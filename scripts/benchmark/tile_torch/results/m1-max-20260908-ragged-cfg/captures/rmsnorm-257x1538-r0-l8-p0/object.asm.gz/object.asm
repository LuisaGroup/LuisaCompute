
/tmp/luisa-ragged-cfg.pbUI2k/capture/rmsnorm-257x1538-r0-l8-p0/object/tile_xir_w8_72043_1788863217710517_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	stp	d15, d14, [sp, #-0xa0]!
       4:      	stp	d13, d12, [sp, #0x10]
       8:      	stp	d11, d10, [sp, #0x20]
       c:      	stp	d9, d8, [sp, #0x30]
      10:      	stp	x28, x27, [sp, #0x40]
      14:      	stp	x26, x25, [sp, #0x50]
      18:      	stp	x24, x23, [sp, #0x60]
      1c:      	stp	x22, x21, [sp, #0x70]
      20:      	stp	x20, x19, [sp, #0x80]
      24:      	stp	x29, x30, [sp, #0x90]
      28:      	sub	sp, sp, #0x4, lsl #12   ; =0x4000
      2c:      	sub	sp, sp, #0x320
      30:      	fmov	s1, wzr
      34:      	add	x8, sp, #0x4, lsl #12   ; =0x4000
      38:      	add	x8, x8, #0x2c8
      3c:      	add	x9, sp, #0x320
      40:      	str	wzr, [x9, #0x3ffc]
      44:      	stur	wzr, [x8, #0x51]
      48:      	stur	xzr, [x8, #0x34]
      4c:      	stur	xzr, [x8, #0x44]
      50:      	stur	xzr, [x8, #0x3c]
      54:      	stur	xzr, [x8, #0x14]
      58:      	stur	xzr, [x8, #0x24]
      5c:      	stur	xzr, [x8, #0x1c]
      60:      	str	xzr, [sp, #0x42d0]
      64:      	str	xzr, [sp, #0x42c8]
      68:      	ldr	x6, [x0]
      6c:      	ldr	x7, [x0, #0x10]
      70:      	ldr	x19, [x0, #0x30]
      74:      	ldr	w9, [x1]
      78:      	ldr	w10, [x1, #0x24]
      7c:      	dup.4s	v0, w2
      80:      	adrp	x11, 0x0 <ltmp0>
      84:      	ldr	q2, [x11]
      88:      	adrp	x11, 0x0 <ltmp0>
      8c:      	ldr	q3, [x11]
      90:      	cmhi.4s	v3, v0, v3
      94:      	cmhi.4s	v0, v0, v2
      98:      	uzp1.8h	v2, v0, v3
      9c:      	xtn.8b	v0, v2
      a0:      	adrp	x11, 0x0 <ltmp0>
      a4:      	ldr	q3, [x11]
      a8:      	and.16b	v3, v2, v3
      ac:      	addv.8h	h3, v3
      b0:      	fmov	w11, s3
      b4:      	and	w11, w11, #0xff
      b8:      	fmov	s3, w11
      bc:      	cmeq.8b	v1, v3, v1
      c0:      	umov.b	w11, v1[0]
      c4:      	and	w12, w11, #0x1
      c8:      	fmov	s1, w12
      cc:      	ubfx	w12, w11, #1, #1
      d0:      	mov.b	v1[1], w12
      d4:      	ubfx	w12, w11, #2, #1
      d8:      	mov.b	v1[2], w12
      dc:      	ubfx	w12, w11, #3, #1
      e0:      	mov.b	v1[3], w12
      e4:      	ubfx	w12, w11, #4, #1
      e8:      	mov.b	v1[4], w12
      ec:      	ubfx	w12, w11, #5, #1
      f0:      	mov.b	v1[5], w12
      f4:      	ubfx	w12, w11, #6, #1
      f8:      	mov.b	v1[6], w12
      fc:      	ubfx	w11, w11, #7, #1
     100:      	mov.b	v1[7], w11
     104:      	movi.8b	v3, #0x1
     108:      	eor.8b	v1, v1, v3
     10c:      	and.8b	v1, v1, v0
     110:      	umaxv.8h	h2, v2
     114:      	fmov	w11, s2
     118:      	shl.8b	v1, v1, #0x7
     11c:      	cmlt.8b	v1, v1, #0
     120:      	adrp	x12, 0x0 <ltmp0>
     124:      	ldr	d2, [x12]
     128:      	and.8b	v1, v1, v2
     12c:      	addv.8b	b1, v1
     130:      	str	b1, [x8, #0x50]
     134:      	add	x12, sp, #0x318
     138:      	str	wzr, [x12, #0x3ffc]
     13c:      	add	x12, sp, #0x2fc
     140:      	str	wzr, [x12, #0x3ffc]
     144:      	add	x12, sp, #0x2f8
     148:      	str	wzr, [x12, #0x3ffc]
     14c:      	add	x12, sp, #0x2dc
     150:      	str	wzr, [x12, #0x3ffc]
     154:      	tbz	w11, #0x0, 0x53b8 <ltmp0+0x53b8>
     158:      	mov	w30, #0x0               ; =0
     15c:      	stp	xzr, xzr, [sp, #0x40]
     160:      	stp	xzr, xzr, [sp, #0x30]
     164:      	stp	xzr, xzr, [sp, #0x20]
     168:      	stp	xzr, xzr, [sp, #0x10]
     16c:      	add	x20, sp, #0x2, lsl #12  ; =0x2000
     170:      	add	x20, x20, #0xaa8
     174:      	dup.2d	v3, x20
     178:      	add	x11, sp, #0x1, lsl #12  ; =0x1000
     17c:      	add	x11, x11, #0x288
     180:      	dup.2d	v1, x11
     184:      	stp	q3, q1, [sp, #0x60]
     188:      	add	w9, w10, w9, lsl #5
     18c:      	dup.4s	v1, w9
     190:      	str	q1, [sp, #0x50]
     194:      	mov	w9, #0x1800             ; =6144
     198:      	add	x9, x7, x9
     19c:      	str	x9, [sp, #0xa0]
     1a0:      	movi.2d	v18, #0000000000000000
     1a4:      	mov	w16, #0x1               ; =1
     1a8:      	add	x23, sp, #0x4, lsl #12  ; =0x4000
     1ac:      	add	x23, x23, #0x318
     1b0:      	add	x25, sp, #0x4, lsl #12  ; =0x4000
     1b4:      	add	x25, x25, #0x2f8
     1b8:      	add	x26, sp, #0x4, lsl #12  ; =0x4000
     1bc:      	add	x26, x26, #0x2d8
     1c0:      	adrp	x27, 0x0 <ltmp0>
     1c4:      	add	x28, sp, #0x4, lsl #12  ; =0x4000
     1c8:      	add	x28, x28, #0x2d0
     1cc:      	movi.2d	v1, #0000000000000000
     1d0:      	str	q1, [sp, #0x410]
     1d4:      	movi.2d	v23, #0000000000000000
     1d8:      	movi.2d	v28, #0000000000000000
     1dc:      	str	q1, [sp, #0x340]
     1e0:      	str	q1, [sp, #0x130]
     1e4:      	movi.2d	v29, #0000000000000000
     1e8:      	movi.2d	v10, #0000000000000000
     1ec:      	movi.2d	v12, #0000000000000000
     1f0:      	movi.2d	v27, #0000000000000000
     1f4:      	stp	q1, q1, [sp, #0x220]
     1f8:      	str	q1, [sp, #0x210]
     1fc:      	stp	q1, q1, [sp, #0x240]
     200:      	stp	q1, q1, [sp, #0x3c0]
     204:      	movi.2d	v26, #0000000000000000
     208:      	add	x17, sp, #0x1, lsl #12  ; =0x1000
     20c:      	add	x17, x17, #0x160
     210:      	mov	w4, #-0x1               ; =-1
     214:      	add	x1, sp, #0x1, lsl #12   ; =0x1000
     218:      	add	x1, x1, #0x140
     21c:      	mov	w5, #0xc0               ; =192
     220:      	add	x22, sp, #0x1, lsl #12  ; =0x1000
     224:      	add	x22, x22, #0x60
     228:      	add	x3, sp, #0xdd0
     22c:      	mov	w9, #0x1                ; =1
     230:      	str	q1, [sp, #0x3b0]
     234:      	stp	q1, q1, [sp, #0xf0]
     238:      	stp	q1, q1, [sp, #0x110]
     23c:      	stp	q1, q1, [sp, #0x260]
     240:      	stp	q1, q1, [sp, #0x320]
     244:      	stp	q1, q1, [sp, #0x3f0]
     248:      	stp	q1, q1, [sp, #0x350]
     24c:      	movi.2d	v22, #0000000000000000
     250:      	movi.2d	v13, #0000000000000000
     254:      	movi.2d	v9, #0000000000000000
     258:      	movi.2d	v11, #0000000000000000
     25c:      	str	q1, [sp, #0x310]
     260:      	movi.2d	v15, #0000000000000000
     264:      	movi.2d	v19, #0000000000000000
     268:      	str	q1, [sp, #0x3e0]
     26c:      	stp	q1, q1, [sp, #0x1a0]
     270:      	stp	q1, q1, [sp, #0x180]
     274:      	stp	q1, q1, [sp, #0x390]
     278:      	stp	q1, q1, [sp, #0x370]
     27c:      	stp	q1, q1, [sp, #0x2a0]
     280:      	stp	q1, q1, [sp, #0x280]
     284:      	movi.2d	v24, #0000000000000000
     288:      	movi.2d	v14, #0000000000000000
     28c:      	movi.2d	v31, #0000000000000000
     290:      	movi.2d	v5, #0000000000000000
     294:      	str	q1, [sp, #0x420]
     298:      	str	q1, [sp, #0x430]
     29c:      	str	q1, [sp, #0x440]
     2a0:      	str	q1, [sp, #0x450]
     2a4:      	stp	x7, x6, [sp, #0x90]
     2a8:      	str	x19, [sp, #0x88]
     2ac:      	b	0x2d0 <ltmp0+0x2d0>
     2b0:      	str	b3, [x23, w9, uxtw]
     2b4:      	orr	w30, w10, w30
     2b8:      	mov	w10, #0x5               ; =5
     2bc:      	str	w10, [x25, w9, uxtw #2]
     2c0:      	add	w24, w9, #0x1
     2c4:      	str	w11, [x26, w9, uxtw #2]
     2c8:      	mov	x9, x24
     2cc:      	cbz	w24, 0x53b8 <ltmp0+0x53b8>
     2d0:      	sub	w24, w9, #0x1
     2d4:      	ldr	w10, [x25, w24, sxtw #2]
     2d8:      	cmp	w10, #0x14
     2dc:      	b.hi	0x5400 <ltmp0+0x5400>
     2e0:      	sxtw	x21, w24
     2e4:      	ldrb	w11, [x23, x21]
     2e8:      	and	w13, w11, #0x1
     2ec:      	fmov	s21, w13
     2f0:      	ubfx	w13, w11, #1, #1
     2f4:      	mov.b	v21[1], w13
     2f8:      	ubfx	w13, w11, #2, #1
     2fc:      	mov.b	v21[2], w13
     300:      	ubfx	w13, w11, #3, #1
     304:      	mov.b	v21[3], w13
     308:      	ubfx	w13, w11, #4, #1
     30c:      	mov.b	v21[4], w13
     310:      	ubfx	w13, w11, #5, #1
     314:      	mov.b	v21[5], w13
     318:      	ubfx	w13, w11, #6, #1
     31c:      	mov.b	v21[6], w13
     320:      	lsr	w11, w11, #7
     324:      	mov.b	v21[7], w11
     328:      	ldr	w14, [x26, w24, sxtw #2]
     32c:      	adrp	x12, 0x0 <ltmp0>
     330:      	add	x12, x12, #0x0
     334:      	adr	x11, 0x344 <ltmp0+0x344>
     338:      	ldrh	w13, [x12, x10, lsl #1]
     33c:      	add	x11, x11, x13, lsl #2
     340:      	br	x11
     344:      	shl.8b	v1, v21, #0x7
     348:      	cmlt.8b	v1, v1, #0
     34c:      	umaxv.8b	b1, v1
     350:      	fmov	w10, s1
     354:      	mov	b1, v21[6]
     358:      	mov.b	v1[4], v21[7]
     35c:      	ushll.2d	v1, v1, #0x0
     360:      	shl.2d	v1, v1, #0x3f
     364:      	cmlt.2d	v1, v1, #0
     368:      	adrp	x11, 0x0 <ltmp0>
     36c:      	ldr	q3, [x11]
     370:      	bit.16b	v5, v3, v1
     374:      	mov	b3, v21[4]
     378:      	mov.b	v3[4], v21[5]
     37c:      	ushll.2d	v3, v3, #0x0
     380:      	shl.2d	v3, v3, #0x3f
     384:      	cmlt.2d	v3, v3, #0
     388:      	adrp	x11, 0x0 <ltmp0>
     38c:      	ldr	q4, [x11]
     390:      	mov	b6, v21[2]
     394:      	mov.b	v6[4], v21[3]
     398:      	bit.16b	v31, v4, v3
     39c:      	ushll.2d	v4, v6, #0x0
     3a0:      	shl.2d	v4, v4, #0x3f
     3a4:      	cmlt.2d	v4, v4, #0
     3a8:      	adrp	x11, 0x0 <ltmp0>
     3ac:      	ldr	q6, [x11]
     3b0:      	bit.16b	v14, v6, v4
     3b4:      	mov	b6, v21[0]
     3b8:      	mov.b	v6[4], v21[1]
     3bc:      	ushll.2d	v6, v6, #0x0
     3c0:      	shl.2d	v6, v6, #0x3f
     3c4:      	cmlt.2d	v6, v6, #0
     3c8:      	adrp	x11, 0x0 <ltmp0>
     3cc:      	ldr	q7, [x11]
     3d0:      	mov.16b	v30, v6
     3d4:      	bsl.16b	v30, v7, v24
     3d8:      	zip1.8b	v7, v21, v0
     3dc:      	ushll.4s	v7, v7, #0x0
     3e0:      	shl.4s	v7, v7, #0x1f
     3e4:      	cmlt.4s	v7, v7, #0
     3e8:      	mov.16b	v24, v19
     3ec:      	ldr	q19, [sp, #0x50]
     3f0:      	and.16b	v16, v7, v19
     3f4:      	zip2.8b	v17, v21, v0
     3f8:      	ushll.4s	v17, v17, #0x0
     3fc:      	shl.4s	v17, v17, #0x1f
     400:      	cmlt.4s	v17, v17, #0
     404:      	and.16b	v19, v17, v19
     408:      	movi.4s	v20, #0x3
     40c:      	and.16b	v7, v7, v20
     410:      	and.16b	v17, v17, v20
     414:      	neg.4s	v17, v17
     418:      	ushl.4s	v17, v19, v17
     41c:      	neg.4s	v7, v7
     420:      	ushl.4s	v7, v16, v7
     424:      	ushll.2d	v16, v7, #0x0
     428:      	ushll2.2d	v7, v7, #0x0
     42c:      	ushll.2d	v19, v17, #0x0
     430:      	ushll2.2d	v17, v17, #0x0
     434:      	ldr	q20, [sp, #0x280]
     438:      	bit.16b	v20, v17, v1
     43c:      	ldr	q17, [sp, #0x290]
     440:      	bit.16b	v17, v19, v3
     444:      	stp	q20, q17, [sp, #0x280]
     448:      	ldr	q17, [sp, #0x2a0]
     44c:      	bit.16b	v17, v7, v4
     450:      	ldr	q7, [sp, #0x2b0]
     454:      	bit.16b	v7, v16, v6
     458:      	stp	q17, q7, [sp, #0x2a0]
     45c:      	ldr	q7, [sp, #0x60]
     460:      	ldr	q16, [sp, #0x180]
     464:      	bit.16b	v16, v7, v1
     468:      	str	q16, [sp, #0x180]
     46c:      	ldr	q16, [sp, #0x190]
     470:      	bit.16b	v16, v7, v3
     474:      	str	q16, [sp, #0x190]
     478:      	ldr	q16, [sp, #0x1a0]
     47c:      	bit.16b	v16, v7, v4
     480:      	str	q16, [sp, #0x1a0]
     484:      	ldr	q16, [sp, #0x1b0]
     488:      	bit.16b	v16, v7, v6
     48c:      	str	q16, [sp, #0x1b0]
     490:      	ldr	q7, [x27]
     494:      	ldr	q16, [sp, #0x370]
     498:      	bit.16b	v16, v7, v1
     49c:      	str	q16, [sp, #0x370]
     4a0:      	adrp	x11, 0x0 <ltmp0>
     4a4:      	ldr	q7, [x11]
     4a8:      	ldr	q16, [sp, #0x380]
     4ac:      	bit.16b	v16, v7, v3
     4b0:      	str	q16, [sp, #0x380]
     4b4:      	adrp	x11, 0x0 <ltmp0>
     4b8:      	ldr	q7, [x11]
     4bc:      	ldr	q16, [sp, #0x390]
     4c0:      	bit.16b	v16, v7, v4
     4c4:      	str	q16, [sp, #0x390]
     4c8:      	adrp	x11, 0x0 <ltmp0>
     4cc:      	ldr	q7, [x11]
     4d0:      	ldr	q16, [sp, #0x3a0]
     4d4:      	bit.16b	v16, v7, v6
     4d8:      	str	q16, [sp, #0x3a0]
     4dc:      	ldr	q7, [sp, #0x3e0]
     4e0:      	bic.16b	v7, v7, v1
     4e4:      	str	q7, [sp, #0x3e0]
     4e8:      	bic.16b	v19, v24, v3
     4ec:      	bic.16b	v15, v15, v4
     4f0:      	ldr	q1, [sp, #0x310]
     4f4:      	bic.16b	v1, v1, v6
     4f8:      	str	q1, [sp, #0x310]
     4fc:      	tbz	w10, #0x0, 0x1068 <ltmp0+0x1068>
     500:      	mov.16b	v24, v30
     504:      	b	0x5fc <ltmp0+0x5fc>
     508:      	shl.8b	v1, v21, #0x7
     50c:      	cmlt.8b	v1, v1, #0
     510:      	and.8b	v1, v1, v2
     514:      	addv.8b	b1, v1
     518:      	fmov	w10, s1
     51c:      	b	0x1d14 <ltmp0+0x1d14>
     520:      	shl.8b	v1, v21, #0x7
     524:      	cmlt.8b	v1, v1, #0
     528:      	and.8b	v1, v1, v2
     52c:      	addv.8b	b1, v1
     530:      	fmov	w11, s1
     534:      	b	0xb10 <ltmp0+0xb10>
     538:      	shl.8b	v1, v21, #0x7
     53c:      	cmlt.8b	v1, v1, #0
     540:      	and.8b	v3, v1, v2
     544:      	addv.8b	b3, v3
     548:      	fmov	w10, s3
     54c:      	rbit	w10, w10
     550:      	clz	w10, w10
     554:      	umaxv.8b	b1, v1
     558:      	fmov	w11, s1
     55c:      	eor	w3, w11, #0x1
     560:      	tst	w11, #0x1
     564:      	csel	w10, w10, wzr, ne
     568:      	b	0x664 <ltmp0+0x664>
     56c:      	shl.8b	v1, v21, #0x7
     570:      	cmlt.8b	v1, v1, #0
     574:      	umaxv.8b	b1, v1
     578:      	fmov	w10, s1
     57c:      	eor	w11, w10, #0x1
     580:      	b	0x1310 <ltmp0+0x1310>
     584:      	shl.8b	v1, v21, #0x7
     588:      	cmlt.8b	v1, v1, #0
     58c:      	and.8b	v1, v1, v2
     590:      	addv.8b	b1, v1
     594:      	fmov	w11, s1
     598:      	b	0x29d8 <ltmp0+0x29d8>
     59c:      	shl.8b	v1, v21, #0x7
     5a0:      	cmlt.8b	v1, v1, #0
     5a4:      	and.8b	v1, v1, v2
     5a8:      	addv.8b	b1, v1
     5ac:      	fmov	w11, s1
     5b0:      	b	0x3ef4 <ltmp0+0x3ef4>
     5b4:      	shl.8b	v1, v21, #0x7
     5b8:      	cmlt.8b	v1, v1, #0
     5bc:      	and.8b	v1, v1, v2
     5c0:      	addv.8b	b1, v1
     5c4:      	fmov	w11, s1
     5c8:      	b	0x898 <ltmp0+0x898>
     5cc:      	shl.8b	v1, v21, #0x7
     5d0:      	cmlt.8b	v1, v1, #0
     5d4:      	and.8b	v1, v1, v2
     5d8:      	addv.8b	b1, v1
     5dc:      	fmov	w11, s1
     5e0:      	b	0x3004 <ltmp0+0x3004>
     5e4:      	shl.8b	v1, v21, #0x7
     5e8:      	cmlt.8b	v1, v1, #0
     5ec:      	and.8b	v1, v1, v2
     5f0:      	addv.8b	b1, v1
     5f4:      	fmov	w11, s1
     5f8:      	b	0x36c8 <ltmp0+0x36c8>
     5fc:      	shl.8b	v1, v21, #0x7
     600:      	cmlt.8b	v1, v1, #0
     604:      	and.8b	v3, v1, v2
     608:      	addv.8b	b3, v3
     60c:      	fmov	w11, s3
     610:      	umaxv.8b	b1, v1
     614:      	fmov	w13, s1
     618:      	rbit	w10, w11
     61c:      	clz	w10, w10
     620:      	tst	w13, #0x1
     624:      	csel	w13, w10, wzr, ne
     628:      	ldr	q1, [sp, #0x310]
     62c:      	str	q1, [sp, #0x1240]
     630:      	str	q15, [sp, #0x1250]
     634:      	str	q19, [sp, #0x1260]
     638:      	ldr	q1, [sp, #0x3e0]
     63c:      	str	q1, [sp, #0x1270]
     640:      	and	x13, x13, #0x7
     644:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     648:      	add	x12, x12, #0x240
     64c:      	ldr	x13, [x12, x13, lsl #3]
     650:      	cmp	x13, #0xc0
     654:      	b.ge	0x890 <ltmp0+0x890>
     658:      	tst	w11, #0xff
     65c:      	b.eq	0x1034 <ltmp0+0x1034>
     660:      	mov	w3, #0x0                ; =0
     664:      	ldr	q1, [sp, #0x310]
     668:      	str	q1, [sp, #0x520]
     66c:      	str	q15, [sp, #0x530]
     670:      	str	q19, [sp, #0x540]
     674:      	ldr	q1, [sp, #0x3e0]
     678:      	str	q1, [sp, #0x550]
     67c:      	mov	w13, w10
     680:      	ubfiz	x15, x13, #3, #3
     684:      	add	x11, sp, #0x520
     688:      	ldr	x11, [x11, x15]
     68c:      	lsl	x0, x11, #3
     690:      	dup.2d	v1, x0
     694:      	add.2d	v3, v1, v24
     698:      	add.2d	v4, v1, v14
     69c:      	add.2d	v6, v1, v31
     6a0:      	add.2d	v1, v1, v5
     6a4:      	ldr	q7, [sp, #0x2b0]
     6a8:      	str	q7, [sp, #0x4a0]
     6ac:      	ldr	q7, [sp, #0x2a0]
     6b0:      	str	q7, [sp, #0x4b0]
     6b4:      	ldr	q7, [sp, #0x290]
     6b8:      	str	q7, [sp, #0x4c0]
     6bc:      	ldr	q7, [sp, #0x280]
     6c0:      	str	q7, [sp, #0x4d0]
     6c4:      	add	x12, sp, #0x4a0
     6c8:      	ldr	x0, [x12, x15]
     6cc:      	str	q1, [sp, #0x510]
     6d0:      	str	q6, [sp, #0x500]
     6d4:      	str	q4, [sp, #0x4f0]
     6d8:      	str	q3, [sp, #0x4e0]
     6dc:      	add	x12, sp, #0x4e0
     6e0:      	ldr	x15, [x12, x15]
     6e4:      	neg	x2, x13
     6e8:      	mov	w12, #0x602             ; =1538
     6ec:      	madd	x0, x0, x12, x2
     6f0:      	add	x15, x0, x15
     6f4:      	add	x15, x6, x15, lsl #2
     6f8:      	shl.8b	v1, v21, #0x7
     6fc:      	cmlt.8b	v1, v1, #0
     700:      	and.8b	v1, v1, v2
     704:      	addv.8b	b1, v1
     708:      	fmov	w0, s1
     70c:      	movi.2d	v1, #0000000000000000
     710:      	movi.2d	v3, #0000000000000000
     714:      	tbnz	w0, #0x0, 0x83c <ltmp0+0x83c>
     718:      	tbnz	w0, #0x1, 0x844 <ltmp0+0x844>
     71c:      	tbnz	w0, #0x2, 0x850 <ltmp0+0x850>
     720:      	tbnz	w0, #0x3, 0x85c <ltmp0+0x85c>
     724:      	tbnz	w0, #0x4, 0x868 <ltmp0+0x868>
     728:      	tbnz	w0, #0x5, 0x874 <ltmp0+0x874>
     72c:      	tbnz	w0, #0x6, 0x880 <ltmp0+0x880>
     730:      	tbz	w0, #0x7, 0x73c <ltmp0+0x73c>
     734:      	add	x15, x15, #0x1c
     738:      	ld1.s	{ v3 }[3], [x15]
     73c:      	lsl	x15, x11, #5
     740:      	dup.2d	v4, x15
     744:      	ldp	q6, q17, [sp, #0x370]
     748:      	add.2d	v6, v4, v6
     74c:      	ldp	q16, q7, [sp, #0x390]
     750:      	add.2d	v7, v4, v7
     754:      	add.2d	v16, v4, v16
     758:      	add.2d	v4, v4, v17
     75c:      	str	q16, [sp, #0x470]
     760:      	str	q7, [sp, #0x460]
     764:      	str	q4, [sp, #0x480]
     768:      	str	q6, [sp, #0x490]
     76c:      	and	x10, x10, #0x7
     770:      	add	x12, sp, #0x460
     774:      	ldr	x10, [x12, x10, lsl #3]
     778:      	sub	x13, x10, x13, lsl #2
     77c:      	ands	w10, w3, #0x1
     780:      	csel	x13, xzr, x13, ne
     784:      	add	x13, x20, x13
     788:      	ldp	q4, q6, [x13]
     78c:      	zip2.8b	v7, v21, v0
     790:      	ushll.4s	v7, v7, #0x0
     794:      	shl.4s	v7, v7, #0x1f
     798:      	cmlt.4s	v7, v7, #0
     79c:      	bif.16b	v3, v6, v7
     7a0:      	zip1.8b	v6, v21, v0
     7a4:      	ushll.4s	v6, v6, #0x0
     7a8:      	shl.4s	v6, v6, #0x1f
     7ac:      	cmlt.4s	v6, v6, #0
     7b0:      	bif.16b	v1, v4, v6
     7b4:      	stp	q1, q3, [x13]
     7b8:      	add	x11, x11, #0x1
     7bc:      	dup.2d	v1, x11
     7c0:      	mov	b3, v21[6]
     7c4:      	mov.b	v3[4], v21[7]
     7c8:      	ushll.2d	v3, v3, #0x0
     7cc:      	shl.2d	v3, v3, #0x3f
     7d0:      	cmlt.2d	v3, v3, #0
     7d4:      	ldr	q4, [sp, #0x3e0]
     7d8:      	bit.16b	v4, v1, v3
     7dc:      	str	q4, [sp, #0x3e0]
     7e0:      	mov	b3, v21[4]
     7e4:      	mov.b	v3[4], v21[5]
     7e8:      	ushll.2d	v3, v3, #0x0
     7ec:      	shl.2d	v3, v3, #0x3f
     7f0:      	cmlt.2d	v3, v3, #0
     7f4:      	mov	b4, v21[2]
     7f8:      	mov.b	v4[4], v21[3]
     7fc:      	bit.16b	v19, v1, v3
     800:      	ushll.2d	v3, v4, #0x0
     804:      	shl.2d	v3, v3, #0x3f
     808:      	cmlt.2d	v3, v3, #0
     80c:      	bit.16b	v15, v1, v3
     810:      	mov	b3, v21[0]
     814:      	mov.b	v3[4], v21[1]
     818:      	ushll.2d	v3, v3, #0x0
     81c:      	shl.2d	v3, v3, #0x3f
     820:      	cmlt.2d	v3, v3, #0
     824:      	ldr	q4, [sp, #0x310]
     828:      	bit.16b	v4, v1, v3
     82c:      	str	q4, [sp, #0x310]
     830:      	add	x3, sp, #0xdd0
     834:      	cbnz	w10, 0x2c8 <ltmp0+0x2c8>
     838:      	b	0x5fc <ltmp0+0x5fc>
     83c:      	ldr	s1, [x15]
     840:      	tbz	w0, #0x1, 0x71c <ltmp0+0x71c>
     844:      	add	x2, x15, #0x4
     848:      	ld1.s	{ v1 }[1], [x2]
     84c:      	tbz	w0, #0x2, 0x720 <ltmp0+0x720>
     850:      	add	x2, x15, #0x8
     854:      	ld1.s	{ v1 }[2], [x2]
     858:      	tbz	w0, #0x3, 0x724 <ltmp0+0x724>
     85c:      	add	x2, x15, #0xc
     860:      	ld1.s	{ v1 }[3], [x2]
     864:      	tbz	w0, #0x4, 0x728 <ltmp0+0x728>
     868:      	add	x2, x15, #0x10
     86c:      	ld1.s	{ v3 }[0], [x2]
     870:      	tbz	w0, #0x5, 0x72c <ltmp0+0x72c>
     874:      	add	x2, x15, #0x14
     878:      	ld1.s	{ v3 }[1], [x2]
     87c:      	tbz	w0, #0x6, 0x730 <ltmp0+0x730>
     880:      	add	x2, x15, #0x18
     884:      	ld1.s	{ v3 }[2], [x2]
     888:      	tbnz	w0, #0x7, 0x734 <ltmp0+0x734>
     88c:      	b	0x73c <ltmp0+0x73c>
     890:      	tst	w11, #0xff
     894:      	b.eq	0x2c8 <ltmp0+0x2c8>
     898:      	mov	w10, #0x2               ; =2
     89c:      	dup.2d	v3, x10
     8a0:      	cmgt.2d	v1, v3, v14
     8a4:      	cmgt.2d	v4, v3, v24
     8a8:      	uzp1.4s	v1, v4, v1
     8ac:      	cmgt.2d	v4, v3, v31
     8b0:      	cmgt.2d	v6, v3, v5
     8b4:      	uzp1.4s	v4, v4, v6
     8b8:      	uzp1.8h	v1, v1, v4
     8bc:      	xtn.8b	v1, v1
     8c0:      	shl.8b	v4, v21, #0x7
     8c4:      	cmlt.8b	v4, v4, #0
     8c8:      	bit.8b	v11, v1, v4
     8cc:      	and.8b	v1, v21, v1
     8d0:      	shl.8b	v1, v1, #0x7
     8d4:      	cmlt.8b	v4, v1, #0
     8d8:      	and.8b	v1, v4, v2
     8dc:      	addv.8b	b1, v1
     8e0:      	umaxv.8b	b4, v4
     8e4:      	fmov	w10, s4
     8e8:      	tbz	w10, #0x0, 0xafc <ltmp0+0xafc>
     8ec:      	cmge.2d	v4, v14, v3
     8f0:      	cmge.2d	v6, v24, v3
     8f4:      	uzp1.4s	v4, v6, v4
     8f8:      	cmge.2d	v6, v31, v3
     8fc:      	cmge.2d	v3, v5, v3
     900:      	uzp1.4s	v3, v6, v3
     904:      	uzp1.8h	v3, v4, v3
     908:      	xtn.8b	v3, v3
     90c:      	and.8b	v3, v21, v3
     910:      	shl.8b	v3, v3, #0x7
     914:      	cmlt.8b	v3, v3, #0
     918:      	and.8b	v3, v3, v2
     91c:      	addv.8b	b3, v3
     920:      	fmov	w10, s3
     924:      	tst	w10, #0xff
     928:      	b.eq	0xafc <ltmp0+0xafc>
     92c:      	subs	w10, w14, #0x1
     930:      	csel	w10, wzr, w10, lo
     934:      	and	w11, w30, #0xff
     938:      	lsr	w13, w11, w10
     93c:      	tst	w13, #0x1
     940:      	ldr	q4, [sp, #0x440]
     944:      	str	q4, [sp, #0x5e0]
     948:      	ldr	q4, [sp, #0x450]
     94c:      	str	q4, [sp, #0x5f0]
     950:      	and	x10, x10, #0x7
     954:      	add	x12, sp, #0x5e0
     958:      	ldr	w10, [x12, x10, lsl #2]
     95c:      	ccmp	w14, #0x0, #0x4, ne
     960:      	ccmp	w10, #0x0, #0x0, ne
     964:      	cset	w10, ne
     968:      	cmp	w11, #0xff
     96c:      	b.ne	0x974 <ltmp0+0x974>
     970:      	tbnz	w10, #0x0, 0x5400 <ltmp0+0x5400>
     974:      	mvn	w11, w30
     978:      	rbit	w11, w11
     97c:      	clz	w11, w11
     980:      	mov	w12, #0xff              ; =255
     984:      	bics	wzr, w12, w30
     988:      	csel	w11, wzr, w11, eq
     98c:      	ubfiz	x13, x11, #2, #3
     990:      	lsl	w15, w16, w11
     994:      	ldr	q6, [sp, #0x440]
     998:      	str	q6, [sp, #0x5c0]
     99c:      	ldr	q4, [sp, #0x450]
     9a0:      	str	q4, [sp, #0x5d0]
     9a4:      	add	x12, sp, #0x5c0
     9a8:      	ldr	w0, [x12, x13]
     9ac:      	cmp	w10, #0x0
     9b0:      	csel	w10, w15, wzr, ne
     9b4:      	csel	w15, wzr, w0, ne
     9b8:      	str	q6, [sp, #0x5a0]
     9bc:      	str	q4, [sp, #0x5b0]
     9c0:      	add	x12, sp, #0x5a0
     9c4:      	str	w15, [x12, x13]
     9c8:      	ldr	q4, [sp, #0x5b0]
     9cc:      	str	q4, [sp, #0x450]
     9d0:      	ldr	q4, [sp, #0x5a0]
     9d4:      	str	q4, [sp, #0x440]
     9d8:      	ldr	q6, [sp, #0x420]
     9dc:      	str	q6, [sp, #0x580]
     9e0:      	ldr	q4, [sp, #0x430]
     9e4:      	str	q4, [sp, #0x590]
     9e8:      	add	x12, sp, #0x580
     9ec:      	ldr	w15, [x12, x13]
     9f0:      	csel	w15, w14, w15, ne
     9f4:      	str	q6, [sp, #0x560]
     9f8:      	str	q4, [sp, #0x570]
     9fc:      	add	x12, sp, #0x560
     a00:      	str	w15, [x12, x13]
     a04:      	ldrb	w13, [x28, x11]
     a08:      	and	w15, w13, #0x1
     a0c:      	fmov	s4, w15
     a10:      	ubfx	w15, w13, #1, #1
     a14:      	mov.b	v4[1], w15
     a18:      	ubfx	w15, w13, #2, #1
     a1c:      	mov.b	v4[2], w15
     a20:      	ubfx	w15, w13, #3, #1
     a24:      	mov.b	v4[3], w15
     a28:      	ubfx	w15, w13, #4, #1
     a2c:      	mov.b	v4[4], w15
     a30:      	ubfx	w15, w13, #5, #1
     a34:      	mov.b	v4[5], w15
     a38:      	ubfx	w15, w13, #6, #1
     a3c:      	mov.b	v4[6], w15
     a40:      	ldr	q6, [sp, #0x570]
     a44:      	str	q6, [sp, #0x430]
     a48:      	ldr	q6, [sp, #0x560]
     a4c:      	str	q6, [sp, #0x420]
     a50:      	lsr	w13, w13, #7
     a54:      	mov.b	v4[7], w13
     a58:      	ldrb	w13, [x8, x11]
     a5c:      	and	w15, w13, #0x1
     a60:      	fmov	s6, w15
     a64:      	ubfx	w15, w13, #1, #1
     a68:      	mov.b	v6[1], w15
     a6c:      	ubfx	w15, w13, #2, #1
     a70:      	mov.b	v6[2], w15
     a74:      	ubfx	w15, w13, #3, #1
     a78:      	mov.b	v6[3], w15
     a7c:      	ubfx	w15, w13, #4, #1
     a80:      	mov.b	v6[4], w15
     a84:      	ubfx	w15, w13, #5, #1
     a88:      	mov.b	v6[5], w15
     a8c:      	ubfx	w15, w13, #6, #1
     a90:      	mov.b	v6[6], w15
     a94:      	lsr	w13, w13, #7
     a98:      	mov.b	v6[7], w13
     a9c:      	csetm	w13, ne
     aa0:      	dup.8b	v7, w13
     aa4:      	bit.8b	v4, v21, v7
     aa8:      	shl.8b	v4, v4, #0x7
     aac:      	cmlt.8b	v4, v4, #0
     ab0:      	and.8b	v4, v4, v2
     ab4:      	addv.8b	b4, v4
     ab8:      	str	b4, [x28, x11]
     abc:      	bic.8b	v4, v6, v7
     ac0:      	shl.8b	v4, v4, #0x7
     ac4:      	cmlt.8b	v4, v4, #0
     ac8:      	and.8b	v4, v4, v2
     acc:      	addv.8b	b4, v4
     ad0:      	str	b4, [x8, x11]
     ad4:      	csinc	w11, w14, w11, eq
     ad8:      	cmp	w24, #0x8
     adc:      	b.hs	0x5400 <ltmp0+0x5400>
     ae0:      	str	b1, [x23, x21]
     ae4:      	mov	w12, #0x4               ; =4
     ae8:      	str	w12, [x25, x21, lsl #2]
     aec:      	str	w11, [x26, x21, lsl #2]
     af0:      	cmp	w9, #0x8
     af4:      	b.lo	0x2b0 <ltmp0+0x2b0>
     af8:      	b	0x5400 <ltmp0+0x5400>
     afc:      	fmov	w10, s1
     b00:      	tst	w10, #0xff
     b04:      	b.eq	0x103c <ltmp0+0x103c>
     b08:      	tst	w11, #0xff
     b0c:      	b.eq	0x2c8 <ltmp0+0x2c8>
     b10:      	rbit	w10, w11
     b14:      	clz	w10, w10
     b18:      	tst	w11, #0xff
     b1c:      	csel	w10, wzr, w10, eq
     b20:      	ldp	q1, q3, [sp, #0x2a0]
     b24:      	str	q3, [sp, #0x1200]
     b28:      	str	q1, [sp, #0x1210]
     b2c:      	ldp	q1, q3, [sp, #0x280]
     b30:      	str	q3, [sp, #0x1220]
     b34:      	str	q1, [sp, #0x1230]
     b38:      	ubfiz	x13, x10, #3, #3
     b3c:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     b40:      	add	x12, x12, #0x200
     b44:      	ldr	x15, [x12, x13]
     b48:      	str	q24, [sp, #0x11c0]
     b4c:      	str	q14, [sp, #0x11d0]
     b50:      	str	q31, [sp, #0x11e0]
     b54:      	str	q5, [sp, #0x11f0]
     b58:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     b5c:      	add	x12, x12, #0x1c0
     b60:      	ldr	x13, [x12, x13]
     b64:      	sub	x13, x13, x10
     b68:      	mov	w12, #0x602             ; =1538
     b6c:      	madd	x13, x15, x12, x13
     b70:      	add	x13, x6, x13, lsl #2
     b74:      	mov	w12, #0x1800            ; =6144
     b78:      	add	x13, x13, x12
     b7c:      	shl.8b	v1, v21, #0x7
     b80:      	cmlt.8b	v1, v1, #0
     b84:      	and.8b	v1, v1, v2
     b88:      	addv.8b	b1, v1
     b8c:      	fmov	w15, s1
     b90:      	movi.2d	v1, #0000000000000000
     b94:      	movi.2d	v3, #0000000000000000
     b98:      	tbnz	w15, #0x0, 0xfe0 <ltmp0+0xfe0>
     b9c:      	tbnz	w15, #0x1, 0xfe8 <ltmp0+0xfe8>
     ba0:      	tbnz	w15, #0x2, 0xff4 <ltmp0+0xff4>
     ba4:      	tbnz	w15, #0x3, 0x1000 <ltmp0+0x1000>
     ba8:      	tbnz	w15, #0x4, 0x100c <ltmp0+0x100c>
     bac:      	tbnz	w15, #0x5, 0x1018 <ltmp0+0x1018>
     bb0:      	tbnz	w15, #0x6, 0x1024 <ltmp0+0x1024>
     bb4:      	tbz	w15, #0x7, 0xbc0 <ltmp0+0xbc0>
     bb8:      	add	x13, x13, #0x1c
     bbc:      	ld1.s	{ v3 }[3], [x13]
     bc0:      	ldp	q4, q6, [sp, #0x390]
     bc4:      	str	q6, [sp, #0x1180]
     bc8:      	str	q4, [sp, #0x1190]
     bcc:      	ldp	q4, q6, [sp, #0x370]
     bd0:      	str	q6, [sp, #0x11a0]
     bd4:      	str	q4, [sp, #0x11b0]
     bd8:      	and	x13, x10, #0x7
     bdc:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     be0:      	add	x12, x12, #0x180
     be4:      	ldr	x13, [x12, x13, lsl #3]
     be8:      	sub	x10, x13, x10, lsl #2
     bec:      	mov	w12, #0x1800            ; =6144
     bf0:      	add	x10, x10, x12
     bf4:      	ands	w11, w11, #0xff
     bf8:      	csel	x10, xzr, x10, eq
     bfc:      	add	x10, x20, x10
     c00:      	ldp	q4, q6, [x10]
     c04:      	zip2.8b	v7, v21, v0
     c08:      	ushll.4s	v7, v7, #0x0
     c0c:      	shl.4s	v7, v7, #0x1f
     c10:      	cmlt.4s	v7, v7, #0
     c14:      	bif.16b	v3, v6, v7
     c18:      	zip1.8b	v6, v21, v0
     c1c:      	ushll.4s	v6, v6, #0x0
     c20:      	shl.4s	v6, v6, #0x1f
     c24:      	cmlt.4s	v6, v6, #0
     c28:      	bif.16b	v1, v4, v6
     c2c:      	stp	q1, q3, [x10]
     c30:      	cbz	w11, 0x2c8 <ltmp0+0x2c8>
     c34:      	cbz	w14, 0xdf8 <ltmp0+0xdf8>
     c38:      	mov	w10, #0x0               ; =0
     c3c:      	shl.8b	v1, v21, #0x7
     c40:      	cmlt.8b	v1, v1, #0
     c44:      	and.8b	v3, v1, v2
     c48:      	addv.8b	b3, v3
     c4c:      	fmov	w11, s3
     c50:      	umaxv.8b	b1, v1
     c54:      	fmov	w2, s1
     c58:      	sub	w13, w14, #0x1
     c5c:      	tst	w11, #0xff
     c60:      	csel	w13, w13, wzr, ne
     c64:      	lsl	w15, w16, w13
     c68:      	and	w11, w15, w30
     c6c:      	tst	w11, #0xff
     c70:      	cset	w3, ne
     c74:      	ldr	q1, [sp, #0x440]
     c78:      	str	q1, [sp, #0x1160]
     c7c:      	ldr	q1, [sp, #0x450]
     c80:      	str	q1, [sp, #0x1170]
     c84:      	ubfiz	x11, x13, #2, #3
     c88:      	ldr	w0, [x17, x11]
     c8c:      	cmp	w0, #0x0
     c90:      	cset	w0, eq
     c94:      	and	w2, w3, w2
     c98:      	ldrb	w3, [x28, w13, sxtw]
     c9c:      	and	w5, w3, #0x1
     ca0:      	fmov	s1, w5
     ca4:      	ubfx	w5, w3, #1, #1
     ca8:      	mov.b	v1[1], w5
     cac:      	ubfx	w5, w3, #2, #1
     cb0:      	mov.b	v1[2], w5
     cb4:      	ubfx	w5, w3, #3, #1
     cb8:      	mov.b	v1[3], w5
     cbc:      	ubfx	w5, w3, #4, #1
     cc0:      	mov.b	v1[4], w5
     cc4:      	ubfx	w5, w3, #5, #1
     cc8:      	mov.b	v1[5], w5
     ccc:      	ubfx	w5, w3, #6, #1
     cd0:      	mov.b	v1[6], w5
     cd4:      	lsr	w3, w3, #7
     cd8:      	mov.b	v1[7], w3
     cdc:      	ldrb	w3, [x8, w13, sxtw]
     ce0:      	and	w5, w3, #0x1
     ce4:      	fmov	s3, w5
     ce8:      	ubfx	w5, w3, #1, #1
     cec:      	mov.b	v3[1], w5
     cf0:      	ubfx	w5, w3, #2, #1
     cf4:      	mov.b	v3[2], w5
     cf8:      	ubfx	w5, w3, #3, #1
     cfc:      	mov.b	v3[3], w5
     d00:      	ubfx	w5, w3, #4, #1
     d04:      	mov.b	v3[4], w5
     d08:      	ubfx	w5, w3, #5, #1
     d0c:      	mov.b	v3[5], w5
     d10:      	ubfx	w5, w3, #6, #1
     d14:      	mov.b	v3[6], w5
     d18:      	lsr	w3, w3, #7
     d1c:      	mov.b	v3[7], w3
     d20:      	orr.8b	v4, v21, v3
     d24:      	and.8b	v6, v0, v1
     d28:      	eor.8b	v6, v6, v4
     d2c:      	shl.8b	v6, v6, #0x7
     d30:      	cmlt.8b	v6, v6, #0
     d34:      	umaxv.8b	b6, v6
     d38:      	fmov	w3, s6
     d3c:      	ands	w0, w2, w0
     d40:      	csetm	w2, ne
     d44:      	bics	w3, w0, w3
     d48:      	csetm	w5, ne
     d4c:      	dup.8b	v6, w5
     d50:      	dup.8b	v7, w2
     d54:      	bic.8b	v16, v4, v6
     d58:      	bit.8b	v3, v16, v7
     d5c:      	shl.8b	v3, v3, #0x7
     d60:      	cmlt.8b	v3, v3, #0
     d64:      	and.8b	v3, v3, v2
     d68:      	addv.8b	b3, v3
     d6c:      	str	b3, [x8, w13, sxtw]
     d70:      	bic.8b	v1, v1, v6
     d74:      	shl.8b	v1, v1, #0x7
     d78:      	cmlt.8b	v1, v1, #0
     d7c:      	and.8b	v1, v1, v2
     d80:      	addv.8b	b1, v1
     d84:      	str	b1, [x28, w13, sxtw]
     d88:      	csinv	w13, w4, w15, eq
     d8c:      	dup.8b	v1, w0
     d90:      	and	w30, w13, w30
     d94:      	shl.8b	v1, v1, #0x7
     d98:      	cmlt.8b	v1, v1, #0
     d9c:      	dup.8b	v3, w3
     da0:      	and.8b	v3, v3, v4
     da4:      	ldr	q4, [sp, #0x420]
     da8:      	str	q4, [sp, #0x1140]
     dac:      	ldr	q4, [sp, #0x430]
     db0:      	str	q4, [sp, #0x1150]
     db4:      	ldr	w11, [x1, x11]
     db8:      	csel	w14, w11, w14, ne
     dbc:      	bit.8b	v21, v3, v1
     dc0:      	shl.8b	v1, v21, #0x7
     dc4:      	cmlt.8b	v1, v1, #0
     dc8:      	and.8b	v1, v1, v2
     dcc:      	addv.8b	b1, v1
     dd0:      	fmov	w11, s1
     dd4:      	cmp	w0, #0x1
     dd8:      	b.ne	0xe0c <ltmp0+0xe0c>
     ddc:      	cmp	w14, #0x0
     de0:      	ccmp	w10, #0x6, #0x2, ne
     de4:      	b.hi	0xe0c <ltmp0+0xe0c>
     de8:      	add	w10, w10, #0x1
     dec:      	tst	w11, #0xff
     df0:      	b.ne	0xc3c <ltmp0+0xc3c>
     df4:      	b	0xe0c <ltmp0+0xe0c>
     df8:      	shl.8b	v1, v21, #0x7
     dfc:      	cmlt.8b	v1, v1, #0
     e00:      	and.8b	v1, v1, v2
     e04:      	addv.8b	b1, v1
     e08:      	fmov	w11, s1
     e0c:      	tst	w11, #0xff
     e10:      	b.eq	0x1070 <ltmp0+0x1070>
     e14:      	rbit	w10, w11
     e18:      	clz	w10, w10
     e1c:      	ldp	q1, q3, [sp, #0x390]
     e20:      	str	q3, [sp, #0x1100]
     e24:      	str	q1, [sp, #0x1110]
     e28:      	ldp	q1, q3, [sp, #0x370]
     e2c:      	str	q3, [sp, #0x1120]
     e30:      	str	q1, [sp, #0x1130]
     e34:      	and	x11, x10, #0x7
     e38:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
     e3c:      	add	x12, x12, #0x100
     e40:      	ldr	x11, [x12, x11, lsl #3]
     e44:      	lsl	w10, w10, #2
     e48:      	sub	x10, x11, x10
     e4c:      	add	x10, x20, x10
     e50:      	ldp	q1, q3, [x10]
     e54:      	fmul.4s	v1, v1, v1
     e58:      	fmul.4s	v3, v3, v3
     e5c:      	ldp	q4, q6, [x10, #0x20]
     e60:      	str	q14, [sp, #0x300]
     e64:      	fmul.4s	v30, v4, v4
     e68:      	fmul.4s	v14, v6, v6
     e6c:      	ldp	q7, q16, [x10, #0x40]
     e70:      	fmul.4s	v7, v7, v7
     e74:      	fmul.4s	v8, v16, v16
     e78:      	str	q19, [sp, #0x170]
     e7c:      	ldp	q19, q17, [x10, #0x60]
     e80:      	mov.16b	v4, v11
     e84:      	fmul.4s	v11, v19, v19
     e88:      	fmul.4s	v17, v17, v17
     e8c:      	str	q4, [sp, #0x160]
     e90:      	mov	b20, v21[6]
     e94:      	mov.b	v20[4], v21[7]
     e98:      	ushll.2d	v20, v20, #0x0
     e9c:      	shl.2d	v20, v20, #0x3f
     ea0:      	cmlt.2d	v20, v20, #0
     ea4:      	mov	w10, #0x4               ; =4
     ea8:      	mov.16b	v19, v12
     eac:      	fmov	d12, d0
     eb0:      	mov.16b	v6, v24
     eb4:      	mov.16b	v0, v22
     eb8:      	mov.16b	v24, v28
     ebc:      	mov.16b	v28, v5
     ec0:      	mov.16b	v5, v18
     ec4:      	mov.16b	v22, v10
     ec8:      	mov.16b	v10, v0
     ecc:      	mov.16b	v0, v23
     ed0:      	dup.2d	v23, x10
     ed4:      	ldr	q4, [sp, #0x400]
     ed8:      	bit.16b	v4, v23, v20
     edc:      	str	q4, [sp, #0x400]
     ee0:      	mov	b20, v21[4]
     ee4:      	mov.b	v20[4], v21[5]
     ee8:      	ushll.2d	v20, v20, #0x0
     eec:      	shl.2d	v20, v20, #0x3f
     ef0:      	cmlt.2d	v20, v20, #0
     ef4:      	bit.16b	v9, v23, v20
     ef8:      	mov	b20, v21[2]
     efc:      	mov.b	v20[4], v21[3]
     f00:      	ushll.2d	v20, v20, #0x0
     f04:      	shl.2d	v20, v20, #0x3f
     f08:      	cmlt.2d	v20, v20, #0
     f0c:      	bit.16b	v13, v23, v20
     f10:      	mov	b20, v21[0]
     f14:      	mov.b	v20[4], v21[1]
     f18:      	ushll.2d	v20, v20, #0x0
     f1c:      	shl.2d	v20, v20, #0x3f
     f20:      	cmlt.2d	v20, v20, #0
     f24:      	bit.16b	v10, v23, v20
     f28:      	zip1.8b	v20, v21, v0
     f2c:      	ushll.4s	v20, v20, #0x0
     f30:      	shl.4s	v20, v20, #0x1f
     f34:      	cmlt.4s	v20, v20, #0
     f38:      	zip2.8b	v23, v21, v0
     f3c:      	ushll.4s	v23, v23, #0x0
     f40:      	shl.4s	v23, v23, #0x1f
     f44:      	cmlt.4s	v23, v23, #0
     f48:      	ldr	q18, [sp, #0x350]
     f4c:      	bit.16b	v18, v3, v23
     f50:      	ldr	q3, [sp, #0x360]
     f54:      	bit.16b	v3, v1, v20
     f58:      	stp	q18, q3, [sp, #0x350]
     f5c:      	ldr	q1, [sp, #0x3f0]
     f60:      	bit.16b	v1, v14, v23
     f64:      	str	q1, [sp, #0x3f0]
     f68:      	ldr	q1, [sp, #0x320]
     f6c:      	bit.16b	v1, v30, v20
     f70:      	ldr	q14, [sp, #0x300]
     f74:      	str	q1, [sp, #0x320]
     f78:      	ldr	q1, [sp, #0x330]
     f7c:      	bit.16b	v1, v8, v23
     f80:      	str	q1, [sp, #0x330]
     f84:      	ldr	q1, [sp, #0x250]
     f88:      	bit.16b	v1, v7, v20
     f8c:      	str	q1, [sp, #0x250]
     f90:      	ldr	q1, [sp, #0x270]
     f94:      	bit.16b	v1, v17, v23
     f98:      	mov.16b	v23, v0
     f9c:      	mov.16b	v0, v10
     fa0:      	mov.16b	v10, v22
     fa4:      	str	q1, [sp, #0x270]
     fa8:      	mov.16b	v18, v5
     fac:      	mov.16b	v5, v28
     fb0:      	mov.16b	v28, v24
     fb4:      	mov.16b	v22, v0
     fb8:      	mov.16b	v24, v6
     fbc:      	fmov	d0, d12
     fc0:      	mov.16b	v12, v19
     fc4:      	ldr	q1, [sp, #0x260]
     fc8:      	bit.16b	v1, v11, v20
     fcc:      	ldp	q11, q19, [sp, #0x160]
     fd0:      	str	q1, [sp, #0x260]
     fd4:      	mov	w5, #0xc0               ; =192
     fd8:      	add	x3, sp, #0xdd0
     fdc:      	b	0x107c <ltmp0+0x107c>
     fe0:      	ldr	s1, [x13]
     fe4:      	tbz	w15, #0x1, 0xba0 <ltmp0+0xba0>
     fe8:      	add	x0, x13, #0x4
     fec:      	ld1.s	{ v1 }[1], [x0]
     ff0:      	tbz	w15, #0x2, 0xba4 <ltmp0+0xba4>
     ff4:      	add	x0, x13, #0x8
     ff8:      	ld1.s	{ v1 }[2], [x0]
     ffc:      	tbz	w15, #0x3, 0xba8 <ltmp0+0xba8>
    1000:      	add	x0, x13, #0xc
    1004:      	ld1.s	{ v1 }[3], [x0]
    1008:      	tbz	w15, #0x4, 0xbac <ltmp0+0xbac>
    100c:      	add	x0, x13, #0x10
    1010:      	ld1.s	{ v3 }[0], [x0]
    1014:      	tbz	w15, #0x5, 0xbb0 <ltmp0+0xbb0>
    1018:      	add	x0, x13, #0x14
    101c:      	ld1.s	{ v3 }[1], [x0]
    1020:      	tbz	w15, #0x6, 0xbb4 <ltmp0+0xbb4>
    1024:      	add	x0, x13, #0x18
    1028:      	ld1.s	{ v3 }[2], [x0]
    102c:      	tbnz	w15, #0x7, 0xbb8 <ltmp0+0xbb8>
    1030:      	b	0xbc0 <ltmp0+0xbc0>
    1034:      	add	x3, sp, #0xdd0
    1038:      	b	0x2c8 <ltmp0+0x2c8>
    103c:      	tst	w11, #0xff
    1040:      	b.ne	0xc34 <ltmp0+0xc34>
    1044:      	b	0x2c8 <ltmp0+0x2c8>
    1048:      	ldp	q18, q29, [sp, #0x2d0]
    104c:      	ldp	q10, q12, [sp, #0x1f0]
    1050:      	ldr	q27, [sp, #0x2f0]
    1054:      	ldp	q26, q23, [sp, #0x140]
    1058:      	ldr	q3, [sp, #0xe0]
    105c:      	ldr	q19, [sp, #0x170]
    1060:      	mov.16b	v5, v28
    1064:      	mov.16b	v28, v3
    1068:      	mov.16b	v24, v30
    106c:      	b	0x2c8 <ltmp0+0x2c8>
    1070:      	mov	w5, #0xc0               ; =192
    1074:      	add	x3, sp, #0xdd0
    1078:      	b	0x2c8 <ltmp0+0x2c8>
    107c:      	shl.8b	v1, v21, #0x7
    1080:      	cmlt.8b	v1, v1, #0
    1084:      	and.8b	v1, v1, v2
    1088:      	addv.8b	b1, v1
    108c:      	fmov	w10, s1
    1090:      	dup.2d	v3, x5
    1094:      	cmgt.2d	v1, v3, v13
    1098:      	cmgt.2d	v4, v3, v22
    109c:      	uzp1.4s	v1, v4, v1
    10a0:      	cmgt.2d	v4, v3, v9
    10a4:      	ldr	q6, [sp, #0x400]
    10a8:      	cmgt.2d	v6, v3, v6
    10ac:      	uzp1.4s	v4, v4, v6
    10b0:      	uzp1.8h	v1, v1, v4
    10b4:      	xtn.8b	v1, v1
    10b8:      	and.8b	v1, v21, v1
    10bc:      	shl.8b	v1, v1, #0x7
    10c0:      	cmlt.8b	v4, v1, #0
    10c4:      	and.8b	v1, v4, v2
    10c8:      	addv.8b	b1, v1
    10cc:      	fmov	w11, s1
    10d0:      	umaxv.8b	b4, v4
    10d4:      	fmov	w13, s4
    10d8:      	tbz	w13, #0x0, 0x12fc <ltmp0+0x12fc>
    10dc:      	cmge.2d	v4, v13, v3
    10e0:      	cmge.2d	v6, v22, v3
    10e4:      	uzp1.4s	v4, v6, v4
    10e8:      	cmge.2d	v6, v9, v3
    10ec:      	ldr	q7, [sp, #0x400]
    10f0:      	cmge.2d	v3, v7, v3
    10f4:      	uzp1.4s	v3, v6, v3
    10f8:      	uzp1.8h	v3, v4, v3
    10fc:      	xtn.8b	v3, v3
    1100:      	and.8b	v3, v21, v3
    1104:      	shl.8b	v3, v3, #0x7
    1108:      	cmlt.8b	v3, v3, #0
    110c:      	and.8b	v3, v3, v2
    1110:      	addv.8b	b3, v3
    1114:      	fmov	w13, s3
    1118:      	tst	w13, #0xff
    111c:      	b.eq	0x12fc <ltmp0+0x12fc>
    1120:      	subs	w10, w14, #0x1
    1124:      	csel	w10, wzr, w10, lo
    1128:      	and	w11, w30, #0xff
    112c:      	lsr	w13, w11, w10
    1130:      	tst	w13, #0x1
    1134:      	ldr	q4, [sp, #0x440]
    1138:      	str	q4, [sp, #0x680]
    113c:      	ldr	q4, [sp, #0x450]
    1140:      	str	q4, [sp, #0x690]
    1144:      	and	x10, x10, #0x7
    1148:      	add	x12, sp, #0x680
    114c:      	ldr	w10, [x12, x10, lsl #2]
    1150:      	ccmp	w14, #0x0, #0x4, ne
    1154:      	ccmp	w10, #0x1, #0x0, ne
    1158:      	cset	w10, ne
    115c:      	cmp	w11, #0xff
    1160:      	b.ne	0x1168 <ltmp0+0x1168>
    1164:      	tbnz	w10, #0x0, 0x5400 <ltmp0+0x5400>
    1168:      	mvn	w11, w30
    116c:      	rbit	w11, w11
    1170:      	clz	w11, w11
    1174:      	mov	w12, #0xff              ; =255
    1178:      	bics	wzr, w12, w30
    117c:      	csel	w11, wzr, w11, eq
    1180:      	ubfiz	x13, x11, #2, #3
    1184:      	lsl	w15, w16, w11
    1188:      	ldr	q6, [sp, #0x440]
    118c:      	str	q6, [sp, #0x660]
    1190:      	ldr	q4, [sp, #0x450]
    1194:      	str	q4, [sp, #0x670]
    1198:      	add	x12, sp, #0x660
    119c:      	ldr	w0, [x12, x13]
    11a0:      	cmp	w10, #0x0
    11a4:      	csel	w10, w15, wzr, ne
    11a8:      	csinc	w15, w0, wzr, eq
    11ac:      	str	q6, [sp, #0x640]
    11b0:      	str	q4, [sp, #0x650]
    11b4:      	add	x12, sp, #0x640
    11b8:      	str	w15, [x12, x13]
    11bc:      	ldr	q4, [sp, #0x650]
    11c0:      	str	q4, [sp, #0x450]
    11c4:      	ldr	q4, [sp, #0x640]
    11c8:      	str	q4, [sp, #0x440]
    11cc:      	ldr	q6, [sp, #0x420]
    11d0:      	str	q6, [sp, #0x620]
    11d4:      	ldr	q4, [sp, #0x430]
    11d8:      	str	q4, [sp, #0x630]
    11dc:      	add	x12, sp, #0x620
    11e0:      	ldr	w15, [x12, x13]
    11e4:      	csel	w15, w14, w15, ne
    11e8:      	str	q6, [sp, #0x600]
    11ec:      	str	q4, [sp, #0x610]
    11f0:      	add	x12, sp, #0x600
    11f4:      	str	w15, [x12, x13]
    11f8:      	ldrb	w13, [x28, x11]
    11fc:      	and	w15, w13, #0x1
    1200:      	fmov	s4, w15
    1204:      	ubfx	w15, w13, #1, #1
    1208:      	mov.b	v4[1], w15
    120c:      	ubfx	w15, w13, #2, #1
    1210:      	mov.b	v4[2], w15
    1214:      	ubfx	w15, w13, #3, #1
    1218:      	mov.b	v4[3], w15
    121c:      	ubfx	w15, w13, #4, #1
    1220:      	mov.b	v4[4], w15
    1224:      	ubfx	w15, w13, #5, #1
    1228:      	mov.b	v4[5], w15
    122c:      	ubfx	w15, w13, #6, #1
    1230:      	mov.b	v4[6], w15
    1234:      	ldr	q6, [sp, #0x610]
    1238:      	str	q6, [sp, #0x430]
    123c:      	ldr	q6, [sp, #0x600]
    1240:      	str	q6, [sp, #0x420]
    1244:      	lsr	w13, w13, #7
    1248:      	mov.b	v4[7], w13
    124c:      	ldrb	w13, [x8, x11]
    1250:      	and	w15, w13, #0x1
    1254:      	fmov	s6, w15
    1258:      	ubfx	w15, w13, #1, #1
    125c:      	mov.b	v6[1], w15
    1260:      	ubfx	w15, w13, #2, #1
    1264:      	mov.b	v6[2], w15
    1268:      	ubfx	w15, w13, #3, #1
    126c:      	mov.b	v6[3], w15
    1270:      	ubfx	w15, w13, #4, #1
    1274:      	mov.b	v6[4], w15
    1278:      	ubfx	w15, w13, #5, #1
    127c:      	mov.b	v6[5], w15
    1280:      	ubfx	w15, w13, #6, #1
    1284:      	mov.b	v6[6], w15
    1288:      	lsr	w13, w13, #7
    128c:      	mov.b	v6[7], w13
    1290:      	csetm	w13, ne
    1294:      	dup.8b	v7, w13
    1298:      	bit.8b	v4, v21, v7
    129c:      	shl.8b	v4, v4, #0x7
    12a0:      	cmlt.8b	v4, v4, #0
    12a4:      	and.8b	v4, v4, v2
    12a8:      	addv.8b	b4, v4
    12ac:      	str	b4, [x28, x11]
    12b0:      	bic.8b	v4, v6, v7
    12b4:      	shl.8b	v4, v4, #0x7
    12b8:      	cmlt.8b	v4, v4, #0
    12bc:      	and.8b	v4, v4, v2
    12c0:      	addv.8b	b4, v4
    12c4:      	str	b4, [x8, x11]
    12c8:      	csinc	w11, w14, w11, eq
    12cc:      	cmp	w24, #0x8
    12d0:      	b.hs	0x5400 <ltmp0+0x5400>
    12d4:      	str	b1, [x23, x21]
    12d8:      	mov	w12, #0x7               ; =7
    12dc:      	str	w12, [x25, x21, lsl #2]
    12e0:      	str	w11, [x26, x21, lsl #2]
    12e4:      	cmp	w9, #0x8
    12e8:      	b.hs	0x5400 <ltmp0+0x5400>
    12ec:      	str	b3, [x23, w9, uxtw]
    12f0:      	orr	w30, w10, w30
    12f4:      	mov	w10, #0x8               ; =8
    12f8:      	b	0x2bc <ltmp0+0x2bc>
    12fc:      	tst	w11, #0xff
    1300:      	b.eq	0x18a0 <ltmp0+0x18a0>
    1304:      	tst	w10, #0xff
    1308:      	b.eq	0x2c8 <ltmp0+0x2c8>
    130c:      	mov	w11, #0x0               ; =0
    1310:      	mov.16b	v1, v24
    1314:      	str	q1, [sp, #0x1e0]
    1318:      	mov.16b	v8, v28
    131c:      	mov.16b	v1, v11
    1320:      	mov.16b	v11, v5
    1324:      	stp	q1, q19, [sp, #0x160]
    1328:      	str	q23, [sp, #0x150]
    132c:      	str	q18, [sp, #0x2d0]
    1330:      	str	q22, [sp, #0xd0]
    1334:      	shl.2d	v1, v22, #0x5
    1338:      	shl.2d	v6, v13, #0x5
    133c:      	shl.2d	v3, v9, #0x5
    1340:      	ldr	q4, [sp, #0x400]
    1344:      	shl.2d	v4, v4, #0x5
    1348:      	ldr	q7, [sp, #0x370]
    134c:      	add.2d	v4, v4, v7
    1350:      	ldr	q7, [sp, #0x380]
    1354:      	add.2d	v3, v3, v7
    1358:      	ldr	q7, [sp, #0x390]
    135c:      	add.2d	v16, v6, v7
    1360:      	ldp	q6, q5, [sp, #0x3a0]
    1364:      	add.2d	v17, v1, v6
    1368:      	ldp	q1, q6, [sp, #0x1a0]
    136c:      	add.2d	v25, v6, v17
    1370:      	add.2d	v23, v1, v16
    1374:      	ldp	q1, q6, [sp, #0x180]
    1378:      	add.2d	v20, v6, v3
    137c:      	add.2d	v6, v1, v4
    1380:      	shl.8b	v1, v21, #0x7
    1384:      	cmlt.8b	v1, v1, #0
    1388:      	and.8b	v1, v1, v2
    138c:      	addv.8b	b1, v1
    1390:      	fmov	d28, d1
    1394:      	fmov	w10, s1
    1398:      	movi.2d	v1, #0000000000000000
    139c:      	movi.2d	v19, #0000000000000000
    13a0:      	str	q8, [sp, #0xe0]
    13a4:      	stp	q29, q27, [sp, #0x2e0]
    13a8:      	stp	q10, q12, [sp, #0x1f0]
    13ac:      	str	q26, [sp, #0x140]
    13b0:      	stp	q9, q31, [sp, #0x1c0]
    13b4:      	stp	q15, q13, [sp, #0xb0]
    13b8:      	str	q14, [sp, #0x300]
    13bc:      	str	q11, [sp, #0x2c0]
    13c0:      	str	q5, [sp, #0x3b0]
    13c4:      	tbnz	w10, #0x0, 0x140c <ltmp0+0x140c>
    13c8:      	tbnz	w10, #0x1, 0x1418 <ltmp0+0x1418>
    13cc:      	ldr	q5, [sp, #0x3f0]
    13d0:      	tbnz	w10, #0x2, 0x1428 <ltmp0+0x1428>
    13d4:      	tbnz	w10, #0x3, 0x1434 <ltmp0+0x1434>
    13d8:      	ldr	q23, [sp, #0x250]
    13dc:      	ldr	q26, [sp, #0x3c0]
    13e0:      	fmov	d18, d0
    13e4:      	tbz	w10, #0x4, 0x144c <ltmp0+0x144c>
    13e8:      	ldr	q8, [sp, #0x410]
    13ec:      	mov.16b	v24, v26
    13f0:      	ldp	q26, q0, [sp, #0x3d0]
    13f4:      	fmov	x13, d20
    13f8:      	ld1.s	{ v19 }[0], [x13]
    13fc:      	str	q5, [sp, #0x3f0]
    1400:      	mov.16b	v5, v23
    1404:      	tbnz	w10, #0x5, 0x1464 <ltmp0+0x1464>
    1408:      	b	0x146c <ltmp0+0x146c>
    140c:      	fmov	x13, d25
    1410:      	ldr	s1, [x13]
    1414:      	tbz	w10, #0x1, 0x13cc <ltmp0+0x13cc>
    1418:      	mov.d	x13, v25[1]
    141c:      	ld1.s	{ v1 }[1], [x13]
    1420:      	ldr	q5, [sp, #0x3f0]
    1424:      	tbz	w10, #0x2, 0x13d4 <ltmp0+0x13d4>
    1428:      	fmov	x13, d23
    142c:      	ld1.s	{ v1 }[2], [x13]
    1430:      	tbz	w10, #0x3, 0x13d8 <ltmp0+0x13d8>
    1434:      	mov.d	x13, v23[1]
    1438:      	ld1.s	{ v1 }[3], [x13]
    143c:      	ldr	q23, [sp, #0x250]
    1440:      	ldr	q26, [sp, #0x3c0]
    1444:      	fmov	d18, d0
    1448:      	tbnz	w10, #0x4, 0x13e8 <ltmp0+0x13e8>
    144c:      	ldr	q8, [sp, #0x410]
    1450:      	mov.16b	v24, v26
    1454:      	ldp	q26, q0, [sp, #0x3d0]
    1458:      	str	q5, [sp, #0x3f0]
    145c:      	mov.16b	v5, v23
    1460:      	tbz	w10, #0x5, 0x146c <ltmp0+0x146c>
    1464:      	mov.d	x13, v20[1]
    1468:      	ld1.s	{ v19 }[1], [x13]
    146c:      	tbnz	w10, #0x6, 0x1744 <ltmp0+0x1744>
    1470:      	tbz	w10, #0x7, 0x147c <ltmp0+0x147c>
    1474:      	mov.d	x10, v6[1]
    1478:      	ld1.s	{ v19 }[3], [x10]
    147c:      	fmul.4s	v6, v19, v19
    1480:      	fmul.4s	v1, v1, v1
    1484:      	ldr	q19, [sp, #0x360]
    1488:      	fadd.4s	v1, v19, v1
    148c:      	str	q1, [sp, #0x250]
    1490:      	ldr	q1, [sp, #0x350]
    1494:      	fadd.4s	v6, v1, v6
    1498:      	ldp	q7, q1, [sp, #0x180]
    149c:      	add.2d	v23, v4, v7
    14a0:      	add.2d	v3, v3, v1
    14a4:      	ldp	q1, q7, [sp, #0x1a0]
    14a8:      	add.2d	v4, v17, v7
    14ac:      	add.2d	v20, v16, v1
    14b0:      	mov	w10, #0x20              ; =32
    14b4:      	dup.2d	v16, x10
    14b8:      	add.2d	v25, v20, v16
    14bc:      	add.2d	v31, v4, v16
    14c0:      	add.2d	v30, v3, v16
    14c4:      	add.2d	v19, v23, v16
    14c8:      	fmov	w10, s28
    14cc:      	movi.2d	v16, #0000000000000000
    14d0:      	movi.2d	v17, #0000000000000000
    14d4:      	tbnz	w10, #0x0, 0x1754 <ltmp0+0x1754>
    14d8:      	tbnz	w10, #0x1, 0x1760 <ltmp0+0x1760>
    14dc:      	tbnz	w10, #0x2, 0x176c <ltmp0+0x176c>
    14e0:      	str	q8, [sp, #0x410]
    14e4:      	tbnz	w10, #0x3, 0x177c <ltmp0+0x177c>
    14e8:      	tbnz	w10, #0x4, 0x1788 <ltmp0+0x1788>
    14ec:      	str	q24, [sp, #0x3c0]
    14f0:      	tbnz	w10, #0x5, 0x1798 <ltmp0+0x1798>
    14f4:      	str	q26, [sp, #0x3d0]
    14f8:      	tbnz	w10, #0x6, 0x17a8 <ltmp0+0x17a8>
    14fc:      	ldr	q15, [sp, #0x340]
    1500:      	fmov	d1, d18
    1504:      	str	q15, [sp, #0x340]
    1508:      	tbz	w10, #0x7, 0x1514 <ltmp0+0x1514>
    150c:      	mov.d	x10, v19[1]
    1510:      	ld1.s	{ v17 }[3], [x10]
    1514:      	fmul.4s	v17, v17, v17
    1518:      	fmul.4s	v16, v16, v16
    151c:      	ldr	q18, [sp, #0x320]
    1520:      	fadd.4s	v19, v18, v16
    1524:      	ldr	q16, [sp, #0x3f0]
    1528:      	fadd.4s	v8, v16, v17
    152c:      	mov	w10, #0x40              ; =64
    1530:      	dup.2d	v16, x10
    1534:      	add.2d	v31, v20, v16
    1538:      	add.2d	v12, v4, v16
    153c:      	add.2d	v25, v3, v16
    1540:      	add.2d	v30, v23, v16
    1544:      	fmov	w10, s28
    1548:      	movi.2d	v16, #0000000000000000
    154c:      	movi.2d	v17, #0000000000000000
    1550:      	tbnz	w10, #0x0, 0x17c4 <ltmp0+0x17c4>
    1554:      	tbnz	w10, #0x1, 0x17d0 <ltmp0+0x17d0>
    1558:      	tbnz	w10, #0x2, 0x17dc <ltmp0+0x17dc>
    155c:      	tbnz	w10, #0x3, 0x17e8 <ltmp0+0x17e8>
    1560:      	tbnz	w10, #0x4, 0x17f4 <ltmp0+0x17f4>
    1564:      	tbnz	w10, #0x5, 0x1800 <ltmp0+0x1800>
    1568:      	tbnz	w10, #0x6, 0x180c <ltmp0+0x180c>
    156c:      	tbz	w10, #0x7, 0x1578 <ltmp0+0x1578>
    1570:      	mov.d	x10, v30[1]
    1574:      	ld1.s	{ v17 }[3], [x10]
    1578:      	fmul.4s	v17, v17, v17
    157c:      	fmul.4s	v16, v16, v16
    1580:      	fadd.4s	v16, v5, v16
    1584:      	ldr	q18, [sp, #0x330]
    1588:      	fadd.4s	v17, v18, v17
    158c:      	mov	w10, #0x60              ; =96
    1590:      	dup.2d	v12, x10
    1594:      	add.2d	v30, v20, v12
    1598:      	add.2d	v31, v4, v12
    159c:      	add.2d	v25, v3, v12
    15a0:      	add.2d	v20, v23, v12
    15a4:      	fmov	w10, s28
    15a8:      	movi.2d	v3, #0000000000000000
    15ac:      	movi.2d	v4, #0000000000000000
    15b0:      	tbnz	w10, #0x0, 0x181c <ltmp0+0x181c>
    15b4:      	mov.16b	v12, v0
    15b8:      	tbnz	w10, #0x1, 0x182c <ltmp0+0x182c>
    15bc:      	ldr	q11, [sp, #0x160]
    15c0:      	fmov	d0, d1
    15c4:      	ldr	q15, [sp, #0xb0]
    15c8:      	tbnz	w10, #0x2, 0x1844 <ltmp0+0x1844>
    15cc:      	ldr	q31, [sp, #0x400]
    15d0:      	ldr	q1, [sp, #0x260]
    15d4:      	tbz	w10, #0x3, 0x15e0 <ltmp0+0x15e0>
    15d8:      	mov.d	x13, v30[1]
    15dc:      	ld1.s	{ v3 }[3], [x13]
    15e0:      	ldr	q18, [sp, #0x270]
    15e4:      	ldr	q13, [sp, #0xc0]
    15e8:      	mov.16b	v23, v5
    15ec:      	ldp	q27, q24, [sp, #0x320]
    15f0:      	ldr	q5, [sp, #0x3f0]
    15f4:      	ldp	q26, q29, [sp, #0x350]
    15f8:      	ldr	q9, [sp, #0x1c0]
    15fc:      	tbnz	w10, #0x4, 0x185c <ltmp0+0x185c>
    1600:      	ldp	q22, q30, [sp, #0x1d0]
    1604:      	ldr	q14, [sp, #0x300]
    1608:      	ldr	q28, [sp, #0x2c0]
    160c:      	str	q31, [sp, #0x400]
    1610:      	tbnz	w10, #0x5, 0x1878 <ltmp0+0x1878>
    1614:      	ldr	q10, [sp, #0xd0]
    1618:      	mov.16b	v31, v22
    161c:      	tbnz	w10, #0x6, 0x188c <ltmp0+0x188c>
    1620:      	mov.16b	v22, v10
    1624:      	tbz	w10, #0x7, 0x1630 <ltmp0+0x1630>
    1628:      	mov.d	x10, v20[1]
    162c:      	ld1.s	{ v4 }[3], [x10]
    1630:      	fmul.4s	v4, v4, v4
    1634:      	fmul.4s	v3, v3, v3
    1638:      	fadd.4s	v3, v1, v3
    163c:      	mov	w10, #0x4               ; =4
    1640:      	dup.2d	v7, x10
    1644:      	mov	b20, v21[6]
    1648:      	mov.b	v20[4], v21[7]
    164c:      	ushll.2d	v20, v20, #0x0
    1650:      	shl.2d	v20, v20, #0x3f
    1654:      	cmlt.2d	v20, v20, #0
    1658:      	and.16b	v20, v20, v7
    165c:      	ldr	q25, [sp, #0x400]
    1660:      	add.2d	v25, v25, v20
    1664:      	str	q25, [sp, #0x400]
    1668:      	mov	b20, v21[4]
    166c:      	mov.b	v20[4], v21[5]
    1670:      	ushll.2d	v20, v20, #0x0
    1674:      	shl.2d	v20, v20, #0x3f
    1678:      	cmlt.2d	v20, v20, #0
    167c:      	and.16b	v20, v20, v7
    1680:      	add.2d	v9, v9, v20
    1684:      	mov	b20, v21[2]
    1688:      	mov.b	v20[4], v21[3]
    168c:      	fadd.4s	v4, v18, v4
    1690:      	ushll.2d	v20, v20, #0x0
    1694:      	shl.2d	v20, v20, #0x3f
    1698:      	cmlt.2d	v20, v20, #0
    169c:      	and.16b	v20, v20, v7
    16a0:      	add.2d	v13, v13, v20
    16a4:      	mov	b20, v21[0]
    16a8:      	mov.b	v20[4], v21[1]
    16ac:      	ushll.2d	v20, v20, #0x0
    16b0:      	shl.2d	v20, v20, #0x3f
    16b4:      	cmlt.2d	v20, v20, #0
    16b8:      	and.16b	v7, v20, v7
    16bc:      	add.2d	v22, v22, v7
    16c0:      	zip1.8b	v7, v21, v0
    16c4:      	ushll.4s	v7, v7, #0x0
    16c8:      	shl.4s	v7, v7, #0x1f
    16cc:      	cmlt.4s	v7, v7, #0
    16d0:      	zip2.8b	v20, v21, v0
    16d4:      	ushll.4s	v20, v20, #0x0
    16d8:      	shl.4s	v20, v20, #0x1f
    16dc:      	cmlt.4s	v20, v20, #0
    16e0:      	bit.16b	v26, v6, v20
    16e4:      	ldr	q6, [sp, #0x250]
    16e8:      	bit.16b	v29, v6, v7
    16ec:      	stp	q26, q29, [sp, #0x350]
    16f0:      	bit.16b	v5, v8, v20
    16f4:      	stp	q12, q5, [sp, #0x3e0]
    16f8:      	bit.16b	v27, v19, v7
    16fc:      	bit.16b	v24, v17, v20
    1700:      	stp	q27, q24, [sp, #0x320]
    1704:      	bit.16b	v23, v16, v7
    1708:      	bit.16b	v18, v4, v20
    170c:      	str	q18, [sp, #0x270]
    1710:      	bit.16b	v1, v3, v7
    1714:      	stp	q23, q1, [sp, #0x250]
    1718:      	tbnz	w11, #0x0, 0x1048 <ltmp0+0x1048>
    171c:      	ldp	q18, q29, [sp, #0x2d0]
    1720:      	ldp	q10, q12, [sp, #0x1f0]
    1724:      	ldr	q27, [sp, #0x2f0]
    1728:      	ldp	q26, q23, [sp, #0x140]
    172c:      	ldr	q3, [sp, #0xe0]
    1730:      	ldr	q19, [sp, #0x170]
    1734:      	mov.16b	v5, v28
    1738:      	mov.16b	v28, v3
    173c:      	mov.16b	v24, v30
    1740:      	b	0x107c <ltmp0+0x107c>
    1744:      	fmov	x13, d6
    1748:      	ld1.s	{ v19 }[2], [x13]
    174c:      	tbnz	w10, #0x7, 0x1474 <ltmp0+0x1474>
    1750:      	b	0x147c <ltmp0+0x147c>
    1754:      	fmov	x13, d31
    1758:      	ldr	s16, [x13]
    175c:      	tbz	w10, #0x1, 0x14dc <ltmp0+0x14dc>
    1760:      	mov.d	x13, v31[1]
    1764:      	ld1.s	{ v16 }[1], [x13]
    1768:      	tbz	w10, #0x2, 0x14e0 <ltmp0+0x14e0>
    176c:      	fmov	x13, d25
    1770:      	ld1.s	{ v16 }[2], [x13]
    1774:      	str	q8, [sp, #0x410]
    1778:      	tbz	w10, #0x3, 0x14e8 <ltmp0+0x14e8>
    177c:      	mov.d	x13, v25[1]
    1780:      	ld1.s	{ v16 }[3], [x13]
    1784:      	tbz	w10, #0x4, 0x14ec <ltmp0+0x14ec>
    1788:      	fmov	x13, d30
    178c:      	ld1.s	{ v17 }[0], [x13]
    1790:      	str	q24, [sp, #0x3c0]
    1794:      	tbz	w10, #0x5, 0x14f4 <ltmp0+0x14f4>
    1798:      	mov.d	x13, v30[1]
    179c:      	ld1.s	{ v17 }[1], [x13]
    17a0:      	str	q26, [sp, #0x3d0]
    17a4:      	tbz	w10, #0x6, 0x14fc <ltmp0+0x14fc>
    17a8:      	fmov	x13, d19
    17ac:      	ld1.s	{ v17 }[2], [x13]
    17b0:      	ldr	q15, [sp, #0x340]
    17b4:      	fmov	d1, d18
    17b8:      	str	q15, [sp, #0x340]
    17bc:      	tbnz	w10, #0x7, 0x150c <ltmp0+0x150c>
    17c0:      	b	0x1514 <ltmp0+0x1514>
    17c4:      	fmov	x13, d12
    17c8:      	ldr	s16, [x13]
    17cc:      	tbz	w10, #0x1, 0x1558 <ltmp0+0x1558>
    17d0:      	mov.d	x13, v12[1]
    17d4:      	ld1.s	{ v16 }[1], [x13]
    17d8:      	tbz	w10, #0x2, 0x155c <ltmp0+0x155c>
    17dc:      	fmov	x13, d31
    17e0:      	ld1.s	{ v16 }[2], [x13]
    17e4:      	tbz	w10, #0x3, 0x1560 <ltmp0+0x1560>
    17e8:      	mov.d	x13, v31[1]
    17ec:      	ld1.s	{ v16 }[3], [x13]
    17f0:      	tbz	w10, #0x4, 0x1564 <ltmp0+0x1564>
    17f4:      	fmov	x13, d25
    17f8:      	ld1.s	{ v17 }[0], [x13]
    17fc:      	tbz	w10, #0x5, 0x1568 <ltmp0+0x1568>
    1800:      	mov.d	x13, v25[1]
    1804:      	ld1.s	{ v17 }[1], [x13]
    1808:      	tbz	w10, #0x6, 0x156c <ltmp0+0x156c>
    180c:      	fmov	x13, d30
    1810:      	ld1.s	{ v17 }[2], [x13]
    1814:      	tbnz	w10, #0x7, 0x1570 <ltmp0+0x1570>
    1818:      	b	0x1578 <ltmp0+0x1578>
    181c:      	fmov	x13, d31
    1820:      	ldr	s3, [x13]
    1824:      	mov.16b	v12, v0
    1828:      	tbz	w10, #0x1, 0x15bc <ltmp0+0x15bc>
    182c:      	mov.d	x13, v31[1]
    1830:      	ld1.s	{ v3 }[1], [x13]
    1834:      	ldr	q11, [sp, #0x160]
    1838:      	fmov	d0, d1
    183c:      	ldr	q15, [sp, #0xb0]
    1840:      	tbz	w10, #0x2, 0x15cc <ltmp0+0x15cc>
    1844:      	fmov	x13, d30
    1848:      	ld1.s	{ v3 }[2], [x13]
    184c:      	ldr	q31, [sp, #0x400]
    1850:      	ldr	q1, [sp, #0x260]
    1854:      	tbnz	w10, #0x3, 0x15d8 <ltmp0+0x15d8>
    1858:      	b	0x15e0 <ltmp0+0x15e0>
    185c:      	fmov	x13, d25
    1860:      	ld1.s	{ v4 }[0], [x13]
    1864:      	ldp	q22, q30, [sp, #0x1d0]
    1868:      	ldr	q14, [sp, #0x300]
    186c:      	ldr	q28, [sp, #0x2c0]
    1870:      	str	q31, [sp, #0x400]
    1874:      	tbz	w10, #0x5, 0x1614 <ltmp0+0x1614>
    1878:      	mov.d	x13, v25[1]
    187c:      	ld1.s	{ v4 }[1], [x13]
    1880:      	ldr	q10, [sp, #0xd0]
    1884:      	mov.16b	v31, v22
    1888:      	tbz	w10, #0x6, 0x1620 <ltmp0+0x1620>
    188c:      	fmov	x13, d20
    1890:      	ld1.s	{ v4 }[2], [x13]
    1894:      	mov.16b	v22, v10
    1898:      	tbnz	w10, #0x7, 0x1628 <ltmp0+0x1628>
    189c:      	b	0x1630 <ltmp0+0x1630>
    18a0:      	tst	w10, #0xff
    18a4:      	b.eq	0x2c8 <ltmp0+0x2c8>
    18a8:      	cbz	w14, 0x1a7c <ltmp0+0x1a7c>
    18ac:      	mov	w11, #0x0               ; =0
    18b0:      	shl.8b	v1, v21, #0x7
    18b4:      	cmlt.8b	v1, v1, #0
    18b8:      	and.8b	v3, v1, v2
    18bc:      	addv.8b	b3, v3
    18c0:      	fmov	w10, s3
    18c4:      	umaxv.8b	b1, v1
    18c8:      	fmov	w2, s1
    18cc:      	sub	w13, w14, #0x1
    18d0:      	tst	w10, #0xff
    18d4:      	csel	w13, w13, wzr, ne
    18d8:      	lsl	w15, w16, w13
    18dc:      	and	w10, w15, w30
    18e0:      	tst	w10, #0xff
    18e4:      	cset	w3, ne
    18e8:      	ldr	q1, [sp, #0x440]
    18ec:      	str	q1, [sp, #0x10e0]
    18f0:      	ldr	q1, [sp, #0x450]
    18f4:      	str	q1, [sp, #0x10f0]
    18f8:      	ubfiz	x10, x13, #2, #3
    18fc:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
    1900:      	add	x12, x12, #0xe0
    1904:      	ldr	w0, [x12, x10]
    1908:      	cmp	w0, #0x1
    190c:      	cset	w0, eq
    1910:      	and	w2, w3, w2
    1914:      	ldrb	w3, [x28, w13, sxtw]
    1918:      	and	w5, w3, #0x1
    191c:      	fmov	s1, w5
    1920:      	ubfx	w5, w3, #1, #1
    1924:      	mov.b	v1[1], w5
    1928:      	ubfx	w5, w3, #2, #1
    192c:      	mov.b	v1[2], w5
    1930:      	ubfx	w5, w3, #3, #1
    1934:      	mov.b	v1[3], w5
    1938:      	ubfx	w5, w3, #4, #1
    193c:      	mov.b	v1[4], w5
    1940:      	ubfx	w5, w3, #5, #1
    1944:      	mov.b	v1[5], w5
    1948:      	ubfx	w5, w3, #6, #1
    194c:      	mov.b	v1[6], w5
    1950:      	lsr	w3, w3, #7
    1954:      	mov.b	v1[7], w3
    1958:      	ldrb	w3, [x8, w13, sxtw]
    195c:      	and	w5, w3, #0x1
    1960:      	fmov	s3, w5
    1964:      	ubfx	w5, w3, #1, #1
    1968:      	mov.b	v3[1], w5
    196c:      	ubfx	w5, w3, #2, #1
    1970:      	mov.b	v3[2], w5
    1974:      	ubfx	w5, w3, #3, #1
    1978:      	mov.b	v3[3], w5
    197c:      	ubfx	w5, w3, #4, #1
    1980:      	mov.b	v3[4], w5
    1984:      	ubfx	w5, w3, #5, #1
    1988:      	mov.b	v3[5], w5
    198c:      	ubfx	w5, w3, #6, #1
    1990:      	mov.b	v3[6], w5
    1994:      	lsr	w3, w3, #7
    1998:      	mov.b	v3[7], w3
    199c:      	orr.8b	v4, v21, v3
    19a0:      	and.8b	v6, v0, v1
    19a4:      	eor.8b	v6, v6, v4
    19a8:      	shl.8b	v6, v6, #0x7
    19ac:      	cmlt.8b	v6, v6, #0
    19b0:      	umaxv.8b	b6, v6
    19b4:      	fmov	w3, s6
    19b8:      	ands	w0, w2, w0
    19bc:      	csetm	w2, ne
    19c0:      	bics	w3, w0, w3
    19c4:      	csetm	w5, ne
    19c8:      	dup.8b	v6, w5
    19cc:      	dup.8b	v7, w2
    19d0:      	bic.8b	v16, v4, v6
    19d4:      	bit.8b	v3, v16, v7
    19d8:      	shl.8b	v3, v3, #0x7
    19dc:      	cmlt.8b	v3, v3, #0
    19e0:      	and.8b	v3, v3, v2
    19e4:      	addv.8b	b3, v3
    19e8:      	str	b3, [x8, w13, sxtw]
    19ec:      	bic.8b	v1, v1, v6
    19f0:      	shl.8b	v1, v1, #0x7
    19f4:      	cmlt.8b	v1, v1, #0
    19f8:      	and.8b	v1, v1, v2
    19fc:      	addv.8b	b1, v1
    1a00:      	str	b1, [x28, w13, sxtw]
    1a04:      	csinv	w13, w4, w15, eq
    1a08:      	dup.8b	v1, w0
    1a0c:      	and	w30, w13, w30
    1a10:      	shl.8b	v1, v1, #0x7
    1a14:      	cmlt.8b	v1, v1, #0
    1a18:      	dup.8b	v3, w3
    1a1c:      	and.8b	v3, v3, v4
    1a20:      	ldr	q4, [sp, #0x420]
    1a24:      	str	q4, [sp, #0x10c0]
    1a28:      	ldr	q4, [sp, #0x430]
    1a2c:      	str	q4, [sp, #0x10d0]
    1a30:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
    1a34:      	add	x12, x12, #0xc0
    1a38:      	ldr	w10, [x12, x10]
    1a3c:      	csel	w14, w10, w14, ne
    1a40:      	bit.8b	v21, v3, v1
    1a44:      	shl.8b	v1, v21, #0x7
    1a48:      	cmlt.8b	v1, v1, #0
    1a4c:      	and.8b	v1, v1, v2
    1a50:      	addv.8b	b1, v1
    1a54:      	fmov	w10, s1
    1a58:      	cmp	w0, #0x1
    1a5c:      	b.ne	0x1a90 <ltmp0+0x1a90>
    1a60:      	cmp	w14, #0x0
    1a64:      	ccmp	w11, #0x6, #0x2, ne
    1a68:      	b.hi	0x1a90 <ltmp0+0x1a90>
    1a6c:      	add	w11, w11, #0x1
    1a70:      	tst	w10, #0xff
    1a74:      	b.ne	0x18b0 <ltmp0+0x18b0>
    1a78:      	b	0x1a90 <ltmp0+0x1a90>
    1a7c:      	shl.8b	v1, v21, #0x7
    1a80:      	cmlt.8b	v1, v1, #0
    1a84:      	and.8b	v1, v1, v2
    1a88:      	addv.8b	b1, v1
    1a8c:      	fmov	w10, s1
    1a90:      	tst	w10, #0xff
    1a94:      	b.eq	0x1070 <ltmp0+0x1070>
    1a98:      	and.8b	v1, v11, v21
    1a9c:      	shl.8b	v1, v1, #0x7
    1aa0:      	cmlt.8b	v1, v1, #0
    1aa4:      	and.8b	v3, v1, v2
    1aa8:      	addv.8b	b4, v3
    1aac:      	umaxv.8b	b1, v1
    1ab0:      	fmov	w11, s1
    1ab4:      	mov	w5, #0xc0               ; =192
    1ab8:      	add	x3, sp, #0xdd0
    1abc:      	tbz	w11, #0x0, 0x1d08 <ltmp0+0x1d08>
    1ac0:      	bic.8b	v3, v21, v11
    1ac4:      	shl.8b	v1, v3, #0x7
    1ac8:      	cmlt.8b	v1, v1, #0
    1acc:      	and.8b	v1, v1, v2
    1ad0:      	addv.8b	b1, v1
    1ad4:      	fmov	w11, s1
    1ad8:      	tst	w11, #0xff
    1adc:      	b.eq	0x1d08 <ltmp0+0x1d08>
    1ae0:      	subs	w10, w14, #0x1
    1ae4:      	csel	w10, wzr, w10, lo
    1ae8:      	and	w11, w30, #0xff
    1aec:      	lsr	w13, w11, w10
    1af0:      	tst	w13, #0x1
    1af4:      	ldr	q6, [sp, #0x440]
    1af8:      	str	q6, [sp, #0x720]
    1afc:      	ldr	q6, [sp, #0x450]
    1b00:      	str	q6, [sp, #0x730]
    1b04:      	and	x10, x10, #0x7
    1b08:      	add	x12, sp, #0x720
    1b0c:      	ldr	w10, [x12, x10, lsl #2]
    1b10:      	ccmp	w14, #0x0, #0x4, ne
    1b14:      	ccmp	w10, #0x2, #0x0, ne
    1b18:      	cset	w10, ne
    1b1c:      	cmp	w11, #0xff
    1b20:      	b.ne	0x1b28 <ltmp0+0x1b28>
    1b24:      	tbnz	w10, #0x0, 0x5400 <ltmp0+0x5400>
    1b28:      	mvn	w11, w30
    1b2c:      	rbit	w11, w11
    1b30:      	clz	w11, w11
    1b34:      	mov	w12, #0xff              ; =255
    1b38:      	bics	wzr, w12, w30
    1b3c:      	csel	w11, wzr, w11, eq
    1b40:      	ubfiz	x13, x11, #2, #3
    1b44:      	lsl	w15, w16, w11
    1b48:      	ldr	q7, [sp, #0x440]
    1b4c:      	str	q7, [sp, #0x700]
    1b50:      	ldr	q6, [sp, #0x450]
    1b54:      	str	q6, [sp, #0x710]
    1b58:      	add	x12, sp, #0x700
    1b5c:      	ldr	w0, [x12, x13]
    1b60:      	cmp	w10, #0x0
    1b64:      	csel	w10, w15, wzr, ne
    1b68:      	mov	w12, #0x2               ; =2
    1b6c:      	csel	w15, w12, w0, ne
    1b70:      	str	q7, [sp, #0x6e0]
    1b74:      	str	q6, [sp, #0x6f0]
    1b78:      	add	x12, sp, #0x6e0
    1b7c:      	str	w15, [x12, x13]
    1b80:      	ldr	q6, [sp, #0x6f0]
    1b84:      	str	q6, [sp, #0x450]
    1b88:      	ldr	q6, [sp, #0x6e0]
    1b8c:      	str	q6, [sp, #0x440]
    1b90:      	ldr	q7, [sp, #0x420]
    1b94:      	str	q7, [sp, #0x6c0]
    1b98:      	ldr	q6, [sp, #0x430]
    1b9c:      	str	q6, [sp, #0x6d0]
    1ba0:      	add	x12, sp, #0x6c0
    1ba4:      	ldr	w15, [x12, x13]
    1ba8:      	csel	w15, w14, w15, ne
    1bac:      	str	q7, [sp, #0x6a0]
    1bb0:      	str	q6, [sp, #0x6b0]
    1bb4:      	add	x12, sp, #0x6a0
    1bb8:      	str	w15, [x12, x13]
    1bbc:      	ldrb	w13, [x28, x11]
    1bc0:      	and	w15, w13, #0x1
    1bc4:      	fmov	s6, w15
    1bc8:      	ubfx	w15, w13, #1, #1
    1bcc:      	mov.b	v6[1], w15
    1bd0:      	ubfx	w15, w13, #2, #1
    1bd4:      	mov.b	v6[2], w15
    1bd8:      	ubfx	w15, w13, #3, #1
    1bdc:      	mov.b	v6[3], w15
    1be0:      	ubfx	w15, w13, #4, #1
    1be4:      	mov.b	v6[4], w15
    1be8:      	ubfx	w15, w13, #5, #1
    1bec:      	mov.b	v6[5], w15
    1bf0:      	ubfx	w15, w13, #6, #1
    1bf4:      	mov.b	v6[6], w15
    1bf8:      	ldr	q7, [sp, #0x6b0]
    1bfc:      	str	q7, [sp, #0x430]
    1c00:      	ldr	q7, [sp, #0x6a0]
    1c04:      	str	q7, [sp, #0x420]
    1c08:      	lsr	w13, w13, #7
    1c0c:      	mov.b	v6[7], w13
    1c10:      	ldrb	w13, [x8, x11]
    1c14:      	and	w15, w13, #0x1
    1c18:      	fmov	s7, w15
    1c1c:      	ubfx	w15, w13, #1, #1
    1c20:      	mov.b	v7[1], w15
    1c24:      	ubfx	w15, w13, #2, #1
    1c28:      	mov.b	v7[2], w15
    1c2c:      	ubfx	w15, w13, #3, #1
    1c30:      	mov.b	v7[3], w15
    1c34:      	ubfx	w15, w13, #4, #1
    1c38:      	mov.b	v7[4], w15
    1c3c:      	ubfx	w15, w13, #5, #1
    1c40:      	mov.b	v7[5], w15
    1c44:      	ubfx	w15, w13, #6, #1
    1c48:      	mov.b	v7[6], w15
    1c4c:      	lsr	w13, w13, #7
    1c50:      	mov.b	v7[7], w13
    1c54:      	csetm	w13, ne
    1c58:      	dup.8b	v16, w13
    1c5c:      	bit.8b	v6, v21, v16
    1c60:      	shl.8b	v6, v6, #0x7
    1c64:      	cmlt.8b	v6, v6, #0
    1c68:      	and.8b	v6, v6, v2
    1c6c:      	addv.8b	b6, v6
    1c70:      	str	b6, [x28, x11]
    1c74:      	bic.8b	v6, v7, v16
    1c78:      	shl.8b	v6, v6, #0x7
    1c7c:      	cmlt.8b	v6, v6, #0
    1c80:      	and.8b	v6, v6, v2
    1c84:      	addv.8b	b6, v6
    1c88:      	str	b6, [x8, x11]
    1c8c:      	csinc	w11, w14, w11, eq
    1c90:      	cmp	w24, #0x8
    1c94:      	b.hs	0x5400 <ltmp0+0x5400>
    1c98:      	str	b4, [x23, x21]
    1c9c:      	mov	w12, #0x9               ; =9
    1ca0:      	str	w12, [x25, x21, lsl #2]
    1ca4:      	str	w11, [x26, x21, lsl #2]
    1ca8:      	cmp	w9, #0x8
    1cac:      	b.hs	0x5400 <ltmp0+0x5400>
    1cb0:      	orr	w30, w10, w30
    1cb4:      	zip2.8b	v4, v3, v0
    1cb8:      	ushll.4s	v4, v4, #0x0
    1cbc:      	shl.4s	v4, v4, #0x1f
    1cc0:      	cmlt.4s	v4, v4, #0
    1cc4:      	ldr	q6, [sp, #0x120]
    1cc8:      	ldr	q7, [sp, #0x350]
    1ccc:      	bit.16b	v6, v7, v4
    1cd0:      	zip1.8b	v3, v3, v0
    1cd4:      	ushll.4s	v3, v3, #0x0
    1cd8:      	shl.4s	v3, v3, #0x1f
    1cdc:      	cmlt.4s	v3, v3, #0
    1ce0:      	str	b1, [x23, w9, uxtw]
    1ce4:      	ldr	q1, [sp, #0x110]
    1ce8:      	ldr	q4, [sp, #0x360]
    1cec:      	bit.16b	v1, v4, v3
    1cf0:      	stp	q1, q6, [sp, #0x110]
    1cf4:      	mov	w10, #0xa               ; =10
    1cf8:      	str	w10, [x25, w9, uxtw #2]
    1cfc:      	str	w11, [x26, w9, uxtw #2]
    1d00:      	add	w24, w9, #0x1
    1d04:      	b	0x2c8 <ltmp0+0x2c8>
    1d08:      	fmov	w11, s4
    1d0c:      	tst	w11, #0xff
    1d10:      	b.eq	0x1f94 <ltmp0+0x1f94>
    1d14:      	rbit	w11, w10
    1d18:      	clz	w11, w11
    1d1c:      	tst	w10, #0xff
    1d20:      	csel	w11, wzr, w11, eq
    1d24:      	ldp	q1, q3, [sp, #0x390]
    1d28:      	str	q3, [sp, #0x1080]
    1d2c:      	str	q1, [sp, #0x1090]
    1d30:      	ldp	q1, q3, [sp, #0x370]
    1d34:      	str	q3, [sp, #0x10a0]
    1d38:      	str	q1, [sp, #0x10b0]
    1d3c:      	and	x13, x11, #0x7
    1d40:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
    1d44:      	add	x12, x12, #0x80
    1d48:      	ldr	x13, [x12, x13, lsl #3]
    1d4c:      	lsl	w11, w11, #2
    1d50:      	ands	w10, w10, #0xff
    1d54:      	sub	x11, x13, x11
    1d58:      	mov	w12, #0x1800            ; =6144
    1d5c:      	add	x11, x11, x12
    1d60:      	csel	x11, xzr, x11, eq
    1d64:      	add	x11, x20, x11
    1d68:      	ldp	q3, q1, [x11]
    1d6c:      	zip1.8b	v4, v21, v0
    1d70:      	ushll.4s	v4, v4, #0x0
    1d74:      	shl.4s	v4, v4, #0x1f
    1d78:      	cmlt.4s	v4, v4, #0
    1d7c:      	and.16b	v3, v4, v3
    1d80:      	zip2.8b	v6, v21, v0
    1d84:      	ushll.4s	v6, v6, #0x0
    1d88:      	shl.4s	v6, v6, #0x1f
    1d8c:      	cmlt.4s	v6, v6, #0
    1d90:      	and.16b	v1, v6, v1
    1d94:      	fmul.4s	v1, v1, v1
    1d98:      	fmul.4s	v3, v3, v3
    1d9c:      	ldr	q7, [sp, #0x360]
    1da0:      	fadd.4s	v3, v7, v3
    1da4:      	ldr	q7, [sp, #0x350]
    1da8:      	fadd.4s	v1, v7, v1
    1dac:      	ldr	q7, [sp, #0x120]
    1db0:      	bit.16b	v7, v1, v6
    1db4:      	ldr	q1, [sp, #0x110]
    1db8:      	bit.16b	v1, v3, v4
    1dbc:      	stp	q1, q7, [sp, #0x110]
    1dc0:      	cbz	w10, 0x2c8 <ltmp0+0x2c8>
    1dc4:      	str	x21, [sp, #0xa8]
    1dc8:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
    1dcc:      	add	x12, x12, #0x40
    1dd0:      	cbz	w14, 0x1fe0 <ltmp0+0x1fe0>
    1dd4:      	mov	w10, #0x0               ; =0
    1dd8:      	shl.8b	v1, v21, #0x7
    1ddc:      	cmlt.8b	v1, v1, #0
    1de0:      	and.8b	v3, v1, v2
    1de4:      	addv.8b	b3, v3
    1de8:      	fmov	w11, s3
    1dec:      	umaxv.8b	b1, v1
    1df0:      	fmov	w2, s1
    1df4:      	sub	w13, w14, #0x1
    1df8:      	tst	w11, #0xff
    1dfc:      	csel	w13, w13, wzr, ne
    1e00:      	lsl	w15, w16, w13
    1e04:      	and	w11, w15, w30
    1e08:      	tst	w11, #0xff
    1e0c:      	cset	w3, ne
    1e10:      	ldr	q1, [sp, #0x440]
    1e14:      	str	q1, [sp, #0x1060]
    1e18:      	ldr	q1, [sp, #0x450]
    1e1c:      	str	q1, [sp, #0x1070]
    1e20:      	ubfiz	x11, x13, #2, #3
    1e24:      	ldr	w0, [x22, x11]
    1e28:      	cmp	w0, #0x2
    1e2c:      	cset	w0, eq
    1e30:      	and	w2, w3, w2
    1e34:      	ldrb	w3, [x28, w13, sxtw]
    1e38:      	and	w5, w3, #0x1
    1e3c:      	fmov	s1, w5
    1e40:      	ubfx	w5, w3, #1, #1
    1e44:      	mov.b	v1[1], w5
    1e48:      	ubfx	w5, w3, #2, #1
    1e4c:      	mov.b	v1[2], w5
    1e50:      	ubfx	w5, w3, #3, #1
    1e54:      	mov.b	v1[3], w5
    1e58:      	ubfx	w5, w3, #4, #1
    1e5c:      	mov.b	v1[4], w5
    1e60:      	ubfx	w5, w3, #5, #1
    1e64:      	mov.b	v1[5], w5
    1e68:      	ubfx	w5, w3, #6, #1
    1e6c:      	mov.b	v1[6], w5
    1e70:      	lsr	w3, w3, #7
    1e74:      	mov.b	v1[7], w3
    1e78:      	ldrb	w3, [x8, w13, sxtw]
    1e7c:      	and	w5, w3, #0x1
    1e80:      	fmov	s3, w5
    1e84:      	ubfx	w5, w3, #1, #1
    1e88:      	mov.b	v3[1], w5
    1e8c:      	ubfx	w5, w3, #2, #1
    1e90:      	mov.b	v3[2], w5
    1e94:      	ubfx	w5, w3, #3, #1
    1e98:      	mov.b	v3[3], w5
    1e9c:      	ubfx	w5, w3, #4, #1
    1ea0:      	mov.b	v3[4], w5
    1ea4:      	ubfx	w5, w3, #5, #1
    1ea8:      	mov.b	v3[5], w5
    1eac:      	ubfx	w5, w3, #6, #1
    1eb0:      	mov.b	v3[6], w5
    1eb4:      	lsr	w3, w3, #7
    1eb8:      	mov.b	v3[7], w3
    1ebc:      	orr.8b	v4, v21, v3
    1ec0:      	and.8b	v6, v0, v1
    1ec4:      	eor.8b	v6, v6, v4
    1ec8:      	shl.8b	v6, v6, #0x7
    1ecc:      	cmlt.8b	v6, v6, #0
    1ed0:      	umaxv.8b	b6, v6
    1ed4:      	fmov	w3, s6
    1ed8:      	ands	w0, w2, w0
    1edc:      	csetm	w2, ne
    1ee0:      	bics	w3, w0, w3
    1ee4:      	csetm	w5, ne
    1ee8:      	dup.8b	v6, w5
    1eec:      	dup.8b	v7, w2
    1ef0:      	bic.8b	v16, v4, v6
    1ef4:      	bit.8b	v3, v16, v7
    1ef8:      	shl.8b	v3, v3, #0x7
    1efc:      	cmlt.8b	v3, v3, #0
    1f00:      	and.8b	v3, v3, v2
    1f04:      	addv.8b	b3, v3
    1f08:      	str	b3, [x8, w13, sxtw]
    1f0c:      	bic.8b	v1, v1, v6
    1f10:      	shl.8b	v1, v1, #0x7
    1f14:      	cmlt.8b	v1, v1, #0
    1f18:      	and.8b	v1, v1, v2
    1f1c:      	addv.8b	b1, v1
    1f20:      	str	b1, [x28, w13, sxtw]
    1f24:      	csinv	w13, w4, w15, eq
    1f28:      	dup.8b	v1, w0
    1f2c:      	and	w30, w13, w30
    1f30:      	shl.8b	v1, v1, #0x7
    1f34:      	cmlt.8b	v1, v1, #0
    1f38:      	dup.8b	v3, w3
    1f3c:      	and.8b	v3, v3, v4
    1f40:      	ldr	q4, [sp, #0x420]
    1f44:      	str	q4, [sp, #0x1040]
    1f48:      	ldr	q4, [sp, #0x430]
    1f4c:      	str	q4, [sp, #0x1050]
    1f50:      	ldr	w11, [x12, x11]
    1f54:      	csel	w14, w11, w14, ne
    1f58:      	bit.8b	v21, v3, v1
    1f5c:      	shl.8b	v1, v21, #0x7
    1f60:      	cmlt.8b	v1, v1, #0
    1f64:      	and.8b	v1, v1, v2
    1f68:      	addv.8b	b1, v1
    1f6c:      	fmov	w11, s1
    1f70:      	cmp	w0, #0x1
    1f74:      	b.ne	0x1ff4 <ltmp0+0x1ff4>
    1f78:      	cmp	w14, #0x0
    1f7c:      	ccmp	w10, #0x6, #0x2, ne
    1f80:      	b.hi	0x1ff4 <ltmp0+0x1ff4>
    1f84:      	add	w10, w10, #0x1
    1f88:      	tst	w11, #0xff
    1f8c:      	b.ne	0x1dd8 <ltmp0+0x1dd8>
    1f90:      	b	0x1ff4 <ltmp0+0x1ff4>
    1f94:      	zip2.8b	v1, v21, v0
    1f98:      	ushll.4s	v1, v1, #0x0
    1f9c:      	shl.4s	v1, v1, #0x1f
    1fa0:      	cmlt.4s	v1, v1, #0
    1fa4:      	ldr	q3, [sp, #0x120]
    1fa8:      	ldp	q6, q4, [sp, #0x350]
    1fac:      	bit.16b	v3, v6, v1
    1fb0:      	str	q3, [sp, #0x120]
    1fb4:      	zip1.8b	v1, v21, v0
    1fb8:      	ushll.4s	v1, v1, #0x0
    1fbc:      	shl.4s	v1, v1, #0x1f
    1fc0:      	cmlt.4s	v1, v1, #0
    1fc4:      	ldr	q3, [sp, #0x110]
    1fc8:      	bit.16b	v3, v4, v1
    1fcc:      	str	q3, [sp, #0x110]
    1fd0:      	str	x21, [sp, #0xa8]
    1fd4:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
    1fd8:      	add	x12, x12, #0x40
    1fdc:      	cbnz	w14, 0x1dd4 <ltmp0+0x1dd4>
    1fe0:      	shl.8b	v1, v21, #0x7
    1fe4:      	cmlt.8b	v1, v1, #0
    1fe8:      	and.8b	v1, v1, v2
    1fec:      	addv.8b	b1, v1
    1ff0:      	fmov	w11, s1
    1ff4:      	tst	w11, #0xff
    1ff8:      	b.eq	0x2730 <ltmp0+0x2730>
    1ffc:      	ldr	q1, [sp, #0x120]
    2000:      	ldr	q3, [sp, #0x3f0]
    2004:      	fadd.4s	v1, v3, v1
    2008:      	ldr	q3, [sp, #0x110]
    200c:      	ldr	q4, [sp, #0x320]
    2010:      	fadd.4s	v3, v4, v3
    2014:      	ldr	q4, [sp, #0x250]
    2018:      	fadd.4s	v3, v4, v3
    201c:      	ldr	q4, [sp, #0x330]
    2020:      	fadd.4s	v1, v4, v1
    2024:      	ldr	q4, [sp, #0x270]
    2028:      	fadd.4s	v6, v4, v1
    202c:      	ldr	q1, [sp, #0x260]
    2030:      	fadd.4s	v7, v1, v3
    2034:      	uzp1.4s	v25, v24, v14
    2038:      	uzp1.4s	v8, v31, v5
    203c:      	movi.4s	v4, #0x1
    2040:      	eor.16b	v3, v25, v4
    2044:      	mov.s	w10, v3[1]
    2048:      	eor.16b	v4, v8, v4
    204c:      	mov.s	w13, v3[2]
    2050:      	mov.s	w15, v3[3]
    2054:      	fmov	w0, s3
    2058:      	cmp	w0, #0x8
    205c:      	csel	w0, w0, wzr, lo
    2060:      	cset	w2, lo
    2064:      	and	x3, x0, #0x7
    2068:      	add	x5, sp, #0xdf8
    206c:      	bfxil	x5, x0, #0, #3
    2070:      	str	d21, [sp, #0xdf8]
    2074:      	ldrb	w0, [x5]
    2078:      	umov.b	w23, v21[0]
    207c:      	and	w0, w2, w0
    2080:      	str	q7, [sp, #0xfa0]
    2084:      	str	q6, [sp, #0xfb0]
    2088:      	add	x12, sp, #0xfa0
    208c:      	ldr	s3, [x12, x3, lsl #2]
    2090:      	ands	w7, w23, #0x1
    2094:      	tst	w7, w0
    2098:      	str	q18, [sp, #0x2d0]
    209c:      	str	q23, [sp, #0x150]
    20a0:      	movi	d23, #0000000000000000
    20a4:      	fcsel	s3, s3, s23, ne
    20a8:      	cmp	w10, #0x8
    20ac:      	csel	w10, w10, wzr, lo
    20b0:      	cset	w0, lo
    20b4:      	and	x2, x10, #0x7
    20b8:      	add	x3, sp, #0xdf8
    20bc:      	bfxil	x3, x10, #0, #3
    20c0:      	ldrb	w3, [x3]
    20c4:      	umov.b	w10, v21[1]
    20c8:      	and	w0, w0, w3
    20cc:      	str	q7, [sp, #0xf80]
    20d0:      	str	q6, [sp, #0xf90]
    20d4:      	add	x12, sp, #0xf80
    20d8:      	ldr	s16, [x12, x2, lsl #2]
    20dc:      	ands	w26, w10, #0x1
    20e0:      	tst	w26, w0
    20e4:      	fcsel	s17, s16, s23, ne
    20e8:      	cmp	w13, #0x8
    20ec:      	csel	w13, w13, wzr, lo
    20f0:      	cset	w0, lo
    20f4:      	and	x2, x13, #0x7
    20f8:      	add	x3, sp, #0xdf8
    20fc:      	bfxil	x3, x13, #0, #3
    2100:      	ldrb	w13, [x3]
    2104:      	umov.b	w19, v21[2]
    2108:      	str	q7, [sp, #0xf60]
    210c:      	str	q6, [sp, #0xf70]
    2110:      	add	x12, sp, #0xf60
    2114:      	ldr	s16, [x12, x2, lsl #2]
    2118:      	and	w13, w0, w13
    211c:      	ands	w20, w19, #0x1
    2120:      	tst	w20, w13
    2124:      	fcsel	s16, s16, s23, ne
    2128:      	cmp	w15, #0x8
    212c:      	csel	w13, w15, wzr, lo
    2130:      	cset	w2, lo
    2134:      	and	x5, x13, #0x7
    2138:      	add	x15, sp, #0xdf8
    213c:      	bfxil	x15, x13, #0, #3
    2140:      	umov.b	w3, v21[3]
    2144:      	ldrb	w6, [x15]
    2148:      	mov.s	w15, v4[1]
    214c:      	mov.s	w13, v4[2]
    2150:      	str	q7, [sp, #0xf40]
    2154:      	str	q6, [sp, #0xf50]
    2158:      	mov.s	w0, v4[3]
    215c:      	fmov	w21, s4
    2160:      	add	x12, sp, #0xf40
    2164:      	ldr	s4, [x12, x5, lsl #2]
    2168:      	and	w2, w2, w6
    216c:      	ands	w5, w3, #0x1
    2170:      	tst	w5, w2
    2174:      	fcsel	s20, s4, s23, ne
    2178:      	cmp	w21, #0x8
    217c:      	csel	w2, w21, wzr, lo
    2180:      	cset	w6, lo
    2184:      	and	x21, x2, #0x7
    2188:      	add	x27, sp, #0xdf8
    218c:      	bfxil	x27, x2, #0, #3
    2190:      	umov.b	w25, v21[4]
    2194:      	ldrb	w2, [x27]
    2198:      	and	w6, w6, w2
    219c:      	str	q7, [sp, #0x1020]
    21a0:      	str	q6, [sp, #0x1030]
    21a4:      	mov.s	v3[1], v17[0]
    21a8:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
    21ac:      	add	x12, x12, #0x20
    21b0:      	ldr	s4, [x12, x21, lsl #2]
    21b4:      	ands	w2, w25, #0x1
    21b8:      	tst	w2, w6
    21bc:      	fcsel	s4, s4, s23, ne
    21c0:      	cmp	w15, #0x8
    21c4:      	csel	w15, w15, wzr, lo
    21c8:      	cset	w6, lo
    21cc:      	and	x27, x15, #0x7
    21d0:      	add	x21, sp, #0xdf8
    21d4:      	bfxil	x21, x15, #0, #3
    21d8:      	ldrb	w15, [x21]
    21dc:      	umov.b	w21, v21[5]
    21e0:      	and	w6, w6, w15
    21e4:      	mov.s	v3[2], v16[0]
    21e8:      	str	q7, [sp, #0x1000]
    21ec:      	str	q6, [sp, #0x1010]
    21f0:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
    21f4:      	ldr	s16, [x12, x27, lsl #2]
    21f8:      	ands	w15, w21, #0x1
    21fc:      	tst	w15, w6
    2200:      	fcsel	s16, s16, s23, ne
    2204:      	cmp	w13, #0x8
    2208:      	csel	w13, w13, wzr, lo
    220c:      	cset	w6, lo
    2210:      	and	x27, x13, #0x7
    2214:      	add	x22, sp, #0xdf8
    2218:      	bfxil	x22, x13, #0, #3
    221c:      	ldrb	w22, [x22]
    2220:      	umov.b	w13, v21[6]
    2224:      	and	w22, w6, w22
    2228:      	str	q7, [sp, #0xfe0]
    222c:      	str	q6, [sp, #0xff0]
    2230:      	mov.s	v3[3], v20[0]
    2234:      	add	x12, sp, #0xfe0
    2238:      	ldr	s17, [x12, x27, lsl #2]
    223c:      	ands	w6, w13, #0x1
    2240:      	tst	w6, w22
    2244:      	fcsel	s17, s17, s23, ne
    2248:      	cmp	w0, #0x8
    224c:      	csel	w0, w0, wzr, lo
    2250:      	cset	w22, lo
    2254:      	and	x27, x0, #0x7
    2258:      	add	x17, sp, #0xdf8
    225c:      	bfxil	x17, x0, #0, #3
    2260:      	ldrb	w17, [x17]
    2264:      	umov.b	w0, v21[7]
    2268:      	and	w17, w22, w17
    226c:      	str	q7, [sp, #0xfc0]
    2270:      	str	q6, [sp, #0xfd0]
    2274:      	mov.s	v4[1], v16[0]
    2278:      	add	x12, sp, #0xfc0
    227c:      	ldr	s16, [x12, x27, lsl #2]
    2280:      	ands	w27, w0, #0x1
    2284:      	tst	w27, w17
    2288:      	fcsel	s20, s16, s23, ne
    228c:      	stp	q29, q27, [sp, #0x2e0]
    2290:      	str	q5, [sp, #0x2c0]
    2294:      	str	q26, [sp, #0x140]
    2298:      	mov.16b	v27, v24
    229c:      	mov.16b	v24, v19
    22a0:      	movi.4s	v19, #0x2
    22a4:      	eor.16b	v16, v25, v19
    22a8:      	mov.s	w17, v16[1]
    22ac:      	fmov	w22, s16
    22b0:      	cmp	w22, #0x8
    22b4:      	csel	w22, w22, wzr, lo
    22b8:      	cset	w1, lo
    22bc:      	add	x12, sp, #0xdf8
    22c0:      	bfxil	x12, x22, #0, #3
    22c4:      	ldrb	w12, [x12]
    22c8:      	and	w12, w1, w12
    22cc:      	mov.s	v4[2], v17[0]
    22d0:      	mov.s	v4[3], v20[0]
    22d4:      	fadd.4s	v4, v6, v4
    22d8:      	fadd.4s	v3, v7, v3
    22dc:      	and	x1, x22, #0x7
    22e0:      	str	q3, [sp, #0xf20]
    22e4:      	str	q4, [sp, #0xf30]
    22e8:      	add	x22, sp, #0xf20
    22ec:      	ldr	s6, [x22, x1, lsl #2]
    22f0:      	add	x22, sp, #0x1, lsl #12  ; =0x1000
    22f4:      	add	x22, x22, #0x60
    22f8:      	tst	w7, w12
    22fc:      	fcsel	s6, s6, s23, ne
    2300:      	cmp	w17, #0x8
    2304:      	csel	w12, w17, wzr, lo
    2308:      	cset	w17, lo
    230c:      	add	x1, sp, #0xdf8
    2310:      	bfxil	x1, x12, #0, #3
    2314:      	ldrb	w1, [x1]
    2318:      	and	w17, w17, w1
    231c:      	and	x12, x12, #0x7
    2320:      	str	q3, [sp, #0xf00]
    2324:      	str	q4, [sp, #0xf10]
    2328:      	add	x1, sp, #0xf00
    232c:      	ldr	s7, [x1, x12, lsl #2]
    2330:      	mov.s	w12, v16[2]
    2334:      	tst	w26, w17
    2338:      	add	x26, sp, #0x4, lsl #12  ; =0x4000
    233c:      	add	x26, x26, #0x2d8
    2340:      	fcsel	s7, s7, s23, ne
    2344:      	cmp	w12, #0x8
    2348:      	csel	w12, w12, wzr, lo
    234c:      	cset	w17, lo
    2350:      	add	x1, sp, #0xdf8
    2354:      	bfxil	x1, x12, #0, #3
    2358:      	ldrb	w1, [x1]
    235c:      	and	w17, w17, w1
    2360:      	and	x12, x12, #0x7
    2364:      	str	q3, [sp, #0xee0]
    2368:      	str	q4, [sp, #0xef0]
    236c:      	add	x1, sp, #0xee0
    2370:      	ldr	s17, [x1, x12, lsl #2]
    2374:      	mov.s	w12, v16[3]
    2378:      	tst	w20, w17
    237c:      	add	x20, sp, #0x2, lsl #12  ; =0x2000
    2380:      	add	x20, x20, #0xaa8
    2384:      	fcsel	s16, s17, s23, ne
    2388:      	cmp	w12, #0x8
    238c:      	csel	w12, w12, wzr, lo
    2390:      	cset	w17, lo
    2394:      	add	x1, sp, #0xdf8
    2398:      	bfxil	x1, x12, #0, #3
    239c:      	ldrb	w1, [x1]
    23a0:      	and	w17, w17, w1
    23a4:      	eor.16b	v19, v8, v19
    23a8:      	mov.16b	v30, v22
    23ac:      	mov.16b	v5, v13
    23b0:      	mov.16b	v25, v9
    23b4:      	ldp	q8, q20, [sp, #0x3c0]
    23b8:      	mov.16b	v9, v11
    23bc:      	mov.16b	v11, v24
    23c0:      	ldr	q22, [sp, #0x210]
    23c4:      	mov.16b	v13, v30
    23c8:      	mov.16b	v24, v27
    23cc:      	ldr	q26, [sp, #0x140]
    23d0:      	ldp	q29, q27, [sp, #0x2e0]
    23d4:      	mov.16b	v30, v5
    23d8:      	ldr	q5, [sp, #0x2c0]
    23dc:      	and	x12, x12, #0x7
    23e0:      	str	q3, [sp, #0xec0]
    23e4:      	str	q4, [sp, #0xed0]
    23e8:      	add	x1, sp, #0xec0
    23ec:      	ldr	s1, [x1, x12, lsl #2]
    23f0:      	tst	w5, w17
    23f4:      	fcsel	s1, s1, s23, ne
    23f8:      	fmov	w12, s19
    23fc:      	cmp	w12, #0x8
    2400:      	csel	w12, w12, wzr, lo
    2404:      	cset	w17, lo
    2408:      	add	x1, sp, #0xdf8
    240c:      	bfxil	x1, x12, #0, #3
    2410:      	ldrb	w1, [x1]
    2414:      	and	w17, w17, w1
    2418:      	mov.s	w1, v19[1]
    241c:      	and	x12, x12, #0x7
    2420:      	str	q3, [sp, #0xea0]
    2424:      	str	q4, [sp, #0xeb0]
    2428:      	add	x5, sp, #0xea0
    242c:      	ldr	s17, [x5, x12, lsl #2]
    2430:      	mov.s	w12, v19[2]
    2434:      	tst	w2, w17
    2438:      	fcsel	s17, s17, s23, ne
    243c:      	cmp	w1, #0x8
    2440:      	csel	w17, w1, wzr, lo
    2444:      	cset	w1, lo
    2448:      	add	x2, sp, #0xdf8
    244c:      	bfxil	x2, x17, #0, #3
    2450:      	ldrb	w2, [x2]
    2454:      	and	w1, w1, w2
    2458:      	mov.s	w2, v19[3]
    245c:      	and	x17, x17, #0x7
    2460:      	str	q3, [sp, #0xe80]
    2464:      	str	q4, [sp, #0xe90]
    2468:      	add	x5, sp, #0xe80
    246c:      	ldr	s19, [x5, x17, lsl #2]
    2470:      	tst	w15, w1
    2474:      	fcsel	s19, s19, s23, ne
    2478:      	cmp	w12, #0x8
    247c:      	csel	w12, w12, wzr, lo
    2480:      	cset	w15, lo
    2484:      	add	x17, sp, #0xdf8
    2488:      	bfxil	x17, x12, #0, #3
    248c:      	ldrb	w17, [x17]
    2490:      	and	w15, w15, w17
    2494:      	and	x12, x12, #0x7
    2498:      	str	q3, [sp, #0xe60]
    249c:      	str	q4, [sp, #0xe70]
    24a0:      	mov.s	v17[1], v19[0]
    24a4:      	add	x17, sp, #0xe60
    24a8:      	ldr	s19, [x17, x12, lsl #2]
    24ac:      	tst	w6, w15
    24b0:      	ldr	x6, [sp, #0x98]
    24b4:      	fcsel	s19, s19, s23, ne
    24b8:      	mov.s	v17[2], v19[0]
    24bc:      	xtn.2s	v19, v24
    24c0:      	cmp	w2, #0x8
    24c4:      	csel	w12, w2, wzr, lo
    24c8:      	cset	w15, lo
    24cc:      	add	x17, sp, #0xdf8
    24d0:      	bfxil	x17, x12, #0, #3
    24d4:      	and	x12, x12, #0x7
    24d8:      	ldrb	w17, [x17]
    24dc:      	and	w15, w15, w17
    24e0:      	str	q3, [sp, #0xe40]
    24e4:      	str	q4, [sp, #0xe50]
    24e8:      	fmov	w17, s19
    24ec:      	add	x1, sp, #0xe40
    24f0:      	ldr	s19, [x1, x12, lsl #2]
    24f4:      	tst	w27, w15
    24f8:      	adrp	x27, 0x2000 <ltmp0+0x2000>
    24fc:      	fcsel	s19, s19, s23, ne
    2500:      	eor	w12, w17, #0x4
    2504:      	cmp	w17, #0x8
    2508:      	csel	w12, w12, wzr, lo
    250c:      	cset	w15, lo
    2510:      	add	x17, sp, #0xdf8
    2514:      	bfxil	x17, x12, #0, #3
    2518:      	ldrb	w17, [x17]
    251c:      	and	w15, w15, w17
    2520:      	mov.s	v17[3], v19[0]
    2524:      	mov.s	v6[1], v7[0]
    2528:      	mov.s	v6[2], v16[0]
    252c:      	tst	w7, w15
    2530:      	mov.s	v6[3], v1[0]
    2534:      	fadd.4s	v1, v3, v6
    2538:      	fadd.4s	v3, v4, v17
    253c:      	and	x12, x12, #0x7
    2540:      	str	q3, [sp, #0xe30]
    2544:      	str	q1, [sp, #0xe20]
    2548:      	add	x15, sp, #0xe20
    254c:      	ldr	s3, [x15, x12, lsl #2]
    2550:      	fcsel	s3, s3, s23, ne
    2554:      	tst	w23, #0x1
    2558:      	add	x23, sp, #0x4, lsl #12  ; =0x4000
    255c:      	add	x23, x23, #0x318
    2560:      	fadd	s1, s1, s3
    2564:      	fcsel	s1, s1, s23, ne
    2568:      	tst	w10, #0x1
    256c:      	fcsel	s3, s1, s23, ne
    2570:      	tst	w19, #0x1
    2574:      	ldp	x19, x7, [sp, #0x88]
    2578:      	fcsel	s4, s1, s23, ne
    257c:      	tst	w3, #0x1
    2580:      	fcsel	s6, s1, s23, ne
    2584:      	tst	w25, #0x1
    2588:      	fcsel	s7, s1, s23, ne
    258c:      	tst	w21, #0x1
    2590:      	fcsel	s16, s1, s23, ne
    2594:      	tst	w13, #0x1
    2598:      	fcsel	s17, s1, s23, ne
    259c:      	tst	w0, #0x1
    25a0:      	fcsel	s19, s1, s23, ne
    25a4:      	mov.s	v1[1], v3[0]
    25a8:      	mov.s	v1[2], v4[0]
    25ac:      	mov.s	v1[3], v6[0]
    25b0:      	rbit	w10, w11
    25b4:      	clz	w10, w10
    25b8:      	mov.s	v7[1], v16[0]
    25bc:      	mov.s	v7[2], v17[0]
    25c0:      	mov.s	v7[3], v19[0]
    25c4:      	mov.16b	v19, v11
    25c8:      	mov.16b	v11, v9
    25cc:      	mov.16b	v9, v25
    25d0:      	str	q7, [sp, #0xe10]
    25d4:      	str	q1, [sp, #0xe00]
    25d8:      	and	x10, x10, #0x7
    25dc:      	add	x11, sp, #0xe00
    25e0:      	ldr	s1, [x11, x10, lsl #2]
    25e4:      	fadd	s1, s1, s23
    25e8:      	ldr	q23, [sp, #0x150]
    25ec:      	ldr	q18, [sp, #0x2d0]
    25f0:      	mov	w10, #0x4000            ; =16384
    25f4:      	movk	w10, #0x44c0, lsl #16
    25f8:      	fmov	s3, w10
    25fc:      	fdiv	s1, s1, s3
    2600:      	dup.4s	v1, v1[0]
    2604:      	zip2.8b	v3, v21, v0
    2608:      	ushll.4s	v3, v3, #0x0
    260c:      	shl.4s	v3, v3, #0x1f
    2610:      	cmlt.4s	v3, v3, #0
    2614:      	ldr	q4, [sp, #0xf0]
    2618:      	bit.16b	v4, v1, v3
    261c:      	str	q4, [sp, #0xf0]
    2620:      	zip1.8b	v3, v21, v0
    2624:      	ushll.4s	v3, v3, #0x0
    2628:      	shl.4s	v3, v3, #0x1f
    262c:      	cmlt.4s	v3, v3, #0
    2630:      	ldr	q4, [sp, #0x100]
    2634:      	bit.16b	v4, v1, v3
    2638:      	str	q4, [sp, #0x100]
    263c:      	mov	b1, v21[6]
    2640:      	mov.b	v1[4], v21[7]
    2644:      	ushll.2d	v1, v1, #0x0
    2648:      	shl.2d	v1, v1, #0x3f
    264c:      	cmlt.2d	v1, v1, #0
    2650:      	mov	b3, v21[4]
    2654:      	mov.b	v3[4], v21[5]
    2658:      	ushll.2d	v3, v3, #0x0
    265c:      	shl.2d	v3, v3, #0x3f
    2660:      	cmlt.2d	v3, v3, #0
    2664:      	mov	b4, v21[2]
    2668:      	mov.b	v4[4], v21[3]
    266c:      	ushll.2d	v4, v4, #0x0
    2670:      	shl.2d	v4, v4, #0x3f
    2674:      	cmlt.2d	v4, v4, #0
    2678:      	mov	b6, v21[0]
    267c:      	mov.b	v6[4], v21[1]
    2680:      	ushll.2d	v6, v6, #0x0
    2684:      	shl.2d	v6, v6, #0x3f
    2688:      	cmlt.2d	v6, v6, #0
    268c:      	ldr	q7, [x27]
    2690:      	ldr	q16, [sp, #0x3b0]
    2694:      	bit.16b	v16, v7, v1
    2698:      	str	q16, [sp, #0x3b0]
    269c:      	adrp	x10, 0x2000 <ltmp0+0x2000>
    26a0:      	ldr	q7, [x10]
    26a4:      	bit.16b	v26, v7, v3
    26a8:      	adrp	x10, 0x2000 <ltmp0+0x2000>
    26ac:      	ldr	q7, [x10]
    26b0:      	bit.16b	v8, v7, v4
    26b4:      	str	q8, [sp, #0x3c0]
    26b8:      	adrp	x10, 0x2000 <ltmp0+0x2000>
    26bc:      	ldr	q7, [x10]
    26c0:      	bit.16b	v20, v7, v6
    26c4:      	str	q20, [sp, #0x3d0]
    26c8:      	ldr	q7, [sp, #0x70]
    26cc:      	ldr	q16, [sp, #0x240]
    26d0:      	bit.16b	v16, v7, v1
    26d4:      	bic.16b	v27, v27, v1
    26d8:      	ldr	q1, [sp, #0x220]
    26dc:      	bit.16b	v1, v7, v3
    26e0:      	bic.16b	v12, v12, v3
    26e4:      	bit.16b	v22, v7, v4
    26e8:      	stp	q22, q1, [sp, #0x210]
    26ec:      	mov.16b	v22, v13
    26f0:      	mov.16b	v13, v30
    26f4:      	bic.16b	v10, v10, v4
    26f8:      	ldr	q1, [sp, #0x230]
    26fc:      	bit.16b	v1, v7, v6
    2700:      	stp	q1, q16, [sp, #0x230]
    2704:      	bic.16b	v29, v29, v6
    2708:      	add	x25, sp, #0x4, lsl #12  ; =0x4000
    270c:      	add	x25, x25, #0x2f8
    2710:      	add	x17, sp, #0x1, lsl #12  ; =0x1000
    2714:      	add	x17, x17, #0x160
    2718:      	add	x1, sp, #0x1, lsl #12   ; =0x1000
    271c:      	add	x1, x1, #0x140
    2720:      	mov	w5, #0xc0               ; =192
    2724:      	add	x3, sp, #0xdd0
    2728:      	ldr	x21, [sp, #0xa8]
    272c:      	b	0x274c <ltmp0+0x274c>
    2730:      	add	x25, sp, #0x4, lsl #12  ; =0x4000
    2734:      	add	x25, x25, #0x2f8
    2738:      	add	x17, sp, #0x1, lsl #12  ; =0x1000
    273c:      	add	x17, x17, #0x160
    2740:      	add	x1, sp, #0x1, lsl #12   ; =0x1000
    2744:      	add	x1, x1, #0x140
    2748:      	b	0x1070 <ltmp0+0x1070>
    274c:      	shl.8b	v1, v21, #0x7
    2750:      	cmlt.8b	v1, v1, #0
    2754:      	and.8b	v1, v1, v2
    2758:      	addv.8b	b1, v1
    275c:      	fmov	w11, s1
    2760:      	dup.2d	v3, x5
    2764:      	cmgt.2d	v1, v3, v10
    2768:      	cmgt.2d	v4, v3, v29
    276c:      	uzp1.4s	v1, v4, v1
    2770:      	cmgt.2d	v4, v3, v12
    2774:      	cmgt.2d	v6, v3, v27
    2778:      	uzp1.4s	v4, v4, v6
    277c:      	uzp1.8h	v1, v1, v4
    2780:      	xtn.8b	v1, v1
    2784:      	and.8b	v1, v21, v1
    2788:      	shl.8b	v1, v1, #0x7
    278c:      	cmlt.8b	v4, v1, #0
    2790:      	and.8b	v1, v4, v2
    2794:      	addv.8b	b1, v1
    2798:      	fmov	w10, s1
    279c:      	umaxv.8b	b4, v4
    27a0:      	fmov	w13, s4
    27a4:      	tbz	w13, #0x0, 0x29c8 <ltmp0+0x29c8>
    27a8:      	cmge.2d	v4, v10, v3
    27ac:      	cmge.2d	v6, v29, v3
    27b0:      	uzp1.4s	v4, v6, v4
    27b4:      	cmge.2d	v6, v12, v3
    27b8:      	cmge.2d	v3, v27, v3
    27bc:      	uzp1.4s	v3, v6, v3
    27c0:      	uzp1.8h	v3, v4, v3
    27c4:      	xtn.8b	v3, v3
    27c8:      	and.8b	v3, v21, v3
    27cc:      	shl.8b	v3, v3, #0x7
    27d0:      	cmlt.8b	v3, v3, #0
    27d4:      	and.8b	v3, v3, v2
    27d8:      	addv.8b	b3, v3
    27dc:      	fmov	w13, s3
    27e0:      	tst	w13, #0xff
    27e4:      	b.eq	0x29c8 <ltmp0+0x29c8>
    27e8:      	subs	w10, w14, #0x1
    27ec:      	csel	w10, wzr, w10, lo
    27f0:      	and	w11, w30, #0xff
    27f4:      	lsr	w12, w11, w10
    27f8:      	tst	w12, #0x1
    27fc:      	ldr	q4, [sp, #0x440]
    2800:      	str	q4, [sp, #0x7c0]
    2804:      	ldr	q4, [sp, #0x450]
    2808:      	str	q4, [sp, #0x7d0]
    280c:      	and	x10, x10, #0x7
    2810:      	add	x12, sp, #0x7c0
    2814:      	ldr	w10, [x12, x10, lsl #2]
    2818:      	ccmp	w14, #0x0, #0x4, ne
    281c:      	ccmp	w10, #0x3, #0x0, ne
    2820:      	cset	w10, ne
    2824:      	cmp	w11, #0xff
    2828:      	b.ne	0x2830 <ltmp0+0x2830>
    282c:      	tbnz	w10, #0x0, 0x5400 <ltmp0+0x5400>
    2830:      	mvn	w11, w30
    2834:      	rbit	w11, w11
    2838:      	clz	w11, w11
    283c:      	mov	w12, #0xff              ; =255
    2840:      	bics	wzr, w12, w30
    2844:      	csel	w11, wzr, w11, eq
    2848:      	ubfiz	x12, x11, #2, #3
    284c:      	lsl	w13, w16, w11
    2850:      	ldr	q6, [sp, #0x440]
    2854:      	str	q6, [sp, #0x7a0]
    2858:      	ldr	q4, [sp, #0x450]
    285c:      	str	q4, [sp, #0x7b0]
    2860:      	add	x15, sp, #0x7a0
    2864:      	ldr	w15, [x15, x12]
    2868:      	cmp	w10, #0x0
    286c:      	csel	w10, w13, wzr, ne
    2870:      	mov	w13, #0x3               ; =3
    2874:      	csel	w13, w13, w15, ne
    2878:      	str	q6, [sp, #0x780]
    287c:      	str	q4, [sp, #0x790]
    2880:      	add	x15, sp, #0x780
    2884:      	str	w13, [x15, x12]
    2888:      	ldr	q4, [sp, #0x790]
    288c:      	str	q4, [sp, #0x450]
    2890:      	ldr	q4, [sp, #0x780]
    2894:      	str	q4, [sp, #0x440]
    2898:      	ldr	q6, [sp, #0x420]
    289c:      	str	q6, [sp, #0x760]
    28a0:      	ldr	q4, [sp, #0x430]
    28a4:      	str	q4, [sp, #0x770]
    28a8:      	add	x13, sp, #0x760
    28ac:      	ldr	w13, [x13, x12]
    28b0:      	csel	w13, w14, w13, ne
    28b4:      	str	q6, [sp, #0x740]
    28b8:      	str	q4, [sp, #0x750]
    28bc:      	add	x15, sp, #0x740
    28c0:      	str	w13, [x15, x12]
    28c4:      	ldrb	w12, [x28, x11]
    28c8:      	and	w13, w12, #0x1
    28cc:      	fmov	s4, w13
    28d0:      	ubfx	w13, w12, #1, #1
    28d4:      	mov.b	v4[1], w13
    28d8:      	ubfx	w13, w12, #2, #1
    28dc:      	mov.b	v4[2], w13
    28e0:      	ubfx	w13, w12, #3, #1
    28e4:      	mov.b	v4[3], w13
    28e8:      	ubfx	w13, w12, #4, #1
    28ec:      	mov.b	v4[4], w13
    28f0:      	ubfx	w13, w12, #5, #1
    28f4:      	mov.b	v4[5], w13
    28f8:      	ubfx	w13, w12, #6, #1
    28fc:      	mov.b	v4[6], w13
    2900:      	ldr	q6, [sp, #0x750]
    2904:      	str	q6, [sp, #0x430]
    2908:      	ldr	q6, [sp, #0x740]
    290c:      	str	q6, [sp, #0x420]
    2910:      	lsr	w12, w12, #7
    2914:      	mov.b	v4[7], w12
    2918:      	ldrb	w12, [x8, x11]
    291c:      	and	w13, w12, #0x1
    2920:      	fmov	s6, w13
    2924:      	ubfx	w13, w12, #1, #1
    2928:      	mov.b	v6[1], w13
    292c:      	ubfx	w13, w12, #2, #1
    2930:      	mov.b	v6[2], w13
    2934:      	ubfx	w13, w12, #3, #1
    2938:      	mov.b	v6[3], w13
    293c:      	ubfx	w13, w12, #4, #1
    2940:      	mov.b	v6[4], w13
    2944:      	ubfx	w13, w12, #5, #1
    2948:      	mov.b	v6[5], w13
    294c:      	ubfx	w13, w12, #6, #1
    2950:      	mov.b	v6[6], w13
    2954:      	lsr	w12, w12, #7
    2958:      	mov.b	v6[7], w12
    295c:      	csetm	w12, ne
    2960:      	dup.8b	v7, w12
    2964:      	bit.8b	v4, v21, v7
    2968:      	shl.8b	v4, v4, #0x7
    296c:      	cmlt.8b	v4, v4, #0
    2970:      	and.8b	v4, v4, v2
    2974:      	addv.8b	b4, v4
    2978:      	str	b4, [x28, x11]
    297c:      	bic.8b	v4, v6, v7
    2980:      	shl.8b	v4, v4, #0x7
    2984:      	cmlt.8b	v4, v4, #0
    2988:      	and.8b	v4, v4, v2
    298c:      	addv.8b	b4, v4
    2990:      	str	b4, [x8, x11]
    2994:      	csinc	w11, w14, w11, eq
    2998:      	cmp	w24, #0x8
    299c:      	b.hs	0x5400 <ltmp0+0x5400>
    29a0:      	str	b1, [x23, x21]
    29a4:      	mov	w12, #0xc               ; =12
    29a8:      	str	w12, [x25, x21, lsl #2]
    29ac:      	str	w11, [x26, x21, lsl #2]
    29b0:      	cmp	w9, #0x8
    29b4:      	b.hs	0x5400 <ltmp0+0x5400>
    29b8:      	str	b3, [x23, w9, uxtw]
    29bc:      	orr	w30, w10, w30
    29c0:      	mov	w10, #0xd               ; =13
    29c4:      	b	0x2bc <ltmp0+0x2bc>
    29c8:      	tst	w10, #0xff
    29cc:      	b.eq	0x2bdc <ltmp0+0x2bdc>
    29d0:      	tst	w11, #0xff
    29d4:      	b.eq	0x2c8 <ltmp0+0x2c8>
    29d8:      	rbit	w10, w11
    29dc:      	clz	w10, w10
    29e0:      	tst	w11, #0xff
    29e4:      	csel	w10, wzr, w10, eq
    29e8:      	str	q29, [sp, #0x820]
    29ec:      	str	q10, [sp, #0x830]
    29f0:      	str	q12, [sp, #0x840]
    29f4:      	str	q27, [sp, #0x850]
    29f8:      	ubfiz	x13, x10, #3, #3
    29fc:      	add	x12, sp, #0x820
    2a00:      	ldr	x15, [x12, x13]
    2a04:      	str	q24, [sp, #0x7e0]
    2a08:      	str	q14, [sp, #0x7f0]
    2a0c:      	str	q31, [sp, #0x800]
    2a10:      	str	q5, [sp, #0x810]
    2a14:      	add	x12, sp, #0x7e0
    2a18:      	ldr	x13, [x12, x13]
    2a1c:      	sub	x10, x13, x10
    2a20:      	add	x13, x7, x15, lsl #5
    2a24:      	add	x10, x13, x10, lsl #2
    2a28:      	shl.8b	v1, v21, #0x7
    2a2c:      	cmlt.8b	v1, v1, #0
    2a30:      	and.8b	v1, v1, v2
    2a34:      	addv.8b	b4, v1
    2a38:      	fmov	w13, s4
    2a3c:      	movi.2d	v3, #0000000000000000
    2a40:      	movi.2d	v1, #0000000000000000
    2a44:      	tbnz	w13, #0x0, 0x2b20 <ltmp0+0x2b20>
    2a48:      	tbnz	w13, #0x1, 0x2b28 <ltmp0+0x2b28>
    2a4c:      	tbnz	w13, #0x2, 0x2b34 <ltmp0+0x2b34>
    2a50:      	tbnz	w13, #0x3, 0x2b40 <ltmp0+0x2b40>
    2a54:      	tbnz	w13, #0x4, 0x2b4c <ltmp0+0x2b4c>
    2a58:      	tbnz	w13, #0x5, 0x2b58 <ltmp0+0x2b58>
    2a5c:      	tbnz	w13, #0x6, 0x2b64 <ltmp0+0x2b64>
    2a60:      	mov.16b	v30, v24
    2a64:      	mov.16b	v24, v19
    2a68:      	tbz	w13, #0x7, 0x2a74 <ltmp0+0x2a74>
    2a6c:      	add	x10, x10, #0x1c
    2a70:      	ld1.s	{ v1 }[3], [x10]
    2a74:      	shl.2d	v6, v29, #0x5
    2a78:      	shl.2d	v7, v10, #0x5
    2a7c:      	shl.2d	v17, v12, #0x5
    2a80:      	shl.2d	v19, v27, #0x5
    2a84:      	ldr	q16, [sp, #0x230]
    2a88:      	ldp	q20, q25, [sp, #0x3c0]
    2a8c:      	add.2d	v16, v16, v25
    2a90:      	add.2d	v16, v16, v6
    2a94:      	ldr	q6, [sp, #0x210]
    2a98:      	add.2d	v6, v6, v20
    2a9c:      	add.2d	v7, v6, v7
    2aa0:      	ldr	q6, [sp, #0x220]
    2aa4:      	add.2d	v6, v6, v26
    2aa8:      	add.2d	v6, v6, v17
    2aac:      	ldr	q17, [sp, #0x240]
    2ab0:      	ldr	q20, [sp, #0x3b0]
    2ab4:      	add.2d	v17, v17, v20
    2ab8:      	fmov	w10, s4
    2abc:      	add.2d	v4, v17, v19
    2ac0:      	tbnz	w10, #0x0, 0x2b7c <ltmp0+0x2b7c>
    2ac4:      	mov.16b	v19, v24
    2ac8:      	tbnz	w10, #0x1, 0x2b8c <ltmp0+0x2b8c>
    2acc:      	mov.16b	v24, v30
    2ad0:      	tbnz	w10, #0x2, 0x2b9c <ltmp0+0x2b9c>
    2ad4:      	tbnz	w10, #0x3, 0x2ba8 <ltmp0+0x2ba8>
    2ad8:      	tbnz	w10, #0x4, 0x2bb4 <ltmp0+0x2bb4>
    2adc:      	tbnz	w10, #0x5, 0x2bc0 <ltmp0+0x2bc0>
    2ae0:      	tbnz	w10, #0x6, 0x2bcc <ltmp0+0x2bcc>
    2ae4:      	tbz	w10, #0x7, 0x2af0 <ltmp0+0x2af0>
    2ae8:      	mov.d	x10, v4[1]
    2aec:      	st1.s	{ v1 }[3], [x10]
    2af0:      	movi.8b	v1, #0x1
    2af4:      	and.8b	v1, v21, v1
    2af8:      	ushll.8h	v1, v1, #0x0
    2afc:      	ushll.4s	v3, v1, #0x0
    2b00:      	ushll2.4s	v1, v1, #0x0
    2b04:      	uaddw2.2d	v27, v27, v1
    2b08:      	uaddw.2d	v12, v12, v1
    2b0c:      	uaddw2.2d	v10, v10, v3
    2b10:      	uaddw.2d	v29, v29, v3
    2b14:      	tst	w11, #0xff
    2b18:      	b.ne	0x274c <ltmp0+0x274c>
    2b1c:      	b	0x2c8 <ltmp0+0x2c8>
    2b20:      	ldr	s3, [x10]
    2b24:      	tbz	w13, #0x1, 0x2a4c <ltmp0+0x2a4c>
    2b28:      	add	x15, x10, #0x4
    2b2c:      	ld1.s	{ v3 }[1], [x15]
    2b30:      	tbz	w13, #0x2, 0x2a50 <ltmp0+0x2a50>
    2b34:      	add	x15, x10, #0x8
    2b38:      	ld1.s	{ v3 }[2], [x15]
    2b3c:      	tbz	w13, #0x3, 0x2a54 <ltmp0+0x2a54>
    2b40:      	add	x15, x10, #0xc
    2b44:      	ld1.s	{ v3 }[3], [x15]
    2b48:      	tbz	w13, #0x4, 0x2a58 <ltmp0+0x2a58>
    2b4c:      	add	x15, x10, #0x10
    2b50:      	ld1.s	{ v1 }[0], [x15]
    2b54:      	tbz	w13, #0x5, 0x2a5c <ltmp0+0x2a5c>
    2b58:      	add	x15, x10, #0x14
    2b5c:      	ld1.s	{ v1 }[1], [x15]
    2b60:      	tbz	w13, #0x6, 0x2a60 <ltmp0+0x2a60>
    2b64:      	add	x15, x10, #0x18
    2b68:      	ld1.s	{ v1 }[2], [x15]
    2b6c:      	mov.16b	v30, v24
    2b70:      	mov.16b	v24, v19
    2b74:      	tbnz	w13, #0x7, 0x2a6c <ltmp0+0x2a6c>
    2b78:      	b	0x2a74 <ltmp0+0x2a74>
    2b7c:      	fmov	x13, d16
    2b80:      	str	s3, [x13]
    2b84:      	mov.16b	v19, v24
    2b88:      	tbz	w10, #0x1, 0x2acc <ltmp0+0x2acc>
    2b8c:      	mov.d	x13, v16[1]
    2b90:      	st1.s	{ v3 }[1], [x13]
    2b94:      	mov.16b	v24, v30
    2b98:      	tbz	w10, #0x2, 0x2ad4 <ltmp0+0x2ad4>
    2b9c:      	fmov	x13, d7
    2ba0:      	st1.s	{ v3 }[2], [x13]
    2ba4:      	tbz	w10, #0x3, 0x2ad8 <ltmp0+0x2ad8>
    2ba8:      	mov.d	x13, v7[1]
    2bac:      	st1.s	{ v3 }[3], [x13]
    2bb0:      	tbz	w10, #0x4, 0x2adc <ltmp0+0x2adc>
    2bb4:      	fmov	x13, d6
    2bb8:      	str	s1, [x13]
    2bbc:      	tbz	w10, #0x5, 0x2ae0 <ltmp0+0x2ae0>
    2bc0:      	mov.d	x13, v6[1]
    2bc4:      	st1.s	{ v1 }[1], [x13]
    2bc8:      	tbz	w10, #0x6, 0x2ae4 <ltmp0+0x2ae4>
    2bcc:      	fmov	x13, d4
    2bd0:      	st1.s	{ v1 }[2], [x13]
    2bd4:      	tbnz	w10, #0x7, 0x2ae8 <ltmp0+0x2ae8>
    2bd8:      	b	0x2af0 <ltmp0+0x2af0>
    2bdc:      	tst	w11, #0xff
    2be0:      	b.eq	0x2c8 <ltmp0+0x2c8>
    2be4:      	cbz	w14, 0x2dac <ltmp0+0x2dac>
    2be8:      	mov	w10, #0x0               ; =0
    2bec:      	shl.8b	v1, v21, #0x7
    2bf0:      	cmlt.8b	v1, v1, #0
    2bf4:      	and.8b	v3, v1, v2
    2bf8:      	addv.8b	b3, v3
    2bfc:      	fmov	w11, s3
    2c00:      	umaxv.8b	b1, v1
    2c04:      	fmov	w12, s1
    2c08:      	sub	w13, w14, #0x1
    2c0c:      	tst	w11, #0xff
    2c10:      	csel	w13, w13, wzr, ne
    2c14:      	lsl	w15, w16, w13
    2c18:      	and	w11, w15, w30
    2c1c:      	tst	w11, #0xff
    2c20:      	cset	w17, ne
    2c24:      	ldr	q1, [sp, #0x440]
    2c28:      	str	q1, [sp, #0xdd0]
    2c2c:      	ldr	q1, [sp, #0x450]
    2c30:      	str	q1, [sp, #0xde0]
    2c34:      	ubfiz	x11, x13, #2, #3
    2c38:      	ldr	w0, [x3, x11]
    2c3c:      	cmp	w0, #0x3
    2c40:      	cset	w0, eq
    2c44:      	and	w2, w17, w12
    2c48:      	ldrb	w12, [x28, w13, sxtw]
    2c4c:      	and	w17, w12, #0x1
    2c50:      	fmov	s1, w17
    2c54:      	ubfx	w17, w12, #1, #1
    2c58:      	mov.b	v1[1], w17
    2c5c:      	ubfx	w17, w12, #2, #1
    2c60:      	mov.b	v1[2], w17
    2c64:      	ubfx	w17, w12, #3, #1
    2c68:      	mov.b	v1[3], w17
    2c6c:      	ubfx	w17, w12, #4, #1
    2c70:      	mov.b	v1[4], w17
    2c74:      	ubfx	w17, w12, #5, #1
    2c78:      	mov.b	v1[5], w17
    2c7c:      	ubfx	w17, w12, #6, #1
    2c80:      	mov.b	v1[6], w17
    2c84:      	lsr	w12, w12, #7
    2c88:      	mov.b	v1[7], w12
    2c8c:      	ldrb	w12, [x8, w13, sxtw]
    2c90:      	and	w17, w12, #0x1
    2c94:      	fmov	s3, w17
    2c98:      	ubfx	w17, w12, #1, #1
    2c9c:      	mov.b	v3[1], w17
    2ca0:      	ubfx	w17, w12, #2, #1
    2ca4:      	mov.b	v3[2], w17
    2ca8:      	ubfx	w17, w12, #3, #1
    2cac:      	mov.b	v3[3], w17
    2cb0:      	ubfx	w17, w12, #4, #1
    2cb4:      	mov.b	v3[4], w17
    2cb8:      	ubfx	w17, w12, #5, #1
    2cbc:      	mov.b	v3[5], w17
    2cc0:      	ubfx	w17, w12, #6, #1
    2cc4:      	mov.b	v3[6], w17
    2cc8:      	lsr	w12, w12, #7
    2ccc:      	mov.b	v3[7], w12
    2cd0:      	orr.8b	v4, v21, v3
    2cd4:      	and.8b	v6, v0, v1
    2cd8:      	eor.8b	v6, v6, v4
    2cdc:      	shl.8b	v6, v6, #0x7
    2ce0:      	cmlt.8b	v6, v6, #0
    2ce4:      	umaxv.8b	b6, v6
    2ce8:      	fmov	w12, s6
    2cec:      	ands	w17, w2, w0
    2cf0:      	csetm	w0, ne
    2cf4:      	bics	w12, w17, w12
    2cf8:      	csetm	w1, ne
    2cfc:      	dup.8b	v6, w1
    2d00:      	dup.8b	v7, w0
    2d04:      	bic.8b	v16, v4, v6
    2d08:      	bit.8b	v3, v16, v7
    2d0c:      	shl.8b	v3, v3, #0x7
    2d10:      	cmlt.8b	v3, v3, #0
    2d14:      	and.8b	v3, v3, v2
    2d18:      	addv.8b	b3, v3
    2d1c:      	str	b3, [x8, w13, sxtw]
    2d20:      	bic.8b	v1, v1, v6
    2d24:      	shl.8b	v1, v1, #0x7
    2d28:      	cmlt.8b	v1, v1, #0
    2d2c:      	and.8b	v1, v1, v2
    2d30:      	addv.8b	b1, v1
    2d34:      	str	b1, [x28, w13, sxtw]
    2d38:      	csinv	w13, w4, w15, eq
    2d3c:      	dup.8b	v1, w17
    2d40:      	and	w30, w13, w30
    2d44:      	shl.8b	v1, v1, #0x7
    2d48:      	cmlt.8b	v1, v1, #0
    2d4c:      	dup.8b	v3, w12
    2d50:      	and.8b	v3, v3, v4
    2d54:      	ldr	q4, [sp, #0x420]
    2d58:      	str	q4, [sp, #0xdb0]
    2d5c:      	ldr	q4, [sp, #0x430]
    2d60:      	str	q4, [sp, #0xdc0]
    2d64:      	add	x12, sp, #0xdb0
    2d68:      	ldr	w11, [x12, x11]
    2d6c:      	csel	w14, w11, w14, ne
    2d70:      	bit.8b	v21, v3, v1
    2d74:      	shl.8b	v1, v21, #0x7
    2d78:      	cmlt.8b	v1, v1, #0
    2d7c:      	and.8b	v1, v1, v2
    2d80:      	addv.8b	b1, v1
    2d84:      	fmov	w11, s1
    2d88:      	cmp	w17, #0x1
    2d8c:      	b.ne	0x2dc0 <ltmp0+0x2dc0>
    2d90:      	cmp	w14, #0x0
    2d94:      	ccmp	w10, #0x6, #0x2, ne
    2d98:      	b.hi	0x2dc0 <ltmp0+0x2dc0>
    2d9c:      	add	w10, w10, #0x1
    2da0:      	tst	w11, #0xff
    2da4:      	b.ne	0x2bec <ltmp0+0x2bec>
    2da8:      	b	0x2dc0 <ltmp0+0x2dc0>
    2dac:      	shl.8b	v1, v21, #0x7
    2db0:      	cmlt.8b	v1, v1, #0
    2db4:      	and.8b	v1, v1, v2
    2db8:      	addv.8b	b1, v1
    2dbc:      	fmov	w11, s1
    2dc0:      	tst	w11, #0xff
    2dc4:      	b.eq	0x3420 <ltmp0+0x3420>
    2dc8:      	and.8b	v1, v11, v21
    2dcc:      	shl.8b	v1, v1, #0x7
    2dd0:      	cmlt.8b	v3, v1, #0
    2dd4:      	and.8b	v1, v3, v2
    2dd8:      	addv.8b	b1, v1
    2ddc:      	umaxv.8b	b3, v3
    2de0:      	fmov	w10, s3
    2de4:      	add	x17, sp, #0x1, lsl #12  ; =0x1000
    2de8:      	add	x17, x17, #0x160
    2dec:      	add	x1, sp, #0x1, lsl #12   ; =0x1000
    2df0:      	add	x1, x1, #0x140
    2df4:      	tbz	w10, #0x0, 0x2ff8 <ltmp0+0x2ff8>
    2df8:      	bic.8b	v3, v21, v11
    2dfc:      	shl.8b	v3, v3, #0x7
    2e00:      	cmlt.8b	v3, v3, #0
    2e04:      	and.8b	v3, v3, v2
    2e08:      	addv.8b	b3, v3
    2e0c:      	fmov	w10, s3
    2e10:      	tst	w10, #0xff
    2e14:      	b.eq	0x2ff8 <ltmp0+0x2ff8>
    2e18:      	subs	w10, w14, #0x1
    2e1c:      	csel	w10, wzr, w10, lo
    2e20:      	and	w11, w30, #0xff
    2e24:      	lsr	w12, w11, w10
    2e28:      	tst	w12, #0x1
    2e2c:      	ldr	q4, [sp, #0x440]
    2e30:      	str	q4, [sp, #0x8e0]
    2e34:      	ldr	q4, [sp, #0x450]
    2e38:      	str	q4, [sp, #0x8f0]
    2e3c:      	and	x10, x10, #0x7
    2e40:      	add	x12, sp, #0x8e0
    2e44:      	ldr	w10, [x12, x10, lsl #2]
    2e48:      	ccmp	w14, #0x0, #0x4, ne
    2e4c:      	ccmp	w10, #0x4, #0x0, ne
    2e50:      	cset	w10, ne
    2e54:      	cmp	w11, #0xff
    2e58:      	b.ne	0x2e60 <ltmp0+0x2e60>
    2e5c:      	tbnz	w10, #0x0, 0x5400 <ltmp0+0x5400>
    2e60:      	mvn	w11, w30
    2e64:      	rbit	w11, w11
    2e68:      	clz	w11, w11
    2e6c:      	mov	w12, #0xff              ; =255
    2e70:      	bics	wzr, w12, w30
    2e74:      	csel	w11, wzr, w11, eq
    2e78:      	ubfiz	x12, x11, #2, #3
    2e7c:      	lsl	w13, w16, w11
    2e80:      	ldr	q6, [sp, #0x440]
    2e84:      	str	q6, [sp, #0x8c0]
    2e88:      	ldr	q4, [sp, #0x450]
    2e8c:      	str	q4, [sp, #0x8d0]
    2e90:      	add	x15, sp, #0x8c0
    2e94:      	ldr	w15, [x15, x12]
    2e98:      	cmp	w10, #0x0
    2e9c:      	csel	w10, w13, wzr, ne
    2ea0:      	mov	w13, #0x4               ; =4
    2ea4:      	csel	w13, w13, w15, ne
    2ea8:      	str	q6, [sp, #0x8a0]
    2eac:      	str	q4, [sp, #0x8b0]
    2eb0:      	add	x15, sp, #0x8a0
    2eb4:      	str	w13, [x15, x12]
    2eb8:      	ldr	q4, [sp, #0x8b0]
    2ebc:      	str	q4, [sp, #0x450]
    2ec0:      	ldr	q4, [sp, #0x8a0]
    2ec4:      	str	q4, [sp, #0x440]
    2ec8:      	ldr	q6, [sp, #0x420]
    2ecc:      	str	q6, [sp, #0x880]
    2ed0:      	ldr	q4, [sp, #0x430]
    2ed4:      	str	q4, [sp, #0x890]
    2ed8:      	add	x13, sp, #0x880
    2edc:      	ldr	w13, [x13, x12]
    2ee0:      	csel	w13, w14, w13, ne
    2ee4:      	str	q6, [sp, #0x860]
    2ee8:      	str	q4, [sp, #0x870]
    2eec:      	add	x15, sp, #0x860
    2ef0:      	str	w13, [x15, x12]
    2ef4:      	ldrb	w12, [x28, x11]
    2ef8:      	and	w13, w12, #0x1
    2efc:      	fmov	s4, w13
    2f00:      	ubfx	w13, w12, #1, #1
    2f04:      	mov.b	v4[1], w13
    2f08:      	ubfx	w13, w12, #2, #1
    2f0c:      	mov.b	v4[2], w13
    2f10:      	ubfx	w13, w12, #3, #1
    2f14:      	mov.b	v4[3], w13
    2f18:      	ubfx	w13, w12, #4, #1
    2f1c:      	mov.b	v4[4], w13
    2f20:      	ubfx	w13, w12, #5, #1
    2f24:      	mov.b	v4[5], w13
    2f28:      	ubfx	w13, w12, #6, #1
    2f2c:      	mov.b	v4[6], w13
    2f30:      	ldr	q6, [sp, #0x870]
    2f34:      	str	q6, [sp, #0x430]
    2f38:      	ldr	q6, [sp, #0x860]
    2f3c:      	str	q6, [sp, #0x420]
    2f40:      	lsr	w12, w12, #7
    2f44:      	mov.b	v4[7], w12
    2f48:      	ldrb	w12, [x8, x11]
    2f4c:      	and	w13, w12, #0x1
    2f50:      	fmov	s6, w13
    2f54:      	ubfx	w13, w12, #1, #1
    2f58:      	mov.b	v6[1], w13
    2f5c:      	ubfx	w13, w12, #2, #1
    2f60:      	mov.b	v6[2], w13
    2f64:      	ubfx	w13, w12, #3, #1
    2f68:      	mov.b	v6[3], w13
    2f6c:      	ubfx	w13, w12, #4, #1
    2f70:      	mov.b	v6[4], w13
    2f74:      	ubfx	w13, w12, #5, #1
    2f78:      	mov.b	v6[5], w13
    2f7c:      	ubfx	w13, w12, #6, #1
    2f80:      	mov.b	v6[6], w13
    2f84:      	lsr	w12, w12, #7
    2f88:      	mov.b	v6[7], w12
    2f8c:      	csetm	w12, ne
    2f90:      	dup.8b	v7, w12
    2f94:      	bit.8b	v4, v21, v7
    2f98:      	shl.8b	v4, v4, #0x7
    2f9c:      	cmlt.8b	v4, v4, #0
    2fa0:      	and.8b	v4, v4, v2
    2fa4:      	addv.8b	b4, v4
    2fa8:      	str	b4, [x28, x11]
    2fac:      	bic.8b	v4, v6, v7
    2fb0:      	shl.8b	v4, v4, #0x7
    2fb4:      	cmlt.8b	v4, v4, #0
    2fb8:      	and.8b	v4, v4, v2
    2fbc:      	addv.8b	b4, v4
    2fc0:      	str	b4, [x8, x11]
    2fc4:      	csinc	w11, w14, w11, eq
    2fc8:      	cmp	w24, #0x8
    2fcc:      	b.hs	0x5400 <ltmp0+0x5400>
    2fd0:      	str	b1, [x23, x21]
    2fd4:      	mov	w12, #0xe               ; =14
    2fd8:      	str	w12, [x25, x21, lsl #2]
    2fdc:      	str	w11, [x26, x21, lsl #2]
    2fe0:      	cmp	w9, #0x8
    2fe4:      	b.hs	0x5400 <ltmp0+0x5400>
    2fe8:      	str	b3, [x23, w9, uxtw]
    2fec:      	orr	w30, w10, w30
    2ff0:      	mov	w10, #0xf               ; =15
    2ff4:      	b	0x2bc <ltmp0+0x2bc>
    2ff8:      	fmov	w10, s1
    2ffc:      	tst	w10, #0xff
    3000:      	b.eq	0x30f8 <ltmp0+0x30f8>
    3004:      	rbit	w10, w11
    3008:      	clz	w10, w10
    300c:      	tst	w11, #0xff
    3010:      	csel	w10, wzr, w10, eq
    3014:      	str	q24, [sp, #0xd70]
    3018:      	str	q14, [sp, #0xd80]
    301c:      	str	q31, [sp, #0xd90]
    3020:      	str	q5, [sp, #0xda0]
    3024:      	and	x13, x10, #0x7
    3028:      	add	x12, sp, #0xd70
    302c:      	ldr	x13, [x12, x13, lsl #3]
    3030:      	sub	x13, x13, x10
    3034:      	ldr	x12, [sp, #0xa0]
    3038:      	add	x13, x12, x13, lsl #2
    303c:      	shl.8b	v1, v21, #0x7
    3040:      	cmlt.8b	v1, v1, #0
    3044:      	and.8b	v1, v1, v2
    3048:      	addv.8b	b1, v1
    304c:      	fmov	w15, s1
    3050:      	movi.2d	v1, #0000000000000000
    3054:      	movi.2d	v3, #0000000000000000
    3058:      	tbnz	w15, #0x0, 0x33cc <ltmp0+0x33cc>
    305c:      	tbnz	w15, #0x1, 0x33d4 <ltmp0+0x33d4>
    3060:      	tbnz	w15, #0x2, 0x33e0 <ltmp0+0x33e0>
    3064:      	tbnz	w15, #0x3, 0x33ec <ltmp0+0x33ec>
    3068:      	tbnz	w15, #0x4, 0x33f8 <ltmp0+0x33f8>
    306c:      	tbnz	w15, #0x5, 0x3404 <ltmp0+0x3404>
    3070:      	tbnz	w15, #0x6, 0x3410 <ltmp0+0x3410>
    3074:      	tbz	w15, #0x7, 0x3080 <ltmp0+0x3080>
    3078:      	add	x13, x13, #0x1c
    307c:      	ld1.s	{ v3 }[3], [x13]
    3080:      	ldp	q4, q6, [sp, #0x3c0]
    3084:      	str	q6, [sp, #0xd30]
    3088:      	str	q4, [sp, #0xd40]
    308c:      	str	q26, [sp, #0xd50]
    3090:      	ldr	q4, [sp, #0x3b0]
    3094:      	str	q4, [sp, #0xd60]
    3098:      	and	x13, x10, #0x7
    309c:      	add	x12, sp, #0xd30
    30a0:      	ldr	x13, [x12, x13, lsl #3]
    30a4:      	sub	x10, x13, x10, lsl #2
    30a8:      	mov	w12, #0x1800            ; =6144
    30ac:      	add	x10, x10, x12
    30b0:      	ands	w11, w11, #0xff
    30b4:      	csel	x10, xzr, x10, eq
    30b8:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
    30bc:      	add	x12, x12, #0x288
    30c0:      	add	x10, x12, x10
    30c4:      	ldp	q4, q6, [x10]
    30c8:      	zip2.8b	v7, v21, v0
    30cc:      	ushll.4s	v7, v7, #0x0
    30d0:      	shl.4s	v7, v7, #0x1f
    30d4:      	cmlt.4s	v7, v7, #0
    30d8:      	bif.16b	v3, v6, v7
    30dc:      	zip1.8b	v6, v21, v0
    30e0:      	ushll.4s	v6, v6, #0x0
    30e4:      	shl.4s	v6, v6, #0x1f
    30e8:      	cmlt.4s	v6, v6, #0
    30ec:      	bif.16b	v1, v4, v6
    30f0:      	stp	q1, q3, [x10]
    30f4:      	cbz	w11, 0x2c8 <ltmp0+0x2c8>
    30f8:      	cbz	w14, 0x32c4 <ltmp0+0x32c4>
    30fc:      	mov	w10, #0x0               ; =0
    3100:      	shl.8b	v1, v21, #0x7
    3104:      	cmlt.8b	v1, v1, #0
    3108:      	and.8b	v3, v1, v2
    310c:      	addv.8b	b3, v3
    3110:      	fmov	w11, s3
    3114:      	umaxv.8b	b1, v1
    3118:      	fmov	w12, s1
    311c:      	sub	w13, w14, #0x1
    3120:      	tst	w11, #0xff
    3124:      	csel	w13, w13, wzr, ne
    3128:      	lsl	w15, w16, w13
    312c:      	and	w11, w15, w30
    3130:      	tst	w11, #0xff
    3134:      	cset	w17, ne
    3138:      	ldr	q1, [sp, #0x440]
    313c:      	str	q1, [sp, #0xd10]
    3140:      	ldr	q1, [sp, #0x450]
    3144:      	str	q1, [sp, #0xd20]
    3148:      	ubfiz	x11, x13, #2, #3
    314c:      	add	x0, sp, #0xd10
    3150:      	ldr	w0, [x0, x11]
    3154:      	cmp	w0, #0x4
    3158:      	cset	w0, eq
    315c:      	and	w2, w17, w12
    3160:      	ldrb	w12, [x28, w13, sxtw]
    3164:      	and	w17, w12, #0x1
    3168:      	fmov	s1, w17
    316c:      	ubfx	w17, w12, #1, #1
    3170:      	mov.b	v1[1], w17
    3174:      	ubfx	w17, w12, #2, #1
    3178:      	mov.b	v1[2], w17
    317c:      	ubfx	w17, w12, #3, #1
    3180:      	mov.b	v1[3], w17
    3184:      	ubfx	w17, w12, #4, #1
    3188:      	mov.b	v1[4], w17
    318c:      	ubfx	w17, w12, #5, #1
    3190:      	mov.b	v1[5], w17
    3194:      	ubfx	w17, w12, #6, #1
    3198:      	mov.b	v1[6], w17
    319c:      	lsr	w12, w12, #7
    31a0:      	mov.b	v1[7], w12
    31a4:      	ldrb	w12, [x8, w13, sxtw]
    31a8:      	and	w17, w12, #0x1
    31ac:      	fmov	s3, w17
    31b0:      	ubfx	w17, w12, #1, #1
    31b4:      	mov.b	v3[1], w17
    31b8:      	ubfx	w17, w12, #2, #1
    31bc:      	mov.b	v3[2], w17
    31c0:      	ubfx	w17, w12, #3, #1
    31c4:      	mov.b	v3[3], w17
    31c8:      	ubfx	w17, w12, #4, #1
    31cc:      	mov.b	v3[4], w17
    31d0:      	ubfx	w17, w12, #5, #1
    31d4:      	mov.b	v3[5], w17
    31d8:      	ubfx	w17, w12, #6, #1
    31dc:      	mov.b	v3[6], w17
    31e0:      	lsr	w12, w12, #7
    31e4:      	mov.b	v3[7], w12
    31e8:      	orr.8b	v4, v21, v3
    31ec:      	and.8b	v6, v0, v1
    31f0:      	eor.8b	v6, v6, v4
    31f4:      	shl.8b	v6, v6, #0x7
    31f8:      	cmlt.8b	v6, v6, #0
    31fc:      	umaxv.8b	b6, v6
    3200:      	fmov	w12, s6
    3204:      	ands	w17, w2, w0
    3208:      	csetm	w0, ne
    320c:      	bics	w12, w17, w12
    3210:      	csetm	w1, ne
    3214:      	dup.8b	v6, w1
    3218:      	dup.8b	v7, w0
    321c:      	bic.8b	v16, v4, v6
    3220:      	bit.8b	v3, v16, v7
    3224:      	shl.8b	v3, v3, #0x7
    3228:      	cmlt.8b	v3, v3, #0
    322c:      	and.8b	v3, v3, v2
    3230:      	addv.8b	b3, v3
    3234:      	str	b3, [x8, w13, sxtw]
    3238:      	bic.8b	v1, v1, v6
    323c:      	shl.8b	v1, v1, #0x7
    3240:      	cmlt.8b	v1, v1, #0
    3244:      	and.8b	v1, v1, v2
    3248:      	addv.8b	b1, v1
    324c:      	str	b1, [x28, w13, sxtw]
    3250:      	csinv	w13, w4, w15, eq
    3254:      	dup.8b	v1, w17
    3258:      	and	w30, w13, w30
    325c:      	shl.8b	v1, v1, #0x7
    3260:      	cmlt.8b	v1, v1, #0
    3264:      	dup.8b	v3, w12
    3268:      	and.8b	v3, v3, v4
    326c:      	ldr	q4, [sp, #0x420]
    3270:      	str	q4, [sp, #0xcf0]
    3274:      	ldr	q4, [sp, #0x430]
    3278:      	str	q4, [sp, #0xd00]
    327c:      	add	x12, sp, #0xcf0
    3280:      	ldr	w11, [x12, x11]
    3284:      	csel	w14, w11, w14, ne
    3288:      	bit.8b	v21, v3, v1
    328c:      	shl.8b	v1, v21, #0x7
    3290:      	cmlt.8b	v1, v1, #0
    3294:      	and.8b	v1, v1, v2
    3298:      	addv.8b	b1, v1
    329c:      	fmov	w11, s1
    32a0:      	cmp	w17, #0x1
    32a4:      	b.ne	0x32d8 <ltmp0+0x32d8>
    32a8:      	cmp	w14, #0x0
    32ac:      	ccmp	w10, #0x6, #0x2, ne
    32b0:      	b.hi	0x32d8 <ltmp0+0x32d8>
    32b4:      	add	w10, w10, #0x1
    32b8:      	tst	w11, #0xff
    32bc:      	b.ne	0x3100 <ltmp0+0x3100>
    32c0:      	b	0x32d8 <ltmp0+0x32d8>
    32c4:      	shl.8b	v1, v21, #0x7
    32c8:      	cmlt.8b	v1, v1, #0
    32cc:      	and.8b	v1, v1, v2
    32d0:      	addv.8b	b1, v1
    32d4:      	fmov	w11, s1
    32d8:      	tst	w11, #0xff
    32dc:      	b.eq	0x3420 <ltmp0+0x3420>
    32e0:      	rbit	w10, w11
    32e4:      	clz	w10, w10
    32e8:      	ldp	q1, q3, [sp, #0xf0]
    32ec:      	str	q3, [sp, #0xcd0]
    32f0:      	str	q1, [sp, #0xce0]
    32f4:      	and	x10, x10, #0x7
    32f8:      	add	x11, sp, #0xcd0
    32fc:      	ldr	s1, [x11, x10, lsl #2]
    3300:      	mov	w10, #0xc5ac            ; =50604
    3304:      	movk	w10, #0x3727, lsl #16
    3308:      	fmov	s3, w10
    330c:      	fadd	s1, s1, s3
    3310:      	fsqrt	s1, s1
    3314:      	dup.4s	v1, v1[0]
    3318:      	zip2.8b	v3, v21, v0
    331c:      	ushll.4s	v3, v3, #0x0
    3320:      	shl.4s	v3, v3, #0x1f
    3324:      	cmlt.4s	v3, v3, #0
    3328:      	ldr	q4, [sp, #0x130]
    332c:      	bit.16b	v4, v1, v3
    3330:      	str	q4, [sp, #0x130]
    3334:      	zip1.8b	v3, v21, v0
    3338:      	ushll.4s	v3, v3, #0x0
    333c:      	shl.4s	v3, v3, #0x1f
    3340:      	cmlt.4s	v3, v3, #0
    3344:      	ldr	q4, [sp, #0x340]
    3348:      	bit.16b	v4, v1, v3
    334c:      	str	q4, [sp, #0x340]
    3350:      	mov	b1, v21[6]
    3354:      	mov.b	v1[4], v21[7]
    3358:      	ushll.2d	v1, v1, #0x0
    335c:      	shl.2d	v1, v1, #0x3f
    3360:      	cmge.2d	v1, v1, #0
    3364:      	and.16b	v28, v1, v28
    3368:      	mov	b1, v21[4]
    336c:      	mov.b	v1[4], v21[5]
    3370:      	ushll.2d	v1, v1, #0x0
    3374:      	shl.2d	v1, v1, #0x3f
    3378:      	cmge.2d	v1, v1, #0
    337c:      	mov	b3, v21[2]
    3380:      	mov.b	v3[4], v21[3]
    3384:      	and.16b	v23, v1, v23
    3388:      	ushll.2d	v1, v3, #0x0
    338c:      	shl.2d	v1, v1, #0x3f
    3390:      	cmge.2d	v1, v1, #0
    3394:      	ldr	q3, [sp, #0x410]
    3398:      	and.16b	v3, v1, v3
    339c:      	str	q3, [sp, #0x410]
    33a0:      	mov	b1, v21[0]
    33a4:      	mov.b	v1[4], v21[1]
    33a8:      	ushll.2d	v1, v1, #0x0
    33ac:      	shl.2d	v1, v1, #0x3f
    33b0:      	cmge.2d	v1, v1, #0
    33b4:      	and.16b	v18, v1, v18
    33b8:      	add	x17, sp, #0x1, lsl #12  ; =0x1000
    33bc:      	add	x17, x17, #0x160
    33c0:      	add	x1, sp, #0x1, lsl #12   ; =0x1000
    33c4:      	add	x1, x1, #0x140
    33c8:      	b	0x3434 <ltmp0+0x3434>
    33cc:      	ldr	s1, [x13]
    33d0:      	tbz	w15, #0x1, 0x3060 <ltmp0+0x3060>
    33d4:      	add	x0, x13, #0x4
    33d8:      	ld1.s	{ v1 }[1], [x0]
    33dc:      	tbz	w15, #0x2, 0x3064 <ltmp0+0x3064>
    33e0:      	add	x0, x13, #0x8
    33e4:      	ld1.s	{ v1 }[2], [x0]
    33e8:      	tbz	w15, #0x3, 0x3068 <ltmp0+0x3068>
    33ec:      	add	x0, x13, #0xc
    33f0:      	ld1.s	{ v1 }[3], [x0]
    33f4:      	tbz	w15, #0x4, 0x306c <ltmp0+0x306c>
    33f8:      	add	x0, x13, #0x10
    33fc:      	ld1.s	{ v3 }[0], [x0]
    3400:      	tbz	w15, #0x5, 0x3070 <ltmp0+0x3070>
    3404:      	add	x0, x13, #0x14
    3408:      	ld1.s	{ v3 }[1], [x0]
    340c:      	tbz	w15, #0x6, 0x3074 <ltmp0+0x3074>
    3410:      	add	x0, x13, #0x18
    3414:      	ld1.s	{ v3 }[2], [x0]
    3418:      	tbnz	w15, #0x7, 0x3078 <ltmp0+0x3078>
    341c:      	b	0x3080 <ltmp0+0x3080>
    3420:      	add	x17, sp, #0x1, lsl #12  ; =0x1000
    3424:      	add	x17, x17, #0x160
    3428:      	add	x1, sp, #0x1, lsl #12   ; =0x1000
    342c:      	add	x1, x1, #0x140
    3430:      	b	0x2c8 <ltmp0+0x2c8>
    3434:      	shl.8b	v1, v21, #0x7
    3438:      	cmlt.8b	v1, v1, #0
    343c:      	and.8b	v1, v1, v2
    3440:      	addv.8b	b1, v1
    3444:      	fmov	w11, s1
    3448:      	dup.2d	v3, x5
    344c:      	ldr	q1, [sp, #0x410]
    3450:      	cmgt.2d	v1, v3, v1
    3454:      	cmgt.2d	v4, v3, v18
    3458:      	uzp1.4s	v1, v4, v1
    345c:      	cmgt.2d	v4, v3, v23
    3460:      	cmgt.2d	v6, v3, v28
    3464:      	uzp1.4s	v4, v4, v6
    3468:      	uzp1.8h	v1, v1, v4
    346c:      	xtn.8b	v1, v1
    3470:      	and.8b	v1, v21, v1
    3474:      	shl.8b	v1, v1, #0x7
    3478:      	cmlt.8b	v4, v1, #0
    347c:      	and.8b	v1, v4, v2
    3480:      	addv.8b	b1, v1
    3484:      	fmov	w10, s1
    3488:      	umaxv.8b	b4, v4
    348c:      	fmov	w13, s4
    3490:      	tbz	w13, #0x0, 0x36b8 <ltmp0+0x36b8>
    3494:      	ldr	q4, [sp, #0x410]
    3498:      	cmge.2d	v4, v4, v3
    349c:      	cmge.2d	v6, v18, v3
    34a0:      	uzp1.4s	v4, v6, v4
    34a4:      	cmge.2d	v6, v23, v3
    34a8:      	cmge.2d	v3, v28, v3
    34ac:      	uzp1.4s	v3, v6, v3
    34b0:      	uzp1.8h	v3, v4, v3
    34b4:      	xtn.8b	v3, v3
    34b8:      	and.8b	v3, v21, v3
    34bc:      	shl.8b	v3, v3, #0x7
    34c0:      	cmlt.8b	v3, v3, #0
    34c4:      	and.8b	v3, v3, v2
    34c8:      	addv.8b	b3, v3
    34cc:      	fmov	w13, s3
    34d0:      	tst	w13, #0xff
    34d4:      	b.eq	0x36b8 <ltmp0+0x36b8>
    34d8:      	subs	w10, w14, #0x1
    34dc:      	csel	w10, wzr, w10, lo
    34e0:      	and	w11, w30, #0xff
    34e4:      	lsr	w12, w11, w10
    34e8:      	tst	w12, #0x1
    34ec:      	ldr	q4, [sp, #0x440]
    34f0:      	str	q4, [sp, #0x980]
    34f4:      	ldr	q4, [sp, #0x450]
    34f8:      	str	q4, [sp, #0x990]
    34fc:      	and	x10, x10, #0x7
    3500:      	add	x12, sp, #0x980
    3504:      	ldr	w10, [x12, x10, lsl #2]
    3508:      	ccmp	w14, #0x0, #0x4, ne
    350c:      	ccmp	w10, #0x5, #0x0, ne
    3510:      	cset	w10, ne
    3514:      	cmp	w11, #0xff
    3518:      	b.ne	0x3520 <ltmp0+0x3520>
    351c:      	tbnz	w10, #0x0, 0x5400 <ltmp0+0x5400>
    3520:      	mvn	w11, w30
    3524:      	rbit	w11, w11
    3528:      	clz	w11, w11
    352c:      	mov	w12, #0xff              ; =255
    3530:      	bics	wzr, w12, w30
    3534:      	csel	w11, wzr, w11, eq
    3538:      	ubfiz	x12, x11, #2, #3
    353c:      	lsl	w13, w16, w11
    3540:      	ldr	q6, [sp, #0x440]
    3544:      	str	q6, [sp, #0x960]
    3548:      	ldr	q4, [sp, #0x450]
    354c:      	str	q4, [sp, #0x970]
    3550:      	add	x15, sp, #0x960
    3554:      	ldr	w15, [x15, x12]
    3558:      	cmp	w10, #0x0
    355c:      	csel	w10, w13, wzr, ne
    3560:      	mov	w13, #0x5               ; =5
    3564:      	csel	w13, w13, w15, ne
    3568:      	str	q6, [sp, #0x940]
    356c:      	str	q4, [sp, #0x950]
    3570:      	add	x15, sp, #0x940
    3574:      	str	w13, [x15, x12]
    3578:      	ldr	q4, [sp, #0x950]
    357c:      	str	q4, [sp, #0x450]
    3580:      	ldr	q4, [sp, #0x940]
    3584:      	str	q4, [sp, #0x440]
    3588:      	ldr	q6, [sp, #0x420]
    358c:      	str	q6, [sp, #0x920]
    3590:      	ldr	q4, [sp, #0x430]
    3594:      	str	q4, [sp, #0x930]
    3598:      	add	x13, sp, #0x920
    359c:      	ldr	w13, [x13, x12]
    35a0:      	csel	w13, w14, w13, ne
    35a4:      	str	q6, [sp, #0x900]
    35a8:      	str	q4, [sp, #0x910]
    35ac:      	add	x15, sp, #0x900
    35b0:      	str	w13, [x15, x12]
    35b4:      	ldrb	w12, [x28, x11]
    35b8:      	and	w13, w12, #0x1
    35bc:      	fmov	s4, w13
    35c0:      	ubfx	w13, w12, #1, #1
    35c4:      	mov.b	v4[1], w13
    35c8:      	ubfx	w13, w12, #2, #1
    35cc:      	mov.b	v4[2], w13
    35d0:      	ubfx	w13, w12, #3, #1
    35d4:      	mov.b	v4[3], w13
    35d8:      	ubfx	w13, w12, #4, #1
    35dc:      	mov.b	v4[4], w13
    35e0:      	ubfx	w13, w12, #5, #1
    35e4:      	mov.b	v4[5], w13
    35e8:      	ubfx	w13, w12, #6, #1
    35ec:      	mov.b	v4[6], w13
    35f0:      	ldr	q6, [sp, #0x910]
    35f4:      	str	q6, [sp, #0x430]
    35f8:      	ldr	q6, [sp, #0x900]
    35fc:      	str	q6, [sp, #0x420]
    3600:      	lsr	w12, w12, #7
    3604:      	mov.b	v4[7], w12
    3608:      	ldrb	w12, [x8, x11]
    360c:      	and	w13, w12, #0x1
    3610:      	fmov	s6, w13
    3614:      	ubfx	w13, w12, #1, #1
    3618:      	mov.b	v6[1], w13
    361c:      	ubfx	w13, w12, #2, #1
    3620:      	mov.b	v6[2], w13
    3624:      	ubfx	w13, w12, #3, #1
    3628:      	mov.b	v6[3], w13
    362c:      	ubfx	w13, w12, #4, #1
    3630:      	mov.b	v6[4], w13
    3634:      	ubfx	w13, w12, #5, #1
    3638:      	mov.b	v6[5], w13
    363c:      	ubfx	w13, w12, #6, #1
    3640:      	mov.b	v6[6], w13
    3644:      	lsr	w12, w12, #7
    3648:      	mov.b	v6[7], w12
    364c:      	csetm	w12, ne
    3650:      	dup.8b	v7, w12
    3654:      	bit.8b	v4, v21, v7
    3658:      	shl.8b	v4, v4, #0x7
    365c:      	cmlt.8b	v4, v4, #0
    3660:      	and.8b	v4, v4, v2
    3664:      	addv.8b	b4, v4
    3668:      	str	b4, [x28, x11]
    366c:      	bic.8b	v4, v6, v7
    3670:      	shl.8b	v4, v4, #0x7
    3674:      	cmlt.8b	v4, v4, #0
    3678:      	and.8b	v4, v4, v2
    367c:      	addv.8b	b4, v4
    3680:      	str	b4, [x8, x11]
    3684:      	csinc	w11, w14, w11, eq
    3688:      	cmp	w24, #0x8
    368c:      	b.hs	0x5400 <ltmp0+0x5400>
    3690:      	str	b1, [x23, x21]
    3694:      	mov	w12, #0x11              ; =17
    3698:      	str	w12, [x25, x21, lsl #2]
    369c:      	str	w11, [x26, x21, lsl #2]
    36a0:      	cmp	w9, #0x8
    36a4:      	b.hs	0x5400 <ltmp0+0x5400>
    36a8:      	str	b3, [x23, w9, uxtw]
    36ac:      	orr	w30, w10, w30
    36b0:      	mov	w10, #0x12              ; =18
    36b4:      	b	0x2bc <ltmp0+0x2bc>
    36b8:      	tst	w10, #0xff
    36bc:      	b.eq	0x3ac8 <ltmp0+0x3ac8>
    36c0:      	tst	w11, #0xff
    36c4:      	b.eq	0x2c8 <ltmp0+0x2c8>
    36c8:      	str	d0, [sp, #0x170]
    36cc:      	stp	q29, q27, [sp, #0x2e0]
    36d0:      	stp	q10, q12, [sp, #0x1f0]
    36d4:      	ldr	q27, [sp, #0x3c0]
    36d8:      	stp	q31, q24, [sp, #0x1d0]
    36dc:      	mov.16b	v16, v28
    36e0:      	str	q14, [sp, #0x300]
    36e4:      	mov.16b	v30, v22
    36e8:      	ldr	q28, [sp, #0x130]
    36ec:      	stp	q5, q18, [sp, #0x2c0]
    36f0:      	ldr	q0, [sp, #0x340]
    36f4:      	mov.16b	v12, v19
    36f8:      	mov.16b	v22, v15
    36fc:      	ldr	q1, [sp, #0x410]
    3700:      	rbit	w10, w11
    3704:      	clz	w10, w10
    3708:      	tst	w11, #0xff
    370c:      	csel	w10, wzr, w10, eq
    3710:      	shl.2d	v4, v18, #0x5
    3714:      	shl.2d	v6, v1, #0x5
    3718:      	mov.16b	v18, v23
    371c:      	shl.2d	v7, v23, #0x5
    3720:      	mov.16b	v14, v16
    3724:      	shl.2d	v16, v16, #0x5
    3728:      	ldr	q1, [sp, #0x1b0]
    372c:      	ldp	q3, q5, [sp, #0x390]
    3730:      	add.2d	v1, v1, v5
    3734:      	add.2d	v25, v1, v4
    3738:      	ldr	q1, [sp, #0x1a0]
    373c:      	add.2d	v1, v1, v3
    3740:      	add.2d	v23, v1, v6
    3744:      	ldr	q1, [sp, #0x190]
    3748:      	ldp	q3, q5, [sp, #0x370]
    374c:      	add.2d	v1, v1, v5
    3750:      	add.2d	v20, v1, v7
    3754:      	ldr	q1, [sp, #0x180]
    3758:      	add.2d	v1, v1, v3
    375c:      	add.2d	v19, v1, v16
    3760:      	shl.8b	v1, v21, #0x7
    3764:      	cmlt.8b	v1, v1, #0
    3768:      	and.8b	v1, v1, v2
    376c:      	addv.8b	b15, v1
    3770:      	fmov	w13, s15
    3774:      	movi.2d	v17, #0000000000000000
    3778:      	movi.2d	v3, #0000000000000000
    377c:      	str	q9, [sp, #0x1c0]
    3780:      	str	q0, [sp, #0x340]
    3784:      	str	q27, [sp, #0x3c0]
    3788:      	tbnz	w13, #0x0, 0x3988 <ltmp0+0x3988>
    378c:      	tbnz	w13, #0x1, 0x3994 <ltmp0+0x3994>
    3790:      	tbnz	w13, #0x2, 0x39a0 <ltmp0+0x39a0>
    3794:      	tbnz	w13, #0x3, 0x39ac <ltmp0+0x39ac>
    3798:      	mov.16b	v10, v26
    379c:      	tbnz	w13, #0x4, 0x39bc <ltmp0+0x39bc>
    37a0:      	mov.16b	v9, v22
    37a4:      	mov.16b	v1, v12
    37a8:      	mov.16b	v26, v27
    37ac:      	tbnz	w13, #0x5, 0x39d4 <ltmp0+0x39d4>
    37b0:      	ldr	d29, [sp, #0x170]
    37b4:      	mov.16b	v22, v30
    37b8:      	tbz	w13, #0x6, 0x37c4 <ltmp0+0x37c4>
    37bc:      	fmov	x15, d19
    37c0:      	ld1.s	{ v3 }[2], [x15]
    37c4:      	ldp	q24, q30, [sp, #0x1e0]
    37c8:      	ldr	q5, [sp, #0x200]
    37cc:      	mov.16b	v20, v14
    37d0:      	ldp	q25, q14, [sp, #0x2f0]
    37d4:      	mov.16b	v27, v20
    37d8:      	mov.16b	v12, v18
    37dc:      	tbz	w13, #0x7, 0x37e8 <ltmp0+0x37e8>
    37e0:      	mov.d	x13, v19[1]
    37e4:      	ld1.s	{ v3 }[3], [x13]
    37e8:      	ldr	q31, [sp, #0x1d0]
    37ec:      	str	q0, [sp, #0xa60]
    37f0:      	str	q28, [sp, #0xa70]
    37f4:      	and	x13, x10, #0x7
    37f8:      	add	x12, sp, #0xa60
    37fc:      	add	x13, x12, x13, lsl #2
    3800:      	ld1r.4s	{ v19 }, [x13]
    3804:      	fdiv.4s	v3, v3, v19
    3808:      	fdiv.4s	v17, v17, v19
    380c:      	ldr	q18, [sp, #0x3b0]
    3810:      	add.2d	v23, v16, v18
    3814:      	add.2d	v7, v7, v10
    3818:      	add.2d	v6, v6, v26
    381c:      	ldr	q16, [sp, #0x3d0]
    3820:      	add.2d	v4, v4, v16
    3824:      	ldr	q16, [sp, #0x230]
    3828:      	add.2d	v20, v16, v4
    382c:      	ldp	q0, q4, [sp, #0x210]
    3830:      	add.2d	v19, v0, v6
    3834:      	add.2d	v16, v4, v7
    3838:      	ldr	q4, [sp, #0x240]
    383c:      	add.2d	v7, v4, v23
    3840:      	fmov	w13, s15
    3844:      	movi.2d	v6, #0000000000000000
    3848:      	movi.2d	v4, #0000000000000000
    384c:      	ldr	q28, [sp, #0x2c0]
    3850:      	tbnz	w13, #0x0, 0x39ec <ltmp0+0x39ec>
    3854:      	ldr	q18, [sp, #0x2d0]
    3858:      	tbnz	w13, #0x1, 0x39fc <ltmp0+0x39fc>
    385c:      	ldr	q20, [sp, #0x2e0]
    3860:      	mov.16b	v23, v12
    3864:      	mov.16b	v12, v5
    3868:      	tbnz	w13, #0x2, 0x3a14 <ltmp0+0x3a14>
    386c:      	mov.16b	v5, v28
    3870:      	mov.16b	v28, v27
    3874:      	tbnz	w13, #0x3, 0x3a28 <ltmp0+0x3a28>
    3878:      	mov.16b	v19, v1
    387c:      	mov.16b	v27, v25
    3880:      	tbnz	w13, #0x4, 0x3a3c <ltmp0+0x3a3c>
    3884:      	mov.16b	v26, v10
    3888:      	tbnz	w13, #0x5, 0x3a4c <ltmp0+0x3a4c>
    388c:      	mov.16b	v10, v30
    3890:      	tbnz	w13, #0x6, 0x3a5c <ltmp0+0x3a5c>
    3894:      	fmov	d0, d29
    3898:      	tbz	w13, #0x7, 0x38a4 <ltmp0+0x38a4>
    389c:      	mov.d	x13, v7[1]
    38a0:      	ld1.s	{ v4 }[3], [x13]
    38a4:      	mov.16b	v29, v20
    38a8:      	fmul.4s	v6, v6, v17
    38ac:      	ldp	q7, q1, [sp, #0x2a0]
    38b0:      	str	q1, [sp, #0xa20]
    38b4:      	str	q7, [sp, #0xa30]
    38b8:      	ldp	q7, q1, [sp, #0x280]
    38bc:      	str	q1, [sp, #0xa40]
    38c0:      	str	q7, [sp, #0xa50]
    38c4:      	ubfiz	x13, x10, #3, #3
    38c8:      	add	x12, sp, #0xa20
    38cc:      	ldr	x15, [x12, x13]
    38d0:      	str	q18, [sp, #0x9e0]
    38d4:      	ldr	q7, [sp, #0x410]
    38d8:      	str	q7, [sp, #0x9f0]
    38dc:      	str	q23, [sp, #0xa00]
    38e0:      	str	q28, [sp, #0xa10]
    38e4:      	add	x12, sp, #0x9e0
    38e8:      	ldr	x0, [x12, x13]
    38ec:      	str	q24, [sp, #0x9a0]
    38f0:      	str	q14, [sp, #0x9b0]
    38f4:      	str	q31, [sp, #0x9c0]
    38f8:      	str	q5, [sp, #0x9d0]
    38fc:      	add	x12, sp, #0x9a0
    3900:      	ldr	x13, [x12, x13]
    3904:      	fmul.4s	v3, v4, v3
    3908:      	sub	x10, x13, x10
    390c:      	mov	w12, #0x602             ; =1538
    3910:      	madd	x10, x15, x12, x10
    3914:      	add	x13, x19, x0, lsl #5
    3918:      	add	x10, x13, x10, lsl #2
    391c:      	fmov	w13, s15
    3920:      	tbnz	w13, #0x0, 0x3a70 <ltmp0+0x3a70>
    3924:      	mov.16b	v15, v9
    3928:      	tbnz	w13, #0x1, 0x3a7c <ltmp0+0x3a7c>
    392c:      	ldr	q9, [sp, #0x1c0]
    3930:      	tbnz	w13, #0x2, 0x3a8c <ltmp0+0x3a8c>
    3934:      	tbnz	w13, #0x3, 0x3a98 <ltmp0+0x3a98>
    3938:      	tbnz	w13, #0x4, 0x3aa4 <ltmp0+0x3aa4>
    393c:      	tbnz	w13, #0x5, 0x3aac <ltmp0+0x3aac>
    3940:      	tbnz	w13, #0x6, 0x3ab8 <ltmp0+0x3ab8>
    3944:      	tbz	w13, #0x7, 0x3950 <ltmp0+0x3950>
    3948:      	add	x10, x10, #0x1c
    394c:      	st1.s	{ v3 }[3], [x10]
    3950:      	movi.8b	v1, #0x1
    3954:      	and.8b	v1, v21, v1
    3958:      	ushll.8h	v1, v1, #0x0
    395c:      	ushll.4s	v3, v1, #0x0
    3960:      	ushll2.4s	v1, v1, #0x0
    3964:      	uaddw2.2d	v28, v28, v1
    3968:      	uaddw.2d	v23, v23, v1
    396c:      	ldr	q1, [sp, #0x410]
    3970:      	uaddw2.2d	v1, v1, v3
    3974:      	str	q1, [sp, #0x410]
    3978:      	uaddw.2d	v18, v18, v3
    397c:      	tst	w11, #0xff
    3980:      	b.ne	0x3434 <ltmp0+0x3434>
    3984:      	b	0x2c8 <ltmp0+0x2c8>
    3988:      	fmov	x15, d25
    398c:      	ldr	s17, [x15]
    3990:      	tbz	w13, #0x1, 0x3790 <ltmp0+0x3790>
    3994:      	mov.d	x15, v25[1]
    3998:      	ld1.s	{ v17 }[1], [x15]
    399c:      	tbz	w13, #0x2, 0x3794 <ltmp0+0x3794>
    39a0:      	fmov	x15, d23
    39a4:      	ld1.s	{ v17 }[2], [x15]
    39a8:      	tbz	w13, #0x3, 0x3798 <ltmp0+0x3798>
    39ac:      	mov.d	x15, v23[1]
    39b0:      	ld1.s	{ v17 }[3], [x15]
    39b4:      	mov.16b	v10, v26
    39b8:      	tbz	w13, #0x4, 0x37a0 <ltmp0+0x37a0>
    39bc:      	fmov	x15, d20
    39c0:      	ld1.s	{ v3 }[0], [x15]
    39c4:      	mov.16b	v9, v22
    39c8:      	mov.16b	v1, v12
    39cc:      	mov.16b	v26, v27
    39d0:      	tbz	w13, #0x5, 0x37b0 <ltmp0+0x37b0>
    39d4:      	mov.d	x15, v20[1]
    39d8:      	ld1.s	{ v3 }[1], [x15]
    39dc:      	ldr	d29, [sp, #0x170]
    39e0:      	mov.16b	v22, v30
    39e4:      	tbnz	w13, #0x6, 0x37bc <ltmp0+0x37bc>
    39e8:      	b	0x37c4 <ltmp0+0x37c4>
    39ec:      	fmov	x15, d20
    39f0:      	ldr	s6, [x15]
    39f4:      	ldr	q18, [sp, #0x2d0]
    39f8:      	tbz	w13, #0x1, 0x385c <ltmp0+0x385c>
    39fc:      	mov.d	x15, v20[1]
    3a00:      	ld1.s	{ v6 }[1], [x15]
    3a04:      	ldr	q20, [sp, #0x2e0]
    3a08:      	mov.16b	v23, v12
    3a0c:      	mov.16b	v12, v5
    3a10:      	tbz	w13, #0x2, 0x386c <ltmp0+0x386c>
    3a14:      	fmov	x15, d19
    3a18:      	ld1.s	{ v6 }[2], [x15]
    3a1c:      	mov.16b	v5, v28
    3a20:      	mov.16b	v28, v27
    3a24:      	tbz	w13, #0x3, 0x3878 <ltmp0+0x3878>
    3a28:      	mov.d	x15, v19[1]
    3a2c:      	ld1.s	{ v6 }[3], [x15]
    3a30:      	mov.16b	v19, v1
    3a34:      	mov.16b	v27, v25
    3a38:      	tbz	w13, #0x4, 0x3884 <ltmp0+0x3884>
    3a3c:      	fmov	x15, d16
    3a40:      	ld1.s	{ v4 }[0], [x15]
    3a44:      	mov.16b	v26, v10
    3a48:      	tbz	w13, #0x5, 0x388c <ltmp0+0x388c>
    3a4c:      	mov.d	x15, v16[1]
    3a50:      	ld1.s	{ v4 }[1], [x15]
    3a54:      	mov.16b	v10, v30
    3a58:      	tbz	w13, #0x6, 0x3894 <ltmp0+0x3894>
    3a5c:      	fmov	x15, d7
    3a60:      	ld1.s	{ v4 }[2], [x15]
    3a64:      	fmov	d0, d29
    3a68:      	tbnz	w13, #0x7, 0x389c <ltmp0+0x389c>
    3a6c:      	b	0x38a4 <ltmp0+0x38a4>
    3a70:      	str	s6, [x10]
    3a74:      	mov.16b	v15, v9
    3a78:      	tbz	w13, #0x1, 0x392c <ltmp0+0x392c>
    3a7c:      	add	x15, x10, #0x4
    3a80:      	st1.s	{ v6 }[1], [x15]
    3a84:      	ldr	q9, [sp, #0x1c0]
    3a88:      	tbz	w13, #0x2, 0x3934 <ltmp0+0x3934>
    3a8c:      	add	x15, x10, #0x8
    3a90:      	st1.s	{ v6 }[2], [x15]
    3a94:      	tbz	w13, #0x3, 0x3938 <ltmp0+0x3938>
    3a98:      	add	x15, x10, #0xc
    3a9c:      	st1.s	{ v6 }[3], [x15]
    3aa0:      	tbz	w13, #0x4, 0x393c <ltmp0+0x393c>
    3aa4:      	str	s3, [x10, #0x10]
    3aa8:      	tbz	w13, #0x5, 0x3940 <ltmp0+0x3940>
    3aac:      	add	x15, x10, #0x14
    3ab0:      	st1.s	{ v3 }[1], [x15]
    3ab4:      	tbz	w13, #0x6, 0x3944 <ltmp0+0x3944>
    3ab8:      	add	x15, x10, #0x18
    3abc:      	st1.s	{ v3 }[2], [x15]
    3ac0:      	tbnz	w13, #0x7, 0x3948 <ltmp0+0x3948>
    3ac4:      	b	0x3950 <ltmp0+0x3950>
    3ac8:      	tst	w11, #0xff
    3acc:      	b.eq	0x2c8 <ltmp0+0x2c8>
    3ad0:      	cbz	w14, 0x3c9c <ltmp0+0x3c9c>
    3ad4:      	mov	w10, #0x0               ; =0
    3ad8:      	shl.8b	v1, v21, #0x7
    3adc:      	cmlt.8b	v1, v1, #0
    3ae0:      	and.8b	v3, v1, v2
    3ae4:      	addv.8b	b3, v3
    3ae8:      	fmov	w11, s3
    3aec:      	umaxv.8b	b1, v1
    3af0:      	fmov	w12, s1
    3af4:      	sub	w13, w14, #0x1
    3af8:      	tst	w11, #0xff
    3afc:      	csel	w13, w13, wzr, ne
    3b00:      	lsl	w15, w16, w13
    3b04:      	and	w11, w15, w30
    3b08:      	tst	w11, #0xff
    3b0c:      	cset	w17, ne
    3b10:      	ldr	q1, [sp, #0x440]
    3b14:      	str	q1, [sp, #0xcb0]
    3b18:      	ldr	q1, [sp, #0x450]
    3b1c:      	str	q1, [sp, #0xcc0]
    3b20:      	ubfiz	x11, x13, #2, #3
    3b24:      	add	x0, sp, #0xcb0
    3b28:      	ldr	w0, [x0, x11]
    3b2c:      	cmp	w0, #0x5
    3b30:      	cset	w0, eq
    3b34:      	and	w2, w17, w12
    3b38:      	ldrb	w12, [x28, w13, sxtw]
    3b3c:      	and	w17, w12, #0x1
    3b40:      	fmov	s1, w17
    3b44:      	ubfx	w17, w12, #1, #1
    3b48:      	mov.b	v1[1], w17
    3b4c:      	ubfx	w17, w12, #2, #1
    3b50:      	mov.b	v1[2], w17
    3b54:      	ubfx	w17, w12, #3, #1
    3b58:      	mov.b	v1[3], w17
    3b5c:      	ubfx	w17, w12, #4, #1
    3b60:      	mov.b	v1[4], w17
    3b64:      	ubfx	w17, w12, #5, #1
    3b68:      	mov.b	v1[5], w17
    3b6c:      	ubfx	w17, w12, #6, #1
    3b70:      	mov.b	v1[6], w17
    3b74:      	lsr	w12, w12, #7
    3b78:      	mov.b	v1[7], w12
    3b7c:      	ldrb	w12, [x8, w13, sxtw]
    3b80:      	and	w17, w12, #0x1
    3b84:      	fmov	s3, w17
    3b88:      	ubfx	w17, w12, #1, #1
    3b8c:      	mov.b	v3[1], w17
    3b90:      	ubfx	w17, w12, #2, #1
    3b94:      	mov.b	v3[2], w17
    3b98:      	ubfx	w17, w12, #3, #1
    3b9c:      	mov.b	v3[3], w17
    3ba0:      	ubfx	w17, w12, #4, #1
    3ba4:      	mov.b	v3[4], w17
    3ba8:      	ubfx	w17, w12, #5, #1
    3bac:      	mov.b	v3[5], w17
    3bb0:      	ubfx	w17, w12, #6, #1
    3bb4:      	mov.b	v3[6], w17
    3bb8:      	lsr	w12, w12, #7
    3bbc:      	mov.b	v3[7], w12
    3bc0:      	orr.8b	v4, v21, v3
    3bc4:      	and.8b	v6, v0, v1
    3bc8:      	eor.8b	v6, v6, v4
    3bcc:      	shl.8b	v6, v6, #0x7
    3bd0:      	cmlt.8b	v6, v6, #0
    3bd4:      	umaxv.8b	b6, v6
    3bd8:      	fmov	w12, s6
    3bdc:      	ands	w17, w2, w0
    3be0:      	csetm	w0, ne
    3be4:      	bics	w12, w17, w12
    3be8:      	csetm	w1, ne
    3bec:      	dup.8b	v6, w1
    3bf0:      	dup.8b	v7, w0
    3bf4:      	bic.8b	v16, v4, v6
    3bf8:      	bit.8b	v3, v16, v7
    3bfc:      	shl.8b	v3, v3, #0x7
    3c00:      	cmlt.8b	v3, v3, #0
    3c04:      	and.8b	v3, v3, v2
    3c08:      	addv.8b	b3, v3
    3c0c:      	str	b3, [x8, w13, sxtw]
    3c10:      	bic.8b	v1, v1, v6
    3c14:      	shl.8b	v1, v1, #0x7
    3c18:      	cmlt.8b	v1, v1, #0
    3c1c:      	and.8b	v1, v1, v2
    3c20:      	addv.8b	b1, v1
    3c24:      	str	b1, [x28, w13, sxtw]
    3c28:      	csinv	w13, w4, w15, eq
    3c2c:      	dup.8b	v1, w17
    3c30:      	and	w30, w13, w30
    3c34:      	shl.8b	v1, v1, #0x7
    3c38:      	cmlt.8b	v1, v1, #0
    3c3c:      	dup.8b	v3, w12
    3c40:      	and.8b	v3, v3, v4
    3c44:      	ldr	q4, [sp, #0x420]
    3c48:      	str	q4, [sp, #0xc90]
    3c4c:      	ldr	q4, [sp, #0x430]
    3c50:      	str	q4, [sp, #0xca0]
    3c54:      	add	x12, sp, #0xc90
    3c58:      	ldr	w11, [x12, x11]
    3c5c:      	csel	w14, w11, w14, ne
    3c60:      	bit.8b	v21, v3, v1
    3c64:      	shl.8b	v1, v21, #0x7
    3c68:      	cmlt.8b	v1, v1, #0
    3c6c:      	and.8b	v1, v1, v2
    3c70:      	addv.8b	b1, v1
    3c74:      	fmov	w11, s1
    3c78:      	cmp	w17, #0x1
    3c7c:      	b.ne	0x3cb0 <ltmp0+0x3cb0>
    3c80:      	cmp	w14, #0x0
    3c84:      	ccmp	w10, #0x6, #0x2, ne
    3c88:      	b.hi	0x3cb0 <ltmp0+0x3cb0>
    3c8c:      	add	w10, w10, #0x1
    3c90:      	tst	w11, #0xff
    3c94:      	b.ne	0x3ad8 <ltmp0+0x3ad8>
    3c98:      	b	0x3cb0 <ltmp0+0x3cb0>
    3c9c:      	shl.8b	v1, v21, #0x7
    3ca0:      	cmlt.8b	v1, v1, #0
    3ca4:      	and.8b	v1, v1, v2
    3ca8:      	addv.8b	b1, v1
    3cac:      	fmov	w11, s1
    3cb0:      	tst	w11, #0xff
    3cb4:      	b.eq	0x3420 <ltmp0+0x3420>
    3cb8:      	and.8b	v1, v11, v21
    3cbc:      	shl.8b	v1, v1, #0x7
    3cc0:      	cmlt.8b	v3, v1, #0
    3cc4:      	and.8b	v1, v3, v2
    3cc8:      	addv.8b	b1, v1
    3ccc:      	umaxv.8b	b3, v3
    3cd0:      	fmov	w10, s3
    3cd4:      	add	x17, sp, #0x1, lsl #12  ; =0x1000
    3cd8:      	add	x17, x17, #0x160
    3cdc:      	add	x1, sp, #0x1, lsl #12   ; =0x1000
    3ce0:      	add	x1, x1, #0x140
    3ce4:      	tbz	w10, #0x0, 0x3ee8 <ltmp0+0x3ee8>
    3ce8:      	bic.8b	v3, v21, v11
    3cec:      	shl.8b	v3, v3, #0x7
    3cf0:      	cmlt.8b	v3, v3, #0
    3cf4:      	and.8b	v3, v3, v2
    3cf8:      	addv.8b	b3, v3
    3cfc:      	fmov	w10, s3
    3d00:      	tst	w10, #0xff
    3d04:      	b.eq	0x3ee8 <ltmp0+0x3ee8>
    3d08:      	subs	w10, w14, #0x1
    3d0c:      	csel	w10, wzr, w10, lo
    3d10:      	and	w11, w30, #0xff
    3d14:      	lsr	w12, w11, w10
    3d18:      	tst	w12, #0x1
    3d1c:      	ldr	q4, [sp, #0x440]
    3d20:      	str	q4, [sp, #0xb00]
    3d24:      	ldr	q4, [sp, #0x450]
    3d28:      	str	q4, [sp, #0xb10]
    3d2c:      	and	x10, x10, #0x7
    3d30:      	add	x12, sp, #0xb00
    3d34:      	ldr	w10, [x12, x10, lsl #2]
    3d38:      	ccmp	w14, #0x0, #0x4, ne
    3d3c:      	ccmp	w10, #0x6, #0x0, ne
    3d40:      	cset	w10, ne
    3d44:      	cmp	w11, #0xff
    3d48:      	b.ne	0x3d50 <ltmp0+0x3d50>
    3d4c:      	tbnz	w10, #0x0, 0x5400 <ltmp0+0x5400>
    3d50:      	mvn	w11, w30
    3d54:      	rbit	w11, w11
    3d58:      	clz	w11, w11
    3d5c:      	mov	w12, #0xff              ; =255
    3d60:      	bics	wzr, w12, w30
    3d64:      	csel	w11, wzr, w11, eq
    3d68:      	ubfiz	x12, x11, #2, #3
    3d6c:      	lsl	w13, w16, w11
    3d70:      	ldr	q6, [sp, #0x440]
    3d74:      	str	q6, [sp, #0xae0]
    3d78:      	ldr	q4, [sp, #0x450]
    3d7c:      	str	q4, [sp, #0xaf0]
    3d80:      	add	x15, sp, #0xae0
    3d84:      	ldr	w15, [x15, x12]
    3d88:      	cmp	w10, #0x0
    3d8c:      	csel	w10, w13, wzr, ne
    3d90:      	mov	w13, #0x6               ; =6
    3d94:      	csel	w13, w13, w15, ne
    3d98:      	str	q6, [sp, #0xac0]
    3d9c:      	str	q4, [sp, #0xad0]
    3da0:      	add	x15, sp, #0xac0
    3da4:      	str	w13, [x15, x12]
    3da8:      	ldr	q4, [sp, #0xad0]
    3dac:      	str	q4, [sp, #0x450]
    3db0:      	ldr	q4, [sp, #0xac0]
    3db4:      	str	q4, [sp, #0x440]
    3db8:      	ldr	q6, [sp, #0x420]
    3dbc:      	str	q6, [sp, #0xaa0]
    3dc0:      	ldr	q4, [sp, #0x430]
    3dc4:      	str	q4, [sp, #0xab0]
    3dc8:      	add	x13, sp, #0xaa0
    3dcc:      	ldr	w13, [x13, x12]
    3dd0:      	csel	w13, w14, w13, ne
    3dd4:      	str	q6, [sp, #0xa80]
    3dd8:      	str	q4, [sp, #0xa90]
    3ddc:      	add	x15, sp, #0xa80
    3de0:      	str	w13, [x15, x12]
    3de4:      	ldrb	w12, [x28, x11]
    3de8:      	and	w13, w12, #0x1
    3dec:      	fmov	s4, w13
    3df0:      	ubfx	w13, w12, #1, #1
    3df4:      	mov.b	v4[1], w13
    3df8:      	ubfx	w13, w12, #2, #1
    3dfc:      	mov.b	v4[2], w13
    3e00:      	ubfx	w13, w12, #3, #1
    3e04:      	mov.b	v4[3], w13
    3e08:      	ubfx	w13, w12, #4, #1
    3e0c:      	mov.b	v4[4], w13
    3e10:      	ubfx	w13, w12, #5, #1
    3e14:      	mov.b	v4[5], w13
    3e18:      	ubfx	w13, w12, #6, #1
    3e1c:      	mov.b	v4[6], w13
    3e20:      	ldr	q6, [sp, #0xa90]
    3e24:      	str	q6, [sp, #0x430]
    3e28:      	ldr	q6, [sp, #0xa80]
    3e2c:      	str	q6, [sp, #0x420]
    3e30:      	lsr	w12, w12, #7
    3e34:      	mov.b	v4[7], w12
    3e38:      	ldrb	w12, [x8, x11]
    3e3c:      	and	w13, w12, #0x1
    3e40:      	fmov	s6, w13
    3e44:      	ubfx	w13, w12, #1, #1
    3e48:      	mov.b	v6[1], w13
    3e4c:      	ubfx	w13, w12, #2, #1
    3e50:      	mov.b	v6[2], w13
    3e54:      	ubfx	w13, w12, #3, #1
    3e58:      	mov.b	v6[3], w13
    3e5c:      	ubfx	w13, w12, #4, #1
    3e60:      	mov.b	v6[4], w13
    3e64:      	ubfx	w13, w12, #5, #1
    3e68:      	mov.b	v6[5], w13
    3e6c:      	ubfx	w13, w12, #6, #1
    3e70:      	mov.b	v6[6], w13
    3e74:      	lsr	w12, w12, #7
    3e78:      	mov.b	v6[7], w12
    3e7c:      	csetm	w12, ne
    3e80:      	dup.8b	v7, w12
    3e84:      	bit.8b	v4, v21, v7
    3e88:      	shl.8b	v4, v4, #0x7
    3e8c:      	cmlt.8b	v4, v4, #0
    3e90:      	and.8b	v4, v4, v2
    3e94:      	addv.8b	b4, v4
    3e98:      	str	b4, [x28, x11]
    3e9c:      	bic.8b	v4, v6, v7
    3ea0:      	shl.8b	v4, v4, #0x7
    3ea4:      	cmlt.8b	v4, v4, #0
    3ea8:      	and.8b	v4, v4, v2
    3eac:      	addv.8b	b4, v4
    3eb0:      	str	b4, [x8, x11]
    3eb4:      	csinc	w11, w14, w11, eq
    3eb8:      	cmp	w24, #0x8
    3ebc:      	b.hs	0x5400 <ltmp0+0x5400>
    3ec0:      	str	b1, [x23, x21]
    3ec4:      	mov	w12, #0x13              ; =19
    3ec8:      	str	w12, [x25, x21, lsl #2]
    3ecc:      	str	w11, [x26, x21, lsl #2]
    3ed0:      	cmp	w9, #0x8
    3ed4:      	b.hs	0x5400 <ltmp0+0x5400>
    3ed8:      	str	b3, [x23, w9, uxtw]
    3edc:      	orr	w30, w10, w30
    3ee0:      	mov	w10, #0x14              ; =20
    3ee4:      	b	0x2bc <ltmp0+0x2bc>
    3ee8:      	fmov	w10, s1
    3eec:      	tst	w10, #0xff
    3ef0:      	b.eq	0x40d4 <ltmp0+0x40d4>
    3ef4:      	rbit	w10, w11
    3ef8:      	clz	w10, w10
    3efc:      	tst	w11, #0xff
    3f00:      	csel	w13, wzr, w10, eq
    3f04:      	mov	w3, #0x1800             ; =6144
    3f08:      	sub	x15, x3, w13, uxtw #2
    3f0c:      	tst	w11, #0xff
    3f10:      	ldp	q1, q3, [sp, #0x390]
    3f14:      	str	q3, [sp, #0xc50]
    3f18:      	str	q1, [sp, #0xc60]
    3f1c:      	ldp	q1, q3, [sp, #0x370]
    3f20:      	str	q3, [sp, #0xc70]
    3f24:      	str	q1, [sp, #0xc80]
    3f28:      	and	x0, x13, #0x7
    3f2c:      	add	x10, sp, #0xc30
    3f30:      	add	x2, x10, x0, lsl #2
    3f34:      	add	x10, sp, #0xc50
    3f38:      	ldr	x10, [x10, x0, lsl #3]
    3f3c:      	add	x10, x15, x10
    3f40:      	csel	x10, xzr, x10, eq
    3f44:      	add	x10, x20, x10
    3f48:      	ldp	q3, q1, [x10]
    3f4c:      	zip1.8b	v4, v21, v0
    3f50:      	ushll.4s	v4, v4, #0x0
    3f54:      	shl.4s	v4, v4, #0x1f
    3f58:      	cmlt.4s	v6, v4, #0
    3f5c:      	and.16b	v4, v6, v3
    3f60:      	shl.8b	v3, v21, #0x7
    3f64:      	cmlt.8b	v3, v3, #0
    3f68:      	and.8b	v3, v3, v2
    3f6c:      	addv.8b	b3, v3
    3f70:      	fmov	w10, s3
    3f74:      	ldr	q3, [sp, #0x340]
    3f78:      	str	q3, [sp, #0xc30]
    3f7c:      	ldr	q3, [sp, #0x130]
    3f80:      	str	q3, [sp, #0xc40]
    3f84:      	ld1r.4s	{ v3 }, [x2]
    3f88:      	ldr	q7, [sp, #0x3d0]
    3f8c:      	str	q7, [sp, #0xbf0]
    3f90:      	ldr	q7, [sp, #0x3c0]
    3f94:      	str	q7, [sp, #0xc00]
    3f98:      	str	q26, [sp, #0xc10]
    3f9c:      	ldr	q7, [sp, #0x3b0]
    3fa0:      	str	q7, [sp, #0xc20]
    3fa4:      	add	x12, sp, #0xbf0
    3fa8:      	ldr	x2, [x12, x0, lsl #3]
    3fac:      	fdiv.4s	v7, v4, v3
    3fb0:      	add	x15, x15, x2
    3fb4:      	csel	x15, xzr, x15, eq
    3fb8:      	add	x12, sp, #0x1, lsl #12  ; =0x1000
    3fbc:      	add	x12, x12, #0x288
    3fc0:      	add	x15, x12, x15
    3fc4:      	ldp	q16, q4, [x15]
    3fc8:      	and.16b	v6, v6, v16
    3fcc:      	fmul.4s	v6, v7, v6
    3fd0:      	ldr	q7, [sp, #0x2b0]
    3fd4:      	str	q7, [sp, #0xbb0]
    3fd8:      	ldr	q7, [sp, #0x2a0]
    3fdc:      	str	q7, [sp, #0xbc0]
    3fe0:      	ldr	q7, [sp, #0x290]
    3fe4:      	str	q7, [sp, #0xbd0]
    3fe8:      	ldr	q7, [sp, #0x280]
    3fec:      	str	q7, [sp, #0xbe0]
    3ff0:      	add	x12, sp, #0xbb0
    3ff4:      	ldr	x15, [x12, x0, lsl #3]
    3ff8:      	str	q24, [sp, #0xb70]
    3ffc:      	str	q14, [sp, #0xb80]
    4000:      	str	q31, [sp, #0xb90]
    4004:      	str	q5, [sp, #0xba0]
    4008:      	add	x12, sp, #0xb70
    400c:      	ldr	x0, [x12, x0, lsl #3]
    4010:      	sub	x13, x0, x13
    4014:      	mov	w12, #0x602             ; =1538
    4018:      	madd	x13, x15, x12, x13
    401c:      	add	x13, x19, x13, lsl #2
    4020:      	add	x13, x13, x3
    4024:      	tbnz	w10, #0x0, 0x407c <ltmp0+0x407c>
    4028:      	tbnz	w10, #0x1, 0x4084 <ltmp0+0x4084>
    402c:      	add	x3, sp, #0xdd0
    4030:      	tbnz	w10, #0x2, 0x4094 <ltmp0+0x4094>
    4034:      	tbz	w10, #0x3, 0x4040 <ltmp0+0x4040>
    4038:      	add	x15, x13, #0xc
    403c:      	st1.s	{ v6 }[3], [x15]
    4040:      	zip2.8b	v6, v21, v0
    4044:      	ushll.4s	v6, v6, #0x0
    4048:      	shl.4s	v6, v6, #0x1f
    404c:      	cmlt.4s	v6, v6, #0
    4050:      	and.16b	v1, v6, v1
    4054:      	fdiv.4s	v1, v1, v3
    4058:      	and.16b	v3, v6, v4
    405c:      	fmul.4s	v1, v1, v3
    4060:      	tbnz	w10, #0x4, 0x40a4 <ltmp0+0x40a4>
    4064:      	tbnz	w10, #0x5, 0x40ac <ltmp0+0x40ac>
    4068:      	tbnz	w10, #0x6, 0x40b8 <ltmp0+0x40b8>
    406c:      	tbnz	w10, #0x7, 0x40c4 <ltmp0+0x40c4>
    4070:      	tst	w11, #0xff
    4074:      	b.ne	0x40d4 <ltmp0+0x40d4>
    4078:      	b	0x2c8 <ltmp0+0x2c8>
    407c:      	str	s6, [x13]
    4080:      	tbz	w10, #0x1, 0x402c <ltmp0+0x402c>
    4084:      	add	x15, x13, #0x4
    4088:      	st1.s	{ v6 }[1], [x15]
    408c:      	add	x3, sp, #0xdd0
    4090:      	tbz	w10, #0x2, 0x4034 <ltmp0+0x4034>
    4094:      	add	x15, x13, #0x8
    4098:      	st1.s	{ v6 }[2], [x15]
    409c:      	tbnz	w10, #0x3, 0x4038 <ltmp0+0x4038>
    40a0:      	b	0x4040 <ltmp0+0x4040>
    40a4:      	str	s1, [x13, #0x10]
    40a8:      	tbz	w10, #0x5, 0x4068 <ltmp0+0x4068>
    40ac:      	add	x15, x13, #0x14
    40b0:      	st1.s	{ v1 }[1], [x15]
    40b4:      	tbz	w10, #0x6, 0x406c <ltmp0+0x406c>
    40b8:      	add	x15, x13, #0x18
    40bc:      	st1.s	{ v1 }[2], [x15]
    40c0:      	tbz	w10, #0x7, 0x4070 <ltmp0+0x4070>
    40c4:      	add	x10, x13, #0x1c
    40c8:      	st1.s	{ v1 }[3], [x10]
    40cc:      	tst	w11, #0xff
    40d0:      	b.eq	0x2c8 <ltmp0+0x2c8>
    40d4:      	cbz	w14, 0x42a0 <ltmp0+0x42a0>
    40d8:      	mov	w10, #0x0               ; =0
    40dc:      	shl.8b	v1, v21, #0x7
    40e0:      	cmlt.8b	v1, v1, #0
    40e4:      	and.8b	v3, v1, v2
    40e8:      	addv.8b	b3, v3
    40ec:      	fmov	w11, s3
    40f0:      	umaxv.8b	b1, v1
    40f4:      	fmov	w12, s1
    40f8:      	sub	w13, w14, #0x1
    40fc:      	tst	w11, #0xff
    4100:      	csel	w13, w13, wzr, ne
    4104:      	lsl	w15, w16, w13
    4108:      	and	w11, w15, w30
    410c:      	tst	w11, #0xff
    4110:      	cset	w17, ne
    4114:      	ldr	q1, [sp, #0x440]
    4118:      	str	q1, [sp, #0xb50]
    411c:      	ldr	q1, [sp, #0x450]
    4120:      	str	q1, [sp, #0xb60]
    4124:      	ubfiz	x11, x13, #2, #3
    4128:      	add	x0, sp, #0xb50
    412c:      	ldr	w0, [x0, x11]
    4130:      	cmp	w0, #0x6
    4134:      	cset	w0, eq
    4138:      	and	w2, w17, w12
    413c:      	ldrb	w12, [x28, w13, sxtw]
    4140:      	and	w17, w12, #0x1
    4144:      	fmov	s1, w17
    4148:      	ubfx	w17, w12, #1, #1
    414c:      	mov.b	v1[1], w17
    4150:      	ubfx	w17, w12, #2, #1
    4154:      	mov.b	v1[2], w17
    4158:      	ubfx	w17, w12, #3, #1
    415c:      	mov.b	v1[3], w17
    4160:      	ubfx	w17, w12, #4, #1
    4164:      	mov.b	v1[4], w17
    4168:      	ubfx	w17, w12, #5, #1
    416c:      	mov.b	v1[5], w17
    4170:      	ubfx	w17, w12, #6, #1
    4174:      	mov.b	v1[6], w17
    4178:      	lsr	w12, w12, #7
    417c:      	mov.b	v1[7], w12
    4180:      	ldrb	w12, [x8, w13, sxtw]
    4184:      	and	w17, w12, #0x1
    4188:      	fmov	s3, w17
    418c:      	ubfx	w17, w12, #1, #1
    4190:      	mov.b	v3[1], w17
    4194:      	ubfx	w17, w12, #2, #1
    4198:      	mov.b	v3[2], w17
    419c:      	ubfx	w17, w12, #3, #1
    41a0:      	mov.b	v3[3], w17
    41a4:      	ubfx	w17, w12, #4, #1
    41a8:      	mov.b	v3[4], w17
    41ac:      	ubfx	w17, w12, #5, #1
    41b0:      	mov.b	v3[5], w17
    41b4:      	ubfx	w17, w12, #6, #1
    41b8:      	mov.b	v3[6], w17
    41bc:      	lsr	w12, w12, #7
    41c0:      	mov.b	v3[7], w12
    41c4:      	orr.8b	v4, v21, v3
    41c8:      	and.8b	v6, v0, v1
    41cc:      	eor.8b	v6, v6, v4
    41d0:      	shl.8b	v6, v6, #0x7
    41d4:      	cmlt.8b	v6, v6, #0
    41d8:      	umaxv.8b	b6, v6
    41dc:      	fmov	w12, s6
    41e0:      	ands	w17, w2, w0
    41e4:      	csetm	w0, ne
    41e8:      	bics	w12, w17, w12
    41ec:      	csetm	w1, ne
    41f0:      	dup.8b	v6, w1
    41f4:      	dup.8b	v7, w0
    41f8:      	bic.8b	v16, v4, v6
    41fc:      	bit.8b	v3, v16, v7
    4200:      	shl.8b	v3, v3, #0x7
    4204:      	cmlt.8b	v3, v3, #0
    4208:      	and.8b	v3, v3, v2
    420c:      	addv.8b	b3, v3
    4210:      	str	b3, [x8, w13, sxtw]
    4214:      	bic.8b	v1, v1, v6
    4218:      	shl.8b	v1, v1, #0x7
    421c:      	cmlt.8b	v1, v1, #0
    4220:      	and.8b	v1, v1, v2
    4224:      	addv.8b	b1, v1
    4228:      	str	b1, [x28, w13, sxtw]
    422c:      	csinv	w13, w4, w15, eq
    4230:      	dup.8b	v1, w17
    4234:      	and	w30, w13, w30
    4238:      	shl.8b	v1, v1, #0x7
    423c:      	cmlt.8b	v1, v1, #0
    4240:      	dup.8b	v3, w12
    4244:      	and.8b	v3, v3, v4
    4248:      	ldr	q4, [sp, #0x420]
    424c:      	str	q4, [sp, #0xb30]
    4250:      	ldr	q4, [sp, #0x430]
    4254:      	str	q4, [sp, #0xb40]
    4258:      	add	x12, sp, #0xb30
    425c:      	ldr	w11, [x12, x11]
    4260:      	csel	w14, w11, w14, ne
    4264:      	bit.8b	v21, v3, v1
    4268:      	shl.8b	v1, v21, #0x7
    426c:      	cmlt.8b	v1, v1, #0
    4270:      	and.8b	v1, v1, v2
    4274:      	addv.8b	b1, v1
    4278:      	fmov	w11, s1
    427c:      	cmp	w17, #0x1
    4280:      	b.ne	0x42b4 <ltmp0+0x42b4>
    4284:      	cmp	w14, #0x0
    4288:      	ccmp	w10, #0x6, #0x2, ne
    428c:      	b.hi	0x42b4 <ltmp0+0x42b4>
    4290:      	add	w10, w10, #0x1
    4294:      	tst	w11, #0xff
    4298:      	b.ne	0x40dc <ltmp0+0x40dc>
    429c:      	b	0x42b4 <ltmp0+0x42b4>
    42a0:      	shl.8b	v1, v21, #0x7
    42a4:      	cmlt.8b	v1, v1, #0
    42a8:      	and.8b	v1, v1, v2
    42ac:      	addv.8b	b1, v1
    42b0:      	fmov	w11, s1
    42b4:      	tst	w11, #0xff
    42b8:      	b.eq	0x3420 <ltmp0+0x3420>
    42bc:      	bic.8b	v0, v0, v21
    42c0:      	tst	w30, #0xff
    42c4:      	add	x17, sp, #0x1, lsl #12  ; =0x1000
    42c8:      	add	x17, x17, #0x160
    42cc:      	add	x1, sp, #0x1, lsl #12   ; =0x1000
    42d0:      	add	x1, x1, #0x140
    42d4:      	b.eq	0x53b0 <ltmp0+0x53b0>
    42d8:      	ldrb	w10, [x8, #0x8]
    42dc:      	and	w11, w10, #0x1
    42e0:      	fmov	s1, w11
    42e4:      	ubfx	w11, w10, #1, #1
    42e8:      	mov.b	v1[1], w11
    42ec:      	ubfx	w11, w10, #2, #1
    42f0:      	mov.b	v1[2], w11
    42f4:      	ubfx	w11, w10, #3, #1
    42f8:      	mov.b	v1[3], w11
    42fc:      	ubfx	w11, w10, #4, #1
    4300:      	mov.b	v1[4], w11
    4304:      	ubfx	w11, w10, #5, #1
    4308:      	mov.b	v1[5], w11
    430c:      	ubfx	w11, w10, #6, #1
    4310:      	mov.b	v1[6], w11
    4314:      	lsr	w10, w10, #7
    4318:      	mov.b	v1[7], w10
    431c:      	ldrb	w10, [x8]
    4320:      	and	w11, w10, #0x1
    4324:      	fmov	s6, w11
    4328:      	ubfx	w11, w10, #1, #1
    432c:      	mov.b	v6[1], w11
    4330:      	ubfx	w11, w10, #2, #1
    4334:      	mov.b	v6[2], w11
    4338:      	ubfx	w11, w10, #3, #1
    433c:      	mov.b	v6[3], w11
    4340:      	ubfx	w11, w10, #4, #1
    4344:      	mov.b	v6[4], w11
    4348:      	ubfx	w11, w10, #5, #1
    434c:      	mov.b	v6[5], w11
    4350:      	ubfx	w11, w10, #6, #1
    4354:      	mov.b	v6[6], w11
    4358:      	lsr	w10, w10, #7
    435c:      	mov.b	v6[7], w10
    4360:      	and.8b	v7, v0, v1
    4364:      	eor.8b	v1, v6, v7
    4368:      	shl.8b	v1, v1, #0x7
    436c:      	cmlt.8b	v3, v1, #0
    4370:      	umaxv.8b	b1, v3
    4374:      	fmov	w10, s1
    4378:      	eor	w10, w10, #0x1
    437c:      	and	w11, w30, w10
    4380:      	dup.8b	v1, w11
    4384:      	and.8b	v1, v1, v6
    4388:      	shl.8b	v4, v1, #0x7
    438c:      	cmlt.8b	v4, v4, #0
    4390:      	and.8b	v4, v4, v2
    4394:      	addv.8b	b4, v4
    4398:      	fmov	w10, s4
    439c:      	tst	w11, #0x1
    43a0:      	csetm	w11, ne
    43a4:      	dup.8b	v16, w11
    43a8:      	bic.8b	v7, v7, v16
    43ac:      	shl.8b	v7, v7, #0x7
    43b0:      	cmlt.8b	v7, v7, #0
    43b4:      	and.8b	v7, v7, v2
    43b8:      	addv.8b	b7, v7
    43bc:      	str	b7, [x8, #0x8]
    43c0:      	bic.8b	v6, v6, v16
    43c4:      	shl.8b	v6, v6, #0x7
    43c8:      	cmlt.8b	v6, v6, #0
    43cc:      	and.8b	v6, v6, v2
    43d0:      	addv.8b	b6, v6
    43d4:      	str	b6, [x8]
    43d8:      	cmp	w24, #0x8
    43dc:      	b.lo	0x43e8 <ltmp0+0x43e8>
    43e0:      	tst	w10, #0xff
    43e4:      	b.ne	0x5400 <ltmp0+0x5400>
    43e8:      	and.8b	v3, v3, v2
    43ec:      	addv.8b	b3, v3
    43f0:      	fmov	w11, s3
    43f4:      	ldr	d3, [sp, #0x48]
    43f8:      	cmeq.8b	v3, v4, v3
    43fc:      	mvn.8b	v3, v3
    4400:      	umov.b	w12, v3[0]
    4404:      	sbfx	w13, w12, #0, #1
    4408:      	fmov	s3, w13
    440c:      	sbfx	w13, w12, #1, #1
    4410:      	mov.b	v3[1], w13
    4414:      	sbfx	w13, w12, #2, #1
    4418:      	mov.b	v3[2], w13
    441c:      	sbfx	w13, w12, #3, #1
    4420:      	mov.b	v3[3], w13
    4424:      	sbfx	w13, w12, #4, #1
    4428:      	mov.b	v3[4], w13
    442c:      	sbfx	w13, w12, #5, #1
    4430:      	mov.b	v3[5], w13
    4434:      	sbfx	w13, w12, #6, #1
    4438:      	mov.b	v3[6], w13
    443c:      	sbfx	w12, w12, #7, #1
    4440:      	mov.b	v3[7], w12
    4444:      	and	w12, w30, #0xfffffffe
    4448:      	tst	w11, #0xff
    444c:      	csel	w11, w12, w30, eq
    4450:      	tst	w10, #0xff
    4454:      	csel	x10, x21, xzr, ne
    4458:      	ldrb	w12, [x23, x10]
    445c:      	and	w13, w12, #0x1
    4460:      	fmov	s4, w13
    4464:      	ubfx	w13, w12, #1, #1
    4468:      	mov.b	v4[1], w13
    446c:      	ubfx	w13, w12, #2, #1
    4470:      	mov.b	v4[2], w13
    4474:      	ubfx	w13, w12, #3, #1
    4478:      	mov.b	v4[3], w13
    447c:      	ubfx	w13, w12, #4, #1
    4480:      	mov.b	v4[4], w13
    4484:      	ubfx	w13, w12, #5, #1
    4488:      	mov.b	v4[5], w13
    448c:      	ubfx	w13, w12, #6, #1
    4490:      	mov.b	v4[6], w13
    4494:      	lsr	w12, w12, #7
    4498:      	mov.b	v4[7], w12
    449c:      	bif.8b	v1, v4, v3
    44a0:      	ldr	q3, [sp, #0x440]
    44a4:      	fmov	w12, s3
    44a8:      	adrp	x15, 0x4000 <ltmp0+0x4000>
    44ac:      	add	x15, x15, #0x0
    44b0:      	add	x12, x15, w12, sxtw #2
    44b4:      	ldr	q3, [sp, #0x420]
    44b8:      	fmov	w13, s3
    44bc:      	shl.8b	v1, v1, #0x7
    44c0:      	cmlt.8b	v1, v1, #0
    44c4:      	and.8b	v1, v1, v2
    44c8:      	addv.8b	b1, v1
    44cc:      	str	b1, [x23, x10]
    44d0:      	lsl	x10, x10, #2
    44d4:      	add	x14, x25, x10
    44d8:      	csel	x12, x12, x14, ne
    44dc:      	ldr	w12, [x12]
    44e0:      	str	w12, [x14]
    44e4:      	ldr	w12, [x26, x10]
    44e8:      	csel	w12, w13, w12, ne
    44ec:      	str	w12, [x26, x10]
    44f0:      	csel	w10, w9, w24, ne
    44f4:      	and	w9, w11, #0x2
    44f8:      	ldrb	w12, [x8, #0x9]
    44fc:      	and	w13, w12, #0x1
    4500:      	fmov	s1, w13
    4504:      	ubfx	w13, w12, #1, #1
    4508:      	mov.b	v1[1], w13
    450c:      	ubfx	w13, w12, #2, #1
    4510:      	mov.b	v1[2], w13
    4514:      	ubfx	w13, w12, #3, #1
    4518:      	mov.b	v1[3], w13
    451c:      	ubfx	w13, w12, #4, #1
    4520:      	mov.b	v1[4], w13
    4524:      	ubfx	w13, w12, #5, #1
    4528:      	mov.b	v1[5], w13
    452c:      	ubfx	w13, w12, #6, #1
    4530:      	mov.b	v1[6], w13
    4534:      	lsr	w12, w12, #7
    4538:      	mov.b	v1[7], w12
    453c:      	ldrb	w12, [x8, #0x1]
    4540:      	and	w13, w12, #0x1
    4544:      	fmov	s6, w13
    4548:      	ubfx	w13, w12, #1, #1
    454c:      	mov.b	v6[1], w13
    4550:      	ubfx	w13, w12, #2, #1
    4554:      	mov.b	v6[2], w13
    4558:      	ubfx	w13, w12, #3, #1
    455c:      	mov.b	v6[3], w13
    4560:      	ubfx	w13, w12, #4, #1
    4564:      	mov.b	v6[4], w13
    4568:      	ubfx	w13, w12, #5, #1
    456c:      	mov.b	v6[5], w13
    4570:      	ubfx	w13, w12, #6, #1
    4574:      	mov.b	v6[6], w13
    4578:      	lsr	w12, w12, #7
    457c:      	mov.b	v6[7], w12
    4580:      	and.8b	v7, v0, v1
    4584:      	eor.8b	v1, v6, v7
    4588:      	shl.8b	v1, v1, #0x7
    458c:      	cmlt.8b	v3, v1, #0
    4590:      	umaxv.8b	b1, v3
    4594:      	fmov	w12, s1
    4598:      	eor	w12, w12, #0x1
    459c:      	ands	w9, w12, w9, lsr #1
    45a0:      	dup.8b	v1, w9
    45a4:      	and.8b	v1, v1, v6
    45a8:      	shl.8b	v4, v1, #0x7
    45ac:      	cmlt.8b	v4, v4, #0
    45b0:      	and.8b	v4, v4, v2
    45b4:      	addv.8b	b4, v4
    45b8:      	fmov	w12, s4
    45bc:      	csetm	w9, ne
    45c0:      	dup.8b	v16, w9
    45c4:      	bic.8b	v7, v7, v16
    45c8:      	shl.8b	v7, v7, #0x7
    45cc:      	cmlt.8b	v7, v7, #0
    45d0:      	and.8b	v7, v7, v2
    45d4:      	addv.8b	b7, v7
    45d8:      	stur	b7, [x8, #0x9]
    45dc:      	bic.8b	v6, v6, v16
    45e0:      	shl.8b	v6, v6, #0x7
    45e4:      	cmlt.8b	v6, v6, #0
    45e8:      	and.8b	v6, v6, v2
    45ec:      	addv.8b	b6, v6
    45f0:      	stur	b6, [x8, #0x1]
    45f4:      	cmp	w10, #0x8
    45f8:      	and	w9, w12, #0xff
    45fc:      	ccmp	w9, #0x0, #0x4, hs
    4600:      	b.ne	0x5400 <ltmp0+0x5400>
    4604:      	and.8b	v3, v3, v2
    4608:      	ldr	d6, [sp, #0x40]
    460c:      	cmeq.8b	v4, v4, v6
    4610:      	mvn.8b	v4, v4
    4614:      	umov.b	w9, v4[0]
    4618:      	addv.8b	b4, v3
    461c:      	sbfx	w13, w9, #0, #1
    4620:      	fmov	s3, w13
    4624:      	sbfx	w13, w9, #1, #1
    4628:      	mov.b	v3[1], w13
    462c:      	sbfx	w13, w9, #2, #1
    4630:      	mov.b	v3[2], w13
    4634:      	sbfx	w13, w9, #3, #1
    4638:      	mov.b	v3[3], w13
    463c:      	sbfx	w13, w9, #4, #1
    4640:      	mov.b	v3[4], w13
    4644:      	sbfx	w13, w9, #5, #1
    4648:      	mov.b	v3[5], w13
    464c:      	sbfx	w13, w9, #6, #1
    4650:      	mov.b	v3[6], w13
    4654:      	sbfx	w9, w9, #7, #1
    4658:      	mov.b	v3[7], w9
    465c:      	fmov	w9, s4
    4660:      	and	w13, w11, #0xfffffffd
    4664:      	tst	w9, #0xff
    4668:      	csel	w9, w13, w11, eq
    466c:      	sxtw	x11, w10
    4670:      	tst	w12, #0xff
    4674:      	csel	x11, x11, xzr, ne
    4678:      	ldrb	w12, [x23, x11]
    467c:      	and	w13, w12, #0x1
    4680:      	fmov	s4, w13
    4684:      	ubfx	w13, w12, #1, #1
    4688:      	mov.b	v4[1], w13
    468c:      	ubfx	w13, w12, #2, #1
    4690:      	mov.b	v4[2], w13
    4694:      	ubfx	w13, w12, #3, #1
    4698:      	mov.b	v4[3], w13
    469c:      	ubfx	w13, w12, #4, #1
    46a0:      	mov.b	v4[4], w13
    46a4:      	ubfx	w13, w12, #5, #1
    46a8:      	mov.b	v4[5], w13
    46ac:      	ubfx	w13, w12, #6, #1
    46b0:      	mov.b	v4[6], w13
    46b4:      	lsr	w12, w12, #7
    46b8:      	mov.b	v4[7], w12
    46bc:      	bif.8b	v1, v4, v3
    46c0:      	ldr	q3, [sp, #0x440]
    46c4:      	mov.s	w12, v3[1]
    46c8:      	add	x12, x15, w12, sxtw #2
    46cc:      	ldr	q3, [sp, #0x420]
    46d0:      	mov.s	w13, v3[1]
    46d4:      	shl.8b	v1, v1, #0x7
    46d8:      	cmlt.8b	v1, v1, #0
    46dc:      	and.8b	v1, v1, v2
    46e0:      	addv.8b	b1, v1
    46e4:      	str	b1, [x23, x11]
    46e8:      	lsl	x11, x11, #2
    46ec:      	add	x14, x25, x11
    46f0:      	csel	x12, x12, x14, ne
    46f4:      	ldr	w12, [x12]
    46f8:      	str	w12, [x14]
    46fc:      	ldr	w12, [x26, x11]
    4700:      	csel	w12, w13, w12, ne
    4704:      	str	w12, [x26, x11]
    4708:      	cinc	w10, w10, ne
    470c:      	and	w11, w9, #0x4
    4710:      	ldrb	w12, [x8, #0xa]
    4714:      	and	w13, w12, #0x1
    4718:      	fmov	s1, w13
    471c:      	ubfx	w13, w12, #1, #1
    4720:      	mov.b	v1[1], w13
    4724:      	ubfx	w13, w12, #2, #1
    4728:      	mov.b	v1[2], w13
    472c:      	ubfx	w13, w12, #3, #1
    4730:      	mov.b	v1[3], w13
    4734:      	ubfx	w13, w12, #4, #1
    4738:      	mov.b	v1[4], w13
    473c:      	ubfx	w13, w12, #5, #1
    4740:      	mov.b	v1[5], w13
    4744:      	ubfx	w13, w12, #6, #1
    4748:      	mov.b	v1[6], w13
    474c:      	lsr	w12, w12, #7
    4750:      	mov.b	v1[7], w12
    4754:      	ldrb	w12, [x8, #0x2]
    4758:      	and	w13, w12, #0x1
    475c:      	fmov	s6, w13
    4760:      	ubfx	w13, w12, #1, #1
    4764:      	mov.b	v6[1], w13
    4768:      	ubfx	w13, w12, #2, #1
    476c:      	mov.b	v6[2], w13
    4770:      	ubfx	w13, w12, #3, #1
    4774:      	mov.b	v6[3], w13
    4778:      	ubfx	w13, w12, #4, #1
    477c:      	mov.b	v6[4], w13
    4780:      	ubfx	w13, w12, #5, #1
    4784:      	mov.b	v6[5], w13
    4788:      	ubfx	w13, w12, #6, #1
    478c:      	mov.b	v6[6], w13
    4790:      	lsr	w12, w12, #7
    4794:      	mov.b	v6[7], w12
    4798:      	and.8b	v7, v0, v1
    479c:      	eor.8b	v1, v6, v7
    47a0:      	shl.8b	v1, v1, #0x7
    47a4:      	cmlt.8b	v3, v1, #0
    47a8:      	umaxv.8b	b1, v3
    47ac:      	fmov	w12, s1
    47b0:      	eor	w12, w12, #0x1
    47b4:      	ands	w11, w12, w11, lsr #2
    47b8:      	dup.8b	v1, w11
    47bc:      	and.8b	v1, v1, v6
    47c0:      	shl.8b	v4, v1, #0x7
    47c4:      	cmlt.8b	v4, v4, #0
    47c8:      	and.8b	v4, v4, v2
    47cc:      	addv.8b	b4, v4
    47d0:      	fmov	w11, s4
    47d4:      	csetm	w12, ne
    47d8:      	dup.8b	v16, w12
    47dc:      	bic.8b	v7, v7, v16
    47e0:      	shl.8b	v7, v7, #0x7
    47e4:      	cmlt.8b	v7, v7, #0
    47e8:      	and.8b	v7, v7, v2
    47ec:      	addv.8b	b7, v7
    47f0:      	stur	b7, [x8, #0xa]
    47f4:      	bic.8b	v6, v6, v16
    47f8:      	shl.8b	v6, v6, #0x7
    47fc:      	cmlt.8b	v6, v6, #0
    4800:      	and.8b	v6, v6, v2
    4804:      	addv.8b	b6, v6
    4808:      	stur	b6, [x8, #0x2]
    480c:      	cmp	w10, #0x8
    4810:      	and	w12, w11, #0xff
    4814:      	ccmp	w12, #0x0, #0x4, hs
    4818:      	b.ne	0x5400 <ltmp0+0x5400>
    481c:      	and.8b	v3, v3, v2
    4820:      	ldr	d6, [sp, #0x38]
    4824:      	cmeq.8b	v4, v4, v6
    4828:      	mvn.8b	v4, v4
    482c:      	umov.b	w12, v4[0]
    4830:      	addv.8b	b4, v3
    4834:      	sbfx	w13, w12, #0, #1
    4838:      	fmov	s3, w13
    483c:      	sbfx	w13, w12, #1, #1
    4840:      	mov.b	v3[1], w13
    4844:      	sbfx	w13, w12, #2, #1
    4848:      	mov.b	v3[2], w13
    484c:      	sbfx	w13, w12, #3, #1
    4850:      	mov.b	v3[3], w13
    4854:      	sbfx	w13, w12, #4, #1
    4858:      	mov.b	v3[4], w13
    485c:      	sbfx	w13, w12, #5, #1
    4860:      	mov.b	v3[5], w13
    4864:      	sbfx	w13, w12, #6, #1
    4868:      	mov.b	v3[6], w13
    486c:      	sbfx	w12, w12, #7, #1
    4870:      	mov.b	v3[7], w12
    4874:      	fmov	w12, s4
    4878:      	and	w13, w9, #0xfffffffb
    487c:      	tst	w12, #0xff
    4880:      	csel	w9, w13, w9, eq
    4884:      	sxtw	x12, w10
    4888:      	tst	w11, #0xff
    488c:      	csel	x11, x12, xzr, ne
    4890:      	ldrb	w12, [x23, x11]
    4894:      	and	w13, w12, #0x1
    4898:      	fmov	s4, w13
    489c:      	ubfx	w13, w12, #1, #1
    48a0:      	mov.b	v4[1], w13
    48a4:      	ubfx	w13, w12, #2, #1
    48a8:      	mov.b	v4[2], w13
    48ac:      	ubfx	w13, w12, #3, #1
    48b0:      	mov.b	v4[3], w13
    48b4:      	ubfx	w13, w12, #4, #1
    48b8:      	mov.b	v4[4], w13
    48bc:      	ubfx	w13, w12, #5, #1
    48c0:      	mov.b	v4[5], w13
    48c4:      	ubfx	w13, w12, #6, #1
    48c8:      	mov.b	v4[6], w13
    48cc:      	lsr	w12, w12, #7
    48d0:      	mov.b	v4[7], w12
    48d4:      	bif.8b	v1, v4, v3
    48d8:      	ldr	q3, [sp, #0x440]
    48dc:      	mov.s	w12, v3[2]
    48e0:      	add	x12, x15, w12, sxtw #2
    48e4:      	ldr	q3, [sp, #0x420]
    48e8:      	mov.s	w13, v3[2]
    48ec:      	shl.8b	v1, v1, #0x7
    48f0:      	cmlt.8b	v1, v1, #0
    48f4:      	and.8b	v1, v1, v2
    48f8:      	addv.8b	b1, v1
    48fc:      	str	b1, [x23, x11]
    4900:      	lsl	x11, x11, #2
    4904:      	add	x14, x25, x11
    4908:      	csel	x12, x12, x14, ne
    490c:      	ldr	w12, [x12]
    4910:      	str	w12, [x14]
    4914:      	ldr	w12, [x26, x11]
    4918:      	csel	w12, w13, w12, ne
    491c:      	str	w12, [x26, x11]
    4920:      	cinc	w10, w10, ne
    4924:      	and	w11, w9, #0x8
    4928:      	ldrb	w12, [x8, #0xb]
    492c:      	and	w13, w12, #0x1
    4930:      	fmov	s1, w13
    4934:      	ubfx	w13, w12, #1, #1
    4938:      	mov.b	v1[1], w13
    493c:      	ubfx	w13, w12, #2, #1
    4940:      	mov.b	v1[2], w13
    4944:      	ubfx	w13, w12, #3, #1
    4948:      	mov.b	v1[3], w13
    494c:      	ubfx	w13, w12, #4, #1
    4950:      	mov.b	v1[4], w13
    4954:      	ubfx	w13, w12, #5, #1
    4958:      	mov.b	v1[5], w13
    495c:      	ubfx	w13, w12, #6, #1
    4960:      	mov.b	v1[6], w13
    4964:      	lsr	w12, w12, #7
    4968:      	mov.b	v1[7], w12
    496c:      	ldrb	w12, [x8, #0x3]
    4970:      	and	w13, w12, #0x1
    4974:      	fmov	s6, w13
    4978:      	ubfx	w13, w12, #1, #1
    497c:      	mov.b	v6[1], w13
    4980:      	ubfx	w13, w12, #2, #1
    4984:      	mov.b	v6[2], w13
    4988:      	ubfx	w13, w12, #3, #1
    498c:      	mov.b	v6[3], w13
    4990:      	ubfx	w13, w12, #4, #1
    4994:      	mov.b	v6[4], w13
    4998:      	ubfx	w13, w12, #5, #1
    499c:      	mov.b	v6[5], w13
    49a0:      	ubfx	w13, w12, #6, #1
    49a4:      	mov.b	v6[6], w13
    49a8:      	lsr	w12, w12, #7
    49ac:      	mov.b	v6[7], w12
    49b0:      	and.8b	v7, v0, v1
    49b4:      	eor.8b	v1, v6, v7
    49b8:      	shl.8b	v1, v1, #0x7
    49bc:      	cmlt.8b	v3, v1, #0
    49c0:      	umaxv.8b	b1, v3
    49c4:      	fmov	w12, s1
    49c8:      	eor	w12, w12, #0x1
    49cc:      	ands	w11, w12, w11, lsr #3
    49d0:      	dup.8b	v1, w11
    49d4:      	and.8b	v1, v1, v6
    49d8:      	shl.8b	v4, v1, #0x7
    49dc:      	cmlt.8b	v4, v4, #0
    49e0:      	and.8b	v4, v4, v2
    49e4:      	addv.8b	b4, v4
    49e8:      	fmov	w11, s4
    49ec:      	csetm	w12, ne
    49f0:      	dup.8b	v16, w12
    49f4:      	bic.8b	v7, v7, v16
    49f8:      	shl.8b	v7, v7, #0x7
    49fc:      	cmlt.8b	v7, v7, #0
    4a00:      	and.8b	v7, v7, v2
    4a04:      	addv.8b	b7, v7
    4a08:      	stur	b7, [x8, #0xb]
    4a0c:      	bic.8b	v6, v6, v16
    4a10:      	shl.8b	v6, v6, #0x7
    4a14:      	cmlt.8b	v6, v6, #0
    4a18:      	and.8b	v6, v6, v2
    4a1c:      	addv.8b	b6, v6
    4a20:      	stur	b6, [x8, #0x3]
    4a24:      	cmp	w10, #0x8
    4a28:      	and	w12, w11, #0xff
    4a2c:      	ccmp	w12, #0x0, #0x4, hs
    4a30:      	b.ne	0x5400 <ltmp0+0x5400>
    4a34:      	and.8b	v3, v3, v2
    4a38:      	ldr	d6, [sp, #0x30]
    4a3c:      	cmeq.8b	v4, v4, v6
    4a40:      	mvn.8b	v4, v4
    4a44:      	umov.b	w12, v4[0]
    4a48:      	addv.8b	b4, v3
    4a4c:      	sbfx	w13, w12, #0, #1
    4a50:      	fmov	s3, w13
    4a54:      	sbfx	w13, w12, #1, #1
    4a58:      	mov.b	v3[1], w13
    4a5c:      	sbfx	w13, w12, #2, #1
    4a60:      	mov.b	v3[2], w13
    4a64:      	sbfx	w13, w12, #3, #1
    4a68:      	mov.b	v3[3], w13
    4a6c:      	sbfx	w13, w12, #4, #1
    4a70:      	mov.b	v3[4], w13
    4a74:      	sbfx	w13, w12, #5, #1
    4a78:      	mov.b	v3[5], w13
    4a7c:      	sbfx	w13, w12, #6, #1
    4a80:      	mov.b	v3[6], w13
    4a84:      	sbfx	w12, w12, #7, #1
    4a88:      	mov.b	v3[7], w12
    4a8c:      	fmov	w12, s4
    4a90:      	and	w13, w9, #0xfffffff7
    4a94:      	tst	w12, #0xff
    4a98:      	csel	w9, w13, w9, eq
    4a9c:      	sxtw	x12, w10
    4aa0:      	tst	w11, #0xff
    4aa4:      	csel	x11, x12, xzr, ne
    4aa8:      	ldrb	w12, [x23, x11]
    4aac:      	and	w13, w12, #0x1
    4ab0:      	fmov	s4, w13
    4ab4:      	ubfx	w13, w12, #1, #1
    4ab8:      	mov.b	v4[1], w13
    4abc:      	ubfx	w13, w12, #2, #1
    4ac0:      	mov.b	v4[2], w13
    4ac4:      	ubfx	w13, w12, #3, #1
    4ac8:      	mov.b	v4[3], w13
    4acc:      	ubfx	w13, w12, #4, #1
    4ad0:      	mov.b	v4[4], w13
    4ad4:      	ubfx	w13, w12, #5, #1
    4ad8:      	mov.b	v4[5], w13
    4adc:      	ubfx	w13, w12, #6, #1
    4ae0:      	mov.b	v4[6], w13
    4ae4:      	lsr	w12, w12, #7
    4ae8:      	mov.b	v4[7], w12
    4aec:      	bif.8b	v1, v4, v3
    4af0:      	ldr	q3, [sp, #0x440]
    4af4:      	mov.s	w12, v3[3]
    4af8:      	add	x12, x15, w12, sxtw #2
    4afc:      	ldr	q3, [sp, #0x420]
    4b00:      	mov.s	w13, v3[3]
    4b04:      	shl.8b	v1, v1, #0x7
    4b08:      	cmlt.8b	v1, v1, #0
    4b0c:      	and.8b	v1, v1, v2
    4b10:      	addv.8b	b1, v1
    4b14:      	str	b1, [x23, x11]
    4b18:      	lsl	x11, x11, #2
    4b1c:      	add	x14, x25, x11
    4b20:      	csel	x12, x12, x14, ne
    4b24:      	ldr	w12, [x12]
    4b28:      	str	w12, [x14]
    4b2c:      	ldr	w12, [x26, x11]
    4b30:      	csel	w12, w13, w12, ne
    4b34:      	str	w12, [x26, x11]
    4b38:      	cinc	w11, w10, ne
    4b3c:      	and	w10, w9, #0x10
    4b40:      	ldrb	w12, [x8, #0xc]
    4b44:      	and	w13, w12, #0x1
    4b48:      	fmov	s1, w13
    4b4c:      	ubfx	w13, w12, #1, #1
    4b50:      	mov.b	v1[1], w13
    4b54:      	ubfx	w13, w12, #2, #1
    4b58:      	mov.b	v1[2], w13
    4b5c:      	ubfx	w13, w12, #3, #1
    4b60:      	mov.b	v1[3], w13
    4b64:      	ubfx	w13, w12, #4, #1
    4b68:      	mov.b	v1[4], w13
    4b6c:      	ubfx	w13, w12, #5, #1
    4b70:      	mov.b	v1[5], w13
    4b74:      	ubfx	w13, w12, #6, #1
    4b78:      	mov.b	v1[6], w13
    4b7c:      	lsr	w12, w12, #7
    4b80:      	mov.b	v1[7], w12
    4b84:      	ldrb	w12, [x8, #0x4]
    4b88:      	and	w13, w12, #0x1
    4b8c:      	fmov	s6, w13
    4b90:      	ubfx	w13, w12, #1, #1
    4b94:      	mov.b	v6[1], w13
    4b98:      	ubfx	w13, w12, #2, #1
    4b9c:      	mov.b	v6[2], w13
    4ba0:      	ubfx	w13, w12, #3, #1
    4ba4:      	mov.b	v6[3], w13
    4ba8:      	ubfx	w13, w12, #4, #1
    4bac:      	mov.b	v6[4], w13
    4bb0:      	ubfx	w13, w12, #5, #1
    4bb4:      	mov.b	v6[5], w13
    4bb8:      	ubfx	w13, w12, #6, #1
    4bbc:      	mov.b	v6[6], w13
    4bc0:      	lsr	w12, w12, #7
    4bc4:      	mov.b	v6[7], w12
    4bc8:      	and.8b	v7, v0, v1
    4bcc:      	eor.8b	v1, v6, v7
    4bd0:      	shl.8b	v1, v1, #0x7
    4bd4:      	cmlt.8b	v3, v1, #0
    4bd8:      	umaxv.8b	b1, v3
    4bdc:      	fmov	w12, s1
    4be0:      	eor	w12, w12, #0x1
    4be4:      	ands	w10, w12, w10, lsr #4
    4be8:      	dup.8b	v1, w10
    4bec:      	and.8b	v1, v1, v6
    4bf0:      	shl.8b	v4, v1, #0x7
    4bf4:      	cmlt.8b	v4, v4, #0
    4bf8:      	and.8b	v4, v4, v2
    4bfc:      	addv.8b	b4, v4
    4c00:      	fmov	w12, s4
    4c04:      	csetm	w10, ne
    4c08:      	dup.8b	v16, w10
    4c0c:      	bic.8b	v7, v7, v16
    4c10:      	shl.8b	v7, v7, #0x7
    4c14:      	cmlt.8b	v7, v7, #0
    4c18:      	and.8b	v7, v7, v2
    4c1c:      	addv.8b	b7, v7
    4c20:      	stur	b7, [x8, #0xc]
    4c24:      	bic.8b	v6, v6, v16
    4c28:      	shl.8b	v6, v6, #0x7
    4c2c:      	cmlt.8b	v6, v6, #0
    4c30:      	and.8b	v6, v6, v2
    4c34:      	addv.8b	b6, v6
    4c38:      	stur	b6, [x8, #0x4]
    4c3c:      	cmp	w11, #0x8
    4c40:      	and	w10, w12, #0xff
    4c44:      	ccmp	w10, #0x0, #0x4, hs
    4c48:      	b.ne	0x5400 <ltmp0+0x5400>
    4c4c:      	and.8b	v3, v3, v2
    4c50:      	addv.8b	b3, v3
    4c54:      	fmov	w10, s3
    4c58:      	ldr	d3, [sp, #0x28]
    4c5c:      	cmeq.8b	v3, v4, v3
    4c60:      	mvn.8b	v3, v3
    4c64:      	umov.b	w13, v3[0]
    4c68:      	sbfx	w14, w13, #0, #1
    4c6c:      	fmov	s3, w14
    4c70:      	sbfx	w14, w13, #1, #1
    4c74:      	mov.b	v3[1], w14
    4c78:      	sbfx	w14, w13, #2, #1
    4c7c:      	mov.b	v3[2], w14
    4c80:      	sbfx	w14, w13, #3, #1
    4c84:      	mov.b	v3[3], w14
    4c88:      	sbfx	w14, w13, #4, #1
    4c8c:      	mov.b	v3[4], w14
    4c90:      	sbfx	w14, w13, #5, #1
    4c94:      	mov.b	v3[5], w14
    4c98:      	sbfx	w14, w13, #6, #1
    4c9c:      	mov.b	v3[6], w14
    4ca0:      	sbfx	w13, w13, #7, #1
    4ca4:      	mov.b	v3[7], w13
    4ca8:      	and	w13, w9, #0xffffffef
    4cac:      	tst	w10, #0xff
    4cb0:      	csel	w10, w13, w9, eq
    4cb4:      	sxtw	x9, w11
    4cb8:      	tst	w12, #0xff
    4cbc:      	csel	x9, x9, xzr, ne
    4cc0:      	ldrb	w12, [x23, x9]
    4cc4:      	and	w13, w12, #0x1
    4cc8:      	fmov	s4, w13
    4ccc:      	ubfx	w13, w12, #1, #1
    4cd0:      	mov.b	v4[1], w13
    4cd4:      	ubfx	w13, w12, #2, #1
    4cd8:      	mov.b	v4[2], w13
    4cdc:      	ubfx	w13, w12, #3, #1
    4ce0:      	mov.b	v4[3], w13
    4ce4:      	ubfx	w13, w12, #4, #1
    4ce8:      	mov.b	v4[4], w13
    4cec:      	ubfx	w13, w12, #5, #1
    4cf0:      	mov.b	v4[5], w13
    4cf4:      	ubfx	w13, w12, #6, #1
    4cf8:      	mov.b	v4[6], w13
    4cfc:      	lsr	w12, w12, #7
    4d00:      	mov.b	v4[7], w12
    4d04:      	bif.8b	v1, v4, v3
    4d08:      	ldr	q3, [sp, #0x450]
    4d0c:      	fmov	w12, s3
    4d10:      	add	x12, x15, w12, sxtw #2
    4d14:      	ldr	q3, [sp, #0x430]
    4d18:      	fmov	w13, s3
    4d1c:      	shl.8b	v1, v1, #0x7
    4d20:      	cmlt.8b	v1, v1, #0
    4d24:      	and.8b	v1, v1, v2
    4d28:      	addv.8b	b1, v1
    4d2c:      	str	b1, [x23, x9]
    4d30:      	lsl	x9, x9, #2
    4d34:      	add	x14, x25, x9
    4d38:      	csel	x12, x12, x14, ne
    4d3c:      	ldr	w12, [x12]
    4d40:      	str	w12, [x14]
    4d44:      	ldr	w12, [x26, x9]
    4d48:      	csel	w12, w13, w12, ne
    4d4c:      	str	w12, [x26, x9]
    4d50:      	cinc	w9, w11, ne
    4d54:      	and	w11, w10, #0x20
    4d58:      	ldrb	w12, [x8, #0xd]
    4d5c:      	and	w13, w12, #0x1
    4d60:      	fmov	s1, w13
    4d64:      	ubfx	w13, w12, #1, #1
    4d68:      	mov.b	v1[1], w13
    4d6c:      	ubfx	w13, w12, #2, #1
    4d70:      	mov.b	v1[2], w13
    4d74:      	ubfx	w13, w12, #3, #1
    4d78:      	mov.b	v1[3], w13
    4d7c:      	ubfx	w13, w12, #4, #1
    4d80:      	mov.b	v1[4], w13
    4d84:      	ubfx	w13, w12, #5, #1
    4d88:      	mov.b	v1[5], w13
    4d8c:      	ubfx	w13, w12, #6, #1
    4d90:      	mov.b	v1[6], w13
    4d94:      	lsr	w12, w12, #7
    4d98:      	mov.b	v1[7], w12
    4d9c:      	ldrb	w12, [x8, #0x5]
    4da0:      	and	w13, w12, #0x1
    4da4:      	fmov	s6, w13
    4da8:      	ubfx	w13, w12, #1, #1
    4dac:      	mov.b	v6[1], w13
    4db0:      	ubfx	w13, w12, #2, #1
    4db4:      	mov.b	v6[2], w13
    4db8:      	ubfx	w13, w12, #3, #1
    4dbc:      	mov.b	v6[3], w13
    4dc0:      	ubfx	w13, w12, #4, #1
    4dc4:      	mov.b	v6[4], w13
    4dc8:      	ubfx	w13, w12, #5, #1
    4dcc:      	mov.b	v6[5], w13
    4dd0:      	ubfx	w13, w12, #6, #1
    4dd4:      	mov.b	v6[6], w13
    4dd8:      	lsr	w12, w12, #7
    4ddc:      	mov.b	v6[7], w12
    4de0:      	and.8b	v7, v0, v1
    4de4:      	eor.8b	v1, v6, v7
    4de8:      	shl.8b	v1, v1, #0x7
    4dec:      	cmlt.8b	v3, v1, #0
    4df0:      	umaxv.8b	b1, v3
    4df4:      	fmov	w12, s1
    4df8:      	eor	w12, w12, #0x1
    4dfc:      	ands	w11, w12, w11, lsr #5
    4e00:      	dup.8b	v1, w11
    4e04:      	and.8b	v1, v1, v6
    4e08:      	shl.8b	v4, v1, #0x7
    4e0c:      	cmlt.8b	v4, v4, #0
    4e10:      	and.8b	v4, v4, v2
    4e14:      	addv.8b	b4, v4
    4e18:      	fmov	w11, s4
    4e1c:      	csetm	w12, ne
    4e20:      	dup.8b	v16, w12
    4e24:      	bic.8b	v7, v7, v16
    4e28:      	shl.8b	v7, v7, #0x7
    4e2c:      	cmlt.8b	v7, v7, #0
    4e30:      	and.8b	v7, v7, v2
    4e34:      	addv.8b	b7, v7
    4e38:      	stur	b7, [x8, #0xd]
    4e3c:      	bic.8b	v6, v6, v16
    4e40:      	shl.8b	v6, v6, #0x7
    4e44:      	cmlt.8b	v6, v6, #0
    4e48:      	and.8b	v6, v6, v2
    4e4c:      	addv.8b	b6, v6
    4e50:      	stur	b6, [x8, #0x5]
    4e54:      	cmp	w9, #0x8
    4e58:      	and	w12, w11, #0xff
    4e5c:      	ccmp	w12, #0x0, #0x4, hs
    4e60:      	b.ne	0x5400 <ltmp0+0x5400>
    4e64:      	and.8b	v3, v3, v2
    4e68:      	addv.8b	b3, v3
    4e6c:      	fmov	w12, s3
    4e70:      	ldr	d3, [sp, #0x20]
    4e74:      	cmeq.8b	v3, v4, v3
    4e78:      	mvn.8b	v3, v3
    4e7c:      	umov.b	w13, v3[0]
    4e80:      	sbfx	w14, w13, #0, #1
    4e84:      	fmov	s3, w14
    4e88:      	sbfx	w14, w13, #1, #1
    4e8c:      	mov.b	v3[1], w14
    4e90:      	sbfx	w14, w13, #2, #1
    4e94:      	mov.b	v3[2], w14
    4e98:      	sbfx	w14, w13, #3, #1
    4e9c:      	mov.b	v3[3], w14
    4ea0:      	sbfx	w14, w13, #4, #1
    4ea4:      	mov.b	v3[4], w14
    4ea8:      	sbfx	w14, w13, #5, #1
    4eac:      	mov.b	v3[5], w14
    4eb0:      	sbfx	w14, w13, #6, #1
    4eb4:      	mov.b	v3[6], w14
    4eb8:      	sbfx	w13, w13, #7, #1
    4ebc:      	mov.b	v3[7], w13
    4ec0:      	and	w13, w10, #0xffffffdf
    4ec4:      	tst	w12, #0xff
    4ec8:      	csel	w10, w13, w10, eq
    4ecc:      	sxtw	x12, w9
    4ed0:      	tst	w11, #0xff
    4ed4:      	csel	x11, x12, xzr, ne
    4ed8:      	ldrb	w12, [x23, x11]
    4edc:      	and	w13, w12, #0x1
    4ee0:      	fmov	s4, w13
    4ee4:      	ubfx	w13, w12, #1, #1
    4ee8:      	mov.b	v4[1], w13
    4eec:      	ubfx	w13, w12, #2, #1
    4ef0:      	mov.b	v4[2], w13
    4ef4:      	ubfx	w13, w12, #3, #1
    4ef8:      	mov.b	v4[3], w13
    4efc:      	ubfx	w13, w12, #4, #1
    4f00:      	mov.b	v4[4], w13
    4f04:      	ubfx	w13, w12, #5, #1
    4f08:      	mov.b	v4[5], w13
    4f0c:      	ubfx	w13, w12, #6, #1
    4f10:      	mov.b	v4[6], w13
    4f14:      	lsr	w12, w12, #7
    4f18:      	mov.b	v4[7], w12
    4f1c:      	ldr	q6, [sp, #0x450]
    4f20:      	mov.s	w12, v6[1]
    4f24:      	bif.8b	v1, v4, v3
    4f28:      	add	x12, x15, w12, sxtw #2
    4f2c:      	ldr	q3, [sp, #0x430]
    4f30:      	mov.s	w13, v3[1]
    4f34:      	shl.8b	v1, v1, #0x7
    4f38:      	cmlt.8b	v1, v1, #0
    4f3c:      	and.8b	v1, v1, v2
    4f40:      	addv.8b	b1, v1
    4f44:      	str	b1, [x23, x11]
    4f48:      	lsl	x11, x11, #2
    4f4c:      	add	x14, x25, x11
    4f50:      	csel	x12, x12, x14, ne
    4f54:      	ldr	w12, [x12]
    4f58:      	str	w12, [x14]
    4f5c:      	ldr	w12, [x26, x11]
    4f60:      	csel	w12, w13, w12, ne
    4f64:      	str	w12, [x26, x11]
    4f68:      	cinc	w9, w9, ne
    4f6c:      	ldrb	w11, [x8, #0xe]
    4f70:      	and	w12, w11, #0x1
    4f74:      	fmov	s1, w12
    4f78:      	ubfx	w12, w11, #1, #1
    4f7c:      	mov.b	v1[1], w12
    4f80:      	ubfx	w12, w11, #2, #1
    4f84:      	mov.b	v1[2], w12
    4f88:      	ubfx	w12, w11, #3, #1
    4f8c:      	mov.b	v1[3], w12
    4f90:      	ubfx	w12, w11, #4, #1
    4f94:      	mov.b	v1[4], w12
    4f98:      	ubfx	w12, w11, #5, #1
    4f9c:      	mov.b	v1[5], w12
    4fa0:      	ubfx	w12, w11, #6, #1
    4fa4:      	mov.b	v1[6], w12
    4fa8:      	lsr	w11, w11, #7
    4fac:      	mov.b	v1[7], w11
    4fb0:      	ldrb	w11, [x8, #0x6]
    4fb4:      	and	w12, w11, #0x1
    4fb8:      	fmov	s6, w12
    4fbc:      	ubfx	w12, w11, #1, #1
    4fc0:      	mov.b	v6[1], w12
    4fc4:      	ubfx	w12, w11, #2, #1
    4fc8:      	mov.b	v6[2], w12
    4fcc:      	ubfx	w12, w11, #3, #1
    4fd0:      	mov.b	v6[3], w12
    4fd4:      	ubfx	w12, w11, #4, #1
    4fd8:      	mov.b	v6[4], w12
    4fdc:      	ubfx	w12, w11, #5, #1
    4fe0:      	mov.b	v6[5], w12
    4fe4:      	ubfx	w12, w11, #6, #1
    4fe8:      	mov.b	v6[6], w12
    4fec:      	and	w12, w10, #0x40
    4ff0:      	lsr	w11, w11, #7
    4ff4:      	mov.b	v6[7], w11
    4ff8:      	and.8b	v7, v0, v1
    4ffc:      	eor.8b	v1, v6, v7
    5000:      	shl.8b	v1, v1, #0x7
    5004:      	cmlt.8b	v3, v1, #0
    5008:      	umaxv.8b	b1, v3
    500c:      	fmov	w11, s1
    5010:      	eor	w11, w11, #0x1
    5014:      	ands	w11, w11, w12, lsr #6
    5018:      	dup.8b	v1, w11
    501c:      	and.8b	v1, v1, v6
    5020:      	shl.8b	v4, v1, #0x7
    5024:      	cmlt.8b	v4, v4, #0
    5028:      	and.8b	v4, v4, v2
    502c:      	addv.8b	b4, v4
    5030:      	fmov	w11, s4
    5034:      	csetm	w12, ne
    5038:      	dup.8b	v16, w12
    503c:      	bic.8b	v7, v7, v16
    5040:      	shl.8b	v7, v7, #0x7
    5044:      	cmlt.8b	v7, v7, #0
    5048:      	and.8b	v7, v7, v2
    504c:      	addv.8b	b7, v7
    5050:      	stur	b7, [x8, #0xe]
    5054:      	bic.8b	v6, v6, v16
    5058:      	shl.8b	v6, v6, #0x7
    505c:      	cmlt.8b	v6, v6, #0
    5060:      	and.8b	v6, v6, v2
    5064:      	addv.8b	b6, v6
    5068:      	stur	b6, [x8, #0x6]
    506c:      	cmp	w9, #0x8
    5070:      	b.lo	0x507c <ltmp0+0x507c>
    5074:      	tst	w11, #0xff
    5078:      	b.ne	0x5400 <ltmp0+0x5400>
    507c:      	and.8b	v3, v3, v2
    5080:      	ldr	d6, [sp, #0x18]
    5084:      	cmeq.8b	v4, v4, v6
    5088:      	mvn.8b	v4, v4
    508c:      	umov.b	w12, v4[0]
    5090:      	addv.8b	b4, v3
    5094:      	sbfx	w13, w12, #0, #1
    5098:      	fmov	s3, w13
    509c:      	sbfx	w13, w12, #1, #1
    50a0:      	mov.b	v3[1], w13
    50a4:      	sbfx	w13, w12, #2, #1
    50a8:      	mov.b	v3[2], w13
    50ac:      	sbfx	w13, w12, #3, #1
    50b0:      	mov.b	v3[3], w13
    50b4:      	sbfx	w13, w12, #4, #1
    50b8:      	mov.b	v3[4], w13
    50bc:      	sbfx	w13, w12, #5, #1
    50c0:      	mov.b	v3[5], w13
    50c4:      	sbfx	w13, w12, #6, #1
    50c8:      	mov.b	v3[6], w13
    50cc:      	sbfx	w12, w12, #7, #1
    50d0:      	mov.b	v3[7], w12
    50d4:      	fmov	w12, s4
    50d8:      	and	w13, w10, #0xffffffbf
    50dc:      	tst	w12, #0xff
    50e0:      	csel	w10, w13, w10, eq
    50e4:      	sxtw	x12, w9
    50e8:      	tst	w11, #0xff
    50ec:      	csel	x11, x12, xzr, ne
    50f0:      	ldrb	w12, [x23, x11]
    50f4:      	and	w13, w12, #0x1
    50f8:      	fmov	s4, w13
    50fc:      	ubfx	w13, w12, #1, #1
    5100:      	mov.b	v4[1], w13
    5104:      	ubfx	w13, w12, #2, #1
    5108:      	mov.b	v4[2], w13
    510c:      	ubfx	w13, w12, #3, #1
    5110:      	mov.b	v4[3], w13
    5114:      	ubfx	w13, w12, #4, #1
    5118:      	mov.b	v4[4], w13
    511c:      	ubfx	w13, w12, #5, #1
    5120:      	mov.b	v4[5], w13
    5124:      	ubfx	w13, w12, #6, #1
    5128:      	mov.b	v4[6], w13
    512c:      	lsr	w12, w12, #7
    5130:      	mov.b	v4[7], w12
    5134:      	bif.8b	v1, v4, v3
    5138:      	ldr	q3, [sp, #0x450]
    513c:      	mov.s	w12, v3[2]
    5140:      	add	x12, x15, w12, sxtw #2
    5144:      	ldr	q3, [sp, #0x430]
    5148:      	mov.s	w13, v3[2]
    514c:      	sxtb	w10, w10
    5150:      	shl.8b	v1, v1, #0x7
    5154:      	cmlt.8b	v1, v1, #0
    5158:      	and.8b	v1, v1, v2
    515c:      	addv.8b	b1, v1
    5160:      	str	b1, [x23, x11]
    5164:      	lsl	x11, x11, #2
    5168:      	ldr	w14, [x26, x11]
    516c:      	csel	w13, w13, w14, ne
    5170:      	add	x14, x25, x11
    5174:      	csel	x12, x12, x14, ne
    5178:      	ldr	w12, [x12]
    517c:      	str	w13, [x26, x11]
    5180:      	str	w12, [x14]
    5184:      	cinc	w9, w9, ne
    5188:      	cmp	w10, #0x0
    518c:      	ldrb	w11, [x8, #0xf]
    5190:      	and	w12, w11, #0x1
    5194:      	fmov	s1, w12
    5198:      	ubfx	w12, w11, #1, #1
    519c:      	mov.b	v1[1], w12
    51a0:      	ubfx	w12, w11, #2, #1
    51a4:      	mov.b	v1[2], w12
    51a8:      	ubfx	w12, w11, #3, #1
    51ac:      	mov.b	v1[3], w12
    51b0:      	ubfx	w12, w11, #4, #1
    51b4:      	mov.b	v1[4], w12
    51b8:      	ubfx	w12, w11, #5, #1
    51bc:      	mov.b	v1[5], w12
    51c0:      	ubfx	w12, w11, #6, #1
    51c4:      	mov.b	v1[6], w12
    51c8:      	lsr	w11, w11, #7
    51cc:      	mov.b	v1[7], w11
    51d0:      	ldrb	w11, [x8, #0x7]
    51d4:      	and	w12, w11, #0x1
    51d8:      	fmov	s6, w12
    51dc:      	ubfx	w12, w11, #1, #1
    51e0:      	mov.b	v6[1], w12
    51e4:      	ubfx	w12, w11, #2, #1
    51e8:      	mov.b	v6[2], w12
    51ec:      	ubfx	w12, w11, #3, #1
    51f0:      	mov.b	v6[3], w12
    51f4:      	ubfx	w12, w11, #4, #1
    51f8:      	mov.b	v6[4], w12
    51fc:      	ubfx	w12, w11, #5, #1
    5200:      	mov.b	v6[5], w12
    5204:      	ubfx	w12, w11, #6, #1
    5208:      	mov.b	v6[6], w12
    520c:      	cset	w12, lt
    5210:      	lsr	w11, w11, #7
    5214:      	mov.b	v6[7], w11
    5218:      	and.8b	v7, v0, v1
    521c:      	eor.8b	v1, v6, v7
    5220:      	shl.8b	v1, v1, #0x7
    5224:      	cmlt.8b	v3, v1, #0
    5228:      	umaxv.8b	b1, v3
    522c:      	fmov	w11, s1
    5230:      	eor	w11, w11, #0x1
    5234:      	ands	w11, w12, w11
    5238:      	dup.8b	v1, w11
    523c:      	and.8b	v1, v1, v6
    5240:      	shl.8b	v4, v1, #0x7
    5244:      	cmlt.8b	v4, v4, #0
    5248:      	and.8b	v4, v4, v2
    524c:      	addv.8b	b4, v4
    5250:      	fmov	w11, s4
    5254:      	csetm	w12, ne
    5258:      	dup.8b	v16, w12
    525c:      	bic.8b	v7, v7, v16
    5260:      	shl.8b	v7, v7, #0x7
    5264:      	cmlt.8b	v7, v7, #0
    5268:      	and.8b	v7, v7, v2
    526c:      	addv.8b	b7, v7
    5270:      	stur	b7, [x8, #0xf]
    5274:      	bic.8b	v6, v6, v16
    5278:      	shl.8b	v6, v6, #0x7
    527c:      	cmlt.8b	v6, v6, #0
    5280:      	and.8b	v6, v6, v2
    5284:      	addv.8b	b6, v6
    5288:      	stur	b6, [x8, #0x7]
    528c:      	cmp	w9, #0x8
    5290:      	b.lo	0x529c <ltmp0+0x529c>
    5294:      	tst	w11, #0xff
    5298:      	b.ne	0x5400 <ltmp0+0x5400>
    529c:      	and.8b	v3, v3, v2
    52a0:      	addv.8b	b6, v3
    52a4:      	ldr	d3, [sp, #0x10]
    52a8:      	cmeq.8b	v3, v4, v3
    52ac:      	mvn.8b	v3, v3
    52b0:      	umov.b	w12, v3[0]
    52b4:      	sbfx	w13, w12, #0, #1
    52b8:      	fmov	s3, w13
    52bc:      	sbfx	w13, w12, #1, #1
    52c0:      	mov.b	v3[1], w13
    52c4:      	sbfx	w13, w12, #2, #1
    52c8:      	mov.b	v3[2], w13
    52cc:      	sbfx	w13, w12, #3, #1
    52d0:      	mov.b	v3[3], w13
    52d4:      	sbfx	w13, w12, #4, #1
    52d8:      	mov.b	v3[4], w13
    52dc:      	sbfx	w13, w12, #5, #1
    52e0:      	mov.b	v3[5], w13
    52e4:      	sbfx	w13, w12, #6, #1
    52e8:      	mov.b	v3[6], w13
    52ec:      	fmov	w13, s6
    52f0:      	sbfx	w12, w12, #7, #1
    52f4:      	mov.b	v3[7], w12
    52f8:      	and	w12, w10, #0x7f
    52fc:      	tst	w13, #0xff
    5300:      	csel	w30, w12, w10, eq
    5304:      	sxtw	x10, w9
    5308:      	tst	w11, #0xff
    530c:      	csel	x10, x10, xzr, ne
    5310:      	ldrb	w11, [x23, x10]
    5314:      	and	w12, w11, #0x1
    5318:      	fmov	s4, w12
    531c:      	ubfx	w12, w11, #1, #1
    5320:      	mov.b	v4[1], w12
    5324:      	ubfx	w12, w11, #2, #1
    5328:      	mov.b	v4[2], w12
    532c:      	ubfx	w12, w11, #3, #1
    5330:      	mov.b	v4[3], w12
    5334:      	ubfx	w12, w11, #4, #1
    5338:      	mov.b	v4[4], w12
    533c:      	ubfx	w12, w11, #5, #1
    5340:      	mov.b	v4[5], w12
    5344:      	ubfx	w12, w11, #6, #1
    5348:      	mov.b	v4[6], w12
    534c:      	lsr	w11, w11, #7
    5350:      	mov.b	v4[7], w11
    5354:      	bif.8b	v1, v4, v3
    5358:      	ldr	q3, [sp, #0x450]
    535c:      	mov.s	w11, v3[3]
    5360:      	ldr	q3, [sp, #0x430]
    5364:      	mov.s	w12, v3[3]
    5368:      	shl.8b	v1, v1, #0x7
    536c:      	cmlt.8b	v1, v1, #0
    5370:      	and.8b	v1, v1, v2
    5374:      	addv.8b	b1, v1
    5378:      	str	b1, [x23, x10]
    537c:      	adrp	x13, 0x5000 <ltmp0+0x5000>
    5380:      	add	x13, x13, #0x0
    5384:      	add	x11, x13, w11, sxtw #2
    5388:      	lsl	x10, x10, #2
    538c:      	add	x13, x25, x10
    5390:      	csel	x11, x11, x13, ne
    5394:      	ldr	w11, [x11]
    5398:      	str	w11, [x13]
    539c:      	ldr	w11, [x26, x10]
    53a0:      	csel	w11, w12, w11, ne
    53a4:      	str	w11, [x26, x10]
    53a8:      	cinc	w24, w9, ne
    53ac:      	b	0x2c8 <ltmp0+0x2c8>
    53b0:      	mov	w30, #0x0               ; =0
    53b4:      	b	0x2c8 <ltmp0+0x2c8>
    53b8:      	shl.8b	v0, v0, #0x7
    53bc:      	cmlt.8b	v0, v0, #0
    53c0:      	umaxv.8b	b0, v0
    53c4:      	fmov	w8, s0
    53c8:      	tbnz	w8, #0x0, 0x5400 <ltmp0+0x5400>
    53cc:      	add	sp, sp, #0x4, lsl #12   ; =0x4000
    53d0:      	add	sp, sp, #0x320
    53d4:      	ldp	x29, x30, [sp, #0x90]
    53d8:      	ldp	x20, x19, [sp, #0x80]
    53dc:      	ldp	x22, x21, [sp, #0x70]
    53e0:      	ldp	x24, x23, [sp, #0x60]
    53e4:      	ldp	x26, x25, [sp, #0x50]
    53e8:      	ldp	x28, x27, [sp, #0x40]
    53ec:      	ldp	d9, d8, [sp, #0x30]
    53f0:      	ldp	d11, d10, [sp, #0x20]
    53f4:      	ldp	d13, d12, [sp, #0x10]
    53f8:      	ldp	d15, d14, [sp], #0xa0
    53fc:      	ret
    5400:      	brk	#0x1

0000000000005404 <_llm_rows.packet_batch>:
    5404:      	stp	x26, x25, [sp, #-0x50]!
    5408:      	stp	x24, x23, [sp, #0x10]
    540c:      	stp	x22, x21, [sp, #0x20]
    5410:      	stp	x20, x19, [sp, #0x30]
    5414:      	stp	x29, x30, [sp, #0x40]
    5418:      	mov	x21, x3
    541c:      	mov	x19, x2
    5420:      	mov	x20, x0
    5424:      	ldr	w23, [x2, #0x24]
    5428:      	ldr	w8, [x2]
    542c:      	ldr	w9, [x2, #0xc]
    5430:      	lsl	x8, x8, #5
    5434:      	cmp	x8, x9
    5438:      	csel	x10, x8, xzr, ls
    543c:      	add	x10, x10, x23
    5440:      	subs	x11, x9, x10
    5444:      	mov	w12, #0x20              ; =32
    5448:      	sub	x13, x12, x23
    544c:      	cmp	x11, x13
    5450:      	csel	x11, x11, x13, lo
    5454:      	cmp	x9, x10
    5458:      	ccmp	x23, x12, #0x2, hi
    545c:      	ccmp	x8, x9, #0x2, lo
    5460:      	csel	x8, x11, xzr, ls
    5464:      	cmp	w3, #0x4
    5468:      	b.ne	0x54e0 <_llm_rows.packet_batch+0xdc>
    546c:      	cmp	x8, #0x20
    5470:      	b.lo	0x54e0 <_llm_rows.packet_batch+0xdc>
    5474:      	mov	x0, x20
    5478:      	mov	x1, x19
    547c:      	mov	w2, #0x8                ; =8
    5480:      	bl	0x5480 <_llm_rows.packet_batch+0x7c>
    5484:      	add	w8, w23, #0x8
    5488:      	str	w8, [x19, #0x24]
    548c:      	mov	x0, x20
    5490:      	mov	x1, x19
    5494:      	mov	w2, #0x8                ; =8
    5498:      	bl	0x5498 <_llm_rows.packet_batch+0x94>
    549c:      	add	w8, w23, #0x10
    54a0:      	str	w8, [x19, #0x24]
    54a4:      	mov	x0, x20
    54a8:      	mov	x1, x19
    54ac:      	mov	w2, #0x8                ; =8
    54b0:      	bl	0x54b0 <_llm_rows.packet_batch+0xac>
    54b4:      	add	w8, w23, #0x18
    54b8:      	str	w8, [x19, #0x24]
    54bc:      	mov	x0, x20
    54c0:      	mov	x1, x19
    54c4:      	mov	w2, #0x8                ; =8
    54c8:      	ldp	x29, x30, [sp, #0x40]
    54cc:      	ldp	x20, x19, [sp, #0x30]
    54d0:      	ldp	x22, x21, [sp, #0x20]
    54d4:      	ldp	x24, x23, [sp, #0x10]
    54d8:      	ldp	x26, x25, [sp], #0x50
    54dc:      	b	0x54dc <_llm_rows.packet_batch+0xd8>
    54e0:      	ubfiz	x9, x21, #3, #32
    54e4:      	cmp	x8, x9
    54e8:      	csel	x8, x8, x9, lo
    54ec:      	lsr	x24, x8, #3
    54f0:      	and	w22, w8, #0x7
    54f4:      	cmp	x8, #0x8
    54f8:      	b.lo	0x5524 <_llm_rows.packet_batch+0x120>
    54fc:      	mov	x25, x24
    5500:      	mov	x26, x23
    5504:      	str	w26, [x19, #0x24]
    5508:      	mov	x0, x20
    550c:      	mov	x1, x19
    5510:      	mov	w2, #0x8                ; =8
    5514:      	bl	0x5514 <_llm_rows.packet_batch+0x110>
    5518:      	add	w26, w26, #0x8
    551c:      	subs	w25, w25, #0x1
    5520:      	b.ne	0x5504 <_llm_rows.packet_batch+0x100>
    5524:      	cbz	w22, 0x5540 <_llm_rows.packet_batch+0x13c>
    5528:      	add	w8, w23, w24, lsl #3
    552c:      	str	w8, [x19, #0x24]
    5530:      	mov	x0, x20
    5534:      	mov	x1, x19
    5538:      	mov	x2, x22
    553c:      	bl	0x553c <_llm_rows.packet_batch+0x138>
    5540:      	lsl	w8, w21, #3
    5544:      	sub	w8, w8, #0x8
    5548:      	cmp	w21, #0x0
    554c:      	csel	w8, wzr, w8, eq
    5550:      	add	w8, w23, w8
    5554:      	str	w8, [x19, #0x24]
    5558:      	ldp	x29, x30, [sp, #0x40]
    555c:      	ldp	x20, x19, [sp, #0x30]
    5560:      	ldp	x22, x21, [sp, #0x20]
    5564:      	ldp	x24, x23, [sp, #0x10]
    5568:      	ldp	x26, x25, [sp], #0x50
    556c:      	ret

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [16416 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16416 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.slot13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot13, align 32
  %.spill14 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill14, align 4
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot16, align 64
  %.spill17 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill17, align 4
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat20, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat22, %41
  %44 = mul i32 %32, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat24, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat26, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat28
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 512
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state29 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state29, 8
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat31, %.spill.load
  %.spill.load32 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load32, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 4097)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state33 = load i64, ptr %.slot, align 4
  %.splatinsert34 = insertelement <8 x i64> poison, i64 %.state33, i64 0
  %.splat35 = shufflevector <8 x i64> %.splatinsert34, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat35, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state36 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state36, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load37 = load <8 x i64>, ptr %.spill, align 64
  %102 = icmp slt <8 x i64> %.spill.load37, splat (i64 1)
  %103 = load <8 x i1>, ptr %.spill5, align 1
  %104 = select <8 x i1> %51, <8 x i1> %102, <8 x i1> %103
  store <8 x i1> %104, ptr %.spill5, align 1
  %105 = and <8 x i1> %51, %102
  %106 = xor <8 x i1> %102, splat (i1 true)
  %107 = and <8 x i1> %51, %106
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %109 = bitcast <8 x i1> %105 to i8
  %110 = call i8 @llvm.cttz.i8(i8 %109, i1 false)
  %111 = zext i8 %110 to i32
  %112 = select i1 %108, i32 %111, i32 0
  %.spill.load38 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> splat (i64 4096), %.spill.load38
  %.spill.load39 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load39, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 4097)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = select <8 x i1> %105, <8 x i64> %118, <8 x i64> zeroinitializer
  %121 = extractelement <8 x i64> %120, i32 %112
  %122 = zext i32 %112 to i64
  %123 = sub i64 %121, %122
  %124 = mul i64 %123, 4
  %buffer.contiguous.address40 = getelementptr i8, ptr %119, i64 %124
  %buffer.contiguous.load41 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address40, i32 1, <8 x i1> %105, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load42 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 1
  %127 = add <8 x i64> %126, splat (i64 16384)
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %132 = extractelement <8 x ptr> %130, i32 0
  %133 = extractelement <8 x i64> %131, i32 %112
  %134 = zext i32 %112 to i64
  %135 = mul i64 %134, 4
  %136 = sub i64 %133, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %138 = select i1 %137, i64 %136, i64 0
  %private.contiguous.address43 = getelementptr i8, ptr %132, i64 %138
  %private.contiguous.preserve44 = load <8 x float>, ptr %private.contiguous.address43, align 4
  %139 = select <8 x i1> %105, <8 x float> %buffer.contiguous.load41, <8 x float> %private.contiguous.preserve44
  store <8 x float> %139, ptr %private.contiguous.address43, align 4
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %107)
  %141 = bitcast <8 x i1> %107 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  store float 0.000000e+00, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  %tile_snapshot.spill.load45 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load45, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load45, 1
  %147 = add <8 x i64> %146, zeroinitializer
  %148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %149 = insertvalue { <8 x ptr>, <8 x i64> } %148, <8 x i64> %147, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %152 = extractelement <8 x ptr> %150, i32 0
  %153 = extractelement <8 x i64> %151, i32 0
  %154 = sub i64 %153, 0
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %156 = select i1 %155, i64 %154, i64 0
  %private.contiguous.address46 = getelementptr i8, ptr %152, i64 %156
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address46, align 4
  %157 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %158 = fmul <8 x float> %157, %157
  %tile_snapshot.spill.load47 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 0
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 1
  %161 = add <8 x i64> %160, splat (i64 32)
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %163, 1
  %166 = extractelement <8 x ptr> %164, i32 0
  %167 = extractelement <8 x i64> %165, i32 0
  %168 = sub i64 %167, 0
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %170 = select i1 %169, i64 %168, i64 0
  %private.contiguous.address48 = getelementptr i8, ptr %166, i64 %170
  %private.contiguous.load49 = load <8 x float>, ptr %private.contiguous.address48, align 4
  %171 = select <8 x i1> %51, <8 x float> %private.contiguous.load49, <8 x float> zeroinitializer
  %172 = fmul <8 x float> %171, %171
  %tile_snapshot.spill.load50 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 1
  %175 = add <8 x i64> %174, splat (i64 64)
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = extractelement <8 x ptr> %178, i32 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address51 = getelementptr i8, ptr %180, i64 %184
  %private.contiguous.load52 = load <8 x float>, ptr %private.contiguous.address51, align 4
  %185 = select <8 x i1> %51, <8 x float> %private.contiguous.load52, <8 x float> zeroinitializer
  %186 = fmul <8 x float> %185, %185
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %189 = add <8 x i64> %188, splat (i64 96)
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = extractelement <8 x ptr> %192, i32 0
  %195 = extractelement <8 x i64> %193, i32 0
  %196 = sub i64 %195, 0
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %198 = select i1 %197, i64 %196, i64 0
  %private.contiguous.address54 = getelementptr i8, ptr %194, i64 %198
  %private.contiguous.load55 = load <8 x float>, ptr %private.contiguous.address54, align 4
  %199 = select <8 x i1> %51, <8 x float> %private.contiguous.load55, <8 x float> zeroinitializer
  %200 = fmul <8 x float> %199, %199
  %201 = load <8 x i64>, ptr %.slot8, align 64
  %202 = select <8 x i1> %51, <8 x i64> splat (i64 4), <8 x i64> %201
  store <8 x i64> %202, ptr %.slot8, align 64
  %203 = load <8 x float>, ptr %.slot9, align 32
  %204 = select <8 x i1> %51, <8 x float> %158, <8 x float> %203
  store <8 x float> %204, ptr %.slot9, align 32
  %205 = load <8 x float>, ptr %.slot10, align 32
  %206 = select <8 x i1> %51, <8 x float> %172, <8 x float> %205
  store <8 x float> %206, ptr %.slot10, align 32
  %207 = load <8 x float>, ptr %.slot11, align 32
  %208 = select <8 x i1> %51, <8 x float> %186, <8 x float> %207
  store <8 x float> %208, ptr %.slot11, align 32
  %209 = load <8 x float>, ptr %.slot12, align 32
  %210 = select <8 x i1> %51, <8 x float> %200, <8 x float> %209
  store <8 x float> %210, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state56 = load <8 x i64>, ptr %.slot8, align 64
  %211 = icmp slt <8 x i64> %.state56, splat (i64 512)
  %212 = extractelement <8 x i1> %211, i32 0
  br i1 %212, label %direct.true57, label %direct.false58

direct.schedule.7:                                ; preds = %direct.true57
  %.state59 = load <8 x i64>, ptr %.slot8, align 64
  %213 = add <8 x i64> %.state59, zeroinitializer
  %tile_snapshot.spill.load60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 1
  %216 = mul <8 x i64> %213, splat (i64 32)
  %217 = add <8 x i64> %215, %216
  %218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %214, 0
  %219 = insertvalue { <8 x ptr>, <8 x i64> } %218, <8 x i64> %217, 1
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %219, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %222 = getelementptr i8, <8 x ptr> %220, <8 x i64> %221
  %223 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %222, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %224 = fmul <8 x float> %223, %223
  %.state61 = load <8 x float>, ptr %.slot9, align 32
  %225 = fadd <8 x float> %.state61, %224
  %.state62 = load <8 x i64>, ptr %.slot8, align 64
  %226 = add <8 x i64> %.state62, splat (i64 1)
  %tile_snapshot.spill.load63 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 1
  %229 = mul <8 x i64> %226, splat (i64 32)
  %230 = add <8 x i64> %228, %229
  %231 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %227, 0
  %232 = insertvalue { <8 x ptr>, <8 x i64> } %231, <8 x i64> %230, 1
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %232, 0
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %232, 1
  %235 = getelementptr i8, <8 x ptr> %233, <8 x i64> %234
  %236 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %235, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %237 = fmul <8 x float> %236, %236
  %.state64 = load <8 x float>, ptr %.slot10, align 32
  %238 = fadd <8 x float> %.state64, %237
  %.state65 = load <8 x i64>, ptr %.slot8, align 64
  %239 = add <8 x i64> %.state65, splat (i64 2)
  %tile_snapshot.spill.load66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load66, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load66, 1
  %242 = mul <8 x i64> %239, splat (i64 32)
  %243 = add <8 x i64> %241, %242
  %244 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %240, 0
  %245 = insertvalue { <8 x ptr>, <8 x i64> } %244, <8 x i64> %243, 1
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %245, 0
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %245, 1
  %248 = getelementptr i8, <8 x ptr> %246, <8 x i64> %247
  %249 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %248, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %250 = fmul <8 x float> %249, %249
  %.state67 = load <8 x float>, ptr %.slot11, align 32
  %251 = fadd <8 x float> %.state67, %250
  %.state68 = load <8 x i64>, ptr %.slot8, align 64
  %252 = add <8 x i64> %.state68, splat (i64 3)
  %tile_snapshot.spill.load69 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 1
  %255 = mul <8 x i64> %252, splat (i64 32)
  %256 = add <8 x i64> %254, %255
  %257 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %253, 0
  %258 = insertvalue { <8 x ptr>, <8 x i64> } %257, <8 x i64> %256, 1
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %258, 0
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %258, 1
  %261 = getelementptr i8, <8 x ptr> %259, <8 x i64> %260
  %262 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %261, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %263 = fmul <8 x float> %262, %262
  %.state70 = load <8 x float>, ptr %.slot12, align 32
  %264 = fadd <8 x float> %.state70, %263
  %.state71 = load <8 x i64>, ptr %.slot8, align 64
  %265 = add <8 x i64> %.state71, splat (i64 4)
  %266 = load <8 x i64>, ptr %.slot8, align 64
  %267 = select <8 x i1> %51, <8 x i64> %265, <8 x i64> %266
  store <8 x i64> %267, ptr %.slot8, align 64
  %268 = load <8 x float>, ptr %.slot9, align 32
  %269 = select <8 x i1> %51, <8 x float> %225, <8 x float> %268
  store <8 x float> %269, ptr %.slot9, align 32
  %270 = load <8 x float>, ptr %.slot10, align 32
  %271 = select <8 x i1> %51, <8 x float> %238, <8 x float> %270
  store <8 x float> %271, ptr %.slot10, align 32
  %272 = load <8 x float>, ptr %.slot11, align 32
  %273 = select <8 x i1> %51, <8 x float> %251, <8 x float> %272
  store <8 x float> %273, ptr %.slot11, align 32
  %274 = load <8 x float>, ptr %.slot12, align 32
  %275 = select <8 x i1> %51, <8 x float> %264, <8 x float> %274
  store <8 x float> %275, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false58
  %.spill.load72 = load <8 x i1>, ptr %.spill5, align 1
  %276 = and <8 x i1> %51, %.spill.load72
  %277 = xor <8 x i1> %.spill.load72, splat (i1 true)
  %278 = and <8 x i1> %51, %277
  %279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  %280 = bitcast <8 x i1> %276 to i8
  %281 = call i8 @llvm.cttz.i8(i8 %280, i1 false)
  %282 = zext i8 %281 to i32
  %283 = select i1 %279, i32 %282, i32 0
  %tile_snapshot.spill.load73 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 1
  %286 = add <8 x i64> %285, splat (i64 16384)
  %287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %284, 0
  %288 = insertvalue { <8 x ptr>, <8 x i64> } %287, <8 x i64> %286, 1
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %288, 1
  %291 = extractelement <8 x ptr> %289, i32 0
  %292 = extractelement <8 x i64> %290, i32 %283
  %293 = zext i32 %283 to i64
  %294 = mul i64 %293, 4
  %295 = sub i64 %292, %294
  %296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  %297 = select i1 %296, i64 %295, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %291, i64 %297
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %298 = select <8 x i1> %276, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %299 = fmul <8 x float> %298, %298
  %.state76 = load <8 x float>, ptr %.slot9, align 32
  %300 = fadd <8 x float> %.state76, %299
  %301 = load <8 x float>, ptr %.slot13, align 32
  %302 = select <8 x i1> %276, <8 x float> %300, <8 x float> %301
  store <8 x float> %302, ptr %.slot13, align 32
  %303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %278)
  %304 = bitcast <8 x i1> %278 to i8
  %305 = call i8 @llvm.cttz.i8(i8 %304, i1 false)
  %306 = zext i8 %305 to i32
  %307 = select i1 %303, i32 %306, i32 0
  %.state77 = load <8 x float>, ptr %.slot9, align 32
  %308 = load <8 x float>, ptr %.slot13, align 32
  %309 = select <8 x i1> %278, <8 x float> %.state77, <8 x float> %308
  store <8 x float> %309, ptr %.slot13, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.state78 = load <8 x float>, ptr %.slot13, align 32
  %.state79 = load <8 x float>, ptr %.slot10, align 32
  %310 = fadd <8 x float> %.state78, %.state79
  %.state80 = load <8 x float>, ptr %.slot11, align 32
  %311 = fadd <8 x float> %310, %.state80
  %.state81 = load <8 x float>, ptr %.slot12, align 32
  %312 = fadd <8 x float> %311, %.state81
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %313 = trunc <8 x i64> %.spill.load82 to <8 x i32>
  %314 = xor <8 x i32> %313, splat (i32 1)
  %315 = extractelement <8 x i32> %314, i64 0
  %316 = icmp ult i32 %315, 8
  %317 = select i1 %316, i32 %315, i32 0
  %318 = extractelement <8 x i1> %51, i32 %317
  %319 = extractelement <8 x i1> %51, i64 0
  %320 = and i1 %316, %318
  %321 = and i1 %319, %320
  %322 = extractelement <8 x float> %312, i32 %317
  %323 = select i1 %321, float %322, float 0.000000e+00
  %324 = insertelement <8 x float> poison, float %323, i64 0
  %325 = xor i1 %321, true
  %326 = and i1 %319, %325
  %327 = insertelement <8 x i1> poison, i1 %326, i64 0
  %328 = extractelement <8 x i32> %314, i64 1
  %329 = icmp ult i32 %328, 8
  %330 = select i1 %329, i32 %328, i32 0
  %331 = extractelement <8 x i1> %51, i32 %330
  %332 = extractelement <8 x i1> %51, i64 1
  %333 = and i1 %329, %331
  %334 = and i1 %332, %333
  %335 = extractelement <8 x float> %312, i32 %330
  %336 = select i1 %334, float %335, float 0.000000e+00
  %337 = insertelement <8 x float> %324, float %336, i64 1
  %338 = xor i1 %334, true
  %339 = and i1 %332, %338
  %340 = insertelement <8 x i1> %327, i1 %339, i64 1
  %341 = extractelement <8 x i32> %314, i64 2
  %342 = icmp ult i32 %341, 8
  %343 = select i1 %342, i32 %341, i32 0
  %344 = extractelement <8 x i1> %51, i32 %343
  %345 = extractelement <8 x i1> %51, i64 2
  %346 = and i1 %342, %344
  %347 = and i1 %345, %346
  %348 = extractelement <8 x float> %312, i32 %343
  %349 = select i1 %347, float %348, float 0.000000e+00
  %350 = insertelement <8 x float> %337, float %349, i64 2
  %351 = xor i1 %347, true
  %352 = and i1 %345, %351
  %353 = insertelement <8 x i1> %340, i1 %352, i64 2
  %354 = extractelement <8 x i32> %314, i64 3
  %355 = icmp ult i32 %354, 8
  %356 = select i1 %355, i32 %354, i32 0
  %357 = extractelement <8 x i1> %51, i32 %356
  %358 = extractelement <8 x i1> %51, i64 3
  %359 = and i1 %355, %357
  %360 = and i1 %358, %359
  %361 = extractelement <8 x float> %312, i32 %356
  %362 = select i1 %360, float %361, float 0.000000e+00
  %363 = insertelement <8 x float> %350, float %362, i64 3
  %364 = xor i1 %360, true
  %365 = and i1 %358, %364
  %366 = insertelement <8 x i1> %353, i1 %365, i64 3
  %367 = extractelement <8 x i32> %314, i64 4
  %368 = icmp ult i32 %367, 8
  %369 = select i1 %368, i32 %367, i32 0
  %370 = extractelement <8 x i1> %51, i32 %369
  %371 = extractelement <8 x i1> %51, i64 4
  %372 = and i1 %368, %370
  %373 = and i1 %371, %372
  %374 = extractelement <8 x float> %312, i32 %369
  %375 = select i1 %373, float %374, float 0.000000e+00
  %376 = insertelement <8 x float> %363, float %375, i64 4
  %377 = xor i1 %373, true
  %378 = and i1 %371, %377
  %379 = insertelement <8 x i1> %366, i1 %378, i64 4
  %380 = extractelement <8 x i32> %314, i64 5
  %381 = icmp ult i32 %380, 8
  %382 = select i1 %381, i32 %380, i32 0
  %383 = extractelement <8 x i1> %51, i32 %382
  %384 = extractelement <8 x i1> %51, i64 5
  %385 = and i1 %381, %383
  %386 = and i1 %384, %385
  %387 = extractelement <8 x float> %312, i32 %382
  %388 = select i1 %386, float %387, float 0.000000e+00
  %389 = insertelement <8 x float> %376, float %388, i64 5
  %390 = xor i1 %386, true
  %391 = and i1 %384, %390
  %392 = insertelement <8 x i1> %379, i1 %391, i64 5
  %393 = extractelement <8 x i32> %314, i64 6
  %394 = icmp ult i32 %393, 8
  %395 = select i1 %394, i32 %393, i32 0
  %396 = extractelement <8 x i1> %51, i32 %395
  %397 = extractelement <8 x i1> %51, i64 6
  %398 = and i1 %394, %396
  %399 = and i1 %397, %398
  %400 = extractelement <8 x float> %312, i32 %395
  %401 = select i1 %399, float %400, float 0.000000e+00
  %402 = insertelement <8 x float> %389, float %401, i64 6
  %403 = xor i1 %399, true
  %404 = and i1 %397, %403
  %405 = insertelement <8 x i1> %392, i1 %404, i64 6
  %406 = extractelement <8 x i32> %314, i64 7
  %407 = icmp ult i32 %406, 8
  %408 = select i1 %407, i32 %406, i32 0
  %409 = extractelement <8 x i1> %51, i32 %408
  %410 = extractelement <8 x i1> %51, i64 7
  %411 = and i1 %407, %409
  %412 = and i1 %410, %411
  %413 = extractelement <8 x float> %312, i32 %408
  %414 = select i1 %412, float %413, float 0.000000e+00
  %415 = insertelement <8 x float> %402, float %414, i64 7
  %416 = xor i1 %412, true
  %417 = and i1 %410, %416
  %418 = insertelement <8 x i1> %405, i1 %417, i64 7
  %419 = fadd <8 x float> %312, %415
  %420 = xor <8 x i32> %313, splat (i32 2)
  %421 = extractelement <8 x i32> %420, i64 0
  %422 = icmp ult i32 %421, 8
  %423 = select i1 %422, i32 %421, i32 0
  %424 = extractelement <8 x i1> %51, i32 %423
  %425 = extractelement <8 x i1> %51, i64 0
  %426 = and i1 %422, %424
  %427 = and i1 %425, %426
  %428 = extractelement <8 x float> %419, i32 %423
  %429 = select i1 %427, float %428, float 0.000000e+00
  %430 = insertelement <8 x float> poison, float %429, i64 0
  %431 = xor i1 %427, true
  %432 = and i1 %425, %431
  %433 = insertelement <8 x i1> poison, i1 %432, i64 0
  %434 = extractelement <8 x i32> %420, i64 1
  %435 = icmp ult i32 %434, 8
  %436 = select i1 %435, i32 %434, i32 0
  %437 = extractelement <8 x i1> %51, i32 %436
  %438 = extractelement <8 x i1> %51, i64 1
  %439 = and i1 %435, %437
  %440 = and i1 %438, %439
  %441 = extractelement <8 x float> %419, i32 %436
  %442 = select i1 %440, float %441, float 0.000000e+00
  %443 = insertelement <8 x float> %430, float %442, i64 1
  %444 = xor i1 %440, true
  %445 = and i1 %438, %444
  %446 = insertelement <8 x i1> %433, i1 %445, i64 1
  %447 = extractelement <8 x i32> %420, i64 2
  %448 = icmp ult i32 %447, 8
  %449 = select i1 %448, i32 %447, i32 0
  %450 = extractelement <8 x i1> %51, i32 %449
  %451 = extractelement <8 x i1> %51, i64 2
  %452 = and i1 %448, %450
  %453 = and i1 %451, %452
  %454 = extractelement <8 x float> %419, i32 %449
  %455 = select i1 %453, float %454, float 0.000000e+00
  %456 = insertelement <8 x float> %443, float %455, i64 2
  %457 = xor i1 %453, true
  %458 = and i1 %451, %457
  %459 = insertelement <8 x i1> %446, i1 %458, i64 2
  %460 = extractelement <8 x i32> %420, i64 3
  %461 = icmp ult i32 %460, 8
  %462 = select i1 %461, i32 %460, i32 0
  %463 = extractelement <8 x i1> %51, i32 %462
  %464 = extractelement <8 x i1> %51, i64 3
  %465 = and i1 %461, %463
  %466 = and i1 %464, %465
  %467 = extractelement <8 x float> %419, i32 %462
  %468 = select i1 %466, float %467, float 0.000000e+00
  %469 = insertelement <8 x float> %456, float %468, i64 3
  %470 = xor i1 %466, true
  %471 = and i1 %464, %470
  %472 = insertelement <8 x i1> %459, i1 %471, i64 3
  %473 = extractelement <8 x i32> %420, i64 4
  %474 = icmp ult i32 %473, 8
  %475 = select i1 %474, i32 %473, i32 0
  %476 = extractelement <8 x i1> %51, i32 %475
  %477 = extractelement <8 x i1> %51, i64 4
  %478 = and i1 %474, %476
  %479 = and i1 %477, %478
  %480 = extractelement <8 x float> %419, i32 %475
  %481 = select i1 %479, float %480, float 0.000000e+00
  %482 = insertelement <8 x float> %469, float %481, i64 4
  %483 = xor i1 %479, true
  %484 = and i1 %477, %483
  %485 = insertelement <8 x i1> %472, i1 %484, i64 4
  %486 = extractelement <8 x i32> %420, i64 5
  %487 = icmp ult i32 %486, 8
  %488 = select i1 %487, i32 %486, i32 0
  %489 = extractelement <8 x i1> %51, i32 %488
  %490 = extractelement <8 x i1> %51, i64 5
  %491 = and i1 %487, %489
  %492 = and i1 %490, %491
  %493 = extractelement <8 x float> %419, i32 %488
  %494 = select i1 %492, float %493, float 0.000000e+00
  %495 = insertelement <8 x float> %482, float %494, i64 5
  %496 = xor i1 %492, true
  %497 = and i1 %490, %496
  %498 = insertelement <8 x i1> %485, i1 %497, i64 5
  %499 = extractelement <8 x i32> %420, i64 6
  %500 = icmp ult i32 %499, 8
  %501 = select i1 %500, i32 %499, i32 0
  %502 = extractelement <8 x i1> %51, i32 %501
  %503 = extractelement <8 x i1> %51, i64 6
  %504 = and i1 %500, %502
  %505 = and i1 %503, %504
  %506 = extractelement <8 x float> %419, i32 %501
  %507 = select i1 %505, float %506, float 0.000000e+00
  %508 = insertelement <8 x float> %495, float %507, i64 6
  %509 = xor i1 %505, true
  %510 = and i1 %503, %509
  %511 = insertelement <8 x i1> %498, i1 %510, i64 6
  %512 = extractelement <8 x i32> %420, i64 7
  %513 = icmp ult i32 %512, 8
  %514 = select i1 %513, i32 %512, i32 0
  %515 = extractelement <8 x i1> %51, i32 %514
  %516 = extractelement <8 x i1> %51, i64 7
  %517 = and i1 %513, %515
  %518 = and i1 %516, %517
  %519 = extractelement <8 x float> %419, i32 %514
  %520 = select i1 %518, float %519, float 0.000000e+00
  %521 = insertelement <8 x float> %508, float %520, i64 7
  %522 = xor i1 %518, true
  %523 = and i1 %516, %522
  %524 = insertelement <8 x i1> %511, i1 %523, i64 7
  %525 = fadd <8 x float> %419, %521
  %526 = xor <8 x i32> %313, splat (i32 4)
  %527 = extractelement <8 x i32> %526, i64 0
  %528 = icmp ult i32 %527, 8
  %529 = select i1 %528, i32 %527, i32 0
  %530 = extractelement <8 x i1> %51, i32 %529
  %531 = extractelement <8 x i1> %51, i64 0
  %532 = and i1 %528, %530
  %533 = and i1 %531, %532
  %534 = extractelement <8 x float> %525, i32 %529
  %535 = select i1 %533, float %534, float 0.000000e+00
  %536 = insertelement <8 x float> poison, float %535, i64 0
  %537 = xor i1 %533, true
  %538 = and i1 %531, %537
  %539 = insertelement <8 x i1> poison, i1 %538, i64 0
  %540 = extractelement <8 x i32> %526, i64 1
  %541 = icmp ult i32 %540, 8
  %542 = select i1 %541, i32 %540, i32 0
  %543 = extractelement <8 x i1> %51, i32 %542
  %544 = extractelement <8 x i1> %51, i64 1
  %545 = and i1 %541, %543
  %546 = and i1 %544, %545
  %547 = extractelement <8 x float> %525, i32 %542
  %548 = select i1 %546, float %547, float 0.000000e+00
  %549 = insertelement <8 x float> %536, float %548, i64 1
  %550 = xor i1 %546, true
  %551 = and i1 %544, %550
  %552 = insertelement <8 x i1> %539, i1 %551, i64 1
  %553 = extractelement <8 x i32> %526, i64 2
  %554 = icmp ult i32 %553, 8
  %555 = select i1 %554, i32 %553, i32 0
  %556 = extractelement <8 x i1> %51, i32 %555
  %557 = extractelement <8 x i1> %51, i64 2
  %558 = and i1 %554, %556
  %559 = and i1 %557, %558
  %560 = extractelement <8 x float> %525, i32 %555
  %561 = select i1 %559, float %560, float 0.000000e+00
  %562 = insertelement <8 x float> %549, float %561, i64 2
  %563 = xor i1 %559, true
  %564 = and i1 %557, %563
  %565 = insertelement <8 x i1> %552, i1 %564, i64 2
  %566 = extractelement <8 x i32> %526, i64 3
  %567 = icmp ult i32 %566, 8
  %568 = select i1 %567, i32 %566, i32 0
  %569 = extractelement <8 x i1> %51, i32 %568
  %570 = extractelement <8 x i1> %51, i64 3
  %571 = and i1 %567, %569
  %572 = and i1 %570, %571
  %573 = extractelement <8 x float> %525, i32 %568
  %574 = select i1 %572, float %573, float 0.000000e+00
  %575 = insertelement <8 x float> %562, float %574, i64 3
  %576 = xor i1 %572, true
  %577 = and i1 %570, %576
  %578 = insertelement <8 x i1> %565, i1 %577, i64 3
  %579 = extractelement <8 x i32> %526, i64 4
  %580 = icmp ult i32 %579, 8
  %581 = select i1 %580, i32 %579, i32 0
  %582 = extractelement <8 x i1> %51, i32 %581
  %583 = extractelement <8 x i1> %51, i64 4
  %584 = and i1 %580, %582
  %585 = and i1 %583, %584
  %586 = extractelement <8 x float> %525, i32 %581
  %587 = select i1 %585, float %586, float 0.000000e+00
  %588 = insertelement <8 x float> %575, float %587, i64 4
  %589 = xor i1 %585, true
  %590 = and i1 %583, %589
  %591 = insertelement <8 x i1> %578, i1 %590, i64 4
  %592 = extractelement <8 x i32> %526, i64 5
  %593 = icmp ult i32 %592, 8
  %594 = select i1 %593, i32 %592, i32 0
  %595 = extractelement <8 x i1> %51, i32 %594
  %596 = extractelement <8 x i1> %51, i64 5
  %597 = and i1 %593, %595
  %598 = and i1 %596, %597
  %599 = extractelement <8 x float> %525, i32 %594
  %600 = select i1 %598, float %599, float 0.000000e+00
  %601 = insertelement <8 x float> %588, float %600, i64 5
  %602 = xor i1 %598, true
  %603 = and i1 %596, %602
  %604 = insertelement <8 x i1> %591, i1 %603, i64 5
  %605 = extractelement <8 x i32> %526, i64 6
  %606 = icmp ult i32 %605, 8
  %607 = select i1 %606, i32 %605, i32 0
  %608 = extractelement <8 x i1> %51, i32 %607
  %609 = extractelement <8 x i1> %51, i64 6
  %610 = and i1 %606, %608
  %611 = and i1 %609, %610
  %612 = extractelement <8 x float> %525, i32 %607
  %613 = select i1 %611, float %612, float 0.000000e+00
  %614 = insertelement <8 x float> %601, float %613, i64 6
  %615 = xor i1 %611, true
  %616 = and i1 %609, %615
  %617 = insertelement <8 x i1> %604, i1 %616, i64 6
  %618 = extractelement <8 x i32> %526, i64 7
  %619 = icmp ult i32 %618, 8
  %620 = select i1 %619, i32 %618, i32 0
  %621 = extractelement <8 x i1> %51, i32 %620
  %622 = extractelement <8 x i1> %51, i64 7
  %623 = and i1 %619, %621
  %624 = and i1 %622, %623
  %625 = extractelement <8 x float> %525, i32 %620
  %626 = select i1 %624, float %625, float 0.000000e+00
  %627 = insertelement <8 x float> %614, float %626, i64 7
  %628 = xor i1 %624, true
  %629 = and i1 %622, %628
  %630 = insertelement <8 x i1> %617, i1 %629, i64 7
  %631 = fadd <8 x float> %525, %627
  %632 = extractelement <8 x i1> %51, i32 0
  %633 = extractelement <8 x i1> %51, i64 0
  %634 = and i1 true, %632
  %635 = and i1 %633, %634
  %636 = extractelement <8 x float> %631, i32 0
  %637 = select i1 %635, float %636, float 0.000000e+00
  %638 = insertelement <8 x float> poison, float %637, i64 0
  %639 = xor i1 %635, true
  %640 = and i1 %633, %639
  %641 = insertelement <8 x i1> poison, i1 %640, i64 0
  %642 = extractelement <8 x i1> %51, i32 0
  %643 = extractelement <8 x i1> %51, i64 1
  %644 = and i1 true, %642
  %645 = and i1 %643, %644
  %646 = extractelement <8 x float> %631, i32 0
  %647 = select i1 %645, float %646, float 0.000000e+00
  %648 = insertelement <8 x float> %638, float %647, i64 1
  %649 = xor i1 %645, true
  %650 = and i1 %643, %649
  %651 = insertelement <8 x i1> %641, i1 %650, i64 1
  %652 = extractelement <8 x i1> %51, i32 0
  %653 = extractelement <8 x i1> %51, i64 2
  %654 = and i1 true, %652
  %655 = and i1 %653, %654
  %656 = extractelement <8 x float> %631, i32 0
  %657 = select i1 %655, float %656, float 0.000000e+00
  %658 = insertelement <8 x float> %648, float %657, i64 2
  %659 = xor i1 %655, true
  %660 = and i1 %653, %659
  %661 = insertelement <8 x i1> %651, i1 %660, i64 2
  %662 = extractelement <8 x i1> %51, i32 0
  %663 = extractelement <8 x i1> %51, i64 3
  %664 = and i1 true, %662
  %665 = and i1 %663, %664
  %666 = extractelement <8 x float> %631, i32 0
  %667 = select i1 %665, float %666, float 0.000000e+00
  %668 = insertelement <8 x float> %658, float %667, i64 3
  %669 = xor i1 %665, true
  %670 = and i1 %663, %669
  %671 = insertelement <8 x i1> %661, i1 %670, i64 3
  %672 = extractelement <8 x i1> %51, i32 0
  %673 = extractelement <8 x i1> %51, i64 4
  %674 = and i1 true, %672
  %675 = and i1 %673, %674
  %676 = extractelement <8 x float> %631, i32 0
  %677 = select i1 %675, float %676, float 0.000000e+00
  %678 = insertelement <8 x float> %668, float %677, i64 4
  %679 = xor i1 %675, true
  %680 = and i1 %673, %679
  %681 = insertelement <8 x i1> %671, i1 %680, i64 4
  %682 = extractelement <8 x i1> %51, i32 0
  %683 = extractelement <8 x i1> %51, i64 5
  %684 = and i1 true, %682
  %685 = and i1 %683, %684
  %686 = extractelement <8 x float> %631, i32 0
  %687 = select i1 %685, float %686, float 0.000000e+00
  %688 = insertelement <8 x float> %678, float %687, i64 5
  %689 = xor i1 %685, true
  %690 = and i1 %683, %689
  %691 = insertelement <8 x i1> %681, i1 %690, i64 5
  %692 = extractelement <8 x i1> %51, i32 0
  %693 = extractelement <8 x i1> %51, i64 6
  %694 = and i1 true, %692
  %695 = and i1 %693, %694
  %696 = extractelement <8 x float> %631, i32 0
  %697 = select i1 %695, float %696, float 0.000000e+00
  %698 = insertelement <8 x float> %688, float %697, i64 6
  %699 = xor i1 %695, true
  %700 = and i1 %693, %699
  %701 = insertelement <8 x i1> %691, i1 %700, i64 6
  %702 = extractelement <8 x i1> %51, i32 0
  %703 = extractelement <8 x i1> %51, i64 7
  %704 = and i1 true, %702
  %705 = and i1 %703, %704
  %706 = extractelement <8 x float> %631, i32 0
  %707 = select i1 %705, float %706, float 0.000000e+00
  %708 = insertelement <8 x float> %698, float %707, i64 7
  %709 = xor i1 %705, true
  %710 = and i1 %703, %709
  %711 = insertelement <8 x i1> %701, i1 %710, i64 7
  %712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %713 = bitcast <8 x i1> %51 to i8
  %714 = call i8 @llvm.cttz.i8(i8 %713, i1 false)
  %715 = zext i8 %714 to i32
  %716 = select i1 %712, i32 %715, i32 0
  %717 = extractelement <8 x float> %708, i32 %716
  %.spill.load83 = load float, ptr %.spill6, align 4
  %718 = fadd float %.spill.load83, %717
  %719 = fdiv float %718, 4.097000e+03
  store float %719, ptr %.spill14, align 4
  %720 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %720, 0
  %723 = select <8 x i1> %51, <8 x ptr> %721, <8 x ptr> %722
  %724 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %720, 1
  %726 = select <8 x i1> %51, <8 x i64> %724, <8 x i64> %725
  %727 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %723, 0
  %728 = insertvalue { <8 x ptr>, <8 x i64> } %727, <8 x i64> %726, 1
  store { <8 x ptr>, <8 x i64> } %728, ptr %tile_snapshot.spill15, align 64
  %729 = load <8 x i64>, ptr %.slot16, align 64
  %730 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %729
  store <8 x i64> %730, ptr %.slot16, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state84 = load <8 x i64>, ptr %.slot16, align 64
  %731 = icmp slt <8 x i64> %.state84, splat (i64 512)
  %732 = extractelement <8 x i1> %731, i32 0
  br i1 %732, label %direct.true85, label %direct.false86

direct.schedule.12:                               ; preds = %direct.true85
  %.state87 = load <8 x i64>, ptr %.slot16, align 64
  %733 = mul <8 x i64> %.state87, splat (i64 8)
  %.spill.load88 = load <8 x i64>, ptr %.spill, align 64
  %734 = add <8 x i64> %733, %.spill.load88
  %.spill.load89 = load i64, ptr %.spill7, align 4
  %735 = add i64 %.spill.load89, 0
  %736 = add <8 x i64> zeroinitializer, %734
  %737 = mul i64 %735, 4097
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %737, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %738 = add <8 x i64> %.splat91, %736
  %739 = extractvalue { ptr, i64 } %15, 0
  %740 = extractelement <8 x i64> %738, i32 0
  %741 = sub i64 %740, 0
  %742 = mul i64 %741, 4
  %buffer.contiguous.address92 = getelementptr i8, ptr %739, i64 %742
  %buffer.contiguous.load93 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address92, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 1
  %.state95 = load <8 x i64>, ptr %.slot16, align 64
  %745 = mul <8 x i64> %.state95, splat (i64 32)
  %746 = add <8 x i64> %744, %745
  %747 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %743, 0
  %748 = insertvalue { <8 x ptr>, <8 x i64> } %747, <8 x i64> %746, 1
  %749 = extractvalue { <8 x ptr>, <8 x i64> } %748, 0
  %750 = extractvalue { <8 x ptr>, <8 x i64> } %748, 1
  %751 = getelementptr i8, <8 x ptr> %749, <8 x i64> %750
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %buffer.contiguous.load93, <8 x ptr> %751, i32 1, <8 x i1> %51)
  %.state96 = load <8 x i64>, ptr %.slot16, align 64
  %752 = add <8 x i64> %.state96, splat (i64 1)
  %753 = load <8 x i64>, ptr %.slot16, align 64
  %754 = select <8 x i1> %51, <8 x i64> %752, <8 x i64> %753
  store <8 x i64> %754, ptr %.slot16, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false86
  %.spill.load97 = load <8 x i1>, ptr %.spill5, align 1
  %755 = and <8 x i1> %51, %.spill.load97
  %756 = xor <8 x i1> %.spill.load97, splat (i1 true)
  %757 = and <8 x i1> %51, %756
  %758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %755)
  %759 = bitcast <8 x i1> %755 to i8
  %760 = call i8 @llvm.cttz.i8(i8 %759, i1 false)
  %761 = zext i8 %760 to i32
  %762 = select i1 %758, i32 %761, i32 0
  %.spill.load98 = load <8 x i64>, ptr %.spill, align 64
  %763 = add <8 x i64> splat (i64 4096), %.spill.load98
  %.spill.load99 = load i64, ptr %.spill7, align 4
  %764 = add i64 %.spill.load99, 0
  %765 = add <8 x i64> zeroinitializer, %763
  %766 = mul i64 %764, 4097
  %.splatinsert100 = insertelement <8 x i64> poison, i64 %766, i64 0
  %.splat101 = shufflevector <8 x i64> %.splatinsert100, <8 x i64> poison, <8 x i32> zeroinitializer
  %767 = add <8 x i64> %.splat101, %765
  %768 = extractvalue { ptr, i64 } %15, 0
  %769 = select <8 x i1> %755, <8 x i64> %767, <8 x i64> zeroinitializer
  %770 = extractelement <8 x i64> %769, i32 %762
  %771 = zext i32 %762 to i64
  %772 = sub i64 %770, %771
  %773 = mul i64 %772, 4
  %buffer.contiguous.address102 = getelementptr i8, ptr %768, i64 %773
  %buffer.contiguous.load103 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address102, i32 1, <8 x i1> %755, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load104 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load104, 0
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load104, 1
  %776 = add <8 x i64> %775, splat (i64 16384)
  %777 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %774, 0
  %778 = insertvalue { <8 x ptr>, <8 x i64> } %777, <8 x i64> %776, 1
  %779 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %778, 1
  %781 = extractelement <8 x ptr> %779, i32 0
  %782 = extractelement <8 x i64> %780, i32 %762
  %783 = zext i32 %762 to i64
  %784 = mul i64 %783, 4
  %785 = sub i64 %782, %784
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %755)
  %787 = select i1 %786, i64 %785, i64 0
  %private.contiguous.address105 = getelementptr i8, ptr %781, i64 %787
  %private.contiguous.preserve106 = load <8 x float>, ptr %private.contiguous.address105, align 4
  %788 = select <8 x i1> %755, <8 x float> %buffer.contiguous.load103, <8 x float> %private.contiguous.preserve106
  store <8 x float> %788, ptr %private.contiguous.address105, align 4
  %789 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %757)
  %790 = bitcast <8 x i1> %757 to i8
  %791 = call i8 @llvm.cttz.i8(i8 %790, i1 false)
  %792 = zext i8 %791 to i32
  %793 = select i1 %789, i32 %792, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %.spill.load107 = load float, ptr %.spill14, align 4
  %794 = fadd float %.spill.load107, 0x3EE4F8B580000000
  %795 = call float @llvm.sqrt.f32(float %794)
  store float %795, ptr %.spill17, align 4
  %796 = load <8 x i64>, ptr %.slot18, align 64
  %797 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %796
  store <8 x i64> %797, ptr %.slot18, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state108 = load <8 x i64>, ptr %.slot18, align 64
  %798 = icmp slt <8 x i64> %.state108, splat (i64 512)
  %799 = extractelement <8 x i1> %798, i32 0
  br i1 %799, label %direct.true109, label %direct.false110

direct.schedule.17:                               ; preds = %direct.true109
  %.state111 = load <8 x i64>, ptr %.slot18, align 64
  %800 = mul <8 x i64> %.state111, splat (i64 8)
  %.spill.load112 = load <8 x i64>, ptr %.spill, align 64
  %801 = add <8 x i64> %800, %.spill.load112
  %.spill.load113 = load <8 x i64>, ptr %.spill4, align 64
  %802 = add <8 x i64> %.spill.load113, zeroinitializer
  %803 = add <8 x i64> zeroinitializer, %802
  %804 = add <8 x i64> zeroinitializer, %801
  %805 = mul <8 x i64> %803, splat (i64 4097)
  %806 = add <8 x i64> %805, %804
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %.state115 = load <8 x i64>, ptr %.slot18, align 64
  %809 = mul <8 x i64> %.state115, splat (i64 32)
  %810 = add <8 x i64> %808, %809
  %811 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %807, 0
  %812 = insertvalue { <8 x ptr>, <8 x i64> } %811, <8 x i64> %810, 1
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %812, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %812, 1
  %815 = getelementptr i8, <8 x ptr> %813, <8 x i64> %814
  %816 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %815, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %.spill.load116 = load float, ptr %.spill17, align 4
  %.splatinsert117 = insertelement <8 x float> poison, float %.spill.load116, i64 0
  %.splat118 = shufflevector <8 x float> %.splatinsert117, <8 x float> poison, <8 x i32> zeroinitializer
  %817 = fdiv <8 x float> %816, %.splat118
  %tile_snapshot.spill.load119 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 0
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 1
  %.state120 = load <8 x i64>, ptr %.slot18, align 64
  %820 = mul <8 x i64> %.state120, splat (i64 32)
  %821 = add <8 x i64> %819, %820
  %822 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %818, 0
  %823 = insertvalue { <8 x ptr>, <8 x i64> } %822, <8 x i64> %821, 1
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %823, 0
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %823, 1
  %826 = getelementptr i8, <8 x ptr> %824, <8 x i64> %825
  %827 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %826, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %828 = fmul <8 x float> %817, %827
  %829 = extractvalue { ptr, i64 } %27, 0
  %830 = extractelement <8 x i64> %806, i32 0
  %831 = sub i64 %830, 0
  %832 = mul i64 %831, 4
  %buffer.contiguous.address121 = getelementptr i8, ptr %829, i64 %832
  call void @llvm.masked.store.v8f32.p0(<8 x float> %828, ptr %buffer.contiguous.address121, i32 1, <8 x i1> %51)
  %.state122 = load <8 x i64>, ptr %.slot18, align 64
  %833 = add <8 x i64> %.state122, splat (i64 1)
  %834 = load <8 x i64>, ptr %.slot18, align 64
  %835 = select <8 x i1> %51, <8 x i64> %833, <8 x i64> %834
  store <8 x i64> %835, ptr %.slot18, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false110
  %.spill.load123 = load <8 x i1>, ptr %.spill5, align 1
  %836 = and <8 x i1> %51, %.spill.load123
  %837 = xor <8 x i1> %.spill.load123, splat (i1 true)
  %838 = and <8 x i1> %51, %837
  %839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %836)
  %840 = bitcast <8 x i1> %836 to i8
  %841 = call i8 @llvm.cttz.i8(i8 %840, i1 false)
  %842 = zext i8 %841 to i32
  %843 = select i1 %839, i32 %842, i32 0
  %.spill.load124 = load <8 x i64>, ptr %.spill, align 64
  %844 = add <8 x i64> splat (i64 4096), %.spill.load124
  %.spill.load125 = load <8 x i64>, ptr %.spill4, align 64
  %845 = add <8 x i64> %.spill.load125, zeroinitializer
  %846 = add <8 x i64> zeroinitializer, %845
  %847 = add <8 x i64> zeroinitializer, %844
  %848 = mul <8 x i64> %846, splat (i64 4097)
  %849 = add <8 x i64> %848, %847
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %852 = add <8 x i64> %851, splat (i64 16384)
  %853 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %850, 0
  %854 = insertvalue { <8 x ptr>, <8 x i64> } %853, <8 x i64> %852, 1
  %855 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %854, 1
  %857 = extractelement <8 x ptr> %855, i32 0
  %858 = extractelement <8 x i64> %856, i32 %843
  %859 = zext i32 %843 to i64
  %860 = mul i64 %859, 4
  %861 = sub i64 %858, %860
  %862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %836)
  %863 = select i1 %862, i64 %861, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %857, i64 %863
  %private.contiguous.load128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %864 = select <8 x i1> %836, <8 x float> %private.contiguous.load128, <8 x float> zeroinitializer
  %.spill.load129 = load float, ptr %.spill17, align 4
  %.splatinsert130 = insertelement <8 x float> poison, float %.spill.load129, i64 0
  %.splat131 = shufflevector <8 x float> %.splatinsert130, <8 x float> poison, <8 x i32> zeroinitializer
  %865 = fdiv <8 x float> %864, %.splat131
  %tile_snapshot.spill.load132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 0
  %867 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 1
  %868 = add <8 x i64> %867, splat (i64 16384)
  %869 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %866, 0
  %870 = insertvalue { <8 x ptr>, <8 x i64> } %869, <8 x i64> %868, 1
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %870, 1
  %873 = extractelement <8 x ptr> %871, i32 0
  %874 = extractelement <8 x i64> %872, i32 %843
  %875 = zext i32 %843 to i64
  %876 = mul i64 %875, 4
  %877 = sub i64 %874, %876
  %878 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %836)
  %879 = select i1 %878, i64 %877, i64 0
  %private.contiguous.address133 = getelementptr i8, ptr %873, i64 %879
  %private.contiguous.load134 = load <8 x float>, ptr %private.contiguous.address133, align 4
  %880 = select <8 x i1> %836, <8 x float> %private.contiguous.load134, <8 x float> zeroinitializer
  %881 = fmul <8 x float> %865, %880
  %882 = extractvalue { ptr, i64 } %27, 0
  %883 = extractelement <8 x i64> %849, i32 %843
  %884 = zext i32 %843 to i64
  %885 = sub i64 %883, %884
  %886 = mul i64 %885, 4
  %buffer.contiguous.address135 = getelementptr i8, ptr %882, i64 %886
  call void @llvm.masked.store.v8f32.p0(<8 x float> %881, ptr %buffer.contiguous.address135, i32 1, <8 x i1> %836)
  %887 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %838)
  %888 = bitcast <8 x i1> %838 to i8
  %889 = call i8 @llvm.cttz.i8(i8 %888, i1 false)
  %890 = zext i8 %889 to i32
  %891 = select i1 %887, i32 %890, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true57:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false58:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true85:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false86:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true109:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false110:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), i32 immarg, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, i32 immarg, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, i32 immarg, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), i32 immarg, <8 x i1>) #4

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [16416 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16416 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %.spill6 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill6, align 4
  %.spill7 = alloca i64, align 8
  store i64 0, ptr %.spill7, align 4
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.slot13 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot13, align 32
  %.spill14 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill14, align 4
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot16, align 64
  %.spill17 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill17, align 4
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat20, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat22, %41
  %44 = mul i32 %32, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat24, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat26, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert27 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat28
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 512
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state29 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state29, 8
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat31, %.spill.load
  %.spill.load32 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load32, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 4097)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state33 = load i64, ptr %.slot, align 4
  %.splatinsert34 = insertelement <8 x i64> poison, i64 %.state33, i64 0
  %.splat35 = shufflevector <8 x i64> %.splatinsert34, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat35, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state36 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state36, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load37 = load <8 x i64>, ptr %.spill, align 64
  %102 = icmp slt <8 x i64> %.spill.load37, splat (i64 1)
  %103 = load <8 x i1>, ptr %.spill5, align 1
  %104 = select <8 x i1> %51, <8 x i1> %102, <8 x i1> %103
  store <8 x i1> %104, ptr %.spill5, align 1
  %105 = and <8 x i1> %51, %102
  %106 = xor <8 x i1> %102, splat (i1 true)
  %107 = and <8 x i1> %51, %106
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %109 = bitcast <8 x i1> %105 to i8
  %110 = call i8 @llvm.cttz.i8(i8 %109, i1 false)
  %111 = zext i8 %110 to i32
  %112 = select i1 %108, i32 %111, i32 0
  %.spill.load38 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> splat (i64 4096), %.spill.load38
  %.spill.load39 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load39, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 4097)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = select <8 x i1> %105, <8 x i64> %118, <8 x i64> zeroinitializer
  %121 = extractelement <8 x i64> %120, i32 %112
  %122 = zext i32 %112 to i64
  %123 = sub i64 %121, %122
  %124 = mul i64 %123, 4
  %buffer.contiguous.address40 = getelementptr i8, ptr %119, i64 %124
  %buffer.contiguous.load41 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address40, i32 1, <8 x i1> %105, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load42 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 1
  %127 = add <8 x i64> %126, splat (i64 16384)
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %132 = extractelement <8 x ptr> %130, i32 0
  %133 = extractelement <8 x i64> %131, i32 %112
  %134 = zext i32 %112 to i64
  %135 = mul i64 %134, 4
  %136 = sub i64 %133, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %138 = select i1 %137, i64 %136, i64 0
  %private.contiguous.address43 = getelementptr i8, ptr %132, i64 %138
  %private.contiguous.preserve44 = load <8 x float>, ptr %private.contiguous.address43, align 4
  %139 = select <8 x i1> %105, <8 x float> %buffer.contiguous.load41, <8 x float> %private.contiguous.preserve44
  store <8 x float> %139, ptr %private.contiguous.address43, align 4
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %107)
  %141 = bitcast <8 x i1> %107 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  store float 0.000000e+00, ptr %.spill6, align 4
  store i64 0, ptr %.spill7, align 4
  %tile_snapshot.spill.load45 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load45, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load45, 1
  %147 = add <8 x i64> %146, zeroinitializer
  %148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %149 = insertvalue { <8 x ptr>, <8 x i64> } %148, <8 x i64> %147, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %152 = extractelement <8 x ptr> %150, i32 0
  %153 = extractelement <8 x i64> %151, i32 0
  %154 = sub i64 %153, 0
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %156 = select i1 %155, i64 %154, i64 0
  %private.contiguous.address46 = getelementptr i8, ptr %152, i64 %156
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address46, align 4
  %157 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %158 = fmul <8 x float> %157, %157
  %tile_snapshot.spill.load47 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 0
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 1
  %161 = add <8 x i64> %160, splat (i64 32)
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %163, 1
  %166 = extractelement <8 x ptr> %164, i32 0
  %167 = extractelement <8 x i64> %165, i32 0
  %168 = sub i64 %167, 0
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %170 = select i1 %169, i64 %168, i64 0
  %private.contiguous.address48 = getelementptr i8, ptr %166, i64 %170
  %private.contiguous.load49 = load <8 x float>, ptr %private.contiguous.address48, align 4
  %171 = select <8 x i1> %51, <8 x float> %private.contiguous.load49, <8 x float> zeroinitializer
  %172 = fmul <8 x float> %171, %171
  %tile_snapshot.spill.load50 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load50, 1
  %175 = add <8 x i64> %174, splat (i64 64)
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = extractelement <8 x ptr> %178, i32 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address51 = getelementptr i8, ptr %180, i64 %184
  %private.contiguous.load52 = load <8 x float>, ptr %private.contiguous.address51, align 4
  %185 = select <8 x i1> %51, <8 x float> %private.contiguous.load52, <8 x float> zeroinitializer
  %186 = fmul <8 x float> %185, %185
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %189 = add <8 x i64> %188, splat (i64 96)
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = extractelement <8 x ptr> %192, i32 0
  %195 = extractelement <8 x i64> %193, i32 0
  %196 = sub i64 %195, 0
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %198 = select i1 %197, i64 %196, i64 0
  %private.contiguous.address54 = getelementptr i8, ptr %194, i64 %198
  %private.contiguous.load55 = load <8 x float>, ptr %private.contiguous.address54, align 4
  %199 = select <8 x i1> %51, <8 x float> %private.contiguous.load55, <8 x float> zeroinitializer
  %200 = fmul <8 x float> %199, %199
  %201 = load <8 x i64>, ptr %.slot8, align 64
  %202 = select <8 x i1> %51, <8 x i64> splat (i64 4), <8 x i64> %201
  store <8 x i64> %202, ptr %.slot8, align 64
  %203 = load <8 x float>, ptr %.slot9, align 32
  %204 = select <8 x i1> %51, <8 x float> %158, <8 x float> %203
  store <8 x float> %204, ptr %.slot9, align 32
  %205 = load <8 x float>, ptr %.slot10, align 32
  %206 = select <8 x i1> %51, <8 x float> %172, <8 x float> %205
  store <8 x float> %206, ptr %.slot10, align 32
  %207 = load <8 x float>, ptr %.slot11, align 32
  %208 = select <8 x i1> %51, <8 x float> %186, <8 x float> %207
  store <8 x float> %208, ptr %.slot11, align 32
  %209 = load <8 x float>, ptr %.slot12, align 32
  %210 = select <8 x i1> %51, <8 x float> %200, <8 x float> %209
  store <8 x float> %210, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state56 = load <8 x i64>, ptr %.slot8, align 64
  %211 = icmp slt <8 x i64> %.state56, splat (i64 512)
  %212 = extractelement <8 x i1> %211, i32 0
  br i1 %212, label %direct.true57, label %direct.false58

direct.schedule.7:                                ; preds = %direct.true57
  %.state59 = load <8 x i64>, ptr %.slot8, align 64
  %213 = add <8 x i64> %.state59, zeroinitializer
  %tile_snapshot.spill.load60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 1
  %216 = mul <8 x i64> %213, splat (i64 32)
  %217 = add <8 x i64> %215, %216
  %218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %214, 0
  %219 = insertvalue { <8 x ptr>, <8 x i64> } %218, <8 x i64> %217, 1
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %219, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %222 = getelementptr i8, <8 x ptr> %220, <8 x i64> %221
  %223 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %222, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %224 = fmul <8 x float> %223, %223
  %.state61 = load <8 x float>, ptr %.slot9, align 32
  %225 = fadd <8 x float> %.state61, %224
  %.state62 = load <8 x i64>, ptr %.slot8, align 64
  %226 = add <8 x i64> %.state62, splat (i64 1)
  %tile_snapshot.spill.load63 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load63, 1
  %229 = mul <8 x i64> %226, splat (i64 32)
  %230 = add <8 x i64> %228, %229
  %231 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %227, 0
  %232 = insertvalue { <8 x ptr>, <8 x i64> } %231, <8 x i64> %230, 1
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %232, 0
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %232, 1
  %235 = getelementptr i8, <8 x ptr> %233, <8 x i64> %234
  %236 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %235, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %237 = fmul <8 x float> %236, %236
  %.state64 = load <8 x float>, ptr %.slot10, align 32
  %238 = fadd <8 x float> %.state64, %237
  %.state65 = load <8 x i64>, ptr %.slot8, align 64
  %239 = add <8 x i64> %.state65, splat (i64 2)
  %tile_snapshot.spill.load66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load66, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load66, 1
  %242 = mul <8 x i64> %239, splat (i64 32)
  %243 = add <8 x i64> %241, %242
  %244 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %240, 0
  %245 = insertvalue { <8 x ptr>, <8 x i64> } %244, <8 x i64> %243, 1
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %245, 0
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %245, 1
  %248 = getelementptr i8, <8 x ptr> %246, <8 x i64> %247
  %249 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %248, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %250 = fmul <8 x float> %249, %249
  %.state67 = load <8 x float>, ptr %.slot11, align 32
  %251 = fadd <8 x float> %.state67, %250
  %.state68 = load <8 x i64>, ptr %.slot8, align 64
  %252 = add <8 x i64> %.state68, splat (i64 3)
  %tile_snapshot.spill.load69 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 1
  %255 = mul <8 x i64> %252, splat (i64 32)
  %256 = add <8 x i64> %254, %255
  %257 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %253, 0
  %258 = insertvalue { <8 x ptr>, <8 x i64> } %257, <8 x i64> %256, 1
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %258, 0
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %258, 1
  %261 = getelementptr i8, <8 x ptr> %259, <8 x i64> %260
  %262 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %261, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %263 = fmul <8 x float> %262, %262
  %.state70 = load <8 x float>, ptr %.slot12, align 32
  %264 = fadd <8 x float> %.state70, %263
  %.state71 = load <8 x i64>, ptr %.slot8, align 64
  %265 = add <8 x i64> %.state71, splat (i64 4)
  %266 = load <8 x i64>, ptr %.slot8, align 64
  %267 = select <8 x i1> %51, <8 x i64> %265, <8 x i64> %266
  store <8 x i64> %267, ptr %.slot8, align 64
  %268 = load <8 x float>, ptr %.slot9, align 32
  %269 = select <8 x i1> %51, <8 x float> %225, <8 x float> %268
  store <8 x float> %269, ptr %.slot9, align 32
  %270 = load <8 x float>, ptr %.slot10, align 32
  %271 = select <8 x i1> %51, <8 x float> %238, <8 x float> %270
  store <8 x float> %271, ptr %.slot10, align 32
  %272 = load <8 x float>, ptr %.slot11, align 32
  %273 = select <8 x i1> %51, <8 x float> %251, <8 x float> %272
  store <8 x float> %273, ptr %.slot11, align 32
  %274 = load <8 x float>, ptr %.slot12, align 32
  %275 = select <8 x i1> %51, <8 x float> %264, <8 x float> %274
  store <8 x float> %275, ptr %.slot12, align 32
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false58
  %.spill.load72 = load <8 x i1>, ptr %.spill5, align 1
  %276 = and <8 x i1> %51, %.spill.load72
  %277 = xor <8 x i1> %.spill.load72, splat (i1 true)
  %278 = and <8 x i1> %51, %277
  %279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  %280 = bitcast <8 x i1> %276 to i8
  %281 = call i8 @llvm.cttz.i8(i8 %280, i1 false)
  %282 = zext i8 %281 to i32
  %283 = select i1 %279, i32 %282, i32 0
  %tile_snapshot.spill.load73 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 0
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 1
  %286 = add <8 x i64> %285, splat (i64 16384)
  %287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %284, 0
  %288 = insertvalue { <8 x ptr>, <8 x i64> } %287, <8 x i64> %286, 1
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %288, 1
  %291 = extractelement <8 x ptr> %289, i32 0
  %292 = extractelement <8 x i64> %290, i32 %283
  %293 = zext i32 %283 to i64
  %294 = mul i64 %293, 4
  %295 = sub i64 %292, %294
  %296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  %297 = select i1 %296, i64 %295, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %291, i64 %297
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %298 = select <8 x i1> %276, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %299 = fmul <8 x float> %298, %298
  %.state76 = load <8 x float>, ptr %.slot9, align 32
  %300 = fadd <8 x float> %.state76, %299
  %301 = load <8 x float>, ptr %.slot13, align 32
  %302 = select <8 x i1> %276, <8 x float> %300, <8 x float> %301
  store <8 x float> %302, ptr %.slot13, align 32
  %303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %278)
  %304 = bitcast <8 x i1> %278 to i8
  %305 = call i8 @llvm.cttz.i8(i8 %304, i1 false)
  %306 = zext i8 %305 to i32
  %307 = select i1 %303, i32 %306, i32 0
  %.state77 = load <8 x float>, ptr %.slot9, align 32
  %308 = load <8 x float>, ptr %.slot13, align 32
  %309 = select <8 x i1> %278, <8 x float> %.state77, <8 x float> %308
  store <8 x float> %309, ptr %.slot13, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.state78 = load <8 x float>, ptr %.slot13, align 32
  %.state79 = load <8 x float>, ptr %.slot10, align 32
  %310 = fadd <8 x float> %.state78, %.state79
  %.state80 = load <8 x float>, ptr %.slot11, align 32
  %311 = fadd <8 x float> %310, %.state80
  %.state81 = load <8 x float>, ptr %.slot12, align 32
  %312 = fadd <8 x float> %311, %.state81
  %.spill.load82 = load <8 x i64>, ptr %.spill, align 64
  %313 = trunc <8 x i64> %.spill.load82 to <8 x i32>
  %314 = xor <8 x i32> %313, splat (i32 1)
  %315 = extractelement <8 x i32> %314, i64 0
  %316 = icmp ult i32 %315, 8
  %317 = select i1 %316, i32 %315, i32 0
  %318 = extractelement <8 x i1> %51, i32 %317
  %319 = extractelement <8 x i1> %51, i64 0
  %320 = and i1 %316, %318
  %321 = and i1 %319, %320
  %322 = extractelement <8 x float> %312, i32 %317
  %323 = select i1 %321, float %322, float 0.000000e+00
  %324 = insertelement <8 x float> poison, float %323, i64 0
  %325 = xor i1 %321, true
  %326 = and i1 %319, %325
  %327 = insertelement <8 x i1> poison, i1 %326, i64 0
  %328 = extractelement <8 x i32> %314, i64 1
  %329 = icmp ult i32 %328, 8
  %330 = select i1 %329, i32 %328, i32 0
  %331 = extractelement <8 x i1> %51, i32 %330
  %332 = extractelement <8 x i1> %51, i64 1
  %333 = and i1 %329, %331
  %334 = and i1 %332, %333
  %335 = extractelement <8 x float> %312, i32 %330
  %336 = select i1 %334, float %335, float 0.000000e+00
  %337 = insertelement <8 x float> %324, float %336, i64 1
  %338 = xor i1 %334, true
  %339 = and i1 %332, %338
  %340 = insertelement <8 x i1> %327, i1 %339, i64 1
  %341 = extractelement <8 x i32> %314, i64 2
  %342 = icmp ult i32 %341, 8
  %343 = select i1 %342, i32 %341, i32 0
  %344 = extractelement <8 x i1> %51, i32 %343
  %345 = extractelement <8 x i1> %51, i64 2
  %346 = and i1 %342, %344
  %347 = and i1 %345, %346
  %348 = extractelement <8 x float> %312, i32 %343
  %349 = select i1 %347, float %348, float 0.000000e+00
  %350 = insertelement <8 x float> %337, float %349, i64 2
  %351 = xor i1 %347, true
  %352 = and i1 %345, %351
  %353 = insertelement <8 x i1> %340, i1 %352, i64 2
  %354 = extractelement <8 x i32> %314, i64 3
  %355 = icmp ult i32 %354, 8
  %356 = select i1 %355, i32 %354, i32 0
  %357 = extractelement <8 x i1> %51, i32 %356
  %358 = extractelement <8 x i1> %51, i64 3
  %359 = and i1 %355, %357
  %360 = and i1 %358, %359
  %361 = extractelement <8 x float> %312, i32 %356
  %362 = select i1 %360, float %361, float 0.000000e+00
  %363 = insertelement <8 x float> %350, float %362, i64 3
  %364 = xor i1 %360, true
  %365 = and i1 %358, %364
  %366 = insertelement <8 x i1> %353, i1 %365, i64 3
  %367 = extractelement <8 x i32> %314, i64 4
  %368 = icmp ult i32 %367, 8
  %369 = select i1 %368, i32 %367, i32 0
  %370 = extractelement <8 x i1> %51, i32 %369
  %371 = extractelement <8 x i1> %51, i64 4
  %372 = and i1 %368, %370
  %373 = and i1 %371, %372
  %374 = extractelement <8 x float> %312, i32 %369
  %375 = select i1 %373, float %374, float 0.000000e+00
  %376 = insertelement <8 x float> %363, float %375, i64 4
  %377 = xor i1 %373, true
  %378 = and i1 %371, %377
  %379 = insertelement <8 x i1> %366, i1 %378, i64 4
  %380 = extractelement <8 x i32> %314, i64 5
  %381 = icmp ult i32 %380, 8
  %382 = select i1 %381, i32 %380, i32 0
  %383 = extractelement <8 x i1> %51, i32 %382
  %384 = extractelement <8 x i1> %51, i64 5
  %385 = and i1 %381, %383
  %386 = and i1 %384, %385
  %387 = extractelement <8 x float> %312, i32 %382
  %388 = select i1 %386, float %387, float 0.000000e+00
  %389 = insertelement <8 x float> %376, float %388, i64 5
  %390 = xor i1 %386, true
  %391 = and i1 %384, %390
  %392 = insertelement <8 x i1> %379, i1 %391, i64 5
  %393 = extractelement <8 x i32> %314, i64 6
  %394 = icmp ult i32 %393, 8
  %395 = select i1 %394, i32 %393, i32 0
  %396 = extractelement <8 x i1> %51, i32 %395
  %397 = extractelement <8 x i1> %51, i64 6
  %398 = and i1 %394, %396
  %399 = and i1 %397, %398
  %400 = extractelement <8 x float> %312, i32 %395
  %401 = select i1 %399, float %400, float 0.000000e+00
  %402 = insertelement <8 x float> %389, float %401, i64 6
  %403 = xor i1 %399, true
  %404 = and i1 %397, %403
  %405 = insertelement <8 x i1> %392, i1 %404, i64 6
  %406 = extractelement <8 x i32> %314, i64 7
  %407 = icmp ult i32 %406, 8
  %408 = select i1 %407, i32 %406, i32 0
  %409 = extractelement <8 x i1> %51, i32 %408
  %410 = extractelement <8 x i1> %51, i64 7
  %411 = and i1 %407, %409
  %412 = and i1 %410, %411
  %413 = extractelement <8 x float> %312, i32 %408
  %414 = select i1 %412, float %413, float 0.000000e+00
  %415 = insertelement <8 x float> %402, float %414, i64 7
  %416 = xor i1 %412, true
  %417 = and i1 %410, %416
  %418 = insertelement <8 x i1> %405, i1 %417, i64 7
  %419 = fadd <8 x float> %312, %415
  %420 = xor <8 x i32> %313, splat (i32 2)
  %421 = extractelement <8 x i32> %420, i64 0
  %422 = icmp ult i32 %421, 8
  %423 = select i1 %422, i32 %421, i32 0
  %424 = extractelement <8 x i1> %51, i32 %423
  %425 = extractelement <8 x i1> %51, i64 0
  %426 = and i1 %422, %424
  %427 = and i1 %425, %426
  %428 = extractelement <8 x float> %419, i32 %423
  %429 = select i1 %427, float %428, float 0.000000e+00
  %430 = insertelement <8 x float> poison, float %429, i64 0
  %431 = xor i1 %427, true
  %432 = and i1 %425, %431
  %433 = insertelement <8 x i1> poison, i1 %432, i64 0
  %434 = extractelement <8 x i32> %420, i64 1
  %435 = icmp ult i32 %434, 8
  %436 = select i1 %435, i32 %434, i32 0
  %437 = extractelement <8 x i1> %51, i32 %436
  %438 = extractelement <8 x i1> %51, i64 1
  %439 = and i1 %435, %437
  %440 = and i1 %438, %439
  %441 = extractelement <8 x float> %419, i32 %436
  %442 = select i1 %440, float %441, float 0.000000e+00
  %443 = insertelement <8 x float> %430, float %442, i64 1
  %444 = xor i1 %440, true
  %445 = and i1 %438, %444
  %446 = insertelement <8 x i1> %433, i1 %445, i64 1
  %447 = extractelement <8 x i32> %420, i64 2
  %448 = icmp ult i32 %447, 8
  %449 = select i1 %448, i32 %447, i32 0
  %450 = extractelement <8 x i1> %51, i32 %449
  %451 = extractelement <8 x i1> %51, i64 2
  %452 = and i1 %448, %450
  %453 = and i1 %451, %452
  %454 = extractelement <8 x float> %419, i32 %449
  %455 = select i1 %453, float %454, float 0.000000e+00
  %456 = insertelement <8 x float> %443, float %455, i64 2
  %457 = xor i1 %453, true
  %458 = and i1 %451, %457
  %459 = insertelement <8 x i1> %446, i1 %458, i64 2
  %460 = extractelement <8 x i32> %420, i64 3
  %461 = icmp ult i32 %460, 8
  %462 = select i1 %461, i32 %460, i32 0
  %463 = extractelement <8 x i1> %51, i32 %462
  %464 = extractelement <8 x i1> %51, i64 3
  %465 = and i1 %461, %463
  %466 = and i1 %464, %465
  %467 = extractelement <8 x float> %419, i32 %462
  %468 = select i1 %466, float %467, float 0.000000e+00
  %469 = insertelement <8 x float> %456, float %468, i64 3
  %470 = xor i1 %466, true
  %471 = and i1 %464, %470
  %472 = insertelement <8 x i1> %459, i1 %471, i64 3
  %473 = extractelement <8 x i32> %420, i64 4
  %474 = icmp ult i32 %473, 8
  %475 = select i1 %474, i32 %473, i32 0
  %476 = extractelement <8 x i1> %51, i32 %475
  %477 = extractelement <8 x i1> %51, i64 4
  %478 = and i1 %474, %476
  %479 = and i1 %477, %478
  %480 = extractelement <8 x float> %419, i32 %475
  %481 = select i1 %479, float %480, float 0.000000e+00
  %482 = insertelement <8 x float> %469, float %481, i64 4
  %483 = xor i1 %479, true
  %484 = and i1 %477, %483
  %485 = insertelement <8 x i1> %472, i1 %484, i64 4
  %486 = extractelement <8 x i32> %420, i64 5
  %487 = icmp ult i32 %486, 8
  %488 = select i1 %487, i32 %486, i32 0
  %489 = extractelement <8 x i1> %51, i32 %488
  %490 = extractelement <8 x i1> %51, i64 5
  %491 = and i1 %487, %489
  %492 = and i1 %490, %491
  %493 = extractelement <8 x float> %419, i32 %488
  %494 = select i1 %492, float %493, float 0.000000e+00
  %495 = insertelement <8 x float> %482, float %494, i64 5
  %496 = xor i1 %492, true
  %497 = and i1 %490, %496
  %498 = insertelement <8 x i1> %485, i1 %497, i64 5
  %499 = extractelement <8 x i32> %420, i64 6
  %500 = icmp ult i32 %499, 8
  %501 = select i1 %500, i32 %499, i32 0
  %502 = extractelement <8 x i1> %51, i32 %501
  %503 = extractelement <8 x i1> %51, i64 6
  %504 = and i1 %500, %502
  %505 = and i1 %503, %504
  %506 = extractelement <8 x float> %419, i32 %501
  %507 = select i1 %505, float %506, float 0.000000e+00
  %508 = insertelement <8 x float> %495, float %507, i64 6
  %509 = xor i1 %505, true
  %510 = and i1 %503, %509
  %511 = insertelement <8 x i1> %498, i1 %510, i64 6
  %512 = extractelement <8 x i32> %420, i64 7
  %513 = icmp ult i32 %512, 8
  %514 = select i1 %513, i32 %512, i32 0
  %515 = extractelement <8 x i1> %51, i32 %514
  %516 = extractelement <8 x i1> %51, i64 7
  %517 = and i1 %513, %515
  %518 = and i1 %516, %517
  %519 = extractelement <8 x float> %419, i32 %514
  %520 = select i1 %518, float %519, float 0.000000e+00
  %521 = insertelement <8 x float> %508, float %520, i64 7
  %522 = xor i1 %518, true
  %523 = and i1 %516, %522
  %524 = insertelement <8 x i1> %511, i1 %523, i64 7
  %525 = fadd <8 x float> %419, %521
  %526 = xor <8 x i32> %313, splat (i32 4)
  %527 = extractelement <8 x i32> %526, i64 0
  %528 = icmp ult i32 %527, 8
  %529 = select i1 %528, i32 %527, i32 0
  %530 = extractelement <8 x i1> %51, i32 %529
  %531 = extractelement <8 x i1> %51, i64 0
  %532 = and i1 %528, %530
  %533 = and i1 %531, %532
  %534 = extractelement <8 x float> %525, i32 %529
  %535 = select i1 %533, float %534, float 0.000000e+00
  %536 = insertelement <8 x float> poison, float %535, i64 0
  %537 = xor i1 %533, true
  %538 = and i1 %531, %537
  %539 = insertelement <8 x i1> poison, i1 %538, i64 0
  %540 = extractelement <8 x i32> %526, i64 1
  %541 = icmp ult i32 %540, 8
  %542 = select i1 %541, i32 %540, i32 0
  %543 = extractelement <8 x i1> %51, i32 %542
  %544 = extractelement <8 x i1> %51, i64 1
  %545 = and i1 %541, %543
  %546 = and i1 %544, %545
  %547 = extractelement <8 x float> %525, i32 %542
  %548 = select i1 %546, float %547, float 0.000000e+00
  %549 = insertelement <8 x float> %536, float %548, i64 1
  %550 = xor i1 %546, true
  %551 = and i1 %544, %550
  %552 = insertelement <8 x i1> %539, i1 %551, i64 1
  %553 = extractelement <8 x i32> %526, i64 2
  %554 = icmp ult i32 %553, 8
  %555 = select i1 %554, i32 %553, i32 0
  %556 = extractelement <8 x i1> %51, i32 %555
  %557 = extractelement <8 x i1> %51, i64 2
  %558 = and i1 %554, %556
  %559 = and i1 %557, %558
  %560 = extractelement <8 x float> %525, i32 %555
  %561 = select i1 %559, float %560, float 0.000000e+00
  %562 = insertelement <8 x float> %549, float %561, i64 2
  %563 = xor i1 %559, true
  %564 = and i1 %557, %563
  %565 = insertelement <8 x i1> %552, i1 %564, i64 2
  %566 = extractelement <8 x i32> %526, i64 3
  %567 = icmp ult i32 %566, 8
  %568 = select i1 %567, i32 %566, i32 0
  %569 = extractelement <8 x i1> %51, i32 %568
  %570 = extractelement <8 x i1> %51, i64 3
  %571 = and i1 %567, %569
  %572 = and i1 %570, %571
  %573 = extractelement <8 x float> %525, i32 %568
  %574 = select i1 %572, float %573, float 0.000000e+00
  %575 = insertelement <8 x float> %562, float %574, i64 3
  %576 = xor i1 %572, true
  %577 = and i1 %570, %576
  %578 = insertelement <8 x i1> %565, i1 %577, i64 3
  %579 = extractelement <8 x i32> %526, i64 4
  %580 = icmp ult i32 %579, 8
  %581 = select i1 %580, i32 %579, i32 0
  %582 = extractelement <8 x i1> %51, i32 %581
  %583 = extractelement <8 x i1> %51, i64 4
  %584 = and i1 %580, %582
  %585 = and i1 %583, %584
  %586 = extractelement <8 x float> %525, i32 %581
  %587 = select i1 %585, float %586, float 0.000000e+00
  %588 = insertelement <8 x float> %575, float %587, i64 4
  %589 = xor i1 %585, true
  %590 = and i1 %583, %589
  %591 = insertelement <8 x i1> %578, i1 %590, i64 4
  %592 = extractelement <8 x i32> %526, i64 5
  %593 = icmp ult i32 %592, 8
  %594 = select i1 %593, i32 %592, i32 0
  %595 = extractelement <8 x i1> %51, i32 %594
  %596 = extractelement <8 x i1> %51, i64 5
  %597 = and i1 %593, %595
  %598 = and i1 %596, %597
  %599 = extractelement <8 x float> %525, i32 %594
  %600 = select i1 %598, float %599, float 0.000000e+00
  %601 = insertelement <8 x float> %588, float %600, i64 5
  %602 = xor i1 %598, true
  %603 = and i1 %596, %602
  %604 = insertelement <8 x i1> %591, i1 %603, i64 5
  %605 = extractelement <8 x i32> %526, i64 6
  %606 = icmp ult i32 %605, 8
  %607 = select i1 %606, i32 %605, i32 0
  %608 = extractelement <8 x i1> %51, i32 %607
  %609 = extractelement <8 x i1> %51, i64 6
  %610 = and i1 %606, %608
  %611 = and i1 %609, %610
  %612 = extractelement <8 x float> %525, i32 %607
  %613 = select i1 %611, float %612, float 0.000000e+00
  %614 = insertelement <8 x float> %601, float %613, i64 6
  %615 = xor i1 %611, true
  %616 = and i1 %609, %615
  %617 = insertelement <8 x i1> %604, i1 %616, i64 6
  %618 = extractelement <8 x i32> %526, i64 7
  %619 = icmp ult i32 %618, 8
  %620 = select i1 %619, i32 %618, i32 0
  %621 = extractelement <8 x i1> %51, i32 %620
  %622 = extractelement <8 x i1> %51, i64 7
  %623 = and i1 %619, %621
  %624 = and i1 %622, %623
  %625 = extractelement <8 x float> %525, i32 %620
  %626 = select i1 %624, float %625, float 0.000000e+00
  %627 = insertelement <8 x float> %614, float %626, i64 7
  %628 = xor i1 %624, true
  %629 = and i1 %622, %628
  %630 = insertelement <8 x i1> %617, i1 %629, i64 7
  %631 = fadd <8 x float> %525, %627
  %632 = extractelement <8 x i1> %51, i32 0
  %633 = extractelement <8 x i1> %51, i64 0
  %634 = and i1 true, %632
  %635 = and i1 %633, %634
  %636 = extractelement <8 x float> %631, i32 0
  %637 = select i1 %635, float %636, float 0.000000e+00
  %638 = insertelement <8 x float> poison, float %637, i64 0
  %639 = xor i1 %635, true
  %640 = and i1 %633, %639
  %641 = insertelement <8 x i1> poison, i1 %640, i64 0
  %642 = extractelement <8 x i1> %51, i32 0
  %643 = extractelement <8 x i1> %51, i64 1
  %644 = and i1 true, %642
  %645 = and i1 %643, %644
  %646 = extractelement <8 x float> %631, i32 0
  %647 = select i1 %645, float %646, float 0.000000e+00
  %648 = insertelement <8 x float> %638, float %647, i64 1
  %649 = xor i1 %645, true
  %650 = and i1 %643, %649
  %651 = insertelement <8 x i1> %641, i1 %650, i64 1
  %652 = extractelement <8 x i1> %51, i32 0
  %653 = extractelement <8 x i1> %51, i64 2
  %654 = and i1 true, %652
  %655 = and i1 %653, %654
  %656 = extractelement <8 x float> %631, i32 0
  %657 = select i1 %655, float %656, float 0.000000e+00
  %658 = insertelement <8 x float> %648, float %657, i64 2
  %659 = xor i1 %655, true
  %660 = and i1 %653, %659
  %661 = insertelement <8 x i1> %651, i1 %660, i64 2
  %662 = extractelement <8 x i1> %51, i32 0
  %663 = extractelement <8 x i1> %51, i64 3
  %664 = and i1 true, %662
  %665 = and i1 %663, %664
  %666 = extractelement <8 x float> %631, i32 0
  %667 = select i1 %665, float %666, float 0.000000e+00
  %668 = insertelement <8 x float> %658, float %667, i64 3
  %669 = xor i1 %665, true
  %670 = and i1 %663, %669
  %671 = insertelement <8 x i1> %661, i1 %670, i64 3
  %672 = extractelement <8 x i1> %51, i32 0
  %673 = extractelement <8 x i1> %51, i64 4
  %674 = and i1 true, %672
  %675 = and i1 %673, %674
  %676 = extractelement <8 x float> %631, i32 0
  %677 = select i1 %675, float %676, float 0.000000e+00
  %678 = insertelement <8 x float> %668, float %677, i64 4
  %679 = xor i1 %675, true
  %680 = and i1 %673, %679
  %681 = insertelement <8 x i1> %671, i1 %680, i64 4
  %682 = extractelement <8 x i1> %51, i32 0
  %683 = extractelement <8 x i1> %51, i64 5
  %684 = and i1 true, %682
  %685 = and i1 %683, %684
  %686 = extractelement <8 x float> %631, i32 0
  %687 = select i1 %685, float %686, float 0.000000e+00
  %688 = insertelement <8 x float> %678, float %687, i64 5
  %689 = xor i1 %685, true
  %690 = and i1 %683, %689
  %691 = insertelement <8 x i1> %681, i1 %690, i64 5
  %692 = extractelement <8 x i1> %51, i32 0
  %693 = extractelement <8 x i1> %51, i64 6
  %694 = and i1 true, %692
  %695 = and i1 %693, %694
  %696 = extractelement <8 x float> %631, i32 0
  %697 = select i1 %695, float %696, float 0.000000e+00
  %698 = insertelement <8 x float> %688, float %697, i64 6
  %699 = xor i1 %695, true
  %700 = and i1 %693, %699
  %701 = insertelement <8 x i1> %691, i1 %700, i64 6
  %702 = extractelement <8 x i1> %51, i32 0
  %703 = extractelement <8 x i1> %51, i64 7
  %704 = and i1 true, %702
  %705 = and i1 %703, %704
  %706 = extractelement <8 x float> %631, i32 0
  %707 = select i1 %705, float %706, float 0.000000e+00
  %708 = insertelement <8 x float> %698, float %707, i64 7
  %709 = xor i1 %705, true
  %710 = and i1 %703, %709
  %711 = insertelement <8 x i1> %701, i1 %710, i64 7
  %712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %713 = bitcast <8 x i1> %51 to i8
  %714 = call i8 @llvm.cttz.i8(i8 %713, i1 false)
  %715 = zext i8 %714 to i32
  %716 = select i1 %712, i32 %715, i32 0
  %717 = extractelement <8 x float> %708, i32 %716
  %.spill.load83 = load float, ptr %.spill6, align 4
  %718 = fadd float %.spill.load83, %717
  %719 = fdiv float %718, 4.097000e+03
  store float %719, ptr %.spill14, align 4
  %720 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %720, 0
  %723 = select <8 x i1> %51, <8 x ptr> %721, <8 x ptr> %722
  %724 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %720, 1
  %726 = select <8 x i1> %51, <8 x i64> %724, <8 x i64> %725
  %727 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %723, 0
  %728 = insertvalue { <8 x ptr>, <8 x i64> } %727, <8 x i64> %726, 1
  store { <8 x ptr>, <8 x i64> } %728, ptr %tile_snapshot.spill15, align 64
  %729 = load <8 x i64>, ptr %.slot16, align 64
  %730 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %729
  store <8 x i64> %730, ptr %.slot16, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state84 = load <8 x i64>, ptr %.slot16, align 64
  %731 = icmp slt <8 x i64> %.state84, splat (i64 512)
  %732 = extractelement <8 x i1> %731, i32 0
  br i1 %732, label %direct.true85, label %direct.false86

direct.schedule.12:                               ; preds = %direct.true85
  %.state87 = load <8 x i64>, ptr %.slot16, align 64
  %733 = mul <8 x i64> %.state87, splat (i64 8)
  %.spill.load88 = load <8 x i64>, ptr %.spill, align 64
  %734 = add <8 x i64> %733, %.spill.load88
  %.spill.load89 = load i64, ptr %.spill7, align 4
  %735 = add i64 %.spill.load89, 0
  %736 = add <8 x i64> zeroinitializer, %734
  %737 = mul i64 %735, 4097
  %.splatinsert90 = insertelement <8 x i64> poison, i64 %737, i64 0
  %.splat91 = shufflevector <8 x i64> %.splatinsert90, <8 x i64> poison, <8 x i32> zeroinitializer
  %738 = add <8 x i64> %.splat91, %736
  %739 = extractvalue { ptr, i64 } %15, 0
  %740 = extractelement <8 x i64> %738, i32 0
  %741 = sub i64 %740, 0
  %742 = mul i64 %741, 4
  %buffer.contiguous.address92 = getelementptr i8, ptr %739, i64 %742
  %buffer.contiguous.load93 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address92, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load94, 1
  %.state95 = load <8 x i64>, ptr %.slot16, align 64
  %745 = mul <8 x i64> %.state95, splat (i64 32)
  %746 = add <8 x i64> %744, %745
  %747 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %743, 0
  %748 = insertvalue { <8 x ptr>, <8 x i64> } %747, <8 x i64> %746, 1
  %749 = extractvalue { <8 x ptr>, <8 x i64> } %748, 0
  %750 = extractvalue { <8 x ptr>, <8 x i64> } %748, 1
  %751 = getelementptr i8, <8 x ptr> %749, <8 x i64> %750
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %buffer.contiguous.load93, <8 x ptr> %751, i32 1, <8 x i1> %51)
  %.state96 = load <8 x i64>, ptr %.slot16, align 64
  %752 = add <8 x i64> %.state96, splat (i64 1)
  %753 = load <8 x i64>, ptr %.slot16, align 64
  %754 = select <8 x i1> %51, <8 x i64> %752, <8 x i64> %753
  store <8 x i64> %754, ptr %.slot16, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false86
  %.spill.load97 = load <8 x i1>, ptr %.spill5, align 1
  %755 = and <8 x i1> %51, %.spill.load97
  %756 = xor <8 x i1> %.spill.load97, splat (i1 true)
  %757 = and <8 x i1> %51, %756
  %758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %755)
  %759 = bitcast <8 x i1> %755 to i8
  %760 = call i8 @llvm.cttz.i8(i8 %759, i1 false)
  %761 = zext i8 %760 to i32
  %762 = select i1 %758, i32 %761, i32 0
  %.spill.load98 = load <8 x i64>, ptr %.spill, align 64
  %763 = add <8 x i64> splat (i64 4096), %.spill.load98
  %.spill.load99 = load i64, ptr %.spill7, align 4
  %764 = add i64 %.spill.load99, 0
  %765 = add <8 x i64> zeroinitializer, %763
  %766 = mul i64 %764, 4097
  %.splatinsert100 = insertelement <8 x i64> poison, i64 %766, i64 0
  %.splat101 = shufflevector <8 x i64> %.splatinsert100, <8 x i64> poison, <8 x i32> zeroinitializer
  %767 = add <8 x i64> %.splat101, %765
  %768 = extractvalue { ptr, i64 } %15, 0
  %769 = select <8 x i1> %755, <8 x i64> %767, <8 x i64> zeroinitializer
  %770 = extractelement <8 x i64> %769, i32 %762
  %771 = zext i32 %762 to i64
  %772 = sub i64 %770, %771
  %773 = mul i64 %772, 4
  %buffer.contiguous.address102 = getelementptr i8, ptr %768, i64 %773
  %buffer.contiguous.load103 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr %buffer.contiguous.address102, i32 1, <8 x i1> %755, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load104 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load104, 0
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load104, 1
  %776 = add <8 x i64> %775, splat (i64 16384)
  %777 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %774, 0
  %778 = insertvalue { <8 x ptr>, <8 x i64> } %777, <8 x i64> %776, 1
  %779 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %778, 1
  %781 = extractelement <8 x ptr> %779, i32 0
  %782 = extractelement <8 x i64> %780, i32 %762
  %783 = zext i32 %762 to i64
  %784 = mul i64 %783, 4
  %785 = sub i64 %782, %784
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %755)
  %787 = select i1 %786, i64 %785, i64 0
  %private.contiguous.address105 = getelementptr i8, ptr %781, i64 %787
  %private.contiguous.preserve106 = load <8 x float>, ptr %private.contiguous.address105, align 4
  %788 = select <8 x i1> %755, <8 x float> %buffer.contiguous.load103, <8 x float> %private.contiguous.preserve106
  store <8 x float> %788, ptr %private.contiguous.address105, align 4
  %789 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %757)
  %790 = bitcast <8 x i1> %757 to i8
  %791 = call i8 @llvm.cttz.i8(i8 %790, i1 false)
  %792 = zext i8 %791 to i32
  %793 = select i1 %789, i32 %792, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %.spill.load107 = load float, ptr %.spill14, align 4
  %794 = fadd float %.spill.load107, 0x3EE4F8B580000000
  %795 = call float @llvm.sqrt.f32(float %794)
  store float %795, ptr %.spill17, align 4
  %796 = load <8 x i64>, ptr %.slot18, align 64
  %797 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %796
  store <8 x i64> %797, ptr %.slot18, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state108 = load <8 x i64>, ptr %.slot18, align 64
  %798 = icmp slt <8 x i64> %.state108, splat (i64 512)
  %799 = extractelement <8 x i1> %798, i32 0
  br i1 %799, label %direct.true109, label %direct.false110

direct.schedule.17:                               ; preds = %direct.true109
  %.state111 = load <8 x i64>, ptr %.slot18, align 64
  %800 = mul <8 x i64> %.state111, splat (i64 8)
  %.spill.load112 = load <8 x i64>, ptr %.spill, align 64
  %801 = add <8 x i64> %800, %.spill.load112
  %.spill.load113 = load <8 x i64>, ptr %.spill4, align 64
  %802 = add <8 x i64> %.spill.load113, zeroinitializer
  %803 = add <8 x i64> zeroinitializer, %802
  %804 = add <8 x i64> zeroinitializer, %801
  %805 = mul <8 x i64> %803, splat (i64 4097)
  %806 = add <8 x i64> %805, %804
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %808 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %.state115 = load <8 x i64>, ptr %.slot18, align 64
  %809 = mul <8 x i64> %.state115, splat (i64 32)
  %810 = add <8 x i64> %808, %809
  %811 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %807, 0
  %812 = insertvalue { <8 x ptr>, <8 x i64> } %811, <8 x i64> %810, 1
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %812, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %812, 1
  %815 = getelementptr i8, <8 x ptr> %813, <8 x i64> %814
  %816 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %815, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %.spill.load116 = load float, ptr %.spill17, align 4
  %.splatinsert117 = insertelement <8 x float> poison, float %.spill.load116, i64 0
  %.splat118 = shufflevector <8 x float> %.splatinsert117, <8 x float> poison, <8 x i32> zeroinitializer
  %817 = fdiv <8 x float> %816, %.splat118
  %tile_snapshot.spill.load119 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 0
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load119, 1
  %.state120 = load <8 x i64>, ptr %.slot18, align 64
  %820 = mul <8 x i64> %.state120, splat (i64 32)
  %821 = add <8 x i64> %819, %820
  %822 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %818, 0
  %823 = insertvalue { <8 x ptr>, <8 x i64> } %822, <8 x i64> %821, 1
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %823, 0
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %823, 1
  %826 = getelementptr i8, <8 x ptr> %824, <8 x i64> %825
  %827 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> %826, i32 1, <8 x i1> %51, <8 x float> zeroinitializer)
  %828 = fmul <8 x float> %817, %827
  %829 = extractvalue { ptr, i64 } %27, 0
  %830 = extractelement <8 x i64> %806, i32 0
  %831 = sub i64 %830, 0
  %832 = mul i64 %831, 4
  %buffer.contiguous.address121 = getelementptr i8, ptr %829, i64 %832
  call void @llvm.masked.store.v8f32.p0(<8 x float> %828, ptr %buffer.contiguous.address121, i32 1, <8 x i1> %51)
  %.state122 = load <8 x i64>, ptr %.slot18, align 64
  %833 = add <8 x i64> %.state122, splat (i64 1)
  %834 = load <8 x i64>, ptr %.slot18, align 64
  %835 = select <8 x i1> %51, <8 x i64> %833, <8 x i64> %834
  store <8 x i64> %835, ptr %.slot18, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false110
  %.spill.load123 = load <8 x i1>, ptr %.spill5, align 1
  %836 = and <8 x i1> %51, %.spill.load123
  %837 = xor <8 x i1> %.spill.load123, splat (i1 true)
  %838 = and <8 x i1> %51, %837
  %839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %836)
  %840 = bitcast <8 x i1> %836 to i8
  %841 = call i8 @llvm.cttz.i8(i8 %840, i1 false)
  %842 = zext i8 %841 to i32
  %843 = select i1 %839, i32 %842, i32 0
  %.spill.load124 = load <8 x i64>, ptr %.spill, align 64
  %844 = add <8 x i64> splat (i64 4096), %.spill.load124
  %.spill.load125 = load <8 x i64>, ptr %.spill4, align 64
  %845 = add <8 x i64> %.spill.load125, zeroinitializer
  %846 = add <8 x i64> zeroinitializer, %845
  %847 = add <8 x i64> zeroinitializer, %844
  %848 = mul <8 x i64> %846, splat (i64 4097)
  %849 = add <8 x i64> %848, %847
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %852 = add <8 x i64> %851, splat (i64 16384)
  %853 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %850, 0
  %854 = insertvalue { <8 x ptr>, <8 x i64> } %853, <8 x i64> %852, 1
  %855 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %854, 1
  %857 = extractelement <8 x ptr> %855, i32 0
  %858 = extractelement <8 x i64> %856, i32 %843
  %859 = zext i32 %843 to i64
  %860 = mul i64 %859, 4
  %861 = sub i64 %858, %860
  %862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %836)
  %863 = select i1 %862, i64 %861, i64 0
  %private.contiguous.address127 = getelementptr i8, ptr %857, i64 %863
  %private.contiguous.load128 = load <8 x float>, ptr %private.contiguous.address127, align 4
  %864 = select <8 x i1> %836, <8 x float> %private.contiguous.load128, <8 x float> zeroinitializer
  %.spill.load129 = load float, ptr %.spill17, align 4
  %.splatinsert130 = insertelement <8 x float> poison, float %.spill.load129, i64 0
  %.splat131 = shufflevector <8 x float> %.splatinsert130, <8 x float> poison, <8 x i32> zeroinitializer
  %865 = fdiv <8 x float> %864, %.splat131
  %tile_snapshot.spill.load132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 0
  %867 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load132, 1
  %868 = add <8 x i64> %867, splat (i64 16384)
  %869 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %866, 0
  %870 = insertvalue { <8 x ptr>, <8 x i64> } %869, <8 x i64> %868, 1
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %870, 1
  %873 = extractelement <8 x ptr> %871, i32 0
  %874 = extractelement <8 x i64> %872, i32 %843
  %875 = zext i32 %843 to i64
  %876 = mul i64 %875, 4
  %877 = sub i64 %874, %876
  %878 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %836)
  %879 = select i1 %878, i64 %877, i64 0
  %private.contiguous.address133 = getelementptr i8, ptr %873, i64 %879
  %private.contiguous.load134 = load <8 x float>, ptr %private.contiguous.address133, align 4
  %880 = select <8 x i1> %836, <8 x float> %private.contiguous.load134, <8 x float> zeroinitializer
  %881 = fmul <8 x float> %865, %880
  %882 = extractvalue { ptr, i64 } %27, 0
  %883 = extractelement <8 x i64> %849, i32 %843
  %884 = zext i32 %843 to i64
  %885 = sub i64 %883, %884
  %886 = mul i64 %885, 4
  %buffer.contiguous.address135 = getelementptr i8, ptr %882, i64 %886
  call void @llvm.masked.store.v8f32.p0(<8 x float> %881, ptr %buffer.contiguous.address135, i32 1, <8 x i1> %836)
  %887 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %838)
  %888 = bitcast <8 x i1> %838 to i8
  %889 = call i8 @llvm.cttz.i8(i8 %888, i1 false)
  %890 = zext i8 %889 to i32
  %891 = select i1 %887, i32 %890, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true57:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false58:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true85:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false86:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true109:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false110:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

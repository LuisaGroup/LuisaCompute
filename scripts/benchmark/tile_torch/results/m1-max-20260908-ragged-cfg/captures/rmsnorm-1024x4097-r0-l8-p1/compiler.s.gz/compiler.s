	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_1:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_2:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_5:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_6:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_7:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_8:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_9:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_10:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_11:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_12:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_13:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_14:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_15:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
lCPI0_16:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_17:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_18:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_19:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_20:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_21:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_22:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_23:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #1472
	str	x0, [sp, #336]                  ; 8-byte Folded Spill
	str	w3, [sp, #360]                  ; 4-byte Folded Spill
	cbz	w3, LBB0_267
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w15, #0                         ; =0x0
	add	x8, sp, #1408
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #1440
	dup.2d	v0, x8
	mov	w27, #4                         ; =0x4
	dup.2d	v1, x14
	adrp	x16, lCPI0_1@PAGE
	adrp	x1, lCPI0_2@PAGE
	adrp	x17, lCPI0_3@PAGE
	adrp	x4, lCPI0_4@PAGE
	dup.2d	v2, x27
	str	q2, [sp, #320]                  ; 16-byte Folded Spill
	adrp	x5, lCPI0_5@PAGE
	adrp	x6, lCPI0_6@PAGE
	adrp	x7, lCPI0_7@PAGE
	adrp	x19, lCPI0_8@PAGE
	adrp	x20, lCPI0_9@PAGE
	ldp	w9, w8, [x2, #44]
	str	w9, [sp, #356]                  ; 4-byte Folded Spill
	str	w8, [sp, #352]                  ; 4-byte Folded Spill
	adrp	x22, lCPI0_10@PAGE
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
	adrp	x23, lCPI0_11@PAGE
	adrp	x24, lCPI0_12@PAGE
	adrp	x25, lCPI0_13@PAGE
	adrp	x26, lCPI0_14@PAGE
	adrp	x10, lCPI0_15@PAGE
	mov	w28, #1                         ; =0x1
	movi	d11, #0000000000000000
	ldp	w8, w9, [x2]
	ldp	w11, w12, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Folded Spill
	str	x12, [sp, #344]                 ; 8-byte Folded Spill
	str	q3, [sp, #640]                  ; 16-byte Folded Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w8, w2, #1
	ldr	w9, [sp, #356]                  ; 4-byte Folded Reload
	cmp	w8, w9
	cset	w9, eq
	csinc	w8, wzr, w2, eq
	cinc	w11, w0, eq
	ldr	w12, [sp, #352]                 ; 4-byte Folded Reload
	cmp	w11, w12
	cset	w12, eq
	ands	w12, w9, w12
	csel	w9, wzr, w11, ne
	add	w11, w13, w12
	add	w15, w15, #1
	ldr	w12, [sp, #360]                 ; 4-byte Folded Reload
	cmp	w15, w12
	b.eq	LBB0_266
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_39 Depth 2
                                        ;       Child Loop BB0_40 Depth 3
                                        ;       Child Loop BB0_42 Depth 3
                                        ;       Child Loop BB0_44 Depth 3
                                        ;       Child Loop BB0_46 Depth 3
                                        ;     Child Loop BB0_52 Depth 2
                                        ;     Child Loop BB0_79 Depth 2
                                        ;     Child Loop BB0_145 Depth 2
                                        ;     Child Loop BB0_189 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
                                        ;     Child Loop BB0_21 Depth 2
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
	mov	x0, x11
	str	w9, [sp, #364]                  ; 4-byte Folded Spill
	mov	x3, x8
	ubfiz	x8, x8, #5, #32
	ldr	x13, [sp, #344]                 ; 8-byte Folded Reload
	cmp	x8, x13
	csel	x9, x8, xzr, ls
	subs	x11, x13, x9
	cmp	x11, #32
	mov	w12, #32                        ; =0x20
	csel	x11, x11, x12, lo
	cmp	x13, x9
	ccmp	x8, x13, #2, hi
	csel	x9, x11, xzr, ls
	cmp	x9, #32
	str	w15, [sp, #372]                 ; 4-byte Folded Spill
	str	w0, [sp, #368]                  ; 4-byte Folded Spill
	str	x3, [sp, #376]                  ; 8-byte Folded Spill
	b.lo	LBB0_37
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x9, [sp, #336]                  ; 8-byte Folded Reload
	ldr	x11, [x9]
	ldr	x2, [x9, #16]
	ldr	x9, [x9, #48]
	str	x9, [sp, #528]                  ; 8-byte Folded Spill
	ubfiz	w13, w3, #2, #27
	mov	w9, #16388                      ; =0x4004
	umull	x12, w13, w9
	mov	x15, x11
	str	w13, [sp, #512]                 ; 4-byte Folded Spill
	umaddl	x9, w13, w9, x11
LBB0_5:                                 ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x13, x9, x8
	ldp	q2, q4, [x13]
	add	x13, x14, x8
	stp	q2, q4, [x13]
	add	x8, x8, #32
	cmp	x8, #4, lsl #12                 ; =16384
	b.ne	LBB0_5
; %bb.6:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x12, #4, lsl #12            ; =16384
	ldr	s2, [x15, x9]
	str	q2, [sp, #704]                  ; 16-byte Folded Spill
	str	s2, [x14, x8]
	ldr	q2, [sp, #17824]
	ldr	q4, [sp, #17840]
	fmul.4s	v5, v4, v4
	fmul.4s	v4, v2, v2
	ldr	q2, [sp, #17856]
	ldr	q6, [sp, #17872]
	fmul.4s	v7, v6, v6
	fmul.4s	v6, v2, v2
	ldr	q2, [sp, #17888]
	ldr	q16, [sp, #17904]
	fmul.4s	v31, v16, v16
	fmul.4s	v8, v2, v2
	ldr	q2, [sp, #17920]
	ldr	q16, [sp, #17936]
	fmul.4s	v10, v16, v16
	fmul.4s	v9, v2, v2
	ldr	q14, [sp, #320]                 ; 16-byte Folded Reload
	mov.16b	v11, v14
	mov.16b	v12, v14
	mov.16b	v13, v14
LBB0_7:                                 ; %direct.true57.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v2, v11, #5
	add.2d	v28, v1, v2
	ldr	q2, [sp, #640]                  ; 16-byte Folded Reload
	add.2d	v19, v28, v2
	mov.d	x8, v19[1]
	ldr	q25, [x16, lCPI0_1@PAGEOFF]
	shl.2d	v2, v12, #5
	add.2d	v16, v1, v2
	add.2d	v20, v16, v25
	mov.d	x13, v20[1]
	ldr	q17, [x1, lCPI0_2@PAGEOFF]
	shl.2d	v2, v13, #5
	add.2d	v15, v1, v2
	add.2d	v21, v15, v17
	mov.d	x0, v21[1]
	ldr	q18, [x17, lCPI0_3@PAGEOFF]
	shl.2d	v2, v14, #5
	add.2d	v2, v1, v2
	add.2d	v22, v2, v18
	mov.d	x21, v22[1]
	fmov	x30, d19
	ldr	s19, [x30]
	fmov	x30, d20
	fmov	x11, d21
	ld1.s	{ v19 }[1], [x8]
	fmov	x8, d22
	ld1.s	{ v19 }[2], [x30]
	ld1.s	{ v19 }[3], [x13]
	ldr	s20, [x11]
	ld1.s	{ v20 }[1], [x0]
	ld1.s	{ v20 }[2], [x8]
	ld1.s	{ v20 }[3], [x21]
	fmul.4s	v20, v20, v20
	fmul.4s	v19, v19, v19
	fadd.4s	v4, v4, v19
	fadd.4s	v5, v5, v20
	ldr	q21, [x4, lCPI0_4@PAGEOFF]
	ldr	q22, [x5, lCPI0_5@PAGEOFF]
	ldr	q26, [x6, lCPI0_6@PAGEOFF]
	ldr	q27, [x7, lCPI0_7@PAGEOFF]
	add.2d	v19, v2, v27
	add.2d	v20, v15, v26
	add.2d	v23, v16, v22
	add.2d	v24, v28, v21
	mov.d	x8, v24[1]
	fmov	x11, d24
	mov.d	x13, v23[1]
	fmov	x0, d23
	mov.d	x21, v20[1]
	fmov	x30, d20
	mov.d	x3, v19[1]
	ldr	s20, [x11]
	ld1.s	{ v20 }[1], [x8]
	ld1.s	{ v20 }[2], [x0]
	ld1.s	{ v20 }[3], [x13]
	fmov	x8, d19
	ldr	s19, [x30]
	ld1.s	{ v19 }[1], [x21]
	ld1.s	{ v19 }[2], [x8]
	ld1.s	{ v19 }[3], [x3]
	fmul.4s	v19, v19, v19
	fmul.4s	v20, v20, v20
	fadd.4s	v6, v6, v20
	fadd.4s	v7, v7, v19
	ldr	q24, [x19, lCPI0_8@PAGEOFF]
	ldr	q23, [x20, lCPI0_9@PAGEOFF]
	ldr	q29, [x22, lCPI0_10@PAGEOFF]
	ldr	q3, [x23, lCPI0_11@PAGEOFF]
	add.2d	v19, v2, v3
	add.2d	v20, v28, v24
	mov.d	x8, v20[1]
	fmov	x11, d20
	add.2d	v20, v16, v23
	mov.d	x13, v20[1]
	fmov	x0, d20
	add.2d	v20, v15, v29
	mov.d	x3, v20[1]
	mov.d	x21, v19[1]
	fmov	x30, d20
	ldr	s20, [x11]
	ld1.s	{ v20 }[1], [x8]
	ld1.s	{ v20 }[2], [x0]
	fmov	x8, d19
	ld1.s	{ v20 }[3], [x13]
	ldr	s19, [x30]
	ld1.s	{ v19 }[1], [x3]
	ld1.s	{ v19 }[2], [x8]
	ld1.s	{ v19 }[3], [x21]
	fmul.4s	v19, v19, v19
	fmul.4s	v20, v20, v20
	fadd.4s	v8, v8, v20
	fadd.4s	v31, v31, v19
	ldr	q20, [x24, lCPI0_12@PAGEOFF]
	add.2d	v19, v28, v20
	mov.d	x8, v19[1]
	ldr	q28, [x25, lCPI0_13@PAGEOFF]
	fmov	x11, d19
	ldr	q30, [x26, lCPI0_14@PAGEOFF]
	add.2d	v19, v16, v28
	mov.d	x13, v19[1]
	fmov	x0, d19
	ldr	q16, [x10, lCPI0_15@PAGEOFF]
	add.2d	v2, v2, v16
	add.2d	v19, v15, v30
	mov.d	x3, v19[1]
	fmov	x21, d19
	mov.d	x30, v2[1]
	ldr	s19, [x11]
	ld1.s	{ v19 }[1], [x8]
	fmov	x8, d2
	ld1.s	{ v19 }[2], [x0]
	ld1.s	{ v19 }[3], [x13]
	fmul.4s	v2, v19, v19
	fadd.4s	v9, v9, v2
	ldr	s2, [x21]
	ld1.s	{ v2 }[1], [x3]
	ld1.s	{ v2 }[2], [x8]
	ld1.s	{ v2 }[3], [x30]
	fmul.4s	v2, v2, v2
	fadd.4s	v10, v10, v2
	dup.2d	v2, x27
	add.2d	v13, v13, v2
	add.2d	v12, v12, v2
	add.2d	v14, v14, v2
	add.2d	v11, v11, v2
	fmov	x8, d11
	cmp	x8, #512
	b.lt	LBB0_7
; %bb.8:                                ; %direct.true85.i.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	stp	q3, q29, [sp, #608]             ; 32-byte Folded Spill
	stp	q23, q24, [sp, #656]            ; 32-byte Folded Spill
	str	q16, [sp, #544]                 ; 16-byte Folded Spill
	str	q20, [sp, #592]                 ; 16-byte Folded Spill
	stp	q22, q21, [sp, #720]            ; 32-byte Folded Spill
	mov	x8, #0                          ; =0x0
	movi.2d	v2, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v11, #0000000000000000
	mov.16b	v16, v25
	ldr	q3, [sp, #640]                  ; 16-byte Folded Reload
LBB0_9:                                 ; %direct.true85.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, x2, x8, lsl #5
	ldp	q13, q12, [x8]
	shl.2d	v14, v2, #5
	shl.2d	v15, v19, #5
	shl.2d	v21, v20, #5
	shl.2d	v22, v11, #5
	add.2d	v22, v22, v18
	add.2d	v22, v0, v22
	add.2d	v21, v21, v17
	add.2d	v15, v15, v16
	add.2d	v14, v14, v3
	add.2d	v14, v0, v14
	mov.d	x8, v14[1]
	fmov	x11, d14
	str	s13, [x11]
	st1.s	{ v13 }[1], [x8]
	add.2d	v14, v0, v15
	mov.d	x8, v14[1]
	fmov	x11, d14
	st1.s	{ v13 }[2], [x11]
	add.2d	v21, v0, v21
	st1.s	{ v13 }[3], [x8]
	mov.d	x8, v21[1]
	fmov	x11, d21
	str	s12, [x11]
	st1.s	{ v12 }[1], [x8]
	mov.d	x8, v22[1]
	fmov	x11, d22
	st1.s	{ v12 }[2], [x11]
	st1.s	{ v12 }[3], [x8]
	dup.2d	v21, x28
	add.2d	v20, v20, v21
	add.2d	v19, v19, v21
	add.2d	v11, v11, v21
	add.2d	v2, v2, v21
	fmov	x8, d2
	cmp	x8, #512
	b.lt	LBB0_9
; %bb.10:                               ; %direct.false86.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q2, [sp, #704]                  ; 16-byte Folded Reload
	fmul.4s	v2, v2, v2
	fadd.4s	v2, v2, v4
	mov.s	v4[0], v2[0]
	fadd.4s	v2, v7, v5
	fadd.4s	v4, v6, v4
	fadd.4s	v4, v8, v4
	fadd.4s	v2, v31, v2
	fadd.4s	v2, v10, v2
	fadd.4s	v4, v9, v4
	rev64.4s	v5, v4
	rev64.4s	v6, v2
	fadd.4s	v4, v4, v5
	dup.4s	v5, v4[2]
	fadd.4s	v2, v2, v6
	dup.4s	v6, v2[2]
	fadd.4s	v2, v2, v6
	fadd.4s	v4, v4, v5
	fadd.4s	v2, v4, v2
	movi	d4, #0000000000000000
	fadd	s4, s2, s4
	mov	w11, #2048                      ; =0x800
	movk	w11, #17792, lsl #16
	fmov	s5, w11
	add	x5, x2, #4, lsl #12             ; =16384
	ldr	q2, [sp, #17792]
	ld1.s	{ v2 }[0], [x5]
	fdiv	s4, s4, s5
	mov	w11, #50604                     ; =0xc5ac
	movk	w11, #14119, lsl #16
	fmov	s5, w11
	fadd	s4, s4, s5
	fsqrt	s4, s4
	dup.4s	v5, v4[0]
	str	q2, [sp, #17792]
	ldr	x17, [sp, #528]                 ; 8-byte Folded Reload
	add	x12, x17, x12
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	mov	x1, x15
	ldr	w4, [sp, #512]                  ; 4-byte Folded Reload
	ldr	q25, [sp, #672]                 ; 16-byte Folded Reload
LBB0_11:                                ; %direct.true109.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v20, #5
	shl.2d	v22, v19, #5
	shl.2d	v31, v7, #5
	shl.2d	v8, v6, #5
	orr.16b	v8, v8, v3
	orr.16b	v31, v31, v16
	orr.16b	v22, v22, v17
	orr.16b	v21, v21, v18
	add.2d	v9, v1, v21
	add.2d	v10, v1, v22
	add.2d	v11, v1, v31
	add.2d	v12, v1, v8
	mov.d	x11, v12[1]
	mov.d	x13, v11[1]
	mov.d	x3, v10[1]
	fmov	x21, d12
	fmov	x30, d10
	mov.d	x0, v9[1]
	fmov	x20, d9
	ldr	s9, [x30]
	ld1.s	{ v9 }[1], [x3]
	ld1.s	{ v9 }[2], [x20]
	ld1.s	{ v9 }[3], [x0]
	fmov	x0, d11
	ldr	s10, [x21]
	ld1.s	{ v10 }[1], [x11]
	ld1.s	{ v10 }[2], [x0]
	ld1.s	{ v10 }[3], [x13]
	fdiv.4s	v10, v10, v5
	fdiv.4s	v9, v9, v5
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v31, v0, v31
	add.2d	v8, v0, v8
	mov.d	x11, v8[1]
	fmov	x13, d8
	mov.d	x0, v31[1]
	mov.d	x3, v22[1]
	mov.d	x20, v21[1]
	fmov	x21, d31
	ldr	s31, [x13]
	ld1.s	{ v31 }[1], [x11]
	ld1.s	{ v31 }[2], [x21]
	fmov	x11, d22
	ld1.s	{ v31 }[3], [x0]
	ldr	s22, [x11]
	ld1.s	{ v22 }[1], [x3]
	fmov	x11, d21
	ld1.s	{ v22 }[2], [x11]
	ld1.s	{ v22 }[3], [x20]
	fmul.4s	v21, v9, v22
	fmul.4s	v22, v10, v31
	add	x8, x12, x8, lsl #5
	stp	q22, q21, [x8]
	dup.2d	v21, x28
	add.2d	v19, v19, v21
	add.2d	v7, v7, v21
	add.2d	v20, v20, v21
	add.2d	v6, v6, v21
	fmov	x8, d6
	cmp	x8, #512
	b.lt	LBB0_11
; %bb.12:                               ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	stp	q30, q28, [sp, #560]            ; 32-byte Folded Spill
	stp	q27, q26, [sp, #688]            ; 32-byte Folded Spill
	mov	x12, #0                         ; =0x0
	ldr	q5, [sp, #34208]
	fdiv.4s	v4, v5, v4
	fmul.4s	v2, v2, v4
	str	s2, [x17, x9]
	orr	w9, w4, #0x1
	mov	w11, #16388                     ; =0x4004
	umull	x8, w9, w11
	umaddl	x9, w9, w11, x1
	ldr	w15, [sp, #372]                 ; 4-byte Folded Reload
LBB0_13:                                ; %direct.true.i8.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x9, x12
	ldp	q2, q4, [x11]
	add	x11, x14, x12
	stp	q2, q4, [x11]
	add	x12, x12, #32
	cmp	x12, #4, lsl #12                ; =16384
	b.ne	LBB0_13
; %bb.14:                               ; %direct.false.i14.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #4, lsl #12             ; =16384
	ldr	s2, [x1, x9]
	mov	w11, #16384                     ; =0x4000
	str	q2, [sp, #496]                  ; 16-byte Folded Spill
	str	s2, [x14, x11]
	ldr	q2, [sp, #17824]
	ldr	q4, [sp, #17840]
	fmul.4s	v5, v4, v4
	fmul.4s	v4, v2, v2
	ldr	q2, [sp, #17856]
	ldr	q6, [sp, #17872]
	fmul.4s	v7, v6, v6
	fmul.4s	v6, v2, v2
	ldr	q2, [sp, #17888]
	ldr	q19, [sp, #17904]
	fmul.4s	v31, v19, v19
	fmul.4s	v8, v2, v2
	ldr	q2, [sp, #17920]
	ldr	q19, [sp, #17936]
	fmul.4s	v10, v19, v19
	fmul.4s	v9, v2, v2
	dup.2d	v11, x27
	mov.16b	v12, v11
	mov.16b	v13, v11
	mov.16b	v14, v11
	mov.16b	v28, v25
	ldp	q24, q30, [sp, #608]            ; 32-byte Folded Reload
	ldp	q26, q25, [sp, #576]            ; 32-byte Folded Reload
	ldp	q29, q27, [sp, #544]            ; 32-byte Folded Reload
LBB0_15:                                ; %direct.true57.i26.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v2, v11, #5
	shl.2d	v20, v12, #5
	shl.2d	v21, v13, #5
	shl.2d	v19, v14, #5
	add.2d	v15, v1, v19
	add.2d	v22, v15, v18
	add.2d	v19, v1, v2
	add.2d	v23, v19, v3
	mov.d	x11, v23[1]
	add.2d	v2, v1, v21
	add.2d	v20, v1, v20
	fmov	x12, d23
	add.2d	v21, v20, v16
	mov.d	x13, v21[1]
	fmov	x0, d21
	add.2d	v21, v2, v17
	mov.d	x3, v21[1]
	fmov	x20, d21
	mov.d	x21, v22[1]
	ldr	s21, [x12]
	ld1.s	{ v21 }[1], [x11]
	fmov	x11, d22
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x13]
	ldr	s22, [x20]
	ld1.s	{ v22 }[1], [x3]
	ld1.s	{ v22 }[2], [x11]
	ld1.s	{ v22 }[3], [x21]
	fmul.4s	v22, v22, v22
	fmul.4s	v21, v21, v21
	fadd.4s	v4, v4, v21
	fadd.4s	v5, v5, v22
	ldr	q21, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v21, v15, v21
	ldr	q22, [sp, #736]                 ; 16-byte Folded Reload
	add.2d	v22, v19, v22
	mov.d	x11, v22[1]
	fmov	x12, d22
	ldr	q22, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v22, v20, v22
	mov.d	x13, v22[1]
	fmov	x0, d22
	ldr	q22, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v2, v22
	mov.d	x3, v22[1]
	mov.d	x20, v21[1]
	fmov	x21, d22
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x11]
	ld1.s	{ v22 }[2], [x0]
	fmov	x11, d21
	ld1.s	{ v22 }[3], [x13]
	ldr	s21, [x21]
	ld1.s	{ v21 }[1], [x3]
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x20]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	fadd.4s	v6, v6, v22
	fadd.4s	v7, v7, v21
	add.2d	v21, v15, v24
	add.2d	v22, v19, v28
	mov.d	x11, v22[1]
	fmov	x12, d22
	ldr	q22, [sp, #656]                 ; 16-byte Folded Reload
	add.2d	v22, v20, v22
	mov.d	x13, v22[1]
	fmov	x0, d22
	add.2d	v22, v2, v30
	mov.d	x3, v22[1]
	fmov	x20, d22
	mov.d	x21, v21[1]
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x11]
	ld1.s	{ v22 }[2], [x0]
	ld1.s	{ v22 }[3], [x13]
	fmov	x11, d21
	fmul.4s	v21, v22, v22
	fadd.4s	v8, v8, v21
	ldr	s21, [x20]
	ld1.s	{ v21 }[1], [x3]
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x21]
	fmul.4s	v21, v21, v21
	fadd.4s	v31, v31, v21
	add.2d	v20, v20, v26
	add.2d	v19, v19, v25
	mov.d	x11, v19[1]
	mov.d	x12, v20[1]
	fmov	x13, d19
	fmov	x0, d20
	add.2d	v19, v15, v29
	add.2d	v2, v2, v27
	mov.d	x3, v2[1]
	fmov	x20, d2
	mov.d	x21, v19[1]
	ldr	s2, [x13]
	ld1.s	{ v2 }[1], [x11]
	fmov	x11, d19
	ld1.s	{ v2 }[2], [x0]
	ld1.s	{ v2 }[3], [x12]
	fmul.4s	v2, v2, v2
	fadd.4s	v9, v9, v2
	ldr	s2, [x20]
	ld1.s	{ v2 }[1], [x3]
	ld1.s	{ v2 }[2], [x11]
	ld1.s	{ v2 }[3], [x21]
	fmul.4s	v2, v2, v2
	fadd.4s	v10, v10, v2
	dup.2d	v2, x27
	add.2d	v13, v13, v2
	add.2d	v12, v12, v2
	add.2d	v14, v14, v2
	add.2d	v11, v11, v2
	fmov	x11, d11
	cmp	x11, #512
	b.lt	LBB0_15
; %bb.16:                               ; %direct.true85.i33.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	movi.2d	v2, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v11, #0000000000000000
LBB0_17:                                ; %direct.true85.i33.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x2, x12, lsl #5
	ldp	q22, q21, [x11]
	shl.2d	v23, v2, #5
	shl.2d	v12, v19, #5
	shl.2d	v13, v20, #5
	shl.2d	v14, v11, #5
	add.2d	v14, v14, v18
	add.2d	v14, v0, v14
	add.2d	v13, v13, v17
	add.2d	v12, v12, v16
	add.2d	v23, v23, v3
	add.2d	v23, v0, v23
	mov.d	x11, v23[1]
	fmov	x12, d23
	str	s22, [x12]
	st1.s	{ v22 }[1], [x11]
	add.2d	v23, v0, v12
	mov.d	x11, v23[1]
	fmov	x12, d23
	st1.s	{ v22 }[2], [x12]
	add.2d	v23, v0, v13
	st1.s	{ v22 }[3], [x11]
	mov.d	x11, v23[1]
	fmov	x12, d23
	str	s21, [x12]
	st1.s	{ v21 }[1], [x11]
	mov.d	x11, v14[1]
	fmov	x12, d14
	st1.s	{ v21 }[2], [x12]
	st1.s	{ v21 }[3], [x11]
	dup.2d	v21, x28
	add.2d	v20, v20, v21
	add.2d	v19, v19, v21
	add.2d	v11, v11, v21
	add.2d	v2, v2, v21
	fmov	x12, d2
	cmp	x12, #512
	b.lt	LBB0_17
; %bb.18:                               ; %direct.false86.i37.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	ldr	q2, [sp, #496]                  ; 16-byte Folded Reload
	fmul.4s	v2, v2, v2
	fadd.4s	v2, v2, v4
	mov.s	v4[0], v2[0]
	fadd.4s	v2, v7, v5
	fadd.4s	v4, v6, v4
	fadd.4s	v4, v8, v4
	fadd.4s	v2, v31, v2
	fadd.4s	v2, v10, v2
	fadd.4s	v4, v9, v4
	rev64.4s	v5, v4
	rev64.4s	v6, v2
	fadd.4s	v2, v2, v6
	fadd.4s	v4, v4, v5
	dup.4s	v5, v4[2]
	dup.4s	v6, v2[2]
	fadd.4s	v2, v2, v6
	fadd.4s	v4, v4, v5
	fadd.4s	v2, v4, v2
	movi	d4, #0000000000000000
	fadd	s4, s2, s4
	mov	w11, #2048                      ; =0x800
	movk	w11, #17792, lsl #16
	fmov	s5, w11
	ldr	q2, [sp, #17792]
	ld1.s	{ v2 }[0], [x5]
	fdiv	s4, s4, s5
	mov	w11, #50604                     ; =0xc5ac
	movk	w11, #14119, lsl #16
	fmov	s5, w11
	fadd	s4, s4, s5
	fsqrt	s4, s4
	dup.4s	v5, v4[0]
	str	q2, [sp, #17792]
	add	x8, x17, x8
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB0_19:                                ; %direct.true109.i45.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v20, #5
	shl.2d	v22, v19, #5
	shl.2d	v23, v7, #5
	shl.2d	v31, v6, #5
	orr.16b	v31, v31, v3
	orr.16b	v23, v23, v16
	orr.16b	v22, v22, v17
	orr.16b	v21, v21, v18
	add.2d	v8, v1, v21
	add.2d	v9, v1, v22
	add.2d	v10, v1, v23
	add.2d	v11, v1, v31
	mov.d	x11, v11[1]
	mov.d	x13, v10[1]
	mov.d	x0, v9[1]
	fmov	x3, d11
	fmov	x20, d9
	mov.d	x21, v8[1]
	fmov	x30, d8
	ldr	s8, [x20]
	ld1.s	{ v8 }[1], [x0]
	ld1.s	{ v8 }[2], [x30]
	ld1.s	{ v8 }[3], [x21]
	fmov	x0, d10
	ldr	s9, [x3]
	ld1.s	{ v9 }[1], [x11]
	ld1.s	{ v9 }[2], [x0]
	ld1.s	{ v9 }[3], [x13]
	fdiv.4s	v9, v9, v5
	fdiv.4s	v8, v8, v5
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v31, v0, v31
	mov.d	x11, v31[1]
	fmov	x13, d31
	mov.d	x0, v23[1]
	mov.d	x3, v22[1]
	mov.d	x20, v21[1]
	fmov	x21, d23
	ldr	s23, [x13]
	ld1.s	{ v23 }[1], [x11]
	ld1.s	{ v23 }[2], [x21]
	fmov	x11, d22
	ld1.s	{ v23 }[3], [x0]
	ldr	s22, [x11]
	ld1.s	{ v22 }[1], [x3]
	fmov	x11, d21
	ld1.s	{ v22 }[2], [x11]
	ld1.s	{ v22 }[3], [x20]
	fmul.4s	v21, v8, v22
	fmul.4s	v22, v9, v23
	add	x11, x8, x12, lsl #5
	stp	q22, q21, [x11]
	dup.2d	v21, x28
	add.2d	v19, v19, v21
	add.2d	v7, v7, v21
	add.2d	v20, v20, v21
	add.2d	v6, v6, v21
	fmov	x12, d6
	cmp	x12, #512
	b.lt	LBB0_19
; %bb.20:                               ; %llm_rows.full_packet.exit50.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	ldr	q5, [sp, #34208]
	fdiv.4s	v4, v5, v4
	fmul.4s	v2, v2, v4
	str	s2, [x17, x9]
	orr	w9, w4, #0x2
	mov	w11, #16388                     ; =0x4004
	umull	x8, w9, w11
	umaddl	x9, w9, w11, x1
LBB0_21:                                ; %direct.true.i56.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x9, x12
	ldp	q2, q4, [x11]
	add	x11, x14, x12
	stp	q2, q4, [x11]
	add	x12, x12, #32
	cmp	x12, #4, lsl #12                ; =16384
	b.ne	LBB0_21
; %bb.22:                               ; %direct.false.i62.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #4, lsl #12             ; =16384
	ldr	s2, [x1, x9]
	mov	w11, #16384                     ; =0x4000
	str	q2, [sp, #496]                  ; 16-byte Folded Spill
	str	s2, [x14, x11]
	ldr	q2, [sp, #17824]
	ldr	q4, [sp, #17840]
	fmul.4s	v5, v4, v4
	fmul.4s	v4, v2, v2
	ldr	q2, [sp, #17856]
	ldr	q6, [sp, #17872]
	fmul.4s	v7, v6, v6
	fmul.4s	v6, v2, v2
	ldr	q2, [sp, #17888]
	ldr	q19, [sp, #17904]
	fmul.4s	v31, v19, v19
	fmul.4s	v8, v2, v2
	ldr	q2, [sp, #17920]
	ldr	q19, [sp, #17936]
	fmul.4s	v10, v19, v19
	fmul.4s	v9, v2, v2
	dup.2d	v11, x27
	mov.16b	v12, v11
	mov.16b	v13, v11
	mov.16b	v14, v11
	ldr	q29, [sp, #656]                 ; 16-byte Folded Reload
	ldp	q24, q30, [sp, #608]            ; 32-byte Folded Reload
	ldp	q26, q25, [sp, #576]            ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #544]            ; 32-byte Folded Reload
LBB0_23:                                ; %direct.true57.i74.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v2, v11, #5
	shl.2d	v20, v12, #5
	shl.2d	v21, v13, #5
	shl.2d	v19, v14, #5
	add.2d	v15, v1, v19
	add.2d	v22, v15, v18
	add.2d	v19, v1, v2
	add.2d	v23, v19, v3
	mov.d	x11, v23[1]
	add.2d	v2, v1, v21
	add.2d	v20, v1, v20
	fmov	x12, d23
	add.2d	v21, v20, v16
	mov.d	x13, v21[1]
	fmov	x0, d21
	add.2d	v21, v2, v17
	mov.d	x3, v21[1]
	fmov	x20, d21
	mov.d	x21, v22[1]
	ldr	s21, [x12]
	ld1.s	{ v21 }[1], [x11]
	fmov	x11, d22
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x13]
	ldr	s22, [x20]
	ld1.s	{ v22 }[1], [x3]
	ld1.s	{ v22 }[2], [x11]
	ld1.s	{ v22 }[3], [x21]
	fmul.4s	v22, v22, v22
	fmul.4s	v21, v21, v21
	fadd.4s	v4, v4, v21
	fadd.4s	v5, v5, v22
	ldr	q21, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v21, v15, v21
	ldr	q22, [sp, #736]                 ; 16-byte Folded Reload
	add.2d	v22, v19, v22
	mov.d	x11, v22[1]
	fmov	x12, d22
	ldr	q22, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v22, v20, v22
	mov.d	x13, v22[1]
	fmov	x0, d22
	ldr	q22, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v2, v22
	mov.d	x3, v22[1]
	mov.d	x20, v21[1]
	fmov	x21, d22
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x11]
	ld1.s	{ v22 }[2], [x0]
	fmov	x11, d21
	ld1.s	{ v22 }[3], [x13]
	ldr	s21, [x21]
	ld1.s	{ v21 }[1], [x3]
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x20]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	fadd.4s	v6, v6, v22
	fadd.4s	v7, v7, v21
	add.2d	v21, v15, v24
	ldr	q22, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v22, v19, v22
	mov.d	x11, v22[1]
	fmov	x12, d22
	add.2d	v22, v20, v29
	mov.d	x13, v22[1]
	fmov	x0, d22
	add.2d	v22, v2, v30
	mov.d	x3, v22[1]
	fmov	x20, d22
	mov.d	x21, v21[1]
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x11]
	ld1.s	{ v22 }[2], [x0]
	ld1.s	{ v22 }[3], [x13]
	fmov	x11, d21
	fmul.4s	v21, v22, v22
	fadd.4s	v8, v8, v21
	ldr	s21, [x20]
	ld1.s	{ v21 }[1], [x3]
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x21]
	fmul.4s	v21, v21, v21
	fadd.4s	v31, v31, v21
	add.2d	v20, v20, v26
	add.2d	v19, v19, v25
	mov.d	x11, v19[1]
	mov.d	x12, v20[1]
	fmov	x13, d19
	fmov	x0, d20
	add.2d	v19, v15, v28
	add.2d	v2, v2, v27
	mov.d	x3, v2[1]
	fmov	x20, d2
	mov.d	x21, v19[1]
	ldr	s2, [x13]
	ld1.s	{ v2 }[1], [x11]
	fmov	x11, d19
	ld1.s	{ v2 }[2], [x0]
	ld1.s	{ v2 }[3], [x12]
	fmul.4s	v2, v2, v2
	fadd.4s	v9, v9, v2
	ldr	s2, [x20]
	ld1.s	{ v2 }[1], [x3]
	ld1.s	{ v2 }[2], [x11]
	ld1.s	{ v2 }[3], [x21]
	fmul.4s	v2, v2, v2
	fadd.4s	v10, v10, v2
	dup.2d	v2, x27
	add.2d	v13, v13, v2
	add.2d	v12, v12, v2
	add.2d	v14, v14, v2
	add.2d	v11, v11, v2
	fmov	x11, d11
	cmp	x11, #512
	b.lt	LBB0_23
; %bb.24:                               ; %direct.true85.i81.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	movi.2d	v2, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v11, #0000000000000000
LBB0_25:                                ; %direct.true85.i81.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x11, x2, x12, lsl #5
	ldp	q22, q21, [x11]
	shl.2d	v23, v2, #5
	shl.2d	v12, v19, #5
	shl.2d	v13, v20, #5
	shl.2d	v14, v11, #5
	add.2d	v14, v14, v18
	add.2d	v14, v0, v14
	add.2d	v13, v13, v17
	add.2d	v12, v12, v16
	add.2d	v23, v23, v3
	add.2d	v23, v0, v23
	mov.d	x11, v23[1]
	fmov	x12, d23
	str	s22, [x12]
	st1.s	{ v22 }[1], [x11]
	add.2d	v23, v0, v12
	mov.d	x11, v23[1]
	fmov	x12, d23
	st1.s	{ v22 }[2], [x12]
	add.2d	v23, v0, v13
	st1.s	{ v22 }[3], [x11]
	mov.d	x11, v23[1]
	fmov	x12, d23
	str	s21, [x12]
	st1.s	{ v21 }[1], [x11]
	mov.d	x11, v14[1]
	fmov	x12, d14
	st1.s	{ v21 }[2], [x12]
	st1.s	{ v21 }[3], [x11]
	dup.2d	v21, x28
	add.2d	v20, v20, v21
	add.2d	v19, v19, v21
	add.2d	v11, v11, v21
	add.2d	v2, v2, v21
	fmov	x12, d2
	cmp	x12, #512
	b.lt	LBB0_25
; %bb.26:                               ; %direct.false86.i85.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	ldr	q2, [sp, #496]                  ; 16-byte Folded Reload
	fmul.4s	v2, v2, v2
	fadd.4s	v2, v2, v4
	mov.s	v4[0], v2[0]
	fadd.4s	v2, v7, v5
	fadd.4s	v4, v6, v4
	fadd.4s	v4, v8, v4
	fadd.4s	v2, v31, v2
	fadd.4s	v2, v10, v2
	fadd.4s	v4, v9, v4
	rev64.4s	v5, v4
	rev64.4s	v6, v2
	fadd.4s	v2, v2, v6
	fadd.4s	v4, v4, v5
	dup.4s	v5, v4[2]
	dup.4s	v6, v2[2]
	fadd.4s	v2, v2, v6
	fadd.4s	v4, v4, v5
	fadd.4s	v2, v4, v2
	movi	d4, #0000000000000000
	fadd	s4, s2, s4
	mov	w11, #2048                      ; =0x800
	movk	w11, #17792, lsl #16
	fmov	s5, w11
	ldr	q2, [sp, #17792]
	ld1.s	{ v2 }[0], [x5]
	fdiv	s4, s4, s5
	mov	w11, #50604                     ; =0xc5ac
	movk	w11, #14119, lsl #16
	fmov	s5, w11
	fadd	s4, s4, s5
	fsqrt	s4, s4
	dup.4s	v5, v4[0]
	str	q2, [sp, #17792]
	add	x8, x17, x8
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB0_27:                                ; %direct.true109.i93.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v20, #5
	shl.2d	v22, v19, #5
	shl.2d	v23, v7, #5
	shl.2d	v31, v6, #5
	orr.16b	v31, v31, v3
	orr.16b	v23, v23, v16
	orr.16b	v22, v22, v17
	orr.16b	v21, v21, v18
	add.2d	v8, v1, v21
	add.2d	v9, v1, v22
	add.2d	v10, v1, v23
	add.2d	v11, v1, v31
	mov.d	x11, v11[1]
	mov.d	x13, v10[1]
	mov.d	x0, v9[1]
	fmov	x3, d11
	fmov	x20, d9
	mov.d	x21, v8[1]
	fmov	x30, d8
	ldr	s8, [x20]
	ld1.s	{ v8 }[1], [x0]
	ld1.s	{ v8 }[2], [x30]
	ld1.s	{ v8 }[3], [x21]
	fmov	x0, d10
	ldr	s9, [x3]
	ld1.s	{ v9 }[1], [x11]
	ld1.s	{ v9 }[2], [x0]
	ld1.s	{ v9 }[3], [x13]
	fdiv.4s	v9, v9, v5
	fdiv.4s	v8, v8, v5
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v31, v0, v31
	mov.d	x11, v31[1]
	fmov	x13, d31
	mov.d	x0, v23[1]
	mov.d	x3, v22[1]
	mov.d	x20, v21[1]
	fmov	x21, d23
	ldr	s23, [x13]
	ld1.s	{ v23 }[1], [x11]
	ld1.s	{ v23 }[2], [x21]
	fmov	x11, d22
	ld1.s	{ v23 }[3], [x0]
	ldr	s22, [x11]
	ld1.s	{ v22 }[1], [x3]
	fmov	x11, d21
	ld1.s	{ v22 }[2], [x11]
	ld1.s	{ v22 }[3], [x20]
	fmul.4s	v21, v8, v22
	fmul.4s	v22, v9, v23
	add	x11, x8, x12, lsl #5
	stp	q22, q21, [x11]
	dup.2d	v21, x28
	add.2d	v19, v19, v21
	add.2d	v7, v7, v21
	add.2d	v20, v20, v21
	add.2d	v6, v6, v21
	fmov	x12, d6
	cmp	x12, #512
	b.lt	LBB0_27
; %bb.28:                               ; %llm_rows.full_packet.exit98.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q5, [sp, #34208]
	fdiv.4s	v4, v5, v4
	fmul.4s	v2, v2, v4
	str	s2, [x17, x9]
	orr	w9, w4, #0x3
	mov	w12, #16388                     ; =0x4004
	umull	x11, w9, w12
	umaddl	x9, w9, w12, x1
LBB0_29:                                ; %direct.true.i104.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x9, x8
	ldp	q2, q4, [x12]
	add	x12, x14, x8
	stp	q2, q4, [x12]
	add	x8, x8, #32
	cmp	x8, #4, lsl #12                 ; =16384
	b.ne	LBB0_29
; %bb.30:                               ; %direct.false.i110.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x11, #4, lsl #12            ; =16384
	ldr	s2, [x1, x9]
	str	q2, [sp, #512]                  ; 16-byte Folded Spill
	str	s2, [x14, x8]
	ldr	q2, [sp, #17824]
	ldr	q4, [sp, #17840]
	fmul.4s	v4, v4, v4
	fmul.4s	v2, v2, v2
	ldr	q5, [sp, #17856]
	ldr	q6, [sp, #17872]
	fmul.4s	v6, v6, v6
	fmul.4s	v5, v5, v5
	ldr	q19, [sp, #17888]
	ldr	q7, [sp, #17904]
	fmul.4s	v7, v7, v7
	fmul.4s	v31, v19, v19
	ldr	q19, [sp, #17920]
	ldr	q20, [sp, #17936]
	fmul.4s	v9, v20, v20
	fmul.4s	v8, v19, v19
	dup.2d	v11, x27
	mov.16b	v12, v11
	mov.16b	v13, v11
	mov.16b	v14, v11
	ldr	q29, [sp, #656]                 ; 16-byte Folded Reload
	ldp	q24, q30, [sp, #608]            ; 32-byte Folded Reload
	ldp	q26, q25, [sp, #576]            ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #544]            ; 32-byte Folded Reload
LBB0_31:                                ; %direct.true57.i122.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v19, v11, #5
	shl.2d	v20, v12, #5
	shl.2d	v21, v13, #5
	shl.2d	v22, v14, #5
	add.2d	v15, v1, v22
	add.2d	v22, v15, v18
	add.2d	v19, v1, v19
	add.2d	v23, v19, v3
	mov.d	x8, v23[1]
	add.2d	v10, v1, v21
	add.2d	v20, v1, v20
	fmov	x12, d23
	add.2d	v21, v20, v16
	mov.d	x13, v21[1]
	fmov	x0, d21
	add.2d	v21, v10, v17
	mov.d	x3, v21[1]
	fmov	x20, d21
	mov.d	x21, v22[1]
	ldr	s21, [x12]
	ld1.s	{ v21 }[1], [x8]
	fmov	x8, d22
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x13]
	ldr	s22, [x20]
	ld1.s	{ v22 }[1], [x3]
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x21]
	fmul.4s	v22, v22, v22
	fmul.4s	v21, v21, v21
	fadd.4s	v2, v2, v21
	fadd.4s	v4, v4, v22
	ldr	q21, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v21, v15, v21
	ldr	q22, [sp, #736]                 ; 16-byte Folded Reload
	add.2d	v22, v19, v22
	mov.d	x8, v22[1]
	fmov	x12, d22
	ldr	q22, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v22, v20, v22
	mov.d	x13, v22[1]
	fmov	x0, d22
	ldr	q22, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v10, v22
	mov.d	x3, v22[1]
	mov.d	x20, v21[1]
	fmov	x21, d22
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x8]
	ld1.s	{ v22 }[2], [x0]
	fmov	x8, d21
	ld1.s	{ v22 }[3], [x13]
	ldr	s21, [x21]
	ld1.s	{ v21 }[1], [x3]
	ld1.s	{ v21 }[2], [x8]
	ld1.s	{ v21 }[3], [x20]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	fadd.4s	v5, v5, v22
	fadd.4s	v6, v6, v21
	add.2d	v21, v15, v24
	ldr	q22, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v22, v19, v22
	mov.d	x8, v22[1]
	fmov	x12, d22
	add.2d	v22, v20, v29
	mov.d	x13, v22[1]
	fmov	x0, d22
	add.2d	v22, v10, v30
	mov.d	x3, v22[1]
	fmov	x20, d22
	mov.d	x21, v21[1]
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x8]
	ld1.s	{ v22 }[2], [x0]
	ld1.s	{ v22 }[3], [x13]
	fmov	x8, d21
	fmul.4s	v21, v22, v22
	fadd.4s	v31, v31, v21
	ldr	s21, [x20]
	ld1.s	{ v21 }[1], [x3]
	ld1.s	{ v21 }[2], [x8]
	ld1.s	{ v21 }[3], [x21]
	fmul.4s	v21, v21, v21
	fadd.4s	v7, v7, v21
	add.2d	v20, v20, v26
	add.2d	v19, v19, v25
	mov.d	x8, v19[1]
	mov.d	x12, v20[1]
	fmov	x13, d19
	fmov	x0, d20
	add.2d	v19, v15, v28
	add.2d	v20, v10, v27
	mov.d	x3, v20[1]
	fmov	x20, d20
	mov.d	x21, v19[1]
	ldr	s20, [x13]
	ld1.s	{ v20 }[1], [x8]
	fmov	x8, d19
	ld1.s	{ v20 }[2], [x0]
	ld1.s	{ v20 }[3], [x12]
	fmul.4s	v19, v20, v20
	fadd.4s	v8, v8, v19
	ldr	s19, [x20]
	ld1.s	{ v19 }[1], [x3]
	ld1.s	{ v19 }[2], [x8]
	ld1.s	{ v19 }[3], [x21]
	fmul.4s	v19, v19, v19
	fadd.4s	v9, v9, v19
	dup.2d	v19, x27
	add.2d	v13, v13, v19
	add.2d	v12, v12, v19
	add.2d	v14, v14, v19
	add.2d	v11, v11, v19
	fmov	x8, d11
	cmp	x8, #512
	b.lt	LBB0_31
; %bb.32:                               ; %direct.true85.i129.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
LBB0_33:                                ; %direct.true85.i129.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, x2, x8, lsl #5
	ldp	q24, q23, [x8]
	shl.2d	v25, v19, #5
	shl.2d	v26, v20, #5
	shl.2d	v27, v21, #5
	shl.2d	v28, v22, #5
	add.2d	v28, v28, v18
	add.2d	v28, v0, v28
	add.2d	v27, v27, v17
	add.2d	v26, v26, v16
	add.2d	v25, v25, v3
	add.2d	v25, v0, v25
	mov.d	x8, v25[1]
	fmov	x12, d25
	str	s24, [x12]
	st1.s	{ v24 }[1], [x8]
	add.2d	v25, v0, v26
	mov.d	x8, v25[1]
	fmov	x12, d25
	st1.s	{ v24 }[2], [x12]
	add.2d	v25, v0, v27
	st1.s	{ v24 }[3], [x8]
	mov.d	x8, v25[1]
	fmov	x12, d25
	str	s23, [x12]
	st1.s	{ v23 }[1], [x8]
	mov.d	x8, v28[1]
	fmov	x12, d28
	st1.s	{ v23 }[2], [x12]
	st1.s	{ v23 }[3], [x8]
	dup.2d	v23, x28
	add.2d	v21, v21, v23
	add.2d	v20, v20, v23
	add.2d	v22, v22, v23
	add.2d	v19, v19, v23
	fmov	x8, d19
	cmp	x8, #512
	b.lt	LBB0_33
; %bb.34:                               ; %direct.false86.i133.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q19, [sp, #512]                 ; 16-byte Folded Reload
	fmul.4s	v19, v19, v19
	fadd.4s	v19, v19, v2
	mov.s	v2[0], v19[0]
	ldr	q19, [sp, #17792]
	ld1.s	{ v19 }[0], [x5]
	fadd.4s	v4, v6, v4
	fadd.4s	v2, v5, v2
	fadd.4s	v2, v31, v2
	fadd.4s	v4, v7, v4
	fadd.4s	v4, v9, v4
	fadd.4s	v2, v8, v2
	rev64.4s	v5, v2
	rev64.4s	v6, v4
	fadd.4s	v4, v4, v6
	fadd.4s	v2, v2, v5
	dup.4s	v5, v2[2]
	dup.4s	v6, v4[2]
	fadd.4s	v4, v4, v6
	fadd.4s	v2, v2, v5
	fadd.4s	v2, v2, v4
	movi	d11, #0000000000000000
	fadd	s2, s2, s11
	mov	w12, #2048                      ; =0x800
	movk	w12, #17792, lsl #16
	fmov	s4, w12
	fdiv	s2, s2, s4
	mov	w12, #50604                     ; =0xc5ac
	movk	w12, #14119, lsl #16
	fmov	s4, w12
	fadd	s2, s2, s4
	fsqrt	s2, s2
	dup.4s	v4, v2[0]
	str	q19, [sp, #17792]
	add	x11, x17, x11
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB0_35:                                ; %direct.true109.i141.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v20, #5
	shl.2d	v22, v7, #5
	shl.2d	v23, v6, #5
	shl.2d	v24, v5, #5
	orr.16b	v24, v24, v3
	orr.16b	v23, v23, v16
	orr.16b	v22, v22, v17
	orr.16b	v21, v21, v18
	add.2d	v25, v1, v21
	add.2d	v26, v1, v22
	add.2d	v27, v1, v23
	add.2d	v28, v1, v24
	mov.d	x12, v28[1]
	mov.d	x13, v27[1]
	mov.d	x0, v26[1]
	fmov	x2, d28
	fmov	x3, d26
	mov.d	x20, v25[1]
	fmov	x21, d25
	ldr	s25, [x3]
	ld1.s	{ v25 }[1], [x0]
	ld1.s	{ v25 }[2], [x21]
	ld1.s	{ v25 }[3], [x20]
	fmov	x0, d27
	ldr	s26, [x2]
	ld1.s	{ v26 }[1], [x12]
	ld1.s	{ v26 }[2], [x0]
	ld1.s	{ v26 }[3], [x13]
	fdiv.4s	v26, v26, v4
	fdiv.4s	v25, v25, v4
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v24, v0, v24
	mov.d	x12, v24[1]
	fmov	x13, d24
	mov.d	x0, v23[1]
	mov.d	x2, v22[1]
	mov.d	x3, v21[1]
	fmov	x20, d23
	ldr	s23, [x13]
	ld1.s	{ v23 }[1], [x12]
	ld1.s	{ v23 }[2], [x20]
	fmov	x12, d22
	ld1.s	{ v23 }[3], [x0]
	ldr	s22, [x12]
	ld1.s	{ v22 }[1], [x2]
	fmov	x12, d21
	ld1.s	{ v22 }[2], [x12]
	ld1.s	{ v22 }[3], [x3]
	fmul.4s	v21, v25, v22
	fmul.4s	v22, v26, v23
	add	x8, x11, x8, lsl #5
	stp	q22, q21, [x8]
	dup.2d	v21, x28
	add.2d	v7, v7, v21
	add.2d	v6, v6, v21
	add.2d	v20, v20, v21
	add.2d	v5, v5, v21
	fmov	x8, d5
	cmp	x8, #512
	b.lt	LBB0_35
; %bb.36:                               ; %llm_rows.full_packet.exit146.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q4, [sp, #34208]
	fdiv.4s	v2, v4, v2
	fmul.4s	v2, v19, v2
	str	s2, [x17, x9]
	adrp	x1, lCPI0_2@PAGE
	adrp	x4, lCPI0_4@PAGE
	adrp	x17, lCPI0_3@PAGE
	adrp	x5, lCPI0_5@PAGE
	adrp	x6, lCPI0_6@PAGE
	adrp	x7, lCPI0_7@PAGE
	adrp	x19, lCPI0_8@PAGE
	adrp	x20, lCPI0_9@PAGE
	ldr	w13, [sp, #368]                 ; 4-byte Folded Reload
	ldr	w0, [sp, #364]                  ; 4-byte Folded Reload
	ldr	x2, [sp, #376]                  ; 8-byte Folded Reload
	b	LBB0_2
LBB0_37:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	lsr	x8, x9, #3
	str	x8, [sp, #720]                  ; 8-byte Folded Spill
	str	x9, [sp, #624]                  ; 8-byte Folded Spill
	cmp	x9, #8
	b.lo	LBB0_48
; %bb.38:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x2, #0                          ; =0x0
	ldr	x8, [sp, #336]                  ; 8-byte Folded Reload
	ldr	x10, [x8]
	ldr	x20, [x8, #16]
	ldr	x12, [x8, #48]
	add	x8, x20, #4, lsl #12            ; =16384
	str	x8, [sp, #688]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #376]                  ; 8-byte Folded Reload
	lsl	w9, w8, #2
	str	x9, [sp, #672]                  ; 8-byte Folded Spill
                                        ; kill: def $w8 killed $w8 killed $x8 def $x8
	and	x8, x8, #0x7ffffff
	mov	w9, #16                         ; =0x10
	movk	w9, #1, lsl #16
	str	x10, [sp, #704]                 ; 8-byte Folded Spill
	umaddl	x21, w8, w9, x10
	str	x12, [sp, #656]                 ; 8-byte Folded Spill
LBB0_39:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_40 Depth 3
                                        ;       Child Loop BB0_42 Depth 3
                                        ;       Child Loop BB0_44 Depth 3
                                        ;       Child Loop BB0_46 Depth 3
	mov	x25, x22
	mov	x12, #0                         ; =0x0
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	add	w8, w2, w8
	and	x8, x8, #0x1fffffff
	add	x8, x8, x8, lsl #12
	lsl	x8, x8, #2
LBB0_40:                                ; %direct.true.i152.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x0, x21, x12
	ldp	q2, q4, [x0]
	add	x0, x14, x12
	stp	q2, q4, [x0]
	add	x12, x12, #32
	cmp	x12, #4, lsl #12                ; =16384
	b.ne	LBB0_40
; %bb.41:                               ; %direct.false.i158.i
                                        ;   in Loop: Header=BB0_39 Depth=2
	add	x10, x8, #4, lsl #12            ; =16384
	ldr	x9, [sp, #704]                  ; 8-byte Folded Reload
	str	x10, [sp, #736]                 ; 8-byte Folded Spill
	ldr	s6, [x9, x10]
	mov	w9, #16384                      ; =0x4000
	str	s6, [x14, x9]
	ldr	q2, [sp, #17824]
	ldr	q4, [sp, #17840]
	fmul.4s	v16, v4, v4
	fmul.4s	v7, v2, v2
	ldr	q2, [sp, #17856]
	ldr	q4, [sp, #17872]
	fmul.4s	v18, v4, v4
	fmul.4s	v17, v2, v2
	ldr	q2, [sp, #17888]
	ldr	q4, [sp, #17904]
	fmul.4s	v19, v4, v4
	fmul.4s	v20, v2, v2
	ldr	q2, [sp, #17920]
	ldr	q4, [sp, #17936]
	fmul.4s	v22, v4, v4
	fmul.4s	v21, v2, v2
	dup.2d	v23, x27
	mov.16b	v24, v23
	mov.16b	v25, v23
	mov.16b	v26, v23
	adrp	x4, lCPI0_2@PAGE
	adrp	x17, lCPI0_4@PAGE
	adrp	x5, lCPI0_3@PAGE
	adrp	x6, lCPI0_5@PAGE
	adrp	x7, lCPI0_6@PAGE
	adrp	x19, lCPI0_7@PAGE
	adrp	x22, lCPI0_8@PAGE
	adrp	x23, lCPI0_9@PAGE
	mov	x24, x25
	adrp	x26, lCPI0_11@PAGE
	mov	w12, #4                         ; =0x4
	adrp	x27, lCPI0_12@PAGE
	adrp	x13, lCPI0_13@PAGE
	adrp	x14, lCPI0_14@PAGE
	adrp	x10, lCPI0_15@PAGE
LBB0_42:                                ; %direct.true57.i170.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.2d	v2, v23, #5
	add.2d	v27, v1, v2
	add.2d	v31, v27, v3
	mov.d	x0, v31[1]
	ldr	q2, [x16, lCPI0_1@PAGEOFF]
	shl.2d	v4, v24, #5
	add.2d	v28, v1, v4
	add.2d	v8, v28, v2
	mov.d	x11, v8[1]
	ldr	q4, [x4, lCPI0_2@PAGEOFF]
	shl.2d	v5, v25, #5
	add.2d	v29, v1, v5
	add.2d	v9, v29, v4
	mov.d	x30, v9[1]
	ldr	q5, [x5, lCPI0_3@PAGEOFF]
	shl.2d	v30, v26, #5
	add.2d	v30, v1, v30
	add.2d	v10, v30, v5
	mov.d	x9, v10[1]
	fmov	x3, d31
	ldr	s31, [x3]
	fmov	x3, d8
	fmov	x1, d9
	ld1.s	{ v31 }[1], [x0]
	fmov	x0, d10
	ld1.s	{ v31 }[2], [x3]
	ld1.s	{ v31 }[3], [x11]
	ldr	s8, [x1]
	ld1.s	{ v8 }[1], [x30]
	ld1.s	{ v8 }[2], [x0]
	ld1.s	{ v8 }[3], [x9]
	fmul.4s	v8, v8, v8
	fmul.4s	v31, v31, v31
	fadd.4s	v7, v7, v31
	fadd.4s	v16, v16, v8
	ldr	q31, [x17, lCPI0_4@PAGEOFF]
	ldr	q8, [x6, lCPI0_5@PAGEOFF]
	ldr	q9, [x7, lCPI0_6@PAGEOFF]
	ldr	q10, [x19, lCPI0_7@PAGEOFF]
	add.2d	v10, v30, v10
	add.2d	v9, v29, v9
	add.2d	v8, v28, v8
	add.2d	v31, v27, v31
	mov.d	x9, v31[1]
	fmov	x11, d31
	mov.d	x0, v8[1]
	fmov	x1, d8
	mov.d	x3, v9[1]
	fmov	x30, d9
	mov.d	x15, v10[1]
	ldr	s31, [x11]
	ld1.s	{ v31 }[1], [x9]
	ld1.s	{ v31 }[2], [x1]
	ld1.s	{ v31 }[3], [x0]
	fmov	x9, d10
	ldr	s8, [x30]
	ld1.s	{ v8 }[1], [x3]
	ld1.s	{ v8 }[2], [x9]
	ld1.s	{ v8 }[3], [x15]
	fmul.4s	v8, v8, v8
	fmul.4s	v31, v31, v31
	fadd.4s	v17, v17, v31
	fadd.4s	v18, v18, v8
	ldr	q31, [x22, lCPI0_8@PAGEOFF]
	ldr	q8, [x23, lCPI0_9@PAGEOFF]
	ldr	q9, [x24, lCPI0_10@PAGEOFF]
	ldr	q10, [x26, lCPI0_11@PAGEOFF]
	add.2d	v10, v30, v10
	add.2d	v9, v29, v9
	add.2d	v8, v28, v8
	add.2d	v31, v27, v31
	mov.d	x9, v31[1]
	mov.d	x11, v8[1]
	fmov	x15, d31
	fmov	x0, d8
	mov.d	x1, v9[1]
	mov.d	x3, v10[1]
	fmov	x30, d9
	ldr	s31, [x15]
	ld1.s	{ v31 }[1], [x9]
	ld1.s	{ v31 }[2], [x0]
	fmov	x9, d10
	ld1.s	{ v31 }[3], [x11]
	ldr	s8, [x30]
	ld1.s	{ v8 }[1], [x1]
	ld1.s	{ v8 }[2], [x9]
	ld1.s	{ v8 }[3], [x3]
	fmul.4s	v8, v8, v8
	fmul.4s	v31, v31, v31
	fadd.4s	v20, v20, v31
	fadd.4s	v19, v19, v8
	ldr	q31, [x27, lCPI0_12@PAGEOFF]
	ldr	q8, [x13, lCPI0_13@PAGEOFF]
	ldr	q9, [x14, lCPI0_14@PAGEOFF]
	ldr	q10, [x10, lCPI0_15@PAGEOFF]
	add.2d	v30, v30, v10
	add.2d	v29, v29, v9
	add.2d	v28, v28, v8
	add.2d	v27, v27, v31
	mov.d	x9, v27[1]
	fmov	x11, d27
	mov.d	x15, v28[1]
	fmov	x0, d28
	mov.d	x1, v29[1]
	fmov	x3, d29
	mov.d	x30, v30[1]
	ldr	s27, [x11]
	ld1.s	{ v27 }[1], [x9]
	fmov	x9, d30
	ld1.s	{ v27 }[2], [x0]
	ld1.s	{ v27 }[3], [x15]
	ldr	s28, [x3]
	ld1.s	{ v28 }[1], [x1]
	ld1.s	{ v28 }[2], [x9]
	ld1.s	{ v28 }[3], [x30]
	fmul.4s	v28, v28, v28
	fmul.4s	v27, v27, v27
	fadd.4s	v21, v21, v27
	fadd.4s	v22, v22, v28
	dup.2d	v27, x12
	add.2d	v25, v25, v27
	add.2d	v24, v24, v27
	add.2d	v26, v26, v27
	add.2d	v23, v23, v27
	fmov	x9, d23
	cmp	x9, #512
	b.lt	LBB0_42
; %bb.43:                               ; %direct.true85.i177.i.preheader
                                        ;   in Loop: Header=BB0_39 Depth=2
	mov	x0, #0                          ; =0x0
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
LBB0_44:                                ; %direct.true85.i177.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x20, x0, lsl #5
	ldp	q28, q27, [x9]
	shl.2d	v29, v23, #5
	shl.2d	v30, v24, #5
	shl.2d	v31, v25, #5
	shl.2d	v8, v26, #5
	add.2d	v8, v8, v5
	add.2d	v8, v0, v8
	add.2d	v31, v31, v4
	add.2d	v30, v30, v2
	add.2d	v29, v29, v3
	add.2d	v29, v0, v29
	mov.d	x9, v29[1]
	fmov	x11, d29
	str	s28, [x11]
	st1.s	{ v28 }[1], [x9]
	add.2d	v29, v0, v30
	mov.d	x9, v29[1]
	fmov	x11, d29
	st1.s	{ v28 }[2], [x11]
	add.2d	v29, v0, v31
	st1.s	{ v28 }[3], [x9]
	mov.d	x9, v29[1]
	fmov	x11, d29
	str	s27, [x11]
	st1.s	{ v27 }[1], [x9]
	mov.d	x9, v8[1]
	fmov	x11, d8
	st1.s	{ v27 }[2], [x11]
	st1.s	{ v27 }[3], [x9]
	dup.2d	v27, x28
	add.2d	v25, v25, v27
	add.2d	v24, v24, v27
	add.2d	v26, v26, v27
	add.2d	v23, v23, v27
	fmov	x0, d23
	cmp	x0, #512
	b.lt	LBB0_44
; %bb.45:                               ; %direct.false86.i181.i
                                        ;   in Loop: Header=BB0_39 Depth=2
	mov	x0, #0                          ; =0x0
	fmul.4s	v6, v6, v6
	fadd.4s	v6, v6, v7
	mov.s	v7[0], v6[0]
	fadd.4s	v6, v18, v16
	fadd.4s	v7, v17, v7
	fadd.4s	v7, v20, v7
	fadd.4s	v6, v19, v6
	fadd.4s	v6, v22, v6
	fadd.4s	v7, v21, v7
	rev64.4s	v16, v7
	rev64.4s	v17, v6
	fadd.4s	v6, v6, v17
	fadd.4s	v7, v7, v16
	dup.4s	v16, v7[2]
	dup.4s	v17, v6[2]
	fadd.4s	v6, v6, v17
	fadd.4s	v7, v7, v16
	fadd.4s	v6, v7, v6
	fadd	s7, s6, s11
	mov	w9, #2048                       ; =0x800
	movk	w9, #17792, lsl #16
	fmov	s16, w9
	ldr	q6, [sp, #17792]
	ldr	x9, [sp, #688]                  ; 8-byte Folded Reload
	ld1.s	{ v6 }[0], [x9]
	fdiv	s7, s7, s16
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s16, w9
	fadd	s7, s7, s16
	fsqrt	s7, s7
	dup.4s	v16, v7[0]
	str	q6, [sp, #17792]
	ldr	x12, [sp, #656]                 ; 8-byte Folded Reload
	add	x8, x12, x8
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	mov	x22, x25
	adrp	x26, lCPI0_14@PAGE
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #1440
	mov	w27, #4                         ; =0x4
LBB0_46:                                ; %direct.true109.i189.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_39 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.2d	v21, v20, #5
	shl.2d	v22, v19, #5
	shl.2d	v23, v18, #5
	shl.2d	v24, v17, #5
	orr.16b	v24, v24, v3
	orr.16b	v23, v23, v2
	orr.16b	v22, v22, v4
	orr.16b	v21, v21, v5
	add.2d	v25, v1, v21
	add.2d	v26, v1, v22
	add.2d	v27, v1, v23
	add.2d	v28, v1, v24
	mov.d	x9, v28[1]
	mov.d	x11, v27[1]
	mov.d	x15, v26[1]
	fmov	x1, d28
	fmov	x3, d26
	mov.d	x30, v25[1]
	fmov	x16, d25
	ldr	s25, [x3]
	ld1.s	{ v25 }[1], [x15]
	ld1.s	{ v25 }[2], [x16]
	ld1.s	{ v25 }[3], [x30]
	fmov	x15, d27
	ldr	s26, [x1]
	ld1.s	{ v26 }[1], [x9]
	ld1.s	{ v26 }[2], [x15]
	ld1.s	{ v26 }[3], [x11]
	fdiv.4s	v26, v26, v16
	fdiv.4s	v25, v25, v16
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v24, v0, v24
	mov.d	x9, v24[1]
	fmov	x11, d24
	mov.d	x15, v23[1]
	mov.d	x16, v22[1]
	mov.d	x1, v21[1]
	fmov	x3, d23
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x9]
	ld1.s	{ v23 }[2], [x3]
	fmov	x9, d22
	ld1.s	{ v23 }[3], [x15]
	ldr	s22, [x9]
	ld1.s	{ v22 }[1], [x16]
	fmov	x9, d21
	ld1.s	{ v22 }[2], [x9]
	ld1.s	{ v22 }[3], [x1]
	fmul.4s	v21, v25, v22
	fmul.4s	v22, v26, v23
	add	x9, x8, x0, lsl #5
	stp	q22, q21, [x9]
	dup.2d	v21, x28
	add.2d	v19, v19, v21
	add.2d	v18, v18, v21
	add.2d	v20, v20, v21
	add.2d	v17, v17, v21
	fmov	x0, d17
	cmp	x0, #512
	b.lt	LBB0_46
; %bb.47:                               ; %llm_rows.full_packet.exit194.i
                                        ;   in Loop: Header=BB0_39 Depth=2
	ldr	q2, [sp, #34208]
	fdiv.4s	v2, v2, v7
	fmul.4s	v2, v6, v2
	ldr	x8, [sp, #736]                  ; 8-byte Folded Reload
	str	s2, [x12, x8]
	add	x2, x2, #1
	mov	w8, #16388                      ; =0x4004
	add	x21, x21, x8
	ldr	x8, [sp, #720]                  ; 8-byte Folded Reload
	cmp	x2, x8
	adrp	x16, lCPI0_1@PAGE
	b.ne	LBB0_39
LBB0_48:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #624]                  ; 8-byte Folded Reload
	and	w8, w8, #0x7
	ldr	w15, [sp, #372]                 ; 4-byte Folded Reload
	adrp	x1, lCPI0_2@PAGE
	adrp	x4, lCPI0_4@PAGE
	adrp	x17, lCPI0_3@PAGE
	adrp	x5, lCPI0_5@PAGE
	adrp	x6, lCPI0_6@PAGE
	adrp	x7, lCPI0_7@PAGE
	adrp	x19, lCPI0_8@PAGE
	adrp	x20, lCPI0_9@PAGE
	adrp	x23, lCPI0_11@PAGE
	adrp	x24, lCPI0_12@PAGE
	adrp	x25, lCPI0_13@PAGE
	adrp	x10, lCPI0_15@PAGE
	ldr	w13, [sp, #368]                 ; 4-byte Folded Reload
	ldr	w0, [sp, #364]                  ; 4-byte Folded Reload
	ldr	x2, [sp, #376]                  ; 8-byte Folded Reload
	cbz	w8, LBB0_2
; %bb.49:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v2, w8
Lloh2:
	adrp	x8, lCPI0_17@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_17@PAGEOFF]
Lloh4:
	adrp	x8, lCPI0_18@PAGE
Lloh5:
	ldr	q5, [x8, lCPI0_18@PAGEOFF]
	cmhi.4s	v8, v2, v5
	cmhi.4s	v31, v2, v4
	uzp1.8h	v4, v31, v8
	umaxv.8h	h2, v4
	fmov	w8, s2
	tbz	w8, #0, LBB0_2
; %bb.50:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x11, [sp, #336]                 ; 8-byte Folded Reload
	ldr	x8, [x11]
	ldr	x20, [x11, #16]
	ldr	x11, [x11, #48]
	str	x11, [sp, #312]                 ; 8-byte Folded Spill
Lloh6:
	adrp	x11, lCPI0_16@PAGE
Lloh7:
	ldr	q2, [x11, lCPI0_16@PAGEOFF]
	str	q4, [sp, #144]                  ; 16-byte Folded Spill
	and.16b	v2, v4, v2
	addv.8h	h16, v2
	ubfiz	w11, w2, #2, #27
	ldr	x12, [sp, #720]                 ; 8-byte Folded Reload
	orr	w11, w11, w12
	fmov	w12, s16
	and	w5, w12, #0xff
	dup.4s	v2, w11
	and.16b	v6, v31, v2
	and.16b	v5, v8, v2
	ushll2.2d	v2, v5, #0
	ushll2.2d	v4, v6, #0
	ushll.2d	v5, v5, #0
	ushll.2d	v7, v6, #0
	fmov	x11, d7
	mov	w12, #16388                     ; =0x4004
	umaddl	x11, w11, w12, x8
	b	LBB0_52
LBB0_51:                                ; %else959
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x12, x14, x9
	ldp	q18, q19, [x12]
	bif.16b	v17, v19, v8
	bif.16b	v6, v18, v31
	stp	q6, q17, [x12]
	add	x9, x9, #32
	cmp	x9, #4, lsl #12                 ; =16384
	b.eq	LBB0_68
LBB0_52:                                ; %direct.true.i199.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s16
	add	x12, x11, x9
	movi.2d	v6, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w13, #0, LBB0_60
; %bb.53:                               ; %else
                                        ;   in Loop: Header=BB0_52 Depth=2
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_61
LBB0_54:                                ; %else941
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w13, #2, LBB0_62
LBB0_55:                                ; %else944
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w13, #3, LBB0_63
LBB0_56:                                ; %else947
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w13, #4, LBB0_64
LBB0_57:                                ; %else950
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w13, #5, LBB0_65
LBB0_58:                                ; %else953
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w13, #6, LBB0_66
LBB0_59:                                ; %else956
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbz	w13, #7, LBB0_51
	b	LBB0_67
LBB0_60:                                ; %cond.load
                                        ;   in Loop: Header=BB0_52 Depth=2
	ldr	s6, [x12]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_54
LBB0_61:                                ; %cond.load940
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #4
	ld1.s	{ v6 }[1], [x15]
	tbz	w13, #2, LBB0_55
LBB0_62:                                ; %cond.load943
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #8
	ld1.s	{ v6 }[2], [x15]
	tbz	w13, #3, LBB0_56
LBB0_63:                                ; %cond.load946
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #12
	ld1.s	{ v6 }[3], [x15]
	tbz	w13, #4, LBB0_57
LBB0_64:                                ; %cond.load949
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #16
	ld1.s	{ v17 }[0], [x15]
	tbz	w13, #5, LBB0_58
LBB0_65:                                ; %cond.load952
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #20
	ld1.s	{ v17 }[1], [x15]
	tbz	w13, #6, LBB0_59
LBB0_66:                                ; %cond.load955
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x12, #24
	ld1.s	{ v17 }[2], [x15]
	tbz	w13, #7, LBB0_51
LBB0_67:                                ; %cond.load958
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x12, x12, #28
	ld1.s	{ v17 }[3], [x12]
	b	LBB0_51
LBB0_68:                                ; %direct.true57.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	xtn.4h	v6, v31
	uzp1.8b	v19, v6, v0
	sshll.2d	v6, v31, #0
Lloh8:
	adrp	x9, lCPI0_22@PAGE
Lloh9:
	ldr	q17, [x9, lCPI0_22@PAGEOFF]
	and.16b	v20, v6, v17
	movi.2d	v21, #0000000000000000
	mov.b	v21[0], v19[0]
Lloh10:
	adrp	x9, lCPI0_23@PAGE
Lloh11:
	ldr	d17, [x9, lCPI0_23@PAGEOFF]
	str	d17, [sp, #184]                 ; 8-byte Folded Spill
	and.8b	v17, v21, v17
	addv.8b	b17, v17
	fmov	w9, s17
	umaxv.8b	b17, v21
	fmov	w11, s17
	rbit	w12, w9
	clz	w12, w12
	tst	w11, #0x1
	csel	w4, w12, wzr, ne
	mov	w12, #4096                      ; =0x1000
	dup.2d	v18, x12
	str	q20, [sp, #96]                  ; 16-byte Folded Spill
	orr.16b	v22, v20, v18
	mov	w12, #4097                      ; =0x1001
	dup.2s	v17, w12
	xtn.2s	v7, v7
	str	q22, [sp, #192]                 ; 16-byte Folded Spill
	umlal.2d	v22, v7, v17
	movi.2d	v20, #0000000000000000
	mov.b	v20[0], v19[0]
	ushll.2d	v19, v20, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	str	q22, [sp, #272]                 ; 16-byte Folded Spill
	and.16b	v19, v19, v22
	movi.2d	v20, #0000000000000000
	str	q20, [sp, #1376]
	str	q20, [sp, #1360]
	str	q20, [sp, #1344]
	str	q19, [sp, #1328]
	and	x12, x4, #0x7
	add	x13, sp, #1328
	ldr	x12, [x13, x12, lsl #3]
	sub	x12, x12, x4
	add	x8, x8, x12, lsl #2
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w11, #0, LBB0_246
; %bb.69:                               ; %else963
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #1, LBB0_247
LBB0_70:                                ; %else966
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #2, LBB0_248
LBB0_71:                                ; %else969
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #3, LBB0_249
LBB0_72:                                ; %else972
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #4, LBB0_250
LBB0_73:                                ; %else975
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #5, LBB0_251
LBB0_74:                                ; %else978
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #6, LBB0_252
LBB0_75:                                ; %else981
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #7, LBB0_77
LBB0_76:                                ; %cond.load983
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x8, #28
	ld1.s	{ v27 }[3], [x8]
LBB0_77:                                ; %else984
                                        ;   in Loop: Header=BB0_3 Depth=1
	sshll.2d	v19, v8, #0
	sshll2.2d	v14, v31, #0
	sshll2.2d	v15, v8, #0
Lloh12:
	adrp	x8, lCPI0_19@PAGE
Lloh13:
	ldr	q20, [x8, lCPI0_19@PAGEOFF]
	and.16b	v29, v15, v20
Lloh14:
	adrp	x8, lCPI0_20@PAGE
Lloh15:
	ldr	q20, [x8, lCPI0_20@PAGEOFF]
	and.16b	v25, v14, v20
Lloh16:
	adrp	x8, lCPI0_21@PAGE
Lloh17:
	ldr	q20, [x8, lCPI0_21@PAGEOFF]
	and.16b	v30, v19, v20
	and.16b	v20, v19, v1
	str	q20, [sp, #656]                 ; 16-byte Folded Spill
	and.16b	v28, v6, v1
Lloh18:
	adrp	x8, lCPI0_3@PAGE
Lloh19:
	ldr	q20, [x8, lCPI0_3@PAGEOFF]
	and.16b	v22, v15, v20
	ldr	q20, [x16, lCPI0_1@PAGEOFF]
	and.16b	v23, v14, v20
Lloh20:
	adrp	x8, lCPI0_2@PAGE
Lloh21:
	ldr	q20, [x8, lCPI0_2@PAGEOFF]
	and.16b	v19, v19, v20
	and.16b	v24, v6, v3
	stp	q30, q25, [sp, #16]             ; 32-byte Folded Spill
	orr.16b	v20, v30, v18
	orr.16b	v25, v25, v18
	str	q29, [sp, #48]                  ; 16-byte Folded Spill
	orr.16b	v18, v29, v18
	umull.2d	v6, v7, v17
	str	q6, [sp, #208]                  ; 16-byte Folded Spill
	xtn.2s	v4, v4
	xtn.2s	v5, v5
	xtn.2s	v2, v2
	str	q18, [sp, #160]                 ; 16-byte Folded Spill
	mov.16b	v6, v18
	umlal.2d	v6, v2, v17
	stp	q25, q20, [sp, #112]            ; 32-byte Folded Spill
	mov.16b	v2, v25
	umlal.2d	v2, v4, v17
	stp	q2, q6, [sp, #240]              ; 32-byte Folded Spill
	mov.16b	v2, v20
	umlal.2d	v2, v5, v17
	str	q2, [sp, #224]                  ; 16-byte Folded Spill
	str	q24, [sp, #1264]
	str	q23, [sp, #1280]
	str	q19, [sp, #1296]
	str	q22, [sp, #1312]
	and	x8, x4, #0x7
	add	x11, sp, #1264
	ldr	x8, [x11, x8, lsl #3]
	orr	x8, x8, #0x4000
	sub	x8, x8, x4, lsl #2
	tst	w9, #0xff
	csel	x3, xzr, x8, eq
	add	x8, x14, x3
	ldp	q2, q4, [x8]
	zip2.8b	v5, v21, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	stp	q27, q26, [sp, #64]             ; 32-byte Folded Spill
	bit.16b	v4, v27, v5
	str	q21, [sp, #288]                 ; 16-byte Folded Spill
	zip1.8b	v5, v21, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bit.16b	v2, v26, v5
	stp	q2, q4, [x8]
	mov	w8, #32                         ; =0x20
	dup.2d	v2, x8
	orr.16b	v5, v19, v2
	orr.16b	v4, v23, v2
	stp	q4, q5, [sp, #544]              ; 32-byte Folded Spill
	orr.16b	v4, v24, v2
	orr.16b	v2, v22, v2
	stp	q2, q4, [sp, #512]              ; 32-byte Folded Spill
	mov	w8, #64                         ; =0x40
	dup.2d	v2, x8
	orr.16b	v5, v19, v2
	orr.16b	v4, v23, v2
	stp	q4, q5, [sp, #480]              ; 32-byte Folded Spill
	orr.16b	v4, v24, v2
	orr.16b	v2, v22, v2
	stp	q2, q4, [sp, #448]              ; 32-byte Folded Spill
	mov	w8, #96                         ; =0x60
	dup.2d	v2, x8
	stp	q19, q23, [sp, #688]            ; 32-byte Folded Spill
	orr.16b	v5, v19, v2
	orr.16b	v4, v23, v2
	stp	q4, q5, [sp, #416]              ; 32-byte Folded Spill
	orr.16b	v4, v24, v2
	str	q22, [sp, #720]                 ; 16-byte Folded Spill
	orr.16b	v2, v22, v2
	stp	q2, q4, [sp, #384]              ; 32-byte Folded Spill
	ldr	q2, [sp, #17936]
	ldr	q4, [sp, #17920]
	fmul.4s	v4, v4, v4
	fmul.4s	v2, v2, v2
	and.16b	v11, v8, v2
	and.16b	v12, v31, v4
	ldr	q2, [sp, #17888]
	fmul.4s	v2, v2, v2
	ldr	q4, [sp, #17904]
	fmul.4s	v4, v4, v4
	and.16b	v13, v8, v4
	and.16b	v18, v31, v2
	ldr	q2, [sp, #17856]
	fmul.4s	v2, v2, v2
	ldr	q4, [sp, #17872]
	fmul.4s	v4, v4, v4
	and.16b	v20, v8, v4
	and.16b	v22, v31, v2
	str	q24, [sp, #672]                 ; 16-byte Folded Spill
	fmov	x8, d24
	add	x8, x14, x8
	ldp	q2, q4, [x8]
	fmul.4s	v2, v2, v2
	fmul.4s	v4, v4, v4
	and.16b	v10, v8, v4
	and.16b	v9, v31, v2
	sshll.2d	v2, v8, #0
	dup.2d	v5, x27
	and.16b	v2, v2, v5
	sshll.2d	v4, v31, #0
	and.16b	v19, v4, v5
	and.16b	v4, v15, v5
	and.16b	v17, v14, v5
	stp	q15, q14, [sp, #592]            ; 32-byte Folded Spill
	and.16b	v5, v15, v1
	str	q5, [sp, #736]                  ; 16-byte Folded Spill
	and.16b	v29, v14, v1
	str	q29, [sp, #576]                 ; 16-byte Folded Spill
	str	q28, [sp, #624]                 ; 16-byte Folded Spill
	b	LBB0_79
LBB0_78:                                ; %else1180
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmul.4s	v5, v30, v30
	fmul.4s	v6, v7, v7
	fadd.4s	v26, v9, v6
	fadd.4s	v27, v10, v5
	fmul.4s	v5, v25, v25
	fmul.4s	v6, v24, v24
	fadd.4s	v6, v22, v6
	fadd.4s	v5, v20, v5
	fmul.4s	v7, v23, v23
	fmul.4s	v21, v21, v21
	fadd.4s	v21, v18, v21
	fadd.4s	v7, v13, v7
	sshll.2d	v23, v31, #0
	sshll.2d	v24, v8, #0
	fmul.4s	v25, v14, v14
	fmul.4s	v28, v28, v28
	fadd.4s	v28, v11, v28
	fadd.4s	v25, v12, v25
	dup.2d	v30, x27
	ldr	q14, [sp, #592]                 ; 16-byte Folded Reload
	and.16b	v14, v14, v30
	add.2d	v4, v4, v14
	ldr	q14, [sp, #608]                 ; 16-byte Folded Reload
	and.16b	v14, v14, v30
	add.2d	v17, v17, v14
	and.16b	v24, v24, v30
	add.2d	v2, v2, v24
	and.16b	v23, v23, v30
	add.2d	v19, v19, v23
	bit.16b	v10, v27, v8
	bit.16b	v9, v26, v31
	bit.16b	v20, v5, v8
	bit.16b	v22, v6, v31
	bit.16b	v13, v7, v8
	bit.16b	v18, v21, v31
	bit.16b	v12, v25, v31
	bit.16b	v11, v28, v8
	fmov	x8, d19
	cmp	x8, #512
	ldr	q28, [sp, #624]                 ; 16-byte Folded Reload
	b.ge	LBB0_143
LBB0_79:                                ; %direct.true57.i214.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w8, s16
	shl.2d	v14, v19, #5
	ldr	q5, [sp, #672]                  ; 16-byte Folded Reload
	orr.16b	v5, v14, v5
	add.2d	v5, v28, v5
	movi.2d	v7, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbnz	w8, #0, LBB0_114
; %bb.80:                               ; %else991
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_115
LBB0_81:                                ; %else997
                                        ;   in Loop: Header=BB0_79 Depth=2
	shl.2d	v15, v17, #5
	ldr	q5, [sp, #704]                  ; 16-byte Folded Reload
	orr.16b	v5, v15, v5
	add.2d	v5, v29, v5
	ldr	q27, [sp, #656]                 ; 16-byte Folded Reload
	tbnz	w8, #2, LBB0_116
LBB0_82:                                ; %else1003
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_117
LBB0_83:                                ; %else1009
                                        ;   in Loop: Header=BB0_79 Depth=2
	shl.2d	v5, v2, #5
	ldr	q6, [sp, #688]                  ; 16-byte Folded Reload
	orr.16b	v6, v5, v6
	add.2d	v6, v27, v6
	tbnz	w8, #4, LBB0_118
LBB0_84:                                ; %else1015
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_119
LBB0_85:                                ; %else1021
                                        ;   in Loop: Header=BB0_79 Depth=2
	shl.2d	v6, v4, #5
	ldp	q21, q23, [sp, #720]            ; 32-byte Folded Reload
	orr.16b	v21, v6, v21
	add.2d	v21, v23, v21
	tbnz	w8, #6, LBB0_120
LBB0_86:                                ; %else1027
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbz	w8, #7, LBB0_88
LBB0_87:                                ; %cond.load1029
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v21[1]
	ld1.s	{ v30 }[3], [x8]
LBB0_88:                                ; %else1033
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	w8, s16
	ldr	q21, [sp, #528]                 ; 16-byte Folded Reload
	add.2d	v21, v21, v14
	add.2d	v21, v28, v21
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbnz	w8, #0, LBB0_121
; %bb.89:                               ; %else1040
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_122
LBB0_90:                                ; %else1046
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q21, [sp, #544]                 ; 16-byte Folded Reload
	add.2d	v21, v21, v15
	add.2d	v21, v29, v21
	tbnz	w8, #2, LBB0_123
LBB0_91:                                ; %else1052
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_124
LBB0_92:                                ; %else1058
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q21, [sp, #560]                 ; 16-byte Folded Reload
	add.2d	v21, v21, v5
	add.2d	v21, v27, v21
	tbnz	w8, #4, LBB0_125
LBB0_93:                                ; %else1064
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_126
LBB0_94:                                ; %else1070
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q21, [sp, #512]                 ; 16-byte Folded Reload
	add.2d	v21, v21, v6
	ldr	q23, [sp, #736]                 ; 16-byte Folded Reload
	add.2d	v21, v23, v21
	tbnz	w8, #6, LBB0_127
LBB0_95:                                ; %else1076
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbz	w8, #7, LBB0_97
LBB0_96:                                ; %cond.load1078
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v21[1]
	ld1.s	{ v25 }[3], [x8]
LBB0_97:                                ; %else1082
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	w8, s16
	ldr	q21, [sp, #464]                 ; 16-byte Folded Reload
	add.2d	v21, v21, v14
	add.2d	v26, v28, v21
	movi.2d	v21, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w8, #0, LBB0_128
; %bb.98:                               ; %else1089
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_129
LBB0_99:                                ; %else1095
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q26, [sp, #480]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v15
	add.2d	v26, v29, v26
	tbnz	w8, #2, LBB0_130
LBB0_100:                               ; %else1101
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_131
LBB0_101:                               ; %else1107
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q26, [sp, #496]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v5
	add.2d	v26, v27, v26
	tbnz	w8, #4, LBB0_132
LBB0_102:                               ; %else1113
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_133
LBB0_103:                               ; %else1119
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q26, [sp, #448]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v6
	ldr	q29, [sp, #736]                 ; 16-byte Folded Reload
	add.2d	v26, v29, v26
	tbnz	w8, #6, LBB0_134
LBB0_104:                               ; %else1125
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q29, [sp, #576]                 ; 16-byte Folded Reload
	tbz	w8, #7, LBB0_106
LBB0_105:                               ; %cond.load1127
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v26[1]
	ld1.s	{ v23 }[3], [x8]
LBB0_106:                               ; %else1131
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	w8, s16
	ldr	q26, [sp, #400]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v14
	add.2d	v26, v28, v26
	movi.2d	v14, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w8, #0, LBB0_135
; %bb.107:                              ; %else1138
                                        ;   in Loop: Header=BB0_79 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_136
LBB0_108:                               ; %else1144
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q26, [sp, #416]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v15
	add.2d	v26, v29, v26
	tbnz	w8, #2, LBB0_137
LBB0_109:                               ; %else1150
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #3, LBB0_138
LBB0_110:                               ; %else1156
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q26, [sp, #432]                 ; 16-byte Folded Reload
	add.2d	v5, v26, v5
	add.2d	v5, v27, v5
	tbnz	w8, #4, LBB0_139
LBB0_111:                               ; %else1162
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbnz	w8, #5, LBB0_140
LBB0_112:                               ; %else1168
                                        ;   in Loop: Header=BB0_79 Depth=2
	ldr	q5, [sp, #384]                  ; 16-byte Folded Reload
	add.2d	v5, v5, v6
	ldr	q6, [sp, #736]                  ; 16-byte Folded Reload
	add.2d	v5, v6, v5
	tbnz	w8, #6, LBB0_141
LBB0_113:                               ; %else1174
                                        ;   in Loop: Header=BB0_79 Depth=2
	tbz	w8, #7, LBB0_78
	b	LBB0_142
LBB0_114:                               ; %cond.load987
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d5
	ldr	s7, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_81
LBB0_115:                               ; %cond.load993
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v7 }[1], [x9]
	shl.2d	v15, v17, #5
	ldr	q5, [sp, #704]                  ; 16-byte Folded Reload
	orr.16b	v5, v15, v5
	add.2d	v5, v29, v5
	ldr	q27, [sp, #656]                 ; 16-byte Folded Reload
	tbz	w8, #2, LBB0_82
LBB0_116:                               ; %cond.load999
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d5
	ld1.s	{ v7 }[2], [x9]
	tbz	w8, #3, LBB0_83
LBB0_117:                               ; %cond.load1005
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v7 }[3], [x9]
	shl.2d	v5, v2, #5
	ldr	q6, [sp, #688]                  ; 16-byte Folded Reload
	orr.16b	v6, v5, v6
	add.2d	v6, v27, v6
	tbz	w8, #4, LBB0_84
LBB0_118:                               ; %cond.load1011
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d6
	ld1.s	{ v30 }[0], [x9]
	tbz	w8, #5, LBB0_85
LBB0_119:                               ; %cond.load1017
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v30 }[1], [x9]
	shl.2d	v6, v4, #5
	ldp	q21, q23, [sp, #720]            ; 32-byte Folded Reload
	orr.16b	v21, v6, v21
	add.2d	v21, v23, v21
	tbz	w8, #6, LBB0_86
LBB0_120:                               ; %cond.load1023
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d21
	ld1.s	{ v30 }[2], [x9]
	tbnz	w8, #7, LBB0_87
	b	LBB0_88
LBB0_121:                               ; %cond.load1036
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d21
	ldr	s24, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_90
LBB0_122:                               ; %cond.load1042
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v21[1]
	ld1.s	{ v24 }[1], [x9]
	ldr	q21, [sp, #544]                 ; 16-byte Folded Reload
	add.2d	v21, v21, v15
	add.2d	v21, v29, v21
	tbz	w8, #2, LBB0_91
LBB0_123:                               ; %cond.load1048
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d21
	ld1.s	{ v24 }[2], [x9]
	tbz	w8, #3, LBB0_92
LBB0_124:                               ; %cond.load1054
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v21[1]
	ld1.s	{ v24 }[3], [x9]
	ldr	q21, [sp, #560]                 ; 16-byte Folded Reload
	add.2d	v21, v21, v5
	add.2d	v21, v27, v21
	tbz	w8, #4, LBB0_93
LBB0_125:                               ; %cond.load1060
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d21
	ld1.s	{ v25 }[0], [x9]
	tbz	w8, #5, LBB0_94
LBB0_126:                               ; %cond.load1066
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v21[1]
	ld1.s	{ v25 }[1], [x9]
	ldr	q21, [sp, #512]                 ; 16-byte Folded Reload
	add.2d	v21, v21, v6
	ldr	q23, [sp, #736]                 ; 16-byte Folded Reload
	add.2d	v21, v23, v21
	tbz	w8, #6, LBB0_95
LBB0_127:                               ; %cond.load1072
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d21
	ld1.s	{ v25 }[2], [x9]
	tbnz	w8, #7, LBB0_96
	b	LBB0_97
LBB0_128:                               ; %cond.load1085
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d26
	ldr	s21, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_99
LBB0_129:                               ; %cond.load1091
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v26[1]
	ld1.s	{ v21 }[1], [x9]
	ldr	q26, [sp, #480]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v15
	add.2d	v26, v29, v26
	tbz	w8, #2, LBB0_100
LBB0_130:                               ; %cond.load1097
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d26
	ld1.s	{ v21 }[2], [x9]
	tbz	w8, #3, LBB0_101
LBB0_131:                               ; %cond.load1103
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v26[1]
	ld1.s	{ v21 }[3], [x9]
	ldr	q26, [sp, #496]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v5
	add.2d	v26, v27, v26
	tbz	w8, #4, LBB0_102
LBB0_132:                               ; %cond.load1109
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d26
	ld1.s	{ v23 }[0], [x9]
	tbz	w8, #5, LBB0_103
LBB0_133:                               ; %cond.load1115
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v26[1]
	ld1.s	{ v23 }[1], [x9]
	ldr	q26, [sp, #448]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v6
	ldr	q29, [sp, #736]                 ; 16-byte Folded Reload
	add.2d	v26, v29, v26
	tbz	w8, #6, LBB0_104
LBB0_134:                               ; %cond.load1121
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d26
	ld1.s	{ v23 }[2], [x9]
	ldr	q29, [sp, #576]                 ; 16-byte Folded Reload
	tbnz	w8, #7, LBB0_105
	b	LBB0_106
LBB0_135:                               ; %cond.load1134
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d26
	ldr	s14, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_108
LBB0_136:                               ; %cond.load1140
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v26[1]
	ld1.s	{ v14 }[1], [x9]
	ldr	q26, [sp, #416]                 ; 16-byte Folded Reload
	add.2d	v26, v26, v15
	add.2d	v26, v29, v26
	tbz	w8, #2, LBB0_109
LBB0_137:                               ; %cond.load1146
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d26
	ld1.s	{ v14 }[2], [x9]
	tbz	w8, #3, LBB0_110
LBB0_138:                               ; %cond.load1152
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v26[1]
	ld1.s	{ v14 }[3], [x9]
	ldr	q26, [sp, #432]                 ; 16-byte Folded Reload
	add.2d	v5, v26, v5
	add.2d	v5, v27, v5
	tbz	w8, #4, LBB0_111
LBB0_139:                               ; %cond.load1158
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d5
	ld1.s	{ v28 }[0], [x9]
	tbz	w8, #5, LBB0_112
LBB0_140:                               ; %cond.load1164
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v28 }[1], [x9]
	ldr	q5, [sp, #384]                  ; 16-byte Folded Reload
	add.2d	v5, v5, v6
	ldr	q6, [sp, #736]                  ; 16-byte Folded Reload
	add.2d	v5, v6, v5
	tbz	w8, #6, LBB0_113
LBB0_141:                               ; %cond.load1170
                                        ;   in Loop: Header=BB0_79 Depth=2
	fmov	x9, d5
	ld1.s	{ v28 }[2], [x9]
	tbz	w8, #7, LBB0_78
LBB0_142:                               ; %cond.load1176
                                        ;   in Loop: Header=BB0_79 Depth=2
	mov.d	x8, v5[1]
	ld1.s	{ v28 }[3], [x8]
	b	LBB0_78
LBB0_143:                               ; %direct.false58.i215.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldp	q4, q2, [sp, #592]              ; 32-byte Folded Reload
	and.16b	v14, v4, v0
	and.16b	v15, v2, v0
	sshll.2d	v2, v8, #0
	and.16b	v6, v2, v0
	sshll.2d	v2, v31, #0
	and.16b	v7, v2, v0
	dup.2d	v2, x28
	ushll2.2d	v4, v8, #0
	and.16b	v5, v4, v2
	ushll2.2d	v4, v31, #0
	and.16b	v30, v4, v2
	ushll.2d	v4, v8, #0
	and.16b	v8, v4, v2
	ushll.2d	v4, v31, #0
	and.16b	v31, v4, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v19, #0000000000000000
	b	LBB0_145
LBB0_144:                               ; %else1238
                                        ;   in Loop: Header=BB0_145 Depth=2
	add.2d	v4, v4, v30
	add.2d	v17, v17, v8
	add.2d	v19, v19, v5
	add.2d	v2, v2, v31
	fmov	x8, d2
	cmp	x8, #512
	b.ge	LBB0_177
LBB0_145:                               ; %direct.true85.i216.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s16
	add	x8, x20, x8, lsl #5
	movi.2d	v23, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w9, #0, LBB0_161
; %bb.146:                              ; %else1184
                                        ;   in Loop: Header=BB0_145 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_162
LBB0_147:                               ; %else1187
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #2, LBB0_163
LBB0_148:                               ; %else1190
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #3, LBB0_164
LBB0_149:                               ; %else1193
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #4, LBB0_165
LBB0_150:                               ; %else1196
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #5, LBB0_166
LBB0_151:                               ; %else1199
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #6, LBB0_167
LBB0_152:                               ; %else1202
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w9, #7, LBB0_168
LBB0_153:                               ; %else1205
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	w8, s16
	shl.2d	v24, v2, #5
	ldr	q25, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v24, v24, v25
	add.2d	v24, v7, v24
	tbnz	w8, #0, LBB0_169
LBB0_154:                               ; %else1210
                                        ;   in Loop: Header=BB0_145 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_170
LBB0_155:                               ; %else1214
                                        ;   in Loop: Header=BB0_145 Depth=2
	shl.2d	v24, v4, #5
	ldr	q25, [sp, #704]                 ; 16-byte Folded Reload
	orr.16b	v24, v24, v25
	add.2d	v24, v15, v24
	tbnz	w8, #2, LBB0_171
LBB0_156:                               ; %else1218
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w8, #3, LBB0_172
LBB0_157:                               ; %else1222
                                        ;   in Loop: Header=BB0_145 Depth=2
	shl.2d	v23, v17, #5
	ldr	q24, [sp, #688]                 ; 16-byte Folded Reload
	orr.16b	v23, v23, v24
	add.2d	v23, v6, v23
	tbnz	w8, #4, LBB0_173
LBB0_158:                               ; %else1226
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbnz	w8, #5, LBB0_174
LBB0_159:                               ; %else1230
                                        ;   in Loop: Header=BB0_145 Depth=2
	shl.2d	v23, v19, #5
	ldr	q24, [sp, #720]                 ; 16-byte Folded Reload
	orr.16b	v23, v23, v24
	add.2d	v23, v14, v23
	tbnz	w8, #6, LBB0_175
LBB0_160:                               ; %else1234
                                        ;   in Loop: Header=BB0_145 Depth=2
	tbz	w8, #7, LBB0_144
	b	LBB0_176
LBB0_161:                               ; %cond.load1183
                                        ;   in Loop: Header=BB0_145 Depth=2
	ldr	s23, [x8]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_147
LBB0_162:                               ; %cond.load1186
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #4
	ld1.s	{ v23 }[1], [x11]
	tbz	w9, #2, LBB0_148
LBB0_163:                               ; %cond.load1189
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #8
	ld1.s	{ v23 }[2], [x11]
	tbz	w9, #3, LBB0_149
LBB0_164:                               ; %cond.load1192
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #12
	ld1.s	{ v23 }[3], [x11]
	tbz	w9, #4, LBB0_150
LBB0_165:                               ; %cond.load1195
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #16
	ld1.s	{ v21 }[0], [x11]
	tbz	w9, #5, LBB0_151
LBB0_166:                               ; %cond.load1198
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #20
	ld1.s	{ v21 }[1], [x11]
	tbz	w9, #6, LBB0_152
LBB0_167:                               ; %cond.load1201
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x11, x8, #24
	ld1.s	{ v21 }[2], [x11]
	tbz	w9, #7, LBB0_153
LBB0_168:                               ; %cond.load1204
                                        ;   in Loop: Header=BB0_145 Depth=2
	add	x8, x8, #28
	ld1.s	{ v21 }[3], [x8]
	fmov	w8, s16
	shl.2d	v24, v2, #5
	ldr	q25, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v24, v24, v25
	add.2d	v24, v7, v24
	tbz	w8, #0, LBB0_154
LBB0_169:                               ; %cond.store
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x9, d24
	str	s23, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_155
LBB0_170:                               ; %cond.store1211
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x9, v24[1]
	st1.s	{ v23 }[1], [x9]
	shl.2d	v24, v4, #5
	ldr	q25, [sp, #704]                 ; 16-byte Folded Reload
	orr.16b	v24, v24, v25
	add.2d	v24, v15, v24
	tbz	w8, #2, LBB0_156
LBB0_171:                               ; %cond.store1215
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x9, d24
	st1.s	{ v23 }[2], [x9]
	tbz	w8, #3, LBB0_157
LBB0_172:                               ; %cond.store1219
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x9, v24[1]
	st1.s	{ v23 }[3], [x9]
	shl.2d	v23, v17, #5
	ldr	q24, [sp, #688]                 ; 16-byte Folded Reload
	orr.16b	v23, v23, v24
	add.2d	v23, v6, v23
	tbz	w8, #4, LBB0_158
LBB0_173:                               ; %cond.store1223
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x9, d23
	str	s21, [x9]
	tbz	w8, #5, LBB0_159
LBB0_174:                               ; %cond.store1227
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x9, v23[1]
	st1.s	{ v21 }[1], [x9]
	shl.2d	v23, v19, #5
	ldr	q24, [sp, #720]                 ; 16-byte Folded Reload
	orr.16b	v23, v23, v24
	add.2d	v23, v14, v23
	tbz	w8, #6, LBB0_160
LBB0_175:                               ; %cond.store1231
                                        ;   in Loop: Header=BB0_145 Depth=2
	fmov	x9, d23
	st1.s	{ v21 }[2], [x9]
	tbz	w8, #7, LBB0_144
LBB0_176:                               ; %cond.store1235
                                        ;   in Loop: Header=BB0_145 Depth=2
	mov.d	x8, v23[1]
	st1.s	{ v21 }[3], [x8]
	b	LBB0_144
LBB0_177:                               ; %direct.false86.i218.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q2, [sp, #144]                  ; 16-byte Folded Reload
	xtn.8b	v2, v2
	ldp	q17, q4, [sp, #64]              ; 32-byte Folded Reload
	fmul.4s	v4, v4, v4
	fmul.4s	v17, v17, v17
	fadd.4s	v17, v17, v10
	fadd.4s	v4, v4, v9
	ldr	q9, [sp, #288]                  ; 16-byte Folded Reload
	zip1.8b	v19, v9, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	and.16b	v4, v19, v4
	zip2.8b	v19, v9, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	and.16b	v17, v19, v17
	zip2.8b	v19, v2, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	movi.2d	v21, #0000000000000000
	mov.b	v21[2], v2[1]
	mov.b	v21[4], v2[2]
	mov.b	v21[6], v2[3]
	bit.16b	v17, v27, v19
	ushll.4s	v19, v21, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	bit.16b	v4, v26, v19
	fadd.4s	v4, v22, v4
	fadd.4s	v17, v20, v17
	fadd.4s	v19, v13, v17
	fadd.4s	v4, v18, v4
	fadd.4s	v17, v12, v4
	fadd.4s	v18, v11, v19
	ldr	q4, [sp, #96]                   ; 16-byte Folded Reload
	ldp	q20, q19, [sp, #32]             ; 32-byte Folded Reload
	uzp1.4s	v4, v4, v20
	ldr	q20, [sp, #16]                  ; 16-byte Folded Reload
	uzp1.4s	v19, v20, v19
	movi.4s	v21, #1
	eor.16b	v20, v4, v21
	mov.s	w9, v20[1]
	mov.s	w13, v20[2]
	eor.16b	v23, v19, v21
	mov.s	w15, v20[3]
	fmov	w8, s20
	add	x11, sp, #824
	bfxil	x11, x8, #0, #3
	str	d2, [sp, #824]
	ldrb	w12, [x11]
	and	x11, x8, #0x7
	umov.b	w8, v2[0]
	str	q18, [sp, #1104]
	str	q17, [sp, #1088]
	add	x16, sp, #1088
	ldr	s20, [x16, x11, lsl #2]
	ands	w11, w8, #0x1
	tst	w11, w12
	movi	d11, #0000000000000000
	fcsel	s20, s20, s11, ne
	add	x12, sp, #824
	bfxil	x12, x9, #0, #3
	ldrb	w12, [x12]
	and	x16, x9, #0x7
	umov.b	w9, v2[1]
	str	q18, [sp, #1072]
	str	q17, [sp, #1056]
	add	x17, sp, #1056
	ldr	s21, [x17, x16, lsl #2]
	ands	w16, w9, #0x1
	tst	w16, w12
	fcsel	s21, s21, s11, ne
	add	x12, sp, #824
	bfxil	x12, x13, #0, #3
	ldrb	w16, [x12]
	umov.b	w12, v2[2]
	and	x13, x13, #0x7
	str	q18, [sp, #1040]
	str	q17, [sp, #1024]
	add	x17, sp, #1024
	ldr	s22, [x17, x13, lsl #2]
	ands	w13, w12, #0x1
	tst	w13, w16
	fcsel	s22, s22, s11, ne
	add	x13, sp, #824
	bfxil	x13, x15, #0, #3
	ldrb	w16, [x13]
	and	x15, x15, #0x7
	umov.b	w13, v2[3]
	stp	q17, q18, [sp, #992]
	add	x17, sp, #992
	ldr	s24, [x17, x15, lsl #2]
	ands	w15, w13, #0x1
	tst	w15, w16
	mov.s	w15, v23[1]
	mov.s	w16, v23[2]
	fcsel	s24, s24, s11, ne
	mov.s	w1, v23[3]
	fmov	w0, s23
	and	x2, x0, #0x7
	add	x21, sp, #824
	bfxil	x21, x0, #0, #3
	ldrb	w21, [x21]
	umov.b	w0, v2[4]
	and	w21, w0, w21
	str	q18, [sp, #1232]
	str	q17, [sp, #1216]
	add	x17, sp, #1216
	ldr	s23, [x17, x2, lsl #2]
	tst	w21, #0x1
	fcsel	s23, s23, s11, ne
	add	x2, sp, #824
	bfxil	x2, x15, #0, #3
	ldrb	w2, [x2]
	and	x15, x15, #0x7
	umov.b	w21, v2[5]
	str	q18, [sp, #1200]
	str	q17, [sp, #1184]
	add	x17, sp, #1184
	ldr	s25, [x17, x15, lsl #2]
	ands	w15, w21, #0x1
	tst	w15, w2
	fcsel	s25, s25, s11, ne
	add	x15, sp, #824
	bfxil	x15, x16, #0, #3
	ldrb	w15, [x15]
	and	x16, x16, #0x7
	umov.b	w30, v2[6]
	str	q18, [sp, #1168]
	str	q17, [sp, #1152]
	add	x17, sp, #1152
	ldr	s26, [x17, x16, lsl #2]
	ands	w16, w30, #0x1
	tst	w16, w15
	fcsel	s26, s26, s11, ne
	add	x15, sp, #824
	bfxil	x15, x1, #0, #3
	ldrb	w15, [x15]
	umov.b	w2, v2[7]
	and	x16, x1, #0x7
	str	q18, [sp, #1136]
	str	q17, [sp, #1120]
	add	x17, sp, #1120
	ldr	s2, [x17, x16, lsl #2]
	ands	w16, w2, #0x1
	tst	w16, w15
	fcsel	s2, s2, s11, ne
	mov.s	v23[1], v25[0]
	mov.s	v23[2], v26[0]
	mov.s	v23[3], v2[0]
	mov.s	v20[1], v21[0]
	mov.s	v20[2], v22[0]
	mov.s	v20[3], v24[0]
	fadd.4s	v2, v17, v20
	fadd.4s	v17, v18, v23
	movi.4s	v20, #2
	eor.16b	v18, v19, v20
	eor.16b	v4, v4, v20
	fmov	w15, s4
	add	x16, sp, #824
	bfxil	x16, x15, #0, #3
	ldrb	w16, [x16]
	and	x15, x15, #0x7
	stp	q2, q17, [sp, #960]
	add	x17, sp, #960
	ldr	s4, [x17, x15, lsl #2]
	tst	w11, w16
	fcsel	s4, s4, s11, ne
	fmov	w15, s18
	and	x16, x15, #0x7
	add	x1, sp, #824
	bfxil	x1, x15, #0, #3
	ldrb	w15, [x1]
	and	w15, w0, w15
	stp	q2, q17, [sp, #928]
	add	x17, sp, #928
	ldr	s18, [x17, x16, lsl #2]
	tst	w15, #0x1
	fcsel	s18, s18, s11, ne
	fadd.4s	v17, v17, v18
	tst	w11, w0
	fcsel	s17, s17, s11, ne
	ands	w8, w8, #0x1
	fadd.4s	v2, v2, v4
	fadd	s2, s2, s17
	fcsel	s4, s2, s11, ne
	tst	w9, #0x1
	fcsel	s17, s4, s11, ne
	tst	w12, #0x1
	fcsel	s18, s4, s11, ne
	tst	w13, #0x1
	fcsel	s19, s4, s11, ne
	tst	w8, w0
	fcsel	s20, s2, s11, ne
	tst	w21, #0x1
	fcsel	s21, s4, s11, ne
	tst	w30, #0x1
	fcsel	s22, s4, s11, ne
	tst	w2, #0x1
	shl.8b	v2, v9, #7
	cmlt.8b	v2, v2, #0
	ldr	d23, [sp, #184]                 ; 8-byte Folded Reload
	and.8b	v2, v2, v23
	addv.8b	b2, v2
	fmov	w8, s2
	fcsel	s23, s4, s11, ne
	mov.s	v4[1], v17[0]
	mov.s	v4[2], v18[0]
	mov.s	v4[3], v19[0]
	mov.s	v20[1], v21[0]
	mov.s	v20[2], v22[0]
	mov.s	v20[3], v23[0]
	rbit	w9, w5
	clz	w9, w9
	stp	q4, q20, [sp, #896]
	and	x9, x9, #0x7
	add	x11, sp, #896
	ldr	s4, [x11, x9, lsl #2]
	mov	b17, v9[0]
	mov.b	v17[4], v9[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	mov	b18, v9[2]
	mov.b	v18[4], v9[3]
	ldr	q19, [sp, #192]                 ; 16-byte Folded Reload
	and.16b	v17, v17, v19
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	ldp	q19, q20, [sp, #112]            ; 32-byte Folded Reload
	and.16b	v18, v18, v19
	mov	b19, v9[4]
	mov.b	v19[4], v9[5]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	and.16b	v19, v19, v20
	mov	b20, v9[6]
	mov.b	v20[4], v9[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	ldr	q21, [sp, #160]                 ; 16-byte Folded Reload
	and.16b	v20, v20, v21
	stp	q19, q20, [sp, #864]
	stp	q17, q18, [sp, #832]
	and	x9, x4, #0x7
	add	x11, sp, #832
	ldr	x9, [x11, x9, lsl #3]
	mov	x30, x4
	sub	x9, x9, x4
	add	x9, x20, x9, lsl #2
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbz	w8, #0, LBB0_179
; %bb.178:                              ; %cond.load1240
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	s17, [x9]
LBB0_179:                               ; %else1241
                                        ;   in Loop: Header=BB0_3 Depth=1
	adrp	x1, lCPI0_2@PAGE
	adrp	x4, lCPI0_4@PAGE
	adrp	x17, lCPI0_3@PAGE
	adrp	x5, lCPI0_5@PAGE
	adrp	x6, lCPI0_6@PAGE
	adrp	x7, lCPI0_7@PAGE
	adrp	x19, lCPI0_8@PAGE
	adrp	x20, lCPI0_9@PAGE
	ldr	x2, [sp, #312]                  ; 8-byte Folded Reload
	ldr	q26, [sp, #656]                 ; 16-byte Folded Reload
	tbnz	w8, #1, LBB0_253
; %bb.180:                              ; %else1244
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	w15, [sp, #372]                 ; 4-byte Folded Reload
	adrp	x16, lCPI0_1@PAGE
	ldr	w13, [sp, #368]                 ; 4-byte Folded Reload
	ldr	w0, [sp, #364]                  ; 4-byte Folded Reload
	tbnz	w8, #2, LBB0_254
LBB0_181:                               ; %else1247
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #3, LBB0_255
LBB0_182:                               ; %else1250
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #4, LBB0_256
LBB0_183:                               ; %else1253
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #5, LBB0_257
LBB0_184:                               ; %else1256
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #6, LBB0_258
LBB0_185:                               ; %else1259
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #7, LBB0_187
LBB0_186:                               ; %cond.load1261
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #28
	ld1.s	{ v18 }[3], [x8]
LBB0_187:                               ; %else1262
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	fadd	s4, s4, s11
	mov	w8, #2048                       ; =0x800
	movk	w8, #17792, lsl #16
	fmov	s19, w8
	fdiv	s4, s4, s19
	add	x8, sp, #1408
	add	x8, x8, x3
	ldp	q19, q20, [x8]
	zip2.8b	v21, v9, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	bif.16b	v18, v20, v21
	zip1.8b	v20, v9, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmlt.4s	v20, v20, #0
	bif.16b	v17, v19, v20
	stp	q17, q18, [x8]
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s17, w8
	fadd	s4, s4, s17
	fsqrt	s4, s4
	dup.4s	v4, v4[0]
	ldr	q17, [sp, #208]                 ; 16-byte Folded Reload
	fmov	x8, d17
	add	x8, x2, x8, lsl #2
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	b	LBB0_189
LBB0_188:                               ; %else1378
                                        ;   in Loop: Header=BB0_189 Depth=2
	add.2d	v18, v18, v30
	add.2d	v19, v19, v8
	add.2d	v20, v20, v5
	add.2d	v17, v17, v31
	fmov	x9, d17
	cmp	x9, #512
	b.ge	LBB0_237
LBB0_189:                               ; %direct.true109.i225.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s16
	shl.2d	v21, v17, #5
	ldr	q22, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v23, v21, v22
	add.2d	v24, v28, v23
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbnz	w11, #0, LBB0_213
; %bb.190:                              ; %else1269
                                        ;   in Loop: Header=BB0_189 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_214
LBB0_191:                               ; %else1275
                                        ;   in Loop: Header=BB0_189 Depth=2
	shl.2d	v24, v18, #5
	ldr	q25, [sp, #704]                 ; 16-byte Folded Reload
	orr.16b	v24, v24, v25
	add.2d	v25, v29, v24
	tbnz	w11, #2, LBB0_215
LBB0_192:                               ; %else1281
                                        ;   in Loop: Header=BB0_189 Depth=2
	tbnz	w11, #3, LBB0_216
LBB0_193:                               ; %else1287
                                        ;   in Loop: Header=BB0_189 Depth=2
	shl.2d	v25, v19, #5
	ldr	q27, [sp, #688]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v27
	add.2d	v26, v26, v25
	tbnz	w11, #4, LBB0_217
LBB0_194:                               ; %else1293
                                        ;   in Loop: Header=BB0_189 Depth=2
	tbnz	w11, #5, LBB0_218
LBB0_195:                               ; %else1299
                                        ;   in Loop: Header=BB0_189 Depth=2
	shl.2d	v26, v20, #5
	ldp	q28, q27, [sp, #720]            ; 32-byte Folded Reload
	orr.16b	v26, v26, v28
	add.2d	v27, v27, v26
	tbnz	w11, #6, LBB0_219
LBB0_196:                               ; %else1305
                                        ;   in Loop: Header=BB0_189 Depth=2
	tbnz	w11, #7, LBB0_220
LBB0_197:                               ; %else1311
                                        ;   in Loop: Header=BB0_189 Depth=2
	fmov	w11, s16
	add.2d	v28, v7, v23
	movi.2d	v27, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w11, #0, LBB0_221
LBB0_198:                               ; %else1318
                                        ;   in Loop: Header=BB0_189 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_222
LBB0_199:                               ; %else1324
                                        ;   in Loop: Header=BB0_189 Depth=2
	ldr	q28, [sp, #624]                 ; 16-byte Folded Reload
	add.2d	v24, v15, v24
	tbnz	w11, #2, LBB0_223
LBB0_200:                               ; %else1330
                                        ;   in Loop: Header=BB0_189 Depth=2
	tbnz	w11, #3, LBB0_224
LBB0_201:                               ; %else1336
                                        ;   in Loop: Header=BB0_189 Depth=2
	add.2d	v24, v6, v25
	tbnz	w11, #4, LBB0_225
LBB0_202:                               ; %else1342
                                        ;   in Loop: Header=BB0_189 Depth=2
	tbnz	w11, #5, LBB0_226
LBB0_203:                               ; %else1348
                                        ;   in Loop: Header=BB0_189 Depth=2
	add.2d	v24, v14, v26
	tbnz	w11, #6, LBB0_227
LBB0_204:                               ; %else1354
                                        ;   in Loop: Header=BB0_189 Depth=2
	tbnz	w11, #7, LBB0_228
LBB0_205:                               ; %else1360
                                        ;   in Loop: Header=BB0_189 Depth=2
	fdiv.4s	v21, v21, v4
	fmov	w11, s16
	fmul.4s	v21, v21, v27
	add	x9, x8, x9, lsl #5
	tbnz	w11, #0, LBB0_229
LBB0_206:                               ; %else1364
                                        ;   in Loop: Header=BB0_189 Depth=2
	and	w11, w11, #0xff
	ldr	q26, [sp, #656]                 ; 16-byte Folded Reload
	tbnz	w11, #1, LBB0_230
LBB0_207:                               ; %else1366
                                        ;   in Loop: Header=BB0_189 Depth=2
	tbnz	w11, #2, LBB0_231
LBB0_208:                               ; %else1368
                                        ;   in Loop: Header=BB0_189 Depth=2
	tbnz	w11, #3, LBB0_232
LBB0_209:                               ; %else1370
                                        ;   in Loop: Header=BB0_189 Depth=2
	fdiv.4s	v21, v22, v4
	fmul.4s	v21, v21, v23
	tbnz	w11, #4, LBB0_233
LBB0_210:                               ; %else1372
                                        ;   in Loop: Header=BB0_189 Depth=2
	tbnz	w11, #5, LBB0_234
LBB0_211:                               ; %else1374
                                        ;   in Loop: Header=BB0_189 Depth=2
	tbnz	w11, #6, LBB0_235
LBB0_212:                               ; %else1376
                                        ;   in Loop: Header=BB0_189 Depth=2
	tbz	w11, #7, LBB0_188
	b	LBB0_236
LBB0_213:                               ; %cond.load1265
                                        ;   in Loop: Header=BB0_189 Depth=2
	fmov	x12, d24
	ldr	s21, [x12]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_191
LBB0_214:                               ; %cond.load1271
                                        ;   in Loop: Header=BB0_189 Depth=2
	mov.d	x12, v24[1]
	ld1.s	{ v21 }[1], [x12]
	shl.2d	v24, v18, #5
	ldr	q25, [sp, #704]                 ; 16-byte Folded Reload
	orr.16b	v24, v24, v25
	add.2d	v25, v29, v24
	tbz	w11, #2, LBB0_192
LBB0_215:                               ; %cond.load1277
                                        ;   in Loop: Header=BB0_189 Depth=2
	fmov	x12, d25
	ld1.s	{ v21 }[2], [x12]
	tbz	w11, #3, LBB0_193
LBB0_216:                               ; %cond.load1283
                                        ;   in Loop: Header=BB0_189 Depth=2
	mov.d	x12, v25[1]
	ld1.s	{ v21 }[3], [x12]
	shl.2d	v25, v19, #5
	ldr	q27, [sp, #688]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v27
	add.2d	v26, v26, v25
	tbz	w11, #4, LBB0_194
LBB0_217:                               ; %cond.load1289
                                        ;   in Loop: Header=BB0_189 Depth=2
	fmov	x12, d26
	ld1.s	{ v22 }[0], [x12]
	tbz	w11, #5, LBB0_195
LBB0_218:                               ; %cond.load1295
                                        ;   in Loop: Header=BB0_189 Depth=2
	mov.d	x12, v26[1]
	ld1.s	{ v22 }[1], [x12]
	shl.2d	v26, v20, #5
	ldp	q28, q27, [sp, #720]            ; 32-byte Folded Reload
	orr.16b	v26, v26, v28
	add.2d	v27, v27, v26
	tbz	w11, #6, LBB0_196
LBB0_219:                               ; %cond.load1301
                                        ;   in Loop: Header=BB0_189 Depth=2
	fmov	x12, d27
	ld1.s	{ v22 }[2], [x12]
	tbz	w11, #7, LBB0_197
LBB0_220:                               ; %cond.load1307
                                        ;   in Loop: Header=BB0_189 Depth=2
	mov.d	x11, v27[1]
	ld1.s	{ v22 }[3], [x11]
	fmov	w11, s16
	add.2d	v28, v7, v23
	movi.2d	v27, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbz	w11, #0, LBB0_198
LBB0_221:                               ; %cond.load1314
                                        ;   in Loop: Header=BB0_189 Depth=2
	fmov	x12, d28
	ldr	s27, [x12]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_199
LBB0_222:                               ; %cond.load1320
                                        ;   in Loop: Header=BB0_189 Depth=2
	mov.d	x12, v28[1]
	ld1.s	{ v27 }[1], [x12]
	ldr	q28, [sp, #624]                 ; 16-byte Folded Reload
	add.2d	v24, v15, v24
	tbz	w11, #2, LBB0_200
LBB0_223:                               ; %cond.load1326
                                        ;   in Loop: Header=BB0_189 Depth=2
	fmov	x12, d24
	ld1.s	{ v27 }[2], [x12]
	tbz	w11, #3, LBB0_201
LBB0_224:                               ; %cond.load1332
                                        ;   in Loop: Header=BB0_189 Depth=2
	mov.d	x12, v24[1]
	ld1.s	{ v27 }[3], [x12]
	add.2d	v24, v6, v25
	tbz	w11, #4, LBB0_202
LBB0_225:                               ; %cond.load1338
                                        ;   in Loop: Header=BB0_189 Depth=2
	fmov	x12, d24
	ld1.s	{ v23 }[0], [x12]
	tbz	w11, #5, LBB0_203
LBB0_226:                               ; %cond.load1344
                                        ;   in Loop: Header=BB0_189 Depth=2
	mov.d	x12, v24[1]
	ld1.s	{ v23 }[1], [x12]
	add.2d	v24, v14, v26
	tbz	w11, #6, LBB0_204
LBB0_227:                               ; %cond.load1350
                                        ;   in Loop: Header=BB0_189 Depth=2
	fmov	x12, d24
	ld1.s	{ v23 }[2], [x12]
	tbz	w11, #7, LBB0_205
LBB0_228:                               ; %cond.load1356
                                        ;   in Loop: Header=BB0_189 Depth=2
	mov.d	x11, v24[1]
	ld1.s	{ v23 }[3], [x11]
	fdiv.4s	v21, v21, v4
	fmov	w11, s16
	fmul.4s	v21, v21, v27
	add	x9, x8, x9, lsl #5
	tbz	w11, #0, LBB0_206
LBB0_229:                               ; %cond.store1363
                                        ;   in Loop: Header=BB0_189 Depth=2
	str	s21, [x9]
	and	w11, w11, #0xff
	ldr	q26, [sp, #656]                 ; 16-byte Folded Reload
	tbz	w11, #1, LBB0_207
LBB0_230:                               ; %cond.store1365
                                        ;   in Loop: Header=BB0_189 Depth=2
	add	x12, x9, #4
	st1.s	{ v21 }[1], [x12]
	tbz	w11, #2, LBB0_208
LBB0_231:                               ; %cond.store1367
                                        ;   in Loop: Header=BB0_189 Depth=2
	add	x12, x9, #8
	st1.s	{ v21 }[2], [x12]
	tbz	w11, #3, LBB0_209
LBB0_232:                               ; %cond.store1369
                                        ;   in Loop: Header=BB0_189 Depth=2
	add	x12, x9, #12
	st1.s	{ v21 }[3], [x12]
	fdiv.4s	v21, v22, v4
	fmul.4s	v21, v21, v23
	tbz	w11, #4, LBB0_210
LBB0_233:                               ; %cond.store1371
                                        ;   in Loop: Header=BB0_189 Depth=2
	str	s21, [x9, #16]
	tbz	w11, #5, LBB0_211
LBB0_234:                               ; %cond.store1373
                                        ;   in Loop: Header=BB0_189 Depth=2
	add	x12, x9, #20
	st1.s	{ v21 }[1], [x12]
	tbz	w11, #6, LBB0_212
LBB0_235:                               ; %cond.store1375
                                        ;   in Loop: Header=BB0_189 Depth=2
	add	x12, x9, #24
	st1.s	{ v21 }[2], [x12]
	tbz	w11, #7, LBB0_188
LBB0_236:                               ; %cond.store1377
                                        ;   in Loop: Header=BB0_189 Depth=2
	add	x9, x9, #28
	st1.s	{ v21 }[3], [x9]
	b	LBB0_188
LBB0_237:                               ; %direct.false110.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x14, x3
	ldp	q6, q5, [x8]
	zip1.8b	v7, v9, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v6, v7, v6
	fmov	w8, s2
	fdiv.4s	v6, v6, v4
	add	x9, sp, #1408
	add	x9, x9, x3
	ldp	q16, q2, [x9]
	and.16b	v7, v7, v16
	fmul.4s	v6, v6, v7
	ldr	q7, [sp, #272]                  ; 16-byte Folded Reload
	str	q7, [sp, #752]
	ldr	q7, [sp, #240]                  ; 16-byte Folded Reload
	str	q7, [sp, #768]
	ldr	q7, [sp, #224]                  ; 16-byte Folded Reload
	str	q7, [sp, #784]
	ldr	q7, [sp, #256]                  ; 16-byte Folded Reload
	str	q7, [sp, #800]
	and	x9, x30, #0x7
	add	x11, sp, #752
	ldr	x9, [x11, x9, lsl #3]
	sub	x9, x9, x30
	add	x9, x2, x9, lsl #2
	tbnz	w8, #0, LBB0_259
; %bb.238:                              ; %else1381
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x2, [sp, #376]                  ; 8-byte Folded Reload
	tbnz	w8, #1, LBB0_260
LBB0_239:                               ; %else1383
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #2, LBB0_261
LBB0_240:                               ; %else1385
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #3, LBB0_242
LBB0_241:                               ; %cond.store1386
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #12
	st1.s	{ v6 }[3], [x11]
LBB0_242:                               ; %else1387
                                        ;   in Loop: Header=BB0_3 Depth=1
	zip2.8b	v6, v9, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v5, v6, v5
	fdiv.4s	v4, v5, v4
	and.16b	v2, v6, v2
	fmul.4s	v2, v4, v2
	tbnz	w8, #4, LBB0_262
; %bb.243:                              ; %else1389
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #5, LBB0_263
LBB0_244:                               ; %else1391
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w8, #6, LBB0_264
LBB0_245:                               ; %else1393
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #7, LBB0_2
	b	LBB0_265
LBB0_246:                               ; %cond.load962
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	s26, [x8]
	tbz	w9, #1, LBB0_70
LBB0_247:                               ; %cond.load965
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #4
	ld1.s	{ v26 }[1], [x11]
	tbz	w9, #2, LBB0_71
LBB0_248:                               ; %cond.load968
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #8
	ld1.s	{ v26 }[2], [x11]
	tbz	w9, #3, LBB0_72
LBB0_249:                               ; %cond.load971
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #12
	ld1.s	{ v26 }[3], [x11]
	tbz	w9, #4, LBB0_73
LBB0_250:                               ; %cond.load974
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #16
	ld1.s	{ v27 }[0], [x11]
	tbz	w9, #5, LBB0_74
LBB0_251:                               ; %cond.load977
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #20
	ld1.s	{ v27 }[1], [x11]
	tbz	w9, #6, LBB0_75
LBB0_252:                               ; %cond.load980
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x8, #24
	ld1.s	{ v27 }[2], [x11]
	tbnz	w9, #7, LBB0_76
	b	LBB0_77
LBB0_253:                               ; %cond.load1243
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #4
	ld1.s	{ v17 }[1], [x11]
	ldr	w15, [sp, #372]                 ; 4-byte Folded Reload
	adrp	x16, lCPI0_1@PAGE
	ldr	w13, [sp, #368]                 ; 4-byte Folded Reload
	ldr	w0, [sp, #364]                  ; 4-byte Folded Reload
	tbz	w8, #2, LBB0_181
LBB0_254:                               ; %cond.load1246
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #8
	ld1.s	{ v17 }[2], [x11]
	tbz	w8, #3, LBB0_182
LBB0_255:                               ; %cond.load1249
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #12
	ld1.s	{ v17 }[3], [x11]
	tbz	w8, #4, LBB0_183
LBB0_256:                               ; %cond.load1252
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #16
	ld1.s	{ v18 }[0], [x11]
	tbz	w8, #5, LBB0_184
LBB0_257:                               ; %cond.load1255
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #20
	ld1.s	{ v18 }[1], [x11]
	tbz	w8, #6, LBB0_185
LBB0_258:                               ; %cond.load1258
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #24
	ld1.s	{ v18 }[2], [x11]
	tbnz	w8, #7, LBB0_186
	b	LBB0_187
LBB0_259:                               ; %cond.store1380
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s6, [x9]
	ldr	x2, [sp, #376]                  ; 8-byte Folded Reload
	tbz	w8, #1, LBB0_239
LBB0_260:                               ; %cond.store1382
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #4
	st1.s	{ v6 }[1], [x11]
	tbz	w8, #2, LBB0_240
LBB0_261:                               ; %cond.store1384
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #8
	st1.s	{ v6 }[2], [x11]
	tbnz	w8, #3, LBB0_241
	b	LBB0_242
LBB0_262:                               ; %cond.store1388
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s2, [x9, #16]
	tbz	w8, #5, LBB0_244
LBB0_263:                               ; %cond.store1390
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #20
	st1.s	{ v2 }[1], [x11]
	tbz	w8, #6, LBB0_245
LBB0_264:                               ; %cond.store1392
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x9, #24
	st1.s	{ v2 }[2], [x11]
	tbz	w8, #7, LBB0_2
LBB0_265:                               ; %cond.store1394
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #28
	st1.s	{ v2 }[3], [x8]
	b	LBB0_2
LBB0_266:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Folded Reload
	stp	w2, w0, [x9]
	str	w13, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
LBB0_267:                               ; %block.batch.exit
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #1472
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_1:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_2:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	32                              ; 0x20
	.quad	36                              ; 0x24
lCPI0_5:
	.quad	40                              ; 0x28
	.quad	44                              ; 0x2c
lCPI0_6:
	.quad	48                              ; 0x30
	.quad	52                              ; 0x34
lCPI0_7:
	.quad	56                              ; 0x38
	.quad	60                              ; 0x3c
lCPI0_8:
	.quad	64                              ; 0x40
	.quad	68                              ; 0x44
lCPI0_9:
	.quad	72                              ; 0x48
	.quad	76                              ; 0x4c
lCPI0_10:
	.quad	80                              ; 0x50
	.quad	84                              ; 0x54
lCPI0_11:
	.quad	88                              ; 0x58
	.quad	92                              ; 0x5c
lCPI0_12:
	.quad	96                              ; 0x60
	.quad	100                             ; 0x64
lCPI0_13:
	.quad	104                             ; 0x68
	.quad	108                             ; 0x6c
lCPI0_14:
	.quad	112                             ; 0x70
	.quad	116                             ; 0x74
lCPI0_15:
	.quad	120                             ; 0x78
	.quad	124                             ; 0x7c
lCPI0_16:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_17:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_18:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_19:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_20:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_21:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_22:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_23:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1968
	str	x0, [sp, #336]                  ; 8-byte Folded Spill
	str	w3, [sp, #360]                  ; 4-byte Folded Spill
	cbz	w3, LBB0_257
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w12, #0                         ; =0x0
	add	x8, sp, #1392
	add	x9, sp, #1680
	ldp	w11, w10, [x2, #44]
	str	w11, [sp, #348]                 ; 4-byte Folded Spill
	str	w10, [sp, #344]                 ; 4-byte Folded Spill
	mov	w15, #4                         ; =0x4
	adrp	x16, lCPI0_2@PAGE
	adrp	x17, lCPI0_3@PAGE
	dup.2d	v0, x8
	adrp	x1, lCPI0_4@PAGE
	adrp	x4, lCPI0_5@PAGE
	adrp	x5, lCPI0_6@PAGE
	adrp	x6, lCPI0_7@PAGE
	dup.2d	v1, x9
	adrp	x7, lCPI0_8@PAGE
	adrp	x19, lCPI0_9@PAGE
	adrp	x20, lCPI0_10@PAGE
	adrp	x21, lCPI0_11@PAGE
	dup.2d	v2, x15
	str	q2, [sp, #320]                  ; 16-byte Folded Spill
	adrp	x22, lCPI0_12@PAGE
Lloh0:
	adrp	x9, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x9, lCPI0_0@PAGEOFF]
	adrp	x23, lCPI0_13@PAGE
Lloh2:
	adrp	x9, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x9, lCPI0_1@PAGEOFF]
	adrp	x24, lCPI0_14@PAGE
	adrp	x25, lCPI0_15@PAGE
	mov	w26, #1                         ; =0x1
	movi	d12, #0000000000000000
	ldp	w11, w10, [x2, #4]
	ldr	w9, [x2]
	str	x2, [sp, #352]                  ; 8-byte Folded Spill
	str	q3, [sp, #608]                  ; 16-byte Folded Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w8, w0, #1
	ldr	w9, [sp, #348]                  ; 4-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w9, wzr, w0, eq
	cinc	w10, w14, eq
	ldr	w11, [sp, #344]                 ; 4-byte Folded Reload
	cmp	w10, w11
	cset	w11, eq
	ands	w8, w8, w11
	csel	w11, wzr, w10, ne
	add	w10, w13, w8
	add	w12, w12, #1
	ldr	w8, [sp, #360]                  ; 4-byte Folded Reload
	cmp	w12, w8
	ldr	x2, [sp, #352]                  ; 8-byte Folded Reload
	b.eq	LBB0_256
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_31 Depth 2
                                        ;       Child Loop BB0_32 Depth 3
                                        ;       Child Loop BB0_34 Depth 3
                                        ;       Child Loop BB0_36 Depth 3
                                        ;     Child Loop BB0_42 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_135 Depth 2
                                        ;     Child Loop BB0_178 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
                                        ;     Child Loop BB0_21 Depth 2
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
	str	w12, [sp, #372]                 ; 4-byte Folded Spill
	str	w10, [sp, #368]                 ; 4-byte Folded Spill
	str	w11, [sp, #364]                 ; 4-byte Folded Spill
	mov	x14, x9
	ldr	w9, [x2, #12]
	ubfiz	x10, x14, #5, #32
	cmp	x10, x9
	csel	x11, x10, xzr, ls
	subs	x12, x9, x11
	cmp	x12, #32
	mov	w8, #32                         ; =0x20
	csel	x12, x12, x8, lo
	cmp	x9, x11
	ccmp	x10, x9, #2, hi
	csel	x9, x12, xzr, ls
	cmp	x9, #32
	str	x14, [sp, #376]                 ; 8-byte Folded Spill
	b.lo	LBB0_29
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #336]                  ; 8-byte Folded Reload
	ldr	x3, [x8]
	ldr	x13, [x8, #16]
	ubfiz	w11, w14, #2, #27
	mov	w9, #260                        ; =0x104
	umull	x10, w11, w9
	str	w11, [sp, #512]                 ; 4-byte Folded Spill
	umaddl	x9, w11, w9, x3
	ldp	q2, q5, [x9]
	str	q5, [sp, #1696]
	str	q2, [sp, #1680]
	ldp	q6, q7, [x9, #32]
	str	q7, [sp, #1728]
	str	q6, [sp, #1712]
	ldp	q16, q17, [x9, #64]
	str	q17, [sp, #1760]
	str	q16, [sp, #1744]
	ldp	q18, q19, [x9, #96]
	str	q19, [sp, #1792]
	str	q18, [sp, #1776]
	ldp	q20, q21, [x9, #128]
	str	q21, [sp, #1824]
	str	q20, [sp, #1808]
	ldp	q20, q21, [x9, #160]
	str	q21, [sp, #1856]
	str	q20, [sp, #1840]
	ldp	q20, q21, [x9, #192]
	str	q21, [sp, #1888]
	str	q20, [sp, #1872]
	ldp	q20, q21, [x9, #224]
	str	q21, [sp, #1920]
	str	q20, [sp, #1904]
	add	x9, x10, #256
	ldr	s20, [x3, x9]
	fmul.4s	v5, v5, v5
	fmul.4s	v2, v2, v2
	ldr	x12, [x8, #48]
	str	q20, [sp, #656]                 ; 16-byte Folded Spill
	str	q20, [sp, #1936]
	fmul.4s	v9, v7, v7
	fmul.4s	v8, v6, v6
	fmul.4s	v7, v17, v17
	fmul.4s	v10, v16, v16
	fmul.4s	v17, v19, v19
	fmul.4s	v16, v18, v18
	ldr	q14, [sp, #320]                 ; 16-byte Folded Reload
	mov.16b	v11, v14
	mov.16b	v12, v14
	mov.16b	v13, v14
LBB0_5:                                 ; %direct.true57.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v6, v11, #5
	add.2d	v29, v1, v6
	ldr	q3, [sp, #608]                  ; 16-byte Folded Reload
	add.2d	v20, v29, v3
	mov.d	x11, v20[1]
	shl.2d	v6, v12, #5
	add.2d	v18, v1, v6
	add.2d	v21, v18, v4
	mov.d	x14, v21[1]
	ldr	q3, [x16, lCPI0_2@PAGEOFF]
	shl.2d	v6, v13, #5
	add.2d	v15, v1, v6
	add.2d	v22, v15, v3
	mov.d	x0, v22[1]
	ldr	q19, [x17, lCPI0_3@PAGEOFF]
	shl.2d	v6, v14, #5
	add.2d	v6, v1, v6
	add.2d	v23, v6, v19
	mov.d	x2, v23[1]
	fmov	x27, d20
	ldr	s20, [x27]
	fmov	x27, d21
	fmov	x28, d22
	ld1.s	{ v20 }[1], [x11]
	fmov	x11, d23
	ld1.s	{ v20 }[2], [x27]
	ld1.s	{ v20 }[3], [x14]
	ldr	s21, [x28]
	ld1.s	{ v21 }[1], [x0]
	ld1.s	{ v21 }[2], [x11]
	ld1.s	{ v21 }[3], [x2]
	fmul.4s	v21, v21, v21
	fmul.4s	v20, v20, v20
	fadd.4s	v2, v2, v20
	fadd.4s	v5, v5, v21
	ldr	q22, [x1, lCPI0_4@PAGEOFF]
	ldr	q23, [x4, lCPI0_5@PAGEOFF]
	ldr	q26, [x5, lCPI0_6@PAGEOFF]
	ldr	q27, [x6, lCPI0_7@PAGEOFF]
	add.2d	v20, v6, v27
	add.2d	v21, v15, v26
	add.2d	v24, v18, v23
	add.2d	v25, v29, v22
	mov.d	x11, v25[1]
	fmov	x14, d25
	mov.d	x0, v24[1]
	fmov	x2, d24
	mov.d	x27, v21[1]
	fmov	x28, d21
	mov.d	x8, v20[1]
	ldr	s21, [x14]
	ld1.s	{ v21 }[1], [x11]
	ld1.s	{ v21 }[2], [x2]
	ld1.s	{ v21 }[3], [x0]
	fmov	x11, d20
	ldr	s20, [x28]
	ld1.s	{ v20 }[1], [x27]
	ld1.s	{ v20 }[2], [x11]
	ld1.s	{ v20 }[3], [x8]
	fmul.4s	v20, v20, v20
	fmul.4s	v21, v21, v21
	fadd.4s	v8, v8, v21
	fadd.4s	v9, v9, v20
	ldr	q24, [x7, lCPI0_8@PAGEOFF]
	ldr	q25, [x19, lCPI0_9@PAGEOFF]
	ldr	q28, [x20, lCPI0_10@PAGEOFF]
	ldr	q30, [x21, lCPI0_11@PAGEOFF]
	add.2d	v20, v6, v30
	add.2d	v21, v29, v24
	mov.d	x8, v21[1]
	fmov	x11, d21
	add.2d	v21, v18, v25
	mov.d	x14, v21[1]
	fmov	x0, d21
	add.2d	v21, v15, v28
	mov.d	x2, v21[1]
	mov.d	x27, v20[1]
	fmov	x28, d21
	ldr	s21, [x11]
	ld1.s	{ v21 }[1], [x8]
	ld1.s	{ v21 }[2], [x0]
	fmov	x8, d20
	ld1.s	{ v21 }[3], [x14]
	ldr	s20, [x28]
	ld1.s	{ v20 }[1], [x2]
	ld1.s	{ v20 }[2], [x8]
	ld1.s	{ v20 }[3], [x27]
	fmul.4s	v20, v20, v20
	fmul.4s	v21, v21, v21
	fadd.4s	v10, v10, v21
	fadd.4s	v7, v7, v20
	ldr	q21, [x22, lCPI0_12@PAGEOFF]
	add.2d	v20, v29, v21
	mov.d	x8, v20[1]
	ldr	q29, [x23, lCPI0_13@PAGEOFF]
	fmov	x11, d20
	ldr	q31, [x24, lCPI0_14@PAGEOFF]
	add.2d	v20, v18, v29
	mov.d	x14, v20[1]
	fmov	x0, d20
	ldr	q18, [x25, lCPI0_15@PAGEOFF]
	add.2d	v6, v6, v18
	add.2d	v20, v15, v31
	mov.d	x2, v20[1]
	fmov	x27, d20
	mov.d	x28, v6[1]
	ldr	s20, [x11]
	ld1.s	{ v20 }[1], [x8]
	fmov	x8, d6
	ld1.s	{ v20 }[2], [x0]
	ld1.s	{ v20 }[3], [x14]
	fmul.4s	v6, v20, v20
	fadd.4s	v16, v16, v6
	ldr	s6, [x27]
	ld1.s	{ v6 }[1], [x2]
	ld1.s	{ v6 }[2], [x8]
	ld1.s	{ v6 }[3], [x28]
	fmul.4s	v6, v6, v6
	fadd.4s	v17, v17, v6
	dup.2d	v6, x15
	add.2d	v13, v13, v6
	add.2d	v12, v12, v6
	add.2d	v14, v14, v6
	add.2d	v11, v11, v6
	fmov	x8, d11
	cmp	x8, #8
	b.lt	LBB0_5
; %bb.6:                                ; %direct.true85.i.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q18, [sp, #528]                 ; 16-byte Folded Spill
	str	q21, [sp, #576]                 ; 16-byte Folded Spill
	stp	q23, q22, [sp, #704]            ; 32-byte Folded Spill
	mov	x11, #0                         ; =0x0
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v11, #0000000000000000
	mov.16b	v18, v3
	ldr	q3, [sp, #608]                  ; 16-byte Folded Reload
LBB0_7:                                 ; %direct.true85.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, x13, x11, lsl #5
	ldp	q13, q12, [x8]
	shl.2d	v14, v6, #5
	shl.2d	v15, v20, #5
	shl.2d	v22, v21, #5
	shl.2d	v23, v11, #5
	add.2d	v23, v23, v19
	add.2d	v23, v0, v23
	add.2d	v22, v22, v18
	add.2d	v15, v15, v4
	add.2d	v14, v14, v3
	add.2d	v14, v0, v14
	mov.d	x8, v14[1]
	fmov	x11, d14
	str	s13, [x11]
	st1.s	{ v13 }[1], [x8]
	add.2d	v14, v0, v15
	mov.d	x8, v14[1]
	fmov	x11, d14
	st1.s	{ v13 }[2], [x11]
	add.2d	v22, v0, v22
	st1.s	{ v13 }[3], [x8]
	mov.d	x8, v22[1]
	fmov	x11, d22
	str	s12, [x11]
	st1.s	{ v12 }[1], [x8]
	mov.d	x8, v23[1]
	fmov	x11, d23
	st1.s	{ v12 }[2], [x11]
	st1.s	{ v12 }[3], [x8]
	dup.2d	v22, x26
	add.2d	v21, v21, v22
	add.2d	v20, v20, v22
	add.2d	v11, v11, v22
	add.2d	v6, v6, v22
	fmov	x11, d6
	cmp	x11, #8
	b.lt	LBB0_7
; %bb.8:                                ; %direct.false86.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	stp	q31, q29, [sp, #544]            ; 32-byte Folded Spill
	str	q30, [sp, #592]                 ; 16-byte Folded Spill
	stp	q28, q25, [sp, #624]            ; 32-byte Folded Spill
	stp	q27, q26, [sp, #672]            ; 32-byte Folded Spill
	mov	x11, #0                         ; =0x0
	ldr	q6, [sp, #656]                  ; 16-byte Folded Reload
	fmul.4s	v6, v6, v6
	fadd.4s	v6, v6, v2
	mov.s	v2[0], v6[0]
	fadd.4s	v5, v9, v5
	fadd.4s	v2, v8, v2
	fadd.4s	v2, v10, v2
	fadd.4s	v5, v7, v5
	fadd.4s	v5, v17, v5
	fadd.4s	v2, v16, v2
	rev64.4s	v6, v2
	rev64.4s	v7, v5
	fadd.4s	v2, v2, v6
	dup.4s	v6, v2[2]
	fadd.4s	v5, v5, v7
	dup.4s	v7, v5[2]
	fadd.4s	v5, v5, v7
	fadd.4s	v2, v2, v6
	fadd.4s	v2, v2, v5
	movi	d5, #0000000000000000
	fadd	s5, s2, s5
	mov	w8, #1115815936                 ; =0x42820000
	fmov	s6, w8
	add	x8, x13, #256
	ldr	q2, [sp, #1648]
	str	x8, [sp, #496]                  ; 8-byte Folded Spill
	ld1.s	{ v2 }[0], [x8]
	fdiv	s5, s5, s6
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s6, w8
	fadd	s5, s5, s6
	fsqrt	s5, s5
	dup.4s	v6, v5[0]
	str	q2, [sp, #1648]
	add	x10, x12, x10
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB0_9:                                 ; %direct.true109.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v20, #5
	shl.2d	v22, v17, #5
	shl.2d	v23, v16, #5
	shl.2d	v8, v7, #5
	orr.16b	v8, v8, v3
	orr.16b	v23, v23, v4
	orr.16b	v22, v22, v18
	orr.16b	v21, v21, v19
	add.2d	v9, v1, v21
	add.2d	v10, v1, v22
	add.2d	v11, v1, v23
	add.2d	v12, v1, v8
	mov.d	x8, v12[1]
	mov.d	x14, v11[1]
	mov.d	x0, v10[1]
	fmov	x27, d12
	fmov	x28, d10
	mov.d	x2, v9[1]
	fmov	x30, d9
	ldr	s9, [x28]
	ld1.s	{ v9 }[1], [x0]
	ld1.s	{ v9 }[2], [x30]
	ld1.s	{ v9 }[3], [x2]
	fmov	x0, d11
	ldr	s10, [x27]
	ld1.s	{ v10 }[1], [x8]
	ld1.s	{ v10 }[2], [x0]
	ld1.s	{ v10 }[3], [x14]
	fdiv.4s	v10, v10, v6
	fdiv.4s	v9, v9, v6
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v8, v0, v8
	mov.d	x8, v8[1]
	fmov	x14, d8
	mov.d	x0, v23[1]
	mov.d	x2, v22[1]
	mov.d	x27, v21[1]
	fmov	x28, d23
	ldr	s23, [x14]
	ld1.s	{ v23 }[1], [x8]
	ld1.s	{ v23 }[2], [x28]
	fmov	x8, d22
	ld1.s	{ v23 }[3], [x0]
	ldr	s22, [x8]
	ld1.s	{ v22 }[1], [x2]
	fmov	x8, d21
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x27]
	fmul.4s	v21, v9, v22
	fmul.4s	v22, v10, v23
	add	x8, x10, x11, lsl #5
	stp	q22, q21, [x8]
	dup.2d	v21, x26
	add.2d	v17, v17, v21
	add.2d	v16, v16, v21
	add.2d	v20, v20, v21
	add.2d	v7, v7, v21
	fmov	x11, d7
	cmp	x11, #8
	b.lt	LBB0_9
; %bb.10:                               ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q6, [sp, #1936]
	fdiv.4s	v5, v6, v5
	fmul.4s	v2, v2, v5
	str	s2, [x12, x9]
	ldr	w8, [sp, #512]                  ; 4-byte Folded Reload
	orr	w8, w8, #0x1
	mov	w9, #260                        ; =0x104
	umull	x10, w8, w9
	umaddl	x8, w8, w9, x3
	ldp	q2, q5, [x8]
	str	q5, [sp, #1696]
	str	q2, [sp, #1680]
	ldp	q6, q7, [x8, #32]
	str	q7, [sp, #1728]
	str	q6, [sp, #1712]
	ldp	q16, q17, [x8, #64]
	str	q17, [sp, #1760]
	str	q16, [sp, #1744]
	ldp	q20, q21, [x8, #96]
	str	q21, [sp, #1792]
	str	q20, [sp, #1776]
	ldp	q22, q23, [x8, #128]
	str	q23, [sp, #1824]
	str	q22, [sp, #1808]
	ldp	q22, q23, [x8, #160]
	str	q23, [sp, #1856]
	str	q22, [sp, #1840]
	ldp	q22, q23, [x8, #192]
	str	q23, [sp, #1888]
	str	q22, [sp, #1872]
	ldp	q22, q23, [x8, #224]
	str	q23, [sp, #1920]
	str	q22, [sp, #1904]
	add	x9, x10, #256
	ldr	s22, [x3, x9]
	str	q22, [sp, #480]                 ; 16-byte Folded Spill
	str	q22, [sp, #1936]
	fmul.4s	v5, v5, v5
	fmul.4s	v2, v2, v2
	fmul.4s	v9, v7, v7
	fmul.4s	v8, v6, v6
	fmul.4s	v7, v17, v17
	fmul.4s	v10, v16, v16
	fmul.4s	v17, v21, v21
	fmul.4s	v16, v20, v20
	dup.2d	v11, x15
	mov.16b	v12, v11
	mov.16b	v13, v11
	mov.16b	v14, v11
	mov.16b	v29, v24
	ldr	q31, [sp, #624]                 ; 16-byte Folded Reload
	ldp	q26, q25, [sp, #576]            ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #544]            ; 32-byte Folded Reload
	ldr	q30, [sp, #528]                 ; 16-byte Folded Reload
LBB0_11:                                ; %direct.true57.i33.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v6, v11, #5
	shl.2d	v21, v12, #5
	shl.2d	v22, v13, #5
	shl.2d	v20, v14, #5
	add.2d	v15, v1, v20
	add.2d	v23, v15, v19
	add.2d	v20, v1, v6
	add.2d	v24, v20, v3
	mov.d	x8, v24[1]
	add.2d	v6, v1, v22
	add.2d	v21, v1, v21
	fmov	x11, d24
	add.2d	v22, v21, v4
	mov.d	x14, v22[1]
	fmov	x0, d22
	add.2d	v22, v6, v18
	mov.d	x2, v22[1]
	fmov	x27, d22
	mov.d	x28, v23[1]
	ldr	s22, [x11]
	ld1.s	{ v22 }[1], [x8]
	fmov	x8, d23
	ld1.s	{ v22 }[2], [x0]
	ld1.s	{ v22 }[3], [x14]
	ldr	s23, [x27]
	ld1.s	{ v23 }[1], [x2]
	ld1.s	{ v23 }[2], [x8]
	ld1.s	{ v23 }[3], [x28]
	fmul.4s	v23, v23, v23
	fmul.4s	v22, v22, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v5, v5, v23
	ldr	q22, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v22, v15, v22
	ldr	q23, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v23, v20, v23
	mov.d	x8, v23[1]
	fmov	x11, d23
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v23, v21, v23
	mov.d	x14, v23[1]
	fmov	x0, d23
	ldr	q23, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v23, v6, v23
	mov.d	x2, v23[1]
	mov.d	x27, v22[1]
	fmov	x28, d23
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x8]
	ld1.s	{ v23 }[2], [x0]
	fmov	x8, d22
	ld1.s	{ v23 }[3], [x14]
	ldr	s22, [x28]
	ld1.s	{ v22 }[1], [x2]
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x27]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	fadd.4s	v8, v8, v23
	fadd.4s	v9, v9, v22
	add.2d	v22, v15, v25
	add.2d	v23, v20, v29
	mov.d	x8, v23[1]
	fmov	x11, d23
	ldr	q23, [sp, #640]                 ; 16-byte Folded Reload
	add.2d	v23, v21, v23
	mov.d	x14, v23[1]
	fmov	x0, d23
	add.2d	v23, v6, v31
	mov.d	x2, v23[1]
	fmov	x27, d23
	mov.d	x28, v22[1]
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x8]
	ld1.s	{ v23 }[2], [x0]
	ld1.s	{ v23 }[3], [x14]
	fmov	x8, d22
	fmul.4s	v22, v23, v23
	fadd.4s	v10, v10, v22
	ldr	s22, [x27]
	ld1.s	{ v22 }[1], [x2]
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x28]
	fmul.4s	v22, v22, v22
	fadd.4s	v7, v7, v22
	add.2d	v21, v21, v27
	add.2d	v20, v20, v26
	mov.d	x8, v20[1]
	mov.d	x11, v21[1]
	fmov	x14, d20
	fmov	x0, d21
	add.2d	v20, v15, v30
	add.2d	v6, v6, v28
	mov.d	x2, v6[1]
	fmov	x27, d6
	mov.d	x28, v20[1]
	ldr	s6, [x14]
	ld1.s	{ v6 }[1], [x8]
	fmov	x8, d20
	ld1.s	{ v6 }[2], [x0]
	ld1.s	{ v6 }[3], [x11]
	fmul.4s	v6, v6, v6
	fadd.4s	v16, v16, v6
	ldr	s6, [x27]
	ld1.s	{ v6 }[1], [x2]
	ld1.s	{ v6 }[2], [x8]
	ld1.s	{ v6 }[3], [x28]
	fmul.4s	v6, v6, v6
	fadd.4s	v17, v17, v6
	dup.2d	v6, x15
	add.2d	v13, v13, v6
	add.2d	v12, v12, v6
	add.2d	v14, v14, v6
	add.2d	v11, v11, v6
	fmov	x8, d11
	cmp	x8, #8
	b.lt	LBB0_11
; %bb.12:                               ; %direct.true85.i40.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q29, [sp, #656]                 ; 16-byte Folded Spill
	mov	x11, #0                         ; =0x0
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v11, #0000000000000000
LBB0_13:                                ; %direct.true85.i40.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, x13, x11, lsl #5
	ldp	q23, q22, [x8]
	shl.2d	v24, v6, #5
	shl.2d	v12, v20, #5
	shl.2d	v13, v21, #5
	shl.2d	v14, v11, #5
	add.2d	v14, v14, v19
	add.2d	v14, v0, v14
	add.2d	v13, v13, v18
	add.2d	v12, v12, v4
	add.2d	v24, v24, v3
	add.2d	v24, v0, v24
	mov.d	x8, v24[1]
	fmov	x11, d24
	str	s23, [x11]
	st1.s	{ v23 }[1], [x8]
	add.2d	v24, v0, v12
	mov.d	x8, v24[1]
	fmov	x11, d24
	st1.s	{ v23 }[2], [x11]
	add.2d	v24, v0, v13
	st1.s	{ v23 }[3], [x8]
	mov.d	x8, v24[1]
	fmov	x11, d24
	str	s22, [x11]
	st1.s	{ v22 }[1], [x8]
	mov.d	x8, v14[1]
	fmov	x11, d14
	st1.s	{ v22 }[2], [x11]
	st1.s	{ v22 }[3], [x8]
	dup.2d	v22, x26
	add.2d	v21, v21, v22
	add.2d	v20, v20, v22
	add.2d	v11, v11, v22
	add.2d	v6, v6, v22
	fmov	x11, d6
	cmp	x11, #8
	b.lt	LBB0_13
; %bb.14:                               ; %direct.false86.i44.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	q6, [sp, #480]                  ; 16-byte Folded Reload
	fmul.4s	v6, v6, v6
	fadd.4s	v6, v6, v2
	mov.s	v2[0], v6[0]
	fadd.4s	v5, v9, v5
	fadd.4s	v2, v8, v2
	fadd.4s	v2, v10, v2
	fadd.4s	v5, v7, v5
	fadd.4s	v5, v17, v5
	fadd.4s	v2, v16, v2
	rev64.4s	v6, v2
	rev64.4s	v7, v5
	fadd.4s	v5, v5, v7
	fadd.4s	v2, v2, v6
	dup.4s	v6, v2[2]
	dup.4s	v7, v5[2]
	fadd.4s	v5, v5, v7
	fadd.4s	v2, v2, v6
	fadd.4s	v2, v2, v5
	movi	d5, #0000000000000000
	fadd	s5, s2, s5
	mov	w8, #1115815936                 ; =0x42820000
	fmov	s6, w8
	ldr	q2, [sp, #1648]
	ldr	x8, [sp, #496]                  ; 8-byte Folded Reload
	ld1.s	{ v2 }[0], [x8]
	fdiv	s5, s5, s6
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s6, w8
	fadd	s5, s5, s6
	fsqrt	s5, s5
	dup.4s	v6, v5[0]
	str	q2, [sp, #1648]
	add	x10, x12, x10
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB0_15:                                ; %direct.true109.i52.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v20, #5
	shl.2d	v22, v17, #5
	shl.2d	v23, v16, #5
	shl.2d	v24, v7, #5
	orr.16b	v24, v24, v3
	orr.16b	v23, v23, v4
	orr.16b	v22, v22, v18
	orr.16b	v21, v21, v19
	add.2d	v8, v1, v21
	add.2d	v9, v1, v22
	add.2d	v10, v1, v23
	add.2d	v11, v1, v24
	mov.d	x8, v11[1]
	mov.d	x14, v10[1]
	mov.d	x0, v9[1]
	fmov	x2, d11
	fmov	x27, d9
	mov.d	x28, v8[1]
	fmov	x30, d8
	ldr	s8, [x27]
	ld1.s	{ v8 }[1], [x0]
	ld1.s	{ v8 }[2], [x30]
	ld1.s	{ v8 }[3], [x28]
	fmov	x0, d10
	ldr	s9, [x2]
	ld1.s	{ v9 }[1], [x8]
	ld1.s	{ v9 }[2], [x0]
	ld1.s	{ v9 }[3], [x14]
	fdiv.4s	v9, v9, v6
	fdiv.4s	v8, v8, v6
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v24, v0, v24
	mov.d	x8, v24[1]
	fmov	x14, d24
	mov.d	x0, v23[1]
	mov.d	x2, v22[1]
	mov.d	x27, v21[1]
	fmov	x28, d23
	ldr	s23, [x14]
	ld1.s	{ v23 }[1], [x8]
	ld1.s	{ v23 }[2], [x28]
	fmov	x8, d22
	ld1.s	{ v23 }[3], [x0]
	ldr	s22, [x8]
	ld1.s	{ v22 }[1], [x2]
	fmov	x8, d21
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x27]
	fmul.4s	v21, v8, v22
	fmul.4s	v22, v9, v23
	add	x8, x10, x11, lsl #5
	stp	q22, q21, [x8]
	dup.2d	v21, x26
	add.2d	v17, v17, v21
	add.2d	v16, v16, v21
	add.2d	v20, v20, v21
	add.2d	v7, v7, v21
	fmov	x11, d7
	cmp	x11, #8
	b.lt	LBB0_15
; %bb.16:                               ; %llm_rows.full_packet.exit57.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q6, [sp, #1936]
	fdiv.4s	v5, v6, v5
	fmul.4s	v2, v2, v5
	str	s2, [x12, x9]
	ldr	w8, [sp, #512]                  ; 4-byte Folded Reload
	orr	w8, w8, #0x2
	mov	w9, #260                        ; =0x104
	umull	x10, w8, w9
	umaddl	x8, w8, w9, x3
	ldp	q2, q5, [x8]
	str	q5, [sp, #1696]
	str	q2, [sp, #1680]
	ldp	q6, q7, [x8, #32]
	str	q7, [sp, #1728]
	str	q6, [sp, #1712]
	ldp	q16, q17, [x8, #64]
	str	q17, [sp, #1760]
	str	q16, [sp, #1744]
	ldp	q20, q21, [x8, #96]
	str	q21, [sp, #1792]
	str	q20, [sp, #1776]
	ldp	q22, q23, [x8, #128]
	str	q23, [sp, #1824]
	str	q22, [sp, #1808]
	ldp	q22, q23, [x8, #160]
	str	q23, [sp, #1856]
	str	q22, [sp, #1840]
	ldp	q22, q23, [x8, #192]
	str	q23, [sp, #1888]
	str	q22, [sp, #1872]
	ldp	q22, q23, [x8, #224]
	str	q23, [sp, #1920]
	str	q22, [sp, #1904]
	add	x9, x10, #256
	ldr	s22, [x3, x9]
	str	q22, [sp, #480]                 ; 16-byte Folded Spill
	str	q22, [sp, #1936]
	fmul.4s	v5, v5, v5
	fmul.4s	v2, v2, v2
	fmul.4s	v9, v7, v7
	fmul.4s	v8, v6, v6
	fmul.4s	v7, v17, v17
	fmul.4s	v10, v16, v16
	fmul.4s	v17, v21, v21
	fmul.4s	v16, v20, v20
	dup.2d	v11, x15
	mov.16b	v12, v11
	mov.16b	v13, v11
	mov.16b	v14, v11
	ldp	q31, q30, [sp, #624]            ; 32-byte Folded Reload
	ldp	q26, q25, [sp, #576]            ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #544]            ; 32-byte Folded Reload
	ldr	q29, [sp, #528]                 ; 16-byte Folded Reload
LBB0_17:                                ; %direct.true57.i88.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v6, v11, #5
	shl.2d	v21, v12, #5
	shl.2d	v22, v13, #5
	shl.2d	v20, v14, #5
	add.2d	v15, v1, v20
	add.2d	v23, v15, v19
	add.2d	v20, v1, v6
	add.2d	v24, v20, v3
	mov.d	x8, v24[1]
	add.2d	v6, v1, v22
	add.2d	v21, v1, v21
	fmov	x11, d24
	add.2d	v22, v21, v4
	mov.d	x14, v22[1]
	fmov	x0, d22
	add.2d	v22, v6, v18
	mov.d	x2, v22[1]
	fmov	x27, d22
	mov.d	x28, v23[1]
	ldr	s22, [x11]
	ld1.s	{ v22 }[1], [x8]
	fmov	x8, d23
	ld1.s	{ v22 }[2], [x0]
	ld1.s	{ v22 }[3], [x14]
	ldr	s23, [x27]
	ld1.s	{ v23 }[1], [x2]
	ld1.s	{ v23 }[2], [x8]
	ld1.s	{ v23 }[3], [x28]
	fmul.4s	v23, v23, v23
	fmul.4s	v22, v22, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v5, v5, v23
	ldr	q22, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v22, v15, v22
	ldr	q23, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v23, v20, v23
	mov.d	x8, v23[1]
	fmov	x11, d23
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v23, v21, v23
	mov.d	x14, v23[1]
	fmov	x0, d23
	ldr	q23, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v23, v6, v23
	mov.d	x2, v23[1]
	mov.d	x27, v22[1]
	fmov	x28, d23
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x8]
	ld1.s	{ v23 }[2], [x0]
	fmov	x8, d22
	ld1.s	{ v23 }[3], [x14]
	ldr	s22, [x28]
	ld1.s	{ v22 }[1], [x2]
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x27]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	fadd.4s	v8, v8, v23
	fadd.4s	v9, v9, v22
	add.2d	v22, v15, v25
	ldr	q23, [sp, #656]                 ; 16-byte Folded Reload
	add.2d	v23, v20, v23
	mov.d	x8, v23[1]
	fmov	x11, d23
	add.2d	v23, v21, v30
	mov.d	x14, v23[1]
	fmov	x0, d23
	add.2d	v23, v6, v31
	mov.d	x2, v23[1]
	fmov	x27, d23
	mov.d	x28, v22[1]
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x8]
	ld1.s	{ v23 }[2], [x0]
	ld1.s	{ v23 }[3], [x14]
	fmov	x8, d22
	fmul.4s	v22, v23, v23
	fadd.4s	v10, v10, v22
	ldr	s22, [x27]
	ld1.s	{ v22 }[1], [x2]
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x28]
	fmul.4s	v22, v22, v22
	fadd.4s	v7, v7, v22
	add.2d	v21, v21, v27
	add.2d	v20, v20, v26
	mov.d	x8, v20[1]
	mov.d	x11, v21[1]
	fmov	x14, d20
	fmov	x0, d21
	add.2d	v20, v15, v29
	add.2d	v6, v6, v28
	mov.d	x2, v6[1]
	fmov	x27, d6
	mov.d	x28, v20[1]
	ldr	s6, [x14]
	ld1.s	{ v6 }[1], [x8]
	fmov	x8, d20
	ld1.s	{ v6 }[2], [x0]
	ld1.s	{ v6 }[3], [x11]
	fmul.4s	v6, v6, v6
	fadd.4s	v16, v16, v6
	ldr	s6, [x27]
	ld1.s	{ v6 }[1], [x2]
	ld1.s	{ v6 }[2], [x8]
	ld1.s	{ v6 }[3], [x28]
	fmul.4s	v6, v6, v6
	fadd.4s	v17, v17, v6
	dup.2d	v6, x15
	add.2d	v13, v13, v6
	add.2d	v12, v12, v6
	add.2d	v14, v14, v6
	add.2d	v11, v11, v6
	fmov	x8, d11
	cmp	x8, #8
	b.lt	LBB0_17
; %bb.18:                               ; %direct.true85.i95.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	movi.2d	v6, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v11, #0000000000000000
LBB0_19:                                ; %direct.true85.i95.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, x13, x11, lsl #5
	ldp	q23, q22, [x8]
	shl.2d	v24, v6, #5
	shl.2d	v12, v20, #5
	shl.2d	v13, v21, #5
	shl.2d	v14, v11, #5
	add.2d	v14, v14, v19
	add.2d	v14, v0, v14
	add.2d	v13, v13, v18
	add.2d	v12, v12, v4
	add.2d	v24, v24, v3
	add.2d	v24, v0, v24
	mov.d	x8, v24[1]
	fmov	x11, d24
	str	s23, [x11]
	st1.s	{ v23 }[1], [x8]
	add.2d	v24, v0, v12
	mov.d	x8, v24[1]
	fmov	x11, d24
	st1.s	{ v23 }[2], [x11]
	add.2d	v24, v0, v13
	st1.s	{ v23 }[3], [x8]
	mov.d	x8, v24[1]
	fmov	x11, d24
	str	s22, [x11]
	st1.s	{ v22 }[1], [x8]
	mov.d	x8, v14[1]
	fmov	x11, d14
	st1.s	{ v22 }[2], [x11]
	st1.s	{ v22 }[3], [x8]
	dup.2d	v22, x26
	add.2d	v21, v21, v22
	add.2d	v20, v20, v22
	add.2d	v11, v11, v22
	add.2d	v6, v6, v22
	fmov	x11, d6
	cmp	x11, #8
	b.lt	LBB0_19
; %bb.20:                               ; %direct.false86.i99.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	q6, [sp, #480]                  ; 16-byte Folded Reload
	fmul.4s	v6, v6, v6
	fadd.4s	v6, v6, v2
	mov.s	v2[0], v6[0]
	fadd.4s	v5, v9, v5
	fadd.4s	v2, v8, v2
	fadd.4s	v2, v10, v2
	fadd.4s	v5, v7, v5
	fadd.4s	v5, v17, v5
	fadd.4s	v2, v16, v2
	rev64.4s	v6, v2
	rev64.4s	v7, v5
	fadd.4s	v5, v5, v7
	fadd.4s	v2, v2, v6
	dup.4s	v6, v2[2]
	dup.4s	v7, v5[2]
	fadd.4s	v5, v5, v7
	fadd.4s	v2, v2, v6
	fadd.4s	v2, v2, v5
	movi	d5, #0000000000000000
	fadd	s5, s2, s5
	mov	w8, #1115815936                 ; =0x42820000
	fmov	s6, w8
	ldr	q2, [sp, #1648]
	ldr	x8, [sp, #496]                  ; 8-byte Folded Reload
	ld1.s	{ v2 }[0], [x8]
	fdiv	s5, s5, s6
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s6, w8
	fadd	s5, s5, s6
	fsqrt	s5, s5
	dup.4s	v6, v5[0]
	str	q2, [sp, #1648]
	add	x10, x12, x10
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB0_21:                                ; %direct.true109.i107.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v20, #5
	shl.2d	v22, v17, #5
	shl.2d	v23, v16, #5
	shl.2d	v24, v7, #5
	orr.16b	v24, v24, v3
	orr.16b	v23, v23, v4
	orr.16b	v22, v22, v18
	orr.16b	v21, v21, v19
	add.2d	v8, v1, v21
	add.2d	v9, v1, v22
	add.2d	v10, v1, v23
	add.2d	v11, v1, v24
	mov.d	x8, v11[1]
	mov.d	x14, v10[1]
	mov.d	x0, v9[1]
	fmov	x2, d11
	fmov	x27, d9
	mov.d	x28, v8[1]
	fmov	x30, d8
	ldr	s8, [x27]
	ld1.s	{ v8 }[1], [x0]
	ld1.s	{ v8 }[2], [x30]
	ld1.s	{ v8 }[3], [x28]
	fmov	x0, d10
	ldr	s9, [x2]
	ld1.s	{ v9 }[1], [x8]
	ld1.s	{ v9 }[2], [x0]
	ld1.s	{ v9 }[3], [x14]
	fdiv.4s	v9, v9, v6
	fdiv.4s	v8, v8, v6
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v24, v0, v24
	mov.d	x8, v24[1]
	fmov	x14, d24
	mov.d	x0, v23[1]
	mov.d	x2, v22[1]
	mov.d	x27, v21[1]
	fmov	x28, d23
	ldr	s23, [x14]
	ld1.s	{ v23 }[1], [x8]
	ld1.s	{ v23 }[2], [x28]
	fmov	x8, d22
	ld1.s	{ v23 }[3], [x0]
	ldr	s22, [x8]
	ld1.s	{ v22 }[1], [x2]
	fmov	x8, d21
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x27]
	fmul.4s	v21, v8, v22
	fmul.4s	v22, v9, v23
	add	x8, x10, x11, lsl #5
	stp	q22, q21, [x8]
	dup.2d	v21, x26
	add.2d	v17, v17, v21
	add.2d	v16, v16, v21
	add.2d	v20, v20, v21
	add.2d	v7, v7, v21
	fmov	x11, d7
	cmp	x11, #8
	b.lt	LBB0_21
; %bb.22:                               ; %llm_rows.full_packet.exit112.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q6, [sp, #1936]
	fdiv.4s	v5, v6, v5
	fmul.4s	v2, v2, v5
	str	s2, [x12, x9]
	ldr	w8, [sp, #512]                  ; 4-byte Folded Reload
	orr	w8, w8, #0x3
	mov	w9, #260                        ; =0x104
	umull	x10, w8, w9
	umaddl	x8, w8, w9, x3
	ldp	q2, q5, [x8]
	str	q5, [sp, #1696]
	str	q2, [sp, #1680]
	ldp	q6, q7, [x8, #32]
	str	q7, [sp, #1728]
	str	q6, [sp, #1712]
	ldp	q16, q20, [x8, #64]
	str	q20, [sp, #1760]
	str	q16, [sp, #1744]
	ldp	q21, q22, [x8, #96]
	str	q22, [sp, #1792]
	str	q21, [sp, #1776]
	ldp	q17, q23, [x8, #128]
	str	q23, [sp, #1824]
	str	q17, [sp, #1808]
	ldp	q17, q23, [x8, #160]
	str	q23, [sp, #1856]
	str	q17, [sp, #1840]
	ldp	q17, q23, [x8, #192]
	str	q23, [sp, #1888]
	str	q17, [sp, #1872]
	ldp	q17, q23, [x8, #224]
	str	q23, [sp, #1920]
	str	q17, [sp, #1904]
	add	x9, x10, #256
	ldr	s17, [x3, x9]
	str	q17, [sp, #512]                 ; 16-byte Folded Spill
	str	q17, [sp, #1936]
	fmul.4s	v5, v5, v5
	fmul.4s	v2, v2, v2
	fmul.4s	v8, v7, v7
	fmul.4s	v17, v6, v6
	fmul.4s	v6, v20, v20
	fmul.4s	v9, v16, v16
	fmul.4s	v16, v22, v22
	fmul.4s	v7, v21, v21
	dup.2d	v11, x15
	mov.16b	v12, v11
	mov.16b	v13, v11
	mov.16b	v14, v11
	ldp	q31, q30, [sp, #624]            ; 32-byte Folded Reload
	ldp	q26, q25, [sp, #576]            ; 32-byte Folded Reload
	ldp	q28, q27, [sp, #544]            ; 32-byte Folded Reload
	ldr	q29, [sp, #528]                 ; 16-byte Folded Reload
LBB0_23:                                ; %direct.true57.i143.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v20, v11, #5
	shl.2d	v21, v12, #5
	shl.2d	v22, v13, #5
	shl.2d	v23, v14, #5
	add.2d	v15, v1, v23
	add.2d	v23, v15, v19
	add.2d	v20, v1, v20
	add.2d	v24, v20, v3
	mov.d	x8, v24[1]
	add.2d	v10, v1, v22
	add.2d	v21, v1, v21
	fmov	x11, d24
	add.2d	v22, v21, v4
	mov.d	x14, v22[1]
	fmov	x0, d22
	add.2d	v22, v10, v18
	mov.d	x2, v22[1]
	fmov	x3, d22
	mov.d	x27, v23[1]
	ldr	s22, [x11]
	ld1.s	{ v22 }[1], [x8]
	fmov	x8, d23
	ld1.s	{ v22 }[2], [x0]
	ld1.s	{ v22 }[3], [x14]
	ldr	s23, [x3]
	ld1.s	{ v23 }[1], [x2]
	ld1.s	{ v23 }[2], [x8]
	ld1.s	{ v23 }[3], [x27]
	fmul.4s	v23, v23, v23
	fmul.4s	v22, v22, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v5, v5, v23
	ldr	q22, [sp, #672]                 ; 16-byte Folded Reload
	add.2d	v22, v15, v22
	ldr	q23, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v23, v20, v23
	mov.d	x8, v23[1]
	fmov	x11, d23
	ldr	q23, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v23, v21, v23
	mov.d	x14, v23[1]
	fmov	x0, d23
	ldr	q23, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v23, v10, v23
	mov.d	x2, v23[1]
	mov.d	x3, v22[1]
	fmov	x27, d23
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x8]
	ld1.s	{ v23 }[2], [x0]
	fmov	x8, d22
	ld1.s	{ v23 }[3], [x14]
	ldr	s22, [x27]
	ld1.s	{ v22 }[1], [x2]
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x3]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	fadd.4s	v17, v17, v23
	fadd.4s	v8, v8, v22
	add.2d	v22, v15, v25
	ldr	q23, [sp, #656]                 ; 16-byte Folded Reload
	add.2d	v23, v20, v23
	mov.d	x8, v23[1]
	fmov	x11, d23
	add.2d	v23, v21, v30
	mov.d	x14, v23[1]
	fmov	x0, d23
	add.2d	v23, v10, v31
	mov.d	x2, v23[1]
	fmov	x3, d23
	mov.d	x27, v22[1]
	ldr	s23, [x11]
	ld1.s	{ v23 }[1], [x8]
	ld1.s	{ v23 }[2], [x0]
	ld1.s	{ v23 }[3], [x14]
	fmov	x8, d22
	fmul.4s	v22, v23, v23
	fadd.4s	v9, v9, v22
	ldr	s22, [x3]
	ld1.s	{ v22 }[1], [x2]
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x27]
	fmul.4s	v22, v22, v22
	fadd.4s	v6, v6, v22
	add.2d	v21, v21, v27
	add.2d	v20, v20, v26
	mov.d	x8, v20[1]
	mov.d	x11, v21[1]
	fmov	x14, d20
	fmov	x0, d21
	add.2d	v20, v15, v29
	add.2d	v21, v10, v28
	mov.d	x2, v21[1]
	fmov	x3, d21
	mov.d	x27, v20[1]
	ldr	s21, [x14]
	ld1.s	{ v21 }[1], [x8]
	fmov	x8, d20
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x11]
	fmul.4s	v20, v21, v21
	fadd.4s	v7, v7, v20
	ldr	s20, [x3]
	ld1.s	{ v20 }[1], [x2]
	ld1.s	{ v20 }[2], [x8]
	ld1.s	{ v20 }[3], [x27]
	fmul.4s	v20, v20, v20
	fadd.4s	v16, v16, v20
	dup.2d	v20, x15
	add.2d	v13, v13, v20
	add.2d	v12, v12, v20
	add.2d	v14, v14, v20
	add.2d	v11, v11, v20
	fmov	x8, d11
	cmp	x8, #8
	b.lt	LBB0_23
; %bb.24:                               ; %direct.true85.i150.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
LBB0_25:                                ; %direct.true85.i150.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x8, x13, x11, lsl #5
	ldp	q25, q24, [x8]
	shl.2d	v26, v20, #5
	shl.2d	v27, v21, #5
	shl.2d	v28, v22, #5
	shl.2d	v29, v23, #5
	add.2d	v29, v29, v19
	add.2d	v29, v0, v29
	add.2d	v28, v28, v18
	add.2d	v27, v27, v4
	add.2d	v26, v26, v3
	add.2d	v26, v0, v26
	mov.d	x8, v26[1]
	fmov	x11, d26
	str	s25, [x11]
	st1.s	{ v25 }[1], [x8]
	add.2d	v26, v0, v27
	mov.d	x8, v26[1]
	fmov	x11, d26
	st1.s	{ v25 }[2], [x11]
	add.2d	v26, v0, v28
	st1.s	{ v25 }[3], [x8]
	mov.d	x8, v26[1]
	fmov	x11, d26
	str	s24, [x11]
	st1.s	{ v24 }[1], [x8]
	mov.d	x8, v29[1]
	fmov	x11, d29
	st1.s	{ v24 }[2], [x11]
	st1.s	{ v24 }[3], [x8]
	dup.2d	v24, x26
	add.2d	v22, v22, v24
	add.2d	v21, v21, v24
	add.2d	v23, v23, v24
	add.2d	v20, v20, v24
	fmov	x11, d20
	cmp	x11, #8
	b.lt	LBB0_25
; %bb.26:                               ; %direct.false86.i154.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	q20, [sp, #512]                 ; 16-byte Folded Reload
	fmul.4s	v20, v20, v20
	fadd.4s	v20, v20, v2
	mov.s	v2[0], v20[0]
	ldr	q20, [sp, #1648]
	ldr	x8, [sp, #496]                  ; 8-byte Folded Reload
	ld1.s	{ v20 }[0], [x8]
	fadd.4s	v5, v8, v5
	fadd.4s	v2, v17, v2
	fadd.4s	v2, v9, v2
	fadd.4s	v5, v6, v5
	fadd.4s	v5, v16, v5
	fadd.4s	v2, v7, v2
	rev64.4s	v6, v2
	rev64.4s	v7, v5
	fadd.4s	v5, v5, v7
	fadd.4s	v2, v2, v6
	dup.4s	v6, v2[2]
	dup.4s	v7, v5[2]
	fadd.4s	v5, v5, v7
	fadd.4s	v2, v2, v6
	fadd.4s	v2, v2, v5
	movi	d12, #0000000000000000
	fadd	s2, s2, s12
	mov	w8, #1115815936                 ; =0x42820000
	fmov	s5, w8
	fdiv	s2, s2, s5
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s5, w8
	fadd	s2, s2, s5
	fsqrt	s2, s2
	dup.4s	v5, v2[0]
	str	q20, [sp, #1648]
	add	x10, x12, x10
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB0_27:                                ; %direct.true109.i162.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v21, v17, #5
	shl.2d	v22, v16, #5
	shl.2d	v23, v7, #5
	shl.2d	v24, v6, #5
	orr.16b	v24, v24, v3
	orr.16b	v23, v23, v4
	orr.16b	v22, v22, v18
	orr.16b	v21, v21, v19
	add.2d	v25, v1, v21
	add.2d	v26, v1, v22
	add.2d	v27, v1, v23
	add.2d	v28, v1, v24
	mov.d	x8, v28[1]
	mov.d	x13, v27[1]
	mov.d	x14, v26[1]
	fmov	x0, d28
	fmov	x2, d26
	mov.d	x3, v25[1]
	fmov	x27, d25
	ldr	s25, [x2]
	ld1.s	{ v25 }[1], [x14]
	ld1.s	{ v25 }[2], [x27]
	ld1.s	{ v25 }[3], [x3]
	fmov	x14, d27
	ldr	s26, [x0]
	ld1.s	{ v26 }[1], [x8]
	ld1.s	{ v26 }[2], [x14]
	ld1.s	{ v26 }[3], [x13]
	fdiv.4s	v26, v26, v5
	fdiv.4s	v25, v25, v5
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v24, v0, v24
	mov.d	x8, v24[1]
	fmov	x13, d24
	mov.d	x14, v23[1]
	mov.d	x0, v22[1]
	mov.d	x2, v21[1]
	fmov	x3, d23
	ldr	s23, [x13]
	ld1.s	{ v23 }[1], [x8]
	ld1.s	{ v23 }[2], [x3]
	fmov	x8, d22
	ld1.s	{ v23 }[3], [x14]
	ldr	s22, [x8]
	ld1.s	{ v22 }[1], [x0]
	fmov	x8, d21
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x2]
	fmul.4s	v21, v25, v22
	fmul.4s	v22, v26, v23
	add	x8, x10, x11, lsl #5
	stp	q22, q21, [x8]
	dup.2d	v21, x26
	add.2d	v16, v16, v21
	add.2d	v7, v7, v21
	add.2d	v17, v17, v21
	add.2d	v6, v6, v21
	fmov	x11, d6
	cmp	x11, #8
	b.lt	LBB0_27
; %bb.28:                               ; %llm_rows.full_packet.exit167.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q5, [sp, #1936]
	fdiv.4s	v2, v5, v2
	fmul.4s	v2, v20, v2
	str	s2, [x12, x9]
	ldr	w12, [sp, #372]                 ; 4-byte Folded Reload
	ldr	w13, [sp, #368]                 ; 4-byte Folded Reload
	ldr	w14, [sp, #364]                 ; 4-byte Folded Reload
	ldr	x0, [sp, #376]                  ; 8-byte Folded Reload
	b	LBB0_2
LBB0_29:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	lsr	x8, x9, #3
	str	x8, [sp, #720]                  ; 8-byte Folded Spill
	str	x9, [sp, #672]                  ; 8-byte Folded Spill
	cmp	x9, #8
	b.lo	LBB0_38
; %bb.30:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x2, #0                          ; =0x0
	ldr	x8, [sp, #336]                  ; 8-byte Folded Reload
	ldr	x3, [x8]
	ldr	x30, [x8, #16]
	ldr	x9, [x8, #48]
	add	x8, x30, #256
	str	x8, [sp, #704]                  ; 8-byte Folded Spill
	ldr	x8, [sp, #376]                  ; 8-byte Folded Reload
	lsl	w8, w8, #2
	str	x8, [sp, #688]                  ; 8-byte Folded Spill
LBB0_31:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_32 Depth 3
                                        ;       Child Loop BB0_34 Depth 3
                                        ;       Child Loop BB0_36 Depth 3
	ldr	x8, [sp, #688]                  ; 8-byte Folded Reload
	add	w8, w2, w8
	and	x8, x8, #0x1fffffff
	add	x8, x8, x8, lsl #6
	lsl	x11, x8, #2
	add	x8, x3, x11
	ldp	q2, q5, [x8]
	str	q5, [sp, #1696]
	str	q2, [sp, #1680]
	ldp	q17, q18, [x8, #32]
	str	q18, [sp, #1728]
	str	q17, [sp, #1712]
	ldp	q19, q22, [x8, #64]
	str	q22, [sp, #1760]
	str	q19, [sp, #1744]
	ldp	q23, q24, [x8, #96]
	str	q24, [sp, #1792]
	str	q23, [sp, #1776]
	ldp	q6, q7, [x8, #128]
	str	q7, [sp, #1824]
	str	q6, [sp, #1808]
	ldp	q6, q7, [x8, #160]
	str	q7, [sp, #1856]
	str	q6, [sp, #1840]
	ldp	q6, q7, [x8, #192]
	str	q7, [sp, #1888]
	str	q6, [sp, #1872]
	ldp	q6, q7, [x8, #224]
	str	q7, [sp, #1920]
	str	q6, [sp, #1904]
	add	x0, x11, #256
	ldr	s16, [x3, x0]
	str	q16, [sp, #1936]
	fmul.4s	v7, v5, v5
	fmul.4s	v6, v2, v2
	fmul.4s	v21, v18, v18
	fmul.4s	v20, v17, v17
	fmul.4s	v17, v22, v22
	fmul.4s	v22, v19, v19
	fmul.4s	v19, v24, v24
	fmul.4s	v18, v23, v23
	dup.2d	v23, x15
	mov.16b	v24, v23
	mov.16b	v25, v23
	mov.16b	v26, v23
LBB0_32:                                ; %direct.true57.i198.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_31 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.2d	v2, v23, #5
	add.2d	v27, v1, v2
	add.2d	v31, v27, v3
	mov.d	x8, v31[1]
	shl.2d	v2, v24, #5
	add.2d	v28, v1, v2
	add.2d	v8, v28, v4
	mov.d	x27, v8[1]
	ldr	q2, [x16, lCPI0_2@PAGEOFF]
	shl.2d	v5, v25, #5
	add.2d	v29, v1, v5
	add.2d	v9, v29, v2
	mov.d	x28, v9[1]
	ldr	q5, [x17, lCPI0_3@PAGEOFF]
	shl.2d	v30, v26, #5
	add.2d	v30, v1, v30
	add.2d	v10, v30, v5
	mov.d	x13, v10[1]
	fmov	x12, d31
	ldr	s31, [x12]
	fmov	x12, d8
	fmov	x14, d9
	ld1.s	{ v31 }[1], [x8]
	fmov	x8, d10
	ld1.s	{ v31 }[2], [x12]
	ld1.s	{ v31 }[3], [x27]
	ldr	s8, [x14]
	ld1.s	{ v8 }[1], [x28]
	ld1.s	{ v8 }[2], [x8]
	ld1.s	{ v8 }[3], [x13]
	fmul.4s	v8, v8, v8
	fmul.4s	v31, v31, v31
	fadd.4s	v6, v6, v31
	fadd.4s	v7, v7, v8
	ldr	q31, [x1, lCPI0_4@PAGEOFF]
	ldr	q8, [x4, lCPI0_5@PAGEOFF]
	ldr	q9, [x5, lCPI0_6@PAGEOFF]
	ldr	q10, [x6, lCPI0_7@PAGEOFF]
	add.2d	v10, v30, v10
	add.2d	v9, v29, v9
	add.2d	v8, v28, v8
	add.2d	v31, v27, v31
	mov.d	x8, v31[1]
	fmov	x12, d31
	mov.d	x13, v8[1]
	fmov	x14, d8
	mov.d	x27, v9[1]
	fmov	x28, d9
	mov.d	x10, v10[1]
	ldr	s31, [x12]
	ld1.s	{ v31 }[1], [x8]
	ld1.s	{ v31 }[2], [x14]
	ld1.s	{ v31 }[3], [x13]
	fmov	x8, d10
	ldr	s8, [x28]
	ld1.s	{ v8 }[1], [x27]
	ld1.s	{ v8 }[2], [x8]
	ld1.s	{ v8 }[3], [x10]
	fmul.4s	v8, v8, v8
	fmul.4s	v31, v31, v31
	fadd.4s	v20, v20, v31
	fadd.4s	v21, v21, v8
	ldr	q31, [x7, lCPI0_8@PAGEOFF]
	ldr	q8, [x19, lCPI0_9@PAGEOFF]
	ldr	q9, [x20, lCPI0_10@PAGEOFF]
	ldr	q10, [x21, lCPI0_11@PAGEOFF]
	add.2d	v10, v30, v10
	add.2d	v9, v29, v9
	add.2d	v8, v28, v8
	add.2d	v31, v27, v31
	mov.d	x8, v31[1]
	mov.d	x10, v8[1]
	fmov	x12, d31
	fmov	x13, d8
	mov.d	x14, v9[1]
	mov.d	x27, v10[1]
	fmov	x28, d9
	ldr	s31, [x12]
	ld1.s	{ v31 }[1], [x8]
	ld1.s	{ v31 }[2], [x13]
	fmov	x8, d10
	ld1.s	{ v31 }[3], [x10]
	ldr	s8, [x28]
	ld1.s	{ v8 }[1], [x14]
	ld1.s	{ v8 }[2], [x8]
	ld1.s	{ v8 }[3], [x27]
	fmul.4s	v8, v8, v8
	fmul.4s	v31, v31, v31
	fadd.4s	v22, v22, v31
	fadd.4s	v17, v17, v8
	ldr	q31, [x22, lCPI0_12@PAGEOFF]
	ldr	q8, [x23, lCPI0_13@PAGEOFF]
	ldr	q9, [x24, lCPI0_14@PAGEOFF]
	ldr	q10, [x25, lCPI0_15@PAGEOFF]
	add.2d	v30, v30, v10
	add.2d	v29, v29, v9
	add.2d	v28, v28, v8
	add.2d	v27, v27, v31
	mov.d	x8, v27[1]
	fmov	x10, d27
	mov.d	x12, v28[1]
	fmov	x13, d28
	mov.d	x14, v29[1]
	fmov	x27, d29
	mov.d	x28, v30[1]
	ldr	s27, [x10]
	ld1.s	{ v27 }[1], [x8]
	fmov	x8, d30
	ld1.s	{ v27 }[2], [x13]
	ld1.s	{ v27 }[3], [x12]
	ldr	s28, [x27]
	ld1.s	{ v28 }[1], [x14]
	ld1.s	{ v28 }[2], [x8]
	ld1.s	{ v28 }[3], [x28]
	fmul.4s	v28, v28, v28
	fmul.4s	v27, v27, v27
	fadd.4s	v18, v18, v27
	fadd.4s	v19, v19, v28
	dup.2d	v27, x15
	add.2d	v25, v25, v27
	add.2d	v24, v24, v27
	add.2d	v26, v26, v27
	add.2d	v23, v23, v27
	fmov	x8, d23
	cmp	x8, #8
	b.lt	LBB0_32
; %bb.33:                               ; %direct.true85.i205.i.preheader
                                        ;   in Loop: Header=BB0_31 Depth=2
	mov	x27, #0                         ; =0x0
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
LBB0_34:                                ; %direct.true85.i205.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_31 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x8, x30, x27, lsl #5
	ldp	q28, q27, [x8]
	shl.2d	v29, v23, #5
	shl.2d	v30, v24, #5
	shl.2d	v31, v25, #5
	shl.2d	v8, v26, #5
	add.2d	v8, v8, v5
	add.2d	v8, v0, v8
	add.2d	v31, v31, v2
	add.2d	v30, v30, v4
	add.2d	v29, v29, v3
	add.2d	v29, v0, v29
	mov.d	x8, v29[1]
	fmov	x10, d29
	str	s28, [x10]
	st1.s	{ v28 }[1], [x8]
	add.2d	v29, v0, v30
	mov.d	x8, v29[1]
	fmov	x10, d29
	st1.s	{ v28 }[2], [x10]
	add.2d	v29, v0, v31
	st1.s	{ v28 }[3], [x8]
	mov.d	x8, v29[1]
	fmov	x10, d29
	str	s27, [x10]
	st1.s	{ v27 }[1], [x8]
	mov.d	x8, v8[1]
	fmov	x10, d8
	st1.s	{ v27 }[2], [x10]
	st1.s	{ v27 }[3], [x8]
	dup.2d	v27, x26
	add.2d	v25, v25, v27
	add.2d	v24, v24, v27
	add.2d	v26, v26, v27
	add.2d	v23, v23, v27
	fmov	x27, d23
	cmp	x27, #8
	b.lt	LBB0_34
; %bb.35:                               ; %direct.false86.i209.i
                                        ;   in Loop: Header=BB0_31 Depth=2
	mov	x27, #0                         ; =0x0
	fmul.4s	v16, v16, v16
	fadd.4s	v16, v16, v6
	mov.s	v6[0], v16[0]
	fadd.4s	v7, v21, v7
	fadd.4s	v6, v20, v6
	fadd.4s	v6, v22, v6
	fadd.4s	v7, v17, v7
	fadd.4s	v7, v19, v7
	fadd.4s	v6, v18, v6
	rev64.4s	v16, v6
	rev64.4s	v17, v7
	fadd.4s	v7, v7, v17
	fadd.4s	v6, v6, v16
	dup.4s	v16, v6[2]
	dup.4s	v17, v7[2]
	fadd.4s	v7, v7, v17
	fadd.4s	v6, v6, v16
	fadd.4s	v6, v6, v7
	fadd	s7, s6, s12
	mov	w8, #1115815936                 ; =0x42820000
	fmov	s16, w8
	ldr	q6, [sp, #1648]
	ldr	x8, [sp, #704]                  ; 8-byte Folded Reload
	ld1.s	{ v6 }[0], [x8]
	fdiv	s7, s7, s16
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s16, w8
	fadd	s7, s7, s16
	fsqrt	s7, s7
	dup.4s	v16, v7[0]
	str	q6, [sp, #1648]
	add	x11, x9, x11
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB0_36:                                ; %direct.true109.i217.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_31 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	shl.2d	v21, v20, #5
	shl.2d	v22, v19, #5
	shl.2d	v23, v18, #5
	shl.2d	v24, v17, #5
	orr.16b	v24, v24, v3
	orr.16b	v23, v23, v4
	orr.16b	v22, v22, v2
	orr.16b	v21, v21, v5
	add.2d	v25, v1, v21
	add.2d	v26, v1, v22
	add.2d	v27, v1, v23
	add.2d	v28, v1, v24
	mov.d	x8, v28[1]
	mov.d	x10, v27[1]
	mov.d	x12, v26[1]
	fmov	x13, d28
	fmov	x14, d26
	mov.d	x28, v25[1]
	fmov	x1, d25
	ldr	s25, [x14]
	ld1.s	{ v25 }[1], [x12]
	ld1.s	{ v25 }[2], [x1]
	ld1.s	{ v25 }[3], [x28]
	fmov	x12, d27
	ldr	s26, [x13]
	ld1.s	{ v26 }[1], [x8]
	ld1.s	{ v26 }[2], [x12]
	ld1.s	{ v26 }[3], [x10]
	fdiv.4s	v26, v26, v16
	fdiv.4s	v25, v25, v16
	add.2d	v21, v0, v21
	add.2d	v22, v0, v22
	add.2d	v23, v0, v23
	add.2d	v24, v0, v24
	mov.d	x8, v24[1]
	fmov	x10, d24
	mov.d	x12, v23[1]
	mov.d	x13, v22[1]
	mov.d	x14, v21[1]
	fmov	x1, d23
	ldr	s23, [x10]
	ld1.s	{ v23 }[1], [x8]
	ld1.s	{ v23 }[2], [x1]
	fmov	x8, d22
	ld1.s	{ v23 }[3], [x12]
	ldr	s22, [x8]
	ld1.s	{ v22 }[1], [x13]
	fmov	x8, d21
	ld1.s	{ v22 }[2], [x8]
	ld1.s	{ v22 }[3], [x14]
	fmul.4s	v21, v25, v22
	fmul.4s	v22, v26, v23
	add	x8, x11, x27, lsl #5
	stp	q22, q21, [x8]
	dup.2d	v21, x26
	add.2d	v19, v19, v21
	add.2d	v18, v18, v21
	add.2d	v20, v20, v21
	add.2d	v17, v17, v21
	fmov	x27, d17
	cmp	x27, #8
	b.lt	LBB0_36
; %bb.37:                               ; %llm_rows.full_packet.exit222.i
                                        ;   in Loop: Header=BB0_31 Depth=2
	ldr	q2, [sp, #1936]
	fdiv.4s	v2, v2, v7
	fmul.4s	v2, v6, v2
	str	s2, [x9, x0]
	add	x2, x2, #1
	ldr	x8, [sp, #720]                  ; 8-byte Folded Reload
	cmp	x2, x8
	adrp	x1, lCPI0_4@PAGE
	b.ne	LBB0_31
LBB0_38:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #672]                  ; 8-byte Folded Reload
	and	w9, w8, #0x7
	ldr	w12, [sp, #372]                 ; 4-byte Folded Reload
	ldr	w13, [sp, #368]                 ; 4-byte Folded Reload
	ldr	w14, [sp, #364]                 ; 4-byte Folded Reload
	ldr	x0, [sp, #376]                  ; 8-byte Folded Reload
	cbz	w9, LBB0_2
; %bb.39:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v2, w9
Lloh4:
	adrp	x8, lCPI0_17@PAGE
Lloh5:
	ldr	q5, [x8, lCPI0_17@PAGEOFF]
Lloh6:
	adrp	x8, lCPI0_18@PAGE
Lloh7:
	ldr	q6, [x8, lCPI0_18@PAGEOFF]
	cmhi.4s	v10, v2, v6
	cmhi.4s	v2, v2, v5
	uzp1.8h	v6, v2, v10
	umaxv.8h	h5, v6
	fmov	w8, s5
	tbz	w8, #0, LBB0_2
; %bb.40:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x10, #0                         ; =0x0
	ldr	x8, [sp, #336]                  ; 8-byte Folded Reload
	ldr	x9, [x8]
	ldr	x3, [x8, #16]
	ldr	x1, [x8, #48]
Lloh8:
	adrp	x8, lCPI0_16@PAGE
Lloh9:
	ldr	q5, [x8, lCPI0_16@PAGEOFF]
	str	q6, [sp, #144]                  ; 16-byte Folded Spill
	and.16b	v5, v6, v5
	addv.8h	h18, v5
	ubfiz	w8, w0, #2, #27
	ldr	x11, [sp, #720]                 ; 8-byte Folded Reload
	orr	w8, w8, w11
	fmov	w11, s18
	and	w11, w11, #0xff
	str	w11, [sp, #228]                 ; 4-byte Folded Spill
	dup.4s	v5, w8
	and.16b	v16, v2, v5
	and.16b	v7, v10, v5
	ushll2.2d	v5, v7, #0
	ushll2.2d	v6, v16, #0
	ushll.2d	v7, v7, #0
	ushll.2d	v17, v16, #0
	fmov	x8, d17
	mov	w11, #260                       ; =0x104
	umaddl	x11, w8, w11, x9
	add	x14, sp, #1680
	b	LBB0_42
LBB0_41:                                ; %else936
                                        ;   in Loop: Header=BB0_42 Depth=2
	add	x8, x14, x10
	ldp	q20, q21, [x8]
	bif.16b	v19, v21, v10
	bif.16b	v16, v20, v2
	stp	q16, q19, [x8]
	add	x10, x10, #32
	cmp	x10, #256
	b.eq	LBB0_58
LBB0_42:                                ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s18
	add	x12, x11, x10
	movi.2d	v16, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w13, #0, LBB0_50
; %bb.43:                               ; %else
                                        ;   in Loop: Header=BB0_42 Depth=2
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_51
LBB0_44:                                ; %else918
                                        ;   in Loop: Header=BB0_42 Depth=2
	tbnz	w13, #2, LBB0_52
LBB0_45:                                ; %else921
                                        ;   in Loop: Header=BB0_42 Depth=2
	tbnz	w13, #3, LBB0_53
LBB0_46:                                ; %else924
                                        ;   in Loop: Header=BB0_42 Depth=2
	tbnz	w13, #4, LBB0_54
LBB0_47:                                ; %else927
                                        ;   in Loop: Header=BB0_42 Depth=2
	tbnz	w13, #5, LBB0_55
LBB0_48:                                ; %else930
                                        ;   in Loop: Header=BB0_42 Depth=2
	tbnz	w13, #6, LBB0_56
LBB0_49:                                ; %else933
                                        ;   in Loop: Header=BB0_42 Depth=2
	tbz	w13, #7, LBB0_41
	b	LBB0_57
LBB0_50:                                ; %cond.load
                                        ;   in Loop: Header=BB0_42 Depth=2
	ldr	s16, [x12]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_44
LBB0_51:                                ; %cond.load917
                                        ;   in Loop: Header=BB0_42 Depth=2
	add	x8, x12, #4
	ld1.s	{ v16 }[1], [x8]
	tbz	w13, #2, LBB0_45
LBB0_52:                                ; %cond.load920
                                        ;   in Loop: Header=BB0_42 Depth=2
	add	x8, x12, #8
	ld1.s	{ v16 }[2], [x8]
	tbz	w13, #3, LBB0_46
LBB0_53:                                ; %cond.load923
                                        ;   in Loop: Header=BB0_42 Depth=2
	add	x8, x12, #12
	ld1.s	{ v16 }[3], [x8]
	tbz	w13, #4, LBB0_47
LBB0_54:                                ; %cond.load926
                                        ;   in Loop: Header=BB0_42 Depth=2
	add	x8, x12, #16
	ld1.s	{ v19 }[0], [x8]
	tbz	w13, #5, LBB0_48
LBB0_55:                                ; %cond.load929
                                        ;   in Loop: Header=BB0_42 Depth=2
	add	x8, x12, #20
	ld1.s	{ v19 }[1], [x8]
	tbz	w13, #6, LBB0_49
LBB0_56:                                ; %cond.load932
                                        ;   in Loop: Header=BB0_42 Depth=2
	add	x8, x12, #24
	ld1.s	{ v19 }[2], [x8]
	tbz	w13, #7, LBB0_41
LBB0_57:                                ; %cond.load935
                                        ;   in Loop: Header=BB0_42 Depth=2
	add	x8, x12, #28
	ld1.s	{ v19 }[3], [x8]
	b	LBB0_41
LBB0_58:                                ; %direct.true57.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	xtn.4h	v16, v2
	uzp1.8b	v20, v16, v0
	sshll.2d	v16, v2, #0
Lloh10:
	adrp	x8, lCPI0_22@PAGE
Lloh11:
	ldr	q19, [x8, lCPI0_22@PAGEOFF]
	and.16b	v21, v16, v19
	movi.2d	v22, #0000000000000000
	mov.b	v22[0], v20[0]
Lloh12:
	adrp	x8, lCPI0_23@PAGE
Lloh13:
	ldr	d19, [x8, lCPI0_23@PAGEOFF]
	str	d19, [sp, #184]                 ; 8-byte Folded Spill
	and.8b	v19, v22, v19
	addv.8b	b19, v19
	fmov	w10, s19
	umaxv.8b	b19, v22
	fmov	w8, s19
	rbit	w11, w10
	clz	w11, w11
	tst	w8, #0x1
	csel	w13, w11, wzr, ne
	mov	w11, #64                        ; =0x40
	dup.2d	v19, x11
	str	q21, [sp, #96]                  ; 16-byte Folded Spill
	orr.16b	v23, v21, v19
	xtn.2s	v17, v17
	str	q23, [sp, #192]                 ; 16-byte Folded Spill
	movi.2s	v21, #65
	umlal.2d	v23, v17, v21
	movi.2d	v21, #0000000000000000
	mov.b	v21[0], v20[0]
	ushll.2d	v20, v21, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	str	q23, [sp, #288]                 ; 16-byte Folded Spill
	and.16b	v20, v20, v23
	movi.2d	v21, #0000000000000000
	str	q21, [sp, #1360]
	str	q21, [sp, #1344]
	str	q21, [sp, #1328]
	str	q20, [sp, #1312]
	and	x11, x13, #0x7
	add	x12, sp, #1312
	ldr	x11, [x12, x11, lsl #3]
	sub	x11, x11, x13
	add	x9, x9, x11, lsl #2
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w8, #0, LBB0_235
; %bb.59:                               ; %else940
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #1, LBB0_236
LBB0_60:                                ; %else943
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #2, LBB0_237
LBB0_61:                                ; %else946
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #3, LBB0_238
LBB0_62:                                ; %else949
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #4, LBB0_239
LBB0_63:                                ; %else952
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #5, LBB0_240
LBB0_64:                                ; %else955
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #6, LBB0_241
LBB0_65:                                ; %else958
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w10, #7, LBB0_67
LBB0_66:                                ; %cond.load960
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #28
	ld1.s	{ v28 }[3], [x8]
LBB0_67:                                ; %else961
                                        ;   in Loop: Header=BB0_3 Depth=1
	sshll.2d	v20, v10, #0
	sshll2.2d	v30, v2, #0
	sshll2.2d	v31, v10, #0
Lloh14:
	adrp	x8, lCPI0_19@PAGE
Lloh15:
	ldr	q21, [x8, lCPI0_19@PAGEOFF]
	and.16b	v29, v31, v21
Lloh16:
	adrp	x8, lCPI0_20@PAGE
Lloh17:
	ldr	q21, [x8, lCPI0_20@PAGEOFF]
	and.16b	v26, v30, v21
Lloh18:
	adrp	x8, lCPI0_21@PAGE
Lloh19:
	ldr	q21, [x8, lCPI0_21@PAGEOFF]
	and.16b	v25, v20, v21
	and.16b	v23, v20, v1
	and.16b	v21, v16, v1
	stp	q21, q23, [sp, #704]            ; 32-byte Folded Spill
	ldr	q21, [x17, lCPI0_3@PAGEOFF]
	and.16b	v23, v31, v21
	and.16b	v24, v30, v4
	ldr	q21, [x16, lCPI0_2@PAGEOFF]
	and.16b	v20, v20, v21
	and.16b	v21, v16, v3
	stp	q25, q26, [sp, #16]             ; 32-byte Folded Spill
	orr.16b	v25, v25, v19
	orr.16b	v26, v26, v19
	str	q29, [sp, #48]                  ; 16-byte Folded Spill
	orr.16b	v19, v29, v19
	movi.2s	v16, #65
	umull.2d	v17, v17, v16
	str	q17, [sp, #208]                 ; 16-byte Folded Spill
	xtn.2s	v6, v6
	xtn.2s	v7, v7
	xtn.2s	v5, v5
	str	q19, [sp, #160]                 ; 16-byte Folded Spill
	mov.16b	v17, v19
	umlal.2d	v17, v5, v16
	stp	q26, q25, [sp, #112]            ; 32-byte Folded Spill
	mov.16b	v5, v26
	umlal.2d	v5, v6, v16
	stp	q5, q17, [sp, #256]             ; 32-byte Folded Spill
	mov.16b	v5, v25
	umlal.2d	v5, v7, v16
	str	q5, [sp, #240]                  ; 16-byte Folded Spill
	str	q21, [sp, #1248]
	str	q24, [sp, #1264]
	str	q20, [sp, #1280]
	str	q23, [sp, #1296]
	and	x8, x13, #0x7
	add	x9, sp, #1248
	ldr	x8, [x9, x8, lsl #3]
	orr	x8, x8, #0x100
	sub	x8, x8, x13, lsl #2
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	str	x8, [sp, #232]                  ; 8-byte Folded Spill
	add	x8, x14, x8
	ldp	q5, q6, [x8]
	zip2.8b	v7, v22, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	stp	q28, q27, [sp, #64]             ; 32-byte Folded Spill
	bit.16b	v6, v28, v7
	str	q22, [sp, #304]                 ; 16-byte Folded Spill
	zip1.8b	v7, v22, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v5, v27, v7
	stp	q5, q6, [x8]
	mov	w8, #32                         ; =0x20
	dup.2d	v5, x8
	orr.16b	v7, v20, v5
	orr.16b	v6, v24, v5
	stp	q6, q7, [sp, #544]              ; 32-byte Folded Spill
	orr.16b	v6, v21, v5
	orr.16b	v5, v23, v5
	stp	q5, q6, [sp, #512]              ; 32-byte Folded Spill
	mov	w8, #64                         ; =0x40
	dup.2d	v5, x8
	orr.16b	v7, v20, v5
	orr.16b	v6, v24, v5
	stp	q6, q7, [sp, #480]              ; 32-byte Folded Spill
	orr.16b	v6, v21, v5
	orr.16b	v5, v23, v5
	stp	q5, q6, [sp, #448]              ; 32-byte Folded Spill
	mov	w8, #96                         ; =0x60
	dup.2d	v5, x8
	stp	q20, q24, [sp, #640]            ; 32-byte Folded Spill
	orr.16b	v7, v20, v5
	orr.16b	v6, v24, v5
	stp	q6, q7, [sp, #416]              ; 32-byte Folded Spill
	orr.16b	v6, v21, v5
	str	q23, [sp, #672]                 ; 16-byte Folded Spill
	orr.16b	v5, v23, v5
	stp	q5, q6, [sp, #384]              ; 32-byte Folded Spill
	ldr	q5, [sp, #1792]
	ldr	q6, [sp, #1776]
	fmul.4s	v6, v6, v6
	fmul.4s	v5, v5, v5
	and.16b	v14, v10, v5
	and.16b	v20, v2, v6
	ldr	q5, [sp, #1744]
	fmul.4s	v5, v5, v5
	ldr	q6, [sp, #1760]
	fmul.4s	v6, v6, v6
	and.16b	v23, v10, v6
	and.16b	v15, v2, v5
	ldr	q5, [sp, #1712]
	fmul.4s	v5, v5, v5
	ldr	q6, [sp, #1728]
	fmul.4s	v6, v6, v6
	and.16b	v11, v10, v6
	and.16b	v13, v2, v5
	str	q21, [sp, #624]                 ; 16-byte Folded Spill
	fmov	x8, d21
	add	x8, x14, x8
	ldp	q5, q6, [x8]
	fmul.4s	v5, v5, v5
	fmul.4s	v6, v6, v6
	and.16b	v21, v10, v6
	and.16b	v12, v2, v5
	sshll.2d	v5, v10, #0
	dup.2d	v6, x15
	and.16b	v5, v5, v6
	sshll.2d	v7, v2, #0
	and.16b	v19, v7, v6
	and.16b	v16, v31, v6
	and.16b	v17, v30, v6
	stp	q31, q30, [sp, #576]            ; 32-byte Folded Spill
	and.16b	v6, v31, v1
	str	q6, [sp, #688]                  ; 16-byte Folded Spill
	and.16b	v31, v30, v1
	b	LBB0_69
LBB0_68:                                ; %else1157
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmul.4s	v6, v9, v9
	fmul.4s	v7, v8, v8
	fadd.4s	v22, v12, v7
	fadd.4s	v26, v21, v6
	fmul.4s	v6, v28, v28
	fmul.4s	v7, v27, v27
	fadd.4s	v7, v13, v7
	fadd.4s	v6, v11, v6
	fmul.4s	v24, v24, v24
	fmul.4s	v27, v29, v29
	fadd.4s	v27, v15, v27
	fadd.4s	v24, v23, v24
	sshll.2d	v28, v2, #0
	sshll.2d	v29, v10, #0
	fmul.4s	v25, v25, v25
	fmul.4s	v30, v30, v30
	fadd.4s	v30, v14, v30
	fadd.4s	v25, v20, v25
	dup.2d	v8, x15
	ldr	q9, [sp, #576]                  ; 16-byte Folded Reload
	and.16b	v9, v9, v8
	add.2d	v16, v16, v9
	ldr	q9, [sp, #592]                  ; 16-byte Folded Reload
	and.16b	v9, v9, v8
	add.2d	v17, v17, v9
	and.16b	v29, v29, v8
	add.2d	v5, v5, v29
	and.16b	v28, v28, v8
	add.2d	v19, v19, v28
	bit.16b	v21, v26, v10
	bit.16b	v12, v22, v2
	bit.16b	v11, v6, v10
	bit.16b	v13, v7, v2
	bit.16b	v23, v24, v10
	bit.16b	v15, v27, v2
	bit.16b	v20, v25, v2
	bit.16b	v14, v30, v10
	fmov	x8, d19
	cmp	x8, #8
	b.ge	LBB0_133
LBB0_69:                                ; %direct.true57.i230.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s18
	shl.2d	v22, v19, #5
	ldr	q6, [sp, #624]                  ; 16-byte Folded Reload
	orr.16b	v6, v22, v6
	ldr	q7, [sp, #704]                  ; 16-byte Folded Reload
	add.2d	v6, v7, v6
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w9, #0, LBB0_104
; %bb.70:                               ; %else968
                                        ;   in Loop: Header=BB0_69 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_105
LBB0_71:                                ; %else974
                                        ;   in Loop: Header=BB0_69 Depth=2
	shl.2d	v6, v17, #5
	ldr	q7, [sp, #656]                  ; 16-byte Folded Reload
	orr.16b	v7, v6, v7
	add.2d	v7, v31, v7
	tbnz	w9, #2, LBB0_106
LBB0_72:                                ; %else980
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbnz	w9, #3, LBB0_107
LBB0_73:                                ; %else986
                                        ;   in Loop: Header=BB0_69 Depth=2
	shl.2d	v7, v5, #5
	ldr	q24, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v24, v7, v24
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v24, v25, v24
	tbnz	w9, #4, LBB0_108
LBB0_74:                                ; %else992
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbnz	w9, #5, LBB0_109
LBB0_75:                                ; %else998
                                        ;   in Loop: Header=BB0_69 Depth=2
	shl.2d	v26, v16, #5
	ldp	q24, q25, [sp, #672]            ; 32-byte Folded Reload
	orr.16b	v24, v26, v24
	add.2d	v24, v25, v24
	tbnz	w9, #6, LBB0_110
LBB0_76:                                ; %else1004
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbz	w9, #7, LBB0_78
LBB0_77:                                ; %cond.load1006
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v24[1]
	ld1.s	{ v9 }[3], [x8]
LBB0_78:                                ; %else1010
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	w9, s18
	ldr	q24, [sp, #528]                 ; 16-byte Folded Reload
	add.2d	v24, v24, v22
	ldr	q25, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v24, v25, v24
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w9, #0, LBB0_111
; %bb.79:                               ; %else1017
                                        ;   in Loop: Header=BB0_69 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_112
LBB0_80:                                ; %else1023
                                        ;   in Loop: Header=BB0_69 Depth=2
	ldr	q24, [sp, #544]                 ; 16-byte Folded Reload
	add.2d	v24, v24, v6
	add.2d	v24, v31, v24
	tbnz	w9, #2, LBB0_113
LBB0_81:                                ; %else1029
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbnz	w9, #3, LBB0_114
LBB0_82:                                ; %else1035
                                        ;   in Loop: Header=BB0_69 Depth=2
	ldr	q24, [sp, #560]                 ; 16-byte Folded Reload
	add.2d	v24, v24, v7
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v24, v25, v24
	tbnz	w9, #4, LBB0_115
LBB0_83:                                ; %else1041
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbnz	w9, #5, LBB0_116
LBB0_84:                                ; %else1047
                                        ;   in Loop: Header=BB0_69 Depth=2
	ldr	q24, [sp, #512]                 ; 16-byte Folded Reload
	add.2d	v24, v24, v26
	ldr	q25, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v24, v25, v24
	tbnz	w9, #6, LBB0_117
LBB0_85:                                ; %else1053
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbz	w9, #7, LBB0_87
LBB0_86:                                ; %cond.load1055
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v24[1]
	ld1.s	{ v28 }[3], [x8]
LBB0_87:                                ; %else1059
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	w9, s18
	ldr	q24, [sp, #464]                 ; 16-byte Folded Reload
	add.2d	v24, v24, v22
	ldr	q25, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v24
	movi.2d	v29, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w9, #0, LBB0_118
; %bb.88:                               ; %else1066
                                        ;   in Loop: Header=BB0_69 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_119
LBB0_89:                                ; %else1072
                                        ;   in Loop: Header=BB0_69 Depth=2
	ldr	q25, [sp, #480]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v6
	add.2d	v25, v31, v25
	tbnz	w9, #2, LBB0_120
LBB0_90:                                ; %else1078
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbnz	w9, #3, LBB0_121
LBB0_91:                                ; %else1084
                                        ;   in Loop: Header=BB0_69 Depth=2
	ldr	q25, [sp, #496]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v7
	ldr	q30, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v25, v30, v25
	tbnz	w9, #4, LBB0_122
LBB0_92:                                ; %else1090
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbnz	w9, #5, LBB0_123
LBB0_93:                                ; %else1096
                                        ;   in Loop: Header=BB0_69 Depth=2
	ldr	q25, [sp, #448]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v26
	ldr	q30, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v25, v30, v25
	tbnz	w9, #6, LBB0_124
LBB0_94:                                ; %else1102
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbz	w9, #7, LBB0_96
LBB0_95:                                ; %cond.load1104
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v25[1]
	ld1.s	{ v24 }[3], [x8]
LBB0_96:                                ; %else1108
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	w9, s18
	ldr	q25, [sp, #400]                 ; 16-byte Folded Reload
	add.2d	v22, v25, v22
	ldr	q25, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v22, v25, v22
	movi.2d	v25, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbnz	w9, #0, LBB0_125
; %bb.97:                               ; %else1115
                                        ;   in Loop: Header=BB0_69 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_126
LBB0_98:                                ; %else1121
                                        ;   in Loop: Header=BB0_69 Depth=2
	ldr	q22, [sp, #416]                 ; 16-byte Folded Reload
	add.2d	v6, v22, v6
	add.2d	v6, v31, v6
	tbnz	w9, #2, LBB0_127
LBB0_99:                                ; %else1127
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbnz	w9, #3, LBB0_128
LBB0_100:                               ; %else1133
                                        ;   in Loop: Header=BB0_69 Depth=2
	ldr	q6, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v6, v6, v7
	ldr	q7, [sp, #720]                  ; 16-byte Folded Reload
	add.2d	v6, v7, v6
	tbnz	w9, #4, LBB0_129
LBB0_101:                               ; %else1139
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbnz	w9, #5, LBB0_130
LBB0_102:                               ; %else1145
                                        ;   in Loop: Header=BB0_69 Depth=2
	ldr	q6, [sp, #384]                  ; 16-byte Folded Reload
	add.2d	v6, v6, v26
	ldr	q7, [sp, #688]                  ; 16-byte Folded Reload
	add.2d	v6, v7, v6
	tbnz	w9, #6, LBB0_131
LBB0_103:                               ; %else1151
                                        ;   in Loop: Header=BB0_69 Depth=2
	tbz	w9, #7, LBB0_68
	b	LBB0_132
LBB0_104:                               ; %cond.load964
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d6
	ldr	s8, [x8]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_71
LBB0_105:                               ; %cond.load970
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v6[1]
	ld1.s	{ v8 }[1], [x8]
	shl.2d	v6, v17, #5
	ldr	q7, [sp, #656]                  ; 16-byte Folded Reload
	orr.16b	v7, v6, v7
	add.2d	v7, v31, v7
	tbz	w9, #2, LBB0_72
LBB0_106:                               ; %cond.load976
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d7
	ld1.s	{ v8 }[2], [x8]
	tbz	w9, #3, LBB0_73
LBB0_107:                               ; %cond.load982
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v8 }[3], [x8]
	shl.2d	v7, v5, #5
	ldr	q24, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v24, v7, v24
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v24, v25, v24
	tbz	w9, #4, LBB0_74
LBB0_108:                               ; %cond.load988
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d24
	ld1.s	{ v9 }[0], [x8]
	tbz	w9, #5, LBB0_75
LBB0_109:                               ; %cond.load994
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v24[1]
	ld1.s	{ v9 }[1], [x8]
	shl.2d	v26, v16, #5
	ldp	q24, q25, [sp, #672]            ; 32-byte Folded Reload
	orr.16b	v24, v26, v24
	add.2d	v24, v25, v24
	tbz	w9, #6, LBB0_76
LBB0_110:                               ; %cond.load1000
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d24
	ld1.s	{ v9 }[2], [x8]
	tbnz	w9, #7, LBB0_77
	b	LBB0_78
LBB0_111:                               ; %cond.load1013
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d24
	ldr	s27, [x8]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_80
LBB0_112:                               ; %cond.load1019
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v24[1]
	ld1.s	{ v27 }[1], [x8]
	ldr	q24, [sp, #544]                 ; 16-byte Folded Reload
	add.2d	v24, v24, v6
	add.2d	v24, v31, v24
	tbz	w9, #2, LBB0_81
LBB0_113:                               ; %cond.load1025
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d24
	ld1.s	{ v27 }[2], [x8]
	tbz	w9, #3, LBB0_82
LBB0_114:                               ; %cond.load1031
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v24[1]
	ld1.s	{ v27 }[3], [x8]
	ldr	q24, [sp, #560]                 ; 16-byte Folded Reload
	add.2d	v24, v24, v7
	ldr	q25, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v24, v25, v24
	tbz	w9, #4, LBB0_83
LBB0_115:                               ; %cond.load1037
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d24
	ld1.s	{ v28 }[0], [x8]
	tbz	w9, #5, LBB0_84
LBB0_116:                               ; %cond.load1043
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v24[1]
	ld1.s	{ v28 }[1], [x8]
	ldr	q24, [sp, #512]                 ; 16-byte Folded Reload
	add.2d	v24, v24, v26
	ldr	q25, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v24, v25, v24
	tbz	w9, #6, LBB0_85
LBB0_117:                               ; %cond.load1049
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d24
	ld1.s	{ v28 }[2], [x8]
	tbnz	w9, #7, LBB0_86
	b	LBB0_87
LBB0_118:                               ; %cond.load1062
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d25
	ldr	s29, [x8]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_89
LBB0_119:                               ; %cond.load1068
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v25[1]
	ld1.s	{ v29 }[1], [x8]
	ldr	q25, [sp, #480]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v6
	add.2d	v25, v31, v25
	tbz	w9, #2, LBB0_90
LBB0_120:                               ; %cond.load1074
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d25
	ld1.s	{ v29 }[2], [x8]
	tbz	w9, #3, LBB0_91
LBB0_121:                               ; %cond.load1080
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v25[1]
	ld1.s	{ v29 }[3], [x8]
	ldr	q25, [sp, #496]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v7
	ldr	q30, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v25, v30, v25
	tbz	w9, #4, LBB0_92
LBB0_122:                               ; %cond.load1086
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d25
	ld1.s	{ v24 }[0], [x8]
	tbz	w9, #5, LBB0_93
LBB0_123:                               ; %cond.load1092
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v25[1]
	ld1.s	{ v24 }[1], [x8]
	ldr	q25, [sp, #448]                 ; 16-byte Folded Reload
	add.2d	v25, v25, v26
	ldr	q30, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v25, v30, v25
	tbz	w9, #6, LBB0_94
LBB0_124:                               ; %cond.load1098
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d25
	ld1.s	{ v24 }[2], [x8]
	tbnz	w9, #7, LBB0_95
	b	LBB0_96
LBB0_125:                               ; %cond.load1111
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d22
	ldr	s25, [x8]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_98
LBB0_126:                               ; %cond.load1117
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v22[1]
	ld1.s	{ v25 }[1], [x8]
	ldr	q22, [sp, #416]                 ; 16-byte Folded Reload
	add.2d	v6, v22, v6
	add.2d	v6, v31, v6
	tbz	w9, #2, LBB0_99
LBB0_127:                               ; %cond.load1123
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d6
	ld1.s	{ v25 }[2], [x8]
	tbz	w9, #3, LBB0_100
LBB0_128:                               ; %cond.load1129
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v6[1]
	ld1.s	{ v25 }[3], [x8]
	ldr	q6, [sp, #432]                  ; 16-byte Folded Reload
	add.2d	v6, v6, v7
	ldr	q7, [sp, #720]                  ; 16-byte Folded Reload
	add.2d	v6, v7, v6
	tbz	w9, #4, LBB0_101
LBB0_129:                               ; %cond.load1135
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d6
	ld1.s	{ v30 }[0], [x8]
	tbz	w9, #5, LBB0_102
LBB0_130:                               ; %cond.load1141
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v6[1]
	ld1.s	{ v30 }[1], [x8]
	ldr	q6, [sp, #384]                  ; 16-byte Folded Reload
	add.2d	v6, v6, v26
	ldr	q7, [sp, #688]                  ; 16-byte Folded Reload
	add.2d	v6, v7, v6
	tbz	w9, #6, LBB0_103
LBB0_131:                               ; %cond.load1147
                                        ;   in Loop: Header=BB0_69 Depth=2
	fmov	x8, d6
	ld1.s	{ v30 }[2], [x8]
	tbz	w9, #7, LBB0_68
LBB0_132:                               ; %cond.load1153
                                        ;   in Loop: Header=BB0_69 Depth=2
	mov.d	x8, v6[1]
	ld1.s	{ v30 }[3], [x8]
	b	LBB0_68
LBB0_133:                               ; %direct.false58.i231.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	x1, [sp, #560]                  ; 8-byte Folded Spill
	mov	x9, #0                          ; =0x0
	ldp	q6, q5, [sp, #576]              ; 32-byte Folded Reload
	and.16b	v16, v6, v0
	and.16b	v17, v5, v0
	sshll.2d	v5, v10, #0
	and.16b	v6, v5, v0
	sshll.2d	v5, v2, #0
	and.16b	v7, v5, v0
	dup.2d	v5, x26
	ushll2.2d	v19, v10, #0
	and.16b	v8, v19, v5
	ushll2.2d	v19, v2, #0
	and.16b	v9, v19, v5
	ushll.2d	v19, v10, #0
	and.16b	v10, v19, v5
	ushll.2d	v2, v2, #0
	and.16b	v2, v2, v5
	movi.2d	v5, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v27, #0000000000000000
	b	LBB0_135
LBB0_134:                               ; %else1215
                                        ;   in Loop: Header=BB0_135 Depth=2
	add.2d	v19, v19, v9
	add.2d	v24, v24, v10
	add.2d	v27, v27, v8
	add.2d	v5, v5, v2
	fmov	x9, d5
	cmp	x9, #8
	b.ge	LBB0_167
LBB0_135:                               ; %direct.true85.i232.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w10, s18
	add	x9, x3, x9, lsl #5
	movi.2d	v29, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w10, #0, LBB0_151
; %bb.136:                              ; %else1161
                                        ;   in Loop: Header=BB0_135 Depth=2
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_152
LBB0_137:                               ; %else1164
                                        ;   in Loop: Header=BB0_135 Depth=2
	tbnz	w10, #2, LBB0_153
LBB0_138:                               ; %else1167
                                        ;   in Loop: Header=BB0_135 Depth=2
	tbnz	w10, #3, LBB0_154
LBB0_139:                               ; %else1170
                                        ;   in Loop: Header=BB0_135 Depth=2
	tbnz	w10, #4, LBB0_155
LBB0_140:                               ; %else1173
                                        ;   in Loop: Header=BB0_135 Depth=2
	tbnz	w10, #5, LBB0_156
LBB0_141:                               ; %else1176
                                        ;   in Loop: Header=BB0_135 Depth=2
	tbnz	w10, #6, LBB0_157
LBB0_142:                               ; %else1179
                                        ;   in Loop: Header=BB0_135 Depth=2
	tbnz	w10, #7, LBB0_158
LBB0_143:                               ; %else1182
                                        ;   in Loop: Header=BB0_135 Depth=2
	fmov	w9, s18
	shl.2d	v25, v5, #5
	ldr	q30, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v30
	add.2d	v25, v7, v25
	tbnz	w9, #0, LBB0_159
LBB0_144:                               ; %else1187
                                        ;   in Loop: Header=BB0_135 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_160
LBB0_145:                               ; %else1191
                                        ;   in Loop: Header=BB0_135 Depth=2
	shl.2d	v25, v19, #5
	ldr	q30, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v30
	add.2d	v25, v17, v25
	tbnz	w9, #2, LBB0_161
LBB0_146:                               ; %else1195
                                        ;   in Loop: Header=BB0_135 Depth=2
	tbnz	w9, #3, LBB0_162
LBB0_147:                               ; %else1199
                                        ;   in Loop: Header=BB0_135 Depth=2
	shl.2d	v25, v24, #5
	ldr	q29, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v29
	add.2d	v25, v6, v25
	tbnz	w9, #4, LBB0_163
LBB0_148:                               ; %else1203
                                        ;   in Loop: Header=BB0_135 Depth=2
	tbnz	w9, #5, LBB0_164
LBB0_149:                               ; %else1207
                                        ;   in Loop: Header=BB0_135 Depth=2
	shl.2d	v25, v27, #5
	ldr	q29, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v29
	add.2d	v25, v16, v25
	tbnz	w9, #6, LBB0_165
LBB0_150:                               ; %else1211
                                        ;   in Loop: Header=BB0_135 Depth=2
	tbz	w9, #7, LBB0_134
	b	LBB0_166
LBB0_151:                               ; %cond.load1160
                                        ;   in Loop: Header=BB0_135 Depth=2
	ldr	s29, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_137
LBB0_152:                               ; %cond.load1163
                                        ;   in Loop: Header=BB0_135 Depth=2
	add	x8, x9, #4
	ld1.s	{ v29 }[1], [x8]
	tbz	w10, #2, LBB0_138
LBB0_153:                               ; %cond.load1166
                                        ;   in Loop: Header=BB0_135 Depth=2
	add	x8, x9, #8
	ld1.s	{ v29 }[2], [x8]
	tbz	w10, #3, LBB0_139
LBB0_154:                               ; %cond.load1169
                                        ;   in Loop: Header=BB0_135 Depth=2
	add	x8, x9, #12
	ld1.s	{ v29 }[3], [x8]
	tbz	w10, #4, LBB0_140
LBB0_155:                               ; %cond.load1172
                                        ;   in Loop: Header=BB0_135 Depth=2
	add	x8, x9, #16
	ld1.s	{ v28 }[0], [x8]
	tbz	w10, #5, LBB0_141
LBB0_156:                               ; %cond.load1175
                                        ;   in Loop: Header=BB0_135 Depth=2
	add	x8, x9, #20
	ld1.s	{ v28 }[1], [x8]
	tbz	w10, #6, LBB0_142
LBB0_157:                               ; %cond.load1178
                                        ;   in Loop: Header=BB0_135 Depth=2
	add	x8, x9, #24
	ld1.s	{ v28 }[2], [x8]
	tbz	w10, #7, LBB0_143
LBB0_158:                               ; %cond.load1181
                                        ;   in Loop: Header=BB0_135 Depth=2
	add	x8, x9, #28
	ld1.s	{ v28 }[3], [x8]
	fmov	w9, s18
	shl.2d	v25, v5, #5
	ldr	q30, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v30
	add.2d	v25, v7, v25
	tbz	w9, #0, LBB0_144
LBB0_159:                               ; %cond.store
                                        ;   in Loop: Header=BB0_135 Depth=2
	fmov	x8, d25
	str	s29, [x8]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_145
LBB0_160:                               ; %cond.store1188
                                        ;   in Loop: Header=BB0_135 Depth=2
	mov.d	x8, v25[1]
	st1.s	{ v29 }[1], [x8]
	shl.2d	v25, v19, #5
	ldr	q30, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v30
	add.2d	v25, v17, v25
	tbz	w9, #2, LBB0_146
LBB0_161:                               ; %cond.store1192
                                        ;   in Loop: Header=BB0_135 Depth=2
	fmov	x8, d25
	st1.s	{ v29 }[2], [x8]
	tbz	w9, #3, LBB0_147
LBB0_162:                               ; %cond.store1196
                                        ;   in Loop: Header=BB0_135 Depth=2
	mov.d	x8, v25[1]
	st1.s	{ v29 }[3], [x8]
	shl.2d	v25, v24, #5
	ldr	q29, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v29
	add.2d	v25, v6, v25
	tbz	w9, #4, LBB0_148
LBB0_163:                               ; %cond.store1200
                                        ;   in Loop: Header=BB0_135 Depth=2
	fmov	x8, d25
	str	s28, [x8]
	tbz	w9, #5, LBB0_149
LBB0_164:                               ; %cond.store1204
                                        ;   in Loop: Header=BB0_135 Depth=2
	mov.d	x8, v25[1]
	st1.s	{ v28 }[1], [x8]
	shl.2d	v25, v27, #5
	ldr	q29, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v25, v25, v29
	add.2d	v25, v16, v25
	tbz	w9, #6, LBB0_150
LBB0_165:                               ; %cond.store1208
                                        ;   in Loop: Header=BB0_135 Depth=2
	fmov	x8, d25
	st1.s	{ v28 }[2], [x8]
	tbz	w9, #7, LBB0_134
LBB0_166:                               ; %cond.store1212
                                        ;   in Loop: Header=BB0_135 Depth=2
	mov.d	x8, v25[1]
	st1.s	{ v28 }[3], [x8]
	b	LBB0_134
LBB0_167:                               ; %direct.false86.i234.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q5, [sp, #144]                  ; 16-byte Folded Reload
	xtn.8b	v5, v5
	ldp	q24, q19, [sp, #64]             ; 32-byte Folded Reload
	fmul.4s	v19, v19, v19
	fmul.4s	v24, v24, v24
	fadd.4s	v21, v24, v21
	fadd.4s	v19, v19, v12
	ldr	q27, [sp, #304]                 ; 16-byte Folded Reload
	zip1.8b	v24, v27, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	and.16b	v19, v24, v19
	zip2.8b	v24, v27, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	and.16b	v21, v24, v21
	zip2.8b	v24, v5, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	movi.2d	v25, #0000000000000000
	mov.b	v25[2], v5[1]
	mov.b	v25[4], v5[2]
	mov.b	v25[6], v5[3]
	bit.16b	v21, v26, v24
	ushll.4s	v24, v25, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	bit.16b	v19, v22, v24
	fadd.4s	v19, v13, v19
	mov.16b	v13, v27
	fadd.4s	v21, v11, v21
	fadd.4s	v21, v23, v21
	fadd.4s	v19, v15, v19
	fadd.4s	v20, v20, v19
	fadd.4s	v21, v14, v21
	ldr	q19, [sp, #96]                  ; 16-byte Folded Reload
	ldp	q23, q22, [sp, #32]             ; 32-byte Folded Reload
	uzp1.4s	v19, v19, v23
	ldr	q23, [sp, #16]                  ; 16-byte Folded Reload
	uzp1.4s	v22, v23, v22
	movi.4s	v24, #1
	eor.16b	v23, v19, v24
	mov.s	w8, v23[1]
	mov.s	w12, v23[2]
	eor.16b	v26, v22, v24
	mov.s	w0, v23[3]
	fmov	w9, s23
	add	x10, sp, #808
	bfxil	x10, x9, #0, #3
	str	d5, [sp, #808]
	ldrb	w10, [x10]
	and	x11, x9, #0x7
	umov.b	w9, v5[0]
	str	q21, [sp, #1088]
	str	q20, [sp, #1072]
	add	x14, sp, #1072
	ldr	s23, [x14, x11, lsl #2]
	ands	w11, w9, #0x1
	tst	w11, w10
	movi	d12, #0000000000000000
	fcsel	s23, s23, s12, ne
	add	x10, sp, #808
	bfxil	x10, x8, #0, #3
	ldrb	w14, [x10]
	and	x8, x8, #0x7
	umov.b	w10, v5[1]
	str	q21, [sp, #1056]
	str	q20, [sp, #1040]
	add	x1, sp, #1040
	ldr	s24, [x1, x8, lsl #2]
	ands	w8, w10, #0x1
	tst	w8, w14
	fcsel	s24, s24, s12, ne
	add	x8, sp, #808
	bfxil	x8, x12, #0, #3
	ldrb	w8, [x8]
	umov.b	w14, v5[2]
	and	x12, x12, #0x7
	stp	q20, q21, [sp, #1008]
	add	x1, sp, #1008
	ldr	s25, [x1, x12, lsl #2]
	ands	w12, w14, #0x1
	tst	w12, w8
	fcsel	s25, s25, s12, ne
	add	x8, sp, #808
	bfxil	x8, x0, #0, #3
	ldrb	w8, [x8]
	and	x12, x0, #0x7
	umov.b	w0, v5[3]
	stp	q20, q21, [sp, #976]
	add	x1, sp, #976
	ldr	s27, [x1, x12, lsl #2]
	ands	w12, w0, #0x1
	tst	w12, w8
	mov.s	w8, v26[1]
	mov.s	w12, v26[2]
	fcsel	s27, s27, s12, ne
	mov.s	w1, v26[3]
	fmov	w2, s26
	and	x27, x2, #0x7
	add	x28, sp, #808
	bfxil	x28, x2, #0, #3
	ldrb	w28, [x28]
	umov.b	w2, v5[4]
	and	w28, w2, w28
	str	q21, [sp, #1216]
	str	q20, [sp, #1200]
	add	x30, sp, #1200
	ldr	s26, [x30, x27, lsl #2]
	tst	w28, #0x1
	fcsel	s26, s26, s12, ne
	add	x27, sp, #808
	bfxil	x27, x8, #0, #3
	ldrb	w28, [x27]
	and	x8, x8, #0x7
	umov.b	w27, v5[5]
	str	q21, [sp, #1184]
	str	q20, [sp, #1168]
	add	x30, sp, #1168
	ldr	s28, [x30, x8, lsl #2]
	ands	w8, w27, #0x1
	tst	w8, w28
	fcsel	s28, s28, s12, ne
	add	x8, sp, #808
	bfxil	x8, x12, #0, #3
	ldrb	w8, [x8]
	and	x12, x12, #0x7
	umov.b	w30, v5[6]
	str	q21, [sp, #1152]
	str	q20, [sp, #1136]
	add	x28, sp, #1136
	ldr	s29, [x28, x12, lsl #2]
	ands	w12, w30, #0x1
	tst	w12, w8
	fcsel	s29, s29, s12, ne
	add	x8, sp, #808
	bfxil	x8, x1, #0, #3
	ldrb	w8, [x8]
	umov.b	w12, v5[7]
	and	x1, x1, #0x7
	str	q21, [sp, #1120]
	str	q20, [sp, #1104]
	add	x28, sp, #1104
	ldr	s5, [x28, x1, lsl #2]
	ands	w1, w12, #0x1
	tst	w1, w8
	fcsel	s5, s5, s12, ne
	mov.s	v26[1], v28[0]
	mov.s	v26[2], v29[0]
	mov.s	v26[3], v5[0]
	mov.s	v23[1], v24[0]
	mov.s	v23[2], v25[0]
	mov.s	v23[3], v27[0]
	fadd.4s	v5, v20, v23
	fadd.4s	v20, v21, v26
	movi.4s	v23, #2
	eor.16b	v21, v22, v23
	eor.16b	v19, v19, v23
	fmov	w8, s19
	add	x1, sp, #808
	bfxil	x1, x8, #0, #3
	ldrb	w1, [x1]
	and	x8, x8, #0x7
	stp	q5, q20, [sp, #944]
	add	x28, sp, #944
	ldr	s19, [x28, x8, lsl #2]
	tst	w11, w1
	fcsel	s19, s19, s12, ne
	fmov	w8, s21
	and	x1, x8, #0x7
	add	x28, sp, #808
	bfxil	x28, x8, #0, #3
	ldrb	w8, [x28]
	and	w8, w2, w8
	stp	q5, q20, [sp, #912]
	add	x28, sp, #912
	ldr	s21, [x28, x1, lsl #2]
	tst	w8, #0x1
	fcsel	s21, s21, s12, ne
	fadd.4s	v20, v20, v21
	tst	w11, w2
	fcsel	s20, s20, s12, ne
	ands	w8, w9, #0x1
	fadd.4s	v5, v5, v19
	fadd	s5, s5, s20
	fcsel	s19, s5, s12, ne
	tst	w10, #0x1
	fcsel	s20, s19, s12, ne
	tst	w14, #0x1
	fcsel	s21, s19, s12, ne
	tst	w0, #0x1
	fcsel	s22, s19, s12, ne
	tst	w8, w2
	fcsel	s23, s5, s12, ne
	tst	w27, #0x1
	fcsel	s24, s19, s12, ne
	tst	w30, #0x1
	fcsel	s25, s19, s12, ne
	tst	w12, #0x1
	shl.8b	v5, v13, #7
	cmlt.8b	v5, v5, #0
	ldr	d26, [sp, #184]                 ; 8-byte Folded Reload
	and.8b	v5, v5, v26
	addv.8b	b5, v5
	fmov	w9, s5
	fcsel	s26, s19, s12, ne
	mov.s	v19[1], v20[0]
	mov.s	v19[2], v21[0]
	mov.s	v19[3], v22[0]
	mov.s	v23[1], v24[0]
	mov.s	v23[2], v25[0]
	mov.s	v23[3], v26[0]
	ldr	w8, [sp, #228]                  ; 4-byte Folded Reload
	rbit	w8, w8
	clz	w8, w8
	stp	q19, q23, [sp, #880]
	and	x8, x8, #0x7
	add	x10, sp, #880
	ldr	s19, [x10, x8, lsl #2]
	mov	b20, v13[0]
	mov.b	v20[4], v13[1]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	mov	b21, v13[2]
	mov.b	v21[4], v13[3]
	ldr	q22, [sp, #192]                 ; 16-byte Folded Reload
	and.16b	v20, v20, v22
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	ldp	q22, q23, [sp, #112]            ; 32-byte Folded Reload
	and.16b	v21, v21, v22
	mov	b22, v13[4]
	mov.b	v22[4], v13[5]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v22, v22, v23
	mov	b23, v13[6]
	mov.b	v23[4], v13[7]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	ldr	q24, [sp, #160]                 ; 16-byte Folded Reload
	and.16b	v23, v23, v24
	stp	q22, q23, [sp, #848]
	stp	q20, q21, [sp, #816]
	and	x8, x13, #0x7
	add	x10, sp, #816
	ldr	x8, [x10, x8, lsl #3]
	sub	x8, x8, x13
	add	x10, x3, x8, lsl #2
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w9, #0, LBB0_242
; %bb.168:                              ; %else1218
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	w14, [sp, #364]                 ; 4-byte Folded Reload
	ldr	x2, [sp, #560]                  ; 8-byte Folded Reload
	ldr	x3, [sp, #232]                  ; 8-byte Folded Reload
	tbnz	w9, #1, LBB0_243
LBB0_169:                               ; %else1221
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, sp, #1680
	adrp	x1, lCPI0_4@PAGE
	ldr	x0, [sp, #376]                  ; 8-byte Folded Reload
	tbnz	w9, #2, LBB0_244
LBB0_170:                               ; %else1224
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #3, LBB0_245
LBB0_171:                               ; %else1227
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #4, LBB0_246
LBB0_172:                               ; %else1230
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #5, LBB0_247
LBB0_173:                               ; %else1233
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #6, LBB0_248
LBB0_174:                               ; %else1236
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #7, LBB0_176
LBB0_175:                               ; %cond.load1238
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #28
	ld1.s	{ v21 }[3], [x8]
LBB0_176:                               ; %else1239
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x10, #0                         ; =0x0
	fadd	s19, s19, s12
	mov	w8, #1115815936                 ; =0x42820000
	fmov	s22, w8
	fdiv	s19, s19, s22
	add	x8, sp, #1392
	add	x8, x8, x3
	ldp	q22, q23, [x8]
	zip2.8b	v24, v13, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	bif.16b	v21, v23, v24
	zip1.8b	v23, v13, v0
	ushll.4s	v23, v23, #0
	shl.4s	v23, v23, #31
	cmlt.4s	v23, v23, #0
	bif.16b	v20, v22, v23
	stp	q20, q21, [x8]
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s20, w8
	fadd	s19, s19, s20
	fsqrt	s19, s19
	dup.4s	v19, v19[0]
	ldr	q20, [sp, #208]                 ; 16-byte Folded Reload
	fmov	x8, d20
	add	x9, x2, x8, lsl #2
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	b	LBB0_178
LBB0_177:                               ; %else1355
                                        ;   in Loop: Header=BB0_178 Depth=2
	add.2d	v21, v21, v9
	add.2d	v22, v22, v10
	add.2d	v23, v23, v8
	add.2d	v20, v20, v2
	fmov	x10, d20
	cmp	x10, #8
	b.ge	LBB0_226
LBB0_178:                               ; %direct.true109.i241.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s18
	shl.2d	v24, v20, #5
	ldr	q25, [sp, #624]                 ; 16-byte Folded Reload
	orr.16b	v25, v24, v25
	ldr	q24, [sp, #704]                 ; 16-byte Folded Reload
	add.2d	v27, v24, v25
	movi.2d	v24, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbnz	w11, #0, LBB0_202
; %bb.179:                              ; %else1246
                                        ;   in Loop: Header=BB0_178 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_203
LBB0_180:                               ; %else1252
                                        ;   in Loop: Header=BB0_178 Depth=2
	shl.2d	v27, v21, #5
	ldr	q28, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v28, v27, v28
	add.2d	v27, v31, v28
	tbnz	w11, #2, LBB0_204
LBB0_181:                               ; %else1258
                                        ;   in Loop: Header=BB0_178 Depth=2
	tbnz	w11, #3, LBB0_205
LBB0_182:                               ; %else1264
                                        ;   in Loop: Header=BB0_178 Depth=2
	shl.2d	v27, v22, #5
	ldr	q29, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v29, v27, v29
	ldr	q27, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v27, v27, v29
	tbnz	w11, #4, LBB0_206
LBB0_183:                               ; %else1270
                                        ;   in Loop: Header=BB0_178 Depth=2
	tbnz	w11, #5, LBB0_207
LBB0_184:                               ; %else1276
                                        ;   in Loop: Header=BB0_178 Depth=2
	shl.2d	v27, v23, #5
	ldr	q30, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v30, v27, v30
	ldr	q27, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v27, v27, v30
	tbnz	w11, #6, LBB0_208
LBB0_185:                               ; %else1282
                                        ;   in Loop: Header=BB0_178 Depth=2
	tbnz	w11, #7, LBB0_209
LBB0_186:                               ; %else1288
                                        ;   in Loop: Header=BB0_178 Depth=2
	fmov	w11, s18
	add.2d	v11, v7, v25
	movi.2d	v25, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w11, #0, LBB0_210
LBB0_187:                               ; %else1295
                                        ;   in Loop: Header=BB0_178 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_211
LBB0_188:                               ; %else1301
                                        ;   in Loop: Header=BB0_178 Depth=2
	add.2d	v28, v17, v28
	tbnz	w11, #2, LBB0_212
LBB0_189:                               ; %else1307
                                        ;   in Loop: Header=BB0_178 Depth=2
	tbnz	w11, #3, LBB0_213
LBB0_190:                               ; %else1313
                                        ;   in Loop: Header=BB0_178 Depth=2
	add.2d	v28, v6, v29
	tbnz	w11, #4, LBB0_214
LBB0_191:                               ; %else1319
                                        ;   in Loop: Header=BB0_178 Depth=2
	tbnz	w11, #5, LBB0_215
LBB0_192:                               ; %else1325
                                        ;   in Loop: Header=BB0_178 Depth=2
	add.2d	v28, v16, v30
	tbnz	w11, #6, LBB0_216
LBB0_193:                               ; %else1331
                                        ;   in Loop: Header=BB0_178 Depth=2
	tbnz	w11, #7, LBB0_217
LBB0_194:                               ; %else1337
                                        ;   in Loop: Header=BB0_178 Depth=2
	fdiv.4s	v24, v24, v19
	fmov	w11, s18
	fmul.4s	v24, v24, v25
	add	x10, x9, x10, lsl #5
	tbnz	w11, #0, LBB0_218
LBB0_195:                               ; %else1341
                                        ;   in Loop: Header=BB0_178 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_219
LBB0_196:                               ; %else1343
                                        ;   in Loop: Header=BB0_178 Depth=2
	tbnz	w11, #2, LBB0_220
LBB0_197:                               ; %else1345
                                        ;   in Loop: Header=BB0_178 Depth=2
	tbnz	w11, #3, LBB0_221
LBB0_198:                               ; %else1347
                                        ;   in Loop: Header=BB0_178 Depth=2
	fdiv.4s	v24, v26, v19
	fmul.4s	v24, v24, v27
	tbnz	w11, #4, LBB0_222
LBB0_199:                               ; %else1349
                                        ;   in Loop: Header=BB0_178 Depth=2
	tbnz	w11, #5, LBB0_223
LBB0_200:                               ; %else1351
                                        ;   in Loop: Header=BB0_178 Depth=2
	tbnz	w11, #6, LBB0_224
LBB0_201:                               ; %else1353
                                        ;   in Loop: Header=BB0_178 Depth=2
	tbz	w11, #7, LBB0_177
	b	LBB0_225
LBB0_202:                               ; %cond.load1242
                                        ;   in Loop: Header=BB0_178 Depth=2
	fmov	x8, d27
	ldr	s24, [x8]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_180
LBB0_203:                               ; %cond.load1248
                                        ;   in Loop: Header=BB0_178 Depth=2
	mov.d	x8, v27[1]
	ld1.s	{ v24 }[1], [x8]
	shl.2d	v27, v21, #5
	ldr	q28, [sp, #656]                 ; 16-byte Folded Reload
	orr.16b	v28, v27, v28
	add.2d	v27, v31, v28
	tbz	w11, #2, LBB0_181
LBB0_204:                               ; %cond.load1254
                                        ;   in Loop: Header=BB0_178 Depth=2
	fmov	x8, d27
	ld1.s	{ v24 }[2], [x8]
	tbz	w11, #3, LBB0_182
LBB0_205:                               ; %cond.load1260
                                        ;   in Loop: Header=BB0_178 Depth=2
	mov.d	x8, v27[1]
	ld1.s	{ v24 }[3], [x8]
	shl.2d	v27, v22, #5
	ldr	q29, [sp, #640]                 ; 16-byte Folded Reload
	orr.16b	v29, v27, v29
	ldr	q27, [sp, #720]                 ; 16-byte Folded Reload
	add.2d	v27, v27, v29
	tbz	w11, #4, LBB0_183
LBB0_206:                               ; %cond.load1266
                                        ;   in Loop: Header=BB0_178 Depth=2
	fmov	x8, d27
	ld1.s	{ v26 }[0], [x8]
	tbz	w11, #5, LBB0_184
LBB0_207:                               ; %cond.load1272
                                        ;   in Loop: Header=BB0_178 Depth=2
	mov.d	x8, v27[1]
	ld1.s	{ v26 }[1], [x8]
	shl.2d	v27, v23, #5
	ldr	q30, [sp, #672]                 ; 16-byte Folded Reload
	orr.16b	v30, v27, v30
	ldr	q27, [sp, #688]                 ; 16-byte Folded Reload
	add.2d	v27, v27, v30
	tbz	w11, #6, LBB0_185
LBB0_208:                               ; %cond.load1278
                                        ;   in Loop: Header=BB0_178 Depth=2
	fmov	x8, d27
	ld1.s	{ v26 }[2], [x8]
	tbz	w11, #7, LBB0_186
LBB0_209:                               ; %cond.load1284
                                        ;   in Loop: Header=BB0_178 Depth=2
	mov.d	x8, v27[1]
	ld1.s	{ v26 }[3], [x8]
	fmov	w11, s18
	add.2d	v11, v7, v25
	movi.2d	v25, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbz	w11, #0, LBB0_187
LBB0_210:                               ; %cond.load1291
                                        ;   in Loop: Header=BB0_178 Depth=2
	fmov	x8, d11
	ldr	s25, [x8]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_188
LBB0_211:                               ; %cond.load1297
                                        ;   in Loop: Header=BB0_178 Depth=2
	mov.d	x8, v11[1]
	ld1.s	{ v25 }[1], [x8]
	add.2d	v28, v17, v28
	tbz	w11, #2, LBB0_189
LBB0_212:                               ; %cond.load1303
                                        ;   in Loop: Header=BB0_178 Depth=2
	fmov	x8, d28
	ld1.s	{ v25 }[2], [x8]
	tbz	w11, #3, LBB0_190
LBB0_213:                               ; %cond.load1309
                                        ;   in Loop: Header=BB0_178 Depth=2
	mov.d	x8, v28[1]
	ld1.s	{ v25 }[3], [x8]
	add.2d	v28, v6, v29
	tbz	w11, #4, LBB0_191
LBB0_214:                               ; %cond.load1315
                                        ;   in Loop: Header=BB0_178 Depth=2
	fmov	x8, d28
	ld1.s	{ v27 }[0], [x8]
	tbz	w11, #5, LBB0_192
LBB0_215:                               ; %cond.load1321
                                        ;   in Loop: Header=BB0_178 Depth=2
	mov.d	x8, v28[1]
	ld1.s	{ v27 }[1], [x8]
	add.2d	v28, v16, v30
	tbz	w11, #6, LBB0_193
LBB0_216:                               ; %cond.load1327
                                        ;   in Loop: Header=BB0_178 Depth=2
	fmov	x8, d28
	ld1.s	{ v27 }[2], [x8]
	tbz	w11, #7, LBB0_194
LBB0_217:                               ; %cond.load1333
                                        ;   in Loop: Header=BB0_178 Depth=2
	mov.d	x8, v28[1]
	ld1.s	{ v27 }[3], [x8]
	fdiv.4s	v24, v24, v19
	fmov	w11, s18
	fmul.4s	v24, v24, v25
	add	x10, x9, x10, lsl #5
	tbz	w11, #0, LBB0_195
LBB0_218:                               ; %cond.store1340
                                        ;   in Loop: Header=BB0_178 Depth=2
	str	s24, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_196
LBB0_219:                               ; %cond.store1342
                                        ;   in Loop: Header=BB0_178 Depth=2
	add	x8, x10, #4
	st1.s	{ v24 }[1], [x8]
	tbz	w11, #2, LBB0_197
LBB0_220:                               ; %cond.store1344
                                        ;   in Loop: Header=BB0_178 Depth=2
	add	x8, x10, #8
	st1.s	{ v24 }[2], [x8]
	tbz	w11, #3, LBB0_198
LBB0_221:                               ; %cond.store1346
                                        ;   in Loop: Header=BB0_178 Depth=2
	add	x8, x10, #12
	st1.s	{ v24 }[3], [x8]
	fdiv.4s	v24, v26, v19
	fmul.4s	v24, v24, v27
	tbz	w11, #4, LBB0_199
LBB0_222:                               ; %cond.store1348
                                        ;   in Loop: Header=BB0_178 Depth=2
	str	s24, [x10, #16]
	tbz	w11, #5, LBB0_200
LBB0_223:                               ; %cond.store1350
                                        ;   in Loop: Header=BB0_178 Depth=2
	add	x8, x10, #20
	st1.s	{ v24 }[1], [x8]
	tbz	w11, #6, LBB0_201
LBB0_224:                               ; %cond.store1352
                                        ;   in Loop: Header=BB0_178 Depth=2
	add	x8, x10, #24
	st1.s	{ v24 }[2], [x8]
	tbz	w11, #7, LBB0_177
LBB0_225:                               ; %cond.store1354
                                        ;   in Loop: Header=BB0_178 Depth=2
	add	x8, x10, #28
	st1.s	{ v24 }[3], [x8]
	b	LBB0_177
LBB0_226:                               ; %direct.false110.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x12, x3
	ldp	q6, q2, [x8]
	zip1.8b	v7, v13, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v6, v7, v6
	fmov	w9, s5
	fdiv.4s	v6, v6, v19
	add	x8, sp, #1392
	add	x8, x8, x3
	ldp	q16, q5, [x8]
	and.16b	v7, v7, v16
	fmul.4s	v6, v6, v7
	ldr	q7, [sp, #288]                  ; 16-byte Folded Reload
	str	q7, [sp, #736]
	ldr	q7, [sp, #256]                  ; 16-byte Folded Reload
	str	q7, [sp, #752]
	ldr	q7, [sp, #240]                  ; 16-byte Folded Reload
	str	q7, [sp, #768]
	ldr	q7, [sp, #272]                  ; 16-byte Folded Reload
	str	q7, [sp, #784]
	and	x8, x13, #0x7
	add	x10, sp, #736
	ldr	x8, [x10, x8, lsl #3]
	sub	x8, x8, x13
	add	x10, x2, x8, lsl #2
	tbnz	w9, #0, LBB0_249
; %bb.227:                              ; %else1358
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	w12, [sp, #372]                 ; 4-byte Folded Reload
	ldr	w13, [sp, #368]                 ; 4-byte Folded Reload
	tbnz	w9, #1, LBB0_250
LBB0_228:                               ; %else1360
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #2, LBB0_251
LBB0_229:                               ; %else1362
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #3, LBB0_231
LBB0_230:                               ; %cond.store1363
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #12
	st1.s	{ v6 }[3], [x8]
LBB0_231:                               ; %else1364
                                        ;   in Loop: Header=BB0_3 Depth=1
	zip2.8b	v6, v13, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v2, v6, v2
	fdiv.4s	v2, v2, v19
	and.16b	v5, v6, v5
	fmul.4s	v2, v2, v5
	tbnz	w9, #4, LBB0_252
; %bb.232:                              ; %else1366
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #5, LBB0_253
LBB0_233:                               ; %else1368
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #6, LBB0_254
LBB0_234:                               ; %else1370
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #7, LBB0_2
	b	LBB0_255
LBB0_235:                               ; %cond.load939
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	s27, [x9]
	tbz	w10, #1, LBB0_60
LBB0_236:                               ; %cond.load942
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #4
	ld1.s	{ v27 }[1], [x8]
	tbz	w10, #2, LBB0_61
LBB0_237:                               ; %cond.load945
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #8
	ld1.s	{ v27 }[2], [x8]
	tbz	w10, #3, LBB0_62
LBB0_238:                               ; %cond.load948
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #12
	ld1.s	{ v27 }[3], [x8]
	tbz	w10, #4, LBB0_63
LBB0_239:                               ; %cond.load951
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #16
	ld1.s	{ v28 }[0], [x8]
	tbz	w10, #5, LBB0_64
LBB0_240:                               ; %cond.load954
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #20
	ld1.s	{ v28 }[1], [x8]
	tbz	w10, #6, LBB0_65
LBB0_241:                               ; %cond.load957
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x9, #24
	ld1.s	{ v28 }[2], [x8]
	tbnz	w10, #7, LBB0_66
	b	LBB0_67
LBB0_242:                               ; %cond.load1217
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	s20, [x10]
	ldr	w14, [sp, #364]                 ; 4-byte Folded Reload
	ldr	x2, [sp, #560]                  ; 8-byte Folded Reload
	ldr	x3, [sp, #232]                  ; 8-byte Folded Reload
	tbz	w9, #1, LBB0_169
LBB0_243:                               ; %cond.load1220
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #4
	ld1.s	{ v20 }[1], [x8]
	add	x12, sp, #1680
	adrp	x1, lCPI0_4@PAGE
	ldr	x0, [sp, #376]                  ; 8-byte Folded Reload
	tbz	w9, #2, LBB0_170
LBB0_244:                               ; %cond.load1223
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #8
	ld1.s	{ v20 }[2], [x8]
	tbz	w9, #3, LBB0_171
LBB0_245:                               ; %cond.load1226
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #12
	ld1.s	{ v20 }[3], [x8]
	tbz	w9, #4, LBB0_172
LBB0_246:                               ; %cond.load1229
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #16
	ld1.s	{ v21 }[0], [x8]
	tbz	w9, #5, LBB0_173
LBB0_247:                               ; %cond.load1232
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #20
	ld1.s	{ v21 }[1], [x8]
	tbz	w9, #6, LBB0_174
LBB0_248:                               ; %cond.load1235
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #24
	ld1.s	{ v21 }[2], [x8]
	tbnz	w9, #7, LBB0_175
	b	LBB0_176
LBB0_249:                               ; %cond.store1357
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s6, [x10]
	ldr	w12, [sp, #372]                 ; 4-byte Folded Reload
	ldr	w13, [sp, #368]                 ; 4-byte Folded Reload
	tbz	w9, #1, LBB0_228
LBB0_250:                               ; %cond.store1359
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #4
	st1.s	{ v6 }[1], [x8]
	tbz	w9, #2, LBB0_229
LBB0_251:                               ; %cond.store1361
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #8
	st1.s	{ v6 }[2], [x8]
	tbnz	w9, #3, LBB0_230
	b	LBB0_231
LBB0_252:                               ; %cond.store1365
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s2, [x10, #16]
	tbz	w9, #5, LBB0_233
LBB0_253:                               ; %cond.store1367
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #20
	st1.s	{ v2 }[1], [x8]
	tbz	w9, #6, LBB0_234
LBB0_254:                               ; %cond.store1369
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #24
	st1.s	{ v2 }[2], [x8]
	tbz	w9, #7, LBB0_2
LBB0_255:                               ; %cond.store1371
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x10, #28
	st1.s	{ v2 }[3], [x8]
	b	LBB0_2
LBB0_256:                               ; %block.batch.exit.loopexit
	stp	w0, w14, [x2]
	str	w13, [x2, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x2, #36]
LBB0_257:                               ; %block.batch.exit
	add	sp, sp, #1968
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
                                        ; -- End function
.subsections_via_symbols

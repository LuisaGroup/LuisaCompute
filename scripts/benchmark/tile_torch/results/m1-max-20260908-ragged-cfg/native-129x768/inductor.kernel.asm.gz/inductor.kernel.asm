
/private/tmp/luisa-ragged-cfg.pbUI2k/native-129x768/inductor/yg/cygdjjqsjvh3vp2cbj3o7av4tvbc7qefs6jq6or3nvlccxglrlnl.main.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006a8 <_kernel>:
     6a8:      	sub	sp, sp, #0xb0
     6ac:      	stp	d11, d10, [sp, #0x40]
     6b0:      	stp	d9, d8, [sp, #0x50]
     6b4:      	stp	x26, x25, [sp, #0x60]
     6b8:      	stp	x24, x23, [sp, #0x70]
     6bc:      	stp	x22, x21, [sp, #0x80]
     6c0:      	stp	x20, x19, [sp, #0x90]
     6c4:      	stp	x29, x30, [sp, #0xa0]
     6c8:      	add	x29, sp, #0xa0
     6cc:      	mov	x19, #0x0               ; =0
     6d0:      	str	wzr, [sp, #0x20]
     6d4:      	adrp	x20, 0x4000 <dyld_stub_binder+0x4000>
     6d8:      	ldr	x20, [x20, #0x90]
     6dc:      	add	x8, sp, #0x20
     6e0:      	str	x8, [x20]
     6e4:      	mov	w8, #0x44400000         ; =1145044992
     6e8:      	fmov	s8, w8
     6ec:      	mov	w8, #0xc5ac             ; =50604
     6f0:      	movk	w8, #0x3727, lsl #16
     6f4:      	fmov	s9, w8
     6f8:      	fmov	s10, #1.00000000
     6fc:      	b	0x714 <_kernel+0x6c>
     700:      	add	x19, x19, #0x1
     704:      	add	x0, x0, #0xc00
     708:      	add	x3, x3, #0xc00
     70c:      	cmp	x19, #0x81
     710:      	b.eq	0x7c8 <_kernel+0x120>
     714:      	movi.2d	v0, #0000000000000000
     718:      	mov	x8, #-0x4               ; =-4
     71c:      	mov	x9, x0
     720:      	ldr	q1, [x9], #0x10
     724:      	fmul.4s	v1, v1, v1
     728:      	fadd.4s	v0, v0, v1
     72c:      	add	x8, x8, #0x4
     730:      	cmp	x8, #0x2fc
     734:      	b.lo	0x720 <_kernel+0x78>
     738:      	mov	x21, #0x0               ; =0
     73c:      	dup.2d	v1, v0[1]
     740:      	fadd.4s	v0, v0, v1
     744:      	faddp.2s	s0, v0
     748:      	str	s0, [x2, x19, lsl #2]
     74c:      	mov	x22, #-0x4              ; =-4
     750:      	ldr	q2, [x0, x21]
     754:      	ldr	s0, [x2, x19, lsl #2]
     758:      	ldr	q3, [x1, x21]
     75c:      	fdiv	s0, s0, s8
     760:      	fadd	s1, s0, s9
     764:      	fsqrt	s0, s1
     768:      	fcmp	s0, s0
     76c:      	b.vs	0x794 <_kernel+0xec>
     770:      	fdiv	s0, s10, s0
     774:      	fmul.4s	v0, v2, v0[0]
     778:      	fmul.4s	v0, v3, v0
     77c:      	str	q0, [x3, x21]
     780:      	add	x22, x22, #0x4
     784:      	add	x21, x21, #0x10
     788:      	cmp	x22, #0x2fc
     78c:      	b.lo	0x750 <_kernel+0xa8>
     790:      	b	0x700 <_kernel+0x58>
     794:      	mov.16b	v0, v1
     798:      	mov	x23, x3
     79c:      	mov	x25, x2
     7a0:      	mov	x24, x1
     7a4:      	mov	x26, x0
     7a8:      	stp	q3, q2, [sp]
     7ac:      	bl	0x1768 <dyld_stub_binder+0x1768>
     7b0:      	ldp	q3, q2, [sp]
     7b4:      	mov	x0, x26
     7b8:      	mov	x1, x24
     7bc:      	mov	x2, x25
     7c0:      	mov	x3, x23
     7c4:      	b	0x770 <_kernel+0xc8>
     7c8:      	str	xzr, [x20]
     7cc:      	add	x8, sp, #0x20
     7d0:      	ldapr	w8, [x8]
     7d4:      	cbnz	w8, 0x7fc <_kernel+0x154>
     7d8:      	ldp	x29, x30, [sp, #0xa0]
     7dc:      	ldp	x20, x19, [sp, #0x90]
     7e0:      	ldp	x22, x21, [sp, #0x80]
     7e4:      	ldp	x24, x23, [sp, #0x70]
     7e8:      	ldp	x26, x25, [sp, #0x60]
     7ec:      	ldp	d9, d8, [sp, #0x50]
     7f0:      	ldp	d11, d10, [sp, #0x40]
     7f4:      	add	sp, sp, #0xb0
     7f8:      	ret
     7fc:      	mov	w0, #0x10               ; =16
     800:      	bl	0x16fc <dyld_stub_binder+0x16fc>
     804:      	mov	x19, x0
     808:      	mov	w8, #0x33d              ; =829
     80c:      	str	w8, [sp, #0x24]
     810:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     814:      	add	x0, x0, #0xa38
     818:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     81c:      	add	x1, x1, #0xac4
     820:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     824:      	add	x3, x3, #0xaef
     828:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     82c:      	add	x4, x4, #0xb6d
     830:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     834:      	add	x2, x2, #0xaec
     838:      	add	x8, sp, #0x28
     83c:      	add	x5, sp, #0x24
     840:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x38>
     844:      	add	x7, x7, #0xb6f
     848:      	mov	x6, x2
     84c:      	bl	0x8c0 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     850:      	mov	w21, #0x1               ; =1
     854:      	add	x1, sp, #0x28
     858:      	mov	x0, x19
     85c:      	bl	0x1648 <dyld_stub_binder+0x1648>
     860:      	mov	w21, #0x0               ; =0
     864:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     868:      	ldr	x1, [x1, #0x18]
     86c:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     870:      	ldr	x2, [x2, #0x8]
     874:      	mov	x0, x19
     878:      	bl	0x172c <dyld_stub_binder+0x172c>
     87c:      	brk	#0x1
     880:      	mov	x20, x0
     884:      	ldrsb	w8, [sp, #0x3f]
     888:      	tbz	w8, #0x1f, 0x8a4 <_kernel+0x1fc>
     88c:      	ldr	x0, [sp, #0x28]
     890:      	ldr	x8, [sp, #0x38]
     894:      	and	x1, x8, #0x7fffffffffffffff
     898:      	bl	0x16e4 <dyld_stub_binder+0x16e4>
     89c:      	tbnz	w21, #0x0, 0x8b0 <_kernel+0x208>
     8a0:      	b	0x8b8 <_kernel+0x210>
     8a4:      	cbnz	w21, 0x8b0 <_kernel+0x208>
     8a8:      	b	0x8b8 <_kernel+0x210>
     8ac:      	mov	x20, x0
     8b0:      	mov	x0, x19
     8b4:      	bl	0x1720 <dyld_stub_binder+0x1720>
     8b8:      	mov	x0, x20
     8bc:      	bl	0x160c <dyld_stub_binder+0x160c>

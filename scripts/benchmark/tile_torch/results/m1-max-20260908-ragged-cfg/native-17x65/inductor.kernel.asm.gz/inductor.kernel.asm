
/private/tmp/luisa-ragged-cfg.pbUI2k/native-17x65/inductor/yh/cyhuzwrm6vgeemgughw44mwhwghv755kvprb3qqx3mixdpovrpuk.main.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006a8 <_kernel>:
     6a8:      	sub	sp, sp, #0xe0
     6ac:      	stp	d11, d10, [sp, #0x60]
     6b0:      	stp	d9, d8, [sp, #0x70]
     6b4:      	stp	x28, x27, [sp, #0x80]
     6b8:      	stp	x26, x25, [sp, #0x90]
     6bc:      	stp	x24, x23, [sp, #0xa0]
     6c0:      	stp	x22, x21, [sp, #0xb0]
     6c4:      	stp	x20, x19, [sp, #0xc0]
     6c8:      	stp	x29, x30, [sp, #0xd0]
     6cc:      	add	x29, sp, #0xd0
     6d0:      	mov	x19, #0x0               ; =0
     6d4:      	str	wzr, [sp, #0x40]
     6d8:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     6dc:      	ldr	x9, [x9, #0x98]
     6e0:      	add	x8, sp, #0x40
     6e4:      	str	x8, [x9]
     6e8:      	mov	w21, #0x104             ; =260
     6ec:      	adrp	x22, 0x4000 <dyld_stub_binder+0x4000>
     6f0:      	ldr	x22, [x22, #0x80]
     6f4:      	movi.2d	v8, #0000000000000000
     6f8:      	mov	w8, #0x42820000         ; =1115815936
     6fc:      	fmov	s9, w8
     700:      	mov	w8, #0xc5ac             ; =50604
     704:      	movk	w8, #0x3727, lsl #16
     708:      	fmov	s10, w8
     70c:      	fmov	s11, #1.00000000
     710:      	mov	x23, x0
     714:      	mov	x20, x3
     718:      	b	0x760 <_kernel+0xb8>
     71c:      	ldr	s2, [x0, x25, lsl #2]
     720:      	ldr	s0, [x2, x19, lsl #2]
     724:      	ldr	s3, [x1, #0x100]
     728:      	fdiv	s0, s0, s9
     72c:      	fadd	s1, s0, s10
     730:      	fsqrt	s0, s1
     734:      	fcmp	s0, s0
     738:      	b.vs	0x8c4 <_kernel+0x21c>
     73c:      	fdiv	s0, s11, s0
     740:      	fmul	s0, s2, s0
     744:      	fmul	s0, s3, s0
     748:      	str	s0, [x3, x25, lsl #2]
     74c:      	add	x19, x19, #0x1
     750:      	add	x20, x20, #0x104
     754:      	add	x23, x23, #0x104
     758:      	cmp	x19, #0x11
     75c:      	b.eq	0x908 <_kernel+0x260>
     760:      	madd	x8, x19, x21, x0
     764:      	ldr	q0, [x22]
     768:      	ldp	q1, q2, [x8]
     76c:      	fmul.4s	v1, v1, v1
     770:      	fmul.4s	v2, v2, v2
     774:      	fadd.4s	v1, v1, v2
     778:      	ldp	q2, q3, [x8, #0x20]
     77c:      	fmul.4s	v2, v2, v2
     780:      	fadd.4s	v1, v1, v2
     784:      	fmul.4s	v2, v3, v3
     788:      	fadd.4s	v1, v1, v2
     78c:      	ldp	q2, q3, [x8, #0x40]
     790:      	fmul.4s	v2, v2, v2
     794:      	fadd.4s	v1, v1, v2
     798:      	fmul.4s	v2, v3, v3
     79c:      	fadd.4s	v1, v1, v2
     7a0:      	ldp	q2, q3, [x8, #0x60]
     7a4:      	fmul.4s	v2, v2, v2
     7a8:      	fadd.4s	v1, v1, v2
     7ac:      	fmul.4s	v2, v3, v3
     7b0:      	fadd.4s	v1, v1, v2
     7b4:      	ldp	q2, q3, [x8, #0x80]
     7b8:      	fmul.4s	v2, v2, v2
     7bc:      	fadd.4s	v1, v1, v2
     7c0:      	fmul.4s	v2, v3, v3
     7c4:      	fadd.4s	v1, v1, v2
     7c8:      	ldp	q2, q3, [x8, #0xa0]
     7cc:      	fmul.4s	v2, v2, v2
     7d0:      	fadd.4s	v1, v1, v2
     7d4:      	fmul.4s	v2, v3, v3
     7d8:      	fadd.4s	v1, v1, v2
     7dc:      	ldp	q2, q3, [x8, #0xc0]
     7e0:      	fmul.4s	v2, v2, v2
     7e4:      	fadd.4s	v1, v1, v2
     7e8:      	fmul.4s	v2, v3, v3
     7ec:      	fadd.4s	v1, v1, v2
     7f0:      	ldp	q2, q3, [x8, #0xe0]
     7f4:      	fmul.4s	v2, v2, v2
     7f8:      	fadd.4s	v1, v1, v2
     7fc:      	fmul.4s	v2, v3, v3
     800:      	fadd.4s	v1, v1, v2
     804:      	ldr	s2, [x8, #0x100]
     808:      	fmul	s2, s2, s2
     80c:      	movi.2d	v3, #0000000000000000
     810:      	mov.s	v3[0], v2[0]
     814:      	fadd.4s	v2, v1, v3
     818:      	bsl.16b	v0, v2, v1
     81c:      	dup.2d	v1, v0[1]
     820:      	fadd.4s	v0, v1, v0
     824:      	faddp.2s	s0, v0
     828:      	fadd	s0, s0, s8
     82c:      	str	s0, [x2, x19, lsl #2]
     830:      	add	x8, x19, x19, lsl #6
     834:      	add	x25, x8, #0x40
     838:      	mov	x26, #-0x4              ; =-4
     83c:      	mov	x27, x1
     840:      	mov	x28, x23
     844:      	mov	x24, x20
     848:      	cmp	x26, #0x3c
     84c:      	b.eq	0x71c <_kernel+0x74>
     850:      	ldr	s0, [x2, x19, lsl #2]
     854:      	ldr	q2, [x28]
     858:      	ldr	q3, [x27]
     85c:      	fdiv	s0, s0, s9
     860:      	fadd	s1, s0, s10
     864:      	fsqrt	s0, s1
     868:      	fcmp	s0, s0
     86c:      	b.vs	0x898 <_kernel+0x1f0>
     870:      	fdiv	s0, s11, s0
     874:      	fmul.4s	v0, v2, v0[0]
     878:      	fmul.4s	v0, v3, v0
     87c:      	str	q0, [x24], #0x10
     880:      	add	x28, x28, #0x10
     884:      	add	x27, x27, #0x10
     888:      	add	x26, x26, #0x4
     88c:      	cmp	x26, #0x3d
     890:      	b.lo	0x848 <_kernel+0x1a0>
     894:      	b	0x74c <_kernel+0xa4>
     898:      	mov.16b	v0, v1
     89c:      	stp	x1, x3, [sp, #0x30]
     8a0:      	stp	x0, x2, [sp, #0x20]
     8a4:      	stp	q3, q2, [sp]
     8a8:      	bl	0x18ac <dyld_stub_binder+0x18ac>
     8ac:      	ldp	q3, q2, [sp]
     8b0:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     8b4:      	ldr	x9, [x9, #0x98]
     8b8:      	ldp	x0, x2, [sp, #0x20]
     8bc:      	ldp	x1, x3, [sp, #0x30]
     8c0:      	b	0x870 <_kernel+0x1c8>
     8c4:      	mov.16b	v0, v1
     8c8:      	mov	x24, x3
     8cc:      	mov	x27, x2
     8d0:      	mov	x26, x1
     8d4:      	mov	x28, x0
     8d8:      	str	s2, [sp, #0x38]
     8dc:      	str	s3, [sp, #0x30]
     8e0:      	bl	0x18ac <dyld_stub_binder+0x18ac>
     8e4:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     8e8:      	ldr	x9, [x9, #0x98]
     8ec:      	ldr	s3, [sp, #0x30]
     8f0:      	ldr	s2, [sp, #0x38]
     8f4:      	mov	x0, x28
     8f8:      	mov	x1, x26
     8fc:      	mov	x2, x27
     900:      	mov	x3, x24
     904:      	b	0x73c <_kernel+0x94>
     908:      	str	xzr, [x9]
     90c:      	add	x8, sp, #0x40
     910:      	ldapr	w8, [x8]
     914:      	cbnz	w8, 0x940 <_kernel+0x298>
     918:      	ldp	x29, x30, [sp, #0xd0]
     91c:      	ldp	x20, x19, [sp, #0xc0]
     920:      	ldp	x22, x21, [sp, #0xb0]
     924:      	ldp	x24, x23, [sp, #0xa0]
     928:      	ldp	x26, x25, [sp, #0x90]
     92c:      	ldp	x28, x27, [sp, #0x80]
     930:      	ldp	d9, d8, [sp, #0x70]
     934:      	ldp	d11, d10, [sp, #0x60]
     938:      	add	sp, sp, #0xe0
     93c:      	ret
     940:      	mov	w0, #0x10               ; =16
     944:      	bl	0x1840 <dyld_stub_binder+0x1840>
     948:      	mov	x19, x0
     94c:      	mov	w8, #0x33d              ; =829
     950:      	str	w8, [sp, #0x44]
     954:      	adrp	x0, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x60>
     958:      	add	x0, x0, #0xb7c
     95c:      	adrp	x1, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x60>
     960:      	add	x1, x1, #0xc08
     964:      	adrp	x3, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x60>
     968:      	add	x3, x3, #0xc33
     96c:      	adrp	x4, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x60>
     970:      	add	x4, x4, #0xcb1
     974:      	adrp	x2, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x60>
     978:      	add	x2, x2, #0xc30
     97c:      	add	x8, sp, #0x48
     980:      	add	x5, sp, #0x44
     984:      	adrp	x7, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x60>
     988:      	add	x7, x7, #0xcb3
     98c:      	mov	x6, x2
     990:      	bl	0xa04 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     994:      	mov	w21, #0x1               ; =1
     998:      	add	x1, sp, #0x48
     99c:      	mov	x0, x19
     9a0:      	bl	0x178c <dyld_stub_binder+0x178c>
     9a4:      	mov	w21, #0x0               ; =0
     9a8:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     9ac:      	ldr	x1, [x1, #0x18]
     9b0:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     9b4:      	ldr	x2, [x2, #0x8]
     9b8:      	mov	x0, x19
     9bc:      	bl	0x1870 <dyld_stub_binder+0x1870>
     9c0:      	brk	#0x1
     9c4:      	mov	x20, x0
     9c8:      	ldrsb	w8, [sp, #0x5f]
     9cc:      	tbz	w8, #0x1f, 0x9e8 <_kernel+0x340>
     9d0:      	ldr	x0, [sp, #0x48]
     9d4:      	ldr	x8, [sp, #0x58]
     9d8:      	and	x1, x8, #0x7fffffffffffffff
     9dc:      	bl	0x1828 <dyld_stub_binder+0x1828>
     9e0:      	tbnz	w21, #0x0, 0x9f4 <_kernel+0x34c>
     9e4:      	b	0x9fc <_kernel+0x354>
     9e8:      	cbnz	w21, 0x9f4 <_kernel+0x34c>
     9ec:      	b	0x9fc <_kernel+0x354>
     9f0:      	mov	x20, x0
     9f4:      	mov	x0, x19
     9f8:      	bl	0x1864 <dyld_stub_binder+0x1864>
     9fc:      	mov	x0, x20
     a00:      	bl	0x1750 <dyld_stub_binder+0x1750>


/private/tmp/luisa-ragged-cfg.pbUI2k/native-1024x4097/inductor/oh/cohwsiyfpihsxsbv2loxydaneo5uxr7xwcaamt7m37roarpeg355.main.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006a8 <_kernel>:
     6a8:      	sub	sp, sp, #0xf0
     6ac:      	stp	d11, d10, [sp, #0x70]
     6b0:      	stp	d9, d8, [sp, #0x80]
     6b4:      	stp	x28, x27, [sp, #0x90]
     6b8:      	stp	x26, x25, [sp, #0xa0]
     6bc:      	stp	x24, x23, [sp, #0xb0]
     6c0:      	stp	x22, x21, [sp, #0xc0]
     6c4:      	stp	x20, x19, [sp, #0xd0]
     6c8:      	stp	x29, x30, [sp, #0xe0]
     6cc:      	add	x29, sp, #0xe0
     6d0:      	mov	x19, x3
     6d4:      	mov	x20, x2
     6d8:      	mov	x21, x1
     6dc:      	mov	x24, x0
     6e0:      	mov	x23, #0x0               ; =0
     6e4:      	str	wzr, [sp, #0x68]
     6e8:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     6ec:      	ldr	x9, [x9, #0x98]
     6f0:      	add	x8, sp, #0x68
     6f4:      	str	x8, [x9]
     6f8:      	mov	w27, #0x4004            ; =16388
     6fc:      	mov	w8, #0x800              ; =2048
     700:      	movk	w8, #0x4580, lsl #16
     704:      	fmov	s8, w8
     708:      	mov	w8, #0xc5ac             ; =50604
     70c:      	movk	w8, #0x3727, lsl #16
     710:      	fmov	s9, w8
     714:      	fmov	s10, #1.00000000
     718:      	str	x3, [sp, #0x28]
     71c:      	mov	x22, x0
     720:      	b	0x770 <_kernel+0xc8>
     724:      	ldr	s2, [x24, x25, lsl #2]
     728:      	ldr	s0, [x20, x23, lsl #2]
     72c:      	add	x8, x21, #0x4, lsl #12  ; =0x4000
     730:      	ldr	s3, [x8]
     734:      	fdiv	s0, s0, s8
     738:      	fadd	s1, s0, s9
     73c:      	fsqrt	s0, s1
     740:      	fcmp	s0, s0
     744:      	b.vs	0x9dc <_kernel+0x334>
     748:      	fdiv	s0, s10, s0
     74c:      	fmul	s0, s2, s0
     750:      	fmul	s0, s3, s0
     754:      	ldr	x8, [sp, #0x28]
     758:      	str	s0, [x8, x25, lsl #2]
     75c:      	add	x23, x23, #0x1
     760:      	add	x22, x22, x27
     764:      	add	x19, x19, x27
     768:      	cmp	x23, #0x400
     76c:      	b.eq	0x9f8 <_kernel+0x350>
     770:      	movi.2d	v0, #0000000000000000
     774:      	stp	q0, q0, [sp, #0x40]
     778:      	str	q0, [sp, #0x30]
     77c:      	mov	w8, #0x1                ; =1
     780:      	str	x8, [sp, #0x48]
     784:      	str	wzr, [sp, #0x6c]
     788:      	add	x0, sp, #0x30
     78c:      	add	x2, sp, #0x6c
     790:      	mov	w1, #0x1                ; =1
     794:      	bl	0xb28 <__ZNSt3__16vectorIfNS_9allocatorIfEEE6assignEmRKf>
     798:      	madd	x8, x23, x27, x24
     79c:      	add	x8, x8, #0x4, lsl #12   ; =0x4000
     7a0:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
     7a4:      	ldr	x9, [x9, #0x80]
     7a8:      	ldr	q1, [x9]
     7ac:      	movi.2d	v0, #0000000000000000
     7b0:      	mov	x9, #-0x4               ; =-4
     7b4:      	mov	x10, x22
     7b8:      	cmp	x9, #0xffc
     7bc:      	b.eq	0x9a4 <_kernel+0x2fc>
     7c0:      	ldr	q2, [x10], #0x10
     7c4:      	fmul.4s	v2, v2, v2
     7c8:      	fadd.4s	v0, v0, v2
     7cc:      	add	x9, x9, #0x4
     7d0:      	cmp	x9, #0xffd
     7d4:      	b.lo	0x7b8 <_kernel+0x110>
     7d8:      	ldr	x8, [sp, #0x30]
     7dc:      	ldr	x9, [sp, #0x48]
     7e0:      	ldr	s1, [x8]
     7e4:      	cmp	x9, #0x2
     7e8:      	b.lo	0x908 <_kernel+0x260>
     7ec:      	cmp	x9, #0x5
     7f0:      	b.hs	0x7fc <_kernel+0x154>
     7f4:      	mov	w12, #0x1               ; =1
     7f8:      	b	0x8f0 <_kernel+0x248>
     7fc:      	sub	x10, x9, #0x1
     800:      	cmp	x9, #0x11
     804:      	b.hs	0x810 <_kernel+0x168>
     808:      	mov	x11, #0x0               ; =0
     80c:      	b	0x8ac <_kernel+0x204>
     810:      	and	x12, x10, #0xc
     814:      	and	x11, x10, #0xfffffffffffffff0
     818:      	add	x13, x8, #0x24
     81c:      	and	x14, x10, #0xfffffffffffffff0
     820:      	ldp	q2, q3, [x13, #-0x20]
     824:      	mov	s4, v2[3]
     828:      	mov	s5, v2[2]
     82c:      	mov	s6, v2[1]
     830:      	mov	s7, v3[3]
     834:      	mov	s16, v3[2]
     838:      	mov	s17, v3[1]
     83c:      	ldp	q18, q19, [x13], #0x40
     840:      	mov	s20, v18[3]
     844:      	mov	s21, v18[2]
     848:      	mov	s22, v18[1]
     84c:      	mov	s23, v19[3]
     850:      	mov	s24, v19[2]
     854:      	mov	s25, v19[1]
     858:      	fadd	s1, s1, s2
     85c:      	fadd	s1, s1, s6
     860:      	fadd	s1, s1, s5
     864:      	fadd	s1, s1, s4
     868:      	fadd	s1, s1, s3
     86c:      	fadd	s1, s1, s17
     870:      	fadd	s1, s1, s16
     874:      	fadd	s1, s1, s7
     878:      	fadd	s1, s1, s18
     87c:      	fadd	s1, s1, s22
     880:      	fadd	s1, s1, s21
     884:      	fadd	s1, s1, s20
     888:      	fadd	s1, s1, s19
     88c:      	fadd	s1, s1, s25
     890:      	fadd	s1, s1, s24
     894:      	fadd	s1, s1, s23
     898:      	subs	x14, x14, #0x10
     89c:      	b.ne	0x820 <_kernel+0x178>
     8a0:      	cmp	x10, x11
     8a4:      	b.eq	0x908 <_kernel+0x260>
     8a8:      	cbz	x12, 0x9d4 <_kernel+0x32c>
     8ac:      	and	x13, x10, #0xfffffffffffffffc
     8b0:      	orr	x12, x13, #0x1
     8b4:      	add	x14, x8, x11, lsl #2
     8b8:      	add	x14, x14, #0x4
     8bc:      	sub	x11, x11, x13
     8c0:      	ldr	q2, [x14], #0x10
     8c4:      	mov	s3, v2[3]
     8c8:      	mov	s4, v2[2]
     8cc:      	mov	s5, v2[1]
     8d0:      	fadd	s1, s1, s2
     8d4:      	fadd	s1, s1, s5
     8d8:      	fadd	s1, s1, s4
     8dc:      	fadd	s1, s1, s3
     8e0:      	adds	x11, x11, #0x4
     8e4:      	b.ne	0x8c0 <_kernel+0x218>
     8e8:      	cmp	x10, x13
     8ec:      	b.eq	0x908 <_kernel+0x260>
     8f0:      	sub	x9, x9, x12
     8f4:      	add	x8, x8, x12, lsl #2
     8f8:      	ldr	s2, [x8], #0x4
     8fc:      	fadd	s1, s1, s2
     900:      	subs	x9, x9, #0x1
     904:      	b.ne	0x8f8 <_kernel+0x250>
     908:      	dup.2d	v2, v0[1]
     90c:      	fadd.4s	v0, v0, v2
     910:      	faddp.2s	s0, v0
     914:      	fadd	s0, s1, s0
     918:      	str	s0, [x20, x23, lsl #2]
     91c:      	ldr	x0, [sp, #0x30]
     920:      	cbz	x0, 0x934 <_kernel+0x28c>
     924:      	str	x0, [sp, #0x38]
     928:      	ldr	x8, [sp, #0x40]
     92c:      	sub	x1, x8, x0
     930:      	bl	0x1c1c <dyld_stub_binder+0x1c1c>
     934:      	mov	x26, #0x0               ; =0
     938:      	add	x8, x23, x23, lsl #12
     93c:      	add	x25, x8, #0x1, lsl #12  ; =0x1000
     940:      	mov	x28, #-0x4              ; =-4
     944:      	cmp	x28, #0xffc
     948:      	b.eq	0x724 <_kernel+0x7c>
     94c:      	ldr	q2, [x22, x26]
     950:      	ldr	s0, [x20, x23, lsl #2]
     954:      	ldr	q3, [x21, x26]
     958:      	fdiv	s0, s0, s8
     95c:      	fadd	s1, s0, s9
     960:      	fsqrt	s0, s1
     964:      	fcmp	s0, s0
     968:      	b.vs	0x990 <_kernel+0x2e8>
     96c:      	fdiv	s0, s10, s0
     970:      	fmul.4s	v0, v2, v0[0]
     974:      	fmul.4s	v0, v3, v0
     978:      	str	q0, [x19, x26]
     97c:      	add	x26, x26, #0x10
     980:      	add	x28, x28, #0x4
     984:      	cmp	x28, #0xffd
     988:      	b.lo	0x944 <_kernel+0x29c>
     98c:      	b	0x75c <_kernel+0xb4>
     990:      	mov.16b	v0, v1
     994:      	stp	q3, q2, [sp]
     998:      	bl	0x1ca0 <dyld_stub_binder+0x1ca0>
     99c:      	ldp	q3, q2, [sp]
     9a0:      	b	0x96c <_kernel+0x2c4>
     9a4:      	ldr	s2, [x8]
     9a8:      	fmul	s2, s2, s2
     9ac:      	movi.2d	v3, #0000000000000000
     9b0:      	mov.s	v3[0], v2[0]
     9b4:      	and.16b	v1, v1, v3
     9b8:      	fadd.4s	v0, v0, v1
     9bc:      	ldr	x8, [sp, #0x30]
     9c0:      	ldr	x9, [sp, #0x48]
     9c4:      	ldr	s1, [x8]
     9c8:      	cmp	x9, #0x2
     9cc:      	b.hs	0x7ec <_kernel+0x144>
     9d0:      	b	0x908 <_kernel+0x260>
     9d4:      	orr	x12, x11, #0x1
     9d8:      	b	0x8f0 <_kernel+0x248>
     9dc:      	mov.16b	v0, v1
     9e0:      	str	s2, [sp, #0x10]
     9e4:      	str	s3, [sp]
     9e8:      	bl	0x1ca0 <dyld_stub_binder+0x1ca0>
     9ec:      	ldr	s3, [sp]
     9f0:      	ldr	s2, [sp, #0x10]
     9f4:      	b	0x748 <_kernel+0xa0>
     9f8:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     9fc:      	ldr	x8, [x8, #0x98]
     a00:      	str	xzr, [x8]
     a04:      	add	x8, sp, #0x68
     a08:      	ldapr	w8, [x8]
     a0c:      	cbnz	w8, 0xa38 <_kernel+0x390>
     a10:      	ldp	x29, x30, [sp, #0xe0]
     a14:      	ldp	x20, x19, [sp, #0xd0]
     a18:      	ldp	x22, x21, [sp, #0xc0]
     a1c:      	ldp	x24, x23, [sp, #0xb0]
     a20:      	ldp	x26, x25, [sp, #0xa0]
     a24:      	ldp	x28, x27, [sp, #0x90]
     a28:      	ldp	d9, d8, [sp, #0x80]
     a2c:      	ldp	d11, d10, [sp, #0x70]
     a30:      	add	sp, sp, #0xf0
     a34:      	ret
     a38:      	mov	w0, #0x10               ; =16
     a3c:      	bl	0x1c34 <dyld_stub_binder+0x1c34>
     a40:      	mov	x19, x0
     a44:      	mov	w8, #0x33d              ; =829
     a48:      	str	w8, [sp, #0x6c]
     a4c:      	adrp	x0, 0x1000 <__ZN3c106detail12_str_wrapperIJPKcS3_S3_S3_RKiS3_S3_EE4callERKS3_S8_S8_S8_S5_S8_S8_+0x13c>
     a50:      	add	x0, x0, #0xf7f
     a54:      	adrp	x1, 0x2000 <dyld_stub_binder+0x2000>
     a58:      	add	x1, x1, #0xb
     a5c:      	adrp	x3, 0x2000 <dyld_stub_binder+0x2000>
     a60:      	add	x3, x3, #0x36
     a64:      	adrp	x4, 0x2000 <dyld_stub_binder+0x2000>
     a68:      	add	x4, x4, #0xb4
     a6c:      	adrp	x2, 0x2000 <dyld_stub_binder+0x2000>
     a70:      	add	x2, x2, #0x33
     a74:      	add	x8, sp, #0x30
     a78:      	add	x5, sp, #0x6c
     a7c:      	adrp	x7, 0x2000 <dyld_stub_binder+0x2000>
     a80:      	add	x7, x7, #0xb6
     a84:      	mov	x6, x2
     a88:      	bl	0xe7c <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     a8c:      	mov	w21, #0x1               ; =1
     a90:      	add	x1, sp, #0x30
     a94:      	mov	x0, x19
     a98:      	bl	0x1b80 <dyld_stub_binder+0x1b80>
     a9c:      	mov	w21, #0x0               ; =0
     aa0:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     aa4:      	ldr	x1, [x1, #0x18]
     aa8:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     aac:      	ldr	x2, [x2, #0x8]
     ab0:      	mov	x0, x19
     ab4:      	bl	0x1c64 <dyld_stub_binder+0x1c64>
     ab8:      	brk	#0x1
     abc:      	mov	x20, x0
     ac0:      	ldrsb	w8, [sp, #0x47]
     ac4:      	tbz	w8, #0x1f, 0xae0 <_kernel+0x438>
     ac8:      	ldr	x0, [sp, #0x30]
     acc:      	ldr	x8, [sp, #0x40]
     ad0:      	and	x1, x8, #0x7fffffffffffffff
     ad4:      	bl	0x1c1c <dyld_stub_binder+0x1c1c>
     ad8:      	tbnz	w21, #0x0, 0xaec <_kernel+0x444>
     adc:      	b	0xb08 <_kernel+0x460>
     ae0:      	cbnz	w21, 0xaec <_kernel+0x444>
     ae4:      	b	0xb08 <_kernel+0x460>
     ae8:      	mov	x20, x0
     aec:      	mov	x0, x19
     af0:      	bl	0x1c58 <dyld_stub_binder+0x1c58>
     af4:      	mov	x0, x20
     af8:      	bl	0x1b44 <dyld_stub_binder+0x1b44>
     afc:      	mov	x20, x0
     b00:      	ldr	x0, [sp, #0x30]
     b04:      	cbnz	x0, 0xb10 <_kernel+0x468>
     b08:      	mov	x0, x20
     b0c:      	bl	0x1b44 <dyld_stub_binder+0x1b44>
     b10:      	str	x0, [sp, #0x38]
     b14:      	ldr	x8, [sp, #0x40]
     b18:      	sub	x1, x8, x0
     b1c:      	bl	0x1c1c <dyld_stub_binder+0x1c1c>
     b20:      	mov	x0, x20
     b24:      	bl	0x1b44 <dyld_stub_binder+0x1b44>

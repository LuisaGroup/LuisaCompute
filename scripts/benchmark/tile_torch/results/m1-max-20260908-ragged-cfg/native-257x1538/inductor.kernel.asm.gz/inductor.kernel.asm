
/private/tmp/luisa-ragged-cfg.pbUI2k/native-257x1538/inductor/2u/c2utptxdervntjtedme5grohjlvbrntjb7kpxlavmamlhnem6idq.main.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006a8 <_kernel>:
     6a8:      	sub	sp, sp, #0xc0
     6ac:      	stp	d11, d10, [sp, #0x40]
     6b0:      	stp	d9, d8, [sp, #0x50]
     6b4:      	stp	x28, x27, [sp, #0x60]
     6b8:      	stp	x26, x25, [sp, #0x70]
     6bc:      	stp	x24, x23, [sp, #0x80]
     6c0:      	stp	x22, x21, [sp, #0x90]
     6c4:      	stp	x20, x19, [sp, #0xa0]
     6c8:      	stp	x29, x30, [sp, #0xb0]
     6cc:      	add	x29, sp, #0xb0
     6d0:      	mov	x19, #0x0               ; =0
     6d4:      	adrp	x20, 0x4000 <dyld_stub_binder+0x4000>
     6d8:      	ldr	x20, [x20, #0x98]
     6dc:      	str	wzr, [sp, #0x20]
     6e0:      	add	x8, sp, #0x20
     6e4:      	str	x8, [x20]
     6e8:      	adrp	x21, 0x4000 <dyld_stub_binder+0x4000>
     6ec:      	ldr	x21, [x21, #0x80]
     6f0:      	movi.2d	v8, #0000000000000000
     6f4:      	mov	w8, #0x4000             ; =16384
     6f8:      	movk	w8, #0x44c0, lsl #16
     6fc:      	fmov	s9, w8
     700:      	mov	w8, #0xc5ac             ; =50604
     704:      	movk	w8, #0x3727, lsl #16
     708:      	fmov	s10, w8
     70c:      	fmov	s11, #1.00000000
     710:      	mov	w22, #0x1808            ; =6152
     714:      	b	0x750 <_kernel+0xa8>
     718:      	ldr	d3, [x0, x23]
     71c:      	ldr	d2, [x1, x23]
     720:      	fsqrt	s1, s0
     724:      	fcmp	s1, s1
     728:      	b.vs	0x834 <_kernel+0x18c>
     72c:      	fdiv	s0, s11, s1
     730:      	fmul.2s	v0, v3, v0[0]
     734:      	fmul.2s	v0, v2, v0
     738:      	str	d0, [x3, x23]
     73c:      	add	x19, x19, #0x1
     740:      	add	x0, x0, x22
     744:      	add	x3, x3, x22
     748:      	cmp	x19, #0x101
     74c:      	b.eq	0x870 <_kernel+0x1c8>
     750:      	ldr	q1, [x21]
     754:      	movi.2d	v0, #0000000000000000
     758:      	mov	x8, #-0x4               ; =-4
     75c:      	mov	x9, x0
     760:      	add	x8, x8, #0x4
     764:      	cmp	x8, #0x600
     768:      	b.hs	0x820 <_kernel+0x178>
     76c:      	ldr	q2, [x9], #0x10
     770:      	fmul.4s	v2, v2, v2
     774:      	fadd.4s	v0, v0, v2
     778:      	cmp	x8, #0x5fe
     77c:      	b.lo	0x760 <_kernel+0xb8>
     780:      	mov	x23, #0x0               ; =0
     784:      	dup.2d	v1, v0[1]
     788:      	fadd.4s	v0, v0, v1
     78c:      	faddp.2s	s0, v0
     790:      	fadd	s0, s0, s8
     794:      	str	s0, [x2, x19, lsl #2]
     798:      	mov	x24, #-0x4              ; =-4
     79c:      	add	x8, x24, #0x4
     7a0:      	ldr	s0, [x2, x19, lsl #2]
     7a4:      	fdiv	s0, s0, s9
     7a8:      	fadd	s0, s0, s10
     7ac:      	cmp	x8, #0x600
     7b0:      	b.hs	0x718 <_kernel+0x70>
     7b4:      	ldr	q2, [x0, x23]
     7b8:      	ldr	q3, [x1, x23]
     7bc:      	fsqrt	s1, s0
     7c0:      	fcmp	s1, s1
     7c4:      	b.vs	0x7ec <_kernel+0x144>
     7c8:      	fdiv	s0, s11, s1
     7cc:      	fmul.4s	v0, v2, v0[0]
     7d0:      	fmul.4s	v0, v3, v0
     7d4:      	str	q0, [x3, x23]
     7d8:      	add	x23, x23, #0x10
     7dc:      	add	x24, x24, #0x4
     7e0:      	cmp	x24, #0x5fe
     7e4:      	b.lo	0x79c <_kernel+0xf4>
     7e8:      	b	0x73c <_kernel+0x94>
     7ec:      	mov	x25, x3
     7f0:      	mov	x27, x2
     7f4:      	mov	x26, x1
     7f8:      	mov	x28, x0
     7fc:      	stp	q3, q2, [sp]
     800:      	bl	0x1814 <dyld_stub_binder+0x1814>
     804:      	ldp	q3, q2, [sp]
     808:      	mov	x0, x28
     80c:      	mov	x1, x26
     810:      	mov	x2, x27
     814:      	mov	x3, x25
     818:      	mov.16b	v1, v0
     81c:      	b	0x7c8 <_kernel+0x120>
     820:      	ldr	d2, [x9]
     824:      	fmul.4s	v2, v2, v2
     828:      	fadd.4s	v2, v0, v2
     82c:      	bit.16b	v0, v2, v1
     830:      	b	0x780 <_kernel+0xd8>
     834:      	mov	x24, x3
     838:      	mov	x26, x2
     83c:      	mov	x25, x1
     840:      	mov	x27, x0
     844:      	str	d3, [sp, #0x10]
     848:      	str	d2, [sp]
     84c:      	bl	0x1814 <dyld_stub_binder+0x1814>
     850:      	ldr	d2, [sp]
     854:      	ldr	d3, [sp, #0x10]
     858:      	mov	x0, x27
     85c:      	mov	x1, x25
     860:      	mov	x2, x26
     864:      	mov	x3, x24
     868:      	mov.16b	v1, v0
     86c:      	b	0x72c <_kernel+0x84>
     870:      	str	xzr, [x20]
     874:      	add	x8, sp, #0x20
     878:      	ldapr	w8, [x8]
     87c:      	cbnz	w8, 0x8a8 <_kernel+0x200>
     880:      	ldp	x29, x30, [sp, #0xb0]
     884:      	ldp	x20, x19, [sp, #0xa0]
     888:      	ldp	x22, x21, [sp, #0x90]
     88c:      	ldp	x24, x23, [sp, #0x80]
     890:      	ldp	x26, x25, [sp, #0x70]
     894:      	ldp	x28, x27, [sp, #0x60]
     898:      	ldp	d9, d8, [sp, #0x50]
     89c:      	ldp	d11, d10, [sp, #0x40]
     8a0:      	add	sp, sp, #0xc0
     8a4:      	ret
     8a8:      	mov	w0, #0x10               ; =16
     8ac:      	bl	0x17a8 <dyld_stub_binder+0x17a8>
     8b0:      	mov	x19, x0
     8b4:      	mov	w8, #0x33d              ; =829
     8b8:      	str	w8, [sp, #0x24]
     8bc:      	adrp	x0, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf8>
     8c0:      	add	x0, x0, #0xae4
     8c4:      	adrp	x1, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf8>
     8c8:      	add	x1, x1, #0xb70
     8cc:      	adrp	x3, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf8>
     8d0:      	add	x3, x3, #0xb9b
     8d4:      	adrp	x4, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf8>
     8d8:      	add	x4, x4, #0xc19
     8dc:      	adrp	x2, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf8>
     8e0:      	add	x2, x2, #0xb98
     8e4:      	add	x8, sp, #0x28
     8e8:      	add	x5, sp, #0x24
     8ec:      	adrp	x7, 0x1000 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf8>
     8f0:      	add	x7, x7, #0xc1b
     8f4:      	mov	x6, x2
     8f8:      	bl	0x96c <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     8fc:      	mov	w21, #0x1               ; =1
     900:      	add	x1, sp, #0x28
     904:      	mov	x0, x19
     908:      	bl	0x16f4 <dyld_stub_binder+0x16f4>
     90c:      	mov	w21, #0x0               ; =0
     910:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     914:      	ldr	x1, [x1, #0x18]
     918:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     91c:      	ldr	x2, [x2, #0x8]
     920:      	mov	x0, x19
     924:      	bl	0x17d8 <dyld_stub_binder+0x17d8>
     928:      	brk	#0x1
     92c:      	mov	x20, x0
     930:      	ldrsb	w8, [sp, #0x3f]
     934:      	tbz	w8, #0x1f, 0x950 <_kernel+0x2a8>
     938:      	ldr	x0, [sp, #0x28]
     93c:      	ldr	x8, [sp, #0x38]
     940:      	and	x1, x8, #0x7fffffffffffffff
     944:      	bl	0x1790 <dyld_stub_binder+0x1790>
     948:      	tbnz	w21, #0x0, 0x95c <_kernel+0x2b4>
     94c:      	b	0x964 <_kernel+0x2bc>
     950:      	cbnz	w21, 0x95c <_kernel+0x2b4>
     954:      	b	0x964 <_kernel+0x2bc>
     958:      	mov	x20, x0
     95c:      	mov	x0, x19
     960:      	bl	0x17cc <dyld_stub_binder+0x17cc>
     964:      	mov	x0, x20
     968:      	bl	0x16b8 <dyld_stub_binder+0x16b8>

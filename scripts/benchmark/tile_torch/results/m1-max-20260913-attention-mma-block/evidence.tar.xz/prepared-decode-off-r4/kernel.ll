; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca i64, align 8
  store i64 0, ptr %.slot33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %.spill44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca i64, align 8
  store i64 0, ptr %.slot48, align 4
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca i64, align 8
  store i64 0, ptr %.slot50, align 4
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca i64, align 8
  store i64 0, ptr %.slot52, align 4
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca i64, align 8
  store i64 0, ptr %.slot54, align 4
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca i64, align 8
  store i64 0, ptr %.slot58, align 4
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca i64, align 8
  store i64 0, ptr %.slot60, align 4
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca i64, align 8
  store i64 0, ptr %.slot62, align 4
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca i64, align 8
  store i64 0, ptr %.slot64, align 4
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.slot66 = alloca i64, align 8
  store i64 0, ptr %.slot66, align 4
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca i64, align 8
  store i64 0, ptr %.slot68, align 4
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca i64, align 8
  store i64 0, ptr %.slot70, align 4
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca i64, align 8
  store i64 0, ptr %.slot72, align 4
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca i64, align 8
  store i64 0, ptr %.slot74, align 4
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca i64, align 8
  store i64 0, ptr %.slot76, align 4
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.spill78 = alloca i64, align 8
  store i64 0, ptr %.spill78, align 4
  %.spill79 = alloca i1, align 1
  store i1 false, ptr %.spill79, align 1
  %.spill80 = alloca i1, align 1
  store i1 false, ptr %.spill80, align 1
  %.spill81 = alloca i1, align 1
  store i1 false, ptr %.spill81, align 1
  %.spill82 = alloca i1, align 1
  store i1 false, ptr %.spill82, align 1
  %.spill83 = alloca i1, align 1
  store i1 false, ptr %.spill83, align 1
  %.spill84 = alloca i1, align 1
  store i1 false, ptr %.spill84, align 1
  %.spill85 = alloca i1, align 1
  store i1 false, ptr %.spill85, align 1
  %.spill86 = alloca i1, align 1
  store i1 false, ptr %.spill86, align 1
  %.spill87 = alloca i1, align 1
  store i1 false, ptr %.spill87, align 1
  %.spill88 = alloca i1, align 1
  store i1 false, ptr %.spill88, align 1
  %.spill89 = alloca i1, align 1
  store i1 false, ptr %.spill89, align 1
  %.spill90 = alloca i1, align 1
  store i1 false, ptr %.spill90, align 1
  %.spill91 = alloca i1, align 1
  store i1 false, ptr %.spill91, align 1
  %.spill92 = alloca i1, align 1
  store i1 false, ptr %.spill92, align 1
  %.spill93 = alloca i1, align 1
  store i1 false, ptr %.spill93, align 1
  %.spill94 = alloca i1, align 1
  store i1 false, ptr %.spill94, align 1
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %.spill101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %.spill104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill104, align 32
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.spill106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill106, align 32
  %.spill107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %.spill109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill109, align 32
  %.spill110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill110, align 32
  %tile_snapshot.spill111 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill111, align 64
  %.slot112 = alloca i64, align 8
  store i64 0, ptr %.slot112, align 4
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.spill114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %.spill116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill116, align 32
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.spill118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill118, align 32
  %.spill119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %.spill121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill121, align 32
  %.spill122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill122, align 32
  %.spill123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill123, align 32
  %.spill124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill124, align 32
  %.spill125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %.spill131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill131, align 32
  %tile_snapshot.spill132 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill132, align 64
  %.spill133 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill133, align 32
  %.slot134 = alloca i64, align 8
  store i64 0, ptr %.slot134, align 4
  %.slot135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot135, align 32
  %.spill136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill136, align 32
  %tile_snapshot.spill137 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill137, align 64
  %.slot138 = alloca i64, align 8
  store i64 0, ptr %.slot138, align 4
  %.slot139 = alloca i64, align 8
  store i64 0, ptr %.slot139, align 4
  %.slot140 = alloca i64, align 8
  store i64 0, ptr %.slot140, align 4
  %.slot141 = alloca i64, align 8
  store i64 0, ptr %.slot141, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert142 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat143 = shufflevector <8 x i32> %.splatinsert142, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat143, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert144 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat145 = shufflevector <8 x i32> %.splatinsert144, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat145, %61
  %64 = mul i32 %52, 1
  %.splatinsert146 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat147 = shufflevector <8 x i32> %.splatinsert146, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat147, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert148 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat149 = shufflevector <8 x i32> %.splatinsert148, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat149, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert150 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat151 = shufflevector <8 x i32> %.splatinsert150, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat151
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %94 = icmp slt i64 %.state, 80
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load i64, ptr %.spill29, align 4
  %95 = add i64 %.spill.load, 0
  %.spill.load152 = load <8 x i64>, ptr %.spill, align 64
  %96 = add <8 x i64> %.spill.load152, zeroinitializer
  %97 = mul i64 %95, 8
  %.splatinsert153 = insertelement <8 x i64> poison, i64 %97, i64 0
  %.splat154 = shufflevector <8 x i64> %.splatinsert153, <8 x i64> poison, <8 x i32> zeroinitializer
  %98 = add <8 x i64> %.splat154, %96
  %.spill.load155 = load i64, ptr %.spill29, align 4
  %99 = add i64 %.spill.load155, 0
  %100 = mul <8 x i64> %98, splat (i64 1)
  %.splatinsert156 = insertelement <8 x i64> poison, i64 %99, i64 0
  %.splat157 = shufflevector <8 x i64> %.splatinsert156, <8 x i64> poison, <8 x i32> zeroinitializer
  %101 = add <8 x i64> %100, %.splat157
  %.state158 = load i64, ptr %.slot, align 4
  %102 = add i64 0, %.state158
  %103 = mul <8 x i64> %101, splat (i64 80)
  %.splatinsert159 = insertelement <8 x i64> poison, i64 %102, i64 0
  %.splat160 = shufflevector <8 x i64> %.splatinsert159, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = add <8 x i64> %103, %.splat160
  %105 = extractvalue { ptr, i64 } %29, 0
  %106 = mul <8 x i64> %104, splat (i64 4)
  %107 = getelementptr i8, ptr %105, <8 x i64> %106
  %108 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %107, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state161 = load i64, ptr %.slot, align 4
  %.splatinsert162 = insertelement <8 x i64> poison, i64 %.state161, i64 0
  %.splat163 = shufflevector <8 x i64> %.splatinsert162, <8 x i64> poison, <8 x i32> zeroinitializer
  %111 = mul <8 x i64> %.splat163, splat (i64 32)
  %112 = add <8 x i64> %110, %111
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %114, 1
  %117 = extractelement <8 x ptr> %115, i32 0
  %118 = extractelement <8 x i64> %116, i32 0
  %119 = sub i64 %118, 0
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %121 = select i1 %120, i64 %119, i64 0
  %private.contiguous.address = getelementptr i8, ptr %117, i64 %121
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %122 = select <8 x i1> %71, <8 x float> %108, <8 x float> %private.contiguous.preserve
  store <8 x float> %122, ptr %private.contiguous.address, align 4
  %.state164 = load i64, ptr %.slot, align 4
  %123 = add i64 %.state164, 1
  store i64 %123, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill31, align 64
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %71, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %71, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %tile_snapshot.spill32, align 64
  store i64 0, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state165 = load i64, ptr %.slot33, align 4
  %142 = icmp slt i64 %.state165, 96
  br i1 %142, label %direct.true166, label %direct.false167

direct.schedule.5:                                ; preds = %direct.true166
  %tile_snapshot.spill.load168 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load168, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load168, 1
  %.state169 = load i64, ptr %.slot33, align 4
  %.splatinsert170 = insertelement <8 x i64> poison, i64 %.state169, i64 0
  %.splat171 = shufflevector <8 x i64> %.splatinsert170, <8 x i64> poison, <8 x i32> zeroinitializer
  %145 = mul <8 x i64> %.splat171, splat (i64 32)
  %146 = add <8 x i64> %144, %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %151 = extractelement <8 x ptr> %149, i32 0
  %152 = extractelement <8 x i64> %150, i32 0
  %153 = sub i64 %152, 0
  %154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %155 = select i1 %154, i64 %153, i64 0
  %private.contiguous.address172 = getelementptr i8, ptr %151, i64 %155
  %private.contiguous.preserve173 = load <8 x float>, ptr %private.contiguous.address172, align 4
  %156 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve173
  store <8 x float> %156, ptr %private.contiguous.address172, align 4
  %.state174 = load i64, ptr %.slot33, align 4
  %157 = add i64 %.state174, 1
  store i64 %157, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false167
  store i64 0, ptr %.slot34, align 4
  %158 = load <8 x float>, ptr %.slot35, align 32
  %159 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %158
  store <8 x float> %159, ptr %.slot35, align 32
  %160 = load <8 x float>, ptr %.slot36, align 32
  %161 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %160
  store <8 x float> %161, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.81, %direct.schedule.6
  %.state175 = load i64, ptr %.slot34, align 4
  %162 = icmp slt i64 %.state175, 129
  br i1 %162, label %direct.true176, label %direct.false177

direct.schedule.8:                                ; preds = %direct.true176
  %.state178 = load i64, ptr %.slot34, align 4
  %163 = sdiv i64 %.state178, 1
  %164 = mul i64 %163, 16
  store i64 %164, ptr %.spill37, align 4
  %165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %168 = select <8 x i1> %71, <8 x ptr> %166, <8 x ptr> %167
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %171 = select <8 x i1> %71, <8 x i64> %169, <8 x i64> %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  store { <8 x ptr>, <8 x i64> } %173, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state179 = load i64, ptr %.slot39, align 4
  %174 = icmp slt i64 %.state179, 1280
  br i1 %174, label %direct.true180, label %direct.false181

direct.schedule.10:                               ; preds = %direct.true180
  %.state182 = load i64, ptr %.slot39, align 4
  %175 = srem i64 %.state182, 80
  %.state183 = load i64, ptr %.slot39, align 4
  %176 = sdiv i64 %.state183, 80
  %.spill.load184 = load i64, ptr %.spill29, align 4
  %177 = add i64 %.spill.load184, 0
  %.spill.load185 = load <8 x i64>, ptr %.spill30, align 64
  %178 = add <8 x i64> %.spill.load185, zeroinitializer
  %179 = mul i64 %177, 2
  %.splatinsert186 = insertelement <8 x i64> poison, i64 %179, i64 0
  %.splat187 = shufflevector <8 x i64> %.splatinsert186, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = add <8 x i64> %.splat187, %178
  %.spill.load188 = load i64, ptr %.spill37, align 4
  %181 = add i64 %.spill.load188, %176
  %182 = mul <8 x i64> %180, splat (i64 2053)
  %.splatinsert189 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat190 = shufflevector <8 x i64> %.splatinsert189, <8 x i64> poison, <8 x i32> zeroinitializer
  %183 = add <8 x i64> %182, %.splat190
  %184 = icmp sge i64 %181, 0
  %185 = and i1 true, %184
  %186 = icmp slt i64 %181, 2053
  %187 = and i1 %185, %186
  %188 = add i64 0, %175
  %189 = mul <8 x i64> %183, splat (i64 80)
  %.splatinsert191 = insertelement <8 x i64> poison, i64 %188, i64 0
  %.splat192 = shufflevector <8 x i64> %.splatinsert191, <8 x i64> poison, <8 x i32> zeroinitializer
  %190 = add <8 x i64> %189, %.splat192
  %191 = load <8 x i64>, ptr %.spill40, align 64
  %192 = select <8 x i1> %71, <8 x i64> %190, <8 x i64> %191
  store <8 x i64> %192, ptr %.spill40, align 64
  br i1 %187, label %direct.true193, label %direct.false194

direct.schedule.11:                               ; preds = %direct.true193
  %.spill.load195 = load <8 x i64>, ptr %.spill40, align 64
  %193 = extractvalue { ptr, i64 } %35, 0
  %194 = mul <8 x i64> %.spill.load195, splat (i64 4)
  %195 = getelementptr i8, ptr %193, <8 x i64> %194
  %196 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %195, <8 x i1> %71, <8 x float> zeroinitializer)
  %197 = load <8 x float>, ptr %.slot41, align 32
  %198 = select <8 x i1> %71, <8 x float> %196, <8 x float> %197
  store <8 x float> %198, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.11, %direct.false194
  %tile_snapshot.spill.load196 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load196, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load196, 1
  %.state197 = load i64, ptr %.slot39, align 4
  %.splatinsert198 = insertelement <8 x i64> poison, i64 %.state197, i64 0
  %.splat199 = shufflevector <8 x i64> %.splatinsert198, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = mul <8 x i64> %.splat199, splat (i64 32)
  %202 = add <8 x i64> %200, %201
  %203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %199, 0
  %204 = insertvalue { <8 x ptr>, <8 x i64> } %203, <8 x i64> %202, 1
  %.state200 = load <8 x float>, ptr %.slot41, align 32
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %204, 1
  %207 = extractelement <8 x ptr> %205, i32 0
  %208 = extractelement <8 x i64> %206, i32 0
  %209 = sub i64 %208, 0
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %211 = select i1 %210, i64 %209, i64 0
  %private.contiguous.address201 = getelementptr i8, ptr %207, i64 %211
  %private.contiguous.preserve202 = load <8 x float>, ptr %private.contiguous.address201, align 4
  %212 = select <8 x i1> %71, <8 x float> %.state200, <8 x float> %private.contiguous.preserve202
  store <8 x float> %212, ptr %private.contiguous.address201, align 4
  %.state203 = load i64, ptr %.slot39, align 4
  %213 = add i64 %.state203, 1
  store i64 %213, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false181
  %214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 0
  %217 = select <8 x i1> %71, <8 x ptr> %215, <8 x ptr> %216
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %220 = select <8 x i1> %71, <8 x i64> %218, <8 x i64> %219
  %221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %222 = insertvalue { <8 x ptr>, <8 x i64> } %221, <8 x i64> %220, 1
  store { <8 x ptr>, <8 x i64> } %222, ptr %tile_snapshot.spill42, align 64
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state204 = load i64, ptr %.slot43, align 4
  %223 = icmp slt i64 %.state204, 1536
  br i1 %223, label %direct.true205, label %direct.false206

direct.schedule.15:                               ; preds = %direct.true205
  %.state207 = load i64, ptr %.slot43, align 4
  %224 = srem i64 %.state207, 96
  %.state208 = load i64, ptr %.slot43, align 4
  %225 = sdiv i64 %.state208, 96
  %.spill.load209 = load i64, ptr %.spill29, align 4
  %226 = add i64 %.spill.load209, 0
  %.spill.load210 = load <8 x i64>, ptr %.spill30, align 64
  %227 = add <8 x i64> %.spill.load210, zeroinitializer
  %228 = mul i64 %226, 2
  %.splatinsert211 = insertelement <8 x i64> poison, i64 %228, i64 0
  %.splat212 = shufflevector <8 x i64> %.splatinsert211, <8 x i64> poison, <8 x i32> zeroinitializer
  %229 = add <8 x i64> %.splat212, %227
  %.spill.load213 = load i64, ptr %.spill37, align 4
  %230 = add i64 %.spill.load213, %225
  %231 = mul <8 x i64> %229, splat (i64 2053)
  %.splatinsert214 = insertelement <8 x i64> poison, i64 %230, i64 0
  %.splat215 = shufflevector <8 x i64> %.splatinsert214, <8 x i64> poison, <8 x i32> zeroinitializer
  %232 = add <8 x i64> %231, %.splat215
  %233 = icmp sge i64 %230, 0
  %234 = and i1 true, %233
  %235 = icmp slt i64 %230, 2053
  %236 = and i1 %234, %235
  %237 = add i64 0, %224
  %238 = mul <8 x i64> %232, splat (i64 96)
  %.splatinsert216 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat217 = shufflevector <8 x i64> %.splatinsert216, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = add <8 x i64> %238, %.splat217
  %240 = load <8 x i64>, ptr %.spill44, align 64
  %241 = select <8 x i1> %71, <8 x i64> %239, <8 x i64> %240
  store <8 x i64> %241, ptr %.spill44, align 64
  br i1 %236, label %direct.true218, label %direct.false219

direct.schedule.16:                               ; preds = %direct.true218
  %.spill.load220 = load <8 x i64>, ptr %.spill44, align 64
  %242 = extractvalue { ptr, i64 } %41, 0
  %243 = mul <8 x i64> %.spill.load220, splat (i64 4)
  %244 = getelementptr i8, ptr %242, <8 x i64> %243
  %245 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %244, <8 x i1> %71, <8 x float> zeroinitializer)
  %246 = load <8 x float>, ptr %.slot45, align 32
  %247 = select <8 x i1> %71, <8 x float> %245, <8 x float> %246
  store <8 x float> %247, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.16, %direct.false219
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %.state222 = load i64, ptr %.slot43, align 4
  %.splatinsert223 = insertelement <8 x i64> poison, i64 %.state222, i64 0
  %.splat224 = shufflevector <8 x i64> %.splatinsert223, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = mul <8 x i64> %.splat224, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %.state225 = load <8 x float>, ptr %.slot45, align 32
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address226 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.preserve227 = load <8 x float>, ptr %private.contiguous.address226, align 4
  %261 = select <8 x i1> %71, <8 x float> %.state225, <8 x float> %private.contiguous.preserve227
  store <8 x float> %261, ptr %private.contiguous.address226, align 4
  %.state228 = load i64, ptr %.slot43, align 4
  %262 = add i64 %.state228, 1
  store i64 %262, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false206
  store i64 0, ptr %.slot46, align 4
  %263 = load <8 x float>, ptr %.slot47, align 32
  %264 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %263
  store <8 x float> %264, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state229 = load i64, ptr %.slot46, align 4
  %265 = icmp slt i64 %.state229, 80
  br i1 %265, label %direct.true230, label %direct.false231

direct.schedule.20:                               ; preds = %direct.true230
  %.state232 = load i64, ptr %.slot46, align 4
  %266 = add i64 0, %.state232
  %tile_snapshot.spill.load233 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load233, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load233, 1
  %.splatinsert234 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat235 = shufflevector <8 x i64> %.splatinsert234, <8 x i64> poison, <8 x i32> zeroinitializer
  %269 = mul <8 x i64> %.splat235, splat (i64 32)
  %270 = add <8 x i64> %268, %269
  %271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %267, 0
  %272 = insertvalue { <8 x ptr>, <8 x i64> } %271, <8 x i64> %270, 1
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %272, 1
  %275 = extractelement <8 x ptr> %273, i32 0
  %276 = extractelement <8 x i64> %274, i32 0
  %277 = sub i64 %276, 0
  %278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %279 = select i1 %278, i64 %277, i64 0
  %private.contiguous.address236 = getelementptr i8, ptr %275, i64 %279
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address236, align 4
  %280 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load237 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 1
  %.splatinsert238 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat239 = shufflevector <8 x i64> %.splatinsert238, <8 x i64> poison, <8 x i32> zeroinitializer
  %283 = mul <8 x i64> %.splat239, splat (i64 32)
  %284 = add <8 x i64> %282, %283
  %285 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %281, 0
  %286 = insertvalue { <8 x ptr>, <8 x i64> } %285, <8 x i64> %284, 1
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %286, 1
  %289 = extractelement <8 x ptr> %287, i32 0
  %290 = extractelement <8 x i64> %288, i32 0
  %291 = sub i64 %290, 0
  %292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %293 = select i1 %292, i64 %291, i64 0
  %private.contiguous.address240 = getelementptr i8, ptr %289, i64 %293
  %private.contiguous.load241 = load <8 x float>, ptr %private.contiguous.address240, align 4
  %294 = select <8 x i1> %71, <8 x float> %private.contiguous.load241, <8 x float> zeroinitializer
  %295 = fmul <8 x float> %280, %294
  %.state242 = load <8 x float>, ptr %.slot47, align 32
  %296 = fadd <8 x float> %.state242, %295
  %.state243 = load i64, ptr %.slot46, align 4
  %297 = add i64 %.state243, 1
  store i64 %297, ptr %.slot46, align 4
  %298 = load <8 x float>, ptr %.slot47, align 32
  %299 = select <8 x i1> %71, <8 x float> %296, <8 x float> %298
  store <8 x float> %299, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false231
  store i64 0, ptr %.slot48, align 4
  %300 = load <8 x float>, ptr %.slot49, align 32
  %301 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %300
  store <8 x float> %301, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state244 = load i64, ptr %.slot48, align 4
  %302 = icmp slt i64 %.state244, 80
  br i1 %302, label %direct.true245, label %direct.false246

direct.schedule.23:                               ; preds = %direct.true245
  %.state247 = load i64, ptr %.slot48, align 4
  %303 = add i64 0, %.state247
  %tile_snapshot.spill.load248 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %.splatinsert249 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat250 = shufflevector <8 x i64> %.splatinsert249, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat250, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address251 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load252 = load <8 x float>, ptr %private.contiguous.address251, align 4
  %317 = select <8 x i1> %71, <8 x float> %private.contiguous.load252, <8 x float> zeroinitializer
  %.state253 = load i64, ptr %.slot48, align 4
  %318 = add i64 80, %.state253
  %tile_snapshot.spill.load254 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %.splatinsert255 = insertelement <8 x i64> poison, i64 %318, i64 0
  %.splat256 = shufflevector <8 x i64> %.splatinsert255, <8 x i64> poison, <8 x i32> zeroinitializer
  %321 = mul <8 x i64> %.splat256, splat (i64 32)
  %322 = add <8 x i64> %320, %321
  %323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %319, 0
  %324 = insertvalue { <8 x ptr>, <8 x i64> } %323, <8 x i64> %322, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %324, 1
  %327 = extractelement <8 x ptr> %325, i32 0
  %328 = extractelement <8 x i64> %326, i32 0
  %329 = sub i64 %328, 0
  %330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %331 = select i1 %330, i64 %329, i64 0
  %private.contiguous.address257 = getelementptr i8, ptr %327, i64 %331
  %private.contiguous.load258 = load <8 x float>, ptr %private.contiguous.address257, align 4
  %332 = select <8 x i1> %71, <8 x float> %private.contiguous.load258, <8 x float> zeroinitializer
  %333 = fmul <8 x float> %317, %332
  %.state259 = load <8 x float>, ptr %.slot49, align 32
  %334 = fadd <8 x float> %.state259, %333
  %.state260 = load i64, ptr %.slot48, align 4
  %335 = add i64 %.state260, 1
  store i64 %335, ptr %.slot48, align 4
  %336 = load <8 x float>, ptr %.slot49, align 32
  %337 = select <8 x i1> %71, <8 x float> %334, <8 x float> %336
  store <8 x float> %337, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false246
  store i64 0, ptr %.slot50, align 4
  %338 = load <8 x float>, ptr %.slot51, align 32
  %339 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %338
  store <8 x float> %339, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state261 = load i64, ptr %.slot50, align 4
  %340 = icmp slt i64 %.state261, 80
  br i1 %340, label %direct.true262, label %direct.false263

direct.schedule.26:                               ; preds = %direct.true262
  %.state264 = load i64, ptr %.slot50, align 4
  %341 = add i64 0, %.state264
  %tile_snapshot.spill.load265 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 0
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 1
  %.splatinsert266 = insertelement <8 x i64> poison, i64 %341, i64 0
  %.splat267 = shufflevector <8 x i64> %.splatinsert266, <8 x i64> poison, <8 x i32> zeroinitializer
  %344 = mul <8 x i64> %.splat267, splat (i64 32)
  %345 = add <8 x i64> %343, %344
  %346 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %342, 0
  %347 = insertvalue { <8 x ptr>, <8 x i64> } %346, <8 x i64> %345, 1
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %347, 1
  %350 = extractelement <8 x ptr> %348, i32 0
  %351 = extractelement <8 x i64> %349, i32 0
  %352 = sub i64 %351, 0
  %353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %354 = select i1 %353, i64 %352, i64 0
  %private.contiguous.address268 = getelementptr i8, ptr %350, i64 %354
  %private.contiguous.load269 = load <8 x float>, ptr %private.contiguous.address268, align 4
  %355 = select <8 x i1> %71, <8 x float> %private.contiguous.load269, <8 x float> zeroinitializer
  %.state270 = load i64, ptr %.slot50, align 4
  %356 = add i64 160, %.state270
  %tile_snapshot.spill.load271 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %.splatinsert272 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat273 = shufflevector <8 x i64> %.splatinsert272, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat273, splat (i64 32)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = extractelement <8 x ptr> %363, i32 0
  %366 = extractelement <8 x i64> %364, i32 0
  %367 = sub i64 %366, 0
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %369 = select i1 %368, i64 %367, i64 0
  %private.contiguous.address274 = getelementptr i8, ptr %365, i64 %369
  %private.contiguous.load275 = load <8 x float>, ptr %private.contiguous.address274, align 4
  %370 = select <8 x i1> %71, <8 x float> %private.contiguous.load275, <8 x float> zeroinitializer
  %371 = fmul <8 x float> %355, %370
  %.state276 = load <8 x float>, ptr %.slot51, align 32
  %372 = fadd <8 x float> %.state276, %371
  %.state277 = load i64, ptr %.slot50, align 4
  %373 = add i64 %.state277, 1
  store i64 %373, ptr %.slot50, align 4
  %374 = load <8 x float>, ptr %.slot51, align 32
  %375 = select <8 x i1> %71, <8 x float> %372, <8 x float> %374
  store <8 x float> %375, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false263
  store i64 0, ptr %.slot52, align 4
  %376 = load <8 x float>, ptr %.slot53, align 32
  %377 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %376
  store <8 x float> %377, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state278 = load i64, ptr %.slot52, align 4
  %378 = icmp slt i64 %.state278, 80
  br i1 %378, label %direct.true279, label %direct.false280

direct.schedule.29:                               ; preds = %direct.true279
  %.state281 = load i64, ptr %.slot52, align 4
  %379 = add i64 0, %.state281
  %tile_snapshot.spill.load282 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load282, 0
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load282, 1
  %.splatinsert283 = insertelement <8 x i64> poison, i64 %379, i64 0
  %.splat284 = shufflevector <8 x i64> %.splatinsert283, <8 x i64> poison, <8 x i32> zeroinitializer
  %382 = mul <8 x i64> %.splat284, splat (i64 32)
  %383 = add <8 x i64> %381, %382
  %384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %380, 0
  %385 = insertvalue { <8 x ptr>, <8 x i64> } %384, <8 x i64> %383, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %385, 1
  %388 = extractelement <8 x ptr> %386, i32 0
  %389 = extractelement <8 x i64> %387, i32 0
  %390 = sub i64 %389, 0
  %391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %392 = select i1 %391, i64 %390, i64 0
  %private.contiguous.address285 = getelementptr i8, ptr %388, i64 %392
  %private.contiguous.load286 = load <8 x float>, ptr %private.contiguous.address285, align 4
  %393 = select <8 x i1> %71, <8 x float> %private.contiguous.load286, <8 x float> zeroinitializer
  %.state287 = load i64, ptr %.slot52, align 4
  %394 = add i64 240, %.state287
  %tile_snapshot.spill.load288 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 0
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 1
  %.splatinsert289 = insertelement <8 x i64> poison, i64 %394, i64 0
  %.splat290 = shufflevector <8 x i64> %.splatinsert289, <8 x i64> poison, <8 x i32> zeroinitializer
  %397 = mul <8 x i64> %.splat290, splat (i64 32)
  %398 = add <8 x i64> %396, %397
  %399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %395, 0
  %400 = insertvalue { <8 x ptr>, <8 x i64> } %399, <8 x i64> %398, 1
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %400, 1
  %403 = extractelement <8 x ptr> %401, i32 0
  %404 = extractelement <8 x i64> %402, i32 0
  %405 = sub i64 %404, 0
  %406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %407 = select i1 %406, i64 %405, i64 0
  %private.contiguous.address291 = getelementptr i8, ptr %403, i64 %407
  %private.contiguous.load292 = load <8 x float>, ptr %private.contiguous.address291, align 4
  %408 = select <8 x i1> %71, <8 x float> %private.contiguous.load292, <8 x float> zeroinitializer
  %409 = fmul <8 x float> %393, %408
  %.state293 = load <8 x float>, ptr %.slot53, align 32
  %410 = fadd <8 x float> %.state293, %409
  %.state294 = load i64, ptr %.slot52, align 4
  %411 = add i64 %.state294, 1
  store i64 %411, ptr %.slot52, align 4
  %412 = load <8 x float>, ptr %.slot53, align 32
  %413 = select <8 x i1> %71, <8 x float> %410, <8 x float> %412
  store <8 x float> %413, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false280
  store i64 0, ptr %.slot54, align 4
  %414 = load <8 x float>, ptr %.slot55, align 32
  %415 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %414
  store <8 x float> %415, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state295 = load i64, ptr %.slot54, align 4
  %416 = icmp slt i64 %.state295, 80
  br i1 %416, label %direct.true296, label %direct.false297

direct.schedule.32:                               ; preds = %direct.true296
  %.state298 = load i64, ptr %.slot54, align 4
  %417 = add i64 0, %.state298
  %tile_snapshot.spill.load299 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load299, 0
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load299, 1
  %.splatinsert300 = insertelement <8 x i64> poison, i64 %417, i64 0
  %.splat301 = shufflevector <8 x i64> %.splatinsert300, <8 x i64> poison, <8 x i32> zeroinitializer
  %420 = mul <8 x i64> %.splat301, splat (i64 32)
  %421 = add <8 x i64> %419, %420
  %422 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %418, 0
  %423 = insertvalue { <8 x ptr>, <8 x i64> } %422, <8 x i64> %421, 1
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %423, 1
  %426 = extractelement <8 x ptr> %424, i32 0
  %427 = extractelement <8 x i64> %425, i32 0
  %428 = sub i64 %427, 0
  %429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %430 = select i1 %429, i64 %428, i64 0
  %private.contiguous.address302 = getelementptr i8, ptr %426, i64 %430
  %private.contiguous.load303 = load <8 x float>, ptr %private.contiguous.address302, align 4
  %431 = select <8 x i1> %71, <8 x float> %private.contiguous.load303, <8 x float> zeroinitializer
  %.state304 = load i64, ptr %.slot54, align 4
  %432 = add i64 320, %.state304
  %tile_snapshot.spill.load305 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load305, 0
  %434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load305, 1
  %.splatinsert306 = insertelement <8 x i64> poison, i64 %432, i64 0
  %.splat307 = shufflevector <8 x i64> %.splatinsert306, <8 x i64> poison, <8 x i32> zeroinitializer
  %435 = mul <8 x i64> %.splat307, splat (i64 32)
  %436 = add <8 x i64> %434, %435
  %437 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %433, 0
  %438 = insertvalue { <8 x ptr>, <8 x i64> } %437, <8 x i64> %436, 1
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %438, 1
  %441 = extractelement <8 x ptr> %439, i32 0
  %442 = extractelement <8 x i64> %440, i32 0
  %443 = sub i64 %442, 0
  %444 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %445 = select i1 %444, i64 %443, i64 0
  %private.contiguous.address308 = getelementptr i8, ptr %441, i64 %445
  %private.contiguous.load309 = load <8 x float>, ptr %private.contiguous.address308, align 4
  %446 = select <8 x i1> %71, <8 x float> %private.contiguous.load309, <8 x float> zeroinitializer
  %447 = fmul <8 x float> %431, %446
  %.state310 = load <8 x float>, ptr %.slot55, align 32
  %448 = fadd <8 x float> %.state310, %447
  %.state311 = load i64, ptr %.slot54, align 4
  %449 = add i64 %.state311, 1
  store i64 %449, ptr %.slot54, align 4
  %450 = load <8 x float>, ptr %.slot55, align 32
  %451 = select <8 x i1> %71, <8 x float> %448, <8 x float> %450
  store <8 x float> %451, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false297
  store i64 0, ptr %.slot56, align 4
  %452 = load <8 x float>, ptr %.slot57, align 32
  %453 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %452
  store <8 x float> %453, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state312 = load i64, ptr %.slot56, align 4
  %454 = icmp slt i64 %.state312, 80
  br i1 %454, label %direct.true313, label %direct.false314

direct.schedule.35:                               ; preds = %direct.true313
  %.state315 = load i64, ptr %.slot56, align 4
  %455 = add i64 0, %.state315
  %tile_snapshot.spill.load316 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %456 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load316, 0
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load316, 1
  %.splatinsert317 = insertelement <8 x i64> poison, i64 %455, i64 0
  %.splat318 = shufflevector <8 x i64> %.splatinsert317, <8 x i64> poison, <8 x i32> zeroinitializer
  %458 = mul <8 x i64> %.splat318, splat (i64 32)
  %459 = add <8 x i64> %457, %458
  %460 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %456, 0
  %461 = insertvalue { <8 x ptr>, <8 x i64> } %460, <8 x i64> %459, 1
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %461, 1
  %464 = extractelement <8 x ptr> %462, i32 0
  %465 = extractelement <8 x i64> %463, i32 0
  %466 = sub i64 %465, 0
  %467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %468 = select i1 %467, i64 %466, i64 0
  %private.contiguous.address319 = getelementptr i8, ptr %464, i64 %468
  %private.contiguous.load320 = load <8 x float>, ptr %private.contiguous.address319, align 4
  %469 = select <8 x i1> %71, <8 x float> %private.contiguous.load320, <8 x float> zeroinitializer
  %.state321 = load i64, ptr %.slot56, align 4
  %470 = add i64 400, %.state321
  %tile_snapshot.spill.load322 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load322, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load322, 1
  %.splatinsert323 = insertelement <8 x i64> poison, i64 %470, i64 0
  %.splat324 = shufflevector <8 x i64> %.splatinsert323, <8 x i64> poison, <8 x i32> zeroinitializer
  %473 = mul <8 x i64> %.splat324, splat (i64 32)
  %474 = add <8 x i64> %472, %473
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %471, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = extractelement <8 x ptr> %477, i32 0
  %480 = extractelement <8 x i64> %478, i32 0
  %481 = sub i64 %480, 0
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %483 = select i1 %482, i64 %481, i64 0
  %private.contiguous.address325 = getelementptr i8, ptr %479, i64 %483
  %private.contiguous.load326 = load <8 x float>, ptr %private.contiguous.address325, align 4
  %484 = select <8 x i1> %71, <8 x float> %private.contiguous.load326, <8 x float> zeroinitializer
  %485 = fmul <8 x float> %469, %484
  %.state327 = load <8 x float>, ptr %.slot57, align 32
  %486 = fadd <8 x float> %.state327, %485
  %.state328 = load i64, ptr %.slot56, align 4
  %487 = add i64 %.state328, 1
  store i64 %487, ptr %.slot56, align 4
  %488 = load <8 x float>, ptr %.slot57, align 32
  %489 = select <8 x i1> %71, <8 x float> %486, <8 x float> %488
  store <8 x float> %489, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false314
  store i64 0, ptr %.slot58, align 4
  %490 = load <8 x float>, ptr %.slot59, align 32
  %491 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %490
  store <8 x float> %491, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state329 = load i64, ptr %.slot58, align 4
  %492 = icmp slt i64 %.state329, 80
  br i1 %492, label %direct.true330, label %direct.false331

direct.schedule.38:                               ; preds = %direct.true330
  %.state332 = load i64, ptr %.slot58, align 4
  %493 = add i64 0, %.state332
  %tile_snapshot.spill.load333 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load333, 0
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load333, 1
  %.splatinsert334 = insertelement <8 x i64> poison, i64 %493, i64 0
  %.splat335 = shufflevector <8 x i64> %.splatinsert334, <8 x i64> poison, <8 x i32> zeroinitializer
  %496 = mul <8 x i64> %.splat335, splat (i64 32)
  %497 = add <8 x i64> %495, %496
  %498 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %494, 0
  %499 = insertvalue { <8 x ptr>, <8 x i64> } %498, <8 x i64> %497, 1
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %499, 1
  %502 = extractelement <8 x ptr> %500, i32 0
  %503 = extractelement <8 x i64> %501, i32 0
  %504 = sub i64 %503, 0
  %505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %506 = select i1 %505, i64 %504, i64 0
  %private.contiguous.address336 = getelementptr i8, ptr %502, i64 %506
  %private.contiguous.load337 = load <8 x float>, ptr %private.contiguous.address336, align 4
  %507 = select <8 x i1> %71, <8 x float> %private.contiguous.load337, <8 x float> zeroinitializer
  %.state338 = load i64, ptr %.slot58, align 4
  %508 = add i64 480, %.state338
  %tile_snapshot.spill.load339 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 0
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 1
  %.splatinsert340 = insertelement <8 x i64> poison, i64 %508, i64 0
  %.splat341 = shufflevector <8 x i64> %.splatinsert340, <8 x i64> poison, <8 x i32> zeroinitializer
  %511 = mul <8 x i64> %.splat341, splat (i64 32)
  %512 = add <8 x i64> %510, %511
  %513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %509, 0
  %514 = insertvalue { <8 x ptr>, <8 x i64> } %513, <8 x i64> %512, 1
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %514, 1
  %517 = extractelement <8 x ptr> %515, i32 0
  %518 = extractelement <8 x i64> %516, i32 0
  %519 = sub i64 %518, 0
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %521 = select i1 %520, i64 %519, i64 0
  %private.contiguous.address342 = getelementptr i8, ptr %517, i64 %521
  %private.contiguous.load343 = load <8 x float>, ptr %private.contiguous.address342, align 4
  %522 = select <8 x i1> %71, <8 x float> %private.contiguous.load343, <8 x float> zeroinitializer
  %523 = fmul <8 x float> %507, %522
  %.state344 = load <8 x float>, ptr %.slot59, align 32
  %524 = fadd <8 x float> %.state344, %523
  %.state345 = load i64, ptr %.slot58, align 4
  %525 = add i64 %.state345, 1
  store i64 %525, ptr %.slot58, align 4
  %526 = load <8 x float>, ptr %.slot59, align 32
  %527 = select <8 x i1> %71, <8 x float> %524, <8 x float> %526
  store <8 x float> %527, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false331
  store i64 0, ptr %.slot60, align 4
  %528 = load <8 x float>, ptr %.slot61, align 32
  %529 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %528
  store <8 x float> %529, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state346 = load i64, ptr %.slot60, align 4
  %530 = icmp slt i64 %.state346, 80
  br i1 %530, label %direct.true347, label %direct.false348

direct.schedule.41:                               ; preds = %direct.true347
  %.state349 = load i64, ptr %.slot60, align 4
  %531 = add i64 0, %.state349
  %tile_snapshot.spill.load350 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load350, 0
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load350, 1
  %.splatinsert351 = insertelement <8 x i64> poison, i64 %531, i64 0
  %.splat352 = shufflevector <8 x i64> %.splatinsert351, <8 x i64> poison, <8 x i32> zeroinitializer
  %534 = mul <8 x i64> %.splat352, splat (i64 32)
  %535 = add <8 x i64> %533, %534
  %536 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %532, 0
  %537 = insertvalue { <8 x ptr>, <8 x i64> } %536, <8 x i64> %535, 1
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %539 = extractvalue { <8 x ptr>, <8 x i64> } %537, 1
  %540 = extractelement <8 x ptr> %538, i32 0
  %541 = extractelement <8 x i64> %539, i32 0
  %542 = sub i64 %541, 0
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %544 = select i1 %543, i64 %542, i64 0
  %private.contiguous.address353 = getelementptr i8, ptr %540, i64 %544
  %private.contiguous.load354 = load <8 x float>, ptr %private.contiguous.address353, align 4
  %545 = select <8 x i1> %71, <8 x float> %private.contiguous.load354, <8 x float> zeroinitializer
  %.state355 = load i64, ptr %.slot60, align 4
  %546 = add i64 560, %.state355
  %tile_snapshot.spill.load356 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load356, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load356, 1
  %.splatinsert357 = insertelement <8 x i64> poison, i64 %546, i64 0
  %.splat358 = shufflevector <8 x i64> %.splatinsert357, <8 x i64> poison, <8 x i32> zeroinitializer
  %549 = mul <8 x i64> %.splat358, splat (i64 32)
  %550 = add <8 x i64> %548, %549
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %547, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = extractelement <8 x ptr> %553, i32 0
  %556 = extractelement <8 x i64> %554, i32 0
  %557 = sub i64 %556, 0
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %559 = select i1 %558, i64 %557, i64 0
  %private.contiguous.address359 = getelementptr i8, ptr %555, i64 %559
  %private.contiguous.load360 = load <8 x float>, ptr %private.contiguous.address359, align 4
  %560 = select <8 x i1> %71, <8 x float> %private.contiguous.load360, <8 x float> zeroinitializer
  %561 = fmul <8 x float> %545, %560
  %.state361 = load <8 x float>, ptr %.slot61, align 32
  %562 = fadd <8 x float> %.state361, %561
  %.state362 = load i64, ptr %.slot60, align 4
  %563 = add i64 %.state362, 1
  store i64 %563, ptr %.slot60, align 4
  %564 = load <8 x float>, ptr %.slot61, align 32
  %565 = select <8 x i1> %71, <8 x float> %562, <8 x float> %564
  store <8 x float> %565, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false348
  store i64 0, ptr %.slot62, align 4
  %566 = load <8 x float>, ptr %.slot63, align 32
  %567 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %566
  store <8 x float> %567, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state363 = load i64, ptr %.slot62, align 4
  %568 = icmp slt i64 %.state363, 80
  br i1 %568, label %direct.true364, label %direct.false365

direct.schedule.44:                               ; preds = %direct.true364
  %.state366 = load i64, ptr %.slot62, align 4
  %569 = add i64 0, %.state366
  %tile_snapshot.spill.load367 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load367, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load367, 1
  %.splatinsert368 = insertelement <8 x i64> poison, i64 %569, i64 0
  %.splat369 = shufflevector <8 x i64> %.splatinsert368, <8 x i64> poison, <8 x i32> zeroinitializer
  %572 = mul <8 x i64> %.splat369, splat (i64 32)
  %573 = add <8 x i64> %571, %572
  %574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %570, 0
  %575 = insertvalue { <8 x ptr>, <8 x i64> } %574, <8 x i64> %573, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %575, 1
  %578 = extractelement <8 x ptr> %576, i32 0
  %579 = extractelement <8 x i64> %577, i32 0
  %580 = sub i64 %579, 0
  %581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %582 = select i1 %581, i64 %580, i64 0
  %private.contiguous.address370 = getelementptr i8, ptr %578, i64 %582
  %private.contiguous.load371 = load <8 x float>, ptr %private.contiguous.address370, align 4
  %583 = select <8 x i1> %71, <8 x float> %private.contiguous.load371, <8 x float> zeroinitializer
  %.state372 = load i64, ptr %.slot62, align 4
  %584 = add i64 640, %.state372
  %tile_snapshot.spill.load373 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %.splatinsert374 = insertelement <8 x i64> poison, i64 %584, i64 0
  %.splat375 = shufflevector <8 x i64> %.splatinsert374, <8 x i64> poison, <8 x i32> zeroinitializer
  %587 = mul <8 x i64> %.splat375, splat (i64 32)
  %588 = add <8 x i64> %586, %587
  %589 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %585, 0
  %590 = insertvalue { <8 x ptr>, <8 x i64> } %589, <8 x i64> %588, 1
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %592 = extractvalue { <8 x ptr>, <8 x i64> } %590, 1
  %593 = extractelement <8 x ptr> %591, i32 0
  %594 = extractelement <8 x i64> %592, i32 0
  %595 = sub i64 %594, 0
  %596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %597 = select i1 %596, i64 %595, i64 0
  %private.contiguous.address376 = getelementptr i8, ptr %593, i64 %597
  %private.contiguous.load377 = load <8 x float>, ptr %private.contiguous.address376, align 4
  %598 = select <8 x i1> %71, <8 x float> %private.contiguous.load377, <8 x float> zeroinitializer
  %599 = fmul <8 x float> %583, %598
  %.state378 = load <8 x float>, ptr %.slot63, align 32
  %600 = fadd <8 x float> %.state378, %599
  %.state379 = load i64, ptr %.slot62, align 4
  %601 = add i64 %.state379, 1
  store i64 %601, ptr %.slot62, align 4
  %602 = load <8 x float>, ptr %.slot63, align 32
  %603 = select <8 x i1> %71, <8 x float> %600, <8 x float> %602
  store <8 x float> %603, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false365
  store i64 0, ptr %.slot64, align 4
  %604 = load <8 x float>, ptr %.slot65, align 32
  %605 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %604
  store <8 x float> %605, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state380 = load i64, ptr %.slot64, align 4
  %606 = icmp slt i64 %.state380, 80
  br i1 %606, label %direct.true381, label %direct.false382

direct.schedule.47:                               ; preds = %direct.true381
  %.state383 = load i64, ptr %.slot64, align 4
  %607 = add i64 0, %.state383
  %tile_snapshot.spill.load384 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load384, 0
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load384, 1
  %.splatinsert385 = insertelement <8 x i64> poison, i64 %607, i64 0
  %.splat386 = shufflevector <8 x i64> %.splatinsert385, <8 x i64> poison, <8 x i32> zeroinitializer
  %610 = mul <8 x i64> %.splat386, splat (i64 32)
  %611 = add <8 x i64> %609, %610
  %612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %608, 0
  %613 = insertvalue { <8 x ptr>, <8 x i64> } %612, <8 x i64> %611, 1
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %613, 1
  %616 = extractelement <8 x ptr> %614, i32 0
  %617 = extractelement <8 x i64> %615, i32 0
  %618 = sub i64 %617, 0
  %619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %620 = select i1 %619, i64 %618, i64 0
  %private.contiguous.address387 = getelementptr i8, ptr %616, i64 %620
  %private.contiguous.load388 = load <8 x float>, ptr %private.contiguous.address387, align 4
  %621 = select <8 x i1> %71, <8 x float> %private.contiguous.load388, <8 x float> zeroinitializer
  %.state389 = load i64, ptr %.slot64, align 4
  %622 = add i64 720, %.state389
  %tile_snapshot.spill.load390 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load390, 0
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load390, 1
  %.splatinsert391 = insertelement <8 x i64> poison, i64 %622, i64 0
  %.splat392 = shufflevector <8 x i64> %.splatinsert391, <8 x i64> poison, <8 x i32> zeroinitializer
  %625 = mul <8 x i64> %.splat392, splat (i64 32)
  %626 = add <8 x i64> %624, %625
  %627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %623, 0
  %628 = insertvalue { <8 x ptr>, <8 x i64> } %627, <8 x i64> %626, 1
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %628, 1
  %631 = extractelement <8 x ptr> %629, i32 0
  %632 = extractelement <8 x i64> %630, i32 0
  %633 = sub i64 %632, 0
  %634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %635 = select i1 %634, i64 %633, i64 0
  %private.contiguous.address393 = getelementptr i8, ptr %631, i64 %635
  %private.contiguous.load394 = load <8 x float>, ptr %private.contiguous.address393, align 4
  %636 = select <8 x i1> %71, <8 x float> %private.contiguous.load394, <8 x float> zeroinitializer
  %637 = fmul <8 x float> %621, %636
  %.state395 = load <8 x float>, ptr %.slot65, align 32
  %638 = fadd <8 x float> %.state395, %637
  %.state396 = load i64, ptr %.slot64, align 4
  %639 = add i64 %.state396, 1
  store i64 %639, ptr %.slot64, align 4
  %640 = load <8 x float>, ptr %.slot65, align 32
  %641 = select <8 x i1> %71, <8 x float> %638, <8 x float> %640
  store <8 x float> %641, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false382
  store i64 0, ptr %.slot66, align 4
  %642 = load <8 x float>, ptr %.slot67, align 32
  %643 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %642
  store <8 x float> %643, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state397 = load i64, ptr %.slot66, align 4
  %644 = icmp slt i64 %.state397, 80
  br i1 %644, label %direct.true398, label %direct.false399

direct.schedule.50:                               ; preds = %direct.true398
  %.state400 = load i64, ptr %.slot66, align 4
  %645 = add i64 0, %.state400
  %tile_snapshot.spill.load401 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load401, 0
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load401, 1
  %.splatinsert402 = insertelement <8 x i64> poison, i64 %645, i64 0
  %.splat403 = shufflevector <8 x i64> %.splatinsert402, <8 x i64> poison, <8 x i32> zeroinitializer
  %648 = mul <8 x i64> %.splat403, splat (i64 32)
  %649 = add <8 x i64> %647, %648
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %646, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 0
  %656 = sub i64 %655, 0
  %657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %658 = select i1 %657, i64 %656, i64 0
  %private.contiguous.address404 = getelementptr i8, ptr %654, i64 %658
  %private.contiguous.load405 = load <8 x float>, ptr %private.contiguous.address404, align 4
  %659 = select <8 x i1> %71, <8 x float> %private.contiguous.load405, <8 x float> zeroinitializer
  %.state406 = load i64, ptr %.slot66, align 4
  %660 = add i64 800, %.state406
  %tile_snapshot.spill.load407 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %.splatinsert408 = insertelement <8 x i64> poison, i64 %660, i64 0
  %.splat409 = shufflevector <8 x i64> %.splatinsert408, <8 x i64> poison, <8 x i32> zeroinitializer
  %663 = mul <8 x i64> %.splat409, splat (i64 32)
  %664 = add <8 x i64> %662, %663
  %665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %661, 0
  %666 = insertvalue { <8 x ptr>, <8 x i64> } %665, <8 x i64> %664, 1
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %666, 1
  %669 = extractelement <8 x ptr> %667, i32 0
  %670 = extractelement <8 x i64> %668, i32 0
  %671 = sub i64 %670, 0
  %672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %673 = select i1 %672, i64 %671, i64 0
  %private.contiguous.address410 = getelementptr i8, ptr %669, i64 %673
  %private.contiguous.load411 = load <8 x float>, ptr %private.contiguous.address410, align 4
  %674 = select <8 x i1> %71, <8 x float> %private.contiguous.load411, <8 x float> zeroinitializer
  %675 = fmul <8 x float> %659, %674
  %.state412 = load <8 x float>, ptr %.slot67, align 32
  %676 = fadd <8 x float> %.state412, %675
  %.state413 = load i64, ptr %.slot66, align 4
  %677 = add i64 %.state413, 1
  store i64 %677, ptr %.slot66, align 4
  %678 = load <8 x float>, ptr %.slot67, align 32
  %679 = select <8 x i1> %71, <8 x float> %676, <8 x float> %678
  store <8 x float> %679, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false399
  store i64 0, ptr %.slot68, align 4
  %680 = load <8 x float>, ptr %.slot69, align 32
  %681 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %680
  store <8 x float> %681, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state414 = load i64, ptr %.slot68, align 4
  %682 = icmp slt i64 %.state414, 80
  br i1 %682, label %direct.true415, label %direct.false416

direct.schedule.53:                               ; preds = %direct.true415
  %.state417 = load i64, ptr %.slot68, align 4
  %683 = add i64 0, %.state417
  %tile_snapshot.spill.load418 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load418, 0
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load418, 1
  %.splatinsert419 = insertelement <8 x i64> poison, i64 %683, i64 0
  %.splat420 = shufflevector <8 x i64> %.splatinsert419, <8 x i64> poison, <8 x i32> zeroinitializer
  %686 = mul <8 x i64> %.splat420, splat (i64 32)
  %687 = add <8 x i64> %685, %686
  %688 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %684, 0
  %689 = insertvalue { <8 x ptr>, <8 x i64> } %688, <8 x i64> %687, 1
  %690 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %689, 1
  %692 = extractelement <8 x ptr> %690, i32 0
  %693 = extractelement <8 x i64> %691, i32 0
  %694 = sub i64 %693, 0
  %695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %696 = select i1 %695, i64 %694, i64 0
  %private.contiguous.address421 = getelementptr i8, ptr %692, i64 %696
  %private.contiguous.load422 = load <8 x float>, ptr %private.contiguous.address421, align 4
  %697 = select <8 x i1> %71, <8 x float> %private.contiguous.load422, <8 x float> zeroinitializer
  %.state423 = load i64, ptr %.slot68, align 4
  %698 = add i64 880, %.state423
  %tile_snapshot.spill.load424 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load424, 0
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load424, 1
  %.splatinsert425 = insertelement <8 x i64> poison, i64 %698, i64 0
  %.splat426 = shufflevector <8 x i64> %.splatinsert425, <8 x i64> poison, <8 x i32> zeroinitializer
  %701 = mul <8 x i64> %.splat426, splat (i64 32)
  %702 = add <8 x i64> %700, %701
  %703 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %699, 0
  %704 = insertvalue { <8 x ptr>, <8 x i64> } %703, <8 x i64> %702, 1
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %706 = extractvalue { <8 x ptr>, <8 x i64> } %704, 1
  %707 = extractelement <8 x ptr> %705, i32 0
  %708 = extractelement <8 x i64> %706, i32 0
  %709 = sub i64 %708, 0
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %711 = select i1 %710, i64 %709, i64 0
  %private.contiguous.address427 = getelementptr i8, ptr %707, i64 %711
  %private.contiguous.load428 = load <8 x float>, ptr %private.contiguous.address427, align 4
  %712 = select <8 x i1> %71, <8 x float> %private.contiguous.load428, <8 x float> zeroinitializer
  %713 = fmul <8 x float> %697, %712
  %.state429 = load <8 x float>, ptr %.slot69, align 32
  %714 = fadd <8 x float> %.state429, %713
  %.state430 = load i64, ptr %.slot68, align 4
  %715 = add i64 %.state430, 1
  store i64 %715, ptr %.slot68, align 4
  %716 = load <8 x float>, ptr %.slot69, align 32
  %717 = select <8 x i1> %71, <8 x float> %714, <8 x float> %716
  store <8 x float> %717, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false416
  store i64 0, ptr %.slot70, align 4
  %718 = load <8 x float>, ptr %.slot71, align 32
  %719 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %718
  store <8 x float> %719, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state431 = load i64, ptr %.slot70, align 4
  %720 = icmp slt i64 %.state431, 80
  br i1 %720, label %direct.true432, label %direct.false433

direct.schedule.56:                               ; preds = %direct.true432
  %.state434 = load i64, ptr %.slot70, align 4
  %721 = add i64 0, %.state434
  %tile_snapshot.spill.load435 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 0
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 1
  %.splatinsert436 = insertelement <8 x i64> poison, i64 %721, i64 0
  %.splat437 = shufflevector <8 x i64> %.splatinsert436, <8 x i64> poison, <8 x i32> zeroinitializer
  %724 = mul <8 x i64> %.splat437, splat (i64 32)
  %725 = add <8 x i64> %723, %724
  %726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %722, 0
  %727 = insertvalue { <8 x ptr>, <8 x i64> } %726, <8 x i64> %725, 1
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %727, 1
  %730 = extractelement <8 x ptr> %728, i32 0
  %731 = extractelement <8 x i64> %729, i32 0
  %732 = sub i64 %731, 0
  %733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %734 = select i1 %733, i64 %732, i64 0
  %private.contiguous.address438 = getelementptr i8, ptr %730, i64 %734
  %private.contiguous.load439 = load <8 x float>, ptr %private.contiguous.address438, align 4
  %735 = select <8 x i1> %71, <8 x float> %private.contiguous.load439, <8 x float> zeroinitializer
  %.state440 = load i64, ptr %.slot70, align 4
  %736 = add i64 960, %.state440
  %tile_snapshot.spill.load441 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load441, 0
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load441, 1
  %.splatinsert442 = insertelement <8 x i64> poison, i64 %736, i64 0
  %.splat443 = shufflevector <8 x i64> %.splatinsert442, <8 x i64> poison, <8 x i32> zeroinitializer
  %739 = mul <8 x i64> %.splat443, splat (i64 32)
  %740 = add <8 x i64> %738, %739
  %741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %737, 0
  %742 = insertvalue { <8 x ptr>, <8 x i64> } %741, <8 x i64> %740, 1
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %742, 1
  %745 = extractelement <8 x ptr> %743, i32 0
  %746 = extractelement <8 x i64> %744, i32 0
  %747 = sub i64 %746, 0
  %748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %749 = select i1 %748, i64 %747, i64 0
  %private.contiguous.address444 = getelementptr i8, ptr %745, i64 %749
  %private.contiguous.load445 = load <8 x float>, ptr %private.contiguous.address444, align 4
  %750 = select <8 x i1> %71, <8 x float> %private.contiguous.load445, <8 x float> zeroinitializer
  %751 = fmul <8 x float> %735, %750
  %.state446 = load <8 x float>, ptr %.slot71, align 32
  %752 = fadd <8 x float> %.state446, %751
  %.state447 = load i64, ptr %.slot70, align 4
  %753 = add i64 %.state447, 1
  store i64 %753, ptr %.slot70, align 4
  %754 = load <8 x float>, ptr %.slot71, align 32
  %755 = select <8 x i1> %71, <8 x float> %752, <8 x float> %754
  store <8 x float> %755, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false433
  store i64 0, ptr %.slot72, align 4
  %756 = load <8 x float>, ptr %.slot73, align 32
  %757 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %756
  store <8 x float> %757, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state448 = load i64, ptr %.slot72, align 4
  %758 = icmp slt i64 %.state448, 80
  br i1 %758, label %direct.true449, label %direct.false450

direct.schedule.59:                               ; preds = %direct.true449
  %.state451 = load i64, ptr %.slot72, align 4
  %759 = add i64 0, %.state451
  %tile_snapshot.spill.load452 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load452, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load452, 1
  %.splatinsert453 = insertelement <8 x i64> poison, i64 %759, i64 0
  %.splat454 = shufflevector <8 x i64> %.splatinsert453, <8 x i64> poison, <8 x i32> zeroinitializer
  %762 = mul <8 x i64> %.splat454, splat (i64 32)
  %763 = add <8 x i64> %761, %762
  %764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %760, 0
  %765 = insertvalue { <8 x ptr>, <8 x i64> } %764, <8 x i64> %763, 1
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %768 = extractelement <8 x ptr> %766, i32 0
  %769 = extractelement <8 x i64> %767, i32 0
  %770 = sub i64 %769, 0
  %771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %772 = select i1 %771, i64 %770, i64 0
  %private.contiguous.address455 = getelementptr i8, ptr %768, i64 %772
  %private.contiguous.load456 = load <8 x float>, ptr %private.contiguous.address455, align 4
  %773 = select <8 x i1> %71, <8 x float> %private.contiguous.load456, <8 x float> zeroinitializer
  %.state457 = load i64, ptr %.slot72, align 4
  %774 = add i64 1040, %.state457
  %tile_snapshot.spill.load458 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load458, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load458, 1
  %.splatinsert459 = insertelement <8 x i64> poison, i64 %774, i64 0
  %.splat460 = shufflevector <8 x i64> %.splatinsert459, <8 x i64> poison, <8 x i32> zeroinitializer
  %777 = mul <8 x i64> %.splat460, splat (i64 32)
  %778 = add <8 x i64> %776, %777
  %779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %775, 0
  %780 = insertvalue { <8 x ptr>, <8 x i64> } %779, <8 x i64> %778, 1
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %780, 1
  %783 = extractelement <8 x ptr> %781, i32 0
  %784 = extractelement <8 x i64> %782, i32 0
  %785 = sub i64 %784, 0
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %787 = select i1 %786, i64 %785, i64 0
  %private.contiguous.address461 = getelementptr i8, ptr %783, i64 %787
  %private.contiguous.load462 = load <8 x float>, ptr %private.contiguous.address461, align 4
  %788 = select <8 x i1> %71, <8 x float> %private.contiguous.load462, <8 x float> zeroinitializer
  %789 = fmul <8 x float> %773, %788
  %.state463 = load <8 x float>, ptr %.slot73, align 32
  %790 = fadd <8 x float> %.state463, %789
  %.state464 = load i64, ptr %.slot72, align 4
  %791 = add i64 %.state464, 1
  store i64 %791, ptr %.slot72, align 4
  %792 = load <8 x float>, ptr %.slot73, align 32
  %793 = select <8 x i1> %71, <8 x float> %790, <8 x float> %792
  store <8 x float> %793, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false450
  store i64 0, ptr %.slot74, align 4
  %794 = load <8 x float>, ptr %.slot75, align 32
  %795 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %794
  store <8 x float> %795, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state465 = load i64, ptr %.slot74, align 4
  %796 = icmp slt i64 %.state465, 80
  br i1 %796, label %direct.true466, label %direct.false467

direct.schedule.62:                               ; preds = %direct.true466
  %.state468 = load i64, ptr %.slot74, align 4
  %797 = add i64 0, %.state468
  %tile_snapshot.spill.load469 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load469, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load469, 1
  %.splatinsert470 = insertelement <8 x i64> poison, i64 %797, i64 0
  %.splat471 = shufflevector <8 x i64> %.splatinsert470, <8 x i64> poison, <8 x i32> zeroinitializer
  %800 = mul <8 x i64> %.splat471, splat (i64 32)
  %801 = add <8 x i64> %799, %800
  %802 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %798, 0
  %803 = insertvalue { <8 x ptr>, <8 x i64> } %802, <8 x i64> %801, 1
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %803, 1
  %806 = extractelement <8 x ptr> %804, i32 0
  %807 = extractelement <8 x i64> %805, i32 0
  %808 = sub i64 %807, 0
  %809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %810 = select i1 %809, i64 %808, i64 0
  %private.contiguous.address472 = getelementptr i8, ptr %806, i64 %810
  %private.contiguous.load473 = load <8 x float>, ptr %private.contiguous.address472, align 4
  %811 = select <8 x i1> %71, <8 x float> %private.contiguous.load473, <8 x float> zeroinitializer
  %.state474 = load i64, ptr %.slot74, align 4
  %812 = add i64 1120, %.state474
  %tile_snapshot.spill.load475 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load475, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load475, 1
  %.splatinsert476 = insertelement <8 x i64> poison, i64 %812, i64 0
  %.splat477 = shufflevector <8 x i64> %.splatinsert476, <8 x i64> poison, <8 x i32> zeroinitializer
  %815 = mul <8 x i64> %.splat477, splat (i64 32)
  %816 = add <8 x i64> %814, %815
  %817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %813, 0
  %818 = insertvalue { <8 x ptr>, <8 x i64> } %817, <8 x i64> %816, 1
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %818, 1
  %821 = extractelement <8 x ptr> %819, i32 0
  %822 = extractelement <8 x i64> %820, i32 0
  %823 = sub i64 %822, 0
  %824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %825 = select i1 %824, i64 %823, i64 0
  %private.contiguous.address478 = getelementptr i8, ptr %821, i64 %825
  %private.contiguous.load479 = load <8 x float>, ptr %private.contiguous.address478, align 4
  %826 = select <8 x i1> %71, <8 x float> %private.contiguous.load479, <8 x float> zeroinitializer
  %827 = fmul <8 x float> %811, %826
  %.state480 = load <8 x float>, ptr %.slot75, align 32
  %828 = fadd <8 x float> %.state480, %827
  %.state481 = load i64, ptr %.slot74, align 4
  %829 = add i64 %.state481, 1
  store i64 %829, ptr %.slot74, align 4
  %830 = load <8 x float>, ptr %.slot75, align 32
  %831 = select <8 x i1> %71, <8 x float> %828, <8 x float> %830
  store <8 x float> %831, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false467
  store i64 0, ptr %.slot76, align 4
  %832 = load <8 x float>, ptr %.slot77, align 32
  %833 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %832
  store <8 x float> %833, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state482 = load i64, ptr %.slot76, align 4
  %834 = icmp slt i64 %.state482, 80
  br i1 %834, label %direct.true483, label %direct.false484

direct.schedule.65:                               ; preds = %direct.true483
  %.state485 = load i64, ptr %.slot76, align 4
  %835 = add i64 0, %.state485
  %tile_snapshot.spill.load486 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load486, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load486, 1
  %.splatinsert487 = insertelement <8 x i64> poison, i64 %835, i64 0
  %.splat488 = shufflevector <8 x i64> %.splatinsert487, <8 x i64> poison, <8 x i32> zeroinitializer
  %838 = mul <8 x i64> %.splat488, splat (i64 32)
  %839 = add <8 x i64> %837, %838
  %840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %836, 0
  %841 = insertvalue { <8 x ptr>, <8 x i64> } %840, <8 x i64> %839, 1
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %841, 1
  %844 = extractelement <8 x ptr> %842, i32 0
  %845 = extractelement <8 x i64> %843, i32 0
  %846 = sub i64 %845, 0
  %847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %848 = select i1 %847, i64 %846, i64 0
  %private.contiguous.address489 = getelementptr i8, ptr %844, i64 %848
  %private.contiguous.load490 = load <8 x float>, ptr %private.contiguous.address489, align 4
  %849 = select <8 x i1> %71, <8 x float> %private.contiguous.load490, <8 x float> zeroinitializer
  %.state491 = load i64, ptr %.slot76, align 4
  %850 = add i64 1200, %.state491
  %tile_snapshot.spill.load492 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load492, 0
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load492, 1
  %.splatinsert493 = insertelement <8 x i64> poison, i64 %850, i64 0
  %.splat494 = shufflevector <8 x i64> %.splatinsert493, <8 x i64> poison, <8 x i32> zeroinitializer
  %853 = mul <8 x i64> %.splat494, splat (i64 32)
  %854 = add <8 x i64> %852, %853
  %855 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %851, 0
  %856 = insertvalue { <8 x ptr>, <8 x i64> } %855, <8 x i64> %854, 1
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %856, 1
  %859 = extractelement <8 x ptr> %857, i32 0
  %860 = extractelement <8 x i64> %858, i32 0
  %861 = sub i64 %860, 0
  %862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %863 = select i1 %862, i64 %861, i64 0
  %private.contiguous.address495 = getelementptr i8, ptr %859, i64 %863
  %private.contiguous.load496 = load <8 x float>, ptr %private.contiguous.address495, align 4
  %864 = select <8 x i1> %71, <8 x float> %private.contiguous.load496, <8 x float> zeroinitializer
  %865 = fmul <8 x float> %849, %864
  %.state497 = load <8 x float>, ptr %.slot77, align 32
  %866 = fadd <8 x float> %.state497, %865
  %.state498 = load i64, ptr %.slot76, align 4
  %867 = add i64 %.state498, 1
  store i64 %867, ptr %.slot76, align 4
  %868 = load <8 x float>, ptr %.slot77, align 32
  %869 = select <8 x i1> %71, <8 x float> %866, <8 x float> %868
  store <8 x float> %869, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false484
  %.state499 = load <8 x float>, ptr %.slot47, align 32
  %870 = fmul <8 x float> %.state499, splat (float 0x3FBC9F25C0000000)
  %.state500 = load <8 x float>, ptr %.slot49, align 32
  %871 = fmul <8 x float> %.state500, splat (float 0x3FBC9F25C0000000)
  %.state501 = load <8 x float>, ptr %.slot51, align 32
  %872 = fmul <8 x float> %.state501, splat (float 0x3FBC9F25C0000000)
  %.state502 = load <8 x float>, ptr %.slot53, align 32
  %873 = fmul <8 x float> %.state502, splat (float 0x3FBC9F25C0000000)
  %.state503 = load <8 x float>, ptr %.slot55, align 32
  %874 = fmul <8 x float> %.state503, splat (float 0x3FBC9F25C0000000)
  %.state504 = load <8 x float>, ptr %.slot57, align 32
  %875 = fmul <8 x float> %.state504, splat (float 0x3FBC9F25C0000000)
  %.state505 = load <8 x float>, ptr %.slot59, align 32
  %876 = fmul <8 x float> %.state505, splat (float 0x3FBC9F25C0000000)
  %.state506 = load <8 x float>, ptr %.slot61, align 32
  %877 = fmul <8 x float> %.state506, splat (float 0x3FBC9F25C0000000)
  %.state507 = load <8 x float>, ptr %.slot63, align 32
  %878 = fmul <8 x float> %.state507, splat (float 0x3FBC9F25C0000000)
  %.state508 = load <8 x float>, ptr %.slot65, align 32
  %879 = fmul <8 x float> %.state508, splat (float 0x3FBC9F25C0000000)
  %.state509 = load <8 x float>, ptr %.slot67, align 32
  %880 = fmul <8 x float> %.state509, splat (float 0x3FBC9F25C0000000)
  %.state510 = load <8 x float>, ptr %.slot69, align 32
  %881 = fmul <8 x float> %.state510, splat (float 0x3FBC9F25C0000000)
  %.state511 = load <8 x float>, ptr %.slot71, align 32
  %882 = fmul <8 x float> %.state511, splat (float 0x3FBC9F25C0000000)
  %.state512 = load <8 x float>, ptr %.slot73, align 32
  %883 = fmul <8 x float> %.state512, splat (float 0x3FBC9F25C0000000)
  %.state513 = load <8 x float>, ptr %.slot75, align 32
  %884 = fmul <8 x float> %.state513, splat (float 0x3FBC9F25C0000000)
  %.state514 = load <8 x float>, ptr %.slot77, align 32
  %885 = fmul <8 x float> %.state514, splat (float 0x3FBC9F25C0000000)
  %.spill.load515 = load i64, ptr %.spill37, align 4
  %886 = add i64 0, %.spill.load515
  %.spill.load516 = load i64, ptr %.spill37, align 4
  %887 = add i64 1, %.spill.load516
  %.spill.load517 = load i64, ptr %.spill37, align 4
  %888 = add i64 2, %.spill.load517
  %.spill.load518 = load i64, ptr %.spill37, align 4
  %889 = add i64 3, %.spill.load518
  %.spill.load519 = load i64, ptr %.spill37, align 4
  %890 = add i64 4, %.spill.load519
  %.spill.load520 = load i64, ptr %.spill37, align 4
  %891 = add i64 5, %.spill.load520
  %.spill.load521 = load i64, ptr %.spill37, align 4
  %892 = add i64 6, %.spill.load521
  %.spill.load522 = load i64, ptr %.spill37, align 4
  %893 = add i64 7, %.spill.load522
  %.spill.load523 = load i64, ptr %.spill37, align 4
  %894 = add i64 8, %.spill.load523
  %.spill.load524 = load i64, ptr %.spill37, align 4
  %895 = add i64 9, %.spill.load524
  %.spill.load525 = load i64, ptr %.spill37, align 4
  %896 = add i64 10, %.spill.load525
  %.spill.load526 = load i64, ptr %.spill37, align 4
  %897 = add i64 11, %.spill.load526
  %.spill.load527 = load i64, ptr %.spill37, align 4
  %898 = add i64 12, %.spill.load527
  %.spill.load528 = load i64, ptr %.spill37, align 4
  %899 = add i64 13, %.spill.load528
  %.spill.load529 = load i64, ptr %.spill37, align 4
  %900 = add i64 14, %.spill.load529
  %.spill.load530 = load i64, ptr %.spill37, align 4
  %901 = add i64 15, %.spill.load530
  %902 = icmp slt i64 %886, 2053
  %903 = icmp slt i64 %887, 2053
  %904 = icmp slt i64 %888, 2053
  %905 = icmp slt i64 %889, 2053
  %906 = icmp slt i64 %890, 2053
  %907 = icmp slt i64 %891, 2053
  %908 = icmp slt i64 %892, 2053
  %909 = icmp slt i64 %893, 2053
  %910 = icmp slt i64 %894, 2053
  %911 = icmp slt i64 %895, 2053
  %912 = icmp slt i64 %896, 2053
  %913 = icmp slt i64 %897, 2053
  %914 = icmp slt i64 %898, 2053
  %915 = icmp slt i64 %899, 2053
  %916 = icmp slt i64 %900, 2053
  %917 = icmp slt i64 %901, 2053
  %.spill.load531 = load i64, ptr %.spill29, align 4
  %918 = add i64 0, %.spill.load531
  store i64 %918, ptr %.spill78, align 4
  %919 = add i64 %918, 2053
  %920 = sub i64 %919, 1
  %921 = icmp sle i64 %886, %920
  %922 = icmp sle i64 %887, %920
  %923 = icmp sle i64 %888, %920
  %924 = icmp sle i64 %889, %920
  %925 = icmp sle i64 %890, %920
  %926 = icmp sle i64 %891, %920
  %927 = icmp sle i64 %892, %920
  %928 = icmp sle i64 %893, %920
  %929 = icmp sle i64 %894, %920
  %930 = icmp sle i64 %895, %920
  %931 = icmp sle i64 %896, %920
  %932 = icmp sle i64 %897, %920
  %933 = icmp sle i64 %898, %920
  %934 = icmp sle i64 %899, %920
  %935 = icmp sle i64 %900, %920
  %936 = icmp sle i64 %901, %920
  %937 = and i1 %902, %921
  store i1 %937, ptr %.spill79, align 1
  %938 = and i1 %903, %922
  store i1 %938, ptr %.spill80, align 1
  %939 = and i1 %904, %923
  store i1 %939, ptr %.spill81, align 1
  %940 = and i1 %905, %924
  store i1 %940, ptr %.spill82, align 1
  %941 = and i1 %906, %925
  store i1 %941, ptr %.spill83, align 1
  %942 = and i1 %907, %926
  store i1 %942, ptr %.spill84, align 1
  %943 = and i1 %908, %927
  store i1 %943, ptr %.spill85, align 1
  %944 = and i1 %909, %928
  store i1 %944, ptr %.spill86, align 1
  %945 = and i1 %910, %929
  store i1 %945, ptr %.spill87, align 1
  %946 = and i1 %911, %930
  store i1 %946, ptr %.spill88, align 1
  %947 = and i1 %912, %931
  store i1 %947, ptr %.spill89, align 1
  %948 = and i1 %913, %932
  store i1 %948, ptr %.spill90, align 1
  %949 = and i1 %914, %933
  store i1 %949, ptr %.spill91, align 1
  %950 = and i1 %915, %934
  store i1 %950, ptr %.spill92, align 1
  %951 = and i1 %916, %935
  store i1 %951, ptr %.spill93, align 1
  %952 = and i1 %917, %936
  store i1 %952, ptr %.spill94, align 1
  %.splatinsert532 = insertelement <8 x i1> poison, i1 %937, i64 0
  %.splat533 = shufflevector <8 x i1> %.splatinsert532, <8 x i1> poison, <8 x i32> zeroinitializer
  %953 = select <8 x i1> %.splat533, <8 x float> %870, <8 x float> splat (float 0xC6293E5940000000)
  %954 = load <8 x float>, ptr %.spill95, align 32
  %955 = select <8 x i1> %71, <8 x float> %953, <8 x float> %954
  store <8 x float> %955, ptr %.spill95, align 32
  %.splatinsert534 = insertelement <8 x i1> poison, i1 %938, i64 0
  %.splat535 = shufflevector <8 x i1> %.splatinsert534, <8 x i1> poison, <8 x i32> zeroinitializer
  %956 = select <8 x i1> %.splat535, <8 x float> %871, <8 x float> splat (float 0xC6293E5940000000)
  %957 = load <8 x float>, ptr %.spill96, align 32
  %958 = select <8 x i1> %71, <8 x float> %956, <8 x float> %957
  store <8 x float> %958, ptr %.spill96, align 32
  %.splatinsert536 = insertelement <8 x i1> poison, i1 %939, i64 0
  %.splat537 = shufflevector <8 x i1> %.splatinsert536, <8 x i1> poison, <8 x i32> zeroinitializer
  %959 = select <8 x i1> %.splat537, <8 x float> %872, <8 x float> splat (float 0xC6293E5940000000)
  %960 = load <8 x float>, ptr %.spill97, align 32
  %961 = select <8 x i1> %71, <8 x float> %959, <8 x float> %960
  store <8 x float> %961, ptr %.spill97, align 32
  %.splatinsert538 = insertelement <8 x i1> poison, i1 %940, i64 0
  %.splat539 = shufflevector <8 x i1> %.splatinsert538, <8 x i1> poison, <8 x i32> zeroinitializer
  %962 = select <8 x i1> %.splat539, <8 x float> %873, <8 x float> splat (float 0xC6293E5940000000)
  %963 = load <8 x float>, ptr %.spill98, align 32
  %964 = select <8 x i1> %71, <8 x float> %962, <8 x float> %963
  store <8 x float> %964, ptr %.spill98, align 32
  %.splatinsert540 = insertelement <8 x i1> poison, i1 %941, i64 0
  %.splat541 = shufflevector <8 x i1> %.splatinsert540, <8 x i1> poison, <8 x i32> zeroinitializer
  %965 = select <8 x i1> %.splat541, <8 x float> %874, <8 x float> splat (float 0xC6293E5940000000)
  %966 = load <8 x float>, ptr %.spill99, align 32
  %967 = select <8 x i1> %71, <8 x float> %965, <8 x float> %966
  store <8 x float> %967, ptr %.spill99, align 32
  %.splatinsert542 = insertelement <8 x i1> poison, i1 %942, i64 0
  %.splat543 = shufflevector <8 x i1> %.splatinsert542, <8 x i1> poison, <8 x i32> zeroinitializer
  %968 = select <8 x i1> %.splat543, <8 x float> %875, <8 x float> splat (float 0xC6293E5940000000)
  %969 = load <8 x float>, ptr %.spill100, align 32
  %970 = select <8 x i1> %71, <8 x float> %968, <8 x float> %969
  store <8 x float> %970, ptr %.spill100, align 32
  %.splatinsert544 = insertelement <8 x i1> poison, i1 %943, i64 0
  %.splat545 = shufflevector <8 x i1> %.splatinsert544, <8 x i1> poison, <8 x i32> zeroinitializer
  %971 = select <8 x i1> %.splat545, <8 x float> %876, <8 x float> splat (float 0xC6293E5940000000)
  %972 = load <8 x float>, ptr %.spill101, align 32
  %973 = select <8 x i1> %71, <8 x float> %971, <8 x float> %972
  store <8 x float> %973, ptr %.spill101, align 32
  %.splatinsert546 = insertelement <8 x i1> poison, i1 %944, i64 0
  %.splat547 = shufflevector <8 x i1> %.splatinsert546, <8 x i1> poison, <8 x i32> zeroinitializer
  %974 = select <8 x i1> %.splat547, <8 x float> %877, <8 x float> splat (float 0xC6293E5940000000)
  %975 = load <8 x float>, ptr %.spill102, align 32
  %976 = select <8 x i1> %71, <8 x float> %974, <8 x float> %975
  store <8 x float> %976, ptr %.spill102, align 32
  %.splatinsert548 = insertelement <8 x i1> poison, i1 %945, i64 0
  %.splat549 = shufflevector <8 x i1> %.splatinsert548, <8 x i1> poison, <8 x i32> zeroinitializer
  %977 = select <8 x i1> %.splat549, <8 x float> %878, <8 x float> splat (float 0xC6293E5940000000)
  %978 = load <8 x float>, ptr %.spill103, align 32
  %979 = select <8 x i1> %71, <8 x float> %977, <8 x float> %978
  store <8 x float> %979, ptr %.spill103, align 32
  %.splatinsert550 = insertelement <8 x i1> poison, i1 %946, i64 0
  %.splat551 = shufflevector <8 x i1> %.splatinsert550, <8 x i1> poison, <8 x i32> zeroinitializer
  %980 = select <8 x i1> %.splat551, <8 x float> %879, <8 x float> splat (float 0xC6293E5940000000)
  %981 = load <8 x float>, ptr %.spill104, align 32
  %982 = select <8 x i1> %71, <8 x float> %980, <8 x float> %981
  store <8 x float> %982, ptr %.spill104, align 32
  %.splatinsert552 = insertelement <8 x i1> poison, i1 %947, i64 0
  %.splat553 = shufflevector <8 x i1> %.splatinsert552, <8 x i1> poison, <8 x i32> zeroinitializer
  %983 = select <8 x i1> %.splat553, <8 x float> %880, <8 x float> splat (float 0xC6293E5940000000)
  %984 = load <8 x float>, ptr %.spill105, align 32
  %985 = select <8 x i1> %71, <8 x float> %983, <8 x float> %984
  store <8 x float> %985, ptr %.spill105, align 32
  %.splatinsert554 = insertelement <8 x i1> poison, i1 %948, i64 0
  %.splat555 = shufflevector <8 x i1> %.splatinsert554, <8 x i1> poison, <8 x i32> zeroinitializer
  %986 = select <8 x i1> %.splat555, <8 x float> %881, <8 x float> splat (float 0xC6293E5940000000)
  %987 = load <8 x float>, ptr %.spill106, align 32
  %988 = select <8 x i1> %71, <8 x float> %986, <8 x float> %987
  store <8 x float> %988, ptr %.spill106, align 32
  %.splatinsert556 = insertelement <8 x i1> poison, i1 %949, i64 0
  %.splat557 = shufflevector <8 x i1> %.splatinsert556, <8 x i1> poison, <8 x i32> zeroinitializer
  %989 = select <8 x i1> %.splat557, <8 x float> %882, <8 x float> splat (float 0xC6293E5940000000)
  %990 = load <8 x float>, ptr %.spill107, align 32
  %991 = select <8 x i1> %71, <8 x float> %989, <8 x float> %990
  store <8 x float> %991, ptr %.spill107, align 32
  %.splatinsert558 = insertelement <8 x i1> poison, i1 %950, i64 0
  %.splat559 = shufflevector <8 x i1> %.splatinsert558, <8 x i1> poison, <8 x i32> zeroinitializer
  %992 = select <8 x i1> %.splat559, <8 x float> %883, <8 x float> splat (float 0xC6293E5940000000)
  %993 = load <8 x float>, ptr %.spill108, align 32
  %994 = select <8 x i1> %71, <8 x float> %992, <8 x float> %993
  store <8 x float> %994, ptr %.spill108, align 32
  %.splatinsert560 = insertelement <8 x i1> poison, i1 %951, i64 0
  %.splat561 = shufflevector <8 x i1> %.splatinsert560, <8 x i1> poison, <8 x i32> zeroinitializer
  %995 = select <8 x i1> %.splat561, <8 x float> %884, <8 x float> splat (float 0xC6293E5940000000)
  %996 = load <8 x float>, ptr %.spill109, align 32
  %997 = select <8 x i1> %71, <8 x float> %995, <8 x float> %996
  store <8 x float> %997, ptr %.spill109, align 32
  %.splatinsert562 = insertelement <8 x i1> poison, i1 %952, i64 0
  %.splat563 = shufflevector <8 x i1> %.splatinsert562, <8 x i1> poison, <8 x i32> zeroinitializer
  %998 = select <8 x i1> %.splat563, <8 x float> %885, <8 x float> splat (float 0xC6293E5940000000)
  %999 = load <8 x float>, ptr %.spill110, align 32
  %1000 = select <8 x i1> %71, <8 x float> %998, <8 x float> %999
  store <8 x float> %1000, ptr %.spill110, align 32
  %1001 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 0
  %1004 = select <8 x i1> %71, <8 x ptr> %1002, <8 x ptr> %1003
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 1
  %1007 = select <8 x i1> %71, <8 x i64> %1005, <8 x i64> %1006
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } %1008, <8 x i64> %1007, 1
  store { <8 x ptr>, <8 x i64> } %1009, ptr %tile_snapshot.spill111, align 64
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1012 = add <8 x i64> %1011, zeroinitializer
  %1013 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1010, 0
  %1014 = insertvalue { <8 x ptr>, <8 x i64> } %1013, <8 x i64> %1012, 1
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %1014, 1
  %1017 = extractelement <8 x ptr> %1015, i32 0
  %1018 = extractelement <8 x i64> %1016, i32 0
  %1019 = sub i64 %1018, 0
  %1020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1021 = select i1 %1020, i64 %1019, i64 0
  %private.contiguous.address564 = getelementptr i8, ptr %1017, i64 %1021
  %private.contiguous.preserve565 = load <8 x float>, ptr %private.contiguous.address564, align 4
  %1022 = select <8 x i1> %71, <8 x float> %953, <8 x float> %private.contiguous.preserve565
  store <8 x float> %1022, ptr %private.contiguous.address564, align 4
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1025 = add <8 x i64> %1024, splat (i64 32)
  %1026 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1023, 0
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } %1026, <8 x i64> %1025, 1
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1027, 1
  %1030 = extractelement <8 x ptr> %1028, i32 0
  %1031 = extractelement <8 x i64> %1029, i32 0
  %1032 = sub i64 %1031, 0
  %1033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1034 = select i1 %1033, i64 %1032, i64 0
  %private.contiguous.address566 = getelementptr i8, ptr %1030, i64 %1034
  %private.contiguous.preserve567 = load <8 x float>, ptr %private.contiguous.address566, align 4
  %1035 = select <8 x i1> %71, <8 x float> %956, <8 x float> %private.contiguous.preserve567
  store <8 x float> %1035, ptr %private.contiguous.address566, align 4
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1038 = add <8 x i64> %1037, splat (i64 64)
  %1039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } %1039, <8 x i64> %1038, 1
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %1040, 1
  %1043 = extractelement <8 x ptr> %1041, i32 0
  %1044 = extractelement <8 x i64> %1042, i32 0
  %1045 = sub i64 %1044, 0
  %1046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1047 = select i1 %1046, i64 %1045, i64 0
  %private.contiguous.address568 = getelementptr i8, ptr %1043, i64 %1047
  %private.contiguous.preserve569 = load <8 x float>, ptr %private.contiguous.address568, align 4
  %1048 = select <8 x i1> %71, <8 x float> %959, <8 x float> %private.contiguous.preserve569
  store <8 x float> %1048, ptr %private.contiguous.address568, align 4
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1051 = add <8 x i64> %1050, splat (i64 96)
  %1052 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1049, 0
  %1053 = insertvalue { <8 x ptr>, <8 x i64> } %1052, <8 x i64> %1051, 1
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %1053, 1
  %1056 = extractelement <8 x ptr> %1054, i32 0
  %1057 = extractelement <8 x i64> %1055, i32 0
  %1058 = sub i64 %1057, 0
  %1059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1060 = select i1 %1059, i64 %1058, i64 0
  %private.contiguous.address570 = getelementptr i8, ptr %1056, i64 %1060
  %private.contiguous.preserve571 = load <8 x float>, ptr %private.contiguous.address570, align 4
  %1061 = select <8 x i1> %71, <8 x float> %962, <8 x float> %private.contiguous.preserve571
  store <8 x float> %1061, ptr %private.contiguous.address570, align 4
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1064 = add <8 x i64> %1063, splat (i64 128)
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1062, 0
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } %1065, <8 x i64> %1064, 1
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 1
  %1069 = extractelement <8 x ptr> %1067, i32 0
  %1070 = extractelement <8 x i64> %1068, i32 0
  %1071 = sub i64 %1070, 0
  %1072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1073 = select i1 %1072, i64 %1071, i64 0
  %private.contiguous.address572 = getelementptr i8, ptr %1069, i64 %1073
  %private.contiguous.preserve573 = load <8 x float>, ptr %private.contiguous.address572, align 4
  %1074 = select <8 x i1> %71, <8 x float> %965, <8 x float> %private.contiguous.preserve573
  store <8 x float> %1074, ptr %private.contiguous.address572, align 4
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1077 = add <8 x i64> %1076, splat (i64 160)
  %1078 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1075, 0
  %1079 = insertvalue { <8 x ptr>, <8 x i64> } %1078, <8 x i64> %1077, 1
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1079, 1
  %1082 = extractelement <8 x ptr> %1080, i32 0
  %1083 = extractelement <8 x i64> %1081, i32 0
  %1084 = sub i64 %1083, 0
  %1085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1086 = select i1 %1085, i64 %1084, i64 0
  %private.contiguous.address574 = getelementptr i8, ptr %1082, i64 %1086
  %private.contiguous.preserve575 = load <8 x float>, ptr %private.contiguous.address574, align 4
  %1087 = select <8 x i1> %71, <8 x float> %968, <8 x float> %private.contiguous.preserve575
  store <8 x float> %1087, ptr %private.contiguous.address574, align 4
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1090 = add <8 x i64> %1089, splat (i64 192)
  %1091 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1088, 0
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } %1091, <8 x i64> %1090, 1
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1092, 1
  %1095 = extractelement <8 x ptr> %1093, i32 0
  %1096 = extractelement <8 x i64> %1094, i32 0
  %1097 = sub i64 %1096, 0
  %1098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1099 = select i1 %1098, i64 %1097, i64 0
  %private.contiguous.address576 = getelementptr i8, ptr %1095, i64 %1099
  %private.contiguous.preserve577 = load <8 x float>, ptr %private.contiguous.address576, align 4
  %1100 = select <8 x i1> %71, <8 x float> %971, <8 x float> %private.contiguous.preserve577
  store <8 x float> %1100, ptr %private.contiguous.address576, align 4
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1103 = add <8 x i64> %1102, splat (i64 224)
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1101, 0
  %1105 = insertvalue { <8 x ptr>, <8 x i64> } %1104, <8 x i64> %1103, 1
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %1105, 1
  %1108 = extractelement <8 x ptr> %1106, i32 0
  %1109 = extractelement <8 x i64> %1107, i32 0
  %1110 = sub i64 %1109, 0
  %1111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1112 = select i1 %1111, i64 %1110, i64 0
  %private.contiguous.address578 = getelementptr i8, ptr %1108, i64 %1112
  %private.contiguous.preserve579 = load <8 x float>, ptr %private.contiguous.address578, align 4
  %1113 = select <8 x i1> %71, <8 x float> %974, <8 x float> %private.contiguous.preserve579
  store <8 x float> %1113, ptr %private.contiguous.address578, align 4
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1116 = add <8 x i64> %1115, splat (i64 256)
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1114, 0
  %1118 = insertvalue { <8 x ptr>, <8 x i64> } %1117, <8 x i64> %1116, 1
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 1
  %1121 = extractelement <8 x ptr> %1119, i32 0
  %1122 = extractelement <8 x i64> %1120, i32 0
  %1123 = sub i64 %1122, 0
  %1124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1125 = select i1 %1124, i64 %1123, i64 0
  %private.contiguous.address580 = getelementptr i8, ptr %1121, i64 %1125
  %private.contiguous.preserve581 = load <8 x float>, ptr %private.contiguous.address580, align 4
  %1126 = select <8 x i1> %71, <8 x float> %977, <8 x float> %private.contiguous.preserve581
  store <8 x float> %1126, ptr %private.contiguous.address580, align 4
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1129 = add <8 x i64> %1128, splat (i64 288)
  %1130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1127, 0
  %1131 = insertvalue { <8 x ptr>, <8 x i64> } %1130, <8 x i64> %1129, 1
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %1131, 1
  %1134 = extractelement <8 x ptr> %1132, i32 0
  %1135 = extractelement <8 x i64> %1133, i32 0
  %1136 = sub i64 %1135, 0
  %1137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1138 = select i1 %1137, i64 %1136, i64 0
  %private.contiguous.address582 = getelementptr i8, ptr %1134, i64 %1138
  %private.contiguous.preserve583 = load <8 x float>, ptr %private.contiguous.address582, align 4
  %1139 = select <8 x i1> %71, <8 x float> %980, <8 x float> %private.contiguous.preserve583
  store <8 x float> %1139, ptr %private.contiguous.address582, align 4
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1142 = add <8 x i64> %1141, splat (i64 320)
  %1143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } %1143, <8 x i64> %1142, 1
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1144, 1
  %1147 = extractelement <8 x ptr> %1145, i32 0
  %1148 = extractelement <8 x i64> %1146, i32 0
  %1149 = sub i64 %1148, 0
  %1150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1151 = select i1 %1150, i64 %1149, i64 0
  %private.contiguous.address584 = getelementptr i8, ptr %1147, i64 %1151
  %private.contiguous.preserve585 = load <8 x float>, ptr %private.contiguous.address584, align 4
  %1152 = select <8 x i1> %71, <8 x float> %983, <8 x float> %private.contiguous.preserve585
  store <8 x float> %1152, ptr %private.contiguous.address584, align 4
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1155 = add <8 x i64> %1154, splat (i64 352)
  %1156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1153, 0
  %1157 = insertvalue { <8 x ptr>, <8 x i64> } %1156, <8 x i64> %1155, 1
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %1157, 1
  %1160 = extractelement <8 x ptr> %1158, i32 0
  %1161 = extractelement <8 x i64> %1159, i32 0
  %1162 = sub i64 %1161, 0
  %1163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1164 = select i1 %1163, i64 %1162, i64 0
  %private.contiguous.address586 = getelementptr i8, ptr %1160, i64 %1164
  %private.contiguous.preserve587 = load <8 x float>, ptr %private.contiguous.address586, align 4
  %1165 = select <8 x i1> %71, <8 x float> %986, <8 x float> %private.contiguous.preserve587
  store <8 x float> %1165, ptr %private.contiguous.address586, align 4
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1168 = add <8 x i64> %1167, splat (i64 384)
  %1169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1166, 0
  %1170 = insertvalue { <8 x ptr>, <8 x i64> } %1169, <8 x i64> %1168, 1
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %1170, 1
  %1173 = extractelement <8 x ptr> %1171, i32 0
  %1174 = extractelement <8 x i64> %1172, i32 0
  %1175 = sub i64 %1174, 0
  %1176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1177 = select i1 %1176, i64 %1175, i64 0
  %private.contiguous.address588 = getelementptr i8, ptr %1173, i64 %1177
  %private.contiguous.preserve589 = load <8 x float>, ptr %private.contiguous.address588, align 4
  %1178 = select <8 x i1> %71, <8 x float> %989, <8 x float> %private.contiguous.preserve589
  store <8 x float> %1178, ptr %private.contiguous.address588, align 4
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1181 = add <8 x i64> %1180, splat (i64 416)
  %1182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1179, 0
  %1183 = insertvalue { <8 x ptr>, <8 x i64> } %1182, <8 x i64> %1181, 1
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %1183, 1
  %1186 = extractelement <8 x ptr> %1184, i32 0
  %1187 = extractelement <8 x i64> %1185, i32 0
  %1188 = sub i64 %1187, 0
  %1189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1190 = select i1 %1189, i64 %1188, i64 0
  %private.contiguous.address590 = getelementptr i8, ptr %1186, i64 %1190
  %private.contiguous.preserve591 = load <8 x float>, ptr %private.contiguous.address590, align 4
  %1191 = select <8 x i1> %71, <8 x float> %992, <8 x float> %private.contiguous.preserve591
  store <8 x float> %1191, ptr %private.contiguous.address590, align 4
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1194 = add <8 x i64> %1193, splat (i64 448)
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1192, 0
  %1196 = insertvalue { <8 x ptr>, <8 x i64> } %1195, <8 x i64> %1194, 1
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 1
  %1199 = extractelement <8 x ptr> %1197, i32 0
  %1200 = extractelement <8 x i64> %1198, i32 0
  %1201 = sub i64 %1200, 0
  %1202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1203 = select i1 %1202, i64 %1201, i64 0
  %private.contiguous.address592 = getelementptr i8, ptr %1199, i64 %1203
  %private.contiguous.preserve593 = load <8 x float>, ptr %private.contiguous.address592, align 4
  %1204 = select <8 x i1> %71, <8 x float> %995, <8 x float> %private.contiguous.preserve593
  store <8 x float> %1204, ptr %private.contiguous.address592, align 4
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1207 = add <8 x i64> %1206, splat (i64 480)
  %1208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1205, 0
  %1209 = insertvalue { <8 x ptr>, <8 x i64> } %1208, <8 x i64> %1207, 1
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1211 = extractvalue { <8 x ptr>, <8 x i64> } %1209, 1
  %1212 = extractelement <8 x ptr> %1210, i32 0
  %1213 = extractelement <8 x i64> %1211, i32 0
  %1214 = sub i64 %1213, 0
  %1215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1216 = select i1 %1215, i64 %1214, i64 0
  %private.contiguous.address594 = getelementptr i8, ptr %1212, i64 %1216
  %private.contiguous.preserve595 = load <8 x float>, ptr %private.contiguous.address594, align 4
  %1217 = select <8 x i1> %71, <8 x float> %998, <8 x float> %private.contiguous.preserve595
  store <8 x float> %1217, ptr %private.contiguous.address594, align 4
  store i64 0, ptr %.slot112, align 4
  %1218 = load <8 x float>, ptr %.slot113, align 32
  %1219 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1218
  store <8 x float> %1219, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state596 = load i64, ptr %.slot112, align 4
  %1220 = icmp slt i64 %.state596, 16
  br i1 %1220, label %direct.true597, label %direct.false598

direct.schedule.68:                               ; preds = %direct.true597
  %.state599 = load i64, ptr %.slot112, align 4
  %1221 = sdiv i64 %.state599, 1
  %.spill.load600 = load i64, ptr %.spill78, align 4
  %1222 = mul i64 %.spill.load600, 1
  %1223 = add i64 %1222, 0
  %1224 = mul i64 %1223, 1
  %1225 = add i64 %1224, 0
  %1226 = mul i64 %1225, 16
  %1227 = add i64 %1226, %1221
  %tile_snapshot.spill.load601 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load601, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load601, 1
  %.splatinsert602 = insertelement <8 x i64> poison, i64 %1227, i64 0
  %.splat603 = shufflevector <8 x i64> %.splatinsert602, <8 x i64> poison, <8 x i32> zeroinitializer
  %1230 = mul <8 x i64> %.splat603, splat (i64 32)
  %1231 = add <8 x i64> %1229, %1230
  %1232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1228, 0
  %1233 = insertvalue { <8 x ptr>, <8 x i64> } %1232, <8 x i64> %1231, 1
  %1234 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1235 = extractvalue { <8 x ptr>, <8 x i64> } %1233, 1
  %1236 = extractelement <8 x ptr> %1234, i32 0
  %1237 = extractelement <8 x i64> %1235, i32 0
  %1238 = sub i64 %1237, 0
  %1239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1240 = select i1 %1239, i64 %1238, i64 0
  %private.contiguous.address604 = getelementptr i8, ptr %1236, i64 %1240
  %private.contiguous.load605 = load <8 x float>, ptr %private.contiguous.address604, align 4
  %1241 = select <8 x i1> %71, <8 x float> %private.contiguous.load605, <8 x float> zeroinitializer
  %.state606 = load <8 x float>, ptr %.slot113, align 32
  %1242 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state606, <8 x float> %1241)
  %.state607 = load i64, ptr %.slot112, align 4
  %1243 = add i64 %.state607, 1
  store i64 %1243, ptr %.slot112, align 4
  %1244 = load <8 x float>, ptr %.slot113, align 32
  %1245 = select <8 x i1> %71, <8 x float> %1242, <8 x float> %1244
  store <8 x float> %1245, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false598
  %.state608 = load <8 x float>, ptr %.slot35, align 32
  %.state609 = load <8 x float>, ptr %.slot113, align 32
  %1246 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state608, <8 x float> %.state609)
  %1247 = load <8 x float>, ptr %.spill114, align 32
  %1248 = select <8 x i1> %71, <8 x float> %1246, <8 x float> %1247
  store <8 x float> %1248, ptr %.spill114, align 32
  %.state610 = load <8 x float>, ptr %.slot35, align 32
  %1249 = fsub <8 x float> %.state610, %1246
  %1250 = select <8 x i1> %71, <8 x float> %1249, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1250)
  %1251 = load <8 x float>, ptr %.spill115, align 32
  %1252 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1251
  store <8 x float> %1252, ptr %.spill115, align 32
  %.spill.load611 = load <8 x float>, ptr %.spill95, align 32
  %1253 = fsub <8 x float> %.spill.load611, %1246
  %.spill.load612 = load <8 x float>, ptr %.spill96, align 32
  %1254 = fsub <8 x float> %.spill.load612, %1246
  %.spill.load613 = load <8 x float>, ptr %.spill97, align 32
  %1255 = fsub <8 x float> %.spill.load613, %1246
  %.spill.load614 = load <8 x float>, ptr %.spill98, align 32
  %1256 = fsub <8 x float> %.spill.load614, %1246
  %.spill.load615 = load <8 x float>, ptr %.spill99, align 32
  %1257 = fsub <8 x float> %.spill.load615, %1246
  %.spill.load616 = load <8 x float>, ptr %.spill100, align 32
  %1258 = fsub <8 x float> %.spill.load616, %1246
  %.spill.load617 = load <8 x float>, ptr %.spill101, align 32
  %1259 = fsub <8 x float> %.spill.load617, %1246
  %.spill.load618 = load <8 x float>, ptr %.spill102, align 32
  %1260 = fsub <8 x float> %.spill.load618, %1246
  %.spill.load619 = load <8 x float>, ptr %.spill103, align 32
  %1261 = fsub <8 x float> %.spill.load619, %1246
  %.spill.load620 = load <8 x float>, ptr %.spill104, align 32
  %1262 = fsub <8 x float> %.spill.load620, %1246
  %.spill.load621 = load <8 x float>, ptr %.spill105, align 32
  %1263 = fsub <8 x float> %.spill.load621, %1246
  %.spill.load622 = load <8 x float>, ptr %.spill106, align 32
  %1264 = fsub <8 x float> %.spill.load622, %1246
  %.spill.load623 = load <8 x float>, ptr %.spill107, align 32
  %1265 = fsub <8 x float> %.spill.load623, %1246
  %.spill.load624 = load <8 x float>, ptr %.spill108, align 32
  %1266 = fsub <8 x float> %.spill.load624, %1246
  %.spill.load625 = load <8 x float>, ptr %.spill109, align 32
  %1267 = fsub <8 x float> %.spill.load625, %1246
  %.spill.load626 = load <8 x float>, ptr %.spill110, align 32
  %1268 = fsub <8 x float> %.spill.load626, %1246
  %1269 = select <8 x i1> %71, <8 x float> %1253, <8 x float> zeroinitializer
  %native.exp627 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1269)
  %1270 = select <8 x i1> %71, <8 x float> %1254, <8 x float> zeroinitializer
  %native.exp628 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1270)
  %1271 = select <8 x i1> %71, <8 x float> %1255, <8 x float> zeroinitializer
  %native.exp629 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1271)
  %1272 = select <8 x i1> %71, <8 x float> %1256, <8 x float> zeroinitializer
  %native.exp630 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1272)
  %1273 = select <8 x i1> %71, <8 x float> %1257, <8 x float> zeroinitializer
  %native.exp631 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1273)
  %1274 = select <8 x i1> %71, <8 x float> %1258, <8 x float> zeroinitializer
  %native.exp632 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1274)
  %1275 = select <8 x i1> %71, <8 x float> %1259, <8 x float> zeroinitializer
  %native.exp633 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1275)
  %1276 = select <8 x i1> %71, <8 x float> %1260, <8 x float> zeroinitializer
  %native.exp634 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1276)
  %1277 = select <8 x i1> %71, <8 x float> %1261, <8 x float> zeroinitializer
  %native.exp635 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1277)
  %1278 = select <8 x i1> %71, <8 x float> %1262, <8 x float> zeroinitializer
  %native.exp636 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1278)
  %1279 = select <8 x i1> %71, <8 x float> %1263, <8 x float> zeroinitializer
  %native.exp637 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1279)
  %1280 = select <8 x i1> %71, <8 x float> %1264, <8 x float> zeroinitializer
  %native.exp638 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1280)
  %1281 = select <8 x i1> %71, <8 x float> %1265, <8 x float> zeroinitializer
  %native.exp639 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1281)
  %1282 = select <8 x i1> %71, <8 x float> %1266, <8 x float> zeroinitializer
  %native.exp640 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1282)
  %1283 = select <8 x i1> %71, <8 x float> %1267, <8 x float> zeroinitializer
  %native.exp641 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1283)
  %1284 = select <8 x i1> %71, <8 x float> %1268, <8 x float> zeroinitializer
  %native.exp642 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1284)
  %.spill.load643 = load i1, ptr %.spill79, align 1
  %.splatinsert644 = insertelement <8 x i1> poison, i1 %.spill.load643, i64 0
  %.splat645 = shufflevector <8 x i1> %.splatinsert644, <8 x i1> poison, <8 x i32> zeroinitializer
  %1285 = select <8 x i1> %.splat645, <8 x float> %native.exp627, <8 x float> zeroinitializer
  %1286 = load <8 x float>, ptr %.spill116, align 32
  %1287 = select <8 x i1> %71, <8 x float> %1285, <8 x float> %1286
  store <8 x float> %1287, ptr %.spill116, align 32
  %.spill.load646 = load i1, ptr %.spill80, align 1
  %.splatinsert647 = insertelement <8 x i1> poison, i1 %.spill.load646, i64 0
  %.splat648 = shufflevector <8 x i1> %.splatinsert647, <8 x i1> poison, <8 x i32> zeroinitializer
  %1288 = select <8 x i1> %.splat648, <8 x float> %native.exp628, <8 x float> zeroinitializer
  %1289 = load <8 x float>, ptr %.spill117, align 32
  %1290 = select <8 x i1> %71, <8 x float> %1288, <8 x float> %1289
  store <8 x float> %1290, ptr %.spill117, align 32
  %.spill.load649 = load i1, ptr %.spill81, align 1
  %.splatinsert650 = insertelement <8 x i1> poison, i1 %.spill.load649, i64 0
  %.splat651 = shufflevector <8 x i1> %.splatinsert650, <8 x i1> poison, <8 x i32> zeroinitializer
  %1291 = select <8 x i1> %.splat651, <8 x float> %native.exp629, <8 x float> zeroinitializer
  %1292 = load <8 x float>, ptr %.spill118, align 32
  %1293 = select <8 x i1> %71, <8 x float> %1291, <8 x float> %1292
  store <8 x float> %1293, ptr %.spill118, align 32
  %.spill.load652 = load i1, ptr %.spill82, align 1
  %.splatinsert653 = insertelement <8 x i1> poison, i1 %.spill.load652, i64 0
  %.splat654 = shufflevector <8 x i1> %.splatinsert653, <8 x i1> poison, <8 x i32> zeroinitializer
  %1294 = select <8 x i1> %.splat654, <8 x float> %native.exp630, <8 x float> zeroinitializer
  %1295 = load <8 x float>, ptr %.spill119, align 32
  %1296 = select <8 x i1> %71, <8 x float> %1294, <8 x float> %1295
  store <8 x float> %1296, ptr %.spill119, align 32
  %.spill.load655 = load i1, ptr %.spill83, align 1
  %.splatinsert656 = insertelement <8 x i1> poison, i1 %.spill.load655, i64 0
  %.splat657 = shufflevector <8 x i1> %.splatinsert656, <8 x i1> poison, <8 x i32> zeroinitializer
  %1297 = select <8 x i1> %.splat657, <8 x float> %native.exp631, <8 x float> zeroinitializer
  %1298 = load <8 x float>, ptr %.spill120, align 32
  %1299 = select <8 x i1> %71, <8 x float> %1297, <8 x float> %1298
  store <8 x float> %1299, ptr %.spill120, align 32
  %.spill.load658 = load i1, ptr %.spill84, align 1
  %.splatinsert659 = insertelement <8 x i1> poison, i1 %.spill.load658, i64 0
  %.splat660 = shufflevector <8 x i1> %.splatinsert659, <8 x i1> poison, <8 x i32> zeroinitializer
  %1300 = select <8 x i1> %.splat660, <8 x float> %native.exp632, <8 x float> zeroinitializer
  %1301 = load <8 x float>, ptr %.spill121, align 32
  %1302 = select <8 x i1> %71, <8 x float> %1300, <8 x float> %1301
  store <8 x float> %1302, ptr %.spill121, align 32
  %.spill.load661 = load i1, ptr %.spill85, align 1
  %.splatinsert662 = insertelement <8 x i1> poison, i1 %.spill.load661, i64 0
  %.splat663 = shufflevector <8 x i1> %.splatinsert662, <8 x i1> poison, <8 x i32> zeroinitializer
  %1303 = select <8 x i1> %.splat663, <8 x float> %native.exp633, <8 x float> zeroinitializer
  %1304 = load <8 x float>, ptr %.spill122, align 32
  %1305 = select <8 x i1> %71, <8 x float> %1303, <8 x float> %1304
  store <8 x float> %1305, ptr %.spill122, align 32
  %.spill.load664 = load i1, ptr %.spill86, align 1
  %.splatinsert665 = insertelement <8 x i1> poison, i1 %.spill.load664, i64 0
  %.splat666 = shufflevector <8 x i1> %.splatinsert665, <8 x i1> poison, <8 x i32> zeroinitializer
  %1306 = select <8 x i1> %.splat666, <8 x float> %native.exp634, <8 x float> zeroinitializer
  %1307 = load <8 x float>, ptr %.spill123, align 32
  %1308 = select <8 x i1> %71, <8 x float> %1306, <8 x float> %1307
  store <8 x float> %1308, ptr %.spill123, align 32
  %.spill.load667 = load i1, ptr %.spill87, align 1
  %.splatinsert668 = insertelement <8 x i1> poison, i1 %.spill.load667, i64 0
  %.splat669 = shufflevector <8 x i1> %.splatinsert668, <8 x i1> poison, <8 x i32> zeroinitializer
  %1309 = select <8 x i1> %.splat669, <8 x float> %native.exp635, <8 x float> zeroinitializer
  %1310 = load <8 x float>, ptr %.spill124, align 32
  %1311 = select <8 x i1> %71, <8 x float> %1309, <8 x float> %1310
  store <8 x float> %1311, ptr %.spill124, align 32
  %.spill.load670 = load i1, ptr %.spill88, align 1
  %.splatinsert671 = insertelement <8 x i1> poison, i1 %.spill.load670, i64 0
  %.splat672 = shufflevector <8 x i1> %.splatinsert671, <8 x i1> poison, <8 x i32> zeroinitializer
  %1312 = select <8 x i1> %.splat672, <8 x float> %native.exp636, <8 x float> zeroinitializer
  %1313 = load <8 x float>, ptr %.spill125, align 32
  %1314 = select <8 x i1> %71, <8 x float> %1312, <8 x float> %1313
  store <8 x float> %1314, ptr %.spill125, align 32
  %.spill.load673 = load i1, ptr %.spill89, align 1
  %.splatinsert674 = insertelement <8 x i1> poison, i1 %.spill.load673, i64 0
  %.splat675 = shufflevector <8 x i1> %.splatinsert674, <8 x i1> poison, <8 x i32> zeroinitializer
  %1315 = select <8 x i1> %.splat675, <8 x float> %native.exp637, <8 x float> zeroinitializer
  %1316 = load <8 x float>, ptr %.spill126, align 32
  %1317 = select <8 x i1> %71, <8 x float> %1315, <8 x float> %1316
  store <8 x float> %1317, ptr %.spill126, align 32
  %.spill.load676 = load i1, ptr %.spill90, align 1
  %.splatinsert677 = insertelement <8 x i1> poison, i1 %.spill.load676, i64 0
  %.splat678 = shufflevector <8 x i1> %.splatinsert677, <8 x i1> poison, <8 x i32> zeroinitializer
  %1318 = select <8 x i1> %.splat678, <8 x float> %native.exp638, <8 x float> zeroinitializer
  %1319 = load <8 x float>, ptr %.spill127, align 32
  %1320 = select <8 x i1> %71, <8 x float> %1318, <8 x float> %1319
  store <8 x float> %1320, ptr %.spill127, align 32
  %.spill.load679 = load i1, ptr %.spill91, align 1
  %.splatinsert680 = insertelement <8 x i1> poison, i1 %.spill.load679, i64 0
  %.splat681 = shufflevector <8 x i1> %.splatinsert680, <8 x i1> poison, <8 x i32> zeroinitializer
  %1321 = select <8 x i1> %.splat681, <8 x float> %native.exp639, <8 x float> zeroinitializer
  %1322 = load <8 x float>, ptr %.spill128, align 32
  %1323 = select <8 x i1> %71, <8 x float> %1321, <8 x float> %1322
  store <8 x float> %1323, ptr %.spill128, align 32
  %.spill.load682 = load i1, ptr %.spill92, align 1
  %.splatinsert683 = insertelement <8 x i1> poison, i1 %.spill.load682, i64 0
  %.splat684 = shufflevector <8 x i1> %.splatinsert683, <8 x i1> poison, <8 x i32> zeroinitializer
  %1324 = select <8 x i1> %.splat684, <8 x float> %native.exp640, <8 x float> zeroinitializer
  %1325 = load <8 x float>, ptr %.spill129, align 32
  %1326 = select <8 x i1> %71, <8 x float> %1324, <8 x float> %1325
  store <8 x float> %1326, ptr %.spill129, align 32
  %.spill.load685 = load i1, ptr %.spill93, align 1
  %.splatinsert686 = insertelement <8 x i1> poison, i1 %.spill.load685, i64 0
  %.splat687 = shufflevector <8 x i1> %.splatinsert686, <8 x i1> poison, <8 x i32> zeroinitializer
  %1327 = select <8 x i1> %.splat687, <8 x float> %native.exp641, <8 x float> zeroinitializer
  %1328 = load <8 x float>, ptr %.spill130, align 32
  %1329 = select <8 x i1> %71, <8 x float> %1327, <8 x float> %1328
  store <8 x float> %1329, ptr %.spill130, align 32
  %.spill.load688 = load i1, ptr %.spill94, align 1
  %.splatinsert689 = insertelement <8 x i1> poison, i1 %.spill.load688, i64 0
  %.splat690 = shufflevector <8 x i1> %.splatinsert689, <8 x i1> poison, <8 x i32> zeroinitializer
  %1330 = select <8 x i1> %.splat690, <8 x float> %native.exp642, <8 x float> zeroinitializer
  %1331 = load <8 x float>, ptr %.spill131, align 32
  %1332 = select <8 x i1> %71, <8 x float> %1330, <8 x float> %1331
  store <8 x float> %1332, ptr %.spill131, align 32
  %1333 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %1334 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1335 = extractvalue { <8 x ptr>, <8 x i64> } %1333, 0
  %1336 = select <8 x i1> %71, <8 x ptr> %1334, <8 x ptr> %1335
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1338 = extractvalue { <8 x ptr>, <8 x i64> } %1333, 1
  %1339 = select <8 x i1> %71, <8 x i64> %1337, <8 x i64> %1338
  %1340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1336, 0
  %1341 = insertvalue { <8 x ptr>, <8 x i64> } %1340, <8 x i64> %1339, 1
  store { <8 x ptr>, <8 x i64> } %1341, ptr %tile_snapshot.spill132, align 64
  %1342 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1343 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1344 = add <8 x i64> %1343, zeroinitializer
  %1345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1342, 0
  %1346 = insertvalue { <8 x ptr>, <8 x i64> } %1345, <8 x i64> %1344, 1
  %1347 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1348 = extractvalue { <8 x ptr>, <8 x i64> } %1346, 1
  %1349 = extractelement <8 x ptr> %1347, i32 0
  %1350 = extractelement <8 x i64> %1348, i32 0
  %1351 = sub i64 %1350, 0
  %1352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1353 = select i1 %1352, i64 %1351, i64 0
  %private.contiguous.address691 = getelementptr i8, ptr %1349, i64 %1353
  %private.contiguous.preserve692 = load <8 x float>, ptr %private.contiguous.address691, align 4
  %1354 = select <8 x i1> %71, <8 x float> %1285, <8 x float> %private.contiguous.preserve692
  store <8 x float> %1354, ptr %private.contiguous.address691, align 4
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1356 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1357 = add <8 x i64> %1356, splat (i64 32)
  %1358 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1355, 0
  %1359 = insertvalue { <8 x ptr>, <8 x i64> } %1358, <8 x i64> %1357, 1
  %1360 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1361 = extractvalue { <8 x ptr>, <8 x i64> } %1359, 1
  %1362 = extractelement <8 x ptr> %1360, i32 0
  %1363 = extractelement <8 x i64> %1361, i32 0
  %1364 = sub i64 %1363, 0
  %1365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1366 = select i1 %1365, i64 %1364, i64 0
  %private.contiguous.address693 = getelementptr i8, ptr %1362, i64 %1366
  %private.contiguous.preserve694 = load <8 x float>, ptr %private.contiguous.address693, align 4
  %1367 = select <8 x i1> %71, <8 x float> %1288, <8 x float> %private.contiguous.preserve694
  store <8 x float> %1367, ptr %private.contiguous.address693, align 4
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1370 = add <8 x i64> %1369, splat (i64 64)
  %1371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1368, 0
  %1372 = insertvalue { <8 x ptr>, <8 x i64> } %1371, <8 x i64> %1370, 1
  %1373 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %1372, 1
  %1375 = extractelement <8 x ptr> %1373, i32 0
  %1376 = extractelement <8 x i64> %1374, i32 0
  %1377 = sub i64 %1376, 0
  %1378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1379 = select i1 %1378, i64 %1377, i64 0
  %private.contiguous.address695 = getelementptr i8, ptr %1375, i64 %1379
  %private.contiguous.preserve696 = load <8 x float>, ptr %private.contiguous.address695, align 4
  %1380 = select <8 x i1> %71, <8 x float> %1291, <8 x float> %private.contiguous.preserve696
  store <8 x float> %1380, ptr %private.contiguous.address695, align 4
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1382 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1383 = add <8 x i64> %1382, splat (i64 96)
  %1384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1381, 0
  %1385 = insertvalue { <8 x ptr>, <8 x i64> } %1384, <8 x i64> %1383, 1
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1387 = extractvalue { <8 x ptr>, <8 x i64> } %1385, 1
  %1388 = extractelement <8 x ptr> %1386, i32 0
  %1389 = extractelement <8 x i64> %1387, i32 0
  %1390 = sub i64 %1389, 0
  %1391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1392 = select i1 %1391, i64 %1390, i64 0
  %private.contiguous.address697 = getelementptr i8, ptr %1388, i64 %1392
  %private.contiguous.preserve698 = load <8 x float>, ptr %private.contiguous.address697, align 4
  %1393 = select <8 x i1> %71, <8 x float> %1294, <8 x float> %private.contiguous.preserve698
  store <8 x float> %1393, ptr %private.contiguous.address697, align 4
  %1394 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1395 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1396 = add <8 x i64> %1395, splat (i64 128)
  %1397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1394, 0
  %1398 = insertvalue { <8 x ptr>, <8 x i64> } %1397, <8 x i64> %1396, 1
  %1399 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1400 = extractvalue { <8 x ptr>, <8 x i64> } %1398, 1
  %1401 = extractelement <8 x ptr> %1399, i32 0
  %1402 = extractelement <8 x i64> %1400, i32 0
  %1403 = sub i64 %1402, 0
  %1404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1405 = select i1 %1404, i64 %1403, i64 0
  %private.contiguous.address699 = getelementptr i8, ptr %1401, i64 %1405
  %private.contiguous.preserve700 = load <8 x float>, ptr %private.contiguous.address699, align 4
  %1406 = select <8 x i1> %71, <8 x float> %1297, <8 x float> %private.contiguous.preserve700
  store <8 x float> %1406, ptr %private.contiguous.address699, align 4
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1408 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1409 = add <8 x i64> %1408, splat (i64 160)
  %1410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1407, 0
  %1411 = insertvalue { <8 x ptr>, <8 x i64> } %1410, <8 x i64> %1409, 1
  %1412 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1413 = extractvalue { <8 x ptr>, <8 x i64> } %1411, 1
  %1414 = extractelement <8 x ptr> %1412, i32 0
  %1415 = extractelement <8 x i64> %1413, i32 0
  %1416 = sub i64 %1415, 0
  %1417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1418 = select i1 %1417, i64 %1416, i64 0
  %private.contiguous.address701 = getelementptr i8, ptr %1414, i64 %1418
  %private.contiguous.preserve702 = load <8 x float>, ptr %private.contiguous.address701, align 4
  %1419 = select <8 x i1> %71, <8 x float> %1300, <8 x float> %private.contiguous.preserve702
  store <8 x float> %1419, ptr %private.contiguous.address701, align 4
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1421 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1422 = add <8 x i64> %1421, splat (i64 192)
  %1423 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1420, 0
  %1424 = insertvalue { <8 x ptr>, <8 x i64> } %1423, <8 x i64> %1422, 1
  %1425 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1426 = extractvalue { <8 x ptr>, <8 x i64> } %1424, 1
  %1427 = extractelement <8 x ptr> %1425, i32 0
  %1428 = extractelement <8 x i64> %1426, i32 0
  %1429 = sub i64 %1428, 0
  %1430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1431 = select i1 %1430, i64 %1429, i64 0
  %private.contiguous.address703 = getelementptr i8, ptr %1427, i64 %1431
  %private.contiguous.preserve704 = load <8 x float>, ptr %private.contiguous.address703, align 4
  %1432 = select <8 x i1> %71, <8 x float> %1303, <8 x float> %private.contiguous.preserve704
  store <8 x float> %1432, ptr %private.contiguous.address703, align 4
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1435 = add <8 x i64> %1434, splat (i64 224)
  %1436 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1433, 0
  %1437 = insertvalue { <8 x ptr>, <8 x i64> } %1436, <8 x i64> %1435, 1
  %1438 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %1437, 1
  %1440 = extractelement <8 x ptr> %1438, i32 0
  %1441 = extractelement <8 x i64> %1439, i32 0
  %1442 = sub i64 %1441, 0
  %1443 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1444 = select i1 %1443, i64 %1442, i64 0
  %private.contiguous.address705 = getelementptr i8, ptr %1440, i64 %1444
  %private.contiguous.preserve706 = load <8 x float>, ptr %private.contiguous.address705, align 4
  %1445 = select <8 x i1> %71, <8 x float> %1306, <8 x float> %private.contiguous.preserve706
  store <8 x float> %1445, ptr %private.contiguous.address705, align 4
  %1446 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1447 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1448 = add <8 x i64> %1447, splat (i64 256)
  %1449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1446, 0
  %1450 = insertvalue { <8 x ptr>, <8 x i64> } %1449, <8 x i64> %1448, 1
  %1451 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1452 = extractvalue { <8 x ptr>, <8 x i64> } %1450, 1
  %1453 = extractelement <8 x ptr> %1451, i32 0
  %1454 = extractelement <8 x i64> %1452, i32 0
  %1455 = sub i64 %1454, 0
  %1456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1457 = select i1 %1456, i64 %1455, i64 0
  %private.contiguous.address707 = getelementptr i8, ptr %1453, i64 %1457
  %private.contiguous.preserve708 = load <8 x float>, ptr %private.contiguous.address707, align 4
  %1458 = select <8 x i1> %71, <8 x float> %1309, <8 x float> %private.contiguous.preserve708
  store <8 x float> %1458, ptr %private.contiguous.address707, align 4
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1460 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1461 = add <8 x i64> %1460, splat (i64 288)
  %1462 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1459, 0
  %1463 = insertvalue { <8 x ptr>, <8 x i64> } %1462, <8 x i64> %1461, 1
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1465 = extractvalue { <8 x ptr>, <8 x i64> } %1463, 1
  %1466 = extractelement <8 x ptr> %1464, i32 0
  %1467 = extractelement <8 x i64> %1465, i32 0
  %1468 = sub i64 %1467, 0
  %1469 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1470 = select i1 %1469, i64 %1468, i64 0
  %private.contiguous.address709 = getelementptr i8, ptr %1466, i64 %1470
  %private.contiguous.preserve710 = load <8 x float>, ptr %private.contiguous.address709, align 4
  %1471 = select <8 x i1> %71, <8 x float> %1312, <8 x float> %private.contiguous.preserve710
  store <8 x float> %1471, ptr %private.contiguous.address709, align 4
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1473 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1474 = add <8 x i64> %1473, splat (i64 320)
  %1475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1472, 0
  %1476 = insertvalue { <8 x ptr>, <8 x i64> } %1475, <8 x i64> %1474, 1
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1478 = extractvalue { <8 x ptr>, <8 x i64> } %1476, 1
  %1479 = extractelement <8 x ptr> %1477, i32 0
  %1480 = extractelement <8 x i64> %1478, i32 0
  %1481 = sub i64 %1480, 0
  %1482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1483 = select i1 %1482, i64 %1481, i64 0
  %private.contiguous.address711 = getelementptr i8, ptr %1479, i64 %1483
  %private.contiguous.preserve712 = load <8 x float>, ptr %private.contiguous.address711, align 4
  %1484 = select <8 x i1> %71, <8 x float> %1315, <8 x float> %private.contiguous.preserve712
  store <8 x float> %1484, ptr %private.contiguous.address711, align 4
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1487 = add <8 x i64> %1486, splat (i64 352)
  %1488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1485, 0
  %1489 = insertvalue { <8 x ptr>, <8 x i64> } %1488, <8 x i64> %1487, 1
  %1490 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1491 = extractvalue { <8 x ptr>, <8 x i64> } %1489, 1
  %1492 = extractelement <8 x ptr> %1490, i32 0
  %1493 = extractelement <8 x i64> %1491, i32 0
  %1494 = sub i64 %1493, 0
  %1495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1496 = select i1 %1495, i64 %1494, i64 0
  %private.contiguous.address713 = getelementptr i8, ptr %1492, i64 %1496
  %private.contiguous.preserve714 = load <8 x float>, ptr %private.contiguous.address713, align 4
  %1497 = select <8 x i1> %71, <8 x float> %1318, <8 x float> %private.contiguous.preserve714
  store <8 x float> %1497, ptr %private.contiguous.address713, align 4
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1499 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1500 = add <8 x i64> %1499, splat (i64 384)
  %1501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1498, 0
  %1502 = insertvalue { <8 x ptr>, <8 x i64> } %1501, <8 x i64> %1500, 1
  %1503 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1504 = extractvalue { <8 x ptr>, <8 x i64> } %1502, 1
  %1505 = extractelement <8 x ptr> %1503, i32 0
  %1506 = extractelement <8 x i64> %1504, i32 0
  %1507 = sub i64 %1506, 0
  %1508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1509 = select i1 %1508, i64 %1507, i64 0
  %private.contiguous.address715 = getelementptr i8, ptr %1505, i64 %1509
  %private.contiguous.preserve716 = load <8 x float>, ptr %private.contiguous.address715, align 4
  %1510 = select <8 x i1> %71, <8 x float> %1321, <8 x float> %private.contiguous.preserve716
  store <8 x float> %1510, ptr %private.contiguous.address715, align 4
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1512 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1513 = add <8 x i64> %1512, splat (i64 416)
  %1514 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1511, 0
  %1515 = insertvalue { <8 x ptr>, <8 x i64> } %1514, <8 x i64> %1513, 1
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %1515, 1
  %1518 = extractelement <8 x ptr> %1516, i32 0
  %1519 = extractelement <8 x i64> %1517, i32 0
  %1520 = sub i64 %1519, 0
  %1521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1522 = select i1 %1521, i64 %1520, i64 0
  %private.contiguous.address717 = getelementptr i8, ptr %1518, i64 %1522
  %private.contiguous.preserve718 = load <8 x float>, ptr %private.contiguous.address717, align 4
  %1523 = select <8 x i1> %71, <8 x float> %1324, <8 x float> %private.contiguous.preserve718
  store <8 x float> %1523, ptr %private.contiguous.address717, align 4
  %1524 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1525 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1526 = add <8 x i64> %1525, splat (i64 448)
  %1527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1524, 0
  %1528 = insertvalue { <8 x ptr>, <8 x i64> } %1527, <8 x i64> %1526, 1
  %1529 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %1528, 1
  %1531 = extractelement <8 x ptr> %1529, i32 0
  %1532 = extractelement <8 x i64> %1530, i32 0
  %1533 = sub i64 %1532, 0
  %1534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1535 = select i1 %1534, i64 %1533, i64 0
  %private.contiguous.address719 = getelementptr i8, ptr %1531, i64 %1535
  %private.contiguous.preserve720 = load <8 x float>, ptr %private.contiguous.address719, align 4
  %1536 = select <8 x i1> %71, <8 x float> %1327, <8 x float> %private.contiguous.preserve720
  store <8 x float> %1536, ptr %private.contiguous.address719, align 4
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1539 = add <8 x i64> %1538, splat (i64 480)
  %1540 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1537, 0
  %1541 = insertvalue { <8 x ptr>, <8 x i64> } %1540, <8 x i64> %1539, 1
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1543 = extractvalue { <8 x ptr>, <8 x i64> } %1541, 1
  %1544 = extractelement <8 x ptr> %1542, i32 0
  %1545 = extractelement <8 x i64> %1543, i32 0
  %1546 = sub i64 %1545, 0
  %1547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1548 = select i1 %1547, i64 %1546, i64 0
  %private.contiguous.address721 = getelementptr i8, ptr %1544, i64 %1548
  %private.contiguous.preserve722 = load <8 x float>, ptr %private.contiguous.address721, align 4
  %1549 = select <8 x i1> %71, <8 x float> %1330, <8 x float> %private.contiguous.preserve722
  store <8 x float> %1549, ptr %private.contiguous.address721, align 4
  %.state723 = load <8 x float>, ptr %.slot36, align 32
  %1550 = fmul <8 x float> %.state723, %native.exp
  %1551 = load <8 x float>, ptr %.spill133, align 32
  %1552 = select <8 x i1> %71, <8 x float> %1550, <8 x float> %1551
  store <8 x float> %1552, ptr %.spill133, align 32
  store i64 0, ptr %.slot134, align 4
  %1553 = load <8 x float>, ptr %.slot135, align 32
  %1554 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1553
  store <8 x float> %1554, ptr %.slot135, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state724 = load i64, ptr %.slot134, align 4
  %1555 = icmp slt i64 %.state724, 16
  br i1 %1555, label %direct.true725, label %direct.false726

direct.schedule.71:                               ; preds = %direct.true725
  %.state727 = load i64, ptr %.slot134, align 4
  %1556 = sdiv i64 %.state727, 1
  %.spill.load728 = load i64, ptr %.spill78, align 4
  %1557 = mul i64 %.spill.load728, 1
  %1558 = add i64 %1557, 0
  %1559 = mul i64 %1558, 1
  %1560 = add i64 %1559, 0
  %1561 = mul i64 %1560, 16
  %1562 = add i64 %1561, %1556
  %tile_snapshot.spill.load729 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load729, 0
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load729, 1
  %.splatinsert730 = insertelement <8 x i64> poison, i64 %1562, i64 0
  %.splat731 = shufflevector <8 x i64> %.splatinsert730, <8 x i64> poison, <8 x i32> zeroinitializer
  %1565 = mul <8 x i64> %.splat731, splat (i64 32)
  %1566 = add <8 x i64> %1564, %1565
  %1567 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1563, 0
  %1568 = insertvalue { <8 x ptr>, <8 x i64> } %1567, <8 x i64> %1566, 1
  %1569 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1570 = extractvalue { <8 x ptr>, <8 x i64> } %1568, 1
  %1571 = extractelement <8 x ptr> %1569, i32 0
  %1572 = extractelement <8 x i64> %1570, i32 0
  %1573 = sub i64 %1572, 0
  %1574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1575 = select i1 %1574, i64 %1573, i64 0
  %private.contiguous.address732 = getelementptr i8, ptr %1571, i64 %1575
  %private.contiguous.load733 = load <8 x float>, ptr %private.contiguous.address732, align 4
  %1576 = select <8 x i1> %71, <8 x float> %private.contiguous.load733, <8 x float> zeroinitializer
  %.state734 = load <8 x float>, ptr %.slot135, align 32
  %1577 = fadd <8 x float> %.state734, %1576
  %.state735 = load i64, ptr %.slot134, align 4
  %1578 = add i64 %.state735, 1
  store i64 %1578, ptr %.slot134, align 4
  %1579 = load <8 x float>, ptr %.slot135, align 32
  %1580 = select <8 x i1> %71, <8 x float> %1577, <8 x float> %1579
  store <8 x float> %1580, ptr %.slot135, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false726
  %.spill.load736 = load <8 x float>, ptr %.spill133, align 32
  %.state737 = load <8 x float>, ptr %.slot135, align 32
  %1581 = fadd <8 x float> %.spill.load736, %.state737
  %1582 = load <8 x float>, ptr %.spill136, align 32
  %1583 = select <8 x i1> %71, <8 x float> %1581, <8 x float> %1582
  store <8 x float> %1583, ptr %.spill136, align 32
  %1584 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill137, align 64
  %1585 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1586 = extractvalue { <8 x ptr>, <8 x i64> } %1584, 0
  %1587 = select <8 x i1> %71, <8 x ptr> %1585, <8 x ptr> %1586
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %1584, 1
  %1590 = select <8 x i1> %71, <8 x i64> %1588, <8 x i64> %1589
  %1591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1587, 0
  %1592 = insertvalue { <8 x ptr>, <8 x i64> } %1591, <8 x i64> %1590, 1
  store { <8 x ptr>, <8 x i64> } %1592, ptr %tile_snapshot.spill137, align 64
  store i64 0, ptr %.slot138, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.74, %direct.schedule.72
  %.state738 = load i64, ptr %.slot138, align 4
  %1593 = icmp slt i64 %.state738, 24
  br i1 %1593, label %direct.true739, label %direct.false740

direct.schedule.74:                               ; preds = %direct.true739
  %.state741 = load i64, ptr %.slot138, align 4
  %1594 = mul i64 %.state741, 4
  %1595 = add i64 0, %1594
  %1596 = add i64 %1595, 0
  %1597 = add i64 0, %1596
  %tile_snapshot.spill.load742 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load742, 0
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load742, 1
  %.splatinsert743 = insertelement <8 x i64> poison, i64 %1597, i64 0
  %.splat744 = shufflevector <8 x i64> %.splatinsert743, <8 x i64> poison, <8 x i32> zeroinitializer
  %1600 = mul <8 x i64> %.splat744, splat (i64 32)
  %1601 = add <8 x i64> %1599, %1600
  %1602 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1598, 0
  %1603 = insertvalue { <8 x ptr>, <8 x i64> } %1602, <8 x i64> %1601, 1
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %1603, 1
  %1606 = extractelement <8 x ptr> %1604, i32 0
  %1607 = extractelement <8 x i64> %1605, i32 0
  %1608 = sub i64 %1607, 0
  %1609 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1610 = select i1 %1609, i64 %1608, i64 0
  %private.contiguous.address745 = getelementptr i8, ptr %1606, i64 %1610
  %private.contiguous.load746 = load <8 x float>, ptr %private.contiguous.address745, align 4
  %1611 = select <8 x i1> %71, <8 x float> %private.contiguous.load746, <8 x float> zeroinitializer
  %.spill.load747 = load <8 x float>, ptr %.spill115, align 32
  %1612 = fmul <8 x float> %1611, %.spill.load747
  %1613 = add i64 %1595, 1
  %1614 = add i64 0, %1613
  %tile_snapshot.spill.load748 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load748, 0
  %1616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load748, 1
  %.splatinsert749 = insertelement <8 x i64> poison, i64 %1614, i64 0
  %.splat750 = shufflevector <8 x i64> %.splatinsert749, <8 x i64> poison, <8 x i32> zeroinitializer
  %1617 = mul <8 x i64> %.splat750, splat (i64 32)
  %1618 = add <8 x i64> %1616, %1617
  %1619 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1615, 0
  %1620 = insertvalue { <8 x ptr>, <8 x i64> } %1619, <8 x i64> %1618, 1
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1622 = extractvalue { <8 x ptr>, <8 x i64> } %1620, 1
  %1623 = extractelement <8 x ptr> %1621, i32 0
  %1624 = extractelement <8 x i64> %1622, i32 0
  %1625 = sub i64 %1624, 0
  %1626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1627 = select i1 %1626, i64 %1625, i64 0
  %private.contiguous.address751 = getelementptr i8, ptr %1623, i64 %1627
  %private.contiguous.load752 = load <8 x float>, ptr %private.contiguous.address751, align 4
  %1628 = select <8 x i1> %71, <8 x float> %private.contiguous.load752, <8 x float> zeroinitializer
  %.spill.load753 = load <8 x float>, ptr %.spill115, align 32
  %1629 = fmul <8 x float> %1628, %.spill.load753
  %1630 = add i64 %1595, 2
  %1631 = add i64 0, %1630
  %tile_snapshot.spill.load754 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load754, 0
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load754, 1
  %.splatinsert755 = insertelement <8 x i64> poison, i64 %1631, i64 0
  %.splat756 = shufflevector <8 x i64> %.splatinsert755, <8 x i64> poison, <8 x i32> zeroinitializer
  %1634 = mul <8 x i64> %.splat756, splat (i64 32)
  %1635 = add <8 x i64> %1633, %1634
  %1636 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1632, 0
  %1637 = insertvalue { <8 x ptr>, <8 x i64> } %1636, <8 x i64> %1635, 1
  %1638 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1639 = extractvalue { <8 x ptr>, <8 x i64> } %1637, 1
  %1640 = extractelement <8 x ptr> %1638, i32 0
  %1641 = extractelement <8 x i64> %1639, i32 0
  %1642 = sub i64 %1641, 0
  %1643 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1644 = select i1 %1643, i64 %1642, i64 0
  %private.contiguous.address757 = getelementptr i8, ptr %1640, i64 %1644
  %private.contiguous.load758 = load <8 x float>, ptr %private.contiguous.address757, align 4
  %1645 = select <8 x i1> %71, <8 x float> %private.contiguous.load758, <8 x float> zeroinitializer
  %.spill.load759 = load <8 x float>, ptr %.spill115, align 32
  %1646 = fmul <8 x float> %1645, %.spill.load759
  %1647 = add i64 %1595, 3
  %1648 = add i64 0, %1647
  %tile_snapshot.spill.load760 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1649 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load760, 0
  %1650 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load760, 1
  %.splatinsert761 = insertelement <8 x i64> poison, i64 %1648, i64 0
  %.splat762 = shufflevector <8 x i64> %.splatinsert761, <8 x i64> poison, <8 x i32> zeroinitializer
  %1651 = mul <8 x i64> %.splat762, splat (i64 32)
  %1652 = add <8 x i64> %1650, %1651
  %1653 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1649, 0
  %1654 = insertvalue { <8 x ptr>, <8 x i64> } %1653, <8 x i64> %1652, 1
  %1655 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1656 = extractvalue { <8 x ptr>, <8 x i64> } %1654, 1
  %1657 = extractelement <8 x ptr> %1655, i32 0
  %1658 = extractelement <8 x i64> %1656, i32 0
  %1659 = sub i64 %1658, 0
  %1660 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1661 = select i1 %1660, i64 %1659, i64 0
  %private.contiguous.address763 = getelementptr i8, ptr %1657, i64 %1661
  %private.contiguous.load764 = load <8 x float>, ptr %private.contiguous.address763, align 4
  %1662 = select <8 x i1> %71, <8 x float> %private.contiguous.load764, <8 x float> zeroinitializer
  %.spill.load765 = load <8 x float>, ptr %.spill115, align 32
  %1663 = fmul <8 x float> %1662, %.spill.load765
  %tile_snapshot.spill.load766 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load766, 0
  %1665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load766, 1
  %.splatinsert767 = insertelement <8 x i64> poison, i64 %1597, i64 0
  %.splat768 = shufflevector <8 x i64> %.splatinsert767, <8 x i64> poison, <8 x i32> zeroinitializer
  %1666 = mul <8 x i64> %.splat768, splat (i64 32)
  %1667 = add <8 x i64> %1665, %1666
  %1668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1664, 0
  %1669 = insertvalue { <8 x ptr>, <8 x i64> } %1668, <8 x i64> %1667, 1
  %1670 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1671 = extractvalue { <8 x ptr>, <8 x i64> } %1669, 1
  %1672 = extractelement <8 x ptr> %1670, i32 0
  %1673 = extractelement <8 x i64> %1671, i32 0
  %1674 = sub i64 %1673, 0
  %1675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1676 = select i1 %1675, i64 %1674, i64 0
  %private.contiguous.address769 = getelementptr i8, ptr %1672, i64 %1676
  %private.contiguous.load770 = load <8 x float>, ptr %private.contiguous.address769, align 4
  %1677 = select <8 x i1> %71, <8 x float> %private.contiguous.load770, <8 x float> zeroinitializer
  %.spill.load771 = load <8 x float>, ptr %.spill116, align 32
  %1678 = fmul <8 x float> %.spill.load771, %1677
  %1679 = fadd <8 x float> %1612, %1678
  %tile_snapshot.spill.load772 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1680 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load772, 0
  %1681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load772, 1
  %.splatinsert773 = insertelement <8 x i64> poison, i64 %1614, i64 0
  %.splat774 = shufflevector <8 x i64> %.splatinsert773, <8 x i64> poison, <8 x i32> zeroinitializer
  %1682 = mul <8 x i64> %.splat774, splat (i64 32)
  %1683 = add <8 x i64> %1681, %1682
  %1684 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1680, 0
  %1685 = insertvalue { <8 x ptr>, <8 x i64> } %1684, <8 x i64> %1683, 1
  %1686 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %1685, 1
  %1688 = extractelement <8 x ptr> %1686, i32 0
  %1689 = extractelement <8 x i64> %1687, i32 0
  %1690 = sub i64 %1689, 0
  %1691 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1692 = select i1 %1691, i64 %1690, i64 0
  %private.contiguous.address775 = getelementptr i8, ptr %1688, i64 %1692
  %private.contiguous.load776 = load <8 x float>, ptr %private.contiguous.address775, align 4
  %1693 = select <8 x i1> %71, <8 x float> %private.contiguous.load776, <8 x float> zeroinitializer
  %.spill.load777 = load <8 x float>, ptr %.spill116, align 32
  %1694 = fmul <8 x float> %.spill.load777, %1693
  %1695 = fadd <8 x float> %1629, %1694
  %tile_snapshot.spill.load778 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1696 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 0
  %1697 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 1
  %.splatinsert779 = insertelement <8 x i64> poison, i64 %1631, i64 0
  %.splat780 = shufflevector <8 x i64> %.splatinsert779, <8 x i64> poison, <8 x i32> zeroinitializer
  %1698 = mul <8 x i64> %.splat780, splat (i64 32)
  %1699 = add <8 x i64> %1697, %1698
  %1700 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1696, 0
  %1701 = insertvalue { <8 x ptr>, <8 x i64> } %1700, <8 x i64> %1699, 1
  %1702 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %1701, 1
  %1704 = extractelement <8 x ptr> %1702, i32 0
  %1705 = extractelement <8 x i64> %1703, i32 0
  %1706 = sub i64 %1705, 0
  %1707 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1708 = select i1 %1707, i64 %1706, i64 0
  %private.contiguous.address781 = getelementptr i8, ptr %1704, i64 %1708
  %private.contiguous.load782 = load <8 x float>, ptr %private.contiguous.address781, align 4
  %1709 = select <8 x i1> %71, <8 x float> %private.contiguous.load782, <8 x float> zeroinitializer
  %.spill.load783 = load <8 x float>, ptr %.spill116, align 32
  %1710 = fmul <8 x float> %.spill.load783, %1709
  %1711 = fadd <8 x float> %1646, %1710
  %tile_snapshot.spill.load784 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1712 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 0
  %1713 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 1
  %.splatinsert785 = insertelement <8 x i64> poison, i64 %1648, i64 0
  %.splat786 = shufflevector <8 x i64> %.splatinsert785, <8 x i64> poison, <8 x i32> zeroinitializer
  %1714 = mul <8 x i64> %.splat786, splat (i64 32)
  %1715 = add <8 x i64> %1713, %1714
  %1716 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1712, 0
  %1717 = insertvalue { <8 x ptr>, <8 x i64> } %1716, <8 x i64> %1715, 1
  %1718 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1719 = extractvalue { <8 x ptr>, <8 x i64> } %1717, 1
  %1720 = extractelement <8 x ptr> %1718, i32 0
  %1721 = extractelement <8 x i64> %1719, i32 0
  %1722 = sub i64 %1721, 0
  %1723 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1724 = select i1 %1723, i64 %1722, i64 0
  %private.contiguous.address787 = getelementptr i8, ptr %1720, i64 %1724
  %private.contiguous.load788 = load <8 x float>, ptr %private.contiguous.address787, align 4
  %1725 = select <8 x i1> %71, <8 x float> %private.contiguous.load788, <8 x float> zeroinitializer
  %.spill.load789 = load <8 x float>, ptr %.spill116, align 32
  %1726 = fmul <8 x float> %.spill.load789, %1725
  %1727 = fadd <8 x float> %1663, %1726
  %1728 = add i64 96, %1596
  %tile_snapshot.spill.load790 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 0
  %1730 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 1
  %.splatinsert791 = insertelement <8 x i64> poison, i64 %1728, i64 0
  %.splat792 = shufflevector <8 x i64> %.splatinsert791, <8 x i64> poison, <8 x i32> zeroinitializer
  %1731 = mul <8 x i64> %.splat792, splat (i64 32)
  %1732 = add <8 x i64> %1730, %1731
  %1733 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1729, 0
  %1734 = insertvalue { <8 x ptr>, <8 x i64> } %1733, <8 x i64> %1732, 1
  %1735 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1736 = extractvalue { <8 x ptr>, <8 x i64> } %1734, 1
  %1737 = extractelement <8 x ptr> %1735, i32 0
  %1738 = extractelement <8 x i64> %1736, i32 0
  %1739 = sub i64 %1738, 0
  %1740 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1741 = select i1 %1740, i64 %1739, i64 0
  %private.contiguous.address793 = getelementptr i8, ptr %1737, i64 %1741
  %private.contiguous.load794 = load <8 x float>, ptr %private.contiguous.address793, align 4
  %1742 = select <8 x i1> %71, <8 x float> %private.contiguous.load794, <8 x float> zeroinitializer
  %.spill.load795 = load <8 x float>, ptr %.spill117, align 32
  %1743 = fmul <8 x float> %.spill.load795, %1742
  %1744 = fadd <8 x float> %1679, %1743
  %1745 = add i64 96, %1613
  %tile_snapshot.spill.load796 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1746 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load796, 0
  %1747 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load796, 1
  %.splatinsert797 = insertelement <8 x i64> poison, i64 %1745, i64 0
  %.splat798 = shufflevector <8 x i64> %.splatinsert797, <8 x i64> poison, <8 x i32> zeroinitializer
  %1748 = mul <8 x i64> %.splat798, splat (i64 32)
  %1749 = add <8 x i64> %1747, %1748
  %1750 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1746, 0
  %1751 = insertvalue { <8 x ptr>, <8 x i64> } %1750, <8 x i64> %1749, 1
  %1752 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1753 = extractvalue { <8 x ptr>, <8 x i64> } %1751, 1
  %1754 = extractelement <8 x ptr> %1752, i32 0
  %1755 = extractelement <8 x i64> %1753, i32 0
  %1756 = sub i64 %1755, 0
  %1757 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1758 = select i1 %1757, i64 %1756, i64 0
  %private.contiguous.address799 = getelementptr i8, ptr %1754, i64 %1758
  %private.contiguous.load800 = load <8 x float>, ptr %private.contiguous.address799, align 4
  %1759 = select <8 x i1> %71, <8 x float> %private.contiguous.load800, <8 x float> zeroinitializer
  %.spill.load801 = load <8 x float>, ptr %.spill117, align 32
  %1760 = fmul <8 x float> %.spill.load801, %1759
  %1761 = fadd <8 x float> %1695, %1760
  %1762 = add i64 96, %1630
  %tile_snapshot.spill.load802 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load802, 0
  %1764 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load802, 1
  %.splatinsert803 = insertelement <8 x i64> poison, i64 %1762, i64 0
  %.splat804 = shufflevector <8 x i64> %.splatinsert803, <8 x i64> poison, <8 x i32> zeroinitializer
  %1765 = mul <8 x i64> %.splat804, splat (i64 32)
  %1766 = add <8 x i64> %1764, %1765
  %1767 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1763, 0
  %1768 = insertvalue { <8 x ptr>, <8 x i64> } %1767, <8 x i64> %1766, 1
  %1769 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1770 = extractvalue { <8 x ptr>, <8 x i64> } %1768, 1
  %1771 = extractelement <8 x ptr> %1769, i32 0
  %1772 = extractelement <8 x i64> %1770, i32 0
  %1773 = sub i64 %1772, 0
  %1774 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1775 = select i1 %1774, i64 %1773, i64 0
  %private.contiguous.address805 = getelementptr i8, ptr %1771, i64 %1775
  %private.contiguous.load806 = load <8 x float>, ptr %private.contiguous.address805, align 4
  %1776 = select <8 x i1> %71, <8 x float> %private.contiguous.load806, <8 x float> zeroinitializer
  %.spill.load807 = load <8 x float>, ptr %.spill117, align 32
  %1777 = fmul <8 x float> %.spill.load807, %1776
  %1778 = fadd <8 x float> %1711, %1777
  %1779 = add i64 96, %1647
  %tile_snapshot.spill.load808 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1780 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load808, 0
  %1781 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load808, 1
  %.splatinsert809 = insertelement <8 x i64> poison, i64 %1779, i64 0
  %.splat810 = shufflevector <8 x i64> %.splatinsert809, <8 x i64> poison, <8 x i32> zeroinitializer
  %1782 = mul <8 x i64> %.splat810, splat (i64 32)
  %1783 = add <8 x i64> %1781, %1782
  %1784 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1780, 0
  %1785 = insertvalue { <8 x ptr>, <8 x i64> } %1784, <8 x i64> %1783, 1
  %1786 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1787 = extractvalue { <8 x ptr>, <8 x i64> } %1785, 1
  %1788 = extractelement <8 x ptr> %1786, i32 0
  %1789 = extractelement <8 x i64> %1787, i32 0
  %1790 = sub i64 %1789, 0
  %1791 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1792 = select i1 %1791, i64 %1790, i64 0
  %private.contiguous.address811 = getelementptr i8, ptr %1788, i64 %1792
  %private.contiguous.load812 = load <8 x float>, ptr %private.contiguous.address811, align 4
  %1793 = select <8 x i1> %71, <8 x float> %private.contiguous.load812, <8 x float> zeroinitializer
  %.spill.load813 = load <8 x float>, ptr %.spill117, align 32
  %1794 = fmul <8 x float> %.spill.load813, %1793
  %1795 = fadd <8 x float> %1727, %1794
  %1796 = add i64 192, %1596
  %tile_snapshot.spill.load814 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load814, 0
  %1798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load814, 1
  %.splatinsert815 = insertelement <8 x i64> poison, i64 %1796, i64 0
  %.splat816 = shufflevector <8 x i64> %.splatinsert815, <8 x i64> poison, <8 x i32> zeroinitializer
  %1799 = mul <8 x i64> %.splat816, splat (i64 32)
  %1800 = add <8 x i64> %1798, %1799
  %1801 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1797, 0
  %1802 = insertvalue { <8 x ptr>, <8 x i64> } %1801, <8 x i64> %1800, 1
  %1803 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1804 = extractvalue { <8 x ptr>, <8 x i64> } %1802, 1
  %1805 = extractelement <8 x ptr> %1803, i32 0
  %1806 = extractelement <8 x i64> %1804, i32 0
  %1807 = sub i64 %1806, 0
  %1808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1809 = select i1 %1808, i64 %1807, i64 0
  %private.contiguous.address817 = getelementptr i8, ptr %1805, i64 %1809
  %private.contiguous.load818 = load <8 x float>, ptr %private.contiguous.address817, align 4
  %1810 = select <8 x i1> %71, <8 x float> %private.contiguous.load818, <8 x float> zeroinitializer
  %.spill.load819 = load <8 x float>, ptr %.spill118, align 32
  %1811 = fmul <8 x float> %.spill.load819, %1810
  %1812 = fadd <8 x float> %1744, %1811
  %1813 = add i64 192, %1613
  %tile_snapshot.spill.load820 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load820, 0
  %1815 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load820, 1
  %.splatinsert821 = insertelement <8 x i64> poison, i64 %1813, i64 0
  %.splat822 = shufflevector <8 x i64> %.splatinsert821, <8 x i64> poison, <8 x i32> zeroinitializer
  %1816 = mul <8 x i64> %.splat822, splat (i64 32)
  %1817 = add <8 x i64> %1815, %1816
  %1818 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1814, 0
  %1819 = insertvalue { <8 x ptr>, <8 x i64> } %1818, <8 x i64> %1817, 1
  %1820 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1821 = extractvalue { <8 x ptr>, <8 x i64> } %1819, 1
  %1822 = extractelement <8 x ptr> %1820, i32 0
  %1823 = extractelement <8 x i64> %1821, i32 0
  %1824 = sub i64 %1823, 0
  %1825 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1826 = select i1 %1825, i64 %1824, i64 0
  %private.contiguous.address823 = getelementptr i8, ptr %1822, i64 %1826
  %private.contiguous.load824 = load <8 x float>, ptr %private.contiguous.address823, align 4
  %1827 = select <8 x i1> %71, <8 x float> %private.contiguous.load824, <8 x float> zeroinitializer
  %.spill.load825 = load <8 x float>, ptr %.spill118, align 32
  %1828 = fmul <8 x float> %.spill.load825, %1827
  %1829 = fadd <8 x float> %1761, %1828
  %1830 = add i64 192, %1630
  %tile_snapshot.spill.load826 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1831 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load826, 0
  %1832 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load826, 1
  %.splatinsert827 = insertelement <8 x i64> poison, i64 %1830, i64 0
  %.splat828 = shufflevector <8 x i64> %.splatinsert827, <8 x i64> poison, <8 x i32> zeroinitializer
  %1833 = mul <8 x i64> %.splat828, splat (i64 32)
  %1834 = add <8 x i64> %1832, %1833
  %1835 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1831, 0
  %1836 = insertvalue { <8 x ptr>, <8 x i64> } %1835, <8 x i64> %1834, 1
  %1837 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1838 = extractvalue { <8 x ptr>, <8 x i64> } %1836, 1
  %1839 = extractelement <8 x ptr> %1837, i32 0
  %1840 = extractelement <8 x i64> %1838, i32 0
  %1841 = sub i64 %1840, 0
  %1842 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1843 = select i1 %1842, i64 %1841, i64 0
  %private.contiguous.address829 = getelementptr i8, ptr %1839, i64 %1843
  %private.contiguous.load830 = load <8 x float>, ptr %private.contiguous.address829, align 4
  %1844 = select <8 x i1> %71, <8 x float> %private.contiguous.load830, <8 x float> zeroinitializer
  %.spill.load831 = load <8 x float>, ptr %.spill118, align 32
  %1845 = fmul <8 x float> %.spill.load831, %1844
  %1846 = fadd <8 x float> %1778, %1845
  %1847 = add i64 192, %1647
  %tile_snapshot.spill.load832 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1848 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load832, 0
  %1849 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load832, 1
  %.splatinsert833 = insertelement <8 x i64> poison, i64 %1847, i64 0
  %.splat834 = shufflevector <8 x i64> %.splatinsert833, <8 x i64> poison, <8 x i32> zeroinitializer
  %1850 = mul <8 x i64> %.splat834, splat (i64 32)
  %1851 = add <8 x i64> %1849, %1850
  %1852 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1848, 0
  %1853 = insertvalue { <8 x ptr>, <8 x i64> } %1852, <8 x i64> %1851, 1
  %1854 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1855 = extractvalue { <8 x ptr>, <8 x i64> } %1853, 1
  %1856 = extractelement <8 x ptr> %1854, i32 0
  %1857 = extractelement <8 x i64> %1855, i32 0
  %1858 = sub i64 %1857, 0
  %1859 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1860 = select i1 %1859, i64 %1858, i64 0
  %private.contiguous.address835 = getelementptr i8, ptr %1856, i64 %1860
  %private.contiguous.load836 = load <8 x float>, ptr %private.contiguous.address835, align 4
  %1861 = select <8 x i1> %71, <8 x float> %private.contiguous.load836, <8 x float> zeroinitializer
  %.spill.load837 = load <8 x float>, ptr %.spill118, align 32
  %1862 = fmul <8 x float> %.spill.load837, %1861
  %1863 = fadd <8 x float> %1795, %1862
  %1864 = add i64 288, %1596
  %tile_snapshot.spill.load838 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load838, 0
  %1866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load838, 1
  %.splatinsert839 = insertelement <8 x i64> poison, i64 %1864, i64 0
  %.splat840 = shufflevector <8 x i64> %.splatinsert839, <8 x i64> poison, <8 x i32> zeroinitializer
  %1867 = mul <8 x i64> %.splat840, splat (i64 32)
  %1868 = add <8 x i64> %1866, %1867
  %1869 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1865, 0
  %1870 = insertvalue { <8 x ptr>, <8 x i64> } %1869, <8 x i64> %1868, 1
  %1871 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1872 = extractvalue { <8 x ptr>, <8 x i64> } %1870, 1
  %1873 = extractelement <8 x ptr> %1871, i32 0
  %1874 = extractelement <8 x i64> %1872, i32 0
  %1875 = sub i64 %1874, 0
  %1876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1877 = select i1 %1876, i64 %1875, i64 0
  %private.contiguous.address841 = getelementptr i8, ptr %1873, i64 %1877
  %private.contiguous.load842 = load <8 x float>, ptr %private.contiguous.address841, align 4
  %1878 = select <8 x i1> %71, <8 x float> %private.contiguous.load842, <8 x float> zeroinitializer
  %.spill.load843 = load <8 x float>, ptr %.spill119, align 32
  %1879 = fmul <8 x float> %.spill.load843, %1878
  %1880 = fadd <8 x float> %1812, %1879
  %1881 = add i64 288, %1613
  %tile_snapshot.spill.load844 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1882 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load844, 0
  %1883 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load844, 1
  %.splatinsert845 = insertelement <8 x i64> poison, i64 %1881, i64 0
  %.splat846 = shufflevector <8 x i64> %.splatinsert845, <8 x i64> poison, <8 x i32> zeroinitializer
  %1884 = mul <8 x i64> %.splat846, splat (i64 32)
  %1885 = add <8 x i64> %1883, %1884
  %1886 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1882, 0
  %1887 = insertvalue { <8 x ptr>, <8 x i64> } %1886, <8 x i64> %1885, 1
  %1888 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1889 = extractvalue { <8 x ptr>, <8 x i64> } %1887, 1
  %1890 = extractelement <8 x ptr> %1888, i32 0
  %1891 = extractelement <8 x i64> %1889, i32 0
  %1892 = sub i64 %1891, 0
  %1893 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1894 = select i1 %1893, i64 %1892, i64 0
  %private.contiguous.address847 = getelementptr i8, ptr %1890, i64 %1894
  %private.contiguous.load848 = load <8 x float>, ptr %private.contiguous.address847, align 4
  %1895 = select <8 x i1> %71, <8 x float> %private.contiguous.load848, <8 x float> zeroinitializer
  %.spill.load849 = load <8 x float>, ptr %.spill119, align 32
  %1896 = fmul <8 x float> %.spill.load849, %1895
  %1897 = fadd <8 x float> %1829, %1896
  %1898 = add i64 288, %1630
  %tile_snapshot.spill.load850 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1899 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load850, 0
  %1900 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load850, 1
  %.splatinsert851 = insertelement <8 x i64> poison, i64 %1898, i64 0
  %.splat852 = shufflevector <8 x i64> %.splatinsert851, <8 x i64> poison, <8 x i32> zeroinitializer
  %1901 = mul <8 x i64> %.splat852, splat (i64 32)
  %1902 = add <8 x i64> %1900, %1901
  %1903 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1899, 0
  %1904 = insertvalue { <8 x ptr>, <8 x i64> } %1903, <8 x i64> %1902, 1
  %1905 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1906 = extractvalue { <8 x ptr>, <8 x i64> } %1904, 1
  %1907 = extractelement <8 x ptr> %1905, i32 0
  %1908 = extractelement <8 x i64> %1906, i32 0
  %1909 = sub i64 %1908, 0
  %1910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1911 = select i1 %1910, i64 %1909, i64 0
  %private.contiguous.address853 = getelementptr i8, ptr %1907, i64 %1911
  %private.contiguous.load854 = load <8 x float>, ptr %private.contiguous.address853, align 4
  %1912 = select <8 x i1> %71, <8 x float> %private.contiguous.load854, <8 x float> zeroinitializer
  %.spill.load855 = load <8 x float>, ptr %.spill119, align 32
  %1913 = fmul <8 x float> %.spill.load855, %1912
  %1914 = fadd <8 x float> %1846, %1913
  %1915 = add i64 288, %1647
  %tile_snapshot.spill.load856 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1916 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load856, 0
  %1917 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load856, 1
  %.splatinsert857 = insertelement <8 x i64> poison, i64 %1915, i64 0
  %.splat858 = shufflevector <8 x i64> %.splatinsert857, <8 x i64> poison, <8 x i32> zeroinitializer
  %1918 = mul <8 x i64> %.splat858, splat (i64 32)
  %1919 = add <8 x i64> %1917, %1918
  %1920 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1916, 0
  %1921 = insertvalue { <8 x ptr>, <8 x i64> } %1920, <8 x i64> %1919, 1
  %1922 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1923 = extractvalue { <8 x ptr>, <8 x i64> } %1921, 1
  %1924 = extractelement <8 x ptr> %1922, i32 0
  %1925 = extractelement <8 x i64> %1923, i32 0
  %1926 = sub i64 %1925, 0
  %1927 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1928 = select i1 %1927, i64 %1926, i64 0
  %private.contiguous.address859 = getelementptr i8, ptr %1924, i64 %1928
  %private.contiguous.load860 = load <8 x float>, ptr %private.contiguous.address859, align 4
  %1929 = select <8 x i1> %71, <8 x float> %private.contiguous.load860, <8 x float> zeroinitializer
  %.spill.load861 = load <8 x float>, ptr %.spill119, align 32
  %1930 = fmul <8 x float> %.spill.load861, %1929
  %1931 = fadd <8 x float> %1863, %1930
  %1932 = add i64 384, %1596
  %tile_snapshot.spill.load862 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1933 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load862, 0
  %1934 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load862, 1
  %.splatinsert863 = insertelement <8 x i64> poison, i64 %1932, i64 0
  %.splat864 = shufflevector <8 x i64> %.splatinsert863, <8 x i64> poison, <8 x i32> zeroinitializer
  %1935 = mul <8 x i64> %.splat864, splat (i64 32)
  %1936 = add <8 x i64> %1934, %1935
  %1937 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1933, 0
  %1938 = insertvalue { <8 x ptr>, <8 x i64> } %1937, <8 x i64> %1936, 1
  %1939 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1940 = extractvalue { <8 x ptr>, <8 x i64> } %1938, 1
  %1941 = extractelement <8 x ptr> %1939, i32 0
  %1942 = extractelement <8 x i64> %1940, i32 0
  %1943 = sub i64 %1942, 0
  %1944 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1945 = select i1 %1944, i64 %1943, i64 0
  %private.contiguous.address865 = getelementptr i8, ptr %1941, i64 %1945
  %private.contiguous.load866 = load <8 x float>, ptr %private.contiguous.address865, align 4
  %1946 = select <8 x i1> %71, <8 x float> %private.contiguous.load866, <8 x float> zeroinitializer
  %.spill.load867 = load <8 x float>, ptr %.spill120, align 32
  %1947 = fmul <8 x float> %.spill.load867, %1946
  %1948 = fadd <8 x float> %1880, %1947
  %1949 = add i64 384, %1613
  %tile_snapshot.spill.load868 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1950 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 0
  %1951 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 1
  %.splatinsert869 = insertelement <8 x i64> poison, i64 %1949, i64 0
  %.splat870 = shufflevector <8 x i64> %.splatinsert869, <8 x i64> poison, <8 x i32> zeroinitializer
  %1952 = mul <8 x i64> %.splat870, splat (i64 32)
  %1953 = add <8 x i64> %1951, %1952
  %1954 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1950, 0
  %1955 = insertvalue { <8 x ptr>, <8 x i64> } %1954, <8 x i64> %1953, 1
  %1956 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1957 = extractvalue { <8 x ptr>, <8 x i64> } %1955, 1
  %1958 = extractelement <8 x ptr> %1956, i32 0
  %1959 = extractelement <8 x i64> %1957, i32 0
  %1960 = sub i64 %1959, 0
  %1961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1962 = select i1 %1961, i64 %1960, i64 0
  %private.contiguous.address871 = getelementptr i8, ptr %1958, i64 %1962
  %private.contiguous.load872 = load <8 x float>, ptr %private.contiguous.address871, align 4
  %1963 = select <8 x i1> %71, <8 x float> %private.contiguous.load872, <8 x float> zeroinitializer
  %.spill.load873 = load <8 x float>, ptr %.spill120, align 32
  %1964 = fmul <8 x float> %.spill.load873, %1963
  %1965 = fadd <8 x float> %1897, %1964
  %1966 = add i64 384, %1630
  %tile_snapshot.spill.load874 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1967 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load874, 0
  %1968 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load874, 1
  %.splatinsert875 = insertelement <8 x i64> poison, i64 %1966, i64 0
  %.splat876 = shufflevector <8 x i64> %.splatinsert875, <8 x i64> poison, <8 x i32> zeroinitializer
  %1969 = mul <8 x i64> %.splat876, splat (i64 32)
  %1970 = add <8 x i64> %1968, %1969
  %1971 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1967, 0
  %1972 = insertvalue { <8 x ptr>, <8 x i64> } %1971, <8 x i64> %1970, 1
  %1973 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1974 = extractvalue { <8 x ptr>, <8 x i64> } %1972, 1
  %1975 = extractelement <8 x ptr> %1973, i32 0
  %1976 = extractelement <8 x i64> %1974, i32 0
  %1977 = sub i64 %1976, 0
  %1978 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1979 = select i1 %1978, i64 %1977, i64 0
  %private.contiguous.address877 = getelementptr i8, ptr %1975, i64 %1979
  %private.contiguous.load878 = load <8 x float>, ptr %private.contiguous.address877, align 4
  %1980 = select <8 x i1> %71, <8 x float> %private.contiguous.load878, <8 x float> zeroinitializer
  %.spill.load879 = load <8 x float>, ptr %.spill120, align 32
  %1981 = fmul <8 x float> %.spill.load879, %1980
  %1982 = fadd <8 x float> %1914, %1981
  %1983 = add i64 384, %1647
  %tile_snapshot.spill.load880 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1984 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load880, 0
  %1985 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load880, 1
  %.splatinsert881 = insertelement <8 x i64> poison, i64 %1983, i64 0
  %.splat882 = shufflevector <8 x i64> %.splatinsert881, <8 x i64> poison, <8 x i32> zeroinitializer
  %1986 = mul <8 x i64> %.splat882, splat (i64 32)
  %1987 = add <8 x i64> %1985, %1986
  %1988 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1984, 0
  %1989 = insertvalue { <8 x ptr>, <8 x i64> } %1988, <8 x i64> %1987, 1
  %1990 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1991 = extractvalue { <8 x ptr>, <8 x i64> } %1989, 1
  %1992 = extractelement <8 x ptr> %1990, i32 0
  %1993 = extractelement <8 x i64> %1991, i32 0
  %1994 = sub i64 %1993, 0
  %1995 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1996 = select i1 %1995, i64 %1994, i64 0
  %private.contiguous.address883 = getelementptr i8, ptr %1992, i64 %1996
  %private.contiguous.load884 = load <8 x float>, ptr %private.contiguous.address883, align 4
  %1997 = select <8 x i1> %71, <8 x float> %private.contiguous.load884, <8 x float> zeroinitializer
  %.spill.load885 = load <8 x float>, ptr %.spill120, align 32
  %1998 = fmul <8 x float> %.spill.load885, %1997
  %1999 = fadd <8 x float> %1931, %1998
  %2000 = add i64 480, %1596
  %tile_snapshot.spill.load886 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2001 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load886, 0
  %2002 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load886, 1
  %.splatinsert887 = insertelement <8 x i64> poison, i64 %2000, i64 0
  %.splat888 = shufflevector <8 x i64> %.splatinsert887, <8 x i64> poison, <8 x i32> zeroinitializer
  %2003 = mul <8 x i64> %.splat888, splat (i64 32)
  %2004 = add <8 x i64> %2002, %2003
  %2005 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2001, 0
  %2006 = insertvalue { <8 x ptr>, <8 x i64> } %2005, <8 x i64> %2004, 1
  %2007 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2008 = extractvalue { <8 x ptr>, <8 x i64> } %2006, 1
  %2009 = extractelement <8 x ptr> %2007, i32 0
  %2010 = extractelement <8 x i64> %2008, i32 0
  %2011 = sub i64 %2010, 0
  %2012 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2013 = select i1 %2012, i64 %2011, i64 0
  %private.contiguous.address889 = getelementptr i8, ptr %2009, i64 %2013
  %private.contiguous.load890 = load <8 x float>, ptr %private.contiguous.address889, align 4
  %2014 = select <8 x i1> %71, <8 x float> %private.contiguous.load890, <8 x float> zeroinitializer
  %.spill.load891 = load <8 x float>, ptr %.spill121, align 32
  %2015 = fmul <8 x float> %.spill.load891, %2014
  %2016 = fadd <8 x float> %1948, %2015
  %2017 = add i64 480, %1613
  %tile_snapshot.spill.load892 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2018 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load892, 0
  %2019 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load892, 1
  %.splatinsert893 = insertelement <8 x i64> poison, i64 %2017, i64 0
  %.splat894 = shufflevector <8 x i64> %.splatinsert893, <8 x i64> poison, <8 x i32> zeroinitializer
  %2020 = mul <8 x i64> %.splat894, splat (i64 32)
  %2021 = add <8 x i64> %2019, %2020
  %2022 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2018, 0
  %2023 = insertvalue { <8 x ptr>, <8 x i64> } %2022, <8 x i64> %2021, 1
  %2024 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2025 = extractvalue { <8 x ptr>, <8 x i64> } %2023, 1
  %2026 = extractelement <8 x ptr> %2024, i32 0
  %2027 = extractelement <8 x i64> %2025, i32 0
  %2028 = sub i64 %2027, 0
  %2029 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2030 = select i1 %2029, i64 %2028, i64 0
  %private.contiguous.address895 = getelementptr i8, ptr %2026, i64 %2030
  %private.contiguous.load896 = load <8 x float>, ptr %private.contiguous.address895, align 4
  %2031 = select <8 x i1> %71, <8 x float> %private.contiguous.load896, <8 x float> zeroinitializer
  %.spill.load897 = load <8 x float>, ptr %.spill121, align 32
  %2032 = fmul <8 x float> %.spill.load897, %2031
  %2033 = fadd <8 x float> %1965, %2032
  %2034 = add i64 480, %1630
  %tile_snapshot.spill.load898 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2035 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load898, 0
  %2036 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load898, 1
  %.splatinsert899 = insertelement <8 x i64> poison, i64 %2034, i64 0
  %.splat900 = shufflevector <8 x i64> %.splatinsert899, <8 x i64> poison, <8 x i32> zeroinitializer
  %2037 = mul <8 x i64> %.splat900, splat (i64 32)
  %2038 = add <8 x i64> %2036, %2037
  %2039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2035, 0
  %2040 = insertvalue { <8 x ptr>, <8 x i64> } %2039, <8 x i64> %2038, 1
  %2041 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2042 = extractvalue { <8 x ptr>, <8 x i64> } %2040, 1
  %2043 = extractelement <8 x ptr> %2041, i32 0
  %2044 = extractelement <8 x i64> %2042, i32 0
  %2045 = sub i64 %2044, 0
  %2046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2047 = select i1 %2046, i64 %2045, i64 0
  %private.contiguous.address901 = getelementptr i8, ptr %2043, i64 %2047
  %private.contiguous.load902 = load <8 x float>, ptr %private.contiguous.address901, align 4
  %2048 = select <8 x i1> %71, <8 x float> %private.contiguous.load902, <8 x float> zeroinitializer
  %.spill.load903 = load <8 x float>, ptr %.spill121, align 32
  %2049 = fmul <8 x float> %.spill.load903, %2048
  %2050 = fadd <8 x float> %1982, %2049
  %2051 = add i64 480, %1647
  %tile_snapshot.spill.load904 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2052 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load904, 0
  %2053 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load904, 1
  %.splatinsert905 = insertelement <8 x i64> poison, i64 %2051, i64 0
  %.splat906 = shufflevector <8 x i64> %.splatinsert905, <8 x i64> poison, <8 x i32> zeroinitializer
  %2054 = mul <8 x i64> %.splat906, splat (i64 32)
  %2055 = add <8 x i64> %2053, %2054
  %2056 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2052, 0
  %2057 = insertvalue { <8 x ptr>, <8 x i64> } %2056, <8 x i64> %2055, 1
  %2058 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2059 = extractvalue { <8 x ptr>, <8 x i64> } %2057, 1
  %2060 = extractelement <8 x ptr> %2058, i32 0
  %2061 = extractelement <8 x i64> %2059, i32 0
  %2062 = sub i64 %2061, 0
  %2063 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2064 = select i1 %2063, i64 %2062, i64 0
  %private.contiguous.address907 = getelementptr i8, ptr %2060, i64 %2064
  %private.contiguous.load908 = load <8 x float>, ptr %private.contiguous.address907, align 4
  %2065 = select <8 x i1> %71, <8 x float> %private.contiguous.load908, <8 x float> zeroinitializer
  %.spill.load909 = load <8 x float>, ptr %.spill121, align 32
  %2066 = fmul <8 x float> %.spill.load909, %2065
  %2067 = fadd <8 x float> %1999, %2066
  %2068 = add i64 576, %1596
  %tile_snapshot.spill.load910 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2069 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load910, 0
  %2070 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load910, 1
  %.splatinsert911 = insertelement <8 x i64> poison, i64 %2068, i64 0
  %.splat912 = shufflevector <8 x i64> %.splatinsert911, <8 x i64> poison, <8 x i32> zeroinitializer
  %2071 = mul <8 x i64> %.splat912, splat (i64 32)
  %2072 = add <8 x i64> %2070, %2071
  %2073 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2069, 0
  %2074 = insertvalue { <8 x ptr>, <8 x i64> } %2073, <8 x i64> %2072, 1
  %2075 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2076 = extractvalue { <8 x ptr>, <8 x i64> } %2074, 1
  %2077 = extractelement <8 x ptr> %2075, i32 0
  %2078 = extractelement <8 x i64> %2076, i32 0
  %2079 = sub i64 %2078, 0
  %2080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2081 = select i1 %2080, i64 %2079, i64 0
  %private.contiguous.address913 = getelementptr i8, ptr %2077, i64 %2081
  %private.contiguous.load914 = load <8 x float>, ptr %private.contiguous.address913, align 4
  %2082 = select <8 x i1> %71, <8 x float> %private.contiguous.load914, <8 x float> zeroinitializer
  %.spill.load915 = load <8 x float>, ptr %.spill122, align 32
  %2083 = fmul <8 x float> %.spill.load915, %2082
  %2084 = fadd <8 x float> %2016, %2083
  %2085 = add i64 576, %1613
  %tile_snapshot.spill.load916 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2086 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load916, 0
  %2087 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load916, 1
  %.splatinsert917 = insertelement <8 x i64> poison, i64 %2085, i64 0
  %.splat918 = shufflevector <8 x i64> %.splatinsert917, <8 x i64> poison, <8 x i32> zeroinitializer
  %2088 = mul <8 x i64> %.splat918, splat (i64 32)
  %2089 = add <8 x i64> %2087, %2088
  %2090 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2086, 0
  %2091 = insertvalue { <8 x ptr>, <8 x i64> } %2090, <8 x i64> %2089, 1
  %2092 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2093 = extractvalue { <8 x ptr>, <8 x i64> } %2091, 1
  %2094 = extractelement <8 x ptr> %2092, i32 0
  %2095 = extractelement <8 x i64> %2093, i32 0
  %2096 = sub i64 %2095, 0
  %2097 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2098 = select i1 %2097, i64 %2096, i64 0
  %private.contiguous.address919 = getelementptr i8, ptr %2094, i64 %2098
  %private.contiguous.load920 = load <8 x float>, ptr %private.contiguous.address919, align 4
  %2099 = select <8 x i1> %71, <8 x float> %private.contiguous.load920, <8 x float> zeroinitializer
  %.spill.load921 = load <8 x float>, ptr %.spill122, align 32
  %2100 = fmul <8 x float> %.spill.load921, %2099
  %2101 = fadd <8 x float> %2033, %2100
  %2102 = add i64 576, %1630
  %tile_snapshot.spill.load922 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load922, 0
  %2104 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load922, 1
  %.splatinsert923 = insertelement <8 x i64> poison, i64 %2102, i64 0
  %.splat924 = shufflevector <8 x i64> %.splatinsert923, <8 x i64> poison, <8 x i32> zeroinitializer
  %2105 = mul <8 x i64> %.splat924, splat (i64 32)
  %2106 = add <8 x i64> %2104, %2105
  %2107 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2103, 0
  %2108 = insertvalue { <8 x ptr>, <8 x i64> } %2107, <8 x i64> %2106, 1
  %2109 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2110 = extractvalue { <8 x ptr>, <8 x i64> } %2108, 1
  %2111 = extractelement <8 x ptr> %2109, i32 0
  %2112 = extractelement <8 x i64> %2110, i32 0
  %2113 = sub i64 %2112, 0
  %2114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2115 = select i1 %2114, i64 %2113, i64 0
  %private.contiguous.address925 = getelementptr i8, ptr %2111, i64 %2115
  %private.contiguous.load926 = load <8 x float>, ptr %private.contiguous.address925, align 4
  %2116 = select <8 x i1> %71, <8 x float> %private.contiguous.load926, <8 x float> zeroinitializer
  %.spill.load927 = load <8 x float>, ptr %.spill122, align 32
  %2117 = fmul <8 x float> %.spill.load927, %2116
  %2118 = fadd <8 x float> %2050, %2117
  %2119 = add i64 576, %1647
  %tile_snapshot.spill.load928 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2120 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load928, 0
  %2121 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load928, 1
  %.splatinsert929 = insertelement <8 x i64> poison, i64 %2119, i64 0
  %.splat930 = shufflevector <8 x i64> %.splatinsert929, <8 x i64> poison, <8 x i32> zeroinitializer
  %2122 = mul <8 x i64> %.splat930, splat (i64 32)
  %2123 = add <8 x i64> %2121, %2122
  %2124 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2120, 0
  %2125 = insertvalue { <8 x ptr>, <8 x i64> } %2124, <8 x i64> %2123, 1
  %2126 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2127 = extractvalue { <8 x ptr>, <8 x i64> } %2125, 1
  %2128 = extractelement <8 x ptr> %2126, i32 0
  %2129 = extractelement <8 x i64> %2127, i32 0
  %2130 = sub i64 %2129, 0
  %2131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2132 = select i1 %2131, i64 %2130, i64 0
  %private.contiguous.address931 = getelementptr i8, ptr %2128, i64 %2132
  %private.contiguous.load932 = load <8 x float>, ptr %private.contiguous.address931, align 4
  %2133 = select <8 x i1> %71, <8 x float> %private.contiguous.load932, <8 x float> zeroinitializer
  %.spill.load933 = load <8 x float>, ptr %.spill122, align 32
  %2134 = fmul <8 x float> %.spill.load933, %2133
  %2135 = fadd <8 x float> %2067, %2134
  %2136 = add i64 672, %1596
  %tile_snapshot.spill.load934 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load934, 0
  %2138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load934, 1
  %.splatinsert935 = insertelement <8 x i64> poison, i64 %2136, i64 0
  %.splat936 = shufflevector <8 x i64> %.splatinsert935, <8 x i64> poison, <8 x i32> zeroinitializer
  %2139 = mul <8 x i64> %.splat936, splat (i64 32)
  %2140 = add <8 x i64> %2138, %2139
  %2141 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2137, 0
  %2142 = insertvalue { <8 x ptr>, <8 x i64> } %2141, <8 x i64> %2140, 1
  %2143 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2144 = extractvalue { <8 x ptr>, <8 x i64> } %2142, 1
  %2145 = extractelement <8 x ptr> %2143, i32 0
  %2146 = extractelement <8 x i64> %2144, i32 0
  %2147 = sub i64 %2146, 0
  %2148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2149 = select i1 %2148, i64 %2147, i64 0
  %private.contiguous.address937 = getelementptr i8, ptr %2145, i64 %2149
  %private.contiguous.load938 = load <8 x float>, ptr %private.contiguous.address937, align 4
  %2150 = select <8 x i1> %71, <8 x float> %private.contiguous.load938, <8 x float> zeroinitializer
  %.spill.load939 = load <8 x float>, ptr %.spill123, align 32
  %2151 = fmul <8 x float> %.spill.load939, %2150
  %2152 = fadd <8 x float> %2084, %2151
  %2153 = add i64 672, %1613
  %tile_snapshot.spill.load940 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2154 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load940, 0
  %2155 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load940, 1
  %.splatinsert941 = insertelement <8 x i64> poison, i64 %2153, i64 0
  %.splat942 = shufflevector <8 x i64> %.splatinsert941, <8 x i64> poison, <8 x i32> zeroinitializer
  %2156 = mul <8 x i64> %.splat942, splat (i64 32)
  %2157 = add <8 x i64> %2155, %2156
  %2158 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2154, 0
  %2159 = insertvalue { <8 x ptr>, <8 x i64> } %2158, <8 x i64> %2157, 1
  %2160 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2161 = extractvalue { <8 x ptr>, <8 x i64> } %2159, 1
  %2162 = extractelement <8 x ptr> %2160, i32 0
  %2163 = extractelement <8 x i64> %2161, i32 0
  %2164 = sub i64 %2163, 0
  %2165 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2166 = select i1 %2165, i64 %2164, i64 0
  %private.contiguous.address943 = getelementptr i8, ptr %2162, i64 %2166
  %private.contiguous.load944 = load <8 x float>, ptr %private.contiguous.address943, align 4
  %2167 = select <8 x i1> %71, <8 x float> %private.contiguous.load944, <8 x float> zeroinitializer
  %.spill.load945 = load <8 x float>, ptr %.spill123, align 32
  %2168 = fmul <8 x float> %.spill.load945, %2167
  %2169 = fadd <8 x float> %2101, %2168
  %2170 = add i64 672, %1630
  %tile_snapshot.spill.load946 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load946, 0
  %2172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load946, 1
  %.splatinsert947 = insertelement <8 x i64> poison, i64 %2170, i64 0
  %.splat948 = shufflevector <8 x i64> %.splatinsert947, <8 x i64> poison, <8 x i32> zeroinitializer
  %2173 = mul <8 x i64> %.splat948, splat (i64 32)
  %2174 = add <8 x i64> %2172, %2173
  %2175 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2171, 0
  %2176 = insertvalue { <8 x ptr>, <8 x i64> } %2175, <8 x i64> %2174, 1
  %2177 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2178 = extractvalue { <8 x ptr>, <8 x i64> } %2176, 1
  %2179 = extractelement <8 x ptr> %2177, i32 0
  %2180 = extractelement <8 x i64> %2178, i32 0
  %2181 = sub i64 %2180, 0
  %2182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2183 = select i1 %2182, i64 %2181, i64 0
  %private.contiguous.address949 = getelementptr i8, ptr %2179, i64 %2183
  %private.contiguous.load950 = load <8 x float>, ptr %private.contiguous.address949, align 4
  %2184 = select <8 x i1> %71, <8 x float> %private.contiguous.load950, <8 x float> zeroinitializer
  %.spill.load951 = load <8 x float>, ptr %.spill123, align 32
  %2185 = fmul <8 x float> %.spill.load951, %2184
  %2186 = fadd <8 x float> %2118, %2185
  %2187 = add i64 672, %1647
  %tile_snapshot.spill.load952 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load952, 0
  %2189 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load952, 1
  %.splatinsert953 = insertelement <8 x i64> poison, i64 %2187, i64 0
  %.splat954 = shufflevector <8 x i64> %.splatinsert953, <8 x i64> poison, <8 x i32> zeroinitializer
  %2190 = mul <8 x i64> %.splat954, splat (i64 32)
  %2191 = add <8 x i64> %2189, %2190
  %2192 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2188, 0
  %2193 = insertvalue { <8 x ptr>, <8 x i64> } %2192, <8 x i64> %2191, 1
  %2194 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2195 = extractvalue { <8 x ptr>, <8 x i64> } %2193, 1
  %2196 = extractelement <8 x ptr> %2194, i32 0
  %2197 = extractelement <8 x i64> %2195, i32 0
  %2198 = sub i64 %2197, 0
  %2199 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2200 = select i1 %2199, i64 %2198, i64 0
  %private.contiguous.address955 = getelementptr i8, ptr %2196, i64 %2200
  %private.contiguous.load956 = load <8 x float>, ptr %private.contiguous.address955, align 4
  %2201 = select <8 x i1> %71, <8 x float> %private.contiguous.load956, <8 x float> zeroinitializer
  %.spill.load957 = load <8 x float>, ptr %.spill123, align 32
  %2202 = fmul <8 x float> %.spill.load957, %2201
  %2203 = fadd <8 x float> %2135, %2202
  %2204 = add i64 768, %1596
  %tile_snapshot.spill.load958 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2205 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load958, 0
  %2206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load958, 1
  %.splatinsert959 = insertelement <8 x i64> poison, i64 %2204, i64 0
  %.splat960 = shufflevector <8 x i64> %.splatinsert959, <8 x i64> poison, <8 x i32> zeroinitializer
  %2207 = mul <8 x i64> %.splat960, splat (i64 32)
  %2208 = add <8 x i64> %2206, %2207
  %2209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2205, 0
  %2210 = insertvalue { <8 x ptr>, <8 x i64> } %2209, <8 x i64> %2208, 1
  %2211 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2212 = extractvalue { <8 x ptr>, <8 x i64> } %2210, 1
  %2213 = extractelement <8 x ptr> %2211, i32 0
  %2214 = extractelement <8 x i64> %2212, i32 0
  %2215 = sub i64 %2214, 0
  %2216 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2217 = select i1 %2216, i64 %2215, i64 0
  %private.contiguous.address961 = getelementptr i8, ptr %2213, i64 %2217
  %private.contiguous.load962 = load <8 x float>, ptr %private.contiguous.address961, align 4
  %2218 = select <8 x i1> %71, <8 x float> %private.contiguous.load962, <8 x float> zeroinitializer
  %.spill.load963 = load <8 x float>, ptr %.spill124, align 32
  %2219 = fmul <8 x float> %.spill.load963, %2218
  %2220 = fadd <8 x float> %2152, %2219
  %2221 = add i64 768, %1613
  %tile_snapshot.spill.load964 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load964, 0
  %2223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load964, 1
  %.splatinsert965 = insertelement <8 x i64> poison, i64 %2221, i64 0
  %.splat966 = shufflevector <8 x i64> %.splatinsert965, <8 x i64> poison, <8 x i32> zeroinitializer
  %2224 = mul <8 x i64> %.splat966, splat (i64 32)
  %2225 = add <8 x i64> %2223, %2224
  %2226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2222, 0
  %2227 = insertvalue { <8 x ptr>, <8 x i64> } %2226, <8 x i64> %2225, 1
  %2228 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2229 = extractvalue { <8 x ptr>, <8 x i64> } %2227, 1
  %2230 = extractelement <8 x ptr> %2228, i32 0
  %2231 = extractelement <8 x i64> %2229, i32 0
  %2232 = sub i64 %2231, 0
  %2233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2234 = select i1 %2233, i64 %2232, i64 0
  %private.contiguous.address967 = getelementptr i8, ptr %2230, i64 %2234
  %private.contiguous.load968 = load <8 x float>, ptr %private.contiguous.address967, align 4
  %2235 = select <8 x i1> %71, <8 x float> %private.contiguous.load968, <8 x float> zeroinitializer
  %.spill.load969 = load <8 x float>, ptr %.spill124, align 32
  %2236 = fmul <8 x float> %.spill.load969, %2235
  %2237 = fadd <8 x float> %2169, %2236
  %2238 = add i64 768, %1630
  %tile_snapshot.spill.load970 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2239 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load970, 0
  %2240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load970, 1
  %.splatinsert971 = insertelement <8 x i64> poison, i64 %2238, i64 0
  %.splat972 = shufflevector <8 x i64> %.splatinsert971, <8 x i64> poison, <8 x i32> zeroinitializer
  %2241 = mul <8 x i64> %.splat972, splat (i64 32)
  %2242 = add <8 x i64> %2240, %2241
  %2243 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2239, 0
  %2244 = insertvalue { <8 x ptr>, <8 x i64> } %2243, <8 x i64> %2242, 1
  %2245 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2246 = extractvalue { <8 x ptr>, <8 x i64> } %2244, 1
  %2247 = extractelement <8 x ptr> %2245, i32 0
  %2248 = extractelement <8 x i64> %2246, i32 0
  %2249 = sub i64 %2248, 0
  %2250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2251 = select i1 %2250, i64 %2249, i64 0
  %private.contiguous.address973 = getelementptr i8, ptr %2247, i64 %2251
  %private.contiguous.load974 = load <8 x float>, ptr %private.contiguous.address973, align 4
  %2252 = select <8 x i1> %71, <8 x float> %private.contiguous.load974, <8 x float> zeroinitializer
  %.spill.load975 = load <8 x float>, ptr %.spill124, align 32
  %2253 = fmul <8 x float> %.spill.load975, %2252
  %2254 = fadd <8 x float> %2186, %2253
  %2255 = add i64 768, %1647
  %tile_snapshot.spill.load976 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load976, 0
  %2257 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load976, 1
  %.splatinsert977 = insertelement <8 x i64> poison, i64 %2255, i64 0
  %.splat978 = shufflevector <8 x i64> %.splatinsert977, <8 x i64> poison, <8 x i32> zeroinitializer
  %2258 = mul <8 x i64> %.splat978, splat (i64 32)
  %2259 = add <8 x i64> %2257, %2258
  %2260 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2256, 0
  %2261 = insertvalue { <8 x ptr>, <8 x i64> } %2260, <8 x i64> %2259, 1
  %2262 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2263 = extractvalue { <8 x ptr>, <8 x i64> } %2261, 1
  %2264 = extractelement <8 x ptr> %2262, i32 0
  %2265 = extractelement <8 x i64> %2263, i32 0
  %2266 = sub i64 %2265, 0
  %2267 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2268 = select i1 %2267, i64 %2266, i64 0
  %private.contiguous.address979 = getelementptr i8, ptr %2264, i64 %2268
  %private.contiguous.load980 = load <8 x float>, ptr %private.contiguous.address979, align 4
  %2269 = select <8 x i1> %71, <8 x float> %private.contiguous.load980, <8 x float> zeroinitializer
  %.spill.load981 = load <8 x float>, ptr %.spill124, align 32
  %2270 = fmul <8 x float> %.spill.load981, %2269
  %2271 = fadd <8 x float> %2203, %2270
  %2272 = add i64 864, %1596
  %tile_snapshot.spill.load982 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load982, 0
  %2274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load982, 1
  %.splatinsert983 = insertelement <8 x i64> poison, i64 %2272, i64 0
  %.splat984 = shufflevector <8 x i64> %.splatinsert983, <8 x i64> poison, <8 x i32> zeroinitializer
  %2275 = mul <8 x i64> %.splat984, splat (i64 32)
  %2276 = add <8 x i64> %2274, %2275
  %2277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2273, 0
  %2278 = insertvalue { <8 x ptr>, <8 x i64> } %2277, <8 x i64> %2276, 1
  %2279 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2280 = extractvalue { <8 x ptr>, <8 x i64> } %2278, 1
  %2281 = extractelement <8 x ptr> %2279, i32 0
  %2282 = extractelement <8 x i64> %2280, i32 0
  %2283 = sub i64 %2282, 0
  %2284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2285 = select i1 %2284, i64 %2283, i64 0
  %private.contiguous.address985 = getelementptr i8, ptr %2281, i64 %2285
  %private.contiguous.load986 = load <8 x float>, ptr %private.contiguous.address985, align 4
  %2286 = select <8 x i1> %71, <8 x float> %private.contiguous.load986, <8 x float> zeroinitializer
  %.spill.load987 = load <8 x float>, ptr %.spill125, align 32
  %2287 = fmul <8 x float> %.spill.load987, %2286
  %2288 = fadd <8 x float> %2220, %2287
  %2289 = add i64 864, %1613
  %tile_snapshot.spill.load988 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2290 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load988, 0
  %2291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load988, 1
  %.splatinsert989 = insertelement <8 x i64> poison, i64 %2289, i64 0
  %.splat990 = shufflevector <8 x i64> %.splatinsert989, <8 x i64> poison, <8 x i32> zeroinitializer
  %2292 = mul <8 x i64> %.splat990, splat (i64 32)
  %2293 = add <8 x i64> %2291, %2292
  %2294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2290, 0
  %2295 = insertvalue { <8 x ptr>, <8 x i64> } %2294, <8 x i64> %2293, 1
  %2296 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2297 = extractvalue { <8 x ptr>, <8 x i64> } %2295, 1
  %2298 = extractelement <8 x ptr> %2296, i32 0
  %2299 = extractelement <8 x i64> %2297, i32 0
  %2300 = sub i64 %2299, 0
  %2301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2302 = select i1 %2301, i64 %2300, i64 0
  %private.contiguous.address991 = getelementptr i8, ptr %2298, i64 %2302
  %private.contiguous.load992 = load <8 x float>, ptr %private.contiguous.address991, align 4
  %2303 = select <8 x i1> %71, <8 x float> %private.contiguous.load992, <8 x float> zeroinitializer
  %.spill.load993 = load <8 x float>, ptr %.spill125, align 32
  %2304 = fmul <8 x float> %.spill.load993, %2303
  %2305 = fadd <8 x float> %2237, %2304
  %2306 = add i64 864, %1630
  %tile_snapshot.spill.load994 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load994, 0
  %2308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load994, 1
  %.splatinsert995 = insertelement <8 x i64> poison, i64 %2306, i64 0
  %.splat996 = shufflevector <8 x i64> %.splatinsert995, <8 x i64> poison, <8 x i32> zeroinitializer
  %2309 = mul <8 x i64> %.splat996, splat (i64 32)
  %2310 = add <8 x i64> %2308, %2309
  %2311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2307, 0
  %2312 = insertvalue { <8 x ptr>, <8 x i64> } %2311, <8 x i64> %2310, 1
  %2313 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2314 = extractvalue { <8 x ptr>, <8 x i64> } %2312, 1
  %2315 = extractelement <8 x ptr> %2313, i32 0
  %2316 = extractelement <8 x i64> %2314, i32 0
  %2317 = sub i64 %2316, 0
  %2318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2319 = select i1 %2318, i64 %2317, i64 0
  %private.contiguous.address997 = getelementptr i8, ptr %2315, i64 %2319
  %private.contiguous.load998 = load <8 x float>, ptr %private.contiguous.address997, align 4
  %2320 = select <8 x i1> %71, <8 x float> %private.contiguous.load998, <8 x float> zeroinitializer
  %.spill.load999 = load <8 x float>, ptr %.spill125, align 32
  %2321 = fmul <8 x float> %.spill.load999, %2320
  %2322 = fadd <8 x float> %2254, %2321
  %2323 = add i64 864, %1647
  %tile_snapshot.spill.load1000 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1000, 0
  %2325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1000, 1
  %.splatinsert1001 = insertelement <8 x i64> poison, i64 %2323, i64 0
  %.splat1002 = shufflevector <8 x i64> %.splatinsert1001, <8 x i64> poison, <8 x i32> zeroinitializer
  %2326 = mul <8 x i64> %.splat1002, splat (i64 32)
  %2327 = add <8 x i64> %2325, %2326
  %2328 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2324, 0
  %2329 = insertvalue { <8 x ptr>, <8 x i64> } %2328, <8 x i64> %2327, 1
  %2330 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2331 = extractvalue { <8 x ptr>, <8 x i64> } %2329, 1
  %2332 = extractelement <8 x ptr> %2330, i32 0
  %2333 = extractelement <8 x i64> %2331, i32 0
  %2334 = sub i64 %2333, 0
  %2335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2336 = select i1 %2335, i64 %2334, i64 0
  %private.contiguous.address1003 = getelementptr i8, ptr %2332, i64 %2336
  %private.contiguous.load1004 = load <8 x float>, ptr %private.contiguous.address1003, align 4
  %2337 = select <8 x i1> %71, <8 x float> %private.contiguous.load1004, <8 x float> zeroinitializer
  %.spill.load1005 = load <8 x float>, ptr %.spill125, align 32
  %2338 = fmul <8 x float> %.spill.load1005, %2337
  %2339 = fadd <8 x float> %2271, %2338
  %2340 = add i64 960, %1596
  %tile_snapshot.spill.load1006 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 0
  %2342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 1
  %.splatinsert1007 = insertelement <8 x i64> poison, i64 %2340, i64 0
  %.splat1008 = shufflevector <8 x i64> %.splatinsert1007, <8 x i64> poison, <8 x i32> zeroinitializer
  %2343 = mul <8 x i64> %.splat1008, splat (i64 32)
  %2344 = add <8 x i64> %2342, %2343
  %2345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2341, 0
  %2346 = insertvalue { <8 x ptr>, <8 x i64> } %2345, <8 x i64> %2344, 1
  %2347 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2348 = extractvalue { <8 x ptr>, <8 x i64> } %2346, 1
  %2349 = extractelement <8 x ptr> %2347, i32 0
  %2350 = extractelement <8 x i64> %2348, i32 0
  %2351 = sub i64 %2350, 0
  %2352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2353 = select i1 %2352, i64 %2351, i64 0
  %private.contiguous.address1009 = getelementptr i8, ptr %2349, i64 %2353
  %private.contiguous.load1010 = load <8 x float>, ptr %private.contiguous.address1009, align 4
  %2354 = select <8 x i1> %71, <8 x float> %private.contiguous.load1010, <8 x float> zeroinitializer
  %.spill.load1011 = load <8 x float>, ptr %.spill126, align 32
  %2355 = fmul <8 x float> %.spill.load1011, %2354
  %2356 = fadd <8 x float> %2288, %2355
  %2357 = add i64 960, %1613
  %tile_snapshot.spill.load1012 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1012, 0
  %2359 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1012, 1
  %.splatinsert1013 = insertelement <8 x i64> poison, i64 %2357, i64 0
  %.splat1014 = shufflevector <8 x i64> %.splatinsert1013, <8 x i64> poison, <8 x i32> zeroinitializer
  %2360 = mul <8 x i64> %.splat1014, splat (i64 32)
  %2361 = add <8 x i64> %2359, %2360
  %2362 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2358, 0
  %2363 = insertvalue { <8 x ptr>, <8 x i64> } %2362, <8 x i64> %2361, 1
  %2364 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2365 = extractvalue { <8 x ptr>, <8 x i64> } %2363, 1
  %2366 = extractelement <8 x ptr> %2364, i32 0
  %2367 = extractelement <8 x i64> %2365, i32 0
  %2368 = sub i64 %2367, 0
  %2369 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2370 = select i1 %2369, i64 %2368, i64 0
  %private.contiguous.address1015 = getelementptr i8, ptr %2366, i64 %2370
  %private.contiguous.load1016 = load <8 x float>, ptr %private.contiguous.address1015, align 4
  %2371 = select <8 x i1> %71, <8 x float> %private.contiguous.load1016, <8 x float> zeroinitializer
  %.spill.load1017 = load <8 x float>, ptr %.spill126, align 32
  %2372 = fmul <8 x float> %.spill.load1017, %2371
  %2373 = fadd <8 x float> %2305, %2372
  %2374 = add i64 960, %1630
  %tile_snapshot.spill.load1018 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2375 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1018, 0
  %2376 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1018, 1
  %.splatinsert1019 = insertelement <8 x i64> poison, i64 %2374, i64 0
  %.splat1020 = shufflevector <8 x i64> %.splatinsert1019, <8 x i64> poison, <8 x i32> zeroinitializer
  %2377 = mul <8 x i64> %.splat1020, splat (i64 32)
  %2378 = add <8 x i64> %2376, %2377
  %2379 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2375, 0
  %2380 = insertvalue { <8 x ptr>, <8 x i64> } %2379, <8 x i64> %2378, 1
  %2381 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2382 = extractvalue { <8 x ptr>, <8 x i64> } %2380, 1
  %2383 = extractelement <8 x ptr> %2381, i32 0
  %2384 = extractelement <8 x i64> %2382, i32 0
  %2385 = sub i64 %2384, 0
  %2386 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2387 = select i1 %2386, i64 %2385, i64 0
  %private.contiguous.address1021 = getelementptr i8, ptr %2383, i64 %2387
  %private.contiguous.load1022 = load <8 x float>, ptr %private.contiguous.address1021, align 4
  %2388 = select <8 x i1> %71, <8 x float> %private.contiguous.load1022, <8 x float> zeroinitializer
  %.spill.load1023 = load <8 x float>, ptr %.spill126, align 32
  %2389 = fmul <8 x float> %.spill.load1023, %2388
  %2390 = fadd <8 x float> %2322, %2389
  %2391 = add i64 960, %1647
  %tile_snapshot.spill.load1024 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1024, 0
  %2393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1024, 1
  %.splatinsert1025 = insertelement <8 x i64> poison, i64 %2391, i64 0
  %.splat1026 = shufflevector <8 x i64> %.splatinsert1025, <8 x i64> poison, <8 x i32> zeroinitializer
  %2394 = mul <8 x i64> %.splat1026, splat (i64 32)
  %2395 = add <8 x i64> %2393, %2394
  %2396 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2392, 0
  %2397 = insertvalue { <8 x ptr>, <8 x i64> } %2396, <8 x i64> %2395, 1
  %2398 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2399 = extractvalue { <8 x ptr>, <8 x i64> } %2397, 1
  %2400 = extractelement <8 x ptr> %2398, i32 0
  %2401 = extractelement <8 x i64> %2399, i32 0
  %2402 = sub i64 %2401, 0
  %2403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2404 = select i1 %2403, i64 %2402, i64 0
  %private.contiguous.address1027 = getelementptr i8, ptr %2400, i64 %2404
  %private.contiguous.load1028 = load <8 x float>, ptr %private.contiguous.address1027, align 4
  %2405 = select <8 x i1> %71, <8 x float> %private.contiguous.load1028, <8 x float> zeroinitializer
  %.spill.load1029 = load <8 x float>, ptr %.spill126, align 32
  %2406 = fmul <8 x float> %.spill.load1029, %2405
  %2407 = fadd <8 x float> %2339, %2406
  %2408 = add i64 1056, %1596
  %tile_snapshot.spill.load1030 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1030, 0
  %2410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1030, 1
  %.splatinsert1031 = insertelement <8 x i64> poison, i64 %2408, i64 0
  %.splat1032 = shufflevector <8 x i64> %.splatinsert1031, <8 x i64> poison, <8 x i32> zeroinitializer
  %2411 = mul <8 x i64> %.splat1032, splat (i64 32)
  %2412 = add <8 x i64> %2410, %2411
  %2413 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2409, 0
  %2414 = insertvalue { <8 x ptr>, <8 x i64> } %2413, <8 x i64> %2412, 1
  %2415 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2416 = extractvalue { <8 x ptr>, <8 x i64> } %2414, 1
  %2417 = extractelement <8 x ptr> %2415, i32 0
  %2418 = extractelement <8 x i64> %2416, i32 0
  %2419 = sub i64 %2418, 0
  %2420 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2421 = select i1 %2420, i64 %2419, i64 0
  %private.contiguous.address1033 = getelementptr i8, ptr %2417, i64 %2421
  %private.contiguous.load1034 = load <8 x float>, ptr %private.contiguous.address1033, align 4
  %2422 = select <8 x i1> %71, <8 x float> %private.contiguous.load1034, <8 x float> zeroinitializer
  %.spill.load1035 = load <8 x float>, ptr %.spill127, align 32
  %2423 = fmul <8 x float> %.spill.load1035, %2422
  %2424 = fadd <8 x float> %2356, %2423
  %2425 = add i64 1056, %1613
  %tile_snapshot.spill.load1036 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1036, 0
  %2427 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1036, 1
  %.splatinsert1037 = insertelement <8 x i64> poison, i64 %2425, i64 0
  %.splat1038 = shufflevector <8 x i64> %.splatinsert1037, <8 x i64> poison, <8 x i32> zeroinitializer
  %2428 = mul <8 x i64> %.splat1038, splat (i64 32)
  %2429 = add <8 x i64> %2427, %2428
  %2430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2426, 0
  %2431 = insertvalue { <8 x ptr>, <8 x i64> } %2430, <8 x i64> %2429, 1
  %2432 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2433 = extractvalue { <8 x ptr>, <8 x i64> } %2431, 1
  %2434 = extractelement <8 x ptr> %2432, i32 0
  %2435 = extractelement <8 x i64> %2433, i32 0
  %2436 = sub i64 %2435, 0
  %2437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2438 = select i1 %2437, i64 %2436, i64 0
  %private.contiguous.address1039 = getelementptr i8, ptr %2434, i64 %2438
  %private.contiguous.load1040 = load <8 x float>, ptr %private.contiguous.address1039, align 4
  %2439 = select <8 x i1> %71, <8 x float> %private.contiguous.load1040, <8 x float> zeroinitializer
  %.spill.load1041 = load <8 x float>, ptr %.spill127, align 32
  %2440 = fmul <8 x float> %.spill.load1041, %2439
  %2441 = fadd <8 x float> %2373, %2440
  %2442 = add i64 1056, %1630
  %tile_snapshot.spill.load1042 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2443 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1042, 0
  %2444 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1042, 1
  %.splatinsert1043 = insertelement <8 x i64> poison, i64 %2442, i64 0
  %.splat1044 = shufflevector <8 x i64> %.splatinsert1043, <8 x i64> poison, <8 x i32> zeroinitializer
  %2445 = mul <8 x i64> %.splat1044, splat (i64 32)
  %2446 = add <8 x i64> %2444, %2445
  %2447 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2443, 0
  %2448 = insertvalue { <8 x ptr>, <8 x i64> } %2447, <8 x i64> %2446, 1
  %2449 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2450 = extractvalue { <8 x ptr>, <8 x i64> } %2448, 1
  %2451 = extractelement <8 x ptr> %2449, i32 0
  %2452 = extractelement <8 x i64> %2450, i32 0
  %2453 = sub i64 %2452, 0
  %2454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2455 = select i1 %2454, i64 %2453, i64 0
  %private.contiguous.address1045 = getelementptr i8, ptr %2451, i64 %2455
  %private.contiguous.load1046 = load <8 x float>, ptr %private.contiguous.address1045, align 4
  %2456 = select <8 x i1> %71, <8 x float> %private.contiguous.load1046, <8 x float> zeroinitializer
  %.spill.load1047 = load <8 x float>, ptr %.spill127, align 32
  %2457 = fmul <8 x float> %.spill.load1047, %2456
  %2458 = fadd <8 x float> %2390, %2457
  %2459 = add i64 1056, %1647
  %tile_snapshot.spill.load1048 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1048, 0
  %2461 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1048, 1
  %.splatinsert1049 = insertelement <8 x i64> poison, i64 %2459, i64 0
  %.splat1050 = shufflevector <8 x i64> %.splatinsert1049, <8 x i64> poison, <8 x i32> zeroinitializer
  %2462 = mul <8 x i64> %.splat1050, splat (i64 32)
  %2463 = add <8 x i64> %2461, %2462
  %2464 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2460, 0
  %2465 = insertvalue { <8 x ptr>, <8 x i64> } %2464, <8 x i64> %2463, 1
  %2466 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2467 = extractvalue { <8 x ptr>, <8 x i64> } %2465, 1
  %2468 = extractelement <8 x ptr> %2466, i32 0
  %2469 = extractelement <8 x i64> %2467, i32 0
  %2470 = sub i64 %2469, 0
  %2471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2472 = select i1 %2471, i64 %2470, i64 0
  %private.contiguous.address1051 = getelementptr i8, ptr %2468, i64 %2472
  %private.contiguous.load1052 = load <8 x float>, ptr %private.contiguous.address1051, align 4
  %2473 = select <8 x i1> %71, <8 x float> %private.contiguous.load1052, <8 x float> zeroinitializer
  %.spill.load1053 = load <8 x float>, ptr %.spill127, align 32
  %2474 = fmul <8 x float> %.spill.load1053, %2473
  %2475 = fadd <8 x float> %2407, %2474
  %2476 = add i64 1152, %1596
  %tile_snapshot.spill.load1054 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2477 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1054, 0
  %2478 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1054, 1
  %.splatinsert1055 = insertelement <8 x i64> poison, i64 %2476, i64 0
  %.splat1056 = shufflevector <8 x i64> %.splatinsert1055, <8 x i64> poison, <8 x i32> zeroinitializer
  %2479 = mul <8 x i64> %.splat1056, splat (i64 32)
  %2480 = add <8 x i64> %2478, %2479
  %2481 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2477, 0
  %2482 = insertvalue { <8 x ptr>, <8 x i64> } %2481, <8 x i64> %2480, 1
  %2483 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2484 = extractvalue { <8 x ptr>, <8 x i64> } %2482, 1
  %2485 = extractelement <8 x ptr> %2483, i32 0
  %2486 = extractelement <8 x i64> %2484, i32 0
  %2487 = sub i64 %2486, 0
  %2488 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2489 = select i1 %2488, i64 %2487, i64 0
  %private.contiguous.address1057 = getelementptr i8, ptr %2485, i64 %2489
  %private.contiguous.load1058 = load <8 x float>, ptr %private.contiguous.address1057, align 4
  %2490 = select <8 x i1> %71, <8 x float> %private.contiguous.load1058, <8 x float> zeroinitializer
  %.spill.load1059 = load <8 x float>, ptr %.spill128, align 32
  %2491 = fmul <8 x float> %.spill.load1059, %2490
  %2492 = fadd <8 x float> %2424, %2491
  %2493 = add i64 1152, %1613
  %tile_snapshot.spill.load1060 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1060, 0
  %2495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1060, 1
  %.splatinsert1061 = insertelement <8 x i64> poison, i64 %2493, i64 0
  %.splat1062 = shufflevector <8 x i64> %.splatinsert1061, <8 x i64> poison, <8 x i32> zeroinitializer
  %2496 = mul <8 x i64> %.splat1062, splat (i64 32)
  %2497 = add <8 x i64> %2495, %2496
  %2498 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2494, 0
  %2499 = insertvalue { <8 x ptr>, <8 x i64> } %2498, <8 x i64> %2497, 1
  %2500 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2501 = extractvalue { <8 x ptr>, <8 x i64> } %2499, 1
  %2502 = extractelement <8 x ptr> %2500, i32 0
  %2503 = extractelement <8 x i64> %2501, i32 0
  %2504 = sub i64 %2503, 0
  %2505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2506 = select i1 %2505, i64 %2504, i64 0
  %private.contiguous.address1063 = getelementptr i8, ptr %2502, i64 %2506
  %private.contiguous.load1064 = load <8 x float>, ptr %private.contiguous.address1063, align 4
  %2507 = select <8 x i1> %71, <8 x float> %private.contiguous.load1064, <8 x float> zeroinitializer
  %.spill.load1065 = load <8 x float>, ptr %.spill128, align 32
  %2508 = fmul <8 x float> %.spill.load1065, %2507
  %2509 = fadd <8 x float> %2441, %2508
  %2510 = add i64 1152, %1630
  %tile_snapshot.spill.load1066 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1066, 0
  %2512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1066, 1
  %.splatinsert1067 = insertelement <8 x i64> poison, i64 %2510, i64 0
  %.splat1068 = shufflevector <8 x i64> %.splatinsert1067, <8 x i64> poison, <8 x i32> zeroinitializer
  %2513 = mul <8 x i64> %.splat1068, splat (i64 32)
  %2514 = add <8 x i64> %2512, %2513
  %2515 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2511, 0
  %2516 = insertvalue { <8 x ptr>, <8 x i64> } %2515, <8 x i64> %2514, 1
  %2517 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2518 = extractvalue { <8 x ptr>, <8 x i64> } %2516, 1
  %2519 = extractelement <8 x ptr> %2517, i32 0
  %2520 = extractelement <8 x i64> %2518, i32 0
  %2521 = sub i64 %2520, 0
  %2522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2523 = select i1 %2522, i64 %2521, i64 0
  %private.contiguous.address1069 = getelementptr i8, ptr %2519, i64 %2523
  %private.contiguous.load1070 = load <8 x float>, ptr %private.contiguous.address1069, align 4
  %2524 = select <8 x i1> %71, <8 x float> %private.contiguous.load1070, <8 x float> zeroinitializer
  %.spill.load1071 = load <8 x float>, ptr %.spill128, align 32
  %2525 = fmul <8 x float> %.spill.load1071, %2524
  %2526 = fadd <8 x float> %2458, %2525
  %2527 = add i64 1152, %1647
  %tile_snapshot.spill.load1072 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1072, 0
  %2529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1072, 1
  %.splatinsert1073 = insertelement <8 x i64> poison, i64 %2527, i64 0
  %.splat1074 = shufflevector <8 x i64> %.splatinsert1073, <8 x i64> poison, <8 x i32> zeroinitializer
  %2530 = mul <8 x i64> %.splat1074, splat (i64 32)
  %2531 = add <8 x i64> %2529, %2530
  %2532 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2528, 0
  %2533 = insertvalue { <8 x ptr>, <8 x i64> } %2532, <8 x i64> %2531, 1
  %2534 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2535 = extractvalue { <8 x ptr>, <8 x i64> } %2533, 1
  %2536 = extractelement <8 x ptr> %2534, i32 0
  %2537 = extractelement <8 x i64> %2535, i32 0
  %2538 = sub i64 %2537, 0
  %2539 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2540 = select i1 %2539, i64 %2538, i64 0
  %private.contiguous.address1075 = getelementptr i8, ptr %2536, i64 %2540
  %private.contiguous.load1076 = load <8 x float>, ptr %private.contiguous.address1075, align 4
  %2541 = select <8 x i1> %71, <8 x float> %private.contiguous.load1076, <8 x float> zeroinitializer
  %.spill.load1077 = load <8 x float>, ptr %.spill128, align 32
  %2542 = fmul <8 x float> %.spill.load1077, %2541
  %2543 = fadd <8 x float> %2475, %2542
  %2544 = add i64 1248, %1596
  %tile_snapshot.spill.load1078 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1078, 0
  %2546 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1078, 1
  %.splatinsert1079 = insertelement <8 x i64> poison, i64 %2544, i64 0
  %.splat1080 = shufflevector <8 x i64> %.splatinsert1079, <8 x i64> poison, <8 x i32> zeroinitializer
  %2547 = mul <8 x i64> %.splat1080, splat (i64 32)
  %2548 = add <8 x i64> %2546, %2547
  %2549 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2545, 0
  %2550 = insertvalue { <8 x ptr>, <8 x i64> } %2549, <8 x i64> %2548, 1
  %2551 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2552 = extractvalue { <8 x ptr>, <8 x i64> } %2550, 1
  %2553 = extractelement <8 x ptr> %2551, i32 0
  %2554 = extractelement <8 x i64> %2552, i32 0
  %2555 = sub i64 %2554, 0
  %2556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2557 = select i1 %2556, i64 %2555, i64 0
  %private.contiguous.address1081 = getelementptr i8, ptr %2553, i64 %2557
  %private.contiguous.load1082 = load <8 x float>, ptr %private.contiguous.address1081, align 4
  %2558 = select <8 x i1> %71, <8 x float> %private.contiguous.load1082, <8 x float> zeroinitializer
  %.spill.load1083 = load <8 x float>, ptr %.spill129, align 32
  %2559 = fmul <8 x float> %.spill.load1083, %2558
  %2560 = fadd <8 x float> %2492, %2559
  %2561 = add i64 1248, %1613
  %tile_snapshot.spill.load1084 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2562 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1084, 0
  %2563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1084, 1
  %.splatinsert1085 = insertelement <8 x i64> poison, i64 %2561, i64 0
  %.splat1086 = shufflevector <8 x i64> %.splatinsert1085, <8 x i64> poison, <8 x i32> zeroinitializer
  %2564 = mul <8 x i64> %.splat1086, splat (i64 32)
  %2565 = add <8 x i64> %2563, %2564
  %2566 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2562, 0
  %2567 = insertvalue { <8 x ptr>, <8 x i64> } %2566, <8 x i64> %2565, 1
  %2568 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2569 = extractvalue { <8 x ptr>, <8 x i64> } %2567, 1
  %2570 = extractelement <8 x ptr> %2568, i32 0
  %2571 = extractelement <8 x i64> %2569, i32 0
  %2572 = sub i64 %2571, 0
  %2573 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2574 = select i1 %2573, i64 %2572, i64 0
  %private.contiguous.address1087 = getelementptr i8, ptr %2570, i64 %2574
  %private.contiguous.load1088 = load <8 x float>, ptr %private.contiguous.address1087, align 4
  %2575 = select <8 x i1> %71, <8 x float> %private.contiguous.load1088, <8 x float> zeroinitializer
  %.spill.load1089 = load <8 x float>, ptr %.spill129, align 32
  %2576 = fmul <8 x float> %.spill.load1089, %2575
  %2577 = fadd <8 x float> %2509, %2576
  %2578 = add i64 1248, %1630
  %tile_snapshot.spill.load1090 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2579 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1090, 0
  %2580 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1090, 1
  %.splatinsert1091 = insertelement <8 x i64> poison, i64 %2578, i64 0
  %.splat1092 = shufflevector <8 x i64> %.splatinsert1091, <8 x i64> poison, <8 x i32> zeroinitializer
  %2581 = mul <8 x i64> %.splat1092, splat (i64 32)
  %2582 = add <8 x i64> %2580, %2581
  %2583 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2579, 0
  %2584 = insertvalue { <8 x ptr>, <8 x i64> } %2583, <8 x i64> %2582, 1
  %2585 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2586 = extractvalue { <8 x ptr>, <8 x i64> } %2584, 1
  %2587 = extractelement <8 x ptr> %2585, i32 0
  %2588 = extractelement <8 x i64> %2586, i32 0
  %2589 = sub i64 %2588, 0
  %2590 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2591 = select i1 %2590, i64 %2589, i64 0
  %private.contiguous.address1093 = getelementptr i8, ptr %2587, i64 %2591
  %private.contiguous.load1094 = load <8 x float>, ptr %private.contiguous.address1093, align 4
  %2592 = select <8 x i1> %71, <8 x float> %private.contiguous.load1094, <8 x float> zeroinitializer
  %.spill.load1095 = load <8 x float>, ptr %.spill129, align 32
  %2593 = fmul <8 x float> %.spill.load1095, %2592
  %2594 = fadd <8 x float> %2526, %2593
  %2595 = add i64 1248, %1647
  %tile_snapshot.spill.load1096 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1096, 0
  %2597 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1096, 1
  %.splatinsert1097 = insertelement <8 x i64> poison, i64 %2595, i64 0
  %.splat1098 = shufflevector <8 x i64> %.splatinsert1097, <8 x i64> poison, <8 x i32> zeroinitializer
  %2598 = mul <8 x i64> %.splat1098, splat (i64 32)
  %2599 = add <8 x i64> %2597, %2598
  %2600 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2596, 0
  %2601 = insertvalue { <8 x ptr>, <8 x i64> } %2600, <8 x i64> %2599, 1
  %2602 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2603 = extractvalue { <8 x ptr>, <8 x i64> } %2601, 1
  %2604 = extractelement <8 x ptr> %2602, i32 0
  %2605 = extractelement <8 x i64> %2603, i32 0
  %2606 = sub i64 %2605, 0
  %2607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2608 = select i1 %2607, i64 %2606, i64 0
  %private.contiguous.address1099 = getelementptr i8, ptr %2604, i64 %2608
  %private.contiguous.load1100 = load <8 x float>, ptr %private.contiguous.address1099, align 4
  %2609 = select <8 x i1> %71, <8 x float> %private.contiguous.load1100, <8 x float> zeroinitializer
  %.spill.load1101 = load <8 x float>, ptr %.spill129, align 32
  %2610 = fmul <8 x float> %.spill.load1101, %2609
  %2611 = fadd <8 x float> %2543, %2610
  %2612 = add i64 1344, %1596
  %tile_snapshot.spill.load1102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2613 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1102, 0
  %2614 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1102, 1
  %.splatinsert1103 = insertelement <8 x i64> poison, i64 %2612, i64 0
  %.splat1104 = shufflevector <8 x i64> %.splatinsert1103, <8 x i64> poison, <8 x i32> zeroinitializer
  %2615 = mul <8 x i64> %.splat1104, splat (i64 32)
  %2616 = add <8 x i64> %2614, %2615
  %2617 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2613, 0
  %2618 = insertvalue { <8 x ptr>, <8 x i64> } %2617, <8 x i64> %2616, 1
  %2619 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2620 = extractvalue { <8 x ptr>, <8 x i64> } %2618, 1
  %2621 = extractelement <8 x ptr> %2619, i32 0
  %2622 = extractelement <8 x i64> %2620, i32 0
  %2623 = sub i64 %2622, 0
  %2624 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2625 = select i1 %2624, i64 %2623, i64 0
  %private.contiguous.address1105 = getelementptr i8, ptr %2621, i64 %2625
  %private.contiguous.load1106 = load <8 x float>, ptr %private.contiguous.address1105, align 4
  %2626 = select <8 x i1> %71, <8 x float> %private.contiguous.load1106, <8 x float> zeroinitializer
  %.spill.load1107 = load <8 x float>, ptr %.spill130, align 32
  %2627 = fmul <8 x float> %.spill.load1107, %2626
  %2628 = fadd <8 x float> %2560, %2627
  %2629 = add i64 1344, %1613
  %tile_snapshot.spill.load1108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1108, 0
  %2631 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1108, 1
  %.splatinsert1109 = insertelement <8 x i64> poison, i64 %2629, i64 0
  %.splat1110 = shufflevector <8 x i64> %.splatinsert1109, <8 x i64> poison, <8 x i32> zeroinitializer
  %2632 = mul <8 x i64> %.splat1110, splat (i64 32)
  %2633 = add <8 x i64> %2631, %2632
  %2634 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2630, 0
  %2635 = insertvalue { <8 x ptr>, <8 x i64> } %2634, <8 x i64> %2633, 1
  %2636 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2637 = extractvalue { <8 x ptr>, <8 x i64> } %2635, 1
  %2638 = extractelement <8 x ptr> %2636, i32 0
  %2639 = extractelement <8 x i64> %2637, i32 0
  %2640 = sub i64 %2639, 0
  %2641 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2642 = select i1 %2641, i64 %2640, i64 0
  %private.contiguous.address1111 = getelementptr i8, ptr %2638, i64 %2642
  %private.contiguous.load1112 = load <8 x float>, ptr %private.contiguous.address1111, align 4
  %2643 = select <8 x i1> %71, <8 x float> %private.contiguous.load1112, <8 x float> zeroinitializer
  %.spill.load1113 = load <8 x float>, ptr %.spill130, align 32
  %2644 = fmul <8 x float> %.spill.load1113, %2643
  %2645 = fadd <8 x float> %2577, %2644
  %2646 = add i64 1344, %1630
  %tile_snapshot.spill.load1114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1114, 0
  %2648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1114, 1
  %.splatinsert1115 = insertelement <8 x i64> poison, i64 %2646, i64 0
  %.splat1116 = shufflevector <8 x i64> %.splatinsert1115, <8 x i64> poison, <8 x i32> zeroinitializer
  %2649 = mul <8 x i64> %.splat1116, splat (i64 32)
  %2650 = add <8 x i64> %2648, %2649
  %2651 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2647, 0
  %2652 = insertvalue { <8 x ptr>, <8 x i64> } %2651, <8 x i64> %2650, 1
  %2653 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2654 = extractvalue { <8 x ptr>, <8 x i64> } %2652, 1
  %2655 = extractelement <8 x ptr> %2653, i32 0
  %2656 = extractelement <8 x i64> %2654, i32 0
  %2657 = sub i64 %2656, 0
  %2658 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2659 = select i1 %2658, i64 %2657, i64 0
  %private.contiguous.address1117 = getelementptr i8, ptr %2655, i64 %2659
  %private.contiguous.load1118 = load <8 x float>, ptr %private.contiguous.address1117, align 4
  %2660 = select <8 x i1> %71, <8 x float> %private.contiguous.load1118, <8 x float> zeroinitializer
  %.spill.load1119 = load <8 x float>, ptr %.spill130, align 32
  %2661 = fmul <8 x float> %.spill.load1119, %2660
  %2662 = fadd <8 x float> %2594, %2661
  %2663 = add i64 1344, %1647
  %tile_snapshot.spill.load1120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1120, 0
  %2665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1120, 1
  %.splatinsert1121 = insertelement <8 x i64> poison, i64 %2663, i64 0
  %.splat1122 = shufflevector <8 x i64> %.splatinsert1121, <8 x i64> poison, <8 x i32> zeroinitializer
  %2666 = mul <8 x i64> %.splat1122, splat (i64 32)
  %2667 = add <8 x i64> %2665, %2666
  %2668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2664, 0
  %2669 = insertvalue { <8 x ptr>, <8 x i64> } %2668, <8 x i64> %2667, 1
  %2670 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2671 = extractvalue { <8 x ptr>, <8 x i64> } %2669, 1
  %2672 = extractelement <8 x ptr> %2670, i32 0
  %2673 = extractelement <8 x i64> %2671, i32 0
  %2674 = sub i64 %2673, 0
  %2675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2676 = select i1 %2675, i64 %2674, i64 0
  %private.contiguous.address1123 = getelementptr i8, ptr %2672, i64 %2676
  %private.contiguous.load1124 = load <8 x float>, ptr %private.contiguous.address1123, align 4
  %2677 = select <8 x i1> %71, <8 x float> %private.contiguous.load1124, <8 x float> zeroinitializer
  %.spill.load1125 = load <8 x float>, ptr %.spill130, align 32
  %2678 = fmul <8 x float> %.spill.load1125, %2677
  %2679 = fadd <8 x float> %2611, %2678
  %2680 = add i64 1440, %1596
  %tile_snapshot.spill.load1126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1126, 0
  %2682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1126, 1
  %.splatinsert1127 = insertelement <8 x i64> poison, i64 %2680, i64 0
  %.splat1128 = shufflevector <8 x i64> %.splatinsert1127, <8 x i64> poison, <8 x i32> zeroinitializer
  %2683 = mul <8 x i64> %.splat1128, splat (i64 32)
  %2684 = add <8 x i64> %2682, %2683
  %2685 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2681, 0
  %2686 = insertvalue { <8 x ptr>, <8 x i64> } %2685, <8 x i64> %2684, 1
  %2687 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2688 = extractvalue { <8 x ptr>, <8 x i64> } %2686, 1
  %2689 = extractelement <8 x ptr> %2687, i32 0
  %2690 = extractelement <8 x i64> %2688, i32 0
  %2691 = sub i64 %2690, 0
  %2692 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2693 = select i1 %2692, i64 %2691, i64 0
  %private.contiguous.address1129 = getelementptr i8, ptr %2689, i64 %2693
  %private.contiguous.load1130 = load <8 x float>, ptr %private.contiguous.address1129, align 4
  %2694 = select <8 x i1> %71, <8 x float> %private.contiguous.load1130, <8 x float> zeroinitializer
  %.spill.load1131 = load <8 x float>, ptr %.spill131, align 32
  %2695 = fmul <8 x float> %.spill.load1131, %2694
  %2696 = fadd <8 x float> %2628, %2695
  %2697 = add i64 1440, %1613
  %tile_snapshot.spill.load1132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2698 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1132, 0
  %2699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1132, 1
  %.splatinsert1133 = insertelement <8 x i64> poison, i64 %2697, i64 0
  %.splat1134 = shufflevector <8 x i64> %.splatinsert1133, <8 x i64> poison, <8 x i32> zeroinitializer
  %2700 = mul <8 x i64> %.splat1134, splat (i64 32)
  %2701 = add <8 x i64> %2699, %2700
  %2702 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2698, 0
  %2703 = insertvalue { <8 x ptr>, <8 x i64> } %2702, <8 x i64> %2701, 1
  %2704 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2705 = extractvalue { <8 x ptr>, <8 x i64> } %2703, 1
  %2706 = extractelement <8 x ptr> %2704, i32 0
  %2707 = extractelement <8 x i64> %2705, i32 0
  %2708 = sub i64 %2707, 0
  %2709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2710 = select i1 %2709, i64 %2708, i64 0
  %private.contiguous.address1135 = getelementptr i8, ptr %2706, i64 %2710
  %private.contiguous.load1136 = load <8 x float>, ptr %private.contiguous.address1135, align 4
  %2711 = select <8 x i1> %71, <8 x float> %private.contiguous.load1136, <8 x float> zeroinitializer
  %.spill.load1137 = load <8 x float>, ptr %.spill131, align 32
  %2712 = fmul <8 x float> %.spill.load1137, %2711
  %2713 = fadd <8 x float> %2645, %2712
  %2714 = add i64 1440, %1630
  %tile_snapshot.spill.load1138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2715 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1138, 0
  %2716 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1138, 1
  %.splatinsert1139 = insertelement <8 x i64> poison, i64 %2714, i64 0
  %.splat1140 = shufflevector <8 x i64> %.splatinsert1139, <8 x i64> poison, <8 x i32> zeroinitializer
  %2717 = mul <8 x i64> %.splat1140, splat (i64 32)
  %2718 = add <8 x i64> %2716, %2717
  %2719 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2715, 0
  %2720 = insertvalue { <8 x ptr>, <8 x i64> } %2719, <8 x i64> %2718, 1
  %2721 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2722 = extractvalue { <8 x ptr>, <8 x i64> } %2720, 1
  %2723 = extractelement <8 x ptr> %2721, i32 0
  %2724 = extractelement <8 x i64> %2722, i32 0
  %2725 = sub i64 %2724, 0
  %2726 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2727 = select i1 %2726, i64 %2725, i64 0
  %private.contiguous.address1141 = getelementptr i8, ptr %2723, i64 %2727
  %private.contiguous.load1142 = load <8 x float>, ptr %private.contiguous.address1141, align 4
  %2728 = select <8 x i1> %71, <8 x float> %private.contiguous.load1142, <8 x float> zeroinitializer
  %.spill.load1143 = load <8 x float>, ptr %.spill131, align 32
  %2729 = fmul <8 x float> %.spill.load1143, %2728
  %2730 = fadd <8 x float> %2662, %2729
  %2731 = add i64 1440, %1647
  %tile_snapshot.spill.load1144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2732 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1144, 0
  %2733 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1144, 1
  %.splatinsert1145 = insertelement <8 x i64> poison, i64 %2731, i64 0
  %.splat1146 = shufflevector <8 x i64> %.splatinsert1145, <8 x i64> poison, <8 x i32> zeroinitializer
  %2734 = mul <8 x i64> %.splat1146, splat (i64 32)
  %2735 = add <8 x i64> %2733, %2734
  %2736 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2732, 0
  %2737 = insertvalue { <8 x ptr>, <8 x i64> } %2736, <8 x i64> %2735, 1
  %2738 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2739 = extractvalue { <8 x ptr>, <8 x i64> } %2737, 1
  %2740 = extractelement <8 x ptr> %2738, i32 0
  %2741 = extractelement <8 x i64> %2739, i32 0
  %2742 = sub i64 %2741, 0
  %2743 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2744 = select i1 %2743, i64 %2742, i64 0
  %private.contiguous.address1147 = getelementptr i8, ptr %2740, i64 %2744
  %private.contiguous.load1148 = load <8 x float>, ptr %private.contiguous.address1147, align 4
  %2745 = select <8 x i1> %71, <8 x float> %private.contiguous.load1148, <8 x float> zeroinitializer
  %.spill.load1149 = load <8 x float>, ptr %.spill131, align 32
  %2746 = fmul <8 x float> %.spill.load1149, %2745
  %2747 = fadd <8 x float> %2679, %2746
  %tile_snapshot.spill.load1150 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill137, align 64
  %2748 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1150, 0
  %2749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1150, 1
  %.splatinsert1151 = insertelement <8 x i64> poison, i64 %1596, i64 0
  %.splat1152 = shufflevector <8 x i64> %.splatinsert1151, <8 x i64> poison, <8 x i32> zeroinitializer
  %2750 = mul <8 x i64> %.splat1152, splat (i64 32)
  %2751 = add <8 x i64> %2749, %2750
  %2752 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2748, 0
  %2753 = insertvalue { <8 x ptr>, <8 x i64> } %2752, <8 x i64> %2751, 1
  %2754 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2755 = extractvalue { <8 x ptr>, <8 x i64> } %2753, 1
  %2756 = extractelement <8 x ptr> %2754, i32 0
  %2757 = extractelement <8 x i64> %2755, i32 0
  %2758 = sub i64 %2757, 0
  %2759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2760 = select i1 %2759, i64 %2758, i64 0
  %private.contiguous.address1153 = getelementptr i8, ptr %2756, i64 %2760
  %private.contiguous.preserve1154 = load <8 x float>, ptr %private.contiguous.address1153, align 4
  %2761 = select <8 x i1> %71, <8 x float> %2696, <8 x float> %private.contiguous.preserve1154
  store <8 x float> %2761, ptr %private.contiguous.address1153, align 4
  %tile_snapshot.spill.load1155 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill137, align 64
  %2762 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1155, 0
  %2763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1155, 1
  %.splatinsert1156 = insertelement <8 x i64> poison, i64 %1613, i64 0
  %.splat1157 = shufflevector <8 x i64> %.splatinsert1156, <8 x i64> poison, <8 x i32> zeroinitializer
  %2764 = mul <8 x i64> %.splat1157, splat (i64 32)
  %2765 = add <8 x i64> %2763, %2764
  %2766 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2762, 0
  %2767 = insertvalue { <8 x ptr>, <8 x i64> } %2766, <8 x i64> %2765, 1
  %2768 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2769 = extractvalue { <8 x ptr>, <8 x i64> } %2767, 1
  %2770 = extractelement <8 x ptr> %2768, i32 0
  %2771 = extractelement <8 x i64> %2769, i32 0
  %2772 = sub i64 %2771, 0
  %2773 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2774 = select i1 %2773, i64 %2772, i64 0
  %private.contiguous.address1158 = getelementptr i8, ptr %2770, i64 %2774
  %private.contiguous.preserve1159 = load <8 x float>, ptr %private.contiguous.address1158, align 4
  %2775 = select <8 x i1> %71, <8 x float> %2713, <8 x float> %private.contiguous.preserve1159
  store <8 x float> %2775, ptr %private.contiguous.address1158, align 4
  %tile_snapshot.spill.load1160 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill137, align 64
  %2776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1160, 0
  %2777 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1160, 1
  %.splatinsert1161 = insertelement <8 x i64> poison, i64 %1630, i64 0
  %.splat1162 = shufflevector <8 x i64> %.splatinsert1161, <8 x i64> poison, <8 x i32> zeroinitializer
  %2778 = mul <8 x i64> %.splat1162, splat (i64 32)
  %2779 = add <8 x i64> %2777, %2778
  %2780 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2776, 0
  %2781 = insertvalue { <8 x ptr>, <8 x i64> } %2780, <8 x i64> %2779, 1
  %2782 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2783 = extractvalue { <8 x ptr>, <8 x i64> } %2781, 1
  %2784 = extractelement <8 x ptr> %2782, i32 0
  %2785 = extractelement <8 x i64> %2783, i32 0
  %2786 = sub i64 %2785, 0
  %2787 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2788 = select i1 %2787, i64 %2786, i64 0
  %private.contiguous.address1163 = getelementptr i8, ptr %2784, i64 %2788
  %private.contiguous.preserve1164 = load <8 x float>, ptr %private.contiguous.address1163, align 4
  %2789 = select <8 x i1> %71, <8 x float> %2730, <8 x float> %private.contiguous.preserve1164
  store <8 x float> %2789, ptr %private.contiguous.address1163, align 4
  %tile_snapshot.spill.load1165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill137, align 64
  %2790 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1165, 0
  %2791 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1165, 1
  %.splatinsert1166 = insertelement <8 x i64> poison, i64 %1647, i64 0
  %.splat1167 = shufflevector <8 x i64> %.splatinsert1166, <8 x i64> poison, <8 x i32> zeroinitializer
  %2792 = mul <8 x i64> %.splat1167, splat (i64 32)
  %2793 = add <8 x i64> %2791, %2792
  %2794 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2790, 0
  %2795 = insertvalue { <8 x ptr>, <8 x i64> } %2794, <8 x i64> %2793, 1
  %2796 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2797 = extractvalue { <8 x ptr>, <8 x i64> } %2795, 1
  %2798 = extractelement <8 x ptr> %2796, i32 0
  %2799 = extractelement <8 x i64> %2797, i32 0
  %2800 = sub i64 %2799, 0
  %2801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2802 = select i1 %2801, i64 %2800, i64 0
  %private.contiguous.address1168 = getelementptr i8, ptr %2798, i64 %2802
  %private.contiguous.preserve1169 = load <8 x float>, ptr %private.contiguous.address1168, align 4
  %2803 = select <8 x i1> %71, <8 x float> %2747, <8 x float> %private.contiguous.preserve1169
  store <8 x float> %2803, ptr %private.contiguous.address1168, align 4
  %.state1170 = load i64, ptr %.slot138, align 4
  %2804 = add i64 %.state1170, 1
  store i64 %2804, ptr %.slot138, align 4
  br label %direct.schedule.73

direct.schedule.75:                               ; preds = %direct.false740
  store i64 0, ptr %.slot139, align 4
  br label %direct.schedule.76

direct.schedule.76:                               ; preds = %direct.schedule.77, %direct.schedule.75
  %.state1171 = load i64, ptr %.slot139, align 4
  %2805 = icmp slt i64 %.state1171, 96
  br i1 %2805, label %direct.true1172, label %direct.false1173

direct.schedule.77:                               ; preds = %direct.true1172
  %tile_snapshot.spill.load1174 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill137, align 64
  %2806 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1174, 0
  %2807 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1174, 1
  %.state1175 = load i64, ptr %.slot139, align 4
  %.splatinsert1176 = insertelement <8 x i64> poison, i64 %.state1175, i64 0
  %.splat1177 = shufflevector <8 x i64> %.splatinsert1176, <8 x i64> poison, <8 x i32> zeroinitializer
  %2808 = mul <8 x i64> %.splat1177, splat (i64 32)
  %2809 = add <8 x i64> %2807, %2808
  %2810 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2806, 0
  %2811 = insertvalue { <8 x ptr>, <8 x i64> } %2810, <8 x i64> %2809, 1
  %2812 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2813 = extractvalue { <8 x ptr>, <8 x i64> } %2811, 1
  %2814 = extractelement <8 x ptr> %2812, i32 0
  %2815 = extractelement <8 x i64> %2813, i32 0
  %2816 = sub i64 %2815, 0
  %2817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2818 = select i1 %2817, i64 %2816, i64 0
  %private.contiguous.address1178 = getelementptr i8, ptr %2814, i64 %2818
  %private.contiguous.load1179 = load <8 x float>, ptr %private.contiguous.address1178, align 4
  %2819 = select <8 x i1> %71, <8 x float> %private.contiguous.load1179, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1180 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %2820 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1180, 0
  %2821 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1180, 1
  %.state1181 = load i64, ptr %.slot139, align 4
  %.splatinsert1182 = insertelement <8 x i64> poison, i64 %.state1181, i64 0
  %.splat1183 = shufflevector <8 x i64> %.splatinsert1182, <8 x i64> poison, <8 x i32> zeroinitializer
  %2822 = mul <8 x i64> %.splat1183, splat (i64 32)
  %2823 = add <8 x i64> %2821, %2822
  %2824 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2820, 0
  %2825 = insertvalue { <8 x ptr>, <8 x i64> } %2824, <8 x i64> %2823, 1
  %2826 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %2827 = extractvalue { <8 x ptr>, <8 x i64> } %2825, 1
  %2828 = extractelement <8 x ptr> %2826, i32 0
  %2829 = extractelement <8 x i64> %2827, i32 0
  %2830 = sub i64 %2829, 0
  %2831 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2832 = select i1 %2831, i64 %2830, i64 0
  %private.contiguous.address1184 = getelementptr i8, ptr %2828, i64 %2832
  %private.contiguous.preserve1185 = load <8 x float>, ptr %private.contiguous.address1184, align 4
  %2833 = select <8 x i1> %71, <8 x float> %2819, <8 x float> %private.contiguous.preserve1185
  store <8 x float> %2833, ptr %private.contiguous.address1184, align 4
  %.state1186 = load i64, ptr %.slot139, align 4
  %2834 = add i64 %.state1186, 1
  store i64 %2834, ptr %.slot139, align 4
  br label %direct.schedule.76

direct.schedule.78:                               ; preds = %direct.false1173
  store i64 0, ptr %.slot140, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state1187 = load i64, ptr %.slot140, align 4
  %2835 = icmp slt i64 %.state1187, 96
  br i1 %2835, label %direct.true1188, label %direct.false1189

direct.schedule.80:                               ; preds = %direct.true1188
  %tile_snapshot.spill.load1190 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %2836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1190, 0
  %2837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1190, 1
  %.state1191 = load i64, ptr %.slot140, align 4
  %.splatinsert1192 = insertelement <8 x i64> poison, i64 %.state1191, i64 0
  %.splat1193 = shufflevector <8 x i64> %.splatinsert1192, <8 x i64> poison, <8 x i32> zeroinitializer
  %2838 = mul <8 x i64> %.splat1193, splat (i64 32)
  %2839 = add <8 x i64> %2837, %2838
  %2840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2836, 0
  %2841 = insertvalue { <8 x ptr>, <8 x i64> } %2840, <8 x i64> %2839, 1
  %2842 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %2843 = extractvalue { <8 x ptr>, <8 x i64> } %2841, 1
  %2844 = extractelement <8 x ptr> %2842, i32 0
  %2845 = extractelement <8 x i64> %2843, i32 0
  %2846 = sub i64 %2845, 0
  %2847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2848 = select i1 %2847, i64 %2846, i64 0
  %private.contiguous.address1194 = getelementptr i8, ptr %2844, i64 %2848
  %private.contiguous.load1195 = load <8 x float>, ptr %private.contiguous.address1194, align 4
  %2849 = select <8 x i1> %71, <8 x float> %private.contiguous.load1195, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1196 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %2850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1196, 0
  %2851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1196, 1
  %.state1197 = load i64, ptr %.slot140, align 4
  %.splatinsert1198 = insertelement <8 x i64> poison, i64 %.state1197, i64 0
  %.splat1199 = shufflevector <8 x i64> %.splatinsert1198, <8 x i64> poison, <8 x i32> zeroinitializer
  %2852 = mul <8 x i64> %.splat1199, splat (i64 32)
  %2853 = add <8 x i64> %2851, %2852
  %2854 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2850, 0
  %2855 = insertvalue { <8 x ptr>, <8 x i64> } %2854, <8 x i64> %2853, 1
  %2856 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2857 = extractvalue { <8 x ptr>, <8 x i64> } %2855, 1
  %2858 = extractelement <8 x ptr> %2856, i32 0
  %2859 = extractelement <8 x i64> %2857, i32 0
  %2860 = sub i64 %2859, 0
  %2861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2862 = select i1 %2861, i64 %2860, i64 0
  %private.contiguous.address1200 = getelementptr i8, ptr %2858, i64 %2862
  %private.contiguous.preserve1201 = load <8 x float>, ptr %private.contiguous.address1200, align 4
  %2863 = select <8 x i1> %71, <8 x float> %2849, <8 x float> %private.contiguous.preserve1201
  store <8 x float> %2863, ptr %private.contiguous.address1200, align 4
  %.state1202 = load i64, ptr %.slot140, align 4
  %2864 = add i64 %.state1202, 1
  store i64 %2864, ptr %.slot140, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false1189
  %.state1203 = load i64, ptr %.slot34, align 4
  %2865 = add i64 %.state1203, 1
  %.spill.load1204 = load <8 x float>, ptr %.spill114, align 32
  %.spill.load1205 = load <8 x float>, ptr %.spill136, align 32
  store i64 %2865, ptr %.slot34, align 4
  %2866 = load <8 x float>, ptr %.slot35, align 32
  %2867 = select <8 x i1> %71, <8 x float> %.spill.load1204, <8 x float> %2866
  store <8 x float> %2867, ptr %.slot35, align 32
  %2868 = load <8 x float>, ptr %.slot36, align 32
  %2869 = select <8 x i1> %71, <8 x float> %.spill.load1205, <8 x float> %2868
  store <8 x float> %2869, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.82:                               ; preds = %direct.false177
  store i64 0, ptr %.slot141, align 4
  br label %direct.schedule.83

direct.schedule.83:                               ; preds = %direct.schedule.84, %direct.schedule.82
  %.state1206 = load i64, ptr %.slot141, align 4
  %2870 = icmp slt i64 %.state1206, 96
  br i1 %2870, label %direct.true1207, label %direct.false1208

direct.schedule.84:                               ; preds = %direct.true1207
  %.spill.load1209 = load i64, ptr %.spill29, align 4
  %2871 = add i64 %.spill.load1209, 0
  %.spill.load1210 = load <8 x i64>, ptr %.spill, align 64
  %2872 = add <8 x i64> %.spill.load1210, zeroinitializer
  %2873 = mul i64 %2871, 8
  %.splatinsert1211 = insertelement <8 x i64> poison, i64 %2873, i64 0
  %.splat1212 = shufflevector <8 x i64> %.splatinsert1211, <8 x i64> poison, <8 x i32> zeroinitializer
  %2874 = add <8 x i64> %.splat1212, %2872
  %.spill.load1213 = load i64, ptr %.spill29, align 4
  %2875 = add i64 %.spill.load1213, 0
  %2876 = mul <8 x i64> %2874, splat (i64 1)
  %.splatinsert1214 = insertelement <8 x i64> poison, i64 %2875, i64 0
  %.splat1215 = shufflevector <8 x i64> %.splatinsert1214, <8 x i64> poison, <8 x i32> zeroinitializer
  %2877 = add <8 x i64> %2876, %.splat1215
  %.state1216 = load i64, ptr %.slot141, align 4
  %2878 = add i64 0, %.state1216
  %2879 = mul <8 x i64> %2877, splat (i64 96)
  %.splatinsert1217 = insertelement <8 x i64> poison, i64 %2878, i64 0
  %.splat1218 = shufflevector <8 x i64> %.splatinsert1217, <8 x i64> poison, <8 x i32> zeroinitializer
  %2880 = add <8 x i64> %2879, %.splat1218
  %.state1219 = load i64, ptr %.slot141, align 4
  %2881 = add i64 0, %.state1219
  %tile_snapshot.spill.load1220 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %2882 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1220, 0
  %2883 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1220, 1
  %.splatinsert1221 = insertelement <8 x i64> poison, i64 %2881, i64 0
  %.splat1222 = shufflevector <8 x i64> %.splatinsert1221, <8 x i64> poison, <8 x i32> zeroinitializer
  %2884 = mul <8 x i64> %.splat1222, splat (i64 32)
  %2885 = add <8 x i64> %2883, %2884
  %2886 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2882, 0
  %2887 = insertvalue { <8 x ptr>, <8 x i64> } %2886, <8 x i64> %2885, 1
  %2888 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2889 = extractvalue { <8 x ptr>, <8 x i64> } %2887, 1
  %2890 = extractelement <8 x ptr> %2888, i32 0
  %2891 = extractelement <8 x i64> %2889, i32 0
  %2892 = sub i64 %2891, 0
  %2893 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2894 = select i1 %2893, i64 %2892, i64 0
  %private.contiguous.address1223 = getelementptr i8, ptr %2890, i64 %2894
  %private.contiguous.load1224 = load <8 x float>, ptr %private.contiguous.address1223, align 4
  %2895 = select <8 x i1> %71, <8 x float> %private.contiguous.load1224, <8 x float> zeroinitializer
  %.state1225 = load <8 x float>, ptr %.slot36, align 32
  %2896 = fdiv <8 x float> %2895, %.state1225
  %2897 = extractvalue { ptr, i64 } %47, 0
  %2898 = mul <8 x i64> %2880, splat (i64 4)
  %2899 = getelementptr i8, ptr %2897, <8 x i64> %2898
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2896, <8 x ptr> align 1 %2899, <8 x i1> %71)
  %.state1226 = load i64, ptr %.slot141, align 4
  %2900 = add i64 %.state1226, 1
  store i64 %2900, ptr %.slot141, align 4
  br label %direct.schedule.83

direct.schedule.85:                               ; preds = %direct.false1208
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true166:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false167:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true176:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false177:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.82

direct.true180:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false181:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true193:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false194:                                  ; preds = %direct.schedule.10
  %2901 = load <8 x float>, ptr %.slot41, align 32
  %2902 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2901
  store <8 x float> %2902, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.true205:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false206:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true218:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false219:                                  ; preds = %direct.schedule.15
  %2903 = load <8 x float>, ptr %.slot45, align 32
  %2904 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2903
  store <8 x float> %2904, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.true230:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false231:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true245:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false246:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true262:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false263:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true279:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false280:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true296:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false297:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true313:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false314:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true330:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false331:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true347:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false348:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true364:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false365:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true381:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false382:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true398:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false399:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true415:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false416:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true432:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false433:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true449:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false450:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true466:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false467:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true483:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false484:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true597:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false598:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true725:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false726:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true739:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false740:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.75

direct.true1172:                                  ; preds = %direct.schedule.76
  br label %direct.schedule.77

direct.false1173:                                 ; preds = %direct.schedule.76
  br label %direct.schedule.78

direct.true1188:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false1189:                                 ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true1207:                                  ; preds = %direct.schedule.83
  br label %direct.schedule.84

direct.false1208:                                 ; preds = %direct.schedule.83
  br label %direct.schedule.85
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #3 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #4

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(write) }

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
BUILD = Path('/tmp/luisa-next-integration.roZbN8/build')
RUNNER = ROOT / 'scripts/benchmark/tile_torch/native_tile.py'
CASES = [('decode', (1, 8, 2, 1, 2053, 80, 96), (1, 16)),
         ('prefill', (1, 4, 2, 32, 65, 32, 32), (4, 16))]


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def run(command, folder, stem, env=None):
    record = dict(command=command, started=time.time(), environment={k:v for k,v in (env or {}).items() if k.startswith('LUISA_')})
    save(folder/(stem+'.command.json'), record)
    try:
        p = subprocess.run(command, env=env, capture_output=True, timeout=60)
        (folder/(stem+'.stdout')).write_bytes(p.stdout)
        (folder/(stem+'.stderr')).write_bytes(p.stderr)
        record.update(returncode=p.returncode, finished=time.time())
        save(folder/(stem+'.command.json'), record)
        p.check_returncode()
        return p.stdout
    except subprocess.TimeoutExpired as e:
        (folder/(stem+'.stdout')).write_bytes(e.stdout or b'')
        (folder/(stem+'.stderr')).write_bytes(e.stderr or b'')
        record.update(error='timeout', finished=time.time())
        save(folder/(stem+'.command.json'), record)
        raise


def capture():
    for case, dims, block in CASES:
        for packet in ('off','on'):
            for width in (1,2,4):
                name = f'{case}-{packet}-r{width}'
                folder = OUT/name
                folder.mkdir()
                prefix = folder/'output.f32'
                env = {k:v for k,v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_'))}
                env.update(LUISA_TILE_BENCH_XIR_BACKEND='simd', LUISA_TILE_BENCH_ATTENTION_QK='mma',
                           LUISA_TILE_BENCH_ATTENTION_PV='mma', LUISA_TILE_BENCH_XIR_MMA_OUTPUT_BLOCK=str(width),
                           LUISA_TILE_BENCH_DUMP_SOURCE=str(prefix)+'.source.txt', LUISA_SIMD_DUMP_ASSEMBLY_DIR=str(folder/'objects'))
                env['LUISA_SIMD_'+('ENABLE' if packet=='on' else 'DISABLE')+'_FULL_PACKET_SPECIALIZATION']='1'
                m = json.loads(run([str(BUILD/'bin/benchmark_tile_xir'),'llm','attention',','.join(map(str,dims)),
                                    *map(str,block),'3','1','1',str(prefix)],folder,'capture',env))
                assert f'requested_mma_output_block={width};' in m['realization']
                assert f'blocked_mmas={0 if width==1 else 1};' in m['realization']
                run([sys.executable,str(RUNNER),'prepare','--capture-kind','llm','--llvm','/opt/homebrew/opt/llvm/bin',
                     '--prefix',str(prefix),'--log',str(folder/'capture.stdout'),'--objects',str(folder/'objects'),
                     '--output',str(OUT/('prepared-'+name)),'--name',f'r{width}'],folder,'prepare')
                print(name, m['realization'].split('full_packet_specializations=')[-1], flush=True)


def replay():
    record = dict(started=time.time(),load_before=os.getloadavg(),experiments=[])
    for case,dims,block in CASES:
        for packet in ('off','on'):
            for width in (2,4):
                name=f'{case}-{packet}-r{width}'
                run([sys.executable,str(RUNNER),'replay','--prepared',str(OUT/f'prepared-{case}-{packet}-r1/prepared.json'),
                     '--prepared',str(OUT/f'prepared-{name}/prepared.json'),'--output',str(OUT/('replay-'+name)),
                     '--cycles','3','--samples','7','--warmup-ms','30','--target-ms','15'],OUT,'replay-'+name)
                record['experiments'].append(dict(case=case,packet=packet,width=width,dimensions=dims,block=block))
                save(OUT/'replays.json',record)
                print(name,'replayed',flush=True)
    record.update(finished=time.time(),load_after=os.getloadavg())
    save(OUT/'replays.json',record)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('phase',choices=('capture','replay'))
    args=p.parse_args()
    (capture if args.phase=='capture' else replay)()

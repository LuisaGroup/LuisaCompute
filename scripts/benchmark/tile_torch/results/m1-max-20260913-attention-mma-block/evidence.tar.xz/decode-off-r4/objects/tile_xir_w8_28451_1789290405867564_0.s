	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v2, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v2, v4
	cmhi.4s	v1, v2, v3
	uzp1.8h	v17, v1, v0
	umaxv.8h	h5, v17
	fmov	w8, s5
	tbz	w8, #0, LBB0_120
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3232
	mov	x9, #0                          ; =0x0
	ldr	x10, [x1, #136]
	add	x8, x10, #2560
	mov	w11, #5632                      ; =0x1600
	add	x11, x10, x11
	mov	w12, #8704                      ; =0x2200
	add	x12, x10, x12
	mov	w13, #49664                     ; =0xc200
	add	x13, x10, x13
	add	x14, x10, #24, lsl #12          ; =98304
	add	x14, x14, #512
	add	x15, x10, #24, lsl #12          ; =98304
	add	x15, x15, #1536
	ldr	x2, [x0]
	ldr	x16, [x0, #16]
	ldr	w17, [x1]
	ldr	w1, [x1, #36]
	add	w1, w1, w17, lsl #5
	ldr	x17, [x0, #32]
	ldr	x0, [x0, #48]
	str	x0, [sp, #88]                   ; 8-byte Spill
	dup.4s	v5, w1
	add.4s	v6, v5, v4
	add.4s	v5, v5, v3
	and.16b	v16, v1, v5
	and.16b	v7, v0, v6
	ushll2.2d	v22, v7, #0
	ushll2.2d	v23, v16, #0
	ushll.2d	v25, v7, #0
	ushll.2d	v27, v16, #0
	movi.4s	v6, #80
	umull2.2d	v5, v7, v6
	umull2.2d	v6, v16, v6
	movi.2s	v18, #80
	umull.2d	v7, v7, v18
	umull.2d	v16, v16, v18
Lloh4:
	adrp	x0, lCPI0_2@PAGE
Lloh5:
	ldr	q18, [x0, lCPI0_2@PAGEOFF]
	and.16b	v17, v17, v18
	addv.8h	h24, v17
	fmov	w0, s24
	dup.2d	v17, x2
	b	LBB0_3
LBB0_2:                                 ; %else297
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x10, x9, lsl #5
	ldp	q20, q21, [x1]
	bif.16b	v19, v21, v0
	bif.16b	v18, v20, v1
	stp	q18, q19, [x1]
	add	x9, x9, #1
	cmp	x9, #80
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v20, x9
	add.2d	v18, v20, v16
	shl.2d	v18, v18, #2
	add.2d	v21, v17, v18
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w0, #0, LBB0_11
; %bb.4:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d21
	ldr	s18, [x1]
	and	w1, w0, #0xff
	tbnz	w1, #1, LBB0_12
LBB0_5:                                 ; %else279
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v6
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w1, #2, LBB0_13
LBB0_6:                                 ; %cond.load281
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d21
	ld1.s	{ v18 }[2], [x2]
	tbnz	w1, #3, LBB0_14
LBB0_7:                                 ; %else285
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v21, v20, v7
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w1, #4, LBB0_15
LBB0_8:                                 ; %cond.load287
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d21
	ld1.s	{ v19 }[0], [x2]
	tbnz	w1, #5, LBB0_16
LBB0_9:                                 ; %else291
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v20, v20, v5
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbz	w1, #6, LBB0_17
LBB0_10:                                ; %cond.load293
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x2, d20
	ld1.s	{ v19 }[2], [x2]
	tbz	w1, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w1, w0, #0xff
	tbz	w1, #1, LBB0_5
LBB0_12:                                ; %cond.load278
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v18 }[1], [x2]
	add.2d	v21, v20, v6
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w1, #2, LBB0_6
LBB0_13:                                ; %else282
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #3, LBB0_7
LBB0_14:                                ; %cond.load284
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v18 }[3], [x2]
	add.2d	v21, v20, v7
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w1, #4, LBB0_8
LBB0_15:                                ; %else288
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #5, LBB0_9
LBB0_16:                                ; %cond.load290
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x2, v21[1]
	ld1.s	{ v19 }[1], [x2]
	add.2d	v20, v20, v5
	shl.2d	v20, v20, #2
	add.2d	v20, v17, v20
	tbnz	w1, #6, LBB0_10
LBB0_17:                                ; %else294
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #7, LBB0_2
LBB0_18:                                ; %cond.load296
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v20[1]
	ld1.s	{ v19 }[3], [x1]
	b	LBB0_2
LBB0_19:                                ; %direct.true166.preheader
	mov	x9, #0                          ; =0x0
	cmhs.4s	v21, v4, v2
	cmhs.4s	v26, v3, v2
LBB0_20:                                ; %direct.true166
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, x8, x9
	ldp	q2, q3, [x0]
	and.16b	v3, v21, v3
	and.16b	v2, v26, v2
	stp	q2, q3, [x0]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false167
	mov	x0, #0                          ; =0x0
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	sshll2.2d	v9, v1, #0
	sshll2.2d	v7, v0, #0
	stp	q27, q25, [sp, #16]             ; 32-byte Folded Spill
	ushr.2d	v4, v27, #2
	stp	q23, q22, [sp, #48]             ; 32-byte Folded Spill
	ushr.2d	v5, v23, #2
	ushr.2d	v6, v25, #2
	mov.16b	v25, v7
	ushr.2d	v7, v22, #2
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q16, [x9, lCPI0_6@PAGEOFF]
	str	q16, [sp, #1824]                ; 16-byte Spill
	and.16b	v8, v2, v16
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v16, w9
	and.16b	v17, v0, v16
	str	q17, [sp, #2576]                ; 16-byte Spill
	mov.d	x9, v7[1]
	mov	w1, #2053                       ; =0x805
	mul	x9, x9, x1
	fmov	x2, d7
	mul	x2, x2, x1
	fmov	d7, x2
	mov.d	v7[1], x9
	mov.d	x9, v6[1]
	mul	x9, x9, x1
	fmov	x2, d6
	mul	x2, x2, x1
	fmov	d6, x2
	mov.d	v6[1], x9
	str	q16, [sp, #352]                 ; 16-byte Spill
	and.16b	v16, v1, v16
	str	q16, [sp, #2560]                ; 16-byte Spill
	mov.d	x9, v5[1]
	mul	x9, x9, x1
	fmov	x2, d5
	mul	x2, x2, x1
	fmov	d5, x2
	mov.d	v5[1], x9
	mov.d	x9, v4[1]
	mul	x9, x9, x1
	fmov	x2, d4
	mul	x1, x2, x1
	fmov	d4, x1
	mov.d	v4[1], x9
	and.16b	v17, v2, v4
	and.16b	v10, v9, v5
	and.16b	v4, v3, v6
	and.16b	v2, v25, v7
	str	q2, [sp, #3152]                 ; 16-byte Spill
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	stp	q2, q4, [sp, #288]              ; 32-byte Folded Spill
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #2896]                 ; 16-byte Spill
	str	q2, [sp, #1808]                 ; 16-byte Spill
	str	q2, [sp, #1792]                 ; 16-byte Spill
	str	q2, [sp, #1776]                 ; 16-byte Spill
	movi.2d	v18, #0000000000000000
	movi.2d	v15, #0000000000000000
	str	q2, [sp, #2624]                 ; 16-byte Spill
	mov	w9, #52736                      ; =0xce00
	add	x1, x10, x9
	str	q2, [sp, #2592]                 ; 16-byte Spill
	movi.2d	v31, #0000000000000000
	movi.2d	v5, #0000000000000000
Lloh8:
	adrp	x9, lCPI0_3@PAGE
Lloh9:
	ldr	q2, [x9, lCPI0_3@PAGEOFF]
	str	q2, [sp, #1760]                 ; 16-byte Spill
Lloh10:
	adrp	x9, lCPI0_4@PAGE
Lloh11:
	ldr	q2, [x9, lCPI0_4@PAGEOFF]
	str	q2, [sp, #1744]                 ; 16-byte Spill
Lloh12:
	adrp	x9, lCPI0_5@PAGE
Lloh13:
	ldr	q2, [x9, lCPI0_5@PAGEOFF]
	str	q2, [sp, #1728]                 ; 16-byte Spill
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #2880]                 ; 16-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #512
	str	x9, [sp, #280]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #544
	str	x9, [sp, #272]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #576
	str	x9, [sp, #264]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #608
	str	x9, [sp, #256]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #640
	str	x9, [sp, #248]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #672
	str	x9, [sp, #240]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #704
	str	x9, [sp, #232]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #736
	str	x9, [sp, #224]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #768
	str	x9, [sp, #216]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #800
	str	x9, [sp, #208]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #832
	str	x9, [sp, #200]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #864
	str	x9, [sp, #192]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #896
	str	x9, [sp, #184]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #928
	str	x9, [sp, #176]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #960
	str	x9, [sp, #168]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #992
	str	x9, [sp, #160]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1024
	str	x9, [sp, #152]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1056
	str	x9, [sp, #144]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1088
	str	x9, [sp, #136]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1120
	str	x9, [sp, #128]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1152
	str	x9, [sp, #120]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1184
	str	x9, [sp, #112]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1216
	str	x9, [sp, #104]                  ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x9, x9, #1248
	str	x9, [sp, #96]                   ; 8-byte Spill
	add	x9, x10, #24, lsl #12           ; =98304
	add	x19, x9, #1280
	add	x9, x10, #24, lsl #12           ; =98304
	add	x20, x9, #1312
	add	x9, x10, #24, lsl #12           ; =98304
	add	x21, x9, #1344
	add	x9, x10, #24, lsl #12           ; =98304
	add	x22, x9, #1376
	add	x9, x10, #24, lsl #12           ; =98304
	add	x23, x9, #1408
	add	x9, x10, #24, lsl #12           ; =98304
	add	x24, x9, #1440
	add	x9, x10, #24, lsl #12           ; =98304
	add	x25, x9, #1472
	add	x9, x10, #24, lsl #12           ; =98304
	add	x26, x9, #1504
	mov	w27, #52429                     ; =0xcccd
	mov	w28, #80                        ; =0x50
	mov	w30, #43691                     ; =0xaaab
	mov	w9, #96                         ; =0x60
	movi.2d	v28, #0000000000000000
	movi.2d	v30, #0000000000000000
	str	q2, [sp, #1536]                 ; 16-byte Spill
	str	q2, [sp, #1520]                 ; 16-byte Spill
	str	q2, [sp, #1504]                 ; 16-byte Spill
	str	q2, [sp, #1488]                 ; 16-byte Spill
	str	q2, [sp, #1472]                 ; 16-byte Spill
	str	q2, [sp, #1456]                 ; 16-byte Spill
	movi.2d	v3, #0000000000000000
	str	q2, [sp, #2864]                 ; 16-byte Spill
	str	q2, [sp, #2848]                 ; 16-byte Spill
	str	q2, [sp, #2832]                 ; 16-byte Spill
	str	q2, [sp, #2816]                 ; 16-byte Spill
	str	q2, [sp, #2800]                 ; 16-byte Spill
	str	q2, [sp, #2784]                 ; 16-byte Spill
	str	q2, [sp, #2768]                 ; 16-byte Spill
	str	q2, [sp, #2752]                 ; 16-byte Spill
	str	q2, [sp, #2736]                 ; 16-byte Spill
	str	q2, [sp, #2720]                 ; 16-byte Spill
	str	q2, [sp, #2704]                 ; 16-byte Spill
	str	q2, [sp, #2688]                 ; 16-byte Spill
	str	q2, [sp, #2672]                 ; 16-byte Spill
	str	q2, [sp, #2656]                 ; 16-byte Spill
	str	q2, [sp, #3200]                 ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	str	q2, [sp, #2640]                 ; 16-byte Spill
	movi.2d	v27, #0000000000000000
	str	q2, [sp, #1712]                 ; 16-byte Spill
	str	q2, [sp, #1696]                 ; 16-byte Spill
	str	q2, [sp, #1680]                 ; 16-byte Spill
	str	q2, [sp, #1664]                 ; 16-byte Spill
	str	q2, [sp, #2528]                 ; 16-byte Spill
	str	q2, [sp, #2512]                 ; 16-byte Spill
	str	q2, [sp, #2496]                 ; 16-byte Spill
	str	q2, [sp, #2480]                 ; 16-byte Spill
	str	q2, [sp, #2464]                 ; 16-byte Spill
	str	q2, [sp, #2448]                 ; 16-byte Spill
	str	q2, [sp, #2432]                 ; 16-byte Spill
	str	q2, [sp, #2416]                 ; 16-byte Spill
	movi.2d	v20, #0000000000000000
	str	q2, [sp, #2400]                 ; 16-byte Spill
	movi.2d	v14, #0000000000000000
	str	q2, [sp, #2384]                 ; 16-byte Spill
	movi.2d	v12, #0000000000000000
	str	q2, [sp, #2368]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	str	q2, [sp, #2352]                 ; 16-byte Spill
	movi.2d	v22, #0000000000000000
	str	q2, [sp, #2336]                 ; 16-byte Spill
	str	q2, [sp, #2320]                 ; 16-byte Spill
	str	q2, [sp, #2304]                 ; 16-byte Spill
	str	q2, [sp, #2288]                 ; 16-byte Spill
	str	q2, [sp, #2272]                 ; 16-byte Spill
	str	q2, [sp, #2256]                 ; 16-byte Spill
	str	q2, [sp, #2240]                 ; 16-byte Spill
	str	q2, [sp, #2224]                 ; 16-byte Spill
	str	q2, [sp, #2208]                 ; 16-byte Spill
	movi.2d	v11, #0000000000000000
	str	q2, [sp, #2192]                 ; 16-byte Spill
	str	q2, [sp, #2176]                 ; 16-byte Spill
	str	q2, [sp, #2160]                 ; 16-byte Spill
	str	q2, [sp, #3136]                 ; 16-byte Spill
	str	q2, [sp, #3120]                 ; 16-byte Spill
	str	q2, [sp, #3104]                 ; 16-byte Spill
	str	q2, [sp, #3088]                 ; 16-byte Spill
	str	q2, [sp, #3072]                 ; 16-byte Spill
	str	q2, [sp, #3184]                 ; 16-byte Spill
	str	q2, [sp, #2608]                 ; 16-byte Spill
	str	q2, [sp, #1648]                 ; 16-byte Spill
	str	q2, [sp, #1632]                 ; 16-byte Spill
	str	q2, [sp, #1616]                 ; 16-byte Spill
	str	q2, [sp, #3056]                 ; 16-byte Spill
	str	q2, [sp, #3040]                 ; 16-byte Spill
	str	q2, [sp, #3024]                 ; 16-byte Spill
	str	q2, [sp, #3008]                 ; 16-byte Spill
	str	q2, [sp, #2992]                 ; 16-byte Spill
	str	q2, [sp, #3168]                 ; 16-byte Spill
	str	q2, [sp, #1600]                 ; 16-byte Spill
	str	q2, [sp, #1584]                 ; 16-byte Spill
	str	q2, [sp, #1568]                 ; 16-byte Spill
	str	q2, [sp, #1552]                 ; 16-byte Spill
	movi.2d	v23, #0000000000000000
	movi.2d	v29, #0000000000000000
	stp	q21, q24, [sp, #432]            ; 32-byte Folded Spill
	stp	q9, q26, [sp, #400]             ; 32-byte Folded Spill
	stp	q8, q25, [sp, #368]             ; 32-byte Folded Spill
	stp	q10, q17, [sp, #320]            ; 32-byte Folded Spill
LBB0_22:                                ; %direct.true176
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;     Child Loop BB0_65 Depth 2
                                        ;     Child Loop BB0_67 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_71 Depth 2
                                        ;     Child Loop BB0_73 Depth 2
                                        ;     Child Loop BB0_75 Depth 2
                                        ;     Child Loop BB0_77 Depth 2
                                        ;     Child Loop BB0_79 Depth 2
                                        ;     Child Loop BB0_81 Depth 2
                                        ;     Child Loop BB0_83 Depth 2
                                        ;     Child Loop BB0_85 Depth 2
                                        ;     Child Loop BB0_87 Depth 2
                                        ;     Child Loop BB0_89 Depth 2
                                        ;     Child Loop BB0_91 Depth 2
                                        ;     Child Loop BB0_93 Depth 2
                                        ;     Child Loop BB0_95 Depth 2
                                        ;     Child Loop BB0_97 Depth 2
                                        ;     Child Loop BB0_99 Depth 2
	str	q27, [sp, #2912]                ; 16-byte Spill
	str	q5, [sp, #2928]                 ; 16-byte Spill
	str	q31, [sp, #2944]                ; 16-byte Spill
	str	q30, [sp, #1360]                ; 16-byte Spill
	str	q28, [sp, #1376]                ; 16-byte Spill
	str	q4, [sp, #2960]                 ; 16-byte Spill
	str	q3, [sp, #2976]                 ; 16-byte Spill
	str	q29, [sp, #1392]                ; 16-byte Spill
	str	q23, [sp, #1408]                ; 16-byte Spill
	str	q15, [sp, #1424]                ; 16-byte Spill
	str	q18, [sp, #1440]                ; 16-byte Spill
	mov	x3, #0                          ; =0x0
	lsl	x2, x0, #4
	ldr	q2, [sp, #304]                  ; 16-byte Reload
	ldr	q6, [sp, #1680]                 ; 16-byte Reload
	ldr	q15, [sp, #2464]                ; 16-byte Reload
	ldr	q28, [sp, #2432]                ; 16-byte Reload
	ldr	q18, [sp, #2320]                ; 16-byte Reload
	ldr	q3, [sp, #2288]                 ; 16-byte Reload
	ldr	q4, [sp, #2256]                 ; 16-byte Reload
	ldr	q5, [sp, #2224]                 ; 16-byte Reload
	ldr	q27, [sp, #2160]                ; 16-byte Reload
	b	LBB0_24
LBB0_23:                                ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_24 Depth=2
	str	q31, [sp, #2992]                ; 16-byte Spill
	str	q30, [sp, #3008]                ; 16-byte Spill
	str	q29, [sp, #3024]                ; 16-byte Spill
	ldr	q16, [sp, #3040]                ; 16-byte Reload
	bit.16b	v16, v19, v0
	str	q16, [sp, #3040]                ; 16-byte Spill
	ldr	q16, [sp, #3056]                ; 16-byte Reload
	bit.16b	v16, v7, v1
	str	q16, [sp, #3056]                ; 16-byte Spill
	add	x4, x12, x3, lsl #5
	ldp	q16, q23, [x4]
	bif.16b	v19, v23, v0
	bif.16b	v7, v16, v1
	stp	q7, q19, [x4]
	add	x3, x3, #1
	cmp	x3, #1280
	b.eq	LBB0_41
LBB0_24:                                ; %direct.true180
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w4, w3, #0xffff
	mul	w4, w4, w27
	lsr	w5, w4, #22
	add	x4, x2, x5
	dup.2d	v7, x4
	add.2d	v16, v7, v10
	add.2d	v19, v7, v2
	ldr	q23, [sp, #3152]                ; 16-byte Reload
	add.2d	v23, v7, v23
	mov.d	x6, v23[1]
	fmov	x7, d23
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	fmov	d23, x7
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	mov.d	v23[1], x6
	mov.d	x6, v19[1]
	fmov	x7, d19
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	fmov	d19, x7
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	mov.d	v19[1], x6
	mov.d	x6, v16[1]
	add.2d	v7, v7, v17
	fmov	x7, d16
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	fmov	d16, x7
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	mov.d	v16[1], x6
	mov.d	x6, v7[1]
	fmov	x7, d7
	add	x7, x7, x7, lsl #2
	lsl	x7, x7, #4
	fmov	d7, x7
	sshll.2d	v29, v1, #0
	msub	w5, w5, w28, w3
	and	x5, x5, #0xffff
	add	x6, x6, x6, lsl #2
	lsl	x6, x6, #4
	mov.d	v7[1], x6
	dup.2d	v30, x5
	sshll.2d	v31, v0, #0
	add.2d	v7, v7, v30
	add.2d	v16, v16, v30
	add.2d	v19, v19, v30
	add.2d	v23, v23, v30
	ldr	q30, [sp, #3168]                ; 16-byte Reload
	bit.16b	v30, v23, v25
	str	q30, [sp, #3168]                ; 16-byte Spill
	ldr	q23, [sp, #2992]                ; 16-byte Reload
	bsl.16b	v31, v19, v23
	ldr	q30, [sp, #3008]                ; 16-byte Reload
	bit.16b	v30, v16, v9
	ldr	q16, [sp, #3024]                ; 16-byte Reload
	bsl.16b	v29, v7, v16
	movi.2d	v7, #0000000000000000
	movi.2d	v19, #0000000000000000
	cmp	x4, #2052
	b.hi	LBB0_23
; %bb.25:                               ; %direct.true193
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	w4, s24
	shl.2d	v7, v29, #2
	dup.2d	v23, x16
	add.2d	v16, v23, v7
	movi.2d	v7, #0000000000000000
	tbz	w4, #0, LBB0_33
; %bb.26:                               ; %cond.load300
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x5, d16
	ldr	s7, [x5]
	and	w4, w4, #0xff
	tbnz	w4, #1, LBB0_34
LBB0_27:                                ; %else310
                                        ;   in Loop: Header=BB0_24 Depth=2
	shl.2d	v16, v30, #2
	add.2d	v16, v23, v16
	tbz	w4, #2, LBB0_35
LBB0_28:                                ; %cond.load312
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x5, d16
	ld1.s	{ v7 }[2], [x5]
	tbnz	w4, #3, LBB0_36
LBB0_29:                                ; %else322
                                        ;   in Loop: Header=BB0_24 Depth=2
	shl.2d	v16, v31, #2
	add.2d	v16, v23, v16
	tbz	w4, #4, LBB0_37
LBB0_30:                                ; %cond.load324
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x5, d16
	ld1.s	{ v19 }[0], [x5]
	tbnz	w4, #5, LBB0_38
LBB0_31:                                ; %else334
                                        ;   in Loop: Header=BB0_24 Depth=2
	ldr	q16, [sp, #3168]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v16, v23, v16
	tbz	w4, #6, LBB0_39
LBB0_32:                                ; %cond.load336
                                        ;   in Loop: Header=BB0_24 Depth=2
	fmov	x5, d16
	ld1.s	{ v19 }[2], [x5]
	tbz	w4, #7, LBB0_23
	b	LBB0_40
LBB0_33:                                ; %else304
                                        ;   in Loop: Header=BB0_24 Depth=2
	and	w4, w4, #0xff
	tbz	w4, #1, LBB0_27
LBB0_34:                                ; %cond.load306
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x5, v16[1]
	ld1.s	{ v7 }[1], [x5]
	shl.2d	v16, v30, #2
	add.2d	v16, v23, v16
	tbnz	w4, #2, LBB0_28
LBB0_35:                                ; %else316
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w4, #3, LBB0_29
LBB0_36:                                ; %cond.load318
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x5, v16[1]
	ld1.s	{ v7 }[3], [x5]
	shl.2d	v16, v31, #2
	add.2d	v16, v23, v16
	tbnz	w4, #4, LBB0_30
LBB0_37:                                ; %else328
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w4, #5, LBB0_31
LBB0_38:                                ; %cond.load330
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x5, v16[1]
	ld1.s	{ v19 }[1], [x5]
	ldr	q16, [sp, #3168]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v16, v23, v16
	tbnz	w4, #6, LBB0_32
LBB0_39:                                ; %else340
                                        ;   in Loop: Header=BB0_24 Depth=2
	tbz	w4, #7, LBB0_23
LBB0_40:                                ; %cond.load342
                                        ;   in Loop: Header=BB0_24 Depth=2
	mov.d	x4, v16[1]
	ld1.s	{ v19 }[3], [x4]
	b	LBB0_23
LBB0_41:                                ; %direct.true205.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x3, #0                          ; =0x0
	b	LBB0_43
LBB0_42:                                ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_43 Depth=2
	str	q31, [sp, #3072]                ; 16-byte Spill
	str	q30, [sp, #3088]                ; 16-byte Spill
	str	q29, [sp, #3104]                ; 16-byte Spill
	ldr	q16, [sp, #3120]                ; 16-byte Reload
	bit.16b	v16, v19, v0
	str	q16, [sp, #3120]                ; 16-byte Spill
	ldr	q16, [sp, #3136]                ; 16-byte Reload
	bit.16b	v16, v7, v1
	str	q16, [sp, #3136]                ; 16-byte Spill
	add	x4, x13, x3, lsl #5
	ldp	q16, q23, [x4]
	bif.16b	v19, v23, v0
	bif.16b	v7, v16, v1
	stp	q7, q19, [x4]
	add	x3, x3, #1
	cmp	x3, #1536
	b.eq	LBB0_60
LBB0_43:                                ; %direct.true205
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w4, w3, #0xffff
	mul	w4, w4, w30
	lsr	w5, w4, #22
	add	x4, x2, x5
	dup.2d	v7, x4
	add.2d	v16, v7, v10
	add.2d	v19, v7, v2
	ldr	q23, [sp, #3152]                ; 16-byte Reload
	add.2d	v23, v7, v23
	mov.d	x6, v23[1]
	fmov	x7, d23
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	fmov	d23, x7
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	mov.d	v23[1], x6
	mov.d	x6, v19[1]
	fmov	x7, d19
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	fmov	d19, x7
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	mov.d	v19[1], x6
	mov.d	x6, v16[1]
	add.2d	v7, v7, v17
	fmov	x7, d16
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	fmov	d16, x7
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	mov.d	v16[1], x6
	mov.d	x6, v7[1]
	fmov	x7, d7
	add	x7, x7, x7, lsl #1
	lsl	x7, x7, #5
	fmov	d7, x7
	sshll.2d	v29, v1, #0
	msub	w5, w5, w9, w3
	and	x5, x5, #0xffff
	add	x6, x6, x6, lsl #1
	lsl	x6, x6, #5
	mov.d	v7[1], x6
	dup.2d	v30, x5
	sshll.2d	v31, v0, #0
	add.2d	v7, v7, v30
	add.2d	v16, v16, v30
	add.2d	v19, v19, v30
	add.2d	v23, v23, v30
	ldr	q30, [sp, #3184]                ; 16-byte Reload
	bit.16b	v30, v23, v25
	str	q30, [sp, #3184]                ; 16-byte Spill
	ldr	q23, [sp, #3072]                ; 16-byte Reload
	bsl.16b	v31, v19, v23
	ldr	q30, [sp, #3088]                ; 16-byte Reload
	bit.16b	v30, v16, v9
	ldr	q16, [sp, #3104]                ; 16-byte Reload
	bsl.16b	v29, v7, v16
	movi.2d	v7, #0000000000000000
	movi.2d	v19, #0000000000000000
	cmp	x4, #2053
	b.hs	LBB0_42
; %bb.44:                               ; %direct.true218
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	w4, s24
	shl.2d	v7, v29, #2
	dup.2d	v23, x17
	add.2d	v16, v23, v7
	movi.2d	v7, #0000000000000000
	tbz	w4, #0, LBB0_52
; %bb.45:                               ; %cond.load349
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x5, d16
	ldr	s7, [x5]
	and	w4, w4, #0xff
	tbnz	w4, #1, LBB0_53
LBB0_46:                                ; %else359
                                        ;   in Loop: Header=BB0_43 Depth=2
	shl.2d	v16, v30, #2
	add.2d	v16, v23, v16
	tbz	w4, #2, LBB0_54
LBB0_47:                                ; %cond.load361
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x5, d16
	ld1.s	{ v7 }[2], [x5]
	tbnz	w4, #3, LBB0_55
LBB0_48:                                ; %else371
                                        ;   in Loop: Header=BB0_43 Depth=2
	shl.2d	v16, v31, #2
	add.2d	v16, v23, v16
	tbz	w4, #4, LBB0_56
LBB0_49:                                ; %cond.load373
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x5, d16
	ld1.s	{ v19 }[0], [x5]
	tbnz	w4, #5, LBB0_57
LBB0_50:                                ; %else383
                                        ;   in Loop: Header=BB0_43 Depth=2
	ldr	q16, [sp, #3184]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v16, v23, v16
	tbz	w4, #6, LBB0_58
LBB0_51:                                ; %cond.load385
                                        ;   in Loop: Header=BB0_43 Depth=2
	fmov	x5, d16
	ld1.s	{ v19 }[2], [x5]
	tbz	w4, #7, LBB0_42
	b	LBB0_59
LBB0_52:                                ; %else353
                                        ;   in Loop: Header=BB0_43 Depth=2
	and	w4, w4, #0xff
	tbz	w4, #1, LBB0_46
LBB0_53:                                ; %cond.load355
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x5, v16[1]
	ld1.s	{ v7 }[1], [x5]
	shl.2d	v16, v30, #2
	add.2d	v16, v23, v16
	tbnz	w4, #2, LBB0_47
LBB0_54:                                ; %else365
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w4, #3, LBB0_48
LBB0_55:                                ; %cond.load367
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x5, v16[1]
	ld1.s	{ v7 }[3], [x5]
	shl.2d	v16, v31, #2
	add.2d	v16, v23, v16
	tbnz	w4, #4, LBB0_49
LBB0_56:                                ; %else377
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w4, #5, LBB0_50
LBB0_57:                                ; %cond.load379
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x5, v16[1]
	ld1.s	{ v19 }[1], [x5]
	ldr	q16, [sp, #3184]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v16, v23, v16
	tbnz	w4, #6, LBB0_51
LBB0_58:                                ; %else389
                                        ;   in Loop: Header=BB0_43 Depth=2
	tbz	w4, #7, LBB0_42
LBB0_59:                                ; %cond.load391
                                        ;   in Loop: Header=BB0_43 Depth=2
	mov.d	x4, v16[1]
	ld1.s	{ v19 }[3], [x4]
	b	LBB0_42
LBB0_60:                                ; %direct.false206
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x2, #0                          ; =0x0
	sshll.2d	v7, v1, #0
	sshll.2d	v16, v0, #0
	ldr	q2, [sp, #1760]                 ; 16-byte Reload
	ldr	q19, [sp, #1552]                ; 16-byte Reload
	bit.16b	v19, v2, v25
	str	q19, [sp, #1552]                ; 16-byte Spill
	ldr	q2, [sp, #1744]                 ; 16-byte Reload
	ldr	q19, [sp, #1584]                ; 16-byte Reload
	bit.16b	v19, v2, v9
	str	q19, [sp, #1584]                ; 16-byte Spill
	ldr	q2, [sp, #1728]                 ; 16-byte Reload
	ldr	q19, [sp, #1568]                ; 16-byte Reload
	bit.16b	v19, v2, v16
	str	q19, [sp, #1568]                ; 16-byte Spill
	ldr	q29, [sp, #1600]                ; 16-byte Reload
	ldr	q2, [sp, #1824]                 ; 16-byte Reload
	bit.16b	v29, v2, v7
	bic.16b	v27, v27, v0
	ldr	q2, [sp, #2176]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
LBB0_61:                                ; %direct.true230
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d7, x2
	orr.16b	v16, v7, v8
	fmov	x3, d16
	add	x3, x10, x3
	ldp	q16, q19, [x3]
	orr.16b	v7, v7, v29
	fmov	x3, d7
	add	x3, x12, x3
	ldp	q7, q23, [x3]
	fmul.4s	v19, v19, v23
	fmul.4s	v7, v16, v7
	fadd.4s	v7, v2, v7
	fadd.4s	v16, v27, v19
	bit.16b	v27, v16, v0
	bit.16b	v2, v7, v1
	add	x2, x2, #32
	cmp	x2, #2560
	b.ne	LBB0_61
; %bb.62:                               ; %direct.false231
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q29, [sp, #1600]                ; 16-byte Spill
	str	q27, [sp, #2160]                ; 16-byte Spill
	str	q2, [sp, #2176]                 ; 16-byte Spill
	ldr	q27, [sp, #2192]                ; 16-byte Reload
	and.16b	v27, v21, v27
	and.16b	v11, v26, v11
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q2, [sp, #1664]                 ; 16-byte Reload
	ldr	q29, [sp, #2528]                ; 16-byte Reload
	ldr	q30, [sp, #2512]                ; 16-byte Reload
	ldr	q31, [sp, #2496]                ; 16-byte Reload
LBB0_63:                                ; %direct.true245
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #11264]
	ldr	q23, [x2, #11280]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v11, v7
	fadd.4s	v16, v27, v16
	bit.16b	v27, v16, v0
	bit.16b	v11, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_63
; %bb.64:                               ; %direct.false246
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q27, [sp, #2192]                ; 16-byte Spill
	str	q11, [sp, #2064]                ; 16-byte Spill
	ldr	q11, [sp, #2208]                ; 16-byte Reload
	and.16b	v11, v21, v11
	and.16b	v5, v26, v5
	mov	x2, x10
	mov	w3, #80                         ; =0x50
LBB0_65:                                ; %direct.true262
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #13824]
	ldr	q23, [x2, #13840]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v5, v7
	fadd.4s	v16, v11, v16
	bit.16b	v11, v16, v0
	bit.16b	v5, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_65
; %bb.66:                               ; %direct.false263
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q11, [sp, #2208]                ; 16-byte Spill
	str	q5, [sp, #2224]                 ; 16-byte Spill
	ldr	q5, [sp, #2240]                 ; 16-byte Reload
	and.16b	v5, v21, v5
	and.16b	v4, v26, v4
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q27, [sp, #2160]                ; 16-byte Reload
LBB0_67:                                ; %direct.true279
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #16384]
	ldr	q23, [x2, #16400]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v4, v7
	fadd.4s	v16, v5, v16
	bit.16b	v5, v16, v0
	bit.16b	v4, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_67
; %bb.68:                               ; %direct.false280
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q5, [sp, #2240]                 ; 16-byte Spill
	str	q4, [sp, #2256]                 ; 16-byte Spill
	ldr	q4, [sp, #2272]                 ; 16-byte Reload
	and.16b	v4, v21, v4
	and.16b	v3, v26, v3
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q11, [sp, #2064]                ; 16-byte Reload
LBB0_69:                                ; %direct.true296
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #18944]
	ldr	q23, [x2, #18960]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v3, v7
	fadd.4s	v16, v4, v16
	bit.16b	v4, v16, v0
	bit.16b	v3, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_69
; %bb.70:                               ; %direct.false297
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q4, [sp, #2272]                 ; 16-byte Spill
	str	q3, [sp, #2288]                 ; 16-byte Spill
	ldr	q3, [sp, #2304]                 ; 16-byte Reload
	and.16b	v3, v21, v3
	and.16b	v18, v26, v18
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q5, [sp, #2224]                 ; 16-byte Reload
LBB0_71:                                ; %direct.true313
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #21504]
	ldr	q23, [x2, #21520]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v18, v7
	fadd.4s	v16, v3, v16
	bit.16b	v3, v16, v0
	bit.16b	v18, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_71
; %bb.72:                               ; %direct.false314
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q3, [sp, #2304]                 ; 16-byte Spill
	str	q18, [sp, #2320]                ; 16-byte Spill
	ldr	q18, [sp, #2336]                ; 16-byte Reload
	and.16b	v18, v21, v18
	and.16b	v22, v26, v22
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q4, [sp, #2256]                 ; 16-byte Reload
LBB0_73:                                ; %direct.true330
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #24064]
	ldr	q23, [x2, #24080]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v22, v7
	fadd.4s	v16, v18, v16
	bit.16b	v18, v16, v0
	bit.16b	v22, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_73
; %bb.74:                               ; %direct.false331
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q18, [sp, #2336]                ; 16-byte Spill
	str	q22, [sp, #2080]                ; 16-byte Spill
	ldr	q22, [sp, #2352]                ; 16-byte Reload
	and.16b	v22, v21, v22
	and.16b	v13, v26, v13
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q3, [sp, #2288]                 ; 16-byte Reload
LBB0_75:                                ; %direct.true347
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #26624]
	ldr	q23, [x2, #26640]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v13, v7
	fadd.4s	v16, v22, v16
	bit.16b	v22, v16, v0
	bit.16b	v13, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_75
; %bb.76:                               ; %direct.false348
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q22, [sp, #2352]                ; 16-byte Spill
	str	q13, [sp, #2096]                ; 16-byte Spill
	ldr	q13, [sp, #2368]                ; 16-byte Reload
	and.16b	v13, v21, v13
	and.16b	v12, v26, v12
	mov	x2, x10
	mov	w3, #80                         ; =0x50
LBB0_77:                                ; %direct.true364
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #29184]
	ldr	q23, [x2, #29200]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v12, v7
	fadd.4s	v16, v13, v16
	bit.16b	v13, v16, v0
	bit.16b	v12, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_77
; %bb.78:                               ; %direct.false365
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q13, [sp, #2368]                ; 16-byte Spill
	str	q12, [sp, #2112]                ; 16-byte Spill
	ldr	q12, [sp, #2384]                ; 16-byte Reload
	and.16b	v12, v21, v12
	and.16b	v14, v26, v14
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q18, [sp, #2080]                ; 16-byte Reload
LBB0_79:                                ; %direct.true381
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #31744]
	ldr	q23, [x2, #31760]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v14, v7
	fadd.4s	v16, v12, v16
	bit.16b	v12, v16, v0
	bit.16b	v14, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_79
; %bb.80:                               ; %direct.false382
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q12, [sp, #2384]                ; 16-byte Spill
	str	q14, [sp, #2128]                ; 16-byte Spill
	ldr	q14, [sp, #2400]                ; 16-byte Reload
	and.16b	v14, v21, v14
	and.16b	v20, v26, v20
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q13, [sp, #2096]                ; 16-byte Reload
LBB0_81:                                ; %direct.true398
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #34304]
	ldr	q23, [x2, #34320]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v20, v7
	fadd.4s	v16, v14, v16
	bit.16b	v14, v16, v0
	bit.16b	v20, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_81
; %bb.82:                               ; %direct.false399
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q14, [sp, #2400]                ; 16-byte Spill
	str	q20, [sp, #2144]                ; 16-byte Spill
	ldr	q20, [sp, #2416]                ; 16-byte Reload
	and.16b	v20, v21, v20
	and.16b	v28, v26, v28
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q12, [sp, #2112]                ; 16-byte Reload
LBB0_83:                                ; %direct.true415
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #36864]
	ldr	q23, [x2, #36880]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v28, v7
	fadd.4s	v16, v20, v16
	bit.16b	v20, v16, v0
	bit.16b	v28, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_83
; %bb.84:                               ; %direct.false416
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q20, [sp, #2416]                ; 16-byte Spill
	str	q28, [sp, #2432]                ; 16-byte Spill
	ldr	q28, [sp, #2448]                ; 16-byte Reload
	and.16b	v28, v21, v28
	and.16b	v15, v26, v15
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q14, [sp, #2128]                ; 16-byte Reload
LBB0_85:                                ; %direct.true432
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #39424]
	ldr	q23, [x2, #39440]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v15, v7
	fadd.4s	v16, v28, v16
	bit.16b	v28, v16, v0
	bit.16b	v15, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_85
; %bb.86:                               ; %direct.false433
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q28, [sp, #2448]                ; 16-byte Spill
	str	q15, [sp, #2464]                ; 16-byte Spill
	ldr	q15, [sp, #2480]                ; 16-byte Reload
	and.16b	v15, v21, v15
	and.16b	v31, v26, v31
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q20, [sp, #2144]                ; 16-byte Reload
LBB0_87:                                ; %direct.true449
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #41984]
	ldr	q23, [x2, #42000]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v31, v7
	fadd.4s	v16, v15, v16
	bit.16b	v15, v16, v0
	bit.16b	v31, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_87
; %bb.88:                               ; %direct.false450
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q15, [sp, #2480]                ; 16-byte Spill
	and.16b	v30, v21, v30
	and.16b	v29, v26, v29
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q28, [sp, #2432]                ; 16-byte Reload
LBB0_89:                                ; %direct.true466
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #44544]
	ldr	q23, [x2, #44560]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v29, v7
	fadd.4s	v16, v30, v16
	bit.16b	v30, v16, v0
	bit.16b	v29, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_89
; %bb.90:                               ; %direct.false467
                                        ;   in Loop: Header=BB0_22 Depth=1
	str	q31, [sp, #2496]                ; 16-byte Spill
	str	q30, [sp, #2512]                ; 16-byte Spill
	str	q29, [sp, #2528]                ; 16-byte Spill
	and.16b	v2, v21, v2
	and.16b	v6, v26, v6
	mov	x2, x10
	mov	w3, #80                         ; =0x50
	ldr	q15, [sp, #2464]                ; 16-byte Reload
LBB0_91:                                ; %direct.true483
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q16, [x2]
	ldr	q19, [x2, #47104]
	ldr	q23, [x2, #47120]
	fmul.4s	v16, v16, v23
	fmul.4s	v7, v7, v19
	fadd.4s	v7, v6, v7
	fadd.4s	v16, v2, v16
	bit.16b	v2, v16, v0
	bit.16b	v6, v7, v1
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_91
; %bb.92:                               ; %direct.false484
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x2, #0                          ; =0x0
	mov	w3, #63790                      ; =0xf92e
	movk	w3, #15844, lsl #16
	dup.4s	v7, w3
	cmp	x0, #128
	cset	w3, lo
	dup.4h	v16, w3
	ldr	q17, [sp, #2176]                ; 16-byte Reload
	fmul.4s	v21, v17, v7
	fmul.4s	v17, v27, v7
	ldp	x4, x5, [sp, #272]              ; 16-byte Folded Reload
	ldp	q30, q31, [x5]
	fmul.4s	v19, v11, v7
	mov.16b	v11, v17
	ldr	q17, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v17, v17, v7
	bit.16b	v31, v11, v0
	mov.16b	v22, v21
	bit.16b	v30, v21, v1
	stp	q30, q31, [x5]
	fmul.4s	v24, v5, v7
	ldr	q5, [sp, #2208]                 ; 16-byte Reload
	fmul.4s	v21, v5, v7
	fmul.4s	v27, v4, v7
	ldr	q4, [sp, #2240]                 ; 16-byte Reload
	fmul.4s	v26, v4, v7
	ldp	q30, q31, [x4]
	fmul.4s	v5, v3, v7
	str	q17, [sp, #2016]                ; 16-byte Spill
	bit.16b	v31, v17, v0
	str	q19, [sp, #2000]                ; 16-byte Spill
	bit.16b	v30, v19, v1
	stp	q30, q31, [x4]
	ldr	q3, [sp, #2272]                 ; 16-byte Reload
	fmul.4s	v4, v3, v7
	ldr	q3, [sp, #2304]                 ; 16-byte Reload
	fmul.4s	v30, v3, v7
	ldr	q3, [sp, #2320]                 ; 16-byte Reload
	fmul.4s	v31, v3, v7
	ldp	x4, x6, [sp, #256]              ; 16-byte Folded Reload
	ldp	q8, q19, [x6]
	ldr	q17, [sp, #2336]                ; 16-byte Reload
	fmul.4s	v23, v17, v7
	str	q21, [sp, #1936]                ; 16-byte Spill
	bit.16b	v19, v21, v0
	str	q24, [sp, #1920]                ; 16-byte Spill
	bit.16b	v8, v24, v1
	stp	q8, q19, [x6]
	fmul.4s	v19, v18, v7
	ldr	q17, [sp, #2352]                ; 16-byte Reload
	fmul.4s	v8, v17, v7
	fmul.4s	v29, v13, v7
	mov.16b	v24, v2
	ldp	q21, q2, [x4]
	ldr	q17, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v13, v17, v7
	str	q26, [sp, #1840]                ; 16-byte Spill
	bit.16b	v2, v26, v0
	str	q27, [sp, #1312]                ; 16-byte Spill
	bit.16b	v21, v27, v1
	stp	q21, q2, [x4]
	fmul.4s	v21, v12, v7
	fmul.4s	v18, v14, v7
	ldr	q2, [sp, #2384]                 ; 16-byte Reload
	fmul.4s	v26, v2, v7
	ldp	x4, x7, [sp, #240]              ; 16-byte Folded Reload
	ldp	q2, q10, [x7]
	ushll.4s	v16, v16, #0
	str	q4, [sp, #1264]                 ; 16-byte Spill
	bit.16b	v10, v4, v0
	str	q5, [sp, #1248]                 ; 16-byte Spill
	bit.16b	v2, v5, v1
	stp	q2, q10, [x7]
	shl.4s	v2, v16, #31
	cmlt.4s	v16, v2, #0
	ldr	q17, [sp, #352]                 ; 16-byte Reload
	mov.16b	v3, v16
	bsl.16b	v3, v31, v17
	ldp	q2, q31, [x4]
	mov.16b	v4, v16
	bsl.16b	v4, v30, v17
	str	q4, [sp, #1152]                 ; 16-byte Spill
	mov.16b	v30, v0
	bsl.16b	v30, v4, v31
	str	q3, [sp, #1168]                 ; 16-byte Spill
	bit.16b	v2, v3, v1
	stp	q2, q30, [x4]
	fmul.4s	v5, v20, v7
	ldr	q2, [sp, #2400]                 ; 16-byte Reload
	fmul.4s	v30, v2, v7
	mov.16b	v2, v16
	bsl.16b	v2, v19, v17
	ldr	x4, [sp, #232]                  ; 8-byte Reload
	ldp	q19, q31, [x4]
	mov.16b	v3, v16
	bsl.16b	v3, v23, v17
	str	q3, [sp, #1072]                 ; 16-byte Spill
	mov.16b	v23, v0
	bsl.16b	v23, v3, v31
	str	q2, [sp, #1088]                 ; 16-byte Spill
	bit.16b	v19, v2, v1
	stp	q19, q23, [x4]
	fmul.4s	v19, v28, v7
	ldr	q2, [sp, #2416]                 ; 16-byte Reload
	fmul.4s	v23, v2, v7
	mov.16b	v2, v16
	bsl.16b	v2, v29, v17
	ldr	x4, [sp, #224]                  ; 8-byte Reload
	ldp	q29, q31, [x4]
	mov.16b	v3, v16
	bsl.16b	v3, v8, v17
	stp	q3, q2, [sp, #976]              ; 32-byte Folded Spill
	bit.16b	v31, v3, v0
	bit.16b	v29, v2, v1
	stp	q29, q31, [x4]
	fmul.4s	v29, v15, v7
	ldr	q2, [sp, #2448]                 ; 16-byte Reload
	fmul.4s	v31, v2, v7
	mov.16b	v2, v16
	bsl.16b	v2, v21, v17
	ldr	x4, [sp, #216]                  ; 8-byte Reload
	ldp	q21, q8, [x4]
	mov.16b	v3, v16
	bsl.16b	v3, v13, v17
	stp	q3, q2, [sp, #880]              ; 32-byte Folded Spill
	bit.16b	v8, v3, v0
	bit.16b	v21, v2, v1
	stp	q21, q8, [x4]
	ldr	q2, [sp, #2480]                 ; 16-byte Reload
	fmul.4s	v21, v2, v7
	ldr	q2, [sp, #2496]                 ; 16-byte Reload
	fmul.4s	v8, v2, v7
	mov.16b	v3, v16
	bsl.16b	v3, v26, v17
	ldr	x4, [sp, #208]                  ; 8-byte Reload
	ldp	q2, q10, [x4]
	mov.16b	v4, v16
	bsl.16b	v4, v18, v17
	stp	q4, q3, [sp, #912]              ; 32-byte Folded Spill
	bit.16b	v2, v4, v1
	bit.16b	v10, v3, v0
	stp	q2, q10, [x4]
	mov.16b	v3, v16
	bsl.16b	v3, v30, v17
	mov.16b	v4, v16
	bsl.16b	v4, v5, v17
	mov.16b	v5, v16
	bsl.16b	v5, v23, v17
	ldr	x4, [sp, #200]                  ; 8-byte Reload
	ldp	q23, q2, [x4]
	mov.16b	v18, v16
	bsl.16b	v18, v19, v17
	stp	q4, q3, [sp, #1008]             ; 32-byte Folded Spill
	mov.16b	v19, v1
	bsl.16b	v19, v4, v23
	bit.16b	v2, v3, v0
	stp	q19, q2, [x4]
	mov.16b	v3, v16
	bsl.16b	v3, v31, v17
	mov.16b	v4, v16
	bsl.16b	v4, v29, v17
	ldr	x4, [sp, #192]                  ; 8-byte Reload
	ldp	q19, q2, [x4]
	str	q18, [sp, #1104]                ; 16-byte Spill
	bit.16b	v19, v18, v1
	str	q5, [sp, #1120]                 ; 16-byte Spill
	bit.16b	v2, v5, v0
	stp	q19, q2, [x4]
	ldr	x4, [sp, #184]                  ; 8-byte Reload
	ldp	q19, q2, [x4]
	str	q4, [sp, #1184]                 ; 16-byte Spill
	bit.16b	v19, v4, v1
	str	q3, [sp, #1200]                 ; 16-byte Spill
	bit.16b	v2, v3, v0
	stp	q19, q2, [x4]
	ldr	q2, [sp, #2528]                 ; 16-byte Reload
	fmul.4s	v2, v2, v7
	ldr	q19, [sp, #2512]                ; 16-byte Reload
	fmul.4s	v19, v19, v7
	str	q6, [sp, #1680]                 ; 16-byte Spill
	fmul.4s	v23, v6, v7
	str	q24, [sp, #1664]                ; 16-byte Spill
	fmul.4s	v7, v24, v7
	mov.16b	v18, v16
	bsl.16b	v18, v8, v17
	mov.16b	v20, v16
	bsl.16b	v20, v21, v17
	mov.16b	v5, v16
	bsl.16b	v5, v19, v17
	mov.16b	v6, v16
	bsl.16b	v6, v2, v17
	mov.16b	v3, v16
	bsl.16b	v3, v7, v17
	mov.16b	v4, v16
	bsl.16b	v4, v23, v17
	ldr	x4, [sp, #176]                  ; 8-byte Reload
	ldp	q7, q2, [x4]
	str	q20, [sp, #1328]                ; 16-byte Spill
	bit.16b	v2, v20, v0
	str	q18, [sp, #1344]                ; 16-byte Spill
	bit.16b	v7, v18, v1
	stp	q7, q2, [x4]
	ldr	x4, [sp, #168]                  ; 8-byte Reload
	ldp	q2, q7, [x4]
	str	q6, [sp, #1856]                 ; 16-byte Spill
	bit.16b	v2, v6, v1
	str	q5, [sp, #1872]                 ; 16-byte Spill
	bit.16b	v7, v5, v0
	stp	q2, q7, [x4]
	ldr	x4, [sp, #160]                  ; 8-byte Reload
	ldp	q2, q7, [x4]
	str	q4, [sp, #1952]                 ; 16-byte Spill
	bit.16b	v2, v4, v1
	str	q3, [sp, #2048]                 ; 16-byte Spill
	bit.16b	v7, v3, v0
	stp	q2, q7, [x4]
	mvni.4s	v2, #127, msl #16
	ldr	q19, [sp, #1696]                ; 16-byte Reload
	bit.16b	v19, v2, v0
	mvni.4s	v27, #127, msl #16
	ldr	q16, [sp, #1712]                ; 16-byte Reload
	bit.16b	v16, v2, v1
	dup.8b	v2, w3
	str	d2, [sp, #808]                  ; 8-byte Spill
LBB0_93:                                ; %direct.true597
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x3, x14, x2
	ldp	q2, q7, [x3]
	and.16b	v7, v0, v7
	and.16b	v2, v1, v2
	fmaxnm.4s	v2, v16, v2
	fmaxnm.4s	v7, v19, v7
	bit.16b	v19, v7, v0
	bit.16b	v16, v2, v1
	add	x2, x2, #32
	cmp	x2, #512
	b.ne	LBB0_93
; %bb.94:                               ; %direct.false598
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x2, #0                          ; =0x0
	ldr	q6, [sp, #1760]                 ; 16-byte Reload
	ldr	q2, [sp, #1616]                 ; 16-byte Reload
	bit.16b	v2, v6, v25
	str	q2, [sp, #1616]                 ; 16-byte Spill
	ldr	q7, [sp, #1744]                 ; 16-byte Reload
	ldr	q2, [sp, #1648]                 ; 16-byte Reload
	bit.16b	v2, v7, v9
	str	q2, [sp, #1648]                 ; 16-byte Spill
	ldr	q2, [sp, #1776]                 ; 16-byte Reload
	bit.16b	v2, v6, v25
	str	q2, [sp, #1776]                 ; 16-byte Spill
	ldr	q2, [sp, #1808]                 ; 16-byte Reload
	bit.16b	v2, v7, v9
	str	q2, [sp, #1808]                 ; 16-byte Spill
	str	q16, [sp, #1712]                ; 16-byte Spill
	ldr	q2, [sp, #2560]                 ; 16-byte Reload
	fmaxnm.4s	v3, v2, v16
	fsub.4s	v2, v22, v3
	and.16b	v5, v1, v2
	mov	w3, #-1026555904                ; =0xc2d00000
	dup.4s	v20, w3
	mov	w3, #1120403456                 ; =0x42c80000
	dup.4s	v18, w3
	fcmge.4s	v2, v5, v20
	fcmge.4s	v7, v18, v5
	and.16b	v2, v2, v7
	str	q19, [sp, #1696]                ; 16-byte Spill
	ldr	q4, [sp, #2576]                 ; 16-byte Reload
	fmaxnm.4s	v4, v4, v19
	fsub.4s	v7, v11, v4
	and.16b	v6, v0, v7
	fcmge.4s	v7, v6, v20
	fcmge.4s	v16, v18, v6
	and.16b	v7, v7, v16
	and.16b	v16, v7, v6
	mov	w3, #43579                      ; =0xaa3b
	movk	w3, #16312, lsl #16
	dup.4s	v26, w3
	fmul.4s	v7, v16, v26
	movi.4s	v17, #75, lsl #24
	mvni.4s	v30, #128, lsl #24
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v5
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	mov	w3, #29184                      ; =0x7200
	movk	w3, #16177, lsl #16
	dup.4s	v28, w3
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v23, v16, v23
	fcvtzs.4s	v16, v19
	scvtf.4s	v19, v16
	fmul.4s	v29, v19, v28
	fsub.4s	v2, v2, v29
	mov	w3, #48782                      ; =0xbe8e
	movk	w3, #13759, lsl #16
	dup.4s	v9, w3
	fmul.4s	v19, v19, v9
	fsub.4s	v2, v2, v19
	fmul.4s	v19, v21, v9
	fsub.4s	v19, v23, v19
	mov	w3, #11226                      ; =0x2bda
	movk	w3, #14672, lsl #16
	dup.4s	v10, w3
	fmul.4s	v21, v19, v10
	mov	w3, #38601                      ; =0x96c9
	movk	w3, #15030, lsl #16
	dup.4s	v11, w3
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v19, v21
	mov	w3, #34982                      ; =0x88a6
	movk	w3, #15368, lsl #16
	dup.4s	v12, w3
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v19, v21
	mov	w3, #43642                      ; =0xaa7a
	movk	w3, #15658, lsl #16
	dup.4s	v13, w3
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v19, v21
	mov	w3, #43691                      ; =0xaaab
	movk	w3, #15914, lsl #16
	dup.4s	v14, w3
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v19, v21
	movi.4s	v31, #63, lsl #24
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v19, v19
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v19, v19, v21
	fmov.4s	v8, #1.00000000
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v16, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v19, v19, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v19, v19, v29
	sub.4s	v16, v16, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v19, v7
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q5, [sp, #528]                  ; 16-byte Spill
	fcmgt.4s	v16, v20, v5
	bic.16b	v2, v2, v16
	str	q6, [sp, #1056]                 ; 16-byte Spill
	fcmgt.4s	v16, v20, v6
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v6, v18
	fneg.4s	v15, v27
	bit.16b	v7, v15, v16
	str	q7, [sp, #2032]                 ; 16-byte Spill
	fcmgt.4s	v7, v5, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #2544]                 ; 16-byte Spill
	ldr	q2, [sp, #2000]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v24, v1, v2
	fcmge.4s	v2, v24, v20
	fcmge.4s	v7, v18, v24
	and.16b	v2, v2, v7
	ldr	q5, [sp, #2016]                 ; 16-byte Reload
	fsub.4s	v7, v5, v4
	and.16b	v27, v0, v7
	fcmge.4s	v7, v27, v20
	fcmge.4s	v16, v18, v27
	and.16b	v7, v7, v16
	and.16b	v16, v7, v27
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v24
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q24, [sp, #1984]                ; 16-byte Spill
	fcmgt.4s	v16, v20, v24
	bic.16b	v2, v2, v16
	str	q27, [sp, #1968]                ; 16-byte Spill
	fcmgt.4s	v16, v20, v27
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v27, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #2000]                 ; 16-byte Spill
	fcmgt.4s	v7, v24, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #2016]                 ; 16-byte Spill
	ldr	q2, [sp, #1920]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v24, v1, v2
	fcmge.4s	v2, v24, v20
	fcmge.4s	v7, v18, v24
	and.16b	v2, v2, v7
	ldr	q5, [sp, #1936]                 ; 16-byte Reload
	fsub.4s	v7, v5, v4
	and.16b	v27, v0, v7
	fcmge.4s	v7, v27, v20
	fcmge.4s	v16, v18, v27
	and.16b	v7, v7, v16
	and.16b	v16, v7, v27
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v24
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q24, [sp, #1904]                ; 16-byte Spill
	fcmgt.4s	v16, v20, v24
	bic.16b	v2, v2, v16
	str	q27, [sp, #1888]                ; 16-byte Spill
	fcmgt.4s	v16, v20, v27
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v27, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #1936]                 ; 16-byte Spill
	fcmgt.4s	v7, v24, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #1920]                 ; 16-byte Spill
	ldr	q2, [sp, #1312]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v24, v1, v2
	fcmge.4s	v2, v24, v20
	fcmge.4s	v7, v18, v24
	and.16b	v2, v2, v7
	ldr	q5, [sp, #1840]                 ; 16-byte Reload
	fsub.4s	v7, v5, v4
	and.16b	v27, v0, v7
	fcmge.4s	v7, v27, v20
	fcmge.4s	v16, v18, v27
	and.16b	v7, v7, v16
	and.16b	v16, v7, v27
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v24
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q24, [sp, #1296]                ; 16-byte Spill
	fcmgt.4s	v16, v20, v24
	bic.16b	v2, v2, v16
	str	q27, [sp, #1280]                ; 16-byte Spill
	fcmgt.4s	v16, v20, v27
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v27, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #1840]                 ; 16-byte Spill
	fcmgt.4s	v7, v24, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #1312]                 ; 16-byte Spill
	ldr	q2, [sp, #1248]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v24, v1, v2
	fcmge.4s	v2, v24, v20
	fcmge.4s	v7, v18, v24
	and.16b	v2, v2, v7
	ldr	q5, [sp, #1264]                 ; 16-byte Reload
	fsub.4s	v7, v5, v4
	and.16b	v27, v0, v7
	fcmge.4s	v7, v27, v20
	fcmge.4s	v16, v18, v27
	and.16b	v7, v7, v16
	and.16b	v16, v7, v27
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v24
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q24, [sp, #1232]                ; 16-byte Spill
	fcmgt.4s	v16, v20, v24
	bic.16b	v2, v2, v16
	str	q27, [sp, #1216]                ; 16-byte Spill
	fcmgt.4s	v16, v20, v27
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v27, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #1264]                 ; 16-byte Spill
	fcmgt.4s	v7, v24, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #1248]                 ; 16-byte Spill
	ldr	q2, [sp, #1152]                 ; 16-byte Reload
	fsub.4s	v2, v2, v4
	and.16b	v24, v0, v2
	fcmge.4s	v2, v24, v20
	fcmge.4s	v7, v18, v24
	and.16b	v2, v2, v7
	ldr	q5, [sp, #1168]                 ; 16-byte Reload
	fsub.4s	v7, v5, v3
	and.16b	v27, v1, v7
	fcmge.4s	v7, v27, v20
	fcmge.4s	v16, v18, v27
	and.16b	v7, v7, v16
	and.16b	v16, v7, v27
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v24
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q24, [sp, #960]                 ; 16-byte Spill
	fcmgt.4s	v16, v20, v24
	bic.16b	v2, v2, v16
	str	q27, [sp, #1136]                ; 16-byte Spill
	fcmgt.4s	v16, v20, v27
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v27, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #1168]                 ; 16-byte Spill
	fcmgt.4s	v7, v24, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #1152]                 ; 16-byte Spill
	ldr	q2, [sp, #1072]                 ; 16-byte Reload
	fsub.4s	v2, v2, v4
	and.16b	v6, v0, v2
	fcmge.4s	v2, v6, v20
	fcmge.4s	v7, v18, v6
	and.16b	v2, v2, v7
	ldr	q5, [sp, #1088]                 ; 16-byte Reload
	fsub.4s	v7, v5, v3
	and.16b	v27, v1, v7
	fcmge.4s	v7, v27, v20
	fcmge.4s	v16, v18, v27
	and.16b	v7, v7, v16
	and.16b	v16, v7, v27
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v6
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q6, [sp, #864]                  ; 16-byte Spill
	fcmgt.4s	v16, v20, v6
	bic.16b	v2, v2, v16
	str	q27, [sp, #1040]                ; 16-byte Spill
	fcmgt.4s	v16, v20, v27
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v27, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #1088]                 ; 16-byte Spill
	fcmgt.4s	v7, v6, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #1072]                 ; 16-byte Spill
	ldr	q2, [sp, #976]                  ; 16-byte Reload
	fsub.4s	v2, v2, v4
	and.16b	v6, v0, v2
	fcmge.4s	v2, v6, v20
	fcmge.4s	v7, v18, v6
	and.16b	v2, v2, v7
	ldr	q7, [sp, #992]                  ; 16-byte Reload
	fsub.4s	v7, v7, v3
	and.16b	v27, v1, v7
	fcmge.4s	v7, v27, v20
	fcmge.4s	v16, v18, v27
	and.16b	v7, v7, v16
	and.16b	v16, v7, v27
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v6
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q6, [sp, #832]                  ; 16-byte Spill
	fcmgt.4s	v16, v20, v6
	bic.16b	v2, v2, v16
	str	q27, [sp, #944]                 ; 16-byte Spill
	fcmgt.4s	v16, v20, v27
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v27, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #992]                  ; 16-byte Spill
	fcmgt.4s	v7, v6, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #976]                  ; 16-byte Spill
	ldp	q2, q6, [sp, #880]              ; 32-byte Folded Reload
	fsub.4s	v2, v2, v4
	and.16b	v5, v0, v2
	fcmge.4s	v2, v5, v20
	fcmge.4s	v7, v18, v5
	and.16b	v2, v2, v7
	fsub.4s	v7, v6, v3
	and.16b	v27, v1, v7
	fcmge.4s	v7, v27, v20
	fcmge.4s	v16, v18, v27
	and.16b	v7, v7, v16
	and.16b	v16, v7, v27
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v5
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q5, [sp, #784]                  ; 16-byte Spill
	fcmgt.4s	v16, v20, v5
	bic.16b	v2, v2, v16
	str	q27, [sp, #848]                 ; 16-byte Spill
	fcmgt.4s	v16, v20, v27
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v27, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #896]                  ; 16-byte Spill
	fcmgt.4s	v7, v5, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #880]                  ; 16-byte Spill
	ldr	q2, [sp, #912]                  ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v6, v1, v2
	fcmge.4s	v2, v6, v20
	fcmge.4s	v7, v18, v6
	and.16b	v2, v2, v7
	ldr	q7, [sp, #928]                  ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v27, v0, v7
	fcmge.4s	v7, v27, v20
	fcmge.4s	v16, v18, v27
	and.16b	v7, v7, v16
	and.16b	v16, v7, v27
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v6
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q6, [sp, #768]                  ; 16-byte Spill
	fcmgt.4s	v16, v20, v6
	bic.16b	v2, v2, v16
	str	q27, [sp, #816]                 ; 16-byte Spill
	fcmgt.4s	v16, v20, v27
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v27, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #928]                  ; 16-byte Spill
	fcmgt.4s	v7, v6, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #912]                  ; 16-byte Spill
	ldr	q2, [sp, #1008]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v6, v1, v2
	fcmge.4s	v2, v6, v20
	fcmge.4s	v7, v18, v6
	and.16b	v2, v2, v7
	ldr	q7, [sp, #1024]                 ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v27, v0, v7
	fcmge.4s	v7, v27, v20
	fcmge.4s	v16, v18, v27
	and.16b	v7, v7, v16
	and.16b	v16, v7, v27
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v6
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	stp	q27, q6, [sp, #736]             ; 32-byte Folded Spill
	fcmgt.4s	v16, v20, v6
	bic.16b	v2, v2, v16
	fcmgt.4s	v16, v20, v27
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v27, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #1024]                 ; 16-byte Spill
	fcmgt.4s	v7, v6, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #1008]                 ; 16-byte Spill
	ldr	q2, [sp, #1104]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v5, v1, v2
	fcmge.4s	v2, v5, v20
	fcmge.4s	v7, v18, v5
	and.16b	v2, v2, v7
	ldr	q7, [sp, #1120]                 ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v24, v0, v7
	fcmge.4s	v7, v24, v20
	fcmge.4s	v16, v18, v24
	and.16b	v7, v7, v16
	and.16b	v16, v7, v24
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v5
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q5, [sp, #656]                  ; 16-byte Spill
	fcmgt.4s	v16, v20, v5
	bic.16b	v2, v2, v16
	str	q24, [sp, #720]                 ; 16-byte Spill
	fcmgt.4s	v16, v20, v24
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v24, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #1120]                 ; 16-byte Spill
	fcmgt.4s	v7, v5, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #1104]                 ; 16-byte Spill
	ldr	q2, [sp, #1184]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v5, v1, v2
	fcmge.4s	v2, v5, v20
	fcmge.4s	v7, v18, v5
	and.16b	v2, v2, v7
	ldr	q7, [sp, #1200]                 ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v22, v0, v7
	fcmge.4s	v7, v22, v20
	fcmge.4s	v16, v18, v22
	and.16b	v7, v7, v16
	and.16b	v16, v7, v22
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v5
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q5, [sp, #624]                  ; 16-byte Spill
	fcmgt.4s	v16, v20, v5
	bic.16b	v2, v2, v16
	str	q22, [sp, #672]                 ; 16-byte Spill
	fcmgt.4s	v16, v20, v22
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v22, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #1200]                 ; 16-byte Spill
	fcmgt.4s	v7, v5, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #1184]                 ; 16-byte Spill
	ldr	q2, [sp, #1328]                 ; 16-byte Reload
	fsub.4s	v2, v2, v4
	and.16b	v5, v0, v2
	fcmge.4s	v2, v5, v20
	fcmge.4s	v7, v18, v5
	and.16b	v2, v2, v7
	ldr	q7, [sp, #1344]                 ; 16-byte Reload
	fsub.4s	v7, v7, v3
	and.16b	v22, v1, v7
	fcmge.4s	v7, v22, v20
	fcmge.4s	v16, v18, v22
	and.16b	v7, v7, v16
	and.16b	v16, v7, v22
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v5
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	str	q5, [sp, #560]                  ; 16-byte Spill
	fcmgt.4s	v16, v20, v5
	bic.16b	v2, v2, v16
	str	q22, [sp, #640]                 ; 16-byte Spill
	fcmgt.4s	v16, v20, v22
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v22, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #704]                  ; 16-byte Spill
	fcmgt.4s	v7, v5, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #688]                  ; 16-byte Spill
	ldr	q2, [sp, #1856]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v27, v1, v2
	fcmge.4s	v2, v27, v20
	fcmge.4s	v7, v18, v27
	and.16b	v2, v2, v7
	ldr	q7, [sp, #1872]                 ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v22, v0, v7
	fcmge.4s	v7, v22, v20
	fcmge.4s	v16, v18, v22
	and.16b	v7, v7, v16
	and.16b	v16, v7, v22
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v27
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	fcmgt.4s	v16, v20, v27
	bic.16b	v2, v2, v16
	str	q22, [sp, #576]                 ; 16-byte Spill
	fcmgt.4s	v16, v20, v22
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v22, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #1872]                 ; 16-byte Spill
	fcmgt.4s	v7, v27, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #1856]                 ; 16-byte Spill
	ldr	q2, [sp, #1952]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v25, v1, v2
	fcmge.4s	v2, v25, v20
	fcmge.4s	v7, v18, v25
	and.16b	v2, v2, v7
	ldr	q7, [sp, #2048]                 ; 16-byte Reload
	fsub.4s	v7, v7, v4
	and.16b	v22, v0, v7
	fcmge.4s	v7, v22, v20
	fcmge.4s	v16, v18, v22
	and.16b	v7, v7, v16
	and.16b	v16, v7, v22
	fmul.4s	v7, v16, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v7
	fadd.4s	v7, v7, v19
	fsub.4s	v7, v7, v19
	and.16b	v2, v2, v25
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v7, v7
	scvtf.4s	v21, v7
	fmul.4s	v23, v21, v28
	fsub.4s	v16, v16, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fmul.4s	v21, v21, v9
	fsub.4s	v16, v16, v21
	fmul.4s	v21, v16, v10
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v16, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v16, v16, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v16, v16, v8
	sshr.4s	v23, v7, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v16, v16, v29
	sub.4s	v19, v19, v21
	sub.4s	v7, v7, v23
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	fcmgt.4s	v16, v20, v25
	bic.16b	v2, v2, v16
	str	q22, [sp, #544]                 ; 16-byte Spill
	fcmgt.4s	v16, v20, v22
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v22, v18
	bit.16b	v7, v15, v16
	str	q7, [sp, #608]                  ; 16-byte Spill
	fcmgt.4s	v7, v25, v18
	bit.16b	v2, v15, v7
	str	q2, [sp, #592]                  ; 16-byte Spill
	str	q4, [sp, #1328]                 ; 16-byte Spill
	ldr	q2, [sp, #2576]                 ; 16-byte Reload
	fsub.4s	v2, v2, v4
	and.16b	v6, v0, v2
	fcmge.4s	v2, v6, v20
	fcmge.4s	v7, v18, v6
	and.16b	v2, v2, v7
	str	q3, [sp, #1344]                 ; 16-byte Spill
	ldr	q4, [sp, #2560]                 ; 16-byte Reload
	fsub.4s	v7, v4, v3
	and.16b	v3, v1, v7
	fcmge.4s	v7, v3, v20
	fcmge.4s	v16, v18, v3
	and.16b	v7, v7, v16
	and.16b	v7, v7, v3
	fmul.4s	v16, v7, v26
	mov.16b	v19, v30
	bsl.16b	v19, v17, v16
	fadd.4s	v16, v16, v19
	fsub.4s	v16, v16, v19
	and.16b	v2, v2, v6
	fmul.4s	v19, v2, v26
	mov.16b	v21, v30
	bsl.16b	v21, v17, v19
	fadd.4s	v19, v19, v21
	fsub.4s	v19, v19, v21
	fcvtzs.4s	v16, v16
	scvtf.4s	v21, v16
	fmul.4s	v23, v21, v28
	fsub.4s	v7, v7, v23
	fcvtzs.4s	v19, v19
	scvtf.4s	v23, v19
	fmul.4s	v29, v23, v28
	fsub.4s	v2, v2, v29
	fmul.4s	v21, v21, v9
	fmul.4s	v23, v23, v9
	fsub.4s	v2, v2, v23
	fsub.4s	v7, v7, v21
	fmul.4s	v21, v7, v10
	fmul.4s	v23, v2, v10
	fadd.4s	v23, v23, v11
	fadd.4s	v21, v21, v11
	fmul.4s	v21, v7, v21
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v12
	fadd.4s	v21, v21, v12
	fmul.4s	v21, v7, v21
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v13
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v7, v21
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v14
	fadd.4s	v21, v21, v14
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v29, v7, v7
	fmul.4s	v21, v29, v21
	fmul.4s	v23, v2, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v29, v2, v2
	fmul.4s	v23, v29, v23
	fadd.4s	v2, v2, v23
	fadd.4s	v7, v7, v21
	fadd.4s	v2, v2, v8
	sshr.4s	v21, v19, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v8
	fmul.4s	v2, v2, v23
	fadd.4s	v7, v7, v8
	sshr.4s	v23, v16, #1
	shl.4s	v29, v23, #23
	add.4s	v29, v29, v8
	fmul.4s	v7, v7, v29
	sub.4s	v19, v19, v21
	sub.4s	v16, v16, v23
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v8
	fmul.4s	v7, v7, v16
	shl.4s	v16, v19, #23
	add.4s	v16, v16, v8
	fmul.4s	v2, v2, v16
	fcmgt.4s	v16, v20, v6
	bic.16b	v2, v2, v16
	str	q3, [sp, #496]                  ; 16-byte Spill
	fcmgt.4s	v16, v20, v3
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v3, v18
	mov.16b	v3, v16
	bsl.16b	v3, v15, v7
	str	q3, [sp, #512]                  ; 16-byte Spill
	fcmgt.4s	v7, v6, v18
	bit.16b	v2, v15, v7
	stp	q6, q2, [sp, #464]              ; 32-byte Folded Spill
	ldr	q2, [sp, #528]                  ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q17, [sp, #288]                 ; 16-byte Reload
	ldr	q3, [sp, #2544]                 ; 16-byte Reload
	mov.16b	v18, v2
	bsl.16b	v18, v3, v17
	str	q18, [sp, #2048]                ; 16-byte Spill
	ldr	q2, [sp, #1056]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	mov.16b	v26, v2
	bsl.16b	v26, v3, v17
	str	q26, [sp, #2032]                ; 16-byte Spill
	ldr	q2, [sp, #1984]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	mov.16b	v22, v2
	bsl.16b	v22, v3, v17
	str	q22, [sp, #2016]                ; 16-byte Spill
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #2000]                 ; 16-byte Reload
	mov.16b	v6, v2
	bsl.16b	v6, v3, v17
	str	q6, [sp, #2000]                 ; 16-byte Spill
	ldr	q2, [sp, #1904]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	bsl.16b	v2, v3, v17
	str	q2, [sp, #1984]                 ; 16-byte Spill
	ldr	q2, [sp, #1888]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	mov.16b	v28, v2
	bsl.16b	v28, v3, v17
	str	q28, [sp, #1968]                ; 16-byte Spill
	ldr	q2, [sp, #1296]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #1312]                 ; 16-byte Reload
	bsl.16b	v2, v3, v17
	str	q2, [sp, #1952]                 ; 16-byte Spill
	ldr	q2, [sp, #1280]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	mov.16b	v20, v2
	bsl.16b	v20, v3, v17
	str	q20, [sp, #1936]                ; 16-byte Spill
	ldr	q2, [sp, #1232]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #1248]                 ; 16-byte Reload
	bsl.16b	v2, v3, v17
	str	q2, [sp, #1920]                 ; 16-byte Spill
	ldr	q2, [sp, #1216]                 ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #1264]                 ; 16-byte Reload
	bsl.16b	v2, v3, v17
	str	q2, [sp, #2544]                 ; 16-byte Spill
	ldr	q2, [sp, #960]                  ; 16-byte Reload
	fcmeq.4s	v2, v2, v2
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	bsl.16b	v2, v3, v17
	ldr	q3, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v7, v3, v3
	ldr	q3, [sp, #1168]                 ; 16-byte Reload
	mov.16b	v21, v7
	bsl.16b	v21, v3, v17
	ldr	q3, [sp, #864]                  ; 16-byte Reload
	fcmeq.4s	v7, v3, v3
	ldr	q3, [sp, #1072]                 ; 16-byte Reload
	mov.16b	v8, v7
	bsl.16b	v8, v3, v17
	ldr	q3, [sp, #1040]                 ; 16-byte Reload
	fcmeq.4s	v7, v3, v3
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	mov.16b	v10, v7
	bsl.16b	v10, v3, v17
	ldr	q3, [sp, #832]                  ; 16-byte Reload
	fcmeq.4s	v7, v3, v3
	ldr	q3, [sp, #976]                  ; 16-byte Reload
	mov.16b	v19, v7
	bsl.16b	v19, v3, v17
	ldr	q3, [sp, #944]                  ; 16-byte Reload
	fcmeq.4s	v16, v3, v3
	ldr	q3, [sp, #992]                  ; 16-byte Reload
	mov.16b	v7, v16
	bsl.16b	v7, v3, v17
	ldr	q3, [sp, #784]                  ; 16-byte Reload
	fcmeq.4s	v16, v3, v3
	ldr	q3, [sp, #880]                  ; 16-byte Reload
	mov.16b	v29, v16
	bsl.16b	v29, v3, v17
	ldr	q3, [sp, #848]                  ; 16-byte Reload
	fcmeq.4s	v16, v3, v3
	ldr	q3, [sp, #896]                  ; 16-byte Reload
	bsl.16b	v16, v3, v17
	ldr	q3, [sp, #768]                  ; 16-byte Reload
	fcmeq.4s	v23, v3, v3
	ldr	q3, [sp, #912]                  ; 16-byte Reload
	mov.16b	v9, v23
	bsl.16b	v9, v3, v17
	ldr	q3, [sp, #816]                  ; 16-byte Reload
	fcmeq.4s	v23, v3, v3
	ldr	q3, [sp, #928]                  ; 16-byte Reload
	bsl.16b	v23, v3, v17
	ldr	q3, [sp, #752]                  ; 16-byte Reload
	fcmeq.4s	v30, v3, v3
	ldr	q3, [sp, #1008]                 ; 16-byte Reload
	bif.16b	v3, v17, v30
	str	q3, [sp, #1152]                 ; 16-byte Spill
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	fcmeq.4s	v30, v3, v3
	ldr	q3, [sp, #1024]                 ; 16-byte Reload
	bsl.16b	v30, v3, v17
	ldr	q3, [sp, #656]                  ; 16-byte Reload
	fcmeq.4s	v31, v3, v3
	ldr	q3, [sp, #1104]                 ; 16-byte Reload
	bif.16b	v3, v17, v31
	str	q3, [sp, #1168]                 ; 16-byte Spill
	ldr	q3, [sp, #720]                  ; 16-byte Reload
	fcmeq.4s	v31, v3, v3
	ldr	q3, [sp, #1120]                 ; 16-byte Reload
	bif.16b	v3, v17, v31
	str	q3, [sp, #1136]                 ; 16-byte Spill
	ldr	q3, [sp, #624]                  ; 16-byte Reload
	fcmeq.4s	v31, v3, v3
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	bif.16b	v3, v17, v31
	str	q3, [sp, #1232]                 ; 16-byte Spill
	ldr	q3, [sp, #672]                  ; 16-byte Reload
	fcmeq.4s	v31, v3, v3
	ldr	q3, [sp, #1200]                 ; 16-byte Reload
	bif.16b	v3, v17, v31
	str	q3, [sp, #1200]                 ; 16-byte Spill
	ldr	q3, [sp, #560]                  ; 16-byte Reload
	fcmeq.4s	v31, v3, v3
	ldr	q3, [sp, #688]                  ; 16-byte Reload
	bif.16b	v3, v17, v31
	str	q3, [sp, #1248]                 ; 16-byte Spill
	ldr	q3, [sp, #640]                  ; 16-byte Reload
	fcmeq.4s	v31, v3, v3
	ldr	q3, [sp, #704]                  ; 16-byte Reload
	bif.16b	v3, v17, v31
	str	q3, [sp, #1216]                 ; 16-byte Spill
	fcmeq.4s	v31, v27, v27
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	bif.16b	v3, v17, v31
	str	q3, [sp, #1280]                 ; 16-byte Spill
	ldr	q3, [sp, #576]                  ; 16-byte Reload
	fcmeq.4s	v31, v3, v3
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	bif.16b	v3, v17, v31
	str	q3, [sp, #1264]                 ; 16-byte Spill
	fcmeq.4s	v31, v25, v25
	ldr	q3, [sp, #592]                  ; 16-byte Reload
	bif.16b	v3, v17, v31
	str	q3, [sp, #1312]                 ; 16-byte Spill
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	fcmeq.4s	v31, v3, v3
	ldr	q3, [sp, #608]                  ; 16-byte Reload
	bif.16b	v3, v17, v31
	str	q3, [sp, #1296]                 ; 16-byte Spill
	ldr	d3, [sp, #808]                  ; 8-byte Reload
	zip1.8b	v31, v3, v0
	ushll.4s	v31, v31, #0
	shl.4s	v31, v31, #31
	cmlt.4s	v31, v31, #0
	and.16b	v24, v31, v21
	str	q24, [sp, #1904]                ; 16-byte Spill
	zip2.8b	v21, v3, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	and.16b	v5, v21, v2
	str	q5, [sp, #1888]                 ; 16-byte Spill
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v10, v2, v10
	str	q10, [sp, #1872]                ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v4, v2, v8
	str	q4, [sp, #1856]                 ; 16-byte Spill
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v2, v2, v7
	str	q2, [sp, #1840]                 ; 16-byte Spill
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v15, v2, v19
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v13, v2, v16
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v12, v2, v29
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v14, v2, v23
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v11, v2, v9
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v9, v2, v30
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q7, [sp, #1152]                 ; 16-byte Reload
	and.16b	v8, v2, v7
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q7, [sp, #1136]                 ; 16-byte Reload
	and.16b	v31, v2, v7
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q7, [sp, #1168]                 ; 16-byte Reload
	and.16b	v27, v2, v7
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q7, [sp, #1200]                 ; 16-byte Reload
	and.16b	v30, v2, v7
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q7, [sp, #1232]                 ; 16-byte Reload
	and.16b	v29, v2, v7
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q7, [sp, #1216]                 ; 16-byte Reload
	and.16b	v25, v2, v7
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q7, [sp, #1248]                 ; 16-byte Reload
	and.16b	v23, v2, v7
	ldp	x3, x4, [sp, #144]              ; 16-byte Folded Reload
	ldp	q7, q2, [x4]
	bit.16b	v2, v26, v0
	bit.16b	v7, v18, v1
	stp	q7, q2, [x4]
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q7, [sp, #1264]                 ; 16-byte Reload
	and.16b	v21, v2, v7
	ldp	q7, q2, [x3]
	bit.16b	v2, v6, v0
	bit.16b	v7, v22, v1
	stp	q7, q2, [x3]
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #1280]                 ; 16-byte Reload
	and.16b	v18, v2, v6
	ldp	x3, x5, [sp, #128]              ; 16-byte Folded Reload
	ldp	q7, q2, [x5]
	bit.16b	v2, v28, v0
	ldr	q28, [sp, #1984]                ; 16-byte Reload
	bit.16b	v7, v28, v1
	stp	q7, q2, [x5]
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q6, [sp, #1296]                 ; 16-byte Reload
	and.16b	v19, v2, v6
	ldp	q7, q2, [x3]
	bit.16b	v2, v20, v0
	ldr	q22, [sp, #1952]                ; 16-byte Reload
	bit.16b	v7, v22, v1
	stp	q7, q2, [x3]
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #1312]                 ; 16-byte Reload
	and.16b	v16, v2, v3
	ldp	x3, x6, [sp, #112]              ; 16-byte Folded Reload
	ldp	q7, q2, [x6]
	ldr	q3, [sp, #2544]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	ldr	q20, [sp, #1920]                ; 16-byte Reload
	bit.16b	v7, v20, v1
	stp	q7, q2, [x6]
	ldp	q7, q2, [x3]
	bit.16b	v2, v5, v0
	bit.16b	v7, v24, v1
	stp	q7, q2, [x3]
	ldp	x3, x7, [sp, #96]               ; 16-byte Folded Reload
	ldp	q7, q2, [x7]
	bit.16b	v2, v4, v0
	bit.16b	v7, v10, v1
	stp	q7, q2, [x7]
	ldp	q7, q2, [x3]
	bit.16b	v2, v15, v0
	ldr	q5, [sp, #1840]                 ; 16-byte Reload
	bit.16b	v7, v5, v1
	stp	q7, q2, [x3]
	ldp	q7, q2, [x19]
	bit.16b	v2, v12, v0
	bit.16b	v7, v13, v1
	stp	q7, q2, [x19]
	ldp	q2, q7, [x20]
	bit.16b	v2, v11, v1
	bit.16b	v7, v14, v0
	stp	q2, q7, [x20]
	ldp	q2, q7, [x21]
	bit.16b	v2, v8, v1
	bit.16b	v7, v9, v0
	stp	q2, q7, [x21]
	ldp	q2, q7, [x22]
	bit.16b	v2, v27, v1
	bit.16b	v7, v31, v0
	stp	q2, q7, [x22]
	ldp	q2, q7, [x23]
	bit.16b	v2, v29, v1
	bit.16b	v7, v30, v0
	stp	q2, q7, [x23]
	ldp	q7, q2, [x24]
	bit.16b	v2, v23, v0
	bit.16b	v7, v25, v1
	stp	q7, q2, [x24]
	ldp	q2, q7, [x25]
	bit.16b	v2, v18, v1
	bit.16b	v7, v21, v0
	stp	q2, q7, [x25]
	ldp	q2, q7, [x26]
	bit.16b	v2, v16, v1
	bit.16b	v7, v19, v0
	stp	q2, q7, [x26]
	ldp	q2, q3, [sp, #464]              ; 32-byte Folded Reload
	fcmeq.4s	v2, v2, v2
	mov.16b	v26, v2
	bsl.16b	v26, v3, v17
	ldp	q2, q3, [sp, #496]              ; 32-byte Folded Reload
	fcmeq.4s	v2, v2, v2
	bit.16b	v17, v3, v2
	sshll.2d	v2, v0, #0
	ldr	q6, [sp, #1728]                 ; 16-byte Reload
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	bit.16b	v3, v6, v2
	str	q3, [sp, #1632]                 ; 16-byte Spill
	ldr	q7, [sp, #1792]                 ; 16-byte Reload
	bit.16b	v7, v6, v2
	str	q7, [sp, #1792]                 ; 16-byte Spill
	sshll.2d	v2, v1, #0
	ldr	q3, [sp, #2608]                 ; 16-byte Reload
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	bit.16b	v3, v4, v2
	ldr	q10, [sp, #2896]                ; 16-byte Reload
	bit.16b	v10, v4, v2
	ldr	q24, [sp, #2640]                ; 16-byte Reload
	str	q17, [sp, #1072]                ; 16-byte Spill
	bit.16b	v24, v17, v1
	str	q26, [sp, #1088]                ; 16-byte Spill
	ldr	q2, [sp, #2912]                 ; 16-byte Reload
	bit.16b	v2, v26, v0
	str	q2, [sp, #2912]                 ; 16-byte Spill
	ldr	q26, [sp, #3200]                ; 16-byte Reload
	ldr	q2, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v26, v2, v1
	ldr	q2, [sp, #2960]                 ; 16-byte Reload
	ldr	q4, [sp, #2032]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #2960]                 ; 16-byte Spill
	ldr	q2, [sp, #2672]                 ; 16-byte Reload
	ldr	q4, [sp, #2016]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #2672]                 ; 16-byte Spill
	ldr	q2, [sp, #2656]                 ; 16-byte Reload
	ldr	q4, [sp, #2000]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #2656]                 ; 16-byte Spill
	ldr	q2, [sp, #2704]                 ; 16-byte Reload
	bit.16b	v2, v28, v1
	str	q2, [sp, #2704]                 ; 16-byte Spill
	ldr	q2, [sp, #2688]                 ; 16-byte Reload
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #2688]                 ; 16-byte Spill
	ldr	q2, [sp, #2736]                 ; 16-byte Reload
	bit.16b	v2, v22, v1
	str	q2, [sp, #2736]                 ; 16-byte Spill
	ldr	q2, [sp, #2720]                 ; 16-byte Reload
	ldr	q4, [sp, #1936]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #2720]                 ; 16-byte Spill
	ldr	q2, [sp, #2768]                 ; 16-byte Reload
	bit.16b	v2, v20, v1
	str	q2, [sp, #2768]                 ; 16-byte Spill
	ldr	q4, [sp, #2544]                 ; 16-byte Reload
	ldr	q2, [sp, #2752]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #2752]                 ; 16-byte Spill
	ldr	q2, [sp, #2800]                 ; 16-byte Reload
	ldr	q4, [sp, #1904]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #2800]                 ; 16-byte Spill
	ldr	q2, [sp, #2784]                 ; 16-byte Reload
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #2784]                 ; 16-byte Spill
	ldr	q2, [sp, #2832]                 ; 16-byte Reload
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #2832]                 ; 16-byte Spill
	ldr	q2, [sp, #2816]                 ; 16-byte Reload
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #2816]                 ; 16-byte Spill
	ldr	q2, [sp, #2864]                 ; 16-byte Reload
	bit.16b	v2, v5, v1
	str	q2, [sp, #2864]                 ; 16-byte Spill
	str	q15, [sp, #1312]                ; 16-byte Spill
	ldr	q2, [sp, #2848]                 ; 16-byte Reload
	bit.16b	v2, v15, v0
	str	q2, [sp, #2848]                 ; 16-byte Spill
	ldr	q22, [sp, #1456]                ; 16-byte Reload
	str	q13, [sp, #1296]                ; 16-byte Spill
	bit.16b	v22, v13, v1
	str	q12, [sp, #1280]                ; 16-byte Spill
	ldr	q2, [sp, #2976]                 ; 16-byte Reload
	bit.16b	v2, v12, v0
	str	q2, [sp, #2976]                 ; 16-byte Spill
	ldr	q12, [sp, #1488]                ; 16-byte Reload
	str	q11, [sp, #1248]                ; 16-byte Spill
	bit.16b	v12, v11, v1
	ldr	q13, [sp, #1472]                ; 16-byte Reload
	str	q14, [sp, #1264]                ; 16-byte Spill
	bit.16b	v13, v14, v0
	ldr	q20, [sp, #1520]                ; 16-byte Reload
	str	q8, [sp, #1216]                 ; 16-byte Spill
	bit.16b	v20, v8, v1
	ldr	q14, [sp, #1504]                ; 16-byte Reload
	str	q9, [sp, #1232]                 ; 16-byte Spill
	bit.16b	v14, v9, v0
	ldr	q28, [sp, #1360]                ; 16-byte Reload
	str	q27, [sp, #1200]                ; 16-byte Spill
	bit.16b	v28, v27, v1
	ldr	q11, [sp, #1536]                ; 16-byte Reload
	str	q31, [sp, #1360]                ; 16-byte Spill
	bit.16b	v11, v31, v0
	ldr	q27, [sp, #2880]                ; 16-byte Reload
	str	q29, [sp, #1168]                ; 16-byte Spill
	bit.16b	v27, v29, v1
	ldr	q17, [sp, #1376]                ; 16-byte Reload
	str	q30, [sp, #1184]                ; 16-byte Spill
	bit.16b	v17, v30, v0
	str	q25, [sp, #1376]                ; 16-byte Spill
	ldr	q2, [sp, #2944]                 ; 16-byte Reload
	bit.16b	v2, v25, v1
	str	q2, [sp, #2944]                 ; 16-byte Spill
	str	q23, [sp, #1152]                ; 16-byte Spill
	ldr	q2, [sp, #2928]                 ; 16-byte Reload
	bit.16b	v2, v23, v0
	str	q2, [sp, #2928]                 ; 16-byte Spill
	str	q18, [sp, #1120]                ; 16-byte Spill
	ldr	q2, [sp, #2624]                 ; 16-byte Reload
	bit.16b	v2, v18, v1
	str	q2, [sp, #2624]                 ; 16-byte Spill
	str	q21, [sp, #1136]                ; 16-byte Spill
	ldr	q4, [sp, #2592]                 ; 16-byte Reload
	bit.16b	v4, v21, v0
	str	q4, [sp, #2592]                 ; 16-byte Spill
	ldr	q18, [sp, #1440]                ; 16-byte Reload
	str	q16, [sp, #1104]                ; 16-byte Spill
	bit.16b	v18, v16, v1
	ldr	q15, [sp, #1424]                ; 16-byte Reload
	str	q19, [sp, #1440]                ; 16-byte Spill
	bit.16b	v15, v19, v0
	ldr	q6, [sp, #368]                  ; 16-byte Reload
	str	q10, [sp, #2896]                ; 16-byte Spill
	str	q27, [sp, #2880]                ; 16-byte Spill
	str	q26, [sp, #3200]                ; 16-byte Spill
	str	q24, [sp, #2640]                ; 16-byte Spill
	str	q3, [sp, #2608]                 ; 16-byte Spill
LBB0_95:                                ; %direct.true739
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d7, x2
	orr.16b	v2, v7, v6
	fmov	x3, d2
	add	x3, x8, x3
	ldp	q16, q2, [x3]
	and.16b	v16, v1, v16
	and.16b	v2, v0, v2
	add	x3, x2, #32
	fmov	d23, x3
	orr.16b	v19, v23, v6
	ldr	q4, [sp, #2912]                 ; 16-byte Reload
	fmul.4s	v2, v4, v2
	fmov	x3, d19
	add	x3, x8, x3
	ldp	q19, q21, [x3]
	and.16b	v21, v0, v21
	fmul.4s	v16, v24, v16
	and.16b	v29, v1, v19
	add	x3, x2, #64
	fmov	d19, x3
	orr.16b	v30, v19, v6
	fmov	x3, d30
	fmul.4s	v30, v24, v29
	add	x3, x8, x3
	ldp	q29, q31, [x3]
	and.16b	v31, v0, v31
	and.16b	v29, v1, v29
	fmul.4s	v21, v4, v21
	fmul.4s	v8, v24, v29
	add	x3, x2, #96
	fmov	d29, x3
	orr.16b	v10, v29, v6
	fmov	x3, d10
	fmul.4s	v31, v4, v31
	add	x3, x8, x3
	ldp	q10, q9, [x3]
	and.16b	v9, v0, v9
	and.16b	v10, v1, v10
	fmul.4s	v10, v24, v10
	orr.16b	v24, v7, v3
	fmov	x3, d24
	add	x3, x13, x3
	ldp	q25, q24, [x3]
	fmul.4s	v9, v4, v9
	and.16b	v25, v1, v25
	and.16b	v24, v0, v24
	ldr	q4, [sp, #2960]                 ; 16-byte Reload
	fmul.4s	v24, v4, v24
	fmul.4s	v25, v26, v25
	orr.16b	v26, v23, v3
	fadd.4s	v16, v16, v25
	fmov	x3, d26
	add	x3, x13, x3
	ldp	q25, q26, [x3]
	and.16b	v26, v0, v26
	fadd.4s	v2, v2, v24
	and.16b	v24, v1, v25
	ldr	q25, [sp, #3200]                ; 16-byte Reload
	fmul.4s	v24, v25, v24
	fmul.4s	v25, v4, v26
	orr.16b	v26, v19, v3
	fmov	x3, d26
	fadd.4s	v21, v21, v25
	add	x3, x13, x3
	ldp	q25, q26, [x3]
	and.16b	v26, v0, v26
	and.16b	v25, v1, v25
	fadd.4s	v24, v30, v24
	ldr	q30, [sp, #3200]                ; 16-byte Reload
	fmul.4s	v25, v30, v25
	fmul.4s	v26, v4, v26
	orr.16b	v30, v29, v3
	fmov	x3, d30
	add	x3, x13, x3
	fadd.4s	v26, v31, v26
	ldp	q30, q31, [x3]
	and.16b	v31, v0, v31
	and.16b	v30, v1, v30
	ldr	q3, [sp, #3200]                 ; 16-byte Reload
	fmul.4s	v30, v3, v30
	ldr	q3, [sp, #2608]                 ; 16-byte Reload
	fadd.4s	v25, v8, v25
	fmul.4s	v31, v4, v31
	fadd.4s	v31, v9, v31
	add	x3, x1, x2
	ldp	q8, q9, [x3]
	fadd.4s	v30, v10, v30
	and.16b	v9, v0, v9
	and.16b	v8, v1, v8
	ldr	q4, [sp, #2672]                 ; 16-byte Reload
	fmul.4s	v8, v4, v8
	ldr	q5, [sp, #2656]                 ; 16-byte Reload
	fmul.4s	v9, v5, v9
	fadd.4s	v2, v2, v9
	ldp	q9, q10, [x3, #32]
	and.16b	v9, v1, v9
	and.16b	v10, v0, v10
	fmul.4s	v10, v5, v10
	fmul.4s	v9, v4, v9
	fadd.4s	v16, v16, v8
	fadd.4s	v24, v24, v9
	ldp	q9, q8, [x3, #64]
	and.16b	v9, v1, v9
	and.16b	v8, v0, v8
	fadd.4s	v21, v21, v10
	fmul.4s	v8, v5, v8
	fmul.4s	v9, v4, v9
	fadd.4s	v25, v25, v9
	ldp	q10, q9, [x3, #96]
	fadd.4s	v26, v26, v8
	and.16b	v8, v1, v10
	and.16b	v9, v0, v9
	fmul.4s	v9, v5, v9
	fmul.4s	v8, v4, v8
	ldr	q10, [x3, #3088]
	fadd.4s	v30, v30, v8
	ldr	q8, [x3, #3072]
	and.16b	v8, v1, v8
	and.16b	v10, v0, v10
	ldr	q5, [sp, #2688]                 ; 16-byte Reload
	fmul.4s	v10, v5, v10
	ldr	q4, [sp, #2704]                 ; 16-byte Reload
	fmul.4s	v8, v4, v8
	fadd.4s	v31, v31, v9
	fadd.4s	v16, v16, v8
	ldr	q8, [x3, #3104]
	ldr	q9, [x3, #3120]
	and.16b	v9, v0, v9
	and.16b	v8, v1, v8
	fadd.4s	v2, v2, v10
	fmul.4s	v8, v4, v8
	fmul.4s	v9, v5, v9
	fadd.4s	v21, v21, v9
	ldr	q9, [x3, #3136]
	ldr	q10, [x3, #3152]
	fadd.4s	v24, v24, v8
	and.16b	v8, v0, v10
	and.16b	v9, v1, v9
	fmul.4s	v9, v4, v9
	fmul.4s	v8, v5, v8
	ldr	q10, [x3, #3168]
	fadd.4s	v26, v26, v8
	ldr	q8, [x3, #3184]
	and.16b	v8, v0, v8
	and.16b	v10, v1, v10
	fmul.4s	v10, v4, v10
	fmul.4s	v8, v5, v8
	fadd.4s	v25, v25, v9
	fadd.4s	v31, v31, v8
	ldr	q8, [x3, #6144]
	ldr	q9, [x3, #6160]
	and.16b	v9, v0, v9
	and.16b	v8, v1, v8
	fadd.4s	v30, v30, v10
	ldr	q4, [sp, #2736]                 ; 16-byte Reload
	fmul.4s	v8, v4, v8
	ldr	q5, [sp, #2720]                 ; 16-byte Reload
	fmul.4s	v9, v5, v9
	fadd.4s	v2, v2, v9
	ldr	q9, [x3, #6192]
	ldr	q10, [x3, #6176]
	fadd.4s	v16, v16, v8
	and.16b	v8, v1, v10
	and.16b	v9, v0, v9
	fmul.4s	v9, v5, v9
	fmul.4s	v8, v4, v8
	ldr	q10, [x3, #6224]
	fadd.4s	v24, v24, v8
	ldr	q8, [x3, #6208]
	and.16b	v8, v1, v8
	and.16b	v10, v0, v10
	fmul.4s	v10, v5, v10
	fmul.4s	v8, v4, v8
	fadd.4s	v21, v21, v9
	fadd.4s	v25, v25, v8
	ldr	q8, [x3, #6256]
	ldr	q9, [x3, #6240]
	and.16b	v9, v1, v9
	and.16b	v8, v0, v8
	fadd.4s	v26, v26, v10
	fmul.4s	v8, v5, v8
	fmul.4s	v9, v4, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x3, #9232]
	ldr	q10, [x3, #9216]
	fadd.4s	v31, v31, v8
	and.16b	v8, v1, v10
	and.16b	v9, v0, v9
	ldr	q5, [sp, #2752]                 ; 16-byte Reload
	fmul.4s	v9, v5, v9
	ldr	q4, [sp, #2768]                 ; 16-byte Reload
	fmul.4s	v8, v4, v8
	ldr	q10, [x3, #9248]
	fadd.4s	v16, v16, v8
	ldr	q8, [x3, #9264]
	and.16b	v8, v0, v8
	and.16b	v10, v1, v10
	fmul.4s	v10, v4, v10
	fmul.4s	v8, v5, v8
	fadd.4s	v2, v2, v9
	fadd.4s	v21, v21, v8
	ldr	q8, [x3, #9280]
	ldr	q9, [x3, #9296]
	and.16b	v9, v0, v9
	and.16b	v8, v1, v8
	fadd.4s	v24, v24, v10
	fmul.4s	v8, v4, v8
	fmul.4s	v9, v5, v9
	fadd.4s	v26, v26, v9
	ldr	q9, [x3, #9312]
	ldr	q10, [x3, #9328]
	fadd.4s	v25, v25, v8
	and.16b	v8, v0, v10
	and.16b	v9, v1, v9
	fmul.4s	v9, v4, v9
	fmul.4s	v8, v5, v8
	ldr	q10, [x3, #12288]
	fadd.4s	v31, v31, v8
	ldr	q8, [x3, #12304]
	and.16b	v8, v0, v8
	and.16b	v10, v1, v10
	ldr	q4, [sp, #2800]                 ; 16-byte Reload
	fmul.4s	v10, v4, v10
	ldr	q5, [sp, #2784]                 ; 16-byte Reload
	fmul.4s	v8, v5, v8
	fadd.4s	v30, v30, v9
	fadd.4s	v2, v2, v8
	ldr	q8, [x3, #12336]
	ldr	q9, [x3, #12320]
	and.16b	v9, v1, v9
	and.16b	v8, v0, v8
	fadd.4s	v16, v16, v10
	fmul.4s	v8, v5, v8
	fmul.4s	v9, v4, v9
	fadd.4s	v24, v24, v9
	ldr	q9, [x3, #12368]
	ldr	q10, [x3, #12352]
	fadd.4s	v21, v21, v8
	and.16b	v8, v1, v10
	and.16b	v9, v0, v9
	fmul.4s	v9, v5, v9
	fmul.4s	v8, v4, v8
	ldr	q10, [x3, #12400]
	fadd.4s	v25, v25, v8
	ldr	q8, [x3, #12384]
	and.16b	v8, v1, v8
	and.16b	v10, v0, v10
	fmul.4s	v10, v5, v10
	fmul.4s	v8, v4, v8
	fadd.4s	v26, v26, v9
	fadd.4s	v30, v30, v8
	ldr	q8, [x3, #15376]
	ldr	q9, [x3, #15360]
	and.16b	v9, v1, v9
	and.16b	v8, v0, v8
	fadd.4s	v31, v31, v10
	ldr	q5, [sp, #2816]                 ; 16-byte Reload
	fmul.4s	v8, v5, v8
	ldr	q4, [sp, #2832]                 ; 16-byte Reload
	fmul.4s	v9, v4, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x3, #15392]
	ldr	q10, [x3, #15408]
	fadd.4s	v2, v2, v8
	and.16b	v8, v0, v10
	and.16b	v9, v1, v9
	fmul.4s	v9, v4, v9
	fmul.4s	v8, v5, v8
	ldr	q10, [x3, #15424]
	fadd.4s	v21, v21, v8
	ldr	q8, [x3, #15440]
	and.16b	v8, v0, v8
	and.16b	v10, v1, v10
	fmul.4s	v10, v4, v10
	fmul.4s	v8, v5, v8
	fadd.4s	v24, v24, v9
	fadd.4s	v26, v26, v8
	ldr	q8, [x3, #15456]
	ldr	q9, [x3, #15472]
	and.16b	v9, v0, v9
	and.16b	v8, v1, v8
	fadd.4s	v25, v25, v10
	fmul.4s	v8, v4, v8
	fmul.4s	v9, v5, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x3, #18432]
	ldr	q10, [x3, #18448]
	fadd.4s	v30, v30, v8
	and.16b	v8, v0, v10
	and.16b	v9, v1, v9
	ldr	q4, [sp, #2864]                 ; 16-byte Reload
	fmul.4s	v9, v4, v9
	ldr	q5, [sp, #2848]                 ; 16-byte Reload
	fmul.4s	v8, v5, v8
	ldr	q10, [x3, #18480]
	fadd.4s	v2, v2, v8
	ldr	q8, [x3, #18464]
	and.16b	v8, v1, v8
	and.16b	v10, v0, v10
	fmul.4s	v10, v5, v10
	fmul.4s	v8, v4, v8
	fadd.4s	v16, v16, v9
	fadd.4s	v24, v24, v8
	ldr	q8, [x3, #18512]
	ldr	q9, [x3, #18496]
	and.16b	v9, v1, v9
	and.16b	v8, v0, v8
	fadd.4s	v21, v21, v10
	fmul.4s	v8, v5, v8
	fmul.4s	v9, v4, v9
	fadd.4s	v25, v25, v9
	ldr	q9, [x3, #18544]
	ldr	q10, [x3, #18528]
	fadd.4s	v26, v26, v8
	and.16b	v8, v1, v10
	and.16b	v9, v0, v9
	fmul.4s	v9, v5, v9
	fmul.4s	v8, v4, v8
	ldr	q10, [x3, #21520]
	fadd.4s	v30, v30, v8
	ldr	q8, [x3, #21504]
	and.16b	v8, v1, v8
	and.16b	v10, v0, v10
	ldr	q4, [sp, #2976]                 ; 16-byte Reload
	fmul.4s	v10, v4, v10
	fmul.4s	v8, v22, v8
	fadd.4s	v31, v31, v9
	fadd.4s	v16, v16, v8
	ldr	q8, [x3, #21536]
	ldr	q9, [x3, #21552]
	and.16b	v9, v0, v9
	and.16b	v8, v1, v8
	fadd.4s	v2, v2, v10
	fmul.4s	v8, v22, v8
	fmul.4s	v9, v4, v9
	fadd.4s	v21, v21, v9
	ldr	q9, [x3, #21568]
	ldr	q10, [x3, #21584]
	fadd.4s	v24, v24, v8
	and.16b	v8, v0, v10
	and.16b	v9, v1, v9
	fmul.4s	v9, v22, v9
	fmul.4s	v8, v4, v8
	ldr	q10, [x3, #21600]
	fadd.4s	v26, v26, v8
	ldr	q8, [x3, #21616]
	and.16b	v8, v0, v8
	and.16b	v10, v1, v10
	fmul.4s	v10, v22, v10
	fmul.4s	v8, v4, v8
	fadd.4s	v25, v25, v9
	fadd.4s	v31, v31, v8
	ldr	q8, [x3, #24576]
	ldr	q9, [x3, #24592]
	and.16b	v9, v0, v9
	and.16b	v8, v1, v8
	fadd.4s	v30, v30, v10
	fmul.4s	v8, v12, v8
	fmul.4s	v9, v13, v9
	fadd.4s	v2, v2, v9
	ldr	q9, [x3, #24624]
	ldr	q10, [x3, #24608]
	fadd.4s	v16, v16, v8
	and.16b	v8, v1, v10
	and.16b	v9, v0, v9
	fmul.4s	v9, v13, v9
	fmul.4s	v8, v12, v8
	ldr	q10, [x3, #24656]
	fadd.4s	v24, v24, v8
	ldr	q8, [x3, #24640]
	and.16b	v8, v1, v8
	and.16b	v10, v0, v10
	fmul.4s	v10, v13, v10
	fmul.4s	v8, v12, v8
	fadd.4s	v21, v21, v9
	fadd.4s	v25, v25, v8
	ldr	q8, [x3, #24688]
	ldr	q9, [x3, #24672]
	and.16b	v9, v1, v9
	and.16b	v8, v0, v8
	fadd.4s	v26, v26, v10
	fmul.4s	v8, v13, v8
	fmul.4s	v9, v12, v9
	fadd.4s	v30, v30, v9
	ldr	q9, [x3, #27664]
	ldr	q10, [x3, #27648]
	fadd.4s	v31, v31, v8
	and.16b	v8, v1, v10
	and.16b	v9, v0, v9
	fmul.4s	v9, v14, v9
	fmul.4s	v8, v20, v8
	ldr	q10, [x3, #27680]
	fadd.4s	v16, v16, v8
	ldr	q8, [x3, #27696]
	and.16b	v8, v0, v8
	and.16b	v10, v1, v10
	fmul.4s	v10, v20, v10
	fmul.4s	v8, v14, v8
	fadd.4s	v2, v2, v9
	fadd.4s	v21, v21, v8
	ldr	q8, [x3, #27712]
	ldr	q9, [x3, #27728]
	and.16b	v9, v0, v9
	and.16b	v8, v1, v8
	fadd.4s	v24, v24, v10
	fmul.4s	v8, v20, v8
	fmul.4s	v9, v14, v9
	fadd.4s	v26, v26, v9
	ldr	q9, [x3, #27744]
	ldr	q10, [x3, #27760]
	fadd.4s	v25, v25, v8
	and.16b	v8, v0, v10
	and.16b	v9, v1, v9
	fmul.4s	v9, v20, v9
	fmul.4s	v8, v14, v8
	ldr	q10, [x3, #30720]
	fadd.4s	v31, v31, v8
	ldr	q8, [x3, #30736]
	and.16b	v8, v0, v8
	and.16b	v10, v1, v10
	fmul.4s	v10, v28, v10
	fmul.4s	v8, v11, v8
	fadd.4s	v30, v30, v9
	fadd.4s	v2, v2, v8
	ldr	q8, [x3, #30768]
	ldr	q9, [x3, #30752]
	and.16b	v9, v1, v9
	and.16b	v8, v0, v8
	fadd.4s	v16, v16, v10
	fmul.4s	v8, v11, v8
	fmul.4s	v9, v28, v9
	fadd.4s	v24, v24, v9
	ldr	q9, [x3, #30800]
	ldr	q10, [x3, #30784]
	fadd.4s	v21, v21, v8
	and.16b	v8, v1, v10
	and.16b	v9, v0, v9
	fmul.4s	v9, v11, v9
	fmul.4s	v8, v28, v8
	ldr	q10, [x3, #30832]
	fadd.4s	v25, v25, v8
	ldr	q8, [x3, #30816]
	and.16b	v8, v1, v8
	and.16b	v10, v0, v10
	fmul.4s	v10, v11, v10
	fmul.4s	v8, v28, v8
	fadd.4s	v26, v26, v9
	fadd.4s	v30, v30, v8
	ldr	q8, [x3, #33808]
	ldr	q9, [x3, #33792]
	and.16b	v9, v1, v9
	and.16b	v8, v0, v8
	fadd.4s	v31, v31, v10
	fmul.4s	v8, v17, v8
	fmul.4s	v9, v27, v9
	fadd.4s	v16, v16, v9
	ldr	q9, [x3, #33824]
	ldr	q10, [x3, #33840]
	fadd.4s	v2, v2, v8
	and.16b	v8, v0, v10
	and.16b	v9, v1, v9
	fmul.4s	v9, v27, v9
	fmul.4s	v8, v17, v8
	ldr	q10, [x3, #33856]
	fadd.4s	v21, v21, v8
	ldr	q8, [x3, #33872]
	and.16b	v8, v0, v8
	and.16b	v10, v1, v10
	fmul.4s	v10, v27, v10
	fmul.4s	v8, v17, v8
	fadd.4s	v24, v24, v9
	fadd.4s	v26, v26, v8
	ldr	q8, [x3, #33888]
	ldr	q9, [x3, #33904]
	and.16b	v9, v0, v9
	and.16b	v8, v1, v8
	fadd.4s	v25, v25, v10
	fmul.4s	v8, v27, v8
	fmul.4s	v9, v17, v9
	fadd.4s	v31, v31, v9
	ldr	q9, [x3, #36864]
	ldr	q10, [x3, #36880]
	fadd.4s	v30, v30, v8
	and.16b	v8, v0, v10
	and.16b	v9, v1, v9
	ldr	q4, [sp, #2944]                 ; 16-byte Reload
	fmul.4s	v9, v4, v9
	ldr	q5, [sp, #2928]                 ; 16-byte Reload
	fmul.4s	v8, v5, v8
	ldr	q10, [x3, #36912]
	fadd.4s	v2, v2, v8
	ldr	q8, [x3, #36896]
	and.16b	v8, v1, v8
	and.16b	v10, v0, v10
	fmul.4s	v10, v5, v10
	fmul.4s	v8, v4, v8
	fadd.4s	v16, v16, v9
	fadd.4s	v24, v24, v8
	ldr	q8, [x3, #36944]
	ldr	q9, [x3, #36928]
	and.16b	v9, v1, v9
	and.16b	v8, v0, v8
	fadd.4s	v21, v21, v10
	fmul.4s	v8, v5, v8
	fmul.4s	v9, v4, v9
	fadd.4s	v25, v25, v9
	ldr	q9, [x3, #36976]
	ldr	q10, [x3, #36960]
	fadd.4s	v26, v26, v8
	and.16b	v8, v1, v10
	and.16b	v9, v0, v9
	fmul.4s	v9, v5, v9
	fmul.4s	v8, v4, v8
	ldr	q10, [x3, #39952]
	fadd.4s	v27, v30, v8
	ldr	q30, [x3, #39936]
	and.16b	v30, v1, v30
	and.16b	v8, v0, v10
	ldr	q4, [sp, #2592]                 ; 16-byte Reload
	fmul.4s	v8, v4, v8
	ldr	q5, [sp, #2624]                 ; 16-byte Reload
	fmul.4s	v30, v5, v30
	fadd.4s	v31, v31, v9
	fadd.4s	v9, v16, v30
	ldr	q16, [x3, #39968]
	ldr	q30, [x3, #39984]
	and.16b	v30, v0, v30
	and.16b	v16, v1, v16
	fadd.4s	v2, v2, v8
	fmul.4s	v16, v5, v16
	fmul.4s	v30, v4, v30
	fadd.4s	v8, v21, v30
	ldr	q21, [x3, #40000]
	ldr	q30, [x3, #40016]
	fadd.4s	v24, v24, v16
	and.16b	v16, v0, v30
	and.16b	v21, v1, v21
	fmul.4s	v21, v5, v21
	fmul.4s	v16, v4, v16
	ldr	q10, [x3, #40032]
	fadd.4s	v30, v26, v16
	ldr	q16, [x3, #40048]
	and.16b	v16, v0, v16
	and.16b	v26, v1, v10
	fmul.4s	v26, v5, v26
	fmul.4s	v16, v4, v16
	fadd.4s	v21, v25, v21
	fadd.4s	v16, v31, v16
	ldr	q25, [x3, #43008]
	ldr	q31, [x3, #43024]
	and.16b	v10, v0, v31
	and.16b	v25, v1, v25
	fadd.4s	v31, v27, v26
	fmul.4s	v25, v18, v25
	fmul.4s	v26, v15, v10
	ldr	q10, [sp, #2896]                ; 16-byte Reload
	ldr	q27, [x3, #43056]
	fadd.4s	v2, v2, v26
	ldr	q26, [x3, #43040]
	fadd.4s	v25, v9, v25
	ldr	q9, [x3, #43088]
	orr.16b	v7, v7, v10
	fmov	x4, d7
	ldr	q7, [x3, #43072]
	add	x4, x15, x4
	and.16b	v26, v1, v26
	fmul.4s	v26, v18, v26
	fadd.4s	v24, v24, v26
	and.16b	v27, v0, v27
	fmul.4s	v27, v15, v27
	fadd.4s	v27, v8, v27
	ldp	q8, q26, [x4]
	bif.16b	v25, v8, v1
	ldr	q8, [x3, #43120]
	bif.16b	v2, v26, v0
	ldr	q26, [x3, #43104]
	stp	q25, q2, [x4]
	orr.16b	v2, v23, v10
	fmov	x3, d2
	and.16b	v2, v1, v7
	add	x3, x15, x3
	fmul.4s	v2, v18, v2
	fadd.4s	v2, v21, v2
	ldp	q21, q7, [x3]
	bit.16b	v7, v27, v0
	ldr	q27, [sp, #2880]                ; 16-byte Reload
	bit.16b	v21, v24, v1
	ldr	q24, [sp, #2640]                ; 16-byte Reload
	stp	q21, q7, [x3]
	orr.16b	v7, v19, v10
	fmov	x3, d7
	orr.16b	v7, v29, v10
	fmov	x4, d7
	and.16b	v7, v0, v9
	fmul.4s	v7, v15, v7
	fadd.4s	v7, v30, v7
	add	x3, x15, x3
	and.16b	v19, v1, v26
	ldr	q26, [sp, #3200]                ; 16-byte Reload
	fmul.4s	v19, v18, v19
	fadd.4s	v19, v31, v19
	ldp	q21, q4, [x3]
	bif.16b	v7, v4, v0
	bif.16b	v2, v21, v1
	stp	q2, q7, [x3]
	add	x3, x15, x4
	and.16b	v2, v0, v8
	fmul.4s	v2, v15, v2
	fadd.4s	v2, v16, v2
	ldp	q7, q4, [x3]
	bif.16b	v2, v4, v0
	bit.16b	v7, v19, v1
	stp	q7, q2, [x3]
	add	x2, x2, #128
	cmp	x2, #3072
	b.ne	LBB0_95
; %bb.96:                               ; %direct.true1172.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q27, [sp, #2912]                ; 16-byte Reload
	ldr	q9, [sp, #2960]                 ; 16-byte Reload
	ldr	q25, [sp, #2976]                ; 16-byte Reload
	mov.16b	v30, v28
	mov.16b	v28, v17
	ldr	q5, [sp, #2928]                 ; 16-byte Reload
	ldr	q31, [sp, #2944]                ; 16-byte Reload
	mov	x2, #0                          ; =0x0
	mov.16b	v8, v6
LBB0_97:                                ; %direct.true1172
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	d2, x2
	orr.16b	v7, v2, v10
	fmov	x3, d7
	add	x3, x15, x3
	ldp	q7, q16, [x3]
	orr.16b	v2, v2, v8
	fmov	x3, d2
	add	x3, x11, x3
	ldp	q2, q19, [x3]
	bif.16b	v16, v19, v0
	bit.16b	v2, v7, v1
	stp	q2, q16, [x3]
	add	x2, x2, #32
	cmp	x2, #3072
	b.ne	LBB0_97
; %bb.98:                               ; %direct.true1188.preheader
                                        ;   in Loop: Header=BB0_22 Depth=1
	mov	x2, x10
	mov	w3, #96                         ; =0x60
	ldp	q21, q24, [sp, #432]            ; 32-byte Folded Reload
	ldr	q26, [sp, #416]                 ; 16-byte Reload
	ldp	q10, q17, [sp, #320]            ; 32-byte Folded Reload
	ldr	q23, [sp, #1408]                ; 16-byte Reload
	ldr	q29, [sp, #1392]                ; 16-byte Reload
	str	q11, [sp, #1536]                ; 16-byte Spill
	str	q20, [sp, #1520]                ; 16-byte Spill
	str	q14, [sp, #1504]                ; 16-byte Spill
	str	q12, [sp, #1488]                ; 16-byte Spill
	str	q13, [sp, #1472]                ; 16-byte Spill
	str	q22, [sp, #1456]                ; 16-byte Spill
	mov.16b	v3, v25
	mov.16b	v4, v9
LBB0_99:                                ; %direct.true1188
                                        ;   Parent Loop BB0_22 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x2, #5632]
	ldr	q7, [x2, #5648]
	ldr	q16, [x2, #2560]
	ldr	q19, [x2, #2576]
	bif.16b	v7, v19, v0
	bif.16b	v2, v16, v1
	str	q2, [x2, #2560]
	str	q7, [x2, #2576]
	add	x2, x2, #32
	subs	x3, x3, #1
	b.ne	LBB0_99
; %bb.100:                              ; %direct.false1189
                                        ;   in Loop: Header=BB0_22 Depth=1
	ldr	q2, [sp, #2576]                 ; 16-byte Reload
	ldr	q7, [sp, #1328]                 ; 16-byte Reload
	bit.16b	v2, v7, v0
	str	q2, [sp, #2576]                 ; 16-byte Spill
	ldr	q2, [sp, #2560]                 ; 16-byte Reload
	ldr	q7, [sp, #1344]                 ; 16-byte Reload
	bit.16b	v2, v7, v1
	str	q2, [sp, #2560]                 ; 16-byte Spill
	movi.2d	v7, #0000000000000000
	ldr	q2, [sp, #2048]                 ; 16-byte Reload
	fadd.4s	v2, v2, v7
	ldr	q16, [sp, #2016]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #2032]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #2000]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1968]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1984]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1952]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1936]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #2544]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1920]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1904]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1856]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1872]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1840]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1312]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1280]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1296]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1248]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1264]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1232]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1216]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1200]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1360]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1184]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1168]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1376]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1152]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1136]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1120]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1104]                ; 16-byte Reload
	fadd.4s	v2, v2, v16
	ldr	q16, [sp, #1440]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	ldr	q16, [sp, #1072]                ; 16-byte Reload
	fmul.4s	v16, v23, v16
	ldr	q19, [sp, #1088]                ; 16-byte Reload
	fmul.4s	v19, v29, v19
	fadd.4s	v7, v19, v7
	fadd.4s	v2, v16, v2
	bit.16b	v23, v2, v1
	bit.16b	v29, v7, v0
	add	x0, x0, #1
	cmp	x0, #129
	ldp	q25, q9, [sp, #384]             ; 32-byte Folded Reload
	ldr	q20, [sp, #2144]                ; 16-byte Reload
	ldr	q14, [sp, #2128]                ; 16-byte Reload
	ldr	q12, [sp, #2112]                ; 16-byte Reload
	ldr	q13, [sp, #2096]                ; 16-byte Reload
	ldr	q22, [sp, #2080]                ; 16-byte Reload
	ldr	q11, [sp, #2064]                ; 16-byte Reload
	b.ne	LBB0_22
; %bb.101:                              ; %direct.schedule.83.preheader
	mov	x9, #0                          ; =0x0
	ldp	q2, q4, [sp, #16]               ; 32-byte Folded Reload
	xtn.2s	v2, v2
	movi.2s	v5, #96
	umull.2d	v2, v2, v5
	ldp	q3, q6, [sp, #48]               ; 32-byte Folded Reload
	xtn.2s	v3, v3
	umull.2d	v3, v3, v5
	xtn.2s	v4, v4
	umull.2d	v4, v4, v5
	xtn.2s	v6, v6
	umull.2d	v5, v6, v5
	ldr	x12, [sp, #88]                  ; 8-byte Reload
	b	LBB0_103
LBB0_102:                               ; %else420
                                        ;   in Loop: Header=BB0_103 Depth=1
	add	x9, x9, #1
	cmp	x9, #96
	b.eq	LBB0_119
LBB0_103:                               ; %direct.true1207
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w10, s24
	dup.2d	v6, x9
	add.2d	v7, v6, v2
	add	x11, x8, x9, lsl #5
	ldp	q17, q16, [x11]
	and.16b	v17, v1, v17
	fdiv.4s	v17, v17, v23
	shl.2d	v18, v7, #2
	dup.2d	v7, x12
	add.2d	v18, v7, v18
	tbz	w10, #0, LBB0_111
; %bb.104:                              ; %cond.store
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x11, d18
	str	s17, [x11]
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_112
LBB0_105:                               ; %else402
                                        ;   in Loop: Header=BB0_103 Depth=1
	add.2d	v18, v6, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbz	w10, #2, LBB0_113
LBB0_106:                               ; %cond.store403
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x11, d18
	st1.s	{ v17 }[2], [x11]
	tbnz	w10, #3, LBB0_114
LBB0_107:                               ; %else408
                                        ;   in Loop: Header=BB0_103 Depth=1
	add.2d	v17, v6, v4
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v29
	shl.2d	v17, v17, #2
	add.2d	v17, v7, v17
	tbz	w10, #4, LBB0_115
LBB0_108:                               ; %cond.store409
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x11, d17
	str	s16, [x11]
	tbnz	w10, #5, LBB0_116
LBB0_109:                               ; %else414
                                        ;   in Loop: Header=BB0_103 Depth=1
	add.2d	v6, v6, v5
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbz	w10, #6, LBB0_117
LBB0_110:                               ; %cond.store415
                                        ;   in Loop: Header=BB0_103 Depth=1
	fmov	x11, d6
	st1.s	{ v16 }[2], [x11]
	tbz	w10, #7, LBB0_102
	b	LBB0_118
LBB0_111:                               ; %else399
                                        ;   in Loop: Header=BB0_103 Depth=1
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_105
LBB0_112:                               ; %cond.store400
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x11, v18[1]
	st1.s	{ v17 }[1], [x11]
	add.2d	v18, v6, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbnz	w10, #2, LBB0_106
LBB0_113:                               ; %else405
                                        ;   in Loop: Header=BB0_103 Depth=1
	tbz	w10, #3, LBB0_107
LBB0_114:                               ; %cond.store406
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x11, v18[1]
	st1.s	{ v17 }[3], [x11]
	add.2d	v17, v6, v4
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v29
	shl.2d	v17, v17, #2
	add.2d	v17, v7, v17
	tbnz	w10, #4, LBB0_108
LBB0_115:                               ; %else411
                                        ;   in Loop: Header=BB0_103 Depth=1
	tbz	w10, #5, LBB0_109
LBB0_116:                               ; %cond.store412
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x11, v17[1]
	st1.s	{ v16 }[1], [x11]
	add.2d	v6, v6, v5
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbnz	w10, #6, LBB0_110
LBB0_117:                               ; %else417
                                        ;   in Loop: Header=BB0_103 Depth=1
	tbz	w10, #7, LBB0_102
LBB0_118:                               ; %cond.store418
                                        ;   in Loop: Header=BB0_103 Depth=1
	mov.d	x10, v6[1]
	st1.s	{ v16 }[3], [x10]
	b	LBB0_102
LBB0_119:
	add	sp, sp, #3232
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_120:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.full_packet
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention.full_packet:             ; @llm_attention.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2048
	mov	x8, #0                          ; =0x0
	ldr	x20, [x1, #136]
	ldr	x9, [x0]
	ldr	x19, [x0, #16]
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
	ldr	x11, [x0, #32]
	str	x11, [sp, #472]                 ; 8-byte Spill
	ldr	x11, [x0, #48]
	str	x11, [sp, #24]                  ; 8-byte Spill
	dup.4s	v0, w10
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
	add.4s	v3, v0, v1
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x10, lCPI0_1@PAGEOFF]
	add.4s	v2, v0, v1
	ushll2.2d	v1, v2, #0
	ushll2.2d	v0, v3, #0
	stp	q0, q1, [sp, #64]               ; 32-byte Folded Spill
	ushll.2d	v1, v2, #0
	ushll.2d	v0, v3, #0
	stp	q0, q1, [sp, #32]               ; 32-byte Folded Spill
	movi.4s	v1, #80
	umull2.2d	v0, v2, v1
	umull2.2d	v1, v3, v1
	movi.2s	v4, #80
	umull.2d	v2, v2, v4
	umull.2d	v3, v3, v4
	dup.2d	v4, x9
LBB0_1:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v5, x8
	add.2d	v6, v5, v0
	add.2d	v7, v5, v2
	add.2d	v16, v5, v1
	add.2d	v5, v5, v3
	shl.2d	v5, v5, #2
	shl.2d	v16, v16, #2
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	add.2d	v6, v4, v6
	add.2d	v7, v4, v7
	add.2d	v16, v4, v16
	add.2d	v5, v4, v5
	mov.d	x9, v5[1]
	fmov	x10, d5
	mov.d	x11, v16[1]
	fmov	x12, d16
	mov.d	x13, v7[1]
	fmov	x14, d7
	mov.d	x15, v6[1]
	ldr	s5, [x10]
	ld1.s	{ v5 }[1], [x9]
	fmov	x9, d6
	ld1.s	{ v5 }[2], [x12]
	ld1.s	{ v5 }[3], [x11]
	ldr	s6, [x14]
	ld1.s	{ v6 }[1], [x13]
	ld1.s	{ v6 }[2], [x9]
	ld1.s	{ v6 }[3], [x15]
	add	x9, x20, x8, lsl #5
	stp	q5, q6, [x9]
	add	x8, x8, #1
	cmp	x8, #80
	b.ne	LBB0_1
; %bb.2:                                ; %direct.true166.preheader
	add	x8, x20, #2560
	str	x8, [sp, #16]                   ; 8-byte Spill
	add	x0, x20, #2560
	mov	w1, #3072                       ; =0xc00
	bl	_bzero
	mov	x0, #0                          ; =0x0
	mov	w8, #8704                       ; =0x2200
	add	x24, x20, x8
	mov	w8, #49664                      ; =0xc200
	add	x25, x20, x8
	ldp	q2, q0, [sp, #64]               ; 32-byte Folded Reload
	shrn.2s	v0, v0, #2
	ldp	q3, q1, [sp, #32]               ; 32-byte Folded Reload
	shrn.2s	v1, v1, #2
	mov	w8, #2053                       ; =0x805
	shrn.2s	v2, v2, #2
	mov	w10, #62154                     ; =0xf2ca
	movk	w10, #61769, lsl #16
	add	x9, x20, #24, lsl #12           ; =98304
	shrn.2s	v3, v3, #2
	add	x11, x9, #512
	add	x9, x20, #24, lsl #12           ; =98304
	add	x9, x9, #544
	stp	x9, x11, [sp, #456]             ; 16-byte Folded Spill
	add	x9, x20, #24, lsl #12           ; =98304
	dup.2s	v4, w8
	add	x8, x9, #576
	str	x8, [sp, #448]                  ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	umull.2d	v5, v3, v4
	add	x8, x8, #608
	str	x8, [sp, #424]                  ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	umull.2d	v6, v2, v4
	add	x8, x8, #640
	str	x8, [sp, #392]                  ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	umull.2d	v7, v1, v4
	add	x8, x8, #672
	str	x8, [sp, #360]                  ; 8-byte Spill
	add	x8, x20, #24, lsl #12           ; =98304
	umull.2d	v16, v0, v4
	add	x9, x8, #704
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #736
	stp	x8, x9, [sp, #320]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	dup.4s	v1, w10
	add	x9, x8, #768
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #800
	stp	x8, x9, [sp, #304]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	dup.2d	v17, x19
	add	x9, x8, #832
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #864
	stp	x8, x9, [sp, #272]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x9, x8, #896
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #928
	stp	x8, x9, [sp, #256]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x9, x8, #960
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #992
	stp	x8, x9, [sp, #240]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x9, x8, #1024
	add	x8, x20, #24, lsl #12           ; =98304
	mvni.4s	v0, #63, msl #16
	add	x8, x8, #1056
	stp	x8, x9, [sp, #224]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	fneg.4s	v0, v0
	str	q0, [sp, #208]                  ; 16-byte Spill
	add	x9, x8, #1088
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1120
	stp	x8, x9, [sp, #192]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x9, x8, #1152
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1184
	stp	x8, x9, [sp, #176]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x9, x8, #1216
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1248
	stp	x8, x9, [sp, #160]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x9, x8, #1280
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1312
	stp	x8, x9, [sp, #144]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x9, x8, #1344
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1376
	stp	x8, x9, [sp, #128]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x9, x8, #1408
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1440
	stp	x8, x9, [sp, #112]              ; 16-byte Folded Spill
	add	x8, x20, #24, lsl #12           ; =98304
	add	x9, x8, #1472
	add	x8, x20, #24, lsl #12           ; =98304
	add	x8, x8, #1504
	stp	x8, x9, [sp, #96]               ; 16-byte Folded Spill
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	mov.16b	v0, v1
	mov	w26, #34304                     ; =0x8600
	movk	w26, #1, lsl #16
	mov	w1, #52429                      ; =0xcccd
	mov	w2, #80                         ; =0x50
	mov	w3, #43691                      ; =0xaaab
	mov	w4, #96                         ; =0x60
	mov	w5, #2560                       ; =0xa00
	movk	w5, #1, lsl #16
	mov	w6, #2592                       ; =0xa20
	movk	w6, #1, lsl #16
	mov	w7, #5632                       ; =0x1600
	movk	w7, #1, lsl #16
	mov	w30, #5664                      ; =0x1620
	movk	w30, #1, lsl #16
	mov	w21, #24096                     ; =0x5e20
	movk	w21, #1, lsl #16
	mov	w19, #27136                     ; =0x6a00
	movk	w19, #1, lsl #16
	mov	w27, #27168                     ; =0x6a20
	movk	w27, #1, lsl #16
	mov	w22, #30208                     ; =0x7600
	movk	w22, #1, lsl #16
	mov	w28, #30240                     ; =0x7620
	movk	w28, #1, lsl #16
	mov	w23, #34336                     ; =0x8620
	movk	w23, #1, lsl #16
	str	q5, [sp, #432]                  ; 16-byte Spill
	str	q6, [sp, #400]                  ; 16-byte Spill
	str	q7, [sp, #368]                  ; 16-byte Spill
	str	q16, [sp, #336]                 ; 16-byte Spill
	str	q17, [sp, #288]                 ; 16-byte Spill
LBB0_3:                                 ; %direct.true176
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_12 Depth 2
                                        ;     Child Loop BB0_14 Depth 2
                                        ;     Child Loop BB0_16 Depth 2
                                        ;     Child Loop BB0_18 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
                                        ;     Child Loop BB0_22 Depth 2
                                        ;     Child Loop BB0_24 Depth 2
                                        ;     Child Loop BB0_26 Depth 2
                                        ;     Child Loop BB0_28 Depth 2
                                        ;     Child Loop BB0_30 Depth 2
                                        ;     Child Loop BB0_32 Depth 2
                                        ;     Child Loop BB0_34 Depth 2
                                        ;     Child Loop BB0_36 Depth 2
                                        ;     Child Loop BB0_38 Depth 2
                                        ;     Child Loop BB0_40 Depth 2
                                        ;     Child Loop BB0_42 Depth 2
                                        ;     Child Loop BB0_44 Depth 2
	str	q0, [sp, #1968]                 ; 16-byte Spill
	str	q1, [sp, #1984]                 ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	lsl	x8, x0, #4
	ldr	x17, [sp, #472]                 ; 8-byte Reload
	b	LBB0_5
LBB0_4:                                 ; %direct.schedule.12
                                        ;   in Loop: Header=BB0_5 Depth=2
	add	x10, x24, x9, lsl #5
	stp	q0, q1, [x10]
	add	x9, x9, #1
	cmp	x9, #1280
	b.eq	LBB0_7
LBB0_5:                                 ; %direct.true180
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w10, w9, #0xffff
	mul	w10, w10, w1
	lsr	w10, w10, #22
	add	x11, x8, x10
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	cmp	x11, #2052
	b.hi	LBB0_4
; %bb.6:                                ; %direct.true193
                                        ;   in Loop: Header=BB0_5 Depth=2
	dup.2d	v0, x11
	add.2d	v1, v0, v16
	add.2d	v2, v0, v7
	add.2d	v3, v0, v6
	add.2d	v0, v0, v5
	mov.d	x11, v0[1]
	fmov	x12, d0
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d0, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v0[1], x11
	mov.d	x11, v3[1]
	fmov	x12, d3
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d3, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v3[1], x11
	mov.d	x11, v2[1]
	fmov	x12, d2
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d2, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v2[1], x11
	mov.d	x11, v1[1]
	fmov	x12, d1
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d1, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v1[1], x11
	msub	w10, w10, w2, w9
	and	x10, x10, #0xffff
	dup.2d	v4, x10
	add.2d	v1, v1, v4
	add.2d	v2, v2, v4
	add.2d	v3, v3, v4
	add.2d	v0, v0, v4
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	add.2d	v1, v17, v1
	add.2d	v2, v17, v2
	add.2d	v3, v17, v3
	add.2d	v0, v17, v0
	mov.d	x10, v0[1]
	fmov	x11, d0
	mov.d	x12, v3[1]
	fmov	x13, d3
	mov.d	x14, v2[1]
	fmov	x15, d2
	mov.d	x16, v1[1]
	ldr	s0, [x11]
	ld1.s	{ v0 }[1], [x10]
	fmov	x10, d1
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x12]
	ldr	s1, [x15]
	ld1.s	{ v1 }[1], [x14]
	ld1.s	{ v1 }[2], [x10]
	ld1.s	{ v1 }[3], [x16]
	b	LBB0_4
LBB0_7:                                 ; %direct.true205.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	mov	w1, #20992                      ; =0x5200
	movk	w1, #1, lsl #16
	mov	w2, #21024                      ; =0x5220
	movk	w2, #1, lsl #16
	b	LBB0_9
LBB0_8:                                 ; %direct.schedule.17
                                        ;   in Loop: Header=BB0_9 Depth=2
	add	x10, x25, x9, lsl #5
	stp	q0, q1, [x10]
	add	x9, x9, #1
	cmp	x9, #1536
	b.eq	LBB0_11
LBB0_9:                                 ; %direct.true205
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w10, w9, #0xffff
	mul	w10, w10, w3
	lsr	w10, w10, #22
	add	x11, x8, x10
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	cmp	x11, #2052
	b.hi	LBB0_8
; %bb.10:                               ; %direct.true218
                                        ;   in Loop: Header=BB0_9 Depth=2
	dup.2d	v0, x11
	add.2d	v1, v0, v16
	add.2d	v2, v0, v7
	add.2d	v3, v0, v6
	add.2d	v0, v0, v5
	mov.d	x11, v0[1]
	fmov	x12, d0
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d0, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v0[1], x11
	mov.d	x11, v3[1]
	fmov	x12, d3
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d3, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v3[1], x11
	mov.d	x11, v2[1]
	fmov	x12, d2
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d2, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v2[1], x11
	mov.d	x11, v1[1]
	fmov	x12, d1
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d1, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v1[1], x11
	msub	w10, w10, w4, w9
	and	x10, x10, #0xffff
	dup.2d	v4, x10
	add.2d	v1, v1, v4
	add.2d	v2, v2, v4
	add.2d	v3, v3, v4
	add.2d	v0, v0, v4
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v4, x17
	add.2d	v1, v4, v1
	add.2d	v2, v4, v2
	add.2d	v3, v4, v3
	add.2d	v0, v4, v0
	mov.d	x10, v0[1]
	fmov	x11, d0
	mov.d	x12, v3[1]
	fmov	x13, d3
	mov.d	x14, v2[1]
	fmov	x15, d2
	mov.d	x16, v1[1]
	ldr	s0, [x11]
	ld1.s	{ v0 }[1], [x10]
	fmov	x10, d1
	ld1.s	{ v0 }[2], [x13]
	ld1.s	{ v0 }[3], [x12]
	ldr	s1, [x15]
	ld1.s	{ v1 }[1], [x14]
	ld1.s	{ v1 }[2], [x10]
	ld1.s	{ v1 }[3], [x16]
	b	LBB0_8
LBB0_11:                                ; %direct.true230.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v0, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v1, #0000000000000000
LBB0_12:                                ; %direct.true230
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q3, q2, [x8]
	ldr	q4, [x8, #8720]
	ldr	q5, [x8, #8704]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_12
; %bb.13:                               ; %direct.true245.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v2, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v3, #0000000000000000
	mov	w12, #8736                      ; =0x2220
	movk	w12, #1, lsl #16
	mov	w13, #11776                     ; =0x2e00
	movk	w13, #1, lsl #16
	mov	w14, #11808                     ; =0x2e20
	movk	w14, #1, lsl #16
	mov	w15, #14848                     ; =0x3a00
	movk	w15, #1, lsl #16
	mov	w16, #14880                     ; =0x3a20
	movk	w16, #1, lsl #16
	mov	w17, #17920                     ; =0x4600
	movk	w17, #1, lsl #16
	mov	w3, #24064                      ; =0x5e00
	movk	w3, #1, lsl #16
LBB0_14:                                ; %direct.true245
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q5, q4, [x8]
	ldr	q6, [x8, #11280]
	ldr	q7, [x8, #11264]
	fmul.4s	v5, v5, v7
	fmul.4s	v4, v4, v6
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v5
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_14
; %bb.15:                               ; %direct.true262.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q19, [sp, #1504]                ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v5, #0000000000000000
	mov	w11, #8704                      ; =0x2200
	movk	w11, #1, lsl #16
LBB0_16:                                ; %direct.true262
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q7, q6, [x8]
	ldr	q16, [x8, #13840]
	ldr	q17, [x8, #13824]
	fmul.4s	v7, v7, v17
	fmul.4s	v6, v6, v16
	fadd.4s	v4, v4, v6
	fadd.4s	v5, v5, v7
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_16
; %bb.17:                               ; %direct.true279.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q20, [sp, #1488]                ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v7, #0000000000000000
LBB0_18:                                ; %direct.true279
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q17, q16, [x8]
	ldr	q18, [x8, #16400]
	ldr	q19, [x8, #16384]
	fmul.4s	v17, v17, v19
	fmul.4s	v16, v16, v18
	fadd.4s	v6, v6, v16
	fadd.4s	v7, v7, v17
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_18
; %bb.19:                               ; %direct.true296.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v16, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v17, #0000000000000000
LBB0_20:                                ; %direct.true296
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q19, q18, [x8]
	ldr	q20, [x8, #18960]
	ldr	q21, [x8, #18944]
	fmul.4s	v19, v19, v21
	fmul.4s	v18, v18, v20
	fadd.4s	v16, v16, v18
	fadd.4s	v17, v17, v19
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_20
; %bb.21:                               ; %direct.true313.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v18, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v19, #0000000000000000
LBB0_22:                                ; %direct.true313
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q21, q20, [x8]
	ldr	q22, [x8, #21520]
	ldr	q23, [x8, #21504]
	fmul.4s	v21, v21, v23
	fmul.4s	v20, v20, v22
	fadd.4s	v18, v18, v20
	fadd.4s	v19, v19, v21
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_22
; %bb.23:                               ; %direct.true330.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v20, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v21, #0000000000000000
LBB0_24:                                ; %direct.true330
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q23, q22, [x8]
	ldr	q24, [x8, #24080]
	ldr	q25, [x8, #24064]
	fmul.4s	v23, v23, v25
	fmul.4s	v22, v22, v24
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v23
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_24
; %bb.25:                               ; %direct.true347.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v22, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v23, #0000000000000000
LBB0_26:                                ; %direct.true347
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q25, q24, [x8]
	ldr	q26, [x8, #26640]
	ldr	q27, [x8, #26624]
	fmul.4s	v25, v25, v27
	fmul.4s	v24, v24, v26
	fadd.4s	v22, v22, v24
	fadd.4s	v23, v23, v25
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_26
; %bb.27:                               ; %direct.true364.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v24, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v25, #0000000000000000
LBB0_28:                                ; %direct.true364
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q27, q26, [x8]
	ldr	q28, [x8, #29200]
	ldr	q29, [x8, #29184]
	fmul.4s	v27, v27, v29
	fmul.4s	v26, v26, v28
	fadd.4s	v24, v24, v26
	fadd.4s	v25, v25, v27
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_28
; %bb.29:                               ; %direct.true381.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v26, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v27, #0000000000000000
LBB0_30:                                ; %direct.true381
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q29, q28, [x8]
	ldr	q30, [x8, #31760]
	ldr	q31, [x8, #31744]
	fmul.4s	v29, v29, v31
	fmul.4s	v28, v28, v30
	fadd.4s	v26, v26, v28
	fadd.4s	v27, v27, v29
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_30
; %bb.31:                               ; %direct.true398.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v28, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v29, #0000000000000000
LBB0_32:                                ; %direct.true398
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q31, q30, [x8]
	ldr	q8, [x8, #34320]
	ldr	q9, [x8, #34304]
	fmul.4s	v31, v31, v9
	fmul.4s	v30, v30, v8
	fadd.4s	v28, v28, v30
	fadd.4s	v29, v29, v31
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_32
; %bb.33:                               ; %direct.true415.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v30, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v31, #0000000000000000
LBB0_34:                                ; %direct.true415
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q9, q8, [x8]
	ldr	q10, [x8, #36880]
	ldr	q11, [x8, #36864]
	fmul.4s	v9, v9, v11
	fmul.4s	v8, v8, v10
	fadd.4s	v30, v30, v8
	fadd.4s	v31, v31, v9
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_34
; %bb.35:                               ; %direct.true432.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v8, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v9, #0000000000000000
LBB0_36:                                ; %direct.true432
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q11, q10, [x8]
	ldr	q12, [x8, #39440]
	ldr	q13, [x8, #39424]
	fmul.4s	v11, v11, v13
	fmul.4s	v10, v10, v12
	fadd.4s	v8, v8, v10
	fadd.4s	v9, v9, v11
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_36
; %bb.37:                               ; %direct.true449.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q3, [sp, #1952]                 ; 16-byte Spill
	str	q2, [sp, #2000]                 ; 16-byte Spill
	str	q1, [sp, #2016]                 ; 16-byte Spill
	str	q0, [sp, #2032]                 ; 16-byte Spill
	movi.2d	v10, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v11, #0000000000000000
LBB0_38:                                ; %direct.true449
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q13, q12, [x8]
	ldr	q14, [x8, #42000]
	ldr	q15, [x8, #41984]
	fmul.4s	v13, v13, v15
	fmul.4s	v12, v12, v14
	fadd.4s	v10, v10, v12
	fadd.4s	v11, v11, v13
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_38
; %bb.39:                               ; %direct.true466.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v12, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v13, #0000000000000000
LBB0_40:                                ; %direct.true466
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q15, q14, [x8]
	ldr	q0, [x8, #44560]
	ldr	q1, [x8, #44544]
	fmul.4s	v1, v15, v1
	fmul.4s	v0, v14, v0
	fadd.4s	v12, v12, v0
	fadd.4s	v13, v13, v1
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_40
; %bb.41:                               ; %direct.true483.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi.2d	v14, #0000000000000000
	mov	x8, x20
	mov	w9, #80                         ; =0x50
	movi.2d	v15, #0000000000000000
LBB0_42:                                ; %direct.true483
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8]
	ldr	q2, [x8, #47120]
	ldr	q3, [x8, #47104]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	fadd.4s	v14, v14, v0
	fadd.4s	v15, v15, v1
	add	x8, x8, #32
	subs	x9, x9, #1
	b.ne	LBB0_42
; %bb.43:                               ; %direct.false484
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w8, #63790                      ; =0xf92e
	movk	w8, #15844, lsl #16
	dup.4s	v0, w8
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1792]                 ; 16-byte Spill
	ldr	q1, [sp, #2032]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1616]                 ; 16-byte Spill
	ldr	q1, [sp, #1952]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1600]                 ; 16-byte Spill
	ldr	q1, [sp, #2000]                 ; 16-byte Reload
	fmul.4s	v1, v1, v0
	str	q1, [sp, #1584]                 ; 16-byte Spill
	fmul.4s	v1, v5, v0
	str	q1, [sp, #1568]                 ; 16-byte Spill
	fmul.4s	v1, v4, v0
	str	q1, [sp, #1552]                 ; 16-byte Spill
	fmul.4s	v1, v7, v0
	str	q1, [sp, #2032]                 ; 16-byte Spill
	fmul.4s	v1, v6, v0
	str	q1, [sp, #1536]                 ; 16-byte Spill
	fmul.4s	v1, v17, v0
	str	q1, [sp, #2016]                 ; 16-byte Spill
	fmul.4s	v1, v16, v0
	str	q1, [sp, #2000]                 ; 16-byte Spill
	fmul.4s	v1, v18, v0
	fmul.4s	v2, v19, v0
	fmul.4s	v3, v20, v0
	fmul.4s	v5, v21, v0
	fmul.4s	v6, v22, v0
	fmul.4s	v7, v23, v0
	fmul.4s	v16, v24, v0
	fmul.4s	v17, v25, v0
	fmul.4s	v18, v26, v0
	fmul.4s	v19, v27, v0
	fmul.4s	v20, v28, v0
	fmul.4s	v21, v29, v0
	fmul.4s	v22, v30, v0
	fmul.4s	v23, v31, v0
	fmul.4s	v24, v8, v0
	fmul.4s	v25, v9, v0
	fmul.4s	v26, v10, v0
	fmul.4s	v27, v11, v0
	fmul.4s	v28, v12, v0
	fmul.4s	v29, v13, v0
	fmul.4s	v30, v14, v0
	fmul.4s	v0, v15, v0
	str	x0, [sp, #1528]                 ; 8-byte Spill
	cmp	x0, #128
	cset	w8, lo
	dup.4h	v4, w8
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v8, v4, #0
	str	q8, [sp, #560]                  ; 16-byte Spill
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v31, w8
	bif.16b	v2, v31, v8
	str	q2, [sp, #1952]                 ; 16-byte Spill
	mov.16b	v11, v8
	bsl.16b	v11, v1, v31
	mov.16b	v4, v8
	bsl.16b	v4, v5, v31
	str	q4, [sp, #1872]                 ; 16-byte Spill
	mov.16b	v10, v8
	bsl.16b	v10, v3, v31
	str	q10, [sp, #1632]                ; 16-byte Spill
	mov.16b	v3, v8
	bsl.16b	v3, v7, v31
	str	q3, [sp, #1936]                 ; 16-byte Spill
	mov.16b	v9, v8
	bsl.16b	v9, v6, v31
	str	q9, [sp, #1648]                 ; 16-byte Spill
	mov.16b	v5, v8
	bsl.16b	v5, v17, v31
	str	q5, [sp, #1856]                 ; 16-byte Spill
	bif.16b	v16, v31, v8
	str	q16, [sp, #1664]                ; 16-byte Spill
	mov.16b	v7, v8
	bsl.16b	v7, v19, v31
	str	q7, [sp, #1920]                 ; 16-byte Spill
	bif.16b	v18, v31, v8
	str	q18, [sp, #1680]                ; 16-byte Spill
	mov.16b	v17, v8
	bsl.16b	v17, v21, v31
	str	q17, [sp, #1840]                ; 16-byte Spill
	bif.16b	v20, v31, v8
	str	q20, [sp, #1696]                ; 16-byte Spill
	mov.16b	v19, v8
	bsl.16b	v19, v23, v31
	str	q19, [sp, #1904]                ; 16-byte Spill
	bif.16b	v22, v31, v8
	str	q22, [sp, #1712]                ; 16-byte Spill
	mov.16b	v21, v8
	bsl.16b	v21, v25, v31
	str	q21, [sp, #1824]                ; 16-byte Spill
	bif.16b	v24, v31, v8
	str	q24, [sp, #1728]                ; 16-byte Spill
	mov.16b	v23, v8
	bsl.16b	v23, v27, v31
	str	q23, [sp, #1888]                ; 16-byte Spill
	mov.16b	v27, v8
	bsl.16b	v27, v26, v31
	str	q27, [sp, #1744]                ; 16-byte Spill
	mov.16b	v25, v8
	bsl.16b	v25, v29, v31
	str	q25, [sp, #1808]                ; 16-byte Spill
	mov.16b	v6, v8
	bsl.16b	v6, v28, v31
	str	q6, [sp, #1760]                 ; 16-byte Spill
	mov.16b	v12, v8
	bsl.16b	v12, v0, v31
	str	q12, [sp, #1312]                ; 16-byte Spill
	bit.16b	v31, v30, v8
	str	q31, [sp, #1776]                ; 16-byte Spill
	mvni.4s	v26, #127, msl #16
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	fmaxnm.4s	v0, v1, v26
	ldr	q28, [sp, #1600]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v28
	ldr	q29, [sp, #1568]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v29
	ldr	q30, [sp, #2032]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v30
	ldr	q30, [sp, #2016]                ; 16-byte Reload
	fmaxnm.4s	v0, v0, v30
	fmaxnm.4s	v0, v0, v2
	fmaxnm.4s	v0, v0, v4
	fmaxnm.4s	v0, v0, v3
	fmaxnm.4s	v0, v0, v5
	fmaxnm.4s	v0, v0, v7
	fmaxnm.4s	v0, v0, v17
	fmaxnm.4s	v0, v0, v19
	fmaxnm.4s	v0, v0, v21
	fmaxnm.4s	v0, v0, v23
	fmaxnm.4s	v0, v0, v25
	fmaxnm.4s	v0, v0, v12
	ldr	q2, [sp, #1984]                 ; 16-byte Reload
	fmaxnm.4s	v12, v2, v0
	fsub.4s	v0, v1, v12
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v1, w8
	fcmge.4s	v2, v0, v1
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v4, w8
	fcmge.4s	v3, v4, v0
	and.16b	v2, v2, v3
	ldr	q5, [sp, #1616]                 ; 16-byte Reload
	fmaxnm.4s	v3, v5, v26
	ldr	q13, [sp, #1584]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v13
	ldr	q14, [sp, #1552]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v14
	ldr	q15, [sp, #1536]                ; 16-byte Reload
	fmaxnm.4s	v3, v3, v15
	ldr	q7, [sp, #2000]                 ; 16-byte Reload
	fmaxnm.4s	v3, v3, v7
	fmaxnm.4s	v3, v3, v11
	str	q11, [sp, #1104]                ; 16-byte Spill
	fmaxnm.4s	v3, v3, v10
	fmaxnm.4s	v3, v3, v9
	fmaxnm.4s	v3, v3, v16
	fmaxnm.4s	v3, v3, v18
	fmaxnm.4s	v3, v3, v20
	fmaxnm.4s	v3, v3, v22
	fmaxnm.4s	v3, v3, v24
	fmaxnm.4s	v3, v3, v27
	fmaxnm.4s	v3, v3, v6
	fmaxnm.4s	v3, v3, v31
	ldr	q6, [sp, #1968]                 ; 16-byte Reload
	fmaxnm.4s	v30, v6, v3
	fsub.4s	v10, v5, v30
	fcmge.4s	v3, v10, v1
	fcmge.4s	v5, v4, v10
	and.16b	v3, v3, v5
	and.16b	v3, v3, v10
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v22, w8
	fmul.4s	v5, v3, v22
	movi.4s	v7, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v6, v16
	bsl.16b	v6, v7, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v2, v0
	fmul.4s	v2, v6, v22
	bif.16b	v7, v2, v16
	fadd.4s	v2, v2, v7
	fsub.4s	v7, v2, v7
	fcvtzs.4s	v2, v5
	scvtf.4s	v5, v2
	mov	w8, #29184                      ; =0x7200
	movk	w8, #16177, lsl #16
	dup.4s	v21, w8
	fmul.4s	v16, v5, v21
	fsub.4s	v16, v3, v16
	fcvtzs.4s	v3, v7
	scvtf.4s	v7, v3
	fmul.4s	v17, v7, v21
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #13759, lsl #16
	dup.4s	v19, w8
	fsub.4s	v6, v6, v17
	fmul.4s	v7, v7, v19
	fsub.4s	v20, v6, v7
	fmul.4s	v5, v5, v19
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v18, w8
	fsub.4s	v5, v16, v5
	fmul.4s	v6, v5, v18
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v17, w8
	fadd.4s	v6, v6, v17
	fmul.4s	v6, v5, v6
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v16, w8
	fadd.4s	v6, v6, v16
	fmul.4s	v6, v5, v6
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v7, w8
	fadd.4s	v6, v6, v7
	fmul.4s	v23, v5, v6
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v6, w8
	fadd.4s	v23, v23, v6
	fmul.4s	v23, v5, v23
	movi.4s	v31, #63, lsl #24
	fadd.4s	v23, v23, v31
	fmul.4s	v24, v5, v5
	fmul.4s	v23, v24, v23
	fmul.4s	v24, v20, v18
	fadd.4s	v24, v24, v17
	fmul.4s	v24, v20, v24
	fadd.4s	v24, v24, v16
	fmul.4s	v24, v20, v24
	fadd.4s	v24, v24, v7
	fmul.4s	v24, v20, v24
	fadd.4s	v24, v24, v6
	fmul.4s	v24, v20, v24
	fadd.4s	v24, v24, v31
	fmul.4s	v25, v20, v20
	fmul.4s	v24, v25, v24
	fadd.4s	v20, v20, v24
	fadd.4s	v5, v5, v23
	fmov.4s	v27, #1.00000000
	fadd.4s	v20, v20, v27
	sshr.4s	v23, v3, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v27
	fmul.4s	v20, v20, v24
	fadd.4s	v5, v5, v27
	sshr.4s	v24, v2, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v27
	fmul.4s	v5, v5, v25
	sub.4s	v3, v3, v23
	sub.4s	v2, v2, v24
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v5, v2
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	str	q0, [sp, #1392]                 ; 16-byte Spill
	fcmgt.4s	v5, v1, v0
	bic.16b	v3, v3, v5
	str	q10, [sp, #1440]                ; 16-byte Spill
	fcmgt.4s	v5, v1, v10
	bic.16b	v2, v2, v5
	fcmgt.4s	v20, v10, v4
	fneg.4s	v5, v26
	bit.16b	v2, v5, v20
	str	q2, [sp, #1424]                 ; 16-byte Spill
	fcmgt.4s	v2, v0, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1408]                 ; 16-byte Spill
	fsub.4s	v28, v28, v12
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	fsub.4s	v10, v13, v30
	fcmge.4s	v3, v10, v1
	fcmge.4s	v20, v4, v10
	and.16b	v3, v3, v20
	and.16b	v3, v3, v10
	fmul.4s	v20, v3, v22
	movi.4s	v0, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v23, v24
	bsl.16b	v23, v0, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v22
	bsl.16b	v24, v0, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	str	q28, [sp, #1328]                ; 16-byte Spill
	fcmgt.4s	v20, v1, v28
	bic.16b	v3, v3, v20
	str	q10, [sp, #1360]                ; 16-byte Spill
	fcmgt.4s	v20, v1, v10
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v10, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1376]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1344]                 ; 16-byte Spill
	fsub.4s	v28, v29, v12
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	fsub.4s	v0, v14, v30
	fcmge.4s	v3, v0, v1
	fcmge.4s	v20, v4, v0
	and.16b	v3, v3, v20
	and.16b	v3, v3, v0
	fmul.4s	v20, v3, v22
	movi.4s	v24, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v23, v25
	bsl.16b	v23, v24, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v22
	bif.16b	v24, v2, v25
	mvni.4s	v29, #128, lsl #24
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	str	q28, [sp, #1248]                ; 16-byte Spill
	fcmgt.4s	v20, v1, v28
	bic.16b	v3, v3, v20
	str	q0, [sp, #1280]                 ; 16-byte Spill
	fcmgt.4s	v20, v1, v0
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v0, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1296]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1264]                 ; 16-byte Spill
	ldr	q0, [sp, #2032]                 ; 16-byte Reload
	fsub.4s	v28, v0, v12
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	fsub.4s	v0, v15, v30
	fcmge.4s	v3, v0, v1
	fcmge.4s	v20, v4, v0
	and.16b	v3, v3, v20
	and.16b	v3, v3, v0
	fmul.4s	v20, v3, v22
	movi.4s	v24, #75, lsl #24
	mov.16b	v23, v29
	bsl.16b	v23, v24, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v22
	bif.16b	v24, v2, v29
	movi.4s	v9, #75, lsl #24
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	str	q28, [sp, #1184]                ; 16-byte Spill
	fcmgt.4s	v20, v1, v28
	bic.16b	v3, v3, v20
	str	q0, [sp, #1216]                 ; 16-byte Spill
	fcmgt.4s	v20, v1, v0
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v0, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1232]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1200]                 ; 16-byte Spill
	ldr	q0, [sp, #2016]                 ; 16-byte Reload
	fsub.4s	v28, v0, v12
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q0, [sp, #2000]                 ; 16-byte Reload
	fsub.4s	v0, v0, v30
	fcmge.4s	v3, v0, v1
	fcmge.4s	v20, v4, v0
	and.16b	v3, v3, v20
	and.16b	v3, v3, v0
	fmul.4s	v20, v3, v22
	mov.16b	v23, v29
	bsl.16b	v23, v9, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v22
	mov.16b	v24, v29
	bsl.16b	v24, v9, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	str	q28, [sp, #1120]                ; 16-byte Spill
	fcmgt.4s	v20, v1, v28
	bic.16b	v3, v3, v20
	str	q0, [sp, #1152]                 ; 16-byte Spill
	fcmgt.4s	v20, v1, v0
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v0, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1168]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1136]                 ; 16-byte Spill
	fsub.4s	v28, v11, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	mov.16b	v9, v12
	fsub.4s	v29, v3, v12
	fcmge.4s	v3, v29, v1
	fcmge.4s	v20, v4, v29
	and.16b	v3, v3, v20
	and.16b	v3, v3, v29
	fmul.4s	v20, v3, v22
	mvni.4s	v0, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v23, v0
	bsl.16b	v23, v24, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v22
	bif.16b	v24, v2, v0
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	str	q28, [sp, #1040]                ; 16-byte Spill
	fcmgt.4s	v20, v1, v28
	bic.16b	v3, v3, v20
	str	q29, [sp, #1072]                ; 16-byte Spill
	fcmgt.4s	v20, v1, v29
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v29, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1088]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #1056]                 ; 16-byte Spill
	ldr	q0, [sp, #1632]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	fsub.4s	v0, v3, v12
	fcmge.4s	v3, v0, v1
	fcmge.4s	v20, v4, v0
	and.16b	v3, v3, v20
	and.16b	v3, v3, v0
	fmul.4s	v20, v3, v22
	movi.4s	v24, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v23, v25
	bsl.16b	v23, v24, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v22
	bif.16b	v24, v2, v25
	mvni.4s	v29, #128, lsl #24
	movi.4s	v10, #75, lsl #24
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	fcmgt.4s	v20, v1, v28
	bic.16b	v3, v3, v20
	str	q0, [sp, #1008]                 ; 16-byte Spill
	fcmgt.4s	v20, v1, v0
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v0, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	str	q0, [sp, #1024]                 ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q28, q0, [sp, #976]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1648]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	fsub.4s	v0, v3, v12
	fcmge.4s	v3, v0, v1
	fcmge.4s	v20, v4, v0
	and.16b	v3, v3, v20
	and.16b	v3, v3, v0
	fmul.4s	v20, v3, v22
	mov.16b	v23, v29
	bsl.16b	v23, v10, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v22
	mov.16b	v24, v29
	bsl.16b	v24, v10, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	fcmgt.4s	v20, v1, v28
	bic.16b	v3, v3, v20
	str	q0, [sp, #944]                  ; 16-byte Spill
	fcmgt.4s	v20, v1, v0
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v0, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	str	q0, [sp, #960]                  ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q28, q0, [sp, #912]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1664]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	fsub.4s	v29, v3, v12
	fcmge.4s	v3, v29, v1
	fcmge.4s	v20, v4, v29
	and.16b	v3, v3, v20
	and.16b	v3, v3, v29
	fmul.4s	v20, v3, v22
	mvni.4s	v0, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v23, v0
	bsl.16b	v23, v24, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v22
	bif.16b	v24, v2, v0
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	fcmgt.4s	v20, v1, v28
	bic.16b	v3, v3, v20
	fcmgt.4s	v20, v1, v29
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v29, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	stp	q29, q0, [sp, #880]             ; 32-byte Folded Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q28, q0, [sp, #848]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1680]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	fsub.4s	v0, v3, v12
	fcmge.4s	v3, v0, v1
	fcmge.4s	v20, v4, v0
	and.16b	v3, v3, v20
	and.16b	v3, v3, v0
	fmul.4s	v20, v3, v22
	movi.4s	v24, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v23, v25
	bsl.16b	v23, v24, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v22
	bif.16b	v24, v2, v25
	mvni.4s	v29, #128, lsl #24
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	fcmgt.4s	v20, v1, v28
	bic.16b	v3, v3, v20
	str	q0, [sp, #816]                  ; 16-byte Spill
	fcmgt.4s	v20, v1, v0
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v0, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	str	q0, [sp, #832]                  ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q28, q0, [sp, #784]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1696]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	fsub.4s	v0, v3, v12
	fcmge.4s	v3, v0, v1
	fcmge.4s	v20, v4, v0
	and.16b	v3, v3, v20
	and.16b	v3, v3, v0
	fmul.4s	v20, v3, v22
	mov.16b	v23, v29
	bsl.16b	v23, v10, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v22
	mov.16b	v24, v29
	bsl.16b	v24, v10, v2
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	fcmgt.4s	v20, v1, v28
	bic.16b	v3, v3, v20
	str	q0, [sp, #752]                  ; 16-byte Spill
	fcmgt.4s	v20, v1, v0
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v0, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	str	q0, [sp, #768]                  ; 16-byte Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q28, q0, [sp, #720]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1712]                 ; 16-byte Reload
	fsub.4s	v28, v0, v30
	fcmge.4s	v2, v28, v1
	fcmge.4s	v3, v4, v28
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	fsub.4s	v29, v3, v12
	fcmge.4s	v3, v29, v1
	fcmge.4s	v20, v4, v29
	and.16b	v3, v3, v20
	and.16b	v3, v3, v29
	fmul.4s	v20, v3, v22
	mvni.4s	v0, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v23, v0
	bsl.16b	v23, v24, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v28
	fmul.4s	v2, v23, v22
	bif.16b	v24, v2, v0
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	fcmgt.4s	v20, v1, v28
	bic.16b	v3, v3, v20
	fcmgt.4s	v20, v1, v29
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v29, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	stp	q29, q0, [sp, #688]             ; 32-byte Folded Spill
	fcmgt.4s	v2, v28, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	stp	q28, q0, [sp, #656]             ; 32-byte Folded Spill
	ldr	q0, [sp, #1728]                 ; 16-byte Reload
	fsub.4s	v0, v0, v30
	fcmge.4s	v2, v0, v1
	fcmge.4s	v3, v4, v0
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1824]                 ; 16-byte Reload
	fsub.4s	v28, v3, v12
	fcmge.4s	v3, v28, v1
	fcmge.4s	v20, v4, v28
	and.16b	v3, v3, v20
	and.16b	v3, v3, v28
	fmul.4s	v20, v3, v22
	movi.4s	v24, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v23, v25
	bsl.16b	v23, v24, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v0
	fmul.4s	v2, v23, v22
	bif.16b	v24, v2, v25
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v21
	fsub.4s	v23, v23, v26
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v27
	fmul.4s	v3, v3, v26
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	str	q0, [sp, #608]                  ; 16-byte Spill
	fcmgt.4s	v20, v1, v0
	bic.16b	v3, v3, v20
	fcmgt.4s	v20, v1, v28
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v28, v4
	bit.16b	v2, v5, v20
	str	q2, [sp, #640]                  ; 16-byte Spill
	fcmgt.4s	v2, v0, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #624]                  ; 16-byte Spill
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	fsub.4s	v12, v0, v30
	fcmge.4s	v2, v12, v1
	fcmge.4s	v3, v4, v12
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1888]                 ; 16-byte Reload
	fsub.4s	v26, v3, v9
	fcmge.4s	v3, v26, v1
	fcmge.4s	v20, v4, v26
	and.16b	v3, v3, v20
	and.16b	v3, v3, v26
	fmul.4s	v20, v3, v22
	mvni.4s	v0, #128, lsl #24
	movi.4s	v24, #75, lsl #24
	mov.16b	v23, v0
	bsl.16b	v23, v24, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v12
	fmul.4s	v2, v23, v22
	bif.16b	v24, v2, v0
	movi.4s	v29, #75, lsl #24
	fadd.4s	v2, v2, v24
	fsub.4s	v24, v2, v24
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v25, v20, v21
	fsub.4s	v3, v3, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v10, v25, v21
	fsub.4s	v23, v23, v10
	fmul.4s	v25, v25, v19
	fsub.4s	v23, v23, v25
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v25, v3, v3
	fmul.4s	v20, v25, v20
	fmul.4s	v25, v23, v18
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v6
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v10, v23, v23
	fmul.4s	v25, v10, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v24, #1
	shl.4s	v25, v23, #23
	add.4s	v25, v25, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v3, v3, v27
	sshr.4s	v25, v2, #1
	shl.4s	v10, v25, #23
	add.4s	v10, v10, v27
	fmul.4s	v3, v3, v10
	sub.4s	v23, v24, v23
	sub.4s	v2, v2, v25
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	fcmgt.4s	v20, v1, v12
	bic.16b	v3, v3, v20
	fcmgt.4s	v20, v1, v26
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v26, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	str	q0, [sp, #592]                  ; 16-byte Spill
	fcmgt.4s	v2, v12, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #576]                  ; 16-byte Spill
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	fsub.4s	v25, v0, v30
	fcmge.4s	v2, v25, v1
	fcmge.4s	v3, v4, v25
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	fsub.4s	v24, v3, v9
	fcmge.4s	v3, v24, v1
	fcmge.4s	v20, v4, v24
	and.16b	v3, v3, v20
	and.16b	v3, v3, v24
	fmul.4s	v20, v3, v22
	mvni.4s	v0, #128, lsl #24
	mov.16b	v23, v0
	bsl.16b	v23, v29, v20
	fadd.4s	v20, v20, v23
	fsub.4s	v20, v20, v23
	and.16b	v23, v2, v25
	fmul.4s	v2, v23, v22
	mov.16b	v10, v0
	bsl.16b	v10, v29, v2
	mvni.4s	v8, #128, lsl #24
	fadd.4s	v2, v2, v10
	fsub.4s	v10, v2, v10
	fcvtzs.4s	v2, v20
	scvtf.4s	v20, v2
	fmul.4s	v11, v20, v21
	fsub.4s	v3, v3, v11
	fcvtzs.4s	v10, v10
	scvtf.4s	v11, v10
	fmul.4s	v15, v11, v21
	fsub.4s	v23, v23, v15
	fmul.4s	v11, v11, v19
	fsub.4s	v23, v23, v11
	fmul.4s	v20, v20, v19
	fsub.4s	v3, v3, v20
	fmul.4s	v20, v3, v18
	fadd.4s	v20, v20, v17
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v6
	fmul.4s	v20, v3, v20
	fadd.4s	v20, v20, v31
	fmul.4s	v11, v3, v3
	fmul.4s	v20, v11, v20
	fmul.4s	v11, v23, v18
	fadd.4s	v11, v11, v17
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v16
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v7
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v6
	fmul.4s	v11, v23, v11
	fadd.4s	v11, v11, v31
	fmul.4s	v15, v23, v23
	fmul.4s	v11, v15, v11
	fadd.4s	v23, v23, v11
	fadd.4s	v3, v3, v20
	fadd.4s	v20, v23, v27
	sshr.4s	v23, v10, #1
	shl.4s	v11, v23, #23
	add.4s	v11, v11, v27
	fmul.4s	v20, v20, v11
	fadd.4s	v3, v3, v27
	sshr.4s	v11, v2, #1
	shl.4s	v15, v11, #23
	add.4s	v15, v15, v27
	fmul.4s	v3, v3, v15
	sub.4s	v23, v10, v23
	sub.4s	v2, v2, v11
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v23, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v20, v3
	fcmgt.4s	v20, v1, v25
	bic.16b	v3, v3, v20
	fcmgt.4s	v20, v1, v24
	bic.16b	v2, v2, v20
	fcmgt.4s	v20, v24, v4
	mov.16b	v0, v20
	bsl.16b	v0, v5, v2
	str	q0, [sp, #544]                  ; 16-byte Spill
	fcmgt.4s	v2, v25, v4
	mov.16b	v0, v2
	bsl.16b	v0, v5, v3
	str	q0, [sp, #528]                  ; 16-byte Spill
	ldr	q0, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v23, v0, v30
	fcmge.4s	v2, v23, v1
	fcmge.4s	v3, v4, v23
	and.16b	v2, v2, v3
	ldr	q29, [sp, #1312]                ; 16-byte Reload
	fsub.4s	v20, v29, v9
	fcmge.4s	v3, v20, v1
	fcmge.4s	v10, v4, v20
	and.16b	v3, v3, v10
	and.16b	v3, v3, v20
	fmul.4s	v10, v3, v22
	movi.4s	v0, #75, lsl #24
	mov.16b	v11, v8
	bsl.16b	v11, v0, v10
	fadd.4s	v10, v10, v11
	fsub.4s	v10, v10, v11
	and.16b	v11, v2, v23
	fmul.4s	v2, v11, v22
	mov.16b	v15, v8
	bsl.16b	v15, v0, v2
	fadd.4s	v2, v2, v15
	fsub.4s	v15, v2, v15
	fcvtzs.4s	v2, v10
	scvtf.4s	v10, v2
	fmul.4s	v14, v10, v21
	fsub.4s	v3, v3, v14
	fcvtzs.4s	v14, v15
	scvtf.4s	v15, v14
	fmul.4s	v13, v15, v21
	fsub.4s	v11, v11, v13
	fmul.4s	v13, v15, v19
	fsub.4s	v11, v11, v13
	fmul.4s	v10, v10, v19
	fsub.4s	v3, v3, v10
	fmul.4s	v10, v3, v18
	fadd.4s	v10, v10, v17
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v16
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v6
	fmul.4s	v10, v3, v10
	fadd.4s	v10, v10, v31
	fmul.4s	v13, v3, v3
	fmul.4s	v10, v13, v10
	fmul.4s	v13, v11, v18
	fadd.4s	v13, v13, v17
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v16
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v7
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v6
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v13, v31
	fmul.4s	v15, v11, v11
	fmul.4s	v13, v15, v13
	fadd.4s	v11, v11, v13
	fadd.4s	v3, v3, v10
	fadd.4s	v10, v11, v27
	sshr.4s	v11, v14, #1
	shl.4s	v13, v11, #23
	add.4s	v13, v13, v27
	fmul.4s	v10, v10, v13
	fadd.4s	v3, v3, v27
	sshr.4s	v13, v2, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v27
	fmul.4s	v3, v3, v15
	sub.4s	v11, v14, v11
	sub.4s	v2, v2, v13
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v27
	fmul.4s	v2, v3, v2
	shl.4s	v3, v11, #23
	add.4s	v3, v3, v27
	fmul.4s	v3, v10, v3
	fcmgt.4s	v10, v1, v23
	bic.16b	v3, v3, v10
	fcmgt.4s	v10, v1, v20
	bic.16b	v2, v2, v10
	fcmgt.4s	v10, v20, v4
	mov.16b	v0, v10
	bsl.16b	v0, v5, v2
	str	q0, [sp, #512]                  ; 16-byte Spill
	fcmgt.4s	v2, v23, v4
	bit.16b	v3, v5, v2
	str	q30, [sp, #1456]                ; 16-byte Spill
	ldr	q0, [sp, #1968]                 ; 16-byte Reload
	fsub.4s	v30, v0, v30
	fcmge.4s	v2, v30, v1
	fcmge.4s	v13, v4, v30
	and.16b	v13, v2, v13
	str	q9, [sp, #1472]                 ; 16-byte Spill
	ldr	q2, [sp, #1984]                 ; 16-byte Reload
	fsub.4s	v2, v2, v9
	fcmge.4s	v14, v2, v1
	fcmge.4s	v15, v4, v2
	and.16b	v14, v14, v15
	and.16b	v14, v14, v2
	fmul.4s	v15, v14, v22
	movi.4s	v9, #75, lsl #24
	mov.16b	v0, v8
	bsl.16b	v0, v9, v15
	fadd.4s	v15, v15, v0
	fsub.4s	v0, v15, v0
	and.16b	v13, v13, v30
	fmul.4s	v22, v13, v22
	mov.16b	v15, v8
	bsl.16b	v15, v9, v22
	fadd.4s	v22, v22, v15
	fsub.4s	v22, v22, v15
	fcvtzs.4s	v0, v0
	scvtf.4s	v15, v0
	fmul.4s	v11, v15, v21
	fsub.4s	v11, v14, v11
	fcvtzs.4s	v22, v22
	scvtf.4s	v14, v22
	fmul.4s	v21, v14, v21
	fsub.4s	v21, v13, v21
	fmul.4s	v13, v15, v19
	fmul.4s	v19, v14, v19
	fsub.4s	v19, v21, v19
	fsub.4s	v21, v11, v13
	fmul.4s	v11, v21, v18
	fmul.4s	v18, v19, v18
	fadd.4s	v18, v18, v17
	fadd.4s	v17, v11, v17
	fmul.4s	v17, v21, v17
	fmul.4s	v18, v19, v18
	fadd.4s	v18, v18, v16
	fadd.4s	v16, v17, v16
	fmul.4s	v16, v21, v16
	fmul.4s	v17, v19, v18
	fadd.4s	v17, v17, v7
	fadd.4s	v7, v16, v7
	fmul.4s	v7, v21, v7
	fmul.4s	v16, v19, v17
	fadd.4s	v16, v16, v6
	fadd.4s	v6, v7, v6
	fmul.4s	v6, v21, v6
	fadd.4s	v6, v6, v31
	fmul.4s	v7, v21, v21
	fmul.4s	v6, v7, v6
	fmul.4s	v7, v19, v16
	fadd.4s	v7, v7, v31
	fmul.4s	v16, v19, v19
	fmul.4s	v7, v16, v7
	fadd.4s	v7, v19, v7
	fadd.4s	v6, v21, v6
	fadd.4s	v7, v7, v27
	sshr.4s	v16, v22, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v27
	fmul.4s	v7, v7, v17
	fadd.4s	v6, v6, v27
	sshr.4s	v17, v0, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v27
	fmul.4s	v6, v6, v18
	sub.4s	v16, v22, v16
	sub.4s	v0, v0, v17
	shl.4s	v0, v0, #23
	add.4s	v0, v0, v27
	fmul.4s	v0, v6, v0
	shl.4s	v6, v16, #23
	add.4s	v6, v6, v27
	fmul.4s	v6, v7, v6
	fcmgt.4s	v7, v1, v30
	bic.16b	v6, v6, v7
	str	q2, [sp, #1968]                 ; 16-byte Spill
	fcmgt.4s	v1, v1, v2
	bic.16b	v0, v0, v1
	fcmgt.4s	v1, v2, v4
	bit.16b	v0, v5, v1
	str	q0, [sp, #1984]                 ; 16-byte Spill
	fcmgt.4s	v1, v30, v4
	mov.16b	v0, v1
	bsl.16b	v0, v5, v6
	stp	q30, q0, [sp, #480]             ; 32-byte Folded Spill
	ldp	x8, x9, [sp, #456]              ; 16-byte Folded Reload
	ldr	q0, [sp, #1616]                 ; 16-byte Reload
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldr	q0, [sp, #1584]                 ; 16-byte Reload
	ldr	q4, [sp, #1600]                 ; 16-byte Reload
	stp	q4, q0, [x8]
	ldr	x8, [sp, #448]                  ; 8-byte Reload
	ldr	q0, [sp, #1552]                 ; 16-byte Reload
	ldr	q4, [sp, #1568]                 ; 16-byte Reload
	stp	q4, q0, [x8]
	ldr	x8, [sp, #424]                  ; 8-byte Reload
	ldr	q0, [sp, #1536]                 ; 16-byte Reload
	ldr	q4, [sp, #2032]                 ; 16-byte Reload
	stp	q4, q0, [x8]
	ldr	x8, [sp, #392]                  ; 8-byte Reload
	ldr	q0, [sp, #2000]                 ; 16-byte Reload
	ldr	q4, [sp, #2016]                 ; 16-byte Reload
	stp	q4, q0, [x8]
	ldr	x8, [sp, #360]                  ; 8-byte Reload
	ldr	q0, [sp, #1104]                 ; 16-byte Reload
	ldr	q4, [sp, #1952]                 ; 16-byte Reload
	stp	q4, q0, [x8]
	ldp	x8, x9, [sp, #320]              ; 16-byte Folded Reload
	ldr	q0, [sp, #1632]                 ; 16-byte Reload
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldr	q0, [sp, #1648]                 ; 16-byte Reload
	ldr	q4, [sp, #1936]                 ; 16-byte Reload
	stp	q4, q0, [x8]
	ldp	x8, x9, [sp, #304]              ; 16-byte Folded Reload
	ldr	q0, [sp, #1664]                 ; 16-byte Reload
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldr	q0, [sp, #1680]                 ; 16-byte Reload
	ldr	q4, [sp, #1920]                 ; 16-byte Reload
	stp	q4, q0, [x8]
	ldp	x8, x9, [sp, #272]              ; 16-byte Folded Reload
	ldr	q0, [sp, #1696]                 ; 16-byte Reload
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldr	q0, [sp, #1712]                 ; 16-byte Reload
	ldr	q4, [sp, #1904]                 ; 16-byte Reload
	stp	q4, q0, [x8]
	ldp	x8, x9, [sp, #256]              ; 16-byte Folded Reload
	ldr	q0, [sp, #1728]                 ; 16-byte Reload
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldr	q0, [sp, #1744]                 ; 16-byte Reload
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	stp	q4, q0, [x8]
	ldp	x8, x9, [sp, #240]              ; 16-byte Folded Reload
	ldr	q0, [sp, #1760]                 ; 16-byte Reload
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	stp	q4, q0, [x9]
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	stp	q29, q4, [x8]
	ldr	q4, [sp, #1392]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q13, [sp, #208]                 ; 16-byte Reload
	ldr	q5, [sp, #1408]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #2032]                 ; 16-byte Spill
	ldr	q4, [sp, #1440]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1424]                 ; 16-byte Reload
	mov.16b	v14, v4
	bsl.16b	v14, v5, v13
	ldr	q4, [sp, #1328]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1344]                 ; 16-byte Reload
	mov.16b	v15, v4
	bsl.16b	v15, v5, v13
	ldr	q4, [sp, #1360]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1376]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #1872]                 ; 16-byte Spill
	ldr	q4, [sp, #1248]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1264]                 ; 16-byte Reload
	mov.16b	v8, v4
	bsl.16b	v8, v5, v13
	ldr	q4, [sp, #1280]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1296]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #1840]                 ; 16-byte Spill
	ldr	q4, [sp, #1184]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1200]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #1856]                 ; 16-byte Spill
	ldr	q4, [sp, #1216]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1232]                 ; 16-byte Reload
	mov.16b	v10, v4
	bsl.16b	v10, v5, v13
	ldr	q4, [sp, #1120]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1136]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #1888]                 ; 16-byte Spill
	ldr	q4, [sp, #1152]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1168]                 ; 16-byte Reload
	mov.16b	v0, v4
	bsl.16b	v0, v5, v13
	str	q0, [sp, #1824]                 ; 16-byte Spill
	ldr	q4, [sp, #1040]                 ; 16-byte Reload
	fcmeq.4s	v4, v4, v4
	ldr	q5, [sp, #1056]                 ; 16-byte Reload
	bsl.16b	v4, v5, v13
	ldr	q5, [sp, #1072]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1088]                 ; 16-byte Reload
	bsl.16b	v5, v6, v13
	ldp	q6, q7, [sp, #976]              ; 32-byte Folded Reload
	fcmeq.4s	v6, v6, v6
	bsl.16b	v6, v7, v13
	ldp	q7, q16, [sp, #1008]            ; 32-byte Folded Reload
	fcmeq.4s	v7, v7, v7
	bsl.16b	v7, v16, v13
	ldp	q16, q17, [sp, #912]            ; 32-byte Folded Reload
	fcmeq.4s	v16, v16, v16
	bsl.16b	v16, v17, v13
	ldp	q17, q18, [sp, #944]            ; 32-byte Folded Reload
	fcmeq.4s	v17, v17, v17
	bsl.16b	v17, v18, v13
	ldp	q18, q19, [sp, #848]            ; 32-byte Folded Reload
	fcmeq.4s	v18, v18, v18
	bsl.16b	v18, v19, v13
	ldp	q19, q21, [sp, #880]            ; 32-byte Folded Reload
	fcmeq.4s	v19, v19, v19
	bsl.16b	v19, v21, v13
	ldp	q21, q22, [sp, #784]            ; 32-byte Folded Reload
	fcmeq.4s	v21, v21, v21
	bsl.16b	v21, v22, v13
	ldp	q22, q27, [sp, #816]            ; 32-byte Folded Reload
	fcmeq.4s	v22, v22, v22
	bsl.16b	v22, v27, v13
	ldp	q0, q27, [sp, #720]             ; 32-byte Folded Reload
	fcmeq.4s	v11, v0, v0
	bsl.16b	v11, v27, v13
	ldp	q1, q27, [sp, #752]             ; 32-byte Folded Reload
	fcmeq.4s	v9, v1, v1
	bsl.16b	v9, v27, v13
	ldp	q2, q27, [sp, #656]             ; 32-byte Folded Reload
	fcmeq.4s	v31, v2, v2
	bsl.16b	v31, v27, v13
	ldp	q29, q27, [sp, #688]            ; 32-byte Folded Reload
	fcmeq.4s	v30, v29, v29
	bsl.16b	v30, v27, v13
	ldr	q27, [sp, #608]                 ; 16-byte Reload
	fcmeq.4s	v29, v27, v27
	ldr	q27, [sp, #624]                 ; 16-byte Reload
	bsl.16b	v29, v27, v13
	fcmeq.4s	v28, v28, v28
	ldr	q27, [sp, #640]                 ; 16-byte Reload
	mov.16b	v1, v28
	bsl.16b	v1, v27, v13
	fcmeq.4s	v27, v12, v12
	ldr	q12, [sp, #576]                 ; 16-byte Reload
	mov.16b	v0, v27
	bsl.16b	v0, v12, v13
	str	q0, [sp, #2016]                 ; 16-byte Spill
	fcmeq.4s	v26, v26, v26
	ldr	q12, [sp, #592]                 ; 16-byte Reload
	bsl.16b	v26, v12, v13
	fcmeq.4s	v25, v25, v25
	ldp	q2, q12, [sp, #512]             ; 32-byte Folded Reload
	mov.16b	v0, v25
	bsl.16b	v0, v12, v13
	fcmeq.4s	v24, v24, v24
	ldr	q12, [sp, #544]                 ; 16-byte Reload
	bsl.16b	v24, v12, v13
	fcmeq.4s	v23, v23, v23
	bif.16b	v3, v13, v23
	fcmeq.4s	v20, v20, v20
	bsl.16b	v20, v2, v13
	ldr	q12, [sp, #560]                 ; 16-byte Reload
	and.16b	v5, v12, v5
	and.16b	v2, v12, v4
	and.16b	v23, v12, v7
	mov.16b	v7, v8
	and.16b	v25, v12, v6
	mov.16b	v6, v14
	and.16b	v8, v12, v17
	ldr	q17, [sp, #1840]                ; 16-byte Reload
	and.16b	v4, v12, v16
	ldr	q16, [sp, #1872]                ; 16-byte Reload
	and.16b	v27, v12, v19
	mov.16b	v19, v10
	and.16b	v28, v12, v18
	ldr	q18, [sp, #1856]                ; 16-byte Reload
	and.16b	v10, v12, v22
	mov.16b	v22, v5
	and.16b	v5, v12, v21
	ldr	q21, [sp, #1824]                ; 16-byte Reload
	and.16b	v9, v12, v9
	and.16b	v11, v12, v11
	and.16b	v30, v12, v30
	and.16b	v14, v12, v31
	and.16b	v31, v12, v1
	and.16b	v29, v12, v29
	and.16b	v26, v12, v26
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	and.16b	v1, v12, v1
	str	q1, [sp, #2016]                 ; 16-byte Spill
	and.16b	v1, v12, v24
	and.16b	v0, v12, v0
	and.16b	v24, v12, v20
	ldr	q20, [sp, #1888]                ; 16-byte Reload
	and.16b	v3, v12, v3
	str	q3, [sp, #2000]                 ; 16-byte Spill
	mov.16b	v12, v1
	ldr	q1, [sp, #480]                  ; 16-byte Reload
	fcmeq.4s	v3, v1, v1
	ldr	q1, [sp, #496]                  ; 16-byte Reload
	bif.16b	v1, v13, v3
	str	q1, [sp, #1920]                 ; 16-byte Spill
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	bsl.16b	v1, v3, v13
	str	q1, [sp, #1904]                 ; 16-byte Spill
	mov.16b	v13, v0
	ldp	x8, x9, [sp, #224]              ; 16-byte Folded Reload
	ldr	q0, [sp, #2032]                 ; 16-byte Reload
	stp	q0, q6, [x9]
	stp	q15, q16, [x8]
	ldp	x8, x9, [sp, #192]              ; 16-byte Folded Reload
	stp	q7, q17, [x9]
	stp	q18, q19, [x8]
	ldp	x8, x10, [sp, #176]             ; 16-byte Folded Reload
	stp	q20, q21, [x10]
	str	q2, [sp, #1984]                 ; 16-byte Spill
	stp	q22, q2, [x8]
	ldr	x8, [sp, #168]                  ; 8-byte Reload
	stp	q23, q25, [x8]
	ldr	x8, [sp, #160]                  ; 8-byte Reload
	str	q4, [sp, #1968]                 ; 16-byte Spill
	stp	q8, q4, [x8]
	ldr	x8, [sp, #152]                  ; 8-byte Reload
	stp	q27, q28, [x8]
	ldr	x8, [sp, #144]                  ; 8-byte Reload
	str	q5, [sp, #1952]                 ; 16-byte Spill
	stp	q10, q5, [x8]
	ldr	x8, [sp, #136]                  ; 8-byte Reload
	stp	q9, q11, [x8]
	ldr	x8, [sp, #128]                  ; 8-byte Reload
	str	q14, [sp, #1936]                ; 16-byte Spill
	stp	q30, q14, [x8]
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	stp	q31, q29, [x8]
	ldr	x8, [sp, #112]                  ; 8-byte Reload
	ldr	q0, [sp, #2016]                 ; 16-byte Reload
	stp	q26, q0, [x8]
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	stp	q12, q13, [x8]
	ldr	x8, [sp, #96]                   ; 8-byte Reload
	ldr	q0, [sp, #2000]                 ; 16-byte Reload
	stp	q24, q0, [x8]
	mov	x8, x20
	mov	w9, #48                         ; =0x30
	mov	w0, #17952                      ; =0x4620
	movk	w0, #1, lsl #16
LBB0_44:                                ; %direct.true739
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [x8, #2576]
	ldr	q1, [x8, #2560]
	ldr	q5, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v1, v5, v1
	ldr	q2, [x8, #2608]
	ldr	q3, [x8, #2592]
	ldr	q4, [sp, #1920]                 ; 16-byte Reload
	fmul.4s	v0, v4, v0
	fmul.4s	v3, v5, v3
	fmul.4s	v2, v4, v2
	ldr	q4, [x8, #49680]
	ldr	q5, [x8, #49664]
	ldr	q14, [sp, #2032]                ; 16-byte Reload
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v6, v4
	fadd.4s	v0, v0, v4
	fadd.4s	v1, v1, v5
	ldr	q4, [x8, #49712]
	ldr	q5, [x8, #49696]
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v6, v4
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v5
	ldr	q4, [x8, #52736]
	ldr	q5, [x8, #52752]
	fmul.4s	v5, v16, v5
	fmul.4s	v4, v15, v4
	fadd.4s	v1, v1, v4
	fadd.4s	v0, v0, v5
	ldr	q4, [x8, #52768]
	ldr	q5, [x8, #52784]
	fmul.4s	v5, v16, v5
	fmul.4s	v4, v15, v4
	fadd.4s	v3, v3, v4
	fadd.4s	v2, v2, v5
	ldr	q4, [x8, #55824]
	ldr	q5, [x8, #55808]
	fmul.4s	v5, v7, v5
	fmul.4s	v4, v17, v4
	fadd.4s	v0, v0, v4
	fadd.4s	v1, v1, v5
	ldr	q4, [x8, #55856]
	ldr	q5, [x8, #55840]
	fmul.4s	v5, v7, v5
	fmul.4s	v4, v17, v4
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v5
	ldr	q4, [x8, #58880]
	ldr	q5, [x8, #58896]
	fmul.4s	v5, v19, v5
	fmul.4s	v4, v18, v4
	fadd.4s	v1, v1, v4
	fadd.4s	v0, v0, v5
	ldr	q4, [x8, #58912]
	ldr	q5, [x8, #58928]
	fmul.4s	v5, v19, v5
	fmul.4s	v4, v18, v4
	fadd.4s	v3, v3, v4
	fadd.4s	v2, v2, v5
	ldr	q4, [x8, #61968]
	ldr	q5, [x8, #61952]
	fmul.4s	v5, v20, v5
	fmul.4s	v4, v21, v4
	fadd.4s	v0, v0, v4
	fadd.4s	v1, v1, v5
	ldr	q4, [x8, #62000]
	ldr	q5, [x8, #61984]
	fmul.4s	v5, v20, v5
	fmul.4s	v4, v21, v4
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v5
	ldr	q4, [x8, #65024]
	ldr	q5, [x8, #65040]
	ldr	q14, [sp, #1984]                ; 16-byte Reload
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v22, v4
	fadd.4s	v1, v1, v4
	fadd.4s	v0, v0, v5
	ldr	q4, [x8, #65056]
	ldr	q5, [x8, #65072]
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v22, v4
	fadd.4s	v3, v3, v4
	fadd.4s	v2, v2, v5
	add	x10, x8, x5
	ldp	q5, q4, [x10]
	fmul.4s	v5, v23, v5
	fmul.4s	v4, v25, v4
	fadd.4s	v0, v0, v4
	fadd.4s	v1, v1, v5
	add	x10, x8, x6
	ldp	q5, q4, [x10]
	fmul.4s	v5, v23, v5
	fmul.4s	v4, v25, v4
	fadd.4s	v2, v2, v4
	add	x10, x8, x7
	fadd.4s	v3, v3, v5
	ldp	q4, q5, [x10]
	ldr	q14, [sp, #1968]                ; 16-byte Reload
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v8, v4
	fadd.4s	v1, v1, v4
	add	x10, x8, x30
	fadd.4s	v0, v0, v5
	ldp	q4, q5, [x10]
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v8, v4
	fadd.4s	v3, v3, v4
	fadd.4s	v2, v2, v5
	add	x10, x8, x11
	ldp	q5, q4, [x10]
	fmul.4s	v5, v27, v5
	fmul.4s	v4, v28, v4
	fadd.4s	v0, v0, v4
	fadd.4s	v1, v1, v5
	add	x10, x8, x12
	ldp	q5, q4, [x10]
	fmul.4s	v5, v27, v5
	fmul.4s	v4, v28, v4
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v5
	add	x10, x8, x13
	ldp	q4, q5, [x10]
	ldr	q14, [sp, #1952]                ; 16-byte Reload
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v10, v4
	fadd.4s	v1, v1, v4
	fadd.4s	v0, v0, v5
	add	x10, x8, x14
	ldp	q4, q5, [x10]
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v10, v4
	fadd.4s	v3, v3, v4
	add	x10, x8, x15
	fadd.4s	v2, v2, v5
	ldp	q5, q4, [x10]
	fmul.4s	v5, v9, v5
	fmul.4s	v4, v11, v4
	fadd.4s	v0, v0, v4
	add	x10, x8, x16
	fadd.4s	v1, v1, v5
	ldp	q5, q4, [x10]
	fmul.4s	v5, v9, v5
	fmul.4s	v4, v11, v4
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v5
	add	x10, x8, x17
	ldp	q4, q5, [x10]
	ldr	q14, [sp, #1936]                ; 16-byte Reload
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v30, v4
	fadd.4s	v1, v1, v4
	fadd.4s	v0, v0, v5
	add	x10, x8, x0
	ldp	q4, q5, [x10]
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v30, v4
	fadd.4s	v3, v3, v4
	fadd.4s	v2, v2, v5
	add	x10, x8, x1
	ldp	q5, q4, [x10]
	fmul.4s	v5, v31, v5
	fmul.4s	v4, v29, v4
	fadd.4s	v0, v0, v4
	fadd.4s	v1, v1, v5
	add	x10, x8, x2
	ldp	q5, q4, [x10]
	fmul.4s	v5, v31, v5
	fmul.4s	v4, v29, v4
	fadd.4s	v2, v2, v4
	add	x10, x8, x3
	fadd.4s	v3, v3, v5
	ldp	q4, q5, [x10]
	ldr	q14, [sp, #2016]                ; 16-byte Reload
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v26, v4
	fadd.4s	v1, v1, v4
	add	x10, x8, x21
	fadd.4s	v0, v0, v5
	ldp	q4, q5, [x10]
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v26, v4
	fadd.4s	v3, v3, v4
	fadd.4s	v2, v2, v5
	add	x10, x8, x19
	ldp	q5, q4, [x10]
	fmul.4s	v5, v12, v5
	fmul.4s	v4, v13, v4
	fadd.4s	v0, v0, v4
	fadd.4s	v1, v1, v5
	add	x10, x8, x27
	ldp	q5, q4, [x10]
	fmul.4s	v5, v12, v5
	fmul.4s	v4, v13, v4
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v5
	add	x10, x8, x22
	ldp	q4, q5, [x10]
	ldr	q14, [sp, #2000]                ; 16-byte Reload
	fmul.4s	v5, v14, v5
	fmul.4s	v4, v24, v4
	fadd.4s	v1, v1, v4
	fadd.4s	v0, v0, v5
	add	x10, x8, x28
	ldp	q4, q5, [x10]
	fmul.4s	v4, v24, v4
	fadd.4s	v3, v3, v4
	fmul.4s	v4, v14, v5
	fadd.4s	v2, v2, v4
	add	x10, x8, x26
	stp	q1, q0, [x10]
	add	x10, x8, x23
	stp	q3, q2, [x10]
	add	x8, x8, #64
	subs	x9, x9, #1
	b.ne	LBB0_44
; %bb.45:                               ; %direct.true958.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w8, #5632                       ; =0x1600
	add	x0, x20, x8
	add	x1, x20, x26
	mov	w2, #3072                       ; =0xc00
	str	q15, [sp, #1440]                ; 16-byte Spill
	str	q6, [sp, #1424]                 ; 16-byte Spill
	str	q7, [sp, #1536]                 ; 16-byte Spill
	str	q19, [sp, #1552]                ; 16-byte Spill
	str	q22, [sp, #1568]                ; 16-byte Spill
	str	q8, [sp, #1616]                 ; 16-byte Spill
	str	q10, [sp, #1696]                ; 16-byte Spill
	str	q30, [sp, #1744]                ; 16-byte Spill
	str	q26, [sp, #1792]                ; 16-byte Spill
	str	q24, [sp, #1808]                ; 16-byte Spill
	str	q23, [sp, #1584]                ; 16-byte Spill
	str	q25, [sp, #1600]                ; 16-byte Spill
	str	q27, [sp, #1632]                ; 16-byte Spill
	str	q28, [sp, #1648]                ; 16-byte Spill
	str	q9, [sp, #1664]                 ; 16-byte Spill
	str	q11, [sp, #1680]                ; 16-byte Spill
	str	q31, [sp, #1712]                ; 16-byte Spill
	str	q29, [sp, #1728]                ; 16-byte Spill
	str	q12, [sp, #1760]                ; 16-byte Spill
	str	q13, [sp, #1776]                ; 16-byte Spill
	bl	_memcpy
	add	x0, x20, #2560
	add	x1, x20, x26
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	w30, #5664                      ; =0x1620
	movk	w30, #1, lsl #16
	mov	w7, #5632                       ; =0x1600
	movk	w7, #1, lsl #16
	mov	w6, #2592                       ; =0xa20
	movk	w6, #1, lsl #16
	mov	w5, #2560                       ; =0xa00
	movk	w5, #1, lsl #16
	ldr	q0, [sp, #1488]                 ; 16-byte Reload
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	ldr	q2, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	movi.2d	v3, #0000000000000000
	ldr	q2, [sp, #1424]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2032]                 ; 16-byte Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #1440]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1536]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1552]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1984]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1568]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1584]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1600]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1616]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1952]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1696]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2016]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1760]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2000]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v19, v1, v3
	fadd.4s	v20, v0, v2
	ldr	x0, [sp, #1528]                 ; 8-byte Reload
	add	x0, x0, #1
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	ldr	q0, [sp, #1456]                 ; 16-byte Reload
	cmp	x0, #129
	ldr	q5, [sp, #432]                  ; 16-byte Reload
	ldr	q6, [sp, #400]                  ; 16-byte Reload
	ldr	q7, [sp, #368]                  ; 16-byte Reload
	ldr	q16, [sp, #336]                 ; 16-byte Reload
	ldr	q17, [sp, #288]                 ; 16-byte Reload
	mov	w1, #52429                      ; =0xcccd
	mov	w2, #80                         ; =0x50
	mov	w3, #43691                      ; =0xaaab
	mov	w4, #96                         ; =0x60
	b.ne	LBB0_3
; %bb.46:                               ; %direct.schedule.83.preheader
	mov	x8, #0                          ; =0x0
	ldp	q0, q2, [sp, #32]               ; 32-byte Folded Reload
	xtn.2s	v0, v0
	movi.2s	v3, #96
	umull.2d	v0, v0, v3
	ldp	q1, q4, [sp, #64]               ; 32-byte Folded Reload
	xtn.2s	v1, v1
	umull.2d	v1, v1, v3
	xtn.2s	v2, v2
	umull.2d	v2, v2, v3
	xtn.2s	v4, v4
	umull.2d	v3, v4, v3
	ldp	x12, x11, [sp, #16]             ; 16-byte Folded Reload
LBB0_47:                                ; %direct.true993
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v4, x8
	add.2d	v5, v4, v3
	add.2d	v6, v4, v2
	add.2d	v7, v4, v1
	add.2d	v4, v4, v0
	add	x9, x12, x8, lsl #5
	ldp	q16, q17, [x9]
	fdiv.4s	v17, v17, v20
	fdiv.4s	v16, v16, v19
	shl.2d	v4, v4, #2
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	shl.2d	v5, v5, #2
	dup.2d	v18, x11
	add.2d	v5, v18, v5
	add.2d	v4, v18, v4
	mov.d	x9, v4[1]
	fmov	x10, d4
	str	s16, [x10]
	st1.s	{ v16 }[1], [x9]
	add.2d	v4, v18, v7
	mov.d	x9, v4[1]
	fmov	x10, d4
	st1.s	{ v16 }[2], [x10]
	add.2d	v4, v18, v6
	st1.s	{ v16 }[3], [x9]
	mov.d	x9, v4[1]
	fmov	x10, d4
	str	s17, [x10]
	st1.s	{ v17 }[1], [x9]
	mov.d	x9, v5[1]
	fmov	x10, d5
	st1.s	{ v17 }[2], [x10]
	st1.s	{ v17 }[3], [x9]
	add	x8, x8, #1
	cmp	x8, #96
	b.ne	LBB0_47
; %bb.48:                               ; %common.ret
	add	sp, sp, #2048
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_3:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_4:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_5:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_6:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_132
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3216
	mov	x21, x3
	mov	x22, x2
	mov	x25, x0
	mov	w27, #0                         ; =0x0
	ldp	w19, w8, [x2, #44]
	str	w8, [sp, #172]                  ; 4-byte Spill
Lloh4:
	adrp	x8, lCPI1_0@PAGE
Lloh5:
	ldr	q19, [x8, lCPI1_0@PAGEOFF]
Lloh6:
	adrp	x8, lCPI1_1@PAGE
Lloh7:
	ldr	q20, [x8, lCPI1_1@PAGEOFF]
Lloh8:
	adrp	x8, lCPI1_2@PAGE
Lloh9:
	ldr	q18, [x8, lCPI1_2@PAGEOFF]
	mov	w23, #52429                     ; =0xcccd
	mov	w28, #80                        ; =0x50
	mov	w24, #43691                     ; =0xaaab
	mov	w26, #96                        ; =0x60
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #192]                  ; 16-byte Spill
	ldp	w2, w12, [x2]
	ldp	w13, w8, [x22, #8]
	str	x8, [sp, #160]                  ; 8-byte Spill
	str	w3, [sp, #28]                   ; 4-byte Spill
	stp	x0, x22, [sp, #8]               ; 16-byte Folded Spill
	str	w19, [sp, #140]                 ; 4-byte Spill
	str	q19, [sp, #512]                 ; 16-byte Spill
	str	q20, [sp, #112]                 ; 16-byte Spill
	str	q18, [sp, #144]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x22, #36]
	ldr	w19, [sp, #140]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w2, #1
	cmp	w8, w19
	cset	w8, eq
	csinc	w2, wzr, w2, eq
	ldp	w13, w9, [sp, #176]             ; 8-byte Folded Reload
	cinc	w9, w9, eq
	ldr	w10, [sp, #172]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w12, wzr, w9, ne
	add	w13, w13, w8
	add	w27, w27, #1
	cmp	w27, w21
	b.eq	LBB1_131
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_32 Depth 2
                                        ;     Child Loop BB1_34 Depth 2
                                        ;       Child Loop BB1_36 Depth 3
                                        ;       Child Loop BB1_55 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;       Child Loop BB1_85 Depth 3
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
                                        ;       Child Loop BB1_91 Depth 3
                                        ;       Child Loop BB1_93 Depth 3
                                        ;       Child Loop BB1_95 Depth 3
                                        ;       Child Loop BB1_97 Depth 3
                                        ;       Child Loop BB1_99 Depth 3
                                        ;       Child Loop BB1_101 Depth 3
                                        ;       Child Loop BB1_103 Depth 3
                                        ;       Child Loop BB1_105 Depth 3
                                        ;       Child Loop BB1_107 Depth 3
                                        ;       Child Loop BB1_109 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
                                        ;     Child Loop BB1_115 Depth 2
	ubfiz	x8, x2, #5, #32
	ldr	x14, [sp, #160]                 ; 8-byte Reload
	cmp	x8, x14
	csel	x9, x8, xzr, ls
	subs	x10, x14, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x14, x9
	str	x2, [sp, #184]                  ; 8-byte Spill
	stp	w2, w12, [x22]
	stp	w13, w12, [sp, #176]            ; 8-byte Folded Spill
	str	w13, [x22, #8]
	str	wzr, [x22, #36]
	ccmp	x8, x14, #2, hi
	csel	x20, x10, xzr, ls
	cmp	x20, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #184]                  ; 8-byte Reload
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x19, x20, #3
	cbz	x19, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	cmp	x19, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	cmp	x19, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	cmp	x19, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x22, #36]
	mov	x0, x25
	mov	x1, x22
	bl	_llm_attention.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w20, #0x7
	ldr	q19, [sp, #512]                 ; 16-byte Reload
	ldr	q20, [sp, #112]                 ; 16-byte Reload
	ldr	q18, [sp, #144]                 ; 16-byte Reload
	ldr	x2, [sp, #184]                  ; 8-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w0, w19, #3
	dup.4s	v25, w8
	str	w0, [x22, #36]
	cmhi.4s	v0, v25, v20
	cmhi.4s	v2, v25, v19
	uzp1.8h	v6, v2, v0
	umaxv.8h	h1, v6
	fmov	w8, s1
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x10, [x22, #136]
	add	x8, x10, #2560
	mov	w11, #5632                      ; =0x1600
	add	x11, x10, x11
	mov	w12, #8704                      ; =0x2200
	add	x12, x10, x12
	mov	w13, #49664                     ; =0xc200
	add	x13, x10, x13
	mov	w14, #33280                     ; =0x8200
	movk	w14, #1, lsl #16
	add	x14, x10, x14
	mov	w15, #34304                     ; =0x8600
	movk	w15, #1, lsl #16
	add	x15, x10, x15
	ldr	x1, [x25]
	ldr	x16, [x25, #16]
	ldr	x17, [x25, #32]
	orr	w0, w0, w2, lsl #5
	dup.4s	v1, w0
	ldr	x0, [x25, #48]
	str	x0, [sp, #96]                   ; 8-byte Spill
	orr.16b	v3, v1, v20
	orr.16b	v1, v1, v19
	and.16b	v5, v2, v1
	and.16b	v4, v0, v3
	ushll2.2d	v21, v4, #0
	ushll2.2d	v22, v5, #0
	ushll.2d	v23, v4, #0
	ushll.2d	v24, v5, #0
	movi.4s	v3, #80
	umull2.2d	v1, v4, v3
	umull2.2d	v3, v5, v3
	movi.2s	v7, #80
	umull.2d	v4, v4, v7
	umull.2d	v5, v5, v7
	and.16b	v6, v6, v18
	addv.8h	h11, v6
	dup.2d	v6, x1
	fmov	w0, s11
	b	LBB1_15
LBB1_14:                                ; %else290
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x1, x10, x9, lsl #5
	ldp	q17, q18, [x1]
	bif.16b	v16, v18, v0
	bif.16b	v7, v17, v2
	stp	q7, q16, [x1]
	add	x9, x9, #1
	cmp	x9, #80
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v17, x9
	add.2d	v7, v17, v5
	shl.2d	v7, v7, #2
	add.2d	v18, v6, v7
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w0, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w1, w0, #0xff
	tbnz	w1, #1, LBB1_24
LBB1_17:                                ; %else272
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v18, v17, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v6, v18
	tbnz	w1, #2, LBB1_25
LBB1_18:                                ; %else275
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w1, #3, LBB1_26
LBB1_19:                                ; %else278
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v18, v17, v4
	shl.2d	v18, v18, #2
	add.2d	v18, v6, v18
	tbnz	w1, #4, LBB1_27
LBB1_20:                                ; %else281
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w1, #5, LBB1_28
LBB1_21:                                ; %else284
                                        ;   in Loop: Header=BB1_15 Depth=2
	add.2d	v17, v17, v1
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbnz	w1, #6, LBB1_29
LBB1_22:                                ; %else287
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w1, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x1, d18
	ldr	s7, [x1]
	and	w1, w0, #0xff
	tbz	w1, #1, LBB1_17
LBB1_24:                                ; %cond.load271
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x2, v18[1]
	ld1.s	{ v7 }[1], [x2]
	add.2d	v18, v17, v3
	shl.2d	v18, v18, #2
	add.2d	v18, v6, v18
	tbz	w1, #2, LBB1_18
LBB1_25:                                ; %cond.load274
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x2, d18
	ld1.s	{ v7 }[2], [x2]
	tbz	w1, #3, LBB1_19
LBB1_26:                                ; %cond.load277
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x2, v18[1]
	ld1.s	{ v7 }[3], [x2]
	add.2d	v18, v17, v4
	shl.2d	v18, v18, #2
	add.2d	v18, v6, v18
	tbz	w1, #4, LBB1_20
LBB1_27:                                ; %cond.load280
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x2, d18
	ld1.s	{ v16 }[0], [x2]
	tbz	w1, #5, LBB1_21
LBB1_28:                                ; %cond.load283
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x2, v18[1]
	ld1.s	{ v16 }[1], [x2]
	add.2d	v17, v17, v1
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbz	w1, #6, LBB1_22
LBB1_29:                                ; %cond.load286
                                        ;   in Loop: Header=BB1_15 Depth=2
	fmov	x2, d17
	ld1.s	{ v16 }[2], [x2]
	tbz	w1, #7, LBB1_14
LBB1_30:                                ; %cond.load289
                                        ;   in Loop: Header=BB1_15 Depth=2
	mov.d	x1, v17[1]
	ld1.s	{ v16 }[3], [x1]
	b	LBB1_14
LBB1_31:                                ; %direct.true166.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w27, [sp, #108]                 ; 4-byte Spill
	mov	x9, #0                          ; =0x0
LBB1_32:                                ; %direct.true166.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x0, x8, x9
	ldp	q1, q3, [x0]
	cmhs.4s	v17, v20, v25
	and.16b	v3, v17, v3
	cmhs.4s	v18, v19, v25
	and.16b	v1, v18, v1
	stp	q1, q3, [x0]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB1_32
; %bb.33:                               ; %direct.false167.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q25, [sp, #496]                 ; 16-byte Spill
	mov	x0, #0                          ; =0x0
	sshll.2d	v1, v2, #0
	sshll.2d	v3, v0, #0
	sshll2.2d	v16, v2, #0
	sshll2.2d	v7, v0, #0
	stp	q24, q23, [sp, #32]             ; 32-byte Folded Spill
	ushr.2d	v4, v24, #2
	stp	q22, q21, [sp, #64]             ; 32-byte Folded Spill
	ushr.2d	v5, v22, #2
	ushr.2d	v6, v23, #2
	mov.16b	v23, v7
	ushr.2d	v7, v21, #2
Lloh10:
	adrp	x9, lCPI1_6@PAGE
Lloh11:
	ldr	q19, [x9, lCPI1_6@PAGEOFF]
	str	q19, [sp, #2000]                ; 16-byte Spill
	and.16b	v8, v1, v19
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v19, w9
	and.16b	v20, v0, v19
	str	q20, [sp, #2736]                ; 16-byte Spill
	str	q19, [sp, #416]                 ; 16-byte Spill
	and.16b	v19, v2, v19
	str	q19, [sp, #2720]                ; 16-byte Spill
	mov.d	x9, v7[1]
	mov	w2, #2053                       ; =0x805
	mul	x9, x9, x2
	fmov	x1, d7
	mul	x1, x1, x2
	fmov	d7, x1
	mov.d	v7[1], x9
	mov.d	x9, v6[1]
	mul	x9, x9, x2
	fmov	x1, d6
	mul	x1, x1, x2
	fmov	d6, x1
	mov.d	v6[1], x9
	mov.d	x9, v5[1]
	mul	x9, x9, x2
	fmov	x1, d5
	mul	x1, x1, x2
	fmov	d5, x1
	mov.d	v5[1], x9
	mov.d	x9, v4[1]
	mul	x9, x9, x2
	fmov	x1, d4
	mul	x1, x1, x2
	fmov	d4, x1
	mov.d	v4[1], x9
	and.16b	v26, v1, v4
	str	q16, [sp, #432]                 ; 16-byte Spill
	and.16b	v1, v16, v5
	str	q1, [sp, #3072]                 ; 16-byte Spill
	and.16b	v1, v3, v6
	str	q1, [sp, #3056]                 ; 16-byte Spill
	and.16b	v1, v23, v7
	str	q1, [sp, #3040]                 ; 16-byte Spill
	movi.2d	v21, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #1984]                 ; 16-byte Spill
	str	q1, [sp, #1968]                 ; 16-byte Spill
	str	q1, [sp, #1952]                 ; 16-byte Spill
	str	q1, [sp, #1936]                 ; 16-byte Spill
	str	q1, [sp, #1920]                 ; 16-byte Spill
	str	q1, [sp, #1904]                 ; 16-byte Spill
	movi.2d	v27, #0000000000000000
	str	q1, [sp, #1584]                 ; 16-byte Spill
	str	q1, [sp, #1568]                 ; 16-byte Spill
	str	q1, [sp, #1680]                 ; 16-byte Spill
	mov	w9, #52736                      ; =0xce00
	add	x1, x10, x9
	str	q1, [sp, #1664]                 ; 16-byte Spill
	mov	w9, #33312                      ; =0x8220
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #392]                  ; 8-byte Spill
	str	q1, [sp, #1648]                 ; 16-byte Spill
	mov	w9, #33344                      ; =0x8240
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #384]                  ; 8-byte Spill
	str	q1, [sp, #1632]                 ; 16-byte Spill
	mov	w9, #33376                      ; =0x8260
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #376]                  ; 8-byte Spill
	str	q1, [sp, #1616]                 ; 16-byte Spill
	mov	w9, #33408                      ; =0x8280
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #368]                  ; 8-byte Spill
	str	q1, [sp, #1600]                 ; 16-byte Spill
	mov	w9, #33440                      ; =0x82a0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #360]                  ; 8-byte Spill
	str	q1, [sp, #1888]                 ; 16-byte Spill
	mov	w9, #33472                      ; =0x82c0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #352]                  ; 8-byte Spill
	movi.2d	v9, #0000000000000000
	mov	w9, #33504                      ; =0x82e0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #344]                  ; 8-byte Spill
	movi.2d	v7, #0000000000000000
	mov	w9, #33536                      ; =0x8300
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #336]                  ; 8-byte Spill
	movi.2d	v10, #0000000000000000
	mov	w9, #33568                      ; =0x8320
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #328]                  ; 8-byte Spill
	mov	w9, #33600                      ; =0x8340
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #320]                  ; 8-byte Spill
	mov	w9, #33632                      ; =0x8360
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #312]                  ; 8-byte Spill
	mov	w9, #33664                      ; =0x8380
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #304]                  ; 8-byte Spill
	mov	w9, #33696                      ; =0x83a0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #296]                  ; 8-byte Spill
	mov	w9, #33728                      ; =0x83c0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #288]                  ; 8-byte Spill
	mov	w9, #33760                      ; =0x83e0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #280]                  ; 8-byte Spill
	mov	w9, #33792                      ; =0x8400
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #272]                  ; 8-byte Spill
	mov	w9, #33824                      ; =0x8420
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #264]                  ; 8-byte Spill
	mov	w9, #33856                      ; =0x8440
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #256]                  ; 8-byte Spill
	mov	w9, #33888                      ; =0x8460
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #248]                  ; 8-byte Spill
	mov	w9, #33920                      ; =0x8480
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #240]                  ; 8-byte Spill
	mov	w9, #33952                      ; =0x84a0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #232]                  ; 8-byte Spill
	mov	w9, #33984                      ; =0x84c0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #224]                  ; 8-byte Spill
	mov	w9, #34016                      ; =0x84e0
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	str	x9, [sp, #216]                  ; 8-byte Spill
	mov	w9, #34048                      ; =0x8500
	movk	w9, #1, lsl #16
	add	x9, x10, x9
	mov	w2, #34080                      ; =0x8520
	movk	w2, #1, lsl #16
	add	x22, x10, x2
	mov	w2, #34112                      ; =0x8540
	movk	w2, #1, lsl #16
	add	x25, x10, x2
	mov	w2, #34144                      ; =0x8560
	movk	w2, #1, lsl #16
	add	x27, x10, x2
	mov	w2, #34176                      ; =0x8580
	movk	w2, #1, lsl #16
	add	x20, x10, x2
	mov	w2, #34208                      ; =0x85a0
	movk	w2, #1, lsl #16
	add	x2, x10, x2
	mov	w3, #34240                      ; =0x85c0
	movk	w3, #1, lsl #16
	add	x3, x10, x3
	mov	w4, #34272                      ; =0x85e0
	movk	w4, #1, lsl #16
	add	x4, x10, x4
	movi.2d	v22, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	str	q1, [sp, #1872]                 ; 16-byte Spill
	movi.2d	v24, #0000000000000000
	str	q1, [sp, #2864]                 ; 16-byte Spill
	str	q1, [sp, #2848]                 ; 16-byte Spill
	movi.2d	v30, #0000000000000000
	str	q1, [sp, #2832]                 ; 16-byte Spill
	str	q1, [sp, #2816]                 ; 16-byte Spill
	str	q1, [sp, #2800]                 ; 16-byte Spill
	str	q1, [sp, #2784]                 ; 16-byte Spill
	str	q1, [sp, #3104]                 ; 16-byte Spill
	str	q1, [sp, #2768]                 ; 16-byte Spill
	str	q1, [sp, #3088]                 ; 16-byte Spill
	str	q1, [sp, #2752]                 ; 16-byte Spill
	str	q1, [sp, #1856]                 ; 16-byte Spill
	str	q1, [sp, #1840]                 ; 16-byte Spill
	str	q1, [sp, #1824]                 ; 16-byte Spill
	str	q1, [sp, #1808]                 ; 16-byte Spill
	str	q1, [sp, #2688]                 ; 16-byte Spill
	str	q1, [sp, #2672]                 ; 16-byte Spill
	str	q1, [sp, #2656]                 ; 16-byte Spill
	str	q1, [sp, #2640]                 ; 16-byte Spill
	str	q1, [sp, #2624]                 ; 16-byte Spill
	str	q1, [sp, #2608]                 ; 16-byte Spill
	movi.2d	v20, #0000000000000000
	str	q1, [sp, #2592]                 ; 16-byte Spill
	movi.2d	v12, #0000000000000000
	str	q1, [sp, #2576]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	str	q1, [sp, #2560]                 ; 16-byte Spill
	movi.2d	v14, #0000000000000000
	str	q1, [sp, #2544]                 ; 16-byte Spill
	str	q1, [sp, #2528]                 ; 16-byte Spill
	str	q1, [sp, #2512]                 ; 16-byte Spill
	str	q1, [sp, #2496]                 ; 16-byte Spill
	str	q1, [sp, #2480]                 ; 16-byte Spill
	str	q1, [sp, #2464]                 ; 16-byte Spill
	str	q1, [sp, #2448]                 ; 16-byte Spill
	str	q1, [sp, #2432]                 ; 16-byte Spill
	str	q1, [sp, #2416]                 ; 16-byte Spill
	str	q1, [sp, #2400]                 ; 16-byte Spill
	str	q1, [sp, #2384]                 ; 16-byte Spill
	str	q1, [sp, #2368]                 ; 16-byte Spill
	str	q1, [sp, #2352]                 ; 16-byte Spill
	str	q1, [sp, #2336]                 ; 16-byte Spill
	str	q1, [sp, #2320]                 ; 16-byte Spill
	str	q1, [sp, #2304]                 ; 16-byte Spill
	str	q1, [sp, #2288]                 ; 16-byte Spill
	str	q1, [sp, #3024]                 ; 16-byte Spill
	str	q1, [sp, #3184]                 ; 16-byte Spill
	str	q1, [sp, #3168]                 ; 16-byte Spill
	str	q1, [sp, #3152]                 ; 16-byte Spill
	str	q1, [sp, #1792]                 ; 16-byte Spill
	str	q1, [sp, #1776]                 ; 16-byte Spill
	str	q1, [sp, #1760]                 ; 16-byte Spill
	str	q1, [sp, #1744]                 ; 16-byte Spill
	str	q1, [sp, #3008]                 ; 16-byte Spill
	str	q1, [sp, #2992]                 ; 16-byte Spill
	str	q1, [sp, #3136]                 ; 16-byte Spill
	str	q1, [sp, #3120]                 ; 16-byte Spill
	str	q1, [sp, #1728]                 ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q1, [sp, #1712]                 ; 16-byte Spill
	str	q1, [sp, #1696]                 ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	stp	q17, q11, [sp, #464]            ; 32-byte Folded Spill
	str	q18, [sp, #448]                 ; 16-byte Spill
	str	q23, [sp, #2016]                ; 16-byte Spill
	str	q8, [sp, #2880]                 ; 16-byte Spill
	str	q26, [sp, #400]                 ; 16-byte Spill
LBB1_34:                                ; %direct.true176.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_36 Depth 3
                                        ;       Child Loop BB1_55 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_75 Depth 3
                                        ;       Child Loop BB1_77 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_83 Depth 3
                                        ;       Child Loop BB1_85 Depth 3
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_89 Depth 3
                                        ;       Child Loop BB1_91 Depth 3
                                        ;       Child Loop BB1_93 Depth 3
                                        ;       Child Loop BB1_95 Depth 3
                                        ;       Child Loop BB1_97 Depth 3
                                        ;       Child Loop BB1_99 Depth 3
                                        ;       Child Loop BB1_101 Depth 3
                                        ;       Child Loop BB1_103 Depth 3
                                        ;       Child Loop BB1_105 Depth 3
                                        ;       Child Loop BB1_107 Depth 3
                                        ;       Child Loop BB1_109 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
	str	q10, [sp, #2896]                ; 16-byte Spill
	str	q7, [sp, #2912]                 ; 16-byte Spill
	str	q6, [sp, #1440]                 ; 16-byte Spill
	str	q5, [sp, #1456]                 ; 16-byte Spill
	str	q4, [sp, #2928]                 ; 16-byte Spill
	str	q3, [sp, #2944]                 ; 16-byte Spill
	str	q22, [sp, #2960]                ; 16-byte Spill
	str	q24, [sp, #1488]                ; 16-byte Spill
	str	q27, [sp, #1536]                ; 16-byte Spill
	str	q28, [sp, #2976]                ; 16-byte Spill
	str	q21, [sp, #1552]                ; 16-byte Spill
	mov	x6, #0                          ; =0x0
	lsl	x5, x0, #4
	ldr	q7, [sp, #432]                  ; 16-byte Reload
	ldr	q27, [sp, #2624]                ; 16-byte Reload
	ldr	q28, [sp, #2528]                ; 16-byte Reload
	ldr	q8, [sp, #2496]                 ; 16-byte Reload
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
	ldr	q4, [sp, #2432]                 ; 16-byte Reload
	ldr	q5, [sp, #2400]                 ; 16-byte Reload
	ldr	q6, [sp, #2368]                 ; 16-byte Reload
	ldr	q22, [sp, #2320]                ; 16-byte Reload
	b	LBB1_36
LBB1_35:                                ; %direct.schedule.12.i.i
                                        ;   in Loop: Header=BB1_36 Depth=3
	str	q25, [sp, #2992]                ; 16-byte Spill
	str	q24, [sp, #3008]                ; 16-byte Spill
	add	x7, x12, x6, lsl #5
	ldp	q21, q10, [x7]
	bif.16b	v31, v10, v0
	bif.16b	v1, v21, v2
	stp	q1, q31, [x7]
	add	x6, x6, #1
	cmp	x6, #1280
	b.eq	LBB1_53
LBB1_36:                                ; %direct.true180.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w7, w6, #0xffff
	mul	w7, w7, w23
	lsr	w30, w7, #22
	add	x7, x5, x30
	dup.2d	v1, x7
	ldr	q16, [sp, #3072]                ; 16-byte Reload
	add.2d	v21, v1, v16
	ldr	q16, [sp, #3056]                ; 16-byte Reload
	add.2d	v31, v1, v16
	ldr	q16, [sp, #3040]                ; 16-byte Reload
	add.2d	v10, v1, v16
	mov.d	x21, v10[1]
	fmov	x19, d10
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	fmov	d10, x19
	add	x19, x21, x21, lsl #2
	lsl	x19, x19, #4
	mov.d	v10[1], x19
	mov.d	x19, v31[1]
	fmov	x21, d31
	add	x21, x21, x21, lsl #2
	lsl	x21, x21, #4
	fmov	d31, x21
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	mov.d	v31[1], x19
	mov.d	x19, v21[1]
	add.2d	v1, v1, v26
	fmov	x21, d21
	add	x21, x21, x21, lsl #2
	lsl	x21, x21, #4
	fmov	d21, x21
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	mov.d	v21[1], x19
	mov.d	x19, v1[1]
	fmov	x21, d1
	add	x21, x21, x21, lsl #2
	lsl	x21, x21, #4
	fmov	d1, x21
	sshll.2d	v16, v2, #0
	msub	w21, w30, w28, w6
	and	x21, x21, #0xffff
	add	x19, x19, x19, lsl #2
	lsl	x19, x19, #4
	mov.d	v1[1], x19
	dup.2d	v24, x21
	sshll.2d	v25, v0, #0
	add.2d	v1, v1, v24
	add.2d	v21, v21, v24
	add.2d	v31, v31, v24
	add.2d	v24, v10, v24
	ldr	q10, [sp, #3120]                ; 16-byte Reload
	bit.16b	v10, v24, v23
	str	q10, [sp, #3120]                ; 16-byte Spill
	ldr	q24, [sp, #3136]                ; 16-byte Reload
	bit.16b	v24, v31, v25
	str	q24, [sp, #3136]                ; 16-byte Spill
	ldr	q25, [sp, #2992]                ; 16-byte Reload
	bit.16b	v25, v21, v7
	ldr	q24, [sp, #3008]                ; 16-byte Reload
	bit.16b	v24, v1, v16
	movi.2d	v1, #0000000000000000
	movi.2d	v31, #0000000000000000
	cmp	x7, #2052
	b.hi	LBB1_35
; %bb.37:                               ; %direct.true193.i.i
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	w7, s11
	shl.2d	v1, v24, #2
	dup.2d	v10, x16
	add.2d	v21, v10, v1
	movi.2d	v1, #0000000000000000
	tbnz	w7, #0, LBB1_45
; %bb.38:                               ; %else297
                                        ;   in Loop: Header=BB1_36 Depth=3
	and	w7, w7, #0xff
	tbnz	w7, #1, LBB1_46
LBB1_39:                                ; %else303
                                        ;   in Loop: Header=BB1_36 Depth=3
	shl.2d	v16, v25, #2
	add.2d	v21, v10, v16
	tbnz	w7, #2, LBB1_47
LBB1_40:                                ; %else309
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbnz	w7, #3, LBB1_48
LBB1_41:                                ; %else315
                                        ;   in Loop: Header=BB1_36 Depth=3
	ldr	q16, [sp, #3136]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v21, v10, v16
	tbnz	w7, #4, LBB1_49
LBB1_42:                                ; %else321
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbnz	w7, #5, LBB1_50
LBB1_43:                                ; %else327
                                        ;   in Loop: Header=BB1_36 Depth=3
	ldr	q16, [sp, #3120]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v21, v10, v16
	tbnz	w7, #6, LBB1_51
LBB1_44:                                ; %else333
                                        ;   in Loop: Header=BB1_36 Depth=3
	tbz	w7, #7, LBB1_35
	b	LBB1_52
LBB1_45:                                ; %cond.load293
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x19, d21
	ldr	s1, [x19]
	and	w7, w7, #0xff
	tbz	w7, #1, LBB1_39
LBB1_46:                                ; %cond.load299
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x19, v21[1]
	ld1.s	{ v1 }[1], [x19]
	shl.2d	v16, v25, #2
	add.2d	v21, v10, v16
	tbz	w7, #2, LBB1_40
LBB1_47:                                ; %cond.load305
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x19, d21
	ld1.s	{ v1 }[2], [x19]
	tbz	w7, #3, LBB1_41
LBB1_48:                                ; %cond.load311
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x19, v21[1]
	ld1.s	{ v1 }[3], [x19]
	ldr	q16, [sp, #3136]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v21, v10, v16
	tbz	w7, #4, LBB1_42
LBB1_49:                                ; %cond.load317
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x19, d21
	ld1.s	{ v31 }[0], [x19]
	tbz	w7, #5, LBB1_43
LBB1_50:                                ; %cond.load323
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x19, v21[1]
	ld1.s	{ v31 }[1], [x19]
	ldr	q16, [sp, #3120]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v21, v10, v16
	tbz	w7, #6, LBB1_44
LBB1_51:                                ; %cond.load329
                                        ;   in Loop: Header=BB1_36 Depth=3
	fmov	x19, d21
	ld1.s	{ v31 }[2], [x19]
	tbz	w7, #7, LBB1_35
LBB1_52:                                ; %cond.load335
                                        ;   in Loop: Header=BB1_36 Depth=3
	mov.d	x7, v21[1]
	ld1.s	{ v31 }[3], [x7]
	b	LBB1_35
LBB1_53:                                ; %direct.true205.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x6, #0                          ; =0x0
	b	LBB1_55
LBB1_54:                                ; %direct.schedule.17.i.i
                                        ;   in Loop: Header=BB1_55 Depth=3
	str	q24, [sp, #3024]                ; 16-byte Spill
	add	x7, x13, x6, lsl #5
	ldp	q21, q10, [x7]
	bif.16b	v31, v10, v0
	bif.16b	v1, v21, v2
	stp	q1, q31, [x7]
	add	x6, x6, #1
	cmp	x6, #1536
	b.eq	LBB1_72
LBB1_55:                                ; %direct.true205.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w7, w6, #0xffff
	mul	w7, w7, w24
	lsr	w30, w7, #22
	add	x7, x5, x30
	dup.2d	v1, x7
	ldr	q16, [sp, #3072]                ; 16-byte Reload
	add.2d	v16, v1, v16
	ldr	q21, [sp, #3056]                ; 16-byte Reload
	add.2d	v21, v1, v21
	ldr	q24, [sp, #3040]                ; 16-byte Reload
	add.2d	v24, v1, v24
	mov.d	x19, v24[1]
	fmov	x21, d24
	add	x21, x21, x21, lsl #1
	lsl	x21, x21, #5
	fmov	d24, x21
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	mov.d	v24[1], x19
	mov.d	x19, v21[1]
	fmov	x21, d21
	add	x21, x21, x21, lsl #1
	lsl	x21, x21, #5
	fmov	d21, x21
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	mov.d	v21[1], x19
	mov.d	x19, v16[1]
	add.2d	v1, v1, v26
	fmov	x21, d16
	add	x21, x21, x21, lsl #1
	lsl	x21, x21, #5
	fmov	d16, x21
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	mov.d	v16[1], x19
	mov.d	x19, v1[1]
	fmov	x21, d1
	add	x21, x21, x21, lsl #1
	lsl	x21, x21, #5
	fmov	d1, x21
	sshll.2d	v25, v2, #0
	msub	w21, w30, w26, w6
	and	x21, x21, #0xffff
	add	x19, x19, x19, lsl #1
	lsl	x19, x19, #5
	mov.d	v1[1], x19
	dup.2d	v31, x21
	sshll.2d	v10, v0, #0
	add.2d	v1, v1, v31
	add.2d	v16, v16, v31
	add.2d	v21, v21, v31
	add.2d	v24, v24, v31
	ldr	q31, [sp, #3152]                ; 16-byte Reload
	bit.16b	v31, v24, v23
	str	q31, [sp, #3152]                ; 16-byte Spill
	ldr	q24, [sp, #3168]                ; 16-byte Reload
	bit.16b	v24, v21, v10
	str	q24, [sp, #3168]                ; 16-byte Spill
	ldr	q21, [sp, #3184]                ; 16-byte Reload
	bit.16b	v21, v16, v7
	str	q21, [sp, #3184]                ; 16-byte Spill
	ldr	q24, [sp, #3024]                ; 16-byte Reload
	bit.16b	v24, v1, v25
	movi.2d	v1, #0000000000000000
	movi.2d	v31, #0000000000000000
	cmp	x7, #2053
	b.hs	LBB1_54
; %bb.56:                               ; %direct.true218.i.i
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	w7, s11
	shl.2d	v1, v24, #2
	dup.2d	v10, x17
	add.2d	v21, v10, v1
	movi.2d	v1, #0000000000000000
	tbnz	w7, #0, LBB1_64
; %bb.57:                               ; %else346
                                        ;   in Loop: Header=BB1_55 Depth=3
	and	w7, w7, #0xff
	tbnz	w7, #1, LBB1_65
LBB1_58:                                ; %else352
                                        ;   in Loop: Header=BB1_55 Depth=3
	ldr	q16, [sp, #3184]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v21, v10, v16
	tbnz	w7, #2, LBB1_66
LBB1_59:                                ; %else358
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbnz	w7, #3, LBB1_67
LBB1_60:                                ; %else364
                                        ;   in Loop: Header=BB1_55 Depth=3
	ldr	q16, [sp, #3168]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v21, v10, v16
	tbnz	w7, #4, LBB1_68
LBB1_61:                                ; %else370
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbnz	w7, #5, LBB1_69
LBB1_62:                                ; %else376
                                        ;   in Loop: Header=BB1_55 Depth=3
	ldr	q16, [sp, #3152]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v21, v10, v16
	tbnz	w7, #6, LBB1_70
LBB1_63:                                ; %else382
                                        ;   in Loop: Header=BB1_55 Depth=3
	tbz	w7, #7, LBB1_54
	b	LBB1_71
LBB1_64:                                ; %cond.load342
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x19, d21
	ldr	s1, [x19]
	and	w7, w7, #0xff
	tbz	w7, #1, LBB1_58
LBB1_65:                                ; %cond.load348
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x19, v21[1]
	ld1.s	{ v1 }[1], [x19]
	ldr	q16, [sp, #3184]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v21, v10, v16
	tbz	w7, #2, LBB1_59
LBB1_66:                                ; %cond.load354
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x19, d21
	ld1.s	{ v1 }[2], [x19]
	tbz	w7, #3, LBB1_60
LBB1_67:                                ; %cond.load360
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x19, v21[1]
	ld1.s	{ v1 }[3], [x19]
	ldr	q16, [sp, #3168]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v21, v10, v16
	tbz	w7, #4, LBB1_61
LBB1_68:                                ; %cond.load366
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x19, d21
	ld1.s	{ v31 }[0], [x19]
	tbz	w7, #5, LBB1_62
LBB1_69:                                ; %cond.load372
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x19, v21[1]
	ld1.s	{ v31 }[1], [x19]
	ldr	q16, [sp, #3152]                ; 16-byte Reload
	shl.2d	v16, v16, #2
	add.2d	v21, v10, v16
	tbz	w7, #6, LBB1_63
LBB1_70:                                ; %cond.load378
                                        ;   in Loop: Header=BB1_55 Depth=3
	fmov	x19, d21
	ld1.s	{ v31 }[2], [x19]
	tbz	w7, #7, LBB1_54
LBB1_71:                                ; %cond.load384
                                        ;   in Loop: Header=BB1_55 Depth=3
	mov.d	x7, v21[1]
	ld1.s	{ v31 }[3], [x7]
	b	LBB1_54
LBB1_72:                                ; %direct.false206.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x5, #0                          ; =0x0
	sshll.2d	v1, v2, #0
	sshll.2d	v16, v0, #0
Lloh12:
	adrp	x6, lCPI1_3@PAGE
Lloh13:
	ldr	q29, [x6, lCPI1_3@PAGEOFF]
	ldr	q21, [sp, #1696]                ; 16-byte Reload
	bit.16b	v21, v29, v23
	str	q21, [sp, #1696]                ; 16-byte Spill
Lloh14:
	adrp	x6, lCPI1_4@PAGE
Lloh15:
	ldr	q21, [x6, lCPI1_4@PAGEOFF]
	str	q21, [sp, #2192]                ; 16-byte Spill
	bit.16b	v19, v21, v7
	str	q19, [sp, #1472]                ; 16-byte Spill
Lloh16:
	adrp	x6, lCPI1_5@PAGE
Lloh17:
	ldr	q19, [x6, lCPI1_5@PAGEOFF]
	ldr	q7, [sp, #1712]                 ; 16-byte Reload
	str	q19, [sp, #2208]                ; 16-byte Spill
	bit.16b	v7, v19, v16
	str	q7, [sp, #1712]                 ; 16-byte Spill
	ldr	q7, [sp, #2000]                 ; 16-byte Reload
	ldr	q19, [sp, #1728]                ; 16-byte Reload
	bit.16b	v19, v7, v1
	ldr	q31, [sp, #2288]                ; 16-byte Reload
	bic.16b	v31, v31, v0
	ldr	q25, [sp, #2304]                ; 16-byte Reload
	bic.16b	v25, v25, v2
	ldr	q7, [sp, #2880]                 ; 16-byte Reload
	ldr	q10, [sp, #2352]                ; 16-byte Reload
LBB1_73:                                ; %direct.true230.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d1, x5
	orr.16b	v16, v1, v7
	fmov	x6, d16
	add	x6, x10, x6
	ldp	q16, q21, [x6]
	orr.16b	v1, v1, v19
	fmov	x6, d1
	add	x6, x12, x6
	ldp	q1, q24, [x6]
	fmul.4s	v21, v21, v24
	fmul.4s	v1, v16, v1
	fadd.4s	v1, v25, v1
	fadd.4s	v16, v31, v21
	bit.16b	v31, v16, v0
	bit.16b	v25, v1, v2
	add	x5, x5, #32
	cmp	x5, #2560
	b.ne	LBB1_73
; %bb.74:                               ; %direct.false231.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q19, [sp, #1728]                ; 16-byte Spill
	str	q31, [sp, #2288]                ; 16-byte Spill
	str	q25, [sp, #2304]                ; 16-byte Spill
	and.16b	v22, v17, v22
	ldr	q7, [sp, #2336]                 ; 16-byte Reload
	and.16b	v7, v18, v7
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q25, [sp, #2688]                ; 16-byte Reload
	ldr	q31, [sp, #2672]                ; 16-byte Reload
LBB1_75:                                ; %direct.true245.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #11264]
	ldr	q24, [x5, #11280]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v7, v1
	fadd.4s	v16, v22, v16
	bit.16b	v22, v16, v0
	bit.16b	v7, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_75
; %bb.76:                               ; %direct.false246.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q22, [sp, #2320]                ; 16-byte Spill
	str	q7, [sp, #2336]                 ; 16-byte Spill
	and.16b	v10, v17, v10
	and.16b	v6, v18, v6
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q7, [sp, #1824]                 ; 16-byte Reload
	ldr	q22, [sp, #2656]                ; 16-byte Reload
LBB1_77:                                ; %direct.true262.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #13824]
	ldr	q24, [x5, #13840]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v6, v1
	fadd.4s	v16, v10, v16
	bit.16b	v10, v16, v0
	bit.16b	v6, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_77
; %bb.78:                               ; %direct.false263.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q10, [sp, #2352]                ; 16-byte Spill
	str	q6, [sp, #2368]                 ; 16-byte Spill
	ldr	q6, [sp, #2384]                 ; 16-byte Reload
	and.16b	v6, v17, v6
	and.16b	v5, v18, v5
	mov	x5, x10
	mov	w6, #80                         ; =0x50
LBB1_79:                                ; %direct.true279.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #16384]
	ldr	q24, [x5, #16400]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v5, v1
	fadd.4s	v16, v6, v16
	bit.16b	v6, v16, v0
	bit.16b	v5, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_79
; %bb.80:                               ; %direct.false280.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q6, [sp, #2384]                 ; 16-byte Spill
	str	q5, [sp, #2400]                 ; 16-byte Spill
	ldr	q5, [sp, #2416]                 ; 16-byte Reload
	and.16b	v5, v17, v5
	and.16b	v4, v18, v4
	mov	x5, x10
	mov	w6, #80                         ; =0x50
LBB1_81:                                ; %direct.true296.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #18944]
	ldr	q24, [x5, #18960]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v4, v1
	fadd.4s	v16, v5, v16
	bit.16b	v5, v16, v0
	bit.16b	v4, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_81
; %bb.82:                               ; %direct.false297.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q5, [sp, #2416]                 ; 16-byte Spill
	str	q4, [sp, #2432]                 ; 16-byte Spill
	ldr	q4, [sp, #2448]                 ; 16-byte Reload
	and.16b	v4, v17, v4
	and.16b	v3, v18, v3
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q6, [sp, #2368]                 ; 16-byte Reload
LBB1_83:                                ; %direct.true313.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #21504]
	ldr	q24, [x5, #21520]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v3, v1
	fadd.4s	v16, v4, v16
	bit.16b	v4, v16, v0
	bit.16b	v3, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_83
; %bb.84:                               ; %direct.false314.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q4, [sp, #2448]                 ; 16-byte Spill
	str	q3, [sp, #2464]                 ; 16-byte Spill
	ldr	q3, [sp, #2480]                 ; 16-byte Reload
	and.16b	v3, v17, v3
	and.16b	v8, v18, v8
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q5, [sp, #2400]                 ; 16-byte Reload
LBB1_85:                                ; %direct.true330.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #24064]
	ldr	q24, [x5, #24080]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v8, v1
	fadd.4s	v16, v3, v16
	bit.16b	v3, v16, v0
	bit.16b	v8, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_85
; %bb.86:                               ; %direct.false331.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q3, [sp, #2480]                 ; 16-byte Spill
	str	q8, [sp, #2496]                 ; 16-byte Spill
	ldr	q8, [sp, #2512]                 ; 16-byte Reload
	and.16b	v8, v17, v8
	and.16b	v28, v18, v28
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q4, [sp, #2432]                 ; 16-byte Reload
LBB1_87:                                ; %direct.true347.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #26624]
	ldr	q24, [x5, #26640]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v28, v1
	fadd.4s	v16, v8, v16
	bit.16b	v8, v16, v0
	bit.16b	v28, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_87
; %bb.88:                               ; %direct.false348.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q8, [sp, #2512]                 ; 16-byte Spill
	str	q28, [sp, #2528]                ; 16-byte Spill
	ldr	q28, [sp, #2544]                ; 16-byte Reload
	and.16b	v28, v17, v28
	and.16b	v14, v18, v14
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
LBB1_89:                                ; %direct.true364.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #29184]
	ldr	q24, [x5, #29200]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v14, v1
	fadd.4s	v16, v28, v16
	bit.16b	v28, v16, v0
	bit.16b	v14, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_89
; %bb.90:                               ; %direct.false365.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q28, [sp, #2544]                ; 16-byte Spill
	str	q14, [sp, #2224]                ; 16-byte Spill
	ldr	q14, [sp, #2560]                ; 16-byte Reload
	and.16b	v14, v17, v14
	and.16b	v13, v18, v13
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q8, [sp, #2496]                 ; 16-byte Reload
LBB1_91:                                ; %direct.true381.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #31744]
	ldr	q24, [x5, #31760]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v13, v1
	fadd.4s	v16, v14, v16
	bit.16b	v14, v16, v0
	bit.16b	v13, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_91
; %bb.92:                               ; %direct.false382.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q14, [sp, #2560]                ; 16-byte Spill
	str	q13, [sp, #2240]                ; 16-byte Spill
	ldr	q13, [sp, #2576]                ; 16-byte Reload
	and.16b	v13, v17, v13
	and.16b	v12, v18, v12
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q28, [sp, #2528]                ; 16-byte Reload
LBB1_93:                                ; %direct.true398.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #34304]
	ldr	q24, [x5, #34320]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v12, v1
	fadd.4s	v16, v13, v16
	bit.16b	v13, v16, v0
	bit.16b	v12, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_93
; %bb.94:                               ; %direct.false399.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q13, [sp, #2576]                ; 16-byte Spill
	str	q12, [sp, #2256]                ; 16-byte Spill
	ldr	q12, [sp, #2592]                ; 16-byte Reload
	and.16b	v12, v17, v12
	and.16b	v20, v18, v20
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q14, [sp, #2224]                ; 16-byte Reload
LBB1_95:                                ; %direct.true415.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #36864]
	ldr	q24, [x5, #36880]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v20, v1
	fadd.4s	v16, v12, v16
	bit.16b	v12, v16, v0
	bit.16b	v20, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_95
; %bb.96:                               ; %direct.false416.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q12, [sp, #2592]                ; 16-byte Spill
	str	q20, [sp, #2272]                ; 16-byte Spill
	ldr	q20, [sp, #2608]                ; 16-byte Reload
	and.16b	v20, v17, v20
	and.16b	v27, v18, v27
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q13, [sp, #2240]                ; 16-byte Reload
LBB1_97:                                ; %direct.true432.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #39424]
	ldr	q24, [x5, #39440]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v27, v1
	fadd.4s	v16, v20, v16
	bit.16b	v20, v16, v0
	bit.16b	v27, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_97
; %bb.98:                               ; %direct.false433.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q20, [sp, #2608]                ; 16-byte Spill
	str	q27, [sp, #2624]                ; 16-byte Spill
	ldr	q27, [sp, #2640]                ; 16-byte Reload
	and.16b	v27, v17, v27
	and.16b	v22, v18, v22
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q12, [sp, #2256]                ; 16-byte Reload
LBB1_99:                                ; %direct.true449.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #41984]
	ldr	q24, [x5, #42000]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v22, v1
	fadd.4s	v16, v27, v16
	bit.16b	v27, v16, v0
	bit.16b	v22, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_99
; %bb.100:                              ; %direct.false450.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q27, [sp, #2640]                ; 16-byte Spill
	and.16b	v31, v17, v31
	and.16b	v25, v18, v25
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q20, [sp, #2272]                ; 16-byte Reload
LBB1_101:                               ; %direct.true466.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #44544]
	ldr	q24, [x5, #44560]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v25, v1
	fadd.4s	v16, v31, v16
	bit.16b	v31, v16, v0
	bit.16b	v25, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_101
; %bb.102:                              ; %direct.false467.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q22, [sp, #2656]                ; 16-byte Spill
	str	q31, [sp, #2672]                ; 16-byte Spill
	str	q25, [sp, #2688]                ; 16-byte Spill
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	and.16b	v17, v17, v1
	and.16b	v7, v18, v7
	mov	x5, x10
	mov	w6, #80                         ; =0x50
	ldr	q18, [sp, #2624]                ; 16-byte Reload
	ldr	q23, [sp, #2608]                ; 16-byte Reload
	ldr	q27, [sp, #2592]                ; 16-byte Reload
LBB1_103:                               ; %direct.true483.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q16, [x5]
	ldr	q21, [x5, #47104]
	ldr	q24, [x5, #47120]
	fmul.4s	v16, v16, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v1, v7, v1
	fadd.4s	v16, v17, v16
	bit.16b	v17, v16, v0
	bit.16b	v7, v1, v2
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_103
; %bb.104:                              ; %direct.false484.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q30, [sp, #2704]                ; 16-byte Spill
	str	q9, [sp, #1504]                 ; 16-byte Spill
	str	q15, [sp, #1520]                ; 16-byte Spill
	mov	x5, #0                          ; =0x0
	mov	w6, #63790                      ; =0xf92e
	movk	w6, #15844, lsl #16
	dup.4s	v10, w6
	ldr	q1, [sp, #2304]                 ; 16-byte Reload
	fmul.4s	v15, v1, v10
	ldr	q1, [sp, #2288]                 ; 16-byte Reload
	fmul.4s	v9, v1, v10
	mov	w6, #33280                      ; =0x8200
	movk	w6, #1, lsl #16
	add	x6, x10, x6
	ldp	q1, q16, [x6]
	ldr	q19, [sp, #2336]                ; 16-byte Reload
	fmul.4s	v25, v19, v10
	cmp	x0, #128
	bit.16b	v16, v9, v0
	bit.16b	v1, v15, v2
	stp	q1, q16, [x6]
	cset	w6, lo
	dup.4h	v31, w6
	ldr	q1, [sp, #2320]                 ; 16-byte Reload
	fmul.4s	v24, v1, v10
	fmul.4s	v26, v6, v10
	ldr	q1, [sp, #2352]                 ; 16-byte Reload
	fmul.4s	v19, v1, v10
	fmul.4s	v22, v5, v10
	ldr	x7, [sp, #392]                  ; 8-byte Reload
	ldp	q16, q21, [x7]
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	fmul.4s	v6, v1, v10
	fmul.4s	v5, v4, v10
	str	q24, [sp, #2144]                ; 16-byte Spill
	bit.16b	v21, v24, v0
	str	q25, [sp, #2128]                ; 16-byte Spill
	bit.16b	v16, v25, v2
	stp	q16, q21, [x7]
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	fmul.4s	v4, v1, v10
	ldr	q1, [sp, #2448]                 ; 16-byte Reload
	fmul.4s	v16, v1, v10
	fmul.4s	v21, v3, v10
	ldr	x7, [sp, #384]                  ; 8-byte Reload
	ldp	q24, q25, [x7]
	ldr	q1, [sp, #2480]                 ; 16-byte Reload
	fmul.4s	v1, v1, v10
	str	q1, [sp, #2176]                 ; 16-byte Spill
	str	q19, [sp, #2064]                ; 16-byte Spill
	bit.16b	v25, v19, v0
	str	q26, [sp, #2048]                ; 16-byte Spill
	bit.16b	v24, v26, v2
	stp	q24, q25, [x7]
	fmul.4s	v24, v8, v10
	ldr	q1, [sp, #2512]                 ; 16-byte Reload
	fmul.4s	v8, v1, v10
	fmul.4s	v25, v28, v10
	ldr	x7, [sp, #376]                  ; 8-byte Reload
	ldp	q1, q11, [x7]
	ldr	q19, [sp, #2544]                ; 16-byte Reload
	fmul.4s	v19, v19, v10
	str	q6, [sp, #1360]                 ; 16-byte Spill
	bit.16b	v11, v6, v0
	str	q22, [sp, #1344]                ; 16-byte Spill
	bit.16b	v1, v22, v2
	stp	q1, q11, [x7]
	fmul.4s	v11, v14, v10
	fmul.4s	v6, v13, v10
	ldr	q1, [sp, #2560]                 ; 16-byte Reload
	fmul.4s	v22, v1, v10
	ldr	x7, [sp, #368]                  ; 8-byte Reload
	mov.16b	v30, v17
	ldp	q1, q17, [x7]
	ushll.4s	v31, v31, #0
	str	q4, [sp, #1264]                 ; 16-byte Spill
	bit.16b	v17, v4, v0
	str	q5, [sp, #1248]                 ; 16-byte Spill
	bit.16b	v1, v5, v2
	stp	q1, q17, [x7]
	shl.4s	v1, v31, #31
	cmlt.4s	v1, v1, #0
	ldr	q26, [sp, #416]                 ; 16-byte Reload
	mov.16b	v3, v1
	bsl.16b	v3, v21, v26
	ldr	x7, [sp, #360]                  ; 8-byte Reload
	ldp	q17, q21, [x7]
	mov.16b	v4, v1
	bsl.16b	v4, v16, v26
	str	q4, [sp, #1152]                 ; 16-byte Spill
	mov.16b	v16, v0
	bsl.16b	v16, v4, v21
	str	q3, [sp, #1168]                 ; 16-byte Spill
	bit.16b	v17, v3, v2
	stp	q17, q16, [x7]
	fmul.4s	v16, v12, v10
	ldr	q17, [sp, #2576]                ; 16-byte Reload
	fmul.4s	v17, v17, v10
	mov.16b	v3, v1
	bsl.16b	v3, v24, v26
	ldr	x7, [sp, #352]                  ; 8-byte Reload
	ldp	q21, q24, [x7]
	ldr	q4, [sp, #2176]                 ; 16-byte Reload
	bif.16b	v4, v26, v1
	str	q4, [sp, #1056]                 ; 16-byte Spill
	bit.16b	v24, v4, v0
	str	q3, [sp, #1072]                 ; 16-byte Spill
	bit.16b	v21, v3, v2
	stp	q21, q24, [x7]
	fmul.4s	v21, v20, v10
	fmul.4s	v24, v27, v10
	mov.16b	v4, v1
	bsl.16b	v4, v25, v26
	ldr	x7, [sp, #344]                  ; 8-byte Reload
	ldp	q25, q31, [x7]
	mov.16b	v3, v1
	bsl.16b	v3, v8, v26
	stp	q4, q3, [sp, #960]              ; 32-byte Folded Spill
	bit.16b	v31, v3, v0
	bit.16b	v25, v4, v2
	stp	q25, q31, [x7]
	fmul.4s	v25, v18, v10
	fmul.4s	v31, v23, v10
	mov.16b	v3, v1
	bsl.16b	v3, v11, v26
	ldr	x7, [sp, #336]                  ; 8-byte Reload
	ldp	q11, q18, [x7]
	mov.16b	v4, v1
	bsl.16b	v4, v19, v26
	stp	q4, q3, [sp, #864]              ; 32-byte Folded Spill
	bit.16b	v18, v4, v0
	bit.16b	v11, v3, v2
	stp	q11, q18, [x7]
	ldr	q18, [sp, #2640]                ; 16-byte Reload
	fmul.4s	v18, v18, v10
	ldr	q19, [sp, #2656]                ; 16-byte Reload
	fmul.4s	v11, v19, v10
	mov.16b	v3, v1
	bsl.16b	v3, v22, v26
	ldr	x7, [sp, #328]                  ; 8-byte Reload
	mov.16b	v19, v7
	ldp	q7, q23, [x7]
	mov.16b	v4, v1
	bsl.16b	v4, v6, v26
	stp	q4, q3, [sp, #896]              ; 32-byte Folded Spill
	bit.16b	v7, v4, v2
	bit.16b	v23, v3, v0
	stp	q7, q23, [x7]
	mov.16b	v3, v1
	bsl.16b	v3, v17, v26
	mov.16b	v4, v1
	bsl.16b	v4, v16, v26
	mov.16b	v5, v1
	bsl.16b	v5, v24, v26
	ldr	x7, [sp, #320]                  ; 8-byte Reload
	ldp	q16, q7, [x7]
	mov.16b	v6, v1
	bsl.16b	v6, v21, v26
	stp	q4, q3, [sp, #992]              ; 32-byte Folded Spill
	bit.16b	v16, v4, v2
	bit.16b	v7, v3, v0
	stp	q16, q7, [x7]
	mov.16b	v3, v1
	bsl.16b	v3, v31, v26
	mov.16b	v4, v1
	bsl.16b	v4, v25, v26
	ldr	x7, [sp, #312]                  ; 8-byte Reload
	ldp	q16, q7, [x7]
	str	q6, [sp, #1088]                 ; 16-byte Spill
	bit.16b	v16, v6, v2
	str	q5, [sp, #1104]                 ; 16-byte Spill
	bit.16b	v7, v5, v0
	stp	q16, q7, [x7]
	ldr	x7, [sp, #304]                  ; 8-byte Reload
	ldp	q16, q7, [x7]
	str	q4, [sp, #1184]                 ; 16-byte Spill
	bit.16b	v16, v4, v2
	str	q3, [sp, #1200]                 ; 16-byte Spill
	bit.16b	v7, v3, v0
	stp	q16, q7, [x7]
	ldr	q7, [sp, #2688]                 ; 16-byte Reload
	fmul.4s	v7, v7, v10
	ldr	q16, [sp, #2672]                ; 16-byte Reload
	fmul.4s	v16, v16, v10
	str	q19, [sp, #1824]                ; 16-byte Spill
	fmul.4s	v17, v19, v10
	str	q30, [sp, #1808]                ; 16-byte Spill
	fmul.4s	v21, v30, v10
	mov.16b	v19, v1
	bsl.16b	v19, v11, v26
	bif.16b	v18, v26, v1
	mov.16b	v5, v1
	bsl.16b	v5, v16, v26
	mov.16b	v6, v1
	bsl.16b	v6, v7, v26
	mov.16b	v3, v1
	bsl.16b	v3, v21, v26
	mov.16b	v4, v1
	bsl.16b	v4, v17, v26
	ldr	x7, [sp, #296]                  ; 8-byte Reload
	ldp	q7, q1, [x7]
	str	q18, [sp, #1280]                ; 16-byte Spill
	bit.16b	v1, v18, v0
	str	q19, [sp, #1296]                ; 16-byte Spill
	bit.16b	v7, v19, v2
	stp	q7, q1, [x7]
	ldr	x7, [sp, #288]                  ; 8-byte Reload
	ldp	q1, q7, [x7]
	str	q6, [sp, #1408]                 ; 16-byte Spill
	bit.16b	v1, v6, v2
	str	q5, [sp, #1424]                 ; 16-byte Spill
	bit.16b	v7, v5, v0
	stp	q1, q7, [x7]
	ldr	x7, [sp, #280]                  ; 8-byte Reload
	ldp	q1, q7, [x7]
	str	q4, [sp, #2080]                 ; 16-byte Spill
	bit.16b	v1, v4, v2
	str	q3, [sp, #2096]                 ; 16-byte Spill
	bit.16b	v7, v3, v0
	stp	q1, q7, [x7]
	mvni.4s	v1, #127, msl #16
	ldr	q17, [sp, #1840]                ; 16-byte Reload
	bit.16b	v17, v1, v0
	mvni.4s	v23, #127, msl #16
	ldr	q16, [sp, #1856]                ; 16-byte Reload
	bit.16b	v16, v1, v2
	dup.8b	v1, w6
	str	d1, [sp, #2032]                 ; 8-byte Spill
LBB1_105:                               ; %direct.true597.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x6, x14, x5
	ldp	q1, q7, [x6]
	and.16b	v7, v0, v7
	and.16b	v1, v2, v1
	fmaxnm.4s	v1, v16, v1
	fmaxnm.4s	v7, v17, v7
	bit.16b	v17, v7, v0
	bit.16b	v16, v1, v2
	add	x5, x5, #32
	cmp	x5, #512
	b.ne	LBB1_105
; %bb.106:                              ; %direct.false598.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x5, #0                          ; =0x0
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	bit.16b	v3, v29, v1
	str	q3, [sp, #1744]                 ; 16-byte Spill
	ldr	q7, [sp, #1952]                 ; 16-byte Reload
	bit.16b	v7, v29, v1
	str	q7, [sp, #1952]                 ; 16-byte Spill
	str	q16, [sp, #1856]                ; 16-byte Spill
	ldr	q1, [sp, #2720]                 ; 16-byte Reload
	fmaxnm.4s	v11, v1, v16
	fsub.4s	v1, v15, v11
	ldp	q4, q7, [sp, #496]              ; 32-byte Folded Reload
	cmhi.4s	v31, v4, v7
	and.16b	v4, v31, v1
	mov	w6, #-1026555904                ; =0xc2d00000
	dup.4s	v27, w6
	fcmge.4s	v1, v4, v27
	mov	w6, #1120403456                 ; =0x42c80000
	dup.4s	v20, w6
	fcmge.4s	v7, v20, v4
	and.16b	v1, v1, v7
	str	q17, [sp, #1840]                ; 16-byte Spill
	ldr	q3, [sp, #2736]                 ; 16-byte Reload
	fmaxnm.4s	v6, v3, v17
	fsub.4s	v7, v9, v6
	and.16b	v28, v0, v7
	fcmge.4s	v7, v28, v27
	fcmge.4s	v16, v20, v28
	and.16b	v7, v7, v16
	and.16b	v7, v7, v28
	mov	w6, #43579                      ; =0xaa3b
	movk	w6, #16312, lsl #16
	dup.4s	v13, w6
	fmul.4s	v16, v7, v13
	movi.4s	v3, #75, lsl #24
	mvni.4s	v14, #128, lsl #24
	mov.16b	v17, v14
	bsl.16b	v17, v3, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v4
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v3, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	mov	w6, #29184                      ; =0x7200
	movk	w6, #16177, lsl #16
	dup.4s	v15, w6
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v10, v18
	scvtf.4s	v18, v10
	fmul.4s	v21, v18, v15
	fsub.4s	v17, v17, v21
	mov	w6, #48782                      ; =0xbe8e
	movk	w6, #13759, lsl #16
	dup.4s	v5, w6
	fmul.4s	v18, v18, v5
	fsub.4s	v17, v17, v18
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	mov	w6, #11226                      ; =0x2bda
	movk	w6, #14672, lsl #16
	dup.4s	v9, w6
	fmul.4s	v16, v7, v9
	mov	w6, #38601                      ; =0x96c9
	movk	w6, #15030, lsl #16
	dup.4s	v29, w6
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	mov	w6, #34982                      ; =0x88a6
	movk	w6, #15368, lsl #16
	dup.4s	v22, w6
	fadd.4s	v16, v16, v22
	mov	w6, #43642                      ; =0xaa7a
	movk	w6, #15658, lsl #16
	dup.4s	v30, w6
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	mov	w6, #43691                      ; =0xaaab
	movk	w6, #15914, lsl #16
	dup.4s	v3, w6
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	movi.4s	v26, #63, lsl #24
	fadd.4s	v16, v16, v26
	fmul.4s	v18, v7, v7
	fmul.4s	v16, v18, v16
	fmul.4s	v18, v17, v9
	fadd.4s	v18, v18, v29
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v30
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v17, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v21, v17, v17
	fmul.4s	v18, v21, v18
	fadd.4s	v17, v17, v18
	fadd.4s	v7, v7, v16
	fmov.4s	v24, #1.00000000
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v10, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v24
	fmul.4s	v16, v16, v18
	fadd.4s	v7, v7, v24
	sshr.4s	v18, v1, #1
	shl.4s	v21, v18, #23
	add.4s	v21, v21, v24
	fmul.4s	v7, v7, v21
	sub.4s	v17, v10, v17
	sub.4s	v1, v1, v18
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q4, [sp, #624]                  ; 16-byte Spill
	fcmgt.4s	v16, v27, v4
	bic.16b	v7, v7, v16
	str	q28, [sp, #2112]                ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v28, v20
	fneg.4s	v25, v23
	bit.16b	v1, v25, v16
	str	q1, [sp, #2176]                 ; 16-byte Spill
	fcmgt.4s	v1, v4, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #2160]                 ; 16-byte Spill
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v28, v31, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #2144]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v8, v0, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	movi.4s	v4, #75, lsl #24
	mov.16b	v17, v14
	bsl.16b	v17, v4, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v4, v1
	movi.4s	v19, #75, lsl #24
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #944]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #848]                  ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #2144]                 ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #2128]                 ; 16-byte Spill
	ldr	q1, [sp, #2048]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v28, v31, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #2064]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v8, v0, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #1392]                ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #1376]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #2064]                 ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #2048]                 ; 16-byte Spill
	ldr	q1, [sp, #1344]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v28, v31, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #1360]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v8, v0, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #1328]                ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #1312]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #1360]                 ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #1344]                 ; 16-byte Spill
	ldr	q1, [sp, #1248]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v28, v31, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #1264]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v8, v0, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #1232]                ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #1216]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #1264]                 ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #1248]                 ; 16-byte Spill
	ldr	q1, [sp, #1152]                 ; 16-byte Reload
	fsub.4s	v1, v1, v6
	and.16b	v28, v0, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #1168]                 ; 16-byte Reload
	fsub.4s	v7, v7, v11
	and.16b	v8, v31, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #1136]                ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #1120]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #1168]                 ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #1152]                 ; 16-byte Spill
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	fsub.4s	v1, v1, v6
	and.16b	v28, v0, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #1072]                 ; 16-byte Reload
	fsub.4s	v7, v7, v11
	and.16b	v8, v31, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #1040]                ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #1024]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #1072]                 ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #1056]                 ; 16-byte Spill
	ldp	q4, q1, [sp, #960]              ; 32-byte Folded Reload
	fsub.4s	v1, v1, v6
	and.16b	v28, v0, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	fsub.4s	v7, v4, v11
	and.16b	v8, v31, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #816]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #928]                  ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #976]                  ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #960]                  ; 16-byte Spill
	ldr	q1, [sp, #864]                  ; 16-byte Reload
	fsub.4s	v1, v1, v6
	and.16b	v28, v0, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #880]                  ; 16-byte Reload
	fsub.4s	v7, v7, v11
	and.16b	v8, v31, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #784]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #832]                  ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #880]                  ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #864]                  ; 16-byte Spill
	ldr	q1, [sp, #896]                  ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v28, v31, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #912]                  ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v8, v0, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #752]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #800]                  ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #912]                  ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #896]                  ; 16-byte Spill
	ldr	q1, [sp, #992]                  ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v28, v31, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #1008]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v8, v0, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #720]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #768]                  ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #1008]                 ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #992]                  ; 16-byte Spill
	ldr	q1, [sp, #1088]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v28, v31, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #1104]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v8, v0, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #688]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #736]                  ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #1104]                 ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #1088]                 ; 16-byte Spill
	ldr	q1, [sp, #1184]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v28, v31, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #1200]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v8, v0, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #608]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #704]                  ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #1200]                 ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #1184]                 ; 16-byte Spill
	ldr	q1, [sp, #1280]                 ; 16-byte Reload
	fsub.4s	v1, v1, v6
	and.16b	v28, v0, v1
	fcmge.4s	v1, v28, v27
	fcmge.4s	v7, v20, v28
	and.16b	v1, v1, v7
	ldr	q7, [sp, #1296]                 ; 16-byte Reload
	fsub.4s	v7, v7, v11
	and.16b	v8, v31, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v28
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	str	q28, [sp, #592]                 ; 16-byte Spill
	fcmgt.4s	v16, v27, v28
	bic.16b	v7, v7, v16
	str	q8, [sp, #672]                  ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #1280]                 ; 16-byte Spill
	fcmgt.4s	v1, v28, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #1296]                 ; 16-byte Spill
	ldr	q1, [sp, #1408]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v10, v31, v1
	fcmge.4s	v1, v10, v27
	fcmge.4s	v7, v20, v10
	and.16b	v1, v1, v7
	ldr	q7, [sp, #1424]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v8, v0, v7
	fcmge.4s	v7, v8, v27
	fcmge.4s	v16, v20, v8
	and.16b	v7, v7, v16
	and.16b	v7, v7, v8
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v10
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	fcmgt.4s	v16, v27, v10
	bic.16b	v7, v7, v16
	str	q8, [sp, #528]                  ; 16-byte Spill
	fcmgt.4s	v16, v27, v8
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v8, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #656]                  ; 16-byte Spill
	fcmgt.4s	v1, v10, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #640]                  ; 16-byte Spill
	ldr	q1, [sp, #2080]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v8, v31, v1
	fcmge.4s	v1, v8, v27
	fcmge.4s	v7, v20, v8
	and.16b	v1, v1, v7
	ldr	q7, [sp, #2096]                 ; 16-byte Reload
	fsub.4s	v7, v7, v6
	and.16b	v12, v0, v7
	fcmge.4s	v7, v12, v27
	fcmge.4s	v16, v20, v12
	and.16b	v7, v7, v16
	and.16b	v7, v7, v12
	fmul.4s	v16, v7, v13
	movi.4s	v4, #75, lsl #24
	mov.16b	v17, v14
	bsl.16b	v17, v4, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v17, v1, v8
	fmul.4s	v1, v17, v13
	mov.16b	v18, v14
	bsl.16b	v18, v4, v1
	fadd.4s	v1, v1, v18
	fsub.4s	v18, v1, v18
	fcvtzs.4s	v1, v16
	scvtf.4s	v16, v1
	fmul.4s	v21, v16, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v18, v18
	scvtf.4s	v21, v18
	fmul.4s	v23, v21, v15
	fsub.4s	v17, v17, v23
	fmul.4s	v21, v21, v5
	fsub.4s	v17, v17, v21
	fmul.4s	v16, v16, v5
	fsub.4s	v7, v7, v16
	fmul.4s	v16, v7, v9
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v30
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v3
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v26
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v21, v17, v9
	fadd.4s	v21, v21, v29
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v30
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v3
	fmul.4s	v21, v17, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v17, v17
	fmul.4s	v21, v23, v21
	fadd.4s	v17, v17, v21
	fadd.4s	v7, v7, v16
	fadd.4s	v16, v17, v24
	sshr.4s	v17, v18, #1
	shl.4s	v21, v17, #23
	add.4s	v21, v21, v24
	fmul.4s	v16, v16, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v1, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v18, v17
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v24
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v24
	fmul.4s	v7, v16, v7
	fcmgt.4s	v16, v27, v8
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v27, v12
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v12, v20
	bit.16b	v1, v25, v16
	str	q1, [sp, #2096]                 ; 16-byte Spill
	fcmgt.4s	v1, v8, v20
	bsl.16b	v1, v25, v7
	str	q1, [sp, #2080]                 ; 16-byte Spill
	str	q6, [sp, #1408]                 ; 16-byte Spill
	ldr	q1, [sp, #2736]                 ; 16-byte Reload
	fsub.4s	v1, v1, v6
	and.16b	v4, v0, v1
	fcmge.4s	v1, v4, v27
	fcmge.4s	v7, v20, v4
	and.16b	v1, v1, v7
	str	q11, [sp, #1424]                ; 16-byte Spill
	ldr	q6, [sp, #2720]                 ; 16-byte Reload
	fsub.4s	v7, v6, v11
	and.16b	v6, v31, v7
	fcmge.4s	v7, v6, v27
	fcmge.4s	v16, v20, v6
	and.16b	v7, v7, v16
	and.16b	v7, v7, v6
	fmul.4s	v16, v7, v13
	mov.16b	v17, v14
	bsl.16b	v17, v19, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v1, v1, v4
	fmul.4s	v17, v1, v13
	mov.16b	v18, v14
	bsl.16b	v18, v19, v17
	fadd.4s	v17, v17, v18
	fsub.4s	v17, v17, v18
	fcvtzs.4s	v16, v16
	scvtf.4s	v18, v16
	fmul.4s	v21, v18, v15
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v17, v17
	scvtf.4s	v21, v17
	fmul.4s	v23, v21, v15
	fsub.4s	v1, v1, v23
	fmul.4s	v18, v18, v5
	fmul.4s	v21, v21, v5
	fsub.4s	v1, v1, v21
	fsub.4s	v7, v7, v18
	fmul.4s	v18, v7, v9
	fmul.4s	v21, v1, v9
	fadd.4s	v21, v21, v29
	fadd.4s	v18, v18, v29
	fmul.4s	v18, v7, v18
	fmul.4s	v21, v1, v21
	fadd.4s	v21, v21, v22
	fadd.4s	v18, v18, v22
	fmul.4s	v18, v7, v18
	fmul.4s	v21, v1, v21
	fadd.4s	v21, v21, v30
	fadd.4s	v18, v18, v30
	fmul.4s	v18, v7, v18
	fmul.4s	v21, v1, v21
	fadd.4s	v21, v21, v3
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v7, v18
	fadd.4s	v18, v18, v26
	fmul.4s	v23, v7, v7
	fmul.4s	v18, v23, v18
	fmul.4s	v21, v1, v21
	fadd.4s	v21, v21, v26
	fmul.4s	v23, v1, v1
	fmul.4s	v21, v23, v21
	fadd.4s	v1, v1, v21
	fadd.4s	v7, v7, v18
	fadd.4s	v1, v1, v24
	sshr.4s	v18, v17, #1
	shl.4s	v21, v18, #23
	add.4s	v21, v21, v24
	fmul.4s	v1, v1, v21
	fadd.4s	v7, v7, v24
	sshr.4s	v21, v16, #1
	shl.4s	v23, v21, #23
	add.4s	v23, v23, v24
	fmul.4s	v7, v7, v23
	sub.4s	v17, v17, v18
	sub.4s	v16, v16, v21
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v24
	fmul.4s	v7, v7, v16
	shl.4s	v16, v17, #23
	add.4s	v16, v16, v24
	fmul.4s	v1, v1, v16
	fcmgt.4s	v16, v27, v4
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v27, v6
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v6, v20
	mov.16b	v3, v16
	bsl.16b	v3, v25, v7
	stp	q6, q3, [sp, #560]              ; 32-byte Folded Spill
	fcmgt.4s	v7, v4, v20
	mov.16b	v30, v4
	bit.16b	v1, v25, v7
	str	q1, [sp, #544]                  ; 16-byte Spill
	sshll2.2d	v1, v31, #0
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	ldr	q4, [sp, #2192]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #1776]                 ; 16-byte Spill
	ldr	q7, [sp, #1984]                 ; 16-byte Reload
	bit.16b	v7, v4, v1
	str	q7, [sp, #1984]                 ; 16-byte Spill
	sshll.2d	v1, v0, #0
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	ldr	q4, [sp, #2208]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #1760]                 ; 16-byte Spill
	ldr	q7, [sp, #1968]                 ; 16-byte Reload
	bit.16b	v7, v4, v1
	str	q7, [sp, #1968]                 ; 16-byte Spill
	ldr	q1, [sp, #624]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q26, [sp, #192]                 ; 16-byte Reload
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	mov.16b	v5, v1
	bsl.16b	v5, v3, v26
	str	q5, [sp, #2208]                 ; 16-byte Spill
	ldr	q1, [sp, #2112]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	mov.16b	v4, v1
	bsl.16b	v4, v3, v26
	str	q4, [sp, #2192]                 ; 16-byte Spill
	ldr	q1, [sp, #944]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	mov.16b	v20, v1
	bsl.16b	v20, v3, v26
	str	q20, [sp, #2176]                ; 16-byte Spill
	ldr	q1, [sp, #848]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	mov.16b	v6, v1
	bsl.16b	v6, v3, v26
	str	q6, [sp, #2160]                 ; 16-byte Spill
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	mov.16b	v22, v1
	bsl.16b	v22, v3, v26
	str	q22, [sp, #2144]                ; 16-byte Spill
	ldr	q1, [sp, #1376]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	mov.16b	v17, v1
	bsl.16b	v17, v3, v26
	str	q17, [sp, #2128]                ; 16-byte Spill
	ldr	q1, [sp, #1328]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1344]                 ; 16-byte Reload
	mov.16b	v28, v1
	bsl.16b	v28, v3, v26
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1360]                 ; 16-byte Reload
	mov.16b	v19, v1
	bsl.16b	v19, v3, v26
	str	q19, [sp, #2112]                ; 16-byte Spill
	ldr	q1, [sp, #1232]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1248]                 ; 16-byte Reload
	mov.16b	v14, v1
	bsl.16b	v14, v3, v26
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1264]                 ; 16-byte Reload
	mov.16b	v13, v1
	bsl.16b	v13, v3, v26
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	mov.16b	v29, v1
	bsl.16b	v29, v3, v26
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1168]                 ; 16-byte Reload
	mov.16b	v27, v1
	bsl.16b	v27, v3, v26
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1056]                 ; 16-byte Reload
	mov.16b	v15, v1
	bsl.16b	v15, v3, v26
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1072]                 ; 16-byte Reload
	bsl.16b	v1, v3, v26
	str	q1, [sp, #1392]                 ; 16-byte Spill
	ldr	q1, [sp, #816]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldp	q7, q3, [sp, #960]              ; 32-byte Folded Reload
	mov.16b	v9, v1
	bsl.16b	v9, v7, v26
	ldr	q1, [sp, #928]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v3, v26
	str	q1, [sp, #1376]                 ; 16-byte Spill
	ldr	q1, [sp, #784]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldp	q7, q3, [sp, #864]              ; 32-byte Folded Reload
	mov.16b	v18, v1
	bsl.16b	v18, v7, v26
	ldr	q1, [sp, #832]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v3, v26
	str	q1, [sp, #1360]                 ; 16-byte Spill
	ldr	q1, [sp, #752]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldp	q7, q3, [sp, #896]              ; 32-byte Folded Reload
	bsl.16b	v1, v7, v26
	str	q1, [sp, #1344]                 ; 16-byte Spill
	ldr	q1, [sp, #800]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	mov.16b	v21, v1
	bsl.16b	v21, v3, v26
	ldr	q1, [sp, #720]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldp	q7, q3, [sp, #992]              ; 32-byte Folded Reload
	bsl.16b	v1, v7, v26
	str	q1, [sp, #1328]                 ; 16-byte Spill
	ldr	q1, [sp, #768]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	mov.16b	v23, v1
	bsl.16b	v23, v3, v26
	ldr	q1, [sp, #688]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	bsl.16b	v1, v3, v26
	str	q1, [sp, #1312]                 ; 16-byte Spill
	ldr	q1, [sp, #736]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1104]                 ; 16-byte Reload
	mov.16b	v24, v1
	bsl.16b	v24, v3, v26
	ldr	q1, [sp, #608]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	bsl.16b	v1, v3, v26
	str	q1, [sp, #1264]                 ; 16-byte Spill
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1200]                 ; 16-byte Reload
	mov.16b	v25, v1
	bsl.16b	v25, v3, v26
	ldr	q1, [sp, #592]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1296]                 ; 16-byte Reload
	mov.16b	v11, v1
	bsl.16b	v11, v3, v26
	ldr	q1, [sp, #672]                  ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q3, [sp, #1280]                 ; 16-byte Reload
	bsl.16b	v1, v3, v26
	str	q1, [sp, #1296]                 ; 16-byte Spill
	fcmeq.4s	v1, v10, v10
	ldr	q3, [sp, #640]                  ; 16-byte Reload
	bsl.16b	v1, v3, v26
	str	q1, [sp, #1280]                 ; 16-byte Spill
	ldr	q1, [sp, #528]                  ; 16-byte Reload
	fcmeq.4s	v10, v1, v1
	ldr	q1, [sp, #656]                  ; 16-byte Reload
	bsl.16b	v10, v1, v26
	fcmeq.4s	v1, v8, v8
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	bsl.16b	v1, v3, v26
	str	q1, [sp, #1248]                 ; 16-byte Spill
	fcmeq.4s	v1, v12, v12
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	bsl.16b	v1, v3, v26
	ldr	x6, [sp, #272]                  ; 8-byte Reload
	ldp	q16, q7, [x6]
	bit.16b	v7, v4, v0
	bit.16b	v16, v5, v31
	stp	q16, q7, [x6]
	ldr	d3, [sp, #2032]                 ; 8-byte Reload
	zip2.8b	v7, v3, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v5, v7, v29
	and.16b	v29, v7, v15
	and.16b	v8, v7, v9
	and.16b	v9, v7, v18
	and.16b	v12, v7, v21
	and.16b	v4, v7, v23
	str	q4, [sp, #2048]                 ; 16-byte Spill
	and.16b	v15, v7, v24
	and.16b	v21, v7, v25
	str	q21, [sp, #2064]                ; 16-byte Spill
	and.16b	v11, v7, v11
	and.16b	v18, v7, v10
	str	q18, [sp, #2080]                ; 16-byte Spill
	and.16b	v16, v7, v1
	str	q16, [sp, #2096]                ; 16-byte Spill
	ldp	x6, x7, [sp, #256]              ; 16-byte Folded Reload
	ldp	q7, q1, [x7]
	bit.16b	v1, v6, v0
	bit.16b	v7, v20, v31
	stp	q7, q1, [x7]
	ldp	q7, q1, [x6]
	bit.16b	v1, v17, v0
	bit.16b	v7, v22, v31
	stp	q7, q1, [x6]
	ldr	x6, [sp, #248]                  ; 8-byte Reload
	ldp	q7, q1, [x6]
	bit.16b	v1, v19, v0
	bit.16b	v7, v28, v31
	mov.16b	v24, v28
	stp	q7, q1, [x6]
	ldr	x6, [sp, #240]                  ; 8-byte Reload
	ldp	q7, q1, [x6]
	bit.16b	v1, v13, v0
	bit.16b	v7, v14, v31
	stp	q7, q1, [x6]
	zip1.8b	v1, v3, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v25, v1, v27
	ldr	q3, [sp, #1392]                 ; 16-byte Reload
	and.16b	v6, v1, v3
	ldr	q3, [sp, #1376]                 ; 16-byte Reload
	and.16b	v17, v1, v3
	ldr	q3, [sp, #1360]                 ; 16-byte Reload
	and.16b	v19, v1, v3
	ldr	q3, [sp, #1344]                 ; 16-byte Reload
	and.16b	v20, v1, v3
	ldr	q3, [sp, #1328]                 ; 16-byte Reload
	and.16b	v22, v1, v3
	ldr	q3, [sp, #1312]                 ; 16-byte Reload
	and.16b	v23, v1, v3
	ldr	q3, [sp, #1264]                 ; 16-byte Reload
	and.16b	v27, v1, v3
	ldr	q3, [sp, #1296]                 ; 16-byte Reload
	and.16b	v28, v1, v3
	ldr	q3, [sp, #1280]                 ; 16-byte Reload
	and.16b	v10, v1, v3
	ldr	q3, [sp, #1248]                 ; 16-byte Reload
	and.16b	v3, v1, v3
	str	q3, [sp, #2032]                 ; 16-byte Spill
	ldr	x6, [sp, #232]                  ; 8-byte Reload
	ldp	q7, q1, [x6]
	bit.16b	v1, v5, v0
	bit.16b	v7, v25, v31
	stp	q7, q1, [x6]
	ldr	x6, [sp, #224]                  ; 8-byte Reload
	ldp	q7, q1, [x6]
	bit.16b	v1, v29, v0
	bit.16b	v7, v6, v31
	stp	q7, q1, [x6]
	ldr	x6, [sp, #216]                  ; 8-byte Reload
	ldp	q7, q1, [x6]
	bit.16b	v1, v8, v0
	bit.16b	v7, v17, v31
	stp	q7, q1, [x6]
	ldp	q7, q1, [x9]
	bit.16b	v1, v9, v0
	bit.16b	v7, v19, v31
	stp	q7, q1, [x9]
	ldp	q1, q7, [x22]
	bit.16b	v1, v20, v31
	bit.16b	v7, v12, v0
	stp	q1, q7, [x22]
	ldp	q1, q7, [x25]
	bit.16b	v1, v22, v31
	bit.16b	v7, v4, v0
	stp	q1, q7, [x25]
	ldp	q1, q7, [x27]
	bit.16b	v1, v23, v31
	bit.16b	v7, v15, v0
	stp	q1, q7, [x27]
	ldp	q1, q7, [x20]
	bit.16b	v1, v27, v31
	bit.16b	v7, v21, v0
	stp	q1, q7, [x20]
	ldp	q7, q1, [x2]
	bit.16b	v1, v11, v0
	bit.16b	v7, v28, v31
	stp	q7, q1, [x2]
	ldp	q1, q7, [x3]
	bit.16b	v1, v10, v31
	bit.16b	v7, v18, v0
	stp	q1, q7, [x3]
	ldp	q1, q7, [x4]
	bit.16b	v1, v3, v31
	bit.16b	v7, v16, v0
	stp	q1, q7, [x4]
	fcmeq.4s	v1, v30, v30
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	bif.16b	v3, v26, v1
	ldp	q1, q4, [sp, #560]              ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	mov.16b	v16, v1
	bsl.16b	v16, v4, v26
	sshll.2d	v1, v31, #0
	ldr	q7, [sp, #2000]                 ; 16-byte Reload
	ldr	q30, [sp, #1792]                ; 16-byte Reload
	bit.16b	v30, v7, v1
	ldr	q18, [sp, #2976]                ; 16-byte Reload
	bit.16b	v18, v7, v1
	str	q18, [sp, #2976]                ; 16-byte Spill
	ldr	q18, [sp, #3088]                ; 16-byte Reload
	str	q16, [sp, #1120]                ; 16-byte Spill
	bit.16b	v18, v16, v31
	str	q3, [sp, #1136]                 ; 16-byte Spill
	ldr	q1, [sp, #2752]                 ; 16-byte Reload
	bit.16b	v1, v3, v0
	str	q1, [sp, #2752]                 ; 16-byte Spill
	ldr	q21, [sp, #3104]                ; 16-byte Reload
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	bit.16b	v21, v1, v31
	ldr	q1, [sp, #2768]                 ; 16-byte Reload
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	bit.16b	v1, v3, v0
	str	q1, [sp, #2768]                 ; 16-byte Spill
	ldr	q1, [sp, #2800]                 ; 16-byte Reload
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	bit.16b	v1, v3, v31
	str	q1, [sp, #2800]                 ; 16-byte Spill
	ldr	q1, [sp, #2784]                 ; 16-byte Reload
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v3, v0
	str	q1, [sp, #2784]                 ; 16-byte Spill
	ldr	q1, [sp, #2832]                 ; 16-byte Reload
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	bit.16b	v1, v3, v31
	str	q1, [sp, #2832]                 ; 16-byte Spill
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	bit.16b	v3, v1, v0
	str	q3, [sp, #2816]                 ; 16-byte Spill
	str	q24, [sp, #1392]                ; 16-byte Spill
	ldr	q1, [sp, #2848]                 ; 16-byte Reload
	bit.16b	v1, v24, v31
	str	q1, [sp, #2848]                 ; 16-byte Spill
	ldr	q4, [sp, #2704]                 ; 16-byte Reload
	ldr	q1, [sp, #2112]                 ; 16-byte Reload
	bit.16b	v4, v1, v0
	ldr	q24, [sp, #1488]                ; 16-byte Reload
	str	q14, [sp, #1376]                ; 16-byte Spill
	bit.16b	v24, v14, v31
	str	q13, [sp, #1488]                ; 16-byte Spill
	ldr	q1, [sp, #2864]                 ; 16-byte Reload
	bit.16b	v1, v13, v0
	str	q1, [sp, #2864]                 ; 16-byte Spill
	ldr	q7, [sp, #1440]                 ; 16-byte Reload
	str	q25, [sp, #1152]                ; 16-byte Spill
	bit.16b	v7, v25, v31
	ldr	q25, [sp, #1872]                ; 16-byte Reload
	str	q5, [sp, #1328]                 ; 16-byte Spill
	bit.16b	v25, v5, v0
	str	q6, [sp, #1184]                 ; 16-byte Spill
	ldr	q1, [sp, #2928]                 ; 16-byte Reload
	bit.16b	v1, v6, v31
	str	q1, [sp, #2928]                 ; 16-byte Spill
	ldr	q5, [sp, #1456]                 ; 16-byte Reload
	str	q29, [sp, #1312]                ; 16-byte Spill
	bit.16b	v5, v29, v0
	str	q17, [sp, #1168]                ; 16-byte Spill
	ldr	q1, [sp, #2960]                 ; 16-byte Reload
	bit.16b	v1, v17, v31
	str	q1, [sp, #2960]                 ; 16-byte Spill
	str	q8, [sp, #1360]                 ; 16-byte Spill
	ldr	q3, [sp, #2944]                 ; 16-byte Reload
	bit.16b	v3, v8, v0
	str	q3, [sp, #2944]                 ; 16-byte Spill
	str	q19, [sp, #1216]                ; 16-byte Spill
	ldr	q1, [sp, #2912]                 ; 16-byte Reload
	bit.16b	v1, v19, v31
	str	q1, [sp, #2912]                 ; 16-byte Spill
	str	q9, [sp, #1344]                 ; 16-byte Spill
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	bit.16b	v3, v9, v0
	str	q3, [sp, #2896]                 ; 16-byte Spill
	ldr	q8, [sp, #1888]                 ; 16-byte Reload
	str	q20, [sp, #1200]                ; 16-byte Spill
	bit.16b	v8, v20, v31
	mov.16b	v6, v7
	ldr	q9, [sp, #1504]                 ; 16-byte Reload
	str	q12, [sp, #1440]                ; 16-byte Spill
	bit.16b	v9, v12, v0
	ldr	q13, [sp, #1616]                ; 16-byte Reload
	str	q22, [sp, #1248]                ; 16-byte Spill
	bit.16b	v13, v22, v31
	ldr	q14, [sp, #1600]                ; 16-byte Reload
	ldr	q1, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v14, v1, v0
	ldr	q20, [sp, #1648]                ; 16-byte Reload
	str	q23, [sp, #1232]                ; 16-byte Spill
	bit.16b	v20, v23, v31
	ldr	q12, [sp, #1632]                ; 16-byte Reload
	str	q15, [sp, #1456]                ; 16-byte Spill
	bit.16b	v12, v15, v0
	ldr	q29, [sp, #1680]                ; 16-byte Reload
	str	q27, [sp, #1280]                ; 16-byte Spill
	bit.16b	v29, v27, v31
	ldr	q19, [sp, #1664]                ; 16-byte Reload
	ldr	q1, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v19, v1, v0
	ldr	q15, [sp, #1584]                ; 16-byte Reload
	str	q28, [sp, #1264]                ; 16-byte Spill
	bit.16b	v15, v28, v31
	ldr	q28, [sp, #1568]                ; 16-byte Reload
	str	q11, [sp, #1504]                ; 16-byte Spill
	bit.16b	v28, v11, v0
	ldr	q11, [sp, #1904]                ; 16-byte Reload
	str	q10, [sp, #1296]                ; 16-byte Spill
	bit.16b	v11, v10, v31
	ldr	q27, [sp, #1536]                ; 16-byte Reload
	ldr	q1, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v27, v1, v0
	ldr	q23, [sp, #1936]                ; 16-byte Reload
	ldr	q1, [sp, #2032]                 ; 16-byte Reload
	bit.16b	v23, v1, v31
	ldr	q26, [sp, #1920]                ; 16-byte Reload
	ldr	q1, [sp, #2096]                 ; 16-byte Reload
	bit.16b	v26, v1, v0
	str	q21, [sp, #3104]                ; 16-byte Spill
	str	q18, [sp, #3088]                ; 16-byte Spill
LBB1_107:                               ; %direct.true739.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d1, x5
	ldr	q3, [sp, #2880]                 ; 16-byte Reload
	orr.16b	v7, v1, v3
	fmov	x6, d7
	add	x6, x8, x6
	ldp	q16, q7, [x6]
	and.16b	v16, v31, v16
	and.16b	v7, v0, v7
	add	x6, x5, #32
	ldr	q22, [sp, #2752]                ; 16-byte Reload
	fmul.4s	v7, v22, v7
	fmov	d10, x6
	orr.16b	v17, v10, v3
	fmov	x6, d17
	add	x6, x8, x6
	orr.16b	v17, v1, v30
	fmul.4s	v16, v18, v16
	fmov	x7, d17
	add	x7, x13, x7
	ldp	q18, q17, [x7]
	and.16b	v18, v31, v18
	fmul.4s	v18, v21, v18
	fadd.4s	v16, v16, v18
	ldp	q18, q21, [x6]
	and.16b	v21, v0, v21
	and.16b	v17, v0, v17
	ldr	q3, [sp, #2768]                 ; 16-byte Reload
	fmul.4s	v17, v3, v17
	fadd.4s	v7, v7, v17
	orr.16b	v17, v10, v30
	fmov	x6, d17
	add	x6, x13, x6
	ldr	q17, [x6, #16]
	fmul.4s	v21, v22, v21
	and.16b	v17, v0, v17
	fmul.4s	v17, v3, v17
	fadd.4s	v17, v21, v17
	ldr	q21, [x6]
	and.16b	v18, v31, v18
	ldr	q22, [sp, #3088]                ; 16-byte Reload
	fmul.4s	v18, v22, v18
	and.16b	v21, v31, v21
	ldr	q22, [sp, #3104]                ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v18, v18, v21
	add	x6, x1, x5
	ldr	q21, [x6, #16]
	and.16b	v21, v0, v21
	ldr	q22, [sp, #2784]                ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6]
	and.16b	v21, v31, v21
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	fmul.4s	v21, v3, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #32]
	and.16b	v21, v31, v21
	fmul.4s	v21, v3, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #48]
	and.16b	v21, v0, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #3072]
	and.16b	v21, v31, v21
	ldr	q22, [sp, #2832]                ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #3088]
	and.16b	v21, v0, v21
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	fmul.4s	v21, v3, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #3120]
	and.16b	v21, v0, v21
	fmul.4s	v21, v3, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #3104]
	and.16b	v21, v31, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #6160]
	and.16b	v21, v0, v21
	fmul.4s	v21, v4, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #6144]
	and.16b	v21, v31, v21
	ldr	q3, [sp, #2848]                 ; 16-byte Reload
	fmul.4s	v21, v3, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #6176]
	and.16b	v21, v31, v21
	fmul.4s	v21, v3, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #6192]
	and.16b	v21, v0, v21
	fmul.4s	v21, v4, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #9216]
	and.16b	v21, v31, v21
	fmul.4s	v21, v24, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #9232]
	and.16b	v21, v0, v21
	ldr	q3, [sp, #2864]                 ; 16-byte Reload
	fmul.4s	v21, v3, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #9264]
	and.16b	v21, v0, v21
	fmul.4s	v21, v3, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #9248]
	and.16b	v21, v31, v21
	fmul.4s	v21, v24, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #12304]
	and.16b	v21, v0, v21
	fmul.4s	v21, v25, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #12288]
	and.16b	v21, v31, v21
	fmul.4s	v21, v6, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #12320]
	and.16b	v21, v31, v21
	fmul.4s	v21, v6, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #12336]
	and.16b	v21, v0, v21
	fmul.4s	v21, v25, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #15360]
	and.16b	v21, v31, v21
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	fmul.4s	v21, v3, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #15376]
	and.16b	v21, v0, v21
	fmul.4s	v21, v5, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #15408]
	and.16b	v21, v0, v21
	fmul.4s	v21, v5, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #15392]
	and.16b	v21, v31, v21
	fmul.4s	v21, v3, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #18448]
	and.16b	v21, v0, v21
	ldr	q3, [sp, #2944]                 ; 16-byte Reload
	fmul.4s	v21, v3, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #18432]
	and.16b	v21, v31, v21
	ldr	q22, [sp, #2960]                ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #18464]
	and.16b	v21, v31, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #18480]
	and.16b	v21, v0, v21
	fmul.4s	v21, v3, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #21504]
	and.16b	v21, v31, v21
	ldr	q22, [sp, #2912]                ; 16-byte Reload
	fmul.4s	v21, v22, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #21520]
	and.16b	v21, v0, v21
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	fmul.4s	v21, v3, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #21552]
	and.16b	v21, v0, v21
	fmul.4s	v21, v3, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #21536]
	and.16b	v21, v31, v21
	fmul.4s	v21, v22, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #24592]
	and.16b	v21, v0, v21
	fmul.4s	v21, v9, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #24576]
	and.16b	v21, v31, v21
	fmul.4s	v21, v8, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #24608]
	and.16b	v21, v31, v21
	fmul.4s	v21, v8, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #24624]
	and.16b	v21, v0, v21
	fmul.4s	v21, v9, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #27648]
	and.16b	v21, v31, v21
	fmul.4s	v21, v13, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #27664]
	and.16b	v21, v0, v21
	fmul.4s	v21, v14, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #27696]
	and.16b	v21, v0, v21
	fmul.4s	v21, v14, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #27680]
	and.16b	v21, v31, v21
	fmul.4s	v21, v13, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #30736]
	and.16b	v21, v0, v21
	fmul.4s	v21, v12, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #30720]
	and.16b	v21, v31, v21
	fmul.4s	v21, v20, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #30752]
	and.16b	v21, v31, v21
	fmul.4s	v21, v20, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #30768]
	and.16b	v21, v0, v21
	fmul.4s	v21, v12, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #33792]
	and.16b	v21, v31, v21
	fmul.4s	v21, v29, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #33808]
	and.16b	v21, v0, v21
	fmul.4s	v21, v19, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #33840]
	and.16b	v21, v0, v21
	fmul.4s	v21, v19, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #33824]
	and.16b	v21, v31, v21
	fmul.4s	v21, v29, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #36880]
	and.16b	v21, v0, v21
	fmul.4s	v21, v28, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #36864]
	and.16b	v21, v31, v21
	fmul.4s	v21, v15, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #36896]
	and.16b	v21, v31, v21
	fmul.4s	v21, v15, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #36912]
	and.16b	v21, v0, v21
	fmul.4s	v21, v28, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #39936]
	and.16b	v21, v31, v21
	fmul.4s	v21, v11, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #39952]
	and.16b	v21, v0, v21
	fmul.4s	v21, v27, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #39984]
	and.16b	v21, v0, v21
	fmul.4s	v21, v27, v21
	fadd.4s	v17, v17, v21
	ldr	q21, [x6, #39968]
	and.16b	v21, v31, v21
	fmul.4s	v21, v11, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [x6, #43024]
	and.16b	v21, v0, v21
	fmul.4s	v21, v26, v21
	fadd.4s	v7, v7, v21
	ldr	q21, [x6, #43008]
	and.16b	v21, v31, v21
	fmul.4s	v21, v23, v21
	fadd.4s	v16, v16, v21
	ldr	q21, [x6, #43040]
	and.16b	v21, v31, v21
	fmul.4s	v21, v23, v21
	fadd.4s	v18, v18, v21
	ldr	q21, [sp, #3104]                ; 16-byte Reload
	ldr	q22, [sp, #2976]                ; 16-byte Reload
	orr.16b	v1, v1, v22
	fmov	x7, d1
	ldr	q1, [x6, #43056]
	and.16b	v1, v0, v1
	fmul.4s	v1, v26, v1
	fadd.4s	v1, v17, v1
	add	x6, x15, x7
	ldp	q3, q17, [x6]
	bif.16b	v16, v3, v31
	bif.16b	v7, v17, v0
	stp	q16, q7, [x6]
	orr.16b	v7, v10, v22
	fmov	x6, d7
	add	x6, x15, x6
	ldp	q7, q3, [x6]
	bif.16b	v1, v3, v0
	bit.16b	v7, v18, v31
	ldr	q18, [sp, #3088]                ; 16-byte Reload
	stp	q7, q1, [x6]
	add	x5, x5, #64
	cmp	x5, #3072
	b.ne	LBB1_107
; %bb.108:                              ; %direct.true958.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	str	q30, [sp, #1792]                ; 16-byte Spill
	str	q4, [sp, #2704]                 ; 16-byte Spill
	str	q25, [sp, #1872]                ; 16-byte Spill
	ldr	q4, [sp, #2928]                 ; 16-byte Reload
	ldr	q3, [sp, #2944]                 ; 16-byte Reload
	ldr	q22, [sp, #2960]                ; 16-byte Reload
	ldr	q10, [sp, #2896]                ; 16-byte Reload
	ldr	q30, [sp, #2912]                ; 16-byte Reload
	str	q8, [sp, #1888]                 ; 16-byte Spill
	str	q28, [sp, #1568]                ; 16-byte Spill
	str	q15, [sp, #1584]                ; 16-byte Spill
	str	q11, [sp, #1904]                ; 16-byte Spill
	str	q26, [sp, #1920]                ; 16-byte Spill
	str	q23, [sp, #1936]                ; 16-byte Spill
	mov	x5, #0                          ; =0x0
	ldr	q11, [sp, #480]                 ; 16-byte Reload
	ldr	q26, [sp, #400]                 ; 16-byte Reload
	ldr	q8, [sp, #2880]                 ; 16-byte Reload
	ldr	q28, [sp, #2976]                ; 16-byte Reload
LBB1_109:                               ; %direct.true958.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d1, x5
	orr.16b	v7, v1, v28
	fmov	x6, d7
	add	x6, x15, x6
	ldp	q7, q16, [x6]
	orr.16b	v1, v1, v8
	fmov	x6, d1
	add	x6, x11, x6
	ldp	q1, q17, [x6]
	bif.16b	v16, v17, v0
	bit.16b	v1, v7, v31
	stp	q1, q16, [x6]
	add	x5, x5, #32
	cmp	x5, #3072
	b.ne	LBB1_109
; %bb.110:                              ; %direct.true974.i.i.preheader
                                        ;   in Loop: Header=BB1_34 Depth=2
	mov	x5, x10
	mov	w6, #96                         ; =0x60
	ldr	q21, [sp, #1552]                ; 16-byte Reload
	ldr	q18, [sp, #448]                 ; 16-byte Reload
	ldr	q23, [sp, #2016]                ; 16-byte Reload
	str	q29, [sp, #1680]                ; 16-byte Spill
	str	q19, [sp, #1664]                ; 16-byte Spill
	str	q20, [sp, #1648]                ; 16-byte Spill
	str	q12, [sp, #1632]                ; 16-byte Spill
	str	q13, [sp, #1616]                ; 16-byte Spill
	str	q14, [sp, #1600]                ; 16-byte Spill
	ldr	q15, [sp, #1520]                ; 16-byte Reload
LBB1_111:                               ; %direct.true974.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_34 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q1, [x5, #5632]
	ldr	q7, [x5, #5648]
	ldr	q16, [x5, #2560]
	ldr	q17, [x5, #2576]
	bif.16b	v7, v17, v0
	bif.16b	v1, v16, v31
	str	q1, [x5, #2560]
	str	q7, [x5, #2576]
	add	x5, x5, #32
	subs	x6, x6, #1
	b.ne	LBB1_111
; %bb.112:                              ; %direct.false975.i.i
                                        ;   in Loop: Header=BB1_34 Depth=2
	ldr	q1, [sp, #2736]                 ; 16-byte Reload
	ldr	q7, [sp, #1408]                 ; 16-byte Reload
	bit.16b	v1, v7, v0
	str	q1, [sp, #2736]                 ; 16-byte Spill
	ldr	q1, [sp, #2720]                 ; 16-byte Reload
	ldr	q7, [sp, #1424]                 ; 16-byte Reload
	bit.16b	v1, v7, v31
	str	q1, [sp, #2720]                 ; 16-byte Spill
	movi.2d	v7, #0000000000000000
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	fadd.4s	v1, v1, v7
	ldr	q16, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #2192]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #2160]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #2128]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #2144]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #1392]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #2112]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #1488]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #1376]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #1152]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #1328]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #1312]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #1184]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #1168]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #1360]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #1344]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #1216]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #1200]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #1440]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #2048]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #1248]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #1232]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #1456]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #2064]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #1280]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #1264]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #1504]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #2080]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #1296]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #2032]                ; 16-byte Reload
	fadd.4s	v1, v16, v1
	ldr	q16, [sp, #2096]                ; 16-byte Reload
	fadd.4s	v7, v16, v7
	ldr	q16, [sp, #1120]                ; 16-byte Reload
	fmul.4s	v16, v15, v16
	ldr	q17, [sp, #1136]                ; 16-byte Reload
	fmul.4s	v17, v21, v17
	fadd.4s	v7, v17, v7
	fadd.4s	v1, v16, v1
	bit.16b	v15, v1, v31
	bit.16b	v21, v7, v0
	add	x0, x0, #1
	cmp	x0, #129
	ldr	q17, [sp, #464]                 ; 16-byte Reload
	mov.16b	v7, v30
	ldr	q30, [sp, #2704]                ; 16-byte Reload
	ldr	q20, [sp, #2272]                ; 16-byte Reload
	ldr	q12, [sp, #2256]                ; 16-byte Reload
	ldr	q13, [sp, #2240]                ; 16-byte Reload
	ldr	q14, [sp, #2224]                ; 16-byte Reload
	ldr	q19, [sp, #1472]                ; 16-byte Reload
	b.ne	LBB1_34
; %bb.113:                              ; %direct.schedule.83.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	ldp	q1, q3, [sp, #32]               ; 32-byte Folded Reload
	xtn.2s	v1, v1
	movi.2s	v5, #96
	umull.2d	v1, v1, v5
	ldp	q2, q4, [sp, #64]               ; 32-byte Folded Reload
	xtn.2s	v2, v2
	umull.2d	v2, v2, v5
	xtn.2s	v3, v3
	umull.2d	v3, v3, v5
	xtn.2s	v4, v4
	umull.2d	v4, v4, v5
	ldr	w21, [sp, #28]                  ; 4-byte Reload
	ldp	x25, x22, [sp, #8]              ; 16-byte Folded Reload
	ldr	w27, [sp, #108]                 ; 4-byte Reload
	ldr	q18, [sp, #144]                 ; 16-byte Reload
	ldr	x2, [sp, #184]                  ; 8-byte Reload
	ldr	x12, [sp, #96]                  ; 8-byte Reload
	b	LBB1_115
LBB1_114:                               ; %else413
                                        ;   in Loop: Header=BB1_115 Depth=2
	add	x9, x9, #1
	cmp	x9, #96
	b.eq	LBB1_2
LBB1_115:                               ; %direct.true993.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	uzp1.8h	v5, v31, v0
	and.16b	v5, v5, v18
	addv.8h	h5, v5
	fmov	w10, s5
	dup.2d	v5, x9
	add.2d	v6, v5, v1
	add	x11, x8, x9, lsl #5
	ldp	q16, q7, [x11]
	and.16b	v16, v31, v16
	fdiv.4s	v16, v16, v15
	shl.2d	v17, v6, #2
	dup.2d	v6, x12
	add.2d	v17, v6, v17
	tbnz	w10, #0, LBB1_123
; %bb.116:                              ; %else392
                                        ;   in Loop: Header=BB1_115 Depth=2
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_124
LBB1_117:                               ; %else395
                                        ;   in Loop: Header=BB1_115 Depth=2
	add.2d	v17, v5, v2
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbnz	w10, #2, LBB1_125
LBB1_118:                               ; %else398
                                        ;   in Loop: Header=BB1_115 Depth=2
	tbnz	w10, #3, LBB1_126
LBB1_119:                               ; %else401
                                        ;   in Loop: Header=BB1_115 Depth=2
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v21
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbnz	w10, #4, LBB1_127
LBB1_120:                               ; %else404
                                        ;   in Loop: Header=BB1_115 Depth=2
	tbnz	w10, #5, LBB1_128
LBB1_121:                               ; %else407
                                        ;   in Loop: Header=BB1_115 Depth=2
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbnz	w10, #6, LBB1_129
LBB1_122:                               ; %else410
                                        ;   in Loop: Header=BB1_115 Depth=2
	tbz	w10, #7, LBB1_114
	b	LBB1_130
LBB1_123:                               ; %cond.store
                                        ;   in Loop: Header=BB1_115 Depth=2
	fmov	x11, d17
	str	s16, [x11]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_117
LBB1_124:                               ; %cond.store393
                                        ;   in Loop: Header=BB1_115 Depth=2
	mov.d	x11, v17[1]
	st1.s	{ v16 }[1], [x11]
	add.2d	v17, v5, v2
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbz	w10, #2, LBB1_118
LBB1_125:                               ; %cond.store396
                                        ;   in Loop: Header=BB1_115 Depth=2
	fmov	x11, d17
	st1.s	{ v16 }[2], [x11]
	tbz	w10, #3, LBB1_119
LBB1_126:                               ; %cond.store399
                                        ;   in Loop: Header=BB1_115 Depth=2
	mov.d	x11, v17[1]
	st1.s	{ v16 }[3], [x11]
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v21
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbz	w10, #4, LBB1_120
LBB1_127:                               ; %cond.store402
                                        ;   in Loop: Header=BB1_115 Depth=2
	fmov	x11, d16
	str	s7, [x11]
	tbz	w10, #5, LBB1_121
LBB1_128:                               ; %cond.store405
                                        ;   in Loop: Header=BB1_115 Depth=2
	mov.d	x11, v16[1]
	st1.s	{ v7 }[1], [x11]
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbz	w10, #6, LBB1_122
LBB1_129:                               ; %cond.store408
                                        ;   in Loop: Header=BB1_115 Depth=2
	fmov	x11, d5
	st1.s	{ v7 }[2], [x11]
	tbz	w10, #7, LBB1_114
LBB1_130:                               ; %cond.store411
                                        ;   in Loop: Header=BB1_115 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v7 }[3], [x10]
	b	LBB1_114
LBB1_131:
	add	sp, sp, #3216
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB1_132:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
                                        ; -- End function
.subsections_via_symbols

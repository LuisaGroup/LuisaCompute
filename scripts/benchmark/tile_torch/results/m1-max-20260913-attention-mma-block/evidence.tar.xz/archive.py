"""Freeze capture source identity before any further isolated-source updates."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import tarfile
import time

OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/mike/CLionProjects/luisa')
SOURCE=Path('/tmp/luisa-next-integration.roZbN8/source')
BUILD=SOURCE.parent/'build'
ARCHIVE=ROOT/'scripts/benchmark/tile_torch/results/m1-max-20260913-attention-mma-block'

def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()

def save(p,obj):
    p.write_text(json.dumps(obj,indent=2)+'\n')

if __name__=='__main__':
    dst=ARCHIVE/'sources.tar.gz'
    if dst.exists():
        raise RuntimeError('source identity already frozen')
    paths=['include/luisa/tile','src/tile','include/luisa/xir','src/xir','src/backends/simd',
           'src/tests/common','src/tests/benchmark/benchmark_tile_xir.cpp','src/tests/unit/tile/bridge/test_xir_target_info.cpp','src/tests/unit/tile/bridge/test_xir_runtime.cpp','src/tests/unit/simd/test_llvm_schedule_codegen.cpp','src/backends/metal4/tile/metal_tile.cpp']
    hashes={}
    with tarfile.open(dst,'w:gz',compresslevel=6) as t:
        for relative in paths:
            p=SOURCE/relative
            t.add(p,arcname=relative)
            for f in (p.rglob('*') if p.is_dir() else [p]):
                if f.is_file():
                    hashes[str(f.relative_to(SOURCE))]=sha(f)
    binaries=[BUILD/'bin/benchmark_tile_xir',*sorted((BUILD/'bin').glob('*.dylib')),*sorted((BUILD/'bin').glob('*.so'))]
    info=dict(checkpoint='2026-09-13 attention MMA-output-block native-entry',frozen_unix=time.time(),
              platform=platform.platform(),main_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
              origin_next=subprocess.check_output(['git','rev-parse','origin/next'],cwd=ROOT,text=True).strip(),
              source_state='Isolated producer sources at 33f36e74b plus the generic MMA output-block candidate and regression tests. Upstream 19 commits and protected TIRx WIP excluded. Defaults unchanged; fixed requested realization, uncalibrated cost.',
              source_sha256=hashes,source_archive_sha256=sha(dst),
              binary_sha256={p.name:sha(p) for p in binaries},
              build_configuration_sha256=sha(BUILD/'CMakeCache.txt'),
              acceptance=dict(cpu_numerical=True,simd_native_replay=True,automatic_planner_win=False,new_torch_or_gpu_comparison=False),
              exclusions=['Full Runtime dependency binaries are fingerprinted, not all archived; actual timed ORC objects/dylibs/helper are retained.',
                          'Guard payloads are not saved; execution receipts and complete logical outputs are retained.',
                          'Pure SIMD capture only; Metal4 option forwarding compiled but not executed. Complete 4-CTest validation and syntax receipts retained.'])
    save(ARCHIVE/'provenance.json',info)
    print(dst,dst.stat().st_size)


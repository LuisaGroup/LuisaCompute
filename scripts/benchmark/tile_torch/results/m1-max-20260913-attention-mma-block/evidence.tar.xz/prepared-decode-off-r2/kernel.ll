; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2560
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 5632
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 8704
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49664
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 98816
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 99328
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 99840
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill31, align 64
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca i64, align 8
  store i64 0, ptr %.slot33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.slot39 = alloca i64, align 8
  store i64 0, ptr %.slot39, align 4
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %.spill44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca i64, align 8
  store i64 0, ptr %.slot48, align 4
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca i64, align 8
  store i64 0, ptr %.slot50, align 4
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca i64, align 8
  store i64 0, ptr %.slot52, align 4
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca i64, align 8
  store i64 0, ptr %.slot54, align 4
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca i64, align 8
  store i64 0, ptr %.slot58, align 4
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca i64, align 8
  store i64 0, ptr %.slot60, align 4
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca i64, align 8
  store i64 0, ptr %.slot62, align 4
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca i64, align 8
  store i64 0, ptr %.slot64, align 4
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.slot66 = alloca i64, align 8
  store i64 0, ptr %.slot66, align 4
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca i64, align 8
  store i64 0, ptr %.slot68, align 4
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca i64, align 8
  store i64 0, ptr %.slot70, align 4
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca i64, align 8
  store i64 0, ptr %.slot72, align 4
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca i64, align 8
  store i64 0, ptr %.slot74, align 4
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca i64, align 8
  store i64 0, ptr %.slot76, align 4
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.spill78 = alloca i64, align 8
  store i64 0, ptr %.spill78, align 4
  %.spill79 = alloca i1, align 1
  store i1 false, ptr %.spill79, align 1
  %.spill80 = alloca i1, align 1
  store i1 false, ptr %.spill80, align 1
  %.spill81 = alloca i1, align 1
  store i1 false, ptr %.spill81, align 1
  %.spill82 = alloca i1, align 1
  store i1 false, ptr %.spill82, align 1
  %.spill83 = alloca i1, align 1
  store i1 false, ptr %.spill83, align 1
  %.spill84 = alloca i1, align 1
  store i1 false, ptr %.spill84, align 1
  %.spill85 = alloca i1, align 1
  store i1 false, ptr %.spill85, align 1
  %.spill86 = alloca i1, align 1
  store i1 false, ptr %.spill86, align 1
  %.spill87 = alloca i1, align 1
  store i1 false, ptr %.spill87, align 1
  %.spill88 = alloca i1, align 1
  store i1 false, ptr %.spill88, align 1
  %.spill89 = alloca i1, align 1
  store i1 false, ptr %.spill89, align 1
  %.spill90 = alloca i1, align 1
  store i1 false, ptr %.spill90, align 1
  %.spill91 = alloca i1, align 1
  store i1 false, ptr %.spill91, align 1
  %.spill92 = alloca i1, align 1
  store i1 false, ptr %.spill92, align 1
  %.spill93 = alloca i1, align 1
  store i1 false, ptr %.spill93, align 1
  %.spill94 = alloca i1, align 1
  store i1 false, ptr %.spill94, align 1
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %.spill101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %.spill103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill103, align 32
  %.spill104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill104, align 32
  %.spill105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill105, align 32
  %.spill106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill106, align 32
  %.spill107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill107, align 32
  %.spill108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill108, align 32
  %.spill109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill109, align 32
  %.spill110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill110, align 32
  %tile_snapshot.spill111 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill111, align 64
  %.slot112 = alloca i64, align 8
  store i64 0, ptr %.slot112, align 4
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.spill114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %.spill116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill116, align 32
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.spill118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill118, align 32
  %.spill119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %.spill121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill121, align 32
  %.spill122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill122, align 32
  %.spill123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill123, align 32
  %.spill124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill124, align 32
  %.spill125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %.spill131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill131, align 32
  %tile_snapshot.spill132 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill132, align 64
  %.spill133 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill133, align 32
  %.slot134 = alloca i64, align 8
  store i64 0, ptr %.slot134, align 4
  %.slot135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot135, align 32
  %.spill136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill136, align 32
  %tile_snapshot.spill137 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill137, align 64
  %.slot138 = alloca i64, align 8
  store i64 0, ptr %.slot138, align 4
  %.slot139 = alloca i64, align 8
  store i64 0, ptr %.slot139, align 4
  %.slot140 = alloca i64, align 8
  store i64 0, ptr %.slot140, align 4
  %.slot141 = alloca i64, align 8
  store i64 0, ptr %.slot141, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert142 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat143 = shufflevector <8 x i32> %.splatinsert142, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat143, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert144 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat145 = shufflevector <8 x i32> %.splatinsert144, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat145, %61
  %64 = mul i32 %52, 1
  %.splatinsert146 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat147 = shufflevector <8 x i32> %.splatinsert146, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat147, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert148 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat149 = shufflevector <8 x i32> %.splatinsert148, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat149, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert150 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat151 = shufflevector <8 x i32> %.splatinsert150, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat151
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %94 = icmp slt i64 %.state, 80
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load i64, ptr %.spill29, align 4
  %95 = add i64 %.spill.load, 0
  %.spill.load152 = load <8 x i64>, ptr %.spill, align 64
  %96 = add <8 x i64> %.spill.load152, zeroinitializer
  %97 = mul i64 %95, 8
  %.splatinsert153 = insertelement <8 x i64> poison, i64 %97, i64 0
  %.splat154 = shufflevector <8 x i64> %.splatinsert153, <8 x i64> poison, <8 x i32> zeroinitializer
  %98 = add <8 x i64> %.splat154, %96
  %.spill.load155 = load i64, ptr %.spill29, align 4
  %99 = add i64 %.spill.load155, 0
  %100 = mul <8 x i64> %98, splat (i64 1)
  %.splatinsert156 = insertelement <8 x i64> poison, i64 %99, i64 0
  %.splat157 = shufflevector <8 x i64> %.splatinsert156, <8 x i64> poison, <8 x i32> zeroinitializer
  %101 = add <8 x i64> %100, %.splat157
  %.state158 = load i64, ptr %.slot, align 4
  %102 = add i64 0, %.state158
  %103 = mul <8 x i64> %101, splat (i64 80)
  %.splatinsert159 = insertelement <8 x i64> poison, i64 %102, i64 0
  %.splat160 = shufflevector <8 x i64> %.splatinsert159, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = add <8 x i64> %103, %.splat160
  %105 = extractvalue { ptr, i64 } %29, 0
  %106 = mul <8 x i64> %104, splat (i64 4)
  %107 = getelementptr i8, ptr %105, <8 x i64> %106
  %108 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %107, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state161 = load i64, ptr %.slot, align 4
  %.splatinsert162 = insertelement <8 x i64> poison, i64 %.state161, i64 0
  %.splat163 = shufflevector <8 x i64> %.splatinsert162, <8 x i64> poison, <8 x i32> zeroinitializer
  %111 = mul <8 x i64> %.splat163, splat (i64 32)
  %112 = add <8 x i64> %110, %111
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %114, 1
  %117 = extractelement <8 x ptr> %115, i32 0
  %118 = extractelement <8 x i64> %116, i32 0
  %119 = sub i64 %118, 0
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %121 = select i1 %120, i64 %119, i64 0
  %private.contiguous.address = getelementptr i8, ptr %117, i64 %121
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %122 = select <8 x i1> %71, <8 x float> %108, <8 x float> %private.contiguous.preserve
  store <8 x float> %122, ptr %private.contiguous.address, align 4
  %.state164 = load i64, ptr %.slot, align 4
  %123 = add i64 %.state164, 1
  store i64 %123, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill31, align 64
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %71, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %71, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %tile_snapshot.spill32, align 64
  store i64 0, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state165 = load i64, ptr %.slot33, align 4
  %142 = icmp slt i64 %.state165, 96
  br i1 %142, label %direct.true166, label %direct.false167

direct.schedule.5:                                ; preds = %direct.true166
  %tile_snapshot.spill.load168 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load168, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load168, 1
  %.state169 = load i64, ptr %.slot33, align 4
  %.splatinsert170 = insertelement <8 x i64> poison, i64 %.state169, i64 0
  %.splat171 = shufflevector <8 x i64> %.splatinsert170, <8 x i64> poison, <8 x i32> zeroinitializer
  %145 = mul <8 x i64> %.splat171, splat (i64 32)
  %146 = add <8 x i64> %144, %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %151 = extractelement <8 x ptr> %149, i32 0
  %152 = extractelement <8 x i64> %150, i32 0
  %153 = sub i64 %152, 0
  %154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %155 = select i1 %154, i64 %153, i64 0
  %private.contiguous.address172 = getelementptr i8, ptr %151, i64 %155
  %private.contiguous.preserve173 = load <8 x float>, ptr %private.contiguous.address172, align 4
  %156 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve173
  store <8 x float> %156, ptr %private.contiguous.address172, align 4
  %.state174 = load i64, ptr %.slot33, align 4
  %157 = add i64 %.state174, 1
  store i64 %157, ptr %.slot33, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false167
  store i64 0, ptr %.slot34, align 4
  %158 = load <8 x float>, ptr %.slot35, align 32
  %159 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %158
  store <8 x float> %159, ptr %.slot35, align 32
  %160 = load <8 x float>, ptr %.slot36, align 32
  %161 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %160
  store <8 x float> %161, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.81, %direct.schedule.6
  %.state175 = load i64, ptr %.slot34, align 4
  %162 = icmp slt i64 %.state175, 129
  br i1 %162, label %direct.true176, label %direct.false177

direct.schedule.8:                                ; preds = %direct.true176
  %.state178 = load i64, ptr %.slot34, align 4
  %163 = sdiv i64 %.state178, 1
  %164 = mul i64 %163, 16
  store i64 %164, ptr %.spill37, align 4
  %165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %168 = select <8 x i1> %71, <8 x ptr> %166, <8 x ptr> %167
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %171 = select <8 x i1> %71, <8 x i64> %169, <8 x i64> %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %168, 0
  %173 = insertvalue { <8 x ptr>, <8 x i64> } %172, <8 x i64> %171, 1
  store { <8 x ptr>, <8 x i64> } %173, ptr %tile_snapshot.spill38, align 64
  store i64 0, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state179 = load i64, ptr %.slot39, align 4
  %174 = icmp slt i64 %.state179, 1280
  br i1 %174, label %direct.true180, label %direct.false181

direct.schedule.10:                               ; preds = %direct.true180
  %.state182 = load i64, ptr %.slot39, align 4
  %175 = srem i64 %.state182, 80
  %.state183 = load i64, ptr %.slot39, align 4
  %176 = sdiv i64 %.state183, 80
  %.spill.load184 = load i64, ptr %.spill29, align 4
  %177 = add i64 %.spill.load184, 0
  %.spill.load185 = load <8 x i64>, ptr %.spill30, align 64
  %178 = add <8 x i64> %.spill.load185, zeroinitializer
  %179 = mul i64 %177, 2
  %.splatinsert186 = insertelement <8 x i64> poison, i64 %179, i64 0
  %.splat187 = shufflevector <8 x i64> %.splatinsert186, <8 x i64> poison, <8 x i32> zeroinitializer
  %180 = add <8 x i64> %.splat187, %178
  %.spill.load188 = load i64, ptr %.spill37, align 4
  %181 = add i64 %.spill.load188, %176
  %182 = mul <8 x i64> %180, splat (i64 2053)
  %.splatinsert189 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat190 = shufflevector <8 x i64> %.splatinsert189, <8 x i64> poison, <8 x i32> zeroinitializer
  %183 = add <8 x i64> %182, %.splat190
  %184 = icmp sge i64 %181, 0
  %185 = and i1 true, %184
  %186 = icmp slt i64 %181, 2053
  %187 = and i1 %185, %186
  %188 = add i64 0, %175
  %189 = mul <8 x i64> %183, splat (i64 80)
  %.splatinsert191 = insertelement <8 x i64> poison, i64 %188, i64 0
  %.splat192 = shufflevector <8 x i64> %.splatinsert191, <8 x i64> poison, <8 x i32> zeroinitializer
  %190 = add <8 x i64> %189, %.splat192
  %191 = load <8 x i64>, ptr %.spill40, align 64
  %192 = select <8 x i1> %71, <8 x i64> %190, <8 x i64> %191
  store <8 x i64> %192, ptr %.spill40, align 64
  br i1 %187, label %direct.true193, label %direct.false194

direct.schedule.11:                               ; preds = %direct.true193
  %.spill.load195 = load <8 x i64>, ptr %.spill40, align 64
  %193 = extractvalue { ptr, i64 } %35, 0
  %194 = mul <8 x i64> %.spill.load195, splat (i64 4)
  %195 = getelementptr i8, ptr %193, <8 x i64> %194
  %196 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %195, <8 x i1> %71, <8 x float> zeroinitializer)
  %197 = load <8 x float>, ptr %.slot41, align 32
  %198 = select <8 x i1> %71, <8 x float> %196, <8 x float> %197
  store <8 x float> %198, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.11, %direct.false194
  %tile_snapshot.spill.load196 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load196, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load196, 1
  %.state197 = load i64, ptr %.slot39, align 4
  %.splatinsert198 = insertelement <8 x i64> poison, i64 %.state197, i64 0
  %.splat199 = shufflevector <8 x i64> %.splatinsert198, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = mul <8 x i64> %.splat199, splat (i64 32)
  %202 = add <8 x i64> %200, %201
  %203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %199, 0
  %204 = insertvalue { <8 x ptr>, <8 x i64> } %203, <8 x i64> %202, 1
  %.state200 = load <8 x float>, ptr %.slot41, align 32
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %204, 1
  %207 = extractelement <8 x ptr> %205, i32 0
  %208 = extractelement <8 x i64> %206, i32 0
  %209 = sub i64 %208, 0
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %211 = select i1 %210, i64 %209, i64 0
  %private.contiguous.address201 = getelementptr i8, ptr %207, i64 %211
  %private.contiguous.preserve202 = load <8 x float>, ptr %private.contiguous.address201, align 4
  %212 = select <8 x i1> %71, <8 x float> %.state200, <8 x float> %private.contiguous.preserve202
  store <8 x float> %212, ptr %private.contiguous.address201, align 4
  %.state203 = load i64, ptr %.slot39, align 4
  %213 = add i64 %.state203, 1
  store i64 %213, ptr %.slot39, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false181
  %214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 0
  %217 = select <8 x i1> %71, <8 x ptr> %215, <8 x ptr> %216
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %220 = select <8 x i1> %71, <8 x i64> %218, <8 x i64> %219
  %221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %222 = insertvalue { <8 x ptr>, <8 x i64> } %221, <8 x i64> %220, 1
  store { <8 x ptr>, <8 x i64> } %222, ptr %tile_snapshot.spill42, align 64
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state204 = load i64, ptr %.slot43, align 4
  %223 = icmp slt i64 %.state204, 1536
  br i1 %223, label %direct.true205, label %direct.false206

direct.schedule.15:                               ; preds = %direct.true205
  %.state207 = load i64, ptr %.slot43, align 4
  %224 = srem i64 %.state207, 96
  %.state208 = load i64, ptr %.slot43, align 4
  %225 = sdiv i64 %.state208, 96
  %.spill.load209 = load i64, ptr %.spill29, align 4
  %226 = add i64 %.spill.load209, 0
  %.spill.load210 = load <8 x i64>, ptr %.spill30, align 64
  %227 = add <8 x i64> %.spill.load210, zeroinitializer
  %228 = mul i64 %226, 2
  %.splatinsert211 = insertelement <8 x i64> poison, i64 %228, i64 0
  %.splat212 = shufflevector <8 x i64> %.splatinsert211, <8 x i64> poison, <8 x i32> zeroinitializer
  %229 = add <8 x i64> %.splat212, %227
  %.spill.load213 = load i64, ptr %.spill37, align 4
  %230 = add i64 %.spill.load213, %225
  %231 = mul <8 x i64> %229, splat (i64 2053)
  %.splatinsert214 = insertelement <8 x i64> poison, i64 %230, i64 0
  %.splat215 = shufflevector <8 x i64> %.splatinsert214, <8 x i64> poison, <8 x i32> zeroinitializer
  %232 = add <8 x i64> %231, %.splat215
  %233 = icmp sge i64 %230, 0
  %234 = and i1 true, %233
  %235 = icmp slt i64 %230, 2053
  %236 = and i1 %234, %235
  %237 = add i64 0, %224
  %238 = mul <8 x i64> %232, splat (i64 96)
  %.splatinsert216 = insertelement <8 x i64> poison, i64 %237, i64 0
  %.splat217 = shufflevector <8 x i64> %.splatinsert216, <8 x i64> poison, <8 x i32> zeroinitializer
  %239 = add <8 x i64> %238, %.splat217
  %240 = load <8 x i64>, ptr %.spill44, align 64
  %241 = select <8 x i1> %71, <8 x i64> %239, <8 x i64> %240
  store <8 x i64> %241, ptr %.spill44, align 64
  br i1 %236, label %direct.true218, label %direct.false219

direct.schedule.16:                               ; preds = %direct.true218
  %.spill.load220 = load <8 x i64>, ptr %.spill44, align 64
  %242 = extractvalue { ptr, i64 } %41, 0
  %243 = mul <8 x i64> %.spill.load220, splat (i64 4)
  %244 = getelementptr i8, ptr %242, <8 x i64> %243
  %245 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %244, <8 x i1> %71, <8 x float> zeroinitializer)
  %246 = load <8 x float>, ptr %.slot45, align 32
  %247 = select <8 x i1> %71, <8 x float> %245, <8 x float> %246
  store <8 x float> %247, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.16, %direct.false219
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %.state222 = load i64, ptr %.slot43, align 4
  %.splatinsert223 = insertelement <8 x i64> poison, i64 %.state222, i64 0
  %.splat224 = shufflevector <8 x i64> %.splatinsert223, <8 x i64> poison, <8 x i32> zeroinitializer
  %250 = mul <8 x i64> %.splat224, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %.state225 = load <8 x float>, ptr %.slot45, align 32
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address226 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.preserve227 = load <8 x float>, ptr %private.contiguous.address226, align 4
  %261 = select <8 x i1> %71, <8 x float> %.state225, <8 x float> %private.contiguous.preserve227
  store <8 x float> %261, ptr %private.contiguous.address226, align 4
  %.state228 = load i64, ptr %.slot43, align 4
  %262 = add i64 %.state228, 1
  store i64 %262, ptr %.slot43, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false206
  store i64 0, ptr %.slot46, align 4
  %263 = load <8 x float>, ptr %.slot47, align 32
  %264 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %263
  store <8 x float> %264, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state229 = load i64, ptr %.slot46, align 4
  %265 = icmp slt i64 %.state229, 80
  br i1 %265, label %direct.true230, label %direct.false231

direct.schedule.20:                               ; preds = %direct.true230
  %.state232 = load i64, ptr %.slot46, align 4
  %266 = add i64 0, %.state232
  %tile_snapshot.spill.load233 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load233, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load233, 1
  %.splatinsert234 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat235 = shufflevector <8 x i64> %.splatinsert234, <8 x i64> poison, <8 x i32> zeroinitializer
  %269 = mul <8 x i64> %.splat235, splat (i64 32)
  %270 = add <8 x i64> %268, %269
  %271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %267, 0
  %272 = insertvalue { <8 x ptr>, <8 x i64> } %271, <8 x i64> %270, 1
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %272, 1
  %275 = extractelement <8 x ptr> %273, i32 0
  %276 = extractelement <8 x i64> %274, i32 0
  %277 = sub i64 %276, 0
  %278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %279 = select i1 %278, i64 %277, i64 0
  %private.contiguous.address236 = getelementptr i8, ptr %275, i64 %279
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address236, align 4
  %280 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load237 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 1
  %.splatinsert238 = insertelement <8 x i64> poison, i64 %266, i64 0
  %.splat239 = shufflevector <8 x i64> %.splatinsert238, <8 x i64> poison, <8 x i32> zeroinitializer
  %283 = mul <8 x i64> %.splat239, splat (i64 32)
  %284 = add <8 x i64> %282, %283
  %285 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %281, 0
  %286 = insertvalue { <8 x ptr>, <8 x i64> } %285, <8 x i64> %284, 1
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %286, 1
  %289 = extractelement <8 x ptr> %287, i32 0
  %290 = extractelement <8 x i64> %288, i32 0
  %291 = sub i64 %290, 0
  %292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %293 = select i1 %292, i64 %291, i64 0
  %private.contiguous.address240 = getelementptr i8, ptr %289, i64 %293
  %private.contiguous.load241 = load <8 x float>, ptr %private.contiguous.address240, align 4
  %294 = select <8 x i1> %71, <8 x float> %private.contiguous.load241, <8 x float> zeroinitializer
  %295 = fmul <8 x float> %280, %294
  %.state242 = load <8 x float>, ptr %.slot47, align 32
  %296 = fadd <8 x float> %.state242, %295
  %.state243 = load i64, ptr %.slot46, align 4
  %297 = add i64 %.state243, 1
  store i64 %297, ptr %.slot46, align 4
  %298 = load <8 x float>, ptr %.slot47, align 32
  %299 = select <8 x i1> %71, <8 x float> %296, <8 x float> %298
  store <8 x float> %299, ptr %.slot47, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false231
  store i64 0, ptr %.slot48, align 4
  %300 = load <8 x float>, ptr %.slot49, align 32
  %301 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %300
  store <8 x float> %301, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state244 = load i64, ptr %.slot48, align 4
  %302 = icmp slt i64 %.state244, 80
  br i1 %302, label %direct.true245, label %direct.false246

direct.schedule.23:                               ; preds = %direct.true245
  %.state247 = load i64, ptr %.slot48, align 4
  %303 = add i64 0, %.state247
  %tile_snapshot.spill.load248 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %.splatinsert249 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat250 = shufflevector <8 x i64> %.splatinsert249, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat250, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address251 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load252 = load <8 x float>, ptr %private.contiguous.address251, align 4
  %317 = select <8 x i1> %71, <8 x float> %private.contiguous.load252, <8 x float> zeroinitializer
  %.state253 = load i64, ptr %.slot48, align 4
  %318 = add i64 80, %.state253
  %tile_snapshot.spill.load254 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %.splatinsert255 = insertelement <8 x i64> poison, i64 %318, i64 0
  %.splat256 = shufflevector <8 x i64> %.splatinsert255, <8 x i64> poison, <8 x i32> zeroinitializer
  %321 = mul <8 x i64> %.splat256, splat (i64 32)
  %322 = add <8 x i64> %320, %321
  %323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %319, 0
  %324 = insertvalue { <8 x ptr>, <8 x i64> } %323, <8 x i64> %322, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %324, 1
  %327 = extractelement <8 x ptr> %325, i32 0
  %328 = extractelement <8 x i64> %326, i32 0
  %329 = sub i64 %328, 0
  %330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %331 = select i1 %330, i64 %329, i64 0
  %private.contiguous.address257 = getelementptr i8, ptr %327, i64 %331
  %private.contiguous.load258 = load <8 x float>, ptr %private.contiguous.address257, align 4
  %332 = select <8 x i1> %71, <8 x float> %private.contiguous.load258, <8 x float> zeroinitializer
  %333 = fmul <8 x float> %317, %332
  %.state259 = load <8 x float>, ptr %.slot49, align 32
  %334 = fadd <8 x float> %.state259, %333
  %.state260 = load i64, ptr %.slot48, align 4
  %335 = add i64 %.state260, 1
  store i64 %335, ptr %.slot48, align 4
  %336 = load <8 x float>, ptr %.slot49, align 32
  %337 = select <8 x i1> %71, <8 x float> %334, <8 x float> %336
  store <8 x float> %337, ptr %.slot49, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false246
  store i64 0, ptr %.slot50, align 4
  %338 = load <8 x float>, ptr %.slot51, align 32
  %339 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %338
  store <8 x float> %339, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state261 = load i64, ptr %.slot50, align 4
  %340 = icmp slt i64 %.state261, 80
  br i1 %340, label %direct.true262, label %direct.false263

direct.schedule.26:                               ; preds = %direct.true262
  %.state264 = load i64, ptr %.slot50, align 4
  %341 = add i64 0, %.state264
  %tile_snapshot.spill.load265 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 0
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 1
  %.splatinsert266 = insertelement <8 x i64> poison, i64 %341, i64 0
  %.splat267 = shufflevector <8 x i64> %.splatinsert266, <8 x i64> poison, <8 x i32> zeroinitializer
  %344 = mul <8 x i64> %.splat267, splat (i64 32)
  %345 = add <8 x i64> %343, %344
  %346 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %342, 0
  %347 = insertvalue { <8 x ptr>, <8 x i64> } %346, <8 x i64> %345, 1
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %347, 1
  %350 = extractelement <8 x ptr> %348, i32 0
  %351 = extractelement <8 x i64> %349, i32 0
  %352 = sub i64 %351, 0
  %353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %354 = select i1 %353, i64 %352, i64 0
  %private.contiguous.address268 = getelementptr i8, ptr %350, i64 %354
  %private.contiguous.load269 = load <8 x float>, ptr %private.contiguous.address268, align 4
  %355 = select <8 x i1> %71, <8 x float> %private.contiguous.load269, <8 x float> zeroinitializer
  %.state270 = load i64, ptr %.slot50, align 4
  %356 = add i64 160, %.state270
  %tile_snapshot.spill.load271 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %.splatinsert272 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat273 = shufflevector <8 x i64> %.splatinsert272, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat273, splat (i64 32)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = extractelement <8 x ptr> %363, i32 0
  %366 = extractelement <8 x i64> %364, i32 0
  %367 = sub i64 %366, 0
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %369 = select i1 %368, i64 %367, i64 0
  %private.contiguous.address274 = getelementptr i8, ptr %365, i64 %369
  %private.contiguous.load275 = load <8 x float>, ptr %private.contiguous.address274, align 4
  %370 = select <8 x i1> %71, <8 x float> %private.contiguous.load275, <8 x float> zeroinitializer
  %371 = fmul <8 x float> %355, %370
  %.state276 = load <8 x float>, ptr %.slot51, align 32
  %372 = fadd <8 x float> %.state276, %371
  %.state277 = load i64, ptr %.slot50, align 4
  %373 = add i64 %.state277, 1
  store i64 %373, ptr %.slot50, align 4
  %374 = load <8 x float>, ptr %.slot51, align 32
  %375 = select <8 x i1> %71, <8 x float> %372, <8 x float> %374
  store <8 x float> %375, ptr %.slot51, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false263
  store i64 0, ptr %.slot52, align 4
  %376 = load <8 x float>, ptr %.slot53, align 32
  %377 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %376
  store <8 x float> %377, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state278 = load i64, ptr %.slot52, align 4
  %378 = icmp slt i64 %.state278, 80
  br i1 %378, label %direct.true279, label %direct.false280

direct.schedule.29:                               ; preds = %direct.true279
  %.state281 = load i64, ptr %.slot52, align 4
  %379 = add i64 0, %.state281
  %tile_snapshot.spill.load282 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load282, 0
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load282, 1
  %.splatinsert283 = insertelement <8 x i64> poison, i64 %379, i64 0
  %.splat284 = shufflevector <8 x i64> %.splatinsert283, <8 x i64> poison, <8 x i32> zeroinitializer
  %382 = mul <8 x i64> %.splat284, splat (i64 32)
  %383 = add <8 x i64> %381, %382
  %384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %380, 0
  %385 = insertvalue { <8 x ptr>, <8 x i64> } %384, <8 x i64> %383, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %385, 1
  %388 = extractelement <8 x ptr> %386, i32 0
  %389 = extractelement <8 x i64> %387, i32 0
  %390 = sub i64 %389, 0
  %391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %392 = select i1 %391, i64 %390, i64 0
  %private.contiguous.address285 = getelementptr i8, ptr %388, i64 %392
  %private.contiguous.load286 = load <8 x float>, ptr %private.contiguous.address285, align 4
  %393 = select <8 x i1> %71, <8 x float> %private.contiguous.load286, <8 x float> zeroinitializer
  %.state287 = load i64, ptr %.slot52, align 4
  %394 = add i64 240, %.state287
  %tile_snapshot.spill.load288 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 0
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 1
  %.splatinsert289 = insertelement <8 x i64> poison, i64 %394, i64 0
  %.splat290 = shufflevector <8 x i64> %.splatinsert289, <8 x i64> poison, <8 x i32> zeroinitializer
  %397 = mul <8 x i64> %.splat290, splat (i64 32)
  %398 = add <8 x i64> %396, %397
  %399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %395, 0
  %400 = insertvalue { <8 x ptr>, <8 x i64> } %399, <8 x i64> %398, 1
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %400, 1
  %403 = extractelement <8 x ptr> %401, i32 0
  %404 = extractelement <8 x i64> %402, i32 0
  %405 = sub i64 %404, 0
  %406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %407 = select i1 %406, i64 %405, i64 0
  %private.contiguous.address291 = getelementptr i8, ptr %403, i64 %407
  %private.contiguous.load292 = load <8 x float>, ptr %private.contiguous.address291, align 4
  %408 = select <8 x i1> %71, <8 x float> %private.contiguous.load292, <8 x float> zeroinitializer
  %409 = fmul <8 x float> %393, %408
  %.state293 = load <8 x float>, ptr %.slot53, align 32
  %410 = fadd <8 x float> %.state293, %409
  %.state294 = load i64, ptr %.slot52, align 4
  %411 = add i64 %.state294, 1
  store i64 %411, ptr %.slot52, align 4
  %412 = load <8 x float>, ptr %.slot53, align 32
  %413 = select <8 x i1> %71, <8 x float> %410, <8 x float> %412
  store <8 x float> %413, ptr %.slot53, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false280
  store i64 0, ptr %.slot54, align 4
  %414 = load <8 x float>, ptr %.slot55, align 32
  %415 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %414
  store <8 x float> %415, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state295 = load i64, ptr %.slot54, align 4
  %416 = icmp slt i64 %.state295, 80
  br i1 %416, label %direct.true296, label %direct.false297

direct.schedule.32:                               ; preds = %direct.true296
  %.state298 = load i64, ptr %.slot54, align 4
  %417 = add i64 0, %.state298
  %tile_snapshot.spill.load299 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load299, 0
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load299, 1
  %.splatinsert300 = insertelement <8 x i64> poison, i64 %417, i64 0
  %.splat301 = shufflevector <8 x i64> %.splatinsert300, <8 x i64> poison, <8 x i32> zeroinitializer
  %420 = mul <8 x i64> %.splat301, splat (i64 32)
  %421 = add <8 x i64> %419, %420
  %422 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %418, 0
  %423 = insertvalue { <8 x ptr>, <8 x i64> } %422, <8 x i64> %421, 1
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %423, 1
  %426 = extractelement <8 x ptr> %424, i32 0
  %427 = extractelement <8 x i64> %425, i32 0
  %428 = sub i64 %427, 0
  %429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %430 = select i1 %429, i64 %428, i64 0
  %private.contiguous.address302 = getelementptr i8, ptr %426, i64 %430
  %private.contiguous.load303 = load <8 x float>, ptr %private.contiguous.address302, align 4
  %431 = select <8 x i1> %71, <8 x float> %private.contiguous.load303, <8 x float> zeroinitializer
  %.state304 = load i64, ptr %.slot54, align 4
  %432 = add i64 320, %.state304
  %tile_snapshot.spill.load305 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load305, 0
  %434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load305, 1
  %.splatinsert306 = insertelement <8 x i64> poison, i64 %432, i64 0
  %.splat307 = shufflevector <8 x i64> %.splatinsert306, <8 x i64> poison, <8 x i32> zeroinitializer
  %435 = mul <8 x i64> %.splat307, splat (i64 32)
  %436 = add <8 x i64> %434, %435
  %437 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %433, 0
  %438 = insertvalue { <8 x ptr>, <8 x i64> } %437, <8 x i64> %436, 1
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %438, 1
  %441 = extractelement <8 x ptr> %439, i32 0
  %442 = extractelement <8 x i64> %440, i32 0
  %443 = sub i64 %442, 0
  %444 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %445 = select i1 %444, i64 %443, i64 0
  %private.contiguous.address308 = getelementptr i8, ptr %441, i64 %445
  %private.contiguous.load309 = load <8 x float>, ptr %private.contiguous.address308, align 4
  %446 = select <8 x i1> %71, <8 x float> %private.contiguous.load309, <8 x float> zeroinitializer
  %447 = fmul <8 x float> %431, %446
  %.state310 = load <8 x float>, ptr %.slot55, align 32
  %448 = fadd <8 x float> %.state310, %447
  %.state311 = load i64, ptr %.slot54, align 4
  %449 = add i64 %.state311, 1
  store i64 %449, ptr %.slot54, align 4
  %450 = load <8 x float>, ptr %.slot55, align 32
  %451 = select <8 x i1> %71, <8 x float> %448, <8 x float> %450
  store <8 x float> %451, ptr %.slot55, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false297
  store i64 0, ptr %.slot56, align 4
  %452 = load <8 x float>, ptr %.slot57, align 32
  %453 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %452
  store <8 x float> %453, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state312 = load i64, ptr %.slot56, align 4
  %454 = icmp slt i64 %.state312, 80
  br i1 %454, label %direct.true313, label %direct.false314

direct.schedule.35:                               ; preds = %direct.true313
  %.state315 = load i64, ptr %.slot56, align 4
  %455 = add i64 0, %.state315
  %tile_snapshot.spill.load316 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %456 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load316, 0
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load316, 1
  %.splatinsert317 = insertelement <8 x i64> poison, i64 %455, i64 0
  %.splat318 = shufflevector <8 x i64> %.splatinsert317, <8 x i64> poison, <8 x i32> zeroinitializer
  %458 = mul <8 x i64> %.splat318, splat (i64 32)
  %459 = add <8 x i64> %457, %458
  %460 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %456, 0
  %461 = insertvalue { <8 x ptr>, <8 x i64> } %460, <8 x i64> %459, 1
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %461, 1
  %464 = extractelement <8 x ptr> %462, i32 0
  %465 = extractelement <8 x i64> %463, i32 0
  %466 = sub i64 %465, 0
  %467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %468 = select i1 %467, i64 %466, i64 0
  %private.contiguous.address319 = getelementptr i8, ptr %464, i64 %468
  %private.contiguous.load320 = load <8 x float>, ptr %private.contiguous.address319, align 4
  %469 = select <8 x i1> %71, <8 x float> %private.contiguous.load320, <8 x float> zeroinitializer
  %.state321 = load i64, ptr %.slot56, align 4
  %470 = add i64 400, %.state321
  %tile_snapshot.spill.load322 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load322, 0
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load322, 1
  %.splatinsert323 = insertelement <8 x i64> poison, i64 %470, i64 0
  %.splat324 = shufflevector <8 x i64> %.splatinsert323, <8 x i64> poison, <8 x i32> zeroinitializer
  %473 = mul <8 x i64> %.splat324, splat (i64 32)
  %474 = add <8 x i64> %472, %473
  %475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %471, 0
  %476 = insertvalue { <8 x ptr>, <8 x i64> } %475, <8 x i64> %474, 1
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %476, 1
  %479 = extractelement <8 x ptr> %477, i32 0
  %480 = extractelement <8 x i64> %478, i32 0
  %481 = sub i64 %480, 0
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %483 = select i1 %482, i64 %481, i64 0
  %private.contiguous.address325 = getelementptr i8, ptr %479, i64 %483
  %private.contiguous.load326 = load <8 x float>, ptr %private.contiguous.address325, align 4
  %484 = select <8 x i1> %71, <8 x float> %private.contiguous.load326, <8 x float> zeroinitializer
  %485 = fmul <8 x float> %469, %484
  %.state327 = load <8 x float>, ptr %.slot57, align 32
  %486 = fadd <8 x float> %.state327, %485
  %.state328 = load i64, ptr %.slot56, align 4
  %487 = add i64 %.state328, 1
  store i64 %487, ptr %.slot56, align 4
  %488 = load <8 x float>, ptr %.slot57, align 32
  %489 = select <8 x i1> %71, <8 x float> %486, <8 x float> %488
  store <8 x float> %489, ptr %.slot57, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false314
  store i64 0, ptr %.slot58, align 4
  %490 = load <8 x float>, ptr %.slot59, align 32
  %491 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %490
  store <8 x float> %491, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state329 = load i64, ptr %.slot58, align 4
  %492 = icmp slt i64 %.state329, 80
  br i1 %492, label %direct.true330, label %direct.false331

direct.schedule.38:                               ; preds = %direct.true330
  %.state332 = load i64, ptr %.slot58, align 4
  %493 = add i64 0, %.state332
  %tile_snapshot.spill.load333 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load333, 0
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load333, 1
  %.splatinsert334 = insertelement <8 x i64> poison, i64 %493, i64 0
  %.splat335 = shufflevector <8 x i64> %.splatinsert334, <8 x i64> poison, <8 x i32> zeroinitializer
  %496 = mul <8 x i64> %.splat335, splat (i64 32)
  %497 = add <8 x i64> %495, %496
  %498 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %494, 0
  %499 = insertvalue { <8 x ptr>, <8 x i64> } %498, <8 x i64> %497, 1
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %499, 1
  %502 = extractelement <8 x ptr> %500, i32 0
  %503 = extractelement <8 x i64> %501, i32 0
  %504 = sub i64 %503, 0
  %505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %506 = select i1 %505, i64 %504, i64 0
  %private.contiguous.address336 = getelementptr i8, ptr %502, i64 %506
  %private.contiguous.load337 = load <8 x float>, ptr %private.contiguous.address336, align 4
  %507 = select <8 x i1> %71, <8 x float> %private.contiguous.load337, <8 x float> zeroinitializer
  %.state338 = load i64, ptr %.slot58, align 4
  %508 = add i64 480, %.state338
  %tile_snapshot.spill.load339 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 0
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 1
  %.splatinsert340 = insertelement <8 x i64> poison, i64 %508, i64 0
  %.splat341 = shufflevector <8 x i64> %.splatinsert340, <8 x i64> poison, <8 x i32> zeroinitializer
  %511 = mul <8 x i64> %.splat341, splat (i64 32)
  %512 = add <8 x i64> %510, %511
  %513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %509, 0
  %514 = insertvalue { <8 x ptr>, <8 x i64> } %513, <8 x i64> %512, 1
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %514, 1
  %517 = extractelement <8 x ptr> %515, i32 0
  %518 = extractelement <8 x i64> %516, i32 0
  %519 = sub i64 %518, 0
  %520 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %521 = select i1 %520, i64 %519, i64 0
  %private.contiguous.address342 = getelementptr i8, ptr %517, i64 %521
  %private.contiguous.load343 = load <8 x float>, ptr %private.contiguous.address342, align 4
  %522 = select <8 x i1> %71, <8 x float> %private.contiguous.load343, <8 x float> zeroinitializer
  %523 = fmul <8 x float> %507, %522
  %.state344 = load <8 x float>, ptr %.slot59, align 32
  %524 = fadd <8 x float> %.state344, %523
  %.state345 = load i64, ptr %.slot58, align 4
  %525 = add i64 %.state345, 1
  store i64 %525, ptr %.slot58, align 4
  %526 = load <8 x float>, ptr %.slot59, align 32
  %527 = select <8 x i1> %71, <8 x float> %524, <8 x float> %526
  store <8 x float> %527, ptr %.slot59, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false331
  store i64 0, ptr %.slot60, align 4
  %528 = load <8 x float>, ptr %.slot61, align 32
  %529 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %528
  store <8 x float> %529, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state346 = load i64, ptr %.slot60, align 4
  %530 = icmp slt i64 %.state346, 80
  br i1 %530, label %direct.true347, label %direct.false348

direct.schedule.41:                               ; preds = %direct.true347
  %.state349 = load i64, ptr %.slot60, align 4
  %531 = add i64 0, %.state349
  %tile_snapshot.spill.load350 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load350, 0
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load350, 1
  %.splatinsert351 = insertelement <8 x i64> poison, i64 %531, i64 0
  %.splat352 = shufflevector <8 x i64> %.splatinsert351, <8 x i64> poison, <8 x i32> zeroinitializer
  %534 = mul <8 x i64> %.splat352, splat (i64 32)
  %535 = add <8 x i64> %533, %534
  %536 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %532, 0
  %537 = insertvalue { <8 x ptr>, <8 x i64> } %536, <8 x i64> %535, 1
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %539 = extractvalue { <8 x ptr>, <8 x i64> } %537, 1
  %540 = extractelement <8 x ptr> %538, i32 0
  %541 = extractelement <8 x i64> %539, i32 0
  %542 = sub i64 %541, 0
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %544 = select i1 %543, i64 %542, i64 0
  %private.contiguous.address353 = getelementptr i8, ptr %540, i64 %544
  %private.contiguous.load354 = load <8 x float>, ptr %private.contiguous.address353, align 4
  %545 = select <8 x i1> %71, <8 x float> %private.contiguous.load354, <8 x float> zeroinitializer
  %.state355 = load i64, ptr %.slot60, align 4
  %546 = add i64 560, %.state355
  %tile_snapshot.spill.load356 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load356, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load356, 1
  %.splatinsert357 = insertelement <8 x i64> poison, i64 %546, i64 0
  %.splat358 = shufflevector <8 x i64> %.splatinsert357, <8 x i64> poison, <8 x i32> zeroinitializer
  %549 = mul <8 x i64> %.splat358, splat (i64 32)
  %550 = add <8 x i64> %548, %549
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %547, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = extractelement <8 x ptr> %553, i32 0
  %556 = extractelement <8 x i64> %554, i32 0
  %557 = sub i64 %556, 0
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %559 = select i1 %558, i64 %557, i64 0
  %private.contiguous.address359 = getelementptr i8, ptr %555, i64 %559
  %private.contiguous.load360 = load <8 x float>, ptr %private.contiguous.address359, align 4
  %560 = select <8 x i1> %71, <8 x float> %private.contiguous.load360, <8 x float> zeroinitializer
  %561 = fmul <8 x float> %545, %560
  %.state361 = load <8 x float>, ptr %.slot61, align 32
  %562 = fadd <8 x float> %.state361, %561
  %.state362 = load i64, ptr %.slot60, align 4
  %563 = add i64 %.state362, 1
  store i64 %563, ptr %.slot60, align 4
  %564 = load <8 x float>, ptr %.slot61, align 32
  %565 = select <8 x i1> %71, <8 x float> %562, <8 x float> %564
  store <8 x float> %565, ptr %.slot61, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false348
  store i64 0, ptr %.slot62, align 4
  %566 = load <8 x float>, ptr %.slot63, align 32
  %567 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %566
  store <8 x float> %567, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state363 = load i64, ptr %.slot62, align 4
  %568 = icmp slt i64 %.state363, 80
  br i1 %568, label %direct.true364, label %direct.false365

direct.schedule.44:                               ; preds = %direct.true364
  %.state366 = load i64, ptr %.slot62, align 4
  %569 = add i64 0, %.state366
  %tile_snapshot.spill.load367 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load367, 0
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load367, 1
  %.splatinsert368 = insertelement <8 x i64> poison, i64 %569, i64 0
  %.splat369 = shufflevector <8 x i64> %.splatinsert368, <8 x i64> poison, <8 x i32> zeroinitializer
  %572 = mul <8 x i64> %.splat369, splat (i64 32)
  %573 = add <8 x i64> %571, %572
  %574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %570, 0
  %575 = insertvalue { <8 x ptr>, <8 x i64> } %574, <8 x i64> %573, 1
  %576 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %575, 1
  %578 = extractelement <8 x ptr> %576, i32 0
  %579 = extractelement <8 x i64> %577, i32 0
  %580 = sub i64 %579, 0
  %581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %582 = select i1 %581, i64 %580, i64 0
  %private.contiguous.address370 = getelementptr i8, ptr %578, i64 %582
  %private.contiguous.load371 = load <8 x float>, ptr %private.contiguous.address370, align 4
  %583 = select <8 x i1> %71, <8 x float> %private.contiguous.load371, <8 x float> zeroinitializer
  %.state372 = load i64, ptr %.slot62, align 4
  %584 = add i64 640, %.state372
  %tile_snapshot.spill.load373 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %.splatinsert374 = insertelement <8 x i64> poison, i64 %584, i64 0
  %.splat375 = shufflevector <8 x i64> %.splatinsert374, <8 x i64> poison, <8 x i32> zeroinitializer
  %587 = mul <8 x i64> %.splat375, splat (i64 32)
  %588 = add <8 x i64> %586, %587
  %589 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %585, 0
  %590 = insertvalue { <8 x ptr>, <8 x i64> } %589, <8 x i64> %588, 1
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %592 = extractvalue { <8 x ptr>, <8 x i64> } %590, 1
  %593 = extractelement <8 x ptr> %591, i32 0
  %594 = extractelement <8 x i64> %592, i32 0
  %595 = sub i64 %594, 0
  %596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %597 = select i1 %596, i64 %595, i64 0
  %private.contiguous.address376 = getelementptr i8, ptr %593, i64 %597
  %private.contiguous.load377 = load <8 x float>, ptr %private.contiguous.address376, align 4
  %598 = select <8 x i1> %71, <8 x float> %private.contiguous.load377, <8 x float> zeroinitializer
  %599 = fmul <8 x float> %583, %598
  %.state378 = load <8 x float>, ptr %.slot63, align 32
  %600 = fadd <8 x float> %.state378, %599
  %.state379 = load i64, ptr %.slot62, align 4
  %601 = add i64 %.state379, 1
  store i64 %601, ptr %.slot62, align 4
  %602 = load <8 x float>, ptr %.slot63, align 32
  %603 = select <8 x i1> %71, <8 x float> %600, <8 x float> %602
  store <8 x float> %603, ptr %.slot63, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false365
  store i64 0, ptr %.slot64, align 4
  %604 = load <8 x float>, ptr %.slot65, align 32
  %605 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %604
  store <8 x float> %605, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state380 = load i64, ptr %.slot64, align 4
  %606 = icmp slt i64 %.state380, 80
  br i1 %606, label %direct.true381, label %direct.false382

direct.schedule.47:                               ; preds = %direct.true381
  %.state383 = load i64, ptr %.slot64, align 4
  %607 = add i64 0, %.state383
  %tile_snapshot.spill.load384 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load384, 0
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load384, 1
  %.splatinsert385 = insertelement <8 x i64> poison, i64 %607, i64 0
  %.splat386 = shufflevector <8 x i64> %.splatinsert385, <8 x i64> poison, <8 x i32> zeroinitializer
  %610 = mul <8 x i64> %.splat386, splat (i64 32)
  %611 = add <8 x i64> %609, %610
  %612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %608, 0
  %613 = insertvalue { <8 x ptr>, <8 x i64> } %612, <8 x i64> %611, 1
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %613, 1
  %616 = extractelement <8 x ptr> %614, i32 0
  %617 = extractelement <8 x i64> %615, i32 0
  %618 = sub i64 %617, 0
  %619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %620 = select i1 %619, i64 %618, i64 0
  %private.contiguous.address387 = getelementptr i8, ptr %616, i64 %620
  %private.contiguous.load388 = load <8 x float>, ptr %private.contiguous.address387, align 4
  %621 = select <8 x i1> %71, <8 x float> %private.contiguous.load388, <8 x float> zeroinitializer
  %.state389 = load i64, ptr %.slot64, align 4
  %622 = add i64 720, %.state389
  %tile_snapshot.spill.load390 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %623 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load390, 0
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load390, 1
  %.splatinsert391 = insertelement <8 x i64> poison, i64 %622, i64 0
  %.splat392 = shufflevector <8 x i64> %.splatinsert391, <8 x i64> poison, <8 x i32> zeroinitializer
  %625 = mul <8 x i64> %.splat392, splat (i64 32)
  %626 = add <8 x i64> %624, %625
  %627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %623, 0
  %628 = insertvalue { <8 x ptr>, <8 x i64> } %627, <8 x i64> %626, 1
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %628, 1
  %631 = extractelement <8 x ptr> %629, i32 0
  %632 = extractelement <8 x i64> %630, i32 0
  %633 = sub i64 %632, 0
  %634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %635 = select i1 %634, i64 %633, i64 0
  %private.contiguous.address393 = getelementptr i8, ptr %631, i64 %635
  %private.contiguous.load394 = load <8 x float>, ptr %private.contiguous.address393, align 4
  %636 = select <8 x i1> %71, <8 x float> %private.contiguous.load394, <8 x float> zeroinitializer
  %637 = fmul <8 x float> %621, %636
  %.state395 = load <8 x float>, ptr %.slot65, align 32
  %638 = fadd <8 x float> %.state395, %637
  %.state396 = load i64, ptr %.slot64, align 4
  %639 = add i64 %.state396, 1
  store i64 %639, ptr %.slot64, align 4
  %640 = load <8 x float>, ptr %.slot65, align 32
  %641 = select <8 x i1> %71, <8 x float> %638, <8 x float> %640
  store <8 x float> %641, ptr %.slot65, align 32
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false382
  store i64 0, ptr %.slot66, align 4
  %642 = load <8 x float>, ptr %.slot67, align 32
  %643 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %642
  store <8 x float> %643, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state397 = load i64, ptr %.slot66, align 4
  %644 = icmp slt i64 %.state397, 80
  br i1 %644, label %direct.true398, label %direct.false399

direct.schedule.50:                               ; preds = %direct.true398
  %.state400 = load i64, ptr %.slot66, align 4
  %645 = add i64 0, %.state400
  %tile_snapshot.spill.load401 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load401, 0
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load401, 1
  %.splatinsert402 = insertelement <8 x i64> poison, i64 %645, i64 0
  %.splat403 = shufflevector <8 x i64> %.splatinsert402, <8 x i64> poison, <8 x i32> zeroinitializer
  %648 = mul <8 x i64> %.splat403, splat (i64 32)
  %649 = add <8 x i64> %647, %648
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %646, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 0
  %656 = sub i64 %655, 0
  %657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %658 = select i1 %657, i64 %656, i64 0
  %private.contiguous.address404 = getelementptr i8, ptr %654, i64 %658
  %private.contiguous.load405 = load <8 x float>, ptr %private.contiguous.address404, align 4
  %659 = select <8 x i1> %71, <8 x float> %private.contiguous.load405, <8 x float> zeroinitializer
  %.state406 = load i64, ptr %.slot66, align 4
  %660 = add i64 800, %.state406
  %tile_snapshot.spill.load407 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %.splatinsert408 = insertelement <8 x i64> poison, i64 %660, i64 0
  %.splat409 = shufflevector <8 x i64> %.splatinsert408, <8 x i64> poison, <8 x i32> zeroinitializer
  %663 = mul <8 x i64> %.splat409, splat (i64 32)
  %664 = add <8 x i64> %662, %663
  %665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %661, 0
  %666 = insertvalue { <8 x ptr>, <8 x i64> } %665, <8 x i64> %664, 1
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %666, 1
  %669 = extractelement <8 x ptr> %667, i32 0
  %670 = extractelement <8 x i64> %668, i32 0
  %671 = sub i64 %670, 0
  %672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %673 = select i1 %672, i64 %671, i64 0
  %private.contiguous.address410 = getelementptr i8, ptr %669, i64 %673
  %private.contiguous.load411 = load <8 x float>, ptr %private.contiguous.address410, align 4
  %674 = select <8 x i1> %71, <8 x float> %private.contiguous.load411, <8 x float> zeroinitializer
  %675 = fmul <8 x float> %659, %674
  %.state412 = load <8 x float>, ptr %.slot67, align 32
  %676 = fadd <8 x float> %.state412, %675
  %.state413 = load i64, ptr %.slot66, align 4
  %677 = add i64 %.state413, 1
  store i64 %677, ptr %.slot66, align 4
  %678 = load <8 x float>, ptr %.slot67, align 32
  %679 = select <8 x i1> %71, <8 x float> %676, <8 x float> %678
  store <8 x float> %679, ptr %.slot67, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false399
  store i64 0, ptr %.slot68, align 4
  %680 = load <8 x float>, ptr %.slot69, align 32
  %681 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %680
  store <8 x float> %681, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state414 = load i64, ptr %.slot68, align 4
  %682 = icmp slt i64 %.state414, 80
  br i1 %682, label %direct.true415, label %direct.false416

direct.schedule.53:                               ; preds = %direct.true415
  %.state417 = load i64, ptr %.slot68, align 4
  %683 = add i64 0, %.state417
  %tile_snapshot.spill.load418 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load418, 0
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load418, 1
  %.splatinsert419 = insertelement <8 x i64> poison, i64 %683, i64 0
  %.splat420 = shufflevector <8 x i64> %.splatinsert419, <8 x i64> poison, <8 x i32> zeroinitializer
  %686 = mul <8 x i64> %.splat420, splat (i64 32)
  %687 = add <8 x i64> %685, %686
  %688 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %684, 0
  %689 = insertvalue { <8 x ptr>, <8 x i64> } %688, <8 x i64> %687, 1
  %690 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %689, 1
  %692 = extractelement <8 x ptr> %690, i32 0
  %693 = extractelement <8 x i64> %691, i32 0
  %694 = sub i64 %693, 0
  %695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %696 = select i1 %695, i64 %694, i64 0
  %private.contiguous.address421 = getelementptr i8, ptr %692, i64 %696
  %private.contiguous.load422 = load <8 x float>, ptr %private.contiguous.address421, align 4
  %697 = select <8 x i1> %71, <8 x float> %private.contiguous.load422, <8 x float> zeroinitializer
  %.state423 = load i64, ptr %.slot68, align 4
  %698 = add i64 880, %.state423
  %tile_snapshot.spill.load424 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load424, 0
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load424, 1
  %.splatinsert425 = insertelement <8 x i64> poison, i64 %698, i64 0
  %.splat426 = shufflevector <8 x i64> %.splatinsert425, <8 x i64> poison, <8 x i32> zeroinitializer
  %701 = mul <8 x i64> %.splat426, splat (i64 32)
  %702 = add <8 x i64> %700, %701
  %703 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %699, 0
  %704 = insertvalue { <8 x ptr>, <8 x i64> } %703, <8 x i64> %702, 1
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %706 = extractvalue { <8 x ptr>, <8 x i64> } %704, 1
  %707 = extractelement <8 x ptr> %705, i32 0
  %708 = extractelement <8 x i64> %706, i32 0
  %709 = sub i64 %708, 0
  %710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %711 = select i1 %710, i64 %709, i64 0
  %private.contiguous.address427 = getelementptr i8, ptr %707, i64 %711
  %private.contiguous.load428 = load <8 x float>, ptr %private.contiguous.address427, align 4
  %712 = select <8 x i1> %71, <8 x float> %private.contiguous.load428, <8 x float> zeroinitializer
  %713 = fmul <8 x float> %697, %712
  %.state429 = load <8 x float>, ptr %.slot69, align 32
  %714 = fadd <8 x float> %.state429, %713
  %.state430 = load i64, ptr %.slot68, align 4
  %715 = add i64 %.state430, 1
  store i64 %715, ptr %.slot68, align 4
  %716 = load <8 x float>, ptr %.slot69, align 32
  %717 = select <8 x i1> %71, <8 x float> %714, <8 x float> %716
  store <8 x float> %717, ptr %.slot69, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false416
  store i64 0, ptr %.slot70, align 4
  %718 = load <8 x float>, ptr %.slot71, align 32
  %719 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %718
  store <8 x float> %719, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state431 = load i64, ptr %.slot70, align 4
  %720 = icmp slt i64 %.state431, 80
  br i1 %720, label %direct.true432, label %direct.false433

direct.schedule.56:                               ; preds = %direct.true432
  %.state434 = load i64, ptr %.slot70, align 4
  %721 = add i64 0, %.state434
  %tile_snapshot.spill.load435 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 0
  %723 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 1
  %.splatinsert436 = insertelement <8 x i64> poison, i64 %721, i64 0
  %.splat437 = shufflevector <8 x i64> %.splatinsert436, <8 x i64> poison, <8 x i32> zeroinitializer
  %724 = mul <8 x i64> %.splat437, splat (i64 32)
  %725 = add <8 x i64> %723, %724
  %726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %722, 0
  %727 = insertvalue { <8 x ptr>, <8 x i64> } %726, <8 x i64> %725, 1
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %727, 1
  %730 = extractelement <8 x ptr> %728, i32 0
  %731 = extractelement <8 x i64> %729, i32 0
  %732 = sub i64 %731, 0
  %733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %734 = select i1 %733, i64 %732, i64 0
  %private.contiguous.address438 = getelementptr i8, ptr %730, i64 %734
  %private.contiguous.load439 = load <8 x float>, ptr %private.contiguous.address438, align 4
  %735 = select <8 x i1> %71, <8 x float> %private.contiguous.load439, <8 x float> zeroinitializer
  %.state440 = load i64, ptr %.slot70, align 4
  %736 = add i64 960, %.state440
  %tile_snapshot.spill.load441 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load441, 0
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load441, 1
  %.splatinsert442 = insertelement <8 x i64> poison, i64 %736, i64 0
  %.splat443 = shufflevector <8 x i64> %.splatinsert442, <8 x i64> poison, <8 x i32> zeroinitializer
  %739 = mul <8 x i64> %.splat443, splat (i64 32)
  %740 = add <8 x i64> %738, %739
  %741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %737, 0
  %742 = insertvalue { <8 x ptr>, <8 x i64> } %741, <8 x i64> %740, 1
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %742, 1
  %745 = extractelement <8 x ptr> %743, i32 0
  %746 = extractelement <8 x i64> %744, i32 0
  %747 = sub i64 %746, 0
  %748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %749 = select i1 %748, i64 %747, i64 0
  %private.contiguous.address444 = getelementptr i8, ptr %745, i64 %749
  %private.contiguous.load445 = load <8 x float>, ptr %private.contiguous.address444, align 4
  %750 = select <8 x i1> %71, <8 x float> %private.contiguous.load445, <8 x float> zeroinitializer
  %751 = fmul <8 x float> %735, %750
  %.state446 = load <8 x float>, ptr %.slot71, align 32
  %752 = fadd <8 x float> %.state446, %751
  %.state447 = load i64, ptr %.slot70, align 4
  %753 = add i64 %.state447, 1
  store i64 %753, ptr %.slot70, align 4
  %754 = load <8 x float>, ptr %.slot71, align 32
  %755 = select <8 x i1> %71, <8 x float> %752, <8 x float> %754
  store <8 x float> %755, ptr %.slot71, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false433
  store i64 0, ptr %.slot72, align 4
  %756 = load <8 x float>, ptr %.slot73, align 32
  %757 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %756
  store <8 x float> %757, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state448 = load i64, ptr %.slot72, align 4
  %758 = icmp slt i64 %.state448, 80
  br i1 %758, label %direct.true449, label %direct.false450

direct.schedule.59:                               ; preds = %direct.true449
  %.state451 = load i64, ptr %.slot72, align 4
  %759 = add i64 0, %.state451
  %tile_snapshot.spill.load452 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load452, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load452, 1
  %.splatinsert453 = insertelement <8 x i64> poison, i64 %759, i64 0
  %.splat454 = shufflevector <8 x i64> %.splatinsert453, <8 x i64> poison, <8 x i32> zeroinitializer
  %762 = mul <8 x i64> %.splat454, splat (i64 32)
  %763 = add <8 x i64> %761, %762
  %764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %760, 0
  %765 = insertvalue { <8 x ptr>, <8 x i64> } %764, <8 x i64> %763, 1
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %765, 1
  %768 = extractelement <8 x ptr> %766, i32 0
  %769 = extractelement <8 x i64> %767, i32 0
  %770 = sub i64 %769, 0
  %771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %772 = select i1 %771, i64 %770, i64 0
  %private.contiguous.address455 = getelementptr i8, ptr %768, i64 %772
  %private.contiguous.load456 = load <8 x float>, ptr %private.contiguous.address455, align 4
  %773 = select <8 x i1> %71, <8 x float> %private.contiguous.load456, <8 x float> zeroinitializer
  %.state457 = load i64, ptr %.slot72, align 4
  %774 = add i64 1040, %.state457
  %tile_snapshot.spill.load458 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load458, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load458, 1
  %.splatinsert459 = insertelement <8 x i64> poison, i64 %774, i64 0
  %.splat460 = shufflevector <8 x i64> %.splatinsert459, <8 x i64> poison, <8 x i32> zeroinitializer
  %777 = mul <8 x i64> %.splat460, splat (i64 32)
  %778 = add <8 x i64> %776, %777
  %779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %775, 0
  %780 = insertvalue { <8 x ptr>, <8 x i64> } %779, <8 x i64> %778, 1
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %780, 1
  %783 = extractelement <8 x ptr> %781, i32 0
  %784 = extractelement <8 x i64> %782, i32 0
  %785 = sub i64 %784, 0
  %786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %787 = select i1 %786, i64 %785, i64 0
  %private.contiguous.address461 = getelementptr i8, ptr %783, i64 %787
  %private.contiguous.load462 = load <8 x float>, ptr %private.contiguous.address461, align 4
  %788 = select <8 x i1> %71, <8 x float> %private.contiguous.load462, <8 x float> zeroinitializer
  %789 = fmul <8 x float> %773, %788
  %.state463 = load <8 x float>, ptr %.slot73, align 32
  %790 = fadd <8 x float> %.state463, %789
  %.state464 = load i64, ptr %.slot72, align 4
  %791 = add i64 %.state464, 1
  store i64 %791, ptr %.slot72, align 4
  %792 = load <8 x float>, ptr %.slot73, align 32
  %793 = select <8 x i1> %71, <8 x float> %790, <8 x float> %792
  store <8 x float> %793, ptr %.slot73, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false450
  store i64 0, ptr %.slot74, align 4
  %794 = load <8 x float>, ptr %.slot75, align 32
  %795 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %794
  store <8 x float> %795, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state465 = load i64, ptr %.slot74, align 4
  %796 = icmp slt i64 %.state465, 80
  br i1 %796, label %direct.true466, label %direct.false467

direct.schedule.62:                               ; preds = %direct.true466
  %.state468 = load i64, ptr %.slot74, align 4
  %797 = add i64 0, %.state468
  %tile_snapshot.spill.load469 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load469, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load469, 1
  %.splatinsert470 = insertelement <8 x i64> poison, i64 %797, i64 0
  %.splat471 = shufflevector <8 x i64> %.splatinsert470, <8 x i64> poison, <8 x i32> zeroinitializer
  %800 = mul <8 x i64> %.splat471, splat (i64 32)
  %801 = add <8 x i64> %799, %800
  %802 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %798, 0
  %803 = insertvalue { <8 x ptr>, <8 x i64> } %802, <8 x i64> %801, 1
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %803, 1
  %806 = extractelement <8 x ptr> %804, i32 0
  %807 = extractelement <8 x i64> %805, i32 0
  %808 = sub i64 %807, 0
  %809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %810 = select i1 %809, i64 %808, i64 0
  %private.contiguous.address472 = getelementptr i8, ptr %806, i64 %810
  %private.contiguous.load473 = load <8 x float>, ptr %private.contiguous.address472, align 4
  %811 = select <8 x i1> %71, <8 x float> %private.contiguous.load473, <8 x float> zeroinitializer
  %.state474 = load i64, ptr %.slot74, align 4
  %812 = add i64 1120, %.state474
  %tile_snapshot.spill.load475 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %813 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load475, 0
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load475, 1
  %.splatinsert476 = insertelement <8 x i64> poison, i64 %812, i64 0
  %.splat477 = shufflevector <8 x i64> %.splatinsert476, <8 x i64> poison, <8 x i32> zeroinitializer
  %815 = mul <8 x i64> %.splat477, splat (i64 32)
  %816 = add <8 x i64> %814, %815
  %817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %813, 0
  %818 = insertvalue { <8 x ptr>, <8 x i64> } %817, <8 x i64> %816, 1
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %818, 1
  %821 = extractelement <8 x ptr> %819, i32 0
  %822 = extractelement <8 x i64> %820, i32 0
  %823 = sub i64 %822, 0
  %824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %825 = select i1 %824, i64 %823, i64 0
  %private.contiguous.address478 = getelementptr i8, ptr %821, i64 %825
  %private.contiguous.load479 = load <8 x float>, ptr %private.contiguous.address478, align 4
  %826 = select <8 x i1> %71, <8 x float> %private.contiguous.load479, <8 x float> zeroinitializer
  %827 = fmul <8 x float> %811, %826
  %.state480 = load <8 x float>, ptr %.slot75, align 32
  %828 = fadd <8 x float> %.state480, %827
  %.state481 = load i64, ptr %.slot74, align 4
  %829 = add i64 %.state481, 1
  store i64 %829, ptr %.slot74, align 4
  %830 = load <8 x float>, ptr %.slot75, align 32
  %831 = select <8 x i1> %71, <8 x float> %828, <8 x float> %830
  store <8 x float> %831, ptr %.slot75, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false467
  store i64 0, ptr %.slot76, align 4
  %832 = load <8 x float>, ptr %.slot77, align 32
  %833 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %832
  store <8 x float> %833, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state482 = load i64, ptr %.slot76, align 4
  %834 = icmp slt i64 %.state482, 80
  br i1 %834, label %direct.true483, label %direct.false484

direct.schedule.65:                               ; preds = %direct.true483
  %.state485 = load i64, ptr %.slot76, align 4
  %835 = add i64 0, %.state485
  %tile_snapshot.spill.load486 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load486, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load486, 1
  %.splatinsert487 = insertelement <8 x i64> poison, i64 %835, i64 0
  %.splat488 = shufflevector <8 x i64> %.splatinsert487, <8 x i64> poison, <8 x i32> zeroinitializer
  %838 = mul <8 x i64> %.splat488, splat (i64 32)
  %839 = add <8 x i64> %837, %838
  %840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %836, 0
  %841 = insertvalue { <8 x ptr>, <8 x i64> } %840, <8 x i64> %839, 1
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %841, 1
  %844 = extractelement <8 x ptr> %842, i32 0
  %845 = extractelement <8 x i64> %843, i32 0
  %846 = sub i64 %845, 0
  %847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %848 = select i1 %847, i64 %846, i64 0
  %private.contiguous.address489 = getelementptr i8, ptr %844, i64 %848
  %private.contiguous.load490 = load <8 x float>, ptr %private.contiguous.address489, align 4
  %849 = select <8 x i1> %71, <8 x float> %private.contiguous.load490, <8 x float> zeroinitializer
  %.state491 = load i64, ptr %.slot76, align 4
  %850 = add i64 1200, %.state491
  %tile_snapshot.spill.load492 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load492, 0
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load492, 1
  %.splatinsert493 = insertelement <8 x i64> poison, i64 %850, i64 0
  %.splat494 = shufflevector <8 x i64> %.splatinsert493, <8 x i64> poison, <8 x i32> zeroinitializer
  %853 = mul <8 x i64> %.splat494, splat (i64 32)
  %854 = add <8 x i64> %852, %853
  %855 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %851, 0
  %856 = insertvalue { <8 x ptr>, <8 x i64> } %855, <8 x i64> %854, 1
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %856, 1
  %859 = extractelement <8 x ptr> %857, i32 0
  %860 = extractelement <8 x i64> %858, i32 0
  %861 = sub i64 %860, 0
  %862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %863 = select i1 %862, i64 %861, i64 0
  %private.contiguous.address495 = getelementptr i8, ptr %859, i64 %863
  %private.contiguous.load496 = load <8 x float>, ptr %private.contiguous.address495, align 4
  %864 = select <8 x i1> %71, <8 x float> %private.contiguous.load496, <8 x float> zeroinitializer
  %865 = fmul <8 x float> %849, %864
  %.state497 = load <8 x float>, ptr %.slot77, align 32
  %866 = fadd <8 x float> %.state497, %865
  %.state498 = load i64, ptr %.slot76, align 4
  %867 = add i64 %.state498, 1
  store i64 %867, ptr %.slot76, align 4
  %868 = load <8 x float>, ptr %.slot77, align 32
  %869 = select <8 x i1> %71, <8 x float> %866, <8 x float> %868
  store <8 x float> %869, ptr %.slot77, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false484
  %.state499 = load <8 x float>, ptr %.slot47, align 32
  %870 = fmul <8 x float> %.state499, splat (float 0x3FBC9F25C0000000)
  %.state500 = load <8 x float>, ptr %.slot49, align 32
  %871 = fmul <8 x float> %.state500, splat (float 0x3FBC9F25C0000000)
  %.state501 = load <8 x float>, ptr %.slot51, align 32
  %872 = fmul <8 x float> %.state501, splat (float 0x3FBC9F25C0000000)
  %.state502 = load <8 x float>, ptr %.slot53, align 32
  %873 = fmul <8 x float> %.state502, splat (float 0x3FBC9F25C0000000)
  %.state503 = load <8 x float>, ptr %.slot55, align 32
  %874 = fmul <8 x float> %.state503, splat (float 0x3FBC9F25C0000000)
  %.state504 = load <8 x float>, ptr %.slot57, align 32
  %875 = fmul <8 x float> %.state504, splat (float 0x3FBC9F25C0000000)
  %.state505 = load <8 x float>, ptr %.slot59, align 32
  %876 = fmul <8 x float> %.state505, splat (float 0x3FBC9F25C0000000)
  %.state506 = load <8 x float>, ptr %.slot61, align 32
  %877 = fmul <8 x float> %.state506, splat (float 0x3FBC9F25C0000000)
  %.state507 = load <8 x float>, ptr %.slot63, align 32
  %878 = fmul <8 x float> %.state507, splat (float 0x3FBC9F25C0000000)
  %.state508 = load <8 x float>, ptr %.slot65, align 32
  %879 = fmul <8 x float> %.state508, splat (float 0x3FBC9F25C0000000)
  %.state509 = load <8 x float>, ptr %.slot67, align 32
  %880 = fmul <8 x float> %.state509, splat (float 0x3FBC9F25C0000000)
  %.state510 = load <8 x float>, ptr %.slot69, align 32
  %881 = fmul <8 x float> %.state510, splat (float 0x3FBC9F25C0000000)
  %.state511 = load <8 x float>, ptr %.slot71, align 32
  %882 = fmul <8 x float> %.state511, splat (float 0x3FBC9F25C0000000)
  %.state512 = load <8 x float>, ptr %.slot73, align 32
  %883 = fmul <8 x float> %.state512, splat (float 0x3FBC9F25C0000000)
  %.state513 = load <8 x float>, ptr %.slot75, align 32
  %884 = fmul <8 x float> %.state513, splat (float 0x3FBC9F25C0000000)
  %.state514 = load <8 x float>, ptr %.slot77, align 32
  %885 = fmul <8 x float> %.state514, splat (float 0x3FBC9F25C0000000)
  %.spill.load515 = load i64, ptr %.spill37, align 4
  %886 = add i64 0, %.spill.load515
  %.spill.load516 = load i64, ptr %.spill37, align 4
  %887 = add i64 1, %.spill.load516
  %.spill.load517 = load i64, ptr %.spill37, align 4
  %888 = add i64 2, %.spill.load517
  %.spill.load518 = load i64, ptr %.spill37, align 4
  %889 = add i64 3, %.spill.load518
  %.spill.load519 = load i64, ptr %.spill37, align 4
  %890 = add i64 4, %.spill.load519
  %.spill.load520 = load i64, ptr %.spill37, align 4
  %891 = add i64 5, %.spill.load520
  %.spill.load521 = load i64, ptr %.spill37, align 4
  %892 = add i64 6, %.spill.load521
  %.spill.load522 = load i64, ptr %.spill37, align 4
  %893 = add i64 7, %.spill.load522
  %.spill.load523 = load i64, ptr %.spill37, align 4
  %894 = add i64 8, %.spill.load523
  %.spill.load524 = load i64, ptr %.spill37, align 4
  %895 = add i64 9, %.spill.load524
  %.spill.load525 = load i64, ptr %.spill37, align 4
  %896 = add i64 10, %.spill.load525
  %.spill.load526 = load i64, ptr %.spill37, align 4
  %897 = add i64 11, %.spill.load526
  %.spill.load527 = load i64, ptr %.spill37, align 4
  %898 = add i64 12, %.spill.load527
  %.spill.load528 = load i64, ptr %.spill37, align 4
  %899 = add i64 13, %.spill.load528
  %.spill.load529 = load i64, ptr %.spill37, align 4
  %900 = add i64 14, %.spill.load529
  %.spill.load530 = load i64, ptr %.spill37, align 4
  %901 = add i64 15, %.spill.load530
  %902 = icmp slt i64 %886, 2053
  %903 = icmp slt i64 %887, 2053
  %904 = icmp slt i64 %888, 2053
  %905 = icmp slt i64 %889, 2053
  %906 = icmp slt i64 %890, 2053
  %907 = icmp slt i64 %891, 2053
  %908 = icmp slt i64 %892, 2053
  %909 = icmp slt i64 %893, 2053
  %910 = icmp slt i64 %894, 2053
  %911 = icmp slt i64 %895, 2053
  %912 = icmp slt i64 %896, 2053
  %913 = icmp slt i64 %897, 2053
  %914 = icmp slt i64 %898, 2053
  %915 = icmp slt i64 %899, 2053
  %916 = icmp slt i64 %900, 2053
  %917 = icmp slt i64 %901, 2053
  %.spill.load531 = load i64, ptr %.spill29, align 4
  %918 = add i64 0, %.spill.load531
  store i64 %918, ptr %.spill78, align 4
  %919 = add i64 %918, 2053
  %920 = sub i64 %919, 1
  %921 = icmp sle i64 %886, %920
  %922 = icmp sle i64 %887, %920
  %923 = icmp sle i64 %888, %920
  %924 = icmp sle i64 %889, %920
  %925 = icmp sle i64 %890, %920
  %926 = icmp sle i64 %891, %920
  %927 = icmp sle i64 %892, %920
  %928 = icmp sle i64 %893, %920
  %929 = icmp sle i64 %894, %920
  %930 = icmp sle i64 %895, %920
  %931 = icmp sle i64 %896, %920
  %932 = icmp sle i64 %897, %920
  %933 = icmp sle i64 %898, %920
  %934 = icmp sle i64 %899, %920
  %935 = icmp sle i64 %900, %920
  %936 = icmp sle i64 %901, %920
  %937 = and i1 %902, %921
  store i1 %937, ptr %.spill79, align 1
  %938 = and i1 %903, %922
  store i1 %938, ptr %.spill80, align 1
  %939 = and i1 %904, %923
  store i1 %939, ptr %.spill81, align 1
  %940 = and i1 %905, %924
  store i1 %940, ptr %.spill82, align 1
  %941 = and i1 %906, %925
  store i1 %941, ptr %.spill83, align 1
  %942 = and i1 %907, %926
  store i1 %942, ptr %.spill84, align 1
  %943 = and i1 %908, %927
  store i1 %943, ptr %.spill85, align 1
  %944 = and i1 %909, %928
  store i1 %944, ptr %.spill86, align 1
  %945 = and i1 %910, %929
  store i1 %945, ptr %.spill87, align 1
  %946 = and i1 %911, %930
  store i1 %946, ptr %.spill88, align 1
  %947 = and i1 %912, %931
  store i1 %947, ptr %.spill89, align 1
  %948 = and i1 %913, %932
  store i1 %948, ptr %.spill90, align 1
  %949 = and i1 %914, %933
  store i1 %949, ptr %.spill91, align 1
  %950 = and i1 %915, %934
  store i1 %950, ptr %.spill92, align 1
  %951 = and i1 %916, %935
  store i1 %951, ptr %.spill93, align 1
  %952 = and i1 %917, %936
  store i1 %952, ptr %.spill94, align 1
  %.splatinsert532 = insertelement <8 x i1> poison, i1 %937, i64 0
  %.splat533 = shufflevector <8 x i1> %.splatinsert532, <8 x i1> poison, <8 x i32> zeroinitializer
  %953 = select <8 x i1> %.splat533, <8 x float> %870, <8 x float> splat (float 0xC6293E5940000000)
  %954 = load <8 x float>, ptr %.spill95, align 32
  %955 = select <8 x i1> %71, <8 x float> %953, <8 x float> %954
  store <8 x float> %955, ptr %.spill95, align 32
  %.splatinsert534 = insertelement <8 x i1> poison, i1 %938, i64 0
  %.splat535 = shufflevector <8 x i1> %.splatinsert534, <8 x i1> poison, <8 x i32> zeroinitializer
  %956 = select <8 x i1> %.splat535, <8 x float> %871, <8 x float> splat (float 0xC6293E5940000000)
  %957 = load <8 x float>, ptr %.spill96, align 32
  %958 = select <8 x i1> %71, <8 x float> %956, <8 x float> %957
  store <8 x float> %958, ptr %.spill96, align 32
  %.splatinsert536 = insertelement <8 x i1> poison, i1 %939, i64 0
  %.splat537 = shufflevector <8 x i1> %.splatinsert536, <8 x i1> poison, <8 x i32> zeroinitializer
  %959 = select <8 x i1> %.splat537, <8 x float> %872, <8 x float> splat (float 0xC6293E5940000000)
  %960 = load <8 x float>, ptr %.spill97, align 32
  %961 = select <8 x i1> %71, <8 x float> %959, <8 x float> %960
  store <8 x float> %961, ptr %.spill97, align 32
  %.splatinsert538 = insertelement <8 x i1> poison, i1 %940, i64 0
  %.splat539 = shufflevector <8 x i1> %.splatinsert538, <8 x i1> poison, <8 x i32> zeroinitializer
  %962 = select <8 x i1> %.splat539, <8 x float> %873, <8 x float> splat (float 0xC6293E5940000000)
  %963 = load <8 x float>, ptr %.spill98, align 32
  %964 = select <8 x i1> %71, <8 x float> %962, <8 x float> %963
  store <8 x float> %964, ptr %.spill98, align 32
  %.splatinsert540 = insertelement <8 x i1> poison, i1 %941, i64 0
  %.splat541 = shufflevector <8 x i1> %.splatinsert540, <8 x i1> poison, <8 x i32> zeroinitializer
  %965 = select <8 x i1> %.splat541, <8 x float> %874, <8 x float> splat (float 0xC6293E5940000000)
  %966 = load <8 x float>, ptr %.spill99, align 32
  %967 = select <8 x i1> %71, <8 x float> %965, <8 x float> %966
  store <8 x float> %967, ptr %.spill99, align 32
  %.splatinsert542 = insertelement <8 x i1> poison, i1 %942, i64 0
  %.splat543 = shufflevector <8 x i1> %.splatinsert542, <8 x i1> poison, <8 x i32> zeroinitializer
  %968 = select <8 x i1> %.splat543, <8 x float> %875, <8 x float> splat (float 0xC6293E5940000000)
  %969 = load <8 x float>, ptr %.spill100, align 32
  %970 = select <8 x i1> %71, <8 x float> %968, <8 x float> %969
  store <8 x float> %970, ptr %.spill100, align 32
  %.splatinsert544 = insertelement <8 x i1> poison, i1 %943, i64 0
  %.splat545 = shufflevector <8 x i1> %.splatinsert544, <8 x i1> poison, <8 x i32> zeroinitializer
  %971 = select <8 x i1> %.splat545, <8 x float> %876, <8 x float> splat (float 0xC6293E5940000000)
  %972 = load <8 x float>, ptr %.spill101, align 32
  %973 = select <8 x i1> %71, <8 x float> %971, <8 x float> %972
  store <8 x float> %973, ptr %.spill101, align 32
  %.splatinsert546 = insertelement <8 x i1> poison, i1 %944, i64 0
  %.splat547 = shufflevector <8 x i1> %.splatinsert546, <8 x i1> poison, <8 x i32> zeroinitializer
  %974 = select <8 x i1> %.splat547, <8 x float> %877, <8 x float> splat (float 0xC6293E5940000000)
  %975 = load <8 x float>, ptr %.spill102, align 32
  %976 = select <8 x i1> %71, <8 x float> %974, <8 x float> %975
  store <8 x float> %976, ptr %.spill102, align 32
  %.splatinsert548 = insertelement <8 x i1> poison, i1 %945, i64 0
  %.splat549 = shufflevector <8 x i1> %.splatinsert548, <8 x i1> poison, <8 x i32> zeroinitializer
  %977 = select <8 x i1> %.splat549, <8 x float> %878, <8 x float> splat (float 0xC6293E5940000000)
  %978 = load <8 x float>, ptr %.spill103, align 32
  %979 = select <8 x i1> %71, <8 x float> %977, <8 x float> %978
  store <8 x float> %979, ptr %.spill103, align 32
  %.splatinsert550 = insertelement <8 x i1> poison, i1 %946, i64 0
  %.splat551 = shufflevector <8 x i1> %.splatinsert550, <8 x i1> poison, <8 x i32> zeroinitializer
  %980 = select <8 x i1> %.splat551, <8 x float> %879, <8 x float> splat (float 0xC6293E5940000000)
  %981 = load <8 x float>, ptr %.spill104, align 32
  %982 = select <8 x i1> %71, <8 x float> %980, <8 x float> %981
  store <8 x float> %982, ptr %.spill104, align 32
  %.splatinsert552 = insertelement <8 x i1> poison, i1 %947, i64 0
  %.splat553 = shufflevector <8 x i1> %.splatinsert552, <8 x i1> poison, <8 x i32> zeroinitializer
  %983 = select <8 x i1> %.splat553, <8 x float> %880, <8 x float> splat (float 0xC6293E5940000000)
  %984 = load <8 x float>, ptr %.spill105, align 32
  %985 = select <8 x i1> %71, <8 x float> %983, <8 x float> %984
  store <8 x float> %985, ptr %.spill105, align 32
  %.splatinsert554 = insertelement <8 x i1> poison, i1 %948, i64 0
  %.splat555 = shufflevector <8 x i1> %.splatinsert554, <8 x i1> poison, <8 x i32> zeroinitializer
  %986 = select <8 x i1> %.splat555, <8 x float> %881, <8 x float> splat (float 0xC6293E5940000000)
  %987 = load <8 x float>, ptr %.spill106, align 32
  %988 = select <8 x i1> %71, <8 x float> %986, <8 x float> %987
  store <8 x float> %988, ptr %.spill106, align 32
  %.splatinsert556 = insertelement <8 x i1> poison, i1 %949, i64 0
  %.splat557 = shufflevector <8 x i1> %.splatinsert556, <8 x i1> poison, <8 x i32> zeroinitializer
  %989 = select <8 x i1> %.splat557, <8 x float> %882, <8 x float> splat (float 0xC6293E5940000000)
  %990 = load <8 x float>, ptr %.spill107, align 32
  %991 = select <8 x i1> %71, <8 x float> %989, <8 x float> %990
  store <8 x float> %991, ptr %.spill107, align 32
  %.splatinsert558 = insertelement <8 x i1> poison, i1 %950, i64 0
  %.splat559 = shufflevector <8 x i1> %.splatinsert558, <8 x i1> poison, <8 x i32> zeroinitializer
  %992 = select <8 x i1> %.splat559, <8 x float> %883, <8 x float> splat (float 0xC6293E5940000000)
  %993 = load <8 x float>, ptr %.spill108, align 32
  %994 = select <8 x i1> %71, <8 x float> %992, <8 x float> %993
  store <8 x float> %994, ptr %.spill108, align 32
  %.splatinsert560 = insertelement <8 x i1> poison, i1 %951, i64 0
  %.splat561 = shufflevector <8 x i1> %.splatinsert560, <8 x i1> poison, <8 x i32> zeroinitializer
  %995 = select <8 x i1> %.splat561, <8 x float> %884, <8 x float> splat (float 0xC6293E5940000000)
  %996 = load <8 x float>, ptr %.spill109, align 32
  %997 = select <8 x i1> %71, <8 x float> %995, <8 x float> %996
  store <8 x float> %997, ptr %.spill109, align 32
  %.splatinsert562 = insertelement <8 x i1> poison, i1 %952, i64 0
  %.splat563 = shufflevector <8 x i1> %.splatinsert562, <8 x i1> poison, <8 x i32> zeroinitializer
  %998 = select <8 x i1> %.splat563, <8 x float> %885, <8 x float> splat (float 0xC6293E5940000000)
  %999 = load <8 x float>, ptr %.spill110, align 32
  %1000 = select <8 x i1> %71, <8 x float> %998, <8 x float> %999
  store <8 x float> %1000, ptr %.spill110, align 32
  %1001 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 0
  %1004 = select <8 x i1> %71, <8 x ptr> %1002, <8 x ptr> %1003
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 1
  %1007 = select <8 x i1> %71, <8 x i64> %1005, <8 x i64> %1006
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } %1008, <8 x i64> %1007, 1
  store { <8 x ptr>, <8 x i64> } %1009, ptr %tile_snapshot.spill111, align 64
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1012 = add <8 x i64> %1011, zeroinitializer
  %1013 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1010, 0
  %1014 = insertvalue { <8 x ptr>, <8 x i64> } %1013, <8 x i64> %1012, 1
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %1014, 1
  %1017 = extractelement <8 x ptr> %1015, i32 0
  %1018 = extractelement <8 x i64> %1016, i32 0
  %1019 = sub i64 %1018, 0
  %1020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1021 = select i1 %1020, i64 %1019, i64 0
  %private.contiguous.address564 = getelementptr i8, ptr %1017, i64 %1021
  %private.contiguous.preserve565 = load <8 x float>, ptr %private.contiguous.address564, align 4
  %1022 = select <8 x i1> %71, <8 x float> %953, <8 x float> %private.contiguous.preserve565
  store <8 x float> %1022, ptr %private.contiguous.address564, align 4
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1025 = add <8 x i64> %1024, splat (i64 32)
  %1026 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1023, 0
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } %1026, <8 x i64> %1025, 1
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1027, 1
  %1030 = extractelement <8 x ptr> %1028, i32 0
  %1031 = extractelement <8 x i64> %1029, i32 0
  %1032 = sub i64 %1031, 0
  %1033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1034 = select i1 %1033, i64 %1032, i64 0
  %private.contiguous.address566 = getelementptr i8, ptr %1030, i64 %1034
  %private.contiguous.preserve567 = load <8 x float>, ptr %private.contiguous.address566, align 4
  %1035 = select <8 x i1> %71, <8 x float> %956, <8 x float> %private.contiguous.preserve567
  store <8 x float> %1035, ptr %private.contiguous.address566, align 4
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1038 = add <8 x i64> %1037, splat (i64 64)
  %1039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } %1039, <8 x i64> %1038, 1
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %1040, 1
  %1043 = extractelement <8 x ptr> %1041, i32 0
  %1044 = extractelement <8 x i64> %1042, i32 0
  %1045 = sub i64 %1044, 0
  %1046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1047 = select i1 %1046, i64 %1045, i64 0
  %private.contiguous.address568 = getelementptr i8, ptr %1043, i64 %1047
  %private.contiguous.preserve569 = load <8 x float>, ptr %private.contiguous.address568, align 4
  %1048 = select <8 x i1> %71, <8 x float> %959, <8 x float> %private.contiguous.preserve569
  store <8 x float> %1048, ptr %private.contiguous.address568, align 4
  %1049 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1051 = add <8 x i64> %1050, splat (i64 96)
  %1052 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1049, 0
  %1053 = insertvalue { <8 x ptr>, <8 x i64> } %1052, <8 x i64> %1051, 1
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %1053, 1
  %1056 = extractelement <8 x ptr> %1054, i32 0
  %1057 = extractelement <8 x i64> %1055, i32 0
  %1058 = sub i64 %1057, 0
  %1059 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1060 = select i1 %1059, i64 %1058, i64 0
  %private.contiguous.address570 = getelementptr i8, ptr %1056, i64 %1060
  %private.contiguous.preserve571 = load <8 x float>, ptr %private.contiguous.address570, align 4
  %1061 = select <8 x i1> %71, <8 x float> %962, <8 x float> %private.contiguous.preserve571
  store <8 x float> %1061, ptr %private.contiguous.address570, align 4
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1064 = add <8 x i64> %1063, splat (i64 128)
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1062, 0
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } %1065, <8 x i64> %1064, 1
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 1
  %1069 = extractelement <8 x ptr> %1067, i32 0
  %1070 = extractelement <8 x i64> %1068, i32 0
  %1071 = sub i64 %1070, 0
  %1072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1073 = select i1 %1072, i64 %1071, i64 0
  %private.contiguous.address572 = getelementptr i8, ptr %1069, i64 %1073
  %private.contiguous.preserve573 = load <8 x float>, ptr %private.contiguous.address572, align 4
  %1074 = select <8 x i1> %71, <8 x float> %965, <8 x float> %private.contiguous.preserve573
  store <8 x float> %1074, ptr %private.contiguous.address572, align 4
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1077 = add <8 x i64> %1076, splat (i64 160)
  %1078 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1075, 0
  %1079 = insertvalue { <8 x ptr>, <8 x i64> } %1078, <8 x i64> %1077, 1
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1079, 1
  %1082 = extractelement <8 x ptr> %1080, i32 0
  %1083 = extractelement <8 x i64> %1081, i32 0
  %1084 = sub i64 %1083, 0
  %1085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1086 = select i1 %1085, i64 %1084, i64 0
  %private.contiguous.address574 = getelementptr i8, ptr %1082, i64 %1086
  %private.contiguous.preserve575 = load <8 x float>, ptr %private.contiguous.address574, align 4
  %1087 = select <8 x i1> %71, <8 x float> %968, <8 x float> %private.contiguous.preserve575
  store <8 x float> %1087, ptr %private.contiguous.address574, align 4
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1090 = add <8 x i64> %1089, splat (i64 192)
  %1091 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1088, 0
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } %1091, <8 x i64> %1090, 1
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1092, 1
  %1095 = extractelement <8 x ptr> %1093, i32 0
  %1096 = extractelement <8 x i64> %1094, i32 0
  %1097 = sub i64 %1096, 0
  %1098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1099 = select i1 %1098, i64 %1097, i64 0
  %private.contiguous.address576 = getelementptr i8, ptr %1095, i64 %1099
  %private.contiguous.preserve577 = load <8 x float>, ptr %private.contiguous.address576, align 4
  %1100 = select <8 x i1> %71, <8 x float> %971, <8 x float> %private.contiguous.preserve577
  store <8 x float> %1100, ptr %private.contiguous.address576, align 4
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1103 = add <8 x i64> %1102, splat (i64 224)
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1101, 0
  %1105 = insertvalue { <8 x ptr>, <8 x i64> } %1104, <8 x i64> %1103, 1
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %1105, 1
  %1108 = extractelement <8 x ptr> %1106, i32 0
  %1109 = extractelement <8 x i64> %1107, i32 0
  %1110 = sub i64 %1109, 0
  %1111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1112 = select i1 %1111, i64 %1110, i64 0
  %private.contiguous.address578 = getelementptr i8, ptr %1108, i64 %1112
  %private.contiguous.preserve579 = load <8 x float>, ptr %private.contiguous.address578, align 4
  %1113 = select <8 x i1> %71, <8 x float> %974, <8 x float> %private.contiguous.preserve579
  store <8 x float> %1113, ptr %private.contiguous.address578, align 4
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1116 = add <8 x i64> %1115, splat (i64 256)
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1114, 0
  %1118 = insertvalue { <8 x ptr>, <8 x i64> } %1117, <8 x i64> %1116, 1
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 1
  %1121 = extractelement <8 x ptr> %1119, i32 0
  %1122 = extractelement <8 x i64> %1120, i32 0
  %1123 = sub i64 %1122, 0
  %1124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1125 = select i1 %1124, i64 %1123, i64 0
  %private.contiguous.address580 = getelementptr i8, ptr %1121, i64 %1125
  %private.contiguous.preserve581 = load <8 x float>, ptr %private.contiguous.address580, align 4
  %1126 = select <8 x i1> %71, <8 x float> %977, <8 x float> %private.contiguous.preserve581
  store <8 x float> %1126, ptr %private.contiguous.address580, align 4
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1129 = add <8 x i64> %1128, splat (i64 288)
  %1130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1127, 0
  %1131 = insertvalue { <8 x ptr>, <8 x i64> } %1130, <8 x i64> %1129, 1
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %1131, 1
  %1134 = extractelement <8 x ptr> %1132, i32 0
  %1135 = extractelement <8 x i64> %1133, i32 0
  %1136 = sub i64 %1135, 0
  %1137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1138 = select i1 %1137, i64 %1136, i64 0
  %private.contiguous.address582 = getelementptr i8, ptr %1134, i64 %1138
  %private.contiguous.preserve583 = load <8 x float>, ptr %private.contiguous.address582, align 4
  %1139 = select <8 x i1> %71, <8 x float> %980, <8 x float> %private.contiguous.preserve583
  store <8 x float> %1139, ptr %private.contiguous.address582, align 4
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1142 = add <8 x i64> %1141, splat (i64 320)
  %1143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } %1143, <8 x i64> %1142, 1
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1144, 1
  %1147 = extractelement <8 x ptr> %1145, i32 0
  %1148 = extractelement <8 x i64> %1146, i32 0
  %1149 = sub i64 %1148, 0
  %1150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1151 = select i1 %1150, i64 %1149, i64 0
  %private.contiguous.address584 = getelementptr i8, ptr %1147, i64 %1151
  %private.contiguous.preserve585 = load <8 x float>, ptr %private.contiguous.address584, align 4
  %1152 = select <8 x i1> %71, <8 x float> %983, <8 x float> %private.contiguous.preserve585
  store <8 x float> %1152, ptr %private.contiguous.address584, align 4
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1155 = add <8 x i64> %1154, splat (i64 352)
  %1156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1153, 0
  %1157 = insertvalue { <8 x ptr>, <8 x i64> } %1156, <8 x i64> %1155, 1
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %1157, 1
  %1160 = extractelement <8 x ptr> %1158, i32 0
  %1161 = extractelement <8 x i64> %1159, i32 0
  %1162 = sub i64 %1161, 0
  %1163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1164 = select i1 %1163, i64 %1162, i64 0
  %private.contiguous.address586 = getelementptr i8, ptr %1160, i64 %1164
  %private.contiguous.preserve587 = load <8 x float>, ptr %private.contiguous.address586, align 4
  %1165 = select <8 x i1> %71, <8 x float> %986, <8 x float> %private.contiguous.preserve587
  store <8 x float> %1165, ptr %private.contiguous.address586, align 4
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1168 = add <8 x i64> %1167, splat (i64 384)
  %1169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1166, 0
  %1170 = insertvalue { <8 x ptr>, <8 x i64> } %1169, <8 x i64> %1168, 1
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %1170, 1
  %1173 = extractelement <8 x ptr> %1171, i32 0
  %1174 = extractelement <8 x i64> %1172, i32 0
  %1175 = sub i64 %1174, 0
  %1176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1177 = select i1 %1176, i64 %1175, i64 0
  %private.contiguous.address588 = getelementptr i8, ptr %1173, i64 %1177
  %private.contiguous.preserve589 = load <8 x float>, ptr %private.contiguous.address588, align 4
  %1178 = select <8 x i1> %71, <8 x float> %989, <8 x float> %private.contiguous.preserve589
  store <8 x float> %1178, ptr %private.contiguous.address588, align 4
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1181 = add <8 x i64> %1180, splat (i64 416)
  %1182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1179, 0
  %1183 = insertvalue { <8 x ptr>, <8 x i64> } %1182, <8 x i64> %1181, 1
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %1183, 1
  %1186 = extractelement <8 x ptr> %1184, i32 0
  %1187 = extractelement <8 x i64> %1185, i32 0
  %1188 = sub i64 %1187, 0
  %1189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1190 = select i1 %1189, i64 %1188, i64 0
  %private.contiguous.address590 = getelementptr i8, ptr %1186, i64 %1190
  %private.contiguous.preserve591 = load <8 x float>, ptr %private.contiguous.address590, align 4
  %1191 = select <8 x i1> %71, <8 x float> %992, <8 x float> %private.contiguous.preserve591
  store <8 x float> %1191, ptr %private.contiguous.address590, align 4
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1194 = add <8 x i64> %1193, splat (i64 448)
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1192, 0
  %1196 = insertvalue { <8 x ptr>, <8 x i64> } %1195, <8 x i64> %1194, 1
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 1
  %1199 = extractelement <8 x ptr> %1197, i32 0
  %1200 = extractelement <8 x i64> %1198, i32 0
  %1201 = sub i64 %1200, 0
  %1202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1203 = select i1 %1202, i64 %1201, i64 0
  %private.contiguous.address592 = getelementptr i8, ptr %1199, i64 %1203
  %private.contiguous.preserve593 = load <8 x float>, ptr %private.contiguous.address592, align 4
  %1204 = select <8 x i1> %71, <8 x float> %995, <8 x float> %private.contiguous.preserve593
  store <8 x float> %1204, ptr %private.contiguous.address592, align 4
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1206 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1207 = add <8 x i64> %1206, splat (i64 480)
  %1208 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1205, 0
  %1209 = insertvalue { <8 x ptr>, <8 x i64> } %1208, <8 x i64> %1207, 1
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1211 = extractvalue { <8 x ptr>, <8 x i64> } %1209, 1
  %1212 = extractelement <8 x ptr> %1210, i32 0
  %1213 = extractelement <8 x i64> %1211, i32 0
  %1214 = sub i64 %1213, 0
  %1215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1216 = select i1 %1215, i64 %1214, i64 0
  %private.contiguous.address594 = getelementptr i8, ptr %1212, i64 %1216
  %private.contiguous.preserve595 = load <8 x float>, ptr %private.contiguous.address594, align 4
  %1217 = select <8 x i1> %71, <8 x float> %998, <8 x float> %private.contiguous.preserve595
  store <8 x float> %1217, ptr %private.contiguous.address594, align 4
  store i64 0, ptr %.slot112, align 4
  %1218 = load <8 x float>, ptr %.slot113, align 32
  %1219 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1218
  store <8 x float> %1219, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state596 = load i64, ptr %.slot112, align 4
  %1220 = icmp slt i64 %.state596, 16
  br i1 %1220, label %direct.true597, label %direct.false598

direct.schedule.68:                               ; preds = %direct.true597
  %.state599 = load i64, ptr %.slot112, align 4
  %1221 = sdiv i64 %.state599, 1
  %.spill.load600 = load i64, ptr %.spill78, align 4
  %1222 = mul i64 %.spill.load600, 1
  %1223 = add i64 %1222, 0
  %1224 = mul i64 %1223, 1
  %1225 = add i64 %1224, 0
  %1226 = mul i64 %1225, 16
  %1227 = add i64 %1226, %1221
  %tile_snapshot.spill.load601 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load601, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load601, 1
  %.splatinsert602 = insertelement <8 x i64> poison, i64 %1227, i64 0
  %.splat603 = shufflevector <8 x i64> %.splatinsert602, <8 x i64> poison, <8 x i32> zeroinitializer
  %1230 = mul <8 x i64> %.splat603, splat (i64 32)
  %1231 = add <8 x i64> %1229, %1230
  %1232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1228, 0
  %1233 = insertvalue { <8 x ptr>, <8 x i64> } %1232, <8 x i64> %1231, 1
  %1234 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1235 = extractvalue { <8 x ptr>, <8 x i64> } %1233, 1
  %1236 = extractelement <8 x ptr> %1234, i32 0
  %1237 = extractelement <8 x i64> %1235, i32 0
  %1238 = sub i64 %1237, 0
  %1239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1240 = select i1 %1239, i64 %1238, i64 0
  %private.contiguous.address604 = getelementptr i8, ptr %1236, i64 %1240
  %private.contiguous.load605 = load <8 x float>, ptr %private.contiguous.address604, align 4
  %1241 = select <8 x i1> %71, <8 x float> %private.contiguous.load605, <8 x float> zeroinitializer
  %.state606 = load <8 x float>, ptr %.slot113, align 32
  %1242 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state606, <8 x float> %1241)
  %.state607 = load i64, ptr %.slot112, align 4
  %1243 = add i64 %.state607, 1
  store i64 %1243, ptr %.slot112, align 4
  %1244 = load <8 x float>, ptr %.slot113, align 32
  %1245 = select <8 x i1> %71, <8 x float> %1242, <8 x float> %1244
  store <8 x float> %1245, ptr %.slot113, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false598
  %.state608 = load <8 x float>, ptr %.slot35, align 32
  %.state609 = load <8 x float>, ptr %.slot113, align 32
  %1246 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state608, <8 x float> %.state609)
  %1247 = load <8 x float>, ptr %.spill114, align 32
  %1248 = select <8 x i1> %71, <8 x float> %1246, <8 x float> %1247
  store <8 x float> %1248, ptr %.spill114, align 32
  %.state610 = load <8 x float>, ptr %.slot35, align 32
  %1249 = fsub <8 x float> %.state610, %1246
  %1250 = select <8 x i1> %71, <8 x float> %1249, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1250)
  %1251 = load <8 x float>, ptr %.spill115, align 32
  %1252 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %1251
  store <8 x float> %1252, ptr %.spill115, align 32
  %.spill.load611 = load <8 x float>, ptr %.spill95, align 32
  %1253 = fsub <8 x float> %.spill.load611, %1246
  %.spill.load612 = load <8 x float>, ptr %.spill96, align 32
  %1254 = fsub <8 x float> %.spill.load612, %1246
  %.spill.load613 = load <8 x float>, ptr %.spill97, align 32
  %1255 = fsub <8 x float> %.spill.load613, %1246
  %.spill.load614 = load <8 x float>, ptr %.spill98, align 32
  %1256 = fsub <8 x float> %.spill.load614, %1246
  %.spill.load615 = load <8 x float>, ptr %.spill99, align 32
  %1257 = fsub <8 x float> %.spill.load615, %1246
  %.spill.load616 = load <8 x float>, ptr %.spill100, align 32
  %1258 = fsub <8 x float> %.spill.load616, %1246
  %.spill.load617 = load <8 x float>, ptr %.spill101, align 32
  %1259 = fsub <8 x float> %.spill.load617, %1246
  %.spill.load618 = load <8 x float>, ptr %.spill102, align 32
  %1260 = fsub <8 x float> %.spill.load618, %1246
  %.spill.load619 = load <8 x float>, ptr %.spill103, align 32
  %1261 = fsub <8 x float> %.spill.load619, %1246
  %.spill.load620 = load <8 x float>, ptr %.spill104, align 32
  %1262 = fsub <8 x float> %.spill.load620, %1246
  %.spill.load621 = load <8 x float>, ptr %.spill105, align 32
  %1263 = fsub <8 x float> %.spill.load621, %1246
  %.spill.load622 = load <8 x float>, ptr %.spill106, align 32
  %1264 = fsub <8 x float> %.spill.load622, %1246
  %.spill.load623 = load <8 x float>, ptr %.spill107, align 32
  %1265 = fsub <8 x float> %.spill.load623, %1246
  %.spill.load624 = load <8 x float>, ptr %.spill108, align 32
  %1266 = fsub <8 x float> %.spill.load624, %1246
  %.spill.load625 = load <8 x float>, ptr %.spill109, align 32
  %1267 = fsub <8 x float> %.spill.load625, %1246
  %.spill.load626 = load <8 x float>, ptr %.spill110, align 32
  %1268 = fsub <8 x float> %.spill.load626, %1246
  %1269 = select <8 x i1> %71, <8 x float> %1253, <8 x float> zeroinitializer
  %native.exp627 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1269)
  %1270 = select <8 x i1> %71, <8 x float> %1254, <8 x float> zeroinitializer
  %native.exp628 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1270)
  %1271 = select <8 x i1> %71, <8 x float> %1255, <8 x float> zeroinitializer
  %native.exp629 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1271)
  %1272 = select <8 x i1> %71, <8 x float> %1256, <8 x float> zeroinitializer
  %native.exp630 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1272)
  %1273 = select <8 x i1> %71, <8 x float> %1257, <8 x float> zeroinitializer
  %native.exp631 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1273)
  %1274 = select <8 x i1> %71, <8 x float> %1258, <8 x float> zeroinitializer
  %native.exp632 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1274)
  %1275 = select <8 x i1> %71, <8 x float> %1259, <8 x float> zeroinitializer
  %native.exp633 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1275)
  %1276 = select <8 x i1> %71, <8 x float> %1260, <8 x float> zeroinitializer
  %native.exp634 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1276)
  %1277 = select <8 x i1> %71, <8 x float> %1261, <8 x float> zeroinitializer
  %native.exp635 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1277)
  %1278 = select <8 x i1> %71, <8 x float> %1262, <8 x float> zeroinitializer
  %native.exp636 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1278)
  %1279 = select <8 x i1> %71, <8 x float> %1263, <8 x float> zeroinitializer
  %native.exp637 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1279)
  %1280 = select <8 x i1> %71, <8 x float> %1264, <8 x float> zeroinitializer
  %native.exp638 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1280)
  %1281 = select <8 x i1> %71, <8 x float> %1265, <8 x float> zeroinitializer
  %native.exp639 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1281)
  %1282 = select <8 x i1> %71, <8 x float> %1266, <8 x float> zeroinitializer
  %native.exp640 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1282)
  %1283 = select <8 x i1> %71, <8 x float> %1267, <8 x float> zeroinitializer
  %native.exp641 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1283)
  %1284 = select <8 x i1> %71, <8 x float> %1268, <8 x float> zeroinitializer
  %native.exp642 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1284)
  %.spill.load643 = load i1, ptr %.spill79, align 1
  %.splatinsert644 = insertelement <8 x i1> poison, i1 %.spill.load643, i64 0
  %.splat645 = shufflevector <8 x i1> %.splatinsert644, <8 x i1> poison, <8 x i32> zeroinitializer
  %1285 = select <8 x i1> %.splat645, <8 x float> %native.exp627, <8 x float> zeroinitializer
  %1286 = load <8 x float>, ptr %.spill116, align 32
  %1287 = select <8 x i1> %71, <8 x float> %1285, <8 x float> %1286
  store <8 x float> %1287, ptr %.spill116, align 32
  %.spill.load646 = load i1, ptr %.spill80, align 1
  %.splatinsert647 = insertelement <8 x i1> poison, i1 %.spill.load646, i64 0
  %.splat648 = shufflevector <8 x i1> %.splatinsert647, <8 x i1> poison, <8 x i32> zeroinitializer
  %1288 = select <8 x i1> %.splat648, <8 x float> %native.exp628, <8 x float> zeroinitializer
  %1289 = load <8 x float>, ptr %.spill117, align 32
  %1290 = select <8 x i1> %71, <8 x float> %1288, <8 x float> %1289
  store <8 x float> %1290, ptr %.spill117, align 32
  %.spill.load649 = load i1, ptr %.spill81, align 1
  %.splatinsert650 = insertelement <8 x i1> poison, i1 %.spill.load649, i64 0
  %.splat651 = shufflevector <8 x i1> %.splatinsert650, <8 x i1> poison, <8 x i32> zeroinitializer
  %1291 = select <8 x i1> %.splat651, <8 x float> %native.exp629, <8 x float> zeroinitializer
  %1292 = load <8 x float>, ptr %.spill118, align 32
  %1293 = select <8 x i1> %71, <8 x float> %1291, <8 x float> %1292
  store <8 x float> %1293, ptr %.spill118, align 32
  %.spill.load652 = load i1, ptr %.spill82, align 1
  %.splatinsert653 = insertelement <8 x i1> poison, i1 %.spill.load652, i64 0
  %.splat654 = shufflevector <8 x i1> %.splatinsert653, <8 x i1> poison, <8 x i32> zeroinitializer
  %1294 = select <8 x i1> %.splat654, <8 x float> %native.exp630, <8 x float> zeroinitializer
  %1295 = load <8 x float>, ptr %.spill119, align 32
  %1296 = select <8 x i1> %71, <8 x float> %1294, <8 x float> %1295
  store <8 x float> %1296, ptr %.spill119, align 32
  %.spill.load655 = load i1, ptr %.spill83, align 1
  %.splatinsert656 = insertelement <8 x i1> poison, i1 %.spill.load655, i64 0
  %.splat657 = shufflevector <8 x i1> %.splatinsert656, <8 x i1> poison, <8 x i32> zeroinitializer
  %1297 = select <8 x i1> %.splat657, <8 x float> %native.exp631, <8 x float> zeroinitializer
  %1298 = load <8 x float>, ptr %.spill120, align 32
  %1299 = select <8 x i1> %71, <8 x float> %1297, <8 x float> %1298
  store <8 x float> %1299, ptr %.spill120, align 32
  %.spill.load658 = load i1, ptr %.spill84, align 1
  %.splatinsert659 = insertelement <8 x i1> poison, i1 %.spill.load658, i64 0
  %.splat660 = shufflevector <8 x i1> %.splatinsert659, <8 x i1> poison, <8 x i32> zeroinitializer
  %1300 = select <8 x i1> %.splat660, <8 x float> %native.exp632, <8 x float> zeroinitializer
  %1301 = load <8 x float>, ptr %.spill121, align 32
  %1302 = select <8 x i1> %71, <8 x float> %1300, <8 x float> %1301
  store <8 x float> %1302, ptr %.spill121, align 32
  %.spill.load661 = load i1, ptr %.spill85, align 1
  %.splatinsert662 = insertelement <8 x i1> poison, i1 %.spill.load661, i64 0
  %.splat663 = shufflevector <8 x i1> %.splatinsert662, <8 x i1> poison, <8 x i32> zeroinitializer
  %1303 = select <8 x i1> %.splat663, <8 x float> %native.exp633, <8 x float> zeroinitializer
  %1304 = load <8 x float>, ptr %.spill122, align 32
  %1305 = select <8 x i1> %71, <8 x float> %1303, <8 x float> %1304
  store <8 x float> %1305, ptr %.spill122, align 32
  %.spill.load664 = load i1, ptr %.spill86, align 1
  %.splatinsert665 = insertelement <8 x i1> poison, i1 %.spill.load664, i64 0
  %.splat666 = shufflevector <8 x i1> %.splatinsert665, <8 x i1> poison, <8 x i32> zeroinitializer
  %1306 = select <8 x i1> %.splat666, <8 x float> %native.exp634, <8 x float> zeroinitializer
  %1307 = load <8 x float>, ptr %.spill123, align 32
  %1308 = select <8 x i1> %71, <8 x float> %1306, <8 x float> %1307
  store <8 x float> %1308, ptr %.spill123, align 32
  %.spill.load667 = load i1, ptr %.spill87, align 1
  %.splatinsert668 = insertelement <8 x i1> poison, i1 %.spill.load667, i64 0
  %.splat669 = shufflevector <8 x i1> %.splatinsert668, <8 x i1> poison, <8 x i32> zeroinitializer
  %1309 = select <8 x i1> %.splat669, <8 x float> %native.exp635, <8 x float> zeroinitializer
  %1310 = load <8 x float>, ptr %.spill124, align 32
  %1311 = select <8 x i1> %71, <8 x float> %1309, <8 x float> %1310
  store <8 x float> %1311, ptr %.spill124, align 32
  %.spill.load670 = load i1, ptr %.spill88, align 1
  %.splatinsert671 = insertelement <8 x i1> poison, i1 %.spill.load670, i64 0
  %.splat672 = shufflevector <8 x i1> %.splatinsert671, <8 x i1> poison, <8 x i32> zeroinitializer
  %1312 = select <8 x i1> %.splat672, <8 x float> %native.exp636, <8 x float> zeroinitializer
  %1313 = load <8 x float>, ptr %.spill125, align 32
  %1314 = select <8 x i1> %71, <8 x float> %1312, <8 x float> %1313
  store <8 x float> %1314, ptr %.spill125, align 32
  %.spill.load673 = load i1, ptr %.spill89, align 1
  %.splatinsert674 = insertelement <8 x i1> poison, i1 %.spill.load673, i64 0
  %.splat675 = shufflevector <8 x i1> %.splatinsert674, <8 x i1> poison, <8 x i32> zeroinitializer
  %1315 = select <8 x i1> %.splat675, <8 x float> %native.exp637, <8 x float> zeroinitializer
  %1316 = load <8 x float>, ptr %.spill126, align 32
  %1317 = select <8 x i1> %71, <8 x float> %1315, <8 x float> %1316
  store <8 x float> %1317, ptr %.spill126, align 32
  %.spill.load676 = load i1, ptr %.spill90, align 1
  %.splatinsert677 = insertelement <8 x i1> poison, i1 %.spill.load676, i64 0
  %.splat678 = shufflevector <8 x i1> %.splatinsert677, <8 x i1> poison, <8 x i32> zeroinitializer
  %1318 = select <8 x i1> %.splat678, <8 x float> %native.exp638, <8 x float> zeroinitializer
  %1319 = load <8 x float>, ptr %.spill127, align 32
  %1320 = select <8 x i1> %71, <8 x float> %1318, <8 x float> %1319
  store <8 x float> %1320, ptr %.spill127, align 32
  %.spill.load679 = load i1, ptr %.spill91, align 1
  %.splatinsert680 = insertelement <8 x i1> poison, i1 %.spill.load679, i64 0
  %.splat681 = shufflevector <8 x i1> %.splatinsert680, <8 x i1> poison, <8 x i32> zeroinitializer
  %1321 = select <8 x i1> %.splat681, <8 x float> %native.exp639, <8 x float> zeroinitializer
  %1322 = load <8 x float>, ptr %.spill128, align 32
  %1323 = select <8 x i1> %71, <8 x float> %1321, <8 x float> %1322
  store <8 x float> %1323, ptr %.spill128, align 32
  %.spill.load682 = load i1, ptr %.spill92, align 1
  %.splatinsert683 = insertelement <8 x i1> poison, i1 %.spill.load682, i64 0
  %.splat684 = shufflevector <8 x i1> %.splatinsert683, <8 x i1> poison, <8 x i32> zeroinitializer
  %1324 = select <8 x i1> %.splat684, <8 x float> %native.exp640, <8 x float> zeroinitializer
  %1325 = load <8 x float>, ptr %.spill129, align 32
  %1326 = select <8 x i1> %71, <8 x float> %1324, <8 x float> %1325
  store <8 x float> %1326, ptr %.spill129, align 32
  %.spill.load685 = load i1, ptr %.spill93, align 1
  %.splatinsert686 = insertelement <8 x i1> poison, i1 %.spill.load685, i64 0
  %.splat687 = shufflevector <8 x i1> %.splatinsert686, <8 x i1> poison, <8 x i32> zeroinitializer
  %1327 = select <8 x i1> %.splat687, <8 x float> %native.exp641, <8 x float> zeroinitializer
  %1328 = load <8 x float>, ptr %.spill130, align 32
  %1329 = select <8 x i1> %71, <8 x float> %1327, <8 x float> %1328
  store <8 x float> %1329, ptr %.spill130, align 32
  %.spill.load688 = load i1, ptr %.spill94, align 1
  %.splatinsert689 = insertelement <8 x i1> poison, i1 %.spill.load688, i64 0
  %.splat690 = shufflevector <8 x i1> %.splatinsert689, <8 x i1> poison, <8 x i32> zeroinitializer
  %1330 = select <8 x i1> %.splat690, <8 x float> %native.exp642, <8 x float> zeroinitializer
  %1331 = load <8 x float>, ptr %.spill131, align 32
  %1332 = select <8 x i1> %71, <8 x float> %1330, <8 x float> %1331
  store <8 x float> %1332, ptr %.spill131, align 32
  %1333 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %1334 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1335 = extractvalue { <8 x ptr>, <8 x i64> } %1333, 0
  %1336 = select <8 x i1> %71, <8 x ptr> %1334, <8 x ptr> %1335
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1338 = extractvalue { <8 x ptr>, <8 x i64> } %1333, 1
  %1339 = select <8 x i1> %71, <8 x i64> %1337, <8 x i64> %1338
  %1340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1336, 0
  %1341 = insertvalue { <8 x ptr>, <8 x i64> } %1340, <8 x i64> %1339, 1
  store { <8 x ptr>, <8 x i64> } %1341, ptr %tile_snapshot.spill132, align 64
  %1342 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1343 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1344 = add <8 x i64> %1343, zeroinitializer
  %1345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1342, 0
  %1346 = insertvalue { <8 x ptr>, <8 x i64> } %1345, <8 x i64> %1344, 1
  %1347 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1348 = extractvalue { <8 x ptr>, <8 x i64> } %1346, 1
  %1349 = extractelement <8 x ptr> %1347, i32 0
  %1350 = extractelement <8 x i64> %1348, i32 0
  %1351 = sub i64 %1350, 0
  %1352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1353 = select i1 %1352, i64 %1351, i64 0
  %private.contiguous.address691 = getelementptr i8, ptr %1349, i64 %1353
  %private.contiguous.preserve692 = load <8 x float>, ptr %private.contiguous.address691, align 4
  %1354 = select <8 x i1> %71, <8 x float> %1285, <8 x float> %private.contiguous.preserve692
  store <8 x float> %1354, ptr %private.contiguous.address691, align 4
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1356 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1357 = add <8 x i64> %1356, splat (i64 32)
  %1358 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1355, 0
  %1359 = insertvalue { <8 x ptr>, <8 x i64> } %1358, <8 x i64> %1357, 1
  %1360 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1361 = extractvalue { <8 x ptr>, <8 x i64> } %1359, 1
  %1362 = extractelement <8 x ptr> %1360, i32 0
  %1363 = extractelement <8 x i64> %1361, i32 0
  %1364 = sub i64 %1363, 0
  %1365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1366 = select i1 %1365, i64 %1364, i64 0
  %private.contiguous.address693 = getelementptr i8, ptr %1362, i64 %1366
  %private.contiguous.preserve694 = load <8 x float>, ptr %private.contiguous.address693, align 4
  %1367 = select <8 x i1> %71, <8 x float> %1288, <8 x float> %private.contiguous.preserve694
  store <8 x float> %1367, ptr %private.contiguous.address693, align 4
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1370 = add <8 x i64> %1369, splat (i64 64)
  %1371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1368, 0
  %1372 = insertvalue { <8 x ptr>, <8 x i64> } %1371, <8 x i64> %1370, 1
  %1373 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %1372, 1
  %1375 = extractelement <8 x ptr> %1373, i32 0
  %1376 = extractelement <8 x i64> %1374, i32 0
  %1377 = sub i64 %1376, 0
  %1378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1379 = select i1 %1378, i64 %1377, i64 0
  %private.contiguous.address695 = getelementptr i8, ptr %1375, i64 %1379
  %private.contiguous.preserve696 = load <8 x float>, ptr %private.contiguous.address695, align 4
  %1380 = select <8 x i1> %71, <8 x float> %1291, <8 x float> %private.contiguous.preserve696
  store <8 x float> %1380, ptr %private.contiguous.address695, align 4
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1382 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1383 = add <8 x i64> %1382, splat (i64 96)
  %1384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1381, 0
  %1385 = insertvalue { <8 x ptr>, <8 x i64> } %1384, <8 x i64> %1383, 1
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1387 = extractvalue { <8 x ptr>, <8 x i64> } %1385, 1
  %1388 = extractelement <8 x ptr> %1386, i32 0
  %1389 = extractelement <8 x i64> %1387, i32 0
  %1390 = sub i64 %1389, 0
  %1391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1392 = select i1 %1391, i64 %1390, i64 0
  %private.contiguous.address697 = getelementptr i8, ptr %1388, i64 %1392
  %private.contiguous.preserve698 = load <8 x float>, ptr %private.contiguous.address697, align 4
  %1393 = select <8 x i1> %71, <8 x float> %1294, <8 x float> %private.contiguous.preserve698
  store <8 x float> %1393, ptr %private.contiguous.address697, align 4
  %1394 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1395 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1396 = add <8 x i64> %1395, splat (i64 128)
  %1397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1394, 0
  %1398 = insertvalue { <8 x ptr>, <8 x i64> } %1397, <8 x i64> %1396, 1
  %1399 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1400 = extractvalue { <8 x ptr>, <8 x i64> } %1398, 1
  %1401 = extractelement <8 x ptr> %1399, i32 0
  %1402 = extractelement <8 x i64> %1400, i32 0
  %1403 = sub i64 %1402, 0
  %1404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1405 = select i1 %1404, i64 %1403, i64 0
  %private.contiguous.address699 = getelementptr i8, ptr %1401, i64 %1405
  %private.contiguous.preserve700 = load <8 x float>, ptr %private.contiguous.address699, align 4
  %1406 = select <8 x i1> %71, <8 x float> %1297, <8 x float> %private.contiguous.preserve700
  store <8 x float> %1406, ptr %private.contiguous.address699, align 4
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1408 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1409 = add <8 x i64> %1408, splat (i64 160)
  %1410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1407, 0
  %1411 = insertvalue { <8 x ptr>, <8 x i64> } %1410, <8 x i64> %1409, 1
  %1412 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1413 = extractvalue { <8 x ptr>, <8 x i64> } %1411, 1
  %1414 = extractelement <8 x ptr> %1412, i32 0
  %1415 = extractelement <8 x i64> %1413, i32 0
  %1416 = sub i64 %1415, 0
  %1417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1418 = select i1 %1417, i64 %1416, i64 0
  %private.contiguous.address701 = getelementptr i8, ptr %1414, i64 %1418
  %private.contiguous.preserve702 = load <8 x float>, ptr %private.contiguous.address701, align 4
  %1419 = select <8 x i1> %71, <8 x float> %1300, <8 x float> %private.contiguous.preserve702
  store <8 x float> %1419, ptr %private.contiguous.address701, align 4
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1421 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1422 = add <8 x i64> %1421, splat (i64 192)
  %1423 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1420, 0
  %1424 = insertvalue { <8 x ptr>, <8 x i64> } %1423, <8 x i64> %1422, 1
  %1425 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1426 = extractvalue { <8 x ptr>, <8 x i64> } %1424, 1
  %1427 = extractelement <8 x ptr> %1425, i32 0
  %1428 = extractelement <8 x i64> %1426, i32 0
  %1429 = sub i64 %1428, 0
  %1430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1431 = select i1 %1430, i64 %1429, i64 0
  %private.contiguous.address703 = getelementptr i8, ptr %1427, i64 %1431
  %private.contiguous.preserve704 = load <8 x float>, ptr %private.contiguous.address703, align 4
  %1432 = select <8 x i1> %71, <8 x float> %1303, <8 x float> %private.contiguous.preserve704
  store <8 x float> %1432, ptr %private.contiguous.address703, align 4
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1435 = add <8 x i64> %1434, splat (i64 224)
  %1436 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1433, 0
  %1437 = insertvalue { <8 x ptr>, <8 x i64> } %1436, <8 x i64> %1435, 1
  %1438 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %1437, 1
  %1440 = extractelement <8 x ptr> %1438, i32 0
  %1441 = extractelement <8 x i64> %1439, i32 0
  %1442 = sub i64 %1441, 0
  %1443 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1444 = select i1 %1443, i64 %1442, i64 0
  %private.contiguous.address705 = getelementptr i8, ptr %1440, i64 %1444
  %private.contiguous.preserve706 = load <8 x float>, ptr %private.contiguous.address705, align 4
  %1445 = select <8 x i1> %71, <8 x float> %1306, <8 x float> %private.contiguous.preserve706
  store <8 x float> %1445, ptr %private.contiguous.address705, align 4
  %1446 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1447 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1448 = add <8 x i64> %1447, splat (i64 256)
  %1449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1446, 0
  %1450 = insertvalue { <8 x ptr>, <8 x i64> } %1449, <8 x i64> %1448, 1
  %1451 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1452 = extractvalue { <8 x ptr>, <8 x i64> } %1450, 1
  %1453 = extractelement <8 x ptr> %1451, i32 0
  %1454 = extractelement <8 x i64> %1452, i32 0
  %1455 = sub i64 %1454, 0
  %1456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1457 = select i1 %1456, i64 %1455, i64 0
  %private.contiguous.address707 = getelementptr i8, ptr %1453, i64 %1457
  %private.contiguous.preserve708 = load <8 x float>, ptr %private.contiguous.address707, align 4
  %1458 = select <8 x i1> %71, <8 x float> %1309, <8 x float> %private.contiguous.preserve708
  store <8 x float> %1458, ptr %private.contiguous.address707, align 4
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1460 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1461 = add <8 x i64> %1460, splat (i64 288)
  %1462 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1459, 0
  %1463 = insertvalue { <8 x ptr>, <8 x i64> } %1462, <8 x i64> %1461, 1
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1465 = extractvalue { <8 x ptr>, <8 x i64> } %1463, 1
  %1466 = extractelement <8 x ptr> %1464, i32 0
  %1467 = extractelement <8 x i64> %1465, i32 0
  %1468 = sub i64 %1467, 0
  %1469 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1470 = select i1 %1469, i64 %1468, i64 0
  %private.contiguous.address709 = getelementptr i8, ptr %1466, i64 %1470
  %private.contiguous.preserve710 = load <8 x float>, ptr %private.contiguous.address709, align 4
  %1471 = select <8 x i1> %71, <8 x float> %1312, <8 x float> %private.contiguous.preserve710
  store <8 x float> %1471, ptr %private.contiguous.address709, align 4
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1473 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1474 = add <8 x i64> %1473, splat (i64 320)
  %1475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1472, 0
  %1476 = insertvalue { <8 x ptr>, <8 x i64> } %1475, <8 x i64> %1474, 1
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1478 = extractvalue { <8 x ptr>, <8 x i64> } %1476, 1
  %1479 = extractelement <8 x ptr> %1477, i32 0
  %1480 = extractelement <8 x i64> %1478, i32 0
  %1481 = sub i64 %1480, 0
  %1482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1483 = select i1 %1482, i64 %1481, i64 0
  %private.contiguous.address711 = getelementptr i8, ptr %1479, i64 %1483
  %private.contiguous.preserve712 = load <8 x float>, ptr %private.contiguous.address711, align 4
  %1484 = select <8 x i1> %71, <8 x float> %1315, <8 x float> %private.contiguous.preserve712
  store <8 x float> %1484, ptr %private.contiguous.address711, align 4
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1487 = add <8 x i64> %1486, splat (i64 352)
  %1488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1485, 0
  %1489 = insertvalue { <8 x ptr>, <8 x i64> } %1488, <8 x i64> %1487, 1
  %1490 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1491 = extractvalue { <8 x ptr>, <8 x i64> } %1489, 1
  %1492 = extractelement <8 x ptr> %1490, i32 0
  %1493 = extractelement <8 x i64> %1491, i32 0
  %1494 = sub i64 %1493, 0
  %1495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1496 = select i1 %1495, i64 %1494, i64 0
  %private.contiguous.address713 = getelementptr i8, ptr %1492, i64 %1496
  %private.contiguous.preserve714 = load <8 x float>, ptr %private.contiguous.address713, align 4
  %1497 = select <8 x i1> %71, <8 x float> %1318, <8 x float> %private.contiguous.preserve714
  store <8 x float> %1497, ptr %private.contiguous.address713, align 4
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1499 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1500 = add <8 x i64> %1499, splat (i64 384)
  %1501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1498, 0
  %1502 = insertvalue { <8 x ptr>, <8 x i64> } %1501, <8 x i64> %1500, 1
  %1503 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1504 = extractvalue { <8 x ptr>, <8 x i64> } %1502, 1
  %1505 = extractelement <8 x ptr> %1503, i32 0
  %1506 = extractelement <8 x i64> %1504, i32 0
  %1507 = sub i64 %1506, 0
  %1508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1509 = select i1 %1508, i64 %1507, i64 0
  %private.contiguous.address715 = getelementptr i8, ptr %1505, i64 %1509
  %private.contiguous.preserve716 = load <8 x float>, ptr %private.contiguous.address715, align 4
  %1510 = select <8 x i1> %71, <8 x float> %1321, <8 x float> %private.contiguous.preserve716
  store <8 x float> %1510, ptr %private.contiguous.address715, align 4
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1512 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1513 = add <8 x i64> %1512, splat (i64 416)
  %1514 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1511, 0
  %1515 = insertvalue { <8 x ptr>, <8 x i64> } %1514, <8 x i64> %1513, 1
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %1515, 1
  %1518 = extractelement <8 x ptr> %1516, i32 0
  %1519 = extractelement <8 x i64> %1517, i32 0
  %1520 = sub i64 %1519, 0
  %1521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1522 = select i1 %1521, i64 %1520, i64 0
  %private.contiguous.address717 = getelementptr i8, ptr %1518, i64 %1522
  %private.contiguous.preserve718 = load <8 x float>, ptr %private.contiguous.address717, align 4
  %1523 = select <8 x i1> %71, <8 x float> %1324, <8 x float> %private.contiguous.preserve718
  store <8 x float> %1523, ptr %private.contiguous.address717, align 4
  %1524 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1525 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1526 = add <8 x i64> %1525, splat (i64 448)
  %1527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1524, 0
  %1528 = insertvalue { <8 x ptr>, <8 x i64> } %1527, <8 x i64> %1526, 1
  %1529 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1530 = extractvalue { <8 x ptr>, <8 x i64> } %1528, 1
  %1531 = extractelement <8 x ptr> %1529, i32 0
  %1532 = extractelement <8 x i64> %1530, i32 0
  %1533 = sub i64 %1532, 0
  %1534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1535 = select i1 %1534, i64 %1533, i64 0
  %private.contiguous.address719 = getelementptr i8, ptr %1531, i64 %1535
  %private.contiguous.preserve720 = load <8 x float>, ptr %private.contiguous.address719, align 4
  %1536 = select <8 x i1> %71, <8 x float> %1327, <8 x float> %private.contiguous.preserve720
  store <8 x float> %1536, ptr %private.contiguous.address719, align 4
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1539 = add <8 x i64> %1538, splat (i64 480)
  %1540 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1537, 0
  %1541 = insertvalue { <8 x ptr>, <8 x i64> } %1540, <8 x i64> %1539, 1
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1543 = extractvalue { <8 x ptr>, <8 x i64> } %1541, 1
  %1544 = extractelement <8 x ptr> %1542, i32 0
  %1545 = extractelement <8 x i64> %1543, i32 0
  %1546 = sub i64 %1545, 0
  %1547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1548 = select i1 %1547, i64 %1546, i64 0
  %private.contiguous.address721 = getelementptr i8, ptr %1544, i64 %1548
  %private.contiguous.preserve722 = load <8 x float>, ptr %private.contiguous.address721, align 4
  %1549 = select <8 x i1> %71, <8 x float> %1330, <8 x float> %private.contiguous.preserve722
  store <8 x float> %1549, ptr %private.contiguous.address721, align 4
  %.state723 = load <8 x float>, ptr %.slot36, align 32
  %1550 = fmul <8 x float> %.state723, %native.exp
  %1551 = load <8 x float>, ptr %.spill133, align 32
  %1552 = select <8 x i1> %71, <8 x float> %1550, <8 x float> %1551
  store <8 x float> %1552, ptr %.spill133, align 32
  store i64 0, ptr %.slot134, align 4
  %1553 = load <8 x float>, ptr %.slot135, align 32
  %1554 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1553
  store <8 x float> %1554, ptr %.slot135, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state724 = load i64, ptr %.slot134, align 4
  %1555 = icmp slt i64 %.state724, 16
  br i1 %1555, label %direct.true725, label %direct.false726

direct.schedule.71:                               ; preds = %direct.true725
  %.state727 = load i64, ptr %.slot134, align 4
  %1556 = sdiv i64 %.state727, 1
  %.spill.load728 = load i64, ptr %.spill78, align 4
  %1557 = mul i64 %.spill.load728, 1
  %1558 = add i64 %1557, 0
  %1559 = mul i64 %1558, 1
  %1560 = add i64 %1559, 0
  %1561 = mul i64 %1560, 16
  %1562 = add i64 %1561, %1556
  %tile_snapshot.spill.load729 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load729, 0
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load729, 1
  %.splatinsert730 = insertelement <8 x i64> poison, i64 %1562, i64 0
  %.splat731 = shufflevector <8 x i64> %.splatinsert730, <8 x i64> poison, <8 x i32> zeroinitializer
  %1565 = mul <8 x i64> %.splat731, splat (i64 32)
  %1566 = add <8 x i64> %1564, %1565
  %1567 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1563, 0
  %1568 = insertvalue { <8 x ptr>, <8 x i64> } %1567, <8 x i64> %1566, 1
  %1569 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1570 = extractvalue { <8 x ptr>, <8 x i64> } %1568, 1
  %1571 = extractelement <8 x ptr> %1569, i32 0
  %1572 = extractelement <8 x i64> %1570, i32 0
  %1573 = sub i64 %1572, 0
  %1574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1575 = select i1 %1574, i64 %1573, i64 0
  %private.contiguous.address732 = getelementptr i8, ptr %1571, i64 %1575
  %private.contiguous.load733 = load <8 x float>, ptr %private.contiguous.address732, align 4
  %1576 = select <8 x i1> %71, <8 x float> %private.contiguous.load733, <8 x float> zeroinitializer
  %.state734 = load <8 x float>, ptr %.slot135, align 32
  %1577 = fadd <8 x float> %.state734, %1576
  %.state735 = load i64, ptr %.slot134, align 4
  %1578 = add i64 %.state735, 1
  store i64 %1578, ptr %.slot134, align 4
  %1579 = load <8 x float>, ptr %.slot135, align 32
  %1580 = select <8 x i1> %71, <8 x float> %1577, <8 x float> %1579
  store <8 x float> %1580, ptr %.slot135, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false726
  %.spill.load736 = load <8 x float>, ptr %.spill133, align 32
  %.state737 = load <8 x float>, ptr %.slot135, align 32
  %1581 = fadd <8 x float> %.spill.load736, %.state737
  %1582 = load <8 x float>, ptr %.spill136, align 32
  %1583 = select <8 x i1> %71, <8 x float> %1581, <8 x float> %1582
  store <8 x float> %1583, ptr %.spill136, align 32
  %1584 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill137, align 64
  %1585 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1586 = extractvalue { <8 x ptr>, <8 x i64> } %1584, 0
  %1587 = select <8 x i1> %71, <8 x ptr> %1585, <8 x ptr> %1586
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %1584, 1
  %1590 = select <8 x i1> %71, <8 x i64> %1588, <8 x i64> %1589
  %1591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1587, 0
  %1592 = insertvalue { <8 x ptr>, <8 x i64> } %1591, <8 x i64> %1590, 1
  store { <8 x ptr>, <8 x i64> } %1592, ptr %tile_snapshot.spill137, align 64
  store i64 0, ptr %.slot138, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.74, %direct.schedule.72
  %.state738 = load i64, ptr %.slot138, align 4
  %1593 = icmp slt i64 %.state738, 48
  br i1 %1593, label %direct.true739, label %direct.false740

direct.schedule.74:                               ; preds = %direct.true739
  %.state741 = load i64, ptr %.slot138, align 4
  %1594 = mul i64 %.state741, 2
  %1595 = add i64 0, %1594
  %1596 = add i64 %1595, 0
  %1597 = add i64 0, %1596
  %tile_snapshot.spill.load742 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load742, 0
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load742, 1
  %.splatinsert743 = insertelement <8 x i64> poison, i64 %1597, i64 0
  %.splat744 = shufflevector <8 x i64> %.splatinsert743, <8 x i64> poison, <8 x i32> zeroinitializer
  %1600 = mul <8 x i64> %.splat744, splat (i64 32)
  %1601 = add <8 x i64> %1599, %1600
  %1602 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1598, 0
  %1603 = insertvalue { <8 x ptr>, <8 x i64> } %1602, <8 x i64> %1601, 1
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %1603, 1
  %1606 = extractelement <8 x ptr> %1604, i32 0
  %1607 = extractelement <8 x i64> %1605, i32 0
  %1608 = sub i64 %1607, 0
  %1609 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1610 = select i1 %1609, i64 %1608, i64 0
  %private.contiguous.address745 = getelementptr i8, ptr %1606, i64 %1610
  %private.contiguous.load746 = load <8 x float>, ptr %private.contiguous.address745, align 4
  %1611 = select <8 x i1> %71, <8 x float> %private.contiguous.load746, <8 x float> zeroinitializer
  %.spill.load747 = load <8 x float>, ptr %.spill115, align 32
  %1612 = fmul <8 x float> %1611, %.spill.load747
  %1613 = add i64 %1595, 1
  %1614 = add i64 0, %1613
  %tile_snapshot.spill.load748 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %1615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load748, 0
  %1616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load748, 1
  %.splatinsert749 = insertelement <8 x i64> poison, i64 %1614, i64 0
  %.splat750 = shufflevector <8 x i64> %.splatinsert749, <8 x i64> poison, <8 x i32> zeroinitializer
  %1617 = mul <8 x i64> %.splat750, splat (i64 32)
  %1618 = add <8 x i64> %1616, %1617
  %1619 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1615, 0
  %1620 = insertvalue { <8 x ptr>, <8 x i64> } %1619, <8 x i64> %1618, 1
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1622 = extractvalue { <8 x ptr>, <8 x i64> } %1620, 1
  %1623 = extractelement <8 x ptr> %1621, i32 0
  %1624 = extractelement <8 x i64> %1622, i32 0
  %1625 = sub i64 %1624, 0
  %1626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1627 = select i1 %1626, i64 %1625, i64 0
  %private.contiguous.address751 = getelementptr i8, ptr %1623, i64 %1627
  %private.contiguous.load752 = load <8 x float>, ptr %private.contiguous.address751, align 4
  %1628 = select <8 x i1> %71, <8 x float> %private.contiguous.load752, <8 x float> zeroinitializer
  %.spill.load753 = load <8 x float>, ptr %.spill115, align 32
  %1629 = fmul <8 x float> %1628, %.spill.load753
  %tile_snapshot.spill.load754 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load754, 0
  %1631 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load754, 1
  %.splatinsert755 = insertelement <8 x i64> poison, i64 %1597, i64 0
  %.splat756 = shufflevector <8 x i64> %.splatinsert755, <8 x i64> poison, <8 x i32> zeroinitializer
  %1632 = mul <8 x i64> %.splat756, splat (i64 32)
  %1633 = add <8 x i64> %1631, %1632
  %1634 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1630, 0
  %1635 = insertvalue { <8 x ptr>, <8 x i64> } %1634, <8 x i64> %1633, 1
  %1636 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1637 = extractvalue { <8 x ptr>, <8 x i64> } %1635, 1
  %1638 = extractelement <8 x ptr> %1636, i32 0
  %1639 = extractelement <8 x i64> %1637, i32 0
  %1640 = sub i64 %1639, 0
  %1641 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1642 = select i1 %1641, i64 %1640, i64 0
  %private.contiguous.address757 = getelementptr i8, ptr %1638, i64 %1642
  %private.contiguous.load758 = load <8 x float>, ptr %private.contiguous.address757, align 4
  %1643 = select <8 x i1> %71, <8 x float> %private.contiguous.load758, <8 x float> zeroinitializer
  %.spill.load759 = load <8 x float>, ptr %.spill116, align 32
  %1644 = fmul <8 x float> %.spill.load759, %1643
  %1645 = fadd <8 x float> %1612, %1644
  %tile_snapshot.spill.load760 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load760, 0
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load760, 1
  %.splatinsert761 = insertelement <8 x i64> poison, i64 %1614, i64 0
  %.splat762 = shufflevector <8 x i64> %.splatinsert761, <8 x i64> poison, <8 x i32> zeroinitializer
  %1648 = mul <8 x i64> %.splat762, splat (i64 32)
  %1649 = add <8 x i64> %1647, %1648
  %1650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1646, 0
  %1651 = insertvalue { <8 x ptr>, <8 x i64> } %1650, <8 x i64> %1649, 1
  %1652 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1653 = extractvalue { <8 x ptr>, <8 x i64> } %1651, 1
  %1654 = extractelement <8 x ptr> %1652, i32 0
  %1655 = extractelement <8 x i64> %1653, i32 0
  %1656 = sub i64 %1655, 0
  %1657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1658 = select i1 %1657, i64 %1656, i64 0
  %private.contiguous.address763 = getelementptr i8, ptr %1654, i64 %1658
  %private.contiguous.load764 = load <8 x float>, ptr %private.contiguous.address763, align 4
  %1659 = select <8 x i1> %71, <8 x float> %private.contiguous.load764, <8 x float> zeroinitializer
  %.spill.load765 = load <8 x float>, ptr %.spill116, align 32
  %1660 = fmul <8 x float> %.spill.load765, %1659
  %1661 = fadd <8 x float> %1629, %1660
  %1662 = add i64 96, %1596
  %tile_snapshot.spill.load766 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load766, 0
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load766, 1
  %.splatinsert767 = insertelement <8 x i64> poison, i64 %1662, i64 0
  %.splat768 = shufflevector <8 x i64> %.splatinsert767, <8 x i64> poison, <8 x i32> zeroinitializer
  %1665 = mul <8 x i64> %.splat768, splat (i64 32)
  %1666 = add <8 x i64> %1664, %1665
  %1667 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1663, 0
  %1668 = insertvalue { <8 x ptr>, <8 x i64> } %1667, <8 x i64> %1666, 1
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1670 = extractvalue { <8 x ptr>, <8 x i64> } %1668, 1
  %1671 = extractelement <8 x ptr> %1669, i32 0
  %1672 = extractelement <8 x i64> %1670, i32 0
  %1673 = sub i64 %1672, 0
  %1674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1675 = select i1 %1674, i64 %1673, i64 0
  %private.contiguous.address769 = getelementptr i8, ptr %1671, i64 %1675
  %private.contiguous.load770 = load <8 x float>, ptr %private.contiguous.address769, align 4
  %1676 = select <8 x i1> %71, <8 x float> %private.contiguous.load770, <8 x float> zeroinitializer
  %.spill.load771 = load <8 x float>, ptr %.spill117, align 32
  %1677 = fmul <8 x float> %.spill.load771, %1676
  %1678 = fadd <8 x float> %1645, %1677
  %1679 = add i64 96, %1613
  %tile_snapshot.spill.load772 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1680 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load772, 0
  %1681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load772, 1
  %.splatinsert773 = insertelement <8 x i64> poison, i64 %1679, i64 0
  %.splat774 = shufflevector <8 x i64> %.splatinsert773, <8 x i64> poison, <8 x i32> zeroinitializer
  %1682 = mul <8 x i64> %.splat774, splat (i64 32)
  %1683 = add <8 x i64> %1681, %1682
  %1684 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1680, 0
  %1685 = insertvalue { <8 x ptr>, <8 x i64> } %1684, <8 x i64> %1683, 1
  %1686 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %1685, 1
  %1688 = extractelement <8 x ptr> %1686, i32 0
  %1689 = extractelement <8 x i64> %1687, i32 0
  %1690 = sub i64 %1689, 0
  %1691 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1692 = select i1 %1691, i64 %1690, i64 0
  %private.contiguous.address775 = getelementptr i8, ptr %1688, i64 %1692
  %private.contiguous.load776 = load <8 x float>, ptr %private.contiguous.address775, align 4
  %1693 = select <8 x i1> %71, <8 x float> %private.contiguous.load776, <8 x float> zeroinitializer
  %.spill.load777 = load <8 x float>, ptr %.spill117, align 32
  %1694 = fmul <8 x float> %.spill.load777, %1693
  %1695 = fadd <8 x float> %1661, %1694
  %1696 = add i64 192, %1596
  %tile_snapshot.spill.load778 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1697 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 0
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load778, 1
  %.splatinsert779 = insertelement <8 x i64> poison, i64 %1696, i64 0
  %.splat780 = shufflevector <8 x i64> %.splatinsert779, <8 x i64> poison, <8 x i32> zeroinitializer
  %1699 = mul <8 x i64> %.splat780, splat (i64 32)
  %1700 = add <8 x i64> %1698, %1699
  %1701 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1697, 0
  %1702 = insertvalue { <8 x ptr>, <8 x i64> } %1701, <8 x i64> %1700, 1
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1704 = extractvalue { <8 x ptr>, <8 x i64> } %1702, 1
  %1705 = extractelement <8 x ptr> %1703, i32 0
  %1706 = extractelement <8 x i64> %1704, i32 0
  %1707 = sub i64 %1706, 0
  %1708 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1709 = select i1 %1708, i64 %1707, i64 0
  %private.contiguous.address781 = getelementptr i8, ptr %1705, i64 %1709
  %private.contiguous.load782 = load <8 x float>, ptr %private.contiguous.address781, align 4
  %1710 = select <8 x i1> %71, <8 x float> %private.contiguous.load782, <8 x float> zeroinitializer
  %.spill.load783 = load <8 x float>, ptr %.spill118, align 32
  %1711 = fmul <8 x float> %.spill.load783, %1710
  %1712 = fadd <8 x float> %1678, %1711
  %1713 = add i64 192, %1613
  %tile_snapshot.spill.load784 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1714 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 0
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 1
  %.splatinsert785 = insertelement <8 x i64> poison, i64 %1713, i64 0
  %.splat786 = shufflevector <8 x i64> %.splatinsert785, <8 x i64> poison, <8 x i32> zeroinitializer
  %1716 = mul <8 x i64> %.splat786, splat (i64 32)
  %1717 = add <8 x i64> %1715, %1716
  %1718 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1714, 0
  %1719 = insertvalue { <8 x ptr>, <8 x i64> } %1718, <8 x i64> %1717, 1
  %1720 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1721 = extractvalue { <8 x ptr>, <8 x i64> } %1719, 1
  %1722 = extractelement <8 x ptr> %1720, i32 0
  %1723 = extractelement <8 x i64> %1721, i32 0
  %1724 = sub i64 %1723, 0
  %1725 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1726 = select i1 %1725, i64 %1724, i64 0
  %private.contiguous.address787 = getelementptr i8, ptr %1722, i64 %1726
  %private.contiguous.load788 = load <8 x float>, ptr %private.contiguous.address787, align 4
  %1727 = select <8 x i1> %71, <8 x float> %private.contiguous.load788, <8 x float> zeroinitializer
  %.spill.load789 = load <8 x float>, ptr %.spill118, align 32
  %1728 = fmul <8 x float> %.spill.load789, %1727
  %1729 = fadd <8 x float> %1695, %1728
  %1730 = add i64 288, %1596
  %tile_snapshot.spill.load790 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1731 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 0
  %1732 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load790, 1
  %.splatinsert791 = insertelement <8 x i64> poison, i64 %1730, i64 0
  %.splat792 = shufflevector <8 x i64> %.splatinsert791, <8 x i64> poison, <8 x i32> zeroinitializer
  %1733 = mul <8 x i64> %.splat792, splat (i64 32)
  %1734 = add <8 x i64> %1732, %1733
  %1735 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1731, 0
  %1736 = insertvalue { <8 x ptr>, <8 x i64> } %1735, <8 x i64> %1734, 1
  %1737 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1738 = extractvalue { <8 x ptr>, <8 x i64> } %1736, 1
  %1739 = extractelement <8 x ptr> %1737, i32 0
  %1740 = extractelement <8 x i64> %1738, i32 0
  %1741 = sub i64 %1740, 0
  %1742 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1743 = select i1 %1742, i64 %1741, i64 0
  %private.contiguous.address793 = getelementptr i8, ptr %1739, i64 %1743
  %private.contiguous.load794 = load <8 x float>, ptr %private.contiguous.address793, align 4
  %1744 = select <8 x i1> %71, <8 x float> %private.contiguous.load794, <8 x float> zeroinitializer
  %.spill.load795 = load <8 x float>, ptr %.spill119, align 32
  %1745 = fmul <8 x float> %.spill.load795, %1744
  %1746 = fadd <8 x float> %1712, %1745
  %1747 = add i64 288, %1613
  %tile_snapshot.spill.load796 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load796, 0
  %1749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load796, 1
  %.splatinsert797 = insertelement <8 x i64> poison, i64 %1747, i64 0
  %.splat798 = shufflevector <8 x i64> %.splatinsert797, <8 x i64> poison, <8 x i32> zeroinitializer
  %1750 = mul <8 x i64> %.splat798, splat (i64 32)
  %1751 = add <8 x i64> %1749, %1750
  %1752 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1748, 0
  %1753 = insertvalue { <8 x ptr>, <8 x i64> } %1752, <8 x i64> %1751, 1
  %1754 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1755 = extractvalue { <8 x ptr>, <8 x i64> } %1753, 1
  %1756 = extractelement <8 x ptr> %1754, i32 0
  %1757 = extractelement <8 x i64> %1755, i32 0
  %1758 = sub i64 %1757, 0
  %1759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1760 = select i1 %1759, i64 %1758, i64 0
  %private.contiguous.address799 = getelementptr i8, ptr %1756, i64 %1760
  %private.contiguous.load800 = load <8 x float>, ptr %private.contiguous.address799, align 4
  %1761 = select <8 x i1> %71, <8 x float> %private.contiguous.load800, <8 x float> zeroinitializer
  %.spill.load801 = load <8 x float>, ptr %.spill119, align 32
  %1762 = fmul <8 x float> %.spill.load801, %1761
  %1763 = fadd <8 x float> %1729, %1762
  %1764 = add i64 384, %1596
  %tile_snapshot.spill.load802 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1765 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load802, 0
  %1766 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load802, 1
  %.splatinsert803 = insertelement <8 x i64> poison, i64 %1764, i64 0
  %.splat804 = shufflevector <8 x i64> %.splatinsert803, <8 x i64> poison, <8 x i32> zeroinitializer
  %1767 = mul <8 x i64> %.splat804, splat (i64 32)
  %1768 = add <8 x i64> %1766, %1767
  %1769 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1765, 0
  %1770 = insertvalue { <8 x ptr>, <8 x i64> } %1769, <8 x i64> %1768, 1
  %1771 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1772 = extractvalue { <8 x ptr>, <8 x i64> } %1770, 1
  %1773 = extractelement <8 x ptr> %1771, i32 0
  %1774 = extractelement <8 x i64> %1772, i32 0
  %1775 = sub i64 %1774, 0
  %1776 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1777 = select i1 %1776, i64 %1775, i64 0
  %private.contiguous.address805 = getelementptr i8, ptr %1773, i64 %1777
  %private.contiguous.load806 = load <8 x float>, ptr %private.contiguous.address805, align 4
  %1778 = select <8 x i1> %71, <8 x float> %private.contiguous.load806, <8 x float> zeroinitializer
  %.spill.load807 = load <8 x float>, ptr %.spill120, align 32
  %1779 = fmul <8 x float> %.spill.load807, %1778
  %1780 = fadd <8 x float> %1746, %1779
  %1781 = add i64 384, %1613
  %tile_snapshot.spill.load808 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1782 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load808, 0
  %1783 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load808, 1
  %.splatinsert809 = insertelement <8 x i64> poison, i64 %1781, i64 0
  %.splat810 = shufflevector <8 x i64> %.splatinsert809, <8 x i64> poison, <8 x i32> zeroinitializer
  %1784 = mul <8 x i64> %.splat810, splat (i64 32)
  %1785 = add <8 x i64> %1783, %1784
  %1786 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1782, 0
  %1787 = insertvalue { <8 x ptr>, <8 x i64> } %1786, <8 x i64> %1785, 1
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1789 = extractvalue { <8 x ptr>, <8 x i64> } %1787, 1
  %1790 = extractelement <8 x ptr> %1788, i32 0
  %1791 = extractelement <8 x i64> %1789, i32 0
  %1792 = sub i64 %1791, 0
  %1793 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1794 = select i1 %1793, i64 %1792, i64 0
  %private.contiguous.address811 = getelementptr i8, ptr %1790, i64 %1794
  %private.contiguous.load812 = load <8 x float>, ptr %private.contiguous.address811, align 4
  %1795 = select <8 x i1> %71, <8 x float> %private.contiguous.load812, <8 x float> zeroinitializer
  %.spill.load813 = load <8 x float>, ptr %.spill120, align 32
  %1796 = fmul <8 x float> %.spill.load813, %1795
  %1797 = fadd <8 x float> %1763, %1796
  %1798 = add i64 480, %1596
  %tile_snapshot.spill.load814 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load814, 0
  %1800 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load814, 1
  %.splatinsert815 = insertelement <8 x i64> poison, i64 %1798, i64 0
  %.splat816 = shufflevector <8 x i64> %.splatinsert815, <8 x i64> poison, <8 x i32> zeroinitializer
  %1801 = mul <8 x i64> %.splat816, splat (i64 32)
  %1802 = add <8 x i64> %1800, %1801
  %1803 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1799, 0
  %1804 = insertvalue { <8 x ptr>, <8 x i64> } %1803, <8 x i64> %1802, 1
  %1805 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1806 = extractvalue { <8 x ptr>, <8 x i64> } %1804, 1
  %1807 = extractelement <8 x ptr> %1805, i32 0
  %1808 = extractelement <8 x i64> %1806, i32 0
  %1809 = sub i64 %1808, 0
  %1810 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1811 = select i1 %1810, i64 %1809, i64 0
  %private.contiguous.address817 = getelementptr i8, ptr %1807, i64 %1811
  %private.contiguous.load818 = load <8 x float>, ptr %private.contiguous.address817, align 4
  %1812 = select <8 x i1> %71, <8 x float> %private.contiguous.load818, <8 x float> zeroinitializer
  %.spill.load819 = load <8 x float>, ptr %.spill121, align 32
  %1813 = fmul <8 x float> %.spill.load819, %1812
  %1814 = fadd <8 x float> %1780, %1813
  %1815 = add i64 480, %1613
  %tile_snapshot.spill.load820 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load820, 0
  %1817 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load820, 1
  %.splatinsert821 = insertelement <8 x i64> poison, i64 %1815, i64 0
  %.splat822 = shufflevector <8 x i64> %.splatinsert821, <8 x i64> poison, <8 x i32> zeroinitializer
  %1818 = mul <8 x i64> %.splat822, splat (i64 32)
  %1819 = add <8 x i64> %1817, %1818
  %1820 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1816, 0
  %1821 = insertvalue { <8 x ptr>, <8 x i64> } %1820, <8 x i64> %1819, 1
  %1822 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %1821, 1
  %1824 = extractelement <8 x ptr> %1822, i32 0
  %1825 = extractelement <8 x i64> %1823, i32 0
  %1826 = sub i64 %1825, 0
  %1827 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1828 = select i1 %1827, i64 %1826, i64 0
  %private.contiguous.address823 = getelementptr i8, ptr %1824, i64 %1828
  %private.contiguous.load824 = load <8 x float>, ptr %private.contiguous.address823, align 4
  %1829 = select <8 x i1> %71, <8 x float> %private.contiguous.load824, <8 x float> zeroinitializer
  %.spill.load825 = load <8 x float>, ptr %.spill121, align 32
  %1830 = fmul <8 x float> %.spill.load825, %1829
  %1831 = fadd <8 x float> %1797, %1830
  %1832 = add i64 576, %1596
  %tile_snapshot.spill.load826 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1833 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load826, 0
  %1834 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load826, 1
  %.splatinsert827 = insertelement <8 x i64> poison, i64 %1832, i64 0
  %.splat828 = shufflevector <8 x i64> %.splatinsert827, <8 x i64> poison, <8 x i32> zeroinitializer
  %1835 = mul <8 x i64> %.splat828, splat (i64 32)
  %1836 = add <8 x i64> %1834, %1835
  %1837 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1833, 0
  %1838 = insertvalue { <8 x ptr>, <8 x i64> } %1837, <8 x i64> %1836, 1
  %1839 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1840 = extractvalue { <8 x ptr>, <8 x i64> } %1838, 1
  %1841 = extractelement <8 x ptr> %1839, i32 0
  %1842 = extractelement <8 x i64> %1840, i32 0
  %1843 = sub i64 %1842, 0
  %1844 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1845 = select i1 %1844, i64 %1843, i64 0
  %private.contiguous.address829 = getelementptr i8, ptr %1841, i64 %1845
  %private.contiguous.load830 = load <8 x float>, ptr %private.contiguous.address829, align 4
  %1846 = select <8 x i1> %71, <8 x float> %private.contiguous.load830, <8 x float> zeroinitializer
  %.spill.load831 = load <8 x float>, ptr %.spill122, align 32
  %1847 = fmul <8 x float> %.spill.load831, %1846
  %1848 = fadd <8 x float> %1814, %1847
  %1849 = add i64 576, %1613
  %tile_snapshot.spill.load832 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load832, 0
  %1851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load832, 1
  %.splatinsert833 = insertelement <8 x i64> poison, i64 %1849, i64 0
  %.splat834 = shufflevector <8 x i64> %.splatinsert833, <8 x i64> poison, <8 x i32> zeroinitializer
  %1852 = mul <8 x i64> %.splat834, splat (i64 32)
  %1853 = add <8 x i64> %1851, %1852
  %1854 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1850, 0
  %1855 = insertvalue { <8 x ptr>, <8 x i64> } %1854, <8 x i64> %1853, 1
  %1856 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1857 = extractvalue { <8 x ptr>, <8 x i64> } %1855, 1
  %1858 = extractelement <8 x ptr> %1856, i32 0
  %1859 = extractelement <8 x i64> %1857, i32 0
  %1860 = sub i64 %1859, 0
  %1861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1862 = select i1 %1861, i64 %1860, i64 0
  %private.contiguous.address835 = getelementptr i8, ptr %1858, i64 %1862
  %private.contiguous.load836 = load <8 x float>, ptr %private.contiguous.address835, align 4
  %1863 = select <8 x i1> %71, <8 x float> %private.contiguous.load836, <8 x float> zeroinitializer
  %.spill.load837 = load <8 x float>, ptr %.spill122, align 32
  %1864 = fmul <8 x float> %.spill.load837, %1863
  %1865 = fadd <8 x float> %1831, %1864
  %1866 = add i64 672, %1596
  %tile_snapshot.spill.load838 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1867 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load838, 0
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load838, 1
  %.splatinsert839 = insertelement <8 x i64> poison, i64 %1866, i64 0
  %.splat840 = shufflevector <8 x i64> %.splatinsert839, <8 x i64> poison, <8 x i32> zeroinitializer
  %1869 = mul <8 x i64> %.splat840, splat (i64 32)
  %1870 = add <8 x i64> %1868, %1869
  %1871 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1867, 0
  %1872 = insertvalue { <8 x ptr>, <8 x i64> } %1871, <8 x i64> %1870, 1
  %1873 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1874 = extractvalue { <8 x ptr>, <8 x i64> } %1872, 1
  %1875 = extractelement <8 x ptr> %1873, i32 0
  %1876 = extractelement <8 x i64> %1874, i32 0
  %1877 = sub i64 %1876, 0
  %1878 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1879 = select i1 %1878, i64 %1877, i64 0
  %private.contiguous.address841 = getelementptr i8, ptr %1875, i64 %1879
  %private.contiguous.load842 = load <8 x float>, ptr %private.contiguous.address841, align 4
  %1880 = select <8 x i1> %71, <8 x float> %private.contiguous.load842, <8 x float> zeroinitializer
  %.spill.load843 = load <8 x float>, ptr %.spill123, align 32
  %1881 = fmul <8 x float> %.spill.load843, %1880
  %1882 = fadd <8 x float> %1848, %1881
  %1883 = add i64 672, %1613
  %tile_snapshot.spill.load844 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1884 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load844, 0
  %1885 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load844, 1
  %.splatinsert845 = insertelement <8 x i64> poison, i64 %1883, i64 0
  %.splat846 = shufflevector <8 x i64> %.splatinsert845, <8 x i64> poison, <8 x i32> zeroinitializer
  %1886 = mul <8 x i64> %.splat846, splat (i64 32)
  %1887 = add <8 x i64> %1885, %1886
  %1888 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1884, 0
  %1889 = insertvalue { <8 x ptr>, <8 x i64> } %1888, <8 x i64> %1887, 1
  %1890 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1891 = extractvalue { <8 x ptr>, <8 x i64> } %1889, 1
  %1892 = extractelement <8 x ptr> %1890, i32 0
  %1893 = extractelement <8 x i64> %1891, i32 0
  %1894 = sub i64 %1893, 0
  %1895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1896 = select i1 %1895, i64 %1894, i64 0
  %private.contiguous.address847 = getelementptr i8, ptr %1892, i64 %1896
  %private.contiguous.load848 = load <8 x float>, ptr %private.contiguous.address847, align 4
  %1897 = select <8 x i1> %71, <8 x float> %private.contiguous.load848, <8 x float> zeroinitializer
  %.spill.load849 = load <8 x float>, ptr %.spill123, align 32
  %1898 = fmul <8 x float> %.spill.load849, %1897
  %1899 = fadd <8 x float> %1865, %1898
  %1900 = add i64 768, %1596
  %tile_snapshot.spill.load850 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1901 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load850, 0
  %1902 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load850, 1
  %.splatinsert851 = insertelement <8 x i64> poison, i64 %1900, i64 0
  %.splat852 = shufflevector <8 x i64> %.splatinsert851, <8 x i64> poison, <8 x i32> zeroinitializer
  %1903 = mul <8 x i64> %.splat852, splat (i64 32)
  %1904 = add <8 x i64> %1902, %1903
  %1905 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1901, 0
  %1906 = insertvalue { <8 x ptr>, <8 x i64> } %1905, <8 x i64> %1904, 1
  %1907 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1908 = extractvalue { <8 x ptr>, <8 x i64> } %1906, 1
  %1909 = extractelement <8 x ptr> %1907, i32 0
  %1910 = extractelement <8 x i64> %1908, i32 0
  %1911 = sub i64 %1910, 0
  %1912 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1913 = select i1 %1912, i64 %1911, i64 0
  %private.contiguous.address853 = getelementptr i8, ptr %1909, i64 %1913
  %private.contiguous.load854 = load <8 x float>, ptr %private.contiguous.address853, align 4
  %1914 = select <8 x i1> %71, <8 x float> %private.contiguous.load854, <8 x float> zeroinitializer
  %.spill.load855 = load <8 x float>, ptr %.spill124, align 32
  %1915 = fmul <8 x float> %.spill.load855, %1914
  %1916 = fadd <8 x float> %1882, %1915
  %1917 = add i64 768, %1613
  %tile_snapshot.spill.load856 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1918 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load856, 0
  %1919 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load856, 1
  %.splatinsert857 = insertelement <8 x i64> poison, i64 %1917, i64 0
  %.splat858 = shufflevector <8 x i64> %.splatinsert857, <8 x i64> poison, <8 x i32> zeroinitializer
  %1920 = mul <8 x i64> %.splat858, splat (i64 32)
  %1921 = add <8 x i64> %1919, %1920
  %1922 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1918, 0
  %1923 = insertvalue { <8 x ptr>, <8 x i64> } %1922, <8 x i64> %1921, 1
  %1924 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1925 = extractvalue { <8 x ptr>, <8 x i64> } %1923, 1
  %1926 = extractelement <8 x ptr> %1924, i32 0
  %1927 = extractelement <8 x i64> %1925, i32 0
  %1928 = sub i64 %1927, 0
  %1929 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1930 = select i1 %1929, i64 %1928, i64 0
  %private.contiguous.address859 = getelementptr i8, ptr %1926, i64 %1930
  %private.contiguous.load860 = load <8 x float>, ptr %private.contiguous.address859, align 4
  %1931 = select <8 x i1> %71, <8 x float> %private.contiguous.load860, <8 x float> zeroinitializer
  %.spill.load861 = load <8 x float>, ptr %.spill124, align 32
  %1932 = fmul <8 x float> %.spill.load861, %1931
  %1933 = fadd <8 x float> %1899, %1932
  %1934 = add i64 864, %1596
  %tile_snapshot.spill.load862 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1935 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load862, 0
  %1936 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load862, 1
  %.splatinsert863 = insertelement <8 x i64> poison, i64 %1934, i64 0
  %.splat864 = shufflevector <8 x i64> %.splatinsert863, <8 x i64> poison, <8 x i32> zeroinitializer
  %1937 = mul <8 x i64> %.splat864, splat (i64 32)
  %1938 = add <8 x i64> %1936, %1937
  %1939 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1935, 0
  %1940 = insertvalue { <8 x ptr>, <8 x i64> } %1939, <8 x i64> %1938, 1
  %1941 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1942 = extractvalue { <8 x ptr>, <8 x i64> } %1940, 1
  %1943 = extractelement <8 x ptr> %1941, i32 0
  %1944 = extractelement <8 x i64> %1942, i32 0
  %1945 = sub i64 %1944, 0
  %1946 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1947 = select i1 %1946, i64 %1945, i64 0
  %private.contiguous.address865 = getelementptr i8, ptr %1943, i64 %1947
  %private.contiguous.load866 = load <8 x float>, ptr %private.contiguous.address865, align 4
  %1948 = select <8 x i1> %71, <8 x float> %private.contiguous.load866, <8 x float> zeroinitializer
  %.spill.load867 = load <8 x float>, ptr %.spill125, align 32
  %1949 = fmul <8 x float> %.spill.load867, %1948
  %1950 = fadd <8 x float> %1916, %1949
  %1951 = add i64 864, %1613
  %tile_snapshot.spill.load868 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1952 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 0
  %1953 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load868, 1
  %.splatinsert869 = insertelement <8 x i64> poison, i64 %1951, i64 0
  %.splat870 = shufflevector <8 x i64> %.splatinsert869, <8 x i64> poison, <8 x i32> zeroinitializer
  %1954 = mul <8 x i64> %.splat870, splat (i64 32)
  %1955 = add <8 x i64> %1953, %1954
  %1956 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1952, 0
  %1957 = insertvalue { <8 x ptr>, <8 x i64> } %1956, <8 x i64> %1955, 1
  %1958 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1959 = extractvalue { <8 x ptr>, <8 x i64> } %1957, 1
  %1960 = extractelement <8 x ptr> %1958, i32 0
  %1961 = extractelement <8 x i64> %1959, i32 0
  %1962 = sub i64 %1961, 0
  %1963 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1964 = select i1 %1963, i64 %1962, i64 0
  %private.contiguous.address871 = getelementptr i8, ptr %1960, i64 %1964
  %private.contiguous.load872 = load <8 x float>, ptr %private.contiguous.address871, align 4
  %1965 = select <8 x i1> %71, <8 x float> %private.contiguous.load872, <8 x float> zeroinitializer
  %.spill.load873 = load <8 x float>, ptr %.spill125, align 32
  %1966 = fmul <8 x float> %.spill.load873, %1965
  %1967 = fadd <8 x float> %1933, %1966
  %1968 = add i64 960, %1596
  %tile_snapshot.spill.load874 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1969 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load874, 0
  %1970 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load874, 1
  %.splatinsert875 = insertelement <8 x i64> poison, i64 %1968, i64 0
  %.splat876 = shufflevector <8 x i64> %.splatinsert875, <8 x i64> poison, <8 x i32> zeroinitializer
  %1971 = mul <8 x i64> %.splat876, splat (i64 32)
  %1972 = add <8 x i64> %1970, %1971
  %1973 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1969, 0
  %1974 = insertvalue { <8 x ptr>, <8 x i64> } %1973, <8 x i64> %1972, 1
  %1975 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1976 = extractvalue { <8 x ptr>, <8 x i64> } %1974, 1
  %1977 = extractelement <8 x ptr> %1975, i32 0
  %1978 = extractelement <8 x i64> %1976, i32 0
  %1979 = sub i64 %1978, 0
  %1980 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1981 = select i1 %1980, i64 %1979, i64 0
  %private.contiguous.address877 = getelementptr i8, ptr %1977, i64 %1981
  %private.contiguous.load878 = load <8 x float>, ptr %private.contiguous.address877, align 4
  %1982 = select <8 x i1> %71, <8 x float> %private.contiguous.load878, <8 x float> zeroinitializer
  %.spill.load879 = load <8 x float>, ptr %.spill126, align 32
  %1983 = fmul <8 x float> %.spill.load879, %1982
  %1984 = fadd <8 x float> %1950, %1983
  %1985 = add i64 960, %1613
  %tile_snapshot.spill.load880 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %1986 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load880, 0
  %1987 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load880, 1
  %.splatinsert881 = insertelement <8 x i64> poison, i64 %1985, i64 0
  %.splat882 = shufflevector <8 x i64> %.splatinsert881, <8 x i64> poison, <8 x i32> zeroinitializer
  %1988 = mul <8 x i64> %.splat882, splat (i64 32)
  %1989 = add <8 x i64> %1987, %1988
  %1990 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1986, 0
  %1991 = insertvalue { <8 x ptr>, <8 x i64> } %1990, <8 x i64> %1989, 1
  %1992 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1993 = extractvalue { <8 x ptr>, <8 x i64> } %1991, 1
  %1994 = extractelement <8 x ptr> %1992, i32 0
  %1995 = extractelement <8 x i64> %1993, i32 0
  %1996 = sub i64 %1995, 0
  %1997 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1998 = select i1 %1997, i64 %1996, i64 0
  %private.contiguous.address883 = getelementptr i8, ptr %1994, i64 %1998
  %private.contiguous.load884 = load <8 x float>, ptr %private.contiguous.address883, align 4
  %1999 = select <8 x i1> %71, <8 x float> %private.contiguous.load884, <8 x float> zeroinitializer
  %.spill.load885 = load <8 x float>, ptr %.spill126, align 32
  %2000 = fmul <8 x float> %.spill.load885, %1999
  %2001 = fadd <8 x float> %1967, %2000
  %2002 = add i64 1056, %1596
  %tile_snapshot.spill.load886 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2003 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load886, 0
  %2004 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load886, 1
  %.splatinsert887 = insertelement <8 x i64> poison, i64 %2002, i64 0
  %.splat888 = shufflevector <8 x i64> %.splatinsert887, <8 x i64> poison, <8 x i32> zeroinitializer
  %2005 = mul <8 x i64> %.splat888, splat (i64 32)
  %2006 = add <8 x i64> %2004, %2005
  %2007 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2003, 0
  %2008 = insertvalue { <8 x ptr>, <8 x i64> } %2007, <8 x i64> %2006, 1
  %2009 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2010 = extractvalue { <8 x ptr>, <8 x i64> } %2008, 1
  %2011 = extractelement <8 x ptr> %2009, i32 0
  %2012 = extractelement <8 x i64> %2010, i32 0
  %2013 = sub i64 %2012, 0
  %2014 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2015 = select i1 %2014, i64 %2013, i64 0
  %private.contiguous.address889 = getelementptr i8, ptr %2011, i64 %2015
  %private.contiguous.load890 = load <8 x float>, ptr %private.contiguous.address889, align 4
  %2016 = select <8 x i1> %71, <8 x float> %private.contiguous.load890, <8 x float> zeroinitializer
  %.spill.load891 = load <8 x float>, ptr %.spill127, align 32
  %2017 = fmul <8 x float> %.spill.load891, %2016
  %2018 = fadd <8 x float> %1984, %2017
  %2019 = add i64 1056, %1613
  %tile_snapshot.spill.load892 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2020 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load892, 0
  %2021 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load892, 1
  %.splatinsert893 = insertelement <8 x i64> poison, i64 %2019, i64 0
  %.splat894 = shufflevector <8 x i64> %.splatinsert893, <8 x i64> poison, <8 x i32> zeroinitializer
  %2022 = mul <8 x i64> %.splat894, splat (i64 32)
  %2023 = add <8 x i64> %2021, %2022
  %2024 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2020, 0
  %2025 = insertvalue { <8 x ptr>, <8 x i64> } %2024, <8 x i64> %2023, 1
  %2026 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2027 = extractvalue { <8 x ptr>, <8 x i64> } %2025, 1
  %2028 = extractelement <8 x ptr> %2026, i32 0
  %2029 = extractelement <8 x i64> %2027, i32 0
  %2030 = sub i64 %2029, 0
  %2031 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2032 = select i1 %2031, i64 %2030, i64 0
  %private.contiguous.address895 = getelementptr i8, ptr %2028, i64 %2032
  %private.contiguous.load896 = load <8 x float>, ptr %private.contiguous.address895, align 4
  %2033 = select <8 x i1> %71, <8 x float> %private.contiguous.load896, <8 x float> zeroinitializer
  %.spill.load897 = load <8 x float>, ptr %.spill127, align 32
  %2034 = fmul <8 x float> %.spill.load897, %2033
  %2035 = fadd <8 x float> %2001, %2034
  %2036 = add i64 1152, %1596
  %tile_snapshot.spill.load898 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2037 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load898, 0
  %2038 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load898, 1
  %.splatinsert899 = insertelement <8 x i64> poison, i64 %2036, i64 0
  %.splat900 = shufflevector <8 x i64> %.splatinsert899, <8 x i64> poison, <8 x i32> zeroinitializer
  %2039 = mul <8 x i64> %.splat900, splat (i64 32)
  %2040 = add <8 x i64> %2038, %2039
  %2041 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2037, 0
  %2042 = insertvalue { <8 x ptr>, <8 x i64> } %2041, <8 x i64> %2040, 1
  %2043 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2044 = extractvalue { <8 x ptr>, <8 x i64> } %2042, 1
  %2045 = extractelement <8 x ptr> %2043, i32 0
  %2046 = extractelement <8 x i64> %2044, i32 0
  %2047 = sub i64 %2046, 0
  %2048 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2049 = select i1 %2048, i64 %2047, i64 0
  %private.contiguous.address901 = getelementptr i8, ptr %2045, i64 %2049
  %private.contiguous.load902 = load <8 x float>, ptr %private.contiguous.address901, align 4
  %2050 = select <8 x i1> %71, <8 x float> %private.contiguous.load902, <8 x float> zeroinitializer
  %.spill.load903 = load <8 x float>, ptr %.spill128, align 32
  %2051 = fmul <8 x float> %.spill.load903, %2050
  %2052 = fadd <8 x float> %2018, %2051
  %2053 = add i64 1152, %1613
  %tile_snapshot.spill.load904 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2054 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load904, 0
  %2055 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load904, 1
  %.splatinsert905 = insertelement <8 x i64> poison, i64 %2053, i64 0
  %.splat906 = shufflevector <8 x i64> %.splatinsert905, <8 x i64> poison, <8 x i32> zeroinitializer
  %2056 = mul <8 x i64> %.splat906, splat (i64 32)
  %2057 = add <8 x i64> %2055, %2056
  %2058 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2054, 0
  %2059 = insertvalue { <8 x ptr>, <8 x i64> } %2058, <8 x i64> %2057, 1
  %2060 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2061 = extractvalue { <8 x ptr>, <8 x i64> } %2059, 1
  %2062 = extractelement <8 x ptr> %2060, i32 0
  %2063 = extractelement <8 x i64> %2061, i32 0
  %2064 = sub i64 %2063, 0
  %2065 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2066 = select i1 %2065, i64 %2064, i64 0
  %private.contiguous.address907 = getelementptr i8, ptr %2062, i64 %2066
  %private.contiguous.load908 = load <8 x float>, ptr %private.contiguous.address907, align 4
  %2067 = select <8 x i1> %71, <8 x float> %private.contiguous.load908, <8 x float> zeroinitializer
  %.spill.load909 = load <8 x float>, ptr %.spill128, align 32
  %2068 = fmul <8 x float> %.spill.load909, %2067
  %2069 = fadd <8 x float> %2035, %2068
  %2070 = add i64 1248, %1596
  %tile_snapshot.spill.load910 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2071 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load910, 0
  %2072 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load910, 1
  %.splatinsert911 = insertelement <8 x i64> poison, i64 %2070, i64 0
  %.splat912 = shufflevector <8 x i64> %.splatinsert911, <8 x i64> poison, <8 x i32> zeroinitializer
  %2073 = mul <8 x i64> %.splat912, splat (i64 32)
  %2074 = add <8 x i64> %2072, %2073
  %2075 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2071, 0
  %2076 = insertvalue { <8 x ptr>, <8 x i64> } %2075, <8 x i64> %2074, 1
  %2077 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2078 = extractvalue { <8 x ptr>, <8 x i64> } %2076, 1
  %2079 = extractelement <8 x ptr> %2077, i32 0
  %2080 = extractelement <8 x i64> %2078, i32 0
  %2081 = sub i64 %2080, 0
  %2082 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2083 = select i1 %2082, i64 %2081, i64 0
  %private.contiguous.address913 = getelementptr i8, ptr %2079, i64 %2083
  %private.contiguous.load914 = load <8 x float>, ptr %private.contiguous.address913, align 4
  %2084 = select <8 x i1> %71, <8 x float> %private.contiguous.load914, <8 x float> zeroinitializer
  %.spill.load915 = load <8 x float>, ptr %.spill129, align 32
  %2085 = fmul <8 x float> %.spill.load915, %2084
  %2086 = fadd <8 x float> %2052, %2085
  %2087 = add i64 1248, %1613
  %tile_snapshot.spill.load916 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2088 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load916, 0
  %2089 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load916, 1
  %.splatinsert917 = insertelement <8 x i64> poison, i64 %2087, i64 0
  %.splat918 = shufflevector <8 x i64> %.splatinsert917, <8 x i64> poison, <8 x i32> zeroinitializer
  %2090 = mul <8 x i64> %.splat918, splat (i64 32)
  %2091 = add <8 x i64> %2089, %2090
  %2092 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2088, 0
  %2093 = insertvalue { <8 x ptr>, <8 x i64> } %2092, <8 x i64> %2091, 1
  %2094 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2095 = extractvalue { <8 x ptr>, <8 x i64> } %2093, 1
  %2096 = extractelement <8 x ptr> %2094, i32 0
  %2097 = extractelement <8 x i64> %2095, i32 0
  %2098 = sub i64 %2097, 0
  %2099 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2100 = select i1 %2099, i64 %2098, i64 0
  %private.contiguous.address919 = getelementptr i8, ptr %2096, i64 %2100
  %private.contiguous.load920 = load <8 x float>, ptr %private.contiguous.address919, align 4
  %2101 = select <8 x i1> %71, <8 x float> %private.contiguous.load920, <8 x float> zeroinitializer
  %.spill.load921 = load <8 x float>, ptr %.spill129, align 32
  %2102 = fmul <8 x float> %.spill.load921, %2101
  %2103 = fadd <8 x float> %2069, %2102
  %2104 = add i64 1344, %1596
  %tile_snapshot.spill.load922 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2105 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load922, 0
  %2106 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load922, 1
  %.splatinsert923 = insertelement <8 x i64> poison, i64 %2104, i64 0
  %.splat924 = shufflevector <8 x i64> %.splatinsert923, <8 x i64> poison, <8 x i32> zeroinitializer
  %2107 = mul <8 x i64> %.splat924, splat (i64 32)
  %2108 = add <8 x i64> %2106, %2107
  %2109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2105, 0
  %2110 = insertvalue { <8 x ptr>, <8 x i64> } %2109, <8 x i64> %2108, 1
  %2111 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2112 = extractvalue { <8 x ptr>, <8 x i64> } %2110, 1
  %2113 = extractelement <8 x ptr> %2111, i32 0
  %2114 = extractelement <8 x i64> %2112, i32 0
  %2115 = sub i64 %2114, 0
  %2116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2117 = select i1 %2116, i64 %2115, i64 0
  %private.contiguous.address925 = getelementptr i8, ptr %2113, i64 %2117
  %private.contiguous.load926 = load <8 x float>, ptr %private.contiguous.address925, align 4
  %2118 = select <8 x i1> %71, <8 x float> %private.contiguous.load926, <8 x float> zeroinitializer
  %.spill.load927 = load <8 x float>, ptr %.spill130, align 32
  %2119 = fmul <8 x float> %.spill.load927, %2118
  %2120 = fadd <8 x float> %2086, %2119
  %2121 = add i64 1344, %1613
  %tile_snapshot.spill.load928 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load928, 0
  %2123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load928, 1
  %.splatinsert929 = insertelement <8 x i64> poison, i64 %2121, i64 0
  %.splat930 = shufflevector <8 x i64> %.splatinsert929, <8 x i64> poison, <8 x i32> zeroinitializer
  %2124 = mul <8 x i64> %.splat930, splat (i64 32)
  %2125 = add <8 x i64> %2123, %2124
  %2126 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2122, 0
  %2127 = insertvalue { <8 x ptr>, <8 x i64> } %2126, <8 x i64> %2125, 1
  %2128 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2129 = extractvalue { <8 x ptr>, <8 x i64> } %2127, 1
  %2130 = extractelement <8 x ptr> %2128, i32 0
  %2131 = extractelement <8 x i64> %2129, i32 0
  %2132 = sub i64 %2131, 0
  %2133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2134 = select i1 %2133, i64 %2132, i64 0
  %private.contiguous.address931 = getelementptr i8, ptr %2130, i64 %2134
  %private.contiguous.load932 = load <8 x float>, ptr %private.contiguous.address931, align 4
  %2135 = select <8 x i1> %71, <8 x float> %private.contiguous.load932, <8 x float> zeroinitializer
  %.spill.load933 = load <8 x float>, ptr %.spill130, align 32
  %2136 = fmul <8 x float> %.spill.load933, %2135
  %2137 = fadd <8 x float> %2103, %2136
  %2138 = add i64 1440, %1596
  %tile_snapshot.spill.load934 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2139 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load934, 0
  %2140 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load934, 1
  %.splatinsert935 = insertelement <8 x i64> poison, i64 %2138, i64 0
  %.splat936 = shufflevector <8 x i64> %.splatinsert935, <8 x i64> poison, <8 x i32> zeroinitializer
  %2141 = mul <8 x i64> %.splat936, splat (i64 32)
  %2142 = add <8 x i64> %2140, %2141
  %2143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2139, 0
  %2144 = insertvalue { <8 x ptr>, <8 x i64> } %2143, <8 x i64> %2142, 1
  %2145 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2146 = extractvalue { <8 x ptr>, <8 x i64> } %2144, 1
  %2147 = extractelement <8 x ptr> %2145, i32 0
  %2148 = extractelement <8 x i64> %2146, i32 0
  %2149 = sub i64 %2148, 0
  %2150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2151 = select i1 %2150, i64 %2149, i64 0
  %private.contiguous.address937 = getelementptr i8, ptr %2147, i64 %2151
  %private.contiguous.load938 = load <8 x float>, ptr %private.contiguous.address937, align 4
  %2152 = select <8 x i1> %71, <8 x float> %private.contiguous.load938, <8 x float> zeroinitializer
  %.spill.load939 = load <8 x float>, ptr %.spill131, align 32
  %2153 = fmul <8 x float> %.spill.load939, %2152
  %2154 = fadd <8 x float> %2120, %2153
  %2155 = add i64 1440, %1613
  %tile_snapshot.spill.load940 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load940, 0
  %2157 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load940, 1
  %.splatinsert941 = insertelement <8 x i64> poison, i64 %2155, i64 0
  %.splat942 = shufflevector <8 x i64> %.splatinsert941, <8 x i64> poison, <8 x i32> zeroinitializer
  %2158 = mul <8 x i64> %.splat942, splat (i64 32)
  %2159 = add <8 x i64> %2157, %2158
  %2160 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2156, 0
  %2161 = insertvalue { <8 x ptr>, <8 x i64> } %2160, <8 x i64> %2159, 1
  %2162 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %2163 = extractvalue { <8 x ptr>, <8 x i64> } %2161, 1
  %2164 = extractelement <8 x ptr> %2162, i32 0
  %2165 = extractelement <8 x i64> %2163, i32 0
  %2166 = sub i64 %2165, 0
  %2167 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2168 = select i1 %2167, i64 %2166, i64 0
  %private.contiguous.address943 = getelementptr i8, ptr %2164, i64 %2168
  %private.contiguous.load944 = load <8 x float>, ptr %private.contiguous.address943, align 4
  %2169 = select <8 x i1> %71, <8 x float> %private.contiguous.load944, <8 x float> zeroinitializer
  %.spill.load945 = load <8 x float>, ptr %.spill131, align 32
  %2170 = fmul <8 x float> %.spill.load945, %2169
  %2171 = fadd <8 x float> %2137, %2170
  %tile_snapshot.spill.load946 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill137, align 64
  %2172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load946, 0
  %2173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load946, 1
  %.splatinsert947 = insertelement <8 x i64> poison, i64 %1596, i64 0
  %.splat948 = shufflevector <8 x i64> %.splatinsert947, <8 x i64> poison, <8 x i32> zeroinitializer
  %2174 = mul <8 x i64> %.splat948, splat (i64 32)
  %2175 = add <8 x i64> %2173, %2174
  %2176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2172, 0
  %2177 = insertvalue { <8 x ptr>, <8 x i64> } %2176, <8 x i64> %2175, 1
  %2178 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2179 = extractvalue { <8 x ptr>, <8 x i64> } %2177, 1
  %2180 = extractelement <8 x ptr> %2178, i32 0
  %2181 = extractelement <8 x i64> %2179, i32 0
  %2182 = sub i64 %2181, 0
  %2183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2184 = select i1 %2183, i64 %2182, i64 0
  %private.contiguous.address949 = getelementptr i8, ptr %2180, i64 %2184
  %private.contiguous.preserve950 = load <8 x float>, ptr %private.contiguous.address949, align 4
  %2185 = select <8 x i1> %71, <8 x float> %2154, <8 x float> %private.contiguous.preserve950
  store <8 x float> %2185, ptr %private.contiguous.address949, align 4
  %tile_snapshot.spill.load951 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill137, align 64
  %2186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load951, 0
  %2187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load951, 1
  %.splatinsert952 = insertelement <8 x i64> poison, i64 %1613, i64 0
  %.splat953 = shufflevector <8 x i64> %.splatinsert952, <8 x i64> poison, <8 x i32> zeroinitializer
  %2188 = mul <8 x i64> %.splat953, splat (i64 32)
  %2189 = add <8 x i64> %2187, %2188
  %2190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2186, 0
  %2191 = insertvalue { <8 x ptr>, <8 x i64> } %2190, <8 x i64> %2189, 1
  %2192 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2193 = extractvalue { <8 x ptr>, <8 x i64> } %2191, 1
  %2194 = extractelement <8 x ptr> %2192, i32 0
  %2195 = extractelement <8 x i64> %2193, i32 0
  %2196 = sub i64 %2195, 0
  %2197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2198 = select i1 %2197, i64 %2196, i64 0
  %private.contiguous.address954 = getelementptr i8, ptr %2194, i64 %2198
  %private.contiguous.preserve955 = load <8 x float>, ptr %private.contiguous.address954, align 4
  %2199 = select <8 x i1> %71, <8 x float> %2171, <8 x float> %private.contiguous.preserve955
  store <8 x float> %2199, ptr %private.contiguous.address954, align 4
  %.state956 = load i64, ptr %.slot138, align 4
  %2200 = add i64 %.state956, 1
  store i64 %2200, ptr %.slot138, align 4
  br label %direct.schedule.73

direct.schedule.75:                               ; preds = %direct.false740
  store i64 0, ptr %.slot139, align 4
  br label %direct.schedule.76

direct.schedule.76:                               ; preds = %direct.schedule.77, %direct.schedule.75
  %.state957 = load i64, ptr %.slot139, align 4
  %2201 = icmp slt i64 %.state957, 96
  br i1 %2201, label %direct.true958, label %direct.false959

direct.schedule.77:                               ; preds = %direct.true958
  %tile_snapshot.spill.load960 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill137, align 64
  %2202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load960, 0
  %2203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load960, 1
  %.state961 = load i64, ptr %.slot139, align 4
  %.splatinsert962 = insertelement <8 x i64> poison, i64 %.state961, i64 0
  %.splat963 = shufflevector <8 x i64> %.splatinsert962, <8 x i64> poison, <8 x i32> zeroinitializer
  %2204 = mul <8 x i64> %.splat963, splat (i64 32)
  %2205 = add <8 x i64> %2203, %2204
  %2206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2202, 0
  %2207 = insertvalue { <8 x ptr>, <8 x i64> } %2206, <8 x i64> %2205, 1
  %2208 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2209 = extractvalue { <8 x ptr>, <8 x i64> } %2207, 1
  %2210 = extractelement <8 x ptr> %2208, i32 0
  %2211 = extractelement <8 x i64> %2209, i32 0
  %2212 = sub i64 %2211, 0
  %2213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2214 = select i1 %2213, i64 %2212, i64 0
  %private.contiguous.address964 = getelementptr i8, ptr %2210, i64 %2214
  %private.contiguous.load965 = load <8 x float>, ptr %private.contiguous.address964, align 4
  %2215 = select <8 x i1> %71, <8 x float> %private.contiguous.load965, <8 x float> zeroinitializer
  %tile_snapshot.spill.load966 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %2216 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load966, 0
  %2217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load966, 1
  %.state967 = load i64, ptr %.slot139, align 4
  %.splatinsert968 = insertelement <8 x i64> poison, i64 %.state967, i64 0
  %.splat969 = shufflevector <8 x i64> %.splatinsert968, <8 x i64> poison, <8 x i32> zeroinitializer
  %2218 = mul <8 x i64> %.splat969, splat (i64 32)
  %2219 = add <8 x i64> %2217, %2218
  %2220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2216, 0
  %2221 = insertvalue { <8 x ptr>, <8 x i64> } %2220, <8 x i64> %2219, 1
  %2222 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %2223 = extractvalue { <8 x ptr>, <8 x i64> } %2221, 1
  %2224 = extractelement <8 x ptr> %2222, i32 0
  %2225 = extractelement <8 x i64> %2223, i32 0
  %2226 = sub i64 %2225, 0
  %2227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2228 = select i1 %2227, i64 %2226, i64 0
  %private.contiguous.address970 = getelementptr i8, ptr %2224, i64 %2228
  %private.contiguous.preserve971 = load <8 x float>, ptr %private.contiguous.address970, align 4
  %2229 = select <8 x i1> %71, <8 x float> %2215, <8 x float> %private.contiguous.preserve971
  store <8 x float> %2229, ptr %private.contiguous.address970, align 4
  %.state972 = load i64, ptr %.slot139, align 4
  %2230 = add i64 %.state972, 1
  store i64 %2230, ptr %.slot139, align 4
  br label %direct.schedule.76

direct.schedule.78:                               ; preds = %direct.false959
  store i64 0, ptr %.slot140, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state973 = load i64, ptr %.slot140, align 4
  %2231 = icmp slt i64 %.state973, 96
  br i1 %2231, label %direct.true974, label %direct.false975

direct.schedule.80:                               ; preds = %direct.true974
  %tile_snapshot.spill.load976 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %2232 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load976, 0
  %2233 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load976, 1
  %.state977 = load i64, ptr %.slot140, align 4
  %.splatinsert978 = insertelement <8 x i64> poison, i64 %.state977, i64 0
  %.splat979 = shufflevector <8 x i64> %.splatinsert978, <8 x i64> poison, <8 x i32> zeroinitializer
  %2234 = mul <8 x i64> %.splat979, splat (i64 32)
  %2235 = add <8 x i64> %2233, %2234
  %2236 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2232, 0
  %2237 = insertvalue { <8 x ptr>, <8 x i64> } %2236, <8 x i64> %2235, 1
  %2238 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %2239 = extractvalue { <8 x ptr>, <8 x i64> } %2237, 1
  %2240 = extractelement <8 x ptr> %2238, i32 0
  %2241 = extractelement <8 x i64> %2239, i32 0
  %2242 = sub i64 %2241, 0
  %2243 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2244 = select i1 %2243, i64 %2242, i64 0
  %private.contiguous.address980 = getelementptr i8, ptr %2240, i64 %2244
  %private.contiguous.load981 = load <8 x float>, ptr %private.contiguous.address980, align 4
  %2245 = select <8 x i1> %71, <8 x float> %private.contiguous.load981, <8 x float> zeroinitializer
  %tile_snapshot.spill.load982 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %2246 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load982, 0
  %2247 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load982, 1
  %.state983 = load i64, ptr %.slot140, align 4
  %.splatinsert984 = insertelement <8 x i64> poison, i64 %.state983, i64 0
  %.splat985 = shufflevector <8 x i64> %.splatinsert984, <8 x i64> poison, <8 x i32> zeroinitializer
  %2248 = mul <8 x i64> %.splat985, splat (i64 32)
  %2249 = add <8 x i64> %2247, %2248
  %2250 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2246, 0
  %2251 = insertvalue { <8 x ptr>, <8 x i64> } %2250, <8 x i64> %2249, 1
  %2252 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2253 = extractvalue { <8 x ptr>, <8 x i64> } %2251, 1
  %2254 = extractelement <8 x ptr> %2252, i32 0
  %2255 = extractelement <8 x i64> %2253, i32 0
  %2256 = sub i64 %2255, 0
  %2257 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2258 = select i1 %2257, i64 %2256, i64 0
  %private.contiguous.address986 = getelementptr i8, ptr %2254, i64 %2258
  %private.contiguous.preserve987 = load <8 x float>, ptr %private.contiguous.address986, align 4
  %2259 = select <8 x i1> %71, <8 x float> %2245, <8 x float> %private.contiguous.preserve987
  store <8 x float> %2259, ptr %private.contiguous.address986, align 4
  %.state988 = load i64, ptr %.slot140, align 4
  %2260 = add i64 %.state988, 1
  store i64 %2260, ptr %.slot140, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false975
  %.state989 = load i64, ptr %.slot34, align 4
  %2261 = add i64 %.state989, 1
  %.spill.load990 = load <8 x float>, ptr %.spill114, align 32
  %.spill.load991 = load <8 x float>, ptr %.spill136, align 32
  store i64 %2261, ptr %.slot34, align 4
  %2262 = load <8 x float>, ptr %.slot35, align 32
  %2263 = select <8 x i1> %71, <8 x float> %.spill.load990, <8 x float> %2262
  store <8 x float> %2263, ptr %.slot35, align 32
  %2264 = load <8 x float>, ptr %.slot36, align 32
  %2265 = select <8 x i1> %71, <8 x float> %.spill.load991, <8 x float> %2264
  store <8 x float> %2265, ptr %.slot36, align 32
  br label %direct.schedule.7

direct.schedule.82:                               ; preds = %direct.false177
  store i64 0, ptr %.slot141, align 4
  br label %direct.schedule.83

direct.schedule.83:                               ; preds = %direct.schedule.84, %direct.schedule.82
  %.state992 = load i64, ptr %.slot141, align 4
  %2266 = icmp slt i64 %.state992, 96
  br i1 %2266, label %direct.true993, label %direct.false994

direct.schedule.84:                               ; preds = %direct.true993
  %.spill.load995 = load i64, ptr %.spill29, align 4
  %2267 = add i64 %.spill.load995, 0
  %.spill.load996 = load <8 x i64>, ptr %.spill, align 64
  %2268 = add <8 x i64> %.spill.load996, zeroinitializer
  %2269 = mul i64 %2267, 8
  %.splatinsert997 = insertelement <8 x i64> poison, i64 %2269, i64 0
  %.splat998 = shufflevector <8 x i64> %.splatinsert997, <8 x i64> poison, <8 x i32> zeroinitializer
  %2270 = add <8 x i64> %.splat998, %2268
  %.spill.load999 = load i64, ptr %.spill29, align 4
  %2271 = add i64 %.spill.load999, 0
  %2272 = mul <8 x i64> %2270, splat (i64 1)
  %.splatinsert1000 = insertelement <8 x i64> poison, i64 %2271, i64 0
  %.splat1001 = shufflevector <8 x i64> %.splatinsert1000, <8 x i64> poison, <8 x i32> zeroinitializer
  %2273 = add <8 x i64> %2272, %.splat1001
  %.state1002 = load i64, ptr %.slot141, align 4
  %2274 = add i64 0, %.state1002
  %2275 = mul <8 x i64> %2273, splat (i64 96)
  %.splatinsert1003 = insertelement <8 x i64> poison, i64 %2274, i64 0
  %.splat1004 = shufflevector <8 x i64> %.splatinsert1003, <8 x i64> poison, <8 x i32> zeroinitializer
  %2276 = add <8 x i64> %2275, %.splat1004
  %.state1005 = load i64, ptr %.slot141, align 4
  %2277 = add i64 0, %.state1005
  %tile_snapshot.spill.load1006 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill31, align 64
  %2278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 0
  %2279 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 1
  %.splatinsert1007 = insertelement <8 x i64> poison, i64 %2277, i64 0
  %.splat1008 = shufflevector <8 x i64> %.splatinsert1007, <8 x i64> poison, <8 x i32> zeroinitializer
  %2280 = mul <8 x i64> %.splat1008, splat (i64 32)
  %2281 = add <8 x i64> %2279, %2280
  %2282 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2278, 0
  %2283 = insertvalue { <8 x ptr>, <8 x i64> } %2282, <8 x i64> %2281, 1
  %2284 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2285 = extractvalue { <8 x ptr>, <8 x i64> } %2283, 1
  %2286 = extractelement <8 x ptr> %2284, i32 0
  %2287 = extractelement <8 x i64> %2285, i32 0
  %2288 = sub i64 %2287, 0
  %2289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %2290 = select i1 %2289, i64 %2288, i64 0
  %private.contiguous.address1009 = getelementptr i8, ptr %2286, i64 %2290
  %private.contiguous.load1010 = load <8 x float>, ptr %private.contiguous.address1009, align 4
  %2291 = select <8 x i1> %71, <8 x float> %private.contiguous.load1010, <8 x float> zeroinitializer
  %.state1011 = load <8 x float>, ptr %.slot36, align 32
  %2292 = fdiv <8 x float> %2291, %.state1011
  %2293 = extractvalue { ptr, i64 } %47, 0
  %2294 = mul <8 x i64> %2276, splat (i64 4)
  %2295 = getelementptr i8, ptr %2293, <8 x i64> %2294
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2292, <8 x ptr> align 1 %2295, <8 x i1> %71)
  %.state1012 = load i64, ptr %.slot141, align 4
  %2296 = add i64 %.state1012, 1
  store i64 %2296, ptr %.slot141, align 4
  br label %direct.schedule.83

direct.schedule.85:                               ; preds = %direct.false994
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true166:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false167:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true176:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false177:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.82

direct.true180:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false181:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true193:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false194:                                  ; preds = %direct.schedule.10
  %2297 = load <8 x float>, ptr %.slot41, align 32
  %2298 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2297
  store <8 x float> %2298, ptr %.slot41, align 32
  br label %direct.schedule.12

direct.true205:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false206:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true218:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false219:                                  ; preds = %direct.schedule.15
  %2299 = load <8 x float>, ptr %.slot45, align 32
  %2300 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %2299
  store <8 x float> %2300, ptr %.slot45, align 32
  br label %direct.schedule.17

direct.true230:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false231:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true245:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false246:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true262:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false263:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true279:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false280:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true296:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false297:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true313:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false314:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true330:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false331:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true347:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false348:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true364:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false365:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true381:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false382:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true398:                                   ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false399:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true415:                                   ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false416:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true432:                                   ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false433:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true449:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false450:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true466:                                   ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false467:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true483:                                   ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false484:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true597:                                   ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false598:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true725:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false726:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true739:                                   ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false740:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.75

direct.true958:                                   ; preds = %direct.schedule.76
  br label %direct.schedule.77

direct.false959:                                  ; preds = %direct.schedule.76
  br label %direct.schedule.78

direct.true974:                                   ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false975:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true993:                                   ; preds = %direct.schedule.83
  br label %direct.schedule.84

direct.false994:                                  ; preds = %direct.schedule.83
  br label %direct.schedule.85
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #2

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #3 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #4

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(write) }

"""One fresh two-arm ABBA pair through the unchanged native_rows C++ timer.

This is not the native_tile timer cohort. No compilation, wrapper execution,
timer rewrite, or substitution of hand-written operator implementations.
"""
import argparse
import ctypes as c
import json
import math
from pathlib import Path
import statistics
import sys
import time

import driver


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepared', type=Path, required=True)
    parser.add_argument('--local', type=int, choices=(1, 8), required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cpu-window-owned', action='store_true')
    args = parser.parse_args()
    need, read, sha = driver.need, driver.read, driver.sha
    need(args.cpu_window_owned, 'explicit exclusive CPU window required')
    admission = driver.verify()
    prepared = args.prepared.resolve()
    prior = read(driver.HERE / 'prepare-results.json')
    need(prior['status'] == 'passed' and len(prior['jobs']) == 22, 'full candidate preparation not complete')
    bundle = driver.base.native_tile.verify(prepared)
    metadata = bundle['metadata']
    op, dims = metadata['operation'], metadata['dimensions']
    label = ('rms' if op == 'rmsnorm' else 'softmax') + str(dims[1])
    match = [row for row in prior['jobs'] if row['case'] == label and row['local_lanes'] == args.local]
    need(len(match) == 1 and match[0]['status'] == 'passed' and match[0]['prepared_sha256'] == sha(prepared), 'candidate not bound to admitted preparation')
    need(bundle['name'] == driver.CANDIDATE and bundle['abi'] in (0, 2) and bundle['packet_width'] == 8 and bundle['block'] == [32, 1, 1] and
         bundle['dispatch'] == [dims[0] * args.local, 1, 1] and f'local_lanes={args.local};' in metadata['realization'], 'row timer cannot reproduce Tile launch')
    manifest = read(driver.TORCH / 'manifest.json')
    cases = [case for case in manifest['cases'] if (case['operation'], case['dimensions']) == (op, dims)]
    need(len(cases) == 1, 'unplanned Torch case')
    case = cases[0]
    tensor_entry = case['entries']['inductor']
    sys.path.insert(0, str(driver.base.HELPERS))
    import native_rows as rows
    import numpy as np
    # Only now may native libraries load; no Tensor op executes in the timer.
    import torch
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    need(torch.__version__ == manifest['torch_version'] and torch.version.git_version == manifest['torch_git_version'], 'Torch build/version changed')
    arrays = [np.fromfile(prepared.parent / name, dtype=np.float32).reshape(shape)
              for name, shape in zip(bundle['input_files'], case['input_shapes'])]
    need([rows.array_digest(a) for a in arrays] == case['input_sha256'], 'Torch and Tile inputs differ')
    expected = rows.reference(op, dims, arrays)
    captured_reference = np.fromfile(prepared.parent / 'expected.f64', dtype=np.float64).reshape(case['output_shape'])
    need(np.allclose(captured_reference, expected, atol=1e-12, rtol=1e-12), 'independent FP64 reference mismatch')
    plan = tensor_entry['plan']
    # All exposed writable ABI arguments get FP64 oracles, including scratch.
    x = arrays[0].astype(np.float64)
    if op == 'rmsnorm':
        expected_writes = [np.sum(x * x, axis=1, keepdims=True), expected]
    else:
        mask = np.arange(dims[1])[None, :] <= (np.arange(dims[0]) % dims[1])[:, None]
        scores = np.where(mask, x, float(np.float32(-1e30)))
        maximum = scores.max(axis=1, keepdims=True)
        expected_writes = [maximum, np.exp(scores - maximum).sum(axis=1, keepdims=True), expected]
    write_views = [view for kind, view in zip(plan['types'], plan['arguments']) if kind == 'float*']
    need(len(write_views) == len(expected_writes) and {view['storage'] for view in write_views} == set(plan['allocations']), 'unsupported writable scratch contract')
    for descriptor, reference in zip(write_views, expected_writes):
        allocation = plan['allocations'][descriptor['storage']]
        need(descriptor['offset'] == 0 and tuple(descriptor['shape']) == reference.shape and allocation['elements'] == reference.size,
             'scratch oracle does not cover complete allocation')
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    expected.tofile(output / 'expected.f64')
    for i, reference in enumerate(expected_writes):
        reference.tofile(output / f'torch-write-{i}.f64')
    helper_library = c.CDLL(manifest['helper'])
    helper = helper_library.replay_native_rows
    ptr, u32, size, double = c.c_void_p, c.c_uint32, c.c_size_t, c.c_double
    helper.argtypes = [ptr, u32, u32, u32, c.POINTER(ptr), c.POINTER(size), u32, u32, u32,
                       u32, u32, size, u32, u32, u32, c.POINTER(double), c.POINTER(c.c_uint64)]
    helper.restype = c.c_int
    variants = []
    libraries = []
    for name in ('torch-inductor', driver.CANDIDATE):
        owners = {f'input{i}': rows.Guarded(a.size, a) for i, a in enumerate(arrays)}
        if name == 'torch-inductor':
            library = c.CDLL(tensor_entry['library'])
            address = c.cast(getattr(library, tensor_entry['symbol']), ptr)
            owners.update({key: rows.Guarded(value['elements']) for key, value in plan['allocations'].items()})
            arguments = [rows.view_array(view, owners) for view in plan['arguments']]
            writes = [(rows.view_array(view, owners), ref) for view, ref in zip(write_views, expected_writes)]
            final = rows.view_array(plan['output'], owners)
            abi, const_mask, local, workspace = 1, plan['const_mask'], 1, 0
        else:
            library = c.CDLL(str(prepared.parent / 'kernel.dylib'))
            address = c.cast(getattr(library, bundle['symbol']), ptr)
            owners['output'] = rows.Guarded(expected.size)
            final = owners['output'].data.reshape(expected.shape)
            arguments = [owners[f'input{i}'].data for i in range(3)] + [final]
            writes = [(final, expected)]
            abi, const_mask, local, workspace = bundle['abi'], 7, args.local, bundle['workspace_bytes']
        libraries.append(library)
        variants.append(dict(name=name, owners=owners, address=address, abi=abi, const_mask=const_mask, local=local, workspace=workspace,
                             pointers=(ptr * len(arguments))(*(a.ctypes.data for a in arguments)),
                             sizes=(size * len(arguments))(*(a.nbytes for a in arguments)), writes=writes, final=final))
    artifact_hashes = {str(prepared): sha(prepared), str(prepared.parent / 'kernel.dylib'): sha(prepared.parent / 'kernel.dylib'),
                       tensor_entry['library']: tensor_entry['library_sha256'], manifest['helper']: manifest['helper_sha256'], str(Path(__file__).resolve()): sha(__file__)}
    report = dict(status='running', started=time.time(), timer='native_rows', cpu_threads=1, operation=op, dimensions=dims,
                  local_lanes=args.local, historical_times_reused=False, order_policy='ABBA per cycle; two matched pairs per cycle',
                  cycles=3, samples=5, warmup_ms=40, target_ms=20, visits=[], preflight=[], artifacts_sha256=artifact_hashes,
                  boundary='Common unchanged native_rows C++ callback timer; not the native_tile regression cohort. Runtime/Python/JIT/caller allocations/validation excluded; launch resets/traversal/emitted allocation included.')
    def persist():
        rows.save(output / 'results.json', report)
    def visit(index, samples_count, warmup, target):
        variant = variants[index]
        for name, owner in variant['owners'].items():
            if not name.startswith('input'):
                owner.data.fill(np.nan)
        samples, repetitions = (double * samples_count)(), c.c_uint64()
        code = helper(variant['address'], variant['abi'], len(variant['pointers']), variant['const_mask'], variant['pointers'], variant['sizes'],
                      *dims, 8, 32, variant['local'], variant['workspace'], samples_count, warmup, target, samples, c.byref(repetitions))
        need(code == 0 and repetitions.value > 0 and all(math.isfinite(v) and v > 0 for v in samples), 'native_rows invocation failed')
        checks = [rows.validate_output(actual, reference) for actual, reference in variant['writes']]
        for owner in variant['owners'].values():
            owner.check()
        need([rows.array_digest(variant['owners'][f'input{i}'].data) for i in range(3)] == case['input_sha256'], 'immutable input changed')
        return dict(variant=variant['name'], valid=True, all_guards_passed=True, inputs_unchanged=True, samples_us=list(samples),
                    repetitions=repetitions.value, median_us=statistics.median(samples), correctness=checks,
                    output_sha256=rows.array_digest(variant['final']))
    persist()
    try:
        # Existing helper has no validation-only API. Its one-sample 1ms
        # preflight is checked and discarded, never used as a timing result.
        for index in (0, 1):
            checked = visit(index, 1, 0, 1)
            report['preflight'].append({k: v for k, v in checked.items() if k not in ('samples_us', 'median_us', 'repetitions')})
        output_hashes = {}
        for cycle in range(3):
            for position, index in enumerate((0, 1, 1, 0)):
                checked = visit(index, 5, 40, 20)
                checked.update(cycle=cycle, position=position)
                need(output_hashes.setdefault(checked['variant'], checked['output_sha256']) == checked['output_sha256'], 'fixed-entry output unstable')
                variants[index]['final'].tofile(output / f'visit-{cycle}-{position}.f32')
                report['visits'].append(checked)
                persist()
        ratios = []
        for cycle in range(3):
            visits = report['visits'][cycle * 4:cycle * 4 + 4]
            ratios.extend((visits[1]['median_us'] / visits[0]['median_us'], visits[2]['median_us'] / visits[3]['median_us']))
        report['summary_us'] = {v['name']: statistics.median(row['median_us'] for row in report['visits'] if row['variant'] == v['name']) for v in variants}
        report['candidate_over_baseline'] = dict(baseline='torch-inductor', candidate=driver.CANDIDATE, pairs=ratios,
                                                median=statistics.median(ratios), minimum=min(ratios), maximum=max(ratios))
        need(all(sha(path) == digest for path, digest in artifact_hashes.items()), 'loaded artifact changed')
        driver.verify()
        report.update(status='passed', artifacts_unchanged=True)
    except BaseException as error:
        report.update(status='Error', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        report['finished'] = time.time()
        persist()


if __name__ == '__main__':
    main()

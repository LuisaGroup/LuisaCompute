"""Fresh full12 byte-private vs retained full11 default; no old timing reuse.

Reuse the previous bounded process runner, capture validation, native_tile
timer, and Torch ABI validation. Only gate identity and baseline provenance
are adapted. Native phases require a separately approved CPU window.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
RAW = HERE.parent
OLD = RAW / 'cpu-full11-vs-full9.H7yzJk'
COHORT = RAW / 'byte-private-candidate.Oe9AVl'
CANDIDATE = 'full12-byte-private'
PINS = {
    OLD / 'driver.py': '101a26b36c6c8269f01f31e5bb4902b59e09f4d601e43d41766d179b6065c490',
    OLD / 'torch_pairs.py': '4394dc0c3018b4ce4b048bc3eb2eb27a41090471f35d115c1977720fc3bb3141',
    OLD / 'admission.json': '7455bcee95d0cdb217ba5d62b0d0e7d7c73e4d8e5f0406e6bb228933fca75d0d',
    OLD / 'joined-admission.json': '2468acd1c43fea4330b18ec9d19e96ae9e2cc19999b93e502be855ce5fc034ca',
    OLD / 'capture-results.json': '0e92407101a803135a7b47b5c5c32bd0d650fb53f412d6363f5fcf73b5a7aaa6',
    OLD / 'prepare-results.json': '427fdb9790dfd337e44472c2103ad5070e85f8f582bd23c1c1aec460c58575f5',
    COHORT / 'run.py': '5e278ef14292ba3c7cbe3872d3452e529f77da1b8b54c9159dc5487470553071',
    COHORT / 'owned.json': '87afaa5ad8eca0e1c1ff9cbb07e42b54393e84ae524a09b9a68181f8628cb1e6',
    COHORT / 'plan.json': '589f9170a86b4c9dd5984380ad56e65fba263713bc2f877c5a8191c29c1ba8f3',
    COHORT / 'source-freeze-byte-private.json': '71573837811263abe91d86a4c0b33bb425479e2bd5c2638e92d899a1afb56720',
    COHORT / 'build-full-12/result.json': '3775280fcd9a709d320431df4b153f0a0342bc75d20ba3d6749e856c4e250b2a',
    COHORT / 'test-full12-unit-simd/result.json': '83b5345846b0e1c3c1c28f23b2dec8f7993f8fb562504beddd3104cdbfa6b351',
    COHORT / 'test-full12-tile-simd/result.json': '1d1c4214de85002c229f5fe91e0a8ebdc124fcc94633e7b1b34ea23436f82e93',
    COHORT / 'test-full12-host-plan/result.json': '0308d7ba97ab83488ef13f4f3c018823e9f3b118d893ec7483c05af3932332c2',
}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load_module(name, path):
    if digest(path) != PINS[path]:
        raise ValueError('pinned module changed: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


previous = load_module('full11_driver', OLD / 'driver.py')
cohort = load_module('byte_private_cohort', COHORT / 'run.py')
base = previous.base
base.HERE, base.RAW = HERE, RAW
need, sha, read, save = base.need, base.sha, base.read, base.save
copy_exact = previous.copy_exact
TORCH = previous.TORCH


def identities():
    return [(case, local) for case in base.CASES for local in (1, 8)]


def pinned():
    for path, expected in PINS.items():
        need(sha(path) == expected, 'pinned provenance changed: ' + str(path))


def configure_gates(path):
    need(Path(path).resolve() == (HERE / 'gates-full12.json').resolve(), 'wrong gate binding')
    binding = read(path)
    need(binding['schema'] == 1 and set(binding['gates']) == {'build', 'unit', 'tile', 'host'}, 'bad gate set')
    base.FREEZE = Path(binding['freeze_receipt']).resolve()
    base.GATES = {name: Path(value).resolve() for name, value in binding['gates'].items()}
    base.GATE_BINDING = Path(path).resolve()
    need(base.FREEZE == cohort.FREEZE and all(path in PINS for path in base.GATES.values()), 'unpinned gate path')


def source_identity(frozen):
    pinned()
    _, actual = cohort.check_frozen()
    need(frozen == actual and len(frozen['source_sha256']) == 27, 'wrong candidate freeze')


def check_gate(path, frozen):
    result, command = read(path), read(path.parent / 'command.json')
    need(result['status'] == 'passed' and result['exit_code'] == 0 and not result.get('timed_out') and
         result['source_unchanged'] and result['child_exited'], 'incomplete gate: ' + str(path))
    for key, expected in (('source_sha256', frozen['source_sha256']), ('identity', frozen['identity']),
                          ('source_freeze_sha256', sha(cohort.FREEZE))):
        need(result[key] == command[key] == expected, 'gate identity mismatch: ' + key)
    need(result['command'] == command['command'] and frozen['finished'] <= result['started'] <= result['finished'], 'gate command/chronology mismatch')
    for channel in ('stdout', 'stderr'):
        need(sha(path.parent / (channel + '.txt')) == result[channel + '_sha256'], 'gate log drift')
    return result


# Existing admission/process/capture code calls these narrow identity hooks.
base.configure_gates = configure_gates
base.source_identity = source_identity
base.check_gate = check_gate


def baseline_catalog():
    pinned()
    joined, admission = read(OLD / 'joined-admission.json'), read(OLD / 'admission.json')
    need(joined['status'] == admission['status'] == 'passed' and
         joined['admission_sha256'] == sha(OLD / 'admission.json') and
         admission['freeze_sha256'] == '29ef908f51beadddedaac6cc85735f2c260cf86978c075bd0fb875707230099c', 'not retained full11 admission')
    snapshot = OLD / 'full11-immutable'
    saved = {}
    for name, expected in joined['full11_snapshot'].items():
        path = Path(name).resolve()
        relative = path.relative_to(snapshot)
        need(sha(path) == expected, 'full11 snapshot drift: ' + str(path))
        prefix, *suffix = relative.parts
        root = {'selected': base.SELECTED, 'build': base.BUILD, 'raw': RAW}[prefix]
        saved[(root / Path(*suffix)).resolve()] = (path, expected)
    for original, expected in admission['critical_files_sha256'].items() | admission['gate_sha256'].items():
        need(saved[Path(original).resolve()][1] == expected, 'historical capture producer/gate not preserved')
    need(saved[(OLD / 'admission.json').resolve()][1] == sha(OLD / 'admission.json'), 'full11 snapshot admission differs')
    captures, preparations = read(OLD / 'capture-results.json'), read(OLD / 'prepare-results.json')
    for phase in (captures, preparations):
        need(phase['status'] == 'passed' and phase['joined_admission_sha256'] == sha(OLD / 'joined-admission.json') and
             len(phase['jobs']) == 22 and all(row['status'] == 'passed' for row in phase['jobs']), 'incomplete retained full11 phase')
    capture_rows = {(row['case'], row['local_lanes']): row for row in captures['jobs']}
    prepare_rows = {(row['case'], row['local_lanes']): row for row in preparations['jobs']}
    need(len(capture_rows) == len(prepare_rows) == 22, 'duplicate baseline cases')
    catalog = []
    for case, local in identities():
        key = case[0], local
        label = f'{case[0]}-l{local}'
        capture, prepared = OLD / ('capture-' + label), OLD / ('prepared-' + label) / 'prepared.json'
        need(sha(capture / 'validation.json') == capture_rows[key]['validation_sha256'] and
             sha(prepared) == prepare_rows[key]['prepared_sha256'], 'full11 case binding drift')
        validation = read(capture / 'validation.json')
        for path, expected in validation['files_sha256'].items():
            need(sha(path) == expected, 'retained capture artifact changed')
        for phase_dir in (capture, OLD / ('prepare-' + label)):
            command, result = read(phase_dir / 'command.json'), read(phase_dir / 'result.json')
            need(result['status'] == 'passed' and result['exit_code'] == 0 and not result['timed_out'] and
                 result['argv'] == command['argv'] and
                 result['admission_sha256'] == command['admission_sha256'] == sha(OLD / 'admission.json') and
                 result['driver_sha256'] == command['driver_sha256'] == sha(base.__file__), 'historical process binding mismatch')
        bundle = base.native_tile.verify(prepared)
        need(bundle['name'] == 'full11-default' and bundle['metadata'] == validation['metadata'], 'not actual full11 default artifact')
        for original, expected in bundle['original_sha256'].items():
            original = Path(original).resolve()
            retained = saved[original][0] if original in saved else original
            need(sha(retained) == expected, 'historical original unavailable/changed')
        catalog.append(dict(case=case[0], local_lanes=local, manifest=str(prepared), sha256=sha(prepared),
                            input_sha256=validation['input_sha256'], validation_sha256=sha(capture / 'validation.json')))
    return catalog, saved


def admit():
    configure_gates(HERE / 'gates-full12.json')
    baseline, saved = baseline_catalog()
    base.admit()
    current = read(HERE / 'admission.json')
    for relative in ('scripts/benchmark/tile_torch/native_tile.py', 'scripts/benchmark/tile_torch/native_tile_replay.cpp',
                     'scripts/benchmark/tile_torch/compare_llm.py', 'src/backends/simd/llvm/llvm_schedule_codegen.h'):
        need(sha(base.SELECTED / relative) == saved[(base.SELECTED / relative).resolve()][1], 'timer/helper/ABI changed')
    files = {str(base.SELECTED / name): expected for name, expected in read(base.FREEZE)['source_sha256'].items()}
    files.update(current['critical_files_sha256'])
    files.update(current['gate_sha256'])
    files.update({str(path): sha(path) for path in (base.FREEZE, COHORT / 'run.py', COHORT / 'owned.json', COHORT / 'plan.json',
                                                   HERE / 'admission.json', HERE / 'gates-full12.json', HERE / 'plan_v1.json',
                                                   Path(__file__), HERE / 'torch_pairs.py')})
    for gate in base.GATES.values():
        files.update({str(gate.parent / name): sha(gate.parent / name) for name in ('command.json', 'stdout.txt', 'stderr.txt')})
    copies = {}
    for original, expected in files.items():
        source = Path(original).resolve()
        if source.is_relative_to(base.SELECTED):
            relative = Path('selected') / source.relative_to(base.SELECTED)
        elif source.is_relative_to(base.BUILD):
            relative = Path('build') / source.relative_to(base.BUILD)
        else:
            relative = Path('raw') / source.relative_to(RAW)
        target = HERE / 'full12-immutable' / relative
        copy_exact(source, target, expected)
        copies[str(target)] = expected
    for row in baseline:
        original = Path(row['manifest'])
        bundle = base.native_tile.verify(original)
        target = HERE / f"baseline-{row['case']}-l{row['local_lanes']}"
        for relative, expected in bundle['files'].items():
            copy_exact(original.parent / relative, target / relative, expected)
        copy_exact(original, target / 'prepared.json', row['sha256'])
        row.update(snapshot_manifest=str(target / 'prepared.json'), snapshot_sha256=sha(target / 'prepared.json'))
    torch = previous.torch_catalog(baseline)
    torch['boundary'] = 'Fresh full12/Inductor pairs use unchanged native_rows; separate from native_tile full11/full12 times.'
    save(HERE / 'joined-admission.json', dict(status='passed', finished=time.time(), baseline=baseline,
         admission_sha256=sha(HERE / 'admission.json'), driver_sha256=sha(__file__), torch_driver_sha256=sha(HERE / 'torch_pairs.py'),
         parent_pins={str(path): expected for path, expected in PINS.items()}, full12_snapshot=copies, torch=torch,
         historical_times_reused=False, boundary='27-file overlay plus four critical capture binaries; not complete runtime closure.'))


def verify():
    pinned()
    base.verify_admission()
    data = read(HERE / 'joined-admission.json')
    need(data['status'] == 'passed' and data['admission_sha256'] == sha(HERE / 'admission.json') and
         data['driver_sha256'] == sha(__file__) and data['torch_driver_sha256'] == sha(HERE / 'torch_pairs.py'), 'current admission drift')
    for path, expected in data['parent_pins'].items() | data['full12_snapshot'].items() | data['torch']['files_sha256'].items():
        need(sha(path) == expected, 'admitted artifact drift: ' + path)
    for row in data['baseline']:
        need(sha(row['snapshot_manifest']) == row['snapshot_sha256'], 'baseline bundle drift')
        base.native_tile.verify(row['snapshot_manifest'])
    return data


def byte_ir_evidence(prepared, historical):
    def inspect(path):
        text = path.read_text()
        return dict(ir_sha256=sha(path), object_sha256=sha(path.parent / 'kernel.o'),
                    byte_gather_calls=len(re.findall(r'\bcall\b[^\n]*@llvm\.masked\.gather\.v\d+i8\b', text)),
                    byte_scatter_calls=len(re.findall(r'\bcall\b[^\n]*@llvm\.masked\.scatter\.v\d+i8\b', text)),
                    private_byte_loads=len(re.findall(r'(?m)^.*private\.contiguous\.load[^=\n]*=\s*load\s+<\d+ x i8>', text)),
                    private_byte_preserve_loads=len(re.findall(r'(?m)^.*private\.contiguous\.preserve[^=\n]*=\s*load\s+<\d+ x i8>', text)),
                    private_byte_stores=len(re.findall(r'(?m)^\s*store\s+<\d+ x i8>[^\n]*,\s*ptr %private\.contiguous\.address', text)),
                    packed_private_bool_accesses=len([line for line in text.splitlines() if 'private.contiguous.' in line and
                                                      re.search(r'\b(load|store)\s+<\d+ x i1>', line)]))
    old, new = inspect(historical.parent / 'kernel.ll'), inspect(prepared.parent / 'kernel.ll')
    need(new['packed_private_bool_accesses'] == 0, 'packed private bool memory in captured IR')
    return dict(baseline=old, candidate=new, byte_gathers_removed=old['byte_gather_calls'] - new['byte_gather_calls'],
                boundary='Actual captured IR and ORC object hashes; counts are observations, not assumptions that every case must change or machine-instruction counts.')


def phase(mode):
    admitted = verify()
    baseline = {(row['case'], row['local_lanes']): row for row in admitted['baseline']}
    prior_path = None if mode == 'capture' else HERE / (('capture' if mode == 'prepare' else 'prepare') + '-results.json')
    prior = None if prior_path is None else read(prior_path)
    prior_sha = None if prior_path is None else sha(prior_path)
    if prior:
        need(prior['status'] == 'passed' and prior['joined_admission_sha256'] == sha(HERE / 'joined-admission.json') and
             len(prior['jobs']) == 22 and all(row['status'] == 'passed' for row in prior['jobs']), 'required full phase incomplete')
    cases = identities() if mode != 'torch' else identities()[:8]
    report = dict(status='running', mode=mode, started=time.time(), joined_admission_sha256=sha(HERE / 'joined-admission.json'),
                  prior_phase_sha256=prior_sha, jobs=[dict(case=case[0], local_lanes=local, status='NotRun') for case, local in cases],
                  timer='native_rows' if mode == 'torch' else 'native_tile', historical_times_reused=False)
    try:
        for row, (case, local) in zip(report['jobs'], cases):
            name, op, dims, block = case
            label = f'{name}-l{local}'
            capture, prepared = HERE / ('capture-' + label), HERE / ('prepared-' + label) / 'prepared.json'
            prefix, historical = capture / 'output.f32', Path(baseline[name, local]['snapshot_manifest'])
            verify()
            if mode == 'capture':
                env = dict(LUISA_SIMD_WARP_WIDTH='8', LUISA_SIMD_WORKER_COUNT='1', LUISA_TILE_BENCH_XIR_BACKEND='simd',
                           LUISA_TILE_BENCH_XIR_LOCAL_LANES=str(local), LUISA_TILE_BENCH_XIR_BLOCK_SIZE='32',
                           LUISA_TILE_BENCH_XIR_BLOCKS_PER_TASK='1', LUISA_TILE_BENCH_DUMP_SOURCE=str(prefix) + '.source.txt',
                           LUISA_SIMD_DUMP_ASSEMBLY_DIR=str(capture / 'objects'))
                argv = ['/usr/bin/env', *(f'{key}={value}' for key, value in env.items()), str(base.BUILD / 'bin/benchmark_tile_xir'),
                        'llm', op, ','.join(map(str, dims)), *map(str, block), '3', '10', '20', str(prefix)]
                base.run(capture, argv, capture=True)
                checked = base.validate_capture(case, local, CANDIDATE, capture)
                need(checked['input_sha256'] == baseline[name, local]['input_sha256'], 'full12/full11 input mismatch')
                base.native_tile.check_matched_metadata(checked['metadata'], read(historical)['metadata'], 'llm')
                save(capture / 'validation.json', checked)
                row['validation_sha256'] = sha(capture / 'validation.json')
            else:
                previous_row = next(r for r in prior['jobs'] if (r['case'], r['local_lanes']) == (name, local))
                if mode == 'prepare':
                    need(sha(capture / 'validation.json') == previous_row['validation_sha256'], 'capture validation drift')
                    for path, expected in read(capture / 'validation.json')['files_sha256'].items():
                        need(sha(path) == expected, 'captured artifact changed')
                    argv = [str(base.PYTHON), str(base.HELPERS / 'native_tile.py'), 'prepare', '--capture-kind', 'llm', '--name', CANDIDATE,
                            '--prefix', str(prefix), '--log', str(capture / 'stdout.txt'), '--objects', str(capture / 'objects'),
                            '--llvm', str(base.LLVM), '--output', str(prepared.parent)]
                    base.run(HERE / ('prepare-' + label), argv)
                    bundle = base.native_tile.verify(prepared)
                    need(bundle['metadata'] == read(capture / 'validation.json')['metadata'], 'prepared metadata drift')
                    for relative in (*bundle['input_files'], 'expected.f64', 'native_tile_replay.cpp', 'backends/simd/llvm/llvm_schedule_codegen.h'):
                        need(bundle['files'][relative] == read(historical)['files'][relative], 'cross-version ABI/input/oracle drift')
                    row['prepared_sha256'] = sha(prepared)
                    row['byte_ir'] = byte_ir_evidence(prepared, historical)
                else:
                    need(sha(prepared) == previous_row['prepared_sha256'], 'prepared manifest drift')
                    base.native_tile.verify(prepared)
                    output = HERE / (mode + '-output-' + label)
                    if mode == 'replay':
                        argv = [str(base.PYTHON), str(base.HELPERS / 'native_tile.py'), 'replay', '--prepared', str(historical), '--prepared', str(prepared),
                                '--cycles', '3', '--samples', '5', '--warmup-ms', '40', '--target-ms', '20', '--output', str(output)]
                    else:
                        argv = [str(base.PYTHON), str(HERE / 'torch_pairs.py'), '--cpu-window-owned', '--prepared', str(prepared), '--local', str(local), '--output', str(output)]
                    base.run(HERE / (mode + '-' + label), argv)
                    result = read(output / 'results.json')
                    need(result['status'] == 'passed' and result['artifacts_unchanged'] and len(result['visits']) == 12, 'incomplete pair')
                    need(all(v['valid'] and v['all_guards_passed'] and v['inputs_unchanged'] and len(v['samples_us']) == 5 for v in result['visits']), 'invalid timed visit')
                    row.update(candidate_over_baseline=result['candidate_over_baseline'], summary_us=result['summary_us'], result_sha256=sha(output / 'results.json'))
            verify()
            need(prior_path is None or sha(prior_path) == prior_sha, 'prior phase changed')
            row['status'] = 'passed'
            print(mode, label, 'passed', flush=True)
        report['status'] = 'passed'
    except BaseException as error:
        row.update(status='Error', error=f'{type(error).__name__}: {error}')
        report.update(status='Error', error=row['error'], continuation='Stop; remaining cases NotRun, no retries or silent matrix reduction.')
        raise
    finally:
        report['finished'] = time.time()
        save(HERE / (mode + '-results.json'), report)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('self-check', 'admit', 'capture', 'prepare', 'replay', 'torch'))
    parser.add_argument('--cpu-window-owned', action='store_true')
    args = parser.parse_args()
    if args.mode == 'self-check':
        need(len(identities()) == 22 and read(HERE / 'plan_v1.json')['cases'] == json.loads(json.dumps(base.CASES)), 'matrix changed')
        baseline, _ = baseline_catalog()
        previous.torch_catalog(baseline)
        configure_gates(HERE / 'gates-full12.json')
        source_identity(read(base.FREEZE))
        for path in base.GATES.values():
            check_gate(path, read(base.FREEZE))
        save(HERE / 'self-check.json', dict(status='passed', finished=time.time(), driver_sha256=sha(__file__),
             torch_driver_sha256=sha(HERE / 'torch_pairs.py'), parent_pins={str(p): h for p, h in PINS.items()},
             native_tile_edges=22, native_rows_edges=8, admitted=False, native_executed=False))
        print('Read-only passed: full12 freeze/4 gates; retained full11 22 actual prepared objects; unchanged separate Torch timer. No admission or native execution.')
    elif args.mode == 'admit':
        admit()
    else:
        need(args.cpu_window_owned, 'explicit root-approved exclusive CPU window required')
        phase(args.mode)


if __name__ == '__main__':
    main()

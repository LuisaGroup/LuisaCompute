# 原生 attention phase profiling：独立协议与推论边界审查

本记录只读检查 `run.py`、`profile_child.py`、`trace.py` 和已完成 MHA 收据；没有重新执行 native entry、采样、构建或 benchmark。PC parser 由另一任务独立实现，本文不是其完整执行审计，也不把尚未完成的代表矩阵记为通过。

## 1. 结论与需要保留的限制

当前协议适合定位**同一已验证 native entry**中的热点，没有发现使已完成成功 run 数值无效的 blocker。采样是受扰动的诊断，不能替代此前 72 visits / 504 samples 的未采样 ABBA 性能结果。

- `profile_child.py:89–105` 在加载前检查 frozen manifest、全部 inventoried 文件及已归档 verifier 源码；没有重新编译对象。
- `profile_child.py:123–177` 检查完整有限输出、FP64 oracle、guard、输入只读，并要求本次输出与本臂 capture 逐位一致。
- `profile_child.py:179–197` 在 READY 前做 validation-only preflight，GO 后运行同一 C++ helper，完成后再次核对 manifest/source/artifact；不是只检查开头几个元素。
- `profile_child.py:55–74,135–144` 同时记录 kernel/helper 的 `dladdr` image base、entry address、路径和文件 SHA；ABI、dispatch、block、packet width、workspace 均来自原 manifest。
- 这是磁盘 artifact / loader 路径对应的收据，不是读取进程全部代码页后的内存完整性证明。Python/系统动态库也不是完整 loader closure。
- frozen cohort 已有独立 FP64 `einsum` 审计；profile child 复用其中的固定 oracle，不能描述成每次采样又独立重建了一遍数学参考。

## 2. 两种采样协议必须分别命名

`run.py:32–45` 的 plan 固定 `/usr/bin/sample`、5秒、1ms间隔和 GO 后0.25秒延迟；`run.py:62–101` 只 attach 自己创建的 PID，记录父子握手、退出状态并保留失败。

第一次 `decode-mha-d64-off` 的 child/sampler 成功，但文本栈折叠到整个函数，缺少可靠 phase PC 分辨率。应记为 **native validation passed / phase attribution unavailable**，不能假装有精细分布，也不应把它改成数值 Error。

`trace.py:36–69` 是随后增加的 Time Profiler fallback：它立即在 GO 后启动 `xctrace`，独立记录 `manifest_sha256`、`child_sha256`、`driver_sha256`，不是之前 sample plan 的1ms/0.25秒实验。

离线验收须补齐以下关系，不能仅凭 `status=OK`：

1. 每个 trace plan 的 manifest hash = profile plan 对应 cohort hash = READY/RESULT prepared hash = 原始 native 实验中已审计的 manifest hash。
2. 每个 trace 的 child hash = READY/RESULT driver hash = 冻结 `profile_child.py`；trace driver hash 对应实际保存的 `trace.py`。
3. READY/RESULT 的 PID、目标 thread ID、ABI、launch 和两幅 image identities 一致；profiler attach PID 是本次 child PID。
4. `preflight.f32`、`profiled.f32` 都与原 capture 全字节一致；非空/有限/error/guard/tolerance 收据与完整 payload 匹配。
5. 原始 sample、失败尝试与 trace 结果分别保留，不把某个分辨率不足的结果覆盖成另一种协议的成功结果。

## 3. 时间窗与 PC 坐标

MHA-on 的 trace command wall time 是 `1789304730.514386 → 1789304742.028814`；child profiled call 的 monotonic 区间是 `753480811961083 → 753490821480083 ns`，约10.0095秒。命令包括 attach/startup/export 收尾，**不能把它的11.51秒当成实际采样窗口**。

验收应检查导出记录的实际采样起止、时基、目标线程及 profiler event 来源；若没有可验证的 trace-time → child-monotonic 变换，应明确记 `window_alignment=unverified`。不能通过减去第一个样本时间，就宣称已经与 child 的 GO/PROFILE_BEGIN 精确同步。过滤为 kernel image PC 能排除大量 host 工作，但不是完整时间窗证明。

PC 映射链应为：

```text
目标线程的原始 Timer Fired PC
  → dladdr base + linked Mach-O load mapping
  → linked executable section VM address / instruction offset
  → 确认存在的机器指令与保守 phase 类别
```

- `PC - image_base` 是 image-relative；`PC - entry_address` 是 symbol-relative，两者都不是 relocatable `kernel.o` offset。
- 一般转换为 linked VM address 还需 `__TEXT` 的 preferred VM address；文件偏移需对应 section 的 address/offset。即使本批 preferred base 恰为0，也要验收这个条件。
- 必须使用本次加载的 `kernel.dylib` 哈希和可执行 section/指令表，不把 `kernel.o` 的汇编地址直接套上。可用 entry-image offset、linked symbol address、UUID/section 范围做交叉检查。
- 原始 Timer Fired 的 instruction PC 优先；不要普遍减1、减4或把 stack caller return address当作正在执行的 instruction。derived profile frame 若与 raw PC 相差1，只能按相同 timestamp/thread 的逐项 join 证明该导出变换，并记录 unmatched/冲突数。
- Stackshot 与 timer rows 分开；derived profile 的时间权重与 raw row count 分开。不要同时累计一条采样的 raw PC 与其所有 stack frames，也不要混用两种分母。
- 缺少映像的小整数 frame、无法 unwind 的调用者、非4字节对齐/非指令PC、padding/data、无法映射符号都保留为 unknown/invalid，不强行归入 QK/PV。
- `libc` leaf 只有在可见且可靠的 kernel-rooted stack 上才能归为 kernel 内部调用；没有这样的祖先只能记来源未知。未见 memcpy 样本不证明没有 copy。

## 4. 占比能推导什么

设选定同一权重口径、目标线程与有效窗口内，所有观察总权重为 `W`，可判定属于阶段 j 的互斥 leaf 权重为 `Wj`。`Wj/W` 只是**该采样实验中的观察占比**。必须同时报告时间覆盖、目标线程总行数、kernel image 命中、可分类量、unknown/外部调用量和 dropped/unmatched量。

若只对已分类样本归一化，设覆盖率为 `c`、阶段条件占比为 `q`，则它在原观察总体中的已知量是 `c*q`，不是 `q`。当剩余未分类样本可能全部属于阶段 j 时，纯集合关系给出的范围为 `[c*q, c*q + (1-c)]`；这是**观察集合的缺失范围**，不是实际运行时间的置信区间。

只有再假设采样无偏、窗口代表稳定运行、相关样本足够、阶段完全划分且优化不改变其余成本，才能把真实时间分数 `f` 代入 Amdahl 条件式：

`speedup(s) = 1 / ((1-f) + f/s)`，`s→∞` 时为 `1/(1-f)`。

当前的 kernel-image 条件占比既不等于完整 native-entry 的 `f`，也没有证明上述条件；不能由它宣布“优化 QK 最多只能快 X%”或“PV 占比 Y%，因此真实 copy 成本为 Z µs”。更不能把采样比例乘到另一次未采样 ABBA latency 上，当成测得的 phase 绝对时间。

固定间隔可能与重复 KV loop 相关，attach/中断也会改变缓存、频率、调度。PC 位置不是 stall attribution、retired-instruction count 或每条指令的独立 latency；sampling skid、指令边界/邻近PC和代码移动都会限制细粒度归因。普通 `sqrt(p*(1-p)/N)` 不能在没有独立性/随机性论证时当作可靠误差条。

可以成立的较弱结论是：“在该受扰动 run、该可验证权重/coverage 中，大量样本位于某组实际 linked 指令；这值得作为下次单变量实验目标”。可比较代表负例 MHA、长KV、正例 batch-GQA 的热点**位置与映射形态**，但它们的占比变化本身不能说明绝对阶段变快或变慢。

## 5. 隐私安全的归档白名单

不要递归打包整个 profiling root。child 继承的环境不只三个线程变量；`.trace`、TOC、进程映像/字符串表和未筛选 XML 可能携带无关环境、绝对路径或进程信息。不能靠删一个 `environment` 字段就认定安全。

建议公开产物仅包含：

- 明确版本的 parser、记录方法说明，以及经过字段白名单构造的 plan/validation 摘要。
- `profile-summary.json`、`leaf-pcs.csv`：case/arm、受控维度/launch、image/source/manifest SHA、相对时间/相对PC、phase类别、权重单位、完整分母、unknown和join统计。
- 经过审核的 linked-kernel section/symbol/instruction mapping 或其确定性生成输入；只收自己的 kernel image，不带整个系统 image 表。
- preflight/profiled 输出或其与已有公开 capture 相等的核验摘要；受扰动 samples 即使保留也显式标注 `performance_comparison_accepted=false`。
- 私有原始 trace/XML 的内容哈希、字节数、排除理由和 sanitization schema；**不公开原始值本身**。

公开摘要应移除 PID/TID、ASLR 绝对地址、无关 image path、用户目录、环境变量和完整 trace TOC；thread 可用 `target-main` 角色名。原始证据私下保留，不原地改写。脱敏派生物须单独命名并给出自己的 SHA，不能暗称与原始文件逐字节相同。

只发布安全摘要时，应明确它支持重新验证 PC→linked 指令分类和汇总算术，**不等于公开了能从原 trace 完整重导出的一切信息**。有选择地省略原始隐私数据是边界说明，不应该用“完整离线原始重放包”来形容。

## 6. 下一步的最小实验

先由 parser 验收三类代表 case 的 off/on 目标线程、raw PC→linked 指令与 coverage，保留初始折叠 pilot。按观察热点选择一个 phase/layout 转换点：例如只改变 native MMA 参数的物理快照或 packet↔program 转换，不同时改变 exec distribution、clone预算与算法。先过相同完整oracle，再用未采样同口径 ABBA 验证；若改动改变其他 live storage/代码或 clone 准入，要作为完整 realization 变化报告。采样仅用于检验解释，不进入 cost model 标定数据。

## 7. 后续归档决策（覆盖第5节的保守发布选项）

第5节记录的是最初“只公开脱敏派生物”的保守选项，并非本次最终归档范围。主任务随后明确选择：在 parser 对 schema、目标 PID/TID、frame/image 范围和路径清单做结构化检查、再由主任务复核后，公开 **两份原始、目标限定的 `time-sample.xml` / `time-profile.xml` 导出表**，以及本次 owned per-trace plan/result/run JSON 与输出。它们不等于完整 Instruments trace。

本次目标进程的 PID/TID、ASLR/image addresses、临时/项目路径和被核验的系统库路径属于明确批准的诊断证据；不把这些字段误称为继承环境。全部 `.trace`、原始 TOC、`sample.txt` 及未审核的日志/环境数据仍排除。只额外提取必要的 clock anchor，保留原 TOC 的哈希收据，不公开 TOC 内容。

原始 XML 以原字节和 SHA 保存，可独立重做 raw PC/weight 提取；`normalized-samples.json` 等则是另有 schema/SHA 的派生物，两者必须分别标明，不能把派生物的哈希当成原 XML 的哈希。打包器采用显式文件白名单及精确 XML SHA 审批，不递归收录 profiling 根目录。相关 `.dylib`、目标符号/指令映射和可重定位 parser 一并提供；完整 compiler source 与数学输入依赖已提交的原 native 实验包。

"""Pure synthetic parser checks. No native code, profiler, build or live images."""
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import unittest
import xml.etree.ElementTree as E

spec = importlib.util.spec_from_file_location('profile_parser', Path(__file__).with_name('parse_profile.py'))
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)


def table(schema, columns, rows):
    return '<trace-query-result><node><schema name="' + schema + '">' + ''.join(
        '<col><mnemonic>' + c + '</mnemonic></col>' for c in columns) + '</schema>' + rows + '</node></trace-query-result>'


class ProfileParserTests(unittest.TestCase):
    def fixture(self, root):
        (root / 'run').mkdir()
        image_root = root / 'relocated'
        image_root.mkdir()
        header = struct.pack('<8I', 0xfeedfacf, 0x100000c, 0, 6, 1, 152, 0, 0)
        segment = struct.pack('<II16sQQQQIIII', 0x19, 152, b'__TEXT', 0, 0x1000, 0, 0x1000, 5, 5, 1, 0)
        section = struct.pack('<16s16sQQIIIIIIII', b'__text', b'__TEXT', 0x100, 0x20, 0x100, 2, 0, 0, 0x80000000, 0, 0, 0)
        image = header + segment + section + bytes(0x1000 - len(header + segment + section))
        digest = hashlib.sha256(image).hexdigest()
        images = {}
        for name, base, file in [('kernel', 0x100000, 'kernel.dylib'), ('helper', 0x200000, 'replay.dylib')]:
            (image_root / file).write_bytes(image)
            images[name] = dict(resolved_path='/private/not-live/' + file, base=base, sha256=digest, entry_image_offset=0x100)
        ready = dict(pid=7, thread_id=9, images=images, object_sha256='f' * 64)
        good = dict(own_capture_bitwise_equal=True, all_guards_passed=True, inputs_unchanged=True,
                    launch_metadata_unchanged=True, call_started_monotonic_ns=10**9, call_finished_monotonic_ns=12 * 10**9)
        documents = {'ready.json': ready, 'result.json': dict(status='passed', artifacts_unchanged=True, preflight=good, profiled=good),
                     'profile-begin.json': dict(unix=100, monotonic_ns=10**9)}
        for name, data in documents.items():
            (root / 'run' / name).write_text(json.dumps(data))
        anchor = root / 'clock.json'
        anchor.write_text(json.dumps(dict(format='native-profile-clock-anchor-v1', trace_start_iso='1970-01-01T00:01:40+00:00', trace_start_unix=100, toc_sha256='a' * 64)))
        thread = '<thread><tid>9</tid><process><pid>7</pid></process></thread>'
        rows = ''
        for i, pc in enumerate((0x100100, 0x100104, 0x200100), 1):
            rows += f'<row><sample-time>{i * 10**9}</sample-time>{thread}<core>0</core><thread-state>Running</thread-state><sentinel/><kperf-bt><text-address>{pc}</text-address></kperf-bt><time-sample-kind fmt="Timer Fired">0</time-sample-kind></row>'
        raw_cols = ['time', 'thread', 'core-index', 'thread-state', 'cp-kernel-callstack', 'cp-user-callstack', 'sample-type']
        (root / 'time-sample.xml').write_text(table('time-sample', raw_cols, rows))
        prof = f'<row><sample-time>{10**9}</sample-time>{thread}<process><pid>7</pid></process><core>0</core><thread-state>Running</thread-state><weight>1000000</weight><tagged-backtrace><backtrace><frame name="kernel_test" addr="0x100101"><binary path="/private/not-live/kernel.dylib" load-addr="0x100000"/></frame></backtrace></tagged-backtrace></row>'
        profile_cols = ['time', 'thread', 'process', 'core', 'thread-state', 'weight', 'stack']
        (root / 'time-profile.xml').write_text(table('time-profile', profile_cols, prof))
        return image_root, anchor

    def test_raw_pc_survives_missing_derived_rows_and_relocation(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            images, anchor = self.fixture(root)
            summary, pcs, image, normalized, clock, privacy = p.analyze(root, images, anchor)
            self.assertEqual(summary['counts']['selected_timer_rows'], 3)
            self.assertEqual(summary['counts']['raw_kernel_leaf'], 2)
            self.assertEqual(summary['counts']['matched_kernel_leaf'], 1)
            self.assertEqual(summary['counts']['unmatched_or_ambiguous_raw_rows'], 2)
            self.assertEqual(pcs[0x104]['samples'], 1)
            self.assertEqual(pcs[0x104]['weight_ns'], 0)
            self.assertEqual(pcs[0x104]['matched_samples'], 0)
            self.assertIsNone(normalized[1]['profile_weight_ns'])
            self.assertEqual(summary['profile_leaf_minus_raw_pc_counts'], {'1': 1})

    def test_missing_ref(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.fixture(root)
            parsed = p.Table(root / 'time-sample.xml', 'time-sample')
            with self.assertRaisesRegex(ValueError, 'missing/cyclic XML ref'):
                parsed.resolve(E.fromstring('<thread ref="absent"/>'))

    def test_duplicate_id(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'bad.xml'
            path.write_text('<root><item id="1"/><other id="1"/></root>')
            with self.assertRaisesRegex(ValueError, 'duplicate XML id'):
                p.Table(path, 'time-sample')

    def test_reject_unaligned_raw_pc(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            images, anchor = self.fixture(root)
            raw = root / 'time-sample.xml'
            raw.write_text(raw.read_text().replace(str(0x100104), str(0x100105)))
            with self.assertRaisesRegex(ValueError, 'unaligned raw arm64'):
                p.analyze(root, images, anchor)

    def test_reject_wrong_process(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            images, anchor = self.fixture(root)
            raw = root / 'time-sample.xml'
            raw.write_text(raw.read_text().replace('<pid>7</pid>', '<pid>8</pid>'))
            with self.assertRaisesRegex(ValueError, 'another process/thread'):
                p.analyze(root, images, anchor)

    def test_no_dtd(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'bad.xml'
            path.write_text('<!DOCTYPE root [<!ENTITY value "private">]><root/>')
            with self.assertRaisesRegex(ValueError, 'entities/DTD'):
                p.Table(path, 'time-sample')


if __name__ == '__main__':
    unittest.main()

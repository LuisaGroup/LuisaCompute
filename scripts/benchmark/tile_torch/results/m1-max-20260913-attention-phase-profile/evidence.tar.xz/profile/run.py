"""Sample only owned replay processes; these are diagnostic, not timing cohorts."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
FROZEN = Path('/tmp/luisa-attention-native-mma.DImNTO')
CASES = ('decode-mha-d64', 'decode-gqa-d80', 'decode-long-kv', 'prefill-q4', 'prefill-q8', 'batch-gqa-q4')
CHILD = ROOT / 'profile_child.py'

def require(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    require(path.is_file() and not path.is_symlink(), 'missing/nonregular input: ' + str(path))
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

def freeze():
    expected = dict(cases=list(CASES), variants=['off', 'on'], duration_seconds=5, sampling_interval_ms=1, delay_after_go_seconds=0.25,
                    source_plan_sha256=sha(FROZEN / 'plan.json'), source_archive_sha256=sha(FROZEN / 'sources.tar.gz'),
                    scripts={p.name: sha(p) for p in (Path(__file__).resolve(), CHILD)},
                    prepared={name + '-' + arm: sha(FROZEN / ('prepared-' + name + '-' + arm) / 'prepared.json')
                              for name in CASES for arm in ('off', 'on')},
                    sampling_tool='/usr/bin/sample', python=str(Path(sys.executable).resolve()),
                    boundary='Disturbed sampling of existing native entry; no benchmark gain or cost calibration. Filter PCs to the recorded kernel image.')
    path = ROOT / 'plan.json'
    if path.exists():
        require(all(json.loads(path.read_text()).get(k) == v for k, v in expected.items()), 'frozen profile plan changed')
    else:
        save(path, dict(**expected, frozen_unix=time.time()))
    return sha(path)

def run(name, arm, plan_hash):
    label = name + '-' + arm
    directory = ROOT / label
    directory.mkdir()
    env = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_'))}
    env.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    argv = [sys.executable, '-B', str(CHILD), '--prepared', str(FROZEN / ('prepared-' + label) / 'prepared.json'),
            '--output', str(directory / 'run')]
    record = dict(status='Running', command=argv, started=time.time(), plan_sha256=plan_hash,
                  process_group_isolated=True, environment={k: env[k] for k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')})
    save(directory / 'child.command.json', record)
    process = None
    stdout = b''
    try:
        with (directory / 'child.stderr').open('xb') as stderr:
            process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr, env=env, start_new_session=True)
            require(select.select([process.stdout], [], [], 15)[0], 'no validated READY within 15 seconds')
            line = process.stdout.readline()
            stdout += line
            ready = json.loads(line)
            require(ready.get('event') == 'READY' and ready['pid'] == process.pid, 'child did not acknowledge validated readiness')
            record['ready'] = ready
            process.stdin.write(b'GO\n')
            process.stdin.flush()
            record['go_sent_unix'] = time.time()
            time.sleep(0.25)
            sample_argv = ['/usr/bin/sample', str(process.pid), '5', '1', '-mayDie', '-fullPaths', '-file', str(directory / 'sample.txt')]
            sample = dict(command=sample_argv, started=time.time(), pid=process.pid, timeout_seconds=15)
            save(directory / 'sample.command.json', sample)
            with (directory / 'sample.stdout').open('xb') as sample_out, (directory / 'sample.stderr').open('xb') as sample_err:
                sampled = subprocess.run(sample_argv, stdout=sample_out, stderr=sample_err, timeout=15)
            sample.update(returncode=sampled.returncode, finished=time.time())
            save(directory / 'sample.result.json', sample)
            tail, _ = process.communicate(timeout=25)
            stdout += tail
            record['returncode'] = process.returncode
            require(process.returncode == 0, 'child failed full post-sampling validation')
            lines = [json.loads(line) for line in stdout.splitlines()]
            require(lines[-1].get('event') == 'RESULT' and lines[-1].get('status') == 'passed', 'missing successful complete child result')
            require(sampled.returncode == 0 and (directory / 'sample.txt').stat().st_size > 0, 'sampler failed; retain native validation separately')
            record.update(status='OK', result=lines[-1], sample_sha256=sha(directory / 'sample.txt'))
    except BaseException as error:
        record.update(status='Error', error=str(error))
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            tail, _ = process.communicate()
            stdout += tail
            record['returncode'] = process.returncode
        raise
    finally:
        with (directory / 'child.stdout').open('xb') as stream:
            stream.write(stdout)
        record['finished'] = time.time()
        save(directory / 'child.result.json', record)
    require(freeze() == plan_hash, 'profile identities changed')
    print(label, record['status'], flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', choices=CASES, action='append')
    parser.add_argument('--arm', choices=('off', 'on'), action='append')
    args = parser.parse_args()
    plan_hash = freeze()
    for name in args.case or CASES:
        for arm in args.arm or ('off', 'on'):
            run(name, arm, plan_hash)

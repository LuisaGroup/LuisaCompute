#!/usr/bin/env python3
"""Read-only trace analysis; writes only NEW_DIR, never loads native code.

python3 -B parse_profile.py --trace-dir TRACE_DIR --output NEW_DIR
Raw Timer Fired rows are counted once each; Stackshot rows are retained as a
separate excluded category. Join time-profile by exact (timestamp, thread ID)
to recover its explicit nanosecond weight and symbolicated frames. The actual
leaf instruction PC always comes from time-sample, never rounded from frames.
Only ready.json's exact image path/base and its hashed Mach-O code sections
admit a kernel PC. Incomplete unwind makes inclusive libc counts lower bounds.
Public outputs contain relative PCs/symbols/hashes, not private trace metadata.
"""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime
import hashlib
import json
from pathlib import Path
import struct
import xml.etree.ElementTree as E


def need(value, message):
    if not value:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def macho_image(image, image_root=None):
    original = Path(image['resolved_path'])
    path = image_root / original.name if image_root is not None else original
    data = path.read_bytes()
    need(hashlib.sha256(data).hexdigest() == image['sha256'], 'loaded image file identity changed')
    header = struct.unpack_from('<8I', data)
    need(header[0] == 0xfeedfacf and header[1] == 0x100000c, 'expected thin arm64 Mach-O')
    commands, offset, segments = header[4], 32, []
    for _ in range(commands):
        command, size = struct.unpack_from('<II', data, offset)
        need(size >= 8 and offset + size <= len(data), 'invalid Mach-O command')
        if command == 0x19:
            _, _, name, vm, length, file_offset, file_size, maxprot, prot, count, flags = struct.unpack_from('<II16sQQQQIIII', data, offset)
            sections = []
            for i in range(count):
                name2, segment, addr, size2, file2, align, reloc, nreloc, attrs, r1, r2, r3 = struct.unpack_from('<16s16sQQIIIIIIII', data, offset + 72 + i * 80)
                if prot & 4 and (attrs & 0x80000400 or name2.rstrip(b'\0') in (b'__text', b'__stubs', b'__stub_helper')):
                    sections.append(dict(section=name2.rstrip(b'\0').decode(), vmaddr=addr, size=size2, file_offset=file2))
            segments.append((name.rstrip(b'\0').decode(), vm, sections))
        offset += size
    origin = [vm for name, vm, _ in segments if name == '__TEXT']
    need(len(origin) == 1, 'ambiguous __TEXT VM origin')
    sections = [dict(s, image_offset=s['vmaddr'] - origin[0]) for _, _, group in segments for s in group]
    need(sections, 'no executable sections')
    return dict(base=image['base'], path=str(original.resolve()), vm_origin=origin[0], sections=sections)


def in_image(pc, image):
    relative = pc - image['base']
    return next((s for s in image['sections'] if s['image_offset'] <= relative < s['image_offset'] + s['size']), None)


class Table:
    def __init__(self, path, schema):
        payload = path.read_bytes()
        need(b'<!DOCTYPE' not in payload.upper() and b'<!ENTITY' not in payload.upper(), 'XML entities/DTD not admitted')
        self.tree = E.ElementTree(E.fromstring(payload))
        self.ids = {e.attrib['id']: e for e in self.tree.iter() if 'id' in e.attrib}
        need(len(self.ids) == sum('id' in e.attrib for e in self.tree.iter()), 'duplicate XML id')
        nodes = [n for n in self.tree.findall('node') if n.find('schema').get('name') == schema]
        need(len(nodes) == 1, 'missing/ambiguous schema ' + schema)
        columns = [c.findtext('mnemonic') for c in nodes[0].find('schema')]
        self.rows = []
        for row in nodes[0].findall('row'):
            need(len(row) == len(columns), 'row/schema extent mismatch')
            self.rows.append(dict(zip(columns, row)))

    def resolve(self, element):
        need(element is not None, 'missing XML element')
        visited = set()
        while 'ref' in element.attrib:
            ref = element.attrib['ref']
            need(ref in self.ids and ref not in visited, 'missing/cyclic XML ref')
            visited.add(ref)
            element = self.ids[ref]
        return element

    def child(self, element, name):
        element = self.resolve(element)
        return next((self.resolve(e) for e in element if self.resolve(e).tag == name), None)

    def integer(self, element):
        return int(self.resolve(element).text)

    def identity(self, thread):
        return self.integer(self.child(thread, 'tid')), self.integer(self.child(self.child(thread, 'process'), 'pid'))


def audit_xml(table, ready):
    tags = {'boolean', 'col', 'core', 'device-session', 'engineering-type', 'kperf-bt', 'mnemonic', 'name', 'node',
            'pid', 'process', 'register-content', 'row', 'sample-time', 'schema', 'sentinel', 'text-address',
            'text-addresses', 'thread', 'thread-state', 'tid', 'time-sample-kind', 'trace-query-result',
            'backtrace', 'binary', 'frame', 'tagged-backtrace', 'uint64', 'weight'}
    attrs = {'documentation', 'fmt', 'id', 'name', 'ref', 'xpath', 'UUID', 'addr', 'arch', 'load-addr', 'path'}
    need(all(e.tag in tags and set(e.attrib) <= attrs for e in table.tree.iter()), 'unexpected XML field; privacy review required')
    for e in table.tree.iter():
        table.resolve(e)
    identities = {table.identity(row['thread']) for row in table.rows}
    need(identities == {(ready['thread_id'], ready['pid'])}, 'XML includes another process/thread')
    paths = {}
    for e in table.tree.iter('binary'):
        e = table.resolve(e)
        if 'path' in e.attrib:
            paths[e.attrib['path']] = dict(e.attrib)
    return dict(status='target_only_fields_checked', rows=len(table.rows),
                pid=ready['pid'], tid=ready['thread_id'], environment_fields_present=False,
                element_tags=sorted({e.tag for e in table.tree.iter()}),
                attributes=sorted({k for e in table.tree.iter() for k in e.attrib}),
                loaded_image_path_inventory=list(paths.values()),
                publication='Contains the scoped target PID, ASLR addresses and own/system/Python image paths; requires owner approval. No TOC/environment copied.')


def analyze(directory, image_root=None, clock_anchor_path=None):
    ready = load(directory / 'run/ready.json')
    result = load(directory / 'run/result.json')
    need(result['status'] == 'passed' and result['artifacts_unchanged'] is True, 'child did not pass complete checks')
    for phase in ('preflight', 'profiled'):
        need(all(result[phase][k] is True for k in ('own_capture_bitwise_equal', 'all_guards_passed', 'inputs_unchanged', 'launch_metadata_unchanged')),
             'missing complete child checks')
    images = {key: macho_image(ready['images'][key], image_root) for key in ('kernel', 'helper')}
    raw, profile = Table(directory / 'time-sample.xml', 'time-sample'), Table(directory / 'time-profile.xml', 'time-profile')
    privacy = dict(time_sample=audit_xml(raw, ready), time_profile=audit_xml(profile, ready))
    profile_rows = defaultdict(list)
    for row in profile.rows:
        tid, pid = profile.identity(row['thread'])
        if tid == ready['thread_id'] and pid == ready['pid']:
            profile_rows[(profile.integer(row['time']), tid)].append(row)
    counts, weights, kinds, shifts = Counter(), Counter(), Counter(), Counter()
    pcs, symbols, libraries = defaultdict(Counter), defaultdict(Counter), defaultdict(Counter)
    selected_times, joined_keys, raw_keys, normalized = [], set(), Counter(), []
    for row in raw.rows:
        kind = raw.resolve(row['sample-type']).get('fmt')
        kinds[kind] += 1
        tid, pid = raw.identity(row['thread'])
        if kind != 'Timer Fired' or tid != ready['thread_id'] or pid != ready['pid']:
            continue
        key = (raw.integer(row['time']), tid)
        raw_keys[key] += 1
        counts['selected_timer_rows'] += 1
        selected_times.append(key[0])
        bt = raw.resolve(row['cp-user-callstack'])
        pc_element = raw.child(bt, 'text-address')
        if pc_element is None:
            counts['missing_raw_leaf_pc'] += 1
            continue
        pc = raw.integer(pc_element)
        counts['raw_unaligned_leaf_pc'] += int(pc % 4 != 0)
        matching = profile_rows.get(key, [])
        matched = len(matching) == 1
        frames, weight = [], 0
        if not matched:
            counts['unmatched_or_ambiguous_raw_rows'] += 1
        else:
            joined_keys.add(key)
            derived = matching[0]
            weight = profile.integer(derived['weight'])
            need(weight > 0, 'nonpositive time-profile weight')
            counts['joined_rows'] += 1
            weights['joined_weight_ns'] += weight
            backtrace = profile.child(derived['stack'], 'backtrace')
            if backtrace is not None:
                for frame0 in backtrace:
                    frame = profile.resolve(frame0)
                    if frame.tag != 'frame':
                        continue
                    binary = profile.child(frame, 'binary')
                    frames.append(dict(pc=int(frame.get('addr'), 16), name=frame.get('name', ''),
                                       path=binary.get('path', '') if binary is not None else '',
                                       base=int(binary.get('load-addr', '0'), 16) if binary is not None else 0))
        if frames:
            shifts[str(frames[0]['pc'] - pc)] += 1
        bad_unwind = any(not f['path'] and f['pc'] < 4096 for f in frames[1:])
        counts['rows_with_small_unimaged_ancestor'] += int(bad_unwind)
        weights['small_unimaged_ancestor_ns'] += weight if bad_unwind else 0
        leaf = frames[0] if frames else dict(name='unknown', path='', base=0)
        symbol = leaf['name'] if frames and frames[0]['pc'] - pc in (0, 1) else 'unresolved'
        if in_image(pc, images['kernel']) is not None:
            category = 'kernel_leaf'
            if leaf['path']:
                need(str(Path(leaf['path']).resolve()) == images['kernel']['path'] and leaf['base'] == images['kernel']['base'],
                     'raw code PC disagrees with symbolicated kernel identity')
            relative = pc - images['kernel']['base']
            pcs[relative]['samples'] += 1
            pcs[relative]['matched_samples'] += int(matched)
            pcs[relative]['weight_ns'] += weight
            symbols[symbol]['samples'] += 1
            symbols[symbol]['weight_ns'] += weight
        elif in_image(pc, images['helper']) is not None:
            category = 'helper_leaf'
        elif leaf['path'].startswith('/usr/lib/system/libsystem_'):
            category = 'libsystem_leaf'
        elif not leaf['path']:
            category = 'unknown_leaf'
        else:
            category = 'other_leaf'
        counts['raw_' + category] += 1
        counts['matched_' + category] += int(matched)
        weights[category + '_ns'] += weight
        if category != 'kernel_leaf':
            label = (Path(leaf['path']).name or 'unknown') + ':' + symbol
            libraries[label]['samples'] += 1
            libraries[label]['weight_ns'] += weight
        ancestor = any(f['path'] and str(Path(f['path']).resolve()) == images['kernel']['path'] and f['base'] == images['kernel']['base'] for f in frames[1:])
        if category == 'libsystem_leaf' and ancestor:
            counts['observed_kernel_rooted_libsystem_leaf'] += 1
            weights['observed_kernel_rooted_libsystem_leaf_ns'] += weight
        image_key = 'kernel' if category == 'kernel_leaf' else 'helper' if category == 'helper_leaf' else None
        normalized.append(dict(time_ns=key[0], raw_category=category,
                               image_offset=pc - images[image_key]['base'] if image_key else None,
                               raw_pc_aligned=pc % 4 == 0, profile_matched=matched,
                               profile_weight_ns=weight if matched else None,
                               profile_leaf_minus_raw_pc=frames[0]['pc'] - pc if frames else None,
                               leaf_symbol=symbol, leaf_library=Path(leaf['path']).name or 'unknown',
                               small_unimaged_ancestor=bad_unwind,
                               observed_kernel_rooted_libsystem=category == 'libsystem_leaf' and ancestor))
    counts['raw_duplicate_selected_keys'] = sum(n - 1 for n in raw_keys.values())
    need(counts['raw_duplicate_selected_keys'] == 0, 'duplicate selected Timer Fired timestamps; no implicit deduplication')
    need(counts['raw_unaligned_leaf_pc'] == 0, 'unaligned raw arm64 instruction PC; no implicit normalization')
    counts['unmatched_profile_rows'] = sum(len(v) for k, v in profile_rows.items() if k not in joined_keys)
    need(selected_times, 'no selected Timer Fired rows')
    # Read only the TOC clock anchor, never copy environment/process metadata.
    if clock_anchor_path is None:
        toc = E.parse(directory / 'toc.xml')
        start_dates = toc.findall('.//start-date')
        need(len(start_dates) == 1, 'ambiguous trace clock anchor')
        clock_anchor = dict(format='native-profile-clock-anchor-v1', trace_start_iso=start_dates[0].text,
                            trace_start_unix=datetime.fromisoformat(start_dates[0].text).timestamp(),
                            toc_sha256=sha(directory / 'toc.xml'),
                            scope='Only the trace clock anchor extracted; original TOC includes private environment and is not published.')
    else:
        clock_anchor = load(clock_anchor_path)
        need(clock_anchor['format'] == 'native-profile-clock-anchor-v1', 'invalid relocated clock anchor')
        need(clock_anchor['trace_start_unix'] == datetime.fromisoformat(clock_anchor['trace_start_iso']).timestamp(), 'clock anchors disagree')
    trace_unix = clock_anchor['trace_start_unix']
    marker = load(directory / 'run/profile-begin.json')
    call = result['profiled']
    call_unix = marker['unix'] + (call['call_started_monotonic_ns'] - marker['monotonic_ns']) / 1e9
    window = [trace_unix + x / 1e9 - call_unix for x in (min(selected_times), max(selected_times))]
    summary = dict(format='native-profile-counts-v1', status='checked', performance_comparison_accepted=False,
                   inputs_sha256={name: sha(directory / name) for name in ('time-sample.xml', 'time-profile.xml', 'run/ready.json', 'run/result.json', 'run/profile-begin.json')},
                   parser_sha256=sha(Path(__file__)), kernel_image_sha256=ready['images']['kernel']['sha256'],
                   kernel_object_sha256=ready['object_sha256'], kernel_entry_image_offset=ready['images']['kernel']['entry_image_offset'],
                   mach_o_vm_origin=images['kernel']['vm_origin'], executable_sections=images['kernel']['sections'],
                   raw_row_kinds=dict(kinds), counts=dict(counts), weights_ns=dict(weights),
                   profile_leaf_minus_raw_pc_counts=dict(shifts), raw_timestamp_range_ns=[min(selected_times), max(selected_times)],
                   approximate_seconds_after_profiled_call_start=window,
                   last_sample_precedes_10s_minimum_calibration_start=window[1] < 10,
                   sampled_kernel_symbols={k: dict(v) for k, v in sorted(symbols.items(), key=lambda x: -x[1]['samples'])},
                   nonkernel_leaf_symbols={k: dict(v) for k, v in sorted(libraries.items(), key=lambda x: -x[1]['samples'])},
                   semantics=[
                       'Raw Timer Fired rows are unit observations; Stackshots excluded, not silently deduplicated.',
                       'Weights are explicit time-profile weight values in nanoseconds, not durations measured between raw rows.',
                       'Exact timestamp/thread join retains unmatched counts; fractions must state selected-row or joined-weight denominator.',
                       'PCs use raw text-address. The recorded frame-minus-PC delta is empirical, not an assumed architecture rule.',
                       'Image offset = raw PC - dladdr base. Mach-O VMaddr = image offset + __TEXT vmaddr; file offset is section-local translation, not ORC.o offset.',
                       'Observed kernel-rooted libsystem is an unwind-dependent lower bound, not proof of absent copy/allocation costs.',
                       'Trace start-date has millisecond precision; relative-window wall/monotonic alignment is approximate. Initial kernel validation invocation is not phase-marked.',
                       'Profiler perturbation, sample skid and incomplete unwinding prohibit causal or unprofiled runtime-speedup inference.'])
    summary['normalized_rows'] = len(normalized)
    return summary, pcs, images['kernel'], normalized, clock_anchor, privacy


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--trace-dir', '--directory', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--image-root', type=Path, help='Relocated directory containing hash-identical kernel.dylib/replay.dylib')
    parser.add_argument('--clock-anchor', type=Path, help='Safe clock-anchor JSON instead of the private TOC')
    args = parser.parse_args()
    summary, pcs, image, normalized, anchor, privacy = analyze(args.trace_dir.resolve(), args.image_root, args.clock_anchor)
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / 'profile-summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False) + '\n')
    (args.output / 'normalized-samples.json').write_text(json.dumps(dict(
        format='native-profile-normalized-rows-v1', source_sha256=summary['inputs_sha256'],
        raw_row_kinds=summary['raw_row_kinds'], rows=normalized), separators=(',', ':'), allow_nan=False) + '\n')
    (args.output / 'clock-anchor.json').write_text(json.dumps(anchor, indent=2, allow_nan=False) + '\n')
    (args.output / 'xml-privacy-audit.json').write_text(json.dumps(privacy, indent=2, allow_nan=False) + '\n')
    with (args.output / 'leaf-pcs.csv').open('x') as stream:
        writer = csv.writer(stream)
        writer.writerow(['image_offset_hex', 'macho_vmaddr_hex', 'linked_image_file_offset_hex', 'raw_samples', 'matched_samples', 'weight_ns'])
        for relative, value in sorted(pcs.items(), key=lambda x: (-x[1]['samples'], x[0])):
            section = in_image(image['base'] + relative, image)
            writer.writerow([hex(relative), hex(relative + image['vm_origin']),
                             hex(section['file_offset'] + relative - section['image_offset']), value['samples'], value['matched_samples'], value['weight_ns']])
    print(json.dumps(dict(counts=summary['counts'], weights_ns=summary['weights_ns'],
                          frame_pc_delta=summary['profile_leaf_minus_raw_pc_counts'],
                          kernel_symbols=summary['sampled_kernel_symbols'], nonkernel=summary['nonkernel_leaf_symbols']), indent=2))


if __name__ == '__main__':
    main()

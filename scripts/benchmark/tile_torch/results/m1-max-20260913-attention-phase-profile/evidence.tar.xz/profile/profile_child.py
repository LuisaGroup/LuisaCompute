#!/usr/bin/env python3
"""Profile an existing prepared native entry; never compile or alter its bundle.

Usage: python3 -B profile_child.py --prepared PATH/prepared.json --output NEW_DIR
The supervisor captures stdout/stderr, waits for READY, sends GO\n, profiles the
PID, and enforces a process-group deadline. Retain only kernel-image PC samples;
the enclosing helper also contains allocation/validation/clock/calibration work.
All timing here is disturbed diagnostic evidence, never a performance comparison.
"""
import argparse
import array
import ctypes as c
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import struct
import sys
import threading
import time

sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def emit(event, **fields):
    record = dict(event=event, pid=os.getpid(), thread_id=threading.get_native_id(),
                  unix=time.time(), monotonic_ns=time.monotonic_ns(), **fields)
    print(json.dumps(record, allow_nan=False), flush=True)
    return record


class DlInfo(c.Structure):
    _fields_ = [('filename', c.c_char_p), ('base', c.c_void_p),
                ('symbol', c.c_char_p), ('symbol_address', c.c_void_p)]


def image_info(function, expected_path, symbol):
    address = c.cast(function, c.c_void_p).value
    loader = c.CDLL(None)
    dladdr = loader.dladdr
    dladdr.argtypes = [c.c_void_p, c.POINTER(DlInfo)]
    dladdr.restype = c.c_int
    info = DlInfo()
    require(dladdr(address, c.byref(info)) != 0 and info.filename and info.base,
            'dladdr did not identify the loaded image')
    filename = os.fsdecode(info.filename)
    require(Path(filename).resolve() == expected_path.resolve(), 'loaded image path mismatch')
    require(info.symbol_address == address and info.symbol, 'entry symbol address is ambiguous')
    observed_symbol = os.fsdecode(info.symbol)
    require(observed_symbol.lstrip('_') == symbol.lstrip('_'), 'loaded entry symbol mismatch')
    return dict(path=filename, resolved_path=str(Path(filename).resolve()), sha256=sha(expected_path),
                base=info.base, base_hex=hex(info.base), entry_address=address, entry_hex=hex(address),
                symbol=observed_symbol, symbol_address=info.symbol_address,
                entry_image_offset=address - info.base,
                mapping='PC - base is image-relative; PC - symbol_address is symbol-relative. '
                        'Neither is automatically a relocatable ORC object section offset.')


def run(args):
    require(platform.system() == 'Darwin' and platform.machine() == 'arm64', 'Darwin arm64 only')
    manifest = args.prepared.resolve(strict=True)
    bundle = manifest.parent
    output = args.output.resolve()
    require(not output.is_relative_to(bundle), 'profile output must be outside the frozen bundle')
    output.mkdir(parents=True, exist_ok=False)
    manifest_hash, runner_hash = sha(manifest), sha(__file__)
    data = json.loads(manifest.read_bytes())
    require(data.get('status') == 'prepared' and data.get('format') == 'native-tile-entry-v1',
            'unsupported or incomplete prepared bundle')

    def verify_files():
        require(sha(manifest) == manifest_hash and sha(__file__) == runner_hash, 'manifest/driver changed')
        for name, digest in data['files'].items():
            relative = Path(name)
            path = bundle / relative
            require(not relative.is_absolute() and '..' not in relative.parts and
                    path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(bundle),
                    'unsafe/nonregular prepared artifact: ' + name)
            require(sha(path) == digest, 'prepared artifact changed: ' + name)

    verify_files()
    frozen_runner = bundle / 'native_tile.py'
    require('native_tile.py' in data['files'], 'missing frozen verifier source')
    spec = importlib.util.spec_from_file_location('frozen_native_tile_profile', frozen_runner)
    native = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    require(native.verify(manifest) == data, 'frozen native verifier disagrees')
    require(data['capture_kind'] == 'llm' and data['metadata']['operation'] == 'attention',
            'this diagnostic is restricted to the frozen attention cohort')
    require(data['metadata']['precision'] == 'fp32' and data['metadata']['fast_math'] is False and
            data['metadata']['relaxed_precision'] is False, 'expected precise FP32 capture')
    require(type(data['output_elements']) is int and 0 < data['output_elements'] <= 2**26,
            'invalid output extent')
    require(len(data['input_files']) == 3 and all(name in data['files'] for name in data['input_files']),
            'expected three inventoried attention inputs')
    expected_bytes = (bundle / 'expected.f64').read_bytes()
    require(len(expected_bytes) == 8 * data['output_elements'], 'oracle byte extent mismatch')
    expected_values = array.array('d', expected_bytes)
    require(all(math.isfinite(x) for x in expected_values), 'nonfinite oracle')
    inputs = [(bundle / name).read_bytes() for name in data['input_files']]
    for payload, shape in zip(inputs, data['metadata']['input_shapes']):
        require(shape and all(type(x) is int and x > 0 for x in shape) and
                len(payload) == 4 * math.prod(shape), 'input byte extent mismatch')
        require(all(math.isfinite(x) for x in array.array('f', payload)), 'nonfinite input')
    captured = (bundle / 'captured.f32').read_bytes()
    require(len(captured) == 4 * data['output_elements'], 'capture byte extent mismatch')
    native.check_output(array.array('f', captured), expected_values, data['atol'], data['rtol'])
    require(data['abi'] in (0, 2) and 0 <= data['workspace_bytes'] <= 16 * 1024**2,
            'unsupported entry ABI/workspace')
    for field in ('dispatch', 'block'):
        require(len(data[field]) == 3 and all(type(x) is int and 0 < x <= 0xffffffff for x in data[field]),
                'invalid launch ' + field)
    width = data['packet_width']
    require(type(width) is int and 0 < width <= 64 and width & (width - 1) == 0 and
            math.prod(data['block']) % width == 0, 'invalid packet width')
    p, u32, size, d = c.c_void_p, c.c_uint32, c.c_size_t, c.c_double
    kernel_library = c.CDLL(str(bundle / 'kernel.dylib'))
    helper_library = c.CDLL(str(bundle / 'replay.dylib'))
    entry = getattr(kernel_library, data['symbol'])
    helper = helper_library.replay_native_tile
    helper.argtypes = [p, u32, u32, c.POINTER(p), c.POINTER(size), c.POINTER(u32), c.POINTER(c.POINTER(d)),
                       c.POINTER(u32), c.POINTER(u32), u32, size, u32, u32, u32, d, d,
                       c.POINTER(d), c.POINTER(c.c_uint64), c.POINTER(d)]
    helper.restype = c.c_int
    images = dict(kernel=image_info(entry, bundle / 'kernel.dylib', data['symbol']),
                  helper=image_info(helper, bundle / 'replay.dylib', 'replay_native_tile'))
    expected = (d * data['output_elements']).from_buffer_copy(expected_bytes)
    nan_output = struct.pack('f', float('nan')) * len(expected)
    owners = [c.create_string_buffer(raw, len(raw)) for raw in [*inputs, nan_output]]
    count = len(owners)
    pointers = (p * count)(*(c.addressof(owner) for owner in owners))
    sizes = (size * count)(*(c.sizeof(owner) for owner in owners))
    writable = (u32 * count)(0, 0, 0, 1)
    oracles = (c.POINTER(d) * count)(None, None, None, expected)
    dispatch, block = (u32 * 3)(*data['dispatch']), (u32 * 3)(*data['block'])

    def invoke(phase, samples_count, warmup_ms, target_ms):
        c.memmove(owners[-1], nan_output, len(nan_output))
        samples, repetitions, error = (d * samples_count)(), c.c_uint64(), d()
        start = time.monotonic_ns()
        result = helper(c.cast(entry, p), data['abi'], count, pointers, sizes, writable, oracles,
                        dispatch, block, width, data['workspace_bytes'], samples_count, warmup_ms, target_ms,
                        data['atol'], data['rtol'], samples, c.byref(repetitions), c.byref(error))
        end = time.monotonic_ns()
        actual = bytes(owners[-1])
        (output / (phase + '.f32')).write_bytes(actual)
        require(result == 0, 'native helper failure ' + str(result) + ' during ' + phase)
        check = native.check_output(array.array('f', actual), expected_values, data['atol'], data['rtol'])
        require(actual == captured, 'output differs bitwise from this entry capture')
        require(all(bytes(owner) == payload for owner, payload in zip(owners[:-1], inputs)), 'caller input changed')
        require(math.isfinite(error.value), 'invalid helper error')
        require(not samples_count or (repetitions.value > 0 and all(math.isfinite(x) and x > 0 for x in samples)),
                'invalid diagnostic helper sample')
        return dict(phase=phase, returncode=result, correctness=check, output_sha256=hashlib.sha256(actual).hexdigest(),
                    own_capture_bitwise_equal=True, all_guards_passed=True, inputs_unchanged=True,
                    launch_metadata_unchanged=True, helper_max_abs_error=error.value,
                    call_started_monotonic_ns=start, call_finished_monotonic_ns=end,
                    sample_count=samples_count, warmup_ms=warmup_ms, target_ms=target_ms,
                    disturbed_samples_us=list(samples), repetitions=repetitions.value)

    preflight = invoke('preflight', 0, 0, 0)
    verify_files()
    identity = dict(prepared=str(manifest), prepared_sha256=manifest_hash, driver_sha256=runner_hash,
                    object_sha256=data['files']['kernel.o'], images=images, abi=data['abi'],
                    dispatch=data['dispatch'], block=data['block'], packet_width=width,
                    workspace_bytes=data['workspace_bytes'], performance_comparison_accepted=False)
    ready = emit('READY', **identity, preflight=preflight)
    save(output / 'ready.json', ready)
    require(sys.stdin.readline(16) == 'GO\n', 'expected supervisor GO line')
    begin = emit('PROFILE_BEGIN', warmup_ms=10000, requested_parent_sample_seconds=5)
    save(output / 'profile-begin.json', begin)
    profiled = invoke('profiled', 1, 10000, 1)
    verify_files()
    require(native.verify(manifest) == data, 'frozen verifier changed after profiling')
    result = emit('RESULT', status='passed', **identity, preflight=preflight, profiled=profiled,
                  artifacts_unchanged=True,
                  scope='Sample kernel image PCs only. Helper phases/clock and Python are not kernel cost. '
                        'The profiled sample is disturbed and is not an ABBA performance comparison.')
    save(output / 'result.json', result)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepared', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        run(args)
    except Exception as error:
        emit('RESULT', status='error', error=repr(error), performance_comparison_accepted=False)
        raise SystemExit(1)

"""Detailed own-process Time Profiler fallback; keeps the collapsed sample pilot."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
OLD = Path('/tmp/luisa-attention-native-mma.DImNTO')

def require(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--case', choices=('decode-mha-d64', 'decode-gqa-d80', 'decode-long-kv', 'prefill-q4', 'prefill-q8', 'batch-gqa-q4'), required=True)
parser.add_argument('--arm', choices=('off', 'on'), required=True)
args = parser.parse_args()
label = args.case + '-' + args.arm
folder = ROOT / ('trace-' + label)
folder.mkdir()
manifest = OLD / ('prepared-' + label) / 'prepared.json'
argv = [sys.executable, '-B', str(ROOT / 'profile_child.py'), '--prepared', str(manifest), '--output', str(folder / 'run')]
record = dict(status='Running', started=time.time(), command=argv, manifest_sha256=sha(manifest),
              child_sha256=sha(ROOT / 'profile_child.py'), driver_sha256=sha(Path(__file__)), performance_comparison_accepted=False)
save(folder / 'plan.json', record)
env = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_'))}
env.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
process = None
stdout = b''
try:
    with (folder / 'child.stderr').open('xb') as error:
        process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=error, env=env, start_new_session=True)
        require(select.select([process.stdout], [], [], 15)[0], 'READY timeout')
        first = process.stdout.readline()
        stdout += first
        ready = json.loads(first)
        require(ready.get('event') == 'READY' and ready['pid'] == process.pid, 'child failed validation readiness')
        record['ready'] = ready
        process.stdin.write(b'GO\n')
        process.stdin.flush()
        record['go_sent_unix'] = time.time()
        trace_argv = ['xcrun', 'xctrace', 'record', '--template', 'Time Profiler', '--attach', str(process.pid),
                      '--time-limit', '5s', '--output', str(folder / 'recording.trace'), '--no-prompt']
        trace = dict(command=trace_argv, started=time.time())
        save(folder / 'trace.command.json', trace)
        with (folder / 'trace.stdout').open('xb') as out, (folder / 'trace.stderr').open('xb') as err:
            result = subprocess.run(trace_argv, stdout=out, stderr=err, timeout=25)
        trace.update(returncode=result.returncode, finished=time.time())
        save(folder / 'trace.result.json', trace)
        tail, _ = process.communicate(timeout=20)
        stdout += tail
        record['returncode'] = process.returncode
        require(process.returncode == 0 and json.loads(stdout.splitlines()[-1]).get('status') == 'passed', 'native postvalidation failed')
        require(result.returncode == 0, 'Time Profiler failed; native validation is retained separately')
        record.update(status='OK', result=json.loads(stdout.splitlines()[-1]))
except BaseException as error:
    record.update(status='Error', error=str(error))
    if process is not None and process.poll() is None:
        os.killpg(process.pid, signal.SIGKILL)
        tail, _ = process.communicate()
        stdout += tail
        record['returncode'] = process.returncode
    raise
finally:
    with (folder / 'child.stdout').open('xb') as stream:
        stream.write(stdout)
    record['finished'] = time.time()
    save(folder / 'result.json', record)
print(label, record['status'])

# MHA-on：实际 linked image 的保守阶段映射

分析对象是 READY 中 `dladdr` 实际解析到的 `kernel.dylib`，不是另行从 LLVM
源码重编译的模块。实文件 SHA256 与 READY 完全一致：
`92a087653c8156dd8bb5e3b36c97c0ddc89f4f215eb5cc5a1a65d63a14c60d85`。
原 capture object 也匹配 READY 的
`c3cd82e678a9ea6f77c85dcf51ddf422c11a7275b589b082ca159fc5d8b8ca4e`。

## 地址规则

- `dladdr` image base：`0x103f78000`。
- linked `_llm_attention`：`[0x350,0x1d690)`，runtime 起点 `0x103f78350`。
- linked `_llm_attention.packet_batch.blocks`：`[0x1d690,0x1d8ac)`；runtime
  entry `0x103f95690` 与 READY 完全相符。
- 原 ORC object 的 body 从0开始、wrapper从`0x1d340`开始。两个完整
  disassembly 都有30039条指令，全部地址一一相差`0x350`。983条编码不同，
  仅涉及454条 ADRP、517条 LDR、12条 BL；不是整份机器码逐字相同的声明。
- 分类使用原始 `time-sample` leaf PC 减 image base，必须四字节对齐。
  `time-profile` 的展示 frame 地址在交叉检查中比 raw PC 多1；不拿它直接
  对齐、不从任意地址盲减1。无可靠 native unwind 的 inclusive stack 不计入阶段归因。

## 已证实的区间

完整19个半开区间在 `phase-ranges.json`；有界逐指令摘录在
`phase-excerpts.txt`。未覆盖地址明确保留为 unclassified。

| 阶段 | image-relative 区间 | 证据 |
|---|---|---|
| K定义快照拷贝 | `[0x9c10,0x9e08)` | x4由argument_buffer+16加载；1024个元素、八条带mask的program scalar gather/scatter路径 |
| V定义快照拷贝 | `[0x9e50,0xa01c)` | x5由argument_buffer+32加载；同样1024元素的scalar lane循环 |
| QK | 八个离散循环，首个`[0xab4c,0xac3c)`，最后`[0xb328,0xb418)` | 每循环16个D方向vector MUL、原水平树、16个score；Q从固定基址逐score重读 |
| PV | 八个离散循环，首个`[0x11e9c,0x11f94)`，最后`[0x126dc,0x127d4)` | 16次有序贡献；P标量广播、V四列vector，64列分16组 |
| 最终归一化、输出scatter与epilogue | `[0x1631c,0x1d690)` | pipeline出口跳至0x1631c；acc/row_sum、输出base来自argument_buffer+48；包括cold masked-store块 |

K/V不仅由代码排列顺序推测：`kernel.ll:437–448`定义K `%38`、V `%44`；
`direct.schedule.3/4`从`%38`读取并写`tile_snapshot.spill166`，
`direct.schedule.6/7`从`%44`读取并写`tile_snapshot.spill168`。机器码
`0x8468/0x846c`分别加载x4/x5，热点循环的源地址恰从这两个寄存器派生。
循环每轮index加1、byte offset加4、在0x1000结束，构成精确1024元素遍历。
所以它们是输入到私有快照的拷贝，并非QK/PV算术，也不是memcpy调用；
此dylib没有未解析import。

## 不作过度拆分

`[0xb418,0x11e70)`含QK结果投影、max/exp/probability、rescale和快照读写。
可确认原在线softmax的存在，例如`0xba08/0xba0c`的fmaxnm、
`0xba40`开始的exp范围检查/ln2多项式、`0xd870`起alpha的exp与seed rescale；
这些都与保存LLVM的native exp helper相符。但机器指令已经交错，不能把整个
区间当作纯exp成本。`[0x127d4,0x1631c)`也混有PV结果投影、carry搬运和
延后安排的row_sum更新。这两个粗上下文区间不参与默认精确阶段统计。

采样PC落在copy循环只支持“执行时间集中于该实现区域”，不能分别证明DRAM
带宽、cache miss、branch、地址生成或spill的因果比例；采样skid仍存在。
没有可靠调用链也不能外推inclusive helper开销。

## 优化优先级

独立parser v3补齐4个没有time-profile行的原始Timer样本后，统计K2381、V2349，
共4730/5574个Timer Fired leaf样本。初步matched-only分子4727已经过时；
最终窗口、原始权重和遗漏行以独立parser结果为准，不把这当作
未受profile影响的性能测量。这个证据使通用快照copy traversal成为比单独
native输出R分组更优先的下一候选：保留定义时刻和bounds，把
`(element,program lane)`改为`(program lane,contiguous element vector)`。
仍需actual entry A/B验证，不能由样本比例直接预测可达到的加速。

本次没有修改仓库、构建或运行新kernel/benchmark。命令、hash与解析失败记录
见同目录receipts及`analysis-notes.md`。

## Long-KV / batch 的补充

Long-KV的实际函数是`_llm_attention.full_packet`，linked body从`0x438`开始。
两处可证实的输入copy区间为`[0x13c4,0x14d8)`和`[0x14e8,0x15fc)`，
每处遍历2048元素：full-packet去除了program active-mask分支，但没有把
element→program scalar gather/scatter改成program→contiguous vector。
独立parser v3统计两者2221+2189=4410/5409 raw Timer leaf样本。
相应image身份、命令与独立区间文件保存在`decode-long-kv/`。

Batch-on的hot PCs落在复杂structured-mask CFG中。可看见640/768元素循环
及大量mask构造/转换，但尚未为其跨地址布局的全部代码块建立可审查的源数据流
对应。`batch-gqa-q4/phase-ranges.json`明确发布空分类，保持unclassified；
不把MHA区间或百分比套过来。

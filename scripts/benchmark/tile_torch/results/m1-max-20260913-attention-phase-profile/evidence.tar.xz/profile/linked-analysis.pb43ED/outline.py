#!/usr/bin/env python3
"""Parse saved disassembly only; optional address-bounded stdout excerpt."""
import json
from bisect import bisect_left, bisect_right
from pathlib import Path
import re
import sys
ROOT = Path(__file__).resolve().parent
def parse(name):
    rows = {}
    for line in (ROOT / name).read_text().splitlines():
        m = re.match(r'\s*([0-9a-f]+):\s+([0-9a-f]{8})\s+(.+)', line)
        if m:
            rows[int(m[1], 16)] = (m[2], m[3])
    return rows
linked = parse('linked-disassembly.stdout')
obj = parse('object-disassembly.stdout')
if len(sys.argv) == 3:
    begin, end = (int(x, 16) for x in sys.argv[1:])
    for addr, (word, text) in linked.items():
        if begin <= addr < end:
            print(f'{addr:08x}: {word} {text}')
    raise SystemExit(0)
assert len(linked) == len(obj)
changes = []
for address, (word, text) in obj.items():
    actual = linked[address + 0x350]
    if word != actual[0]:
        changes.append({'object_address': hex(address), 'linked_address': hex(address+0x350),
                        'object': text, 'linked': actual[1]})
loops = []
addresses = list(linked)
instructions = [x[1] for x in linked.values()]
for address, (word, text) in linked.items():
    m = re.match(r'(b\.[a-z]+|cbnz|cbz|tbnz|tbz)\s+.*?(0x[0-9a-f]+)\s+<', text)
    if m and (start := int(m[2], 16)) < address:
        body = instructions[bisect_left(addresses, start):bisect_right(addresses, address)]
        loops.append({'begin': hex(start), 'end_exclusive': hex(address+4),
                      'branch': text, 'instructions': len(body),
                      'fmul': sum(x.startswith('fmul') for x in body),
                      'fadd': sum(x.startswith('fadd') for x in body),
                      'ld1': sum(x.startswith('ld1') for x in body),
                      'st1': sum(x.startswith('st1') for x in body)})
report = {'instruction_count': len(linked), 'address_delta': '0x350',
          'word_changes': changes, 'backward_conditional_branches': loops}
(ROOT / 'instruction-outline.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'instruction_count': len(linked), 'word_changes': len(changes),
                  'backward_conditional_branches': len(loops)}))

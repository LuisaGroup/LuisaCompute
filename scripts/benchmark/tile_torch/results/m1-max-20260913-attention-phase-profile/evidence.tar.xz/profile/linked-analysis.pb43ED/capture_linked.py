#!/usr/bin/env python3
"""Read-only linked-image evidence capture; never execute the inspected code."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
case = sys.argv[1] if len(sys.argv) > 1 else 'decode-mha-d64'
assert case in ('decode-mha-d64', 'decode-long-kv', 'batch-gqa-q4')
ROOT = BASE if case == 'decode-mha-d64' else BASE / case
ROOT.mkdir(exist_ok=True)
READY = BASE.parent / f'trace-{case}-on/run/ready.json'
ready = json.loads(READY.read_text())
image = Path(ready['images']['kernel']['resolved_path'])
obj = image.with_name('kernel.o')
LLVM = Path('/opt/homebrew/opt/llvm/bin')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def capture(label, argv):
    start = time.time()
    result = subprocess.run([str(a) for a in argv], capture_output=True, check=False)
    stdout = ROOT / f'{label}.stdout'
    stderr = ROOT / f'{label}.stderr'
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    receipt = {'argv': [str(a) for a in argv], 'started_unix': start,
               'finished_unix': time.time(), 'returncode': result.returncode,
               'stdout': stdout.name, 'stdout_sha256': sha(stdout),
               'stderr': stderr.name, 'stderr_sha256': sha(stderr)}
    (ROOT / f'{label}.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if result.returncode:
        raise SystemExit(f'{label} failed: {result.returncode}')

assert sha(image) == ready['images']['kernel']['sha256']
assert sha(obj) == ready['object_sha256']
identity = {'ready_path': str(READY), 'ready_sha256': sha(READY),
            'kernel_path': str(image), 'kernel_sha256': sha(image),
            'object_path': str(obj), 'object_sha256': sha(obj),
            'images': ready['images'],
            'tools': {str(LLVM / name): sha(LLVM / name)
                      for name in ('llvm-nm', 'llvm-objdump')}}
(ROOT / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
for name, file in (('linked', image), ('object', obj)):
    capture(f'{name}-symbols', [LLVM/'llvm-nm', '--defined-only', file])
    capture(f'{name}-sections', [LLVM/'llvm-objdump', '--section-headers', file])
    capture(f'{name}-disassembly', [LLVM/'llvm-objdump', '--disassemble', file])
capture('linked-imports', [LLVM/'llvm-nm', '--undefined-only', image])
print(json.dumps({'status': 'captured', 'root': str(ROOT), 'identity': identity}))

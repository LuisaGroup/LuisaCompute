#!/usr/bin/env python3
"""Conservative additional-image ranges; no inference from MHA's code offsets."""
import hashlib
import json
from pathlib import Path
import re
BASE = Path(__file__).resolve().parent
for name in ('decode-long-kv','batch-gqa-q4'):
    root=BASE/name
    identity=json.loads((root/'identity.json').read_text())
    rows={}
    for line in (root/'linked-disassembly.stdout').read_text().splitlines():
        m=re.match(r'\s*([0-9a-f]+):\s+[0-9a-f]{8}\s+(.+)',line)
        if m:
            rows[int(m[1],16)]=m[2]
    intervals=[]
    if name=='decode-long-kv':
        for phase,begin,end in [('K_definition_snapshot_copy_full_packet',0x13c4,0x14d8),
                               ('V_definition_snapshot_copy_full_packet',0x14e8,0x15fc)]:
            assert begin in rows and end-4 in rows
            assert rows[end-4].startswith('b\t') and hex(begin) in rows[end-4]
            body=[t for a,t in rows.items() if begin<=a<end]
            assert sum(t.startswith('fmul') or t.startswith('fadd') for t in body)==0
            intervals.append({'phase':phase,'begin':begin,'end_exclusive':end,
                              'begin_hex':hex(begin),'end_exclusive_hex':hex(end),
                              'evidence':'2048-element scalar gather/scatter copy inside full_packet. '
                                         'argument_buffer+16 -> x10 -> [sp+0xd58] -> x1 for K; '
                                         '+32 -> x11 -> [sp+0xd50] -> x1 for V. '
                                         'Per-program bounds fill remains; active-lane mask removed only.'})
        body_begin,body_end=0x438,0x52fc
        note='Only the full_packet copy ranges are classified; wrapper inlined fallback and all other PCs remain unclassified.'
    else:
        body_begin,body_end=0x350,0x2b334
        note=('Structured mask CFG has640/768-element loops at0x6c78/0x7f50, '
             'but their discontiguous machine blocks were not fully mapped to typed buffer reads. '
             'No defensible full-loop interval is published: all batch PCs remain unclassified.')
    report={'format':'linked-instruction-phase-ranges-v1','image_sha256':identity['kernel_sha256'],
            'object_sha256':identity['object_sha256'],'image_base':identity['images']['kernel']['base'],
            'body_begin':body_begin,'body_end_exclusive':body_end,
            'address_rule':'Exact raw leaf PC minus this image base; require 4-byte alignment.',
            'classification':note,'ranges':intervals}
    (root/'phase-ranges.json').write_text(json.dumps(report,indent=2)+'\n')
    with (root/'phase-excerpts.txt').open('w') as output:
        output.write(note+'\n')
        for item in intervals:
            output.write(f"\n{item['phase']} [{item['begin_hex']},{item['end_exclusive_hex']})\n")
            for address,text in rows.items():
                if item['begin']<=address<item['end_exclusive']:
                    output.write(f'{address:08x}: {text}\n')
    print(name,len(intervals),hashlib.sha256((root/'phase-ranges.json').read_bytes()).hexdigest())

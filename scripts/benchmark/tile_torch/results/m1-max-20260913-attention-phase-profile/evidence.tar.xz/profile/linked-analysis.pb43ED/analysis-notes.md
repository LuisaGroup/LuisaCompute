# Analysis execution notes

No repository files, build outputs or kernels were changed or executed. The
scripts only inspect already captured linked images and their saved text.

- The initial outline parser accidentally selected the bit-number hexadecimal
  literal in `tbz/tbnz` as the branch target. Its output is retained as
  `instruction-outline.initial-invalid.json` and MUST NOT be used. The corrected
  parser requires the address immediately preceding the symbol annotation.
- The first phase validation expected 128 static vector divides from logical
  output cardinality. It failed: the optimized linked image contains 182 static
  vector divides, including cold-path instruction duplication. The check was
  corrected to the inspected actual count; no code was changed to fit a test.
- The initial capture script was called `inspect.py`, shadowing Python's stdlib
  module during traceback rendering. This caused the same seven read-only
  inspection commands to run again on the unchanged inputs. It was renamed to
  `capture_linked.py`; saved receipts represent the final successful capture.
  `__pycache__` is not evidence and must not be packaged.
- The first additional-image script invocation failed before execution because
  a multi-line string lacked parentheses; this syntax error was corrected.

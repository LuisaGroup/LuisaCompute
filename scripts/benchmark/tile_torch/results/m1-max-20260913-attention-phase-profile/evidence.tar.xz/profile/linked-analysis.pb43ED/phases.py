#!/usr/bin/env python3
"""Machine-readable conservative phase ranges from inspected exact linked code."""
import hashlib
import json
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parent
rows = {}
for line in (ROOT/'linked-disassembly.stdout').read_text().splitlines():
    m = re.match(r'\s*([0-9a-f]+):\s+[0-9a-f]{8}\s+(.+)', line)
    if m:
        rows[int(m[1], 16)] = m[2]
identity = json.loads((ROOT/'identity.json').read_text())
ranges = []
def add(phase, begin, end, evidence, **extra):
    assert begin in rows and end-4 in rows
    ranges.append({'phase': phase, 'begin': begin, 'end_exclusive': end,
                   'begin_hex': hex(begin), 'end_exclusive_hex': hex(end),
                   'evidence': evidence, **extra})
add('K_definition_snapshot_copy', 0x9c10, 0x9e08,
    'Source x4 loaded from argument_buffer+16 at 0x8468; destination private handle. '
    '1024-element loop, 8 active-program scalar gather/scatter paths. LLVM lines1833-1881, operand%38.')
add('V_definition_snapshot_copy', 0x9e50, 0xa01c,
    'Source x5 loaded from argument_buffer+32 at 0x846c; destination private handle. '
    '1024-element loop, 8 active-program scalar gather/scatter paths. LLVM lines1897-1945, operand%44.')
qk = [(0xab4c,0xac3c),(0xac68,0xad58),(0xad88,0xae78),(0xaea8,0xaf98),
      (0xafc8,0xb0b8),(0xb0e8,0xb1d8),(0xb208,0xb2f8),(0xb328,0xb418)]
pv = [(0x11e9c,0x11f94),(0x11fc4,0x120bc),(0x120f8,0x121f0),(0x1222c,0x12324),
      (0x12354,0x1244c),(0x1247c,0x12574),(0x125ac,0x126a4),(0x126dc,0x127d4)]
for phase, intervals, adds in [('QK_contraction_score_loop',qk,19),('PV_output_vector_loop',pv,16)]:
    for lane,(begin,end) in enumerate(intervals):
        body = [t for a,t in rows.items() if begin<=a<end]
        assert sum(t.startswith('fmul') for t in body)==16
        assert sum(t.startswith('fadd') for t in body)==adds
        assert rows[end-4].startswith('b.ne') and hex(begin) in rows[end-4]
        add(phase,begin,end,
            'QK:16 D-vector products plus per-output tree,16 scores; PV:16 ordered P*V updates,16 output groups. '
            'Matched original typed helper and inspected backedge; setup/mask gaps excluded.',program_lane=lane)
add('final_normalization_output_scatter_epilogue',0x1631c,0x1d690,
    'Pipeline exit0x9b78 targets0x1631c; fdiv.4s then masked output stores and function epilogue/cold store blocks. '
    'Output base loaded from argument_buffer+48 at0x8470. LLVM direct.schedule.15 and final O.store(acc/row_sum).')
assert sum(t.startswith('fdiv') for a,t in rows.items() if 0x1631c<=a<0x1d690)==182
for left,right in zip(sorted(ranges,key=lambda x:x['begin']),sorted(ranges,key=lambda x:x['begin'])[1:]):
    assert left['end_exclusive']<=right['begin']
report = {
    'format':'linked-instruction-phase-ranges-v1',
    'image_sha256':identity['kernel_sha256'],
    'object_sha256':identity['object_sha256'],
    'image_base':identity['images']['kernel']['base'],
    'body_begin':0x350,'body_end_exclusive':0x1d690,
    'wrapper_begin':0x1d690,'text_end_exclusive':0x1d8ac,
    'object_to_linked_text_delta':0x350,
    'address_rule':'Use exact raw time-sample leaf PC minus dladdr image base. Require 4-byte alignment. '
                   'Do not use unaligned time-profile frame addresses or silently round/subtract1.',
    'classification':'Half-open image-relative ranges, leaf-only. All omitted PCs remain unclassified. '
                     'Sampling skid prevents assigning individual memory-instruction latency.',
    'ranges':ranges,
    'coarse_context_not_used_for_default_attribution':[
        {'begin':0xb418,'end_exclusive':0x11e70,'context':'post-QK softmax/exp/probability/rescale and snapshot materialization; not pure arithmetic'},
        {'begin':0x127d4,'end_exclusive':0x1631c,'context':'PV result projection, carry state and deferred row-sum update; not pure copies'}],
    'unclassified_detail':'No separate memcpy call exists in this dylib. Initialization, other snapshots, '
                          'softmax/exp mixed regions, loop control and spills are not apportioned into pure causes.'}
(ROOT/'phase-ranges.json').write_text(json.dumps(report,indent=2)+'\n')
with (ROOT/'phase-excerpts.txt').open('w') as output:
    for item in ranges:
        output.write(f"\n{item['phase']} [{item['begin_hex']},{item['end_exclusive_hex']})\n")
        if item['phase'].startswith('final_'):
            continue
        for address,text in rows.items():
            if item['begin']<=address<item['end_exclusive']:
                output.write(f'{address:08x}: {text}\n')
print(json.dumps({'status':'passed','ranges':len(ranges),'phase_ranges_sha256':hashlib.sha256((ROOT/'phase-ranges.json').read_bytes()).hexdigest()}))

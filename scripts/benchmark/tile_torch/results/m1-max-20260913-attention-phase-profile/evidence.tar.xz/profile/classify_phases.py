#!/usr/bin/env python3
"""Classify exact raw leaf PCs using reviewed, image-bound half-open ranges.

No native execution, disassembly inference or broad phase interpolation. Gaps
remain unclassified. Counts and derived weights retain separate denominators.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def classify(analysis, rules_path):
    summary = json.loads((analysis / 'profile-summary.json').read_bytes())
    normalized = json.loads((analysis / 'normalized-samples.json').read_bytes())
    rules = json.loads(rules_path.read_bytes())
    need(rules['image_sha256'] == summary['kernel_image_sha256'], 'phase map belongs to another linked image')
    if 'object_sha256' in rules:
        need(rules['object_sha256'] == summary['kernel_object_sha256'], 'phase map belongs to another ORC object')
    ranges = sorted(rules['ranges'], key=lambda r: r['begin'])
    for i, r in enumerate(ranges):
        need(type(r['begin']) is int and type(r['end_exclusive']) is int and
             0 <= r['begin'] < r['end_exclusive'] and r['begin'] % 4 == r['end_exclusive'] % 4 == 0,
             'invalid arm64 half-open instruction range')
        need(not i or ranges[i - 1]['end_exclusive'] <= r['begin'], 'overlapping phase ranges')
    groups = {r['phase']: Counter() for r in ranges}
    groups['unclassified_kernel'] = Counter()
    groups['outside_kernel'] = Counter()
    rows = normalized['rows']
    need(len(rows) == summary['counts']['selected_timer_rows'], 'normalized rows omit raw Timer Fired observations')
    for row in rows:
        if row['raw_category'] != 'kernel_leaf':
            label = 'outside_kernel'
        else:
            pc = row['image_offset']
            need(row['raw_pc_aligned'] is True and type(pc) is int and pc % 4 == 0, 'unaligned/missing exact kernel PC')
            hits = [r for r in ranges if r['begin'] <= pc < r['end_exclusive']]
            label = hits[0]['phase'] if hits else 'unclassified_kernel'
        group = groups[label]
        group['raw_samples'] += 1
        group['matched_samples'] += int(row['profile_matched'])
        if row['profile_matched']:
            need(type(row['profile_weight_ns']) is int and row['profile_weight_ns'] > 0, 'invalid derived sample weight')
            group['weight_ns'] += row['profile_weight_ns']
    counts = summary['counts']
    weights = summary['weights_ns']
    need(sum(v['raw_samples'] for v in groups.values()) == counts['selected_timer_rows'], 'raw counts do not reconcile')
    need(sum(v['matched_samples'] for v in groups.values()) == counts['joined_rows'], 'joined counts do not reconcile')
    need(sum(v['weight_ns'] for v in groups.values()) == weights['joined_weight_ns'], 'weights do not reconcile')
    phases = {}
    for name, values in groups.items():
        phases[name] = dict(raw_samples=values['raw_samples'], matched_samples=values['matched_samples'],
                            weight_ns=values['weight_ns'], raw_fraction_of_all_timer_samples=values['raw_samples'] / counts['selected_timer_rows'],
                            weight_fraction_of_all_matched_samples=values['weight_ns'] / weights['joined_weight_ns'])
    return dict(format='native-profile-phase-counts-v1', status='checked', performance_comparison_accepted=False,
                image_sha256=summary['kernel_image_sha256'], rules_sha256=sha(rules_path),
                analysis_sha256=sha(analysis / 'profile-summary.json'), normalized_sha256=sha(analysis / 'normalized-samples.json'),
                classifier_sha256=sha(Path(__file__)),
                denominators=dict(raw_timer_samples=counts['selected_timer_rows'], raw_kernel_samples=counts['raw_kernel_leaf'],
                                  matched_samples=counts['joined_rows'], matched_weight_ns=weights['joined_weight_ns'],
                                  matched_kernel_weight_ns=weights['kernel_leaf_ns']),
                phases=phases,
                limits='Only reviewed exact ranges are attributed; gaps remain unclassified. Leaf observations are not causal costs, '
                       'wall-time shares or attainable speedup bounds. Derived-table missing rows have raw counts but no invented weight.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis', type=Path, required=True)
    parser.add_argument('--ranges', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = classify(args.analysis, args.ranges)
    with args.output.open('x') as stream:
        stream.write(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps(report['phases'], indent=2))

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [39 x i32] [i32 5, i32 4, i32 8, i32 108, i32 15, i32 14, i32 20, i32 19, i32 23, i32 26, i32 29, i32 32, i32 35, i32 38, i32 41, i32 44, i32 47, i32 50, i32 53, i32 56, i32 59, i32 62, i32 65, i32 68, i32 71, i32 74, i32 77, i32 80, i32 83, i32 86, i32 89, i32 92, i32 101, i32 100, i32 99, i32 104, i32 107, i32 113, i32 112], align 4

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 5120
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 11264
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 17408
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 37888
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 62464
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 64512
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 64640
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 66688
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 72832
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill37 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill37, align 64
  %.spill38 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill38, align 64
  %.spill39 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill39, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %tile_snapshot.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill42, align 64
  %tile_snapshot.spill43 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill43, align 64
  %.slot44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot44, align 64
  %.slot45 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot45, align 64
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.spill54 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill54, align 64
  %tile_snapshot.spill55 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill55, align 64
  %.slot56 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot56, align 64
  %.spill57 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill57, align 64
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %tile_snapshot.spill59 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill59, align 64
  %.slot60 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot60, align 64
  %.spill61 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill61, align 64
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.slot63 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot63, align 64
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.slot66 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot66, align 32
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot68, align 64
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot72, align 32
  %.slot73 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot73, align 64
  %.slot74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot74, align 32
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.slot78 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot78, align 64
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.slot83 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot83, align 64
  %.slot84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot84, align 32
  %.slot85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot85, align 32
  %.slot86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot86, align 32
  %.slot87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot87, align 32
  %.slot88 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot88, align 64
  %.slot89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot89, align 32
  %.slot90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot90, align 32
  %.slot91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot91, align 32
  %.slot92 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot92, align 32
  %.slot93 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot93, align 64
  %.slot94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot94, align 32
  %.slot95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot95, align 32
  %.slot96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot96, align 32
  %.slot97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot97, align 32
  %.slot98 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot98, align 64
  %.slot99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot99, align 32
  %.slot100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot100, align 32
  %.slot101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot101, align 32
  %.slot102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot102, align 32
  %.slot103 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot103, align 64
  %.slot104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot104, align 32
  %.slot105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot105, align 32
  %.slot106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot106, align 32
  %.slot107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot107, align 32
  %.slot108 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot108, align 64
  %.slot109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot109, align 32
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %.slot111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot111, align 32
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.slot113 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot113, align 64
  %.slot114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot114, align 32
  %.slot115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot115, align 32
  %.slot116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot116, align 32
  %.slot117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot117, align 32
  %.slot118 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot118, align 64
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.slot120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot120, align 32
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.slot122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot122, align 32
  %.slot123 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot123, align 64
  %.slot124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot124, align 32
  %.slot125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot125, align 32
  %.slot126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot126, align 32
  %.slot127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot127, align 32
  %.slot128 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot128, align 64
  %.slot129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot129, align 32
  %.slot130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot130, align 32
  %.slot131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot131, align 32
  %.slot132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot132, align 32
  %.slot133 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot133, align 64
  %.slot134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot134, align 32
  %.slot135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot135, align 32
  %.slot136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot136, align 32
  %.slot137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot137, align 32
  %.slot138 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot138, align 64
  %.slot139 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot139, align 32
  %.slot140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot140, align 32
  %.slot141 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot141, align 32
  %.slot142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot142, align 32
  %.spill143 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill143, align 1
  %.spill144 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill144, align 1
  %.spill145 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill145, align 1
  %.spill146 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill146, align 1
  %.spill147 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill147, align 1
  %.spill148 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill148, align 1
  %.spill149 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill149, align 1
  %.spill150 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill150, align 1
  %.spill151 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill151, align 1
  %.spill152 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill152, align 1
  %.spill153 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill153, align 1
  %.spill154 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill154, align 1
  %.spill155 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill155, align 1
  %.spill156 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill156, align 1
  %.spill157 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill157, align 1
  %.spill158 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill158, align 1
  %.spill159 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill159, align 1
  %.spill160 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill160, align 1
  %.spill161 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill161, align 1
  %.spill162 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill162, align 1
  %.spill163 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill163, align 1
  %.spill164 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill164, align 1
  %.spill165 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill165, align 1
  %.spill166 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill166, align 1
  %.spill167 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill167, align 1
  %.spill168 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill168, align 1
  %.spill169 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill169, align 1
  %.spill170 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill170, align 1
  %.spill171 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill171, align 1
  %.spill172 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill172, align 1
  %.spill173 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill173, align 1
  %.spill174 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill174, align 1
  %.spill175 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill175, align 1
  %.spill176 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill176, align 1
  %.spill177 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill177, align 1
  %.spill178 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill178, align 1
  %.spill179 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill179, align 1
  %.spill180 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill180, align 1
  %.spill181 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill181, align 1
  %.spill182 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill182, align 1
  %.spill183 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill183, align 1
  %.spill184 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill184, align 1
  %.spill185 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill185, align 1
  %.spill186 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill186, align 1
  %.spill187 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill187, align 1
  %.spill188 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill188, align 1
  %.spill189 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill189, align 1
  %.spill190 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill190, align 1
  %.spill191 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill191, align 1
  %.spill192 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill192, align 1
  %.spill193 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill193, align 1
  %.spill194 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill194, align 1
  %.spill195 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill195, align 1
  %.spill196 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill196, align 1
  %.spill197 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill197, align 1
  %.spill198 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill198, align 1
  %.spill199 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill199, align 1
  %.spill200 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill200, align 1
  %.spill201 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill201, align 1
  %.spill202 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill202, align 1
  %.spill203 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill203, align 1
  %.spill204 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill204, align 1
  %.spill205 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill205, align 1
  %.spill206 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill206, align 1
  %.spill207 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill207, align 32
  %.spill208 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill208, align 32
  %.spill209 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill209, align 32
  %.spill210 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill210, align 32
  %.spill211 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill211, align 32
  %.spill212 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill212, align 32
  %.spill213 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill213, align 32
  %.spill214 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill214, align 32
  %.spill215 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill215, align 32
  %.spill216 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill216, align 32
  %.spill217 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill217, align 32
  %.spill218 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill218, align 32
  %.spill219 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill219, align 32
  %.spill220 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill220, align 32
  %.spill221 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill221, align 32
  %.spill222 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill222, align 32
  %.spill223 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill223, align 32
  %.spill224 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill224, align 32
  %.spill225 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill225, align 32
  %.spill226 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill226, align 32
  %.spill227 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill227, align 32
  %.spill228 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill228, align 32
  %.spill229 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill229, align 32
  %.spill230 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill230, align 32
  %.spill231 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill231, align 32
  %.spill232 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill232, align 32
  %.spill233 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill233, align 32
  %.spill234 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill234, align 32
  %.spill235 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill235, align 32
  %.spill236 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill236, align 32
  %.spill237 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill237, align 32
  %.spill238 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill238, align 32
  %.spill239 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill239, align 32
  %.spill240 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill240, align 32
  %.spill241 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill241, align 32
  %.spill242 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill242, align 32
  %.spill243 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill243, align 32
  %.spill244 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill244, align 32
  %.spill245 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill245, align 32
  %.spill246 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill246, align 32
  %.spill247 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill247, align 32
  %.spill248 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill248, align 32
  %.spill249 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill249, align 32
  %.spill250 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill250, align 32
  %.spill251 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill251, align 32
  %.spill252 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill252, align 32
  %.spill253 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill253, align 32
  %.spill254 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill254, align 32
  %.spill255 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill255, align 32
  %.spill256 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill256, align 32
  %.spill257 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill257, align 32
  %.spill258 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill258, align 32
  %.spill259 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill259, align 32
  %.spill260 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill260, align 32
  %.spill261 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill261, align 32
  %.spill262 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill262, align 32
  %.spill263 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill263, align 32
  %.spill264 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill264, align 32
  %.spill265 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill265, align 32
  %.spill266 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill266, align 32
  %.spill267 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill267, align 32
  %.spill268 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill268, align 32
  %.spill269 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill269, align 32
  %.spill270 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill270, align 32
  %tile_snapshot.spill271 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill271, align 64
  %.slot272 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot272, align 64
  %.slot273 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot273, align 32
  %.slot274 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot274, align 64
  %.slot275 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot275, align 32
  %.slot276 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot276, align 64
  %.slot277 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot277, align 32
  %.slot278 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot278, align 64
  %.slot279 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot279, align 32
  %.spill280 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill280, align 32
  %.spill281 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill281, align 32
  %.spill282 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill282, align 32
  %.spill283 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill283, align 32
  %tile_snapshot.spill284 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill284, align 64
  %tile_snapshot.spill285 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill285, align 64
  %.spill286 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill286, align 32
  %.spill287 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill287, align 32
  %.spill288 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill288, align 32
  %.spill289 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill289, align 32
  %.slot290 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot290, align 64
  %.slot291 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot291, align 32
  %.slot292 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot292, align 64
  %.slot293 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot293, align 32
  %.slot294 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot294, align 64
  %.slot295 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot295, align 32
  %.slot296 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot296, align 64
  %.slot297 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot297, align 32
  %.spill298 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill298, align 32
  %.spill299 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill299, align 32
  %.spill300 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill300, align 32
  %.spill301 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill301, align 32
  %tile_snapshot.spill302 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill302, align 64
  %.slot303 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot303, align 64
  %.spill304 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill304, align 64
  %.slot305 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot305, align 64
  %.spill306 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill306, align 64
  %.spill307 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill307, align 64
  %.spill308 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill308, align 64
  %.spill309 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill309, align 64
  %.spill310 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill310, align 64
  %.spill311 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill311, align 64
  %.spill312 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill312, align 64
  %.spill313 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill313, align 64
  %.slot314 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot314, align 64
  %.slot315 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot315, align 32
  %.slot316 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot316, align 32
  %.slot317 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot317, align 32
  %.slot318 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot318, align 32
  %.slot319 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot319, align 64
  %.slot320 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot320, align 64
  %tile_snapshot.spill321 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill321, align 64
  %.slot322 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot322, align 64
  %.spill323 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill323, align 64
  %.spill324 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill324, align 32
  %30 = getelementptr i8, ptr %argument_buffer, i64 0
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 16
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 32
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = getelementptr i8, ptr %argument_buffer, i64 48
  %49 = load ptr, ptr %48, align 16
  %50 = getelementptr i8, ptr %48, i64 8
  %51 = load i64, ptr %50, align 8
  %52 = insertvalue { ptr, i64 } poison, ptr %49, 0
  %53 = insertvalue { ptr, i64 } %52, i64 %51, 1
  %54 = load i32, ptr %launch_config, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 12
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 4
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 16
  %60 = load i32, ptr %59, align 4
  %61 = getelementptr i8, ptr %launch_config, i64 8
  %62 = load i32, ptr %61, align 4
  %63 = getelementptr i8, ptr %launch_config, i64 20
  %64 = load i32, ptr %63, align 4
  %65 = getelementptr i8, ptr %launch_config, i64 36
  %66 = load i32, ptr %65, align 4
  %.splatinsert325 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat326 = shufflevector <8 x i32> %.splatinsert325, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat326, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %68 = mul i32 %54, 32
  %.splatinsert327 = insertelement <8 x i32> poison, i32 %68, i64 0
  %.splat328 = shufflevector <8 x i32> %.splatinsert327, <8 x i32> poison, <8 x i32> zeroinitializer
  %69 = add <8 x i32> %.splat328, %67
  %70 = mul i32 %58, 1
  %.splatinsert329 = insertelement <8 x i32> poison, i32 %70, i64 0
  %.splat330 = shufflevector <8 x i32> %.splatinsert329, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = add <8 x i32> %.splat330, zeroinitializer
  %72 = mul i32 %62, 1
  %.splatinsert331 = insertelement <8 x i32> poison, i32 %72, i64 0
  %.splat332 = shufflevector <8 x i32> %.splatinsert331, <8 x i32> poison, <8 x i32> zeroinitializer
  %73 = add <8 x i32> %.splat332, zeroinitializer
  %74 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %69, 0
  %75 = insertvalue [3 x <8 x i32>] %74, <8 x i32> %71, 1
  %76 = insertvalue [3 x <8 x i32>] %75, <8 x i32> %73, 2
  %.splatinsert333 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat334 = shufflevector <8 x i32> %.splatinsert333, <8 x i32> poison, <8 x i32> zeroinitializer
  %77 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat334
  store <8 x i1> %77, ptr %live.mask, align 1
  %78 = load i32, ptr %current.token, align 4
  %79 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %77)
  %80 = load i32, ptr %ready.count, align 4
  %81 = icmp uge i32 %80, 8
  %82 = and i1 %79, %81
  br i1 %82, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %83 = select i1 %79, i32 %80, i32 0
  %84 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %83
  %85 = load <8 x i1>, ptr %84, align 1
  %86 = select i1 %79, <8 x i1> %77, <8 x i1> %85
  store <8 x i1> %86, ptr %84, align 1
  %87 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %83
  %88 = load i32, ptr %87, align 4
  %89 = select i1 %79, i32 0, i32 %88
  store i32 %89, ptr %87, align 4
  %90 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %83
  %91 = load i32, ptr %90, align 4
  %92 = select i1 %79, i32 %78, i32 %91
  store i32 %92, ptr %90, align 4
  %93 = add i32 %80, 1
  %94 = select i1 %79, i32 %93, i32 %80
  store i32 %94, ptr %ready.count, align 4
  %95 = load <8 x i1>, ptr %runnable.mask, align 1
  %96 = or <8 x i1> %95, %77
  store <8 x i1> %96, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit2226, %convergence.target.112.ready, %convergence.cascade.exit2208, %schedule.111, %varying.coherent.false2204, %varying.coherent.true2203, %varying.coherent.false2189, %varying.coherent.true2188, %convergence.target.108.ready, %convergence.cascade.exit2153, %convergence.target.107.ready, %convergence.cascade.exit2127, %schedule.106, %varying.coherent.false2120, %varying.coherent.true2119, %convergence.target.104.ready, %convergence.cascade.exit2096, %schedule.103, %varying.coherent.false2089, %varying.coherent.true2088, %convergence.target.101.ready, %convergence.cascade.exit2065, %convergence.target.100.ready, %convergence.cascade.exit2047, %convergence.target.99.ready, %convergence.cascade.exit2017, %schedule.98, %varying.coherent.false1999, %varying.coherent.true1998, %schedule.96, %varying.coherent.false1980, %varying.coherent.true1979, %schedule.94, %varying.coherent.false1970, %varying.coherent.true1969, %convergence.target.92.ready, %convergence.cascade.exit1938, %schedule.91, %varying.coherent.false1932, %varying.coherent.true1931, %convergence.target.89.ready, %convergence.cascade.exit1908, %schedule.88, %varying.coherent.false1902, %varying.coherent.true1901, %convergence.target.86.ready, %convergence.cascade.exit1878, %schedule.85, %varying.coherent.false1872, %varying.coherent.true1871, %convergence.target.83.ready, %convergence.cascade.exit1848, %schedule.82, %varying.coherent.false1842, %varying.coherent.true1841, %convergence.target.80.ready, %convergence.cascade.exit1471, %schedule.79, %varying.coherent.false1465, %varying.coherent.true1464, %convergence.target.77.ready, %convergence.cascade.exit1441, %schedule.76, %varying.coherent.false1435, %varying.coherent.true1434, %convergence.target.74.ready, %convergence.cascade.exit1411, %schedule.73, %varying.coherent.false1405, %varying.coherent.true1404, %convergence.target.71.ready, %convergence.cascade.exit1381, %schedule.70, %varying.coherent.false1375, %varying.coherent.true1374, %convergence.target.68.ready, %convergence.cascade.exit1141, %schedule.67, %varying.coherent.false1126, %varying.coherent.true1125, %convergence.target.65.ready, %convergence.cascade.exit1102, %schedule.64, %varying.coherent.false1087, %varying.coherent.true1086, %convergence.target.62.ready, %convergence.cascade.exit1063, %schedule.61, %varying.coherent.false1048, %varying.coherent.true1047, %convergence.target.59.ready, %convergence.cascade.exit1024, %schedule.58, %varying.coherent.false1009, %varying.coherent.true1008, %convergence.target.56.ready, %convergence.cascade.exit985, %schedule.55, %varying.coherent.false970, %varying.coherent.true969, %convergence.target.53.ready, %convergence.cascade.exit946, %schedule.52, %varying.coherent.false931, %varying.coherent.true930, %convergence.target.50.ready, %convergence.cascade.exit907, %schedule.49, %varying.coherent.false894, %varying.coherent.true893, %convergence.target.47.ready, %convergence.cascade.exit870, %schedule.46, %varying.coherent.false855, %varying.coherent.true854, %convergence.target.44.ready, %convergence.cascade.exit831, %schedule.43, %varying.coherent.false816, %varying.coherent.true815, %convergence.target.41.ready, %convergence.cascade.exit792, %schedule.40, %varying.coherent.false777, %varying.coherent.true776, %convergence.target.38.ready, %convergence.cascade.exit753, %schedule.37, %varying.coherent.false738, %varying.coherent.true737, %convergence.target.35.ready, %convergence.cascade.exit714, %schedule.34, %varying.coherent.false699, %varying.coherent.true698, %convergence.target.32.ready, %convergence.cascade.exit675, %schedule.31, %varying.coherent.false660, %varying.coherent.true659, %convergence.target.29.ready, %convergence.cascade.exit636, %schedule.28, %varying.coherent.false621, %varying.coherent.true620, %convergence.target.26.ready, %convergence.cascade.exit597, %schedule.25, %varying.coherent.false582, %varying.coherent.true581, %convergence.target.23.ready, %convergence.cascade.exit558, %schedule.22, %varying.coherent.false545, %varying.coherent.true544, %convergence.target.20.ready, %convergence.cascade.exit521, %convergence.target.19.ready, %convergence.cascade.exit500, %schedule.18, %varying.coherent.false497, %varying.coherent.true496, %varying.coherent.false484, %varying.coherent.true483, %convergence.target.15.ready, %convergence.cascade.exit460, %convergence.target.14.ready, %convergence.cascade.exit439, %schedule.13, %varying.coherent.false436, %varying.coherent.true435, %varying.coherent.false423, %varying.coherent.true422, %schedule.10, %varying.coherent.false413, %varying.coherent.true412, %convergence.target.8.ready, %convergence.cascade.exit389, %schedule.7, %varying.coherent.false384, %varying.coherent.true383, %convergence.target.5.ready, %convergence.cascade.exit360, %convergence.target.4.ready, %convergence.cascade.exit, %schedule.3, %varying.coherent.false348, %varying.coherent.true347, %varying.coherent.false, %varying.coherent.true, %schedule.0, %ready.overflow.resume
  %97 = load i32, ptr %ready.count, align 4
  %98 = icmp ne i32 %97, 0
  br i1 %98, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %99 = sub i32 %97, 1
  store i32 %99, ptr %ready.count, align 4
  %100 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %99
  %101 = load <8 x i1>, ptr %100, align 1
  store <8 x i1> %101, ptr %current.mask, align 1
  %102 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %99
  %103 = load i32, ptr %102, align 4
  %104 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %99
  %105 = load i32, ptr %104, align 4
  store i32 %105, ptr %current.token, align 4
  %106 = load <8 x i1>, ptr %runnable.mask, align 1
  %107 = xor <8 x i1> %101, splat (i1 true)
  %108 = and <8 x i1> %106, %107
  store <8 x i1> %108, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume2202, %ready.overflow.resume2187, %ready.overflow.resume2118, %ready.overflow.resume2087, %ready.overflow.resume1997, %ready.overflow.resume1978, %ready.overflow.resume1968, %ready.overflow.resume1930, %ready.overflow.resume1900, %ready.overflow.resume1870, %ready.overflow.resume1840, %ready.overflow.resume1463, %ready.overflow.resume1433, %ready.overflow.resume1403, %ready.overflow.resume1373, %ready.overflow.resume1124, %ready.overflow.resume1085, %ready.overflow.resume1046, %ready.overflow.resume1007, %ready.overflow.resume968, %ready.overflow.resume929, %ready.overflow.resume892, %ready.overflow.resume853, %ready.overflow.resume814, %ready.overflow.resume775, %ready.overflow.resume736, %ready.overflow.resume697, %ready.overflow.resume658, %ready.overflow.resume619, %ready.overflow.resume580, %ready.overflow.resume543, %ready.overflow.resume495, %ready.overflow.resume482, %ready.overflow.resume434, %ready.overflow.resume421, %ready.overflow.resume411, %ready.overflow.resume382, %ready.overflow.resume346, %ready.overflow.resume336, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %103, %scheduler.dispatch ], [ 5, %ready.overflow.resume336 ], [ 4, %ready.overflow.resume346 ], [ 8, %ready.overflow.resume382 ], [ 108, %ready.overflow.resume411 ], [ 15, %ready.overflow.resume421 ], [ 14, %ready.overflow.resume434 ], [ 20, %ready.overflow.resume482 ], [ 19, %ready.overflow.resume495 ], [ 23, %ready.overflow.resume543 ], [ 26, %ready.overflow.resume580 ], [ 29, %ready.overflow.resume619 ], [ 32, %ready.overflow.resume658 ], [ 35, %ready.overflow.resume697 ], [ 38, %ready.overflow.resume736 ], [ 41, %ready.overflow.resume775 ], [ 44, %ready.overflow.resume814 ], [ 47, %ready.overflow.resume853 ], [ 50, %ready.overflow.resume892 ], [ 53, %ready.overflow.resume929 ], [ 56, %ready.overflow.resume968 ], [ 59, %ready.overflow.resume1007 ], [ 62, %ready.overflow.resume1046 ], [ 65, %ready.overflow.resume1085 ], [ 68, %ready.overflow.resume1124 ], [ 71, %ready.overflow.resume1373 ], [ 74, %ready.overflow.resume1403 ], [ 77, %ready.overflow.resume1433 ], [ 80, %ready.overflow.resume1463 ], [ 83, %ready.overflow.resume1840 ], [ 86, %ready.overflow.resume1870 ], [ 89, %ready.overflow.resume1900 ], [ 92, %ready.overflow.resume1930 ], [ 101, %ready.overflow.resume1968 ], [ 100, %ready.overflow.resume1978 ], [ 99, %ready.overflow.resume1997 ], [ 104, %ready.overflow.resume2087 ], [ 107, %ready.overflow.resume2118 ], [ 113, %ready.overflow.resume2187 ], [ 112, %ready.overflow.resume2202 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
    i32 48, label %schedule.48
    i32 49, label %schedule.49
    i32 50, label %schedule.50
    i32 51, label %schedule.51
    i32 52, label %schedule.52
    i32 53, label %schedule.53
    i32 54, label %schedule.54
    i32 55, label %schedule.55
    i32 56, label %schedule.56
    i32 57, label %schedule.57
    i32 58, label %schedule.58
    i32 59, label %schedule.59
    i32 60, label %schedule.60
    i32 61, label %schedule.61
    i32 62, label %schedule.62
    i32 63, label %schedule.63
    i32 64, label %schedule.64
    i32 65, label %schedule.65
    i32 66, label %schedule.66
    i32 67, label %schedule.67
    i32 68, label %schedule.68
    i32 69, label %schedule.69
    i32 70, label %schedule.70
    i32 71, label %schedule.71
    i32 72, label %schedule.72
    i32 73, label %schedule.73
    i32 74, label %schedule.74
    i32 75, label %schedule.75
    i32 76, label %schedule.76
    i32 77, label %schedule.77
    i32 78, label %schedule.78
    i32 79, label %schedule.79
    i32 80, label %schedule.80
    i32 81, label %schedule.81
    i32 82, label %schedule.82
    i32 83, label %schedule.83
    i32 84, label %schedule.84
    i32 85, label %schedule.85
    i32 86, label %schedule.86
    i32 87, label %schedule.87
    i32 88, label %schedule.88
    i32 89, label %schedule.89
    i32 90, label %schedule.90
    i32 91, label %schedule.91
    i32 92, label %schedule.92
    i32 93, label %schedule.93
    i32 94, label %schedule.94
    i32 95, label %schedule.95
    i32 96, label %schedule.96
    i32 97, label %schedule.97
    i32 98, label %schedule.98
    i32 99, label %schedule.99
    i32 100, label %schedule.100
    i32 101, label %schedule.101
    i32 102, label %schedule.102
    i32 103, label %schedule.103
    i32 104, label %schedule.104
    i32 105, label %schedule.105
    i32 106, label %schedule.106
    i32 107, label %schedule.107
    i32 108, label %schedule.108
    i32 109, label %schedule.109
    i32 110, label %schedule.110
    i32 111, label %schedule.111
    i32 112, label %schedule.112
    i32 113, label %schedule.113
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %109 = load <8 x i1>, ptr %live.mask, align 1
  %110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %109)
  br i1 %110, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %111 = load <8 x i1>, ptr %current.mask, align 1
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %113 = bitcast <8 x i1> %111 to i8
  %114 = call i8 @llvm.cttz.i8(i8 %113, i1 false)
  %115 = zext i8 %114 to i32
  %116 = select i1 %112, i32 %115, i32 0
  %117 = extractvalue [3 x <8 x i32>] %76, 0
  %118 = zext <8 x i32> %117 to <8 x i64>
  %119 = select <8 x i1> %111, <8 x i64> %118, <8 x i64> zeroinitializer
  %120 = select <8 x i1> %111, <8 x i64> splat (i64 30), <8 x i64> splat (i64 1)
  %121 = sdiv <8 x i64> %119, %120
  %122 = load <8 x i64>, ptr %.spill, align 64
  %123 = select <8 x i1> %111, <8 x i64> %121, <8 x i64> %122
  store <8 x i64> %123, ptr %.spill, align 64
  %124 = select <8 x i1> %111, <8 x i64> %118, <8 x i64> zeroinitializer
  %125 = select <8 x i1> %111, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %126 = sdiv <8 x i64> %124, %125
  %127 = select <8 x i1> %111, <8 x i64> %126, <8 x i64> zeroinitializer
  %128 = select <8 x i1> %111, <8 x i64> splat (i64 6), <8 x i64> splat (i64 1)
  %129 = srem <8 x i64> %127, %128
  %130 = load <8 x i64>, ptr %.spill37, align 64
  %131 = select <8 x i1> %111, <8 x i64> %129, <8 x i64> %130
  store <8 x i64> %131, ptr %.spill37, align 64
  %132 = select <8 x i1> %111, <8 x i64> %118, <8 x i64> zeroinitializer
  %133 = select <8 x i1> %111, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %134 = sdiv <8 x i64> %132, %133
  %135 = select <8 x i1> %111, <8 x i64> %134, <8 x i64> zeroinitializer
  %136 = select <8 x i1> %111, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %137 = srem <8 x i64> %135, %136
  %138 = mul <8 x i64> %137, splat (i64 4)
  %139 = load <8 x i64>, ptr %.spill38, align 64
  %140 = select <8 x i1> %111, <8 x i64> %138, <8 x i64> %139
  store <8 x i64> %140, ptr %.spill38, align 64
  %141 = select <8 x i1> %111, <8 x i64> %129, <8 x i64> zeroinitializer
  %142 = select <8 x i1> %111, <8 x i64> splat (i64 3), <8 x i64> splat (i64 1)
  %143 = sdiv <8 x i64> %141, %142
  %144 = load <8 x i64>, ptr %.spill39, align 64
  %145 = select <8 x i1> %111, <8 x i64> %143, <8 x i64> %144
  store <8 x i64> %145, ptr %.spill39, align 64
  %146 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %146, 0
  %149 = select <8 x i1> %111, <8 x ptr> %147, <8 x ptr> %148
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %146, 1
  %152 = select <8 x i1> %111, <8 x i64> %150, <8 x i64> %151
  %153 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %149, 0
  %154 = insertvalue { <8 x ptr>, <8 x i64> } %153, <8 x i64> %152, 1
  store { <8 x ptr>, <8 x i64> } %154, ptr %tile_snapshot.spill, align 64
  %155 = load <8 x i64>, ptr %.slot, align 64
  %156 = select <8 x i1> %111, <8 x i64> zeroinitializer, <8 x i64> %155
  store <8 x i64> %156, ptr %.slot, align 64
  store <8 x i1> %111, ptr %current.mask, align 1
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  br i1 %157, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.4.ready, %schedule.0, %scheduler.dispatch.route
  %158 = load <8 x i1>, ptr %current.mask, align 1
  %159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %158)
  %160 = bitcast <8 x i1> %158 to i8
  %161 = call i8 @llvm.cttz.i8(i8 %160, i1 false)
  %162 = zext i8 %161 to i32
  %163 = select i1 %159, i32 %162, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %164 = icmp slt <8 x i64> %.state, splat (i64 160)
  %165 = and <8 x i1> %158, %164
  %166 = xor <8 x i1> %164, splat (i1 true)
  %167 = and <8 x i1> %158, %166
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %165)
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %167)
  %170 = and i1 %168, %169
  br i1 %170, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %171 = load <8 x i1>, ptr %current.mask, align 1
  %172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %171)
  %173 = bitcast <8 x i1> %171 to i8
  %174 = call i8 @llvm.cttz.i8(i8 %173, i1 false)
  %175 = zext i8 %174 to i32
  %176 = select i1 %172, i32 %175, i32 0
  %.state337 = load <8 x i64>, ptr %.slot, align 64
  %177 = select <8 x i1> %171, <8 x i64> %.state337, <8 x i64> zeroinitializer
  %178 = select <8 x i1> %171, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %179 = srem <8 x i64> %177, %178
  %.state338 = load <8 x i64>, ptr %.slot, align 64
  %180 = select <8 x i1> %171, <8 x i64> %.state338, <8 x i64> zeroinitializer
  %181 = select <8 x i1> %171, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %182 = sdiv <8 x i64> %180, %181
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %183 = add <8 x i64> %.spill.load, zeroinitializer
  %184 = add <8 x i64> zeroinitializer, %183
  %.spill.load339 = load <8 x i64>, ptr %.spill37, align 64
  %185 = add <8 x i64> %.spill.load339, zeroinitializer
  %186 = mul <8 x i64> %184, splat (i64 6)
  %187 = add <8 x i64> %186, %185
  %.spill.load340 = load <8 x i64>, ptr %.spill38, align 64
  %188 = add <8 x i64> %.spill.load340, %182
  %189 = mul <8 x i64> %187, splat (i64 17)
  %190 = add <8 x i64> %189, %188
  %191 = icmp sge <8 x i64> %188, zeroinitializer
  %192 = and <8 x i1> splat (i1 true), %191
  %193 = icmp slt <8 x i64> %188, splat (i64 17)
  %194 = and <8 x i1> %192, %193
  %195 = add <8 x i64> zeroinitializer, %179
  %196 = mul <8 x i64> %190, splat (i64 40)
  %197 = add <8 x i64> %196, %195
  %198 = load <8 x i64>, ptr %.spill40, align 64
  %199 = select <8 x i1> %171, <8 x i64> %197, <8 x i64> %198
  store <8 x i64> %199, ptr %.spill40, align 64
  %200 = and <8 x i1> %171, %194
  %201 = xor <8 x i1> %194, splat (i1 true)
  %202 = and <8 x i1> %171, %201
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %202)
  %205 = and i1 %203, %204
  br i1 %205, label %varying.divergent341, label %varying.coherent342

schedule.3:                                       ; preds = %varying.coherent.true347, %scheduler.dispatch.route
  %206 = load <8 x i1>, ptr %current.mask, align 1
  %207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %206)
  %208 = bitcast <8 x i1> %206 to i8
  %209 = call i8 @llvm.cttz.i8(i8 %208, i1 false)
  %210 = zext i8 %209 to i32
  %211 = select i1 %207, i32 %210, i32 0
  %.spill.load349 = load <8 x i64>, ptr %.spill40, align 64
  %212 = extractvalue { ptr, i64 } %35, 0
  %213 = mul <8 x i64> %.spill.load349, splat (i64 4)
  %214 = getelementptr i8, ptr %212, <8 x i64> %213
  %215 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %214, <8 x i1> %206, <8 x float> zeroinitializer)
  %216 = load <8 x float>, ptr %.slot41, align 32
  %217 = select <8 x i1> %206, <8 x float> %215, <8 x float> %216
  store <8 x float> %217, ptr %.slot41, align 32
  store <8 x i1> %206, ptr %current.mask, align 1
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %206)
  br i1 %218, label %schedule.4, label %scheduler.loop

schedule.4:                                       ; preds = %schedule.3, %varying.coherent.false348, %scheduler.dispatch.route
  %219 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.5:                                       ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %220 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token361 = load i32, ptr %current.token, align 4
  %convergence.token.present362 = icmp ne i32 %convergence.current.token361, 0
  br i1 %convergence.token.present362, label %convergence.cascade359, label %convergence.cascade.exit360

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %221 = load <8 x i1>, ptr %current.mask, align 1
  %222 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  %223 = bitcast <8 x i1> %221 to i8
  %224 = call i8 @llvm.cttz.i8(i8 %223, i1 false)
  %225 = zext i8 %224 to i32
  %226 = select i1 %222, i32 %225, i32 0
  %.state376 = load <8 x i64>, ptr %.slot, align 64
  %227 = icmp slt <8 x i64> %.state376, splat (i64 192)
  %228 = and <8 x i1> %221, %227
  %229 = xor <8 x i1> %227, splat (i1 true)
  %230 = and <8 x i1> %221, %229
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %230)
  %233 = and i1 %231, %232
  br i1 %233, label %varying.divergent377, label %varying.coherent378

schedule.7:                                       ; preds = %varying.coherent.true383, %scheduler.dispatch.route
  %234 = load <8 x i1>, ptr %current.mask, align 1
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  %236 = bitcast <8 x i1> %234 to i8
  %237 = call i8 @llvm.cttz.i8(i8 %236, i1 false)
  %238 = zext i8 %237 to i32
  %239 = select i1 %235, i32 %238, i32 0
  %tile_snapshot.spill.load385 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load385, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load385, 1
  %.state386 = load <8 x i64>, ptr %.slot, align 64
  %242 = mul <8 x i64> %.state386, splat (i64 32)
  %243 = add <8 x i64> %241, %242
  %244 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %240, 0
  %245 = insertvalue { <8 x ptr>, <8 x i64> } %244, <8 x i64> %243, 1
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %245, 0
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %245, 1
  %248 = getelementptr i8, <8 x ptr> %246, <8 x i64> %247
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %248, <8 x i1> %234)
  %.state387 = load <8 x i64>, ptr %.slot, align 64
  %249 = add <8 x i64> %.state387, splat (i64 1)
  %250 = load <8 x i64>, ptr %.slot, align 64
  %251 = select <8 x i1> %234, <8 x i64> %249, <8 x i64> %250
  store <8 x i64> %251, ptr %.slot, align 64
  store <8 x i1> %234, ptr %current.mask, align 1
  %252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %234)
  br i1 %252, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false384, %scheduler.dispatch.route
  %253 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token390 = load i32, ptr %current.token, align 4
  %convergence.token.present391 = icmp ne i32 %convergence.current.token390, 0
  br i1 %convergence.token.present391, label %convergence.cascade388, label %convergence.cascade.exit389

schedule.9:                                       ; preds = %convergence.target.107.ready, %convergence.target.8.ready, %scheduler.dispatch.route
  %254 = load <8 x i1>, ptr %current.mask, align 1
  %255 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  %256 = bitcast <8 x i1> %254 to i8
  %257 = call i8 @llvm.cttz.i8(i8 %256, i1 false)
  %258 = zext i8 %257 to i32
  %259 = select i1 %255, i32 %258, i32 0
  %.state405 = load <8 x i64>, ptr %.slot, align 64
  %260 = icmp slt <8 x i64> %.state405, splat (i64 5)
  %261 = and <8 x i1> %254, %260
  %262 = xor <8 x i1> %260, splat (i1 true)
  %263 = and <8 x i1> %254, %262
  %264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %261)
  %265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %263)
  %266 = and i1 %264, %265
  br i1 %266, label %varying.divergent406, label %varying.coherent407

schedule.10:                                      ; preds = %varying.coherent.true412, %scheduler.dispatch.route
  %267 = load <8 x i1>, ptr %current.mask, align 1
  %268 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %267)
  %269 = bitcast <8 x i1> %267 to i8
  %270 = call i8 @llvm.cttz.i8(i8 %269, i1 false)
  %271 = zext i8 %270 to i32
  %272 = select i1 %268, i32 %271, i32 0
  %.state414 = load <8 x i64>, ptr %.slot, align 64
  %273 = select <8 x i1> %267, <8 x i64> %.state414, <8 x i64> zeroinitializer
  %274 = select <8 x i1> %267, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %275 = sdiv <8 x i64> %273, %274
  %276 = mul <8 x i64> %275, splat (i64 16)
  %277 = load <8 x i64>, ptr %.spill54, align 64
  %278 = select <8 x i1> %267, <8 x i64> %276, <8 x i64> %277
  store <8 x i64> %278, ptr %.spill54, align 64
  %279 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %279, 0
  %282 = select <8 x i1> %267, <8 x ptr> %280, <8 x ptr> %281
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %279, 1
  %285 = select <8 x i1> %267, <8 x i64> %283, <8 x i64> %284
  %286 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %282, 0
  %287 = insertvalue { <8 x ptr>, <8 x i64> } %286, <8 x i64> %285, 1
  store { <8 x ptr>, <8 x i64> } %287, ptr %tile_snapshot.spill55, align 64
  %288 = load <8 x i64>, ptr %.slot56, align 64
  %289 = select <8 x i1> %267, <8 x i64> zeroinitializer, <8 x i64> %288
  store <8 x i64> %289, ptr %.slot56, align 64
  store <8 x i1> %267, ptr %current.mask, align 1
  %290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %267)
  br i1 %290, label %schedule.11, label %scheduler.loop

schedule.11:                                      ; preds = %convergence.target.14.ready, %schedule.10, %scheduler.dispatch.route
  %291 = load <8 x i1>, ptr %current.mask, align 1
  %292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %291)
  %293 = bitcast <8 x i1> %291 to i8
  %294 = call i8 @llvm.cttz.i8(i8 %293, i1 false)
  %295 = zext i8 %294 to i32
  %296 = select i1 %292, i32 %295, i32 0
  %.state415 = load <8 x i64>, ptr %.slot56, align 64
  %297 = icmp slt <8 x i64> %.state415, splat (i64 640)
  %298 = and <8 x i1> %291, %297
  %299 = xor <8 x i1> %297, splat (i1 true)
  %300 = and <8 x i1> %291, %299
  %301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %298)
  %302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %300)
  %303 = and i1 %301, %302
  br i1 %303, label %varying.divergent416, label %varying.coherent417

schedule.12:                                      ; preds = %varying.coherent.true422, %scheduler.dispatch.route
  %304 = load <8 x i1>, ptr %current.mask, align 1
  %305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %304)
  %306 = bitcast <8 x i1> %304 to i8
  %307 = call i8 @llvm.cttz.i8(i8 %306, i1 false)
  %308 = zext i8 %307 to i32
  %309 = select i1 %305, i32 %308, i32 0
  %.state424 = load <8 x i64>, ptr %.slot56, align 64
  %310 = select <8 x i1> %304, <8 x i64> %.state424, <8 x i64> zeroinitializer
  %311 = select <8 x i1> %304, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %312 = srem <8 x i64> %310, %311
  %.state425 = load <8 x i64>, ptr %.slot56, align 64
  %313 = select <8 x i1> %304, <8 x i64> %.state425, <8 x i64> zeroinitializer
  %314 = select <8 x i1> %304, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %315 = sdiv <8 x i64> %313, %314
  %.spill.load426 = load <8 x i64>, ptr %.spill, align 64
  %316 = add <8 x i64> %.spill.load426, zeroinitializer
  %317 = add <8 x i64> zeroinitializer, %316
  %.spill.load427 = load <8 x i64>, ptr %.spill39, align 64
  %318 = add <8 x i64> %.spill.load427, zeroinitializer
  %319 = mul <8 x i64> %317, splat (i64 2)
  %320 = add <8 x i64> %319, %318
  %.spill.load428 = load <8 x i64>, ptr %.spill54, align 64
  %321 = add <8 x i64> %.spill.load428, %315
  %322 = mul <8 x i64> %320, splat (i64 67)
  %323 = add <8 x i64> %322, %321
  %324 = icmp sge <8 x i64> %321, zeroinitializer
  %325 = and <8 x i1> splat (i1 true), %324
  %326 = icmp slt <8 x i64> %321, splat (i64 67)
  %327 = and <8 x i1> %325, %326
  %328 = add <8 x i64> zeroinitializer, %312
  %329 = mul <8 x i64> %323, splat (i64 40)
  %330 = add <8 x i64> %329, %328
  %331 = load <8 x i64>, ptr %.spill57, align 64
  %332 = select <8 x i1> %304, <8 x i64> %330, <8 x i64> %331
  store <8 x i64> %332, ptr %.spill57, align 64
  %333 = and <8 x i1> %304, %327
  %334 = xor <8 x i1> %327, splat (i1 true)
  %335 = and <8 x i1> %304, %334
  %336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %333)
  %337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %335)
  %338 = and i1 %336, %337
  br i1 %338, label %varying.divergent429, label %varying.coherent430

schedule.13:                                      ; preds = %varying.coherent.true435, %scheduler.dispatch.route
  %339 = load <8 x i1>, ptr %current.mask, align 1
  %340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %339)
  %341 = bitcast <8 x i1> %339 to i8
  %342 = call i8 @llvm.cttz.i8(i8 %341, i1 false)
  %343 = zext i8 %342 to i32
  %344 = select i1 %340, i32 %343, i32 0
  %.spill.load437 = load <8 x i64>, ptr %.spill57, align 64
  %345 = extractvalue { ptr, i64 } %41, 0
  %346 = mul <8 x i64> %.spill.load437, splat (i64 4)
  %347 = getelementptr i8, ptr %345, <8 x i64> %346
  %348 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %347, <8 x i1> %339, <8 x float> zeroinitializer)
  %349 = load <8 x float>, ptr %.slot58, align 32
  %350 = select <8 x i1> %339, <8 x float> %348, <8 x float> %349
  store <8 x float> %350, ptr %.slot58, align 32
  store <8 x i1> %339, ptr %current.mask, align 1
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %339)
  br i1 %351, label %schedule.14, label %scheduler.loop

schedule.14:                                      ; preds = %schedule.13, %varying.coherent.false436, %scheduler.dispatch.route
  %352 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token440 = load i32, ptr %current.token, align 4
  %convergence.token.present441 = icmp ne i32 %convergence.current.token440, 0
  br i1 %convergence.token.present441, label %convergence.cascade438, label %convergence.cascade.exit439

schedule.15:                                      ; preds = %varying.coherent.false423, %scheduler.dispatch.route
  %353 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token461 = load i32, ptr %current.token, align 4
  %convergence.token.present462 = icmp ne i32 %convergence.current.token461, 0
  br i1 %convergence.token.present462, label %convergence.cascade459, label %convergence.cascade.exit460

schedule.16:                                      ; preds = %convergence.target.19.ready, %convergence.target.15.ready, %scheduler.dispatch.route
  %354 = load <8 x i1>, ptr %current.mask, align 1
  %355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %354)
  %356 = bitcast <8 x i1> %354 to i8
  %357 = call i8 @llvm.cttz.i8(i8 %356, i1 false)
  %358 = zext i8 %357 to i32
  %359 = select i1 %355, i32 %358, i32 0
  %.state476 = load <8 x i64>, ptr %.slot56, align 64
  %360 = icmp slt <8 x i64> %.state476, splat (i64 768)
  %361 = and <8 x i1> %354, %360
  %362 = xor <8 x i1> %360, splat (i1 true)
  %363 = and <8 x i1> %354, %362
  %364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %361)
  %365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %363)
  %366 = and i1 %364, %365
  br i1 %366, label %varying.divergent477, label %varying.coherent478

schedule.17:                                      ; preds = %varying.coherent.true483, %scheduler.dispatch.route
  %367 = load <8 x i1>, ptr %current.mask, align 1
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %367)
  %369 = bitcast <8 x i1> %367 to i8
  %370 = call i8 @llvm.cttz.i8(i8 %369, i1 false)
  %371 = zext i8 %370 to i32
  %372 = select i1 %368, i32 %371, i32 0
  %.state485 = load <8 x i64>, ptr %.slot56, align 64
  %373 = select <8 x i1> %367, <8 x i64> %.state485, <8 x i64> zeroinitializer
  %374 = select <8 x i1> %367, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %375 = srem <8 x i64> %373, %374
  %.state486 = load <8 x i64>, ptr %.slot56, align 64
  %376 = select <8 x i1> %367, <8 x i64> %.state486, <8 x i64> zeroinitializer
  %377 = select <8 x i1> %367, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %378 = sdiv <8 x i64> %376, %377
  %.spill.load487 = load <8 x i64>, ptr %.spill, align 64
  %379 = add <8 x i64> %.spill.load487, zeroinitializer
  %380 = add <8 x i64> zeroinitializer, %379
  %.spill.load488 = load <8 x i64>, ptr %.spill39, align 64
  %381 = add <8 x i64> %.spill.load488, zeroinitializer
  %382 = mul <8 x i64> %380, splat (i64 2)
  %383 = add <8 x i64> %382, %381
  %.spill.load489 = load <8 x i64>, ptr %.spill54, align 64
  %384 = add <8 x i64> %.spill.load489, %378
  %385 = mul <8 x i64> %383, splat (i64 67)
  %386 = add <8 x i64> %385, %384
  %387 = icmp sge <8 x i64> %384, zeroinitializer
  %388 = and <8 x i1> splat (i1 true), %387
  %389 = icmp slt <8 x i64> %384, splat (i64 67)
  %390 = and <8 x i1> %388, %389
  %391 = add <8 x i64> zeroinitializer, %375
  %392 = mul <8 x i64> %386, splat (i64 48)
  %393 = add <8 x i64> %392, %391
  %394 = load <8 x i64>, ptr %.spill61, align 64
  %395 = select <8 x i1> %367, <8 x i64> %393, <8 x i64> %394
  store <8 x i64> %395, ptr %.spill61, align 64
  %396 = and <8 x i1> %367, %390
  %397 = xor <8 x i1> %390, splat (i1 true)
  %398 = and <8 x i1> %367, %397
  %399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %396)
  %400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %398)
  %401 = and i1 %399, %400
  br i1 %401, label %varying.divergent490, label %varying.coherent491

schedule.18:                                      ; preds = %varying.coherent.true496, %scheduler.dispatch.route
  %402 = load <8 x i1>, ptr %current.mask, align 1
  %403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %402)
  %404 = bitcast <8 x i1> %402 to i8
  %405 = call i8 @llvm.cttz.i8(i8 %404, i1 false)
  %406 = zext i8 %405 to i32
  %407 = select i1 %403, i32 %406, i32 0
  %.spill.load498 = load <8 x i64>, ptr %.spill61, align 64
  %408 = extractvalue { ptr, i64 } %47, 0
  %409 = mul <8 x i64> %.spill.load498, splat (i64 4)
  %410 = getelementptr i8, ptr %408, <8 x i64> %409
  %411 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %410, <8 x i1> %402, <8 x float> zeroinitializer)
  %412 = load <8 x float>, ptr %.slot58, align 32
  %413 = select <8 x i1> %402, <8 x float> %411, <8 x float> %412
  store <8 x float> %413, ptr %.slot58, align 32
  store <8 x i1> %402, ptr %current.mask, align 1
  %414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %402)
  br i1 %414, label %schedule.19, label %scheduler.loop

schedule.19:                                      ; preds = %schedule.18, %varying.coherent.false497, %scheduler.dispatch.route
  %415 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token501 = load i32, ptr %current.token, align 4
  %convergence.token.present502 = icmp ne i32 %convergence.current.token501, 0
  br i1 %convergence.token.present502, label %convergence.cascade499, label %convergence.cascade.exit500

schedule.20:                                      ; preds = %varying.coherent.false484, %scheduler.dispatch.route
  %416 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token522 = load i32, ptr %current.token, align 4
  %convergence.token.present523 = icmp ne i32 %convergence.current.token522, 0
  br i1 %convergence.token.present523, label %convergence.cascade520, label %convergence.cascade.exit521

schedule.21:                                      ; preds = %schedule.22, %convergence.target.20.ready, %scheduler.dispatch.route
  %417 = load <8 x i1>, ptr %current.mask, align 1
  %418 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %417)
  %419 = bitcast <8 x i1> %417 to i8
  %420 = call i8 @llvm.cttz.i8(i8 %419, i1 false)
  %421 = zext i8 %420 to i32
  %422 = select i1 %418, i32 %421, i32 0
  %.state537 = load <8 x i64>, ptr %.slot56, align 64
  %423 = icmp slt <8 x i64> %.state537, splat (i64 40)
  %424 = and <8 x i1> %417, %423
  %425 = xor <8 x i1> %423, splat (i1 true)
  %426 = and <8 x i1> %417, %425
  %427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %424)
  %428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %426)
  %429 = and i1 %427, %428
  br i1 %429, label %varying.divergent538, label %varying.coherent539

schedule.22:                                      ; preds = %varying.coherent.true544, %scheduler.dispatch.route
  %430 = load <8 x i1>, ptr %current.mask, align 1
  %431 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %430)
  %432 = bitcast <8 x i1> %430 to i8
  %433 = call i8 @llvm.cttz.i8(i8 %432, i1 false)
  %434 = zext i8 %433 to i32
  %435 = select i1 %431, i32 %434, i32 0
  %.state546 = load <8 x i64>, ptr %.slot56, align 64
  %436 = add <8 x i64> zeroinitializer, %.state546
  %tile_snapshot.spill.load547 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 0
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 1
  %439 = mul <8 x i64> %436, splat (i64 32)
  %440 = add <8 x i64> %438, %439
  %441 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %437, 0
  %442 = insertvalue { <8 x ptr>, <8 x i64> } %441, <8 x i64> %440, 1
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %442, 0
  %444 = extractvalue { <8 x ptr>, <8 x i64> } %442, 1
  %445 = getelementptr i8, <8 x ptr> %443, <8 x i64> %444
  %446 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %445, <8 x i1> %430, <8 x float> zeroinitializer)
  %.state548 = load <8 x i64>, ptr %.slot56, align 64
  %447 = add <8 x i64> splat (i64 40), %.state548
  %tile_snapshot.spill.load549 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %448 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load549, 0
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load549, 1
  %450 = mul <8 x i64> %447, splat (i64 32)
  %451 = add <8 x i64> %449, %450
  %452 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %448, 0
  %453 = insertvalue { <8 x ptr>, <8 x i64> } %452, <8 x i64> %451, 1
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %453, 0
  %455 = extractvalue { <8 x ptr>, <8 x i64> } %453, 1
  %456 = getelementptr i8, <8 x ptr> %454, <8 x i64> %455
  %457 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %456, <8 x i1> %430, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load550 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %458 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load550, 0
  %459 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load550, 1
  %460 = mul <8 x i64> %436, splat (i64 32)
  %461 = add <8 x i64> %459, %460
  %462 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %458, 0
  %463 = insertvalue { <8 x ptr>, <8 x i64> } %462, <8 x i64> %461, 1
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %463, 0
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %463, 1
  %466 = getelementptr i8, <8 x ptr> %464, <8 x i64> %465
  %467 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %466, <8 x i1> %430, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load551 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load551, 0
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load551, 1
  %470 = mul <8 x i64> %447, splat (i64 32)
  %471 = add <8 x i64> %469, %470
  %472 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %468, 0
  %473 = insertvalue { <8 x ptr>, <8 x i64> } %472, <8 x i64> %471, 1
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %473, 0
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %473, 1
  %476 = getelementptr i8, <8 x ptr> %474, <8 x i64> %475
  %477 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %476, <8 x i1> %430, <8 x float> zeroinitializer)
  %478 = fmul <8 x float> %446, %467
  %.state552 = load <8 x float>, ptr %.slot58, align 32
  %479 = fadd <8 x float> %.state552, %478
  %480 = fmul <8 x float> %446, %477
  %.state553 = load <8 x float>, ptr %.slot65, align 32
  %481 = fadd <8 x float> %.state553, %480
  %482 = fmul <8 x float> %457, %467
  %.state554 = load <8 x float>, ptr %.slot66, align 32
  %483 = fadd <8 x float> %.state554, %482
  %484 = fmul <8 x float> %457, %477
  %.state555 = load <8 x float>, ptr %.slot67, align 32
  %485 = fadd <8 x float> %.state555, %484
  %.state556 = load <8 x i64>, ptr %.slot56, align 64
  %486 = add <8 x i64> %.state556, splat (i64 1)
  %487 = load <8 x i64>, ptr %.slot56, align 64
  %488 = select <8 x i1> %430, <8 x i64> %486, <8 x i64> %487
  store <8 x i64> %488, ptr %.slot56, align 64
  %489 = load <8 x float>, ptr %.slot58, align 32
  %490 = select <8 x i1> %430, <8 x float> %479, <8 x float> %489
  store <8 x float> %490, ptr %.slot58, align 32
  %491 = load <8 x float>, ptr %.slot65, align 32
  %492 = select <8 x i1> %430, <8 x float> %481, <8 x float> %491
  store <8 x float> %492, ptr %.slot65, align 32
  %493 = load <8 x float>, ptr %.slot66, align 32
  %494 = select <8 x i1> %430, <8 x float> %483, <8 x float> %493
  store <8 x float> %494, ptr %.slot66, align 32
  %495 = load <8 x float>, ptr %.slot67, align 32
  %496 = select <8 x i1> %430, <8 x float> %485, <8 x float> %495
  store <8 x float> %496, ptr %.slot67, align 32
  store <8 x i1> %430, ptr %current.mask, align 1
  %497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %430)
  br i1 %497, label %schedule.21, label %scheduler.loop

schedule.23:                                      ; preds = %varying.coherent.false545, %scheduler.dispatch.route
  %498 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token559 = load i32, ptr %current.token, align 4
  %convergence.token.present560 = icmp ne i32 %convergence.current.token559, 0
  br i1 %convergence.token.present560, label %convergence.cascade557, label %convergence.cascade.exit558

schedule.24:                                      ; preds = %schedule.25, %convergence.target.23.ready, %scheduler.dispatch.route
  %499 = load <8 x i1>, ptr %current.mask, align 1
  %500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %499)
  %501 = bitcast <8 x i1> %499 to i8
  %502 = call i8 @llvm.cttz.i8(i8 %501, i1 false)
  %503 = zext i8 %502 to i32
  %504 = select i1 %500, i32 %503, i32 0
  %.state574 = load <8 x i64>, ptr %.slot56, align 64
  %505 = icmp slt <8 x i64> %.state574, splat (i64 40)
  %506 = and <8 x i1> %499, %505
  %507 = xor <8 x i1> %505, splat (i1 true)
  %508 = and <8 x i1> %499, %507
  %509 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %506)
  %510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %508)
  %511 = and i1 %509, %510
  br i1 %511, label %varying.divergent575, label %varying.coherent576

schedule.25:                                      ; preds = %varying.coherent.true581, %scheduler.dispatch.route
  %512 = load <8 x i1>, ptr %current.mask, align 1
  %513 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %512)
  %514 = bitcast <8 x i1> %512 to i8
  %515 = call i8 @llvm.cttz.i8(i8 %514, i1 false)
  %516 = zext i8 %515 to i32
  %517 = select i1 %513, i32 %516, i32 0
  %.state583 = load <8 x i64>, ptr %.slot56, align 64
  %518 = add <8 x i64> zeroinitializer, %.state583
  %tile_snapshot.spill.load584 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %519 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load584, 0
  %520 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load584, 1
  %521 = mul <8 x i64> %518, splat (i64 32)
  %522 = add <8 x i64> %520, %521
  %523 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %519, 0
  %524 = insertvalue { <8 x ptr>, <8 x i64> } %523, <8 x i64> %522, 1
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %524, 0
  %526 = extractvalue { <8 x ptr>, <8 x i64> } %524, 1
  %527 = getelementptr i8, <8 x ptr> %525, <8 x i64> %526
  %528 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %527, <8 x i1> %512, <8 x float> zeroinitializer)
  %.state585 = load <8 x i64>, ptr %.slot56, align 64
  %529 = add <8 x i64> splat (i64 40), %.state585
  %tile_snapshot.spill.load586 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load586, 0
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load586, 1
  %532 = mul <8 x i64> %529, splat (i64 32)
  %533 = add <8 x i64> %531, %532
  %534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %530, 0
  %535 = insertvalue { <8 x ptr>, <8 x i64> } %534, <8 x i64> %533, 1
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %535, 0
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %535, 1
  %538 = getelementptr i8, <8 x ptr> %536, <8 x i64> %537
  %539 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %538, <8 x i1> %512, <8 x float> zeroinitializer)
  %.state587 = load <8 x i64>, ptr %.slot56, align 64
  %540 = add <8 x i64> splat (i64 80), %.state587
  %tile_snapshot.spill.load588 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load588, 0
  %542 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load588, 1
  %543 = mul <8 x i64> %540, splat (i64 32)
  %544 = add <8 x i64> %542, %543
  %545 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %541, 0
  %546 = insertvalue { <8 x ptr>, <8 x i64> } %545, <8 x i64> %544, 1
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %546, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %546, 1
  %549 = getelementptr i8, <8 x ptr> %547, <8 x i64> %548
  %550 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %549, <8 x i1> %512, <8 x float> zeroinitializer)
  %.state589 = load <8 x i64>, ptr %.slot56, align 64
  %551 = add <8 x i64> splat (i64 120), %.state589
  %tile_snapshot.spill.load590 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load590, 0
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load590, 1
  %554 = mul <8 x i64> %551, splat (i64 32)
  %555 = add <8 x i64> %553, %554
  %556 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %552, 0
  %557 = insertvalue { <8 x ptr>, <8 x i64> } %556, <8 x i64> %555, 1
  %558 = extractvalue { <8 x ptr>, <8 x i64> } %557, 0
  %559 = extractvalue { <8 x ptr>, <8 x i64> } %557, 1
  %560 = getelementptr i8, <8 x ptr> %558, <8 x i64> %559
  %561 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %560, <8 x i1> %512, <8 x float> zeroinitializer)
  %562 = fmul <8 x float> %528, %550
  %.state591 = load <8 x float>, ptr %.slot69, align 32
  %563 = fadd <8 x float> %.state591, %562
  %564 = fmul <8 x float> %528, %561
  %.state592 = load <8 x float>, ptr %.slot70, align 32
  %565 = fadd <8 x float> %.state592, %564
  %566 = fmul <8 x float> %539, %550
  %.state593 = load <8 x float>, ptr %.slot71, align 32
  %567 = fadd <8 x float> %.state593, %566
  %568 = fmul <8 x float> %539, %561
  %.state594 = load <8 x float>, ptr %.slot72, align 32
  %569 = fadd <8 x float> %.state594, %568
  %.state595 = load <8 x i64>, ptr %.slot56, align 64
  %570 = add <8 x i64> %.state595, splat (i64 1)
  %571 = load <8 x i64>, ptr %.slot56, align 64
  %572 = select <8 x i1> %512, <8 x i64> %570, <8 x i64> %571
  store <8 x i64> %572, ptr %.slot56, align 64
  %573 = load <8 x float>, ptr %.slot69, align 32
  %574 = select <8 x i1> %512, <8 x float> %563, <8 x float> %573
  store <8 x float> %574, ptr %.slot69, align 32
  %575 = load <8 x float>, ptr %.slot70, align 32
  %576 = select <8 x i1> %512, <8 x float> %565, <8 x float> %575
  store <8 x float> %576, ptr %.slot70, align 32
  %577 = load <8 x float>, ptr %.slot71, align 32
  %578 = select <8 x i1> %512, <8 x float> %567, <8 x float> %577
  store <8 x float> %578, ptr %.slot71, align 32
  %579 = load <8 x float>, ptr %.slot72, align 32
  %580 = select <8 x i1> %512, <8 x float> %569, <8 x float> %579
  store <8 x float> %580, ptr %.slot72, align 32
  store <8 x i1> %512, ptr %current.mask, align 1
  %581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %512)
  br i1 %581, label %schedule.24, label %scheduler.loop

schedule.26:                                      ; preds = %varying.coherent.false582, %scheduler.dispatch.route
  %582 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token598 = load i32, ptr %current.token, align 4
  %convergence.token.present599 = icmp ne i32 %convergence.current.token598, 0
  br i1 %convergence.token.present599, label %convergence.cascade596, label %convergence.cascade.exit597

schedule.27:                                      ; preds = %schedule.28, %convergence.target.26.ready, %scheduler.dispatch.route
  %583 = load <8 x i1>, ptr %current.mask, align 1
  %584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %583)
  %585 = bitcast <8 x i1> %583 to i8
  %586 = call i8 @llvm.cttz.i8(i8 %585, i1 false)
  %587 = zext i8 %586 to i32
  %588 = select i1 %584, i32 %587, i32 0
  %.state613 = load <8 x i64>, ptr %.slot56, align 64
  %589 = icmp slt <8 x i64> %.state613, splat (i64 40)
  %590 = and <8 x i1> %583, %589
  %591 = xor <8 x i1> %589, splat (i1 true)
  %592 = and <8 x i1> %583, %591
  %593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %590)
  %594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %592)
  %595 = and i1 %593, %594
  br i1 %595, label %varying.divergent614, label %varying.coherent615

schedule.28:                                      ; preds = %varying.coherent.true620, %scheduler.dispatch.route
  %596 = load <8 x i1>, ptr %current.mask, align 1
  %597 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %596)
  %598 = bitcast <8 x i1> %596 to i8
  %599 = call i8 @llvm.cttz.i8(i8 %598, i1 false)
  %600 = zext i8 %599 to i32
  %601 = select i1 %597, i32 %600, i32 0
  %.state622 = load <8 x i64>, ptr %.slot56, align 64
  %602 = add <8 x i64> zeroinitializer, %.state622
  %tile_snapshot.spill.load623 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load623, 0
  %604 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load623, 1
  %605 = mul <8 x i64> %602, splat (i64 32)
  %606 = add <8 x i64> %604, %605
  %607 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %603, 0
  %608 = insertvalue { <8 x ptr>, <8 x i64> } %607, <8 x i64> %606, 1
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %608, 0
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %608, 1
  %611 = getelementptr i8, <8 x ptr> %609, <8 x i64> %610
  %612 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %611, <8 x i1> %596, <8 x float> zeroinitializer)
  %.state624 = load <8 x i64>, ptr %.slot56, align 64
  %613 = add <8 x i64> splat (i64 40), %.state624
  %tile_snapshot.spill.load625 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load625, 0
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load625, 1
  %616 = mul <8 x i64> %613, splat (i64 32)
  %617 = add <8 x i64> %615, %616
  %618 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %614, 0
  %619 = insertvalue { <8 x ptr>, <8 x i64> } %618, <8 x i64> %617, 1
  %620 = extractvalue { <8 x ptr>, <8 x i64> } %619, 0
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %619, 1
  %622 = getelementptr i8, <8 x ptr> %620, <8 x i64> %621
  %623 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %622, <8 x i1> %596, <8 x float> zeroinitializer)
  %.state626 = load <8 x i64>, ptr %.slot56, align 64
  %624 = add <8 x i64> splat (i64 160), %.state626
  %tile_snapshot.spill.load627 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %625 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load627, 0
  %626 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load627, 1
  %627 = mul <8 x i64> %624, splat (i64 32)
  %628 = add <8 x i64> %626, %627
  %629 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %625, 0
  %630 = insertvalue { <8 x ptr>, <8 x i64> } %629, <8 x i64> %628, 1
  %631 = extractvalue { <8 x ptr>, <8 x i64> } %630, 0
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %630, 1
  %633 = getelementptr i8, <8 x ptr> %631, <8 x i64> %632
  %634 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %633, <8 x i1> %596, <8 x float> zeroinitializer)
  %.state628 = load <8 x i64>, ptr %.slot56, align 64
  %635 = add <8 x i64> splat (i64 200), %.state628
  %tile_snapshot.spill.load629 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load629, 0
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load629, 1
  %638 = mul <8 x i64> %635, splat (i64 32)
  %639 = add <8 x i64> %637, %638
  %640 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %636, 0
  %641 = insertvalue { <8 x ptr>, <8 x i64> } %640, <8 x i64> %639, 1
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %641, 0
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %641, 1
  %644 = getelementptr i8, <8 x ptr> %642, <8 x i64> %643
  %645 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %644, <8 x i1> %596, <8 x float> zeroinitializer)
  %646 = fmul <8 x float> %612, %634
  %.state630 = load <8 x float>, ptr %.slot74, align 32
  %647 = fadd <8 x float> %.state630, %646
  %648 = fmul <8 x float> %612, %645
  %.state631 = load <8 x float>, ptr %.slot75, align 32
  %649 = fadd <8 x float> %.state631, %648
  %650 = fmul <8 x float> %623, %634
  %.state632 = load <8 x float>, ptr %.slot76, align 32
  %651 = fadd <8 x float> %.state632, %650
  %652 = fmul <8 x float> %623, %645
  %.state633 = load <8 x float>, ptr %.slot77, align 32
  %653 = fadd <8 x float> %.state633, %652
  %.state634 = load <8 x i64>, ptr %.slot56, align 64
  %654 = add <8 x i64> %.state634, splat (i64 1)
  %655 = load <8 x i64>, ptr %.slot56, align 64
  %656 = select <8 x i1> %596, <8 x i64> %654, <8 x i64> %655
  store <8 x i64> %656, ptr %.slot56, align 64
  %657 = load <8 x float>, ptr %.slot74, align 32
  %658 = select <8 x i1> %596, <8 x float> %647, <8 x float> %657
  store <8 x float> %658, ptr %.slot74, align 32
  %659 = load <8 x float>, ptr %.slot75, align 32
  %660 = select <8 x i1> %596, <8 x float> %649, <8 x float> %659
  store <8 x float> %660, ptr %.slot75, align 32
  %661 = load <8 x float>, ptr %.slot76, align 32
  %662 = select <8 x i1> %596, <8 x float> %651, <8 x float> %661
  store <8 x float> %662, ptr %.slot76, align 32
  %663 = load <8 x float>, ptr %.slot77, align 32
  %664 = select <8 x i1> %596, <8 x float> %653, <8 x float> %663
  store <8 x float> %664, ptr %.slot77, align 32
  store <8 x i1> %596, ptr %current.mask, align 1
  %665 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %596)
  br i1 %665, label %schedule.27, label %scheduler.loop

schedule.29:                                      ; preds = %varying.coherent.false621, %scheduler.dispatch.route
  %666 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token637 = load i32, ptr %current.token, align 4
  %convergence.token.present638 = icmp ne i32 %convergence.current.token637, 0
  br i1 %convergence.token.present638, label %convergence.cascade635, label %convergence.cascade.exit636

schedule.30:                                      ; preds = %schedule.31, %convergence.target.29.ready, %scheduler.dispatch.route
  %667 = load <8 x i1>, ptr %current.mask, align 1
  %668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %667)
  %669 = bitcast <8 x i1> %667 to i8
  %670 = call i8 @llvm.cttz.i8(i8 %669, i1 false)
  %671 = zext i8 %670 to i32
  %672 = select i1 %668, i32 %671, i32 0
  %.state652 = load <8 x i64>, ptr %.slot56, align 64
  %673 = icmp slt <8 x i64> %.state652, splat (i64 40)
  %674 = and <8 x i1> %667, %673
  %675 = xor <8 x i1> %673, splat (i1 true)
  %676 = and <8 x i1> %667, %675
  %677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %674)
  %678 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %676)
  %679 = and i1 %677, %678
  br i1 %679, label %varying.divergent653, label %varying.coherent654

schedule.31:                                      ; preds = %varying.coherent.true659, %scheduler.dispatch.route
  %680 = load <8 x i1>, ptr %current.mask, align 1
  %681 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %680)
  %682 = bitcast <8 x i1> %680 to i8
  %683 = call i8 @llvm.cttz.i8(i8 %682, i1 false)
  %684 = zext i8 %683 to i32
  %685 = select i1 %681, i32 %684, i32 0
  %.state661 = load <8 x i64>, ptr %.slot56, align 64
  %686 = add <8 x i64> zeroinitializer, %.state661
  %tile_snapshot.spill.load662 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load662, 0
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load662, 1
  %689 = mul <8 x i64> %686, splat (i64 32)
  %690 = add <8 x i64> %688, %689
  %691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %687, 0
  %692 = insertvalue { <8 x ptr>, <8 x i64> } %691, <8 x i64> %690, 1
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %692, 0
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %692, 1
  %695 = getelementptr i8, <8 x ptr> %693, <8 x i64> %694
  %696 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %695, <8 x i1> %680, <8 x float> zeroinitializer)
  %.state663 = load <8 x i64>, ptr %.slot56, align 64
  %697 = add <8 x i64> splat (i64 40), %.state663
  %tile_snapshot.spill.load664 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %698 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load664, 0
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load664, 1
  %700 = mul <8 x i64> %697, splat (i64 32)
  %701 = add <8 x i64> %699, %700
  %702 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %698, 0
  %703 = insertvalue { <8 x ptr>, <8 x i64> } %702, <8 x i64> %701, 1
  %704 = extractvalue { <8 x ptr>, <8 x i64> } %703, 0
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %703, 1
  %706 = getelementptr i8, <8 x ptr> %704, <8 x i64> %705
  %707 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %706, <8 x i1> %680, <8 x float> zeroinitializer)
  %.state665 = load <8 x i64>, ptr %.slot56, align 64
  %708 = add <8 x i64> splat (i64 240), %.state665
  %tile_snapshot.spill.load666 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load666, 0
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load666, 1
  %711 = mul <8 x i64> %708, splat (i64 32)
  %712 = add <8 x i64> %710, %711
  %713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %709, 0
  %714 = insertvalue { <8 x ptr>, <8 x i64> } %713, <8 x i64> %712, 1
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %714, 0
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %714, 1
  %717 = getelementptr i8, <8 x ptr> %715, <8 x i64> %716
  %718 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %717, <8 x i1> %680, <8 x float> zeroinitializer)
  %.state667 = load <8 x i64>, ptr %.slot56, align 64
  %719 = add <8 x i64> splat (i64 280), %.state667
  %tile_snapshot.spill.load668 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %720 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load668, 0
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load668, 1
  %722 = mul <8 x i64> %719, splat (i64 32)
  %723 = add <8 x i64> %721, %722
  %724 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %720, 0
  %725 = insertvalue { <8 x ptr>, <8 x i64> } %724, <8 x i64> %723, 1
  %726 = extractvalue { <8 x ptr>, <8 x i64> } %725, 0
  %727 = extractvalue { <8 x ptr>, <8 x i64> } %725, 1
  %728 = getelementptr i8, <8 x ptr> %726, <8 x i64> %727
  %729 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %728, <8 x i1> %680, <8 x float> zeroinitializer)
  %730 = fmul <8 x float> %696, %718
  %.state669 = load <8 x float>, ptr %.slot79, align 32
  %731 = fadd <8 x float> %.state669, %730
  %732 = fmul <8 x float> %696, %729
  %.state670 = load <8 x float>, ptr %.slot80, align 32
  %733 = fadd <8 x float> %.state670, %732
  %734 = fmul <8 x float> %707, %718
  %.state671 = load <8 x float>, ptr %.slot81, align 32
  %735 = fadd <8 x float> %.state671, %734
  %736 = fmul <8 x float> %707, %729
  %.state672 = load <8 x float>, ptr %.slot82, align 32
  %737 = fadd <8 x float> %.state672, %736
  %.state673 = load <8 x i64>, ptr %.slot56, align 64
  %738 = add <8 x i64> %.state673, splat (i64 1)
  %739 = load <8 x i64>, ptr %.slot56, align 64
  %740 = select <8 x i1> %680, <8 x i64> %738, <8 x i64> %739
  store <8 x i64> %740, ptr %.slot56, align 64
  %741 = load <8 x float>, ptr %.slot79, align 32
  %742 = select <8 x i1> %680, <8 x float> %731, <8 x float> %741
  store <8 x float> %742, ptr %.slot79, align 32
  %743 = load <8 x float>, ptr %.slot80, align 32
  %744 = select <8 x i1> %680, <8 x float> %733, <8 x float> %743
  store <8 x float> %744, ptr %.slot80, align 32
  %745 = load <8 x float>, ptr %.slot81, align 32
  %746 = select <8 x i1> %680, <8 x float> %735, <8 x float> %745
  store <8 x float> %746, ptr %.slot81, align 32
  %747 = load <8 x float>, ptr %.slot82, align 32
  %748 = select <8 x i1> %680, <8 x float> %737, <8 x float> %747
  store <8 x float> %748, ptr %.slot82, align 32
  store <8 x i1> %680, ptr %current.mask, align 1
  %749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %680)
  br i1 %749, label %schedule.30, label %scheduler.loop

schedule.32:                                      ; preds = %varying.coherent.false660, %scheduler.dispatch.route
  %750 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token676 = load i32, ptr %current.token, align 4
  %convergence.token.present677 = icmp ne i32 %convergence.current.token676, 0
  br i1 %convergence.token.present677, label %convergence.cascade674, label %convergence.cascade.exit675

schedule.33:                                      ; preds = %schedule.34, %convergence.target.32.ready, %scheduler.dispatch.route
  %751 = load <8 x i1>, ptr %current.mask, align 1
  %752 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %751)
  %753 = bitcast <8 x i1> %751 to i8
  %754 = call i8 @llvm.cttz.i8(i8 %753, i1 false)
  %755 = zext i8 %754 to i32
  %756 = select i1 %752, i32 %755, i32 0
  %.state691 = load <8 x i64>, ptr %.slot56, align 64
  %757 = icmp slt <8 x i64> %.state691, splat (i64 40)
  %758 = and <8 x i1> %751, %757
  %759 = xor <8 x i1> %757, splat (i1 true)
  %760 = and <8 x i1> %751, %759
  %761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %758)
  %762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %760)
  %763 = and i1 %761, %762
  br i1 %763, label %varying.divergent692, label %varying.coherent693

schedule.34:                                      ; preds = %varying.coherent.true698, %scheduler.dispatch.route
  %764 = load <8 x i1>, ptr %current.mask, align 1
  %765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %764)
  %766 = bitcast <8 x i1> %764 to i8
  %767 = call i8 @llvm.cttz.i8(i8 %766, i1 false)
  %768 = zext i8 %767 to i32
  %769 = select i1 %765, i32 %768, i32 0
  %.state700 = load <8 x i64>, ptr %.slot56, align 64
  %770 = add <8 x i64> zeroinitializer, %.state700
  %tile_snapshot.spill.load701 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %771 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load701, 0
  %772 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load701, 1
  %773 = mul <8 x i64> %770, splat (i64 32)
  %774 = add <8 x i64> %772, %773
  %775 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %771, 0
  %776 = insertvalue { <8 x ptr>, <8 x i64> } %775, <8 x i64> %774, 1
  %777 = extractvalue { <8 x ptr>, <8 x i64> } %776, 0
  %778 = extractvalue { <8 x ptr>, <8 x i64> } %776, 1
  %779 = getelementptr i8, <8 x ptr> %777, <8 x i64> %778
  %780 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %779, <8 x i1> %764, <8 x float> zeroinitializer)
  %.state702 = load <8 x i64>, ptr %.slot56, align 64
  %781 = add <8 x i64> splat (i64 40), %.state702
  %tile_snapshot.spill.load703 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 0
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 1
  %784 = mul <8 x i64> %781, splat (i64 32)
  %785 = add <8 x i64> %783, %784
  %786 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %782, 0
  %787 = insertvalue { <8 x ptr>, <8 x i64> } %786, <8 x i64> %785, 1
  %788 = extractvalue { <8 x ptr>, <8 x i64> } %787, 0
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %787, 1
  %790 = getelementptr i8, <8 x ptr> %788, <8 x i64> %789
  %791 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %790, <8 x i1> %764, <8 x float> zeroinitializer)
  %.state704 = load <8 x i64>, ptr %.slot56, align 64
  %792 = add <8 x i64> splat (i64 320), %.state704
  %tile_snapshot.spill.load705 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %793 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load705, 0
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load705, 1
  %795 = mul <8 x i64> %792, splat (i64 32)
  %796 = add <8 x i64> %794, %795
  %797 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %793, 0
  %798 = insertvalue { <8 x ptr>, <8 x i64> } %797, <8 x i64> %796, 1
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %798, 0
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %798, 1
  %801 = getelementptr i8, <8 x ptr> %799, <8 x i64> %800
  %802 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %801, <8 x i1> %764, <8 x float> zeroinitializer)
  %.state706 = load <8 x i64>, ptr %.slot56, align 64
  %803 = add <8 x i64> splat (i64 360), %.state706
  %tile_snapshot.spill.load707 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load707, 0
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load707, 1
  %806 = mul <8 x i64> %803, splat (i64 32)
  %807 = add <8 x i64> %805, %806
  %808 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %804, 0
  %809 = insertvalue { <8 x ptr>, <8 x i64> } %808, <8 x i64> %807, 1
  %810 = extractvalue { <8 x ptr>, <8 x i64> } %809, 0
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %809, 1
  %812 = getelementptr i8, <8 x ptr> %810, <8 x i64> %811
  %813 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %812, <8 x i1> %764, <8 x float> zeroinitializer)
  %814 = fmul <8 x float> %780, %802
  %.state708 = load <8 x float>, ptr %.slot84, align 32
  %815 = fadd <8 x float> %.state708, %814
  %816 = fmul <8 x float> %780, %813
  %.state709 = load <8 x float>, ptr %.slot85, align 32
  %817 = fadd <8 x float> %.state709, %816
  %818 = fmul <8 x float> %791, %802
  %.state710 = load <8 x float>, ptr %.slot86, align 32
  %819 = fadd <8 x float> %.state710, %818
  %820 = fmul <8 x float> %791, %813
  %.state711 = load <8 x float>, ptr %.slot87, align 32
  %821 = fadd <8 x float> %.state711, %820
  %.state712 = load <8 x i64>, ptr %.slot56, align 64
  %822 = add <8 x i64> %.state712, splat (i64 1)
  %823 = load <8 x i64>, ptr %.slot56, align 64
  %824 = select <8 x i1> %764, <8 x i64> %822, <8 x i64> %823
  store <8 x i64> %824, ptr %.slot56, align 64
  %825 = load <8 x float>, ptr %.slot84, align 32
  %826 = select <8 x i1> %764, <8 x float> %815, <8 x float> %825
  store <8 x float> %826, ptr %.slot84, align 32
  %827 = load <8 x float>, ptr %.slot85, align 32
  %828 = select <8 x i1> %764, <8 x float> %817, <8 x float> %827
  store <8 x float> %828, ptr %.slot85, align 32
  %829 = load <8 x float>, ptr %.slot86, align 32
  %830 = select <8 x i1> %764, <8 x float> %819, <8 x float> %829
  store <8 x float> %830, ptr %.slot86, align 32
  %831 = load <8 x float>, ptr %.slot87, align 32
  %832 = select <8 x i1> %764, <8 x float> %821, <8 x float> %831
  store <8 x float> %832, ptr %.slot87, align 32
  store <8 x i1> %764, ptr %current.mask, align 1
  %833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %764)
  br i1 %833, label %schedule.33, label %scheduler.loop

schedule.35:                                      ; preds = %varying.coherent.false699, %scheduler.dispatch.route
  %834 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token715 = load i32, ptr %current.token, align 4
  %convergence.token.present716 = icmp ne i32 %convergence.current.token715, 0
  br i1 %convergence.token.present716, label %convergence.cascade713, label %convergence.cascade.exit714

schedule.36:                                      ; preds = %schedule.37, %convergence.target.35.ready, %scheduler.dispatch.route
  %835 = load <8 x i1>, ptr %current.mask, align 1
  %836 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %835)
  %837 = bitcast <8 x i1> %835 to i8
  %838 = call i8 @llvm.cttz.i8(i8 %837, i1 false)
  %839 = zext i8 %838 to i32
  %840 = select i1 %836, i32 %839, i32 0
  %.state730 = load <8 x i64>, ptr %.slot56, align 64
  %841 = icmp slt <8 x i64> %.state730, splat (i64 40)
  %842 = and <8 x i1> %835, %841
  %843 = xor <8 x i1> %841, splat (i1 true)
  %844 = and <8 x i1> %835, %843
  %845 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %842)
  %846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %844)
  %847 = and i1 %845, %846
  br i1 %847, label %varying.divergent731, label %varying.coherent732

schedule.37:                                      ; preds = %varying.coherent.true737, %scheduler.dispatch.route
  %848 = load <8 x i1>, ptr %current.mask, align 1
  %849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %848)
  %850 = bitcast <8 x i1> %848 to i8
  %851 = call i8 @llvm.cttz.i8(i8 %850, i1 false)
  %852 = zext i8 %851 to i32
  %853 = select i1 %849, i32 %852, i32 0
  %.state739 = load <8 x i64>, ptr %.slot56, align 64
  %854 = add <8 x i64> zeroinitializer, %.state739
  %tile_snapshot.spill.load740 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %855 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load740, 0
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load740, 1
  %857 = mul <8 x i64> %854, splat (i64 32)
  %858 = add <8 x i64> %856, %857
  %859 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %855, 0
  %860 = insertvalue { <8 x ptr>, <8 x i64> } %859, <8 x i64> %858, 1
  %861 = extractvalue { <8 x ptr>, <8 x i64> } %860, 0
  %862 = extractvalue { <8 x ptr>, <8 x i64> } %860, 1
  %863 = getelementptr i8, <8 x ptr> %861, <8 x i64> %862
  %864 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %863, <8 x i1> %848, <8 x float> zeroinitializer)
  %.state741 = load <8 x i64>, ptr %.slot56, align 64
  %865 = add <8 x i64> splat (i64 40), %.state741
  %tile_snapshot.spill.load742 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load742, 0
  %867 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load742, 1
  %868 = mul <8 x i64> %865, splat (i64 32)
  %869 = add <8 x i64> %867, %868
  %870 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %866, 0
  %871 = insertvalue { <8 x ptr>, <8 x i64> } %870, <8 x i64> %869, 1
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %871, 0
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %871, 1
  %874 = getelementptr i8, <8 x ptr> %872, <8 x i64> %873
  %875 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %874, <8 x i1> %848, <8 x float> zeroinitializer)
  %.state743 = load <8 x i64>, ptr %.slot56, align 64
  %876 = add <8 x i64> splat (i64 400), %.state743
  %tile_snapshot.spill.load744 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load744, 0
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load744, 1
  %879 = mul <8 x i64> %876, splat (i64 32)
  %880 = add <8 x i64> %878, %879
  %881 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %877, 0
  %882 = insertvalue { <8 x ptr>, <8 x i64> } %881, <8 x i64> %880, 1
  %883 = extractvalue { <8 x ptr>, <8 x i64> } %882, 0
  %884 = extractvalue { <8 x ptr>, <8 x i64> } %882, 1
  %885 = getelementptr i8, <8 x ptr> %883, <8 x i64> %884
  %886 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %885, <8 x i1> %848, <8 x float> zeroinitializer)
  %.state745 = load <8 x i64>, ptr %.slot56, align 64
  %887 = add <8 x i64> splat (i64 440), %.state745
  %tile_snapshot.spill.load746 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %888 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load746, 0
  %889 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load746, 1
  %890 = mul <8 x i64> %887, splat (i64 32)
  %891 = add <8 x i64> %889, %890
  %892 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %888, 0
  %893 = insertvalue { <8 x ptr>, <8 x i64> } %892, <8 x i64> %891, 1
  %894 = extractvalue { <8 x ptr>, <8 x i64> } %893, 0
  %895 = extractvalue { <8 x ptr>, <8 x i64> } %893, 1
  %896 = getelementptr i8, <8 x ptr> %894, <8 x i64> %895
  %897 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %896, <8 x i1> %848, <8 x float> zeroinitializer)
  %898 = fmul <8 x float> %864, %886
  %.state747 = load <8 x float>, ptr %.slot89, align 32
  %899 = fadd <8 x float> %.state747, %898
  %900 = fmul <8 x float> %864, %897
  %.state748 = load <8 x float>, ptr %.slot90, align 32
  %901 = fadd <8 x float> %.state748, %900
  %902 = fmul <8 x float> %875, %886
  %.state749 = load <8 x float>, ptr %.slot91, align 32
  %903 = fadd <8 x float> %.state749, %902
  %904 = fmul <8 x float> %875, %897
  %.state750 = load <8 x float>, ptr %.slot92, align 32
  %905 = fadd <8 x float> %.state750, %904
  %.state751 = load <8 x i64>, ptr %.slot56, align 64
  %906 = add <8 x i64> %.state751, splat (i64 1)
  %907 = load <8 x i64>, ptr %.slot56, align 64
  %908 = select <8 x i1> %848, <8 x i64> %906, <8 x i64> %907
  store <8 x i64> %908, ptr %.slot56, align 64
  %909 = load <8 x float>, ptr %.slot89, align 32
  %910 = select <8 x i1> %848, <8 x float> %899, <8 x float> %909
  store <8 x float> %910, ptr %.slot89, align 32
  %911 = load <8 x float>, ptr %.slot90, align 32
  %912 = select <8 x i1> %848, <8 x float> %901, <8 x float> %911
  store <8 x float> %912, ptr %.slot90, align 32
  %913 = load <8 x float>, ptr %.slot91, align 32
  %914 = select <8 x i1> %848, <8 x float> %903, <8 x float> %913
  store <8 x float> %914, ptr %.slot91, align 32
  %915 = load <8 x float>, ptr %.slot92, align 32
  %916 = select <8 x i1> %848, <8 x float> %905, <8 x float> %915
  store <8 x float> %916, ptr %.slot92, align 32
  store <8 x i1> %848, ptr %current.mask, align 1
  %917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %848)
  br i1 %917, label %schedule.36, label %scheduler.loop

schedule.38:                                      ; preds = %varying.coherent.false738, %scheduler.dispatch.route
  %918 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token754 = load i32, ptr %current.token, align 4
  %convergence.token.present755 = icmp ne i32 %convergence.current.token754, 0
  br i1 %convergence.token.present755, label %convergence.cascade752, label %convergence.cascade.exit753

schedule.39:                                      ; preds = %schedule.40, %convergence.target.38.ready, %scheduler.dispatch.route
  %919 = load <8 x i1>, ptr %current.mask, align 1
  %920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %919)
  %921 = bitcast <8 x i1> %919 to i8
  %922 = call i8 @llvm.cttz.i8(i8 %921, i1 false)
  %923 = zext i8 %922 to i32
  %924 = select i1 %920, i32 %923, i32 0
  %.state769 = load <8 x i64>, ptr %.slot56, align 64
  %925 = icmp slt <8 x i64> %.state769, splat (i64 40)
  %926 = and <8 x i1> %919, %925
  %927 = xor <8 x i1> %925, splat (i1 true)
  %928 = and <8 x i1> %919, %927
  %929 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %926)
  %930 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %928)
  %931 = and i1 %929, %930
  br i1 %931, label %varying.divergent770, label %varying.coherent771

schedule.40:                                      ; preds = %varying.coherent.true776, %scheduler.dispatch.route
  %932 = load <8 x i1>, ptr %current.mask, align 1
  %933 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %932)
  %934 = bitcast <8 x i1> %932 to i8
  %935 = call i8 @llvm.cttz.i8(i8 %934, i1 false)
  %936 = zext i8 %935 to i32
  %937 = select i1 %933, i32 %936, i32 0
  %.state778 = load <8 x i64>, ptr %.slot56, align 64
  %938 = add <8 x i64> zeroinitializer, %.state778
  %tile_snapshot.spill.load779 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %939 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load779, 0
  %940 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load779, 1
  %941 = mul <8 x i64> %938, splat (i64 32)
  %942 = add <8 x i64> %940, %941
  %943 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %939, 0
  %944 = insertvalue { <8 x ptr>, <8 x i64> } %943, <8 x i64> %942, 1
  %945 = extractvalue { <8 x ptr>, <8 x i64> } %944, 0
  %946 = extractvalue { <8 x ptr>, <8 x i64> } %944, 1
  %947 = getelementptr i8, <8 x ptr> %945, <8 x i64> %946
  %948 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %947, <8 x i1> %932, <8 x float> zeroinitializer)
  %.state780 = load <8 x i64>, ptr %.slot56, align 64
  %949 = add <8 x i64> splat (i64 40), %.state780
  %tile_snapshot.spill.load781 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load781, 0
  %951 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load781, 1
  %952 = mul <8 x i64> %949, splat (i64 32)
  %953 = add <8 x i64> %951, %952
  %954 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %950, 0
  %955 = insertvalue { <8 x ptr>, <8 x i64> } %954, <8 x i64> %953, 1
  %956 = extractvalue { <8 x ptr>, <8 x i64> } %955, 0
  %957 = extractvalue { <8 x ptr>, <8 x i64> } %955, 1
  %958 = getelementptr i8, <8 x ptr> %956, <8 x i64> %957
  %959 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %958, <8 x i1> %932, <8 x float> zeroinitializer)
  %.state782 = load <8 x i64>, ptr %.slot56, align 64
  %960 = add <8 x i64> splat (i64 480), %.state782
  %tile_snapshot.spill.load783 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 0
  %962 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load783, 1
  %963 = mul <8 x i64> %960, splat (i64 32)
  %964 = add <8 x i64> %962, %963
  %965 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %961, 0
  %966 = insertvalue { <8 x ptr>, <8 x i64> } %965, <8 x i64> %964, 1
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %966, 0
  %968 = extractvalue { <8 x ptr>, <8 x i64> } %966, 1
  %969 = getelementptr i8, <8 x ptr> %967, <8 x i64> %968
  %970 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %969, <8 x i1> %932, <8 x float> zeroinitializer)
  %.state784 = load <8 x i64>, ptr %.slot56, align 64
  %971 = add <8 x i64> splat (i64 520), %.state784
  %tile_snapshot.spill.load785 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %972 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load785, 0
  %973 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load785, 1
  %974 = mul <8 x i64> %971, splat (i64 32)
  %975 = add <8 x i64> %973, %974
  %976 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %972, 0
  %977 = insertvalue { <8 x ptr>, <8 x i64> } %976, <8 x i64> %975, 1
  %978 = extractvalue { <8 x ptr>, <8 x i64> } %977, 0
  %979 = extractvalue { <8 x ptr>, <8 x i64> } %977, 1
  %980 = getelementptr i8, <8 x ptr> %978, <8 x i64> %979
  %981 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %980, <8 x i1> %932, <8 x float> zeroinitializer)
  %982 = fmul <8 x float> %948, %970
  %.state786 = load <8 x float>, ptr %.slot94, align 32
  %983 = fadd <8 x float> %.state786, %982
  %984 = fmul <8 x float> %948, %981
  %.state787 = load <8 x float>, ptr %.slot95, align 32
  %985 = fadd <8 x float> %.state787, %984
  %986 = fmul <8 x float> %959, %970
  %.state788 = load <8 x float>, ptr %.slot96, align 32
  %987 = fadd <8 x float> %.state788, %986
  %988 = fmul <8 x float> %959, %981
  %.state789 = load <8 x float>, ptr %.slot97, align 32
  %989 = fadd <8 x float> %.state789, %988
  %.state790 = load <8 x i64>, ptr %.slot56, align 64
  %990 = add <8 x i64> %.state790, splat (i64 1)
  %991 = load <8 x i64>, ptr %.slot56, align 64
  %992 = select <8 x i1> %932, <8 x i64> %990, <8 x i64> %991
  store <8 x i64> %992, ptr %.slot56, align 64
  %993 = load <8 x float>, ptr %.slot94, align 32
  %994 = select <8 x i1> %932, <8 x float> %983, <8 x float> %993
  store <8 x float> %994, ptr %.slot94, align 32
  %995 = load <8 x float>, ptr %.slot95, align 32
  %996 = select <8 x i1> %932, <8 x float> %985, <8 x float> %995
  store <8 x float> %996, ptr %.slot95, align 32
  %997 = load <8 x float>, ptr %.slot96, align 32
  %998 = select <8 x i1> %932, <8 x float> %987, <8 x float> %997
  store <8 x float> %998, ptr %.slot96, align 32
  %999 = load <8 x float>, ptr %.slot97, align 32
  %1000 = select <8 x i1> %932, <8 x float> %989, <8 x float> %999
  store <8 x float> %1000, ptr %.slot97, align 32
  store <8 x i1> %932, ptr %current.mask, align 1
  %1001 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %932)
  br i1 %1001, label %schedule.39, label %scheduler.loop

schedule.41:                                      ; preds = %varying.coherent.false777, %scheduler.dispatch.route
  %1002 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token793 = load i32, ptr %current.token, align 4
  %convergence.token.present794 = icmp ne i32 %convergence.current.token793, 0
  br i1 %convergence.token.present794, label %convergence.cascade791, label %convergence.cascade.exit792

schedule.42:                                      ; preds = %schedule.43, %convergence.target.41.ready, %scheduler.dispatch.route
  %1003 = load <8 x i1>, ptr %current.mask, align 1
  %1004 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1003)
  %1005 = bitcast <8 x i1> %1003 to i8
  %1006 = call i8 @llvm.cttz.i8(i8 %1005, i1 false)
  %1007 = zext i8 %1006 to i32
  %1008 = select i1 %1004, i32 %1007, i32 0
  %.state808 = load <8 x i64>, ptr %.slot56, align 64
  %1009 = icmp slt <8 x i64> %.state808, splat (i64 40)
  %1010 = and <8 x i1> %1003, %1009
  %1011 = xor <8 x i1> %1009, splat (i1 true)
  %1012 = and <8 x i1> %1003, %1011
  %1013 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1010)
  %1014 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1012)
  %1015 = and i1 %1013, %1014
  br i1 %1015, label %varying.divergent809, label %varying.coherent810

schedule.43:                                      ; preds = %varying.coherent.true815, %scheduler.dispatch.route
  %1016 = load <8 x i1>, ptr %current.mask, align 1
  %1017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1016)
  %1018 = bitcast <8 x i1> %1016 to i8
  %1019 = call i8 @llvm.cttz.i8(i8 %1018, i1 false)
  %1020 = zext i8 %1019 to i32
  %1021 = select i1 %1017, i32 %1020, i32 0
  %.state817 = load <8 x i64>, ptr %.slot56, align 64
  %1022 = add <8 x i64> zeroinitializer, %.state817
  %tile_snapshot.spill.load818 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 0
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 1
  %1025 = mul <8 x i64> %1022, splat (i64 32)
  %1026 = add <8 x i64> %1024, %1025
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1023, 0
  %1028 = insertvalue { <8 x ptr>, <8 x i64> } %1027, <8 x i64> %1026, 1
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1028, 0
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %1028, 1
  %1031 = getelementptr i8, <8 x ptr> %1029, <8 x i64> %1030
  %1032 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1031, <8 x i1> %1016, <8 x float> zeroinitializer)
  %.state819 = load <8 x i64>, ptr %.slot56, align 64
  %1033 = add <8 x i64> splat (i64 40), %.state819
  %tile_snapshot.spill.load820 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1034 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load820, 0
  %1035 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load820, 1
  %1036 = mul <8 x i64> %1033, splat (i64 32)
  %1037 = add <8 x i64> %1035, %1036
  %1038 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1034, 0
  %1039 = insertvalue { <8 x ptr>, <8 x i64> } %1038, <8 x i64> %1037, 1
  %1040 = extractvalue { <8 x ptr>, <8 x i64> } %1039, 0
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %1039, 1
  %1042 = getelementptr i8, <8 x ptr> %1040, <8 x i64> %1041
  %1043 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1042, <8 x i1> %1016, <8 x float> zeroinitializer)
  %.state821 = load <8 x i64>, ptr %.slot56, align 64
  %1044 = add <8 x i64> splat (i64 560), %.state821
  %tile_snapshot.spill.load822 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1045 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load822, 0
  %1046 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load822, 1
  %1047 = mul <8 x i64> %1044, splat (i64 32)
  %1048 = add <8 x i64> %1046, %1047
  %1049 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1045, 0
  %1050 = insertvalue { <8 x ptr>, <8 x i64> } %1049, <8 x i64> %1048, 1
  %1051 = extractvalue { <8 x ptr>, <8 x i64> } %1050, 0
  %1052 = extractvalue { <8 x ptr>, <8 x i64> } %1050, 1
  %1053 = getelementptr i8, <8 x ptr> %1051, <8 x i64> %1052
  %1054 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1053, <8 x i1> %1016, <8 x float> zeroinitializer)
  %.state823 = load <8 x i64>, ptr %.slot56, align 64
  %1055 = add <8 x i64> splat (i64 600), %.state823
  %tile_snapshot.spill.load824 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load824, 0
  %1057 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load824, 1
  %1058 = mul <8 x i64> %1055, splat (i64 32)
  %1059 = add <8 x i64> %1057, %1058
  %1060 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1056, 0
  %1061 = insertvalue { <8 x ptr>, <8 x i64> } %1060, <8 x i64> %1059, 1
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %1061, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %1061, 1
  %1064 = getelementptr i8, <8 x ptr> %1062, <8 x i64> %1063
  %1065 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1064, <8 x i1> %1016, <8 x float> zeroinitializer)
  %1066 = fmul <8 x float> %1032, %1054
  %.state825 = load <8 x float>, ptr %.slot99, align 32
  %1067 = fadd <8 x float> %.state825, %1066
  %1068 = fmul <8 x float> %1032, %1065
  %.state826 = load <8 x float>, ptr %.slot100, align 32
  %1069 = fadd <8 x float> %.state826, %1068
  %1070 = fmul <8 x float> %1043, %1054
  %.state827 = load <8 x float>, ptr %.slot101, align 32
  %1071 = fadd <8 x float> %.state827, %1070
  %1072 = fmul <8 x float> %1043, %1065
  %.state828 = load <8 x float>, ptr %.slot102, align 32
  %1073 = fadd <8 x float> %.state828, %1072
  %.state829 = load <8 x i64>, ptr %.slot56, align 64
  %1074 = add <8 x i64> %.state829, splat (i64 1)
  %1075 = load <8 x i64>, ptr %.slot56, align 64
  %1076 = select <8 x i1> %1016, <8 x i64> %1074, <8 x i64> %1075
  store <8 x i64> %1076, ptr %.slot56, align 64
  %1077 = load <8 x float>, ptr %.slot99, align 32
  %1078 = select <8 x i1> %1016, <8 x float> %1067, <8 x float> %1077
  store <8 x float> %1078, ptr %.slot99, align 32
  %1079 = load <8 x float>, ptr %.slot100, align 32
  %1080 = select <8 x i1> %1016, <8 x float> %1069, <8 x float> %1079
  store <8 x float> %1080, ptr %.slot100, align 32
  %1081 = load <8 x float>, ptr %.slot101, align 32
  %1082 = select <8 x i1> %1016, <8 x float> %1071, <8 x float> %1081
  store <8 x float> %1082, ptr %.slot101, align 32
  %1083 = load <8 x float>, ptr %.slot102, align 32
  %1084 = select <8 x i1> %1016, <8 x float> %1073, <8 x float> %1083
  store <8 x float> %1084, ptr %.slot102, align 32
  store <8 x i1> %1016, ptr %current.mask, align 1
  %1085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1016)
  br i1 %1085, label %schedule.42, label %scheduler.loop

schedule.44:                                      ; preds = %varying.coherent.false816, %scheduler.dispatch.route
  %1086 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token832 = load i32, ptr %current.token, align 4
  %convergence.token.present833 = icmp ne i32 %convergence.current.token832, 0
  br i1 %convergence.token.present833, label %convergence.cascade830, label %convergence.cascade.exit831

schedule.45:                                      ; preds = %schedule.46, %convergence.target.44.ready, %scheduler.dispatch.route
  %1087 = load <8 x i1>, ptr %current.mask, align 1
  %1088 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1087)
  %1089 = bitcast <8 x i1> %1087 to i8
  %1090 = call i8 @llvm.cttz.i8(i8 %1089, i1 false)
  %1091 = zext i8 %1090 to i32
  %1092 = select i1 %1088, i32 %1091, i32 0
  %.state847 = load <8 x i64>, ptr %.slot56, align 64
  %1093 = icmp slt <8 x i64> %.state847, splat (i64 40)
  %1094 = and <8 x i1> %1087, %1093
  %1095 = xor <8 x i1> %1093, splat (i1 true)
  %1096 = and <8 x i1> %1087, %1095
  %1097 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1094)
  %1098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1096)
  %1099 = and i1 %1097, %1098
  br i1 %1099, label %varying.divergent848, label %varying.coherent849

schedule.46:                                      ; preds = %varying.coherent.true854, %scheduler.dispatch.route
  %1100 = load <8 x i1>, ptr %current.mask, align 1
  %1101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1100)
  %1102 = bitcast <8 x i1> %1100 to i8
  %1103 = call i8 @llvm.cttz.i8(i8 %1102, i1 false)
  %1104 = zext i8 %1103 to i32
  %1105 = select i1 %1101, i32 %1104, i32 0
  %.state856 = load <8 x i64>, ptr %.slot56, align 64
  %1106 = add <8 x i64> splat (i64 80), %.state856
  %tile_snapshot.spill.load857 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load857, 0
  %1108 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load857, 1
  %1109 = mul <8 x i64> %1106, splat (i64 32)
  %1110 = add <8 x i64> %1108, %1109
  %1111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1107, 0
  %1112 = insertvalue { <8 x ptr>, <8 x i64> } %1111, <8 x i64> %1110, 1
  %1113 = extractvalue { <8 x ptr>, <8 x i64> } %1112, 0
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %1112, 1
  %1115 = getelementptr i8, <8 x ptr> %1113, <8 x i64> %1114
  %1116 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1115, <8 x i1> %1100, <8 x float> zeroinitializer)
  %.state858 = load <8 x i64>, ptr %.slot56, align 64
  %1117 = add <8 x i64> splat (i64 120), %.state858
  %tile_snapshot.spill.load859 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load859, 0
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load859, 1
  %1120 = mul <8 x i64> %1117, splat (i64 32)
  %1121 = add <8 x i64> %1119, %1120
  %1122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1118, 0
  %1123 = insertvalue { <8 x ptr>, <8 x i64> } %1122, <8 x i64> %1121, 1
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %1123, 0
  %1125 = extractvalue { <8 x ptr>, <8 x i64> } %1123, 1
  %1126 = getelementptr i8, <8 x ptr> %1124, <8 x i64> %1125
  %1127 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1126, <8 x i1> %1100, <8 x float> zeroinitializer)
  %.state860 = load <8 x i64>, ptr %.slot56, align 64
  %1128 = add <8 x i64> zeroinitializer, %.state860
  %tile_snapshot.spill.load861 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load861, 0
  %1130 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load861, 1
  %1131 = mul <8 x i64> %1128, splat (i64 32)
  %1132 = add <8 x i64> %1130, %1131
  %1133 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1129, 0
  %1134 = insertvalue { <8 x ptr>, <8 x i64> } %1133, <8 x i64> %1132, 1
  %1135 = extractvalue { <8 x ptr>, <8 x i64> } %1134, 0
  %1136 = extractvalue { <8 x ptr>, <8 x i64> } %1134, 1
  %1137 = getelementptr i8, <8 x ptr> %1135, <8 x i64> %1136
  %1138 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1137, <8 x i1> %1100, <8 x float> zeroinitializer)
  %.state862 = load <8 x i64>, ptr %.slot56, align 64
  %1139 = add <8 x i64> splat (i64 40), %.state862
  %tile_snapshot.spill.load863 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load863, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load863, 1
  %1142 = mul <8 x i64> %1139, splat (i64 32)
  %1143 = add <8 x i64> %1141, %1142
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1145 = insertvalue { <8 x ptr>, <8 x i64> } %1144, <8 x i64> %1143, 1
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1145, 0
  %1147 = extractvalue { <8 x ptr>, <8 x i64> } %1145, 1
  %1148 = getelementptr i8, <8 x ptr> %1146, <8 x i64> %1147
  %1149 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1148, <8 x i1> %1100, <8 x float> zeroinitializer)
  %1150 = fmul <8 x float> %1116, %1138
  %.state864 = load <8 x float>, ptr %.slot104, align 32
  %1151 = fadd <8 x float> %.state864, %1150
  %1152 = fmul <8 x float> %1116, %1149
  %.state865 = load <8 x float>, ptr %.slot105, align 32
  %1153 = fadd <8 x float> %.state865, %1152
  %1154 = fmul <8 x float> %1127, %1138
  %.state866 = load <8 x float>, ptr %.slot106, align 32
  %1155 = fadd <8 x float> %.state866, %1154
  %1156 = fmul <8 x float> %1127, %1149
  %.state867 = load <8 x float>, ptr %.slot107, align 32
  %1157 = fadd <8 x float> %.state867, %1156
  %.state868 = load <8 x i64>, ptr %.slot56, align 64
  %1158 = add <8 x i64> %.state868, splat (i64 1)
  %1159 = load <8 x i64>, ptr %.slot56, align 64
  %1160 = select <8 x i1> %1100, <8 x i64> %1158, <8 x i64> %1159
  store <8 x i64> %1160, ptr %.slot56, align 64
  %1161 = load <8 x float>, ptr %.slot104, align 32
  %1162 = select <8 x i1> %1100, <8 x float> %1151, <8 x float> %1161
  store <8 x float> %1162, ptr %.slot104, align 32
  %1163 = load <8 x float>, ptr %.slot105, align 32
  %1164 = select <8 x i1> %1100, <8 x float> %1153, <8 x float> %1163
  store <8 x float> %1164, ptr %.slot105, align 32
  %1165 = load <8 x float>, ptr %.slot106, align 32
  %1166 = select <8 x i1> %1100, <8 x float> %1155, <8 x float> %1165
  store <8 x float> %1166, ptr %.slot106, align 32
  %1167 = load <8 x float>, ptr %.slot107, align 32
  %1168 = select <8 x i1> %1100, <8 x float> %1157, <8 x float> %1167
  store <8 x float> %1168, ptr %.slot107, align 32
  store <8 x i1> %1100, ptr %current.mask, align 1
  %1169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1100)
  br i1 %1169, label %schedule.45, label %scheduler.loop

schedule.47:                                      ; preds = %varying.coherent.false855, %scheduler.dispatch.route
  %1170 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token871 = load i32, ptr %current.token, align 4
  %convergence.token.present872 = icmp ne i32 %convergence.current.token871, 0
  br i1 %convergence.token.present872, label %convergence.cascade869, label %convergence.cascade.exit870

schedule.48:                                      ; preds = %schedule.49, %convergence.target.47.ready, %scheduler.dispatch.route
  %1171 = load <8 x i1>, ptr %current.mask, align 1
  %1172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1171)
  %1173 = bitcast <8 x i1> %1171 to i8
  %1174 = call i8 @llvm.cttz.i8(i8 %1173, i1 false)
  %1175 = zext i8 %1174 to i32
  %1176 = select i1 %1172, i32 %1175, i32 0
  %.state886 = load <8 x i64>, ptr %.slot56, align 64
  %1177 = icmp slt <8 x i64> %.state886, splat (i64 40)
  %1178 = and <8 x i1> %1171, %1177
  %1179 = xor <8 x i1> %1177, splat (i1 true)
  %1180 = and <8 x i1> %1171, %1179
  %1181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1178)
  %1182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1180)
  %1183 = and i1 %1181, %1182
  br i1 %1183, label %varying.divergent887, label %varying.coherent888

schedule.49:                                      ; preds = %varying.coherent.true893, %scheduler.dispatch.route
  %1184 = load <8 x i1>, ptr %current.mask, align 1
  %1185 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1184)
  %1186 = bitcast <8 x i1> %1184 to i8
  %1187 = call i8 @llvm.cttz.i8(i8 %1186, i1 false)
  %1188 = zext i8 %1187 to i32
  %1189 = select i1 %1185, i32 %1188, i32 0
  %.state895 = load <8 x i64>, ptr %.slot56, align 64
  %1190 = add <8 x i64> splat (i64 80), %.state895
  %tile_snapshot.spill.load896 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load896, 0
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load896, 1
  %1193 = mul <8 x i64> %1190, splat (i64 32)
  %1194 = add <8 x i64> %1192, %1193
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1191, 0
  %1196 = insertvalue { <8 x ptr>, <8 x i64> } %1195, <8 x i64> %1194, 1
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 1
  %1199 = getelementptr i8, <8 x ptr> %1197, <8 x i64> %1198
  %1200 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1199, <8 x i1> %1184, <8 x float> zeroinitializer)
  %.state897 = load <8 x i64>, ptr %.slot56, align 64
  %1201 = add <8 x i64> splat (i64 120), %.state897
  %tile_snapshot.spill.load898 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load898, 0
  %1203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load898, 1
  %1204 = mul <8 x i64> %1201, splat (i64 32)
  %1205 = add <8 x i64> %1203, %1204
  %1206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1202, 0
  %1207 = insertvalue { <8 x ptr>, <8 x i64> } %1206, <8 x i64> %1205, 1
  %1208 = extractvalue { <8 x ptr>, <8 x i64> } %1207, 0
  %1209 = extractvalue { <8 x ptr>, <8 x i64> } %1207, 1
  %1210 = getelementptr i8, <8 x ptr> %1208, <8 x i64> %1209
  %1211 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1210, <8 x i1> %1184, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load899 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1212 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load899, 0
  %1213 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load899, 1
  %1214 = mul <8 x i64> %1190, splat (i64 32)
  %1215 = add <8 x i64> %1213, %1214
  %1216 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1212, 0
  %1217 = insertvalue { <8 x ptr>, <8 x i64> } %1216, <8 x i64> %1215, 1
  %1218 = extractvalue { <8 x ptr>, <8 x i64> } %1217, 0
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %1217, 1
  %1220 = getelementptr i8, <8 x ptr> %1218, <8 x i64> %1219
  %1221 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1220, <8 x i1> %1184, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load900 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load900, 0
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load900, 1
  %1224 = mul <8 x i64> %1201, splat (i64 32)
  %1225 = add <8 x i64> %1223, %1224
  %1226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1222, 0
  %1227 = insertvalue { <8 x ptr>, <8 x i64> } %1226, <8 x i64> %1225, 1
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %1227, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %1227, 1
  %1230 = getelementptr i8, <8 x ptr> %1228, <8 x i64> %1229
  %1231 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1230, <8 x i1> %1184, <8 x float> zeroinitializer)
  %1232 = fmul <8 x float> %1200, %1221
  %.state901 = load <8 x float>, ptr %.slot109, align 32
  %1233 = fadd <8 x float> %.state901, %1232
  %1234 = fmul <8 x float> %1200, %1231
  %.state902 = load <8 x float>, ptr %.slot110, align 32
  %1235 = fadd <8 x float> %.state902, %1234
  %1236 = fmul <8 x float> %1211, %1221
  %.state903 = load <8 x float>, ptr %.slot111, align 32
  %1237 = fadd <8 x float> %.state903, %1236
  %1238 = fmul <8 x float> %1211, %1231
  %.state904 = load <8 x float>, ptr %.slot112, align 32
  %1239 = fadd <8 x float> %.state904, %1238
  %.state905 = load <8 x i64>, ptr %.slot56, align 64
  %1240 = add <8 x i64> %.state905, splat (i64 1)
  %1241 = load <8 x i64>, ptr %.slot56, align 64
  %1242 = select <8 x i1> %1184, <8 x i64> %1240, <8 x i64> %1241
  store <8 x i64> %1242, ptr %.slot56, align 64
  %1243 = load <8 x float>, ptr %.slot109, align 32
  %1244 = select <8 x i1> %1184, <8 x float> %1233, <8 x float> %1243
  store <8 x float> %1244, ptr %.slot109, align 32
  %1245 = load <8 x float>, ptr %.slot110, align 32
  %1246 = select <8 x i1> %1184, <8 x float> %1235, <8 x float> %1245
  store <8 x float> %1246, ptr %.slot110, align 32
  %1247 = load <8 x float>, ptr %.slot111, align 32
  %1248 = select <8 x i1> %1184, <8 x float> %1237, <8 x float> %1247
  store <8 x float> %1248, ptr %.slot111, align 32
  %1249 = load <8 x float>, ptr %.slot112, align 32
  %1250 = select <8 x i1> %1184, <8 x float> %1239, <8 x float> %1249
  store <8 x float> %1250, ptr %.slot112, align 32
  store <8 x i1> %1184, ptr %current.mask, align 1
  %1251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1184)
  br i1 %1251, label %schedule.48, label %scheduler.loop

schedule.50:                                      ; preds = %varying.coherent.false894, %scheduler.dispatch.route
  %1252 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token908 = load i32, ptr %current.token, align 4
  %convergence.token.present909 = icmp ne i32 %convergence.current.token908, 0
  br i1 %convergence.token.present909, label %convergence.cascade906, label %convergence.cascade.exit907

schedule.51:                                      ; preds = %schedule.52, %convergence.target.50.ready, %scheduler.dispatch.route
  %1253 = load <8 x i1>, ptr %current.mask, align 1
  %1254 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1253)
  %1255 = bitcast <8 x i1> %1253 to i8
  %1256 = call i8 @llvm.cttz.i8(i8 %1255, i1 false)
  %1257 = zext i8 %1256 to i32
  %1258 = select i1 %1254, i32 %1257, i32 0
  %.state923 = load <8 x i64>, ptr %.slot56, align 64
  %1259 = icmp slt <8 x i64> %.state923, splat (i64 40)
  %1260 = and <8 x i1> %1253, %1259
  %1261 = xor <8 x i1> %1259, splat (i1 true)
  %1262 = and <8 x i1> %1253, %1261
  %1263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1260)
  %1264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1262)
  %1265 = and i1 %1263, %1264
  br i1 %1265, label %varying.divergent924, label %varying.coherent925

schedule.52:                                      ; preds = %varying.coherent.true930, %scheduler.dispatch.route
  %1266 = load <8 x i1>, ptr %current.mask, align 1
  %1267 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1266)
  %1268 = bitcast <8 x i1> %1266 to i8
  %1269 = call i8 @llvm.cttz.i8(i8 %1268, i1 false)
  %1270 = zext i8 %1269 to i32
  %1271 = select i1 %1267, i32 %1270, i32 0
  %.state932 = load <8 x i64>, ptr %.slot56, align 64
  %1272 = add <8 x i64> splat (i64 80), %.state932
  %tile_snapshot.spill.load933 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load933, 0
  %1274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load933, 1
  %1275 = mul <8 x i64> %1272, splat (i64 32)
  %1276 = add <8 x i64> %1274, %1275
  %1277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1273, 0
  %1278 = insertvalue { <8 x ptr>, <8 x i64> } %1277, <8 x i64> %1276, 1
  %1279 = extractvalue { <8 x ptr>, <8 x i64> } %1278, 0
  %1280 = extractvalue { <8 x ptr>, <8 x i64> } %1278, 1
  %1281 = getelementptr i8, <8 x ptr> %1279, <8 x i64> %1280
  %1282 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1281, <8 x i1> %1266, <8 x float> zeroinitializer)
  %.state934 = load <8 x i64>, ptr %.slot56, align 64
  %1283 = add <8 x i64> splat (i64 120), %.state934
  %tile_snapshot.spill.load935 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load935, 0
  %1285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load935, 1
  %1286 = mul <8 x i64> %1283, splat (i64 32)
  %1287 = add <8 x i64> %1285, %1286
  %1288 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1284, 0
  %1289 = insertvalue { <8 x ptr>, <8 x i64> } %1288, <8 x i64> %1287, 1
  %1290 = extractvalue { <8 x ptr>, <8 x i64> } %1289, 0
  %1291 = extractvalue { <8 x ptr>, <8 x i64> } %1289, 1
  %1292 = getelementptr i8, <8 x ptr> %1290, <8 x i64> %1291
  %1293 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1292, <8 x i1> %1266, <8 x float> zeroinitializer)
  %.state936 = load <8 x i64>, ptr %.slot56, align 64
  %1294 = add <8 x i64> splat (i64 160), %.state936
  %tile_snapshot.spill.load937 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load937, 0
  %1296 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load937, 1
  %1297 = mul <8 x i64> %1294, splat (i64 32)
  %1298 = add <8 x i64> %1296, %1297
  %1299 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1295, 0
  %1300 = insertvalue { <8 x ptr>, <8 x i64> } %1299, <8 x i64> %1298, 1
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %1300, 0
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %1300, 1
  %1303 = getelementptr i8, <8 x ptr> %1301, <8 x i64> %1302
  %1304 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1303, <8 x i1> %1266, <8 x float> zeroinitializer)
  %.state938 = load <8 x i64>, ptr %.slot56, align 64
  %1305 = add <8 x i64> splat (i64 200), %.state938
  %tile_snapshot.spill.load939 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load939, 0
  %1307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load939, 1
  %1308 = mul <8 x i64> %1305, splat (i64 32)
  %1309 = add <8 x i64> %1307, %1308
  %1310 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1306, 0
  %1311 = insertvalue { <8 x ptr>, <8 x i64> } %1310, <8 x i64> %1309, 1
  %1312 = extractvalue { <8 x ptr>, <8 x i64> } %1311, 0
  %1313 = extractvalue { <8 x ptr>, <8 x i64> } %1311, 1
  %1314 = getelementptr i8, <8 x ptr> %1312, <8 x i64> %1313
  %1315 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1314, <8 x i1> %1266, <8 x float> zeroinitializer)
  %1316 = fmul <8 x float> %1282, %1304
  %.state940 = load <8 x float>, ptr %.slot114, align 32
  %1317 = fadd <8 x float> %.state940, %1316
  %1318 = fmul <8 x float> %1282, %1315
  %.state941 = load <8 x float>, ptr %.slot115, align 32
  %1319 = fadd <8 x float> %.state941, %1318
  %1320 = fmul <8 x float> %1293, %1304
  %.state942 = load <8 x float>, ptr %.slot116, align 32
  %1321 = fadd <8 x float> %.state942, %1320
  %1322 = fmul <8 x float> %1293, %1315
  %.state943 = load <8 x float>, ptr %.slot117, align 32
  %1323 = fadd <8 x float> %.state943, %1322
  %.state944 = load <8 x i64>, ptr %.slot56, align 64
  %1324 = add <8 x i64> %.state944, splat (i64 1)
  %1325 = load <8 x i64>, ptr %.slot56, align 64
  %1326 = select <8 x i1> %1266, <8 x i64> %1324, <8 x i64> %1325
  store <8 x i64> %1326, ptr %.slot56, align 64
  %1327 = load <8 x float>, ptr %.slot114, align 32
  %1328 = select <8 x i1> %1266, <8 x float> %1317, <8 x float> %1327
  store <8 x float> %1328, ptr %.slot114, align 32
  %1329 = load <8 x float>, ptr %.slot115, align 32
  %1330 = select <8 x i1> %1266, <8 x float> %1319, <8 x float> %1329
  store <8 x float> %1330, ptr %.slot115, align 32
  %1331 = load <8 x float>, ptr %.slot116, align 32
  %1332 = select <8 x i1> %1266, <8 x float> %1321, <8 x float> %1331
  store <8 x float> %1332, ptr %.slot116, align 32
  %1333 = load <8 x float>, ptr %.slot117, align 32
  %1334 = select <8 x i1> %1266, <8 x float> %1323, <8 x float> %1333
  store <8 x float> %1334, ptr %.slot117, align 32
  store <8 x i1> %1266, ptr %current.mask, align 1
  %1335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1266)
  br i1 %1335, label %schedule.51, label %scheduler.loop

schedule.53:                                      ; preds = %varying.coherent.false931, %scheduler.dispatch.route
  %1336 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token947 = load i32, ptr %current.token, align 4
  %convergence.token.present948 = icmp ne i32 %convergence.current.token947, 0
  br i1 %convergence.token.present948, label %convergence.cascade945, label %convergence.cascade.exit946

schedule.54:                                      ; preds = %schedule.55, %convergence.target.53.ready, %scheduler.dispatch.route
  %1337 = load <8 x i1>, ptr %current.mask, align 1
  %1338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1337)
  %1339 = bitcast <8 x i1> %1337 to i8
  %1340 = call i8 @llvm.cttz.i8(i8 %1339, i1 false)
  %1341 = zext i8 %1340 to i32
  %1342 = select i1 %1338, i32 %1341, i32 0
  %.state962 = load <8 x i64>, ptr %.slot56, align 64
  %1343 = icmp slt <8 x i64> %.state962, splat (i64 40)
  %1344 = and <8 x i1> %1337, %1343
  %1345 = xor <8 x i1> %1343, splat (i1 true)
  %1346 = and <8 x i1> %1337, %1345
  %1347 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1344)
  %1348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1346)
  %1349 = and i1 %1347, %1348
  br i1 %1349, label %varying.divergent963, label %varying.coherent964

schedule.55:                                      ; preds = %varying.coherent.true969, %scheduler.dispatch.route
  %1350 = load <8 x i1>, ptr %current.mask, align 1
  %1351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1350)
  %1352 = bitcast <8 x i1> %1350 to i8
  %1353 = call i8 @llvm.cttz.i8(i8 %1352, i1 false)
  %1354 = zext i8 %1353 to i32
  %1355 = select i1 %1351, i32 %1354, i32 0
  %.state971 = load <8 x i64>, ptr %.slot56, align 64
  %1356 = add <8 x i64> splat (i64 80), %.state971
  %tile_snapshot.spill.load972 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load972, 0
  %1358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load972, 1
  %1359 = mul <8 x i64> %1356, splat (i64 32)
  %1360 = add <8 x i64> %1358, %1359
  %1361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1357, 0
  %1362 = insertvalue { <8 x ptr>, <8 x i64> } %1361, <8 x i64> %1360, 1
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %1362, 0
  %1364 = extractvalue { <8 x ptr>, <8 x i64> } %1362, 1
  %1365 = getelementptr i8, <8 x ptr> %1363, <8 x i64> %1364
  %1366 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1365, <8 x i1> %1350, <8 x float> zeroinitializer)
  %.state973 = load <8 x i64>, ptr %.slot56, align 64
  %1367 = add <8 x i64> splat (i64 120), %.state973
  %tile_snapshot.spill.load974 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load974, 0
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load974, 1
  %1370 = mul <8 x i64> %1367, splat (i64 32)
  %1371 = add <8 x i64> %1369, %1370
  %1372 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1368, 0
  %1373 = insertvalue { <8 x ptr>, <8 x i64> } %1372, <8 x i64> %1371, 1
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %1373, 0
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %1373, 1
  %1376 = getelementptr i8, <8 x ptr> %1374, <8 x i64> %1375
  %1377 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1376, <8 x i1> %1350, <8 x float> zeroinitializer)
  %.state975 = load <8 x i64>, ptr %.slot56, align 64
  %1378 = add <8 x i64> splat (i64 240), %.state975
  %tile_snapshot.spill.load976 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1379 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load976, 0
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load976, 1
  %1381 = mul <8 x i64> %1378, splat (i64 32)
  %1382 = add <8 x i64> %1380, %1381
  %1383 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1379, 0
  %1384 = insertvalue { <8 x ptr>, <8 x i64> } %1383, <8 x i64> %1382, 1
  %1385 = extractvalue { <8 x ptr>, <8 x i64> } %1384, 0
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %1384, 1
  %1387 = getelementptr i8, <8 x ptr> %1385, <8 x i64> %1386
  %1388 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1387, <8 x i1> %1350, <8 x float> zeroinitializer)
  %.state977 = load <8 x i64>, ptr %.slot56, align 64
  %1389 = add <8 x i64> splat (i64 280), %.state977
  %tile_snapshot.spill.load978 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load978, 0
  %1391 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load978, 1
  %1392 = mul <8 x i64> %1389, splat (i64 32)
  %1393 = add <8 x i64> %1391, %1392
  %1394 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1390, 0
  %1395 = insertvalue { <8 x ptr>, <8 x i64> } %1394, <8 x i64> %1393, 1
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %1395, 0
  %1397 = extractvalue { <8 x ptr>, <8 x i64> } %1395, 1
  %1398 = getelementptr i8, <8 x ptr> %1396, <8 x i64> %1397
  %1399 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1398, <8 x i1> %1350, <8 x float> zeroinitializer)
  %1400 = fmul <8 x float> %1366, %1388
  %.state979 = load <8 x float>, ptr %.slot119, align 32
  %1401 = fadd <8 x float> %.state979, %1400
  %1402 = fmul <8 x float> %1366, %1399
  %.state980 = load <8 x float>, ptr %.slot120, align 32
  %1403 = fadd <8 x float> %.state980, %1402
  %1404 = fmul <8 x float> %1377, %1388
  %.state981 = load <8 x float>, ptr %.slot121, align 32
  %1405 = fadd <8 x float> %.state981, %1404
  %1406 = fmul <8 x float> %1377, %1399
  %.state982 = load <8 x float>, ptr %.slot122, align 32
  %1407 = fadd <8 x float> %.state982, %1406
  %.state983 = load <8 x i64>, ptr %.slot56, align 64
  %1408 = add <8 x i64> %.state983, splat (i64 1)
  %1409 = load <8 x i64>, ptr %.slot56, align 64
  %1410 = select <8 x i1> %1350, <8 x i64> %1408, <8 x i64> %1409
  store <8 x i64> %1410, ptr %.slot56, align 64
  %1411 = load <8 x float>, ptr %.slot119, align 32
  %1412 = select <8 x i1> %1350, <8 x float> %1401, <8 x float> %1411
  store <8 x float> %1412, ptr %.slot119, align 32
  %1413 = load <8 x float>, ptr %.slot120, align 32
  %1414 = select <8 x i1> %1350, <8 x float> %1403, <8 x float> %1413
  store <8 x float> %1414, ptr %.slot120, align 32
  %1415 = load <8 x float>, ptr %.slot121, align 32
  %1416 = select <8 x i1> %1350, <8 x float> %1405, <8 x float> %1415
  store <8 x float> %1416, ptr %.slot121, align 32
  %1417 = load <8 x float>, ptr %.slot122, align 32
  %1418 = select <8 x i1> %1350, <8 x float> %1407, <8 x float> %1417
  store <8 x float> %1418, ptr %.slot122, align 32
  store <8 x i1> %1350, ptr %current.mask, align 1
  %1419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1350)
  br i1 %1419, label %schedule.54, label %scheduler.loop

schedule.56:                                      ; preds = %varying.coherent.false970, %scheduler.dispatch.route
  %1420 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token986 = load i32, ptr %current.token, align 4
  %convergence.token.present987 = icmp ne i32 %convergence.current.token986, 0
  br i1 %convergence.token.present987, label %convergence.cascade984, label %convergence.cascade.exit985

schedule.57:                                      ; preds = %schedule.58, %convergence.target.56.ready, %scheduler.dispatch.route
  %1421 = load <8 x i1>, ptr %current.mask, align 1
  %1422 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1421)
  %1423 = bitcast <8 x i1> %1421 to i8
  %1424 = call i8 @llvm.cttz.i8(i8 %1423, i1 false)
  %1425 = zext i8 %1424 to i32
  %1426 = select i1 %1422, i32 %1425, i32 0
  %.state1001 = load <8 x i64>, ptr %.slot56, align 64
  %1427 = icmp slt <8 x i64> %.state1001, splat (i64 40)
  %1428 = and <8 x i1> %1421, %1427
  %1429 = xor <8 x i1> %1427, splat (i1 true)
  %1430 = and <8 x i1> %1421, %1429
  %1431 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1428)
  %1432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1430)
  %1433 = and i1 %1431, %1432
  br i1 %1433, label %varying.divergent1002, label %varying.coherent1003

schedule.58:                                      ; preds = %varying.coherent.true1008, %scheduler.dispatch.route
  %1434 = load <8 x i1>, ptr %current.mask, align 1
  %1435 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1434)
  %1436 = bitcast <8 x i1> %1434 to i8
  %1437 = call i8 @llvm.cttz.i8(i8 %1436, i1 false)
  %1438 = zext i8 %1437 to i32
  %1439 = select i1 %1435, i32 %1438, i32 0
  %.state1010 = load <8 x i64>, ptr %.slot56, align 64
  %1440 = add <8 x i64> splat (i64 80), %.state1010
  %tile_snapshot.spill.load1011 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1011, 0
  %1442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1011, 1
  %1443 = mul <8 x i64> %1440, splat (i64 32)
  %1444 = add <8 x i64> %1442, %1443
  %1445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1441, 0
  %1446 = insertvalue { <8 x ptr>, <8 x i64> } %1445, <8 x i64> %1444, 1
  %1447 = extractvalue { <8 x ptr>, <8 x i64> } %1446, 0
  %1448 = extractvalue { <8 x ptr>, <8 x i64> } %1446, 1
  %1449 = getelementptr i8, <8 x ptr> %1447, <8 x i64> %1448
  %1450 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1449, <8 x i1> %1434, <8 x float> zeroinitializer)
  %.state1012 = load <8 x i64>, ptr %.slot56, align 64
  %1451 = add <8 x i64> splat (i64 120), %.state1012
  %tile_snapshot.spill.load1013 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1013, 0
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1013, 1
  %1454 = mul <8 x i64> %1451, splat (i64 32)
  %1455 = add <8 x i64> %1453, %1454
  %1456 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1452, 0
  %1457 = insertvalue { <8 x ptr>, <8 x i64> } %1456, <8 x i64> %1455, 1
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 0
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 1
  %1460 = getelementptr i8, <8 x ptr> %1458, <8 x i64> %1459
  %1461 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1460, <8 x i1> %1434, <8 x float> zeroinitializer)
  %.state1014 = load <8 x i64>, ptr %.slot56, align 64
  %1462 = add <8 x i64> splat (i64 320), %.state1014
  %tile_snapshot.spill.load1015 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1463 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1015, 0
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1015, 1
  %1465 = mul <8 x i64> %1462, splat (i64 32)
  %1466 = add <8 x i64> %1464, %1465
  %1467 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1463, 0
  %1468 = insertvalue { <8 x ptr>, <8 x i64> } %1467, <8 x i64> %1466, 1
  %1469 = extractvalue { <8 x ptr>, <8 x i64> } %1468, 0
  %1470 = extractvalue { <8 x ptr>, <8 x i64> } %1468, 1
  %1471 = getelementptr i8, <8 x ptr> %1469, <8 x i64> %1470
  %1472 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1471, <8 x i1> %1434, <8 x float> zeroinitializer)
  %.state1016 = load <8 x i64>, ptr %.slot56, align 64
  %1473 = add <8 x i64> splat (i64 360), %.state1016
  %tile_snapshot.spill.load1017 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1017, 0
  %1475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1017, 1
  %1476 = mul <8 x i64> %1473, splat (i64 32)
  %1477 = add <8 x i64> %1475, %1476
  %1478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1474, 0
  %1479 = insertvalue { <8 x ptr>, <8 x i64> } %1478, <8 x i64> %1477, 1
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %1479, 0
  %1481 = extractvalue { <8 x ptr>, <8 x i64> } %1479, 1
  %1482 = getelementptr i8, <8 x ptr> %1480, <8 x i64> %1481
  %1483 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1482, <8 x i1> %1434, <8 x float> zeroinitializer)
  %1484 = fmul <8 x float> %1450, %1472
  %.state1018 = load <8 x float>, ptr %.slot124, align 32
  %1485 = fadd <8 x float> %.state1018, %1484
  %1486 = fmul <8 x float> %1450, %1483
  %.state1019 = load <8 x float>, ptr %.slot125, align 32
  %1487 = fadd <8 x float> %.state1019, %1486
  %1488 = fmul <8 x float> %1461, %1472
  %.state1020 = load <8 x float>, ptr %.slot126, align 32
  %1489 = fadd <8 x float> %.state1020, %1488
  %1490 = fmul <8 x float> %1461, %1483
  %.state1021 = load <8 x float>, ptr %.slot127, align 32
  %1491 = fadd <8 x float> %.state1021, %1490
  %.state1022 = load <8 x i64>, ptr %.slot56, align 64
  %1492 = add <8 x i64> %.state1022, splat (i64 1)
  %1493 = load <8 x i64>, ptr %.slot56, align 64
  %1494 = select <8 x i1> %1434, <8 x i64> %1492, <8 x i64> %1493
  store <8 x i64> %1494, ptr %.slot56, align 64
  %1495 = load <8 x float>, ptr %.slot124, align 32
  %1496 = select <8 x i1> %1434, <8 x float> %1485, <8 x float> %1495
  store <8 x float> %1496, ptr %.slot124, align 32
  %1497 = load <8 x float>, ptr %.slot125, align 32
  %1498 = select <8 x i1> %1434, <8 x float> %1487, <8 x float> %1497
  store <8 x float> %1498, ptr %.slot125, align 32
  %1499 = load <8 x float>, ptr %.slot126, align 32
  %1500 = select <8 x i1> %1434, <8 x float> %1489, <8 x float> %1499
  store <8 x float> %1500, ptr %.slot126, align 32
  %1501 = load <8 x float>, ptr %.slot127, align 32
  %1502 = select <8 x i1> %1434, <8 x float> %1491, <8 x float> %1501
  store <8 x float> %1502, ptr %.slot127, align 32
  store <8 x i1> %1434, ptr %current.mask, align 1
  %1503 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1434)
  br i1 %1503, label %schedule.57, label %scheduler.loop

schedule.59:                                      ; preds = %varying.coherent.false1009, %scheduler.dispatch.route
  %1504 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1025 = load i32, ptr %current.token, align 4
  %convergence.token.present1026 = icmp ne i32 %convergence.current.token1025, 0
  br i1 %convergence.token.present1026, label %convergence.cascade1023, label %convergence.cascade.exit1024

schedule.60:                                      ; preds = %schedule.61, %convergence.target.59.ready, %scheduler.dispatch.route
  %1505 = load <8 x i1>, ptr %current.mask, align 1
  %1506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1505)
  %1507 = bitcast <8 x i1> %1505 to i8
  %1508 = call i8 @llvm.cttz.i8(i8 %1507, i1 false)
  %1509 = zext i8 %1508 to i32
  %1510 = select i1 %1506, i32 %1509, i32 0
  %.state1040 = load <8 x i64>, ptr %.slot56, align 64
  %1511 = icmp slt <8 x i64> %.state1040, splat (i64 40)
  %1512 = and <8 x i1> %1505, %1511
  %1513 = xor <8 x i1> %1511, splat (i1 true)
  %1514 = and <8 x i1> %1505, %1513
  %1515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1512)
  %1516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1514)
  %1517 = and i1 %1515, %1516
  br i1 %1517, label %varying.divergent1041, label %varying.coherent1042

schedule.61:                                      ; preds = %varying.coherent.true1047, %scheduler.dispatch.route
  %1518 = load <8 x i1>, ptr %current.mask, align 1
  %1519 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1518)
  %1520 = bitcast <8 x i1> %1518 to i8
  %1521 = call i8 @llvm.cttz.i8(i8 %1520, i1 false)
  %1522 = zext i8 %1521 to i32
  %1523 = select i1 %1519, i32 %1522, i32 0
  %.state1049 = load <8 x i64>, ptr %.slot56, align 64
  %1524 = add <8 x i64> splat (i64 80), %.state1049
  %tile_snapshot.spill.load1050 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1525 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1050, 0
  %1526 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1050, 1
  %1527 = mul <8 x i64> %1524, splat (i64 32)
  %1528 = add <8 x i64> %1526, %1527
  %1529 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1525, 0
  %1530 = insertvalue { <8 x ptr>, <8 x i64> } %1529, <8 x i64> %1528, 1
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %1530, 0
  %1532 = extractvalue { <8 x ptr>, <8 x i64> } %1530, 1
  %1533 = getelementptr i8, <8 x ptr> %1531, <8 x i64> %1532
  %1534 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1533, <8 x i1> %1518, <8 x float> zeroinitializer)
  %.state1051 = load <8 x i64>, ptr %.slot56, align 64
  %1535 = add <8 x i64> splat (i64 120), %.state1051
  %tile_snapshot.spill.load1052 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1052, 0
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1052, 1
  %1538 = mul <8 x i64> %1535, splat (i64 32)
  %1539 = add <8 x i64> %1537, %1538
  %1540 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1536, 0
  %1541 = insertvalue { <8 x ptr>, <8 x i64> } %1540, <8 x i64> %1539, 1
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %1541, 0
  %1543 = extractvalue { <8 x ptr>, <8 x i64> } %1541, 1
  %1544 = getelementptr i8, <8 x ptr> %1542, <8 x i64> %1543
  %1545 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1544, <8 x i1> %1518, <8 x float> zeroinitializer)
  %.state1053 = load <8 x i64>, ptr %.slot56, align 64
  %1546 = add <8 x i64> splat (i64 400), %.state1053
  %tile_snapshot.spill.load1054 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1054, 0
  %1548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1054, 1
  %1549 = mul <8 x i64> %1546, splat (i64 32)
  %1550 = add <8 x i64> %1548, %1549
  %1551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1547, 0
  %1552 = insertvalue { <8 x ptr>, <8 x i64> } %1551, <8 x i64> %1550, 1
  %1553 = extractvalue { <8 x ptr>, <8 x i64> } %1552, 0
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %1552, 1
  %1555 = getelementptr i8, <8 x ptr> %1553, <8 x i64> %1554
  %1556 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1555, <8 x i1> %1518, <8 x float> zeroinitializer)
  %.state1055 = load <8 x i64>, ptr %.slot56, align 64
  %1557 = add <8 x i64> splat (i64 440), %.state1055
  %tile_snapshot.spill.load1056 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1558 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1056, 0
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1056, 1
  %1560 = mul <8 x i64> %1557, splat (i64 32)
  %1561 = add <8 x i64> %1559, %1560
  %1562 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1558, 0
  %1563 = insertvalue { <8 x ptr>, <8 x i64> } %1562, <8 x i64> %1561, 1
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %1563, 0
  %1565 = extractvalue { <8 x ptr>, <8 x i64> } %1563, 1
  %1566 = getelementptr i8, <8 x ptr> %1564, <8 x i64> %1565
  %1567 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1566, <8 x i1> %1518, <8 x float> zeroinitializer)
  %1568 = fmul <8 x float> %1534, %1556
  %.state1057 = load <8 x float>, ptr %.slot129, align 32
  %1569 = fadd <8 x float> %.state1057, %1568
  %1570 = fmul <8 x float> %1534, %1567
  %.state1058 = load <8 x float>, ptr %.slot130, align 32
  %1571 = fadd <8 x float> %.state1058, %1570
  %1572 = fmul <8 x float> %1545, %1556
  %.state1059 = load <8 x float>, ptr %.slot131, align 32
  %1573 = fadd <8 x float> %.state1059, %1572
  %1574 = fmul <8 x float> %1545, %1567
  %.state1060 = load <8 x float>, ptr %.slot132, align 32
  %1575 = fadd <8 x float> %.state1060, %1574
  %.state1061 = load <8 x i64>, ptr %.slot56, align 64
  %1576 = add <8 x i64> %.state1061, splat (i64 1)
  %1577 = load <8 x i64>, ptr %.slot56, align 64
  %1578 = select <8 x i1> %1518, <8 x i64> %1576, <8 x i64> %1577
  store <8 x i64> %1578, ptr %.slot56, align 64
  %1579 = load <8 x float>, ptr %.slot129, align 32
  %1580 = select <8 x i1> %1518, <8 x float> %1569, <8 x float> %1579
  store <8 x float> %1580, ptr %.slot129, align 32
  %1581 = load <8 x float>, ptr %.slot130, align 32
  %1582 = select <8 x i1> %1518, <8 x float> %1571, <8 x float> %1581
  store <8 x float> %1582, ptr %.slot130, align 32
  %1583 = load <8 x float>, ptr %.slot131, align 32
  %1584 = select <8 x i1> %1518, <8 x float> %1573, <8 x float> %1583
  store <8 x float> %1584, ptr %.slot131, align 32
  %1585 = load <8 x float>, ptr %.slot132, align 32
  %1586 = select <8 x i1> %1518, <8 x float> %1575, <8 x float> %1585
  store <8 x float> %1586, ptr %.slot132, align 32
  store <8 x i1> %1518, ptr %current.mask, align 1
  %1587 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1518)
  br i1 %1587, label %schedule.60, label %scheduler.loop

schedule.62:                                      ; preds = %varying.coherent.false1048, %scheduler.dispatch.route
  %1588 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1064 = load i32, ptr %current.token, align 4
  %convergence.token.present1065 = icmp ne i32 %convergence.current.token1064, 0
  br i1 %convergence.token.present1065, label %convergence.cascade1062, label %convergence.cascade.exit1063

schedule.63:                                      ; preds = %schedule.64, %convergence.target.62.ready, %scheduler.dispatch.route
  %1589 = load <8 x i1>, ptr %current.mask, align 1
  %1590 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1589)
  %1591 = bitcast <8 x i1> %1589 to i8
  %1592 = call i8 @llvm.cttz.i8(i8 %1591, i1 false)
  %1593 = zext i8 %1592 to i32
  %1594 = select i1 %1590, i32 %1593, i32 0
  %.state1079 = load <8 x i64>, ptr %.slot56, align 64
  %1595 = icmp slt <8 x i64> %.state1079, splat (i64 40)
  %1596 = and <8 x i1> %1589, %1595
  %1597 = xor <8 x i1> %1595, splat (i1 true)
  %1598 = and <8 x i1> %1589, %1597
  %1599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1596)
  %1600 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1598)
  %1601 = and i1 %1599, %1600
  br i1 %1601, label %varying.divergent1080, label %varying.coherent1081

schedule.64:                                      ; preds = %varying.coherent.true1086, %scheduler.dispatch.route
  %1602 = load <8 x i1>, ptr %current.mask, align 1
  %1603 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1602)
  %1604 = bitcast <8 x i1> %1602 to i8
  %1605 = call i8 @llvm.cttz.i8(i8 %1604, i1 false)
  %1606 = zext i8 %1605 to i32
  %1607 = select i1 %1603, i32 %1606, i32 0
  %.state1088 = load <8 x i64>, ptr %.slot56, align 64
  %1608 = add <8 x i64> splat (i64 80), %.state1088
  %tile_snapshot.spill.load1089 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1089, 0
  %1610 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1089, 1
  %1611 = mul <8 x i64> %1608, splat (i64 32)
  %1612 = add <8 x i64> %1610, %1611
  %1613 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1609, 0
  %1614 = insertvalue { <8 x ptr>, <8 x i64> } %1613, <8 x i64> %1612, 1
  %1615 = extractvalue { <8 x ptr>, <8 x i64> } %1614, 0
  %1616 = extractvalue { <8 x ptr>, <8 x i64> } %1614, 1
  %1617 = getelementptr i8, <8 x ptr> %1615, <8 x i64> %1616
  %1618 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1617, <8 x i1> %1602, <8 x float> zeroinitializer)
  %.state1090 = load <8 x i64>, ptr %.slot56, align 64
  %1619 = add <8 x i64> splat (i64 120), %.state1090
  %tile_snapshot.spill.load1091 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1620 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1091, 0
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1091, 1
  %1622 = mul <8 x i64> %1619, splat (i64 32)
  %1623 = add <8 x i64> %1621, %1622
  %1624 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1620, 0
  %1625 = insertvalue { <8 x ptr>, <8 x i64> } %1624, <8 x i64> %1623, 1
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %1625, 0
  %1627 = extractvalue { <8 x ptr>, <8 x i64> } %1625, 1
  %1628 = getelementptr i8, <8 x ptr> %1626, <8 x i64> %1627
  %1629 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1628, <8 x i1> %1602, <8 x float> zeroinitializer)
  %.state1092 = load <8 x i64>, ptr %.slot56, align 64
  %1630 = add <8 x i64> splat (i64 480), %.state1092
  %tile_snapshot.spill.load1093 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1631 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1093, 0
  %1632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1093, 1
  %1633 = mul <8 x i64> %1630, splat (i64 32)
  %1634 = add <8 x i64> %1632, %1633
  %1635 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1631, 0
  %1636 = insertvalue { <8 x ptr>, <8 x i64> } %1635, <8 x i64> %1634, 1
  %1637 = extractvalue { <8 x ptr>, <8 x i64> } %1636, 0
  %1638 = extractvalue { <8 x ptr>, <8 x i64> } %1636, 1
  %1639 = getelementptr i8, <8 x ptr> %1637, <8 x i64> %1638
  %1640 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1639, <8 x i1> %1602, <8 x float> zeroinitializer)
  %.state1094 = load <8 x i64>, ptr %.slot56, align 64
  %1641 = add <8 x i64> splat (i64 520), %.state1094
  %tile_snapshot.spill.load1095 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1095, 0
  %1643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1095, 1
  %1644 = mul <8 x i64> %1641, splat (i64 32)
  %1645 = add <8 x i64> %1643, %1644
  %1646 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1642, 0
  %1647 = insertvalue { <8 x ptr>, <8 x i64> } %1646, <8 x i64> %1645, 1
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %1647, 0
  %1649 = extractvalue { <8 x ptr>, <8 x i64> } %1647, 1
  %1650 = getelementptr i8, <8 x ptr> %1648, <8 x i64> %1649
  %1651 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1650, <8 x i1> %1602, <8 x float> zeroinitializer)
  %1652 = fmul <8 x float> %1618, %1640
  %.state1096 = load <8 x float>, ptr %.slot134, align 32
  %1653 = fadd <8 x float> %.state1096, %1652
  %1654 = fmul <8 x float> %1618, %1651
  %.state1097 = load <8 x float>, ptr %.slot135, align 32
  %1655 = fadd <8 x float> %.state1097, %1654
  %1656 = fmul <8 x float> %1629, %1640
  %.state1098 = load <8 x float>, ptr %.slot136, align 32
  %1657 = fadd <8 x float> %.state1098, %1656
  %1658 = fmul <8 x float> %1629, %1651
  %.state1099 = load <8 x float>, ptr %.slot137, align 32
  %1659 = fadd <8 x float> %.state1099, %1658
  %.state1100 = load <8 x i64>, ptr %.slot56, align 64
  %1660 = add <8 x i64> %.state1100, splat (i64 1)
  %1661 = load <8 x i64>, ptr %.slot56, align 64
  %1662 = select <8 x i1> %1602, <8 x i64> %1660, <8 x i64> %1661
  store <8 x i64> %1662, ptr %.slot56, align 64
  %1663 = load <8 x float>, ptr %.slot134, align 32
  %1664 = select <8 x i1> %1602, <8 x float> %1653, <8 x float> %1663
  store <8 x float> %1664, ptr %.slot134, align 32
  %1665 = load <8 x float>, ptr %.slot135, align 32
  %1666 = select <8 x i1> %1602, <8 x float> %1655, <8 x float> %1665
  store <8 x float> %1666, ptr %.slot135, align 32
  %1667 = load <8 x float>, ptr %.slot136, align 32
  %1668 = select <8 x i1> %1602, <8 x float> %1657, <8 x float> %1667
  store <8 x float> %1668, ptr %.slot136, align 32
  %1669 = load <8 x float>, ptr %.slot137, align 32
  %1670 = select <8 x i1> %1602, <8 x float> %1659, <8 x float> %1669
  store <8 x float> %1670, ptr %.slot137, align 32
  store <8 x i1> %1602, ptr %current.mask, align 1
  %1671 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1602)
  br i1 %1671, label %schedule.63, label %scheduler.loop

schedule.65:                                      ; preds = %varying.coherent.false1087, %scheduler.dispatch.route
  %1672 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1103 = load i32, ptr %current.token, align 4
  %convergence.token.present1104 = icmp ne i32 %convergence.current.token1103, 0
  br i1 %convergence.token.present1104, label %convergence.cascade1101, label %convergence.cascade.exit1102

schedule.66:                                      ; preds = %schedule.67, %convergence.target.65.ready, %scheduler.dispatch.route
  %1673 = load <8 x i1>, ptr %current.mask, align 1
  %1674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1673)
  %1675 = bitcast <8 x i1> %1673 to i8
  %1676 = call i8 @llvm.cttz.i8(i8 %1675, i1 false)
  %1677 = zext i8 %1676 to i32
  %1678 = select i1 %1674, i32 %1677, i32 0
  %.state1118 = load <8 x i64>, ptr %.slot56, align 64
  %1679 = icmp slt <8 x i64> %.state1118, splat (i64 40)
  %1680 = and <8 x i1> %1673, %1679
  %1681 = xor <8 x i1> %1679, splat (i1 true)
  %1682 = and <8 x i1> %1673, %1681
  %1683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1680)
  %1684 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1682)
  %1685 = and i1 %1683, %1684
  br i1 %1685, label %varying.divergent1119, label %varying.coherent1120

schedule.67:                                      ; preds = %varying.coherent.true1125, %scheduler.dispatch.route
  %1686 = load <8 x i1>, ptr %current.mask, align 1
  %1687 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1686)
  %1688 = bitcast <8 x i1> %1686 to i8
  %1689 = call i8 @llvm.cttz.i8(i8 %1688, i1 false)
  %1690 = zext i8 %1689 to i32
  %1691 = select i1 %1687, i32 %1690, i32 0
  %.state1127 = load <8 x i64>, ptr %.slot56, align 64
  %1692 = add <8 x i64> splat (i64 80), %.state1127
  %tile_snapshot.spill.load1128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1128, 0
  %1694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1128, 1
  %1695 = mul <8 x i64> %1692, splat (i64 32)
  %1696 = add <8 x i64> %1694, %1695
  %1697 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1693, 0
  %1698 = insertvalue { <8 x ptr>, <8 x i64> } %1697, <8 x i64> %1696, 1
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %1698, 0
  %1700 = extractvalue { <8 x ptr>, <8 x i64> } %1698, 1
  %1701 = getelementptr i8, <8 x ptr> %1699, <8 x i64> %1700
  %1702 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1701, <8 x i1> %1686, <8 x float> zeroinitializer)
  %.state1129 = load <8 x i64>, ptr %.slot56, align 64
  %1703 = add <8 x i64> splat (i64 120), %.state1129
  %tile_snapshot.spill.load1130 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1704 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1130, 0
  %1705 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1130, 1
  %1706 = mul <8 x i64> %1703, splat (i64 32)
  %1707 = add <8 x i64> %1705, %1706
  %1708 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1704, 0
  %1709 = insertvalue { <8 x ptr>, <8 x i64> } %1708, <8 x i64> %1707, 1
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %1709, 0
  %1711 = extractvalue { <8 x ptr>, <8 x i64> } %1709, 1
  %1712 = getelementptr i8, <8 x ptr> %1710, <8 x i64> %1711
  %1713 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1712, <8 x i1> %1686, <8 x float> zeroinitializer)
  %.state1131 = load <8 x i64>, ptr %.slot56, align 64
  %1714 = add <8 x i64> splat (i64 560), %.state1131
  %tile_snapshot.spill.load1132 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1132, 0
  %1716 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1132, 1
  %1717 = mul <8 x i64> %1714, splat (i64 32)
  %1718 = add <8 x i64> %1716, %1717
  %1719 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1715, 0
  %1720 = insertvalue { <8 x ptr>, <8 x i64> } %1719, <8 x i64> %1718, 1
  %1721 = extractvalue { <8 x ptr>, <8 x i64> } %1720, 0
  %1722 = extractvalue { <8 x ptr>, <8 x i64> } %1720, 1
  %1723 = getelementptr i8, <8 x ptr> %1721, <8 x i64> %1722
  %1724 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1723, <8 x i1> %1686, <8 x float> zeroinitializer)
  %.state1133 = load <8 x i64>, ptr %.slot56, align 64
  %1725 = add <8 x i64> splat (i64 600), %.state1133
  %tile_snapshot.spill.load1134 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1134, 0
  %1727 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1134, 1
  %1728 = mul <8 x i64> %1725, splat (i64 32)
  %1729 = add <8 x i64> %1727, %1728
  %1730 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1726, 0
  %1731 = insertvalue { <8 x ptr>, <8 x i64> } %1730, <8 x i64> %1729, 1
  %1732 = extractvalue { <8 x ptr>, <8 x i64> } %1731, 0
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %1731, 1
  %1734 = getelementptr i8, <8 x ptr> %1732, <8 x i64> %1733
  %1735 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1734, <8 x i1> %1686, <8 x float> zeroinitializer)
  %1736 = fmul <8 x float> %1702, %1724
  %.state1135 = load <8 x float>, ptr %.slot139, align 32
  %1737 = fadd <8 x float> %.state1135, %1736
  %1738 = fmul <8 x float> %1702, %1735
  %.state1136 = load <8 x float>, ptr %.slot140, align 32
  %1739 = fadd <8 x float> %.state1136, %1738
  %1740 = fmul <8 x float> %1713, %1724
  %.state1137 = load <8 x float>, ptr %.slot141, align 32
  %1741 = fadd <8 x float> %.state1137, %1740
  %1742 = fmul <8 x float> %1713, %1735
  %.state1138 = load <8 x float>, ptr %.slot142, align 32
  %1743 = fadd <8 x float> %.state1138, %1742
  %.state1139 = load <8 x i64>, ptr %.slot56, align 64
  %1744 = add <8 x i64> %.state1139, splat (i64 1)
  %1745 = load <8 x i64>, ptr %.slot56, align 64
  %1746 = select <8 x i1> %1686, <8 x i64> %1744, <8 x i64> %1745
  store <8 x i64> %1746, ptr %.slot56, align 64
  %1747 = load <8 x float>, ptr %.slot139, align 32
  %1748 = select <8 x i1> %1686, <8 x float> %1737, <8 x float> %1747
  store <8 x float> %1748, ptr %.slot139, align 32
  %1749 = load <8 x float>, ptr %.slot140, align 32
  %1750 = select <8 x i1> %1686, <8 x float> %1739, <8 x float> %1749
  store <8 x float> %1750, ptr %.slot140, align 32
  %1751 = load <8 x float>, ptr %.slot141, align 32
  %1752 = select <8 x i1> %1686, <8 x float> %1741, <8 x float> %1751
  store <8 x float> %1752, ptr %.slot141, align 32
  %1753 = load <8 x float>, ptr %.slot142, align 32
  %1754 = select <8 x i1> %1686, <8 x float> %1743, <8 x float> %1753
  store <8 x float> %1754, ptr %.slot142, align 32
  store <8 x i1> %1686, ptr %current.mask, align 1
  %1755 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1686)
  br i1 %1755, label %schedule.66, label %scheduler.loop

schedule.68:                                      ; preds = %varying.coherent.false1126, %scheduler.dispatch.route
  %1756 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1142 = load i32, ptr %current.token, align 4
  %convergence.token.present1143 = icmp ne i32 %convergence.current.token1142, 0
  br i1 %convergence.token.present1143, label %convergence.cascade1140, label %convergence.cascade.exit1141

schedule.69:                                      ; preds = %schedule.70, %convergence.target.68.ready, %scheduler.dispatch.route
  %1757 = load <8 x i1>, ptr %current.mask, align 1
  %1758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1757)
  %1759 = bitcast <8 x i1> %1757 to i8
  %1760 = call i8 @llvm.cttz.i8(i8 %1759, i1 false)
  %1761 = zext i8 %1760 to i32
  %1762 = select i1 %1758, i32 %1761, i32 0
  %.state1367 = load <8 x i64>, ptr %.slot56, align 64
  %1763 = icmp slt <8 x i64> %.state1367, splat (i64 16)
  %1764 = and <8 x i1> %1757, %1763
  %1765 = xor <8 x i1> %1763, splat (i1 true)
  %1766 = and <8 x i1> %1757, %1765
  %1767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1764)
  %1768 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1766)
  %1769 = and i1 %1767, %1768
  br i1 %1769, label %varying.divergent1368, label %varying.coherent1369

schedule.70:                                      ; preds = %varying.coherent.true1374, %scheduler.dispatch.route
  %1770 = load <8 x i1>, ptr %current.mask, align 1
  %1771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1770)
  %1772 = bitcast <8 x i1> %1770 to i8
  %1773 = call i8 @llvm.cttz.i8(i8 %1772, i1 false)
  %1774 = zext i8 %1773 to i32
  %1775 = select i1 %1771, i32 %1774, i32 0
  %.state1376 = load <8 x i64>, ptr %.slot56, align 64
  %1776 = select <8 x i1> %1770, <8 x i64> %.state1376, <8 x i64> zeroinitializer
  %1777 = select <8 x i1> %1770, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1778 = sdiv <8 x i64> %1776, %1777
  %1779 = add <8 x i64> zeroinitializer, %1778
  %tile_snapshot.spill.load1377 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %1780 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1377, 0
  %1781 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1377, 1
  %1782 = mul <8 x i64> %1779, splat (i64 32)
  %1783 = add <8 x i64> %1781, %1782
  %1784 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1780, 0
  %1785 = insertvalue { <8 x ptr>, <8 x i64> } %1784, <8 x i64> %1783, 1
  %1786 = extractvalue { <8 x ptr>, <8 x i64> } %1785, 0
  %1787 = extractvalue { <8 x ptr>, <8 x i64> } %1785, 1
  %1788 = getelementptr i8, <8 x ptr> %1786, <8 x i64> %1787
  %1789 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1788, <8 x i1> %1770, <8 x float> zeroinitializer)
  %.state1378 = load <8 x float>, ptr %.slot58, align 32
  %1790 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1378, <8 x float> %1789)
  %.state1379 = load <8 x i64>, ptr %.slot56, align 64
  %1791 = add <8 x i64> %.state1379, splat (i64 1)
  %1792 = load <8 x i64>, ptr %.slot56, align 64
  %1793 = select <8 x i1> %1770, <8 x i64> %1791, <8 x i64> %1792
  store <8 x i64> %1793, ptr %.slot56, align 64
  %1794 = load <8 x float>, ptr %.slot58, align 32
  %1795 = select <8 x i1> %1770, <8 x float> %1790, <8 x float> %1794
  store <8 x float> %1795, ptr %.slot58, align 32
  store <8 x i1> %1770, ptr %current.mask, align 1
  %1796 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1770)
  br i1 %1796, label %schedule.69, label %scheduler.loop

schedule.71:                                      ; preds = %varying.coherent.false1375, %scheduler.dispatch.route
  %1797 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1382 = load i32, ptr %current.token, align 4
  %convergence.token.present1383 = icmp ne i32 %convergence.current.token1382, 0
  br i1 %convergence.token.present1383, label %convergence.cascade1380, label %convergence.cascade.exit1381

schedule.72:                                      ; preds = %schedule.73, %convergence.target.71.ready, %scheduler.dispatch.route
  %1798 = load <8 x i1>, ptr %current.mask, align 1
  %1799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1798)
  %1800 = bitcast <8 x i1> %1798 to i8
  %1801 = call i8 @llvm.cttz.i8(i8 %1800, i1 false)
  %1802 = zext i8 %1801 to i32
  %1803 = select i1 %1799, i32 %1802, i32 0
  %.state1397 = load <8 x i64>, ptr %.slot56, align 64
  %1804 = icmp slt <8 x i64> %.state1397, splat (i64 16)
  %1805 = and <8 x i1> %1798, %1804
  %1806 = xor <8 x i1> %1804, splat (i1 true)
  %1807 = and <8 x i1> %1798, %1806
  %1808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1805)
  %1809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1807)
  %1810 = and i1 %1808, %1809
  br i1 %1810, label %varying.divergent1398, label %varying.coherent1399

schedule.73:                                      ; preds = %varying.coherent.true1404, %scheduler.dispatch.route
  %1811 = load <8 x i1>, ptr %current.mask, align 1
  %1812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1811)
  %1813 = bitcast <8 x i1> %1811 to i8
  %1814 = call i8 @llvm.cttz.i8(i8 %1813, i1 false)
  %1815 = zext i8 %1814 to i32
  %1816 = select i1 %1812, i32 %1815, i32 0
  %.state1406 = load <8 x i64>, ptr %.slot56, align 64
  %1817 = select <8 x i1> %1811, <8 x i64> %.state1406, <8 x i64> zeroinitializer
  %1818 = select <8 x i1> %1811, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1819 = sdiv <8 x i64> %1817, %1818
  %1820 = add <8 x i64> splat (i64 16), %1819
  %tile_snapshot.spill.load1407 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %1821 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1407, 0
  %1822 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1407, 1
  %1823 = mul <8 x i64> %1820, splat (i64 32)
  %1824 = add <8 x i64> %1822, %1823
  %1825 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1821, 0
  %1826 = insertvalue { <8 x ptr>, <8 x i64> } %1825, <8 x i64> %1824, 1
  %1827 = extractvalue { <8 x ptr>, <8 x i64> } %1826, 0
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %1826, 1
  %1829 = getelementptr i8, <8 x ptr> %1827, <8 x i64> %1828
  %1830 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1829, <8 x i1> %1811, <8 x float> zeroinitializer)
  %.state1408 = load <8 x float>, ptr %.slot65, align 32
  %1831 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1408, <8 x float> %1830)
  %.state1409 = load <8 x i64>, ptr %.slot56, align 64
  %1832 = add <8 x i64> %.state1409, splat (i64 1)
  %1833 = load <8 x i64>, ptr %.slot56, align 64
  %1834 = select <8 x i1> %1811, <8 x i64> %1832, <8 x i64> %1833
  store <8 x i64> %1834, ptr %.slot56, align 64
  %1835 = load <8 x float>, ptr %.slot65, align 32
  %1836 = select <8 x i1> %1811, <8 x float> %1831, <8 x float> %1835
  store <8 x float> %1836, ptr %.slot65, align 32
  store <8 x i1> %1811, ptr %current.mask, align 1
  %1837 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1811)
  br i1 %1837, label %schedule.72, label %scheduler.loop

schedule.74:                                      ; preds = %varying.coherent.false1405, %scheduler.dispatch.route
  %1838 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1412 = load i32, ptr %current.token, align 4
  %convergence.token.present1413 = icmp ne i32 %convergence.current.token1412, 0
  br i1 %convergence.token.present1413, label %convergence.cascade1410, label %convergence.cascade.exit1411

schedule.75:                                      ; preds = %schedule.76, %convergence.target.74.ready, %scheduler.dispatch.route
  %1839 = load <8 x i1>, ptr %current.mask, align 1
  %1840 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1839)
  %1841 = bitcast <8 x i1> %1839 to i8
  %1842 = call i8 @llvm.cttz.i8(i8 %1841, i1 false)
  %1843 = zext i8 %1842 to i32
  %1844 = select i1 %1840, i32 %1843, i32 0
  %.state1427 = load <8 x i64>, ptr %.slot56, align 64
  %1845 = icmp slt <8 x i64> %.state1427, splat (i64 16)
  %1846 = and <8 x i1> %1839, %1845
  %1847 = xor <8 x i1> %1845, splat (i1 true)
  %1848 = and <8 x i1> %1839, %1847
  %1849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1846)
  %1850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1848)
  %1851 = and i1 %1849, %1850
  br i1 %1851, label %varying.divergent1428, label %varying.coherent1429

schedule.76:                                      ; preds = %varying.coherent.true1434, %scheduler.dispatch.route
  %1852 = load <8 x i1>, ptr %current.mask, align 1
  %1853 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1852)
  %1854 = bitcast <8 x i1> %1852 to i8
  %1855 = call i8 @llvm.cttz.i8(i8 %1854, i1 false)
  %1856 = zext i8 %1855 to i32
  %1857 = select i1 %1853, i32 %1856, i32 0
  %.state1436 = load <8 x i64>, ptr %.slot56, align 64
  %1858 = select <8 x i1> %1852, <8 x i64> %.state1436, <8 x i64> zeroinitializer
  %1859 = select <8 x i1> %1852, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1860 = sdiv <8 x i64> %1858, %1859
  %1861 = add <8 x i64> splat (i64 32), %1860
  %tile_snapshot.spill.load1437 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %1862 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1437, 0
  %1863 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1437, 1
  %1864 = mul <8 x i64> %1861, splat (i64 32)
  %1865 = add <8 x i64> %1863, %1864
  %1866 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1862, 0
  %1867 = insertvalue { <8 x ptr>, <8 x i64> } %1866, <8 x i64> %1865, 1
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %1867, 0
  %1869 = extractvalue { <8 x ptr>, <8 x i64> } %1867, 1
  %1870 = getelementptr i8, <8 x ptr> %1868, <8 x i64> %1869
  %1871 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1870, <8 x i1> %1852, <8 x float> zeroinitializer)
  %.state1438 = load <8 x float>, ptr %.slot66, align 32
  %1872 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1438, <8 x float> %1871)
  %.state1439 = load <8 x i64>, ptr %.slot56, align 64
  %1873 = add <8 x i64> %.state1439, splat (i64 1)
  %1874 = load <8 x i64>, ptr %.slot56, align 64
  %1875 = select <8 x i1> %1852, <8 x i64> %1873, <8 x i64> %1874
  store <8 x i64> %1875, ptr %.slot56, align 64
  %1876 = load <8 x float>, ptr %.slot66, align 32
  %1877 = select <8 x i1> %1852, <8 x float> %1872, <8 x float> %1876
  store <8 x float> %1877, ptr %.slot66, align 32
  store <8 x i1> %1852, ptr %current.mask, align 1
  %1878 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1852)
  br i1 %1878, label %schedule.75, label %scheduler.loop

schedule.77:                                      ; preds = %varying.coherent.false1435, %scheduler.dispatch.route
  %1879 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1442 = load i32, ptr %current.token, align 4
  %convergence.token.present1443 = icmp ne i32 %convergence.current.token1442, 0
  br i1 %convergence.token.present1443, label %convergence.cascade1440, label %convergence.cascade.exit1441

schedule.78:                                      ; preds = %schedule.79, %convergence.target.77.ready, %scheduler.dispatch.route
  %1880 = load <8 x i1>, ptr %current.mask, align 1
  %1881 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1880)
  %1882 = bitcast <8 x i1> %1880 to i8
  %1883 = call i8 @llvm.cttz.i8(i8 %1882, i1 false)
  %1884 = zext i8 %1883 to i32
  %1885 = select i1 %1881, i32 %1884, i32 0
  %.state1457 = load <8 x i64>, ptr %.slot56, align 64
  %1886 = icmp slt <8 x i64> %.state1457, splat (i64 16)
  %1887 = and <8 x i1> %1880, %1886
  %1888 = xor <8 x i1> %1886, splat (i1 true)
  %1889 = and <8 x i1> %1880, %1888
  %1890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1887)
  %1891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1889)
  %1892 = and i1 %1890, %1891
  br i1 %1892, label %varying.divergent1458, label %varying.coherent1459

schedule.79:                                      ; preds = %varying.coherent.true1464, %scheduler.dispatch.route
  %1893 = load <8 x i1>, ptr %current.mask, align 1
  %1894 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1893)
  %1895 = bitcast <8 x i1> %1893 to i8
  %1896 = call i8 @llvm.cttz.i8(i8 %1895, i1 false)
  %1897 = zext i8 %1896 to i32
  %1898 = select i1 %1894, i32 %1897, i32 0
  %.state1466 = load <8 x i64>, ptr %.slot56, align 64
  %1899 = select <8 x i1> %1893, <8 x i64> %.state1466, <8 x i64> zeroinitializer
  %1900 = select <8 x i1> %1893, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1901 = sdiv <8 x i64> %1899, %1900
  %1902 = add <8 x i64> splat (i64 48), %1901
  %tile_snapshot.spill.load1467 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %1903 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1467, 0
  %1904 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1467, 1
  %1905 = mul <8 x i64> %1902, splat (i64 32)
  %1906 = add <8 x i64> %1904, %1905
  %1907 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1903, 0
  %1908 = insertvalue { <8 x ptr>, <8 x i64> } %1907, <8 x i64> %1906, 1
  %1909 = extractvalue { <8 x ptr>, <8 x i64> } %1908, 0
  %1910 = extractvalue { <8 x ptr>, <8 x i64> } %1908, 1
  %1911 = getelementptr i8, <8 x ptr> %1909, <8 x i64> %1910
  %1912 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1911, <8 x i1> %1893, <8 x float> zeroinitializer)
  %.state1468 = load <8 x float>, ptr %.slot67, align 32
  %1913 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1468, <8 x float> %1912)
  %.state1469 = load <8 x i64>, ptr %.slot56, align 64
  %1914 = add <8 x i64> %.state1469, splat (i64 1)
  %1915 = load <8 x i64>, ptr %.slot56, align 64
  %1916 = select <8 x i1> %1893, <8 x i64> %1914, <8 x i64> %1915
  store <8 x i64> %1916, ptr %.slot56, align 64
  %1917 = load <8 x float>, ptr %.slot67, align 32
  %1918 = select <8 x i1> %1893, <8 x float> %1913, <8 x float> %1917
  store <8 x float> %1918, ptr %.slot67, align 32
  store <8 x i1> %1893, ptr %current.mask, align 1
  %1919 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1893)
  br i1 %1919, label %schedule.78, label %scheduler.loop

schedule.80:                                      ; preds = %varying.coherent.false1465, %scheduler.dispatch.route
  %1920 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1472 = load i32, ptr %current.token, align 4
  %convergence.token.present1473 = icmp ne i32 %convergence.current.token1472, 0
  br i1 %convergence.token.present1473, label %convergence.cascade1470, label %convergence.cascade.exit1471

schedule.81:                                      ; preds = %schedule.82, %convergence.target.80.ready, %scheduler.dispatch.route
  %1921 = load <8 x i1>, ptr %current.mask, align 1
  %1922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1921)
  %1923 = bitcast <8 x i1> %1921 to i8
  %1924 = call i8 @llvm.cttz.i8(i8 %1923, i1 false)
  %1925 = zext i8 %1924 to i32
  %1926 = select i1 %1922, i32 %1925, i32 0
  %.state1834 = load <8 x i64>, ptr %.slot56, align 64
  %1927 = icmp slt <8 x i64> %.state1834, splat (i64 16)
  %1928 = and <8 x i1> %1921, %1927
  %1929 = xor <8 x i1> %1927, splat (i1 true)
  %1930 = and <8 x i1> %1921, %1929
  %1931 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1928)
  %1932 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1930)
  %1933 = and i1 %1931, %1932
  br i1 %1933, label %varying.divergent1835, label %varying.coherent1836

schedule.82:                                      ; preds = %varying.coherent.true1841, %scheduler.dispatch.route
  %1934 = load <8 x i1>, ptr %current.mask, align 1
  %1935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1934)
  %1936 = bitcast <8 x i1> %1934 to i8
  %1937 = call i8 @llvm.cttz.i8(i8 %1936, i1 false)
  %1938 = zext i8 %1937 to i32
  %1939 = select i1 %1935, i32 %1938, i32 0
  %.state1843 = load <8 x i64>, ptr %.slot56, align 64
  %1940 = select <8 x i1> %1934, <8 x i64> %.state1843, <8 x i64> zeroinitializer
  %1941 = select <8 x i1> %1934, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1942 = sdiv <8 x i64> %1940, %1941
  %1943 = add <8 x i64> zeroinitializer, %1942
  %tile_snapshot.spill.load1844 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %1944 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1844, 0
  %1945 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1844, 1
  %1946 = mul <8 x i64> %1943, splat (i64 32)
  %1947 = add <8 x i64> %1945, %1946
  %1948 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1944, 0
  %1949 = insertvalue { <8 x ptr>, <8 x i64> } %1948, <8 x i64> %1947, 1
  %1950 = extractvalue { <8 x ptr>, <8 x i64> } %1949, 0
  %1951 = extractvalue { <8 x ptr>, <8 x i64> } %1949, 1
  %1952 = getelementptr i8, <8 x ptr> %1950, <8 x i64> %1951
  %1953 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1952, <8 x i1> %1934, <8 x float> zeroinitializer)
  %.state1845 = load <8 x float>, ptr %.slot41, align 32
  %1954 = fadd <8 x float> %.state1845, %1953
  %.state1846 = load <8 x i64>, ptr %.slot56, align 64
  %1955 = add <8 x i64> %.state1846, splat (i64 1)
  %1956 = load <8 x i64>, ptr %.slot56, align 64
  %1957 = select <8 x i1> %1934, <8 x i64> %1955, <8 x i64> %1956
  store <8 x i64> %1957, ptr %.slot56, align 64
  %1958 = load <8 x float>, ptr %.slot41, align 32
  %1959 = select <8 x i1> %1934, <8 x float> %1954, <8 x float> %1958
  store <8 x float> %1959, ptr %.slot41, align 32
  store <8 x i1> %1934, ptr %current.mask, align 1
  %1960 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1934)
  br i1 %1960, label %schedule.81, label %scheduler.loop

schedule.83:                                      ; preds = %varying.coherent.false1842, %scheduler.dispatch.route
  %1961 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1849 = load i32, ptr %current.token, align 4
  %convergence.token.present1850 = icmp ne i32 %convergence.current.token1849, 0
  br i1 %convergence.token.present1850, label %convergence.cascade1847, label %convergence.cascade.exit1848

schedule.84:                                      ; preds = %schedule.85, %convergence.target.83.ready, %scheduler.dispatch.route
  %1962 = load <8 x i1>, ptr %current.mask, align 1
  %1963 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1962)
  %1964 = bitcast <8 x i1> %1962 to i8
  %1965 = call i8 @llvm.cttz.i8(i8 %1964, i1 false)
  %1966 = zext i8 %1965 to i32
  %1967 = select i1 %1963, i32 %1966, i32 0
  %.state1864 = load <8 x i64>, ptr %.slot56, align 64
  %1968 = icmp slt <8 x i64> %.state1864, splat (i64 16)
  %1969 = and <8 x i1> %1962, %1968
  %1970 = xor <8 x i1> %1968, splat (i1 true)
  %1971 = and <8 x i1> %1962, %1970
  %1972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1969)
  %1973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1971)
  %1974 = and i1 %1972, %1973
  br i1 %1974, label %varying.divergent1865, label %varying.coherent1866

schedule.85:                                      ; preds = %varying.coherent.true1871, %scheduler.dispatch.route
  %1975 = load <8 x i1>, ptr %current.mask, align 1
  %1976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1975)
  %1977 = bitcast <8 x i1> %1975 to i8
  %1978 = call i8 @llvm.cttz.i8(i8 %1977, i1 false)
  %1979 = zext i8 %1978 to i32
  %1980 = select i1 %1976, i32 %1979, i32 0
  %.state1873 = load <8 x i64>, ptr %.slot56, align 64
  %1981 = select <8 x i1> %1975, <8 x i64> %.state1873, <8 x i64> zeroinitializer
  %1982 = select <8 x i1> %1975, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1983 = sdiv <8 x i64> %1981, %1982
  %1984 = add <8 x i64> splat (i64 16), %1983
  %tile_snapshot.spill.load1874 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %1985 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1874, 0
  %1986 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1874, 1
  %1987 = mul <8 x i64> %1984, splat (i64 32)
  %1988 = add <8 x i64> %1986, %1987
  %1989 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1985, 0
  %1990 = insertvalue { <8 x ptr>, <8 x i64> } %1989, <8 x i64> %1988, 1
  %1991 = extractvalue { <8 x ptr>, <8 x i64> } %1990, 0
  %1992 = extractvalue { <8 x ptr>, <8 x i64> } %1990, 1
  %1993 = getelementptr i8, <8 x ptr> %1991, <8 x i64> %1992
  %1994 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1993, <8 x i1> %1975, <8 x float> zeroinitializer)
  %.state1875 = load <8 x float>, ptr %.slot47, align 32
  %1995 = fadd <8 x float> %.state1875, %1994
  %.state1876 = load <8 x i64>, ptr %.slot56, align 64
  %1996 = add <8 x i64> %.state1876, splat (i64 1)
  %1997 = load <8 x i64>, ptr %.slot56, align 64
  %1998 = select <8 x i1> %1975, <8 x i64> %1996, <8 x i64> %1997
  store <8 x i64> %1998, ptr %.slot56, align 64
  %1999 = load <8 x float>, ptr %.slot47, align 32
  %2000 = select <8 x i1> %1975, <8 x float> %1995, <8 x float> %1999
  store <8 x float> %2000, ptr %.slot47, align 32
  store <8 x i1> %1975, ptr %current.mask, align 1
  %2001 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1975)
  br i1 %2001, label %schedule.84, label %scheduler.loop

schedule.86:                                      ; preds = %varying.coherent.false1872, %scheduler.dispatch.route
  %2002 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1879 = load i32, ptr %current.token, align 4
  %convergence.token.present1880 = icmp ne i32 %convergence.current.token1879, 0
  br i1 %convergence.token.present1880, label %convergence.cascade1877, label %convergence.cascade.exit1878

schedule.87:                                      ; preds = %schedule.88, %convergence.target.86.ready, %scheduler.dispatch.route
  %2003 = load <8 x i1>, ptr %current.mask, align 1
  %2004 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2003)
  %2005 = bitcast <8 x i1> %2003 to i8
  %2006 = call i8 @llvm.cttz.i8(i8 %2005, i1 false)
  %2007 = zext i8 %2006 to i32
  %2008 = select i1 %2004, i32 %2007, i32 0
  %.state1894 = load <8 x i64>, ptr %.slot56, align 64
  %2009 = icmp slt <8 x i64> %.state1894, splat (i64 16)
  %2010 = and <8 x i1> %2003, %2009
  %2011 = xor <8 x i1> %2009, splat (i1 true)
  %2012 = and <8 x i1> %2003, %2011
  %2013 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2010)
  %2014 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2012)
  %2015 = and i1 %2013, %2014
  br i1 %2015, label %varying.divergent1895, label %varying.coherent1896

schedule.88:                                      ; preds = %varying.coherent.true1901, %scheduler.dispatch.route
  %2016 = load <8 x i1>, ptr %current.mask, align 1
  %2017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2016)
  %2018 = bitcast <8 x i1> %2016 to i8
  %2019 = call i8 @llvm.cttz.i8(i8 %2018, i1 false)
  %2020 = zext i8 %2019 to i32
  %2021 = select i1 %2017, i32 %2020, i32 0
  %.state1903 = load <8 x i64>, ptr %.slot56, align 64
  %2022 = select <8 x i1> %2016, <8 x i64> %.state1903, <8 x i64> zeroinitializer
  %2023 = select <8 x i1> %2016, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2024 = sdiv <8 x i64> %2022, %2023
  %2025 = add <8 x i64> splat (i64 32), %2024
  %tile_snapshot.spill.load1904 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %2026 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1904, 0
  %2027 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1904, 1
  %2028 = mul <8 x i64> %2025, splat (i64 32)
  %2029 = add <8 x i64> %2027, %2028
  %2030 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2026, 0
  %2031 = insertvalue { <8 x ptr>, <8 x i64> } %2030, <8 x i64> %2029, 1
  %2032 = extractvalue { <8 x ptr>, <8 x i64> } %2031, 0
  %2033 = extractvalue { <8 x ptr>, <8 x i64> } %2031, 1
  %2034 = getelementptr i8, <8 x ptr> %2032, <8 x i64> %2033
  %2035 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2034, <8 x i1> %2016, <8 x float> zeroinitializer)
  %.state1905 = load <8 x float>, ptr %.slot48, align 32
  %2036 = fadd <8 x float> %.state1905, %2035
  %.state1906 = load <8 x i64>, ptr %.slot56, align 64
  %2037 = add <8 x i64> %.state1906, splat (i64 1)
  %2038 = load <8 x i64>, ptr %.slot56, align 64
  %2039 = select <8 x i1> %2016, <8 x i64> %2037, <8 x i64> %2038
  store <8 x i64> %2039, ptr %.slot56, align 64
  %2040 = load <8 x float>, ptr %.slot48, align 32
  %2041 = select <8 x i1> %2016, <8 x float> %2036, <8 x float> %2040
  store <8 x float> %2041, ptr %.slot48, align 32
  store <8 x i1> %2016, ptr %current.mask, align 1
  %2042 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2016)
  br i1 %2042, label %schedule.87, label %scheduler.loop

schedule.89:                                      ; preds = %varying.coherent.false1902, %scheduler.dispatch.route
  %2043 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1909 = load i32, ptr %current.token, align 4
  %convergence.token.present1910 = icmp ne i32 %convergence.current.token1909, 0
  br i1 %convergence.token.present1910, label %convergence.cascade1907, label %convergence.cascade.exit1908

schedule.90:                                      ; preds = %schedule.91, %convergence.target.89.ready, %scheduler.dispatch.route
  %2044 = load <8 x i1>, ptr %current.mask, align 1
  %2045 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2044)
  %2046 = bitcast <8 x i1> %2044 to i8
  %2047 = call i8 @llvm.cttz.i8(i8 %2046, i1 false)
  %2048 = zext i8 %2047 to i32
  %2049 = select i1 %2045, i32 %2048, i32 0
  %.state1924 = load <8 x i64>, ptr %.slot56, align 64
  %2050 = icmp slt <8 x i64> %.state1924, splat (i64 16)
  %2051 = and <8 x i1> %2044, %2050
  %2052 = xor <8 x i1> %2050, splat (i1 true)
  %2053 = and <8 x i1> %2044, %2052
  %2054 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2051)
  %2055 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2053)
  %2056 = and i1 %2054, %2055
  br i1 %2056, label %varying.divergent1925, label %varying.coherent1926

schedule.91:                                      ; preds = %varying.coherent.true1931, %scheduler.dispatch.route
  %2057 = load <8 x i1>, ptr %current.mask, align 1
  %2058 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2057)
  %2059 = bitcast <8 x i1> %2057 to i8
  %2060 = call i8 @llvm.cttz.i8(i8 %2059, i1 false)
  %2061 = zext i8 %2060 to i32
  %2062 = select i1 %2058, i32 %2061, i32 0
  %.state1933 = load <8 x i64>, ptr %.slot56, align 64
  %2063 = select <8 x i1> %2057, <8 x i64> %.state1933, <8 x i64> zeroinitializer
  %2064 = select <8 x i1> %2057, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2065 = sdiv <8 x i64> %2063, %2064
  %2066 = add <8 x i64> splat (i64 48), %2065
  %tile_snapshot.spill.load1934 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %2067 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1934, 0
  %2068 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1934, 1
  %2069 = mul <8 x i64> %2066, splat (i64 32)
  %2070 = add <8 x i64> %2068, %2069
  %2071 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2067, 0
  %2072 = insertvalue { <8 x ptr>, <8 x i64> } %2071, <8 x i64> %2070, 1
  %2073 = extractvalue { <8 x ptr>, <8 x i64> } %2072, 0
  %2074 = extractvalue { <8 x ptr>, <8 x i64> } %2072, 1
  %2075 = getelementptr i8, <8 x ptr> %2073, <8 x i64> %2074
  %2076 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2075, <8 x i1> %2057, <8 x float> zeroinitializer)
  %.state1935 = load <8 x float>, ptr %.slot49, align 32
  %2077 = fadd <8 x float> %.state1935, %2076
  %.state1936 = load <8 x i64>, ptr %.slot56, align 64
  %2078 = add <8 x i64> %.state1936, splat (i64 1)
  %2079 = load <8 x i64>, ptr %.slot56, align 64
  %2080 = select <8 x i1> %2057, <8 x i64> %2078, <8 x i64> %2079
  store <8 x i64> %2080, ptr %.slot56, align 64
  %2081 = load <8 x float>, ptr %.slot49, align 32
  %2082 = select <8 x i1> %2057, <8 x float> %2077, <8 x float> %2081
  store <8 x float> %2082, ptr %.slot49, align 32
  store <8 x i1> %2057, ptr %current.mask, align 1
  %2083 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2057)
  br i1 %2083, label %schedule.90, label %scheduler.loop

schedule.92:                                      ; preds = %varying.coherent.false1932, %scheduler.dispatch.route
  %2084 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1939 = load i32, ptr %current.token, align 4
  %convergence.token.present1940 = icmp ne i32 %convergence.current.token1939, 0
  br i1 %convergence.token.present1940, label %convergence.cascade1937, label %convergence.cascade.exit1938

schedule.93:                                      ; preds = %convergence.target.100.ready, %convergence.target.92.ready, %scheduler.dispatch.route
  %2085 = load <8 x i1>, ptr %current.mask, align 1
  %2086 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2085)
  %2087 = bitcast <8 x i1> %2085 to i8
  %2088 = call i8 @llvm.cttz.i8(i8 %2087, i1 false)
  %2089 = zext i8 %2088 to i32
  %2090 = select i1 %2086, i32 %2089, i32 0
  %.state1962 = load <8 x i64>, ptr %.slot56, align 64
  %2091 = icmp slt <8 x i64> %.state1962, splat (i64 2)
  %2092 = and <8 x i1> %2085, %2091
  %2093 = xor <8 x i1> %2091, splat (i1 true)
  %2094 = and <8 x i1> %2085, %2093
  %2095 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2092)
  %2096 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2094)
  %2097 = and i1 %2095, %2096
  br i1 %2097, label %varying.divergent1963, label %varying.coherent1964

schedule.94:                                      ; preds = %varying.coherent.true1969, %scheduler.dispatch.route
  %2098 = load <8 x i1>, ptr %current.mask, align 1
  %2099 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2098)
  %2100 = bitcast <8 x i1> %2098 to i8
  %2101 = call i8 @llvm.cttz.i8(i8 %2100, i1 false)
  %2102 = zext i8 %2101 to i32
  %2103 = select i1 %2099, i32 %2102, i32 0
  %.state1971 = load <8 x i64>, ptr %.slot56, align 64
  %2104 = mul <8 x i64> %.state1971, splat (i64 2)
  %2105 = load <8 x i64>, ptr %.spill304, align 64
  %2106 = select <8 x i1> %2098, <8 x i64> %2104, <8 x i64> %2105
  store <8 x i64> %2106, ptr %.spill304, align 64
  %2107 = load <8 x i64>, ptr %.slot305, align 64
  %2108 = select <8 x i1> %2098, <8 x i64> zeroinitializer, <8 x i64> %2107
  store <8 x i64> %2108, ptr %.slot305, align 64
  store <8 x i1> %2098, ptr %current.mask, align 1
  %2109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2098)
  br i1 %2109, label %schedule.95, label %scheduler.loop

schedule.95:                                      ; preds = %convergence.target.99.ready, %schedule.94, %scheduler.dispatch.route
  %2110 = load <8 x i1>, ptr %current.mask, align 1
  %2111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2110)
  %2112 = bitcast <8 x i1> %2110 to i8
  %2113 = call i8 @llvm.cttz.i8(i8 %2112, i1 false)
  %2114 = zext i8 %2113 to i32
  %2115 = select i1 %2111, i32 %2114, i32 0
  %.state1972 = load <8 x i64>, ptr %.slot305, align 64
  %2116 = icmp slt <8 x i64> %.state1972, splat (i64 24)
  %2117 = and <8 x i1> %2110, %2116
  %2118 = xor <8 x i1> %2116, splat (i1 true)
  %2119 = and <8 x i1> %2110, %2118
  %2120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2117)
  %2121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2119)
  %2122 = and i1 %2120, %2121
  br i1 %2122, label %varying.divergent1973, label %varying.coherent1974

schedule.96:                                      ; preds = %varying.coherent.true1979, %scheduler.dispatch.route
  %2123 = load <8 x i1>, ptr %current.mask, align 1
  %2124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2123)
  %2125 = bitcast <8 x i1> %2123 to i8
  %2126 = call i8 @llvm.cttz.i8(i8 %2125, i1 false)
  %2127 = zext i8 %2126 to i32
  %2128 = select i1 %2124, i32 %2127, i32 0
  %.state1981 = load <8 x i64>, ptr %.slot305, align 64
  %2129 = mul <8 x i64> %.state1981, splat (i64 2)
  %.spill.load1982 = load <8 x i64>, ptr %.spill304, align 64
  %2130 = add <8 x i64> zeroinitializer, %.spill.load1982
  %2131 = mul <8 x i64> %2130, splat (i64 48)
  %2132 = add <8 x i64> %2131, %2129
  %2133 = add <8 x i64> %2132, zeroinitializer
  %2134 = load <8 x i64>, ptr %.spill306, align 64
  %2135 = select <8 x i1> %2123, <8 x i64> %2133, <8 x i64> %2134
  store <8 x i64> %2135, ptr %.spill306, align 64
  %2136 = select <8 x i1> %2123, <8 x i64> %2133, <8 x i64> zeroinitializer
  %2137 = select <8 x i1> %2123, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2138 = srem <8 x i64> %2136, %2137
  %2139 = load <8 x i64>, ptr %.spill307, align 64
  %2140 = select <8 x i1> %2123, <8 x i64> %2138, <8 x i64> %2139
  store <8 x i64> %2140, ptr %.spill307, align 64
  %2141 = select <8 x i1> %2123, <8 x i64> %2133, <8 x i64> zeroinitializer
  %2142 = select <8 x i1> %2123, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2143 = sdiv <8 x i64> %2141, %2142
  %2144 = add <8 x i64> zeroinitializer, %2143
  %2145 = load <8 x i64>, ptr %.spill308, align 64
  %2146 = select <8 x i1> %2123, <8 x i64> %2144, <8 x i64> %2145
  store <8 x i64> %2146, ptr %.spill308, align 64
  %2147 = mul <8 x i64> %2144, splat (i64 48)
  %2148 = add <8 x i64> %2147, %2138
  %tile_snapshot.spill.load1983 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1983, 0
  %2150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1983, 1
  %2151 = mul <8 x i64> %2148, splat (i64 32)
  %2152 = add <8 x i64> %2150, %2151
  %2153 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2149, 0
  %2154 = insertvalue { <8 x ptr>, <8 x i64> } %2153, <8 x i64> %2152, 1
  %2155 = extractvalue { <8 x ptr>, <8 x i64> } %2154, 0
  %2156 = extractvalue { <8 x ptr>, <8 x i64> } %2154, 1
  %2157 = getelementptr i8, <8 x ptr> %2155, <8 x i64> %2156
  %2158 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2157, <8 x i1> %2123, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1984 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill284, align 64
  %2159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1984, 0
  %2160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1984, 1
  %2161 = mul <8 x i64> %2144, splat (i64 32)
  %2162 = add <8 x i64> %2160, %2161
  %2163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2159, 0
  %2164 = insertvalue { <8 x ptr>, <8 x i64> } %2163, <8 x i64> %2162, 1
  %2165 = extractvalue { <8 x ptr>, <8 x i64> } %2164, 0
  %2166 = extractvalue { <8 x ptr>, <8 x i64> } %2164, 1
  %2167 = getelementptr i8, <8 x ptr> %2165, <8 x i64> %2166
  %2168 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2167, <8 x i1> %2123, <8 x float> zeroinitializer)
  %2169 = fmul <8 x float> %2158, %2168
  %2170 = add <8 x i64> %2132, splat (i64 1)
  %2171 = load <8 x i64>, ptr %.spill309, align 64
  %2172 = select <8 x i1> %2123, <8 x i64> %2170, <8 x i64> %2171
  store <8 x i64> %2172, ptr %.spill309, align 64
  %2173 = select <8 x i1> %2123, <8 x i64> %2170, <8 x i64> zeroinitializer
  %2174 = select <8 x i1> %2123, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2175 = srem <8 x i64> %2173, %2174
  %2176 = load <8 x i64>, ptr %.spill310, align 64
  %2177 = select <8 x i1> %2123, <8 x i64> %2175, <8 x i64> %2176
  store <8 x i64> %2177, ptr %.spill310, align 64
  %2178 = select <8 x i1> %2123, <8 x i64> %2170, <8 x i64> zeroinitializer
  %2179 = select <8 x i1> %2123, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2180 = sdiv <8 x i64> %2178, %2179
  %2181 = add <8 x i64> zeroinitializer, %2180
  %2182 = mul <8 x i64> %2181, splat (i64 48)
  %2183 = add <8 x i64> %2182, %2175
  %tile_snapshot.spill.load1985 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1985, 0
  %2185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1985, 1
  %2186 = mul <8 x i64> %2183, splat (i64 32)
  %2187 = add <8 x i64> %2185, %2186
  %2188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2184, 0
  %2189 = insertvalue { <8 x ptr>, <8 x i64> } %2188, <8 x i64> %2187, 1
  %2190 = extractvalue { <8 x ptr>, <8 x i64> } %2189, 0
  %2191 = extractvalue { <8 x ptr>, <8 x i64> } %2189, 1
  %2192 = getelementptr i8, <8 x ptr> %2190, <8 x i64> %2191
  %2193 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2192, <8 x i1> %2123, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1986 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill284, align 64
  %2194 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1986, 0
  %2195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1986, 1
  %2196 = mul <8 x i64> %2181, splat (i64 32)
  %2197 = add <8 x i64> %2195, %2196
  %2198 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2194, 0
  %2199 = insertvalue { <8 x ptr>, <8 x i64> } %2198, <8 x i64> %2197, 1
  %2200 = extractvalue { <8 x ptr>, <8 x i64> } %2199, 0
  %2201 = extractvalue { <8 x ptr>, <8 x i64> } %2199, 1
  %2202 = getelementptr i8, <8 x ptr> %2200, <8 x i64> %2201
  %2203 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2202, <8 x i1> %2123, <8 x float> zeroinitializer)
  %2204 = fmul <8 x float> %2193, %2203
  %2205 = add <8 x i64> %2132, splat (i64 48)
  %2206 = load <8 x i64>, ptr %.spill311, align 64
  %2207 = select <8 x i1> %2123, <8 x i64> %2205, <8 x i64> %2206
  store <8 x i64> %2207, ptr %.spill311, align 64
  %2208 = select <8 x i1> %2123, <8 x i64> %2205, <8 x i64> zeroinitializer
  %2209 = select <8 x i1> %2123, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2210 = srem <8 x i64> %2208, %2209
  %2211 = select <8 x i1> %2123, <8 x i64> %2205, <8 x i64> zeroinitializer
  %2212 = select <8 x i1> %2123, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2213 = sdiv <8 x i64> %2211, %2212
  %2214 = add <8 x i64> zeroinitializer, %2213
  %2215 = load <8 x i64>, ptr %.spill312, align 64
  %2216 = select <8 x i1> %2123, <8 x i64> %2214, <8 x i64> %2215
  store <8 x i64> %2216, ptr %.spill312, align 64
  %2217 = mul <8 x i64> %2214, splat (i64 48)
  %2218 = add <8 x i64> %2217, %2210
  %tile_snapshot.spill.load1987 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2219 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1987, 0
  %2220 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1987, 1
  %2221 = mul <8 x i64> %2218, splat (i64 32)
  %2222 = add <8 x i64> %2220, %2221
  %2223 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2219, 0
  %2224 = insertvalue { <8 x ptr>, <8 x i64> } %2223, <8 x i64> %2222, 1
  %2225 = extractvalue { <8 x ptr>, <8 x i64> } %2224, 0
  %2226 = extractvalue { <8 x ptr>, <8 x i64> } %2224, 1
  %2227 = getelementptr i8, <8 x ptr> %2225, <8 x i64> %2226
  %2228 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2227, <8 x i1> %2123, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1988 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill284, align 64
  %2229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1988, 0
  %2230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1988, 1
  %2231 = mul <8 x i64> %2214, splat (i64 32)
  %2232 = add <8 x i64> %2230, %2231
  %2233 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2229, 0
  %2234 = insertvalue { <8 x ptr>, <8 x i64> } %2233, <8 x i64> %2232, 1
  %2235 = extractvalue { <8 x ptr>, <8 x i64> } %2234, 0
  %2236 = extractvalue { <8 x ptr>, <8 x i64> } %2234, 1
  %2237 = getelementptr i8, <8 x ptr> %2235, <8 x i64> %2236
  %2238 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2237, <8 x i1> %2123, <8 x float> zeroinitializer)
  %2239 = fmul <8 x float> %2228, %2238
  %2240 = add <8 x i64> %2132, splat (i64 49)
  %2241 = load <8 x i64>, ptr %.spill313, align 64
  %2242 = select <8 x i1> %2123, <8 x i64> %2240, <8 x i64> %2241
  store <8 x i64> %2242, ptr %.spill313, align 64
  %2243 = select <8 x i1> %2123, <8 x i64> %2240, <8 x i64> zeroinitializer
  %2244 = select <8 x i1> %2123, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2245 = srem <8 x i64> %2243, %2244
  %2246 = select <8 x i1> %2123, <8 x i64> %2240, <8 x i64> zeroinitializer
  %2247 = select <8 x i1> %2123, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2248 = sdiv <8 x i64> %2246, %2247
  %2249 = add <8 x i64> zeroinitializer, %2248
  %2250 = mul <8 x i64> %2249, splat (i64 48)
  %2251 = add <8 x i64> %2250, %2245
  %tile_snapshot.spill.load1989 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1989, 0
  %2253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1989, 1
  %2254 = mul <8 x i64> %2251, splat (i64 32)
  %2255 = add <8 x i64> %2253, %2254
  %2256 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2252, 0
  %2257 = insertvalue { <8 x ptr>, <8 x i64> } %2256, <8 x i64> %2255, 1
  %2258 = extractvalue { <8 x ptr>, <8 x i64> } %2257, 0
  %2259 = extractvalue { <8 x ptr>, <8 x i64> } %2257, 1
  %2260 = getelementptr i8, <8 x ptr> %2258, <8 x i64> %2259
  %2261 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2260, <8 x i1> %2123, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1990 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill284, align 64
  %2262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1990, 0
  %2263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1990, 1
  %2264 = mul <8 x i64> %2249, splat (i64 32)
  %2265 = add <8 x i64> %2263, %2264
  %2266 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2262, 0
  %2267 = insertvalue { <8 x ptr>, <8 x i64> } %2266, <8 x i64> %2265, 1
  %2268 = extractvalue { <8 x ptr>, <8 x i64> } %2267, 0
  %2269 = extractvalue { <8 x ptr>, <8 x i64> } %2267, 1
  %2270 = getelementptr i8, <8 x ptr> %2268, <8 x i64> %2269
  %2271 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2270, <8 x i1> %2123, <8 x float> zeroinitializer)
  %2272 = fmul <8 x float> %2261, %2271
  %2273 = load <8 x i64>, ptr %.slot314, align 64
  %2274 = select <8 x i1> %2123, <8 x i64> zeroinitializer, <8 x i64> %2273
  store <8 x i64> %2274, ptr %.slot314, align 64
  %2275 = load <8 x float>, ptr %.slot41, align 32
  %2276 = select <8 x i1> %2123, <8 x float> %2169, <8 x float> %2275
  store <8 x float> %2276, ptr %.slot41, align 32
  %2277 = load <8 x float>, ptr %.slot47, align 32
  %2278 = select <8 x i1> %2123, <8 x float> %2204, <8 x float> %2277
  store <8 x float> %2278, ptr %.slot47, align 32
  %2279 = load <8 x float>, ptr %.slot48, align 32
  %2280 = select <8 x i1> %2123, <8 x float> %2239, <8 x float> %2279
  store <8 x float> %2280, ptr %.slot48, align 32
  %2281 = load <8 x float>, ptr %.slot49, align 32
  %2282 = select <8 x i1> %2123, <8 x float> %2272, <8 x float> %2281
  store <8 x float> %2282, ptr %.slot49, align 32
  store <8 x i1> %2123, ptr %current.mask, align 1
  %2283 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2123)
  br i1 %2283, label %schedule.97, label %scheduler.loop

schedule.97:                                      ; preds = %schedule.98, %schedule.96, %scheduler.dispatch.route
  %2284 = load <8 x i1>, ptr %current.mask, align 1
  %2285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2284)
  %2286 = bitcast <8 x i1> %2284 to i8
  %2287 = call i8 @llvm.cttz.i8(i8 %2286, i1 false)
  %2288 = zext i8 %2287 to i32
  %2289 = select i1 %2285, i32 %2288, i32 0
  %.state1991 = load <8 x i64>, ptr %.slot314, align 64
  %2290 = icmp slt <8 x i64> %.state1991, splat (i64 16)
  %2291 = and <8 x i1> %2284, %2290
  %2292 = xor <8 x i1> %2290, splat (i1 true)
  %2293 = and <8 x i1> %2284, %2292
  %2294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2291)
  %2295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2293)
  %2296 = and i1 %2294, %2295
  br i1 %2296, label %varying.divergent1992, label %varying.coherent1993

schedule.98:                                      ; preds = %varying.coherent.true1998, %scheduler.dispatch.route
  %2297 = load <8 x i1>, ptr %current.mask, align 1
  %2298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2297)
  %2299 = bitcast <8 x i1> %2297 to i8
  %2300 = call i8 @llvm.cttz.i8(i8 %2299, i1 false)
  %2301 = zext i8 %2300 to i32
  %2302 = select i1 %2298, i32 %2301, i32 0
  %.spill.load2000 = load <8 x i64>, ptr %.spill308, align 64
  %2303 = mul <8 x i64> %.spill.load2000, splat (i64 16)
  %.state2001 = load <8 x i64>, ptr %.slot314, align 64
  %2304 = add <8 x i64> %2303, %.state2001
  %tile_snapshot.spill.load2002 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %2305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2002, 0
  %2306 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2002, 1
  %2307 = mul <8 x i64> %2304, splat (i64 32)
  %2308 = add <8 x i64> %2306, %2307
  %2309 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2305, 0
  %2310 = insertvalue { <8 x ptr>, <8 x i64> } %2309, <8 x i64> %2308, 1
  %2311 = extractvalue { <8 x ptr>, <8 x i64> } %2310, 0
  %2312 = extractvalue { <8 x ptr>, <8 x i64> } %2310, 1
  %2313 = getelementptr i8, <8 x ptr> %2311, <8 x i64> %2312
  %2314 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2313, <8 x i1> %2297, <8 x float> zeroinitializer)
  %.spill.load2003 = load <8 x i64>, ptr %.spill312, align 64
  %2315 = mul <8 x i64> %.spill.load2003, splat (i64 16)
  %.state2004 = load <8 x i64>, ptr %.slot314, align 64
  %2316 = add <8 x i64> %2315, %.state2004
  %tile_snapshot.spill.load2005 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %2317 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2005, 0
  %2318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2005, 1
  %2319 = mul <8 x i64> %2316, splat (i64 32)
  %2320 = add <8 x i64> %2318, %2319
  %2321 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2317, 0
  %2322 = insertvalue { <8 x ptr>, <8 x i64> } %2321, <8 x i64> %2320, 1
  %2323 = extractvalue { <8 x ptr>, <8 x i64> } %2322, 0
  %2324 = extractvalue { <8 x ptr>, <8 x i64> } %2322, 1
  %2325 = getelementptr i8, <8 x ptr> %2323, <8 x i64> %2324
  %2326 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2325, <8 x i1> %2297, <8 x float> zeroinitializer)
  %.state2006 = load <8 x i64>, ptr %.slot314, align 64
  %2327 = add <8 x i64> zeroinitializer, %.state2006
  %2328 = mul <8 x i64> %2327, splat (i64 48)
  %.spill.load2007 = load <8 x i64>, ptr %.spill307, align 64
  %2329 = add <8 x i64> %2328, %.spill.load2007
  %tile_snapshot.spill.load2008 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %2330 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2008, 0
  %2331 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2008, 1
  %2332 = mul <8 x i64> %2329, splat (i64 32)
  %2333 = add <8 x i64> %2331, %2332
  %2334 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2330, 0
  %2335 = insertvalue { <8 x ptr>, <8 x i64> } %2334, <8 x i64> %2333, 1
  %2336 = extractvalue { <8 x ptr>, <8 x i64> } %2335, 0
  %2337 = extractvalue { <8 x ptr>, <8 x i64> } %2335, 1
  %2338 = getelementptr i8, <8 x ptr> %2336, <8 x i64> %2337
  %2339 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2338, <8 x i1> %2297, <8 x float> zeroinitializer)
  %.spill.load2009 = load <8 x i64>, ptr %.spill310, align 64
  %2340 = add <8 x i64> %2328, %.spill.load2009
  %tile_snapshot.spill.load2010 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %2341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2010, 0
  %2342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2010, 1
  %2343 = mul <8 x i64> %2340, splat (i64 32)
  %2344 = add <8 x i64> %2342, %2343
  %2345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2341, 0
  %2346 = insertvalue { <8 x ptr>, <8 x i64> } %2345, <8 x i64> %2344, 1
  %2347 = extractvalue { <8 x ptr>, <8 x i64> } %2346, 0
  %2348 = extractvalue { <8 x ptr>, <8 x i64> } %2346, 1
  %2349 = getelementptr i8, <8 x ptr> %2347, <8 x i64> %2348
  %2350 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2349, <8 x i1> %2297, <8 x float> zeroinitializer)
  %2351 = fmul <8 x float> %2314, %2339
  %.state2011 = load <8 x float>, ptr %.slot41, align 32
  %2352 = fadd <8 x float> %.state2011, %2351
  %2353 = fmul <8 x float> %2314, %2350
  %.state2012 = load <8 x float>, ptr %.slot47, align 32
  %2354 = fadd <8 x float> %.state2012, %2353
  %2355 = fmul <8 x float> %2326, %2339
  %.state2013 = load <8 x float>, ptr %.slot48, align 32
  %2356 = fadd <8 x float> %.state2013, %2355
  %2357 = fmul <8 x float> %2326, %2350
  %.state2014 = load <8 x float>, ptr %.slot49, align 32
  %2358 = fadd <8 x float> %.state2014, %2357
  %.state2015 = load <8 x i64>, ptr %.slot314, align 64
  %2359 = add <8 x i64> %.state2015, splat (i64 1)
  %2360 = load <8 x i64>, ptr %.slot314, align 64
  %2361 = select <8 x i1> %2297, <8 x i64> %2359, <8 x i64> %2360
  store <8 x i64> %2361, ptr %.slot314, align 64
  %2362 = load <8 x float>, ptr %.slot41, align 32
  %2363 = select <8 x i1> %2297, <8 x float> %2352, <8 x float> %2362
  store <8 x float> %2363, ptr %.slot41, align 32
  %2364 = load <8 x float>, ptr %.slot47, align 32
  %2365 = select <8 x i1> %2297, <8 x float> %2354, <8 x float> %2364
  store <8 x float> %2365, ptr %.slot47, align 32
  %2366 = load <8 x float>, ptr %.slot48, align 32
  %2367 = select <8 x i1> %2297, <8 x float> %2356, <8 x float> %2366
  store <8 x float> %2367, ptr %.slot48, align 32
  %2368 = load <8 x float>, ptr %.slot49, align 32
  %2369 = select <8 x i1> %2297, <8 x float> %2358, <8 x float> %2368
  store <8 x float> %2369, ptr %.slot49, align 32
  store <8 x i1> %2297, ptr %current.mask, align 1
  %2370 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2297)
  br i1 %2370, label %schedule.97, label %scheduler.loop

schedule.99:                                      ; preds = %varying.coherent.false1999, %scheduler.dispatch.route
  %2371 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2018 = load i32, ptr %current.token, align 4
  %convergence.token.present2019 = icmp ne i32 %convergence.current.token2018, 0
  br i1 %convergence.token.present2019, label %convergence.cascade2016, label %convergence.cascade.exit2017

schedule.100:                                     ; preds = %varying.coherent.false1980, %scheduler.dispatch.route
  %2372 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2048 = load i32, ptr %current.token, align 4
  %convergence.token.present2049 = icmp ne i32 %convergence.current.token2048, 0
  br i1 %convergence.token.present2049, label %convergence.cascade2046, label %convergence.cascade.exit2047

schedule.101:                                     ; preds = %varying.coherent.false1970, %scheduler.dispatch.route
  %2373 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2066 = load i32, ptr %current.token, align 4
  %convergence.token.present2067 = icmp ne i32 %convergence.current.token2066, 0
  br i1 %convergence.token.present2067, label %convergence.cascade2064, label %convergence.cascade.exit2065

schedule.102:                                     ; preds = %schedule.103, %convergence.target.101.ready, %scheduler.dispatch.route
  %2374 = load <8 x i1>, ptr %current.mask, align 1
  %2375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2374)
  %2376 = bitcast <8 x i1> %2374 to i8
  %2377 = call i8 @llvm.cttz.i8(i8 %2376, i1 false)
  %2378 = zext i8 %2377 to i32
  %2379 = select i1 %2375, i32 %2378, i32 0
  %.state2081 = load <8 x i64>, ptr %.slot56, align 64
  %2380 = icmp slt <8 x i64> %.state2081, splat (i64 192)
  %2381 = and <8 x i1> %2374, %2380
  %2382 = xor <8 x i1> %2380, splat (i1 true)
  %2383 = and <8 x i1> %2374, %2382
  %2384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2381)
  %2385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2383)
  %2386 = and i1 %2384, %2385
  br i1 %2386, label %varying.divergent2082, label %varying.coherent2083

schedule.103:                                     ; preds = %varying.coherent.true2088, %scheduler.dispatch.route
  %2387 = load <8 x i1>, ptr %current.mask, align 1
  %2388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2387)
  %2389 = bitcast <8 x i1> %2387 to i8
  %2390 = call i8 @llvm.cttz.i8(i8 %2389, i1 false)
  %2391 = zext i8 %2390 to i32
  %2392 = select i1 %2388, i32 %2391, i32 0
  %tile_snapshot.spill.load2090 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %2393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2090, 0
  %2394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2090, 1
  %.state2091 = load <8 x i64>, ptr %.slot56, align 64
  %2395 = mul <8 x i64> %.state2091, splat (i64 32)
  %2396 = add <8 x i64> %2394, %2395
  %2397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2393, 0
  %2398 = insertvalue { <8 x ptr>, <8 x i64> } %2397, <8 x i64> %2396, 1
  %2399 = extractvalue { <8 x ptr>, <8 x i64> } %2398, 0
  %2400 = extractvalue { <8 x ptr>, <8 x i64> } %2398, 1
  %2401 = getelementptr i8, <8 x ptr> %2399, <8 x i64> %2400
  %2402 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2401, <8 x i1> %2387, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2092 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %2403 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2092, 0
  %2404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2092, 1
  %.state2093 = load <8 x i64>, ptr %.slot56, align 64
  %2405 = mul <8 x i64> %.state2093, splat (i64 32)
  %2406 = add <8 x i64> %2404, %2405
  %2407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2403, 0
  %2408 = insertvalue { <8 x ptr>, <8 x i64> } %2407, <8 x i64> %2406, 1
  %2409 = extractvalue { <8 x ptr>, <8 x i64> } %2408, 0
  %2410 = extractvalue { <8 x ptr>, <8 x i64> } %2408, 1
  %2411 = getelementptr i8, <8 x ptr> %2409, <8 x i64> %2410
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2402, <8 x ptr> align 1 %2411, <8 x i1> %2387)
  %.state2094 = load <8 x i64>, ptr %.slot56, align 64
  %2412 = add <8 x i64> %.state2094, splat (i64 1)
  %2413 = load <8 x i64>, ptr %.slot56, align 64
  %2414 = select <8 x i1> %2387, <8 x i64> %2412, <8 x i64> %2413
  store <8 x i64> %2414, ptr %.slot56, align 64
  store <8 x i1> %2387, ptr %current.mask, align 1
  %2415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2387)
  br i1 %2415, label %schedule.102, label %scheduler.loop

schedule.104:                                     ; preds = %varying.coherent.false2089, %scheduler.dispatch.route
  %2416 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2097 = load i32, ptr %current.token, align 4
  %convergence.token.present2098 = icmp ne i32 %convergence.current.token2097, 0
  br i1 %convergence.token.present2098, label %convergence.cascade2095, label %convergence.cascade.exit2096

schedule.105:                                     ; preds = %schedule.106, %convergence.target.104.ready, %scheduler.dispatch.route
  %2417 = load <8 x i1>, ptr %current.mask, align 1
  %2418 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2417)
  %2419 = bitcast <8 x i1> %2417 to i8
  %2420 = call i8 @llvm.cttz.i8(i8 %2419, i1 false)
  %2421 = zext i8 %2420 to i32
  %2422 = select i1 %2418, i32 %2421, i32 0
  %.state2112 = load <8 x i64>, ptr %.slot56, align 64
  %2423 = icmp slt <8 x i64> %.state2112, splat (i64 192)
  %2424 = and <8 x i1> %2417, %2423
  %2425 = xor <8 x i1> %2423, splat (i1 true)
  %2426 = and <8 x i1> %2417, %2425
  %2427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2424)
  %2428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2426)
  %2429 = and i1 %2427, %2428
  br i1 %2429, label %varying.divergent2113, label %varying.coherent2114

schedule.106:                                     ; preds = %varying.coherent.true2119, %scheduler.dispatch.route
  %2430 = load <8 x i1>, ptr %current.mask, align 1
  %2431 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2430)
  %2432 = bitcast <8 x i1> %2430 to i8
  %2433 = call i8 @llvm.cttz.i8(i8 %2432, i1 false)
  %2434 = zext i8 %2433 to i32
  %2435 = select i1 %2431, i32 %2434, i32 0
  %tile_snapshot.spill.load2121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %2436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2121, 0
  %2437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2121, 1
  %.state2122 = load <8 x i64>, ptr %.slot56, align 64
  %2438 = mul <8 x i64> %.state2122, splat (i64 32)
  %2439 = add <8 x i64> %2437, %2438
  %2440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2436, 0
  %2441 = insertvalue { <8 x ptr>, <8 x i64> } %2440, <8 x i64> %2439, 1
  %2442 = extractvalue { <8 x ptr>, <8 x i64> } %2441, 0
  %2443 = extractvalue { <8 x ptr>, <8 x i64> } %2441, 1
  %2444 = getelementptr i8, <8 x ptr> %2442, <8 x i64> %2443
  %2445 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2444, <8 x i1> %2430, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2123, 0
  %2447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2123, 1
  %.state2124 = load <8 x i64>, ptr %.slot56, align 64
  %2448 = mul <8 x i64> %.state2124, splat (i64 32)
  %2449 = add <8 x i64> %2447, %2448
  %2450 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2446, 0
  %2451 = insertvalue { <8 x ptr>, <8 x i64> } %2450, <8 x i64> %2449, 1
  %2452 = extractvalue { <8 x ptr>, <8 x i64> } %2451, 0
  %2453 = extractvalue { <8 x ptr>, <8 x i64> } %2451, 1
  %2454 = getelementptr i8, <8 x ptr> %2452, <8 x i64> %2453
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2445, <8 x ptr> align 1 %2454, <8 x i1> %2430)
  %.state2125 = load <8 x i64>, ptr %.slot56, align 64
  %2455 = add <8 x i64> %.state2125, splat (i64 1)
  %2456 = load <8 x i64>, ptr %.slot56, align 64
  %2457 = select <8 x i1> %2430, <8 x i64> %2455, <8 x i64> %2456
  store <8 x i64> %2457, ptr %.slot56, align 64
  store <8 x i1> %2430, ptr %current.mask, align 1
  %2458 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2430)
  br i1 %2458, label %schedule.105, label %scheduler.loop

schedule.107:                                     ; preds = %varying.coherent.false2120, %scheduler.dispatch.route
  %2459 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2128 = load i32, ptr %current.token, align 4
  %convergence.token.present2129 = icmp ne i32 %convergence.current.token2128, 0
  br i1 %convergence.token.present2129, label %convergence.cascade2126, label %convergence.cascade.exit2127

schedule.108:                                     ; preds = %varying.coherent.false413, %scheduler.dispatch.route
  %2460 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2154 = load i32, ptr %current.token, align 4
  %convergence.token.present2155 = icmp ne i32 %convergence.current.token2154, 0
  br i1 %convergence.token.present2155, label %convergence.cascade2152, label %convergence.cascade.exit2153

schedule.109:                                     ; preds = %convergence.target.112.ready, %convergence.target.108.ready, %scheduler.dispatch.route
  %2461 = load <8 x i1>, ptr %current.mask, align 1
  %2462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2461)
  %2463 = bitcast <8 x i1> %2461 to i8
  %2464 = call i8 @llvm.cttz.i8(i8 %2463, i1 false)
  %2465 = zext i8 %2464 to i32
  %2466 = select i1 %2462, i32 %2465, i32 0
  %.state2181 = load <8 x i64>, ptr %.slot, align 64
  %2467 = icmp slt <8 x i64> %.state2181, splat (i64 192)
  %2468 = and <8 x i1> %2461, %2467
  %2469 = xor <8 x i1> %2467, splat (i1 true)
  %2470 = and <8 x i1> %2461, %2469
  %2471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2468)
  %2472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2470)
  %2473 = and i1 %2471, %2472
  br i1 %2473, label %varying.divergent2182, label %varying.coherent2183

schedule.110:                                     ; preds = %varying.coherent.true2188, %scheduler.dispatch.route
  %2474 = load <8 x i1>, ptr %current.mask, align 1
  %2475 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2474)
  %2476 = bitcast <8 x i1> %2474 to i8
  %2477 = call i8 @llvm.cttz.i8(i8 %2476, i1 false)
  %2478 = zext i8 %2477 to i32
  %2479 = select i1 %2475, i32 %2478, i32 0
  %.state2190 = load <8 x i64>, ptr %.slot, align 64
  %2480 = select <8 x i1> %2474, <8 x i64> %.state2190, <8 x i64> zeroinitializer
  %2481 = select <8 x i1> %2474, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2482 = srem <8 x i64> %2480, %2481
  %.state2191 = load <8 x i64>, ptr %.slot, align 64
  %2483 = select <8 x i1> %2474, <8 x i64> %.state2191, <8 x i64> zeroinitializer
  %2484 = select <8 x i1> %2474, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2485 = sdiv <8 x i64> %2483, %2484
  %.spill.load2192 = load <8 x i64>, ptr %.spill, align 64
  %2486 = add <8 x i64> %.spill.load2192, zeroinitializer
  %2487 = add <8 x i64> zeroinitializer, %2486
  %.spill.load2193 = load <8 x i64>, ptr %.spill37, align 64
  %2488 = add <8 x i64> %.spill.load2193, zeroinitializer
  %2489 = mul <8 x i64> %2487, splat (i64 6)
  %2490 = add <8 x i64> %2489, %2488
  %.spill.load2194 = load <8 x i64>, ptr %.spill38, align 64
  %2491 = add <8 x i64> %.spill.load2194, %2485
  %2492 = mul <8 x i64> %2490, splat (i64 17)
  %2493 = add <8 x i64> %2492, %2491
  %2494 = icmp sge <8 x i64> %2491, zeroinitializer
  %2495 = and <8 x i1> splat (i1 true), %2494
  %2496 = icmp slt <8 x i64> %2491, splat (i64 17)
  %2497 = and <8 x i1> %2495, %2496
  %2498 = add <8 x i64> zeroinitializer, %2482
  %2499 = mul <8 x i64> %2493, splat (i64 48)
  %2500 = add <8 x i64> %2499, %2498
  %2501 = load <8 x i64>, ptr %.spill323, align 64
  %2502 = select <8 x i1> %2474, <8 x i64> %2500, <8 x i64> %2501
  store <8 x i64> %2502, ptr %.spill323, align 64
  %2503 = add <8 x i64> zeroinitializer, %2485
  %2504 = mul <8 x i64> %2503, splat (i64 48)
  %2505 = add <8 x i64> %2504, %2482
  %tile_snapshot.spill.load2195 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2195, 0
  %2507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2195, 1
  %2508 = mul <8 x i64> %2505, splat (i64 32)
  %2509 = add <8 x i64> %2507, %2508
  %2510 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2506, 0
  %2511 = insertvalue { <8 x ptr>, <8 x i64> } %2510, <8 x i64> %2509, 1
  %2512 = extractvalue { <8 x ptr>, <8 x i64> } %2511, 0
  %2513 = extractvalue { <8 x ptr>, <8 x i64> } %2511, 1
  %2514 = getelementptr i8, <8 x ptr> %2512, <8 x i64> %2513
  %2515 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2514, <8 x i1> %2474, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2196 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill321, align 64
  %2516 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2196, 0
  %2517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2196, 1
  %2518 = mul <8 x i64> %2503, splat (i64 32)
  %2519 = add <8 x i64> %2517, %2518
  %2520 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2516, 0
  %2521 = insertvalue { <8 x ptr>, <8 x i64> } %2520, <8 x i64> %2519, 1
  %2522 = extractvalue { <8 x ptr>, <8 x i64> } %2521, 0
  %2523 = extractvalue { <8 x ptr>, <8 x i64> } %2521, 1
  %2524 = getelementptr i8, <8 x ptr> %2522, <8 x i64> %2523
  %2525 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2524, <8 x i1> %2474, <8 x float> zeroinitializer)
  %2526 = fdiv <8 x float> %2515, %2525
  %2527 = load <8 x float>, ptr %.spill324, align 32
  %2528 = select <8 x i1> %2474, <8 x float> %2526, <8 x float> %2527
  store <8 x float> %2528, ptr %.spill324, align 32
  %2529 = and <8 x i1> %2474, %2497
  %2530 = xor <8 x i1> %2497, splat (i1 true)
  %2531 = and <8 x i1> %2474, %2530
  %2532 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2529)
  %2533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2531)
  %2534 = and i1 %2532, %2533
  br i1 %2534, label %varying.divergent2197, label %varying.coherent2198

schedule.111:                                     ; preds = %varying.coherent.true2203, %scheduler.dispatch.route
  %2535 = load <8 x i1>, ptr %current.mask, align 1
  %2536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2535)
  %2537 = bitcast <8 x i1> %2535 to i8
  %2538 = call i8 @llvm.cttz.i8(i8 %2537, i1 false)
  %2539 = zext i8 %2538 to i32
  %2540 = select i1 %2536, i32 %2539, i32 0
  %.spill.load2205 = load <8 x i64>, ptr %.spill323, align 64
  %.spill.load2206 = load <8 x float>, ptr %.spill324, align 32
  %2541 = extractvalue { ptr, i64 } %53, 0
  %2542 = mul <8 x i64> %.spill.load2205, splat (i64 4)
  %2543 = getelementptr i8, ptr %2541, <8 x i64> %2542
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load2206, <8 x ptr> align 1 %2543, <8 x i1> %2535)
  store <8 x i1> %2535, ptr %current.mask, align 1
  %2544 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2535)
  br i1 %2544, label %schedule.112, label %scheduler.loop

schedule.112:                                     ; preds = %schedule.111, %varying.coherent.false2204, %scheduler.dispatch.route
  %2545 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2209 = load i32, ptr %current.token, align 4
  %convergence.token.present2210 = icmp ne i32 %convergence.current.token2209, 0
  br i1 %convergence.token.present2210, label %convergence.cascade2207, label %convergence.cascade.exit2208

schedule.113:                                     ; preds = %varying.coherent.false2189, %scheduler.dispatch.route
  %2546 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2227 = load i32, ptr %current.token, align 4
  %convergence.token.present2228 = icmp ne i32 %convergence.current.token2227, 0
  br i1 %convergence.token.present2228, label %convergence.cascade2225, label %convergence.cascade.exit2226

varying.divergent:                                ; preds = %schedule.1
  %2547 = load i32, ptr %current.token, align 4
  %2548 = icmp ne i32 %2547, 0
  %2549 = sub i32 %2547, 1
  %2550 = select i1 %2548, i32 %2549, i32 0
  %2551 = load i8, ptr %frame.active, align 1
  %2552 = trunc i32 %2550 to i8
  %2553 = shl i8 1, %2552
  %2554 = and i8 %2551, %2553
  %2555 = icmp ne i8 %2554, 0
  %2556 = load <8 x i32>, ptr %frame.static.id, align 32
  %2557 = extractelement <8 x i32> %2556, i32 %2550
  %2558 = icmp eq i32 %2557, 0
  %2559 = and i1 %2555, %2558
  %2560 = and i1 %2548, %2559
  %2561 = xor i1 %2560, true
  %2562 = and i1 true, %2561
  %2563 = xor i8 %2551, -1
  %2564 = icmp ne i8 %2563, 0
  %2565 = xor i1 %2564, true
  %2566 = and i1 %2562, %2565
  br i1 %2566, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %168, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %2567 = call i8 @llvm.cttz.i8(i8 %2563, i1 false)
  %2568 = zext i8 %2567 to i32
  %2569 = select i1 %2564, i32 %2568, i32 0
  %2570 = trunc i32 %2569 to i8
  %2571 = shl i8 1, %2570
  %2572 = or i8 %2551, %2571
  %2573 = select i1 %2562, i8 %2572, i8 %2551
  store i8 %2573, ptr %frame.active, align 1
  %2574 = load <8 x i32>, ptr %frame.static.id, align 32
  %2575 = extractelement <8 x i32> %2574, i32 %2569
  %2576 = select i1 %2562, i32 0, i32 %2575
  %2577 = load <8 x i32>, ptr %frame.static.id, align 32
  %2578 = insertelement <8 x i32> %2577, i32 %2576, i32 %2569
  store <8 x i32> %2578, ptr %frame.static.id, align 32
  %2579 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2580 = extractelement <8 x i32> %2579, i32 %2569
  %2581 = select i1 %2562, i32 %2547, i32 %2580
  %2582 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2583 = insertelement <8 x i32> %2582, i32 %2581, i32 %2569
  store <8 x i32> %2583, ptr %frame.parent.token, align 32
  %2584 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2569
  %2585 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2569
  %2586 = load <8 x i1>, ptr %2584, align 1
  %2587 = load <8 x i1>, ptr %2585, align 1
  %2588 = select i1 %2562, <8 x i1> %158, <8 x i1> %2586
  store <8 x i1> %2588, ptr %2584, align 1
  %2589 = select i1 %2562, <8 x i1> zeroinitializer, <8 x i1> %2587
  store <8 x i1> %2589, ptr %2585, align 1
  %2590 = add i32 %2569, 1
  %2591 = select i1 %2560, i32 %2547, i32 %2590
  %2592 = select i1 true, i32 %2591, i32 %2547
  store i32 %2592, ptr %current.token, align 4
  %2593 = load i32, ptr %current.token, align 4
  %2594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %165)
  %2595 = load i32, ptr %ready.count, align 4
  %2596 = icmp uge i32 %2595, 8
  %2597 = and i1 %2594, %2596
  br i1 %2597, label %ready.overflow.trap335, label %ready.overflow.resume336

ready.overflow.trap335:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume336:                         ; preds = %convergence.overflow.resume
  %2598 = select i1 %2594, i32 %2595, i32 0
  %2599 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2598
  %2600 = load <8 x i1>, ptr %2599, align 1
  %2601 = select i1 %2594, <8 x i1> %165, <8 x i1> %2600
  store <8 x i1> %2601, ptr %2599, align 1
  %2602 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2598
  %2603 = load i32, ptr %2602, align 4
  %2604 = select i1 %2594, i32 2, i32 %2603
  store i32 %2604, ptr %2602, align 4
  %2605 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2598
  %2606 = load i32, ptr %2605, align 4
  %2607 = select i1 %2594, i32 %2593, i32 %2606
  store i32 %2607, ptr %2605, align 4
  %2608 = add i32 %2595, 1
  %2609 = select i1 %2594, i32 %2608, i32 %2595
  store i32 %2609, ptr %ready.count, align 4
  %2610 = load <8 x i1>, ptr %runnable.mask, align 1
  %2611 = or <8 x i1> %2610, %165
  store <8 x i1> %2611, ptr %runnable.mask, align 1
  store <8 x i1> %167, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %158, ptr %current.mask, align 1
  %2612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %158)
  br i1 %2612, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %158, ptr %current.mask, align 1
  %2613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %158)
  br i1 %2613, label %schedule.5, label %scheduler.loop

varying.divergent341:                             ; preds = %schedule.2
  %2614 = load i32, ptr %current.token, align 4
  %2615 = icmp ne i32 %2614, 0
  %2616 = sub i32 %2614, 1
  %2617 = select i1 %2615, i32 %2616, i32 0
  %2618 = load i8, ptr %frame.active, align 1
  %2619 = trunc i32 %2617 to i8
  %2620 = shl i8 1, %2619
  %2621 = and i8 %2618, %2620
  %2622 = icmp ne i8 %2621, 0
  %2623 = load <8 x i32>, ptr %frame.static.id, align 32
  %2624 = extractelement <8 x i32> %2623, i32 %2617
  %2625 = icmp eq i32 %2624, 1
  %2626 = and i1 %2622, %2625
  %2627 = and i1 %2615, %2626
  %2628 = xor i1 %2627, true
  %2629 = and i1 true, %2628
  %2630 = xor i8 %2618, -1
  %2631 = icmp ne i8 %2630, 0
  %2632 = xor i1 %2631, true
  %2633 = and i1 %2629, %2632
  br i1 %2633, label %convergence.overflow.trap343, label %convergence.overflow.resume344

varying.coherent342:                              ; preds = %schedule.2
  br i1 %203, label %varying.coherent.true347, label %varying.coherent.false348

convergence.overflow.trap343:                     ; preds = %varying.divergent341
  call void @llvm.trap()
  unreachable

convergence.overflow.resume344:                   ; preds = %varying.divergent341
  %2634 = call i8 @llvm.cttz.i8(i8 %2630, i1 false)
  %2635 = zext i8 %2634 to i32
  %2636 = select i1 %2631, i32 %2635, i32 0
  %2637 = trunc i32 %2636 to i8
  %2638 = shl i8 1, %2637
  %2639 = or i8 %2618, %2638
  %2640 = select i1 %2629, i8 %2639, i8 %2618
  store i8 %2640, ptr %frame.active, align 1
  %2641 = load <8 x i32>, ptr %frame.static.id, align 32
  %2642 = extractelement <8 x i32> %2641, i32 %2636
  %2643 = select i1 %2629, i32 1, i32 %2642
  %2644 = load <8 x i32>, ptr %frame.static.id, align 32
  %2645 = insertelement <8 x i32> %2644, i32 %2643, i32 %2636
  store <8 x i32> %2645, ptr %frame.static.id, align 32
  %2646 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2647 = extractelement <8 x i32> %2646, i32 %2636
  %2648 = select i1 %2629, i32 %2614, i32 %2647
  %2649 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2650 = insertelement <8 x i32> %2649, i32 %2648, i32 %2636
  store <8 x i32> %2650, ptr %frame.parent.token, align 32
  %2651 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2636
  %2652 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2636
  %2653 = load <8 x i1>, ptr %2651, align 1
  %2654 = load <8 x i1>, ptr %2652, align 1
  %2655 = select i1 %2629, <8 x i1> %171, <8 x i1> %2653
  store <8 x i1> %2655, ptr %2651, align 1
  %2656 = select i1 %2629, <8 x i1> zeroinitializer, <8 x i1> %2654
  store <8 x i1> %2656, ptr %2652, align 1
  %2657 = add i32 %2636, 1
  %2658 = select i1 %2627, i32 %2614, i32 %2657
  %2659 = select i1 true, i32 %2658, i32 %2614
  store i32 %2659, ptr %current.token, align 4
  %2660 = load <8 x float>, ptr %.slot41, align 32
  %2661 = select <8 x i1> %202, <8 x float> zeroinitializer, <8 x float> %2660
  store <8 x float> %2661, ptr %.slot41, align 32
  %2662 = load i32, ptr %current.token, align 4
  %2663 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %200)
  %2664 = load i32, ptr %ready.count, align 4
  %2665 = icmp uge i32 %2664, 8
  %2666 = and i1 %2663, %2665
  br i1 %2666, label %ready.overflow.trap345, label %ready.overflow.resume346

ready.overflow.trap345:                           ; preds = %convergence.overflow.resume344
  call void @llvm.trap()
  unreachable

ready.overflow.resume346:                         ; preds = %convergence.overflow.resume344
  %2667 = select i1 %2663, i32 %2664, i32 0
  %2668 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2667
  %2669 = load <8 x i1>, ptr %2668, align 1
  %2670 = select i1 %2663, <8 x i1> %200, <8 x i1> %2669
  store <8 x i1> %2670, ptr %2668, align 1
  %2671 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2667
  %2672 = load i32, ptr %2671, align 4
  %2673 = select i1 %2663, i32 3, i32 %2672
  store i32 %2673, ptr %2671, align 4
  %2674 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2667
  %2675 = load i32, ptr %2674, align 4
  %2676 = select i1 %2663, i32 %2662, i32 %2675
  store i32 %2676, ptr %2674, align 4
  %2677 = add i32 %2664, 1
  %2678 = select i1 %2663, i32 %2677, i32 %2664
  store i32 %2678, ptr %ready.count, align 4
  %2679 = load <8 x i1>, ptr %runnable.mask, align 1
  %2680 = or <8 x i1> %2679, %200
  store <8 x i1> %2680, ptr %runnable.mask, align 1
  store <8 x i1> %202, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true347:                         ; preds = %varying.coherent342
  store <8 x i1> %171, ptr %current.mask, align 1
  %2681 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %171)
  br i1 %2681, label %schedule.3, label %scheduler.loop

varying.coherent.false348:                        ; preds = %varying.coherent342
  %2682 = load <8 x float>, ptr %.slot41, align 32
  %2683 = select <8 x i1> %171, <8 x float> zeroinitializer, <8 x float> %2682
  store <8 x float> %2683, ptr %.slot41, align 32
  store <8 x i1> %171, ptr %current.mask, align 1
  %2684 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %171)
  br i1 %2684, label %schedule.4, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.flow = phi <8 x i1> [ %219, %schedule.4 ], [ %2727, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.4 ], [ %2728, %convergence.cascade ]
  %2685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %2686 = load i32, ptr %current.token, align 4
  %2687 = icmp ne i32 %2686, 0
  %2688 = and i1 %2685, %2687
  %2689 = sub i32 %2686, 1
  %2690 = select i1 %2688, i32 %2689, i32 0
  %2691 = load i8, ptr %frame.active, align 1
  %2692 = trunc i32 %2690 to i8
  %2693 = shl i8 1, %2692
  %2694 = and i8 %2691, %2693
  %2695 = icmp ne i8 %2694, 0
  %2696 = load <8 x i32>, ptr %frame.static.id, align 32
  %2697 = extractelement <8 x i32> %2696, i32 %2690
  %convergence.target.pointer = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %2697
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %2698 = icmp eq i32 %convergence.dynamic.target, 4
  %2699 = and i1 %2695, %2698
  %2700 = and i1 %2688, %2699
  %2701 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2690
  %2702 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2690
  %2703 = load <8 x i1>, ptr %2701, align 1
  %2704 = load <8 x i1>, ptr %2702, align 1
  %2705 = or <8 x i1> %2704, %convergence.cascade.flow
  %2706 = load <8 x i1>, ptr %live.mask, align 1
  %2707 = and <8 x i1> %2703, %2706
  %2708 = icmp eq <8 x i1> %2705, %2707
  %2709 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2708)
  %2710 = and i1 %2700, %2709
  %2711 = select i1 %2710, <8 x i1> zeroinitializer, <8 x i1> %2705
  %2712 = select i1 %2700, <8 x i1> %2711, <8 x i1> %2704
  store <8 x i1> %2712, ptr %2702, align 1
  %2713 = select i1 %2710, <8 x i1> zeroinitializer, <8 x i1> %2703
  store <8 x i1> %2713, ptr %2701, align 1
  %2714 = trunc i32 %2690 to i8
  %2715 = shl i8 1, %2714
  %2716 = xor i8 %2715, -1
  %2717 = and i8 %2691, %2716
  %2718 = select i1 %2710, i8 %2717, i8 %2691
  store i8 %2718, ptr %frame.active, align 1
  %.splatinsert350 = insertelement <8 x i1> poison, i1 %2700, i64 0
  %.splat351 = shufflevector <8 x i1> %.splatinsert350, <8 x i1> poison, <8 x i32> zeroinitializer
  %2719 = and <8 x i1> %convergence.cascade.flow, %.splat351
  %2720 = load <8 x i1>, ptr %runnable.mask, align 1
  %2721 = xor <8 x i1> %2719, splat (i1 true)
  %2722 = and <8 x i1> %2720, %2721
  store <8 x i1> %2722, ptr %runnable.mask, align 1
  %.splatinsert352 = insertelement <8 x i1> poison, i1 %2710, i64 0
  %.splat353 = shufflevector <8 x i1> %.splatinsert352, <8 x i1> poison, <8 x i32> zeroinitializer
  %2723 = select <8 x i1> %.splat353, <8 x i1> %2705, <8 x i1> zeroinitializer
  %2724 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2725 = extractelement <8 x i32> %2724, i32 %2690
  %2726 = select i1 %2710, i32 %2725, i32 %2686
  store i32 %2726, ptr %current.token, align 4
  %.splatinsert354 = insertelement <8 x i1> poison, i1 %2700, i64 0
  %.splat355 = shufflevector <8 x i1> %.splatinsert354, <8 x i1> poison, <8 x i32> zeroinitializer
  %2727 = select <8 x i1> %.splat355, <8 x i1> %2723, <8 x i1> %convergence.cascade.flow
  %2728 = add i32 %convergence.cascade.depth, 1
  %2729 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2727)
  %2730 = icmp ult i32 %2728, 8
  %2731 = and i1 %2729, %2730
  %2732 = and i1 %2700, %2731
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %2733 = and i1 %2732, %convergence.parent.present
  br i1 %2733, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.result = phi <8 x i1> [ %219, %schedule.4 ], [ %2727, %convergence.cascade ]
  %2734 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %2734, label %convergence.target.4.ready, label %scheduler.loop

convergence.target.4.ready:                       ; preds = %convergence.cascade.exit
  %2735 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %2736 = bitcast <8 x i1> %convergence.cascade.result to i8
  %2737 = call i8 @llvm.cttz.i8(i8 %2736, i1 false)
  %2738 = zext i8 %2737 to i32
  %2739 = select i1 %2735, i32 %2738, i32 0
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %2740 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2741 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state356 = load <8 x i64>, ptr %.slot, align 64
  %2742 = mul <8 x i64> %.state356, splat (i64 32)
  %2743 = add <8 x i64> %2741, %2742
  %2744 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2740, 0
  %2745 = insertvalue { <8 x ptr>, <8 x i64> } %2744, <8 x i64> %2743, 1
  %.state357 = load <8 x float>, ptr %.slot41, align 32
  %2746 = extractvalue { <8 x ptr>, <8 x i64> } %2745, 0
  %2747 = extractvalue { <8 x ptr>, <8 x i64> } %2745, 1
  %2748 = getelementptr i8, <8 x ptr> %2746, <8 x i64> %2747
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state357, <8 x ptr> align 1 %2748, <8 x i1> %convergence.cascade.result)
  %.state358 = load <8 x i64>, ptr %.slot, align 64
  %2749 = add <8 x i64> %.state358, splat (i64 1)
  %2750 = load <8 x i64>, ptr %.slot, align 64
  %2751 = select <8 x i1> %convergence.cascade.result, <8 x i64> %2749, <8 x i64> %2750
  store <8 x i64> %2751, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %2752 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %2752, label %schedule.1, label %scheduler.loop

convergence.cascade359:                           ; preds = %convergence.cascade359, %schedule.5
  %convergence.cascade.flow363 = phi <8 x i1> [ %220, %schedule.5 ], [ %2795, %convergence.cascade359 ]
  %convergence.cascade.depth364 = phi i32 [ 0, %schedule.5 ], [ %2796, %convergence.cascade359 ]
  %2753 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow363)
  %2754 = load i32, ptr %current.token, align 4
  %2755 = icmp ne i32 %2754, 0
  %2756 = and i1 %2753, %2755
  %2757 = sub i32 %2754, 1
  %2758 = select i1 %2756, i32 %2757, i32 0
  %2759 = load i8, ptr %frame.active, align 1
  %2760 = trunc i32 %2758 to i8
  %2761 = shl i8 1, %2760
  %2762 = and i8 %2759, %2761
  %2763 = icmp ne i8 %2762, 0
  %2764 = load <8 x i32>, ptr %frame.static.id, align 32
  %2765 = extractelement <8 x i32> %2764, i32 %2758
  %convergence.target.pointer365 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %2765
  %convergence.dynamic.target366 = load i32, ptr %convergence.target.pointer365, align 4
  %2766 = icmp eq i32 %convergence.dynamic.target366, 5
  %2767 = and i1 %2763, %2766
  %2768 = and i1 %2756, %2767
  %2769 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2758
  %2770 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2758
  %2771 = load <8 x i1>, ptr %2769, align 1
  %2772 = load <8 x i1>, ptr %2770, align 1
  %2773 = or <8 x i1> %2772, %convergence.cascade.flow363
  %2774 = load <8 x i1>, ptr %live.mask, align 1
  %2775 = and <8 x i1> %2771, %2774
  %2776 = icmp eq <8 x i1> %2773, %2775
  %2777 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2776)
  %2778 = and i1 %2768, %2777
  %2779 = select i1 %2778, <8 x i1> zeroinitializer, <8 x i1> %2773
  %2780 = select i1 %2768, <8 x i1> %2779, <8 x i1> %2772
  store <8 x i1> %2780, ptr %2770, align 1
  %2781 = select i1 %2778, <8 x i1> zeroinitializer, <8 x i1> %2771
  store <8 x i1> %2781, ptr %2769, align 1
  %2782 = trunc i32 %2758 to i8
  %2783 = shl i8 1, %2782
  %2784 = xor i8 %2783, -1
  %2785 = and i8 %2759, %2784
  %2786 = select i1 %2778, i8 %2785, i8 %2759
  store i8 %2786, ptr %frame.active, align 1
  %.splatinsert367 = insertelement <8 x i1> poison, i1 %2768, i64 0
  %.splat368 = shufflevector <8 x i1> %.splatinsert367, <8 x i1> poison, <8 x i32> zeroinitializer
  %2787 = and <8 x i1> %convergence.cascade.flow363, %.splat368
  %2788 = load <8 x i1>, ptr %runnable.mask, align 1
  %2789 = xor <8 x i1> %2787, splat (i1 true)
  %2790 = and <8 x i1> %2788, %2789
  store <8 x i1> %2790, ptr %runnable.mask, align 1
  %.splatinsert369 = insertelement <8 x i1> poison, i1 %2778, i64 0
  %.splat370 = shufflevector <8 x i1> %.splatinsert369, <8 x i1> poison, <8 x i32> zeroinitializer
  %2791 = select <8 x i1> %.splat370, <8 x i1> %2773, <8 x i1> zeroinitializer
  %2792 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2793 = extractelement <8 x i32> %2792, i32 %2758
  %2794 = select i1 %2778, i32 %2793, i32 %2754
  store i32 %2794, ptr %current.token, align 4
  %.splatinsert371 = insertelement <8 x i1> poison, i1 %2768, i64 0
  %.splat372 = shufflevector <8 x i1> %.splatinsert371, <8 x i1> poison, <8 x i32> zeroinitializer
  %2795 = select <8 x i1> %.splat372, <8 x i1> %2791, <8 x i1> %convergence.cascade.flow363
  %2796 = add i32 %convergence.cascade.depth364, 1
  %2797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2795)
  %2798 = icmp ult i32 %2796, 8
  %2799 = and i1 %2797, %2798
  %2800 = and i1 %2768, %2799
  %convergence.parent.token373 = load i32, ptr %current.token, align 4
  %convergence.parent.present374 = icmp ne i32 %convergence.parent.token373, 0
  %2801 = and i1 %2800, %convergence.parent.present374
  br i1 %2801, label %convergence.cascade359, label %convergence.cascade.exit360

convergence.cascade.exit360:                      ; preds = %convergence.cascade359, %schedule.5
  %convergence.cascade.result375 = phi <8 x i1> [ %220, %schedule.5 ], [ %2795, %convergence.cascade359 ]
  %2802 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result375)
  br i1 %2802, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit360
  %2803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result375)
  %2804 = bitcast <8 x i1> %convergence.cascade.result375 to i8
  %2805 = call i8 @llvm.cttz.i8(i8 %2804, i1 false)
  %2806 = zext i8 %2805 to i32
  %2807 = select i1 %2803, i32 %2806, i32 0
  %2808 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill42, align 64
  %2809 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2810 = extractvalue { <8 x ptr>, <8 x i64> } %2808, 0
  %2811 = select <8 x i1> %convergence.cascade.result375, <8 x ptr> %2809, <8 x ptr> %2810
  %2812 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %2813 = extractvalue { <8 x ptr>, <8 x i64> } %2808, 1
  %2814 = select <8 x i1> %convergence.cascade.result375, <8 x i64> %2812, <8 x i64> %2813
  %2815 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2811, 0
  %2816 = insertvalue { <8 x ptr>, <8 x i64> } %2815, <8 x i64> %2814, 1
  store { <8 x ptr>, <8 x i64> } %2816, ptr %tile_snapshot.spill42, align 64
  %2817 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %2818 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %2819 = extractvalue { <8 x ptr>, <8 x i64> } %2817, 0
  %2820 = select <8 x i1> %convergence.cascade.result375, <8 x ptr> %2818, <8 x ptr> %2819
  %2821 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %2822 = extractvalue { <8 x ptr>, <8 x i64> } %2817, 1
  %2823 = select <8 x i1> %convergence.cascade.result375, <8 x i64> %2821, <8 x i64> %2822
  %2824 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2820, 0
  %2825 = insertvalue { <8 x ptr>, <8 x i64> } %2824, <8 x i64> %2823, 1
  store { <8 x ptr>, <8 x i64> } %2825, ptr %tile_snapshot.spill43, align 64
  %2826 = load <8 x i64>, ptr %.slot, align 64
  %2827 = select <8 x i1> %convergence.cascade.result375, <8 x i64> zeroinitializer, <8 x i64> %2826
  store <8 x i64> %2827, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result375, ptr %current.mask, align 1
  %2828 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result375)
  br i1 %2828, label %schedule.6, label %scheduler.loop

varying.divergent377:                             ; preds = %schedule.6
  %2829 = load i32, ptr %current.token, align 4
  %2830 = icmp ne i32 %2829, 0
  %2831 = sub i32 %2829, 1
  %2832 = select i1 %2830, i32 %2831, i32 0
  %2833 = load i8, ptr %frame.active, align 1
  %2834 = trunc i32 %2832 to i8
  %2835 = shl i8 1, %2834
  %2836 = and i8 %2833, %2835
  %2837 = icmp ne i8 %2836, 0
  %2838 = load <8 x i32>, ptr %frame.static.id, align 32
  %2839 = extractelement <8 x i32> %2838, i32 %2832
  %2840 = icmp eq i32 %2839, 2
  %2841 = and i1 %2837, %2840
  %2842 = and i1 %2830, %2841
  %2843 = xor i1 %2842, true
  %2844 = and i1 true, %2843
  %2845 = xor i8 %2833, -1
  %2846 = icmp ne i8 %2845, 0
  %2847 = xor i1 %2846, true
  %2848 = and i1 %2844, %2847
  br i1 %2848, label %convergence.overflow.trap379, label %convergence.overflow.resume380

varying.coherent378:                              ; preds = %schedule.6
  br i1 %231, label %varying.coherent.true383, label %varying.coherent.false384

convergence.overflow.trap379:                     ; preds = %varying.divergent377
  call void @llvm.trap()
  unreachable

convergence.overflow.resume380:                   ; preds = %varying.divergent377
  %2849 = call i8 @llvm.cttz.i8(i8 %2845, i1 false)
  %2850 = zext i8 %2849 to i32
  %2851 = select i1 %2846, i32 %2850, i32 0
  %2852 = trunc i32 %2851 to i8
  %2853 = shl i8 1, %2852
  %2854 = or i8 %2833, %2853
  %2855 = select i1 %2844, i8 %2854, i8 %2833
  store i8 %2855, ptr %frame.active, align 1
  %2856 = load <8 x i32>, ptr %frame.static.id, align 32
  %2857 = extractelement <8 x i32> %2856, i32 %2851
  %2858 = select i1 %2844, i32 2, i32 %2857
  %2859 = load <8 x i32>, ptr %frame.static.id, align 32
  %2860 = insertelement <8 x i32> %2859, i32 %2858, i32 %2851
  store <8 x i32> %2860, ptr %frame.static.id, align 32
  %2861 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2862 = extractelement <8 x i32> %2861, i32 %2851
  %2863 = select i1 %2844, i32 %2829, i32 %2862
  %2864 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2865 = insertelement <8 x i32> %2864, i32 %2863, i32 %2851
  store <8 x i32> %2865, ptr %frame.parent.token, align 32
  %2866 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2851
  %2867 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2851
  %2868 = load <8 x i1>, ptr %2866, align 1
  %2869 = load <8 x i1>, ptr %2867, align 1
  %2870 = select i1 %2844, <8 x i1> %221, <8 x i1> %2868
  store <8 x i1> %2870, ptr %2866, align 1
  %2871 = select i1 %2844, <8 x i1> zeroinitializer, <8 x i1> %2869
  store <8 x i1> %2871, ptr %2867, align 1
  %2872 = add i32 %2851, 1
  %2873 = select i1 %2842, i32 %2829, i32 %2872
  %2874 = select i1 true, i32 %2873, i32 %2829
  store i32 %2874, ptr %current.token, align 4
  %2875 = load i32, ptr %current.token, align 4
  %2876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %2877 = load i32, ptr %ready.count, align 4
  %2878 = icmp uge i32 %2877, 8
  %2879 = and i1 %2876, %2878
  br i1 %2879, label %ready.overflow.trap381, label %ready.overflow.resume382

ready.overflow.trap381:                           ; preds = %convergence.overflow.resume380
  call void @llvm.trap()
  unreachable

ready.overflow.resume382:                         ; preds = %convergence.overflow.resume380
  %2880 = select i1 %2876, i32 %2877, i32 0
  %2881 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2880
  %2882 = load <8 x i1>, ptr %2881, align 1
  %2883 = select i1 %2876, <8 x i1> %228, <8 x i1> %2882
  store <8 x i1> %2883, ptr %2881, align 1
  %2884 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2880
  %2885 = load i32, ptr %2884, align 4
  %2886 = select i1 %2876, i32 7, i32 %2885
  store i32 %2886, ptr %2884, align 4
  %2887 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2880
  %2888 = load i32, ptr %2887, align 4
  %2889 = select i1 %2876, i32 %2875, i32 %2888
  store i32 %2889, ptr %2887, align 4
  %2890 = add i32 %2877, 1
  %2891 = select i1 %2876, i32 %2890, i32 %2877
  store i32 %2891, ptr %ready.count, align 4
  %2892 = load <8 x i1>, ptr %runnable.mask, align 1
  %2893 = or <8 x i1> %2892, %228
  store <8 x i1> %2893, ptr %runnable.mask, align 1
  store <8 x i1> %230, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true383:                         ; preds = %varying.coherent378
  store <8 x i1> %221, ptr %current.mask, align 1
  %2894 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  br i1 %2894, label %schedule.7, label %scheduler.loop

varying.coherent.false384:                        ; preds = %varying.coherent378
  store <8 x i1> %221, ptr %current.mask, align 1
  %2895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  br i1 %2895, label %schedule.8, label %scheduler.loop

convergence.cascade388:                           ; preds = %convergence.cascade388, %schedule.8
  %convergence.cascade.flow392 = phi <8 x i1> [ %253, %schedule.8 ], [ %2938, %convergence.cascade388 ]
  %convergence.cascade.depth393 = phi i32 [ 0, %schedule.8 ], [ %2939, %convergence.cascade388 ]
  %2896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow392)
  %2897 = load i32, ptr %current.token, align 4
  %2898 = icmp ne i32 %2897, 0
  %2899 = and i1 %2896, %2898
  %2900 = sub i32 %2897, 1
  %2901 = select i1 %2899, i32 %2900, i32 0
  %2902 = load i8, ptr %frame.active, align 1
  %2903 = trunc i32 %2901 to i8
  %2904 = shl i8 1, %2903
  %2905 = and i8 %2902, %2904
  %2906 = icmp ne i8 %2905, 0
  %2907 = load <8 x i32>, ptr %frame.static.id, align 32
  %2908 = extractelement <8 x i32> %2907, i32 %2901
  %convergence.target.pointer394 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %2908
  %convergence.dynamic.target395 = load i32, ptr %convergence.target.pointer394, align 4
  %2909 = icmp eq i32 %convergence.dynamic.target395, 8
  %2910 = and i1 %2906, %2909
  %2911 = and i1 %2899, %2910
  %2912 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2901
  %2913 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2901
  %2914 = load <8 x i1>, ptr %2912, align 1
  %2915 = load <8 x i1>, ptr %2913, align 1
  %2916 = or <8 x i1> %2915, %convergence.cascade.flow392
  %2917 = load <8 x i1>, ptr %live.mask, align 1
  %2918 = and <8 x i1> %2914, %2917
  %2919 = icmp eq <8 x i1> %2916, %2918
  %2920 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2919)
  %2921 = and i1 %2911, %2920
  %2922 = select i1 %2921, <8 x i1> zeroinitializer, <8 x i1> %2916
  %2923 = select i1 %2911, <8 x i1> %2922, <8 x i1> %2915
  store <8 x i1> %2923, ptr %2913, align 1
  %2924 = select i1 %2921, <8 x i1> zeroinitializer, <8 x i1> %2914
  store <8 x i1> %2924, ptr %2912, align 1
  %2925 = trunc i32 %2901 to i8
  %2926 = shl i8 1, %2925
  %2927 = xor i8 %2926, -1
  %2928 = and i8 %2902, %2927
  %2929 = select i1 %2921, i8 %2928, i8 %2902
  store i8 %2929, ptr %frame.active, align 1
  %.splatinsert396 = insertelement <8 x i1> poison, i1 %2911, i64 0
  %.splat397 = shufflevector <8 x i1> %.splatinsert396, <8 x i1> poison, <8 x i32> zeroinitializer
  %2930 = and <8 x i1> %convergence.cascade.flow392, %.splat397
  %2931 = load <8 x i1>, ptr %runnable.mask, align 1
  %2932 = xor <8 x i1> %2930, splat (i1 true)
  %2933 = and <8 x i1> %2931, %2932
  store <8 x i1> %2933, ptr %runnable.mask, align 1
  %.splatinsert398 = insertelement <8 x i1> poison, i1 %2921, i64 0
  %.splat399 = shufflevector <8 x i1> %.splatinsert398, <8 x i1> poison, <8 x i32> zeroinitializer
  %2934 = select <8 x i1> %.splat399, <8 x i1> %2916, <8 x i1> zeroinitializer
  %2935 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2936 = extractelement <8 x i32> %2935, i32 %2901
  %2937 = select i1 %2921, i32 %2936, i32 %2897
  store i32 %2937, ptr %current.token, align 4
  %.splatinsert400 = insertelement <8 x i1> poison, i1 %2911, i64 0
  %.splat401 = shufflevector <8 x i1> %.splatinsert400, <8 x i1> poison, <8 x i32> zeroinitializer
  %2938 = select <8 x i1> %.splat401, <8 x i1> %2934, <8 x i1> %convergence.cascade.flow392
  %2939 = add i32 %convergence.cascade.depth393, 1
  %2940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2938)
  %2941 = icmp ult i32 %2939, 8
  %2942 = and i1 %2940, %2941
  %2943 = and i1 %2911, %2942
  %convergence.parent.token402 = load i32, ptr %current.token, align 4
  %convergence.parent.present403 = icmp ne i32 %convergence.parent.token402, 0
  %2944 = and i1 %2943, %convergence.parent.present403
  br i1 %2944, label %convergence.cascade388, label %convergence.cascade.exit389

convergence.cascade.exit389:                      ; preds = %convergence.cascade388, %schedule.8
  %convergence.cascade.result404 = phi <8 x i1> [ %253, %schedule.8 ], [ %2938, %convergence.cascade388 ]
  %2945 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result404)
  br i1 %2945, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit389
  %2946 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result404)
  %2947 = bitcast <8 x i1> %convergence.cascade.result404 to i8
  %2948 = call i8 @llvm.cttz.i8(i8 %2947, i1 false)
  %2949 = zext i8 %2948 to i32
  %2950 = select i1 %2946, i32 %2949, i32 0
  %2951 = load <8 x i64>, ptr %.slot, align 64
  %2952 = select <8 x i1> %convergence.cascade.result404, <8 x i64> zeroinitializer, <8 x i64> %2951
  store <8 x i64> %2952, ptr %.slot, align 64
  %2953 = load <8 x float>, ptr %.slot41, align 32
  %2954 = select <8 x i1> %convergence.cascade.result404, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2953
  store <8 x float> %2954, ptr %.slot41, align 32
  %2955 = load <8 x float>, ptr %.slot47, align 32
  %2956 = select <8 x i1> %convergence.cascade.result404, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2955
  store <8 x float> %2956, ptr %.slot47, align 32
  %2957 = load <8 x float>, ptr %.slot48, align 32
  %2958 = select <8 x i1> %convergence.cascade.result404, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2957
  store <8 x float> %2958, ptr %.slot48, align 32
  %2959 = load <8 x float>, ptr %.slot49, align 32
  %2960 = select <8 x i1> %convergence.cascade.result404, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2959
  store <8 x float> %2960, ptr %.slot49, align 32
  %2961 = load <8 x float>, ptr %.slot50, align 32
  %2962 = select <8 x i1> %convergence.cascade.result404, <8 x float> zeroinitializer, <8 x float> %2961
  store <8 x float> %2962, ptr %.slot50, align 32
  %2963 = load <8 x float>, ptr %.slot51, align 32
  %2964 = select <8 x i1> %convergence.cascade.result404, <8 x float> zeroinitializer, <8 x float> %2963
  store <8 x float> %2964, ptr %.slot51, align 32
  %2965 = load <8 x float>, ptr %.slot52, align 32
  %2966 = select <8 x i1> %convergence.cascade.result404, <8 x float> zeroinitializer, <8 x float> %2965
  store <8 x float> %2966, ptr %.slot52, align 32
  %2967 = load <8 x float>, ptr %.slot53, align 32
  %2968 = select <8 x i1> %convergence.cascade.result404, <8 x float> zeroinitializer, <8 x float> %2967
  store <8 x float> %2968, ptr %.slot53, align 32
  store <8 x i1> %convergence.cascade.result404, ptr %current.mask, align 1
  %2969 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result404)
  br i1 %2969, label %schedule.9, label %scheduler.loop

varying.divergent406:                             ; preds = %schedule.9
  %2970 = load i32, ptr %current.token, align 4
  %2971 = icmp ne i32 %2970, 0
  %2972 = sub i32 %2970, 1
  %2973 = select i1 %2971, i32 %2972, i32 0
  %2974 = load i8, ptr %frame.active, align 1
  %2975 = trunc i32 %2973 to i8
  %2976 = shl i8 1, %2975
  %2977 = and i8 %2974, %2976
  %2978 = icmp ne i8 %2977, 0
  %2979 = load <8 x i32>, ptr %frame.static.id, align 32
  %2980 = extractelement <8 x i32> %2979, i32 %2973
  %2981 = icmp eq i32 %2980, 3
  %2982 = and i1 %2978, %2981
  %2983 = and i1 %2971, %2982
  %2984 = xor i1 %2983, true
  %2985 = and i1 true, %2984
  %2986 = xor i8 %2974, -1
  %2987 = icmp ne i8 %2986, 0
  %2988 = xor i1 %2987, true
  %2989 = and i1 %2985, %2988
  br i1 %2989, label %convergence.overflow.trap408, label %convergence.overflow.resume409

varying.coherent407:                              ; preds = %schedule.9
  br i1 %264, label %varying.coherent.true412, label %varying.coherent.false413

convergence.overflow.trap408:                     ; preds = %varying.divergent406
  call void @llvm.trap()
  unreachable

convergence.overflow.resume409:                   ; preds = %varying.divergent406
  %2990 = call i8 @llvm.cttz.i8(i8 %2986, i1 false)
  %2991 = zext i8 %2990 to i32
  %2992 = select i1 %2987, i32 %2991, i32 0
  %2993 = trunc i32 %2992 to i8
  %2994 = shl i8 1, %2993
  %2995 = or i8 %2974, %2994
  %2996 = select i1 %2985, i8 %2995, i8 %2974
  store i8 %2996, ptr %frame.active, align 1
  %2997 = load <8 x i32>, ptr %frame.static.id, align 32
  %2998 = extractelement <8 x i32> %2997, i32 %2992
  %2999 = select i1 %2985, i32 3, i32 %2998
  %3000 = load <8 x i32>, ptr %frame.static.id, align 32
  %3001 = insertelement <8 x i32> %3000, i32 %2999, i32 %2992
  store <8 x i32> %3001, ptr %frame.static.id, align 32
  %3002 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3003 = extractelement <8 x i32> %3002, i32 %2992
  %3004 = select i1 %2985, i32 %2970, i32 %3003
  %3005 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3006 = insertelement <8 x i32> %3005, i32 %3004, i32 %2992
  store <8 x i32> %3006, ptr %frame.parent.token, align 32
  %3007 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2992
  %3008 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2992
  %3009 = load <8 x i1>, ptr %3007, align 1
  %3010 = load <8 x i1>, ptr %3008, align 1
  %3011 = select i1 %2985, <8 x i1> %254, <8 x i1> %3009
  store <8 x i1> %3011, ptr %3007, align 1
  %3012 = select i1 %2985, <8 x i1> zeroinitializer, <8 x i1> %3010
  store <8 x i1> %3012, ptr %3008, align 1
  %3013 = add i32 %2992, 1
  %3014 = select i1 %2983, i32 %2970, i32 %3013
  %3015 = select i1 true, i32 %3014, i32 %2970
  store i32 %3015, ptr %current.token, align 4
  %3016 = load i32, ptr %current.token, align 4
  %3017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %261)
  %3018 = load i32, ptr %ready.count, align 4
  %3019 = icmp uge i32 %3018, 8
  %3020 = and i1 %3017, %3019
  br i1 %3020, label %ready.overflow.trap410, label %ready.overflow.resume411

ready.overflow.trap410:                           ; preds = %convergence.overflow.resume409
  call void @llvm.trap()
  unreachable

ready.overflow.resume411:                         ; preds = %convergence.overflow.resume409
  %3021 = select i1 %3017, i32 %3018, i32 0
  %3022 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3021
  %3023 = load <8 x i1>, ptr %3022, align 1
  %3024 = select i1 %3017, <8 x i1> %261, <8 x i1> %3023
  store <8 x i1> %3024, ptr %3022, align 1
  %3025 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3021
  %3026 = load i32, ptr %3025, align 4
  %3027 = select i1 %3017, i32 10, i32 %3026
  store i32 %3027, ptr %3025, align 4
  %3028 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3021
  %3029 = load i32, ptr %3028, align 4
  %3030 = select i1 %3017, i32 %3016, i32 %3029
  store i32 %3030, ptr %3028, align 4
  %3031 = add i32 %3018, 1
  %3032 = select i1 %3017, i32 %3031, i32 %3018
  store i32 %3032, ptr %ready.count, align 4
  %3033 = load <8 x i1>, ptr %runnable.mask, align 1
  %3034 = or <8 x i1> %3033, %261
  store <8 x i1> %3034, ptr %runnable.mask, align 1
  store <8 x i1> %263, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true412:                         ; preds = %varying.coherent407
  store <8 x i1> %254, ptr %current.mask, align 1
  %3035 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  br i1 %3035, label %schedule.10, label %scheduler.loop

varying.coherent.false413:                        ; preds = %varying.coherent407
  store <8 x i1> %254, ptr %current.mask, align 1
  %3036 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  br i1 %3036, label %schedule.108, label %scheduler.loop

varying.divergent416:                             ; preds = %schedule.11
  %3037 = load i32, ptr %current.token, align 4
  %3038 = icmp ne i32 %3037, 0
  %3039 = sub i32 %3037, 1
  %3040 = select i1 %3038, i32 %3039, i32 0
  %3041 = load i8, ptr %frame.active, align 1
  %3042 = trunc i32 %3040 to i8
  %3043 = shl i8 1, %3042
  %3044 = and i8 %3041, %3043
  %3045 = icmp ne i8 %3044, 0
  %3046 = load <8 x i32>, ptr %frame.static.id, align 32
  %3047 = extractelement <8 x i32> %3046, i32 %3040
  %3048 = icmp eq i32 %3047, 4
  %3049 = and i1 %3045, %3048
  %3050 = and i1 %3038, %3049
  %3051 = xor i1 %3050, true
  %3052 = and i1 true, %3051
  %3053 = xor i8 %3041, -1
  %3054 = icmp ne i8 %3053, 0
  %3055 = xor i1 %3054, true
  %3056 = and i1 %3052, %3055
  br i1 %3056, label %convergence.overflow.trap418, label %convergence.overflow.resume419

varying.coherent417:                              ; preds = %schedule.11
  br i1 %301, label %varying.coherent.true422, label %varying.coherent.false423

convergence.overflow.trap418:                     ; preds = %varying.divergent416
  call void @llvm.trap()
  unreachable

convergence.overflow.resume419:                   ; preds = %varying.divergent416
  %3057 = call i8 @llvm.cttz.i8(i8 %3053, i1 false)
  %3058 = zext i8 %3057 to i32
  %3059 = select i1 %3054, i32 %3058, i32 0
  %3060 = trunc i32 %3059 to i8
  %3061 = shl i8 1, %3060
  %3062 = or i8 %3041, %3061
  %3063 = select i1 %3052, i8 %3062, i8 %3041
  store i8 %3063, ptr %frame.active, align 1
  %3064 = load <8 x i32>, ptr %frame.static.id, align 32
  %3065 = extractelement <8 x i32> %3064, i32 %3059
  %3066 = select i1 %3052, i32 4, i32 %3065
  %3067 = load <8 x i32>, ptr %frame.static.id, align 32
  %3068 = insertelement <8 x i32> %3067, i32 %3066, i32 %3059
  store <8 x i32> %3068, ptr %frame.static.id, align 32
  %3069 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3070 = extractelement <8 x i32> %3069, i32 %3059
  %3071 = select i1 %3052, i32 %3037, i32 %3070
  %3072 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3073 = insertelement <8 x i32> %3072, i32 %3071, i32 %3059
  store <8 x i32> %3073, ptr %frame.parent.token, align 32
  %3074 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3059
  %3075 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3059
  %3076 = load <8 x i1>, ptr %3074, align 1
  %3077 = load <8 x i1>, ptr %3075, align 1
  %3078 = select i1 %3052, <8 x i1> %291, <8 x i1> %3076
  store <8 x i1> %3078, ptr %3074, align 1
  %3079 = select i1 %3052, <8 x i1> zeroinitializer, <8 x i1> %3077
  store <8 x i1> %3079, ptr %3075, align 1
  %3080 = add i32 %3059, 1
  %3081 = select i1 %3050, i32 %3037, i32 %3080
  %3082 = select i1 true, i32 %3081, i32 %3037
  store i32 %3082, ptr %current.token, align 4
  %3083 = load i32, ptr %current.token, align 4
  %3084 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %298)
  %3085 = load i32, ptr %ready.count, align 4
  %3086 = icmp uge i32 %3085, 8
  %3087 = and i1 %3084, %3086
  br i1 %3087, label %ready.overflow.trap420, label %ready.overflow.resume421

ready.overflow.trap420:                           ; preds = %convergence.overflow.resume419
  call void @llvm.trap()
  unreachable

ready.overflow.resume421:                         ; preds = %convergence.overflow.resume419
  %3088 = select i1 %3084, i32 %3085, i32 0
  %3089 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3088
  %3090 = load <8 x i1>, ptr %3089, align 1
  %3091 = select i1 %3084, <8 x i1> %298, <8 x i1> %3090
  store <8 x i1> %3091, ptr %3089, align 1
  %3092 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3088
  %3093 = load i32, ptr %3092, align 4
  %3094 = select i1 %3084, i32 12, i32 %3093
  store i32 %3094, ptr %3092, align 4
  %3095 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3088
  %3096 = load i32, ptr %3095, align 4
  %3097 = select i1 %3084, i32 %3083, i32 %3096
  store i32 %3097, ptr %3095, align 4
  %3098 = add i32 %3085, 1
  %3099 = select i1 %3084, i32 %3098, i32 %3085
  store i32 %3099, ptr %ready.count, align 4
  %3100 = load <8 x i1>, ptr %runnable.mask, align 1
  %3101 = or <8 x i1> %3100, %298
  store <8 x i1> %3101, ptr %runnable.mask, align 1
  store <8 x i1> %300, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true422:                         ; preds = %varying.coherent417
  store <8 x i1> %291, ptr %current.mask, align 1
  %3102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %291)
  br i1 %3102, label %schedule.12, label %scheduler.loop

varying.coherent.false423:                        ; preds = %varying.coherent417
  store <8 x i1> %291, ptr %current.mask, align 1
  %3103 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %291)
  br i1 %3103, label %schedule.15, label %scheduler.loop

varying.divergent429:                             ; preds = %schedule.12
  %3104 = load i32, ptr %current.token, align 4
  %3105 = icmp ne i32 %3104, 0
  %3106 = sub i32 %3104, 1
  %3107 = select i1 %3105, i32 %3106, i32 0
  %3108 = load i8, ptr %frame.active, align 1
  %3109 = trunc i32 %3107 to i8
  %3110 = shl i8 1, %3109
  %3111 = and i8 %3108, %3110
  %3112 = icmp ne i8 %3111, 0
  %3113 = load <8 x i32>, ptr %frame.static.id, align 32
  %3114 = extractelement <8 x i32> %3113, i32 %3107
  %3115 = icmp eq i32 %3114, 5
  %3116 = and i1 %3112, %3115
  %3117 = and i1 %3105, %3116
  %3118 = xor i1 %3117, true
  %3119 = and i1 true, %3118
  %3120 = xor i8 %3108, -1
  %3121 = icmp ne i8 %3120, 0
  %3122 = xor i1 %3121, true
  %3123 = and i1 %3119, %3122
  br i1 %3123, label %convergence.overflow.trap431, label %convergence.overflow.resume432

varying.coherent430:                              ; preds = %schedule.12
  br i1 %336, label %varying.coherent.true435, label %varying.coherent.false436

convergence.overflow.trap431:                     ; preds = %varying.divergent429
  call void @llvm.trap()
  unreachable

convergence.overflow.resume432:                   ; preds = %varying.divergent429
  %3124 = call i8 @llvm.cttz.i8(i8 %3120, i1 false)
  %3125 = zext i8 %3124 to i32
  %3126 = select i1 %3121, i32 %3125, i32 0
  %3127 = trunc i32 %3126 to i8
  %3128 = shl i8 1, %3127
  %3129 = or i8 %3108, %3128
  %3130 = select i1 %3119, i8 %3129, i8 %3108
  store i8 %3130, ptr %frame.active, align 1
  %3131 = load <8 x i32>, ptr %frame.static.id, align 32
  %3132 = extractelement <8 x i32> %3131, i32 %3126
  %3133 = select i1 %3119, i32 5, i32 %3132
  %3134 = load <8 x i32>, ptr %frame.static.id, align 32
  %3135 = insertelement <8 x i32> %3134, i32 %3133, i32 %3126
  store <8 x i32> %3135, ptr %frame.static.id, align 32
  %3136 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3137 = extractelement <8 x i32> %3136, i32 %3126
  %3138 = select i1 %3119, i32 %3104, i32 %3137
  %3139 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3140 = insertelement <8 x i32> %3139, i32 %3138, i32 %3126
  store <8 x i32> %3140, ptr %frame.parent.token, align 32
  %3141 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3126
  %3142 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3126
  %3143 = load <8 x i1>, ptr %3141, align 1
  %3144 = load <8 x i1>, ptr %3142, align 1
  %3145 = select i1 %3119, <8 x i1> %304, <8 x i1> %3143
  store <8 x i1> %3145, ptr %3141, align 1
  %3146 = select i1 %3119, <8 x i1> zeroinitializer, <8 x i1> %3144
  store <8 x i1> %3146, ptr %3142, align 1
  %3147 = add i32 %3126, 1
  %3148 = select i1 %3117, i32 %3104, i32 %3147
  %3149 = select i1 true, i32 %3148, i32 %3104
  store i32 %3149, ptr %current.token, align 4
  %3150 = load <8 x float>, ptr %.slot58, align 32
  %3151 = select <8 x i1> %335, <8 x float> zeroinitializer, <8 x float> %3150
  store <8 x float> %3151, ptr %.slot58, align 32
  %3152 = load i32, ptr %current.token, align 4
  %3153 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %333)
  %3154 = load i32, ptr %ready.count, align 4
  %3155 = icmp uge i32 %3154, 8
  %3156 = and i1 %3153, %3155
  br i1 %3156, label %ready.overflow.trap433, label %ready.overflow.resume434

ready.overflow.trap433:                           ; preds = %convergence.overflow.resume432
  call void @llvm.trap()
  unreachable

ready.overflow.resume434:                         ; preds = %convergence.overflow.resume432
  %3157 = select i1 %3153, i32 %3154, i32 0
  %3158 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3157
  %3159 = load <8 x i1>, ptr %3158, align 1
  %3160 = select i1 %3153, <8 x i1> %333, <8 x i1> %3159
  store <8 x i1> %3160, ptr %3158, align 1
  %3161 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3157
  %3162 = load i32, ptr %3161, align 4
  %3163 = select i1 %3153, i32 13, i32 %3162
  store i32 %3163, ptr %3161, align 4
  %3164 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3157
  %3165 = load i32, ptr %3164, align 4
  %3166 = select i1 %3153, i32 %3152, i32 %3165
  store i32 %3166, ptr %3164, align 4
  %3167 = add i32 %3154, 1
  %3168 = select i1 %3153, i32 %3167, i32 %3154
  store i32 %3168, ptr %ready.count, align 4
  %3169 = load <8 x i1>, ptr %runnable.mask, align 1
  %3170 = or <8 x i1> %3169, %333
  store <8 x i1> %3170, ptr %runnable.mask, align 1
  store <8 x i1> %335, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true435:                         ; preds = %varying.coherent430
  store <8 x i1> %304, ptr %current.mask, align 1
  %3171 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %304)
  br i1 %3171, label %schedule.13, label %scheduler.loop

varying.coherent.false436:                        ; preds = %varying.coherent430
  %3172 = load <8 x float>, ptr %.slot58, align 32
  %3173 = select <8 x i1> %304, <8 x float> zeroinitializer, <8 x float> %3172
  store <8 x float> %3173, ptr %.slot58, align 32
  store <8 x i1> %304, ptr %current.mask, align 1
  %3174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %304)
  br i1 %3174, label %schedule.14, label %scheduler.loop

convergence.cascade438:                           ; preds = %convergence.cascade438, %schedule.14
  %convergence.cascade.flow442 = phi <8 x i1> [ %352, %schedule.14 ], [ %3217, %convergence.cascade438 ]
  %convergence.cascade.depth443 = phi i32 [ 0, %schedule.14 ], [ %3218, %convergence.cascade438 ]
  %3175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow442)
  %3176 = load i32, ptr %current.token, align 4
  %3177 = icmp ne i32 %3176, 0
  %3178 = and i1 %3175, %3177
  %3179 = sub i32 %3176, 1
  %3180 = select i1 %3178, i32 %3179, i32 0
  %3181 = load i8, ptr %frame.active, align 1
  %3182 = trunc i32 %3180 to i8
  %3183 = shl i8 1, %3182
  %3184 = and i8 %3181, %3183
  %3185 = icmp ne i8 %3184, 0
  %3186 = load <8 x i32>, ptr %frame.static.id, align 32
  %3187 = extractelement <8 x i32> %3186, i32 %3180
  %convergence.target.pointer444 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3187
  %convergence.dynamic.target445 = load i32, ptr %convergence.target.pointer444, align 4
  %3188 = icmp eq i32 %convergence.dynamic.target445, 14
  %3189 = and i1 %3185, %3188
  %3190 = and i1 %3178, %3189
  %3191 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3180
  %3192 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3180
  %3193 = load <8 x i1>, ptr %3191, align 1
  %3194 = load <8 x i1>, ptr %3192, align 1
  %3195 = or <8 x i1> %3194, %convergence.cascade.flow442
  %3196 = load <8 x i1>, ptr %live.mask, align 1
  %3197 = and <8 x i1> %3193, %3196
  %3198 = icmp eq <8 x i1> %3195, %3197
  %3199 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3198)
  %3200 = and i1 %3190, %3199
  %3201 = select i1 %3200, <8 x i1> zeroinitializer, <8 x i1> %3195
  %3202 = select i1 %3190, <8 x i1> %3201, <8 x i1> %3194
  store <8 x i1> %3202, ptr %3192, align 1
  %3203 = select i1 %3200, <8 x i1> zeroinitializer, <8 x i1> %3193
  store <8 x i1> %3203, ptr %3191, align 1
  %3204 = trunc i32 %3180 to i8
  %3205 = shl i8 1, %3204
  %3206 = xor i8 %3205, -1
  %3207 = and i8 %3181, %3206
  %3208 = select i1 %3200, i8 %3207, i8 %3181
  store i8 %3208, ptr %frame.active, align 1
  %.splatinsert446 = insertelement <8 x i1> poison, i1 %3190, i64 0
  %.splat447 = shufflevector <8 x i1> %.splatinsert446, <8 x i1> poison, <8 x i32> zeroinitializer
  %3209 = and <8 x i1> %convergence.cascade.flow442, %.splat447
  %3210 = load <8 x i1>, ptr %runnable.mask, align 1
  %3211 = xor <8 x i1> %3209, splat (i1 true)
  %3212 = and <8 x i1> %3210, %3211
  store <8 x i1> %3212, ptr %runnable.mask, align 1
  %.splatinsert448 = insertelement <8 x i1> poison, i1 %3200, i64 0
  %.splat449 = shufflevector <8 x i1> %.splatinsert448, <8 x i1> poison, <8 x i32> zeroinitializer
  %3213 = select <8 x i1> %.splat449, <8 x i1> %3195, <8 x i1> zeroinitializer
  %3214 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3215 = extractelement <8 x i32> %3214, i32 %3180
  %3216 = select i1 %3200, i32 %3215, i32 %3176
  store i32 %3216, ptr %current.token, align 4
  %.splatinsert450 = insertelement <8 x i1> poison, i1 %3190, i64 0
  %.splat451 = shufflevector <8 x i1> %.splatinsert450, <8 x i1> poison, <8 x i32> zeroinitializer
  %3217 = select <8 x i1> %.splat451, <8 x i1> %3213, <8 x i1> %convergence.cascade.flow442
  %3218 = add i32 %convergence.cascade.depth443, 1
  %3219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3217)
  %3220 = icmp ult i32 %3218, 8
  %3221 = and i1 %3219, %3220
  %3222 = and i1 %3190, %3221
  %convergence.parent.token452 = load i32, ptr %current.token, align 4
  %convergence.parent.present453 = icmp ne i32 %convergence.parent.token452, 0
  %3223 = and i1 %3222, %convergence.parent.present453
  br i1 %3223, label %convergence.cascade438, label %convergence.cascade.exit439

convergence.cascade.exit439:                      ; preds = %convergence.cascade438, %schedule.14
  %convergence.cascade.result454 = phi <8 x i1> [ %352, %schedule.14 ], [ %3217, %convergence.cascade438 ]
  %3224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  br i1 %3224, label %convergence.target.14.ready, label %scheduler.loop

convergence.target.14.ready:                      ; preds = %convergence.cascade.exit439
  %3225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3226 = bitcast <8 x i1> %convergence.cascade.result454 to i8
  %3227 = call i8 @llvm.cttz.i8(i8 %3226, i1 false)
  %3228 = zext i8 %3227 to i32
  %3229 = select i1 %3225, i32 %3228, i32 0
  %tile_snapshot.spill.load455 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %3230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %3231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %.state456 = load <8 x i64>, ptr %.slot56, align 64
  %3232 = mul <8 x i64> %.state456, splat (i64 32)
  %3233 = add <8 x i64> %3231, %3232
  %3234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3230, 0
  %3235 = insertvalue { <8 x ptr>, <8 x i64> } %3234, <8 x i64> %3233, 1
  %.state457 = load <8 x float>, ptr %.slot58, align 32
  %3236 = extractvalue { <8 x ptr>, <8 x i64> } %3235, 0
  %3237 = extractvalue { <8 x ptr>, <8 x i64> } %3235, 1
  %3238 = getelementptr i8, <8 x ptr> %3236, <8 x i64> %3237
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state457, <8 x ptr> align 1 %3238, <8 x i1> %convergence.cascade.result454)
  %.state458 = load <8 x i64>, ptr %.slot56, align 64
  %3239 = add <8 x i64> %.state458, splat (i64 1)
  %3240 = load <8 x i64>, ptr %.slot56, align 64
  %3241 = select <8 x i1> %convergence.cascade.result454, <8 x i64> %3239, <8 x i64> %3240
  store <8 x i64> %3241, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result454, ptr %current.mask, align 1
  %3242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  br i1 %3242, label %schedule.11, label %scheduler.loop

convergence.cascade459:                           ; preds = %convergence.cascade459, %schedule.15
  %convergence.cascade.flow463 = phi <8 x i1> [ %353, %schedule.15 ], [ %3285, %convergence.cascade459 ]
  %convergence.cascade.depth464 = phi i32 [ 0, %schedule.15 ], [ %3286, %convergence.cascade459 ]
  %3243 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow463)
  %3244 = load i32, ptr %current.token, align 4
  %3245 = icmp ne i32 %3244, 0
  %3246 = and i1 %3243, %3245
  %3247 = sub i32 %3244, 1
  %3248 = select i1 %3246, i32 %3247, i32 0
  %3249 = load i8, ptr %frame.active, align 1
  %3250 = trunc i32 %3248 to i8
  %3251 = shl i8 1, %3250
  %3252 = and i8 %3249, %3251
  %3253 = icmp ne i8 %3252, 0
  %3254 = load <8 x i32>, ptr %frame.static.id, align 32
  %3255 = extractelement <8 x i32> %3254, i32 %3248
  %convergence.target.pointer465 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3255
  %convergence.dynamic.target466 = load i32, ptr %convergence.target.pointer465, align 4
  %3256 = icmp eq i32 %convergence.dynamic.target466, 15
  %3257 = and i1 %3253, %3256
  %3258 = and i1 %3246, %3257
  %3259 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3248
  %3260 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3248
  %3261 = load <8 x i1>, ptr %3259, align 1
  %3262 = load <8 x i1>, ptr %3260, align 1
  %3263 = or <8 x i1> %3262, %convergence.cascade.flow463
  %3264 = load <8 x i1>, ptr %live.mask, align 1
  %3265 = and <8 x i1> %3261, %3264
  %3266 = icmp eq <8 x i1> %3263, %3265
  %3267 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3266)
  %3268 = and i1 %3258, %3267
  %3269 = select i1 %3268, <8 x i1> zeroinitializer, <8 x i1> %3263
  %3270 = select i1 %3258, <8 x i1> %3269, <8 x i1> %3262
  store <8 x i1> %3270, ptr %3260, align 1
  %3271 = select i1 %3268, <8 x i1> zeroinitializer, <8 x i1> %3261
  store <8 x i1> %3271, ptr %3259, align 1
  %3272 = trunc i32 %3248 to i8
  %3273 = shl i8 1, %3272
  %3274 = xor i8 %3273, -1
  %3275 = and i8 %3249, %3274
  %3276 = select i1 %3268, i8 %3275, i8 %3249
  store i8 %3276, ptr %frame.active, align 1
  %.splatinsert467 = insertelement <8 x i1> poison, i1 %3258, i64 0
  %.splat468 = shufflevector <8 x i1> %.splatinsert467, <8 x i1> poison, <8 x i32> zeroinitializer
  %3277 = and <8 x i1> %convergence.cascade.flow463, %.splat468
  %3278 = load <8 x i1>, ptr %runnable.mask, align 1
  %3279 = xor <8 x i1> %3277, splat (i1 true)
  %3280 = and <8 x i1> %3278, %3279
  store <8 x i1> %3280, ptr %runnable.mask, align 1
  %.splatinsert469 = insertelement <8 x i1> poison, i1 %3268, i64 0
  %.splat470 = shufflevector <8 x i1> %.splatinsert469, <8 x i1> poison, <8 x i32> zeroinitializer
  %3281 = select <8 x i1> %.splat470, <8 x i1> %3263, <8 x i1> zeroinitializer
  %3282 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3283 = extractelement <8 x i32> %3282, i32 %3248
  %3284 = select i1 %3268, i32 %3283, i32 %3244
  store i32 %3284, ptr %current.token, align 4
  %.splatinsert471 = insertelement <8 x i1> poison, i1 %3258, i64 0
  %.splat472 = shufflevector <8 x i1> %.splatinsert471, <8 x i1> poison, <8 x i32> zeroinitializer
  %3285 = select <8 x i1> %.splat472, <8 x i1> %3281, <8 x i1> %convergence.cascade.flow463
  %3286 = add i32 %convergence.cascade.depth464, 1
  %3287 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3285)
  %3288 = icmp ult i32 %3286, 8
  %3289 = and i1 %3287, %3288
  %3290 = and i1 %3258, %3289
  %convergence.parent.token473 = load i32, ptr %current.token, align 4
  %convergence.parent.present474 = icmp ne i32 %convergence.parent.token473, 0
  %3291 = and i1 %3290, %convergence.parent.present474
  br i1 %3291, label %convergence.cascade459, label %convergence.cascade.exit460

convergence.cascade.exit460:                      ; preds = %convergence.cascade459, %schedule.15
  %convergence.cascade.result475 = phi <8 x i1> [ %353, %schedule.15 ], [ %3285, %convergence.cascade459 ]
  %3292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result475)
  br i1 %3292, label %convergence.target.15.ready, label %scheduler.loop

convergence.target.15.ready:                      ; preds = %convergence.cascade.exit460
  %3293 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result475)
  %3294 = bitcast <8 x i1> %convergence.cascade.result475 to i8
  %3295 = call i8 @llvm.cttz.i8(i8 %3294, i1 false)
  %3296 = zext i8 %3295 to i32
  %3297 = select i1 %3293, i32 %3296, i32 0
  %3298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %3299 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %3300 = extractvalue { <8 x ptr>, <8 x i64> } %3298, 0
  %3301 = select <8 x i1> %convergence.cascade.result475, <8 x ptr> %3299, <8 x ptr> %3300
  %3302 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %3303 = extractvalue { <8 x ptr>, <8 x i64> } %3298, 1
  %3304 = select <8 x i1> %convergence.cascade.result475, <8 x i64> %3302, <8 x i64> %3303
  %3305 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3301, 0
  %3306 = insertvalue { <8 x ptr>, <8 x i64> } %3305, <8 x i64> %3304, 1
  store { <8 x ptr>, <8 x i64> } %3306, ptr %tile_snapshot.spill59, align 64
  %3307 = load <8 x i64>, ptr %.slot56, align 64
  %3308 = select <8 x i1> %convergence.cascade.result475, <8 x i64> zeroinitializer, <8 x i64> %3307
  store <8 x i64> %3308, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result475, ptr %current.mask, align 1
  %3309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result475)
  br i1 %3309, label %schedule.16, label %scheduler.loop

varying.divergent477:                             ; preds = %schedule.16
  %3310 = load i32, ptr %current.token, align 4
  %3311 = icmp ne i32 %3310, 0
  %3312 = sub i32 %3310, 1
  %3313 = select i1 %3311, i32 %3312, i32 0
  %3314 = load i8, ptr %frame.active, align 1
  %3315 = trunc i32 %3313 to i8
  %3316 = shl i8 1, %3315
  %3317 = and i8 %3314, %3316
  %3318 = icmp ne i8 %3317, 0
  %3319 = load <8 x i32>, ptr %frame.static.id, align 32
  %3320 = extractelement <8 x i32> %3319, i32 %3313
  %3321 = icmp eq i32 %3320, 6
  %3322 = and i1 %3318, %3321
  %3323 = and i1 %3311, %3322
  %3324 = xor i1 %3323, true
  %3325 = and i1 true, %3324
  %3326 = xor i8 %3314, -1
  %3327 = icmp ne i8 %3326, 0
  %3328 = xor i1 %3327, true
  %3329 = and i1 %3325, %3328
  br i1 %3329, label %convergence.overflow.trap479, label %convergence.overflow.resume480

varying.coherent478:                              ; preds = %schedule.16
  br i1 %364, label %varying.coherent.true483, label %varying.coherent.false484

convergence.overflow.trap479:                     ; preds = %varying.divergent477
  call void @llvm.trap()
  unreachable

convergence.overflow.resume480:                   ; preds = %varying.divergent477
  %3330 = call i8 @llvm.cttz.i8(i8 %3326, i1 false)
  %3331 = zext i8 %3330 to i32
  %3332 = select i1 %3327, i32 %3331, i32 0
  %3333 = trunc i32 %3332 to i8
  %3334 = shl i8 1, %3333
  %3335 = or i8 %3314, %3334
  %3336 = select i1 %3325, i8 %3335, i8 %3314
  store i8 %3336, ptr %frame.active, align 1
  %3337 = load <8 x i32>, ptr %frame.static.id, align 32
  %3338 = extractelement <8 x i32> %3337, i32 %3332
  %3339 = select i1 %3325, i32 6, i32 %3338
  %3340 = load <8 x i32>, ptr %frame.static.id, align 32
  %3341 = insertelement <8 x i32> %3340, i32 %3339, i32 %3332
  store <8 x i32> %3341, ptr %frame.static.id, align 32
  %3342 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3343 = extractelement <8 x i32> %3342, i32 %3332
  %3344 = select i1 %3325, i32 %3310, i32 %3343
  %3345 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3346 = insertelement <8 x i32> %3345, i32 %3344, i32 %3332
  store <8 x i32> %3346, ptr %frame.parent.token, align 32
  %3347 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3332
  %3348 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3332
  %3349 = load <8 x i1>, ptr %3347, align 1
  %3350 = load <8 x i1>, ptr %3348, align 1
  %3351 = select i1 %3325, <8 x i1> %354, <8 x i1> %3349
  store <8 x i1> %3351, ptr %3347, align 1
  %3352 = select i1 %3325, <8 x i1> zeroinitializer, <8 x i1> %3350
  store <8 x i1> %3352, ptr %3348, align 1
  %3353 = add i32 %3332, 1
  %3354 = select i1 %3323, i32 %3310, i32 %3353
  %3355 = select i1 true, i32 %3354, i32 %3310
  store i32 %3355, ptr %current.token, align 4
  %3356 = load i32, ptr %current.token, align 4
  %3357 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %361)
  %3358 = load i32, ptr %ready.count, align 4
  %3359 = icmp uge i32 %3358, 8
  %3360 = and i1 %3357, %3359
  br i1 %3360, label %ready.overflow.trap481, label %ready.overflow.resume482

ready.overflow.trap481:                           ; preds = %convergence.overflow.resume480
  call void @llvm.trap()
  unreachable

ready.overflow.resume482:                         ; preds = %convergence.overflow.resume480
  %3361 = select i1 %3357, i32 %3358, i32 0
  %3362 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3361
  %3363 = load <8 x i1>, ptr %3362, align 1
  %3364 = select i1 %3357, <8 x i1> %361, <8 x i1> %3363
  store <8 x i1> %3364, ptr %3362, align 1
  %3365 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3361
  %3366 = load i32, ptr %3365, align 4
  %3367 = select i1 %3357, i32 17, i32 %3366
  store i32 %3367, ptr %3365, align 4
  %3368 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3361
  %3369 = load i32, ptr %3368, align 4
  %3370 = select i1 %3357, i32 %3356, i32 %3369
  store i32 %3370, ptr %3368, align 4
  %3371 = add i32 %3358, 1
  %3372 = select i1 %3357, i32 %3371, i32 %3358
  store i32 %3372, ptr %ready.count, align 4
  %3373 = load <8 x i1>, ptr %runnable.mask, align 1
  %3374 = or <8 x i1> %3373, %361
  store <8 x i1> %3374, ptr %runnable.mask, align 1
  store <8 x i1> %363, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true483:                         ; preds = %varying.coherent478
  store <8 x i1> %354, ptr %current.mask, align 1
  %3375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %354)
  br i1 %3375, label %schedule.17, label %scheduler.loop

varying.coherent.false484:                        ; preds = %varying.coherent478
  store <8 x i1> %354, ptr %current.mask, align 1
  %3376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %354)
  br i1 %3376, label %schedule.20, label %scheduler.loop

varying.divergent490:                             ; preds = %schedule.17
  %3377 = load i32, ptr %current.token, align 4
  %3378 = icmp ne i32 %3377, 0
  %3379 = sub i32 %3377, 1
  %3380 = select i1 %3378, i32 %3379, i32 0
  %3381 = load i8, ptr %frame.active, align 1
  %3382 = trunc i32 %3380 to i8
  %3383 = shl i8 1, %3382
  %3384 = and i8 %3381, %3383
  %3385 = icmp ne i8 %3384, 0
  %3386 = load <8 x i32>, ptr %frame.static.id, align 32
  %3387 = extractelement <8 x i32> %3386, i32 %3380
  %3388 = icmp eq i32 %3387, 7
  %3389 = and i1 %3385, %3388
  %3390 = and i1 %3378, %3389
  %3391 = xor i1 %3390, true
  %3392 = and i1 true, %3391
  %3393 = xor i8 %3381, -1
  %3394 = icmp ne i8 %3393, 0
  %3395 = xor i1 %3394, true
  %3396 = and i1 %3392, %3395
  br i1 %3396, label %convergence.overflow.trap492, label %convergence.overflow.resume493

varying.coherent491:                              ; preds = %schedule.17
  br i1 %399, label %varying.coherent.true496, label %varying.coherent.false497

convergence.overflow.trap492:                     ; preds = %varying.divergent490
  call void @llvm.trap()
  unreachable

convergence.overflow.resume493:                   ; preds = %varying.divergent490
  %3397 = call i8 @llvm.cttz.i8(i8 %3393, i1 false)
  %3398 = zext i8 %3397 to i32
  %3399 = select i1 %3394, i32 %3398, i32 0
  %3400 = trunc i32 %3399 to i8
  %3401 = shl i8 1, %3400
  %3402 = or i8 %3381, %3401
  %3403 = select i1 %3392, i8 %3402, i8 %3381
  store i8 %3403, ptr %frame.active, align 1
  %3404 = load <8 x i32>, ptr %frame.static.id, align 32
  %3405 = extractelement <8 x i32> %3404, i32 %3399
  %3406 = select i1 %3392, i32 7, i32 %3405
  %3407 = load <8 x i32>, ptr %frame.static.id, align 32
  %3408 = insertelement <8 x i32> %3407, i32 %3406, i32 %3399
  store <8 x i32> %3408, ptr %frame.static.id, align 32
  %3409 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3410 = extractelement <8 x i32> %3409, i32 %3399
  %3411 = select i1 %3392, i32 %3377, i32 %3410
  %3412 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3413 = insertelement <8 x i32> %3412, i32 %3411, i32 %3399
  store <8 x i32> %3413, ptr %frame.parent.token, align 32
  %3414 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3399
  %3415 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3399
  %3416 = load <8 x i1>, ptr %3414, align 1
  %3417 = load <8 x i1>, ptr %3415, align 1
  %3418 = select i1 %3392, <8 x i1> %367, <8 x i1> %3416
  store <8 x i1> %3418, ptr %3414, align 1
  %3419 = select i1 %3392, <8 x i1> zeroinitializer, <8 x i1> %3417
  store <8 x i1> %3419, ptr %3415, align 1
  %3420 = add i32 %3399, 1
  %3421 = select i1 %3390, i32 %3377, i32 %3420
  %3422 = select i1 true, i32 %3421, i32 %3377
  store i32 %3422, ptr %current.token, align 4
  %3423 = load <8 x float>, ptr %.slot58, align 32
  %3424 = select <8 x i1> %398, <8 x float> zeroinitializer, <8 x float> %3423
  store <8 x float> %3424, ptr %.slot58, align 32
  %3425 = load i32, ptr %current.token, align 4
  %3426 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %396)
  %3427 = load i32, ptr %ready.count, align 4
  %3428 = icmp uge i32 %3427, 8
  %3429 = and i1 %3426, %3428
  br i1 %3429, label %ready.overflow.trap494, label %ready.overflow.resume495

ready.overflow.trap494:                           ; preds = %convergence.overflow.resume493
  call void @llvm.trap()
  unreachable

ready.overflow.resume495:                         ; preds = %convergence.overflow.resume493
  %3430 = select i1 %3426, i32 %3427, i32 0
  %3431 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3430
  %3432 = load <8 x i1>, ptr %3431, align 1
  %3433 = select i1 %3426, <8 x i1> %396, <8 x i1> %3432
  store <8 x i1> %3433, ptr %3431, align 1
  %3434 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3430
  %3435 = load i32, ptr %3434, align 4
  %3436 = select i1 %3426, i32 18, i32 %3435
  store i32 %3436, ptr %3434, align 4
  %3437 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3430
  %3438 = load i32, ptr %3437, align 4
  %3439 = select i1 %3426, i32 %3425, i32 %3438
  store i32 %3439, ptr %3437, align 4
  %3440 = add i32 %3427, 1
  %3441 = select i1 %3426, i32 %3440, i32 %3427
  store i32 %3441, ptr %ready.count, align 4
  %3442 = load <8 x i1>, ptr %runnable.mask, align 1
  %3443 = or <8 x i1> %3442, %396
  store <8 x i1> %3443, ptr %runnable.mask, align 1
  store <8 x i1> %398, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true496:                         ; preds = %varying.coherent491
  store <8 x i1> %367, ptr %current.mask, align 1
  %3444 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %367)
  br i1 %3444, label %schedule.18, label %scheduler.loop

varying.coherent.false497:                        ; preds = %varying.coherent491
  %3445 = load <8 x float>, ptr %.slot58, align 32
  %3446 = select <8 x i1> %367, <8 x float> zeroinitializer, <8 x float> %3445
  store <8 x float> %3446, ptr %.slot58, align 32
  store <8 x i1> %367, ptr %current.mask, align 1
  %3447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %367)
  br i1 %3447, label %schedule.19, label %scheduler.loop

convergence.cascade499:                           ; preds = %convergence.cascade499, %schedule.19
  %convergence.cascade.flow503 = phi <8 x i1> [ %415, %schedule.19 ], [ %3490, %convergence.cascade499 ]
  %convergence.cascade.depth504 = phi i32 [ 0, %schedule.19 ], [ %3491, %convergence.cascade499 ]
  %3448 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow503)
  %3449 = load i32, ptr %current.token, align 4
  %3450 = icmp ne i32 %3449, 0
  %3451 = and i1 %3448, %3450
  %3452 = sub i32 %3449, 1
  %3453 = select i1 %3451, i32 %3452, i32 0
  %3454 = load i8, ptr %frame.active, align 1
  %3455 = trunc i32 %3453 to i8
  %3456 = shl i8 1, %3455
  %3457 = and i8 %3454, %3456
  %3458 = icmp ne i8 %3457, 0
  %3459 = load <8 x i32>, ptr %frame.static.id, align 32
  %3460 = extractelement <8 x i32> %3459, i32 %3453
  %convergence.target.pointer505 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3460
  %convergence.dynamic.target506 = load i32, ptr %convergence.target.pointer505, align 4
  %3461 = icmp eq i32 %convergence.dynamic.target506, 19
  %3462 = and i1 %3458, %3461
  %3463 = and i1 %3451, %3462
  %3464 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3453
  %3465 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3453
  %3466 = load <8 x i1>, ptr %3464, align 1
  %3467 = load <8 x i1>, ptr %3465, align 1
  %3468 = or <8 x i1> %3467, %convergence.cascade.flow503
  %3469 = load <8 x i1>, ptr %live.mask, align 1
  %3470 = and <8 x i1> %3466, %3469
  %3471 = icmp eq <8 x i1> %3468, %3470
  %3472 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3471)
  %3473 = and i1 %3463, %3472
  %3474 = select i1 %3473, <8 x i1> zeroinitializer, <8 x i1> %3468
  %3475 = select i1 %3463, <8 x i1> %3474, <8 x i1> %3467
  store <8 x i1> %3475, ptr %3465, align 1
  %3476 = select i1 %3473, <8 x i1> zeroinitializer, <8 x i1> %3466
  store <8 x i1> %3476, ptr %3464, align 1
  %3477 = trunc i32 %3453 to i8
  %3478 = shl i8 1, %3477
  %3479 = xor i8 %3478, -1
  %3480 = and i8 %3454, %3479
  %3481 = select i1 %3473, i8 %3480, i8 %3454
  store i8 %3481, ptr %frame.active, align 1
  %.splatinsert507 = insertelement <8 x i1> poison, i1 %3463, i64 0
  %.splat508 = shufflevector <8 x i1> %.splatinsert507, <8 x i1> poison, <8 x i32> zeroinitializer
  %3482 = and <8 x i1> %convergence.cascade.flow503, %.splat508
  %3483 = load <8 x i1>, ptr %runnable.mask, align 1
  %3484 = xor <8 x i1> %3482, splat (i1 true)
  %3485 = and <8 x i1> %3483, %3484
  store <8 x i1> %3485, ptr %runnable.mask, align 1
  %.splatinsert509 = insertelement <8 x i1> poison, i1 %3473, i64 0
  %.splat510 = shufflevector <8 x i1> %.splatinsert509, <8 x i1> poison, <8 x i32> zeroinitializer
  %3486 = select <8 x i1> %.splat510, <8 x i1> %3468, <8 x i1> zeroinitializer
  %3487 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3488 = extractelement <8 x i32> %3487, i32 %3453
  %3489 = select i1 %3473, i32 %3488, i32 %3449
  store i32 %3489, ptr %current.token, align 4
  %.splatinsert511 = insertelement <8 x i1> poison, i1 %3463, i64 0
  %.splat512 = shufflevector <8 x i1> %.splatinsert511, <8 x i1> poison, <8 x i32> zeroinitializer
  %3490 = select <8 x i1> %.splat512, <8 x i1> %3486, <8 x i1> %convergence.cascade.flow503
  %3491 = add i32 %convergence.cascade.depth504, 1
  %3492 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3490)
  %3493 = icmp ult i32 %3491, 8
  %3494 = and i1 %3492, %3493
  %3495 = and i1 %3463, %3494
  %convergence.parent.token513 = load i32, ptr %current.token, align 4
  %convergence.parent.present514 = icmp ne i32 %convergence.parent.token513, 0
  %3496 = and i1 %3495, %convergence.parent.present514
  br i1 %3496, label %convergence.cascade499, label %convergence.cascade.exit500

convergence.cascade.exit500:                      ; preds = %convergence.cascade499, %schedule.19
  %convergence.cascade.result515 = phi <8 x i1> [ %415, %schedule.19 ], [ %3490, %convergence.cascade499 ]
  %3497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result515)
  br i1 %3497, label %convergence.target.19.ready, label %scheduler.loop

convergence.target.19.ready:                      ; preds = %convergence.cascade.exit500
  %3498 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result515)
  %3499 = bitcast <8 x i1> %convergence.cascade.result515 to i8
  %3500 = call i8 @llvm.cttz.i8(i8 %3499, i1 false)
  %3501 = zext i8 %3500 to i32
  %3502 = select i1 %3498, i32 %3501, i32 0
  %tile_snapshot.spill.load516 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill59, align 64
  %3503 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load516, 0
  %3504 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load516, 1
  %.state517 = load <8 x i64>, ptr %.slot56, align 64
  %3505 = mul <8 x i64> %.state517, splat (i64 32)
  %3506 = add <8 x i64> %3504, %3505
  %3507 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3503, 0
  %3508 = insertvalue { <8 x ptr>, <8 x i64> } %3507, <8 x i64> %3506, 1
  %.state518 = load <8 x float>, ptr %.slot58, align 32
  %3509 = extractvalue { <8 x ptr>, <8 x i64> } %3508, 0
  %3510 = extractvalue { <8 x ptr>, <8 x i64> } %3508, 1
  %3511 = getelementptr i8, <8 x ptr> %3509, <8 x i64> %3510
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state518, <8 x ptr> align 1 %3511, <8 x i1> %convergence.cascade.result515)
  %.state519 = load <8 x i64>, ptr %.slot56, align 64
  %3512 = add <8 x i64> %.state519, splat (i64 1)
  %3513 = load <8 x i64>, ptr %.slot56, align 64
  %3514 = select <8 x i1> %convergence.cascade.result515, <8 x i64> %3512, <8 x i64> %3513
  store <8 x i64> %3514, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result515, ptr %current.mask, align 1
  %3515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result515)
  br i1 %3515, label %schedule.16, label %scheduler.loop

convergence.cascade520:                           ; preds = %convergence.cascade520, %schedule.20
  %convergence.cascade.flow524 = phi <8 x i1> [ %416, %schedule.20 ], [ %3558, %convergence.cascade520 ]
  %convergence.cascade.depth525 = phi i32 [ 0, %schedule.20 ], [ %3559, %convergence.cascade520 ]
  %3516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow524)
  %3517 = load i32, ptr %current.token, align 4
  %3518 = icmp ne i32 %3517, 0
  %3519 = and i1 %3516, %3518
  %3520 = sub i32 %3517, 1
  %3521 = select i1 %3519, i32 %3520, i32 0
  %3522 = load i8, ptr %frame.active, align 1
  %3523 = trunc i32 %3521 to i8
  %3524 = shl i8 1, %3523
  %3525 = and i8 %3522, %3524
  %3526 = icmp ne i8 %3525, 0
  %3527 = load <8 x i32>, ptr %frame.static.id, align 32
  %3528 = extractelement <8 x i32> %3527, i32 %3521
  %convergence.target.pointer526 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3528
  %convergence.dynamic.target527 = load i32, ptr %convergence.target.pointer526, align 4
  %3529 = icmp eq i32 %convergence.dynamic.target527, 20
  %3530 = and i1 %3526, %3529
  %3531 = and i1 %3519, %3530
  %3532 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3521
  %3533 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3521
  %3534 = load <8 x i1>, ptr %3532, align 1
  %3535 = load <8 x i1>, ptr %3533, align 1
  %3536 = or <8 x i1> %3535, %convergence.cascade.flow524
  %3537 = load <8 x i1>, ptr %live.mask, align 1
  %3538 = and <8 x i1> %3534, %3537
  %3539 = icmp eq <8 x i1> %3536, %3538
  %3540 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3539)
  %3541 = and i1 %3531, %3540
  %3542 = select i1 %3541, <8 x i1> zeroinitializer, <8 x i1> %3536
  %3543 = select i1 %3531, <8 x i1> %3542, <8 x i1> %3535
  store <8 x i1> %3543, ptr %3533, align 1
  %3544 = select i1 %3541, <8 x i1> zeroinitializer, <8 x i1> %3534
  store <8 x i1> %3544, ptr %3532, align 1
  %3545 = trunc i32 %3521 to i8
  %3546 = shl i8 1, %3545
  %3547 = xor i8 %3546, -1
  %3548 = and i8 %3522, %3547
  %3549 = select i1 %3541, i8 %3548, i8 %3522
  store i8 %3549, ptr %frame.active, align 1
  %.splatinsert528 = insertelement <8 x i1> poison, i1 %3531, i64 0
  %.splat529 = shufflevector <8 x i1> %.splatinsert528, <8 x i1> poison, <8 x i32> zeroinitializer
  %3550 = and <8 x i1> %convergence.cascade.flow524, %.splat529
  %3551 = load <8 x i1>, ptr %runnable.mask, align 1
  %3552 = xor <8 x i1> %3550, splat (i1 true)
  %3553 = and <8 x i1> %3551, %3552
  store <8 x i1> %3553, ptr %runnable.mask, align 1
  %.splatinsert530 = insertelement <8 x i1> poison, i1 %3541, i64 0
  %.splat531 = shufflevector <8 x i1> %.splatinsert530, <8 x i1> poison, <8 x i32> zeroinitializer
  %3554 = select <8 x i1> %.splat531, <8 x i1> %3536, <8 x i1> zeroinitializer
  %3555 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3556 = extractelement <8 x i32> %3555, i32 %3521
  %3557 = select i1 %3541, i32 %3556, i32 %3517
  store i32 %3557, ptr %current.token, align 4
  %.splatinsert532 = insertelement <8 x i1> poison, i1 %3531, i64 0
  %.splat533 = shufflevector <8 x i1> %.splatinsert532, <8 x i1> poison, <8 x i32> zeroinitializer
  %3558 = select <8 x i1> %.splat533, <8 x i1> %3554, <8 x i1> %convergence.cascade.flow524
  %3559 = add i32 %convergence.cascade.depth525, 1
  %3560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3558)
  %3561 = icmp ult i32 %3559, 8
  %3562 = and i1 %3560, %3561
  %3563 = and i1 %3531, %3562
  %convergence.parent.token534 = load i32, ptr %current.token, align 4
  %convergence.parent.present535 = icmp ne i32 %convergence.parent.token534, 0
  %3564 = and i1 %3563, %convergence.parent.present535
  br i1 %3564, label %convergence.cascade520, label %convergence.cascade.exit521

convergence.cascade.exit521:                      ; preds = %convergence.cascade520, %schedule.20
  %convergence.cascade.result536 = phi <8 x i1> [ %416, %schedule.20 ], [ %3558, %convergence.cascade520 ]
  %3565 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  br i1 %3565, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit521
  %3566 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  %3567 = bitcast <8 x i1> %convergence.cascade.result536 to i8
  %3568 = call i8 @llvm.cttz.i8(i8 %3567, i1 false)
  %3569 = zext i8 %3568 to i32
  %3570 = select i1 %3566, i32 %3569, i32 0
  %3571 = load <8 x i64>, ptr %.slot56, align 64
  %3572 = select <8 x i1> %convergence.cascade.result536, <8 x i64> zeroinitializer, <8 x i64> %3571
  store <8 x i64> %3572, ptr %.slot56, align 64
  %3573 = load <8 x float>, ptr %.slot58, align 32
  %3574 = select <8 x i1> %convergence.cascade.result536, <8 x float> zeroinitializer, <8 x float> %3573
  store <8 x float> %3574, ptr %.slot58, align 32
  %3575 = load <8 x float>, ptr %.slot65, align 32
  %3576 = select <8 x i1> %convergence.cascade.result536, <8 x float> zeroinitializer, <8 x float> %3575
  store <8 x float> %3576, ptr %.slot65, align 32
  %3577 = load <8 x float>, ptr %.slot66, align 32
  %3578 = select <8 x i1> %convergence.cascade.result536, <8 x float> zeroinitializer, <8 x float> %3577
  store <8 x float> %3578, ptr %.slot66, align 32
  %3579 = load <8 x float>, ptr %.slot67, align 32
  %3580 = select <8 x i1> %convergence.cascade.result536, <8 x float> zeroinitializer, <8 x float> %3579
  store <8 x float> %3580, ptr %.slot67, align 32
  store <8 x i1> %convergence.cascade.result536, ptr %current.mask, align 1
  %3581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result536)
  br i1 %3581, label %schedule.21, label %scheduler.loop

varying.divergent538:                             ; preds = %schedule.21
  %3582 = load i32, ptr %current.token, align 4
  %3583 = icmp ne i32 %3582, 0
  %3584 = sub i32 %3582, 1
  %3585 = select i1 %3583, i32 %3584, i32 0
  %3586 = load i8, ptr %frame.active, align 1
  %3587 = trunc i32 %3585 to i8
  %3588 = shl i8 1, %3587
  %3589 = and i8 %3586, %3588
  %3590 = icmp ne i8 %3589, 0
  %3591 = load <8 x i32>, ptr %frame.static.id, align 32
  %3592 = extractelement <8 x i32> %3591, i32 %3585
  %3593 = icmp eq i32 %3592, 8
  %3594 = and i1 %3590, %3593
  %3595 = and i1 %3583, %3594
  %3596 = xor i1 %3595, true
  %3597 = and i1 true, %3596
  %3598 = xor i8 %3586, -1
  %3599 = icmp ne i8 %3598, 0
  %3600 = xor i1 %3599, true
  %3601 = and i1 %3597, %3600
  br i1 %3601, label %convergence.overflow.trap540, label %convergence.overflow.resume541

varying.coherent539:                              ; preds = %schedule.21
  br i1 %427, label %varying.coherent.true544, label %varying.coherent.false545

convergence.overflow.trap540:                     ; preds = %varying.divergent538
  call void @llvm.trap()
  unreachable

convergence.overflow.resume541:                   ; preds = %varying.divergent538
  %3602 = call i8 @llvm.cttz.i8(i8 %3598, i1 false)
  %3603 = zext i8 %3602 to i32
  %3604 = select i1 %3599, i32 %3603, i32 0
  %3605 = trunc i32 %3604 to i8
  %3606 = shl i8 1, %3605
  %3607 = or i8 %3586, %3606
  %3608 = select i1 %3597, i8 %3607, i8 %3586
  store i8 %3608, ptr %frame.active, align 1
  %3609 = load <8 x i32>, ptr %frame.static.id, align 32
  %3610 = extractelement <8 x i32> %3609, i32 %3604
  %3611 = select i1 %3597, i32 8, i32 %3610
  %3612 = load <8 x i32>, ptr %frame.static.id, align 32
  %3613 = insertelement <8 x i32> %3612, i32 %3611, i32 %3604
  store <8 x i32> %3613, ptr %frame.static.id, align 32
  %3614 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3615 = extractelement <8 x i32> %3614, i32 %3604
  %3616 = select i1 %3597, i32 %3582, i32 %3615
  %3617 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3618 = insertelement <8 x i32> %3617, i32 %3616, i32 %3604
  store <8 x i32> %3618, ptr %frame.parent.token, align 32
  %3619 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3604
  %3620 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3604
  %3621 = load <8 x i1>, ptr %3619, align 1
  %3622 = load <8 x i1>, ptr %3620, align 1
  %3623 = select i1 %3597, <8 x i1> %417, <8 x i1> %3621
  store <8 x i1> %3623, ptr %3619, align 1
  %3624 = select i1 %3597, <8 x i1> zeroinitializer, <8 x i1> %3622
  store <8 x i1> %3624, ptr %3620, align 1
  %3625 = add i32 %3604, 1
  %3626 = select i1 %3595, i32 %3582, i32 %3625
  %3627 = select i1 true, i32 %3626, i32 %3582
  store i32 %3627, ptr %current.token, align 4
  %3628 = load i32, ptr %current.token, align 4
  %3629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %424)
  %3630 = load i32, ptr %ready.count, align 4
  %3631 = icmp uge i32 %3630, 8
  %3632 = and i1 %3629, %3631
  br i1 %3632, label %ready.overflow.trap542, label %ready.overflow.resume543

ready.overflow.trap542:                           ; preds = %convergence.overflow.resume541
  call void @llvm.trap()
  unreachable

ready.overflow.resume543:                         ; preds = %convergence.overflow.resume541
  %3633 = select i1 %3629, i32 %3630, i32 0
  %3634 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3633
  %3635 = load <8 x i1>, ptr %3634, align 1
  %3636 = select i1 %3629, <8 x i1> %424, <8 x i1> %3635
  store <8 x i1> %3636, ptr %3634, align 1
  %3637 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3633
  %3638 = load i32, ptr %3637, align 4
  %3639 = select i1 %3629, i32 22, i32 %3638
  store i32 %3639, ptr %3637, align 4
  %3640 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3633
  %3641 = load i32, ptr %3640, align 4
  %3642 = select i1 %3629, i32 %3628, i32 %3641
  store i32 %3642, ptr %3640, align 4
  %3643 = add i32 %3630, 1
  %3644 = select i1 %3629, i32 %3643, i32 %3630
  store i32 %3644, ptr %ready.count, align 4
  %3645 = load <8 x i1>, ptr %runnable.mask, align 1
  %3646 = or <8 x i1> %3645, %424
  store <8 x i1> %3646, ptr %runnable.mask, align 1
  store <8 x i1> %426, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true544:                         ; preds = %varying.coherent539
  store <8 x i1> %417, ptr %current.mask, align 1
  %3647 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %417)
  br i1 %3647, label %schedule.22, label %scheduler.loop

varying.coherent.false545:                        ; preds = %varying.coherent539
  store <8 x i1> %417, ptr %current.mask, align 1
  %3648 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %417)
  br i1 %3648, label %schedule.23, label %scheduler.loop

convergence.cascade557:                           ; preds = %convergence.cascade557, %schedule.23
  %convergence.cascade.flow561 = phi <8 x i1> [ %498, %schedule.23 ], [ %3691, %convergence.cascade557 ]
  %convergence.cascade.depth562 = phi i32 [ 0, %schedule.23 ], [ %3692, %convergence.cascade557 ]
  %3649 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow561)
  %3650 = load i32, ptr %current.token, align 4
  %3651 = icmp ne i32 %3650, 0
  %3652 = and i1 %3649, %3651
  %3653 = sub i32 %3650, 1
  %3654 = select i1 %3652, i32 %3653, i32 0
  %3655 = load i8, ptr %frame.active, align 1
  %3656 = trunc i32 %3654 to i8
  %3657 = shl i8 1, %3656
  %3658 = and i8 %3655, %3657
  %3659 = icmp ne i8 %3658, 0
  %3660 = load <8 x i32>, ptr %frame.static.id, align 32
  %3661 = extractelement <8 x i32> %3660, i32 %3654
  %convergence.target.pointer563 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3661
  %convergence.dynamic.target564 = load i32, ptr %convergence.target.pointer563, align 4
  %3662 = icmp eq i32 %convergence.dynamic.target564, 23
  %3663 = and i1 %3659, %3662
  %3664 = and i1 %3652, %3663
  %3665 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3654
  %3666 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3654
  %3667 = load <8 x i1>, ptr %3665, align 1
  %3668 = load <8 x i1>, ptr %3666, align 1
  %3669 = or <8 x i1> %3668, %convergence.cascade.flow561
  %3670 = load <8 x i1>, ptr %live.mask, align 1
  %3671 = and <8 x i1> %3667, %3670
  %3672 = icmp eq <8 x i1> %3669, %3671
  %3673 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3672)
  %3674 = and i1 %3664, %3673
  %3675 = select i1 %3674, <8 x i1> zeroinitializer, <8 x i1> %3669
  %3676 = select i1 %3664, <8 x i1> %3675, <8 x i1> %3668
  store <8 x i1> %3676, ptr %3666, align 1
  %3677 = select i1 %3674, <8 x i1> zeroinitializer, <8 x i1> %3667
  store <8 x i1> %3677, ptr %3665, align 1
  %3678 = trunc i32 %3654 to i8
  %3679 = shl i8 1, %3678
  %3680 = xor i8 %3679, -1
  %3681 = and i8 %3655, %3680
  %3682 = select i1 %3674, i8 %3681, i8 %3655
  store i8 %3682, ptr %frame.active, align 1
  %.splatinsert565 = insertelement <8 x i1> poison, i1 %3664, i64 0
  %.splat566 = shufflevector <8 x i1> %.splatinsert565, <8 x i1> poison, <8 x i32> zeroinitializer
  %3683 = and <8 x i1> %convergence.cascade.flow561, %.splat566
  %3684 = load <8 x i1>, ptr %runnable.mask, align 1
  %3685 = xor <8 x i1> %3683, splat (i1 true)
  %3686 = and <8 x i1> %3684, %3685
  store <8 x i1> %3686, ptr %runnable.mask, align 1
  %.splatinsert567 = insertelement <8 x i1> poison, i1 %3674, i64 0
  %.splat568 = shufflevector <8 x i1> %.splatinsert567, <8 x i1> poison, <8 x i32> zeroinitializer
  %3687 = select <8 x i1> %.splat568, <8 x i1> %3669, <8 x i1> zeroinitializer
  %3688 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3689 = extractelement <8 x i32> %3688, i32 %3654
  %3690 = select i1 %3674, i32 %3689, i32 %3650
  store i32 %3690, ptr %current.token, align 4
  %.splatinsert569 = insertelement <8 x i1> poison, i1 %3664, i64 0
  %.splat570 = shufflevector <8 x i1> %.splatinsert569, <8 x i1> poison, <8 x i32> zeroinitializer
  %3691 = select <8 x i1> %.splat570, <8 x i1> %3687, <8 x i1> %convergence.cascade.flow561
  %3692 = add i32 %convergence.cascade.depth562, 1
  %3693 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3691)
  %3694 = icmp ult i32 %3692, 8
  %3695 = and i1 %3693, %3694
  %3696 = and i1 %3664, %3695
  %convergence.parent.token571 = load i32, ptr %current.token, align 4
  %convergence.parent.present572 = icmp ne i32 %convergence.parent.token571, 0
  %3697 = and i1 %3696, %convergence.parent.present572
  br i1 %3697, label %convergence.cascade557, label %convergence.cascade.exit558

convergence.cascade.exit558:                      ; preds = %convergence.cascade557, %schedule.23
  %convergence.cascade.result573 = phi <8 x i1> [ %498, %schedule.23 ], [ %3691, %convergence.cascade557 ]
  %3698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result573)
  br i1 %3698, label %convergence.target.23.ready, label %scheduler.loop

convergence.target.23.ready:                      ; preds = %convergence.cascade.exit558
  %3699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result573)
  %3700 = bitcast <8 x i1> %convergence.cascade.result573 to i8
  %3701 = call i8 @llvm.cttz.i8(i8 %3700, i1 false)
  %3702 = zext i8 %3701 to i32
  %3703 = select i1 %3699, i32 %3702, i32 0
  %3704 = load <8 x i64>, ptr %.slot56, align 64
  %3705 = select <8 x i1> %convergence.cascade.result573, <8 x i64> zeroinitializer, <8 x i64> %3704
  store <8 x i64> %3705, ptr %.slot56, align 64
  %3706 = load <8 x float>, ptr %.slot69, align 32
  %3707 = select <8 x i1> %convergence.cascade.result573, <8 x float> zeroinitializer, <8 x float> %3706
  store <8 x float> %3707, ptr %.slot69, align 32
  %3708 = load <8 x float>, ptr %.slot70, align 32
  %3709 = select <8 x i1> %convergence.cascade.result573, <8 x float> zeroinitializer, <8 x float> %3708
  store <8 x float> %3709, ptr %.slot70, align 32
  %3710 = load <8 x float>, ptr %.slot71, align 32
  %3711 = select <8 x i1> %convergence.cascade.result573, <8 x float> zeroinitializer, <8 x float> %3710
  store <8 x float> %3711, ptr %.slot71, align 32
  %3712 = load <8 x float>, ptr %.slot72, align 32
  %3713 = select <8 x i1> %convergence.cascade.result573, <8 x float> zeroinitializer, <8 x float> %3712
  store <8 x float> %3713, ptr %.slot72, align 32
  store <8 x i1> %convergence.cascade.result573, ptr %current.mask, align 1
  %3714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result573)
  br i1 %3714, label %schedule.24, label %scheduler.loop

varying.divergent575:                             ; preds = %schedule.24
  %3715 = load i32, ptr %current.token, align 4
  %3716 = icmp ne i32 %3715, 0
  %3717 = sub i32 %3715, 1
  %3718 = select i1 %3716, i32 %3717, i32 0
  %3719 = load i8, ptr %frame.active, align 1
  %3720 = trunc i32 %3718 to i8
  %3721 = shl i8 1, %3720
  %3722 = and i8 %3719, %3721
  %3723 = icmp ne i8 %3722, 0
  %3724 = load <8 x i32>, ptr %frame.static.id, align 32
  %3725 = extractelement <8 x i32> %3724, i32 %3718
  %3726 = icmp eq i32 %3725, 9
  %3727 = and i1 %3723, %3726
  %3728 = and i1 %3716, %3727
  %3729 = xor i1 %3728, true
  %3730 = and i1 true, %3729
  %3731 = xor i8 %3719, -1
  %3732 = icmp ne i8 %3731, 0
  %3733 = xor i1 %3732, true
  %3734 = and i1 %3730, %3733
  br i1 %3734, label %convergence.overflow.trap577, label %convergence.overflow.resume578

varying.coherent576:                              ; preds = %schedule.24
  br i1 %509, label %varying.coherent.true581, label %varying.coherent.false582

convergence.overflow.trap577:                     ; preds = %varying.divergent575
  call void @llvm.trap()
  unreachable

convergence.overflow.resume578:                   ; preds = %varying.divergent575
  %3735 = call i8 @llvm.cttz.i8(i8 %3731, i1 false)
  %3736 = zext i8 %3735 to i32
  %3737 = select i1 %3732, i32 %3736, i32 0
  %3738 = trunc i32 %3737 to i8
  %3739 = shl i8 1, %3738
  %3740 = or i8 %3719, %3739
  %3741 = select i1 %3730, i8 %3740, i8 %3719
  store i8 %3741, ptr %frame.active, align 1
  %3742 = load <8 x i32>, ptr %frame.static.id, align 32
  %3743 = extractelement <8 x i32> %3742, i32 %3737
  %3744 = select i1 %3730, i32 9, i32 %3743
  %3745 = load <8 x i32>, ptr %frame.static.id, align 32
  %3746 = insertelement <8 x i32> %3745, i32 %3744, i32 %3737
  store <8 x i32> %3746, ptr %frame.static.id, align 32
  %3747 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3748 = extractelement <8 x i32> %3747, i32 %3737
  %3749 = select i1 %3730, i32 %3715, i32 %3748
  %3750 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3751 = insertelement <8 x i32> %3750, i32 %3749, i32 %3737
  store <8 x i32> %3751, ptr %frame.parent.token, align 32
  %3752 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3737
  %3753 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3737
  %3754 = load <8 x i1>, ptr %3752, align 1
  %3755 = load <8 x i1>, ptr %3753, align 1
  %3756 = select i1 %3730, <8 x i1> %499, <8 x i1> %3754
  store <8 x i1> %3756, ptr %3752, align 1
  %3757 = select i1 %3730, <8 x i1> zeroinitializer, <8 x i1> %3755
  store <8 x i1> %3757, ptr %3753, align 1
  %3758 = add i32 %3737, 1
  %3759 = select i1 %3728, i32 %3715, i32 %3758
  %3760 = select i1 true, i32 %3759, i32 %3715
  store i32 %3760, ptr %current.token, align 4
  %3761 = load i32, ptr %current.token, align 4
  %3762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %506)
  %3763 = load i32, ptr %ready.count, align 4
  %3764 = icmp uge i32 %3763, 8
  %3765 = and i1 %3762, %3764
  br i1 %3765, label %ready.overflow.trap579, label %ready.overflow.resume580

ready.overflow.trap579:                           ; preds = %convergence.overflow.resume578
  call void @llvm.trap()
  unreachable

ready.overflow.resume580:                         ; preds = %convergence.overflow.resume578
  %3766 = select i1 %3762, i32 %3763, i32 0
  %3767 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3766
  %3768 = load <8 x i1>, ptr %3767, align 1
  %3769 = select i1 %3762, <8 x i1> %506, <8 x i1> %3768
  store <8 x i1> %3769, ptr %3767, align 1
  %3770 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3766
  %3771 = load i32, ptr %3770, align 4
  %3772 = select i1 %3762, i32 25, i32 %3771
  store i32 %3772, ptr %3770, align 4
  %3773 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3766
  %3774 = load i32, ptr %3773, align 4
  %3775 = select i1 %3762, i32 %3761, i32 %3774
  store i32 %3775, ptr %3773, align 4
  %3776 = add i32 %3763, 1
  %3777 = select i1 %3762, i32 %3776, i32 %3763
  store i32 %3777, ptr %ready.count, align 4
  %3778 = load <8 x i1>, ptr %runnable.mask, align 1
  %3779 = or <8 x i1> %3778, %506
  store <8 x i1> %3779, ptr %runnable.mask, align 1
  store <8 x i1> %508, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true581:                         ; preds = %varying.coherent576
  store <8 x i1> %499, ptr %current.mask, align 1
  %3780 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %499)
  br i1 %3780, label %schedule.25, label %scheduler.loop

varying.coherent.false582:                        ; preds = %varying.coherent576
  store <8 x i1> %499, ptr %current.mask, align 1
  %3781 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %499)
  br i1 %3781, label %schedule.26, label %scheduler.loop

convergence.cascade596:                           ; preds = %convergence.cascade596, %schedule.26
  %convergence.cascade.flow600 = phi <8 x i1> [ %582, %schedule.26 ], [ %3824, %convergence.cascade596 ]
  %convergence.cascade.depth601 = phi i32 [ 0, %schedule.26 ], [ %3825, %convergence.cascade596 ]
  %3782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow600)
  %3783 = load i32, ptr %current.token, align 4
  %3784 = icmp ne i32 %3783, 0
  %3785 = and i1 %3782, %3784
  %3786 = sub i32 %3783, 1
  %3787 = select i1 %3785, i32 %3786, i32 0
  %3788 = load i8, ptr %frame.active, align 1
  %3789 = trunc i32 %3787 to i8
  %3790 = shl i8 1, %3789
  %3791 = and i8 %3788, %3790
  %3792 = icmp ne i8 %3791, 0
  %3793 = load <8 x i32>, ptr %frame.static.id, align 32
  %3794 = extractelement <8 x i32> %3793, i32 %3787
  %convergence.target.pointer602 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3794
  %convergence.dynamic.target603 = load i32, ptr %convergence.target.pointer602, align 4
  %3795 = icmp eq i32 %convergence.dynamic.target603, 26
  %3796 = and i1 %3792, %3795
  %3797 = and i1 %3785, %3796
  %3798 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3787
  %3799 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3787
  %3800 = load <8 x i1>, ptr %3798, align 1
  %3801 = load <8 x i1>, ptr %3799, align 1
  %3802 = or <8 x i1> %3801, %convergence.cascade.flow600
  %3803 = load <8 x i1>, ptr %live.mask, align 1
  %3804 = and <8 x i1> %3800, %3803
  %3805 = icmp eq <8 x i1> %3802, %3804
  %3806 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3805)
  %3807 = and i1 %3797, %3806
  %3808 = select i1 %3807, <8 x i1> zeroinitializer, <8 x i1> %3802
  %3809 = select i1 %3797, <8 x i1> %3808, <8 x i1> %3801
  store <8 x i1> %3809, ptr %3799, align 1
  %3810 = select i1 %3807, <8 x i1> zeroinitializer, <8 x i1> %3800
  store <8 x i1> %3810, ptr %3798, align 1
  %3811 = trunc i32 %3787 to i8
  %3812 = shl i8 1, %3811
  %3813 = xor i8 %3812, -1
  %3814 = and i8 %3788, %3813
  %3815 = select i1 %3807, i8 %3814, i8 %3788
  store i8 %3815, ptr %frame.active, align 1
  %.splatinsert604 = insertelement <8 x i1> poison, i1 %3797, i64 0
  %.splat605 = shufflevector <8 x i1> %.splatinsert604, <8 x i1> poison, <8 x i32> zeroinitializer
  %3816 = and <8 x i1> %convergence.cascade.flow600, %.splat605
  %3817 = load <8 x i1>, ptr %runnable.mask, align 1
  %3818 = xor <8 x i1> %3816, splat (i1 true)
  %3819 = and <8 x i1> %3817, %3818
  store <8 x i1> %3819, ptr %runnable.mask, align 1
  %.splatinsert606 = insertelement <8 x i1> poison, i1 %3807, i64 0
  %.splat607 = shufflevector <8 x i1> %.splatinsert606, <8 x i1> poison, <8 x i32> zeroinitializer
  %3820 = select <8 x i1> %.splat607, <8 x i1> %3802, <8 x i1> zeroinitializer
  %3821 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3822 = extractelement <8 x i32> %3821, i32 %3787
  %3823 = select i1 %3807, i32 %3822, i32 %3783
  store i32 %3823, ptr %current.token, align 4
  %.splatinsert608 = insertelement <8 x i1> poison, i1 %3797, i64 0
  %.splat609 = shufflevector <8 x i1> %.splatinsert608, <8 x i1> poison, <8 x i32> zeroinitializer
  %3824 = select <8 x i1> %.splat609, <8 x i1> %3820, <8 x i1> %convergence.cascade.flow600
  %3825 = add i32 %convergence.cascade.depth601, 1
  %3826 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3824)
  %3827 = icmp ult i32 %3825, 8
  %3828 = and i1 %3826, %3827
  %3829 = and i1 %3797, %3828
  %convergence.parent.token610 = load i32, ptr %current.token, align 4
  %convergence.parent.present611 = icmp ne i32 %convergence.parent.token610, 0
  %3830 = and i1 %3829, %convergence.parent.present611
  br i1 %3830, label %convergence.cascade596, label %convergence.cascade.exit597

convergence.cascade.exit597:                      ; preds = %convergence.cascade596, %schedule.26
  %convergence.cascade.result612 = phi <8 x i1> [ %582, %schedule.26 ], [ %3824, %convergence.cascade596 ]
  %3831 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result612)
  br i1 %3831, label %convergence.target.26.ready, label %scheduler.loop

convergence.target.26.ready:                      ; preds = %convergence.cascade.exit597
  %3832 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result612)
  %3833 = bitcast <8 x i1> %convergence.cascade.result612 to i8
  %3834 = call i8 @llvm.cttz.i8(i8 %3833, i1 false)
  %3835 = zext i8 %3834 to i32
  %3836 = select i1 %3832, i32 %3835, i32 0
  %3837 = load <8 x i64>, ptr %.slot56, align 64
  %3838 = select <8 x i1> %convergence.cascade.result612, <8 x i64> zeroinitializer, <8 x i64> %3837
  store <8 x i64> %3838, ptr %.slot56, align 64
  %3839 = load <8 x float>, ptr %.slot74, align 32
  %3840 = select <8 x i1> %convergence.cascade.result612, <8 x float> zeroinitializer, <8 x float> %3839
  store <8 x float> %3840, ptr %.slot74, align 32
  %3841 = load <8 x float>, ptr %.slot75, align 32
  %3842 = select <8 x i1> %convergence.cascade.result612, <8 x float> zeroinitializer, <8 x float> %3841
  store <8 x float> %3842, ptr %.slot75, align 32
  %3843 = load <8 x float>, ptr %.slot76, align 32
  %3844 = select <8 x i1> %convergence.cascade.result612, <8 x float> zeroinitializer, <8 x float> %3843
  store <8 x float> %3844, ptr %.slot76, align 32
  %3845 = load <8 x float>, ptr %.slot77, align 32
  %3846 = select <8 x i1> %convergence.cascade.result612, <8 x float> zeroinitializer, <8 x float> %3845
  store <8 x float> %3846, ptr %.slot77, align 32
  store <8 x i1> %convergence.cascade.result612, ptr %current.mask, align 1
  %3847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result612)
  br i1 %3847, label %schedule.27, label %scheduler.loop

varying.divergent614:                             ; preds = %schedule.27
  %3848 = load i32, ptr %current.token, align 4
  %3849 = icmp ne i32 %3848, 0
  %3850 = sub i32 %3848, 1
  %3851 = select i1 %3849, i32 %3850, i32 0
  %3852 = load i8, ptr %frame.active, align 1
  %3853 = trunc i32 %3851 to i8
  %3854 = shl i8 1, %3853
  %3855 = and i8 %3852, %3854
  %3856 = icmp ne i8 %3855, 0
  %3857 = load <8 x i32>, ptr %frame.static.id, align 32
  %3858 = extractelement <8 x i32> %3857, i32 %3851
  %3859 = icmp eq i32 %3858, 10
  %3860 = and i1 %3856, %3859
  %3861 = and i1 %3849, %3860
  %3862 = xor i1 %3861, true
  %3863 = and i1 true, %3862
  %3864 = xor i8 %3852, -1
  %3865 = icmp ne i8 %3864, 0
  %3866 = xor i1 %3865, true
  %3867 = and i1 %3863, %3866
  br i1 %3867, label %convergence.overflow.trap616, label %convergence.overflow.resume617

varying.coherent615:                              ; preds = %schedule.27
  br i1 %593, label %varying.coherent.true620, label %varying.coherent.false621

convergence.overflow.trap616:                     ; preds = %varying.divergent614
  call void @llvm.trap()
  unreachable

convergence.overflow.resume617:                   ; preds = %varying.divergent614
  %3868 = call i8 @llvm.cttz.i8(i8 %3864, i1 false)
  %3869 = zext i8 %3868 to i32
  %3870 = select i1 %3865, i32 %3869, i32 0
  %3871 = trunc i32 %3870 to i8
  %3872 = shl i8 1, %3871
  %3873 = or i8 %3852, %3872
  %3874 = select i1 %3863, i8 %3873, i8 %3852
  store i8 %3874, ptr %frame.active, align 1
  %3875 = load <8 x i32>, ptr %frame.static.id, align 32
  %3876 = extractelement <8 x i32> %3875, i32 %3870
  %3877 = select i1 %3863, i32 10, i32 %3876
  %3878 = load <8 x i32>, ptr %frame.static.id, align 32
  %3879 = insertelement <8 x i32> %3878, i32 %3877, i32 %3870
  store <8 x i32> %3879, ptr %frame.static.id, align 32
  %3880 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3881 = extractelement <8 x i32> %3880, i32 %3870
  %3882 = select i1 %3863, i32 %3848, i32 %3881
  %3883 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3884 = insertelement <8 x i32> %3883, i32 %3882, i32 %3870
  store <8 x i32> %3884, ptr %frame.parent.token, align 32
  %3885 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3870
  %3886 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3870
  %3887 = load <8 x i1>, ptr %3885, align 1
  %3888 = load <8 x i1>, ptr %3886, align 1
  %3889 = select i1 %3863, <8 x i1> %583, <8 x i1> %3887
  store <8 x i1> %3889, ptr %3885, align 1
  %3890 = select i1 %3863, <8 x i1> zeroinitializer, <8 x i1> %3888
  store <8 x i1> %3890, ptr %3886, align 1
  %3891 = add i32 %3870, 1
  %3892 = select i1 %3861, i32 %3848, i32 %3891
  %3893 = select i1 true, i32 %3892, i32 %3848
  store i32 %3893, ptr %current.token, align 4
  %3894 = load i32, ptr %current.token, align 4
  %3895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %590)
  %3896 = load i32, ptr %ready.count, align 4
  %3897 = icmp uge i32 %3896, 8
  %3898 = and i1 %3895, %3897
  br i1 %3898, label %ready.overflow.trap618, label %ready.overflow.resume619

ready.overflow.trap618:                           ; preds = %convergence.overflow.resume617
  call void @llvm.trap()
  unreachable

ready.overflow.resume619:                         ; preds = %convergence.overflow.resume617
  %3899 = select i1 %3895, i32 %3896, i32 0
  %3900 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3899
  %3901 = load <8 x i1>, ptr %3900, align 1
  %3902 = select i1 %3895, <8 x i1> %590, <8 x i1> %3901
  store <8 x i1> %3902, ptr %3900, align 1
  %3903 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3899
  %3904 = load i32, ptr %3903, align 4
  %3905 = select i1 %3895, i32 28, i32 %3904
  store i32 %3905, ptr %3903, align 4
  %3906 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3899
  %3907 = load i32, ptr %3906, align 4
  %3908 = select i1 %3895, i32 %3894, i32 %3907
  store i32 %3908, ptr %3906, align 4
  %3909 = add i32 %3896, 1
  %3910 = select i1 %3895, i32 %3909, i32 %3896
  store i32 %3910, ptr %ready.count, align 4
  %3911 = load <8 x i1>, ptr %runnable.mask, align 1
  %3912 = or <8 x i1> %3911, %590
  store <8 x i1> %3912, ptr %runnable.mask, align 1
  store <8 x i1> %592, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true620:                         ; preds = %varying.coherent615
  store <8 x i1> %583, ptr %current.mask, align 1
  %3913 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %583)
  br i1 %3913, label %schedule.28, label %scheduler.loop

varying.coherent.false621:                        ; preds = %varying.coherent615
  store <8 x i1> %583, ptr %current.mask, align 1
  %3914 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %583)
  br i1 %3914, label %schedule.29, label %scheduler.loop

convergence.cascade635:                           ; preds = %convergence.cascade635, %schedule.29
  %convergence.cascade.flow639 = phi <8 x i1> [ %666, %schedule.29 ], [ %3957, %convergence.cascade635 ]
  %convergence.cascade.depth640 = phi i32 [ 0, %schedule.29 ], [ %3958, %convergence.cascade635 ]
  %3915 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow639)
  %3916 = load i32, ptr %current.token, align 4
  %3917 = icmp ne i32 %3916, 0
  %3918 = and i1 %3915, %3917
  %3919 = sub i32 %3916, 1
  %3920 = select i1 %3918, i32 %3919, i32 0
  %3921 = load i8, ptr %frame.active, align 1
  %3922 = trunc i32 %3920 to i8
  %3923 = shl i8 1, %3922
  %3924 = and i8 %3921, %3923
  %3925 = icmp ne i8 %3924, 0
  %3926 = load <8 x i32>, ptr %frame.static.id, align 32
  %3927 = extractelement <8 x i32> %3926, i32 %3920
  %convergence.target.pointer641 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %3927
  %convergence.dynamic.target642 = load i32, ptr %convergence.target.pointer641, align 4
  %3928 = icmp eq i32 %convergence.dynamic.target642, 29
  %3929 = and i1 %3925, %3928
  %3930 = and i1 %3918, %3929
  %3931 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3920
  %3932 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3920
  %3933 = load <8 x i1>, ptr %3931, align 1
  %3934 = load <8 x i1>, ptr %3932, align 1
  %3935 = or <8 x i1> %3934, %convergence.cascade.flow639
  %3936 = load <8 x i1>, ptr %live.mask, align 1
  %3937 = and <8 x i1> %3933, %3936
  %3938 = icmp eq <8 x i1> %3935, %3937
  %3939 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3938)
  %3940 = and i1 %3930, %3939
  %3941 = select i1 %3940, <8 x i1> zeroinitializer, <8 x i1> %3935
  %3942 = select i1 %3930, <8 x i1> %3941, <8 x i1> %3934
  store <8 x i1> %3942, ptr %3932, align 1
  %3943 = select i1 %3940, <8 x i1> zeroinitializer, <8 x i1> %3933
  store <8 x i1> %3943, ptr %3931, align 1
  %3944 = trunc i32 %3920 to i8
  %3945 = shl i8 1, %3944
  %3946 = xor i8 %3945, -1
  %3947 = and i8 %3921, %3946
  %3948 = select i1 %3940, i8 %3947, i8 %3921
  store i8 %3948, ptr %frame.active, align 1
  %.splatinsert643 = insertelement <8 x i1> poison, i1 %3930, i64 0
  %.splat644 = shufflevector <8 x i1> %.splatinsert643, <8 x i1> poison, <8 x i32> zeroinitializer
  %3949 = and <8 x i1> %convergence.cascade.flow639, %.splat644
  %3950 = load <8 x i1>, ptr %runnable.mask, align 1
  %3951 = xor <8 x i1> %3949, splat (i1 true)
  %3952 = and <8 x i1> %3950, %3951
  store <8 x i1> %3952, ptr %runnable.mask, align 1
  %.splatinsert645 = insertelement <8 x i1> poison, i1 %3940, i64 0
  %.splat646 = shufflevector <8 x i1> %.splatinsert645, <8 x i1> poison, <8 x i32> zeroinitializer
  %3953 = select <8 x i1> %.splat646, <8 x i1> %3935, <8 x i1> zeroinitializer
  %3954 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3955 = extractelement <8 x i32> %3954, i32 %3920
  %3956 = select i1 %3940, i32 %3955, i32 %3916
  store i32 %3956, ptr %current.token, align 4
  %.splatinsert647 = insertelement <8 x i1> poison, i1 %3930, i64 0
  %.splat648 = shufflevector <8 x i1> %.splatinsert647, <8 x i1> poison, <8 x i32> zeroinitializer
  %3957 = select <8 x i1> %.splat648, <8 x i1> %3953, <8 x i1> %convergence.cascade.flow639
  %3958 = add i32 %convergence.cascade.depth640, 1
  %3959 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3957)
  %3960 = icmp ult i32 %3958, 8
  %3961 = and i1 %3959, %3960
  %3962 = and i1 %3930, %3961
  %convergence.parent.token649 = load i32, ptr %current.token, align 4
  %convergence.parent.present650 = icmp ne i32 %convergence.parent.token649, 0
  %3963 = and i1 %3962, %convergence.parent.present650
  br i1 %3963, label %convergence.cascade635, label %convergence.cascade.exit636

convergence.cascade.exit636:                      ; preds = %convergence.cascade635, %schedule.29
  %convergence.cascade.result651 = phi <8 x i1> [ %666, %schedule.29 ], [ %3957, %convergence.cascade635 ]
  %3964 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result651)
  br i1 %3964, label %convergence.target.29.ready, label %scheduler.loop

convergence.target.29.ready:                      ; preds = %convergence.cascade.exit636
  %3965 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result651)
  %3966 = bitcast <8 x i1> %convergence.cascade.result651 to i8
  %3967 = call i8 @llvm.cttz.i8(i8 %3966, i1 false)
  %3968 = zext i8 %3967 to i32
  %3969 = select i1 %3965, i32 %3968, i32 0
  %3970 = load <8 x i64>, ptr %.slot56, align 64
  %3971 = select <8 x i1> %convergence.cascade.result651, <8 x i64> zeroinitializer, <8 x i64> %3970
  store <8 x i64> %3971, ptr %.slot56, align 64
  %3972 = load <8 x float>, ptr %.slot79, align 32
  %3973 = select <8 x i1> %convergence.cascade.result651, <8 x float> zeroinitializer, <8 x float> %3972
  store <8 x float> %3973, ptr %.slot79, align 32
  %3974 = load <8 x float>, ptr %.slot80, align 32
  %3975 = select <8 x i1> %convergence.cascade.result651, <8 x float> zeroinitializer, <8 x float> %3974
  store <8 x float> %3975, ptr %.slot80, align 32
  %3976 = load <8 x float>, ptr %.slot81, align 32
  %3977 = select <8 x i1> %convergence.cascade.result651, <8 x float> zeroinitializer, <8 x float> %3976
  store <8 x float> %3977, ptr %.slot81, align 32
  %3978 = load <8 x float>, ptr %.slot82, align 32
  %3979 = select <8 x i1> %convergence.cascade.result651, <8 x float> zeroinitializer, <8 x float> %3978
  store <8 x float> %3979, ptr %.slot82, align 32
  store <8 x i1> %convergence.cascade.result651, ptr %current.mask, align 1
  %3980 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result651)
  br i1 %3980, label %schedule.30, label %scheduler.loop

varying.divergent653:                             ; preds = %schedule.30
  %3981 = load i32, ptr %current.token, align 4
  %3982 = icmp ne i32 %3981, 0
  %3983 = sub i32 %3981, 1
  %3984 = select i1 %3982, i32 %3983, i32 0
  %3985 = load i8, ptr %frame.active, align 1
  %3986 = trunc i32 %3984 to i8
  %3987 = shl i8 1, %3986
  %3988 = and i8 %3985, %3987
  %3989 = icmp ne i8 %3988, 0
  %3990 = load <8 x i32>, ptr %frame.static.id, align 32
  %3991 = extractelement <8 x i32> %3990, i32 %3984
  %3992 = icmp eq i32 %3991, 11
  %3993 = and i1 %3989, %3992
  %3994 = and i1 %3982, %3993
  %3995 = xor i1 %3994, true
  %3996 = and i1 true, %3995
  %3997 = xor i8 %3985, -1
  %3998 = icmp ne i8 %3997, 0
  %3999 = xor i1 %3998, true
  %4000 = and i1 %3996, %3999
  br i1 %4000, label %convergence.overflow.trap655, label %convergence.overflow.resume656

varying.coherent654:                              ; preds = %schedule.30
  br i1 %677, label %varying.coherent.true659, label %varying.coherent.false660

convergence.overflow.trap655:                     ; preds = %varying.divergent653
  call void @llvm.trap()
  unreachable

convergence.overflow.resume656:                   ; preds = %varying.divergent653
  %4001 = call i8 @llvm.cttz.i8(i8 %3997, i1 false)
  %4002 = zext i8 %4001 to i32
  %4003 = select i1 %3998, i32 %4002, i32 0
  %4004 = trunc i32 %4003 to i8
  %4005 = shl i8 1, %4004
  %4006 = or i8 %3985, %4005
  %4007 = select i1 %3996, i8 %4006, i8 %3985
  store i8 %4007, ptr %frame.active, align 1
  %4008 = load <8 x i32>, ptr %frame.static.id, align 32
  %4009 = extractelement <8 x i32> %4008, i32 %4003
  %4010 = select i1 %3996, i32 11, i32 %4009
  %4011 = load <8 x i32>, ptr %frame.static.id, align 32
  %4012 = insertelement <8 x i32> %4011, i32 %4010, i32 %4003
  store <8 x i32> %4012, ptr %frame.static.id, align 32
  %4013 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4014 = extractelement <8 x i32> %4013, i32 %4003
  %4015 = select i1 %3996, i32 %3981, i32 %4014
  %4016 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4017 = insertelement <8 x i32> %4016, i32 %4015, i32 %4003
  store <8 x i32> %4017, ptr %frame.parent.token, align 32
  %4018 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4003
  %4019 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4003
  %4020 = load <8 x i1>, ptr %4018, align 1
  %4021 = load <8 x i1>, ptr %4019, align 1
  %4022 = select i1 %3996, <8 x i1> %667, <8 x i1> %4020
  store <8 x i1> %4022, ptr %4018, align 1
  %4023 = select i1 %3996, <8 x i1> zeroinitializer, <8 x i1> %4021
  store <8 x i1> %4023, ptr %4019, align 1
  %4024 = add i32 %4003, 1
  %4025 = select i1 %3994, i32 %3981, i32 %4024
  %4026 = select i1 true, i32 %4025, i32 %3981
  store i32 %4026, ptr %current.token, align 4
  %4027 = load i32, ptr %current.token, align 4
  %4028 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %674)
  %4029 = load i32, ptr %ready.count, align 4
  %4030 = icmp uge i32 %4029, 8
  %4031 = and i1 %4028, %4030
  br i1 %4031, label %ready.overflow.trap657, label %ready.overflow.resume658

ready.overflow.trap657:                           ; preds = %convergence.overflow.resume656
  call void @llvm.trap()
  unreachable

ready.overflow.resume658:                         ; preds = %convergence.overflow.resume656
  %4032 = select i1 %4028, i32 %4029, i32 0
  %4033 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4032
  %4034 = load <8 x i1>, ptr %4033, align 1
  %4035 = select i1 %4028, <8 x i1> %674, <8 x i1> %4034
  store <8 x i1> %4035, ptr %4033, align 1
  %4036 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4032
  %4037 = load i32, ptr %4036, align 4
  %4038 = select i1 %4028, i32 31, i32 %4037
  store i32 %4038, ptr %4036, align 4
  %4039 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4032
  %4040 = load i32, ptr %4039, align 4
  %4041 = select i1 %4028, i32 %4027, i32 %4040
  store i32 %4041, ptr %4039, align 4
  %4042 = add i32 %4029, 1
  %4043 = select i1 %4028, i32 %4042, i32 %4029
  store i32 %4043, ptr %ready.count, align 4
  %4044 = load <8 x i1>, ptr %runnable.mask, align 1
  %4045 = or <8 x i1> %4044, %674
  store <8 x i1> %4045, ptr %runnable.mask, align 1
  store <8 x i1> %676, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true659:                         ; preds = %varying.coherent654
  store <8 x i1> %667, ptr %current.mask, align 1
  %4046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %667)
  br i1 %4046, label %schedule.31, label %scheduler.loop

varying.coherent.false660:                        ; preds = %varying.coherent654
  store <8 x i1> %667, ptr %current.mask, align 1
  %4047 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %667)
  br i1 %4047, label %schedule.32, label %scheduler.loop

convergence.cascade674:                           ; preds = %convergence.cascade674, %schedule.32
  %convergence.cascade.flow678 = phi <8 x i1> [ %750, %schedule.32 ], [ %4090, %convergence.cascade674 ]
  %convergence.cascade.depth679 = phi i32 [ 0, %schedule.32 ], [ %4091, %convergence.cascade674 ]
  %4048 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow678)
  %4049 = load i32, ptr %current.token, align 4
  %4050 = icmp ne i32 %4049, 0
  %4051 = and i1 %4048, %4050
  %4052 = sub i32 %4049, 1
  %4053 = select i1 %4051, i32 %4052, i32 0
  %4054 = load i8, ptr %frame.active, align 1
  %4055 = trunc i32 %4053 to i8
  %4056 = shl i8 1, %4055
  %4057 = and i8 %4054, %4056
  %4058 = icmp ne i8 %4057, 0
  %4059 = load <8 x i32>, ptr %frame.static.id, align 32
  %4060 = extractelement <8 x i32> %4059, i32 %4053
  %convergence.target.pointer680 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4060
  %convergence.dynamic.target681 = load i32, ptr %convergence.target.pointer680, align 4
  %4061 = icmp eq i32 %convergence.dynamic.target681, 32
  %4062 = and i1 %4058, %4061
  %4063 = and i1 %4051, %4062
  %4064 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4053
  %4065 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4053
  %4066 = load <8 x i1>, ptr %4064, align 1
  %4067 = load <8 x i1>, ptr %4065, align 1
  %4068 = or <8 x i1> %4067, %convergence.cascade.flow678
  %4069 = load <8 x i1>, ptr %live.mask, align 1
  %4070 = and <8 x i1> %4066, %4069
  %4071 = icmp eq <8 x i1> %4068, %4070
  %4072 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4071)
  %4073 = and i1 %4063, %4072
  %4074 = select i1 %4073, <8 x i1> zeroinitializer, <8 x i1> %4068
  %4075 = select i1 %4063, <8 x i1> %4074, <8 x i1> %4067
  store <8 x i1> %4075, ptr %4065, align 1
  %4076 = select i1 %4073, <8 x i1> zeroinitializer, <8 x i1> %4066
  store <8 x i1> %4076, ptr %4064, align 1
  %4077 = trunc i32 %4053 to i8
  %4078 = shl i8 1, %4077
  %4079 = xor i8 %4078, -1
  %4080 = and i8 %4054, %4079
  %4081 = select i1 %4073, i8 %4080, i8 %4054
  store i8 %4081, ptr %frame.active, align 1
  %.splatinsert682 = insertelement <8 x i1> poison, i1 %4063, i64 0
  %.splat683 = shufflevector <8 x i1> %.splatinsert682, <8 x i1> poison, <8 x i32> zeroinitializer
  %4082 = and <8 x i1> %convergence.cascade.flow678, %.splat683
  %4083 = load <8 x i1>, ptr %runnable.mask, align 1
  %4084 = xor <8 x i1> %4082, splat (i1 true)
  %4085 = and <8 x i1> %4083, %4084
  store <8 x i1> %4085, ptr %runnable.mask, align 1
  %.splatinsert684 = insertelement <8 x i1> poison, i1 %4073, i64 0
  %.splat685 = shufflevector <8 x i1> %.splatinsert684, <8 x i1> poison, <8 x i32> zeroinitializer
  %4086 = select <8 x i1> %.splat685, <8 x i1> %4068, <8 x i1> zeroinitializer
  %4087 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4088 = extractelement <8 x i32> %4087, i32 %4053
  %4089 = select i1 %4073, i32 %4088, i32 %4049
  store i32 %4089, ptr %current.token, align 4
  %.splatinsert686 = insertelement <8 x i1> poison, i1 %4063, i64 0
  %.splat687 = shufflevector <8 x i1> %.splatinsert686, <8 x i1> poison, <8 x i32> zeroinitializer
  %4090 = select <8 x i1> %.splat687, <8 x i1> %4086, <8 x i1> %convergence.cascade.flow678
  %4091 = add i32 %convergence.cascade.depth679, 1
  %4092 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4090)
  %4093 = icmp ult i32 %4091, 8
  %4094 = and i1 %4092, %4093
  %4095 = and i1 %4063, %4094
  %convergence.parent.token688 = load i32, ptr %current.token, align 4
  %convergence.parent.present689 = icmp ne i32 %convergence.parent.token688, 0
  %4096 = and i1 %4095, %convergence.parent.present689
  br i1 %4096, label %convergence.cascade674, label %convergence.cascade.exit675

convergence.cascade.exit675:                      ; preds = %convergence.cascade674, %schedule.32
  %convergence.cascade.result690 = phi <8 x i1> [ %750, %schedule.32 ], [ %4090, %convergence.cascade674 ]
  %4097 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result690)
  br i1 %4097, label %convergence.target.32.ready, label %scheduler.loop

convergence.target.32.ready:                      ; preds = %convergence.cascade.exit675
  %4098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result690)
  %4099 = bitcast <8 x i1> %convergence.cascade.result690 to i8
  %4100 = call i8 @llvm.cttz.i8(i8 %4099, i1 false)
  %4101 = zext i8 %4100 to i32
  %4102 = select i1 %4098, i32 %4101, i32 0
  %4103 = load <8 x i64>, ptr %.slot56, align 64
  %4104 = select <8 x i1> %convergence.cascade.result690, <8 x i64> zeroinitializer, <8 x i64> %4103
  store <8 x i64> %4104, ptr %.slot56, align 64
  %4105 = load <8 x float>, ptr %.slot84, align 32
  %4106 = select <8 x i1> %convergence.cascade.result690, <8 x float> zeroinitializer, <8 x float> %4105
  store <8 x float> %4106, ptr %.slot84, align 32
  %4107 = load <8 x float>, ptr %.slot85, align 32
  %4108 = select <8 x i1> %convergence.cascade.result690, <8 x float> zeroinitializer, <8 x float> %4107
  store <8 x float> %4108, ptr %.slot85, align 32
  %4109 = load <8 x float>, ptr %.slot86, align 32
  %4110 = select <8 x i1> %convergence.cascade.result690, <8 x float> zeroinitializer, <8 x float> %4109
  store <8 x float> %4110, ptr %.slot86, align 32
  %4111 = load <8 x float>, ptr %.slot87, align 32
  %4112 = select <8 x i1> %convergence.cascade.result690, <8 x float> zeroinitializer, <8 x float> %4111
  store <8 x float> %4112, ptr %.slot87, align 32
  store <8 x i1> %convergence.cascade.result690, ptr %current.mask, align 1
  %4113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result690)
  br i1 %4113, label %schedule.33, label %scheduler.loop

varying.divergent692:                             ; preds = %schedule.33
  %4114 = load i32, ptr %current.token, align 4
  %4115 = icmp ne i32 %4114, 0
  %4116 = sub i32 %4114, 1
  %4117 = select i1 %4115, i32 %4116, i32 0
  %4118 = load i8, ptr %frame.active, align 1
  %4119 = trunc i32 %4117 to i8
  %4120 = shl i8 1, %4119
  %4121 = and i8 %4118, %4120
  %4122 = icmp ne i8 %4121, 0
  %4123 = load <8 x i32>, ptr %frame.static.id, align 32
  %4124 = extractelement <8 x i32> %4123, i32 %4117
  %4125 = icmp eq i32 %4124, 12
  %4126 = and i1 %4122, %4125
  %4127 = and i1 %4115, %4126
  %4128 = xor i1 %4127, true
  %4129 = and i1 true, %4128
  %4130 = xor i8 %4118, -1
  %4131 = icmp ne i8 %4130, 0
  %4132 = xor i1 %4131, true
  %4133 = and i1 %4129, %4132
  br i1 %4133, label %convergence.overflow.trap694, label %convergence.overflow.resume695

varying.coherent693:                              ; preds = %schedule.33
  br i1 %761, label %varying.coherent.true698, label %varying.coherent.false699

convergence.overflow.trap694:                     ; preds = %varying.divergent692
  call void @llvm.trap()
  unreachable

convergence.overflow.resume695:                   ; preds = %varying.divergent692
  %4134 = call i8 @llvm.cttz.i8(i8 %4130, i1 false)
  %4135 = zext i8 %4134 to i32
  %4136 = select i1 %4131, i32 %4135, i32 0
  %4137 = trunc i32 %4136 to i8
  %4138 = shl i8 1, %4137
  %4139 = or i8 %4118, %4138
  %4140 = select i1 %4129, i8 %4139, i8 %4118
  store i8 %4140, ptr %frame.active, align 1
  %4141 = load <8 x i32>, ptr %frame.static.id, align 32
  %4142 = extractelement <8 x i32> %4141, i32 %4136
  %4143 = select i1 %4129, i32 12, i32 %4142
  %4144 = load <8 x i32>, ptr %frame.static.id, align 32
  %4145 = insertelement <8 x i32> %4144, i32 %4143, i32 %4136
  store <8 x i32> %4145, ptr %frame.static.id, align 32
  %4146 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4147 = extractelement <8 x i32> %4146, i32 %4136
  %4148 = select i1 %4129, i32 %4114, i32 %4147
  %4149 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4150 = insertelement <8 x i32> %4149, i32 %4148, i32 %4136
  store <8 x i32> %4150, ptr %frame.parent.token, align 32
  %4151 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4136
  %4152 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4136
  %4153 = load <8 x i1>, ptr %4151, align 1
  %4154 = load <8 x i1>, ptr %4152, align 1
  %4155 = select i1 %4129, <8 x i1> %751, <8 x i1> %4153
  store <8 x i1> %4155, ptr %4151, align 1
  %4156 = select i1 %4129, <8 x i1> zeroinitializer, <8 x i1> %4154
  store <8 x i1> %4156, ptr %4152, align 1
  %4157 = add i32 %4136, 1
  %4158 = select i1 %4127, i32 %4114, i32 %4157
  %4159 = select i1 true, i32 %4158, i32 %4114
  store i32 %4159, ptr %current.token, align 4
  %4160 = load i32, ptr %current.token, align 4
  %4161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %758)
  %4162 = load i32, ptr %ready.count, align 4
  %4163 = icmp uge i32 %4162, 8
  %4164 = and i1 %4161, %4163
  br i1 %4164, label %ready.overflow.trap696, label %ready.overflow.resume697

ready.overflow.trap696:                           ; preds = %convergence.overflow.resume695
  call void @llvm.trap()
  unreachable

ready.overflow.resume697:                         ; preds = %convergence.overflow.resume695
  %4165 = select i1 %4161, i32 %4162, i32 0
  %4166 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4165
  %4167 = load <8 x i1>, ptr %4166, align 1
  %4168 = select i1 %4161, <8 x i1> %758, <8 x i1> %4167
  store <8 x i1> %4168, ptr %4166, align 1
  %4169 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4165
  %4170 = load i32, ptr %4169, align 4
  %4171 = select i1 %4161, i32 34, i32 %4170
  store i32 %4171, ptr %4169, align 4
  %4172 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4165
  %4173 = load i32, ptr %4172, align 4
  %4174 = select i1 %4161, i32 %4160, i32 %4173
  store i32 %4174, ptr %4172, align 4
  %4175 = add i32 %4162, 1
  %4176 = select i1 %4161, i32 %4175, i32 %4162
  store i32 %4176, ptr %ready.count, align 4
  %4177 = load <8 x i1>, ptr %runnable.mask, align 1
  %4178 = or <8 x i1> %4177, %758
  store <8 x i1> %4178, ptr %runnable.mask, align 1
  store <8 x i1> %760, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true698:                         ; preds = %varying.coherent693
  store <8 x i1> %751, ptr %current.mask, align 1
  %4179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %751)
  br i1 %4179, label %schedule.34, label %scheduler.loop

varying.coherent.false699:                        ; preds = %varying.coherent693
  store <8 x i1> %751, ptr %current.mask, align 1
  %4180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %751)
  br i1 %4180, label %schedule.35, label %scheduler.loop

convergence.cascade713:                           ; preds = %convergence.cascade713, %schedule.35
  %convergence.cascade.flow717 = phi <8 x i1> [ %834, %schedule.35 ], [ %4223, %convergence.cascade713 ]
  %convergence.cascade.depth718 = phi i32 [ 0, %schedule.35 ], [ %4224, %convergence.cascade713 ]
  %4181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow717)
  %4182 = load i32, ptr %current.token, align 4
  %4183 = icmp ne i32 %4182, 0
  %4184 = and i1 %4181, %4183
  %4185 = sub i32 %4182, 1
  %4186 = select i1 %4184, i32 %4185, i32 0
  %4187 = load i8, ptr %frame.active, align 1
  %4188 = trunc i32 %4186 to i8
  %4189 = shl i8 1, %4188
  %4190 = and i8 %4187, %4189
  %4191 = icmp ne i8 %4190, 0
  %4192 = load <8 x i32>, ptr %frame.static.id, align 32
  %4193 = extractelement <8 x i32> %4192, i32 %4186
  %convergence.target.pointer719 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4193
  %convergence.dynamic.target720 = load i32, ptr %convergence.target.pointer719, align 4
  %4194 = icmp eq i32 %convergence.dynamic.target720, 35
  %4195 = and i1 %4191, %4194
  %4196 = and i1 %4184, %4195
  %4197 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4186
  %4198 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4186
  %4199 = load <8 x i1>, ptr %4197, align 1
  %4200 = load <8 x i1>, ptr %4198, align 1
  %4201 = or <8 x i1> %4200, %convergence.cascade.flow717
  %4202 = load <8 x i1>, ptr %live.mask, align 1
  %4203 = and <8 x i1> %4199, %4202
  %4204 = icmp eq <8 x i1> %4201, %4203
  %4205 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4204)
  %4206 = and i1 %4196, %4205
  %4207 = select i1 %4206, <8 x i1> zeroinitializer, <8 x i1> %4201
  %4208 = select i1 %4196, <8 x i1> %4207, <8 x i1> %4200
  store <8 x i1> %4208, ptr %4198, align 1
  %4209 = select i1 %4206, <8 x i1> zeroinitializer, <8 x i1> %4199
  store <8 x i1> %4209, ptr %4197, align 1
  %4210 = trunc i32 %4186 to i8
  %4211 = shl i8 1, %4210
  %4212 = xor i8 %4211, -1
  %4213 = and i8 %4187, %4212
  %4214 = select i1 %4206, i8 %4213, i8 %4187
  store i8 %4214, ptr %frame.active, align 1
  %.splatinsert721 = insertelement <8 x i1> poison, i1 %4196, i64 0
  %.splat722 = shufflevector <8 x i1> %.splatinsert721, <8 x i1> poison, <8 x i32> zeroinitializer
  %4215 = and <8 x i1> %convergence.cascade.flow717, %.splat722
  %4216 = load <8 x i1>, ptr %runnable.mask, align 1
  %4217 = xor <8 x i1> %4215, splat (i1 true)
  %4218 = and <8 x i1> %4216, %4217
  store <8 x i1> %4218, ptr %runnable.mask, align 1
  %.splatinsert723 = insertelement <8 x i1> poison, i1 %4206, i64 0
  %.splat724 = shufflevector <8 x i1> %.splatinsert723, <8 x i1> poison, <8 x i32> zeroinitializer
  %4219 = select <8 x i1> %.splat724, <8 x i1> %4201, <8 x i1> zeroinitializer
  %4220 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4221 = extractelement <8 x i32> %4220, i32 %4186
  %4222 = select i1 %4206, i32 %4221, i32 %4182
  store i32 %4222, ptr %current.token, align 4
  %.splatinsert725 = insertelement <8 x i1> poison, i1 %4196, i64 0
  %.splat726 = shufflevector <8 x i1> %.splatinsert725, <8 x i1> poison, <8 x i32> zeroinitializer
  %4223 = select <8 x i1> %.splat726, <8 x i1> %4219, <8 x i1> %convergence.cascade.flow717
  %4224 = add i32 %convergence.cascade.depth718, 1
  %4225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4223)
  %4226 = icmp ult i32 %4224, 8
  %4227 = and i1 %4225, %4226
  %4228 = and i1 %4196, %4227
  %convergence.parent.token727 = load i32, ptr %current.token, align 4
  %convergence.parent.present728 = icmp ne i32 %convergence.parent.token727, 0
  %4229 = and i1 %4228, %convergence.parent.present728
  br i1 %4229, label %convergence.cascade713, label %convergence.cascade.exit714

convergence.cascade.exit714:                      ; preds = %convergence.cascade713, %schedule.35
  %convergence.cascade.result729 = phi <8 x i1> [ %834, %schedule.35 ], [ %4223, %convergence.cascade713 ]
  %4230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result729)
  br i1 %4230, label %convergence.target.35.ready, label %scheduler.loop

convergence.target.35.ready:                      ; preds = %convergence.cascade.exit714
  %4231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result729)
  %4232 = bitcast <8 x i1> %convergence.cascade.result729 to i8
  %4233 = call i8 @llvm.cttz.i8(i8 %4232, i1 false)
  %4234 = zext i8 %4233 to i32
  %4235 = select i1 %4231, i32 %4234, i32 0
  %4236 = load <8 x i64>, ptr %.slot56, align 64
  %4237 = select <8 x i1> %convergence.cascade.result729, <8 x i64> zeroinitializer, <8 x i64> %4236
  store <8 x i64> %4237, ptr %.slot56, align 64
  %4238 = load <8 x float>, ptr %.slot89, align 32
  %4239 = select <8 x i1> %convergence.cascade.result729, <8 x float> zeroinitializer, <8 x float> %4238
  store <8 x float> %4239, ptr %.slot89, align 32
  %4240 = load <8 x float>, ptr %.slot90, align 32
  %4241 = select <8 x i1> %convergence.cascade.result729, <8 x float> zeroinitializer, <8 x float> %4240
  store <8 x float> %4241, ptr %.slot90, align 32
  %4242 = load <8 x float>, ptr %.slot91, align 32
  %4243 = select <8 x i1> %convergence.cascade.result729, <8 x float> zeroinitializer, <8 x float> %4242
  store <8 x float> %4243, ptr %.slot91, align 32
  %4244 = load <8 x float>, ptr %.slot92, align 32
  %4245 = select <8 x i1> %convergence.cascade.result729, <8 x float> zeroinitializer, <8 x float> %4244
  store <8 x float> %4245, ptr %.slot92, align 32
  store <8 x i1> %convergence.cascade.result729, ptr %current.mask, align 1
  %4246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result729)
  br i1 %4246, label %schedule.36, label %scheduler.loop

varying.divergent731:                             ; preds = %schedule.36
  %4247 = load i32, ptr %current.token, align 4
  %4248 = icmp ne i32 %4247, 0
  %4249 = sub i32 %4247, 1
  %4250 = select i1 %4248, i32 %4249, i32 0
  %4251 = load i8, ptr %frame.active, align 1
  %4252 = trunc i32 %4250 to i8
  %4253 = shl i8 1, %4252
  %4254 = and i8 %4251, %4253
  %4255 = icmp ne i8 %4254, 0
  %4256 = load <8 x i32>, ptr %frame.static.id, align 32
  %4257 = extractelement <8 x i32> %4256, i32 %4250
  %4258 = icmp eq i32 %4257, 13
  %4259 = and i1 %4255, %4258
  %4260 = and i1 %4248, %4259
  %4261 = xor i1 %4260, true
  %4262 = and i1 true, %4261
  %4263 = xor i8 %4251, -1
  %4264 = icmp ne i8 %4263, 0
  %4265 = xor i1 %4264, true
  %4266 = and i1 %4262, %4265
  br i1 %4266, label %convergence.overflow.trap733, label %convergence.overflow.resume734

varying.coherent732:                              ; preds = %schedule.36
  br i1 %845, label %varying.coherent.true737, label %varying.coherent.false738

convergence.overflow.trap733:                     ; preds = %varying.divergent731
  call void @llvm.trap()
  unreachable

convergence.overflow.resume734:                   ; preds = %varying.divergent731
  %4267 = call i8 @llvm.cttz.i8(i8 %4263, i1 false)
  %4268 = zext i8 %4267 to i32
  %4269 = select i1 %4264, i32 %4268, i32 0
  %4270 = trunc i32 %4269 to i8
  %4271 = shl i8 1, %4270
  %4272 = or i8 %4251, %4271
  %4273 = select i1 %4262, i8 %4272, i8 %4251
  store i8 %4273, ptr %frame.active, align 1
  %4274 = load <8 x i32>, ptr %frame.static.id, align 32
  %4275 = extractelement <8 x i32> %4274, i32 %4269
  %4276 = select i1 %4262, i32 13, i32 %4275
  %4277 = load <8 x i32>, ptr %frame.static.id, align 32
  %4278 = insertelement <8 x i32> %4277, i32 %4276, i32 %4269
  store <8 x i32> %4278, ptr %frame.static.id, align 32
  %4279 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4280 = extractelement <8 x i32> %4279, i32 %4269
  %4281 = select i1 %4262, i32 %4247, i32 %4280
  %4282 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4283 = insertelement <8 x i32> %4282, i32 %4281, i32 %4269
  store <8 x i32> %4283, ptr %frame.parent.token, align 32
  %4284 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4269
  %4285 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4269
  %4286 = load <8 x i1>, ptr %4284, align 1
  %4287 = load <8 x i1>, ptr %4285, align 1
  %4288 = select i1 %4262, <8 x i1> %835, <8 x i1> %4286
  store <8 x i1> %4288, ptr %4284, align 1
  %4289 = select i1 %4262, <8 x i1> zeroinitializer, <8 x i1> %4287
  store <8 x i1> %4289, ptr %4285, align 1
  %4290 = add i32 %4269, 1
  %4291 = select i1 %4260, i32 %4247, i32 %4290
  %4292 = select i1 true, i32 %4291, i32 %4247
  store i32 %4292, ptr %current.token, align 4
  %4293 = load i32, ptr %current.token, align 4
  %4294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %842)
  %4295 = load i32, ptr %ready.count, align 4
  %4296 = icmp uge i32 %4295, 8
  %4297 = and i1 %4294, %4296
  br i1 %4297, label %ready.overflow.trap735, label %ready.overflow.resume736

ready.overflow.trap735:                           ; preds = %convergence.overflow.resume734
  call void @llvm.trap()
  unreachable

ready.overflow.resume736:                         ; preds = %convergence.overflow.resume734
  %4298 = select i1 %4294, i32 %4295, i32 0
  %4299 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4298
  %4300 = load <8 x i1>, ptr %4299, align 1
  %4301 = select i1 %4294, <8 x i1> %842, <8 x i1> %4300
  store <8 x i1> %4301, ptr %4299, align 1
  %4302 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4298
  %4303 = load i32, ptr %4302, align 4
  %4304 = select i1 %4294, i32 37, i32 %4303
  store i32 %4304, ptr %4302, align 4
  %4305 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4298
  %4306 = load i32, ptr %4305, align 4
  %4307 = select i1 %4294, i32 %4293, i32 %4306
  store i32 %4307, ptr %4305, align 4
  %4308 = add i32 %4295, 1
  %4309 = select i1 %4294, i32 %4308, i32 %4295
  store i32 %4309, ptr %ready.count, align 4
  %4310 = load <8 x i1>, ptr %runnable.mask, align 1
  %4311 = or <8 x i1> %4310, %842
  store <8 x i1> %4311, ptr %runnable.mask, align 1
  store <8 x i1> %844, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true737:                         ; preds = %varying.coherent732
  store <8 x i1> %835, ptr %current.mask, align 1
  %4312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %835)
  br i1 %4312, label %schedule.37, label %scheduler.loop

varying.coherent.false738:                        ; preds = %varying.coherent732
  store <8 x i1> %835, ptr %current.mask, align 1
  %4313 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %835)
  br i1 %4313, label %schedule.38, label %scheduler.loop

convergence.cascade752:                           ; preds = %convergence.cascade752, %schedule.38
  %convergence.cascade.flow756 = phi <8 x i1> [ %918, %schedule.38 ], [ %4356, %convergence.cascade752 ]
  %convergence.cascade.depth757 = phi i32 [ 0, %schedule.38 ], [ %4357, %convergence.cascade752 ]
  %4314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow756)
  %4315 = load i32, ptr %current.token, align 4
  %4316 = icmp ne i32 %4315, 0
  %4317 = and i1 %4314, %4316
  %4318 = sub i32 %4315, 1
  %4319 = select i1 %4317, i32 %4318, i32 0
  %4320 = load i8, ptr %frame.active, align 1
  %4321 = trunc i32 %4319 to i8
  %4322 = shl i8 1, %4321
  %4323 = and i8 %4320, %4322
  %4324 = icmp ne i8 %4323, 0
  %4325 = load <8 x i32>, ptr %frame.static.id, align 32
  %4326 = extractelement <8 x i32> %4325, i32 %4319
  %convergence.target.pointer758 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4326
  %convergence.dynamic.target759 = load i32, ptr %convergence.target.pointer758, align 4
  %4327 = icmp eq i32 %convergence.dynamic.target759, 38
  %4328 = and i1 %4324, %4327
  %4329 = and i1 %4317, %4328
  %4330 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4319
  %4331 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4319
  %4332 = load <8 x i1>, ptr %4330, align 1
  %4333 = load <8 x i1>, ptr %4331, align 1
  %4334 = or <8 x i1> %4333, %convergence.cascade.flow756
  %4335 = load <8 x i1>, ptr %live.mask, align 1
  %4336 = and <8 x i1> %4332, %4335
  %4337 = icmp eq <8 x i1> %4334, %4336
  %4338 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4337)
  %4339 = and i1 %4329, %4338
  %4340 = select i1 %4339, <8 x i1> zeroinitializer, <8 x i1> %4334
  %4341 = select i1 %4329, <8 x i1> %4340, <8 x i1> %4333
  store <8 x i1> %4341, ptr %4331, align 1
  %4342 = select i1 %4339, <8 x i1> zeroinitializer, <8 x i1> %4332
  store <8 x i1> %4342, ptr %4330, align 1
  %4343 = trunc i32 %4319 to i8
  %4344 = shl i8 1, %4343
  %4345 = xor i8 %4344, -1
  %4346 = and i8 %4320, %4345
  %4347 = select i1 %4339, i8 %4346, i8 %4320
  store i8 %4347, ptr %frame.active, align 1
  %.splatinsert760 = insertelement <8 x i1> poison, i1 %4329, i64 0
  %.splat761 = shufflevector <8 x i1> %.splatinsert760, <8 x i1> poison, <8 x i32> zeroinitializer
  %4348 = and <8 x i1> %convergence.cascade.flow756, %.splat761
  %4349 = load <8 x i1>, ptr %runnable.mask, align 1
  %4350 = xor <8 x i1> %4348, splat (i1 true)
  %4351 = and <8 x i1> %4349, %4350
  store <8 x i1> %4351, ptr %runnable.mask, align 1
  %.splatinsert762 = insertelement <8 x i1> poison, i1 %4339, i64 0
  %.splat763 = shufflevector <8 x i1> %.splatinsert762, <8 x i1> poison, <8 x i32> zeroinitializer
  %4352 = select <8 x i1> %.splat763, <8 x i1> %4334, <8 x i1> zeroinitializer
  %4353 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4354 = extractelement <8 x i32> %4353, i32 %4319
  %4355 = select i1 %4339, i32 %4354, i32 %4315
  store i32 %4355, ptr %current.token, align 4
  %.splatinsert764 = insertelement <8 x i1> poison, i1 %4329, i64 0
  %.splat765 = shufflevector <8 x i1> %.splatinsert764, <8 x i1> poison, <8 x i32> zeroinitializer
  %4356 = select <8 x i1> %.splat765, <8 x i1> %4352, <8 x i1> %convergence.cascade.flow756
  %4357 = add i32 %convergence.cascade.depth757, 1
  %4358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4356)
  %4359 = icmp ult i32 %4357, 8
  %4360 = and i1 %4358, %4359
  %4361 = and i1 %4329, %4360
  %convergence.parent.token766 = load i32, ptr %current.token, align 4
  %convergence.parent.present767 = icmp ne i32 %convergence.parent.token766, 0
  %4362 = and i1 %4361, %convergence.parent.present767
  br i1 %4362, label %convergence.cascade752, label %convergence.cascade.exit753

convergence.cascade.exit753:                      ; preds = %convergence.cascade752, %schedule.38
  %convergence.cascade.result768 = phi <8 x i1> [ %918, %schedule.38 ], [ %4356, %convergence.cascade752 ]
  %4363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result768)
  br i1 %4363, label %convergence.target.38.ready, label %scheduler.loop

convergence.target.38.ready:                      ; preds = %convergence.cascade.exit753
  %4364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result768)
  %4365 = bitcast <8 x i1> %convergence.cascade.result768 to i8
  %4366 = call i8 @llvm.cttz.i8(i8 %4365, i1 false)
  %4367 = zext i8 %4366 to i32
  %4368 = select i1 %4364, i32 %4367, i32 0
  %4369 = load <8 x i64>, ptr %.slot56, align 64
  %4370 = select <8 x i1> %convergence.cascade.result768, <8 x i64> zeroinitializer, <8 x i64> %4369
  store <8 x i64> %4370, ptr %.slot56, align 64
  %4371 = load <8 x float>, ptr %.slot94, align 32
  %4372 = select <8 x i1> %convergence.cascade.result768, <8 x float> zeroinitializer, <8 x float> %4371
  store <8 x float> %4372, ptr %.slot94, align 32
  %4373 = load <8 x float>, ptr %.slot95, align 32
  %4374 = select <8 x i1> %convergence.cascade.result768, <8 x float> zeroinitializer, <8 x float> %4373
  store <8 x float> %4374, ptr %.slot95, align 32
  %4375 = load <8 x float>, ptr %.slot96, align 32
  %4376 = select <8 x i1> %convergence.cascade.result768, <8 x float> zeroinitializer, <8 x float> %4375
  store <8 x float> %4376, ptr %.slot96, align 32
  %4377 = load <8 x float>, ptr %.slot97, align 32
  %4378 = select <8 x i1> %convergence.cascade.result768, <8 x float> zeroinitializer, <8 x float> %4377
  store <8 x float> %4378, ptr %.slot97, align 32
  store <8 x i1> %convergence.cascade.result768, ptr %current.mask, align 1
  %4379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result768)
  br i1 %4379, label %schedule.39, label %scheduler.loop

varying.divergent770:                             ; preds = %schedule.39
  %4380 = load i32, ptr %current.token, align 4
  %4381 = icmp ne i32 %4380, 0
  %4382 = sub i32 %4380, 1
  %4383 = select i1 %4381, i32 %4382, i32 0
  %4384 = load i8, ptr %frame.active, align 1
  %4385 = trunc i32 %4383 to i8
  %4386 = shl i8 1, %4385
  %4387 = and i8 %4384, %4386
  %4388 = icmp ne i8 %4387, 0
  %4389 = load <8 x i32>, ptr %frame.static.id, align 32
  %4390 = extractelement <8 x i32> %4389, i32 %4383
  %4391 = icmp eq i32 %4390, 14
  %4392 = and i1 %4388, %4391
  %4393 = and i1 %4381, %4392
  %4394 = xor i1 %4393, true
  %4395 = and i1 true, %4394
  %4396 = xor i8 %4384, -1
  %4397 = icmp ne i8 %4396, 0
  %4398 = xor i1 %4397, true
  %4399 = and i1 %4395, %4398
  br i1 %4399, label %convergence.overflow.trap772, label %convergence.overflow.resume773

varying.coherent771:                              ; preds = %schedule.39
  br i1 %929, label %varying.coherent.true776, label %varying.coherent.false777

convergence.overflow.trap772:                     ; preds = %varying.divergent770
  call void @llvm.trap()
  unreachable

convergence.overflow.resume773:                   ; preds = %varying.divergent770
  %4400 = call i8 @llvm.cttz.i8(i8 %4396, i1 false)
  %4401 = zext i8 %4400 to i32
  %4402 = select i1 %4397, i32 %4401, i32 0
  %4403 = trunc i32 %4402 to i8
  %4404 = shl i8 1, %4403
  %4405 = or i8 %4384, %4404
  %4406 = select i1 %4395, i8 %4405, i8 %4384
  store i8 %4406, ptr %frame.active, align 1
  %4407 = load <8 x i32>, ptr %frame.static.id, align 32
  %4408 = extractelement <8 x i32> %4407, i32 %4402
  %4409 = select i1 %4395, i32 14, i32 %4408
  %4410 = load <8 x i32>, ptr %frame.static.id, align 32
  %4411 = insertelement <8 x i32> %4410, i32 %4409, i32 %4402
  store <8 x i32> %4411, ptr %frame.static.id, align 32
  %4412 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4413 = extractelement <8 x i32> %4412, i32 %4402
  %4414 = select i1 %4395, i32 %4380, i32 %4413
  %4415 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4416 = insertelement <8 x i32> %4415, i32 %4414, i32 %4402
  store <8 x i32> %4416, ptr %frame.parent.token, align 32
  %4417 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4402
  %4418 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4402
  %4419 = load <8 x i1>, ptr %4417, align 1
  %4420 = load <8 x i1>, ptr %4418, align 1
  %4421 = select i1 %4395, <8 x i1> %919, <8 x i1> %4419
  store <8 x i1> %4421, ptr %4417, align 1
  %4422 = select i1 %4395, <8 x i1> zeroinitializer, <8 x i1> %4420
  store <8 x i1> %4422, ptr %4418, align 1
  %4423 = add i32 %4402, 1
  %4424 = select i1 %4393, i32 %4380, i32 %4423
  %4425 = select i1 true, i32 %4424, i32 %4380
  store i32 %4425, ptr %current.token, align 4
  %4426 = load i32, ptr %current.token, align 4
  %4427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %926)
  %4428 = load i32, ptr %ready.count, align 4
  %4429 = icmp uge i32 %4428, 8
  %4430 = and i1 %4427, %4429
  br i1 %4430, label %ready.overflow.trap774, label %ready.overflow.resume775

ready.overflow.trap774:                           ; preds = %convergence.overflow.resume773
  call void @llvm.trap()
  unreachable

ready.overflow.resume775:                         ; preds = %convergence.overflow.resume773
  %4431 = select i1 %4427, i32 %4428, i32 0
  %4432 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4431
  %4433 = load <8 x i1>, ptr %4432, align 1
  %4434 = select i1 %4427, <8 x i1> %926, <8 x i1> %4433
  store <8 x i1> %4434, ptr %4432, align 1
  %4435 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4431
  %4436 = load i32, ptr %4435, align 4
  %4437 = select i1 %4427, i32 40, i32 %4436
  store i32 %4437, ptr %4435, align 4
  %4438 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4431
  %4439 = load i32, ptr %4438, align 4
  %4440 = select i1 %4427, i32 %4426, i32 %4439
  store i32 %4440, ptr %4438, align 4
  %4441 = add i32 %4428, 1
  %4442 = select i1 %4427, i32 %4441, i32 %4428
  store i32 %4442, ptr %ready.count, align 4
  %4443 = load <8 x i1>, ptr %runnable.mask, align 1
  %4444 = or <8 x i1> %4443, %926
  store <8 x i1> %4444, ptr %runnable.mask, align 1
  store <8 x i1> %928, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true776:                         ; preds = %varying.coherent771
  store <8 x i1> %919, ptr %current.mask, align 1
  %4445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %919)
  br i1 %4445, label %schedule.40, label %scheduler.loop

varying.coherent.false777:                        ; preds = %varying.coherent771
  store <8 x i1> %919, ptr %current.mask, align 1
  %4446 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %919)
  br i1 %4446, label %schedule.41, label %scheduler.loop

convergence.cascade791:                           ; preds = %convergence.cascade791, %schedule.41
  %convergence.cascade.flow795 = phi <8 x i1> [ %1002, %schedule.41 ], [ %4489, %convergence.cascade791 ]
  %convergence.cascade.depth796 = phi i32 [ 0, %schedule.41 ], [ %4490, %convergence.cascade791 ]
  %4447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow795)
  %4448 = load i32, ptr %current.token, align 4
  %4449 = icmp ne i32 %4448, 0
  %4450 = and i1 %4447, %4449
  %4451 = sub i32 %4448, 1
  %4452 = select i1 %4450, i32 %4451, i32 0
  %4453 = load i8, ptr %frame.active, align 1
  %4454 = trunc i32 %4452 to i8
  %4455 = shl i8 1, %4454
  %4456 = and i8 %4453, %4455
  %4457 = icmp ne i8 %4456, 0
  %4458 = load <8 x i32>, ptr %frame.static.id, align 32
  %4459 = extractelement <8 x i32> %4458, i32 %4452
  %convergence.target.pointer797 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4459
  %convergence.dynamic.target798 = load i32, ptr %convergence.target.pointer797, align 4
  %4460 = icmp eq i32 %convergence.dynamic.target798, 41
  %4461 = and i1 %4457, %4460
  %4462 = and i1 %4450, %4461
  %4463 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4452
  %4464 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4452
  %4465 = load <8 x i1>, ptr %4463, align 1
  %4466 = load <8 x i1>, ptr %4464, align 1
  %4467 = or <8 x i1> %4466, %convergence.cascade.flow795
  %4468 = load <8 x i1>, ptr %live.mask, align 1
  %4469 = and <8 x i1> %4465, %4468
  %4470 = icmp eq <8 x i1> %4467, %4469
  %4471 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4470)
  %4472 = and i1 %4462, %4471
  %4473 = select i1 %4472, <8 x i1> zeroinitializer, <8 x i1> %4467
  %4474 = select i1 %4462, <8 x i1> %4473, <8 x i1> %4466
  store <8 x i1> %4474, ptr %4464, align 1
  %4475 = select i1 %4472, <8 x i1> zeroinitializer, <8 x i1> %4465
  store <8 x i1> %4475, ptr %4463, align 1
  %4476 = trunc i32 %4452 to i8
  %4477 = shl i8 1, %4476
  %4478 = xor i8 %4477, -1
  %4479 = and i8 %4453, %4478
  %4480 = select i1 %4472, i8 %4479, i8 %4453
  store i8 %4480, ptr %frame.active, align 1
  %.splatinsert799 = insertelement <8 x i1> poison, i1 %4462, i64 0
  %.splat800 = shufflevector <8 x i1> %.splatinsert799, <8 x i1> poison, <8 x i32> zeroinitializer
  %4481 = and <8 x i1> %convergence.cascade.flow795, %.splat800
  %4482 = load <8 x i1>, ptr %runnable.mask, align 1
  %4483 = xor <8 x i1> %4481, splat (i1 true)
  %4484 = and <8 x i1> %4482, %4483
  store <8 x i1> %4484, ptr %runnable.mask, align 1
  %.splatinsert801 = insertelement <8 x i1> poison, i1 %4472, i64 0
  %.splat802 = shufflevector <8 x i1> %.splatinsert801, <8 x i1> poison, <8 x i32> zeroinitializer
  %4485 = select <8 x i1> %.splat802, <8 x i1> %4467, <8 x i1> zeroinitializer
  %4486 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4487 = extractelement <8 x i32> %4486, i32 %4452
  %4488 = select i1 %4472, i32 %4487, i32 %4448
  store i32 %4488, ptr %current.token, align 4
  %.splatinsert803 = insertelement <8 x i1> poison, i1 %4462, i64 0
  %.splat804 = shufflevector <8 x i1> %.splatinsert803, <8 x i1> poison, <8 x i32> zeroinitializer
  %4489 = select <8 x i1> %.splat804, <8 x i1> %4485, <8 x i1> %convergence.cascade.flow795
  %4490 = add i32 %convergence.cascade.depth796, 1
  %4491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4489)
  %4492 = icmp ult i32 %4490, 8
  %4493 = and i1 %4491, %4492
  %4494 = and i1 %4462, %4493
  %convergence.parent.token805 = load i32, ptr %current.token, align 4
  %convergence.parent.present806 = icmp ne i32 %convergence.parent.token805, 0
  %4495 = and i1 %4494, %convergence.parent.present806
  br i1 %4495, label %convergence.cascade791, label %convergence.cascade.exit792

convergence.cascade.exit792:                      ; preds = %convergence.cascade791, %schedule.41
  %convergence.cascade.result807 = phi <8 x i1> [ %1002, %schedule.41 ], [ %4489, %convergence.cascade791 ]
  %4496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result807)
  br i1 %4496, label %convergence.target.41.ready, label %scheduler.loop

convergence.target.41.ready:                      ; preds = %convergence.cascade.exit792
  %4497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result807)
  %4498 = bitcast <8 x i1> %convergence.cascade.result807 to i8
  %4499 = call i8 @llvm.cttz.i8(i8 %4498, i1 false)
  %4500 = zext i8 %4499 to i32
  %4501 = select i1 %4497, i32 %4500, i32 0
  %4502 = load <8 x i64>, ptr %.slot56, align 64
  %4503 = select <8 x i1> %convergence.cascade.result807, <8 x i64> zeroinitializer, <8 x i64> %4502
  store <8 x i64> %4503, ptr %.slot56, align 64
  %4504 = load <8 x float>, ptr %.slot99, align 32
  %4505 = select <8 x i1> %convergence.cascade.result807, <8 x float> zeroinitializer, <8 x float> %4504
  store <8 x float> %4505, ptr %.slot99, align 32
  %4506 = load <8 x float>, ptr %.slot100, align 32
  %4507 = select <8 x i1> %convergence.cascade.result807, <8 x float> zeroinitializer, <8 x float> %4506
  store <8 x float> %4507, ptr %.slot100, align 32
  %4508 = load <8 x float>, ptr %.slot101, align 32
  %4509 = select <8 x i1> %convergence.cascade.result807, <8 x float> zeroinitializer, <8 x float> %4508
  store <8 x float> %4509, ptr %.slot101, align 32
  %4510 = load <8 x float>, ptr %.slot102, align 32
  %4511 = select <8 x i1> %convergence.cascade.result807, <8 x float> zeroinitializer, <8 x float> %4510
  store <8 x float> %4511, ptr %.slot102, align 32
  store <8 x i1> %convergence.cascade.result807, ptr %current.mask, align 1
  %4512 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result807)
  br i1 %4512, label %schedule.42, label %scheduler.loop

varying.divergent809:                             ; preds = %schedule.42
  %4513 = load i32, ptr %current.token, align 4
  %4514 = icmp ne i32 %4513, 0
  %4515 = sub i32 %4513, 1
  %4516 = select i1 %4514, i32 %4515, i32 0
  %4517 = load i8, ptr %frame.active, align 1
  %4518 = trunc i32 %4516 to i8
  %4519 = shl i8 1, %4518
  %4520 = and i8 %4517, %4519
  %4521 = icmp ne i8 %4520, 0
  %4522 = load <8 x i32>, ptr %frame.static.id, align 32
  %4523 = extractelement <8 x i32> %4522, i32 %4516
  %4524 = icmp eq i32 %4523, 15
  %4525 = and i1 %4521, %4524
  %4526 = and i1 %4514, %4525
  %4527 = xor i1 %4526, true
  %4528 = and i1 true, %4527
  %4529 = xor i8 %4517, -1
  %4530 = icmp ne i8 %4529, 0
  %4531 = xor i1 %4530, true
  %4532 = and i1 %4528, %4531
  br i1 %4532, label %convergence.overflow.trap811, label %convergence.overflow.resume812

varying.coherent810:                              ; preds = %schedule.42
  br i1 %1013, label %varying.coherent.true815, label %varying.coherent.false816

convergence.overflow.trap811:                     ; preds = %varying.divergent809
  call void @llvm.trap()
  unreachable

convergence.overflow.resume812:                   ; preds = %varying.divergent809
  %4533 = call i8 @llvm.cttz.i8(i8 %4529, i1 false)
  %4534 = zext i8 %4533 to i32
  %4535 = select i1 %4530, i32 %4534, i32 0
  %4536 = trunc i32 %4535 to i8
  %4537 = shl i8 1, %4536
  %4538 = or i8 %4517, %4537
  %4539 = select i1 %4528, i8 %4538, i8 %4517
  store i8 %4539, ptr %frame.active, align 1
  %4540 = load <8 x i32>, ptr %frame.static.id, align 32
  %4541 = extractelement <8 x i32> %4540, i32 %4535
  %4542 = select i1 %4528, i32 15, i32 %4541
  %4543 = load <8 x i32>, ptr %frame.static.id, align 32
  %4544 = insertelement <8 x i32> %4543, i32 %4542, i32 %4535
  store <8 x i32> %4544, ptr %frame.static.id, align 32
  %4545 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4546 = extractelement <8 x i32> %4545, i32 %4535
  %4547 = select i1 %4528, i32 %4513, i32 %4546
  %4548 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4549 = insertelement <8 x i32> %4548, i32 %4547, i32 %4535
  store <8 x i32> %4549, ptr %frame.parent.token, align 32
  %4550 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4535
  %4551 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4535
  %4552 = load <8 x i1>, ptr %4550, align 1
  %4553 = load <8 x i1>, ptr %4551, align 1
  %4554 = select i1 %4528, <8 x i1> %1003, <8 x i1> %4552
  store <8 x i1> %4554, ptr %4550, align 1
  %4555 = select i1 %4528, <8 x i1> zeroinitializer, <8 x i1> %4553
  store <8 x i1> %4555, ptr %4551, align 1
  %4556 = add i32 %4535, 1
  %4557 = select i1 %4526, i32 %4513, i32 %4556
  %4558 = select i1 true, i32 %4557, i32 %4513
  store i32 %4558, ptr %current.token, align 4
  %4559 = load i32, ptr %current.token, align 4
  %4560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1010)
  %4561 = load i32, ptr %ready.count, align 4
  %4562 = icmp uge i32 %4561, 8
  %4563 = and i1 %4560, %4562
  br i1 %4563, label %ready.overflow.trap813, label %ready.overflow.resume814

ready.overflow.trap813:                           ; preds = %convergence.overflow.resume812
  call void @llvm.trap()
  unreachable

ready.overflow.resume814:                         ; preds = %convergence.overflow.resume812
  %4564 = select i1 %4560, i32 %4561, i32 0
  %4565 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4564
  %4566 = load <8 x i1>, ptr %4565, align 1
  %4567 = select i1 %4560, <8 x i1> %1010, <8 x i1> %4566
  store <8 x i1> %4567, ptr %4565, align 1
  %4568 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4564
  %4569 = load i32, ptr %4568, align 4
  %4570 = select i1 %4560, i32 43, i32 %4569
  store i32 %4570, ptr %4568, align 4
  %4571 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4564
  %4572 = load i32, ptr %4571, align 4
  %4573 = select i1 %4560, i32 %4559, i32 %4572
  store i32 %4573, ptr %4571, align 4
  %4574 = add i32 %4561, 1
  %4575 = select i1 %4560, i32 %4574, i32 %4561
  store i32 %4575, ptr %ready.count, align 4
  %4576 = load <8 x i1>, ptr %runnable.mask, align 1
  %4577 = or <8 x i1> %4576, %1010
  store <8 x i1> %4577, ptr %runnable.mask, align 1
  store <8 x i1> %1012, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true815:                         ; preds = %varying.coherent810
  store <8 x i1> %1003, ptr %current.mask, align 1
  %4578 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1003)
  br i1 %4578, label %schedule.43, label %scheduler.loop

varying.coherent.false816:                        ; preds = %varying.coherent810
  store <8 x i1> %1003, ptr %current.mask, align 1
  %4579 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1003)
  br i1 %4579, label %schedule.44, label %scheduler.loop

convergence.cascade830:                           ; preds = %convergence.cascade830, %schedule.44
  %convergence.cascade.flow834 = phi <8 x i1> [ %1086, %schedule.44 ], [ %4622, %convergence.cascade830 ]
  %convergence.cascade.depth835 = phi i32 [ 0, %schedule.44 ], [ %4623, %convergence.cascade830 ]
  %4580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow834)
  %4581 = load i32, ptr %current.token, align 4
  %4582 = icmp ne i32 %4581, 0
  %4583 = and i1 %4580, %4582
  %4584 = sub i32 %4581, 1
  %4585 = select i1 %4583, i32 %4584, i32 0
  %4586 = load i8, ptr %frame.active, align 1
  %4587 = trunc i32 %4585 to i8
  %4588 = shl i8 1, %4587
  %4589 = and i8 %4586, %4588
  %4590 = icmp ne i8 %4589, 0
  %4591 = load <8 x i32>, ptr %frame.static.id, align 32
  %4592 = extractelement <8 x i32> %4591, i32 %4585
  %convergence.target.pointer836 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4592
  %convergence.dynamic.target837 = load i32, ptr %convergence.target.pointer836, align 4
  %4593 = icmp eq i32 %convergence.dynamic.target837, 44
  %4594 = and i1 %4590, %4593
  %4595 = and i1 %4583, %4594
  %4596 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4585
  %4597 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4585
  %4598 = load <8 x i1>, ptr %4596, align 1
  %4599 = load <8 x i1>, ptr %4597, align 1
  %4600 = or <8 x i1> %4599, %convergence.cascade.flow834
  %4601 = load <8 x i1>, ptr %live.mask, align 1
  %4602 = and <8 x i1> %4598, %4601
  %4603 = icmp eq <8 x i1> %4600, %4602
  %4604 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4603)
  %4605 = and i1 %4595, %4604
  %4606 = select i1 %4605, <8 x i1> zeroinitializer, <8 x i1> %4600
  %4607 = select i1 %4595, <8 x i1> %4606, <8 x i1> %4599
  store <8 x i1> %4607, ptr %4597, align 1
  %4608 = select i1 %4605, <8 x i1> zeroinitializer, <8 x i1> %4598
  store <8 x i1> %4608, ptr %4596, align 1
  %4609 = trunc i32 %4585 to i8
  %4610 = shl i8 1, %4609
  %4611 = xor i8 %4610, -1
  %4612 = and i8 %4586, %4611
  %4613 = select i1 %4605, i8 %4612, i8 %4586
  store i8 %4613, ptr %frame.active, align 1
  %.splatinsert838 = insertelement <8 x i1> poison, i1 %4595, i64 0
  %.splat839 = shufflevector <8 x i1> %.splatinsert838, <8 x i1> poison, <8 x i32> zeroinitializer
  %4614 = and <8 x i1> %convergence.cascade.flow834, %.splat839
  %4615 = load <8 x i1>, ptr %runnable.mask, align 1
  %4616 = xor <8 x i1> %4614, splat (i1 true)
  %4617 = and <8 x i1> %4615, %4616
  store <8 x i1> %4617, ptr %runnable.mask, align 1
  %.splatinsert840 = insertelement <8 x i1> poison, i1 %4605, i64 0
  %.splat841 = shufflevector <8 x i1> %.splatinsert840, <8 x i1> poison, <8 x i32> zeroinitializer
  %4618 = select <8 x i1> %.splat841, <8 x i1> %4600, <8 x i1> zeroinitializer
  %4619 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4620 = extractelement <8 x i32> %4619, i32 %4585
  %4621 = select i1 %4605, i32 %4620, i32 %4581
  store i32 %4621, ptr %current.token, align 4
  %.splatinsert842 = insertelement <8 x i1> poison, i1 %4595, i64 0
  %.splat843 = shufflevector <8 x i1> %.splatinsert842, <8 x i1> poison, <8 x i32> zeroinitializer
  %4622 = select <8 x i1> %.splat843, <8 x i1> %4618, <8 x i1> %convergence.cascade.flow834
  %4623 = add i32 %convergence.cascade.depth835, 1
  %4624 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4622)
  %4625 = icmp ult i32 %4623, 8
  %4626 = and i1 %4624, %4625
  %4627 = and i1 %4595, %4626
  %convergence.parent.token844 = load i32, ptr %current.token, align 4
  %convergence.parent.present845 = icmp ne i32 %convergence.parent.token844, 0
  %4628 = and i1 %4627, %convergence.parent.present845
  br i1 %4628, label %convergence.cascade830, label %convergence.cascade.exit831

convergence.cascade.exit831:                      ; preds = %convergence.cascade830, %schedule.44
  %convergence.cascade.result846 = phi <8 x i1> [ %1086, %schedule.44 ], [ %4622, %convergence.cascade830 ]
  %4629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result846)
  br i1 %4629, label %convergence.target.44.ready, label %scheduler.loop

convergence.target.44.ready:                      ; preds = %convergence.cascade.exit831
  %4630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result846)
  %4631 = bitcast <8 x i1> %convergence.cascade.result846 to i8
  %4632 = call i8 @llvm.cttz.i8(i8 %4631, i1 false)
  %4633 = zext i8 %4632 to i32
  %4634 = select i1 %4630, i32 %4633, i32 0
  %4635 = load <8 x i64>, ptr %.slot56, align 64
  %4636 = select <8 x i1> %convergence.cascade.result846, <8 x i64> zeroinitializer, <8 x i64> %4635
  store <8 x i64> %4636, ptr %.slot56, align 64
  %4637 = load <8 x float>, ptr %.slot104, align 32
  %4638 = select <8 x i1> %convergence.cascade.result846, <8 x float> zeroinitializer, <8 x float> %4637
  store <8 x float> %4638, ptr %.slot104, align 32
  %4639 = load <8 x float>, ptr %.slot105, align 32
  %4640 = select <8 x i1> %convergence.cascade.result846, <8 x float> zeroinitializer, <8 x float> %4639
  store <8 x float> %4640, ptr %.slot105, align 32
  %4641 = load <8 x float>, ptr %.slot106, align 32
  %4642 = select <8 x i1> %convergence.cascade.result846, <8 x float> zeroinitializer, <8 x float> %4641
  store <8 x float> %4642, ptr %.slot106, align 32
  %4643 = load <8 x float>, ptr %.slot107, align 32
  %4644 = select <8 x i1> %convergence.cascade.result846, <8 x float> zeroinitializer, <8 x float> %4643
  store <8 x float> %4644, ptr %.slot107, align 32
  store <8 x i1> %convergence.cascade.result846, ptr %current.mask, align 1
  %4645 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result846)
  br i1 %4645, label %schedule.45, label %scheduler.loop

varying.divergent848:                             ; preds = %schedule.45
  %4646 = load i32, ptr %current.token, align 4
  %4647 = icmp ne i32 %4646, 0
  %4648 = sub i32 %4646, 1
  %4649 = select i1 %4647, i32 %4648, i32 0
  %4650 = load i8, ptr %frame.active, align 1
  %4651 = trunc i32 %4649 to i8
  %4652 = shl i8 1, %4651
  %4653 = and i8 %4650, %4652
  %4654 = icmp ne i8 %4653, 0
  %4655 = load <8 x i32>, ptr %frame.static.id, align 32
  %4656 = extractelement <8 x i32> %4655, i32 %4649
  %4657 = icmp eq i32 %4656, 16
  %4658 = and i1 %4654, %4657
  %4659 = and i1 %4647, %4658
  %4660 = xor i1 %4659, true
  %4661 = and i1 true, %4660
  %4662 = xor i8 %4650, -1
  %4663 = icmp ne i8 %4662, 0
  %4664 = xor i1 %4663, true
  %4665 = and i1 %4661, %4664
  br i1 %4665, label %convergence.overflow.trap850, label %convergence.overflow.resume851

varying.coherent849:                              ; preds = %schedule.45
  br i1 %1097, label %varying.coherent.true854, label %varying.coherent.false855

convergence.overflow.trap850:                     ; preds = %varying.divergent848
  call void @llvm.trap()
  unreachable

convergence.overflow.resume851:                   ; preds = %varying.divergent848
  %4666 = call i8 @llvm.cttz.i8(i8 %4662, i1 false)
  %4667 = zext i8 %4666 to i32
  %4668 = select i1 %4663, i32 %4667, i32 0
  %4669 = trunc i32 %4668 to i8
  %4670 = shl i8 1, %4669
  %4671 = or i8 %4650, %4670
  %4672 = select i1 %4661, i8 %4671, i8 %4650
  store i8 %4672, ptr %frame.active, align 1
  %4673 = load <8 x i32>, ptr %frame.static.id, align 32
  %4674 = extractelement <8 x i32> %4673, i32 %4668
  %4675 = select i1 %4661, i32 16, i32 %4674
  %4676 = load <8 x i32>, ptr %frame.static.id, align 32
  %4677 = insertelement <8 x i32> %4676, i32 %4675, i32 %4668
  store <8 x i32> %4677, ptr %frame.static.id, align 32
  %4678 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4679 = extractelement <8 x i32> %4678, i32 %4668
  %4680 = select i1 %4661, i32 %4646, i32 %4679
  %4681 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4682 = insertelement <8 x i32> %4681, i32 %4680, i32 %4668
  store <8 x i32> %4682, ptr %frame.parent.token, align 32
  %4683 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4668
  %4684 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4668
  %4685 = load <8 x i1>, ptr %4683, align 1
  %4686 = load <8 x i1>, ptr %4684, align 1
  %4687 = select i1 %4661, <8 x i1> %1087, <8 x i1> %4685
  store <8 x i1> %4687, ptr %4683, align 1
  %4688 = select i1 %4661, <8 x i1> zeroinitializer, <8 x i1> %4686
  store <8 x i1> %4688, ptr %4684, align 1
  %4689 = add i32 %4668, 1
  %4690 = select i1 %4659, i32 %4646, i32 %4689
  %4691 = select i1 true, i32 %4690, i32 %4646
  store i32 %4691, ptr %current.token, align 4
  %4692 = load i32, ptr %current.token, align 4
  %4693 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1094)
  %4694 = load i32, ptr %ready.count, align 4
  %4695 = icmp uge i32 %4694, 8
  %4696 = and i1 %4693, %4695
  br i1 %4696, label %ready.overflow.trap852, label %ready.overflow.resume853

ready.overflow.trap852:                           ; preds = %convergence.overflow.resume851
  call void @llvm.trap()
  unreachable

ready.overflow.resume853:                         ; preds = %convergence.overflow.resume851
  %4697 = select i1 %4693, i32 %4694, i32 0
  %4698 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4697
  %4699 = load <8 x i1>, ptr %4698, align 1
  %4700 = select i1 %4693, <8 x i1> %1094, <8 x i1> %4699
  store <8 x i1> %4700, ptr %4698, align 1
  %4701 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4697
  %4702 = load i32, ptr %4701, align 4
  %4703 = select i1 %4693, i32 46, i32 %4702
  store i32 %4703, ptr %4701, align 4
  %4704 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4697
  %4705 = load i32, ptr %4704, align 4
  %4706 = select i1 %4693, i32 %4692, i32 %4705
  store i32 %4706, ptr %4704, align 4
  %4707 = add i32 %4694, 1
  %4708 = select i1 %4693, i32 %4707, i32 %4694
  store i32 %4708, ptr %ready.count, align 4
  %4709 = load <8 x i1>, ptr %runnable.mask, align 1
  %4710 = or <8 x i1> %4709, %1094
  store <8 x i1> %4710, ptr %runnable.mask, align 1
  store <8 x i1> %1096, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true854:                         ; preds = %varying.coherent849
  store <8 x i1> %1087, ptr %current.mask, align 1
  %4711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1087)
  br i1 %4711, label %schedule.46, label %scheduler.loop

varying.coherent.false855:                        ; preds = %varying.coherent849
  store <8 x i1> %1087, ptr %current.mask, align 1
  %4712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1087)
  br i1 %4712, label %schedule.47, label %scheduler.loop

convergence.cascade869:                           ; preds = %convergence.cascade869, %schedule.47
  %convergence.cascade.flow873 = phi <8 x i1> [ %1170, %schedule.47 ], [ %4755, %convergence.cascade869 ]
  %convergence.cascade.depth874 = phi i32 [ 0, %schedule.47 ], [ %4756, %convergence.cascade869 ]
  %4713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow873)
  %4714 = load i32, ptr %current.token, align 4
  %4715 = icmp ne i32 %4714, 0
  %4716 = and i1 %4713, %4715
  %4717 = sub i32 %4714, 1
  %4718 = select i1 %4716, i32 %4717, i32 0
  %4719 = load i8, ptr %frame.active, align 1
  %4720 = trunc i32 %4718 to i8
  %4721 = shl i8 1, %4720
  %4722 = and i8 %4719, %4721
  %4723 = icmp ne i8 %4722, 0
  %4724 = load <8 x i32>, ptr %frame.static.id, align 32
  %4725 = extractelement <8 x i32> %4724, i32 %4718
  %convergence.target.pointer875 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4725
  %convergence.dynamic.target876 = load i32, ptr %convergence.target.pointer875, align 4
  %4726 = icmp eq i32 %convergence.dynamic.target876, 47
  %4727 = and i1 %4723, %4726
  %4728 = and i1 %4716, %4727
  %4729 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4718
  %4730 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4718
  %4731 = load <8 x i1>, ptr %4729, align 1
  %4732 = load <8 x i1>, ptr %4730, align 1
  %4733 = or <8 x i1> %4732, %convergence.cascade.flow873
  %4734 = load <8 x i1>, ptr %live.mask, align 1
  %4735 = and <8 x i1> %4731, %4734
  %4736 = icmp eq <8 x i1> %4733, %4735
  %4737 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4736)
  %4738 = and i1 %4728, %4737
  %4739 = select i1 %4738, <8 x i1> zeroinitializer, <8 x i1> %4733
  %4740 = select i1 %4728, <8 x i1> %4739, <8 x i1> %4732
  store <8 x i1> %4740, ptr %4730, align 1
  %4741 = select i1 %4738, <8 x i1> zeroinitializer, <8 x i1> %4731
  store <8 x i1> %4741, ptr %4729, align 1
  %4742 = trunc i32 %4718 to i8
  %4743 = shl i8 1, %4742
  %4744 = xor i8 %4743, -1
  %4745 = and i8 %4719, %4744
  %4746 = select i1 %4738, i8 %4745, i8 %4719
  store i8 %4746, ptr %frame.active, align 1
  %.splatinsert877 = insertelement <8 x i1> poison, i1 %4728, i64 0
  %.splat878 = shufflevector <8 x i1> %.splatinsert877, <8 x i1> poison, <8 x i32> zeroinitializer
  %4747 = and <8 x i1> %convergence.cascade.flow873, %.splat878
  %4748 = load <8 x i1>, ptr %runnable.mask, align 1
  %4749 = xor <8 x i1> %4747, splat (i1 true)
  %4750 = and <8 x i1> %4748, %4749
  store <8 x i1> %4750, ptr %runnable.mask, align 1
  %.splatinsert879 = insertelement <8 x i1> poison, i1 %4738, i64 0
  %.splat880 = shufflevector <8 x i1> %.splatinsert879, <8 x i1> poison, <8 x i32> zeroinitializer
  %4751 = select <8 x i1> %.splat880, <8 x i1> %4733, <8 x i1> zeroinitializer
  %4752 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4753 = extractelement <8 x i32> %4752, i32 %4718
  %4754 = select i1 %4738, i32 %4753, i32 %4714
  store i32 %4754, ptr %current.token, align 4
  %.splatinsert881 = insertelement <8 x i1> poison, i1 %4728, i64 0
  %.splat882 = shufflevector <8 x i1> %.splatinsert881, <8 x i1> poison, <8 x i32> zeroinitializer
  %4755 = select <8 x i1> %.splat882, <8 x i1> %4751, <8 x i1> %convergence.cascade.flow873
  %4756 = add i32 %convergence.cascade.depth874, 1
  %4757 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4755)
  %4758 = icmp ult i32 %4756, 8
  %4759 = and i1 %4757, %4758
  %4760 = and i1 %4728, %4759
  %convergence.parent.token883 = load i32, ptr %current.token, align 4
  %convergence.parent.present884 = icmp ne i32 %convergence.parent.token883, 0
  %4761 = and i1 %4760, %convergence.parent.present884
  br i1 %4761, label %convergence.cascade869, label %convergence.cascade.exit870

convergence.cascade.exit870:                      ; preds = %convergence.cascade869, %schedule.47
  %convergence.cascade.result885 = phi <8 x i1> [ %1170, %schedule.47 ], [ %4755, %convergence.cascade869 ]
  %4762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result885)
  br i1 %4762, label %convergence.target.47.ready, label %scheduler.loop

convergence.target.47.ready:                      ; preds = %convergence.cascade.exit870
  %4763 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result885)
  %4764 = bitcast <8 x i1> %convergence.cascade.result885 to i8
  %4765 = call i8 @llvm.cttz.i8(i8 %4764, i1 false)
  %4766 = zext i8 %4765 to i32
  %4767 = select i1 %4763, i32 %4766, i32 0
  %4768 = load <8 x i64>, ptr %.slot56, align 64
  %4769 = select <8 x i1> %convergence.cascade.result885, <8 x i64> zeroinitializer, <8 x i64> %4768
  store <8 x i64> %4769, ptr %.slot56, align 64
  %4770 = load <8 x float>, ptr %.slot109, align 32
  %4771 = select <8 x i1> %convergence.cascade.result885, <8 x float> zeroinitializer, <8 x float> %4770
  store <8 x float> %4771, ptr %.slot109, align 32
  %4772 = load <8 x float>, ptr %.slot110, align 32
  %4773 = select <8 x i1> %convergence.cascade.result885, <8 x float> zeroinitializer, <8 x float> %4772
  store <8 x float> %4773, ptr %.slot110, align 32
  %4774 = load <8 x float>, ptr %.slot111, align 32
  %4775 = select <8 x i1> %convergence.cascade.result885, <8 x float> zeroinitializer, <8 x float> %4774
  store <8 x float> %4775, ptr %.slot111, align 32
  %4776 = load <8 x float>, ptr %.slot112, align 32
  %4777 = select <8 x i1> %convergence.cascade.result885, <8 x float> zeroinitializer, <8 x float> %4776
  store <8 x float> %4777, ptr %.slot112, align 32
  store <8 x i1> %convergence.cascade.result885, ptr %current.mask, align 1
  %4778 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result885)
  br i1 %4778, label %schedule.48, label %scheduler.loop

varying.divergent887:                             ; preds = %schedule.48
  %4779 = load i32, ptr %current.token, align 4
  %4780 = icmp ne i32 %4779, 0
  %4781 = sub i32 %4779, 1
  %4782 = select i1 %4780, i32 %4781, i32 0
  %4783 = load i8, ptr %frame.active, align 1
  %4784 = trunc i32 %4782 to i8
  %4785 = shl i8 1, %4784
  %4786 = and i8 %4783, %4785
  %4787 = icmp ne i8 %4786, 0
  %4788 = load <8 x i32>, ptr %frame.static.id, align 32
  %4789 = extractelement <8 x i32> %4788, i32 %4782
  %4790 = icmp eq i32 %4789, 17
  %4791 = and i1 %4787, %4790
  %4792 = and i1 %4780, %4791
  %4793 = xor i1 %4792, true
  %4794 = and i1 true, %4793
  %4795 = xor i8 %4783, -1
  %4796 = icmp ne i8 %4795, 0
  %4797 = xor i1 %4796, true
  %4798 = and i1 %4794, %4797
  br i1 %4798, label %convergence.overflow.trap889, label %convergence.overflow.resume890

varying.coherent888:                              ; preds = %schedule.48
  br i1 %1181, label %varying.coherent.true893, label %varying.coherent.false894

convergence.overflow.trap889:                     ; preds = %varying.divergent887
  call void @llvm.trap()
  unreachable

convergence.overflow.resume890:                   ; preds = %varying.divergent887
  %4799 = call i8 @llvm.cttz.i8(i8 %4795, i1 false)
  %4800 = zext i8 %4799 to i32
  %4801 = select i1 %4796, i32 %4800, i32 0
  %4802 = trunc i32 %4801 to i8
  %4803 = shl i8 1, %4802
  %4804 = or i8 %4783, %4803
  %4805 = select i1 %4794, i8 %4804, i8 %4783
  store i8 %4805, ptr %frame.active, align 1
  %4806 = load <8 x i32>, ptr %frame.static.id, align 32
  %4807 = extractelement <8 x i32> %4806, i32 %4801
  %4808 = select i1 %4794, i32 17, i32 %4807
  %4809 = load <8 x i32>, ptr %frame.static.id, align 32
  %4810 = insertelement <8 x i32> %4809, i32 %4808, i32 %4801
  store <8 x i32> %4810, ptr %frame.static.id, align 32
  %4811 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4812 = extractelement <8 x i32> %4811, i32 %4801
  %4813 = select i1 %4794, i32 %4779, i32 %4812
  %4814 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4815 = insertelement <8 x i32> %4814, i32 %4813, i32 %4801
  store <8 x i32> %4815, ptr %frame.parent.token, align 32
  %4816 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4801
  %4817 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4801
  %4818 = load <8 x i1>, ptr %4816, align 1
  %4819 = load <8 x i1>, ptr %4817, align 1
  %4820 = select i1 %4794, <8 x i1> %1171, <8 x i1> %4818
  store <8 x i1> %4820, ptr %4816, align 1
  %4821 = select i1 %4794, <8 x i1> zeroinitializer, <8 x i1> %4819
  store <8 x i1> %4821, ptr %4817, align 1
  %4822 = add i32 %4801, 1
  %4823 = select i1 %4792, i32 %4779, i32 %4822
  %4824 = select i1 true, i32 %4823, i32 %4779
  store i32 %4824, ptr %current.token, align 4
  %4825 = load i32, ptr %current.token, align 4
  %4826 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1178)
  %4827 = load i32, ptr %ready.count, align 4
  %4828 = icmp uge i32 %4827, 8
  %4829 = and i1 %4826, %4828
  br i1 %4829, label %ready.overflow.trap891, label %ready.overflow.resume892

ready.overflow.trap891:                           ; preds = %convergence.overflow.resume890
  call void @llvm.trap()
  unreachable

ready.overflow.resume892:                         ; preds = %convergence.overflow.resume890
  %4830 = select i1 %4826, i32 %4827, i32 0
  %4831 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4830
  %4832 = load <8 x i1>, ptr %4831, align 1
  %4833 = select i1 %4826, <8 x i1> %1178, <8 x i1> %4832
  store <8 x i1> %4833, ptr %4831, align 1
  %4834 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4830
  %4835 = load i32, ptr %4834, align 4
  %4836 = select i1 %4826, i32 49, i32 %4835
  store i32 %4836, ptr %4834, align 4
  %4837 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4830
  %4838 = load i32, ptr %4837, align 4
  %4839 = select i1 %4826, i32 %4825, i32 %4838
  store i32 %4839, ptr %4837, align 4
  %4840 = add i32 %4827, 1
  %4841 = select i1 %4826, i32 %4840, i32 %4827
  store i32 %4841, ptr %ready.count, align 4
  %4842 = load <8 x i1>, ptr %runnable.mask, align 1
  %4843 = or <8 x i1> %4842, %1178
  store <8 x i1> %4843, ptr %runnable.mask, align 1
  store <8 x i1> %1180, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true893:                         ; preds = %varying.coherent888
  store <8 x i1> %1171, ptr %current.mask, align 1
  %4844 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1171)
  br i1 %4844, label %schedule.49, label %scheduler.loop

varying.coherent.false894:                        ; preds = %varying.coherent888
  store <8 x i1> %1171, ptr %current.mask, align 1
  %4845 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1171)
  br i1 %4845, label %schedule.50, label %scheduler.loop

convergence.cascade906:                           ; preds = %convergence.cascade906, %schedule.50
  %convergence.cascade.flow910 = phi <8 x i1> [ %1252, %schedule.50 ], [ %4888, %convergence.cascade906 ]
  %convergence.cascade.depth911 = phi i32 [ 0, %schedule.50 ], [ %4889, %convergence.cascade906 ]
  %4846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow910)
  %4847 = load i32, ptr %current.token, align 4
  %4848 = icmp ne i32 %4847, 0
  %4849 = and i1 %4846, %4848
  %4850 = sub i32 %4847, 1
  %4851 = select i1 %4849, i32 %4850, i32 0
  %4852 = load i8, ptr %frame.active, align 1
  %4853 = trunc i32 %4851 to i8
  %4854 = shl i8 1, %4853
  %4855 = and i8 %4852, %4854
  %4856 = icmp ne i8 %4855, 0
  %4857 = load <8 x i32>, ptr %frame.static.id, align 32
  %4858 = extractelement <8 x i32> %4857, i32 %4851
  %convergence.target.pointer912 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4858
  %convergence.dynamic.target913 = load i32, ptr %convergence.target.pointer912, align 4
  %4859 = icmp eq i32 %convergence.dynamic.target913, 50
  %4860 = and i1 %4856, %4859
  %4861 = and i1 %4849, %4860
  %4862 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4851
  %4863 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4851
  %4864 = load <8 x i1>, ptr %4862, align 1
  %4865 = load <8 x i1>, ptr %4863, align 1
  %4866 = or <8 x i1> %4865, %convergence.cascade.flow910
  %4867 = load <8 x i1>, ptr %live.mask, align 1
  %4868 = and <8 x i1> %4864, %4867
  %4869 = icmp eq <8 x i1> %4866, %4868
  %4870 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4869)
  %4871 = and i1 %4861, %4870
  %4872 = select i1 %4871, <8 x i1> zeroinitializer, <8 x i1> %4866
  %4873 = select i1 %4861, <8 x i1> %4872, <8 x i1> %4865
  store <8 x i1> %4873, ptr %4863, align 1
  %4874 = select i1 %4871, <8 x i1> zeroinitializer, <8 x i1> %4864
  store <8 x i1> %4874, ptr %4862, align 1
  %4875 = trunc i32 %4851 to i8
  %4876 = shl i8 1, %4875
  %4877 = xor i8 %4876, -1
  %4878 = and i8 %4852, %4877
  %4879 = select i1 %4871, i8 %4878, i8 %4852
  store i8 %4879, ptr %frame.active, align 1
  %.splatinsert914 = insertelement <8 x i1> poison, i1 %4861, i64 0
  %.splat915 = shufflevector <8 x i1> %.splatinsert914, <8 x i1> poison, <8 x i32> zeroinitializer
  %4880 = and <8 x i1> %convergence.cascade.flow910, %.splat915
  %4881 = load <8 x i1>, ptr %runnable.mask, align 1
  %4882 = xor <8 x i1> %4880, splat (i1 true)
  %4883 = and <8 x i1> %4881, %4882
  store <8 x i1> %4883, ptr %runnable.mask, align 1
  %.splatinsert916 = insertelement <8 x i1> poison, i1 %4871, i64 0
  %.splat917 = shufflevector <8 x i1> %.splatinsert916, <8 x i1> poison, <8 x i32> zeroinitializer
  %4884 = select <8 x i1> %.splat917, <8 x i1> %4866, <8 x i1> zeroinitializer
  %4885 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4886 = extractelement <8 x i32> %4885, i32 %4851
  %4887 = select i1 %4871, i32 %4886, i32 %4847
  store i32 %4887, ptr %current.token, align 4
  %.splatinsert918 = insertelement <8 x i1> poison, i1 %4861, i64 0
  %.splat919 = shufflevector <8 x i1> %.splatinsert918, <8 x i1> poison, <8 x i32> zeroinitializer
  %4888 = select <8 x i1> %.splat919, <8 x i1> %4884, <8 x i1> %convergence.cascade.flow910
  %4889 = add i32 %convergence.cascade.depth911, 1
  %4890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4888)
  %4891 = icmp ult i32 %4889, 8
  %4892 = and i1 %4890, %4891
  %4893 = and i1 %4861, %4892
  %convergence.parent.token920 = load i32, ptr %current.token, align 4
  %convergence.parent.present921 = icmp ne i32 %convergence.parent.token920, 0
  %4894 = and i1 %4893, %convergence.parent.present921
  br i1 %4894, label %convergence.cascade906, label %convergence.cascade.exit907

convergence.cascade.exit907:                      ; preds = %convergence.cascade906, %schedule.50
  %convergence.cascade.result922 = phi <8 x i1> [ %1252, %schedule.50 ], [ %4888, %convergence.cascade906 ]
  %4895 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result922)
  br i1 %4895, label %convergence.target.50.ready, label %scheduler.loop

convergence.target.50.ready:                      ; preds = %convergence.cascade.exit907
  %4896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result922)
  %4897 = bitcast <8 x i1> %convergence.cascade.result922 to i8
  %4898 = call i8 @llvm.cttz.i8(i8 %4897, i1 false)
  %4899 = zext i8 %4898 to i32
  %4900 = select i1 %4896, i32 %4899, i32 0
  %4901 = load <8 x i64>, ptr %.slot56, align 64
  %4902 = select <8 x i1> %convergence.cascade.result922, <8 x i64> zeroinitializer, <8 x i64> %4901
  store <8 x i64> %4902, ptr %.slot56, align 64
  %4903 = load <8 x float>, ptr %.slot114, align 32
  %4904 = select <8 x i1> %convergence.cascade.result922, <8 x float> zeroinitializer, <8 x float> %4903
  store <8 x float> %4904, ptr %.slot114, align 32
  %4905 = load <8 x float>, ptr %.slot115, align 32
  %4906 = select <8 x i1> %convergence.cascade.result922, <8 x float> zeroinitializer, <8 x float> %4905
  store <8 x float> %4906, ptr %.slot115, align 32
  %4907 = load <8 x float>, ptr %.slot116, align 32
  %4908 = select <8 x i1> %convergence.cascade.result922, <8 x float> zeroinitializer, <8 x float> %4907
  store <8 x float> %4908, ptr %.slot116, align 32
  %4909 = load <8 x float>, ptr %.slot117, align 32
  %4910 = select <8 x i1> %convergence.cascade.result922, <8 x float> zeroinitializer, <8 x float> %4909
  store <8 x float> %4910, ptr %.slot117, align 32
  store <8 x i1> %convergence.cascade.result922, ptr %current.mask, align 1
  %4911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result922)
  br i1 %4911, label %schedule.51, label %scheduler.loop

varying.divergent924:                             ; preds = %schedule.51
  %4912 = load i32, ptr %current.token, align 4
  %4913 = icmp ne i32 %4912, 0
  %4914 = sub i32 %4912, 1
  %4915 = select i1 %4913, i32 %4914, i32 0
  %4916 = load i8, ptr %frame.active, align 1
  %4917 = trunc i32 %4915 to i8
  %4918 = shl i8 1, %4917
  %4919 = and i8 %4916, %4918
  %4920 = icmp ne i8 %4919, 0
  %4921 = load <8 x i32>, ptr %frame.static.id, align 32
  %4922 = extractelement <8 x i32> %4921, i32 %4915
  %4923 = icmp eq i32 %4922, 18
  %4924 = and i1 %4920, %4923
  %4925 = and i1 %4913, %4924
  %4926 = xor i1 %4925, true
  %4927 = and i1 true, %4926
  %4928 = xor i8 %4916, -1
  %4929 = icmp ne i8 %4928, 0
  %4930 = xor i1 %4929, true
  %4931 = and i1 %4927, %4930
  br i1 %4931, label %convergence.overflow.trap926, label %convergence.overflow.resume927

varying.coherent925:                              ; preds = %schedule.51
  br i1 %1263, label %varying.coherent.true930, label %varying.coherent.false931

convergence.overflow.trap926:                     ; preds = %varying.divergent924
  call void @llvm.trap()
  unreachable

convergence.overflow.resume927:                   ; preds = %varying.divergent924
  %4932 = call i8 @llvm.cttz.i8(i8 %4928, i1 false)
  %4933 = zext i8 %4932 to i32
  %4934 = select i1 %4929, i32 %4933, i32 0
  %4935 = trunc i32 %4934 to i8
  %4936 = shl i8 1, %4935
  %4937 = or i8 %4916, %4936
  %4938 = select i1 %4927, i8 %4937, i8 %4916
  store i8 %4938, ptr %frame.active, align 1
  %4939 = load <8 x i32>, ptr %frame.static.id, align 32
  %4940 = extractelement <8 x i32> %4939, i32 %4934
  %4941 = select i1 %4927, i32 18, i32 %4940
  %4942 = load <8 x i32>, ptr %frame.static.id, align 32
  %4943 = insertelement <8 x i32> %4942, i32 %4941, i32 %4934
  store <8 x i32> %4943, ptr %frame.static.id, align 32
  %4944 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4945 = extractelement <8 x i32> %4944, i32 %4934
  %4946 = select i1 %4927, i32 %4912, i32 %4945
  %4947 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4948 = insertelement <8 x i32> %4947, i32 %4946, i32 %4934
  store <8 x i32> %4948, ptr %frame.parent.token, align 32
  %4949 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4934
  %4950 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4934
  %4951 = load <8 x i1>, ptr %4949, align 1
  %4952 = load <8 x i1>, ptr %4950, align 1
  %4953 = select i1 %4927, <8 x i1> %1253, <8 x i1> %4951
  store <8 x i1> %4953, ptr %4949, align 1
  %4954 = select i1 %4927, <8 x i1> zeroinitializer, <8 x i1> %4952
  store <8 x i1> %4954, ptr %4950, align 1
  %4955 = add i32 %4934, 1
  %4956 = select i1 %4925, i32 %4912, i32 %4955
  %4957 = select i1 true, i32 %4956, i32 %4912
  store i32 %4957, ptr %current.token, align 4
  %4958 = load i32, ptr %current.token, align 4
  %4959 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1260)
  %4960 = load i32, ptr %ready.count, align 4
  %4961 = icmp uge i32 %4960, 8
  %4962 = and i1 %4959, %4961
  br i1 %4962, label %ready.overflow.trap928, label %ready.overflow.resume929

ready.overflow.trap928:                           ; preds = %convergence.overflow.resume927
  call void @llvm.trap()
  unreachable

ready.overflow.resume929:                         ; preds = %convergence.overflow.resume927
  %4963 = select i1 %4959, i32 %4960, i32 0
  %4964 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4963
  %4965 = load <8 x i1>, ptr %4964, align 1
  %4966 = select i1 %4959, <8 x i1> %1260, <8 x i1> %4965
  store <8 x i1> %4966, ptr %4964, align 1
  %4967 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4963
  %4968 = load i32, ptr %4967, align 4
  %4969 = select i1 %4959, i32 52, i32 %4968
  store i32 %4969, ptr %4967, align 4
  %4970 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4963
  %4971 = load i32, ptr %4970, align 4
  %4972 = select i1 %4959, i32 %4958, i32 %4971
  store i32 %4972, ptr %4970, align 4
  %4973 = add i32 %4960, 1
  %4974 = select i1 %4959, i32 %4973, i32 %4960
  store i32 %4974, ptr %ready.count, align 4
  %4975 = load <8 x i1>, ptr %runnable.mask, align 1
  %4976 = or <8 x i1> %4975, %1260
  store <8 x i1> %4976, ptr %runnable.mask, align 1
  store <8 x i1> %1262, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true930:                         ; preds = %varying.coherent925
  store <8 x i1> %1253, ptr %current.mask, align 1
  %4977 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1253)
  br i1 %4977, label %schedule.52, label %scheduler.loop

varying.coherent.false931:                        ; preds = %varying.coherent925
  store <8 x i1> %1253, ptr %current.mask, align 1
  %4978 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1253)
  br i1 %4978, label %schedule.53, label %scheduler.loop

convergence.cascade945:                           ; preds = %convergence.cascade945, %schedule.53
  %convergence.cascade.flow949 = phi <8 x i1> [ %1336, %schedule.53 ], [ %5021, %convergence.cascade945 ]
  %convergence.cascade.depth950 = phi i32 [ 0, %schedule.53 ], [ %5022, %convergence.cascade945 ]
  %4979 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow949)
  %4980 = load i32, ptr %current.token, align 4
  %4981 = icmp ne i32 %4980, 0
  %4982 = and i1 %4979, %4981
  %4983 = sub i32 %4980, 1
  %4984 = select i1 %4982, i32 %4983, i32 0
  %4985 = load i8, ptr %frame.active, align 1
  %4986 = trunc i32 %4984 to i8
  %4987 = shl i8 1, %4986
  %4988 = and i8 %4985, %4987
  %4989 = icmp ne i8 %4988, 0
  %4990 = load <8 x i32>, ptr %frame.static.id, align 32
  %4991 = extractelement <8 x i32> %4990, i32 %4984
  %convergence.target.pointer951 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %4991
  %convergence.dynamic.target952 = load i32, ptr %convergence.target.pointer951, align 4
  %4992 = icmp eq i32 %convergence.dynamic.target952, 53
  %4993 = and i1 %4989, %4992
  %4994 = and i1 %4982, %4993
  %4995 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4984
  %4996 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4984
  %4997 = load <8 x i1>, ptr %4995, align 1
  %4998 = load <8 x i1>, ptr %4996, align 1
  %4999 = or <8 x i1> %4998, %convergence.cascade.flow949
  %5000 = load <8 x i1>, ptr %live.mask, align 1
  %5001 = and <8 x i1> %4997, %5000
  %5002 = icmp eq <8 x i1> %4999, %5001
  %5003 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5002)
  %5004 = and i1 %4994, %5003
  %5005 = select i1 %5004, <8 x i1> zeroinitializer, <8 x i1> %4999
  %5006 = select i1 %4994, <8 x i1> %5005, <8 x i1> %4998
  store <8 x i1> %5006, ptr %4996, align 1
  %5007 = select i1 %5004, <8 x i1> zeroinitializer, <8 x i1> %4997
  store <8 x i1> %5007, ptr %4995, align 1
  %5008 = trunc i32 %4984 to i8
  %5009 = shl i8 1, %5008
  %5010 = xor i8 %5009, -1
  %5011 = and i8 %4985, %5010
  %5012 = select i1 %5004, i8 %5011, i8 %4985
  store i8 %5012, ptr %frame.active, align 1
  %.splatinsert953 = insertelement <8 x i1> poison, i1 %4994, i64 0
  %.splat954 = shufflevector <8 x i1> %.splatinsert953, <8 x i1> poison, <8 x i32> zeroinitializer
  %5013 = and <8 x i1> %convergence.cascade.flow949, %.splat954
  %5014 = load <8 x i1>, ptr %runnable.mask, align 1
  %5015 = xor <8 x i1> %5013, splat (i1 true)
  %5016 = and <8 x i1> %5014, %5015
  store <8 x i1> %5016, ptr %runnable.mask, align 1
  %.splatinsert955 = insertelement <8 x i1> poison, i1 %5004, i64 0
  %.splat956 = shufflevector <8 x i1> %.splatinsert955, <8 x i1> poison, <8 x i32> zeroinitializer
  %5017 = select <8 x i1> %.splat956, <8 x i1> %4999, <8 x i1> zeroinitializer
  %5018 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5019 = extractelement <8 x i32> %5018, i32 %4984
  %5020 = select i1 %5004, i32 %5019, i32 %4980
  store i32 %5020, ptr %current.token, align 4
  %.splatinsert957 = insertelement <8 x i1> poison, i1 %4994, i64 0
  %.splat958 = shufflevector <8 x i1> %.splatinsert957, <8 x i1> poison, <8 x i32> zeroinitializer
  %5021 = select <8 x i1> %.splat958, <8 x i1> %5017, <8 x i1> %convergence.cascade.flow949
  %5022 = add i32 %convergence.cascade.depth950, 1
  %5023 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5021)
  %5024 = icmp ult i32 %5022, 8
  %5025 = and i1 %5023, %5024
  %5026 = and i1 %4994, %5025
  %convergence.parent.token959 = load i32, ptr %current.token, align 4
  %convergence.parent.present960 = icmp ne i32 %convergence.parent.token959, 0
  %5027 = and i1 %5026, %convergence.parent.present960
  br i1 %5027, label %convergence.cascade945, label %convergence.cascade.exit946

convergence.cascade.exit946:                      ; preds = %convergence.cascade945, %schedule.53
  %convergence.cascade.result961 = phi <8 x i1> [ %1336, %schedule.53 ], [ %5021, %convergence.cascade945 ]
  %5028 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result961)
  br i1 %5028, label %convergence.target.53.ready, label %scheduler.loop

convergence.target.53.ready:                      ; preds = %convergence.cascade.exit946
  %5029 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result961)
  %5030 = bitcast <8 x i1> %convergence.cascade.result961 to i8
  %5031 = call i8 @llvm.cttz.i8(i8 %5030, i1 false)
  %5032 = zext i8 %5031 to i32
  %5033 = select i1 %5029, i32 %5032, i32 0
  %5034 = load <8 x i64>, ptr %.slot56, align 64
  %5035 = select <8 x i1> %convergence.cascade.result961, <8 x i64> zeroinitializer, <8 x i64> %5034
  store <8 x i64> %5035, ptr %.slot56, align 64
  %5036 = load <8 x float>, ptr %.slot119, align 32
  %5037 = select <8 x i1> %convergence.cascade.result961, <8 x float> zeroinitializer, <8 x float> %5036
  store <8 x float> %5037, ptr %.slot119, align 32
  %5038 = load <8 x float>, ptr %.slot120, align 32
  %5039 = select <8 x i1> %convergence.cascade.result961, <8 x float> zeroinitializer, <8 x float> %5038
  store <8 x float> %5039, ptr %.slot120, align 32
  %5040 = load <8 x float>, ptr %.slot121, align 32
  %5041 = select <8 x i1> %convergence.cascade.result961, <8 x float> zeroinitializer, <8 x float> %5040
  store <8 x float> %5041, ptr %.slot121, align 32
  %5042 = load <8 x float>, ptr %.slot122, align 32
  %5043 = select <8 x i1> %convergence.cascade.result961, <8 x float> zeroinitializer, <8 x float> %5042
  store <8 x float> %5043, ptr %.slot122, align 32
  store <8 x i1> %convergence.cascade.result961, ptr %current.mask, align 1
  %5044 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result961)
  br i1 %5044, label %schedule.54, label %scheduler.loop

varying.divergent963:                             ; preds = %schedule.54
  %5045 = load i32, ptr %current.token, align 4
  %5046 = icmp ne i32 %5045, 0
  %5047 = sub i32 %5045, 1
  %5048 = select i1 %5046, i32 %5047, i32 0
  %5049 = load i8, ptr %frame.active, align 1
  %5050 = trunc i32 %5048 to i8
  %5051 = shl i8 1, %5050
  %5052 = and i8 %5049, %5051
  %5053 = icmp ne i8 %5052, 0
  %5054 = load <8 x i32>, ptr %frame.static.id, align 32
  %5055 = extractelement <8 x i32> %5054, i32 %5048
  %5056 = icmp eq i32 %5055, 19
  %5057 = and i1 %5053, %5056
  %5058 = and i1 %5046, %5057
  %5059 = xor i1 %5058, true
  %5060 = and i1 true, %5059
  %5061 = xor i8 %5049, -1
  %5062 = icmp ne i8 %5061, 0
  %5063 = xor i1 %5062, true
  %5064 = and i1 %5060, %5063
  br i1 %5064, label %convergence.overflow.trap965, label %convergence.overflow.resume966

varying.coherent964:                              ; preds = %schedule.54
  br i1 %1347, label %varying.coherent.true969, label %varying.coherent.false970

convergence.overflow.trap965:                     ; preds = %varying.divergent963
  call void @llvm.trap()
  unreachable

convergence.overflow.resume966:                   ; preds = %varying.divergent963
  %5065 = call i8 @llvm.cttz.i8(i8 %5061, i1 false)
  %5066 = zext i8 %5065 to i32
  %5067 = select i1 %5062, i32 %5066, i32 0
  %5068 = trunc i32 %5067 to i8
  %5069 = shl i8 1, %5068
  %5070 = or i8 %5049, %5069
  %5071 = select i1 %5060, i8 %5070, i8 %5049
  store i8 %5071, ptr %frame.active, align 1
  %5072 = load <8 x i32>, ptr %frame.static.id, align 32
  %5073 = extractelement <8 x i32> %5072, i32 %5067
  %5074 = select i1 %5060, i32 19, i32 %5073
  %5075 = load <8 x i32>, ptr %frame.static.id, align 32
  %5076 = insertelement <8 x i32> %5075, i32 %5074, i32 %5067
  store <8 x i32> %5076, ptr %frame.static.id, align 32
  %5077 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5078 = extractelement <8 x i32> %5077, i32 %5067
  %5079 = select i1 %5060, i32 %5045, i32 %5078
  %5080 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5081 = insertelement <8 x i32> %5080, i32 %5079, i32 %5067
  store <8 x i32> %5081, ptr %frame.parent.token, align 32
  %5082 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5067
  %5083 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5067
  %5084 = load <8 x i1>, ptr %5082, align 1
  %5085 = load <8 x i1>, ptr %5083, align 1
  %5086 = select i1 %5060, <8 x i1> %1337, <8 x i1> %5084
  store <8 x i1> %5086, ptr %5082, align 1
  %5087 = select i1 %5060, <8 x i1> zeroinitializer, <8 x i1> %5085
  store <8 x i1> %5087, ptr %5083, align 1
  %5088 = add i32 %5067, 1
  %5089 = select i1 %5058, i32 %5045, i32 %5088
  %5090 = select i1 true, i32 %5089, i32 %5045
  store i32 %5090, ptr %current.token, align 4
  %5091 = load i32, ptr %current.token, align 4
  %5092 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1344)
  %5093 = load i32, ptr %ready.count, align 4
  %5094 = icmp uge i32 %5093, 8
  %5095 = and i1 %5092, %5094
  br i1 %5095, label %ready.overflow.trap967, label %ready.overflow.resume968

ready.overflow.trap967:                           ; preds = %convergence.overflow.resume966
  call void @llvm.trap()
  unreachable

ready.overflow.resume968:                         ; preds = %convergence.overflow.resume966
  %5096 = select i1 %5092, i32 %5093, i32 0
  %5097 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5096
  %5098 = load <8 x i1>, ptr %5097, align 1
  %5099 = select i1 %5092, <8 x i1> %1344, <8 x i1> %5098
  store <8 x i1> %5099, ptr %5097, align 1
  %5100 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5096
  %5101 = load i32, ptr %5100, align 4
  %5102 = select i1 %5092, i32 55, i32 %5101
  store i32 %5102, ptr %5100, align 4
  %5103 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5096
  %5104 = load i32, ptr %5103, align 4
  %5105 = select i1 %5092, i32 %5091, i32 %5104
  store i32 %5105, ptr %5103, align 4
  %5106 = add i32 %5093, 1
  %5107 = select i1 %5092, i32 %5106, i32 %5093
  store i32 %5107, ptr %ready.count, align 4
  %5108 = load <8 x i1>, ptr %runnable.mask, align 1
  %5109 = or <8 x i1> %5108, %1344
  store <8 x i1> %5109, ptr %runnable.mask, align 1
  store <8 x i1> %1346, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true969:                         ; preds = %varying.coherent964
  store <8 x i1> %1337, ptr %current.mask, align 1
  %5110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1337)
  br i1 %5110, label %schedule.55, label %scheduler.loop

varying.coherent.false970:                        ; preds = %varying.coherent964
  store <8 x i1> %1337, ptr %current.mask, align 1
  %5111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1337)
  br i1 %5111, label %schedule.56, label %scheduler.loop

convergence.cascade984:                           ; preds = %convergence.cascade984, %schedule.56
  %convergence.cascade.flow988 = phi <8 x i1> [ %1420, %schedule.56 ], [ %5154, %convergence.cascade984 ]
  %convergence.cascade.depth989 = phi i32 [ 0, %schedule.56 ], [ %5155, %convergence.cascade984 ]
  %5112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow988)
  %5113 = load i32, ptr %current.token, align 4
  %5114 = icmp ne i32 %5113, 0
  %5115 = and i1 %5112, %5114
  %5116 = sub i32 %5113, 1
  %5117 = select i1 %5115, i32 %5116, i32 0
  %5118 = load i8, ptr %frame.active, align 1
  %5119 = trunc i32 %5117 to i8
  %5120 = shl i8 1, %5119
  %5121 = and i8 %5118, %5120
  %5122 = icmp ne i8 %5121, 0
  %5123 = load <8 x i32>, ptr %frame.static.id, align 32
  %5124 = extractelement <8 x i32> %5123, i32 %5117
  %convergence.target.pointer990 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5124
  %convergence.dynamic.target991 = load i32, ptr %convergence.target.pointer990, align 4
  %5125 = icmp eq i32 %convergence.dynamic.target991, 56
  %5126 = and i1 %5122, %5125
  %5127 = and i1 %5115, %5126
  %5128 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5117
  %5129 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5117
  %5130 = load <8 x i1>, ptr %5128, align 1
  %5131 = load <8 x i1>, ptr %5129, align 1
  %5132 = or <8 x i1> %5131, %convergence.cascade.flow988
  %5133 = load <8 x i1>, ptr %live.mask, align 1
  %5134 = and <8 x i1> %5130, %5133
  %5135 = icmp eq <8 x i1> %5132, %5134
  %5136 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5135)
  %5137 = and i1 %5127, %5136
  %5138 = select i1 %5137, <8 x i1> zeroinitializer, <8 x i1> %5132
  %5139 = select i1 %5127, <8 x i1> %5138, <8 x i1> %5131
  store <8 x i1> %5139, ptr %5129, align 1
  %5140 = select i1 %5137, <8 x i1> zeroinitializer, <8 x i1> %5130
  store <8 x i1> %5140, ptr %5128, align 1
  %5141 = trunc i32 %5117 to i8
  %5142 = shl i8 1, %5141
  %5143 = xor i8 %5142, -1
  %5144 = and i8 %5118, %5143
  %5145 = select i1 %5137, i8 %5144, i8 %5118
  store i8 %5145, ptr %frame.active, align 1
  %.splatinsert992 = insertelement <8 x i1> poison, i1 %5127, i64 0
  %.splat993 = shufflevector <8 x i1> %.splatinsert992, <8 x i1> poison, <8 x i32> zeroinitializer
  %5146 = and <8 x i1> %convergence.cascade.flow988, %.splat993
  %5147 = load <8 x i1>, ptr %runnable.mask, align 1
  %5148 = xor <8 x i1> %5146, splat (i1 true)
  %5149 = and <8 x i1> %5147, %5148
  store <8 x i1> %5149, ptr %runnable.mask, align 1
  %.splatinsert994 = insertelement <8 x i1> poison, i1 %5137, i64 0
  %.splat995 = shufflevector <8 x i1> %.splatinsert994, <8 x i1> poison, <8 x i32> zeroinitializer
  %5150 = select <8 x i1> %.splat995, <8 x i1> %5132, <8 x i1> zeroinitializer
  %5151 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5152 = extractelement <8 x i32> %5151, i32 %5117
  %5153 = select i1 %5137, i32 %5152, i32 %5113
  store i32 %5153, ptr %current.token, align 4
  %.splatinsert996 = insertelement <8 x i1> poison, i1 %5127, i64 0
  %.splat997 = shufflevector <8 x i1> %.splatinsert996, <8 x i1> poison, <8 x i32> zeroinitializer
  %5154 = select <8 x i1> %.splat997, <8 x i1> %5150, <8 x i1> %convergence.cascade.flow988
  %5155 = add i32 %convergence.cascade.depth989, 1
  %5156 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5154)
  %5157 = icmp ult i32 %5155, 8
  %5158 = and i1 %5156, %5157
  %5159 = and i1 %5127, %5158
  %convergence.parent.token998 = load i32, ptr %current.token, align 4
  %convergence.parent.present999 = icmp ne i32 %convergence.parent.token998, 0
  %5160 = and i1 %5159, %convergence.parent.present999
  br i1 %5160, label %convergence.cascade984, label %convergence.cascade.exit985

convergence.cascade.exit985:                      ; preds = %convergence.cascade984, %schedule.56
  %convergence.cascade.result1000 = phi <8 x i1> [ %1420, %schedule.56 ], [ %5154, %convergence.cascade984 ]
  %5161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1000)
  br i1 %5161, label %convergence.target.56.ready, label %scheduler.loop

convergence.target.56.ready:                      ; preds = %convergence.cascade.exit985
  %5162 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1000)
  %5163 = bitcast <8 x i1> %convergence.cascade.result1000 to i8
  %5164 = call i8 @llvm.cttz.i8(i8 %5163, i1 false)
  %5165 = zext i8 %5164 to i32
  %5166 = select i1 %5162, i32 %5165, i32 0
  %5167 = load <8 x i64>, ptr %.slot56, align 64
  %5168 = select <8 x i1> %convergence.cascade.result1000, <8 x i64> zeroinitializer, <8 x i64> %5167
  store <8 x i64> %5168, ptr %.slot56, align 64
  %5169 = load <8 x float>, ptr %.slot124, align 32
  %5170 = select <8 x i1> %convergence.cascade.result1000, <8 x float> zeroinitializer, <8 x float> %5169
  store <8 x float> %5170, ptr %.slot124, align 32
  %5171 = load <8 x float>, ptr %.slot125, align 32
  %5172 = select <8 x i1> %convergence.cascade.result1000, <8 x float> zeroinitializer, <8 x float> %5171
  store <8 x float> %5172, ptr %.slot125, align 32
  %5173 = load <8 x float>, ptr %.slot126, align 32
  %5174 = select <8 x i1> %convergence.cascade.result1000, <8 x float> zeroinitializer, <8 x float> %5173
  store <8 x float> %5174, ptr %.slot126, align 32
  %5175 = load <8 x float>, ptr %.slot127, align 32
  %5176 = select <8 x i1> %convergence.cascade.result1000, <8 x float> zeroinitializer, <8 x float> %5175
  store <8 x float> %5176, ptr %.slot127, align 32
  store <8 x i1> %convergence.cascade.result1000, ptr %current.mask, align 1
  %5177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1000)
  br i1 %5177, label %schedule.57, label %scheduler.loop

varying.divergent1002:                            ; preds = %schedule.57
  %5178 = load i32, ptr %current.token, align 4
  %5179 = icmp ne i32 %5178, 0
  %5180 = sub i32 %5178, 1
  %5181 = select i1 %5179, i32 %5180, i32 0
  %5182 = load i8, ptr %frame.active, align 1
  %5183 = trunc i32 %5181 to i8
  %5184 = shl i8 1, %5183
  %5185 = and i8 %5182, %5184
  %5186 = icmp ne i8 %5185, 0
  %5187 = load <8 x i32>, ptr %frame.static.id, align 32
  %5188 = extractelement <8 x i32> %5187, i32 %5181
  %5189 = icmp eq i32 %5188, 20
  %5190 = and i1 %5186, %5189
  %5191 = and i1 %5179, %5190
  %5192 = xor i1 %5191, true
  %5193 = and i1 true, %5192
  %5194 = xor i8 %5182, -1
  %5195 = icmp ne i8 %5194, 0
  %5196 = xor i1 %5195, true
  %5197 = and i1 %5193, %5196
  br i1 %5197, label %convergence.overflow.trap1004, label %convergence.overflow.resume1005

varying.coherent1003:                             ; preds = %schedule.57
  br i1 %1431, label %varying.coherent.true1008, label %varying.coherent.false1009

convergence.overflow.trap1004:                    ; preds = %varying.divergent1002
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1005:                  ; preds = %varying.divergent1002
  %5198 = call i8 @llvm.cttz.i8(i8 %5194, i1 false)
  %5199 = zext i8 %5198 to i32
  %5200 = select i1 %5195, i32 %5199, i32 0
  %5201 = trunc i32 %5200 to i8
  %5202 = shl i8 1, %5201
  %5203 = or i8 %5182, %5202
  %5204 = select i1 %5193, i8 %5203, i8 %5182
  store i8 %5204, ptr %frame.active, align 1
  %5205 = load <8 x i32>, ptr %frame.static.id, align 32
  %5206 = extractelement <8 x i32> %5205, i32 %5200
  %5207 = select i1 %5193, i32 20, i32 %5206
  %5208 = load <8 x i32>, ptr %frame.static.id, align 32
  %5209 = insertelement <8 x i32> %5208, i32 %5207, i32 %5200
  store <8 x i32> %5209, ptr %frame.static.id, align 32
  %5210 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5211 = extractelement <8 x i32> %5210, i32 %5200
  %5212 = select i1 %5193, i32 %5178, i32 %5211
  %5213 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5214 = insertelement <8 x i32> %5213, i32 %5212, i32 %5200
  store <8 x i32> %5214, ptr %frame.parent.token, align 32
  %5215 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5200
  %5216 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5200
  %5217 = load <8 x i1>, ptr %5215, align 1
  %5218 = load <8 x i1>, ptr %5216, align 1
  %5219 = select i1 %5193, <8 x i1> %1421, <8 x i1> %5217
  store <8 x i1> %5219, ptr %5215, align 1
  %5220 = select i1 %5193, <8 x i1> zeroinitializer, <8 x i1> %5218
  store <8 x i1> %5220, ptr %5216, align 1
  %5221 = add i32 %5200, 1
  %5222 = select i1 %5191, i32 %5178, i32 %5221
  %5223 = select i1 true, i32 %5222, i32 %5178
  store i32 %5223, ptr %current.token, align 4
  %5224 = load i32, ptr %current.token, align 4
  %5225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1428)
  %5226 = load i32, ptr %ready.count, align 4
  %5227 = icmp uge i32 %5226, 8
  %5228 = and i1 %5225, %5227
  br i1 %5228, label %ready.overflow.trap1006, label %ready.overflow.resume1007

ready.overflow.trap1006:                          ; preds = %convergence.overflow.resume1005
  call void @llvm.trap()
  unreachable

ready.overflow.resume1007:                        ; preds = %convergence.overflow.resume1005
  %5229 = select i1 %5225, i32 %5226, i32 0
  %5230 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5229
  %5231 = load <8 x i1>, ptr %5230, align 1
  %5232 = select i1 %5225, <8 x i1> %1428, <8 x i1> %5231
  store <8 x i1> %5232, ptr %5230, align 1
  %5233 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5229
  %5234 = load i32, ptr %5233, align 4
  %5235 = select i1 %5225, i32 58, i32 %5234
  store i32 %5235, ptr %5233, align 4
  %5236 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5229
  %5237 = load i32, ptr %5236, align 4
  %5238 = select i1 %5225, i32 %5224, i32 %5237
  store i32 %5238, ptr %5236, align 4
  %5239 = add i32 %5226, 1
  %5240 = select i1 %5225, i32 %5239, i32 %5226
  store i32 %5240, ptr %ready.count, align 4
  %5241 = load <8 x i1>, ptr %runnable.mask, align 1
  %5242 = or <8 x i1> %5241, %1428
  store <8 x i1> %5242, ptr %runnable.mask, align 1
  store <8 x i1> %1430, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1008:                        ; preds = %varying.coherent1003
  store <8 x i1> %1421, ptr %current.mask, align 1
  %5243 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1421)
  br i1 %5243, label %schedule.58, label %scheduler.loop

varying.coherent.false1009:                       ; preds = %varying.coherent1003
  store <8 x i1> %1421, ptr %current.mask, align 1
  %5244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1421)
  br i1 %5244, label %schedule.59, label %scheduler.loop

convergence.cascade1023:                          ; preds = %convergence.cascade1023, %schedule.59
  %convergence.cascade.flow1027 = phi <8 x i1> [ %1504, %schedule.59 ], [ %5287, %convergence.cascade1023 ]
  %convergence.cascade.depth1028 = phi i32 [ 0, %schedule.59 ], [ %5288, %convergence.cascade1023 ]
  %5245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1027)
  %5246 = load i32, ptr %current.token, align 4
  %5247 = icmp ne i32 %5246, 0
  %5248 = and i1 %5245, %5247
  %5249 = sub i32 %5246, 1
  %5250 = select i1 %5248, i32 %5249, i32 0
  %5251 = load i8, ptr %frame.active, align 1
  %5252 = trunc i32 %5250 to i8
  %5253 = shl i8 1, %5252
  %5254 = and i8 %5251, %5253
  %5255 = icmp ne i8 %5254, 0
  %5256 = load <8 x i32>, ptr %frame.static.id, align 32
  %5257 = extractelement <8 x i32> %5256, i32 %5250
  %convergence.target.pointer1029 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5257
  %convergence.dynamic.target1030 = load i32, ptr %convergence.target.pointer1029, align 4
  %5258 = icmp eq i32 %convergence.dynamic.target1030, 59
  %5259 = and i1 %5255, %5258
  %5260 = and i1 %5248, %5259
  %5261 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5250
  %5262 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5250
  %5263 = load <8 x i1>, ptr %5261, align 1
  %5264 = load <8 x i1>, ptr %5262, align 1
  %5265 = or <8 x i1> %5264, %convergence.cascade.flow1027
  %5266 = load <8 x i1>, ptr %live.mask, align 1
  %5267 = and <8 x i1> %5263, %5266
  %5268 = icmp eq <8 x i1> %5265, %5267
  %5269 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5268)
  %5270 = and i1 %5260, %5269
  %5271 = select i1 %5270, <8 x i1> zeroinitializer, <8 x i1> %5265
  %5272 = select i1 %5260, <8 x i1> %5271, <8 x i1> %5264
  store <8 x i1> %5272, ptr %5262, align 1
  %5273 = select i1 %5270, <8 x i1> zeroinitializer, <8 x i1> %5263
  store <8 x i1> %5273, ptr %5261, align 1
  %5274 = trunc i32 %5250 to i8
  %5275 = shl i8 1, %5274
  %5276 = xor i8 %5275, -1
  %5277 = and i8 %5251, %5276
  %5278 = select i1 %5270, i8 %5277, i8 %5251
  store i8 %5278, ptr %frame.active, align 1
  %.splatinsert1031 = insertelement <8 x i1> poison, i1 %5260, i64 0
  %.splat1032 = shufflevector <8 x i1> %.splatinsert1031, <8 x i1> poison, <8 x i32> zeroinitializer
  %5279 = and <8 x i1> %convergence.cascade.flow1027, %.splat1032
  %5280 = load <8 x i1>, ptr %runnable.mask, align 1
  %5281 = xor <8 x i1> %5279, splat (i1 true)
  %5282 = and <8 x i1> %5280, %5281
  store <8 x i1> %5282, ptr %runnable.mask, align 1
  %.splatinsert1033 = insertelement <8 x i1> poison, i1 %5270, i64 0
  %.splat1034 = shufflevector <8 x i1> %.splatinsert1033, <8 x i1> poison, <8 x i32> zeroinitializer
  %5283 = select <8 x i1> %.splat1034, <8 x i1> %5265, <8 x i1> zeroinitializer
  %5284 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5285 = extractelement <8 x i32> %5284, i32 %5250
  %5286 = select i1 %5270, i32 %5285, i32 %5246
  store i32 %5286, ptr %current.token, align 4
  %.splatinsert1035 = insertelement <8 x i1> poison, i1 %5260, i64 0
  %.splat1036 = shufflevector <8 x i1> %.splatinsert1035, <8 x i1> poison, <8 x i32> zeroinitializer
  %5287 = select <8 x i1> %.splat1036, <8 x i1> %5283, <8 x i1> %convergence.cascade.flow1027
  %5288 = add i32 %convergence.cascade.depth1028, 1
  %5289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5287)
  %5290 = icmp ult i32 %5288, 8
  %5291 = and i1 %5289, %5290
  %5292 = and i1 %5260, %5291
  %convergence.parent.token1037 = load i32, ptr %current.token, align 4
  %convergence.parent.present1038 = icmp ne i32 %convergence.parent.token1037, 0
  %5293 = and i1 %5292, %convergence.parent.present1038
  br i1 %5293, label %convergence.cascade1023, label %convergence.cascade.exit1024

convergence.cascade.exit1024:                     ; preds = %convergence.cascade1023, %schedule.59
  %convergence.cascade.result1039 = phi <8 x i1> [ %1504, %schedule.59 ], [ %5287, %convergence.cascade1023 ]
  %5294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1039)
  br i1 %5294, label %convergence.target.59.ready, label %scheduler.loop

convergence.target.59.ready:                      ; preds = %convergence.cascade.exit1024
  %5295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1039)
  %5296 = bitcast <8 x i1> %convergence.cascade.result1039 to i8
  %5297 = call i8 @llvm.cttz.i8(i8 %5296, i1 false)
  %5298 = zext i8 %5297 to i32
  %5299 = select i1 %5295, i32 %5298, i32 0
  %5300 = load <8 x i64>, ptr %.slot56, align 64
  %5301 = select <8 x i1> %convergence.cascade.result1039, <8 x i64> zeroinitializer, <8 x i64> %5300
  store <8 x i64> %5301, ptr %.slot56, align 64
  %5302 = load <8 x float>, ptr %.slot129, align 32
  %5303 = select <8 x i1> %convergence.cascade.result1039, <8 x float> zeroinitializer, <8 x float> %5302
  store <8 x float> %5303, ptr %.slot129, align 32
  %5304 = load <8 x float>, ptr %.slot130, align 32
  %5305 = select <8 x i1> %convergence.cascade.result1039, <8 x float> zeroinitializer, <8 x float> %5304
  store <8 x float> %5305, ptr %.slot130, align 32
  %5306 = load <8 x float>, ptr %.slot131, align 32
  %5307 = select <8 x i1> %convergence.cascade.result1039, <8 x float> zeroinitializer, <8 x float> %5306
  store <8 x float> %5307, ptr %.slot131, align 32
  %5308 = load <8 x float>, ptr %.slot132, align 32
  %5309 = select <8 x i1> %convergence.cascade.result1039, <8 x float> zeroinitializer, <8 x float> %5308
  store <8 x float> %5309, ptr %.slot132, align 32
  store <8 x i1> %convergence.cascade.result1039, ptr %current.mask, align 1
  %5310 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1039)
  br i1 %5310, label %schedule.60, label %scheduler.loop

varying.divergent1041:                            ; preds = %schedule.60
  %5311 = load i32, ptr %current.token, align 4
  %5312 = icmp ne i32 %5311, 0
  %5313 = sub i32 %5311, 1
  %5314 = select i1 %5312, i32 %5313, i32 0
  %5315 = load i8, ptr %frame.active, align 1
  %5316 = trunc i32 %5314 to i8
  %5317 = shl i8 1, %5316
  %5318 = and i8 %5315, %5317
  %5319 = icmp ne i8 %5318, 0
  %5320 = load <8 x i32>, ptr %frame.static.id, align 32
  %5321 = extractelement <8 x i32> %5320, i32 %5314
  %5322 = icmp eq i32 %5321, 21
  %5323 = and i1 %5319, %5322
  %5324 = and i1 %5312, %5323
  %5325 = xor i1 %5324, true
  %5326 = and i1 true, %5325
  %5327 = xor i8 %5315, -1
  %5328 = icmp ne i8 %5327, 0
  %5329 = xor i1 %5328, true
  %5330 = and i1 %5326, %5329
  br i1 %5330, label %convergence.overflow.trap1043, label %convergence.overflow.resume1044

varying.coherent1042:                             ; preds = %schedule.60
  br i1 %1515, label %varying.coherent.true1047, label %varying.coherent.false1048

convergence.overflow.trap1043:                    ; preds = %varying.divergent1041
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1044:                  ; preds = %varying.divergent1041
  %5331 = call i8 @llvm.cttz.i8(i8 %5327, i1 false)
  %5332 = zext i8 %5331 to i32
  %5333 = select i1 %5328, i32 %5332, i32 0
  %5334 = trunc i32 %5333 to i8
  %5335 = shl i8 1, %5334
  %5336 = or i8 %5315, %5335
  %5337 = select i1 %5326, i8 %5336, i8 %5315
  store i8 %5337, ptr %frame.active, align 1
  %5338 = load <8 x i32>, ptr %frame.static.id, align 32
  %5339 = extractelement <8 x i32> %5338, i32 %5333
  %5340 = select i1 %5326, i32 21, i32 %5339
  %5341 = load <8 x i32>, ptr %frame.static.id, align 32
  %5342 = insertelement <8 x i32> %5341, i32 %5340, i32 %5333
  store <8 x i32> %5342, ptr %frame.static.id, align 32
  %5343 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5344 = extractelement <8 x i32> %5343, i32 %5333
  %5345 = select i1 %5326, i32 %5311, i32 %5344
  %5346 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5347 = insertelement <8 x i32> %5346, i32 %5345, i32 %5333
  store <8 x i32> %5347, ptr %frame.parent.token, align 32
  %5348 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5333
  %5349 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5333
  %5350 = load <8 x i1>, ptr %5348, align 1
  %5351 = load <8 x i1>, ptr %5349, align 1
  %5352 = select i1 %5326, <8 x i1> %1505, <8 x i1> %5350
  store <8 x i1> %5352, ptr %5348, align 1
  %5353 = select i1 %5326, <8 x i1> zeroinitializer, <8 x i1> %5351
  store <8 x i1> %5353, ptr %5349, align 1
  %5354 = add i32 %5333, 1
  %5355 = select i1 %5324, i32 %5311, i32 %5354
  %5356 = select i1 true, i32 %5355, i32 %5311
  store i32 %5356, ptr %current.token, align 4
  %5357 = load i32, ptr %current.token, align 4
  %5358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1512)
  %5359 = load i32, ptr %ready.count, align 4
  %5360 = icmp uge i32 %5359, 8
  %5361 = and i1 %5358, %5360
  br i1 %5361, label %ready.overflow.trap1045, label %ready.overflow.resume1046

ready.overflow.trap1045:                          ; preds = %convergence.overflow.resume1044
  call void @llvm.trap()
  unreachable

ready.overflow.resume1046:                        ; preds = %convergence.overflow.resume1044
  %5362 = select i1 %5358, i32 %5359, i32 0
  %5363 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5362
  %5364 = load <8 x i1>, ptr %5363, align 1
  %5365 = select i1 %5358, <8 x i1> %1512, <8 x i1> %5364
  store <8 x i1> %5365, ptr %5363, align 1
  %5366 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5362
  %5367 = load i32, ptr %5366, align 4
  %5368 = select i1 %5358, i32 61, i32 %5367
  store i32 %5368, ptr %5366, align 4
  %5369 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5362
  %5370 = load i32, ptr %5369, align 4
  %5371 = select i1 %5358, i32 %5357, i32 %5370
  store i32 %5371, ptr %5369, align 4
  %5372 = add i32 %5359, 1
  %5373 = select i1 %5358, i32 %5372, i32 %5359
  store i32 %5373, ptr %ready.count, align 4
  %5374 = load <8 x i1>, ptr %runnable.mask, align 1
  %5375 = or <8 x i1> %5374, %1512
  store <8 x i1> %5375, ptr %runnable.mask, align 1
  store <8 x i1> %1514, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1047:                        ; preds = %varying.coherent1042
  store <8 x i1> %1505, ptr %current.mask, align 1
  %5376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1505)
  br i1 %5376, label %schedule.61, label %scheduler.loop

varying.coherent.false1048:                       ; preds = %varying.coherent1042
  store <8 x i1> %1505, ptr %current.mask, align 1
  %5377 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1505)
  br i1 %5377, label %schedule.62, label %scheduler.loop

convergence.cascade1062:                          ; preds = %convergence.cascade1062, %schedule.62
  %convergence.cascade.flow1066 = phi <8 x i1> [ %1588, %schedule.62 ], [ %5420, %convergence.cascade1062 ]
  %convergence.cascade.depth1067 = phi i32 [ 0, %schedule.62 ], [ %5421, %convergence.cascade1062 ]
  %5378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1066)
  %5379 = load i32, ptr %current.token, align 4
  %5380 = icmp ne i32 %5379, 0
  %5381 = and i1 %5378, %5380
  %5382 = sub i32 %5379, 1
  %5383 = select i1 %5381, i32 %5382, i32 0
  %5384 = load i8, ptr %frame.active, align 1
  %5385 = trunc i32 %5383 to i8
  %5386 = shl i8 1, %5385
  %5387 = and i8 %5384, %5386
  %5388 = icmp ne i8 %5387, 0
  %5389 = load <8 x i32>, ptr %frame.static.id, align 32
  %5390 = extractelement <8 x i32> %5389, i32 %5383
  %convergence.target.pointer1068 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5390
  %convergence.dynamic.target1069 = load i32, ptr %convergence.target.pointer1068, align 4
  %5391 = icmp eq i32 %convergence.dynamic.target1069, 62
  %5392 = and i1 %5388, %5391
  %5393 = and i1 %5381, %5392
  %5394 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5383
  %5395 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5383
  %5396 = load <8 x i1>, ptr %5394, align 1
  %5397 = load <8 x i1>, ptr %5395, align 1
  %5398 = or <8 x i1> %5397, %convergence.cascade.flow1066
  %5399 = load <8 x i1>, ptr %live.mask, align 1
  %5400 = and <8 x i1> %5396, %5399
  %5401 = icmp eq <8 x i1> %5398, %5400
  %5402 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5401)
  %5403 = and i1 %5393, %5402
  %5404 = select i1 %5403, <8 x i1> zeroinitializer, <8 x i1> %5398
  %5405 = select i1 %5393, <8 x i1> %5404, <8 x i1> %5397
  store <8 x i1> %5405, ptr %5395, align 1
  %5406 = select i1 %5403, <8 x i1> zeroinitializer, <8 x i1> %5396
  store <8 x i1> %5406, ptr %5394, align 1
  %5407 = trunc i32 %5383 to i8
  %5408 = shl i8 1, %5407
  %5409 = xor i8 %5408, -1
  %5410 = and i8 %5384, %5409
  %5411 = select i1 %5403, i8 %5410, i8 %5384
  store i8 %5411, ptr %frame.active, align 1
  %.splatinsert1070 = insertelement <8 x i1> poison, i1 %5393, i64 0
  %.splat1071 = shufflevector <8 x i1> %.splatinsert1070, <8 x i1> poison, <8 x i32> zeroinitializer
  %5412 = and <8 x i1> %convergence.cascade.flow1066, %.splat1071
  %5413 = load <8 x i1>, ptr %runnable.mask, align 1
  %5414 = xor <8 x i1> %5412, splat (i1 true)
  %5415 = and <8 x i1> %5413, %5414
  store <8 x i1> %5415, ptr %runnable.mask, align 1
  %.splatinsert1072 = insertelement <8 x i1> poison, i1 %5403, i64 0
  %.splat1073 = shufflevector <8 x i1> %.splatinsert1072, <8 x i1> poison, <8 x i32> zeroinitializer
  %5416 = select <8 x i1> %.splat1073, <8 x i1> %5398, <8 x i1> zeroinitializer
  %5417 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5418 = extractelement <8 x i32> %5417, i32 %5383
  %5419 = select i1 %5403, i32 %5418, i32 %5379
  store i32 %5419, ptr %current.token, align 4
  %.splatinsert1074 = insertelement <8 x i1> poison, i1 %5393, i64 0
  %.splat1075 = shufflevector <8 x i1> %.splatinsert1074, <8 x i1> poison, <8 x i32> zeroinitializer
  %5420 = select <8 x i1> %.splat1075, <8 x i1> %5416, <8 x i1> %convergence.cascade.flow1066
  %5421 = add i32 %convergence.cascade.depth1067, 1
  %5422 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5420)
  %5423 = icmp ult i32 %5421, 8
  %5424 = and i1 %5422, %5423
  %5425 = and i1 %5393, %5424
  %convergence.parent.token1076 = load i32, ptr %current.token, align 4
  %convergence.parent.present1077 = icmp ne i32 %convergence.parent.token1076, 0
  %5426 = and i1 %5425, %convergence.parent.present1077
  br i1 %5426, label %convergence.cascade1062, label %convergence.cascade.exit1063

convergence.cascade.exit1063:                     ; preds = %convergence.cascade1062, %schedule.62
  %convergence.cascade.result1078 = phi <8 x i1> [ %1588, %schedule.62 ], [ %5420, %convergence.cascade1062 ]
  %5427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1078)
  br i1 %5427, label %convergence.target.62.ready, label %scheduler.loop

convergence.target.62.ready:                      ; preds = %convergence.cascade.exit1063
  %5428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1078)
  %5429 = bitcast <8 x i1> %convergence.cascade.result1078 to i8
  %5430 = call i8 @llvm.cttz.i8(i8 %5429, i1 false)
  %5431 = zext i8 %5430 to i32
  %5432 = select i1 %5428, i32 %5431, i32 0
  %5433 = load <8 x i64>, ptr %.slot56, align 64
  %5434 = select <8 x i1> %convergence.cascade.result1078, <8 x i64> zeroinitializer, <8 x i64> %5433
  store <8 x i64> %5434, ptr %.slot56, align 64
  %5435 = load <8 x float>, ptr %.slot134, align 32
  %5436 = select <8 x i1> %convergence.cascade.result1078, <8 x float> zeroinitializer, <8 x float> %5435
  store <8 x float> %5436, ptr %.slot134, align 32
  %5437 = load <8 x float>, ptr %.slot135, align 32
  %5438 = select <8 x i1> %convergence.cascade.result1078, <8 x float> zeroinitializer, <8 x float> %5437
  store <8 x float> %5438, ptr %.slot135, align 32
  %5439 = load <8 x float>, ptr %.slot136, align 32
  %5440 = select <8 x i1> %convergence.cascade.result1078, <8 x float> zeroinitializer, <8 x float> %5439
  store <8 x float> %5440, ptr %.slot136, align 32
  %5441 = load <8 x float>, ptr %.slot137, align 32
  %5442 = select <8 x i1> %convergence.cascade.result1078, <8 x float> zeroinitializer, <8 x float> %5441
  store <8 x float> %5442, ptr %.slot137, align 32
  store <8 x i1> %convergence.cascade.result1078, ptr %current.mask, align 1
  %5443 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1078)
  br i1 %5443, label %schedule.63, label %scheduler.loop

varying.divergent1080:                            ; preds = %schedule.63
  %5444 = load i32, ptr %current.token, align 4
  %5445 = icmp ne i32 %5444, 0
  %5446 = sub i32 %5444, 1
  %5447 = select i1 %5445, i32 %5446, i32 0
  %5448 = load i8, ptr %frame.active, align 1
  %5449 = trunc i32 %5447 to i8
  %5450 = shl i8 1, %5449
  %5451 = and i8 %5448, %5450
  %5452 = icmp ne i8 %5451, 0
  %5453 = load <8 x i32>, ptr %frame.static.id, align 32
  %5454 = extractelement <8 x i32> %5453, i32 %5447
  %5455 = icmp eq i32 %5454, 22
  %5456 = and i1 %5452, %5455
  %5457 = and i1 %5445, %5456
  %5458 = xor i1 %5457, true
  %5459 = and i1 true, %5458
  %5460 = xor i8 %5448, -1
  %5461 = icmp ne i8 %5460, 0
  %5462 = xor i1 %5461, true
  %5463 = and i1 %5459, %5462
  br i1 %5463, label %convergence.overflow.trap1082, label %convergence.overflow.resume1083

varying.coherent1081:                             ; preds = %schedule.63
  br i1 %1599, label %varying.coherent.true1086, label %varying.coherent.false1087

convergence.overflow.trap1082:                    ; preds = %varying.divergent1080
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1083:                  ; preds = %varying.divergent1080
  %5464 = call i8 @llvm.cttz.i8(i8 %5460, i1 false)
  %5465 = zext i8 %5464 to i32
  %5466 = select i1 %5461, i32 %5465, i32 0
  %5467 = trunc i32 %5466 to i8
  %5468 = shl i8 1, %5467
  %5469 = or i8 %5448, %5468
  %5470 = select i1 %5459, i8 %5469, i8 %5448
  store i8 %5470, ptr %frame.active, align 1
  %5471 = load <8 x i32>, ptr %frame.static.id, align 32
  %5472 = extractelement <8 x i32> %5471, i32 %5466
  %5473 = select i1 %5459, i32 22, i32 %5472
  %5474 = load <8 x i32>, ptr %frame.static.id, align 32
  %5475 = insertelement <8 x i32> %5474, i32 %5473, i32 %5466
  store <8 x i32> %5475, ptr %frame.static.id, align 32
  %5476 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5477 = extractelement <8 x i32> %5476, i32 %5466
  %5478 = select i1 %5459, i32 %5444, i32 %5477
  %5479 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5480 = insertelement <8 x i32> %5479, i32 %5478, i32 %5466
  store <8 x i32> %5480, ptr %frame.parent.token, align 32
  %5481 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5466
  %5482 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5466
  %5483 = load <8 x i1>, ptr %5481, align 1
  %5484 = load <8 x i1>, ptr %5482, align 1
  %5485 = select i1 %5459, <8 x i1> %1589, <8 x i1> %5483
  store <8 x i1> %5485, ptr %5481, align 1
  %5486 = select i1 %5459, <8 x i1> zeroinitializer, <8 x i1> %5484
  store <8 x i1> %5486, ptr %5482, align 1
  %5487 = add i32 %5466, 1
  %5488 = select i1 %5457, i32 %5444, i32 %5487
  %5489 = select i1 true, i32 %5488, i32 %5444
  store i32 %5489, ptr %current.token, align 4
  %5490 = load i32, ptr %current.token, align 4
  %5491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1596)
  %5492 = load i32, ptr %ready.count, align 4
  %5493 = icmp uge i32 %5492, 8
  %5494 = and i1 %5491, %5493
  br i1 %5494, label %ready.overflow.trap1084, label %ready.overflow.resume1085

ready.overflow.trap1084:                          ; preds = %convergence.overflow.resume1083
  call void @llvm.trap()
  unreachable

ready.overflow.resume1085:                        ; preds = %convergence.overflow.resume1083
  %5495 = select i1 %5491, i32 %5492, i32 0
  %5496 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5495
  %5497 = load <8 x i1>, ptr %5496, align 1
  %5498 = select i1 %5491, <8 x i1> %1596, <8 x i1> %5497
  store <8 x i1> %5498, ptr %5496, align 1
  %5499 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5495
  %5500 = load i32, ptr %5499, align 4
  %5501 = select i1 %5491, i32 64, i32 %5500
  store i32 %5501, ptr %5499, align 4
  %5502 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5495
  %5503 = load i32, ptr %5502, align 4
  %5504 = select i1 %5491, i32 %5490, i32 %5503
  store i32 %5504, ptr %5502, align 4
  %5505 = add i32 %5492, 1
  %5506 = select i1 %5491, i32 %5505, i32 %5492
  store i32 %5506, ptr %ready.count, align 4
  %5507 = load <8 x i1>, ptr %runnable.mask, align 1
  %5508 = or <8 x i1> %5507, %1596
  store <8 x i1> %5508, ptr %runnable.mask, align 1
  store <8 x i1> %1598, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1086:                        ; preds = %varying.coherent1081
  store <8 x i1> %1589, ptr %current.mask, align 1
  %5509 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1589)
  br i1 %5509, label %schedule.64, label %scheduler.loop

varying.coherent.false1087:                       ; preds = %varying.coherent1081
  store <8 x i1> %1589, ptr %current.mask, align 1
  %5510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1589)
  br i1 %5510, label %schedule.65, label %scheduler.loop

convergence.cascade1101:                          ; preds = %convergence.cascade1101, %schedule.65
  %convergence.cascade.flow1105 = phi <8 x i1> [ %1672, %schedule.65 ], [ %5553, %convergence.cascade1101 ]
  %convergence.cascade.depth1106 = phi i32 [ 0, %schedule.65 ], [ %5554, %convergence.cascade1101 ]
  %5511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1105)
  %5512 = load i32, ptr %current.token, align 4
  %5513 = icmp ne i32 %5512, 0
  %5514 = and i1 %5511, %5513
  %5515 = sub i32 %5512, 1
  %5516 = select i1 %5514, i32 %5515, i32 0
  %5517 = load i8, ptr %frame.active, align 1
  %5518 = trunc i32 %5516 to i8
  %5519 = shl i8 1, %5518
  %5520 = and i8 %5517, %5519
  %5521 = icmp ne i8 %5520, 0
  %5522 = load <8 x i32>, ptr %frame.static.id, align 32
  %5523 = extractelement <8 x i32> %5522, i32 %5516
  %convergence.target.pointer1107 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5523
  %convergence.dynamic.target1108 = load i32, ptr %convergence.target.pointer1107, align 4
  %5524 = icmp eq i32 %convergence.dynamic.target1108, 65
  %5525 = and i1 %5521, %5524
  %5526 = and i1 %5514, %5525
  %5527 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5516
  %5528 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5516
  %5529 = load <8 x i1>, ptr %5527, align 1
  %5530 = load <8 x i1>, ptr %5528, align 1
  %5531 = or <8 x i1> %5530, %convergence.cascade.flow1105
  %5532 = load <8 x i1>, ptr %live.mask, align 1
  %5533 = and <8 x i1> %5529, %5532
  %5534 = icmp eq <8 x i1> %5531, %5533
  %5535 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5534)
  %5536 = and i1 %5526, %5535
  %5537 = select i1 %5536, <8 x i1> zeroinitializer, <8 x i1> %5531
  %5538 = select i1 %5526, <8 x i1> %5537, <8 x i1> %5530
  store <8 x i1> %5538, ptr %5528, align 1
  %5539 = select i1 %5536, <8 x i1> zeroinitializer, <8 x i1> %5529
  store <8 x i1> %5539, ptr %5527, align 1
  %5540 = trunc i32 %5516 to i8
  %5541 = shl i8 1, %5540
  %5542 = xor i8 %5541, -1
  %5543 = and i8 %5517, %5542
  %5544 = select i1 %5536, i8 %5543, i8 %5517
  store i8 %5544, ptr %frame.active, align 1
  %.splatinsert1109 = insertelement <8 x i1> poison, i1 %5526, i64 0
  %.splat1110 = shufflevector <8 x i1> %.splatinsert1109, <8 x i1> poison, <8 x i32> zeroinitializer
  %5545 = and <8 x i1> %convergence.cascade.flow1105, %.splat1110
  %5546 = load <8 x i1>, ptr %runnable.mask, align 1
  %5547 = xor <8 x i1> %5545, splat (i1 true)
  %5548 = and <8 x i1> %5546, %5547
  store <8 x i1> %5548, ptr %runnable.mask, align 1
  %.splatinsert1111 = insertelement <8 x i1> poison, i1 %5536, i64 0
  %.splat1112 = shufflevector <8 x i1> %.splatinsert1111, <8 x i1> poison, <8 x i32> zeroinitializer
  %5549 = select <8 x i1> %.splat1112, <8 x i1> %5531, <8 x i1> zeroinitializer
  %5550 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5551 = extractelement <8 x i32> %5550, i32 %5516
  %5552 = select i1 %5536, i32 %5551, i32 %5512
  store i32 %5552, ptr %current.token, align 4
  %.splatinsert1113 = insertelement <8 x i1> poison, i1 %5526, i64 0
  %.splat1114 = shufflevector <8 x i1> %.splatinsert1113, <8 x i1> poison, <8 x i32> zeroinitializer
  %5553 = select <8 x i1> %.splat1114, <8 x i1> %5549, <8 x i1> %convergence.cascade.flow1105
  %5554 = add i32 %convergence.cascade.depth1106, 1
  %5555 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5553)
  %5556 = icmp ult i32 %5554, 8
  %5557 = and i1 %5555, %5556
  %5558 = and i1 %5526, %5557
  %convergence.parent.token1115 = load i32, ptr %current.token, align 4
  %convergence.parent.present1116 = icmp ne i32 %convergence.parent.token1115, 0
  %5559 = and i1 %5558, %convergence.parent.present1116
  br i1 %5559, label %convergence.cascade1101, label %convergence.cascade.exit1102

convergence.cascade.exit1102:                     ; preds = %convergence.cascade1101, %schedule.65
  %convergence.cascade.result1117 = phi <8 x i1> [ %1672, %schedule.65 ], [ %5553, %convergence.cascade1101 ]
  %5560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1117)
  br i1 %5560, label %convergence.target.65.ready, label %scheduler.loop

convergence.target.65.ready:                      ; preds = %convergence.cascade.exit1102
  %5561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1117)
  %5562 = bitcast <8 x i1> %convergence.cascade.result1117 to i8
  %5563 = call i8 @llvm.cttz.i8(i8 %5562, i1 false)
  %5564 = zext i8 %5563 to i32
  %5565 = select i1 %5561, i32 %5564, i32 0
  %5566 = load <8 x i64>, ptr %.slot56, align 64
  %5567 = select <8 x i1> %convergence.cascade.result1117, <8 x i64> zeroinitializer, <8 x i64> %5566
  store <8 x i64> %5567, ptr %.slot56, align 64
  %5568 = load <8 x float>, ptr %.slot139, align 32
  %5569 = select <8 x i1> %convergence.cascade.result1117, <8 x float> zeroinitializer, <8 x float> %5568
  store <8 x float> %5569, ptr %.slot139, align 32
  %5570 = load <8 x float>, ptr %.slot140, align 32
  %5571 = select <8 x i1> %convergence.cascade.result1117, <8 x float> zeroinitializer, <8 x float> %5570
  store <8 x float> %5571, ptr %.slot140, align 32
  %5572 = load <8 x float>, ptr %.slot141, align 32
  %5573 = select <8 x i1> %convergence.cascade.result1117, <8 x float> zeroinitializer, <8 x float> %5572
  store <8 x float> %5573, ptr %.slot141, align 32
  %5574 = load <8 x float>, ptr %.slot142, align 32
  %5575 = select <8 x i1> %convergence.cascade.result1117, <8 x float> zeroinitializer, <8 x float> %5574
  store <8 x float> %5575, ptr %.slot142, align 32
  store <8 x i1> %convergence.cascade.result1117, ptr %current.mask, align 1
  %5576 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1117)
  br i1 %5576, label %schedule.66, label %scheduler.loop

varying.divergent1119:                            ; preds = %schedule.66
  %5577 = load i32, ptr %current.token, align 4
  %5578 = icmp ne i32 %5577, 0
  %5579 = sub i32 %5577, 1
  %5580 = select i1 %5578, i32 %5579, i32 0
  %5581 = load i8, ptr %frame.active, align 1
  %5582 = trunc i32 %5580 to i8
  %5583 = shl i8 1, %5582
  %5584 = and i8 %5581, %5583
  %5585 = icmp ne i8 %5584, 0
  %5586 = load <8 x i32>, ptr %frame.static.id, align 32
  %5587 = extractelement <8 x i32> %5586, i32 %5580
  %5588 = icmp eq i32 %5587, 23
  %5589 = and i1 %5585, %5588
  %5590 = and i1 %5578, %5589
  %5591 = xor i1 %5590, true
  %5592 = and i1 true, %5591
  %5593 = xor i8 %5581, -1
  %5594 = icmp ne i8 %5593, 0
  %5595 = xor i1 %5594, true
  %5596 = and i1 %5592, %5595
  br i1 %5596, label %convergence.overflow.trap1121, label %convergence.overflow.resume1122

varying.coherent1120:                             ; preds = %schedule.66
  br i1 %1683, label %varying.coherent.true1125, label %varying.coherent.false1126

convergence.overflow.trap1121:                    ; preds = %varying.divergent1119
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1122:                  ; preds = %varying.divergent1119
  %5597 = call i8 @llvm.cttz.i8(i8 %5593, i1 false)
  %5598 = zext i8 %5597 to i32
  %5599 = select i1 %5594, i32 %5598, i32 0
  %5600 = trunc i32 %5599 to i8
  %5601 = shl i8 1, %5600
  %5602 = or i8 %5581, %5601
  %5603 = select i1 %5592, i8 %5602, i8 %5581
  store i8 %5603, ptr %frame.active, align 1
  %5604 = load <8 x i32>, ptr %frame.static.id, align 32
  %5605 = extractelement <8 x i32> %5604, i32 %5599
  %5606 = select i1 %5592, i32 23, i32 %5605
  %5607 = load <8 x i32>, ptr %frame.static.id, align 32
  %5608 = insertelement <8 x i32> %5607, i32 %5606, i32 %5599
  store <8 x i32> %5608, ptr %frame.static.id, align 32
  %5609 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5610 = extractelement <8 x i32> %5609, i32 %5599
  %5611 = select i1 %5592, i32 %5577, i32 %5610
  %5612 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5613 = insertelement <8 x i32> %5612, i32 %5611, i32 %5599
  store <8 x i32> %5613, ptr %frame.parent.token, align 32
  %5614 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5599
  %5615 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5599
  %5616 = load <8 x i1>, ptr %5614, align 1
  %5617 = load <8 x i1>, ptr %5615, align 1
  %5618 = select i1 %5592, <8 x i1> %1673, <8 x i1> %5616
  store <8 x i1> %5618, ptr %5614, align 1
  %5619 = select i1 %5592, <8 x i1> zeroinitializer, <8 x i1> %5617
  store <8 x i1> %5619, ptr %5615, align 1
  %5620 = add i32 %5599, 1
  %5621 = select i1 %5590, i32 %5577, i32 %5620
  %5622 = select i1 true, i32 %5621, i32 %5577
  store i32 %5622, ptr %current.token, align 4
  %5623 = load i32, ptr %current.token, align 4
  %5624 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1680)
  %5625 = load i32, ptr %ready.count, align 4
  %5626 = icmp uge i32 %5625, 8
  %5627 = and i1 %5624, %5626
  br i1 %5627, label %ready.overflow.trap1123, label %ready.overflow.resume1124

ready.overflow.trap1123:                          ; preds = %convergence.overflow.resume1122
  call void @llvm.trap()
  unreachable

ready.overflow.resume1124:                        ; preds = %convergence.overflow.resume1122
  %5628 = select i1 %5624, i32 %5625, i32 0
  %5629 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5628
  %5630 = load <8 x i1>, ptr %5629, align 1
  %5631 = select i1 %5624, <8 x i1> %1680, <8 x i1> %5630
  store <8 x i1> %5631, ptr %5629, align 1
  %5632 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5628
  %5633 = load i32, ptr %5632, align 4
  %5634 = select i1 %5624, i32 67, i32 %5633
  store i32 %5634, ptr %5632, align 4
  %5635 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5628
  %5636 = load i32, ptr %5635, align 4
  %5637 = select i1 %5624, i32 %5623, i32 %5636
  store i32 %5637, ptr %5635, align 4
  %5638 = add i32 %5625, 1
  %5639 = select i1 %5624, i32 %5638, i32 %5625
  store i32 %5639, ptr %ready.count, align 4
  %5640 = load <8 x i1>, ptr %runnable.mask, align 1
  %5641 = or <8 x i1> %5640, %1680
  store <8 x i1> %5641, ptr %runnable.mask, align 1
  store <8 x i1> %1682, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1125:                        ; preds = %varying.coherent1120
  store <8 x i1> %1673, ptr %current.mask, align 1
  %5642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1673)
  br i1 %5642, label %schedule.67, label %scheduler.loop

varying.coherent.false1126:                       ; preds = %varying.coherent1120
  store <8 x i1> %1673, ptr %current.mask, align 1
  %5643 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1673)
  br i1 %5643, label %schedule.68, label %scheduler.loop

convergence.cascade1140:                          ; preds = %convergence.cascade1140, %schedule.68
  %convergence.cascade.flow1144 = phi <8 x i1> [ %1756, %schedule.68 ], [ %5686, %convergence.cascade1140 ]
  %convergence.cascade.depth1145 = phi i32 [ 0, %schedule.68 ], [ %5687, %convergence.cascade1140 ]
  %5644 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1144)
  %5645 = load i32, ptr %current.token, align 4
  %5646 = icmp ne i32 %5645, 0
  %5647 = and i1 %5644, %5646
  %5648 = sub i32 %5645, 1
  %5649 = select i1 %5647, i32 %5648, i32 0
  %5650 = load i8, ptr %frame.active, align 1
  %5651 = trunc i32 %5649 to i8
  %5652 = shl i8 1, %5651
  %5653 = and i8 %5650, %5652
  %5654 = icmp ne i8 %5653, 0
  %5655 = load <8 x i32>, ptr %frame.static.id, align 32
  %5656 = extractelement <8 x i32> %5655, i32 %5649
  %convergence.target.pointer1146 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %5656
  %convergence.dynamic.target1147 = load i32, ptr %convergence.target.pointer1146, align 4
  %5657 = icmp eq i32 %convergence.dynamic.target1147, 68
  %5658 = and i1 %5654, %5657
  %5659 = and i1 %5647, %5658
  %5660 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5649
  %5661 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5649
  %5662 = load <8 x i1>, ptr %5660, align 1
  %5663 = load <8 x i1>, ptr %5661, align 1
  %5664 = or <8 x i1> %5663, %convergence.cascade.flow1144
  %5665 = load <8 x i1>, ptr %live.mask, align 1
  %5666 = and <8 x i1> %5662, %5665
  %5667 = icmp eq <8 x i1> %5664, %5666
  %5668 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5667)
  %5669 = and i1 %5659, %5668
  %5670 = select i1 %5669, <8 x i1> zeroinitializer, <8 x i1> %5664
  %5671 = select i1 %5659, <8 x i1> %5670, <8 x i1> %5663
  store <8 x i1> %5671, ptr %5661, align 1
  %5672 = select i1 %5669, <8 x i1> zeroinitializer, <8 x i1> %5662
  store <8 x i1> %5672, ptr %5660, align 1
  %5673 = trunc i32 %5649 to i8
  %5674 = shl i8 1, %5673
  %5675 = xor i8 %5674, -1
  %5676 = and i8 %5650, %5675
  %5677 = select i1 %5669, i8 %5676, i8 %5650
  store i8 %5677, ptr %frame.active, align 1
  %.splatinsert1148 = insertelement <8 x i1> poison, i1 %5659, i64 0
  %.splat1149 = shufflevector <8 x i1> %.splatinsert1148, <8 x i1> poison, <8 x i32> zeroinitializer
  %5678 = and <8 x i1> %convergence.cascade.flow1144, %.splat1149
  %5679 = load <8 x i1>, ptr %runnable.mask, align 1
  %5680 = xor <8 x i1> %5678, splat (i1 true)
  %5681 = and <8 x i1> %5679, %5680
  store <8 x i1> %5681, ptr %runnable.mask, align 1
  %.splatinsert1150 = insertelement <8 x i1> poison, i1 %5669, i64 0
  %.splat1151 = shufflevector <8 x i1> %.splatinsert1150, <8 x i1> poison, <8 x i32> zeroinitializer
  %5682 = select <8 x i1> %.splat1151, <8 x i1> %5664, <8 x i1> zeroinitializer
  %5683 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5684 = extractelement <8 x i32> %5683, i32 %5649
  %5685 = select i1 %5669, i32 %5684, i32 %5645
  store i32 %5685, ptr %current.token, align 4
  %.splatinsert1152 = insertelement <8 x i1> poison, i1 %5659, i64 0
  %.splat1153 = shufflevector <8 x i1> %.splatinsert1152, <8 x i1> poison, <8 x i32> zeroinitializer
  %5686 = select <8 x i1> %.splat1153, <8 x i1> %5682, <8 x i1> %convergence.cascade.flow1144
  %5687 = add i32 %convergence.cascade.depth1145, 1
  %5688 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5686)
  %5689 = icmp ult i32 %5687, 8
  %5690 = and i1 %5688, %5689
  %5691 = and i1 %5659, %5690
  %convergence.parent.token1154 = load i32, ptr %current.token, align 4
  %convergence.parent.present1155 = icmp ne i32 %convergence.parent.token1154, 0
  %5692 = and i1 %5691, %convergence.parent.present1155
  br i1 %5692, label %convergence.cascade1140, label %convergence.cascade.exit1141

convergence.cascade.exit1141:                     ; preds = %convergence.cascade1140, %schedule.68
  %convergence.cascade.result1156 = phi <8 x i1> [ %1756, %schedule.68 ], [ %5686, %convergence.cascade1140 ]
  %5693 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  br i1 %5693, label %convergence.target.68.ready, label %scheduler.loop

convergence.target.68.ready:                      ; preds = %convergence.cascade.exit1141
  %5694 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %5695 = bitcast <8 x i1> %convergence.cascade.result1156 to i8
  %5696 = call i8 @llvm.cttz.i8(i8 %5695, i1 false)
  %5697 = zext i8 %5696 to i32
  %5698 = select i1 %5694, i32 %5697, i32 0
  %.state1157 = load <8 x float>, ptr %.slot58, align 32
  %5699 = fmul <8 x float> %.state1157, splat (float 0x3FC43D1360000000)
  %.state1158 = load <8 x float>, ptr %.slot65, align 32
  %5700 = fmul <8 x float> %.state1158, splat (float 0x3FC43D1360000000)
  %.state1159 = load <8 x float>, ptr %.slot69, align 32
  %5701 = fmul <8 x float> %.state1159, splat (float 0x3FC43D1360000000)
  %.state1160 = load <8 x float>, ptr %.slot70, align 32
  %5702 = fmul <8 x float> %.state1160, splat (float 0x3FC43D1360000000)
  %.state1161 = load <8 x float>, ptr %.slot74, align 32
  %5703 = fmul <8 x float> %.state1161, splat (float 0x3FC43D1360000000)
  %.state1162 = load <8 x float>, ptr %.slot75, align 32
  %5704 = fmul <8 x float> %.state1162, splat (float 0x3FC43D1360000000)
  %.state1163 = load <8 x float>, ptr %.slot79, align 32
  %5705 = fmul <8 x float> %.state1163, splat (float 0x3FC43D1360000000)
  %.state1164 = load <8 x float>, ptr %.slot80, align 32
  %5706 = fmul <8 x float> %.state1164, splat (float 0x3FC43D1360000000)
  %.state1165 = load <8 x float>, ptr %.slot84, align 32
  %5707 = fmul <8 x float> %.state1165, splat (float 0x3FC43D1360000000)
  %.state1166 = load <8 x float>, ptr %.slot85, align 32
  %5708 = fmul <8 x float> %.state1166, splat (float 0x3FC43D1360000000)
  %.state1167 = load <8 x float>, ptr %.slot89, align 32
  %5709 = fmul <8 x float> %.state1167, splat (float 0x3FC43D1360000000)
  %.state1168 = load <8 x float>, ptr %.slot90, align 32
  %5710 = fmul <8 x float> %.state1168, splat (float 0x3FC43D1360000000)
  %.state1169 = load <8 x float>, ptr %.slot94, align 32
  %5711 = fmul <8 x float> %.state1169, splat (float 0x3FC43D1360000000)
  %.state1170 = load <8 x float>, ptr %.slot95, align 32
  %5712 = fmul <8 x float> %.state1170, splat (float 0x3FC43D1360000000)
  %.state1171 = load <8 x float>, ptr %.slot99, align 32
  %5713 = fmul <8 x float> %.state1171, splat (float 0x3FC43D1360000000)
  %.state1172 = load <8 x float>, ptr %.slot100, align 32
  %5714 = fmul <8 x float> %.state1172, splat (float 0x3FC43D1360000000)
  %.state1173 = load <8 x float>, ptr %.slot66, align 32
  %5715 = fmul <8 x float> %.state1173, splat (float 0x3FC43D1360000000)
  %.state1174 = load <8 x float>, ptr %.slot67, align 32
  %5716 = fmul <8 x float> %.state1174, splat (float 0x3FC43D1360000000)
  %.state1175 = load <8 x float>, ptr %.slot71, align 32
  %5717 = fmul <8 x float> %.state1175, splat (float 0x3FC43D1360000000)
  %.state1176 = load <8 x float>, ptr %.slot72, align 32
  %5718 = fmul <8 x float> %.state1176, splat (float 0x3FC43D1360000000)
  %.state1177 = load <8 x float>, ptr %.slot76, align 32
  %5719 = fmul <8 x float> %.state1177, splat (float 0x3FC43D1360000000)
  %.state1178 = load <8 x float>, ptr %.slot77, align 32
  %5720 = fmul <8 x float> %.state1178, splat (float 0x3FC43D1360000000)
  %.state1179 = load <8 x float>, ptr %.slot81, align 32
  %5721 = fmul <8 x float> %.state1179, splat (float 0x3FC43D1360000000)
  %.state1180 = load <8 x float>, ptr %.slot82, align 32
  %5722 = fmul <8 x float> %.state1180, splat (float 0x3FC43D1360000000)
  %.state1181 = load <8 x float>, ptr %.slot86, align 32
  %5723 = fmul <8 x float> %.state1181, splat (float 0x3FC43D1360000000)
  %.state1182 = load <8 x float>, ptr %.slot87, align 32
  %5724 = fmul <8 x float> %.state1182, splat (float 0x3FC43D1360000000)
  %.state1183 = load <8 x float>, ptr %.slot91, align 32
  %5725 = fmul <8 x float> %.state1183, splat (float 0x3FC43D1360000000)
  %.state1184 = load <8 x float>, ptr %.slot92, align 32
  %5726 = fmul <8 x float> %.state1184, splat (float 0x3FC43D1360000000)
  %.state1185 = load <8 x float>, ptr %.slot96, align 32
  %5727 = fmul <8 x float> %.state1185, splat (float 0x3FC43D1360000000)
  %.state1186 = load <8 x float>, ptr %.slot97, align 32
  %5728 = fmul <8 x float> %.state1186, splat (float 0x3FC43D1360000000)
  %.state1187 = load <8 x float>, ptr %.slot101, align 32
  %5729 = fmul <8 x float> %.state1187, splat (float 0x3FC43D1360000000)
  %.state1188 = load <8 x float>, ptr %.slot102, align 32
  %5730 = fmul <8 x float> %.state1188, splat (float 0x3FC43D1360000000)
  %.state1189 = load <8 x float>, ptr %.slot104, align 32
  %5731 = fmul <8 x float> %.state1189, splat (float 0x3FC43D1360000000)
  %.state1190 = load <8 x float>, ptr %.slot105, align 32
  %5732 = fmul <8 x float> %.state1190, splat (float 0x3FC43D1360000000)
  %.state1191 = load <8 x float>, ptr %.slot109, align 32
  %5733 = fmul <8 x float> %.state1191, splat (float 0x3FC43D1360000000)
  %.state1192 = load <8 x float>, ptr %.slot110, align 32
  %5734 = fmul <8 x float> %.state1192, splat (float 0x3FC43D1360000000)
  %.state1193 = load <8 x float>, ptr %.slot114, align 32
  %5735 = fmul <8 x float> %.state1193, splat (float 0x3FC43D1360000000)
  %.state1194 = load <8 x float>, ptr %.slot115, align 32
  %5736 = fmul <8 x float> %.state1194, splat (float 0x3FC43D1360000000)
  %.state1195 = load <8 x float>, ptr %.slot119, align 32
  %5737 = fmul <8 x float> %.state1195, splat (float 0x3FC43D1360000000)
  %.state1196 = load <8 x float>, ptr %.slot120, align 32
  %5738 = fmul <8 x float> %.state1196, splat (float 0x3FC43D1360000000)
  %.state1197 = load <8 x float>, ptr %.slot124, align 32
  %5739 = fmul <8 x float> %.state1197, splat (float 0x3FC43D1360000000)
  %.state1198 = load <8 x float>, ptr %.slot125, align 32
  %5740 = fmul <8 x float> %.state1198, splat (float 0x3FC43D1360000000)
  %.state1199 = load <8 x float>, ptr %.slot129, align 32
  %5741 = fmul <8 x float> %.state1199, splat (float 0x3FC43D1360000000)
  %.state1200 = load <8 x float>, ptr %.slot130, align 32
  %5742 = fmul <8 x float> %.state1200, splat (float 0x3FC43D1360000000)
  %.state1201 = load <8 x float>, ptr %.slot134, align 32
  %5743 = fmul <8 x float> %.state1201, splat (float 0x3FC43D1360000000)
  %.state1202 = load <8 x float>, ptr %.slot135, align 32
  %5744 = fmul <8 x float> %.state1202, splat (float 0x3FC43D1360000000)
  %.state1203 = load <8 x float>, ptr %.slot139, align 32
  %5745 = fmul <8 x float> %.state1203, splat (float 0x3FC43D1360000000)
  %.state1204 = load <8 x float>, ptr %.slot140, align 32
  %5746 = fmul <8 x float> %.state1204, splat (float 0x3FC43D1360000000)
  %.state1205 = load <8 x float>, ptr %.slot106, align 32
  %5747 = fmul <8 x float> %.state1205, splat (float 0x3FC43D1360000000)
  %.state1206 = load <8 x float>, ptr %.slot107, align 32
  %5748 = fmul <8 x float> %.state1206, splat (float 0x3FC43D1360000000)
  %.state1207 = load <8 x float>, ptr %.slot111, align 32
  %5749 = fmul <8 x float> %.state1207, splat (float 0x3FC43D1360000000)
  %.state1208 = load <8 x float>, ptr %.slot112, align 32
  %5750 = fmul <8 x float> %.state1208, splat (float 0x3FC43D1360000000)
  %.state1209 = load <8 x float>, ptr %.slot116, align 32
  %5751 = fmul <8 x float> %.state1209, splat (float 0x3FC43D1360000000)
  %.state1210 = load <8 x float>, ptr %.slot117, align 32
  %5752 = fmul <8 x float> %.state1210, splat (float 0x3FC43D1360000000)
  %.state1211 = load <8 x float>, ptr %.slot121, align 32
  %5753 = fmul <8 x float> %.state1211, splat (float 0x3FC43D1360000000)
  %.state1212 = load <8 x float>, ptr %.slot122, align 32
  %5754 = fmul <8 x float> %.state1212, splat (float 0x3FC43D1360000000)
  %.state1213 = load <8 x float>, ptr %.slot126, align 32
  %5755 = fmul <8 x float> %.state1213, splat (float 0x3FC43D1360000000)
  %.state1214 = load <8 x float>, ptr %.slot127, align 32
  %5756 = fmul <8 x float> %.state1214, splat (float 0x3FC43D1360000000)
  %.state1215 = load <8 x float>, ptr %.slot131, align 32
  %5757 = fmul <8 x float> %.state1215, splat (float 0x3FC43D1360000000)
  %.state1216 = load <8 x float>, ptr %.slot132, align 32
  %5758 = fmul <8 x float> %.state1216, splat (float 0x3FC43D1360000000)
  %.state1217 = load <8 x float>, ptr %.slot136, align 32
  %5759 = fmul <8 x float> %.state1217, splat (float 0x3FC43D1360000000)
  %.state1218 = load <8 x float>, ptr %.slot137, align 32
  %5760 = fmul <8 x float> %.state1218, splat (float 0x3FC43D1360000000)
  %.state1219 = load <8 x float>, ptr %.slot141, align 32
  %5761 = fmul <8 x float> %.state1219, splat (float 0x3FC43D1360000000)
  %.state1220 = load <8 x float>, ptr %.slot142, align 32
  %5762 = fmul <8 x float> %.state1220, splat (float 0x3FC43D1360000000)
  %.spill.load1221 = load <8 x i64>, ptr %.spill54, align 64
  %5763 = add <8 x i64> zeroinitializer, %.spill.load1221
  %.spill.load1222 = load <8 x i64>, ptr %.spill54, align 64
  %5764 = add <8 x i64> splat (i64 1), %.spill.load1222
  %.spill.load1223 = load <8 x i64>, ptr %.spill54, align 64
  %5765 = add <8 x i64> splat (i64 2), %.spill.load1223
  %.spill.load1224 = load <8 x i64>, ptr %.spill54, align 64
  %5766 = add <8 x i64> splat (i64 3), %.spill.load1224
  %.spill.load1225 = load <8 x i64>, ptr %.spill54, align 64
  %5767 = add <8 x i64> splat (i64 4), %.spill.load1225
  %.spill.load1226 = load <8 x i64>, ptr %.spill54, align 64
  %5768 = add <8 x i64> splat (i64 5), %.spill.load1226
  %.spill.load1227 = load <8 x i64>, ptr %.spill54, align 64
  %5769 = add <8 x i64> splat (i64 6), %.spill.load1227
  %.spill.load1228 = load <8 x i64>, ptr %.spill54, align 64
  %5770 = add <8 x i64> splat (i64 7), %.spill.load1228
  %.spill.load1229 = load <8 x i64>, ptr %.spill54, align 64
  %5771 = add <8 x i64> splat (i64 8), %.spill.load1229
  %.spill.load1230 = load <8 x i64>, ptr %.spill54, align 64
  %5772 = add <8 x i64> splat (i64 9), %.spill.load1230
  %.spill.load1231 = load <8 x i64>, ptr %.spill54, align 64
  %5773 = add <8 x i64> splat (i64 10), %.spill.load1231
  %.spill.load1232 = load <8 x i64>, ptr %.spill54, align 64
  %5774 = add <8 x i64> splat (i64 11), %.spill.load1232
  %.spill.load1233 = load <8 x i64>, ptr %.spill54, align 64
  %5775 = add <8 x i64> splat (i64 12), %.spill.load1233
  %.spill.load1234 = load <8 x i64>, ptr %.spill54, align 64
  %5776 = add <8 x i64> splat (i64 13), %.spill.load1234
  %.spill.load1235 = load <8 x i64>, ptr %.spill54, align 64
  %5777 = add <8 x i64> splat (i64 14), %.spill.load1235
  %.spill.load1236 = load <8 x i64>, ptr %.spill54, align 64
  %5778 = add <8 x i64> splat (i64 15), %.spill.load1236
  %5779 = icmp slt <8 x i64> %5763, splat (i64 67)
  %5780 = icmp slt <8 x i64> %5764, splat (i64 67)
  %5781 = icmp slt <8 x i64> %5765, splat (i64 67)
  %5782 = icmp slt <8 x i64> %5766, splat (i64 67)
  %5783 = icmp slt <8 x i64> %5767, splat (i64 67)
  %5784 = icmp slt <8 x i64> %5768, splat (i64 67)
  %5785 = icmp slt <8 x i64> %5769, splat (i64 67)
  %5786 = icmp slt <8 x i64> %5770, splat (i64 67)
  %5787 = icmp slt <8 x i64> %5771, splat (i64 67)
  %5788 = icmp slt <8 x i64> %5772, splat (i64 67)
  %5789 = icmp slt <8 x i64> %5773, splat (i64 67)
  %5790 = icmp slt <8 x i64> %5774, splat (i64 67)
  %5791 = icmp slt <8 x i64> %5775, splat (i64 67)
  %5792 = icmp slt <8 x i64> %5776, splat (i64 67)
  %5793 = icmp slt <8 x i64> %5777, splat (i64 67)
  %5794 = icmp slt <8 x i64> %5778, splat (i64 67)
  %.spill.load1237 = load <8 x i64>, ptr %.spill38, align 64
  %5795 = add <8 x i64> zeroinitializer, %.spill.load1237
  %.spill.load1238 = load <8 x i64>, ptr %.spill38, align 64
  %5796 = add <8 x i64> splat (i64 1), %.spill.load1238
  %.spill.load1239 = load <8 x i64>, ptr %.spill38, align 64
  %5797 = add <8 x i64> splat (i64 2), %.spill.load1239
  %.spill.load1240 = load <8 x i64>, ptr %.spill38, align 64
  %5798 = add <8 x i64> splat (i64 3), %.spill.load1240
  %5799 = add <8 x i64> %5795, splat (i64 67)
  %5800 = add <8 x i64> %5796, splat (i64 67)
  %5801 = add <8 x i64> %5797, splat (i64 67)
  %5802 = add <8 x i64> %5798, splat (i64 67)
  %5803 = sub <8 x i64> %5799, splat (i64 17)
  %5804 = sub <8 x i64> %5800, splat (i64 17)
  %5805 = sub <8 x i64> %5801, splat (i64 17)
  %5806 = sub <8 x i64> %5802, splat (i64 17)
  %5807 = icmp sle <8 x i64> %5763, %5803
  %5808 = icmp sle <8 x i64> %5763, %5804
  %5809 = icmp sle <8 x i64> %5763, %5805
  %5810 = icmp sle <8 x i64> %5763, %5806
  %5811 = icmp sle <8 x i64> %5764, %5803
  %5812 = icmp sle <8 x i64> %5764, %5804
  %5813 = icmp sle <8 x i64> %5764, %5805
  %5814 = icmp sle <8 x i64> %5764, %5806
  %5815 = icmp sle <8 x i64> %5765, %5803
  %5816 = icmp sle <8 x i64> %5765, %5804
  %5817 = icmp sle <8 x i64> %5765, %5805
  %5818 = icmp sle <8 x i64> %5765, %5806
  %5819 = icmp sle <8 x i64> %5766, %5803
  %5820 = icmp sle <8 x i64> %5766, %5804
  %5821 = icmp sle <8 x i64> %5766, %5805
  %5822 = icmp sle <8 x i64> %5766, %5806
  %5823 = icmp sle <8 x i64> %5767, %5803
  %5824 = icmp sle <8 x i64> %5767, %5804
  %5825 = icmp sle <8 x i64> %5767, %5805
  %5826 = icmp sle <8 x i64> %5767, %5806
  %5827 = icmp sle <8 x i64> %5768, %5803
  %5828 = icmp sle <8 x i64> %5768, %5804
  %5829 = icmp sle <8 x i64> %5768, %5805
  %5830 = icmp sle <8 x i64> %5768, %5806
  %5831 = icmp sle <8 x i64> %5769, %5803
  %5832 = icmp sle <8 x i64> %5769, %5804
  %5833 = icmp sle <8 x i64> %5769, %5805
  %5834 = icmp sle <8 x i64> %5769, %5806
  %5835 = icmp sle <8 x i64> %5770, %5803
  %5836 = icmp sle <8 x i64> %5770, %5804
  %5837 = icmp sle <8 x i64> %5770, %5805
  %5838 = icmp sle <8 x i64> %5770, %5806
  %5839 = icmp sle <8 x i64> %5771, %5803
  %5840 = icmp sle <8 x i64> %5771, %5804
  %5841 = icmp sle <8 x i64> %5771, %5805
  %5842 = icmp sle <8 x i64> %5771, %5806
  %5843 = icmp sle <8 x i64> %5772, %5803
  %5844 = icmp sle <8 x i64> %5772, %5804
  %5845 = icmp sle <8 x i64> %5772, %5805
  %5846 = icmp sle <8 x i64> %5772, %5806
  %5847 = icmp sle <8 x i64> %5773, %5803
  %5848 = icmp sle <8 x i64> %5773, %5804
  %5849 = icmp sle <8 x i64> %5773, %5805
  %5850 = icmp sle <8 x i64> %5773, %5806
  %5851 = icmp sle <8 x i64> %5774, %5803
  %5852 = icmp sle <8 x i64> %5774, %5804
  %5853 = icmp sle <8 x i64> %5774, %5805
  %5854 = icmp sle <8 x i64> %5774, %5806
  %5855 = icmp sle <8 x i64> %5775, %5803
  %5856 = icmp sle <8 x i64> %5775, %5804
  %5857 = icmp sle <8 x i64> %5775, %5805
  %5858 = icmp sle <8 x i64> %5775, %5806
  %5859 = icmp sle <8 x i64> %5776, %5803
  %5860 = icmp sle <8 x i64> %5776, %5804
  %5861 = icmp sle <8 x i64> %5776, %5805
  %5862 = icmp sle <8 x i64> %5776, %5806
  %5863 = icmp sle <8 x i64> %5777, %5803
  %5864 = icmp sle <8 x i64> %5777, %5804
  %5865 = icmp sle <8 x i64> %5777, %5805
  %5866 = icmp sle <8 x i64> %5777, %5806
  %5867 = icmp sle <8 x i64> %5778, %5803
  %5868 = icmp sle <8 x i64> %5778, %5804
  %5869 = icmp sle <8 x i64> %5778, %5805
  %5870 = icmp sle <8 x i64> %5778, %5806
  %5871 = and <8 x i1> %5779, %5807
  %5872 = load <8 x i1>, ptr %.spill143, align 1
  %5873 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5871, <8 x i1> %5872
  store <8 x i1> %5873, ptr %.spill143, align 1
  %5874 = and <8 x i1> %5779, %5808
  %5875 = load <8 x i1>, ptr %.spill144, align 1
  %5876 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5874, <8 x i1> %5875
  store <8 x i1> %5876, ptr %.spill144, align 1
  %5877 = and <8 x i1> %5779, %5809
  %5878 = load <8 x i1>, ptr %.spill145, align 1
  %5879 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5877, <8 x i1> %5878
  store <8 x i1> %5879, ptr %.spill145, align 1
  %5880 = and <8 x i1> %5779, %5810
  %5881 = load <8 x i1>, ptr %.spill146, align 1
  %5882 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5880, <8 x i1> %5881
  store <8 x i1> %5882, ptr %.spill146, align 1
  %5883 = and <8 x i1> %5780, %5811
  %5884 = load <8 x i1>, ptr %.spill147, align 1
  %5885 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5883, <8 x i1> %5884
  store <8 x i1> %5885, ptr %.spill147, align 1
  %5886 = and <8 x i1> %5780, %5812
  %5887 = load <8 x i1>, ptr %.spill148, align 1
  %5888 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5886, <8 x i1> %5887
  store <8 x i1> %5888, ptr %.spill148, align 1
  %5889 = and <8 x i1> %5780, %5813
  %5890 = load <8 x i1>, ptr %.spill149, align 1
  %5891 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5889, <8 x i1> %5890
  store <8 x i1> %5891, ptr %.spill149, align 1
  %5892 = and <8 x i1> %5780, %5814
  %5893 = load <8 x i1>, ptr %.spill150, align 1
  %5894 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5892, <8 x i1> %5893
  store <8 x i1> %5894, ptr %.spill150, align 1
  %5895 = and <8 x i1> %5781, %5815
  %5896 = load <8 x i1>, ptr %.spill151, align 1
  %5897 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5895, <8 x i1> %5896
  store <8 x i1> %5897, ptr %.spill151, align 1
  %5898 = and <8 x i1> %5781, %5816
  %5899 = load <8 x i1>, ptr %.spill152, align 1
  %5900 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5898, <8 x i1> %5899
  store <8 x i1> %5900, ptr %.spill152, align 1
  %5901 = and <8 x i1> %5781, %5817
  %5902 = load <8 x i1>, ptr %.spill153, align 1
  %5903 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5901, <8 x i1> %5902
  store <8 x i1> %5903, ptr %.spill153, align 1
  %5904 = and <8 x i1> %5781, %5818
  %5905 = load <8 x i1>, ptr %.spill154, align 1
  %5906 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5904, <8 x i1> %5905
  store <8 x i1> %5906, ptr %.spill154, align 1
  %5907 = and <8 x i1> %5782, %5819
  %5908 = load <8 x i1>, ptr %.spill155, align 1
  %5909 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5907, <8 x i1> %5908
  store <8 x i1> %5909, ptr %.spill155, align 1
  %5910 = and <8 x i1> %5782, %5820
  %5911 = load <8 x i1>, ptr %.spill156, align 1
  %5912 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5910, <8 x i1> %5911
  store <8 x i1> %5912, ptr %.spill156, align 1
  %5913 = and <8 x i1> %5782, %5821
  %5914 = load <8 x i1>, ptr %.spill157, align 1
  %5915 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5913, <8 x i1> %5914
  store <8 x i1> %5915, ptr %.spill157, align 1
  %5916 = and <8 x i1> %5782, %5822
  %5917 = load <8 x i1>, ptr %.spill158, align 1
  %5918 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5916, <8 x i1> %5917
  store <8 x i1> %5918, ptr %.spill158, align 1
  %5919 = and <8 x i1> %5783, %5823
  %5920 = load <8 x i1>, ptr %.spill159, align 1
  %5921 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5919, <8 x i1> %5920
  store <8 x i1> %5921, ptr %.spill159, align 1
  %5922 = and <8 x i1> %5783, %5824
  %5923 = load <8 x i1>, ptr %.spill160, align 1
  %5924 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5922, <8 x i1> %5923
  store <8 x i1> %5924, ptr %.spill160, align 1
  %5925 = and <8 x i1> %5783, %5825
  %5926 = load <8 x i1>, ptr %.spill161, align 1
  %5927 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5925, <8 x i1> %5926
  store <8 x i1> %5927, ptr %.spill161, align 1
  %5928 = and <8 x i1> %5783, %5826
  %5929 = load <8 x i1>, ptr %.spill162, align 1
  %5930 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5928, <8 x i1> %5929
  store <8 x i1> %5930, ptr %.spill162, align 1
  %5931 = and <8 x i1> %5784, %5827
  %5932 = load <8 x i1>, ptr %.spill163, align 1
  %5933 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5931, <8 x i1> %5932
  store <8 x i1> %5933, ptr %.spill163, align 1
  %5934 = and <8 x i1> %5784, %5828
  %5935 = load <8 x i1>, ptr %.spill164, align 1
  %5936 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5934, <8 x i1> %5935
  store <8 x i1> %5936, ptr %.spill164, align 1
  %5937 = and <8 x i1> %5784, %5829
  %5938 = load <8 x i1>, ptr %.spill165, align 1
  %5939 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5937, <8 x i1> %5938
  store <8 x i1> %5939, ptr %.spill165, align 1
  %5940 = and <8 x i1> %5784, %5830
  %5941 = load <8 x i1>, ptr %.spill166, align 1
  %5942 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5940, <8 x i1> %5941
  store <8 x i1> %5942, ptr %.spill166, align 1
  %5943 = and <8 x i1> %5785, %5831
  %5944 = load <8 x i1>, ptr %.spill167, align 1
  %5945 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5943, <8 x i1> %5944
  store <8 x i1> %5945, ptr %.spill167, align 1
  %5946 = and <8 x i1> %5785, %5832
  %5947 = load <8 x i1>, ptr %.spill168, align 1
  %5948 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5946, <8 x i1> %5947
  store <8 x i1> %5948, ptr %.spill168, align 1
  %5949 = and <8 x i1> %5785, %5833
  %5950 = load <8 x i1>, ptr %.spill169, align 1
  %5951 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5949, <8 x i1> %5950
  store <8 x i1> %5951, ptr %.spill169, align 1
  %5952 = and <8 x i1> %5785, %5834
  %5953 = load <8 x i1>, ptr %.spill170, align 1
  %5954 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5952, <8 x i1> %5953
  store <8 x i1> %5954, ptr %.spill170, align 1
  %5955 = and <8 x i1> %5786, %5835
  %5956 = load <8 x i1>, ptr %.spill171, align 1
  %5957 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5955, <8 x i1> %5956
  store <8 x i1> %5957, ptr %.spill171, align 1
  %5958 = and <8 x i1> %5786, %5836
  %5959 = load <8 x i1>, ptr %.spill172, align 1
  %5960 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5958, <8 x i1> %5959
  store <8 x i1> %5960, ptr %.spill172, align 1
  %5961 = and <8 x i1> %5786, %5837
  %5962 = load <8 x i1>, ptr %.spill173, align 1
  %5963 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5961, <8 x i1> %5962
  store <8 x i1> %5963, ptr %.spill173, align 1
  %5964 = and <8 x i1> %5786, %5838
  %5965 = load <8 x i1>, ptr %.spill174, align 1
  %5966 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5964, <8 x i1> %5965
  store <8 x i1> %5966, ptr %.spill174, align 1
  %5967 = and <8 x i1> %5787, %5839
  %5968 = load <8 x i1>, ptr %.spill175, align 1
  %5969 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5967, <8 x i1> %5968
  store <8 x i1> %5969, ptr %.spill175, align 1
  %5970 = and <8 x i1> %5787, %5840
  %5971 = load <8 x i1>, ptr %.spill176, align 1
  %5972 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5970, <8 x i1> %5971
  store <8 x i1> %5972, ptr %.spill176, align 1
  %5973 = and <8 x i1> %5787, %5841
  %5974 = load <8 x i1>, ptr %.spill177, align 1
  %5975 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5973, <8 x i1> %5974
  store <8 x i1> %5975, ptr %.spill177, align 1
  %5976 = and <8 x i1> %5787, %5842
  %5977 = load <8 x i1>, ptr %.spill178, align 1
  %5978 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5976, <8 x i1> %5977
  store <8 x i1> %5978, ptr %.spill178, align 1
  %5979 = and <8 x i1> %5788, %5843
  %5980 = load <8 x i1>, ptr %.spill179, align 1
  %5981 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5979, <8 x i1> %5980
  store <8 x i1> %5981, ptr %.spill179, align 1
  %5982 = and <8 x i1> %5788, %5844
  %5983 = load <8 x i1>, ptr %.spill180, align 1
  %5984 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5982, <8 x i1> %5983
  store <8 x i1> %5984, ptr %.spill180, align 1
  %5985 = and <8 x i1> %5788, %5845
  %5986 = load <8 x i1>, ptr %.spill181, align 1
  %5987 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5985, <8 x i1> %5986
  store <8 x i1> %5987, ptr %.spill181, align 1
  %5988 = and <8 x i1> %5788, %5846
  %5989 = load <8 x i1>, ptr %.spill182, align 1
  %5990 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5988, <8 x i1> %5989
  store <8 x i1> %5990, ptr %.spill182, align 1
  %5991 = and <8 x i1> %5789, %5847
  %5992 = load <8 x i1>, ptr %.spill183, align 1
  %5993 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5991, <8 x i1> %5992
  store <8 x i1> %5993, ptr %.spill183, align 1
  %5994 = and <8 x i1> %5789, %5848
  %5995 = load <8 x i1>, ptr %.spill184, align 1
  %5996 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5994, <8 x i1> %5995
  store <8 x i1> %5996, ptr %.spill184, align 1
  %5997 = and <8 x i1> %5789, %5849
  %5998 = load <8 x i1>, ptr %.spill185, align 1
  %5999 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %5997, <8 x i1> %5998
  store <8 x i1> %5999, ptr %.spill185, align 1
  %6000 = and <8 x i1> %5789, %5850
  %6001 = load <8 x i1>, ptr %.spill186, align 1
  %6002 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6000, <8 x i1> %6001
  store <8 x i1> %6002, ptr %.spill186, align 1
  %6003 = and <8 x i1> %5790, %5851
  %6004 = load <8 x i1>, ptr %.spill187, align 1
  %6005 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6003, <8 x i1> %6004
  store <8 x i1> %6005, ptr %.spill187, align 1
  %6006 = and <8 x i1> %5790, %5852
  %6007 = load <8 x i1>, ptr %.spill188, align 1
  %6008 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6006, <8 x i1> %6007
  store <8 x i1> %6008, ptr %.spill188, align 1
  %6009 = and <8 x i1> %5790, %5853
  %6010 = load <8 x i1>, ptr %.spill189, align 1
  %6011 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6009, <8 x i1> %6010
  store <8 x i1> %6011, ptr %.spill189, align 1
  %6012 = and <8 x i1> %5790, %5854
  %6013 = load <8 x i1>, ptr %.spill190, align 1
  %6014 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6012, <8 x i1> %6013
  store <8 x i1> %6014, ptr %.spill190, align 1
  %6015 = and <8 x i1> %5791, %5855
  %6016 = load <8 x i1>, ptr %.spill191, align 1
  %6017 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6015, <8 x i1> %6016
  store <8 x i1> %6017, ptr %.spill191, align 1
  %6018 = and <8 x i1> %5791, %5856
  %6019 = load <8 x i1>, ptr %.spill192, align 1
  %6020 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6018, <8 x i1> %6019
  store <8 x i1> %6020, ptr %.spill192, align 1
  %6021 = and <8 x i1> %5791, %5857
  %6022 = load <8 x i1>, ptr %.spill193, align 1
  %6023 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6021, <8 x i1> %6022
  store <8 x i1> %6023, ptr %.spill193, align 1
  %6024 = and <8 x i1> %5791, %5858
  %6025 = load <8 x i1>, ptr %.spill194, align 1
  %6026 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6024, <8 x i1> %6025
  store <8 x i1> %6026, ptr %.spill194, align 1
  %6027 = and <8 x i1> %5792, %5859
  %6028 = load <8 x i1>, ptr %.spill195, align 1
  %6029 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6027, <8 x i1> %6028
  store <8 x i1> %6029, ptr %.spill195, align 1
  %6030 = and <8 x i1> %5792, %5860
  %6031 = load <8 x i1>, ptr %.spill196, align 1
  %6032 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6030, <8 x i1> %6031
  store <8 x i1> %6032, ptr %.spill196, align 1
  %6033 = and <8 x i1> %5792, %5861
  %6034 = load <8 x i1>, ptr %.spill197, align 1
  %6035 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6033, <8 x i1> %6034
  store <8 x i1> %6035, ptr %.spill197, align 1
  %6036 = and <8 x i1> %5792, %5862
  %6037 = load <8 x i1>, ptr %.spill198, align 1
  %6038 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6036, <8 x i1> %6037
  store <8 x i1> %6038, ptr %.spill198, align 1
  %6039 = and <8 x i1> %5793, %5863
  %6040 = load <8 x i1>, ptr %.spill199, align 1
  %6041 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6039, <8 x i1> %6040
  store <8 x i1> %6041, ptr %.spill199, align 1
  %6042 = and <8 x i1> %5793, %5864
  %6043 = load <8 x i1>, ptr %.spill200, align 1
  %6044 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6042, <8 x i1> %6043
  store <8 x i1> %6044, ptr %.spill200, align 1
  %6045 = and <8 x i1> %5793, %5865
  %6046 = load <8 x i1>, ptr %.spill201, align 1
  %6047 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6045, <8 x i1> %6046
  store <8 x i1> %6047, ptr %.spill201, align 1
  %6048 = and <8 x i1> %5793, %5866
  %6049 = load <8 x i1>, ptr %.spill202, align 1
  %6050 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6048, <8 x i1> %6049
  store <8 x i1> %6050, ptr %.spill202, align 1
  %6051 = and <8 x i1> %5794, %5867
  %6052 = load <8 x i1>, ptr %.spill203, align 1
  %6053 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6051, <8 x i1> %6052
  store <8 x i1> %6053, ptr %.spill203, align 1
  %6054 = and <8 x i1> %5794, %5868
  %6055 = load <8 x i1>, ptr %.spill204, align 1
  %6056 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6054, <8 x i1> %6055
  store <8 x i1> %6056, ptr %.spill204, align 1
  %6057 = and <8 x i1> %5794, %5869
  %6058 = load <8 x i1>, ptr %.spill205, align 1
  %6059 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6057, <8 x i1> %6058
  store <8 x i1> %6059, ptr %.spill205, align 1
  %6060 = and <8 x i1> %5794, %5870
  %6061 = load <8 x i1>, ptr %.spill206, align 1
  %6062 = select <8 x i1> %convergence.cascade.result1156, <8 x i1> %6060, <8 x i1> %6061
  store <8 x i1> %6062, ptr %.spill206, align 1
  %6063 = select <8 x i1> %5871, <8 x float> %5699, <8 x float> splat (float 0xC6293E5940000000)
  %6064 = load <8 x float>, ptr %.spill207, align 32
  %6065 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6063, <8 x float> %6064
  store <8 x float> %6065, ptr %.spill207, align 32
  %6066 = select <8 x i1> %5883, <8 x float> %5700, <8 x float> splat (float 0xC6293E5940000000)
  %6067 = load <8 x float>, ptr %.spill208, align 32
  %6068 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6066, <8 x float> %6067
  store <8 x float> %6068, ptr %.spill208, align 32
  %6069 = select <8 x i1> %5895, <8 x float> %5701, <8 x float> splat (float 0xC6293E5940000000)
  %6070 = load <8 x float>, ptr %.spill209, align 32
  %6071 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6069, <8 x float> %6070
  store <8 x float> %6071, ptr %.spill209, align 32
  %6072 = select <8 x i1> %5907, <8 x float> %5702, <8 x float> splat (float 0xC6293E5940000000)
  %6073 = load <8 x float>, ptr %.spill210, align 32
  %6074 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6072, <8 x float> %6073
  store <8 x float> %6074, ptr %.spill210, align 32
  %6075 = select <8 x i1> %5919, <8 x float> %5703, <8 x float> splat (float 0xC6293E5940000000)
  %6076 = load <8 x float>, ptr %.spill211, align 32
  %6077 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6075, <8 x float> %6076
  store <8 x float> %6077, ptr %.spill211, align 32
  %6078 = select <8 x i1> %5931, <8 x float> %5704, <8 x float> splat (float 0xC6293E5940000000)
  %6079 = load <8 x float>, ptr %.spill212, align 32
  %6080 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6078, <8 x float> %6079
  store <8 x float> %6080, ptr %.spill212, align 32
  %6081 = select <8 x i1> %5943, <8 x float> %5705, <8 x float> splat (float 0xC6293E5940000000)
  %6082 = load <8 x float>, ptr %.spill213, align 32
  %6083 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6081, <8 x float> %6082
  store <8 x float> %6083, ptr %.spill213, align 32
  %6084 = select <8 x i1> %5955, <8 x float> %5706, <8 x float> splat (float 0xC6293E5940000000)
  %6085 = load <8 x float>, ptr %.spill214, align 32
  %6086 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6084, <8 x float> %6085
  store <8 x float> %6086, ptr %.spill214, align 32
  %6087 = select <8 x i1> %5967, <8 x float> %5707, <8 x float> splat (float 0xC6293E5940000000)
  %6088 = load <8 x float>, ptr %.spill215, align 32
  %6089 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6087, <8 x float> %6088
  store <8 x float> %6089, ptr %.spill215, align 32
  %6090 = select <8 x i1> %5979, <8 x float> %5708, <8 x float> splat (float 0xC6293E5940000000)
  %6091 = load <8 x float>, ptr %.spill216, align 32
  %6092 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6090, <8 x float> %6091
  store <8 x float> %6092, ptr %.spill216, align 32
  %6093 = select <8 x i1> %5991, <8 x float> %5709, <8 x float> splat (float 0xC6293E5940000000)
  %6094 = load <8 x float>, ptr %.spill217, align 32
  %6095 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6093, <8 x float> %6094
  store <8 x float> %6095, ptr %.spill217, align 32
  %6096 = select <8 x i1> %6003, <8 x float> %5710, <8 x float> splat (float 0xC6293E5940000000)
  %6097 = load <8 x float>, ptr %.spill218, align 32
  %6098 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6096, <8 x float> %6097
  store <8 x float> %6098, ptr %.spill218, align 32
  %6099 = select <8 x i1> %6015, <8 x float> %5711, <8 x float> splat (float 0xC6293E5940000000)
  %6100 = load <8 x float>, ptr %.spill219, align 32
  %6101 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6099, <8 x float> %6100
  store <8 x float> %6101, ptr %.spill219, align 32
  %6102 = select <8 x i1> %6027, <8 x float> %5712, <8 x float> splat (float 0xC6293E5940000000)
  %6103 = load <8 x float>, ptr %.spill220, align 32
  %6104 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6102, <8 x float> %6103
  store <8 x float> %6104, ptr %.spill220, align 32
  %6105 = select <8 x i1> %6039, <8 x float> %5713, <8 x float> splat (float 0xC6293E5940000000)
  %6106 = load <8 x float>, ptr %.spill221, align 32
  %6107 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6105, <8 x float> %6106
  store <8 x float> %6107, ptr %.spill221, align 32
  %6108 = select <8 x i1> %6051, <8 x float> %5714, <8 x float> splat (float 0xC6293E5940000000)
  %6109 = load <8 x float>, ptr %.spill222, align 32
  %6110 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6108, <8 x float> %6109
  store <8 x float> %6110, ptr %.spill222, align 32
  %6111 = select <8 x i1> %5874, <8 x float> %5715, <8 x float> splat (float 0xC6293E5940000000)
  %6112 = load <8 x float>, ptr %.spill223, align 32
  %6113 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6111, <8 x float> %6112
  store <8 x float> %6113, ptr %.spill223, align 32
  %6114 = select <8 x i1> %5886, <8 x float> %5716, <8 x float> splat (float 0xC6293E5940000000)
  %6115 = load <8 x float>, ptr %.spill224, align 32
  %6116 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6114, <8 x float> %6115
  store <8 x float> %6116, ptr %.spill224, align 32
  %6117 = select <8 x i1> %5898, <8 x float> %5717, <8 x float> splat (float 0xC6293E5940000000)
  %6118 = load <8 x float>, ptr %.spill225, align 32
  %6119 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6117, <8 x float> %6118
  store <8 x float> %6119, ptr %.spill225, align 32
  %6120 = select <8 x i1> %5910, <8 x float> %5718, <8 x float> splat (float 0xC6293E5940000000)
  %6121 = load <8 x float>, ptr %.spill226, align 32
  %6122 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6120, <8 x float> %6121
  store <8 x float> %6122, ptr %.spill226, align 32
  %6123 = select <8 x i1> %5922, <8 x float> %5719, <8 x float> splat (float 0xC6293E5940000000)
  %6124 = load <8 x float>, ptr %.spill227, align 32
  %6125 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6123, <8 x float> %6124
  store <8 x float> %6125, ptr %.spill227, align 32
  %6126 = select <8 x i1> %5934, <8 x float> %5720, <8 x float> splat (float 0xC6293E5940000000)
  %6127 = load <8 x float>, ptr %.spill228, align 32
  %6128 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6126, <8 x float> %6127
  store <8 x float> %6128, ptr %.spill228, align 32
  %6129 = select <8 x i1> %5946, <8 x float> %5721, <8 x float> splat (float 0xC6293E5940000000)
  %6130 = load <8 x float>, ptr %.spill229, align 32
  %6131 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6129, <8 x float> %6130
  store <8 x float> %6131, ptr %.spill229, align 32
  %6132 = select <8 x i1> %5958, <8 x float> %5722, <8 x float> splat (float 0xC6293E5940000000)
  %6133 = load <8 x float>, ptr %.spill230, align 32
  %6134 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6132, <8 x float> %6133
  store <8 x float> %6134, ptr %.spill230, align 32
  %6135 = select <8 x i1> %5970, <8 x float> %5723, <8 x float> splat (float 0xC6293E5940000000)
  %6136 = load <8 x float>, ptr %.spill231, align 32
  %6137 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6135, <8 x float> %6136
  store <8 x float> %6137, ptr %.spill231, align 32
  %6138 = select <8 x i1> %5982, <8 x float> %5724, <8 x float> splat (float 0xC6293E5940000000)
  %6139 = load <8 x float>, ptr %.spill232, align 32
  %6140 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6138, <8 x float> %6139
  store <8 x float> %6140, ptr %.spill232, align 32
  %6141 = select <8 x i1> %5994, <8 x float> %5725, <8 x float> splat (float 0xC6293E5940000000)
  %6142 = load <8 x float>, ptr %.spill233, align 32
  %6143 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6141, <8 x float> %6142
  store <8 x float> %6143, ptr %.spill233, align 32
  %6144 = select <8 x i1> %6006, <8 x float> %5726, <8 x float> splat (float 0xC6293E5940000000)
  %6145 = load <8 x float>, ptr %.spill234, align 32
  %6146 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6144, <8 x float> %6145
  store <8 x float> %6146, ptr %.spill234, align 32
  %6147 = select <8 x i1> %6018, <8 x float> %5727, <8 x float> splat (float 0xC6293E5940000000)
  %6148 = load <8 x float>, ptr %.spill235, align 32
  %6149 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6147, <8 x float> %6148
  store <8 x float> %6149, ptr %.spill235, align 32
  %6150 = select <8 x i1> %6030, <8 x float> %5728, <8 x float> splat (float 0xC6293E5940000000)
  %6151 = load <8 x float>, ptr %.spill236, align 32
  %6152 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6150, <8 x float> %6151
  store <8 x float> %6152, ptr %.spill236, align 32
  %6153 = select <8 x i1> %6042, <8 x float> %5729, <8 x float> splat (float 0xC6293E5940000000)
  %6154 = load <8 x float>, ptr %.spill237, align 32
  %6155 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6153, <8 x float> %6154
  store <8 x float> %6155, ptr %.spill237, align 32
  %6156 = select <8 x i1> %6054, <8 x float> %5730, <8 x float> splat (float 0xC6293E5940000000)
  %6157 = load <8 x float>, ptr %.spill238, align 32
  %6158 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6156, <8 x float> %6157
  store <8 x float> %6158, ptr %.spill238, align 32
  %6159 = select <8 x i1> %5877, <8 x float> %5731, <8 x float> splat (float 0xC6293E5940000000)
  %6160 = load <8 x float>, ptr %.spill239, align 32
  %6161 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6159, <8 x float> %6160
  store <8 x float> %6161, ptr %.spill239, align 32
  %6162 = select <8 x i1> %5889, <8 x float> %5732, <8 x float> splat (float 0xC6293E5940000000)
  %6163 = load <8 x float>, ptr %.spill240, align 32
  %6164 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6162, <8 x float> %6163
  store <8 x float> %6164, ptr %.spill240, align 32
  %6165 = select <8 x i1> %5901, <8 x float> %5733, <8 x float> splat (float 0xC6293E5940000000)
  %6166 = load <8 x float>, ptr %.spill241, align 32
  %6167 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6165, <8 x float> %6166
  store <8 x float> %6167, ptr %.spill241, align 32
  %6168 = select <8 x i1> %5913, <8 x float> %5734, <8 x float> splat (float 0xC6293E5940000000)
  %6169 = load <8 x float>, ptr %.spill242, align 32
  %6170 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6168, <8 x float> %6169
  store <8 x float> %6170, ptr %.spill242, align 32
  %6171 = select <8 x i1> %5925, <8 x float> %5735, <8 x float> splat (float 0xC6293E5940000000)
  %6172 = load <8 x float>, ptr %.spill243, align 32
  %6173 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6171, <8 x float> %6172
  store <8 x float> %6173, ptr %.spill243, align 32
  %6174 = select <8 x i1> %5937, <8 x float> %5736, <8 x float> splat (float 0xC6293E5940000000)
  %6175 = load <8 x float>, ptr %.spill244, align 32
  %6176 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6174, <8 x float> %6175
  store <8 x float> %6176, ptr %.spill244, align 32
  %6177 = select <8 x i1> %5949, <8 x float> %5737, <8 x float> splat (float 0xC6293E5940000000)
  %6178 = load <8 x float>, ptr %.spill245, align 32
  %6179 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6177, <8 x float> %6178
  store <8 x float> %6179, ptr %.spill245, align 32
  %6180 = select <8 x i1> %5961, <8 x float> %5738, <8 x float> splat (float 0xC6293E5940000000)
  %6181 = load <8 x float>, ptr %.spill246, align 32
  %6182 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6180, <8 x float> %6181
  store <8 x float> %6182, ptr %.spill246, align 32
  %6183 = select <8 x i1> %5973, <8 x float> %5739, <8 x float> splat (float 0xC6293E5940000000)
  %6184 = load <8 x float>, ptr %.spill247, align 32
  %6185 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6183, <8 x float> %6184
  store <8 x float> %6185, ptr %.spill247, align 32
  %6186 = select <8 x i1> %5985, <8 x float> %5740, <8 x float> splat (float 0xC6293E5940000000)
  %6187 = load <8 x float>, ptr %.spill248, align 32
  %6188 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6186, <8 x float> %6187
  store <8 x float> %6188, ptr %.spill248, align 32
  %6189 = select <8 x i1> %5997, <8 x float> %5741, <8 x float> splat (float 0xC6293E5940000000)
  %6190 = load <8 x float>, ptr %.spill249, align 32
  %6191 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6189, <8 x float> %6190
  store <8 x float> %6191, ptr %.spill249, align 32
  %6192 = select <8 x i1> %6009, <8 x float> %5742, <8 x float> splat (float 0xC6293E5940000000)
  %6193 = load <8 x float>, ptr %.spill250, align 32
  %6194 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6192, <8 x float> %6193
  store <8 x float> %6194, ptr %.spill250, align 32
  %6195 = select <8 x i1> %6021, <8 x float> %5743, <8 x float> splat (float 0xC6293E5940000000)
  %6196 = load <8 x float>, ptr %.spill251, align 32
  %6197 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6195, <8 x float> %6196
  store <8 x float> %6197, ptr %.spill251, align 32
  %6198 = select <8 x i1> %6033, <8 x float> %5744, <8 x float> splat (float 0xC6293E5940000000)
  %6199 = load <8 x float>, ptr %.spill252, align 32
  %6200 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6198, <8 x float> %6199
  store <8 x float> %6200, ptr %.spill252, align 32
  %6201 = select <8 x i1> %6045, <8 x float> %5745, <8 x float> splat (float 0xC6293E5940000000)
  %6202 = load <8 x float>, ptr %.spill253, align 32
  %6203 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6201, <8 x float> %6202
  store <8 x float> %6203, ptr %.spill253, align 32
  %6204 = select <8 x i1> %6057, <8 x float> %5746, <8 x float> splat (float 0xC6293E5940000000)
  %6205 = load <8 x float>, ptr %.spill254, align 32
  %6206 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6204, <8 x float> %6205
  store <8 x float> %6206, ptr %.spill254, align 32
  %6207 = select <8 x i1> %5880, <8 x float> %5747, <8 x float> splat (float 0xC6293E5940000000)
  %6208 = load <8 x float>, ptr %.spill255, align 32
  %6209 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6207, <8 x float> %6208
  store <8 x float> %6209, ptr %.spill255, align 32
  %6210 = select <8 x i1> %5892, <8 x float> %5748, <8 x float> splat (float 0xC6293E5940000000)
  %6211 = load <8 x float>, ptr %.spill256, align 32
  %6212 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6210, <8 x float> %6211
  store <8 x float> %6212, ptr %.spill256, align 32
  %6213 = select <8 x i1> %5904, <8 x float> %5749, <8 x float> splat (float 0xC6293E5940000000)
  %6214 = load <8 x float>, ptr %.spill257, align 32
  %6215 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6213, <8 x float> %6214
  store <8 x float> %6215, ptr %.spill257, align 32
  %6216 = select <8 x i1> %5916, <8 x float> %5750, <8 x float> splat (float 0xC6293E5940000000)
  %6217 = load <8 x float>, ptr %.spill258, align 32
  %6218 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6216, <8 x float> %6217
  store <8 x float> %6218, ptr %.spill258, align 32
  %6219 = select <8 x i1> %5928, <8 x float> %5751, <8 x float> splat (float 0xC6293E5940000000)
  %6220 = load <8 x float>, ptr %.spill259, align 32
  %6221 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6219, <8 x float> %6220
  store <8 x float> %6221, ptr %.spill259, align 32
  %6222 = select <8 x i1> %5940, <8 x float> %5752, <8 x float> splat (float 0xC6293E5940000000)
  %6223 = load <8 x float>, ptr %.spill260, align 32
  %6224 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6222, <8 x float> %6223
  store <8 x float> %6224, ptr %.spill260, align 32
  %6225 = select <8 x i1> %5952, <8 x float> %5753, <8 x float> splat (float 0xC6293E5940000000)
  %6226 = load <8 x float>, ptr %.spill261, align 32
  %6227 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6225, <8 x float> %6226
  store <8 x float> %6227, ptr %.spill261, align 32
  %6228 = select <8 x i1> %5964, <8 x float> %5754, <8 x float> splat (float 0xC6293E5940000000)
  %6229 = load <8 x float>, ptr %.spill262, align 32
  %6230 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6228, <8 x float> %6229
  store <8 x float> %6230, ptr %.spill262, align 32
  %6231 = select <8 x i1> %5976, <8 x float> %5755, <8 x float> splat (float 0xC6293E5940000000)
  %6232 = load <8 x float>, ptr %.spill263, align 32
  %6233 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6231, <8 x float> %6232
  store <8 x float> %6233, ptr %.spill263, align 32
  %6234 = select <8 x i1> %5988, <8 x float> %5756, <8 x float> splat (float 0xC6293E5940000000)
  %6235 = load <8 x float>, ptr %.spill264, align 32
  %6236 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6234, <8 x float> %6235
  store <8 x float> %6236, ptr %.spill264, align 32
  %6237 = select <8 x i1> %6000, <8 x float> %5757, <8 x float> splat (float 0xC6293E5940000000)
  %6238 = load <8 x float>, ptr %.spill265, align 32
  %6239 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6237, <8 x float> %6238
  store <8 x float> %6239, ptr %.spill265, align 32
  %6240 = select <8 x i1> %6012, <8 x float> %5758, <8 x float> splat (float 0xC6293E5940000000)
  %6241 = load <8 x float>, ptr %.spill266, align 32
  %6242 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6240, <8 x float> %6241
  store <8 x float> %6242, ptr %.spill266, align 32
  %6243 = select <8 x i1> %6024, <8 x float> %5759, <8 x float> splat (float 0xC6293E5940000000)
  %6244 = load <8 x float>, ptr %.spill267, align 32
  %6245 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6243, <8 x float> %6244
  store <8 x float> %6245, ptr %.spill267, align 32
  %6246 = select <8 x i1> %6036, <8 x float> %5760, <8 x float> splat (float 0xC6293E5940000000)
  %6247 = load <8 x float>, ptr %.spill268, align 32
  %6248 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6246, <8 x float> %6247
  store <8 x float> %6248, ptr %.spill268, align 32
  %6249 = select <8 x i1> %6048, <8 x float> %5761, <8 x float> splat (float 0xC6293E5940000000)
  %6250 = load <8 x float>, ptr %.spill269, align 32
  %6251 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6249, <8 x float> %6250
  store <8 x float> %6251, ptr %.spill269, align 32
  %6252 = select <8 x i1> %6060, <8 x float> %5762, <8 x float> splat (float 0xC6293E5940000000)
  %6253 = load <8 x float>, ptr %.spill270, align 32
  %6254 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6252, <8 x float> %6253
  store <8 x float> %6254, ptr %.spill270, align 32
  %6255 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %6256 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6257 = extractvalue { <8 x ptr>, <8 x i64> } %6255, 0
  %6258 = select <8 x i1> %convergence.cascade.result1156, <8 x ptr> %6256, <8 x ptr> %6257
  %6259 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6260 = extractvalue { <8 x ptr>, <8 x i64> } %6255, 1
  %6261 = select <8 x i1> %convergence.cascade.result1156, <8 x i64> %6259, <8 x i64> %6260
  %6262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6258, 0
  %6263 = insertvalue { <8 x ptr>, <8 x i64> } %6262, <8 x i64> %6261, 1
  store { <8 x ptr>, <8 x i64> } %6263, ptr %tile_snapshot.spill271, align 64
  %6264 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6265 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6266 = add <8 x i64> %6265, zeroinitializer
  %6267 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6264, 0
  %6268 = insertvalue { <8 x ptr>, <8 x i64> } %6267, <8 x i64> %6266, 1
  %6269 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6270 = extractvalue { <8 x ptr>, <8 x i64> } %6268, 1
  %6271 = extractelement <8 x ptr> %6269, i32 0
  %6272 = extractelement <8 x i64> %6270, i32 %5698
  %6273 = zext i32 %5698 to i64
  %6274 = mul i64 %6273, 4
  %6275 = sub i64 %6272, %6274
  %6276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6277 = select i1 %6276, i64 %6275, i64 0
  %private.contiguous.address = getelementptr i8, ptr %6271, i64 %6277
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %6278 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6063, <8 x float> %private.contiguous.preserve
  store <8 x float> %6278, ptr %private.contiguous.address, align 4
  %6279 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6280 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6281 = add <8 x i64> %6280, splat (i64 32)
  %6282 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6279, 0
  %6283 = insertvalue { <8 x ptr>, <8 x i64> } %6282, <8 x i64> %6281, 1
  %6284 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6285 = extractvalue { <8 x ptr>, <8 x i64> } %6283, 1
  %6286 = extractelement <8 x ptr> %6284, i32 0
  %6287 = extractelement <8 x i64> %6285, i32 %5698
  %6288 = zext i32 %5698 to i64
  %6289 = mul i64 %6288, 4
  %6290 = sub i64 %6287, %6289
  %6291 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6292 = select i1 %6291, i64 %6290, i64 0
  %private.contiguous.address1241 = getelementptr i8, ptr %6286, i64 %6292
  %private.contiguous.preserve1242 = load <8 x float>, ptr %private.contiguous.address1241, align 4
  %6293 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6066, <8 x float> %private.contiguous.preserve1242
  store <8 x float> %6293, ptr %private.contiguous.address1241, align 4
  %6294 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6295 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6296 = add <8 x i64> %6295, splat (i64 64)
  %6297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6294, 0
  %6298 = insertvalue { <8 x ptr>, <8 x i64> } %6297, <8 x i64> %6296, 1
  %6299 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6300 = extractvalue { <8 x ptr>, <8 x i64> } %6298, 1
  %6301 = extractelement <8 x ptr> %6299, i32 0
  %6302 = extractelement <8 x i64> %6300, i32 %5698
  %6303 = zext i32 %5698 to i64
  %6304 = mul i64 %6303, 4
  %6305 = sub i64 %6302, %6304
  %6306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6307 = select i1 %6306, i64 %6305, i64 0
  %private.contiguous.address1243 = getelementptr i8, ptr %6301, i64 %6307
  %private.contiguous.preserve1244 = load <8 x float>, ptr %private.contiguous.address1243, align 4
  %6308 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6069, <8 x float> %private.contiguous.preserve1244
  store <8 x float> %6308, ptr %private.contiguous.address1243, align 4
  %6309 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6310 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6311 = add <8 x i64> %6310, splat (i64 96)
  %6312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6309, 0
  %6313 = insertvalue { <8 x ptr>, <8 x i64> } %6312, <8 x i64> %6311, 1
  %6314 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6315 = extractvalue { <8 x ptr>, <8 x i64> } %6313, 1
  %6316 = extractelement <8 x ptr> %6314, i32 0
  %6317 = extractelement <8 x i64> %6315, i32 %5698
  %6318 = zext i32 %5698 to i64
  %6319 = mul i64 %6318, 4
  %6320 = sub i64 %6317, %6319
  %6321 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6322 = select i1 %6321, i64 %6320, i64 0
  %private.contiguous.address1245 = getelementptr i8, ptr %6316, i64 %6322
  %private.contiguous.preserve1246 = load <8 x float>, ptr %private.contiguous.address1245, align 4
  %6323 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6072, <8 x float> %private.contiguous.preserve1246
  store <8 x float> %6323, ptr %private.contiguous.address1245, align 4
  %6324 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6325 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6326 = add <8 x i64> %6325, splat (i64 128)
  %6327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6324, 0
  %6328 = insertvalue { <8 x ptr>, <8 x i64> } %6327, <8 x i64> %6326, 1
  %6329 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6330 = extractvalue { <8 x ptr>, <8 x i64> } %6328, 1
  %6331 = extractelement <8 x ptr> %6329, i32 0
  %6332 = extractelement <8 x i64> %6330, i32 %5698
  %6333 = zext i32 %5698 to i64
  %6334 = mul i64 %6333, 4
  %6335 = sub i64 %6332, %6334
  %6336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6337 = select i1 %6336, i64 %6335, i64 0
  %private.contiguous.address1247 = getelementptr i8, ptr %6331, i64 %6337
  %private.contiguous.preserve1248 = load <8 x float>, ptr %private.contiguous.address1247, align 4
  %6338 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6075, <8 x float> %private.contiguous.preserve1248
  store <8 x float> %6338, ptr %private.contiguous.address1247, align 4
  %6339 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6340 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6341 = add <8 x i64> %6340, splat (i64 160)
  %6342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6339, 0
  %6343 = insertvalue { <8 x ptr>, <8 x i64> } %6342, <8 x i64> %6341, 1
  %6344 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6345 = extractvalue { <8 x ptr>, <8 x i64> } %6343, 1
  %6346 = extractelement <8 x ptr> %6344, i32 0
  %6347 = extractelement <8 x i64> %6345, i32 %5698
  %6348 = zext i32 %5698 to i64
  %6349 = mul i64 %6348, 4
  %6350 = sub i64 %6347, %6349
  %6351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6352 = select i1 %6351, i64 %6350, i64 0
  %private.contiguous.address1249 = getelementptr i8, ptr %6346, i64 %6352
  %private.contiguous.preserve1250 = load <8 x float>, ptr %private.contiguous.address1249, align 4
  %6353 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6078, <8 x float> %private.contiguous.preserve1250
  store <8 x float> %6353, ptr %private.contiguous.address1249, align 4
  %6354 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6355 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6356 = add <8 x i64> %6355, splat (i64 192)
  %6357 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6354, 0
  %6358 = insertvalue { <8 x ptr>, <8 x i64> } %6357, <8 x i64> %6356, 1
  %6359 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6360 = extractvalue { <8 x ptr>, <8 x i64> } %6358, 1
  %6361 = extractelement <8 x ptr> %6359, i32 0
  %6362 = extractelement <8 x i64> %6360, i32 %5698
  %6363 = zext i32 %5698 to i64
  %6364 = mul i64 %6363, 4
  %6365 = sub i64 %6362, %6364
  %6366 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6367 = select i1 %6366, i64 %6365, i64 0
  %private.contiguous.address1251 = getelementptr i8, ptr %6361, i64 %6367
  %private.contiguous.preserve1252 = load <8 x float>, ptr %private.contiguous.address1251, align 4
  %6368 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6081, <8 x float> %private.contiguous.preserve1252
  store <8 x float> %6368, ptr %private.contiguous.address1251, align 4
  %6369 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6370 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6371 = add <8 x i64> %6370, splat (i64 224)
  %6372 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6369, 0
  %6373 = insertvalue { <8 x ptr>, <8 x i64> } %6372, <8 x i64> %6371, 1
  %6374 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6375 = extractvalue { <8 x ptr>, <8 x i64> } %6373, 1
  %6376 = extractelement <8 x ptr> %6374, i32 0
  %6377 = extractelement <8 x i64> %6375, i32 %5698
  %6378 = zext i32 %5698 to i64
  %6379 = mul i64 %6378, 4
  %6380 = sub i64 %6377, %6379
  %6381 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6382 = select i1 %6381, i64 %6380, i64 0
  %private.contiguous.address1253 = getelementptr i8, ptr %6376, i64 %6382
  %private.contiguous.preserve1254 = load <8 x float>, ptr %private.contiguous.address1253, align 4
  %6383 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6084, <8 x float> %private.contiguous.preserve1254
  store <8 x float> %6383, ptr %private.contiguous.address1253, align 4
  %6384 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6385 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6386 = add <8 x i64> %6385, splat (i64 256)
  %6387 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6384, 0
  %6388 = insertvalue { <8 x ptr>, <8 x i64> } %6387, <8 x i64> %6386, 1
  %6389 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6390 = extractvalue { <8 x ptr>, <8 x i64> } %6388, 1
  %6391 = extractelement <8 x ptr> %6389, i32 0
  %6392 = extractelement <8 x i64> %6390, i32 %5698
  %6393 = zext i32 %5698 to i64
  %6394 = mul i64 %6393, 4
  %6395 = sub i64 %6392, %6394
  %6396 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6397 = select i1 %6396, i64 %6395, i64 0
  %private.contiguous.address1255 = getelementptr i8, ptr %6391, i64 %6397
  %private.contiguous.preserve1256 = load <8 x float>, ptr %private.contiguous.address1255, align 4
  %6398 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6087, <8 x float> %private.contiguous.preserve1256
  store <8 x float> %6398, ptr %private.contiguous.address1255, align 4
  %6399 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6400 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6401 = add <8 x i64> %6400, splat (i64 288)
  %6402 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6399, 0
  %6403 = insertvalue { <8 x ptr>, <8 x i64> } %6402, <8 x i64> %6401, 1
  %6404 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6405 = extractvalue { <8 x ptr>, <8 x i64> } %6403, 1
  %6406 = extractelement <8 x ptr> %6404, i32 0
  %6407 = extractelement <8 x i64> %6405, i32 %5698
  %6408 = zext i32 %5698 to i64
  %6409 = mul i64 %6408, 4
  %6410 = sub i64 %6407, %6409
  %6411 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6412 = select i1 %6411, i64 %6410, i64 0
  %private.contiguous.address1257 = getelementptr i8, ptr %6406, i64 %6412
  %private.contiguous.preserve1258 = load <8 x float>, ptr %private.contiguous.address1257, align 4
  %6413 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6090, <8 x float> %private.contiguous.preserve1258
  store <8 x float> %6413, ptr %private.contiguous.address1257, align 4
  %6414 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6415 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6416 = add <8 x i64> %6415, splat (i64 320)
  %6417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6414, 0
  %6418 = insertvalue { <8 x ptr>, <8 x i64> } %6417, <8 x i64> %6416, 1
  %6419 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6420 = extractvalue { <8 x ptr>, <8 x i64> } %6418, 1
  %6421 = extractelement <8 x ptr> %6419, i32 0
  %6422 = extractelement <8 x i64> %6420, i32 %5698
  %6423 = zext i32 %5698 to i64
  %6424 = mul i64 %6423, 4
  %6425 = sub i64 %6422, %6424
  %6426 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6427 = select i1 %6426, i64 %6425, i64 0
  %private.contiguous.address1259 = getelementptr i8, ptr %6421, i64 %6427
  %private.contiguous.preserve1260 = load <8 x float>, ptr %private.contiguous.address1259, align 4
  %6428 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6093, <8 x float> %private.contiguous.preserve1260
  store <8 x float> %6428, ptr %private.contiguous.address1259, align 4
  %6429 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6430 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6431 = add <8 x i64> %6430, splat (i64 352)
  %6432 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6429, 0
  %6433 = insertvalue { <8 x ptr>, <8 x i64> } %6432, <8 x i64> %6431, 1
  %6434 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6435 = extractvalue { <8 x ptr>, <8 x i64> } %6433, 1
  %6436 = extractelement <8 x ptr> %6434, i32 0
  %6437 = extractelement <8 x i64> %6435, i32 %5698
  %6438 = zext i32 %5698 to i64
  %6439 = mul i64 %6438, 4
  %6440 = sub i64 %6437, %6439
  %6441 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6442 = select i1 %6441, i64 %6440, i64 0
  %private.contiguous.address1261 = getelementptr i8, ptr %6436, i64 %6442
  %private.contiguous.preserve1262 = load <8 x float>, ptr %private.contiguous.address1261, align 4
  %6443 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6096, <8 x float> %private.contiguous.preserve1262
  store <8 x float> %6443, ptr %private.contiguous.address1261, align 4
  %6444 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6445 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6446 = add <8 x i64> %6445, splat (i64 384)
  %6447 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6444, 0
  %6448 = insertvalue { <8 x ptr>, <8 x i64> } %6447, <8 x i64> %6446, 1
  %6449 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6450 = extractvalue { <8 x ptr>, <8 x i64> } %6448, 1
  %6451 = extractelement <8 x ptr> %6449, i32 0
  %6452 = extractelement <8 x i64> %6450, i32 %5698
  %6453 = zext i32 %5698 to i64
  %6454 = mul i64 %6453, 4
  %6455 = sub i64 %6452, %6454
  %6456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6457 = select i1 %6456, i64 %6455, i64 0
  %private.contiguous.address1263 = getelementptr i8, ptr %6451, i64 %6457
  %private.contiguous.preserve1264 = load <8 x float>, ptr %private.contiguous.address1263, align 4
  %6458 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6099, <8 x float> %private.contiguous.preserve1264
  store <8 x float> %6458, ptr %private.contiguous.address1263, align 4
  %6459 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6460 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6461 = add <8 x i64> %6460, splat (i64 416)
  %6462 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6459, 0
  %6463 = insertvalue { <8 x ptr>, <8 x i64> } %6462, <8 x i64> %6461, 1
  %6464 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6465 = extractvalue { <8 x ptr>, <8 x i64> } %6463, 1
  %6466 = extractelement <8 x ptr> %6464, i32 0
  %6467 = extractelement <8 x i64> %6465, i32 %5698
  %6468 = zext i32 %5698 to i64
  %6469 = mul i64 %6468, 4
  %6470 = sub i64 %6467, %6469
  %6471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6472 = select i1 %6471, i64 %6470, i64 0
  %private.contiguous.address1265 = getelementptr i8, ptr %6466, i64 %6472
  %private.contiguous.preserve1266 = load <8 x float>, ptr %private.contiguous.address1265, align 4
  %6473 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6102, <8 x float> %private.contiguous.preserve1266
  store <8 x float> %6473, ptr %private.contiguous.address1265, align 4
  %6474 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6475 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6476 = add <8 x i64> %6475, splat (i64 448)
  %6477 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6474, 0
  %6478 = insertvalue { <8 x ptr>, <8 x i64> } %6477, <8 x i64> %6476, 1
  %6479 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6480 = extractvalue { <8 x ptr>, <8 x i64> } %6478, 1
  %6481 = extractelement <8 x ptr> %6479, i32 0
  %6482 = extractelement <8 x i64> %6480, i32 %5698
  %6483 = zext i32 %5698 to i64
  %6484 = mul i64 %6483, 4
  %6485 = sub i64 %6482, %6484
  %6486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6487 = select i1 %6486, i64 %6485, i64 0
  %private.contiguous.address1267 = getelementptr i8, ptr %6481, i64 %6487
  %private.contiguous.preserve1268 = load <8 x float>, ptr %private.contiguous.address1267, align 4
  %6488 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6105, <8 x float> %private.contiguous.preserve1268
  store <8 x float> %6488, ptr %private.contiguous.address1267, align 4
  %6489 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6490 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6491 = add <8 x i64> %6490, splat (i64 480)
  %6492 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6489, 0
  %6493 = insertvalue { <8 x ptr>, <8 x i64> } %6492, <8 x i64> %6491, 1
  %6494 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6495 = extractvalue { <8 x ptr>, <8 x i64> } %6493, 1
  %6496 = extractelement <8 x ptr> %6494, i32 0
  %6497 = extractelement <8 x i64> %6495, i32 %5698
  %6498 = zext i32 %5698 to i64
  %6499 = mul i64 %6498, 4
  %6500 = sub i64 %6497, %6499
  %6501 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6502 = select i1 %6501, i64 %6500, i64 0
  %private.contiguous.address1269 = getelementptr i8, ptr %6496, i64 %6502
  %private.contiguous.preserve1270 = load <8 x float>, ptr %private.contiguous.address1269, align 4
  %6503 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6108, <8 x float> %private.contiguous.preserve1270
  store <8 x float> %6503, ptr %private.contiguous.address1269, align 4
  %6504 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6505 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6506 = add <8 x i64> %6505, splat (i64 512)
  %6507 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6504, 0
  %6508 = insertvalue { <8 x ptr>, <8 x i64> } %6507, <8 x i64> %6506, 1
  %6509 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6510 = extractvalue { <8 x ptr>, <8 x i64> } %6508, 1
  %6511 = extractelement <8 x ptr> %6509, i32 0
  %6512 = extractelement <8 x i64> %6510, i32 %5698
  %6513 = zext i32 %5698 to i64
  %6514 = mul i64 %6513, 4
  %6515 = sub i64 %6512, %6514
  %6516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6517 = select i1 %6516, i64 %6515, i64 0
  %private.contiguous.address1271 = getelementptr i8, ptr %6511, i64 %6517
  %private.contiguous.preserve1272 = load <8 x float>, ptr %private.contiguous.address1271, align 4
  %6518 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6111, <8 x float> %private.contiguous.preserve1272
  store <8 x float> %6518, ptr %private.contiguous.address1271, align 4
  %6519 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6520 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6521 = add <8 x i64> %6520, splat (i64 544)
  %6522 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6519, 0
  %6523 = insertvalue { <8 x ptr>, <8 x i64> } %6522, <8 x i64> %6521, 1
  %6524 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6525 = extractvalue { <8 x ptr>, <8 x i64> } %6523, 1
  %6526 = extractelement <8 x ptr> %6524, i32 0
  %6527 = extractelement <8 x i64> %6525, i32 %5698
  %6528 = zext i32 %5698 to i64
  %6529 = mul i64 %6528, 4
  %6530 = sub i64 %6527, %6529
  %6531 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6532 = select i1 %6531, i64 %6530, i64 0
  %private.contiguous.address1273 = getelementptr i8, ptr %6526, i64 %6532
  %private.contiguous.preserve1274 = load <8 x float>, ptr %private.contiguous.address1273, align 4
  %6533 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6114, <8 x float> %private.contiguous.preserve1274
  store <8 x float> %6533, ptr %private.contiguous.address1273, align 4
  %6534 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6535 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6536 = add <8 x i64> %6535, splat (i64 576)
  %6537 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6534, 0
  %6538 = insertvalue { <8 x ptr>, <8 x i64> } %6537, <8 x i64> %6536, 1
  %6539 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6540 = extractvalue { <8 x ptr>, <8 x i64> } %6538, 1
  %6541 = extractelement <8 x ptr> %6539, i32 0
  %6542 = extractelement <8 x i64> %6540, i32 %5698
  %6543 = zext i32 %5698 to i64
  %6544 = mul i64 %6543, 4
  %6545 = sub i64 %6542, %6544
  %6546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6547 = select i1 %6546, i64 %6545, i64 0
  %private.contiguous.address1275 = getelementptr i8, ptr %6541, i64 %6547
  %private.contiguous.preserve1276 = load <8 x float>, ptr %private.contiguous.address1275, align 4
  %6548 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6117, <8 x float> %private.contiguous.preserve1276
  store <8 x float> %6548, ptr %private.contiguous.address1275, align 4
  %6549 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6550 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6551 = add <8 x i64> %6550, splat (i64 608)
  %6552 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6549, 0
  %6553 = insertvalue { <8 x ptr>, <8 x i64> } %6552, <8 x i64> %6551, 1
  %6554 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6555 = extractvalue { <8 x ptr>, <8 x i64> } %6553, 1
  %6556 = extractelement <8 x ptr> %6554, i32 0
  %6557 = extractelement <8 x i64> %6555, i32 %5698
  %6558 = zext i32 %5698 to i64
  %6559 = mul i64 %6558, 4
  %6560 = sub i64 %6557, %6559
  %6561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6562 = select i1 %6561, i64 %6560, i64 0
  %private.contiguous.address1277 = getelementptr i8, ptr %6556, i64 %6562
  %private.contiguous.preserve1278 = load <8 x float>, ptr %private.contiguous.address1277, align 4
  %6563 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6120, <8 x float> %private.contiguous.preserve1278
  store <8 x float> %6563, ptr %private.contiguous.address1277, align 4
  %6564 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6565 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6566 = add <8 x i64> %6565, splat (i64 640)
  %6567 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6564, 0
  %6568 = insertvalue { <8 x ptr>, <8 x i64> } %6567, <8 x i64> %6566, 1
  %6569 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6570 = extractvalue { <8 x ptr>, <8 x i64> } %6568, 1
  %6571 = extractelement <8 x ptr> %6569, i32 0
  %6572 = extractelement <8 x i64> %6570, i32 %5698
  %6573 = zext i32 %5698 to i64
  %6574 = mul i64 %6573, 4
  %6575 = sub i64 %6572, %6574
  %6576 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6577 = select i1 %6576, i64 %6575, i64 0
  %private.contiguous.address1279 = getelementptr i8, ptr %6571, i64 %6577
  %private.contiguous.preserve1280 = load <8 x float>, ptr %private.contiguous.address1279, align 4
  %6578 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6123, <8 x float> %private.contiguous.preserve1280
  store <8 x float> %6578, ptr %private.contiguous.address1279, align 4
  %6579 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6580 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6581 = add <8 x i64> %6580, splat (i64 672)
  %6582 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6579, 0
  %6583 = insertvalue { <8 x ptr>, <8 x i64> } %6582, <8 x i64> %6581, 1
  %6584 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6585 = extractvalue { <8 x ptr>, <8 x i64> } %6583, 1
  %6586 = extractelement <8 x ptr> %6584, i32 0
  %6587 = extractelement <8 x i64> %6585, i32 %5698
  %6588 = zext i32 %5698 to i64
  %6589 = mul i64 %6588, 4
  %6590 = sub i64 %6587, %6589
  %6591 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6592 = select i1 %6591, i64 %6590, i64 0
  %private.contiguous.address1281 = getelementptr i8, ptr %6586, i64 %6592
  %private.contiguous.preserve1282 = load <8 x float>, ptr %private.contiguous.address1281, align 4
  %6593 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6126, <8 x float> %private.contiguous.preserve1282
  store <8 x float> %6593, ptr %private.contiguous.address1281, align 4
  %6594 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6595 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6596 = add <8 x i64> %6595, splat (i64 704)
  %6597 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6594, 0
  %6598 = insertvalue { <8 x ptr>, <8 x i64> } %6597, <8 x i64> %6596, 1
  %6599 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6600 = extractvalue { <8 x ptr>, <8 x i64> } %6598, 1
  %6601 = extractelement <8 x ptr> %6599, i32 0
  %6602 = extractelement <8 x i64> %6600, i32 %5698
  %6603 = zext i32 %5698 to i64
  %6604 = mul i64 %6603, 4
  %6605 = sub i64 %6602, %6604
  %6606 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6607 = select i1 %6606, i64 %6605, i64 0
  %private.contiguous.address1283 = getelementptr i8, ptr %6601, i64 %6607
  %private.contiguous.preserve1284 = load <8 x float>, ptr %private.contiguous.address1283, align 4
  %6608 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6129, <8 x float> %private.contiguous.preserve1284
  store <8 x float> %6608, ptr %private.contiguous.address1283, align 4
  %6609 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6610 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6611 = add <8 x i64> %6610, splat (i64 736)
  %6612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6609, 0
  %6613 = insertvalue { <8 x ptr>, <8 x i64> } %6612, <8 x i64> %6611, 1
  %6614 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6615 = extractvalue { <8 x ptr>, <8 x i64> } %6613, 1
  %6616 = extractelement <8 x ptr> %6614, i32 0
  %6617 = extractelement <8 x i64> %6615, i32 %5698
  %6618 = zext i32 %5698 to i64
  %6619 = mul i64 %6618, 4
  %6620 = sub i64 %6617, %6619
  %6621 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6622 = select i1 %6621, i64 %6620, i64 0
  %private.contiguous.address1285 = getelementptr i8, ptr %6616, i64 %6622
  %private.contiguous.preserve1286 = load <8 x float>, ptr %private.contiguous.address1285, align 4
  %6623 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6132, <8 x float> %private.contiguous.preserve1286
  store <8 x float> %6623, ptr %private.contiguous.address1285, align 4
  %6624 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6625 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6626 = add <8 x i64> %6625, splat (i64 768)
  %6627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6624, 0
  %6628 = insertvalue { <8 x ptr>, <8 x i64> } %6627, <8 x i64> %6626, 1
  %6629 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6630 = extractvalue { <8 x ptr>, <8 x i64> } %6628, 1
  %6631 = extractelement <8 x ptr> %6629, i32 0
  %6632 = extractelement <8 x i64> %6630, i32 %5698
  %6633 = zext i32 %5698 to i64
  %6634 = mul i64 %6633, 4
  %6635 = sub i64 %6632, %6634
  %6636 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6637 = select i1 %6636, i64 %6635, i64 0
  %private.contiguous.address1287 = getelementptr i8, ptr %6631, i64 %6637
  %private.contiguous.preserve1288 = load <8 x float>, ptr %private.contiguous.address1287, align 4
  %6638 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6135, <8 x float> %private.contiguous.preserve1288
  store <8 x float> %6638, ptr %private.contiguous.address1287, align 4
  %6639 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6640 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6641 = add <8 x i64> %6640, splat (i64 800)
  %6642 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6639, 0
  %6643 = insertvalue { <8 x ptr>, <8 x i64> } %6642, <8 x i64> %6641, 1
  %6644 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6645 = extractvalue { <8 x ptr>, <8 x i64> } %6643, 1
  %6646 = extractelement <8 x ptr> %6644, i32 0
  %6647 = extractelement <8 x i64> %6645, i32 %5698
  %6648 = zext i32 %5698 to i64
  %6649 = mul i64 %6648, 4
  %6650 = sub i64 %6647, %6649
  %6651 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6652 = select i1 %6651, i64 %6650, i64 0
  %private.contiguous.address1289 = getelementptr i8, ptr %6646, i64 %6652
  %private.contiguous.preserve1290 = load <8 x float>, ptr %private.contiguous.address1289, align 4
  %6653 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6138, <8 x float> %private.contiguous.preserve1290
  store <8 x float> %6653, ptr %private.contiguous.address1289, align 4
  %6654 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6655 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6656 = add <8 x i64> %6655, splat (i64 832)
  %6657 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6654, 0
  %6658 = insertvalue { <8 x ptr>, <8 x i64> } %6657, <8 x i64> %6656, 1
  %6659 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6660 = extractvalue { <8 x ptr>, <8 x i64> } %6658, 1
  %6661 = extractelement <8 x ptr> %6659, i32 0
  %6662 = extractelement <8 x i64> %6660, i32 %5698
  %6663 = zext i32 %5698 to i64
  %6664 = mul i64 %6663, 4
  %6665 = sub i64 %6662, %6664
  %6666 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6667 = select i1 %6666, i64 %6665, i64 0
  %private.contiguous.address1291 = getelementptr i8, ptr %6661, i64 %6667
  %private.contiguous.preserve1292 = load <8 x float>, ptr %private.contiguous.address1291, align 4
  %6668 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6141, <8 x float> %private.contiguous.preserve1292
  store <8 x float> %6668, ptr %private.contiguous.address1291, align 4
  %6669 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6670 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6671 = add <8 x i64> %6670, splat (i64 864)
  %6672 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6669, 0
  %6673 = insertvalue { <8 x ptr>, <8 x i64> } %6672, <8 x i64> %6671, 1
  %6674 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6675 = extractvalue { <8 x ptr>, <8 x i64> } %6673, 1
  %6676 = extractelement <8 x ptr> %6674, i32 0
  %6677 = extractelement <8 x i64> %6675, i32 %5698
  %6678 = zext i32 %5698 to i64
  %6679 = mul i64 %6678, 4
  %6680 = sub i64 %6677, %6679
  %6681 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6682 = select i1 %6681, i64 %6680, i64 0
  %private.contiguous.address1293 = getelementptr i8, ptr %6676, i64 %6682
  %private.contiguous.preserve1294 = load <8 x float>, ptr %private.contiguous.address1293, align 4
  %6683 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6144, <8 x float> %private.contiguous.preserve1294
  store <8 x float> %6683, ptr %private.contiguous.address1293, align 4
  %6684 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6685 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6686 = add <8 x i64> %6685, splat (i64 896)
  %6687 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6684, 0
  %6688 = insertvalue { <8 x ptr>, <8 x i64> } %6687, <8 x i64> %6686, 1
  %6689 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6690 = extractvalue { <8 x ptr>, <8 x i64> } %6688, 1
  %6691 = extractelement <8 x ptr> %6689, i32 0
  %6692 = extractelement <8 x i64> %6690, i32 %5698
  %6693 = zext i32 %5698 to i64
  %6694 = mul i64 %6693, 4
  %6695 = sub i64 %6692, %6694
  %6696 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6697 = select i1 %6696, i64 %6695, i64 0
  %private.contiguous.address1295 = getelementptr i8, ptr %6691, i64 %6697
  %private.contiguous.preserve1296 = load <8 x float>, ptr %private.contiguous.address1295, align 4
  %6698 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6147, <8 x float> %private.contiguous.preserve1296
  store <8 x float> %6698, ptr %private.contiguous.address1295, align 4
  %6699 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6700 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6701 = add <8 x i64> %6700, splat (i64 928)
  %6702 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6699, 0
  %6703 = insertvalue { <8 x ptr>, <8 x i64> } %6702, <8 x i64> %6701, 1
  %6704 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6705 = extractvalue { <8 x ptr>, <8 x i64> } %6703, 1
  %6706 = extractelement <8 x ptr> %6704, i32 0
  %6707 = extractelement <8 x i64> %6705, i32 %5698
  %6708 = zext i32 %5698 to i64
  %6709 = mul i64 %6708, 4
  %6710 = sub i64 %6707, %6709
  %6711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6712 = select i1 %6711, i64 %6710, i64 0
  %private.contiguous.address1297 = getelementptr i8, ptr %6706, i64 %6712
  %private.contiguous.preserve1298 = load <8 x float>, ptr %private.contiguous.address1297, align 4
  %6713 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6150, <8 x float> %private.contiguous.preserve1298
  store <8 x float> %6713, ptr %private.contiguous.address1297, align 4
  %6714 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6715 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6716 = add <8 x i64> %6715, splat (i64 960)
  %6717 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6714, 0
  %6718 = insertvalue { <8 x ptr>, <8 x i64> } %6717, <8 x i64> %6716, 1
  %6719 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6720 = extractvalue { <8 x ptr>, <8 x i64> } %6718, 1
  %6721 = extractelement <8 x ptr> %6719, i32 0
  %6722 = extractelement <8 x i64> %6720, i32 %5698
  %6723 = zext i32 %5698 to i64
  %6724 = mul i64 %6723, 4
  %6725 = sub i64 %6722, %6724
  %6726 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6727 = select i1 %6726, i64 %6725, i64 0
  %private.contiguous.address1299 = getelementptr i8, ptr %6721, i64 %6727
  %private.contiguous.preserve1300 = load <8 x float>, ptr %private.contiguous.address1299, align 4
  %6728 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6153, <8 x float> %private.contiguous.preserve1300
  store <8 x float> %6728, ptr %private.contiguous.address1299, align 4
  %6729 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6730 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6731 = add <8 x i64> %6730, splat (i64 992)
  %6732 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6729, 0
  %6733 = insertvalue { <8 x ptr>, <8 x i64> } %6732, <8 x i64> %6731, 1
  %6734 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6735 = extractvalue { <8 x ptr>, <8 x i64> } %6733, 1
  %6736 = extractelement <8 x ptr> %6734, i32 0
  %6737 = extractelement <8 x i64> %6735, i32 %5698
  %6738 = zext i32 %5698 to i64
  %6739 = mul i64 %6738, 4
  %6740 = sub i64 %6737, %6739
  %6741 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6742 = select i1 %6741, i64 %6740, i64 0
  %private.contiguous.address1301 = getelementptr i8, ptr %6736, i64 %6742
  %private.contiguous.preserve1302 = load <8 x float>, ptr %private.contiguous.address1301, align 4
  %6743 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6156, <8 x float> %private.contiguous.preserve1302
  store <8 x float> %6743, ptr %private.contiguous.address1301, align 4
  %6744 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6745 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6746 = add <8 x i64> %6745, splat (i64 1024)
  %6747 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6744, 0
  %6748 = insertvalue { <8 x ptr>, <8 x i64> } %6747, <8 x i64> %6746, 1
  %6749 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6750 = extractvalue { <8 x ptr>, <8 x i64> } %6748, 1
  %6751 = extractelement <8 x ptr> %6749, i32 0
  %6752 = extractelement <8 x i64> %6750, i32 %5698
  %6753 = zext i32 %5698 to i64
  %6754 = mul i64 %6753, 4
  %6755 = sub i64 %6752, %6754
  %6756 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6757 = select i1 %6756, i64 %6755, i64 0
  %private.contiguous.address1303 = getelementptr i8, ptr %6751, i64 %6757
  %private.contiguous.preserve1304 = load <8 x float>, ptr %private.contiguous.address1303, align 4
  %6758 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6159, <8 x float> %private.contiguous.preserve1304
  store <8 x float> %6758, ptr %private.contiguous.address1303, align 4
  %6759 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6760 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6761 = add <8 x i64> %6760, splat (i64 1056)
  %6762 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6759, 0
  %6763 = insertvalue { <8 x ptr>, <8 x i64> } %6762, <8 x i64> %6761, 1
  %6764 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6765 = extractvalue { <8 x ptr>, <8 x i64> } %6763, 1
  %6766 = extractelement <8 x ptr> %6764, i32 0
  %6767 = extractelement <8 x i64> %6765, i32 %5698
  %6768 = zext i32 %5698 to i64
  %6769 = mul i64 %6768, 4
  %6770 = sub i64 %6767, %6769
  %6771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6772 = select i1 %6771, i64 %6770, i64 0
  %private.contiguous.address1305 = getelementptr i8, ptr %6766, i64 %6772
  %private.contiguous.preserve1306 = load <8 x float>, ptr %private.contiguous.address1305, align 4
  %6773 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6162, <8 x float> %private.contiguous.preserve1306
  store <8 x float> %6773, ptr %private.contiguous.address1305, align 4
  %6774 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6775 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6776 = add <8 x i64> %6775, splat (i64 1088)
  %6777 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6774, 0
  %6778 = insertvalue { <8 x ptr>, <8 x i64> } %6777, <8 x i64> %6776, 1
  %6779 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6780 = extractvalue { <8 x ptr>, <8 x i64> } %6778, 1
  %6781 = extractelement <8 x ptr> %6779, i32 0
  %6782 = extractelement <8 x i64> %6780, i32 %5698
  %6783 = zext i32 %5698 to i64
  %6784 = mul i64 %6783, 4
  %6785 = sub i64 %6782, %6784
  %6786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6787 = select i1 %6786, i64 %6785, i64 0
  %private.contiguous.address1307 = getelementptr i8, ptr %6781, i64 %6787
  %private.contiguous.preserve1308 = load <8 x float>, ptr %private.contiguous.address1307, align 4
  %6788 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6165, <8 x float> %private.contiguous.preserve1308
  store <8 x float> %6788, ptr %private.contiguous.address1307, align 4
  %6789 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6790 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6791 = add <8 x i64> %6790, splat (i64 1120)
  %6792 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6789, 0
  %6793 = insertvalue { <8 x ptr>, <8 x i64> } %6792, <8 x i64> %6791, 1
  %6794 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6795 = extractvalue { <8 x ptr>, <8 x i64> } %6793, 1
  %6796 = extractelement <8 x ptr> %6794, i32 0
  %6797 = extractelement <8 x i64> %6795, i32 %5698
  %6798 = zext i32 %5698 to i64
  %6799 = mul i64 %6798, 4
  %6800 = sub i64 %6797, %6799
  %6801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6802 = select i1 %6801, i64 %6800, i64 0
  %private.contiguous.address1309 = getelementptr i8, ptr %6796, i64 %6802
  %private.contiguous.preserve1310 = load <8 x float>, ptr %private.contiguous.address1309, align 4
  %6803 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6168, <8 x float> %private.contiguous.preserve1310
  store <8 x float> %6803, ptr %private.contiguous.address1309, align 4
  %6804 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6805 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6806 = add <8 x i64> %6805, splat (i64 1152)
  %6807 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6804, 0
  %6808 = insertvalue { <8 x ptr>, <8 x i64> } %6807, <8 x i64> %6806, 1
  %6809 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6810 = extractvalue { <8 x ptr>, <8 x i64> } %6808, 1
  %6811 = extractelement <8 x ptr> %6809, i32 0
  %6812 = extractelement <8 x i64> %6810, i32 %5698
  %6813 = zext i32 %5698 to i64
  %6814 = mul i64 %6813, 4
  %6815 = sub i64 %6812, %6814
  %6816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6817 = select i1 %6816, i64 %6815, i64 0
  %private.contiguous.address1311 = getelementptr i8, ptr %6811, i64 %6817
  %private.contiguous.preserve1312 = load <8 x float>, ptr %private.contiguous.address1311, align 4
  %6818 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6171, <8 x float> %private.contiguous.preserve1312
  store <8 x float> %6818, ptr %private.contiguous.address1311, align 4
  %6819 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6820 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6821 = add <8 x i64> %6820, splat (i64 1184)
  %6822 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6819, 0
  %6823 = insertvalue { <8 x ptr>, <8 x i64> } %6822, <8 x i64> %6821, 1
  %6824 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6825 = extractvalue { <8 x ptr>, <8 x i64> } %6823, 1
  %6826 = extractelement <8 x ptr> %6824, i32 0
  %6827 = extractelement <8 x i64> %6825, i32 %5698
  %6828 = zext i32 %5698 to i64
  %6829 = mul i64 %6828, 4
  %6830 = sub i64 %6827, %6829
  %6831 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6832 = select i1 %6831, i64 %6830, i64 0
  %private.contiguous.address1313 = getelementptr i8, ptr %6826, i64 %6832
  %private.contiguous.preserve1314 = load <8 x float>, ptr %private.contiguous.address1313, align 4
  %6833 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6174, <8 x float> %private.contiguous.preserve1314
  store <8 x float> %6833, ptr %private.contiguous.address1313, align 4
  %6834 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6835 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6836 = add <8 x i64> %6835, splat (i64 1216)
  %6837 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6834, 0
  %6838 = insertvalue { <8 x ptr>, <8 x i64> } %6837, <8 x i64> %6836, 1
  %6839 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6840 = extractvalue { <8 x ptr>, <8 x i64> } %6838, 1
  %6841 = extractelement <8 x ptr> %6839, i32 0
  %6842 = extractelement <8 x i64> %6840, i32 %5698
  %6843 = zext i32 %5698 to i64
  %6844 = mul i64 %6843, 4
  %6845 = sub i64 %6842, %6844
  %6846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6847 = select i1 %6846, i64 %6845, i64 0
  %private.contiguous.address1315 = getelementptr i8, ptr %6841, i64 %6847
  %private.contiguous.preserve1316 = load <8 x float>, ptr %private.contiguous.address1315, align 4
  %6848 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6177, <8 x float> %private.contiguous.preserve1316
  store <8 x float> %6848, ptr %private.contiguous.address1315, align 4
  %6849 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6850 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6851 = add <8 x i64> %6850, splat (i64 1248)
  %6852 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6849, 0
  %6853 = insertvalue { <8 x ptr>, <8 x i64> } %6852, <8 x i64> %6851, 1
  %6854 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6855 = extractvalue { <8 x ptr>, <8 x i64> } %6853, 1
  %6856 = extractelement <8 x ptr> %6854, i32 0
  %6857 = extractelement <8 x i64> %6855, i32 %5698
  %6858 = zext i32 %5698 to i64
  %6859 = mul i64 %6858, 4
  %6860 = sub i64 %6857, %6859
  %6861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6862 = select i1 %6861, i64 %6860, i64 0
  %private.contiguous.address1317 = getelementptr i8, ptr %6856, i64 %6862
  %private.contiguous.preserve1318 = load <8 x float>, ptr %private.contiguous.address1317, align 4
  %6863 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6180, <8 x float> %private.contiguous.preserve1318
  store <8 x float> %6863, ptr %private.contiguous.address1317, align 4
  %6864 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6865 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6866 = add <8 x i64> %6865, splat (i64 1280)
  %6867 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6864, 0
  %6868 = insertvalue { <8 x ptr>, <8 x i64> } %6867, <8 x i64> %6866, 1
  %6869 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6870 = extractvalue { <8 x ptr>, <8 x i64> } %6868, 1
  %6871 = extractelement <8 x ptr> %6869, i32 0
  %6872 = extractelement <8 x i64> %6870, i32 %5698
  %6873 = zext i32 %5698 to i64
  %6874 = mul i64 %6873, 4
  %6875 = sub i64 %6872, %6874
  %6876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6877 = select i1 %6876, i64 %6875, i64 0
  %private.contiguous.address1319 = getelementptr i8, ptr %6871, i64 %6877
  %private.contiguous.preserve1320 = load <8 x float>, ptr %private.contiguous.address1319, align 4
  %6878 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6183, <8 x float> %private.contiguous.preserve1320
  store <8 x float> %6878, ptr %private.contiguous.address1319, align 4
  %6879 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6880 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6881 = add <8 x i64> %6880, splat (i64 1312)
  %6882 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6879, 0
  %6883 = insertvalue { <8 x ptr>, <8 x i64> } %6882, <8 x i64> %6881, 1
  %6884 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6885 = extractvalue { <8 x ptr>, <8 x i64> } %6883, 1
  %6886 = extractelement <8 x ptr> %6884, i32 0
  %6887 = extractelement <8 x i64> %6885, i32 %5698
  %6888 = zext i32 %5698 to i64
  %6889 = mul i64 %6888, 4
  %6890 = sub i64 %6887, %6889
  %6891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6892 = select i1 %6891, i64 %6890, i64 0
  %private.contiguous.address1321 = getelementptr i8, ptr %6886, i64 %6892
  %private.contiguous.preserve1322 = load <8 x float>, ptr %private.contiguous.address1321, align 4
  %6893 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6186, <8 x float> %private.contiguous.preserve1322
  store <8 x float> %6893, ptr %private.contiguous.address1321, align 4
  %6894 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6895 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6896 = add <8 x i64> %6895, splat (i64 1344)
  %6897 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6894, 0
  %6898 = insertvalue { <8 x ptr>, <8 x i64> } %6897, <8 x i64> %6896, 1
  %6899 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6900 = extractvalue { <8 x ptr>, <8 x i64> } %6898, 1
  %6901 = extractelement <8 x ptr> %6899, i32 0
  %6902 = extractelement <8 x i64> %6900, i32 %5698
  %6903 = zext i32 %5698 to i64
  %6904 = mul i64 %6903, 4
  %6905 = sub i64 %6902, %6904
  %6906 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6907 = select i1 %6906, i64 %6905, i64 0
  %private.contiguous.address1323 = getelementptr i8, ptr %6901, i64 %6907
  %private.contiguous.preserve1324 = load <8 x float>, ptr %private.contiguous.address1323, align 4
  %6908 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6189, <8 x float> %private.contiguous.preserve1324
  store <8 x float> %6908, ptr %private.contiguous.address1323, align 4
  %6909 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6910 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6911 = add <8 x i64> %6910, splat (i64 1376)
  %6912 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6909, 0
  %6913 = insertvalue { <8 x ptr>, <8 x i64> } %6912, <8 x i64> %6911, 1
  %6914 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6915 = extractvalue { <8 x ptr>, <8 x i64> } %6913, 1
  %6916 = extractelement <8 x ptr> %6914, i32 0
  %6917 = extractelement <8 x i64> %6915, i32 %5698
  %6918 = zext i32 %5698 to i64
  %6919 = mul i64 %6918, 4
  %6920 = sub i64 %6917, %6919
  %6921 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6922 = select i1 %6921, i64 %6920, i64 0
  %private.contiguous.address1325 = getelementptr i8, ptr %6916, i64 %6922
  %private.contiguous.preserve1326 = load <8 x float>, ptr %private.contiguous.address1325, align 4
  %6923 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6192, <8 x float> %private.contiguous.preserve1326
  store <8 x float> %6923, ptr %private.contiguous.address1325, align 4
  %6924 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6925 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6926 = add <8 x i64> %6925, splat (i64 1408)
  %6927 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6924, 0
  %6928 = insertvalue { <8 x ptr>, <8 x i64> } %6927, <8 x i64> %6926, 1
  %6929 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6930 = extractvalue { <8 x ptr>, <8 x i64> } %6928, 1
  %6931 = extractelement <8 x ptr> %6929, i32 0
  %6932 = extractelement <8 x i64> %6930, i32 %5698
  %6933 = zext i32 %5698 to i64
  %6934 = mul i64 %6933, 4
  %6935 = sub i64 %6932, %6934
  %6936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6937 = select i1 %6936, i64 %6935, i64 0
  %private.contiguous.address1327 = getelementptr i8, ptr %6931, i64 %6937
  %private.contiguous.preserve1328 = load <8 x float>, ptr %private.contiguous.address1327, align 4
  %6938 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6195, <8 x float> %private.contiguous.preserve1328
  store <8 x float> %6938, ptr %private.contiguous.address1327, align 4
  %6939 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6940 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6941 = add <8 x i64> %6940, splat (i64 1440)
  %6942 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6939, 0
  %6943 = insertvalue { <8 x ptr>, <8 x i64> } %6942, <8 x i64> %6941, 1
  %6944 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6945 = extractvalue { <8 x ptr>, <8 x i64> } %6943, 1
  %6946 = extractelement <8 x ptr> %6944, i32 0
  %6947 = extractelement <8 x i64> %6945, i32 %5698
  %6948 = zext i32 %5698 to i64
  %6949 = mul i64 %6948, 4
  %6950 = sub i64 %6947, %6949
  %6951 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6952 = select i1 %6951, i64 %6950, i64 0
  %private.contiguous.address1329 = getelementptr i8, ptr %6946, i64 %6952
  %private.contiguous.preserve1330 = load <8 x float>, ptr %private.contiguous.address1329, align 4
  %6953 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6198, <8 x float> %private.contiguous.preserve1330
  store <8 x float> %6953, ptr %private.contiguous.address1329, align 4
  %6954 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6955 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6956 = add <8 x i64> %6955, splat (i64 1472)
  %6957 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6954, 0
  %6958 = insertvalue { <8 x ptr>, <8 x i64> } %6957, <8 x i64> %6956, 1
  %6959 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6960 = extractvalue { <8 x ptr>, <8 x i64> } %6958, 1
  %6961 = extractelement <8 x ptr> %6959, i32 0
  %6962 = extractelement <8 x i64> %6960, i32 %5698
  %6963 = zext i32 %5698 to i64
  %6964 = mul i64 %6963, 4
  %6965 = sub i64 %6962, %6964
  %6966 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6967 = select i1 %6966, i64 %6965, i64 0
  %private.contiguous.address1331 = getelementptr i8, ptr %6961, i64 %6967
  %private.contiguous.preserve1332 = load <8 x float>, ptr %private.contiguous.address1331, align 4
  %6968 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6201, <8 x float> %private.contiguous.preserve1332
  store <8 x float> %6968, ptr %private.contiguous.address1331, align 4
  %6969 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6970 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6971 = add <8 x i64> %6970, splat (i64 1504)
  %6972 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6969, 0
  %6973 = insertvalue { <8 x ptr>, <8 x i64> } %6972, <8 x i64> %6971, 1
  %6974 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6975 = extractvalue { <8 x ptr>, <8 x i64> } %6973, 1
  %6976 = extractelement <8 x ptr> %6974, i32 0
  %6977 = extractelement <8 x i64> %6975, i32 %5698
  %6978 = zext i32 %5698 to i64
  %6979 = mul i64 %6978, 4
  %6980 = sub i64 %6977, %6979
  %6981 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6982 = select i1 %6981, i64 %6980, i64 0
  %private.contiguous.address1333 = getelementptr i8, ptr %6976, i64 %6982
  %private.contiguous.preserve1334 = load <8 x float>, ptr %private.contiguous.address1333, align 4
  %6983 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6204, <8 x float> %private.contiguous.preserve1334
  store <8 x float> %6983, ptr %private.contiguous.address1333, align 4
  %6984 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6985 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6986 = add <8 x i64> %6985, splat (i64 1536)
  %6987 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6984, 0
  %6988 = insertvalue { <8 x ptr>, <8 x i64> } %6987, <8 x i64> %6986, 1
  %6989 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6990 = extractvalue { <8 x ptr>, <8 x i64> } %6988, 1
  %6991 = extractelement <8 x ptr> %6989, i32 0
  %6992 = extractelement <8 x i64> %6990, i32 %5698
  %6993 = zext i32 %5698 to i64
  %6994 = mul i64 %6993, 4
  %6995 = sub i64 %6992, %6994
  %6996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %6997 = select i1 %6996, i64 %6995, i64 0
  %private.contiguous.address1335 = getelementptr i8, ptr %6991, i64 %6997
  %private.contiguous.preserve1336 = load <8 x float>, ptr %private.contiguous.address1335, align 4
  %6998 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6207, <8 x float> %private.contiguous.preserve1336
  store <8 x float> %6998, ptr %private.contiguous.address1335, align 4
  %6999 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7000 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7001 = add <8 x i64> %7000, splat (i64 1568)
  %7002 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6999, 0
  %7003 = insertvalue { <8 x ptr>, <8 x i64> } %7002, <8 x i64> %7001, 1
  %7004 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7005 = extractvalue { <8 x ptr>, <8 x i64> } %7003, 1
  %7006 = extractelement <8 x ptr> %7004, i32 0
  %7007 = extractelement <8 x i64> %7005, i32 %5698
  %7008 = zext i32 %5698 to i64
  %7009 = mul i64 %7008, 4
  %7010 = sub i64 %7007, %7009
  %7011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7012 = select i1 %7011, i64 %7010, i64 0
  %private.contiguous.address1337 = getelementptr i8, ptr %7006, i64 %7012
  %private.contiguous.preserve1338 = load <8 x float>, ptr %private.contiguous.address1337, align 4
  %7013 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6210, <8 x float> %private.contiguous.preserve1338
  store <8 x float> %7013, ptr %private.contiguous.address1337, align 4
  %7014 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7015 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7016 = add <8 x i64> %7015, splat (i64 1600)
  %7017 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7014, 0
  %7018 = insertvalue { <8 x ptr>, <8 x i64> } %7017, <8 x i64> %7016, 1
  %7019 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7020 = extractvalue { <8 x ptr>, <8 x i64> } %7018, 1
  %7021 = extractelement <8 x ptr> %7019, i32 0
  %7022 = extractelement <8 x i64> %7020, i32 %5698
  %7023 = zext i32 %5698 to i64
  %7024 = mul i64 %7023, 4
  %7025 = sub i64 %7022, %7024
  %7026 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7027 = select i1 %7026, i64 %7025, i64 0
  %private.contiguous.address1339 = getelementptr i8, ptr %7021, i64 %7027
  %private.contiguous.preserve1340 = load <8 x float>, ptr %private.contiguous.address1339, align 4
  %7028 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6213, <8 x float> %private.contiguous.preserve1340
  store <8 x float> %7028, ptr %private.contiguous.address1339, align 4
  %7029 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7030 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7031 = add <8 x i64> %7030, splat (i64 1632)
  %7032 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7029, 0
  %7033 = insertvalue { <8 x ptr>, <8 x i64> } %7032, <8 x i64> %7031, 1
  %7034 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7035 = extractvalue { <8 x ptr>, <8 x i64> } %7033, 1
  %7036 = extractelement <8 x ptr> %7034, i32 0
  %7037 = extractelement <8 x i64> %7035, i32 %5698
  %7038 = zext i32 %5698 to i64
  %7039 = mul i64 %7038, 4
  %7040 = sub i64 %7037, %7039
  %7041 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7042 = select i1 %7041, i64 %7040, i64 0
  %private.contiguous.address1341 = getelementptr i8, ptr %7036, i64 %7042
  %private.contiguous.preserve1342 = load <8 x float>, ptr %private.contiguous.address1341, align 4
  %7043 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6216, <8 x float> %private.contiguous.preserve1342
  store <8 x float> %7043, ptr %private.contiguous.address1341, align 4
  %7044 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7045 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7046 = add <8 x i64> %7045, splat (i64 1664)
  %7047 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7044, 0
  %7048 = insertvalue { <8 x ptr>, <8 x i64> } %7047, <8 x i64> %7046, 1
  %7049 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7050 = extractvalue { <8 x ptr>, <8 x i64> } %7048, 1
  %7051 = extractelement <8 x ptr> %7049, i32 0
  %7052 = extractelement <8 x i64> %7050, i32 %5698
  %7053 = zext i32 %5698 to i64
  %7054 = mul i64 %7053, 4
  %7055 = sub i64 %7052, %7054
  %7056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7057 = select i1 %7056, i64 %7055, i64 0
  %private.contiguous.address1343 = getelementptr i8, ptr %7051, i64 %7057
  %private.contiguous.preserve1344 = load <8 x float>, ptr %private.contiguous.address1343, align 4
  %7058 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6219, <8 x float> %private.contiguous.preserve1344
  store <8 x float> %7058, ptr %private.contiguous.address1343, align 4
  %7059 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7060 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7061 = add <8 x i64> %7060, splat (i64 1696)
  %7062 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7059, 0
  %7063 = insertvalue { <8 x ptr>, <8 x i64> } %7062, <8 x i64> %7061, 1
  %7064 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7065 = extractvalue { <8 x ptr>, <8 x i64> } %7063, 1
  %7066 = extractelement <8 x ptr> %7064, i32 0
  %7067 = extractelement <8 x i64> %7065, i32 %5698
  %7068 = zext i32 %5698 to i64
  %7069 = mul i64 %7068, 4
  %7070 = sub i64 %7067, %7069
  %7071 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7072 = select i1 %7071, i64 %7070, i64 0
  %private.contiguous.address1345 = getelementptr i8, ptr %7066, i64 %7072
  %private.contiguous.preserve1346 = load <8 x float>, ptr %private.contiguous.address1345, align 4
  %7073 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6222, <8 x float> %private.contiguous.preserve1346
  store <8 x float> %7073, ptr %private.contiguous.address1345, align 4
  %7074 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7075 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7076 = add <8 x i64> %7075, splat (i64 1728)
  %7077 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7074, 0
  %7078 = insertvalue { <8 x ptr>, <8 x i64> } %7077, <8 x i64> %7076, 1
  %7079 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7080 = extractvalue { <8 x ptr>, <8 x i64> } %7078, 1
  %7081 = extractelement <8 x ptr> %7079, i32 0
  %7082 = extractelement <8 x i64> %7080, i32 %5698
  %7083 = zext i32 %5698 to i64
  %7084 = mul i64 %7083, 4
  %7085 = sub i64 %7082, %7084
  %7086 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7087 = select i1 %7086, i64 %7085, i64 0
  %private.contiguous.address1347 = getelementptr i8, ptr %7081, i64 %7087
  %private.contiguous.preserve1348 = load <8 x float>, ptr %private.contiguous.address1347, align 4
  %7088 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6225, <8 x float> %private.contiguous.preserve1348
  store <8 x float> %7088, ptr %private.contiguous.address1347, align 4
  %7089 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7090 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7091 = add <8 x i64> %7090, splat (i64 1760)
  %7092 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7089, 0
  %7093 = insertvalue { <8 x ptr>, <8 x i64> } %7092, <8 x i64> %7091, 1
  %7094 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7095 = extractvalue { <8 x ptr>, <8 x i64> } %7093, 1
  %7096 = extractelement <8 x ptr> %7094, i32 0
  %7097 = extractelement <8 x i64> %7095, i32 %5698
  %7098 = zext i32 %5698 to i64
  %7099 = mul i64 %7098, 4
  %7100 = sub i64 %7097, %7099
  %7101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7102 = select i1 %7101, i64 %7100, i64 0
  %private.contiguous.address1349 = getelementptr i8, ptr %7096, i64 %7102
  %private.contiguous.preserve1350 = load <8 x float>, ptr %private.contiguous.address1349, align 4
  %7103 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6228, <8 x float> %private.contiguous.preserve1350
  store <8 x float> %7103, ptr %private.contiguous.address1349, align 4
  %7104 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7105 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7106 = add <8 x i64> %7105, splat (i64 1792)
  %7107 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7104, 0
  %7108 = insertvalue { <8 x ptr>, <8 x i64> } %7107, <8 x i64> %7106, 1
  %7109 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7110 = extractvalue { <8 x ptr>, <8 x i64> } %7108, 1
  %7111 = extractelement <8 x ptr> %7109, i32 0
  %7112 = extractelement <8 x i64> %7110, i32 %5698
  %7113 = zext i32 %5698 to i64
  %7114 = mul i64 %7113, 4
  %7115 = sub i64 %7112, %7114
  %7116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7117 = select i1 %7116, i64 %7115, i64 0
  %private.contiguous.address1351 = getelementptr i8, ptr %7111, i64 %7117
  %private.contiguous.preserve1352 = load <8 x float>, ptr %private.contiguous.address1351, align 4
  %7118 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6231, <8 x float> %private.contiguous.preserve1352
  store <8 x float> %7118, ptr %private.contiguous.address1351, align 4
  %7119 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7120 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7121 = add <8 x i64> %7120, splat (i64 1824)
  %7122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7119, 0
  %7123 = insertvalue { <8 x ptr>, <8 x i64> } %7122, <8 x i64> %7121, 1
  %7124 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7125 = extractvalue { <8 x ptr>, <8 x i64> } %7123, 1
  %7126 = extractelement <8 x ptr> %7124, i32 0
  %7127 = extractelement <8 x i64> %7125, i32 %5698
  %7128 = zext i32 %5698 to i64
  %7129 = mul i64 %7128, 4
  %7130 = sub i64 %7127, %7129
  %7131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7132 = select i1 %7131, i64 %7130, i64 0
  %private.contiguous.address1353 = getelementptr i8, ptr %7126, i64 %7132
  %private.contiguous.preserve1354 = load <8 x float>, ptr %private.contiguous.address1353, align 4
  %7133 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6234, <8 x float> %private.contiguous.preserve1354
  store <8 x float> %7133, ptr %private.contiguous.address1353, align 4
  %7134 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7135 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7136 = add <8 x i64> %7135, splat (i64 1856)
  %7137 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7134, 0
  %7138 = insertvalue { <8 x ptr>, <8 x i64> } %7137, <8 x i64> %7136, 1
  %7139 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7140 = extractvalue { <8 x ptr>, <8 x i64> } %7138, 1
  %7141 = extractelement <8 x ptr> %7139, i32 0
  %7142 = extractelement <8 x i64> %7140, i32 %5698
  %7143 = zext i32 %5698 to i64
  %7144 = mul i64 %7143, 4
  %7145 = sub i64 %7142, %7144
  %7146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7147 = select i1 %7146, i64 %7145, i64 0
  %private.contiguous.address1355 = getelementptr i8, ptr %7141, i64 %7147
  %private.contiguous.preserve1356 = load <8 x float>, ptr %private.contiguous.address1355, align 4
  %7148 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6237, <8 x float> %private.contiguous.preserve1356
  store <8 x float> %7148, ptr %private.contiguous.address1355, align 4
  %7149 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7150 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7151 = add <8 x i64> %7150, splat (i64 1888)
  %7152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7149, 0
  %7153 = insertvalue { <8 x ptr>, <8 x i64> } %7152, <8 x i64> %7151, 1
  %7154 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7155 = extractvalue { <8 x ptr>, <8 x i64> } %7153, 1
  %7156 = extractelement <8 x ptr> %7154, i32 0
  %7157 = extractelement <8 x i64> %7155, i32 %5698
  %7158 = zext i32 %5698 to i64
  %7159 = mul i64 %7158, 4
  %7160 = sub i64 %7157, %7159
  %7161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7162 = select i1 %7161, i64 %7160, i64 0
  %private.contiguous.address1357 = getelementptr i8, ptr %7156, i64 %7162
  %private.contiguous.preserve1358 = load <8 x float>, ptr %private.contiguous.address1357, align 4
  %7163 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6240, <8 x float> %private.contiguous.preserve1358
  store <8 x float> %7163, ptr %private.contiguous.address1357, align 4
  %7164 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7165 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7166 = add <8 x i64> %7165, splat (i64 1920)
  %7167 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7164, 0
  %7168 = insertvalue { <8 x ptr>, <8 x i64> } %7167, <8 x i64> %7166, 1
  %7169 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7170 = extractvalue { <8 x ptr>, <8 x i64> } %7168, 1
  %7171 = extractelement <8 x ptr> %7169, i32 0
  %7172 = extractelement <8 x i64> %7170, i32 %5698
  %7173 = zext i32 %5698 to i64
  %7174 = mul i64 %7173, 4
  %7175 = sub i64 %7172, %7174
  %7176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7177 = select i1 %7176, i64 %7175, i64 0
  %private.contiguous.address1359 = getelementptr i8, ptr %7171, i64 %7177
  %private.contiguous.preserve1360 = load <8 x float>, ptr %private.contiguous.address1359, align 4
  %7178 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6243, <8 x float> %private.contiguous.preserve1360
  store <8 x float> %7178, ptr %private.contiguous.address1359, align 4
  %7179 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7181 = add <8 x i64> %7180, splat (i64 1952)
  %7182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7179, 0
  %7183 = insertvalue { <8 x ptr>, <8 x i64> } %7182, <8 x i64> %7181, 1
  %7184 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7185 = extractvalue { <8 x ptr>, <8 x i64> } %7183, 1
  %7186 = extractelement <8 x ptr> %7184, i32 0
  %7187 = extractelement <8 x i64> %7185, i32 %5698
  %7188 = zext i32 %5698 to i64
  %7189 = mul i64 %7188, 4
  %7190 = sub i64 %7187, %7189
  %7191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7192 = select i1 %7191, i64 %7190, i64 0
  %private.contiguous.address1361 = getelementptr i8, ptr %7186, i64 %7192
  %private.contiguous.preserve1362 = load <8 x float>, ptr %private.contiguous.address1361, align 4
  %7193 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6246, <8 x float> %private.contiguous.preserve1362
  store <8 x float> %7193, ptr %private.contiguous.address1361, align 4
  %7194 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7195 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7196 = add <8 x i64> %7195, splat (i64 1984)
  %7197 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7194, 0
  %7198 = insertvalue { <8 x ptr>, <8 x i64> } %7197, <8 x i64> %7196, 1
  %7199 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7200 = extractvalue { <8 x ptr>, <8 x i64> } %7198, 1
  %7201 = extractelement <8 x ptr> %7199, i32 0
  %7202 = extractelement <8 x i64> %7200, i32 %5698
  %7203 = zext i32 %5698 to i64
  %7204 = mul i64 %7203, 4
  %7205 = sub i64 %7202, %7204
  %7206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7207 = select i1 %7206, i64 %7205, i64 0
  %private.contiguous.address1363 = getelementptr i8, ptr %7201, i64 %7207
  %private.contiguous.preserve1364 = load <8 x float>, ptr %private.contiguous.address1363, align 4
  %7208 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6249, <8 x float> %private.contiguous.preserve1364
  store <8 x float> %7208, ptr %private.contiguous.address1363, align 4
  %7209 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7210 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7211 = add <8 x i64> %7210, splat (i64 2016)
  %7212 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7209, 0
  %7213 = insertvalue { <8 x ptr>, <8 x i64> } %7212, <8 x i64> %7211, 1
  %7214 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7215 = extractvalue { <8 x ptr>, <8 x i64> } %7213, 1
  %7216 = extractelement <8 x ptr> %7214, i32 0
  %7217 = extractelement <8 x i64> %7215, i32 %5698
  %7218 = zext i32 %5698 to i64
  %7219 = mul i64 %7218, 4
  %7220 = sub i64 %7217, %7219
  %7221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  %7222 = select i1 %7221, i64 %7220, i64 0
  %private.contiguous.address1365 = getelementptr i8, ptr %7216, i64 %7222
  %private.contiguous.preserve1366 = load <8 x float>, ptr %private.contiguous.address1365, align 4
  %7223 = select <8 x i1> %convergence.cascade.result1156, <8 x float> %6252, <8 x float> %private.contiguous.preserve1366
  store <8 x float> %7223, ptr %private.contiguous.address1365, align 4
  %7224 = load <8 x i64>, ptr %.slot56, align 64
  %7225 = select <8 x i1> %convergence.cascade.result1156, <8 x i64> zeroinitializer, <8 x i64> %7224
  store <8 x i64> %7225, ptr %.slot56, align 64
  %7226 = load <8 x float>, ptr %.slot58, align 32
  %7227 = select <8 x i1> %convergence.cascade.result1156, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7226
  store <8 x float> %7227, ptr %.slot58, align 32
  store <8 x i1> %convergence.cascade.result1156, ptr %current.mask, align 1
  %7228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1156)
  br i1 %7228, label %schedule.69, label %scheduler.loop

varying.divergent1368:                            ; preds = %schedule.69
  %7229 = load i32, ptr %current.token, align 4
  %7230 = icmp ne i32 %7229, 0
  %7231 = sub i32 %7229, 1
  %7232 = select i1 %7230, i32 %7231, i32 0
  %7233 = load i8, ptr %frame.active, align 1
  %7234 = trunc i32 %7232 to i8
  %7235 = shl i8 1, %7234
  %7236 = and i8 %7233, %7235
  %7237 = icmp ne i8 %7236, 0
  %7238 = load <8 x i32>, ptr %frame.static.id, align 32
  %7239 = extractelement <8 x i32> %7238, i32 %7232
  %7240 = icmp eq i32 %7239, 24
  %7241 = and i1 %7237, %7240
  %7242 = and i1 %7230, %7241
  %7243 = xor i1 %7242, true
  %7244 = and i1 true, %7243
  %7245 = xor i8 %7233, -1
  %7246 = icmp ne i8 %7245, 0
  %7247 = xor i1 %7246, true
  %7248 = and i1 %7244, %7247
  br i1 %7248, label %convergence.overflow.trap1370, label %convergence.overflow.resume1371

varying.coherent1369:                             ; preds = %schedule.69
  br i1 %1767, label %varying.coherent.true1374, label %varying.coherent.false1375

convergence.overflow.trap1370:                    ; preds = %varying.divergent1368
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1371:                  ; preds = %varying.divergent1368
  %7249 = call i8 @llvm.cttz.i8(i8 %7245, i1 false)
  %7250 = zext i8 %7249 to i32
  %7251 = select i1 %7246, i32 %7250, i32 0
  %7252 = trunc i32 %7251 to i8
  %7253 = shl i8 1, %7252
  %7254 = or i8 %7233, %7253
  %7255 = select i1 %7244, i8 %7254, i8 %7233
  store i8 %7255, ptr %frame.active, align 1
  %7256 = load <8 x i32>, ptr %frame.static.id, align 32
  %7257 = extractelement <8 x i32> %7256, i32 %7251
  %7258 = select i1 %7244, i32 24, i32 %7257
  %7259 = load <8 x i32>, ptr %frame.static.id, align 32
  %7260 = insertelement <8 x i32> %7259, i32 %7258, i32 %7251
  store <8 x i32> %7260, ptr %frame.static.id, align 32
  %7261 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7262 = extractelement <8 x i32> %7261, i32 %7251
  %7263 = select i1 %7244, i32 %7229, i32 %7262
  %7264 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7265 = insertelement <8 x i32> %7264, i32 %7263, i32 %7251
  store <8 x i32> %7265, ptr %frame.parent.token, align 32
  %7266 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7251
  %7267 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7251
  %7268 = load <8 x i1>, ptr %7266, align 1
  %7269 = load <8 x i1>, ptr %7267, align 1
  %7270 = select i1 %7244, <8 x i1> %1757, <8 x i1> %7268
  store <8 x i1> %7270, ptr %7266, align 1
  %7271 = select i1 %7244, <8 x i1> zeroinitializer, <8 x i1> %7269
  store <8 x i1> %7271, ptr %7267, align 1
  %7272 = add i32 %7251, 1
  %7273 = select i1 %7242, i32 %7229, i32 %7272
  %7274 = select i1 true, i32 %7273, i32 %7229
  store i32 %7274, ptr %current.token, align 4
  %7275 = load i32, ptr %current.token, align 4
  %7276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1764)
  %7277 = load i32, ptr %ready.count, align 4
  %7278 = icmp uge i32 %7277, 8
  %7279 = and i1 %7276, %7278
  br i1 %7279, label %ready.overflow.trap1372, label %ready.overflow.resume1373

ready.overflow.trap1372:                          ; preds = %convergence.overflow.resume1371
  call void @llvm.trap()
  unreachable

ready.overflow.resume1373:                        ; preds = %convergence.overflow.resume1371
  %7280 = select i1 %7276, i32 %7277, i32 0
  %7281 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7280
  %7282 = load <8 x i1>, ptr %7281, align 1
  %7283 = select i1 %7276, <8 x i1> %1764, <8 x i1> %7282
  store <8 x i1> %7283, ptr %7281, align 1
  %7284 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7280
  %7285 = load i32, ptr %7284, align 4
  %7286 = select i1 %7276, i32 70, i32 %7285
  store i32 %7286, ptr %7284, align 4
  %7287 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7280
  %7288 = load i32, ptr %7287, align 4
  %7289 = select i1 %7276, i32 %7275, i32 %7288
  store i32 %7289, ptr %7287, align 4
  %7290 = add i32 %7277, 1
  %7291 = select i1 %7276, i32 %7290, i32 %7277
  store i32 %7291, ptr %ready.count, align 4
  %7292 = load <8 x i1>, ptr %runnable.mask, align 1
  %7293 = or <8 x i1> %7292, %1764
  store <8 x i1> %7293, ptr %runnable.mask, align 1
  store <8 x i1> %1766, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1374:                        ; preds = %varying.coherent1369
  store <8 x i1> %1757, ptr %current.mask, align 1
  %7294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1757)
  br i1 %7294, label %schedule.70, label %scheduler.loop

varying.coherent.false1375:                       ; preds = %varying.coherent1369
  store <8 x i1> %1757, ptr %current.mask, align 1
  %7295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1757)
  br i1 %7295, label %schedule.71, label %scheduler.loop

convergence.cascade1380:                          ; preds = %convergence.cascade1380, %schedule.71
  %convergence.cascade.flow1384 = phi <8 x i1> [ %1797, %schedule.71 ], [ %7338, %convergence.cascade1380 ]
  %convergence.cascade.depth1385 = phi i32 [ 0, %schedule.71 ], [ %7339, %convergence.cascade1380 ]
  %7296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1384)
  %7297 = load i32, ptr %current.token, align 4
  %7298 = icmp ne i32 %7297, 0
  %7299 = and i1 %7296, %7298
  %7300 = sub i32 %7297, 1
  %7301 = select i1 %7299, i32 %7300, i32 0
  %7302 = load i8, ptr %frame.active, align 1
  %7303 = trunc i32 %7301 to i8
  %7304 = shl i8 1, %7303
  %7305 = and i8 %7302, %7304
  %7306 = icmp ne i8 %7305, 0
  %7307 = load <8 x i32>, ptr %frame.static.id, align 32
  %7308 = extractelement <8 x i32> %7307, i32 %7301
  %convergence.target.pointer1386 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %7308
  %convergence.dynamic.target1387 = load i32, ptr %convergence.target.pointer1386, align 4
  %7309 = icmp eq i32 %convergence.dynamic.target1387, 71
  %7310 = and i1 %7306, %7309
  %7311 = and i1 %7299, %7310
  %7312 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7301
  %7313 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7301
  %7314 = load <8 x i1>, ptr %7312, align 1
  %7315 = load <8 x i1>, ptr %7313, align 1
  %7316 = or <8 x i1> %7315, %convergence.cascade.flow1384
  %7317 = load <8 x i1>, ptr %live.mask, align 1
  %7318 = and <8 x i1> %7314, %7317
  %7319 = icmp eq <8 x i1> %7316, %7318
  %7320 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7319)
  %7321 = and i1 %7311, %7320
  %7322 = select i1 %7321, <8 x i1> zeroinitializer, <8 x i1> %7316
  %7323 = select i1 %7311, <8 x i1> %7322, <8 x i1> %7315
  store <8 x i1> %7323, ptr %7313, align 1
  %7324 = select i1 %7321, <8 x i1> zeroinitializer, <8 x i1> %7314
  store <8 x i1> %7324, ptr %7312, align 1
  %7325 = trunc i32 %7301 to i8
  %7326 = shl i8 1, %7325
  %7327 = xor i8 %7326, -1
  %7328 = and i8 %7302, %7327
  %7329 = select i1 %7321, i8 %7328, i8 %7302
  store i8 %7329, ptr %frame.active, align 1
  %.splatinsert1388 = insertelement <8 x i1> poison, i1 %7311, i64 0
  %.splat1389 = shufflevector <8 x i1> %.splatinsert1388, <8 x i1> poison, <8 x i32> zeroinitializer
  %7330 = and <8 x i1> %convergence.cascade.flow1384, %.splat1389
  %7331 = load <8 x i1>, ptr %runnable.mask, align 1
  %7332 = xor <8 x i1> %7330, splat (i1 true)
  %7333 = and <8 x i1> %7331, %7332
  store <8 x i1> %7333, ptr %runnable.mask, align 1
  %.splatinsert1390 = insertelement <8 x i1> poison, i1 %7321, i64 0
  %.splat1391 = shufflevector <8 x i1> %.splatinsert1390, <8 x i1> poison, <8 x i32> zeroinitializer
  %7334 = select <8 x i1> %.splat1391, <8 x i1> %7316, <8 x i1> zeroinitializer
  %7335 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7336 = extractelement <8 x i32> %7335, i32 %7301
  %7337 = select i1 %7321, i32 %7336, i32 %7297
  store i32 %7337, ptr %current.token, align 4
  %.splatinsert1392 = insertelement <8 x i1> poison, i1 %7311, i64 0
  %.splat1393 = shufflevector <8 x i1> %.splatinsert1392, <8 x i1> poison, <8 x i32> zeroinitializer
  %7338 = select <8 x i1> %.splat1393, <8 x i1> %7334, <8 x i1> %convergence.cascade.flow1384
  %7339 = add i32 %convergence.cascade.depth1385, 1
  %7340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7338)
  %7341 = icmp ult i32 %7339, 8
  %7342 = and i1 %7340, %7341
  %7343 = and i1 %7311, %7342
  %convergence.parent.token1394 = load i32, ptr %current.token, align 4
  %convergence.parent.present1395 = icmp ne i32 %convergence.parent.token1394, 0
  %7344 = and i1 %7343, %convergence.parent.present1395
  br i1 %7344, label %convergence.cascade1380, label %convergence.cascade.exit1381

convergence.cascade.exit1381:                     ; preds = %convergence.cascade1380, %schedule.71
  %convergence.cascade.result1396 = phi <8 x i1> [ %1797, %schedule.71 ], [ %7338, %convergence.cascade1380 ]
  %7345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1396)
  br i1 %7345, label %convergence.target.71.ready, label %scheduler.loop

convergence.target.71.ready:                      ; preds = %convergence.cascade.exit1381
  %7346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1396)
  %7347 = bitcast <8 x i1> %convergence.cascade.result1396 to i8
  %7348 = call i8 @llvm.cttz.i8(i8 %7347, i1 false)
  %7349 = zext i8 %7348 to i32
  %7350 = select i1 %7346, i32 %7349, i32 0
  %7351 = load <8 x i64>, ptr %.slot56, align 64
  %7352 = select <8 x i1> %convergence.cascade.result1396, <8 x i64> zeroinitializer, <8 x i64> %7351
  store <8 x i64> %7352, ptr %.slot56, align 64
  %7353 = load <8 x float>, ptr %.slot65, align 32
  %7354 = select <8 x i1> %convergence.cascade.result1396, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7353
  store <8 x float> %7354, ptr %.slot65, align 32
  store <8 x i1> %convergence.cascade.result1396, ptr %current.mask, align 1
  %7355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1396)
  br i1 %7355, label %schedule.72, label %scheduler.loop

varying.divergent1398:                            ; preds = %schedule.72
  %7356 = load i32, ptr %current.token, align 4
  %7357 = icmp ne i32 %7356, 0
  %7358 = sub i32 %7356, 1
  %7359 = select i1 %7357, i32 %7358, i32 0
  %7360 = load i8, ptr %frame.active, align 1
  %7361 = trunc i32 %7359 to i8
  %7362 = shl i8 1, %7361
  %7363 = and i8 %7360, %7362
  %7364 = icmp ne i8 %7363, 0
  %7365 = load <8 x i32>, ptr %frame.static.id, align 32
  %7366 = extractelement <8 x i32> %7365, i32 %7359
  %7367 = icmp eq i32 %7366, 25
  %7368 = and i1 %7364, %7367
  %7369 = and i1 %7357, %7368
  %7370 = xor i1 %7369, true
  %7371 = and i1 true, %7370
  %7372 = xor i8 %7360, -1
  %7373 = icmp ne i8 %7372, 0
  %7374 = xor i1 %7373, true
  %7375 = and i1 %7371, %7374
  br i1 %7375, label %convergence.overflow.trap1400, label %convergence.overflow.resume1401

varying.coherent1399:                             ; preds = %schedule.72
  br i1 %1808, label %varying.coherent.true1404, label %varying.coherent.false1405

convergence.overflow.trap1400:                    ; preds = %varying.divergent1398
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1401:                  ; preds = %varying.divergent1398
  %7376 = call i8 @llvm.cttz.i8(i8 %7372, i1 false)
  %7377 = zext i8 %7376 to i32
  %7378 = select i1 %7373, i32 %7377, i32 0
  %7379 = trunc i32 %7378 to i8
  %7380 = shl i8 1, %7379
  %7381 = or i8 %7360, %7380
  %7382 = select i1 %7371, i8 %7381, i8 %7360
  store i8 %7382, ptr %frame.active, align 1
  %7383 = load <8 x i32>, ptr %frame.static.id, align 32
  %7384 = extractelement <8 x i32> %7383, i32 %7378
  %7385 = select i1 %7371, i32 25, i32 %7384
  %7386 = load <8 x i32>, ptr %frame.static.id, align 32
  %7387 = insertelement <8 x i32> %7386, i32 %7385, i32 %7378
  store <8 x i32> %7387, ptr %frame.static.id, align 32
  %7388 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7389 = extractelement <8 x i32> %7388, i32 %7378
  %7390 = select i1 %7371, i32 %7356, i32 %7389
  %7391 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7392 = insertelement <8 x i32> %7391, i32 %7390, i32 %7378
  store <8 x i32> %7392, ptr %frame.parent.token, align 32
  %7393 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7378
  %7394 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7378
  %7395 = load <8 x i1>, ptr %7393, align 1
  %7396 = load <8 x i1>, ptr %7394, align 1
  %7397 = select i1 %7371, <8 x i1> %1798, <8 x i1> %7395
  store <8 x i1> %7397, ptr %7393, align 1
  %7398 = select i1 %7371, <8 x i1> zeroinitializer, <8 x i1> %7396
  store <8 x i1> %7398, ptr %7394, align 1
  %7399 = add i32 %7378, 1
  %7400 = select i1 %7369, i32 %7356, i32 %7399
  %7401 = select i1 true, i32 %7400, i32 %7356
  store i32 %7401, ptr %current.token, align 4
  %7402 = load i32, ptr %current.token, align 4
  %7403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1805)
  %7404 = load i32, ptr %ready.count, align 4
  %7405 = icmp uge i32 %7404, 8
  %7406 = and i1 %7403, %7405
  br i1 %7406, label %ready.overflow.trap1402, label %ready.overflow.resume1403

ready.overflow.trap1402:                          ; preds = %convergence.overflow.resume1401
  call void @llvm.trap()
  unreachable

ready.overflow.resume1403:                        ; preds = %convergence.overflow.resume1401
  %7407 = select i1 %7403, i32 %7404, i32 0
  %7408 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7407
  %7409 = load <8 x i1>, ptr %7408, align 1
  %7410 = select i1 %7403, <8 x i1> %1805, <8 x i1> %7409
  store <8 x i1> %7410, ptr %7408, align 1
  %7411 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7407
  %7412 = load i32, ptr %7411, align 4
  %7413 = select i1 %7403, i32 73, i32 %7412
  store i32 %7413, ptr %7411, align 4
  %7414 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7407
  %7415 = load i32, ptr %7414, align 4
  %7416 = select i1 %7403, i32 %7402, i32 %7415
  store i32 %7416, ptr %7414, align 4
  %7417 = add i32 %7404, 1
  %7418 = select i1 %7403, i32 %7417, i32 %7404
  store i32 %7418, ptr %ready.count, align 4
  %7419 = load <8 x i1>, ptr %runnable.mask, align 1
  %7420 = or <8 x i1> %7419, %1805
  store <8 x i1> %7420, ptr %runnable.mask, align 1
  store <8 x i1> %1807, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1404:                        ; preds = %varying.coherent1399
  store <8 x i1> %1798, ptr %current.mask, align 1
  %7421 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1798)
  br i1 %7421, label %schedule.73, label %scheduler.loop

varying.coherent.false1405:                       ; preds = %varying.coherent1399
  store <8 x i1> %1798, ptr %current.mask, align 1
  %7422 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1798)
  br i1 %7422, label %schedule.74, label %scheduler.loop

convergence.cascade1410:                          ; preds = %convergence.cascade1410, %schedule.74
  %convergence.cascade.flow1414 = phi <8 x i1> [ %1838, %schedule.74 ], [ %7465, %convergence.cascade1410 ]
  %convergence.cascade.depth1415 = phi i32 [ 0, %schedule.74 ], [ %7466, %convergence.cascade1410 ]
  %7423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1414)
  %7424 = load i32, ptr %current.token, align 4
  %7425 = icmp ne i32 %7424, 0
  %7426 = and i1 %7423, %7425
  %7427 = sub i32 %7424, 1
  %7428 = select i1 %7426, i32 %7427, i32 0
  %7429 = load i8, ptr %frame.active, align 1
  %7430 = trunc i32 %7428 to i8
  %7431 = shl i8 1, %7430
  %7432 = and i8 %7429, %7431
  %7433 = icmp ne i8 %7432, 0
  %7434 = load <8 x i32>, ptr %frame.static.id, align 32
  %7435 = extractelement <8 x i32> %7434, i32 %7428
  %convergence.target.pointer1416 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %7435
  %convergence.dynamic.target1417 = load i32, ptr %convergence.target.pointer1416, align 4
  %7436 = icmp eq i32 %convergence.dynamic.target1417, 74
  %7437 = and i1 %7433, %7436
  %7438 = and i1 %7426, %7437
  %7439 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7428
  %7440 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7428
  %7441 = load <8 x i1>, ptr %7439, align 1
  %7442 = load <8 x i1>, ptr %7440, align 1
  %7443 = or <8 x i1> %7442, %convergence.cascade.flow1414
  %7444 = load <8 x i1>, ptr %live.mask, align 1
  %7445 = and <8 x i1> %7441, %7444
  %7446 = icmp eq <8 x i1> %7443, %7445
  %7447 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7446)
  %7448 = and i1 %7438, %7447
  %7449 = select i1 %7448, <8 x i1> zeroinitializer, <8 x i1> %7443
  %7450 = select i1 %7438, <8 x i1> %7449, <8 x i1> %7442
  store <8 x i1> %7450, ptr %7440, align 1
  %7451 = select i1 %7448, <8 x i1> zeroinitializer, <8 x i1> %7441
  store <8 x i1> %7451, ptr %7439, align 1
  %7452 = trunc i32 %7428 to i8
  %7453 = shl i8 1, %7452
  %7454 = xor i8 %7453, -1
  %7455 = and i8 %7429, %7454
  %7456 = select i1 %7448, i8 %7455, i8 %7429
  store i8 %7456, ptr %frame.active, align 1
  %.splatinsert1418 = insertelement <8 x i1> poison, i1 %7438, i64 0
  %.splat1419 = shufflevector <8 x i1> %.splatinsert1418, <8 x i1> poison, <8 x i32> zeroinitializer
  %7457 = and <8 x i1> %convergence.cascade.flow1414, %.splat1419
  %7458 = load <8 x i1>, ptr %runnable.mask, align 1
  %7459 = xor <8 x i1> %7457, splat (i1 true)
  %7460 = and <8 x i1> %7458, %7459
  store <8 x i1> %7460, ptr %runnable.mask, align 1
  %.splatinsert1420 = insertelement <8 x i1> poison, i1 %7448, i64 0
  %.splat1421 = shufflevector <8 x i1> %.splatinsert1420, <8 x i1> poison, <8 x i32> zeroinitializer
  %7461 = select <8 x i1> %.splat1421, <8 x i1> %7443, <8 x i1> zeroinitializer
  %7462 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7463 = extractelement <8 x i32> %7462, i32 %7428
  %7464 = select i1 %7448, i32 %7463, i32 %7424
  store i32 %7464, ptr %current.token, align 4
  %.splatinsert1422 = insertelement <8 x i1> poison, i1 %7438, i64 0
  %.splat1423 = shufflevector <8 x i1> %.splatinsert1422, <8 x i1> poison, <8 x i32> zeroinitializer
  %7465 = select <8 x i1> %.splat1423, <8 x i1> %7461, <8 x i1> %convergence.cascade.flow1414
  %7466 = add i32 %convergence.cascade.depth1415, 1
  %7467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7465)
  %7468 = icmp ult i32 %7466, 8
  %7469 = and i1 %7467, %7468
  %7470 = and i1 %7438, %7469
  %convergence.parent.token1424 = load i32, ptr %current.token, align 4
  %convergence.parent.present1425 = icmp ne i32 %convergence.parent.token1424, 0
  %7471 = and i1 %7470, %convergence.parent.present1425
  br i1 %7471, label %convergence.cascade1410, label %convergence.cascade.exit1411

convergence.cascade.exit1411:                     ; preds = %convergence.cascade1410, %schedule.74
  %convergence.cascade.result1426 = phi <8 x i1> [ %1838, %schedule.74 ], [ %7465, %convergence.cascade1410 ]
  %7472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1426)
  br i1 %7472, label %convergence.target.74.ready, label %scheduler.loop

convergence.target.74.ready:                      ; preds = %convergence.cascade.exit1411
  %7473 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1426)
  %7474 = bitcast <8 x i1> %convergence.cascade.result1426 to i8
  %7475 = call i8 @llvm.cttz.i8(i8 %7474, i1 false)
  %7476 = zext i8 %7475 to i32
  %7477 = select i1 %7473, i32 %7476, i32 0
  %7478 = load <8 x i64>, ptr %.slot56, align 64
  %7479 = select <8 x i1> %convergence.cascade.result1426, <8 x i64> zeroinitializer, <8 x i64> %7478
  store <8 x i64> %7479, ptr %.slot56, align 64
  %7480 = load <8 x float>, ptr %.slot66, align 32
  %7481 = select <8 x i1> %convergence.cascade.result1426, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7480
  store <8 x float> %7481, ptr %.slot66, align 32
  store <8 x i1> %convergence.cascade.result1426, ptr %current.mask, align 1
  %7482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1426)
  br i1 %7482, label %schedule.75, label %scheduler.loop

varying.divergent1428:                            ; preds = %schedule.75
  %7483 = load i32, ptr %current.token, align 4
  %7484 = icmp ne i32 %7483, 0
  %7485 = sub i32 %7483, 1
  %7486 = select i1 %7484, i32 %7485, i32 0
  %7487 = load i8, ptr %frame.active, align 1
  %7488 = trunc i32 %7486 to i8
  %7489 = shl i8 1, %7488
  %7490 = and i8 %7487, %7489
  %7491 = icmp ne i8 %7490, 0
  %7492 = load <8 x i32>, ptr %frame.static.id, align 32
  %7493 = extractelement <8 x i32> %7492, i32 %7486
  %7494 = icmp eq i32 %7493, 26
  %7495 = and i1 %7491, %7494
  %7496 = and i1 %7484, %7495
  %7497 = xor i1 %7496, true
  %7498 = and i1 true, %7497
  %7499 = xor i8 %7487, -1
  %7500 = icmp ne i8 %7499, 0
  %7501 = xor i1 %7500, true
  %7502 = and i1 %7498, %7501
  br i1 %7502, label %convergence.overflow.trap1430, label %convergence.overflow.resume1431

varying.coherent1429:                             ; preds = %schedule.75
  br i1 %1849, label %varying.coherent.true1434, label %varying.coherent.false1435

convergence.overflow.trap1430:                    ; preds = %varying.divergent1428
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1431:                  ; preds = %varying.divergent1428
  %7503 = call i8 @llvm.cttz.i8(i8 %7499, i1 false)
  %7504 = zext i8 %7503 to i32
  %7505 = select i1 %7500, i32 %7504, i32 0
  %7506 = trunc i32 %7505 to i8
  %7507 = shl i8 1, %7506
  %7508 = or i8 %7487, %7507
  %7509 = select i1 %7498, i8 %7508, i8 %7487
  store i8 %7509, ptr %frame.active, align 1
  %7510 = load <8 x i32>, ptr %frame.static.id, align 32
  %7511 = extractelement <8 x i32> %7510, i32 %7505
  %7512 = select i1 %7498, i32 26, i32 %7511
  %7513 = load <8 x i32>, ptr %frame.static.id, align 32
  %7514 = insertelement <8 x i32> %7513, i32 %7512, i32 %7505
  store <8 x i32> %7514, ptr %frame.static.id, align 32
  %7515 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7516 = extractelement <8 x i32> %7515, i32 %7505
  %7517 = select i1 %7498, i32 %7483, i32 %7516
  %7518 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7519 = insertelement <8 x i32> %7518, i32 %7517, i32 %7505
  store <8 x i32> %7519, ptr %frame.parent.token, align 32
  %7520 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7505
  %7521 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7505
  %7522 = load <8 x i1>, ptr %7520, align 1
  %7523 = load <8 x i1>, ptr %7521, align 1
  %7524 = select i1 %7498, <8 x i1> %1839, <8 x i1> %7522
  store <8 x i1> %7524, ptr %7520, align 1
  %7525 = select i1 %7498, <8 x i1> zeroinitializer, <8 x i1> %7523
  store <8 x i1> %7525, ptr %7521, align 1
  %7526 = add i32 %7505, 1
  %7527 = select i1 %7496, i32 %7483, i32 %7526
  %7528 = select i1 true, i32 %7527, i32 %7483
  store i32 %7528, ptr %current.token, align 4
  %7529 = load i32, ptr %current.token, align 4
  %7530 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1846)
  %7531 = load i32, ptr %ready.count, align 4
  %7532 = icmp uge i32 %7531, 8
  %7533 = and i1 %7530, %7532
  br i1 %7533, label %ready.overflow.trap1432, label %ready.overflow.resume1433

ready.overflow.trap1432:                          ; preds = %convergence.overflow.resume1431
  call void @llvm.trap()
  unreachable

ready.overflow.resume1433:                        ; preds = %convergence.overflow.resume1431
  %7534 = select i1 %7530, i32 %7531, i32 0
  %7535 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7534
  %7536 = load <8 x i1>, ptr %7535, align 1
  %7537 = select i1 %7530, <8 x i1> %1846, <8 x i1> %7536
  store <8 x i1> %7537, ptr %7535, align 1
  %7538 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7534
  %7539 = load i32, ptr %7538, align 4
  %7540 = select i1 %7530, i32 76, i32 %7539
  store i32 %7540, ptr %7538, align 4
  %7541 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7534
  %7542 = load i32, ptr %7541, align 4
  %7543 = select i1 %7530, i32 %7529, i32 %7542
  store i32 %7543, ptr %7541, align 4
  %7544 = add i32 %7531, 1
  %7545 = select i1 %7530, i32 %7544, i32 %7531
  store i32 %7545, ptr %ready.count, align 4
  %7546 = load <8 x i1>, ptr %runnable.mask, align 1
  %7547 = or <8 x i1> %7546, %1846
  store <8 x i1> %7547, ptr %runnable.mask, align 1
  store <8 x i1> %1848, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1434:                        ; preds = %varying.coherent1429
  store <8 x i1> %1839, ptr %current.mask, align 1
  %7548 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1839)
  br i1 %7548, label %schedule.76, label %scheduler.loop

varying.coherent.false1435:                       ; preds = %varying.coherent1429
  store <8 x i1> %1839, ptr %current.mask, align 1
  %7549 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1839)
  br i1 %7549, label %schedule.77, label %scheduler.loop

convergence.cascade1440:                          ; preds = %convergence.cascade1440, %schedule.77
  %convergence.cascade.flow1444 = phi <8 x i1> [ %1879, %schedule.77 ], [ %7592, %convergence.cascade1440 ]
  %convergence.cascade.depth1445 = phi i32 [ 0, %schedule.77 ], [ %7593, %convergence.cascade1440 ]
  %7550 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1444)
  %7551 = load i32, ptr %current.token, align 4
  %7552 = icmp ne i32 %7551, 0
  %7553 = and i1 %7550, %7552
  %7554 = sub i32 %7551, 1
  %7555 = select i1 %7553, i32 %7554, i32 0
  %7556 = load i8, ptr %frame.active, align 1
  %7557 = trunc i32 %7555 to i8
  %7558 = shl i8 1, %7557
  %7559 = and i8 %7556, %7558
  %7560 = icmp ne i8 %7559, 0
  %7561 = load <8 x i32>, ptr %frame.static.id, align 32
  %7562 = extractelement <8 x i32> %7561, i32 %7555
  %convergence.target.pointer1446 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %7562
  %convergence.dynamic.target1447 = load i32, ptr %convergence.target.pointer1446, align 4
  %7563 = icmp eq i32 %convergence.dynamic.target1447, 77
  %7564 = and i1 %7560, %7563
  %7565 = and i1 %7553, %7564
  %7566 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7555
  %7567 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7555
  %7568 = load <8 x i1>, ptr %7566, align 1
  %7569 = load <8 x i1>, ptr %7567, align 1
  %7570 = or <8 x i1> %7569, %convergence.cascade.flow1444
  %7571 = load <8 x i1>, ptr %live.mask, align 1
  %7572 = and <8 x i1> %7568, %7571
  %7573 = icmp eq <8 x i1> %7570, %7572
  %7574 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7573)
  %7575 = and i1 %7565, %7574
  %7576 = select i1 %7575, <8 x i1> zeroinitializer, <8 x i1> %7570
  %7577 = select i1 %7565, <8 x i1> %7576, <8 x i1> %7569
  store <8 x i1> %7577, ptr %7567, align 1
  %7578 = select i1 %7575, <8 x i1> zeroinitializer, <8 x i1> %7568
  store <8 x i1> %7578, ptr %7566, align 1
  %7579 = trunc i32 %7555 to i8
  %7580 = shl i8 1, %7579
  %7581 = xor i8 %7580, -1
  %7582 = and i8 %7556, %7581
  %7583 = select i1 %7575, i8 %7582, i8 %7556
  store i8 %7583, ptr %frame.active, align 1
  %.splatinsert1448 = insertelement <8 x i1> poison, i1 %7565, i64 0
  %.splat1449 = shufflevector <8 x i1> %.splatinsert1448, <8 x i1> poison, <8 x i32> zeroinitializer
  %7584 = and <8 x i1> %convergence.cascade.flow1444, %.splat1449
  %7585 = load <8 x i1>, ptr %runnable.mask, align 1
  %7586 = xor <8 x i1> %7584, splat (i1 true)
  %7587 = and <8 x i1> %7585, %7586
  store <8 x i1> %7587, ptr %runnable.mask, align 1
  %.splatinsert1450 = insertelement <8 x i1> poison, i1 %7575, i64 0
  %.splat1451 = shufflevector <8 x i1> %.splatinsert1450, <8 x i1> poison, <8 x i32> zeroinitializer
  %7588 = select <8 x i1> %.splat1451, <8 x i1> %7570, <8 x i1> zeroinitializer
  %7589 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7590 = extractelement <8 x i32> %7589, i32 %7555
  %7591 = select i1 %7575, i32 %7590, i32 %7551
  store i32 %7591, ptr %current.token, align 4
  %.splatinsert1452 = insertelement <8 x i1> poison, i1 %7565, i64 0
  %.splat1453 = shufflevector <8 x i1> %.splatinsert1452, <8 x i1> poison, <8 x i32> zeroinitializer
  %7592 = select <8 x i1> %.splat1453, <8 x i1> %7588, <8 x i1> %convergence.cascade.flow1444
  %7593 = add i32 %convergence.cascade.depth1445, 1
  %7594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7592)
  %7595 = icmp ult i32 %7593, 8
  %7596 = and i1 %7594, %7595
  %7597 = and i1 %7565, %7596
  %convergence.parent.token1454 = load i32, ptr %current.token, align 4
  %convergence.parent.present1455 = icmp ne i32 %convergence.parent.token1454, 0
  %7598 = and i1 %7597, %convergence.parent.present1455
  br i1 %7598, label %convergence.cascade1440, label %convergence.cascade.exit1441

convergence.cascade.exit1441:                     ; preds = %convergence.cascade1440, %schedule.77
  %convergence.cascade.result1456 = phi <8 x i1> [ %1879, %schedule.77 ], [ %7592, %convergence.cascade1440 ]
  %7599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1456)
  br i1 %7599, label %convergence.target.77.ready, label %scheduler.loop

convergence.target.77.ready:                      ; preds = %convergence.cascade.exit1441
  %7600 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1456)
  %7601 = bitcast <8 x i1> %convergence.cascade.result1456 to i8
  %7602 = call i8 @llvm.cttz.i8(i8 %7601, i1 false)
  %7603 = zext i8 %7602 to i32
  %7604 = select i1 %7600, i32 %7603, i32 0
  %7605 = load <8 x i64>, ptr %.slot56, align 64
  %7606 = select <8 x i1> %convergence.cascade.result1456, <8 x i64> zeroinitializer, <8 x i64> %7605
  store <8 x i64> %7606, ptr %.slot56, align 64
  %7607 = load <8 x float>, ptr %.slot67, align 32
  %7608 = select <8 x i1> %convergence.cascade.result1456, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7607
  store <8 x float> %7608, ptr %.slot67, align 32
  store <8 x i1> %convergence.cascade.result1456, ptr %current.mask, align 1
  %7609 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1456)
  br i1 %7609, label %schedule.78, label %scheduler.loop

varying.divergent1458:                            ; preds = %schedule.78
  %7610 = load i32, ptr %current.token, align 4
  %7611 = icmp ne i32 %7610, 0
  %7612 = sub i32 %7610, 1
  %7613 = select i1 %7611, i32 %7612, i32 0
  %7614 = load i8, ptr %frame.active, align 1
  %7615 = trunc i32 %7613 to i8
  %7616 = shl i8 1, %7615
  %7617 = and i8 %7614, %7616
  %7618 = icmp ne i8 %7617, 0
  %7619 = load <8 x i32>, ptr %frame.static.id, align 32
  %7620 = extractelement <8 x i32> %7619, i32 %7613
  %7621 = icmp eq i32 %7620, 27
  %7622 = and i1 %7618, %7621
  %7623 = and i1 %7611, %7622
  %7624 = xor i1 %7623, true
  %7625 = and i1 true, %7624
  %7626 = xor i8 %7614, -1
  %7627 = icmp ne i8 %7626, 0
  %7628 = xor i1 %7627, true
  %7629 = and i1 %7625, %7628
  br i1 %7629, label %convergence.overflow.trap1460, label %convergence.overflow.resume1461

varying.coherent1459:                             ; preds = %schedule.78
  br i1 %1890, label %varying.coherent.true1464, label %varying.coherent.false1465

convergence.overflow.trap1460:                    ; preds = %varying.divergent1458
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1461:                  ; preds = %varying.divergent1458
  %7630 = call i8 @llvm.cttz.i8(i8 %7626, i1 false)
  %7631 = zext i8 %7630 to i32
  %7632 = select i1 %7627, i32 %7631, i32 0
  %7633 = trunc i32 %7632 to i8
  %7634 = shl i8 1, %7633
  %7635 = or i8 %7614, %7634
  %7636 = select i1 %7625, i8 %7635, i8 %7614
  store i8 %7636, ptr %frame.active, align 1
  %7637 = load <8 x i32>, ptr %frame.static.id, align 32
  %7638 = extractelement <8 x i32> %7637, i32 %7632
  %7639 = select i1 %7625, i32 27, i32 %7638
  %7640 = load <8 x i32>, ptr %frame.static.id, align 32
  %7641 = insertelement <8 x i32> %7640, i32 %7639, i32 %7632
  store <8 x i32> %7641, ptr %frame.static.id, align 32
  %7642 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7643 = extractelement <8 x i32> %7642, i32 %7632
  %7644 = select i1 %7625, i32 %7610, i32 %7643
  %7645 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7646 = insertelement <8 x i32> %7645, i32 %7644, i32 %7632
  store <8 x i32> %7646, ptr %frame.parent.token, align 32
  %7647 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7632
  %7648 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7632
  %7649 = load <8 x i1>, ptr %7647, align 1
  %7650 = load <8 x i1>, ptr %7648, align 1
  %7651 = select i1 %7625, <8 x i1> %1880, <8 x i1> %7649
  store <8 x i1> %7651, ptr %7647, align 1
  %7652 = select i1 %7625, <8 x i1> zeroinitializer, <8 x i1> %7650
  store <8 x i1> %7652, ptr %7648, align 1
  %7653 = add i32 %7632, 1
  %7654 = select i1 %7623, i32 %7610, i32 %7653
  %7655 = select i1 true, i32 %7654, i32 %7610
  store i32 %7655, ptr %current.token, align 4
  %7656 = load i32, ptr %current.token, align 4
  %7657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1887)
  %7658 = load i32, ptr %ready.count, align 4
  %7659 = icmp uge i32 %7658, 8
  %7660 = and i1 %7657, %7659
  br i1 %7660, label %ready.overflow.trap1462, label %ready.overflow.resume1463

ready.overflow.trap1462:                          ; preds = %convergence.overflow.resume1461
  call void @llvm.trap()
  unreachable

ready.overflow.resume1463:                        ; preds = %convergence.overflow.resume1461
  %7661 = select i1 %7657, i32 %7658, i32 0
  %7662 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7661
  %7663 = load <8 x i1>, ptr %7662, align 1
  %7664 = select i1 %7657, <8 x i1> %1887, <8 x i1> %7663
  store <8 x i1> %7664, ptr %7662, align 1
  %7665 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7661
  %7666 = load i32, ptr %7665, align 4
  %7667 = select i1 %7657, i32 79, i32 %7666
  store i32 %7667, ptr %7665, align 4
  %7668 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7661
  %7669 = load i32, ptr %7668, align 4
  %7670 = select i1 %7657, i32 %7656, i32 %7669
  store i32 %7670, ptr %7668, align 4
  %7671 = add i32 %7658, 1
  %7672 = select i1 %7657, i32 %7671, i32 %7658
  store i32 %7672, ptr %ready.count, align 4
  %7673 = load <8 x i1>, ptr %runnable.mask, align 1
  %7674 = or <8 x i1> %7673, %1887
  store <8 x i1> %7674, ptr %runnable.mask, align 1
  store <8 x i1> %1889, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1464:                        ; preds = %varying.coherent1459
  store <8 x i1> %1880, ptr %current.mask, align 1
  %7675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1880)
  br i1 %7675, label %schedule.79, label %scheduler.loop

varying.coherent.false1465:                       ; preds = %varying.coherent1459
  store <8 x i1> %1880, ptr %current.mask, align 1
  %7676 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1880)
  br i1 %7676, label %schedule.80, label %scheduler.loop

convergence.cascade1470:                          ; preds = %convergence.cascade1470, %schedule.80
  %convergence.cascade.flow1474 = phi <8 x i1> [ %1920, %schedule.80 ], [ %7719, %convergence.cascade1470 ]
  %convergence.cascade.depth1475 = phi i32 [ 0, %schedule.80 ], [ %7720, %convergence.cascade1470 ]
  %7677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1474)
  %7678 = load i32, ptr %current.token, align 4
  %7679 = icmp ne i32 %7678, 0
  %7680 = and i1 %7677, %7679
  %7681 = sub i32 %7678, 1
  %7682 = select i1 %7680, i32 %7681, i32 0
  %7683 = load i8, ptr %frame.active, align 1
  %7684 = trunc i32 %7682 to i8
  %7685 = shl i8 1, %7684
  %7686 = and i8 %7683, %7685
  %7687 = icmp ne i8 %7686, 0
  %7688 = load <8 x i32>, ptr %frame.static.id, align 32
  %7689 = extractelement <8 x i32> %7688, i32 %7682
  %convergence.target.pointer1476 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %7689
  %convergence.dynamic.target1477 = load i32, ptr %convergence.target.pointer1476, align 4
  %7690 = icmp eq i32 %convergence.dynamic.target1477, 80
  %7691 = and i1 %7687, %7690
  %7692 = and i1 %7680, %7691
  %7693 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7682
  %7694 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7682
  %7695 = load <8 x i1>, ptr %7693, align 1
  %7696 = load <8 x i1>, ptr %7694, align 1
  %7697 = or <8 x i1> %7696, %convergence.cascade.flow1474
  %7698 = load <8 x i1>, ptr %live.mask, align 1
  %7699 = and <8 x i1> %7695, %7698
  %7700 = icmp eq <8 x i1> %7697, %7699
  %7701 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7700)
  %7702 = and i1 %7692, %7701
  %7703 = select i1 %7702, <8 x i1> zeroinitializer, <8 x i1> %7697
  %7704 = select i1 %7692, <8 x i1> %7703, <8 x i1> %7696
  store <8 x i1> %7704, ptr %7694, align 1
  %7705 = select i1 %7702, <8 x i1> zeroinitializer, <8 x i1> %7695
  store <8 x i1> %7705, ptr %7693, align 1
  %7706 = trunc i32 %7682 to i8
  %7707 = shl i8 1, %7706
  %7708 = xor i8 %7707, -1
  %7709 = and i8 %7683, %7708
  %7710 = select i1 %7702, i8 %7709, i8 %7683
  store i8 %7710, ptr %frame.active, align 1
  %.splatinsert1478 = insertelement <8 x i1> poison, i1 %7692, i64 0
  %.splat1479 = shufflevector <8 x i1> %.splatinsert1478, <8 x i1> poison, <8 x i32> zeroinitializer
  %7711 = and <8 x i1> %convergence.cascade.flow1474, %.splat1479
  %7712 = load <8 x i1>, ptr %runnable.mask, align 1
  %7713 = xor <8 x i1> %7711, splat (i1 true)
  %7714 = and <8 x i1> %7712, %7713
  store <8 x i1> %7714, ptr %runnable.mask, align 1
  %.splatinsert1480 = insertelement <8 x i1> poison, i1 %7702, i64 0
  %.splat1481 = shufflevector <8 x i1> %.splatinsert1480, <8 x i1> poison, <8 x i32> zeroinitializer
  %7715 = select <8 x i1> %.splat1481, <8 x i1> %7697, <8 x i1> zeroinitializer
  %7716 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7717 = extractelement <8 x i32> %7716, i32 %7682
  %7718 = select i1 %7702, i32 %7717, i32 %7678
  store i32 %7718, ptr %current.token, align 4
  %.splatinsert1482 = insertelement <8 x i1> poison, i1 %7692, i64 0
  %.splat1483 = shufflevector <8 x i1> %.splatinsert1482, <8 x i1> poison, <8 x i32> zeroinitializer
  %7719 = select <8 x i1> %.splat1483, <8 x i1> %7715, <8 x i1> %convergence.cascade.flow1474
  %7720 = add i32 %convergence.cascade.depth1475, 1
  %7721 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7719)
  %7722 = icmp ult i32 %7720, 8
  %7723 = and i1 %7721, %7722
  %7724 = and i1 %7692, %7723
  %convergence.parent.token1484 = load i32, ptr %current.token, align 4
  %convergence.parent.present1485 = icmp ne i32 %convergence.parent.token1484, 0
  %7725 = and i1 %7724, %convergence.parent.present1485
  br i1 %7725, label %convergence.cascade1470, label %convergence.cascade.exit1471

convergence.cascade.exit1471:                     ; preds = %convergence.cascade1470, %schedule.80
  %convergence.cascade.result1486 = phi <8 x i1> [ %1920, %schedule.80 ], [ %7719, %convergence.cascade1470 ]
  %7726 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  br i1 %7726, label %convergence.target.80.ready, label %scheduler.loop

convergence.target.80.ready:                      ; preds = %convergence.cascade.exit1471
  %7727 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %7728 = bitcast <8 x i1> %convergence.cascade.result1486 to i8
  %7729 = call i8 @llvm.cttz.i8(i8 %7728, i1 false)
  %7730 = zext i8 %7729 to i32
  %7731 = select i1 %7727, i32 %7730, i32 0
  %.state1487 = load <8 x float>, ptr %.slot41, align 32
  %.state1488 = load <8 x float>, ptr %.slot58, align 32
  %7732 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1487, <8 x float> %.state1488)
  %7733 = load <8 x float>, ptr %.spill280, align 32
  %7734 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7732, <8 x float> %7733
  store <8 x float> %7734, ptr %.spill280, align 32
  %.state1489 = load <8 x float>, ptr %.slot47, align 32
  %.state1490 = load <8 x float>, ptr %.slot65, align 32
  %7735 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1489, <8 x float> %.state1490)
  %7736 = load <8 x float>, ptr %.spill281, align 32
  %7737 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7735, <8 x float> %7736
  store <8 x float> %7737, ptr %.spill281, align 32
  %.state1491 = load <8 x float>, ptr %.slot48, align 32
  %.state1492 = load <8 x float>, ptr %.slot66, align 32
  %7738 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1491, <8 x float> %.state1492)
  %7739 = load <8 x float>, ptr %.spill282, align 32
  %7740 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7738, <8 x float> %7739
  store <8 x float> %7740, ptr %.spill282, align 32
  %.state1493 = load <8 x float>, ptr %.slot49, align 32
  %.state1494 = load <8 x float>, ptr %.slot67, align 32
  %7741 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1493, <8 x float> %.state1494)
  %7742 = load <8 x float>, ptr %.spill283, align 32
  %7743 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7741, <8 x float> %7742
  store <8 x float> %7743, ptr %.spill283, align 32
  %.state1495 = load <8 x float>, ptr %.slot41, align 32
  %7744 = fsub <8 x float> %.state1495, %7732
  %.state1496 = load <8 x float>, ptr %.slot47, align 32
  %7745 = fsub <8 x float> %.state1496, %7735
  %.state1497 = load <8 x float>, ptr %.slot48, align 32
  %7746 = fsub <8 x float> %.state1497, %7738
  %.state1498 = load <8 x float>, ptr %.slot49, align 32
  %7747 = fsub <8 x float> %.state1498, %7741
  %7748 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7744, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7748)
  %7749 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7745, <8 x float> zeroinitializer
  %native.exp1499 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7749)
  %7750 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7746, <8 x float> zeroinitializer
  %native.exp1500 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7750)
  %7751 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7747, <8 x float> zeroinitializer
  %native.exp1501 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7751)
  %7752 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill284, align 64
  %7753 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7754 = extractvalue { <8 x ptr>, <8 x i64> } %7752, 0
  %7755 = select <8 x i1> %convergence.cascade.result1486, <8 x ptr> %7753, <8 x ptr> %7754
  %7756 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7757 = extractvalue { <8 x ptr>, <8 x i64> } %7752, 1
  %7758 = select <8 x i1> %convergence.cascade.result1486, <8 x i64> %7756, <8 x i64> %7757
  %7759 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7755, 0
  %7760 = insertvalue { <8 x ptr>, <8 x i64> } %7759, <8 x i64> %7758, 1
  store { <8 x ptr>, <8 x i64> } %7760, ptr %tile_snapshot.spill284, align 64
  %7761 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7762 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7763 = add <8 x i64> %7762, zeroinitializer
  %7764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7761, 0
  %7765 = insertvalue { <8 x ptr>, <8 x i64> } %7764, <8 x i64> %7763, 1
  %7766 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7767 = extractvalue { <8 x ptr>, <8 x i64> } %7765, 1
  %7768 = extractelement <8 x ptr> %7766, i32 0
  %7769 = extractelement <8 x i64> %7767, i32 %7731
  %7770 = zext i32 %7731 to i64
  %7771 = mul i64 %7770, 4
  %7772 = sub i64 %7769, %7771
  %7773 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %7774 = select i1 %7773, i64 %7772, i64 0
  %private.contiguous.address1502 = getelementptr i8, ptr %7768, i64 %7774
  %private.contiguous.preserve1503 = load <8 x float>, ptr %private.contiguous.address1502, align 4
  %7775 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve1503
  store <8 x float> %7775, ptr %private.contiguous.address1502, align 4
  %7776 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7777 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7778 = add <8 x i64> %7777, splat (i64 32)
  %7779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7776, 0
  %7780 = insertvalue { <8 x ptr>, <8 x i64> } %7779, <8 x i64> %7778, 1
  %7781 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7782 = extractvalue { <8 x ptr>, <8 x i64> } %7780, 1
  %7783 = extractelement <8 x ptr> %7781, i32 0
  %7784 = extractelement <8 x i64> %7782, i32 %7731
  %7785 = zext i32 %7731 to i64
  %7786 = mul i64 %7785, 4
  %7787 = sub i64 %7784, %7786
  %7788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %7789 = select i1 %7788, i64 %7787, i64 0
  %private.contiguous.address1504 = getelementptr i8, ptr %7783, i64 %7789
  %private.contiguous.preserve1505 = load <8 x float>, ptr %private.contiguous.address1504, align 4
  %7790 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %native.exp1499, <8 x float> %private.contiguous.preserve1505
  store <8 x float> %7790, ptr %private.contiguous.address1504, align 4
  %7791 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7792 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7793 = add <8 x i64> %7792, splat (i64 64)
  %7794 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7791, 0
  %7795 = insertvalue { <8 x ptr>, <8 x i64> } %7794, <8 x i64> %7793, 1
  %7796 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7797 = extractvalue { <8 x ptr>, <8 x i64> } %7795, 1
  %7798 = extractelement <8 x ptr> %7796, i32 0
  %7799 = extractelement <8 x i64> %7797, i32 %7731
  %7800 = zext i32 %7731 to i64
  %7801 = mul i64 %7800, 4
  %7802 = sub i64 %7799, %7801
  %7803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %7804 = select i1 %7803, i64 %7802, i64 0
  %private.contiguous.address1506 = getelementptr i8, ptr %7798, i64 %7804
  %private.contiguous.preserve1507 = load <8 x float>, ptr %private.contiguous.address1506, align 4
  %7805 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %native.exp1500, <8 x float> %private.contiguous.preserve1507
  store <8 x float> %7805, ptr %private.contiguous.address1506, align 4
  %7806 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7807 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7808 = add <8 x i64> %7807, splat (i64 96)
  %7809 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7806, 0
  %7810 = insertvalue { <8 x ptr>, <8 x i64> } %7809, <8 x i64> %7808, 1
  %7811 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7812 = extractvalue { <8 x ptr>, <8 x i64> } %7810, 1
  %7813 = extractelement <8 x ptr> %7811, i32 0
  %7814 = extractelement <8 x i64> %7812, i32 %7731
  %7815 = zext i32 %7731 to i64
  %7816 = mul i64 %7815, 4
  %7817 = sub i64 %7814, %7816
  %7818 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %7819 = select i1 %7818, i64 %7817, i64 0
  %private.contiguous.address1508 = getelementptr i8, ptr %7813, i64 %7819
  %private.contiguous.preserve1509 = load <8 x float>, ptr %private.contiguous.address1508, align 4
  %7820 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %native.exp1501, <8 x float> %private.contiguous.preserve1509
  store <8 x float> %7820, ptr %private.contiguous.address1508, align 4
  %.spill.load1510 = load <8 x float>, ptr %.spill207, align 32
  %7821 = fsub <8 x float> %.spill.load1510, %7732
  %.spill.load1511 = load <8 x float>, ptr %.spill208, align 32
  %7822 = fsub <8 x float> %.spill.load1511, %7732
  %.spill.load1512 = load <8 x float>, ptr %.spill209, align 32
  %7823 = fsub <8 x float> %.spill.load1512, %7732
  %.spill.load1513 = load <8 x float>, ptr %.spill210, align 32
  %7824 = fsub <8 x float> %.spill.load1513, %7732
  %.spill.load1514 = load <8 x float>, ptr %.spill211, align 32
  %7825 = fsub <8 x float> %.spill.load1514, %7732
  %.spill.load1515 = load <8 x float>, ptr %.spill212, align 32
  %7826 = fsub <8 x float> %.spill.load1515, %7732
  %.spill.load1516 = load <8 x float>, ptr %.spill213, align 32
  %7827 = fsub <8 x float> %.spill.load1516, %7732
  %.spill.load1517 = load <8 x float>, ptr %.spill214, align 32
  %7828 = fsub <8 x float> %.spill.load1517, %7732
  %.spill.load1518 = load <8 x float>, ptr %.spill215, align 32
  %7829 = fsub <8 x float> %.spill.load1518, %7732
  %.spill.load1519 = load <8 x float>, ptr %.spill216, align 32
  %7830 = fsub <8 x float> %.spill.load1519, %7732
  %.spill.load1520 = load <8 x float>, ptr %.spill217, align 32
  %7831 = fsub <8 x float> %.spill.load1520, %7732
  %.spill.load1521 = load <8 x float>, ptr %.spill218, align 32
  %7832 = fsub <8 x float> %.spill.load1521, %7732
  %.spill.load1522 = load <8 x float>, ptr %.spill219, align 32
  %7833 = fsub <8 x float> %.spill.load1522, %7732
  %.spill.load1523 = load <8 x float>, ptr %.spill220, align 32
  %7834 = fsub <8 x float> %.spill.load1523, %7732
  %.spill.load1524 = load <8 x float>, ptr %.spill221, align 32
  %7835 = fsub <8 x float> %.spill.load1524, %7732
  %.spill.load1525 = load <8 x float>, ptr %.spill222, align 32
  %7836 = fsub <8 x float> %.spill.load1525, %7732
  %.spill.load1526 = load <8 x float>, ptr %.spill223, align 32
  %7837 = fsub <8 x float> %.spill.load1526, %7735
  %.spill.load1527 = load <8 x float>, ptr %.spill224, align 32
  %7838 = fsub <8 x float> %.spill.load1527, %7735
  %.spill.load1528 = load <8 x float>, ptr %.spill225, align 32
  %7839 = fsub <8 x float> %.spill.load1528, %7735
  %.spill.load1529 = load <8 x float>, ptr %.spill226, align 32
  %7840 = fsub <8 x float> %.spill.load1529, %7735
  %.spill.load1530 = load <8 x float>, ptr %.spill227, align 32
  %7841 = fsub <8 x float> %.spill.load1530, %7735
  %.spill.load1531 = load <8 x float>, ptr %.spill228, align 32
  %7842 = fsub <8 x float> %.spill.load1531, %7735
  %.spill.load1532 = load <8 x float>, ptr %.spill229, align 32
  %7843 = fsub <8 x float> %.spill.load1532, %7735
  %.spill.load1533 = load <8 x float>, ptr %.spill230, align 32
  %7844 = fsub <8 x float> %.spill.load1533, %7735
  %.spill.load1534 = load <8 x float>, ptr %.spill231, align 32
  %7845 = fsub <8 x float> %.spill.load1534, %7735
  %.spill.load1535 = load <8 x float>, ptr %.spill232, align 32
  %7846 = fsub <8 x float> %.spill.load1535, %7735
  %.spill.load1536 = load <8 x float>, ptr %.spill233, align 32
  %7847 = fsub <8 x float> %.spill.load1536, %7735
  %.spill.load1537 = load <8 x float>, ptr %.spill234, align 32
  %7848 = fsub <8 x float> %.spill.load1537, %7735
  %.spill.load1538 = load <8 x float>, ptr %.spill235, align 32
  %7849 = fsub <8 x float> %.spill.load1538, %7735
  %.spill.load1539 = load <8 x float>, ptr %.spill236, align 32
  %7850 = fsub <8 x float> %.spill.load1539, %7735
  %.spill.load1540 = load <8 x float>, ptr %.spill237, align 32
  %7851 = fsub <8 x float> %.spill.load1540, %7735
  %.spill.load1541 = load <8 x float>, ptr %.spill238, align 32
  %7852 = fsub <8 x float> %.spill.load1541, %7735
  %.spill.load1542 = load <8 x float>, ptr %.spill239, align 32
  %7853 = fsub <8 x float> %.spill.load1542, %7738
  %.spill.load1543 = load <8 x float>, ptr %.spill240, align 32
  %7854 = fsub <8 x float> %.spill.load1543, %7738
  %.spill.load1544 = load <8 x float>, ptr %.spill241, align 32
  %7855 = fsub <8 x float> %.spill.load1544, %7738
  %.spill.load1545 = load <8 x float>, ptr %.spill242, align 32
  %7856 = fsub <8 x float> %.spill.load1545, %7738
  %.spill.load1546 = load <8 x float>, ptr %.spill243, align 32
  %7857 = fsub <8 x float> %.spill.load1546, %7738
  %.spill.load1547 = load <8 x float>, ptr %.spill244, align 32
  %7858 = fsub <8 x float> %.spill.load1547, %7738
  %.spill.load1548 = load <8 x float>, ptr %.spill245, align 32
  %7859 = fsub <8 x float> %.spill.load1548, %7738
  %.spill.load1549 = load <8 x float>, ptr %.spill246, align 32
  %7860 = fsub <8 x float> %.spill.load1549, %7738
  %.spill.load1550 = load <8 x float>, ptr %.spill247, align 32
  %7861 = fsub <8 x float> %.spill.load1550, %7738
  %.spill.load1551 = load <8 x float>, ptr %.spill248, align 32
  %7862 = fsub <8 x float> %.spill.load1551, %7738
  %.spill.load1552 = load <8 x float>, ptr %.spill249, align 32
  %7863 = fsub <8 x float> %.spill.load1552, %7738
  %.spill.load1553 = load <8 x float>, ptr %.spill250, align 32
  %7864 = fsub <8 x float> %.spill.load1553, %7738
  %.spill.load1554 = load <8 x float>, ptr %.spill251, align 32
  %7865 = fsub <8 x float> %.spill.load1554, %7738
  %.spill.load1555 = load <8 x float>, ptr %.spill252, align 32
  %7866 = fsub <8 x float> %.spill.load1555, %7738
  %.spill.load1556 = load <8 x float>, ptr %.spill253, align 32
  %7867 = fsub <8 x float> %.spill.load1556, %7738
  %.spill.load1557 = load <8 x float>, ptr %.spill254, align 32
  %7868 = fsub <8 x float> %.spill.load1557, %7738
  %.spill.load1558 = load <8 x float>, ptr %.spill255, align 32
  %7869 = fsub <8 x float> %.spill.load1558, %7741
  %.spill.load1559 = load <8 x float>, ptr %.spill256, align 32
  %7870 = fsub <8 x float> %.spill.load1559, %7741
  %.spill.load1560 = load <8 x float>, ptr %.spill257, align 32
  %7871 = fsub <8 x float> %.spill.load1560, %7741
  %.spill.load1561 = load <8 x float>, ptr %.spill258, align 32
  %7872 = fsub <8 x float> %.spill.load1561, %7741
  %.spill.load1562 = load <8 x float>, ptr %.spill259, align 32
  %7873 = fsub <8 x float> %.spill.load1562, %7741
  %.spill.load1563 = load <8 x float>, ptr %.spill260, align 32
  %7874 = fsub <8 x float> %.spill.load1563, %7741
  %.spill.load1564 = load <8 x float>, ptr %.spill261, align 32
  %7875 = fsub <8 x float> %.spill.load1564, %7741
  %.spill.load1565 = load <8 x float>, ptr %.spill262, align 32
  %7876 = fsub <8 x float> %.spill.load1565, %7741
  %.spill.load1566 = load <8 x float>, ptr %.spill263, align 32
  %7877 = fsub <8 x float> %.spill.load1566, %7741
  %.spill.load1567 = load <8 x float>, ptr %.spill264, align 32
  %7878 = fsub <8 x float> %.spill.load1567, %7741
  %.spill.load1568 = load <8 x float>, ptr %.spill265, align 32
  %7879 = fsub <8 x float> %.spill.load1568, %7741
  %.spill.load1569 = load <8 x float>, ptr %.spill266, align 32
  %7880 = fsub <8 x float> %.spill.load1569, %7741
  %.spill.load1570 = load <8 x float>, ptr %.spill267, align 32
  %7881 = fsub <8 x float> %.spill.load1570, %7741
  %.spill.load1571 = load <8 x float>, ptr %.spill268, align 32
  %7882 = fsub <8 x float> %.spill.load1571, %7741
  %.spill.load1572 = load <8 x float>, ptr %.spill269, align 32
  %7883 = fsub <8 x float> %.spill.load1572, %7741
  %.spill.load1573 = load <8 x float>, ptr %.spill270, align 32
  %7884 = fsub <8 x float> %.spill.load1573, %7741
  %7885 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7821, <8 x float> zeroinitializer
  %native.exp1574 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7885)
  %7886 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7822, <8 x float> zeroinitializer
  %native.exp1575 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7886)
  %7887 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7823, <8 x float> zeroinitializer
  %native.exp1576 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7887)
  %7888 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7824, <8 x float> zeroinitializer
  %native.exp1577 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7888)
  %7889 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7825, <8 x float> zeroinitializer
  %native.exp1578 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7889)
  %7890 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7826, <8 x float> zeroinitializer
  %native.exp1579 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7890)
  %7891 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7827, <8 x float> zeroinitializer
  %native.exp1580 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7891)
  %7892 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7828, <8 x float> zeroinitializer
  %native.exp1581 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7892)
  %7893 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7829, <8 x float> zeroinitializer
  %native.exp1582 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7893)
  %7894 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7830, <8 x float> zeroinitializer
  %native.exp1583 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7894)
  %7895 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7831, <8 x float> zeroinitializer
  %native.exp1584 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7895)
  %7896 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7832, <8 x float> zeroinitializer
  %native.exp1585 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7896)
  %7897 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7833, <8 x float> zeroinitializer
  %native.exp1586 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7897)
  %7898 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7834, <8 x float> zeroinitializer
  %native.exp1587 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7898)
  %7899 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7835, <8 x float> zeroinitializer
  %native.exp1588 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7899)
  %7900 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7836, <8 x float> zeroinitializer
  %native.exp1589 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7900)
  %7901 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7837, <8 x float> zeroinitializer
  %native.exp1590 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7901)
  %7902 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7838, <8 x float> zeroinitializer
  %native.exp1591 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7902)
  %7903 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7839, <8 x float> zeroinitializer
  %native.exp1592 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7903)
  %7904 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7840, <8 x float> zeroinitializer
  %native.exp1593 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7904)
  %7905 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7841, <8 x float> zeroinitializer
  %native.exp1594 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7905)
  %7906 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7842, <8 x float> zeroinitializer
  %native.exp1595 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7906)
  %7907 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7843, <8 x float> zeroinitializer
  %native.exp1596 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7907)
  %7908 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7844, <8 x float> zeroinitializer
  %native.exp1597 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7908)
  %7909 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7845, <8 x float> zeroinitializer
  %native.exp1598 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7909)
  %7910 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7846, <8 x float> zeroinitializer
  %native.exp1599 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7910)
  %7911 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7847, <8 x float> zeroinitializer
  %native.exp1600 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7911)
  %7912 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7848, <8 x float> zeroinitializer
  %native.exp1601 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7912)
  %7913 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7849, <8 x float> zeroinitializer
  %native.exp1602 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7913)
  %7914 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7850, <8 x float> zeroinitializer
  %native.exp1603 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7914)
  %7915 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7851, <8 x float> zeroinitializer
  %native.exp1604 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7915)
  %7916 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7852, <8 x float> zeroinitializer
  %native.exp1605 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7916)
  %7917 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7853, <8 x float> zeroinitializer
  %native.exp1606 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7917)
  %7918 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7854, <8 x float> zeroinitializer
  %native.exp1607 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7918)
  %7919 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7855, <8 x float> zeroinitializer
  %native.exp1608 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7919)
  %7920 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7856, <8 x float> zeroinitializer
  %native.exp1609 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7920)
  %7921 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7857, <8 x float> zeroinitializer
  %native.exp1610 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7921)
  %7922 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7858, <8 x float> zeroinitializer
  %native.exp1611 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7922)
  %7923 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7859, <8 x float> zeroinitializer
  %native.exp1612 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7923)
  %7924 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7860, <8 x float> zeroinitializer
  %native.exp1613 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7924)
  %7925 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7861, <8 x float> zeroinitializer
  %native.exp1614 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7925)
  %7926 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7862, <8 x float> zeroinitializer
  %native.exp1615 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7926)
  %7927 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7863, <8 x float> zeroinitializer
  %native.exp1616 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7927)
  %7928 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7864, <8 x float> zeroinitializer
  %native.exp1617 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7928)
  %7929 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7865, <8 x float> zeroinitializer
  %native.exp1618 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7929)
  %7930 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7866, <8 x float> zeroinitializer
  %native.exp1619 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7930)
  %7931 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7867, <8 x float> zeroinitializer
  %native.exp1620 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7931)
  %7932 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7868, <8 x float> zeroinitializer
  %native.exp1621 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7932)
  %7933 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7869, <8 x float> zeroinitializer
  %native.exp1622 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7933)
  %7934 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7870, <8 x float> zeroinitializer
  %native.exp1623 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7934)
  %7935 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7871, <8 x float> zeroinitializer
  %native.exp1624 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7935)
  %7936 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7872, <8 x float> zeroinitializer
  %native.exp1625 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7936)
  %7937 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7873, <8 x float> zeroinitializer
  %native.exp1626 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7937)
  %7938 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7874, <8 x float> zeroinitializer
  %native.exp1627 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7938)
  %7939 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7875, <8 x float> zeroinitializer
  %native.exp1628 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7939)
  %7940 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7876, <8 x float> zeroinitializer
  %native.exp1629 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7940)
  %7941 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7877, <8 x float> zeroinitializer
  %native.exp1630 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7941)
  %7942 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7878, <8 x float> zeroinitializer
  %native.exp1631 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7942)
  %7943 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7879, <8 x float> zeroinitializer
  %native.exp1632 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7943)
  %7944 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7880, <8 x float> zeroinitializer
  %native.exp1633 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7944)
  %7945 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7881, <8 x float> zeroinitializer
  %native.exp1634 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7945)
  %7946 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7882, <8 x float> zeroinitializer
  %native.exp1635 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7946)
  %7947 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7883, <8 x float> zeroinitializer
  %native.exp1636 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7947)
  %7948 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7884, <8 x float> zeroinitializer
  %native.exp1637 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7948)
  %.spill.load1638 = load <8 x i1>, ptr %.spill143, align 1
  %7949 = select <8 x i1> %.spill.load1638, <8 x float> %native.exp1574, <8 x float> zeroinitializer
  %.spill.load1639 = load <8 x i1>, ptr %.spill147, align 1
  %7950 = select <8 x i1> %.spill.load1639, <8 x float> %native.exp1575, <8 x float> zeroinitializer
  %.spill.load1640 = load <8 x i1>, ptr %.spill151, align 1
  %7951 = select <8 x i1> %.spill.load1640, <8 x float> %native.exp1576, <8 x float> zeroinitializer
  %.spill.load1641 = load <8 x i1>, ptr %.spill155, align 1
  %7952 = select <8 x i1> %.spill.load1641, <8 x float> %native.exp1577, <8 x float> zeroinitializer
  %.spill.load1642 = load <8 x i1>, ptr %.spill159, align 1
  %7953 = select <8 x i1> %.spill.load1642, <8 x float> %native.exp1578, <8 x float> zeroinitializer
  %.spill.load1643 = load <8 x i1>, ptr %.spill163, align 1
  %7954 = select <8 x i1> %.spill.load1643, <8 x float> %native.exp1579, <8 x float> zeroinitializer
  %.spill.load1644 = load <8 x i1>, ptr %.spill167, align 1
  %7955 = select <8 x i1> %.spill.load1644, <8 x float> %native.exp1580, <8 x float> zeroinitializer
  %.spill.load1645 = load <8 x i1>, ptr %.spill171, align 1
  %7956 = select <8 x i1> %.spill.load1645, <8 x float> %native.exp1581, <8 x float> zeroinitializer
  %.spill.load1646 = load <8 x i1>, ptr %.spill175, align 1
  %7957 = select <8 x i1> %.spill.load1646, <8 x float> %native.exp1582, <8 x float> zeroinitializer
  %.spill.load1647 = load <8 x i1>, ptr %.spill179, align 1
  %7958 = select <8 x i1> %.spill.load1647, <8 x float> %native.exp1583, <8 x float> zeroinitializer
  %.spill.load1648 = load <8 x i1>, ptr %.spill183, align 1
  %7959 = select <8 x i1> %.spill.load1648, <8 x float> %native.exp1584, <8 x float> zeroinitializer
  %.spill.load1649 = load <8 x i1>, ptr %.spill187, align 1
  %7960 = select <8 x i1> %.spill.load1649, <8 x float> %native.exp1585, <8 x float> zeroinitializer
  %.spill.load1650 = load <8 x i1>, ptr %.spill191, align 1
  %7961 = select <8 x i1> %.spill.load1650, <8 x float> %native.exp1586, <8 x float> zeroinitializer
  %.spill.load1651 = load <8 x i1>, ptr %.spill195, align 1
  %7962 = select <8 x i1> %.spill.load1651, <8 x float> %native.exp1587, <8 x float> zeroinitializer
  %.spill.load1652 = load <8 x i1>, ptr %.spill199, align 1
  %7963 = select <8 x i1> %.spill.load1652, <8 x float> %native.exp1588, <8 x float> zeroinitializer
  %.spill.load1653 = load <8 x i1>, ptr %.spill203, align 1
  %7964 = select <8 x i1> %.spill.load1653, <8 x float> %native.exp1589, <8 x float> zeroinitializer
  %.spill.load1654 = load <8 x i1>, ptr %.spill144, align 1
  %7965 = select <8 x i1> %.spill.load1654, <8 x float> %native.exp1590, <8 x float> zeroinitializer
  %.spill.load1655 = load <8 x i1>, ptr %.spill148, align 1
  %7966 = select <8 x i1> %.spill.load1655, <8 x float> %native.exp1591, <8 x float> zeroinitializer
  %.spill.load1656 = load <8 x i1>, ptr %.spill152, align 1
  %7967 = select <8 x i1> %.spill.load1656, <8 x float> %native.exp1592, <8 x float> zeroinitializer
  %.spill.load1657 = load <8 x i1>, ptr %.spill156, align 1
  %7968 = select <8 x i1> %.spill.load1657, <8 x float> %native.exp1593, <8 x float> zeroinitializer
  %.spill.load1658 = load <8 x i1>, ptr %.spill160, align 1
  %7969 = select <8 x i1> %.spill.load1658, <8 x float> %native.exp1594, <8 x float> zeroinitializer
  %.spill.load1659 = load <8 x i1>, ptr %.spill164, align 1
  %7970 = select <8 x i1> %.spill.load1659, <8 x float> %native.exp1595, <8 x float> zeroinitializer
  %.spill.load1660 = load <8 x i1>, ptr %.spill168, align 1
  %7971 = select <8 x i1> %.spill.load1660, <8 x float> %native.exp1596, <8 x float> zeroinitializer
  %.spill.load1661 = load <8 x i1>, ptr %.spill172, align 1
  %7972 = select <8 x i1> %.spill.load1661, <8 x float> %native.exp1597, <8 x float> zeroinitializer
  %.spill.load1662 = load <8 x i1>, ptr %.spill176, align 1
  %7973 = select <8 x i1> %.spill.load1662, <8 x float> %native.exp1598, <8 x float> zeroinitializer
  %.spill.load1663 = load <8 x i1>, ptr %.spill180, align 1
  %7974 = select <8 x i1> %.spill.load1663, <8 x float> %native.exp1599, <8 x float> zeroinitializer
  %.spill.load1664 = load <8 x i1>, ptr %.spill184, align 1
  %7975 = select <8 x i1> %.spill.load1664, <8 x float> %native.exp1600, <8 x float> zeroinitializer
  %.spill.load1665 = load <8 x i1>, ptr %.spill188, align 1
  %7976 = select <8 x i1> %.spill.load1665, <8 x float> %native.exp1601, <8 x float> zeroinitializer
  %.spill.load1666 = load <8 x i1>, ptr %.spill192, align 1
  %7977 = select <8 x i1> %.spill.load1666, <8 x float> %native.exp1602, <8 x float> zeroinitializer
  %.spill.load1667 = load <8 x i1>, ptr %.spill196, align 1
  %7978 = select <8 x i1> %.spill.load1667, <8 x float> %native.exp1603, <8 x float> zeroinitializer
  %.spill.load1668 = load <8 x i1>, ptr %.spill200, align 1
  %7979 = select <8 x i1> %.spill.load1668, <8 x float> %native.exp1604, <8 x float> zeroinitializer
  %.spill.load1669 = load <8 x i1>, ptr %.spill204, align 1
  %7980 = select <8 x i1> %.spill.load1669, <8 x float> %native.exp1605, <8 x float> zeroinitializer
  %.spill.load1670 = load <8 x i1>, ptr %.spill145, align 1
  %7981 = select <8 x i1> %.spill.load1670, <8 x float> %native.exp1606, <8 x float> zeroinitializer
  %.spill.load1671 = load <8 x i1>, ptr %.spill149, align 1
  %7982 = select <8 x i1> %.spill.load1671, <8 x float> %native.exp1607, <8 x float> zeroinitializer
  %.spill.load1672 = load <8 x i1>, ptr %.spill153, align 1
  %7983 = select <8 x i1> %.spill.load1672, <8 x float> %native.exp1608, <8 x float> zeroinitializer
  %.spill.load1673 = load <8 x i1>, ptr %.spill157, align 1
  %7984 = select <8 x i1> %.spill.load1673, <8 x float> %native.exp1609, <8 x float> zeroinitializer
  %.spill.load1674 = load <8 x i1>, ptr %.spill161, align 1
  %7985 = select <8 x i1> %.spill.load1674, <8 x float> %native.exp1610, <8 x float> zeroinitializer
  %.spill.load1675 = load <8 x i1>, ptr %.spill165, align 1
  %7986 = select <8 x i1> %.spill.load1675, <8 x float> %native.exp1611, <8 x float> zeroinitializer
  %.spill.load1676 = load <8 x i1>, ptr %.spill169, align 1
  %7987 = select <8 x i1> %.spill.load1676, <8 x float> %native.exp1612, <8 x float> zeroinitializer
  %.spill.load1677 = load <8 x i1>, ptr %.spill173, align 1
  %7988 = select <8 x i1> %.spill.load1677, <8 x float> %native.exp1613, <8 x float> zeroinitializer
  %.spill.load1678 = load <8 x i1>, ptr %.spill177, align 1
  %7989 = select <8 x i1> %.spill.load1678, <8 x float> %native.exp1614, <8 x float> zeroinitializer
  %.spill.load1679 = load <8 x i1>, ptr %.spill181, align 1
  %7990 = select <8 x i1> %.spill.load1679, <8 x float> %native.exp1615, <8 x float> zeroinitializer
  %.spill.load1680 = load <8 x i1>, ptr %.spill185, align 1
  %7991 = select <8 x i1> %.spill.load1680, <8 x float> %native.exp1616, <8 x float> zeroinitializer
  %.spill.load1681 = load <8 x i1>, ptr %.spill189, align 1
  %7992 = select <8 x i1> %.spill.load1681, <8 x float> %native.exp1617, <8 x float> zeroinitializer
  %.spill.load1682 = load <8 x i1>, ptr %.spill193, align 1
  %7993 = select <8 x i1> %.spill.load1682, <8 x float> %native.exp1618, <8 x float> zeroinitializer
  %.spill.load1683 = load <8 x i1>, ptr %.spill197, align 1
  %7994 = select <8 x i1> %.spill.load1683, <8 x float> %native.exp1619, <8 x float> zeroinitializer
  %.spill.load1684 = load <8 x i1>, ptr %.spill201, align 1
  %7995 = select <8 x i1> %.spill.load1684, <8 x float> %native.exp1620, <8 x float> zeroinitializer
  %.spill.load1685 = load <8 x i1>, ptr %.spill205, align 1
  %7996 = select <8 x i1> %.spill.load1685, <8 x float> %native.exp1621, <8 x float> zeroinitializer
  %.spill.load1686 = load <8 x i1>, ptr %.spill146, align 1
  %7997 = select <8 x i1> %.spill.load1686, <8 x float> %native.exp1622, <8 x float> zeroinitializer
  %.spill.load1687 = load <8 x i1>, ptr %.spill150, align 1
  %7998 = select <8 x i1> %.spill.load1687, <8 x float> %native.exp1623, <8 x float> zeroinitializer
  %.spill.load1688 = load <8 x i1>, ptr %.spill154, align 1
  %7999 = select <8 x i1> %.spill.load1688, <8 x float> %native.exp1624, <8 x float> zeroinitializer
  %.spill.load1689 = load <8 x i1>, ptr %.spill158, align 1
  %8000 = select <8 x i1> %.spill.load1689, <8 x float> %native.exp1625, <8 x float> zeroinitializer
  %.spill.load1690 = load <8 x i1>, ptr %.spill162, align 1
  %8001 = select <8 x i1> %.spill.load1690, <8 x float> %native.exp1626, <8 x float> zeroinitializer
  %.spill.load1691 = load <8 x i1>, ptr %.spill166, align 1
  %8002 = select <8 x i1> %.spill.load1691, <8 x float> %native.exp1627, <8 x float> zeroinitializer
  %.spill.load1692 = load <8 x i1>, ptr %.spill170, align 1
  %8003 = select <8 x i1> %.spill.load1692, <8 x float> %native.exp1628, <8 x float> zeroinitializer
  %.spill.load1693 = load <8 x i1>, ptr %.spill174, align 1
  %8004 = select <8 x i1> %.spill.load1693, <8 x float> %native.exp1629, <8 x float> zeroinitializer
  %.spill.load1694 = load <8 x i1>, ptr %.spill178, align 1
  %8005 = select <8 x i1> %.spill.load1694, <8 x float> %native.exp1630, <8 x float> zeroinitializer
  %.spill.load1695 = load <8 x i1>, ptr %.spill182, align 1
  %8006 = select <8 x i1> %.spill.load1695, <8 x float> %native.exp1631, <8 x float> zeroinitializer
  %.spill.load1696 = load <8 x i1>, ptr %.spill186, align 1
  %8007 = select <8 x i1> %.spill.load1696, <8 x float> %native.exp1632, <8 x float> zeroinitializer
  %.spill.load1697 = load <8 x i1>, ptr %.spill190, align 1
  %8008 = select <8 x i1> %.spill.load1697, <8 x float> %native.exp1633, <8 x float> zeroinitializer
  %.spill.load1698 = load <8 x i1>, ptr %.spill194, align 1
  %8009 = select <8 x i1> %.spill.load1698, <8 x float> %native.exp1634, <8 x float> zeroinitializer
  %.spill.load1699 = load <8 x i1>, ptr %.spill198, align 1
  %8010 = select <8 x i1> %.spill.load1699, <8 x float> %native.exp1635, <8 x float> zeroinitializer
  %.spill.load1700 = load <8 x i1>, ptr %.spill202, align 1
  %8011 = select <8 x i1> %.spill.load1700, <8 x float> %native.exp1636, <8 x float> zeroinitializer
  %.spill.load1701 = load <8 x i1>, ptr %.spill206, align 1
  %8012 = select <8 x i1> %.spill.load1701, <8 x float> %native.exp1637, <8 x float> zeroinitializer
  %8013 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill285, align 64
  %8014 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8015 = extractvalue { <8 x ptr>, <8 x i64> } %8013, 0
  %8016 = select <8 x i1> %convergence.cascade.result1486, <8 x ptr> %8014, <8 x ptr> %8015
  %8017 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8018 = extractvalue { <8 x ptr>, <8 x i64> } %8013, 1
  %8019 = select <8 x i1> %convergence.cascade.result1486, <8 x i64> %8017, <8 x i64> %8018
  %8020 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8016, 0
  %8021 = insertvalue { <8 x ptr>, <8 x i64> } %8020, <8 x i64> %8019, 1
  store { <8 x ptr>, <8 x i64> } %8021, ptr %tile_snapshot.spill285, align 64
  %8022 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8023 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8024 = add <8 x i64> %8023, zeroinitializer
  %8025 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8022, 0
  %8026 = insertvalue { <8 x ptr>, <8 x i64> } %8025, <8 x i64> %8024, 1
  %8027 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8028 = extractvalue { <8 x ptr>, <8 x i64> } %8026, 1
  %8029 = extractelement <8 x ptr> %8027, i32 0
  %8030 = extractelement <8 x i64> %8028, i32 %7731
  %8031 = zext i32 %7731 to i64
  %8032 = mul i64 %8031, 4
  %8033 = sub i64 %8030, %8032
  %8034 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8035 = select i1 %8034, i64 %8033, i64 0
  %private.contiguous.address1702 = getelementptr i8, ptr %8029, i64 %8035
  %private.contiguous.preserve1703 = load <8 x float>, ptr %private.contiguous.address1702, align 4
  %8036 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7949, <8 x float> %private.contiguous.preserve1703
  store <8 x float> %8036, ptr %private.contiguous.address1702, align 4
  %8037 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8038 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8039 = add <8 x i64> %8038, splat (i64 32)
  %8040 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8037, 0
  %8041 = insertvalue { <8 x ptr>, <8 x i64> } %8040, <8 x i64> %8039, 1
  %8042 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8043 = extractvalue { <8 x ptr>, <8 x i64> } %8041, 1
  %8044 = extractelement <8 x ptr> %8042, i32 0
  %8045 = extractelement <8 x i64> %8043, i32 %7731
  %8046 = zext i32 %7731 to i64
  %8047 = mul i64 %8046, 4
  %8048 = sub i64 %8045, %8047
  %8049 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8050 = select i1 %8049, i64 %8048, i64 0
  %private.contiguous.address1704 = getelementptr i8, ptr %8044, i64 %8050
  %private.contiguous.preserve1705 = load <8 x float>, ptr %private.contiguous.address1704, align 4
  %8051 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7950, <8 x float> %private.contiguous.preserve1705
  store <8 x float> %8051, ptr %private.contiguous.address1704, align 4
  %8052 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8053 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8054 = add <8 x i64> %8053, splat (i64 64)
  %8055 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8052, 0
  %8056 = insertvalue { <8 x ptr>, <8 x i64> } %8055, <8 x i64> %8054, 1
  %8057 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8058 = extractvalue { <8 x ptr>, <8 x i64> } %8056, 1
  %8059 = extractelement <8 x ptr> %8057, i32 0
  %8060 = extractelement <8 x i64> %8058, i32 %7731
  %8061 = zext i32 %7731 to i64
  %8062 = mul i64 %8061, 4
  %8063 = sub i64 %8060, %8062
  %8064 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8065 = select i1 %8064, i64 %8063, i64 0
  %private.contiguous.address1706 = getelementptr i8, ptr %8059, i64 %8065
  %private.contiguous.preserve1707 = load <8 x float>, ptr %private.contiguous.address1706, align 4
  %8066 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7951, <8 x float> %private.contiguous.preserve1707
  store <8 x float> %8066, ptr %private.contiguous.address1706, align 4
  %8067 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8068 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8069 = add <8 x i64> %8068, splat (i64 96)
  %8070 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8067, 0
  %8071 = insertvalue { <8 x ptr>, <8 x i64> } %8070, <8 x i64> %8069, 1
  %8072 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8073 = extractvalue { <8 x ptr>, <8 x i64> } %8071, 1
  %8074 = extractelement <8 x ptr> %8072, i32 0
  %8075 = extractelement <8 x i64> %8073, i32 %7731
  %8076 = zext i32 %7731 to i64
  %8077 = mul i64 %8076, 4
  %8078 = sub i64 %8075, %8077
  %8079 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8080 = select i1 %8079, i64 %8078, i64 0
  %private.contiguous.address1708 = getelementptr i8, ptr %8074, i64 %8080
  %private.contiguous.preserve1709 = load <8 x float>, ptr %private.contiguous.address1708, align 4
  %8081 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7952, <8 x float> %private.contiguous.preserve1709
  store <8 x float> %8081, ptr %private.contiguous.address1708, align 4
  %8082 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8083 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8084 = add <8 x i64> %8083, splat (i64 128)
  %8085 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8082, 0
  %8086 = insertvalue { <8 x ptr>, <8 x i64> } %8085, <8 x i64> %8084, 1
  %8087 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8088 = extractvalue { <8 x ptr>, <8 x i64> } %8086, 1
  %8089 = extractelement <8 x ptr> %8087, i32 0
  %8090 = extractelement <8 x i64> %8088, i32 %7731
  %8091 = zext i32 %7731 to i64
  %8092 = mul i64 %8091, 4
  %8093 = sub i64 %8090, %8092
  %8094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8095 = select i1 %8094, i64 %8093, i64 0
  %private.contiguous.address1710 = getelementptr i8, ptr %8089, i64 %8095
  %private.contiguous.preserve1711 = load <8 x float>, ptr %private.contiguous.address1710, align 4
  %8096 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7953, <8 x float> %private.contiguous.preserve1711
  store <8 x float> %8096, ptr %private.contiguous.address1710, align 4
  %8097 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8098 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8099 = add <8 x i64> %8098, splat (i64 160)
  %8100 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8097, 0
  %8101 = insertvalue { <8 x ptr>, <8 x i64> } %8100, <8 x i64> %8099, 1
  %8102 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8103 = extractvalue { <8 x ptr>, <8 x i64> } %8101, 1
  %8104 = extractelement <8 x ptr> %8102, i32 0
  %8105 = extractelement <8 x i64> %8103, i32 %7731
  %8106 = zext i32 %7731 to i64
  %8107 = mul i64 %8106, 4
  %8108 = sub i64 %8105, %8107
  %8109 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8110 = select i1 %8109, i64 %8108, i64 0
  %private.contiguous.address1712 = getelementptr i8, ptr %8104, i64 %8110
  %private.contiguous.preserve1713 = load <8 x float>, ptr %private.contiguous.address1712, align 4
  %8111 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7954, <8 x float> %private.contiguous.preserve1713
  store <8 x float> %8111, ptr %private.contiguous.address1712, align 4
  %8112 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8113 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8114 = add <8 x i64> %8113, splat (i64 192)
  %8115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8112, 0
  %8116 = insertvalue { <8 x ptr>, <8 x i64> } %8115, <8 x i64> %8114, 1
  %8117 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8118 = extractvalue { <8 x ptr>, <8 x i64> } %8116, 1
  %8119 = extractelement <8 x ptr> %8117, i32 0
  %8120 = extractelement <8 x i64> %8118, i32 %7731
  %8121 = zext i32 %7731 to i64
  %8122 = mul i64 %8121, 4
  %8123 = sub i64 %8120, %8122
  %8124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8125 = select i1 %8124, i64 %8123, i64 0
  %private.contiguous.address1714 = getelementptr i8, ptr %8119, i64 %8125
  %private.contiguous.preserve1715 = load <8 x float>, ptr %private.contiguous.address1714, align 4
  %8126 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7955, <8 x float> %private.contiguous.preserve1715
  store <8 x float> %8126, ptr %private.contiguous.address1714, align 4
  %8127 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8128 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8129 = add <8 x i64> %8128, splat (i64 224)
  %8130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8127, 0
  %8131 = insertvalue { <8 x ptr>, <8 x i64> } %8130, <8 x i64> %8129, 1
  %8132 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8133 = extractvalue { <8 x ptr>, <8 x i64> } %8131, 1
  %8134 = extractelement <8 x ptr> %8132, i32 0
  %8135 = extractelement <8 x i64> %8133, i32 %7731
  %8136 = zext i32 %7731 to i64
  %8137 = mul i64 %8136, 4
  %8138 = sub i64 %8135, %8137
  %8139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8140 = select i1 %8139, i64 %8138, i64 0
  %private.contiguous.address1716 = getelementptr i8, ptr %8134, i64 %8140
  %private.contiguous.preserve1717 = load <8 x float>, ptr %private.contiguous.address1716, align 4
  %8141 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7956, <8 x float> %private.contiguous.preserve1717
  store <8 x float> %8141, ptr %private.contiguous.address1716, align 4
  %8142 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8143 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8144 = add <8 x i64> %8143, splat (i64 256)
  %8145 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8142, 0
  %8146 = insertvalue { <8 x ptr>, <8 x i64> } %8145, <8 x i64> %8144, 1
  %8147 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8148 = extractvalue { <8 x ptr>, <8 x i64> } %8146, 1
  %8149 = extractelement <8 x ptr> %8147, i32 0
  %8150 = extractelement <8 x i64> %8148, i32 %7731
  %8151 = zext i32 %7731 to i64
  %8152 = mul i64 %8151, 4
  %8153 = sub i64 %8150, %8152
  %8154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8155 = select i1 %8154, i64 %8153, i64 0
  %private.contiguous.address1718 = getelementptr i8, ptr %8149, i64 %8155
  %private.contiguous.preserve1719 = load <8 x float>, ptr %private.contiguous.address1718, align 4
  %8156 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7957, <8 x float> %private.contiguous.preserve1719
  store <8 x float> %8156, ptr %private.contiguous.address1718, align 4
  %8157 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8158 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8159 = add <8 x i64> %8158, splat (i64 288)
  %8160 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8157, 0
  %8161 = insertvalue { <8 x ptr>, <8 x i64> } %8160, <8 x i64> %8159, 1
  %8162 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8163 = extractvalue { <8 x ptr>, <8 x i64> } %8161, 1
  %8164 = extractelement <8 x ptr> %8162, i32 0
  %8165 = extractelement <8 x i64> %8163, i32 %7731
  %8166 = zext i32 %7731 to i64
  %8167 = mul i64 %8166, 4
  %8168 = sub i64 %8165, %8167
  %8169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8170 = select i1 %8169, i64 %8168, i64 0
  %private.contiguous.address1720 = getelementptr i8, ptr %8164, i64 %8170
  %private.contiguous.preserve1721 = load <8 x float>, ptr %private.contiguous.address1720, align 4
  %8171 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7958, <8 x float> %private.contiguous.preserve1721
  store <8 x float> %8171, ptr %private.contiguous.address1720, align 4
  %8172 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8173 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8174 = add <8 x i64> %8173, splat (i64 320)
  %8175 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8172, 0
  %8176 = insertvalue { <8 x ptr>, <8 x i64> } %8175, <8 x i64> %8174, 1
  %8177 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8178 = extractvalue { <8 x ptr>, <8 x i64> } %8176, 1
  %8179 = extractelement <8 x ptr> %8177, i32 0
  %8180 = extractelement <8 x i64> %8178, i32 %7731
  %8181 = zext i32 %7731 to i64
  %8182 = mul i64 %8181, 4
  %8183 = sub i64 %8180, %8182
  %8184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8185 = select i1 %8184, i64 %8183, i64 0
  %private.contiguous.address1722 = getelementptr i8, ptr %8179, i64 %8185
  %private.contiguous.preserve1723 = load <8 x float>, ptr %private.contiguous.address1722, align 4
  %8186 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7959, <8 x float> %private.contiguous.preserve1723
  store <8 x float> %8186, ptr %private.contiguous.address1722, align 4
  %8187 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8188 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8189 = add <8 x i64> %8188, splat (i64 352)
  %8190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8187, 0
  %8191 = insertvalue { <8 x ptr>, <8 x i64> } %8190, <8 x i64> %8189, 1
  %8192 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8193 = extractvalue { <8 x ptr>, <8 x i64> } %8191, 1
  %8194 = extractelement <8 x ptr> %8192, i32 0
  %8195 = extractelement <8 x i64> %8193, i32 %7731
  %8196 = zext i32 %7731 to i64
  %8197 = mul i64 %8196, 4
  %8198 = sub i64 %8195, %8197
  %8199 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8200 = select i1 %8199, i64 %8198, i64 0
  %private.contiguous.address1724 = getelementptr i8, ptr %8194, i64 %8200
  %private.contiguous.preserve1725 = load <8 x float>, ptr %private.contiguous.address1724, align 4
  %8201 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7960, <8 x float> %private.contiguous.preserve1725
  store <8 x float> %8201, ptr %private.contiguous.address1724, align 4
  %8202 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8203 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8204 = add <8 x i64> %8203, splat (i64 384)
  %8205 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8202, 0
  %8206 = insertvalue { <8 x ptr>, <8 x i64> } %8205, <8 x i64> %8204, 1
  %8207 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8208 = extractvalue { <8 x ptr>, <8 x i64> } %8206, 1
  %8209 = extractelement <8 x ptr> %8207, i32 0
  %8210 = extractelement <8 x i64> %8208, i32 %7731
  %8211 = zext i32 %7731 to i64
  %8212 = mul i64 %8211, 4
  %8213 = sub i64 %8210, %8212
  %8214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8215 = select i1 %8214, i64 %8213, i64 0
  %private.contiguous.address1726 = getelementptr i8, ptr %8209, i64 %8215
  %private.contiguous.preserve1727 = load <8 x float>, ptr %private.contiguous.address1726, align 4
  %8216 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7961, <8 x float> %private.contiguous.preserve1727
  store <8 x float> %8216, ptr %private.contiguous.address1726, align 4
  %8217 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8218 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8219 = add <8 x i64> %8218, splat (i64 416)
  %8220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8217, 0
  %8221 = insertvalue { <8 x ptr>, <8 x i64> } %8220, <8 x i64> %8219, 1
  %8222 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8223 = extractvalue { <8 x ptr>, <8 x i64> } %8221, 1
  %8224 = extractelement <8 x ptr> %8222, i32 0
  %8225 = extractelement <8 x i64> %8223, i32 %7731
  %8226 = zext i32 %7731 to i64
  %8227 = mul i64 %8226, 4
  %8228 = sub i64 %8225, %8227
  %8229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8230 = select i1 %8229, i64 %8228, i64 0
  %private.contiguous.address1728 = getelementptr i8, ptr %8224, i64 %8230
  %private.contiguous.preserve1729 = load <8 x float>, ptr %private.contiguous.address1728, align 4
  %8231 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7962, <8 x float> %private.contiguous.preserve1729
  store <8 x float> %8231, ptr %private.contiguous.address1728, align 4
  %8232 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8233 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8234 = add <8 x i64> %8233, splat (i64 448)
  %8235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8232, 0
  %8236 = insertvalue { <8 x ptr>, <8 x i64> } %8235, <8 x i64> %8234, 1
  %8237 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8238 = extractvalue { <8 x ptr>, <8 x i64> } %8236, 1
  %8239 = extractelement <8 x ptr> %8237, i32 0
  %8240 = extractelement <8 x i64> %8238, i32 %7731
  %8241 = zext i32 %7731 to i64
  %8242 = mul i64 %8241, 4
  %8243 = sub i64 %8240, %8242
  %8244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8245 = select i1 %8244, i64 %8243, i64 0
  %private.contiguous.address1730 = getelementptr i8, ptr %8239, i64 %8245
  %private.contiguous.preserve1731 = load <8 x float>, ptr %private.contiguous.address1730, align 4
  %8246 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7963, <8 x float> %private.contiguous.preserve1731
  store <8 x float> %8246, ptr %private.contiguous.address1730, align 4
  %8247 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8248 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8249 = add <8 x i64> %8248, splat (i64 480)
  %8250 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8247, 0
  %8251 = insertvalue { <8 x ptr>, <8 x i64> } %8250, <8 x i64> %8249, 1
  %8252 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8253 = extractvalue { <8 x ptr>, <8 x i64> } %8251, 1
  %8254 = extractelement <8 x ptr> %8252, i32 0
  %8255 = extractelement <8 x i64> %8253, i32 %7731
  %8256 = zext i32 %7731 to i64
  %8257 = mul i64 %8256, 4
  %8258 = sub i64 %8255, %8257
  %8259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8260 = select i1 %8259, i64 %8258, i64 0
  %private.contiguous.address1732 = getelementptr i8, ptr %8254, i64 %8260
  %private.contiguous.preserve1733 = load <8 x float>, ptr %private.contiguous.address1732, align 4
  %8261 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7964, <8 x float> %private.contiguous.preserve1733
  store <8 x float> %8261, ptr %private.contiguous.address1732, align 4
  %8262 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8263 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8264 = add <8 x i64> %8263, splat (i64 512)
  %8265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8262, 0
  %8266 = insertvalue { <8 x ptr>, <8 x i64> } %8265, <8 x i64> %8264, 1
  %8267 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8268 = extractvalue { <8 x ptr>, <8 x i64> } %8266, 1
  %8269 = extractelement <8 x ptr> %8267, i32 0
  %8270 = extractelement <8 x i64> %8268, i32 %7731
  %8271 = zext i32 %7731 to i64
  %8272 = mul i64 %8271, 4
  %8273 = sub i64 %8270, %8272
  %8274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8275 = select i1 %8274, i64 %8273, i64 0
  %private.contiguous.address1734 = getelementptr i8, ptr %8269, i64 %8275
  %private.contiguous.preserve1735 = load <8 x float>, ptr %private.contiguous.address1734, align 4
  %8276 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7965, <8 x float> %private.contiguous.preserve1735
  store <8 x float> %8276, ptr %private.contiguous.address1734, align 4
  %8277 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8278 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8279 = add <8 x i64> %8278, splat (i64 544)
  %8280 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8277, 0
  %8281 = insertvalue { <8 x ptr>, <8 x i64> } %8280, <8 x i64> %8279, 1
  %8282 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8283 = extractvalue { <8 x ptr>, <8 x i64> } %8281, 1
  %8284 = extractelement <8 x ptr> %8282, i32 0
  %8285 = extractelement <8 x i64> %8283, i32 %7731
  %8286 = zext i32 %7731 to i64
  %8287 = mul i64 %8286, 4
  %8288 = sub i64 %8285, %8287
  %8289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8290 = select i1 %8289, i64 %8288, i64 0
  %private.contiguous.address1736 = getelementptr i8, ptr %8284, i64 %8290
  %private.contiguous.preserve1737 = load <8 x float>, ptr %private.contiguous.address1736, align 4
  %8291 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7966, <8 x float> %private.contiguous.preserve1737
  store <8 x float> %8291, ptr %private.contiguous.address1736, align 4
  %8292 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8293 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8294 = add <8 x i64> %8293, splat (i64 576)
  %8295 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8292, 0
  %8296 = insertvalue { <8 x ptr>, <8 x i64> } %8295, <8 x i64> %8294, 1
  %8297 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8298 = extractvalue { <8 x ptr>, <8 x i64> } %8296, 1
  %8299 = extractelement <8 x ptr> %8297, i32 0
  %8300 = extractelement <8 x i64> %8298, i32 %7731
  %8301 = zext i32 %7731 to i64
  %8302 = mul i64 %8301, 4
  %8303 = sub i64 %8300, %8302
  %8304 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8305 = select i1 %8304, i64 %8303, i64 0
  %private.contiguous.address1738 = getelementptr i8, ptr %8299, i64 %8305
  %private.contiguous.preserve1739 = load <8 x float>, ptr %private.contiguous.address1738, align 4
  %8306 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7967, <8 x float> %private.contiguous.preserve1739
  store <8 x float> %8306, ptr %private.contiguous.address1738, align 4
  %8307 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8308 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8309 = add <8 x i64> %8308, splat (i64 608)
  %8310 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8307, 0
  %8311 = insertvalue { <8 x ptr>, <8 x i64> } %8310, <8 x i64> %8309, 1
  %8312 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8313 = extractvalue { <8 x ptr>, <8 x i64> } %8311, 1
  %8314 = extractelement <8 x ptr> %8312, i32 0
  %8315 = extractelement <8 x i64> %8313, i32 %7731
  %8316 = zext i32 %7731 to i64
  %8317 = mul i64 %8316, 4
  %8318 = sub i64 %8315, %8317
  %8319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8320 = select i1 %8319, i64 %8318, i64 0
  %private.contiguous.address1740 = getelementptr i8, ptr %8314, i64 %8320
  %private.contiguous.preserve1741 = load <8 x float>, ptr %private.contiguous.address1740, align 4
  %8321 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7968, <8 x float> %private.contiguous.preserve1741
  store <8 x float> %8321, ptr %private.contiguous.address1740, align 4
  %8322 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8323 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8324 = add <8 x i64> %8323, splat (i64 640)
  %8325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8322, 0
  %8326 = insertvalue { <8 x ptr>, <8 x i64> } %8325, <8 x i64> %8324, 1
  %8327 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8328 = extractvalue { <8 x ptr>, <8 x i64> } %8326, 1
  %8329 = extractelement <8 x ptr> %8327, i32 0
  %8330 = extractelement <8 x i64> %8328, i32 %7731
  %8331 = zext i32 %7731 to i64
  %8332 = mul i64 %8331, 4
  %8333 = sub i64 %8330, %8332
  %8334 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8335 = select i1 %8334, i64 %8333, i64 0
  %private.contiguous.address1742 = getelementptr i8, ptr %8329, i64 %8335
  %private.contiguous.preserve1743 = load <8 x float>, ptr %private.contiguous.address1742, align 4
  %8336 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7969, <8 x float> %private.contiguous.preserve1743
  store <8 x float> %8336, ptr %private.contiguous.address1742, align 4
  %8337 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8338 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8339 = add <8 x i64> %8338, splat (i64 672)
  %8340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8337, 0
  %8341 = insertvalue { <8 x ptr>, <8 x i64> } %8340, <8 x i64> %8339, 1
  %8342 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8343 = extractvalue { <8 x ptr>, <8 x i64> } %8341, 1
  %8344 = extractelement <8 x ptr> %8342, i32 0
  %8345 = extractelement <8 x i64> %8343, i32 %7731
  %8346 = zext i32 %7731 to i64
  %8347 = mul i64 %8346, 4
  %8348 = sub i64 %8345, %8347
  %8349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8350 = select i1 %8349, i64 %8348, i64 0
  %private.contiguous.address1744 = getelementptr i8, ptr %8344, i64 %8350
  %private.contiguous.preserve1745 = load <8 x float>, ptr %private.contiguous.address1744, align 4
  %8351 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7970, <8 x float> %private.contiguous.preserve1745
  store <8 x float> %8351, ptr %private.contiguous.address1744, align 4
  %8352 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8353 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8354 = add <8 x i64> %8353, splat (i64 704)
  %8355 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8352, 0
  %8356 = insertvalue { <8 x ptr>, <8 x i64> } %8355, <8 x i64> %8354, 1
  %8357 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8358 = extractvalue { <8 x ptr>, <8 x i64> } %8356, 1
  %8359 = extractelement <8 x ptr> %8357, i32 0
  %8360 = extractelement <8 x i64> %8358, i32 %7731
  %8361 = zext i32 %7731 to i64
  %8362 = mul i64 %8361, 4
  %8363 = sub i64 %8360, %8362
  %8364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8365 = select i1 %8364, i64 %8363, i64 0
  %private.contiguous.address1746 = getelementptr i8, ptr %8359, i64 %8365
  %private.contiguous.preserve1747 = load <8 x float>, ptr %private.contiguous.address1746, align 4
  %8366 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7971, <8 x float> %private.contiguous.preserve1747
  store <8 x float> %8366, ptr %private.contiguous.address1746, align 4
  %8367 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8368 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8369 = add <8 x i64> %8368, splat (i64 736)
  %8370 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8367, 0
  %8371 = insertvalue { <8 x ptr>, <8 x i64> } %8370, <8 x i64> %8369, 1
  %8372 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8373 = extractvalue { <8 x ptr>, <8 x i64> } %8371, 1
  %8374 = extractelement <8 x ptr> %8372, i32 0
  %8375 = extractelement <8 x i64> %8373, i32 %7731
  %8376 = zext i32 %7731 to i64
  %8377 = mul i64 %8376, 4
  %8378 = sub i64 %8375, %8377
  %8379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8380 = select i1 %8379, i64 %8378, i64 0
  %private.contiguous.address1748 = getelementptr i8, ptr %8374, i64 %8380
  %private.contiguous.preserve1749 = load <8 x float>, ptr %private.contiguous.address1748, align 4
  %8381 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7972, <8 x float> %private.contiguous.preserve1749
  store <8 x float> %8381, ptr %private.contiguous.address1748, align 4
  %8382 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8383 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8384 = add <8 x i64> %8383, splat (i64 768)
  %8385 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8382, 0
  %8386 = insertvalue { <8 x ptr>, <8 x i64> } %8385, <8 x i64> %8384, 1
  %8387 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8388 = extractvalue { <8 x ptr>, <8 x i64> } %8386, 1
  %8389 = extractelement <8 x ptr> %8387, i32 0
  %8390 = extractelement <8 x i64> %8388, i32 %7731
  %8391 = zext i32 %7731 to i64
  %8392 = mul i64 %8391, 4
  %8393 = sub i64 %8390, %8392
  %8394 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8395 = select i1 %8394, i64 %8393, i64 0
  %private.contiguous.address1750 = getelementptr i8, ptr %8389, i64 %8395
  %private.contiguous.preserve1751 = load <8 x float>, ptr %private.contiguous.address1750, align 4
  %8396 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7973, <8 x float> %private.contiguous.preserve1751
  store <8 x float> %8396, ptr %private.contiguous.address1750, align 4
  %8397 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8398 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8399 = add <8 x i64> %8398, splat (i64 800)
  %8400 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8397, 0
  %8401 = insertvalue { <8 x ptr>, <8 x i64> } %8400, <8 x i64> %8399, 1
  %8402 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8403 = extractvalue { <8 x ptr>, <8 x i64> } %8401, 1
  %8404 = extractelement <8 x ptr> %8402, i32 0
  %8405 = extractelement <8 x i64> %8403, i32 %7731
  %8406 = zext i32 %7731 to i64
  %8407 = mul i64 %8406, 4
  %8408 = sub i64 %8405, %8407
  %8409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8410 = select i1 %8409, i64 %8408, i64 0
  %private.contiguous.address1752 = getelementptr i8, ptr %8404, i64 %8410
  %private.contiguous.preserve1753 = load <8 x float>, ptr %private.contiguous.address1752, align 4
  %8411 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7974, <8 x float> %private.contiguous.preserve1753
  store <8 x float> %8411, ptr %private.contiguous.address1752, align 4
  %8412 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8413 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8414 = add <8 x i64> %8413, splat (i64 832)
  %8415 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8412, 0
  %8416 = insertvalue { <8 x ptr>, <8 x i64> } %8415, <8 x i64> %8414, 1
  %8417 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8418 = extractvalue { <8 x ptr>, <8 x i64> } %8416, 1
  %8419 = extractelement <8 x ptr> %8417, i32 0
  %8420 = extractelement <8 x i64> %8418, i32 %7731
  %8421 = zext i32 %7731 to i64
  %8422 = mul i64 %8421, 4
  %8423 = sub i64 %8420, %8422
  %8424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8425 = select i1 %8424, i64 %8423, i64 0
  %private.contiguous.address1754 = getelementptr i8, ptr %8419, i64 %8425
  %private.contiguous.preserve1755 = load <8 x float>, ptr %private.contiguous.address1754, align 4
  %8426 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7975, <8 x float> %private.contiguous.preserve1755
  store <8 x float> %8426, ptr %private.contiguous.address1754, align 4
  %8427 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8428 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8429 = add <8 x i64> %8428, splat (i64 864)
  %8430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8427, 0
  %8431 = insertvalue { <8 x ptr>, <8 x i64> } %8430, <8 x i64> %8429, 1
  %8432 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8433 = extractvalue { <8 x ptr>, <8 x i64> } %8431, 1
  %8434 = extractelement <8 x ptr> %8432, i32 0
  %8435 = extractelement <8 x i64> %8433, i32 %7731
  %8436 = zext i32 %7731 to i64
  %8437 = mul i64 %8436, 4
  %8438 = sub i64 %8435, %8437
  %8439 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8440 = select i1 %8439, i64 %8438, i64 0
  %private.contiguous.address1756 = getelementptr i8, ptr %8434, i64 %8440
  %private.contiguous.preserve1757 = load <8 x float>, ptr %private.contiguous.address1756, align 4
  %8441 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7976, <8 x float> %private.contiguous.preserve1757
  store <8 x float> %8441, ptr %private.contiguous.address1756, align 4
  %8442 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8443 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8444 = add <8 x i64> %8443, splat (i64 896)
  %8445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8442, 0
  %8446 = insertvalue { <8 x ptr>, <8 x i64> } %8445, <8 x i64> %8444, 1
  %8447 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8448 = extractvalue { <8 x ptr>, <8 x i64> } %8446, 1
  %8449 = extractelement <8 x ptr> %8447, i32 0
  %8450 = extractelement <8 x i64> %8448, i32 %7731
  %8451 = zext i32 %7731 to i64
  %8452 = mul i64 %8451, 4
  %8453 = sub i64 %8450, %8452
  %8454 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8455 = select i1 %8454, i64 %8453, i64 0
  %private.contiguous.address1758 = getelementptr i8, ptr %8449, i64 %8455
  %private.contiguous.preserve1759 = load <8 x float>, ptr %private.contiguous.address1758, align 4
  %8456 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7977, <8 x float> %private.contiguous.preserve1759
  store <8 x float> %8456, ptr %private.contiguous.address1758, align 4
  %8457 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8458 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8459 = add <8 x i64> %8458, splat (i64 928)
  %8460 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8457, 0
  %8461 = insertvalue { <8 x ptr>, <8 x i64> } %8460, <8 x i64> %8459, 1
  %8462 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8463 = extractvalue { <8 x ptr>, <8 x i64> } %8461, 1
  %8464 = extractelement <8 x ptr> %8462, i32 0
  %8465 = extractelement <8 x i64> %8463, i32 %7731
  %8466 = zext i32 %7731 to i64
  %8467 = mul i64 %8466, 4
  %8468 = sub i64 %8465, %8467
  %8469 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8470 = select i1 %8469, i64 %8468, i64 0
  %private.contiguous.address1760 = getelementptr i8, ptr %8464, i64 %8470
  %private.contiguous.preserve1761 = load <8 x float>, ptr %private.contiguous.address1760, align 4
  %8471 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7978, <8 x float> %private.contiguous.preserve1761
  store <8 x float> %8471, ptr %private.contiguous.address1760, align 4
  %8472 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8473 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8474 = add <8 x i64> %8473, splat (i64 960)
  %8475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8472, 0
  %8476 = insertvalue { <8 x ptr>, <8 x i64> } %8475, <8 x i64> %8474, 1
  %8477 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8478 = extractvalue { <8 x ptr>, <8 x i64> } %8476, 1
  %8479 = extractelement <8 x ptr> %8477, i32 0
  %8480 = extractelement <8 x i64> %8478, i32 %7731
  %8481 = zext i32 %7731 to i64
  %8482 = mul i64 %8481, 4
  %8483 = sub i64 %8480, %8482
  %8484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8485 = select i1 %8484, i64 %8483, i64 0
  %private.contiguous.address1762 = getelementptr i8, ptr %8479, i64 %8485
  %private.contiguous.preserve1763 = load <8 x float>, ptr %private.contiguous.address1762, align 4
  %8486 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7979, <8 x float> %private.contiguous.preserve1763
  store <8 x float> %8486, ptr %private.contiguous.address1762, align 4
  %8487 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8488 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8489 = add <8 x i64> %8488, splat (i64 992)
  %8490 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8487, 0
  %8491 = insertvalue { <8 x ptr>, <8 x i64> } %8490, <8 x i64> %8489, 1
  %8492 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8493 = extractvalue { <8 x ptr>, <8 x i64> } %8491, 1
  %8494 = extractelement <8 x ptr> %8492, i32 0
  %8495 = extractelement <8 x i64> %8493, i32 %7731
  %8496 = zext i32 %7731 to i64
  %8497 = mul i64 %8496, 4
  %8498 = sub i64 %8495, %8497
  %8499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8500 = select i1 %8499, i64 %8498, i64 0
  %private.contiguous.address1764 = getelementptr i8, ptr %8494, i64 %8500
  %private.contiguous.preserve1765 = load <8 x float>, ptr %private.contiguous.address1764, align 4
  %8501 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7980, <8 x float> %private.contiguous.preserve1765
  store <8 x float> %8501, ptr %private.contiguous.address1764, align 4
  %8502 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8503 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8504 = add <8 x i64> %8503, splat (i64 1024)
  %8505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8502, 0
  %8506 = insertvalue { <8 x ptr>, <8 x i64> } %8505, <8 x i64> %8504, 1
  %8507 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8508 = extractvalue { <8 x ptr>, <8 x i64> } %8506, 1
  %8509 = extractelement <8 x ptr> %8507, i32 0
  %8510 = extractelement <8 x i64> %8508, i32 %7731
  %8511 = zext i32 %7731 to i64
  %8512 = mul i64 %8511, 4
  %8513 = sub i64 %8510, %8512
  %8514 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8515 = select i1 %8514, i64 %8513, i64 0
  %private.contiguous.address1766 = getelementptr i8, ptr %8509, i64 %8515
  %private.contiguous.preserve1767 = load <8 x float>, ptr %private.contiguous.address1766, align 4
  %8516 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7981, <8 x float> %private.contiguous.preserve1767
  store <8 x float> %8516, ptr %private.contiguous.address1766, align 4
  %8517 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8518 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8519 = add <8 x i64> %8518, splat (i64 1056)
  %8520 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8517, 0
  %8521 = insertvalue { <8 x ptr>, <8 x i64> } %8520, <8 x i64> %8519, 1
  %8522 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8523 = extractvalue { <8 x ptr>, <8 x i64> } %8521, 1
  %8524 = extractelement <8 x ptr> %8522, i32 0
  %8525 = extractelement <8 x i64> %8523, i32 %7731
  %8526 = zext i32 %7731 to i64
  %8527 = mul i64 %8526, 4
  %8528 = sub i64 %8525, %8527
  %8529 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8530 = select i1 %8529, i64 %8528, i64 0
  %private.contiguous.address1768 = getelementptr i8, ptr %8524, i64 %8530
  %private.contiguous.preserve1769 = load <8 x float>, ptr %private.contiguous.address1768, align 4
  %8531 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7982, <8 x float> %private.contiguous.preserve1769
  store <8 x float> %8531, ptr %private.contiguous.address1768, align 4
  %8532 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8533 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8534 = add <8 x i64> %8533, splat (i64 1088)
  %8535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8532, 0
  %8536 = insertvalue { <8 x ptr>, <8 x i64> } %8535, <8 x i64> %8534, 1
  %8537 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8538 = extractvalue { <8 x ptr>, <8 x i64> } %8536, 1
  %8539 = extractelement <8 x ptr> %8537, i32 0
  %8540 = extractelement <8 x i64> %8538, i32 %7731
  %8541 = zext i32 %7731 to i64
  %8542 = mul i64 %8541, 4
  %8543 = sub i64 %8540, %8542
  %8544 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8545 = select i1 %8544, i64 %8543, i64 0
  %private.contiguous.address1770 = getelementptr i8, ptr %8539, i64 %8545
  %private.contiguous.preserve1771 = load <8 x float>, ptr %private.contiguous.address1770, align 4
  %8546 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7983, <8 x float> %private.contiguous.preserve1771
  store <8 x float> %8546, ptr %private.contiguous.address1770, align 4
  %8547 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8548 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8549 = add <8 x i64> %8548, splat (i64 1120)
  %8550 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8547, 0
  %8551 = insertvalue { <8 x ptr>, <8 x i64> } %8550, <8 x i64> %8549, 1
  %8552 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8553 = extractvalue { <8 x ptr>, <8 x i64> } %8551, 1
  %8554 = extractelement <8 x ptr> %8552, i32 0
  %8555 = extractelement <8 x i64> %8553, i32 %7731
  %8556 = zext i32 %7731 to i64
  %8557 = mul i64 %8556, 4
  %8558 = sub i64 %8555, %8557
  %8559 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8560 = select i1 %8559, i64 %8558, i64 0
  %private.contiguous.address1772 = getelementptr i8, ptr %8554, i64 %8560
  %private.contiguous.preserve1773 = load <8 x float>, ptr %private.contiguous.address1772, align 4
  %8561 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7984, <8 x float> %private.contiguous.preserve1773
  store <8 x float> %8561, ptr %private.contiguous.address1772, align 4
  %8562 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8563 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8564 = add <8 x i64> %8563, splat (i64 1152)
  %8565 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8562, 0
  %8566 = insertvalue { <8 x ptr>, <8 x i64> } %8565, <8 x i64> %8564, 1
  %8567 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8568 = extractvalue { <8 x ptr>, <8 x i64> } %8566, 1
  %8569 = extractelement <8 x ptr> %8567, i32 0
  %8570 = extractelement <8 x i64> %8568, i32 %7731
  %8571 = zext i32 %7731 to i64
  %8572 = mul i64 %8571, 4
  %8573 = sub i64 %8570, %8572
  %8574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8575 = select i1 %8574, i64 %8573, i64 0
  %private.contiguous.address1774 = getelementptr i8, ptr %8569, i64 %8575
  %private.contiguous.preserve1775 = load <8 x float>, ptr %private.contiguous.address1774, align 4
  %8576 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7985, <8 x float> %private.contiguous.preserve1775
  store <8 x float> %8576, ptr %private.contiguous.address1774, align 4
  %8577 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8578 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8579 = add <8 x i64> %8578, splat (i64 1184)
  %8580 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8577, 0
  %8581 = insertvalue { <8 x ptr>, <8 x i64> } %8580, <8 x i64> %8579, 1
  %8582 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8583 = extractvalue { <8 x ptr>, <8 x i64> } %8581, 1
  %8584 = extractelement <8 x ptr> %8582, i32 0
  %8585 = extractelement <8 x i64> %8583, i32 %7731
  %8586 = zext i32 %7731 to i64
  %8587 = mul i64 %8586, 4
  %8588 = sub i64 %8585, %8587
  %8589 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8590 = select i1 %8589, i64 %8588, i64 0
  %private.contiguous.address1776 = getelementptr i8, ptr %8584, i64 %8590
  %private.contiguous.preserve1777 = load <8 x float>, ptr %private.contiguous.address1776, align 4
  %8591 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7986, <8 x float> %private.contiguous.preserve1777
  store <8 x float> %8591, ptr %private.contiguous.address1776, align 4
  %8592 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8593 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8594 = add <8 x i64> %8593, splat (i64 1216)
  %8595 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8592, 0
  %8596 = insertvalue { <8 x ptr>, <8 x i64> } %8595, <8 x i64> %8594, 1
  %8597 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8598 = extractvalue { <8 x ptr>, <8 x i64> } %8596, 1
  %8599 = extractelement <8 x ptr> %8597, i32 0
  %8600 = extractelement <8 x i64> %8598, i32 %7731
  %8601 = zext i32 %7731 to i64
  %8602 = mul i64 %8601, 4
  %8603 = sub i64 %8600, %8602
  %8604 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8605 = select i1 %8604, i64 %8603, i64 0
  %private.contiguous.address1778 = getelementptr i8, ptr %8599, i64 %8605
  %private.contiguous.preserve1779 = load <8 x float>, ptr %private.contiguous.address1778, align 4
  %8606 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7987, <8 x float> %private.contiguous.preserve1779
  store <8 x float> %8606, ptr %private.contiguous.address1778, align 4
  %8607 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8608 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8609 = add <8 x i64> %8608, splat (i64 1248)
  %8610 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8607, 0
  %8611 = insertvalue { <8 x ptr>, <8 x i64> } %8610, <8 x i64> %8609, 1
  %8612 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8613 = extractvalue { <8 x ptr>, <8 x i64> } %8611, 1
  %8614 = extractelement <8 x ptr> %8612, i32 0
  %8615 = extractelement <8 x i64> %8613, i32 %7731
  %8616 = zext i32 %7731 to i64
  %8617 = mul i64 %8616, 4
  %8618 = sub i64 %8615, %8617
  %8619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8620 = select i1 %8619, i64 %8618, i64 0
  %private.contiguous.address1780 = getelementptr i8, ptr %8614, i64 %8620
  %private.contiguous.preserve1781 = load <8 x float>, ptr %private.contiguous.address1780, align 4
  %8621 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7988, <8 x float> %private.contiguous.preserve1781
  store <8 x float> %8621, ptr %private.contiguous.address1780, align 4
  %8622 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8623 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8624 = add <8 x i64> %8623, splat (i64 1280)
  %8625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8622, 0
  %8626 = insertvalue { <8 x ptr>, <8 x i64> } %8625, <8 x i64> %8624, 1
  %8627 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8628 = extractvalue { <8 x ptr>, <8 x i64> } %8626, 1
  %8629 = extractelement <8 x ptr> %8627, i32 0
  %8630 = extractelement <8 x i64> %8628, i32 %7731
  %8631 = zext i32 %7731 to i64
  %8632 = mul i64 %8631, 4
  %8633 = sub i64 %8630, %8632
  %8634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8635 = select i1 %8634, i64 %8633, i64 0
  %private.contiguous.address1782 = getelementptr i8, ptr %8629, i64 %8635
  %private.contiguous.preserve1783 = load <8 x float>, ptr %private.contiguous.address1782, align 4
  %8636 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7989, <8 x float> %private.contiguous.preserve1783
  store <8 x float> %8636, ptr %private.contiguous.address1782, align 4
  %8637 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8638 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8639 = add <8 x i64> %8638, splat (i64 1312)
  %8640 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8637, 0
  %8641 = insertvalue { <8 x ptr>, <8 x i64> } %8640, <8 x i64> %8639, 1
  %8642 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8643 = extractvalue { <8 x ptr>, <8 x i64> } %8641, 1
  %8644 = extractelement <8 x ptr> %8642, i32 0
  %8645 = extractelement <8 x i64> %8643, i32 %7731
  %8646 = zext i32 %7731 to i64
  %8647 = mul i64 %8646, 4
  %8648 = sub i64 %8645, %8647
  %8649 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8650 = select i1 %8649, i64 %8648, i64 0
  %private.contiguous.address1784 = getelementptr i8, ptr %8644, i64 %8650
  %private.contiguous.preserve1785 = load <8 x float>, ptr %private.contiguous.address1784, align 4
  %8651 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7990, <8 x float> %private.contiguous.preserve1785
  store <8 x float> %8651, ptr %private.contiguous.address1784, align 4
  %8652 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8653 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8654 = add <8 x i64> %8653, splat (i64 1344)
  %8655 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8652, 0
  %8656 = insertvalue { <8 x ptr>, <8 x i64> } %8655, <8 x i64> %8654, 1
  %8657 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8658 = extractvalue { <8 x ptr>, <8 x i64> } %8656, 1
  %8659 = extractelement <8 x ptr> %8657, i32 0
  %8660 = extractelement <8 x i64> %8658, i32 %7731
  %8661 = zext i32 %7731 to i64
  %8662 = mul i64 %8661, 4
  %8663 = sub i64 %8660, %8662
  %8664 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8665 = select i1 %8664, i64 %8663, i64 0
  %private.contiguous.address1786 = getelementptr i8, ptr %8659, i64 %8665
  %private.contiguous.preserve1787 = load <8 x float>, ptr %private.contiguous.address1786, align 4
  %8666 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7991, <8 x float> %private.contiguous.preserve1787
  store <8 x float> %8666, ptr %private.contiguous.address1786, align 4
  %8667 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8668 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8669 = add <8 x i64> %8668, splat (i64 1376)
  %8670 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8667, 0
  %8671 = insertvalue { <8 x ptr>, <8 x i64> } %8670, <8 x i64> %8669, 1
  %8672 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8673 = extractvalue { <8 x ptr>, <8 x i64> } %8671, 1
  %8674 = extractelement <8 x ptr> %8672, i32 0
  %8675 = extractelement <8 x i64> %8673, i32 %7731
  %8676 = zext i32 %7731 to i64
  %8677 = mul i64 %8676, 4
  %8678 = sub i64 %8675, %8677
  %8679 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8680 = select i1 %8679, i64 %8678, i64 0
  %private.contiguous.address1788 = getelementptr i8, ptr %8674, i64 %8680
  %private.contiguous.preserve1789 = load <8 x float>, ptr %private.contiguous.address1788, align 4
  %8681 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7992, <8 x float> %private.contiguous.preserve1789
  store <8 x float> %8681, ptr %private.contiguous.address1788, align 4
  %8682 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8683 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8684 = add <8 x i64> %8683, splat (i64 1408)
  %8685 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8682, 0
  %8686 = insertvalue { <8 x ptr>, <8 x i64> } %8685, <8 x i64> %8684, 1
  %8687 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8688 = extractvalue { <8 x ptr>, <8 x i64> } %8686, 1
  %8689 = extractelement <8 x ptr> %8687, i32 0
  %8690 = extractelement <8 x i64> %8688, i32 %7731
  %8691 = zext i32 %7731 to i64
  %8692 = mul i64 %8691, 4
  %8693 = sub i64 %8690, %8692
  %8694 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8695 = select i1 %8694, i64 %8693, i64 0
  %private.contiguous.address1790 = getelementptr i8, ptr %8689, i64 %8695
  %private.contiguous.preserve1791 = load <8 x float>, ptr %private.contiguous.address1790, align 4
  %8696 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7993, <8 x float> %private.contiguous.preserve1791
  store <8 x float> %8696, ptr %private.contiguous.address1790, align 4
  %8697 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8698 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8699 = add <8 x i64> %8698, splat (i64 1440)
  %8700 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8697, 0
  %8701 = insertvalue { <8 x ptr>, <8 x i64> } %8700, <8 x i64> %8699, 1
  %8702 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8703 = extractvalue { <8 x ptr>, <8 x i64> } %8701, 1
  %8704 = extractelement <8 x ptr> %8702, i32 0
  %8705 = extractelement <8 x i64> %8703, i32 %7731
  %8706 = zext i32 %7731 to i64
  %8707 = mul i64 %8706, 4
  %8708 = sub i64 %8705, %8707
  %8709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8710 = select i1 %8709, i64 %8708, i64 0
  %private.contiguous.address1792 = getelementptr i8, ptr %8704, i64 %8710
  %private.contiguous.preserve1793 = load <8 x float>, ptr %private.contiguous.address1792, align 4
  %8711 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7994, <8 x float> %private.contiguous.preserve1793
  store <8 x float> %8711, ptr %private.contiguous.address1792, align 4
  %8712 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8713 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8714 = add <8 x i64> %8713, splat (i64 1472)
  %8715 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8712, 0
  %8716 = insertvalue { <8 x ptr>, <8 x i64> } %8715, <8 x i64> %8714, 1
  %8717 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8718 = extractvalue { <8 x ptr>, <8 x i64> } %8716, 1
  %8719 = extractelement <8 x ptr> %8717, i32 0
  %8720 = extractelement <8 x i64> %8718, i32 %7731
  %8721 = zext i32 %7731 to i64
  %8722 = mul i64 %8721, 4
  %8723 = sub i64 %8720, %8722
  %8724 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8725 = select i1 %8724, i64 %8723, i64 0
  %private.contiguous.address1794 = getelementptr i8, ptr %8719, i64 %8725
  %private.contiguous.preserve1795 = load <8 x float>, ptr %private.contiguous.address1794, align 4
  %8726 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7995, <8 x float> %private.contiguous.preserve1795
  store <8 x float> %8726, ptr %private.contiguous.address1794, align 4
  %8727 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8728 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8729 = add <8 x i64> %8728, splat (i64 1504)
  %8730 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8727, 0
  %8731 = insertvalue { <8 x ptr>, <8 x i64> } %8730, <8 x i64> %8729, 1
  %8732 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8733 = extractvalue { <8 x ptr>, <8 x i64> } %8731, 1
  %8734 = extractelement <8 x ptr> %8732, i32 0
  %8735 = extractelement <8 x i64> %8733, i32 %7731
  %8736 = zext i32 %7731 to i64
  %8737 = mul i64 %8736, 4
  %8738 = sub i64 %8735, %8737
  %8739 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8740 = select i1 %8739, i64 %8738, i64 0
  %private.contiguous.address1796 = getelementptr i8, ptr %8734, i64 %8740
  %private.contiguous.preserve1797 = load <8 x float>, ptr %private.contiguous.address1796, align 4
  %8741 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7996, <8 x float> %private.contiguous.preserve1797
  store <8 x float> %8741, ptr %private.contiguous.address1796, align 4
  %8742 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8743 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8744 = add <8 x i64> %8743, splat (i64 1536)
  %8745 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8742, 0
  %8746 = insertvalue { <8 x ptr>, <8 x i64> } %8745, <8 x i64> %8744, 1
  %8747 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8748 = extractvalue { <8 x ptr>, <8 x i64> } %8746, 1
  %8749 = extractelement <8 x ptr> %8747, i32 0
  %8750 = extractelement <8 x i64> %8748, i32 %7731
  %8751 = zext i32 %7731 to i64
  %8752 = mul i64 %8751, 4
  %8753 = sub i64 %8750, %8752
  %8754 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8755 = select i1 %8754, i64 %8753, i64 0
  %private.contiguous.address1798 = getelementptr i8, ptr %8749, i64 %8755
  %private.contiguous.preserve1799 = load <8 x float>, ptr %private.contiguous.address1798, align 4
  %8756 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7997, <8 x float> %private.contiguous.preserve1799
  store <8 x float> %8756, ptr %private.contiguous.address1798, align 4
  %8757 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8758 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8759 = add <8 x i64> %8758, splat (i64 1568)
  %8760 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8757, 0
  %8761 = insertvalue { <8 x ptr>, <8 x i64> } %8760, <8 x i64> %8759, 1
  %8762 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8763 = extractvalue { <8 x ptr>, <8 x i64> } %8761, 1
  %8764 = extractelement <8 x ptr> %8762, i32 0
  %8765 = extractelement <8 x i64> %8763, i32 %7731
  %8766 = zext i32 %7731 to i64
  %8767 = mul i64 %8766, 4
  %8768 = sub i64 %8765, %8767
  %8769 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8770 = select i1 %8769, i64 %8768, i64 0
  %private.contiguous.address1800 = getelementptr i8, ptr %8764, i64 %8770
  %private.contiguous.preserve1801 = load <8 x float>, ptr %private.contiguous.address1800, align 4
  %8771 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7998, <8 x float> %private.contiguous.preserve1801
  store <8 x float> %8771, ptr %private.contiguous.address1800, align 4
  %8772 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8773 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8774 = add <8 x i64> %8773, splat (i64 1600)
  %8775 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8772, 0
  %8776 = insertvalue { <8 x ptr>, <8 x i64> } %8775, <8 x i64> %8774, 1
  %8777 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8778 = extractvalue { <8 x ptr>, <8 x i64> } %8776, 1
  %8779 = extractelement <8 x ptr> %8777, i32 0
  %8780 = extractelement <8 x i64> %8778, i32 %7731
  %8781 = zext i32 %7731 to i64
  %8782 = mul i64 %8781, 4
  %8783 = sub i64 %8780, %8782
  %8784 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8785 = select i1 %8784, i64 %8783, i64 0
  %private.contiguous.address1802 = getelementptr i8, ptr %8779, i64 %8785
  %private.contiguous.preserve1803 = load <8 x float>, ptr %private.contiguous.address1802, align 4
  %8786 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %7999, <8 x float> %private.contiguous.preserve1803
  store <8 x float> %8786, ptr %private.contiguous.address1802, align 4
  %8787 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8788 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8789 = add <8 x i64> %8788, splat (i64 1632)
  %8790 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8787, 0
  %8791 = insertvalue { <8 x ptr>, <8 x i64> } %8790, <8 x i64> %8789, 1
  %8792 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8793 = extractvalue { <8 x ptr>, <8 x i64> } %8791, 1
  %8794 = extractelement <8 x ptr> %8792, i32 0
  %8795 = extractelement <8 x i64> %8793, i32 %7731
  %8796 = zext i32 %7731 to i64
  %8797 = mul i64 %8796, 4
  %8798 = sub i64 %8795, %8797
  %8799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8800 = select i1 %8799, i64 %8798, i64 0
  %private.contiguous.address1804 = getelementptr i8, ptr %8794, i64 %8800
  %private.contiguous.preserve1805 = load <8 x float>, ptr %private.contiguous.address1804, align 4
  %8801 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8000, <8 x float> %private.contiguous.preserve1805
  store <8 x float> %8801, ptr %private.contiguous.address1804, align 4
  %8802 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8803 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8804 = add <8 x i64> %8803, splat (i64 1664)
  %8805 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8802, 0
  %8806 = insertvalue { <8 x ptr>, <8 x i64> } %8805, <8 x i64> %8804, 1
  %8807 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8808 = extractvalue { <8 x ptr>, <8 x i64> } %8806, 1
  %8809 = extractelement <8 x ptr> %8807, i32 0
  %8810 = extractelement <8 x i64> %8808, i32 %7731
  %8811 = zext i32 %7731 to i64
  %8812 = mul i64 %8811, 4
  %8813 = sub i64 %8810, %8812
  %8814 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8815 = select i1 %8814, i64 %8813, i64 0
  %private.contiguous.address1806 = getelementptr i8, ptr %8809, i64 %8815
  %private.contiguous.preserve1807 = load <8 x float>, ptr %private.contiguous.address1806, align 4
  %8816 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8001, <8 x float> %private.contiguous.preserve1807
  store <8 x float> %8816, ptr %private.contiguous.address1806, align 4
  %8817 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8818 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8819 = add <8 x i64> %8818, splat (i64 1696)
  %8820 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8817, 0
  %8821 = insertvalue { <8 x ptr>, <8 x i64> } %8820, <8 x i64> %8819, 1
  %8822 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8823 = extractvalue { <8 x ptr>, <8 x i64> } %8821, 1
  %8824 = extractelement <8 x ptr> %8822, i32 0
  %8825 = extractelement <8 x i64> %8823, i32 %7731
  %8826 = zext i32 %7731 to i64
  %8827 = mul i64 %8826, 4
  %8828 = sub i64 %8825, %8827
  %8829 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8830 = select i1 %8829, i64 %8828, i64 0
  %private.contiguous.address1808 = getelementptr i8, ptr %8824, i64 %8830
  %private.contiguous.preserve1809 = load <8 x float>, ptr %private.contiguous.address1808, align 4
  %8831 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8002, <8 x float> %private.contiguous.preserve1809
  store <8 x float> %8831, ptr %private.contiguous.address1808, align 4
  %8832 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8833 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8834 = add <8 x i64> %8833, splat (i64 1728)
  %8835 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8832, 0
  %8836 = insertvalue { <8 x ptr>, <8 x i64> } %8835, <8 x i64> %8834, 1
  %8837 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8838 = extractvalue { <8 x ptr>, <8 x i64> } %8836, 1
  %8839 = extractelement <8 x ptr> %8837, i32 0
  %8840 = extractelement <8 x i64> %8838, i32 %7731
  %8841 = zext i32 %7731 to i64
  %8842 = mul i64 %8841, 4
  %8843 = sub i64 %8840, %8842
  %8844 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8845 = select i1 %8844, i64 %8843, i64 0
  %private.contiguous.address1810 = getelementptr i8, ptr %8839, i64 %8845
  %private.contiguous.preserve1811 = load <8 x float>, ptr %private.contiguous.address1810, align 4
  %8846 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8003, <8 x float> %private.contiguous.preserve1811
  store <8 x float> %8846, ptr %private.contiguous.address1810, align 4
  %8847 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8848 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8849 = add <8 x i64> %8848, splat (i64 1760)
  %8850 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8847, 0
  %8851 = insertvalue { <8 x ptr>, <8 x i64> } %8850, <8 x i64> %8849, 1
  %8852 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8853 = extractvalue { <8 x ptr>, <8 x i64> } %8851, 1
  %8854 = extractelement <8 x ptr> %8852, i32 0
  %8855 = extractelement <8 x i64> %8853, i32 %7731
  %8856 = zext i32 %7731 to i64
  %8857 = mul i64 %8856, 4
  %8858 = sub i64 %8855, %8857
  %8859 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8860 = select i1 %8859, i64 %8858, i64 0
  %private.contiguous.address1812 = getelementptr i8, ptr %8854, i64 %8860
  %private.contiguous.preserve1813 = load <8 x float>, ptr %private.contiguous.address1812, align 4
  %8861 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8004, <8 x float> %private.contiguous.preserve1813
  store <8 x float> %8861, ptr %private.contiguous.address1812, align 4
  %8862 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8863 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8864 = add <8 x i64> %8863, splat (i64 1792)
  %8865 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8862, 0
  %8866 = insertvalue { <8 x ptr>, <8 x i64> } %8865, <8 x i64> %8864, 1
  %8867 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8868 = extractvalue { <8 x ptr>, <8 x i64> } %8866, 1
  %8869 = extractelement <8 x ptr> %8867, i32 0
  %8870 = extractelement <8 x i64> %8868, i32 %7731
  %8871 = zext i32 %7731 to i64
  %8872 = mul i64 %8871, 4
  %8873 = sub i64 %8870, %8872
  %8874 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8875 = select i1 %8874, i64 %8873, i64 0
  %private.contiguous.address1814 = getelementptr i8, ptr %8869, i64 %8875
  %private.contiguous.preserve1815 = load <8 x float>, ptr %private.contiguous.address1814, align 4
  %8876 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8005, <8 x float> %private.contiguous.preserve1815
  store <8 x float> %8876, ptr %private.contiguous.address1814, align 4
  %8877 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8878 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8879 = add <8 x i64> %8878, splat (i64 1824)
  %8880 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8877, 0
  %8881 = insertvalue { <8 x ptr>, <8 x i64> } %8880, <8 x i64> %8879, 1
  %8882 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8883 = extractvalue { <8 x ptr>, <8 x i64> } %8881, 1
  %8884 = extractelement <8 x ptr> %8882, i32 0
  %8885 = extractelement <8 x i64> %8883, i32 %7731
  %8886 = zext i32 %7731 to i64
  %8887 = mul i64 %8886, 4
  %8888 = sub i64 %8885, %8887
  %8889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8890 = select i1 %8889, i64 %8888, i64 0
  %private.contiguous.address1816 = getelementptr i8, ptr %8884, i64 %8890
  %private.contiguous.preserve1817 = load <8 x float>, ptr %private.contiguous.address1816, align 4
  %8891 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8006, <8 x float> %private.contiguous.preserve1817
  store <8 x float> %8891, ptr %private.contiguous.address1816, align 4
  %8892 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8893 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8894 = add <8 x i64> %8893, splat (i64 1856)
  %8895 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8892, 0
  %8896 = insertvalue { <8 x ptr>, <8 x i64> } %8895, <8 x i64> %8894, 1
  %8897 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8898 = extractvalue { <8 x ptr>, <8 x i64> } %8896, 1
  %8899 = extractelement <8 x ptr> %8897, i32 0
  %8900 = extractelement <8 x i64> %8898, i32 %7731
  %8901 = zext i32 %7731 to i64
  %8902 = mul i64 %8901, 4
  %8903 = sub i64 %8900, %8902
  %8904 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8905 = select i1 %8904, i64 %8903, i64 0
  %private.contiguous.address1818 = getelementptr i8, ptr %8899, i64 %8905
  %private.contiguous.preserve1819 = load <8 x float>, ptr %private.contiguous.address1818, align 4
  %8906 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8007, <8 x float> %private.contiguous.preserve1819
  store <8 x float> %8906, ptr %private.contiguous.address1818, align 4
  %8907 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8908 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8909 = add <8 x i64> %8908, splat (i64 1888)
  %8910 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8907, 0
  %8911 = insertvalue { <8 x ptr>, <8 x i64> } %8910, <8 x i64> %8909, 1
  %8912 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8913 = extractvalue { <8 x ptr>, <8 x i64> } %8911, 1
  %8914 = extractelement <8 x ptr> %8912, i32 0
  %8915 = extractelement <8 x i64> %8913, i32 %7731
  %8916 = zext i32 %7731 to i64
  %8917 = mul i64 %8916, 4
  %8918 = sub i64 %8915, %8917
  %8919 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8920 = select i1 %8919, i64 %8918, i64 0
  %private.contiguous.address1820 = getelementptr i8, ptr %8914, i64 %8920
  %private.contiguous.preserve1821 = load <8 x float>, ptr %private.contiguous.address1820, align 4
  %8921 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8008, <8 x float> %private.contiguous.preserve1821
  store <8 x float> %8921, ptr %private.contiguous.address1820, align 4
  %8922 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8923 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8924 = add <8 x i64> %8923, splat (i64 1920)
  %8925 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8922, 0
  %8926 = insertvalue { <8 x ptr>, <8 x i64> } %8925, <8 x i64> %8924, 1
  %8927 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8928 = extractvalue { <8 x ptr>, <8 x i64> } %8926, 1
  %8929 = extractelement <8 x ptr> %8927, i32 0
  %8930 = extractelement <8 x i64> %8928, i32 %7731
  %8931 = zext i32 %7731 to i64
  %8932 = mul i64 %8931, 4
  %8933 = sub i64 %8930, %8932
  %8934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8935 = select i1 %8934, i64 %8933, i64 0
  %private.contiguous.address1822 = getelementptr i8, ptr %8929, i64 %8935
  %private.contiguous.preserve1823 = load <8 x float>, ptr %private.contiguous.address1822, align 4
  %8936 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8009, <8 x float> %private.contiguous.preserve1823
  store <8 x float> %8936, ptr %private.contiguous.address1822, align 4
  %8937 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8938 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8939 = add <8 x i64> %8938, splat (i64 1952)
  %8940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8937, 0
  %8941 = insertvalue { <8 x ptr>, <8 x i64> } %8940, <8 x i64> %8939, 1
  %8942 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8943 = extractvalue { <8 x ptr>, <8 x i64> } %8941, 1
  %8944 = extractelement <8 x ptr> %8942, i32 0
  %8945 = extractelement <8 x i64> %8943, i32 %7731
  %8946 = zext i32 %7731 to i64
  %8947 = mul i64 %8946, 4
  %8948 = sub i64 %8945, %8947
  %8949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8950 = select i1 %8949, i64 %8948, i64 0
  %private.contiguous.address1824 = getelementptr i8, ptr %8944, i64 %8950
  %private.contiguous.preserve1825 = load <8 x float>, ptr %private.contiguous.address1824, align 4
  %8951 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8010, <8 x float> %private.contiguous.preserve1825
  store <8 x float> %8951, ptr %private.contiguous.address1824, align 4
  %8952 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8953 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8954 = add <8 x i64> %8953, splat (i64 1984)
  %8955 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8952, 0
  %8956 = insertvalue { <8 x ptr>, <8 x i64> } %8955, <8 x i64> %8954, 1
  %8957 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8958 = extractvalue { <8 x ptr>, <8 x i64> } %8956, 1
  %8959 = extractelement <8 x ptr> %8957, i32 0
  %8960 = extractelement <8 x i64> %8958, i32 %7731
  %8961 = zext i32 %7731 to i64
  %8962 = mul i64 %8961, 4
  %8963 = sub i64 %8960, %8962
  %8964 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8965 = select i1 %8964, i64 %8963, i64 0
  %private.contiguous.address1826 = getelementptr i8, ptr %8959, i64 %8965
  %private.contiguous.preserve1827 = load <8 x float>, ptr %private.contiguous.address1826, align 4
  %8966 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8011, <8 x float> %private.contiguous.preserve1827
  store <8 x float> %8966, ptr %private.contiguous.address1826, align 4
  %8967 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8968 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8969 = add <8 x i64> %8968, splat (i64 2016)
  %8970 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8967, 0
  %8971 = insertvalue { <8 x ptr>, <8 x i64> } %8970, <8 x i64> %8969, 1
  %8972 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8973 = extractvalue { <8 x ptr>, <8 x i64> } %8971, 1
  %8974 = extractelement <8 x ptr> %8972, i32 0
  %8975 = extractelement <8 x i64> %8973, i32 %7731
  %8976 = zext i32 %7731 to i64
  %8977 = mul i64 %8976, 4
  %8978 = sub i64 %8975, %8977
  %8979 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  %8980 = select i1 %8979, i64 %8978, i64 0
  %private.contiguous.address1828 = getelementptr i8, ptr %8974, i64 %8980
  %private.contiguous.preserve1829 = load <8 x float>, ptr %private.contiguous.address1828, align 4
  %8981 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8012, <8 x float> %private.contiguous.preserve1829
  store <8 x float> %8981, ptr %private.contiguous.address1828, align 4
  %.state1830 = load <8 x float>, ptr %.slot50, align 32
  %8982 = fmul <8 x float> %.state1830, %native.exp
  %8983 = load <8 x float>, ptr %.spill286, align 32
  %8984 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8982, <8 x float> %8983
  store <8 x float> %8984, ptr %.spill286, align 32
  %.state1831 = load <8 x float>, ptr %.slot51, align 32
  %8985 = fmul <8 x float> %.state1831, %native.exp1499
  %8986 = load <8 x float>, ptr %.spill287, align 32
  %8987 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8985, <8 x float> %8986
  store <8 x float> %8987, ptr %.spill287, align 32
  %.state1832 = load <8 x float>, ptr %.slot52, align 32
  %8988 = fmul <8 x float> %.state1832, %native.exp1500
  %8989 = load <8 x float>, ptr %.spill288, align 32
  %8990 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8988, <8 x float> %8989
  store <8 x float> %8990, ptr %.spill288, align 32
  %.state1833 = load <8 x float>, ptr %.slot53, align 32
  %8991 = fmul <8 x float> %.state1833, %native.exp1501
  %8992 = load <8 x float>, ptr %.spill289, align 32
  %8993 = select <8 x i1> %convergence.cascade.result1486, <8 x float> %8991, <8 x float> %8992
  store <8 x float> %8993, ptr %.spill289, align 32
  %8994 = load <8 x i64>, ptr %.slot56, align 64
  %8995 = select <8 x i1> %convergence.cascade.result1486, <8 x i64> zeroinitializer, <8 x i64> %8994
  store <8 x i64> %8995, ptr %.slot56, align 64
  %8996 = load <8 x float>, ptr %.slot41, align 32
  %8997 = select <8 x i1> %convergence.cascade.result1486, <8 x float> zeroinitializer, <8 x float> %8996
  store <8 x float> %8997, ptr %.slot41, align 32
  store <8 x i1> %convergence.cascade.result1486, ptr %current.mask, align 1
  %8998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1486)
  br i1 %8998, label %schedule.81, label %scheduler.loop

varying.divergent1835:                            ; preds = %schedule.81
  %8999 = load i32, ptr %current.token, align 4
  %9000 = icmp ne i32 %8999, 0
  %9001 = sub i32 %8999, 1
  %9002 = select i1 %9000, i32 %9001, i32 0
  %9003 = load i8, ptr %frame.active, align 1
  %9004 = trunc i32 %9002 to i8
  %9005 = shl i8 1, %9004
  %9006 = and i8 %9003, %9005
  %9007 = icmp ne i8 %9006, 0
  %9008 = load <8 x i32>, ptr %frame.static.id, align 32
  %9009 = extractelement <8 x i32> %9008, i32 %9002
  %9010 = icmp eq i32 %9009, 28
  %9011 = and i1 %9007, %9010
  %9012 = and i1 %9000, %9011
  %9013 = xor i1 %9012, true
  %9014 = and i1 true, %9013
  %9015 = xor i8 %9003, -1
  %9016 = icmp ne i8 %9015, 0
  %9017 = xor i1 %9016, true
  %9018 = and i1 %9014, %9017
  br i1 %9018, label %convergence.overflow.trap1837, label %convergence.overflow.resume1838

varying.coherent1836:                             ; preds = %schedule.81
  br i1 %1931, label %varying.coherent.true1841, label %varying.coherent.false1842

convergence.overflow.trap1837:                    ; preds = %varying.divergent1835
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1838:                  ; preds = %varying.divergent1835
  %9019 = call i8 @llvm.cttz.i8(i8 %9015, i1 false)
  %9020 = zext i8 %9019 to i32
  %9021 = select i1 %9016, i32 %9020, i32 0
  %9022 = trunc i32 %9021 to i8
  %9023 = shl i8 1, %9022
  %9024 = or i8 %9003, %9023
  %9025 = select i1 %9014, i8 %9024, i8 %9003
  store i8 %9025, ptr %frame.active, align 1
  %9026 = load <8 x i32>, ptr %frame.static.id, align 32
  %9027 = extractelement <8 x i32> %9026, i32 %9021
  %9028 = select i1 %9014, i32 28, i32 %9027
  %9029 = load <8 x i32>, ptr %frame.static.id, align 32
  %9030 = insertelement <8 x i32> %9029, i32 %9028, i32 %9021
  store <8 x i32> %9030, ptr %frame.static.id, align 32
  %9031 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9032 = extractelement <8 x i32> %9031, i32 %9021
  %9033 = select i1 %9014, i32 %8999, i32 %9032
  %9034 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9035 = insertelement <8 x i32> %9034, i32 %9033, i32 %9021
  store <8 x i32> %9035, ptr %frame.parent.token, align 32
  %9036 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9021
  %9037 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9021
  %9038 = load <8 x i1>, ptr %9036, align 1
  %9039 = load <8 x i1>, ptr %9037, align 1
  %9040 = select i1 %9014, <8 x i1> %1921, <8 x i1> %9038
  store <8 x i1> %9040, ptr %9036, align 1
  %9041 = select i1 %9014, <8 x i1> zeroinitializer, <8 x i1> %9039
  store <8 x i1> %9041, ptr %9037, align 1
  %9042 = add i32 %9021, 1
  %9043 = select i1 %9012, i32 %8999, i32 %9042
  %9044 = select i1 true, i32 %9043, i32 %8999
  store i32 %9044, ptr %current.token, align 4
  %9045 = load i32, ptr %current.token, align 4
  %9046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1928)
  %9047 = load i32, ptr %ready.count, align 4
  %9048 = icmp uge i32 %9047, 8
  %9049 = and i1 %9046, %9048
  br i1 %9049, label %ready.overflow.trap1839, label %ready.overflow.resume1840

ready.overflow.trap1839:                          ; preds = %convergence.overflow.resume1838
  call void @llvm.trap()
  unreachable

ready.overflow.resume1840:                        ; preds = %convergence.overflow.resume1838
  %9050 = select i1 %9046, i32 %9047, i32 0
  %9051 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9050
  %9052 = load <8 x i1>, ptr %9051, align 1
  %9053 = select i1 %9046, <8 x i1> %1928, <8 x i1> %9052
  store <8 x i1> %9053, ptr %9051, align 1
  %9054 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9050
  %9055 = load i32, ptr %9054, align 4
  %9056 = select i1 %9046, i32 82, i32 %9055
  store i32 %9056, ptr %9054, align 4
  %9057 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9050
  %9058 = load i32, ptr %9057, align 4
  %9059 = select i1 %9046, i32 %9045, i32 %9058
  store i32 %9059, ptr %9057, align 4
  %9060 = add i32 %9047, 1
  %9061 = select i1 %9046, i32 %9060, i32 %9047
  store i32 %9061, ptr %ready.count, align 4
  %9062 = load <8 x i1>, ptr %runnable.mask, align 1
  %9063 = or <8 x i1> %9062, %1928
  store <8 x i1> %9063, ptr %runnable.mask, align 1
  store <8 x i1> %1930, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1841:                        ; preds = %varying.coherent1836
  store <8 x i1> %1921, ptr %current.mask, align 1
  %9064 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1921)
  br i1 %9064, label %schedule.82, label %scheduler.loop

varying.coherent.false1842:                       ; preds = %varying.coherent1836
  store <8 x i1> %1921, ptr %current.mask, align 1
  %9065 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1921)
  br i1 %9065, label %schedule.83, label %scheduler.loop

convergence.cascade1847:                          ; preds = %convergence.cascade1847, %schedule.83
  %convergence.cascade.flow1851 = phi <8 x i1> [ %1961, %schedule.83 ], [ %9108, %convergence.cascade1847 ]
  %convergence.cascade.depth1852 = phi i32 [ 0, %schedule.83 ], [ %9109, %convergence.cascade1847 ]
  %9066 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1851)
  %9067 = load i32, ptr %current.token, align 4
  %9068 = icmp ne i32 %9067, 0
  %9069 = and i1 %9066, %9068
  %9070 = sub i32 %9067, 1
  %9071 = select i1 %9069, i32 %9070, i32 0
  %9072 = load i8, ptr %frame.active, align 1
  %9073 = trunc i32 %9071 to i8
  %9074 = shl i8 1, %9073
  %9075 = and i8 %9072, %9074
  %9076 = icmp ne i8 %9075, 0
  %9077 = load <8 x i32>, ptr %frame.static.id, align 32
  %9078 = extractelement <8 x i32> %9077, i32 %9071
  %convergence.target.pointer1853 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9078
  %convergence.dynamic.target1854 = load i32, ptr %convergence.target.pointer1853, align 4
  %9079 = icmp eq i32 %convergence.dynamic.target1854, 83
  %9080 = and i1 %9076, %9079
  %9081 = and i1 %9069, %9080
  %9082 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9071
  %9083 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9071
  %9084 = load <8 x i1>, ptr %9082, align 1
  %9085 = load <8 x i1>, ptr %9083, align 1
  %9086 = or <8 x i1> %9085, %convergence.cascade.flow1851
  %9087 = load <8 x i1>, ptr %live.mask, align 1
  %9088 = and <8 x i1> %9084, %9087
  %9089 = icmp eq <8 x i1> %9086, %9088
  %9090 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9089)
  %9091 = and i1 %9081, %9090
  %9092 = select i1 %9091, <8 x i1> zeroinitializer, <8 x i1> %9086
  %9093 = select i1 %9081, <8 x i1> %9092, <8 x i1> %9085
  store <8 x i1> %9093, ptr %9083, align 1
  %9094 = select i1 %9091, <8 x i1> zeroinitializer, <8 x i1> %9084
  store <8 x i1> %9094, ptr %9082, align 1
  %9095 = trunc i32 %9071 to i8
  %9096 = shl i8 1, %9095
  %9097 = xor i8 %9096, -1
  %9098 = and i8 %9072, %9097
  %9099 = select i1 %9091, i8 %9098, i8 %9072
  store i8 %9099, ptr %frame.active, align 1
  %.splatinsert1855 = insertelement <8 x i1> poison, i1 %9081, i64 0
  %.splat1856 = shufflevector <8 x i1> %.splatinsert1855, <8 x i1> poison, <8 x i32> zeroinitializer
  %9100 = and <8 x i1> %convergence.cascade.flow1851, %.splat1856
  %9101 = load <8 x i1>, ptr %runnable.mask, align 1
  %9102 = xor <8 x i1> %9100, splat (i1 true)
  %9103 = and <8 x i1> %9101, %9102
  store <8 x i1> %9103, ptr %runnable.mask, align 1
  %.splatinsert1857 = insertelement <8 x i1> poison, i1 %9091, i64 0
  %.splat1858 = shufflevector <8 x i1> %.splatinsert1857, <8 x i1> poison, <8 x i32> zeroinitializer
  %9104 = select <8 x i1> %.splat1858, <8 x i1> %9086, <8 x i1> zeroinitializer
  %9105 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9106 = extractelement <8 x i32> %9105, i32 %9071
  %9107 = select i1 %9091, i32 %9106, i32 %9067
  store i32 %9107, ptr %current.token, align 4
  %.splatinsert1859 = insertelement <8 x i1> poison, i1 %9081, i64 0
  %.splat1860 = shufflevector <8 x i1> %.splatinsert1859, <8 x i1> poison, <8 x i32> zeroinitializer
  %9108 = select <8 x i1> %.splat1860, <8 x i1> %9104, <8 x i1> %convergence.cascade.flow1851
  %9109 = add i32 %convergence.cascade.depth1852, 1
  %9110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9108)
  %9111 = icmp ult i32 %9109, 8
  %9112 = and i1 %9110, %9111
  %9113 = and i1 %9081, %9112
  %convergence.parent.token1861 = load i32, ptr %current.token, align 4
  %convergence.parent.present1862 = icmp ne i32 %convergence.parent.token1861, 0
  %9114 = and i1 %9113, %convergence.parent.present1862
  br i1 %9114, label %convergence.cascade1847, label %convergence.cascade.exit1848

convergence.cascade.exit1848:                     ; preds = %convergence.cascade1847, %schedule.83
  %convergence.cascade.result1863 = phi <8 x i1> [ %1961, %schedule.83 ], [ %9108, %convergence.cascade1847 ]
  %9115 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1863)
  br i1 %9115, label %convergence.target.83.ready, label %scheduler.loop

convergence.target.83.ready:                      ; preds = %convergence.cascade.exit1848
  %9116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1863)
  %9117 = bitcast <8 x i1> %convergence.cascade.result1863 to i8
  %9118 = call i8 @llvm.cttz.i8(i8 %9117, i1 false)
  %9119 = zext i8 %9118 to i32
  %9120 = select i1 %9116, i32 %9119, i32 0
  %9121 = load <8 x i64>, ptr %.slot56, align 64
  %9122 = select <8 x i1> %convergence.cascade.result1863, <8 x i64> zeroinitializer, <8 x i64> %9121
  store <8 x i64> %9122, ptr %.slot56, align 64
  %9123 = load <8 x float>, ptr %.slot47, align 32
  %9124 = select <8 x i1> %convergence.cascade.result1863, <8 x float> zeroinitializer, <8 x float> %9123
  store <8 x float> %9124, ptr %.slot47, align 32
  store <8 x i1> %convergence.cascade.result1863, ptr %current.mask, align 1
  %9125 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1863)
  br i1 %9125, label %schedule.84, label %scheduler.loop

varying.divergent1865:                            ; preds = %schedule.84
  %9126 = load i32, ptr %current.token, align 4
  %9127 = icmp ne i32 %9126, 0
  %9128 = sub i32 %9126, 1
  %9129 = select i1 %9127, i32 %9128, i32 0
  %9130 = load i8, ptr %frame.active, align 1
  %9131 = trunc i32 %9129 to i8
  %9132 = shl i8 1, %9131
  %9133 = and i8 %9130, %9132
  %9134 = icmp ne i8 %9133, 0
  %9135 = load <8 x i32>, ptr %frame.static.id, align 32
  %9136 = extractelement <8 x i32> %9135, i32 %9129
  %9137 = icmp eq i32 %9136, 29
  %9138 = and i1 %9134, %9137
  %9139 = and i1 %9127, %9138
  %9140 = xor i1 %9139, true
  %9141 = and i1 true, %9140
  %9142 = xor i8 %9130, -1
  %9143 = icmp ne i8 %9142, 0
  %9144 = xor i1 %9143, true
  %9145 = and i1 %9141, %9144
  br i1 %9145, label %convergence.overflow.trap1867, label %convergence.overflow.resume1868

varying.coherent1866:                             ; preds = %schedule.84
  br i1 %1972, label %varying.coherent.true1871, label %varying.coherent.false1872

convergence.overflow.trap1867:                    ; preds = %varying.divergent1865
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1868:                  ; preds = %varying.divergent1865
  %9146 = call i8 @llvm.cttz.i8(i8 %9142, i1 false)
  %9147 = zext i8 %9146 to i32
  %9148 = select i1 %9143, i32 %9147, i32 0
  %9149 = trunc i32 %9148 to i8
  %9150 = shl i8 1, %9149
  %9151 = or i8 %9130, %9150
  %9152 = select i1 %9141, i8 %9151, i8 %9130
  store i8 %9152, ptr %frame.active, align 1
  %9153 = load <8 x i32>, ptr %frame.static.id, align 32
  %9154 = extractelement <8 x i32> %9153, i32 %9148
  %9155 = select i1 %9141, i32 29, i32 %9154
  %9156 = load <8 x i32>, ptr %frame.static.id, align 32
  %9157 = insertelement <8 x i32> %9156, i32 %9155, i32 %9148
  store <8 x i32> %9157, ptr %frame.static.id, align 32
  %9158 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9159 = extractelement <8 x i32> %9158, i32 %9148
  %9160 = select i1 %9141, i32 %9126, i32 %9159
  %9161 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9162 = insertelement <8 x i32> %9161, i32 %9160, i32 %9148
  store <8 x i32> %9162, ptr %frame.parent.token, align 32
  %9163 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9148
  %9164 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9148
  %9165 = load <8 x i1>, ptr %9163, align 1
  %9166 = load <8 x i1>, ptr %9164, align 1
  %9167 = select i1 %9141, <8 x i1> %1962, <8 x i1> %9165
  store <8 x i1> %9167, ptr %9163, align 1
  %9168 = select i1 %9141, <8 x i1> zeroinitializer, <8 x i1> %9166
  store <8 x i1> %9168, ptr %9164, align 1
  %9169 = add i32 %9148, 1
  %9170 = select i1 %9139, i32 %9126, i32 %9169
  %9171 = select i1 true, i32 %9170, i32 %9126
  store i32 %9171, ptr %current.token, align 4
  %9172 = load i32, ptr %current.token, align 4
  %9173 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1969)
  %9174 = load i32, ptr %ready.count, align 4
  %9175 = icmp uge i32 %9174, 8
  %9176 = and i1 %9173, %9175
  br i1 %9176, label %ready.overflow.trap1869, label %ready.overflow.resume1870

ready.overflow.trap1869:                          ; preds = %convergence.overflow.resume1868
  call void @llvm.trap()
  unreachable

ready.overflow.resume1870:                        ; preds = %convergence.overflow.resume1868
  %9177 = select i1 %9173, i32 %9174, i32 0
  %9178 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9177
  %9179 = load <8 x i1>, ptr %9178, align 1
  %9180 = select i1 %9173, <8 x i1> %1969, <8 x i1> %9179
  store <8 x i1> %9180, ptr %9178, align 1
  %9181 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9177
  %9182 = load i32, ptr %9181, align 4
  %9183 = select i1 %9173, i32 85, i32 %9182
  store i32 %9183, ptr %9181, align 4
  %9184 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9177
  %9185 = load i32, ptr %9184, align 4
  %9186 = select i1 %9173, i32 %9172, i32 %9185
  store i32 %9186, ptr %9184, align 4
  %9187 = add i32 %9174, 1
  %9188 = select i1 %9173, i32 %9187, i32 %9174
  store i32 %9188, ptr %ready.count, align 4
  %9189 = load <8 x i1>, ptr %runnable.mask, align 1
  %9190 = or <8 x i1> %9189, %1969
  store <8 x i1> %9190, ptr %runnable.mask, align 1
  store <8 x i1> %1971, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1871:                        ; preds = %varying.coherent1866
  store <8 x i1> %1962, ptr %current.mask, align 1
  %9191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1962)
  br i1 %9191, label %schedule.85, label %scheduler.loop

varying.coherent.false1872:                       ; preds = %varying.coherent1866
  store <8 x i1> %1962, ptr %current.mask, align 1
  %9192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1962)
  br i1 %9192, label %schedule.86, label %scheduler.loop

convergence.cascade1877:                          ; preds = %convergence.cascade1877, %schedule.86
  %convergence.cascade.flow1881 = phi <8 x i1> [ %2002, %schedule.86 ], [ %9235, %convergence.cascade1877 ]
  %convergence.cascade.depth1882 = phi i32 [ 0, %schedule.86 ], [ %9236, %convergence.cascade1877 ]
  %9193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1881)
  %9194 = load i32, ptr %current.token, align 4
  %9195 = icmp ne i32 %9194, 0
  %9196 = and i1 %9193, %9195
  %9197 = sub i32 %9194, 1
  %9198 = select i1 %9196, i32 %9197, i32 0
  %9199 = load i8, ptr %frame.active, align 1
  %9200 = trunc i32 %9198 to i8
  %9201 = shl i8 1, %9200
  %9202 = and i8 %9199, %9201
  %9203 = icmp ne i8 %9202, 0
  %9204 = load <8 x i32>, ptr %frame.static.id, align 32
  %9205 = extractelement <8 x i32> %9204, i32 %9198
  %convergence.target.pointer1883 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9205
  %convergence.dynamic.target1884 = load i32, ptr %convergence.target.pointer1883, align 4
  %9206 = icmp eq i32 %convergence.dynamic.target1884, 86
  %9207 = and i1 %9203, %9206
  %9208 = and i1 %9196, %9207
  %9209 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9198
  %9210 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9198
  %9211 = load <8 x i1>, ptr %9209, align 1
  %9212 = load <8 x i1>, ptr %9210, align 1
  %9213 = or <8 x i1> %9212, %convergence.cascade.flow1881
  %9214 = load <8 x i1>, ptr %live.mask, align 1
  %9215 = and <8 x i1> %9211, %9214
  %9216 = icmp eq <8 x i1> %9213, %9215
  %9217 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9216)
  %9218 = and i1 %9208, %9217
  %9219 = select i1 %9218, <8 x i1> zeroinitializer, <8 x i1> %9213
  %9220 = select i1 %9208, <8 x i1> %9219, <8 x i1> %9212
  store <8 x i1> %9220, ptr %9210, align 1
  %9221 = select i1 %9218, <8 x i1> zeroinitializer, <8 x i1> %9211
  store <8 x i1> %9221, ptr %9209, align 1
  %9222 = trunc i32 %9198 to i8
  %9223 = shl i8 1, %9222
  %9224 = xor i8 %9223, -1
  %9225 = and i8 %9199, %9224
  %9226 = select i1 %9218, i8 %9225, i8 %9199
  store i8 %9226, ptr %frame.active, align 1
  %.splatinsert1885 = insertelement <8 x i1> poison, i1 %9208, i64 0
  %.splat1886 = shufflevector <8 x i1> %.splatinsert1885, <8 x i1> poison, <8 x i32> zeroinitializer
  %9227 = and <8 x i1> %convergence.cascade.flow1881, %.splat1886
  %9228 = load <8 x i1>, ptr %runnable.mask, align 1
  %9229 = xor <8 x i1> %9227, splat (i1 true)
  %9230 = and <8 x i1> %9228, %9229
  store <8 x i1> %9230, ptr %runnable.mask, align 1
  %.splatinsert1887 = insertelement <8 x i1> poison, i1 %9218, i64 0
  %.splat1888 = shufflevector <8 x i1> %.splatinsert1887, <8 x i1> poison, <8 x i32> zeroinitializer
  %9231 = select <8 x i1> %.splat1888, <8 x i1> %9213, <8 x i1> zeroinitializer
  %9232 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9233 = extractelement <8 x i32> %9232, i32 %9198
  %9234 = select i1 %9218, i32 %9233, i32 %9194
  store i32 %9234, ptr %current.token, align 4
  %.splatinsert1889 = insertelement <8 x i1> poison, i1 %9208, i64 0
  %.splat1890 = shufflevector <8 x i1> %.splatinsert1889, <8 x i1> poison, <8 x i32> zeroinitializer
  %9235 = select <8 x i1> %.splat1890, <8 x i1> %9231, <8 x i1> %convergence.cascade.flow1881
  %9236 = add i32 %convergence.cascade.depth1882, 1
  %9237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9235)
  %9238 = icmp ult i32 %9236, 8
  %9239 = and i1 %9237, %9238
  %9240 = and i1 %9208, %9239
  %convergence.parent.token1891 = load i32, ptr %current.token, align 4
  %convergence.parent.present1892 = icmp ne i32 %convergence.parent.token1891, 0
  %9241 = and i1 %9240, %convergence.parent.present1892
  br i1 %9241, label %convergence.cascade1877, label %convergence.cascade.exit1878

convergence.cascade.exit1878:                     ; preds = %convergence.cascade1877, %schedule.86
  %convergence.cascade.result1893 = phi <8 x i1> [ %2002, %schedule.86 ], [ %9235, %convergence.cascade1877 ]
  %9242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1893)
  br i1 %9242, label %convergence.target.86.ready, label %scheduler.loop

convergence.target.86.ready:                      ; preds = %convergence.cascade.exit1878
  %9243 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1893)
  %9244 = bitcast <8 x i1> %convergence.cascade.result1893 to i8
  %9245 = call i8 @llvm.cttz.i8(i8 %9244, i1 false)
  %9246 = zext i8 %9245 to i32
  %9247 = select i1 %9243, i32 %9246, i32 0
  %9248 = load <8 x i64>, ptr %.slot56, align 64
  %9249 = select <8 x i1> %convergence.cascade.result1893, <8 x i64> zeroinitializer, <8 x i64> %9248
  store <8 x i64> %9249, ptr %.slot56, align 64
  %9250 = load <8 x float>, ptr %.slot48, align 32
  %9251 = select <8 x i1> %convergence.cascade.result1893, <8 x float> zeroinitializer, <8 x float> %9250
  store <8 x float> %9251, ptr %.slot48, align 32
  store <8 x i1> %convergence.cascade.result1893, ptr %current.mask, align 1
  %9252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1893)
  br i1 %9252, label %schedule.87, label %scheduler.loop

varying.divergent1895:                            ; preds = %schedule.87
  %9253 = load i32, ptr %current.token, align 4
  %9254 = icmp ne i32 %9253, 0
  %9255 = sub i32 %9253, 1
  %9256 = select i1 %9254, i32 %9255, i32 0
  %9257 = load i8, ptr %frame.active, align 1
  %9258 = trunc i32 %9256 to i8
  %9259 = shl i8 1, %9258
  %9260 = and i8 %9257, %9259
  %9261 = icmp ne i8 %9260, 0
  %9262 = load <8 x i32>, ptr %frame.static.id, align 32
  %9263 = extractelement <8 x i32> %9262, i32 %9256
  %9264 = icmp eq i32 %9263, 30
  %9265 = and i1 %9261, %9264
  %9266 = and i1 %9254, %9265
  %9267 = xor i1 %9266, true
  %9268 = and i1 true, %9267
  %9269 = xor i8 %9257, -1
  %9270 = icmp ne i8 %9269, 0
  %9271 = xor i1 %9270, true
  %9272 = and i1 %9268, %9271
  br i1 %9272, label %convergence.overflow.trap1897, label %convergence.overflow.resume1898

varying.coherent1896:                             ; preds = %schedule.87
  br i1 %2013, label %varying.coherent.true1901, label %varying.coherent.false1902

convergence.overflow.trap1897:                    ; preds = %varying.divergent1895
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1898:                  ; preds = %varying.divergent1895
  %9273 = call i8 @llvm.cttz.i8(i8 %9269, i1 false)
  %9274 = zext i8 %9273 to i32
  %9275 = select i1 %9270, i32 %9274, i32 0
  %9276 = trunc i32 %9275 to i8
  %9277 = shl i8 1, %9276
  %9278 = or i8 %9257, %9277
  %9279 = select i1 %9268, i8 %9278, i8 %9257
  store i8 %9279, ptr %frame.active, align 1
  %9280 = load <8 x i32>, ptr %frame.static.id, align 32
  %9281 = extractelement <8 x i32> %9280, i32 %9275
  %9282 = select i1 %9268, i32 30, i32 %9281
  %9283 = load <8 x i32>, ptr %frame.static.id, align 32
  %9284 = insertelement <8 x i32> %9283, i32 %9282, i32 %9275
  store <8 x i32> %9284, ptr %frame.static.id, align 32
  %9285 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9286 = extractelement <8 x i32> %9285, i32 %9275
  %9287 = select i1 %9268, i32 %9253, i32 %9286
  %9288 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9289 = insertelement <8 x i32> %9288, i32 %9287, i32 %9275
  store <8 x i32> %9289, ptr %frame.parent.token, align 32
  %9290 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9275
  %9291 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9275
  %9292 = load <8 x i1>, ptr %9290, align 1
  %9293 = load <8 x i1>, ptr %9291, align 1
  %9294 = select i1 %9268, <8 x i1> %2003, <8 x i1> %9292
  store <8 x i1> %9294, ptr %9290, align 1
  %9295 = select i1 %9268, <8 x i1> zeroinitializer, <8 x i1> %9293
  store <8 x i1> %9295, ptr %9291, align 1
  %9296 = add i32 %9275, 1
  %9297 = select i1 %9266, i32 %9253, i32 %9296
  %9298 = select i1 true, i32 %9297, i32 %9253
  store i32 %9298, ptr %current.token, align 4
  %9299 = load i32, ptr %current.token, align 4
  %9300 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2010)
  %9301 = load i32, ptr %ready.count, align 4
  %9302 = icmp uge i32 %9301, 8
  %9303 = and i1 %9300, %9302
  br i1 %9303, label %ready.overflow.trap1899, label %ready.overflow.resume1900

ready.overflow.trap1899:                          ; preds = %convergence.overflow.resume1898
  call void @llvm.trap()
  unreachable

ready.overflow.resume1900:                        ; preds = %convergence.overflow.resume1898
  %9304 = select i1 %9300, i32 %9301, i32 0
  %9305 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9304
  %9306 = load <8 x i1>, ptr %9305, align 1
  %9307 = select i1 %9300, <8 x i1> %2010, <8 x i1> %9306
  store <8 x i1> %9307, ptr %9305, align 1
  %9308 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9304
  %9309 = load i32, ptr %9308, align 4
  %9310 = select i1 %9300, i32 88, i32 %9309
  store i32 %9310, ptr %9308, align 4
  %9311 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9304
  %9312 = load i32, ptr %9311, align 4
  %9313 = select i1 %9300, i32 %9299, i32 %9312
  store i32 %9313, ptr %9311, align 4
  %9314 = add i32 %9301, 1
  %9315 = select i1 %9300, i32 %9314, i32 %9301
  store i32 %9315, ptr %ready.count, align 4
  %9316 = load <8 x i1>, ptr %runnable.mask, align 1
  %9317 = or <8 x i1> %9316, %2010
  store <8 x i1> %9317, ptr %runnable.mask, align 1
  store <8 x i1> %2012, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1901:                        ; preds = %varying.coherent1896
  store <8 x i1> %2003, ptr %current.mask, align 1
  %9318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2003)
  br i1 %9318, label %schedule.88, label %scheduler.loop

varying.coherent.false1902:                       ; preds = %varying.coherent1896
  store <8 x i1> %2003, ptr %current.mask, align 1
  %9319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2003)
  br i1 %9319, label %schedule.89, label %scheduler.loop

convergence.cascade1907:                          ; preds = %convergence.cascade1907, %schedule.89
  %convergence.cascade.flow1911 = phi <8 x i1> [ %2043, %schedule.89 ], [ %9362, %convergence.cascade1907 ]
  %convergence.cascade.depth1912 = phi i32 [ 0, %schedule.89 ], [ %9363, %convergence.cascade1907 ]
  %9320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1911)
  %9321 = load i32, ptr %current.token, align 4
  %9322 = icmp ne i32 %9321, 0
  %9323 = and i1 %9320, %9322
  %9324 = sub i32 %9321, 1
  %9325 = select i1 %9323, i32 %9324, i32 0
  %9326 = load i8, ptr %frame.active, align 1
  %9327 = trunc i32 %9325 to i8
  %9328 = shl i8 1, %9327
  %9329 = and i8 %9326, %9328
  %9330 = icmp ne i8 %9329, 0
  %9331 = load <8 x i32>, ptr %frame.static.id, align 32
  %9332 = extractelement <8 x i32> %9331, i32 %9325
  %convergence.target.pointer1913 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9332
  %convergence.dynamic.target1914 = load i32, ptr %convergence.target.pointer1913, align 4
  %9333 = icmp eq i32 %convergence.dynamic.target1914, 89
  %9334 = and i1 %9330, %9333
  %9335 = and i1 %9323, %9334
  %9336 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9325
  %9337 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9325
  %9338 = load <8 x i1>, ptr %9336, align 1
  %9339 = load <8 x i1>, ptr %9337, align 1
  %9340 = or <8 x i1> %9339, %convergence.cascade.flow1911
  %9341 = load <8 x i1>, ptr %live.mask, align 1
  %9342 = and <8 x i1> %9338, %9341
  %9343 = icmp eq <8 x i1> %9340, %9342
  %9344 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9343)
  %9345 = and i1 %9335, %9344
  %9346 = select i1 %9345, <8 x i1> zeroinitializer, <8 x i1> %9340
  %9347 = select i1 %9335, <8 x i1> %9346, <8 x i1> %9339
  store <8 x i1> %9347, ptr %9337, align 1
  %9348 = select i1 %9345, <8 x i1> zeroinitializer, <8 x i1> %9338
  store <8 x i1> %9348, ptr %9336, align 1
  %9349 = trunc i32 %9325 to i8
  %9350 = shl i8 1, %9349
  %9351 = xor i8 %9350, -1
  %9352 = and i8 %9326, %9351
  %9353 = select i1 %9345, i8 %9352, i8 %9326
  store i8 %9353, ptr %frame.active, align 1
  %.splatinsert1915 = insertelement <8 x i1> poison, i1 %9335, i64 0
  %.splat1916 = shufflevector <8 x i1> %.splatinsert1915, <8 x i1> poison, <8 x i32> zeroinitializer
  %9354 = and <8 x i1> %convergence.cascade.flow1911, %.splat1916
  %9355 = load <8 x i1>, ptr %runnable.mask, align 1
  %9356 = xor <8 x i1> %9354, splat (i1 true)
  %9357 = and <8 x i1> %9355, %9356
  store <8 x i1> %9357, ptr %runnable.mask, align 1
  %.splatinsert1917 = insertelement <8 x i1> poison, i1 %9345, i64 0
  %.splat1918 = shufflevector <8 x i1> %.splatinsert1917, <8 x i1> poison, <8 x i32> zeroinitializer
  %9358 = select <8 x i1> %.splat1918, <8 x i1> %9340, <8 x i1> zeroinitializer
  %9359 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9360 = extractelement <8 x i32> %9359, i32 %9325
  %9361 = select i1 %9345, i32 %9360, i32 %9321
  store i32 %9361, ptr %current.token, align 4
  %.splatinsert1919 = insertelement <8 x i1> poison, i1 %9335, i64 0
  %.splat1920 = shufflevector <8 x i1> %.splatinsert1919, <8 x i1> poison, <8 x i32> zeroinitializer
  %9362 = select <8 x i1> %.splat1920, <8 x i1> %9358, <8 x i1> %convergence.cascade.flow1911
  %9363 = add i32 %convergence.cascade.depth1912, 1
  %9364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9362)
  %9365 = icmp ult i32 %9363, 8
  %9366 = and i1 %9364, %9365
  %9367 = and i1 %9335, %9366
  %convergence.parent.token1921 = load i32, ptr %current.token, align 4
  %convergence.parent.present1922 = icmp ne i32 %convergence.parent.token1921, 0
  %9368 = and i1 %9367, %convergence.parent.present1922
  br i1 %9368, label %convergence.cascade1907, label %convergence.cascade.exit1908

convergence.cascade.exit1908:                     ; preds = %convergence.cascade1907, %schedule.89
  %convergence.cascade.result1923 = phi <8 x i1> [ %2043, %schedule.89 ], [ %9362, %convergence.cascade1907 ]
  %9369 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1923)
  br i1 %9369, label %convergence.target.89.ready, label %scheduler.loop

convergence.target.89.ready:                      ; preds = %convergence.cascade.exit1908
  %9370 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1923)
  %9371 = bitcast <8 x i1> %convergence.cascade.result1923 to i8
  %9372 = call i8 @llvm.cttz.i8(i8 %9371, i1 false)
  %9373 = zext i8 %9372 to i32
  %9374 = select i1 %9370, i32 %9373, i32 0
  %9375 = load <8 x i64>, ptr %.slot56, align 64
  %9376 = select <8 x i1> %convergence.cascade.result1923, <8 x i64> zeroinitializer, <8 x i64> %9375
  store <8 x i64> %9376, ptr %.slot56, align 64
  %9377 = load <8 x float>, ptr %.slot49, align 32
  %9378 = select <8 x i1> %convergence.cascade.result1923, <8 x float> zeroinitializer, <8 x float> %9377
  store <8 x float> %9378, ptr %.slot49, align 32
  store <8 x i1> %convergence.cascade.result1923, ptr %current.mask, align 1
  %9379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1923)
  br i1 %9379, label %schedule.90, label %scheduler.loop

varying.divergent1925:                            ; preds = %schedule.90
  %9380 = load i32, ptr %current.token, align 4
  %9381 = icmp ne i32 %9380, 0
  %9382 = sub i32 %9380, 1
  %9383 = select i1 %9381, i32 %9382, i32 0
  %9384 = load i8, ptr %frame.active, align 1
  %9385 = trunc i32 %9383 to i8
  %9386 = shl i8 1, %9385
  %9387 = and i8 %9384, %9386
  %9388 = icmp ne i8 %9387, 0
  %9389 = load <8 x i32>, ptr %frame.static.id, align 32
  %9390 = extractelement <8 x i32> %9389, i32 %9383
  %9391 = icmp eq i32 %9390, 31
  %9392 = and i1 %9388, %9391
  %9393 = and i1 %9381, %9392
  %9394 = xor i1 %9393, true
  %9395 = and i1 true, %9394
  %9396 = xor i8 %9384, -1
  %9397 = icmp ne i8 %9396, 0
  %9398 = xor i1 %9397, true
  %9399 = and i1 %9395, %9398
  br i1 %9399, label %convergence.overflow.trap1927, label %convergence.overflow.resume1928

varying.coherent1926:                             ; preds = %schedule.90
  br i1 %2054, label %varying.coherent.true1931, label %varying.coherent.false1932

convergence.overflow.trap1927:                    ; preds = %varying.divergent1925
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1928:                  ; preds = %varying.divergent1925
  %9400 = call i8 @llvm.cttz.i8(i8 %9396, i1 false)
  %9401 = zext i8 %9400 to i32
  %9402 = select i1 %9397, i32 %9401, i32 0
  %9403 = trunc i32 %9402 to i8
  %9404 = shl i8 1, %9403
  %9405 = or i8 %9384, %9404
  %9406 = select i1 %9395, i8 %9405, i8 %9384
  store i8 %9406, ptr %frame.active, align 1
  %9407 = load <8 x i32>, ptr %frame.static.id, align 32
  %9408 = extractelement <8 x i32> %9407, i32 %9402
  %9409 = select i1 %9395, i32 31, i32 %9408
  %9410 = load <8 x i32>, ptr %frame.static.id, align 32
  %9411 = insertelement <8 x i32> %9410, i32 %9409, i32 %9402
  store <8 x i32> %9411, ptr %frame.static.id, align 32
  %9412 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9413 = extractelement <8 x i32> %9412, i32 %9402
  %9414 = select i1 %9395, i32 %9380, i32 %9413
  %9415 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9416 = insertelement <8 x i32> %9415, i32 %9414, i32 %9402
  store <8 x i32> %9416, ptr %frame.parent.token, align 32
  %9417 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9402
  %9418 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9402
  %9419 = load <8 x i1>, ptr %9417, align 1
  %9420 = load <8 x i1>, ptr %9418, align 1
  %9421 = select i1 %9395, <8 x i1> %2044, <8 x i1> %9419
  store <8 x i1> %9421, ptr %9417, align 1
  %9422 = select i1 %9395, <8 x i1> zeroinitializer, <8 x i1> %9420
  store <8 x i1> %9422, ptr %9418, align 1
  %9423 = add i32 %9402, 1
  %9424 = select i1 %9393, i32 %9380, i32 %9423
  %9425 = select i1 true, i32 %9424, i32 %9380
  store i32 %9425, ptr %current.token, align 4
  %9426 = load i32, ptr %current.token, align 4
  %9427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2051)
  %9428 = load i32, ptr %ready.count, align 4
  %9429 = icmp uge i32 %9428, 8
  %9430 = and i1 %9427, %9429
  br i1 %9430, label %ready.overflow.trap1929, label %ready.overflow.resume1930

ready.overflow.trap1929:                          ; preds = %convergence.overflow.resume1928
  call void @llvm.trap()
  unreachable

ready.overflow.resume1930:                        ; preds = %convergence.overflow.resume1928
  %9431 = select i1 %9427, i32 %9428, i32 0
  %9432 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9431
  %9433 = load <8 x i1>, ptr %9432, align 1
  %9434 = select i1 %9427, <8 x i1> %2051, <8 x i1> %9433
  store <8 x i1> %9434, ptr %9432, align 1
  %9435 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9431
  %9436 = load i32, ptr %9435, align 4
  %9437 = select i1 %9427, i32 91, i32 %9436
  store i32 %9437, ptr %9435, align 4
  %9438 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9431
  %9439 = load i32, ptr %9438, align 4
  %9440 = select i1 %9427, i32 %9426, i32 %9439
  store i32 %9440, ptr %9438, align 4
  %9441 = add i32 %9428, 1
  %9442 = select i1 %9427, i32 %9441, i32 %9428
  store i32 %9442, ptr %ready.count, align 4
  %9443 = load <8 x i1>, ptr %runnable.mask, align 1
  %9444 = or <8 x i1> %9443, %2051
  store <8 x i1> %9444, ptr %runnable.mask, align 1
  store <8 x i1> %2053, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1931:                        ; preds = %varying.coherent1926
  store <8 x i1> %2044, ptr %current.mask, align 1
  %9445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2044)
  br i1 %9445, label %schedule.91, label %scheduler.loop

varying.coherent.false1932:                       ; preds = %varying.coherent1926
  store <8 x i1> %2044, ptr %current.mask, align 1
  %9446 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2044)
  br i1 %9446, label %schedule.92, label %scheduler.loop

convergence.cascade1937:                          ; preds = %convergence.cascade1937, %schedule.92
  %convergence.cascade.flow1941 = phi <8 x i1> [ %2084, %schedule.92 ], [ %9489, %convergence.cascade1937 ]
  %convergence.cascade.depth1942 = phi i32 [ 0, %schedule.92 ], [ %9490, %convergence.cascade1937 ]
  %9447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1941)
  %9448 = load i32, ptr %current.token, align 4
  %9449 = icmp ne i32 %9448, 0
  %9450 = and i1 %9447, %9449
  %9451 = sub i32 %9448, 1
  %9452 = select i1 %9450, i32 %9451, i32 0
  %9453 = load i8, ptr %frame.active, align 1
  %9454 = trunc i32 %9452 to i8
  %9455 = shl i8 1, %9454
  %9456 = and i8 %9453, %9455
  %9457 = icmp ne i8 %9456, 0
  %9458 = load <8 x i32>, ptr %frame.static.id, align 32
  %9459 = extractelement <8 x i32> %9458, i32 %9452
  %convergence.target.pointer1943 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9459
  %convergence.dynamic.target1944 = load i32, ptr %convergence.target.pointer1943, align 4
  %9460 = icmp eq i32 %convergence.dynamic.target1944, 92
  %9461 = and i1 %9457, %9460
  %9462 = and i1 %9450, %9461
  %9463 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9452
  %9464 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9452
  %9465 = load <8 x i1>, ptr %9463, align 1
  %9466 = load <8 x i1>, ptr %9464, align 1
  %9467 = or <8 x i1> %9466, %convergence.cascade.flow1941
  %9468 = load <8 x i1>, ptr %live.mask, align 1
  %9469 = and <8 x i1> %9465, %9468
  %9470 = icmp eq <8 x i1> %9467, %9469
  %9471 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9470)
  %9472 = and i1 %9462, %9471
  %9473 = select i1 %9472, <8 x i1> zeroinitializer, <8 x i1> %9467
  %9474 = select i1 %9462, <8 x i1> %9473, <8 x i1> %9466
  store <8 x i1> %9474, ptr %9464, align 1
  %9475 = select i1 %9472, <8 x i1> zeroinitializer, <8 x i1> %9465
  store <8 x i1> %9475, ptr %9463, align 1
  %9476 = trunc i32 %9452 to i8
  %9477 = shl i8 1, %9476
  %9478 = xor i8 %9477, -1
  %9479 = and i8 %9453, %9478
  %9480 = select i1 %9472, i8 %9479, i8 %9453
  store i8 %9480, ptr %frame.active, align 1
  %.splatinsert1945 = insertelement <8 x i1> poison, i1 %9462, i64 0
  %.splat1946 = shufflevector <8 x i1> %.splatinsert1945, <8 x i1> poison, <8 x i32> zeroinitializer
  %9481 = and <8 x i1> %convergence.cascade.flow1941, %.splat1946
  %9482 = load <8 x i1>, ptr %runnable.mask, align 1
  %9483 = xor <8 x i1> %9481, splat (i1 true)
  %9484 = and <8 x i1> %9482, %9483
  store <8 x i1> %9484, ptr %runnable.mask, align 1
  %.splatinsert1947 = insertelement <8 x i1> poison, i1 %9472, i64 0
  %.splat1948 = shufflevector <8 x i1> %.splatinsert1947, <8 x i1> poison, <8 x i32> zeroinitializer
  %9485 = select <8 x i1> %.splat1948, <8 x i1> %9467, <8 x i1> zeroinitializer
  %9486 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9487 = extractelement <8 x i32> %9486, i32 %9452
  %9488 = select i1 %9472, i32 %9487, i32 %9448
  store i32 %9488, ptr %current.token, align 4
  %.splatinsert1949 = insertelement <8 x i1> poison, i1 %9462, i64 0
  %.splat1950 = shufflevector <8 x i1> %.splatinsert1949, <8 x i1> poison, <8 x i32> zeroinitializer
  %9489 = select <8 x i1> %.splat1950, <8 x i1> %9485, <8 x i1> %convergence.cascade.flow1941
  %9490 = add i32 %convergence.cascade.depth1942, 1
  %9491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9489)
  %9492 = icmp ult i32 %9490, 8
  %9493 = and i1 %9491, %9492
  %9494 = and i1 %9462, %9493
  %convergence.parent.token1951 = load i32, ptr %current.token, align 4
  %convergence.parent.present1952 = icmp ne i32 %convergence.parent.token1951, 0
  %9495 = and i1 %9494, %convergence.parent.present1952
  br i1 %9495, label %convergence.cascade1937, label %convergence.cascade.exit1938

convergence.cascade.exit1938:                     ; preds = %convergence.cascade1937, %schedule.92
  %convergence.cascade.result1953 = phi <8 x i1> [ %2084, %schedule.92 ], [ %9489, %convergence.cascade1937 ]
  %9496 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1953)
  br i1 %9496, label %convergence.target.92.ready, label %scheduler.loop

convergence.target.92.ready:                      ; preds = %convergence.cascade.exit1938
  %9497 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1953)
  %9498 = bitcast <8 x i1> %convergence.cascade.result1953 to i8
  %9499 = call i8 @llvm.cttz.i8(i8 %9498, i1 false)
  %9500 = zext i8 %9499 to i32
  %9501 = select i1 %9497, i32 %9500, i32 0
  %.spill.load1954 = load <8 x float>, ptr %.spill286, align 32
  %.state1955 = load <8 x float>, ptr %.slot41, align 32
  %9502 = fadd <8 x float> %.spill.load1954, %.state1955
  %9503 = load <8 x float>, ptr %.spill298, align 32
  %9504 = select <8 x i1> %convergence.cascade.result1953, <8 x float> %9502, <8 x float> %9503
  store <8 x float> %9504, ptr %.spill298, align 32
  %.spill.load1956 = load <8 x float>, ptr %.spill287, align 32
  %.state1957 = load <8 x float>, ptr %.slot47, align 32
  %9505 = fadd <8 x float> %.spill.load1956, %.state1957
  %9506 = load <8 x float>, ptr %.spill299, align 32
  %9507 = select <8 x i1> %convergence.cascade.result1953, <8 x float> %9505, <8 x float> %9506
  store <8 x float> %9507, ptr %.spill299, align 32
  %.spill.load1958 = load <8 x float>, ptr %.spill288, align 32
  %.state1959 = load <8 x float>, ptr %.slot48, align 32
  %9508 = fadd <8 x float> %.spill.load1958, %.state1959
  %9509 = load <8 x float>, ptr %.spill300, align 32
  %9510 = select <8 x i1> %convergence.cascade.result1953, <8 x float> %9508, <8 x float> %9509
  store <8 x float> %9510, ptr %.spill300, align 32
  %.spill.load1960 = load <8 x float>, ptr %.spill289, align 32
  %.state1961 = load <8 x float>, ptr %.slot49, align 32
  %9511 = fadd <8 x float> %.spill.load1960, %.state1961
  %9512 = load <8 x float>, ptr %.spill301, align 32
  %9513 = select <8 x i1> %convergence.cascade.result1953, <8 x float> %9511, <8 x float> %9512
  store <8 x float> %9513, ptr %.spill301, align 32
  %9514 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %9515 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %9516 = extractvalue { <8 x ptr>, <8 x i64> } %9514, 0
  %9517 = select <8 x i1> %convergence.cascade.result1953, <8 x ptr> %9515, <8 x ptr> %9516
  %9518 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %9519 = extractvalue { <8 x ptr>, <8 x i64> } %9514, 1
  %9520 = select <8 x i1> %convergence.cascade.result1953, <8 x i64> %9518, <8 x i64> %9519
  %9521 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9517, 0
  %9522 = insertvalue { <8 x ptr>, <8 x i64> } %9521, <8 x i64> %9520, 1
  store { <8 x ptr>, <8 x i64> } %9522, ptr %tile_snapshot.spill302, align 64
  %9523 = load <8 x i64>, ptr %.slot56, align 64
  %9524 = select <8 x i1> %convergence.cascade.result1953, <8 x i64> zeroinitializer, <8 x i64> %9523
  store <8 x i64> %9524, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result1953, ptr %current.mask, align 1
  %9525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1953)
  br i1 %9525, label %schedule.93, label %scheduler.loop

varying.divergent1963:                            ; preds = %schedule.93
  %9526 = load i32, ptr %current.token, align 4
  %9527 = icmp ne i32 %9526, 0
  %9528 = sub i32 %9526, 1
  %9529 = select i1 %9527, i32 %9528, i32 0
  %9530 = load i8, ptr %frame.active, align 1
  %9531 = trunc i32 %9529 to i8
  %9532 = shl i8 1, %9531
  %9533 = and i8 %9530, %9532
  %9534 = icmp ne i8 %9533, 0
  %9535 = load <8 x i32>, ptr %frame.static.id, align 32
  %9536 = extractelement <8 x i32> %9535, i32 %9529
  %9537 = icmp eq i32 %9536, 32
  %9538 = and i1 %9534, %9537
  %9539 = and i1 %9527, %9538
  %9540 = xor i1 %9539, true
  %9541 = and i1 true, %9540
  %9542 = xor i8 %9530, -1
  %9543 = icmp ne i8 %9542, 0
  %9544 = xor i1 %9543, true
  %9545 = and i1 %9541, %9544
  br i1 %9545, label %convergence.overflow.trap1965, label %convergence.overflow.resume1966

varying.coherent1964:                             ; preds = %schedule.93
  br i1 %2095, label %varying.coherent.true1969, label %varying.coherent.false1970

convergence.overflow.trap1965:                    ; preds = %varying.divergent1963
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1966:                  ; preds = %varying.divergent1963
  %9546 = call i8 @llvm.cttz.i8(i8 %9542, i1 false)
  %9547 = zext i8 %9546 to i32
  %9548 = select i1 %9543, i32 %9547, i32 0
  %9549 = trunc i32 %9548 to i8
  %9550 = shl i8 1, %9549
  %9551 = or i8 %9530, %9550
  %9552 = select i1 %9541, i8 %9551, i8 %9530
  store i8 %9552, ptr %frame.active, align 1
  %9553 = load <8 x i32>, ptr %frame.static.id, align 32
  %9554 = extractelement <8 x i32> %9553, i32 %9548
  %9555 = select i1 %9541, i32 32, i32 %9554
  %9556 = load <8 x i32>, ptr %frame.static.id, align 32
  %9557 = insertelement <8 x i32> %9556, i32 %9555, i32 %9548
  store <8 x i32> %9557, ptr %frame.static.id, align 32
  %9558 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9559 = extractelement <8 x i32> %9558, i32 %9548
  %9560 = select i1 %9541, i32 %9526, i32 %9559
  %9561 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9562 = insertelement <8 x i32> %9561, i32 %9560, i32 %9548
  store <8 x i32> %9562, ptr %frame.parent.token, align 32
  %9563 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9548
  %9564 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9548
  %9565 = load <8 x i1>, ptr %9563, align 1
  %9566 = load <8 x i1>, ptr %9564, align 1
  %9567 = select i1 %9541, <8 x i1> %2085, <8 x i1> %9565
  store <8 x i1> %9567, ptr %9563, align 1
  %9568 = select i1 %9541, <8 x i1> zeroinitializer, <8 x i1> %9566
  store <8 x i1> %9568, ptr %9564, align 1
  %9569 = add i32 %9548, 1
  %9570 = select i1 %9539, i32 %9526, i32 %9569
  %9571 = select i1 true, i32 %9570, i32 %9526
  store i32 %9571, ptr %current.token, align 4
  %9572 = load i32, ptr %current.token, align 4
  %9573 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2092)
  %9574 = load i32, ptr %ready.count, align 4
  %9575 = icmp uge i32 %9574, 8
  %9576 = and i1 %9573, %9575
  br i1 %9576, label %ready.overflow.trap1967, label %ready.overflow.resume1968

ready.overflow.trap1967:                          ; preds = %convergence.overflow.resume1966
  call void @llvm.trap()
  unreachable

ready.overflow.resume1968:                        ; preds = %convergence.overflow.resume1966
  %9577 = select i1 %9573, i32 %9574, i32 0
  %9578 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9577
  %9579 = load <8 x i1>, ptr %9578, align 1
  %9580 = select i1 %9573, <8 x i1> %2092, <8 x i1> %9579
  store <8 x i1> %9580, ptr %9578, align 1
  %9581 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9577
  %9582 = load i32, ptr %9581, align 4
  %9583 = select i1 %9573, i32 94, i32 %9582
  store i32 %9583, ptr %9581, align 4
  %9584 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9577
  %9585 = load i32, ptr %9584, align 4
  %9586 = select i1 %9573, i32 %9572, i32 %9585
  store i32 %9586, ptr %9584, align 4
  %9587 = add i32 %9574, 1
  %9588 = select i1 %9573, i32 %9587, i32 %9574
  store i32 %9588, ptr %ready.count, align 4
  %9589 = load <8 x i1>, ptr %runnable.mask, align 1
  %9590 = or <8 x i1> %9589, %2092
  store <8 x i1> %9590, ptr %runnable.mask, align 1
  store <8 x i1> %2094, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1969:                        ; preds = %varying.coherent1964
  store <8 x i1> %2085, ptr %current.mask, align 1
  %9591 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2085)
  br i1 %9591, label %schedule.94, label %scheduler.loop

varying.coherent.false1970:                       ; preds = %varying.coherent1964
  store <8 x i1> %2085, ptr %current.mask, align 1
  %9592 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2085)
  br i1 %9592, label %schedule.101, label %scheduler.loop

varying.divergent1973:                            ; preds = %schedule.95
  %9593 = load i32, ptr %current.token, align 4
  %9594 = icmp ne i32 %9593, 0
  %9595 = sub i32 %9593, 1
  %9596 = select i1 %9594, i32 %9595, i32 0
  %9597 = load i8, ptr %frame.active, align 1
  %9598 = trunc i32 %9596 to i8
  %9599 = shl i8 1, %9598
  %9600 = and i8 %9597, %9599
  %9601 = icmp ne i8 %9600, 0
  %9602 = load <8 x i32>, ptr %frame.static.id, align 32
  %9603 = extractelement <8 x i32> %9602, i32 %9596
  %9604 = icmp eq i32 %9603, 33
  %9605 = and i1 %9601, %9604
  %9606 = and i1 %9594, %9605
  %9607 = xor i1 %9606, true
  %9608 = and i1 true, %9607
  %9609 = xor i8 %9597, -1
  %9610 = icmp ne i8 %9609, 0
  %9611 = xor i1 %9610, true
  %9612 = and i1 %9608, %9611
  br i1 %9612, label %convergence.overflow.trap1975, label %convergence.overflow.resume1976

varying.coherent1974:                             ; preds = %schedule.95
  br i1 %2120, label %varying.coherent.true1979, label %varying.coherent.false1980

convergence.overflow.trap1975:                    ; preds = %varying.divergent1973
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1976:                  ; preds = %varying.divergent1973
  %9613 = call i8 @llvm.cttz.i8(i8 %9609, i1 false)
  %9614 = zext i8 %9613 to i32
  %9615 = select i1 %9610, i32 %9614, i32 0
  %9616 = trunc i32 %9615 to i8
  %9617 = shl i8 1, %9616
  %9618 = or i8 %9597, %9617
  %9619 = select i1 %9608, i8 %9618, i8 %9597
  store i8 %9619, ptr %frame.active, align 1
  %9620 = load <8 x i32>, ptr %frame.static.id, align 32
  %9621 = extractelement <8 x i32> %9620, i32 %9615
  %9622 = select i1 %9608, i32 33, i32 %9621
  %9623 = load <8 x i32>, ptr %frame.static.id, align 32
  %9624 = insertelement <8 x i32> %9623, i32 %9622, i32 %9615
  store <8 x i32> %9624, ptr %frame.static.id, align 32
  %9625 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9626 = extractelement <8 x i32> %9625, i32 %9615
  %9627 = select i1 %9608, i32 %9593, i32 %9626
  %9628 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9629 = insertelement <8 x i32> %9628, i32 %9627, i32 %9615
  store <8 x i32> %9629, ptr %frame.parent.token, align 32
  %9630 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9615
  %9631 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9615
  %9632 = load <8 x i1>, ptr %9630, align 1
  %9633 = load <8 x i1>, ptr %9631, align 1
  %9634 = select i1 %9608, <8 x i1> %2110, <8 x i1> %9632
  store <8 x i1> %9634, ptr %9630, align 1
  %9635 = select i1 %9608, <8 x i1> zeroinitializer, <8 x i1> %9633
  store <8 x i1> %9635, ptr %9631, align 1
  %9636 = add i32 %9615, 1
  %9637 = select i1 %9606, i32 %9593, i32 %9636
  %9638 = select i1 true, i32 %9637, i32 %9593
  store i32 %9638, ptr %current.token, align 4
  %9639 = load i32, ptr %current.token, align 4
  %9640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2117)
  %9641 = load i32, ptr %ready.count, align 4
  %9642 = icmp uge i32 %9641, 8
  %9643 = and i1 %9640, %9642
  br i1 %9643, label %ready.overflow.trap1977, label %ready.overflow.resume1978

ready.overflow.trap1977:                          ; preds = %convergence.overflow.resume1976
  call void @llvm.trap()
  unreachable

ready.overflow.resume1978:                        ; preds = %convergence.overflow.resume1976
  %9644 = select i1 %9640, i32 %9641, i32 0
  %9645 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9644
  %9646 = load <8 x i1>, ptr %9645, align 1
  %9647 = select i1 %9640, <8 x i1> %2117, <8 x i1> %9646
  store <8 x i1> %9647, ptr %9645, align 1
  %9648 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9644
  %9649 = load i32, ptr %9648, align 4
  %9650 = select i1 %9640, i32 96, i32 %9649
  store i32 %9650, ptr %9648, align 4
  %9651 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9644
  %9652 = load i32, ptr %9651, align 4
  %9653 = select i1 %9640, i32 %9639, i32 %9652
  store i32 %9653, ptr %9651, align 4
  %9654 = add i32 %9641, 1
  %9655 = select i1 %9640, i32 %9654, i32 %9641
  store i32 %9655, ptr %ready.count, align 4
  %9656 = load <8 x i1>, ptr %runnable.mask, align 1
  %9657 = or <8 x i1> %9656, %2117
  store <8 x i1> %9657, ptr %runnable.mask, align 1
  store <8 x i1> %2119, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1979:                        ; preds = %varying.coherent1974
  store <8 x i1> %2110, ptr %current.mask, align 1
  %9658 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2110)
  br i1 %9658, label %schedule.96, label %scheduler.loop

varying.coherent.false1980:                       ; preds = %varying.coherent1974
  store <8 x i1> %2110, ptr %current.mask, align 1
  %9659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2110)
  br i1 %9659, label %schedule.100, label %scheduler.loop

varying.divergent1992:                            ; preds = %schedule.97
  %9660 = load i32, ptr %current.token, align 4
  %9661 = icmp ne i32 %9660, 0
  %9662 = sub i32 %9660, 1
  %9663 = select i1 %9661, i32 %9662, i32 0
  %9664 = load i8, ptr %frame.active, align 1
  %9665 = trunc i32 %9663 to i8
  %9666 = shl i8 1, %9665
  %9667 = and i8 %9664, %9666
  %9668 = icmp ne i8 %9667, 0
  %9669 = load <8 x i32>, ptr %frame.static.id, align 32
  %9670 = extractelement <8 x i32> %9669, i32 %9663
  %9671 = icmp eq i32 %9670, 34
  %9672 = and i1 %9668, %9671
  %9673 = and i1 %9661, %9672
  %9674 = xor i1 %9673, true
  %9675 = and i1 true, %9674
  %9676 = xor i8 %9664, -1
  %9677 = icmp ne i8 %9676, 0
  %9678 = xor i1 %9677, true
  %9679 = and i1 %9675, %9678
  br i1 %9679, label %convergence.overflow.trap1994, label %convergence.overflow.resume1995

varying.coherent1993:                             ; preds = %schedule.97
  br i1 %2294, label %varying.coherent.true1998, label %varying.coherent.false1999

convergence.overflow.trap1994:                    ; preds = %varying.divergent1992
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1995:                  ; preds = %varying.divergent1992
  %9680 = call i8 @llvm.cttz.i8(i8 %9676, i1 false)
  %9681 = zext i8 %9680 to i32
  %9682 = select i1 %9677, i32 %9681, i32 0
  %9683 = trunc i32 %9682 to i8
  %9684 = shl i8 1, %9683
  %9685 = or i8 %9664, %9684
  %9686 = select i1 %9675, i8 %9685, i8 %9664
  store i8 %9686, ptr %frame.active, align 1
  %9687 = load <8 x i32>, ptr %frame.static.id, align 32
  %9688 = extractelement <8 x i32> %9687, i32 %9682
  %9689 = select i1 %9675, i32 34, i32 %9688
  %9690 = load <8 x i32>, ptr %frame.static.id, align 32
  %9691 = insertelement <8 x i32> %9690, i32 %9689, i32 %9682
  store <8 x i32> %9691, ptr %frame.static.id, align 32
  %9692 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9693 = extractelement <8 x i32> %9692, i32 %9682
  %9694 = select i1 %9675, i32 %9660, i32 %9693
  %9695 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9696 = insertelement <8 x i32> %9695, i32 %9694, i32 %9682
  store <8 x i32> %9696, ptr %frame.parent.token, align 32
  %9697 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9682
  %9698 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9682
  %9699 = load <8 x i1>, ptr %9697, align 1
  %9700 = load <8 x i1>, ptr %9698, align 1
  %9701 = select i1 %9675, <8 x i1> %2284, <8 x i1> %9699
  store <8 x i1> %9701, ptr %9697, align 1
  %9702 = select i1 %9675, <8 x i1> zeroinitializer, <8 x i1> %9700
  store <8 x i1> %9702, ptr %9698, align 1
  %9703 = add i32 %9682, 1
  %9704 = select i1 %9673, i32 %9660, i32 %9703
  %9705 = select i1 true, i32 %9704, i32 %9660
  store i32 %9705, ptr %current.token, align 4
  %9706 = load i32, ptr %current.token, align 4
  %9707 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2291)
  %9708 = load i32, ptr %ready.count, align 4
  %9709 = icmp uge i32 %9708, 8
  %9710 = and i1 %9707, %9709
  br i1 %9710, label %ready.overflow.trap1996, label %ready.overflow.resume1997

ready.overflow.trap1996:                          ; preds = %convergence.overflow.resume1995
  call void @llvm.trap()
  unreachable

ready.overflow.resume1997:                        ; preds = %convergence.overflow.resume1995
  %9711 = select i1 %9707, i32 %9708, i32 0
  %9712 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9711
  %9713 = load <8 x i1>, ptr %9712, align 1
  %9714 = select i1 %9707, <8 x i1> %2291, <8 x i1> %9713
  store <8 x i1> %9714, ptr %9712, align 1
  %9715 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9711
  %9716 = load i32, ptr %9715, align 4
  %9717 = select i1 %9707, i32 98, i32 %9716
  store i32 %9717, ptr %9715, align 4
  %9718 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9711
  %9719 = load i32, ptr %9718, align 4
  %9720 = select i1 %9707, i32 %9706, i32 %9719
  store i32 %9720, ptr %9718, align 4
  %9721 = add i32 %9708, 1
  %9722 = select i1 %9707, i32 %9721, i32 %9708
  store i32 %9722, ptr %ready.count, align 4
  %9723 = load <8 x i1>, ptr %runnable.mask, align 1
  %9724 = or <8 x i1> %9723, %2291
  store <8 x i1> %9724, ptr %runnable.mask, align 1
  store <8 x i1> %2293, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1998:                        ; preds = %varying.coherent1993
  store <8 x i1> %2284, ptr %current.mask, align 1
  %9725 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2284)
  br i1 %9725, label %schedule.98, label %scheduler.loop

varying.coherent.false1999:                       ; preds = %varying.coherent1993
  store <8 x i1> %2284, ptr %current.mask, align 1
  %9726 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2284)
  br i1 %9726, label %schedule.99, label %scheduler.loop

convergence.cascade2016:                          ; preds = %convergence.cascade2016, %schedule.99
  %convergence.cascade.flow2020 = phi <8 x i1> [ %2371, %schedule.99 ], [ %9769, %convergence.cascade2016 ]
  %convergence.cascade.depth2021 = phi i32 [ 0, %schedule.99 ], [ %9770, %convergence.cascade2016 ]
  %9727 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2020)
  %9728 = load i32, ptr %current.token, align 4
  %9729 = icmp ne i32 %9728, 0
  %9730 = and i1 %9727, %9729
  %9731 = sub i32 %9728, 1
  %9732 = select i1 %9730, i32 %9731, i32 0
  %9733 = load i8, ptr %frame.active, align 1
  %9734 = trunc i32 %9732 to i8
  %9735 = shl i8 1, %9734
  %9736 = and i8 %9733, %9735
  %9737 = icmp ne i8 %9736, 0
  %9738 = load <8 x i32>, ptr %frame.static.id, align 32
  %9739 = extractelement <8 x i32> %9738, i32 %9732
  %convergence.target.pointer2022 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9739
  %convergence.dynamic.target2023 = load i32, ptr %convergence.target.pointer2022, align 4
  %9740 = icmp eq i32 %convergence.dynamic.target2023, 99
  %9741 = and i1 %9737, %9740
  %9742 = and i1 %9730, %9741
  %9743 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9732
  %9744 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9732
  %9745 = load <8 x i1>, ptr %9743, align 1
  %9746 = load <8 x i1>, ptr %9744, align 1
  %9747 = or <8 x i1> %9746, %convergence.cascade.flow2020
  %9748 = load <8 x i1>, ptr %live.mask, align 1
  %9749 = and <8 x i1> %9745, %9748
  %9750 = icmp eq <8 x i1> %9747, %9749
  %9751 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9750)
  %9752 = and i1 %9742, %9751
  %9753 = select i1 %9752, <8 x i1> zeroinitializer, <8 x i1> %9747
  %9754 = select i1 %9742, <8 x i1> %9753, <8 x i1> %9746
  store <8 x i1> %9754, ptr %9744, align 1
  %9755 = select i1 %9752, <8 x i1> zeroinitializer, <8 x i1> %9745
  store <8 x i1> %9755, ptr %9743, align 1
  %9756 = trunc i32 %9732 to i8
  %9757 = shl i8 1, %9756
  %9758 = xor i8 %9757, -1
  %9759 = and i8 %9733, %9758
  %9760 = select i1 %9752, i8 %9759, i8 %9733
  store i8 %9760, ptr %frame.active, align 1
  %.splatinsert2024 = insertelement <8 x i1> poison, i1 %9742, i64 0
  %.splat2025 = shufflevector <8 x i1> %.splatinsert2024, <8 x i1> poison, <8 x i32> zeroinitializer
  %9761 = and <8 x i1> %convergence.cascade.flow2020, %.splat2025
  %9762 = load <8 x i1>, ptr %runnable.mask, align 1
  %9763 = xor <8 x i1> %9761, splat (i1 true)
  %9764 = and <8 x i1> %9762, %9763
  store <8 x i1> %9764, ptr %runnable.mask, align 1
  %.splatinsert2026 = insertelement <8 x i1> poison, i1 %9752, i64 0
  %.splat2027 = shufflevector <8 x i1> %.splatinsert2026, <8 x i1> poison, <8 x i32> zeroinitializer
  %9765 = select <8 x i1> %.splat2027, <8 x i1> %9747, <8 x i1> zeroinitializer
  %9766 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9767 = extractelement <8 x i32> %9766, i32 %9732
  %9768 = select i1 %9752, i32 %9767, i32 %9728
  store i32 %9768, ptr %current.token, align 4
  %.splatinsert2028 = insertelement <8 x i1> poison, i1 %9742, i64 0
  %.splat2029 = shufflevector <8 x i1> %.splatinsert2028, <8 x i1> poison, <8 x i32> zeroinitializer
  %9769 = select <8 x i1> %.splat2029, <8 x i1> %9765, <8 x i1> %convergence.cascade.flow2020
  %9770 = add i32 %convergence.cascade.depth2021, 1
  %9771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9769)
  %9772 = icmp ult i32 %9770, 8
  %9773 = and i1 %9771, %9772
  %9774 = and i1 %9742, %9773
  %convergence.parent.token2030 = load i32, ptr %current.token, align 4
  %convergence.parent.present2031 = icmp ne i32 %convergence.parent.token2030, 0
  %9775 = and i1 %9774, %convergence.parent.present2031
  br i1 %9775, label %convergence.cascade2016, label %convergence.cascade.exit2017

convergence.cascade.exit2017:                     ; preds = %convergence.cascade2016, %schedule.99
  %convergence.cascade.result2032 = phi <8 x i1> [ %2371, %schedule.99 ], [ %9769, %convergence.cascade2016 ]
  %9776 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2032)
  br i1 %9776, label %convergence.target.99.ready, label %scheduler.loop

convergence.target.99.ready:                      ; preds = %convergence.cascade.exit2017
  %9777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2032)
  %9778 = bitcast <8 x i1> %convergence.cascade.result2032 to i8
  %9779 = call i8 @llvm.cttz.i8(i8 %9778, i1 false)
  %9780 = zext i8 %9779 to i32
  %9781 = select i1 %9777, i32 %9780, i32 0
  %tile_snapshot.spill.load2033 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %9782 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2033, 0
  %9783 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2033, 1
  %.spill.load2034 = load <8 x i64>, ptr %.spill306, align 64
  %9784 = mul <8 x i64> %.spill.load2034, splat (i64 32)
  %9785 = add <8 x i64> %9783, %9784
  %9786 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9782, 0
  %9787 = insertvalue { <8 x ptr>, <8 x i64> } %9786, <8 x i64> %9785, 1
  %.state2035 = load <8 x float>, ptr %.slot41, align 32
  %9788 = extractvalue { <8 x ptr>, <8 x i64> } %9787, 0
  %9789 = extractvalue { <8 x ptr>, <8 x i64> } %9787, 1
  %9790 = getelementptr i8, <8 x ptr> %9788, <8 x i64> %9789
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state2035, <8 x ptr> align 1 %9790, <8 x i1> %convergence.cascade.result2032)
  %tile_snapshot.spill.load2036 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %9791 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2036, 0
  %9792 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2036, 1
  %.spill.load2037 = load <8 x i64>, ptr %.spill309, align 64
  %9793 = mul <8 x i64> %.spill.load2037, splat (i64 32)
  %9794 = add <8 x i64> %9792, %9793
  %9795 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9791, 0
  %9796 = insertvalue { <8 x ptr>, <8 x i64> } %9795, <8 x i64> %9794, 1
  %.state2038 = load <8 x float>, ptr %.slot47, align 32
  %9797 = extractvalue { <8 x ptr>, <8 x i64> } %9796, 0
  %9798 = extractvalue { <8 x ptr>, <8 x i64> } %9796, 1
  %9799 = getelementptr i8, <8 x ptr> %9797, <8 x i64> %9798
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state2038, <8 x ptr> align 1 %9799, <8 x i1> %convergence.cascade.result2032)
  %tile_snapshot.spill.load2039 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %9800 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2039, 0
  %9801 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2039, 1
  %.spill.load2040 = load <8 x i64>, ptr %.spill311, align 64
  %9802 = mul <8 x i64> %.spill.load2040, splat (i64 32)
  %9803 = add <8 x i64> %9801, %9802
  %9804 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9800, 0
  %9805 = insertvalue { <8 x ptr>, <8 x i64> } %9804, <8 x i64> %9803, 1
  %.state2041 = load <8 x float>, ptr %.slot48, align 32
  %9806 = extractvalue { <8 x ptr>, <8 x i64> } %9805, 0
  %9807 = extractvalue { <8 x ptr>, <8 x i64> } %9805, 1
  %9808 = getelementptr i8, <8 x ptr> %9806, <8 x i64> %9807
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state2041, <8 x ptr> align 1 %9808, <8 x i1> %convergence.cascade.result2032)
  %tile_snapshot.spill.load2042 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill302, align 64
  %9809 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2042, 0
  %9810 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2042, 1
  %.spill.load2043 = load <8 x i64>, ptr %.spill313, align 64
  %9811 = mul <8 x i64> %.spill.load2043, splat (i64 32)
  %9812 = add <8 x i64> %9810, %9811
  %9813 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9809, 0
  %9814 = insertvalue { <8 x ptr>, <8 x i64> } %9813, <8 x i64> %9812, 1
  %.state2044 = load <8 x float>, ptr %.slot49, align 32
  %9815 = extractvalue { <8 x ptr>, <8 x i64> } %9814, 0
  %9816 = extractvalue { <8 x ptr>, <8 x i64> } %9814, 1
  %9817 = getelementptr i8, <8 x ptr> %9815, <8 x i64> %9816
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state2044, <8 x ptr> align 1 %9817, <8 x i1> %convergence.cascade.result2032)
  %.state2045 = load <8 x i64>, ptr %.slot305, align 64
  %9818 = add <8 x i64> %.state2045, splat (i64 1)
  %9819 = load <8 x i64>, ptr %.slot305, align 64
  %9820 = select <8 x i1> %convergence.cascade.result2032, <8 x i64> %9818, <8 x i64> %9819
  store <8 x i64> %9820, ptr %.slot305, align 64
  store <8 x i1> %convergence.cascade.result2032, ptr %current.mask, align 1
  %9821 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2032)
  br i1 %9821, label %schedule.95, label %scheduler.loop

convergence.cascade2046:                          ; preds = %convergence.cascade2046, %schedule.100
  %convergence.cascade.flow2050 = phi <8 x i1> [ %2372, %schedule.100 ], [ %9864, %convergence.cascade2046 ]
  %convergence.cascade.depth2051 = phi i32 [ 0, %schedule.100 ], [ %9865, %convergence.cascade2046 ]
  %9822 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2050)
  %9823 = load i32, ptr %current.token, align 4
  %9824 = icmp ne i32 %9823, 0
  %9825 = and i1 %9822, %9824
  %9826 = sub i32 %9823, 1
  %9827 = select i1 %9825, i32 %9826, i32 0
  %9828 = load i8, ptr %frame.active, align 1
  %9829 = trunc i32 %9827 to i8
  %9830 = shl i8 1, %9829
  %9831 = and i8 %9828, %9830
  %9832 = icmp ne i8 %9831, 0
  %9833 = load <8 x i32>, ptr %frame.static.id, align 32
  %9834 = extractelement <8 x i32> %9833, i32 %9827
  %convergence.target.pointer2052 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9834
  %convergence.dynamic.target2053 = load i32, ptr %convergence.target.pointer2052, align 4
  %9835 = icmp eq i32 %convergence.dynamic.target2053, 100
  %9836 = and i1 %9832, %9835
  %9837 = and i1 %9825, %9836
  %9838 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9827
  %9839 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9827
  %9840 = load <8 x i1>, ptr %9838, align 1
  %9841 = load <8 x i1>, ptr %9839, align 1
  %9842 = or <8 x i1> %9841, %convergence.cascade.flow2050
  %9843 = load <8 x i1>, ptr %live.mask, align 1
  %9844 = and <8 x i1> %9840, %9843
  %9845 = icmp eq <8 x i1> %9842, %9844
  %9846 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9845)
  %9847 = and i1 %9837, %9846
  %9848 = select i1 %9847, <8 x i1> zeroinitializer, <8 x i1> %9842
  %9849 = select i1 %9837, <8 x i1> %9848, <8 x i1> %9841
  store <8 x i1> %9849, ptr %9839, align 1
  %9850 = select i1 %9847, <8 x i1> zeroinitializer, <8 x i1> %9840
  store <8 x i1> %9850, ptr %9838, align 1
  %9851 = trunc i32 %9827 to i8
  %9852 = shl i8 1, %9851
  %9853 = xor i8 %9852, -1
  %9854 = and i8 %9828, %9853
  %9855 = select i1 %9847, i8 %9854, i8 %9828
  store i8 %9855, ptr %frame.active, align 1
  %.splatinsert2054 = insertelement <8 x i1> poison, i1 %9837, i64 0
  %.splat2055 = shufflevector <8 x i1> %.splatinsert2054, <8 x i1> poison, <8 x i32> zeroinitializer
  %9856 = and <8 x i1> %convergence.cascade.flow2050, %.splat2055
  %9857 = load <8 x i1>, ptr %runnable.mask, align 1
  %9858 = xor <8 x i1> %9856, splat (i1 true)
  %9859 = and <8 x i1> %9857, %9858
  store <8 x i1> %9859, ptr %runnable.mask, align 1
  %.splatinsert2056 = insertelement <8 x i1> poison, i1 %9847, i64 0
  %.splat2057 = shufflevector <8 x i1> %.splatinsert2056, <8 x i1> poison, <8 x i32> zeroinitializer
  %9860 = select <8 x i1> %.splat2057, <8 x i1> %9842, <8 x i1> zeroinitializer
  %9861 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9862 = extractelement <8 x i32> %9861, i32 %9827
  %9863 = select i1 %9847, i32 %9862, i32 %9823
  store i32 %9863, ptr %current.token, align 4
  %.splatinsert2058 = insertelement <8 x i1> poison, i1 %9837, i64 0
  %.splat2059 = shufflevector <8 x i1> %.splatinsert2058, <8 x i1> poison, <8 x i32> zeroinitializer
  %9864 = select <8 x i1> %.splat2059, <8 x i1> %9860, <8 x i1> %convergence.cascade.flow2050
  %9865 = add i32 %convergence.cascade.depth2051, 1
  %9866 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9864)
  %9867 = icmp ult i32 %9865, 8
  %9868 = and i1 %9866, %9867
  %9869 = and i1 %9837, %9868
  %convergence.parent.token2060 = load i32, ptr %current.token, align 4
  %convergence.parent.present2061 = icmp ne i32 %convergence.parent.token2060, 0
  %9870 = and i1 %9869, %convergence.parent.present2061
  br i1 %9870, label %convergence.cascade2046, label %convergence.cascade.exit2047

convergence.cascade.exit2047:                     ; preds = %convergence.cascade2046, %schedule.100
  %convergence.cascade.result2062 = phi <8 x i1> [ %2372, %schedule.100 ], [ %9864, %convergence.cascade2046 ]
  %9871 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2062)
  br i1 %9871, label %convergence.target.100.ready, label %scheduler.loop

convergence.target.100.ready:                     ; preds = %convergence.cascade.exit2047
  %9872 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2062)
  %9873 = bitcast <8 x i1> %convergence.cascade.result2062 to i8
  %9874 = call i8 @llvm.cttz.i8(i8 %9873, i1 false)
  %9875 = zext i8 %9874 to i32
  %9876 = select i1 %9872, i32 %9875, i32 0
  %.state2063 = load <8 x i64>, ptr %.slot56, align 64
  %9877 = add <8 x i64> %.state2063, splat (i64 1)
  %9878 = load <8 x i64>, ptr %.slot56, align 64
  %9879 = select <8 x i1> %convergence.cascade.result2062, <8 x i64> %9877, <8 x i64> %9878
  store <8 x i64> %9879, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result2062, ptr %current.mask, align 1
  %9880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2062)
  br i1 %9880, label %schedule.93, label %scheduler.loop

convergence.cascade2064:                          ; preds = %convergence.cascade2064, %schedule.101
  %convergence.cascade.flow2068 = phi <8 x i1> [ %2373, %schedule.101 ], [ %9923, %convergence.cascade2064 ]
  %convergence.cascade.depth2069 = phi i32 [ 0, %schedule.101 ], [ %9924, %convergence.cascade2064 ]
  %9881 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2068)
  %9882 = load i32, ptr %current.token, align 4
  %9883 = icmp ne i32 %9882, 0
  %9884 = and i1 %9881, %9883
  %9885 = sub i32 %9882, 1
  %9886 = select i1 %9884, i32 %9885, i32 0
  %9887 = load i8, ptr %frame.active, align 1
  %9888 = trunc i32 %9886 to i8
  %9889 = shl i8 1, %9888
  %9890 = and i8 %9887, %9889
  %9891 = icmp ne i8 %9890, 0
  %9892 = load <8 x i32>, ptr %frame.static.id, align 32
  %9893 = extractelement <8 x i32> %9892, i32 %9886
  %convergence.target.pointer2070 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %9893
  %convergence.dynamic.target2071 = load i32, ptr %convergence.target.pointer2070, align 4
  %9894 = icmp eq i32 %convergence.dynamic.target2071, 101
  %9895 = and i1 %9891, %9894
  %9896 = and i1 %9884, %9895
  %9897 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9886
  %9898 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9886
  %9899 = load <8 x i1>, ptr %9897, align 1
  %9900 = load <8 x i1>, ptr %9898, align 1
  %9901 = or <8 x i1> %9900, %convergence.cascade.flow2068
  %9902 = load <8 x i1>, ptr %live.mask, align 1
  %9903 = and <8 x i1> %9899, %9902
  %9904 = icmp eq <8 x i1> %9901, %9903
  %9905 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9904)
  %9906 = and i1 %9896, %9905
  %9907 = select i1 %9906, <8 x i1> zeroinitializer, <8 x i1> %9901
  %9908 = select i1 %9896, <8 x i1> %9907, <8 x i1> %9900
  store <8 x i1> %9908, ptr %9898, align 1
  %9909 = select i1 %9906, <8 x i1> zeroinitializer, <8 x i1> %9899
  store <8 x i1> %9909, ptr %9897, align 1
  %9910 = trunc i32 %9886 to i8
  %9911 = shl i8 1, %9910
  %9912 = xor i8 %9911, -1
  %9913 = and i8 %9887, %9912
  %9914 = select i1 %9906, i8 %9913, i8 %9887
  store i8 %9914, ptr %frame.active, align 1
  %.splatinsert2072 = insertelement <8 x i1> poison, i1 %9896, i64 0
  %.splat2073 = shufflevector <8 x i1> %.splatinsert2072, <8 x i1> poison, <8 x i32> zeroinitializer
  %9915 = and <8 x i1> %convergence.cascade.flow2068, %.splat2073
  %9916 = load <8 x i1>, ptr %runnable.mask, align 1
  %9917 = xor <8 x i1> %9915, splat (i1 true)
  %9918 = and <8 x i1> %9916, %9917
  store <8 x i1> %9918, ptr %runnable.mask, align 1
  %.splatinsert2074 = insertelement <8 x i1> poison, i1 %9906, i64 0
  %.splat2075 = shufflevector <8 x i1> %.splatinsert2074, <8 x i1> poison, <8 x i32> zeroinitializer
  %9919 = select <8 x i1> %.splat2075, <8 x i1> %9901, <8 x i1> zeroinitializer
  %9920 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9921 = extractelement <8 x i32> %9920, i32 %9886
  %9922 = select i1 %9906, i32 %9921, i32 %9882
  store i32 %9922, ptr %current.token, align 4
  %.splatinsert2076 = insertelement <8 x i1> poison, i1 %9896, i64 0
  %.splat2077 = shufflevector <8 x i1> %.splatinsert2076, <8 x i1> poison, <8 x i32> zeroinitializer
  %9923 = select <8 x i1> %.splat2077, <8 x i1> %9919, <8 x i1> %convergence.cascade.flow2068
  %9924 = add i32 %convergence.cascade.depth2069, 1
  %9925 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9923)
  %9926 = icmp ult i32 %9924, 8
  %9927 = and i1 %9925, %9926
  %9928 = and i1 %9896, %9927
  %convergence.parent.token2078 = load i32, ptr %current.token, align 4
  %convergence.parent.present2079 = icmp ne i32 %convergence.parent.token2078, 0
  %9929 = and i1 %9928, %convergence.parent.present2079
  br i1 %9929, label %convergence.cascade2064, label %convergence.cascade.exit2065

convergence.cascade.exit2065:                     ; preds = %convergence.cascade2064, %schedule.101
  %convergence.cascade.result2080 = phi <8 x i1> [ %2373, %schedule.101 ], [ %9923, %convergence.cascade2064 ]
  %9930 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2080)
  br i1 %9930, label %convergence.target.101.ready, label %scheduler.loop

convergence.target.101.ready:                     ; preds = %convergence.cascade.exit2065
  %9931 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2080)
  %9932 = bitcast <8 x i1> %convergence.cascade.result2080 to i8
  %9933 = call i8 @llvm.cttz.i8(i8 %9932, i1 false)
  %9934 = zext i8 %9933 to i32
  %9935 = select i1 %9931, i32 %9934, i32 0
  %9936 = load <8 x i64>, ptr %.slot56, align 64
  %9937 = select <8 x i1> %convergence.cascade.result2080, <8 x i64> zeroinitializer, <8 x i64> %9936
  store <8 x i64> %9937, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result2080, ptr %current.mask, align 1
  %9938 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2080)
  br i1 %9938, label %schedule.102, label %scheduler.loop

varying.divergent2082:                            ; preds = %schedule.102
  %9939 = load i32, ptr %current.token, align 4
  %9940 = icmp ne i32 %9939, 0
  %9941 = sub i32 %9939, 1
  %9942 = select i1 %9940, i32 %9941, i32 0
  %9943 = load i8, ptr %frame.active, align 1
  %9944 = trunc i32 %9942 to i8
  %9945 = shl i8 1, %9944
  %9946 = and i8 %9943, %9945
  %9947 = icmp ne i8 %9946, 0
  %9948 = load <8 x i32>, ptr %frame.static.id, align 32
  %9949 = extractelement <8 x i32> %9948, i32 %9942
  %9950 = icmp eq i32 %9949, 35
  %9951 = and i1 %9947, %9950
  %9952 = and i1 %9940, %9951
  %9953 = xor i1 %9952, true
  %9954 = and i1 true, %9953
  %9955 = xor i8 %9943, -1
  %9956 = icmp ne i8 %9955, 0
  %9957 = xor i1 %9956, true
  %9958 = and i1 %9954, %9957
  br i1 %9958, label %convergence.overflow.trap2084, label %convergence.overflow.resume2085

varying.coherent2083:                             ; preds = %schedule.102
  br i1 %2384, label %varying.coherent.true2088, label %varying.coherent.false2089

convergence.overflow.trap2084:                    ; preds = %varying.divergent2082
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2085:                  ; preds = %varying.divergent2082
  %9959 = call i8 @llvm.cttz.i8(i8 %9955, i1 false)
  %9960 = zext i8 %9959 to i32
  %9961 = select i1 %9956, i32 %9960, i32 0
  %9962 = trunc i32 %9961 to i8
  %9963 = shl i8 1, %9962
  %9964 = or i8 %9943, %9963
  %9965 = select i1 %9954, i8 %9964, i8 %9943
  store i8 %9965, ptr %frame.active, align 1
  %9966 = load <8 x i32>, ptr %frame.static.id, align 32
  %9967 = extractelement <8 x i32> %9966, i32 %9961
  %9968 = select i1 %9954, i32 35, i32 %9967
  %9969 = load <8 x i32>, ptr %frame.static.id, align 32
  %9970 = insertelement <8 x i32> %9969, i32 %9968, i32 %9961
  store <8 x i32> %9970, ptr %frame.static.id, align 32
  %9971 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9972 = extractelement <8 x i32> %9971, i32 %9961
  %9973 = select i1 %9954, i32 %9939, i32 %9972
  %9974 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9975 = insertelement <8 x i32> %9974, i32 %9973, i32 %9961
  store <8 x i32> %9975, ptr %frame.parent.token, align 32
  %9976 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9961
  %9977 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9961
  %9978 = load <8 x i1>, ptr %9976, align 1
  %9979 = load <8 x i1>, ptr %9977, align 1
  %9980 = select i1 %9954, <8 x i1> %2374, <8 x i1> %9978
  store <8 x i1> %9980, ptr %9976, align 1
  %9981 = select i1 %9954, <8 x i1> zeroinitializer, <8 x i1> %9979
  store <8 x i1> %9981, ptr %9977, align 1
  %9982 = add i32 %9961, 1
  %9983 = select i1 %9952, i32 %9939, i32 %9982
  %9984 = select i1 true, i32 %9983, i32 %9939
  store i32 %9984, ptr %current.token, align 4
  %9985 = load i32, ptr %current.token, align 4
  %9986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2381)
  %9987 = load i32, ptr %ready.count, align 4
  %9988 = icmp uge i32 %9987, 8
  %9989 = and i1 %9986, %9988
  br i1 %9989, label %ready.overflow.trap2086, label %ready.overflow.resume2087

ready.overflow.trap2086:                          ; preds = %convergence.overflow.resume2085
  call void @llvm.trap()
  unreachable

ready.overflow.resume2087:                        ; preds = %convergence.overflow.resume2085
  %9990 = select i1 %9986, i32 %9987, i32 0
  %9991 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9990
  %9992 = load <8 x i1>, ptr %9991, align 1
  %9993 = select i1 %9986, <8 x i1> %2381, <8 x i1> %9992
  store <8 x i1> %9993, ptr %9991, align 1
  %9994 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9990
  %9995 = load i32, ptr %9994, align 4
  %9996 = select i1 %9986, i32 103, i32 %9995
  store i32 %9996, ptr %9994, align 4
  %9997 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9990
  %9998 = load i32, ptr %9997, align 4
  %9999 = select i1 %9986, i32 %9985, i32 %9998
  store i32 %9999, ptr %9997, align 4
  %10000 = add i32 %9987, 1
  %10001 = select i1 %9986, i32 %10000, i32 %9987
  store i32 %10001, ptr %ready.count, align 4
  %10002 = load <8 x i1>, ptr %runnable.mask, align 1
  %10003 = or <8 x i1> %10002, %2381
  store <8 x i1> %10003, ptr %runnable.mask, align 1
  store <8 x i1> %2383, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2088:                        ; preds = %varying.coherent2083
  store <8 x i1> %2374, ptr %current.mask, align 1
  %10004 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2374)
  br i1 %10004, label %schedule.103, label %scheduler.loop

varying.coherent.false2089:                       ; preds = %varying.coherent2083
  store <8 x i1> %2374, ptr %current.mask, align 1
  %10005 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2374)
  br i1 %10005, label %schedule.104, label %scheduler.loop

convergence.cascade2095:                          ; preds = %convergence.cascade2095, %schedule.104
  %convergence.cascade.flow2099 = phi <8 x i1> [ %2416, %schedule.104 ], [ %10048, %convergence.cascade2095 ]
  %convergence.cascade.depth2100 = phi i32 [ 0, %schedule.104 ], [ %10049, %convergence.cascade2095 ]
  %10006 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2099)
  %10007 = load i32, ptr %current.token, align 4
  %10008 = icmp ne i32 %10007, 0
  %10009 = and i1 %10006, %10008
  %10010 = sub i32 %10007, 1
  %10011 = select i1 %10009, i32 %10010, i32 0
  %10012 = load i8, ptr %frame.active, align 1
  %10013 = trunc i32 %10011 to i8
  %10014 = shl i8 1, %10013
  %10015 = and i8 %10012, %10014
  %10016 = icmp ne i8 %10015, 0
  %10017 = load <8 x i32>, ptr %frame.static.id, align 32
  %10018 = extractelement <8 x i32> %10017, i32 %10011
  %convergence.target.pointer2101 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10018
  %convergence.dynamic.target2102 = load i32, ptr %convergence.target.pointer2101, align 4
  %10019 = icmp eq i32 %convergence.dynamic.target2102, 104
  %10020 = and i1 %10016, %10019
  %10021 = and i1 %10009, %10020
  %10022 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10011
  %10023 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10011
  %10024 = load <8 x i1>, ptr %10022, align 1
  %10025 = load <8 x i1>, ptr %10023, align 1
  %10026 = or <8 x i1> %10025, %convergence.cascade.flow2099
  %10027 = load <8 x i1>, ptr %live.mask, align 1
  %10028 = and <8 x i1> %10024, %10027
  %10029 = icmp eq <8 x i1> %10026, %10028
  %10030 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10029)
  %10031 = and i1 %10021, %10030
  %10032 = select i1 %10031, <8 x i1> zeroinitializer, <8 x i1> %10026
  %10033 = select i1 %10021, <8 x i1> %10032, <8 x i1> %10025
  store <8 x i1> %10033, ptr %10023, align 1
  %10034 = select i1 %10031, <8 x i1> zeroinitializer, <8 x i1> %10024
  store <8 x i1> %10034, ptr %10022, align 1
  %10035 = trunc i32 %10011 to i8
  %10036 = shl i8 1, %10035
  %10037 = xor i8 %10036, -1
  %10038 = and i8 %10012, %10037
  %10039 = select i1 %10031, i8 %10038, i8 %10012
  store i8 %10039, ptr %frame.active, align 1
  %.splatinsert2103 = insertelement <8 x i1> poison, i1 %10021, i64 0
  %.splat2104 = shufflevector <8 x i1> %.splatinsert2103, <8 x i1> poison, <8 x i32> zeroinitializer
  %10040 = and <8 x i1> %convergence.cascade.flow2099, %.splat2104
  %10041 = load <8 x i1>, ptr %runnable.mask, align 1
  %10042 = xor <8 x i1> %10040, splat (i1 true)
  %10043 = and <8 x i1> %10041, %10042
  store <8 x i1> %10043, ptr %runnable.mask, align 1
  %.splatinsert2105 = insertelement <8 x i1> poison, i1 %10031, i64 0
  %.splat2106 = shufflevector <8 x i1> %.splatinsert2105, <8 x i1> poison, <8 x i32> zeroinitializer
  %10044 = select <8 x i1> %.splat2106, <8 x i1> %10026, <8 x i1> zeroinitializer
  %10045 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10046 = extractelement <8 x i32> %10045, i32 %10011
  %10047 = select i1 %10031, i32 %10046, i32 %10007
  store i32 %10047, ptr %current.token, align 4
  %.splatinsert2107 = insertelement <8 x i1> poison, i1 %10021, i64 0
  %.splat2108 = shufflevector <8 x i1> %.splatinsert2107, <8 x i1> poison, <8 x i32> zeroinitializer
  %10048 = select <8 x i1> %.splat2108, <8 x i1> %10044, <8 x i1> %convergence.cascade.flow2099
  %10049 = add i32 %convergence.cascade.depth2100, 1
  %10050 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10048)
  %10051 = icmp ult i32 %10049, 8
  %10052 = and i1 %10050, %10051
  %10053 = and i1 %10021, %10052
  %convergence.parent.token2109 = load i32, ptr %current.token, align 4
  %convergence.parent.present2110 = icmp ne i32 %convergence.parent.token2109, 0
  %10054 = and i1 %10053, %convergence.parent.present2110
  br i1 %10054, label %convergence.cascade2095, label %convergence.cascade.exit2096

convergence.cascade.exit2096:                     ; preds = %convergence.cascade2095, %schedule.104
  %convergence.cascade.result2111 = phi <8 x i1> [ %2416, %schedule.104 ], [ %10048, %convergence.cascade2095 ]
  %10055 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2111)
  br i1 %10055, label %convergence.target.104.ready, label %scheduler.loop

convergence.target.104.ready:                     ; preds = %convergence.cascade.exit2096
  %10056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2111)
  %10057 = bitcast <8 x i1> %convergence.cascade.result2111 to i8
  %10058 = call i8 @llvm.cttz.i8(i8 %10057, i1 false)
  %10059 = zext i8 %10058 to i32
  %10060 = select i1 %10056, i32 %10059, i32 0
  %10061 = load <8 x i64>, ptr %.slot56, align 64
  %10062 = select <8 x i1> %convergence.cascade.result2111, <8 x i64> zeroinitializer, <8 x i64> %10061
  store <8 x i64> %10062, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result2111, ptr %current.mask, align 1
  %10063 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2111)
  br i1 %10063, label %schedule.105, label %scheduler.loop

varying.divergent2113:                            ; preds = %schedule.105
  %10064 = load i32, ptr %current.token, align 4
  %10065 = icmp ne i32 %10064, 0
  %10066 = sub i32 %10064, 1
  %10067 = select i1 %10065, i32 %10066, i32 0
  %10068 = load i8, ptr %frame.active, align 1
  %10069 = trunc i32 %10067 to i8
  %10070 = shl i8 1, %10069
  %10071 = and i8 %10068, %10070
  %10072 = icmp ne i8 %10071, 0
  %10073 = load <8 x i32>, ptr %frame.static.id, align 32
  %10074 = extractelement <8 x i32> %10073, i32 %10067
  %10075 = icmp eq i32 %10074, 36
  %10076 = and i1 %10072, %10075
  %10077 = and i1 %10065, %10076
  %10078 = xor i1 %10077, true
  %10079 = and i1 true, %10078
  %10080 = xor i8 %10068, -1
  %10081 = icmp ne i8 %10080, 0
  %10082 = xor i1 %10081, true
  %10083 = and i1 %10079, %10082
  br i1 %10083, label %convergence.overflow.trap2115, label %convergence.overflow.resume2116

varying.coherent2114:                             ; preds = %schedule.105
  br i1 %2427, label %varying.coherent.true2119, label %varying.coherent.false2120

convergence.overflow.trap2115:                    ; preds = %varying.divergent2113
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2116:                  ; preds = %varying.divergent2113
  %10084 = call i8 @llvm.cttz.i8(i8 %10080, i1 false)
  %10085 = zext i8 %10084 to i32
  %10086 = select i1 %10081, i32 %10085, i32 0
  %10087 = trunc i32 %10086 to i8
  %10088 = shl i8 1, %10087
  %10089 = or i8 %10068, %10088
  %10090 = select i1 %10079, i8 %10089, i8 %10068
  store i8 %10090, ptr %frame.active, align 1
  %10091 = load <8 x i32>, ptr %frame.static.id, align 32
  %10092 = extractelement <8 x i32> %10091, i32 %10086
  %10093 = select i1 %10079, i32 36, i32 %10092
  %10094 = load <8 x i32>, ptr %frame.static.id, align 32
  %10095 = insertelement <8 x i32> %10094, i32 %10093, i32 %10086
  store <8 x i32> %10095, ptr %frame.static.id, align 32
  %10096 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10097 = extractelement <8 x i32> %10096, i32 %10086
  %10098 = select i1 %10079, i32 %10064, i32 %10097
  %10099 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10100 = insertelement <8 x i32> %10099, i32 %10098, i32 %10086
  store <8 x i32> %10100, ptr %frame.parent.token, align 32
  %10101 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10086
  %10102 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10086
  %10103 = load <8 x i1>, ptr %10101, align 1
  %10104 = load <8 x i1>, ptr %10102, align 1
  %10105 = select i1 %10079, <8 x i1> %2417, <8 x i1> %10103
  store <8 x i1> %10105, ptr %10101, align 1
  %10106 = select i1 %10079, <8 x i1> zeroinitializer, <8 x i1> %10104
  store <8 x i1> %10106, ptr %10102, align 1
  %10107 = add i32 %10086, 1
  %10108 = select i1 %10077, i32 %10064, i32 %10107
  %10109 = select i1 true, i32 %10108, i32 %10064
  store i32 %10109, ptr %current.token, align 4
  %10110 = load i32, ptr %current.token, align 4
  %10111 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2424)
  %10112 = load i32, ptr %ready.count, align 4
  %10113 = icmp uge i32 %10112, 8
  %10114 = and i1 %10111, %10113
  br i1 %10114, label %ready.overflow.trap2117, label %ready.overflow.resume2118

ready.overflow.trap2117:                          ; preds = %convergence.overflow.resume2116
  call void @llvm.trap()
  unreachable

ready.overflow.resume2118:                        ; preds = %convergence.overflow.resume2116
  %10115 = select i1 %10111, i32 %10112, i32 0
  %10116 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10115
  %10117 = load <8 x i1>, ptr %10116, align 1
  %10118 = select i1 %10111, <8 x i1> %2424, <8 x i1> %10117
  store <8 x i1> %10118, ptr %10116, align 1
  %10119 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10115
  %10120 = load i32, ptr %10119, align 4
  %10121 = select i1 %10111, i32 106, i32 %10120
  store i32 %10121, ptr %10119, align 4
  %10122 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10115
  %10123 = load i32, ptr %10122, align 4
  %10124 = select i1 %10111, i32 %10110, i32 %10123
  store i32 %10124, ptr %10122, align 4
  %10125 = add i32 %10112, 1
  %10126 = select i1 %10111, i32 %10125, i32 %10112
  store i32 %10126, ptr %ready.count, align 4
  %10127 = load <8 x i1>, ptr %runnable.mask, align 1
  %10128 = or <8 x i1> %10127, %2424
  store <8 x i1> %10128, ptr %runnable.mask, align 1
  store <8 x i1> %2426, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2119:                        ; preds = %varying.coherent2114
  store <8 x i1> %2417, ptr %current.mask, align 1
  %10129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2417)
  br i1 %10129, label %schedule.106, label %scheduler.loop

varying.coherent.false2120:                       ; preds = %varying.coherent2114
  store <8 x i1> %2417, ptr %current.mask, align 1
  %10130 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2417)
  br i1 %10130, label %schedule.107, label %scheduler.loop

convergence.cascade2126:                          ; preds = %convergence.cascade2126, %schedule.107
  %convergence.cascade.flow2130 = phi <8 x i1> [ %2459, %schedule.107 ], [ %10173, %convergence.cascade2126 ]
  %convergence.cascade.depth2131 = phi i32 [ 0, %schedule.107 ], [ %10174, %convergence.cascade2126 ]
  %10131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2130)
  %10132 = load i32, ptr %current.token, align 4
  %10133 = icmp ne i32 %10132, 0
  %10134 = and i1 %10131, %10133
  %10135 = sub i32 %10132, 1
  %10136 = select i1 %10134, i32 %10135, i32 0
  %10137 = load i8, ptr %frame.active, align 1
  %10138 = trunc i32 %10136 to i8
  %10139 = shl i8 1, %10138
  %10140 = and i8 %10137, %10139
  %10141 = icmp ne i8 %10140, 0
  %10142 = load <8 x i32>, ptr %frame.static.id, align 32
  %10143 = extractelement <8 x i32> %10142, i32 %10136
  %convergence.target.pointer2132 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10143
  %convergence.dynamic.target2133 = load i32, ptr %convergence.target.pointer2132, align 4
  %10144 = icmp eq i32 %convergence.dynamic.target2133, 107
  %10145 = and i1 %10141, %10144
  %10146 = and i1 %10134, %10145
  %10147 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10136
  %10148 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10136
  %10149 = load <8 x i1>, ptr %10147, align 1
  %10150 = load <8 x i1>, ptr %10148, align 1
  %10151 = or <8 x i1> %10150, %convergence.cascade.flow2130
  %10152 = load <8 x i1>, ptr %live.mask, align 1
  %10153 = and <8 x i1> %10149, %10152
  %10154 = icmp eq <8 x i1> %10151, %10153
  %10155 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10154)
  %10156 = and i1 %10146, %10155
  %10157 = select i1 %10156, <8 x i1> zeroinitializer, <8 x i1> %10151
  %10158 = select i1 %10146, <8 x i1> %10157, <8 x i1> %10150
  store <8 x i1> %10158, ptr %10148, align 1
  %10159 = select i1 %10156, <8 x i1> zeroinitializer, <8 x i1> %10149
  store <8 x i1> %10159, ptr %10147, align 1
  %10160 = trunc i32 %10136 to i8
  %10161 = shl i8 1, %10160
  %10162 = xor i8 %10161, -1
  %10163 = and i8 %10137, %10162
  %10164 = select i1 %10156, i8 %10163, i8 %10137
  store i8 %10164, ptr %frame.active, align 1
  %.splatinsert2134 = insertelement <8 x i1> poison, i1 %10146, i64 0
  %.splat2135 = shufflevector <8 x i1> %.splatinsert2134, <8 x i1> poison, <8 x i32> zeroinitializer
  %10165 = and <8 x i1> %convergence.cascade.flow2130, %.splat2135
  %10166 = load <8 x i1>, ptr %runnable.mask, align 1
  %10167 = xor <8 x i1> %10165, splat (i1 true)
  %10168 = and <8 x i1> %10166, %10167
  store <8 x i1> %10168, ptr %runnable.mask, align 1
  %.splatinsert2136 = insertelement <8 x i1> poison, i1 %10156, i64 0
  %.splat2137 = shufflevector <8 x i1> %.splatinsert2136, <8 x i1> poison, <8 x i32> zeroinitializer
  %10169 = select <8 x i1> %.splat2137, <8 x i1> %10151, <8 x i1> zeroinitializer
  %10170 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10171 = extractelement <8 x i32> %10170, i32 %10136
  %10172 = select i1 %10156, i32 %10171, i32 %10132
  store i32 %10172, ptr %current.token, align 4
  %.splatinsert2138 = insertelement <8 x i1> poison, i1 %10146, i64 0
  %.splat2139 = shufflevector <8 x i1> %.splatinsert2138, <8 x i1> poison, <8 x i32> zeroinitializer
  %10173 = select <8 x i1> %.splat2139, <8 x i1> %10169, <8 x i1> %convergence.cascade.flow2130
  %10174 = add i32 %convergence.cascade.depth2131, 1
  %10175 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10173)
  %10176 = icmp ult i32 %10174, 8
  %10177 = and i1 %10175, %10176
  %10178 = and i1 %10146, %10177
  %convergence.parent.token2140 = load i32, ptr %current.token, align 4
  %convergence.parent.present2141 = icmp ne i32 %convergence.parent.token2140, 0
  %10179 = and i1 %10178, %convergence.parent.present2141
  br i1 %10179, label %convergence.cascade2126, label %convergence.cascade.exit2127

convergence.cascade.exit2127:                     ; preds = %convergence.cascade2126, %schedule.107
  %convergence.cascade.result2142 = phi <8 x i1> [ %2459, %schedule.107 ], [ %10173, %convergence.cascade2126 ]
  %10180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2142)
  br i1 %10180, label %convergence.target.107.ready, label %scheduler.loop

convergence.target.107.ready:                     ; preds = %convergence.cascade.exit2127
  %10181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2142)
  %10182 = bitcast <8 x i1> %convergence.cascade.result2142 to i8
  %10183 = call i8 @llvm.cttz.i8(i8 %10182, i1 false)
  %10184 = zext i8 %10183 to i32
  %10185 = select i1 %10181, i32 %10184, i32 0
  %.state2143 = load <8 x i64>, ptr %.slot, align 64
  %10186 = add <8 x i64> %.state2143, splat (i64 1)
  %.spill.load2144 = load <8 x float>, ptr %.spill280, align 32
  %.spill.load2145 = load <8 x float>, ptr %.spill281, align 32
  %.spill.load2146 = load <8 x float>, ptr %.spill282, align 32
  %.spill.load2147 = load <8 x float>, ptr %.spill283, align 32
  %.spill.load2148 = load <8 x float>, ptr %.spill298, align 32
  %.spill.load2149 = load <8 x float>, ptr %.spill299, align 32
  %.spill.load2150 = load <8 x float>, ptr %.spill300, align 32
  %.spill.load2151 = load <8 x float>, ptr %.spill301, align 32
  %10187 = load <8 x i64>, ptr %.slot, align 64
  %10188 = select <8 x i1> %convergence.cascade.result2142, <8 x i64> %10186, <8 x i64> %10187
  store <8 x i64> %10188, ptr %.slot, align 64
  %10189 = load <8 x float>, ptr %.slot41, align 32
  %10190 = select <8 x i1> %convergence.cascade.result2142, <8 x float> %.spill.load2144, <8 x float> %10189
  store <8 x float> %10190, ptr %.slot41, align 32
  %10191 = load <8 x float>, ptr %.slot47, align 32
  %10192 = select <8 x i1> %convergence.cascade.result2142, <8 x float> %.spill.load2145, <8 x float> %10191
  store <8 x float> %10192, ptr %.slot47, align 32
  %10193 = load <8 x float>, ptr %.slot48, align 32
  %10194 = select <8 x i1> %convergence.cascade.result2142, <8 x float> %.spill.load2146, <8 x float> %10193
  store <8 x float> %10194, ptr %.slot48, align 32
  %10195 = load <8 x float>, ptr %.slot49, align 32
  %10196 = select <8 x i1> %convergence.cascade.result2142, <8 x float> %.spill.load2147, <8 x float> %10195
  store <8 x float> %10196, ptr %.slot49, align 32
  %10197 = load <8 x float>, ptr %.slot50, align 32
  %10198 = select <8 x i1> %convergence.cascade.result2142, <8 x float> %.spill.load2148, <8 x float> %10197
  store <8 x float> %10198, ptr %.slot50, align 32
  %10199 = load <8 x float>, ptr %.slot51, align 32
  %10200 = select <8 x i1> %convergence.cascade.result2142, <8 x float> %.spill.load2149, <8 x float> %10199
  store <8 x float> %10200, ptr %.slot51, align 32
  %10201 = load <8 x float>, ptr %.slot52, align 32
  %10202 = select <8 x i1> %convergence.cascade.result2142, <8 x float> %.spill.load2150, <8 x float> %10201
  store <8 x float> %10202, ptr %.slot52, align 32
  %10203 = load <8 x float>, ptr %.slot53, align 32
  %10204 = select <8 x i1> %convergence.cascade.result2142, <8 x float> %.spill.load2151, <8 x float> %10203
  store <8 x float> %10204, ptr %.slot53, align 32
  store <8 x i1> %convergence.cascade.result2142, ptr %current.mask, align 1
  %10205 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2142)
  br i1 %10205, label %schedule.9, label %scheduler.loop

convergence.cascade2152:                          ; preds = %convergence.cascade2152, %schedule.108
  %convergence.cascade.flow2156 = phi <8 x i1> [ %2460, %schedule.108 ], [ %10248, %convergence.cascade2152 ]
  %convergence.cascade.depth2157 = phi i32 [ 0, %schedule.108 ], [ %10249, %convergence.cascade2152 ]
  %10206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2156)
  %10207 = load i32, ptr %current.token, align 4
  %10208 = icmp ne i32 %10207, 0
  %10209 = and i1 %10206, %10208
  %10210 = sub i32 %10207, 1
  %10211 = select i1 %10209, i32 %10210, i32 0
  %10212 = load i8, ptr %frame.active, align 1
  %10213 = trunc i32 %10211 to i8
  %10214 = shl i8 1, %10213
  %10215 = and i8 %10212, %10214
  %10216 = icmp ne i8 %10215, 0
  %10217 = load <8 x i32>, ptr %frame.static.id, align 32
  %10218 = extractelement <8 x i32> %10217, i32 %10211
  %convergence.target.pointer2158 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10218
  %convergence.dynamic.target2159 = load i32, ptr %convergence.target.pointer2158, align 4
  %10219 = icmp eq i32 %convergence.dynamic.target2159, 108
  %10220 = and i1 %10216, %10219
  %10221 = and i1 %10209, %10220
  %10222 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10211
  %10223 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10211
  %10224 = load <8 x i1>, ptr %10222, align 1
  %10225 = load <8 x i1>, ptr %10223, align 1
  %10226 = or <8 x i1> %10225, %convergence.cascade.flow2156
  %10227 = load <8 x i1>, ptr %live.mask, align 1
  %10228 = and <8 x i1> %10224, %10227
  %10229 = icmp eq <8 x i1> %10226, %10228
  %10230 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10229)
  %10231 = and i1 %10221, %10230
  %10232 = select i1 %10231, <8 x i1> zeroinitializer, <8 x i1> %10226
  %10233 = select i1 %10221, <8 x i1> %10232, <8 x i1> %10225
  store <8 x i1> %10233, ptr %10223, align 1
  %10234 = select i1 %10231, <8 x i1> zeroinitializer, <8 x i1> %10224
  store <8 x i1> %10234, ptr %10222, align 1
  %10235 = trunc i32 %10211 to i8
  %10236 = shl i8 1, %10235
  %10237 = xor i8 %10236, -1
  %10238 = and i8 %10212, %10237
  %10239 = select i1 %10231, i8 %10238, i8 %10212
  store i8 %10239, ptr %frame.active, align 1
  %.splatinsert2160 = insertelement <8 x i1> poison, i1 %10221, i64 0
  %.splat2161 = shufflevector <8 x i1> %.splatinsert2160, <8 x i1> poison, <8 x i32> zeroinitializer
  %10240 = and <8 x i1> %convergence.cascade.flow2156, %.splat2161
  %10241 = load <8 x i1>, ptr %runnable.mask, align 1
  %10242 = xor <8 x i1> %10240, splat (i1 true)
  %10243 = and <8 x i1> %10241, %10242
  store <8 x i1> %10243, ptr %runnable.mask, align 1
  %.splatinsert2162 = insertelement <8 x i1> poison, i1 %10231, i64 0
  %.splat2163 = shufflevector <8 x i1> %.splatinsert2162, <8 x i1> poison, <8 x i32> zeroinitializer
  %10244 = select <8 x i1> %.splat2163, <8 x i1> %10226, <8 x i1> zeroinitializer
  %10245 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10246 = extractelement <8 x i32> %10245, i32 %10211
  %10247 = select i1 %10231, i32 %10246, i32 %10207
  store i32 %10247, ptr %current.token, align 4
  %.splatinsert2164 = insertelement <8 x i1> poison, i1 %10221, i64 0
  %.splat2165 = shufflevector <8 x i1> %.splatinsert2164, <8 x i1> poison, <8 x i32> zeroinitializer
  %10248 = select <8 x i1> %.splat2165, <8 x i1> %10244, <8 x i1> %convergence.cascade.flow2156
  %10249 = add i32 %convergence.cascade.depth2157, 1
  %10250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10248)
  %10251 = icmp ult i32 %10249, 8
  %10252 = and i1 %10250, %10251
  %10253 = and i1 %10221, %10252
  %convergence.parent.token2166 = load i32, ptr %current.token, align 4
  %convergence.parent.present2167 = icmp ne i32 %convergence.parent.token2166, 0
  %10254 = and i1 %10253, %convergence.parent.present2167
  br i1 %10254, label %convergence.cascade2152, label %convergence.cascade.exit2153

convergence.cascade.exit2153:                     ; preds = %convergence.cascade2152, %schedule.108
  %convergence.cascade.result2168 = phi <8 x i1> [ %2460, %schedule.108 ], [ %10248, %convergence.cascade2152 ]
  %10255 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2168)
  br i1 %10255, label %convergence.target.108.ready, label %scheduler.loop

convergence.target.108.ready:                     ; preds = %convergence.cascade.exit2153
  %10256 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2168)
  %10257 = bitcast <8 x i1> %convergence.cascade.result2168 to i8
  %10258 = call i8 @llvm.cttz.i8(i8 %10257, i1 false)
  %10259 = zext i8 %10258 to i32
  %10260 = select i1 %10256, i32 %10259, i32 0
  %10261 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill321, align 64
  %10262 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10263 = extractvalue { <8 x ptr>, <8 x i64> } %10261, 0
  %10264 = select <8 x i1> %convergence.cascade.result2168, <8 x ptr> %10262, <8 x ptr> %10263
  %10265 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10266 = extractvalue { <8 x ptr>, <8 x i64> } %10261, 1
  %10267 = select <8 x i1> %convergence.cascade.result2168, <8 x i64> %10265, <8 x i64> %10266
  %10268 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10264, 0
  %10269 = insertvalue { <8 x ptr>, <8 x i64> } %10268, <8 x i64> %10267, 1
  store { <8 x ptr>, <8 x i64> } %10269, ptr %tile_snapshot.spill321, align 64
  %10270 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10271 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10272 = add <8 x i64> %10271, zeroinitializer
  %10273 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10270, 0
  %10274 = insertvalue { <8 x ptr>, <8 x i64> } %10273, <8 x i64> %10272, 1
  %.state2169 = load <8 x float>, ptr %.slot50, align 32
  %10275 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10276 = extractvalue { <8 x ptr>, <8 x i64> } %10274, 1
  %10277 = extractelement <8 x ptr> %10275, i32 0
  %10278 = extractelement <8 x i64> %10276, i32 %10260
  %10279 = zext i32 %10260 to i64
  %10280 = mul i64 %10279, 4
  %10281 = sub i64 %10278, %10280
  %10282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2168)
  %10283 = select i1 %10282, i64 %10281, i64 0
  %private.contiguous.address2170 = getelementptr i8, ptr %10277, i64 %10283
  %private.contiguous.preserve2171 = load <8 x float>, ptr %private.contiguous.address2170, align 4
  %10284 = select <8 x i1> %convergence.cascade.result2168, <8 x float> %.state2169, <8 x float> %private.contiguous.preserve2171
  store <8 x float> %10284, ptr %private.contiguous.address2170, align 4
  %10285 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10286 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10287 = add <8 x i64> %10286, splat (i64 32)
  %10288 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10285, 0
  %10289 = insertvalue { <8 x ptr>, <8 x i64> } %10288, <8 x i64> %10287, 1
  %.state2172 = load <8 x float>, ptr %.slot51, align 32
  %10290 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10291 = extractvalue { <8 x ptr>, <8 x i64> } %10289, 1
  %10292 = extractelement <8 x ptr> %10290, i32 0
  %10293 = extractelement <8 x i64> %10291, i32 %10260
  %10294 = zext i32 %10260 to i64
  %10295 = mul i64 %10294, 4
  %10296 = sub i64 %10293, %10295
  %10297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2168)
  %10298 = select i1 %10297, i64 %10296, i64 0
  %private.contiguous.address2173 = getelementptr i8, ptr %10292, i64 %10298
  %private.contiguous.preserve2174 = load <8 x float>, ptr %private.contiguous.address2173, align 4
  %10299 = select <8 x i1> %convergence.cascade.result2168, <8 x float> %.state2172, <8 x float> %private.contiguous.preserve2174
  store <8 x float> %10299, ptr %private.contiguous.address2173, align 4
  %10300 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10301 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10302 = add <8 x i64> %10301, splat (i64 64)
  %10303 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10300, 0
  %10304 = insertvalue { <8 x ptr>, <8 x i64> } %10303, <8 x i64> %10302, 1
  %.state2175 = load <8 x float>, ptr %.slot52, align 32
  %10305 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10306 = extractvalue { <8 x ptr>, <8 x i64> } %10304, 1
  %10307 = extractelement <8 x ptr> %10305, i32 0
  %10308 = extractelement <8 x i64> %10306, i32 %10260
  %10309 = zext i32 %10260 to i64
  %10310 = mul i64 %10309, 4
  %10311 = sub i64 %10308, %10310
  %10312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2168)
  %10313 = select i1 %10312, i64 %10311, i64 0
  %private.contiguous.address2176 = getelementptr i8, ptr %10307, i64 %10313
  %private.contiguous.preserve2177 = load <8 x float>, ptr %private.contiguous.address2176, align 4
  %10314 = select <8 x i1> %convergence.cascade.result2168, <8 x float> %.state2175, <8 x float> %private.contiguous.preserve2177
  store <8 x float> %10314, ptr %private.contiguous.address2176, align 4
  %10315 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10316 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10317 = add <8 x i64> %10316, splat (i64 96)
  %10318 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10315, 0
  %10319 = insertvalue { <8 x ptr>, <8 x i64> } %10318, <8 x i64> %10317, 1
  %.state2178 = load <8 x float>, ptr %.slot53, align 32
  %10320 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10321 = extractvalue { <8 x ptr>, <8 x i64> } %10319, 1
  %10322 = extractelement <8 x ptr> %10320, i32 0
  %10323 = extractelement <8 x i64> %10321, i32 %10260
  %10324 = zext i32 %10260 to i64
  %10325 = mul i64 %10324, 4
  %10326 = sub i64 %10323, %10325
  %10327 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2168)
  %10328 = select i1 %10327, i64 %10326, i64 0
  %private.contiguous.address2179 = getelementptr i8, ptr %10322, i64 %10328
  %private.contiguous.preserve2180 = load <8 x float>, ptr %private.contiguous.address2179, align 4
  %10329 = select <8 x i1> %convergence.cascade.result2168, <8 x float> %.state2178, <8 x float> %private.contiguous.preserve2180
  store <8 x float> %10329, ptr %private.contiguous.address2179, align 4
  %10330 = load <8 x i64>, ptr %.slot, align 64
  %10331 = select <8 x i1> %convergence.cascade.result2168, <8 x i64> zeroinitializer, <8 x i64> %10330
  store <8 x i64> %10331, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result2168, ptr %current.mask, align 1
  %10332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2168)
  br i1 %10332, label %schedule.109, label %scheduler.loop

varying.divergent2182:                            ; preds = %schedule.109
  %10333 = load i32, ptr %current.token, align 4
  %10334 = icmp ne i32 %10333, 0
  %10335 = sub i32 %10333, 1
  %10336 = select i1 %10334, i32 %10335, i32 0
  %10337 = load i8, ptr %frame.active, align 1
  %10338 = trunc i32 %10336 to i8
  %10339 = shl i8 1, %10338
  %10340 = and i8 %10337, %10339
  %10341 = icmp ne i8 %10340, 0
  %10342 = load <8 x i32>, ptr %frame.static.id, align 32
  %10343 = extractelement <8 x i32> %10342, i32 %10336
  %10344 = icmp eq i32 %10343, 37
  %10345 = and i1 %10341, %10344
  %10346 = and i1 %10334, %10345
  %10347 = xor i1 %10346, true
  %10348 = and i1 true, %10347
  %10349 = xor i8 %10337, -1
  %10350 = icmp ne i8 %10349, 0
  %10351 = xor i1 %10350, true
  %10352 = and i1 %10348, %10351
  br i1 %10352, label %convergence.overflow.trap2184, label %convergence.overflow.resume2185

varying.coherent2183:                             ; preds = %schedule.109
  br i1 %2471, label %varying.coherent.true2188, label %varying.coherent.false2189

convergence.overflow.trap2184:                    ; preds = %varying.divergent2182
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2185:                  ; preds = %varying.divergent2182
  %10353 = call i8 @llvm.cttz.i8(i8 %10349, i1 false)
  %10354 = zext i8 %10353 to i32
  %10355 = select i1 %10350, i32 %10354, i32 0
  %10356 = trunc i32 %10355 to i8
  %10357 = shl i8 1, %10356
  %10358 = or i8 %10337, %10357
  %10359 = select i1 %10348, i8 %10358, i8 %10337
  store i8 %10359, ptr %frame.active, align 1
  %10360 = load <8 x i32>, ptr %frame.static.id, align 32
  %10361 = extractelement <8 x i32> %10360, i32 %10355
  %10362 = select i1 %10348, i32 37, i32 %10361
  %10363 = load <8 x i32>, ptr %frame.static.id, align 32
  %10364 = insertelement <8 x i32> %10363, i32 %10362, i32 %10355
  store <8 x i32> %10364, ptr %frame.static.id, align 32
  %10365 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10366 = extractelement <8 x i32> %10365, i32 %10355
  %10367 = select i1 %10348, i32 %10333, i32 %10366
  %10368 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10369 = insertelement <8 x i32> %10368, i32 %10367, i32 %10355
  store <8 x i32> %10369, ptr %frame.parent.token, align 32
  %10370 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10355
  %10371 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10355
  %10372 = load <8 x i1>, ptr %10370, align 1
  %10373 = load <8 x i1>, ptr %10371, align 1
  %10374 = select i1 %10348, <8 x i1> %2461, <8 x i1> %10372
  store <8 x i1> %10374, ptr %10370, align 1
  %10375 = select i1 %10348, <8 x i1> zeroinitializer, <8 x i1> %10373
  store <8 x i1> %10375, ptr %10371, align 1
  %10376 = add i32 %10355, 1
  %10377 = select i1 %10346, i32 %10333, i32 %10376
  %10378 = select i1 true, i32 %10377, i32 %10333
  store i32 %10378, ptr %current.token, align 4
  %10379 = load i32, ptr %current.token, align 4
  %10380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2468)
  %10381 = load i32, ptr %ready.count, align 4
  %10382 = icmp uge i32 %10381, 8
  %10383 = and i1 %10380, %10382
  br i1 %10383, label %ready.overflow.trap2186, label %ready.overflow.resume2187

ready.overflow.trap2186:                          ; preds = %convergence.overflow.resume2185
  call void @llvm.trap()
  unreachable

ready.overflow.resume2187:                        ; preds = %convergence.overflow.resume2185
  %10384 = select i1 %10380, i32 %10381, i32 0
  %10385 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10384
  %10386 = load <8 x i1>, ptr %10385, align 1
  %10387 = select i1 %10380, <8 x i1> %2468, <8 x i1> %10386
  store <8 x i1> %10387, ptr %10385, align 1
  %10388 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10384
  %10389 = load i32, ptr %10388, align 4
  %10390 = select i1 %10380, i32 110, i32 %10389
  store i32 %10390, ptr %10388, align 4
  %10391 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10384
  %10392 = load i32, ptr %10391, align 4
  %10393 = select i1 %10380, i32 %10379, i32 %10392
  store i32 %10393, ptr %10391, align 4
  %10394 = add i32 %10381, 1
  %10395 = select i1 %10380, i32 %10394, i32 %10381
  store i32 %10395, ptr %ready.count, align 4
  %10396 = load <8 x i1>, ptr %runnable.mask, align 1
  %10397 = or <8 x i1> %10396, %2468
  store <8 x i1> %10397, ptr %runnable.mask, align 1
  store <8 x i1> %2470, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2188:                        ; preds = %varying.coherent2183
  store <8 x i1> %2461, ptr %current.mask, align 1
  %10398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2461)
  br i1 %10398, label %schedule.110, label %scheduler.loop

varying.coherent.false2189:                       ; preds = %varying.coherent2183
  store <8 x i1> %2461, ptr %current.mask, align 1
  %10399 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2461)
  br i1 %10399, label %schedule.113, label %scheduler.loop

varying.divergent2197:                            ; preds = %schedule.110
  %10400 = load i32, ptr %current.token, align 4
  %10401 = icmp ne i32 %10400, 0
  %10402 = sub i32 %10400, 1
  %10403 = select i1 %10401, i32 %10402, i32 0
  %10404 = load i8, ptr %frame.active, align 1
  %10405 = trunc i32 %10403 to i8
  %10406 = shl i8 1, %10405
  %10407 = and i8 %10404, %10406
  %10408 = icmp ne i8 %10407, 0
  %10409 = load <8 x i32>, ptr %frame.static.id, align 32
  %10410 = extractelement <8 x i32> %10409, i32 %10403
  %10411 = icmp eq i32 %10410, 38
  %10412 = and i1 %10408, %10411
  %10413 = and i1 %10401, %10412
  %10414 = xor i1 %10413, true
  %10415 = and i1 true, %10414
  %10416 = xor i8 %10404, -1
  %10417 = icmp ne i8 %10416, 0
  %10418 = xor i1 %10417, true
  %10419 = and i1 %10415, %10418
  br i1 %10419, label %convergence.overflow.trap2199, label %convergence.overflow.resume2200

varying.coherent2198:                             ; preds = %schedule.110
  br i1 %2532, label %varying.coherent.true2203, label %varying.coherent.false2204

convergence.overflow.trap2199:                    ; preds = %varying.divergent2197
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2200:                  ; preds = %varying.divergent2197
  %10420 = call i8 @llvm.cttz.i8(i8 %10416, i1 false)
  %10421 = zext i8 %10420 to i32
  %10422 = select i1 %10417, i32 %10421, i32 0
  %10423 = trunc i32 %10422 to i8
  %10424 = shl i8 1, %10423
  %10425 = or i8 %10404, %10424
  %10426 = select i1 %10415, i8 %10425, i8 %10404
  store i8 %10426, ptr %frame.active, align 1
  %10427 = load <8 x i32>, ptr %frame.static.id, align 32
  %10428 = extractelement <8 x i32> %10427, i32 %10422
  %10429 = select i1 %10415, i32 38, i32 %10428
  %10430 = load <8 x i32>, ptr %frame.static.id, align 32
  %10431 = insertelement <8 x i32> %10430, i32 %10429, i32 %10422
  store <8 x i32> %10431, ptr %frame.static.id, align 32
  %10432 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10433 = extractelement <8 x i32> %10432, i32 %10422
  %10434 = select i1 %10415, i32 %10400, i32 %10433
  %10435 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10436 = insertelement <8 x i32> %10435, i32 %10434, i32 %10422
  store <8 x i32> %10436, ptr %frame.parent.token, align 32
  %10437 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10422
  %10438 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10422
  %10439 = load <8 x i1>, ptr %10437, align 1
  %10440 = load <8 x i1>, ptr %10438, align 1
  %10441 = select i1 %10415, <8 x i1> %2474, <8 x i1> %10439
  store <8 x i1> %10441, ptr %10437, align 1
  %10442 = select i1 %10415, <8 x i1> zeroinitializer, <8 x i1> %10440
  store <8 x i1> %10442, ptr %10438, align 1
  %10443 = add i32 %10422, 1
  %10444 = select i1 %10413, i32 %10400, i32 %10443
  %10445 = select i1 true, i32 %10444, i32 %10400
  store i32 %10445, ptr %current.token, align 4
  %10446 = load i32, ptr %current.token, align 4
  %10447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2529)
  %10448 = load i32, ptr %ready.count, align 4
  %10449 = icmp uge i32 %10448, 8
  %10450 = and i1 %10447, %10449
  br i1 %10450, label %ready.overflow.trap2201, label %ready.overflow.resume2202

ready.overflow.trap2201:                          ; preds = %convergence.overflow.resume2200
  call void @llvm.trap()
  unreachable

ready.overflow.resume2202:                        ; preds = %convergence.overflow.resume2200
  %10451 = select i1 %10447, i32 %10448, i32 0
  %10452 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10451
  %10453 = load <8 x i1>, ptr %10452, align 1
  %10454 = select i1 %10447, <8 x i1> %2529, <8 x i1> %10453
  store <8 x i1> %10454, ptr %10452, align 1
  %10455 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10451
  %10456 = load i32, ptr %10455, align 4
  %10457 = select i1 %10447, i32 111, i32 %10456
  store i32 %10457, ptr %10455, align 4
  %10458 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10451
  %10459 = load i32, ptr %10458, align 4
  %10460 = select i1 %10447, i32 %10446, i32 %10459
  store i32 %10460, ptr %10458, align 4
  %10461 = add i32 %10448, 1
  %10462 = select i1 %10447, i32 %10461, i32 %10448
  store i32 %10462, ptr %ready.count, align 4
  %10463 = load <8 x i1>, ptr %runnable.mask, align 1
  %10464 = or <8 x i1> %10463, %2529
  store <8 x i1> %10464, ptr %runnable.mask, align 1
  store <8 x i1> %2531, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2203:                        ; preds = %varying.coherent2198
  store <8 x i1> %2474, ptr %current.mask, align 1
  %10465 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2474)
  br i1 %10465, label %schedule.111, label %scheduler.loop

varying.coherent.false2204:                       ; preds = %varying.coherent2198
  store <8 x i1> %2474, ptr %current.mask, align 1
  %10466 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2474)
  br i1 %10466, label %schedule.112, label %scheduler.loop

convergence.cascade2207:                          ; preds = %convergence.cascade2207, %schedule.112
  %convergence.cascade.flow2211 = phi <8 x i1> [ %2545, %schedule.112 ], [ %10509, %convergence.cascade2207 ]
  %convergence.cascade.depth2212 = phi i32 [ 0, %schedule.112 ], [ %10510, %convergence.cascade2207 ]
  %10467 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2211)
  %10468 = load i32, ptr %current.token, align 4
  %10469 = icmp ne i32 %10468, 0
  %10470 = and i1 %10467, %10469
  %10471 = sub i32 %10468, 1
  %10472 = select i1 %10470, i32 %10471, i32 0
  %10473 = load i8, ptr %frame.active, align 1
  %10474 = trunc i32 %10472 to i8
  %10475 = shl i8 1, %10474
  %10476 = and i8 %10473, %10475
  %10477 = icmp ne i8 %10476, 0
  %10478 = load <8 x i32>, ptr %frame.static.id, align 32
  %10479 = extractelement <8 x i32> %10478, i32 %10472
  %convergence.target.pointer2213 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10479
  %convergence.dynamic.target2214 = load i32, ptr %convergence.target.pointer2213, align 4
  %10480 = icmp eq i32 %convergence.dynamic.target2214, 112
  %10481 = and i1 %10477, %10480
  %10482 = and i1 %10470, %10481
  %10483 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10472
  %10484 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10472
  %10485 = load <8 x i1>, ptr %10483, align 1
  %10486 = load <8 x i1>, ptr %10484, align 1
  %10487 = or <8 x i1> %10486, %convergence.cascade.flow2211
  %10488 = load <8 x i1>, ptr %live.mask, align 1
  %10489 = and <8 x i1> %10485, %10488
  %10490 = icmp eq <8 x i1> %10487, %10489
  %10491 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10490)
  %10492 = and i1 %10482, %10491
  %10493 = select i1 %10492, <8 x i1> zeroinitializer, <8 x i1> %10487
  %10494 = select i1 %10482, <8 x i1> %10493, <8 x i1> %10486
  store <8 x i1> %10494, ptr %10484, align 1
  %10495 = select i1 %10492, <8 x i1> zeroinitializer, <8 x i1> %10485
  store <8 x i1> %10495, ptr %10483, align 1
  %10496 = trunc i32 %10472 to i8
  %10497 = shl i8 1, %10496
  %10498 = xor i8 %10497, -1
  %10499 = and i8 %10473, %10498
  %10500 = select i1 %10492, i8 %10499, i8 %10473
  store i8 %10500, ptr %frame.active, align 1
  %.splatinsert2215 = insertelement <8 x i1> poison, i1 %10482, i64 0
  %.splat2216 = shufflevector <8 x i1> %.splatinsert2215, <8 x i1> poison, <8 x i32> zeroinitializer
  %10501 = and <8 x i1> %convergence.cascade.flow2211, %.splat2216
  %10502 = load <8 x i1>, ptr %runnable.mask, align 1
  %10503 = xor <8 x i1> %10501, splat (i1 true)
  %10504 = and <8 x i1> %10502, %10503
  store <8 x i1> %10504, ptr %runnable.mask, align 1
  %.splatinsert2217 = insertelement <8 x i1> poison, i1 %10492, i64 0
  %.splat2218 = shufflevector <8 x i1> %.splatinsert2217, <8 x i1> poison, <8 x i32> zeroinitializer
  %10505 = select <8 x i1> %.splat2218, <8 x i1> %10487, <8 x i1> zeroinitializer
  %10506 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10507 = extractelement <8 x i32> %10506, i32 %10472
  %10508 = select i1 %10492, i32 %10507, i32 %10468
  store i32 %10508, ptr %current.token, align 4
  %.splatinsert2219 = insertelement <8 x i1> poison, i1 %10482, i64 0
  %.splat2220 = shufflevector <8 x i1> %.splatinsert2219, <8 x i1> poison, <8 x i32> zeroinitializer
  %10509 = select <8 x i1> %.splat2220, <8 x i1> %10505, <8 x i1> %convergence.cascade.flow2211
  %10510 = add i32 %convergence.cascade.depth2212, 1
  %10511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10509)
  %10512 = icmp ult i32 %10510, 8
  %10513 = and i1 %10511, %10512
  %10514 = and i1 %10482, %10513
  %convergence.parent.token2221 = load i32, ptr %current.token, align 4
  %convergence.parent.present2222 = icmp ne i32 %convergence.parent.token2221, 0
  %10515 = and i1 %10514, %convergence.parent.present2222
  br i1 %10515, label %convergence.cascade2207, label %convergence.cascade.exit2208

convergence.cascade.exit2208:                     ; preds = %convergence.cascade2207, %schedule.112
  %convergence.cascade.result2223 = phi <8 x i1> [ %2545, %schedule.112 ], [ %10509, %convergence.cascade2207 ]
  %10516 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2223)
  br i1 %10516, label %convergence.target.112.ready, label %scheduler.loop

convergence.target.112.ready:                     ; preds = %convergence.cascade.exit2208
  %10517 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2223)
  %10518 = bitcast <8 x i1> %convergence.cascade.result2223 to i8
  %10519 = call i8 @llvm.cttz.i8(i8 %10518, i1 false)
  %10520 = zext i8 %10519 to i32
  %10521 = select i1 %10517, i32 %10520, i32 0
  %.state2224 = load <8 x i64>, ptr %.slot, align 64
  %10522 = add <8 x i64> %.state2224, splat (i64 1)
  %10523 = load <8 x i64>, ptr %.slot, align 64
  %10524 = select <8 x i1> %convergence.cascade.result2223, <8 x i64> %10522, <8 x i64> %10523
  store <8 x i64> %10524, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result2223, ptr %current.mask, align 1
  %10525 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2223)
  br i1 %10525, label %schedule.109, label %scheduler.loop

convergence.cascade2225:                          ; preds = %convergence.cascade2225, %schedule.113
  %convergence.cascade.flow2229 = phi <8 x i1> [ %2546, %schedule.113 ], [ %10568, %convergence.cascade2225 ]
  %convergence.cascade.depth2230 = phi i32 [ 0, %schedule.113 ], [ %10569, %convergence.cascade2225 ]
  %10526 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2229)
  %10527 = load i32, ptr %current.token, align 4
  %10528 = icmp ne i32 %10527, 0
  %10529 = and i1 %10526, %10528
  %10530 = sub i32 %10527, 1
  %10531 = select i1 %10529, i32 %10530, i32 0
  %10532 = load i8, ptr %frame.active, align 1
  %10533 = trunc i32 %10531 to i8
  %10534 = shl i8 1, %10533
  %10535 = and i8 %10532, %10534
  %10536 = icmp ne i8 %10535, 0
  %10537 = load <8 x i32>, ptr %frame.static.id, align 32
  %10538 = extractelement <8 x i32> %10537, i32 %10531
  %convergence.target.pointer2231 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10538
  %convergence.dynamic.target2232 = load i32, ptr %convergence.target.pointer2231, align 4
  %10539 = icmp eq i32 %convergence.dynamic.target2232, 113
  %10540 = and i1 %10536, %10539
  %10541 = and i1 %10529, %10540
  %10542 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10531
  %10543 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10531
  %10544 = load <8 x i1>, ptr %10542, align 1
  %10545 = load <8 x i1>, ptr %10543, align 1
  %10546 = or <8 x i1> %10545, %convergence.cascade.flow2229
  %10547 = load <8 x i1>, ptr %live.mask, align 1
  %10548 = and <8 x i1> %10544, %10547
  %10549 = icmp eq <8 x i1> %10546, %10548
  %10550 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10549)
  %10551 = and i1 %10541, %10550
  %10552 = select i1 %10551, <8 x i1> zeroinitializer, <8 x i1> %10546
  %10553 = select i1 %10541, <8 x i1> %10552, <8 x i1> %10545
  store <8 x i1> %10553, ptr %10543, align 1
  %10554 = select i1 %10551, <8 x i1> zeroinitializer, <8 x i1> %10544
  store <8 x i1> %10554, ptr %10542, align 1
  %10555 = trunc i32 %10531 to i8
  %10556 = shl i8 1, %10555
  %10557 = xor i8 %10556, -1
  %10558 = and i8 %10532, %10557
  %10559 = select i1 %10551, i8 %10558, i8 %10532
  store i8 %10559, ptr %frame.active, align 1
  %.splatinsert2233 = insertelement <8 x i1> poison, i1 %10541, i64 0
  %.splat2234 = shufflevector <8 x i1> %.splatinsert2233, <8 x i1> poison, <8 x i32> zeroinitializer
  %10560 = and <8 x i1> %convergence.cascade.flow2229, %.splat2234
  %10561 = load <8 x i1>, ptr %runnable.mask, align 1
  %10562 = xor <8 x i1> %10560, splat (i1 true)
  %10563 = and <8 x i1> %10561, %10562
  store <8 x i1> %10563, ptr %runnable.mask, align 1
  %.splatinsert2235 = insertelement <8 x i1> poison, i1 %10551, i64 0
  %.splat2236 = shufflevector <8 x i1> %.splatinsert2235, <8 x i1> poison, <8 x i32> zeroinitializer
  %10564 = select <8 x i1> %.splat2236, <8 x i1> %10546, <8 x i1> zeroinitializer
  %10565 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10566 = extractelement <8 x i32> %10565, i32 %10531
  %10567 = select i1 %10551, i32 %10566, i32 %10527
  store i32 %10567, ptr %current.token, align 4
  %.splatinsert2237 = insertelement <8 x i1> poison, i1 %10541, i64 0
  %.splat2238 = shufflevector <8 x i1> %.splatinsert2237, <8 x i1> poison, <8 x i32> zeroinitializer
  %10568 = select <8 x i1> %.splat2238, <8 x i1> %10564, <8 x i1> %convergence.cascade.flow2229
  %10569 = add i32 %convergence.cascade.depth2230, 1
  %10570 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10568)
  %10571 = icmp ult i32 %10569, 8
  %10572 = and i1 %10570, %10571
  %10573 = and i1 %10541, %10572
  %convergence.parent.token2239 = load i32, ptr %current.token, align 4
  %convergence.parent.present2240 = icmp ne i32 %convergence.parent.token2239, 0
  %10574 = and i1 %10573, %convergence.parent.present2240
  br i1 %10574, label %convergence.cascade2225, label %convergence.cascade.exit2226

convergence.cascade.exit2226:                     ; preds = %convergence.cascade2225, %schedule.113
  %convergence.cascade.result2241 = phi <8 x i1> [ %2546, %schedule.113 ], [ %10568, %convergence.cascade2225 ]
  %10575 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2241)
  br i1 %10575, label %convergence.target.113.ready, label %scheduler.loop

convergence.target.113.ready:                     ; preds = %convergence.cascade.exit2226
  %10576 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2241)
  %10577 = bitcast <8 x i1> %convergence.cascade.result2241 to i8
  %10578 = call i8 @llvm.cttz.i8(i8 %10577, i1 false)
  %10579 = zext i8 %10578 to i32
  %10580 = select i1 %10576, i32 %10579, i32 0
  %10581 = load <8 x i1>, ptr %live.mask, align 1
  %10582 = xor <8 x i1> %convergence.cascade.result2241, splat (i1 true)
  %10583 = and <8 x i1> %10581, %10582
  store <8 x i1> %10583, ptr %live.mask, align 1
  %10584 = load <8 x i1>, ptr %runnable.mask, align 1
  %10585 = xor <8 x i1> %convergence.cascade.result2241, splat (i1 true)
  %10586 = and <8 x i1> %10584, %10585
  store <8 x i1> %10586, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.113.ready
  %10587 = load i8, ptr %frame.active, align 1
  %10588 = and i8 %10587, 1
  %10589 = icmp ne i8 %10588, 0
  %10590 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %10591 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %10592 = load <8 x i1>, ptr %10590, align 1
  %10593 = load <8 x i1>, ptr %10591, align 1
  %10594 = and <8 x i1> %10592, %10583
  %10595 = icmp eq <8 x i1> %10593, %10594
  %10596 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10595)
  %10597 = and i1 %10589, %10596
  %.splatinsert2242 = insertelement <8 x i1> poison, i1 %10597, i64 0
  %.splat2243 = shufflevector <8 x i1> %.splatinsert2242, <8 x i1> poison, <8 x i32> zeroinitializer
  %10598 = select <8 x i1> %.splat2243, <8 x i1> %10593, <8 x i1> zeroinitializer
  %10599 = select i1 %10597, <8 x i1> zeroinitializer, <8 x i1> %10594
  store <8 x i1> %10599, ptr %10590, align 1
  %10600 = select i1 %10597, <8 x i1> zeroinitializer, <8 x i1> %10593
  store <8 x i1> %10600, ptr %10591, align 1
  %10601 = and i8 %10587, -2
  %10602 = select i1 %10597, i8 %10601, i8 %10587
  store i8 %10602, ptr %frame.active, align 1
  %10603 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10604 = extractelement <8 x i32> %10603, i32 0
  %10605 = load <8 x i32>, ptr %frame.static.id, align 32
  %10606 = extractelement <8 x i32> %10605, i32 0
  %convergence.target.pointer2244 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10606
  %convergence.dynamic.target2245 = load i32, ptr %convergence.target.pointer2244, align 4
  %10607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10598)
  %10608 = load i32, ptr %ready.count, align 4
  %10609 = icmp uge i32 %10608, 8
  %10610 = and i1 %10607, %10609
  br i1 %10610, label %ready.overflow.trap2246, label %ready.overflow.resume2247

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume2289, %convergence.target.113.ready
  br label %scheduler.loop

ready.overflow.trap2246:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume2247:                        ; preds = %return.frame.cleanup
  %10611 = select i1 %10607, i32 %10608, i32 0
  %10612 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10611
  %10613 = load <8 x i1>, ptr %10612, align 1
  %10614 = select i1 %10607, <8 x i1> %10598, <8 x i1> %10613
  store <8 x i1> %10614, ptr %10612, align 1
  %10615 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10611
  %10616 = load i32, ptr %10615, align 4
  %10617 = select i1 %10607, i32 %convergence.dynamic.target2245, i32 %10616
  store i32 %10617, ptr %10615, align 4
  %10618 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10611
  %10619 = load i32, ptr %10618, align 4
  %10620 = select i1 %10607, i32 %10604, i32 %10619
  store i32 %10620, ptr %10618, align 4
  %10621 = add i32 %10608, 1
  %10622 = select i1 %10607, i32 %10621, i32 %10608
  store i32 %10622, ptr %ready.count, align 4
  %10623 = load <8 x i1>, ptr %runnable.mask, align 1
  %10624 = or <8 x i1> %10623, %10598
  store <8 x i1> %10624, ptr %runnable.mask, align 1
  %10625 = load i8, ptr %frame.active, align 1
  %10626 = and i8 %10625, 2
  %10627 = icmp ne i8 %10626, 0
  %10628 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %10629 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %10630 = load <8 x i1>, ptr %10628, align 1
  %10631 = load <8 x i1>, ptr %10629, align 1
  %10632 = and <8 x i1> %10630, %10583
  %10633 = icmp eq <8 x i1> %10631, %10632
  %10634 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10633)
  %10635 = and i1 %10627, %10634
  %.splatinsert2248 = insertelement <8 x i1> poison, i1 %10635, i64 0
  %.splat2249 = shufflevector <8 x i1> %.splatinsert2248, <8 x i1> poison, <8 x i32> zeroinitializer
  %10636 = select <8 x i1> %.splat2249, <8 x i1> %10631, <8 x i1> zeroinitializer
  %10637 = select i1 %10635, <8 x i1> zeroinitializer, <8 x i1> %10632
  store <8 x i1> %10637, ptr %10628, align 1
  %10638 = select i1 %10635, <8 x i1> zeroinitializer, <8 x i1> %10631
  store <8 x i1> %10638, ptr %10629, align 1
  %10639 = and i8 %10625, -3
  %10640 = select i1 %10635, i8 %10639, i8 %10625
  store i8 %10640, ptr %frame.active, align 1
  %10641 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10642 = extractelement <8 x i32> %10641, i32 1
  %10643 = load <8 x i32>, ptr %frame.static.id, align 32
  %10644 = extractelement <8 x i32> %10643, i32 1
  %convergence.target.pointer2250 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10644
  %convergence.dynamic.target2251 = load i32, ptr %convergence.target.pointer2250, align 4
  %10645 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10636)
  %10646 = load i32, ptr %ready.count, align 4
  %10647 = icmp uge i32 %10646, 8
  %10648 = and i1 %10645, %10647
  br i1 %10648, label %ready.overflow.trap2252, label %ready.overflow.resume2253

ready.overflow.trap2252:                          ; preds = %ready.overflow.resume2247
  call void @llvm.trap()
  unreachable

ready.overflow.resume2253:                        ; preds = %ready.overflow.resume2247
  %10649 = select i1 %10645, i32 %10646, i32 0
  %10650 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10649
  %10651 = load <8 x i1>, ptr %10650, align 1
  %10652 = select i1 %10645, <8 x i1> %10636, <8 x i1> %10651
  store <8 x i1> %10652, ptr %10650, align 1
  %10653 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10649
  %10654 = load i32, ptr %10653, align 4
  %10655 = select i1 %10645, i32 %convergence.dynamic.target2251, i32 %10654
  store i32 %10655, ptr %10653, align 4
  %10656 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10649
  %10657 = load i32, ptr %10656, align 4
  %10658 = select i1 %10645, i32 %10642, i32 %10657
  store i32 %10658, ptr %10656, align 4
  %10659 = add i32 %10646, 1
  %10660 = select i1 %10645, i32 %10659, i32 %10646
  store i32 %10660, ptr %ready.count, align 4
  %10661 = load <8 x i1>, ptr %runnable.mask, align 1
  %10662 = or <8 x i1> %10661, %10636
  store <8 x i1> %10662, ptr %runnable.mask, align 1
  %10663 = load i8, ptr %frame.active, align 1
  %10664 = and i8 %10663, 4
  %10665 = icmp ne i8 %10664, 0
  %10666 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %10667 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %10668 = load <8 x i1>, ptr %10666, align 1
  %10669 = load <8 x i1>, ptr %10667, align 1
  %10670 = and <8 x i1> %10668, %10583
  %10671 = icmp eq <8 x i1> %10669, %10670
  %10672 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10671)
  %10673 = and i1 %10665, %10672
  %.splatinsert2254 = insertelement <8 x i1> poison, i1 %10673, i64 0
  %.splat2255 = shufflevector <8 x i1> %.splatinsert2254, <8 x i1> poison, <8 x i32> zeroinitializer
  %10674 = select <8 x i1> %.splat2255, <8 x i1> %10669, <8 x i1> zeroinitializer
  %10675 = select i1 %10673, <8 x i1> zeroinitializer, <8 x i1> %10670
  store <8 x i1> %10675, ptr %10666, align 1
  %10676 = select i1 %10673, <8 x i1> zeroinitializer, <8 x i1> %10669
  store <8 x i1> %10676, ptr %10667, align 1
  %10677 = and i8 %10663, -5
  %10678 = select i1 %10673, i8 %10677, i8 %10663
  store i8 %10678, ptr %frame.active, align 1
  %10679 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10680 = extractelement <8 x i32> %10679, i32 2
  %10681 = load <8 x i32>, ptr %frame.static.id, align 32
  %10682 = extractelement <8 x i32> %10681, i32 2
  %convergence.target.pointer2256 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10682
  %convergence.dynamic.target2257 = load i32, ptr %convergence.target.pointer2256, align 4
  %10683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10674)
  %10684 = load i32, ptr %ready.count, align 4
  %10685 = icmp uge i32 %10684, 8
  %10686 = and i1 %10683, %10685
  br i1 %10686, label %ready.overflow.trap2258, label %ready.overflow.resume2259

ready.overflow.trap2258:                          ; preds = %ready.overflow.resume2253
  call void @llvm.trap()
  unreachable

ready.overflow.resume2259:                        ; preds = %ready.overflow.resume2253
  %10687 = select i1 %10683, i32 %10684, i32 0
  %10688 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10687
  %10689 = load <8 x i1>, ptr %10688, align 1
  %10690 = select i1 %10683, <8 x i1> %10674, <8 x i1> %10689
  store <8 x i1> %10690, ptr %10688, align 1
  %10691 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10687
  %10692 = load i32, ptr %10691, align 4
  %10693 = select i1 %10683, i32 %convergence.dynamic.target2257, i32 %10692
  store i32 %10693, ptr %10691, align 4
  %10694 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10687
  %10695 = load i32, ptr %10694, align 4
  %10696 = select i1 %10683, i32 %10680, i32 %10695
  store i32 %10696, ptr %10694, align 4
  %10697 = add i32 %10684, 1
  %10698 = select i1 %10683, i32 %10697, i32 %10684
  store i32 %10698, ptr %ready.count, align 4
  %10699 = load <8 x i1>, ptr %runnable.mask, align 1
  %10700 = or <8 x i1> %10699, %10674
  store <8 x i1> %10700, ptr %runnable.mask, align 1
  %10701 = load i8, ptr %frame.active, align 1
  %10702 = and i8 %10701, 8
  %10703 = icmp ne i8 %10702, 0
  %10704 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %10705 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %10706 = load <8 x i1>, ptr %10704, align 1
  %10707 = load <8 x i1>, ptr %10705, align 1
  %10708 = and <8 x i1> %10706, %10583
  %10709 = icmp eq <8 x i1> %10707, %10708
  %10710 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10709)
  %10711 = and i1 %10703, %10710
  %.splatinsert2260 = insertelement <8 x i1> poison, i1 %10711, i64 0
  %.splat2261 = shufflevector <8 x i1> %.splatinsert2260, <8 x i1> poison, <8 x i32> zeroinitializer
  %10712 = select <8 x i1> %.splat2261, <8 x i1> %10707, <8 x i1> zeroinitializer
  %10713 = select i1 %10711, <8 x i1> zeroinitializer, <8 x i1> %10708
  store <8 x i1> %10713, ptr %10704, align 1
  %10714 = select i1 %10711, <8 x i1> zeroinitializer, <8 x i1> %10707
  store <8 x i1> %10714, ptr %10705, align 1
  %10715 = and i8 %10701, -9
  %10716 = select i1 %10711, i8 %10715, i8 %10701
  store i8 %10716, ptr %frame.active, align 1
  %10717 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10718 = extractelement <8 x i32> %10717, i32 3
  %10719 = load <8 x i32>, ptr %frame.static.id, align 32
  %10720 = extractelement <8 x i32> %10719, i32 3
  %convergence.target.pointer2262 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10720
  %convergence.dynamic.target2263 = load i32, ptr %convergence.target.pointer2262, align 4
  %10721 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10712)
  %10722 = load i32, ptr %ready.count, align 4
  %10723 = icmp uge i32 %10722, 8
  %10724 = and i1 %10721, %10723
  br i1 %10724, label %ready.overflow.trap2264, label %ready.overflow.resume2265

ready.overflow.trap2264:                          ; preds = %ready.overflow.resume2259
  call void @llvm.trap()
  unreachable

ready.overflow.resume2265:                        ; preds = %ready.overflow.resume2259
  %10725 = select i1 %10721, i32 %10722, i32 0
  %10726 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10725
  %10727 = load <8 x i1>, ptr %10726, align 1
  %10728 = select i1 %10721, <8 x i1> %10712, <8 x i1> %10727
  store <8 x i1> %10728, ptr %10726, align 1
  %10729 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10725
  %10730 = load i32, ptr %10729, align 4
  %10731 = select i1 %10721, i32 %convergence.dynamic.target2263, i32 %10730
  store i32 %10731, ptr %10729, align 4
  %10732 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10725
  %10733 = load i32, ptr %10732, align 4
  %10734 = select i1 %10721, i32 %10718, i32 %10733
  store i32 %10734, ptr %10732, align 4
  %10735 = add i32 %10722, 1
  %10736 = select i1 %10721, i32 %10735, i32 %10722
  store i32 %10736, ptr %ready.count, align 4
  %10737 = load <8 x i1>, ptr %runnable.mask, align 1
  %10738 = or <8 x i1> %10737, %10712
  store <8 x i1> %10738, ptr %runnable.mask, align 1
  %10739 = load i8, ptr %frame.active, align 1
  %10740 = and i8 %10739, 16
  %10741 = icmp ne i8 %10740, 0
  %10742 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %10743 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %10744 = load <8 x i1>, ptr %10742, align 1
  %10745 = load <8 x i1>, ptr %10743, align 1
  %10746 = and <8 x i1> %10744, %10583
  %10747 = icmp eq <8 x i1> %10745, %10746
  %10748 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10747)
  %10749 = and i1 %10741, %10748
  %.splatinsert2266 = insertelement <8 x i1> poison, i1 %10749, i64 0
  %.splat2267 = shufflevector <8 x i1> %.splatinsert2266, <8 x i1> poison, <8 x i32> zeroinitializer
  %10750 = select <8 x i1> %.splat2267, <8 x i1> %10745, <8 x i1> zeroinitializer
  %10751 = select i1 %10749, <8 x i1> zeroinitializer, <8 x i1> %10746
  store <8 x i1> %10751, ptr %10742, align 1
  %10752 = select i1 %10749, <8 x i1> zeroinitializer, <8 x i1> %10745
  store <8 x i1> %10752, ptr %10743, align 1
  %10753 = and i8 %10739, -17
  %10754 = select i1 %10749, i8 %10753, i8 %10739
  store i8 %10754, ptr %frame.active, align 1
  %10755 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10756 = extractelement <8 x i32> %10755, i32 4
  %10757 = load <8 x i32>, ptr %frame.static.id, align 32
  %10758 = extractelement <8 x i32> %10757, i32 4
  %convergence.target.pointer2268 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10758
  %convergence.dynamic.target2269 = load i32, ptr %convergence.target.pointer2268, align 4
  %10759 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10750)
  %10760 = load i32, ptr %ready.count, align 4
  %10761 = icmp uge i32 %10760, 8
  %10762 = and i1 %10759, %10761
  br i1 %10762, label %ready.overflow.trap2270, label %ready.overflow.resume2271

ready.overflow.trap2270:                          ; preds = %ready.overflow.resume2265
  call void @llvm.trap()
  unreachable

ready.overflow.resume2271:                        ; preds = %ready.overflow.resume2265
  %10763 = select i1 %10759, i32 %10760, i32 0
  %10764 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10763
  %10765 = load <8 x i1>, ptr %10764, align 1
  %10766 = select i1 %10759, <8 x i1> %10750, <8 x i1> %10765
  store <8 x i1> %10766, ptr %10764, align 1
  %10767 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10763
  %10768 = load i32, ptr %10767, align 4
  %10769 = select i1 %10759, i32 %convergence.dynamic.target2269, i32 %10768
  store i32 %10769, ptr %10767, align 4
  %10770 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10763
  %10771 = load i32, ptr %10770, align 4
  %10772 = select i1 %10759, i32 %10756, i32 %10771
  store i32 %10772, ptr %10770, align 4
  %10773 = add i32 %10760, 1
  %10774 = select i1 %10759, i32 %10773, i32 %10760
  store i32 %10774, ptr %ready.count, align 4
  %10775 = load <8 x i1>, ptr %runnable.mask, align 1
  %10776 = or <8 x i1> %10775, %10750
  store <8 x i1> %10776, ptr %runnable.mask, align 1
  %10777 = load i8, ptr %frame.active, align 1
  %10778 = and i8 %10777, 32
  %10779 = icmp ne i8 %10778, 0
  %10780 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %10781 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %10782 = load <8 x i1>, ptr %10780, align 1
  %10783 = load <8 x i1>, ptr %10781, align 1
  %10784 = and <8 x i1> %10782, %10583
  %10785 = icmp eq <8 x i1> %10783, %10784
  %10786 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10785)
  %10787 = and i1 %10779, %10786
  %.splatinsert2272 = insertelement <8 x i1> poison, i1 %10787, i64 0
  %.splat2273 = shufflevector <8 x i1> %.splatinsert2272, <8 x i1> poison, <8 x i32> zeroinitializer
  %10788 = select <8 x i1> %.splat2273, <8 x i1> %10783, <8 x i1> zeroinitializer
  %10789 = select i1 %10787, <8 x i1> zeroinitializer, <8 x i1> %10784
  store <8 x i1> %10789, ptr %10780, align 1
  %10790 = select i1 %10787, <8 x i1> zeroinitializer, <8 x i1> %10783
  store <8 x i1> %10790, ptr %10781, align 1
  %10791 = and i8 %10777, -33
  %10792 = select i1 %10787, i8 %10791, i8 %10777
  store i8 %10792, ptr %frame.active, align 1
  %10793 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10794 = extractelement <8 x i32> %10793, i32 5
  %10795 = load <8 x i32>, ptr %frame.static.id, align 32
  %10796 = extractelement <8 x i32> %10795, i32 5
  %convergence.target.pointer2274 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10796
  %convergence.dynamic.target2275 = load i32, ptr %convergence.target.pointer2274, align 4
  %10797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10788)
  %10798 = load i32, ptr %ready.count, align 4
  %10799 = icmp uge i32 %10798, 8
  %10800 = and i1 %10797, %10799
  br i1 %10800, label %ready.overflow.trap2276, label %ready.overflow.resume2277

ready.overflow.trap2276:                          ; preds = %ready.overflow.resume2271
  call void @llvm.trap()
  unreachable

ready.overflow.resume2277:                        ; preds = %ready.overflow.resume2271
  %10801 = select i1 %10797, i32 %10798, i32 0
  %10802 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10801
  %10803 = load <8 x i1>, ptr %10802, align 1
  %10804 = select i1 %10797, <8 x i1> %10788, <8 x i1> %10803
  store <8 x i1> %10804, ptr %10802, align 1
  %10805 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10801
  %10806 = load i32, ptr %10805, align 4
  %10807 = select i1 %10797, i32 %convergence.dynamic.target2275, i32 %10806
  store i32 %10807, ptr %10805, align 4
  %10808 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10801
  %10809 = load i32, ptr %10808, align 4
  %10810 = select i1 %10797, i32 %10794, i32 %10809
  store i32 %10810, ptr %10808, align 4
  %10811 = add i32 %10798, 1
  %10812 = select i1 %10797, i32 %10811, i32 %10798
  store i32 %10812, ptr %ready.count, align 4
  %10813 = load <8 x i1>, ptr %runnable.mask, align 1
  %10814 = or <8 x i1> %10813, %10788
  store <8 x i1> %10814, ptr %runnable.mask, align 1
  %10815 = load i8, ptr %frame.active, align 1
  %10816 = and i8 %10815, 64
  %10817 = icmp ne i8 %10816, 0
  %10818 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %10819 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %10820 = load <8 x i1>, ptr %10818, align 1
  %10821 = load <8 x i1>, ptr %10819, align 1
  %10822 = and <8 x i1> %10820, %10583
  %10823 = icmp eq <8 x i1> %10821, %10822
  %10824 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10823)
  %10825 = and i1 %10817, %10824
  %.splatinsert2278 = insertelement <8 x i1> poison, i1 %10825, i64 0
  %.splat2279 = shufflevector <8 x i1> %.splatinsert2278, <8 x i1> poison, <8 x i32> zeroinitializer
  %10826 = select <8 x i1> %.splat2279, <8 x i1> %10821, <8 x i1> zeroinitializer
  %10827 = select i1 %10825, <8 x i1> zeroinitializer, <8 x i1> %10822
  store <8 x i1> %10827, ptr %10818, align 1
  %10828 = select i1 %10825, <8 x i1> zeroinitializer, <8 x i1> %10821
  store <8 x i1> %10828, ptr %10819, align 1
  %10829 = and i8 %10815, -65
  %10830 = select i1 %10825, i8 %10829, i8 %10815
  store i8 %10830, ptr %frame.active, align 1
  %10831 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10832 = extractelement <8 x i32> %10831, i32 6
  %10833 = load <8 x i32>, ptr %frame.static.id, align 32
  %10834 = extractelement <8 x i32> %10833, i32 6
  %convergence.target.pointer2280 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10834
  %convergence.dynamic.target2281 = load i32, ptr %convergence.target.pointer2280, align 4
  %10835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10826)
  %10836 = load i32, ptr %ready.count, align 4
  %10837 = icmp uge i32 %10836, 8
  %10838 = and i1 %10835, %10837
  br i1 %10838, label %ready.overflow.trap2282, label %ready.overflow.resume2283

ready.overflow.trap2282:                          ; preds = %ready.overflow.resume2277
  call void @llvm.trap()
  unreachable

ready.overflow.resume2283:                        ; preds = %ready.overflow.resume2277
  %10839 = select i1 %10835, i32 %10836, i32 0
  %10840 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10839
  %10841 = load <8 x i1>, ptr %10840, align 1
  %10842 = select i1 %10835, <8 x i1> %10826, <8 x i1> %10841
  store <8 x i1> %10842, ptr %10840, align 1
  %10843 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10839
  %10844 = load i32, ptr %10843, align 4
  %10845 = select i1 %10835, i32 %convergence.dynamic.target2281, i32 %10844
  store i32 %10845, ptr %10843, align 4
  %10846 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10839
  %10847 = load i32, ptr %10846, align 4
  %10848 = select i1 %10835, i32 %10832, i32 %10847
  store i32 %10848, ptr %10846, align 4
  %10849 = add i32 %10836, 1
  %10850 = select i1 %10835, i32 %10849, i32 %10836
  store i32 %10850, ptr %ready.count, align 4
  %10851 = load <8 x i1>, ptr %runnable.mask, align 1
  %10852 = or <8 x i1> %10851, %10826
  store <8 x i1> %10852, ptr %runnable.mask, align 1
  %10853 = load i8, ptr %frame.active, align 1
  %10854 = and i8 %10853, -128
  %10855 = icmp ne i8 %10854, 0
  %10856 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %10857 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %10858 = load <8 x i1>, ptr %10856, align 1
  %10859 = load <8 x i1>, ptr %10857, align 1
  %10860 = and <8 x i1> %10858, %10583
  %10861 = icmp eq <8 x i1> %10859, %10860
  %10862 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10861)
  %10863 = and i1 %10855, %10862
  %.splatinsert2284 = insertelement <8 x i1> poison, i1 %10863, i64 0
  %.splat2285 = shufflevector <8 x i1> %.splatinsert2284, <8 x i1> poison, <8 x i32> zeroinitializer
  %10864 = select <8 x i1> %.splat2285, <8 x i1> %10859, <8 x i1> zeroinitializer
  %10865 = select i1 %10863, <8 x i1> zeroinitializer, <8 x i1> %10860
  store <8 x i1> %10865, ptr %10856, align 1
  %10866 = select i1 %10863, <8 x i1> zeroinitializer, <8 x i1> %10859
  store <8 x i1> %10866, ptr %10857, align 1
  %10867 = and i8 %10853, 127
  %10868 = select i1 %10863, i8 %10867, i8 %10853
  store i8 %10868, ptr %frame.active, align 1
  %10869 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10870 = extractelement <8 x i32> %10869, i32 7
  %10871 = load <8 x i32>, ptr %frame.static.id, align 32
  %10872 = extractelement <8 x i32> %10871, i32 7
  %convergence.target.pointer2286 = getelementptr inbounds [39 x i32], ptr @convergence.targets, i32 0, i32 %10872
  %convergence.dynamic.target2287 = load i32, ptr %convergence.target.pointer2286, align 4
  %10873 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10864)
  %10874 = load i32, ptr %ready.count, align 4
  %10875 = icmp uge i32 %10874, 8
  %10876 = and i1 %10873, %10875
  br i1 %10876, label %ready.overflow.trap2288, label %ready.overflow.resume2289

ready.overflow.trap2288:                          ; preds = %ready.overflow.resume2283
  call void @llvm.trap()
  unreachable

ready.overflow.resume2289:                        ; preds = %ready.overflow.resume2283
  %10877 = select i1 %10873, i32 %10874, i32 0
  %10878 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10877
  %10879 = load <8 x i1>, ptr %10878, align 1
  %10880 = select i1 %10873, <8 x i1> %10864, <8 x i1> %10879
  store <8 x i1> %10880, ptr %10878, align 1
  %10881 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10877
  %10882 = load i32, ptr %10881, align 4
  %10883 = select i1 %10873, i32 %convergence.dynamic.target2287, i32 %10882
  store i32 %10883, ptr %10881, align 4
  %10884 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10877
  %10885 = load i32, ptr %10884, align 4
  %10886 = select i1 %10873, i32 %10870, i32 %10885
  store i32 %10886, ptr %10884, align 4
  %10887 = add i32 %10874, 1
  %10888 = select i1 %10873, i32 %10887, i32 %10874
  store i32 %10888, ptr %ready.count, align 4
  %10889 = load <8 x i1>, ptr %runnable.mask, align 1
  %10890 = or <8 x i1> %10889, %10864
  store <8 x i1> %10890, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

define dso_local void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

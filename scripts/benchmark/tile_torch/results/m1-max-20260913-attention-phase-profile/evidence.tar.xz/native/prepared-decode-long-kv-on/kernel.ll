; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 4096
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 8192
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 12288
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 77824
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 143360
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 143872
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 144384
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 144896
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 145408
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 149504
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill41 = alloca i64, align 8
  store i64 0, ptr %.spill41, align 4
  %.spill42 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill42, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill43 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill43, align 64
  %tile_snapshot.spill44 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill44, align 64
  %.slot45 = alloca i64, align 8
  store i64 0, ptr %.slot45, align 4
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.spill49 = alloca i64, align 8
  store i64 0, ptr %.spill49, align 4
  %tile_snapshot.spill50 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill50, align 64
  %.slot51 = alloca i64, align 8
  store i64 0, ptr %.slot51, align 4
  %.spill52 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill52, align 64
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %tile_snapshot.spill54 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill54, align 64
  %.slot55 = alloca i64, align 8
  store i64 0, ptr %.slot55, align 4
  %.spill56 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill56, align 64
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.spill58 = alloca i64, align 8
  store i64 0, ptr %.spill58, align 4
  %.spill59 = alloca i1, align 1
  store i1 false, ptr %.spill59, align 1
  %.spill60 = alloca i1, align 1
  store i1 false, ptr %.spill60, align 1
  %.spill61 = alloca i1, align 1
  store i1 false, ptr %.spill61, align 1
  %.spill62 = alloca i1, align 1
  store i1 false, ptr %.spill62, align 1
  %.spill63 = alloca i1, align 1
  store i1 false, ptr %.spill63, align 1
  %.spill64 = alloca i1, align 1
  store i1 false, ptr %.spill64, align 1
  %.spill65 = alloca i1, align 1
  store i1 false, ptr %.spill65, align 1
  %.spill66 = alloca i1, align 1
  store i1 false, ptr %.spill66, align 1
  %.spill67 = alloca i1, align 1
  store i1 false, ptr %.spill67, align 1
  %.spill68 = alloca i1, align 1
  store i1 false, ptr %.spill68, align 1
  %.spill69 = alloca i1, align 1
  store i1 false, ptr %.spill69, align 1
  %.spill70 = alloca i1, align 1
  store i1 false, ptr %.spill70, align 1
  %.spill71 = alloca i1, align 1
  store i1 false, ptr %.spill71, align 1
  %.spill72 = alloca i1, align 1
  store i1 false, ptr %.spill72, align 1
  %.spill73 = alloca i1, align 1
  store i1 false, ptr %.spill73, align 1
  %.spill74 = alloca i1, align 1
  store i1 false, ptr %.spill74, align 1
  %.spill75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill75, align 32
  %.spill76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill76, align 32
  %.spill77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill77, align 32
  %.spill78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill78, align 32
  %.spill79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill79, align 32
  %.spill80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill80, align 32
  %.spill81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill81, align 32
  %.spill82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill82, align 32
  %.spill83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill83, align 32
  %.spill84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill84, align 32
  %.spill85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill85, align 32
  %.spill86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill86, align 32
  %.spill87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill87, align 32
  %.spill88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill88, align 32
  %.spill89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill89, align 32
  %.spill90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill90, align 32
  %tile_snapshot.spill91 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill91, align 64
  %.slot92 = alloca i64, align 8
  store i64 0, ptr %.slot92, align 4
  %.slot93 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot93, align 32
  %.spill94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill94, align 32
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %tile_snapshot.spill96 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill96, align 64
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.slot98 = alloca i64, align 8
  store i64 0, ptr %.slot98, align 4
  %.slot99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %tile_snapshot.spill101 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill101, align 64
  %.slot102 = alloca i64, align 8
  store i64 0, ptr %.slot102, align 4
  %tile_snapshot.spill103 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill103, align 64
  %.slot104 = alloca i64, align 8
  store i64 0, ptr %.slot104, align 4
  %.slot105 = alloca i64, align 8
  store i64 0, ptr %.slot105, align 4
  %.slot106 = alloca i64, align 8
  store i64 0, ptr %.slot106, align 4
  %33 = getelementptr i8, ptr %argument_buffer, i64 0
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = getelementptr i8, ptr %argument_buffer, i64 16
  %40 = load ptr, ptr %39, align 16
  %41 = getelementptr i8, ptr %39, i64 8
  %42 = load i64, ptr %41, align 8
  %43 = insertvalue { ptr, i64 } poison, ptr %40, 0
  %44 = insertvalue { ptr, i64 } %43, i64 %42, 1
  %45 = getelementptr i8, ptr %argument_buffer, i64 32
  %46 = load ptr, ptr %45, align 16
  %47 = getelementptr i8, ptr %45, i64 8
  %48 = load i64, ptr %47, align 8
  %49 = insertvalue { ptr, i64 } poison, ptr %46, 0
  %50 = insertvalue { ptr, i64 } %49, i64 %48, 1
  %51 = getelementptr i8, ptr %argument_buffer, i64 48
  %52 = load ptr, ptr %51, align 16
  %53 = getelementptr i8, ptr %51, i64 8
  %54 = load i64, ptr %53, align 8
  %55 = insertvalue { ptr, i64 } poison, ptr %52, 0
  %56 = insertvalue { ptr, i64 } %55, i64 %54, 1
  %57 = load i32, ptr %launch_config, align 4
  %58 = getelementptr i8, ptr %launch_config, i64 12
  %59 = load i32, ptr %58, align 4
  %60 = getelementptr i8, ptr %launch_config, i64 4
  %61 = load i32, ptr %60, align 4
  %62 = getelementptr i8, ptr %launch_config, i64 16
  %63 = load i32, ptr %62, align 4
  %64 = getelementptr i8, ptr %launch_config, i64 8
  %65 = load i32, ptr %64, align 4
  %66 = getelementptr i8, ptr %launch_config, i64 20
  %67 = load i32, ptr %66, align 4
  %68 = getelementptr i8, ptr %launch_config, i64 36
  %69 = load i32, ptr %68, align 4
  %.splatinsert107 = insertelement <8 x i32> poison, i32 %69, i64 0
  %.splat108 = shufflevector <8 x i32> %.splatinsert107, <8 x i32> poison, <8 x i32> zeroinitializer
  %70 = add <8 x i32> %.splat108, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %71 = mul i32 %57, 32
  %.splatinsert109 = insertelement <8 x i32> poison, i32 %71, i64 0
  %.splat110 = shufflevector <8 x i32> %.splatinsert109, <8 x i32> poison, <8 x i32> zeroinitializer
  %72 = add <8 x i32> %.splat110, %70
  %73 = mul i32 %61, 1
  %.splatinsert111 = insertelement <8 x i32> poison, i32 %73, i64 0
  %.splat112 = shufflevector <8 x i32> %.splatinsert111, <8 x i32> poison, <8 x i32> zeroinitializer
  %74 = add <8 x i32> %.splat112, zeroinitializer
  %75 = mul i32 %65, 1
  %.splatinsert113 = insertelement <8 x i32> poison, i32 %75, i64 0
  %.splat114 = shufflevector <8 x i32> %.splatinsert113, <8 x i32> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i32> %.splat114, zeroinitializer
  %77 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %72, 0
  %78 = insertvalue [3 x <8 x i32>] %77, <8 x i32> %74, 1
  %79 = insertvalue [3 x <8 x i32>] %78, <8 x i32> %76, 2
  %.splatinsert115 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat116 = shufflevector <8 x i32> %.splatinsert115, <8 x i32> poison, <8 x i32> zeroinitializer
  %80 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat116
  %81 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  br i1 %81, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %82 = extractvalue [3 x <8 x i32>] %79, 0
  %83 = zext <8 x i32> %82 to <8 x i64>
  %84 = select <8 x i1> %80, <8 x i64> %83, <8 x i64> zeroinitializer
  %85 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %86 = sdiv <8 x i64> %84, %85
  %87 = load <8 x i64>, ptr %.spill, align 64
  %88 = select <8 x i1> %80, <8 x i64> %86, <8 x i64> %87
  store <8 x i64> %88, ptr %.spill, align 64
  store i64 0, ptr %.spill41, align 4
  %89 = select <8 x i1> %80, <8 x i64> %86, <8 x i64> zeroinitializer
  %90 = select <8 x i1> %80, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %91 = sdiv <8 x i64> %89, %90
  %92 = load <8 x i64>, ptr %.spill42, align 64
  %93 = select <8 x i1> %80, <8 x i64> %91, <8 x i64> %92
  store <8 x i64> %93, ptr %.spill42, align 64
  %94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %94, 0
  %97 = select <8 x i1> %80, <8 x ptr> %95, <8 x ptr> %96
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %94, 1
  %100 = select <8 x i1> %80, <8 x i64> %98, <8 x i64> %99
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %97, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  store { <8 x ptr>, <8 x i64> } %102, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %103 = icmp slt i64 %.state, 128
  br i1 %103, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load i64, ptr %.spill41, align 4
  %104 = add i64 %.spill.load, 0
  %.spill.load117 = load <8 x i64>, ptr %.spill, align 64
  %105 = add <8 x i64> %.spill.load117, zeroinitializer
  %106 = mul i64 %104, 16
  %.splatinsert118 = insertelement <8 x i64> poison, i64 %106, i64 0
  %.splat119 = shufflevector <8 x i64> %.splatinsert118, <8 x i64> poison, <8 x i32> zeroinitializer
  %107 = add <8 x i64> %.splat119, %105
  %.spill.load120 = load i64, ptr %.spill41, align 4
  %108 = add i64 %.spill.load120, 0
  %109 = mul <8 x i64> %107, splat (i64 1)
  %.splatinsert121 = insertelement <8 x i64> poison, i64 %108, i64 0
  %.splat122 = shufflevector <8 x i64> %.splatinsert121, <8 x i64> poison, <8 x i32> zeroinitializer
  %110 = add <8 x i64> %109, %.splat122
  %.state123 = load i64, ptr %.slot, align 4
  %111 = add i64 0, %.state123
  %112 = mul <8 x i64> %110, splat (i64 128)
  %.splatinsert124 = insertelement <8 x i64> poison, i64 %111, i64 0
  %.splat125 = shufflevector <8 x i64> %.splatinsert124, <8 x i64> poison, <8 x i32> zeroinitializer
  %113 = add <8 x i64> %112, %.splat125
  %114 = extractvalue { ptr, i64 } %38, 0
  %115 = mul <8 x i64> %113, splat (i64 4)
  %116 = getelementptr i8, ptr %114, <8 x i64> %115
  %117 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %116, <8 x i1> %80, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %119 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state126 = load i64, ptr %.slot, align 4
  %.splatinsert127 = insertelement <8 x i64> poison, i64 %.state126, i64 0
  %.splat128 = shufflevector <8 x i64> %.splatinsert127, <8 x i64> poison, <8 x i32> zeroinitializer
  %120 = mul <8 x i64> %.splat128, splat (i64 4)
  %121 = add <8 x i64> %119, %120
  %122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %118, 0
  %123 = insertvalue { <8 x ptr>, <8 x i64> } %122, <8 x i64> %121, 1
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %123, 0
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %123, 1
  %126 = getelementptr i8, <8 x ptr> %124, <8 x i64> %125
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %117, <8 x ptr> align 1 %126, <8 x i1> %80)
  %.state129 = load i64, ptr %.slot, align 4
  %127 = add i64 %.state129, 1
  store i64 %127, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %128, 0
  %131 = select <8 x i1> %80, <8 x ptr> %129, <8 x ptr> %130
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %128, 1
  %134 = select <8 x i1> %80, <8 x i64> %132, <8 x i64> %133
  %135 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %131, 0
  %136 = insertvalue { <8 x ptr>, <8 x i64> } %135, <8 x i64> %134, 1
  store { <8 x ptr>, <8 x i64> } %136, ptr %tile_snapshot.spill43, align 64
  %137 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %137, 0
  %140 = select <8 x i1> %80, <8 x ptr> %138, <8 x ptr> %139
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %137, 1
  %143 = select <8 x i1> %80, <8 x i64> %141, <8 x i64> %142
  %144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %140, 0
  %145 = insertvalue { <8 x ptr>, <8 x i64> } %144, <8 x i64> %143, 1
  store { <8 x ptr>, <8 x i64> } %145, ptr %tile_snapshot.spill44, align 64
  store i64 0, ptr %.slot45, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state130 = load i64, ptr %.slot45, align 4
  %146 = icmp slt i64 %.state130, 128
  br i1 %146, label %direct.true131, label %direct.false132

direct.schedule.5:                                ; preds = %direct.true131
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %.state134 = load i64, ptr %.slot45, align 4
  %.splatinsert135 = insertelement <8 x i64> poison, i64 %.state134, i64 0
  %.splat136 = shufflevector <8 x i64> %.splatinsert135, <8 x i64> poison, <8 x i32> zeroinitializer
  %149 = mul <8 x i64> %.splat136, splat (i64 32)
  %150 = add <8 x i64> %148, %149
  %151 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %147, 0
  %152 = insertvalue { <8 x ptr>, <8 x i64> } %151, <8 x i64> %150, 1
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %152, 1
  %155 = extractelement <8 x ptr> %153, i32 0
  %156 = extractelement <8 x i64> %154, i32 0
  %157 = sub i64 %156, 0
  %158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %159 = select i1 %158, i64 %157, i64 0
  %private.contiguous.address = getelementptr i8, ptr %155, i64 %159
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %160 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %160, ptr %private.contiguous.address, align 4
  %.state137 = load i64, ptr %.slot45, align 4
  %161 = add i64 %.state137, 1
  store i64 %161, ptr %.slot45, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false132
  store i64 0, ptr %.slot46, align 4
  %162 = load <8 x float>, ptr %.slot47, align 32
  %163 = select <8 x i1> %80, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %162
  store <8 x float> %163, ptr %.slot47, align 32
  %164 = load <8 x float>, ptr %.slot48, align 32
  %165 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %164
  store <8 x float> %165, ptr %.slot48, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.33, %direct.schedule.6
  %.state138 = load i64, ptr %.slot46, align 4
  %166 = icmp slt i64 %.state138, 513
  br i1 %166, label %direct.true139, label %direct.false140

direct.schedule.8:                                ; preds = %direct.true139
  %.state141 = load i64, ptr %.slot46, align 4
  %167 = sdiv i64 %.state141, 1
  %168 = mul i64 %167, 16
  store i64 %168, ptr %.spill49, align 4
  %169 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %169, 0
  %172 = select <8 x i1> %80, <8 x ptr> %170, <8 x ptr> %171
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %169, 1
  %175 = select <8 x i1> %80, <8 x i64> %173, <8 x i64> %174
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %172, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  store { <8 x ptr>, <8 x i64> } %177, ptr %tile_snapshot.spill50, align 64
  store i64 0, ptr %.slot51, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state142 = load i64, ptr %.slot51, align 4
  %178 = icmp slt i64 %.state142, 2048
  br i1 %178, label %direct.true143, label %direct.false144

direct.schedule.10:                               ; preds = %direct.true143
  %.state145 = load i64, ptr %.slot51, align 4
  %179 = srem i64 %.state145, 128
  %.state146 = load i64, ptr %.slot51, align 4
  %180 = sdiv i64 %.state146, 128
  %.spill.load147 = load i64, ptr %.spill41, align 4
  %181 = add i64 %.spill.load147, 0
  %.spill.load148 = load <8 x i64>, ptr %.spill42, align 64
  %182 = add <8 x i64> %.spill.load148, zeroinitializer
  %183 = mul i64 %181, 4
  %.splatinsert149 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat150 = shufflevector <8 x i64> %.splatinsert149, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %.splat150, %182
  %.spill.load151 = load i64, ptr %.spill49, align 4
  %185 = add i64 %.spill.load151, %180
  %186 = mul <8 x i64> %184, splat (i64 8193)
  %.splatinsert152 = insertelement <8 x i64> poison, i64 %185, i64 0
  %.splat153 = shufflevector <8 x i64> %.splatinsert152, <8 x i64> poison, <8 x i32> zeroinitializer
  %187 = add <8 x i64> %186, %.splat153
  %188 = icmp sge i64 %185, 0
  %189 = and i1 true, %188
  %190 = icmp slt i64 %185, 8193
  %191 = and i1 %189, %190
  %192 = add i64 0, %179
  %193 = mul <8 x i64> %187, splat (i64 128)
  %.splatinsert154 = insertelement <8 x i64> poison, i64 %192, i64 0
  %.splat155 = shufflevector <8 x i64> %.splatinsert154, <8 x i64> poison, <8 x i32> zeroinitializer
  %194 = add <8 x i64> %193, %.splat155
  %195 = load <8 x i64>, ptr %.spill52, align 64
  %196 = select <8 x i1> %80, <8 x i64> %194, <8 x i64> %195
  store <8 x i64> %196, ptr %.spill52, align 64
  br i1 %191, label %direct.true156, label %direct.false157

direct.schedule.11:                               ; preds = %direct.true156
  %.spill.load158 = load <8 x i64>, ptr %.spill52, align 64
  %197 = extractvalue { ptr, i64 } %44, 0
  %198 = mul <8 x i64> %.spill.load158, splat (i64 4)
  %199 = getelementptr i8, ptr %197, <8 x i64> %198
  %200 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %199, <8 x i1> %80, <8 x float> zeroinitializer)
  %201 = load <8 x float>, ptr %.slot53, align 32
  %202 = select <8 x i1> %80, <8 x float> %200, <8 x float> %201
  store <8 x float> %202, ptr %.slot53, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.11, %direct.false157
  %tile_snapshot.spill.load159 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load159, 0
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load159, 1
  %.state160 = load i64, ptr %.slot51, align 4
  %.splatinsert161 = insertelement <8 x i64> poison, i64 %.state160, i64 0
  %.splat162 = shufflevector <8 x i64> %.splatinsert161, <8 x i64> poison, <8 x i32> zeroinitializer
  %205 = mul <8 x i64> %.splat162, splat (i64 4)
  %206 = add <8 x i64> %204, %205
  %207 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %203, 0
  %208 = insertvalue { <8 x ptr>, <8 x i64> } %207, <8 x i64> %206, 1
  %.state163 = load <8 x float>, ptr %.slot53, align 32
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %208, 0
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %208, 1
  %211 = getelementptr i8, <8 x ptr> %209, <8 x i64> %210
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state163, <8 x ptr> align 1 %211, <8 x i1> %80)
  %.state164 = load i64, ptr %.slot51, align 4
  %212 = add i64 %.state164, 1
  store i64 %212, ptr %.slot51, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false144
  %213 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %213, 0
  %216 = select <8 x i1> %80, <8 x ptr> %214, <8 x ptr> %215
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %213, 1
  %219 = select <8 x i1> %80, <8 x i64> %217, <8 x i64> %218
  %220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %216, 0
  %221 = insertvalue { <8 x ptr>, <8 x i64> } %220, <8 x i64> %219, 1
  store { <8 x ptr>, <8 x i64> } %221, ptr %tile_snapshot.spill54, align 64
  store i64 0, ptr %.slot55, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state165 = load i64, ptr %.slot55, align 4
  %222 = icmp slt i64 %.state165, 2048
  br i1 %222, label %direct.true166, label %direct.false167

direct.schedule.15:                               ; preds = %direct.true166
  %.state168 = load i64, ptr %.slot55, align 4
  %223 = srem i64 %.state168, 128
  %.state169 = load i64, ptr %.slot55, align 4
  %224 = sdiv i64 %.state169, 128
  %.spill.load170 = load i64, ptr %.spill41, align 4
  %225 = add i64 %.spill.load170, 0
  %.spill.load171 = load <8 x i64>, ptr %.spill42, align 64
  %226 = add <8 x i64> %.spill.load171, zeroinitializer
  %227 = mul i64 %225, 4
  %.splatinsert172 = insertelement <8 x i64> poison, i64 %227, i64 0
  %.splat173 = shufflevector <8 x i64> %.splatinsert172, <8 x i64> poison, <8 x i32> zeroinitializer
  %228 = add <8 x i64> %.splat173, %226
  %.spill.load174 = load i64, ptr %.spill49, align 4
  %229 = add i64 %.spill.load174, %224
  %230 = mul <8 x i64> %228, splat (i64 8193)
  %.splatinsert175 = insertelement <8 x i64> poison, i64 %229, i64 0
  %.splat176 = shufflevector <8 x i64> %.splatinsert175, <8 x i64> poison, <8 x i32> zeroinitializer
  %231 = add <8 x i64> %230, %.splat176
  %232 = icmp sge i64 %229, 0
  %233 = and i1 true, %232
  %234 = icmp slt i64 %229, 8193
  %235 = and i1 %233, %234
  %236 = add i64 0, %223
  %237 = mul <8 x i64> %231, splat (i64 128)
  %.splatinsert177 = insertelement <8 x i64> poison, i64 %236, i64 0
  %.splat178 = shufflevector <8 x i64> %.splatinsert177, <8 x i64> poison, <8 x i32> zeroinitializer
  %238 = add <8 x i64> %237, %.splat178
  %239 = load <8 x i64>, ptr %.spill56, align 64
  %240 = select <8 x i1> %80, <8 x i64> %238, <8 x i64> %239
  store <8 x i64> %240, ptr %.spill56, align 64
  br i1 %235, label %direct.true179, label %direct.false180

direct.schedule.16:                               ; preds = %direct.true179
  %.spill.load181 = load <8 x i64>, ptr %.spill56, align 64
  %241 = extractvalue { ptr, i64 } %50, 0
  %242 = mul <8 x i64> %.spill.load181, splat (i64 4)
  %243 = getelementptr i8, ptr %241, <8 x i64> %242
  %244 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %243, <8 x i1> %80, <8 x float> zeroinitializer)
  %245 = load <8 x float>, ptr %.slot57, align 32
  %246 = select <8 x i1> %80, <8 x float> %244, <8 x float> %245
  store <8 x float> %246, ptr %.slot57, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.schedule.16, %direct.false180
  %tile_snapshot.spill.load182 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 0
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 1
  %.state183 = load i64, ptr %.slot55, align 4
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %.state183, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %249 = mul <8 x i64> %.splat185, splat (i64 4)
  %250 = add <8 x i64> %248, %249
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %247, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %.state186 = load <8 x float>, ptr %.slot57, align 32
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %252, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = getelementptr i8, <8 x ptr> %253, <8 x i64> %254
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state186, <8 x ptr> align 1 %255, <8 x i1> %80)
  %.state187 = load i64, ptr %.slot55, align 4
  %256 = add i64 %.state187, 1
  store i64 %256, ptr %.slot55, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false167
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %259 = add <8 x i64> %258, zeroinitializer
  %260 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %257, 0
  %261 = insertvalue { <8 x ptr>, <8 x i64> } %260, <8 x i64> %259, 1
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %261, 0
  %263 = extractvalue { <8 x ptr>, <8 x i64> } %261, 1
  %264 = getelementptr i8, <8 x ptr> %262, <8 x i64> %263
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %264, <8 x i1> %80)
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %267 = add <8 x i64> %266, splat (i64 4)
  %268 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %269 = insertvalue { <8 x ptr>, <8 x i64> } %268, <8 x i64> %267, 1
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %269, 0
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %269, 1
  %272 = getelementptr i8, <8 x ptr> %270, <8 x i64> %271
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %272, <8 x i1> %80)
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %275 = add <8 x i64> %274, splat (i64 8)
  %276 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %273, 0
  %277 = insertvalue { <8 x ptr>, <8 x i64> } %276, <8 x i64> %275, 1
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %277, 0
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %277, 1
  %280 = getelementptr i8, <8 x ptr> %278, <8 x i64> %279
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %280, <8 x i1> %80)
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %283 = add <8 x i64> %282, splat (i64 12)
  %284 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %281, 0
  %285 = insertvalue { <8 x ptr>, <8 x i64> } %284, <8 x i64> %283, 1
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %285, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %285, 1
  %288 = getelementptr i8, <8 x ptr> %286, <8 x i64> %287
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %288, <8 x i1> %80)
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %291 = add <8 x i64> %290, splat (i64 16)
  %292 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %289, 0
  %293 = insertvalue { <8 x ptr>, <8 x i64> } %292, <8 x i64> %291, 1
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %293, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %293, 1
  %296 = getelementptr i8, <8 x ptr> %294, <8 x i64> %295
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %296, <8 x i1> %80)
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %299 = add <8 x i64> %298, splat (i64 20)
  %300 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %297, 0
  %301 = insertvalue { <8 x ptr>, <8 x i64> } %300, <8 x i64> %299, 1
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %301, 0
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %301, 1
  %304 = getelementptr i8, <8 x ptr> %302, <8 x i64> %303
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %304, <8 x i1> %80)
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %307 = add <8 x i64> %306, splat (i64 24)
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %305, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %309, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = getelementptr i8, <8 x ptr> %310, <8 x i64> %311
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %312, <8 x i1> %80)
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %315 = add <8 x i64> %314, splat (i64 28)
  %316 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %313, 0
  %317 = insertvalue { <8 x ptr>, <8 x i64> } %316, <8 x i64> %315, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %317, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %317, 1
  %320 = getelementptr i8, <8 x ptr> %318, <8 x i64> %319
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %320, <8 x i1> %80)
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %323 = add <8 x i64> %322, splat (i64 32)
  %324 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %325 = insertvalue { <8 x ptr>, <8 x i64> } %324, <8 x i64> %323, 1
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %325, 0
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %325, 1
  %328 = getelementptr i8, <8 x ptr> %326, <8 x i64> %327
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %328, <8 x i1> %80)
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %331 = add <8 x i64> %330, splat (i64 36)
  %332 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %329, 0
  %333 = insertvalue { <8 x ptr>, <8 x i64> } %332, <8 x i64> %331, 1
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %333, 0
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %333, 1
  %336 = getelementptr i8, <8 x ptr> %334, <8 x i64> %335
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %336, <8 x i1> %80)
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %339 = add <8 x i64> %338, splat (i64 40)
  %340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %337, 0
  %341 = insertvalue { <8 x ptr>, <8 x i64> } %340, <8 x i64> %339, 1
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %341, 0
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %341, 1
  %344 = getelementptr i8, <8 x ptr> %342, <8 x i64> %343
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %344, <8 x i1> %80)
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %347 = add <8 x i64> %346, splat (i64 44)
  %348 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %345, 0
  %349 = insertvalue { <8 x ptr>, <8 x i64> } %348, <8 x i64> %347, 1
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %349, 0
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %349, 1
  %352 = getelementptr i8, <8 x ptr> %350, <8 x i64> %351
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %352, <8 x i1> %80)
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %355 = add <8 x i64> %354, splat (i64 48)
  %356 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %353, 0
  %357 = insertvalue { <8 x ptr>, <8 x i64> } %356, <8 x i64> %355, 1
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %357, 0
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %357, 1
  %360 = getelementptr i8, <8 x ptr> %358, <8 x i64> %359
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %360, <8 x i1> %80)
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %362 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %363 = add <8 x i64> %362, splat (i64 52)
  %364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %361, 0
  %365 = insertvalue { <8 x ptr>, <8 x i64> } %364, <8 x i64> %363, 1
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %365, 0
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %365, 1
  %368 = getelementptr i8, <8 x ptr> %366, <8 x i64> %367
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %368, <8 x i1> %80)
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %371 = add <8 x i64> %370, splat (i64 56)
  %372 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %369, 0
  %373 = insertvalue { <8 x ptr>, <8 x i64> } %372, <8 x i64> %371, 1
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %373, 0
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %373, 1
  %376 = getelementptr i8, <8 x ptr> %374, <8 x i64> %375
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %376, <8 x i1> %80)
  %377 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %378 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %379 = add <8 x i64> %378, splat (i64 60)
  %380 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %377, 0
  %381 = insertvalue { <8 x ptr>, <8 x i64> } %380, <8 x i64> %379, 1
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %381, 0
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %381, 1
  %384 = getelementptr i8, <8 x ptr> %382, <8 x i64> %383
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %384, <8 x i1> %80)
  %tile_snapshot.spill.load188 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %tile_snapshot.spill.load189 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  %385 = extractelement <8 x i1> %80, i64 0
  br i1 %385, label %mma.active, label %mma.continue

direct.schedule.19:                               ; preds = %direct.schedule.20, %mma.continue203
  %.state285 = load i64, ptr %.slot92, align 4
  %386 = icmp slt i64 %.state285, 16
  br i1 %386, label %direct.true286, label %direct.false287

direct.schedule.20:                               ; preds = %direct.true286
  %.state288 = load i64, ptr %.slot92, align 4
  %387 = sdiv i64 %.state288, 1
  %.spill.load289 = load i64, ptr %.spill58, align 4
  %388 = mul i64 %.spill.load289, 1
  %389 = add i64 %388, 0
  %390 = mul i64 %389, 1
  %391 = add i64 %390, 0
  %392 = mul i64 %391, 16
  %393 = add i64 %392, %387
  %tile_snapshot.spill.load290 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill91, align 64
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load290, 0
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load290, 1
  %.splatinsert291 = insertelement <8 x i64> poison, i64 %393, i64 0
  %.splat292 = shufflevector <8 x i64> %.splatinsert291, <8 x i64> poison, <8 x i32> zeroinitializer
  %396 = mul <8 x i64> %.splat292, splat (i64 32)
  %397 = add <8 x i64> %395, %396
  %398 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %394, 0
  %399 = insertvalue { <8 x ptr>, <8 x i64> } %398, <8 x i64> %397, 1
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %399, 1
  %402 = extractelement <8 x ptr> %400, i32 0
  %403 = extractelement <8 x i64> %401, i32 0
  %404 = sub i64 %403, 0
  %405 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %406 = select i1 %405, i64 %404, i64 0
  %private.contiguous.address293 = getelementptr i8, ptr %402, i64 %406
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address293, align 4
  %407 = select <8 x i1> %80, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.state294 = load <8 x float>, ptr %.slot93, align 32
  %408 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state294, <8 x float> %407)
  %.state295 = load i64, ptr %.slot92, align 4
  %409 = add i64 %.state295, 1
  store i64 %409, ptr %.slot92, align 4
  %410 = load <8 x float>, ptr %.slot93, align 32
  %411 = select <8 x i1> %80, <8 x float> %408, <8 x float> %410
  store <8 x float> %411, ptr %.slot93, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false287
  %.state296 = load <8 x float>, ptr %.slot47, align 32
  %.state297 = load <8 x float>, ptr %.slot93, align 32
  %412 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state296, <8 x float> %.state297)
  %413 = load <8 x float>, ptr %.spill94, align 32
  %414 = select <8 x i1> %80, <8 x float> %412, <8 x float> %413
  store <8 x float> %414, ptr %.spill94, align 32
  %.state298 = load <8 x float>, ptr %.slot47, align 32
  %415 = fsub <8 x float> %.state298, %412
  %416 = select <8 x i1> %80, <8 x float> %415, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %416)
  %417 = load <8 x float>, ptr %.spill95, align 32
  %418 = select <8 x i1> %80, <8 x float> %native.exp, <8 x float> %417
  store <8 x float> %418, ptr %.spill95, align 32
  %.spill.load299 = load <8 x float>, ptr %.spill75, align 32
  %419 = fsub <8 x float> %.spill.load299, %412
  %.spill.load300 = load <8 x float>, ptr %.spill76, align 32
  %420 = fsub <8 x float> %.spill.load300, %412
  %.spill.load301 = load <8 x float>, ptr %.spill77, align 32
  %421 = fsub <8 x float> %.spill.load301, %412
  %.spill.load302 = load <8 x float>, ptr %.spill78, align 32
  %422 = fsub <8 x float> %.spill.load302, %412
  %.spill.load303 = load <8 x float>, ptr %.spill79, align 32
  %423 = fsub <8 x float> %.spill.load303, %412
  %.spill.load304 = load <8 x float>, ptr %.spill80, align 32
  %424 = fsub <8 x float> %.spill.load304, %412
  %.spill.load305 = load <8 x float>, ptr %.spill81, align 32
  %425 = fsub <8 x float> %.spill.load305, %412
  %.spill.load306 = load <8 x float>, ptr %.spill82, align 32
  %426 = fsub <8 x float> %.spill.load306, %412
  %.spill.load307 = load <8 x float>, ptr %.spill83, align 32
  %427 = fsub <8 x float> %.spill.load307, %412
  %.spill.load308 = load <8 x float>, ptr %.spill84, align 32
  %428 = fsub <8 x float> %.spill.load308, %412
  %.spill.load309 = load <8 x float>, ptr %.spill85, align 32
  %429 = fsub <8 x float> %.spill.load309, %412
  %.spill.load310 = load <8 x float>, ptr %.spill86, align 32
  %430 = fsub <8 x float> %.spill.load310, %412
  %.spill.load311 = load <8 x float>, ptr %.spill87, align 32
  %431 = fsub <8 x float> %.spill.load311, %412
  %.spill.load312 = load <8 x float>, ptr %.spill88, align 32
  %432 = fsub <8 x float> %.spill.load312, %412
  %.spill.load313 = load <8 x float>, ptr %.spill89, align 32
  %433 = fsub <8 x float> %.spill.load313, %412
  %.spill.load314 = load <8 x float>, ptr %.spill90, align 32
  %434 = fsub <8 x float> %.spill.load314, %412
  %435 = select <8 x i1> %80, <8 x float> %419, <8 x float> zeroinitializer
  %native.exp315 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %435)
  %436 = select <8 x i1> %80, <8 x float> %420, <8 x float> zeroinitializer
  %native.exp316 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %436)
  %437 = select <8 x i1> %80, <8 x float> %421, <8 x float> zeroinitializer
  %native.exp317 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %437)
  %438 = select <8 x i1> %80, <8 x float> %422, <8 x float> zeroinitializer
  %native.exp318 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %438)
  %439 = select <8 x i1> %80, <8 x float> %423, <8 x float> zeroinitializer
  %native.exp319 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %439)
  %440 = select <8 x i1> %80, <8 x float> %424, <8 x float> zeroinitializer
  %native.exp320 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %440)
  %441 = select <8 x i1> %80, <8 x float> %425, <8 x float> zeroinitializer
  %native.exp321 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %441)
  %442 = select <8 x i1> %80, <8 x float> %426, <8 x float> zeroinitializer
  %native.exp322 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %442)
  %443 = select <8 x i1> %80, <8 x float> %427, <8 x float> zeroinitializer
  %native.exp323 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %443)
  %444 = select <8 x i1> %80, <8 x float> %428, <8 x float> zeroinitializer
  %native.exp324 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %444)
  %445 = select <8 x i1> %80, <8 x float> %429, <8 x float> zeroinitializer
  %native.exp325 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %445)
  %446 = select <8 x i1> %80, <8 x float> %430, <8 x float> zeroinitializer
  %native.exp326 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %446)
  %447 = select <8 x i1> %80, <8 x float> %431, <8 x float> zeroinitializer
  %native.exp327 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %447)
  %448 = select <8 x i1> %80, <8 x float> %432, <8 x float> zeroinitializer
  %native.exp328 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %448)
  %449 = select <8 x i1> %80, <8 x float> %433, <8 x float> zeroinitializer
  %native.exp329 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %449)
  %450 = select <8 x i1> %80, <8 x float> %434, <8 x float> zeroinitializer
  %native.exp330 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %450)
  %.spill.load331 = load i1, ptr %.spill59, align 1
  %.splatinsert332 = insertelement <8 x i1> poison, i1 %.spill.load331, i64 0
  %.splat333 = shufflevector <8 x i1> %.splatinsert332, <8 x i1> poison, <8 x i32> zeroinitializer
  %451 = select <8 x i1> %.splat333, <8 x float> %native.exp315, <8 x float> zeroinitializer
  %.spill.load334 = load i1, ptr %.spill60, align 1
  %.splatinsert335 = insertelement <8 x i1> poison, i1 %.spill.load334, i64 0
  %.splat336 = shufflevector <8 x i1> %.splatinsert335, <8 x i1> poison, <8 x i32> zeroinitializer
  %452 = select <8 x i1> %.splat336, <8 x float> %native.exp316, <8 x float> zeroinitializer
  %.spill.load337 = load i1, ptr %.spill61, align 1
  %.splatinsert338 = insertelement <8 x i1> poison, i1 %.spill.load337, i64 0
  %.splat339 = shufflevector <8 x i1> %.splatinsert338, <8 x i1> poison, <8 x i32> zeroinitializer
  %453 = select <8 x i1> %.splat339, <8 x float> %native.exp317, <8 x float> zeroinitializer
  %.spill.load340 = load i1, ptr %.spill62, align 1
  %.splatinsert341 = insertelement <8 x i1> poison, i1 %.spill.load340, i64 0
  %.splat342 = shufflevector <8 x i1> %.splatinsert341, <8 x i1> poison, <8 x i32> zeroinitializer
  %454 = select <8 x i1> %.splat342, <8 x float> %native.exp318, <8 x float> zeroinitializer
  %.spill.load343 = load i1, ptr %.spill63, align 1
  %.splatinsert344 = insertelement <8 x i1> poison, i1 %.spill.load343, i64 0
  %.splat345 = shufflevector <8 x i1> %.splatinsert344, <8 x i1> poison, <8 x i32> zeroinitializer
  %455 = select <8 x i1> %.splat345, <8 x float> %native.exp319, <8 x float> zeroinitializer
  %.spill.load346 = load i1, ptr %.spill64, align 1
  %.splatinsert347 = insertelement <8 x i1> poison, i1 %.spill.load346, i64 0
  %.splat348 = shufflevector <8 x i1> %.splatinsert347, <8 x i1> poison, <8 x i32> zeroinitializer
  %456 = select <8 x i1> %.splat348, <8 x float> %native.exp320, <8 x float> zeroinitializer
  %.spill.load349 = load i1, ptr %.spill65, align 1
  %.splatinsert350 = insertelement <8 x i1> poison, i1 %.spill.load349, i64 0
  %.splat351 = shufflevector <8 x i1> %.splatinsert350, <8 x i1> poison, <8 x i32> zeroinitializer
  %457 = select <8 x i1> %.splat351, <8 x float> %native.exp321, <8 x float> zeroinitializer
  %.spill.load352 = load i1, ptr %.spill66, align 1
  %.splatinsert353 = insertelement <8 x i1> poison, i1 %.spill.load352, i64 0
  %.splat354 = shufflevector <8 x i1> %.splatinsert353, <8 x i1> poison, <8 x i32> zeroinitializer
  %458 = select <8 x i1> %.splat354, <8 x float> %native.exp322, <8 x float> zeroinitializer
  %.spill.load355 = load i1, ptr %.spill67, align 1
  %.splatinsert356 = insertelement <8 x i1> poison, i1 %.spill.load355, i64 0
  %.splat357 = shufflevector <8 x i1> %.splatinsert356, <8 x i1> poison, <8 x i32> zeroinitializer
  %459 = select <8 x i1> %.splat357, <8 x float> %native.exp323, <8 x float> zeroinitializer
  %.spill.load358 = load i1, ptr %.spill68, align 1
  %.splatinsert359 = insertelement <8 x i1> poison, i1 %.spill.load358, i64 0
  %.splat360 = shufflevector <8 x i1> %.splatinsert359, <8 x i1> poison, <8 x i32> zeroinitializer
  %460 = select <8 x i1> %.splat360, <8 x float> %native.exp324, <8 x float> zeroinitializer
  %.spill.load361 = load i1, ptr %.spill69, align 1
  %.splatinsert362 = insertelement <8 x i1> poison, i1 %.spill.load361, i64 0
  %.splat363 = shufflevector <8 x i1> %.splatinsert362, <8 x i1> poison, <8 x i32> zeroinitializer
  %461 = select <8 x i1> %.splat363, <8 x float> %native.exp325, <8 x float> zeroinitializer
  %.spill.load364 = load i1, ptr %.spill70, align 1
  %.splatinsert365 = insertelement <8 x i1> poison, i1 %.spill.load364, i64 0
  %.splat366 = shufflevector <8 x i1> %.splatinsert365, <8 x i1> poison, <8 x i32> zeroinitializer
  %462 = select <8 x i1> %.splat366, <8 x float> %native.exp326, <8 x float> zeroinitializer
  %.spill.load367 = load i1, ptr %.spill71, align 1
  %.splatinsert368 = insertelement <8 x i1> poison, i1 %.spill.load367, i64 0
  %.splat369 = shufflevector <8 x i1> %.splatinsert368, <8 x i1> poison, <8 x i32> zeroinitializer
  %463 = select <8 x i1> %.splat369, <8 x float> %native.exp327, <8 x float> zeroinitializer
  %.spill.load370 = load i1, ptr %.spill72, align 1
  %.splatinsert371 = insertelement <8 x i1> poison, i1 %.spill.load370, i64 0
  %.splat372 = shufflevector <8 x i1> %.splatinsert371, <8 x i1> poison, <8 x i32> zeroinitializer
  %464 = select <8 x i1> %.splat372, <8 x float> %native.exp328, <8 x float> zeroinitializer
  %.spill.load373 = load i1, ptr %.spill73, align 1
  %.splatinsert374 = insertelement <8 x i1> poison, i1 %.spill.load373, i64 0
  %.splat375 = shufflevector <8 x i1> %.splatinsert374, <8 x i1> poison, <8 x i32> zeroinitializer
  %465 = select <8 x i1> %.splat375, <8 x float> %native.exp329, <8 x float> zeroinitializer
  %.spill.load376 = load i1, ptr %.spill74, align 1
  %.splatinsert377 = insertelement <8 x i1> poison, i1 %.spill.load376, i64 0
  %.splat378 = shufflevector <8 x i1> %.splatinsert377, <8 x i1> poison, <8 x i32> zeroinitializer
  %466 = select <8 x i1> %.splat378, <8 x float> %native.exp330, <8 x float> zeroinitializer
  %467 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %467, 0
  %470 = select <8 x i1> %80, <8 x ptr> %468, <8 x ptr> %469
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %467, 1
  %473 = select <8 x i1> %80, <8 x i64> %471, <8 x i64> %472
  %474 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %470, 0
  %475 = insertvalue { <8 x ptr>, <8 x i64> } %474, <8 x i64> %473, 1
  store { <8 x ptr>, <8 x i64> } %475, ptr %tile_snapshot.spill96, align 64
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %478 = add <8 x i64> %477, zeroinitializer
  %479 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %476, 0
  %480 = insertvalue { <8 x ptr>, <8 x i64> } %479, <8 x i64> %478, 1
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %480, 0
  %482 = extractvalue { <8 x ptr>, <8 x i64> } %480, 1
  %483 = getelementptr i8, <8 x ptr> %481, <8 x i64> %482
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %451, <8 x ptr> align 1 %483, <8 x i1> %80)
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %486 = add <8 x i64> %485, splat (i64 4)
  %487 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %484, 0
  %488 = insertvalue { <8 x ptr>, <8 x i64> } %487, <8 x i64> %486, 1
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %488, 0
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %488, 1
  %491 = getelementptr i8, <8 x ptr> %489, <8 x i64> %490
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %452, <8 x ptr> align 1 %491, <8 x i1> %80)
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %493 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %494 = add <8 x i64> %493, splat (i64 8)
  %495 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %492, 0
  %496 = insertvalue { <8 x ptr>, <8 x i64> } %495, <8 x i64> %494, 1
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %496, 0
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %496, 1
  %499 = getelementptr i8, <8 x ptr> %497, <8 x i64> %498
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %453, <8 x ptr> align 1 %499, <8 x i1> %80)
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %502 = add <8 x i64> %501, splat (i64 12)
  %503 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %500, 0
  %504 = insertvalue { <8 x ptr>, <8 x i64> } %503, <8 x i64> %502, 1
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %504, 0
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %504, 1
  %507 = getelementptr i8, <8 x ptr> %505, <8 x i64> %506
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %454, <8 x ptr> align 1 %507, <8 x i1> %80)
  %508 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %510 = add <8 x i64> %509, splat (i64 16)
  %511 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %508, 0
  %512 = insertvalue { <8 x ptr>, <8 x i64> } %511, <8 x i64> %510, 1
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %512, 0
  %514 = extractvalue { <8 x ptr>, <8 x i64> } %512, 1
  %515 = getelementptr i8, <8 x ptr> %513, <8 x i64> %514
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %455, <8 x ptr> align 1 %515, <8 x i1> %80)
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %518 = add <8 x i64> %517, splat (i64 20)
  %519 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %516, 0
  %520 = insertvalue { <8 x ptr>, <8 x i64> } %519, <8 x i64> %518, 1
  %521 = extractvalue { <8 x ptr>, <8 x i64> } %520, 0
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %520, 1
  %523 = getelementptr i8, <8 x ptr> %521, <8 x i64> %522
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %456, <8 x ptr> align 1 %523, <8 x i1> %80)
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %526 = add <8 x i64> %525, splat (i64 24)
  %527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %524, 0
  %528 = insertvalue { <8 x ptr>, <8 x i64> } %527, <8 x i64> %526, 1
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %528, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %528, 1
  %531 = getelementptr i8, <8 x ptr> %529, <8 x i64> %530
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %457, <8 x ptr> align 1 %531, <8 x i1> %80)
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %534 = add <8 x i64> %533, splat (i64 28)
  %535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %532, 0
  %536 = insertvalue { <8 x ptr>, <8 x i64> } %535, <8 x i64> %534, 1
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %536, 0
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %536, 1
  %539 = getelementptr i8, <8 x ptr> %537, <8 x i64> %538
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %458, <8 x ptr> align 1 %539, <8 x i1> %80)
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %542 = add <8 x i64> %541, splat (i64 32)
  %543 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %540, 0
  %544 = insertvalue { <8 x ptr>, <8 x i64> } %543, <8 x i64> %542, 1
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %544, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %544, 1
  %547 = getelementptr i8, <8 x ptr> %545, <8 x i64> %546
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %459, <8 x ptr> align 1 %547, <8 x i1> %80)
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %550 = add <8 x i64> %549, splat (i64 36)
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %548, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %552, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = getelementptr i8, <8 x ptr> %553, <8 x i64> %554
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %460, <8 x ptr> align 1 %555, <8 x i1> %80)
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %557 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %558 = add <8 x i64> %557, splat (i64 40)
  %559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %556, 0
  %560 = insertvalue { <8 x ptr>, <8 x i64> } %559, <8 x i64> %558, 1
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %560, 0
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %560, 1
  %563 = getelementptr i8, <8 x ptr> %561, <8 x i64> %562
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %461, <8 x ptr> align 1 %563, <8 x i1> %80)
  %564 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %565 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %566 = add <8 x i64> %565, splat (i64 44)
  %567 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %564, 0
  %568 = insertvalue { <8 x ptr>, <8 x i64> } %567, <8 x i64> %566, 1
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %568, 0
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %568, 1
  %571 = getelementptr i8, <8 x ptr> %569, <8 x i64> %570
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %462, <8 x ptr> align 1 %571, <8 x i1> %80)
  %572 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %574 = add <8 x i64> %573, splat (i64 48)
  %575 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %572, 0
  %576 = insertvalue { <8 x ptr>, <8 x i64> } %575, <8 x i64> %574, 1
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %576, 0
  %578 = extractvalue { <8 x ptr>, <8 x i64> } %576, 1
  %579 = getelementptr i8, <8 x ptr> %577, <8 x i64> %578
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %463, <8 x ptr> align 1 %579, <8 x i1> %80)
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %582 = add <8 x i64> %581, splat (i64 52)
  %583 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %580, 0
  %584 = insertvalue { <8 x ptr>, <8 x i64> } %583, <8 x i64> %582, 1
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %584, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %584, 1
  %587 = getelementptr i8, <8 x ptr> %585, <8 x i64> %586
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %464, <8 x ptr> align 1 %587, <8 x i1> %80)
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %590 = add <8 x i64> %589, splat (i64 56)
  %591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %588, 0
  %592 = insertvalue { <8 x ptr>, <8 x i64> } %591, <8 x i64> %590, 1
  %593 = extractvalue { <8 x ptr>, <8 x i64> } %592, 0
  %594 = extractvalue { <8 x ptr>, <8 x i64> } %592, 1
  %595 = getelementptr i8, <8 x ptr> %593, <8 x i64> %594
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %465, <8 x ptr> align 1 %595, <8 x i1> %80)
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %597 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %598 = add <8 x i64> %597, splat (i64 60)
  %599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %596, 0
  %600 = insertvalue { <8 x ptr>, <8 x i64> } %599, <8 x i64> %598, 1
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %600, 0
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %600, 1
  %603 = getelementptr i8, <8 x ptr> %601, <8 x i64> %602
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %466, <8 x ptr> align 1 %603, <8 x i1> %80)
  %.state379 = load <8 x float>, ptr %.slot48, align 32
  %604 = fmul <8 x float> %.state379, %native.exp
  %605 = load <8 x float>, ptr %.spill97, align 32
  %606 = select <8 x i1> %80, <8 x float> %604, <8 x float> %605
  store <8 x float> %606, ptr %.spill97, align 32
  store i64 0, ptr %.slot98, align 4
  %607 = load <8 x float>, ptr %.slot99, align 32
  %608 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %607
  store <8 x float> %608, ptr %.slot99, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state380 = load i64, ptr %.slot98, align 4
  %609 = icmp slt i64 %.state380, 16
  br i1 %609, label %direct.true381, label %direct.false382

direct.schedule.23:                               ; preds = %direct.true381
  %.state383 = load i64, ptr %.slot98, align 4
  %610 = sdiv i64 %.state383, 1
  %.spill.load384 = load i64, ptr %.spill58, align 4
  %611 = mul i64 %.spill.load384, 1
  %612 = add i64 %611, 0
  %613 = mul i64 %612, 1
  %614 = add i64 %613, 0
  %615 = mul i64 %614, 16
  %616 = add i64 %615, %610
  %tile_snapshot.spill.load385 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load385, 0
  %618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load385, 1
  %.splatinsert386 = insertelement <8 x i64> poison, i64 %616, i64 0
  %.splat387 = shufflevector <8 x i64> %.splatinsert386, <8 x i64> poison, <8 x i32> zeroinitializer
  %619 = mul <8 x i64> %.splat387, splat (i64 4)
  %620 = add <8 x i64> %618, %619
  %621 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %617, 0
  %622 = insertvalue { <8 x ptr>, <8 x i64> } %621, <8 x i64> %620, 1
  %623 = extractvalue { <8 x ptr>, <8 x i64> } %622, 0
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %622, 1
  %625 = getelementptr i8, <8 x ptr> %623, <8 x i64> %624
  %626 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %625, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state388 = load <8 x float>, ptr %.slot99, align 32
  %627 = fadd <8 x float> %.state388, %626
  %.state389 = load i64, ptr %.slot98, align 4
  %628 = add i64 %.state389, 1
  store i64 %628, ptr %.slot98, align 4
  %629 = load <8 x float>, ptr %.slot99, align 32
  %630 = select <8 x i1> %80, <8 x float> %627, <8 x float> %629
  store <8 x float> %630, ptr %.slot99, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false382
  %.spill.load390 = load <8 x float>, ptr %.spill97, align 32
  %.state391 = load <8 x float>, ptr %.slot99, align 32
  %631 = fadd <8 x float> %.spill.load390, %.state391
  %632 = load <8 x float>, ptr %.spill100, align 32
  %633 = select <8 x i1> %80, <8 x float> %631, <8 x float> %632
  store <8 x float> %633, ptr %.spill100, align 32
  %634 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill101, align 64
  %635 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %634, 0
  %637 = select <8 x i1> %80, <8 x ptr> %635, <8 x ptr> %636
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %639 = extractvalue { <8 x ptr>, <8 x i64> } %634, 1
  %640 = select <8 x i1> %80, <8 x i64> %638, <8 x i64> %639
  %641 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %637, 0
  %642 = insertvalue { <8 x ptr>, <8 x i64> } %641, <8 x i64> %640, 1
  store { <8 x ptr>, <8 x i64> } %642, ptr %tile_snapshot.spill101, align 64
  store i64 0, ptr %.slot102, align 4
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state392 = load i64, ptr %.slot102, align 4
  %643 = icmp slt i64 %.state392, 128
  br i1 %643, label %direct.true393, label %direct.false394

direct.schedule.26:                               ; preds = %direct.true393
  %.state395 = load i64, ptr %.slot102, align 4
  %644 = add i64 0, %.state395
  %tile_snapshot.spill.load396 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %645 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load396, 0
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load396, 1
  %.splatinsert397 = insertelement <8 x i64> poison, i64 %644, i64 0
  %.splat398 = shufflevector <8 x i64> %.splatinsert397, <8 x i64> poison, <8 x i32> zeroinitializer
  %647 = mul <8 x i64> %.splat398, splat (i64 32)
  %648 = add <8 x i64> %646, %647
  %649 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %645, 0
  %650 = insertvalue { <8 x ptr>, <8 x i64> } %649, <8 x i64> %648, 1
  %651 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %650, 1
  %653 = extractelement <8 x ptr> %651, i32 0
  %654 = extractelement <8 x i64> %652, i32 0
  %655 = sub i64 %654, 0
  %656 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %657 = select i1 %656, i64 %655, i64 0
  %private.contiguous.address399 = getelementptr i8, ptr %653, i64 %657
  %private.contiguous.load400 = load <8 x float>, ptr %private.contiguous.address399, align 4
  %658 = select <8 x i1> %80, <8 x float> %private.contiguous.load400, <8 x float> zeroinitializer
  %.spill.load401 = load <8 x float>, ptr %.spill95, align 32
  %659 = fmul <8 x float> %658, %.spill.load401
  %tile_snapshot.spill.load402 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill101, align 64
  %660 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load402, 0
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load402, 1
  %.state403 = load i64, ptr %.slot102, align 4
  %.splatinsert404 = insertelement <8 x i64> poison, i64 %.state403, i64 0
  %.splat405 = shufflevector <8 x i64> %.splatinsert404, <8 x i64> poison, <8 x i32> zeroinitializer
  %662 = mul <8 x i64> %.splat405, splat (i64 4)
  %663 = add <8 x i64> %661, %662
  %664 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %660, 0
  %665 = insertvalue { <8 x ptr>, <8 x i64> } %664, <8 x i64> %663, 1
  %666 = extractvalue { <8 x ptr>, <8 x i64> } %665, 0
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %665, 1
  %668 = getelementptr i8, <8 x ptr> %666, <8 x i64> %667
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %659, <8 x ptr> align 1 %668, <8 x i1> %80)
  %.state406 = load i64, ptr %.slot102, align 4
  %669 = add i64 %.state406, 1
  store i64 %669, ptr %.slot102, align 4
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false394
  %670 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %671 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %670, 0
  %673 = select <8 x i1> %80, <8 x ptr> %671, <8 x ptr> %672
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %670, 1
  %676 = select <8 x i1> %80, <8 x i64> %674, <8 x i64> %675
  %677 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %673, 0
  %678 = insertvalue { <8 x ptr>, <8 x i64> } %677, <8 x i64> %676, 1
  store { <8 x ptr>, <8 x i64> } %678, ptr %tile_snapshot.spill103, align 64
  %tile_snapshot.spill.load407 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %tile_snapshot.spill.load408 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %tile_snapshot.spill.load409 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill101, align 64
  %679 = extractelement <8 x i1> %80, i64 0
  br i1 %679, label %mma.active410, label %mma.continue411

direct.schedule.28:                               ; preds = %direct.schedule.29, %mma.continue425
  %.state426 = load i64, ptr %.slot104, align 4
  %680 = icmp slt i64 %.state426, 128
  br i1 %680, label %direct.true427, label %direct.false428

direct.schedule.29:                               ; preds = %direct.true427
  %tile_snapshot.spill.load429 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load429, 0
  %682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load429, 1
  %.state430 = load i64, ptr %.slot104, align 4
  %.splatinsert431 = insertelement <8 x i64> poison, i64 %.state430, i64 0
  %.splat432 = shufflevector <8 x i64> %.splatinsert431, <8 x i64> poison, <8 x i32> zeroinitializer
  %683 = mul <8 x i64> %.splat432, splat (i64 4)
  %684 = add <8 x i64> %682, %683
  %685 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %681, 0
  %686 = insertvalue { <8 x ptr>, <8 x i64> } %685, <8 x i64> %684, 1
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %686, 0
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %686, 1
  %689 = getelementptr i8, <8 x ptr> %687, <8 x i64> %688
  %690 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %689, <8 x i1> %80, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load433 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load433, 0
  %692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load433, 1
  %.state434 = load i64, ptr %.slot104, align 4
  %.splatinsert435 = insertelement <8 x i64> poison, i64 %.state434, i64 0
  %.splat436 = shufflevector <8 x i64> %.splatinsert435, <8 x i64> poison, <8 x i32> zeroinitializer
  %693 = mul <8 x i64> %.splat436, splat (i64 32)
  %694 = add <8 x i64> %692, %693
  %695 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %691, 0
  %696 = insertvalue { <8 x ptr>, <8 x i64> } %695, <8 x i64> %694, 1
  %697 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %698 = extractvalue { <8 x ptr>, <8 x i64> } %696, 1
  %699 = extractelement <8 x ptr> %697, i32 0
  %700 = extractelement <8 x i64> %698, i32 0
  %701 = sub i64 %700, 0
  %702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %703 = select i1 %702, i64 %701, i64 0
  %private.contiguous.address437 = getelementptr i8, ptr %699, i64 %703
  %private.contiguous.preserve438 = load <8 x float>, ptr %private.contiguous.address437, align 4
  %704 = select <8 x i1> %80, <8 x float> %690, <8 x float> %private.contiguous.preserve438
  store <8 x float> %704, ptr %private.contiguous.address437, align 4
  %.state439 = load i64, ptr %.slot104, align 4
  %705 = add i64 %.state439, 1
  store i64 %705, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false428
  store i64 0, ptr %.slot105, align 4
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state440 = load i64, ptr %.slot105, align 4
  %706 = icmp slt i64 %.state440, 128
  br i1 %706, label %direct.true441, label %direct.false442

direct.schedule.32:                               ; preds = %direct.true441
  %tile_snapshot.spill.load443 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %707 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 0
  %708 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 1
  %.state444 = load i64, ptr %.slot105, align 4
  %.splatinsert445 = insertelement <8 x i64> poison, i64 %.state444, i64 0
  %.splat446 = shufflevector <8 x i64> %.splatinsert445, <8 x i64> poison, <8 x i32> zeroinitializer
  %709 = mul <8 x i64> %.splat446, splat (i64 32)
  %710 = add <8 x i64> %708, %709
  %711 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %707, 0
  %712 = insertvalue { <8 x ptr>, <8 x i64> } %711, <8 x i64> %710, 1
  %713 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %714 = extractvalue { <8 x ptr>, <8 x i64> } %712, 1
  %715 = extractelement <8 x ptr> %713, i32 0
  %716 = extractelement <8 x i64> %714, i32 0
  %717 = sub i64 %716, 0
  %718 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %719 = select i1 %718, i64 %717, i64 0
  %private.contiguous.address447 = getelementptr i8, ptr %715, i64 %719
  %private.contiguous.load448 = load <8 x float>, ptr %private.contiguous.address447, align 4
  %720 = select <8 x i1> %80, <8 x float> %private.contiguous.load448, <8 x float> zeroinitializer
  %tile_snapshot.spill.load449 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load449, 0
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load449, 1
  %.state450 = load i64, ptr %.slot105, align 4
  %.splatinsert451 = insertelement <8 x i64> poison, i64 %.state450, i64 0
  %.splat452 = shufflevector <8 x i64> %.splatinsert451, <8 x i64> poison, <8 x i32> zeroinitializer
  %723 = mul <8 x i64> %.splat452, splat (i64 32)
  %724 = add <8 x i64> %722, %723
  %725 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %721, 0
  %726 = insertvalue { <8 x ptr>, <8 x i64> } %725, <8 x i64> %724, 1
  %727 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %726, 1
  %729 = extractelement <8 x ptr> %727, i32 0
  %730 = extractelement <8 x i64> %728, i32 0
  %731 = sub i64 %730, 0
  %732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %733 = select i1 %732, i64 %731, i64 0
  %private.contiguous.address453 = getelementptr i8, ptr %729, i64 %733
  %private.contiguous.preserve454 = load <8 x float>, ptr %private.contiguous.address453, align 4
  %734 = select <8 x i1> %80, <8 x float> %720, <8 x float> %private.contiguous.preserve454
  store <8 x float> %734, ptr %private.contiguous.address453, align 4
  %.state455 = load i64, ptr %.slot105, align 4
  %735 = add i64 %.state455, 1
  store i64 %735, ptr %.slot105, align 4
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false442
  %.state456 = load i64, ptr %.slot46, align 4
  %736 = add i64 %.state456, 1
  %.spill.load457 = load <8 x float>, ptr %.spill94, align 32
  %.spill.load458 = load <8 x float>, ptr %.spill100, align 32
  store i64 %736, ptr %.slot46, align 4
  %737 = load <8 x float>, ptr %.slot47, align 32
  %738 = select <8 x i1> %80, <8 x float> %.spill.load457, <8 x float> %737
  store <8 x float> %738, ptr %.slot47, align 32
  %739 = load <8 x float>, ptr %.slot48, align 32
  %740 = select <8 x i1> %80, <8 x float> %.spill.load458, <8 x float> %739
  store <8 x float> %740, ptr %.slot48, align 32
  br label %direct.schedule.7

direct.schedule.34:                               ; preds = %direct.false140
  store i64 0, ptr %.slot106, align 4
  br label %direct.schedule.35

direct.schedule.35:                               ; preds = %direct.schedule.36, %direct.schedule.34
  %.state459 = load i64, ptr %.slot106, align 4
  %741 = icmp slt i64 %.state459, 128
  br i1 %741, label %direct.true460, label %direct.false461

direct.schedule.36:                               ; preds = %direct.true460
  %.spill.load462 = load i64, ptr %.spill41, align 4
  %742 = add i64 %.spill.load462, 0
  %.spill.load463 = load <8 x i64>, ptr %.spill, align 64
  %743 = add <8 x i64> %.spill.load463, zeroinitializer
  %744 = mul i64 %742, 16
  %.splatinsert464 = insertelement <8 x i64> poison, i64 %744, i64 0
  %.splat465 = shufflevector <8 x i64> %.splatinsert464, <8 x i64> poison, <8 x i32> zeroinitializer
  %745 = add <8 x i64> %.splat465, %743
  %.spill.load466 = load i64, ptr %.spill41, align 4
  %746 = add i64 %.spill.load466, 0
  %747 = mul <8 x i64> %745, splat (i64 1)
  %.splatinsert467 = insertelement <8 x i64> poison, i64 %746, i64 0
  %.splat468 = shufflevector <8 x i64> %.splatinsert467, <8 x i64> poison, <8 x i32> zeroinitializer
  %748 = add <8 x i64> %747, %.splat468
  %.state469 = load i64, ptr %.slot106, align 4
  %749 = add i64 0, %.state469
  %750 = mul <8 x i64> %748, splat (i64 128)
  %.splatinsert470 = insertelement <8 x i64> poison, i64 %749, i64 0
  %.splat471 = shufflevector <8 x i64> %.splatinsert470, <8 x i64> poison, <8 x i32> zeroinitializer
  %751 = add <8 x i64> %750, %.splat471
  %.state472 = load i64, ptr %.slot106, align 4
  %752 = add i64 0, %.state472
  %tile_snapshot.spill.load473 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %753 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load473, 0
  %754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load473, 1
  %.splatinsert474 = insertelement <8 x i64> poison, i64 %752, i64 0
  %.splat475 = shufflevector <8 x i64> %.splatinsert474, <8 x i64> poison, <8 x i32> zeroinitializer
  %755 = mul <8 x i64> %.splat475, splat (i64 32)
  %756 = add <8 x i64> %754, %755
  %757 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %753, 0
  %758 = insertvalue { <8 x ptr>, <8 x i64> } %757, <8 x i64> %756, 1
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %758, 1
  %761 = extractelement <8 x ptr> %759, i32 0
  %762 = extractelement <8 x i64> %760, i32 0
  %763 = sub i64 %762, 0
  %764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %765 = select i1 %764, i64 %763, i64 0
  %private.contiguous.address476 = getelementptr i8, ptr %761, i64 %765
  %private.contiguous.load477 = load <8 x float>, ptr %private.contiguous.address476, align 4
  %766 = select <8 x i1> %80, <8 x float> %private.contiguous.load477, <8 x float> zeroinitializer
  %.state478 = load <8 x float>, ptr %.slot48, align 32
  %767 = fdiv <8 x float> %766, %.state478
  %768 = extractvalue { ptr, i64 } %56, 0
  %769 = mul <8 x i64> %751, splat (i64 4)
  %770 = getelementptr i8, ptr %768, <8 x i64> %769
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %767, <8 x ptr> align 1 %770, <8 x i1> %80)
  %.state479 = load i64, ptr %.slot106, align 4
  %771 = add i64 %.state479, 1
  store i64 %771, ptr %.slot106, align 4
  br label %direct.schedule.35

direct.schedule.37:                               ; preds = %direct.false461
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true131:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false132:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true139:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false140:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.34

direct.true143:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false144:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true156:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false157:                                  ; preds = %direct.schedule.10
  %772 = load <8 x float>, ptr %.slot53, align 32
  %773 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %772
  store <8 x float> %773, ptr %.slot53, align 32
  br label %direct.schedule.12

direct.true166:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false167:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true179:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false180:                                  ; preds = %direct.schedule.15
  %774 = load <8 x float>, ptr %.slot57, align 32
  %775 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %774
  store <8 x float> %775, ptr %.slot57, align 32
  br label %direct.schedule.17

mma.active:                                       ; preds = %direct.schedule.18
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %777 = extractelement <8 x ptr> %776, i64 0
  %778 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %779 = extractelement <8 x i64> %778, i64 0
  %780 = getelementptr i8, ptr %777, i64 %779
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %782 = extractelement <8 x ptr> %781, i64 0
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %784 = extractelement <8 x i64> %783, i64 0
  %785 = getelementptr i8, ptr %782, i64 %784
  %786 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %787 = extractelement <8 x ptr> %786, i64 0
  %788 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %789 = extractelement <8 x i64> %788, i64 0
  %790 = getelementptr i8, ptr %787, i64 %789
  %791 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %792 = extractelement <8 x ptr> %791, i64 0
  %793 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %794 = extractelement <8 x i64> %793, i64 0
  %795 = getelementptr i8, ptr %792, i64 %794
  call void @llm_attention.strided_mma(ptr %780, ptr %785, ptr %790, ptr %795)
  br label %mma.continue

mma.continue:                                     ; preds = %mma.active, %direct.schedule.18
  %796 = extractelement <8 x i1> %80, i64 1
  br i1 %796, label %mma.active190, label %mma.continue191

mma.active190:                                    ; preds = %mma.continue
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %798 = extractelement <8 x ptr> %797, i64 1
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %800 = extractelement <8 x i64> %799, i64 1
  %801 = getelementptr i8, ptr %798, i64 %800
  %802 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %803 = extractelement <8 x ptr> %802, i64 1
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %805 = extractelement <8 x i64> %804, i64 1
  %806 = getelementptr i8, ptr %803, i64 %805
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %808 = extractelement <8 x ptr> %807, i64 1
  %809 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %810 = extractelement <8 x i64> %809, i64 1
  %811 = getelementptr i8, ptr %808, i64 %810
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %813 = extractelement <8 x ptr> %812, i64 1
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %815 = extractelement <8 x i64> %814, i64 1
  %816 = getelementptr i8, ptr %813, i64 %815
  call void @llm_attention.strided_mma(ptr %801, ptr %806, ptr %811, ptr %816)
  br label %mma.continue191

mma.continue191:                                  ; preds = %mma.active190, %mma.continue
  %817 = extractelement <8 x i1> %80, i64 2
  br i1 %817, label %mma.active192, label %mma.continue193

mma.active192:                                    ; preds = %mma.continue191
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %819 = extractelement <8 x ptr> %818, i64 2
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %821 = extractelement <8 x i64> %820, i64 2
  %822 = getelementptr i8, ptr %819, i64 %821
  %823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %824 = extractelement <8 x ptr> %823, i64 2
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %826 = extractelement <8 x i64> %825, i64 2
  %827 = getelementptr i8, ptr %824, i64 %826
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %829 = extractelement <8 x ptr> %828, i64 2
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %831 = extractelement <8 x i64> %830, i64 2
  %832 = getelementptr i8, ptr %829, i64 %831
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %834 = extractelement <8 x ptr> %833, i64 2
  %835 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %836 = extractelement <8 x i64> %835, i64 2
  %837 = getelementptr i8, ptr %834, i64 %836
  call void @llm_attention.strided_mma(ptr %822, ptr %827, ptr %832, ptr %837)
  br label %mma.continue193

mma.continue193:                                  ; preds = %mma.active192, %mma.continue191
  %838 = extractelement <8 x i1> %80, i64 3
  br i1 %838, label %mma.active194, label %mma.continue195

mma.active194:                                    ; preds = %mma.continue193
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %840 = extractelement <8 x ptr> %839, i64 3
  %841 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %842 = extractelement <8 x i64> %841, i64 3
  %843 = getelementptr i8, ptr %840, i64 %842
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %845 = extractelement <8 x ptr> %844, i64 3
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %847 = extractelement <8 x i64> %846, i64 3
  %848 = getelementptr i8, ptr %845, i64 %847
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %850 = extractelement <8 x ptr> %849, i64 3
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %852 = extractelement <8 x i64> %851, i64 3
  %853 = getelementptr i8, ptr %850, i64 %852
  %854 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %855 = extractelement <8 x ptr> %854, i64 3
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %857 = extractelement <8 x i64> %856, i64 3
  %858 = getelementptr i8, ptr %855, i64 %857
  call void @llm_attention.strided_mma(ptr %843, ptr %848, ptr %853, ptr %858)
  br label %mma.continue195

mma.continue195:                                  ; preds = %mma.active194, %mma.continue193
  %859 = extractelement <8 x i1> %80, i64 4
  br i1 %859, label %mma.active196, label %mma.continue197

mma.active196:                                    ; preds = %mma.continue195
  %860 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %861 = extractelement <8 x ptr> %860, i64 4
  %862 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %863 = extractelement <8 x i64> %862, i64 4
  %864 = getelementptr i8, ptr %861, i64 %863
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %866 = extractelement <8 x ptr> %865, i64 4
  %867 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %868 = extractelement <8 x i64> %867, i64 4
  %869 = getelementptr i8, ptr %866, i64 %868
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %871 = extractelement <8 x ptr> %870, i64 4
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %873 = extractelement <8 x i64> %872, i64 4
  %874 = getelementptr i8, ptr %871, i64 %873
  %875 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %876 = extractelement <8 x ptr> %875, i64 4
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %878 = extractelement <8 x i64> %877, i64 4
  %879 = getelementptr i8, ptr %876, i64 %878
  call void @llm_attention.strided_mma(ptr %864, ptr %869, ptr %874, ptr %879)
  br label %mma.continue197

mma.continue197:                                  ; preds = %mma.active196, %mma.continue195
  %880 = extractelement <8 x i1> %80, i64 5
  br i1 %880, label %mma.active198, label %mma.continue199

mma.active198:                                    ; preds = %mma.continue197
  %881 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %882 = extractelement <8 x ptr> %881, i64 5
  %883 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %884 = extractelement <8 x i64> %883, i64 5
  %885 = getelementptr i8, ptr %882, i64 %884
  %886 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %887 = extractelement <8 x ptr> %886, i64 5
  %888 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %889 = extractelement <8 x i64> %888, i64 5
  %890 = getelementptr i8, ptr %887, i64 %889
  %891 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %892 = extractelement <8 x ptr> %891, i64 5
  %893 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %894 = extractelement <8 x i64> %893, i64 5
  %895 = getelementptr i8, ptr %892, i64 %894
  %896 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %897 = extractelement <8 x ptr> %896, i64 5
  %898 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %899 = extractelement <8 x i64> %898, i64 5
  %900 = getelementptr i8, ptr %897, i64 %899
  call void @llm_attention.strided_mma(ptr %885, ptr %890, ptr %895, ptr %900)
  br label %mma.continue199

mma.continue199:                                  ; preds = %mma.active198, %mma.continue197
  %901 = extractelement <8 x i1> %80, i64 6
  br i1 %901, label %mma.active200, label %mma.continue201

mma.active200:                                    ; preds = %mma.continue199
  %902 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %903 = extractelement <8 x ptr> %902, i64 6
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %905 = extractelement <8 x i64> %904, i64 6
  %906 = getelementptr i8, ptr %903, i64 %905
  %907 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %908 = extractelement <8 x ptr> %907, i64 6
  %909 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %910 = extractelement <8 x i64> %909, i64 6
  %911 = getelementptr i8, ptr %908, i64 %910
  %912 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %913 = extractelement <8 x ptr> %912, i64 6
  %914 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %915 = extractelement <8 x i64> %914, i64 6
  %916 = getelementptr i8, ptr %913, i64 %915
  %917 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %918 = extractelement <8 x ptr> %917, i64 6
  %919 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %920 = extractelement <8 x i64> %919, i64 6
  %921 = getelementptr i8, ptr %918, i64 %920
  call void @llm_attention.strided_mma(ptr %906, ptr %911, ptr %916, ptr %921)
  br label %mma.continue201

mma.continue201:                                  ; preds = %mma.active200, %mma.continue199
  %922 = extractelement <8 x i1> %80, i64 7
  br i1 %922, label %mma.active202, label %mma.continue203

mma.active202:                                    ; preds = %mma.continue201
  %923 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %924 = extractelement <8 x ptr> %923, i64 7
  %925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %926 = extractelement <8 x i64> %925, i64 7
  %927 = getelementptr i8, ptr %924, i64 %926
  %928 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %929 = extractelement <8 x ptr> %928, i64 7
  %930 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %931 = extractelement <8 x i64> %930, i64 7
  %932 = getelementptr i8, ptr %929, i64 %931
  %933 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %934 = extractelement <8 x ptr> %933, i64 7
  %935 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %936 = extractelement <8 x i64> %935, i64 7
  %937 = getelementptr i8, ptr %934, i64 %936
  %938 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %939 = extractelement <8 x ptr> %938, i64 7
  %940 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %941 = extractelement <8 x i64> %940, i64 7
  %942 = getelementptr i8, ptr %939, i64 %941
  call void @llm_attention.strided_mma(ptr %927, ptr %932, ptr %937, ptr %942)
  br label %mma.continue203

mma.continue203:                                  ; preds = %mma.active202, %mma.continue201
  %943 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %944 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %945 = add <8 x i64> %944, zeroinitializer
  %946 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %943, 0
  %947 = insertvalue { <8 x ptr>, <8 x i64> } %946, <8 x i64> %945, 1
  %948 = extractvalue { <8 x ptr>, <8 x i64> } %947, 0
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %947, 1
  %950 = getelementptr i8, <8 x ptr> %948, <8 x i64> %949
  %951 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %950, <8 x i1> %80, <8 x float> zeroinitializer)
  %952 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %953 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %954 = add <8 x i64> %953, splat (i64 4)
  %955 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %952, 0
  %956 = insertvalue { <8 x ptr>, <8 x i64> } %955, <8 x i64> %954, 1
  %957 = extractvalue { <8 x ptr>, <8 x i64> } %956, 0
  %958 = extractvalue { <8 x ptr>, <8 x i64> } %956, 1
  %959 = getelementptr i8, <8 x ptr> %957, <8 x i64> %958
  %960 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %959, <8 x i1> %80, <8 x float> zeroinitializer)
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %962 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %963 = add <8 x i64> %962, splat (i64 8)
  %964 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %961, 0
  %965 = insertvalue { <8 x ptr>, <8 x i64> } %964, <8 x i64> %963, 1
  %966 = extractvalue { <8 x ptr>, <8 x i64> } %965, 0
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %965, 1
  %968 = getelementptr i8, <8 x ptr> %966, <8 x i64> %967
  %969 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %968, <8 x i1> %80, <8 x float> zeroinitializer)
  %970 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %971 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %972 = add <8 x i64> %971, splat (i64 12)
  %973 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %970, 0
  %974 = insertvalue { <8 x ptr>, <8 x i64> } %973, <8 x i64> %972, 1
  %975 = extractvalue { <8 x ptr>, <8 x i64> } %974, 0
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %974, 1
  %977 = getelementptr i8, <8 x ptr> %975, <8 x i64> %976
  %978 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %977, <8 x i1> %80, <8 x float> zeroinitializer)
  %979 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %980 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %981 = add <8 x i64> %980, splat (i64 16)
  %982 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %979, 0
  %983 = insertvalue { <8 x ptr>, <8 x i64> } %982, <8 x i64> %981, 1
  %984 = extractvalue { <8 x ptr>, <8 x i64> } %983, 0
  %985 = extractvalue { <8 x ptr>, <8 x i64> } %983, 1
  %986 = getelementptr i8, <8 x ptr> %984, <8 x i64> %985
  %987 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %986, <8 x i1> %80, <8 x float> zeroinitializer)
  %988 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %989 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %990 = add <8 x i64> %989, splat (i64 20)
  %991 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %988, 0
  %992 = insertvalue { <8 x ptr>, <8 x i64> } %991, <8 x i64> %990, 1
  %993 = extractvalue { <8 x ptr>, <8 x i64> } %992, 0
  %994 = extractvalue { <8 x ptr>, <8 x i64> } %992, 1
  %995 = getelementptr i8, <8 x ptr> %993, <8 x i64> %994
  %996 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %995, <8 x i1> %80, <8 x float> zeroinitializer)
  %997 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %999 = add <8 x i64> %998, splat (i64 24)
  %1000 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %997, 0
  %1001 = insertvalue { <8 x ptr>, <8 x i64> } %1000, <8 x i64> %999, 1
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 0
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 1
  %1004 = getelementptr i8, <8 x ptr> %1002, <8 x i64> %1003
  %1005 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1004, <8 x i1> %80, <8 x float> zeroinitializer)
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1007 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1008 = add <8 x i64> %1007, splat (i64 28)
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1006, 0
  %1010 = insertvalue { <8 x ptr>, <8 x i64> } %1009, <8 x i64> %1008, 1
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %1010, 0
  %1012 = extractvalue { <8 x ptr>, <8 x i64> } %1010, 1
  %1013 = getelementptr i8, <8 x ptr> %1011, <8 x i64> %1012
  %1014 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1013, <8 x i1> %80, <8 x float> zeroinitializer)
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1017 = add <8 x i64> %1016, splat (i64 32)
  %1018 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1015, 0
  %1019 = insertvalue { <8 x ptr>, <8 x i64> } %1018, <8 x i64> %1017, 1
  %1020 = extractvalue { <8 x ptr>, <8 x i64> } %1019, 0
  %1021 = extractvalue { <8 x ptr>, <8 x i64> } %1019, 1
  %1022 = getelementptr i8, <8 x ptr> %1020, <8 x i64> %1021
  %1023 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1022, <8 x i1> %80, <8 x float> zeroinitializer)
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1025 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1026 = add <8 x i64> %1025, splat (i64 36)
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1024, 0
  %1028 = insertvalue { <8 x ptr>, <8 x i64> } %1027, <8 x i64> %1026, 1
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1028, 0
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %1028, 1
  %1031 = getelementptr i8, <8 x ptr> %1029, <8 x i64> %1030
  %1032 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1031, <8 x i1> %80, <8 x float> zeroinitializer)
  %1033 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1034 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1035 = add <8 x i64> %1034, splat (i64 40)
  %1036 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1033, 0
  %1037 = insertvalue { <8 x ptr>, <8 x i64> } %1036, <8 x i64> %1035, 1
  %1038 = extractvalue { <8 x ptr>, <8 x i64> } %1037, 0
  %1039 = extractvalue { <8 x ptr>, <8 x i64> } %1037, 1
  %1040 = getelementptr i8, <8 x ptr> %1038, <8 x i64> %1039
  %1041 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1040, <8 x i1> %80, <8 x float> zeroinitializer)
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1043 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1044 = add <8 x i64> %1043, splat (i64 44)
  %1045 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1042, 0
  %1046 = insertvalue { <8 x ptr>, <8 x i64> } %1045, <8 x i64> %1044, 1
  %1047 = extractvalue { <8 x ptr>, <8 x i64> } %1046, 0
  %1048 = extractvalue { <8 x ptr>, <8 x i64> } %1046, 1
  %1049 = getelementptr i8, <8 x ptr> %1047, <8 x i64> %1048
  %1050 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1049, <8 x i1> %80, <8 x float> zeroinitializer)
  %1051 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1052 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1053 = add <8 x i64> %1052, splat (i64 48)
  %1054 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1051, 0
  %1055 = insertvalue { <8 x ptr>, <8 x i64> } %1054, <8 x i64> %1053, 1
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %1055, 0
  %1057 = extractvalue { <8 x ptr>, <8 x i64> } %1055, 1
  %1058 = getelementptr i8, <8 x ptr> %1056, <8 x i64> %1057
  %1059 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1058, <8 x i1> %80, <8 x float> zeroinitializer)
  %1060 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1062 = add <8 x i64> %1061, splat (i64 52)
  %1063 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1060, 0
  %1064 = insertvalue { <8 x ptr>, <8 x i64> } %1063, <8 x i64> %1062, 1
  %1065 = extractvalue { <8 x ptr>, <8 x i64> } %1064, 0
  %1066 = extractvalue { <8 x ptr>, <8 x i64> } %1064, 1
  %1067 = getelementptr i8, <8 x ptr> %1065, <8 x i64> %1066
  %1068 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1067, <8 x i1> %80, <8 x float> zeroinitializer)
  %1069 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1070 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1071 = add <8 x i64> %1070, splat (i64 56)
  %1072 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1069, 0
  %1073 = insertvalue { <8 x ptr>, <8 x i64> } %1072, <8 x i64> %1071, 1
  %1074 = extractvalue { <8 x ptr>, <8 x i64> } %1073, 0
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %1073, 1
  %1076 = getelementptr i8, <8 x ptr> %1074, <8 x i64> %1075
  %1077 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1076, <8 x i1> %80, <8 x float> zeroinitializer)
  %1078 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1079 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1080 = add <8 x i64> %1079, splat (i64 60)
  %1081 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1078, 0
  %1082 = insertvalue { <8 x ptr>, <8 x i64> } %1081, <8 x i64> %1080, 1
  %1083 = extractvalue { <8 x ptr>, <8 x i64> } %1082, 0
  %1084 = extractvalue { <8 x ptr>, <8 x i64> } %1082, 1
  %1085 = getelementptr i8, <8 x ptr> %1083, <8 x i64> %1084
  %1086 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1085, <8 x i1> %80, <8 x float> zeroinitializer)
  %1087 = fmul <8 x float> %951, splat (float 0x3FB6A09E60000000)
  %1088 = fmul <8 x float> %960, splat (float 0x3FB6A09E60000000)
  %1089 = fmul <8 x float> %969, splat (float 0x3FB6A09E60000000)
  %1090 = fmul <8 x float> %978, splat (float 0x3FB6A09E60000000)
  %1091 = fmul <8 x float> %987, splat (float 0x3FB6A09E60000000)
  %1092 = fmul <8 x float> %996, splat (float 0x3FB6A09E60000000)
  %1093 = fmul <8 x float> %1005, splat (float 0x3FB6A09E60000000)
  %1094 = fmul <8 x float> %1014, splat (float 0x3FB6A09E60000000)
  %1095 = fmul <8 x float> %1023, splat (float 0x3FB6A09E60000000)
  %1096 = fmul <8 x float> %1032, splat (float 0x3FB6A09E60000000)
  %1097 = fmul <8 x float> %1041, splat (float 0x3FB6A09E60000000)
  %1098 = fmul <8 x float> %1050, splat (float 0x3FB6A09E60000000)
  %1099 = fmul <8 x float> %1059, splat (float 0x3FB6A09E60000000)
  %1100 = fmul <8 x float> %1068, splat (float 0x3FB6A09E60000000)
  %1101 = fmul <8 x float> %1077, splat (float 0x3FB6A09E60000000)
  %1102 = fmul <8 x float> %1086, splat (float 0x3FB6A09E60000000)
  %.spill.load204 = load i64, ptr %.spill49, align 4
  %1103 = add i64 0, %.spill.load204
  %.spill.load205 = load i64, ptr %.spill49, align 4
  %1104 = add i64 1, %.spill.load205
  %.spill.load206 = load i64, ptr %.spill49, align 4
  %1105 = add i64 2, %.spill.load206
  %.spill.load207 = load i64, ptr %.spill49, align 4
  %1106 = add i64 3, %.spill.load207
  %.spill.load208 = load i64, ptr %.spill49, align 4
  %1107 = add i64 4, %.spill.load208
  %.spill.load209 = load i64, ptr %.spill49, align 4
  %1108 = add i64 5, %.spill.load209
  %.spill.load210 = load i64, ptr %.spill49, align 4
  %1109 = add i64 6, %.spill.load210
  %.spill.load211 = load i64, ptr %.spill49, align 4
  %1110 = add i64 7, %.spill.load211
  %.spill.load212 = load i64, ptr %.spill49, align 4
  %1111 = add i64 8, %.spill.load212
  %.spill.load213 = load i64, ptr %.spill49, align 4
  %1112 = add i64 9, %.spill.load213
  %.spill.load214 = load i64, ptr %.spill49, align 4
  %1113 = add i64 10, %.spill.load214
  %.spill.load215 = load i64, ptr %.spill49, align 4
  %1114 = add i64 11, %.spill.load215
  %.spill.load216 = load i64, ptr %.spill49, align 4
  %1115 = add i64 12, %.spill.load216
  %.spill.load217 = load i64, ptr %.spill49, align 4
  %1116 = add i64 13, %.spill.load217
  %.spill.load218 = load i64, ptr %.spill49, align 4
  %1117 = add i64 14, %.spill.load218
  %.spill.load219 = load i64, ptr %.spill49, align 4
  %1118 = add i64 15, %.spill.load219
  %1119 = icmp slt i64 %1103, 8193
  %1120 = icmp slt i64 %1104, 8193
  %1121 = icmp slt i64 %1105, 8193
  %1122 = icmp slt i64 %1106, 8193
  %1123 = icmp slt i64 %1107, 8193
  %1124 = icmp slt i64 %1108, 8193
  %1125 = icmp slt i64 %1109, 8193
  %1126 = icmp slt i64 %1110, 8193
  %1127 = icmp slt i64 %1111, 8193
  %1128 = icmp slt i64 %1112, 8193
  %1129 = icmp slt i64 %1113, 8193
  %1130 = icmp slt i64 %1114, 8193
  %1131 = icmp slt i64 %1115, 8193
  %1132 = icmp slt i64 %1116, 8193
  %1133 = icmp slt i64 %1117, 8193
  %1134 = icmp slt i64 %1118, 8193
  %.spill.load220 = load i64, ptr %.spill41, align 4
  %1135 = add i64 0, %.spill.load220
  store i64 %1135, ptr %.spill58, align 4
  %1136 = add i64 %1135, 8193
  %1137 = sub i64 %1136, 1
  %1138 = icmp sle i64 %1103, %1137
  %1139 = icmp sle i64 %1104, %1137
  %1140 = icmp sle i64 %1105, %1137
  %1141 = icmp sle i64 %1106, %1137
  %1142 = icmp sle i64 %1107, %1137
  %1143 = icmp sle i64 %1108, %1137
  %1144 = icmp sle i64 %1109, %1137
  %1145 = icmp sle i64 %1110, %1137
  %1146 = icmp sle i64 %1111, %1137
  %1147 = icmp sle i64 %1112, %1137
  %1148 = icmp sle i64 %1113, %1137
  %1149 = icmp sle i64 %1114, %1137
  %1150 = icmp sle i64 %1115, %1137
  %1151 = icmp sle i64 %1116, %1137
  %1152 = icmp sle i64 %1117, %1137
  %1153 = icmp sle i64 %1118, %1137
  %1154 = and i1 %1119, %1138
  store i1 %1154, ptr %.spill59, align 1
  %1155 = and i1 %1120, %1139
  store i1 %1155, ptr %.spill60, align 1
  %1156 = and i1 %1121, %1140
  store i1 %1156, ptr %.spill61, align 1
  %1157 = and i1 %1122, %1141
  store i1 %1157, ptr %.spill62, align 1
  %1158 = and i1 %1123, %1142
  store i1 %1158, ptr %.spill63, align 1
  %1159 = and i1 %1124, %1143
  store i1 %1159, ptr %.spill64, align 1
  %1160 = and i1 %1125, %1144
  store i1 %1160, ptr %.spill65, align 1
  %1161 = and i1 %1126, %1145
  store i1 %1161, ptr %.spill66, align 1
  %1162 = and i1 %1127, %1146
  store i1 %1162, ptr %.spill67, align 1
  %1163 = and i1 %1128, %1147
  store i1 %1163, ptr %.spill68, align 1
  %1164 = and i1 %1129, %1148
  store i1 %1164, ptr %.spill69, align 1
  %1165 = and i1 %1130, %1149
  store i1 %1165, ptr %.spill70, align 1
  %1166 = and i1 %1131, %1150
  store i1 %1166, ptr %.spill71, align 1
  %1167 = and i1 %1132, %1151
  store i1 %1167, ptr %.spill72, align 1
  %1168 = and i1 %1133, %1152
  store i1 %1168, ptr %.spill73, align 1
  %1169 = and i1 %1134, %1153
  store i1 %1169, ptr %.spill74, align 1
  %.splatinsert221 = insertelement <8 x i1> poison, i1 %1154, i64 0
  %.splat222 = shufflevector <8 x i1> %.splatinsert221, <8 x i1> poison, <8 x i32> zeroinitializer
  %1170 = select <8 x i1> %.splat222, <8 x float> %1087, <8 x float> splat (float 0xC6293E5940000000)
  %1171 = load <8 x float>, ptr %.spill75, align 32
  %1172 = select <8 x i1> %80, <8 x float> %1170, <8 x float> %1171
  store <8 x float> %1172, ptr %.spill75, align 32
  %.splatinsert223 = insertelement <8 x i1> poison, i1 %1155, i64 0
  %.splat224 = shufflevector <8 x i1> %.splatinsert223, <8 x i1> poison, <8 x i32> zeroinitializer
  %1173 = select <8 x i1> %.splat224, <8 x float> %1088, <8 x float> splat (float 0xC6293E5940000000)
  %1174 = load <8 x float>, ptr %.spill76, align 32
  %1175 = select <8 x i1> %80, <8 x float> %1173, <8 x float> %1174
  store <8 x float> %1175, ptr %.spill76, align 32
  %.splatinsert225 = insertelement <8 x i1> poison, i1 %1156, i64 0
  %.splat226 = shufflevector <8 x i1> %.splatinsert225, <8 x i1> poison, <8 x i32> zeroinitializer
  %1176 = select <8 x i1> %.splat226, <8 x float> %1089, <8 x float> splat (float 0xC6293E5940000000)
  %1177 = load <8 x float>, ptr %.spill77, align 32
  %1178 = select <8 x i1> %80, <8 x float> %1176, <8 x float> %1177
  store <8 x float> %1178, ptr %.spill77, align 32
  %.splatinsert227 = insertelement <8 x i1> poison, i1 %1157, i64 0
  %.splat228 = shufflevector <8 x i1> %.splatinsert227, <8 x i1> poison, <8 x i32> zeroinitializer
  %1179 = select <8 x i1> %.splat228, <8 x float> %1090, <8 x float> splat (float 0xC6293E5940000000)
  %1180 = load <8 x float>, ptr %.spill78, align 32
  %1181 = select <8 x i1> %80, <8 x float> %1179, <8 x float> %1180
  store <8 x float> %1181, ptr %.spill78, align 32
  %.splatinsert229 = insertelement <8 x i1> poison, i1 %1158, i64 0
  %.splat230 = shufflevector <8 x i1> %.splatinsert229, <8 x i1> poison, <8 x i32> zeroinitializer
  %1182 = select <8 x i1> %.splat230, <8 x float> %1091, <8 x float> splat (float 0xC6293E5940000000)
  %1183 = load <8 x float>, ptr %.spill79, align 32
  %1184 = select <8 x i1> %80, <8 x float> %1182, <8 x float> %1183
  store <8 x float> %1184, ptr %.spill79, align 32
  %.splatinsert231 = insertelement <8 x i1> poison, i1 %1159, i64 0
  %.splat232 = shufflevector <8 x i1> %.splatinsert231, <8 x i1> poison, <8 x i32> zeroinitializer
  %1185 = select <8 x i1> %.splat232, <8 x float> %1092, <8 x float> splat (float 0xC6293E5940000000)
  %1186 = load <8 x float>, ptr %.spill80, align 32
  %1187 = select <8 x i1> %80, <8 x float> %1185, <8 x float> %1186
  store <8 x float> %1187, ptr %.spill80, align 32
  %.splatinsert233 = insertelement <8 x i1> poison, i1 %1160, i64 0
  %.splat234 = shufflevector <8 x i1> %.splatinsert233, <8 x i1> poison, <8 x i32> zeroinitializer
  %1188 = select <8 x i1> %.splat234, <8 x float> %1093, <8 x float> splat (float 0xC6293E5940000000)
  %1189 = load <8 x float>, ptr %.spill81, align 32
  %1190 = select <8 x i1> %80, <8 x float> %1188, <8 x float> %1189
  store <8 x float> %1190, ptr %.spill81, align 32
  %.splatinsert235 = insertelement <8 x i1> poison, i1 %1161, i64 0
  %.splat236 = shufflevector <8 x i1> %.splatinsert235, <8 x i1> poison, <8 x i32> zeroinitializer
  %1191 = select <8 x i1> %.splat236, <8 x float> %1094, <8 x float> splat (float 0xC6293E5940000000)
  %1192 = load <8 x float>, ptr %.spill82, align 32
  %1193 = select <8 x i1> %80, <8 x float> %1191, <8 x float> %1192
  store <8 x float> %1193, ptr %.spill82, align 32
  %.splatinsert237 = insertelement <8 x i1> poison, i1 %1162, i64 0
  %.splat238 = shufflevector <8 x i1> %.splatinsert237, <8 x i1> poison, <8 x i32> zeroinitializer
  %1194 = select <8 x i1> %.splat238, <8 x float> %1095, <8 x float> splat (float 0xC6293E5940000000)
  %1195 = load <8 x float>, ptr %.spill83, align 32
  %1196 = select <8 x i1> %80, <8 x float> %1194, <8 x float> %1195
  store <8 x float> %1196, ptr %.spill83, align 32
  %.splatinsert239 = insertelement <8 x i1> poison, i1 %1163, i64 0
  %.splat240 = shufflevector <8 x i1> %.splatinsert239, <8 x i1> poison, <8 x i32> zeroinitializer
  %1197 = select <8 x i1> %.splat240, <8 x float> %1096, <8 x float> splat (float 0xC6293E5940000000)
  %1198 = load <8 x float>, ptr %.spill84, align 32
  %1199 = select <8 x i1> %80, <8 x float> %1197, <8 x float> %1198
  store <8 x float> %1199, ptr %.spill84, align 32
  %.splatinsert241 = insertelement <8 x i1> poison, i1 %1164, i64 0
  %.splat242 = shufflevector <8 x i1> %.splatinsert241, <8 x i1> poison, <8 x i32> zeroinitializer
  %1200 = select <8 x i1> %.splat242, <8 x float> %1097, <8 x float> splat (float 0xC6293E5940000000)
  %1201 = load <8 x float>, ptr %.spill85, align 32
  %1202 = select <8 x i1> %80, <8 x float> %1200, <8 x float> %1201
  store <8 x float> %1202, ptr %.spill85, align 32
  %.splatinsert243 = insertelement <8 x i1> poison, i1 %1165, i64 0
  %.splat244 = shufflevector <8 x i1> %.splatinsert243, <8 x i1> poison, <8 x i32> zeroinitializer
  %1203 = select <8 x i1> %.splat244, <8 x float> %1098, <8 x float> splat (float 0xC6293E5940000000)
  %1204 = load <8 x float>, ptr %.spill86, align 32
  %1205 = select <8 x i1> %80, <8 x float> %1203, <8 x float> %1204
  store <8 x float> %1205, ptr %.spill86, align 32
  %.splatinsert245 = insertelement <8 x i1> poison, i1 %1166, i64 0
  %.splat246 = shufflevector <8 x i1> %.splatinsert245, <8 x i1> poison, <8 x i32> zeroinitializer
  %1206 = select <8 x i1> %.splat246, <8 x float> %1099, <8 x float> splat (float 0xC6293E5940000000)
  %1207 = load <8 x float>, ptr %.spill87, align 32
  %1208 = select <8 x i1> %80, <8 x float> %1206, <8 x float> %1207
  store <8 x float> %1208, ptr %.spill87, align 32
  %.splatinsert247 = insertelement <8 x i1> poison, i1 %1167, i64 0
  %.splat248 = shufflevector <8 x i1> %.splatinsert247, <8 x i1> poison, <8 x i32> zeroinitializer
  %1209 = select <8 x i1> %.splat248, <8 x float> %1100, <8 x float> splat (float 0xC6293E5940000000)
  %1210 = load <8 x float>, ptr %.spill88, align 32
  %1211 = select <8 x i1> %80, <8 x float> %1209, <8 x float> %1210
  store <8 x float> %1211, ptr %.spill88, align 32
  %.splatinsert249 = insertelement <8 x i1> poison, i1 %1168, i64 0
  %.splat250 = shufflevector <8 x i1> %.splatinsert249, <8 x i1> poison, <8 x i32> zeroinitializer
  %1212 = select <8 x i1> %.splat250, <8 x float> %1101, <8 x float> splat (float 0xC6293E5940000000)
  %1213 = load <8 x float>, ptr %.spill89, align 32
  %1214 = select <8 x i1> %80, <8 x float> %1212, <8 x float> %1213
  store <8 x float> %1214, ptr %.spill89, align 32
  %.splatinsert251 = insertelement <8 x i1> poison, i1 %1169, i64 0
  %.splat252 = shufflevector <8 x i1> %.splatinsert251, <8 x i1> poison, <8 x i32> zeroinitializer
  %1215 = select <8 x i1> %.splat252, <8 x float> %1102, <8 x float> splat (float 0xC6293E5940000000)
  %1216 = load <8 x float>, ptr %.spill90, align 32
  %1217 = select <8 x i1> %80, <8 x float> %1215, <8 x float> %1216
  store <8 x float> %1217, ptr %.spill90, align 32
  %1218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill91, align 64
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1220 = extractvalue { <8 x ptr>, <8 x i64> } %1218, 0
  %1221 = select <8 x i1> %80, <8 x ptr> %1219, <8 x ptr> %1220
  %1222 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %1218, 1
  %1224 = select <8 x i1> %80, <8 x i64> %1222, <8 x i64> %1223
  %1225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1221, 0
  %1226 = insertvalue { <8 x ptr>, <8 x i64> } %1225, <8 x i64> %1224, 1
  store { <8 x ptr>, <8 x i64> } %1226, ptr %tile_snapshot.spill91, align 64
  %1227 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1229 = add <8 x i64> %1228, zeroinitializer
  %1230 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1227, 0
  %1231 = insertvalue { <8 x ptr>, <8 x i64> } %1230, <8 x i64> %1229, 1
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1233 = extractvalue { <8 x ptr>, <8 x i64> } %1231, 1
  %1234 = extractelement <8 x ptr> %1232, i32 0
  %1235 = extractelement <8 x i64> %1233, i32 0
  %1236 = sub i64 %1235, 0
  %1237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1238 = select i1 %1237, i64 %1236, i64 0
  %private.contiguous.address253 = getelementptr i8, ptr %1234, i64 %1238
  %private.contiguous.preserve254 = load <8 x float>, ptr %private.contiguous.address253, align 4
  %1239 = select <8 x i1> %80, <8 x float> %1170, <8 x float> %private.contiguous.preserve254
  store <8 x float> %1239, ptr %private.contiguous.address253, align 4
  %1240 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1241 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1242 = add <8 x i64> %1241, splat (i64 32)
  %1243 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1240, 0
  %1244 = insertvalue { <8 x ptr>, <8 x i64> } %1243, <8 x i64> %1242, 1
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1246 = extractvalue { <8 x ptr>, <8 x i64> } %1244, 1
  %1247 = extractelement <8 x ptr> %1245, i32 0
  %1248 = extractelement <8 x i64> %1246, i32 0
  %1249 = sub i64 %1248, 0
  %1250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1251 = select i1 %1250, i64 %1249, i64 0
  %private.contiguous.address255 = getelementptr i8, ptr %1247, i64 %1251
  %private.contiguous.preserve256 = load <8 x float>, ptr %private.contiguous.address255, align 4
  %1252 = select <8 x i1> %80, <8 x float> %1173, <8 x float> %private.contiguous.preserve256
  store <8 x float> %1252, ptr %private.contiguous.address255, align 4
  %1253 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1254 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1255 = add <8 x i64> %1254, splat (i64 64)
  %1256 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1253, 0
  %1257 = insertvalue { <8 x ptr>, <8 x i64> } %1256, <8 x i64> %1255, 1
  %1258 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1259 = extractvalue { <8 x ptr>, <8 x i64> } %1257, 1
  %1260 = extractelement <8 x ptr> %1258, i32 0
  %1261 = extractelement <8 x i64> %1259, i32 0
  %1262 = sub i64 %1261, 0
  %1263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1264 = select i1 %1263, i64 %1262, i64 0
  %private.contiguous.address257 = getelementptr i8, ptr %1260, i64 %1264
  %private.contiguous.preserve258 = load <8 x float>, ptr %private.contiguous.address257, align 4
  %1265 = select <8 x i1> %80, <8 x float> %1176, <8 x float> %private.contiguous.preserve258
  store <8 x float> %1265, ptr %private.contiguous.address257, align 4
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1268 = add <8 x i64> %1267, splat (i64 96)
  %1269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1266, 0
  %1270 = insertvalue { <8 x ptr>, <8 x i64> } %1269, <8 x i64> %1268, 1
  %1271 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1272 = extractvalue { <8 x ptr>, <8 x i64> } %1270, 1
  %1273 = extractelement <8 x ptr> %1271, i32 0
  %1274 = extractelement <8 x i64> %1272, i32 0
  %1275 = sub i64 %1274, 0
  %1276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1277 = select i1 %1276, i64 %1275, i64 0
  %private.contiguous.address259 = getelementptr i8, ptr %1273, i64 %1277
  %private.contiguous.preserve260 = load <8 x float>, ptr %private.contiguous.address259, align 4
  %1278 = select <8 x i1> %80, <8 x float> %1179, <8 x float> %private.contiguous.preserve260
  store <8 x float> %1278, ptr %private.contiguous.address259, align 4
  %1279 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1280 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1281 = add <8 x i64> %1280, splat (i64 128)
  %1282 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1279, 0
  %1283 = insertvalue { <8 x ptr>, <8 x i64> } %1282, <8 x i64> %1281, 1
  %1284 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1285 = extractvalue { <8 x ptr>, <8 x i64> } %1283, 1
  %1286 = extractelement <8 x ptr> %1284, i32 0
  %1287 = extractelement <8 x i64> %1285, i32 0
  %1288 = sub i64 %1287, 0
  %1289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1290 = select i1 %1289, i64 %1288, i64 0
  %private.contiguous.address261 = getelementptr i8, ptr %1286, i64 %1290
  %private.contiguous.preserve262 = load <8 x float>, ptr %private.contiguous.address261, align 4
  %1291 = select <8 x i1> %80, <8 x float> %1182, <8 x float> %private.contiguous.preserve262
  store <8 x float> %1291, ptr %private.contiguous.address261, align 4
  %1292 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1293 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1294 = add <8 x i64> %1293, splat (i64 160)
  %1295 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1292, 0
  %1296 = insertvalue { <8 x ptr>, <8 x i64> } %1295, <8 x i64> %1294, 1
  %1297 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1298 = extractvalue { <8 x ptr>, <8 x i64> } %1296, 1
  %1299 = extractelement <8 x ptr> %1297, i32 0
  %1300 = extractelement <8 x i64> %1298, i32 0
  %1301 = sub i64 %1300, 0
  %1302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1303 = select i1 %1302, i64 %1301, i64 0
  %private.contiguous.address263 = getelementptr i8, ptr %1299, i64 %1303
  %private.contiguous.preserve264 = load <8 x float>, ptr %private.contiguous.address263, align 4
  %1304 = select <8 x i1> %80, <8 x float> %1185, <8 x float> %private.contiguous.preserve264
  store <8 x float> %1304, ptr %private.contiguous.address263, align 4
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1307 = add <8 x i64> %1306, splat (i64 192)
  %1308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1305, 0
  %1309 = insertvalue { <8 x ptr>, <8 x i64> } %1308, <8 x i64> %1307, 1
  %1310 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %1309, 1
  %1312 = extractelement <8 x ptr> %1310, i32 0
  %1313 = extractelement <8 x i64> %1311, i32 0
  %1314 = sub i64 %1313, 0
  %1315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1316 = select i1 %1315, i64 %1314, i64 0
  %private.contiguous.address265 = getelementptr i8, ptr %1312, i64 %1316
  %private.contiguous.preserve266 = load <8 x float>, ptr %private.contiguous.address265, align 4
  %1317 = select <8 x i1> %80, <8 x float> %1188, <8 x float> %private.contiguous.preserve266
  store <8 x float> %1317, ptr %private.contiguous.address265, align 4
  %1318 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1319 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1320 = add <8 x i64> %1319, splat (i64 224)
  %1321 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1318, 0
  %1322 = insertvalue { <8 x ptr>, <8 x i64> } %1321, <8 x i64> %1320, 1
  %1323 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %1322, 1
  %1325 = extractelement <8 x ptr> %1323, i32 0
  %1326 = extractelement <8 x i64> %1324, i32 0
  %1327 = sub i64 %1326, 0
  %1328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1329 = select i1 %1328, i64 %1327, i64 0
  %private.contiguous.address267 = getelementptr i8, ptr %1325, i64 %1329
  %private.contiguous.preserve268 = load <8 x float>, ptr %private.contiguous.address267, align 4
  %1330 = select <8 x i1> %80, <8 x float> %1191, <8 x float> %private.contiguous.preserve268
  store <8 x float> %1330, ptr %private.contiguous.address267, align 4
  %1331 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1332 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1333 = add <8 x i64> %1332, splat (i64 256)
  %1334 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1331, 0
  %1335 = insertvalue { <8 x ptr>, <8 x i64> } %1334, <8 x i64> %1333, 1
  %1336 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %1335, 1
  %1338 = extractelement <8 x ptr> %1336, i32 0
  %1339 = extractelement <8 x i64> %1337, i32 0
  %1340 = sub i64 %1339, 0
  %1341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1342 = select i1 %1341, i64 %1340, i64 0
  %private.contiguous.address269 = getelementptr i8, ptr %1338, i64 %1342
  %private.contiguous.preserve270 = load <8 x float>, ptr %private.contiguous.address269, align 4
  %1343 = select <8 x i1> %80, <8 x float> %1194, <8 x float> %private.contiguous.preserve270
  store <8 x float> %1343, ptr %private.contiguous.address269, align 4
  %1344 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1345 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1346 = add <8 x i64> %1345, splat (i64 288)
  %1347 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1344, 0
  %1348 = insertvalue { <8 x ptr>, <8 x i64> } %1347, <8 x i64> %1346, 1
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %1348, 1
  %1351 = extractelement <8 x ptr> %1349, i32 0
  %1352 = extractelement <8 x i64> %1350, i32 0
  %1353 = sub i64 %1352, 0
  %1354 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1355 = select i1 %1354, i64 %1353, i64 0
  %private.contiguous.address271 = getelementptr i8, ptr %1351, i64 %1355
  %private.contiguous.preserve272 = load <8 x float>, ptr %private.contiguous.address271, align 4
  %1356 = select <8 x i1> %80, <8 x float> %1197, <8 x float> %private.contiguous.preserve272
  store <8 x float> %1356, ptr %private.contiguous.address271, align 4
  %1357 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1358 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1359 = add <8 x i64> %1358, splat (i64 320)
  %1360 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1357, 0
  %1361 = insertvalue { <8 x ptr>, <8 x i64> } %1360, <8 x i64> %1359, 1
  %1362 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %1361, 1
  %1364 = extractelement <8 x ptr> %1362, i32 0
  %1365 = extractelement <8 x i64> %1363, i32 0
  %1366 = sub i64 %1365, 0
  %1367 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1368 = select i1 %1367, i64 %1366, i64 0
  %private.contiguous.address273 = getelementptr i8, ptr %1364, i64 %1368
  %private.contiguous.preserve274 = load <8 x float>, ptr %private.contiguous.address273, align 4
  %1369 = select <8 x i1> %80, <8 x float> %1200, <8 x float> %private.contiguous.preserve274
  store <8 x float> %1369, ptr %private.contiguous.address273, align 4
  %1370 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1371 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1372 = add <8 x i64> %1371, splat (i64 352)
  %1373 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1370, 0
  %1374 = insertvalue { <8 x ptr>, <8 x i64> } %1373, <8 x i64> %1372, 1
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %1374, 1
  %1377 = extractelement <8 x ptr> %1375, i32 0
  %1378 = extractelement <8 x i64> %1376, i32 0
  %1379 = sub i64 %1378, 0
  %1380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1381 = select i1 %1380, i64 %1379, i64 0
  %private.contiguous.address275 = getelementptr i8, ptr %1377, i64 %1381
  %private.contiguous.preserve276 = load <8 x float>, ptr %private.contiguous.address275, align 4
  %1382 = select <8 x i1> %80, <8 x float> %1203, <8 x float> %private.contiguous.preserve276
  store <8 x float> %1382, ptr %private.contiguous.address275, align 4
  %1383 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1384 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1385 = add <8 x i64> %1384, splat (i64 384)
  %1386 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1383, 0
  %1387 = insertvalue { <8 x ptr>, <8 x i64> } %1386, <8 x i64> %1385, 1
  %1388 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %1387, 1
  %1390 = extractelement <8 x ptr> %1388, i32 0
  %1391 = extractelement <8 x i64> %1389, i32 0
  %1392 = sub i64 %1391, 0
  %1393 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1394 = select i1 %1393, i64 %1392, i64 0
  %private.contiguous.address277 = getelementptr i8, ptr %1390, i64 %1394
  %private.contiguous.preserve278 = load <8 x float>, ptr %private.contiguous.address277, align 4
  %1395 = select <8 x i1> %80, <8 x float> %1206, <8 x float> %private.contiguous.preserve278
  store <8 x float> %1395, ptr %private.contiguous.address277, align 4
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1397 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1398 = add <8 x i64> %1397, splat (i64 416)
  %1399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1396, 0
  %1400 = insertvalue { <8 x ptr>, <8 x i64> } %1399, <8 x i64> %1398, 1
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %1400, 1
  %1403 = extractelement <8 x ptr> %1401, i32 0
  %1404 = extractelement <8 x i64> %1402, i32 0
  %1405 = sub i64 %1404, 0
  %1406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1407 = select i1 %1406, i64 %1405, i64 0
  %private.contiguous.address279 = getelementptr i8, ptr %1403, i64 %1407
  %private.contiguous.preserve280 = load <8 x float>, ptr %private.contiguous.address279, align 4
  %1408 = select <8 x i1> %80, <8 x float> %1209, <8 x float> %private.contiguous.preserve280
  store <8 x float> %1408, ptr %private.contiguous.address279, align 4
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1411 = add <8 x i64> %1410, splat (i64 448)
  %1412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1409, 0
  %1413 = insertvalue { <8 x ptr>, <8 x i64> } %1412, <8 x i64> %1411, 1
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %1413, 1
  %1416 = extractelement <8 x ptr> %1414, i32 0
  %1417 = extractelement <8 x i64> %1415, i32 0
  %1418 = sub i64 %1417, 0
  %1419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1420 = select i1 %1419, i64 %1418, i64 0
  %private.contiguous.address281 = getelementptr i8, ptr %1416, i64 %1420
  %private.contiguous.preserve282 = load <8 x float>, ptr %private.contiguous.address281, align 4
  %1421 = select <8 x i1> %80, <8 x float> %1212, <8 x float> %private.contiguous.preserve282
  store <8 x float> %1421, ptr %private.contiguous.address281, align 4
  %1422 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1423 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1424 = add <8 x i64> %1423, splat (i64 480)
  %1425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1422, 0
  %1426 = insertvalue { <8 x ptr>, <8 x i64> } %1425, <8 x i64> %1424, 1
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %1426, 1
  %1429 = extractelement <8 x ptr> %1427, i32 0
  %1430 = extractelement <8 x i64> %1428, i32 0
  %1431 = sub i64 %1430, 0
  %1432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1433 = select i1 %1432, i64 %1431, i64 0
  %private.contiguous.address283 = getelementptr i8, ptr %1429, i64 %1433
  %private.contiguous.preserve284 = load <8 x float>, ptr %private.contiguous.address283, align 4
  %1434 = select <8 x i1> %80, <8 x float> %1215, <8 x float> %private.contiguous.preserve284
  store <8 x float> %1434, ptr %private.contiguous.address283, align 4
  store i64 0, ptr %.slot92, align 4
  %1435 = load <8 x float>, ptr %.slot93, align 32
  %1436 = select <8 x i1> %80, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1435
  store <8 x float> %1436, ptr %.slot93, align 32
  br label %direct.schedule.19

direct.true286:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false287:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true381:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false382:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true393:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false394:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

mma.active410:                                    ; preds = %direct.schedule.27
  %1437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1438 = extractelement <8 x ptr> %1437, i64 0
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1440 = extractelement <8 x i64> %1439, i64 0
  %1441 = getelementptr i8, ptr %1438, i64 %1440
  %1442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1443 = extractelement <8 x ptr> %1442, i64 0
  %1444 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1445 = extractelement <8 x i64> %1444, i64 0
  %1446 = getelementptr i8, ptr %1443, i64 %1445
  %1447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1448 = extractelement <8 x ptr> %1447, i64 0
  %1449 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1450 = extractelement <8 x i64> %1449, i64 0
  %1451 = getelementptr i8, ptr %1448, i64 %1450
  %1452 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1453 = extractelement <8 x ptr> %1452, i64 0
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1455 = extractelement <8 x i64> %1454, i64 0
  %1456 = getelementptr i8, ptr %1453, i64 %1455
  call void @llm_attention.strided_mma.1(ptr %1441, ptr %1446, ptr %1451, ptr %1456)
  br label %mma.continue411

mma.continue411:                                  ; preds = %mma.active410, %direct.schedule.27
  %1457 = extractelement <8 x i1> %80, i64 1
  br i1 %1457, label %mma.active412, label %mma.continue413

mma.active412:                                    ; preds = %mma.continue411
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1459 = extractelement <8 x ptr> %1458, i64 1
  %1460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1461 = extractelement <8 x i64> %1460, i64 1
  %1462 = getelementptr i8, ptr %1459, i64 %1461
  %1463 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1464 = extractelement <8 x ptr> %1463, i64 1
  %1465 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1466 = extractelement <8 x i64> %1465, i64 1
  %1467 = getelementptr i8, ptr %1464, i64 %1466
  %1468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1469 = extractelement <8 x ptr> %1468, i64 1
  %1470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1471 = extractelement <8 x i64> %1470, i64 1
  %1472 = getelementptr i8, ptr %1469, i64 %1471
  %1473 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1474 = extractelement <8 x ptr> %1473, i64 1
  %1475 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1476 = extractelement <8 x i64> %1475, i64 1
  %1477 = getelementptr i8, ptr %1474, i64 %1476
  call void @llm_attention.strided_mma.1(ptr %1462, ptr %1467, ptr %1472, ptr %1477)
  br label %mma.continue413

mma.continue413:                                  ; preds = %mma.active412, %mma.continue411
  %1478 = extractelement <8 x i1> %80, i64 2
  br i1 %1478, label %mma.active414, label %mma.continue415

mma.active414:                                    ; preds = %mma.continue413
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1480 = extractelement <8 x ptr> %1479, i64 2
  %1481 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1482 = extractelement <8 x i64> %1481, i64 2
  %1483 = getelementptr i8, ptr %1480, i64 %1482
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1485 = extractelement <8 x ptr> %1484, i64 2
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1487 = extractelement <8 x i64> %1486, i64 2
  %1488 = getelementptr i8, ptr %1485, i64 %1487
  %1489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1490 = extractelement <8 x ptr> %1489, i64 2
  %1491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1492 = extractelement <8 x i64> %1491, i64 2
  %1493 = getelementptr i8, ptr %1490, i64 %1492
  %1494 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1495 = extractelement <8 x ptr> %1494, i64 2
  %1496 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1497 = extractelement <8 x i64> %1496, i64 2
  %1498 = getelementptr i8, ptr %1495, i64 %1497
  call void @llm_attention.strided_mma.1(ptr %1483, ptr %1488, ptr %1493, ptr %1498)
  br label %mma.continue415

mma.continue415:                                  ; preds = %mma.active414, %mma.continue413
  %1499 = extractelement <8 x i1> %80, i64 3
  br i1 %1499, label %mma.active416, label %mma.continue417

mma.active416:                                    ; preds = %mma.continue415
  %1500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1501 = extractelement <8 x ptr> %1500, i64 3
  %1502 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1503 = extractelement <8 x i64> %1502, i64 3
  %1504 = getelementptr i8, ptr %1501, i64 %1503
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1506 = extractelement <8 x ptr> %1505, i64 3
  %1507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1508 = extractelement <8 x i64> %1507, i64 3
  %1509 = getelementptr i8, ptr %1506, i64 %1508
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1511 = extractelement <8 x ptr> %1510, i64 3
  %1512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1513 = extractelement <8 x i64> %1512, i64 3
  %1514 = getelementptr i8, ptr %1511, i64 %1513
  %1515 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1516 = extractelement <8 x ptr> %1515, i64 3
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1518 = extractelement <8 x i64> %1517, i64 3
  %1519 = getelementptr i8, ptr %1516, i64 %1518
  call void @llm_attention.strided_mma.1(ptr %1504, ptr %1509, ptr %1514, ptr %1519)
  br label %mma.continue417

mma.continue417:                                  ; preds = %mma.active416, %mma.continue415
  %1520 = extractelement <8 x i1> %80, i64 4
  br i1 %1520, label %mma.active418, label %mma.continue419

mma.active418:                                    ; preds = %mma.continue417
  %1521 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1522 = extractelement <8 x ptr> %1521, i64 4
  %1523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1524 = extractelement <8 x i64> %1523, i64 4
  %1525 = getelementptr i8, ptr %1522, i64 %1524
  %1526 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1527 = extractelement <8 x ptr> %1526, i64 4
  %1528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1529 = extractelement <8 x i64> %1528, i64 4
  %1530 = getelementptr i8, ptr %1527, i64 %1529
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1532 = extractelement <8 x ptr> %1531, i64 4
  %1533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1534 = extractelement <8 x i64> %1533, i64 4
  %1535 = getelementptr i8, ptr %1532, i64 %1534
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1537 = extractelement <8 x ptr> %1536, i64 4
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1539 = extractelement <8 x i64> %1538, i64 4
  %1540 = getelementptr i8, ptr %1537, i64 %1539
  call void @llm_attention.strided_mma.1(ptr %1525, ptr %1530, ptr %1535, ptr %1540)
  br label %mma.continue419

mma.continue419:                                  ; preds = %mma.active418, %mma.continue417
  %1541 = extractelement <8 x i1> %80, i64 5
  br i1 %1541, label %mma.active420, label %mma.continue421

mma.active420:                                    ; preds = %mma.continue419
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1543 = extractelement <8 x ptr> %1542, i64 5
  %1544 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1545 = extractelement <8 x i64> %1544, i64 5
  %1546 = getelementptr i8, ptr %1543, i64 %1545
  %1547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1548 = extractelement <8 x ptr> %1547, i64 5
  %1549 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1550 = extractelement <8 x i64> %1549, i64 5
  %1551 = getelementptr i8, ptr %1548, i64 %1550
  %1552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1553 = extractelement <8 x ptr> %1552, i64 5
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1555 = extractelement <8 x i64> %1554, i64 5
  %1556 = getelementptr i8, ptr %1553, i64 %1555
  %1557 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1558 = extractelement <8 x ptr> %1557, i64 5
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1560 = extractelement <8 x i64> %1559, i64 5
  %1561 = getelementptr i8, ptr %1558, i64 %1560
  call void @llm_attention.strided_mma.1(ptr %1546, ptr %1551, ptr %1556, ptr %1561)
  br label %mma.continue421

mma.continue421:                                  ; preds = %mma.active420, %mma.continue419
  %1562 = extractelement <8 x i1> %80, i64 6
  br i1 %1562, label %mma.active422, label %mma.continue423

mma.active422:                                    ; preds = %mma.continue421
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1564 = extractelement <8 x ptr> %1563, i64 6
  %1565 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1566 = extractelement <8 x i64> %1565, i64 6
  %1567 = getelementptr i8, ptr %1564, i64 %1566
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1569 = extractelement <8 x ptr> %1568, i64 6
  %1570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1571 = extractelement <8 x i64> %1570, i64 6
  %1572 = getelementptr i8, ptr %1569, i64 %1571
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1574 = extractelement <8 x ptr> %1573, i64 6
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1576 = extractelement <8 x i64> %1575, i64 6
  %1577 = getelementptr i8, ptr %1574, i64 %1576
  %1578 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1579 = extractelement <8 x ptr> %1578, i64 6
  %1580 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1581 = extractelement <8 x i64> %1580, i64 6
  %1582 = getelementptr i8, ptr %1579, i64 %1581
  call void @llm_attention.strided_mma.1(ptr %1567, ptr %1572, ptr %1577, ptr %1582)
  br label %mma.continue423

mma.continue423:                                  ; preds = %mma.active422, %mma.continue421
  %1583 = extractelement <8 x i1> %80, i64 7
  br i1 %1583, label %mma.active424, label %mma.continue425

mma.active424:                                    ; preds = %mma.continue423
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1585 = extractelement <8 x ptr> %1584, i64 7
  %1586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1587 = extractelement <8 x i64> %1586, i64 7
  %1588 = getelementptr i8, ptr %1585, i64 %1587
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1590 = extractelement <8 x ptr> %1589, i64 7
  %1591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1592 = extractelement <8 x i64> %1591, i64 7
  %1593 = getelementptr i8, ptr %1590, i64 %1592
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1595 = extractelement <8 x ptr> %1594, i64 7
  %1596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1597 = extractelement <8 x i64> %1596, i64 7
  %1598 = getelementptr i8, ptr %1595, i64 %1597
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1600 = extractelement <8 x ptr> %1599, i64 7
  %1601 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1602 = extractelement <8 x i64> %1601, i64 7
  %1603 = getelementptr i8, ptr %1600, i64 %1602
  call void @llm_attention.strided_mma.1(ptr %1588, ptr %1593, ptr %1598, ptr %1603)
  br label %mma.continue425

mma.continue425:                                  ; preds = %mma.active424, %mma.continue423
  store i64 0, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.true427:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false428:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true441:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false442:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true460:                                   ; preds = %direct.schedule.35
  br label %direct.schedule.36

direct.false461:                                  ; preds = %direct.schedule.35
  br label %direct.schedule.37
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma(ptr %0, ptr %1, ptr %2, ptr %3) #3 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %39, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 16
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = urem i64 %mma.k, 16
  %6 = udiv i64 %mma.k, 16
  %7 = urem i64 %mma.k, 16
  %8 = mul i64 %7, 128
  %9 = add i64 0, %8
  %10 = udiv i64 %mma.k, 16
  %11 = getelementptr float, ptr %2, i64 %mma.k
  %12 = load float, ptr %11, align 4
  %13 = getelementptr float, ptr %0, i64 0
  %14 = load <4 x float>, ptr %13, align 4
  %15 = getelementptr float, ptr %1, i64 %9
  %16 = load <4 x float>, ptr %15, align 4
  %17 = fmul <4 x float> %14, %16
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.update2, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %29, %mma.update2 ]
  %mma.acc5 = phi <4 x float> [ %17, %mma.update ], [ %28, %mma.update2 ]
  %18 = icmp ult i64 %mma.k4, 31
  br i1 %18, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %19 = add i64 %mma.k4, 1
  %20 = mul i64 %19, 4
  %21 = add i64 0, %20
  %22 = getelementptr float, ptr %0, i64 %21
  %23 = load <4 x float>, ptr %22, align 4
  %24 = add i64 %9, %20
  %25 = getelementptr float, ptr %1, i64 %24
  %26 = load <4 x float>, ptr %25, align 4
  %27 = fmul <4 x float> %23, %26
  %28 = fadd <4 x float> %mma.acc5, %27
  %29 = add i64 %mma.k4, 1
  br label %mma.fold1

mma.fold.done3:                                   ; preds = %mma.fold1
  %30 = extractelement <4 x float> %mma.acc5, i64 0
  %31 = extractelement <4 x float> %mma.acc5, i64 1
  %32 = extractelement <4 x float> %mma.acc5, i64 2
  %33 = extractelement <4 x float> %mma.acc5, i64 3
  %34 = fadd float %30, %31
  %35 = fadd float %32, %33
  %36 = fadd float %34, %35
  %37 = fadd float %12, %36
  %38 = getelementptr float, ptr %3, i64 %mma.k
  store float %37, ptr %38, align 4
  %39 = add i64 %mma.k, 1
  br label %mma.fold
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma.1(ptr %0, ptr %1, ptr %2, ptr %3) #3 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %17, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 1
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = mul i64 %mma.k, 128
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.fold.done8, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %31, %mma.fold.done8 ]
  %mma.acc5 = phi i64 [ 0, %mma.update ], [ %mma.acc5, %mma.fold.done8 ]
  %6 = icmp ult i64 %mma.k4, 32
  br i1 %6, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %7 = mul i64 %mma.k4, 4
  %8 = add i64 %5, %7
  %9 = urem i64 %8, 128
  %10 = udiv i64 %8, 128
  %11 = urem i64 %8, 128
  %12 = mul i64 %11, 1
  %13 = add i64 0, %12
  %14 = udiv i64 %8, 128
  %15 = getelementptr float, ptr %2, i64 %8
  %16 = load <4 x float>, ptr %15, align 4
  br label %mma.fold6

mma.fold.done3:                                   ; preds = %mma.fold1
  %17 = add i64 %mma.k, 1
  br label %mma.fold

mma.fold6:                                        ; preds = %mma.update7, %mma.update2
  %mma.k9 = phi i64 [ 0, %mma.update2 ], [ %29, %mma.update7 ]
  %mma.acc10 = phi <4 x float> [ %16, %mma.update2 ], [ %28, %mma.update7 ]
  %18 = icmp ult i64 %mma.k9, 16
  br i1 %18, label %mma.update7, label %mma.fold.done8

mma.update7:                                      ; preds = %mma.fold6
  %19 = mul i64 %mma.k9, 1
  %20 = add i64 0, %19
  %21 = getelementptr float, ptr %0, i64 %20
  %22 = load float, ptr %21, align 4
  %.splatinsert = insertelement <4 x float> poison, float %22, i64 0
  %.splat = shufflevector <4 x float> %.splatinsert, <4 x float> poison, <4 x i32> zeroinitializer
  %23 = mul i64 %mma.k9, 128
  %24 = add i64 %13, %23
  %25 = getelementptr float, ptr %1, i64 %24
  %26 = load <4 x float>, ptr %25, align 4
  %27 = fmul <4 x float> %.splat, %26
  %28 = fadd <4 x float> %mma.acc10, %27
  %29 = add i64 %mma.k9, 1
  br label %mma.fold6

mma.fold.done8:                                   ; preds = %mma.fold6
  %30 = getelementptr float, ptr %3, i64 %8
  store <4 x float> %mma.acc10, ptr %30, align 4
  %31 = add i64 %mma.k4, 1
  br label %mma.fold1
}

define internal void @llm_attention.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 4096
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 8192
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 12288
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 77824
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 143360
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 143872
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 144384
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 144896
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 145408
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 149504
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill41 = alloca i64, align 8
  store i64 0, ptr %.spill41, align 4
  %.spill42 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill42, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill43 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill43, align 64
  %tile_snapshot.spill44 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill44, align 64
  %.slot45 = alloca i64, align 8
  store i64 0, ptr %.slot45, align 4
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.spill49 = alloca i64, align 8
  store i64 0, ptr %.spill49, align 4
  %tile_snapshot.spill50 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill50, align 64
  %.slot51 = alloca i64, align 8
  store i64 0, ptr %.slot51, align 4
  %.spill52 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill52, align 64
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %tile_snapshot.spill54 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill54, align 64
  %.slot55 = alloca i64, align 8
  store i64 0, ptr %.slot55, align 4
  %.spill56 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill56, align 64
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.spill58 = alloca i64, align 8
  store i64 0, ptr %.spill58, align 4
  %.spill59 = alloca i1, align 1
  store i1 false, ptr %.spill59, align 1
  %.spill60 = alloca i1, align 1
  store i1 false, ptr %.spill60, align 1
  %.spill61 = alloca i1, align 1
  store i1 false, ptr %.spill61, align 1
  %.spill62 = alloca i1, align 1
  store i1 false, ptr %.spill62, align 1
  %.spill63 = alloca i1, align 1
  store i1 false, ptr %.spill63, align 1
  %.spill64 = alloca i1, align 1
  store i1 false, ptr %.spill64, align 1
  %.spill65 = alloca i1, align 1
  store i1 false, ptr %.spill65, align 1
  %.spill66 = alloca i1, align 1
  store i1 false, ptr %.spill66, align 1
  %.spill67 = alloca i1, align 1
  store i1 false, ptr %.spill67, align 1
  %.spill68 = alloca i1, align 1
  store i1 false, ptr %.spill68, align 1
  %.spill69 = alloca i1, align 1
  store i1 false, ptr %.spill69, align 1
  %.spill70 = alloca i1, align 1
  store i1 false, ptr %.spill70, align 1
  %.spill71 = alloca i1, align 1
  store i1 false, ptr %.spill71, align 1
  %.spill72 = alloca i1, align 1
  store i1 false, ptr %.spill72, align 1
  %.spill73 = alloca i1, align 1
  store i1 false, ptr %.spill73, align 1
  %.spill74 = alloca i1, align 1
  store i1 false, ptr %.spill74, align 1
  %.spill75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill75, align 32
  %.spill76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill76, align 32
  %.spill77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill77, align 32
  %.spill78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill78, align 32
  %.spill79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill79, align 32
  %.spill80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill80, align 32
  %.spill81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill81, align 32
  %.spill82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill82, align 32
  %.spill83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill83, align 32
  %.spill84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill84, align 32
  %.spill85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill85, align 32
  %.spill86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill86, align 32
  %.spill87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill87, align 32
  %.spill88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill88, align 32
  %.spill89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill89, align 32
  %.spill90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill90, align 32
  %tile_snapshot.spill91 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill91, align 64
  %.slot92 = alloca i64, align 8
  store i64 0, ptr %.slot92, align 4
  %.slot93 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot93, align 32
  %.spill94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill94, align 32
  %.spill95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill95, align 32
  %tile_snapshot.spill96 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill96, align 64
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %.slot98 = alloca i64, align 8
  store i64 0, ptr %.slot98, align 4
  %.slot99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot99, align 32
  %.spill100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill100, align 32
  %tile_snapshot.spill101 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill101, align 64
  %.slot102 = alloca i64, align 8
  store i64 0, ptr %.slot102, align 4
  %tile_snapshot.spill103 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill103, align 64
  %.slot104 = alloca i64, align 8
  store i64 0, ptr %.slot104, align 4
  %.slot105 = alloca i64, align 8
  store i64 0, ptr %.slot105, align 4
  %.slot106 = alloca i64, align 8
  store i64 0, ptr %.slot106, align 4
  %33 = getelementptr i8, ptr %argument_buffer, i64 0
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = getelementptr i8, ptr %argument_buffer, i64 16
  %40 = load ptr, ptr %39, align 16
  %41 = getelementptr i8, ptr %39, i64 8
  %42 = load i64, ptr %41, align 8
  %43 = insertvalue { ptr, i64 } poison, ptr %40, 0
  %44 = insertvalue { ptr, i64 } %43, i64 %42, 1
  %45 = getelementptr i8, ptr %argument_buffer, i64 32
  %46 = load ptr, ptr %45, align 16
  %47 = getelementptr i8, ptr %45, i64 8
  %48 = load i64, ptr %47, align 8
  %49 = insertvalue { ptr, i64 } poison, ptr %46, 0
  %50 = insertvalue { ptr, i64 } %49, i64 %48, 1
  %51 = getelementptr i8, ptr %argument_buffer, i64 48
  %52 = load ptr, ptr %51, align 16
  %53 = getelementptr i8, ptr %51, i64 8
  %54 = load i64, ptr %53, align 8
  %55 = insertvalue { ptr, i64 } poison, ptr %52, 0
  %56 = insertvalue { ptr, i64 } %55, i64 %54, 1
  %57 = load i32, ptr %launch_config, align 4
  %58 = getelementptr i8, ptr %launch_config, i64 12
  %59 = load i32, ptr %58, align 4
  %60 = getelementptr i8, ptr %launch_config, i64 4
  %61 = load i32, ptr %60, align 4
  %62 = getelementptr i8, ptr %launch_config, i64 16
  %63 = load i32, ptr %62, align 4
  %64 = getelementptr i8, ptr %launch_config, i64 8
  %65 = load i32, ptr %64, align 4
  %66 = getelementptr i8, ptr %launch_config, i64 20
  %67 = load i32, ptr %66, align 4
  %68 = getelementptr i8, ptr %launch_config, i64 36
  %69 = load i32, ptr %68, align 4
  %.splatinsert107 = insertelement <8 x i32> poison, i32 %69, i64 0
  %.splat108 = shufflevector <8 x i32> %.splatinsert107, <8 x i32> poison, <8 x i32> zeroinitializer
  %70 = add <8 x i32> %.splat108, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %71 = mul i32 %57, 32
  %.splatinsert109 = insertelement <8 x i32> poison, i32 %71, i64 0
  %.splat110 = shufflevector <8 x i32> %.splatinsert109, <8 x i32> poison, <8 x i32> zeroinitializer
  %72 = add <8 x i32> %.splat110, %70
  %73 = mul i32 %61, 1
  %.splatinsert111 = insertelement <8 x i32> poison, i32 %73, i64 0
  %.splat112 = shufflevector <8 x i32> %.splatinsert111, <8 x i32> poison, <8 x i32> zeroinitializer
  %74 = add <8 x i32> %.splat112, zeroinitializer
  %75 = mul i32 %65, 1
  %.splatinsert113 = insertelement <8 x i32> poison, i32 %75, i64 0
  %.splat114 = shufflevector <8 x i32> %.splatinsert113, <8 x i32> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i32> %.splat114, zeroinitializer
  %77 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %72, 0
  %78 = insertvalue [3 x <8 x i32>] %77, <8 x i32> %74, 1
  %79 = insertvalue [3 x <8 x i32>] %78, <8 x i32> %76, 2
  %.splatinsert115 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat116 = shufflevector <8 x i32> %.splatinsert115, <8 x i32> poison, <8 x i32> zeroinitializer
  %80 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat116
  %81 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  br i1 %81, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %82 = extractvalue [3 x <8 x i32>] %79, 0
  %83 = zext <8 x i32> %82 to <8 x i64>
  %84 = select <8 x i1> %80, <8 x i64> %83, <8 x i64> zeroinitializer
  %85 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %86 = sdiv <8 x i64> %84, %85
  %87 = load <8 x i64>, ptr %.spill, align 64
  %88 = select <8 x i1> %80, <8 x i64> %86, <8 x i64> %87
  store <8 x i64> %88, ptr %.spill, align 64
  store i64 0, ptr %.spill41, align 4
  %89 = select <8 x i1> %80, <8 x i64> %86, <8 x i64> zeroinitializer
  %90 = select <8 x i1> %80, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %91 = sdiv <8 x i64> %89, %90
  %92 = load <8 x i64>, ptr %.spill42, align 64
  %93 = select <8 x i1> %80, <8 x i64> %91, <8 x i64> %92
  store <8 x i64> %93, ptr %.spill42, align 64
  %94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %94, 0
  %97 = select <8 x i1> %80, <8 x ptr> %95, <8 x ptr> %96
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %94, 1
  %100 = select <8 x i1> %80, <8 x i64> %98, <8 x i64> %99
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %97, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  store { <8 x ptr>, <8 x i64> } %102, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %103 = icmp slt i64 %.state, 128
  br i1 %103, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load i64, ptr %.spill41, align 4
  %104 = add i64 %.spill.load, 0
  %.spill.load117 = load <8 x i64>, ptr %.spill, align 64
  %105 = add <8 x i64> %.spill.load117, zeroinitializer
  %106 = mul i64 %104, 16
  %.splatinsert118 = insertelement <8 x i64> poison, i64 %106, i64 0
  %.splat119 = shufflevector <8 x i64> %.splatinsert118, <8 x i64> poison, <8 x i32> zeroinitializer
  %107 = add <8 x i64> %.splat119, %105
  %.spill.load120 = load i64, ptr %.spill41, align 4
  %108 = add i64 %.spill.load120, 0
  %109 = mul <8 x i64> %107, splat (i64 1)
  %.splatinsert121 = insertelement <8 x i64> poison, i64 %108, i64 0
  %.splat122 = shufflevector <8 x i64> %.splatinsert121, <8 x i64> poison, <8 x i32> zeroinitializer
  %110 = add <8 x i64> %109, %.splat122
  %.state123 = load i64, ptr %.slot, align 4
  %111 = add i64 0, %.state123
  %112 = mul <8 x i64> %110, splat (i64 128)
  %.splatinsert124 = insertelement <8 x i64> poison, i64 %111, i64 0
  %.splat125 = shufflevector <8 x i64> %.splatinsert124, <8 x i64> poison, <8 x i32> zeroinitializer
  %113 = add <8 x i64> %112, %.splat125
  %114 = extractvalue { ptr, i64 } %38, 0
  %115 = mul <8 x i64> %113, splat (i64 4)
  %116 = getelementptr i8, ptr %114, <8 x i64> %115
  %117 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %116, <8 x i1> %80, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %119 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state126 = load i64, ptr %.slot, align 4
  %.splatinsert127 = insertelement <8 x i64> poison, i64 %.state126, i64 0
  %.splat128 = shufflevector <8 x i64> %.splatinsert127, <8 x i64> poison, <8 x i32> zeroinitializer
  %120 = mul <8 x i64> %.splat128, splat (i64 4)
  %121 = add <8 x i64> %119, %120
  %122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %118, 0
  %123 = insertvalue { <8 x ptr>, <8 x i64> } %122, <8 x i64> %121, 1
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %123, 0
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %123, 1
  %126 = getelementptr i8, <8 x ptr> %124, <8 x i64> %125
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %117, <8 x ptr> align 1 %126, <8 x i1> %80)
  %.state129 = load i64, ptr %.slot, align 4
  %127 = add i64 %.state129, 1
  store i64 %127, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %128 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %128, 0
  %131 = select <8 x i1> %80, <8 x ptr> %129, <8 x ptr> %130
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %128, 1
  %134 = select <8 x i1> %80, <8 x i64> %132, <8 x i64> %133
  %135 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %131, 0
  %136 = insertvalue { <8 x ptr>, <8 x i64> } %135, <8 x i64> %134, 1
  store { <8 x ptr>, <8 x i64> } %136, ptr %tile_snapshot.spill43, align 64
  %137 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %137, 0
  %140 = select <8 x i1> %80, <8 x ptr> %138, <8 x ptr> %139
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %137, 1
  %143 = select <8 x i1> %80, <8 x i64> %141, <8 x i64> %142
  %144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %140, 0
  %145 = insertvalue { <8 x ptr>, <8 x i64> } %144, <8 x i64> %143, 1
  store { <8 x ptr>, <8 x i64> } %145, ptr %tile_snapshot.spill44, align 64
  store i64 0, ptr %.slot45, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state130 = load i64, ptr %.slot45, align 4
  %146 = icmp slt i64 %.state130, 128
  br i1 %146, label %direct.true131, label %direct.false132

direct.schedule.5:                                ; preds = %direct.true131
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %.state134 = load i64, ptr %.slot45, align 4
  %.splatinsert135 = insertelement <8 x i64> poison, i64 %.state134, i64 0
  %.splat136 = shufflevector <8 x i64> %.splatinsert135, <8 x i64> poison, <8 x i32> zeroinitializer
  %149 = mul <8 x i64> %.splat136, splat (i64 32)
  %150 = add <8 x i64> %148, %149
  %151 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %147, 0
  %152 = insertvalue { <8 x ptr>, <8 x i64> } %151, <8 x i64> %150, 1
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %152, 1
  %155 = extractelement <8 x ptr> %153, i32 0
  %156 = extractelement <8 x i64> %154, i32 0
  %157 = sub i64 %156, 0
  %158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %159 = select i1 %158, i64 %157, i64 0
  %private.contiguous.address = getelementptr i8, ptr %155, i64 %159
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %160 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %160, ptr %private.contiguous.address, align 4
  %.state137 = load i64, ptr %.slot45, align 4
  %161 = add i64 %.state137, 1
  store i64 %161, ptr %.slot45, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false132
  store i64 0, ptr %.slot46, align 4
  %162 = load <8 x float>, ptr %.slot47, align 32
  %163 = select <8 x i1> %80, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %162
  store <8 x float> %163, ptr %.slot47, align 32
  %164 = load <8 x float>, ptr %.slot48, align 32
  %165 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %164
  store <8 x float> %165, ptr %.slot48, align 32
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.33, %direct.schedule.6
  %.state138 = load i64, ptr %.slot46, align 4
  %166 = icmp slt i64 %.state138, 513
  br i1 %166, label %direct.true139, label %direct.false140

direct.schedule.8:                                ; preds = %direct.true139
  %.state141 = load i64, ptr %.slot46, align 4
  %167 = sdiv i64 %.state141, 1
  %168 = mul i64 %167, 16
  store i64 %168, ptr %.spill49, align 4
  %169 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %169, 0
  %172 = select <8 x i1> %80, <8 x ptr> %170, <8 x ptr> %171
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %169, 1
  %175 = select <8 x i1> %80, <8 x i64> %173, <8 x i64> %174
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %172, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  store { <8 x ptr>, <8 x i64> } %177, ptr %tile_snapshot.spill50, align 64
  store i64 0, ptr %.slot51, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.12, %direct.schedule.8
  %.state142 = load i64, ptr %.slot51, align 4
  %178 = icmp slt i64 %.state142, 2048
  br i1 %178, label %direct.true143, label %direct.false144

direct.schedule.10:                               ; preds = %direct.true143
  %.state145 = load i64, ptr %.slot51, align 4
  %179 = srem i64 %.state145, 128
  %.state146 = load i64, ptr %.slot51, align 4
  %180 = sdiv i64 %.state146, 128
  %.spill.load147 = load i64, ptr %.spill41, align 4
  %181 = add i64 %.spill.load147, 0
  %.spill.load148 = load <8 x i64>, ptr %.spill42, align 64
  %182 = add <8 x i64> %.spill.load148, zeroinitializer
  %183 = mul i64 %181, 4
  %.splatinsert149 = insertelement <8 x i64> poison, i64 %183, i64 0
  %.splat150 = shufflevector <8 x i64> %.splatinsert149, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %.splat150, %182
  %.spill.load151 = load i64, ptr %.spill49, align 4
  %185 = add i64 %.spill.load151, %180
  %186 = mul <8 x i64> %184, splat (i64 8193)
  %.splatinsert152 = insertelement <8 x i64> poison, i64 %185, i64 0
  %.splat153 = shufflevector <8 x i64> %.splatinsert152, <8 x i64> poison, <8 x i32> zeroinitializer
  %187 = add <8 x i64> %186, %.splat153
  %188 = icmp sge i64 %185, 0
  %189 = and i1 true, %188
  %190 = icmp slt i64 %185, 8193
  %191 = and i1 %189, %190
  %192 = add i64 0, %179
  %193 = mul <8 x i64> %187, splat (i64 128)
  %.splatinsert154 = insertelement <8 x i64> poison, i64 %192, i64 0
  %.splat155 = shufflevector <8 x i64> %.splatinsert154, <8 x i64> poison, <8 x i32> zeroinitializer
  %194 = add <8 x i64> %193, %.splat155
  %195 = load <8 x i64>, ptr %.spill52, align 64
  %196 = select <8 x i1> %80, <8 x i64> %194, <8 x i64> %195
  store <8 x i64> %196, ptr %.spill52, align 64
  br i1 %191, label %direct.true156, label %direct.false157

direct.schedule.11:                               ; preds = %direct.true156
  %.spill.load158 = load <8 x i64>, ptr %.spill52, align 64
  %197 = extractvalue { ptr, i64 } %44, 0
  %198 = mul <8 x i64> %.spill.load158, splat (i64 4)
  %199 = getelementptr i8, ptr %197, <8 x i64> %198
  %200 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %199, <8 x i1> %80, <8 x float> zeroinitializer)
  %201 = load <8 x float>, ptr %.slot53, align 32
  %202 = select <8 x i1> %80, <8 x float> %200, <8 x float> %201
  store <8 x float> %202, ptr %.slot53, align 32
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.false157, %direct.schedule.11
  %tile_snapshot.spill.load159 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load159, 0
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load159, 1
  %.state160 = load i64, ptr %.slot51, align 4
  %.splatinsert161 = insertelement <8 x i64> poison, i64 %.state160, i64 0
  %.splat162 = shufflevector <8 x i64> %.splatinsert161, <8 x i64> poison, <8 x i32> zeroinitializer
  %205 = mul <8 x i64> %.splat162, splat (i64 4)
  %206 = add <8 x i64> %204, %205
  %207 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %203, 0
  %208 = insertvalue { <8 x ptr>, <8 x i64> } %207, <8 x i64> %206, 1
  %.state163 = load <8 x float>, ptr %.slot53, align 32
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %208, 0
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %208, 1
  %211 = getelementptr i8, <8 x ptr> %209, <8 x i64> %210
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state163, <8 x ptr> align 1 %211, <8 x i1> %80)
  %.state164 = load i64, ptr %.slot51, align 4
  %212 = add i64 %.state164, 1
  store i64 %212, ptr %.slot51, align 4
  br label %direct.schedule.9

direct.schedule.13:                               ; preds = %direct.false144
  %213 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %213, 0
  %216 = select <8 x i1> %80, <8 x ptr> %214, <8 x ptr> %215
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %213, 1
  %219 = select <8 x i1> %80, <8 x i64> %217, <8 x i64> %218
  %220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %216, 0
  %221 = insertvalue { <8 x ptr>, <8 x i64> } %220, <8 x i64> %219, 1
  store { <8 x ptr>, <8 x i64> } %221, ptr %tile_snapshot.spill54, align 64
  store i64 0, ptr %.slot55, align 4
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.17, %direct.schedule.13
  %.state165 = load i64, ptr %.slot55, align 4
  %222 = icmp slt i64 %.state165, 2048
  br i1 %222, label %direct.true166, label %direct.false167

direct.schedule.15:                               ; preds = %direct.true166
  %.state168 = load i64, ptr %.slot55, align 4
  %223 = srem i64 %.state168, 128
  %.state169 = load i64, ptr %.slot55, align 4
  %224 = sdiv i64 %.state169, 128
  %.spill.load170 = load i64, ptr %.spill41, align 4
  %225 = add i64 %.spill.load170, 0
  %.spill.load171 = load <8 x i64>, ptr %.spill42, align 64
  %226 = add <8 x i64> %.spill.load171, zeroinitializer
  %227 = mul i64 %225, 4
  %.splatinsert172 = insertelement <8 x i64> poison, i64 %227, i64 0
  %.splat173 = shufflevector <8 x i64> %.splatinsert172, <8 x i64> poison, <8 x i32> zeroinitializer
  %228 = add <8 x i64> %.splat173, %226
  %.spill.load174 = load i64, ptr %.spill49, align 4
  %229 = add i64 %.spill.load174, %224
  %230 = mul <8 x i64> %228, splat (i64 8193)
  %.splatinsert175 = insertelement <8 x i64> poison, i64 %229, i64 0
  %.splat176 = shufflevector <8 x i64> %.splatinsert175, <8 x i64> poison, <8 x i32> zeroinitializer
  %231 = add <8 x i64> %230, %.splat176
  %232 = icmp sge i64 %229, 0
  %233 = and i1 true, %232
  %234 = icmp slt i64 %229, 8193
  %235 = and i1 %233, %234
  %236 = add i64 0, %223
  %237 = mul <8 x i64> %231, splat (i64 128)
  %.splatinsert177 = insertelement <8 x i64> poison, i64 %236, i64 0
  %.splat178 = shufflevector <8 x i64> %.splatinsert177, <8 x i64> poison, <8 x i32> zeroinitializer
  %238 = add <8 x i64> %237, %.splat178
  %239 = load <8 x i64>, ptr %.spill56, align 64
  %240 = select <8 x i1> %80, <8 x i64> %238, <8 x i64> %239
  store <8 x i64> %240, ptr %.spill56, align 64
  br i1 %235, label %direct.true179, label %direct.false180

direct.schedule.16:                               ; preds = %direct.true179
  %.spill.load181 = load <8 x i64>, ptr %.spill56, align 64
  %241 = extractvalue { ptr, i64 } %50, 0
  %242 = mul <8 x i64> %.spill.load181, splat (i64 4)
  %243 = getelementptr i8, ptr %241, <8 x i64> %242
  %244 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %243, <8 x i1> %80, <8 x float> zeroinitializer)
  %245 = load <8 x float>, ptr %.slot57, align 32
  %246 = select <8 x i1> %80, <8 x float> %244, <8 x float> %245
  store <8 x float> %246, ptr %.slot57, align 32
  br label %direct.schedule.17

direct.schedule.17:                               ; preds = %direct.false180, %direct.schedule.16
  %tile_snapshot.spill.load182 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 0
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load182, 1
  %.state183 = load i64, ptr %.slot55, align 4
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %.state183, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %249 = mul <8 x i64> %.splat185, splat (i64 4)
  %250 = add <8 x i64> %248, %249
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %247, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %.state186 = load <8 x float>, ptr %.slot57, align 32
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %252, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = getelementptr i8, <8 x ptr> %253, <8 x i64> %254
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state186, <8 x ptr> align 1 %255, <8 x i1> %80)
  %.state187 = load i64, ptr %.slot55, align 4
  %256 = add i64 %.state187, 1
  store i64 %256, ptr %.slot55, align 4
  br label %direct.schedule.14

direct.schedule.18:                               ; preds = %direct.false167
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %259 = add <8 x i64> %258, zeroinitializer
  %260 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %257, 0
  %261 = insertvalue { <8 x ptr>, <8 x i64> } %260, <8 x i64> %259, 1
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %261, 0
  %263 = extractvalue { <8 x ptr>, <8 x i64> } %261, 1
  %264 = getelementptr i8, <8 x ptr> %262, <8 x i64> %263
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %264, <8 x i1> %80)
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %267 = add <8 x i64> %266, splat (i64 4)
  %268 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %269 = insertvalue { <8 x ptr>, <8 x i64> } %268, <8 x i64> %267, 1
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %269, 0
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %269, 1
  %272 = getelementptr i8, <8 x ptr> %270, <8 x i64> %271
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %272, <8 x i1> %80)
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %275 = add <8 x i64> %274, splat (i64 8)
  %276 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %273, 0
  %277 = insertvalue { <8 x ptr>, <8 x i64> } %276, <8 x i64> %275, 1
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %277, 0
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %277, 1
  %280 = getelementptr i8, <8 x ptr> %278, <8 x i64> %279
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %280, <8 x i1> %80)
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %283 = add <8 x i64> %282, splat (i64 12)
  %284 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %281, 0
  %285 = insertvalue { <8 x ptr>, <8 x i64> } %284, <8 x i64> %283, 1
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %285, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %285, 1
  %288 = getelementptr i8, <8 x ptr> %286, <8 x i64> %287
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %288, <8 x i1> %80)
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %291 = add <8 x i64> %290, splat (i64 16)
  %292 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %289, 0
  %293 = insertvalue { <8 x ptr>, <8 x i64> } %292, <8 x i64> %291, 1
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %293, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %293, 1
  %296 = getelementptr i8, <8 x ptr> %294, <8 x i64> %295
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %296, <8 x i1> %80)
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %298 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %299 = add <8 x i64> %298, splat (i64 20)
  %300 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %297, 0
  %301 = insertvalue { <8 x ptr>, <8 x i64> } %300, <8 x i64> %299, 1
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %301, 0
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %301, 1
  %304 = getelementptr i8, <8 x ptr> %302, <8 x i64> %303
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %304, <8 x i1> %80)
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %307 = add <8 x i64> %306, splat (i64 24)
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %305, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %309, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = getelementptr i8, <8 x ptr> %310, <8 x i64> %311
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %312, <8 x i1> %80)
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %315 = add <8 x i64> %314, splat (i64 28)
  %316 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %313, 0
  %317 = insertvalue { <8 x ptr>, <8 x i64> } %316, <8 x i64> %315, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %317, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %317, 1
  %320 = getelementptr i8, <8 x ptr> %318, <8 x i64> %319
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %320, <8 x i1> %80)
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %323 = add <8 x i64> %322, splat (i64 32)
  %324 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %325 = insertvalue { <8 x ptr>, <8 x i64> } %324, <8 x i64> %323, 1
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %325, 0
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %325, 1
  %328 = getelementptr i8, <8 x ptr> %326, <8 x i64> %327
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %328, <8 x i1> %80)
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %331 = add <8 x i64> %330, splat (i64 36)
  %332 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %329, 0
  %333 = insertvalue { <8 x ptr>, <8 x i64> } %332, <8 x i64> %331, 1
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %333, 0
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %333, 1
  %336 = getelementptr i8, <8 x ptr> %334, <8 x i64> %335
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %336, <8 x i1> %80)
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %339 = add <8 x i64> %338, splat (i64 40)
  %340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %337, 0
  %341 = insertvalue { <8 x ptr>, <8 x i64> } %340, <8 x i64> %339, 1
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %341, 0
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %341, 1
  %344 = getelementptr i8, <8 x ptr> %342, <8 x i64> %343
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %344, <8 x i1> %80)
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %347 = add <8 x i64> %346, splat (i64 44)
  %348 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %345, 0
  %349 = insertvalue { <8 x ptr>, <8 x i64> } %348, <8 x i64> %347, 1
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %349, 0
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %349, 1
  %352 = getelementptr i8, <8 x ptr> %350, <8 x i64> %351
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %352, <8 x i1> %80)
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %355 = add <8 x i64> %354, splat (i64 48)
  %356 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %353, 0
  %357 = insertvalue { <8 x ptr>, <8 x i64> } %356, <8 x i64> %355, 1
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %357, 0
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %357, 1
  %360 = getelementptr i8, <8 x ptr> %358, <8 x i64> %359
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %360, <8 x i1> %80)
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %362 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %363 = add <8 x i64> %362, splat (i64 52)
  %364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %361, 0
  %365 = insertvalue { <8 x ptr>, <8 x i64> } %364, <8 x i64> %363, 1
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %365, 0
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %365, 1
  %368 = getelementptr i8, <8 x ptr> %366, <8 x i64> %367
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %368, <8 x i1> %80)
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %371 = add <8 x i64> %370, splat (i64 56)
  %372 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %369, 0
  %373 = insertvalue { <8 x ptr>, <8 x i64> } %372, <8 x i64> %371, 1
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %373, 0
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %373, 1
  %376 = getelementptr i8, <8 x ptr> %374, <8 x i64> %375
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %376, <8 x i1> %80)
  %377 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %378 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %379 = add <8 x i64> %378, splat (i64 60)
  %380 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %377, 0
  %381 = insertvalue { <8 x ptr>, <8 x i64> } %380, <8 x i64> %379, 1
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %381, 0
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %381, 1
  %384 = getelementptr i8, <8 x ptr> %382, <8 x i64> %383
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %384, <8 x i1> %80)
  %tile_snapshot.spill.load188 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %tile_snapshot.spill.load189 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  %385 = extractelement <8 x i1> %80, i64 0
  br i1 %385, label %mma.active, label %mma.continue

direct.schedule.19:                               ; preds = %mma.continue203, %direct.schedule.20
  %.state285 = load i64, ptr %.slot92, align 4
  %386 = icmp slt i64 %.state285, 16
  br i1 %386, label %direct.true286, label %direct.false287

direct.schedule.20:                               ; preds = %direct.true286
  %.state288 = load i64, ptr %.slot92, align 4
  %387 = sdiv i64 %.state288, 1
  %.spill.load289 = load i64, ptr %.spill58, align 4
  %388 = mul i64 %.spill.load289, 1
  %389 = add i64 %388, 0
  %390 = mul i64 %389, 1
  %391 = add i64 %390, 0
  %392 = mul i64 %391, 16
  %393 = add i64 %392, %387
  %tile_snapshot.spill.load290 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill91, align 64
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load290, 0
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load290, 1
  %.splatinsert291 = insertelement <8 x i64> poison, i64 %393, i64 0
  %.splat292 = shufflevector <8 x i64> %.splatinsert291, <8 x i64> poison, <8 x i32> zeroinitializer
  %396 = mul <8 x i64> %.splat292, splat (i64 32)
  %397 = add <8 x i64> %395, %396
  %398 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %394, 0
  %399 = insertvalue { <8 x ptr>, <8 x i64> } %398, <8 x i64> %397, 1
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %399, 1
  %402 = extractelement <8 x ptr> %400, i32 0
  %403 = extractelement <8 x i64> %401, i32 0
  %404 = sub i64 %403, 0
  %405 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %406 = select i1 %405, i64 %404, i64 0
  %private.contiguous.address293 = getelementptr i8, ptr %402, i64 %406
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address293, align 4
  %407 = select <8 x i1> %80, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.state294 = load <8 x float>, ptr %.slot93, align 32
  %408 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state294, <8 x float> %407)
  %.state295 = load i64, ptr %.slot92, align 4
  %409 = add i64 %.state295, 1
  store i64 %409, ptr %.slot92, align 4
  %410 = load <8 x float>, ptr %.slot93, align 32
  %411 = select <8 x i1> %80, <8 x float> %408, <8 x float> %410
  store <8 x float> %411, ptr %.slot93, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false287
  %.state296 = load <8 x float>, ptr %.slot47, align 32
  %.state297 = load <8 x float>, ptr %.slot93, align 32
  %412 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state296, <8 x float> %.state297)
  %413 = load <8 x float>, ptr %.spill94, align 32
  %414 = select <8 x i1> %80, <8 x float> %412, <8 x float> %413
  store <8 x float> %414, ptr %.spill94, align 32
  %.state298 = load <8 x float>, ptr %.slot47, align 32
  %415 = fsub <8 x float> %.state298, %412
  %416 = select <8 x i1> %80, <8 x float> %415, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %416)
  %417 = load <8 x float>, ptr %.spill95, align 32
  %418 = select <8 x i1> %80, <8 x float> %native.exp, <8 x float> %417
  store <8 x float> %418, ptr %.spill95, align 32
  %.spill.load299 = load <8 x float>, ptr %.spill75, align 32
  %419 = fsub <8 x float> %.spill.load299, %412
  %.spill.load300 = load <8 x float>, ptr %.spill76, align 32
  %420 = fsub <8 x float> %.spill.load300, %412
  %.spill.load301 = load <8 x float>, ptr %.spill77, align 32
  %421 = fsub <8 x float> %.spill.load301, %412
  %.spill.load302 = load <8 x float>, ptr %.spill78, align 32
  %422 = fsub <8 x float> %.spill.load302, %412
  %.spill.load303 = load <8 x float>, ptr %.spill79, align 32
  %423 = fsub <8 x float> %.spill.load303, %412
  %.spill.load304 = load <8 x float>, ptr %.spill80, align 32
  %424 = fsub <8 x float> %.spill.load304, %412
  %.spill.load305 = load <8 x float>, ptr %.spill81, align 32
  %425 = fsub <8 x float> %.spill.load305, %412
  %.spill.load306 = load <8 x float>, ptr %.spill82, align 32
  %426 = fsub <8 x float> %.spill.load306, %412
  %.spill.load307 = load <8 x float>, ptr %.spill83, align 32
  %427 = fsub <8 x float> %.spill.load307, %412
  %.spill.load308 = load <8 x float>, ptr %.spill84, align 32
  %428 = fsub <8 x float> %.spill.load308, %412
  %.spill.load309 = load <8 x float>, ptr %.spill85, align 32
  %429 = fsub <8 x float> %.spill.load309, %412
  %.spill.load310 = load <8 x float>, ptr %.spill86, align 32
  %430 = fsub <8 x float> %.spill.load310, %412
  %.spill.load311 = load <8 x float>, ptr %.spill87, align 32
  %431 = fsub <8 x float> %.spill.load311, %412
  %.spill.load312 = load <8 x float>, ptr %.spill88, align 32
  %432 = fsub <8 x float> %.spill.load312, %412
  %.spill.load313 = load <8 x float>, ptr %.spill89, align 32
  %433 = fsub <8 x float> %.spill.load313, %412
  %.spill.load314 = load <8 x float>, ptr %.spill90, align 32
  %434 = fsub <8 x float> %.spill.load314, %412
  %435 = select <8 x i1> %80, <8 x float> %419, <8 x float> zeroinitializer
  %native.exp315 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %435)
  %436 = select <8 x i1> %80, <8 x float> %420, <8 x float> zeroinitializer
  %native.exp316 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %436)
  %437 = select <8 x i1> %80, <8 x float> %421, <8 x float> zeroinitializer
  %native.exp317 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %437)
  %438 = select <8 x i1> %80, <8 x float> %422, <8 x float> zeroinitializer
  %native.exp318 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %438)
  %439 = select <8 x i1> %80, <8 x float> %423, <8 x float> zeroinitializer
  %native.exp319 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %439)
  %440 = select <8 x i1> %80, <8 x float> %424, <8 x float> zeroinitializer
  %native.exp320 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %440)
  %441 = select <8 x i1> %80, <8 x float> %425, <8 x float> zeroinitializer
  %native.exp321 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %441)
  %442 = select <8 x i1> %80, <8 x float> %426, <8 x float> zeroinitializer
  %native.exp322 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %442)
  %443 = select <8 x i1> %80, <8 x float> %427, <8 x float> zeroinitializer
  %native.exp323 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %443)
  %444 = select <8 x i1> %80, <8 x float> %428, <8 x float> zeroinitializer
  %native.exp324 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %444)
  %445 = select <8 x i1> %80, <8 x float> %429, <8 x float> zeroinitializer
  %native.exp325 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %445)
  %446 = select <8 x i1> %80, <8 x float> %430, <8 x float> zeroinitializer
  %native.exp326 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %446)
  %447 = select <8 x i1> %80, <8 x float> %431, <8 x float> zeroinitializer
  %native.exp327 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %447)
  %448 = select <8 x i1> %80, <8 x float> %432, <8 x float> zeroinitializer
  %native.exp328 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %448)
  %449 = select <8 x i1> %80, <8 x float> %433, <8 x float> zeroinitializer
  %native.exp329 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %449)
  %450 = select <8 x i1> %80, <8 x float> %434, <8 x float> zeroinitializer
  %native.exp330 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %450)
  %.spill.load331 = load i1, ptr %.spill59, align 1
  %.splatinsert332 = insertelement <8 x i1> poison, i1 %.spill.load331, i64 0
  %.splat333 = shufflevector <8 x i1> %.splatinsert332, <8 x i1> poison, <8 x i32> zeroinitializer
  %451 = select <8 x i1> %.splat333, <8 x float> %native.exp315, <8 x float> zeroinitializer
  %.spill.load334 = load i1, ptr %.spill60, align 1
  %.splatinsert335 = insertelement <8 x i1> poison, i1 %.spill.load334, i64 0
  %.splat336 = shufflevector <8 x i1> %.splatinsert335, <8 x i1> poison, <8 x i32> zeroinitializer
  %452 = select <8 x i1> %.splat336, <8 x float> %native.exp316, <8 x float> zeroinitializer
  %.spill.load337 = load i1, ptr %.spill61, align 1
  %.splatinsert338 = insertelement <8 x i1> poison, i1 %.spill.load337, i64 0
  %.splat339 = shufflevector <8 x i1> %.splatinsert338, <8 x i1> poison, <8 x i32> zeroinitializer
  %453 = select <8 x i1> %.splat339, <8 x float> %native.exp317, <8 x float> zeroinitializer
  %.spill.load340 = load i1, ptr %.spill62, align 1
  %.splatinsert341 = insertelement <8 x i1> poison, i1 %.spill.load340, i64 0
  %.splat342 = shufflevector <8 x i1> %.splatinsert341, <8 x i1> poison, <8 x i32> zeroinitializer
  %454 = select <8 x i1> %.splat342, <8 x float> %native.exp318, <8 x float> zeroinitializer
  %.spill.load343 = load i1, ptr %.spill63, align 1
  %.splatinsert344 = insertelement <8 x i1> poison, i1 %.spill.load343, i64 0
  %.splat345 = shufflevector <8 x i1> %.splatinsert344, <8 x i1> poison, <8 x i32> zeroinitializer
  %455 = select <8 x i1> %.splat345, <8 x float> %native.exp319, <8 x float> zeroinitializer
  %.spill.load346 = load i1, ptr %.spill64, align 1
  %.splatinsert347 = insertelement <8 x i1> poison, i1 %.spill.load346, i64 0
  %.splat348 = shufflevector <8 x i1> %.splatinsert347, <8 x i1> poison, <8 x i32> zeroinitializer
  %456 = select <8 x i1> %.splat348, <8 x float> %native.exp320, <8 x float> zeroinitializer
  %.spill.load349 = load i1, ptr %.spill65, align 1
  %.splatinsert350 = insertelement <8 x i1> poison, i1 %.spill.load349, i64 0
  %.splat351 = shufflevector <8 x i1> %.splatinsert350, <8 x i1> poison, <8 x i32> zeroinitializer
  %457 = select <8 x i1> %.splat351, <8 x float> %native.exp321, <8 x float> zeroinitializer
  %.spill.load352 = load i1, ptr %.spill66, align 1
  %.splatinsert353 = insertelement <8 x i1> poison, i1 %.spill.load352, i64 0
  %.splat354 = shufflevector <8 x i1> %.splatinsert353, <8 x i1> poison, <8 x i32> zeroinitializer
  %458 = select <8 x i1> %.splat354, <8 x float> %native.exp322, <8 x float> zeroinitializer
  %.spill.load355 = load i1, ptr %.spill67, align 1
  %.splatinsert356 = insertelement <8 x i1> poison, i1 %.spill.load355, i64 0
  %.splat357 = shufflevector <8 x i1> %.splatinsert356, <8 x i1> poison, <8 x i32> zeroinitializer
  %459 = select <8 x i1> %.splat357, <8 x float> %native.exp323, <8 x float> zeroinitializer
  %.spill.load358 = load i1, ptr %.spill68, align 1
  %.splatinsert359 = insertelement <8 x i1> poison, i1 %.spill.load358, i64 0
  %.splat360 = shufflevector <8 x i1> %.splatinsert359, <8 x i1> poison, <8 x i32> zeroinitializer
  %460 = select <8 x i1> %.splat360, <8 x float> %native.exp324, <8 x float> zeroinitializer
  %.spill.load361 = load i1, ptr %.spill69, align 1
  %.splatinsert362 = insertelement <8 x i1> poison, i1 %.spill.load361, i64 0
  %.splat363 = shufflevector <8 x i1> %.splatinsert362, <8 x i1> poison, <8 x i32> zeroinitializer
  %461 = select <8 x i1> %.splat363, <8 x float> %native.exp325, <8 x float> zeroinitializer
  %.spill.load364 = load i1, ptr %.spill70, align 1
  %.splatinsert365 = insertelement <8 x i1> poison, i1 %.spill.load364, i64 0
  %.splat366 = shufflevector <8 x i1> %.splatinsert365, <8 x i1> poison, <8 x i32> zeroinitializer
  %462 = select <8 x i1> %.splat366, <8 x float> %native.exp326, <8 x float> zeroinitializer
  %.spill.load367 = load i1, ptr %.spill71, align 1
  %.splatinsert368 = insertelement <8 x i1> poison, i1 %.spill.load367, i64 0
  %.splat369 = shufflevector <8 x i1> %.splatinsert368, <8 x i1> poison, <8 x i32> zeroinitializer
  %463 = select <8 x i1> %.splat369, <8 x float> %native.exp327, <8 x float> zeroinitializer
  %.spill.load370 = load i1, ptr %.spill72, align 1
  %.splatinsert371 = insertelement <8 x i1> poison, i1 %.spill.load370, i64 0
  %.splat372 = shufflevector <8 x i1> %.splatinsert371, <8 x i1> poison, <8 x i32> zeroinitializer
  %464 = select <8 x i1> %.splat372, <8 x float> %native.exp328, <8 x float> zeroinitializer
  %.spill.load373 = load i1, ptr %.spill73, align 1
  %.splatinsert374 = insertelement <8 x i1> poison, i1 %.spill.load373, i64 0
  %.splat375 = shufflevector <8 x i1> %.splatinsert374, <8 x i1> poison, <8 x i32> zeroinitializer
  %465 = select <8 x i1> %.splat375, <8 x float> %native.exp329, <8 x float> zeroinitializer
  %.spill.load376 = load i1, ptr %.spill74, align 1
  %.splatinsert377 = insertelement <8 x i1> poison, i1 %.spill.load376, i64 0
  %.splat378 = shufflevector <8 x i1> %.splatinsert377, <8 x i1> poison, <8 x i32> zeroinitializer
  %466 = select <8 x i1> %.splat378, <8 x float> %native.exp330, <8 x float> zeroinitializer
  %467 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %467, 0
  %470 = select <8 x i1> %80, <8 x ptr> %468, <8 x ptr> %469
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %467, 1
  %473 = select <8 x i1> %80, <8 x i64> %471, <8 x i64> %472
  %474 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %470, 0
  %475 = insertvalue { <8 x ptr>, <8 x i64> } %474, <8 x i64> %473, 1
  store { <8 x ptr>, <8 x i64> } %475, ptr %tile_snapshot.spill96, align 64
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %477 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %478 = add <8 x i64> %477, zeroinitializer
  %479 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %476, 0
  %480 = insertvalue { <8 x ptr>, <8 x i64> } %479, <8 x i64> %478, 1
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %480, 0
  %482 = extractvalue { <8 x ptr>, <8 x i64> } %480, 1
  %483 = getelementptr i8, <8 x ptr> %481, <8 x i64> %482
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %451, <8 x ptr> align 1 %483, <8 x i1> %80)
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %486 = add <8 x i64> %485, splat (i64 4)
  %487 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %484, 0
  %488 = insertvalue { <8 x ptr>, <8 x i64> } %487, <8 x i64> %486, 1
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %488, 0
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %488, 1
  %491 = getelementptr i8, <8 x ptr> %489, <8 x i64> %490
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %452, <8 x ptr> align 1 %491, <8 x i1> %80)
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %493 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %494 = add <8 x i64> %493, splat (i64 8)
  %495 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %492, 0
  %496 = insertvalue { <8 x ptr>, <8 x i64> } %495, <8 x i64> %494, 1
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %496, 0
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %496, 1
  %499 = getelementptr i8, <8 x ptr> %497, <8 x i64> %498
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %453, <8 x ptr> align 1 %499, <8 x i1> %80)
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %502 = add <8 x i64> %501, splat (i64 12)
  %503 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %500, 0
  %504 = insertvalue { <8 x ptr>, <8 x i64> } %503, <8 x i64> %502, 1
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %504, 0
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %504, 1
  %507 = getelementptr i8, <8 x ptr> %505, <8 x i64> %506
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %454, <8 x ptr> align 1 %507, <8 x i1> %80)
  %508 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %510 = add <8 x i64> %509, splat (i64 16)
  %511 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %508, 0
  %512 = insertvalue { <8 x ptr>, <8 x i64> } %511, <8 x i64> %510, 1
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %512, 0
  %514 = extractvalue { <8 x ptr>, <8 x i64> } %512, 1
  %515 = getelementptr i8, <8 x ptr> %513, <8 x i64> %514
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %455, <8 x ptr> align 1 %515, <8 x i1> %80)
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %518 = add <8 x i64> %517, splat (i64 20)
  %519 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %516, 0
  %520 = insertvalue { <8 x ptr>, <8 x i64> } %519, <8 x i64> %518, 1
  %521 = extractvalue { <8 x ptr>, <8 x i64> } %520, 0
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %520, 1
  %523 = getelementptr i8, <8 x ptr> %521, <8 x i64> %522
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %456, <8 x ptr> align 1 %523, <8 x i1> %80)
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %526 = add <8 x i64> %525, splat (i64 24)
  %527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %524, 0
  %528 = insertvalue { <8 x ptr>, <8 x i64> } %527, <8 x i64> %526, 1
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %528, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %528, 1
  %531 = getelementptr i8, <8 x ptr> %529, <8 x i64> %530
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %457, <8 x ptr> align 1 %531, <8 x i1> %80)
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %534 = add <8 x i64> %533, splat (i64 28)
  %535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %532, 0
  %536 = insertvalue { <8 x ptr>, <8 x i64> } %535, <8 x i64> %534, 1
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %536, 0
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %536, 1
  %539 = getelementptr i8, <8 x ptr> %537, <8 x i64> %538
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %458, <8 x ptr> align 1 %539, <8 x i1> %80)
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %542 = add <8 x i64> %541, splat (i64 32)
  %543 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %540, 0
  %544 = insertvalue { <8 x ptr>, <8 x i64> } %543, <8 x i64> %542, 1
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %544, 0
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %544, 1
  %547 = getelementptr i8, <8 x ptr> %545, <8 x i64> %546
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %459, <8 x ptr> align 1 %547, <8 x i1> %80)
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %550 = add <8 x i64> %549, splat (i64 36)
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %548, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %552, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = getelementptr i8, <8 x ptr> %553, <8 x i64> %554
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %460, <8 x ptr> align 1 %555, <8 x i1> %80)
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %557 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %558 = add <8 x i64> %557, splat (i64 40)
  %559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %556, 0
  %560 = insertvalue { <8 x ptr>, <8 x i64> } %559, <8 x i64> %558, 1
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %560, 0
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %560, 1
  %563 = getelementptr i8, <8 x ptr> %561, <8 x i64> %562
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %461, <8 x ptr> align 1 %563, <8 x i1> %80)
  %564 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %565 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %566 = add <8 x i64> %565, splat (i64 44)
  %567 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %564, 0
  %568 = insertvalue { <8 x ptr>, <8 x i64> } %567, <8 x i64> %566, 1
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %568, 0
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %568, 1
  %571 = getelementptr i8, <8 x ptr> %569, <8 x i64> %570
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %462, <8 x ptr> align 1 %571, <8 x i1> %80)
  %572 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %574 = add <8 x i64> %573, splat (i64 48)
  %575 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %572, 0
  %576 = insertvalue { <8 x ptr>, <8 x i64> } %575, <8 x i64> %574, 1
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %576, 0
  %578 = extractvalue { <8 x ptr>, <8 x i64> } %576, 1
  %579 = getelementptr i8, <8 x ptr> %577, <8 x i64> %578
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %463, <8 x ptr> align 1 %579, <8 x i1> %80)
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %582 = add <8 x i64> %581, splat (i64 52)
  %583 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %580, 0
  %584 = insertvalue { <8 x ptr>, <8 x i64> } %583, <8 x i64> %582, 1
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %584, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %584, 1
  %587 = getelementptr i8, <8 x ptr> %585, <8 x i64> %586
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %464, <8 x ptr> align 1 %587, <8 x i1> %80)
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %590 = add <8 x i64> %589, splat (i64 56)
  %591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %588, 0
  %592 = insertvalue { <8 x ptr>, <8 x i64> } %591, <8 x i64> %590, 1
  %593 = extractvalue { <8 x ptr>, <8 x i64> } %592, 0
  %594 = extractvalue { <8 x ptr>, <8 x i64> } %592, 1
  %595 = getelementptr i8, <8 x ptr> %593, <8 x i64> %594
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %465, <8 x ptr> align 1 %595, <8 x i1> %80)
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %597 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %598 = add <8 x i64> %597, splat (i64 60)
  %599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %596, 0
  %600 = insertvalue { <8 x ptr>, <8 x i64> } %599, <8 x i64> %598, 1
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %600, 0
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %600, 1
  %603 = getelementptr i8, <8 x ptr> %601, <8 x i64> %602
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %466, <8 x ptr> align 1 %603, <8 x i1> %80)
  %.state379 = load <8 x float>, ptr %.slot48, align 32
  %604 = fmul <8 x float> %.state379, %native.exp
  %605 = load <8 x float>, ptr %.spill97, align 32
  %606 = select <8 x i1> %80, <8 x float> %604, <8 x float> %605
  store <8 x float> %606, ptr %.spill97, align 32
  store i64 0, ptr %.slot98, align 4
  %607 = load <8 x float>, ptr %.slot99, align 32
  %608 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %607
  store <8 x float> %608, ptr %.slot99, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state380 = load i64, ptr %.slot98, align 4
  %609 = icmp slt i64 %.state380, 16
  br i1 %609, label %direct.true381, label %direct.false382

direct.schedule.23:                               ; preds = %direct.true381
  %.state383 = load i64, ptr %.slot98, align 4
  %610 = sdiv i64 %.state383, 1
  %.spill.load384 = load i64, ptr %.spill58, align 4
  %611 = mul i64 %.spill.load384, 1
  %612 = add i64 %611, 0
  %613 = mul i64 %612, 1
  %614 = add i64 %613, 0
  %615 = mul i64 %614, 16
  %616 = add i64 %615, %610
  %tile_snapshot.spill.load385 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load385, 0
  %618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load385, 1
  %.splatinsert386 = insertelement <8 x i64> poison, i64 %616, i64 0
  %.splat387 = shufflevector <8 x i64> %.splatinsert386, <8 x i64> poison, <8 x i32> zeroinitializer
  %619 = mul <8 x i64> %.splat387, splat (i64 4)
  %620 = add <8 x i64> %618, %619
  %621 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %617, 0
  %622 = insertvalue { <8 x ptr>, <8 x i64> } %621, <8 x i64> %620, 1
  %623 = extractvalue { <8 x ptr>, <8 x i64> } %622, 0
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %622, 1
  %625 = getelementptr i8, <8 x ptr> %623, <8 x i64> %624
  %626 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %625, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state388 = load <8 x float>, ptr %.slot99, align 32
  %627 = fadd <8 x float> %.state388, %626
  %.state389 = load i64, ptr %.slot98, align 4
  %628 = add i64 %.state389, 1
  store i64 %628, ptr %.slot98, align 4
  %629 = load <8 x float>, ptr %.slot99, align 32
  %630 = select <8 x i1> %80, <8 x float> %627, <8 x float> %629
  store <8 x float> %630, ptr %.slot99, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false382
  %.spill.load390 = load <8 x float>, ptr %.spill97, align 32
  %.state391 = load <8 x float>, ptr %.slot99, align 32
  %631 = fadd <8 x float> %.spill.load390, %.state391
  %632 = load <8 x float>, ptr %.spill100, align 32
  %633 = select <8 x i1> %80, <8 x float> %631, <8 x float> %632
  store <8 x float> %633, ptr %.spill100, align 32
  %634 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill101, align 64
  %635 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %634, 0
  %637 = select <8 x i1> %80, <8 x ptr> %635, <8 x ptr> %636
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %639 = extractvalue { <8 x ptr>, <8 x i64> } %634, 1
  %640 = select <8 x i1> %80, <8 x i64> %638, <8 x i64> %639
  %641 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %637, 0
  %642 = insertvalue { <8 x ptr>, <8 x i64> } %641, <8 x i64> %640, 1
  store { <8 x ptr>, <8 x i64> } %642, ptr %tile_snapshot.spill101, align 64
  store i64 0, ptr %.slot102, align 4
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state392 = load i64, ptr %.slot102, align 4
  %643 = icmp slt i64 %.state392, 128
  br i1 %643, label %direct.true393, label %direct.false394

direct.schedule.26:                               ; preds = %direct.true393
  %.state395 = load i64, ptr %.slot102, align 4
  %644 = add i64 0, %.state395
  %tile_snapshot.spill.load396 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %645 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load396, 0
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load396, 1
  %.splatinsert397 = insertelement <8 x i64> poison, i64 %644, i64 0
  %.splat398 = shufflevector <8 x i64> %.splatinsert397, <8 x i64> poison, <8 x i32> zeroinitializer
  %647 = mul <8 x i64> %.splat398, splat (i64 32)
  %648 = add <8 x i64> %646, %647
  %649 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %645, 0
  %650 = insertvalue { <8 x ptr>, <8 x i64> } %649, <8 x i64> %648, 1
  %651 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %650, 1
  %653 = extractelement <8 x ptr> %651, i32 0
  %654 = extractelement <8 x i64> %652, i32 0
  %655 = sub i64 %654, 0
  %656 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %657 = select i1 %656, i64 %655, i64 0
  %private.contiguous.address399 = getelementptr i8, ptr %653, i64 %657
  %private.contiguous.load400 = load <8 x float>, ptr %private.contiguous.address399, align 4
  %658 = select <8 x i1> %80, <8 x float> %private.contiguous.load400, <8 x float> zeroinitializer
  %.spill.load401 = load <8 x float>, ptr %.spill95, align 32
  %659 = fmul <8 x float> %658, %.spill.load401
  %tile_snapshot.spill.load402 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill101, align 64
  %660 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load402, 0
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load402, 1
  %.state403 = load i64, ptr %.slot102, align 4
  %.splatinsert404 = insertelement <8 x i64> poison, i64 %.state403, i64 0
  %.splat405 = shufflevector <8 x i64> %.splatinsert404, <8 x i64> poison, <8 x i32> zeroinitializer
  %662 = mul <8 x i64> %.splat405, splat (i64 4)
  %663 = add <8 x i64> %661, %662
  %664 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %660, 0
  %665 = insertvalue { <8 x ptr>, <8 x i64> } %664, <8 x i64> %663, 1
  %666 = extractvalue { <8 x ptr>, <8 x i64> } %665, 0
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %665, 1
  %668 = getelementptr i8, <8 x ptr> %666, <8 x i64> %667
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %659, <8 x ptr> align 1 %668, <8 x i1> %80)
  %.state406 = load i64, ptr %.slot102, align 4
  %669 = add i64 %.state406, 1
  store i64 %669, ptr %.slot102, align 4
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false394
  %670 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %671 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %670, 0
  %673 = select <8 x i1> %80, <8 x ptr> %671, <8 x ptr> %672
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %670, 1
  %676 = select <8 x i1> %80, <8 x i64> %674, <8 x i64> %675
  %677 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %673, 0
  %678 = insertvalue { <8 x ptr>, <8 x i64> } %677, <8 x i64> %676, 1
  store { <8 x ptr>, <8 x i64> } %678, ptr %tile_snapshot.spill103, align 64
  %tile_snapshot.spill.load407 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill96, align 64
  %tile_snapshot.spill.load408 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %tile_snapshot.spill.load409 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill101, align 64
  %679 = extractelement <8 x i1> %80, i64 0
  br i1 %679, label %mma.active410, label %mma.continue411

direct.schedule.28:                               ; preds = %mma.continue425, %direct.schedule.29
  %.state426 = load i64, ptr %.slot104, align 4
  %680 = icmp slt i64 %.state426, 128
  br i1 %680, label %direct.true427, label %direct.false428

direct.schedule.29:                               ; preds = %direct.true427
  %tile_snapshot.spill.load429 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load429, 0
  %682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load429, 1
  %.state430 = load i64, ptr %.slot104, align 4
  %.splatinsert431 = insertelement <8 x i64> poison, i64 %.state430, i64 0
  %.splat432 = shufflevector <8 x i64> %.splatinsert431, <8 x i64> poison, <8 x i32> zeroinitializer
  %683 = mul <8 x i64> %.splat432, splat (i64 4)
  %684 = add <8 x i64> %682, %683
  %685 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %681, 0
  %686 = insertvalue { <8 x ptr>, <8 x i64> } %685, <8 x i64> %684, 1
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %686, 0
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %686, 1
  %689 = getelementptr i8, <8 x ptr> %687, <8 x i64> %688
  %690 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %689, <8 x i1> %80, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load433 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load433, 0
  %692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load433, 1
  %.state434 = load i64, ptr %.slot104, align 4
  %.splatinsert435 = insertelement <8 x i64> poison, i64 %.state434, i64 0
  %.splat436 = shufflevector <8 x i64> %.splatinsert435, <8 x i64> poison, <8 x i32> zeroinitializer
  %693 = mul <8 x i64> %.splat436, splat (i64 32)
  %694 = add <8 x i64> %692, %693
  %695 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %691, 0
  %696 = insertvalue { <8 x ptr>, <8 x i64> } %695, <8 x i64> %694, 1
  %697 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %698 = extractvalue { <8 x ptr>, <8 x i64> } %696, 1
  %699 = extractelement <8 x ptr> %697, i32 0
  %700 = extractelement <8 x i64> %698, i32 0
  %701 = sub i64 %700, 0
  %702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %703 = select i1 %702, i64 %701, i64 0
  %private.contiguous.address437 = getelementptr i8, ptr %699, i64 %703
  %private.contiguous.preserve438 = load <8 x float>, ptr %private.contiguous.address437, align 4
  %704 = select <8 x i1> %80, <8 x float> %690, <8 x float> %private.contiguous.preserve438
  store <8 x float> %704, ptr %private.contiguous.address437, align 4
  %.state439 = load i64, ptr %.slot104, align 4
  %705 = add i64 %.state439, 1
  store i64 %705, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false428
  store i64 0, ptr %.slot105, align 4
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state440 = load i64, ptr %.slot105, align 4
  %706 = icmp slt i64 %.state440, 128
  br i1 %706, label %direct.true441, label %direct.false442

direct.schedule.32:                               ; preds = %direct.true441
  %tile_snapshot.spill.load443 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %707 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 0
  %708 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 1
  %.state444 = load i64, ptr %.slot105, align 4
  %.splatinsert445 = insertelement <8 x i64> poison, i64 %.state444, i64 0
  %.splat446 = shufflevector <8 x i64> %.splatinsert445, <8 x i64> poison, <8 x i32> zeroinitializer
  %709 = mul <8 x i64> %.splat446, splat (i64 32)
  %710 = add <8 x i64> %708, %709
  %711 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %707, 0
  %712 = insertvalue { <8 x ptr>, <8 x i64> } %711, <8 x i64> %710, 1
  %713 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %714 = extractvalue { <8 x ptr>, <8 x i64> } %712, 1
  %715 = extractelement <8 x ptr> %713, i32 0
  %716 = extractelement <8 x i64> %714, i32 0
  %717 = sub i64 %716, 0
  %718 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %719 = select i1 %718, i64 %717, i64 0
  %private.contiguous.address447 = getelementptr i8, ptr %715, i64 %719
  %private.contiguous.load448 = load <8 x float>, ptr %private.contiguous.address447, align 4
  %720 = select <8 x i1> %80, <8 x float> %private.contiguous.load448, <8 x float> zeroinitializer
  %tile_snapshot.spill.load449 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load449, 0
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load449, 1
  %.state450 = load i64, ptr %.slot105, align 4
  %.splatinsert451 = insertelement <8 x i64> poison, i64 %.state450, i64 0
  %.splat452 = shufflevector <8 x i64> %.splatinsert451, <8 x i64> poison, <8 x i32> zeroinitializer
  %723 = mul <8 x i64> %.splat452, splat (i64 32)
  %724 = add <8 x i64> %722, %723
  %725 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %721, 0
  %726 = insertvalue { <8 x ptr>, <8 x i64> } %725, <8 x i64> %724, 1
  %727 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %726, 1
  %729 = extractelement <8 x ptr> %727, i32 0
  %730 = extractelement <8 x i64> %728, i32 0
  %731 = sub i64 %730, 0
  %732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %733 = select i1 %732, i64 %731, i64 0
  %private.contiguous.address453 = getelementptr i8, ptr %729, i64 %733
  %private.contiguous.preserve454 = load <8 x float>, ptr %private.contiguous.address453, align 4
  %734 = select <8 x i1> %80, <8 x float> %720, <8 x float> %private.contiguous.preserve454
  store <8 x float> %734, ptr %private.contiguous.address453, align 4
  %.state455 = load i64, ptr %.slot105, align 4
  %735 = add i64 %.state455, 1
  store i64 %735, ptr %.slot105, align 4
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false442
  %.state456 = load i64, ptr %.slot46, align 4
  %736 = add i64 %.state456, 1
  %.spill.load457 = load <8 x float>, ptr %.spill94, align 32
  %.spill.load458 = load <8 x float>, ptr %.spill100, align 32
  store i64 %736, ptr %.slot46, align 4
  %737 = load <8 x float>, ptr %.slot47, align 32
  %738 = select <8 x i1> %80, <8 x float> %.spill.load457, <8 x float> %737
  store <8 x float> %738, ptr %.slot47, align 32
  %739 = load <8 x float>, ptr %.slot48, align 32
  %740 = select <8 x i1> %80, <8 x float> %.spill.load458, <8 x float> %739
  store <8 x float> %740, ptr %.slot48, align 32
  br label %direct.schedule.7

direct.schedule.34:                               ; preds = %direct.false140
  store i64 0, ptr %.slot106, align 4
  br label %direct.schedule.35

direct.schedule.35:                               ; preds = %direct.schedule.36, %direct.schedule.34
  %.state459 = load i64, ptr %.slot106, align 4
  %741 = icmp slt i64 %.state459, 128
  br i1 %741, label %direct.true460, label %direct.false461

direct.schedule.36:                               ; preds = %direct.true460
  %.spill.load462 = load i64, ptr %.spill41, align 4
  %742 = add i64 %.spill.load462, 0
  %.spill.load463 = load <8 x i64>, ptr %.spill, align 64
  %743 = add <8 x i64> %.spill.load463, zeroinitializer
  %744 = mul i64 %742, 16
  %.splatinsert464 = insertelement <8 x i64> poison, i64 %744, i64 0
  %.splat465 = shufflevector <8 x i64> %.splatinsert464, <8 x i64> poison, <8 x i32> zeroinitializer
  %745 = add <8 x i64> %.splat465, %743
  %.spill.load466 = load i64, ptr %.spill41, align 4
  %746 = add i64 %.spill.load466, 0
  %747 = mul <8 x i64> %745, splat (i64 1)
  %.splatinsert467 = insertelement <8 x i64> poison, i64 %746, i64 0
  %.splat468 = shufflevector <8 x i64> %.splatinsert467, <8 x i64> poison, <8 x i32> zeroinitializer
  %748 = add <8 x i64> %747, %.splat468
  %.state469 = load i64, ptr %.slot106, align 4
  %749 = add i64 0, %.state469
  %750 = mul <8 x i64> %748, splat (i64 128)
  %.splatinsert470 = insertelement <8 x i64> poison, i64 %749, i64 0
  %.splat471 = shufflevector <8 x i64> %.splatinsert470, <8 x i64> poison, <8 x i32> zeroinitializer
  %751 = add <8 x i64> %750, %.splat471
  %.state472 = load i64, ptr %.slot106, align 4
  %752 = add i64 0, %.state472
  %tile_snapshot.spill.load473 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill43, align 64
  %753 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load473, 0
  %754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load473, 1
  %.splatinsert474 = insertelement <8 x i64> poison, i64 %752, i64 0
  %.splat475 = shufflevector <8 x i64> %.splatinsert474, <8 x i64> poison, <8 x i32> zeroinitializer
  %755 = mul <8 x i64> %.splat475, splat (i64 32)
  %756 = add <8 x i64> %754, %755
  %757 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %753, 0
  %758 = insertvalue { <8 x ptr>, <8 x i64> } %757, <8 x i64> %756, 1
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %758, 1
  %761 = extractelement <8 x ptr> %759, i32 0
  %762 = extractelement <8 x i64> %760, i32 0
  %763 = sub i64 %762, 0
  %764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %765 = select i1 %764, i64 %763, i64 0
  %private.contiguous.address476 = getelementptr i8, ptr %761, i64 %765
  %private.contiguous.load477 = load <8 x float>, ptr %private.contiguous.address476, align 4
  %766 = select <8 x i1> %80, <8 x float> %private.contiguous.load477, <8 x float> zeroinitializer
  %.state478 = load <8 x float>, ptr %.slot48, align 32
  %767 = fdiv <8 x float> %766, %.state478
  %768 = extractvalue { ptr, i64 } %56, 0
  %769 = mul <8 x i64> %751, splat (i64 4)
  %770 = getelementptr i8, ptr %768, <8 x i64> %769
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %767, <8 x ptr> align 1 %770, <8 x i1> %80)
  %.state479 = load i64, ptr %.slot106, align 4
  %771 = add i64 %.state479, 1
  store i64 %771, ptr %.slot106, align 4
  br label %direct.schedule.35

direct.schedule.37:                               ; preds = %direct.false461
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true131:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false132:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true139:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false140:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.34

direct.true143:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false144:                                  ; preds = %direct.schedule.9
  br label %direct.schedule.13

direct.true156:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false157:                                  ; preds = %direct.schedule.10
  %772 = load <8 x float>, ptr %.slot53, align 32
  %773 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %772
  store <8 x float> %773, ptr %.slot53, align 32
  br label %direct.schedule.12

direct.true166:                                   ; preds = %direct.schedule.14
  br label %direct.schedule.15

direct.false167:                                  ; preds = %direct.schedule.14
  br label %direct.schedule.18

direct.true179:                                   ; preds = %direct.schedule.15
  br label %direct.schedule.16

direct.false180:                                  ; preds = %direct.schedule.15
  %774 = load <8 x float>, ptr %.slot57, align 32
  %775 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %774
  store <8 x float> %775, ptr %.slot57, align 32
  br label %direct.schedule.17

mma.active:                                       ; preds = %direct.schedule.18
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %777 = extractelement <8 x ptr> %776, i64 0
  %778 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %779 = extractelement <8 x i64> %778, i64 0
  %780 = getelementptr i8, ptr %777, i64 %779
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %782 = extractelement <8 x ptr> %781, i64 0
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %784 = extractelement <8 x i64> %783, i64 0
  %785 = getelementptr i8, ptr %782, i64 %784
  %786 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %787 = extractelement <8 x ptr> %786, i64 0
  %788 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %789 = extractelement <8 x i64> %788, i64 0
  %790 = getelementptr i8, ptr %787, i64 %789
  %791 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %792 = extractelement <8 x ptr> %791, i64 0
  %793 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %794 = extractelement <8 x i64> %793, i64 0
  %795 = getelementptr i8, ptr %792, i64 %794
  call void @llm_attention.strided_mma(ptr %780, ptr %785, ptr %790, ptr %795)
  br label %mma.continue

mma.continue:                                     ; preds = %mma.active, %direct.schedule.18
  %796 = extractelement <8 x i1> %80, i64 1
  br i1 %796, label %mma.active190, label %mma.continue191

mma.active190:                                    ; preds = %mma.continue
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %798 = extractelement <8 x ptr> %797, i64 1
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %800 = extractelement <8 x i64> %799, i64 1
  %801 = getelementptr i8, ptr %798, i64 %800
  %802 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %803 = extractelement <8 x ptr> %802, i64 1
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %805 = extractelement <8 x i64> %804, i64 1
  %806 = getelementptr i8, ptr %803, i64 %805
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %808 = extractelement <8 x ptr> %807, i64 1
  %809 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %810 = extractelement <8 x i64> %809, i64 1
  %811 = getelementptr i8, ptr %808, i64 %810
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %813 = extractelement <8 x ptr> %812, i64 1
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %815 = extractelement <8 x i64> %814, i64 1
  %816 = getelementptr i8, ptr %813, i64 %815
  call void @llm_attention.strided_mma(ptr %801, ptr %806, ptr %811, ptr %816)
  br label %mma.continue191

mma.continue191:                                  ; preds = %mma.active190, %mma.continue
  %817 = extractelement <8 x i1> %80, i64 2
  br i1 %817, label %mma.active192, label %mma.continue193

mma.active192:                                    ; preds = %mma.continue191
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %819 = extractelement <8 x ptr> %818, i64 2
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %821 = extractelement <8 x i64> %820, i64 2
  %822 = getelementptr i8, ptr %819, i64 %821
  %823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %824 = extractelement <8 x ptr> %823, i64 2
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %826 = extractelement <8 x i64> %825, i64 2
  %827 = getelementptr i8, ptr %824, i64 %826
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %829 = extractelement <8 x ptr> %828, i64 2
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %831 = extractelement <8 x i64> %830, i64 2
  %832 = getelementptr i8, ptr %829, i64 %831
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %834 = extractelement <8 x ptr> %833, i64 2
  %835 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %836 = extractelement <8 x i64> %835, i64 2
  %837 = getelementptr i8, ptr %834, i64 %836
  call void @llm_attention.strided_mma(ptr %822, ptr %827, ptr %832, ptr %837)
  br label %mma.continue193

mma.continue193:                                  ; preds = %mma.active192, %mma.continue191
  %838 = extractelement <8 x i1> %80, i64 3
  br i1 %838, label %mma.active194, label %mma.continue195

mma.active194:                                    ; preds = %mma.continue193
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %840 = extractelement <8 x ptr> %839, i64 3
  %841 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %842 = extractelement <8 x i64> %841, i64 3
  %843 = getelementptr i8, ptr %840, i64 %842
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %845 = extractelement <8 x ptr> %844, i64 3
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %847 = extractelement <8 x i64> %846, i64 3
  %848 = getelementptr i8, ptr %845, i64 %847
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %850 = extractelement <8 x ptr> %849, i64 3
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %852 = extractelement <8 x i64> %851, i64 3
  %853 = getelementptr i8, ptr %850, i64 %852
  %854 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %855 = extractelement <8 x ptr> %854, i64 3
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %857 = extractelement <8 x i64> %856, i64 3
  %858 = getelementptr i8, ptr %855, i64 %857
  call void @llm_attention.strided_mma(ptr %843, ptr %848, ptr %853, ptr %858)
  br label %mma.continue195

mma.continue195:                                  ; preds = %mma.active194, %mma.continue193
  %859 = extractelement <8 x i1> %80, i64 4
  br i1 %859, label %mma.active196, label %mma.continue197

mma.active196:                                    ; preds = %mma.continue195
  %860 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %861 = extractelement <8 x ptr> %860, i64 4
  %862 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %863 = extractelement <8 x i64> %862, i64 4
  %864 = getelementptr i8, ptr %861, i64 %863
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %866 = extractelement <8 x ptr> %865, i64 4
  %867 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %868 = extractelement <8 x i64> %867, i64 4
  %869 = getelementptr i8, ptr %866, i64 %868
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %871 = extractelement <8 x ptr> %870, i64 4
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %873 = extractelement <8 x i64> %872, i64 4
  %874 = getelementptr i8, ptr %871, i64 %873
  %875 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %876 = extractelement <8 x ptr> %875, i64 4
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %878 = extractelement <8 x i64> %877, i64 4
  %879 = getelementptr i8, ptr %876, i64 %878
  call void @llm_attention.strided_mma(ptr %864, ptr %869, ptr %874, ptr %879)
  br label %mma.continue197

mma.continue197:                                  ; preds = %mma.active196, %mma.continue195
  %880 = extractelement <8 x i1> %80, i64 5
  br i1 %880, label %mma.active198, label %mma.continue199

mma.active198:                                    ; preds = %mma.continue197
  %881 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %882 = extractelement <8 x ptr> %881, i64 5
  %883 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %884 = extractelement <8 x i64> %883, i64 5
  %885 = getelementptr i8, ptr %882, i64 %884
  %886 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %887 = extractelement <8 x ptr> %886, i64 5
  %888 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %889 = extractelement <8 x i64> %888, i64 5
  %890 = getelementptr i8, ptr %887, i64 %889
  %891 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %892 = extractelement <8 x ptr> %891, i64 5
  %893 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %894 = extractelement <8 x i64> %893, i64 5
  %895 = getelementptr i8, ptr %892, i64 %894
  %896 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %897 = extractelement <8 x ptr> %896, i64 5
  %898 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %899 = extractelement <8 x i64> %898, i64 5
  %900 = getelementptr i8, ptr %897, i64 %899
  call void @llm_attention.strided_mma(ptr %885, ptr %890, ptr %895, ptr %900)
  br label %mma.continue199

mma.continue199:                                  ; preds = %mma.active198, %mma.continue197
  %901 = extractelement <8 x i1> %80, i64 6
  br i1 %901, label %mma.active200, label %mma.continue201

mma.active200:                                    ; preds = %mma.continue199
  %902 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %903 = extractelement <8 x ptr> %902, i64 6
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %905 = extractelement <8 x i64> %904, i64 6
  %906 = getelementptr i8, ptr %903, i64 %905
  %907 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %908 = extractelement <8 x ptr> %907, i64 6
  %909 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %910 = extractelement <8 x i64> %909, i64 6
  %911 = getelementptr i8, ptr %908, i64 %910
  %912 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %913 = extractelement <8 x ptr> %912, i64 6
  %914 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %915 = extractelement <8 x i64> %914, i64 6
  %916 = getelementptr i8, ptr %913, i64 %915
  %917 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %918 = extractelement <8 x ptr> %917, i64 6
  %919 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %920 = extractelement <8 x i64> %919, i64 6
  %921 = getelementptr i8, ptr %918, i64 %920
  call void @llm_attention.strided_mma(ptr %906, ptr %911, ptr %916, ptr %921)
  br label %mma.continue201

mma.continue201:                                  ; preds = %mma.active200, %mma.continue199
  %922 = extractelement <8 x i1> %80, i64 7
  br i1 %922, label %mma.active202, label %mma.continue203

mma.active202:                                    ; preds = %mma.continue201
  %923 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 0
  %924 = extractelement <8 x ptr> %923, i64 7
  %925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load188, 1
  %926 = extractelement <8 x i64> %925, i64 7
  %927 = getelementptr i8, ptr %924, i64 %926
  %928 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %929 = extractelement <8 x ptr> %928, i64 7
  %930 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %931 = extractelement <8 x i64> %930, i64 7
  %932 = getelementptr i8, ptr %929, i64 %931
  %933 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %934 = extractelement <8 x ptr> %933, i64 7
  %935 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %936 = extractelement <8 x i64> %935, i64 7
  %937 = getelementptr i8, ptr %934, i64 %936
  %938 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %939 = extractelement <8 x ptr> %938, i64 7
  %940 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %941 = extractelement <8 x i64> %940, i64 7
  %942 = getelementptr i8, ptr %939, i64 %941
  call void @llm_attention.strided_mma(ptr %927, ptr %932, ptr %937, ptr %942)
  br label %mma.continue203

mma.continue203:                                  ; preds = %mma.active202, %mma.continue201
  %943 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %944 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %945 = add <8 x i64> %944, zeroinitializer
  %946 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %943, 0
  %947 = insertvalue { <8 x ptr>, <8 x i64> } %946, <8 x i64> %945, 1
  %948 = extractvalue { <8 x ptr>, <8 x i64> } %947, 0
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %947, 1
  %950 = getelementptr i8, <8 x ptr> %948, <8 x i64> %949
  %951 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %950, <8 x i1> %80, <8 x float> zeroinitializer)
  %952 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %953 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %954 = add <8 x i64> %953, splat (i64 4)
  %955 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %952, 0
  %956 = insertvalue { <8 x ptr>, <8 x i64> } %955, <8 x i64> %954, 1
  %957 = extractvalue { <8 x ptr>, <8 x i64> } %956, 0
  %958 = extractvalue { <8 x ptr>, <8 x i64> } %956, 1
  %959 = getelementptr i8, <8 x ptr> %957, <8 x i64> %958
  %960 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %959, <8 x i1> %80, <8 x float> zeroinitializer)
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %962 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %963 = add <8 x i64> %962, splat (i64 8)
  %964 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %961, 0
  %965 = insertvalue { <8 x ptr>, <8 x i64> } %964, <8 x i64> %963, 1
  %966 = extractvalue { <8 x ptr>, <8 x i64> } %965, 0
  %967 = extractvalue { <8 x ptr>, <8 x i64> } %965, 1
  %968 = getelementptr i8, <8 x ptr> %966, <8 x i64> %967
  %969 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %968, <8 x i1> %80, <8 x float> zeroinitializer)
  %970 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %971 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %972 = add <8 x i64> %971, splat (i64 12)
  %973 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %970, 0
  %974 = insertvalue { <8 x ptr>, <8 x i64> } %973, <8 x i64> %972, 1
  %975 = extractvalue { <8 x ptr>, <8 x i64> } %974, 0
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %974, 1
  %977 = getelementptr i8, <8 x ptr> %975, <8 x i64> %976
  %978 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %977, <8 x i1> %80, <8 x float> zeroinitializer)
  %979 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %980 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %981 = add <8 x i64> %980, splat (i64 16)
  %982 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %979, 0
  %983 = insertvalue { <8 x ptr>, <8 x i64> } %982, <8 x i64> %981, 1
  %984 = extractvalue { <8 x ptr>, <8 x i64> } %983, 0
  %985 = extractvalue { <8 x ptr>, <8 x i64> } %983, 1
  %986 = getelementptr i8, <8 x ptr> %984, <8 x i64> %985
  %987 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %986, <8 x i1> %80, <8 x float> zeroinitializer)
  %988 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %989 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %990 = add <8 x i64> %989, splat (i64 20)
  %991 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %988, 0
  %992 = insertvalue { <8 x ptr>, <8 x i64> } %991, <8 x i64> %990, 1
  %993 = extractvalue { <8 x ptr>, <8 x i64> } %992, 0
  %994 = extractvalue { <8 x ptr>, <8 x i64> } %992, 1
  %995 = getelementptr i8, <8 x ptr> %993, <8 x i64> %994
  %996 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %995, <8 x i1> %80, <8 x float> zeroinitializer)
  %997 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %999 = add <8 x i64> %998, splat (i64 24)
  %1000 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %997, 0
  %1001 = insertvalue { <8 x ptr>, <8 x i64> } %1000, <8 x i64> %999, 1
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 0
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %1001, 1
  %1004 = getelementptr i8, <8 x ptr> %1002, <8 x i64> %1003
  %1005 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1004, <8 x i1> %80, <8 x float> zeroinitializer)
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1007 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1008 = add <8 x i64> %1007, splat (i64 28)
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1006, 0
  %1010 = insertvalue { <8 x ptr>, <8 x i64> } %1009, <8 x i64> %1008, 1
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %1010, 0
  %1012 = extractvalue { <8 x ptr>, <8 x i64> } %1010, 1
  %1013 = getelementptr i8, <8 x ptr> %1011, <8 x i64> %1012
  %1014 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1013, <8 x i1> %80, <8 x float> zeroinitializer)
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1017 = add <8 x i64> %1016, splat (i64 32)
  %1018 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1015, 0
  %1019 = insertvalue { <8 x ptr>, <8 x i64> } %1018, <8 x i64> %1017, 1
  %1020 = extractvalue { <8 x ptr>, <8 x i64> } %1019, 0
  %1021 = extractvalue { <8 x ptr>, <8 x i64> } %1019, 1
  %1022 = getelementptr i8, <8 x ptr> %1020, <8 x i64> %1021
  %1023 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1022, <8 x i1> %80, <8 x float> zeroinitializer)
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1025 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1026 = add <8 x i64> %1025, splat (i64 36)
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1024, 0
  %1028 = insertvalue { <8 x ptr>, <8 x i64> } %1027, <8 x i64> %1026, 1
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1028, 0
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %1028, 1
  %1031 = getelementptr i8, <8 x ptr> %1029, <8 x i64> %1030
  %1032 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1031, <8 x i1> %80, <8 x float> zeroinitializer)
  %1033 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1034 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1035 = add <8 x i64> %1034, splat (i64 40)
  %1036 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1033, 0
  %1037 = insertvalue { <8 x ptr>, <8 x i64> } %1036, <8 x i64> %1035, 1
  %1038 = extractvalue { <8 x ptr>, <8 x i64> } %1037, 0
  %1039 = extractvalue { <8 x ptr>, <8 x i64> } %1037, 1
  %1040 = getelementptr i8, <8 x ptr> %1038, <8 x i64> %1039
  %1041 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1040, <8 x i1> %80, <8 x float> zeroinitializer)
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1043 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1044 = add <8 x i64> %1043, splat (i64 44)
  %1045 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1042, 0
  %1046 = insertvalue { <8 x ptr>, <8 x i64> } %1045, <8 x i64> %1044, 1
  %1047 = extractvalue { <8 x ptr>, <8 x i64> } %1046, 0
  %1048 = extractvalue { <8 x ptr>, <8 x i64> } %1046, 1
  %1049 = getelementptr i8, <8 x ptr> %1047, <8 x i64> %1048
  %1050 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1049, <8 x i1> %80, <8 x float> zeroinitializer)
  %1051 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1052 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1053 = add <8 x i64> %1052, splat (i64 48)
  %1054 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1051, 0
  %1055 = insertvalue { <8 x ptr>, <8 x i64> } %1054, <8 x i64> %1053, 1
  %1056 = extractvalue { <8 x ptr>, <8 x i64> } %1055, 0
  %1057 = extractvalue { <8 x ptr>, <8 x i64> } %1055, 1
  %1058 = getelementptr i8, <8 x ptr> %1056, <8 x i64> %1057
  %1059 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1058, <8 x i1> %80, <8 x float> zeroinitializer)
  %1060 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1062 = add <8 x i64> %1061, splat (i64 52)
  %1063 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1060, 0
  %1064 = insertvalue { <8 x ptr>, <8 x i64> } %1063, <8 x i64> %1062, 1
  %1065 = extractvalue { <8 x ptr>, <8 x i64> } %1064, 0
  %1066 = extractvalue { <8 x ptr>, <8 x i64> } %1064, 1
  %1067 = getelementptr i8, <8 x ptr> %1065, <8 x i64> %1066
  %1068 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1067, <8 x i1> %80, <8 x float> zeroinitializer)
  %1069 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1070 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1071 = add <8 x i64> %1070, splat (i64 56)
  %1072 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1069, 0
  %1073 = insertvalue { <8 x ptr>, <8 x i64> } %1072, <8 x i64> %1071, 1
  %1074 = extractvalue { <8 x ptr>, <8 x i64> } %1073, 0
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %1073, 1
  %1076 = getelementptr i8, <8 x ptr> %1074, <8 x i64> %1075
  %1077 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1076, <8 x i1> %80, <8 x float> zeroinitializer)
  %1078 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1079 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1080 = add <8 x i64> %1079, splat (i64 60)
  %1081 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1078, 0
  %1082 = insertvalue { <8 x ptr>, <8 x i64> } %1081, <8 x i64> %1080, 1
  %1083 = extractvalue { <8 x ptr>, <8 x i64> } %1082, 0
  %1084 = extractvalue { <8 x ptr>, <8 x i64> } %1082, 1
  %1085 = getelementptr i8, <8 x ptr> %1083, <8 x i64> %1084
  %1086 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1085, <8 x i1> %80, <8 x float> zeroinitializer)
  %1087 = fmul <8 x float> %951, splat (float 0x3FB6A09E60000000)
  %1088 = fmul <8 x float> %960, splat (float 0x3FB6A09E60000000)
  %1089 = fmul <8 x float> %969, splat (float 0x3FB6A09E60000000)
  %1090 = fmul <8 x float> %978, splat (float 0x3FB6A09E60000000)
  %1091 = fmul <8 x float> %987, splat (float 0x3FB6A09E60000000)
  %1092 = fmul <8 x float> %996, splat (float 0x3FB6A09E60000000)
  %1093 = fmul <8 x float> %1005, splat (float 0x3FB6A09E60000000)
  %1094 = fmul <8 x float> %1014, splat (float 0x3FB6A09E60000000)
  %1095 = fmul <8 x float> %1023, splat (float 0x3FB6A09E60000000)
  %1096 = fmul <8 x float> %1032, splat (float 0x3FB6A09E60000000)
  %1097 = fmul <8 x float> %1041, splat (float 0x3FB6A09E60000000)
  %1098 = fmul <8 x float> %1050, splat (float 0x3FB6A09E60000000)
  %1099 = fmul <8 x float> %1059, splat (float 0x3FB6A09E60000000)
  %1100 = fmul <8 x float> %1068, splat (float 0x3FB6A09E60000000)
  %1101 = fmul <8 x float> %1077, splat (float 0x3FB6A09E60000000)
  %1102 = fmul <8 x float> %1086, splat (float 0x3FB6A09E60000000)
  %.spill.load204 = load i64, ptr %.spill49, align 4
  %1103 = add i64 0, %.spill.load204
  %.spill.load205 = load i64, ptr %.spill49, align 4
  %1104 = add i64 1, %.spill.load205
  %.spill.load206 = load i64, ptr %.spill49, align 4
  %1105 = add i64 2, %.spill.load206
  %.spill.load207 = load i64, ptr %.spill49, align 4
  %1106 = add i64 3, %.spill.load207
  %.spill.load208 = load i64, ptr %.spill49, align 4
  %1107 = add i64 4, %.spill.load208
  %.spill.load209 = load i64, ptr %.spill49, align 4
  %1108 = add i64 5, %.spill.load209
  %.spill.load210 = load i64, ptr %.spill49, align 4
  %1109 = add i64 6, %.spill.load210
  %.spill.load211 = load i64, ptr %.spill49, align 4
  %1110 = add i64 7, %.spill.load211
  %.spill.load212 = load i64, ptr %.spill49, align 4
  %1111 = add i64 8, %.spill.load212
  %.spill.load213 = load i64, ptr %.spill49, align 4
  %1112 = add i64 9, %.spill.load213
  %.spill.load214 = load i64, ptr %.spill49, align 4
  %1113 = add i64 10, %.spill.load214
  %.spill.load215 = load i64, ptr %.spill49, align 4
  %1114 = add i64 11, %.spill.load215
  %.spill.load216 = load i64, ptr %.spill49, align 4
  %1115 = add i64 12, %.spill.load216
  %.spill.load217 = load i64, ptr %.spill49, align 4
  %1116 = add i64 13, %.spill.load217
  %.spill.load218 = load i64, ptr %.spill49, align 4
  %1117 = add i64 14, %.spill.load218
  %.spill.load219 = load i64, ptr %.spill49, align 4
  %1118 = add i64 15, %.spill.load219
  %1119 = icmp slt i64 %1103, 8193
  %1120 = icmp slt i64 %1104, 8193
  %1121 = icmp slt i64 %1105, 8193
  %1122 = icmp slt i64 %1106, 8193
  %1123 = icmp slt i64 %1107, 8193
  %1124 = icmp slt i64 %1108, 8193
  %1125 = icmp slt i64 %1109, 8193
  %1126 = icmp slt i64 %1110, 8193
  %1127 = icmp slt i64 %1111, 8193
  %1128 = icmp slt i64 %1112, 8193
  %1129 = icmp slt i64 %1113, 8193
  %1130 = icmp slt i64 %1114, 8193
  %1131 = icmp slt i64 %1115, 8193
  %1132 = icmp slt i64 %1116, 8193
  %1133 = icmp slt i64 %1117, 8193
  %1134 = icmp slt i64 %1118, 8193
  %.spill.load220 = load i64, ptr %.spill41, align 4
  %1135 = add i64 0, %.spill.load220
  store i64 %1135, ptr %.spill58, align 4
  %1136 = add i64 %1135, 8193
  %1137 = sub i64 %1136, 1
  %1138 = icmp sle i64 %1103, %1137
  %1139 = icmp sle i64 %1104, %1137
  %1140 = icmp sle i64 %1105, %1137
  %1141 = icmp sle i64 %1106, %1137
  %1142 = icmp sle i64 %1107, %1137
  %1143 = icmp sle i64 %1108, %1137
  %1144 = icmp sle i64 %1109, %1137
  %1145 = icmp sle i64 %1110, %1137
  %1146 = icmp sle i64 %1111, %1137
  %1147 = icmp sle i64 %1112, %1137
  %1148 = icmp sle i64 %1113, %1137
  %1149 = icmp sle i64 %1114, %1137
  %1150 = icmp sle i64 %1115, %1137
  %1151 = icmp sle i64 %1116, %1137
  %1152 = icmp sle i64 %1117, %1137
  %1153 = icmp sle i64 %1118, %1137
  %1154 = and i1 %1119, %1138
  store i1 %1154, ptr %.spill59, align 1
  %1155 = and i1 %1120, %1139
  store i1 %1155, ptr %.spill60, align 1
  %1156 = and i1 %1121, %1140
  store i1 %1156, ptr %.spill61, align 1
  %1157 = and i1 %1122, %1141
  store i1 %1157, ptr %.spill62, align 1
  %1158 = and i1 %1123, %1142
  store i1 %1158, ptr %.spill63, align 1
  %1159 = and i1 %1124, %1143
  store i1 %1159, ptr %.spill64, align 1
  %1160 = and i1 %1125, %1144
  store i1 %1160, ptr %.spill65, align 1
  %1161 = and i1 %1126, %1145
  store i1 %1161, ptr %.spill66, align 1
  %1162 = and i1 %1127, %1146
  store i1 %1162, ptr %.spill67, align 1
  %1163 = and i1 %1128, %1147
  store i1 %1163, ptr %.spill68, align 1
  %1164 = and i1 %1129, %1148
  store i1 %1164, ptr %.spill69, align 1
  %1165 = and i1 %1130, %1149
  store i1 %1165, ptr %.spill70, align 1
  %1166 = and i1 %1131, %1150
  store i1 %1166, ptr %.spill71, align 1
  %1167 = and i1 %1132, %1151
  store i1 %1167, ptr %.spill72, align 1
  %1168 = and i1 %1133, %1152
  store i1 %1168, ptr %.spill73, align 1
  %1169 = and i1 %1134, %1153
  store i1 %1169, ptr %.spill74, align 1
  %.splatinsert221 = insertelement <8 x i1> poison, i1 %1154, i64 0
  %.splat222 = shufflevector <8 x i1> %.splatinsert221, <8 x i1> poison, <8 x i32> zeroinitializer
  %1170 = select <8 x i1> %.splat222, <8 x float> %1087, <8 x float> splat (float 0xC6293E5940000000)
  %1171 = load <8 x float>, ptr %.spill75, align 32
  %1172 = select <8 x i1> %80, <8 x float> %1170, <8 x float> %1171
  store <8 x float> %1172, ptr %.spill75, align 32
  %.splatinsert223 = insertelement <8 x i1> poison, i1 %1155, i64 0
  %.splat224 = shufflevector <8 x i1> %.splatinsert223, <8 x i1> poison, <8 x i32> zeroinitializer
  %1173 = select <8 x i1> %.splat224, <8 x float> %1088, <8 x float> splat (float 0xC6293E5940000000)
  %1174 = load <8 x float>, ptr %.spill76, align 32
  %1175 = select <8 x i1> %80, <8 x float> %1173, <8 x float> %1174
  store <8 x float> %1175, ptr %.spill76, align 32
  %.splatinsert225 = insertelement <8 x i1> poison, i1 %1156, i64 0
  %.splat226 = shufflevector <8 x i1> %.splatinsert225, <8 x i1> poison, <8 x i32> zeroinitializer
  %1176 = select <8 x i1> %.splat226, <8 x float> %1089, <8 x float> splat (float 0xC6293E5940000000)
  %1177 = load <8 x float>, ptr %.spill77, align 32
  %1178 = select <8 x i1> %80, <8 x float> %1176, <8 x float> %1177
  store <8 x float> %1178, ptr %.spill77, align 32
  %.splatinsert227 = insertelement <8 x i1> poison, i1 %1157, i64 0
  %.splat228 = shufflevector <8 x i1> %.splatinsert227, <8 x i1> poison, <8 x i32> zeroinitializer
  %1179 = select <8 x i1> %.splat228, <8 x float> %1090, <8 x float> splat (float 0xC6293E5940000000)
  %1180 = load <8 x float>, ptr %.spill78, align 32
  %1181 = select <8 x i1> %80, <8 x float> %1179, <8 x float> %1180
  store <8 x float> %1181, ptr %.spill78, align 32
  %.splatinsert229 = insertelement <8 x i1> poison, i1 %1158, i64 0
  %.splat230 = shufflevector <8 x i1> %.splatinsert229, <8 x i1> poison, <8 x i32> zeroinitializer
  %1182 = select <8 x i1> %.splat230, <8 x float> %1091, <8 x float> splat (float 0xC6293E5940000000)
  %1183 = load <8 x float>, ptr %.spill79, align 32
  %1184 = select <8 x i1> %80, <8 x float> %1182, <8 x float> %1183
  store <8 x float> %1184, ptr %.spill79, align 32
  %.splatinsert231 = insertelement <8 x i1> poison, i1 %1159, i64 0
  %.splat232 = shufflevector <8 x i1> %.splatinsert231, <8 x i1> poison, <8 x i32> zeroinitializer
  %1185 = select <8 x i1> %.splat232, <8 x float> %1092, <8 x float> splat (float 0xC6293E5940000000)
  %1186 = load <8 x float>, ptr %.spill80, align 32
  %1187 = select <8 x i1> %80, <8 x float> %1185, <8 x float> %1186
  store <8 x float> %1187, ptr %.spill80, align 32
  %.splatinsert233 = insertelement <8 x i1> poison, i1 %1160, i64 0
  %.splat234 = shufflevector <8 x i1> %.splatinsert233, <8 x i1> poison, <8 x i32> zeroinitializer
  %1188 = select <8 x i1> %.splat234, <8 x float> %1093, <8 x float> splat (float 0xC6293E5940000000)
  %1189 = load <8 x float>, ptr %.spill81, align 32
  %1190 = select <8 x i1> %80, <8 x float> %1188, <8 x float> %1189
  store <8 x float> %1190, ptr %.spill81, align 32
  %.splatinsert235 = insertelement <8 x i1> poison, i1 %1161, i64 0
  %.splat236 = shufflevector <8 x i1> %.splatinsert235, <8 x i1> poison, <8 x i32> zeroinitializer
  %1191 = select <8 x i1> %.splat236, <8 x float> %1094, <8 x float> splat (float 0xC6293E5940000000)
  %1192 = load <8 x float>, ptr %.spill82, align 32
  %1193 = select <8 x i1> %80, <8 x float> %1191, <8 x float> %1192
  store <8 x float> %1193, ptr %.spill82, align 32
  %.splatinsert237 = insertelement <8 x i1> poison, i1 %1162, i64 0
  %.splat238 = shufflevector <8 x i1> %.splatinsert237, <8 x i1> poison, <8 x i32> zeroinitializer
  %1194 = select <8 x i1> %.splat238, <8 x float> %1095, <8 x float> splat (float 0xC6293E5940000000)
  %1195 = load <8 x float>, ptr %.spill83, align 32
  %1196 = select <8 x i1> %80, <8 x float> %1194, <8 x float> %1195
  store <8 x float> %1196, ptr %.spill83, align 32
  %.splatinsert239 = insertelement <8 x i1> poison, i1 %1163, i64 0
  %.splat240 = shufflevector <8 x i1> %.splatinsert239, <8 x i1> poison, <8 x i32> zeroinitializer
  %1197 = select <8 x i1> %.splat240, <8 x float> %1096, <8 x float> splat (float 0xC6293E5940000000)
  %1198 = load <8 x float>, ptr %.spill84, align 32
  %1199 = select <8 x i1> %80, <8 x float> %1197, <8 x float> %1198
  store <8 x float> %1199, ptr %.spill84, align 32
  %.splatinsert241 = insertelement <8 x i1> poison, i1 %1164, i64 0
  %.splat242 = shufflevector <8 x i1> %.splatinsert241, <8 x i1> poison, <8 x i32> zeroinitializer
  %1200 = select <8 x i1> %.splat242, <8 x float> %1097, <8 x float> splat (float 0xC6293E5940000000)
  %1201 = load <8 x float>, ptr %.spill85, align 32
  %1202 = select <8 x i1> %80, <8 x float> %1200, <8 x float> %1201
  store <8 x float> %1202, ptr %.spill85, align 32
  %.splatinsert243 = insertelement <8 x i1> poison, i1 %1165, i64 0
  %.splat244 = shufflevector <8 x i1> %.splatinsert243, <8 x i1> poison, <8 x i32> zeroinitializer
  %1203 = select <8 x i1> %.splat244, <8 x float> %1098, <8 x float> splat (float 0xC6293E5940000000)
  %1204 = load <8 x float>, ptr %.spill86, align 32
  %1205 = select <8 x i1> %80, <8 x float> %1203, <8 x float> %1204
  store <8 x float> %1205, ptr %.spill86, align 32
  %.splatinsert245 = insertelement <8 x i1> poison, i1 %1166, i64 0
  %.splat246 = shufflevector <8 x i1> %.splatinsert245, <8 x i1> poison, <8 x i32> zeroinitializer
  %1206 = select <8 x i1> %.splat246, <8 x float> %1099, <8 x float> splat (float 0xC6293E5940000000)
  %1207 = load <8 x float>, ptr %.spill87, align 32
  %1208 = select <8 x i1> %80, <8 x float> %1206, <8 x float> %1207
  store <8 x float> %1208, ptr %.spill87, align 32
  %.splatinsert247 = insertelement <8 x i1> poison, i1 %1167, i64 0
  %.splat248 = shufflevector <8 x i1> %.splatinsert247, <8 x i1> poison, <8 x i32> zeroinitializer
  %1209 = select <8 x i1> %.splat248, <8 x float> %1100, <8 x float> splat (float 0xC6293E5940000000)
  %1210 = load <8 x float>, ptr %.spill88, align 32
  %1211 = select <8 x i1> %80, <8 x float> %1209, <8 x float> %1210
  store <8 x float> %1211, ptr %.spill88, align 32
  %.splatinsert249 = insertelement <8 x i1> poison, i1 %1168, i64 0
  %.splat250 = shufflevector <8 x i1> %.splatinsert249, <8 x i1> poison, <8 x i32> zeroinitializer
  %1212 = select <8 x i1> %.splat250, <8 x float> %1101, <8 x float> splat (float 0xC6293E5940000000)
  %1213 = load <8 x float>, ptr %.spill89, align 32
  %1214 = select <8 x i1> %80, <8 x float> %1212, <8 x float> %1213
  store <8 x float> %1214, ptr %.spill89, align 32
  %.splatinsert251 = insertelement <8 x i1> poison, i1 %1169, i64 0
  %.splat252 = shufflevector <8 x i1> %.splatinsert251, <8 x i1> poison, <8 x i32> zeroinitializer
  %1215 = select <8 x i1> %.splat252, <8 x float> %1102, <8 x float> splat (float 0xC6293E5940000000)
  %1216 = load <8 x float>, ptr %.spill90, align 32
  %1217 = select <8 x i1> %80, <8 x float> %1215, <8 x float> %1216
  store <8 x float> %1217, ptr %.spill90, align 32
  %1218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill91, align 64
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1220 = extractvalue { <8 x ptr>, <8 x i64> } %1218, 0
  %1221 = select <8 x i1> %80, <8 x ptr> %1219, <8 x ptr> %1220
  %1222 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %1218, 1
  %1224 = select <8 x i1> %80, <8 x i64> %1222, <8 x i64> %1223
  %1225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1221, 0
  %1226 = insertvalue { <8 x ptr>, <8 x i64> } %1225, <8 x i64> %1224, 1
  store { <8 x ptr>, <8 x i64> } %1226, ptr %tile_snapshot.spill91, align 64
  %1227 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1229 = add <8 x i64> %1228, zeroinitializer
  %1230 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1227, 0
  %1231 = insertvalue { <8 x ptr>, <8 x i64> } %1230, <8 x i64> %1229, 1
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1233 = extractvalue { <8 x ptr>, <8 x i64> } %1231, 1
  %1234 = extractelement <8 x ptr> %1232, i32 0
  %1235 = extractelement <8 x i64> %1233, i32 0
  %1236 = sub i64 %1235, 0
  %1237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1238 = select i1 %1237, i64 %1236, i64 0
  %private.contiguous.address253 = getelementptr i8, ptr %1234, i64 %1238
  %private.contiguous.preserve254 = load <8 x float>, ptr %private.contiguous.address253, align 4
  %1239 = select <8 x i1> %80, <8 x float> %1170, <8 x float> %private.contiguous.preserve254
  store <8 x float> %1239, ptr %private.contiguous.address253, align 4
  %1240 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1241 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1242 = add <8 x i64> %1241, splat (i64 32)
  %1243 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1240, 0
  %1244 = insertvalue { <8 x ptr>, <8 x i64> } %1243, <8 x i64> %1242, 1
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1246 = extractvalue { <8 x ptr>, <8 x i64> } %1244, 1
  %1247 = extractelement <8 x ptr> %1245, i32 0
  %1248 = extractelement <8 x i64> %1246, i32 0
  %1249 = sub i64 %1248, 0
  %1250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1251 = select i1 %1250, i64 %1249, i64 0
  %private.contiguous.address255 = getelementptr i8, ptr %1247, i64 %1251
  %private.contiguous.preserve256 = load <8 x float>, ptr %private.contiguous.address255, align 4
  %1252 = select <8 x i1> %80, <8 x float> %1173, <8 x float> %private.contiguous.preserve256
  store <8 x float> %1252, ptr %private.contiguous.address255, align 4
  %1253 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1254 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1255 = add <8 x i64> %1254, splat (i64 64)
  %1256 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1253, 0
  %1257 = insertvalue { <8 x ptr>, <8 x i64> } %1256, <8 x i64> %1255, 1
  %1258 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1259 = extractvalue { <8 x ptr>, <8 x i64> } %1257, 1
  %1260 = extractelement <8 x ptr> %1258, i32 0
  %1261 = extractelement <8 x i64> %1259, i32 0
  %1262 = sub i64 %1261, 0
  %1263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1264 = select i1 %1263, i64 %1262, i64 0
  %private.contiguous.address257 = getelementptr i8, ptr %1260, i64 %1264
  %private.contiguous.preserve258 = load <8 x float>, ptr %private.contiguous.address257, align 4
  %1265 = select <8 x i1> %80, <8 x float> %1176, <8 x float> %private.contiguous.preserve258
  store <8 x float> %1265, ptr %private.contiguous.address257, align 4
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1268 = add <8 x i64> %1267, splat (i64 96)
  %1269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1266, 0
  %1270 = insertvalue { <8 x ptr>, <8 x i64> } %1269, <8 x i64> %1268, 1
  %1271 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1272 = extractvalue { <8 x ptr>, <8 x i64> } %1270, 1
  %1273 = extractelement <8 x ptr> %1271, i32 0
  %1274 = extractelement <8 x i64> %1272, i32 0
  %1275 = sub i64 %1274, 0
  %1276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1277 = select i1 %1276, i64 %1275, i64 0
  %private.contiguous.address259 = getelementptr i8, ptr %1273, i64 %1277
  %private.contiguous.preserve260 = load <8 x float>, ptr %private.contiguous.address259, align 4
  %1278 = select <8 x i1> %80, <8 x float> %1179, <8 x float> %private.contiguous.preserve260
  store <8 x float> %1278, ptr %private.contiguous.address259, align 4
  %1279 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1280 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1281 = add <8 x i64> %1280, splat (i64 128)
  %1282 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1279, 0
  %1283 = insertvalue { <8 x ptr>, <8 x i64> } %1282, <8 x i64> %1281, 1
  %1284 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1285 = extractvalue { <8 x ptr>, <8 x i64> } %1283, 1
  %1286 = extractelement <8 x ptr> %1284, i32 0
  %1287 = extractelement <8 x i64> %1285, i32 0
  %1288 = sub i64 %1287, 0
  %1289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1290 = select i1 %1289, i64 %1288, i64 0
  %private.contiguous.address261 = getelementptr i8, ptr %1286, i64 %1290
  %private.contiguous.preserve262 = load <8 x float>, ptr %private.contiguous.address261, align 4
  %1291 = select <8 x i1> %80, <8 x float> %1182, <8 x float> %private.contiguous.preserve262
  store <8 x float> %1291, ptr %private.contiguous.address261, align 4
  %1292 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1293 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1294 = add <8 x i64> %1293, splat (i64 160)
  %1295 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1292, 0
  %1296 = insertvalue { <8 x ptr>, <8 x i64> } %1295, <8 x i64> %1294, 1
  %1297 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1298 = extractvalue { <8 x ptr>, <8 x i64> } %1296, 1
  %1299 = extractelement <8 x ptr> %1297, i32 0
  %1300 = extractelement <8 x i64> %1298, i32 0
  %1301 = sub i64 %1300, 0
  %1302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1303 = select i1 %1302, i64 %1301, i64 0
  %private.contiguous.address263 = getelementptr i8, ptr %1299, i64 %1303
  %private.contiguous.preserve264 = load <8 x float>, ptr %private.contiguous.address263, align 4
  %1304 = select <8 x i1> %80, <8 x float> %1185, <8 x float> %private.contiguous.preserve264
  store <8 x float> %1304, ptr %private.contiguous.address263, align 4
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1307 = add <8 x i64> %1306, splat (i64 192)
  %1308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1305, 0
  %1309 = insertvalue { <8 x ptr>, <8 x i64> } %1308, <8 x i64> %1307, 1
  %1310 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %1309, 1
  %1312 = extractelement <8 x ptr> %1310, i32 0
  %1313 = extractelement <8 x i64> %1311, i32 0
  %1314 = sub i64 %1313, 0
  %1315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1316 = select i1 %1315, i64 %1314, i64 0
  %private.contiguous.address265 = getelementptr i8, ptr %1312, i64 %1316
  %private.contiguous.preserve266 = load <8 x float>, ptr %private.contiguous.address265, align 4
  %1317 = select <8 x i1> %80, <8 x float> %1188, <8 x float> %private.contiguous.preserve266
  store <8 x float> %1317, ptr %private.contiguous.address265, align 4
  %1318 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1319 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1320 = add <8 x i64> %1319, splat (i64 224)
  %1321 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1318, 0
  %1322 = insertvalue { <8 x ptr>, <8 x i64> } %1321, <8 x i64> %1320, 1
  %1323 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %1322, 1
  %1325 = extractelement <8 x ptr> %1323, i32 0
  %1326 = extractelement <8 x i64> %1324, i32 0
  %1327 = sub i64 %1326, 0
  %1328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1329 = select i1 %1328, i64 %1327, i64 0
  %private.contiguous.address267 = getelementptr i8, ptr %1325, i64 %1329
  %private.contiguous.preserve268 = load <8 x float>, ptr %private.contiguous.address267, align 4
  %1330 = select <8 x i1> %80, <8 x float> %1191, <8 x float> %private.contiguous.preserve268
  store <8 x float> %1330, ptr %private.contiguous.address267, align 4
  %1331 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1332 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1333 = add <8 x i64> %1332, splat (i64 256)
  %1334 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1331, 0
  %1335 = insertvalue { <8 x ptr>, <8 x i64> } %1334, <8 x i64> %1333, 1
  %1336 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %1335, 1
  %1338 = extractelement <8 x ptr> %1336, i32 0
  %1339 = extractelement <8 x i64> %1337, i32 0
  %1340 = sub i64 %1339, 0
  %1341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1342 = select i1 %1341, i64 %1340, i64 0
  %private.contiguous.address269 = getelementptr i8, ptr %1338, i64 %1342
  %private.contiguous.preserve270 = load <8 x float>, ptr %private.contiguous.address269, align 4
  %1343 = select <8 x i1> %80, <8 x float> %1194, <8 x float> %private.contiguous.preserve270
  store <8 x float> %1343, ptr %private.contiguous.address269, align 4
  %1344 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1345 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1346 = add <8 x i64> %1345, splat (i64 288)
  %1347 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1344, 0
  %1348 = insertvalue { <8 x ptr>, <8 x i64> } %1347, <8 x i64> %1346, 1
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %1348, 1
  %1351 = extractelement <8 x ptr> %1349, i32 0
  %1352 = extractelement <8 x i64> %1350, i32 0
  %1353 = sub i64 %1352, 0
  %1354 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1355 = select i1 %1354, i64 %1353, i64 0
  %private.contiguous.address271 = getelementptr i8, ptr %1351, i64 %1355
  %private.contiguous.preserve272 = load <8 x float>, ptr %private.contiguous.address271, align 4
  %1356 = select <8 x i1> %80, <8 x float> %1197, <8 x float> %private.contiguous.preserve272
  store <8 x float> %1356, ptr %private.contiguous.address271, align 4
  %1357 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1358 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1359 = add <8 x i64> %1358, splat (i64 320)
  %1360 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1357, 0
  %1361 = insertvalue { <8 x ptr>, <8 x i64> } %1360, <8 x i64> %1359, 1
  %1362 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %1361, 1
  %1364 = extractelement <8 x ptr> %1362, i32 0
  %1365 = extractelement <8 x i64> %1363, i32 0
  %1366 = sub i64 %1365, 0
  %1367 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1368 = select i1 %1367, i64 %1366, i64 0
  %private.contiguous.address273 = getelementptr i8, ptr %1364, i64 %1368
  %private.contiguous.preserve274 = load <8 x float>, ptr %private.contiguous.address273, align 4
  %1369 = select <8 x i1> %80, <8 x float> %1200, <8 x float> %private.contiguous.preserve274
  store <8 x float> %1369, ptr %private.contiguous.address273, align 4
  %1370 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1371 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1372 = add <8 x i64> %1371, splat (i64 352)
  %1373 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1370, 0
  %1374 = insertvalue { <8 x ptr>, <8 x i64> } %1373, <8 x i64> %1372, 1
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %1374, 1
  %1377 = extractelement <8 x ptr> %1375, i32 0
  %1378 = extractelement <8 x i64> %1376, i32 0
  %1379 = sub i64 %1378, 0
  %1380 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1381 = select i1 %1380, i64 %1379, i64 0
  %private.contiguous.address275 = getelementptr i8, ptr %1377, i64 %1381
  %private.contiguous.preserve276 = load <8 x float>, ptr %private.contiguous.address275, align 4
  %1382 = select <8 x i1> %80, <8 x float> %1203, <8 x float> %private.contiguous.preserve276
  store <8 x float> %1382, ptr %private.contiguous.address275, align 4
  %1383 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1384 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1385 = add <8 x i64> %1384, splat (i64 384)
  %1386 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1383, 0
  %1387 = insertvalue { <8 x ptr>, <8 x i64> } %1386, <8 x i64> %1385, 1
  %1388 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %1387, 1
  %1390 = extractelement <8 x ptr> %1388, i32 0
  %1391 = extractelement <8 x i64> %1389, i32 0
  %1392 = sub i64 %1391, 0
  %1393 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1394 = select i1 %1393, i64 %1392, i64 0
  %private.contiguous.address277 = getelementptr i8, ptr %1390, i64 %1394
  %private.contiguous.preserve278 = load <8 x float>, ptr %private.contiguous.address277, align 4
  %1395 = select <8 x i1> %80, <8 x float> %1206, <8 x float> %private.contiguous.preserve278
  store <8 x float> %1395, ptr %private.contiguous.address277, align 4
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1397 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1398 = add <8 x i64> %1397, splat (i64 416)
  %1399 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1396, 0
  %1400 = insertvalue { <8 x ptr>, <8 x i64> } %1399, <8 x i64> %1398, 1
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %1400, 1
  %1403 = extractelement <8 x ptr> %1401, i32 0
  %1404 = extractelement <8 x i64> %1402, i32 0
  %1405 = sub i64 %1404, 0
  %1406 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1407 = select i1 %1406, i64 %1405, i64 0
  %private.contiguous.address279 = getelementptr i8, ptr %1403, i64 %1407
  %private.contiguous.preserve280 = load <8 x float>, ptr %private.contiguous.address279, align 4
  %1408 = select <8 x i1> %80, <8 x float> %1209, <8 x float> %private.contiguous.preserve280
  store <8 x float> %1408, ptr %private.contiguous.address279, align 4
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1411 = add <8 x i64> %1410, splat (i64 448)
  %1412 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1409, 0
  %1413 = insertvalue { <8 x ptr>, <8 x i64> } %1412, <8 x i64> %1411, 1
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %1413, 1
  %1416 = extractelement <8 x ptr> %1414, i32 0
  %1417 = extractelement <8 x i64> %1415, i32 0
  %1418 = sub i64 %1417, 0
  %1419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1420 = select i1 %1419, i64 %1418, i64 0
  %private.contiguous.address281 = getelementptr i8, ptr %1416, i64 %1420
  %private.contiguous.preserve282 = load <8 x float>, ptr %private.contiguous.address281, align 4
  %1421 = select <8 x i1> %80, <8 x float> %1212, <8 x float> %private.contiguous.preserve282
  store <8 x float> %1421, ptr %private.contiguous.address281, align 4
  %1422 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1423 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1424 = add <8 x i64> %1423, splat (i64 480)
  %1425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1422, 0
  %1426 = insertvalue { <8 x ptr>, <8 x i64> } %1425, <8 x i64> %1424, 1
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %1426, 1
  %1429 = extractelement <8 x ptr> %1427, i32 0
  %1430 = extractelement <8 x i64> %1428, i32 0
  %1431 = sub i64 %1430, 0
  %1432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1433 = select i1 %1432, i64 %1431, i64 0
  %private.contiguous.address283 = getelementptr i8, ptr %1429, i64 %1433
  %private.contiguous.preserve284 = load <8 x float>, ptr %private.contiguous.address283, align 4
  %1434 = select <8 x i1> %80, <8 x float> %1215, <8 x float> %private.contiguous.preserve284
  store <8 x float> %1434, ptr %private.contiguous.address283, align 4
  store i64 0, ptr %.slot92, align 4
  %1435 = load <8 x float>, ptr %.slot93, align 32
  %1436 = select <8 x i1> %80, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1435
  store <8 x float> %1436, ptr %.slot93, align 32
  br label %direct.schedule.19

direct.true286:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false287:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true381:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false382:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true393:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false394:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

mma.active410:                                    ; preds = %direct.schedule.27
  %1437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1438 = extractelement <8 x ptr> %1437, i64 0
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1440 = extractelement <8 x i64> %1439, i64 0
  %1441 = getelementptr i8, ptr %1438, i64 %1440
  %1442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1443 = extractelement <8 x ptr> %1442, i64 0
  %1444 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1445 = extractelement <8 x i64> %1444, i64 0
  %1446 = getelementptr i8, ptr %1443, i64 %1445
  %1447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1448 = extractelement <8 x ptr> %1447, i64 0
  %1449 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1450 = extractelement <8 x i64> %1449, i64 0
  %1451 = getelementptr i8, ptr %1448, i64 %1450
  %1452 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1453 = extractelement <8 x ptr> %1452, i64 0
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1455 = extractelement <8 x i64> %1454, i64 0
  %1456 = getelementptr i8, ptr %1453, i64 %1455
  call void @llm_attention.strided_mma.1(ptr %1441, ptr %1446, ptr %1451, ptr %1456)
  br label %mma.continue411

mma.continue411:                                  ; preds = %mma.active410, %direct.schedule.27
  %1457 = extractelement <8 x i1> %80, i64 1
  br i1 %1457, label %mma.active412, label %mma.continue413

mma.active412:                                    ; preds = %mma.continue411
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1459 = extractelement <8 x ptr> %1458, i64 1
  %1460 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1461 = extractelement <8 x i64> %1460, i64 1
  %1462 = getelementptr i8, ptr %1459, i64 %1461
  %1463 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1464 = extractelement <8 x ptr> %1463, i64 1
  %1465 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1466 = extractelement <8 x i64> %1465, i64 1
  %1467 = getelementptr i8, ptr %1464, i64 %1466
  %1468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1469 = extractelement <8 x ptr> %1468, i64 1
  %1470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1471 = extractelement <8 x i64> %1470, i64 1
  %1472 = getelementptr i8, ptr %1469, i64 %1471
  %1473 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1474 = extractelement <8 x ptr> %1473, i64 1
  %1475 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1476 = extractelement <8 x i64> %1475, i64 1
  %1477 = getelementptr i8, ptr %1474, i64 %1476
  call void @llm_attention.strided_mma.1(ptr %1462, ptr %1467, ptr %1472, ptr %1477)
  br label %mma.continue413

mma.continue413:                                  ; preds = %mma.active412, %mma.continue411
  %1478 = extractelement <8 x i1> %80, i64 2
  br i1 %1478, label %mma.active414, label %mma.continue415

mma.active414:                                    ; preds = %mma.continue413
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1480 = extractelement <8 x ptr> %1479, i64 2
  %1481 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1482 = extractelement <8 x i64> %1481, i64 2
  %1483 = getelementptr i8, ptr %1480, i64 %1482
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1485 = extractelement <8 x ptr> %1484, i64 2
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1487 = extractelement <8 x i64> %1486, i64 2
  %1488 = getelementptr i8, ptr %1485, i64 %1487
  %1489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1490 = extractelement <8 x ptr> %1489, i64 2
  %1491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1492 = extractelement <8 x i64> %1491, i64 2
  %1493 = getelementptr i8, ptr %1490, i64 %1492
  %1494 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1495 = extractelement <8 x ptr> %1494, i64 2
  %1496 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1497 = extractelement <8 x i64> %1496, i64 2
  %1498 = getelementptr i8, ptr %1495, i64 %1497
  call void @llm_attention.strided_mma.1(ptr %1483, ptr %1488, ptr %1493, ptr %1498)
  br label %mma.continue415

mma.continue415:                                  ; preds = %mma.active414, %mma.continue413
  %1499 = extractelement <8 x i1> %80, i64 3
  br i1 %1499, label %mma.active416, label %mma.continue417

mma.active416:                                    ; preds = %mma.continue415
  %1500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1501 = extractelement <8 x ptr> %1500, i64 3
  %1502 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1503 = extractelement <8 x i64> %1502, i64 3
  %1504 = getelementptr i8, ptr %1501, i64 %1503
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1506 = extractelement <8 x ptr> %1505, i64 3
  %1507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1508 = extractelement <8 x i64> %1507, i64 3
  %1509 = getelementptr i8, ptr %1506, i64 %1508
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1511 = extractelement <8 x ptr> %1510, i64 3
  %1512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1513 = extractelement <8 x i64> %1512, i64 3
  %1514 = getelementptr i8, ptr %1511, i64 %1513
  %1515 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1516 = extractelement <8 x ptr> %1515, i64 3
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1518 = extractelement <8 x i64> %1517, i64 3
  %1519 = getelementptr i8, ptr %1516, i64 %1518
  call void @llm_attention.strided_mma.1(ptr %1504, ptr %1509, ptr %1514, ptr %1519)
  br label %mma.continue417

mma.continue417:                                  ; preds = %mma.active416, %mma.continue415
  %1520 = extractelement <8 x i1> %80, i64 4
  br i1 %1520, label %mma.active418, label %mma.continue419

mma.active418:                                    ; preds = %mma.continue417
  %1521 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1522 = extractelement <8 x ptr> %1521, i64 4
  %1523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1524 = extractelement <8 x i64> %1523, i64 4
  %1525 = getelementptr i8, ptr %1522, i64 %1524
  %1526 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1527 = extractelement <8 x ptr> %1526, i64 4
  %1528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1529 = extractelement <8 x i64> %1528, i64 4
  %1530 = getelementptr i8, ptr %1527, i64 %1529
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1532 = extractelement <8 x ptr> %1531, i64 4
  %1533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1534 = extractelement <8 x i64> %1533, i64 4
  %1535 = getelementptr i8, ptr %1532, i64 %1534
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1537 = extractelement <8 x ptr> %1536, i64 4
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1539 = extractelement <8 x i64> %1538, i64 4
  %1540 = getelementptr i8, ptr %1537, i64 %1539
  call void @llm_attention.strided_mma.1(ptr %1525, ptr %1530, ptr %1535, ptr %1540)
  br label %mma.continue419

mma.continue419:                                  ; preds = %mma.active418, %mma.continue417
  %1541 = extractelement <8 x i1> %80, i64 5
  br i1 %1541, label %mma.active420, label %mma.continue421

mma.active420:                                    ; preds = %mma.continue419
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1543 = extractelement <8 x ptr> %1542, i64 5
  %1544 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1545 = extractelement <8 x i64> %1544, i64 5
  %1546 = getelementptr i8, ptr %1543, i64 %1545
  %1547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1548 = extractelement <8 x ptr> %1547, i64 5
  %1549 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1550 = extractelement <8 x i64> %1549, i64 5
  %1551 = getelementptr i8, ptr %1548, i64 %1550
  %1552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1553 = extractelement <8 x ptr> %1552, i64 5
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1555 = extractelement <8 x i64> %1554, i64 5
  %1556 = getelementptr i8, ptr %1553, i64 %1555
  %1557 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1558 = extractelement <8 x ptr> %1557, i64 5
  %1559 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1560 = extractelement <8 x i64> %1559, i64 5
  %1561 = getelementptr i8, ptr %1558, i64 %1560
  call void @llm_attention.strided_mma.1(ptr %1546, ptr %1551, ptr %1556, ptr %1561)
  br label %mma.continue421

mma.continue421:                                  ; preds = %mma.active420, %mma.continue419
  %1562 = extractelement <8 x i1> %80, i64 6
  br i1 %1562, label %mma.active422, label %mma.continue423

mma.active422:                                    ; preds = %mma.continue421
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1564 = extractelement <8 x ptr> %1563, i64 6
  %1565 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1566 = extractelement <8 x i64> %1565, i64 6
  %1567 = getelementptr i8, ptr %1564, i64 %1566
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1569 = extractelement <8 x ptr> %1568, i64 6
  %1570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1571 = extractelement <8 x i64> %1570, i64 6
  %1572 = getelementptr i8, ptr %1569, i64 %1571
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1574 = extractelement <8 x ptr> %1573, i64 6
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1576 = extractelement <8 x i64> %1575, i64 6
  %1577 = getelementptr i8, ptr %1574, i64 %1576
  %1578 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1579 = extractelement <8 x ptr> %1578, i64 6
  %1580 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1581 = extractelement <8 x i64> %1580, i64 6
  %1582 = getelementptr i8, ptr %1579, i64 %1581
  call void @llm_attention.strided_mma.1(ptr %1567, ptr %1572, ptr %1577, ptr %1582)
  br label %mma.continue423

mma.continue423:                                  ; preds = %mma.active422, %mma.continue421
  %1583 = extractelement <8 x i1> %80, i64 7
  br i1 %1583, label %mma.active424, label %mma.continue425

mma.active424:                                    ; preds = %mma.continue423
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1585 = extractelement <8 x ptr> %1584, i64 7
  %1586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %1587 = extractelement <8 x i64> %1586, i64 7
  %1588 = getelementptr i8, ptr %1585, i64 %1587
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 0
  %1590 = extractelement <8 x ptr> %1589, i64 7
  %1591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load408, 1
  %1592 = extractelement <8 x i64> %1591, i64 7
  %1593 = getelementptr i8, ptr %1590, i64 %1592
  %1594 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %1595 = extractelement <8 x ptr> %1594, i64 7
  %1596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %1597 = extractelement <8 x i64> %1596, i64 7
  %1598 = getelementptr i8, ptr %1595, i64 %1597
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1600 = extractelement <8 x ptr> %1599, i64 7
  %1601 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1602 = extractelement <8 x i64> %1601, i64 7
  %1603 = getelementptr i8, ptr %1600, i64 %1602
  call void @llm_attention.strided_mma.1(ptr %1588, ptr %1593, ptr %1598, ptr %1603)
  br label %mma.continue425

mma.continue425:                                  ; preds = %mma.active424, %mma.continue423
  store i64 0, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.true427:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false428:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true441:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false442:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true460:                                   ; preds = %direct.schedule.35
  br label %direct.schedule.36

direct.false461:                                  ; preds = %direct.schedule.35
  br label %direct.schedule.37
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nounwind willreturn "fp-contract"="off" }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

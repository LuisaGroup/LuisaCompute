; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [21 x i32] [i32 5, i32 4, i32 8, i32 54, i32 15, i32 14, i32 20, i32 19, i32 23, i32 26, i32 29, i32 32, i32 35, i32 38, i32 41, i32 44, i32 47, i32 50, i32 53, i32 59, i32 58], align 4

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 640, i64 1280, i64 1920, i64 2560, i64 3200, i64 3840, i64 4480>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 5120
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 11264
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 17408
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 2560, i64 5120, i64 7680, i64 10240, i64 12800, i64 15360, i64 17920>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 37888
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 3072, i64 6144, i64 9216, i64 12288, i64 15360, i64 18432, i64 21504>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 62464
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 256, i64 512, i64 768, i64 1024, i64 1280, i64 1536, i64 1792>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 64512
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 256, i64 512, i64 768, i64 1024, i64 1280, i64 1536, i64 1792>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 66560
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 68608
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 68736
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 256, i64 512, i64 768, i64 1024, i64 1280, i64 1536, i64 1792>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 70784
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 768, i64 1536, i64 2304, i64 3072, i64 3840, i64 4608, i64 5376>, 1
  %33 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace41 = load ptr, ptr %33, align 8
  %tile_snapshot.private42 = getelementptr inbounds i8, ptr %private.workspace41, i64 76928
  %.splatinsert43 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private42, i64 0
  %.splat44 = shufflevector <8 x ptr> %.splatinsert43, <8 x ptr> poison, <8 x i32> zeroinitializer
  %34 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat44, 0
  %35 = insertvalue { <8 x ptr>, <8 x i64> } %34, <8 x i64> <i64 0, i64 768, i64 1536, i64 2304, i64 3072, i64 3840, i64 4608, i64 5376>, 1
  %36 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace45 = load ptr, ptr %36, align 8
  %tile_snapshot.private46 = getelementptr inbounds i8, ptr %private.workspace45, i64 83072
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %37 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %38 = insertvalue { <8 x ptr>, <8 x i64> } %37, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill49 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill49, align 64
  %.spill50 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill50, align 64
  %.spill51 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill51, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill52 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill52, align 64
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %tile_snapshot.spill54 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill54, align 64
  %tile_snapshot.spill55 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill55, align 64
  %.slot56 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot56, align 64
  %.slot57 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot57, align 64
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %.slot65 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot65, align 32
  %.spill66 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill66, align 64
  %tile_snapshot.spill67 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill67, align 64
  %.slot68 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot68, align 64
  %.spill69 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill69, align 64
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %tile_snapshot.spill71 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill71, align 64
  %.slot72 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot72, align 64
  %.spill73 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill73, align 64
  %.slot74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot74, align 32
  %.spill75 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill75, align 1
  %.spill76 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill76, align 1
  %.spill77 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill77, align 1
  %.spill78 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill78, align 1
  %.spill79 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill79, align 1
  %.spill80 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill80, align 1
  %.spill81 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill81, align 1
  %.spill82 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill82, align 1
  %.spill83 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill83, align 1
  %.spill84 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill84, align 1
  %.spill85 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill85, align 1
  %.spill86 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill86, align 1
  %.spill87 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill87, align 1
  %.spill88 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill88, align 1
  %.spill89 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill89, align 1
  %.spill90 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill90, align 1
  %.spill91 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill91, align 1
  %.spill92 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill92, align 1
  %.spill93 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill93, align 1
  %.spill94 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill94, align 1
  %.spill95 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill95, align 1
  %.spill96 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill96, align 1
  %.spill97 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill97, align 1
  %.spill98 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill98, align 1
  %.spill99 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill99, align 1
  %.spill100 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill100, align 1
  %.spill101 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill101, align 1
  %.spill102 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill102, align 1
  %.spill103 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill103, align 1
  %.spill104 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill104, align 1
  %.spill105 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill105, align 1
  %.spill106 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill106, align 1
  %.spill107 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill107, align 1
  %.spill108 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill108, align 1
  %.spill109 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill109, align 1
  %.spill110 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill110, align 1
  %.spill111 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill111, align 1
  %.spill112 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill112, align 1
  %.spill113 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill113, align 1
  %.spill114 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill114, align 1
  %.spill115 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill115, align 1
  %.spill116 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill116, align 1
  %.spill117 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill117, align 1
  %.spill118 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill118, align 1
  %.spill119 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill119, align 1
  %.spill120 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill120, align 1
  %.spill121 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill121, align 1
  %.spill122 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill122, align 1
  %.spill123 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill123, align 1
  %.spill124 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill124, align 1
  %.spill125 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill125, align 1
  %.spill126 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill126, align 1
  %.spill127 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill127, align 1
  %.spill128 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill128, align 1
  %.spill129 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill129, align 1
  %.spill130 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill130, align 1
  %.spill131 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill131, align 1
  %.spill132 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill132, align 1
  %.spill133 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill133, align 1
  %.spill134 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill134, align 1
  %.spill135 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill135, align 1
  %.spill136 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill136, align 1
  %.spill137 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill137, align 1
  %.spill138 = alloca <8 x i1>, align 1
  store volatile <8 x i1> zeroinitializer, ptr %.spill138, align 1
  %.spill139 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill139, align 32
  %.spill140 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill141, align 32
  %.spill142 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill142, align 32
  %.spill143 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill143, align 32
  %.spill144 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill144, align 32
  %.spill145 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill145, align 32
  %.spill146 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill146, align 32
  %.spill147 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill147, align 32
  %.spill148 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill148, align 32
  %.spill149 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill149, align 32
  %.spill150 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill150, align 32
  %.spill151 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill151, align 32
  %.spill152 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill152, align 32
  %.spill153 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill153, align 32
  %.spill154 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill154, align 32
  %.spill155 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill155, align 32
  %.spill156 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill156, align 32
  %.spill157 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill157, align 32
  %.spill158 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill158, align 32
  %.spill159 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill159, align 32
  %.spill160 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill160, align 32
  %.spill161 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill161, align 32
  %.spill162 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill162, align 32
  %.spill163 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill163, align 32
  %.spill164 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill164, align 32
  %.spill165 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill165, align 32
  %.spill166 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill166, align 32
  %.spill167 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill167, align 32
  %.spill168 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill168, align 32
  %.spill169 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill169, align 32
  %.spill170 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill170, align 32
  %.spill171 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill171, align 32
  %.spill172 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill172, align 32
  %.spill173 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill173, align 32
  %.spill174 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill174, align 32
  %.spill175 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill175, align 32
  %.spill176 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill176, align 32
  %.spill177 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill177, align 32
  %.spill178 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill178, align 32
  %.spill179 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill179, align 32
  %.spill180 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill180, align 32
  %.spill181 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill181, align 32
  %.spill182 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill182, align 32
  %.spill183 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill183, align 32
  %.spill184 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill184, align 32
  %.spill185 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill185, align 32
  %.spill186 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill186, align 32
  %.spill187 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill187, align 32
  %.spill188 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill188, align 32
  %.spill189 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill189, align 32
  %.spill190 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill190, align 32
  %.spill191 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill191, align 32
  %.spill192 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill192, align 32
  %.spill193 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill193, align 32
  %.spill194 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill194, align 32
  %.spill195 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill195, align 32
  %.spill196 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill196, align 32
  %.spill197 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill197, align 32
  %.spill198 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill198, align 32
  %.spill199 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill199, align 32
  %.spill200 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill200, align 32
  %.spill201 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill201, align 32
  %.spill202 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill202, align 32
  %tile_snapshot.spill203 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill203, align 64
  %.slot204 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot204, align 64
  %.slot205 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot205, align 32
  %.slot206 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot206, align 64
  %.slot207 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot207, align 32
  %.slot208 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot208, align 64
  %.slot209 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot209, align 32
  %.slot210 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot210, align 64
  %.slot211 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot211, align 32
  %.spill212 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill212, align 32
  %.spill213 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill213, align 32
  %.spill214 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill214, align 32
  %.spill215 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill215, align 32
  %tile_snapshot.spill216 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill216, align 64
  %tile_snapshot.spill217 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill217, align 64
  %.spill218 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill218, align 32
  %.spill219 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill219, align 32
  %.spill220 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill220, align 32
  %.spill221 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill221, align 32
  %.slot222 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot222, align 64
  %.slot223 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot223, align 32
  %.slot224 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot224, align 64
  %.slot225 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot225, align 32
  %.slot226 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot226, align 64
  %.slot227 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot227, align 32
  %.slot228 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot228, align 64
  %.slot229 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot229, align 32
  %.spill230 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill230, align 32
  %.spill231 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill231, align 32
  %.spill232 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill232, align 32
  %.spill233 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill233, align 32
  %tile_snapshot.spill234 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill234, align 64
  %.slot235 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot235, align 64
  %tile_snapshot.spill236 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill236, align 64
  %.slot237 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot237, align 64
  %.slot238 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot238, align 64
  %tile_snapshot.spill239 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store volatile { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill239, align 64
  %.slot240 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot240, align 64
  %.spill241 = alloca <8 x i64>, align 64
  store volatile <8 x i64> zeroinitializer, ptr %.spill241, align 64
  %.spill242 = alloca <8 x float>, align 32
  store volatile <8 x float> zeroinitializer, ptr %.spill242, align 32
  %39 = getelementptr i8, ptr %argument_buffer, i64 0
  %40 = load ptr, ptr %39, align 16
  %41 = getelementptr i8, ptr %39, i64 8
  %42 = load i64, ptr %41, align 8
  %43 = insertvalue { ptr, i64 } poison, ptr %40, 0
  %44 = insertvalue { ptr, i64 } %43, i64 %42, 1
  %45 = getelementptr i8, ptr %argument_buffer, i64 16
  %46 = load ptr, ptr %45, align 16
  %47 = getelementptr i8, ptr %45, i64 8
  %48 = load i64, ptr %47, align 8
  %49 = insertvalue { ptr, i64 } poison, ptr %46, 0
  %50 = insertvalue { ptr, i64 } %49, i64 %48, 1
  %51 = getelementptr i8, ptr %argument_buffer, i64 32
  %52 = load ptr, ptr %51, align 16
  %53 = getelementptr i8, ptr %51, i64 8
  %54 = load i64, ptr %53, align 8
  %55 = insertvalue { ptr, i64 } poison, ptr %52, 0
  %56 = insertvalue { ptr, i64 } %55, i64 %54, 1
  %57 = getelementptr i8, ptr %argument_buffer, i64 48
  %58 = load ptr, ptr %57, align 16
  %59 = getelementptr i8, ptr %57, i64 8
  %60 = load i64, ptr %59, align 8
  %61 = insertvalue { ptr, i64 } poison, ptr %58, 0
  %62 = insertvalue { ptr, i64 } %61, i64 %60, 1
  %63 = load i32, ptr %launch_config, align 4
  %64 = getelementptr i8, ptr %launch_config, i64 12
  %65 = load i32, ptr %64, align 4
  %66 = getelementptr i8, ptr %launch_config, i64 4
  %67 = load i32, ptr %66, align 4
  %68 = getelementptr i8, ptr %launch_config, i64 16
  %69 = load i32, ptr %68, align 4
  %70 = getelementptr i8, ptr %launch_config, i64 8
  %71 = load i32, ptr %70, align 4
  %72 = getelementptr i8, ptr %launch_config, i64 20
  %73 = load i32, ptr %72, align 4
  %74 = getelementptr i8, ptr %launch_config, i64 36
  %75 = load i32, ptr %74, align 4
  %.splatinsert243 = insertelement <8 x i32> poison, i32 %75, i64 0
  %.splat244 = shufflevector <8 x i32> %.splatinsert243, <8 x i32> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i32> %.splat244, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %77 = mul i32 %63, 32
  %.splatinsert245 = insertelement <8 x i32> poison, i32 %77, i64 0
  %.splat246 = shufflevector <8 x i32> %.splatinsert245, <8 x i32> poison, <8 x i32> zeroinitializer
  %78 = add <8 x i32> %.splat246, %76
  %79 = mul i32 %67, 1
  %.splatinsert247 = insertelement <8 x i32> poison, i32 %79, i64 0
  %.splat248 = shufflevector <8 x i32> %.splatinsert247, <8 x i32> poison, <8 x i32> zeroinitializer
  %80 = add <8 x i32> %.splat248, zeroinitializer
  %81 = mul i32 %71, 1
  %.splatinsert249 = insertelement <8 x i32> poison, i32 %81, i64 0
  %.splat250 = shufflevector <8 x i32> %.splatinsert249, <8 x i32> poison, <8 x i32> zeroinitializer
  %82 = add <8 x i32> %.splat250, zeroinitializer
  %83 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %78, 0
  %84 = insertvalue [3 x <8 x i32>] %83, <8 x i32> %80, 1
  %85 = insertvalue [3 x <8 x i32>] %84, <8 x i32> %82, 2
  %.splatinsert251 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat252 = shufflevector <8 x i32> %.splatinsert251, <8 x i32> poison, <8 x i32> zeroinitializer
  %86 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat252
  store <8 x i1> %86, ptr %live.mask, align 1
  %87 = load i32, ptr %current.token, align 4
  %88 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %86)
  %89 = load i32, ptr %ready.count, align 4
  %90 = icmp uge i32 %89, 8
  %91 = and i1 %88, %90
  br i1 %91, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %92 = select i1 %88, i32 %89, i32 0
  %93 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %92
  %94 = load <8 x i1>, ptr %93, align 1
  %95 = select i1 %88, <8 x i1> %86, <8 x i1> %94
  store <8 x i1> %95, ptr %93, align 1
  %96 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %92
  %97 = load i32, ptr %96, align 4
  %98 = select i1 %88, i32 0, i32 %97
  store i32 %98, ptr %96, align 4
  %99 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %92
  %100 = load i32, ptr %99, align 4
  %101 = select i1 %88, i32 %87, i32 %100
  store i32 %101, ptr %99, align 4
  %102 = add i32 %89, 1
  %103 = select i1 %88, i32 %102, i32 %89
  store i32 %103, ptr %ready.count, align 4
  %104 = load <8 x i1>, ptr %runnable.mask, align 1
  %105 = or <8 x i1> %104, %86
  store <8 x i1> %105, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %return.frame.cleanup.done, %convergence.cascade.exit1281, %convergence.target.58.ready, %convergence.cascade.exit1263, %schedule.57, %varying.coherent.false1259, %varying.coherent.true1258, %varying.coherent.false1244, %varying.coherent.true1243, %convergence.target.54.ready, %convergence.cascade.exit1208, %convergence.target.53.ready, %convergence.cascade.exit1182, %schedule.52, %varying.coherent.false1175, %varying.coherent.true1174, %convergence.target.50.ready, %convergence.cascade.exit1151, %schedule.49, %varying.coherent.false1144, %varying.coherent.true1143, %mma.continue1135, %convergence.cascade.exit1101, %schedule.46, %varying.coherent.false1092, %varying.coherent.true1091, %convergence.target.44.ready, %convergence.cascade.exit1060, %schedule.43, %varying.coherent.false1054, %varying.coherent.true1053, %convergence.target.41.ready, %convergence.cascade.exit1030, %schedule.40, %varying.coherent.false1024, %varying.coherent.true1023, %convergence.target.38.ready, %convergence.cascade.exit1000, %schedule.37, %varying.coherent.false994, %varying.coherent.true993, %convergence.target.35.ready, %convergence.cascade.exit970, %schedule.34, %varying.coherent.false964, %varying.coherent.true963, %convergence.target.32.ready, %convergence.cascade.exit721, %schedule.31, %varying.coherent.false715, %varying.coherent.true714, %convergence.target.29.ready, %convergence.cascade.exit691, %schedule.28, %varying.coherent.false685, %varying.coherent.true684, %convergence.target.26.ready, %convergence.cascade.exit661, %schedule.25, %varying.coherent.false655, %varying.coherent.true654, %convergence.target.23.ready, %convergence.cascade.exit631, %schedule.22, %varying.coherent.false625, %varying.coherent.true624, %mma.continue470, %convergence.cascade.exit439, %convergence.target.19.ready, %convergence.cascade.exit418, %schedule.18, %varying.coherent.false415, %varying.coherent.true414, %varying.coherent.false402, %varying.coherent.true401, %convergence.target.15.ready, %convergence.cascade.exit378, %convergence.target.14.ready, %convergence.cascade.exit357, %schedule.13, %varying.coherent.false354, %varying.coherent.true353, %varying.coherent.false341, %varying.coherent.true340, %schedule.10, %varying.coherent.false331, %varying.coherent.true330, %convergence.target.8.ready, %convergence.cascade.exit307, %schedule.7, %varying.coherent.false302, %varying.coherent.true301, %convergence.target.5.ready, %convergence.cascade.exit278, %convergence.target.4.ready, %convergence.cascade.exit, %schedule.3, %varying.coherent.false266, %varying.coherent.true265, %varying.coherent.false, %varying.coherent.true, %schedule.0, %ready.overflow.resume
  %106 = load i32, ptr %ready.count, align 4
  %107 = icmp ne i32 %106, 0
  br i1 %107, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %108 = sub i32 %106, 1
  store i32 %108, ptr %ready.count, align 4
  %109 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %108
  %110 = load <8 x i1>, ptr %109, align 1
  store <8 x i1> %110, ptr %current.mask, align 1
  %111 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %108
  %112 = load i32, ptr %111, align 4
  %113 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %108
  %114 = load i32, ptr %113, align 4
  store i32 %114, ptr %current.token, align 4
  %115 = load <8 x i1>, ptr %runnable.mask, align 1
  %116 = xor <8 x i1> %110, splat (i1 true)
  %117 = and <8 x i1> %115, %116
  store <8 x i1> %117, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume1257, %ready.overflow.resume1242, %ready.overflow.resume1173, %ready.overflow.resume1142, %ready.overflow.resume1090, %ready.overflow.resume1052, %ready.overflow.resume1022, %ready.overflow.resume992, %ready.overflow.resume962, %ready.overflow.resume713, %ready.overflow.resume683, %ready.overflow.resume653, %ready.overflow.resume623, %ready.overflow.resume413, %ready.overflow.resume400, %ready.overflow.resume352, %ready.overflow.resume339, %ready.overflow.resume329, %ready.overflow.resume300, %ready.overflow.resume264, %ready.overflow.resume254, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %112, %scheduler.dispatch ], [ 5, %ready.overflow.resume254 ], [ 4, %ready.overflow.resume264 ], [ 8, %ready.overflow.resume300 ], [ 54, %ready.overflow.resume329 ], [ 15, %ready.overflow.resume339 ], [ 14, %ready.overflow.resume352 ], [ 20, %ready.overflow.resume400 ], [ 19, %ready.overflow.resume413 ], [ 23, %ready.overflow.resume623 ], [ 26, %ready.overflow.resume653 ], [ 29, %ready.overflow.resume683 ], [ 32, %ready.overflow.resume713 ], [ 35, %ready.overflow.resume962 ], [ 38, %ready.overflow.resume992 ], [ 41, %ready.overflow.resume1022 ], [ 44, %ready.overflow.resume1052 ], [ 47, %ready.overflow.resume1090 ], [ 50, %ready.overflow.resume1142 ], [ 53, %ready.overflow.resume1173 ], [ 59, %ready.overflow.resume1242 ], [ 58, %ready.overflow.resume1257 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
    i32 48, label %schedule.48
    i32 49, label %schedule.49
    i32 50, label %schedule.50
    i32 51, label %schedule.51
    i32 52, label %schedule.52
    i32 53, label %schedule.53
    i32 54, label %schedule.54
    i32 55, label %schedule.55
    i32 56, label %schedule.56
    i32 57, label %schedule.57
    i32 58, label %schedule.58
    i32 59, label %schedule.59
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %118 = load <8 x i1>, ptr %live.mask, align 1
  %119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %118)
  br i1 %119, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %120 = load <8 x i1>, ptr %current.mask, align 1
  %121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %120)
  %122 = bitcast <8 x i1> %120 to i8
  %123 = call i8 @llvm.cttz.i8(i8 %122, i1 false)
  %124 = zext i8 %123 to i32
  %125 = select i1 %121, i32 %124, i32 0
  %126 = extractvalue [3 x <8 x i32>] %85, 0
  %127 = zext <8 x i32> %126 to <8 x i64>
  %128 = select <8 x i1> %120, <8 x i64> %127, <8 x i64> zeroinitializer
  %129 = select <8 x i1> %120, <8 x i64> splat (i64 30), <8 x i64> splat (i64 1)
  %130 = sdiv <8 x i64> %128, %129
  %131 = load <8 x i64>, ptr %.spill, align 64
  %132 = select <8 x i1> %120, <8 x i64> %130, <8 x i64> %131
  store <8 x i64> %132, ptr %.spill, align 64
  %133 = select <8 x i1> %120, <8 x i64> %127, <8 x i64> zeroinitializer
  %134 = select <8 x i1> %120, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %135 = sdiv <8 x i64> %133, %134
  %136 = select <8 x i1> %120, <8 x i64> %135, <8 x i64> zeroinitializer
  %137 = select <8 x i1> %120, <8 x i64> splat (i64 6), <8 x i64> splat (i64 1)
  %138 = srem <8 x i64> %136, %137
  %139 = load volatile <8 x i64>, ptr %.spill49, align 64
  %140 = select <8 x i1> %120, <8 x i64> %138, <8 x i64> %139
  store volatile <8 x i64> %140, ptr %.spill49, align 64
  %141 = select <8 x i1> %120, <8 x i64> %127, <8 x i64> zeroinitializer
  %142 = select <8 x i1> %120, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %143 = sdiv <8 x i64> %141, %142
  %144 = select <8 x i1> %120, <8 x i64> %143, <8 x i64> zeroinitializer
  %145 = select <8 x i1> %120, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %146 = srem <8 x i64> %144, %145
  %147 = mul <8 x i64> %146, splat (i64 4)
  %148 = load <8 x i64>, ptr %.spill50, align 64
  %149 = select <8 x i1> %120, <8 x i64> %147, <8 x i64> %148
  store <8 x i64> %149, ptr %.spill50, align 64
  %150 = select <8 x i1> %120, <8 x i64> %138, <8 x i64> zeroinitializer
  %151 = select <8 x i1> %120, <8 x i64> splat (i64 3), <8 x i64> splat (i64 1)
  %152 = sdiv <8 x i64> %150, %151
  %153 = load volatile <8 x i64>, ptr %.spill51, align 64
  %154 = select <8 x i1> %120, <8 x i64> %152, <8 x i64> %153
  store volatile <8 x i64> %154, ptr %.spill51, align 64
  %155 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %155, 0
  %158 = select <8 x i1> %120, <8 x ptr> %156, <8 x ptr> %157
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %155, 1
  %161 = select <8 x i1> %120, <8 x i64> %159, <8 x i64> %160
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %158, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  store volatile { <8 x ptr>, <8 x i64> } %163, ptr %tile_snapshot.spill, align 64
  %164 = load <8 x i64>, ptr %.slot, align 64
  %165 = select <8 x i1> %120, <8 x i64> zeroinitializer, <8 x i64> %164
  store <8 x i64> %165, ptr %.slot, align 64
  store <8 x i1> %120, ptr %current.mask, align 1
  %166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %120)
  br i1 %166, label %schedule.1, label %scheduler.loop

schedule.1:                                       ; preds = %convergence.target.4.ready, %schedule.0, %scheduler.dispatch.route
  %167 = load <8 x i1>, ptr %current.mask, align 1
  %168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %167)
  %169 = bitcast <8 x i1> %167 to i8
  %170 = call i8 @llvm.cttz.i8(i8 %169, i1 false)
  %171 = zext i8 %170 to i32
  %172 = select i1 %168, i32 %171, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %173 = icmp slt <8 x i64> %.state, splat (i64 160)
  %174 = and <8 x i1> %167, %173
  %175 = xor <8 x i1> %173, splat (i1 true)
  %176 = and <8 x i1> %167, %175
  %177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %174)
  %178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %176)
  %179 = and i1 %177, %178
  br i1 %179, label %varying.divergent, label %varying.coherent

schedule.2:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %180 = load <8 x i1>, ptr %current.mask, align 1
  %181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %180)
  %182 = bitcast <8 x i1> %180 to i8
  %183 = call i8 @llvm.cttz.i8(i8 %182, i1 false)
  %184 = zext i8 %183 to i32
  %185 = select i1 %181, i32 %184, i32 0
  %.state255 = load <8 x i64>, ptr %.slot, align 64
  %186 = select <8 x i1> %180, <8 x i64> %.state255, <8 x i64> zeroinitializer
  %187 = select <8 x i1> %180, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %188 = srem <8 x i64> %186, %187
  %.state256 = load <8 x i64>, ptr %.slot, align 64
  %189 = select <8 x i1> %180, <8 x i64> %.state256, <8 x i64> zeroinitializer
  %190 = select <8 x i1> %180, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %191 = sdiv <8 x i64> %189, %190
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %192 = add <8 x i64> %.spill.load, zeroinitializer
  %193 = add <8 x i64> zeroinitializer, %192
  %.spill.load257 = load volatile <8 x i64>, ptr %.spill49, align 64
  %194 = add <8 x i64> %.spill.load257, zeroinitializer
  %195 = mul <8 x i64> %193, splat (i64 6)
  %196 = add <8 x i64> %195, %194
  %.spill.load258 = load <8 x i64>, ptr %.spill50, align 64
  %197 = add <8 x i64> %.spill.load258, %191
  %198 = mul <8 x i64> %196, splat (i64 17)
  %199 = add <8 x i64> %198, %197
  %200 = icmp sge <8 x i64> %197, zeroinitializer
  %201 = and <8 x i1> splat (i1 true), %200
  %202 = icmp slt <8 x i64> %197, splat (i64 17)
  %203 = and <8 x i1> %201, %202
  %204 = add <8 x i64> zeroinitializer, %188
  %205 = mul <8 x i64> %199, splat (i64 40)
  %206 = add <8 x i64> %205, %204
  %207 = load volatile <8 x i64>, ptr %.spill52, align 64
  %208 = select <8 x i1> %180, <8 x i64> %206, <8 x i64> %207
  store volatile <8 x i64> %208, ptr %.spill52, align 64
  %209 = and <8 x i1> %180, %203
  %210 = xor <8 x i1> %203, splat (i1 true)
  %211 = and <8 x i1> %180, %210
  %212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %209)
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %211)
  %214 = and i1 %212, %213
  br i1 %214, label %varying.divergent259, label %varying.coherent260

schedule.3:                                       ; preds = %varying.coherent.true265, %scheduler.dispatch.route
  %215 = load <8 x i1>, ptr %current.mask, align 1
  %216 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %215)
  %217 = bitcast <8 x i1> %215 to i8
  %218 = call i8 @llvm.cttz.i8(i8 %217, i1 false)
  %219 = zext i8 %218 to i32
  %220 = select i1 %216, i32 %219, i32 0
  %.spill.load267 = load volatile <8 x i64>, ptr %.spill52, align 64
  %221 = extractvalue { ptr, i64 } %44, 0
  %222 = mul <8 x i64> %.spill.load267, splat (i64 4)
  %223 = getelementptr i8, ptr %221, <8 x i64> %222
  %224 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %223, <8 x i1> %215, <8 x float> zeroinitializer)
  %225 = load <8 x float>, ptr %.slot53, align 32
  %226 = select <8 x i1> %215, <8 x float> %224, <8 x float> %225
  store <8 x float> %226, ptr %.slot53, align 32
  store <8 x i1> %215, ptr %current.mask, align 1
  %227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %215)
  br i1 %227, label %schedule.4, label %scheduler.loop

schedule.4:                                       ; preds = %schedule.3, %varying.coherent.false266, %scheduler.dispatch.route
  %228 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.5:                                       ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %229 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token279 = load i32, ptr %current.token, align 4
  %convergence.token.present280 = icmp ne i32 %convergence.current.token279, 0
  br i1 %convergence.token.present280, label %convergence.cascade277, label %convergence.cascade.exit278

schedule.6:                                       ; preds = %schedule.7, %convergence.target.5.ready, %scheduler.dispatch.route
  %230 = load <8 x i1>, ptr %current.mask, align 1
  %231 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %230)
  %232 = bitcast <8 x i1> %230 to i8
  %233 = call i8 @llvm.cttz.i8(i8 %232, i1 false)
  %234 = zext i8 %233 to i32
  %235 = select i1 %231, i32 %234, i32 0
  %.state294 = load <8 x i64>, ptr %.slot56, align 64
  %236 = icmp slt <8 x i64> %.state294, splat (i64 192)
  %237 = and <8 x i1> %230, %236
  %238 = xor <8 x i1> %236, splat (i1 true)
  %239 = and <8 x i1> %230, %238
  %240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %237)
  %241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %239)
  %242 = and i1 %240, %241
  br i1 %242, label %varying.divergent295, label %varying.coherent296

schedule.7:                                       ; preds = %varying.coherent.true301, %scheduler.dispatch.route
  %243 = load <8 x i1>, ptr %current.mask, align 1
  %244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %243)
  %245 = bitcast <8 x i1> %243 to i8
  %246 = call i8 @llvm.cttz.i8(i8 %245, i1 false)
  %247 = zext i8 %246 to i32
  %248 = select i1 %244, i32 %247, i32 0
  %tile_snapshot.spill.load303 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load303, 0
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load303, 1
  %.state304 = load <8 x i64>, ptr %.slot56, align 64
  %251 = mul <8 x i64> %.state304, splat (i64 32)
  %252 = add <8 x i64> %250, %251
  %253 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %249, 0
  %254 = insertvalue { <8 x ptr>, <8 x i64> } %253, <8 x i64> %252, 1
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %254, 0
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %254, 1
  %257 = getelementptr i8, <8 x ptr> %255, <8 x i64> %256
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %257, <8 x i1> %243)
  %.state305 = load <8 x i64>, ptr %.slot56, align 64
  %258 = add <8 x i64> %.state305, splat (i64 1)
  %259 = load <8 x i64>, ptr %.slot56, align 64
  %260 = select <8 x i1> %243, <8 x i64> %258, <8 x i64> %259
  store <8 x i64> %260, ptr %.slot56, align 64
  store <8 x i1> %243, ptr %current.mask, align 1
  %261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %243)
  br i1 %261, label %schedule.6, label %scheduler.loop

schedule.8:                                       ; preds = %varying.coherent.false302, %scheduler.dispatch.route
  %262 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token308 = load i32, ptr %current.token, align 4
  %convergence.token.present309 = icmp ne i32 %convergence.current.token308, 0
  br i1 %convergence.token.present309, label %convergence.cascade306, label %convergence.cascade.exit307

schedule.9:                                       ; preds = %convergence.target.53.ready, %convergence.target.8.ready, %scheduler.dispatch.route
  %263 = load <8 x i1>, ptr %current.mask, align 1
  %264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %263)
  %265 = bitcast <8 x i1> %263 to i8
  %266 = call i8 @llvm.cttz.i8(i8 %265, i1 false)
  %267 = zext i8 %266 to i32
  %268 = select i1 %264, i32 %267, i32 0
  %.state323 = load <8 x i64>, ptr %.slot57, align 64
  %269 = icmp slt <8 x i64> %.state323, splat (i64 5)
  %270 = and <8 x i1> %263, %269
  %271 = xor <8 x i1> %269, splat (i1 true)
  %272 = and <8 x i1> %263, %271
  %273 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %270)
  %274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %272)
  %275 = and i1 %273, %274
  br i1 %275, label %varying.divergent324, label %varying.coherent325

schedule.10:                                      ; preds = %varying.coherent.true330, %scheduler.dispatch.route
  %276 = load <8 x i1>, ptr %current.mask, align 1
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  %278 = bitcast <8 x i1> %276 to i8
  %279 = call i8 @llvm.cttz.i8(i8 %278, i1 false)
  %280 = zext i8 %279 to i32
  %281 = select i1 %277, i32 %280, i32 0
  %.state332 = load <8 x i64>, ptr %.slot57, align 64
  %282 = select <8 x i1> %276, <8 x i64> %.state332, <8 x i64> zeroinitializer
  %283 = select <8 x i1> %276, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %284 = sdiv <8 x i64> %282, %283
  %285 = mul <8 x i64> %284, splat (i64 16)
  %286 = load <8 x i64>, ptr %.spill66, align 64
  %287 = select <8 x i1> %276, <8 x i64> %285, <8 x i64> %286
  store <8 x i64> %287, ptr %.spill66, align 64
  %288 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %288, 0
  %291 = select <8 x i1> %276, <8 x ptr> %289, <8 x ptr> %290
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %288, 1
  %294 = select <8 x i1> %276, <8 x i64> %292, <8 x i64> %293
  %295 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %291, 0
  %296 = insertvalue { <8 x ptr>, <8 x i64> } %295, <8 x i64> %294, 1
  store volatile { <8 x ptr>, <8 x i64> } %296, ptr %tile_snapshot.spill67, align 64
  %297 = load <8 x i64>, ptr %.slot68, align 64
  %298 = select <8 x i1> %276, <8 x i64> zeroinitializer, <8 x i64> %297
  store <8 x i64> %298, ptr %.slot68, align 64
  store <8 x i1> %276, ptr %current.mask, align 1
  %299 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  br i1 %299, label %schedule.11, label %scheduler.loop

schedule.11:                                      ; preds = %convergence.target.14.ready, %schedule.10, %scheduler.dispatch.route
  %300 = load <8 x i1>, ptr %current.mask, align 1
  %301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %300)
  %302 = bitcast <8 x i1> %300 to i8
  %303 = call i8 @llvm.cttz.i8(i8 %302, i1 false)
  %304 = zext i8 %303 to i32
  %305 = select i1 %301, i32 %304, i32 0
  %.state333 = load <8 x i64>, ptr %.slot68, align 64
  %306 = icmp slt <8 x i64> %.state333, splat (i64 640)
  %307 = and <8 x i1> %300, %306
  %308 = xor <8 x i1> %306, splat (i1 true)
  %309 = and <8 x i1> %300, %308
  %310 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %307)
  %311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %309)
  %312 = and i1 %310, %311
  br i1 %312, label %varying.divergent334, label %varying.coherent335

schedule.12:                                      ; preds = %varying.coherent.true340, %scheduler.dispatch.route
  %313 = load <8 x i1>, ptr %current.mask, align 1
  %314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %313)
  %315 = bitcast <8 x i1> %313 to i8
  %316 = call i8 @llvm.cttz.i8(i8 %315, i1 false)
  %317 = zext i8 %316 to i32
  %318 = select i1 %314, i32 %317, i32 0
  %.state342 = load <8 x i64>, ptr %.slot68, align 64
  %319 = select <8 x i1> %313, <8 x i64> %.state342, <8 x i64> zeroinitializer
  %320 = select <8 x i1> %313, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %321 = srem <8 x i64> %319, %320
  %.state343 = load <8 x i64>, ptr %.slot68, align 64
  %322 = select <8 x i1> %313, <8 x i64> %.state343, <8 x i64> zeroinitializer
  %323 = select <8 x i1> %313, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %324 = sdiv <8 x i64> %322, %323
  %.spill.load344 = load <8 x i64>, ptr %.spill, align 64
  %325 = add <8 x i64> %.spill.load344, zeroinitializer
  %326 = add <8 x i64> zeroinitializer, %325
  %.spill.load345 = load volatile <8 x i64>, ptr %.spill51, align 64
  %327 = add <8 x i64> %.spill.load345, zeroinitializer
  %328 = mul <8 x i64> %326, splat (i64 2)
  %329 = add <8 x i64> %328, %327
  %.spill.load346 = load <8 x i64>, ptr %.spill66, align 64
  %330 = add <8 x i64> %.spill.load346, %324
  %331 = mul <8 x i64> %329, splat (i64 67)
  %332 = add <8 x i64> %331, %330
  %333 = icmp sge <8 x i64> %330, zeroinitializer
  %334 = and <8 x i1> splat (i1 true), %333
  %335 = icmp slt <8 x i64> %330, splat (i64 67)
  %336 = and <8 x i1> %334, %335
  %337 = add <8 x i64> zeroinitializer, %321
  %338 = mul <8 x i64> %332, splat (i64 40)
  %339 = add <8 x i64> %338, %337
  %340 = load volatile <8 x i64>, ptr %.spill69, align 64
  %341 = select <8 x i1> %313, <8 x i64> %339, <8 x i64> %340
  store volatile <8 x i64> %341, ptr %.spill69, align 64
  %342 = and <8 x i1> %313, %336
  %343 = xor <8 x i1> %336, splat (i1 true)
  %344 = and <8 x i1> %313, %343
  %345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %342)
  %346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %344)
  %347 = and i1 %345, %346
  br i1 %347, label %varying.divergent347, label %varying.coherent348

schedule.13:                                      ; preds = %varying.coherent.true353, %scheduler.dispatch.route
  %348 = load <8 x i1>, ptr %current.mask, align 1
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %348)
  %350 = bitcast <8 x i1> %348 to i8
  %351 = call i8 @llvm.cttz.i8(i8 %350, i1 false)
  %352 = zext i8 %351 to i32
  %353 = select i1 %349, i32 %352, i32 0
  %.spill.load355 = load volatile <8 x i64>, ptr %.spill69, align 64
  %354 = extractvalue { ptr, i64 } %50, 0
  %355 = mul <8 x i64> %.spill.load355, splat (i64 4)
  %356 = getelementptr i8, ptr %354, <8 x i64> %355
  %357 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %356, <8 x i1> %348, <8 x float> zeroinitializer)
  %358 = load <8 x float>, ptr %.slot70, align 32
  %359 = select <8 x i1> %348, <8 x float> %357, <8 x float> %358
  store <8 x float> %359, ptr %.slot70, align 32
  store <8 x i1> %348, ptr %current.mask, align 1
  %360 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %348)
  br i1 %360, label %schedule.14, label %scheduler.loop

schedule.14:                                      ; preds = %schedule.13, %varying.coherent.false354, %scheduler.dispatch.route
  %361 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token358 = load i32, ptr %current.token, align 4
  %convergence.token.present359 = icmp ne i32 %convergence.current.token358, 0
  br i1 %convergence.token.present359, label %convergence.cascade356, label %convergence.cascade.exit357

schedule.15:                                      ; preds = %varying.coherent.false341, %scheduler.dispatch.route
  %362 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token379 = load i32, ptr %current.token, align 4
  %convergence.token.present380 = icmp ne i32 %convergence.current.token379, 0
  br i1 %convergence.token.present380, label %convergence.cascade377, label %convergence.cascade.exit378

schedule.16:                                      ; preds = %convergence.target.19.ready, %convergence.target.15.ready, %scheduler.dispatch.route
  %363 = load <8 x i1>, ptr %current.mask, align 1
  %364 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %363)
  %365 = bitcast <8 x i1> %363 to i8
  %366 = call i8 @llvm.cttz.i8(i8 %365, i1 false)
  %367 = zext i8 %366 to i32
  %368 = select i1 %364, i32 %367, i32 0
  %.state394 = load <8 x i64>, ptr %.slot72, align 64
  %369 = icmp slt <8 x i64> %.state394, splat (i64 768)
  %370 = and <8 x i1> %363, %369
  %371 = xor <8 x i1> %369, splat (i1 true)
  %372 = and <8 x i1> %363, %371
  %373 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %370)
  %374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %372)
  %375 = and i1 %373, %374
  br i1 %375, label %varying.divergent395, label %varying.coherent396

schedule.17:                                      ; preds = %varying.coherent.true401, %scheduler.dispatch.route
  %376 = load <8 x i1>, ptr %current.mask, align 1
  %377 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %376)
  %378 = bitcast <8 x i1> %376 to i8
  %379 = call i8 @llvm.cttz.i8(i8 %378, i1 false)
  %380 = zext i8 %379 to i32
  %381 = select i1 %377, i32 %380, i32 0
  %.state403 = load <8 x i64>, ptr %.slot72, align 64
  %382 = select <8 x i1> %376, <8 x i64> %.state403, <8 x i64> zeroinitializer
  %383 = select <8 x i1> %376, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %384 = srem <8 x i64> %382, %383
  %.state404 = load <8 x i64>, ptr %.slot72, align 64
  %385 = select <8 x i1> %376, <8 x i64> %.state404, <8 x i64> zeroinitializer
  %386 = select <8 x i1> %376, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %387 = sdiv <8 x i64> %385, %386
  %.spill.load405 = load <8 x i64>, ptr %.spill, align 64
  %388 = add <8 x i64> %.spill.load405, zeroinitializer
  %389 = add <8 x i64> zeroinitializer, %388
  %.spill.load406 = load volatile <8 x i64>, ptr %.spill51, align 64
  %390 = add <8 x i64> %.spill.load406, zeroinitializer
  %391 = mul <8 x i64> %389, splat (i64 2)
  %392 = add <8 x i64> %391, %390
  %.spill.load407 = load <8 x i64>, ptr %.spill66, align 64
  %393 = add <8 x i64> %.spill.load407, %387
  %394 = mul <8 x i64> %392, splat (i64 67)
  %395 = add <8 x i64> %394, %393
  %396 = icmp sge <8 x i64> %393, zeroinitializer
  %397 = and <8 x i1> splat (i1 true), %396
  %398 = icmp slt <8 x i64> %393, splat (i64 67)
  %399 = and <8 x i1> %397, %398
  %400 = add <8 x i64> zeroinitializer, %384
  %401 = mul <8 x i64> %395, splat (i64 48)
  %402 = add <8 x i64> %401, %400
  %403 = load volatile <8 x i64>, ptr %.spill73, align 64
  %404 = select <8 x i1> %376, <8 x i64> %402, <8 x i64> %403
  store volatile <8 x i64> %404, ptr %.spill73, align 64
  %405 = and <8 x i1> %376, %399
  %406 = xor <8 x i1> %399, splat (i1 true)
  %407 = and <8 x i1> %376, %406
  %408 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %405)
  %409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %407)
  %410 = and i1 %408, %409
  br i1 %410, label %varying.divergent408, label %varying.coherent409

schedule.18:                                      ; preds = %varying.coherent.true414, %scheduler.dispatch.route
  %411 = load <8 x i1>, ptr %current.mask, align 1
  %412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %411)
  %413 = bitcast <8 x i1> %411 to i8
  %414 = call i8 @llvm.cttz.i8(i8 %413, i1 false)
  %415 = zext i8 %414 to i32
  %416 = select i1 %412, i32 %415, i32 0
  %.spill.load416 = load volatile <8 x i64>, ptr %.spill73, align 64
  %417 = extractvalue { ptr, i64 } %56, 0
  %418 = mul <8 x i64> %.spill.load416, splat (i64 4)
  %419 = getelementptr i8, ptr %417, <8 x i64> %418
  %420 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %419, <8 x i1> %411, <8 x float> zeroinitializer)
  %421 = load <8 x float>, ptr %.slot74, align 32
  %422 = select <8 x i1> %411, <8 x float> %420, <8 x float> %421
  store <8 x float> %422, ptr %.slot74, align 32
  store <8 x i1> %411, ptr %current.mask, align 1
  %423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %411)
  br i1 %423, label %schedule.19, label %scheduler.loop

schedule.19:                                      ; preds = %schedule.18, %varying.coherent.false415, %scheduler.dispatch.route
  %424 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token419 = load i32, ptr %current.token, align 4
  %convergence.token.present420 = icmp ne i32 %convergence.current.token419, 0
  br i1 %convergence.token.present420, label %convergence.cascade417, label %convergence.cascade.exit418

schedule.20:                                      ; preds = %varying.coherent.false402, %scheduler.dispatch.route
  %425 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token440 = load i32, ptr %current.token, align 4
  %convergence.token.present441 = icmp ne i32 %convergence.current.token440, 0
  br i1 %convergence.token.present441, label %convergence.cascade438, label %convergence.cascade.exit439

schedule.21:                                      ; preds = %schedule.22, %mma.continue470, %scheduler.dispatch.route
  %426 = load <8 x i1>, ptr %current.mask, align 1
  %427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %426)
  %428 = bitcast <8 x i1> %426 to i8
  %429 = call i8 @llvm.cttz.i8(i8 %428, i1 false)
  %430 = zext i8 %429 to i32
  %431 = select i1 %427, i32 %430, i32 0
  %.state617 = load <8 x i64>, ptr %.slot204, align 64
  %432 = icmp slt <8 x i64> %.state617, splat (i64 16)
  %433 = and <8 x i1> %426, %432
  %434 = xor <8 x i1> %432, splat (i1 true)
  %435 = and <8 x i1> %426, %434
  %436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %433)
  %437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %435)
  %438 = and i1 %436, %437
  br i1 %438, label %varying.divergent618, label %varying.coherent619

schedule.22:                                      ; preds = %varying.coherent.true624, %scheduler.dispatch.route
  %439 = load <8 x i1>, ptr %current.mask, align 1
  %440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %439)
  %441 = bitcast <8 x i1> %439 to i8
  %442 = call i8 @llvm.cttz.i8(i8 %441, i1 false)
  %443 = zext i8 %442 to i32
  %444 = select i1 %440, i32 %443, i32 0
  %.state626 = load <8 x i64>, ptr %.slot204, align 64
  %445 = select <8 x i1> %439, <8 x i64> %.state626, <8 x i64> zeroinitializer
  %446 = select <8 x i1> %439, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %447 = sdiv <8 x i64> %445, %446
  %448 = add <8 x i64> zeroinitializer, %447
  %tile_snapshot.spill.load627 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill203, align 64
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load627, 0
  %450 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load627, 1
  %451 = mul <8 x i64> %448, splat (i64 32)
  %452 = add <8 x i64> %450, %451
  %453 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %449, 0
  %454 = insertvalue { <8 x ptr>, <8 x i64> } %453, <8 x i64> %452, 1
  %455 = extractvalue { <8 x ptr>, <8 x i64> } %454, 0
  %456 = extractvalue { <8 x ptr>, <8 x i64> } %454, 1
  %457 = getelementptr i8, <8 x ptr> %455, <8 x i64> %456
  %458 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %457, <8 x i1> %439, <8 x float> zeroinitializer)
  %.state628 = load <8 x float>, ptr %.slot205, align 32
  %459 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state628, <8 x float> %458)
  %.state629 = load <8 x i64>, ptr %.slot204, align 64
  %460 = add <8 x i64> %.state629, splat (i64 1)
  %461 = load <8 x i64>, ptr %.slot204, align 64
  %462 = select <8 x i1> %439, <8 x i64> %460, <8 x i64> %461
  store <8 x i64> %462, ptr %.slot204, align 64
  %463 = load <8 x float>, ptr %.slot205, align 32
  %464 = select <8 x i1> %439, <8 x float> %459, <8 x float> %463
  store <8 x float> %464, ptr %.slot205, align 32
  store <8 x i1> %439, ptr %current.mask, align 1
  %465 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %439)
  br i1 %465, label %schedule.21, label %scheduler.loop

schedule.23:                                      ; preds = %varying.coherent.false625, %scheduler.dispatch.route
  %466 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token632 = load i32, ptr %current.token, align 4
  %convergence.token.present633 = icmp ne i32 %convergence.current.token632, 0
  br i1 %convergence.token.present633, label %convergence.cascade630, label %convergence.cascade.exit631

schedule.24:                                      ; preds = %schedule.25, %convergence.target.23.ready, %scheduler.dispatch.route
  %467 = load <8 x i1>, ptr %current.mask, align 1
  %468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %467)
  %469 = bitcast <8 x i1> %467 to i8
  %470 = call i8 @llvm.cttz.i8(i8 %469, i1 false)
  %471 = zext i8 %470 to i32
  %472 = select i1 %468, i32 %471, i32 0
  %.state647 = load <8 x i64>, ptr %.slot206, align 64
  %473 = icmp slt <8 x i64> %.state647, splat (i64 16)
  %474 = and <8 x i1> %467, %473
  %475 = xor <8 x i1> %473, splat (i1 true)
  %476 = and <8 x i1> %467, %475
  %477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %474)
  %478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  %479 = and i1 %477, %478
  br i1 %479, label %varying.divergent648, label %varying.coherent649

schedule.25:                                      ; preds = %varying.coherent.true654, %scheduler.dispatch.route
  %480 = load <8 x i1>, ptr %current.mask, align 1
  %481 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %480)
  %482 = bitcast <8 x i1> %480 to i8
  %483 = call i8 @llvm.cttz.i8(i8 %482, i1 false)
  %484 = zext i8 %483 to i32
  %485 = select i1 %481, i32 %484, i32 0
  %.state656 = load <8 x i64>, ptr %.slot206, align 64
  %486 = select <8 x i1> %480, <8 x i64> %.state656, <8 x i64> zeroinitializer
  %487 = select <8 x i1> %480, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %488 = sdiv <8 x i64> %486, %487
  %489 = add <8 x i64> splat (i64 16), %488
  %tile_snapshot.spill.load657 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill203, align 64
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load657, 0
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load657, 1
  %492 = mul <8 x i64> %489, splat (i64 32)
  %493 = add <8 x i64> %491, %492
  %494 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %490, 0
  %495 = insertvalue { <8 x ptr>, <8 x i64> } %494, <8 x i64> %493, 1
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %495, 0
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %495, 1
  %498 = getelementptr i8, <8 x ptr> %496, <8 x i64> %497
  %499 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %498, <8 x i1> %480, <8 x float> zeroinitializer)
  %.state658 = load <8 x float>, ptr %.slot207, align 32
  %500 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state658, <8 x float> %499)
  %.state659 = load <8 x i64>, ptr %.slot206, align 64
  %501 = add <8 x i64> %.state659, splat (i64 1)
  %502 = load <8 x i64>, ptr %.slot206, align 64
  %503 = select <8 x i1> %480, <8 x i64> %501, <8 x i64> %502
  store <8 x i64> %503, ptr %.slot206, align 64
  %504 = load <8 x float>, ptr %.slot207, align 32
  %505 = select <8 x i1> %480, <8 x float> %500, <8 x float> %504
  store <8 x float> %505, ptr %.slot207, align 32
  store <8 x i1> %480, ptr %current.mask, align 1
  %506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %480)
  br i1 %506, label %schedule.24, label %scheduler.loop

schedule.26:                                      ; preds = %varying.coherent.false655, %scheduler.dispatch.route
  %507 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token662 = load i32, ptr %current.token, align 4
  %convergence.token.present663 = icmp ne i32 %convergence.current.token662, 0
  br i1 %convergence.token.present663, label %convergence.cascade660, label %convergence.cascade.exit661

schedule.27:                                      ; preds = %schedule.28, %convergence.target.26.ready, %scheduler.dispatch.route
  %508 = load <8 x i1>, ptr %current.mask, align 1
  %509 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %508)
  %510 = bitcast <8 x i1> %508 to i8
  %511 = call i8 @llvm.cttz.i8(i8 %510, i1 false)
  %512 = zext i8 %511 to i32
  %513 = select i1 %509, i32 %512, i32 0
  %.state677 = load <8 x i64>, ptr %.slot208, align 64
  %514 = icmp slt <8 x i64> %.state677, splat (i64 16)
  %515 = and <8 x i1> %508, %514
  %516 = xor <8 x i1> %514, splat (i1 true)
  %517 = and <8 x i1> %508, %516
  %518 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %515)
  %519 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %517)
  %520 = and i1 %518, %519
  br i1 %520, label %varying.divergent678, label %varying.coherent679

schedule.28:                                      ; preds = %varying.coherent.true684, %scheduler.dispatch.route
  %521 = load <8 x i1>, ptr %current.mask, align 1
  %522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %521)
  %523 = bitcast <8 x i1> %521 to i8
  %524 = call i8 @llvm.cttz.i8(i8 %523, i1 false)
  %525 = zext i8 %524 to i32
  %526 = select i1 %522, i32 %525, i32 0
  %.state686 = load <8 x i64>, ptr %.slot208, align 64
  %527 = select <8 x i1> %521, <8 x i64> %.state686, <8 x i64> zeroinitializer
  %528 = select <8 x i1> %521, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %529 = sdiv <8 x i64> %527, %528
  %530 = add <8 x i64> splat (i64 32), %529
  %tile_snapshot.spill.load687 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill203, align 64
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load687, 0
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load687, 1
  %533 = mul <8 x i64> %530, splat (i64 32)
  %534 = add <8 x i64> %532, %533
  %535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %531, 0
  %536 = insertvalue { <8 x ptr>, <8 x i64> } %535, <8 x i64> %534, 1
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %536, 0
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %536, 1
  %539 = getelementptr i8, <8 x ptr> %537, <8 x i64> %538
  %540 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %539, <8 x i1> %521, <8 x float> zeroinitializer)
  %.state688 = load <8 x float>, ptr %.slot209, align 32
  %541 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state688, <8 x float> %540)
  %.state689 = load <8 x i64>, ptr %.slot208, align 64
  %542 = add <8 x i64> %.state689, splat (i64 1)
  %543 = load <8 x i64>, ptr %.slot208, align 64
  %544 = select <8 x i1> %521, <8 x i64> %542, <8 x i64> %543
  store <8 x i64> %544, ptr %.slot208, align 64
  %545 = load <8 x float>, ptr %.slot209, align 32
  %546 = select <8 x i1> %521, <8 x float> %541, <8 x float> %545
  store <8 x float> %546, ptr %.slot209, align 32
  store <8 x i1> %521, ptr %current.mask, align 1
  %547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %521)
  br i1 %547, label %schedule.27, label %scheduler.loop

schedule.29:                                      ; preds = %varying.coherent.false685, %scheduler.dispatch.route
  %548 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token692 = load i32, ptr %current.token, align 4
  %convergence.token.present693 = icmp ne i32 %convergence.current.token692, 0
  br i1 %convergence.token.present693, label %convergence.cascade690, label %convergence.cascade.exit691

schedule.30:                                      ; preds = %schedule.31, %convergence.target.29.ready, %scheduler.dispatch.route
  %549 = load <8 x i1>, ptr %current.mask, align 1
  %550 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %549)
  %551 = bitcast <8 x i1> %549 to i8
  %552 = call i8 @llvm.cttz.i8(i8 %551, i1 false)
  %553 = zext i8 %552 to i32
  %554 = select i1 %550, i32 %553, i32 0
  %.state707 = load <8 x i64>, ptr %.slot210, align 64
  %555 = icmp slt <8 x i64> %.state707, splat (i64 16)
  %556 = and <8 x i1> %549, %555
  %557 = xor <8 x i1> %555, splat (i1 true)
  %558 = and <8 x i1> %549, %557
  %559 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %556)
  %560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %558)
  %561 = and i1 %559, %560
  br i1 %561, label %varying.divergent708, label %varying.coherent709

schedule.31:                                      ; preds = %varying.coherent.true714, %scheduler.dispatch.route
  %562 = load <8 x i1>, ptr %current.mask, align 1
  %563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %562)
  %564 = bitcast <8 x i1> %562 to i8
  %565 = call i8 @llvm.cttz.i8(i8 %564, i1 false)
  %566 = zext i8 %565 to i32
  %567 = select i1 %563, i32 %566, i32 0
  %.state716 = load <8 x i64>, ptr %.slot210, align 64
  %568 = select <8 x i1> %562, <8 x i64> %.state716, <8 x i64> zeroinitializer
  %569 = select <8 x i1> %562, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %570 = sdiv <8 x i64> %568, %569
  %571 = add <8 x i64> splat (i64 48), %570
  %tile_snapshot.spill.load717 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill203, align 64
  %572 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load717, 0
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load717, 1
  %574 = mul <8 x i64> %571, splat (i64 32)
  %575 = add <8 x i64> %573, %574
  %576 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %572, 0
  %577 = insertvalue { <8 x ptr>, <8 x i64> } %576, <8 x i64> %575, 1
  %578 = extractvalue { <8 x ptr>, <8 x i64> } %577, 0
  %579 = extractvalue { <8 x ptr>, <8 x i64> } %577, 1
  %580 = getelementptr i8, <8 x ptr> %578, <8 x i64> %579
  %581 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %580, <8 x i1> %562, <8 x float> zeroinitializer)
  %.state718 = load <8 x float>, ptr %.slot211, align 32
  %582 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state718, <8 x float> %581)
  %.state719 = load <8 x i64>, ptr %.slot210, align 64
  %583 = add <8 x i64> %.state719, splat (i64 1)
  %584 = load <8 x i64>, ptr %.slot210, align 64
  %585 = select <8 x i1> %562, <8 x i64> %583, <8 x i64> %584
  store <8 x i64> %585, ptr %.slot210, align 64
  %586 = load <8 x float>, ptr %.slot211, align 32
  %587 = select <8 x i1> %562, <8 x float> %582, <8 x float> %586
  store <8 x float> %587, ptr %.slot211, align 32
  store <8 x i1> %562, ptr %current.mask, align 1
  %588 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %562)
  br i1 %588, label %schedule.30, label %scheduler.loop

schedule.32:                                      ; preds = %varying.coherent.false715, %scheduler.dispatch.route
  %589 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token722 = load i32, ptr %current.token, align 4
  %convergence.token.present723 = icmp ne i32 %convergence.current.token722, 0
  br i1 %convergence.token.present723, label %convergence.cascade720, label %convergence.cascade.exit721

schedule.33:                                      ; preds = %schedule.34, %convergence.target.32.ready, %scheduler.dispatch.route
  %590 = load <8 x i1>, ptr %current.mask, align 1
  %591 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %590)
  %592 = bitcast <8 x i1> %590 to i8
  %593 = call i8 @llvm.cttz.i8(i8 %592, i1 false)
  %594 = zext i8 %593 to i32
  %595 = select i1 %591, i32 %594, i32 0
  %.state956 = load <8 x i64>, ptr %.slot222, align 64
  %596 = icmp slt <8 x i64> %.state956, splat (i64 16)
  %597 = and <8 x i1> %590, %596
  %598 = xor <8 x i1> %596, splat (i1 true)
  %599 = and <8 x i1> %590, %598
  %600 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %597)
  %601 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %599)
  %602 = and i1 %600, %601
  br i1 %602, label %varying.divergent957, label %varying.coherent958

schedule.34:                                      ; preds = %varying.coherent.true963, %scheduler.dispatch.route
  %603 = load <8 x i1>, ptr %current.mask, align 1
  %604 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %603)
  %605 = bitcast <8 x i1> %603 to i8
  %606 = call i8 @llvm.cttz.i8(i8 %605, i1 false)
  %607 = zext i8 %606 to i32
  %608 = select i1 %604, i32 %607, i32 0
  %.state965 = load <8 x i64>, ptr %.slot222, align 64
  %609 = select <8 x i1> %603, <8 x i64> %.state965, <8 x i64> zeroinitializer
  %610 = select <8 x i1> %603, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %611 = sdiv <8 x i64> %609, %610
  %612 = add <8 x i64> zeroinitializer, %611
  %tile_snapshot.spill.load966 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill217, align 64
  %613 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load966, 0
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load966, 1
  %615 = mul <8 x i64> %612, splat (i64 4)
  %616 = add <8 x i64> %614, %615
  %617 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %613, 0
  %618 = insertvalue { <8 x ptr>, <8 x i64> } %617, <8 x i64> %616, 1
  %619 = extractvalue { <8 x ptr>, <8 x i64> } %618, 0
  %620 = extractvalue { <8 x ptr>, <8 x i64> } %618, 1
  %621 = getelementptr i8, <8 x ptr> %619, <8 x i64> %620
  %622 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %621, <8 x i1> %603, <8 x float> zeroinitializer)
  %.state967 = load <8 x float>, ptr %.slot223, align 32
  %623 = fadd <8 x float> %.state967, %622
  %.state968 = load <8 x i64>, ptr %.slot222, align 64
  %624 = add <8 x i64> %.state968, splat (i64 1)
  %625 = load <8 x i64>, ptr %.slot222, align 64
  %626 = select <8 x i1> %603, <8 x i64> %624, <8 x i64> %625
  store <8 x i64> %626, ptr %.slot222, align 64
  %627 = load <8 x float>, ptr %.slot223, align 32
  %628 = select <8 x i1> %603, <8 x float> %623, <8 x float> %627
  store <8 x float> %628, ptr %.slot223, align 32
  store <8 x i1> %603, ptr %current.mask, align 1
  %629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %603)
  br i1 %629, label %schedule.33, label %scheduler.loop

schedule.35:                                      ; preds = %varying.coherent.false964, %scheduler.dispatch.route
  %630 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token971 = load i32, ptr %current.token, align 4
  %convergence.token.present972 = icmp ne i32 %convergence.current.token971, 0
  br i1 %convergence.token.present972, label %convergence.cascade969, label %convergence.cascade.exit970

schedule.36:                                      ; preds = %schedule.37, %convergence.target.35.ready, %scheduler.dispatch.route
  %631 = load <8 x i1>, ptr %current.mask, align 1
  %632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %631)
  %633 = bitcast <8 x i1> %631 to i8
  %634 = call i8 @llvm.cttz.i8(i8 %633, i1 false)
  %635 = zext i8 %634 to i32
  %636 = select i1 %632, i32 %635, i32 0
  %.state986 = load <8 x i64>, ptr %.slot224, align 64
  %637 = icmp slt <8 x i64> %.state986, splat (i64 16)
  %638 = and <8 x i1> %631, %637
  %639 = xor <8 x i1> %637, splat (i1 true)
  %640 = and <8 x i1> %631, %639
  %641 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %638)
  %642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %640)
  %643 = and i1 %641, %642
  br i1 %643, label %varying.divergent987, label %varying.coherent988

schedule.37:                                      ; preds = %varying.coherent.true993, %scheduler.dispatch.route
  %644 = load <8 x i1>, ptr %current.mask, align 1
  %645 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %644)
  %646 = bitcast <8 x i1> %644 to i8
  %647 = call i8 @llvm.cttz.i8(i8 %646, i1 false)
  %648 = zext i8 %647 to i32
  %649 = select i1 %645, i32 %648, i32 0
  %.state995 = load <8 x i64>, ptr %.slot224, align 64
  %650 = select <8 x i1> %644, <8 x i64> %.state995, <8 x i64> zeroinitializer
  %651 = select <8 x i1> %644, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %652 = sdiv <8 x i64> %650, %651
  %653 = add <8 x i64> splat (i64 16), %652
  %tile_snapshot.spill.load996 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill217, align 64
  %654 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load996, 0
  %655 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load996, 1
  %656 = mul <8 x i64> %653, splat (i64 4)
  %657 = add <8 x i64> %655, %656
  %658 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %654, 0
  %659 = insertvalue { <8 x ptr>, <8 x i64> } %658, <8 x i64> %657, 1
  %660 = extractvalue { <8 x ptr>, <8 x i64> } %659, 0
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %659, 1
  %662 = getelementptr i8, <8 x ptr> %660, <8 x i64> %661
  %663 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %662, <8 x i1> %644, <8 x float> zeroinitializer)
  %.state997 = load <8 x float>, ptr %.slot225, align 32
  %664 = fadd <8 x float> %.state997, %663
  %.state998 = load <8 x i64>, ptr %.slot224, align 64
  %665 = add <8 x i64> %.state998, splat (i64 1)
  %666 = load <8 x i64>, ptr %.slot224, align 64
  %667 = select <8 x i1> %644, <8 x i64> %665, <8 x i64> %666
  store <8 x i64> %667, ptr %.slot224, align 64
  %668 = load <8 x float>, ptr %.slot225, align 32
  %669 = select <8 x i1> %644, <8 x float> %664, <8 x float> %668
  store <8 x float> %669, ptr %.slot225, align 32
  store <8 x i1> %644, ptr %current.mask, align 1
  %670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %644)
  br i1 %670, label %schedule.36, label %scheduler.loop

schedule.38:                                      ; preds = %varying.coherent.false994, %scheduler.dispatch.route
  %671 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1001 = load i32, ptr %current.token, align 4
  %convergence.token.present1002 = icmp ne i32 %convergence.current.token1001, 0
  br i1 %convergence.token.present1002, label %convergence.cascade999, label %convergence.cascade.exit1000

schedule.39:                                      ; preds = %schedule.40, %convergence.target.38.ready, %scheduler.dispatch.route
  %672 = load <8 x i1>, ptr %current.mask, align 1
  %673 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %672)
  %674 = bitcast <8 x i1> %672 to i8
  %675 = call i8 @llvm.cttz.i8(i8 %674, i1 false)
  %676 = zext i8 %675 to i32
  %677 = select i1 %673, i32 %676, i32 0
  %.state1016 = load <8 x i64>, ptr %.slot226, align 64
  %678 = icmp slt <8 x i64> %.state1016, splat (i64 16)
  %679 = and <8 x i1> %672, %678
  %680 = xor <8 x i1> %678, splat (i1 true)
  %681 = and <8 x i1> %672, %680
  %682 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %679)
  %683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %681)
  %684 = and i1 %682, %683
  br i1 %684, label %varying.divergent1017, label %varying.coherent1018

schedule.40:                                      ; preds = %varying.coherent.true1023, %scheduler.dispatch.route
  %685 = load <8 x i1>, ptr %current.mask, align 1
  %686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %685)
  %687 = bitcast <8 x i1> %685 to i8
  %688 = call i8 @llvm.cttz.i8(i8 %687, i1 false)
  %689 = zext i8 %688 to i32
  %690 = select i1 %686, i32 %689, i32 0
  %.state1025 = load <8 x i64>, ptr %.slot226, align 64
  %691 = select <8 x i1> %685, <8 x i64> %.state1025, <8 x i64> zeroinitializer
  %692 = select <8 x i1> %685, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %693 = sdiv <8 x i64> %691, %692
  %694 = add <8 x i64> splat (i64 32), %693
  %tile_snapshot.spill.load1026 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill217, align 64
  %695 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1026, 0
  %696 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1026, 1
  %697 = mul <8 x i64> %694, splat (i64 4)
  %698 = add <8 x i64> %696, %697
  %699 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %695, 0
  %700 = insertvalue { <8 x ptr>, <8 x i64> } %699, <8 x i64> %698, 1
  %701 = extractvalue { <8 x ptr>, <8 x i64> } %700, 0
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %700, 1
  %703 = getelementptr i8, <8 x ptr> %701, <8 x i64> %702
  %704 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %703, <8 x i1> %685, <8 x float> zeroinitializer)
  %.state1027 = load <8 x float>, ptr %.slot227, align 32
  %705 = fadd <8 x float> %.state1027, %704
  %.state1028 = load <8 x i64>, ptr %.slot226, align 64
  %706 = add <8 x i64> %.state1028, splat (i64 1)
  %707 = load <8 x i64>, ptr %.slot226, align 64
  %708 = select <8 x i1> %685, <8 x i64> %706, <8 x i64> %707
  store <8 x i64> %708, ptr %.slot226, align 64
  %709 = load <8 x float>, ptr %.slot227, align 32
  %710 = select <8 x i1> %685, <8 x float> %705, <8 x float> %709
  store <8 x float> %710, ptr %.slot227, align 32
  store <8 x i1> %685, ptr %current.mask, align 1
  %711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %685)
  br i1 %711, label %schedule.39, label %scheduler.loop

schedule.41:                                      ; preds = %varying.coherent.false1024, %scheduler.dispatch.route
  %712 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1031 = load i32, ptr %current.token, align 4
  %convergence.token.present1032 = icmp ne i32 %convergence.current.token1031, 0
  br i1 %convergence.token.present1032, label %convergence.cascade1029, label %convergence.cascade.exit1030

schedule.42:                                      ; preds = %schedule.43, %convergence.target.41.ready, %scheduler.dispatch.route
  %713 = load <8 x i1>, ptr %current.mask, align 1
  %714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %713)
  %715 = bitcast <8 x i1> %713 to i8
  %716 = call i8 @llvm.cttz.i8(i8 %715, i1 false)
  %717 = zext i8 %716 to i32
  %718 = select i1 %714, i32 %717, i32 0
  %.state1046 = load <8 x i64>, ptr %.slot228, align 64
  %719 = icmp slt <8 x i64> %.state1046, splat (i64 16)
  %720 = and <8 x i1> %713, %719
  %721 = xor <8 x i1> %719, splat (i1 true)
  %722 = and <8 x i1> %713, %721
  %723 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %720)
  %724 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %722)
  %725 = and i1 %723, %724
  br i1 %725, label %varying.divergent1047, label %varying.coherent1048

schedule.43:                                      ; preds = %varying.coherent.true1053, %scheduler.dispatch.route
  %726 = load <8 x i1>, ptr %current.mask, align 1
  %727 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %726)
  %728 = bitcast <8 x i1> %726 to i8
  %729 = call i8 @llvm.cttz.i8(i8 %728, i1 false)
  %730 = zext i8 %729 to i32
  %731 = select i1 %727, i32 %730, i32 0
  %.state1055 = load <8 x i64>, ptr %.slot228, align 64
  %732 = select <8 x i1> %726, <8 x i64> %.state1055, <8 x i64> zeroinitializer
  %733 = select <8 x i1> %726, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %734 = sdiv <8 x i64> %732, %733
  %735 = add <8 x i64> splat (i64 48), %734
  %tile_snapshot.spill.load1056 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill217, align 64
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1056, 0
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1056, 1
  %738 = mul <8 x i64> %735, splat (i64 4)
  %739 = add <8 x i64> %737, %738
  %740 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %736, 0
  %741 = insertvalue { <8 x ptr>, <8 x i64> } %740, <8 x i64> %739, 1
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %741, 0
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %741, 1
  %744 = getelementptr i8, <8 x ptr> %742, <8 x i64> %743
  %745 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %744, <8 x i1> %726, <8 x float> zeroinitializer)
  %.state1057 = load <8 x float>, ptr %.slot229, align 32
  %746 = fadd <8 x float> %.state1057, %745
  %.state1058 = load <8 x i64>, ptr %.slot228, align 64
  %747 = add <8 x i64> %.state1058, splat (i64 1)
  %748 = load <8 x i64>, ptr %.slot228, align 64
  %749 = select <8 x i1> %726, <8 x i64> %747, <8 x i64> %748
  store <8 x i64> %749, ptr %.slot228, align 64
  %750 = load <8 x float>, ptr %.slot229, align 32
  %751 = select <8 x i1> %726, <8 x float> %746, <8 x float> %750
  store <8 x float> %751, ptr %.slot229, align 32
  store <8 x i1> %726, ptr %current.mask, align 1
  %752 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %726)
  br i1 %752, label %schedule.42, label %scheduler.loop

schedule.44:                                      ; preds = %varying.coherent.false1054, %scheduler.dispatch.route
  %753 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1061 = load i32, ptr %current.token, align 4
  %convergence.token.present1062 = icmp ne i32 %convergence.current.token1061, 0
  br i1 %convergence.token.present1062, label %convergence.cascade1059, label %convergence.cascade.exit1060

schedule.45:                                      ; preds = %schedule.46, %convergence.target.44.ready, %scheduler.dispatch.route
  %754 = load <8 x i1>, ptr %current.mask, align 1
  %755 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %754)
  %756 = bitcast <8 x i1> %754 to i8
  %757 = call i8 @llvm.cttz.i8(i8 %756, i1 false)
  %758 = zext i8 %757 to i32
  %759 = select i1 %755, i32 %758, i32 0
  %.state1084 = load <8 x i64>, ptr %.slot235, align 64
  %760 = icmp slt <8 x i64> %.state1084, splat (i64 192)
  %761 = and <8 x i1> %754, %760
  %762 = xor <8 x i1> %760, splat (i1 true)
  %763 = and <8 x i1> %754, %762
  %764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %761)
  %765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %763)
  %766 = and i1 %764, %765
  br i1 %766, label %varying.divergent1085, label %varying.coherent1086

schedule.46:                                      ; preds = %varying.coherent.true1091, %scheduler.dispatch.route
  %767 = load <8 x i1>, ptr %current.mask, align 1
  %768 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %767)
  %769 = bitcast <8 x i1> %767 to i8
  %770 = call i8 @llvm.cttz.i8(i8 %769, i1 false)
  %771 = zext i8 %770 to i32
  %772 = select i1 %768, i32 %771, i32 0
  %.state1093 = load <8 x i64>, ptr %.slot235, align 64
  %773 = select <8 x i1> %767, <8 x i64> %.state1093, <8 x i64> zeroinitializer
  %774 = select <8 x i1> %767, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %775 = srem <8 x i64> %773, %774
  %.state1094 = load <8 x i64>, ptr %.slot235, align 64
  %776 = select <8 x i1> %767, <8 x i64> %.state1094, <8 x i64> zeroinitializer
  %777 = select <8 x i1> %767, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %778 = sdiv <8 x i64> %776, %777
  %779 = add <8 x i64> zeroinitializer, %778
  %780 = mul <8 x i64> %779, splat (i64 48)
  %781 = add <8 x i64> %780, %775
  %tile_snapshot.spill.load1095 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1095, 0
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1095, 1
  %784 = mul <8 x i64> %781, splat (i64 32)
  %785 = add <8 x i64> %783, %784
  %786 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %782, 0
  %787 = insertvalue { <8 x ptr>, <8 x i64> } %786, <8 x i64> %785, 1
  %788 = extractvalue { <8 x ptr>, <8 x i64> } %787, 0
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %787, 1
  %790 = getelementptr i8, <8 x ptr> %788, <8 x i64> %789
  %791 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %790, <8 x i1> %767, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1096 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill216, align 64
  %792 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1096, 0
  %793 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1096, 1
  %794 = mul <8 x i64> %779, splat (i64 32)
  %795 = add <8 x i64> %793, %794
  %796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %792, 0
  %797 = insertvalue { <8 x ptr>, <8 x i64> } %796, <8 x i64> %795, 1
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %797, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %797, 1
  %800 = getelementptr i8, <8 x ptr> %798, <8 x i64> %799
  %801 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %800, <8 x i1> %767, <8 x float> zeroinitializer)
  %802 = fmul <8 x float> %791, %801
  %tile_snapshot.spill.load1097 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill234, align 64
  %803 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1097, 0
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1097, 1
  %.state1098 = load <8 x i64>, ptr %.slot235, align 64
  %805 = mul <8 x i64> %.state1098, splat (i64 4)
  %806 = add <8 x i64> %804, %805
  %807 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %803, 0
  %808 = insertvalue { <8 x ptr>, <8 x i64> } %807, <8 x i64> %806, 1
  %809 = extractvalue { <8 x ptr>, <8 x i64> } %808, 0
  %810 = extractvalue { <8 x ptr>, <8 x i64> } %808, 1
  %811 = getelementptr i8, <8 x ptr> %809, <8 x i64> %810
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %802, <8 x ptr> align 1 %811, <8 x i1> %767)
  %.state1099 = load <8 x i64>, ptr %.slot235, align 64
  %812 = add <8 x i64> %.state1099, splat (i64 1)
  %813 = load <8 x i64>, ptr %.slot235, align 64
  %814 = select <8 x i1> %767, <8 x i64> %812, <8 x i64> %813
  store <8 x i64> %814, ptr %.slot235, align 64
  store <8 x i1> %767, ptr %current.mask, align 1
  %815 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %767)
  br i1 %815, label %schedule.45, label %scheduler.loop

schedule.47:                                      ; preds = %varying.coherent.false1092, %scheduler.dispatch.route
  %816 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1102 = load i32, ptr %current.token, align 4
  %convergence.token.present1103 = icmp ne i32 %convergence.current.token1102, 0
  br i1 %convergence.token.present1103, label %convergence.cascade1100, label %convergence.cascade.exit1101

schedule.48:                                      ; preds = %schedule.49, %mma.continue1135, %scheduler.dispatch.route
  %817 = load <8 x i1>, ptr %current.mask, align 1
  %818 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %817)
  %819 = bitcast <8 x i1> %817 to i8
  %820 = call i8 @llvm.cttz.i8(i8 %819, i1 false)
  %821 = zext i8 %820 to i32
  %822 = select i1 %818, i32 %821, i32 0
  %.state1136 = load <8 x i64>, ptr %.slot237, align 64
  %823 = icmp slt <8 x i64> %.state1136, splat (i64 192)
  %824 = and <8 x i1> %817, %823
  %825 = xor <8 x i1> %823, splat (i1 true)
  %826 = and <8 x i1> %817, %825
  %827 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %824)
  %828 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %826)
  %829 = and i1 %827, %828
  br i1 %829, label %varying.divergent1137, label %varying.coherent1138

schedule.49:                                      ; preds = %varying.coherent.true1143, %scheduler.dispatch.route
  %830 = load <8 x i1>, ptr %current.mask, align 1
  %831 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %830)
  %832 = bitcast <8 x i1> %830 to i8
  %833 = call i8 @llvm.cttz.i8(i8 %832, i1 false)
  %834 = zext i8 %833 to i32
  %835 = select i1 %831, i32 %834, i32 0
  %tile_snapshot.spill.load1145 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill236, align 64
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1145, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1145, 1
  %.state1146 = load <8 x i64>, ptr %.slot237, align 64
  %838 = mul <8 x i64> %.state1146, splat (i64 4)
  %839 = add <8 x i64> %837, %838
  %840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %836, 0
  %841 = insertvalue { <8 x ptr>, <8 x i64> } %840, <8 x i64> %839, 1
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %841, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %841, 1
  %844 = getelementptr i8, <8 x ptr> %842, <8 x i64> %843
  %845 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %844, <8 x i1> %830, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1147 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1147, 0
  %847 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1147, 1
  %.state1148 = load <8 x i64>, ptr %.slot237, align 64
  %848 = mul <8 x i64> %.state1148, splat (i64 32)
  %849 = add <8 x i64> %847, %848
  %850 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %846, 0
  %851 = insertvalue { <8 x ptr>, <8 x i64> } %850, <8 x i64> %849, 1
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %851, 0
  %853 = extractvalue { <8 x ptr>, <8 x i64> } %851, 1
  %854 = getelementptr i8, <8 x ptr> %852, <8 x i64> %853
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %845, <8 x ptr> align 1 %854, <8 x i1> %830)
  %.state1149 = load <8 x i64>, ptr %.slot237, align 64
  %855 = add <8 x i64> %.state1149, splat (i64 1)
  %856 = load <8 x i64>, ptr %.slot237, align 64
  %857 = select <8 x i1> %830, <8 x i64> %855, <8 x i64> %856
  store <8 x i64> %857, ptr %.slot237, align 64
  store <8 x i1> %830, ptr %current.mask, align 1
  %858 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %830)
  br i1 %858, label %schedule.48, label %scheduler.loop

schedule.50:                                      ; preds = %varying.coherent.false1144, %scheduler.dispatch.route
  %859 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1152 = load i32, ptr %current.token, align 4
  %convergence.token.present1153 = icmp ne i32 %convergence.current.token1152, 0
  br i1 %convergence.token.present1153, label %convergence.cascade1150, label %convergence.cascade.exit1151

schedule.51:                                      ; preds = %schedule.52, %convergence.target.50.ready, %scheduler.dispatch.route
  %860 = load <8 x i1>, ptr %current.mask, align 1
  %861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %860)
  %862 = bitcast <8 x i1> %860 to i8
  %863 = call i8 @llvm.cttz.i8(i8 %862, i1 false)
  %864 = zext i8 %863 to i32
  %865 = select i1 %861, i32 %864, i32 0
  %.state1167 = load <8 x i64>, ptr %.slot238, align 64
  %866 = icmp slt <8 x i64> %.state1167, splat (i64 192)
  %867 = and <8 x i1> %860, %866
  %868 = xor <8 x i1> %866, splat (i1 true)
  %869 = and <8 x i1> %860, %868
  %870 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %867)
  %871 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %869)
  %872 = and i1 %870, %871
  br i1 %872, label %varying.divergent1168, label %varying.coherent1169

schedule.52:                                      ; preds = %varying.coherent.true1174, %scheduler.dispatch.route
  %873 = load <8 x i1>, ptr %current.mask, align 1
  %874 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %873)
  %875 = bitcast <8 x i1> %873 to i8
  %876 = call i8 @llvm.cttz.i8(i8 %875, i1 false)
  %877 = zext i8 %876 to i32
  %878 = select i1 %874, i32 %877, i32 0
  %tile_snapshot.spill.load1176 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %879 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1176, 0
  %880 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1176, 1
  %.state1177 = load <8 x i64>, ptr %.slot238, align 64
  %881 = mul <8 x i64> %.state1177, splat (i64 32)
  %882 = add <8 x i64> %880, %881
  %883 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %879, 0
  %884 = insertvalue { <8 x ptr>, <8 x i64> } %883, <8 x i64> %882, 1
  %885 = extractvalue { <8 x ptr>, <8 x i64> } %884, 0
  %886 = extractvalue { <8 x ptr>, <8 x i64> } %884, 1
  %887 = getelementptr i8, <8 x ptr> %885, <8 x i64> %886
  %888 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %887, <8 x i1> %873, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %889 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1178, 0
  %890 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1178, 1
  %.state1179 = load <8 x i64>, ptr %.slot238, align 64
  %891 = mul <8 x i64> %.state1179, splat (i64 32)
  %892 = add <8 x i64> %890, %891
  %893 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %889, 0
  %894 = insertvalue { <8 x ptr>, <8 x i64> } %893, <8 x i64> %892, 1
  %895 = extractvalue { <8 x ptr>, <8 x i64> } %894, 0
  %896 = extractvalue { <8 x ptr>, <8 x i64> } %894, 1
  %897 = getelementptr i8, <8 x ptr> %895, <8 x i64> %896
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %888, <8 x ptr> align 1 %897, <8 x i1> %873)
  %.state1180 = load <8 x i64>, ptr %.slot238, align 64
  %898 = add <8 x i64> %.state1180, splat (i64 1)
  %899 = load <8 x i64>, ptr %.slot238, align 64
  %900 = select <8 x i1> %873, <8 x i64> %898, <8 x i64> %899
  store <8 x i64> %900, ptr %.slot238, align 64
  store <8 x i1> %873, ptr %current.mask, align 1
  %901 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %873)
  br i1 %901, label %schedule.51, label %scheduler.loop

schedule.53:                                      ; preds = %varying.coherent.false1175, %scheduler.dispatch.route
  %902 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1183 = load i32, ptr %current.token, align 4
  %convergence.token.present1184 = icmp ne i32 %convergence.current.token1183, 0
  br i1 %convergence.token.present1184, label %convergence.cascade1181, label %convergence.cascade.exit1182

schedule.54:                                      ; preds = %varying.coherent.false331, %scheduler.dispatch.route
  %903 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1209 = load i32, ptr %current.token, align 4
  %convergence.token.present1210 = icmp ne i32 %convergence.current.token1209, 0
  br i1 %convergence.token.present1210, label %convergence.cascade1207, label %convergence.cascade.exit1208

schedule.55:                                      ; preds = %convergence.target.58.ready, %convergence.target.54.ready, %scheduler.dispatch.route
  %904 = load <8 x i1>, ptr %current.mask, align 1
  %905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %904)
  %906 = bitcast <8 x i1> %904 to i8
  %907 = call i8 @llvm.cttz.i8(i8 %906, i1 false)
  %908 = zext i8 %907 to i32
  %909 = select i1 %905, i32 %908, i32 0
  %.state1236 = load <8 x i64>, ptr %.slot240, align 64
  %910 = icmp slt <8 x i64> %.state1236, splat (i64 192)
  %911 = and <8 x i1> %904, %910
  %912 = xor <8 x i1> %910, splat (i1 true)
  %913 = and <8 x i1> %904, %912
  %914 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %911)
  %915 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %913)
  %916 = and i1 %914, %915
  br i1 %916, label %varying.divergent1237, label %varying.coherent1238

schedule.56:                                      ; preds = %varying.coherent.true1243, %scheduler.dispatch.route
  %917 = load <8 x i1>, ptr %current.mask, align 1
  %918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %917)
  %919 = bitcast <8 x i1> %917 to i8
  %920 = call i8 @llvm.cttz.i8(i8 %919, i1 false)
  %921 = zext i8 %920 to i32
  %922 = select i1 %918, i32 %921, i32 0
  %.state1245 = load <8 x i64>, ptr %.slot240, align 64
  %923 = select <8 x i1> %917, <8 x i64> %.state1245, <8 x i64> zeroinitializer
  %924 = select <8 x i1> %917, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %925 = srem <8 x i64> %923, %924
  %.state1246 = load <8 x i64>, ptr %.slot240, align 64
  %926 = select <8 x i1> %917, <8 x i64> %.state1246, <8 x i64> zeroinitializer
  %927 = select <8 x i1> %917, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %928 = sdiv <8 x i64> %926, %927
  %.spill.load1247 = load <8 x i64>, ptr %.spill, align 64
  %929 = add <8 x i64> %.spill.load1247, zeroinitializer
  %930 = add <8 x i64> zeroinitializer, %929
  %.spill.load1248 = load volatile <8 x i64>, ptr %.spill49, align 64
  %931 = add <8 x i64> %.spill.load1248, zeroinitializer
  %932 = mul <8 x i64> %930, splat (i64 6)
  %933 = add <8 x i64> %932, %931
  %.spill.load1249 = load <8 x i64>, ptr %.spill50, align 64
  %934 = add <8 x i64> %.spill.load1249, %928
  %935 = mul <8 x i64> %933, splat (i64 17)
  %936 = add <8 x i64> %935, %934
  %937 = icmp sge <8 x i64> %934, zeroinitializer
  %938 = and <8 x i1> splat (i1 true), %937
  %939 = icmp slt <8 x i64> %934, splat (i64 17)
  %940 = and <8 x i1> %938, %939
  %941 = add <8 x i64> zeroinitializer, %925
  %942 = mul <8 x i64> %936, splat (i64 48)
  %943 = add <8 x i64> %942, %941
  %944 = load volatile <8 x i64>, ptr %.spill241, align 64
  %945 = select <8 x i1> %917, <8 x i64> %943, <8 x i64> %944
  store volatile <8 x i64> %945, ptr %.spill241, align 64
  %946 = add <8 x i64> zeroinitializer, %928
  %947 = mul <8 x i64> %946, splat (i64 48)
  %948 = add <8 x i64> %947, %925
  %tile_snapshot.spill.load1250 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1250, 0
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1250, 1
  %951 = mul <8 x i64> %948, splat (i64 32)
  %952 = add <8 x i64> %950, %951
  %953 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %949, 0
  %954 = insertvalue { <8 x ptr>, <8 x i64> } %953, <8 x i64> %952, 1
  %955 = extractvalue { <8 x ptr>, <8 x i64> } %954, 0
  %956 = extractvalue { <8 x ptr>, <8 x i64> } %954, 1
  %957 = getelementptr i8, <8 x ptr> %955, <8 x i64> %956
  %958 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %957, <8 x i1> %917, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1251 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill239, align 64
  %959 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1251, 0
  %960 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1251, 1
  %961 = mul <8 x i64> %946, splat (i64 32)
  %962 = add <8 x i64> %960, %961
  %963 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %959, 0
  %964 = insertvalue { <8 x ptr>, <8 x i64> } %963, <8 x i64> %962, 1
  %965 = extractvalue { <8 x ptr>, <8 x i64> } %964, 0
  %966 = extractvalue { <8 x ptr>, <8 x i64> } %964, 1
  %967 = getelementptr i8, <8 x ptr> %965, <8 x i64> %966
  %968 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %967, <8 x i1> %917, <8 x float> zeroinitializer)
  %969 = fdiv <8 x float> %958, %968
  %970 = load volatile <8 x float>, ptr %.spill242, align 32
  %971 = select <8 x i1> %917, <8 x float> %969, <8 x float> %970
  store volatile <8 x float> %971, ptr %.spill242, align 32
  %972 = and <8 x i1> %917, %940
  %973 = xor <8 x i1> %940, splat (i1 true)
  %974 = and <8 x i1> %917, %973
  %975 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %972)
  %976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %974)
  %977 = and i1 %975, %976
  br i1 %977, label %varying.divergent1252, label %varying.coherent1253

schedule.57:                                      ; preds = %varying.coherent.true1258, %scheduler.dispatch.route
  %978 = load <8 x i1>, ptr %current.mask, align 1
  %979 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %978)
  %980 = bitcast <8 x i1> %978 to i8
  %981 = call i8 @llvm.cttz.i8(i8 %980, i1 false)
  %982 = zext i8 %981 to i32
  %983 = select i1 %979, i32 %982, i32 0
  %.spill.load1260 = load volatile <8 x i64>, ptr %.spill241, align 64
  %.spill.load1261 = load volatile <8 x float>, ptr %.spill242, align 32
  %984 = extractvalue { ptr, i64 } %62, 0
  %985 = mul <8 x i64> %.spill.load1260, splat (i64 4)
  %986 = getelementptr i8, ptr %984, <8 x i64> %985
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load1261, <8 x ptr> align 1 %986, <8 x i1> %978)
  store <8 x i1> %978, ptr %current.mask, align 1
  %987 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %978)
  br i1 %987, label %schedule.58, label %scheduler.loop

schedule.58:                                      ; preds = %schedule.57, %varying.coherent.false1259, %scheduler.dispatch.route
  %988 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1264 = load i32, ptr %current.token, align 4
  %convergence.token.present1265 = icmp ne i32 %convergence.current.token1264, 0
  br i1 %convergence.token.present1265, label %convergence.cascade1262, label %convergence.cascade.exit1263

schedule.59:                                      ; preds = %varying.coherent.false1244, %scheduler.dispatch.route
  %989 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1282 = load i32, ptr %current.token, align 4
  %convergence.token.present1283 = icmp ne i32 %convergence.current.token1282, 0
  br i1 %convergence.token.present1283, label %convergence.cascade1280, label %convergence.cascade.exit1281

varying.divergent:                                ; preds = %schedule.1
  %990 = load i32, ptr %current.token, align 4
  %991 = icmp ne i32 %990, 0
  %992 = sub i32 %990, 1
  %993 = select i1 %991, i32 %992, i32 0
  %994 = load i8, ptr %frame.active, align 1
  %995 = trunc i32 %993 to i8
  %996 = shl i8 1, %995
  %997 = and i8 %994, %996
  %998 = icmp ne i8 %997, 0
  %999 = load <8 x i32>, ptr %frame.static.id, align 32
  %1000 = extractelement <8 x i32> %999, i32 %993
  %1001 = icmp eq i32 %1000, 0
  %1002 = and i1 %998, %1001
  %1003 = and i1 %991, %1002
  %1004 = xor i1 %1003, true
  %1005 = and i1 true, %1004
  %1006 = xor i8 %994, -1
  %1007 = icmp ne i8 %1006, 0
  %1008 = xor i1 %1007, true
  %1009 = and i1 %1005, %1008
  br i1 %1009, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.1
  br i1 %177, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %1010 = call i8 @llvm.cttz.i8(i8 %1006, i1 false)
  %1011 = zext i8 %1010 to i32
  %1012 = select i1 %1007, i32 %1011, i32 0
  %1013 = trunc i32 %1012 to i8
  %1014 = shl i8 1, %1013
  %1015 = or i8 %994, %1014
  %1016 = select i1 %1005, i8 %1015, i8 %994
  store i8 %1016, ptr %frame.active, align 1
  %1017 = load <8 x i32>, ptr %frame.static.id, align 32
  %1018 = extractelement <8 x i32> %1017, i32 %1012
  %1019 = select i1 %1005, i32 0, i32 %1018
  %1020 = load <8 x i32>, ptr %frame.static.id, align 32
  %1021 = insertelement <8 x i32> %1020, i32 %1019, i32 %1012
  store <8 x i32> %1021, ptr %frame.static.id, align 32
  %1022 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1023 = extractelement <8 x i32> %1022, i32 %1012
  %1024 = select i1 %1005, i32 %990, i32 %1023
  %1025 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1026 = insertelement <8 x i32> %1025, i32 %1024, i32 %1012
  store <8 x i32> %1026, ptr %frame.parent.token, align 32
  %1027 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1012
  %1028 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1012
  %1029 = load <8 x i1>, ptr %1027, align 1
  %1030 = load <8 x i1>, ptr %1028, align 1
  %1031 = select i1 %1005, <8 x i1> %167, <8 x i1> %1029
  store <8 x i1> %1031, ptr %1027, align 1
  %1032 = select i1 %1005, <8 x i1> zeroinitializer, <8 x i1> %1030
  store <8 x i1> %1032, ptr %1028, align 1
  %1033 = add i32 %1012, 1
  %1034 = select i1 %1003, i32 %990, i32 %1033
  %1035 = select i1 true, i32 %1034, i32 %990
  store i32 %1035, ptr %current.token, align 4
  %1036 = load i32, ptr %current.token, align 4
  %1037 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %174)
  %1038 = load i32, ptr %ready.count, align 4
  %1039 = icmp uge i32 %1038, 8
  %1040 = and i1 %1037, %1039
  br i1 %1040, label %ready.overflow.trap253, label %ready.overflow.resume254

ready.overflow.trap253:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume254:                         ; preds = %convergence.overflow.resume
  %1041 = select i1 %1037, i32 %1038, i32 0
  %1042 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1041
  %1043 = load <8 x i1>, ptr %1042, align 1
  %1044 = select i1 %1037, <8 x i1> %174, <8 x i1> %1043
  store <8 x i1> %1044, ptr %1042, align 1
  %1045 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1041
  %1046 = load i32, ptr %1045, align 4
  %1047 = select i1 %1037, i32 2, i32 %1046
  store i32 %1047, ptr %1045, align 4
  %1048 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1041
  %1049 = load i32, ptr %1048, align 4
  %1050 = select i1 %1037, i32 %1036, i32 %1049
  store i32 %1050, ptr %1048, align 4
  %1051 = add i32 %1038, 1
  %1052 = select i1 %1037, i32 %1051, i32 %1038
  store i32 %1052, ptr %ready.count, align 4
  %1053 = load <8 x i1>, ptr %runnable.mask, align 1
  %1054 = or <8 x i1> %1053, %174
  store <8 x i1> %1054, ptr %runnable.mask, align 1
  store <8 x i1> %176, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %167, ptr %current.mask, align 1
  %1055 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %167)
  br i1 %1055, label %schedule.2, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %167, ptr %current.mask, align 1
  %1056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %167)
  br i1 %1056, label %schedule.5, label %scheduler.loop

varying.divergent259:                             ; preds = %schedule.2
  %1057 = load i32, ptr %current.token, align 4
  %1058 = icmp ne i32 %1057, 0
  %1059 = sub i32 %1057, 1
  %1060 = select i1 %1058, i32 %1059, i32 0
  %1061 = load i8, ptr %frame.active, align 1
  %1062 = trunc i32 %1060 to i8
  %1063 = shl i8 1, %1062
  %1064 = and i8 %1061, %1063
  %1065 = icmp ne i8 %1064, 0
  %1066 = load <8 x i32>, ptr %frame.static.id, align 32
  %1067 = extractelement <8 x i32> %1066, i32 %1060
  %1068 = icmp eq i32 %1067, 1
  %1069 = and i1 %1065, %1068
  %1070 = and i1 %1058, %1069
  %1071 = xor i1 %1070, true
  %1072 = and i1 true, %1071
  %1073 = xor i8 %1061, -1
  %1074 = icmp ne i8 %1073, 0
  %1075 = xor i1 %1074, true
  %1076 = and i1 %1072, %1075
  br i1 %1076, label %convergence.overflow.trap261, label %convergence.overflow.resume262

varying.coherent260:                              ; preds = %schedule.2
  br i1 %212, label %varying.coherent.true265, label %varying.coherent.false266

convergence.overflow.trap261:                     ; preds = %varying.divergent259
  call void @llvm.trap()
  unreachable

convergence.overflow.resume262:                   ; preds = %varying.divergent259
  %1077 = call i8 @llvm.cttz.i8(i8 %1073, i1 false)
  %1078 = zext i8 %1077 to i32
  %1079 = select i1 %1074, i32 %1078, i32 0
  %1080 = trunc i32 %1079 to i8
  %1081 = shl i8 1, %1080
  %1082 = or i8 %1061, %1081
  %1083 = select i1 %1072, i8 %1082, i8 %1061
  store i8 %1083, ptr %frame.active, align 1
  %1084 = load <8 x i32>, ptr %frame.static.id, align 32
  %1085 = extractelement <8 x i32> %1084, i32 %1079
  %1086 = select i1 %1072, i32 1, i32 %1085
  %1087 = load <8 x i32>, ptr %frame.static.id, align 32
  %1088 = insertelement <8 x i32> %1087, i32 %1086, i32 %1079
  store <8 x i32> %1088, ptr %frame.static.id, align 32
  %1089 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1090 = extractelement <8 x i32> %1089, i32 %1079
  %1091 = select i1 %1072, i32 %1057, i32 %1090
  %1092 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1093 = insertelement <8 x i32> %1092, i32 %1091, i32 %1079
  store <8 x i32> %1093, ptr %frame.parent.token, align 32
  %1094 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1079
  %1095 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1079
  %1096 = load <8 x i1>, ptr %1094, align 1
  %1097 = load <8 x i1>, ptr %1095, align 1
  %1098 = select i1 %1072, <8 x i1> %180, <8 x i1> %1096
  store <8 x i1> %1098, ptr %1094, align 1
  %1099 = select i1 %1072, <8 x i1> zeroinitializer, <8 x i1> %1097
  store <8 x i1> %1099, ptr %1095, align 1
  %1100 = add i32 %1079, 1
  %1101 = select i1 %1070, i32 %1057, i32 %1100
  %1102 = select i1 true, i32 %1101, i32 %1057
  store i32 %1102, ptr %current.token, align 4
  %1103 = load <8 x float>, ptr %.slot53, align 32
  %1104 = select <8 x i1> %211, <8 x float> zeroinitializer, <8 x float> %1103
  store <8 x float> %1104, ptr %.slot53, align 32
  %1105 = load i32, ptr %current.token, align 4
  %1106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %209)
  %1107 = load i32, ptr %ready.count, align 4
  %1108 = icmp uge i32 %1107, 8
  %1109 = and i1 %1106, %1108
  br i1 %1109, label %ready.overflow.trap263, label %ready.overflow.resume264

ready.overflow.trap263:                           ; preds = %convergence.overflow.resume262
  call void @llvm.trap()
  unreachable

ready.overflow.resume264:                         ; preds = %convergence.overflow.resume262
  %1110 = select i1 %1106, i32 %1107, i32 0
  %1111 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1110
  %1112 = load <8 x i1>, ptr %1111, align 1
  %1113 = select i1 %1106, <8 x i1> %209, <8 x i1> %1112
  store <8 x i1> %1113, ptr %1111, align 1
  %1114 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1110
  %1115 = load i32, ptr %1114, align 4
  %1116 = select i1 %1106, i32 3, i32 %1115
  store i32 %1116, ptr %1114, align 4
  %1117 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1110
  %1118 = load i32, ptr %1117, align 4
  %1119 = select i1 %1106, i32 %1105, i32 %1118
  store i32 %1119, ptr %1117, align 4
  %1120 = add i32 %1107, 1
  %1121 = select i1 %1106, i32 %1120, i32 %1107
  store i32 %1121, ptr %ready.count, align 4
  %1122 = load <8 x i1>, ptr %runnable.mask, align 1
  %1123 = or <8 x i1> %1122, %209
  store <8 x i1> %1123, ptr %runnable.mask, align 1
  store <8 x i1> %211, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true265:                         ; preds = %varying.coherent260
  store <8 x i1> %180, ptr %current.mask, align 1
  %1124 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %180)
  br i1 %1124, label %schedule.3, label %scheduler.loop

varying.coherent.false266:                        ; preds = %varying.coherent260
  %1125 = load <8 x float>, ptr %.slot53, align 32
  %1126 = select <8 x i1> %180, <8 x float> zeroinitializer, <8 x float> %1125
  store <8 x float> %1126, ptr %.slot53, align 32
  store <8 x i1> %180, ptr %current.mask, align 1
  %1127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %180)
  br i1 %1127, label %schedule.4, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.flow = phi <8 x i1> [ %228, %schedule.4 ], [ %1170, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.4 ], [ %1171, %convergence.cascade ]
  %1128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %1129 = load i32, ptr %current.token, align 4
  %1130 = icmp ne i32 %1129, 0
  %1131 = and i1 %1128, %1130
  %1132 = sub i32 %1129, 1
  %1133 = select i1 %1131, i32 %1132, i32 0
  %1134 = load i8, ptr %frame.active, align 1
  %1135 = trunc i32 %1133 to i8
  %1136 = shl i8 1, %1135
  %1137 = and i8 %1134, %1136
  %1138 = icmp ne i8 %1137, 0
  %1139 = load <8 x i32>, ptr %frame.static.id, align 32
  %1140 = extractelement <8 x i32> %1139, i32 %1133
  %convergence.target.pointer = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1140
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %1141 = icmp eq i32 %convergence.dynamic.target, 4
  %1142 = and i1 %1138, %1141
  %1143 = and i1 %1131, %1142
  %1144 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1133
  %1145 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1133
  %1146 = load <8 x i1>, ptr %1144, align 1
  %1147 = load <8 x i1>, ptr %1145, align 1
  %1148 = or <8 x i1> %1147, %convergence.cascade.flow
  %1149 = load <8 x i1>, ptr %live.mask, align 1
  %1150 = and <8 x i1> %1146, %1149
  %1151 = icmp eq <8 x i1> %1148, %1150
  %1152 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1151)
  %1153 = and i1 %1143, %1152
  %1154 = select i1 %1153, <8 x i1> zeroinitializer, <8 x i1> %1148
  %1155 = select i1 %1143, <8 x i1> %1154, <8 x i1> %1147
  store <8 x i1> %1155, ptr %1145, align 1
  %1156 = select i1 %1153, <8 x i1> zeroinitializer, <8 x i1> %1146
  store <8 x i1> %1156, ptr %1144, align 1
  %1157 = trunc i32 %1133 to i8
  %1158 = shl i8 1, %1157
  %1159 = xor i8 %1158, -1
  %1160 = and i8 %1134, %1159
  %1161 = select i1 %1153, i8 %1160, i8 %1134
  store i8 %1161, ptr %frame.active, align 1
  %.splatinsert268 = insertelement <8 x i1> poison, i1 %1143, i64 0
  %.splat269 = shufflevector <8 x i1> %.splatinsert268, <8 x i1> poison, <8 x i32> zeroinitializer
  %1162 = and <8 x i1> %convergence.cascade.flow, %.splat269
  %1163 = load <8 x i1>, ptr %runnable.mask, align 1
  %1164 = xor <8 x i1> %1162, splat (i1 true)
  %1165 = and <8 x i1> %1163, %1164
  store <8 x i1> %1165, ptr %runnable.mask, align 1
  %.splatinsert270 = insertelement <8 x i1> poison, i1 %1153, i64 0
  %.splat271 = shufflevector <8 x i1> %.splatinsert270, <8 x i1> poison, <8 x i32> zeroinitializer
  %1166 = select <8 x i1> %.splat271, <8 x i1> %1148, <8 x i1> zeroinitializer
  %1167 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1168 = extractelement <8 x i32> %1167, i32 %1133
  %1169 = select i1 %1153, i32 %1168, i32 %1129
  store i32 %1169, ptr %current.token, align 4
  %.splatinsert272 = insertelement <8 x i1> poison, i1 %1143, i64 0
  %.splat273 = shufflevector <8 x i1> %.splatinsert272, <8 x i1> poison, <8 x i32> zeroinitializer
  %1170 = select <8 x i1> %.splat273, <8 x i1> %1166, <8 x i1> %convergence.cascade.flow
  %1171 = add i32 %convergence.cascade.depth, 1
  %1172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1170)
  %1173 = icmp ult i32 %1171, 8
  %1174 = and i1 %1172, %1173
  %1175 = and i1 %1143, %1174
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %1176 = and i1 %1175, %convergence.parent.present
  br i1 %1176, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.4
  %convergence.cascade.result = phi <8 x i1> [ %228, %schedule.4 ], [ %1170, %convergence.cascade ]
  %1177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1177, label %convergence.target.4.ready, label %scheduler.loop

convergence.target.4.ready:                       ; preds = %convergence.cascade.exit
  %1178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %1179 = bitcast <8 x i1> %convergence.cascade.result to i8
  %1180 = call i8 @llvm.cttz.i8(i8 %1179, i1 false)
  %1181 = zext i8 %1180 to i32
  %1182 = select i1 %1178, i32 %1181, i32 0
  %tile_snapshot.spill.load = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state274 = load <8 x i64>, ptr %.slot, align 64
  %1185 = mul <8 x i64> %.state274, splat (i64 4)
  %1186 = add <8 x i64> %1184, %1185
  %1187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1183, 0
  %1188 = insertvalue { <8 x ptr>, <8 x i64> } %1187, <8 x i64> %1186, 1
  %.state275 = load <8 x float>, ptr %.slot53, align 32
  %1189 = extractvalue { <8 x ptr>, <8 x i64> } %1188, 0
  %1190 = extractvalue { <8 x ptr>, <8 x i64> } %1188, 1
  %1191 = getelementptr i8, <8 x ptr> %1189, <8 x i64> %1190
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state275, <8 x ptr> align 1 %1191, <8 x i1> %convergence.cascade.result)
  %.state276 = load <8 x i64>, ptr %.slot, align 64
  %1192 = add <8 x i64> %.state276, splat (i64 1)
  %1193 = load <8 x i64>, ptr %.slot, align 64
  %1194 = select <8 x i1> %convergence.cascade.result, <8 x i64> %1192, <8 x i64> %1193
  store <8 x i64> %1194, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %1195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %1195, label %schedule.1, label %scheduler.loop

convergence.cascade277:                           ; preds = %convergence.cascade277, %schedule.5
  %convergence.cascade.flow281 = phi <8 x i1> [ %229, %schedule.5 ], [ %1238, %convergence.cascade277 ]
  %convergence.cascade.depth282 = phi i32 [ 0, %schedule.5 ], [ %1239, %convergence.cascade277 ]
  %1196 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow281)
  %1197 = load i32, ptr %current.token, align 4
  %1198 = icmp ne i32 %1197, 0
  %1199 = and i1 %1196, %1198
  %1200 = sub i32 %1197, 1
  %1201 = select i1 %1199, i32 %1200, i32 0
  %1202 = load i8, ptr %frame.active, align 1
  %1203 = trunc i32 %1201 to i8
  %1204 = shl i8 1, %1203
  %1205 = and i8 %1202, %1204
  %1206 = icmp ne i8 %1205, 0
  %1207 = load <8 x i32>, ptr %frame.static.id, align 32
  %1208 = extractelement <8 x i32> %1207, i32 %1201
  %convergence.target.pointer283 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1208
  %convergence.dynamic.target284 = load i32, ptr %convergence.target.pointer283, align 4
  %1209 = icmp eq i32 %convergence.dynamic.target284, 5
  %1210 = and i1 %1206, %1209
  %1211 = and i1 %1199, %1210
  %1212 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1201
  %1213 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1201
  %1214 = load <8 x i1>, ptr %1212, align 1
  %1215 = load <8 x i1>, ptr %1213, align 1
  %1216 = or <8 x i1> %1215, %convergence.cascade.flow281
  %1217 = load <8 x i1>, ptr %live.mask, align 1
  %1218 = and <8 x i1> %1214, %1217
  %1219 = icmp eq <8 x i1> %1216, %1218
  %1220 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1219)
  %1221 = and i1 %1211, %1220
  %1222 = select i1 %1221, <8 x i1> zeroinitializer, <8 x i1> %1216
  %1223 = select i1 %1211, <8 x i1> %1222, <8 x i1> %1215
  store <8 x i1> %1223, ptr %1213, align 1
  %1224 = select i1 %1221, <8 x i1> zeroinitializer, <8 x i1> %1214
  store <8 x i1> %1224, ptr %1212, align 1
  %1225 = trunc i32 %1201 to i8
  %1226 = shl i8 1, %1225
  %1227 = xor i8 %1226, -1
  %1228 = and i8 %1202, %1227
  %1229 = select i1 %1221, i8 %1228, i8 %1202
  store i8 %1229, ptr %frame.active, align 1
  %.splatinsert285 = insertelement <8 x i1> poison, i1 %1211, i64 0
  %.splat286 = shufflevector <8 x i1> %.splatinsert285, <8 x i1> poison, <8 x i32> zeroinitializer
  %1230 = and <8 x i1> %convergence.cascade.flow281, %.splat286
  %1231 = load <8 x i1>, ptr %runnable.mask, align 1
  %1232 = xor <8 x i1> %1230, splat (i1 true)
  %1233 = and <8 x i1> %1231, %1232
  store <8 x i1> %1233, ptr %runnable.mask, align 1
  %.splatinsert287 = insertelement <8 x i1> poison, i1 %1221, i64 0
  %.splat288 = shufflevector <8 x i1> %.splatinsert287, <8 x i1> poison, <8 x i32> zeroinitializer
  %1234 = select <8 x i1> %.splat288, <8 x i1> %1216, <8 x i1> zeroinitializer
  %1235 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1236 = extractelement <8 x i32> %1235, i32 %1201
  %1237 = select i1 %1221, i32 %1236, i32 %1197
  store i32 %1237, ptr %current.token, align 4
  %.splatinsert289 = insertelement <8 x i1> poison, i1 %1211, i64 0
  %.splat290 = shufflevector <8 x i1> %.splatinsert289, <8 x i1> poison, <8 x i32> zeroinitializer
  %1238 = select <8 x i1> %.splat290, <8 x i1> %1234, <8 x i1> %convergence.cascade.flow281
  %1239 = add i32 %convergence.cascade.depth282, 1
  %1240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1238)
  %1241 = icmp ult i32 %1239, 8
  %1242 = and i1 %1240, %1241
  %1243 = and i1 %1211, %1242
  %convergence.parent.token291 = load i32, ptr %current.token, align 4
  %convergence.parent.present292 = icmp ne i32 %convergence.parent.token291, 0
  %1244 = and i1 %1243, %convergence.parent.present292
  br i1 %1244, label %convergence.cascade277, label %convergence.cascade.exit278

convergence.cascade.exit278:                      ; preds = %convergence.cascade277, %schedule.5
  %convergence.cascade.result293 = phi <8 x i1> [ %229, %schedule.5 ], [ %1238, %convergence.cascade277 ]
  %1245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result293)
  br i1 %1245, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit278
  %1246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result293)
  %1247 = bitcast <8 x i1> %convergence.cascade.result293 to i8
  %1248 = call i8 @llvm.cttz.i8(i8 %1247, i1 false)
  %1249 = zext i8 %1248 to i32
  %1250 = select i1 %1246, i32 %1249, i32 0
  %1251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %1252 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1253 = extractvalue { <8 x ptr>, <8 x i64> } %1251, 0
  %1254 = select <8 x i1> %convergence.cascade.result293, <8 x ptr> %1252, <8 x ptr> %1253
  %1255 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1256 = extractvalue { <8 x ptr>, <8 x i64> } %1251, 1
  %1257 = select <8 x i1> %convergence.cascade.result293, <8 x i64> %1255, <8 x i64> %1256
  %1258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1254, 0
  %1259 = insertvalue { <8 x ptr>, <8 x i64> } %1258, <8 x i64> %1257, 1
  store { <8 x ptr>, <8 x i64> } %1259, ptr %tile_snapshot.spill54, align 64
  %1260 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill55, align 64
  %1261 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1262 = extractvalue { <8 x ptr>, <8 x i64> } %1260, 0
  %1263 = select <8 x i1> %convergence.cascade.result293, <8 x ptr> %1261, <8 x ptr> %1262
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1265 = extractvalue { <8 x ptr>, <8 x i64> } %1260, 1
  %1266 = select <8 x i1> %convergence.cascade.result293, <8 x i64> %1264, <8 x i64> %1265
  %1267 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1263, 0
  %1268 = insertvalue { <8 x ptr>, <8 x i64> } %1267, <8 x i64> %1266, 1
  store volatile { <8 x ptr>, <8 x i64> } %1268, ptr %tile_snapshot.spill55, align 64
  %1269 = load <8 x i64>, ptr %.slot56, align 64
  %1270 = select <8 x i1> %convergence.cascade.result293, <8 x i64> zeroinitializer, <8 x i64> %1269
  store <8 x i64> %1270, ptr %.slot56, align 64
  store <8 x i1> %convergence.cascade.result293, ptr %current.mask, align 1
  %1271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result293)
  br i1 %1271, label %schedule.6, label %scheduler.loop

varying.divergent295:                             ; preds = %schedule.6
  %1272 = load i32, ptr %current.token, align 4
  %1273 = icmp ne i32 %1272, 0
  %1274 = sub i32 %1272, 1
  %1275 = select i1 %1273, i32 %1274, i32 0
  %1276 = load i8, ptr %frame.active, align 1
  %1277 = trunc i32 %1275 to i8
  %1278 = shl i8 1, %1277
  %1279 = and i8 %1276, %1278
  %1280 = icmp ne i8 %1279, 0
  %1281 = load <8 x i32>, ptr %frame.static.id, align 32
  %1282 = extractelement <8 x i32> %1281, i32 %1275
  %1283 = icmp eq i32 %1282, 2
  %1284 = and i1 %1280, %1283
  %1285 = and i1 %1273, %1284
  %1286 = xor i1 %1285, true
  %1287 = and i1 true, %1286
  %1288 = xor i8 %1276, -1
  %1289 = icmp ne i8 %1288, 0
  %1290 = xor i1 %1289, true
  %1291 = and i1 %1287, %1290
  br i1 %1291, label %convergence.overflow.trap297, label %convergence.overflow.resume298

varying.coherent296:                              ; preds = %schedule.6
  br i1 %240, label %varying.coherent.true301, label %varying.coherent.false302

convergence.overflow.trap297:                     ; preds = %varying.divergent295
  call void @llvm.trap()
  unreachable

convergence.overflow.resume298:                   ; preds = %varying.divergent295
  %1292 = call i8 @llvm.cttz.i8(i8 %1288, i1 false)
  %1293 = zext i8 %1292 to i32
  %1294 = select i1 %1289, i32 %1293, i32 0
  %1295 = trunc i32 %1294 to i8
  %1296 = shl i8 1, %1295
  %1297 = or i8 %1276, %1296
  %1298 = select i1 %1287, i8 %1297, i8 %1276
  store i8 %1298, ptr %frame.active, align 1
  %1299 = load <8 x i32>, ptr %frame.static.id, align 32
  %1300 = extractelement <8 x i32> %1299, i32 %1294
  %1301 = select i1 %1287, i32 2, i32 %1300
  %1302 = load <8 x i32>, ptr %frame.static.id, align 32
  %1303 = insertelement <8 x i32> %1302, i32 %1301, i32 %1294
  store <8 x i32> %1303, ptr %frame.static.id, align 32
  %1304 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1305 = extractelement <8 x i32> %1304, i32 %1294
  %1306 = select i1 %1287, i32 %1272, i32 %1305
  %1307 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1308 = insertelement <8 x i32> %1307, i32 %1306, i32 %1294
  store <8 x i32> %1308, ptr %frame.parent.token, align 32
  %1309 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1294
  %1310 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1294
  %1311 = load <8 x i1>, ptr %1309, align 1
  %1312 = load <8 x i1>, ptr %1310, align 1
  %1313 = select i1 %1287, <8 x i1> %230, <8 x i1> %1311
  store <8 x i1> %1313, ptr %1309, align 1
  %1314 = select i1 %1287, <8 x i1> zeroinitializer, <8 x i1> %1312
  store <8 x i1> %1314, ptr %1310, align 1
  %1315 = add i32 %1294, 1
  %1316 = select i1 %1285, i32 %1272, i32 %1315
  %1317 = select i1 true, i32 %1316, i32 %1272
  store i32 %1317, ptr %current.token, align 4
  %1318 = load i32, ptr %current.token, align 4
  %1319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %237)
  %1320 = load i32, ptr %ready.count, align 4
  %1321 = icmp uge i32 %1320, 8
  %1322 = and i1 %1319, %1321
  br i1 %1322, label %ready.overflow.trap299, label %ready.overflow.resume300

ready.overflow.trap299:                           ; preds = %convergence.overflow.resume298
  call void @llvm.trap()
  unreachable

ready.overflow.resume300:                         ; preds = %convergence.overflow.resume298
  %1323 = select i1 %1319, i32 %1320, i32 0
  %1324 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1323
  %1325 = load <8 x i1>, ptr %1324, align 1
  %1326 = select i1 %1319, <8 x i1> %237, <8 x i1> %1325
  store <8 x i1> %1326, ptr %1324, align 1
  %1327 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1323
  %1328 = load i32, ptr %1327, align 4
  %1329 = select i1 %1319, i32 7, i32 %1328
  store i32 %1329, ptr %1327, align 4
  %1330 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1323
  %1331 = load i32, ptr %1330, align 4
  %1332 = select i1 %1319, i32 %1318, i32 %1331
  store i32 %1332, ptr %1330, align 4
  %1333 = add i32 %1320, 1
  %1334 = select i1 %1319, i32 %1333, i32 %1320
  store i32 %1334, ptr %ready.count, align 4
  %1335 = load <8 x i1>, ptr %runnable.mask, align 1
  %1336 = or <8 x i1> %1335, %237
  store <8 x i1> %1336, ptr %runnable.mask, align 1
  store <8 x i1> %239, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true301:                         ; preds = %varying.coherent296
  store <8 x i1> %230, ptr %current.mask, align 1
  %1337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %230)
  br i1 %1337, label %schedule.7, label %scheduler.loop

varying.coherent.false302:                        ; preds = %varying.coherent296
  store <8 x i1> %230, ptr %current.mask, align 1
  %1338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %230)
  br i1 %1338, label %schedule.8, label %scheduler.loop

convergence.cascade306:                           ; preds = %convergence.cascade306, %schedule.8
  %convergence.cascade.flow310 = phi <8 x i1> [ %262, %schedule.8 ], [ %1381, %convergence.cascade306 ]
  %convergence.cascade.depth311 = phi i32 [ 0, %schedule.8 ], [ %1382, %convergence.cascade306 ]
  %1339 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow310)
  %1340 = load i32, ptr %current.token, align 4
  %1341 = icmp ne i32 %1340, 0
  %1342 = and i1 %1339, %1341
  %1343 = sub i32 %1340, 1
  %1344 = select i1 %1342, i32 %1343, i32 0
  %1345 = load i8, ptr %frame.active, align 1
  %1346 = trunc i32 %1344 to i8
  %1347 = shl i8 1, %1346
  %1348 = and i8 %1345, %1347
  %1349 = icmp ne i8 %1348, 0
  %1350 = load <8 x i32>, ptr %frame.static.id, align 32
  %1351 = extractelement <8 x i32> %1350, i32 %1344
  %convergence.target.pointer312 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1351
  %convergence.dynamic.target313 = load i32, ptr %convergence.target.pointer312, align 4
  %1352 = icmp eq i32 %convergence.dynamic.target313, 8
  %1353 = and i1 %1349, %1352
  %1354 = and i1 %1342, %1353
  %1355 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1344
  %1356 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1344
  %1357 = load <8 x i1>, ptr %1355, align 1
  %1358 = load <8 x i1>, ptr %1356, align 1
  %1359 = or <8 x i1> %1358, %convergence.cascade.flow310
  %1360 = load <8 x i1>, ptr %live.mask, align 1
  %1361 = and <8 x i1> %1357, %1360
  %1362 = icmp eq <8 x i1> %1359, %1361
  %1363 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1362)
  %1364 = and i1 %1354, %1363
  %1365 = select i1 %1364, <8 x i1> zeroinitializer, <8 x i1> %1359
  %1366 = select i1 %1354, <8 x i1> %1365, <8 x i1> %1358
  store <8 x i1> %1366, ptr %1356, align 1
  %1367 = select i1 %1364, <8 x i1> zeroinitializer, <8 x i1> %1357
  store <8 x i1> %1367, ptr %1355, align 1
  %1368 = trunc i32 %1344 to i8
  %1369 = shl i8 1, %1368
  %1370 = xor i8 %1369, -1
  %1371 = and i8 %1345, %1370
  %1372 = select i1 %1364, i8 %1371, i8 %1345
  store i8 %1372, ptr %frame.active, align 1
  %.splatinsert314 = insertelement <8 x i1> poison, i1 %1354, i64 0
  %.splat315 = shufflevector <8 x i1> %.splatinsert314, <8 x i1> poison, <8 x i32> zeroinitializer
  %1373 = and <8 x i1> %convergence.cascade.flow310, %.splat315
  %1374 = load <8 x i1>, ptr %runnable.mask, align 1
  %1375 = xor <8 x i1> %1373, splat (i1 true)
  %1376 = and <8 x i1> %1374, %1375
  store <8 x i1> %1376, ptr %runnable.mask, align 1
  %.splatinsert316 = insertelement <8 x i1> poison, i1 %1364, i64 0
  %.splat317 = shufflevector <8 x i1> %.splatinsert316, <8 x i1> poison, <8 x i32> zeroinitializer
  %1377 = select <8 x i1> %.splat317, <8 x i1> %1359, <8 x i1> zeroinitializer
  %1378 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1379 = extractelement <8 x i32> %1378, i32 %1344
  %1380 = select i1 %1364, i32 %1379, i32 %1340
  store i32 %1380, ptr %current.token, align 4
  %.splatinsert318 = insertelement <8 x i1> poison, i1 %1354, i64 0
  %.splat319 = shufflevector <8 x i1> %.splatinsert318, <8 x i1> poison, <8 x i32> zeroinitializer
  %1381 = select <8 x i1> %.splat319, <8 x i1> %1377, <8 x i1> %convergence.cascade.flow310
  %1382 = add i32 %convergence.cascade.depth311, 1
  %1383 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1381)
  %1384 = icmp ult i32 %1382, 8
  %1385 = and i1 %1383, %1384
  %1386 = and i1 %1354, %1385
  %convergence.parent.token320 = load i32, ptr %current.token, align 4
  %convergence.parent.present321 = icmp ne i32 %convergence.parent.token320, 0
  %1387 = and i1 %1386, %convergence.parent.present321
  br i1 %1387, label %convergence.cascade306, label %convergence.cascade.exit307

convergence.cascade.exit307:                      ; preds = %convergence.cascade306, %schedule.8
  %convergence.cascade.result322 = phi <8 x i1> [ %262, %schedule.8 ], [ %1381, %convergence.cascade306 ]
  %1388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result322)
  br i1 %1388, label %convergence.target.8.ready, label %scheduler.loop

convergence.target.8.ready:                       ; preds = %convergence.cascade.exit307
  %1389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result322)
  %1390 = bitcast <8 x i1> %convergence.cascade.result322 to i8
  %1391 = call i8 @llvm.cttz.i8(i8 %1390, i1 false)
  %1392 = zext i8 %1391 to i32
  %1393 = select i1 %1389, i32 %1392, i32 0
  %1394 = load <8 x i64>, ptr %.slot57, align 64
  %1395 = select <8 x i1> %convergence.cascade.result322, <8 x i64> zeroinitializer, <8 x i64> %1394
  store <8 x i64> %1395, ptr %.slot57, align 64
  %1396 = load <8 x float>, ptr %.slot58, align 32
  %1397 = select <8 x i1> %convergence.cascade.result322, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %1396
  store <8 x float> %1397, ptr %.slot58, align 32
  %1398 = load <8 x float>, ptr %.slot59, align 32
  %1399 = select <8 x i1> %convergence.cascade.result322, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %1398
  store <8 x float> %1399, ptr %.slot59, align 32
  %1400 = load <8 x float>, ptr %.slot60, align 32
  %1401 = select <8 x i1> %convergence.cascade.result322, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %1400
  store <8 x float> %1401, ptr %.slot60, align 32
  %1402 = load <8 x float>, ptr %.slot61, align 32
  %1403 = select <8 x i1> %convergence.cascade.result322, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %1402
  store <8 x float> %1403, ptr %.slot61, align 32
  %1404 = load <8 x float>, ptr %.slot62, align 32
  %1405 = select <8 x i1> %convergence.cascade.result322, <8 x float> zeroinitializer, <8 x float> %1404
  store <8 x float> %1405, ptr %.slot62, align 32
  %1406 = load <8 x float>, ptr %.slot63, align 32
  %1407 = select <8 x i1> %convergence.cascade.result322, <8 x float> zeroinitializer, <8 x float> %1406
  store <8 x float> %1407, ptr %.slot63, align 32
  %1408 = load <8 x float>, ptr %.slot64, align 32
  %1409 = select <8 x i1> %convergence.cascade.result322, <8 x float> zeroinitializer, <8 x float> %1408
  store <8 x float> %1409, ptr %.slot64, align 32
  %1410 = load <8 x float>, ptr %.slot65, align 32
  %1411 = select <8 x i1> %convergence.cascade.result322, <8 x float> zeroinitializer, <8 x float> %1410
  store <8 x float> %1411, ptr %.slot65, align 32
  store <8 x i1> %convergence.cascade.result322, ptr %current.mask, align 1
  %1412 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result322)
  br i1 %1412, label %schedule.9, label %scheduler.loop

varying.divergent324:                             ; preds = %schedule.9
  %1413 = load i32, ptr %current.token, align 4
  %1414 = icmp ne i32 %1413, 0
  %1415 = sub i32 %1413, 1
  %1416 = select i1 %1414, i32 %1415, i32 0
  %1417 = load i8, ptr %frame.active, align 1
  %1418 = trunc i32 %1416 to i8
  %1419 = shl i8 1, %1418
  %1420 = and i8 %1417, %1419
  %1421 = icmp ne i8 %1420, 0
  %1422 = load <8 x i32>, ptr %frame.static.id, align 32
  %1423 = extractelement <8 x i32> %1422, i32 %1416
  %1424 = icmp eq i32 %1423, 3
  %1425 = and i1 %1421, %1424
  %1426 = and i1 %1414, %1425
  %1427 = xor i1 %1426, true
  %1428 = and i1 true, %1427
  %1429 = xor i8 %1417, -1
  %1430 = icmp ne i8 %1429, 0
  %1431 = xor i1 %1430, true
  %1432 = and i1 %1428, %1431
  br i1 %1432, label %convergence.overflow.trap326, label %convergence.overflow.resume327

varying.coherent325:                              ; preds = %schedule.9
  br i1 %273, label %varying.coherent.true330, label %varying.coherent.false331

convergence.overflow.trap326:                     ; preds = %varying.divergent324
  call void @llvm.trap()
  unreachable

convergence.overflow.resume327:                   ; preds = %varying.divergent324
  %1433 = call i8 @llvm.cttz.i8(i8 %1429, i1 false)
  %1434 = zext i8 %1433 to i32
  %1435 = select i1 %1430, i32 %1434, i32 0
  %1436 = trunc i32 %1435 to i8
  %1437 = shl i8 1, %1436
  %1438 = or i8 %1417, %1437
  %1439 = select i1 %1428, i8 %1438, i8 %1417
  store i8 %1439, ptr %frame.active, align 1
  %1440 = load <8 x i32>, ptr %frame.static.id, align 32
  %1441 = extractelement <8 x i32> %1440, i32 %1435
  %1442 = select i1 %1428, i32 3, i32 %1441
  %1443 = load <8 x i32>, ptr %frame.static.id, align 32
  %1444 = insertelement <8 x i32> %1443, i32 %1442, i32 %1435
  store <8 x i32> %1444, ptr %frame.static.id, align 32
  %1445 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1446 = extractelement <8 x i32> %1445, i32 %1435
  %1447 = select i1 %1428, i32 %1413, i32 %1446
  %1448 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1449 = insertelement <8 x i32> %1448, i32 %1447, i32 %1435
  store <8 x i32> %1449, ptr %frame.parent.token, align 32
  %1450 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1435
  %1451 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1435
  %1452 = load <8 x i1>, ptr %1450, align 1
  %1453 = load <8 x i1>, ptr %1451, align 1
  %1454 = select i1 %1428, <8 x i1> %263, <8 x i1> %1452
  store <8 x i1> %1454, ptr %1450, align 1
  %1455 = select i1 %1428, <8 x i1> zeroinitializer, <8 x i1> %1453
  store <8 x i1> %1455, ptr %1451, align 1
  %1456 = add i32 %1435, 1
  %1457 = select i1 %1426, i32 %1413, i32 %1456
  %1458 = select i1 true, i32 %1457, i32 %1413
  store i32 %1458, ptr %current.token, align 4
  %1459 = load i32, ptr %current.token, align 4
  %1460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %270)
  %1461 = load i32, ptr %ready.count, align 4
  %1462 = icmp uge i32 %1461, 8
  %1463 = and i1 %1460, %1462
  br i1 %1463, label %ready.overflow.trap328, label %ready.overflow.resume329

ready.overflow.trap328:                           ; preds = %convergence.overflow.resume327
  call void @llvm.trap()
  unreachable

ready.overflow.resume329:                         ; preds = %convergence.overflow.resume327
  %1464 = select i1 %1460, i32 %1461, i32 0
  %1465 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1464
  %1466 = load <8 x i1>, ptr %1465, align 1
  %1467 = select i1 %1460, <8 x i1> %270, <8 x i1> %1466
  store <8 x i1> %1467, ptr %1465, align 1
  %1468 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1464
  %1469 = load i32, ptr %1468, align 4
  %1470 = select i1 %1460, i32 10, i32 %1469
  store i32 %1470, ptr %1468, align 4
  %1471 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1464
  %1472 = load i32, ptr %1471, align 4
  %1473 = select i1 %1460, i32 %1459, i32 %1472
  store i32 %1473, ptr %1471, align 4
  %1474 = add i32 %1461, 1
  %1475 = select i1 %1460, i32 %1474, i32 %1461
  store i32 %1475, ptr %ready.count, align 4
  %1476 = load <8 x i1>, ptr %runnable.mask, align 1
  %1477 = or <8 x i1> %1476, %270
  store <8 x i1> %1477, ptr %runnable.mask, align 1
  store <8 x i1> %272, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true330:                         ; preds = %varying.coherent325
  store <8 x i1> %263, ptr %current.mask, align 1
  %1478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %263)
  br i1 %1478, label %schedule.10, label %scheduler.loop

varying.coherent.false331:                        ; preds = %varying.coherent325
  store <8 x i1> %263, ptr %current.mask, align 1
  %1479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %263)
  br i1 %1479, label %schedule.54, label %scheduler.loop

varying.divergent334:                             ; preds = %schedule.11
  %1480 = load i32, ptr %current.token, align 4
  %1481 = icmp ne i32 %1480, 0
  %1482 = sub i32 %1480, 1
  %1483 = select i1 %1481, i32 %1482, i32 0
  %1484 = load i8, ptr %frame.active, align 1
  %1485 = trunc i32 %1483 to i8
  %1486 = shl i8 1, %1485
  %1487 = and i8 %1484, %1486
  %1488 = icmp ne i8 %1487, 0
  %1489 = load <8 x i32>, ptr %frame.static.id, align 32
  %1490 = extractelement <8 x i32> %1489, i32 %1483
  %1491 = icmp eq i32 %1490, 4
  %1492 = and i1 %1488, %1491
  %1493 = and i1 %1481, %1492
  %1494 = xor i1 %1493, true
  %1495 = and i1 true, %1494
  %1496 = xor i8 %1484, -1
  %1497 = icmp ne i8 %1496, 0
  %1498 = xor i1 %1497, true
  %1499 = and i1 %1495, %1498
  br i1 %1499, label %convergence.overflow.trap336, label %convergence.overflow.resume337

varying.coherent335:                              ; preds = %schedule.11
  br i1 %310, label %varying.coherent.true340, label %varying.coherent.false341

convergence.overflow.trap336:                     ; preds = %varying.divergent334
  call void @llvm.trap()
  unreachable

convergence.overflow.resume337:                   ; preds = %varying.divergent334
  %1500 = call i8 @llvm.cttz.i8(i8 %1496, i1 false)
  %1501 = zext i8 %1500 to i32
  %1502 = select i1 %1497, i32 %1501, i32 0
  %1503 = trunc i32 %1502 to i8
  %1504 = shl i8 1, %1503
  %1505 = or i8 %1484, %1504
  %1506 = select i1 %1495, i8 %1505, i8 %1484
  store i8 %1506, ptr %frame.active, align 1
  %1507 = load <8 x i32>, ptr %frame.static.id, align 32
  %1508 = extractelement <8 x i32> %1507, i32 %1502
  %1509 = select i1 %1495, i32 4, i32 %1508
  %1510 = load <8 x i32>, ptr %frame.static.id, align 32
  %1511 = insertelement <8 x i32> %1510, i32 %1509, i32 %1502
  store <8 x i32> %1511, ptr %frame.static.id, align 32
  %1512 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1513 = extractelement <8 x i32> %1512, i32 %1502
  %1514 = select i1 %1495, i32 %1480, i32 %1513
  %1515 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1516 = insertelement <8 x i32> %1515, i32 %1514, i32 %1502
  store <8 x i32> %1516, ptr %frame.parent.token, align 32
  %1517 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1502
  %1518 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1502
  %1519 = load <8 x i1>, ptr %1517, align 1
  %1520 = load <8 x i1>, ptr %1518, align 1
  %1521 = select i1 %1495, <8 x i1> %300, <8 x i1> %1519
  store <8 x i1> %1521, ptr %1517, align 1
  %1522 = select i1 %1495, <8 x i1> zeroinitializer, <8 x i1> %1520
  store <8 x i1> %1522, ptr %1518, align 1
  %1523 = add i32 %1502, 1
  %1524 = select i1 %1493, i32 %1480, i32 %1523
  %1525 = select i1 true, i32 %1524, i32 %1480
  store i32 %1525, ptr %current.token, align 4
  %1526 = load i32, ptr %current.token, align 4
  %1527 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %307)
  %1528 = load i32, ptr %ready.count, align 4
  %1529 = icmp uge i32 %1528, 8
  %1530 = and i1 %1527, %1529
  br i1 %1530, label %ready.overflow.trap338, label %ready.overflow.resume339

ready.overflow.trap338:                           ; preds = %convergence.overflow.resume337
  call void @llvm.trap()
  unreachable

ready.overflow.resume339:                         ; preds = %convergence.overflow.resume337
  %1531 = select i1 %1527, i32 %1528, i32 0
  %1532 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1531
  %1533 = load <8 x i1>, ptr %1532, align 1
  %1534 = select i1 %1527, <8 x i1> %307, <8 x i1> %1533
  store <8 x i1> %1534, ptr %1532, align 1
  %1535 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1531
  %1536 = load i32, ptr %1535, align 4
  %1537 = select i1 %1527, i32 12, i32 %1536
  store i32 %1537, ptr %1535, align 4
  %1538 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1531
  %1539 = load i32, ptr %1538, align 4
  %1540 = select i1 %1527, i32 %1526, i32 %1539
  store i32 %1540, ptr %1538, align 4
  %1541 = add i32 %1528, 1
  %1542 = select i1 %1527, i32 %1541, i32 %1528
  store i32 %1542, ptr %ready.count, align 4
  %1543 = load <8 x i1>, ptr %runnable.mask, align 1
  %1544 = or <8 x i1> %1543, %307
  store <8 x i1> %1544, ptr %runnable.mask, align 1
  store <8 x i1> %309, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true340:                         ; preds = %varying.coherent335
  store <8 x i1> %300, ptr %current.mask, align 1
  %1545 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %300)
  br i1 %1545, label %schedule.12, label %scheduler.loop

varying.coherent.false341:                        ; preds = %varying.coherent335
  store <8 x i1> %300, ptr %current.mask, align 1
  %1546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %300)
  br i1 %1546, label %schedule.15, label %scheduler.loop

varying.divergent347:                             ; preds = %schedule.12
  %1547 = load i32, ptr %current.token, align 4
  %1548 = icmp ne i32 %1547, 0
  %1549 = sub i32 %1547, 1
  %1550 = select i1 %1548, i32 %1549, i32 0
  %1551 = load i8, ptr %frame.active, align 1
  %1552 = trunc i32 %1550 to i8
  %1553 = shl i8 1, %1552
  %1554 = and i8 %1551, %1553
  %1555 = icmp ne i8 %1554, 0
  %1556 = load <8 x i32>, ptr %frame.static.id, align 32
  %1557 = extractelement <8 x i32> %1556, i32 %1550
  %1558 = icmp eq i32 %1557, 5
  %1559 = and i1 %1555, %1558
  %1560 = and i1 %1548, %1559
  %1561 = xor i1 %1560, true
  %1562 = and i1 true, %1561
  %1563 = xor i8 %1551, -1
  %1564 = icmp ne i8 %1563, 0
  %1565 = xor i1 %1564, true
  %1566 = and i1 %1562, %1565
  br i1 %1566, label %convergence.overflow.trap349, label %convergence.overflow.resume350

varying.coherent348:                              ; preds = %schedule.12
  br i1 %345, label %varying.coherent.true353, label %varying.coherent.false354

convergence.overflow.trap349:                     ; preds = %varying.divergent347
  call void @llvm.trap()
  unreachable

convergence.overflow.resume350:                   ; preds = %varying.divergent347
  %1567 = call i8 @llvm.cttz.i8(i8 %1563, i1 false)
  %1568 = zext i8 %1567 to i32
  %1569 = select i1 %1564, i32 %1568, i32 0
  %1570 = trunc i32 %1569 to i8
  %1571 = shl i8 1, %1570
  %1572 = or i8 %1551, %1571
  %1573 = select i1 %1562, i8 %1572, i8 %1551
  store i8 %1573, ptr %frame.active, align 1
  %1574 = load <8 x i32>, ptr %frame.static.id, align 32
  %1575 = extractelement <8 x i32> %1574, i32 %1569
  %1576 = select i1 %1562, i32 5, i32 %1575
  %1577 = load <8 x i32>, ptr %frame.static.id, align 32
  %1578 = insertelement <8 x i32> %1577, i32 %1576, i32 %1569
  store <8 x i32> %1578, ptr %frame.static.id, align 32
  %1579 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1580 = extractelement <8 x i32> %1579, i32 %1569
  %1581 = select i1 %1562, i32 %1547, i32 %1580
  %1582 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1583 = insertelement <8 x i32> %1582, i32 %1581, i32 %1569
  store <8 x i32> %1583, ptr %frame.parent.token, align 32
  %1584 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1569
  %1585 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1569
  %1586 = load <8 x i1>, ptr %1584, align 1
  %1587 = load <8 x i1>, ptr %1585, align 1
  %1588 = select i1 %1562, <8 x i1> %313, <8 x i1> %1586
  store <8 x i1> %1588, ptr %1584, align 1
  %1589 = select i1 %1562, <8 x i1> zeroinitializer, <8 x i1> %1587
  store <8 x i1> %1589, ptr %1585, align 1
  %1590 = add i32 %1569, 1
  %1591 = select i1 %1560, i32 %1547, i32 %1590
  %1592 = select i1 true, i32 %1591, i32 %1547
  store i32 %1592, ptr %current.token, align 4
  %1593 = load <8 x float>, ptr %.slot70, align 32
  %1594 = select <8 x i1> %344, <8 x float> zeroinitializer, <8 x float> %1593
  store <8 x float> %1594, ptr %.slot70, align 32
  %1595 = load i32, ptr %current.token, align 4
  %1596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %342)
  %1597 = load i32, ptr %ready.count, align 4
  %1598 = icmp uge i32 %1597, 8
  %1599 = and i1 %1596, %1598
  br i1 %1599, label %ready.overflow.trap351, label %ready.overflow.resume352

ready.overflow.trap351:                           ; preds = %convergence.overflow.resume350
  call void @llvm.trap()
  unreachable

ready.overflow.resume352:                         ; preds = %convergence.overflow.resume350
  %1600 = select i1 %1596, i32 %1597, i32 0
  %1601 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1600
  %1602 = load <8 x i1>, ptr %1601, align 1
  %1603 = select i1 %1596, <8 x i1> %342, <8 x i1> %1602
  store <8 x i1> %1603, ptr %1601, align 1
  %1604 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1600
  %1605 = load i32, ptr %1604, align 4
  %1606 = select i1 %1596, i32 13, i32 %1605
  store i32 %1606, ptr %1604, align 4
  %1607 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1600
  %1608 = load i32, ptr %1607, align 4
  %1609 = select i1 %1596, i32 %1595, i32 %1608
  store i32 %1609, ptr %1607, align 4
  %1610 = add i32 %1597, 1
  %1611 = select i1 %1596, i32 %1610, i32 %1597
  store i32 %1611, ptr %ready.count, align 4
  %1612 = load <8 x i1>, ptr %runnable.mask, align 1
  %1613 = or <8 x i1> %1612, %342
  store <8 x i1> %1613, ptr %runnable.mask, align 1
  store <8 x i1> %344, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true353:                         ; preds = %varying.coherent348
  store <8 x i1> %313, ptr %current.mask, align 1
  %1614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %313)
  br i1 %1614, label %schedule.13, label %scheduler.loop

varying.coherent.false354:                        ; preds = %varying.coherent348
  %1615 = load <8 x float>, ptr %.slot70, align 32
  %1616 = select <8 x i1> %313, <8 x float> zeroinitializer, <8 x float> %1615
  store <8 x float> %1616, ptr %.slot70, align 32
  store <8 x i1> %313, ptr %current.mask, align 1
  %1617 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %313)
  br i1 %1617, label %schedule.14, label %scheduler.loop

convergence.cascade356:                           ; preds = %convergence.cascade356, %schedule.14
  %convergence.cascade.flow360 = phi <8 x i1> [ %361, %schedule.14 ], [ %1660, %convergence.cascade356 ]
  %convergence.cascade.depth361 = phi i32 [ 0, %schedule.14 ], [ %1661, %convergence.cascade356 ]
  %1618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow360)
  %1619 = load i32, ptr %current.token, align 4
  %1620 = icmp ne i32 %1619, 0
  %1621 = and i1 %1618, %1620
  %1622 = sub i32 %1619, 1
  %1623 = select i1 %1621, i32 %1622, i32 0
  %1624 = load i8, ptr %frame.active, align 1
  %1625 = trunc i32 %1623 to i8
  %1626 = shl i8 1, %1625
  %1627 = and i8 %1624, %1626
  %1628 = icmp ne i8 %1627, 0
  %1629 = load <8 x i32>, ptr %frame.static.id, align 32
  %1630 = extractelement <8 x i32> %1629, i32 %1623
  %convergence.target.pointer362 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1630
  %convergence.dynamic.target363 = load i32, ptr %convergence.target.pointer362, align 4
  %1631 = icmp eq i32 %convergence.dynamic.target363, 14
  %1632 = and i1 %1628, %1631
  %1633 = and i1 %1621, %1632
  %1634 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1623
  %1635 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1623
  %1636 = load <8 x i1>, ptr %1634, align 1
  %1637 = load <8 x i1>, ptr %1635, align 1
  %1638 = or <8 x i1> %1637, %convergence.cascade.flow360
  %1639 = load <8 x i1>, ptr %live.mask, align 1
  %1640 = and <8 x i1> %1636, %1639
  %1641 = icmp eq <8 x i1> %1638, %1640
  %1642 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1641)
  %1643 = and i1 %1633, %1642
  %1644 = select i1 %1643, <8 x i1> zeroinitializer, <8 x i1> %1638
  %1645 = select i1 %1633, <8 x i1> %1644, <8 x i1> %1637
  store <8 x i1> %1645, ptr %1635, align 1
  %1646 = select i1 %1643, <8 x i1> zeroinitializer, <8 x i1> %1636
  store <8 x i1> %1646, ptr %1634, align 1
  %1647 = trunc i32 %1623 to i8
  %1648 = shl i8 1, %1647
  %1649 = xor i8 %1648, -1
  %1650 = and i8 %1624, %1649
  %1651 = select i1 %1643, i8 %1650, i8 %1624
  store i8 %1651, ptr %frame.active, align 1
  %.splatinsert364 = insertelement <8 x i1> poison, i1 %1633, i64 0
  %.splat365 = shufflevector <8 x i1> %.splatinsert364, <8 x i1> poison, <8 x i32> zeroinitializer
  %1652 = and <8 x i1> %convergence.cascade.flow360, %.splat365
  %1653 = load <8 x i1>, ptr %runnable.mask, align 1
  %1654 = xor <8 x i1> %1652, splat (i1 true)
  %1655 = and <8 x i1> %1653, %1654
  store <8 x i1> %1655, ptr %runnable.mask, align 1
  %.splatinsert366 = insertelement <8 x i1> poison, i1 %1643, i64 0
  %.splat367 = shufflevector <8 x i1> %.splatinsert366, <8 x i1> poison, <8 x i32> zeroinitializer
  %1656 = select <8 x i1> %.splat367, <8 x i1> %1638, <8 x i1> zeroinitializer
  %1657 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1658 = extractelement <8 x i32> %1657, i32 %1623
  %1659 = select i1 %1643, i32 %1658, i32 %1619
  store i32 %1659, ptr %current.token, align 4
  %.splatinsert368 = insertelement <8 x i1> poison, i1 %1633, i64 0
  %.splat369 = shufflevector <8 x i1> %.splatinsert368, <8 x i1> poison, <8 x i32> zeroinitializer
  %1660 = select <8 x i1> %.splat369, <8 x i1> %1656, <8 x i1> %convergence.cascade.flow360
  %1661 = add i32 %convergence.cascade.depth361, 1
  %1662 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1660)
  %1663 = icmp ult i32 %1661, 8
  %1664 = and i1 %1662, %1663
  %1665 = and i1 %1633, %1664
  %convergence.parent.token370 = load i32, ptr %current.token, align 4
  %convergence.parent.present371 = icmp ne i32 %convergence.parent.token370, 0
  %1666 = and i1 %1665, %convergence.parent.present371
  br i1 %1666, label %convergence.cascade356, label %convergence.cascade.exit357

convergence.cascade.exit357:                      ; preds = %convergence.cascade356, %schedule.14
  %convergence.cascade.result372 = phi <8 x i1> [ %361, %schedule.14 ], [ %1660, %convergence.cascade356 ]
  %1667 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result372)
  br i1 %1667, label %convergence.target.14.ready, label %scheduler.loop

convergence.target.14.ready:                      ; preds = %convergence.cascade.exit357
  %1668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result372)
  %1669 = bitcast <8 x i1> %convergence.cascade.result372 to i8
  %1670 = call i8 @llvm.cttz.i8(i8 %1669, i1 false)
  %1671 = zext i8 %1670 to i32
  %1672 = select i1 %1668, i32 %1671, i32 0
  %tile_snapshot.spill.load373 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %1673 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %1674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %.state374 = load <8 x i64>, ptr %.slot68, align 64
  %1675 = mul <8 x i64> %.state374, splat (i64 4)
  %1676 = add <8 x i64> %1674, %1675
  %1677 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1673, 0
  %1678 = insertvalue { <8 x ptr>, <8 x i64> } %1677, <8 x i64> %1676, 1
  %.state375 = load <8 x float>, ptr %.slot70, align 32
  %1679 = extractvalue { <8 x ptr>, <8 x i64> } %1678, 0
  %1680 = extractvalue { <8 x ptr>, <8 x i64> } %1678, 1
  %1681 = getelementptr i8, <8 x ptr> %1679, <8 x i64> %1680
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state375, <8 x ptr> align 1 %1681, <8 x i1> %convergence.cascade.result372)
  %.state376 = load <8 x i64>, ptr %.slot68, align 64
  %1682 = add <8 x i64> %.state376, splat (i64 1)
  %1683 = load <8 x i64>, ptr %.slot68, align 64
  %1684 = select <8 x i1> %convergence.cascade.result372, <8 x i64> %1682, <8 x i64> %1683
  store <8 x i64> %1684, ptr %.slot68, align 64
  store <8 x i1> %convergence.cascade.result372, ptr %current.mask, align 1
  %1685 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result372)
  br i1 %1685, label %schedule.11, label %scheduler.loop

convergence.cascade377:                           ; preds = %convergence.cascade377, %schedule.15
  %convergence.cascade.flow381 = phi <8 x i1> [ %362, %schedule.15 ], [ %1728, %convergence.cascade377 ]
  %convergence.cascade.depth382 = phi i32 [ 0, %schedule.15 ], [ %1729, %convergence.cascade377 ]
  %1686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow381)
  %1687 = load i32, ptr %current.token, align 4
  %1688 = icmp ne i32 %1687, 0
  %1689 = and i1 %1686, %1688
  %1690 = sub i32 %1687, 1
  %1691 = select i1 %1689, i32 %1690, i32 0
  %1692 = load i8, ptr %frame.active, align 1
  %1693 = trunc i32 %1691 to i8
  %1694 = shl i8 1, %1693
  %1695 = and i8 %1692, %1694
  %1696 = icmp ne i8 %1695, 0
  %1697 = load <8 x i32>, ptr %frame.static.id, align 32
  %1698 = extractelement <8 x i32> %1697, i32 %1691
  %convergence.target.pointer383 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1698
  %convergence.dynamic.target384 = load i32, ptr %convergence.target.pointer383, align 4
  %1699 = icmp eq i32 %convergence.dynamic.target384, 15
  %1700 = and i1 %1696, %1699
  %1701 = and i1 %1689, %1700
  %1702 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1691
  %1703 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1691
  %1704 = load <8 x i1>, ptr %1702, align 1
  %1705 = load <8 x i1>, ptr %1703, align 1
  %1706 = or <8 x i1> %1705, %convergence.cascade.flow381
  %1707 = load <8 x i1>, ptr %live.mask, align 1
  %1708 = and <8 x i1> %1704, %1707
  %1709 = icmp eq <8 x i1> %1706, %1708
  %1710 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1709)
  %1711 = and i1 %1701, %1710
  %1712 = select i1 %1711, <8 x i1> zeroinitializer, <8 x i1> %1706
  %1713 = select i1 %1701, <8 x i1> %1712, <8 x i1> %1705
  store <8 x i1> %1713, ptr %1703, align 1
  %1714 = select i1 %1711, <8 x i1> zeroinitializer, <8 x i1> %1704
  store <8 x i1> %1714, ptr %1702, align 1
  %1715 = trunc i32 %1691 to i8
  %1716 = shl i8 1, %1715
  %1717 = xor i8 %1716, -1
  %1718 = and i8 %1692, %1717
  %1719 = select i1 %1711, i8 %1718, i8 %1692
  store i8 %1719, ptr %frame.active, align 1
  %.splatinsert385 = insertelement <8 x i1> poison, i1 %1701, i64 0
  %.splat386 = shufflevector <8 x i1> %.splatinsert385, <8 x i1> poison, <8 x i32> zeroinitializer
  %1720 = and <8 x i1> %convergence.cascade.flow381, %.splat386
  %1721 = load <8 x i1>, ptr %runnable.mask, align 1
  %1722 = xor <8 x i1> %1720, splat (i1 true)
  %1723 = and <8 x i1> %1721, %1722
  store <8 x i1> %1723, ptr %runnable.mask, align 1
  %.splatinsert387 = insertelement <8 x i1> poison, i1 %1711, i64 0
  %.splat388 = shufflevector <8 x i1> %.splatinsert387, <8 x i1> poison, <8 x i32> zeroinitializer
  %1724 = select <8 x i1> %.splat388, <8 x i1> %1706, <8 x i1> zeroinitializer
  %1725 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1726 = extractelement <8 x i32> %1725, i32 %1691
  %1727 = select i1 %1711, i32 %1726, i32 %1687
  store i32 %1727, ptr %current.token, align 4
  %.splatinsert389 = insertelement <8 x i1> poison, i1 %1701, i64 0
  %.splat390 = shufflevector <8 x i1> %.splatinsert389, <8 x i1> poison, <8 x i32> zeroinitializer
  %1728 = select <8 x i1> %.splat390, <8 x i1> %1724, <8 x i1> %convergence.cascade.flow381
  %1729 = add i32 %convergence.cascade.depth382, 1
  %1730 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1728)
  %1731 = icmp ult i32 %1729, 8
  %1732 = and i1 %1730, %1731
  %1733 = and i1 %1701, %1732
  %convergence.parent.token391 = load i32, ptr %current.token, align 4
  %convergence.parent.present392 = icmp ne i32 %convergence.parent.token391, 0
  %1734 = and i1 %1733, %convergence.parent.present392
  br i1 %1734, label %convergence.cascade377, label %convergence.cascade.exit378

convergence.cascade.exit378:                      ; preds = %convergence.cascade377, %schedule.15
  %convergence.cascade.result393 = phi <8 x i1> [ %362, %schedule.15 ], [ %1728, %convergence.cascade377 ]
  %1735 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result393)
  br i1 %1735, label %convergence.target.15.ready, label %scheduler.loop

convergence.target.15.ready:                      ; preds = %convergence.cascade.exit378
  %1736 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result393)
  %1737 = bitcast <8 x i1> %convergence.cascade.result393 to i8
  %1738 = call i8 @llvm.cttz.i8(i8 %1737, i1 false)
  %1739 = zext i8 %1738 to i32
  %1740 = select i1 %1736, i32 %1739, i32 0
  %1741 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %1742 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1743 = extractvalue { <8 x ptr>, <8 x i64> } %1741, 0
  %1744 = select <8 x i1> %convergence.cascade.result393, <8 x ptr> %1742, <8 x ptr> %1743
  %1745 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1746 = extractvalue { <8 x ptr>, <8 x i64> } %1741, 1
  %1747 = select <8 x i1> %convergence.cascade.result393, <8 x i64> %1745, <8 x i64> %1746
  %1748 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1744, 0
  %1749 = insertvalue { <8 x ptr>, <8 x i64> } %1748, <8 x i64> %1747, 1
  store volatile { <8 x ptr>, <8 x i64> } %1749, ptr %tile_snapshot.spill71, align 64
  %1750 = load <8 x i64>, ptr %.slot72, align 64
  %1751 = select <8 x i1> %convergence.cascade.result393, <8 x i64> zeroinitializer, <8 x i64> %1750
  store <8 x i64> %1751, ptr %.slot72, align 64
  store <8 x i1> %convergence.cascade.result393, ptr %current.mask, align 1
  %1752 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result393)
  br i1 %1752, label %schedule.16, label %scheduler.loop

varying.divergent395:                             ; preds = %schedule.16
  %1753 = load i32, ptr %current.token, align 4
  %1754 = icmp ne i32 %1753, 0
  %1755 = sub i32 %1753, 1
  %1756 = select i1 %1754, i32 %1755, i32 0
  %1757 = load i8, ptr %frame.active, align 1
  %1758 = trunc i32 %1756 to i8
  %1759 = shl i8 1, %1758
  %1760 = and i8 %1757, %1759
  %1761 = icmp ne i8 %1760, 0
  %1762 = load <8 x i32>, ptr %frame.static.id, align 32
  %1763 = extractelement <8 x i32> %1762, i32 %1756
  %1764 = icmp eq i32 %1763, 6
  %1765 = and i1 %1761, %1764
  %1766 = and i1 %1754, %1765
  %1767 = xor i1 %1766, true
  %1768 = and i1 true, %1767
  %1769 = xor i8 %1757, -1
  %1770 = icmp ne i8 %1769, 0
  %1771 = xor i1 %1770, true
  %1772 = and i1 %1768, %1771
  br i1 %1772, label %convergence.overflow.trap397, label %convergence.overflow.resume398

varying.coherent396:                              ; preds = %schedule.16
  br i1 %373, label %varying.coherent.true401, label %varying.coherent.false402

convergence.overflow.trap397:                     ; preds = %varying.divergent395
  call void @llvm.trap()
  unreachable

convergence.overflow.resume398:                   ; preds = %varying.divergent395
  %1773 = call i8 @llvm.cttz.i8(i8 %1769, i1 false)
  %1774 = zext i8 %1773 to i32
  %1775 = select i1 %1770, i32 %1774, i32 0
  %1776 = trunc i32 %1775 to i8
  %1777 = shl i8 1, %1776
  %1778 = or i8 %1757, %1777
  %1779 = select i1 %1768, i8 %1778, i8 %1757
  store i8 %1779, ptr %frame.active, align 1
  %1780 = load <8 x i32>, ptr %frame.static.id, align 32
  %1781 = extractelement <8 x i32> %1780, i32 %1775
  %1782 = select i1 %1768, i32 6, i32 %1781
  %1783 = load <8 x i32>, ptr %frame.static.id, align 32
  %1784 = insertelement <8 x i32> %1783, i32 %1782, i32 %1775
  store <8 x i32> %1784, ptr %frame.static.id, align 32
  %1785 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1786 = extractelement <8 x i32> %1785, i32 %1775
  %1787 = select i1 %1768, i32 %1753, i32 %1786
  %1788 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1789 = insertelement <8 x i32> %1788, i32 %1787, i32 %1775
  store <8 x i32> %1789, ptr %frame.parent.token, align 32
  %1790 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1775
  %1791 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1775
  %1792 = load <8 x i1>, ptr %1790, align 1
  %1793 = load <8 x i1>, ptr %1791, align 1
  %1794 = select i1 %1768, <8 x i1> %363, <8 x i1> %1792
  store <8 x i1> %1794, ptr %1790, align 1
  %1795 = select i1 %1768, <8 x i1> zeroinitializer, <8 x i1> %1793
  store <8 x i1> %1795, ptr %1791, align 1
  %1796 = add i32 %1775, 1
  %1797 = select i1 %1766, i32 %1753, i32 %1796
  %1798 = select i1 true, i32 %1797, i32 %1753
  store i32 %1798, ptr %current.token, align 4
  %1799 = load i32, ptr %current.token, align 4
  %1800 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %370)
  %1801 = load i32, ptr %ready.count, align 4
  %1802 = icmp uge i32 %1801, 8
  %1803 = and i1 %1800, %1802
  br i1 %1803, label %ready.overflow.trap399, label %ready.overflow.resume400

ready.overflow.trap399:                           ; preds = %convergence.overflow.resume398
  call void @llvm.trap()
  unreachable

ready.overflow.resume400:                         ; preds = %convergence.overflow.resume398
  %1804 = select i1 %1800, i32 %1801, i32 0
  %1805 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1804
  %1806 = load <8 x i1>, ptr %1805, align 1
  %1807 = select i1 %1800, <8 x i1> %370, <8 x i1> %1806
  store <8 x i1> %1807, ptr %1805, align 1
  %1808 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1804
  %1809 = load i32, ptr %1808, align 4
  %1810 = select i1 %1800, i32 17, i32 %1809
  store i32 %1810, ptr %1808, align 4
  %1811 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1804
  %1812 = load i32, ptr %1811, align 4
  %1813 = select i1 %1800, i32 %1799, i32 %1812
  store i32 %1813, ptr %1811, align 4
  %1814 = add i32 %1801, 1
  %1815 = select i1 %1800, i32 %1814, i32 %1801
  store i32 %1815, ptr %ready.count, align 4
  %1816 = load <8 x i1>, ptr %runnable.mask, align 1
  %1817 = or <8 x i1> %1816, %370
  store <8 x i1> %1817, ptr %runnable.mask, align 1
  store <8 x i1> %372, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true401:                         ; preds = %varying.coherent396
  store <8 x i1> %363, ptr %current.mask, align 1
  %1818 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %363)
  br i1 %1818, label %schedule.17, label %scheduler.loop

varying.coherent.false402:                        ; preds = %varying.coherent396
  store <8 x i1> %363, ptr %current.mask, align 1
  %1819 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %363)
  br i1 %1819, label %schedule.20, label %scheduler.loop

varying.divergent408:                             ; preds = %schedule.17
  %1820 = load i32, ptr %current.token, align 4
  %1821 = icmp ne i32 %1820, 0
  %1822 = sub i32 %1820, 1
  %1823 = select i1 %1821, i32 %1822, i32 0
  %1824 = load i8, ptr %frame.active, align 1
  %1825 = trunc i32 %1823 to i8
  %1826 = shl i8 1, %1825
  %1827 = and i8 %1824, %1826
  %1828 = icmp ne i8 %1827, 0
  %1829 = load <8 x i32>, ptr %frame.static.id, align 32
  %1830 = extractelement <8 x i32> %1829, i32 %1823
  %1831 = icmp eq i32 %1830, 7
  %1832 = and i1 %1828, %1831
  %1833 = and i1 %1821, %1832
  %1834 = xor i1 %1833, true
  %1835 = and i1 true, %1834
  %1836 = xor i8 %1824, -1
  %1837 = icmp ne i8 %1836, 0
  %1838 = xor i1 %1837, true
  %1839 = and i1 %1835, %1838
  br i1 %1839, label %convergence.overflow.trap410, label %convergence.overflow.resume411

varying.coherent409:                              ; preds = %schedule.17
  br i1 %408, label %varying.coherent.true414, label %varying.coherent.false415

convergence.overflow.trap410:                     ; preds = %varying.divergent408
  call void @llvm.trap()
  unreachable

convergence.overflow.resume411:                   ; preds = %varying.divergent408
  %1840 = call i8 @llvm.cttz.i8(i8 %1836, i1 false)
  %1841 = zext i8 %1840 to i32
  %1842 = select i1 %1837, i32 %1841, i32 0
  %1843 = trunc i32 %1842 to i8
  %1844 = shl i8 1, %1843
  %1845 = or i8 %1824, %1844
  %1846 = select i1 %1835, i8 %1845, i8 %1824
  store i8 %1846, ptr %frame.active, align 1
  %1847 = load <8 x i32>, ptr %frame.static.id, align 32
  %1848 = extractelement <8 x i32> %1847, i32 %1842
  %1849 = select i1 %1835, i32 7, i32 %1848
  %1850 = load <8 x i32>, ptr %frame.static.id, align 32
  %1851 = insertelement <8 x i32> %1850, i32 %1849, i32 %1842
  store <8 x i32> %1851, ptr %frame.static.id, align 32
  %1852 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1853 = extractelement <8 x i32> %1852, i32 %1842
  %1854 = select i1 %1835, i32 %1820, i32 %1853
  %1855 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1856 = insertelement <8 x i32> %1855, i32 %1854, i32 %1842
  store <8 x i32> %1856, ptr %frame.parent.token, align 32
  %1857 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1842
  %1858 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1842
  %1859 = load <8 x i1>, ptr %1857, align 1
  %1860 = load <8 x i1>, ptr %1858, align 1
  %1861 = select i1 %1835, <8 x i1> %376, <8 x i1> %1859
  store <8 x i1> %1861, ptr %1857, align 1
  %1862 = select i1 %1835, <8 x i1> zeroinitializer, <8 x i1> %1860
  store <8 x i1> %1862, ptr %1858, align 1
  %1863 = add i32 %1842, 1
  %1864 = select i1 %1833, i32 %1820, i32 %1863
  %1865 = select i1 true, i32 %1864, i32 %1820
  store i32 %1865, ptr %current.token, align 4
  %1866 = load <8 x float>, ptr %.slot74, align 32
  %1867 = select <8 x i1> %407, <8 x float> zeroinitializer, <8 x float> %1866
  store <8 x float> %1867, ptr %.slot74, align 32
  %1868 = load i32, ptr %current.token, align 4
  %1869 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %405)
  %1870 = load i32, ptr %ready.count, align 4
  %1871 = icmp uge i32 %1870, 8
  %1872 = and i1 %1869, %1871
  br i1 %1872, label %ready.overflow.trap412, label %ready.overflow.resume413

ready.overflow.trap412:                           ; preds = %convergence.overflow.resume411
  call void @llvm.trap()
  unreachable

ready.overflow.resume413:                         ; preds = %convergence.overflow.resume411
  %1873 = select i1 %1869, i32 %1870, i32 0
  %1874 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %1873
  %1875 = load <8 x i1>, ptr %1874, align 1
  %1876 = select i1 %1869, <8 x i1> %405, <8 x i1> %1875
  store <8 x i1> %1876, ptr %1874, align 1
  %1877 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %1873
  %1878 = load i32, ptr %1877, align 4
  %1879 = select i1 %1869, i32 18, i32 %1878
  store i32 %1879, ptr %1877, align 4
  %1880 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %1873
  %1881 = load i32, ptr %1880, align 4
  %1882 = select i1 %1869, i32 %1868, i32 %1881
  store i32 %1882, ptr %1880, align 4
  %1883 = add i32 %1870, 1
  %1884 = select i1 %1869, i32 %1883, i32 %1870
  store i32 %1884, ptr %ready.count, align 4
  %1885 = load <8 x i1>, ptr %runnable.mask, align 1
  %1886 = or <8 x i1> %1885, %405
  store <8 x i1> %1886, ptr %runnable.mask, align 1
  store <8 x i1> %407, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true414:                         ; preds = %varying.coherent409
  store <8 x i1> %376, ptr %current.mask, align 1
  %1887 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %376)
  br i1 %1887, label %schedule.18, label %scheduler.loop

varying.coherent.false415:                        ; preds = %varying.coherent409
  %1888 = load <8 x float>, ptr %.slot74, align 32
  %1889 = select <8 x i1> %376, <8 x float> zeroinitializer, <8 x float> %1888
  store <8 x float> %1889, ptr %.slot74, align 32
  store <8 x i1> %376, ptr %current.mask, align 1
  %1890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %376)
  br i1 %1890, label %schedule.19, label %scheduler.loop

convergence.cascade417:                           ; preds = %convergence.cascade417, %schedule.19
  %convergence.cascade.flow421 = phi <8 x i1> [ %424, %schedule.19 ], [ %1933, %convergence.cascade417 ]
  %convergence.cascade.depth422 = phi i32 [ 0, %schedule.19 ], [ %1934, %convergence.cascade417 ]
  %1891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow421)
  %1892 = load i32, ptr %current.token, align 4
  %1893 = icmp ne i32 %1892, 0
  %1894 = and i1 %1891, %1893
  %1895 = sub i32 %1892, 1
  %1896 = select i1 %1894, i32 %1895, i32 0
  %1897 = load i8, ptr %frame.active, align 1
  %1898 = trunc i32 %1896 to i8
  %1899 = shl i8 1, %1898
  %1900 = and i8 %1897, %1899
  %1901 = icmp ne i8 %1900, 0
  %1902 = load <8 x i32>, ptr %frame.static.id, align 32
  %1903 = extractelement <8 x i32> %1902, i32 %1896
  %convergence.target.pointer423 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1903
  %convergence.dynamic.target424 = load i32, ptr %convergence.target.pointer423, align 4
  %1904 = icmp eq i32 %convergence.dynamic.target424, 19
  %1905 = and i1 %1901, %1904
  %1906 = and i1 %1894, %1905
  %1907 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1896
  %1908 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1896
  %1909 = load <8 x i1>, ptr %1907, align 1
  %1910 = load <8 x i1>, ptr %1908, align 1
  %1911 = or <8 x i1> %1910, %convergence.cascade.flow421
  %1912 = load <8 x i1>, ptr %live.mask, align 1
  %1913 = and <8 x i1> %1909, %1912
  %1914 = icmp eq <8 x i1> %1911, %1913
  %1915 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1914)
  %1916 = and i1 %1906, %1915
  %1917 = select i1 %1916, <8 x i1> zeroinitializer, <8 x i1> %1911
  %1918 = select i1 %1906, <8 x i1> %1917, <8 x i1> %1910
  store <8 x i1> %1918, ptr %1908, align 1
  %1919 = select i1 %1916, <8 x i1> zeroinitializer, <8 x i1> %1909
  store <8 x i1> %1919, ptr %1907, align 1
  %1920 = trunc i32 %1896 to i8
  %1921 = shl i8 1, %1920
  %1922 = xor i8 %1921, -1
  %1923 = and i8 %1897, %1922
  %1924 = select i1 %1916, i8 %1923, i8 %1897
  store i8 %1924, ptr %frame.active, align 1
  %.splatinsert425 = insertelement <8 x i1> poison, i1 %1906, i64 0
  %.splat426 = shufflevector <8 x i1> %.splatinsert425, <8 x i1> poison, <8 x i32> zeroinitializer
  %1925 = and <8 x i1> %convergence.cascade.flow421, %.splat426
  %1926 = load <8 x i1>, ptr %runnable.mask, align 1
  %1927 = xor <8 x i1> %1925, splat (i1 true)
  %1928 = and <8 x i1> %1926, %1927
  store <8 x i1> %1928, ptr %runnable.mask, align 1
  %.splatinsert427 = insertelement <8 x i1> poison, i1 %1916, i64 0
  %.splat428 = shufflevector <8 x i1> %.splatinsert427, <8 x i1> poison, <8 x i32> zeroinitializer
  %1929 = select <8 x i1> %.splat428, <8 x i1> %1911, <8 x i1> zeroinitializer
  %1930 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1931 = extractelement <8 x i32> %1930, i32 %1896
  %1932 = select i1 %1916, i32 %1931, i32 %1892
  store i32 %1932, ptr %current.token, align 4
  %.splatinsert429 = insertelement <8 x i1> poison, i1 %1906, i64 0
  %.splat430 = shufflevector <8 x i1> %.splatinsert429, <8 x i1> poison, <8 x i32> zeroinitializer
  %1933 = select <8 x i1> %.splat430, <8 x i1> %1929, <8 x i1> %convergence.cascade.flow421
  %1934 = add i32 %convergence.cascade.depth422, 1
  %1935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1933)
  %1936 = icmp ult i32 %1934, 8
  %1937 = and i1 %1935, %1936
  %1938 = and i1 %1906, %1937
  %convergence.parent.token431 = load i32, ptr %current.token, align 4
  %convergence.parent.present432 = icmp ne i32 %convergence.parent.token431, 0
  %1939 = and i1 %1938, %convergence.parent.present432
  br i1 %1939, label %convergence.cascade417, label %convergence.cascade.exit418

convergence.cascade.exit418:                      ; preds = %convergence.cascade417, %schedule.19
  %convergence.cascade.result433 = phi <8 x i1> [ %424, %schedule.19 ], [ %1933, %convergence.cascade417 ]
  %1940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result433)
  br i1 %1940, label %convergence.target.19.ready, label %scheduler.loop

convergence.target.19.ready:                      ; preds = %convergence.cascade.exit418
  %1941 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result433)
  %1942 = bitcast <8 x i1> %convergence.cascade.result433 to i8
  %1943 = call i8 @llvm.cttz.i8(i8 %1942, i1 false)
  %1944 = zext i8 %1943 to i32
  %1945 = select i1 %1941, i32 %1944, i32 0
  %tile_snapshot.spill.load434 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %1946 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load434, 0
  %1947 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load434, 1
  %.state435 = load <8 x i64>, ptr %.slot72, align 64
  %1948 = mul <8 x i64> %.state435, splat (i64 4)
  %1949 = add <8 x i64> %1947, %1948
  %1950 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1946, 0
  %1951 = insertvalue { <8 x ptr>, <8 x i64> } %1950, <8 x i64> %1949, 1
  %.state436 = load <8 x float>, ptr %.slot74, align 32
  %1952 = extractvalue { <8 x ptr>, <8 x i64> } %1951, 0
  %1953 = extractvalue { <8 x ptr>, <8 x i64> } %1951, 1
  %1954 = getelementptr i8, <8 x ptr> %1952, <8 x i64> %1953
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state436, <8 x ptr> align 1 %1954, <8 x i1> %convergence.cascade.result433)
  %.state437 = load <8 x i64>, ptr %.slot72, align 64
  %1955 = add <8 x i64> %.state437, splat (i64 1)
  %1956 = load <8 x i64>, ptr %.slot72, align 64
  %1957 = select <8 x i1> %convergence.cascade.result433, <8 x i64> %1955, <8 x i64> %1956
  store <8 x i64> %1957, ptr %.slot72, align 64
  store <8 x i1> %convergence.cascade.result433, ptr %current.mask, align 1
  %1958 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result433)
  br i1 %1958, label %schedule.16, label %scheduler.loop

convergence.cascade438:                           ; preds = %convergence.cascade438, %schedule.20
  %convergence.cascade.flow442 = phi <8 x i1> [ %425, %schedule.20 ], [ %2001, %convergence.cascade438 ]
  %convergence.cascade.depth443 = phi i32 [ 0, %schedule.20 ], [ %2002, %convergence.cascade438 ]
  %1959 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow442)
  %1960 = load i32, ptr %current.token, align 4
  %1961 = icmp ne i32 %1960, 0
  %1962 = and i1 %1959, %1961
  %1963 = sub i32 %1960, 1
  %1964 = select i1 %1962, i32 %1963, i32 0
  %1965 = load i8, ptr %frame.active, align 1
  %1966 = trunc i32 %1964 to i8
  %1967 = shl i8 1, %1966
  %1968 = and i8 %1965, %1967
  %1969 = icmp ne i8 %1968, 0
  %1970 = load <8 x i32>, ptr %frame.static.id, align 32
  %1971 = extractelement <8 x i32> %1970, i32 %1964
  %convergence.target.pointer444 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %1971
  %convergence.dynamic.target445 = load i32, ptr %convergence.target.pointer444, align 4
  %1972 = icmp eq i32 %convergence.dynamic.target445, 20
  %1973 = and i1 %1969, %1972
  %1974 = and i1 %1962, %1973
  %1975 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %1964
  %1976 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %1964
  %1977 = load <8 x i1>, ptr %1975, align 1
  %1978 = load <8 x i1>, ptr %1976, align 1
  %1979 = or <8 x i1> %1978, %convergence.cascade.flow442
  %1980 = load <8 x i1>, ptr %live.mask, align 1
  %1981 = and <8 x i1> %1977, %1980
  %1982 = icmp eq <8 x i1> %1979, %1981
  %1983 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %1982)
  %1984 = and i1 %1974, %1983
  %1985 = select i1 %1984, <8 x i1> zeroinitializer, <8 x i1> %1979
  %1986 = select i1 %1974, <8 x i1> %1985, <8 x i1> %1978
  store <8 x i1> %1986, ptr %1976, align 1
  %1987 = select i1 %1984, <8 x i1> zeroinitializer, <8 x i1> %1977
  store <8 x i1> %1987, ptr %1975, align 1
  %1988 = trunc i32 %1964 to i8
  %1989 = shl i8 1, %1988
  %1990 = xor i8 %1989, -1
  %1991 = and i8 %1965, %1990
  %1992 = select i1 %1984, i8 %1991, i8 %1965
  store i8 %1992, ptr %frame.active, align 1
  %.splatinsert446 = insertelement <8 x i1> poison, i1 %1974, i64 0
  %.splat447 = shufflevector <8 x i1> %.splatinsert446, <8 x i1> poison, <8 x i32> zeroinitializer
  %1993 = and <8 x i1> %convergence.cascade.flow442, %.splat447
  %1994 = load <8 x i1>, ptr %runnable.mask, align 1
  %1995 = xor <8 x i1> %1993, splat (i1 true)
  %1996 = and <8 x i1> %1994, %1995
  store <8 x i1> %1996, ptr %runnable.mask, align 1
  %.splatinsert448 = insertelement <8 x i1> poison, i1 %1984, i64 0
  %.splat449 = shufflevector <8 x i1> %.splatinsert448, <8 x i1> poison, <8 x i32> zeroinitializer
  %1997 = select <8 x i1> %.splat449, <8 x i1> %1979, <8 x i1> zeroinitializer
  %1998 = load <8 x i32>, ptr %frame.parent.token, align 32
  %1999 = extractelement <8 x i32> %1998, i32 %1964
  %2000 = select i1 %1984, i32 %1999, i32 %1960
  store i32 %2000, ptr %current.token, align 4
  %.splatinsert450 = insertelement <8 x i1> poison, i1 %1974, i64 0
  %.splat451 = shufflevector <8 x i1> %.splatinsert450, <8 x i1> poison, <8 x i32> zeroinitializer
  %2001 = select <8 x i1> %.splat451, <8 x i1> %1997, <8 x i1> %convergence.cascade.flow442
  %2002 = add i32 %convergence.cascade.depth443, 1
  %2003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2001)
  %2004 = icmp ult i32 %2002, 8
  %2005 = and i1 %2003, %2004
  %2006 = and i1 %1974, %2005
  %convergence.parent.token452 = load i32, ptr %current.token, align 4
  %convergence.parent.present453 = icmp ne i32 %convergence.parent.token452, 0
  %2007 = and i1 %2006, %convergence.parent.present453
  br i1 %2007, label %convergence.cascade438, label %convergence.cascade.exit439

convergence.cascade.exit439:                      ; preds = %convergence.cascade438, %schedule.20
  %convergence.cascade.result454 = phi <8 x i1> [ %425, %schedule.20 ], [ %2001, %convergence.cascade438 ]
  %2008 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  br i1 %2008, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit439
  %2009 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %2010 = bitcast <8 x i1> %convergence.cascade.result454 to i8
  %2011 = call i8 @llvm.cttz.i8(i8 %2010, i1 false)
  %2012 = zext i8 %2011 to i32
  %2013 = select i1 %2009, i32 %2012, i32 0
  %2014 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2015 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2016 = add <8 x i64> %2015, zeroinitializer
  %2017 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2014, 0
  %2018 = insertvalue { <8 x ptr>, <8 x i64> } %2017, <8 x i64> %2016, 1
  %2019 = extractvalue { <8 x ptr>, <8 x i64> } %2018, 0
  %2020 = extractvalue { <8 x ptr>, <8 x i64> } %2018, 1
  %2021 = getelementptr i8, <8 x ptr> %2019, <8 x i64> %2020
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2021, <8 x i1> %convergence.cascade.result454)
  %2022 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2023 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2024 = add <8 x i64> %2023, splat (i64 4)
  %2025 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2022, 0
  %2026 = insertvalue { <8 x ptr>, <8 x i64> } %2025, <8 x i64> %2024, 1
  %2027 = extractvalue { <8 x ptr>, <8 x i64> } %2026, 0
  %2028 = extractvalue { <8 x ptr>, <8 x i64> } %2026, 1
  %2029 = getelementptr i8, <8 x ptr> %2027, <8 x i64> %2028
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2029, <8 x i1> %convergence.cascade.result454)
  %2030 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2031 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2032 = add <8 x i64> %2031, splat (i64 8)
  %2033 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2030, 0
  %2034 = insertvalue { <8 x ptr>, <8 x i64> } %2033, <8 x i64> %2032, 1
  %2035 = extractvalue { <8 x ptr>, <8 x i64> } %2034, 0
  %2036 = extractvalue { <8 x ptr>, <8 x i64> } %2034, 1
  %2037 = getelementptr i8, <8 x ptr> %2035, <8 x i64> %2036
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2037, <8 x i1> %convergence.cascade.result454)
  %2038 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2039 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2040 = add <8 x i64> %2039, splat (i64 12)
  %2041 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2038, 0
  %2042 = insertvalue { <8 x ptr>, <8 x i64> } %2041, <8 x i64> %2040, 1
  %2043 = extractvalue { <8 x ptr>, <8 x i64> } %2042, 0
  %2044 = extractvalue { <8 x ptr>, <8 x i64> } %2042, 1
  %2045 = getelementptr i8, <8 x ptr> %2043, <8 x i64> %2044
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2045, <8 x i1> %convergence.cascade.result454)
  %2046 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2047 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2048 = add <8 x i64> %2047, splat (i64 16)
  %2049 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2046, 0
  %2050 = insertvalue { <8 x ptr>, <8 x i64> } %2049, <8 x i64> %2048, 1
  %2051 = extractvalue { <8 x ptr>, <8 x i64> } %2050, 0
  %2052 = extractvalue { <8 x ptr>, <8 x i64> } %2050, 1
  %2053 = getelementptr i8, <8 x ptr> %2051, <8 x i64> %2052
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2053, <8 x i1> %convergence.cascade.result454)
  %2054 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2055 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2056 = add <8 x i64> %2055, splat (i64 20)
  %2057 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2054, 0
  %2058 = insertvalue { <8 x ptr>, <8 x i64> } %2057, <8 x i64> %2056, 1
  %2059 = extractvalue { <8 x ptr>, <8 x i64> } %2058, 0
  %2060 = extractvalue { <8 x ptr>, <8 x i64> } %2058, 1
  %2061 = getelementptr i8, <8 x ptr> %2059, <8 x i64> %2060
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2061, <8 x i1> %convergence.cascade.result454)
  %2062 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2063 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2064 = add <8 x i64> %2063, splat (i64 24)
  %2065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2062, 0
  %2066 = insertvalue { <8 x ptr>, <8 x i64> } %2065, <8 x i64> %2064, 1
  %2067 = extractvalue { <8 x ptr>, <8 x i64> } %2066, 0
  %2068 = extractvalue { <8 x ptr>, <8 x i64> } %2066, 1
  %2069 = getelementptr i8, <8 x ptr> %2067, <8 x i64> %2068
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2069, <8 x i1> %convergence.cascade.result454)
  %2070 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2071 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2072 = add <8 x i64> %2071, splat (i64 28)
  %2073 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2070, 0
  %2074 = insertvalue { <8 x ptr>, <8 x i64> } %2073, <8 x i64> %2072, 1
  %2075 = extractvalue { <8 x ptr>, <8 x i64> } %2074, 0
  %2076 = extractvalue { <8 x ptr>, <8 x i64> } %2074, 1
  %2077 = getelementptr i8, <8 x ptr> %2075, <8 x i64> %2076
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2077, <8 x i1> %convergence.cascade.result454)
  %2078 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2079 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2080 = add <8 x i64> %2079, splat (i64 32)
  %2081 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2078, 0
  %2082 = insertvalue { <8 x ptr>, <8 x i64> } %2081, <8 x i64> %2080, 1
  %2083 = extractvalue { <8 x ptr>, <8 x i64> } %2082, 0
  %2084 = extractvalue { <8 x ptr>, <8 x i64> } %2082, 1
  %2085 = getelementptr i8, <8 x ptr> %2083, <8 x i64> %2084
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2085, <8 x i1> %convergence.cascade.result454)
  %2086 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2087 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2088 = add <8 x i64> %2087, splat (i64 36)
  %2089 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2086, 0
  %2090 = insertvalue { <8 x ptr>, <8 x i64> } %2089, <8 x i64> %2088, 1
  %2091 = extractvalue { <8 x ptr>, <8 x i64> } %2090, 0
  %2092 = extractvalue { <8 x ptr>, <8 x i64> } %2090, 1
  %2093 = getelementptr i8, <8 x ptr> %2091, <8 x i64> %2092
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2093, <8 x i1> %convergence.cascade.result454)
  %2094 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2095 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2096 = add <8 x i64> %2095, splat (i64 40)
  %2097 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2094, 0
  %2098 = insertvalue { <8 x ptr>, <8 x i64> } %2097, <8 x i64> %2096, 1
  %2099 = extractvalue { <8 x ptr>, <8 x i64> } %2098, 0
  %2100 = extractvalue { <8 x ptr>, <8 x i64> } %2098, 1
  %2101 = getelementptr i8, <8 x ptr> %2099, <8 x i64> %2100
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2101, <8 x i1> %convergence.cascade.result454)
  %2102 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2103 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2104 = add <8 x i64> %2103, splat (i64 44)
  %2105 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2102, 0
  %2106 = insertvalue { <8 x ptr>, <8 x i64> } %2105, <8 x i64> %2104, 1
  %2107 = extractvalue { <8 x ptr>, <8 x i64> } %2106, 0
  %2108 = extractvalue { <8 x ptr>, <8 x i64> } %2106, 1
  %2109 = getelementptr i8, <8 x ptr> %2107, <8 x i64> %2108
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2109, <8 x i1> %convergence.cascade.result454)
  %2110 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2111 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2112 = add <8 x i64> %2111, splat (i64 48)
  %2113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2110, 0
  %2114 = insertvalue { <8 x ptr>, <8 x i64> } %2113, <8 x i64> %2112, 1
  %2115 = extractvalue { <8 x ptr>, <8 x i64> } %2114, 0
  %2116 = extractvalue { <8 x ptr>, <8 x i64> } %2114, 1
  %2117 = getelementptr i8, <8 x ptr> %2115, <8 x i64> %2116
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2117, <8 x i1> %convergence.cascade.result454)
  %2118 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2119 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2120 = add <8 x i64> %2119, splat (i64 52)
  %2121 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2118, 0
  %2122 = insertvalue { <8 x ptr>, <8 x i64> } %2121, <8 x i64> %2120, 1
  %2123 = extractvalue { <8 x ptr>, <8 x i64> } %2122, 0
  %2124 = extractvalue { <8 x ptr>, <8 x i64> } %2122, 1
  %2125 = getelementptr i8, <8 x ptr> %2123, <8 x i64> %2124
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2125, <8 x i1> %convergence.cascade.result454)
  %2126 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2127 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2128 = add <8 x i64> %2127, splat (i64 56)
  %2129 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2126, 0
  %2130 = insertvalue { <8 x ptr>, <8 x i64> } %2129, <8 x i64> %2128, 1
  %2131 = extractvalue { <8 x ptr>, <8 x i64> } %2130, 0
  %2132 = extractvalue { <8 x ptr>, <8 x i64> } %2130, 1
  %2133 = getelementptr i8, <8 x ptr> %2131, <8 x i64> %2132
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2133, <8 x i1> %convergence.cascade.result454)
  %2134 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2135 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2136 = add <8 x i64> %2135, splat (i64 60)
  %2137 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2134, 0
  %2138 = insertvalue { <8 x ptr>, <8 x i64> } %2137, <8 x i64> %2136, 1
  %2139 = extractvalue { <8 x ptr>, <8 x i64> } %2138, 0
  %2140 = extractvalue { <8 x ptr>, <8 x i64> } %2138, 1
  %2141 = getelementptr i8, <8 x ptr> %2139, <8 x i64> %2140
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2141, <8 x i1> %convergence.cascade.result454)
  %2142 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2143 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2144 = add <8 x i64> %2143, splat (i64 64)
  %2145 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2142, 0
  %2146 = insertvalue { <8 x ptr>, <8 x i64> } %2145, <8 x i64> %2144, 1
  %2147 = extractvalue { <8 x ptr>, <8 x i64> } %2146, 0
  %2148 = extractvalue { <8 x ptr>, <8 x i64> } %2146, 1
  %2149 = getelementptr i8, <8 x ptr> %2147, <8 x i64> %2148
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2149, <8 x i1> %convergence.cascade.result454)
  %2150 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2151 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2152 = add <8 x i64> %2151, splat (i64 68)
  %2153 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2150, 0
  %2154 = insertvalue { <8 x ptr>, <8 x i64> } %2153, <8 x i64> %2152, 1
  %2155 = extractvalue { <8 x ptr>, <8 x i64> } %2154, 0
  %2156 = extractvalue { <8 x ptr>, <8 x i64> } %2154, 1
  %2157 = getelementptr i8, <8 x ptr> %2155, <8 x i64> %2156
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2157, <8 x i1> %convergence.cascade.result454)
  %2158 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2159 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2160 = add <8 x i64> %2159, splat (i64 72)
  %2161 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2158, 0
  %2162 = insertvalue { <8 x ptr>, <8 x i64> } %2161, <8 x i64> %2160, 1
  %2163 = extractvalue { <8 x ptr>, <8 x i64> } %2162, 0
  %2164 = extractvalue { <8 x ptr>, <8 x i64> } %2162, 1
  %2165 = getelementptr i8, <8 x ptr> %2163, <8 x i64> %2164
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2165, <8 x i1> %convergence.cascade.result454)
  %2166 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2168 = add <8 x i64> %2167, splat (i64 76)
  %2169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2166, 0
  %2170 = insertvalue { <8 x ptr>, <8 x i64> } %2169, <8 x i64> %2168, 1
  %2171 = extractvalue { <8 x ptr>, <8 x i64> } %2170, 0
  %2172 = extractvalue { <8 x ptr>, <8 x i64> } %2170, 1
  %2173 = getelementptr i8, <8 x ptr> %2171, <8 x i64> %2172
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2173, <8 x i1> %convergence.cascade.result454)
  %2174 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2175 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2176 = add <8 x i64> %2175, splat (i64 80)
  %2177 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2174, 0
  %2178 = insertvalue { <8 x ptr>, <8 x i64> } %2177, <8 x i64> %2176, 1
  %2179 = extractvalue { <8 x ptr>, <8 x i64> } %2178, 0
  %2180 = extractvalue { <8 x ptr>, <8 x i64> } %2178, 1
  %2181 = getelementptr i8, <8 x ptr> %2179, <8 x i64> %2180
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2181, <8 x i1> %convergence.cascade.result454)
  %2182 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2183 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2184 = add <8 x i64> %2183, splat (i64 84)
  %2185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2182, 0
  %2186 = insertvalue { <8 x ptr>, <8 x i64> } %2185, <8 x i64> %2184, 1
  %2187 = extractvalue { <8 x ptr>, <8 x i64> } %2186, 0
  %2188 = extractvalue { <8 x ptr>, <8 x i64> } %2186, 1
  %2189 = getelementptr i8, <8 x ptr> %2187, <8 x i64> %2188
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2189, <8 x i1> %convergence.cascade.result454)
  %2190 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2191 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2192 = add <8 x i64> %2191, splat (i64 88)
  %2193 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2190, 0
  %2194 = insertvalue { <8 x ptr>, <8 x i64> } %2193, <8 x i64> %2192, 1
  %2195 = extractvalue { <8 x ptr>, <8 x i64> } %2194, 0
  %2196 = extractvalue { <8 x ptr>, <8 x i64> } %2194, 1
  %2197 = getelementptr i8, <8 x ptr> %2195, <8 x i64> %2196
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2197, <8 x i1> %convergence.cascade.result454)
  %2198 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2199 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2200 = add <8 x i64> %2199, splat (i64 92)
  %2201 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2198, 0
  %2202 = insertvalue { <8 x ptr>, <8 x i64> } %2201, <8 x i64> %2200, 1
  %2203 = extractvalue { <8 x ptr>, <8 x i64> } %2202, 0
  %2204 = extractvalue { <8 x ptr>, <8 x i64> } %2202, 1
  %2205 = getelementptr i8, <8 x ptr> %2203, <8 x i64> %2204
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2205, <8 x i1> %convergence.cascade.result454)
  %2206 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2207 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2208 = add <8 x i64> %2207, splat (i64 96)
  %2209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2206, 0
  %2210 = insertvalue { <8 x ptr>, <8 x i64> } %2209, <8 x i64> %2208, 1
  %2211 = extractvalue { <8 x ptr>, <8 x i64> } %2210, 0
  %2212 = extractvalue { <8 x ptr>, <8 x i64> } %2210, 1
  %2213 = getelementptr i8, <8 x ptr> %2211, <8 x i64> %2212
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2213, <8 x i1> %convergence.cascade.result454)
  %2214 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2215 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2216 = add <8 x i64> %2215, splat (i64 100)
  %2217 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2214, 0
  %2218 = insertvalue { <8 x ptr>, <8 x i64> } %2217, <8 x i64> %2216, 1
  %2219 = extractvalue { <8 x ptr>, <8 x i64> } %2218, 0
  %2220 = extractvalue { <8 x ptr>, <8 x i64> } %2218, 1
  %2221 = getelementptr i8, <8 x ptr> %2219, <8 x i64> %2220
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2221, <8 x i1> %convergence.cascade.result454)
  %2222 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2223 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2224 = add <8 x i64> %2223, splat (i64 104)
  %2225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2222, 0
  %2226 = insertvalue { <8 x ptr>, <8 x i64> } %2225, <8 x i64> %2224, 1
  %2227 = extractvalue { <8 x ptr>, <8 x i64> } %2226, 0
  %2228 = extractvalue { <8 x ptr>, <8 x i64> } %2226, 1
  %2229 = getelementptr i8, <8 x ptr> %2227, <8 x i64> %2228
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2229, <8 x i1> %convergence.cascade.result454)
  %2230 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2231 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2232 = add <8 x i64> %2231, splat (i64 108)
  %2233 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2230, 0
  %2234 = insertvalue { <8 x ptr>, <8 x i64> } %2233, <8 x i64> %2232, 1
  %2235 = extractvalue { <8 x ptr>, <8 x i64> } %2234, 0
  %2236 = extractvalue { <8 x ptr>, <8 x i64> } %2234, 1
  %2237 = getelementptr i8, <8 x ptr> %2235, <8 x i64> %2236
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2237, <8 x i1> %convergence.cascade.result454)
  %2238 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2239 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2240 = add <8 x i64> %2239, splat (i64 112)
  %2241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2238, 0
  %2242 = insertvalue { <8 x ptr>, <8 x i64> } %2241, <8 x i64> %2240, 1
  %2243 = extractvalue { <8 x ptr>, <8 x i64> } %2242, 0
  %2244 = extractvalue { <8 x ptr>, <8 x i64> } %2242, 1
  %2245 = getelementptr i8, <8 x ptr> %2243, <8 x i64> %2244
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2245, <8 x i1> %convergence.cascade.result454)
  %2246 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2247 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2248 = add <8 x i64> %2247, splat (i64 116)
  %2249 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2246, 0
  %2250 = insertvalue { <8 x ptr>, <8 x i64> } %2249, <8 x i64> %2248, 1
  %2251 = extractvalue { <8 x ptr>, <8 x i64> } %2250, 0
  %2252 = extractvalue { <8 x ptr>, <8 x i64> } %2250, 1
  %2253 = getelementptr i8, <8 x ptr> %2251, <8 x i64> %2252
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2253, <8 x i1> %convergence.cascade.result454)
  %2254 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2255 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2256 = add <8 x i64> %2255, splat (i64 120)
  %2257 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2254, 0
  %2258 = insertvalue { <8 x ptr>, <8 x i64> } %2257, <8 x i64> %2256, 1
  %2259 = extractvalue { <8 x ptr>, <8 x i64> } %2258, 0
  %2260 = extractvalue { <8 x ptr>, <8 x i64> } %2258, 1
  %2261 = getelementptr i8, <8 x ptr> %2259, <8 x i64> %2260
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2261, <8 x i1> %convergence.cascade.result454)
  %2262 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2263 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2264 = add <8 x i64> %2263, splat (i64 124)
  %2265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2262, 0
  %2266 = insertvalue { <8 x ptr>, <8 x i64> } %2265, <8 x i64> %2264, 1
  %2267 = extractvalue { <8 x ptr>, <8 x i64> } %2266, 0
  %2268 = extractvalue { <8 x ptr>, <8 x i64> } %2266, 1
  %2269 = getelementptr i8, <8 x ptr> %2267, <8 x i64> %2268
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2269, <8 x i1> %convergence.cascade.result454)
  %2270 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2271 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2272 = add <8 x i64> %2271, splat (i64 128)
  %2273 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2270, 0
  %2274 = insertvalue { <8 x ptr>, <8 x i64> } %2273, <8 x i64> %2272, 1
  %2275 = extractvalue { <8 x ptr>, <8 x i64> } %2274, 0
  %2276 = extractvalue { <8 x ptr>, <8 x i64> } %2274, 1
  %2277 = getelementptr i8, <8 x ptr> %2275, <8 x i64> %2276
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2277, <8 x i1> %convergence.cascade.result454)
  %2278 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2279 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2280 = add <8 x i64> %2279, splat (i64 132)
  %2281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2278, 0
  %2282 = insertvalue { <8 x ptr>, <8 x i64> } %2281, <8 x i64> %2280, 1
  %2283 = extractvalue { <8 x ptr>, <8 x i64> } %2282, 0
  %2284 = extractvalue { <8 x ptr>, <8 x i64> } %2282, 1
  %2285 = getelementptr i8, <8 x ptr> %2283, <8 x i64> %2284
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2285, <8 x i1> %convergence.cascade.result454)
  %2286 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2287 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2288 = add <8 x i64> %2287, splat (i64 136)
  %2289 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2286, 0
  %2290 = insertvalue { <8 x ptr>, <8 x i64> } %2289, <8 x i64> %2288, 1
  %2291 = extractvalue { <8 x ptr>, <8 x i64> } %2290, 0
  %2292 = extractvalue { <8 x ptr>, <8 x i64> } %2290, 1
  %2293 = getelementptr i8, <8 x ptr> %2291, <8 x i64> %2292
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2293, <8 x i1> %convergence.cascade.result454)
  %2294 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2295 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2296 = add <8 x i64> %2295, splat (i64 140)
  %2297 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2294, 0
  %2298 = insertvalue { <8 x ptr>, <8 x i64> } %2297, <8 x i64> %2296, 1
  %2299 = extractvalue { <8 x ptr>, <8 x i64> } %2298, 0
  %2300 = extractvalue { <8 x ptr>, <8 x i64> } %2298, 1
  %2301 = getelementptr i8, <8 x ptr> %2299, <8 x i64> %2300
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2301, <8 x i1> %convergence.cascade.result454)
  %2302 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2303 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2304 = add <8 x i64> %2303, splat (i64 144)
  %2305 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2302, 0
  %2306 = insertvalue { <8 x ptr>, <8 x i64> } %2305, <8 x i64> %2304, 1
  %2307 = extractvalue { <8 x ptr>, <8 x i64> } %2306, 0
  %2308 = extractvalue { <8 x ptr>, <8 x i64> } %2306, 1
  %2309 = getelementptr i8, <8 x ptr> %2307, <8 x i64> %2308
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2309, <8 x i1> %convergence.cascade.result454)
  %2310 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2311 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2312 = add <8 x i64> %2311, splat (i64 148)
  %2313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2310, 0
  %2314 = insertvalue { <8 x ptr>, <8 x i64> } %2313, <8 x i64> %2312, 1
  %2315 = extractvalue { <8 x ptr>, <8 x i64> } %2314, 0
  %2316 = extractvalue { <8 x ptr>, <8 x i64> } %2314, 1
  %2317 = getelementptr i8, <8 x ptr> %2315, <8 x i64> %2316
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2317, <8 x i1> %convergence.cascade.result454)
  %2318 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2319 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2320 = add <8 x i64> %2319, splat (i64 152)
  %2321 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2318, 0
  %2322 = insertvalue { <8 x ptr>, <8 x i64> } %2321, <8 x i64> %2320, 1
  %2323 = extractvalue { <8 x ptr>, <8 x i64> } %2322, 0
  %2324 = extractvalue { <8 x ptr>, <8 x i64> } %2322, 1
  %2325 = getelementptr i8, <8 x ptr> %2323, <8 x i64> %2324
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2325, <8 x i1> %convergence.cascade.result454)
  %2326 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2327 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2328 = add <8 x i64> %2327, splat (i64 156)
  %2329 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2326, 0
  %2330 = insertvalue { <8 x ptr>, <8 x i64> } %2329, <8 x i64> %2328, 1
  %2331 = extractvalue { <8 x ptr>, <8 x i64> } %2330, 0
  %2332 = extractvalue { <8 x ptr>, <8 x i64> } %2330, 1
  %2333 = getelementptr i8, <8 x ptr> %2331, <8 x i64> %2332
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2333, <8 x i1> %convergence.cascade.result454)
  %2334 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2335 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2336 = add <8 x i64> %2335, splat (i64 160)
  %2337 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2334, 0
  %2338 = insertvalue { <8 x ptr>, <8 x i64> } %2337, <8 x i64> %2336, 1
  %2339 = extractvalue { <8 x ptr>, <8 x i64> } %2338, 0
  %2340 = extractvalue { <8 x ptr>, <8 x i64> } %2338, 1
  %2341 = getelementptr i8, <8 x ptr> %2339, <8 x i64> %2340
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2341, <8 x i1> %convergence.cascade.result454)
  %2342 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2343 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2344 = add <8 x i64> %2343, splat (i64 164)
  %2345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2342, 0
  %2346 = insertvalue { <8 x ptr>, <8 x i64> } %2345, <8 x i64> %2344, 1
  %2347 = extractvalue { <8 x ptr>, <8 x i64> } %2346, 0
  %2348 = extractvalue { <8 x ptr>, <8 x i64> } %2346, 1
  %2349 = getelementptr i8, <8 x ptr> %2347, <8 x i64> %2348
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2349, <8 x i1> %convergence.cascade.result454)
  %2350 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2351 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2352 = add <8 x i64> %2351, splat (i64 168)
  %2353 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2350, 0
  %2354 = insertvalue { <8 x ptr>, <8 x i64> } %2353, <8 x i64> %2352, 1
  %2355 = extractvalue { <8 x ptr>, <8 x i64> } %2354, 0
  %2356 = extractvalue { <8 x ptr>, <8 x i64> } %2354, 1
  %2357 = getelementptr i8, <8 x ptr> %2355, <8 x i64> %2356
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2357, <8 x i1> %convergence.cascade.result454)
  %2358 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2359 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2360 = add <8 x i64> %2359, splat (i64 172)
  %2361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2358, 0
  %2362 = insertvalue { <8 x ptr>, <8 x i64> } %2361, <8 x i64> %2360, 1
  %2363 = extractvalue { <8 x ptr>, <8 x i64> } %2362, 0
  %2364 = extractvalue { <8 x ptr>, <8 x i64> } %2362, 1
  %2365 = getelementptr i8, <8 x ptr> %2363, <8 x i64> %2364
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2365, <8 x i1> %convergence.cascade.result454)
  %2366 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2367 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2368 = add <8 x i64> %2367, splat (i64 176)
  %2369 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2366, 0
  %2370 = insertvalue { <8 x ptr>, <8 x i64> } %2369, <8 x i64> %2368, 1
  %2371 = extractvalue { <8 x ptr>, <8 x i64> } %2370, 0
  %2372 = extractvalue { <8 x ptr>, <8 x i64> } %2370, 1
  %2373 = getelementptr i8, <8 x ptr> %2371, <8 x i64> %2372
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2373, <8 x i1> %convergence.cascade.result454)
  %2374 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2375 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2376 = add <8 x i64> %2375, splat (i64 180)
  %2377 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2374, 0
  %2378 = insertvalue { <8 x ptr>, <8 x i64> } %2377, <8 x i64> %2376, 1
  %2379 = extractvalue { <8 x ptr>, <8 x i64> } %2378, 0
  %2380 = extractvalue { <8 x ptr>, <8 x i64> } %2378, 1
  %2381 = getelementptr i8, <8 x ptr> %2379, <8 x i64> %2380
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2381, <8 x i1> %convergence.cascade.result454)
  %2382 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2383 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2384 = add <8 x i64> %2383, splat (i64 184)
  %2385 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2382, 0
  %2386 = insertvalue { <8 x ptr>, <8 x i64> } %2385, <8 x i64> %2384, 1
  %2387 = extractvalue { <8 x ptr>, <8 x i64> } %2386, 0
  %2388 = extractvalue { <8 x ptr>, <8 x i64> } %2386, 1
  %2389 = getelementptr i8, <8 x ptr> %2387, <8 x i64> %2388
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2389, <8 x i1> %convergence.cascade.result454)
  %2390 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2391 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2392 = add <8 x i64> %2391, splat (i64 188)
  %2393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2390, 0
  %2394 = insertvalue { <8 x ptr>, <8 x i64> } %2393, <8 x i64> %2392, 1
  %2395 = extractvalue { <8 x ptr>, <8 x i64> } %2394, 0
  %2396 = extractvalue { <8 x ptr>, <8 x i64> } %2394, 1
  %2397 = getelementptr i8, <8 x ptr> %2395, <8 x i64> %2396
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2397, <8 x i1> %convergence.cascade.result454)
  %2398 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2399 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2400 = add <8 x i64> %2399, splat (i64 192)
  %2401 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2398, 0
  %2402 = insertvalue { <8 x ptr>, <8 x i64> } %2401, <8 x i64> %2400, 1
  %2403 = extractvalue { <8 x ptr>, <8 x i64> } %2402, 0
  %2404 = extractvalue { <8 x ptr>, <8 x i64> } %2402, 1
  %2405 = getelementptr i8, <8 x ptr> %2403, <8 x i64> %2404
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2405, <8 x i1> %convergence.cascade.result454)
  %2406 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2407 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2408 = add <8 x i64> %2407, splat (i64 196)
  %2409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2406, 0
  %2410 = insertvalue { <8 x ptr>, <8 x i64> } %2409, <8 x i64> %2408, 1
  %2411 = extractvalue { <8 x ptr>, <8 x i64> } %2410, 0
  %2412 = extractvalue { <8 x ptr>, <8 x i64> } %2410, 1
  %2413 = getelementptr i8, <8 x ptr> %2411, <8 x i64> %2412
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2413, <8 x i1> %convergence.cascade.result454)
  %2414 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2415 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2416 = add <8 x i64> %2415, splat (i64 200)
  %2417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2414, 0
  %2418 = insertvalue { <8 x ptr>, <8 x i64> } %2417, <8 x i64> %2416, 1
  %2419 = extractvalue { <8 x ptr>, <8 x i64> } %2418, 0
  %2420 = extractvalue { <8 x ptr>, <8 x i64> } %2418, 1
  %2421 = getelementptr i8, <8 x ptr> %2419, <8 x i64> %2420
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2421, <8 x i1> %convergence.cascade.result454)
  %2422 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2423 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2424 = add <8 x i64> %2423, splat (i64 204)
  %2425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2422, 0
  %2426 = insertvalue { <8 x ptr>, <8 x i64> } %2425, <8 x i64> %2424, 1
  %2427 = extractvalue { <8 x ptr>, <8 x i64> } %2426, 0
  %2428 = extractvalue { <8 x ptr>, <8 x i64> } %2426, 1
  %2429 = getelementptr i8, <8 x ptr> %2427, <8 x i64> %2428
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2429, <8 x i1> %convergence.cascade.result454)
  %2430 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2431 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2432 = add <8 x i64> %2431, splat (i64 208)
  %2433 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2430, 0
  %2434 = insertvalue { <8 x ptr>, <8 x i64> } %2433, <8 x i64> %2432, 1
  %2435 = extractvalue { <8 x ptr>, <8 x i64> } %2434, 0
  %2436 = extractvalue { <8 x ptr>, <8 x i64> } %2434, 1
  %2437 = getelementptr i8, <8 x ptr> %2435, <8 x i64> %2436
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2437, <8 x i1> %convergence.cascade.result454)
  %2438 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2439 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2440 = add <8 x i64> %2439, splat (i64 212)
  %2441 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2438, 0
  %2442 = insertvalue { <8 x ptr>, <8 x i64> } %2441, <8 x i64> %2440, 1
  %2443 = extractvalue { <8 x ptr>, <8 x i64> } %2442, 0
  %2444 = extractvalue { <8 x ptr>, <8 x i64> } %2442, 1
  %2445 = getelementptr i8, <8 x ptr> %2443, <8 x i64> %2444
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2445, <8 x i1> %convergence.cascade.result454)
  %2446 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2447 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2448 = add <8 x i64> %2447, splat (i64 216)
  %2449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2446, 0
  %2450 = insertvalue { <8 x ptr>, <8 x i64> } %2449, <8 x i64> %2448, 1
  %2451 = extractvalue { <8 x ptr>, <8 x i64> } %2450, 0
  %2452 = extractvalue { <8 x ptr>, <8 x i64> } %2450, 1
  %2453 = getelementptr i8, <8 x ptr> %2451, <8 x i64> %2452
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2453, <8 x i1> %convergence.cascade.result454)
  %2454 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2455 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2456 = add <8 x i64> %2455, splat (i64 220)
  %2457 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2454, 0
  %2458 = insertvalue { <8 x ptr>, <8 x i64> } %2457, <8 x i64> %2456, 1
  %2459 = extractvalue { <8 x ptr>, <8 x i64> } %2458, 0
  %2460 = extractvalue { <8 x ptr>, <8 x i64> } %2458, 1
  %2461 = getelementptr i8, <8 x ptr> %2459, <8 x i64> %2460
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2461, <8 x i1> %convergence.cascade.result454)
  %2462 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2463 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2464 = add <8 x i64> %2463, splat (i64 224)
  %2465 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2462, 0
  %2466 = insertvalue { <8 x ptr>, <8 x i64> } %2465, <8 x i64> %2464, 1
  %2467 = extractvalue { <8 x ptr>, <8 x i64> } %2466, 0
  %2468 = extractvalue { <8 x ptr>, <8 x i64> } %2466, 1
  %2469 = getelementptr i8, <8 x ptr> %2467, <8 x i64> %2468
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2469, <8 x i1> %convergence.cascade.result454)
  %2470 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2471 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2472 = add <8 x i64> %2471, splat (i64 228)
  %2473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2470, 0
  %2474 = insertvalue { <8 x ptr>, <8 x i64> } %2473, <8 x i64> %2472, 1
  %2475 = extractvalue { <8 x ptr>, <8 x i64> } %2474, 0
  %2476 = extractvalue { <8 x ptr>, <8 x i64> } %2474, 1
  %2477 = getelementptr i8, <8 x ptr> %2475, <8 x i64> %2476
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2477, <8 x i1> %convergence.cascade.result454)
  %2478 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2479 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2480 = add <8 x i64> %2479, splat (i64 232)
  %2481 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2478, 0
  %2482 = insertvalue { <8 x ptr>, <8 x i64> } %2481, <8 x i64> %2480, 1
  %2483 = extractvalue { <8 x ptr>, <8 x i64> } %2482, 0
  %2484 = extractvalue { <8 x ptr>, <8 x i64> } %2482, 1
  %2485 = getelementptr i8, <8 x ptr> %2483, <8 x i64> %2484
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2485, <8 x i1> %convergence.cascade.result454)
  %2486 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2487 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2488 = add <8 x i64> %2487, splat (i64 236)
  %2489 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2486, 0
  %2490 = insertvalue { <8 x ptr>, <8 x i64> } %2489, <8 x i64> %2488, 1
  %2491 = extractvalue { <8 x ptr>, <8 x i64> } %2490, 0
  %2492 = extractvalue { <8 x ptr>, <8 x i64> } %2490, 1
  %2493 = getelementptr i8, <8 x ptr> %2491, <8 x i64> %2492
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2493, <8 x i1> %convergence.cascade.result454)
  %2494 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2495 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2496 = add <8 x i64> %2495, splat (i64 240)
  %2497 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2494, 0
  %2498 = insertvalue { <8 x ptr>, <8 x i64> } %2497, <8 x i64> %2496, 1
  %2499 = extractvalue { <8 x ptr>, <8 x i64> } %2498, 0
  %2500 = extractvalue { <8 x ptr>, <8 x i64> } %2498, 1
  %2501 = getelementptr i8, <8 x ptr> %2499, <8 x i64> %2500
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2501, <8 x i1> %convergence.cascade.result454)
  %2502 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2503 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2504 = add <8 x i64> %2503, splat (i64 244)
  %2505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2502, 0
  %2506 = insertvalue { <8 x ptr>, <8 x i64> } %2505, <8 x i64> %2504, 1
  %2507 = extractvalue { <8 x ptr>, <8 x i64> } %2506, 0
  %2508 = extractvalue { <8 x ptr>, <8 x i64> } %2506, 1
  %2509 = getelementptr i8, <8 x ptr> %2507, <8 x i64> %2508
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2509, <8 x i1> %convergence.cascade.result454)
  %2510 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2511 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2512 = add <8 x i64> %2511, splat (i64 248)
  %2513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2510, 0
  %2514 = insertvalue { <8 x ptr>, <8 x i64> } %2513, <8 x i64> %2512, 1
  %2515 = extractvalue { <8 x ptr>, <8 x i64> } %2514, 0
  %2516 = extractvalue { <8 x ptr>, <8 x i64> } %2514, 1
  %2517 = getelementptr i8, <8 x ptr> %2515, <8 x i64> %2516
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2517, <8 x i1> %convergence.cascade.result454)
  %2518 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2519 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2520 = add <8 x i64> %2519, splat (i64 252)
  %2521 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2518, 0
  %2522 = insertvalue { <8 x ptr>, <8 x i64> } %2521, <8 x i64> %2520, 1
  %2523 = extractvalue { <8 x ptr>, <8 x i64> } %2522, 0
  %2524 = extractvalue { <8 x ptr>, <8 x i64> } %2522, 1
  %2525 = getelementptr i8, <8 x ptr> %2523, <8 x i64> %2524
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %2525, <8 x i1> %convergence.cascade.result454)
  %tile_snapshot.spill.load455 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %tile_snapshot.spill.load456 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2526 = extractelement <8 x i1> %convergence.cascade.result454, i64 0
  br i1 %2526, label %mma.active, label %mma.continue

mma.active:                                       ; preds = %convergence.target.20.ready
  %2527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %2528 = extractelement <8 x ptr> %2527, i64 0
  %2529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %2530 = extractelement <8 x i64> %2529, i64 0
  %2531 = getelementptr i8, ptr %2528, i64 %2530
  %2532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %2533 = extractelement <8 x ptr> %2532, i64 0
  %2534 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %2535 = extractelement <8 x i64> %2534, i64 0
  %2536 = getelementptr i8, ptr %2533, i64 %2535
  %2537 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2538 = extractelement <8 x ptr> %2537, i64 0
  %2539 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2540 = extractelement <8 x i64> %2539, i64 0
  %2541 = getelementptr i8, ptr %2538, i64 %2540
  %2542 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2543 = extractelement <8 x ptr> %2542, i64 0
  %2544 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2545 = extractelement <8 x i64> %2544, i64 0
  %2546 = getelementptr i8, ptr %2543, i64 %2545
  call void @llm_attention.strided_mma(ptr %2531, ptr %2536, ptr %2541, ptr %2546)
  br label %mma.continue

mma.continue:                                     ; preds = %mma.active, %convergence.target.20.ready
  %2547 = extractelement <8 x i1> %convergence.cascade.result454, i64 1
  br i1 %2547, label %mma.active457, label %mma.continue458

mma.active457:                                    ; preds = %mma.continue
  %2548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %2549 = extractelement <8 x ptr> %2548, i64 1
  %2550 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %2551 = extractelement <8 x i64> %2550, i64 1
  %2552 = getelementptr i8, ptr %2549, i64 %2551
  %2553 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %2554 = extractelement <8 x ptr> %2553, i64 1
  %2555 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %2556 = extractelement <8 x i64> %2555, i64 1
  %2557 = getelementptr i8, ptr %2554, i64 %2556
  %2558 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2559 = extractelement <8 x ptr> %2558, i64 1
  %2560 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2561 = extractelement <8 x i64> %2560, i64 1
  %2562 = getelementptr i8, ptr %2559, i64 %2561
  %2563 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2564 = extractelement <8 x ptr> %2563, i64 1
  %2565 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2566 = extractelement <8 x i64> %2565, i64 1
  %2567 = getelementptr i8, ptr %2564, i64 %2566
  call void @llm_attention.strided_mma(ptr %2552, ptr %2557, ptr %2562, ptr %2567)
  br label %mma.continue458

mma.continue458:                                  ; preds = %mma.active457, %mma.continue
  %2568 = extractelement <8 x i1> %convergence.cascade.result454, i64 2
  br i1 %2568, label %mma.active459, label %mma.continue460

mma.active459:                                    ; preds = %mma.continue458
  %2569 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %2570 = extractelement <8 x ptr> %2569, i64 2
  %2571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %2572 = extractelement <8 x i64> %2571, i64 2
  %2573 = getelementptr i8, ptr %2570, i64 %2572
  %2574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %2575 = extractelement <8 x ptr> %2574, i64 2
  %2576 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %2577 = extractelement <8 x i64> %2576, i64 2
  %2578 = getelementptr i8, ptr %2575, i64 %2577
  %2579 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2580 = extractelement <8 x ptr> %2579, i64 2
  %2581 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2582 = extractelement <8 x i64> %2581, i64 2
  %2583 = getelementptr i8, ptr %2580, i64 %2582
  %2584 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2585 = extractelement <8 x ptr> %2584, i64 2
  %2586 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2587 = extractelement <8 x i64> %2586, i64 2
  %2588 = getelementptr i8, ptr %2585, i64 %2587
  call void @llm_attention.strided_mma(ptr %2573, ptr %2578, ptr %2583, ptr %2588)
  br label %mma.continue460

mma.continue460:                                  ; preds = %mma.active459, %mma.continue458
  %2589 = extractelement <8 x i1> %convergence.cascade.result454, i64 3
  br i1 %2589, label %mma.active461, label %mma.continue462

mma.active461:                                    ; preds = %mma.continue460
  %2590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %2591 = extractelement <8 x ptr> %2590, i64 3
  %2592 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %2593 = extractelement <8 x i64> %2592, i64 3
  %2594 = getelementptr i8, ptr %2591, i64 %2593
  %2595 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %2596 = extractelement <8 x ptr> %2595, i64 3
  %2597 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %2598 = extractelement <8 x i64> %2597, i64 3
  %2599 = getelementptr i8, ptr %2596, i64 %2598
  %2600 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2601 = extractelement <8 x ptr> %2600, i64 3
  %2602 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2603 = extractelement <8 x i64> %2602, i64 3
  %2604 = getelementptr i8, ptr %2601, i64 %2603
  %2605 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2606 = extractelement <8 x ptr> %2605, i64 3
  %2607 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2608 = extractelement <8 x i64> %2607, i64 3
  %2609 = getelementptr i8, ptr %2606, i64 %2608
  call void @llm_attention.strided_mma(ptr %2594, ptr %2599, ptr %2604, ptr %2609)
  br label %mma.continue462

mma.continue462:                                  ; preds = %mma.active461, %mma.continue460
  %2610 = extractelement <8 x i1> %convergence.cascade.result454, i64 4
  br i1 %2610, label %mma.active463, label %mma.continue464

mma.active463:                                    ; preds = %mma.continue462
  %2611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %2612 = extractelement <8 x ptr> %2611, i64 4
  %2613 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %2614 = extractelement <8 x i64> %2613, i64 4
  %2615 = getelementptr i8, ptr %2612, i64 %2614
  %2616 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %2617 = extractelement <8 x ptr> %2616, i64 4
  %2618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %2619 = extractelement <8 x i64> %2618, i64 4
  %2620 = getelementptr i8, ptr %2617, i64 %2619
  %2621 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2622 = extractelement <8 x ptr> %2621, i64 4
  %2623 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2624 = extractelement <8 x i64> %2623, i64 4
  %2625 = getelementptr i8, ptr %2622, i64 %2624
  %2626 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2627 = extractelement <8 x ptr> %2626, i64 4
  %2628 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2629 = extractelement <8 x i64> %2628, i64 4
  %2630 = getelementptr i8, ptr %2627, i64 %2629
  call void @llm_attention.strided_mma(ptr %2615, ptr %2620, ptr %2625, ptr %2630)
  br label %mma.continue464

mma.continue464:                                  ; preds = %mma.active463, %mma.continue462
  %2631 = extractelement <8 x i1> %convergence.cascade.result454, i64 5
  br i1 %2631, label %mma.active465, label %mma.continue466

mma.active465:                                    ; preds = %mma.continue464
  %2632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %2633 = extractelement <8 x ptr> %2632, i64 5
  %2634 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %2635 = extractelement <8 x i64> %2634, i64 5
  %2636 = getelementptr i8, ptr %2633, i64 %2635
  %2637 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %2638 = extractelement <8 x ptr> %2637, i64 5
  %2639 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %2640 = extractelement <8 x i64> %2639, i64 5
  %2641 = getelementptr i8, ptr %2638, i64 %2640
  %2642 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2643 = extractelement <8 x ptr> %2642, i64 5
  %2644 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2645 = extractelement <8 x i64> %2644, i64 5
  %2646 = getelementptr i8, ptr %2643, i64 %2645
  %2647 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2648 = extractelement <8 x ptr> %2647, i64 5
  %2649 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2650 = extractelement <8 x i64> %2649, i64 5
  %2651 = getelementptr i8, ptr %2648, i64 %2650
  call void @llm_attention.strided_mma(ptr %2636, ptr %2641, ptr %2646, ptr %2651)
  br label %mma.continue466

mma.continue466:                                  ; preds = %mma.active465, %mma.continue464
  %2652 = extractelement <8 x i1> %convergence.cascade.result454, i64 6
  br i1 %2652, label %mma.active467, label %mma.continue468

mma.active467:                                    ; preds = %mma.continue466
  %2653 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %2654 = extractelement <8 x ptr> %2653, i64 6
  %2655 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %2656 = extractelement <8 x i64> %2655, i64 6
  %2657 = getelementptr i8, ptr %2654, i64 %2656
  %2658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %2659 = extractelement <8 x ptr> %2658, i64 6
  %2660 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %2661 = extractelement <8 x i64> %2660, i64 6
  %2662 = getelementptr i8, ptr %2659, i64 %2661
  %2663 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2664 = extractelement <8 x ptr> %2663, i64 6
  %2665 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2666 = extractelement <8 x i64> %2665, i64 6
  %2667 = getelementptr i8, ptr %2664, i64 %2666
  %2668 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2669 = extractelement <8 x ptr> %2668, i64 6
  %2670 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2671 = extractelement <8 x i64> %2670, i64 6
  %2672 = getelementptr i8, ptr %2669, i64 %2671
  call void @llm_attention.strided_mma(ptr %2657, ptr %2662, ptr %2667, ptr %2672)
  br label %mma.continue468

mma.continue468:                                  ; preds = %mma.active467, %mma.continue466
  %2673 = extractelement <8 x i1> %convergence.cascade.result454, i64 7
  br i1 %2673, label %mma.active469, label %mma.continue470

mma.active469:                                    ; preds = %mma.continue468
  %2674 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %2675 = extractelement <8 x ptr> %2674, i64 7
  %2676 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %2677 = extractelement <8 x i64> %2676, i64 7
  %2678 = getelementptr i8, ptr %2675, i64 %2677
  %2679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 0
  %2680 = extractelement <8 x ptr> %2679, i64 7
  %2681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load456, 1
  %2682 = extractelement <8 x i64> %2681, i64 7
  %2683 = getelementptr i8, ptr %2680, i64 %2682
  %2684 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2685 = extractelement <8 x ptr> %2684, i64 7
  %2686 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %2687 = extractelement <8 x i64> %2686, i64 7
  %2688 = getelementptr i8, ptr %2685, i64 %2687
  %2689 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2690 = extractelement <8 x ptr> %2689, i64 7
  %2691 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2692 = extractelement <8 x i64> %2691, i64 7
  %2693 = getelementptr i8, ptr %2690, i64 %2692
  call void @llm_attention.strided_mma(ptr %2678, ptr %2683, ptr %2688, ptr %2693)
  br label %mma.continue470

mma.continue470:                                  ; preds = %mma.active469, %mma.continue468
  %2694 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2695 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2696 = add <8 x i64> %2695, zeroinitializer
  %2697 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2694, 0
  %2698 = insertvalue { <8 x ptr>, <8 x i64> } %2697, <8 x i64> %2696, 1
  %2699 = extractvalue { <8 x ptr>, <8 x i64> } %2698, 0
  %2700 = extractvalue { <8 x ptr>, <8 x i64> } %2698, 1
  %2701 = getelementptr i8, <8 x ptr> %2699, <8 x i64> %2700
  %2702 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2701, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2703 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2704 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2705 = add <8 x i64> %2704, splat (i64 4)
  %2706 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2703, 0
  %2707 = insertvalue { <8 x ptr>, <8 x i64> } %2706, <8 x i64> %2705, 1
  %2708 = extractvalue { <8 x ptr>, <8 x i64> } %2707, 0
  %2709 = extractvalue { <8 x ptr>, <8 x i64> } %2707, 1
  %2710 = getelementptr i8, <8 x ptr> %2708, <8 x i64> %2709
  %2711 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2710, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2712 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2713 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2714 = add <8 x i64> %2713, splat (i64 8)
  %2715 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2712, 0
  %2716 = insertvalue { <8 x ptr>, <8 x i64> } %2715, <8 x i64> %2714, 1
  %2717 = extractvalue { <8 x ptr>, <8 x i64> } %2716, 0
  %2718 = extractvalue { <8 x ptr>, <8 x i64> } %2716, 1
  %2719 = getelementptr i8, <8 x ptr> %2717, <8 x i64> %2718
  %2720 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2719, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2721 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2722 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2723 = add <8 x i64> %2722, splat (i64 12)
  %2724 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2721, 0
  %2725 = insertvalue { <8 x ptr>, <8 x i64> } %2724, <8 x i64> %2723, 1
  %2726 = extractvalue { <8 x ptr>, <8 x i64> } %2725, 0
  %2727 = extractvalue { <8 x ptr>, <8 x i64> } %2725, 1
  %2728 = getelementptr i8, <8 x ptr> %2726, <8 x i64> %2727
  %2729 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2728, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2730 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2731 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2732 = add <8 x i64> %2731, splat (i64 16)
  %2733 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2730, 0
  %2734 = insertvalue { <8 x ptr>, <8 x i64> } %2733, <8 x i64> %2732, 1
  %2735 = extractvalue { <8 x ptr>, <8 x i64> } %2734, 0
  %2736 = extractvalue { <8 x ptr>, <8 x i64> } %2734, 1
  %2737 = getelementptr i8, <8 x ptr> %2735, <8 x i64> %2736
  %2738 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2737, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2739 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2740 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2741 = add <8 x i64> %2740, splat (i64 20)
  %2742 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2739, 0
  %2743 = insertvalue { <8 x ptr>, <8 x i64> } %2742, <8 x i64> %2741, 1
  %2744 = extractvalue { <8 x ptr>, <8 x i64> } %2743, 0
  %2745 = extractvalue { <8 x ptr>, <8 x i64> } %2743, 1
  %2746 = getelementptr i8, <8 x ptr> %2744, <8 x i64> %2745
  %2747 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2746, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2748 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2749 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2750 = add <8 x i64> %2749, splat (i64 24)
  %2751 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2748, 0
  %2752 = insertvalue { <8 x ptr>, <8 x i64> } %2751, <8 x i64> %2750, 1
  %2753 = extractvalue { <8 x ptr>, <8 x i64> } %2752, 0
  %2754 = extractvalue { <8 x ptr>, <8 x i64> } %2752, 1
  %2755 = getelementptr i8, <8 x ptr> %2753, <8 x i64> %2754
  %2756 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2755, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2757 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2758 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2759 = add <8 x i64> %2758, splat (i64 28)
  %2760 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2757, 0
  %2761 = insertvalue { <8 x ptr>, <8 x i64> } %2760, <8 x i64> %2759, 1
  %2762 = extractvalue { <8 x ptr>, <8 x i64> } %2761, 0
  %2763 = extractvalue { <8 x ptr>, <8 x i64> } %2761, 1
  %2764 = getelementptr i8, <8 x ptr> %2762, <8 x i64> %2763
  %2765 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2764, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2766 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2767 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2768 = add <8 x i64> %2767, splat (i64 32)
  %2769 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2766, 0
  %2770 = insertvalue { <8 x ptr>, <8 x i64> } %2769, <8 x i64> %2768, 1
  %2771 = extractvalue { <8 x ptr>, <8 x i64> } %2770, 0
  %2772 = extractvalue { <8 x ptr>, <8 x i64> } %2770, 1
  %2773 = getelementptr i8, <8 x ptr> %2771, <8 x i64> %2772
  %2774 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2773, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2775 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2776 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2777 = add <8 x i64> %2776, splat (i64 36)
  %2778 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2775, 0
  %2779 = insertvalue { <8 x ptr>, <8 x i64> } %2778, <8 x i64> %2777, 1
  %2780 = extractvalue { <8 x ptr>, <8 x i64> } %2779, 0
  %2781 = extractvalue { <8 x ptr>, <8 x i64> } %2779, 1
  %2782 = getelementptr i8, <8 x ptr> %2780, <8 x i64> %2781
  %2783 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2782, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2784 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2785 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2786 = add <8 x i64> %2785, splat (i64 40)
  %2787 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2784, 0
  %2788 = insertvalue { <8 x ptr>, <8 x i64> } %2787, <8 x i64> %2786, 1
  %2789 = extractvalue { <8 x ptr>, <8 x i64> } %2788, 0
  %2790 = extractvalue { <8 x ptr>, <8 x i64> } %2788, 1
  %2791 = getelementptr i8, <8 x ptr> %2789, <8 x i64> %2790
  %2792 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2791, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2793 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2794 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2795 = add <8 x i64> %2794, splat (i64 44)
  %2796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2793, 0
  %2797 = insertvalue { <8 x ptr>, <8 x i64> } %2796, <8 x i64> %2795, 1
  %2798 = extractvalue { <8 x ptr>, <8 x i64> } %2797, 0
  %2799 = extractvalue { <8 x ptr>, <8 x i64> } %2797, 1
  %2800 = getelementptr i8, <8 x ptr> %2798, <8 x i64> %2799
  %2801 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2800, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2802 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2803 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2804 = add <8 x i64> %2803, splat (i64 48)
  %2805 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2802, 0
  %2806 = insertvalue { <8 x ptr>, <8 x i64> } %2805, <8 x i64> %2804, 1
  %2807 = extractvalue { <8 x ptr>, <8 x i64> } %2806, 0
  %2808 = extractvalue { <8 x ptr>, <8 x i64> } %2806, 1
  %2809 = getelementptr i8, <8 x ptr> %2807, <8 x i64> %2808
  %2810 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2809, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2811 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2812 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2813 = add <8 x i64> %2812, splat (i64 52)
  %2814 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2811, 0
  %2815 = insertvalue { <8 x ptr>, <8 x i64> } %2814, <8 x i64> %2813, 1
  %2816 = extractvalue { <8 x ptr>, <8 x i64> } %2815, 0
  %2817 = extractvalue { <8 x ptr>, <8 x i64> } %2815, 1
  %2818 = getelementptr i8, <8 x ptr> %2816, <8 x i64> %2817
  %2819 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2818, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2820 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2821 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2822 = add <8 x i64> %2821, splat (i64 56)
  %2823 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2820, 0
  %2824 = insertvalue { <8 x ptr>, <8 x i64> } %2823, <8 x i64> %2822, 1
  %2825 = extractvalue { <8 x ptr>, <8 x i64> } %2824, 0
  %2826 = extractvalue { <8 x ptr>, <8 x i64> } %2824, 1
  %2827 = getelementptr i8, <8 x ptr> %2825, <8 x i64> %2826
  %2828 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2827, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2829 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2830 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2831 = add <8 x i64> %2830, splat (i64 60)
  %2832 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2829, 0
  %2833 = insertvalue { <8 x ptr>, <8 x i64> } %2832, <8 x i64> %2831, 1
  %2834 = extractvalue { <8 x ptr>, <8 x i64> } %2833, 0
  %2835 = extractvalue { <8 x ptr>, <8 x i64> } %2833, 1
  %2836 = getelementptr i8, <8 x ptr> %2834, <8 x i64> %2835
  %2837 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2836, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2838 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2839 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2840 = add <8 x i64> %2839, splat (i64 64)
  %2841 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2838, 0
  %2842 = insertvalue { <8 x ptr>, <8 x i64> } %2841, <8 x i64> %2840, 1
  %2843 = extractvalue { <8 x ptr>, <8 x i64> } %2842, 0
  %2844 = extractvalue { <8 x ptr>, <8 x i64> } %2842, 1
  %2845 = getelementptr i8, <8 x ptr> %2843, <8 x i64> %2844
  %2846 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2845, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2847 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2848 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2849 = add <8 x i64> %2848, splat (i64 68)
  %2850 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2847, 0
  %2851 = insertvalue { <8 x ptr>, <8 x i64> } %2850, <8 x i64> %2849, 1
  %2852 = extractvalue { <8 x ptr>, <8 x i64> } %2851, 0
  %2853 = extractvalue { <8 x ptr>, <8 x i64> } %2851, 1
  %2854 = getelementptr i8, <8 x ptr> %2852, <8 x i64> %2853
  %2855 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2854, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2856 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2857 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2858 = add <8 x i64> %2857, splat (i64 72)
  %2859 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2856, 0
  %2860 = insertvalue { <8 x ptr>, <8 x i64> } %2859, <8 x i64> %2858, 1
  %2861 = extractvalue { <8 x ptr>, <8 x i64> } %2860, 0
  %2862 = extractvalue { <8 x ptr>, <8 x i64> } %2860, 1
  %2863 = getelementptr i8, <8 x ptr> %2861, <8 x i64> %2862
  %2864 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2863, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2865 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2866 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2867 = add <8 x i64> %2866, splat (i64 76)
  %2868 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2865, 0
  %2869 = insertvalue { <8 x ptr>, <8 x i64> } %2868, <8 x i64> %2867, 1
  %2870 = extractvalue { <8 x ptr>, <8 x i64> } %2869, 0
  %2871 = extractvalue { <8 x ptr>, <8 x i64> } %2869, 1
  %2872 = getelementptr i8, <8 x ptr> %2870, <8 x i64> %2871
  %2873 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2872, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2874 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2875 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2876 = add <8 x i64> %2875, splat (i64 80)
  %2877 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2874, 0
  %2878 = insertvalue { <8 x ptr>, <8 x i64> } %2877, <8 x i64> %2876, 1
  %2879 = extractvalue { <8 x ptr>, <8 x i64> } %2878, 0
  %2880 = extractvalue { <8 x ptr>, <8 x i64> } %2878, 1
  %2881 = getelementptr i8, <8 x ptr> %2879, <8 x i64> %2880
  %2882 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2881, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2883 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2884 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2885 = add <8 x i64> %2884, splat (i64 84)
  %2886 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2883, 0
  %2887 = insertvalue { <8 x ptr>, <8 x i64> } %2886, <8 x i64> %2885, 1
  %2888 = extractvalue { <8 x ptr>, <8 x i64> } %2887, 0
  %2889 = extractvalue { <8 x ptr>, <8 x i64> } %2887, 1
  %2890 = getelementptr i8, <8 x ptr> %2888, <8 x i64> %2889
  %2891 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2890, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2892 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2893 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2894 = add <8 x i64> %2893, splat (i64 88)
  %2895 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2892, 0
  %2896 = insertvalue { <8 x ptr>, <8 x i64> } %2895, <8 x i64> %2894, 1
  %2897 = extractvalue { <8 x ptr>, <8 x i64> } %2896, 0
  %2898 = extractvalue { <8 x ptr>, <8 x i64> } %2896, 1
  %2899 = getelementptr i8, <8 x ptr> %2897, <8 x i64> %2898
  %2900 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2899, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2901 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2902 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2903 = add <8 x i64> %2902, splat (i64 92)
  %2904 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2901, 0
  %2905 = insertvalue { <8 x ptr>, <8 x i64> } %2904, <8 x i64> %2903, 1
  %2906 = extractvalue { <8 x ptr>, <8 x i64> } %2905, 0
  %2907 = extractvalue { <8 x ptr>, <8 x i64> } %2905, 1
  %2908 = getelementptr i8, <8 x ptr> %2906, <8 x i64> %2907
  %2909 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2908, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2910 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2911 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2912 = add <8 x i64> %2911, splat (i64 96)
  %2913 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2910, 0
  %2914 = insertvalue { <8 x ptr>, <8 x i64> } %2913, <8 x i64> %2912, 1
  %2915 = extractvalue { <8 x ptr>, <8 x i64> } %2914, 0
  %2916 = extractvalue { <8 x ptr>, <8 x i64> } %2914, 1
  %2917 = getelementptr i8, <8 x ptr> %2915, <8 x i64> %2916
  %2918 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2917, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2919 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2920 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2921 = add <8 x i64> %2920, splat (i64 100)
  %2922 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2919, 0
  %2923 = insertvalue { <8 x ptr>, <8 x i64> } %2922, <8 x i64> %2921, 1
  %2924 = extractvalue { <8 x ptr>, <8 x i64> } %2923, 0
  %2925 = extractvalue { <8 x ptr>, <8 x i64> } %2923, 1
  %2926 = getelementptr i8, <8 x ptr> %2924, <8 x i64> %2925
  %2927 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2926, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2928 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2929 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2930 = add <8 x i64> %2929, splat (i64 104)
  %2931 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2928, 0
  %2932 = insertvalue { <8 x ptr>, <8 x i64> } %2931, <8 x i64> %2930, 1
  %2933 = extractvalue { <8 x ptr>, <8 x i64> } %2932, 0
  %2934 = extractvalue { <8 x ptr>, <8 x i64> } %2932, 1
  %2935 = getelementptr i8, <8 x ptr> %2933, <8 x i64> %2934
  %2936 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2935, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2937 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2938 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2939 = add <8 x i64> %2938, splat (i64 108)
  %2940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2937, 0
  %2941 = insertvalue { <8 x ptr>, <8 x i64> } %2940, <8 x i64> %2939, 1
  %2942 = extractvalue { <8 x ptr>, <8 x i64> } %2941, 0
  %2943 = extractvalue { <8 x ptr>, <8 x i64> } %2941, 1
  %2944 = getelementptr i8, <8 x ptr> %2942, <8 x i64> %2943
  %2945 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2944, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2946 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2947 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2948 = add <8 x i64> %2947, splat (i64 112)
  %2949 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2946, 0
  %2950 = insertvalue { <8 x ptr>, <8 x i64> } %2949, <8 x i64> %2948, 1
  %2951 = extractvalue { <8 x ptr>, <8 x i64> } %2950, 0
  %2952 = extractvalue { <8 x ptr>, <8 x i64> } %2950, 1
  %2953 = getelementptr i8, <8 x ptr> %2951, <8 x i64> %2952
  %2954 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2953, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2955 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2956 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2957 = add <8 x i64> %2956, splat (i64 116)
  %2958 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2955, 0
  %2959 = insertvalue { <8 x ptr>, <8 x i64> } %2958, <8 x i64> %2957, 1
  %2960 = extractvalue { <8 x ptr>, <8 x i64> } %2959, 0
  %2961 = extractvalue { <8 x ptr>, <8 x i64> } %2959, 1
  %2962 = getelementptr i8, <8 x ptr> %2960, <8 x i64> %2961
  %2963 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2962, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2964 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2965 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2966 = add <8 x i64> %2965, splat (i64 120)
  %2967 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2964, 0
  %2968 = insertvalue { <8 x ptr>, <8 x i64> } %2967, <8 x i64> %2966, 1
  %2969 = extractvalue { <8 x ptr>, <8 x i64> } %2968, 0
  %2970 = extractvalue { <8 x ptr>, <8 x i64> } %2968, 1
  %2971 = getelementptr i8, <8 x ptr> %2969, <8 x i64> %2970
  %2972 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2971, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2973 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2974 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2975 = add <8 x i64> %2974, splat (i64 124)
  %2976 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2973, 0
  %2977 = insertvalue { <8 x ptr>, <8 x i64> } %2976, <8 x i64> %2975, 1
  %2978 = extractvalue { <8 x ptr>, <8 x i64> } %2977, 0
  %2979 = extractvalue { <8 x ptr>, <8 x i64> } %2977, 1
  %2980 = getelementptr i8, <8 x ptr> %2978, <8 x i64> %2979
  %2981 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2980, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2982 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2983 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2984 = add <8 x i64> %2983, splat (i64 128)
  %2985 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2982, 0
  %2986 = insertvalue { <8 x ptr>, <8 x i64> } %2985, <8 x i64> %2984, 1
  %2987 = extractvalue { <8 x ptr>, <8 x i64> } %2986, 0
  %2988 = extractvalue { <8 x ptr>, <8 x i64> } %2986, 1
  %2989 = getelementptr i8, <8 x ptr> %2987, <8 x i64> %2988
  %2990 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2989, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %2991 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2992 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2993 = add <8 x i64> %2992, splat (i64 132)
  %2994 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2991, 0
  %2995 = insertvalue { <8 x ptr>, <8 x i64> } %2994, <8 x i64> %2993, 1
  %2996 = extractvalue { <8 x ptr>, <8 x i64> } %2995, 0
  %2997 = extractvalue { <8 x ptr>, <8 x i64> } %2995, 1
  %2998 = getelementptr i8, <8 x ptr> %2996, <8 x i64> %2997
  %2999 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2998, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3000 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3001 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3002 = add <8 x i64> %3001, splat (i64 136)
  %3003 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3000, 0
  %3004 = insertvalue { <8 x ptr>, <8 x i64> } %3003, <8 x i64> %3002, 1
  %3005 = extractvalue { <8 x ptr>, <8 x i64> } %3004, 0
  %3006 = extractvalue { <8 x ptr>, <8 x i64> } %3004, 1
  %3007 = getelementptr i8, <8 x ptr> %3005, <8 x i64> %3006
  %3008 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3007, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3009 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3010 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3011 = add <8 x i64> %3010, splat (i64 140)
  %3012 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3009, 0
  %3013 = insertvalue { <8 x ptr>, <8 x i64> } %3012, <8 x i64> %3011, 1
  %3014 = extractvalue { <8 x ptr>, <8 x i64> } %3013, 0
  %3015 = extractvalue { <8 x ptr>, <8 x i64> } %3013, 1
  %3016 = getelementptr i8, <8 x ptr> %3014, <8 x i64> %3015
  %3017 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3016, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3018 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3019 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3020 = add <8 x i64> %3019, splat (i64 144)
  %3021 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3018, 0
  %3022 = insertvalue { <8 x ptr>, <8 x i64> } %3021, <8 x i64> %3020, 1
  %3023 = extractvalue { <8 x ptr>, <8 x i64> } %3022, 0
  %3024 = extractvalue { <8 x ptr>, <8 x i64> } %3022, 1
  %3025 = getelementptr i8, <8 x ptr> %3023, <8 x i64> %3024
  %3026 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3025, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3027 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3028 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3029 = add <8 x i64> %3028, splat (i64 148)
  %3030 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3027, 0
  %3031 = insertvalue { <8 x ptr>, <8 x i64> } %3030, <8 x i64> %3029, 1
  %3032 = extractvalue { <8 x ptr>, <8 x i64> } %3031, 0
  %3033 = extractvalue { <8 x ptr>, <8 x i64> } %3031, 1
  %3034 = getelementptr i8, <8 x ptr> %3032, <8 x i64> %3033
  %3035 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3034, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3036 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3037 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3038 = add <8 x i64> %3037, splat (i64 152)
  %3039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3036, 0
  %3040 = insertvalue { <8 x ptr>, <8 x i64> } %3039, <8 x i64> %3038, 1
  %3041 = extractvalue { <8 x ptr>, <8 x i64> } %3040, 0
  %3042 = extractvalue { <8 x ptr>, <8 x i64> } %3040, 1
  %3043 = getelementptr i8, <8 x ptr> %3041, <8 x i64> %3042
  %3044 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3043, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3045 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3046 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3047 = add <8 x i64> %3046, splat (i64 156)
  %3048 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3045, 0
  %3049 = insertvalue { <8 x ptr>, <8 x i64> } %3048, <8 x i64> %3047, 1
  %3050 = extractvalue { <8 x ptr>, <8 x i64> } %3049, 0
  %3051 = extractvalue { <8 x ptr>, <8 x i64> } %3049, 1
  %3052 = getelementptr i8, <8 x ptr> %3050, <8 x i64> %3051
  %3053 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3052, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3054 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3055 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3056 = add <8 x i64> %3055, splat (i64 160)
  %3057 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3054, 0
  %3058 = insertvalue { <8 x ptr>, <8 x i64> } %3057, <8 x i64> %3056, 1
  %3059 = extractvalue { <8 x ptr>, <8 x i64> } %3058, 0
  %3060 = extractvalue { <8 x ptr>, <8 x i64> } %3058, 1
  %3061 = getelementptr i8, <8 x ptr> %3059, <8 x i64> %3060
  %3062 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3061, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3063 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3064 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3065 = add <8 x i64> %3064, splat (i64 164)
  %3066 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3063, 0
  %3067 = insertvalue { <8 x ptr>, <8 x i64> } %3066, <8 x i64> %3065, 1
  %3068 = extractvalue { <8 x ptr>, <8 x i64> } %3067, 0
  %3069 = extractvalue { <8 x ptr>, <8 x i64> } %3067, 1
  %3070 = getelementptr i8, <8 x ptr> %3068, <8 x i64> %3069
  %3071 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3070, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3072 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3073 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3074 = add <8 x i64> %3073, splat (i64 168)
  %3075 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3072, 0
  %3076 = insertvalue { <8 x ptr>, <8 x i64> } %3075, <8 x i64> %3074, 1
  %3077 = extractvalue { <8 x ptr>, <8 x i64> } %3076, 0
  %3078 = extractvalue { <8 x ptr>, <8 x i64> } %3076, 1
  %3079 = getelementptr i8, <8 x ptr> %3077, <8 x i64> %3078
  %3080 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3079, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3081 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3082 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3083 = add <8 x i64> %3082, splat (i64 172)
  %3084 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3081, 0
  %3085 = insertvalue { <8 x ptr>, <8 x i64> } %3084, <8 x i64> %3083, 1
  %3086 = extractvalue { <8 x ptr>, <8 x i64> } %3085, 0
  %3087 = extractvalue { <8 x ptr>, <8 x i64> } %3085, 1
  %3088 = getelementptr i8, <8 x ptr> %3086, <8 x i64> %3087
  %3089 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3088, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3090 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3091 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3092 = add <8 x i64> %3091, splat (i64 176)
  %3093 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3090, 0
  %3094 = insertvalue { <8 x ptr>, <8 x i64> } %3093, <8 x i64> %3092, 1
  %3095 = extractvalue { <8 x ptr>, <8 x i64> } %3094, 0
  %3096 = extractvalue { <8 x ptr>, <8 x i64> } %3094, 1
  %3097 = getelementptr i8, <8 x ptr> %3095, <8 x i64> %3096
  %3098 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3097, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3099 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3100 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3101 = add <8 x i64> %3100, splat (i64 180)
  %3102 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3099, 0
  %3103 = insertvalue { <8 x ptr>, <8 x i64> } %3102, <8 x i64> %3101, 1
  %3104 = extractvalue { <8 x ptr>, <8 x i64> } %3103, 0
  %3105 = extractvalue { <8 x ptr>, <8 x i64> } %3103, 1
  %3106 = getelementptr i8, <8 x ptr> %3104, <8 x i64> %3105
  %3107 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3106, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3108 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3109 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3110 = add <8 x i64> %3109, splat (i64 184)
  %3111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3108, 0
  %3112 = insertvalue { <8 x ptr>, <8 x i64> } %3111, <8 x i64> %3110, 1
  %3113 = extractvalue { <8 x ptr>, <8 x i64> } %3112, 0
  %3114 = extractvalue { <8 x ptr>, <8 x i64> } %3112, 1
  %3115 = getelementptr i8, <8 x ptr> %3113, <8 x i64> %3114
  %3116 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3115, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3117 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3118 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3119 = add <8 x i64> %3118, splat (i64 188)
  %3120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3117, 0
  %3121 = insertvalue { <8 x ptr>, <8 x i64> } %3120, <8 x i64> %3119, 1
  %3122 = extractvalue { <8 x ptr>, <8 x i64> } %3121, 0
  %3123 = extractvalue { <8 x ptr>, <8 x i64> } %3121, 1
  %3124 = getelementptr i8, <8 x ptr> %3122, <8 x i64> %3123
  %3125 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3124, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3126 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3127 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3128 = add <8 x i64> %3127, splat (i64 192)
  %3129 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3126, 0
  %3130 = insertvalue { <8 x ptr>, <8 x i64> } %3129, <8 x i64> %3128, 1
  %3131 = extractvalue { <8 x ptr>, <8 x i64> } %3130, 0
  %3132 = extractvalue { <8 x ptr>, <8 x i64> } %3130, 1
  %3133 = getelementptr i8, <8 x ptr> %3131, <8 x i64> %3132
  %3134 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3133, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3135 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3136 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3137 = add <8 x i64> %3136, splat (i64 196)
  %3138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3135, 0
  %3139 = insertvalue { <8 x ptr>, <8 x i64> } %3138, <8 x i64> %3137, 1
  %3140 = extractvalue { <8 x ptr>, <8 x i64> } %3139, 0
  %3141 = extractvalue { <8 x ptr>, <8 x i64> } %3139, 1
  %3142 = getelementptr i8, <8 x ptr> %3140, <8 x i64> %3141
  %3143 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3142, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3144 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3145 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3146 = add <8 x i64> %3145, splat (i64 200)
  %3147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3144, 0
  %3148 = insertvalue { <8 x ptr>, <8 x i64> } %3147, <8 x i64> %3146, 1
  %3149 = extractvalue { <8 x ptr>, <8 x i64> } %3148, 0
  %3150 = extractvalue { <8 x ptr>, <8 x i64> } %3148, 1
  %3151 = getelementptr i8, <8 x ptr> %3149, <8 x i64> %3150
  %3152 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3151, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3153 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3154 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3155 = add <8 x i64> %3154, splat (i64 204)
  %3156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3153, 0
  %3157 = insertvalue { <8 x ptr>, <8 x i64> } %3156, <8 x i64> %3155, 1
  %3158 = extractvalue { <8 x ptr>, <8 x i64> } %3157, 0
  %3159 = extractvalue { <8 x ptr>, <8 x i64> } %3157, 1
  %3160 = getelementptr i8, <8 x ptr> %3158, <8 x i64> %3159
  %3161 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3160, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3162 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3163 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3164 = add <8 x i64> %3163, splat (i64 208)
  %3165 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3162, 0
  %3166 = insertvalue { <8 x ptr>, <8 x i64> } %3165, <8 x i64> %3164, 1
  %3167 = extractvalue { <8 x ptr>, <8 x i64> } %3166, 0
  %3168 = extractvalue { <8 x ptr>, <8 x i64> } %3166, 1
  %3169 = getelementptr i8, <8 x ptr> %3167, <8 x i64> %3168
  %3170 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3169, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3171 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3172 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3173 = add <8 x i64> %3172, splat (i64 212)
  %3174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3171, 0
  %3175 = insertvalue { <8 x ptr>, <8 x i64> } %3174, <8 x i64> %3173, 1
  %3176 = extractvalue { <8 x ptr>, <8 x i64> } %3175, 0
  %3177 = extractvalue { <8 x ptr>, <8 x i64> } %3175, 1
  %3178 = getelementptr i8, <8 x ptr> %3176, <8 x i64> %3177
  %3179 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3178, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3180 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3181 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3182 = add <8 x i64> %3181, splat (i64 216)
  %3183 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3180, 0
  %3184 = insertvalue { <8 x ptr>, <8 x i64> } %3183, <8 x i64> %3182, 1
  %3185 = extractvalue { <8 x ptr>, <8 x i64> } %3184, 0
  %3186 = extractvalue { <8 x ptr>, <8 x i64> } %3184, 1
  %3187 = getelementptr i8, <8 x ptr> %3185, <8 x i64> %3186
  %3188 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3187, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3189 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3190 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3191 = add <8 x i64> %3190, splat (i64 220)
  %3192 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3189, 0
  %3193 = insertvalue { <8 x ptr>, <8 x i64> } %3192, <8 x i64> %3191, 1
  %3194 = extractvalue { <8 x ptr>, <8 x i64> } %3193, 0
  %3195 = extractvalue { <8 x ptr>, <8 x i64> } %3193, 1
  %3196 = getelementptr i8, <8 x ptr> %3194, <8 x i64> %3195
  %3197 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3196, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3198 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3199 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3200 = add <8 x i64> %3199, splat (i64 224)
  %3201 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3198, 0
  %3202 = insertvalue { <8 x ptr>, <8 x i64> } %3201, <8 x i64> %3200, 1
  %3203 = extractvalue { <8 x ptr>, <8 x i64> } %3202, 0
  %3204 = extractvalue { <8 x ptr>, <8 x i64> } %3202, 1
  %3205 = getelementptr i8, <8 x ptr> %3203, <8 x i64> %3204
  %3206 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3205, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3207 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3208 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3209 = add <8 x i64> %3208, splat (i64 228)
  %3210 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3207, 0
  %3211 = insertvalue { <8 x ptr>, <8 x i64> } %3210, <8 x i64> %3209, 1
  %3212 = extractvalue { <8 x ptr>, <8 x i64> } %3211, 0
  %3213 = extractvalue { <8 x ptr>, <8 x i64> } %3211, 1
  %3214 = getelementptr i8, <8 x ptr> %3212, <8 x i64> %3213
  %3215 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3214, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3216 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3217 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3218 = add <8 x i64> %3217, splat (i64 232)
  %3219 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3216, 0
  %3220 = insertvalue { <8 x ptr>, <8 x i64> } %3219, <8 x i64> %3218, 1
  %3221 = extractvalue { <8 x ptr>, <8 x i64> } %3220, 0
  %3222 = extractvalue { <8 x ptr>, <8 x i64> } %3220, 1
  %3223 = getelementptr i8, <8 x ptr> %3221, <8 x i64> %3222
  %3224 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3223, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3225 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3226 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3227 = add <8 x i64> %3226, splat (i64 236)
  %3228 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3225, 0
  %3229 = insertvalue { <8 x ptr>, <8 x i64> } %3228, <8 x i64> %3227, 1
  %3230 = extractvalue { <8 x ptr>, <8 x i64> } %3229, 0
  %3231 = extractvalue { <8 x ptr>, <8 x i64> } %3229, 1
  %3232 = getelementptr i8, <8 x ptr> %3230, <8 x i64> %3231
  %3233 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3232, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3234 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3235 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3236 = add <8 x i64> %3235, splat (i64 240)
  %3237 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3234, 0
  %3238 = insertvalue { <8 x ptr>, <8 x i64> } %3237, <8 x i64> %3236, 1
  %3239 = extractvalue { <8 x ptr>, <8 x i64> } %3238, 0
  %3240 = extractvalue { <8 x ptr>, <8 x i64> } %3238, 1
  %3241 = getelementptr i8, <8 x ptr> %3239, <8 x i64> %3240
  %3242 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3241, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3243 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3244 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3245 = add <8 x i64> %3244, splat (i64 244)
  %3246 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3243, 0
  %3247 = insertvalue { <8 x ptr>, <8 x i64> } %3246, <8 x i64> %3245, 1
  %3248 = extractvalue { <8 x ptr>, <8 x i64> } %3247, 0
  %3249 = extractvalue { <8 x ptr>, <8 x i64> } %3247, 1
  %3250 = getelementptr i8, <8 x ptr> %3248, <8 x i64> %3249
  %3251 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3250, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3252 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3253 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3254 = add <8 x i64> %3253, splat (i64 248)
  %3255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3252, 0
  %3256 = insertvalue { <8 x ptr>, <8 x i64> } %3255, <8 x i64> %3254, 1
  %3257 = extractvalue { <8 x ptr>, <8 x i64> } %3256, 0
  %3258 = extractvalue { <8 x ptr>, <8 x i64> } %3256, 1
  %3259 = getelementptr i8, <8 x ptr> %3257, <8 x i64> %3258
  %3260 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3259, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3261 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %3262 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %3263 = add <8 x i64> %3262, splat (i64 252)
  %3264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3261, 0
  %3265 = insertvalue { <8 x ptr>, <8 x i64> } %3264, <8 x i64> %3263, 1
  %3266 = extractvalue { <8 x ptr>, <8 x i64> } %3265, 0
  %3267 = extractvalue { <8 x ptr>, <8 x i64> } %3265, 1
  %3268 = getelementptr i8, <8 x ptr> %3266, <8 x i64> %3267
  %3269 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3268, <8 x i1> %convergence.cascade.result454, <8 x float> zeroinitializer)
  %3270 = fmul <8 x float> %2702, splat (float 0x3FC43D1360000000)
  %3271 = fmul <8 x float> %2711, splat (float 0x3FC43D1360000000)
  %3272 = fmul <8 x float> %2720, splat (float 0x3FC43D1360000000)
  %3273 = fmul <8 x float> %2729, splat (float 0x3FC43D1360000000)
  %3274 = fmul <8 x float> %2738, splat (float 0x3FC43D1360000000)
  %3275 = fmul <8 x float> %2747, splat (float 0x3FC43D1360000000)
  %3276 = fmul <8 x float> %2756, splat (float 0x3FC43D1360000000)
  %3277 = fmul <8 x float> %2765, splat (float 0x3FC43D1360000000)
  %3278 = fmul <8 x float> %2774, splat (float 0x3FC43D1360000000)
  %3279 = fmul <8 x float> %2783, splat (float 0x3FC43D1360000000)
  %3280 = fmul <8 x float> %2792, splat (float 0x3FC43D1360000000)
  %3281 = fmul <8 x float> %2801, splat (float 0x3FC43D1360000000)
  %3282 = fmul <8 x float> %2810, splat (float 0x3FC43D1360000000)
  %3283 = fmul <8 x float> %2819, splat (float 0x3FC43D1360000000)
  %3284 = fmul <8 x float> %2828, splat (float 0x3FC43D1360000000)
  %3285 = fmul <8 x float> %2837, splat (float 0x3FC43D1360000000)
  %3286 = fmul <8 x float> %2846, splat (float 0x3FC43D1360000000)
  %3287 = fmul <8 x float> %2855, splat (float 0x3FC43D1360000000)
  %3288 = fmul <8 x float> %2864, splat (float 0x3FC43D1360000000)
  %3289 = fmul <8 x float> %2873, splat (float 0x3FC43D1360000000)
  %3290 = fmul <8 x float> %2882, splat (float 0x3FC43D1360000000)
  %3291 = fmul <8 x float> %2891, splat (float 0x3FC43D1360000000)
  %3292 = fmul <8 x float> %2900, splat (float 0x3FC43D1360000000)
  %3293 = fmul <8 x float> %2909, splat (float 0x3FC43D1360000000)
  %3294 = fmul <8 x float> %2918, splat (float 0x3FC43D1360000000)
  %3295 = fmul <8 x float> %2927, splat (float 0x3FC43D1360000000)
  %3296 = fmul <8 x float> %2936, splat (float 0x3FC43D1360000000)
  %3297 = fmul <8 x float> %2945, splat (float 0x3FC43D1360000000)
  %3298 = fmul <8 x float> %2954, splat (float 0x3FC43D1360000000)
  %3299 = fmul <8 x float> %2963, splat (float 0x3FC43D1360000000)
  %3300 = fmul <8 x float> %2972, splat (float 0x3FC43D1360000000)
  %3301 = fmul <8 x float> %2981, splat (float 0x3FC43D1360000000)
  %3302 = fmul <8 x float> %2990, splat (float 0x3FC43D1360000000)
  %3303 = fmul <8 x float> %2999, splat (float 0x3FC43D1360000000)
  %3304 = fmul <8 x float> %3008, splat (float 0x3FC43D1360000000)
  %3305 = fmul <8 x float> %3017, splat (float 0x3FC43D1360000000)
  %3306 = fmul <8 x float> %3026, splat (float 0x3FC43D1360000000)
  %3307 = fmul <8 x float> %3035, splat (float 0x3FC43D1360000000)
  %3308 = fmul <8 x float> %3044, splat (float 0x3FC43D1360000000)
  %3309 = fmul <8 x float> %3053, splat (float 0x3FC43D1360000000)
  %3310 = fmul <8 x float> %3062, splat (float 0x3FC43D1360000000)
  %3311 = fmul <8 x float> %3071, splat (float 0x3FC43D1360000000)
  %3312 = fmul <8 x float> %3080, splat (float 0x3FC43D1360000000)
  %3313 = fmul <8 x float> %3089, splat (float 0x3FC43D1360000000)
  %3314 = fmul <8 x float> %3098, splat (float 0x3FC43D1360000000)
  %3315 = fmul <8 x float> %3107, splat (float 0x3FC43D1360000000)
  %3316 = fmul <8 x float> %3116, splat (float 0x3FC43D1360000000)
  %3317 = fmul <8 x float> %3125, splat (float 0x3FC43D1360000000)
  %3318 = fmul <8 x float> %3134, splat (float 0x3FC43D1360000000)
  %3319 = fmul <8 x float> %3143, splat (float 0x3FC43D1360000000)
  %3320 = fmul <8 x float> %3152, splat (float 0x3FC43D1360000000)
  %3321 = fmul <8 x float> %3161, splat (float 0x3FC43D1360000000)
  %3322 = fmul <8 x float> %3170, splat (float 0x3FC43D1360000000)
  %3323 = fmul <8 x float> %3179, splat (float 0x3FC43D1360000000)
  %3324 = fmul <8 x float> %3188, splat (float 0x3FC43D1360000000)
  %3325 = fmul <8 x float> %3197, splat (float 0x3FC43D1360000000)
  %3326 = fmul <8 x float> %3206, splat (float 0x3FC43D1360000000)
  %3327 = fmul <8 x float> %3215, splat (float 0x3FC43D1360000000)
  %3328 = fmul <8 x float> %3224, splat (float 0x3FC43D1360000000)
  %3329 = fmul <8 x float> %3233, splat (float 0x3FC43D1360000000)
  %3330 = fmul <8 x float> %3242, splat (float 0x3FC43D1360000000)
  %3331 = fmul <8 x float> %3251, splat (float 0x3FC43D1360000000)
  %3332 = fmul <8 x float> %3260, splat (float 0x3FC43D1360000000)
  %3333 = fmul <8 x float> %3269, splat (float 0x3FC43D1360000000)
  %.spill.load471 = load <8 x i64>, ptr %.spill66, align 64
  %3334 = add <8 x i64> zeroinitializer, %.spill.load471
  %.spill.load472 = load <8 x i64>, ptr %.spill66, align 64
  %3335 = add <8 x i64> splat (i64 1), %.spill.load472
  %.spill.load473 = load <8 x i64>, ptr %.spill66, align 64
  %3336 = add <8 x i64> splat (i64 2), %.spill.load473
  %.spill.load474 = load <8 x i64>, ptr %.spill66, align 64
  %3337 = add <8 x i64> splat (i64 3), %.spill.load474
  %.spill.load475 = load <8 x i64>, ptr %.spill66, align 64
  %3338 = add <8 x i64> splat (i64 4), %.spill.load475
  %.spill.load476 = load <8 x i64>, ptr %.spill66, align 64
  %3339 = add <8 x i64> splat (i64 5), %.spill.load476
  %.spill.load477 = load <8 x i64>, ptr %.spill66, align 64
  %3340 = add <8 x i64> splat (i64 6), %.spill.load477
  %.spill.load478 = load <8 x i64>, ptr %.spill66, align 64
  %3341 = add <8 x i64> splat (i64 7), %.spill.load478
  %.spill.load479 = load <8 x i64>, ptr %.spill66, align 64
  %3342 = add <8 x i64> splat (i64 8), %.spill.load479
  %.spill.load480 = load <8 x i64>, ptr %.spill66, align 64
  %3343 = add <8 x i64> splat (i64 9), %.spill.load480
  %.spill.load481 = load <8 x i64>, ptr %.spill66, align 64
  %3344 = add <8 x i64> splat (i64 10), %.spill.load481
  %.spill.load482 = load <8 x i64>, ptr %.spill66, align 64
  %3345 = add <8 x i64> splat (i64 11), %.spill.load482
  %.spill.load483 = load <8 x i64>, ptr %.spill66, align 64
  %3346 = add <8 x i64> splat (i64 12), %.spill.load483
  %.spill.load484 = load <8 x i64>, ptr %.spill66, align 64
  %3347 = add <8 x i64> splat (i64 13), %.spill.load484
  %.spill.load485 = load <8 x i64>, ptr %.spill66, align 64
  %3348 = add <8 x i64> splat (i64 14), %.spill.load485
  %.spill.load486 = load <8 x i64>, ptr %.spill66, align 64
  %3349 = add <8 x i64> splat (i64 15), %.spill.load486
  %3350 = icmp slt <8 x i64> %3334, splat (i64 67)
  %3351 = icmp slt <8 x i64> %3335, splat (i64 67)
  %3352 = icmp slt <8 x i64> %3336, splat (i64 67)
  %3353 = icmp slt <8 x i64> %3337, splat (i64 67)
  %3354 = icmp slt <8 x i64> %3338, splat (i64 67)
  %3355 = icmp slt <8 x i64> %3339, splat (i64 67)
  %3356 = icmp slt <8 x i64> %3340, splat (i64 67)
  %3357 = icmp slt <8 x i64> %3341, splat (i64 67)
  %3358 = icmp slt <8 x i64> %3342, splat (i64 67)
  %3359 = icmp slt <8 x i64> %3343, splat (i64 67)
  %3360 = icmp slt <8 x i64> %3344, splat (i64 67)
  %3361 = icmp slt <8 x i64> %3345, splat (i64 67)
  %3362 = icmp slt <8 x i64> %3346, splat (i64 67)
  %3363 = icmp slt <8 x i64> %3347, splat (i64 67)
  %3364 = icmp slt <8 x i64> %3348, splat (i64 67)
  %3365 = icmp slt <8 x i64> %3349, splat (i64 67)
  %.spill.load487 = load <8 x i64>, ptr %.spill50, align 64
  %3366 = add <8 x i64> zeroinitializer, %.spill.load487
  %.spill.load488 = load <8 x i64>, ptr %.spill50, align 64
  %3367 = add <8 x i64> splat (i64 1), %.spill.load488
  %.spill.load489 = load <8 x i64>, ptr %.spill50, align 64
  %3368 = add <8 x i64> splat (i64 2), %.spill.load489
  %.spill.load490 = load <8 x i64>, ptr %.spill50, align 64
  %3369 = add <8 x i64> splat (i64 3), %.spill.load490
  %3370 = add <8 x i64> %3366, splat (i64 67)
  %3371 = add <8 x i64> %3367, splat (i64 67)
  %3372 = add <8 x i64> %3368, splat (i64 67)
  %3373 = add <8 x i64> %3369, splat (i64 67)
  %3374 = sub <8 x i64> %3370, splat (i64 17)
  %3375 = sub <8 x i64> %3371, splat (i64 17)
  %3376 = sub <8 x i64> %3372, splat (i64 17)
  %3377 = sub <8 x i64> %3373, splat (i64 17)
  %3378 = icmp sle <8 x i64> %3334, %3374
  %3379 = icmp sle <8 x i64> %3334, %3375
  %3380 = icmp sle <8 x i64> %3334, %3376
  %3381 = icmp sle <8 x i64> %3334, %3377
  %3382 = icmp sle <8 x i64> %3335, %3374
  %3383 = icmp sle <8 x i64> %3335, %3375
  %3384 = icmp sle <8 x i64> %3335, %3376
  %3385 = icmp sle <8 x i64> %3335, %3377
  %3386 = icmp sle <8 x i64> %3336, %3374
  %3387 = icmp sle <8 x i64> %3336, %3375
  %3388 = icmp sle <8 x i64> %3336, %3376
  %3389 = icmp sle <8 x i64> %3336, %3377
  %3390 = icmp sle <8 x i64> %3337, %3374
  %3391 = icmp sle <8 x i64> %3337, %3375
  %3392 = icmp sle <8 x i64> %3337, %3376
  %3393 = icmp sle <8 x i64> %3337, %3377
  %3394 = icmp sle <8 x i64> %3338, %3374
  %3395 = icmp sle <8 x i64> %3338, %3375
  %3396 = icmp sle <8 x i64> %3338, %3376
  %3397 = icmp sle <8 x i64> %3338, %3377
  %3398 = icmp sle <8 x i64> %3339, %3374
  %3399 = icmp sle <8 x i64> %3339, %3375
  %3400 = icmp sle <8 x i64> %3339, %3376
  %3401 = icmp sle <8 x i64> %3339, %3377
  %3402 = icmp sle <8 x i64> %3340, %3374
  %3403 = icmp sle <8 x i64> %3340, %3375
  %3404 = icmp sle <8 x i64> %3340, %3376
  %3405 = icmp sle <8 x i64> %3340, %3377
  %3406 = icmp sle <8 x i64> %3341, %3374
  %3407 = icmp sle <8 x i64> %3341, %3375
  %3408 = icmp sle <8 x i64> %3341, %3376
  %3409 = icmp sle <8 x i64> %3341, %3377
  %3410 = icmp sle <8 x i64> %3342, %3374
  %3411 = icmp sle <8 x i64> %3342, %3375
  %3412 = icmp sle <8 x i64> %3342, %3376
  %3413 = icmp sle <8 x i64> %3342, %3377
  %3414 = icmp sle <8 x i64> %3343, %3374
  %3415 = icmp sle <8 x i64> %3343, %3375
  %3416 = icmp sle <8 x i64> %3343, %3376
  %3417 = icmp sle <8 x i64> %3343, %3377
  %3418 = icmp sle <8 x i64> %3344, %3374
  %3419 = icmp sle <8 x i64> %3344, %3375
  %3420 = icmp sle <8 x i64> %3344, %3376
  %3421 = icmp sle <8 x i64> %3344, %3377
  %3422 = icmp sle <8 x i64> %3345, %3374
  %3423 = icmp sle <8 x i64> %3345, %3375
  %3424 = icmp sle <8 x i64> %3345, %3376
  %3425 = icmp sle <8 x i64> %3345, %3377
  %3426 = icmp sle <8 x i64> %3346, %3374
  %3427 = icmp sle <8 x i64> %3346, %3375
  %3428 = icmp sle <8 x i64> %3346, %3376
  %3429 = icmp sle <8 x i64> %3346, %3377
  %3430 = icmp sle <8 x i64> %3347, %3374
  %3431 = icmp sle <8 x i64> %3347, %3375
  %3432 = icmp sle <8 x i64> %3347, %3376
  %3433 = icmp sle <8 x i64> %3347, %3377
  %3434 = icmp sle <8 x i64> %3348, %3374
  %3435 = icmp sle <8 x i64> %3348, %3375
  %3436 = icmp sle <8 x i64> %3348, %3376
  %3437 = icmp sle <8 x i64> %3348, %3377
  %3438 = icmp sle <8 x i64> %3349, %3374
  %3439 = icmp sle <8 x i64> %3349, %3375
  %3440 = icmp sle <8 x i64> %3349, %3376
  %3441 = icmp sle <8 x i64> %3349, %3377
  %3442 = and <8 x i1> %3350, %3378
  %3443 = load volatile <8 x i1>, ptr %.spill75, align 1
  %3444 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3442, <8 x i1> %3443
  store volatile <8 x i1> %3444, ptr %.spill75, align 1
  %3445 = and <8 x i1> %3350, %3379
  %3446 = load volatile <8 x i1>, ptr %.spill76, align 1
  %3447 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3445, <8 x i1> %3446
  store volatile <8 x i1> %3447, ptr %.spill76, align 1
  %3448 = and <8 x i1> %3350, %3380
  %3449 = load volatile <8 x i1>, ptr %.spill77, align 1
  %3450 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3448, <8 x i1> %3449
  store volatile <8 x i1> %3450, ptr %.spill77, align 1
  %3451 = and <8 x i1> %3350, %3381
  %3452 = load volatile <8 x i1>, ptr %.spill78, align 1
  %3453 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3451, <8 x i1> %3452
  store volatile <8 x i1> %3453, ptr %.spill78, align 1
  %3454 = and <8 x i1> %3351, %3382
  %3455 = load volatile <8 x i1>, ptr %.spill79, align 1
  %3456 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3454, <8 x i1> %3455
  store volatile <8 x i1> %3456, ptr %.spill79, align 1
  %3457 = and <8 x i1> %3351, %3383
  %3458 = load volatile <8 x i1>, ptr %.spill80, align 1
  %3459 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3457, <8 x i1> %3458
  store volatile <8 x i1> %3459, ptr %.spill80, align 1
  %3460 = and <8 x i1> %3351, %3384
  %3461 = load volatile <8 x i1>, ptr %.spill81, align 1
  %3462 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3460, <8 x i1> %3461
  store volatile <8 x i1> %3462, ptr %.spill81, align 1
  %3463 = and <8 x i1> %3351, %3385
  %3464 = load volatile <8 x i1>, ptr %.spill82, align 1
  %3465 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3463, <8 x i1> %3464
  store volatile <8 x i1> %3465, ptr %.spill82, align 1
  %3466 = and <8 x i1> %3352, %3386
  %3467 = load volatile <8 x i1>, ptr %.spill83, align 1
  %3468 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3466, <8 x i1> %3467
  store volatile <8 x i1> %3468, ptr %.spill83, align 1
  %3469 = and <8 x i1> %3352, %3387
  %3470 = load volatile <8 x i1>, ptr %.spill84, align 1
  %3471 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3469, <8 x i1> %3470
  store volatile <8 x i1> %3471, ptr %.spill84, align 1
  %3472 = and <8 x i1> %3352, %3388
  %3473 = load volatile <8 x i1>, ptr %.spill85, align 1
  %3474 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3472, <8 x i1> %3473
  store volatile <8 x i1> %3474, ptr %.spill85, align 1
  %3475 = and <8 x i1> %3352, %3389
  %3476 = load volatile <8 x i1>, ptr %.spill86, align 1
  %3477 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3475, <8 x i1> %3476
  store volatile <8 x i1> %3477, ptr %.spill86, align 1
  %3478 = and <8 x i1> %3353, %3390
  %3479 = load volatile <8 x i1>, ptr %.spill87, align 1
  %3480 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3478, <8 x i1> %3479
  store volatile <8 x i1> %3480, ptr %.spill87, align 1
  %3481 = and <8 x i1> %3353, %3391
  %3482 = load volatile <8 x i1>, ptr %.spill88, align 1
  %3483 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3481, <8 x i1> %3482
  store volatile <8 x i1> %3483, ptr %.spill88, align 1
  %3484 = and <8 x i1> %3353, %3392
  %3485 = load volatile <8 x i1>, ptr %.spill89, align 1
  %3486 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3484, <8 x i1> %3485
  store volatile <8 x i1> %3486, ptr %.spill89, align 1
  %3487 = and <8 x i1> %3353, %3393
  %3488 = load volatile <8 x i1>, ptr %.spill90, align 1
  %3489 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3487, <8 x i1> %3488
  store volatile <8 x i1> %3489, ptr %.spill90, align 1
  %3490 = and <8 x i1> %3354, %3394
  %3491 = load volatile <8 x i1>, ptr %.spill91, align 1
  %3492 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3490, <8 x i1> %3491
  store volatile <8 x i1> %3492, ptr %.spill91, align 1
  %3493 = and <8 x i1> %3354, %3395
  %3494 = load volatile <8 x i1>, ptr %.spill92, align 1
  %3495 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3493, <8 x i1> %3494
  store volatile <8 x i1> %3495, ptr %.spill92, align 1
  %3496 = and <8 x i1> %3354, %3396
  %3497 = load volatile <8 x i1>, ptr %.spill93, align 1
  %3498 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3496, <8 x i1> %3497
  store volatile <8 x i1> %3498, ptr %.spill93, align 1
  %3499 = and <8 x i1> %3354, %3397
  %3500 = load volatile <8 x i1>, ptr %.spill94, align 1
  %3501 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3499, <8 x i1> %3500
  store volatile <8 x i1> %3501, ptr %.spill94, align 1
  %3502 = and <8 x i1> %3355, %3398
  %3503 = load volatile <8 x i1>, ptr %.spill95, align 1
  %3504 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3502, <8 x i1> %3503
  store volatile <8 x i1> %3504, ptr %.spill95, align 1
  %3505 = and <8 x i1> %3355, %3399
  %3506 = load volatile <8 x i1>, ptr %.spill96, align 1
  %3507 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3505, <8 x i1> %3506
  store volatile <8 x i1> %3507, ptr %.spill96, align 1
  %3508 = and <8 x i1> %3355, %3400
  %3509 = load volatile <8 x i1>, ptr %.spill97, align 1
  %3510 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3508, <8 x i1> %3509
  store volatile <8 x i1> %3510, ptr %.spill97, align 1
  %3511 = and <8 x i1> %3355, %3401
  %3512 = load volatile <8 x i1>, ptr %.spill98, align 1
  %3513 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3511, <8 x i1> %3512
  store volatile <8 x i1> %3513, ptr %.spill98, align 1
  %3514 = and <8 x i1> %3356, %3402
  %3515 = load volatile <8 x i1>, ptr %.spill99, align 1
  %3516 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3514, <8 x i1> %3515
  store volatile <8 x i1> %3516, ptr %.spill99, align 1
  %3517 = and <8 x i1> %3356, %3403
  %3518 = load volatile <8 x i1>, ptr %.spill100, align 1
  %3519 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3517, <8 x i1> %3518
  store volatile <8 x i1> %3519, ptr %.spill100, align 1
  %3520 = and <8 x i1> %3356, %3404
  %3521 = load volatile <8 x i1>, ptr %.spill101, align 1
  %3522 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3520, <8 x i1> %3521
  store volatile <8 x i1> %3522, ptr %.spill101, align 1
  %3523 = and <8 x i1> %3356, %3405
  %3524 = load volatile <8 x i1>, ptr %.spill102, align 1
  %3525 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3523, <8 x i1> %3524
  store volatile <8 x i1> %3525, ptr %.spill102, align 1
  %3526 = and <8 x i1> %3357, %3406
  %3527 = load volatile <8 x i1>, ptr %.spill103, align 1
  %3528 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3526, <8 x i1> %3527
  store volatile <8 x i1> %3528, ptr %.spill103, align 1
  %3529 = and <8 x i1> %3357, %3407
  %3530 = load volatile <8 x i1>, ptr %.spill104, align 1
  %3531 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3529, <8 x i1> %3530
  store volatile <8 x i1> %3531, ptr %.spill104, align 1
  %3532 = and <8 x i1> %3357, %3408
  %3533 = load volatile <8 x i1>, ptr %.spill105, align 1
  %3534 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3532, <8 x i1> %3533
  store volatile <8 x i1> %3534, ptr %.spill105, align 1
  %3535 = and <8 x i1> %3357, %3409
  %3536 = load volatile <8 x i1>, ptr %.spill106, align 1
  %3537 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3535, <8 x i1> %3536
  store volatile <8 x i1> %3537, ptr %.spill106, align 1
  %3538 = and <8 x i1> %3358, %3410
  %3539 = load volatile <8 x i1>, ptr %.spill107, align 1
  %3540 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3538, <8 x i1> %3539
  store volatile <8 x i1> %3540, ptr %.spill107, align 1
  %3541 = and <8 x i1> %3358, %3411
  %3542 = load volatile <8 x i1>, ptr %.spill108, align 1
  %3543 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3541, <8 x i1> %3542
  store volatile <8 x i1> %3543, ptr %.spill108, align 1
  %3544 = and <8 x i1> %3358, %3412
  %3545 = load volatile <8 x i1>, ptr %.spill109, align 1
  %3546 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3544, <8 x i1> %3545
  store volatile <8 x i1> %3546, ptr %.spill109, align 1
  %3547 = and <8 x i1> %3358, %3413
  %3548 = load volatile <8 x i1>, ptr %.spill110, align 1
  %3549 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3547, <8 x i1> %3548
  store volatile <8 x i1> %3549, ptr %.spill110, align 1
  %3550 = and <8 x i1> %3359, %3414
  %3551 = load volatile <8 x i1>, ptr %.spill111, align 1
  %3552 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3550, <8 x i1> %3551
  store volatile <8 x i1> %3552, ptr %.spill111, align 1
  %3553 = and <8 x i1> %3359, %3415
  %3554 = load volatile <8 x i1>, ptr %.spill112, align 1
  %3555 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3553, <8 x i1> %3554
  store volatile <8 x i1> %3555, ptr %.spill112, align 1
  %3556 = and <8 x i1> %3359, %3416
  %3557 = load volatile <8 x i1>, ptr %.spill113, align 1
  %3558 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3556, <8 x i1> %3557
  store volatile <8 x i1> %3558, ptr %.spill113, align 1
  %3559 = and <8 x i1> %3359, %3417
  %3560 = load volatile <8 x i1>, ptr %.spill114, align 1
  %3561 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3559, <8 x i1> %3560
  store volatile <8 x i1> %3561, ptr %.spill114, align 1
  %3562 = and <8 x i1> %3360, %3418
  %3563 = load volatile <8 x i1>, ptr %.spill115, align 1
  %3564 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3562, <8 x i1> %3563
  store volatile <8 x i1> %3564, ptr %.spill115, align 1
  %3565 = and <8 x i1> %3360, %3419
  %3566 = load volatile <8 x i1>, ptr %.spill116, align 1
  %3567 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3565, <8 x i1> %3566
  store volatile <8 x i1> %3567, ptr %.spill116, align 1
  %3568 = and <8 x i1> %3360, %3420
  %3569 = load volatile <8 x i1>, ptr %.spill117, align 1
  %3570 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3568, <8 x i1> %3569
  store volatile <8 x i1> %3570, ptr %.spill117, align 1
  %3571 = and <8 x i1> %3360, %3421
  %3572 = load volatile <8 x i1>, ptr %.spill118, align 1
  %3573 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3571, <8 x i1> %3572
  store volatile <8 x i1> %3573, ptr %.spill118, align 1
  %3574 = and <8 x i1> %3361, %3422
  %3575 = load volatile <8 x i1>, ptr %.spill119, align 1
  %3576 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3574, <8 x i1> %3575
  store volatile <8 x i1> %3576, ptr %.spill119, align 1
  %3577 = and <8 x i1> %3361, %3423
  %3578 = load volatile <8 x i1>, ptr %.spill120, align 1
  %3579 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3577, <8 x i1> %3578
  store volatile <8 x i1> %3579, ptr %.spill120, align 1
  %3580 = and <8 x i1> %3361, %3424
  %3581 = load volatile <8 x i1>, ptr %.spill121, align 1
  %3582 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3580, <8 x i1> %3581
  store volatile <8 x i1> %3582, ptr %.spill121, align 1
  %3583 = and <8 x i1> %3361, %3425
  %3584 = load volatile <8 x i1>, ptr %.spill122, align 1
  %3585 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3583, <8 x i1> %3584
  store volatile <8 x i1> %3585, ptr %.spill122, align 1
  %3586 = and <8 x i1> %3362, %3426
  %3587 = load volatile <8 x i1>, ptr %.spill123, align 1
  %3588 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3586, <8 x i1> %3587
  store volatile <8 x i1> %3588, ptr %.spill123, align 1
  %3589 = and <8 x i1> %3362, %3427
  %3590 = load volatile <8 x i1>, ptr %.spill124, align 1
  %3591 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3589, <8 x i1> %3590
  store volatile <8 x i1> %3591, ptr %.spill124, align 1
  %3592 = and <8 x i1> %3362, %3428
  %3593 = load volatile <8 x i1>, ptr %.spill125, align 1
  %3594 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3592, <8 x i1> %3593
  store volatile <8 x i1> %3594, ptr %.spill125, align 1
  %3595 = and <8 x i1> %3362, %3429
  %3596 = load volatile <8 x i1>, ptr %.spill126, align 1
  %3597 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3595, <8 x i1> %3596
  store volatile <8 x i1> %3597, ptr %.spill126, align 1
  %3598 = and <8 x i1> %3363, %3430
  %3599 = load volatile <8 x i1>, ptr %.spill127, align 1
  %3600 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3598, <8 x i1> %3599
  store volatile <8 x i1> %3600, ptr %.spill127, align 1
  %3601 = and <8 x i1> %3363, %3431
  %3602 = load volatile <8 x i1>, ptr %.spill128, align 1
  %3603 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3601, <8 x i1> %3602
  store volatile <8 x i1> %3603, ptr %.spill128, align 1
  %3604 = and <8 x i1> %3363, %3432
  %3605 = load volatile <8 x i1>, ptr %.spill129, align 1
  %3606 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3604, <8 x i1> %3605
  store volatile <8 x i1> %3606, ptr %.spill129, align 1
  %3607 = and <8 x i1> %3363, %3433
  %3608 = load volatile <8 x i1>, ptr %.spill130, align 1
  %3609 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3607, <8 x i1> %3608
  store volatile <8 x i1> %3609, ptr %.spill130, align 1
  %3610 = and <8 x i1> %3364, %3434
  %3611 = load volatile <8 x i1>, ptr %.spill131, align 1
  %3612 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3610, <8 x i1> %3611
  store volatile <8 x i1> %3612, ptr %.spill131, align 1
  %3613 = and <8 x i1> %3364, %3435
  %3614 = load volatile <8 x i1>, ptr %.spill132, align 1
  %3615 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3613, <8 x i1> %3614
  store volatile <8 x i1> %3615, ptr %.spill132, align 1
  %3616 = and <8 x i1> %3364, %3436
  %3617 = load volatile <8 x i1>, ptr %.spill133, align 1
  %3618 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3616, <8 x i1> %3617
  store volatile <8 x i1> %3618, ptr %.spill133, align 1
  %3619 = and <8 x i1> %3364, %3437
  %3620 = load volatile <8 x i1>, ptr %.spill134, align 1
  %3621 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3619, <8 x i1> %3620
  store volatile <8 x i1> %3621, ptr %.spill134, align 1
  %3622 = and <8 x i1> %3365, %3438
  %3623 = load volatile <8 x i1>, ptr %.spill135, align 1
  %3624 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3622, <8 x i1> %3623
  store volatile <8 x i1> %3624, ptr %.spill135, align 1
  %3625 = and <8 x i1> %3365, %3439
  %3626 = load volatile <8 x i1>, ptr %.spill136, align 1
  %3627 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3625, <8 x i1> %3626
  store volatile <8 x i1> %3627, ptr %.spill136, align 1
  %3628 = and <8 x i1> %3365, %3440
  %3629 = load volatile <8 x i1>, ptr %.spill137, align 1
  %3630 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3628, <8 x i1> %3629
  store volatile <8 x i1> %3630, ptr %.spill137, align 1
  %3631 = and <8 x i1> %3365, %3441
  %3632 = load volatile <8 x i1>, ptr %.spill138, align 1
  %3633 = select <8 x i1> %convergence.cascade.result454, <8 x i1> %3631, <8 x i1> %3632
  store volatile <8 x i1> %3633, ptr %.spill138, align 1
  %3634 = select <8 x i1> %3442, <8 x float> %3270, <8 x float> splat (float 0xC6293E5940000000)
  %3635 = load volatile <8 x float>, ptr %.spill139, align 32
  %3636 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3634, <8 x float> %3635
  store volatile <8 x float> %3636, ptr %.spill139, align 32
  %3637 = select <8 x i1> %3454, <8 x float> %3271, <8 x float> splat (float 0xC6293E5940000000)
  %3638 = load volatile <8 x float>, ptr %.spill140, align 32
  %3639 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3637, <8 x float> %3638
  store volatile <8 x float> %3639, ptr %.spill140, align 32
  %3640 = select <8 x i1> %3466, <8 x float> %3272, <8 x float> splat (float 0xC6293E5940000000)
  %3641 = load volatile <8 x float>, ptr %.spill141, align 32
  %3642 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3640, <8 x float> %3641
  store volatile <8 x float> %3642, ptr %.spill141, align 32
  %3643 = select <8 x i1> %3478, <8 x float> %3273, <8 x float> splat (float 0xC6293E5940000000)
  %3644 = load volatile <8 x float>, ptr %.spill142, align 32
  %3645 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3643, <8 x float> %3644
  store volatile <8 x float> %3645, ptr %.spill142, align 32
  %3646 = select <8 x i1> %3490, <8 x float> %3274, <8 x float> splat (float 0xC6293E5940000000)
  %3647 = load volatile <8 x float>, ptr %.spill143, align 32
  %3648 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3646, <8 x float> %3647
  store volatile <8 x float> %3648, ptr %.spill143, align 32
  %3649 = select <8 x i1> %3502, <8 x float> %3275, <8 x float> splat (float 0xC6293E5940000000)
  %3650 = load volatile <8 x float>, ptr %.spill144, align 32
  %3651 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3649, <8 x float> %3650
  store volatile <8 x float> %3651, ptr %.spill144, align 32
  %3652 = select <8 x i1> %3514, <8 x float> %3276, <8 x float> splat (float 0xC6293E5940000000)
  %3653 = load volatile <8 x float>, ptr %.spill145, align 32
  %3654 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3652, <8 x float> %3653
  store volatile <8 x float> %3654, ptr %.spill145, align 32
  %3655 = select <8 x i1> %3526, <8 x float> %3277, <8 x float> splat (float 0xC6293E5940000000)
  %3656 = load volatile <8 x float>, ptr %.spill146, align 32
  %3657 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3655, <8 x float> %3656
  store volatile <8 x float> %3657, ptr %.spill146, align 32
  %3658 = select <8 x i1> %3538, <8 x float> %3278, <8 x float> splat (float 0xC6293E5940000000)
  %3659 = load volatile <8 x float>, ptr %.spill147, align 32
  %3660 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3658, <8 x float> %3659
  store volatile <8 x float> %3660, ptr %.spill147, align 32
  %3661 = select <8 x i1> %3550, <8 x float> %3279, <8 x float> splat (float 0xC6293E5940000000)
  %3662 = load volatile <8 x float>, ptr %.spill148, align 32
  %3663 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3661, <8 x float> %3662
  store volatile <8 x float> %3663, ptr %.spill148, align 32
  %3664 = select <8 x i1> %3562, <8 x float> %3280, <8 x float> splat (float 0xC6293E5940000000)
  %3665 = load volatile <8 x float>, ptr %.spill149, align 32
  %3666 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3664, <8 x float> %3665
  store volatile <8 x float> %3666, ptr %.spill149, align 32
  %3667 = select <8 x i1> %3574, <8 x float> %3281, <8 x float> splat (float 0xC6293E5940000000)
  %3668 = load volatile <8 x float>, ptr %.spill150, align 32
  %3669 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3667, <8 x float> %3668
  store volatile <8 x float> %3669, ptr %.spill150, align 32
  %3670 = select <8 x i1> %3586, <8 x float> %3282, <8 x float> splat (float 0xC6293E5940000000)
  %3671 = load volatile <8 x float>, ptr %.spill151, align 32
  %3672 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3670, <8 x float> %3671
  store volatile <8 x float> %3672, ptr %.spill151, align 32
  %3673 = select <8 x i1> %3598, <8 x float> %3283, <8 x float> splat (float 0xC6293E5940000000)
  %3674 = load volatile <8 x float>, ptr %.spill152, align 32
  %3675 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3673, <8 x float> %3674
  store volatile <8 x float> %3675, ptr %.spill152, align 32
  %3676 = select <8 x i1> %3610, <8 x float> %3284, <8 x float> splat (float 0xC6293E5940000000)
  %3677 = load volatile <8 x float>, ptr %.spill153, align 32
  %3678 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3676, <8 x float> %3677
  store volatile <8 x float> %3678, ptr %.spill153, align 32
  %3679 = select <8 x i1> %3622, <8 x float> %3285, <8 x float> splat (float 0xC6293E5940000000)
  %3680 = load volatile <8 x float>, ptr %.spill154, align 32
  %3681 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3679, <8 x float> %3680
  store volatile <8 x float> %3681, ptr %.spill154, align 32
  %3682 = select <8 x i1> %3445, <8 x float> %3286, <8 x float> splat (float 0xC6293E5940000000)
  %3683 = load volatile <8 x float>, ptr %.spill155, align 32
  %3684 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3682, <8 x float> %3683
  store volatile <8 x float> %3684, ptr %.spill155, align 32
  %3685 = select <8 x i1> %3457, <8 x float> %3287, <8 x float> splat (float 0xC6293E5940000000)
  %3686 = load volatile <8 x float>, ptr %.spill156, align 32
  %3687 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3685, <8 x float> %3686
  store volatile <8 x float> %3687, ptr %.spill156, align 32
  %3688 = select <8 x i1> %3469, <8 x float> %3288, <8 x float> splat (float 0xC6293E5940000000)
  %3689 = load volatile <8 x float>, ptr %.spill157, align 32
  %3690 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3688, <8 x float> %3689
  store volatile <8 x float> %3690, ptr %.spill157, align 32
  %3691 = select <8 x i1> %3481, <8 x float> %3289, <8 x float> splat (float 0xC6293E5940000000)
  %3692 = load volatile <8 x float>, ptr %.spill158, align 32
  %3693 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3691, <8 x float> %3692
  store volatile <8 x float> %3693, ptr %.spill158, align 32
  %3694 = select <8 x i1> %3493, <8 x float> %3290, <8 x float> splat (float 0xC6293E5940000000)
  %3695 = load volatile <8 x float>, ptr %.spill159, align 32
  %3696 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3694, <8 x float> %3695
  store volatile <8 x float> %3696, ptr %.spill159, align 32
  %3697 = select <8 x i1> %3505, <8 x float> %3291, <8 x float> splat (float 0xC6293E5940000000)
  %3698 = load volatile <8 x float>, ptr %.spill160, align 32
  %3699 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3697, <8 x float> %3698
  store volatile <8 x float> %3699, ptr %.spill160, align 32
  %3700 = select <8 x i1> %3517, <8 x float> %3292, <8 x float> splat (float 0xC6293E5940000000)
  %3701 = load volatile <8 x float>, ptr %.spill161, align 32
  %3702 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3700, <8 x float> %3701
  store volatile <8 x float> %3702, ptr %.spill161, align 32
  %3703 = select <8 x i1> %3529, <8 x float> %3293, <8 x float> splat (float 0xC6293E5940000000)
  %3704 = load volatile <8 x float>, ptr %.spill162, align 32
  %3705 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3703, <8 x float> %3704
  store volatile <8 x float> %3705, ptr %.spill162, align 32
  %3706 = select <8 x i1> %3541, <8 x float> %3294, <8 x float> splat (float 0xC6293E5940000000)
  %3707 = load volatile <8 x float>, ptr %.spill163, align 32
  %3708 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3706, <8 x float> %3707
  store volatile <8 x float> %3708, ptr %.spill163, align 32
  %3709 = select <8 x i1> %3553, <8 x float> %3295, <8 x float> splat (float 0xC6293E5940000000)
  %3710 = load volatile <8 x float>, ptr %.spill164, align 32
  %3711 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3709, <8 x float> %3710
  store volatile <8 x float> %3711, ptr %.spill164, align 32
  %3712 = select <8 x i1> %3565, <8 x float> %3296, <8 x float> splat (float 0xC6293E5940000000)
  %3713 = load volatile <8 x float>, ptr %.spill165, align 32
  %3714 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3712, <8 x float> %3713
  store volatile <8 x float> %3714, ptr %.spill165, align 32
  %3715 = select <8 x i1> %3577, <8 x float> %3297, <8 x float> splat (float 0xC6293E5940000000)
  %3716 = load volatile <8 x float>, ptr %.spill166, align 32
  %3717 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3715, <8 x float> %3716
  store volatile <8 x float> %3717, ptr %.spill166, align 32
  %3718 = select <8 x i1> %3589, <8 x float> %3298, <8 x float> splat (float 0xC6293E5940000000)
  %3719 = load volatile <8 x float>, ptr %.spill167, align 32
  %3720 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3718, <8 x float> %3719
  store volatile <8 x float> %3720, ptr %.spill167, align 32
  %3721 = select <8 x i1> %3601, <8 x float> %3299, <8 x float> splat (float 0xC6293E5940000000)
  %3722 = load volatile <8 x float>, ptr %.spill168, align 32
  %3723 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3721, <8 x float> %3722
  store volatile <8 x float> %3723, ptr %.spill168, align 32
  %3724 = select <8 x i1> %3613, <8 x float> %3300, <8 x float> splat (float 0xC6293E5940000000)
  %3725 = load volatile <8 x float>, ptr %.spill169, align 32
  %3726 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3724, <8 x float> %3725
  store volatile <8 x float> %3726, ptr %.spill169, align 32
  %3727 = select <8 x i1> %3625, <8 x float> %3301, <8 x float> splat (float 0xC6293E5940000000)
  %3728 = load volatile <8 x float>, ptr %.spill170, align 32
  %3729 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3727, <8 x float> %3728
  store volatile <8 x float> %3729, ptr %.spill170, align 32
  %3730 = select <8 x i1> %3448, <8 x float> %3302, <8 x float> splat (float 0xC6293E5940000000)
  %3731 = load volatile <8 x float>, ptr %.spill171, align 32
  %3732 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3730, <8 x float> %3731
  store volatile <8 x float> %3732, ptr %.spill171, align 32
  %3733 = select <8 x i1> %3460, <8 x float> %3303, <8 x float> splat (float 0xC6293E5940000000)
  %3734 = load volatile <8 x float>, ptr %.spill172, align 32
  %3735 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3733, <8 x float> %3734
  store volatile <8 x float> %3735, ptr %.spill172, align 32
  %3736 = select <8 x i1> %3472, <8 x float> %3304, <8 x float> splat (float 0xC6293E5940000000)
  %3737 = load volatile <8 x float>, ptr %.spill173, align 32
  %3738 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3736, <8 x float> %3737
  store volatile <8 x float> %3738, ptr %.spill173, align 32
  %3739 = select <8 x i1> %3484, <8 x float> %3305, <8 x float> splat (float 0xC6293E5940000000)
  %3740 = load volatile <8 x float>, ptr %.spill174, align 32
  %3741 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3739, <8 x float> %3740
  store volatile <8 x float> %3741, ptr %.spill174, align 32
  %3742 = select <8 x i1> %3496, <8 x float> %3306, <8 x float> splat (float 0xC6293E5940000000)
  %3743 = load volatile <8 x float>, ptr %.spill175, align 32
  %3744 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3742, <8 x float> %3743
  store volatile <8 x float> %3744, ptr %.spill175, align 32
  %3745 = select <8 x i1> %3508, <8 x float> %3307, <8 x float> splat (float 0xC6293E5940000000)
  %3746 = load volatile <8 x float>, ptr %.spill176, align 32
  %3747 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3745, <8 x float> %3746
  store volatile <8 x float> %3747, ptr %.spill176, align 32
  %3748 = select <8 x i1> %3520, <8 x float> %3308, <8 x float> splat (float 0xC6293E5940000000)
  %3749 = load volatile <8 x float>, ptr %.spill177, align 32
  %3750 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3748, <8 x float> %3749
  store volatile <8 x float> %3750, ptr %.spill177, align 32
  %3751 = select <8 x i1> %3532, <8 x float> %3309, <8 x float> splat (float 0xC6293E5940000000)
  %3752 = load volatile <8 x float>, ptr %.spill178, align 32
  %3753 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3751, <8 x float> %3752
  store volatile <8 x float> %3753, ptr %.spill178, align 32
  %3754 = select <8 x i1> %3544, <8 x float> %3310, <8 x float> splat (float 0xC6293E5940000000)
  %3755 = load volatile <8 x float>, ptr %.spill179, align 32
  %3756 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3754, <8 x float> %3755
  store volatile <8 x float> %3756, ptr %.spill179, align 32
  %3757 = select <8 x i1> %3556, <8 x float> %3311, <8 x float> splat (float 0xC6293E5940000000)
  %3758 = load volatile <8 x float>, ptr %.spill180, align 32
  %3759 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3757, <8 x float> %3758
  store volatile <8 x float> %3759, ptr %.spill180, align 32
  %3760 = select <8 x i1> %3568, <8 x float> %3312, <8 x float> splat (float 0xC6293E5940000000)
  %3761 = load volatile <8 x float>, ptr %.spill181, align 32
  %3762 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3760, <8 x float> %3761
  store volatile <8 x float> %3762, ptr %.spill181, align 32
  %3763 = select <8 x i1> %3580, <8 x float> %3313, <8 x float> splat (float 0xC6293E5940000000)
  %3764 = load volatile <8 x float>, ptr %.spill182, align 32
  %3765 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3763, <8 x float> %3764
  store volatile <8 x float> %3765, ptr %.spill182, align 32
  %3766 = select <8 x i1> %3592, <8 x float> %3314, <8 x float> splat (float 0xC6293E5940000000)
  %3767 = load volatile <8 x float>, ptr %.spill183, align 32
  %3768 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3766, <8 x float> %3767
  store volatile <8 x float> %3768, ptr %.spill183, align 32
  %3769 = select <8 x i1> %3604, <8 x float> %3315, <8 x float> splat (float 0xC6293E5940000000)
  %3770 = load volatile <8 x float>, ptr %.spill184, align 32
  %3771 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3769, <8 x float> %3770
  store volatile <8 x float> %3771, ptr %.spill184, align 32
  %3772 = select <8 x i1> %3616, <8 x float> %3316, <8 x float> splat (float 0xC6293E5940000000)
  %3773 = load volatile <8 x float>, ptr %.spill185, align 32
  %3774 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3772, <8 x float> %3773
  store volatile <8 x float> %3774, ptr %.spill185, align 32
  %3775 = select <8 x i1> %3628, <8 x float> %3317, <8 x float> splat (float 0xC6293E5940000000)
  %3776 = load volatile <8 x float>, ptr %.spill186, align 32
  %3777 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3775, <8 x float> %3776
  store volatile <8 x float> %3777, ptr %.spill186, align 32
  %3778 = select <8 x i1> %3451, <8 x float> %3318, <8 x float> splat (float 0xC6293E5940000000)
  %3779 = load volatile <8 x float>, ptr %.spill187, align 32
  %3780 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3778, <8 x float> %3779
  store volatile <8 x float> %3780, ptr %.spill187, align 32
  %3781 = select <8 x i1> %3463, <8 x float> %3319, <8 x float> splat (float 0xC6293E5940000000)
  %3782 = load volatile <8 x float>, ptr %.spill188, align 32
  %3783 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3781, <8 x float> %3782
  store volatile <8 x float> %3783, ptr %.spill188, align 32
  %3784 = select <8 x i1> %3475, <8 x float> %3320, <8 x float> splat (float 0xC6293E5940000000)
  %3785 = load volatile <8 x float>, ptr %.spill189, align 32
  %3786 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3784, <8 x float> %3785
  store volatile <8 x float> %3786, ptr %.spill189, align 32
  %3787 = select <8 x i1> %3487, <8 x float> %3321, <8 x float> splat (float 0xC6293E5940000000)
  %3788 = load volatile <8 x float>, ptr %.spill190, align 32
  %3789 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3787, <8 x float> %3788
  store volatile <8 x float> %3789, ptr %.spill190, align 32
  %3790 = select <8 x i1> %3499, <8 x float> %3322, <8 x float> splat (float 0xC6293E5940000000)
  %3791 = load volatile <8 x float>, ptr %.spill191, align 32
  %3792 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3790, <8 x float> %3791
  store volatile <8 x float> %3792, ptr %.spill191, align 32
  %3793 = select <8 x i1> %3511, <8 x float> %3323, <8 x float> splat (float 0xC6293E5940000000)
  %3794 = load volatile <8 x float>, ptr %.spill192, align 32
  %3795 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3793, <8 x float> %3794
  store volatile <8 x float> %3795, ptr %.spill192, align 32
  %3796 = select <8 x i1> %3523, <8 x float> %3324, <8 x float> splat (float 0xC6293E5940000000)
  %3797 = load volatile <8 x float>, ptr %.spill193, align 32
  %3798 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3796, <8 x float> %3797
  store volatile <8 x float> %3798, ptr %.spill193, align 32
  %3799 = select <8 x i1> %3535, <8 x float> %3325, <8 x float> splat (float 0xC6293E5940000000)
  %3800 = load volatile <8 x float>, ptr %.spill194, align 32
  %3801 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3799, <8 x float> %3800
  store volatile <8 x float> %3801, ptr %.spill194, align 32
  %3802 = select <8 x i1> %3547, <8 x float> %3326, <8 x float> splat (float 0xC6293E5940000000)
  %3803 = load volatile <8 x float>, ptr %.spill195, align 32
  %3804 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3802, <8 x float> %3803
  store volatile <8 x float> %3804, ptr %.spill195, align 32
  %3805 = select <8 x i1> %3559, <8 x float> %3327, <8 x float> splat (float 0xC6293E5940000000)
  %3806 = load volatile <8 x float>, ptr %.spill196, align 32
  %3807 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3805, <8 x float> %3806
  store volatile <8 x float> %3807, ptr %.spill196, align 32
  %3808 = select <8 x i1> %3571, <8 x float> %3328, <8 x float> splat (float 0xC6293E5940000000)
  %3809 = load volatile <8 x float>, ptr %.spill197, align 32
  %3810 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3808, <8 x float> %3809
  store volatile <8 x float> %3810, ptr %.spill197, align 32
  %3811 = select <8 x i1> %3583, <8 x float> %3329, <8 x float> splat (float 0xC6293E5940000000)
  %3812 = load volatile <8 x float>, ptr %.spill198, align 32
  %3813 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3811, <8 x float> %3812
  store volatile <8 x float> %3813, ptr %.spill198, align 32
  %3814 = select <8 x i1> %3595, <8 x float> %3330, <8 x float> splat (float 0xC6293E5940000000)
  %3815 = load volatile <8 x float>, ptr %.spill199, align 32
  %3816 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3814, <8 x float> %3815
  store volatile <8 x float> %3816, ptr %.spill199, align 32
  %3817 = select <8 x i1> %3607, <8 x float> %3331, <8 x float> splat (float 0xC6293E5940000000)
  %3818 = load volatile <8 x float>, ptr %.spill200, align 32
  %3819 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3817, <8 x float> %3818
  store volatile <8 x float> %3819, ptr %.spill200, align 32
  %3820 = select <8 x i1> %3619, <8 x float> %3332, <8 x float> splat (float 0xC6293E5940000000)
  %3821 = load volatile <8 x float>, ptr %.spill201, align 32
  %3822 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3820, <8 x float> %3821
  store volatile <8 x float> %3822, ptr %.spill201, align 32
  %3823 = select <8 x i1> %3631, <8 x float> %3333, <8 x float> splat (float 0xC6293E5940000000)
  %3824 = load volatile <8 x float>, ptr %.spill202, align 32
  %3825 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3823, <8 x float> %3824
  store volatile <8 x float> %3825, ptr %.spill202, align 32
  %3826 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill203, align 64
  %3827 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3828 = extractvalue { <8 x ptr>, <8 x i64> } %3826, 0
  %3829 = select <8 x i1> %convergence.cascade.result454, <8 x ptr> %3827, <8 x ptr> %3828
  %3830 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3831 = extractvalue { <8 x ptr>, <8 x i64> } %3826, 1
  %3832 = select <8 x i1> %convergence.cascade.result454, <8 x i64> %3830, <8 x i64> %3831
  %3833 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3829, 0
  %3834 = insertvalue { <8 x ptr>, <8 x i64> } %3833, <8 x i64> %3832, 1
  store { <8 x ptr>, <8 x i64> } %3834, ptr %tile_snapshot.spill203, align 64
  %3835 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3836 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3837 = add <8 x i64> %3836, zeroinitializer
  %3838 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3835, 0
  %3839 = insertvalue { <8 x ptr>, <8 x i64> } %3838, <8 x i64> %3837, 1
  %3840 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3841 = extractvalue { <8 x ptr>, <8 x i64> } %3839, 1
  %3842 = extractelement <8 x ptr> %3840, i32 0
  %3843 = extractelement <8 x i64> %3841, i32 %2013
  %3844 = zext i32 %2013 to i64
  %3845 = mul i64 %3844, 4
  %3846 = sub i64 %3843, %3845
  %3847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3848 = select i1 %3847, i64 %3846, i64 0
  %private.contiguous.address = getelementptr i8, ptr %3842, i64 %3848
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %3849 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3634, <8 x float> %private.contiguous.preserve
  store <8 x float> %3849, ptr %private.contiguous.address, align 4
  %3850 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3851 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3852 = add <8 x i64> %3851, splat (i64 32)
  %3853 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3850, 0
  %3854 = insertvalue { <8 x ptr>, <8 x i64> } %3853, <8 x i64> %3852, 1
  %3855 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3856 = extractvalue { <8 x ptr>, <8 x i64> } %3854, 1
  %3857 = extractelement <8 x ptr> %3855, i32 0
  %3858 = extractelement <8 x i64> %3856, i32 %2013
  %3859 = zext i32 %2013 to i64
  %3860 = mul i64 %3859, 4
  %3861 = sub i64 %3858, %3860
  %3862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3863 = select i1 %3862, i64 %3861, i64 0
  %private.contiguous.address491 = getelementptr i8, ptr %3857, i64 %3863
  %private.contiguous.preserve492 = load <8 x float>, ptr %private.contiguous.address491, align 4
  %3864 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3637, <8 x float> %private.contiguous.preserve492
  store <8 x float> %3864, ptr %private.contiguous.address491, align 4
  %3865 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3866 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3867 = add <8 x i64> %3866, splat (i64 64)
  %3868 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3865, 0
  %3869 = insertvalue { <8 x ptr>, <8 x i64> } %3868, <8 x i64> %3867, 1
  %3870 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3871 = extractvalue { <8 x ptr>, <8 x i64> } %3869, 1
  %3872 = extractelement <8 x ptr> %3870, i32 0
  %3873 = extractelement <8 x i64> %3871, i32 %2013
  %3874 = zext i32 %2013 to i64
  %3875 = mul i64 %3874, 4
  %3876 = sub i64 %3873, %3875
  %3877 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3878 = select i1 %3877, i64 %3876, i64 0
  %private.contiguous.address493 = getelementptr i8, ptr %3872, i64 %3878
  %private.contiguous.preserve494 = load <8 x float>, ptr %private.contiguous.address493, align 4
  %3879 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3640, <8 x float> %private.contiguous.preserve494
  store <8 x float> %3879, ptr %private.contiguous.address493, align 4
  %3880 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3881 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3882 = add <8 x i64> %3881, splat (i64 96)
  %3883 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3880, 0
  %3884 = insertvalue { <8 x ptr>, <8 x i64> } %3883, <8 x i64> %3882, 1
  %3885 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3886 = extractvalue { <8 x ptr>, <8 x i64> } %3884, 1
  %3887 = extractelement <8 x ptr> %3885, i32 0
  %3888 = extractelement <8 x i64> %3886, i32 %2013
  %3889 = zext i32 %2013 to i64
  %3890 = mul i64 %3889, 4
  %3891 = sub i64 %3888, %3890
  %3892 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3893 = select i1 %3892, i64 %3891, i64 0
  %private.contiguous.address495 = getelementptr i8, ptr %3887, i64 %3893
  %private.contiguous.preserve496 = load <8 x float>, ptr %private.contiguous.address495, align 4
  %3894 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3643, <8 x float> %private.contiguous.preserve496
  store <8 x float> %3894, ptr %private.contiguous.address495, align 4
  %3895 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3896 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3897 = add <8 x i64> %3896, splat (i64 128)
  %3898 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3895, 0
  %3899 = insertvalue { <8 x ptr>, <8 x i64> } %3898, <8 x i64> %3897, 1
  %3900 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3901 = extractvalue { <8 x ptr>, <8 x i64> } %3899, 1
  %3902 = extractelement <8 x ptr> %3900, i32 0
  %3903 = extractelement <8 x i64> %3901, i32 %2013
  %3904 = zext i32 %2013 to i64
  %3905 = mul i64 %3904, 4
  %3906 = sub i64 %3903, %3905
  %3907 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3908 = select i1 %3907, i64 %3906, i64 0
  %private.contiguous.address497 = getelementptr i8, ptr %3902, i64 %3908
  %private.contiguous.preserve498 = load <8 x float>, ptr %private.contiguous.address497, align 4
  %3909 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3646, <8 x float> %private.contiguous.preserve498
  store <8 x float> %3909, ptr %private.contiguous.address497, align 4
  %3910 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3911 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3912 = add <8 x i64> %3911, splat (i64 160)
  %3913 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3910, 0
  %3914 = insertvalue { <8 x ptr>, <8 x i64> } %3913, <8 x i64> %3912, 1
  %3915 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3916 = extractvalue { <8 x ptr>, <8 x i64> } %3914, 1
  %3917 = extractelement <8 x ptr> %3915, i32 0
  %3918 = extractelement <8 x i64> %3916, i32 %2013
  %3919 = zext i32 %2013 to i64
  %3920 = mul i64 %3919, 4
  %3921 = sub i64 %3918, %3920
  %3922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3923 = select i1 %3922, i64 %3921, i64 0
  %private.contiguous.address499 = getelementptr i8, ptr %3917, i64 %3923
  %private.contiguous.preserve500 = load <8 x float>, ptr %private.contiguous.address499, align 4
  %3924 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3649, <8 x float> %private.contiguous.preserve500
  store <8 x float> %3924, ptr %private.contiguous.address499, align 4
  %3925 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3926 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3927 = add <8 x i64> %3926, splat (i64 192)
  %3928 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3925, 0
  %3929 = insertvalue { <8 x ptr>, <8 x i64> } %3928, <8 x i64> %3927, 1
  %3930 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3931 = extractvalue { <8 x ptr>, <8 x i64> } %3929, 1
  %3932 = extractelement <8 x ptr> %3930, i32 0
  %3933 = extractelement <8 x i64> %3931, i32 %2013
  %3934 = zext i32 %2013 to i64
  %3935 = mul i64 %3934, 4
  %3936 = sub i64 %3933, %3935
  %3937 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3938 = select i1 %3937, i64 %3936, i64 0
  %private.contiguous.address501 = getelementptr i8, ptr %3932, i64 %3938
  %private.contiguous.preserve502 = load <8 x float>, ptr %private.contiguous.address501, align 4
  %3939 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3652, <8 x float> %private.contiguous.preserve502
  store <8 x float> %3939, ptr %private.contiguous.address501, align 4
  %3940 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3941 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3942 = add <8 x i64> %3941, splat (i64 224)
  %3943 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3940, 0
  %3944 = insertvalue { <8 x ptr>, <8 x i64> } %3943, <8 x i64> %3942, 1
  %3945 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3946 = extractvalue { <8 x ptr>, <8 x i64> } %3944, 1
  %3947 = extractelement <8 x ptr> %3945, i32 0
  %3948 = extractelement <8 x i64> %3946, i32 %2013
  %3949 = zext i32 %2013 to i64
  %3950 = mul i64 %3949, 4
  %3951 = sub i64 %3948, %3950
  %3952 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3953 = select i1 %3952, i64 %3951, i64 0
  %private.contiguous.address503 = getelementptr i8, ptr %3947, i64 %3953
  %private.contiguous.preserve504 = load <8 x float>, ptr %private.contiguous.address503, align 4
  %3954 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3655, <8 x float> %private.contiguous.preserve504
  store <8 x float> %3954, ptr %private.contiguous.address503, align 4
  %3955 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3956 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3957 = add <8 x i64> %3956, splat (i64 256)
  %3958 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3955, 0
  %3959 = insertvalue { <8 x ptr>, <8 x i64> } %3958, <8 x i64> %3957, 1
  %3960 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3961 = extractvalue { <8 x ptr>, <8 x i64> } %3959, 1
  %3962 = extractelement <8 x ptr> %3960, i32 0
  %3963 = extractelement <8 x i64> %3961, i32 %2013
  %3964 = zext i32 %2013 to i64
  %3965 = mul i64 %3964, 4
  %3966 = sub i64 %3963, %3965
  %3967 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3968 = select i1 %3967, i64 %3966, i64 0
  %private.contiguous.address505 = getelementptr i8, ptr %3962, i64 %3968
  %private.contiguous.preserve506 = load <8 x float>, ptr %private.contiguous.address505, align 4
  %3969 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3658, <8 x float> %private.contiguous.preserve506
  store <8 x float> %3969, ptr %private.contiguous.address505, align 4
  %3970 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3971 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3972 = add <8 x i64> %3971, splat (i64 288)
  %3973 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3970, 0
  %3974 = insertvalue { <8 x ptr>, <8 x i64> } %3973, <8 x i64> %3972, 1
  %3975 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3976 = extractvalue { <8 x ptr>, <8 x i64> } %3974, 1
  %3977 = extractelement <8 x ptr> %3975, i32 0
  %3978 = extractelement <8 x i64> %3976, i32 %2013
  %3979 = zext i32 %2013 to i64
  %3980 = mul i64 %3979, 4
  %3981 = sub i64 %3978, %3980
  %3982 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3983 = select i1 %3982, i64 %3981, i64 0
  %private.contiguous.address507 = getelementptr i8, ptr %3977, i64 %3983
  %private.contiguous.preserve508 = load <8 x float>, ptr %private.contiguous.address507, align 4
  %3984 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3661, <8 x float> %private.contiguous.preserve508
  store <8 x float> %3984, ptr %private.contiguous.address507, align 4
  %3985 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3986 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %3987 = add <8 x i64> %3986, splat (i64 320)
  %3988 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3985, 0
  %3989 = insertvalue { <8 x ptr>, <8 x i64> } %3988, <8 x i64> %3987, 1
  %3990 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %3991 = extractvalue { <8 x ptr>, <8 x i64> } %3989, 1
  %3992 = extractelement <8 x ptr> %3990, i32 0
  %3993 = extractelement <8 x i64> %3991, i32 %2013
  %3994 = zext i32 %2013 to i64
  %3995 = mul i64 %3994, 4
  %3996 = sub i64 %3993, %3995
  %3997 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %3998 = select i1 %3997, i64 %3996, i64 0
  %private.contiguous.address509 = getelementptr i8, ptr %3992, i64 %3998
  %private.contiguous.preserve510 = load <8 x float>, ptr %private.contiguous.address509, align 4
  %3999 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3664, <8 x float> %private.contiguous.preserve510
  store <8 x float> %3999, ptr %private.contiguous.address509, align 4
  %4000 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4001 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4002 = add <8 x i64> %4001, splat (i64 352)
  %4003 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4000, 0
  %4004 = insertvalue { <8 x ptr>, <8 x i64> } %4003, <8 x i64> %4002, 1
  %4005 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4006 = extractvalue { <8 x ptr>, <8 x i64> } %4004, 1
  %4007 = extractelement <8 x ptr> %4005, i32 0
  %4008 = extractelement <8 x i64> %4006, i32 %2013
  %4009 = zext i32 %2013 to i64
  %4010 = mul i64 %4009, 4
  %4011 = sub i64 %4008, %4010
  %4012 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4013 = select i1 %4012, i64 %4011, i64 0
  %private.contiguous.address511 = getelementptr i8, ptr %4007, i64 %4013
  %private.contiguous.preserve512 = load <8 x float>, ptr %private.contiguous.address511, align 4
  %4014 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3667, <8 x float> %private.contiguous.preserve512
  store <8 x float> %4014, ptr %private.contiguous.address511, align 4
  %4015 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4016 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4017 = add <8 x i64> %4016, splat (i64 384)
  %4018 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4015, 0
  %4019 = insertvalue { <8 x ptr>, <8 x i64> } %4018, <8 x i64> %4017, 1
  %4020 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4021 = extractvalue { <8 x ptr>, <8 x i64> } %4019, 1
  %4022 = extractelement <8 x ptr> %4020, i32 0
  %4023 = extractelement <8 x i64> %4021, i32 %2013
  %4024 = zext i32 %2013 to i64
  %4025 = mul i64 %4024, 4
  %4026 = sub i64 %4023, %4025
  %4027 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4028 = select i1 %4027, i64 %4026, i64 0
  %private.contiguous.address513 = getelementptr i8, ptr %4022, i64 %4028
  %private.contiguous.preserve514 = load <8 x float>, ptr %private.contiguous.address513, align 4
  %4029 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3670, <8 x float> %private.contiguous.preserve514
  store <8 x float> %4029, ptr %private.contiguous.address513, align 4
  %4030 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4031 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4032 = add <8 x i64> %4031, splat (i64 416)
  %4033 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4030, 0
  %4034 = insertvalue { <8 x ptr>, <8 x i64> } %4033, <8 x i64> %4032, 1
  %4035 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4036 = extractvalue { <8 x ptr>, <8 x i64> } %4034, 1
  %4037 = extractelement <8 x ptr> %4035, i32 0
  %4038 = extractelement <8 x i64> %4036, i32 %2013
  %4039 = zext i32 %2013 to i64
  %4040 = mul i64 %4039, 4
  %4041 = sub i64 %4038, %4040
  %4042 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4043 = select i1 %4042, i64 %4041, i64 0
  %private.contiguous.address515 = getelementptr i8, ptr %4037, i64 %4043
  %private.contiguous.preserve516 = load <8 x float>, ptr %private.contiguous.address515, align 4
  %4044 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3673, <8 x float> %private.contiguous.preserve516
  store <8 x float> %4044, ptr %private.contiguous.address515, align 4
  %4045 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4046 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4047 = add <8 x i64> %4046, splat (i64 448)
  %4048 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4045, 0
  %4049 = insertvalue { <8 x ptr>, <8 x i64> } %4048, <8 x i64> %4047, 1
  %4050 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4051 = extractvalue { <8 x ptr>, <8 x i64> } %4049, 1
  %4052 = extractelement <8 x ptr> %4050, i32 0
  %4053 = extractelement <8 x i64> %4051, i32 %2013
  %4054 = zext i32 %2013 to i64
  %4055 = mul i64 %4054, 4
  %4056 = sub i64 %4053, %4055
  %4057 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4058 = select i1 %4057, i64 %4056, i64 0
  %private.contiguous.address517 = getelementptr i8, ptr %4052, i64 %4058
  %private.contiguous.preserve518 = load <8 x float>, ptr %private.contiguous.address517, align 4
  %4059 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3676, <8 x float> %private.contiguous.preserve518
  store <8 x float> %4059, ptr %private.contiguous.address517, align 4
  %4060 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4061 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4062 = add <8 x i64> %4061, splat (i64 480)
  %4063 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4060, 0
  %4064 = insertvalue { <8 x ptr>, <8 x i64> } %4063, <8 x i64> %4062, 1
  %4065 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4066 = extractvalue { <8 x ptr>, <8 x i64> } %4064, 1
  %4067 = extractelement <8 x ptr> %4065, i32 0
  %4068 = extractelement <8 x i64> %4066, i32 %2013
  %4069 = zext i32 %2013 to i64
  %4070 = mul i64 %4069, 4
  %4071 = sub i64 %4068, %4070
  %4072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4073 = select i1 %4072, i64 %4071, i64 0
  %private.contiguous.address519 = getelementptr i8, ptr %4067, i64 %4073
  %private.contiguous.preserve520 = load <8 x float>, ptr %private.contiguous.address519, align 4
  %4074 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3679, <8 x float> %private.contiguous.preserve520
  store <8 x float> %4074, ptr %private.contiguous.address519, align 4
  %4075 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4076 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4077 = add <8 x i64> %4076, splat (i64 512)
  %4078 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4075, 0
  %4079 = insertvalue { <8 x ptr>, <8 x i64> } %4078, <8 x i64> %4077, 1
  %4080 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4081 = extractvalue { <8 x ptr>, <8 x i64> } %4079, 1
  %4082 = extractelement <8 x ptr> %4080, i32 0
  %4083 = extractelement <8 x i64> %4081, i32 %2013
  %4084 = zext i32 %2013 to i64
  %4085 = mul i64 %4084, 4
  %4086 = sub i64 %4083, %4085
  %4087 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4088 = select i1 %4087, i64 %4086, i64 0
  %private.contiguous.address521 = getelementptr i8, ptr %4082, i64 %4088
  %private.contiguous.preserve522 = load <8 x float>, ptr %private.contiguous.address521, align 4
  %4089 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3682, <8 x float> %private.contiguous.preserve522
  store <8 x float> %4089, ptr %private.contiguous.address521, align 4
  %4090 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4091 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4092 = add <8 x i64> %4091, splat (i64 544)
  %4093 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4090, 0
  %4094 = insertvalue { <8 x ptr>, <8 x i64> } %4093, <8 x i64> %4092, 1
  %4095 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4096 = extractvalue { <8 x ptr>, <8 x i64> } %4094, 1
  %4097 = extractelement <8 x ptr> %4095, i32 0
  %4098 = extractelement <8 x i64> %4096, i32 %2013
  %4099 = zext i32 %2013 to i64
  %4100 = mul i64 %4099, 4
  %4101 = sub i64 %4098, %4100
  %4102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4103 = select i1 %4102, i64 %4101, i64 0
  %private.contiguous.address523 = getelementptr i8, ptr %4097, i64 %4103
  %private.contiguous.preserve524 = load <8 x float>, ptr %private.contiguous.address523, align 4
  %4104 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3685, <8 x float> %private.contiguous.preserve524
  store <8 x float> %4104, ptr %private.contiguous.address523, align 4
  %4105 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4106 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4107 = add <8 x i64> %4106, splat (i64 576)
  %4108 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4105, 0
  %4109 = insertvalue { <8 x ptr>, <8 x i64> } %4108, <8 x i64> %4107, 1
  %4110 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4111 = extractvalue { <8 x ptr>, <8 x i64> } %4109, 1
  %4112 = extractelement <8 x ptr> %4110, i32 0
  %4113 = extractelement <8 x i64> %4111, i32 %2013
  %4114 = zext i32 %2013 to i64
  %4115 = mul i64 %4114, 4
  %4116 = sub i64 %4113, %4115
  %4117 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4118 = select i1 %4117, i64 %4116, i64 0
  %private.contiguous.address525 = getelementptr i8, ptr %4112, i64 %4118
  %private.contiguous.preserve526 = load <8 x float>, ptr %private.contiguous.address525, align 4
  %4119 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3688, <8 x float> %private.contiguous.preserve526
  store <8 x float> %4119, ptr %private.contiguous.address525, align 4
  %4120 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4121 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4122 = add <8 x i64> %4121, splat (i64 608)
  %4123 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4120, 0
  %4124 = insertvalue { <8 x ptr>, <8 x i64> } %4123, <8 x i64> %4122, 1
  %4125 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4126 = extractvalue { <8 x ptr>, <8 x i64> } %4124, 1
  %4127 = extractelement <8 x ptr> %4125, i32 0
  %4128 = extractelement <8 x i64> %4126, i32 %2013
  %4129 = zext i32 %2013 to i64
  %4130 = mul i64 %4129, 4
  %4131 = sub i64 %4128, %4130
  %4132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4133 = select i1 %4132, i64 %4131, i64 0
  %private.contiguous.address527 = getelementptr i8, ptr %4127, i64 %4133
  %private.contiguous.preserve528 = load <8 x float>, ptr %private.contiguous.address527, align 4
  %4134 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3691, <8 x float> %private.contiguous.preserve528
  store <8 x float> %4134, ptr %private.contiguous.address527, align 4
  %4135 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4136 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4137 = add <8 x i64> %4136, splat (i64 640)
  %4138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4135, 0
  %4139 = insertvalue { <8 x ptr>, <8 x i64> } %4138, <8 x i64> %4137, 1
  %4140 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4141 = extractvalue { <8 x ptr>, <8 x i64> } %4139, 1
  %4142 = extractelement <8 x ptr> %4140, i32 0
  %4143 = extractelement <8 x i64> %4141, i32 %2013
  %4144 = zext i32 %2013 to i64
  %4145 = mul i64 %4144, 4
  %4146 = sub i64 %4143, %4145
  %4147 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4148 = select i1 %4147, i64 %4146, i64 0
  %private.contiguous.address529 = getelementptr i8, ptr %4142, i64 %4148
  %private.contiguous.preserve530 = load <8 x float>, ptr %private.contiguous.address529, align 4
  %4149 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3694, <8 x float> %private.contiguous.preserve530
  store <8 x float> %4149, ptr %private.contiguous.address529, align 4
  %4150 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4151 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4152 = add <8 x i64> %4151, splat (i64 672)
  %4153 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4150, 0
  %4154 = insertvalue { <8 x ptr>, <8 x i64> } %4153, <8 x i64> %4152, 1
  %4155 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4156 = extractvalue { <8 x ptr>, <8 x i64> } %4154, 1
  %4157 = extractelement <8 x ptr> %4155, i32 0
  %4158 = extractelement <8 x i64> %4156, i32 %2013
  %4159 = zext i32 %2013 to i64
  %4160 = mul i64 %4159, 4
  %4161 = sub i64 %4158, %4160
  %4162 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4163 = select i1 %4162, i64 %4161, i64 0
  %private.contiguous.address531 = getelementptr i8, ptr %4157, i64 %4163
  %private.contiguous.preserve532 = load <8 x float>, ptr %private.contiguous.address531, align 4
  %4164 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3697, <8 x float> %private.contiguous.preserve532
  store <8 x float> %4164, ptr %private.contiguous.address531, align 4
  %4165 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4166 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4167 = add <8 x i64> %4166, splat (i64 704)
  %4168 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4165, 0
  %4169 = insertvalue { <8 x ptr>, <8 x i64> } %4168, <8 x i64> %4167, 1
  %4170 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4171 = extractvalue { <8 x ptr>, <8 x i64> } %4169, 1
  %4172 = extractelement <8 x ptr> %4170, i32 0
  %4173 = extractelement <8 x i64> %4171, i32 %2013
  %4174 = zext i32 %2013 to i64
  %4175 = mul i64 %4174, 4
  %4176 = sub i64 %4173, %4175
  %4177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4178 = select i1 %4177, i64 %4176, i64 0
  %private.contiguous.address533 = getelementptr i8, ptr %4172, i64 %4178
  %private.contiguous.preserve534 = load <8 x float>, ptr %private.contiguous.address533, align 4
  %4179 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3700, <8 x float> %private.contiguous.preserve534
  store <8 x float> %4179, ptr %private.contiguous.address533, align 4
  %4180 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4181 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4182 = add <8 x i64> %4181, splat (i64 736)
  %4183 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4180, 0
  %4184 = insertvalue { <8 x ptr>, <8 x i64> } %4183, <8 x i64> %4182, 1
  %4185 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4186 = extractvalue { <8 x ptr>, <8 x i64> } %4184, 1
  %4187 = extractelement <8 x ptr> %4185, i32 0
  %4188 = extractelement <8 x i64> %4186, i32 %2013
  %4189 = zext i32 %2013 to i64
  %4190 = mul i64 %4189, 4
  %4191 = sub i64 %4188, %4190
  %4192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4193 = select i1 %4192, i64 %4191, i64 0
  %private.contiguous.address535 = getelementptr i8, ptr %4187, i64 %4193
  %private.contiguous.preserve536 = load <8 x float>, ptr %private.contiguous.address535, align 4
  %4194 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3703, <8 x float> %private.contiguous.preserve536
  store <8 x float> %4194, ptr %private.contiguous.address535, align 4
  %4195 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4196 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4197 = add <8 x i64> %4196, splat (i64 768)
  %4198 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4195, 0
  %4199 = insertvalue { <8 x ptr>, <8 x i64> } %4198, <8 x i64> %4197, 1
  %4200 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4201 = extractvalue { <8 x ptr>, <8 x i64> } %4199, 1
  %4202 = extractelement <8 x ptr> %4200, i32 0
  %4203 = extractelement <8 x i64> %4201, i32 %2013
  %4204 = zext i32 %2013 to i64
  %4205 = mul i64 %4204, 4
  %4206 = sub i64 %4203, %4205
  %4207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4208 = select i1 %4207, i64 %4206, i64 0
  %private.contiguous.address537 = getelementptr i8, ptr %4202, i64 %4208
  %private.contiguous.preserve538 = load <8 x float>, ptr %private.contiguous.address537, align 4
  %4209 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3706, <8 x float> %private.contiguous.preserve538
  store <8 x float> %4209, ptr %private.contiguous.address537, align 4
  %4210 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4211 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4212 = add <8 x i64> %4211, splat (i64 800)
  %4213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4210, 0
  %4214 = insertvalue { <8 x ptr>, <8 x i64> } %4213, <8 x i64> %4212, 1
  %4215 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4216 = extractvalue { <8 x ptr>, <8 x i64> } %4214, 1
  %4217 = extractelement <8 x ptr> %4215, i32 0
  %4218 = extractelement <8 x i64> %4216, i32 %2013
  %4219 = zext i32 %2013 to i64
  %4220 = mul i64 %4219, 4
  %4221 = sub i64 %4218, %4220
  %4222 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4223 = select i1 %4222, i64 %4221, i64 0
  %private.contiguous.address539 = getelementptr i8, ptr %4217, i64 %4223
  %private.contiguous.preserve540 = load <8 x float>, ptr %private.contiguous.address539, align 4
  %4224 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3709, <8 x float> %private.contiguous.preserve540
  store <8 x float> %4224, ptr %private.contiguous.address539, align 4
  %4225 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4226 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4227 = add <8 x i64> %4226, splat (i64 832)
  %4228 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4225, 0
  %4229 = insertvalue { <8 x ptr>, <8 x i64> } %4228, <8 x i64> %4227, 1
  %4230 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4231 = extractvalue { <8 x ptr>, <8 x i64> } %4229, 1
  %4232 = extractelement <8 x ptr> %4230, i32 0
  %4233 = extractelement <8 x i64> %4231, i32 %2013
  %4234 = zext i32 %2013 to i64
  %4235 = mul i64 %4234, 4
  %4236 = sub i64 %4233, %4235
  %4237 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4238 = select i1 %4237, i64 %4236, i64 0
  %private.contiguous.address541 = getelementptr i8, ptr %4232, i64 %4238
  %private.contiguous.preserve542 = load <8 x float>, ptr %private.contiguous.address541, align 4
  %4239 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3712, <8 x float> %private.contiguous.preserve542
  store <8 x float> %4239, ptr %private.contiguous.address541, align 4
  %4240 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4241 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4242 = add <8 x i64> %4241, splat (i64 864)
  %4243 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4240, 0
  %4244 = insertvalue { <8 x ptr>, <8 x i64> } %4243, <8 x i64> %4242, 1
  %4245 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4246 = extractvalue { <8 x ptr>, <8 x i64> } %4244, 1
  %4247 = extractelement <8 x ptr> %4245, i32 0
  %4248 = extractelement <8 x i64> %4246, i32 %2013
  %4249 = zext i32 %2013 to i64
  %4250 = mul i64 %4249, 4
  %4251 = sub i64 %4248, %4250
  %4252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4253 = select i1 %4252, i64 %4251, i64 0
  %private.contiguous.address543 = getelementptr i8, ptr %4247, i64 %4253
  %private.contiguous.preserve544 = load <8 x float>, ptr %private.contiguous.address543, align 4
  %4254 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3715, <8 x float> %private.contiguous.preserve544
  store <8 x float> %4254, ptr %private.contiguous.address543, align 4
  %4255 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4256 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4257 = add <8 x i64> %4256, splat (i64 896)
  %4258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4255, 0
  %4259 = insertvalue { <8 x ptr>, <8 x i64> } %4258, <8 x i64> %4257, 1
  %4260 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4261 = extractvalue { <8 x ptr>, <8 x i64> } %4259, 1
  %4262 = extractelement <8 x ptr> %4260, i32 0
  %4263 = extractelement <8 x i64> %4261, i32 %2013
  %4264 = zext i32 %2013 to i64
  %4265 = mul i64 %4264, 4
  %4266 = sub i64 %4263, %4265
  %4267 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4268 = select i1 %4267, i64 %4266, i64 0
  %private.contiguous.address545 = getelementptr i8, ptr %4262, i64 %4268
  %private.contiguous.preserve546 = load <8 x float>, ptr %private.contiguous.address545, align 4
  %4269 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3718, <8 x float> %private.contiguous.preserve546
  store <8 x float> %4269, ptr %private.contiguous.address545, align 4
  %4270 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4271 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4272 = add <8 x i64> %4271, splat (i64 928)
  %4273 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4270, 0
  %4274 = insertvalue { <8 x ptr>, <8 x i64> } %4273, <8 x i64> %4272, 1
  %4275 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4276 = extractvalue { <8 x ptr>, <8 x i64> } %4274, 1
  %4277 = extractelement <8 x ptr> %4275, i32 0
  %4278 = extractelement <8 x i64> %4276, i32 %2013
  %4279 = zext i32 %2013 to i64
  %4280 = mul i64 %4279, 4
  %4281 = sub i64 %4278, %4280
  %4282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4283 = select i1 %4282, i64 %4281, i64 0
  %private.contiguous.address547 = getelementptr i8, ptr %4277, i64 %4283
  %private.contiguous.preserve548 = load <8 x float>, ptr %private.contiguous.address547, align 4
  %4284 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3721, <8 x float> %private.contiguous.preserve548
  store <8 x float> %4284, ptr %private.contiguous.address547, align 4
  %4285 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4286 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4287 = add <8 x i64> %4286, splat (i64 960)
  %4288 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4285, 0
  %4289 = insertvalue { <8 x ptr>, <8 x i64> } %4288, <8 x i64> %4287, 1
  %4290 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4291 = extractvalue { <8 x ptr>, <8 x i64> } %4289, 1
  %4292 = extractelement <8 x ptr> %4290, i32 0
  %4293 = extractelement <8 x i64> %4291, i32 %2013
  %4294 = zext i32 %2013 to i64
  %4295 = mul i64 %4294, 4
  %4296 = sub i64 %4293, %4295
  %4297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4298 = select i1 %4297, i64 %4296, i64 0
  %private.contiguous.address549 = getelementptr i8, ptr %4292, i64 %4298
  %private.contiguous.preserve550 = load <8 x float>, ptr %private.contiguous.address549, align 4
  %4299 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3724, <8 x float> %private.contiguous.preserve550
  store <8 x float> %4299, ptr %private.contiguous.address549, align 4
  %4300 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4301 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4302 = add <8 x i64> %4301, splat (i64 992)
  %4303 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4300, 0
  %4304 = insertvalue { <8 x ptr>, <8 x i64> } %4303, <8 x i64> %4302, 1
  %4305 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4306 = extractvalue { <8 x ptr>, <8 x i64> } %4304, 1
  %4307 = extractelement <8 x ptr> %4305, i32 0
  %4308 = extractelement <8 x i64> %4306, i32 %2013
  %4309 = zext i32 %2013 to i64
  %4310 = mul i64 %4309, 4
  %4311 = sub i64 %4308, %4310
  %4312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4313 = select i1 %4312, i64 %4311, i64 0
  %private.contiguous.address551 = getelementptr i8, ptr %4307, i64 %4313
  %private.contiguous.preserve552 = load <8 x float>, ptr %private.contiguous.address551, align 4
  %4314 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3727, <8 x float> %private.contiguous.preserve552
  store <8 x float> %4314, ptr %private.contiguous.address551, align 4
  %4315 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4316 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4317 = add <8 x i64> %4316, splat (i64 1024)
  %4318 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4315, 0
  %4319 = insertvalue { <8 x ptr>, <8 x i64> } %4318, <8 x i64> %4317, 1
  %4320 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4321 = extractvalue { <8 x ptr>, <8 x i64> } %4319, 1
  %4322 = extractelement <8 x ptr> %4320, i32 0
  %4323 = extractelement <8 x i64> %4321, i32 %2013
  %4324 = zext i32 %2013 to i64
  %4325 = mul i64 %4324, 4
  %4326 = sub i64 %4323, %4325
  %4327 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4328 = select i1 %4327, i64 %4326, i64 0
  %private.contiguous.address553 = getelementptr i8, ptr %4322, i64 %4328
  %private.contiguous.preserve554 = load <8 x float>, ptr %private.contiguous.address553, align 4
  %4329 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3730, <8 x float> %private.contiguous.preserve554
  store <8 x float> %4329, ptr %private.contiguous.address553, align 4
  %4330 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4331 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4332 = add <8 x i64> %4331, splat (i64 1056)
  %4333 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4330, 0
  %4334 = insertvalue { <8 x ptr>, <8 x i64> } %4333, <8 x i64> %4332, 1
  %4335 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4336 = extractvalue { <8 x ptr>, <8 x i64> } %4334, 1
  %4337 = extractelement <8 x ptr> %4335, i32 0
  %4338 = extractelement <8 x i64> %4336, i32 %2013
  %4339 = zext i32 %2013 to i64
  %4340 = mul i64 %4339, 4
  %4341 = sub i64 %4338, %4340
  %4342 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4343 = select i1 %4342, i64 %4341, i64 0
  %private.contiguous.address555 = getelementptr i8, ptr %4337, i64 %4343
  %private.contiguous.preserve556 = load <8 x float>, ptr %private.contiguous.address555, align 4
  %4344 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3733, <8 x float> %private.contiguous.preserve556
  store <8 x float> %4344, ptr %private.contiguous.address555, align 4
  %4345 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4346 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4347 = add <8 x i64> %4346, splat (i64 1088)
  %4348 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4345, 0
  %4349 = insertvalue { <8 x ptr>, <8 x i64> } %4348, <8 x i64> %4347, 1
  %4350 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4351 = extractvalue { <8 x ptr>, <8 x i64> } %4349, 1
  %4352 = extractelement <8 x ptr> %4350, i32 0
  %4353 = extractelement <8 x i64> %4351, i32 %2013
  %4354 = zext i32 %2013 to i64
  %4355 = mul i64 %4354, 4
  %4356 = sub i64 %4353, %4355
  %4357 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4358 = select i1 %4357, i64 %4356, i64 0
  %private.contiguous.address557 = getelementptr i8, ptr %4352, i64 %4358
  %private.contiguous.preserve558 = load <8 x float>, ptr %private.contiguous.address557, align 4
  %4359 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3736, <8 x float> %private.contiguous.preserve558
  store <8 x float> %4359, ptr %private.contiguous.address557, align 4
  %4360 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4361 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4362 = add <8 x i64> %4361, splat (i64 1120)
  %4363 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4360, 0
  %4364 = insertvalue { <8 x ptr>, <8 x i64> } %4363, <8 x i64> %4362, 1
  %4365 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4366 = extractvalue { <8 x ptr>, <8 x i64> } %4364, 1
  %4367 = extractelement <8 x ptr> %4365, i32 0
  %4368 = extractelement <8 x i64> %4366, i32 %2013
  %4369 = zext i32 %2013 to i64
  %4370 = mul i64 %4369, 4
  %4371 = sub i64 %4368, %4370
  %4372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4373 = select i1 %4372, i64 %4371, i64 0
  %private.contiguous.address559 = getelementptr i8, ptr %4367, i64 %4373
  %private.contiguous.preserve560 = load <8 x float>, ptr %private.contiguous.address559, align 4
  %4374 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3739, <8 x float> %private.contiguous.preserve560
  store <8 x float> %4374, ptr %private.contiguous.address559, align 4
  %4375 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4376 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4377 = add <8 x i64> %4376, splat (i64 1152)
  %4378 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4375, 0
  %4379 = insertvalue { <8 x ptr>, <8 x i64> } %4378, <8 x i64> %4377, 1
  %4380 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4381 = extractvalue { <8 x ptr>, <8 x i64> } %4379, 1
  %4382 = extractelement <8 x ptr> %4380, i32 0
  %4383 = extractelement <8 x i64> %4381, i32 %2013
  %4384 = zext i32 %2013 to i64
  %4385 = mul i64 %4384, 4
  %4386 = sub i64 %4383, %4385
  %4387 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4388 = select i1 %4387, i64 %4386, i64 0
  %private.contiguous.address561 = getelementptr i8, ptr %4382, i64 %4388
  %private.contiguous.preserve562 = load <8 x float>, ptr %private.contiguous.address561, align 4
  %4389 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3742, <8 x float> %private.contiguous.preserve562
  store <8 x float> %4389, ptr %private.contiguous.address561, align 4
  %4390 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4391 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4392 = add <8 x i64> %4391, splat (i64 1184)
  %4393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4390, 0
  %4394 = insertvalue { <8 x ptr>, <8 x i64> } %4393, <8 x i64> %4392, 1
  %4395 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4396 = extractvalue { <8 x ptr>, <8 x i64> } %4394, 1
  %4397 = extractelement <8 x ptr> %4395, i32 0
  %4398 = extractelement <8 x i64> %4396, i32 %2013
  %4399 = zext i32 %2013 to i64
  %4400 = mul i64 %4399, 4
  %4401 = sub i64 %4398, %4400
  %4402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4403 = select i1 %4402, i64 %4401, i64 0
  %private.contiguous.address563 = getelementptr i8, ptr %4397, i64 %4403
  %private.contiguous.preserve564 = load <8 x float>, ptr %private.contiguous.address563, align 4
  %4404 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3745, <8 x float> %private.contiguous.preserve564
  store <8 x float> %4404, ptr %private.contiguous.address563, align 4
  %4405 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4406 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4407 = add <8 x i64> %4406, splat (i64 1216)
  %4408 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4405, 0
  %4409 = insertvalue { <8 x ptr>, <8 x i64> } %4408, <8 x i64> %4407, 1
  %4410 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4411 = extractvalue { <8 x ptr>, <8 x i64> } %4409, 1
  %4412 = extractelement <8 x ptr> %4410, i32 0
  %4413 = extractelement <8 x i64> %4411, i32 %2013
  %4414 = zext i32 %2013 to i64
  %4415 = mul i64 %4414, 4
  %4416 = sub i64 %4413, %4415
  %4417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4418 = select i1 %4417, i64 %4416, i64 0
  %private.contiguous.address565 = getelementptr i8, ptr %4412, i64 %4418
  %private.contiguous.preserve566 = load <8 x float>, ptr %private.contiguous.address565, align 4
  %4419 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3748, <8 x float> %private.contiguous.preserve566
  store <8 x float> %4419, ptr %private.contiguous.address565, align 4
  %4420 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4421 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4422 = add <8 x i64> %4421, splat (i64 1248)
  %4423 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4420, 0
  %4424 = insertvalue { <8 x ptr>, <8 x i64> } %4423, <8 x i64> %4422, 1
  %4425 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4426 = extractvalue { <8 x ptr>, <8 x i64> } %4424, 1
  %4427 = extractelement <8 x ptr> %4425, i32 0
  %4428 = extractelement <8 x i64> %4426, i32 %2013
  %4429 = zext i32 %2013 to i64
  %4430 = mul i64 %4429, 4
  %4431 = sub i64 %4428, %4430
  %4432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4433 = select i1 %4432, i64 %4431, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %4427, i64 %4433
  %private.contiguous.preserve568 = load <8 x float>, ptr %private.contiguous.address567, align 4
  %4434 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3751, <8 x float> %private.contiguous.preserve568
  store <8 x float> %4434, ptr %private.contiguous.address567, align 4
  %4435 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4436 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4437 = add <8 x i64> %4436, splat (i64 1280)
  %4438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4435, 0
  %4439 = insertvalue { <8 x ptr>, <8 x i64> } %4438, <8 x i64> %4437, 1
  %4440 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4441 = extractvalue { <8 x ptr>, <8 x i64> } %4439, 1
  %4442 = extractelement <8 x ptr> %4440, i32 0
  %4443 = extractelement <8 x i64> %4441, i32 %2013
  %4444 = zext i32 %2013 to i64
  %4445 = mul i64 %4444, 4
  %4446 = sub i64 %4443, %4445
  %4447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4448 = select i1 %4447, i64 %4446, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %4442, i64 %4448
  %private.contiguous.preserve570 = load <8 x float>, ptr %private.contiguous.address569, align 4
  %4449 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3754, <8 x float> %private.contiguous.preserve570
  store <8 x float> %4449, ptr %private.contiguous.address569, align 4
  %4450 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4451 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4452 = add <8 x i64> %4451, splat (i64 1312)
  %4453 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4450, 0
  %4454 = insertvalue { <8 x ptr>, <8 x i64> } %4453, <8 x i64> %4452, 1
  %4455 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4456 = extractvalue { <8 x ptr>, <8 x i64> } %4454, 1
  %4457 = extractelement <8 x ptr> %4455, i32 0
  %4458 = extractelement <8 x i64> %4456, i32 %2013
  %4459 = zext i32 %2013 to i64
  %4460 = mul i64 %4459, 4
  %4461 = sub i64 %4458, %4460
  %4462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4463 = select i1 %4462, i64 %4461, i64 0
  %private.contiguous.address571 = getelementptr i8, ptr %4457, i64 %4463
  %private.contiguous.preserve572 = load <8 x float>, ptr %private.contiguous.address571, align 4
  %4464 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3757, <8 x float> %private.contiguous.preserve572
  store <8 x float> %4464, ptr %private.contiguous.address571, align 4
  %4465 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4466 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4467 = add <8 x i64> %4466, splat (i64 1344)
  %4468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4465, 0
  %4469 = insertvalue { <8 x ptr>, <8 x i64> } %4468, <8 x i64> %4467, 1
  %4470 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4471 = extractvalue { <8 x ptr>, <8 x i64> } %4469, 1
  %4472 = extractelement <8 x ptr> %4470, i32 0
  %4473 = extractelement <8 x i64> %4471, i32 %2013
  %4474 = zext i32 %2013 to i64
  %4475 = mul i64 %4474, 4
  %4476 = sub i64 %4473, %4475
  %4477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4478 = select i1 %4477, i64 %4476, i64 0
  %private.contiguous.address573 = getelementptr i8, ptr %4472, i64 %4478
  %private.contiguous.preserve574 = load <8 x float>, ptr %private.contiguous.address573, align 4
  %4479 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3760, <8 x float> %private.contiguous.preserve574
  store <8 x float> %4479, ptr %private.contiguous.address573, align 4
  %4480 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4481 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4482 = add <8 x i64> %4481, splat (i64 1376)
  %4483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4480, 0
  %4484 = insertvalue { <8 x ptr>, <8 x i64> } %4483, <8 x i64> %4482, 1
  %4485 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4486 = extractvalue { <8 x ptr>, <8 x i64> } %4484, 1
  %4487 = extractelement <8 x ptr> %4485, i32 0
  %4488 = extractelement <8 x i64> %4486, i32 %2013
  %4489 = zext i32 %2013 to i64
  %4490 = mul i64 %4489, 4
  %4491 = sub i64 %4488, %4490
  %4492 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4493 = select i1 %4492, i64 %4491, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %4487, i64 %4493
  %private.contiguous.preserve576 = load <8 x float>, ptr %private.contiguous.address575, align 4
  %4494 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3763, <8 x float> %private.contiguous.preserve576
  store <8 x float> %4494, ptr %private.contiguous.address575, align 4
  %4495 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4496 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4497 = add <8 x i64> %4496, splat (i64 1408)
  %4498 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4495, 0
  %4499 = insertvalue { <8 x ptr>, <8 x i64> } %4498, <8 x i64> %4497, 1
  %4500 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4501 = extractvalue { <8 x ptr>, <8 x i64> } %4499, 1
  %4502 = extractelement <8 x ptr> %4500, i32 0
  %4503 = extractelement <8 x i64> %4501, i32 %2013
  %4504 = zext i32 %2013 to i64
  %4505 = mul i64 %4504, 4
  %4506 = sub i64 %4503, %4505
  %4507 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4508 = select i1 %4507, i64 %4506, i64 0
  %private.contiguous.address577 = getelementptr i8, ptr %4502, i64 %4508
  %private.contiguous.preserve578 = load <8 x float>, ptr %private.contiguous.address577, align 4
  %4509 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3766, <8 x float> %private.contiguous.preserve578
  store <8 x float> %4509, ptr %private.contiguous.address577, align 4
  %4510 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4511 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4512 = add <8 x i64> %4511, splat (i64 1440)
  %4513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4510, 0
  %4514 = insertvalue { <8 x ptr>, <8 x i64> } %4513, <8 x i64> %4512, 1
  %4515 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4516 = extractvalue { <8 x ptr>, <8 x i64> } %4514, 1
  %4517 = extractelement <8 x ptr> %4515, i32 0
  %4518 = extractelement <8 x i64> %4516, i32 %2013
  %4519 = zext i32 %2013 to i64
  %4520 = mul i64 %4519, 4
  %4521 = sub i64 %4518, %4520
  %4522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4523 = select i1 %4522, i64 %4521, i64 0
  %private.contiguous.address579 = getelementptr i8, ptr %4517, i64 %4523
  %private.contiguous.preserve580 = load <8 x float>, ptr %private.contiguous.address579, align 4
  %4524 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3769, <8 x float> %private.contiguous.preserve580
  store <8 x float> %4524, ptr %private.contiguous.address579, align 4
  %4525 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4526 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4527 = add <8 x i64> %4526, splat (i64 1472)
  %4528 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4525, 0
  %4529 = insertvalue { <8 x ptr>, <8 x i64> } %4528, <8 x i64> %4527, 1
  %4530 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4531 = extractvalue { <8 x ptr>, <8 x i64> } %4529, 1
  %4532 = extractelement <8 x ptr> %4530, i32 0
  %4533 = extractelement <8 x i64> %4531, i32 %2013
  %4534 = zext i32 %2013 to i64
  %4535 = mul i64 %4534, 4
  %4536 = sub i64 %4533, %4535
  %4537 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4538 = select i1 %4537, i64 %4536, i64 0
  %private.contiguous.address581 = getelementptr i8, ptr %4532, i64 %4538
  %private.contiguous.preserve582 = load <8 x float>, ptr %private.contiguous.address581, align 4
  %4539 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3772, <8 x float> %private.contiguous.preserve582
  store <8 x float> %4539, ptr %private.contiguous.address581, align 4
  %4540 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4541 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4542 = add <8 x i64> %4541, splat (i64 1504)
  %4543 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4540, 0
  %4544 = insertvalue { <8 x ptr>, <8 x i64> } %4543, <8 x i64> %4542, 1
  %4545 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4546 = extractvalue { <8 x ptr>, <8 x i64> } %4544, 1
  %4547 = extractelement <8 x ptr> %4545, i32 0
  %4548 = extractelement <8 x i64> %4546, i32 %2013
  %4549 = zext i32 %2013 to i64
  %4550 = mul i64 %4549, 4
  %4551 = sub i64 %4548, %4550
  %4552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4553 = select i1 %4552, i64 %4551, i64 0
  %private.contiguous.address583 = getelementptr i8, ptr %4547, i64 %4553
  %private.contiguous.preserve584 = load <8 x float>, ptr %private.contiguous.address583, align 4
  %4554 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3775, <8 x float> %private.contiguous.preserve584
  store <8 x float> %4554, ptr %private.contiguous.address583, align 4
  %4555 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4556 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4557 = add <8 x i64> %4556, splat (i64 1536)
  %4558 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4555, 0
  %4559 = insertvalue { <8 x ptr>, <8 x i64> } %4558, <8 x i64> %4557, 1
  %4560 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4561 = extractvalue { <8 x ptr>, <8 x i64> } %4559, 1
  %4562 = extractelement <8 x ptr> %4560, i32 0
  %4563 = extractelement <8 x i64> %4561, i32 %2013
  %4564 = zext i32 %2013 to i64
  %4565 = mul i64 %4564, 4
  %4566 = sub i64 %4563, %4565
  %4567 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4568 = select i1 %4567, i64 %4566, i64 0
  %private.contiguous.address585 = getelementptr i8, ptr %4562, i64 %4568
  %private.contiguous.preserve586 = load <8 x float>, ptr %private.contiguous.address585, align 4
  %4569 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3778, <8 x float> %private.contiguous.preserve586
  store <8 x float> %4569, ptr %private.contiguous.address585, align 4
  %4570 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4571 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4572 = add <8 x i64> %4571, splat (i64 1568)
  %4573 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4570, 0
  %4574 = insertvalue { <8 x ptr>, <8 x i64> } %4573, <8 x i64> %4572, 1
  %4575 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4576 = extractvalue { <8 x ptr>, <8 x i64> } %4574, 1
  %4577 = extractelement <8 x ptr> %4575, i32 0
  %4578 = extractelement <8 x i64> %4576, i32 %2013
  %4579 = zext i32 %2013 to i64
  %4580 = mul i64 %4579, 4
  %4581 = sub i64 %4578, %4580
  %4582 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4583 = select i1 %4582, i64 %4581, i64 0
  %private.contiguous.address587 = getelementptr i8, ptr %4577, i64 %4583
  %private.contiguous.preserve588 = load <8 x float>, ptr %private.contiguous.address587, align 4
  %4584 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3781, <8 x float> %private.contiguous.preserve588
  store <8 x float> %4584, ptr %private.contiguous.address587, align 4
  %4585 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4586 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4587 = add <8 x i64> %4586, splat (i64 1600)
  %4588 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4585, 0
  %4589 = insertvalue { <8 x ptr>, <8 x i64> } %4588, <8 x i64> %4587, 1
  %4590 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4591 = extractvalue { <8 x ptr>, <8 x i64> } %4589, 1
  %4592 = extractelement <8 x ptr> %4590, i32 0
  %4593 = extractelement <8 x i64> %4591, i32 %2013
  %4594 = zext i32 %2013 to i64
  %4595 = mul i64 %4594, 4
  %4596 = sub i64 %4593, %4595
  %4597 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4598 = select i1 %4597, i64 %4596, i64 0
  %private.contiguous.address589 = getelementptr i8, ptr %4592, i64 %4598
  %private.contiguous.preserve590 = load <8 x float>, ptr %private.contiguous.address589, align 4
  %4599 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3784, <8 x float> %private.contiguous.preserve590
  store <8 x float> %4599, ptr %private.contiguous.address589, align 4
  %4600 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4601 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4602 = add <8 x i64> %4601, splat (i64 1632)
  %4603 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4600, 0
  %4604 = insertvalue { <8 x ptr>, <8 x i64> } %4603, <8 x i64> %4602, 1
  %4605 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4606 = extractvalue { <8 x ptr>, <8 x i64> } %4604, 1
  %4607 = extractelement <8 x ptr> %4605, i32 0
  %4608 = extractelement <8 x i64> %4606, i32 %2013
  %4609 = zext i32 %2013 to i64
  %4610 = mul i64 %4609, 4
  %4611 = sub i64 %4608, %4610
  %4612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4613 = select i1 %4612, i64 %4611, i64 0
  %private.contiguous.address591 = getelementptr i8, ptr %4607, i64 %4613
  %private.contiguous.preserve592 = load <8 x float>, ptr %private.contiguous.address591, align 4
  %4614 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3787, <8 x float> %private.contiguous.preserve592
  store <8 x float> %4614, ptr %private.contiguous.address591, align 4
  %4615 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4616 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4617 = add <8 x i64> %4616, splat (i64 1664)
  %4618 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4615, 0
  %4619 = insertvalue { <8 x ptr>, <8 x i64> } %4618, <8 x i64> %4617, 1
  %4620 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4621 = extractvalue { <8 x ptr>, <8 x i64> } %4619, 1
  %4622 = extractelement <8 x ptr> %4620, i32 0
  %4623 = extractelement <8 x i64> %4621, i32 %2013
  %4624 = zext i32 %2013 to i64
  %4625 = mul i64 %4624, 4
  %4626 = sub i64 %4623, %4625
  %4627 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4628 = select i1 %4627, i64 %4626, i64 0
  %private.contiguous.address593 = getelementptr i8, ptr %4622, i64 %4628
  %private.contiguous.preserve594 = load <8 x float>, ptr %private.contiguous.address593, align 4
  %4629 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3790, <8 x float> %private.contiguous.preserve594
  store <8 x float> %4629, ptr %private.contiguous.address593, align 4
  %4630 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4631 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4632 = add <8 x i64> %4631, splat (i64 1696)
  %4633 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4630, 0
  %4634 = insertvalue { <8 x ptr>, <8 x i64> } %4633, <8 x i64> %4632, 1
  %4635 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4636 = extractvalue { <8 x ptr>, <8 x i64> } %4634, 1
  %4637 = extractelement <8 x ptr> %4635, i32 0
  %4638 = extractelement <8 x i64> %4636, i32 %2013
  %4639 = zext i32 %2013 to i64
  %4640 = mul i64 %4639, 4
  %4641 = sub i64 %4638, %4640
  %4642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4643 = select i1 %4642, i64 %4641, i64 0
  %private.contiguous.address595 = getelementptr i8, ptr %4637, i64 %4643
  %private.contiguous.preserve596 = load <8 x float>, ptr %private.contiguous.address595, align 4
  %4644 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3793, <8 x float> %private.contiguous.preserve596
  store <8 x float> %4644, ptr %private.contiguous.address595, align 4
  %4645 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4646 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4647 = add <8 x i64> %4646, splat (i64 1728)
  %4648 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4645, 0
  %4649 = insertvalue { <8 x ptr>, <8 x i64> } %4648, <8 x i64> %4647, 1
  %4650 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4651 = extractvalue { <8 x ptr>, <8 x i64> } %4649, 1
  %4652 = extractelement <8 x ptr> %4650, i32 0
  %4653 = extractelement <8 x i64> %4651, i32 %2013
  %4654 = zext i32 %2013 to i64
  %4655 = mul i64 %4654, 4
  %4656 = sub i64 %4653, %4655
  %4657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4658 = select i1 %4657, i64 %4656, i64 0
  %private.contiguous.address597 = getelementptr i8, ptr %4652, i64 %4658
  %private.contiguous.preserve598 = load <8 x float>, ptr %private.contiguous.address597, align 4
  %4659 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3796, <8 x float> %private.contiguous.preserve598
  store <8 x float> %4659, ptr %private.contiguous.address597, align 4
  %4660 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4661 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4662 = add <8 x i64> %4661, splat (i64 1760)
  %4663 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4660, 0
  %4664 = insertvalue { <8 x ptr>, <8 x i64> } %4663, <8 x i64> %4662, 1
  %4665 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4666 = extractvalue { <8 x ptr>, <8 x i64> } %4664, 1
  %4667 = extractelement <8 x ptr> %4665, i32 0
  %4668 = extractelement <8 x i64> %4666, i32 %2013
  %4669 = zext i32 %2013 to i64
  %4670 = mul i64 %4669, 4
  %4671 = sub i64 %4668, %4670
  %4672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4673 = select i1 %4672, i64 %4671, i64 0
  %private.contiguous.address599 = getelementptr i8, ptr %4667, i64 %4673
  %private.contiguous.preserve600 = load <8 x float>, ptr %private.contiguous.address599, align 4
  %4674 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3799, <8 x float> %private.contiguous.preserve600
  store <8 x float> %4674, ptr %private.contiguous.address599, align 4
  %4675 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4676 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4677 = add <8 x i64> %4676, splat (i64 1792)
  %4678 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4675, 0
  %4679 = insertvalue { <8 x ptr>, <8 x i64> } %4678, <8 x i64> %4677, 1
  %4680 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4681 = extractvalue { <8 x ptr>, <8 x i64> } %4679, 1
  %4682 = extractelement <8 x ptr> %4680, i32 0
  %4683 = extractelement <8 x i64> %4681, i32 %2013
  %4684 = zext i32 %2013 to i64
  %4685 = mul i64 %4684, 4
  %4686 = sub i64 %4683, %4685
  %4687 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4688 = select i1 %4687, i64 %4686, i64 0
  %private.contiguous.address601 = getelementptr i8, ptr %4682, i64 %4688
  %private.contiguous.preserve602 = load <8 x float>, ptr %private.contiguous.address601, align 4
  %4689 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3802, <8 x float> %private.contiguous.preserve602
  store <8 x float> %4689, ptr %private.contiguous.address601, align 4
  %4690 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4691 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4692 = add <8 x i64> %4691, splat (i64 1824)
  %4693 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4690, 0
  %4694 = insertvalue { <8 x ptr>, <8 x i64> } %4693, <8 x i64> %4692, 1
  %4695 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4696 = extractvalue { <8 x ptr>, <8 x i64> } %4694, 1
  %4697 = extractelement <8 x ptr> %4695, i32 0
  %4698 = extractelement <8 x i64> %4696, i32 %2013
  %4699 = zext i32 %2013 to i64
  %4700 = mul i64 %4699, 4
  %4701 = sub i64 %4698, %4700
  %4702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4703 = select i1 %4702, i64 %4701, i64 0
  %private.contiguous.address603 = getelementptr i8, ptr %4697, i64 %4703
  %private.contiguous.preserve604 = load <8 x float>, ptr %private.contiguous.address603, align 4
  %4704 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3805, <8 x float> %private.contiguous.preserve604
  store <8 x float> %4704, ptr %private.contiguous.address603, align 4
  %4705 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4706 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4707 = add <8 x i64> %4706, splat (i64 1856)
  %4708 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4705, 0
  %4709 = insertvalue { <8 x ptr>, <8 x i64> } %4708, <8 x i64> %4707, 1
  %4710 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4711 = extractvalue { <8 x ptr>, <8 x i64> } %4709, 1
  %4712 = extractelement <8 x ptr> %4710, i32 0
  %4713 = extractelement <8 x i64> %4711, i32 %2013
  %4714 = zext i32 %2013 to i64
  %4715 = mul i64 %4714, 4
  %4716 = sub i64 %4713, %4715
  %4717 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4718 = select i1 %4717, i64 %4716, i64 0
  %private.contiguous.address605 = getelementptr i8, ptr %4712, i64 %4718
  %private.contiguous.preserve606 = load <8 x float>, ptr %private.contiguous.address605, align 4
  %4719 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3808, <8 x float> %private.contiguous.preserve606
  store <8 x float> %4719, ptr %private.contiguous.address605, align 4
  %4720 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4721 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4722 = add <8 x i64> %4721, splat (i64 1888)
  %4723 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4720, 0
  %4724 = insertvalue { <8 x ptr>, <8 x i64> } %4723, <8 x i64> %4722, 1
  %4725 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4726 = extractvalue { <8 x ptr>, <8 x i64> } %4724, 1
  %4727 = extractelement <8 x ptr> %4725, i32 0
  %4728 = extractelement <8 x i64> %4726, i32 %2013
  %4729 = zext i32 %2013 to i64
  %4730 = mul i64 %4729, 4
  %4731 = sub i64 %4728, %4730
  %4732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4733 = select i1 %4732, i64 %4731, i64 0
  %private.contiguous.address607 = getelementptr i8, ptr %4727, i64 %4733
  %private.contiguous.preserve608 = load <8 x float>, ptr %private.contiguous.address607, align 4
  %4734 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3811, <8 x float> %private.contiguous.preserve608
  store <8 x float> %4734, ptr %private.contiguous.address607, align 4
  %4735 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4736 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4737 = add <8 x i64> %4736, splat (i64 1920)
  %4738 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4735, 0
  %4739 = insertvalue { <8 x ptr>, <8 x i64> } %4738, <8 x i64> %4737, 1
  %4740 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4741 = extractvalue { <8 x ptr>, <8 x i64> } %4739, 1
  %4742 = extractelement <8 x ptr> %4740, i32 0
  %4743 = extractelement <8 x i64> %4741, i32 %2013
  %4744 = zext i32 %2013 to i64
  %4745 = mul i64 %4744, 4
  %4746 = sub i64 %4743, %4745
  %4747 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4748 = select i1 %4747, i64 %4746, i64 0
  %private.contiguous.address609 = getelementptr i8, ptr %4742, i64 %4748
  %private.contiguous.preserve610 = load <8 x float>, ptr %private.contiguous.address609, align 4
  %4749 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3814, <8 x float> %private.contiguous.preserve610
  store <8 x float> %4749, ptr %private.contiguous.address609, align 4
  %4750 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4751 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4752 = add <8 x i64> %4751, splat (i64 1952)
  %4753 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4750, 0
  %4754 = insertvalue { <8 x ptr>, <8 x i64> } %4753, <8 x i64> %4752, 1
  %4755 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4756 = extractvalue { <8 x ptr>, <8 x i64> } %4754, 1
  %4757 = extractelement <8 x ptr> %4755, i32 0
  %4758 = extractelement <8 x i64> %4756, i32 %2013
  %4759 = zext i32 %2013 to i64
  %4760 = mul i64 %4759, 4
  %4761 = sub i64 %4758, %4760
  %4762 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4763 = select i1 %4762, i64 %4761, i64 0
  %private.contiguous.address611 = getelementptr i8, ptr %4757, i64 %4763
  %private.contiguous.preserve612 = load <8 x float>, ptr %private.contiguous.address611, align 4
  %4764 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3817, <8 x float> %private.contiguous.preserve612
  store <8 x float> %4764, ptr %private.contiguous.address611, align 4
  %4765 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4766 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4767 = add <8 x i64> %4766, splat (i64 1984)
  %4768 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4765, 0
  %4769 = insertvalue { <8 x ptr>, <8 x i64> } %4768, <8 x i64> %4767, 1
  %4770 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4771 = extractvalue { <8 x ptr>, <8 x i64> } %4769, 1
  %4772 = extractelement <8 x ptr> %4770, i32 0
  %4773 = extractelement <8 x i64> %4771, i32 %2013
  %4774 = zext i32 %2013 to i64
  %4775 = mul i64 %4774, 4
  %4776 = sub i64 %4773, %4775
  %4777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4778 = select i1 %4777, i64 %4776, i64 0
  %private.contiguous.address613 = getelementptr i8, ptr %4772, i64 %4778
  %private.contiguous.preserve614 = load <8 x float>, ptr %private.contiguous.address613, align 4
  %4779 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3820, <8 x float> %private.contiguous.preserve614
  store <8 x float> %4779, ptr %private.contiguous.address613, align 4
  %4780 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4781 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %4782 = add <8 x i64> %4781, splat (i64 2016)
  %4783 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4780, 0
  %4784 = insertvalue { <8 x ptr>, <8 x i64> } %4783, <8 x i64> %4782, 1
  %4785 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %4786 = extractvalue { <8 x ptr>, <8 x i64> } %4784, 1
  %4787 = extractelement <8 x ptr> %4785, i32 0
  %4788 = extractelement <8 x i64> %4786, i32 %2013
  %4789 = zext i32 %2013 to i64
  %4790 = mul i64 %4789, 4
  %4791 = sub i64 %4788, %4790
  %4792 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  %4793 = select i1 %4792, i64 %4791, i64 0
  %private.contiguous.address615 = getelementptr i8, ptr %4787, i64 %4793
  %private.contiguous.preserve616 = load <8 x float>, ptr %private.contiguous.address615, align 4
  %4794 = select <8 x i1> %convergence.cascade.result454, <8 x float> %3823, <8 x float> %private.contiguous.preserve616
  store <8 x float> %4794, ptr %private.contiguous.address615, align 4
  %4795 = load <8 x i64>, ptr %.slot204, align 64
  %4796 = select <8 x i1> %convergence.cascade.result454, <8 x i64> zeroinitializer, <8 x i64> %4795
  store <8 x i64> %4796, ptr %.slot204, align 64
  %4797 = load <8 x float>, ptr %.slot205, align 32
  %4798 = select <8 x i1> %convergence.cascade.result454, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4797
  store <8 x float> %4798, ptr %.slot205, align 32
  store <8 x i1> %convergence.cascade.result454, ptr %current.mask, align 1
  %4799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result454)
  br i1 %4799, label %schedule.21, label %scheduler.loop

varying.divergent618:                             ; preds = %schedule.21
  %4800 = load i32, ptr %current.token, align 4
  %4801 = icmp ne i32 %4800, 0
  %4802 = sub i32 %4800, 1
  %4803 = select i1 %4801, i32 %4802, i32 0
  %4804 = load i8, ptr %frame.active, align 1
  %4805 = trunc i32 %4803 to i8
  %4806 = shl i8 1, %4805
  %4807 = and i8 %4804, %4806
  %4808 = icmp ne i8 %4807, 0
  %4809 = load <8 x i32>, ptr %frame.static.id, align 32
  %4810 = extractelement <8 x i32> %4809, i32 %4803
  %4811 = icmp eq i32 %4810, 8
  %4812 = and i1 %4808, %4811
  %4813 = and i1 %4801, %4812
  %4814 = xor i1 %4813, true
  %4815 = and i1 true, %4814
  %4816 = xor i8 %4804, -1
  %4817 = icmp ne i8 %4816, 0
  %4818 = xor i1 %4817, true
  %4819 = and i1 %4815, %4818
  br i1 %4819, label %convergence.overflow.trap620, label %convergence.overflow.resume621

varying.coherent619:                              ; preds = %schedule.21
  br i1 %436, label %varying.coherent.true624, label %varying.coherent.false625

convergence.overflow.trap620:                     ; preds = %varying.divergent618
  call void @llvm.trap()
  unreachable

convergence.overflow.resume621:                   ; preds = %varying.divergent618
  %4820 = call i8 @llvm.cttz.i8(i8 %4816, i1 false)
  %4821 = zext i8 %4820 to i32
  %4822 = select i1 %4817, i32 %4821, i32 0
  %4823 = trunc i32 %4822 to i8
  %4824 = shl i8 1, %4823
  %4825 = or i8 %4804, %4824
  %4826 = select i1 %4815, i8 %4825, i8 %4804
  store i8 %4826, ptr %frame.active, align 1
  %4827 = load <8 x i32>, ptr %frame.static.id, align 32
  %4828 = extractelement <8 x i32> %4827, i32 %4822
  %4829 = select i1 %4815, i32 8, i32 %4828
  %4830 = load <8 x i32>, ptr %frame.static.id, align 32
  %4831 = insertelement <8 x i32> %4830, i32 %4829, i32 %4822
  store <8 x i32> %4831, ptr %frame.static.id, align 32
  %4832 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4833 = extractelement <8 x i32> %4832, i32 %4822
  %4834 = select i1 %4815, i32 %4800, i32 %4833
  %4835 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4836 = insertelement <8 x i32> %4835, i32 %4834, i32 %4822
  store <8 x i32> %4836, ptr %frame.parent.token, align 32
  %4837 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4822
  %4838 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4822
  %4839 = load <8 x i1>, ptr %4837, align 1
  %4840 = load <8 x i1>, ptr %4838, align 1
  %4841 = select i1 %4815, <8 x i1> %426, <8 x i1> %4839
  store <8 x i1> %4841, ptr %4837, align 1
  %4842 = select i1 %4815, <8 x i1> zeroinitializer, <8 x i1> %4840
  store <8 x i1> %4842, ptr %4838, align 1
  %4843 = add i32 %4822, 1
  %4844 = select i1 %4813, i32 %4800, i32 %4843
  %4845 = select i1 true, i32 %4844, i32 %4800
  store i32 %4845, ptr %current.token, align 4
  %4846 = load i32, ptr %current.token, align 4
  %4847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %433)
  %4848 = load i32, ptr %ready.count, align 4
  %4849 = icmp uge i32 %4848, 8
  %4850 = and i1 %4847, %4849
  br i1 %4850, label %ready.overflow.trap622, label %ready.overflow.resume623

ready.overflow.trap622:                           ; preds = %convergence.overflow.resume621
  call void @llvm.trap()
  unreachable

ready.overflow.resume623:                         ; preds = %convergence.overflow.resume621
  %4851 = select i1 %4847, i32 %4848, i32 0
  %4852 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4851
  %4853 = load <8 x i1>, ptr %4852, align 1
  %4854 = select i1 %4847, <8 x i1> %433, <8 x i1> %4853
  store <8 x i1> %4854, ptr %4852, align 1
  %4855 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4851
  %4856 = load i32, ptr %4855, align 4
  %4857 = select i1 %4847, i32 22, i32 %4856
  store i32 %4857, ptr %4855, align 4
  %4858 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4851
  %4859 = load i32, ptr %4858, align 4
  %4860 = select i1 %4847, i32 %4846, i32 %4859
  store i32 %4860, ptr %4858, align 4
  %4861 = add i32 %4848, 1
  %4862 = select i1 %4847, i32 %4861, i32 %4848
  store i32 %4862, ptr %ready.count, align 4
  %4863 = load <8 x i1>, ptr %runnable.mask, align 1
  %4864 = or <8 x i1> %4863, %433
  store <8 x i1> %4864, ptr %runnable.mask, align 1
  store <8 x i1> %435, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true624:                         ; preds = %varying.coherent619
  store <8 x i1> %426, ptr %current.mask, align 1
  %4865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %426)
  br i1 %4865, label %schedule.22, label %scheduler.loop

varying.coherent.false625:                        ; preds = %varying.coherent619
  store <8 x i1> %426, ptr %current.mask, align 1
  %4866 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %426)
  br i1 %4866, label %schedule.23, label %scheduler.loop

convergence.cascade630:                           ; preds = %convergence.cascade630, %schedule.23
  %convergence.cascade.flow634 = phi <8 x i1> [ %466, %schedule.23 ], [ %4909, %convergence.cascade630 ]
  %convergence.cascade.depth635 = phi i32 [ 0, %schedule.23 ], [ %4910, %convergence.cascade630 ]
  %4867 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow634)
  %4868 = load i32, ptr %current.token, align 4
  %4869 = icmp ne i32 %4868, 0
  %4870 = and i1 %4867, %4869
  %4871 = sub i32 %4868, 1
  %4872 = select i1 %4870, i32 %4871, i32 0
  %4873 = load i8, ptr %frame.active, align 1
  %4874 = trunc i32 %4872 to i8
  %4875 = shl i8 1, %4874
  %4876 = and i8 %4873, %4875
  %4877 = icmp ne i8 %4876, 0
  %4878 = load <8 x i32>, ptr %frame.static.id, align 32
  %4879 = extractelement <8 x i32> %4878, i32 %4872
  %convergence.target.pointer636 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %4879
  %convergence.dynamic.target637 = load i32, ptr %convergence.target.pointer636, align 4
  %4880 = icmp eq i32 %convergence.dynamic.target637, 23
  %4881 = and i1 %4877, %4880
  %4882 = and i1 %4870, %4881
  %4883 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4872
  %4884 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4872
  %4885 = load <8 x i1>, ptr %4883, align 1
  %4886 = load <8 x i1>, ptr %4884, align 1
  %4887 = or <8 x i1> %4886, %convergence.cascade.flow634
  %4888 = load <8 x i1>, ptr %live.mask, align 1
  %4889 = and <8 x i1> %4885, %4888
  %4890 = icmp eq <8 x i1> %4887, %4889
  %4891 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4890)
  %4892 = and i1 %4882, %4891
  %4893 = select i1 %4892, <8 x i1> zeroinitializer, <8 x i1> %4887
  %4894 = select i1 %4882, <8 x i1> %4893, <8 x i1> %4886
  store <8 x i1> %4894, ptr %4884, align 1
  %4895 = select i1 %4892, <8 x i1> zeroinitializer, <8 x i1> %4885
  store <8 x i1> %4895, ptr %4883, align 1
  %4896 = trunc i32 %4872 to i8
  %4897 = shl i8 1, %4896
  %4898 = xor i8 %4897, -1
  %4899 = and i8 %4873, %4898
  %4900 = select i1 %4892, i8 %4899, i8 %4873
  store i8 %4900, ptr %frame.active, align 1
  %.splatinsert638 = insertelement <8 x i1> poison, i1 %4882, i64 0
  %.splat639 = shufflevector <8 x i1> %.splatinsert638, <8 x i1> poison, <8 x i32> zeroinitializer
  %4901 = and <8 x i1> %convergence.cascade.flow634, %.splat639
  %4902 = load <8 x i1>, ptr %runnable.mask, align 1
  %4903 = xor <8 x i1> %4901, splat (i1 true)
  %4904 = and <8 x i1> %4902, %4903
  store <8 x i1> %4904, ptr %runnable.mask, align 1
  %.splatinsert640 = insertelement <8 x i1> poison, i1 %4892, i64 0
  %.splat641 = shufflevector <8 x i1> %.splatinsert640, <8 x i1> poison, <8 x i32> zeroinitializer
  %4905 = select <8 x i1> %.splat641, <8 x i1> %4887, <8 x i1> zeroinitializer
  %4906 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4907 = extractelement <8 x i32> %4906, i32 %4872
  %4908 = select i1 %4892, i32 %4907, i32 %4868
  store i32 %4908, ptr %current.token, align 4
  %.splatinsert642 = insertelement <8 x i1> poison, i1 %4882, i64 0
  %.splat643 = shufflevector <8 x i1> %.splatinsert642, <8 x i1> poison, <8 x i32> zeroinitializer
  %4909 = select <8 x i1> %.splat643, <8 x i1> %4905, <8 x i1> %convergence.cascade.flow634
  %4910 = add i32 %convergence.cascade.depth635, 1
  %4911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4909)
  %4912 = icmp ult i32 %4910, 8
  %4913 = and i1 %4911, %4912
  %4914 = and i1 %4882, %4913
  %convergence.parent.token644 = load i32, ptr %current.token, align 4
  %convergence.parent.present645 = icmp ne i32 %convergence.parent.token644, 0
  %4915 = and i1 %4914, %convergence.parent.present645
  br i1 %4915, label %convergence.cascade630, label %convergence.cascade.exit631

convergence.cascade.exit631:                      ; preds = %convergence.cascade630, %schedule.23
  %convergence.cascade.result646 = phi <8 x i1> [ %466, %schedule.23 ], [ %4909, %convergence.cascade630 ]
  %4916 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result646)
  br i1 %4916, label %convergence.target.23.ready, label %scheduler.loop

convergence.target.23.ready:                      ; preds = %convergence.cascade.exit631
  %4917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result646)
  %4918 = bitcast <8 x i1> %convergence.cascade.result646 to i8
  %4919 = call i8 @llvm.cttz.i8(i8 %4918, i1 false)
  %4920 = zext i8 %4919 to i32
  %4921 = select i1 %4917, i32 %4920, i32 0
  %4922 = load <8 x i64>, ptr %.slot206, align 64
  %4923 = select <8 x i1> %convergence.cascade.result646, <8 x i64> zeroinitializer, <8 x i64> %4922
  store <8 x i64> %4923, ptr %.slot206, align 64
  %4924 = load <8 x float>, ptr %.slot207, align 32
  %4925 = select <8 x i1> %convergence.cascade.result646, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %4924
  store <8 x float> %4925, ptr %.slot207, align 32
  store <8 x i1> %convergence.cascade.result646, ptr %current.mask, align 1
  %4926 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result646)
  br i1 %4926, label %schedule.24, label %scheduler.loop

varying.divergent648:                             ; preds = %schedule.24
  %4927 = load i32, ptr %current.token, align 4
  %4928 = icmp ne i32 %4927, 0
  %4929 = sub i32 %4927, 1
  %4930 = select i1 %4928, i32 %4929, i32 0
  %4931 = load i8, ptr %frame.active, align 1
  %4932 = trunc i32 %4930 to i8
  %4933 = shl i8 1, %4932
  %4934 = and i8 %4931, %4933
  %4935 = icmp ne i8 %4934, 0
  %4936 = load <8 x i32>, ptr %frame.static.id, align 32
  %4937 = extractelement <8 x i32> %4936, i32 %4930
  %4938 = icmp eq i32 %4937, 9
  %4939 = and i1 %4935, %4938
  %4940 = and i1 %4928, %4939
  %4941 = xor i1 %4940, true
  %4942 = and i1 true, %4941
  %4943 = xor i8 %4931, -1
  %4944 = icmp ne i8 %4943, 0
  %4945 = xor i1 %4944, true
  %4946 = and i1 %4942, %4945
  br i1 %4946, label %convergence.overflow.trap650, label %convergence.overflow.resume651

varying.coherent649:                              ; preds = %schedule.24
  br i1 %477, label %varying.coherent.true654, label %varying.coherent.false655

convergence.overflow.trap650:                     ; preds = %varying.divergent648
  call void @llvm.trap()
  unreachable

convergence.overflow.resume651:                   ; preds = %varying.divergent648
  %4947 = call i8 @llvm.cttz.i8(i8 %4943, i1 false)
  %4948 = zext i8 %4947 to i32
  %4949 = select i1 %4944, i32 %4948, i32 0
  %4950 = trunc i32 %4949 to i8
  %4951 = shl i8 1, %4950
  %4952 = or i8 %4931, %4951
  %4953 = select i1 %4942, i8 %4952, i8 %4931
  store i8 %4953, ptr %frame.active, align 1
  %4954 = load <8 x i32>, ptr %frame.static.id, align 32
  %4955 = extractelement <8 x i32> %4954, i32 %4949
  %4956 = select i1 %4942, i32 9, i32 %4955
  %4957 = load <8 x i32>, ptr %frame.static.id, align 32
  %4958 = insertelement <8 x i32> %4957, i32 %4956, i32 %4949
  store <8 x i32> %4958, ptr %frame.static.id, align 32
  %4959 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4960 = extractelement <8 x i32> %4959, i32 %4949
  %4961 = select i1 %4942, i32 %4927, i32 %4960
  %4962 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4963 = insertelement <8 x i32> %4962, i32 %4961, i32 %4949
  store <8 x i32> %4963, ptr %frame.parent.token, align 32
  %4964 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4949
  %4965 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4949
  %4966 = load <8 x i1>, ptr %4964, align 1
  %4967 = load <8 x i1>, ptr %4965, align 1
  %4968 = select i1 %4942, <8 x i1> %467, <8 x i1> %4966
  store <8 x i1> %4968, ptr %4964, align 1
  %4969 = select i1 %4942, <8 x i1> zeroinitializer, <8 x i1> %4967
  store <8 x i1> %4969, ptr %4965, align 1
  %4970 = add i32 %4949, 1
  %4971 = select i1 %4940, i32 %4927, i32 %4970
  %4972 = select i1 true, i32 %4971, i32 %4927
  store i32 %4972, ptr %current.token, align 4
  %4973 = load i32, ptr %current.token, align 4
  %4974 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %474)
  %4975 = load i32, ptr %ready.count, align 4
  %4976 = icmp uge i32 %4975, 8
  %4977 = and i1 %4974, %4976
  br i1 %4977, label %ready.overflow.trap652, label %ready.overflow.resume653

ready.overflow.trap652:                           ; preds = %convergence.overflow.resume651
  call void @llvm.trap()
  unreachable

ready.overflow.resume653:                         ; preds = %convergence.overflow.resume651
  %4978 = select i1 %4974, i32 %4975, i32 0
  %4979 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4978
  %4980 = load <8 x i1>, ptr %4979, align 1
  %4981 = select i1 %4974, <8 x i1> %474, <8 x i1> %4980
  store <8 x i1> %4981, ptr %4979, align 1
  %4982 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4978
  %4983 = load i32, ptr %4982, align 4
  %4984 = select i1 %4974, i32 25, i32 %4983
  store i32 %4984, ptr %4982, align 4
  %4985 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4978
  %4986 = load i32, ptr %4985, align 4
  %4987 = select i1 %4974, i32 %4973, i32 %4986
  store i32 %4987, ptr %4985, align 4
  %4988 = add i32 %4975, 1
  %4989 = select i1 %4974, i32 %4988, i32 %4975
  store i32 %4989, ptr %ready.count, align 4
  %4990 = load <8 x i1>, ptr %runnable.mask, align 1
  %4991 = or <8 x i1> %4990, %474
  store <8 x i1> %4991, ptr %runnable.mask, align 1
  store <8 x i1> %476, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true654:                         ; preds = %varying.coherent649
  store <8 x i1> %467, ptr %current.mask, align 1
  %4992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %467)
  br i1 %4992, label %schedule.25, label %scheduler.loop

varying.coherent.false655:                        ; preds = %varying.coherent649
  store <8 x i1> %467, ptr %current.mask, align 1
  %4993 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %467)
  br i1 %4993, label %schedule.26, label %scheduler.loop

convergence.cascade660:                           ; preds = %convergence.cascade660, %schedule.26
  %convergence.cascade.flow664 = phi <8 x i1> [ %507, %schedule.26 ], [ %5036, %convergence.cascade660 ]
  %convergence.cascade.depth665 = phi i32 [ 0, %schedule.26 ], [ %5037, %convergence.cascade660 ]
  %4994 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow664)
  %4995 = load i32, ptr %current.token, align 4
  %4996 = icmp ne i32 %4995, 0
  %4997 = and i1 %4994, %4996
  %4998 = sub i32 %4995, 1
  %4999 = select i1 %4997, i32 %4998, i32 0
  %5000 = load i8, ptr %frame.active, align 1
  %5001 = trunc i32 %4999 to i8
  %5002 = shl i8 1, %5001
  %5003 = and i8 %5000, %5002
  %5004 = icmp ne i8 %5003, 0
  %5005 = load <8 x i32>, ptr %frame.static.id, align 32
  %5006 = extractelement <8 x i32> %5005, i32 %4999
  %convergence.target.pointer666 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %5006
  %convergence.dynamic.target667 = load i32, ptr %convergence.target.pointer666, align 4
  %5007 = icmp eq i32 %convergence.dynamic.target667, 26
  %5008 = and i1 %5004, %5007
  %5009 = and i1 %4997, %5008
  %5010 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4999
  %5011 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4999
  %5012 = load <8 x i1>, ptr %5010, align 1
  %5013 = load <8 x i1>, ptr %5011, align 1
  %5014 = or <8 x i1> %5013, %convergence.cascade.flow664
  %5015 = load <8 x i1>, ptr %live.mask, align 1
  %5016 = and <8 x i1> %5012, %5015
  %5017 = icmp eq <8 x i1> %5014, %5016
  %5018 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5017)
  %5019 = and i1 %5009, %5018
  %5020 = select i1 %5019, <8 x i1> zeroinitializer, <8 x i1> %5014
  %5021 = select i1 %5009, <8 x i1> %5020, <8 x i1> %5013
  store <8 x i1> %5021, ptr %5011, align 1
  %5022 = select i1 %5019, <8 x i1> zeroinitializer, <8 x i1> %5012
  store <8 x i1> %5022, ptr %5010, align 1
  %5023 = trunc i32 %4999 to i8
  %5024 = shl i8 1, %5023
  %5025 = xor i8 %5024, -1
  %5026 = and i8 %5000, %5025
  %5027 = select i1 %5019, i8 %5026, i8 %5000
  store i8 %5027, ptr %frame.active, align 1
  %.splatinsert668 = insertelement <8 x i1> poison, i1 %5009, i64 0
  %.splat669 = shufflevector <8 x i1> %.splatinsert668, <8 x i1> poison, <8 x i32> zeroinitializer
  %5028 = and <8 x i1> %convergence.cascade.flow664, %.splat669
  %5029 = load <8 x i1>, ptr %runnable.mask, align 1
  %5030 = xor <8 x i1> %5028, splat (i1 true)
  %5031 = and <8 x i1> %5029, %5030
  store <8 x i1> %5031, ptr %runnable.mask, align 1
  %.splatinsert670 = insertelement <8 x i1> poison, i1 %5019, i64 0
  %.splat671 = shufflevector <8 x i1> %.splatinsert670, <8 x i1> poison, <8 x i32> zeroinitializer
  %5032 = select <8 x i1> %.splat671, <8 x i1> %5014, <8 x i1> zeroinitializer
  %5033 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5034 = extractelement <8 x i32> %5033, i32 %4999
  %5035 = select i1 %5019, i32 %5034, i32 %4995
  store i32 %5035, ptr %current.token, align 4
  %.splatinsert672 = insertelement <8 x i1> poison, i1 %5009, i64 0
  %.splat673 = shufflevector <8 x i1> %.splatinsert672, <8 x i1> poison, <8 x i32> zeroinitializer
  %5036 = select <8 x i1> %.splat673, <8 x i1> %5032, <8 x i1> %convergence.cascade.flow664
  %5037 = add i32 %convergence.cascade.depth665, 1
  %5038 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5036)
  %5039 = icmp ult i32 %5037, 8
  %5040 = and i1 %5038, %5039
  %5041 = and i1 %5009, %5040
  %convergence.parent.token674 = load i32, ptr %current.token, align 4
  %convergence.parent.present675 = icmp ne i32 %convergence.parent.token674, 0
  %5042 = and i1 %5041, %convergence.parent.present675
  br i1 %5042, label %convergence.cascade660, label %convergence.cascade.exit661

convergence.cascade.exit661:                      ; preds = %convergence.cascade660, %schedule.26
  %convergence.cascade.result676 = phi <8 x i1> [ %507, %schedule.26 ], [ %5036, %convergence.cascade660 ]
  %5043 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result676)
  br i1 %5043, label %convergence.target.26.ready, label %scheduler.loop

convergence.target.26.ready:                      ; preds = %convergence.cascade.exit661
  %5044 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result676)
  %5045 = bitcast <8 x i1> %convergence.cascade.result676 to i8
  %5046 = call i8 @llvm.cttz.i8(i8 %5045, i1 false)
  %5047 = zext i8 %5046 to i32
  %5048 = select i1 %5044, i32 %5047, i32 0
  %5049 = load <8 x i64>, ptr %.slot208, align 64
  %5050 = select <8 x i1> %convergence.cascade.result676, <8 x i64> zeroinitializer, <8 x i64> %5049
  store <8 x i64> %5050, ptr %.slot208, align 64
  %5051 = load <8 x float>, ptr %.slot209, align 32
  %5052 = select <8 x i1> %convergence.cascade.result676, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %5051
  store <8 x float> %5052, ptr %.slot209, align 32
  store <8 x i1> %convergence.cascade.result676, ptr %current.mask, align 1
  %5053 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result676)
  br i1 %5053, label %schedule.27, label %scheduler.loop

varying.divergent678:                             ; preds = %schedule.27
  %5054 = load i32, ptr %current.token, align 4
  %5055 = icmp ne i32 %5054, 0
  %5056 = sub i32 %5054, 1
  %5057 = select i1 %5055, i32 %5056, i32 0
  %5058 = load i8, ptr %frame.active, align 1
  %5059 = trunc i32 %5057 to i8
  %5060 = shl i8 1, %5059
  %5061 = and i8 %5058, %5060
  %5062 = icmp ne i8 %5061, 0
  %5063 = load <8 x i32>, ptr %frame.static.id, align 32
  %5064 = extractelement <8 x i32> %5063, i32 %5057
  %5065 = icmp eq i32 %5064, 10
  %5066 = and i1 %5062, %5065
  %5067 = and i1 %5055, %5066
  %5068 = xor i1 %5067, true
  %5069 = and i1 true, %5068
  %5070 = xor i8 %5058, -1
  %5071 = icmp ne i8 %5070, 0
  %5072 = xor i1 %5071, true
  %5073 = and i1 %5069, %5072
  br i1 %5073, label %convergence.overflow.trap680, label %convergence.overflow.resume681

varying.coherent679:                              ; preds = %schedule.27
  br i1 %518, label %varying.coherent.true684, label %varying.coherent.false685

convergence.overflow.trap680:                     ; preds = %varying.divergent678
  call void @llvm.trap()
  unreachable

convergence.overflow.resume681:                   ; preds = %varying.divergent678
  %5074 = call i8 @llvm.cttz.i8(i8 %5070, i1 false)
  %5075 = zext i8 %5074 to i32
  %5076 = select i1 %5071, i32 %5075, i32 0
  %5077 = trunc i32 %5076 to i8
  %5078 = shl i8 1, %5077
  %5079 = or i8 %5058, %5078
  %5080 = select i1 %5069, i8 %5079, i8 %5058
  store i8 %5080, ptr %frame.active, align 1
  %5081 = load <8 x i32>, ptr %frame.static.id, align 32
  %5082 = extractelement <8 x i32> %5081, i32 %5076
  %5083 = select i1 %5069, i32 10, i32 %5082
  %5084 = load <8 x i32>, ptr %frame.static.id, align 32
  %5085 = insertelement <8 x i32> %5084, i32 %5083, i32 %5076
  store <8 x i32> %5085, ptr %frame.static.id, align 32
  %5086 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5087 = extractelement <8 x i32> %5086, i32 %5076
  %5088 = select i1 %5069, i32 %5054, i32 %5087
  %5089 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5090 = insertelement <8 x i32> %5089, i32 %5088, i32 %5076
  store <8 x i32> %5090, ptr %frame.parent.token, align 32
  %5091 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5076
  %5092 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5076
  %5093 = load <8 x i1>, ptr %5091, align 1
  %5094 = load <8 x i1>, ptr %5092, align 1
  %5095 = select i1 %5069, <8 x i1> %508, <8 x i1> %5093
  store <8 x i1> %5095, ptr %5091, align 1
  %5096 = select i1 %5069, <8 x i1> zeroinitializer, <8 x i1> %5094
  store <8 x i1> %5096, ptr %5092, align 1
  %5097 = add i32 %5076, 1
  %5098 = select i1 %5067, i32 %5054, i32 %5097
  %5099 = select i1 true, i32 %5098, i32 %5054
  store i32 %5099, ptr %current.token, align 4
  %5100 = load i32, ptr %current.token, align 4
  %5101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %515)
  %5102 = load i32, ptr %ready.count, align 4
  %5103 = icmp uge i32 %5102, 8
  %5104 = and i1 %5101, %5103
  br i1 %5104, label %ready.overflow.trap682, label %ready.overflow.resume683

ready.overflow.trap682:                           ; preds = %convergence.overflow.resume681
  call void @llvm.trap()
  unreachable

ready.overflow.resume683:                         ; preds = %convergence.overflow.resume681
  %5105 = select i1 %5101, i32 %5102, i32 0
  %5106 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5105
  %5107 = load <8 x i1>, ptr %5106, align 1
  %5108 = select i1 %5101, <8 x i1> %515, <8 x i1> %5107
  store <8 x i1> %5108, ptr %5106, align 1
  %5109 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5105
  %5110 = load i32, ptr %5109, align 4
  %5111 = select i1 %5101, i32 28, i32 %5110
  store i32 %5111, ptr %5109, align 4
  %5112 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5105
  %5113 = load i32, ptr %5112, align 4
  %5114 = select i1 %5101, i32 %5100, i32 %5113
  store i32 %5114, ptr %5112, align 4
  %5115 = add i32 %5102, 1
  %5116 = select i1 %5101, i32 %5115, i32 %5102
  store i32 %5116, ptr %ready.count, align 4
  %5117 = load <8 x i1>, ptr %runnable.mask, align 1
  %5118 = or <8 x i1> %5117, %515
  store <8 x i1> %5118, ptr %runnable.mask, align 1
  store <8 x i1> %517, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true684:                         ; preds = %varying.coherent679
  store <8 x i1> %508, ptr %current.mask, align 1
  %5119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %508)
  br i1 %5119, label %schedule.28, label %scheduler.loop

varying.coherent.false685:                        ; preds = %varying.coherent679
  store <8 x i1> %508, ptr %current.mask, align 1
  %5120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %508)
  br i1 %5120, label %schedule.29, label %scheduler.loop

convergence.cascade690:                           ; preds = %convergence.cascade690, %schedule.29
  %convergence.cascade.flow694 = phi <8 x i1> [ %548, %schedule.29 ], [ %5163, %convergence.cascade690 ]
  %convergence.cascade.depth695 = phi i32 [ 0, %schedule.29 ], [ %5164, %convergence.cascade690 ]
  %5121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow694)
  %5122 = load i32, ptr %current.token, align 4
  %5123 = icmp ne i32 %5122, 0
  %5124 = and i1 %5121, %5123
  %5125 = sub i32 %5122, 1
  %5126 = select i1 %5124, i32 %5125, i32 0
  %5127 = load i8, ptr %frame.active, align 1
  %5128 = trunc i32 %5126 to i8
  %5129 = shl i8 1, %5128
  %5130 = and i8 %5127, %5129
  %5131 = icmp ne i8 %5130, 0
  %5132 = load <8 x i32>, ptr %frame.static.id, align 32
  %5133 = extractelement <8 x i32> %5132, i32 %5126
  %convergence.target.pointer696 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %5133
  %convergence.dynamic.target697 = load i32, ptr %convergence.target.pointer696, align 4
  %5134 = icmp eq i32 %convergence.dynamic.target697, 29
  %5135 = and i1 %5131, %5134
  %5136 = and i1 %5124, %5135
  %5137 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5126
  %5138 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5126
  %5139 = load <8 x i1>, ptr %5137, align 1
  %5140 = load <8 x i1>, ptr %5138, align 1
  %5141 = or <8 x i1> %5140, %convergence.cascade.flow694
  %5142 = load <8 x i1>, ptr %live.mask, align 1
  %5143 = and <8 x i1> %5139, %5142
  %5144 = icmp eq <8 x i1> %5141, %5143
  %5145 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5144)
  %5146 = and i1 %5136, %5145
  %5147 = select i1 %5146, <8 x i1> zeroinitializer, <8 x i1> %5141
  %5148 = select i1 %5136, <8 x i1> %5147, <8 x i1> %5140
  store <8 x i1> %5148, ptr %5138, align 1
  %5149 = select i1 %5146, <8 x i1> zeroinitializer, <8 x i1> %5139
  store <8 x i1> %5149, ptr %5137, align 1
  %5150 = trunc i32 %5126 to i8
  %5151 = shl i8 1, %5150
  %5152 = xor i8 %5151, -1
  %5153 = and i8 %5127, %5152
  %5154 = select i1 %5146, i8 %5153, i8 %5127
  store i8 %5154, ptr %frame.active, align 1
  %.splatinsert698 = insertelement <8 x i1> poison, i1 %5136, i64 0
  %.splat699 = shufflevector <8 x i1> %.splatinsert698, <8 x i1> poison, <8 x i32> zeroinitializer
  %5155 = and <8 x i1> %convergence.cascade.flow694, %.splat699
  %5156 = load <8 x i1>, ptr %runnable.mask, align 1
  %5157 = xor <8 x i1> %5155, splat (i1 true)
  %5158 = and <8 x i1> %5156, %5157
  store <8 x i1> %5158, ptr %runnable.mask, align 1
  %.splatinsert700 = insertelement <8 x i1> poison, i1 %5146, i64 0
  %.splat701 = shufflevector <8 x i1> %.splatinsert700, <8 x i1> poison, <8 x i32> zeroinitializer
  %5159 = select <8 x i1> %.splat701, <8 x i1> %5141, <8 x i1> zeroinitializer
  %5160 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5161 = extractelement <8 x i32> %5160, i32 %5126
  %5162 = select i1 %5146, i32 %5161, i32 %5122
  store i32 %5162, ptr %current.token, align 4
  %.splatinsert702 = insertelement <8 x i1> poison, i1 %5136, i64 0
  %.splat703 = shufflevector <8 x i1> %.splatinsert702, <8 x i1> poison, <8 x i32> zeroinitializer
  %5163 = select <8 x i1> %.splat703, <8 x i1> %5159, <8 x i1> %convergence.cascade.flow694
  %5164 = add i32 %convergence.cascade.depth695, 1
  %5165 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5163)
  %5166 = icmp ult i32 %5164, 8
  %5167 = and i1 %5165, %5166
  %5168 = and i1 %5136, %5167
  %convergence.parent.token704 = load i32, ptr %current.token, align 4
  %convergence.parent.present705 = icmp ne i32 %convergence.parent.token704, 0
  %5169 = and i1 %5168, %convergence.parent.present705
  br i1 %5169, label %convergence.cascade690, label %convergence.cascade.exit691

convergence.cascade.exit691:                      ; preds = %convergence.cascade690, %schedule.29
  %convergence.cascade.result706 = phi <8 x i1> [ %548, %schedule.29 ], [ %5163, %convergence.cascade690 ]
  %5170 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result706)
  br i1 %5170, label %convergence.target.29.ready, label %scheduler.loop

convergence.target.29.ready:                      ; preds = %convergence.cascade.exit691
  %5171 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result706)
  %5172 = bitcast <8 x i1> %convergence.cascade.result706 to i8
  %5173 = call i8 @llvm.cttz.i8(i8 %5172, i1 false)
  %5174 = zext i8 %5173 to i32
  %5175 = select i1 %5171, i32 %5174, i32 0
  %5176 = load <8 x i64>, ptr %.slot210, align 64
  %5177 = select <8 x i1> %convergence.cascade.result706, <8 x i64> zeroinitializer, <8 x i64> %5176
  store <8 x i64> %5177, ptr %.slot210, align 64
  %5178 = load <8 x float>, ptr %.slot211, align 32
  %5179 = select <8 x i1> %convergence.cascade.result706, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %5178
  store <8 x float> %5179, ptr %.slot211, align 32
  store <8 x i1> %convergence.cascade.result706, ptr %current.mask, align 1
  %5180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result706)
  br i1 %5180, label %schedule.30, label %scheduler.loop

varying.divergent708:                             ; preds = %schedule.30
  %5181 = load i32, ptr %current.token, align 4
  %5182 = icmp ne i32 %5181, 0
  %5183 = sub i32 %5181, 1
  %5184 = select i1 %5182, i32 %5183, i32 0
  %5185 = load i8, ptr %frame.active, align 1
  %5186 = trunc i32 %5184 to i8
  %5187 = shl i8 1, %5186
  %5188 = and i8 %5185, %5187
  %5189 = icmp ne i8 %5188, 0
  %5190 = load <8 x i32>, ptr %frame.static.id, align 32
  %5191 = extractelement <8 x i32> %5190, i32 %5184
  %5192 = icmp eq i32 %5191, 11
  %5193 = and i1 %5189, %5192
  %5194 = and i1 %5182, %5193
  %5195 = xor i1 %5194, true
  %5196 = and i1 true, %5195
  %5197 = xor i8 %5185, -1
  %5198 = icmp ne i8 %5197, 0
  %5199 = xor i1 %5198, true
  %5200 = and i1 %5196, %5199
  br i1 %5200, label %convergence.overflow.trap710, label %convergence.overflow.resume711

varying.coherent709:                              ; preds = %schedule.30
  br i1 %559, label %varying.coherent.true714, label %varying.coherent.false715

convergence.overflow.trap710:                     ; preds = %varying.divergent708
  call void @llvm.trap()
  unreachable

convergence.overflow.resume711:                   ; preds = %varying.divergent708
  %5201 = call i8 @llvm.cttz.i8(i8 %5197, i1 false)
  %5202 = zext i8 %5201 to i32
  %5203 = select i1 %5198, i32 %5202, i32 0
  %5204 = trunc i32 %5203 to i8
  %5205 = shl i8 1, %5204
  %5206 = or i8 %5185, %5205
  %5207 = select i1 %5196, i8 %5206, i8 %5185
  store i8 %5207, ptr %frame.active, align 1
  %5208 = load <8 x i32>, ptr %frame.static.id, align 32
  %5209 = extractelement <8 x i32> %5208, i32 %5203
  %5210 = select i1 %5196, i32 11, i32 %5209
  %5211 = load <8 x i32>, ptr %frame.static.id, align 32
  %5212 = insertelement <8 x i32> %5211, i32 %5210, i32 %5203
  store <8 x i32> %5212, ptr %frame.static.id, align 32
  %5213 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5214 = extractelement <8 x i32> %5213, i32 %5203
  %5215 = select i1 %5196, i32 %5181, i32 %5214
  %5216 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5217 = insertelement <8 x i32> %5216, i32 %5215, i32 %5203
  store <8 x i32> %5217, ptr %frame.parent.token, align 32
  %5218 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5203
  %5219 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5203
  %5220 = load <8 x i1>, ptr %5218, align 1
  %5221 = load <8 x i1>, ptr %5219, align 1
  %5222 = select i1 %5196, <8 x i1> %549, <8 x i1> %5220
  store <8 x i1> %5222, ptr %5218, align 1
  %5223 = select i1 %5196, <8 x i1> zeroinitializer, <8 x i1> %5221
  store <8 x i1> %5223, ptr %5219, align 1
  %5224 = add i32 %5203, 1
  %5225 = select i1 %5194, i32 %5181, i32 %5224
  %5226 = select i1 true, i32 %5225, i32 %5181
  store i32 %5226, ptr %current.token, align 4
  %5227 = load i32, ptr %current.token, align 4
  %5228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %556)
  %5229 = load i32, ptr %ready.count, align 4
  %5230 = icmp uge i32 %5229, 8
  %5231 = and i1 %5228, %5230
  br i1 %5231, label %ready.overflow.trap712, label %ready.overflow.resume713

ready.overflow.trap712:                           ; preds = %convergence.overflow.resume711
  call void @llvm.trap()
  unreachable

ready.overflow.resume713:                         ; preds = %convergence.overflow.resume711
  %5232 = select i1 %5228, i32 %5229, i32 0
  %5233 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5232
  %5234 = load <8 x i1>, ptr %5233, align 1
  %5235 = select i1 %5228, <8 x i1> %556, <8 x i1> %5234
  store <8 x i1> %5235, ptr %5233, align 1
  %5236 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5232
  %5237 = load i32, ptr %5236, align 4
  %5238 = select i1 %5228, i32 31, i32 %5237
  store i32 %5238, ptr %5236, align 4
  %5239 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5232
  %5240 = load i32, ptr %5239, align 4
  %5241 = select i1 %5228, i32 %5227, i32 %5240
  store i32 %5241, ptr %5239, align 4
  %5242 = add i32 %5229, 1
  %5243 = select i1 %5228, i32 %5242, i32 %5229
  store i32 %5243, ptr %ready.count, align 4
  %5244 = load <8 x i1>, ptr %runnable.mask, align 1
  %5245 = or <8 x i1> %5244, %556
  store <8 x i1> %5245, ptr %runnable.mask, align 1
  store <8 x i1> %558, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true714:                         ; preds = %varying.coherent709
  store <8 x i1> %549, ptr %current.mask, align 1
  %5246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %549)
  br i1 %5246, label %schedule.31, label %scheduler.loop

varying.coherent.false715:                        ; preds = %varying.coherent709
  store <8 x i1> %549, ptr %current.mask, align 1
  %5247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %549)
  br i1 %5247, label %schedule.32, label %scheduler.loop

convergence.cascade720:                           ; preds = %convergence.cascade720, %schedule.32
  %convergence.cascade.flow724 = phi <8 x i1> [ %589, %schedule.32 ], [ %5290, %convergence.cascade720 ]
  %convergence.cascade.depth725 = phi i32 [ 0, %schedule.32 ], [ %5291, %convergence.cascade720 ]
  %5248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow724)
  %5249 = load i32, ptr %current.token, align 4
  %5250 = icmp ne i32 %5249, 0
  %5251 = and i1 %5248, %5250
  %5252 = sub i32 %5249, 1
  %5253 = select i1 %5251, i32 %5252, i32 0
  %5254 = load i8, ptr %frame.active, align 1
  %5255 = trunc i32 %5253 to i8
  %5256 = shl i8 1, %5255
  %5257 = and i8 %5254, %5256
  %5258 = icmp ne i8 %5257, 0
  %5259 = load <8 x i32>, ptr %frame.static.id, align 32
  %5260 = extractelement <8 x i32> %5259, i32 %5253
  %convergence.target.pointer726 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %5260
  %convergence.dynamic.target727 = load i32, ptr %convergence.target.pointer726, align 4
  %5261 = icmp eq i32 %convergence.dynamic.target727, 32
  %5262 = and i1 %5258, %5261
  %5263 = and i1 %5251, %5262
  %5264 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5253
  %5265 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5253
  %5266 = load <8 x i1>, ptr %5264, align 1
  %5267 = load <8 x i1>, ptr %5265, align 1
  %5268 = or <8 x i1> %5267, %convergence.cascade.flow724
  %5269 = load <8 x i1>, ptr %live.mask, align 1
  %5270 = and <8 x i1> %5266, %5269
  %5271 = icmp eq <8 x i1> %5268, %5270
  %5272 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5271)
  %5273 = and i1 %5263, %5272
  %5274 = select i1 %5273, <8 x i1> zeroinitializer, <8 x i1> %5268
  %5275 = select i1 %5263, <8 x i1> %5274, <8 x i1> %5267
  store <8 x i1> %5275, ptr %5265, align 1
  %5276 = select i1 %5273, <8 x i1> zeroinitializer, <8 x i1> %5266
  store <8 x i1> %5276, ptr %5264, align 1
  %5277 = trunc i32 %5253 to i8
  %5278 = shl i8 1, %5277
  %5279 = xor i8 %5278, -1
  %5280 = and i8 %5254, %5279
  %5281 = select i1 %5273, i8 %5280, i8 %5254
  store i8 %5281, ptr %frame.active, align 1
  %.splatinsert728 = insertelement <8 x i1> poison, i1 %5263, i64 0
  %.splat729 = shufflevector <8 x i1> %.splatinsert728, <8 x i1> poison, <8 x i32> zeroinitializer
  %5282 = and <8 x i1> %convergence.cascade.flow724, %.splat729
  %5283 = load <8 x i1>, ptr %runnable.mask, align 1
  %5284 = xor <8 x i1> %5282, splat (i1 true)
  %5285 = and <8 x i1> %5283, %5284
  store <8 x i1> %5285, ptr %runnable.mask, align 1
  %.splatinsert730 = insertelement <8 x i1> poison, i1 %5273, i64 0
  %.splat731 = shufflevector <8 x i1> %.splatinsert730, <8 x i1> poison, <8 x i32> zeroinitializer
  %5286 = select <8 x i1> %.splat731, <8 x i1> %5268, <8 x i1> zeroinitializer
  %5287 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5288 = extractelement <8 x i32> %5287, i32 %5253
  %5289 = select i1 %5273, i32 %5288, i32 %5249
  store i32 %5289, ptr %current.token, align 4
  %.splatinsert732 = insertelement <8 x i1> poison, i1 %5263, i64 0
  %.splat733 = shufflevector <8 x i1> %.splatinsert732, <8 x i1> poison, <8 x i32> zeroinitializer
  %5290 = select <8 x i1> %.splat733, <8 x i1> %5286, <8 x i1> %convergence.cascade.flow724
  %5291 = add i32 %convergence.cascade.depth725, 1
  %5292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5290)
  %5293 = icmp ult i32 %5291, 8
  %5294 = and i1 %5292, %5293
  %5295 = and i1 %5263, %5294
  %convergence.parent.token734 = load i32, ptr %current.token, align 4
  %convergence.parent.present735 = icmp ne i32 %convergence.parent.token734, 0
  %5296 = and i1 %5295, %convergence.parent.present735
  br i1 %5296, label %convergence.cascade720, label %convergence.cascade.exit721

convergence.cascade.exit721:                      ; preds = %convergence.cascade720, %schedule.32
  %convergence.cascade.result736 = phi <8 x i1> [ %589, %schedule.32 ], [ %5290, %convergence.cascade720 ]
  %5297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result736)
  br i1 %5297, label %convergence.target.32.ready, label %scheduler.loop

convergence.target.32.ready:                      ; preds = %convergence.cascade.exit721
  %5298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result736)
  %5299 = bitcast <8 x i1> %convergence.cascade.result736 to i8
  %5300 = call i8 @llvm.cttz.i8(i8 %5299, i1 false)
  %5301 = zext i8 %5300 to i32
  %5302 = select i1 %5298, i32 %5301, i32 0
  %.state737 = load <8 x float>, ptr %.slot58, align 32
  %.state738 = load <8 x float>, ptr %.slot205, align 32
  %5303 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state737, <8 x float> %.state738)
  %5304 = load volatile <8 x float>, ptr %.spill212, align 32
  %5305 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5303, <8 x float> %5304
  store volatile <8 x float> %5305, ptr %.spill212, align 32
  %.state739 = load <8 x float>, ptr %.slot59, align 32
  %.state740 = load <8 x float>, ptr %.slot207, align 32
  %5306 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state739, <8 x float> %.state740)
  %5307 = load volatile <8 x float>, ptr %.spill213, align 32
  %5308 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5306, <8 x float> %5307
  store volatile <8 x float> %5308, ptr %.spill213, align 32
  %.state741 = load <8 x float>, ptr %.slot60, align 32
  %.state742 = load <8 x float>, ptr %.slot209, align 32
  %5309 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state741, <8 x float> %.state742)
  %5310 = load volatile <8 x float>, ptr %.spill214, align 32
  %5311 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5309, <8 x float> %5310
  store volatile <8 x float> %5311, ptr %.spill214, align 32
  %.state743 = load <8 x float>, ptr %.slot61, align 32
  %.state744 = load <8 x float>, ptr %.slot211, align 32
  %5312 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state743, <8 x float> %.state744)
  %5313 = load volatile <8 x float>, ptr %.spill215, align 32
  %5314 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5312, <8 x float> %5313
  store volatile <8 x float> %5314, ptr %.spill215, align 32
  %.state745 = load <8 x float>, ptr %.slot58, align 32
  %5315 = fsub <8 x float> %.state745, %5303
  %.state746 = load <8 x float>, ptr %.slot59, align 32
  %5316 = fsub <8 x float> %.state746, %5306
  %.state747 = load <8 x float>, ptr %.slot60, align 32
  %5317 = fsub <8 x float> %.state747, %5309
  %.state748 = load <8 x float>, ptr %.slot61, align 32
  %5318 = fsub <8 x float> %.state748, %5312
  %5319 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5315, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5319)
  %5320 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5316, <8 x float> zeroinitializer
  %native.exp749 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5320)
  %5321 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5317, <8 x float> zeroinitializer
  %native.exp750 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5321)
  %5322 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5318, <8 x float> zeroinitializer
  %native.exp751 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5322)
  %5323 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill216, align 64
  %5324 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5325 = extractvalue { <8 x ptr>, <8 x i64> } %5323, 0
  %5326 = select <8 x i1> %convergence.cascade.result736, <8 x ptr> %5324, <8 x ptr> %5325
  %5327 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %5328 = extractvalue { <8 x ptr>, <8 x i64> } %5323, 1
  %5329 = select <8 x i1> %convergence.cascade.result736, <8 x i64> %5327, <8 x i64> %5328
  %5330 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5326, 0
  %5331 = insertvalue { <8 x ptr>, <8 x i64> } %5330, <8 x i64> %5329, 1
  store volatile { <8 x ptr>, <8 x i64> } %5331, ptr %tile_snapshot.spill216, align 64
  %5332 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5333 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %5334 = add <8 x i64> %5333, zeroinitializer
  %5335 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5332, 0
  %5336 = insertvalue { <8 x ptr>, <8 x i64> } %5335, <8 x i64> %5334, 1
  %5337 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5338 = extractvalue { <8 x ptr>, <8 x i64> } %5336, 1
  %5339 = extractelement <8 x ptr> %5337, i32 0
  %5340 = extractelement <8 x i64> %5338, i32 %5302
  %5341 = zext i32 %5302 to i64
  %5342 = mul i64 %5341, 4
  %5343 = sub i64 %5340, %5342
  %5344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result736)
  %5345 = select i1 %5344, i64 %5343, i64 0
  %private.contiguous.address752 = getelementptr i8, ptr %5339, i64 %5345
  %private.contiguous.preserve753 = load <8 x float>, ptr %private.contiguous.address752, align 4
  %5346 = select <8 x i1> %convergence.cascade.result736, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve753
  store <8 x float> %5346, ptr %private.contiguous.address752, align 4
  %5347 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5348 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %5349 = add <8 x i64> %5348, splat (i64 32)
  %5350 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5347, 0
  %5351 = insertvalue { <8 x ptr>, <8 x i64> } %5350, <8 x i64> %5349, 1
  %5352 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5353 = extractvalue { <8 x ptr>, <8 x i64> } %5351, 1
  %5354 = extractelement <8 x ptr> %5352, i32 0
  %5355 = extractelement <8 x i64> %5353, i32 %5302
  %5356 = zext i32 %5302 to i64
  %5357 = mul i64 %5356, 4
  %5358 = sub i64 %5355, %5357
  %5359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result736)
  %5360 = select i1 %5359, i64 %5358, i64 0
  %private.contiguous.address754 = getelementptr i8, ptr %5354, i64 %5360
  %private.contiguous.preserve755 = load <8 x float>, ptr %private.contiguous.address754, align 4
  %5361 = select <8 x i1> %convergence.cascade.result736, <8 x float> %native.exp749, <8 x float> %private.contiguous.preserve755
  store <8 x float> %5361, ptr %private.contiguous.address754, align 4
  %5362 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5363 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %5364 = add <8 x i64> %5363, splat (i64 64)
  %5365 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5362, 0
  %5366 = insertvalue { <8 x ptr>, <8 x i64> } %5365, <8 x i64> %5364, 1
  %5367 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5368 = extractvalue { <8 x ptr>, <8 x i64> } %5366, 1
  %5369 = extractelement <8 x ptr> %5367, i32 0
  %5370 = extractelement <8 x i64> %5368, i32 %5302
  %5371 = zext i32 %5302 to i64
  %5372 = mul i64 %5371, 4
  %5373 = sub i64 %5370, %5372
  %5374 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result736)
  %5375 = select i1 %5374, i64 %5373, i64 0
  %private.contiguous.address756 = getelementptr i8, ptr %5369, i64 %5375
  %private.contiguous.preserve757 = load <8 x float>, ptr %private.contiguous.address756, align 4
  %5376 = select <8 x i1> %convergence.cascade.result736, <8 x float> %native.exp750, <8 x float> %private.contiguous.preserve757
  store <8 x float> %5376, ptr %private.contiguous.address756, align 4
  %5377 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5378 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %5379 = add <8 x i64> %5378, splat (i64 96)
  %5380 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5377, 0
  %5381 = insertvalue { <8 x ptr>, <8 x i64> } %5380, <8 x i64> %5379, 1
  %5382 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %5383 = extractvalue { <8 x ptr>, <8 x i64> } %5381, 1
  %5384 = extractelement <8 x ptr> %5382, i32 0
  %5385 = extractelement <8 x i64> %5383, i32 %5302
  %5386 = zext i32 %5302 to i64
  %5387 = mul i64 %5386, 4
  %5388 = sub i64 %5385, %5387
  %5389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result736)
  %5390 = select i1 %5389, i64 %5388, i64 0
  %private.contiguous.address758 = getelementptr i8, ptr %5384, i64 %5390
  %private.contiguous.preserve759 = load <8 x float>, ptr %private.contiguous.address758, align 4
  %5391 = select <8 x i1> %convergence.cascade.result736, <8 x float> %native.exp751, <8 x float> %private.contiguous.preserve759
  store <8 x float> %5391, ptr %private.contiguous.address758, align 4
  %.spill.load760 = load volatile <8 x float>, ptr %.spill139, align 32
  %5392 = fsub <8 x float> %.spill.load760, %5303
  %.spill.load761 = load volatile <8 x float>, ptr %.spill140, align 32
  %5393 = fsub <8 x float> %.spill.load761, %5303
  %.spill.load762 = load volatile <8 x float>, ptr %.spill141, align 32
  %5394 = fsub <8 x float> %.spill.load762, %5303
  %.spill.load763 = load volatile <8 x float>, ptr %.spill142, align 32
  %5395 = fsub <8 x float> %.spill.load763, %5303
  %.spill.load764 = load volatile <8 x float>, ptr %.spill143, align 32
  %5396 = fsub <8 x float> %.spill.load764, %5303
  %.spill.load765 = load volatile <8 x float>, ptr %.spill144, align 32
  %5397 = fsub <8 x float> %.spill.load765, %5303
  %.spill.load766 = load volatile <8 x float>, ptr %.spill145, align 32
  %5398 = fsub <8 x float> %.spill.load766, %5303
  %.spill.load767 = load volatile <8 x float>, ptr %.spill146, align 32
  %5399 = fsub <8 x float> %.spill.load767, %5303
  %.spill.load768 = load volatile <8 x float>, ptr %.spill147, align 32
  %5400 = fsub <8 x float> %.spill.load768, %5303
  %.spill.load769 = load volatile <8 x float>, ptr %.spill148, align 32
  %5401 = fsub <8 x float> %.spill.load769, %5303
  %.spill.load770 = load volatile <8 x float>, ptr %.spill149, align 32
  %5402 = fsub <8 x float> %.spill.load770, %5303
  %.spill.load771 = load volatile <8 x float>, ptr %.spill150, align 32
  %5403 = fsub <8 x float> %.spill.load771, %5303
  %.spill.load772 = load volatile <8 x float>, ptr %.spill151, align 32
  %5404 = fsub <8 x float> %.spill.load772, %5303
  %.spill.load773 = load volatile <8 x float>, ptr %.spill152, align 32
  %5405 = fsub <8 x float> %.spill.load773, %5303
  %.spill.load774 = load volatile <8 x float>, ptr %.spill153, align 32
  %5406 = fsub <8 x float> %.spill.load774, %5303
  %.spill.load775 = load volatile <8 x float>, ptr %.spill154, align 32
  %5407 = fsub <8 x float> %.spill.load775, %5303
  %.spill.load776 = load volatile <8 x float>, ptr %.spill155, align 32
  %5408 = fsub <8 x float> %.spill.load776, %5306
  %.spill.load777 = load volatile <8 x float>, ptr %.spill156, align 32
  %5409 = fsub <8 x float> %.spill.load777, %5306
  %.spill.load778 = load volatile <8 x float>, ptr %.spill157, align 32
  %5410 = fsub <8 x float> %.spill.load778, %5306
  %.spill.load779 = load volatile <8 x float>, ptr %.spill158, align 32
  %5411 = fsub <8 x float> %.spill.load779, %5306
  %.spill.load780 = load volatile <8 x float>, ptr %.spill159, align 32
  %5412 = fsub <8 x float> %.spill.load780, %5306
  %.spill.load781 = load volatile <8 x float>, ptr %.spill160, align 32
  %5413 = fsub <8 x float> %.spill.load781, %5306
  %.spill.load782 = load volatile <8 x float>, ptr %.spill161, align 32
  %5414 = fsub <8 x float> %.spill.load782, %5306
  %.spill.load783 = load volatile <8 x float>, ptr %.spill162, align 32
  %5415 = fsub <8 x float> %.spill.load783, %5306
  %.spill.load784 = load volatile <8 x float>, ptr %.spill163, align 32
  %5416 = fsub <8 x float> %.spill.load784, %5306
  %.spill.load785 = load volatile <8 x float>, ptr %.spill164, align 32
  %5417 = fsub <8 x float> %.spill.load785, %5306
  %.spill.load786 = load volatile <8 x float>, ptr %.spill165, align 32
  %5418 = fsub <8 x float> %.spill.load786, %5306
  %.spill.load787 = load volatile <8 x float>, ptr %.spill166, align 32
  %5419 = fsub <8 x float> %.spill.load787, %5306
  %.spill.load788 = load volatile <8 x float>, ptr %.spill167, align 32
  %5420 = fsub <8 x float> %.spill.load788, %5306
  %.spill.load789 = load volatile <8 x float>, ptr %.spill168, align 32
  %5421 = fsub <8 x float> %.spill.load789, %5306
  %.spill.load790 = load volatile <8 x float>, ptr %.spill169, align 32
  %5422 = fsub <8 x float> %.spill.load790, %5306
  %.spill.load791 = load volatile <8 x float>, ptr %.spill170, align 32
  %5423 = fsub <8 x float> %.spill.load791, %5306
  %.spill.load792 = load volatile <8 x float>, ptr %.spill171, align 32
  %5424 = fsub <8 x float> %.spill.load792, %5309
  %.spill.load793 = load volatile <8 x float>, ptr %.spill172, align 32
  %5425 = fsub <8 x float> %.spill.load793, %5309
  %.spill.load794 = load volatile <8 x float>, ptr %.spill173, align 32
  %5426 = fsub <8 x float> %.spill.load794, %5309
  %.spill.load795 = load volatile <8 x float>, ptr %.spill174, align 32
  %5427 = fsub <8 x float> %.spill.load795, %5309
  %.spill.load796 = load volatile <8 x float>, ptr %.spill175, align 32
  %5428 = fsub <8 x float> %.spill.load796, %5309
  %.spill.load797 = load volatile <8 x float>, ptr %.spill176, align 32
  %5429 = fsub <8 x float> %.spill.load797, %5309
  %.spill.load798 = load volatile <8 x float>, ptr %.spill177, align 32
  %5430 = fsub <8 x float> %.spill.load798, %5309
  %.spill.load799 = load volatile <8 x float>, ptr %.spill178, align 32
  %5431 = fsub <8 x float> %.spill.load799, %5309
  %.spill.load800 = load volatile <8 x float>, ptr %.spill179, align 32
  %5432 = fsub <8 x float> %.spill.load800, %5309
  %.spill.load801 = load volatile <8 x float>, ptr %.spill180, align 32
  %5433 = fsub <8 x float> %.spill.load801, %5309
  %.spill.load802 = load volatile <8 x float>, ptr %.spill181, align 32
  %5434 = fsub <8 x float> %.spill.load802, %5309
  %.spill.load803 = load volatile <8 x float>, ptr %.spill182, align 32
  %5435 = fsub <8 x float> %.spill.load803, %5309
  %.spill.load804 = load volatile <8 x float>, ptr %.spill183, align 32
  %5436 = fsub <8 x float> %.spill.load804, %5309
  %.spill.load805 = load volatile <8 x float>, ptr %.spill184, align 32
  %5437 = fsub <8 x float> %.spill.load805, %5309
  %.spill.load806 = load volatile <8 x float>, ptr %.spill185, align 32
  %5438 = fsub <8 x float> %.spill.load806, %5309
  %.spill.load807 = load volatile <8 x float>, ptr %.spill186, align 32
  %5439 = fsub <8 x float> %.spill.load807, %5309
  %.spill.load808 = load volatile <8 x float>, ptr %.spill187, align 32
  %5440 = fsub <8 x float> %.spill.load808, %5312
  %.spill.load809 = load volatile <8 x float>, ptr %.spill188, align 32
  %5441 = fsub <8 x float> %.spill.load809, %5312
  %.spill.load810 = load volatile <8 x float>, ptr %.spill189, align 32
  %5442 = fsub <8 x float> %.spill.load810, %5312
  %.spill.load811 = load volatile <8 x float>, ptr %.spill190, align 32
  %5443 = fsub <8 x float> %.spill.load811, %5312
  %.spill.load812 = load volatile <8 x float>, ptr %.spill191, align 32
  %5444 = fsub <8 x float> %.spill.load812, %5312
  %.spill.load813 = load volatile <8 x float>, ptr %.spill192, align 32
  %5445 = fsub <8 x float> %.spill.load813, %5312
  %.spill.load814 = load volatile <8 x float>, ptr %.spill193, align 32
  %5446 = fsub <8 x float> %.spill.load814, %5312
  %.spill.load815 = load volatile <8 x float>, ptr %.spill194, align 32
  %5447 = fsub <8 x float> %.spill.load815, %5312
  %.spill.load816 = load volatile <8 x float>, ptr %.spill195, align 32
  %5448 = fsub <8 x float> %.spill.load816, %5312
  %.spill.load817 = load volatile <8 x float>, ptr %.spill196, align 32
  %5449 = fsub <8 x float> %.spill.load817, %5312
  %.spill.load818 = load volatile <8 x float>, ptr %.spill197, align 32
  %5450 = fsub <8 x float> %.spill.load818, %5312
  %.spill.load819 = load volatile <8 x float>, ptr %.spill198, align 32
  %5451 = fsub <8 x float> %.spill.load819, %5312
  %.spill.load820 = load volatile <8 x float>, ptr %.spill199, align 32
  %5452 = fsub <8 x float> %.spill.load820, %5312
  %.spill.load821 = load volatile <8 x float>, ptr %.spill200, align 32
  %5453 = fsub <8 x float> %.spill.load821, %5312
  %.spill.load822 = load volatile <8 x float>, ptr %.spill201, align 32
  %5454 = fsub <8 x float> %.spill.load822, %5312
  %.spill.load823 = load volatile <8 x float>, ptr %.spill202, align 32
  %5455 = fsub <8 x float> %.spill.load823, %5312
  %5456 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5392, <8 x float> zeroinitializer
  %native.exp824 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5456)
  %5457 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5393, <8 x float> zeroinitializer
  %native.exp825 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5457)
  %5458 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5394, <8 x float> zeroinitializer
  %native.exp826 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5458)
  %5459 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5395, <8 x float> zeroinitializer
  %native.exp827 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5459)
  %5460 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5396, <8 x float> zeroinitializer
  %native.exp828 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5460)
  %5461 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5397, <8 x float> zeroinitializer
  %native.exp829 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5461)
  %5462 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5398, <8 x float> zeroinitializer
  %native.exp830 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5462)
  %5463 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5399, <8 x float> zeroinitializer
  %native.exp831 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5463)
  %5464 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5400, <8 x float> zeroinitializer
  %native.exp832 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5464)
  %5465 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5401, <8 x float> zeroinitializer
  %native.exp833 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5465)
  %5466 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5402, <8 x float> zeroinitializer
  %native.exp834 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5466)
  %5467 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5403, <8 x float> zeroinitializer
  %native.exp835 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5467)
  %5468 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5404, <8 x float> zeroinitializer
  %native.exp836 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5468)
  %5469 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5405, <8 x float> zeroinitializer
  %native.exp837 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5469)
  %5470 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5406, <8 x float> zeroinitializer
  %native.exp838 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5470)
  %5471 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5407, <8 x float> zeroinitializer
  %native.exp839 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5471)
  %5472 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5408, <8 x float> zeroinitializer
  %native.exp840 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5472)
  %5473 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5409, <8 x float> zeroinitializer
  %native.exp841 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5473)
  %5474 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5410, <8 x float> zeroinitializer
  %native.exp842 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5474)
  %5475 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5411, <8 x float> zeroinitializer
  %native.exp843 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5475)
  %5476 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5412, <8 x float> zeroinitializer
  %native.exp844 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5476)
  %5477 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5413, <8 x float> zeroinitializer
  %native.exp845 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5477)
  %5478 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5414, <8 x float> zeroinitializer
  %native.exp846 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5478)
  %5479 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5415, <8 x float> zeroinitializer
  %native.exp847 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5479)
  %5480 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5416, <8 x float> zeroinitializer
  %native.exp848 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5480)
  %5481 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5417, <8 x float> zeroinitializer
  %native.exp849 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5481)
  %5482 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5418, <8 x float> zeroinitializer
  %native.exp850 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5482)
  %5483 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5419, <8 x float> zeroinitializer
  %native.exp851 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5483)
  %5484 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5420, <8 x float> zeroinitializer
  %native.exp852 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5484)
  %5485 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5421, <8 x float> zeroinitializer
  %native.exp853 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5485)
  %5486 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5422, <8 x float> zeroinitializer
  %native.exp854 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5486)
  %5487 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5423, <8 x float> zeroinitializer
  %native.exp855 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5487)
  %5488 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5424, <8 x float> zeroinitializer
  %native.exp856 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5488)
  %5489 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5425, <8 x float> zeroinitializer
  %native.exp857 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5489)
  %5490 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5426, <8 x float> zeroinitializer
  %native.exp858 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5490)
  %5491 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5427, <8 x float> zeroinitializer
  %native.exp859 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5491)
  %5492 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5428, <8 x float> zeroinitializer
  %native.exp860 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5492)
  %5493 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5429, <8 x float> zeroinitializer
  %native.exp861 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5493)
  %5494 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5430, <8 x float> zeroinitializer
  %native.exp862 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5494)
  %5495 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5431, <8 x float> zeroinitializer
  %native.exp863 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5495)
  %5496 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5432, <8 x float> zeroinitializer
  %native.exp864 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5496)
  %5497 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5433, <8 x float> zeroinitializer
  %native.exp865 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5497)
  %5498 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5434, <8 x float> zeroinitializer
  %native.exp866 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5498)
  %5499 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5435, <8 x float> zeroinitializer
  %native.exp867 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5499)
  %5500 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5436, <8 x float> zeroinitializer
  %native.exp868 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5500)
  %5501 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5437, <8 x float> zeroinitializer
  %native.exp869 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5501)
  %5502 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5438, <8 x float> zeroinitializer
  %native.exp870 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5502)
  %5503 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5439, <8 x float> zeroinitializer
  %native.exp871 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5503)
  %5504 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5440, <8 x float> zeroinitializer
  %native.exp872 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5504)
  %5505 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5441, <8 x float> zeroinitializer
  %native.exp873 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5505)
  %5506 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5442, <8 x float> zeroinitializer
  %native.exp874 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5506)
  %5507 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5443, <8 x float> zeroinitializer
  %native.exp875 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5507)
  %5508 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5444, <8 x float> zeroinitializer
  %native.exp876 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5508)
  %5509 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5445, <8 x float> zeroinitializer
  %native.exp877 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5509)
  %5510 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5446, <8 x float> zeroinitializer
  %native.exp878 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5510)
  %5511 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5447, <8 x float> zeroinitializer
  %native.exp879 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5511)
  %5512 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5448, <8 x float> zeroinitializer
  %native.exp880 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5512)
  %5513 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5449, <8 x float> zeroinitializer
  %native.exp881 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5513)
  %5514 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5450, <8 x float> zeroinitializer
  %native.exp882 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5514)
  %5515 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5451, <8 x float> zeroinitializer
  %native.exp883 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5515)
  %5516 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5452, <8 x float> zeroinitializer
  %native.exp884 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5516)
  %5517 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5453, <8 x float> zeroinitializer
  %native.exp885 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5517)
  %5518 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5454, <8 x float> zeroinitializer
  %native.exp886 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5518)
  %5519 = select <8 x i1> %convergence.cascade.result736, <8 x float> %5455, <8 x float> zeroinitializer
  %native.exp887 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %5519)
  %.spill.load888 = load volatile <8 x i1>, ptr %.spill75, align 1
  %5520 = select <8 x i1> %.spill.load888, <8 x float> %native.exp824, <8 x float> zeroinitializer
  %.spill.load889 = load volatile <8 x i1>, ptr %.spill79, align 1
  %5521 = select <8 x i1> %.spill.load889, <8 x float> %native.exp825, <8 x float> zeroinitializer
  %.spill.load890 = load volatile <8 x i1>, ptr %.spill83, align 1
  %5522 = select <8 x i1> %.spill.load890, <8 x float> %native.exp826, <8 x float> zeroinitializer
  %.spill.load891 = load volatile <8 x i1>, ptr %.spill87, align 1
  %5523 = select <8 x i1> %.spill.load891, <8 x float> %native.exp827, <8 x float> zeroinitializer
  %.spill.load892 = load volatile <8 x i1>, ptr %.spill91, align 1
  %5524 = select <8 x i1> %.spill.load892, <8 x float> %native.exp828, <8 x float> zeroinitializer
  %.spill.load893 = load volatile <8 x i1>, ptr %.spill95, align 1
  %5525 = select <8 x i1> %.spill.load893, <8 x float> %native.exp829, <8 x float> zeroinitializer
  %.spill.load894 = load volatile <8 x i1>, ptr %.spill99, align 1
  %5526 = select <8 x i1> %.spill.load894, <8 x float> %native.exp830, <8 x float> zeroinitializer
  %.spill.load895 = load volatile <8 x i1>, ptr %.spill103, align 1
  %5527 = select <8 x i1> %.spill.load895, <8 x float> %native.exp831, <8 x float> zeroinitializer
  %.spill.load896 = load volatile <8 x i1>, ptr %.spill107, align 1
  %5528 = select <8 x i1> %.spill.load896, <8 x float> %native.exp832, <8 x float> zeroinitializer
  %.spill.load897 = load volatile <8 x i1>, ptr %.spill111, align 1
  %5529 = select <8 x i1> %.spill.load897, <8 x float> %native.exp833, <8 x float> zeroinitializer
  %.spill.load898 = load volatile <8 x i1>, ptr %.spill115, align 1
  %5530 = select <8 x i1> %.spill.load898, <8 x float> %native.exp834, <8 x float> zeroinitializer
  %.spill.load899 = load volatile <8 x i1>, ptr %.spill119, align 1
  %5531 = select <8 x i1> %.spill.load899, <8 x float> %native.exp835, <8 x float> zeroinitializer
  %.spill.load900 = load volatile <8 x i1>, ptr %.spill123, align 1
  %5532 = select <8 x i1> %.spill.load900, <8 x float> %native.exp836, <8 x float> zeroinitializer
  %.spill.load901 = load volatile <8 x i1>, ptr %.spill127, align 1
  %5533 = select <8 x i1> %.spill.load901, <8 x float> %native.exp837, <8 x float> zeroinitializer
  %.spill.load902 = load volatile <8 x i1>, ptr %.spill131, align 1
  %5534 = select <8 x i1> %.spill.load902, <8 x float> %native.exp838, <8 x float> zeroinitializer
  %.spill.load903 = load volatile <8 x i1>, ptr %.spill135, align 1
  %5535 = select <8 x i1> %.spill.load903, <8 x float> %native.exp839, <8 x float> zeroinitializer
  %.spill.load904 = load volatile <8 x i1>, ptr %.spill76, align 1
  %5536 = select <8 x i1> %.spill.load904, <8 x float> %native.exp840, <8 x float> zeroinitializer
  %.spill.load905 = load volatile <8 x i1>, ptr %.spill80, align 1
  %5537 = select <8 x i1> %.spill.load905, <8 x float> %native.exp841, <8 x float> zeroinitializer
  %.spill.load906 = load volatile <8 x i1>, ptr %.spill84, align 1
  %5538 = select <8 x i1> %.spill.load906, <8 x float> %native.exp842, <8 x float> zeroinitializer
  %.spill.load907 = load volatile <8 x i1>, ptr %.spill88, align 1
  %5539 = select <8 x i1> %.spill.load907, <8 x float> %native.exp843, <8 x float> zeroinitializer
  %.spill.load908 = load volatile <8 x i1>, ptr %.spill92, align 1
  %5540 = select <8 x i1> %.spill.load908, <8 x float> %native.exp844, <8 x float> zeroinitializer
  %.spill.load909 = load volatile <8 x i1>, ptr %.spill96, align 1
  %5541 = select <8 x i1> %.spill.load909, <8 x float> %native.exp845, <8 x float> zeroinitializer
  %.spill.load910 = load volatile <8 x i1>, ptr %.spill100, align 1
  %5542 = select <8 x i1> %.spill.load910, <8 x float> %native.exp846, <8 x float> zeroinitializer
  %.spill.load911 = load volatile <8 x i1>, ptr %.spill104, align 1
  %5543 = select <8 x i1> %.spill.load911, <8 x float> %native.exp847, <8 x float> zeroinitializer
  %.spill.load912 = load volatile <8 x i1>, ptr %.spill108, align 1
  %5544 = select <8 x i1> %.spill.load912, <8 x float> %native.exp848, <8 x float> zeroinitializer
  %.spill.load913 = load volatile <8 x i1>, ptr %.spill112, align 1
  %5545 = select <8 x i1> %.spill.load913, <8 x float> %native.exp849, <8 x float> zeroinitializer
  %.spill.load914 = load volatile <8 x i1>, ptr %.spill116, align 1
  %5546 = select <8 x i1> %.spill.load914, <8 x float> %native.exp850, <8 x float> zeroinitializer
  %.spill.load915 = load volatile <8 x i1>, ptr %.spill120, align 1
  %5547 = select <8 x i1> %.spill.load915, <8 x float> %native.exp851, <8 x float> zeroinitializer
  %.spill.load916 = load volatile <8 x i1>, ptr %.spill124, align 1
  %5548 = select <8 x i1> %.spill.load916, <8 x float> %native.exp852, <8 x float> zeroinitializer
  %.spill.load917 = load volatile <8 x i1>, ptr %.spill128, align 1
  %5549 = select <8 x i1> %.spill.load917, <8 x float> %native.exp853, <8 x float> zeroinitializer
  %.spill.load918 = load volatile <8 x i1>, ptr %.spill132, align 1
  %5550 = select <8 x i1> %.spill.load918, <8 x float> %native.exp854, <8 x float> zeroinitializer
  %.spill.load919 = load volatile <8 x i1>, ptr %.spill136, align 1
  %5551 = select <8 x i1> %.spill.load919, <8 x float> %native.exp855, <8 x float> zeroinitializer
  %.spill.load920 = load volatile <8 x i1>, ptr %.spill77, align 1
  %5552 = select <8 x i1> %.spill.load920, <8 x float> %native.exp856, <8 x float> zeroinitializer
  %.spill.load921 = load volatile <8 x i1>, ptr %.spill81, align 1
  %5553 = select <8 x i1> %.spill.load921, <8 x float> %native.exp857, <8 x float> zeroinitializer
  %.spill.load922 = load volatile <8 x i1>, ptr %.spill85, align 1
  %5554 = select <8 x i1> %.spill.load922, <8 x float> %native.exp858, <8 x float> zeroinitializer
  %.spill.load923 = load volatile <8 x i1>, ptr %.spill89, align 1
  %5555 = select <8 x i1> %.spill.load923, <8 x float> %native.exp859, <8 x float> zeroinitializer
  %.spill.load924 = load volatile <8 x i1>, ptr %.spill93, align 1
  %5556 = select <8 x i1> %.spill.load924, <8 x float> %native.exp860, <8 x float> zeroinitializer
  %.spill.load925 = load volatile <8 x i1>, ptr %.spill97, align 1
  %5557 = select <8 x i1> %.spill.load925, <8 x float> %native.exp861, <8 x float> zeroinitializer
  %.spill.load926 = load volatile <8 x i1>, ptr %.spill101, align 1
  %5558 = select <8 x i1> %.spill.load926, <8 x float> %native.exp862, <8 x float> zeroinitializer
  %.spill.load927 = load volatile <8 x i1>, ptr %.spill105, align 1
  %5559 = select <8 x i1> %.spill.load927, <8 x float> %native.exp863, <8 x float> zeroinitializer
  %.spill.load928 = load volatile <8 x i1>, ptr %.spill109, align 1
  %5560 = select <8 x i1> %.spill.load928, <8 x float> %native.exp864, <8 x float> zeroinitializer
  %.spill.load929 = load volatile <8 x i1>, ptr %.spill113, align 1
  %5561 = select <8 x i1> %.spill.load929, <8 x float> %native.exp865, <8 x float> zeroinitializer
  %.spill.load930 = load volatile <8 x i1>, ptr %.spill117, align 1
  %5562 = select <8 x i1> %.spill.load930, <8 x float> %native.exp866, <8 x float> zeroinitializer
  %.spill.load931 = load volatile <8 x i1>, ptr %.spill121, align 1
  %5563 = select <8 x i1> %.spill.load931, <8 x float> %native.exp867, <8 x float> zeroinitializer
  %.spill.load932 = load volatile <8 x i1>, ptr %.spill125, align 1
  %5564 = select <8 x i1> %.spill.load932, <8 x float> %native.exp868, <8 x float> zeroinitializer
  %.spill.load933 = load volatile <8 x i1>, ptr %.spill129, align 1
  %5565 = select <8 x i1> %.spill.load933, <8 x float> %native.exp869, <8 x float> zeroinitializer
  %.spill.load934 = load volatile <8 x i1>, ptr %.spill133, align 1
  %5566 = select <8 x i1> %.spill.load934, <8 x float> %native.exp870, <8 x float> zeroinitializer
  %.spill.load935 = load volatile <8 x i1>, ptr %.spill137, align 1
  %5567 = select <8 x i1> %.spill.load935, <8 x float> %native.exp871, <8 x float> zeroinitializer
  %.spill.load936 = load volatile <8 x i1>, ptr %.spill78, align 1
  %5568 = select <8 x i1> %.spill.load936, <8 x float> %native.exp872, <8 x float> zeroinitializer
  %.spill.load937 = load volatile <8 x i1>, ptr %.spill82, align 1
  %5569 = select <8 x i1> %.spill.load937, <8 x float> %native.exp873, <8 x float> zeroinitializer
  %.spill.load938 = load volatile <8 x i1>, ptr %.spill86, align 1
  %5570 = select <8 x i1> %.spill.load938, <8 x float> %native.exp874, <8 x float> zeroinitializer
  %.spill.load939 = load volatile <8 x i1>, ptr %.spill90, align 1
  %5571 = select <8 x i1> %.spill.load939, <8 x float> %native.exp875, <8 x float> zeroinitializer
  %.spill.load940 = load volatile <8 x i1>, ptr %.spill94, align 1
  %5572 = select <8 x i1> %.spill.load940, <8 x float> %native.exp876, <8 x float> zeroinitializer
  %.spill.load941 = load volatile <8 x i1>, ptr %.spill98, align 1
  %5573 = select <8 x i1> %.spill.load941, <8 x float> %native.exp877, <8 x float> zeroinitializer
  %.spill.load942 = load volatile <8 x i1>, ptr %.spill102, align 1
  %5574 = select <8 x i1> %.spill.load942, <8 x float> %native.exp878, <8 x float> zeroinitializer
  %.spill.load943 = load volatile <8 x i1>, ptr %.spill106, align 1
  %5575 = select <8 x i1> %.spill.load943, <8 x float> %native.exp879, <8 x float> zeroinitializer
  %.spill.load944 = load volatile <8 x i1>, ptr %.spill110, align 1
  %5576 = select <8 x i1> %.spill.load944, <8 x float> %native.exp880, <8 x float> zeroinitializer
  %.spill.load945 = load volatile <8 x i1>, ptr %.spill114, align 1
  %5577 = select <8 x i1> %.spill.load945, <8 x float> %native.exp881, <8 x float> zeroinitializer
  %.spill.load946 = load volatile <8 x i1>, ptr %.spill118, align 1
  %5578 = select <8 x i1> %.spill.load946, <8 x float> %native.exp882, <8 x float> zeroinitializer
  %.spill.load947 = load volatile <8 x i1>, ptr %.spill122, align 1
  %5579 = select <8 x i1> %.spill.load947, <8 x float> %native.exp883, <8 x float> zeroinitializer
  %.spill.load948 = load volatile <8 x i1>, ptr %.spill126, align 1
  %5580 = select <8 x i1> %.spill.load948, <8 x float> %native.exp884, <8 x float> zeroinitializer
  %.spill.load949 = load volatile <8 x i1>, ptr %.spill130, align 1
  %5581 = select <8 x i1> %.spill.load949, <8 x float> %native.exp885, <8 x float> zeroinitializer
  %.spill.load950 = load volatile <8 x i1>, ptr %.spill134, align 1
  %5582 = select <8 x i1> %.spill.load950, <8 x float> %native.exp886, <8 x float> zeroinitializer
  %.spill.load951 = load volatile <8 x i1>, ptr %.spill138, align 1
  %5583 = select <8 x i1> %.spill.load951, <8 x float> %native.exp887, <8 x float> zeroinitializer
  %5584 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill217, align 64
  %5585 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5586 = extractvalue { <8 x ptr>, <8 x i64> } %5584, 0
  %5587 = select <8 x i1> %convergence.cascade.result736, <8 x ptr> %5585, <8 x ptr> %5586
  %5588 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5589 = extractvalue { <8 x ptr>, <8 x i64> } %5584, 1
  %5590 = select <8 x i1> %convergence.cascade.result736, <8 x i64> %5588, <8 x i64> %5589
  %5591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5587, 0
  %5592 = insertvalue { <8 x ptr>, <8 x i64> } %5591, <8 x i64> %5590, 1
  store { <8 x ptr>, <8 x i64> } %5592, ptr %tile_snapshot.spill217, align 64
  %5593 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5594 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5595 = add <8 x i64> %5594, zeroinitializer
  %5596 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5593, 0
  %5597 = insertvalue { <8 x ptr>, <8 x i64> } %5596, <8 x i64> %5595, 1
  %5598 = extractvalue { <8 x ptr>, <8 x i64> } %5597, 0
  %5599 = extractvalue { <8 x ptr>, <8 x i64> } %5597, 1
  %5600 = getelementptr i8, <8 x ptr> %5598, <8 x i64> %5599
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5520, <8 x ptr> align 1 %5600, <8 x i1> %convergence.cascade.result736)
  %5601 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5602 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5603 = add <8 x i64> %5602, splat (i64 4)
  %5604 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5601, 0
  %5605 = insertvalue { <8 x ptr>, <8 x i64> } %5604, <8 x i64> %5603, 1
  %5606 = extractvalue { <8 x ptr>, <8 x i64> } %5605, 0
  %5607 = extractvalue { <8 x ptr>, <8 x i64> } %5605, 1
  %5608 = getelementptr i8, <8 x ptr> %5606, <8 x i64> %5607
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5521, <8 x ptr> align 1 %5608, <8 x i1> %convergence.cascade.result736)
  %5609 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5610 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5611 = add <8 x i64> %5610, splat (i64 8)
  %5612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5609, 0
  %5613 = insertvalue { <8 x ptr>, <8 x i64> } %5612, <8 x i64> %5611, 1
  %5614 = extractvalue { <8 x ptr>, <8 x i64> } %5613, 0
  %5615 = extractvalue { <8 x ptr>, <8 x i64> } %5613, 1
  %5616 = getelementptr i8, <8 x ptr> %5614, <8 x i64> %5615
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5522, <8 x ptr> align 1 %5616, <8 x i1> %convergence.cascade.result736)
  %5617 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5618 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5619 = add <8 x i64> %5618, splat (i64 12)
  %5620 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5617, 0
  %5621 = insertvalue { <8 x ptr>, <8 x i64> } %5620, <8 x i64> %5619, 1
  %5622 = extractvalue { <8 x ptr>, <8 x i64> } %5621, 0
  %5623 = extractvalue { <8 x ptr>, <8 x i64> } %5621, 1
  %5624 = getelementptr i8, <8 x ptr> %5622, <8 x i64> %5623
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5523, <8 x ptr> align 1 %5624, <8 x i1> %convergence.cascade.result736)
  %5625 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5626 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5627 = add <8 x i64> %5626, splat (i64 16)
  %5628 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5625, 0
  %5629 = insertvalue { <8 x ptr>, <8 x i64> } %5628, <8 x i64> %5627, 1
  %5630 = extractvalue { <8 x ptr>, <8 x i64> } %5629, 0
  %5631 = extractvalue { <8 x ptr>, <8 x i64> } %5629, 1
  %5632 = getelementptr i8, <8 x ptr> %5630, <8 x i64> %5631
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5524, <8 x ptr> align 1 %5632, <8 x i1> %convergence.cascade.result736)
  %5633 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5634 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5635 = add <8 x i64> %5634, splat (i64 20)
  %5636 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5633, 0
  %5637 = insertvalue { <8 x ptr>, <8 x i64> } %5636, <8 x i64> %5635, 1
  %5638 = extractvalue { <8 x ptr>, <8 x i64> } %5637, 0
  %5639 = extractvalue { <8 x ptr>, <8 x i64> } %5637, 1
  %5640 = getelementptr i8, <8 x ptr> %5638, <8 x i64> %5639
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5525, <8 x ptr> align 1 %5640, <8 x i1> %convergence.cascade.result736)
  %5641 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5642 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5643 = add <8 x i64> %5642, splat (i64 24)
  %5644 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5641, 0
  %5645 = insertvalue { <8 x ptr>, <8 x i64> } %5644, <8 x i64> %5643, 1
  %5646 = extractvalue { <8 x ptr>, <8 x i64> } %5645, 0
  %5647 = extractvalue { <8 x ptr>, <8 x i64> } %5645, 1
  %5648 = getelementptr i8, <8 x ptr> %5646, <8 x i64> %5647
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5526, <8 x ptr> align 1 %5648, <8 x i1> %convergence.cascade.result736)
  %5649 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5650 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5651 = add <8 x i64> %5650, splat (i64 28)
  %5652 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5649, 0
  %5653 = insertvalue { <8 x ptr>, <8 x i64> } %5652, <8 x i64> %5651, 1
  %5654 = extractvalue { <8 x ptr>, <8 x i64> } %5653, 0
  %5655 = extractvalue { <8 x ptr>, <8 x i64> } %5653, 1
  %5656 = getelementptr i8, <8 x ptr> %5654, <8 x i64> %5655
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5527, <8 x ptr> align 1 %5656, <8 x i1> %convergence.cascade.result736)
  %5657 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5658 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5659 = add <8 x i64> %5658, splat (i64 32)
  %5660 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5657, 0
  %5661 = insertvalue { <8 x ptr>, <8 x i64> } %5660, <8 x i64> %5659, 1
  %5662 = extractvalue { <8 x ptr>, <8 x i64> } %5661, 0
  %5663 = extractvalue { <8 x ptr>, <8 x i64> } %5661, 1
  %5664 = getelementptr i8, <8 x ptr> %5662, <8 x i64> %5663
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5528, <8 x ptr> align 1 %5664, <8 x i1> %convergence.cascade.result736)
  %5665 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5666 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5667 = add <8 x i64> %5666, splat (i64 36)
  %5668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5665, 0
  %5669 = insertvalue { <8 x ptr>, <8 x i64> } %5668, <8 x i64> %5667, 1
  %5670 = extractvalue { <8 x ptr>, <8 x i64> } %5669, 0
  %5671 = extractvalue { <8 x ptr>, <8 x i64> } %5669, 1
  %5672 = getelementptr i8, <8 x ptr> %5670, <8 x i64> %5671
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5529, <8 x ptr> align 1 %5672, <8 x i1> %convergence.cascade.result736)
  %5673 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5674 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5675 = add <8 x i64> %5674, splat (i64 40)
  %5676 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5673, 0
  %5677 = insertvalue { <8 x ptr>, <8 x i64> } %5676, <8 x i64> %5675, 1
  %5678 = extractvalue { <8 x ptr>, <8 x i64> } %5677, 0
  %5679 = extractvalue { <8 x ptr>, <8 x i64> } %5677, 1
  %5680 = getelementptr i8, <8 x ptr> %5678, <8 x i64> %5679
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5530, <8 x ptr> align 1 %5680, <8 x i1> %convergence.cascade.result736)
  %5681 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5682 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5683 = add <8 x i64> %5682, splat (i64 44)
  %5684 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5681, 0
  %5685 = insertvalue { <8 x ptr>, <8 x i64> } %5684, <8 x i64> %5683, 1
  %5686 = extractvalue { <8 x ptr>, <8 x i64> } %5685, 0
  %5687 = extractvalue { <8 x ptr>, <8 x i64> } %5685, 1
  %5688 = getelementptr i8, <8 x ptr> %5686, <8 x i64> %5687
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5531, <8 x ptr> align 1 %5688, <8 x i1> %convergence.cascade.result736)
  %5689 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5690 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5691 = add <8 x i64> %5690, splat (i64 48)
  %5692 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5689, 0
  %5693 = insertvalue { <8 x ptr>, <8 x i64> } %5692, <8 x i64> %5691, 1
  %5694 = extractvalue { <8 x ptr>, <8 x i64> } %5693, 0
  %5695 = extractvalue { <8 x ptr>, <8 x i64> } %5693, 1
  %5696 = getelementptr i8, <8 x ptr> %5694, <8 x i64> %5695
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5532, <8 x ptr> align 1 %5696, <8 x i1> %convergence.cascade.result736)
  %5697 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5698 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5699 = add <8 x i64> %5698, splat (i64 52)
  %5700 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5697, 0
  %5701 = insertvalue { <8 x ptr>, <8 x i64> } %5700, <8 x i64> %5699, 1
  %5702 = extractvalue { <8 x ptr>, <8 x i64> } %5701, 0
  %5703 = extractvalue { <8 x ptr>, <8 x i64> } %5701, 1
  %5704 = getelementptr i8, <8 x ptr> %5702, <8 x i64> %5703
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5533, <8 x ptr> align 1 %5704, <8 x i1> %convergence.cascade.result736)
  %5705 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5706 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5707 = add <8 x i64> %5706, splat (i64 56)
  %5708 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5705, 0
  %5709 = insertvalue { <8 x ptr>, <8 x i64> } %5708, <8 x i64> %5707, 1
  %5710 = extractvalue { <8 x ptr>, <8 x i64> } %5709, 0
  %5711 = extractvalue { <8 x ptr>, <8 x i64> } %5709, 1
  %5712 = getelementptr i8, <8 x ptr> %5710, <8 x i64> %5711
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5534, <8 x ptr> align 1 %5712, <8 x i1> %convergence.cascade.result736)
  %5713 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5714 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5715 = add <8 x i64> %5714, splat (i64 60)
  %5716 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5713, 0
  %5717 = insertvalue { <8 x ptr>, <8 x i64> } %5716, <8 x i64> %5715, 1
  %5718 = extractvalue { <8 x ptr>, <8 x i64> } %5717, 0
  %5719 = extractvalue { <8 x ptr>, <8 x i64> } %5717, 1
  %5720 = getelementptr i8, <8 x ptr> %5718, <8 x i64> %5719
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5535, <8 x ptr> align 1 %5720, <8 x i1> %convergence.cascade.result736)
  %5721 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5722 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5723 = add <8 x i64> %5722, splat (i64 64)
  %5724 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5721, 0
  %5725 = insertvalue { <8 x ptr>, <8 x i64> } %5724, <8 x i64> %5723, 1
  %5726 = extractvalue { <8 x ptr>, <8 x i64> } %5725, 0
  %5727 = extractvalue { <8 x ptr>, <8 x i64> } %5725, 1
  %5728 = getelementptr i8, <8 x ptr> %5726, <8 x i64> %5727
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5536, <8 x ptr> align 1 %5728, <8 x i1> %convergence.cascade.result736)
  %5729 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5730 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5731 = add <8 x i64> %5730, splat (i64 68)
  %5732 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5729, 0
  %5733 = insertvalue { <8 x ptr>, <8 x i64> } %5732, <8 x i64> %5731, 1
  %5734 = extractvalue { <8 x ptr>, <8 x i64> } %5733, 0
  %5735 = extractvalue { <8 x ptr>, <8 x i64> } %5733, 1
  %5736 = getelementptr i8, <8 x ptr> %5734, <8 x i64> %5735
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5537, <8 x ptr> align 1 %5736, <8 x i1> %convergence.cascade.result736)
  %5737 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5738 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5739 = add <8 x i64> %5738, splat (i64 72)
  %5740 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5737, 0
  %5741 = insertvalue { <8 x ptr>, <8 x i64> } %5740, <8 x i64> %5739, 1
  %5742 = extractvalue { <8 x ptr>, <8 x i64> } %5741, 0
  %5743 = extractvalue { <8 x ptr>, <8 x i64> } %5741, 1
  %5744 = getelementptr i8, <8 x ptr> %5742, <8 x i64> %5743
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5538, <8 x ptr> align 1 %5744, <8 x i1> %convergence.cascade.result736)
  %5745 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5746 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5747 = add <8 x i64> %5746, splat (i64 76)
  %5748 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5745, 0
  %5749 = insertvalue { <8 x ptr>, <8 x i64> } %5748, <8 x i64> %5747, 1
  %5750 = extractvalue { <8 x ptr>, <8 x i64> } %5749, 0
  %5751 = extractvalue { <8 x ptr>, <8 x i64> } %5749, 1
  %5752 = getelementptr i8, <8 x ptr> %5750, <8 x i64> %5751
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5539, <8 x ptr> align 1 %5752, <8 x i1> %convergence.cascade.result736)
  %5753 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5754 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5755 = add <8 x i64> %5754, splat (i64 80)
  %5756 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5753, 0
  %5757 = insertvalue { <8 x ptr>, <8 x i64> } %5756, <8 x i64> %5755, 1
  %5758 = extractvalue { <8 x ptr>, <8 x i64> } %5757, 0
  %5759 = extractvalue { <8 x ptr>, <8 x i64> } %5757, 1
  %5760 = getelementptr i8, <8 x ptr> %5758, <8 x i64> %5759
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5540, <8 x ptr> align 1 %5760, <8 x i1> %convergence.cascade.result736)
  %5761 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5762 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5763 = add <8 x i64> %5762, splat (i64 84)
  %5764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5761, 0
  %5765 = insertvalue { <8 x ptr>, <8 x i64> } %5764, <8 x i64> %5763, 1
  %5766 = extractvalue { <8 x ptr>, <8 x i64> } %5765, 0
  %5767 = extractvalue { <8 x ptr>, <8 x i64> } %5765, 1
  %5768 = getelementptr i8, <8 x ptr> %5766, <8 x i64> %5767
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5541, <8 x ptr> align 1 %5768, <8 x i1> %convergence.cascade.result736)
  %5769 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5770 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5771 = add <8 x i64> %5770, splat (i64 88)
  %5772 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5769, 0
  %5773 = insertvalue { <8 x ptr>, <8 x i64> } %5772, <8 x i64> %5771, 1
  %5774 = extractvalue { <8 x ptr>, <8 x i64> } %5773, 0
  %5775 = extractvalue { <8 x ptr>, <8 x i64> } %5773, 1
  %5776 = getelementptr i8, <8 x ptr> %5774, <8 x i64> %5775
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5542, <8 x ptr> align 1 %5776, <8 x i1> %convergence.cascade.result736)
  %5777 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5778 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5779 = add <8 x i64> %5778, splat (i64 92)
  %5780 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5777, 0
  %5781 = insertvalue { <8 x ptr>, <8 x i64> } %5780, <8 x i64> %5779, 1
  %5782 = extractvalue { <8 x ptr>, <8 x i64> } %5781, 0
  %5783 = extractvalue { <8 x ptr>, <8 x i64> } %5781, 1
  %5784 = getelementptr i8, <8 x ptr> %5782, <8 x i64> %5783
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5543, <8 x ptr> align 1 %5784, <8 x i1> %convergence.cascade.result736)
  %5785 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5786 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5787 = add <8 x i64> %5786, splat (i64 96)
  %5788 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5785, 0
  %5789 = insertvalue { <8 x ptr>, <8 x i64> } %5788, <8 x i64> %5787, 1
  %5790 = extractvalue { <8 x ptr>, <8 x i64> } %5789, 0
  %5791 = extractvalue { <8 x ptr>, <8 x i64> } %5789, 1
  %5792 = getelementptr i8, <8 x ptr> %5790, <8 x i64> %5791
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5544, <8 x ptr> align 1 %5792, <8 x i1> %convergence.cascade.result736)
  %5793 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5794 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5795 = add <8 x i64> %5794, splat (i64 100)
  %5796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5793, 0
  %5797 = insertvalue { <8 x ptr>, <8 x i64> } %5796, <8 x i64> %5795, 1
  %5798 = extractvalue { <8 x ptr>, <8 x i64> } %5797, 0
  %5799 = extractvalue { <8 x ptr>, <8 x i64> } %5797, 1
  %5800 = getelementptr i8, <8 x ptr> %5798, <8 x i64> %5799
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5545, <8 x ptr> align 1 %5800, <8 x i1> %convergence.cascade.result736)
  %5801 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5802 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5803 = add <8 x i64> %5802, splat (i64 104)
  %5804 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5801, 0
  %5805 = insertvalue { <8 x ptr>, <8 x i64> } %5804, <8 x i64> %5803, 1
  %5806 = extractvalue { <8 x ptr>, <8 x i64> } %5805, 0
  %5807 = extractvalue { <8 x ptr>, <8 x i64> } %5805, 1
  %5808 = getelementptr i8, <8 x ptr> %5806, <8 x i64> %5807
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5546, <8 x ptr> align 1 %5808, <8 x i1> %convergence.cascade.result736)
  %5809 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5810 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5811 = add <8 x i64> %5810, splat (i64 108)
  %5812 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5809, 0
  %5813 = insertvalue { <8 x ptr>, <8 x i64> } %5812, <8 x i64> %5811, 1
  %5814 = extractvalue { <8 x ptr>, <8 x i64> } %5813, 0
  %5815 = extractvalue { <8 x ptr>, <8 x i64> } %5813, 1
  %5816 = getelementptr i8, <8 x ptr> %5814, <8 x i64> %5815
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5547, <8 x ptr> align 1 %5816, <8 x i1> %convergence.cascade.result736)
  %5817 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5818 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5819 = add <8 x i64> %5818, splat (i64 112)
  %5820 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5817, 0
  %5821 = insertvalue { <8 x ptr>, <8 x i64> } %5820, <8 x i64> %5819, 1
  %5822 = extractvalue { <8 x ptr>, <8 x i64> } %5821, 0
  %5823 = extractvalue { <8 x ptr>, <8 x i64> } %5821, 1
  %5824 = getelementptr i8, <8 x ptr> %5822, <8 x i64> %5823
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5548, <8 x ptr> align 1 %5824, <8 x i1> %convergence.cascade.result736)
  %5825 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5826 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5827 = add <8 x i64> %5826, splat (i64 116)
  %5828 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5825, 0
  %5829 = insertvalue { <8 x ptr>, <8 x i64> } %5828, <8 x i64> %5827, 1
  %5830 = extractvalue { <8 x ptr>, <8 x i64> } %5829, 0
  %5831 = extractvalue { <8 x ptr>, <8 x i64> } %5829, 1
  %5832 = getelementptr i8, <8 x ptr> %5830, <8 x i64> %5831
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5549, <8 x ptr> align 1 %5832, <8 x i1> %convergence.cascade.result736)
  %5833 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5834 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5835 = add <8 x i64> %5834, splat (i64 120)
  %5836 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5833, 0
  %5837 = insertvalue { <8 x ptr>, <8 x i64> } %5836, <8 x i64> %5835, 1
  %5838 = extractvalue { <8 x ptr>, <8 x i64> } %5837, 0
  %5839 = extractvalue { <8 x ptr>, <8 x i64> } %5837, 1
  %5840 = getelementptr i8, <8 x ptr> %5838, <8 x i64> %5839
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5550, <8 x ptr> align 1 %5840, <8 x i1> %convergence.cascade.result736)
  %5841 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5842 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5843 = add <8 x i64> %5842, splat (i64 124)
  %5844 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5841, 0
  %5845 = insertvalue { <8 x ptr>, <8 x i64> } %5844, <8 x i64> %5843, 1
  %5846 = extractvalue { <8 x ptr>, <8 x i64> } %5845, 0
  %5847 = extractvalue { <8 x ptr>, <8 x i64> } %5845, 1
  %5848 = getelementptr i8, <8 x ptr> %5846, <8 x i64> %5847
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5551, <8 x ptr> align 1 %5848, <8 x i1> %convergence.cascade.result736)
  %5849 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5850 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5851 = add <8 x i64> %5850, splat (i64 128)
  %5852 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5849, 0
  %5853 = insertvalue { <8 x ptr>, <8 x i64> } %5852, <8 x i64> %5851, 1
  %5854 = extractvalue { <8 x ptr>, <8 x i64> } %5853, 0
  %5855 = extractvalue { <8 x ptr>, <8 x i64> } %5853, 1
  %5856 = getelementptr i8, <8 x ptr> %5854, <8 x i64> %5855
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5552, <8 x ptr> align 1 %5856, <8 x i1> %convergence.cascade.result736)
  %5857 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5858 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5859 = add <8 x i64> %5858, splat (i64 132)
  %5860 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5857, 0
  %5861 = insertvalue { <8 x ptr>, <8 x i64> } %5860, <8 x i64> %5859, 1
  %5862 = extractvalue { <8 x ptr>, <8 x i64> } %5861, 0
  %5863 = extractvalue { <8 x ptr>, <8 x i64> } %5861, 1
  %5864 = getelementptr i8, <8 x ptr> %5862, <8 x i64> %5863
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5553, <8 x ptr> align 1 %5864, <8 x i1> %convergence.cascade.result736)
  %5865 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5866 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5867 = add <8 x i64> %5866, splat (i64 136)
  %5868 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5865, 0
  %5869 = insertvalue { <8 x ptr>, <8 x i64> } %5868, <8 x i64> %5867, 1
  %5870 = extractvalue { <8 x ptr>, <8 x i64> } %5869, 0
  %5871 = extractvalue { <8 x ptr>, <8 x i64> } %5869, 1
  %5872 = getelementptr i8, <8 x ptr> %5870, <8 x i64> %5871
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5554, <8 x ptr> align 1 %5872, <8 x i1> %convergence.cascade.result736)
  %5873 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5874 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5875 = add <8 x i64> %5874, splat (i64 140)
  %5876 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5873, 0
  %5877 = insertvalue { <8 x ptr>, <8 x i64> } %5876, <8 x i64> %5875, 1
  %5878 = extractvalue { <8 x ptr>, <8 x i64> } %5877, 0
  %5879 = extractvalue { <8 x ptr>, <8 x i64> } %5877, 1
  %5880 = getelementptr i8, <8 x ptr> %5878, <8 x i64> %5879
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5555, <8 x ptr> align 1 %5880, <8 x i1> %convergence.cascade.result736)
  %5881 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5882 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5883 = add <8 x i64> %5882, splat (i64 144)
  %5884 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5881, 0
  %5885 = insertvalue { <8 x ptr>, <8 x i64> } %5884, <8 x i64> %5883, 1
  %5886 = extractvalue { <8 x ptr>, <8 x i64> } %5885, 0
  %5887 = extractvalue { <8 x ptr>, <8 x i64> } %5885, 1
  %5888 = getelementptr i8, <8 x ptr> %5886, <8 x i64> %5887
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5556, <8 x ptr> align 1 %5888, <8 x i1> %convergence.cascade.result736)
  %5889 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5890 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5891 = add <8 x i64> %5890, splat (i64 148)
  %5892 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5889, 0
  %5893 = insertvalue { <8 x ptr>, <8 x i64> } %5892, <8 x i64> %5891, 1
  %5894 = extractvalue { <8 x ptr>, <8 x i64> } %5893, 0
  %5895 = extractvalue { <8 x ptr>, <8 x i64> } %5893, 1
  %5896 = getelementptr i8, <8 x ptr> %5894, <8 x i64> %5895
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5557, <8 x ptr> align 1 %5896, <8 x i1> %convergence.cascade.result736)
  %5897 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5898 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5899 = add <8 x i64> %5898, splat (i64 152)
  %5900 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5897, 0
  %5901 = insertvalue { <8 x ptr>, <8 x i64> } %5900, <8 x i64> %5899, 1
  %5902 = extractvalue { <8 x ptr>, <8 x i64> } %5901, 0
  %5903 = extractvalue { <8 x ptr>, <8 x i64> } %5901, 1
  %5904 = getelementptr i8, <8 x ptr> %5902, <8 x i64> %5903
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5558, <8 x ptr> align 1 %5904, <8 x i1> %convergence.cascade.result736)
  %5905 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5906 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5907 = add <8 x i64> %5906, splat (i64 156)
  %5908 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5905, 0
  %5909 = insertvalue { <8 x ptr>, <8 x i64> } %5908, <8 x i64> %5907, 1
  %5910 = extractvalue { <8 x ptr>, <8 x i64> } %5909, 0
  %5911 = extractvalue { <8 x ptr>, <8 x i64> } %5909, 1
  %5912 = getelementptr i8, <8 x ptr> %5910, <8 x i64> %5911
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5559, <8 x ptr> align 1 %5912, <8 x i1> %convergence.cascade.result736)
  %5913 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5914 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5915 = add <8 x i64> %5914, splat (i64 160)
  %5916 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5913, 0
  %5917 = insertvalue { <8 x ptr>, <8 x i64> } %5916, <8 x i64> %5915, 1
  %5918 = extractvalue { <8 x ptr>, <8 x i64> } %5917, 0
  %5919 = extractvalue { <8 x ptr>, <8 x i64> } %5917, 1
  %5920 = getelementptr i8, <8 x ptr> %5918, <8 x i64> %5919
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5560, <8 x ptr> align 1 %5920, <8 x i1> %convergence.cascade.result736)
  %5921 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5922 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5923 = add <8 x i64> %5922, splat (i64 164)
  %5924 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5921, 0
  %5925 = insertvalue { <8 x ptr>, <8 x i64> } %5924, <8 x i64> %5923, 1
  %5926 = extractvalue { <8 x ptr>, <8 x i64> } %5925, 0
  %5927 = extractvalue { <8 x ptr>, <8 x i64> } %5925, 1
  %5928 = getelementptr i8, <8 x ptr> %5926, <8 x i64> %5927
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5561, <8 x ptr> align 1 %5928, <8 x i1> %convergence.cascade.result736)
  %5929 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5930 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5931 = add <8 x i64> %5930, splat (i64 168)
  %5932 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5929, 0
  %5933 = insertvalue { <8 x ptr>, <8 x i64> } %5932, <8 x i64> %5931, 1
  %5934 = extractvalue { <8 x ptr>, <8 x i64> } %5933, 0
  %5935 = extractvalue { <8 x ptr>, <8 x i64> } %5933, 1
  %5936 = getelementptr i8, <8 x ptr> %5934, <8 x i64> %5935
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5562, <8 x ptr> align 1 %5936, <8 x i1> %convergence.cascade.result736)
  %5937 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5938 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5939 = add <8 x i64> %5938, splat (i64 172)
  %5940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5937, 0
  %5941 = insertvalue { <8 x ptr>, <8 x i64> } %5940, <8 x i64> %5939, 1
  %5942 = extractvalue { <8 x ptr>, <8 x i64> } %5941, 0
  %5943 = extractvalue { <8 x ptr>, <8 x i64> } %5941, 1
  %5944 = getelementptr i8, <8 x ptr> %5942, <8 x i64> %5943
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5563, <8 x ptr> align 1 %5944, <8 x i1> %convergence.cascade.result736)
  %5945 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5946 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5947 = add <8 x i64> %5946, splat (i64 176)
  %5948 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5945, 0
  %5949 = insertvalue { <8 x ptr>, <8 x i64> } %5948, <8 x i64> %5947, 1
  %5950 = extractvalue { <8 x ptr>, <8 x i64> } %5949, 0
  %5951 = extractvalue { <8 x ptr>, <8 x i64> } %5949, 1
  %5952 = getelementptr i8, <8 x ptr> %5950, <8 x i64> %5951
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5564, <8 x ptr> align 1 %5952, <8 x i1> %convergence.cascade.result736)
  %5953 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5954 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5955 = add <8 x i64> %5954, splat (i64 180)
  %5956 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5953, 0
  %5957 = insertvalue { <8 x ptr>, <8 x i64> } %5956, <8 x i64> %5955, 1
  %5958 = extractvalue { <8 x ptr>, <8 x i64> } %5957, 0
  %5959 = extractvalue { <8 x ptr>, <8 x i64> } %5957, 1
  %5960 = getelementptr i8, <8 x ptr> %5958, <8 x i64> %5959
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5565, <8 x ptr> align 1 %5960, <8 x i1> %convergence.cascade.result736)
  %5961 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5962 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5963 = add <8 x i64> %5962, splat (i64 184)
  %5964 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5961, 0
  %5965 = insertvalue { <8 x ptr>, <8 x i64> } %5964, <8 x i64> %5963, 1
  %5966 = extractvalue { <8 x ptr>, <8 x i64> } %5965, 0
  %5967 = extractvalue { <8 x ptr>, <8 x i64> } %5965, 1
  %5968 = getelementptr i8, <8 x ptr> %5966, <8 x i64> %5967
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5566, <8 x ptr> align 1 %5968, <8 x i1> %convergence.cascade.result736)
  %5969 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5970 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5971 = add <8 x i64> %5970, splat (i64 188)
  %5972 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5969, 0
  %5973 = insertvalue { <8 x ptr>, <8 x i64> } %5972, <8 x i64> %5971, 1
  %5974 = extractvalue { <8 x ptr>, <8 x i64> } %5973, 0
  %5975 = extractvalue { <8 x ptr>, <8 x i64> } %5973, 1
  %5976 = getelementptr i8, <8 x ptr> %5974, <8 x i64> %5975
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5567, <8 x ptr> align 1 %5976, <8 x i1> %convergence.cascade.result736)
  %5977 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5978 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5979 = add <8 x i64> %5978, splat (i64 192)
  %5980 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5977, 0
  %5981 = insertvalue { <8 x ptr>, <8 x i64> } %5980, <8 x i64> %5979, 1
  %5982 = extractvalue { <8 x ptr>, <8 x i64> } %5981, 0
  %5983 = extractvalue { <8 x ptr>, <8 x i64> } %5981, 1
  %5984 = getelementptr i8, <8 x ptr> %5982, <8 x i64> %5983
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5568, <8 x ptr> align 1 %5984, <8 x i1> %convergence.cascade.result736)
  %5985 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5986 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5987 = add <8 x i64> %5986, splat (i64 196)
  %5988 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5985, 0
  %5989 = insertvalue { <8 x ptr>, <8 x i64> } %5988, <8 x i64> %5987, 1
  %5990 = extractvalue { <8 x ptr>, <8 x i64> } %5989, 0
  %5991 = extractvalue { <8 x ptr>, <8 x i64> } %5989, 1
  %5992 = getelementptr i8, <8 x ptr> %5990, <8 x i64> %5991
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5569, <8 x ptr> align 1 %5992, <8 x i1> %convergence.cascade.result736)
  %5993 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %5994 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %5995 = add <8 x i64> %5994, splat (i64 200)
  %5996 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5993, 0
  %5997 = insertvalue { <8 x ptr>, <8 x i64> } %5996, <8 x i64> %5995, 1
  %5998 = extractvalue { <8 x ptr>, <8 x i64> } %5997, 0
  %5999 = extractvalue { <8 x ptr>, <8 x i64> } %5997, 1
  %6000 = getelementptr i8, <8 x ptr> %5998, <8 x i64> %5999
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5570, <8 x ptr> align 1 %6000, <8 x i1> %convergence.cascade.result736)
  %6001 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6002 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6003 = add <8 x i64> %6002, splat (i64 204)
  %6004 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6001, 0
  %6005 = insertvalue { <8 x ptr>, <8 x i64> } %6004, <8 x i64> %6003, 1
  %6006 = extractvalue { <8 x ptr>, <8 x i64> } %6005, 0
  %6007 = extractvalue { <8 x ptr>, <8 x i64> } %6005, 1
  %6008 = getelementptr i8, <8 x ptr> %6006, <8 x i64> %6007
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5571, <8 x ptr> align 1 %6008, <8 x i1> %convergence.cascade.result736)
  %6009 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6010 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6011 = add <8 x i64> %6010, splat (i64 208)
  %6012 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6009, 0
  %6013 = insertvalue { <8 x ptr>, <8 x i64> } %6012, <8 x i64> %6011, 1
  %6014 = extractvalue { <8 x ptr>, <8 x i64> } %6013, 0
  %6015 = extractvalue { <8 x ptr>, <8 x i64> } %6013, 1
  %6016 = getelementptr i8, <8 x ptr> %6014, <8 x i64> %6015
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5572, <8 x ptr> align 1 %6016, <8 x i1> %convergence.cascade.result736)
  %6017 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6018 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6019 = add <8 x i64> %6018, splat (i64 212)
  %6020 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6017, 0
  %6021 = insertvalue { <8 x ptr>, <8 x i64> } %6020, <8 x i64> %6019, 1
  %6022 = extractvalue { <8 x ptr>, <8 x i64> } %6021, 0
  %6023 = extractvalue { <8 x ptr>, <8 x i64> } %6021, 1
  %6024 = getelementptr i8, <8 x ptr> %6022, <8 x i64> %6023
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5573, <8 x ptr> align 1 %6024, <8 x i1> %convergence.cascade.result736)
  %6025 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6026 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6027 = add <8 x i64> %6026, splat (i64 216)
  %6028 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6025, 0
  %6029 = insertvalue { <8 x ptr>, <8 x i64> } %6028, <8 x i64> %6027, 1
  %6030 = extractvalue { <8 x ptr>, <8 x i64> } %6029, 0
  %6031 = extractvalue { <8 x ptr>, <8 x i64> } %6029, 1
  %6032 = getelementptr i8, <8 x ptr> %6030, <8 x i64> %6031
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5574, <8 x ptr> align 1 %6032, <8 x i1> %convergence.cascade.result736)
  %6033 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6034 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6035 = add <8 x i64> %6034, splat (i64 220)
  %6036 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6033, 0
  %6037 = insertvalue { <8 x ptr>, <8 x i64> } %6036, <8 x i64> %6035, 1
  %6038 = extractvalue { <8 x ptr>, <8 x i64> } %6037, 0
  %6039 = extractvalue { <8 x ptr>, <8 x i64> } %6037, 1
  %6040 = getelementptr i8, <8 x ptr> %6038, <8 x i64> %6039
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5575, <8 x ptr> align 1 %6040, <8 x i1> %convergence.cascade.result736)
  %6041 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6042 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6043 = add <8 x i64> %6042, splat (i64 224)
  %6044 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6041, 0
  %6045 = insertvalue { <8 x ptr>, <8 x i64> } %6044, <8 x i64> %6043, 1
  %6046 = extractvalue { <8 x ptr>, <8 x i64> } %6045, 0
  %6047 = extractvalue { <8 x ptr>, <8 x i64> } %6045, 1
  %6048 = getelementptr i8, <8 x ptr> %6046, <8 x i64> %6047
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5576, <8 x ptr> align 1 %6048, <8 x i1> %convergence.cascade.result736)
  %6049 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6050 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6051 = add <8 x i64> %6050, splat (i64 228)
  %6052 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6049, 0
  %6053 = insertvalue { <8 x ptr>, <8 x i64> } %6052, <8 x i64> %6051, 1
  %6054 = extractvalue { <8 x ptr>, <8 x i64> } %6053, 0
  %6055 = extractvalue { <8 x ptr>, <8 x i64> } %6053, 1
  %6056 = getelementptr i8, <8 x ptr> %6054, <8 x i64> %6055
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5577, <8 x ptr> align 1 %6056, <8 x i1> %convergence.cascade.result736)
  %6057 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6058 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6059 = add <8 x i64> %6058, splat (i64 232)
  %6060 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6057, 0
  %6061 = insertvalue { <8 x ptr>, <8 x i64> } %6060, <8 x i64> %6059, 1
  %6062 = extractvalue { <8 x ptr>, <8 x i64> } %6061, 0
  %6063 = extractvalue { <8 x ptr>, <8 x i64> } %6061, 1
  %6064 = getelementptr i8, <8 x ptr> %6062, <8 x i64> %6063
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5578, <8 x ptr> align 1 %6064, <8 x i1> %convergence.cascade.result736)
  %6065 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6066 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6067 = add <8 x i64> %6066, splat (i64 236)
  %6068 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6065, 0
  %6069 = insertvalue { <8 x ptr>, <8 x i64> } %6068, <8 x i64> %6067, 1
  %6070 = extractvalue { <8 x ptr>, <8 x i64> } %6069, 0
  %6071 = extractvalue { <8 x ptr>, <8 x i64> } %6069, 1
  %6072 = getelementptr i8, <8 x ptr> %6070, <8 x i64> %6071
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5579, <8 x ptr> align 1 %6072, <8 x i1> %convergence.cascade.result736)
  %6073 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6074 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6075 = add <8 x i64> %6074, splat (i64 240)
  %6076 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6073, 0
  %6077 = insertvalue { <8 x ptr>, <8 x i64> } %6076, <8 x i64> %6075, 1
  %6078 = extractvalue { <8 x ptr>, <8 x i64> } %6077, 0
  %6079 = extractvalue { <8 x ptr>, <8 x i64> } %6077, 1
  %6080 = getelementptr i8, <8 x ptr> %6078, <8 x i64> %6079
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5580, <8 x ptr> align 1 %6080, <8 x i1> %convergence.cascade.result736)
  %6081 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6082 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6083 = add <8 x i64> %6082, splat (i64 244)
  %6084 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6081, 0
  %6085 = insertvalue { <8 x ptr>, <8 x i64> } %6084, <8 x i64> %6083, 1
  %6086 = extractvalue { <8 x ptr>, <8 x i64> } %6085, 0
  %6087 = extractvalue { <8 x ptr>, <8 x i64> } %6085, 1
  %6088 = getelementptr i8, <8 x ptr> %6086, <8 x i64> %6087
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5581, <8 x ptr> align 1 %6088, <8 x i1> %convergence.cascade.result736)
  %6089 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6090 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6091 = add <8 x i64> %6090, splat (i64 248)
  %6092 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6089, 0
  %6093 = insertvalue { <8 x ptr>, <8 x i64> } %6092, <8 x i64> %6091, 1
  %6094 = extractvalue { <8 x ptr>, <8 x i64> } %6093, 0
  %6095 = extractvalue { <8 x ptr>, <8 x i64> } %6093, 1
  %6096 = getelementptr i8, <8 x ptr> %6094, <8 x i64> %6095
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5582, <8 x ptr> align 1 %6096, <8 x i1> %convergence.cascade.result736)
  %6097 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %6098 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %6099 = add <8 x i64> %6098, splat (i64 252)
  %6100 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6097, 0
  %6101 = insertvalue { <8 x ptr>, <8 x i64> } %6100, <8 x i64> %6099, 1
  %6102 = extractvalue { <8 x ptr>, <8 x i64> } %6101, 0
  %6103 = extractvalue { <8 x ptr>, <8 x i64> } %6101, 1
  %6104 = getelementptr i8, <8 x ptr> %6102, <8 x i64> %6103
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5583, <8 x ptr> align 1 %6104, <8 x i1> %convergence.cascade.result736)
  %.state952 = load <8 x float>, ptr %.slot62, align 32
  %6105 = fmul <8 x float> %.state952, %native.exp
  %6106 = load volatile <8 x float>, ptr %.spill218, align 32
  %6107 = select <8 x i1> %convergence.cascade.result736, <8 x float> %6105, <8 x float> %6106
  store volatile <8 x float> %6107, ptr %.spill218, align 32
  %.state953 = load <8 x float>, ptr %.slot63, align 32
  %6108 = fmul <8 x float> %.state953, %native.exp749
  %6109 = load volatile <8 x float>, ptr %.spill219, align 32
  %6110 = select <8 x i1> %convergence.cascade.result736, <8 x float> %6108, <8 x float> %6109
  store volatile <8 x float> %6110, ptr %.spill219, align 32
  %.state954 = load <8 x float>, ptr %.slot64, align 32
  %6111 = fmul <8 x float> %.state954, %native.exp750
  %6112 = load volatile <8 x float>, ptr %.spill220, align 32
  %6113 = select <8 x i1> %convergence.cascade.result736, <8 x float> %6111, <8 x float> %6112
  store volatile <8 x float> %6113, ptr %.spill220, align 32
  %.state955 = load <8 x float>, ptr %.slot65, align 32
  %6114 = fmul <8 x float> %.state955, %native.exp751
  %6115 = load volatile <8 x float>, ptr %.spill221, align 32
  %6116 = select <8 x i1> %convergence.cascade.result736, <8 x float> %6114, <8 x float> %6115
  store volatile <8 x float> %6116, ptr %.spill221, align 32
  %6117 = load <8 x i64>, ptr %.slot222, align 64
  %6118 = select <8 x i1> %convergence.cascade.result736, <8 x i64> zeroinitializer, <8 x i64> %6117
  store <8 x i64> %6118, ptr %.slot222, align 64
  %6119 = load <8 x float>, ptr %.slot223, align 32
  %6120 = select <8 x i1> %convergence.cascade.result736, <8 x float> zeroinitializer, <8 x float> %6119
  store <8 x float> %6120, ptr %.slot223, align 32
  store <8 x i1> %convergence.cascade.result736, ptr %current.mask, align 1
  %6121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result736)
  br i1 %6121, label %schedule.33, label %scheduler.loop

varying.divergent957:                             ; preds = %schedule.33
  %6122 = load i32, ptr %current.token, align 4
  %6123 = icmp ne i32 %6122, 0
  %6124 = sub i32 %6122, 1
  %6125 = select i1 %6123, i32 %6124, i32 0
  %6126 = load i8, ptr %frame.active, align 1
  %6127 = trunc i32 %6125 to i8
  %6128 = shl i8 1, %6127
  %6129 = and i8 %6126, %6128
  %6130 = icmp ne i8 %6129, 0
  %6131 = load <8 x i32>, ptr %frame.static.id, align 32
  %6132 = extractelement <8 x i32> %6131, i32 %6125
  %6133 = icmp eq i32 %6132, 12
  %6134 = and i1 %6130, %6133
  %6135 = and i1 %6123, %6134
  %6136 = xor i1 %6135, true
  %6137 = and i1 true, %6136
  %6138 = xor i8 %6126, -1
  %6139 = icmp ne i8 %6138, 0
  %6140 = xor i1 %6139, true
  %6141 = and i1 %6137, %6140
  br i1 %6141, label %convergence.overflow.trap959, label %convergence.overflow.resume960

varying.coherent958:                              ; preds = %schedule.33
  br i1 %600, label %varying.coherent.true963, label %varying.coherent.false964

convergence.overflow.trap959:                     ; preds = %varying.divergent957
  call void @llvm.trap()
  unreachable

convergence.overflow.resume960:                   ; preds = %varying.divergent957
  %6142 = call i8 @llvm.cttz.i8(i8 %6138, i1 false)
  %6143 = zext i8 %6142 to i32
  %6144 = select i1 %6139, i32 %6143, i32 0
  %6145 = trunc i32 %6144 to i8
  %6146 = shl i8 1, %6145
  %6147 = or i8 %6126, %6146
  %6148 = select i1 %6137, i8 %6147, i8 %6126
  store i8 %6148, ptr %frame.active, align 1
  %6149 = load <8 x i32>, ptr %frame.static.id, align 32
  %6150 = extractelement <8 x i32> %6149, i32 %6144
  %6151 = select i1 %6137, i32 12, i32 %6150
  %6152 = load <8 x i32>, ptr %frame.static.id, align 32
  %6153 = insertelement <8 x i32> %6152, i32 %6151, i32 %6144
  store <8 x i32> %6153, ptr %frame.static.id, align 32
  %6154 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6155 = extractelement <8 x i32> %6154, i32 %6144
  %6156 = select i1 %6137, i32 %6122, i32 %6155
  %6157 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6158 = insertelement <8 x i32> %6157, i32 %6156, i32 %6144
  store <8 x i32> %6158, ptr %frame.parent.token, align 32
  %6159 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6144
  %6160 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6144
  %6161 = load <8 x i1>, ptr %6159, align 1
  %6162 = load <8 x i1>, ptr %6160, align 1
  %6163 = select i1 %6137, <8 x i1> %590, <8 x i1> %6161
  store <8 x i1> %6163, ptr %6159, align 1
  %6164 = select i1 %6137, <8 x i1> zeroinitializer, <8 x i1> %6162
  store <8 x i1> %6164, ptr %6160, align 1
  %6165 = add i32 %6144, 1
  %6166 = select i1 %6135, i32 %6122, i32 %6165
  %6167 = select i1 true, i32 %6166, i32 %6122
  store i32 %6167, ptr %current.token, align 4
  %6168 = load i32, ptr %current.token, align 4
  %6169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %597)
  %6170 = load i32, ptr %ready.count, align 4
  %6171 = icmp uge i32 %6170, 8
  %6172 = and i1 %6169, %6171
  br i1 %6172, label %ready.overflow.trap961, label %ready.overflow.resume962

ready.overflow.trap961:                           ; preds = %convergence.overflow.resume960
  call void @llvm.trap()
  unreachable

ready.overflow.resume962:                         ; preds = %convergence.overflow.resume960
  %6173 = select i1 %6169, i32 %6170, i32 0
  %6174 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6173
  %6175 = load <8 x i1>, ptr %6174, align 1
  %6176 = select i1 %6169, <8 x i1> %597, <8 x i1> %6175
  store <8 x i1> %6176, ptr %6174, align 1
  %6177 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6173
  %6178 = load i32, ptr %6177, align 4
  %6179 = select i1 %6169, i32 34, i32 %6178
  store i32 %6179, ptr %6177, align 4
  %6180 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6173
  %6181 = load i32, ptr %6180, align 4
  %6182 = select i1 %6169, i32 %6168, i32 %6181
  store i32 %6182, ptr %6180, align 4
  %6183 = add i32 %6170, 1
  %6184 = select i1 %6169, i32 %6183, i32 %6170
  store i32 %6184, ptr %ready.count, align 4
  %6185 = load <8 x i1>, ptr %runnable.mask, align 1
  %6186 = or <8 x i1> %6185, %597
  store <8 x i1> %6186, ptr %runnable.mask, align 1
  store <8 x i1> %599, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true963:                         ; preds = %varying.coherent958
  store <8 x i1> %590, ptr %current.mask, align 1
  %6187 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %590)
  br i1 %6187, label %schedule.34, label %scheduler.loop

varying.coherent.false964:                        ; preds = %varying.coherent958
  store <8 x i1> %590, ptr %current.mask, align 1
  %6188 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %590)
  br i1 %6188, label %schedule.35, label %scheduler.loop

convergence.cascade969:                           ; preds = %convergence.cascade969, %schedule.35
  %convergence.cascade.flow973 = phi <8 x i1> [ %630, %schedule.35 ], [ %6231, %convergence.cascade969 ]
  %convergence.cascade.depth974 = phi i32 [ 0, %schedule.35 ], [ %6232, %convergence.cascade969 ]
  %6189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow973)
  %6190 = load i32, ptr %current.token, align 4
  %6191 = icmp ne i32 %6190, 0
  %6192 = and i1 %6189, %6191
  %6193 = sub i32 %6190, 1
  %6194 = select i1 %6192, i32 %6193, i32 0
  %6195 = load i8, ptr %frame.active, align 1
  %6196 = trunc i32 %6194 to i8
  %6197 = shl i8 1, %6196
  %6198 = and i8 %6195, %6197
  %6199 = icmp ne i8 %6198, 0
  %6200 = load <8 x i32>, ptr %frame.static.id, align 32
  %6201 = extractelement <8 x i32> %6200, i32 %6194
  %convergence.target.pointer975 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %6201
  %convergence.dynamic.target976 = load i32, ptr %convergence.target.pointer975, align 4
  %6202 = icmp eq i32 %convergence.dynamic.target976, 35
  %6203 = and i1 %6199, %6202
  %6204 = and i1 %6192, %6203
  %6205 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6194
  %6206 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6194
  %6207 = load <8 x i1>, ptr %6205, align 1
  %6208 = load <8 x i1>, ptr %6206, align 1
  %6209 = or <8 x i1> %6208, %convergence.cascade.flow973
  %6210 = load <8 x i1>, ptr %live.mask, align 1
  %6211 = and <8 x i1> %6207, %6210
  %6212 = icmp eq <8 x i1> %6209, %6211
  %6213 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6212)
  %6214 = and i1 %6204, %6213
  %6215 = select i1 %6214, <8 x i1> zeroinitializer, <8 x i1> %6209
  %6216 = select i1 %6204, <8 x i1> %6215, <8 x i1> %6208
  store <8 x i1> %6216, ptr %6206, align 1
  %6217 = select i1 %6214, <8 x i1> zeroinitializer, <8 x i1> %6207
  store <8 x i1> %6217, ptr %6205, align 1
  %6218 = trunc i32 %6194 to i8
  %6219 = shl i8 1, %6218
  %6220 = xor i8 %6219, -1
  %6221 = and i8 %6195, %6220
  %6222 = select i1 %6214, i8 %6221, i8 %6195
  store i8 %6222, ptr %frame.active, align 1
  %.splatinsert977 = insertelement <8 x i1> poison, i1 %6204, i64 0
  %.splat978 = shufflevector <8 x i1> %.splatinsert977, <8 x i1> poison, <8 x i32> zeroinitializer
  %6223 = and <8 x i1> %convergence.cascade.flow973, %.splat978
  %6224 = load <8 x i1>, ptr %runnable.mask, align 1
  %6225 = xor <8 x i1> %6223, splat (i1 true)
  %6226 = and <8 x i1> %6224, %6225
  store <8 x i1> %6226, ptr %runnable.mask, align 1
  %.splatinsert979 = insertelement <8 x i1> poison, i1 %6214, i64 0
  %.splat980 = shufflevector <8 x i1> %.splatinsert979, <8 x i1> poison, <8 x i32> zeroinitializer
  %6227 = select <8 x i1> %.splat980, <8 x i1> %6209, <8 x i1> zeroinitializer
  %6228 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6229 = extractelement <8 x i32> %6228, i32 %6194
  %6230 = select i1 %6214, i32 %6229, i32 %6190
  store i32 %6230, ptr %current.token, align 4
  %.splatinsert981 = insertelement <8 x i1> poison, i1 %6204, i64 0
  %.splat982 = shufflevector <8 x i1> %.splatinsert981, <8 x i1> poison, <8 x i32> zeroinitializer
  %6231 = select <8 x i1> %.splat982, <8 x i1> %6227, <8 x i1> %convergence.cascade.flow973
  %6232 = add i32 %convergence.cascade.depth974, 1
  %6233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6231)
  %6234 = icmp ult i32 %6232, 8
  %6235 = and i1 %6233, %6234
  %6236 = and i1 %6204, %6235
  %convergence.parent.token983 = load i32, ptr %current.token, align 4
  %convergence.parent.present984 = icmp ne i32 %convergence.parent.token983, 0
  %6237 = and i1 %6236, %convergence.parent.present984
  br i1 %6237, label %convergence.cascade969, label %convergence.cascade.exit970

convergence.cascade.exit970:                      ; preds = %convergence.cascade969, %schedule.35
  %convergence.cascade.result985 = phi <8 x i1> [ %630, %schedule.35 ], [ %6231, %convergence.cascade969 ]
  %6238 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result985)
  br i1 %6238, label %convergence.target.35.ready, label %scheduler.loop

convergence.target.35.ready:                      ; preds = %convergence.cascade.exit970
  %6239 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result985)
  %6240 = bitcast <8 x i1> %convergence.cascade.result985 to i8
  %6241 = call i8 @llvm.cttz.i8(i8 %6240, i1 false)
  %6242 = zext i8 %6241 to i32
  %6243 = select i1 %6239, i32 %6242, i32 0
  %6244 = load <8 x i64>, ptr %.slot224, align 64
  %6245 = select <8 x i1> %convergence.cascade.result985, <8 x i64> zeroinitializer, <8 x i64> %6244
  store <8 x i64> %6245, ptr %.slot224, align 64
  %6246 = load <8 x float>, ptr %.slot225, align 32
  %6247 = select <8 x i1> %convergence.cascade.result985, <8 x float> zeroinitializer, <8 x float> %6246
  store <8 x float> %6247, ptr %.slot225, align 32
  store <8 x i1> %convergence.cascade.result985, ptr %current.mask, align 1
  %6248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result985)
  br i1 %6248, label %schedule.36, label %scheduler.loop

varying.divergent987:                             ; preds = %schedule.36
  %6249 = load i32, ptr %current.token, align 4
  %6250 = icmp ne i32 %6249, 0
  %6251 = sub i32 %6249, 1
  %6252 = select i1 %6250, i32 %6251, i32 0
  %6253 = load i8, ptr %frame.active, align 1
  %6254 = trunc i32 %6252 to i8
  %6255 = shl i8 1, %6254
  %6256 = and i8 %6253, %6255
  %6257 = icmp ne i8 %6256, 0
  %6258 = load <8 x i32>, ptr %frame.static.id, align 32
  %6259 = extractelement <8 x i32> %6258, i32 %6252
  %6260 = icmp eq i32 %6259, 13
  %6261 = and i1 %6257, %6260
  %6262 = and i1 %6250, %6261
  %6263 = xor i1 %6262, true
  %6264 = and i1 true, %6263
  %6265 = xor i8 %6253, -1
  %6266 = icmp ne i8 %6265, 0
  %6267 = xor i1 %6266, true
  %6268 = and i1 %6264, %6267
  br i1 %6268, label %convergence.overflow.trap989, label %convergence.overflow.resume990

varying.coherent988:                              ; preds = %schedule.36
  br i1 %641, label %varying.coherent.true993, label %varying.coherent.false994

convergence.overflow.trap989:                     ; preds = %varying.divergent987
  call void @llvm.trap()
  unreachable

convergence.overflow.resume990:                   ; preds = %varying.divergent987
  %6269 = call i8 @llvm.cttz.i8(i8 %6265, i1 false)
  %6270 = zext i8 %6269 to i32
  %6271 = select i1 %6266, i32 %6270, i32 0
  %6272 = trunc i32 %6271 to i8
  %6273 = shl i8 1, %6272
  %6274 = or i8 %6253, %6273
  %6275 = select i1 %6264, i8 %6274, i8 %6253
  store i8 %6275, ptr %frame.active, align 1
  %6276 = load <8 x i32>, ptr %frame.static.id, align 32
  %6277 = extractelement <8 x i32> %6276, i32 %6271
  %6278 = select i1 %6264, i32 13, i32 %6277
  %6279 = load <8 x i32>, ptr %frame.static.id, align 32
  %6280 = insertelement <8 x i32> %6279, i32 %6278, i32 %6271
  store <8 x i32> %6280, ptr %frame.static.id, align 32
  %6281 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6282 = extractelement <8 x i32> %6281, i32 %6271
  %6283 = select i1 %6264, i32 %6249, i32 %6282
  %6284 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6285 = insertelement <8 x i32> %6284, i32 %6283, i32 %6271
  store <8 x i32> %6285, ptr %frame.parent.token, align 32
  %6286 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6271
  %6287 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6271
  %6288 = load <8 x i1>, ptr %6286, align 1
  %6289 = load <8 x i1>, ptr %6287, align 1
  %6290 = select i1 %6264, <8 x i1> %631, <8 x i1> %6288
  store <8 x i1> %6290, ptr %6286, align 1
  %6291 = select i1 %6264, <8 x i1> zeroinitializer, <8 x i1> %6289
  store <8 x i1> %6291, ptr %6287, align 1
  %6292 = add i32 %6271, 1
  %6293 = select i1 %6262, i32 %6249, i32 %6292
  %6294 = select i1 true, i32 %6293, i32 %6249
  store i32 %6294, ptr %current.token, align 4
  %6295 = load i32, ptr %current.token, align 4
  %6296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %638)
  %6297 = load i32, ptr %ready.count, align 4
  %6298 = icmp uge i32 %6297, 8
  %6299 = and i1 %6296, %6298
  br i1 %6299, label %ready.overflow.trap991, label %ready.overflow.resume992

ready.overflow.trap991:                           ; preds = %convergence.overflow.resume990
  call void @llvm.trap()
  unreachable

ready.overflow.resume992:                         ; preds = %convergence.overflow.resume990
  %6300 = select i1 %6296, i32 %6297, i32 0
  %6301 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6300
  %6302 = load <8 x i1>, ptr %6301, align 1
  %6303 = select i1 %6296, <8 x i1> %638, <8 x i1> %6302
  store <8 x i1> %6303, ptr %6301, align 1
  %6304 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6300
  %6305 = load i32, ptr %6304, align 4
  %6306 = select i1 %6296, i32 37, i32 %6305
  store i32 %6306, ptr %6304, align 4
  %6307 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6300
  %6308 = load i32, ptr %6307, align 4
  %6309 = select i1 %6296, i32 %6295, i32 %6308
  store i32 %6309, ptr %6307, align 4
  %6310 = add i32 %6297, 1
  %6311 = select i1 %6296, i32 %6310, i32 %6297
  store i32 %6311, ptr %ready.count, align 4
  %6312 = load <8 x i1>, ptr %runnable.mask, align 1
  %6313 = or <8 x i1> %6312, %638
  store <8 x i1> %6313, ptr %runnable.mask, align 1
  store <8 x i1> %640, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true993:                         ; preds = %varying.coherent988
  store <8 x i1> %631, ptr %current.mask, align 1
  %6314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %631)
  br i1 %6314, label %schedule.37, label %scheduler.loop

varying.coherent.false994:                        ; preds = %varying.coherent988
  store <8 x i1> %631, ptr %current.mask, align 1
  %6315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %631)
  br i1 %6315, label %schedule.38, label %scheduler.loop

convergence.cascade999:                           ; preds = %convergence.cascade999, %schedule.38
  %convergence.cascade.flow1003 = phi <8 x i1> [ %671, %schedule.38 ], [ %6358, %convergence.cascade999 ]
  %convergence.cascade.depth1004 = phi i32 [ 0, %schedule.38 ], [ %6359, %convergence.cascade999 ]
  %6316 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1003)
  %6317 = load i32, ptr %current.token, align 4
  %6318 = icmp ne i32 %6317, 0
  %6319 = and i1 %6316, %6318
  %6320 = sub i32 %6317, 1
  %6321 = select i1 %6319, i32 %6320, i32 0
  %6322 = load i8, ptr %frame.active, align 1
  %6323 = trunc i32 %6321 to i8
  %6324 = shl i8 1, %6323
  %6325 = and i8 %6322, %6324
  %6326 = icmp ne i8 %6325, 0
  %6327 = load <8 x i32>, ptr %frame.static.id, align 32
  %6328 = extractelement <8 x i32> %6327, i32 %6321
  %convergence.target.pointer1005 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %6328
  %convergence.dynamic.target1006 = load i32, ptr %convergence.target.pointer1005, align 4
  %6329 = icmp eq i32 %convergence.dynamic.target1006, 38
  %6330 = and i1 %6326, %6329
  %6331 = and i1 %6319, %6330
  %6332 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6321
  %6333 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6321
  %6334 = load <8 x i1>, ptr %6332, align 1
  %6335 = load <8 x i1>, ptr %6333, align 1
  %6336 = or <8 x i1> %6335, %convergence.cascade.flow1003
  %6337 = load <8 x i1>, ptr %live.mask, align 1
  %6338 = and <8 x i1> %6334, %6337
  %6339 = icmp eq <8 x i1> %6336, %6338
  %6340 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6339)
  %6341 = and i1 %6331, %6340
  %6342 = select i1 %6341, <8 x i1> zeroinitializer, <8 x i1> %6336
  %6343 = select i1 %6331, <8 x i1> %6342, <8 x i1> %6335
  store <8 x i1> %6343, ptr %6333, align 1
  %6344 = select i1 %6341, <8 x i1> zeroinitializer, <8 x i1> %6334
  store <8 x i1> %6344, ptr %6332, align 1
  %6345 = trunc i32 %6321 to i8
  %6346 = shl i8 1, %6345
  %6347 = xor i8 %6346, -1
  %6348 = and i8 %6322, %6347
  %6349 = select i1 %6341, i8 %6348, i8 %6322
  store i8 %6349, ptr %frame.active, align 1
  %.splatinsert1007 = insertelement <8 x i1> poison, i1 %6331, i64 0
  %.splat1008 = shufflevector <8 x i1> %.splatinsert1007, <8 x i1> poison, <8 x i32> zeroinitializer
  %6350 = and <8 x i1> %convergence.cascade.flow1003, %.splat1008
  %6351 = load <8 x i1>, ptr %runnable.mask, align 1
  %6352 = xor <8 x i1> %6350, splat (i1 true)
  %6353 = and <8 x i1> %6351, %6352
  store <8 x i1> %6353, ptr %runnable.mask, align 1
  %.splatinsert1009 = insertelement <8 x i1> poison, i1 %6341, i64 0
  %.splat1010 = shufflevector <8 x i1> %.splatinsert1009, <8 x i1> poison, <8 x i32> zeroinitializer
  %6354 = select <8 x i1> %.splat1010, <8 x i1> %6336, <8 x i1> zeroinitializer
  %6355 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6356 = extractelement <8 x i32> %6355, i32 %6321
  %6357 = select i1 %6341, i32 %6356, i32 %6317
  store i32 %6357, ptr %current.token, align 4
  %.splatinsert1011 = insertelement <8 x i1> poison, i1 %6331, i64 0
  %.splat1012 = shufflevector <8 x i1> %.splatinsert1011, <8 x i1> poison, <8 x i32> zeroinitializer
  %6358 = select <8 x i1> %.splat1012, <8 x i1> %6354, <8 x i1> %convergence.cascade.flow1003
  %6359 = add i32 %convergence.cascade.depth1004, 1
  %6360 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6358)
  %6361 = icmp ult i32 %6359, 8
  %6362 = and i1 %6360, %6361
  %6363 = and i1 %6331, %6362
  %convergence.parent.token1013 = load i32, ptr %current.token, align 4
  %convergence.parent.present1014 = icmp ne i32 %convergence.parent.token1013, 0
  %6364 = and i1 %6363, %convergence.parent.present1014
  br i1 %6364, label %convergence.cascade999, label %convergence.cascade.exit1000

convergence.cascade.exit1000:                     ; preds = %convergence.cascade999, %schedule.38
  %convergence.cascade.result1015 = phi <8 x i1> [ %671, %schedule.38 ], [ %6358, %convergence.cascade999 ]
  %6365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1015)
  br i1 %6365, label %convergence.target.38.ready, label %scheduler.loop

convergence.target.38.ready:                      ; preds = %convergence.cascade.exit1000
  %6366 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1015)
  %6367 = bitcast <8 x i1> %convergence.cascade.result1015 to i8
  %6368 = call i8 @llvm.cttz.i8(i8 %6367, i1 false)
  %6369 = zext i8 %6368 to i32
  %6370 = select i1 %6366, i32 %6369, i32 0
  %6371 = load <8 x i64>, ptr %.slot226, align 64
  %6372 = select <8 x i1> %convergence.cascade.result1015, <8 x i64> zeroinitializer, <8 x i64> %6371
  store <8 x i64> %6372, ptr %.slot226, align 64
  %6373 = load <8 x float>, ptr %.slot227, align 32
  %6374 = select <8 x i1> %convergence.cascade.result1015, <8 x float> zeroinitializer, <8 x float> %6373
  store <8 x float> %6374, ptr %.slot227, align 32
  store <8 x i1> %convergence.cascade.result1015, ptr %current.mask, align 1
  %6375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1015)
  br i1 %6375, label %schedule.39, label %scheduler.loop

varying.divergent1017:                            ; preds = %schedule.39
  %6376 = load i32, ptr %current.token, align 4
  %6377 = icmp ne i32 %6376, 0
  %6378 = sub i32 %6376, 1
  %6379 = select i1 %6377, i32 %6378, i32 0
  %6380 = load i8, ptr %frame.active, align 1
  %6381 = trunc i32 %6379 to i8
  %6382 = shl i8 1, %6381
  %6383 = and i8 %6380, %6382
  %6384 = icmp ne i8 %6383, 0
  %6385 = load <8 x i32>, ptr %frame.static.id, align 32
  %6386 = extractelement <8 x i32> %6385, i32 %6379
  %6387 = icmp eq i32 %6386, 14
  %6388 = and i1 %6384, %6387
  %6389 = and i1 %6377, %6388
  %6390 = xor i1 %6389, true
  %6391 = and i1 true, %6390
  %6392 = xor i8 %6380, -1
  %6393 = icmp ne i8 %6392, 0
  %6394 = xor i1 %6393, true
  %6395 = and i1 %6391, %6394
  br i1 %6395, label %convergence.overflow.trap1019, label %convergence.overflow.resume1020

varying.coherent1018:                             ; preds = %schedule.39
  br i1 %682, label %varying.coherent.true1023, label %varying.coherent.false1024

convergence.overflow.trap1019:                    ; preds = %varying.divergent1017
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1020:                  ; preds = %varying.divergent1017
  %6396 = call i8 @llvm.cttz.i8(i8 %6392, i1 false)
  %6397 = zext i8 %6396 to i32
  %6398 = select i1 %6393, i32 %6397, i32 0
  %6399 = trunc i32 %6398 to i8
  %6400 = shl i8 1, %6399
  %6401 = or i8 %6380, %6400
  %6402 = select i1 %6391, i8 %6401, i8 %6380
  store i8 %6402, ptr %frame.active, align 1
  %6403 = load <8 x i32>, ptr %frame.static.id, align 32
  %6404 = extractelement <8 x i32> %6403, i32 %6398
  %6405 = select i1 %6391, i32 14, i32 %6404
  %6406 = load <8 x i32>, ptr %frame.static.id, align 32
  %6407 = insertelement <8 x i32> %6406, i32 %6405, i32 %6398
  store <8 x i32> %6407, ptr %frame.static.id, align 32
  %6408 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6409 = extractelement <8 x i32> %6408, i32 %6398
  %6410 = select i1 %6391, i32 %6376, i32 %6409
  %6411 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6412 = insertelement <8 x i32> %6411, i32 %6410, i32 %6398
  store <8 x i32> %6412, ptr %frame.parent.token, align 32
  %6413 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6398
  %6414 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6398
  %6415 = load <8 x i1>, ptr %6413, align 1
  %6416 = load <8 x i1>, ptr %6414, align 1
  %6417 = select i1 %6391, <8 x i1> %672, <8 x i1> %6415
  store <8 x i1> %6417, ptr %6413, align 1
  %6418 = select i1 %6391, <8 x i1> zeroinitializer, <8 x i1> %6416
  store <8 x i1> %6418, ptr %6414, align 1
  %6419 = add i32 %6398, 1
  %6420 = select i1 %6389, i32 %6376, i32 %6419
  %6421 = select i1 true, i32 %6420, i32 %6376
  store i32 %6421, ptr %current.token, align 4
  %6422 = load i32, ptr %current.token, align 4
  %6423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %679)
  %6424 = load i32, ptr %ready.count, align 4
  %6425 = icmp uge i32 %6424, 8
  %6426 = and i1 %6423, %6425
  br i1 %6426, label %ready.overflow.trap1021, label %ready.overflow.resume1022

ready.overflow.trap1021:                          ; preds = %convergence.overflow.resume1020
  call void @llvm.trap()
  unreachable

ready.overflow.resume1022:                        ; preds = %convergence.overflow.resume1020
  %6427 = select i1 %6423, i32 %6424, i32 0
  %6428 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6427
  %6429 = load <8 x i1>, ptr %6428, align 1
  %6430 = select i1 %6423, <8 x i1> %679, <8 x i1> %6429
  store <8 x i1> %6430, ptr %6428, align 1
  %6431 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6427
  %6432 = load i32, ptr %6431, align 4
  %6433 = select i1 %6423, i32 40, i32 %6432
  store i32 %6433, ptr %6431, align 4
  %6434 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6427
  %6435 = load i32, ptr %6434, align 4
  %6436 = select i1 %6423, i32 %6422, i32 %6435
  store i32 %6436, ptr %6434, align 4
  %6437 = add i32 %6424, 1
  %6438 = select i1 %6423, i32 %6437, i32 %6424
  store i32 %6438, ptr %ready.count, align 4
  %6439 = load <8 x i1>, ptr %runnable.mask, align 1
  %6440 = or <8 x i1> %6439, %679
  store <8 x i1> %6440, ptr %runnable.mask, align 1
  store <8 x i1> %681, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1023:                        ; preds = %varying.coherent1018
  store <8 x i1> %672, ptr %current.mask, align 1
  %6441 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %672)
  br i1 %6441, label %schedule.40, label %scheduler.loop

varying.coherent.false1024:                       ; preds = %varying.coherent1018
  store <8 x i1> %672, ptr %current.mask, align 1
  %6442 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %672)
  br i1 %6442, label %schedule.41, label %scheduler.loop

convergence.cascade1029:                          ; preds = %convergence.cascade1029, %schedule.41
  %convergence.cascade.flow1033 = phi <8 x i1> [ %712, %schedule.41 ], [ %6485, %convergence.cascade1029 ]
  %convergence.cascade.depth1034 = phi i32 [ 0, %schedule.41 ], [ %6486, %convergence.cascade1029 ]
  %6443 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1033)
  %6444 = load i32, ptr %current.token, align 4
  %6445 = icmp ne i32 %6444, 0
  %6446 = and i1 %6443, %6445
  %6447 = sub i32 %6444, 1
  %6448 = select i1 %6446, i32 %6447, i32 0
  %6449 = load i8, ptr %frame.active, align 1
  %6450 = trunc i32 %6448 to i8
  %6451 = shl i8 1, %6450
  %6452 = and i8 %6449, %6451
  %6453 = icmp ne i8 %6452, 0
  %6454 = load <8 x i32>, ptr %frame.static.id, align 32
  %6455 = extractelement <8 x i32> %6454, i32 %6448
  %convergence.target.pointer1035 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %6455
  %convergence.dynamic.target1036 = load i32, ptr %convergence.target.pointer1035, align 4
  %6456 = icmp eq i32 %convergence.dynamic.target1036, 41
  %6457 = and i1 %6453, %6456
  %6458 = and i1 %6446, %6457
  %6459 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6448
  %6460 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6448
  %6461 = load <8 x i1>, ptr %6459, align 1
  %6462 = load <8 x i1>, ptr %6460, align 1
  %6463 = or <8 x i1> %6462, %convergence.cascade.flow1033
  %6464 = load <8 x i1>, ptr %live.mask, align 1
  %6465 = and <8 x i1> %6461, %6464
  %6466 = icmp eq <8 x i1> %6463, %6465
  %6467 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6466)
  %6468 = and i1 %6458, %6467
  %6469 = select i1 %6468, <8 x i1> zeroinitializer, <8 x i1> %6463
  %6470 = select i1 %6458, <8 x i1> %6469, <8 x i1> %6462
  store <8 x i1> %6470, ptr %6460, align 1
  %6471 = select i1 %6468, <8 x i1> zeroinitializer, <8 x i1> %6461
  store <8 x i1> %6471, ptr %6459, align 1
  %6472 = trunc i32 %6448 to i8
  %6473 = shl i8 1, %6472
  %6474 = xor i8 %6473, -1
  %6475 = and i8 %6449, %6474
  %6476 = select i1 %6468, i8 %6475, i8 %6449
  store i8 %6476, ptr %frame.active, align 1
  %.splatinsert1037 = insertelement <8 x i1> poison, i1 %6458, i64 0
  %.splat1038 = shufflevector <8 x i1> %.splatinsert1037, <8 x i1> poison, <8 x i32> zeroinitializer
  %6477 = and <8 x i1> %convergence.cascade.flow1033, %.splat1038
  %6478 = load <8 x i1>, ptr %runnable.mask, align 1
  %6479 = xor <8 x i1> %6477, splat (i1 true)
  %6480 = and <8 x i1> %6478, %6479
  store <8 x i1> %6480, ptr %runnable.mask, align 1
  %.splatinsert1039 = insertelement <8 x i1> poison, i1 %6468, i64 0
  %.splat1040 = shufflevector <8 x i1> %.splatinsert1039, <8 x i1> poison, <8 x i32> zeroinitializer
  %6481 = select <8 x i1> %.splat1040, <8 x i1> %6463, <8 x i1> zeroinitializer
  %6482 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6483 = extractelement <8 x i32> %6482, i32 %6448
  %6484 = select i1 %6468, i32 %6483, i32 %6444
  store i32 %6484, ptr %current.token, align 4
  %.splatinsert1041 = insertelement <8 x i1> poison, i1 %6458, i64 0
  %.splat1042 = shufflevector <8 x i1> %.splatinsert1041, <8 x i1> poison, <8 x i32> zeroinitializer
  %6485 = select <8 x i1> %.splat1042, <8 x i1> %6481, <8 x i1> %convergence.cascade.flow1033
  %6486 = add i32 %convergence.cascade.depth1034, 1
  %6487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6485)
  %6488 = icmp ult i32 %6486, 8
  %6489 = and i1 %6487, %6488
  %6490 = and i1 %6458, %6489
  %convergence.parent.token1043 = load i32, ptr %current.token, align 4
  %convergence.parent.present1044 = icmp ne i32 %convergence.parent.token1043, 0
  %6491 = and i1 %6490, %convergence.parent.present1044
  br i1 %6491, label %convergence.cascade1029, label %convergence.cascade.exit1030

convergence.cascade.exit1030:                     ; preds = %convergence.cascade1029, %schedule.41
  %convergence.cascade.result1045 = phi <8 x i1> [ %712, %schedule.41 ], [ %6485, %convergence.cascade1029 ]
  %6492 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1045)
  br i1 %6492, label %convergence.target.41.ready, label %scheduler.loop

convergence.target.41.ready:                      ; preds = %convergence.cascade.exit1030
  %6493 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1045)
  %6494 = bitcast <8 x i1> %convergence.cascade.result1045 to i8
  %6495 = call i8 @llvm.cttz.i8(i8 %6494, i1 false)
  %6496 = zext i8 %6495 to i32
  %6497 = select i1 %6493, i32 %6496, i32 0
  %6498 = load <8 x i64>, ptr %.slot228, align 64
  %6499 = select <8 x i1> %convergence.cascade.result1045, <8 x i64> zeroinitializer, <8 x i64> %6498
  store <8 x i64> %6499, ptr %.slot228, align 64
  %6500 = load <8 x float>, ptr %.slot229, align 32
  %6501 = select <8 x i1> %convergence.cascade.result1045, <8 x float> zeroinitializer, <8 x float> %6500
  store <8 x float> %6501, ptr %.slot229, align 32
  store <8 x i1> %convergence.cascade.result1045, ptr %current.mask, align 1
  %6502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1045)
  br i1 %6502, label %schedule.42, label %scheduler.loop

varying.divergent1047:                            ; preds = %schedule.42
  %6503 = load i32, ptr %current.token, align 4
  %6504 = icmp ne i32 %6503, 0
  %6505 = sub i32 %6503, 1
  %6506 = select i1 %6504, i32 %6505, i32 0
  %6507 = load i8, ptr %frame.active, align 1
  %6508 = trunc i32 %6506 to i8
  %6509 = shl i8 1, %6508
  %6510 = and i8 %6507, %6509
  %6511 = icmp ne i8 %6510, 0
  %6512 = load <8 x i32>, ptr %frame.static.id, align 32
  %6513 = extractelement <8 x i32> %6512, i32 %6506
  %6514 = icmp eq i32 %6513, 15
  %6515 = and i1 %6511, %6514
  %6516 = and i1 %6504, %6515
  %6517 = xor i1 %6516, true
  %6518 = and i1 true, %6517
  %6519 = xor i8 %6507, -1
  %6520 = icmp ne i8 %6519, 0
  %6521 = xor i1 %6520, true
  %6522 = and i1 %6518, %6521
  br i1 %6522, label %convergence.overflow.trap1049, label %convergence.overflow.resume1050

varying.coherent1048:                             ; preds = %schedule.42
  br i1 %723, label %varying.coherent.true1053, label %varying.coherent.false1054

convergence.overflow.trap1049:                    ; preds = %varying.divergent1047
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1050:                  ; preds = %varying.divergent1047
  %6523 = call i8 @llvm.cttz.i8(i8 %6519, i1 false)
  %6524 = zext i8 %6523 to i32
  %6525 = select i1 %6520, i32 %6524, i32 0
  %6526 = trunc i32 %6525 to i8
  %6527 = shl i8 1, %6526
  %6528 = or i8 %6507, %6527
  %6529 = select i1 %6518, i8 %6528, i8 %6507
  store i8 %6529, ptr %frame.active, align 1
  %6530 = load <8 x i32>, ptr %frame.static.id, align 32
  %6531 = extractelement <8 x i32> %6530, i32 %6525
  %6532 = select i1 %6518, i32 15, i32 %6531
  %6533 = load <8 x i32>, ptr %frame.static.id, align 32
  %6534 = insertelement <8 x i32> %6533, i32 %6532, i32 %6525
  store <8 x i32> %6534, ptr %frame.static.id, align 32
  %6535 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6536 = extractelement <8 x i32> %6535, i32 %6525
  %6537 = select i1 %6518, i32 %6503, i32 %6536
  %6538 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6539 = insertelement <8 x i32> %6538, i32 %6537, i32 %6525
  store <8 x i32> %6539, ptr %frame.parent.token, align 32
  %6540 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6525
  %6541 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6525
  %6542 = load <8 x i1>, ptr %6540, align 1
  %6543 = load <8 x i1>, ptr %6541, align 1
  %6544 = select i1 %6518, <8 x i1> %713, <8 x i1> %6542
  store <8 x i1> %6544, ptr %6540, align 1
  %6545 = select i1 %6518, <8 x i1> zeroinitializer, <8 x i1> %6543
  store <8 x i1> %6545, ptr %6541, align 1
  %6546 = add i32 %6525, 1
  %6547 = select i1 %6516, i32 %6503, i32 %6546
  %6548 = select i1 true, i32 %6547, i32 %6503
  store i32 %6548, ptr %current.token, align 4
  %6549 = load i32, ptr %current.token, align 4
  %6550 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %720)
  %6551 = load i32, ptr %ready.count, align 4
  %6552 = icmp uge i32 %6551, 8
  %6553 = and i1 %6550, %6552
  br i1 %6553, label %ready.overflow.trap1051, label %ready.overflow.resume1052

ready.overflow.trap1051:                          ; preds = %convergence.overflow.resume1050
  call void @llvm.trap()
  unreachable

ready.overflow.resume1052:                        ; preds = %convergence.overflow.resume1050
  %6554 = select i1 %6550, i32 %6551, i32 0
  %6555 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6554
  %6556 = load <8 x i1>, ptr %6555, align 1
  %6557 = select i1 %6550, <8 x i1> %720, <8 x i1> %6556
  store <8 x i1> %6557, ptr %6555, align 1
  %6558 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6554
  %6559 = load i32, ptr %6558, align 4
  %6560 = select i1 %6550, i32 43, i32 %6559
  store i32 %6560, ptr %6558, align 4
  %6561 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6554
  %6562 = load i32, ptr %6561, align 4
  %6563 = select i1 %6550, i32 %6549, i32 %6562
  store i32 %6563, ptr %6561, align 4
  %6564 = add i32 %6551, 1
  %6565 = select i1 %6550, i32 %6564, i32 %6551
  store i32 %6565, ptr %ready.count, align 4
  %6566 = load <8 x i1>, ptr %runnable.mask, align 1
  %6567 = or <8 x i1> %6566, %720
  store <8 x i1> %6567, ptr %runnable.mask, align 1
  store <8 x i1> %722, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1053:                        ; preds = %varying.coherent1048
  store <8 x i1> %713, ptr %current.mask, align 1
  %6568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %713)
  br i1 %6568, label %schedule.43, label %scheduler.loop

varying.coherent.false1054:                       ; preds = %varying.coherent1048
  store <8 x i1> %713, ptr %current.mask, align 1
  %6569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %713)
  br i1 %6569, label %schedule.44, label %scheduler.loop

convergence.cascade1059:                          ; preds = %convergence.cascade1059, %schedule.44
  %convergence.cascade.flow1063 = phi <8 x i1> [ %753, %schedule.44 ], [ %6612, %convergence.cascade1059 ]
  %convergence.cascade.depth1064 = phi i32 [ 0, %schedule.44 ], [ %6613, %convergence.cascade1059 ]
  %6570 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1063)
  %6571 = load i32, ptr %current.token, align 4
  %6572 = icmp ne i32 %6571, 0
  %6573 = and i1 %6570, %6572
  %6574 = sub i32 %6571, 1
  %6575 = select i1 %6573, i32 %6574, i32 0
  %6576 = load i8, ptr %frame.active, align 1
  %6577 = trunc i32 %6575 to i8
  %6578 = shl i8 1, %6577
  %6579 = and i8 %6576, %6578
  %6580 = icmp ne i8 %6579, 0
  %6581 = load <8 x i32>, ptr %frame.static.id, align 32
  %6582 = extractelement <8 x i32> %6581, i32 %6575
  %convergence.target.pointer1065 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %6582
  %convergence.dynamic.target1066 = load i32, ptr %convergence.target.pointer1065, align 4
  %6583 = icmp eq i32 %convergence.dynamic.target1066, 44
  %6584 = and i1 %6580, %6583
  %6585 = and i1 %6573, %6584
  %6586 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6575
  %6587 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6575
  %6588 = load <8 x i1>, ptr %6586, align 1
  %6589 = load <8 x i1>, ptr %6587, align 1
  %6590 = or <8 x i1> %6589, %convergence.cascade.flow1063
  %6591 = load <8 x i1>, ptr %live.mask, align 1
  %6592 = and <8 x i1> %6588, %6591
  %6593 = icmp eq <8 x i1> %6590, %6592
  %6594 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6593)
  %6595 = and i1 %6585, %6594
  %6596 = select i1 %6595, <8 x i1> zeroinitializer, <8 x i1> %6590
  %6597 = select i1 %6585, <8 x i1> %6596, <8 x i1> %6589
  store <8 x i1> %6597, ptr %6587, align 1
  %6598 = select i1 %6595, <8 x i1> zeroinitializer, <8 x i1> %6588
  store <8 x i1> %6598, ptr %6586, align 1
  %6599 = trunc i32 %6575 to i8
  %6600 = shl i8 1, %6599
  %6601 = xor i8 %6600, -1
  %6602 = and i8 %6576, %6601
  %6603 = select i1 %6595, i8 %6602, i8 %6576
  store i8 %6603, ptr %frame.active, align 1
  %.splatinsert1067 = insertelement <8 x i1> poison, i1 %6585, i64 0
  %.splat1068 = shufflevector <8 x i1> %.splatinsert1067, <8 x i1> poison, <8 x i32> zeroinitializer
  %6604 = and <8 x i1> %convergence.cascade.flow1063, %.splat1068
  %6605 = load <8 x i1>, ptr %runnable.mask, align 1
  %6606 = xor <8 x i1> %6604, splat (i1 true)
  %6607 = and <8 x i1> %6605, %6606
  store <8 x i1> %6607, ptr %runnable.mask, align 1
  %.splatinsert1069 = insertelement <8 x i1> poison, i1 %6595, i64 0
  %.splat1070 = shufflevector <8 x i1> %.splatinsert1069, <8 x i1> poison, <8 x i32> zeroinitializer
  %6608 = select <8 x i1> %.splat1070, <8 x i1> %6590, <8 x i1> zeroinitializer
  %6609 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6610 = extractelement <8 x i32> %6609, i32 %6575
  %6611 = select i1 %6595, i32 %6610, i32 %6571
  store i32 %6611, ptr %current.token, align 4
  %.splatinsert1071 = insertelement <8 x i1> poison, i1 %6585, i64 0
  %.splat1072 = shufflevector <8 x i1> %.splatinsert1071, <8 x i1> poison, <8 x i32> zeroinitializer
  %6612 = select <8 x i1> %.splat1072, <8 x i1> %6608, <8 x i1> %convergence.cascade.flow1063
  %6613 = add i32 %convergence.cascade.depth1064, 1
  %6614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6612)
  %6615 = icmp ult i32 %6613, 8
  %6616 = and i1 %6614, %6615
  %6617 = and i1 %6585, %6616
  %convergence.parent.token1073 = load i32, ptr %current.token, align 4
  %convergence.parent.present1074 = icmp ne i32 %convergence.parent.token1073, 0
  %6618 = and i1 %6617, %convergence.parent.present1074
  br i1 %6618, label %convergence.cascade1059, label %convergence.cascade.exit1060

convergence.cascade.exit1060:                     ; preds = %convergence.cascade1059, %schedule.44
  %convergence.cascade.result1075 = phi <8 x i1> [ %753, %schedule.44 ], [ %6612, %convergence.cascade1059 ]
  %6619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1075)
  br i1 %6619, label %convergence.target.44.ready, label %scheduler.loop

convergence.target.44.ready:                      ; preds = %convergence.cascade.exit1060
  %6620 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1075)
  %6621 = bitcast <8 x i1> %convergence.cascade.result1075 to i8
  %6622 = call i8 @llvm.cttz.i8(i8 %6621, i1 false)
  %6623 = zext i8 %6622 to i32
  %6624 = select i1 %6620, i32 %6623, i32 0
  %.spill.load1076 = load volatile <8 x float>, ptr %.spill218, align 32
  %.state1077 = load <8 x float>, ptr %.slot223, align 32
  %6625 = fadd <8 x float> %.spill.load1076, %.state1077
  %6626 = load volatile <8 x float>, ptr %.spill230, align 32
  %6627 = select <8 x i1> %convergence.cascade.result1075, <8 x float> %6625, <8 x float> %6626
  store volatile <8 x float> %6627, ptr %.spill230, align 32
  %.spill.load1078 = load volatile <8 x float>, ptr %.spill219, align 32
  %.state1079 = load <8 x float>, ptr %.slot225, align 32
  %6628 = fadd <8 x float> %.spill.load1078, %.state1079
  %6629 = load volatile <8 x float>, ptr %.spill231, align 32
  %6630 = select <8 x i1> %convergence.cascade.result1075, <8 x float> %6628, <8 x float> %6629
  store volatile <8 x float> %6630, ptr %.spill231, align 32
  %.spill.load1080 = load volatile <8 x float>, ptr %.spill220, align 32
  %.state1081 = load <8 x float>, ptr %.slot227, align 32
  %6631 = fadd <8 x float> %.spill.load1080, %.state1081
  %6632 = load volatile <8 x float>, ptr %.spill232, align 32
  %6633 = select <8 x i1> %convergence.cascade.result1075, <8 x float> %6631, <8 x float> %6632
  store volatile <8 x float> %6633, ptr %.spill232, align 32
  %.spill.load1082 = load volatile <8 x float>, ptr %.spill221, align 32
  %.state1083 = load <8 x float>, ptr %.slot229, align 32
  %6634 = fadd <8 x float> %.spill.load1082, %.state1083
  %6635 = load volatile <8 x float>, ptr %.spill233, align 32
  %6636 = select <8 x i1> %convergence.cascade.result1075, <8 x float> %6634, <8 x float> %6635
  store volatile <8 x float> %6636, ptr %.spill233, align 32
  %6637 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill234, align 64
  %6638 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %6639 = extractvalue { <8 x ptr>, <8 x i64> } %6637, 0
  %6640 = select <8 x i1> %convergence.cascade.result1075, <8 x ptr> %6638, <8 x ptr> %6639
  %6641 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %6642 = extractvalue { <8 x ptr>, <8 x i64> } %6637, 1
  %6643 = select <8 x i1> %convergence.cascade.result1075, <8 x i64> %6641, <8 x i64> %6642
  %6644 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6640, 0
  %6645 = insertvalue { <8 x ptr>, <8 x i64> } %6644, <8 x i64> %6643, 1
  store volatile { <8 x ptr>, <8 x i64> } %6645, ptr %tile_snapshot.spill234, align 64
  %6646 = load <8 x i64>, ptr %.slot235, align 64
  %6647 = select <8 x i1> %convergence.cascade.result1075, <8 x i64> zeroinitializer, <8 x i64> %6646
  store <8 x i64> %6647, ptr %.slot235, align 64
  store <8 x i1> %convergence.cascade.result1075, ptr %current.mask, align 1
  %6648 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1075)
  br i1 %6648, label %schedule.45, label %scheduler.loop

varying.divergent1085:                            ; preds = %schedule.45
  %6649 = load i32, ptr %current.token, align 4
  %6650 = icmp ne i32 %6649, 0
  %6651 = sub i32 %6649, 1
  %6652 = select i1 %6650, i32 %6651, i32 0
  %6653 = load i8, ptr %frame.active, align 1
  %6654 = trunc i32 %6652 to i8
  %6655 = shl i8 1, %6654
  %6656 = and i8 %6653, %6655
  %6657 = icmp ne i8 %6656, 0
  %6658 = load <8 x i32>, ptr %frame.static.id, align 32
  %6659 = extractelement <8 x i32> %6658, i32 %6652
  %6660 = icmp eq i32 %6659, 16
  %6661 = and i1 %6657, %6660
  %6662 = and i1 %6650, %6661
  %6663 = xor i1 %6662, true
  %6664 = and i1 true, %6663
  %6665 = xor i8 %6653, -1
  %6666 = icmp ne i8 %6665, 0
  %6667 = xor i1 %6666, true
  %6668 = and i1 %6664, %6667
  br i1 %6668, label %convergence.overflow.trap1087, label %convergence.overflow.resume1088

varying.coherent1086:                             ; preds = %schedule.45
  br i1 %764, label %varying.coherent.true1091, label %varying.coherent.false1092

convergence.overflow.trap1087:                    ; preds = %varying.divergent1085
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1088:                  ; preds = %varying.divergent1085
  %6669 = call i8 @llvm.cttz.i8(i8 %6665, i1 false)
  %6670 = zext i8 %6669 to i32
  %6671 = select i1 %6666, i32 %6670, i32 0
  %6672 = trunc i32 %6671 to i8
  %6673 = shl i8 1, %6672
  %6674 = or i8 %6653, %6673
  %6675 = select i1 %6664, i8 %6674, i8 %6653
  store i8 %6675, ptr %frame.active, align 1
  %6676 = load <8 x i32>, ptr %frame.static.id, align 32
  %6677 = extractelement <8 x i32> %6676, i32 %6671
  %6678 = select i1 %6664, i32 16, i32 %6677
  %6679 = load <8 x i32>, ptr %frame.static.id, align 32
  %6680 = insertelement <8 x i32> %6679, i32 %6678, i32 %6671
  store <8 x i32> %6680, ptr %frame.static.id, align 32
  %6681 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6682 = extractelement <8 x i32> %6681, i32 %6671
  %6683 = select i1 %6664, i32 %6649, i32 %6682
  %6684 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6685 = insertelement <8 x i32> %6684, i32 %6683, i32 %6671
  store <8 x i32> %6685, ptr %frame.parent.token, align 32
  %6686 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6671
  %6687 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6671
  %6688 = load <8 x i1>, ptr %6686, align 1
  %6689 = load <8 x i1>, ptr %6687, align 1
  %6690 = select i1 %6664, <8 x i1> %754, <8 x i1> %6688
  store <8 x i1> %6690, ptr %6686, align 1
  %6691 = select i1 %6664, <8 x i1> zeroinitializer, <8 x i1> %6689
  store <8 x i1> %6691, ptr %6687, align 1
  %6692 = add i32 %6671, 1
  %6693 = select i1 %6662, i32 %6649, i32 %6692
  %6694 = select i1 true, i32 %6693, i32 %6649
  store i32 %6694, ptr %current.token, align 4
  %6695 = load i32, ptr %current.token, align 4
  %6696 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %761)
  %6697 = load i32, ptr %ready.count, align 4
  %6698 = icmp uge i32 %6697, 8
  %6699 = and i1 %6696, %6698
  br i1 %6699, label %ready.overflow.trap1089, label %ready.overflow.resume1090

ready.overflow.trap1089:                          ; preds = %convergence.overflow.resume1088
  call void @llvm.trap()
  unreachable

ready.overflow.resume1090:                        ; preds = %convergence.overflow.resume1088
  %6700 = select i1 %6696, i32 %6697, i32 0
  %6701 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %6700
  %6702 = load <8 x i1>, ptr %6701, align 1
  %6703 = select i1 %6696, <8 x i1> %761, <8 x i1> %6702
  store <8 x i1> %6703, ptr %6701, align 1
  %6704 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %6700
  %6705 = load i32, ptr %6704, align 4
  %6706 = select i1 %6696, i32 46, i32 %6705
  store i32 %6706, ptr %6704, align 4
  %6707 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %6700
  %6708 = load i32, ptr %6707, align 4
  %6709 = select i1 %6696, i32 %6695, i32 %6708
  store i32 %6709, ptr %6707, align 4
  %6710 = add i32 %6697, 1
  %6711 = select i1 %6696, i32 %6710, i32 %6697
  store i32 %6711, ptr %ready.count, align 4
  %6712 = load <8 x i1>, ptr %runnable.mask, align 1
  %6713 = or <8 x i1> %6712, %761
  store <8 x i1> %6713, ptr %runnable.mask, align 1
  store <8 x i1> %763, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1091:                        ; preds = %varying.coherent1086
  store <8 x i1> %754, ptr %current.mask, align 1
  %6714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %754)
  br i1 %6714, label %schedule.46, label %scheduler.loop

varying.coherent.false1092:                       ; preds = %varying.coherent1086
  store <8 x i1> %754, ptr %current.mask, align 1
  %6715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %754)
  br i1 %6715, label %schedule.47, label %scheduler.loop

convergence.cascade1100:                          ; preds = %convergence.cascade1100, %schedule.47
  %convergence.cascade.flow1104 = phi <8 x i1> [ %816, %schedule.47 ], [ %6758, %convergence.cascade1100 ]
  %convergence.cascade.depth1105 = phi i32 [ 0, %schedule.47 ], [ %6759, %convergence.cascade1100 ]
  %6716 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1104)
  %6717 = load i32, ptr %current.token, align 4
  %6718 = icmp ne i32 %6717, 0
  %6719 = and i1 %6716, %6718
  %6720 = sub i32 %6717, 1
  %6721 = select i1 %6719, i32 %6720, i32 0
  %6722 = load i8, ptr %frame.active, align 1
  %6723 = trunc i32 %6721 to i8
  %6724 = shl i8 1, %6723
  %6725 = and i8 %6722, %6724
  %6726 = icmp ne i8 %6725, 0
  %6727 = load <8 x i32>, ptr %frame.static.id, align 32
  %6728 = extractelement <8 x i32> %6727, i32 %6721
  %convergence.target.pointer1106 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %6728
  %convergence.dynamic.target1107 = load i32, ptr %convergence.target.pointer1106, align 4
  %6729 = icmp eq i32 %convergence.dynamic.target1107, 47
  %6730 = and i1 %6726, %6729
  %6731 = and i1 %6719, %6730
  %6732 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6721
  %6733 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6721
  %6734 = load <8 x i1>, ptr %6732, align 1
  %6735 = load <8 x i1>, ptr %6733, align 1
  %6736 = or <8 x i1> %6735, %convergence.cascade.flow1104
  %6737 = load <8 x i1>, ptr %live.mask, align 1
  %6738 = and <8 x i1> %6734, %6737
  %6739 = icmp eq <8 x i1> %6736, %6738
  %6740 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %6739)
  %6741 = and i1 %6731, %6740
  %6742 = select i1 %6741, <8 x i1> zeroinitializer, <8 x i1> %6736
  %6743 = select i1 %6731, <8 x i1> %6742, <8 x i1> %6735
  store <8 x i1> %6743, ptr %6733, align 1
  %6744 = select i1 %6741, <8 x i1> zeroinitializer, <8 x i1> %6734
  store <8 x i1> %6744, ptr %6732, align 1
  %6745 = trunc i32 %6721 to i8
  %6746 = shl i8 1, %6745
  %6747 = xor i8 %6746, -1
  %6748 = and i8 %6722, %6747
  %6749 = select i1 %6741, i8 %6748, i8 %6722
  store i8 %6749, ptr %frame.active, align 1
  %.splatinsert1108 = insertelement <8 x i1> poison, i1 %6731, i64 0
  %.splat1109 = shufflevector <8 x i1> %.splatinsert1108, <8 x i1> poison, <8 x i32> zeroinitializer
  %6750 = and <8 x i1> %convergence.cascade.flow1104, %.splat1109
  %6751 = load <8 x i1>, ptr %runnable.mask, align 1
  %6752 = xor <8 x i1> %6750, splat (i1 true)
  %6753 = and <8 x i1> %6751, %6752
  store <8 x i1> %6753, ptr %runnable.mask, align 1
  %.splatinsert1110 = insertelement <8 x i1> poison, i1 %6741, i64 0
  %.splat1111 = shufflevector <8 x i1> %.splatinsert1110, <8 x i1> poison, <8 x i32> zeroinitializer
  %6754 = select <8 x i1> %.splat1111, <8 x i1> %6736, <8 x i1> zeroinitializer
  %6755 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6756 = extractelement <8 x i32> %6755, i32 %6721
  %6757 = select i1 %6741, i32 %6756, i32 %6717
  store i32 %6757, ptr %current.token, align 4
  %.splatinsert1112 = insertelement <8 x i1> poison, i1 %6731, i64 0
  %.splat1113 = shufflevector <8 x i1> %.splatinsert1112, <8 x i1> poison, <8 x i32> zeroinitializer
  %6758 = select <8 x i1> %.splat1113, <8 x i1> %6754, <8 x i1> %convergence.cascade.flow1104
  %6759 = add i32 %convergence.cascade.depth1105, 1
  %6760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6758)
  %6761 = icmp ult i32 %6759, 8
  %6762 = and i1 %6760, %6761
  %6763 = and i1 %6731, %6762
  %convergence.parent.token1114 = load i32, ptr %current.token, align 4
  %convergence.parent.present1115 = icmp ne i32 %convergence.parent.token1114, 0
  %6764 = and i1 %6763, %convergence.parent.present1115
  br i1 %6764, label %convergence.cascade1100, label %convergence.cascade.exit1101

convergence.cascade.exit1101:                     ; preds = %convergence.cascade1100, %schedule.47
  %convergence.cascade.result1116 = phi <8 x i1> [ %816, %schedule.47 ], [ %6758, %convergence.cascade1100 ]
  %6765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1116)
  br i1 %6765, label %convergence.target.47.ready, label %scheduler.loop

convergence.target.47.ready:                      ; preds = %convergence.cascade.exit1101
  %6766 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1116)
  %6767 = bitcast <8 x i1> %convergence.cascade.result1116 to i8
  %6768 = call i8 @llvm.cttz.i8(i8 %6767, i1 false)
  %6769 = zext i8 %6768 to i32
  %6770 = select i1 %6766, i32 %6769, i32 0
  %6771 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill236, align 64
  %6772 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6773 = extractvalue { <8 x ptr>, <8 x i64> } %6771, 0
  %6774 = select <8 x i1> %convergence.cascade.result1116, <8 x ptr> %6772, <8 x ptr> %6773
  %6775 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6776 = extractvalue { <8 x ptr>, <8 x i64> } %6771, 1
  %6777 = select <8 x i1> %convergence.cascade.result1116, <8 x i64> %6775, <8 x i64> %6776
  %6778 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6774, 0
  %6779 = insertvalue { <8 x ptr>, <8 x i64> } %6778, <8 x i64> %6777, 1
  store volatile { <8 x ptr>, <8 x i64> } %6779, ptr %tile_snapshot.spill236, align 64
  %tile_snapshot.spill.load1117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill217, align 64
  %tile_snapshot.spill.load1118 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill71, align 64
  %tile_snapshot.spill.load1119 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill234, align 64
  %6780 = extractelement <8 x i1> %convergence.cascade.result1116, i64 0
  br i1 %6780, label %mma.active1120, label %mma.continue1121

mma.active1120:                                   ; preds = %convergence.target.47.ready
  %6781 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 0
  %6782 = extractelement <8 x ptr> %6781, i64 0
  %6783 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 1
  %6784 = extractelement <8 x i64> %6783, i64 0
  %6785 = getelementptr i8, ptr %6782, i64 %6784
  %6786 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 0
  %6787 = extractelement <8 x ptr> %6786, i64 0
  %6788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 1
  %6789 = extractelement <8 x i64> %6788, i64 0
  %6790 = getelementptr i8, ptr %6787, i64 %6789
  %6791 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 0
  %6792 = extractelement <8 x ptr> %6791, i64 0
  %6793 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 1
  %6794 = extractelement <8 x i64> %6793, i64 0
  %6795 = getelementptr i8, ptr %6792, i64 %6794
  %6796 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6797 = extractelement <8 x ptr> %6796, i64 0
  %6798 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6799 = extractelement <8 x i64> %6798, i64 0
  %6800 = getelementptr i8, ptr %6797, i64 %6799
  call void @llm_attention.strided_mma.1(ptr %6785, ptr %6790, ptr %6795, ptr %6800)
  br label %mma.continue1121

mma.continue1121:                                 ; preds = %mma.active1120, %convergence.target.47.ready
  %6801 = extractelement <8 x i1> %convergence.cascade.result1116, i64 1
  br i1 %6801, label %mma.active1122, label %mma.continue1123

mma.active1122:                                   ; preds = %mma.continue1121
  %6802 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 0
  %6803 = extractelement <8 x ptr> %6802, i64 1
  %6804 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 1
  %6805 = extractelement <8 x i64> %6804, i64 1
  %6806 = getelementptr i8, ptr %6803, i64 %6805
  %6807 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 0
  %6808 = extractelement <8 x ptr> %6807, i64 1
  %6809 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 1
  %6810 = extractelement <8 x i64> %6809, i64 1
  %6811 = getelementptr i8, ptr %6808, i64 %6810
  %6812 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 0
  %6813 = extractelement <8 x ptr> %6812, i64 1
  %6814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 1
  %6815 = extractelement <8 x i64> %6814, i64 1
  %6816 = getelementptr i8, ptr %6813, i64 %6815
  %6817 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6818 = extractelement <8 x ptr> %6817, i64 1
  %6819 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6820 = extractelement <8 x i64> %6819, i64 1
  %6821 = getelementptr i8, ptr %6818, i64 %6820
  call void @llm_attention.strided_mma.1(ptr %6806, ptr %6811, ptr %6816, ptr %6821)
  br label %mma.continue1123

mma.continue1123:                                 ; preds = %mma.active1122, %mma.continue1121
  %6822 = extractelement <8 x i1> %convergence.cascade.result1116, i64 2
  br i1 %6822, label %mma.active1124, label %mma.continue1125

mma.active1124:                                   ; preds = %mma.continue1123
  %6823 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 0
  %6824 = extractelement <8 x ptr> %6823, i64 2
  %6825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 1
  %6826 = extractelement <8 x i64> %6825, i64 2
  %6827 = getelementptr i8, ptr %6824, i64 %6826
  %6828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 0
  %6829 = extractelement <8 x ptr> %6828, i64 2
  %6830 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 1
  %6831 = extractelement <8 x i64> %6830, i64 2
  %6832 = getelementptr i8, ptr %6829, i64 %6831
  %6833 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 0
  %6834 = extractelement <8 x ptr> %6833, i64 2
  %6835 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 1
  %6836 = extractelement <8 x i64> %6835, i64 2
  %6837 = getelementptr i8, ptr %6834, i64 %6836
  %6838 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6839 = extractelement <8 x ptr> %6838, i64 2
  %6840 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6841 = extractelement <8 x i64> %6840, i64 2
  %6842 = getelementptr i8, ptr %6839, i64 %6841
  call void @llm_attention.strided_mma.1(ptr %6827, ptr %6832, ptr %6837, ptr %6842)
  br label %mma.continue1125

mma.continue1125:                                 ; preds = %mma.active1124, %mma.continue1123
  %6843 = extractelement <8 x i1> %convergence.cascade.result1116, i64 3
  br i1 %6843, label %mma.active1126, label %mma.continue1127

mma.active1126:                                   ; preds = %mma.continue1125
  %6844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 0
  %6845 = extractelement <8 x ptr> %6844, i64 3
  %6846 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 1
  %6847 = extractelement <8 x i64> %6846, i64 3
  %6848 = getelementptr i8, ptr %6845, i64 %6847
  %6849 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 0
  %6850 = extractelement <8 x ptr> %6849, i64 3
  %6851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 1
  %6852 = extractelement <8 x i64> %6851, i64 3
  %6853 = getelementptr i8, ptr %6850, i64 %6852
  %6854 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 0
  %6855 = extractelement <8 x ptr> %6854, i64 3
  %6856 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 1
  %6857 = extractelement <8 x i64> %6856, i64 3
  %6858 = getelementptr i8, ptr %6855, i64 %6857
  %6859 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6860 = extractelement <8 x ptr> %6859, i64 3
  %6861 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6862 = extractelement <8 x i64> %6861, i64 3
  %6863 = getelementptr i8, ptr %6860, i64 %6862
  call void @llm_attention.strided_mma.1(ptr %6848, ptr %6853, ptr %6858, ptr %6863)
  br label %mma.continue1127

mma.continue1127:                                 ; preds = %mma.active1126, %mma.continue1125
  %6864 = extractelement <8 x i1> %convergence.cascade.result1116, i64 4
  br i1 %6864, label %mma.active1128, label %mma.continue1129

mma.active1128:                                   ; preds = %mma.continue1127
  %6865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 0
  %6866 = extractelement <8 x ptr> %6865, i64 4
  %6867 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 1
  %6868 = extractelement <8 x i64> %6867, i64 4
  %6869 = getelementptr i8, ptr %6866, i64 %6868
  %6870 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 0
  %6871 = extractelement <8 x ptr> %6870, i64 4
  %6872 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 1
  %6873 = extractelement <8 x i64> %6872, i64 4
  %6874 = getelementptr i8, ptr %6871, i64 %6873
  %6875 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 0
  %6876 = extractelement <8 x ptr> %6875, i64 4
  %6877 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 1
  %6878 = extractelement <8 x i64> %6877, i64 4
  %6879 = getelementptr i8, ptr %6876, i64 %6878
  %6880 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6881 = extractelement <8 x ptr> %6880, i64 4
  %6882 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6883 = extractelement <8 x i64> %6882, i64 4
  %6884 = getelementptr i8, ptr %6881, i64 %6883
  call void @llm_attention.strided_mma.1(ptr %6869, ptr %6874, ptr %6879, ptr %6884)
  br label %mma.continue1129

mma.continue1129:                                 ; preds = %mma.active1128, %mma.continue1127
  %6885 = extractelement <8 x i1> %convergence.cascade.result1116, i64 5
  br i1 %6885, label %mma.active1130, label %mma.continue1131

mma.active1130:                                   ; preds = %mma.continue1129
  %6886 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 0
  %6887 = extractelement <8 x ptr> %6886, i64 5
  %6888 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 1
  %6889 = extractelement <8 x i64> %6888, i64 5
  %6890 = getelementptr i8, ptr %6887, i64 %6889
  %6891 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 0
  %6892 = extractelement <8 x ptr> %6891, i64 5
  %6893 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 1
  %6894 = extractelement <8 x i64> %6893, i64 5
  %6895 = getelementptr i8, ptr %6892, i64 %6894
  %6896 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 0
  %6897 = extractelement <8 x ptr> %6896, i64 5
  %6898 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 1
  %6899 = extractelement <8 x i64> %6898, i64 5
  %6900 = getelementptr i8, ptr %6897, i64 %6899
  %6901 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6902 = extractelement <8 x ptr> %6901, i64 5
  %6903 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6904 = extractelement <8 x i64> %6903, i64 5
  %6905 = getelementptr i8, ptr %6902, i64 %6904
  call void @llm_attention.strided_mma.1(ptr %6890, ptr %6895, ptr %6900, ptr %6905)
  br label %mma.continue1131

mma.continue1131:                                 ; preds = %mma.active1130, %mma.continue1129
  %6906 = extractelement <8 x i1> %convergence.cascade.result1116, i64 6
  br i1 %6906, label %mma.active1132, label %mma.continue1133

mma.active1132:                                   ; preds = %mma.continue1131
  %6907 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 0
  %6908 = extractelement <8 x ptr> %6907, i64 6
  %6909 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 1
  %6910 = extractelement <8 x i64> %6909, i64 6
  %6911 = getelementptr i8, ptr %6908, i64 %6910
  %6912 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 0
  %6913 = extractelement <8 x ptr> %6912, i64 6
  %6914 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 1
  %6915 = extractelement <8 x i64> %6914, i64 6
  %6916 = getelementptr i8, ptr %6913, i64 %6915
  %6917 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 0
  %6918 = extractelement <8 x ptr> %6917, i64 6
  %6919 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 1
  %6920 = extractelement <8 x i64> %6919, i64 6
  %6921 = getelementptr i8, ptr %6918, i64 %6920
  %6922 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6923 = extractelement <8 x ptr> %6922, i64 6
  %6924 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6925 = extractelement <8 x i64> %6924, i64 6
  %6926 = getelementptr i8, ptr %6923, i64 %6925
  call void @llm_attention.strided_mma.1(ptr %6911, ptr %6916, ptr %6921, ptr %6926)
  br label %mma.continue1133

mma.continue1133:                                 ; preds = %mma.active1132, %mma.continue1131
  %6927 = extractelement <8 x i1> %convergence.cascade.result1116, i64 7
  br i1 %6927, label %mma.active1134, label %mma.continue1135

mma.active1134:                                   ; preds = %mma.continue1133
  %6928 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 0
  %6929 = extractelement <8 x ptr> %6928, i64 7
  %6930 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1117, 1
  %6931 = extractelement <8 x i64> %6930, i64 7
  %6932 = getelementptr i8, ptr %6929, i64 %6931
  %6933 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 0
  %6934 = extractelement <8 x ptr> %6933, i64 7
  %6935 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1118, 1
  %6936 = extractelement <8 x i64> %6935, i64 7
  %6937 = getelementptr i8, ptr %6934, i64 %6936
  %6938 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 0
  %6939 = extractelement <8 x ptr> %6938, i64 7
  %6940 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1119, 1
  %6941 = extractelement <8 x i64> %6940, i64 7
  %6942 = getelementptr i8, ptr %6939, i64 %6941
  %6943 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %6944 = extractelement <8 x ptr> %6943, i64 7
  %6945 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %6946 = extractelement <8 x i64> %6945, i64 7
  %6947 = getelementptr i8, ptr %6944, i64 %6946
  call void @llm_attention.strided_mma.1(ptr %6932, ptr %6937, ptr %6942, ptr %6947)
  br label %mma.continue1135

mma.continue1135:                                 ; preds = %mma.active1134, %mma.continue1133
  %6948 = load <8 x i64>, ptr %.slot237, align 64
  %6949 = select <8 x i1> %convergence.cascade.result1116, <8 x i64> zeroinitializer, <8 x i64> %6948
  store <8 x i64> %6949, ptr %.slot237, align 64
  store <8 x i1> %convergence.cascade.result1116, ptr %current.mask, align 1
  %6950 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1116)
  br i1 %6950, label %schedule.48, label %scheduler.loop

varying.divergent1137:                            ; preds = %schedule.48
  %6951 = load i32, ptr %current.token, align 4
  %6952 = icmp ne i32 %6951, 0
  %6953 = sub i32 %6951, 1
  %6954 = select i1 %6952, i32 %6953, i32 0
  %6955 = load i8, ptr %frame.active, align 1
  %6956 = trunc i32 %6954 to i8
  %6957 = shl i8 1, %6956
  %6958 = and i8 %6955, %6957
  %6959 = icmp ne i8 %6958, 0
  %6960 = load <8 x i32>, ptr %frame.static.id, align 32
  %6961 = extractelement <8 x i32> %6960, i32 %6954
  %6962 = icmp eq i32 %6961, 17
  %6963 = and i1 %6959, %6962
  %6964 = and i1 %6952, %6963
  %6965 = xor i1 %6964, true
  %6966 = and i1 true, %6965
  %6967 = xor i8 %6955, -1
  %6968 = icmp ne i8 %6967, 0
  %6969 = xor i1 %6968, true
  %6970 = and i1 %6966, %6969
  br i1 %6970, label %convergence.overflow.trap1139, label %convergence.overflow.resume1140

varying.coherent1138:                             ; preds = %schedule.48
  br i1 %827, label %varying.coherent.true1143, label %varying.coherent.false1144

convergence.overflow.trap1139:                    ; preds = %varying.divergent1137
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1140:                  ; preds = %varying.divergent1137
  %6971 = call i8 @llvm.cttz.i8(i8 %6967, i1 false)
  %6972 = zext i8 %6971 to i32
  %6973 = select i1 %6968, i32 %6972, i32 0
  %6974 = trunc i32 %6973 to i8
  %6975 = shl i8 1, %6974
  %6976 = or i8 %6955, %6975
  %6977 = select i1 %6966, i8 %6976, i8 %6955
  store i8 %6977, ptr %frame.active, align 1
  %6978 = load <8 x i32>, ptr %frame.static.id, align 32
  %6979 = extractelement <8 x i32> %6978, i32 %6973
  %6980 = select i1 %6966, i32 17, i32 %6979
  %6981 = load <8 x i32>, ptr %frame.static.id, align 32
  %6982 = insertelement <8 x i32> %6981, i32 %6980, i32 %6973
  store <8 x i32> %6982, ptr %frame.static.id, align 32
  %6983 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6984 = extractelement <8 x i32> %6983, i32 %6973
  %6985 = select i1 %6966, i32 %6951, i32 %6984
  %6986 = load <8 x i32>, ptr %frame.parent.token, align 32
  %6987 = insertelement <8 x i32> %6986, i32 %6985, i32 %6973
  store <8 x i32> %6987, ptr %frame.parent.token, align 32
  %6988 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %6973
  %6989 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %6973
  %6990 = load <8 x i1>, ptr %6988, align 1
  %6991 = load <8 x i1>, ptr %6989, align 1
  %6992 = select i1 %6966, <8 x i1> %817, <8 x i1> %6990
  store <8 x i1> %6992, ptr %6988, align 1
  %6993 = select i1 %6966, <8 x i1> zeroinitializer, <8 x i1> %6991
  store <8 x i1> %6993, ptr %6989, align 1
  %6994 = add i32 %6973, 1
  %6995 = select i1 %6964, i32 %6951, i32 %6994
  %6996 = select i1 true, i32 %6995, i32 %6951
  store i32 %6996, ptr %current.token, align 4
  %6997 = load i32, ptr %current.token, align 4
  %6998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %824)
  %6999 = load i32, ptr %ready.count, align 4
  %7000 = icmp uge i32 %6999, 8
  %7001 = and i1 %6998, %7000
  br i1 %7001, label %ready.overflow.trap1141, label %ready.overflow.resume1142

ready.overflow.trap1141:                          ; preds = %convergence.overflow.resume1140
  call void @llvm.trap()
  unreachable

ready.overflow.resume1142:                        ; preds = %convergence.overflow.resume1140
  %7002 = select i1 %6998, i32 %6999, i32 0
  %7003 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7002
  %7004 = load <8 x i1>, ptr %7003, align 1
  %7005 = select i1 %6998, <8 x i1> %824, <8 x i1> %7004
  store <8 x i1> %7005, ptr %7003, align 1
  %7006 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7002
  %7007 = load i32, ptr %7006, align 4
  %7008 = select i1 %6998, i32 49, i32 %7007
  store i32 %7008, ptr %7006, align 4
  %7009 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7002
  %7010 = load i32, ptr %7009, align 4
  %7011 = select i1 %6998, i32 %6997, i32 %7010
  store i32 %7011, ptr %7009, align 4
  %7012 = add i32 %6999, 1
  %7013 = select i1 %6998, i32 %7012, i32 %6999
  store i32 %7013, ptr %ready.count, align 4
  %7014 = load <8 x i1>, ptr %runnable.mask, align 1
  %7015 = or <8 x i1> %7014, %824
  store <8 x i1> %7015, ptr %runnable.mask, align 1
  store <8 x i1> %826, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1143:                        ; preds = %varying.coherent1138
  store <8 x i1> %817, ptr %current.mask, align 1
  %7016 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %817)
  br i1 %7016, label %schedule.49, label %scheduler.loop

varying.coherent.false1144:                       ; preds = %varying.coherent1138
  store <8 x i1> %817, ptr %current.mask, align 1
  %7017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %817)
  br i1 %7017, label %schedule.50, label %scheduler.loop

convergence.cascade1150:                          ; preds = %convergence.cascade1150, %schedule.50
  %convergence.cascade.flow1154 = phi <8 x i1> [ %859, %schedule.50 ], [ %7060, %convergence.cascade1150 ]
  %convergence.cascade.depth1155 = phi i32 [ 0, %schedule.50 ], [ %7061, %convergence.cascade1150 ]
  %7018 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1154)
  %7019 = load i32, ptr %current.token, align 4
  %7020 = icmp ne i32 %7019, 0
  %7021 = and i1 %7018, %7020
  %7022 = sub i32 %7019, 1
  %7023 = select i1 %7021, i32 %7022, i32 0
  %7024 = load i8, ptr %frame.active, align 1
  %7025 = trunc i32 %7023 to i8
  %7026 = shl i8 1, %7025
  %7027 = and i8 %7024, %7026
  %7028 = icmp ne i8 %7027, 0
  %7029 = load <8 x i32>, ptr %frame.static.id, align 32
  %7030 = extractelement <8 x i32> %7029, i32 %7023
  %convergence.target.pointer1156 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7030
  %convergence.dynamic.target1157 = load i32, ptr %convergence.target.pointer1156, align 4
  %7031 = icmp eq i32 %convergence.dynamic.target1157, 50
  %7032 = and i1 %7028, %7031
  %7033 = and i1 %7021, %7032
  %7034 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7023
  %7035 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7023
  %7036 = load <8 x i1>, ptr %7034, align 1
  %7037 = load <8 x i1>, ptr %7035, align 1
  %7038 = or <8 x i1> %7037, %convergence.cascade.flow1154
  %7039 = load <8 x i1>, ptr %live.mask, align 1
  %7040 = and <8 x i1> %7036, %7039
  %7041 = icmp eq <8 x i1> %7038, %7040
  %7042 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7041)
  %7043 = and i1 %7033, %7042
  %7044 = select i1 %7043, <8 x i1> zeroinitializer, <8 x i1> %7038
  %7045 = select i1 %7033, <8 x i1> %7044, <8 x i1> %7037
  store <8 x i1> %7045, ptr %7035, align 1
  %7046 = select i1 %7043, <8 x i1> zeroinitializer, <8 x i1> %7036
  store <8 x i1> %7046, ptr %7034, align 1
  %7047 = trunc i32 %7023 to i8
  %7048 = shl i8 1, %7047
  %7049 = xor i8 %7048, -1
  %7050 = and i8 %7024, %7049
  %7051 = select i1 %7043, i8 %7050, i8 %7024
  store i8 %7051, ptr %frame.active, align 1
  %.splatinsert1158 = insertelement <8 x i1> poison, i1 %7033, i64 0
  %.splat1159 = shufflevector <8 x i1> %.splatinsert1158, <8 x i1> poison, <8 x i32> zeroinitializer
  %7052 = and <8 x i1> %convergence.cascade.flow1154, %.splat1159
  %7053 = load <8 x i1>, ptr %runnable.mask, align 1
  %7054 = xor <8 x i1> %7052, splat (i1 true)
  %7055 = and <8 x i1> %7053, %7054
  store <8 x i1> %7055, ptr %runnable.mask, align 1
  %.splatinsert1160 = insertelement <8 x i1> poison, i1 %7043, i64 0
  %.splat1161 = shufflevector <8 x i1> %.splatinsert1160, <8 x i1> poison, <8 x i32> zeroinitializer
  %7056 = select <8 x i1> %.splat1161, <8 x i1> %7038, <8 x i1> zeroinitializer
  %7057 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7058 = extractelement <8 x i32> %7057, i32 %7023
  %7059 = select i1 %7043, i32 %7058, i32 %7019
  store i32 %7059, ptr %current.token, align 4
  %.splatinsert1162 = insertelement <8 x i1> poison, i1 %7033, i64 0
  %.splat1163 = shufflevector <8 x i1> %.splatinsert1162, <8 x i1> poison, <8 x i32> zeroinitializer
  %7060 = select <8 x i1> %.splat1163, <8 x i1> %7056, <8 x i1> %convergence.cascade.flow1154
  %7061 = add i32 %convergence.cascade.depth1155, 1
  %7062 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7060)
  %7063 = icmp ult i32 %7061, 8
  %7064 = and i1 %7062, %7063
  %7065 = and i1 %7033, %7064
  %convergence.parent.token1164 = load i32, ptr %current.token, align 4
  %convergence.parent.present1165 = icmp ne i32 %convergence.parent.token1164, 0
  %7066 = and i1 %7065, %convergence.parent.present1165
  br i1 %7066, label %convergence.cascade1150, label %convergence.cascade.exit1151

convergence.cascade.exit1151:                     ; preds = %convergence.cascade1150, %schedule.50
  %convergence.cascade.result1166 = phi <8 x i1> [ %859, %schedule.50 ], [ %7060, %convergence.cascade1150 ]
  %7067 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1166)
  br i1 %7067, label %convergence.target.50.ready, label %scheduler.loop

convergence.target.50.ready:                      ; preds = %convergence.cascade.exit1151
  %7068 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1166)
  %7069 = bitcast <8 x i1> %convergence.cascade.result1166 to i8
  %7070 = call i8 @llvm.cttz.i8(i8 %7069, i1 false)
  %7071 = zext i8 %7070 to i32
  %7072 = select i1 %7068, i32 %7071, i32 0
  %7073 = load <8 x i64>, ptr %.slot238, align 64
  %7074 = select <8 x i1> %convergence.cascade.result1166, <8 x i64> zeroinitializer, <8 x i64> %7073
  store <8 x i64> %7074, ptr %.slot238, align 64
  store <8 x i1> %convergence.cascade.result1166, ptr %current.mask, align 1
  %7075 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1166)
  br i1 %7075, label %schedule.51, label %scheduler.loop

varying.divergent1168:                            ; preds = %schedule.51
  %7076 = load i32, ptr %current.token, align 4
  %7077 = icmp ne i32 %7076, 0
  %7078 = sub i32 %7076, 1
  %7079 = select i1 %7077, i32 %7078, i32 0
  %7080 = load i8, ptr %frame.active, align 1
  %7081 = trunc i32 %7079 to i8
  %7082 = shl i8 1, %7081
  %7083 = and i8 %7080, %7082
  %7084 = icmp ne i8 %7083, 0
  %7085 = load <8 x i32>, ptr %frame.static.id, align 32
  %7086 = extractelement <8 x i32> %7085, i32 %7079
  %7087 = icmp eq i32 %7086, 18
  %7088 = and i1 %7084, %7087
  %7089 = and i1 %7077, %7088
  %7090 = xor i1 %7089, true
  %7091 = and i1 true, %7090
  %7092 = xor i8 %7080, -1
  %7093 = icmp ne i8 %7092, 0
  %7094 = xor i1 %7093, true
  %7095 = and i1 %7091, %7094
  br i1 %7095, label %convergence.overflow.trap1170, label %convergence.overflow.resume1171

varying.coherent1169:                             ; preds = %schedule.51
  br i1 %870, label %varying.coherent.true1174, label %varying.coherent.false1175

convergence.overflow.trap1170:                    ; preds = %varying.divergent1168
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1171:                  ; preds = %varying.divergent1168
  %7096 = call i8 @llvm.cttz.i8(i8 %7092, i1 false)
  %7097 = zext i8 %7096 to i32
  %7098 = select i1 %7093, i32 %7097, i32 0
  %7099 = trunc i32 %7098 to i8
  %7100 = shl i8 1, %7099
  %7101 = or i8 %7080, %7100
  %7102 = select i1 %7091, i8 %7101, i8 %7080
  store i8 %7102, ptr %frame.active, align 1
  %7103 = load <8 x i32>, ptr %frame.static.id, align 32
  %7104 = extractelement <8 x i32> %7103, i32 %7098
  %7105 = select i1 %7091, i32 18, i32 %7104
  %7106 = load <8 x i32>, ptr %frame.static.id, align 32
  %7107 = insertelement <8 x i32> %7106, i32 %7105, i32 %7098
  store <8 x i32> %7107, ptr %frame.static.id, align 32
  %7108 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7109 = extractelement <8 x i32> %7108, i32 %7098
  %7110 = select i1 %7091, i32 %7076, i32 %7109
  %7111 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7112 = insertelement <8 x i32> %7111, i32 %7110, i32 %7098
  store <8 x i32> %7112, ptr %frame.parent.token, align 32
  %7113 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7098
  %7114 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7098
  %7115 = load <8 x i1>, ptr %7113, align 1
  %7116 = load <8 x i1>, ptr %7114, align 1
  %7117 = select i1 %7091, <8 x i1> %860, <8 x i1> %7115
  store <8 x i1> %7117, ptr %7113, align 1
  %7118 = select i1 %7091, <8 x i1> zeroinitializer, <8 x i1> %7116
  store <8 x i1> %7118, ptr %7114, align 1
  %7119 = add i32 %7098, 1
  %7120 = select i1 %7089, i32 %7076, i32 %7119
  %7121 = select i1 true, i32 %7120, i32 %7076
  store i32 %7121, ptr %current.token, align 4
  %7122 = load i32, ptr %current.token, align 4
  %7123 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %867)
  %7124 = load i32, ptr %ready.count, align 4
  %7125 = icmp uge i32 %7124, 8
  %7126 = and i1 %7123, %7125
  br i1 %7126, label %ready.overflow.trap1172, label %ready.overflow.resume1173

ready.overflow.trap1172:                          ; preds = %convergence.overflow.resume1171
  call void @llvm.trap()
  unreachable

ready.overflow.resume1173:                        ; preds = %convergence.overflow.resume1171
  %7127 = select i1 %7123, i32 %7124, i32 0
  %7128 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7127
  %7129 = load <8 x i1>, ptr %7128, align 1
  %7130 = select i1 %7123, <8 x i1> %867, <8 x i1> %7129
  store <8 x i1> %7130, ptr %7128, align 1
  %7131 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7127
  %7132 = load i32, ptr %7131, align 4
  %7133 = select i1 %7123, i32 52, i32 %7132
  store i32 %7133, ptr %7131, align 4
  %7134 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7127
  %7135 = load i32, ptr %7134, align 4
  %7136 = select i1 %7123, i32 %7122, i32 %7135
  store i32 %7136, ptr %7134, align 4
  %7137 = add i32 %7124, 1
  %7138 = select i1 %7123, i32 %7137, i32 %7124
  store i32 %7138, ptr %ready.count, align 4
  %7139 = load <8 x i1>, ptr %runnable.mask, align 1
  %7140 = or <8 x i1> %7139, %867
  store <8 x i1> %7140, ptr %runnable.mask, align 1
  store <8 x i1> %869, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1174:                        ; preds = %varying.coherent1169
  store <8 x i1> %860, ptr %current.mask, align 1
  %7141 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %860)
  br i1 %7141, label %schedule.52, label %scheduler.loop

varying.coherent.false1175:                       ; preds = %varying.coherent1169
  store <8 x i1> %860, ptr %current.mask, align 1
  %7142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %860)
  br i1 %7142, label %schedule.53, label %scheduler.loop

convergence.cascade1181:                          ; preds = %convergence.cascade1181, %schedule.53
  %convergence.cascade.flow1185 = phi <8 x i1> [ %902, %schedule.53 ], [ %7185, %convergence.cascade1181 ]
  %convergence.cascade.depth1186 = phi i32 [ 0, %schedule.53 ], [ %7186, %convergence.cascade1181 ]
  %7143 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1185)
  %7144 = load i32, ptr %current.token, align 4
  %7145 = icmp ne i32 %7144, 0
  %7146 = and i1 %7143, %7145
  %7147 = sub i32 %7144, 1
  %7148 = select i1 %7146, i32 %7147, i32 0
  %7149 = load i8, ptr %frame.active, align 1
  %7150 = trunc i32 %7148 to i8
  %7151 = shl i8 1, %7150
  %7152 = and i8 %7149, %7151
  %7153 = icmp ne i8 %7152, 0
  %7154 = load <8 x i32>, ptr %frame.static.id, align 32
  %7155 = extractelement <8 x i32> %7154, i32 %7148
  %convergence.target.pointer1187 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7155
  %convergence.dynamic.target1188 = load i32, ptr %convergence.target.pointer1187, align 4
  %7156 = icmp eq i32 %convergence.dynamic.target1188, 53
  %7157 = and i1 %7153, %7156
  %7158 = and i1 %7146, %7157
  %7159 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7148
  %7160 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7148
  %7161 = load <8 x i1>, ptr %7159, align 1
  %7162 = load <8 x i1>, ptr %7160, align 1
  %7163 = or <8 x i1> %7162, %convergence.cascade.flow1185
  %7164 = load <8 x i1>, ptr %live.mask, align 1
  %7165 = and <8 x i1> %7161, %7164
  %7166 = icmp eq <8 x i1> %7163, %7165
  %7167 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7166)
  %7168 = and i1 %7158, %7167
  %7169 = select i1 %7168, <8 x i1> zeroinitializer, <8 x i1> %7163
  %7170 = select i1 %7158, <8 x i1> %7169, <8 x i1> %7162
  store <8 x i1> %7170, ptr %7160, align 1
  %7171 = select i1 %7168, <8 x i1> zeroinitializer, <8 x i1> %7161
  store <8 x i1> %7171, ptr %7159, align 1
  %7172 = trunc i32 %7148 to i8
  %7173 = shl i8 1, %7172
  %7174 = xor i8 %7173, -1
  %7175 = and i8 %7149, %7174
  %7176 = select i1 %7168, i8 %7175, i8 %7149
  store i8 %7176, ptr %frame.active, align 1
  %.splatinsert1189 = insertelement <8 x i1> poison, i1 %7158, i64 0
  %.splat1190 = shufflevector <8 x i1> %.splatinsert1189, <8 x i1> poison, <8 x i32> zeroinitializer
  %7177 = and <8 x i1> %convergence.cascade.flow1185, %.splat1190
  %7178 = load <8 x i1>, ptr %runnable.mask, align 1
  %7179 = xor <8 x i1> %7177, splat (i1 true)
  %7180 = and <8 x i1> %7178, %7179
  store <8 x i1> %7180, ptr %runnable.mask, align 1
  %.splatinsert1191 = insertelement <8 x i1> poison, i1 %7168, i64 0
  %.splat1192 = shufflevector <8 x i1> %.splatinsert1191, <8 x i1> poison, <8 x i32> zeroinitializer
  %7181 = select <8 x i1> %.splat1192, <8 x i1> %7163, <8 x i1> zeroinitializer
  %7182 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7183 = extractelement <8 x i32> %7182, i32 %7148
  %7184 = select i1 %7168, i32 %7183, i32 %7144
  store i32 %7184, ptr %current.token, align 4
  %.splatinsert1193 = insertelement <8 x i1> poison, i1 %7158, i64 0
  %.splat1194 = shufflevector <8 x i1> %.splatinsert1193, <8 x i1> poison, <8 x i32> zeroinitializer
  %7185 = select <8 x i1> %.splat1194, <8 x i1> %7181, <8 x i1> %convergence.cascade.flow1185
  %7186 = add i32 %convergence.cascade.depth1186, 1
  %7187 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7185)
  %7188 = icmp ult i32 %7186, 8
  %7189 = and i1 %7187, %7188
  %7190 = and i1 %7158, %7189
  %convergence.parent.token1195 = load i32, ptr %current.token, align 4
  %convergence.parent.present1196 = icmp ne i32 %convergence.parent.token1195, 0
  %7191 = and i1 %7190, %convergence.parent.present1196
  br i1 %7191, label %convergence.cascade1181, label %convergence.cascade.exit1182

convergence.cascade.exit1182:                     ; preds = %convergence.cascade1181, %schedule.53
  %convergence.cascade.result1197 = phi <8 x i1> [ %902, %schedule.53 ], [ %7185, %convergence.cascade1181 ]
  %7192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1197)
  br i1 %7192, label %convergence.target.53.ready, label %scheduler.loop

convergence.target.53.ready:                      ; preds = %convergence.cascade.exit1182
  %7193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1197)
  %7194 = bitcast <8 x i1> %convergence.cascade.result1197 to i8
  %7195 = call i8 @llvm.cttz.i8(i8 %7194, i1 false)
  %7196 = zext i8 %7195 to i32
  %7197 = select i1 %7193, i32 %7196, i32 0
  %.state1198 = load <8 x i64>, ptr %.slot57, align 64
  %7198 = add <8 x i64> %.state1198, splat (i64 1)
  %.spill.load1199 = load volatile <8 x float>, ptr %.spill212, align 32
  %.spill.load1200 = load volatile <8 x float>, ptr %.spill213, align 32
  %.spill.load1201 = load volatile <8 x float>, ptr %.spill214, align 32
  %.spill.load1202 = load volatile <8 x float>, ptr %.spill215, align 32
  %.spill.load1203 = load volatile <8 x float>, ptr %.spill230, align 32
  %.spill.load1204 = load volatile <8 x float>, ptr %.spill231, align 32
  %.spill.load1205 = load volatile <8 x float>, ptr %.spill232, align 32
  %.spill.load1206 = load volatile <8 x float>, ptr %.spill233, align 32
  %7199 = load <8 x i64>, ptr %.slot57, align 64
  %7200 = select <8 x i1> %convergence.cascade.result1197, <8 x i64> %7198, <8 x i64> %7199
  store <8 x i64> %7200, ptr %.slot57, align 64
  %7201 = load <8 x float>, ptr %.slot58, align 32
  %7202 = select <8 x i1> %convergence.cascade.result1197, <8 x float> %.spill.load1199, <8 x float> %7201
  store <8 x float> %7202, ptr %.slot58, align 32
  %7203 = load <8 x float>, ptr %.slot59, align 32
  %7204 = select <8 x i1> %convergence.cascade.result1197, <8 x float> %.spill.load1200, <8 x float> %7203
  store <8 x float> %7204, ptr %.slot59, align 32
  %7205 = load <8 x float>, ptr %.slot60, align 32
  %7206 = select <8 x i1> %convergence.cascade.result1197, <8 x float> %.spill.load1201, <8 x float> %7205
  store <8 x float> %7206, ptr %.slot60, align 32
  %7207 = load <8 x float>, ptr %.slot61, align 32
  %7208 = select <8 x i1> %convergence.cascade.result1197, <8 x float> %.spill.load1202, <8 x float> %7207
  store <8 x float> %7208, ptr %.slot61, align 32
  %7209 = load <8 x float>, ptr %.slot62, align 32
  %7210 = select <8 x i1> %convergence.cascade.result1197, <8 x float> %.spill.load1203, <8 x float> %7209
  store <8 x float> %7210, ptr %.slot62, align 32
  %7211 = load <8 x float>, ptr %.slot63, align 32
  %7212 = select <8 x i1> %convergence.cascade.result1197, <8 x float> %.spill.load1204, <8 x float> %7211
  store <8 x float> %7212, ptr %.slot63, align 32
  %7213 = load <8 x float>, ptr %.slot64, align 32
  %7214 = select <8 x i1> %convergence.cascade.result1197, <8 x float> %.spill.load1205, <8 x float> %7213
  store <8 x float> %7214, ptr %.slot64, align 32
  %7215 = load <8 x float>, ptr %.slot65, align 32
  %7216 = select <8 x i1> %convergence.cascade.result1197, <8 x float> %.spill.load1206, <8 x float> %7215
  store <8 x float> %7216, ptr %.slot65, align 32
  store <8 x i1> %convergence.cascade.result1197, ptr %current.mask, align 1
  %7217 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1197)
  br i1 %7217, label %schedule.9, label %scheduler.loop

convergence.cascade1207:                          ; preds = %convergence.cascade1207, %schedule.54
  %convergence.cascade.flow1211 = phi <8 x i1> [ %903, %schedule.54 ], [ %7260, %convergence.cascade1207 ]
  %convergence.cascade.depth1212 = phi i32 [ 0, %schedule.54 ], [ %7261, %convergence.cascade1207 ]
  %7218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1211)
  %7219 = load i32, ptr %current.token, align 4
  %7220 = icmp ne i32 %7219, 0
  %7221 = and i1 %7218, %7220
  %7222 = sub i32 %7219, 1
  %7223 = select i1 %7221, i32 %7222, i32 0
  %7224 = load i8, ptr %frame.active, align 1
  %7225 = trunc i32 %7223 to i8
  %7226 = shl i8 1, %7225
  %7227 = and i8 %7224, %7226
  %7228 = icmp ne i8 %7227, 0
  %7229 = load <8 x i32>, ptr %frame.static.id, align 32
  %7230 = extractelement <8 x i32> %7229, i32 %7223
  %convergence.target.pointer1213 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7230
  %convergence.dynamic.target1214 = load i32, ptr %convergence.target.pointer1213, align 4
  %7231 = icmp eq i32 %convergence.dynamic.target1214, 54
  %7232 = and i1 %7228, %7231
  %7233 = and i1 %7221, %7232
  %7234 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7223
  %7235 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7223
  %7236 = load <8 x i1>, ptr %7234, align 1
  %7237 = load <8 x i1>, ptr %7235, align 1
  %7238 = or <8 x i1> %7237, %convergence.cascade.flow1211
  %7239 = load <8 x i1>, ptr %live.mask, align 1
  %7240 = and <8 x i1> %7236, %7239
  %7241 = icmp eq <8 x i1> %7238, %7240
  %7242 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7241)
  %7243 = and i1 %7233, %7242
  %7244 = select i1 %7243, <8 x i1> zeroinitializer, <8 x i1> %7238
  %7245 = select i1 %7233, <8 x i1> %7244, <8 x i1> %7237
  store <8 x i1> %7245, ptr %7235, align 1
  %7246 = select i1 %7243, <8 x i1> zeroinitializer, <8 x i1> %7236
  store <8 x i1> %7246, ptr %7234, align 1
  %7247 = trunc i32 %7223 to i8
  %7248 = shl i8 1, %7247
  %7249 = xor i8 %7248, -1
  %7250 = and i8 %7224, %7249
  %7251 = select i1 %7243, i8 %7250, i8 %7224
  store i8 %7251, ptr %frame.active, align 1
  %.splatinsert1215 = insertelement <8 x i1> poison, i1 %7233, i64 0
  %.splat1216 = shufflevector <8 x i1> %.splatinsert1215, <8 x i1> poison, <8 x i32> zeroinitializer
  %7252 = and <8 x i1> %convergence.cascade.flow1211, %.splat1216
  %7253 = load <8 x i1>, ptr %runnable.mask, align 1
  %7254 = xor <8 x i1> %7252, splat (i1 true)
  %7255 = and <8 x i1> %7253, %7254
  store <8 x i1> %7255, ptr %runnable.mask, align 1
  %.splatinsert1217 = insertelement <8 x i1> poison, i1 %7243, i64 0
  %.splat1218 = shufflevector <8 x i1> %.splatinsert1217, <8 x i1> poison, <8 x i32> zeroinitializer
  %7256 = select <8 x i1> %.splat1218, <8 x i1> %7238, <8 x i1> zeroinitializer
  %7257 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7258 = extractelement <8 x i32> %7257, i32 %7223
  %7259 = select i1 %7243, i32 %7258, i32 %7219
  store i32 %7259, ptr %current.token, align 4
  %.splatinsert1219 = insertelement <8 x i1> poison, i1 %7233, i64 0
  %.splat1220 = shufflevector <8 x i1> %.splatinsert1219, <8 x i1> poison, <8 x i32> zeroinitializer
  %7260 = select <8 x i1> %.splat1220, <8 x i1> %7256, <8 x i1> %convergence.cascade.flow1211
  %7261 = add i32 %convergence.cascade.depth1212, 1
  %7262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7260)
  %7263 = icmp ult i32 %7261, 8
  %7264 = and i1 %7262, %7263
  %7265 = and i1 %7233, %7264
  %convergence.parent.token1221 = load i32, ptr %current.token, align 4
  %convergence.parent.present1222 = icmp ne i32 %convergence.parent.token1221, 0
  %7266 = and i1 %7265, %convergence.parent.present1222
  br i1 %7266, label %convergence.cascade1207, label %convergence.cascade.exit1208

convergence.cascade.exit1208:                     ; preds = %convergence.cascade1207, %schedule.54
  %convergence.cascade.result1223 = phi <8 x i1> [ %903, %schedule.54 ], [ %7260, %convergence.cascade1207 ]
  %7267 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1223)
  br i1 %7267, label %convergence.target.54.ready, label %scheduler.loop

convergence.target.54.ready:                      ; preds = %convergence.cascade.exit1208
  %7268 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1223)
  %7269 = bitcast <8 x i1> %convergence.cascade.result1223 to i8
  %7270 = call i8 @llvm.cttz.i8(i8 %7269, i1 false)
  %7271 = zext i8 %7270 to i32
  %7272 = select i1 %7268, i32 %7271, i32 0
  %7273 = load volatile { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill239, align 64
  %7274 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7275 = extractvalue { <8 x ptr>, <8 x i64> } %7273, 0
  %7276 = select <8 x i1> %convergence.cascade.result1223, <8 x ptr> %7274, <8 x ptr> %7275
  %7277 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %7278 = extractvalue { <8 x ptr>, <8 x i64> } %7273, 1
  %7279 = select <8 x i1> %convergence.cascade.result1223, <8 x i64> %7277, <8 x i64> %7278
  %7280 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7276, 0
  %7281 = insertvalue { <8 x ptr>, <8 x i64> } %7280, <8 x i64> %7279, 1
  store volatile { <8 x ptr>, <8 x i64> } %7281, ptr %tile_snapshot.spill239, align 64
  %7282 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7283 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %7284 = add <8 x i64> %7283, zeroinitializer
  %7285 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7282, 0
  %7286 = insertvalue { <8 x ptr>, <8 x i64> } %7285, <8 x i64> %7284, 1
  %.state1224 = load <8 x float>, ptr %.slot62, align 32
  %7287 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7288 = extractvalue { <8 x ptr>, <8 x i64> } %7286, 1
  %7289 = extractelement <8 x ptr> %7287, i32 0
  %7290 = extractelement <8 x i64> %7288, i32 %7272
  %7291 = zext i32 %7272 to i64
  %7292 = mul i64 %7291, 4
  %7293 = sub i64 %7290, %7292
  %7294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1223)
  %7295 = select i1 %7294, i64 %7293, i64 0
  %private.contiguous.address1225 = getelementptr i8, ptr %7289, i64 %7295
  %private.contiguous.preserve1226 = load <8 x float>, ptr %private.contiguous.address1225, align 4
  %7296 = select <8 x i1> %convergence.cascade.result1223, <8 x float> %.state1224, <8 x float> %private.contiguous.preserve1226
  store <8 x float> %7296, ptr %private.contiguous.address1225, align 4
  %7297 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7298 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %7299 = add <8 x i64> %7298, splat (i64 32)
  %7300 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7297, 0
  %7301 = insertvalue { <8 x ptr>, <8 x i64> } %7300, <8 x i64> %7299, 1
  %.state1227 = load <8 x float>, ptr %.slot63, align 32
  %7302 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7303 = extractvalue { <8 x ptr>, <8 x i64> } %7301, 1
  %7304 = extractelement <8 x ptr> %7302, i32 0
  %7305 = extractelement <8 x i64> %7303, i32 %7272
  %7306 = zext i32 %7272 to i64
  %7307 = mul i64 %7306, 4
  %7308 = sub i64 %7305, %7307
  %7309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1223)
  %7310 = select i1 %7309, i64 %7308, i64 0
  %private.contiguous.address1228 = getelementptr i8, ptr %7304, i64 %7310
  %private.contiguous.preserve1229 = load <8 x float>, ptr %private.contiguous.address1228, align 4
  %7311 = select <8 x i1> %convergence.cascade.result1223, <8 x float> %.state1227, <8 x float> %private.contiguous.preserve1229
  store <8 x float> %7311, ptr %private.contiguous.address1228, align 4
  %7312 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7313 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %7314 = add <8 x i64> %7313, splat (i64 64)
  %7315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7312, 0
  %7316 = insertvalue { <8 x ptr>, <8 x i64> } %7315, <8 x i64> %7314, 1
  %.state1230 = load <8 x float>, ptr %.slot64, align 32
  %7317 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7318 = extractvalue { <8 x ptr>, <8 x i64> } %7316, 1
  %7319 = extractelement <8 x ptr> %7317, i32 0
  %7320 = extractelement <8 x i64> %7318, i32 %7272
  %7321 = zext i32 %7272 to i64
  %7322 = mul i64 %7321, 4
  %7323 = sub i64 %7320, %7322
  %7324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1223)
  %7325 = select i1 %7324, i64 %7323, i64 0
  %private.contiguous.address1231 = getelementptr i8, ptr %7319, i64 %7325
  %private.contiguous.preserve1232 = load <8 x float>, ptr %private.contiguous.address1231, align 4
  %7326 = select <8 x i1> %convergence.cascade.result1223, <8 x float> %.state1230, <8 x float> %private.contiguous.preserve1232
  store <8 x float> %7326, ptr %private.contiguous.address1231, align 4
  %7327 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7328 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %7329 = add <8 x i64> %7328, splat (i64 96)
  %7330 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7327, 0
  %7331 = insertvalue { <8 x ptr>, <8 x i64> } %7330, <8 x i64> %7329, 1
  %.state1233 = load <8 x float>, ptr %.slot65, align 32
  %7332 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %7333 = extractvalue { <8 x ptr>, <8 x i64> } %7331, 1
  %7334 = extractelement <8 x ptr> %7332, i32 0
  %7335 = extractelement <8 x i64> %7333, i32 %7272
  %7336 = zext i32 %7272 to i64
  %7337 = mul i64 %7336, 4
  %7338 = sub i64 %7335, %7337
  %7339 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1223)
  %7340 = select i1 %7339, i64 %7338, i64 0
  %private.contiguous.address1234 = getelementptr i8, ptr %7334, i64 %7340
  %private.contiguous.preserve1235 = load <8 x float>, ptr %private.contiguous.address1234, align 4
  %7341 = select <8 x i1> %convergence.cascade.result1223, <8 x float> %.state1233, <8 x float> %private.contiguous.preserve1235
  store <8 x float> %7341, ptr %private.contiguous.address1234, align 4
  %7342 = load <8 x i64>, ptr %.slot240, align 64
  %7343 = select <8 x i1> %convergence.cascade.result1223, <8 x i64> zeroinitializer, <8 x i64> %7342
  store <8 x i64> %7343, ptr %.slot240, align 64
  store <8 x i1> %convergence.cascade.result1223, ptr %current.mask, align 1
  %7344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1223)
  br i1 %7344, label %schedule.55, label %scheduler.loop

varying.divergent1237:                            ; preds = %schedule.55
  %7345 = load i32, ptr %current.token, align 4
  %7346 = icmp ne i32 %7345, 0
  %7347 = sub i32 %7345, 1
  %7348 = select i1 %7346, i32 %7347, i32 0
  %7349 = load i8, ptr %frame.active, align 1
  %7350 = trunc i32 %7348 to i8
  %7351 = shl i8 1, %7350
  %7352 = and i8 %7349, %7351
  %7353 = icmp ne i8 %7352, 0
  %7354 = load <8 x i32>, ptr %frame.static.id, align 32
  %7355 = extractelement <8 x i32> %7354, i32 %7348
  %7356 = icmp eq i32 %7355, 19
  %7357 = and i1 %7353, %7356
  %7358 = and i1 %7346, %7357
  %7359 = xor i1 %7358, true
  %7360 = and i1 true, %7359
  %7361 = xor i8 %7349, -1
  %7362 = icmp ne i8 %7361, 0
  %7363 = xor i1 %7362, true
  %7364 = and i1 %7360, %7363
  br i1 %7364, label %convergence.overflow.trap1239, label %convergence.overflow.resume1240

varying.coherent1238:                             ; preds = %schedule.55
  br i1 %914, label %varying.coherent.true1243, label %varying.coherent.false1244

convergence.overflow.trap1239:                    ; preds = %varying.divergent1237
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1240:                  ; preds = %varying.divergent1237
  %7365 = call i8 @llvm.cttz.i8(i8 %7361, i1 false)
  %7366 = zext i8 %7365 to i32
  %7367 = select i1 %7362, i32 %7366, i32 0
  %7368 = trunc i32 %7367 to i8
  %7369 = shl i8 1, %7368
  %7370 = or i8 %7349, %7369
  %7371 = select i1 %7360, i8 %7370, i8 %7349
  store i8 %7371, ptr %frame.active, align 1
  %7372 = load <8 x i32>, ptr %frame.static.id, align 32
  %7373 = extractelement <8 x i32> %7372, i32 %7367
  %7374 = select i1 %7360, i32 19, i32 %7373
  %7375 = load <8 x i32>, ptr %frame.static.id, align 32
  %7376 = insertelement <8 x i32> %7375, i32 %7374, i32 %7367
  store <8 x i32> %7376, ptr %frame.static.id, align 32
  %7377 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7378 = extractelement <8 x i32> %7377, i32 %7367
  %7379 = select i1 %7360, i32 %7345, i32 %7378
  %7380 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7381 = insertelement <8 x i32> %7380, i32 %7379, i32 %7367
  store <8 x i32> %7381, ptr %frame.parent.token, align 32
  %7382 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7367
  %7383 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7367
  %7384 = load <8 x i1>, ptr %7382, align 1
  %7385 = load <8 x i1>, ptr %7383, align 1
  %7386 = select i1 %7360, <8 x i1> %904, <8 x i1> %7384
  store <8 x i1> %7386, ptr %7382, align 1
  %7387 = select i1 %7360, <8 x i1> zeroinitializer, <8 x i1> %7385
  store <8 x i1> %7387, ptr %7383, align 1
  %7388 = add i32 %7367, 1
  %7389 = select i1 %7358, i32 %7345, i32 %7388
  %7390 = select i1 true, i32 %7389, i32 %7345
  store i32 %7390, ptr %current.token, align 4
  %7391 = load i32, ptr %current.token, align 4
  %7392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %911)
  %7393 = load i32, ptr %ready.count, align 4
  %7394 = icmp uge i32 %7393, 8
  %7395 = and i1 %7392, %7394
  br i1 %7395, label %ready.overflow.trap1241, label %ready.overflow.resume1242

ready.overflow.trap1241:                          ; preds = %convergence.overflow.resume1240
  call void @llvm.trap()
  unreachable

ready.overflow.resume1242:                        ; preds = %convergence.overflow.resume1240
  %7396 = select i1 %7392, i32 %7393, i32 0
  %7397 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7396
  %7398 = load <8 x i1>, ptr %7397, align 1
  %7399 = select i1 %7392, <8 x i1> %911, <8 x i1> %7398
  store <8 x i1> %7399, ptr %7397, align 1
  %7400 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7396
  %7401 = load i32, ptr %7400, align 4
  %7402 = select i1 %7392, i32 56, i32 %7401
  store i32 %7402, ptr %7400, align 4
  %7403 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7396
  %7404 = load i32, ptr %7403, align 4
  %7405 = select i1 %7392, i32 %7391, i32 %7404
  store i32 %7405, ptr %7403, align 4
  %7406 = add i32 %7393, 1
  %7407 = select i1 %7392, i32 %7406, i32 %7393
  store i32 %7407, ptr %ready.count, align 4
  %7408 = load <8 x i1>, ptr %runnable.mask, align 1
  %7409 = or <8 x i1> %7408, %911
  store <8 x i1> %7409, ptr %runnable.mask, align 1
  store <8 x i1> %913, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1243:                        ; preds = %varying.coherent1238
  store <8 x i1> %904, ptr %current.mask, align 1
  %7410 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %904)
  br i1 %7410, label %schedule.56, label %scheduler.loop

varying.coherent.false1244:                       ; preds = %varying.coherent1238
  store <8 x i1> %904, ptr %current.mask, align 1
  %7411 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %904)
  br i1 %7411, label %schedule.59, label %scheduler.loop

varying.divergent1252:                            ; preds = %schedule.56
  %7412 = load i32, ptr %current.token, align 4
  %7413 = icmp ne i32 %7412, 0
  %7414 = sub i32 %7412, 1
  %7415 = select i1 %7413, i32 %7414, i32 0
  %7416 = load i8, ptr %frame.active, align 1
  %7417 = trunc i32 %7415 to i8
  %7418 = shl i8 1, %7417
  %7419 = and i8 %7416, %7418
  %7420 = icmp ne i8 %7419, 0
  %7421 = load <8 x i32>, ptr %frame.static.id, align 32
  %7422 = extractelement <8 x i32> %7421, i32 %7415
  %7423 = icmp eq i32 %7422, 20
  %7424 = and i1 %7420, %7423
  %7425 = and i1 %7413, %7424
  %7426 = xor i1 %7425, true
  %7427 = and i1 true, %7426
  %7428 = xor i8 %7416, -1
  %7429 = icmp ne i8 %7428, 0
  %7430 = xor i1 %7429, true
  %7431 = and i1 %7427, %7430
  br i1 %7431, label %convergence.overflow.trap1254, label %convergence.overflow.resume1255

varying.coherent1253:                             ; preds = %schedule.56
  br i1 %975, label %varying.coherent.true1258, label %varying.coherent.false1259

convergence.overflow.trap1254:                    ; preds = %varying.divergent1252
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1255:                  ; preds = %varying.divergent1252
  %7432 = call i8 @llvm.cttz.i8(i8 %7428, i1 false)
  %7433 = zext i8 %7432 to i32
  %7434 = select i1 %7429, i32 %7433, i32 0
  %7435 = trunc i32 %7434 to i8
  %7436 = shl i8 1, %7435
  %7437 = or i8 %7416, %7436
  %7438 = select i1 %7427, i8 %7437, i8 %7416
  store i8 %7438, ptr %frame.active, align 1
  %7439 = load <8 x i32>, ptr %frame.static.id, align 32
  %7440 = extractelement <8 x i32> %7439, i32 %7434
  %7441 = select i1 %7427, i32 20, i32 %7440
  %7442 = load <8 x i32>, ptr %frame.static.id, align 32
  %7443 = insertelement <8 x i32> %7442, i32 %7441, i32 %7434
  store <8 x i32> %7443, ptr %frame.static.id, align 32
  %7444 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7445 = extractelement <8 x i32> %7444, i32 %7434
  %7446 = select i1 %7427, i32 %7412, i32 %7445
  %7447 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7448 = insertelement <8 x i32> %7447, i32 %7446, i32 %7434
  store <8 x i32> %7448, ptr %frame.parent.token, align 32
  %7449 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7434
  %7450 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7434
  %7451 = load <8 x i1>, ptr %7449, align 1
  %7452 = load <8 x i1>, ptr %7450, align 1
  %7453 = select i1 %7427, <8 x i1> %917, <8 x i1> %7451
  store <8 x i1> %7453, ptr %7449, align 1
  %7454 = select i1 %7427, <8 x i1> zeroinitializer, <8 x i1> %7452
  store <8 x i1> %7454, ptr %7450, align 1
  %7455 = add i32 %7434, 1
  %7456 = select i1 %7425, i32 %7412, i32 %7455
  %7457 = select i1 true, i32 %7456, i32 %7412
  store i32 %7457, ptr %current.token, align 4
  %7458 = load i32, ptr %current.token, align 4
  %7459 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %972)
  %7460 = load i32, ptr %ready.count, align 4
  %7461 = icmp uge i32 %7460, 8
  %7462 = and i1 %7459, %7461
  br i1 %7462, label %ready.overflow.trap1256, label %ready.overflow.resume1257

ready.overflow.trap1256:                          ; preds = %convergence.overflow.resume1255
  call void @llvm.trap()
  unreachable

ready.overflow.resume1257:                        ; preds = %convergence.overflow.resume1255
  %7463 = select i1 %7459, i32 %7460, i32 0
  %7464 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7463
  %7465 = load <8 x i1>, ptr %7464, align 1
  %7466 = select i1 %7459, <8 x i1> %972, <8 x i1> %7465
  store <8 x i1> %7466, ptr %7464, align 1
  %7467 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7463
  %7468 = load i32, ptr %7467, align 4
  %7469 = select i1 %7459, i32 57, i32 %7468
  store i32 %7469, ptr %7467, align 4
  %7470 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7463
  %7471 = load i32, ptr %7470, align 4
  %7472 = select i1 %7459, i32 %7458, i32 %7471
  store i32 %7472, ptr %7470, align 4
  %7473 = add i32 %7460, 1
  %7474 = select i1 %7459, i32 %7473, i32 %7460
  store i32 %7474, ptr %ready.count, align 4
  %7475 = load <8 x i1>, ptr %runnable.mask, align 1
  %7476 = or <8 x i1> %7475, %972
  store <8 x i1> %7476, ptr %runnable.mask, align 1
  store <8 x i1> %974, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1258:                        ; preds = %varying.coherent1253
  store <8 x i1> %917, ptr %current.mask, align 1
  %7477 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %917)
  br i1 %7477, label %schedule.57, label %scheduler.loop

varying.coherent.false1259:                       ; preds = %varying.coherent1253
  store <8 x i1> %917, ptr %current.mask, align 1
  %7478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %917)
  br i1 %7478, label %schedule.58, label %scheduler.loop

convergence.cascade1262:                          ; preds = %convergence.cascade1262, %schedule.58
  %convergence.cascade.flow1266 = phi <8 x i1> [ %988, %schedule.58 ], [ %7521, %convergence.cascade1262 ]
  %convergence.cascade.depth1267 = phi i32 [ 0, %schedule.58 ], [ %7522, %convergence.cascade1262 ]
  %7479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1266)
  %7480 = load i32, ptr %current.token, align 4
  %7481 = icmp ne i32 %7480, 0
  %7482 = and i1 %7479, %7481
  %7483 = sub i32 %7480, 1
  %7484 = select i1 %7482, i32 %7483, i32 0
  %7485 = load i8, ptr %frame.active, align 1
  %7486 = trunc i32 %7484 to i8
  %7487 = shl i8 1, %7486
  %7488 = and i8 %7485, %7487
  %7489 = icmp ne i8 %7488, 0
  %7490 = load <8 x i32>, ptr %frame.static.id, align 32
  %7491 = extractelement <8 x i32> %7490, i32 %7484
  %convergence.target.pointer1268 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7491
  %convergence.dynamic.target1269 = load i32, ptr %convergence.target.pointer1268, align 4
  %7492 = icmp eq i32 %convergence.dynamic.target1269, 58
  %7493 = and i1 %7489, %7492
  %7494 = and i1 %7482, %7493
  %7495 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7484
  %7496 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7484
  %7497 = load <8 x i1>, ptr %7495, align 1
  %7498 = load <8 x i1>, ptr %7496, align 1
  %7499 = or <8 x i1> %7498, %convergence.cascade.flow1266
  %7500 = load <8 x i1>, ptr %live.mask, align 1
  %7501 = and <8 x i1> %7497, %7500
  %7502 = icmp eq <8 x i1> %7499, %7501
  %7503 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7502)
  %7504 = and i1 %7494, %7503
  %7505 = select i1 %7504, <8 x i1> zeroinitializer, <8 x i1> %7499
  %7506 = select i1 %7494, <8 x i1> %7505, <8 x i1> %7498
  store <8 x i1> %7506, ptr %7496, align 1
  %7507 = select i1 %7504, <8 x i1> zeroinitializer, <8 x i1> %7497
  store <8 x i1> %7507, ptr %7495, align 1
  %7508 = trunc i32 %7484 to i8
  %7509 = shl i8 1, %7508
  %7510 = xor i8 %7509, -1
  %7511 = and i8 %7485, %7510
  %7512 = select i1 %7504, i8 %7511, i8 %7485
  store i8 %7512, ptr %frame.active, align 1
  %.splatinsert1270 = insertelement <8 x i1> poison, i1 %7494, i64 0
  %.splat1271 = shufflevector <8 x i1> %.splatinsert1270, <8 x i1> poison, <8 x i32> zeroinitializer
  %7513 = and <8 x i1> %convergence.cascade.flow1266, %.splat1271
  %7514 = load <8 x i1>, ptr %runnable.mask, align 1
  %7515 = xor <8 x i1> %7513, splat (i1 true)
  %7516 = and <8 x i1> %7514, %7515
  store <8 x i1> %7516, ptr %runnable.mask, align 1
  %.splatinsert1272 = insertelement <8 x i1> poison, i1 %7504, i64 0
  %.splat1273 = shufflevector <8 x i1> %.splatinsert1272, <8 x i1> poison, <8 x i32> zeroinitializer
  %7517 = select <8 x i1> %.splat1273, <8 x i1> %7499, <8 x i1> zeroinitializer
  %7518 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7519 = extractelement <8 x i32> %7518, i32 %7484
  %7520 = select i1 %7504, i32 %7519, i32 %7480
  store i32 %7520, ptr %current.token, align 4
  %.splatinsert1274 = insertelement <8 x i1> poison, i1 %7494, i64 0
  %.splat1275 = shufflevector <8 x i1> %.splatinsert1274, <8 x i1> poison, <8 x i32> zeroinitializer
  %7521 = select <8 x i1> %.splat1275, <8 x i1> %7517, <8 x i1> %convergence.cascade.flow1266
  %7522 = add i32 %convergence.cascade.depth1267, 1
  %7523 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7521)
  %7524 = icmp ult i32 %7522, 8
  %7525 = and i1 %7523, %7524
  %7526 = and i1 %7494, %7525
  %convergence.parent.token1276 = load i32, ptr %current.token, align 4
  %convergence.parent.present1277 = icmp ne i32 %convergence.parent.token1276, 0
  %7527 = and i1 %7526, %convergence.parent.present1277
  br i1 %7527, label %convergence.cascade1262, label %convergence.cascade.exit1263

convergence.cascade.exit1263:                     ; preds = %convergence.cascade1262, %schedule.58
  %convergence.cascade.result1278 = phi <8 x i1> [ %988, %schedule.58 ], [ %7521, %convergence.cascade1262 ]
  %7528 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1278)
  br i1 %7528, label %convergence.target.58.ready, label %scheduler.loop

convergence.target.58.ready:                      ; preds = %convergence.cascade.exit1263
  %7529 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1278)
  %7530 = bitcast <8 x i1> %convergence.cascade.result1278 to i8
  %7531 = call i8 @llvm.cttz.i8(i8 %7530, i1 false)
  %7532 = zext i8 %7531 to i32
  %7533 = select i1 %7529, i32 %7532, i32 0
  %.state1279 = load <8 x i64>, ptr %.slot240, align 64
  %7534 = add <8 x i64> %.state1279, splat (i64 1)
  %7535 = load <8 x i64>, ptr %.slot240, align 64
  %7536 = select <8 x i1> %convergence.cascade.result1278, <8 x i64> %7534, <8 x i64> %7535
  store <8 x i64> %7536, ptr %.slot240, align 64
  store <8 x i1> %convergence.cascade.result1278, ptr %current.mask, align 1
  %7537 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1278)
  br i1 %7537, label %schedule.55, label %scheduler.loop

convergence.cascade1280:                          ; preds = %convergence.cascade1280, %schedule.59
  %convergence.cascade.flow1284 = phi <8 x i1> [ %989, %schedule.59 ], [ %7580, %convergence.cascade1280 ]
  %convergence.cascade.depth1285 = phi i32 [ 0, %schedule.59 ], [ %7581, %convergence.cascade1280 ]
  %7538 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1284)
  %7539 = load i32, ptr %current.token, align 4
  %7540 = icmp ne i32 %7539, 0
  %7541 = and i1 %7538, %7540
  %7542 = sub i32 %7539, 1
  %7543 = select i1 %7541, i32 %7542, i32 0
  %7544 = load i8, ptr %frame.active, align 1
  %7545 = trunc i32 %7543 to i8
  %7546 = shl i8 1, %7545
  %7547 = and i8 %7544, %7546
  %7548 = icmp ne i8 %7547, 0
  %7549 = load <8 x i32>, ptr %frame.static.id, align 32
  %7550 = extractelement <8 x i32> %7549, i32 %7543
  %convergence.target.pointer1286 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7550
  %convergence.dynamic.target1287 = load i32, ptr %convergence.target.pointer1286, align 4
  %7551 = icmp eq i32 %convergence.dynamic.target1287, 59
  %7552 = and i1 %7548, %7551
  %7553 = and i1 %7541, %7552
  %7554 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7543
  %7555 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7543
  %7556 = load <8 x i1>, ptr %7554, align 1
  %7557 = load <8 x i1>, ptr %7555, align 1
  %7558 = or <8 x i1> %7557, %convergence.cascade.flow1284
  %7559 = load <8 x i1>, ptr %live.mask, align 1
  %7560 = and <8 x i1> %7556, %7559
  %7561 = icmp eq <8 x i1> %7558, %7560
  %7562 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7561)
  %7563 = and i1 %7553, %7562
  %7564 = select i1 %7563, <8 x i1> zeroinitializer, <8 x i1> %7558
  %7565 = select i1 %7553, <8 x i1> %7564, <8 x i1> %7557
  store <8 x i1> %7565, ptr %7555, align 1
  %7566 = select i1 %7563, <8 x i1> zeroinitializer, <8 x i1> %7556
  store <8 x i1> %7566, ptr %7554, align 1
  %7567 = trunc i32 %7543 to i8
  %7568 = shl i8 1, %7567
  %7569 = xor i8 %7568, -1
  %7570 = and i8 %7544, %7569
  %7571 = select i1 %7563, i8 %7570, i8 %7544
  store i8 %7571, ptr %frame.active, align 1
  %.splatinsert1288 = insertelement <8 x i1> poison, i1 %7553, i64 0
  %.splat1289 = shufflevector <8 x i1> %.splatinsert1288, <8 x i1> poison, <8 x i32> zeroinitializer
  %7572 = and <8 x i1> %convergence.cascade.flow1284, %.splat1289
  %7573 = load <8 x i1>, ptr %runnable.mask, align 1
  %7574 = xor <8 x i1> %7572, splat (i1 true)
  %7575 = and <8 x i1> %7573, %7574
  store <8 x i1> %7575, ptr %runnable.mask, align 1
  %.splatinsert1290 = insertelement <8 x i1> poison, i1 %7563, i64 0
  %.splat1291 = shufflevector <8 x i1> %.splatinsert1290, <8 x i1> poison, <8 x i32> zeroinitializer
  %7576 = select <8 x i1> %.splat1291, <8 x i1> %7558, <8 x i1> zeroinitializer
  %7577 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7578 = extractelement <8 x i32> %7577, i32 %7543
  %7579 = select i1 %7563, i32 %7578, i32 %7539
  store i32 %7579, ptr %current.token, align 4
  %.splatinsert1292 = insertelement <8 x i1> poison, i1 %7553, i64 0
  %.splat1293 = shufflevector <8 x i1> %.splatinsert1292, <8 x i1> poison, <8 x i32> zeroinitializer
  %7580 = select <8 x i1> %.splat1293, <8 x i1> %7576, <8 x i1> %convergence.cascade.flow1284
  %7581 = add i32 %convergence.cascade.depth1285, 1
  %7582 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7580)
  %7583 = icmp ult i32 %7581, 8
  %7584 = and i1 %7582, %7583
  %7585 = and i1 %7553, %7584
  %convergence.parent.token1294 = load i32, ptr %current.token, align 4
  %convergence.parent.present1295 = icmp ne i32 %convergence.parent.token1294, 0
  %7586 = and i1 %7585, %convergence.parent.present1295
  br i1 %7586, label %convergence.cascade1280, label %convergence.cascade.exit1281

convergence.cascade.exit1281:                     ; preds = %convergence.cascade1280, %schedule.59
  %convergence.cascade.result1296 = phi <8 x i1> [ %989, %schedule.59 ], [ %7580, %convergence.cascade1280 ]
  %7587 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1296)
  br i1 %7587, label %convergence.target.59.ready, label %scheduler.loop

convergence.target.59.ready:                      ; preds = %convergence.cascade.exit1281
  %7588 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1296)
  %7589 = bitcast <8 x i1> %convergence.cascade.result1296 to i8
  %7590 = call i8 @llvm.cttz.i8(i8 %7589, i1 false)
  %7591 = zext i8 %7590 to i32
  %7592 = select i1 %7588, i32 %7591, i32 0
  %7593 = load <8 x i1>, ptr %live.mask, align 1
  %7594 = xor <8 x i1> %convergence.cascade.result1296, splat (i1 true)
  %7595 = and <8 x i1> %7593, %7594
  store <8 x i1> %7595, ptr %live.mask, align 1
  %7596 = load <8 x i1>, ptr %runnable.mask, align 1
  %7597 = xor <8 x i1> %convergence.cascade.result1296, splat (i1 true)
  %7598 = and <8 x i1> %7596, %7597
  store <8 x i1> %7598, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.59.ready
  %7599 = load i8, ptr %frame.active, align 1
  %7600 = and i8 %7599, 1
  %7601 = icmp ne i8 %7600, 0
  %7602 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %7603 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %7604 = load <8 x i1>, ptr %7602, align 1
  %7605 = load <8 x i1>, ptr %7603, align 1
  %7606 = and <8 x i1> %7604, %7595
  %7607 = icmp eq <8 x i1> %7605, %7606
  %7608 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7607)
  %7609 = and i1 %7601, %7608
  %.splatinsert1297 = insertelement <8 x i1> poison, i1 %7609, i64 0
  %.splat1298 = shufflevector <8 x i1> %.splatinsert1297, <8 x i1> poison, <8 x i32> zeroinitializer
  %7610 = select <8 x i1> %.splat1298, <8 x i1> %7605, <8 x i1> zeroinitializer
  %7611 = select i1 %7609, <8 x i1> zeroinitializer, <8 x i1> %7606
  store <8 x i1> %7611, ptr %7602, align 1
  %7612 = select i1 %7609, <8 x i1> zeroinitializer, <8 x i1> %7605
  store <8 x i1> %7612, ptr %7603, align 1
  %7613 = and i8 %7599, -2
  %7614 = select i1 %7609, i8 %7613, i8 %7599
  store i8 %7614, ptr %frame.active, align 1
  %7615 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7616 = extractelement <8 x i32> %7615, i32 0
  %7617 = load <8 x i32>, ptr %frame.static.id, align 32
  %7618 = extractelement <8 x i32> %7617, i32 0
  %convergence.target.pointer1299 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7618
  %convergence.dynamic.target1300 = load i32, ptr %convergence.target.pointer1299, align 4
  %7619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7610)
  %7620 = load i32, ptr %ready.count, align 4
  %7621 = icmp uge i32 %7620, 8
  %7622 = and i1 %7619, %7621
  br i1 %7622, label %ready.overflow.trap1301, label %ready.overflow.resume1302

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume1344, %convergence.target.59.ready
  br label %scheduler.loop

ready.overflow.trap1301:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume1302:                        ; preds = %return.frame.cleanup
  %7623 = select i1 %7619, i32 %7620, i32 0
  %7624 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7623
  %7625 = load <8 x i1>, ptr %7624, align 1
  %7626 = select i1 %7619, <8 x i1> %7610, <8 x i1> %7625
  store <8 x i1> %7626, ptr %7624, align 1
  %7627 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7623
  %7628 = load i32, ptr %7627, align 4
  %7629 = select i1 %7619, i32 %convergence.dynamic.target1300, i32 %7628
  store i32 %7629, ptr %7627, align 4
  %7630 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7623
  %7631 = load i32, ptr %7630, align 4
  %7632 = select i1 %7619, i32 %7616, i32 %7631
  store i32 %7632, ptr %7630, align 4
  %7633 = add i32 %7620, 1
  %7634 = select i1 %7619, i32 %7633, i32 %7620
  store i32 %7634, ptr %ready.count, align 4
  %7635 = load <8 x i1>, ptr %runnable.mask, align 1
  %7636 = or <8 x i1> %7635, %7610
  store <8 x i1> %7636, ptr %runnable.mask, align 1
  %7637 = load i8, ptr %frame.active, align 1
  %7638 = and i8 %7637, 2
  %7639 = icmp ne i8 %7638, 0
  %7640 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %7641 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %7642 = load <8 x i1>, ptr %7640, align 1
  %7643 = load <8 x i1>, ptr %7641, align 1
  %7644 = and <8 x i1> %7642, %7595
  %7645 = icmp eq <8 x i1> %7643, %7644
  %7646 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7645)
  %7647 = and i1 %7639, %7646
  %.splatinsert1303 = insertelement <8 x i1> poison, i1 %7647, i64 0
  %.splat1304 = shufflevector <8 x i1> %.splatinsert1303, <8 x i1> poison, <8 x i32> zeroinitializer
  %7648 = select <8 x i1> %.splat1304, <8 x i1> %7643, <8 x i1> zeroinitializer
  %7649 = select i1 %7647, <8 x i1> zeroinitializer, <8 x i1> %7644
  store <8 x i1> %7649, ptr %7640, align 1
  %7650 = select i1 %7647, <8 x i1> zeroinitializer, <8 x i1> %7643
  store <8 x i1> %7650, ptr %7641, align 1
  %7651 = and i8 %7637, -3
  %7652 = select i1 %7647, i8 %7651, i8 %7637
  store i8 %7652, ptr %frame.active, align 1
  %7653 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7654 = extractelement <8 x i32> %7653, i32 1
  %7655 = load <8 x i32>, ptr %frame.static.id, align 32
  %7656 = extractelement <8 x i32> %7655, i32 1
  %convergence.target.pointer1305 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7656
  %convergence.dynamic.target1306 = load i32, ptr %convergence.target.pointer1305, align 4
  %7657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7648)
  %7658 = load i32, ptr %ready.count, align 4
  %7659 = icmp uge i32 %7658, 8
  %7660 = and i1 %7657, %7659
  br i1 %7660, label %ready.overflow.trap1307, label %ready.overflow.resume1308

ready.overflow.trap1307:                          ; preds = %ready.overflow.resume1302
  call void @llvm.trap()
  unreachable

ready.overflow.resume1308:                        ; preds = %ready.overflow.resume1302
  %7661 = select i1 %7657, i32 %7658, i32 0
  %7662 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7661
  %7663 = load <8 x i1>, ptr %7662, align 1
  %7664 = select i1 %7657, <8 x i1> %7648, <8 x i1> %7663
  store <8 x i1> %7664, ptr %7662, align 1
  %7665 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7661
  %7666 = load i32, ptr %7665, align 4
  %7667 = select i1 %7657, i32 %convergence.dynamic.target1306, i32 %7666
  store i32 %7667, ptr %7665, align 4
  %7668 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7661
  %7669 = load i32, ptr %7668, align 4
  %7670 = select i1 %7657, i32 %7654, i32 %7669
  store i32 %7670, ptr %7668, align 4
  %7671 = add i32 %7658, 1
  %7672 = select i1 %7657, i32 %7671, i32 %7658
  store i32 %7672, ptr %ready.count, align 4
  %7673 = load <8 x i1>, ptr %runnable.mask, align 1
  %7674 = or <8 x i1> %7673, %7648
  store <8 x i1> %7674, ptr %runnable.mask, align 1
  %7675 = load i8, ptr %frame.active, align 1
  %7676 = and i8 %7675, 4
  %7677 = icmp ne i8 %7676, 0
  %7678 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %7679 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %7680 = load <8 x i1>, ptr %7678, align 1
  %7681 = load <8 x i1>, ptr %7679, align 1
  %7682 = and <8 x i1> %7680, %7595
  %7683 = icmp eq <8 x i1> %7681, %7682
  %7684 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7683)
  %7685 = and i1 %7677, %7684
  %.splatinsert1309 = insertelement <8 x i1> poison, i1 %7685, i64 0
  %.splat1310 = shufflevector <8 x i1> %.splatinsert1309, <8 x i1> poison, <8 x i32> zeroinitializer
  %7686 = select <8 x i1> %.splat1310, <8 x i1> %7681, <8 x i1> zeroinitializer
  %7687 = select i1 %7685, <8 x i1> zeroinitializer, <8 x i1> %7682
  store <8 x i1> %7687, ptr %7678, align 1
  %7688 = select i1 %7685, <8 x i1> zeroinitializer, <8 x i1> %7681
  store <8 x i1> %7688, ptr %7679, align 1
  %7689 = and i8 %7675, -5
  %7690 = select i1 %7685, i8 %7689, i8 %7675
  store i8 %7690, ptr %frame.active, align 1
  %7691 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7692 = extractelement <8 x i32> %7691, i32 2
  %7693 = load <8 x i32>, ptr %frame.static.id, align 32
  %7694 = extractelement <8 x i32> %7693, i32 2
  %convergence.target.pointer1311 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7694
  %convergence.dynamic.target1312 = load i32, ptr %convergence.target.pointer1311, align 4
  %7695 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7686)
  %7696 = load i32, ptr %ready.count, align 4
  %7697 = icmp uge i32 %7696, 8
  %7698 = and i1 %7695, %7697
  br i1 %7698, label %ready.overflow.trap1313, label %ready.overflow.resume1314

ready.overflow.trap1313:                          ; preds = %ready.overflow.resume1308
  call void @llvm.trap()
  unreachable

ready.overflow.resume1314:                        ; preds = %ready.overflow.resume1308
  %7699 = select i1 %7695, i32 %7696, i32 0
  %7700 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7699
  %7701 = load <8 x i1>, ptr %7700, align 1
  %7702 = select i1 %7695, <8 x i1> %7686, <8 x i1> %7701
  store <8 x i1> %7702, ptr %7700, align 1
  %7703 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7699
  %7704 = load i32, ptr %7703, align 4
  %7705 = select i1 %7695, i32 %convergence.dynamic.target1312, i32 %7704
  store i32 %7705, ptr %7703, align 4
  %7706 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7699
  %7707 = load i32, ptr %7706, align 4
  %7708 = select i1 %7695, i32 %7692, i32 %7707
  store i32 %7708, ptr %7706, align 4
  %7709 = add i32 %7696, 1
  %7710 = select i1 %7695, i32 %7709, i32 %7696
  store i32 %7710, ptr %ready.count, align 4
  %7711 = load <8 x i1>, ptr %runnable.mask, align 1
  %7712 = or <8 x i1> %7711, %7686
  store <8 x i1> %7712, ptr %runnable.mask, align 1
  %7713 = load i8, ptr %frame.active, align 1
  %7714 = and i8 %7713, 8
  %7715 = icmp ne i8 %7714, 0
  %7716 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %7717 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %7718 = load <8 x i1>, ptr %7716, align 1
  %7719 = load <8 x i1>, ptr %7717, align 1
  %7720 = and <8 x i1> %7718, %7595
  %7721 = icmp eq <8 x i1> %7719, %7720
  %7722 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7721)
  %7723 = and i1 %7715, %7722
  %.splatinsert1315 = insertelement <8 x i1> poison, i1 %7723, i64 0
  %.splat1316 = shufflevector <8 x i1> %.splatinsert1315, <8 x i1> poison, <8 x i32> zeroinitializer
  %7724 = select <8 x i1> %.splat1316, <8 x i1> %7719, <8 x i1> zeroinitializer
  %7725 = select i1 %7723, <8 x i1> zeroinitializer, <8 x i1> %7720
  store <8 x i1> %7725, ptr %7716, align 1
  %7726 = select i1 %7723, <8 x i1> zeroinitializer, <8 x i1> %7719
  store <8 x i1> %7726, ptr %7717, align 1
  %7727 = and i8 %7713, -9
  %7728 = select i1 %7723, i8 %7727, i8 %7713
  store i8 %7728, ptr %frame.active, align 1
  %7729 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7730 = extractelement <8 x i32> %7729, i32 3
  %7731 = load <8 x i32>, ptr %frame.static.id, align 32
  %7732 = extractelement <8 x i32> %7731, i32 3
  %convergence.target.pointer1317 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7732
  %convergence.dynamic.target1318 = load i32, ptr %convergence.target.pointer1317, align 4
  %7733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7724)
  %7734 = load i32, ptr %ready.count, align 4
  %7735 = icmp uge i32 %7734, 8
  %7736 = and i1 %7733, %7735
  br i1 %7736, label %ready.overflow.trap1319, label %ready.overflow.resume1320

ready.overflow.trap1319:                          ; preds = %ready.overflow.resume1314
  call void @llvm.trap()
  unreachable

ready.overflow.resume1320:                        ; preds = %ready.overflow.resume1314
  %7737 = select i1 %7733, i32 %7734, i32 0
  %7738 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7737
  %7739 = load <8 x i1>, ptr %7738, align 1
  %7740 = select i1 %7733, <8 x i1> %7724, <8 x i1> %7739
  store <8 x i1> %7740, ptr %7738, align 1
  %7741 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7737
  %7742 = load i32, ptr %7741, align 4
  %7743 = select i1 %7733, i32 %convergence.dynamic.target1318, i32 %7742
  store i32 %7743, ptr %7741, align 4
  %7744 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7737
  %7745 = load i32, ptr %7744, align 4
  %7746 = select i1 %7733, i32 %7730, i32 %7745
  store i32 %7746, ptr %7744, align 4
  %7747 = add i32 %7734, 1
  %7748 = select i1 %7733, i32 %7747, i32 %7734
  store i32 %7748, ptr %ready.count, align 4
  %7749 = load <8 x i1>, ptr %runnable.mask, align 1
  %7750 = or <8 x i1> %7749, %7724
  store <8 x i1> %7750, ptr %runnable.mask, align 1
  %7751 = load i8, ptr %frame.active, align 1
  %7752 = and i8 %7751, 16
  %7753 = icmp ne i8 %7752, 0
  %7754 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %7755 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %7756 = load <8 x i1>, ptr %7754, align 1
  %7757 = load <8 x i1>, ptr %7755, align 1
  %7758 = and <8 x i1> %7756, %7595
  %7759 = icmp eq <8 x i1> %7757, %7758
  %7760 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7759)
  %7761 = and i1 %7753, %7760
  %.splatinsert1321 = insertelement <8 x i1> poison, i1 %7761, i64 0
  %.splat1322 = shufflevector <8 x i1> %.splatinsert1321, <8 x i1> poison, <8 x i32> zeroinitializer
  %7762 = select <8 x i1> %.splat1322, <8 x i1> %7757, <8 x i1> zeroinitializer
  %7763 = select i1 %7761, <8 x i1> zeroinitializer, <8 x i1> %7758
  store <8 x i1> %7763, ptr %7754, align 1
  %7764 = select i1 %7761, <8 x i1> zeroinitializer, <8 x i1> %7757
  store <8 x i1> %7764, ptr %7755, align 1
  %7765 = and i8 %7751, -17
  %7766 = select i1 %7761, i8 %7765, i8 %7751
  store i8 %7766, ptr %frame.active, align 1
  %7767 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7768 = extractelement <8 x i32> %7767, i32 4
  %7769 = load <8 x i32>, ptr %frame.static.id, align 32
  %7770 = extractelement <8 x i32> %7769, i32 4
  %convergence.target.pointer1323 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7770
  %convergence.dynamic.target1324 = load i32, ptr %convergence.target.pointer1323, align 4
  %7771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7762)
  %7772 = load i32, ptr %ready.count, align 4
  %7773 = icmp uge i32 %7772, 8
  %7774 = and i1 %7771, %7773
  br i1 %7774, label %ready.overflow.trap1325, label %ready.overflow.resume1326

ready.overflow.trap1325:                          ; preds = %ready.overflow.resume1320
  call void @llvm.trap()
  unreachable

ready.overflow.resume1326:                        ; preds = %ready.overflow.resume1320
  %7775 = select i1 %7771, i32 %7772, i32 0
  %7776 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7775
  %7777 = load <8 x i1>, ptr %7776, align 1
  %7778 = select i1 %7771, <8 x i1> %7762, <8 x i1> %7777
  store <8 x i1> %7778, ptr %7776, align 1
  %7779 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7775
  %7780 = load i32, ptr %7779, align 4
  %7781 = select i1 %7771, i32 %convergence.dynamic.target1324, i32 %7780
  store i32 %7781, ptr %7779, align 4
  %7782 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7775
  %7783 = load i32, ptr %7782, align 4
  %7784 = select i1 %7771, i32 %7768, i32 %7783
  store i32 %7784, ptr %7782, align 4
  %7785 = add i32 %7772, 1
  %7786 = select i1 %7771, i32 %7785, i32 %7772
  store i32 %7786, ptr %ready.count, align 4
  %7787 = load <8 x i1>, ptr %runnable.mask, align 1
  %7788 = or <8 x i1> %7787, %7762
  store <8 x i1> %7788, ptr %runnable.mask, align 1
  %7789 = load i8, ptr %frame.active, align 1
  %7790 = and i8 %7789, 32
  %7791 = icmp ne i8 %7790, 0
  %7792 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %7793 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %7794 = load <8 x i1>, ptr %7792, align 1
  %7795 = load <8 x i1>, ptr %7793, align 1
  %7796 = and <8 x i1> %7794, %7595
  %7797 = icmp eq <8 x i1> %7795, %7796
  %7798 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7797)
  %7799 = and i1 %7791, %7798
  %.splatinsert1327 = insertelement <8 x i1> poison, i1 %7799, i64 0
  %.splat1328 = shufflevector <8 x i1> %.splatinsert1327, <8 x i1> poison, <8 x i32> zeroinitializer
  %7800 = select <8 x i1> %.splat1328, <8 x i1> %7795, <8 x i1> zeroinitializer
  %7801 = select i1 %7799, <8 x i1> zeroinitializer, <8 x i1> %7796
  store <8 x i1> %7801, ptr %7792, align 1
  %7802 = select i1 %7799, <8 x i1> zeroinitializer, <8 x i1> %7795
  store <8 x i1> %7802, ptr %7793, align 1
  %7803 = and i8 %7789, -33
  %7804 = select i1 %7799, i8 %7803, i8 %7789
  store i8 %7804, ptr %frame.active, align 1
  %7805 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7806 = extractelement <8 x i32> %7805, i32 5
  %7807 = load <8 x i32>, ptr %frame.static.id, align 32
  %7808 = extractelement <8 x i32> %7807, i32 5
  %convergence.target.pointer1329 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7808
  %convergence.dynamic.target1330 = load i32, ptr %convergence.target.pointer1329, align 4
  %7809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7800)
  %7810 = load i32, ptr %ready.count, align 4
  %7811 = icmp uge i32 %7810, 8
  %7812 = and i1 %7809, %7811
  br i1 %7812, label %ready.overflow.trap1331, label %ready.overflow.resume1332

ready.overflow.trap1331:                          ; preds = %ready.overflow.resume1326
  call void @llvm.trap()
  unreachable

ready.overflow.resume1332:                        ; preds = %ready.overflow.resume1326
  %7813 = select i1 %7809, i32 %7810, i32 0
  %7814 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7813
  %7815 = load <8 x i1>, ptr %7814, align 1
  %7816 = select i1 %7809, <8 x i1> %7800, <8 x i1> %7815
  store <8 x i1> %7816, ptr %7814, align 1
  %7817 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7813
  %7818 = load i32, ptr %7817, align 4
  %7819 = select i1 %7809, i32 %convergence.dynamic.target1330, i32 %7818
  store i32 %7819, ptr %7817, align 4
  %7820 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7813
  %7821 = load i32, ptr %7820, align 4
  %7822 = select i1 %7809, i32 %7806, i32 %7821
  store i32 %7822, ptr %7820, align 4
  %7823 = add i32 %7810, 1
  %7824 = select i1 %7809, i32 %7823, i32 %7810
  store i32 %7824, ptr %ready.count, align 4
  %7825 = load <8 x i1>, ptr %runnable.mask, align 1
  %7826 = or <8 x i1> %7825, %7800
  store <8 x i1> %7826, ptr %runnable.mask, align 1
  %7827 = load i8, ptr %frame.active, align 1
  %7828 = and i8 %7827, 64
  %7829 = icmp ne i8 %7828, 0
  %7830 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %7831 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %7832 = load <8 x i1>, ptr %7830, align 1
  %7833 = load <8 x i1>, ptr %7831, align 1
  %7834 = and <8 x i1> %7832, %7595
  %7835 = icmp eq <8 x i1> %7833, %7834
  %7836 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7835)
  %7837 = and i1 %7829, %7836
  %.splatinsert1333 = insertelement <8 x i1> poison, i1 %7837, i64 0
  %.splat1334 = shufflevector <8 x i1> %.splatinsert1333, <8 x i1> poison, <8 x i32> zeroinitializer
  %7838 = select <8 x i1> %.splat1334, <8 x i1> %7833, <8 x i1> zeroinitializer
  %7839 = select i1 %7837, <8 x i1> zeroinitializer, <8 x i1> %7834
  store <8 x i1> %7839, ptr %7830, align 1
  %7840 = select i1 %7837, <8 x i1> zeroinitializer, <8 x i1> %7833
  store <8 x i1> %7840, ptr %7831, align 1
  %7841 = and i8 %7827, -65
  %7842 = select i1 %7837, i8 %7841, i8 %7827
  store i8 %7842, ptr %frame.active, align 1
  %7843 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7844 = extractelement <8 x i32> %7843, i32 6
  %7845 = load <8 x i32>, ptr %frame.static.id, align 32
  %7846 = extractelement <8 x i32> %7845, i32 6
  %convergence.target.pointer1335 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7846
  %convergence.dynamic.target1336 = load i32, ptr %convergence.target.pointer1335, align 4
  %7847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7838)
  %7848 = load i32, ptr %ready.count, align 4
  %7849 = icmp uge i32 %7848, 8
  %7850 = and i1 %7847, %7849
  br i1 %7850, label %ready.overflow.trap1337, label %ready.overflow.resume1338

ready.overflow.trap1337:                          ; preds = %ready.overflow.resume1332
  call void @llvm.trap()
  unreachable

ready.overflow.resume1338:                        ; preds = %ready.overflow.resume1332
  %7851 = select i1 %7847, i32 %7848, i32 0
  %7852 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7851
  %7853 = load <8 x i1>, ptr %7852, align 1
  %7854 = select i1 %7847, <8 x i1> %7838, <8 x i1> %7853
  store <8 x i1> %7854, ptr %7852, align 1
  %7855 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7851
  %7856 = load i32, ptr %7855, align 4
  %7857 = select i1 %7847, i32 %convergence.dynamic.target1336, i32 %7856
  store i32 %7857, ptr %7855, align 4
  %7858 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7851
  %7859 = load i32, ptr %7858, align 4
  %7860 = select i1 %7847, i32 %7844, i32 %7859
  store i32 %7860, ptr %7858, align 4
  %7861 = add i32 %7848, 1
  %7862 = select i1 %7847, i32 %7861, i32 %7848
  store i32 %7862, ptr %ready.count, align 4
  %7863 = load <8 x i1>, ptr %runnable.mask, align 1
  %7864 = or <8 x i1> %7863, %7838
  store <8 x i1> %7864, ptr %runnable.mask, align 1
  %7865 = load i8, ptr %frame.active, align 1
  %7866 = and i8 %7865, -128
  %7867 = icmp ne i8 %7866, 0
  %7868 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %7869 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %7870 = load <8 x i1>, ptr %7868, align 1
  %7871 = load <8 x i1>, ptr %7869, align 1
  %7872 = and <8 x i1> %7870, %7595
  %7873 = icmp eq <8 x i1> %7871, %7872
  %7874 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7873)
  %7875 = and i1 %7867, %7874
  %.splatinsert1339 = insertelement <8 x i1> poison, i1 %7875, i64 0
  %.splat1340 = shufflevector <8 x i1> %.splatinsert1339, <8 x i1> poison, <8 x i32> zeroinitializer
  %7876 = select <8 x i1> %.splat1340, <8 x i1> %7871, <8 x i1> zeroinitializer
  %7877 = select i1 %7875, <8 x i1> zeroinitializer, <8 x i1> %7872
  store <8 x i1> %7877, ptr %7868, align 1
  %7878 = select i1 %7875, <8 x i1> zeroinitializer, <8 x i1> %7871
  store <8 x i1> %7878, ptr %7869, align 1
  %7879 = and i8 %7865, 127
  %7880 = select i1 %7875, i8 %7879, i8 %7865
  store i8 %7880, ptr %frame.active, align 1
  %7881 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7882 = extractelement <8 x i32> %7881, i32 7
  %7883 = load <8 x i32>, ptr %frame.static.id, align 32
  %7884 = extractelement <8 x i32> %7883, i32 7
  %convergence.target.pointer1341 = getelementptr inbounds [21 x i32], ptr @convergence.targets, i32 0, i32 %7884
  %convergence.dynamic.target1342 = load i32, ptr %convergence.target.pointer1341, align 4
  %7885 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7876)
  %7886 = load i32, ptr %ready.count, align 4
  %7887 = icmp uge i32 %7886, 8
  %7888 = and i1 %7885, %7887
  br i1 %7888, label %ready.overflow.trap1343, label %ready.overflow.resume1344

ready.overflow.trap1343:                          ; preds = %ready.overflow.resume1338
  call void @llvm.trap()
  unreachable

ready.overflow.resume1344:                        ; preds = %ready.overflow.resume1338
  %7889 = select i1 %7885, i32 %7886, i32 0
  %7890 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7889
  %7891 = load <8 x i1>, ptr %7890, align 1
  %7892 = select i1 %7885, <8 x i1> %7876, <8 x i1> %7891
  store <8 x i1> %7892, ptr %7890, align 1
  %7893 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7889
  %7894 = load i32, ptr %7893, align 4
  %7895 = select i1 %7885, i32 %convergence.dynamic.target1342, i32 %7894
  store i32 %7895, ptr %7893, align 4
  %7896 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7889
  %7897 = load i32, ptr %7896, align 4
  %7898 = select i1 %7885, i32 %7882, i32 %7897
  store i32 %7898, ptr %7896, align 4
  %7899 = add i32 %7886, 1
  %7900 = select i1 %7885, i32 %7899, i32 %7886
  store i32 %7900, ptr %ready.count, align 4
  %7901 = load <8 x i1>, ptr %runnable.mask, align 1
  %7902 = or <8 x i1> %7901, %7876
  store <8 x i1> %7902, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #3

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma(ptr %0, ptr %1, ptr %2, ptr %3) #4 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %45, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 64
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = urem i64 %mma.k, 16
  %6 = udiv i64 %mma.k, 16
  %7 = urem i64 %6, 4
  %8 = mul i64 %7, 40
  %9 = add i64 0, %8
  %10 = udiv i64 %6, 4
  %11 = urem i64 %mma.k, 16
  %12 = mul i64 %11, 40
  %13 = add i64 0, %12
  %14 = udiv i64 %mma.k, 16
  %15 = urem i64 %14, 4
  %16 = udiv i64 %14, 4
  %17 = getelementptr float, ptr %2, i64 %mma.k
  %18 = load float, ptr %17, align 4
  %19 = getelementptr float, ptr %0, i64 %9
  %20 = load <4 x float>, ptr %19, align 4
  %21 = getelementptr float, ptr %1, i64 %13
  %22 = load <4 x float>, ptr %21, align 4
  %23 = fmul <4 x float> %20, %22
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.update2, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %35, %mma.update2 ]
  %mma.acc5 = phi <4 x float> [ %23, %mma.update ], [ %34, %mma.update2 ]
  %24 = icmp ult i64 %mma.k4, 9
  br i1 %24, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %25 = add i64 %mma.k4, 1
  %26 = mul i64 %25, 4
  %27 = add i64 %9, %26
  %28 = getelementptr float, ptr %0, i64 %27
  %29 = load <4 x float>, ptr %28, align 4
  %30 = add i64 %13, %26
  %31 = getelementptr float, ptr %1, i64 %30
  %32 = load <4 x float>, ptr %31, align 4
  %33 = fmul <4 x float> %29, %32
  %34 = fadd <4 x float> %mma.acc5, %33
  %35 = add i64 %mma.k4, 1
  br label %mma.fold1

mma.fold.done3:                                   ; preds = %mma.fold1
  %36 = extractelement <4 x float> %mma.acc5, i64 0
  %37 = extractelement <4 x float> %mma.acc5, i64 1
  %38 = extractelement <4 x float> %mma.acc5, i64 2
  %39 = extractelement <4 x float> %mma.acc5, i64 3
  %40 = fadd float %36, %37
  %41 = fadd float %38, %39
  %42 = fadd float %40, %41
  %43 = fadd float %18, %42
  %44 = getelementptr float, ptr %3, i64 %mma.k
  store float %43, ptr %44, align 4
  %45 = add i64 %mma.k, 1
  br label %mma.fold
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #5

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #6 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma.1(ptr %0, ptr %1, ptr %2, ptr %3) #4 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %23, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 4
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = mul i64 %mma.k, 48
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.fold.done8, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %37, %mma.fold.done8 ]
  %mma.acc5 = phi i64 [ 0, %mma.update ], [ %mma.acc5, %mma.fold.done8 ]
  %6 = icmp ult i64 %mma.k4, 12
  br i1 %6, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %7 = mul i64 %mma.k4, 4
  %8 = add i64 %5, %7
  %9 = urem i64 %8, 48
  %10 = udiv i64 %8, 48
  %11 = urem i64 %10, 4
  %12 = mul i64 %11, 16
  %13 = add i64 0, %12
  %14 = udiv i64 %10, 4
  %15 = urem i64 %8, 48
  %16 = mul i64 %15, 1
  %17 = add i64 0, %16
  %18 = udiv i64 %8, 48
  %19 = urem i64 %18, 4
  %20 = udiv i64 %18, 4
  %21 = getelementptr float, ptr %2, i64 %8
  %22 = load <4 x float>, ptr %21, align 4
  br label %mma.fold6

mma.fold.done3:                                   ; preds = %mma.fold1
  %23 = add i64 %mma.k, 1
  br label %mma.fold

mma.fold6:                                        ; preds = %mma.update7, %mma.update2
  %mma.k9 = phi i64 [ 0, %mma.update2 ], [ %35, %mma.update7 ]
  %mma.acc10 = phi <4 x float> [ %22, %mma.update2 ], [ %34, %mma.update7 ]
  %24 = icmp ult i64 %mma.k9, 16
  br i1 %24, label %mma.update7, label %mma.fold.done8

mma.update7:                                      ; preds = %mma.fold6
  %25 = mul i64 %mma.k9, 1
  %26 = add i64 %13, %25
  %27 = getelementptr float, ptr %0, i64 %26
  %28 = load float, ptr %27, align 4
  %.splatinsert = insertelement <4 x float> poison, float %28, i64 0
  %.splat = shufflevector <4 x float> %.splatinsert, <4 x float> poison, <4 x i32> zeroinitializer
  %29 = mul i64 %mma.k9, 48
  %30 = add i64 %17, %29
  %31 = getelementptr float, ptr %1, i64 %30
  %32 = load <4 x float>, ptr %31, align 4
  %33 = fmul <4 x float> %.splat, %32
  %34 = fadd <4 x float> %mma.acc10, %33
  %35 = add i64 %mma.k9, 1
  br label %mma.fold6

mma.fold.done8:                                   ; preds = %mma.fold6
  %36 = getelementptr float, ptr %3, i64 %8
  store <4 x float> %mma.acc10, ptr %36, align 4
  %37 = add i64 %mma.k4, 1
  br label %mma.fold1
}

define dso_local void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nounwind willreturn "fp-contract"="off" }
attributes #5 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [3104 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3104 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [3104 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [3104 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill11 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill11, align 1
  %tile_snapshot.spill12 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill12, align 64
  %.slot13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot13, align 64
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot15, align 64
  %tile_snapshot.spill16 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill16, align 64
  %.slot17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot17, align 64
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %.slot19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot19, align 64
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat21, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat23, %45
  %48 = mul i32 %36, 1
  %.splatinsert24 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat25 = shufflevector <8 x i32> %.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat25, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert26 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat27 = shufflevector <8 x i32> %.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat27, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert28 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat29 = shufflevector <8 x i32> %.splatinsert28, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat29
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %70, 0
  %73 = select <8 x i1> %55, <8 x ptr> %71, <8 x ptr> %72
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %70, 1
  %76 = select <8 x i1> %55, <8 x i64> %74, <8 x i64> %75
  %77 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %73, 0
  %78 = insertvalue { <8 x ptr>, <8 x i64> } %77, <8 x i64> %76, 1
  store { <8 x ptr>, <8 x i64> } %78, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %79 = icmp slt i64 %.state, 96
  br i1 %79, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state30 = load i64, ptr %.slot, align 4
  %80 = mul i64 %.state30, 8
  %.splatinsert31 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat32 = shufflevector <8 x i64> %.splatinsert31, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.splat32, %.spill.load
  %.spill.load33 = load <8 x i64>, ptr %.spill10, align 64
  %82 = add <8 x i64> %.spill.load33, zeroinitializer
  %83 = add <8 x i64> zeroinitializer, %82
  %84 = add <8 x i64> zeroinitializer, %81
  %85 = mul <8 x i64> %83, splat (i64 1538)
  %86 = add <8 x i64> %85, %84
  %87 = extractvalue { ptr, i64 } %13, 0
  %88 = extractelement <8 x i64> %86, i32 0
  %89 = sub i64 %88, 0
  %90 = mul i64 %89, 4
  %buffer.contiguous.address = getelementptr i8, ptr %87, i64 %90
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %92 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state34 = load i64, ptr %.slot, align 4
  %.splatinsert35 = insertelement <8 x i64> poison, i64 %.state34, i64 0
  %.splat36 = shufflevector <8 x i64> %.splatinsert35, <8 x i64> poison, <8 x i32> zeroinitializer
  %93 = mul <8 x i64> %.splat36, splat (i64 32)
  %94 = add <8 x i64> %92, %93
  %95 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %91, 0
  %96 = insertvalue { <8 x ptr>, <8 x i64> } %95, <8 x i64> %94, 1
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %99 = extractelement <8 x ptr> %97, i32 0
  %100 = extractelement <8 x i64> %98, i32 0
  %101 = sub i64 %100, 0
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %103 = select i1 %102, i64 %101, i64 0
  %private.contiguous.address = getelementptr i8, ptr %99, i64 %103
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %104 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %104, ptr %private.contiguous.address, align 4
  %.state37 = load i64, ptr %.slot, align 4
  %105 = add i64 %.state37, 1
  store i64 %105, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load38 = load <8 x i64>, ptr %.spill, align 64
  %106 = icmp slt <8 x i64> %.spill.load38, splat (i64 1)
  %107 = load <8 x i1>, ptr %.spill11, align 1
  %108 = select <8 x i1> %55, <8 x i1> %106, <8 x i1> %107
  store <8 x i1> %108, ptr %.spill11, align 1
  %109 = and <8 x i1> %55, %106
  %110 = xor <8 x i1> %106, splat (i1 true)
  %111 = and <8 x i1> %55, %110
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %109)
  %113 = bitcast <8 x i1> %109 to i8
  %114 = call i8 @llvm.cttz.i8(i8 %113, i1 false)
  %115 = zext i8 %114 to i32
  %116 = select i1 %112, i32 %115, i32 0
  %.spill.load39 = load <8 x i64>, ptr %.spill, align 64
  %117 = add <8 x i64> splat (i64 768), %.spill.load39
  %.spill.load40 = load <8 x i64>, ptr %.spill10, align 64
  %118 = add <8 x i64> %.spill.load40, zeroinitializer
  %119 = add <8 x i64> zeroinitializer, %118
  %120 = add <8 x i64> zeroinitializer, %117
  %121 = mul <8 x i64> %119, splat (i64 1538)
  %122 = add <8 x i64> %121, %120
  %123 = extractvalue { ptr, i64 } %13, 0
  %124 = select <8 x i1> %109, <8 x i64> %122, <8 x i64> zeroinitializer
  %125 = extractelement <8 x i64> %124, i32 %116
  %126 = zext i32 %116 to i64
  %127 = sub i64 %125, %126
  %128 = mul i64 %127, 4
  %buffer.contiguous.address41 = getelementptr i8, ptr %123, i64 %128
  %buffer.contiguous.load42 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address41, <8 x i1> %109, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load43 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 1
  %131 = add <8 x i64> %130, splat (i64 3072)
  %132 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %129, 0
  %133 = insertvalue { <8 x ptr>, <8 x i64> } %132, <8 x i64> %131, 1
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %136 = extractelement <8 x ptr> %134, i32 0
  %137 = extractelement <8 x i64> %135, i32 %116
  %138 = zext i32 %116 to i64
  %139 = mul i64 %138, 4
  %140 = sub i64 %137, %139
  %141 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %109)
  %142 = select i1 %141, i64 %140, i64 0
  %private.contiguous.address44 = getelementptr i8, ptr %136, i64 %142
  %private.contiguous.preserve45 = load <8 x float>, ptr %private.contiguous.address44, align 4
  %143 = select <8 x i1> %109, <8 x float> %buffer.contiguous.load42, <8 x float> %private.contiguous.preserve45
  store <8 x float> %143, ptr %private.contiguous.address44, align 4
  %144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %145 = bitcast <8 x i1> %111 to i8
  %146 = call i8 @llvm.cttz.i8(i8 %145, i1 false)
  %147 = zext i8 %146 to i32
  %148 = select i1 %144, i32 %147, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  %149 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 0
  %152 = select <8 x i1> %55, <8 x ptr> %150, <8 x ptr> %151
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %155 = select <8 x i1> %55, <8 x i64> %153, <8 x i64> %154
  %156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %152, 0
  %157 = insertvalue { <8 x ptr>, <8 x i64> } %156, <8 x i64> %155, 1
  store { <8 x ptr>, <8 x i64> } %157, ptr %tile_snapshot.spill12, align 64
  %158 = load <8 x i64>, ptr %.slot13, align 64
  %159 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %158
  store <8 x i64> %159, ptr %.slot13, align 64
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state46 = load <8 x i64>, ptr %.slot13, align 64
  %160 = icmp slt <8 x i64> %.state46, splat (i64 96)
  %161 = extractelement <8 x i1> %160, i32 0
  br i1 %161, label %direct.true47, label %direct.false48

direct.schedule.7:                                ; preds = %direct.true47
  %.state49 = load <8 x i64>, ptr %.slot13, align 64
  %162 = mul <8 x i64> %.state49, splat (i64 8)
  %.spill.load50 = load <8 x i64>, ptr %.spill, align 64
  %163 = add <8 x i64> %162, %.spill.load50
  %.spill.load51 = load <8 x i64>, ptr %.spill10, align 64
  %164 = add <8 x i64> %.spill.load51, zeroinitializer
  %165 = add <8 x i64> zeroinitializer, %164
  %166 = add <8 x i64> splat (i64 769), %163
  %167 = mul <8 x i64> %165, splat (i64 1538)
  %168 = add <8 x i64> %167, %166
  %169 = extractvalue { ptr, i64 } %13, 0
  %170 = extractelement <8 x i64> %168, i32 0
  %171 = sub i64 %170, 0
  %172 = mul i64 %171, 4
  %buffer.contiguous.address52 = getelementptr i8, ptr %169, i64 %172
  %buffer.contiguous.load53 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address52, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load54 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load54, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load54, 1
  %.state55 = load <8 x i64>, ptr %.slot13, align 64
  %175 = mul <8 x i64> %.state55, splat (i64 32)
  %176 = add <8 x i64> %174, %175
  %177 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %178 = insertvalue { <8 x ptr>, <8 x i64> } %177, <8 x i64> %176, 1
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %178, 1
  %181 = extractelement <8 x ptr> %179, i32 0
  %182 = extractelement <8 x i64> %180, i32 0
  %183 = sub i64 %182, 0
  %184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %185 = select i1 %184, i64 %183, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %181, i64 %185
  %private.contiguous.preserve57 = load <8 x float>, ptr %private.contiguous.address56, align 4
  %186 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load53, <8 x float> %private.contiguous.preserve57
  store <8 x float> %186, ptr %private.contiguous.address56, align 4
  %.state58 = load <8 x i64>, ptr %.slot13, align 64
  %187 = add <8 x i64> %.state58, splat (i64 1)
  %188 = load <8 x i64>, ptr %.slot13, align 64
  %189 = select <8 x i1> %55, <8 x i64> %187, <8 x i64> %188
  store <8 x i64> %189, ptr %.slot13, align 64
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false48
  %.spill.load59 = load <8 x i1>, ptr %.spill11, align 1
  %190 = and <8 x i1> %55, %.spill.load59
  %191 = xor <8 x i1> %.spill.load59, splat (i1 true)
  %192 = and <8 x i1> %55, %191
  %193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %190)
  %194 = bitcast <8 x i1> %190 to i8
  %195 = call i8 @llvm.cttz.i8(i8 %194, i1 false)
  %196 = zext i8 %195 to i32
  %197 = select i1 %193, i32 %196, i32 0
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %198 = add <8 x i64> splat (i64 768), %.spill.load60
  %.spill.load61 = load <8 x i64>, ptr %.spill10, align 64
  %199 = add <8 x i64> %.spill.load61, zeroinitializer
  %200 = add <8 x i64> zeroinitializer, %199
  %201 = add <8 x i64> splat (i64 769), %198
  %202 = mul <8 x i64> %200, splat (i64 1538)
  %203 = add <8 x i64> %202, %201
  %204 = extractvalue { ptr, i64 } %13, 0
  %205 = select <8 x i1> %190, <8 x i64> %203, <8 x i64> zeroinitializer
  %206 = extractelement <8 x i64> %205, i32 %197
  %207 = zext i32 %197 to i64
  %208 = sub i64 %206, %207
  %209 = mul i64 %208, 4
  %buffer.contiguous.address62 = getelementptr i8, ptr %204, i64 %209
  %buffer.contiguous.load63 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address62, <8 x i1> %190, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %212 = add <8 x i64> %211, splat (i64 3072)
  %213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %210, 0
  %214 = insertvalue { <8 x ptr>, <8 x i64> } %213, <8 x i64> %212, 1
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %217 = extractelement <8 x ptr> %215, i32 0
  %218 = extractelement <8 x i64> %216, i32 %197
  %219 = zext i32 %197 to i64
  %220 = mul i64 %219, 4
  %221 = sub i64 %218, %220
  %222 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %190)
  %223 = select i1 %222, i64 %221, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %217, i64 %223
  %private.contiguous.preserve66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %224 = select <8 x i1> %190, <8 x float> %buffer.contiguous.load63, <8 x float> %private.contiguous.preserve66
  store <8 x float> %224, ptr %private.contiguous.address65, align 4
  %225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %192)
  %226 = bitcast <8 x i1> %192 to i8
  %227 = call i8 @llvm.cttz.i8(i8 %226, i1 false)
  %228 = zext i8 %227 to i32
  %229 = select i1 %225, i32 %228, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %230 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %230, 0
  %233 = select <8 x i1> %55, <8 x ptr> %231, <8 x ptr> %232
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %230, 1
  %236 = select <8 x i1> %55, <8 x i64> %234, <8 x i64> %235
  %237 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %233, 0
  %238 = insertvalue { <8 x ptr>, <8 x i64> } %237, <8 x i64> %236, 1
  store { <8 x ptr>, <8 x i64> } %238, ptr %tile_snapshot.spill14, align 64
  %239 = load <8 x i64>, ptr %.slot15, align 64
  %240 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %239
  store <8 x i64> %240, ptr %.slot15, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state67 = load <8 x i64>, ptr %.slot15, align 64
  %241 = icmp slt <8 x i64> %.state67, splat (i64 96)
  %242 = extractelement <8 x i1> %241, i32 0
  br i1 %242, label %direct.true68, label %direct.false69

direct.schedule.12:                               ; preds = %direct.true68
  %.state70 = load <8 x i64>, ptr %.slot15, align 64
  %243 = mul <8 x i64> %.state70, splat (i64 8)
  %.spill.load71 = load <8 x i64>, ptr %.spill, align 64
  %244 = add <8 x i64> %243, %.spill.load71
  %.spill.load72 = load <8 x i64>, ptr %.spill10, align 64
  %245 = add <8 x i64> %.spill.load72, zeroinitializer
  %246 = add <8 x i64> zeroinitializer, %245
  %247 = add <8 x i64> zeroinitializer, %244
  %248 = mul <8 x i64> %246, splat (i64 769)
  %249 = add <8 x i64> %248, %247
  %250 = extractvalue { ptr, i64 } %19, 0
  %251 = extractelement <8 x i64> %249, i32 0
  %252 = sub i64 %251, 0
  %253 = mul i64 %252, 4
  %buffer.contiguous.address73 = getelementptr i8, ptr %250, i64 %253
  %buffer.contiguous.load74 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address73, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load75 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 1
  %.state76 = load <8 x i64>, ptr %.slot15, align 64
  %256 = mul <8 x i64> %.state76, splat (i64 32)
  %257 = add <8 x i64> %255, %256
  %258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %254, 0
  %259 = insertvalue { <8 x ptr>, <8 x i64> } %258, <8 x i64> %257, 1
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %259, 1
  %262 = extractelement <8 x ptr> %260, i32 0
  %263 = extractelement <8 x i64> %261, i32 0
  %264 = sub i64 %263, 0
  %265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %266 = select i1 %265, i64 %264, i64 0
  %private.contiguous.address77 = getelementptr i8, ptr %262, i64 %266
  %private.contiguous.preserve78 = load <8 x float>, ptr %private.contiguous.address77, align 4
  %267 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load74, <8 x float> %private.contiguous.preserve78
  store <8 x float> %267, ptr %private.contiguous.address77, align 4
  %.state79 = load <8 x i64>, ptr %.slot15, align 64
  %268 = add <8 x i64> %.state79, splat (i64 1)
  %269 = load <8 x i64>, ptr %.slot15, align 64
  %270 = select <8 x i1> %55, <8 x i64> %268, <8 x i64> %269
  store <8 x i64> %270, ptr %.slot15, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false69
  %.spill.load80 = load <8 x i1>, ptr %.spill11, align 1
  %271 = and <8 x i1> %55, %.spill.load80
  %272 = xor <8 x i1> %.spill.load80, splat (i1 true)
  %273 = and <8 x i1> %55, %272
  %274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %271)
  %275 = bitcast <8 x i1> %271 to i8
  %276 = call i8 @llvm.cttz.i8(i8 %275, i1 false)
  %277 = zext i8 %276 to i32
  %278 = select i1 %274, i32 %277, i32 0
  %.spill.load81 = load <8 x i64>, ptr %.spill, align 64
  %279 = add <8 x i64> splat (i64 768), %.spill.load81
  %.spill.load82 = load <8 x i64>, ptr %.spill10, align 64
  %280 = add <8 x i64> %.spill.load82, zeroinitializer
  %281 = add <8 x i64> zeroinitializer, %280
  %282 = add <8 x i64> zeroinitializer, %279
  %283 = mul <8 x i64> %281, splat (i64 769)
  %284 = add <8 x i64> %283, %282
  %285 = extractvalue { ptr, i64 } %19, 0
  %286 = select <8 x i1> %271, <8 x i64> %284, <8 x i64> zeroinitializer
  %287 = extractelement <8 x i64> %286, i32 %278
  %288 = zext i32 %278 to i64
  %289 = sub i64 %287, %288
  %290 = mul i64 %289, 4
  %buffer.contiguous.address83 = getelementptr i8, ptr %285, i64 %290
  %buffer.contiguous.load84 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address83, <8 x i1> %271, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 0
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 1
  %293 = add <8 x i64> %292, splat (i64 3072)
  %294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %291, 0
  %295 = insertvalue { <8 x ptr>, <8 x i64> } %294, <8 x i64> %293, 1
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %295, 1
  %298 = extractelement <8 x ptr> %296, i32 0
  %299 = extractelement <8 x i64> %297, i32 %278
  %300 = zext i32 %278 to i64
  %301 = mul i64 %300, 4
  %302 = sub i64 %299, %301
  %303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %271)
  %304 = select i1 %303, i64 %302, i64 0
  %private.contiguous.address86 = getelementptr i8, ptr %298, i64 %304
  %private.contiguous.preserve87 = load <8 x float>, ptr %private.contiguous.address86, align 4
  %305 = select <8 x i1> %271, <8 x float> %buffer.contiguous.load84, <8 x float> %private.contiguous.preserve87
  store <8 x float> %305, ptr %private.contiguous.address86, align 4
  %306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %273)
  %307 = bitcast <8 x i1> %273 to i8
  %308 = call i8 @llvm.cttz.i8(i8 %307, i1 false)
  %309 = zext i8 %308 to i32
  %310 = select i1 %306, i32 %309, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %311 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %311, 0
  %314 = select <8 x i1> %55, <8 x ptr> %312, <8 x ptr> %313
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %311, 1
  %317 = select <8 x i1> %55, <8 x i64> %315, <8 x i64> %316
  %318 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %314, 0
  %319 = insertvalue { <8 x ptr>, <8 x i64> } %318, <8 x i64> %317, 1
  store { <8 x ptr>, <8 x i64> } %319, ptr %tile_snapshot.spill16, align 64
  %320 = load <8 x i64>, ptr %.slot17, align 64
  %321 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %320
  store <8 x i64> %321, ptr %.slot17, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state88 = load <8 x i64>, ptr %.slot17, align 64
  %322 = icmp slt <8 x i64> %.state88, splat (i64 96)
  %323 = extractelement <8 x i1> %322, i32 0
  br i1 %323, label %direct.true89, label %direct.false90

direct.schedule.17:                               ; preds = %direct.true89
  %.state91 = load <8 x i64>, ptr %.slot17, align 64
  %324 = mul <8 x i64> %.state91, splat (i64 8)
  %.spill.load92 = load <8 x i64>, ptr %.spill, align 64
  %325 = add <8 x i64> %324, %.spill.load92
  %.spill.load93 = load <8 x i64>, ptr %.spill10, align 64
  %326 = add <8 x i64> %.spill.load93, zeroinitializer
  %327 = add <8 x i64> zeroinitializer, %326
  %328 = add <8 x i64> zeroinitializer, %325
  %329 = mul <8 x i64> %327, splat (i64 769)
  %330 = add <8 x i64> %329, %328
  %331 = extractvalue { ptr, i64 } %25, 0
  %332 = extractelement <8 x i64> %330, i32 0
  %333 = sub i64 %332, 0
  %334 = mul i64 %333, 4
  %buffer.contiguous.address94 = getelementptr i8, ptr %331, i64 %334
  %buffer.contiguous.load95 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address94, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.state97 = load <8 x i64>, ptr %.slot17, align 64
  %337 = mul <8 x i64> %.state97, splat (i64 32)
  %338 = add <8 x i64> %336, %337
  %339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %335, 0
  %340 = insertvalue { <8 x ptr>, <8 x i64> } %339, <8 x i64> %338, 1
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %340, 1
  %343 = extractelement <8 x ptr> %341, i32 0
  %344 = extractelement <8 x i64> %342, i32 0
  %345 = sub i64 %344, 0
  %346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %347 = select i1 %346, i64 %345, i64 0
  %private.contiguous.address98 = getelementptr i8, ptr %343, i64 %347
  %private.contiguous.preserve99 = load <8 x float>, ptr %private.contiguous.address98, align 4
  %348 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load95, <8 x float> %private.contiguous.preserve99
  store <8 x float> %348, ptr %private.contiguous.address98, align 4
  %.state100 = load <8 x i64>, ptr %.slot17, align 64
  %349 = add <8 x i64> %.state100, splat (i64 1)
  %350 = load <8 x i64>, ptr %.slot17, align 64
  %351 = select <8 x i1> %55, <8 x i64> %349, <8 x i64> %350
  store <8 x i64> %351, ptr %.slot17, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false90
  %.spill.load101 = load <8 x i1>, ptr %.spill11, align 1
  %352 = and <8 x i1> %55, %.spill.load101
  %353 = xor <8 x i1> %.spill.load101, splat (i1 true)
  %354 = and <8 x i1> %55, %353
  %355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %352)
  %356 = bitcast <8 x i1> %352 to i8
  %357 = call i8 @llvm.cttz.i8(i8 %356, i1 false)
  %358 = zext i8 %357 to i32
  %359 = select i1 %355, i32 %358, i32 0
  %.spill.load102 = load <8 x i64>, ptr %.spill, align 64
  %360 = add <8 x i64> splat (i64 768), %.spill.load102
  %.spill.load103 = load <8 x i64>, ptr %.spill10, align 64
  %361 = add <8 x i64> %.spill.load103, zeroinitializer
  %362 = add <8 x i64> zeroinitializer, %361
  %363 = add <8 x i64> zeroinitializer, %360
  %364 = mul <8 x i64> %362, splat (i64 769)
  %365 = add <8 x i64> %364, %363
  %366 = extractvalue { ptr, i64 } %25, 0
  %367 = select <8 x i1> %352, <8 x i64> %365, <8 x i64> zeroinitializer
  %368 = extractelement <8 x i64> %367, i32 %359
  %369 = zext i32 %359 to i64
  %370 = sub i64 %368, %369
  %371 = mul i64 %370, 4
  %buffer.contiguous.address104 = getelementptr i8, ptr %366, i64 %371
  %buffer.contiguous.load105 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address104, <8 x i1> %352, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %374 = add <8 x i64> %373, splat (i64 3072)
  %375 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %372, 0
  %376 = insertvalue { <8 x ptr>, <8 x i64> } %375, <8 x i64> %374, 1
  %377 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %378 = extractvalue { <8 x ptr>, <8 x i64> } %376, 1
  %379 = extractelement <8 x ptr> %377, i32 0
  %380 = extractelement <8 x i64> %378, i32 %359
  %381 = zext i32 %359 to i64
  %382 = mul i64 %381, 4
  %383 = sub i64 %380, %382
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %352)
  %385 = select i1 %384, i64 %383, i64 0
  %private.contiguous.address107 = getelementptr i8, ptr %379, i64 %385
  %private.contiguous.preserve108 = load <8 x float>, ptr %private.contiguous.address107, align 4
  %386 = select <8 x i1> %352, <8 x float> %buffer.contiguous.load105, <8 x float> %private.contiguous.preserve108
  store <8 x float> %386, ptr %private.contiguous.address107, align 4
  %387 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %354)
  %388 = bitcast <8 x i1> %354 to i8
  %389 = call i8 @llvm.cttz.i8(i8 %388, i1 false)
  %390 = zext i8 %389 to i32
  %391 = select i1 %387, i32 %390, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  %392 = load <8 x i64>, ptr %.slot18, align 64
  %393 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %392
  store <8 x i64> %393, ptr %.slot18, align 64
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state109 = load <8 x i64>, ptr %.slot18, align 64
  %394 = icmp slt <8 x i64> %.state109, splat (i64 96)
  %395 = extractelement <8 x i1> %394, i32 0
  br i1 %395, label %direct.true110, label %direct.false111

direct.schedule.22:                               ; preds = %direct.true110
  %.state112 = load <8 x i64>, ptr %.slot18, align 64
  %396 = mul <8 x i64> %.state112, splat (i64 8)
  %.spill.load113 = load <8 x i64>, ptr %.spill, align 64
  %397 = add <8 x i64> %396, %.spill.load113
  %.spill.load114 = load <8 x i64>, ptr %.spill10, align 64
  %398 = add <8 x i64> %.spill.load114, zeroinitializer
  %399 = add <8 x i64> zeroinitializer, %398
  %400 = add <8 x i64> zeroinitializer, %397
  %401 = mul <8 x i64> %399, splat (i64 1538)
  %402 = add <8 x i64> %401, %400
  %tile_snapshot.spill.load115 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 0
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 1
  %.state116 = load <8 x i64>, ptr %.slot18, align 64
  %405 = mul <8 x i64> %.state116, splat (i64 32)
  %406 = add <8 x i64> %404, %405
  %407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %403, 0
  %408 = insertvalue { <8 x ptr>, <8 x i64> } %407, <8 x i64> %406, 1
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %408, 1
  %411 = extractelement <8 x ptr> %409, i32 0
  %412 = extractelement <8 x i64> %410, i32 0
  %413 = sub i64 %412, 0
  %414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %415 = select i1 %414, i64 %413, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %411, i64 %415
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address117, align 4
  %416 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 0
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 1
  %.state119 = load <8 x i64>, ptr %.slot18, align 64
  %419 = mul <8 x i64> %.state119, splat (i64 32)
  %420 = add <8 x i64> %418, %419
  %421 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %417, 0
  %422 = insertvalue { <8 x ptr>, <8 x i64> } %421, <8 x i64> %420, 1
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %422, 1
  %425 = extractelement <8 x ptr> %423, i32 0
  %426 = extractelement <8 x i64> %424, i32 0
  %427 = sub i64 %426, 0
  %428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %429 = select i1 %428, i64 %427, i64 0
  %private.contiguous.address120 = getelementptr i8, ptr %425, i64 %429
  %private.contiguous.load121 = load <8 x float>, ptr %private.contiguous.address120, align 4
  %430 = select <8 x i1> %55, <8 x float> %private.contiguous.load121, <8 x float> zeroinitializer
  %431 = fmul <8 x float> %416, %430
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %.state123 = load <8 x i64>, ptr %.slot18, align 64
  %434 = mul <8 x i64> %.state123, splat (i64 32)
  %435 = add <8 x i64> %433, %434
  %436 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %432, 0
  %437 = insertvalue { <8 x ptr>, <8 x i64> } %436, <8 x i64> %435, 1
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %437, 1
  %440 = extractelement <8 x ptr> %438, i32 0
  %441 = extractelement <8 x i64> %439, i32 0
  %442 = sub i64 %441, 0
  %443 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %444 = select i1 %443, i64 %442, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %440, i64 %444
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %445 = select <8 x i1> %55, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %.state127 = load <8 x i64>, ptr %.slot18, align 64
  %448 = mul <8 x i64> %.state127, splat (i64 32)
  %449 = add <8 x i64> %447, %448
  %450 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %446, 0
  %451 = insertvalue { <8 x ptr>, <8 x i64> } %450, <8 x i64> %449, 1
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %451, 1
  %454 = extractelement <8 x ptr> %452, i32 0
  %455 = extractelement <8 x i64> %453, i32 0
  %456 = sub i64 %455, 0
  %457 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %458 = select i1 %457, i64 %456, i64 0
  %private.contiguous.address128 = getelementptr i8, ptr %454, i64 %458
  %private.contiguous.load129 = load <8 x float>, ptr %private.contiguous.address128, align 4
  %459 = select <8 x i1> %55, <8 x float> %private.contiguous.load129, <8 x float> zeroinitializer
  %460 = fmul <8 x float> %445, %459
  %461 = fsub <8 x float> %431, %460
  %462 = extractvalue { ptr, i64 } %31, 0
  %463 = extractelement <8 x i64> %402, i32 0
  %464 = sub i64 %463, 0
  %465 = mul i64 %464, 4
  %buffer.contiguous.address130 = getelementptr i8, ptr %462, i64 %465
  call void @llvm.masked.store.v8f32.p0(<8 x float> %461, ptr align 1 %buffer.contiguous.address130, <8 x i1> %55)
  %.state131 = load <8 x i64>, ptr %.slot18, align 64
  %466 = add <8 x i64> %.state131, splat (i64 1)
  %467 = load <8 x i64>, ptr %.slot18, align 64
  %468 = select <8 x i1> %55, <8 x i64> %466, <8 x i64> %467
  store <8 x i64> %468, ptr %.slot18, align 64
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false111
  %.spill.load132 = load <8 x i1>, ptr %.spill11, align 1
  %469 = and <8 x i1> %55, %.spill.load132
  %470 = xor <8 x i1> %.spill.load132, splat (i1 true)
  %471 = and <8 x i1> %55, %470
  %472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %469)
  %473 = bitcast <8 x i1> %469 to i8
  %474 = call i8 @llvm.cttz.i8(i8 %473, i1 false)
  %475 = zext i8 %474 to i32
  %476 = select i1 %472, i32 %475, i32 0
  %.spill.load133 = load <8 x i64>, ptr %.spill, align 64
  %477 = add <8 x i64> splat (i64 768), %.spill.load133
  %.spill.load134 = load <8 x i64>, ptr %.spill10, align 64
  %478 = add <8 x i64> %.spill.load134, zeroinitializer
  %479 = add <8 x i64> zeroinitializer, %478
  %480 = add <8 x i64> zeroinitializer, %477
  %481 = mul <8 x i64> %479, splat (i64 1538)
  %482 = add <8 x i64> %481, %480
  %tile_snapshot.spill.load135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %483 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 0
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 1
  %485 = add <8 x i64> %484, splat (i64 3072)
  %486 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %483, 0
  %487 = insertvalue { <8 x ptr>, <8 x i64> } %486, <8 x i64> %485, 1
  %488 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %487, 1
  %490 = extractelement <8 x ptr> %488, i32 0
  %491 = extractelement <8 x i64> %489, i32 %476
  %492 = zext i32 %476 to i64
  %493 = mul i64 %492, 4
  %494 = sub i64 %491, %493
  %495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %469)
  %496 = select i1 %495, i64 %494, i64 0
  %private.contiguous.address136 = getelementptr i8, ptr %490, i64 %496
  %private.contiguous.load137 = load <8 x float>, ptr %private.contiguous.address136, align 4
  %497 = select <8 x i1> %469, <8 x float> %private.contiguous.load137, <8 x float> zeroinitializer
  %tile_snapshot.spill.load138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 0
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 1
  %500 = add <8 x i64> %499, splat (i64 3072)
  %501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %498, 0
  %502 = insertvalue { <8 x ptr>, <8 x i64> } %501, <8 x i64> %500, 1
  %503 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %502, 1
  %505 = extractelement <8 x ptr> %503, i32 0
  %506 = extractelement <8 x i64> %504, i32 %476
  %507 = zext i32 %476 to i64
  %508 = mul i64 %507, 4
  %509 = sub i64 %506, %508
  %510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %469)
  %511 = select i1 %510, i64 %509, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %505, i64 %511
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %512 = select <8 x i1> %469, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %513 = fmul <8 x float> %497, %512
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %514 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %516 = add <8 x i64> %515, splat (i64 3072)
  %517 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %514, 0
  %518 = insertvalue { <8 x ptr>, <8 x i64> } %517, <8 x i64> %516, 1
  %519 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %520 = extractvalue { <8 x ptr>, <8 x i64> } %518, 1
  %521 = extractelement <8 x ptr> %519, i32 0
  %522 = extractelement <8 x i64> %520, i32 %476
  %523 = zext i32 %476 to i64
  %524 = mul i64 %523, 4
  %525 = sub i64 %522, %524
  %526 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %469)
  %527 = select i1 %526, i64 %525, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %521, i64 %527
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %528 = select <8 x i1> %469, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %tile_snapshot.spill.load144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 1
  %531 = add <8 x i64> %530, splat (i64 3072)
  %532 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %529, 0
  %533 = insertvalue { <8 x ptr>, <8 x i64> } %532, <8 x i64> %531, 1
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %533, 1
  %536 = extractelement <8 x ptr> %534, i32 0
  %537 = extractelement <8 x i64> %535, i32 %476
  %538 = zext i32 %476 to i64
  %539 = mul i64 %538, 4
  %540 = sub i64 %537, %539
  %541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %469)
  %542 = select i1 %541, i64 %540, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %536, i64 %542
  %private.contiguous.load146 = load <8 x float>, ptr %private.contiguous.address145, align 4
  %543 = select <8 x i1> %469, <8 x float> %private.contiguous.load146, <8 x float> zeroinitializer
  %544 = fmul <8 x float> %528, %543
  %545 = fsub <8 x float> %513, %544
  %546 = extractvalue { ptr, i64 } %31, 0
  %547 = extractelement <8 x i64> %482, i32 %476
  %548 = zext i32 %476 to i64
  %549 = sub i64 %547, %548
  %550 = mul i64 %549, 4
  %buffer.contiguous.address147 = getelementptr i8, ptr %546, i64 %550
  call void @llvm.masked.store.v8f32.p0(<8 x float> %545, ptr align 1 %buffer.contiguous.address147, <8 x i1> %469)
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %471)
  %552 = bitcast <8 x i1> %471 to i8
  %553 = call i8 @llvm.cttz.i8(i8 %552, i1 false)
  %554 = zext i8 %553 to i32
  %555 = select i1 %551, i32 %554, i32 0
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.23
  %556 = load <8 x i64>, ptr %.slot19, align 64
  %557 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %556
  store <8 x i64> %557, ptr %.slot19, align 64
  br label %direct.schedule.26

direct.schedule.26:                               ; preds = %direct.schedule.27, %direct.schedule.25
  %.state148 = load <8 x i64>, ptr %.slot19, align 64
  %558 = icmp slt <8 x i64> %.state148, splat (i64 96)
  %559 = extractelement <8 x i1> %558, i32 0
  br i1 %559, label %direct.true149, label %direct.false150

direct.schedule.27:                               ; preds = %direct.true149
  %.state151 = load <8 x i64>, ptr %.slot19, align 64
  %560 = mul <8 x i64> %.state151, splat (i64 8)
  %.spill.load152 = load <8 x i64>, ptr %.spill, align 64
  %561 = add <8 x i64> %560, %.spill.load152
  %.spill.load153 = load <8 x i64>, ptr %.spill10, align 64
  %562 = add <8 x i64> %.spill.load153, zeroinitializer
  %563 = add <8 x i64> zeroinitializer, %562
  %564 = add <8 x i64> splat (i64 769), %561
  %565 = mul <8 x i64> %563, splat (i64 1538)
  %566 = add <8 x i64> %565, %564
  %tile_snapshot.spill.load154 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 0
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 1
  %.state155 = load <8 x i64>, ptr %.slot19, align 64
  %569 = mul <8 x i64> %.state155, splat (i64 32)
  %570 = add <8 x i64> %568, %569
  %571 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %567, 0
  %572 = insertvalue { <8 x ptr>, <8 x i64> } %571, <8 x i64> %570, 1
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %572, 1
  %575 = extractelement <8 x ptr> %573, i32 0
  %576 = extractelement <8 x i64> %574, i32 0
  %577 = sub i64 %576, 0
  %578 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %579 = select i1 %578, i64 %577, i64 0
  %private.contiguous.address156 = getelementptr i8, ptr %575, i64 %579
  %private.contiguous.load157 = load <8 x float>, ptr %private.contiguous.address156, align 4
  %580 = select <8 x i1> %55, <8 x float> %private.contiguous.load157, <8 x float> zeroinitializer
  %tile_snapshot.spill.load158 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 0
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 1
  %.state159 = load <8 x i64>, ptr %.slot19, align 64
  %583 = mul <8 x i64> %.state159, splat (i64 32)
  %584 = add <8 x i64> %582, %583
  %585 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %581, 0
  %586 = insertvalue { <8 x ptr>, <8 x i64> } %585, <8 x i64> %584, 1
  %587 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %586, 1
  %589 = extractelement <8 x ptr> %587, i32 0
  %590 = extractelement <8 x i64> %588, i32 0
  %591 = sub i64 %590, 0
  %592 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %593 = select i1 %592, i64 %591, i64 0
  %private.contiguous.address160 = getelementptr i8, ptr %589, i64 %593
  %private.contiguous.load161 = load <8 x float>, ptr %private.contiguous.address160, align 4
  %594 = select <8 x i1> %55, <8 x float> %private.contiguous.load161, <8 x float> zeroinitializer
  %595 = fmul <8 x float> %580, %594
  %tile_snapshot.spill.load162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 0
  %597 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 1
  %.state163 = load <8 x i64>, ptr %.slot19, align 64
  %598 = mul <8 x i64> %.state163, splat (i64 32)
  %599 = add <8 x i64> %597, %598
  %600 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %596, 0
  %601 = insertvalue { <8 x ptr>, <8 x i64> } %600, <8 x i64> %599, 1
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %601, 1
  %604 = extractelement <8 x ptr> %602, i32 0
  %605 = extractelement <8 x i64> %603, i32 0
  %606 = sub i64 %605, 0
  %607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %608 = select i1 %607, i64 %606, i64 0
  %private.contiguous.address164 = getelementptr i8, ptr %604, i64 %608
  %private.contiguous.load165 = load <8 x float>, ptr %private.contiguous.address164, align 4
  %609 = select <8 x i1> %55, <8 x float> %private.contiguous.load165, <8 x float> zeroinitializer
  %tile_snapshot.spill.load166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 0
  %611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 1
  %.state167 = load <8 x i64>, ptr %.slot19, align 64
  %612 = mul <8 x i64> %.state167, splat (i64 32)
  %613 = add <8 x i64> %611, %612
  %614 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %610, 0
  %615 = insertvalue { <8 x ptr>, <8 x i64> } %614, <8 x i64> %613, 1
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %615, 1
  %618 = extractelement <8 x ptr> %616, i32 0
  %619 = extractelement <8 x i64> %617, i32 0
  %620 = sub i64 %619, 0
  %621 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %622 = select i1 %621, i64 %620, i64 0
  %private.contiguous.address168 = getelementptr i8, ptr %618, i64 %622
  %private.contiguous.load169 = load <8 x float>, ptr %private.contiguous.address168, align 4
  %623 = select <8 x i1> %55, <8 x float> %private.contiguous.load169, <8 x float> zeroinitializer
  %624 = fmul <8 x float> %609, %623
  %625 = fadd <8 x float> %595, %624
  %626 = extractvalue { ptr, i64 } %31, 0
  %627 = extractelement <8 x i64> %566, i32 0
  %628 = sub i64 %627, 0
  %629 = mul i64 %628, 4
  %buffer.contiguous.address170 = getelementptr i8, ptr %626, i64 %629
  call void @llvm.masked.store.v8f32.p0(<8 x float> %625, ptr align 1 %buffer.contiguous.address170, <8 x i1> %55)
  %.state171 = load <8 x i64>, ptr %.slot19, align 64
  %630 = add <8 x i64> %.state171, splat (i64 1)
  %631 = load <8 x i64>, ptr %.slot19, align 64
  %632 = select <8 x i1> %55, <8 x i64> %630, <8 x i64> %631
  store <8 x i64> %632, ptr %.slot19, align 64
  br label %direct.schedule.26

direct.schedule.28:                               ; preds = %direct.false150
  %.spill.load172 = load <8 x i1>, ptr %.spill11, align 1
  %633 = and <8 x i1> %55, %.spill.load172
  %634 = xor <8 x i1> %.spill.load172, splat (i1 true)
  %635 = and <8 x i1> %55, %634
  %636 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %637 = bitcast <8 x i1> %633 to i8
  %638 = call i8 @llvm.cttz.i8(i8 %637, i1 false)
  %639 = zext i8 %638 to i32
  %640 = select i1 %636, i32 %639, i32 0
  %.spill.load173 = load <8 x i64>, ptr %.spill, align 64
  %641 = add <8 x i64> splat (i64 768), %.spill.load173
  %.spill.load174 = load <8 x i64>, ptr %.spill10, align 64
  %642 = add <8 x i64> %.spill.load174, zeroinitializer
  %643 = add <8 x i64> zeroinitializer, %642
  %644 = add <8 x i64> splat (i64 769), %641
  %645 = mul <8 x i64> %643, splat (i64 1538)
  %646 = add <8 x i64> %645, %644
  %tile_snapshot.spill.load175 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load175, 0
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load175, 1
  %649 = add <8 x i64> %648, splat (i64 3072)
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %647, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 %640
  %656 = zext i32 %640 to i64
  %657 = mul i64 %656, 4
  %658 = sub i64 %655, %657
  %659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %660 = select i1 %659, i64 %658, i64 0
  %private.contiguous.address176 = getelementptr i8, ptr %654, i64 %660
  %private.contiguous.load177 = load <8 x float>, ptr %private.contiguous.address176, align 4
  %661 = select <8 x i1> %633, <8 x float> %private.contiguous.load177, <8 x float> zeroinitializer
  %tile_snapshot.spill.load178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 0
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 1
  %664 = add <8 x i64> %663, splat (i64 3072)
  %665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %662, 0
  %666 = insertvalue { <8 x ptr>, <8 x i64> } %665, <8 x i64> %664, 1
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %666, 1
  %669 = extractelement <8 x ptr> %667, i32 0
  %670 = extractelement <8 x i64> %668, i32 %640
  %671 = zext i32 %640 to i64
  %672 = mul i64 %671, 4
  %673 = sub i64 %670, %672
  %674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %675 = select i1 %674, i64 %673, i64 0
  %private.contiguous.address179 = getelementptr i8, ptr %669, i64 %675
  %private.contiguous.load180 = load <8 x float>, ptr %private.contiguous.address179, align 4
  %676 = select <8 x i1> %633, <8 x float> %private.contiguous.load180, <8 x float> zeroinitializer
  %677 = fmul <8 x float> %661, %676
  %tile_snapshot.spill.load181 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %678 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 0
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 1
  %680 = add <8 x i64> %679, splat (i64 3072)
  %681 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %678, 0
  %682 = insertvalue { <8 x ptr>, <8 x i64> } %681, <8 x i64> %680, 1
  %683 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %682, 1
  %685 = extractelement <8 x ptr> %683, i32 0
  %686 = extractelement <8 x i64> %684, i32 %640
  %687 = zext i32 %640 to i64
  %688 = mul i64 %687, 4
  %689 = sub i64 %686, %688
  %690 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %691 = select i1 %690, i64 %689, i64 0
  %private.contiguous.address182 = getelementptr i8, ptr %685, i64 %691
  %private.contiguous.load183 = load <8 x float>, ptr %private.contiguous.address182, align 4
  %692 = select <8 x i1> %633, <8 x float> %private.contiguous.load183, <8 x float> zeroinitializer
  %tile_snapshot.spill.load184 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 0
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 1
  %695 = add <8 x i64> %694, splat (i64 3072)
  %696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %693, 0
  %697 = insertvalue { <8 x ptr>, <8 x i64> } %696, <8 x i64> %695, 1
  %698 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %697, 1
  %700 = extractelement <8 x ptr> %698, i32 0
  %701 = extractelement <8 x i64> %699, i32 %640
  %702 = zext i32 %640 to i64
  %703 = mul i64 %702, 4
  %704 = sub i64 %701, %703
  %705 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %706 = select i1 %705, i64 %704, i64 0
  %private.contiguous.address185 = getelementptr i8, ptr %700, i64 %706
  %private.contiguous.load186 = load <8 x float>, ptr %private.contiguous.address185, align 4
  %707 = select <8 x i1> %633, <8 x float> %private.contiguous.load186, <8 x float> zeroinitializer
  %708 = fmul <8 x float> %692, %707
  %709 = fadd <8 x float> %677, %708
  %710 = extractvalue { ptr, i64 } %31, 0
  %711 = extractelement <8 x i64> %646, i32 %640
  %712 = zext i32 %640 to i64
  %713 = sub i64 %711, %712
  %714 = mul i64 %713, 4
  %buffer.contiguous.address187 = getelementptr i8, ptr %710, i64 %714
  call void @llvm.masked.store.v8f32.p0(<8 x float> %709, ptr align 1 %buffer.contiguous.address187, <8 x i1> %633)
  %715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %635)
  %716 = bitcast <8 x i1> %635 to i8
  %717 = call i8 @llvm.cttz.i8(i8 %716, i1 false)
  %718 = zext i8 %717 to i32
  %719 = select i1 %715, i32 %718, i32 0
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.28
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true47:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false48:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true68:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false69:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true89:                                    ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false90:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true110:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false111:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true149:                                   ; preds = %direct.schedule.26
  br label %direct.schedule.27

direct.false150:                                  ; preds = %direct.schedule.26
  br label %direct.schedule.28
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [3104 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3104 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [3104 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [3104 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill11 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill11, align 1
  %tile_snapshot.spill12 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill12, align 64
  %.slot13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot13, align 64
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot15, align 64
  %tile_snapshot.spill16 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill16, align 64
  %.slot17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot17, align 64
  %.slot18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot18, align 64
  %.slot19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot19, align 64
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat21, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat23, %45
  %48 = mul i32 %36, 1
  %.splatinsert24 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat25 = shufflevector <8 x i32> %.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat25, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert26 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat27 = shufflevector <8 x i32> %.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat27, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert28 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat29 = shufflevector <8 x i32> %.splatinsert28, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat29
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %70, 0
  %73 = select <8 x i1> %55, <8 x ptr> %71, <8 x ptr> %72
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %70, 1
  %76 = select <8 x i1> %55, <8 x i64> %74, <8 x i64> %75
  %77 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %73, 0
  %78 = insertvalue { <8 x ptr>, <8 x i64> } %77, <8 x i64> %76, 1
  store { <8 x ptr>, <8 x i64> } %78, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %79 = icmp slt i64 %.state, 96
  br i1 %79, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state30 = load i64, ptr %.slot, align 4
  %80 = mul i64 %.state30, 8
  %.splatinsert31 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat32 = shufflevector <8 x i64> %.splatinsert31, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.splat32, %.spill.load
  %.spill.load33 = load <8 x i64>, ptr %.spill10, align 64
  %82 = add <8 x i64> %.spill.load33, zeroinitializer
  %83 = add <8 x i64> zeroinitializer, %82
  %84 = add <8 x i64> zeroinitializer, %81
  %85 = mul <8 x i64> %83, splat (i64 1538)
  %86 = add <8 x i64> %85, %84
  %87 = extractvalue { ptr, i64 } %13, 0
  %88 = extractelement <8 x i64> %86, i32 0
  %89 = sub i64 %88, 0
  %90 = mul i64 %89, 4
  %buffer.contiguous.address = getelementptr i8, ptr %87, i64 %90
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %92 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state34 = load i64, ptr %.slot, align 4
  %.splatinsert35 = insertelement <8 x i64> poison, i64 %.state34, i64 0
  %.splat36 = shufflevector <8 x i64> %.splatinsert35, <8 x i64> poison, <8 x i32> zeroinitializer
  %93 = mul <8 x i64> %.splat36, splat (i64 32)
  %94 = add <8 x i64> %92, %93
  %95 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %91, 0
  %96 = insertvalue { <8 x ptr>, <8 x i64> } %95, <8 x i64> %94, 1
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %99 = extractelement <8 x ptr> %97, i32 0
  %100 = extractelement <8 x i64> %98, i32 0
  %101 = sub i64 %100, 0
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %103 = select i1 %102, i64 %101, i64 0
  %private.contiguous.address = getelementptr i8, ptr %99, i64 %103
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %104 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %104, ptr %private.contiguous.address, align 4
  %.state37 = load i64, ptr %.slot, align 4
  %105 = add i64 %.state37, 1
  store i64 %105, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load38 = load <8 x i64>, ptr %.spill, align 64
  %106 = icmp slt <8 x i64> %.spill.load38, splat (i64 1)
  %107 = load <8 x i1>, ptr %.spill11, align 1
  %108 = select <8 x i1> %55, <8 x i1> %106, <8 x i1> %107
  store <8 x i1> %108, ptr %.spill11, align 1
  %109 = and <8 x i1> %55, %106
  %110 = xor <8 x i1> %106, splat (i1 true)
  %111 = and <8 x i1> %55, %110
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %109)
  %113 = bitcast <8 x i1> %109 to i8
  %114 = call i8 @llvm.cttz.i8(i8 %113, i1 false)
  %115 = zext i8 %114 to i32
  %116 = select i1 %112, i32 %115, i32 0
  %.spill.load39 = load <8 x i64>, ptr %.spill, align 64
  %117 = add <8 x i64> splat (i64 768), %.spill.load39
  %.spill.load40 = load <8 x i64>, ptr %.spill10, align 64
  %118 = add <8 x i64> %.spill.load40, zeroinitializer
  %119 = add <8 x i64> zeroinitializer, %118
  %120 = add <8 x i64> zeroinitializer, %117
  %121 = mul <8 x i64> %119, splat (i64 1538)
  %122 = add <8 x i64> %121, %120
  %123 = extractvalue { ptr, i64 } %13, 0
  %124 = select <8 x i1> %109, <8 x i64> %122, <8 x i64> zeroinitializer
  %125 = extractelement <8 x i64> %124, i32 %116
  %126 = zext i32 %116 to i64
  %127 = sub i64 %125, %126
  %128 = mul i64 %127, 4
  %buffer.contiguous.address41 = getelementptr i8, ptr %123, i64 %128
  %buffer.contiguous.load42 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address41, <8 x i1> %109, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load43 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 1
  %131 = add <8 x i64> %130, splat (i64 3072)
  %132 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %129, 0
  %133 = insertvalue { <8 x ptr>, <8 x i64> } %132, <8 x i64> %131, 1
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %136 = extractelement <8 x ptr> %134, i32 0
  %137 = extractelement <8 x i64> %135, i32 %116
  %138 = zext i32 %116 to i64
  %139 = mul i64 %138, 4
  %140 = sub i64 %137, %139
  %141 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %109)
  %142 = select i1 %141, i64 %140, i64 0
  %private.contiguous.address44 = getelementptr i8, ptr %136, i64 %142
  %private.contiguous.preserve45 = load <8 x float>, ptr %private.contiguous.address44, align 4
  %143 = select <8 x i1> %109, <8 x float> %buffer.contiguous.load42, <8 x float> %private.contiguous.preserve45
  store <8 x float> %143, ptr %private.contiguous.address44, align 4
  %144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %145 = bitcast <8 x i1> %111 to i8
  %146 = call i8 @llvm.cttz.i8(i8 %145, i1 false)
  %147 = zext i8 %146 to i32
  %148 = select i1 %144, i32 %147, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  %149 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 0
  %152 = select <8 x i1> %55, <8 x ptr> %150, <8 x ptr> %151
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %155 = select <8 x i1> %55, <8 x i64> %153, <8 x i64> %154
  %156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %152, 0
  %157 = insertvalue { <8 x ptr>, <8 x i64> } %156, <8 x i64> %155, 1
  store { <8 x ptr>, <8 x i64> } %157, ptr %tile_snapshot.spill12, align 64
  %158 = load <8 x i64>, ptr %.slot13, align 64
  %159 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %158
  store <8 x i64> %159, ptr %.slot13, align 64
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state46 = load <8 x i64>, ptr %.slot13, align 64
  %160 = icmp slt <8 x i64> %.state46, splat (i64 96)
  %161 = extractelement <8 x i1> %160, i32 0
  br i1 %161, label %direct.true47, label %direct.false48

direct.schedule.7:                                ; preds = %direct.true47
  %.state49 = load <8 x i64>, ptr %.slot13, align 64
  %162 = mul <8 x i64> %.state49, splat (i64 8)
  %.spill.load50 = load <8 x i64>, ptr %.spill, align 64
  %163 = add <8 x i64> %162, %.spill.load50
  %.spill.load51 = load <8 x i64>, ptr %.spill10, align 64
  %164 = add <8 x i64> %.spill.load51, zeroinitializer
  %165 = add <8 x i64> zeroinitializer, %164
  %166 = add <8 x i64> splat (i64 769), %163
  %167 = mul <8 x i64> %165, splat (i64 1538)
  %168 = add <8 x i64> %167, %166
  %169 = extractvalue { ptr, i64 } %13, 0
  %170 = extractelement <8 x i64> %168, i32 0
  %171 = sub i64 %170, 0
  %172 = mul i64 %171, 4
  %buffer.contiguous.address52 = getelementptr i8, ptr %169, i64 %172
  %buffer.contiguous.load53 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address52, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load54 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load54, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load54, 1
  %.state55 = load <8 x i64>, ptr %.slot13, align 64
  %175 = mul <8 x i64> %.state55, splat (i64 32)
  %176 = add <8 x i64> %174, %175
  %177 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %178 = insertvalue { <8 x ptr>, <8 x i64> } %177, <8 x i64> %176, 1
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %178, 1
  %181 = extractelement <8 x ptr> %179, i32 0
  %182 = extractelement <8 x i64> %180, i32 0
  %183 = sub i64 %182, 0
  %184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %185 = select i1 %184, i64 %183, i64 0
  %private.contiguous.address56 = getelementptr i8, ptr %181, i64 %185
  %private.contiguous.preserve57 = load <8 x float>, ptr %private.contiguous.address56, align 4
  %186 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load53, <8 x float> %private.contiguous.preserve57
  store <8 x float> %186, ptr %private.contiguous.address56, align 4
  %.state58 = load <8 x i64>, ptr %.slot13, align 64
  %187 = add <8 x i64> %.state58, splat (i64 1)
  %188 = load <8 x i64>, ptr %.slot13, align 64
  %189 = select <8 x i1> %55, <8 x i64> %187, <8 x i64> %188
  store <8 x i64> %189, ptr %.slot13, align 64
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false48
  %.spill.load59 = load <8 x i1>, ptr %.spill11, align 1
  %190 = and <8 x i1> %55, %.spill.load59
  %191 = xor <8 x i1> %.spill.load59, splat (i1 true)
  %192 = and <8 x i1> %55, %191
  %193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %190)
  %194 = bitcast <8 x i1> %190 to i8
  %195 = call i8 @llvm.cttz.i8(i8 %194, i1 false)
  %196 = zext i8 %195 to i32
  %197 = select i1 %193, i32 %196, i32 0
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %198 = add <8 x i64> splat (i64 768), %.spill.load60
  %.spill.load61 = load <8 x i64>, ptr %.spill10, align 64
  %199 = add <8 x i64> %.spill.load61, zeroinitializer
  %200 = add <8 x i64> zeroinitializer, %199
  %201 = add <8 x i64> splat (i64 769), %198
  %202 = mul <8 x i64> %200, splat (i64 1538)
  %203 = add <8 x i64> %202, %201
  %204 = extractvalue { ptr, i64 } %13, 0
  %205 = select <8 x i1> %190, <8 x i64> %203, <8 x i64> zeroinitializer
  %206 = extractelement <8 x i64> %205, i32 %197
  %207 = zext i32 %197 to i64
  %208 = sub i64 %206, %207
  %209 = mul i64 %208, 4
  %buffer.contiguous.address62 = getelementptr i8, ptr %204, i64 %209
  %buffer.contiguous.load63 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address62, <8 x i1> %190, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %212 = add <8 x i64> %211, splat (i64 3072)
  %213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %210, 0
  %214 = insertvalue { <8 x ptr>, <8 x i64> } %213, <8 x i64> %212, 1
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %217 = extractelement <8 x ptr> %215, i32 0
  %218 = extractelement <8 x i64> %216, i32 %197
  %219 = zext i32 %197 to i64
  %220 = mul i64 %219, 4
  %221 = sub i64 %218, %220
  %222 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %190)
  %223 = select i1 %222, i64 %221, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %217, i64 %223
  %private.contiguous.preserve66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %224 = select <8 x i1> %190, <8 x float> %buffer.contiguous.load63, <8 x float> %private.contiguous.preserve66
  store <8 x float> %224, ptr %private.contiguous.address65, align 4
  %225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %192)
  %226 = bitcast <8 x i1> %192 to i8
  %227 = call i8 @llvm.cttz.i8(i8 %226, i1 false)
  %228 = zext i8 %227 to i32
  %229 = select i1 %225, i32 %228, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %230 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %230, 0
  %233 = select <8 x i1> %55, <8 x ptr> %231, <8 x ptr> %232
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %230, 1
  %236 = select <8 x i1> %55, <8 x i64> %234, <8 x i64> %235
  %237 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %233, 0
  %238 = insertvalue { <8 x ptr>, <8 x i64> } %237, <8 x i64> %236, 1
  store { <8 x ptr>, <8 x i64> } %238, ptr %tile_snapshot.spill14, align 64
  %239 = load <8 x i64>, ptr %.slot15, align 64
  %240 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %239
  store <8 x i64> %240, ptr %.slot15, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state67 = load <8 x i64>, ptr %.slot15, align 64
  %241 = icmp slt <8 x i64> %.state67, splat (i64 96)
  %242 = extractelement <8 x i1> %241, i32 0
  br i1 %242, label %direct.true68, label %direct.false69

direct.schedule.12:                               ; preds = %direct.true68
  %.state70 = load <8 x i64>, ptr %.slot15, align 64
  %243 = mul <8 x i64> %.state70, splat (i64 8)
  %.spill.load71 = load <8 x i64>, ptr %.spill, align 64
  %244 = add <8 x i64> %243, %.spill.load71
  %.spill.load72 = load <8 x i64>, ptr %.spill10, align 64
  %245 = add <8 x i64> %.spill.load72, zeroinitializer
  %246 = add <8 x i64> zeroinitializer, %245
  %247 = add <8 x i64> zeroinitializer, %244
  %248 = mul <8 x i64> %246, splat (i64 769)
  %249 = add <8 x i64> %248, %247
  %250 = extractvalue { ptr, i64 } %19, 0
  %251 = extractelement <8 x i64> %249, i32 0
  %252 = sub i64 %251, 0
  %253 = mul i64 %252, 4
  %buffer.contiguous.address73 = getelementptr i8, ptr %250, i64 %253
  %buffer.contiguous.load74 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address73, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load75 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 1
  %.state76 = load <8 x i64>, ptr %.slot15, align 64
  %256 = mul <8 x i64> %.state76, splat (i64 32)
  %257 = add <8 x i64> %255, %256
  %258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %254, 0
  %259 = insertvalue { <8 x ptr>, <8 x i64> } %258, <8 x i64> %257, 1
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %259, 1
  %262 = extractelement <8 x ptr> %260, i32 0
  %263 = extractelement <8 x i64> %261, i32 0
  %264 = sub i64 %263, 0
  %265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %266 = select i1 %265, i64 %264, i64 0
  %private.contiguous.address77 = getelementptr i8, ptr %262, i64 %266
  %private.contiguous.preserve78 = load <8 x float>, ptr %private.contiguous.address77, align 4
  %267 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load74, <8 x float> %private.contiguous.preserve78
  store <8 x float> %267, ptr %private.contiguous.address77, align 4
  %.state79 = load <8 x i64>, ptr %.slot15, align 64
  %268 = add <8 x i64> %.state79, splat (i64 1)
  %269 = load <8 x i64>, ptr %.slot15, align 64
  %270 = select <8 x i1> %55, <8 x i64> %268, <8 x i64> %269
  store <8 x i64> %270, ptr %.slot15, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false69
  %.spill.load80 = load <8 x i1>, ptr %.spill11, align 1
  %271 = and <8 x i1> %55, %.spill.load80
  %272 = xor <8 x i1> %.spill.load80, splat (i1 true)
  %273 = and <8 x i1> %55, %272
  %274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %271)
  %275 = bitcast <8 x i1> %271 to i8
  %276 = call i8 @llvm.cttz.i8(i8 %275, i1 false)
  %277 = zext i8 %276 to i32
  %278 = select i1 %274, i32 %277, i32 0
  %.spill.load81 = load <8 x i64>, ptr %.spill, align 64
  %279 = add <8 x i64> splat (i64 768), %.spill.load81
  %.spill.load82 = load <8 x i64>, ptr %.spill10, align 64
  %280 = add <8 x i64> %.spill.load82, zeroinitializer
  %281 = add <8 x i64> zeroinitializer, %280
  %282 = add <8 x i64> zeroinitializer, %279
  %283 = mul <8 x i64> %281, splat (i64 769)
  %284 = add <8 x i64> %283, %282
  %285 = extractvalue { ptr, i64 } %19, 0
  %286 = select <8 x i1> %271, <8 x i64> %284, <8 x i64> zeroinitializer
  %287 = extractelement <8 x i64> %286, i32 %278
  %288 = zext i32 %278 to i64
  %289 = sub i64 %287, %288
  %290 = mul i64 %289, 4
  %buffer.contiguous.address83 = getelementptr i8, ptr %285, i64 %290
  %buffer.contiguous.load84 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address83, <8 x i1> %271, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 0
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 1
  %293 = add <8 x i64> %292, splat (i64 3072)
  %294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %291, 0
  %295 = insertvalue { <8 x ptr>, <8 x i64> } %294, <8 x i64> %293, 1
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %295, 1
  %298 = extractelement <8 x ptr> %296, i32 0
  %299 = extractelement <8 x i64> %297, i32 %278
  %300 = zext i32 %278 to i64
  %301 = mul i64 %300, 4
  %302 = sub i64 %299, %301
  %303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %271)
  %304 = select i1 %303, i64 %302, i64 0
  %private.contiguous.address86 = getelementptr i8, ptr %298, i64 %304
  %private.contiguous.preserve87 = load <8 x float>, ptr %private.contiguous.address86, align 4
  %305 = select <8 x i1> %271, <8 x float> %buffer.contiguous.load84, <8 x float> %private.contiguous.preserve87
  store <8 x float> %305, ptr %private.contiguous.address86, align 4
  %306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %273)
  %307 = bitcast <8 x i1> %273 to i8
  %308 = call i8 @llvm.cttz.i8(i8 %307, i1 false)
  %309 = zext i8 %308 to i32
  %310 = select i1 %306, i32 %309, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %311 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %311, 0
  %314 = select <8 x i1> %55, <8 x ptr> %312, <8 x ptr> %313
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %311, 1
  %317 = select <8 x i1> %55, <8 x i64> %315, <8 x i64> %316
  %318 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %314, 0
  %319 = insertvalue { <8 x ptr>, <8 x i64> } %318, <8 x i64> %317, 1
  store { <8 x ptr>, <8 x i64> } %319, ptr %tile_snapshot.spill16, align 64
  %320 = load <8 x i64>, ptr %.slot17, align 64
  %321 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %320
  store <8 x i64> %321, ptr %.slot17, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state88 = load <8 x i64>, ptr %.slot17, align 64
  %322 = icmp slt <8 x i64> %.state88, splat (i64 96)
  %323 = extractelement <8 x i1> %322, i32 0
  br i1 %323, label %direct.true89, label %direct.false90

direct.schedule.17:                               ; preds = %direct.true89
  %.state91 = load <8 x i64>, ptr %.slot17, align 64
  %324 = mul <8 x i64> %.state91, splat (i64 8)
  %.spill.load92 = load <8 x i64>, ptr %.spill, align 64
  %325 = add <8 x i64> %324, %.spill.load92
  %.spill.load93 = load <8 x i64>, ptr %.spill10, align 64
  %326 = add <8 x i64> %.spill.load93, zeroinitializer
  %327 = add <8 x i64> zeroinitializer, %326
  %328 = add <8 x i64> zeroinitializer, %325
  %329 = mul <8 x i64> %327, splat (i64 769)
  %330 = add <8 x i64> %329, %328
  %331 = extractvalue { ptr, i64 } %25, 0
  %332 = extractelement <8 x i64> %330, i32 0
  %333 = sub i64 %332, 0
  %334 = mul i64 %333, 4
  %buffer.contiguous.address94 = getelementptr i8, ptr %331, i64 %334
  %buffer.contiguous.load95 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address94, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.state97 = load <8 x i64>, ptr %.slot17, align 64
  %337 = mul <8 x i64> %.state97, splat (i64 32)
  %338 = add <8 x i64> %336, %337
  %339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %335, 0
  %340 = insertvalue { <8 x ptr>, <8 x i64> } %339, <8 x i64> %338, 1
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %340, 1
  %343 = extractelement <8 x ptr> %341, i32 0
  %344 = extractelement <8 x i64> %342, i32 0
  %345 = sub i64 %344, 0
  %346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %347 = select i1 %346, i64 %345, i64 0
  %private.contiguous.address98 = getelementptr i8, ptr %343, i64 %347
  %private.contiguous.preserve99 = load <8 x float>, ptr %private.contiguous.address98, align 4
  %348 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load95, <8 x float> %private.contiguous.preserve99
  store <8 x float> %348, ptr %private.contiguous.address98, align 4
  %.state100 = load <8 x i64>, ptr %.slot17, align 64
  %349 = add <8 x i64> %.state100, splat (i64 1)
  %350 = load <8 x i64>, ptr %.slot17, align 64
  %351 = select <8 x i1> %55, <8 x i64> %349, <8 x i64> %350
  store <8 x i64> %351, ptr %.slot17, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false90
  %.spill.load101 = load <8 x i1>, ptr %.spill11, align 1
  %352 = and <8 x i1> %55, %.spill.load101
  %353 = xor <8 x i1> %.spill.load101, splat (i1 true)
  %354 = and <8 x i1> %55, %353
  %355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %352)
  %356 = bitcast <8 x i1> %352 to i8
  %357 = call i8 @llvm.cttz.i8(i8 %356, i1 false)
  %358 = zext i8 %357 to i32
  %359 = select i1 %355, i32 %358, i32 0
  %.spill.load102 = load <8 x i64>, ptr %.spill, align 64
  %360 = add <8 x i64> splat (i64 768), %.spill.load102
  %.spill.load103 = load <8 x i64>, ptr %.spill10, align 64
  %361 = add <8 x i64> %.spill.load103, zeroinitializer
  %362 = add <8 x i64> zeroinitializer, %361
  %363 = add <8 x i64> zeroinitializer, %360
  %364 = mul <8 x i64> %362, splat (i64 769)
  %365 = add <8 x i64> %364, %363
  %366 = extractvalue { ptr, i64 } %25, 0
  %367 = select <8 x i1> %352, <8 x i64> %365, <8 x i64> zeroinitializer
  %368 = extractelement <8 x i64> %367, i32 %359
  %369 = zext i32 %359 to i64
  %370 = sub i64 %368, %369
  %371 = mul i64 %370, 4
  %buffer.contiguous.address104 = getelementptr i8, ptr %366, i64 %371
  %buffer.contiguous.load105 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address104, <8 x i1> %352, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %374 = add <8 x i64> %373, splat (i64 3072)
  %375 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %372, 0
  %376 = insertvalue { <8 x ptr>, <8 x i64> } %375, <8 x i64> %374, 1
  %377 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %378 = extractvalue { <8 x ptr>, <8 x i64> } %376, 1
  %379 = extractelement <8 x ptr> %377, i32 0
  %380 = extractelement <8 x i64> %378, i32 %359
  %381 = zext i32 %359 to i64
  %382 = mul i64 %381, 4
  %383 = sub i64 %380, %382
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %352)
  %385 = select i1 %384, i64 %383, i64 0
  %private.contiguous.address107 = getelementptr i8, ptr %379, i64 %385
  %private.contiguous.preserve108 = load <8 x float>, ptr %private.contiguous.address107, align 4
  %386 = select <8 x i1> %352, <8 x float> %buffer.contiguous.load105, <8 x float> %private.contiguous.preserve108
  store <8 x float> %386, ptr %private.contiguous.address107, align 4
  %387 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %354)
  %388 = bitcast <8 x i1> %354 to i8
  %389 = call i8 @llvm.cttz.i8(i8 %388, i1 false)
  %390 = zext i8 %389 to i32
  %391 = select i1 %387, i32 %390, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  %392 = load <8 x i64>, ptr %.slot18, align 64
  %393 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %392
  store <8 x i64> %393, ptr %.slot18, align 64
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state109 = load <8 x i64>, ptr %.slot18, align 64
  %394 = icmp slt <8 x i64> %.state109, splat (i64 96)
  %395 = extractelement <8 x i1> %394, i32 0
  br i1 %395, label %direct.true110, label %direct.false111

direct.schedule.22:                               ; preds = %direct.true110
  %.state112 = load <8 x i64>, ptr %.slot18, align 64
  %396 = mul <8 x i64> %.state112, splat (i64 8)
  %.spill.load113 = load <8 x i64>, ptr %.spill, align 64
  %397 = add <8 x i64> %396, %.spill.load113
  %.spill.load114 = load <8 x i64>, ptr %.spill10, align 64
  %398 = add <8 x i64> %.spill.load114, zeroinitializer
  %399 = add <8 x i64> zeroinitializer, %398
  %400 = add <8 x i64> zeroinitializer, %397
  %401 = mul <8 x i64> %399, splat (i64 1538)
  %402 = add <8 x i64> %401, %400
  %tile_snapshot.spill.load115 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 0
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 1
  %.state116 = load <8 x i64>, ptr %.slot18, align 64
  %405 = mul <8 x i64> %.state116, splat (i64 32)
  %406 = add <8 x i64> %404, %405
  %407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %403, 0
  %408 = insertvalue { <8 x ptr>, <8 x i64> } %407, <8 x i64> %406, 1
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %408, 1
  %411 = extractelement <8 x ptr> %409, i32 0
  %412 = extractelement <8 x i64> %410, i32 0
  %413 = sub i64 %412, 0
  %414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %415 = select i1 %414, i64 %413, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %411, i64 %415
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address117, align 4
  %416 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 0
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load118, 1
  %.state119 = load <8 x i64>, ptr %.slot18, align 64
  %419 = mul <8 x i64> %.state119, splat (i64 32)
  %420 = add <8 x i64> %418, %419
  %421 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %417, 0
  %422 = insertvalue { <8 x ptr>, <8 x i64> } %421, <8 x i64> %420, 1
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %422, 1
  %425 = extractelement <8 x ptr> %423, i32 0
  %426 = extractelement <8 x i64> %424, i32 0
  %427 = sub i64 %426, 0
  %428 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %429 = select i1 %428, i64 %427, i64 0
  %private.contiguous.address120 = getelementptr i8, ptr %425, i64 %429
  %private.contiguous.load121 = load <8 x float>, ptr %private.contiguous.address120, align 4
  %430 = select <8 x i1> %55, <8 x float> %private.contiguous.load121, <8 x float> zeroinitializer
  %431 = fmul <8 x float> %416, %430
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %.state123 = load <8 x i64>, ptr %.slot18, align 64
  %434 = mul <8 x i64> %.state123, splat (i64 32)
  %435 = add <8 x i64> %433, %434
  %436 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %432, 0
  %437 = insertvalue { <8 x ptr>, <8 x i64> } %436, <8 x i64> %435, 1
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %437, 1
  %440 = extractelement <8 x ptr> %438, i32 0
  %441 = extractelement <8 x i64> %439, i32 0
  %442 = sub i64 %441, 0
  %443 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %444 = select i1 %443, i64 %442, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %440, i64 %444
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %445 = select <8 x i1> %55, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  %tile_snapshot.spill.load126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 0
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load126, 1
  %.state127 = load <8 x i64>, ptr %.slot18, align 64
  %448 = mul <8 x i64> %.state127, splat (i64 32)
  %449 = add <8 x i64> %447, %448
  %450 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %446, 0
  %451 = insertvalue { <8 x ptr>, <8 x i64> } %450, <8 x i64> %449, 1
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %451, 1
  %454 = extractelement <8 x ptr> %452, i32 0
  %455 = extractelement <8 x i64> %453, i32 0
  %456 = sub i64 %455, 0
  %457 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %458 = select i1 %457, i64 %456, i64 0
  %private.contiguous.address128 = getelementptr i8, ptr %454, i64 %458
  %private.contiguous.load129 = load <8 x float>, ptr %private.contiguous.address128, align 4
  %459 = select <8 x i1> %55, <8 x float> %private.contiguous.load129, <8 x float> zeroinitializer
  %460 = fmul <8 x float> %445, %459
  %461 = fsub <8 x float> %431, %460
  %462 = extractvalue { ptr, i64 } %31, 0
  %463 = extractelement <8 x i64> %402, i32 0
  %464 = sub i64 %463, 0
  %465 = mul i64 %464, 4
  %buffer.contiguous.address130 = getelementptr i8, ptr %462, i64 %465
  call void @llvm.masked.store.v8f32.p0(<8 x float> %461, ptr align 1 %buffer.contiguous.address130, <8 x i1> %55)
  %.state131 = load <8 x i64>, ptr %.slot18, align 64
  %466 = add <8 x i64> %.state131, splat (i64 1)
  %467 = load <8 x i64>, ptr %.slot18, align 64
  %468 = select <8 x i1> %55, <8 x i64> %466, <8 x i64> %467
  store <8 x i64> %468, ptr %.slot18, align 64
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false111
  %.spill.load132 = load <8 x i1>, ptr %.spill11, align 1
  %469 = and <8 x i1> %55, %.spill.load132
  %470 = xor <8 x i1> %.spill.load132, splat (i1 true)
  %471 = and <8 x i1> %55, %470
  %472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %469)
  %473 = bitcast <8 x i1> %469 to i8
  %474 = call i8 @llvm.cttz.i8(i8 %473, i1 false)
  %475 = zext i8 %474 to i32
  %476 = select i1 %472, i32 %475, i32 0
  %.spill.load133 = load <8 x i64>, ptr %.spill, align 64
  %477 = add <8 x i64> splat (i64 768), %.spill.load133
  %.spill.load134 = load <8 x i64>, ptr %.spill10, align 64
  %478 = add <8 x i64> %.spill.load134, zeroinitializer
  %479 = add <8 x i64> zeroinitializer, %478
  %480 = add <8 x i64> zeroinitializer, %477
  %481 = mul <8 x i64> %479, splat (i64 1538)
  %482 = add <8 x i64> %481, %480
  %tile_snapshot.spill.load135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %483 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 0
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 1
  %485 = add <8 x i64> %484, splat (i64 3072)
  %486 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %483, 0
  %487 = insertvalue { <8 x ptr>, <8 x i64> } %486, <8 x i64> %485, 1
  %488 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %487, 1
  %490 = extractelement <8 x ptr> %488, i32 0
  %491 = extractelement <8 x i64> %489, i32 %476
  %492 = zext i32 %476 to i64
  %493 = mul i64 %492, 4
  %494 = sub i64 %491, %493
  %495 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %469)
  %496 = select i1 %495, i64 %494, i64 0
  %private.contiguous.address136 = getelementptr i8, ptr %490, i64 %496
  %private.contiguous.load137 = load <8 x float>, ptr %private.contiguous.address136, align 4
  %497 = select <8 x i1> %469, <8 x float> %private.contiguous.load137, <8 x float> zeroinitializer
  %tile_snapshot.spill.load138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 0
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 1
  %500 = add <8 x i64> %499, splat (i64 3072)
  %501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %498, 0
  %502 = insertvalue { <8 x ptr>, <8 x i64> } %501, <8 x i64> %500, 1
  %503 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %502, 1
  %505 = extractelement <8 x ptr> %503, i32 0
  %506 = extractelement <8 x i64> %504, i32 %476
  %507 = zext i32 %476 to i64
  %508 = mul i64 %507, 4
  %509 = sub i64 %506, %508
  %510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %469)
  %511 = select i1 %510, i64 %509, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %505, i64 %511
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %512 = select <8 x i1> %469, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %513 = fmul <8 x float> %497, %512
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %514 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %516 = add <8 x i64> %515, splat (i64 3072)
  %517 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %514, 0
  %518 = insertvalue { <8 x ptr>, <8 x i64> } %517, <8 x i64> %516, 1
  %519 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %520 = extractvalue { <8 x ptr>, <8 x i64> } %518, 1
  %521 = extractelement <8 x ptr> %519, i32 0
  %522 = extractelement <8 x i64> %520, i32 %476
  %523 = zext i32 %476 to i64
  %524 = mul i64 %523, 4
  %525 = sub i64 %522, %524
  %526 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %469)
  %527 = select i1 %526, i64 %525, i64 0
  %private.contiguous.address142 = getelementptr i8, ptr %521, i64 %527
  %private.contiguous.load143 = load <8 x float>, ptr %private.contiguous.address142, align 4
  %528 = select <8 x i1> %469, <8 x float> %private.contiguous.load143, <8 x float> zeroinitializer
  %tile_snapshot.spill.load144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 1
  %531 = add <8 x i64> %530, splat (i64 3072)
  %532 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %529, 0
  %533 = insertvalue { <8 x ptr>, <8 x i64> } %532, <8 x i64> %531, 1
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %533, 1
  %536 = extractelement <8 x ptr> %534, i32 0
  %537 = extractelement <8 x i64> %535, i32 %476
  %538 = zext i32 %476 to i64
  %539 = mul i64 %538, 4
  %540 = sub i64 %537, %539
  %541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %469)
  %542 = select i1 %541, i64 %540, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %536, i64 %542
  %private.contiguous.load146 = load <8 x float>, ptr %private.contiguous.address145, align 4
  %543 = select <8 x i1> %469, <8 x float> %private.contiguous.load146, <8 x float> zeroinitializer
  %544 = fmul <8 x float> %528, %543
  %545 = fsub <8 x float> %513, %544
  %546 = extractvalue { ptr, i64 } %31, 0
  %547 = extractelement <8 x i64> %482, i32 %476
  %548 = zext i32 %476 to i64
  %549 = sub i64 %547, %548
  %550 = mul i64 %549, 4
  %buffer.contiguous.address147 = getelementptr i8, ptr %546, i64 %550
  call void @llvm.masked.store.v8f32.p0(<8 x float> %545, ptr align 1 %buffer.contiguous.address147, <8 x i1> %469)
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %471)
  %552 = bitcast <8 x i1> %471 to i8
  %553 = call i8 @llvm.cttz.i8(i8 %552, i1 false)
  %554 = zext i8 %553 to i32
  %555 = select i1 %551, i32 %554, i32 0
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.23
  %556 = load <8 x i64>, ptr %.slot19, align 64
  %557 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %556
  store <8 x i64> %557, ptr %.slot19, align 64
  br label %direct.schedule.26

direct.schedule.26:                               ; preds = %direct.schedule.27, %direct.schedule.25
  %.state148 = load <8 x i64>, ptr %.slot19, align 64
  %558 = icmp slt <8 x i64> %.state148, splat (i64 96)
  %559 = extractelement <8 x i1> %558, i32 0
  br i1 %559, label %direct.true149, label %direct.false150

direct.schedule.27:                               ; preds = %direct.true149
  %.state151 = load <8 x i64>, ptr %.slot19, align 64
  %560 = mul <8 x i64> %.state151, splat (i64 8)
  %.spill.load152 = load <8 x i64>, ptr %.spill, align 64
  %561 = add <8 x i64> %560, %.spill.load152
  %.spill.load153 = load <8 x i64>, ptr %.spill10, align 64
  %562 = add <8 x i64> %.spill.load153, zeroinitializer
  %563 = add <8 x i64> zeroinitializer, %562
  %564 = add <8 x i64> splat (i64 769), %561
  %565 = mul <8 x i64> %563, splat (i64 1538)
  %566 = add <8 x i64> %565, %564
  %tile_snapshot.spill.load154 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 0
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 1
  %.state155 = load <8 x i64>, ptr %.slot19, align 64
  %569 = mul <8 x i64> %.state155, splat (i64 32)
  %570 = add <8 x i64> %568, %569
  %571 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %567, 0
  %572 = insertvalue { <8 x ptr>, <8 x i64> } %571, <8 x i64> %570, 1
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %572, 1
  %575 = extractelement <8 x ptr> %573, i32 0
  %576 = extractelement <8 x i64> %574, i32 0
  %577 = sub i64 %576, 0
  %578 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %579 = select i1 %578, i64 %577, i64 0
  %private.contiguous.address156 = getelementptr i8, ptr %575, i64 %579
  %private.contiguous.load157 = load <8 x float>, ptr %private.contiguous.address156, align 4
  %580 = select <8 x i1> %55, <8 x float> %private.contiguous.load157, <8 x float> zeroinitializer
  %tile_snapshot.spill.load158 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 0
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 1
  %.state159 = load <8 x i64>, ptr %.slot19, align 64
  %583 = mul <8 x i64> %.state159, splat (i64 32)
  %584 = add <8 x i64> %582, %583
  %585 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %581, 0
  %586 = insertvalue { <8 x ptr>, <8 x i64> } %585, <8 x i64> %584, 1
  %587 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %586, 1
  %589 = extractelement <8 x ptr> %587, i32 0
  %590 = extractelement <8 x i64> %588, i32 0
  %591 = sub i64 %590, 0
  %592 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %593 = select i1 %592, i64 %591, i64 0
  %private.contiguous.address160 = getelementptr i8, ptr %589, i64 %593
  %private.contiguous.load161 = load <8 x float>, ptr %private.contiguous.address160, align 4
  %594 = select <8 x i1> %55, <8 x float> %private.contiguous.load161, <8 x float> zeroinitializer
  %595 = fmul <8 x float> %580, %594
  %tile_snapshot.spill.load162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 0
  %597 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 1
  %.state163 = load <8 x i64>, ptr %.slot19, align 64
  %598 = mul <8 x i64> %.state163, splat (i64 32)
  %599 = add <8 x i64> %597, %598
  %600 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %596, 0
  %601 = insertvalue { <8 x ptr>, <8 x i64> } %600, <8 x i64> %599, 1
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %601, 1
  %604 = extractelement <8 x ptr> %602, i32 0
  %605 = extractelement <8 x i64> %603, i32 0
  %606 = sub i64 %605, 0
  %607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %608 = select i1 %607, i64 %606, i64 0
  %private.contiguous.address164 = getelementptr i8, ptr %604, i64 %608
  %private.contiguous.load165 = load <8 x float>, ptr %private.contiguous.address164, align 4
  %609 = select <8 x i1> %55, <8 x float> %private.contiguous.load165, <8 x float> zeroinitializer
  %tile_snapshot.spill.load166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 0
  %611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load166, 1
  %.state167 = load <8 x i64>, ptr %.slot19, align 64
  %612 = mul <8 x i64> %.state167, splat (i64 32)
  %613 = add <8 x i64> %611, %612
  %614 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %610, 0
  %615 = insertvalue { <8 x ptr>, <8 x i64> } %614, <8 x i64> %613, 1
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %615, 1
  %618 = extractelement <8 x ptr> %616, i32 0
  %619 = extractelement <8 x i64> %617, i32 0
  %620 = sub i64 %619, 0
  %621 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %622 = select i1 %621, i64 %620, i64 0
  %private.contiguous.address168 = getelementptr i8, ptr %618, i64 %622
  %private.contiguous.load169 = load <8 x float>, ptr %private.contiguous.address168, align 4
  %623 = select <8 x i1> %55, <8 x float> %private.contiguous.load169, <8 x float> zeroinitializer
  %624 = fmul <8 x float> %609, %623
  %625 = fadd <8 x float> %595, %624
  %626 = extractvalue { ptr, i64 } %31, 0
  %627 = extractelement <8 x i64> %566, i32 0
  %628 = sub i64 %627, 0
  %629 = mul i64 %628, 4
  %buffer.contiguous.address170 = getelementptr i8, ptr %626, i64 %629
  call void @llvm.masked.store.v8f32.p0(<8 x float> %625, ptr align 1 %buffer.contiguous.address170, <8 x i1> %55)
  %.state171 = load <8 x i64>, ptr %.slot19, align 64
  %630 = add <8 x i64> %.state171, splat (i64 1)
  %631 = load <8 x i64>, ptr %.slot19, align 64
  %632 = select <8 x i1> %55, <8 x i64> %630, <8 x i64> %631
  store <8 x i64> %632, ptr %.slot19, align 64
  br label %direct.schedule.26

direct.schedule.28:                               ; preds = %direct.false150
  %.spill.load172 = load <8 x i1>, ptr %.spill11, align 1
  %633 = and <8 x i1> %55, %.spill.load172
  %634 = xor <8 x i1> %.spill.load172, splat (i1 true)
  %635 = and <8 x i1> %55, %634
  %636 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %637 = bitcast <8 x i1> %633 to i8
  %638 = call i8 @llvm.cttz.i8(i8 %637, i1 false)
  %639 = zext i8 %638 to i32
  %640 = select i1 %636, i32 %639, i32 0
  %.spill.load173 = load <8 x i64>, ptr %.spill, align 64
  %641 = add <8 x i64> splat (i64 768), %.spill.load173
  %.spill.load174 = load <8 x i64>, ptr %.spill10, align 64
  %642 = add <8 x i64> %.spill.load174, zeroinitializer
  %643 = add <8 x i64> zeroinitializer, %642
  %644 = add <8 x i64> splat (i64 769), %641
  %645 = mul <8 x i64> %643, splat (i64 1538)
  %646 = add <8 x i64> %645, %644
  %tile_snapshot.spill.load175 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load175, 0
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load175, 1
  %649 = add <8 x i64> %648, splat (i64 3072)
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %647, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = extractelement <8 x ptr> %652, i32 0
  %655 = extractelement <8 x i64> %653, i32 %640
  %656 = zext i32 %640 to i64
  %657 = mul i64 %656, 4
  %658 = sub i64 %655, %657
  %659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %660 = select i1 %659, i64 %658, i64 0
  %private.contiguous.address176 = getelementptr i8, ptr %654, i64 %660
  %private.contiguous.load177 = load <8 x float>, ptr %private.contiguous.address176, align 4
  %661 = select <8 x i1> %633, <8 x float> %private.contiguous.load177, <8 x float> zeroinitializer
  %tile_snapshot.spill.load178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 0
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 1
  %664 = add <8 x i64> %663, splat (i64 3072)
  %665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %662, 0
  %666 = insertvalue { <8 x ptr>, <8 x i64> } %665, <8 x i64> %664, 1
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %666, 1
  %669 = extractelement <8 x ptr> %667, i32 0
  %670 = extractelement <8 x i64> %668, i32 %640
  %671 = zext i32 %640 to i64
  %672 = mul i64 %671, 4
  %673 = sub i64 %670, %672
  %674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %675 = select i1 %674, i64 %673, i64 0
  %private.contiguous.address179 = getelementptr i8, ptr %669, i64 %675
  %private.contiguous.load180 = load <8 x float>, ptr %private.contiguous.address179, align 4
  %676 = select <8 x i1> %633, <8 x float> %private.contiguous.load180, <8 x float> zeroinitializer
  %677 = fmul <8 x float> %661, %676
  %tile_snapshot.spill.load181 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill12, align 64
  %678 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 0
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 1
  %680 = add <8 x i64> %679, splat (i64 3072)
  %681 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %678, 0
  %682 = insertvalue { <8 x ptr>, <8 x i64> } %681, <8 x i64> %680, 1
  %683 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %682, 1
  %685 = extractelement <8 x ptr> %683, i32 0
  %686 = extractelement <8 x i64> %684, i32 %640
  %687 = zext i32 %640 to i64
  %688 = mul i64 %687, 4
  %689 = sub i64 %686, %688
  %690 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %691 = select i1 %690, i64 %689, i64 0
  %private.contiguous.address182 = getelementptr i8, ptr %685, i64 %691
  %private.contiguous.load183 = load <8 x float>, ptr %private.contiguous.address182, align 4
  %692 = select <8 x i1> %633, <8 x float> %private.contiguous.load183, <8 x float> zeroinitializer
  %tile_snapshot.spill.load184 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 0
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 1
  %695 = add <8 x i64> %694, splat (i64 3072)
  %696 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %693, 0
  %697 = insertvalue { <8 x ptr>, <8 x i64> } %696, <8 x i64> %695, 1
  %698 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %697, 1
  %700 = extractelement <8 x ptr> %698, i32 0
  %701 = extractelement <8 x i64> %699, i32 %640
  %702 = zext i32 %640 to i64
  %703 = mul i64 %702, 4
  %704 = sub i64 %701, %703
  %705 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %706 = select i1 %705, i64 %704, i64 0
  %private.contiguous.address185 = getelementptr i8, ptr %700, i64 %706
  %private.contiguous.load186 = load <8 x float>, ptr %private.contiguous.address185, align 4
  %707 = select <8 x i1> %633, <8 x float> %private.contiguous.load186, <8 x float> zeroinitializer
  %708 = fmul <8 x float> %692, %707
  %709 = fadd <8 x float> %677, %708
  %710 = extractvalue { ptr, i64 } %31, 0
  %711 = extractelement <8 x i64> %646, i32 %640
  %712 = zext i32 %640 to i64
  %713 = sub i64 %711, %712
  %714 = mul i64 %713, 4
  %buffer.contiguous.address187 = getelementptr i8, ptr %710, i64 %714
  call void @llvm.masked.store.v8f32.p0(<8 x float> %709, ptr align 1 %buffer.contiguous.address187, <8 x i1> %633)
  %715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %635)
  %716 = bitcast <8 x i1> %635 to i8
  %717 = call i8 @llvm.cttz.i8(i8 %716, i1 false)
  %718 = zext i8 %717 to i32
  %719 = select i1 %715, i32 %718, i32 0
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.28
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true47:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false48:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true68:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false69:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true89:                                    ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false90:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true110:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false111:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true149:                                   ; preds = %direct.schedule.26
  br label %direct.schedule.27

direct.false150:                                  ; preds = %direct.schedule.26
  br label %direct.schedule.28
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

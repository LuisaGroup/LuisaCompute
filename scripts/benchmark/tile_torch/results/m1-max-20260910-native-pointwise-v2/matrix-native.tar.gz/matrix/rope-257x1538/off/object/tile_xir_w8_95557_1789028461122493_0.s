	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	3072                            ; 0xc00
	.quad	3076                            ; 0xc04
lCPI0_8:
	.quad	3088                            ; 0xc10
	.quad	3092                            ; 0xc14
lCPI0_9:
	.quad	3080                            ; 0xc08
	.quad	3084                            ; 0xc0c
lCPI0_10:
	.quad	3096                            ; 0xc18
	.quad	3100                            ; 0xc1c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #848
	str	x0, [sp, #96]                   ; 8-byte Spill
	cbz	w3, LBB0_235
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w19, #0                         ; =0x0
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #84]               ; 8-byte Folded Spill
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #1840
	add	x27, sp, #1, lsl #12            ; =4096
	add	x27, x27, #2832
	ldp	w8, w9, [x2]
	add	x28, sp, #3824
	add	x4, sp, #720
	ldp	w10, w11, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Spill
	str	x11, [sp, #72]                  ; 8-byte Spill
Lloh0:
	adrp	x11, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x11, lCPI0_0@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Spill
Lloh2:
	adrp	x11, lCPI0_1@PAGE
Lloh3:
	ldr	q0, [x11, lCPI0_1@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Spill
Lloh4:
	adrp	x11, lCPI0_2@PAGE
Lloh5:
	ldr	q0, [x11, lCPI0_2@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
	str	w3, [sp, #92]                   ; 4-byte Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w8, w7, #1
	ldp	w11, w9, [sp, #84]              ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w9, eq
	csinc	w8, wzr, w7, eq
	cinc	w10, w6, eq
	cmp	w10, w11
	cset	w11, eq
	ands	w11, w9, w11
	csel	w9, wzr, w10, ne
	add	w10, w5, w11
	add	w19, w19, #1
	cmp	w19, w3
	b.eq	LBB0_234
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_23 Depth 2
                                        ;       Child Loop BB0_24 Depth 3
                                        ;       Child Loop BB0_26 Depth 3
                                        ;     Child Loop BB0_32 Depth 2
                                        ;     Child Loop BB0_59 Depth 2
                                        ;     Child Loop BB0_86 Depth 2
                                        ;     Child Loop BB0_113 Depth 2
                                        ;     Child Loop BB0_140 Depth 2
                                        ;     Child Loop BB0_168 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
	stp	w9, w10, [sp, #108]             ; 8-byte Folded Spill
	mov	x13, x8
	ubfiz	x8, x8, #5, #32
	ldr	x12, [sp, #72]                  ; 8-byte Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	ccmp	x8, x12, #2, hi
	csel	x8, x10, xzr, ls
	cmp	x8, #32
	str	w19, [sp, #116]                 ; 4-byte Spill
	str	x13, [sp, #120]                 ; 8-byte Spill
	b.lo	LBB0_21
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #96]                   ; 8-byte Reload
	ldr	x27, [x8]
	ldr	x24, [x8, #16]
	ldr	x25, [x8, #32]
	ldr	x21, [x8, #48]
	ubfiz	w23, w13, #2, #27
	mov	w26, #6152                      ; =0x1808
	umull	x19, w23, w26
	umaddl	x22, w23, w26, x27
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #1840
	mov	x1, x22
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	str	x19, [sp, #240]                 ; 8-byte Spill
	add	x8, x19, #3072
	str	x8, [sp, #152]                  ; 8-byte Spill
	ldr	s0, [x27, x8]
	str	q0, [sp, #192]                  ; 16-byte Spill
	str	q0, [sp, #13104]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2832
	add	x1, x22, #3076
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	w8, #6148                       ; =0x1804
	umaddl	x22, w23, w26, x8
	ldr	s0, [x27, x22]
	str	q0, [sp, #176]                  ; 16-byte Spill
	str	q0, [sp, #10000]
	mov	w28, #3076                      ; =0xc04
	umull	x19, w23, w28
	umaddl	x1, w23, w28, x24
	add	x0, sp, #3824
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x19, x19, #3072
	str	x24, [sp, #208]                 ; 8-byte Spill
	ldr	s0, [x24, x19]
	str	q0, [sp, #160]                  ; 16-byte Spill
	str	q0, [sp, #6896]
	umaddl	x1, w23, w28, x25
	add	x28, sp, #3824
	add	x0, sp, #720
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x12, sp, #720
	add	x11, sp, #1, lsl #12            ; =4096
	add	x11, x11, #2832
	mov	x8, #0                          ; =0x0
	str	x25, [sp, #224]                 ; 8-byte Spill
	ldr	s0, [x25, x19]
	str	q0, [sp, #3792]
	umaddl	x9, w23, w26, x21
LBB0_5:                                 ; %direct.true110.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x20, x8
	ldp	q1, q2, [x10]
	add	x10, x28, x8
	ldp	q3, q4, [x10]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x10, x11, x8
	ldp	q3, q4, [x10]
	add	x10, x12, x8
	ldp	q5, q6, [x10]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fsub.4s	v1, v1, v3
	fsub.4s	v2, v2, v4
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_5
; %bb.6:                                ; %direct.false111.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldp	q16, q7, [sp, #176]             ; 32-byte Folded Reload
	ldr	q17, [sp, #160]                 ; 16-byte Reload
	fmul.4s	v1, v7, v17
	fmul.4s	v2, v16, v0
	fsub.4s	v1, v1, v2
	ldr	x9, [sp, #152]                  ; 8-byte Reload
	str	s1, [x21, x9]
	ldr	x9, [sp, #240]                  ; 8-byte Reload
	add	x9, x21, x9
	add	x9, x9, #3076
LBB0_7:                                 ; %direct.true149.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x20, x8
	ldp	q1, q2, [x10]
	add	x10, x12, x8
	ldp	q3, q4, [x10]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x10, x11, x8
	ldp	q3, q4, [x10]
	add	x10, x28, x8
	ldp	q5, q6, [x10]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v1, v3
	fadd.4s	v2, v2, v4
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_7
; %bb.8:                                ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmul.4s	v0, v7, v0
	fmul.4s	v1, v16, v17
	fadd.4s	v0, v1, v0
	str	s0, [x21, x22]
	orr	w19, w23, #0x1
	mov	w20, #6152                      ; =0x1808
	umull	x25, w19, w20
	umaddl	x22, w19, w20, x27
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #1840
	mov	x1, x22
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x25, x25, #3072
	ldr	s0, [x27, x25]
	str	q0, [sp, #192]                  ; 16-byte Spill
	str	q0, [sp, #13104]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2832
	add	x1, x22, #3076
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	w8, #6148                       ; =0x1804
	umaddl	x22, w19, w20, x8
	ldr	s0, [x27, x22]
	str	q0, [sp, #176]                  ; 16-byte Spill
	str	q0, [sp, #10000]
	mov	w28, #3076                      ; =0xc04
	umull	x26, w19, w28
	ldr	x24, [sp, #208]                 ; 8-byte Reload
	umaddl	x1, w19, w28, x24
	add	x0, sp, #3824
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x26, x26, #3072
	ldr	s0, [x24, x26]
	str	q0, [sp, #160]                  ; 16-byte Spill
	str	q0, [sp, #6896]
	ldr	x24, [sp, #224]                 ; 8-byte Reload
	umaddl	x1, w19, w28, x24
	add	x28, sp, #3824
	add	x0, sp, #720
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x13, sp, #720
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #2832
	mov	x8, #0                          ; =0x0
	ldr	s0, [x24, x26]
	str	q0, [sp, #3792]
	umaddl	x9, w19, w20, x21
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #1840
LBB0_9:                                 ; %direct.true110.i26.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x11, x8
	ldp	q1, q2, [x10]
	add	x10, x28, x8
	ldp	q3, q4, [x10]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x10, x12, x8
	ldp	q3, q4, [x10]
	add	x10, x13, x8
	ldp	q5, q6, [x10]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fsub.4s	v1, v1, v3
	fsub.4s	v2, v2, v4
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_9
; %bb.10:                               ; %direct.false111.i37.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldp	q16, q7, [sp, #176]             ; 32-byte Folded Reload
	ldr	q17, [sp, #160]                 ; 16-byte Reload
	fmul.4s	v1, v7, v17
	fmul.4s	v2, v16, v0
	fsub.4s	v1, v1, v2
	str	s1, [x21, x25]
	ldr	x9, [sp, #240]                  ; 8-byte Reload
	add	x9, x21, x9
	mov	w10, #9228                      ; =0x240c
	add	x9, x9, x10
LBB0_11:                                ; %direct.true149.i40.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x11, x8
	ldp	q1, q2, [x10]
	add	x10, x13, x8
	ldp	q3, q4, [x10]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x10, x12, x8
	ldp	q3, q4, [x10]
	add	x10, x28, x8
	ldp	q5, q6, [x10]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v1, v3
	fadd.4s	v2, v2, v4
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_11
; %bb.12:                               ; %llm_rows.full_packet.exit53.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmul.4s	v0, v7, v0
	fmul.4s	v1, v16, v17
	fadd.4s	v0, v1, v0
	str	s0, [x21, x22]
	orr	w19, w23, #0x2
	mov	w20, #6152                      ; =0x1808
	umull	x25, w19, w20
	umaddl	x22, w19, w20, x27
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #1840
	mov	x1, x22
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x25, x25, #3072
	ldr	s0, [x27, x25]
	str	q0, [sp, #192]                  ; 16-byte Spill
	str	q0, [sp, #13104]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2832
	add	x1, x22, #3076
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	w8, #6148                       ; =0x1804
	umaddl	x22, w19, w20, x8
	ldr	s0, [x27, x22]
	str	q0, [sp, #176]                  ; 16-byte Spill
	str	q0, [sp, #10000]
	mov	w28, #3076                      ; =0xc04
	umull	x26, w19, w28
	ldr	x24, [sp, #208]                 ; 8-byte Reload
	umaddl	x1, w19, w28, x24
	add	x0, sp, #3824
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x26, x26, #3072
	ldr	s0, [x24, x26]
	str	q0, [sp, #160]                  ; 16-byte Spill
	str	q0, [sp, #6896]
	ldr	x24, [sp, #224]                 ; 8-byte Reload
	umaddl	x1, w19, w28, x24
	add	x28, sp, #3824
	add	x0, sp, #720
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x13, sp, #720
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #2832
	mov	x8, #0                          ; =0x0
	ldr	s0, [x24, x26]
	str	q0, [sp, #3792]
	umaddl	x9, w19, w20, x21
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #1840
LBB0_13:                                ; %direct.true110.i77.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x11, x8
	ldp	q1, q2, [x10]
	add	x10, x28, x8
	ldp	q3, q4, [x10]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x10, x12, x8
	ldp	q3, q4, [x10]
	add	x10, x13, x8
	ldp	q5, q6, [x10]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fsub.4s	v1, v1, v3
	fsub.4s	v2, v2, v4
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_13
; %bb.14:                               ; %direct.false111.i88.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldp	q16, q7, [sp, #176]             ; 32-byte Folded Reload
	ldr	q17, [sp, #160]                 ; 16-byte Reload
	fmul.4s	v1, v7, v17
	fmul.4s	v2, v16, v0
	fsub.4s	v1, v1, v2
	str	s1, [x21, x25]
	ldr	x9, [sp, #240]                  ; 8-byte Reload
	add	x9, x21, x9
	mov	w10, #15380                     ; =0x3c14
	add	x9, x9, x10
LBB0_15:                                ; %direct.true149.i91.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x11, x8
	ldp	q1, q2, [x10]
	add	x10, x13, x8
	ldp	q3, q4, [x10]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x10, x12, x8
	ldp	q3, q4, [x10]
	add	x10, x28, x8
	ldp	q5, q6, [x10]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v1, v3
	fadd.4s	v2, v2, v4
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_15
; %bb.16:                               ; %llm_rows.full_packet.exit104.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmul.4s	v0, v7, v0
	fmul.4s	v1, v16, v17
	fadd.4s	v0, v1, v0
	str	s0, [x21, x22]
	orr	w19, w23, #0x3
	mov	w20, #6152                      ; =0x1808
	umull	x23, w19, w20
	umaddl	x22, w19, w20, x27
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #1840
	mov	x1, x22
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x23, x23, #3072
	ldr	s0, [x27, x23]
	str	q0, [sp, #192]                  ; 16-byte Spill
	str	q0, [sp, #13104]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2832
	add	x1, x22, #3076
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	w8, #6148                       ; =0x1804
	umaddl	x22, w19, w20, x8
	ldr	s0, [x27, x22]
	str	q0, [sp, #176]                  ; 16-byte Spill
	str	q0, [sp, #10000]
	mov	w26, #3076                      ; =0xc04
	umull	x25, w19, w26
	ldr	x24, [sp, #208]                 ; 8-byte Reload
	umaddl	x1, w19, w26, x24
	add	x0, sp, #3824
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x25, x25, #3072
	ldr	s0, [x24, x25]
	str	q0, [sp, #208]                  ; 16-byte Spill
	str	q0, [sp, #6896]
	ldr	x24, [sp, #224]                 ; 8-byte Reload
	umaddl	x1, w19, w26, x24
	add	x0, sp, #720
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x4, sp, #720
	add	x27, sp, #1, lsl #12            ; =4096
	add	x27, x27, #2832
	mov	x8, #0                          ; =0x0
	ldr	s0, [x24, x25]
	str	q0, [sp, #3792]
	umaddl	x9, w19, w20, x21
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #1840
LBB0_17:                                ; %direct.true110.i128.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x20, x8
	ldp	q1, q2, [x10]
	add	x10, x28, x8
	ldp	q3, q4, [x10]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x10, x27, x8
	ldp	q3, q4, [x10]
	add	x10, x4, x8
	ldp	q5, q6, [x10]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fsub.4s	v1, v1, v3
	fsub.4s	v2, v2, v4
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_17
; %bb.18:                               ; %direct.false111.i139.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	ldp	q7, q17, [sp, #192]             ; 32-byte Folded Reload
	fmul.4s	v1, v7, v17
	ldr	q16, [sp, #176]                 ; 16-byte Reload
	fmul.4s	v2, v16, v0
	fsub.4s	v1, v1, v2
	str	s1, [x21, x23]
	ldr	x9, [sp, #240]                  ; 8-byte Reload
	add	x9, x21, x9
	mov	w10, #21532                     ; =0x541c
	add	x9, x9, x10
	ldp	w6, w5, [sp, #108]              ; 8-byte Folded Reload
	ldr	x7, [sp, #120]                  ; 8-byte Reload
	ldr	w3, [sp, #92]                   ; 4-byte Reload
	ldr	w19, [sp, #116]                 ; 4-byte Reload
LBB0_19:                                ; %direct.true149.i142.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x20, x8
	ldp	q1, q2, [x10]
	add	x10, x4, x8
	ldp	q3, q4, [x10]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x10, x27, x8
	ldp	q3, q4, [x10]
	add	x10, x28, x8
	ldp	q5, q6, [x10]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v1, v3
	fadd.4s	v2, v2, v4
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_19
; %bb.20:                               ; %llm_rows.full_packet.exit155.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmul.4s	v0, v7, v0
	fmul.4s	v1, v16, v17
	fadd.4s	v0, v1, v0
	str	s0, [x21, x22]
	b	LBB0_2
LBB0_21:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	x8, [sp, #64]                   ; 8-byte Spill
	lsr	x8, x8, #3
	str	x8, [sp, #192]                  ; 8-byte Spill
	cbz	x8, LBB0_28
; %bb.22:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w24, #0                         ; =0x0
	ldr	x8, [sp, #96]                   ; 8-byte Reload
	ldr	x9, [x8]
	str	x9, [sp, #176]                  ; 8-byte Spill
	ldr	x10, [x8, #16]
	ldr	x9, [x8, #32]
	stp	x9, x10, [sp, #152]             ; 16-byte Folded Spill
	ldr	x10, [x8, #48]
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	lsl	w8, w8, #2
	add	x9, x10, #3076
	str	x9, [sp, #128]                  ; 8-byte Spill
	str	w8, [sp, #140]                  ; 4-byte Spill
	mov	x25, x8
	str	x10, [sp, #144]                 ; 8-byte Spill
LBB0_23:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_24 Depth 3
                                        ;       Child Loop BB0_26 Depth 3
	and	x8, x25, #0x1fffffff
	mov	w20, #6152                      ; =0x1808
	ldr	x9, [sp, #128]                  ; 8-byte Reload
	umaddl	x23, w8, w20, x9
	umaddl	x26, w8, w20, x10
	ldr	w8, [sp, #140]                  ; 4-byte Reload
	add	w8, w24, w8
	and	w28, w8, #0x1fffffff
	umull	x19, w28, w20
	ldr	x27, [sp, #176]                 ; 8-byte Reload
	umaddl	x22, w28, w20, x27
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #1840
	mov	x1, x22
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x19, x19, #3072
	ldr	s0, [x27, x19]
	str	q0, [sp, #240]                  ; 16-byte Spill
	str	q0, [sp, #13104]
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2832
	add	x1, x22, #3076
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	w8, #6148                       ; =0x1804
	umaddl	x22, w28, w20, x8
	ldr	s0, [x27, x22]
	str	q0, [sp, #224]                  ; 16-byte Spill
	str	q0, [sp, #10000]
	mov	w27, #3076                      ; =0xc04
	umull	x20, w28, w27
	ldr	x21, [sp, #160]                 ; 8-byte Reload
	umaddl	x1, w28, w27, x21
	add	x0, sp, #3824
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x20, x20, #3072
	ldr	s0, [x21, x20]
	str	q0, [sp, #208]                  ; 16-byte Spill
	str	q0, [sp, #6896]
	ldr	x21, [sp, #152]                 ; 8-byte Reload
	umaddl	x1, w28, w27, x21
	add	x28, sp, #3824
	add	x0, sp, #720
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x4, sp, #720
	add	x27, sp, #1, lsl #12            ; =4096
	add	x27, x27, #2832
	mov	x8, #0                          ; =0x0
	ldr	s0, [x21, x20]
	add	x20, sp, #2, lsl #12            ; =8192
	add	x20, x20, #1840
	str	q0, [sp, #3792]
LBB0_24:                                ; %direct.true110.i179.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x20, x8
	ldp	q1, q2, [x9]
	add	x9, x28, x8
	ldp	q3, q4, [x9]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x9, x27, x8
	ldp	q3, q4, [x9]
	add	x9, x4, x8
	ldp	q5, q6, [x9]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fsub.4s	v1, v1, v3
	fsub.4s	v2, v2, v4
	add	x9, x26, x8
	stp	q1, q2, [x9]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_24
; %bb.25:                               ; %direct.false111.i190.i
                                        ;   in Loop: Header=BB0_23 Depth=2
	mov	x8, #0                          ; =0x0
	ldp	q16, q7, [sp, #224]             ; 32-byte Folded Reload
	ldr	q17, [sp, #208]                 ; 16-byte Reload
	fmul.4s	v1, v7, v17
	fmul.4s	v2, v16, v0
	fsub.4s	v1, v1, v2
	ldr	x10, [sp, #144]                 ; 8-byte Reload
	str	s1, [x10, x19]
LBB0_26:                                ; %direct.true149.i193.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x20, x8
	ldp	q1, q2, [x9]
	add	x9, x4, x8
	ldp	q3, q4, [x9]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x9, x27, x8
	ldp	q3, q4, [x9]
	add	x9, x28, x8
	ldp	q5, q6, [x9]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v1, v3
	fadd.4s	v2, v2, v4
	add	x9, x23, x8
	stp	q1, q2, [x9]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_26
; %bb.27:                               ; %llm_rows.full_packet.exit206.i
                                        ;   in Loop: Header=BB0_23 Depth=2
	fmul.4s	v0, v7, v0
	fmul.4s	v1, v16, v17
	fadd.4s	v0, v1, v0
	str	s0, [x10, x22]
	add	w24, w24, #1
	add	w25, w25, #1
	ldr	x8, [sp, #192]                  ; 8-byte Reload
	cmp	w24, w8
	b.ne	LBB0_23
LBB0_28:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Reload
	and	w8, w8, #0x7
	ldr	w3, [sp, #92]                   ; 4-byte Reload
	ldp	w5, w19, [sp, #112]             ; 8-byte Folded Reload
	ldr	w6, [sp, #108]                  ; 4-byte Reload
	ldr	x7, [sp, #120]                  ; 8-byte Reload
	cbz	w8, LBB0_2
; %bb.29:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v1, w8
	ldp	q0, q2, [sp, #32]               ; 32-byte Folded Reload
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB0_2
; %bb.30:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x11, [sp, #96]                  ; 8-byte Reload
	ldr	x15, [x11]
	ldr	x13, [x11, #16]
	ldr	x10, [x11, #32]
	ubfiz	w8, w7, #2, #27
	ldr	x12, [sp, #192]                 ; 8-byte Reload
	orr	w8, w8, w12
	dup.4s	v2, w8
	ldr	x8, [x11, #48]
	and.16b	v4, v1, v2
	and.16b	v2, v0, v2
	ushll2.2d	v29, v2, #0
	ushll2.2d	v31, v4, #0
	ushll.2d	v30, v2, #0
	ushll.2d	v9, v4, #0
	fmov	x14, d9
	mov	w11, #6152                      ; =0x1808
	umaddl	x11, w14, w11, x15
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v2, v3, v2
	addv.8h	h2, v2
	fmov	w12, s2
	b	LBB0_32
LBB0_31:                                ; %else104
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x16, x20, x9
	stp	q4, q5, [x16]
	add	x9, x9, #32
	cmp	x9, #3072
	b.eq	LBB0_48
LBB0_32:                                ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x11, x9
	add	x0, x20, x9
	ldr	q4, [x0]
	tbnz	w12, #0, LBB0_40
; %bb.33:                               ; %else
                                        ;   in Loop: Header=BB0_32 Depth=2
	and	w17, w12, #0xff
	tbnz	w17, #1, LBB0_41
LBB0_34:                                ; %else86
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w17, #2, LBB0_42
LBB0_35:                                ; %else89
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w17, #3, LBB0_43
LBB0_36:                                ; %else92
                                        ;   in Loop: Header=BB0_32 Depth=2
	ldr	q5, [x0, #16]
	tbnz	w17, #4, LBB0_44
LBB0_37:                                ; %else95
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w17, #5, LBB0_45
LBB0_38:                                ; %else98
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w17, #6, LBB0_46
LBB0_39:                                ; %else101
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbz	w17, #7, LBB0_31
	b	LBB0_47
LBB0_40:                                ; %cond.load
                                        ;   in Loop: Header=BB0_32 Depth=2
	ld1.s	{ v4 }[0], [x16]
	and	w17, w12, #0xff
	tbz	w17, #1, LBB0_34
LBB0_41:                                ; %cond.load85
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x1, x16, #4
	ld1.s	{ v4 }[1], [x1]
	tbz	w17, #2, LBB0_35
LBB0_42:                                ; %cond.load88
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x1, x16, #8
	ld1.s	{ v4 }[2], [x1]
	tbz	w17, #3, LBB0_36
LBB0_43:                                ; %cond.load91
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x1, x16, #12
	ld1.s	{ v4 }[3], [x1]
	ldr	q5, [x0, #16]
	tbz	w17, #4, LBB0_37
LBB0_44:                                ; %cond.load94
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x0, x16, #16
	ld1.s	{ v5 }[0], [x0]
	tbz	w17, #5, LBB0_38
LBB0_45:                                ; %cond.load97
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x0, x16, #20
	ld1.s	{ v5 }[1], [x0]
	tbz	w17, #6, LBB0_39
LBB0_46:                                ; %cond.load100
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x0, x16, #24
	ld1.s	{ v5 }[2], [x0]
	tbz	w17, #7, LBB0_31
LBB0_47:                                ; %cond.load103
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x16, x16, #28
	ld1.s	{ v5 }[3], [x16]
	b	LBB0_31
LBB0_48:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	xtn.8b	v4, v3
	sshll.2d	v5, v1, #0
	sshll.2d	v7, v0, #0
	sshll2.2d	v16, v1, #0
	sshll2.2d	v17, v0, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q3, [x9, lCPI0_6@PAGEOFF]
	and.16b	v19, v5, v3
	movi.8b	v3, #1
	and.8b	v3, v4, v3
	umov.b	w12, v3[0]
	movi.2d	v3, #0000000000000000
	mov.b	v3[0], v4[0]
	umaxv.8b	b6, v3
	fmov	w17, s6
	rbit	w9, w12
	clz	w9, w9
	tst	w17, #0x1
	csel	w9, w9, wzr, ne
	mov	w11, #768                       ; =0x300
	dup.2d	v23, x11
	mov	w11, #1538                      ; =0x602
	dup.2s	v18, w11
	orr.16b	v10, v19, v23
	xtn.2s	v24, v9
	mov.16b	v20, v10
	movi.2d	v6, #0000000000000000
	mov.b	v6[0], v4[0]
	umlal.2d	v20, v24, v18
	ushll.2d	v4, v6, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	str	q20, [sp, #240]                 ; 16-byte Spill
	and.16b	v4, v4, v20
	movi.2d	v6, #0000000000000000
	stp	q6, q6, [sp, #608]
	stp	q4, q6, [sp, #576]
	ubfiz	x11, x9, #3, #3
	add	x16, sp, #576
	ldr	x16, [x16, x11]
	sub	x16, x16, x9
	add	x16, x15, x16, lsl #2
Lloh8:
	adrp	x0, lCPI0_7@PAGE
Lloh9:
	ldr	q4, [x0, lCPI0_7@PAGEOFF]
	mov	w0, #3072                       ; =0xc00
	dup.2d	v6, x0
	bif.16b	v4, v6, v5
Lloh10:
	adrp	x0, lCPI0_8@PAGE
Lloh11:
	ldr	q5, [x0, lCPI0_8@PAGEOFF]
	bif.16b	v5, v6, v7
Lloh12:
	adrp	x0, lCPI0_9@PAGE
Lloh13:
	ldr	q20, [x0, lCPI0_9@PAGEOFF]
	bif.16b	v20, v6, v16
Lloh14:
	adrp	x0, lCPI0_10@PAGE
Lloh15:
	ldr	q21, [x0, lCPI0_10@PAGEOFF]
	bit.16b	v6, v21, v17
	stp	q5, q6, [sp, #672]
	stp	q4, q20, [sp, #640]
	add	x0, sp, #640
	ldr	x11, [x0, x11]
	sub	x11, x11, w9, uxtw #2
	tst	w12, #0x1
	csel	x11, xzr, x11, eq
	add	x0, x20, x11
	ldp	q5, q4, [x0]
	tbnz	w17, #0, LBB0_193
; %bb.49:                               ; %else108
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w12, #1, LBB0_194
LBB0_50:                                ; %else111
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w12, #2, LBB0_195
LBB0_51:                                ; %else114
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w12, #3, LBB0_196
LBB0_52:                                ; %else117
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w12, #4, LBB0_197
LBB0_53:                                ; %else120
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w12, #5, LBB0_198
LBB0_54:                                ; %else123
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w12, #6, LBB0_199
LBB0_55:                                ; %else126
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w12, #7, LBB0_57
LBB0_56:                                ; %cond.load128
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, x16, #28
	ld1.s	{ v4 }[3], [x12]
LBB0_57:                                ; %else129
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x17, #0                         ; =0x0
Lloh16:
	adrp	x12, lCPI0_3@PAGE
Lloh17:
	ldr	q6, [x12, lCPI0_3@PAGEOFF]
	and.16b	v20, v17, v6
Lloh18:
	adrp	x12, lCPI0_4@PAGE
Lloh19:
	ldr	q6, [x12, lCPI0_4@PAGEOFF]
	and.16b	v21, v16, v6
Lloh20:
	adrp	x12, lCPI0_5@PAGE
Lloh21:
	ldr	q6, [x12, lCPI0_5@PAGEOFF]
	and.16b	v22, v7, v6
	orr.16b	v12, v22, v23
	orr.16b	v11, v21, v23
	orr.16b	v13, v20, v23
	umull.2d	v26, v24, v18
	xtn.2s	v6, v31
	umull.2d	v27, v6, v18
	xtn.2s	v7, v30
	umull.2d	v28, v7, v18
	xtn.2s	v16, v29
	umull.2d	v14, v16, v18
	mov.16b	v17, v13
	umlal.2d	v17, v16, v18
	mov.16b	v16, v11
	umlal.2d	v16, v6, v18
	stp	q16, q17, [sp, #208]            ; 32-byte Folded Spill
	mov.16b	v6, v12
	umlal.2d	v6, v7, v18
	str	q6, [sp, #192]                  ; 16-byte Spill
	add	x12, x20, x11
	stp	q5, q4, [x12]
	fmov	x12, d26
	ushll2.2d	v6, v0, #0
	mov	w16, #1                         ; =0x1
	dup.2d	v18, x16
	and.16b	v7, v6, v18
	ushll2.2d	v6, v1, #0
	and.16b	v16, v6, v18
	ushll.2d	v6, v0, #0
	and.16b	v17, v6, v18
	ushll.2d	v6, v1, #0
	and.16b	v18, v6, v18
	lsl	x12, x12, #2
	add	x16, x15, x12
	movi.2d	v15, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	b	LBB0_59
LBB0_58:                                ; %else154
                                        ;   in Loop: Header=BB0_59 Depth=2
	add	x17, x27, x17
	stp	q25, q6, [x17]
	add.2d	v8, v8, v16
	add.2d	v23, v23, v17
	add.2d	v24, v24, v7
	add.2d	v15, v15, v18
	fmov	x17, d15
	cmp	x17, #96
	b.ge	LBB0_75
LBB0_59:                                ; %direct.true47.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w1, s2
	lsl	x17, x17, #5
	add	x0, x16, x17
	add	x0, x0, #3076
	add	x2, x27, x17
	ldp	q25, q6, [x2]
	tbnz	w1, #0, LBB0_67
; %bb.60:                               ; %else133
                                        ;   in Loop: Header=BB0_59 Depth=2
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB0_68
LBB0_61:                                ; %else136
                                        ;   in Loop: Header=BB0_59 Depth=2
	tbnz	w1, #2, LBB0_69
LBB0_62:                                ; %else139
                                        ;   in Loop: Header=BB0_59 Depth=2
	tbnz	w1, #3, LBB0_70
LBB0_63:                                ; %else142
                                        ;   in Loop: Header=BB0_59 Depth=2
	tbnz	w1, #4, LBB0_71
LBB0_64:                                ; %else145
                                        ;   in Loop: Header=BB0_59 Depth=2
	tbnz	w1, #5, LBB0_72
LBB0_65:                                ; %else148
                                        ;   in Loop: Header=BB0_59 Depth=2
	tbnz	w1, #6, LBB0_73
LBB0_66:                                ; %else151
                                        ;   in Loop: Header=BB0_59 Depth=2
	tbz	w1, #7, LBB0_58
	b	LBB0_74
LBB0_67:                                ; %cond.load132
                                        ;   in Loop: Header=BB0_59 Depth=2
	ld1.s	{ v25 }[0], [x0]
	and	w1, w1, #0xff
	tbz	w1, #1, LBB0_61
LBB0_68:                                ; %cond.load135
                                        ;   in Loop: Header=BB0_59 Depth=2
	add	x2, x0, #4
	ld1.s	{ v25 }[1], [x2]
	tbz	w1, #2, LBB0_62
LBB0_69:                                ; %cond.load138
                                        ;   in Loop: Header=BB0_59 Depth=2
	add	x2, x0, #8
	ld1.s	{ v25 }[2], [x2]
	tbz	w1, #3, LBB0_63
LBB0_70:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_59 Depth=2
	add	x2, x0, #12
	ld1.s	{ v25 }[3], [x2]
	tbz	w1, #4, LBB0_64
LBB0_71:                                ; %cond.load144
                                        ;   in Loop: Header=BB0_59 Depth=2
	add	x2, x0, #16
	ld1.s	{ v6 }[0], [x2]
	tbz	w1, #5, LBB0_65
LBB0_72:                                ; %cond.load147
                                        ;   in Loop: Header=BB0_59 Depth=2
	add	x2, x0, #20
	ld1.s	{ v6 }[1], [x2]
	tbz	w1, #6, LBB0_66
LBB0_73:                                ; %cond.load150
                                        ;   in Loop: Header=BB0_59 Depth=2
	add	x2, x0, #24
	ld1.s	{ v6 }[2], [x2]
	tbz	w1, #7, LBB0_58
LBB0_74:                                ; %cond.load153
                                        ;   in Loop: Header=BB0_59 Depth=2
	add	x0, x0, #28
	ld1.s	{ v6 }[3], [x0]
	b	LBB0_58
LBB0_75:                                ; %direct.false48.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v6, v19, v26
	add.2d	v21, v21, v27
	add.2d	v22, v22, v28
	add.2d	v19, v20, v14
	mov	w16, #1537                      ; =0x601
	dup.2d	v23, x16
	add.2d	v19, v19, v23
	add.2d	v20, v22, v23
	add.2d	v21, v21, v23
	add.2d	v22, v6, v23
	mov	b6, v3[0]
	mov.b	v6[4], v3[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v6, v6, v22
	mov	b23, v3[2]
	mov.b	v23[4], v3[3]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	mov	b24, v3[4]
	mov.b	v24[4], v3[5]
	and.16b	v23, v23, v21
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	and.16b	v24, v24, v20
	mov	b25, v3[6]
	mov.b	v25[4], v3[7]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	and.16b	v25, v25, v19
Lloh22:
	adrp	x16, lCPI0_11@PAGE
Lloh23:
	ldr	d26, [x16, lCPI0_11@PAGEOFF]
	shl.8b	v27, v3, #7
	cmlt.8b	v27, v27, #0
	and.8b	v26, v27, v26
	addv.8b	b27, v26
	stp	q24, q25, [sp, #528]
	stp	q6, q23, [sp, #496]
	and	x16, x9, #0x7
	add	x17, sp, #496
	ldr	x17, [x17, x16, lsl #3]
	fmov	w16, s27
	sub	x17, x17, x9
	add	x15, x15, x17, lsl #2
	add	x17, x27, x11
	ldp	q28, q26, [x17]
	tbnz	w16, #0, LBB0_200
; %bb.76:                               ; %else158
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #1, LBB0_201
LBB0_77:                                ; %else161
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #2, LBB0_202
LBB0_78:                                ; %else164
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #3, LBB0_203
LBB0_79:                                ; %else167
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #4, LBB0_204
LBB0_80:                                ; %else170
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #5, LBB0_205
LBB0_81:                                ; %else173
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #6, LBB0_206
LBB0_82:                                ; %else176
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w16, #7, LBB0_84
LBB0_83:                                ; %cond.load178
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x15, #28
	ld1.s	{ v26 }[3], [x15]
LBB0_84:                                ; %else179
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x15, #0                         ; =0x0
	add	x16, x27, x11
	stp	q28, q26, [x16]
	mov	w16, #3076                      ; =0xc04
	umaddl	x14, w14, w16, x13
	movi.2d	v14, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v8, #0000000000000000
	b	LBB0_86
LBB0_85:                                ; %else204
                                        ;   in Loop: Header=BB0_86 Depth=2
	add	x15, x28, x15
	stp	q6, q25, [x15]
	add.2d	v23, v23, v16
	add.2d	v24, v24, v17
	add.2d	v8, v8, v7
	add.2d	v14, v14, v18
	fmov	x15, d14
	cmp	x15, #96
	b.ge	LBB0_102
LBB0_86:                                ; %direct.true68.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w17, s2
	lsl	x15, x15, #5
	add	x16, x14, x15
	add	x0, x28, x15
	ldp	q6, q25, [x0]
	tbnz	w17, #0, LBB0_94
; %bb.87:                               ; %else183
                                        ;   in Loop: Header=BB0_86 Depth=2
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB0_95
LBB0_88:                                ; %else186
                                        ;   in Loop: Header=BB0_86 Depth=2
	tbnz	w17, #2, LBB0_96
LBB0_89:                                ; %else189
                                        ;   in Loop: Header=BB0_86 Depth=2
	tbnz	w17, #3, LBB0_97
LBB0_90:                                ; %else192
                                        ;   in Loop: Header=BB0_86 Depth=2
	tbnz	w17, #4, LBB0_98
LBB0_91:                                ; %else195
                                        ;   in Loop: Header=BB0_86 Depth=2
	tbnz	w17, #5, LBB0_99
LBB0_92:                                ; %else198
                                        ;   in Loop: Header=BB0_86 Depth=2
	tbnz	w17, #6, LBB0_100
LBB0_93:                                ; %else201
                                        ;   in Loop: Header=BB0_86 Depth=2
	tbz	w17, #7, LBB0_85
	b	LBB0_101
LBB0_94:                                ; %cond.load182
                                        ;   in Loop: Header=BB0_86 Depth=2
	ld1.s	{ v6 }[0], [x16]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB0_88
LBB0_95:                                ; %cond.load185
                                        ;   in Loop: Header=BB0_86 Depth=2
	add	x0, x16, #4
	ld1.s	{ v6 }[1], [x0]
	tbz	w17, #2, LBB0_89
LBB0_96:                                ; %cond.load188
                                        ;   in Loop: Header=BB0_86 Depth=2
	add	x0, x16, #8
	ld1.s	{ v6 }[2], [x0]
	tbz	w17, #3, LBB0_90
LBB0_97:                                ; %cond.load191
                                        ;   in Loop: Header=BB0_86 Depth=2
	add	x0, x16, #12
	ld1.s	{ v6 }[3], [x0]
	tbz	w17, #4, LBB0_91
LBB0_98:                                ; %cond.load194
                                        ;   in Loop: Header=BB0_86 Depth=2
	add	x0, x16, #16
	ld1.s	{ v25 }[0], [x0]
	tbz	w17, #5, LBB0_92
LBB0_99:                                ; %cond.load197
                                        ;   in Loop: Header=BB0_86 Depth=2
	add	x0, x16, #20
	ld1.s	{ v25 }[1], [x0]
	tbz	w17, #6, LBB0_93
LBB0_100:                               ; %cond.load200
                                        ;   in Loop: Header=BB0_86 Depth=2
	add	x0, x16, #24
	ld1.s	{ v25 }[2], [x0]
	tbz	w17, #7, LBB0_85
LBB0_101:                               ; %cond.load203
                                        ;   in Loop: Header=BB0_86 Depth=2
	add	x16, x16, #28
	ld1.s	{ v25 }[3], [x16]
	b	LBB0_85
LBB0_102:                               ; %direct.false69.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x14, v9[1]
	mov	w16, #769                       ; =0x301
	mul	x14, x14, x16
	fmov	x15, d9
	mul	x15, x15, x16
	fmov	d9, x15
	mov.d	v9[1], x14
	mov.d	x14, v31[1]
	mul	x14, x14, x16
	fmov	x15, d31
	mul	x15, x15, x16
	fmov	d6, x15
	mov.d	v6[1], x14
	mov.d	x14, v30[1]
	mul	x14, x14, x16
	fmov	x15, d30
	mul	x15, x15, x16
	fmov	d23, x15
	mov.d	v23[1], x14
	mov.d	x14, v29[1]
	mul	x14, x14, x16
	fmov	x15, d29
	mul	x15, x15, x16
	fmov	d24, x15
	mov.d	v24[1], x14
	add.2d	v24, v24, v13
	add.2d	v23, v23, v12
	add.2d	v6, v6, v11
	add.2d	v25, v9, v10
	mov	b29, v3[0]
	mov.b	v29[4], v3[1]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v25, v29, v25
	mov	b29, v3[2]
	mov.b	v29[4], v3[3]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v6, v29, v6
	mov	b29, v3[4]
	mov.b	v29[4], v3[5]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v23, v29, v23
	mov	b29, v3[6]
	mov.b	v29[4], v3[7]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v24, v29, v24
	fmov	w15, s27
	stp	q23, q24, [sp, #448]
	stp	q25, q6, [sp, #416]
	and	x14, x9, #0x7
	add	x16, sp, #416
	ldr	x14, [x16, x14, lsl #3]
	sub	x14, x14, x9
	lsl	x14, x14, #2
	add	x13, x13, x14
	add	x16, x28, x11
	ldp	q30, q29, [x16]
	tbnz	w15, #0, LBB0_207
; %bb.103:                              ; %else208
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #1, LBB0_208
LBB0_104:                               ; %else211
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #2, LBB0_209
LBB0_105:                               ; %else214
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #3, LBB0_210
LBB0_106:                               ; %else217
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #4, LBB0_211
LBB0_107:                               ; %else220
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #5, LBB0_212
LBB0_108:                               ; %else223
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w15, #6, LBB0_213
LBB0_109:                               ; %else226
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w15, #7, LBB0_111
LBB0_110:                               ; %cond.load228
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x13, #28
	ld1.s	{ v29 }[3], [x13]
LBB0_111:                               ; %else229
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x15, #0                         ; =0x0
	add	x13, x28, x11
	stp	q30, q29, [x13]
	fmov	x13, d9
	add	x13, x10, x13, lsl #2
	movi.2d	v31, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v8, #0000000000000000
	b	LBB0_113
LBB0_112:                               ; %else254
                                        ;   in Loop: Header=BB0_113 Depth=2
	add	x15, x4, x15
	stp	q6, q25, [x15]
	add.2d	v23, v23, v16
	add.2d	v24, v24, v17
	add.2d	v8, v8, v7
	add.2d	v31, v31, v18
	fmov	x15, d31
	cmp	x15, #96
	b.ge	LBB0_129
LBB0_113:                               ; %direct.true89.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w17, s2
	lsl	x15, x15, #5
	add	x16, x13, x15
	add	x0, x4, x15
	ldp	q6, q25, [x0]
	tbnz	w17, #0, LBB0_121
; %bb.114:                              ; %else233
                                        ;   in Loop: Header=BB0_113 Depth=2
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB0_122
LBB0_115:                               ; %else236
                                        ;   in Loop: Header=BB0_113 Depth=2
	tbnz	w17, #2, LBB0_123
LBB0_116:                               ; %else239
                                        ;   in Loop: Header=BB0_113 Depth=2
	tbnz	w17, #3, LBB0_124
LBB0_117:                               ; %else242
                                        ;   in Loop: Header=BB0_113 Depth=2
	tbnz	w17, #4, LBB0_125
LBB0_118:                               ; %else245
                                        ;   in Loop: Header=BB0_113 Depth=2
	tbnz	w17, #5, LBB0_126
LBB0_119:                               ; %else248
                                        ;   in Loop: Header=BB0_113 Depth=2
	tbnz	w17, #6, LBB0_127
LBB0_120:                               ; %else251
                                        ;   in Loop: Header=BB0_113 Depth=2
	tbz	w17, #7, LBB0_112
	b	LBB0_128
LBB0_121:                               ; %cond.load232
                                        ;   in Loop: Header=BB0_113 Depth=2
	ld1.s	{ v6 }[0], [x16]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB0_115
LBB0_122:                               ; %cond.load235
                                        ;   in Loop: Header=BB0_113 Depth=2
	add	x0, x16, #4
	ld1.s	{ v6 }[1], [x0]
	tbz	w17, #2, LBB0_116
LBB0_123:                               ; %cond.load238
                                        ;   in Loop: Header=BB0_113 Depth=2
	add	x0, x16, #8
	ld1.s	{ v6 }[2], [x0]
	tbz	w17, #3, LBB0_117
LBB0_124:                               ; %cond.load241
                                        ;   in Loop: Header=BB0_113 Depth=2
	add	x0, x16, #12
	ld1.s	{ v6 }[3], [x0]
	tbz	w17, #4, LBB0_118
LBB0_125:                               ; %cond.load244
                                        ;   in Loop: Header=BB0_113 Depth=2
	add	x0, x16, #16
	ld1.s	{ v25 }[0], [x0]
	tbz	w17, #5, LBB0_119
LBB0_126:                               ; %cond.load247
                                        ;   in Loop: Header=BB0_113 Depth=2
	add	x0, x16, #20
	ld1.s	{ v25 }[1], [x0]
	tbz	w17, #6, LBB0_120
LBB0_127:                               ; %cond.load250
                                        ;   in Loop: Header=BB0_113 Depth=2
	add	x0, x16, #24
	ld1.s	{ v25 }[2], [x0]
	tbz	w17, #7, LBB0_112
LBB0_128:                               ; %cond.load253
                                        ;   in Loop: Header=BB0_113 Depth=2
	add	x16, x16, #28
	ld1.s	{ v25 }[3], [x16]
	b	LBB0_112
LBB0_129:                               ; %direct.false90.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x10, x10, x14
	add	x13, x4, x11
	ldp	q9, q31, [x13]
	fmov	w13, s27
	tbnz	w13, #0, LBB0_214
; %bb.130:                              ; %else258
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #1, LBB0_215
LBB0_131:                               ; %else261
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #2, LBB0_216
LBB0_132:                               ; %else264
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #3, LBB0_217
LBB0_133:                               ; %else267
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #4, LBB0_218
LBB0_134:                               ; %else270
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #5, LBB0_219
LBB0_135:                               ; %else273
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #6, LBB0_220
LBB0_136:                               ; %else276
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w13, #7, LBB0_138
LBB0_137:                               ; %cond.load278
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x10, x10, #28
	ld1.s	{ v31 }[3], [x10]
LBB0_138:                               ; %else279
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	add	x10, x4, x11
	stp	q9, q31, [x10]
	add	x10, x8, x12
	movi.2d	v6, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	b	LBB0_140
LBB0_139:                               ; %else296
                                        ;   in Loop: Header=BB0_140 Depth=2
	add.2d	v23, v23, v16
	add.2d	v24, v24, v17
	add.2d	v25, v25, v7
	add.2d	v6, v6, v18
	fmov	x13, d6
	cmp	x13, #96
	b.ge	LBB0_156
LBB0_140:                               ; %direct.true110.i223.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w12, s2
	lsl	x11, x13, #5
	add	x13, x20, x11
	ldp	q11, q8, [x13]
	add	x13, x28, x11
	ldp	q12, q10, [x13]
	fmul.4s	v13, v11, v12
	add	x13, x27, x11
	ldp	q14, q11, [x13]
	add	x13, x4, x11
	ldp	q15, q12, [x13]
	fmul.4s	v14, v14, v15
	fsub.4s	v13, v13, v14
	and.16b	v13, v1, v13
	add	x11, x10, x11
	tbnz	w12, #0, LBB0_148
; %bb.141:                              ; %else282
                                        ;   in Loop: Header=BB0_140 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_149
LBB0_142:                               ; %else284
                                        ;   in Loop: Header=BB0_140 Depth=2
	tbnz	w12, #2, LBB0_150
LBB0_143:                               ; %else286
                                        ;   in Loop: Header=BB0_140 Depth=2
	tbnz	w12, #3, LBB0_151
LBB0_144:                               ; %else288
                                        ;   in Loop: Header=BB0_140 Depth=2
	fmul.4s	v8, v8, v10
	fmul.4s	v10, v11, v12
	fsub.4s	v8, v8, v10
	and.16b	v8, v0, v8
	tbnz	w12, #4, LBB0_152
LBB0_145:                               ; %else290
                                        ;   in Loop: Header=BB0_140 Depth=2
	tbnz	w12, #5, LBB0_153
LBB0_146:                               ; %else292
                                        ;   in Loop: Header=BB0_140 Depth=2
	tbnz	w12, #6, LBB0_154
LBB0_147:                               ; %else294
                                        ;   in Loop: Header=BB0_140 Depth=2
	tbz	w12, #7, LBB0_139
	b	LBB0_155
LBB0_148:                               ; %cond.store
                                        ;   in Loop: Header=BB0_140 Depth=2
	str	s13, [x11]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_142
LBB0_149:                               ; %cond.store283
                                        ;   in Loop: Header=BB0_140 Depth=2
	add	x13, x11, #4
	st1.s	{ v13 }[1], [x13]
	tbz	w12, #2, LBB0_143
LBB0_150:                               ; %cond.store285
                                        ;   in Loop: Header=BB0_140 Depth=2
	add	x13, x11, #8
	st1.s	{ v13 }[2], [x13]
	tbz	w12, #3, LBB0_144
LBB0_151:                               ; %cond.store287
                                        ;   in Loop: Header=BB0_140 Depth=2
	add	x13, x11, #12
	st1.s	{ v13 }[3], [x13]
	fmul.4s	v8, v8, v10
	fmul.4s	v10, v11, v12
	fsub.4s	v8, v8, v10
	and.16b	v8, v0, v8
	tbz	w12, #4, LBB0_145
LBB0_152:                               ; %cond.store289
                                        ;   in Loop: Header=BB0_140 Depth=2
	str	s8, [x11, #16]
	tbz	w12, #5, LBB0_146
LBB0_153:                               ; %cond.store291
                                        ;   in Loop: Header=BB0_140 Depth=2
	add	x13, x11, #20
	st1.s	{ v8 }[1], [x13]
	tbz	w12, #6, LBB0_147
LBB0_154:                               ; %cond.store293
                                        ;   in Loop: Header=BB0_140 Depth=2
	add	x13, x11, #24
	st1.s	{ v8 }[2], [x13]
	tbz	w12, #7, LBB0_139
LBB0_155:                               ; %cond.store295
                                        ;   in Loop: Header=BB0_140 Depth=2
	add	x11, x11, #28
	st1.s	{ v8 }[3], [x11]
	b	LBB0_139
LBB0_156:                               ; %direct.false111.i232.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmul.4s	v6, v5, v30
	fmul.4s	v23, v28, v9
	fsub.4s	v6, v6, v23
	zip1.8b	v23, v3, v0
	ushll.4s	v23, v23, #0
	shl.4s	v23, v23, #31
	cmlt.4s	v23, v23, #0
	and.16b	v6, v23, v6
	fmov	w11, s27
	ldr	q24, [sp, #240]                 ; 16-byte Reload
	ldp	q23, q25, [sp, #192]            ; 32-byte Folded Reload
	stp	q24, q25, [sp, #336]
	str	q23, [sp, #368]
	ldr	q23, [sp, #224]                 ; 16-byte Reload
	str	q23, [sp, #384]
	and	x12, x9, #0x7
	add	x13, sp, #336
	ldr	x12, [x13, x12, lsl #3]
	sub	x12, x12, x9
	add	x12, x8, x12, lsl #2
	tbnz	w11, #0, LBB0_221
; %bb.157:                              ; %else299
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w11, #1, LBB0_222
LBB0_158:                               ; %else301
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w11, #2, LBB0_223
LBB0_159:                               ; %else303
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w11, #3, LBB0_161
LBB0_160:                               ; %cond.store304
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x12, #12
	st1.s	{ v6 }[3], [x13]
LBB0_161:                               ; %else305
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmul.4s	v6, v4, v29
	fmul.4s	v23, v26, v31
	fsub.4s	v6, v6, v23
	zip2.8b	v23, v3, v0
	ushll.4s	v23, v23, #0
	shl.4s	v23, v23, #31
	cmlt.4s	v23, v23, #0
	and.16b	v6, v23, v6
	tbnz	w11, #4, LBB0_224
; %bb.162:                              ; %else307
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w11, #5, LBB0_225
LBB0_163:                               ; %else309
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w11, #6, LBB0_226
LBB0_164:                               ; %else311
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w11, #7, LBB0_166
LBB0_165:                               ; %cond.store312
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x11, x12, #28
	st1.s	{ v6 }[3], [x11]
LBB0_166:                               ; %else313
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	movi.2d	v6, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	b	LBB0_168
LBB0_167:                               ; %else330
                                        ;   in Loop: Header=BB0_168 Depth=2
	add.2d	v23, v23, v16
	add.2d	v24, v24, v17
	add.2d	v25, v25, v7
	add.2d	v6, v6, v18
	fmov	x11, d6
	cmp	x11, #96
	b.ge	LBB0_184
LBB0_168:                               ; %direct.true149.i234.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w12, s2
	lsl	x11, x11, #5
	add	x13, x20, x11
	ldp	q11, q8, [x13]
	add	x13, x4, x11
	ldp	q12, q10, [x13]
	fmul.4s	v13, v11, v12
	add	x13, x27, x11
	ldp	q14, q11, [x13]
	add	x13, x28, x11
	ldp	q15, q12, [x13]
	fmul.4s	v14, v14, v15
	fadd.4s	v13, v13, v14
	and.16b	v13, v1, v13
	add	x11, x10, x11
	add	x11, x11, #3076
	tbnz	w12, #0, LBB0_176
; %bb.169:                              ; %else316
                                        ;   in Loop: Header=BB0_168 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_177
LBB0_170:                               ; %else318
                                        ;   in Loop: Header=BB0_168 Depth=2
	tbnz	w12, #2, LBB0_178
LBB0_171:                               ; %else320
                                        ;   in Loop: Header=BB0_168 Depth=2
	tbnz	w12, #3, LBB0_179
LBB0_172:                               ; %else322
                                        ;   in Loop: Header=BB0_168 Depth=2
	fmul.4s	v8, v8, v10
	fmul.4s	v10, v11, v12
	fadd.4s	v8, v8, v10
	and.16b	v8, v0, v8
	tbnz	w12, #4, LBB0_180
LBB0_173:                               ; %else324
                                        ;   in Loop: Header=BB0_168 Depth=2
	tbnz	w12, #5, LBB0_181
LBB0_174:                               ; %else326
                                        ;   in Loop: Header=BB0_168 Depth=2
	tbnz	w12, #6, LBB0_182
LBB0_175:                               ; %else328
                                        ;   in Loop: Header=BB0_168 Depth=2
	tbz	w12, #7, LBB0_167
	b	LBB0_183
LBB0_176:                               ; %cond.store315
                                        ;   in Loop: Header=BB0_168 Depth=2
	str	s13, [x11]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_170
LBB0_177:                               ; %cond.store317
                                        ;   in Loop: Header=BB0_168 Depth=2
	add	x13, x11, #4
	st1.s	{ v13 }[1], [x13]
	tbz	w12, #2, LBB0_171
LBB0_178:                               ; %cond.store319
                                        ;   in Loop: Header=BB0_168 Depth=2
	add	x13, x11, #8
	st1.s	{ v13 }[2], [x13]
	tbz	w12, #3, LBB0_172
LBB0_179:                               ; %cond.store321
                                        ;   in Loop: Header=BB0_168 Depth=2
	add	x13, x11, #12
	st1.s	{ v13 }[3], [x13]
	fmul.4s	v8, v8, v10
	fmul.4s	v10, v11, v12
	fadd.4s	v8, v8, v10
	and.16b	v8, v0, v8
	tbz	w12, #4, LBB0_173
LBB0_180:                               ; %cond.store323
                                        ;   in Loop: Header=BB0_168 Depth=2
	str	s8, [x11, #16]
	tbz	w12, #5, LBB0_174
LBB0_181:                               ; %cond.store325
                                        ;   in Loop: Header=BB0_168 Depth=2
	add	x13, x11, #20
	st1.s	{ v8 }[1], [x13]
	tbz	w12, #6, LBB0_175
LBB0_182:                               ; %cond.store327
                                        ;   in Loop: Header=BB0_168 Depth=2
	add	x13, x11, #24
	st1.s	{ v8 }[2], [x13]
	tbz	w12, #7, LBB0_167
LBB0_183:                               ; %cond.store329
                                        ;   in Loop: Header=BB0_168 Depth=2
	add	x11, x11, #28
	st1.s	{ v8 }[3], [x11]
	b	LBB0_167
LBB0_184:                               ; %direct.false150.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmul.4s	v0, v5, v9
	fmul.4s	v1, v28, v30
	fadd.4s	v0, v1, v0
	zip1.8b	v1, v3, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v0, v1, v0
	fmov	w10, s27
	stp	q22, q21, [sp, #256]
	stp	q20, q19, [sp, #288]
	and	x11, x9, #0x7
	add	x12, sp, #256
	ldr	x11, [x12, x11, lsl #3]
	sub	x9, x11, x9
	add	x8, x8, x9, lsl #2
	tbnz	w10, #0, LBB0_227
; %bb.185:                              ; %else333
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #1, LBB0_228
LBB0_186:                               ; %else335
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #2, LBB0_229
LBB0_187:                               ; %else337
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w10, #3, LBB0_189
LBB0_188:                               ; %cond.store338
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #12
	st1.s	{ v0 }[3], [x9]
LBB0_189:                               ; %else339
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmul.4s	v0, v4, v31
	fmul.4s	v1, v26, v29
	fadd.4s	v0, v1, v0
	zip2.8b	v1, v3, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v0, v1, v0
	tbnz	w10, #4, LBB0_230
; %bb.190:                              ; %else341
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #5, LBB0_231
LBB0_191:                               ; %else343
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #6, LBB0_232
LBB0_192:                               ; %else345
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w10, #7, LBB0_2
	b	LBB0_233
LBB0_193:                               ; %cond.load107
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v5 }[0], [x16]
	tbz	w12, #1, LBB0_50
LBB0_194:                               ; %cond.load110
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x16, #4
	ld1.s	{ v5 }[1], [x17]
	tbz	w12, #2, LBB0_51
LBB0_195:                               ; %cond.load113
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x16, #8
	ld1.s	{ v5 }[2], [x17]
	tbz	w12, #3, LBB0_52
LBB0_196:                               ; %cond.load116
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x16, #12
	ld1.s	{ v5 }[3], [x17]
	tbz	w12, #4, LBB0_53
LBB0_197:                               ; %cond.load119
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x16, #16
	ld1.s	{ v4 }[0], [x17]
	tbz	w12, #5, LBB0_54
LBB0_198:                               ; %cond.load122
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x16, #20
	ld1.s	{ v4 }[1], [x17]
	tbz	w12, #6, LBB0_55
LBB0_199:                               ; %cond.load125
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x16, #24
	ld1.s	{ v4 }[2], [x17]
	tbnz	w12, #7, LBB0_56
	b	LBB0_57
LBB0_200:                               ; %cond.load157
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v28 }[0], [x15]
	tbz	w16, #1, LBB0_77
LBB0_201:                               ; %cond.load160
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #4
	ld1.s	{ v28 }[1], [x17]
	tbz	w16, #2, LBB0_78
LBB0_202:                               ; %cond.load163
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #8
	ld1.s	{ v28 }[2], [x17]
	tbz	w16, #3, LBB0_79
LBB0_203:                               ; %cond.load166
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #12
	ld1.s	{ v28 }[3], [x17]
	tbz	w16, #4, LBB0_80
LBB0_204:                               ; %cond.load169
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #16
	ld1.s	{ v26 }[0], [x17]
	tbz	w16, #5, LBB0_81
LBB0_205:                               ; %cond.load172
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #20
	ld1.s	{ v26 }[1], [x17]
	tbz	w16, #6, LBB0_82
LBB0_206:                               ; %cond.load175
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #24
	ld1.s	{ v26 }[2], [x17]
	tbnz	w16, #7, LBB0_83
	b	LBB0_84
LBB0_207:                               ; %cond.load207
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v30 }[0], [x13]
	tbz	w15, #1, LBB0_104
LBB0_208:                               ; %cond.load210
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x13, #4
	ld1.s	{ v30 }[1], [x16]
	tbz	w15, #2, LBB0_105
LBB0_209:                               ; %cond.load213
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x13, #8
	ld1.s	{ v30 }[2], [x16]
	tbz	w15, #3, LBB0_106
LBB0_210:                               ; %cond.load216
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x13, #12
	ld1.s	{ v30 }[3], [x16]
	tbz	w15, #4, LBB0_107
LBB0_211:                               ; %cond.load219
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x13, #16
	ld1.s	{ v29 }[0], [x16]
	tbz	w15, #5, LBB0_108
LBB0_212:                               ; %cond.load222
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x13, #20
	ld1.s	{ v29 }[1], [x16]
	tbz	w15, #6, LBB0_109
LBB0_213:                               ; %cond.load225
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x13, #24
	ld1.s	{ v29 }[2], [x16]
	tbnz	w15, #7, LBB0_110
	b	LBB0_111
LBB0_214:                               ; %cond.load257
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v9 }[0], [x10]
	tbz	w13, #1, LBB0_131
LBB0_215:                               ; %cond.load260
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x10, #4
	ld1.s	{ v9 }[1], [x14]
	tbz	w13, #2, LBB0_132
LBB0_216:                               ; %cond.load263
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x10, #8
	ld1.s	{ v9 }[2], [x14]
	tbz	w13, #3, LBB0_133
LBB0_217:                               ; %cond.load266
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x10, #12
	ld1.s	{ v9 }[3], [x14]
	tbz	w13, #4, LBB0_134
LBB0_218:                               ; %cond.load269
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x10, #16
	ld1.s	{ v31 }[0], [x14]
	tbz	w13, #5, LBB0_135
LBB0_219:                               ; %cond.load272
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x10, #20
	ld1.s	{ v31 }[1], [x14]
	tbz	w13, #6, LBB0_136
LBB0_220:                               ; %cond.load275
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x14, x10, #24
	ld1.s	{ v31 }[2], [x14]
	tbnz	w13, #7, LBB0_137
	b	LBB0_138
LBB0_221:                               ; %cond.store298
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s6, [x12]
	tbz	w11, #1, LBB0_158
LBB0_222:                               ; %cond.store300
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x12, #4
	st1.s	{ v6 }[1], [x13]
	tbz	w11, #2, LBB0_159
LBB0_223:                               ; %cond.store302
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x12, #8
	st1.s	{ v6 }[2], [x13]
	tbnz	w11, #3, LBB0_160
	b	LBB0_161
LBB0_224:                               ; %cond.store306
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s6, [x12, #16]
	tbz	w11, #5, LBB0_163
LBB0_225:                               ; %cond.store308
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x12, #20
	st1.s	{ v6 }[1], [x13]
	tbz	w11, #6, LBB0_164
LBB0_226:                               ; %cond.store310
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x12, #24
	st1.s	{ v6 }[2], [x13]
	tbnz	w11, #7, LBB0_165
	b	LBB0_166
LBB0_227:                               ; %cond.store332
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s0, [x8]
	tbz	w10, #1, LBB0_186
LBB0_228:                               ; %cond.store334
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #4
	st1.s	{ v0 }[1], [x9]
	tbz	w10, #2, LBB0_187
LBB0_229:                               ; %cond.store336
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #8
	st1.s	{ v0 }[2], [x9]
	tbnz	w10, #3, LBB0_188
	b	LBB0_189
LBB0_230:                               ; %cond.store340
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s0, [x8, #16]
	tbz	w10, #5, LBB0_191
LBB0_231:                               ; %cond.store342
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #20
	st1.s	{ v0 }[1], [x9]
	tbz	w10, #6, LBB0_192
LBB0_232:                               ; %cond.store344
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #24
	st1.s	{ v0 }[2], [x9]
	tbz	w10, #7, LBB0_2
LBB0_233:                               ; %cond.store346
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB0_2
LBB0_234:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Reload
	stp	w7, w6, [x9]
	str	w5, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
LBB0_235:                               ; %block.batch.exit
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #848
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh22, Lloh23
                                        ; -- End function
.subsections_via_symbols

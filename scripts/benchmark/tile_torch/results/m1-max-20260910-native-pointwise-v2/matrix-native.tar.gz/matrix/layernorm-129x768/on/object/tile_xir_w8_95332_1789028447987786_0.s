	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	x24, x23, [sp, #-64]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #128
	ldr	x8, [x0]
	ldr	x20, [x0, #16]
	ldr	x19, [x0, #32]
	ldr	x21, [x0, #48]
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	add	w9, w10, w9, lsl #5
	lsr	w9, w9, #3
	mov	w10, #3072                      ; =0xc00
	umull	x22, w9, w10
	umaddl	x1, w9, w10, x8
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #1152
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #1152
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldr	q0, [sp, #9360]
	ldr	q2, [sp, #9344]
	ldr	q1, [sp, #9392]
	ldr	q5, [sp, #9376]
	ldr	q4, [sp, #9424]
	ldr	q3, [sp, #9408]
	add	x8, x23, #224
	mov	w9, #4                          ; =0x4
	ldr	q6, [sp, #9456]
	ldr	q7, [sp, #9440]
LBB0_1:                                 ; %direct.true66
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q16, q17, [x8, #-96]
	fadd.4s	v0, v0, v17
	fadd.4s	v2, v2, v16
	ldp	q16, q17, [x8, #-64]
	fadd.4s	v1, v1, v17
	fadd.4s	v5, v5, v16
	ldp	q16, q17, [x8, #-32]
	fadd.4s	v4, v4, v17
	fadd.4s	v3, v3, v16
	ldp	q16, q17, [x8], #128
	fadd.4s	v6, v6, v17
	fadd.4s	v7, v7, v16
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB0_1
; %bb.2:                                ; %direct.false67
	mov	x8, #0                          ; =0x0
	fadd.4s	v2, v2, v5
	fadd.4s	v0, v0, v1
	fadd.4s	v0, v0, v4
	fadd.4s	v1, v2, v3
	fadd.4s	v1, v1, v7
	fadd.4s	v0, v0, v6
	rev64.4s	v2, v0
	rev64.4s	v3, v1
	fadd.4s	v1, v1, v3
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[2]
	dup.4s	v3, v1[2]
	fadd.4s	v1, v1, v3
	fadd.4s	v0, v0, v2
	fadd.4s	v0, v1, v0
	movi.2d	v1, #0000000000000000
	fadd	s0, s0, s1
	mov	w9, #1145044992                 ; =0x44400000
	fmov	s1, w9
	fdiv	s0, s0, s1
	dup.4s	v0, v0[0]
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #1152
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2176
LBB0_3:                                 ; %direct.true103
                                        ; =>This Inner Loop Header: Depth=1
	add	x11, x9, x8
	ldp	q2, q1, [x11]
	fsub.4s	v2, v2, v0
	fsub.4s	v1, v1, v0
	add	x11, x10, x8
	stp	q2, q1, [x11]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_3
; %bb.4:                                ; %direct.false104
	ldr	q0, [sp, #6272]
	ldr	q1, [sp, #6288]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #6304]
	ldr	q1, [sp, #6320]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [sp, #6336]
	ldr	q1, [sp, #6352]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #6368]
	ldr	q1, [sp, #6384]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #2176
	add	x8, x8, #224
	mov	w9, #4                          ; =0x4
LBB0_5:                                 ; %direct.true134
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB0_5
; %bb.6:                                ; %direct.false135
	add	x23, sp, #3200
	add	x0, sp, #3200
	mov	x1, x20
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #48]               ; 32-byte Folded Spill
	stp	q5, q3, [sp]                    ; 32-byte Folded Spill
	stp	q6, q16, [sp, #96]              ; 32-byte Folded Spill
	str	q7, [sp, #32]                   ; 16-byte Spill
	str	q17, [sp, #80]                  ; 16-byte Spill
	bl	_memcpy
	ldp	q1, q0, [sp]                    ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #48]               ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #32]                   ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #80]               ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	movi.2d	v1, #0000000000000000
	fadd	s0, s0, s1
	mov	w8, #1145044992                 ; =0x44400000
	fmov	s1, w8
	fdiv	s0, s0, s1
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s1, w8
	fadd	s0, s0, s1
	fsqrt	s0, s0
	subs	x8, x21, x19
	cset	w9, hs
	cmp	x8, #3071
	csel	w8, wzr, w9, ls
	subs	x9, x19, x21
	lsr	x9, x9, #10
	mov	w10, #386                       ; =0x182
	ccmp	x9, x10, #0, hs
	b.hi	LBB0_10
; %bb.7:                                ; %direct.false135
	tbnz	w8, #0, LBB0_10
; %bb.8:                                ; %direct.true225.preheader
	add	x20, sp, #128
	add	x0, sp, #128
	mov	x1, x19
	mov	w2, #3072                       ; =0xc00
	str	q0, [sp, #112]                  ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q0, [sp, #112]                  ; 16-byte Reload
	dup.4s	v0, v0[0]
	add	x9, x21, x22
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2176
	add	x11, sp, #3200
LBB0_9:                                 ; %direct.true244
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x10, x8
	ldp	q2, q1, [x12]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x12, x11, x8
	ldp	q3, q4, [x12]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x12, x20, x8
	ldp	q4, q3, [x12]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	add	x12, x9, x8
	stp	q2, q1, [x12]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_9
	b	LBB0_12
LBB0_10:                                ; %direct.schedule.17.preheader
	mov	x8, #0                          ; =0x0
	dup.4s	v0, v0[0]
	add	x9, x21, x22
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #2176
LBB0_11:                                ; %direct.true195
                                        ; =>This Inner Loop Header: Depth=1
	add	x11, x10, x8
	ldp	q2, q1, [x11]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x11, x23, x8
	ldp	q3, q4, [x11]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x11, x19, x8
	ldp	q4, q3, [x11]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	add	x11, x9, x8
	stp	q2, q1, [x11]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_11
LBB0_12:                                ; %common.ret
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #128
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #64             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_3:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI1_4:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI1_5:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI1_6:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d9, d8, [sp, #-112]!            ; 16-byte Folded Spill
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #1104
	str	x0, [sp, #120]                  ; 8-byte Spill
	cbz	w3, LBB1_127
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x19, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	add	x23, sp, #272
	add	x24, sp, #2, lsl #12            ; =8192
	add	x24, x24, #2128
	add	x25, sp, #1, lsl #12            ; =4096
	add	x25, x25, #3152
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #112]              ; 8-byte Folded Spill
	ldp	w28, w12, [x2]
	ldp	w27, w8, [x2, #8]
	str	x8, [sp, #104]                  ; 8-byte Spill
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #80]                   ; 16-byte Spill
Lloh4:
	adrp	x8, lCPI1_2@PAGE
Lloh5:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #64]                   ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #80
	str	w3, [sp, #60]                   ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w19, [sp, #60]                  ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w28, #1
	ldp	w10, w9, [sp, #112]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w28, wzr, w28, eq
	ldr	w9, [sp, #128]                  ; 4-byte Reload
	cinc	w9, w9, eq
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w12, wzr, w9, ne
	add	w27, w27, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_127
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_32 Depth 2
                                        ;     Child Loop BB1_34 Depth 2
                                        ;     Child Loop BB1_36 Depth 2
                                        ;     Child Loop BB1_39 Depth 2
                                        ;     Child Loop BB1_59 Depth 2
                                        ;     Child Loop BB1_111 Depth 2
                                        ;     Child Loop BB1_77 Depth 2
	ubfiz	x8, x28, #5, #32
	ldr	x13, [sp, #104]                 ; 8-byte Reload
	cmp	x8, x13
	csel	x9, x8, xzr, ls
	subs	x10, x13, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x13, x9
	stp	w28, w12, [x20]
	str	w12, [sp, #128]                 ; 4-byte Spill
	str	w27, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x13, #2, hi
	csel	x26, x10, xzr, ls
	cmp	x26, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x26, [sp, #120]                 ; 8-byte Reload
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x19, x26, #3
	cbz	x19, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #120]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #120]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #120]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x23, [sp, #120]                 ; 8-byte Reload
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x23
	add	x23, sp, #272
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w26, #0x7
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v1, w8
	ldp	q0, q2, [sp, #64]               ; 32-byte Folded Reload
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x11, [sp, #120]                 ; 8-byte Reload
	ldr	x12, [x11, #16]
	ldr	x8, [x11, #32]
	ldr	x0, [x11, #48]
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v2, v3, v2
	addv.8h	h2, v2
	fmov	w10, s2
	and	w10, w10, #0xff
	ldr	x11, [x11]
	ubfiz	w13, w28, #2, #27
	orr	w13, w13, w19
	fmov	s4, w13
	and.16b	v4, v1, v4
	fmov	w13, s4
	mov	w14, #3072                      ; =0xc00
	umull	x15, w13, w14
	str	x15, [sp, #40]                  ; 8-byte Spill
	umaddl	x11, w13, w14, x11
	fmov	w13, s2
	b	LBB1_15
LBB1_14:                                ; %else105
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x24, x9
	stp	q4, q5, [x14]
	add	x9, x9, #32
	cmp	x9, #3072
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x11, x9
	add	x16, x24, x9
	ldr	q4, [x16]
	tbnz	w13, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w15, w13, #0xff
	tbnz	w15, #1, LBB1_24
LBB1_17:                                ; %else87
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #2, LBB1_25
LBB1_18:                                ; %else90
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #3, LBB1_26
LBB1_19:                                ; %else93
                                        ;   in Loop: Header=BB1_15 Depth=2
	ldr	q5, [x16, #16]
	tbnz	w15, #4, LBB1_27
LBB1_20:                                ; %else96
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #5, LBB1_28
LBB1_21:                                ; %else99
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #6, LBB1_29
LBB1_22:                                ; %else102
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w15, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	ld1.s	{ v4 }[0], [x14]
	and	w15, w13, #0xff
	tbz	w15, #1, LBB1_17
LBB1_24:                                ; %cond.load86
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x14, #4
	ld1.s	{ v4 }[1], [x17]
	tbz	w15, #2, LBB1_18
LBB1_25:                                ; %cond.load89
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x14, #8
	ld1.s	{ v4 }[2], [x17]
	tbz	w15, #3, LBB1_19
LBB1_26:                                ; %cond.load92
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x14, #12
	ld1.s	{ v4 }[3], [x17]
	ldr	q5, [x16, #16]
	tbz	w15, #4, LBB1_20
LBB1_27:                                ; %cond.load95
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x16, x14, #16
	ld1.s	{ v5 }[0], [x16]
	tbz	w15, #5, LBB1_21
LBB1_28:                                ; %cond.load98
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x16, x14, #20
	ld1.s	{ v5 }[1], [x16]
	tbz	w15, #6, LBB1_22
LBB1_29:                                ; %cond.load101
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x16, x14, #24
	ld1.s	{ v5 }[2], [x16]
	tbz	w15, #7, LBB1_14
LBB1_30:                                ; %cond.load104
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x14, #28
	ld1.s	{ v5 }[3], [x14]
	b	LBB1_14
LBB1_31:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	x0, [sp, #48]                   ; 8-byte Spill
	ldr	q4, [x23, #10048]
	ldr	q5, [x23, #10064]
	ldr	q6, [x23, #10080]
	ldr	q7, [x23, #10096]
	ldr	q16, [x23, #10112]
	ldr	q19, [x23, #10128]
	ldr	q20, [x23, #10144]
	and.16b	v5, v0, v5
	and.16b	v4, v1, v4
	ldr	q21, [x23, #10160]
	and.16b	v18, v0, v7
	and.16b	v17, v1, v6
	and.16b	v6, v0, v19
	and.16b	v19, v1, v16
	and.16b	v16, v0, v21
	and.16b	v7, v1, v20
	add	x9, x24, #224
	mov	w11, #4                         ; =0x4
LBB1_32:                                ; %direct.true66.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q21, q20, [x9, #-96]
	fadd.4s	v21, v4, v21
	fadd.4s	v20, v5, v20
	ldp	q23, q22, [x9, #-64]
	fadd.4s	v23, v17, v23
	fadd.4s	v22, v18, v22
	ldp	q25, q24, [x9, #-32]
	fadd.4s	v25, v19, v25
	fadd.4s	v24, v6, v24
	ldp	q27, q26, [x9], #128
	fadd.4s	v27, v7, v27
	fadd.4s	v26, v16, v26
	bit.16b	v5, v20, v0
	bit.16b	v4, v21, v1
	bit.16b	v18, v22, v0
	bit.16b	v17, v23, v1
	bit.16b	v6, v24, v0
	bit.16b	v19, v25, v1
	bit.16b	v16, v26, v0
	bit.16b	v7, v27, v1
	cmp	x11, #92
	add	x11, x11, #4
	b.lo	LBB1_32
; %bb.33:                               ; %direct.false67.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x3, #0                          ; =0x0
	xtn.8b	v3, v3
	fadd.4s	v5, v5, v18
	fadd.4s	v4, v4, v17
	fadd.4s	v17, v4, v19
	fadd.4s	v4, v5, v6
	fadd.4s	v4, v4, v16
	fadd.4s	v5, v17, v7
	ldr	q6, [sp, #80]                   ; 16-byte Reload
	and.16b	v7, v1, v6
	ldr	q6, [sp, #64]                   ; 16-byte Reload
	and.16b	v6, v0, v6
	movi.4s	v17, #1
	eor.16b	v16, v6, v17
	eor.16b	v19, v7, v17
	umov.b	w11, v3[0]
	str	q5, [x23, #784]
	ldr	s7, [sp, #1060]
	umov.b	w14, v3[1]
	ands	w9, w11, #0x1
	tst	w9, w14
	fcsel	s7, s7, s8, ne
	mov.s	w13, v19[1]
	add	x15, sp, #1024
	orr	x15, x15, x13, lsl #2
	add	x16, sp, #728
	bfxil	x16, x13, #0, #3
	str	d3, [x23, #456]
	ldrb	w13, [x16]
	and	w13, w14, w13
	stp	q5, q4, [x23, #752]
	ldr	s17, [x15]
	tst	w13, #0x1
	fcsel	s17, s17, s8, ne
	mov.s	w13, v19[2]
	add	x15, sp, #992
	orr	x15, x15, x13, lsl #2
	add	x16, sp, #728
	bfxil	x16, x13, #0, #3
	ldrb	w13, [x16]
	umov.b	w1, v3[2]
	and	w13, w1, w13
	stp	q5, q4, [x23, #720]
	ldr	s18, [x15]
	tst	w13, #0x1
	fcsel	s18, s18, s8, ne
	mov.s	w13, v19[3]
	add	x15, sp, #960
	orr	x15, x15, x13, lsl #2
	add	x16, sp, #728
	bfxil	x16, x13, #0, #3
	ldrb	w13, [x16]
	umov.b	w2, v3[3]
	and	w13, w2, w13
	stp	q5, q4, [x23, #688]
	ldr	s19, [x15]
	tst	w13, #0x1
	fcsel	s19, s19, s8, ne
	fmov	w13, s16
	add	x15, sp, #728
	bfxil	x15, x13, #0, #3
	ldrb	w16, [x15]
	umov.b	w15, v3[4]
	and	w16, w15, w16
	stp	q5, q4, [x23, #656]
	add	x17, sp, #928
	ldr	s20, [x17, w13, uxtw #2]
	tst	w16, #0x1
	fcsel	s20, s20, s8, ne
	mov.s	w13, v16[1]
	add	x17, sp, #728
	bfxil	x17, x13, #0, #3
	umov.b	w16, v3[5]
	ldrb	w17, [x17]
	and	w17, w16, w17
	stp	q5, q4, [x23, #624]
	add	x0, sp, #896
	ldr	s21, [x0, w13, uxtw #2]
	tst	w17, #0x1
	fcsel	s21, s21, s8, ne
	mov.s	w13, v16[2]
	add	x17, sp, #728
	bfxil	x17, x13, #0, #3
	ldrb	w0, [x17]
	umov.b	w17, v3[6]
	and	w0, w17, w0
	stp	q5, q4, [x23, #592]
	add	x4, sp, #864
	ldr	s22, [x4, w13, uxtw #2]
	tst	w0, #0x1
	fcsel	s22, s22, s8, ne
	mov.s	w13, v16[3]
	add	x0, sp, #728
	bfxil	x0, x13, #0, #3
	ldrb	w4, [x0]
	umov.b	w0, v3[7]
	and	w4, w0, w4
	stp	q5, q4, [x23, #560]
	add	x5, sp, #832
	ldr	s16, [x5, w13, uxtw #2]
	tst	w4, #0x1
	fcsel	s16, s16, s8, ne
	mov.s	v7[1], v17[0]
	mov.s	v7[2], v18[0]
	mov.s	v7[3], v19[0]
	mov.s	v20[1], v21[0]
	mov.s	v20[2], v22[0]
	mov.s	v20[3], v16[0]
	fadd.4s	v4, v4, v20
	fadd.4s	v5, v5, v7
	movi.4s	v7, #2
	eor.16b	v6, v6, v7
	str	q5, [x23, #528]
	ldr	s7, [sp, #808]
	tst	w9, w1
	fcsel	s7, s7, s8, ne
	fmov	w9, s6
	add	x13, sp, #728
	bfxil	x13, x9, #0, #3
	ldrb	w13, [x13]
	and	w13, w15, w13
	stp	q5, q4, [x23, #496]
	add	x4, sp, #768
	ldr	s6, [x4, w9, uxtw #2]
	tst	w13, #0x1
	fcsel	s6, s6, s8, ne
	fadd.4s	v4, v4, v6
	and	w13, w11, w15
	tst	w13, #0x1
	fcsel	s4, s4, s8, ne
	ands	w9, w11, #0x1
	fadd.4s	v5, v5, v7
	fadd	s4, s5, s4
	fcsel	s5, s4, s8, ne
	tst	w13, #0x1
	and	w5, w14, w11
	fcsel	s6, s4, s8, ne
	and	w4, w14, w11
	str	w4, [sp, #36]                   ; 4-byte Spill
	tst	w5, #0x1
	and	w5, w1, w11
	fcsel	s7, s4, s8, ne
	and	w4, w1, w11
	str	w4, [sp, #32]                   ; 4-byte Spill
	tst	w5, #0x1
	and	w5, w2, w11
	fcsel	s16, s4, s8, ne
	tst	w5, #0x1
	fcsel	s17, s4, s8, ne
	and	w6, w16, w11
	tst	w6, #0x1
	fcsel	s18, s4, s8, ne
	and	w7, w17, w11
	tst	w7, #0x1
	fcsel	s19, s4, s8, ne
	and	w30, w0, w11
	tst	w30, #0x1
	mov.s	v5[1], v7[0]
	mov.s	v5[2], v16[0]
	mov.s	v5[3], v17[0]
	mov.s	v6[1], v18[0]
	fcsel	s4, s4, s8, ne
	mov.s	v6[2], v19[0]
	mov.s	v6[3], v4[0]
	rbit	w10, w10
	clz	w10, w10
	stp	q5, q6, [x23, #464]
	and	x4, x10, #0x7
	add	x19, sp, #736
	ldr	s4, [x19, x4, lsl #2]
	fadd	s4, s4, s8
	mov	w4, #1145044992                 ; =0x44400000
	fmov	s5, w4
	fdiv	s4, s4, s5
	dup.4s	v4, v4[0]
LBB1_34:                                ; %direct.true103.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x4, x24, x3
	ldp	q6, q5, [x4]
	fsub.4s	v6, v6, v4
	fsub.4s	v5, v5, v4
	add	x4, x25, x3
	ldp	q7, q16, [x4]
	bif.16b	v5, v16, v0
	bif.16b	v6, v7, v1
	stp	q6, q5, [x4]
	add	x3, x3, #32
	cmp	x3, #3072
	b.ne	LBB1_34
; %bb.35:                               ; %direct.false104.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q4, [x23, #6992]
	ldr	q5, [x23, #6976]
	fmul.4s	v6, v5, v5
	fmul.4s	v4, v4, v4
	ldr	q5, [x23, #7024]
	ldr	q7, [x23, #7008]
	fmul.4s	v7, v7, v7
	fmul.4s	v16, v5, v5
	ldr	q5, [x23, #7056]
	ldr	q17, [x23, #7040]
	fmul.4s	v19, v17, v17
	fmul.4s	v20, v5, v5
	ldr	q5, [x23, #7088]
	ldr	q17, [x23, #7072]
	fmul.4s	v21, v17, v17
	fmul.4s	v22, v5, v5
	and.16b	v5, v0, v4
	and.16b	v4, v1, v6
	and.16b	v18, v0, v16
	and.16b	v17, v1, v7
	and.16b	v6, v0, v20
	and.16b	v19, v1, v19
	and.16b	v16, v0, v22
	and.16b	v7, v1, v21
	add	x3, x25, #224
	mov	w4, #4                          ; =0x4
LBB1_36:                                ; %direct.true134.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q21, q20, [x3, #-96]
	and.16b	v21, v1, v21
	and.16b	v20, v0, v20
	fmul.4s	v20, v20, v20
	fmul.4s	v21, v21, v21
	fadd.4s	v21, v4, v21
	fadd.4s	v20, v5, v20
	ldp	q23, q22, [x3, #-64]
	and.16b	v23, v1, v23
	and.16b	v22, v0, v22
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	fadd.4s	v23, v17, v23
	fadd.4s	v22, v18, v22
	ldp	q25, q24, [x3, #-32]
	and.16b	v25, v1, v25
	and.16b	v24, v0, v24
	fmul.4s	v24, v24, v24
	fmul.4s	v25, v25, v25
	fadd.4s	v25, v19, v25
	fadd.4s	v24, v6, v24
	ldp	q27, q26, [x3], #128
	and.16b	v27, v1, v27
	and.16b	v26, v0, v26
	fmul.4s	v26, v26, v26
	fmul.4s	v27, v27, v27
	fadd.4s	v27, v7, v27
	fadd.4s	v26, v16, v26
	bit.16b	v5, v20, v0
	bit.16b	v4, v21, v1
	bit.16b	v18, v22, v0
	bit.16b	v17, v23, v1
	bit.16b	v6, v24, v0
	bit.16b	v19, v25, v1
	bit.16b	v16, v26, v0
	bit.16b	v7, v27, v1
	cmp	x4, #92
	add	x4, x4, #4
	b.lo	LBB1_36
; %bb.37:                               ; %direct.true173.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x3, #0                          ; =0x0
	b	LBB1_39
LBB1_38:                                ; %else130
                                        ;   in Loop: Header=BB1_39 Depth=2
	add	x4, x21, x3
	stp	q20, q21, [x4]
	add	x3, x3, #32
	cmp	x3, #3072
	b.eq	LBB1_55
LBB1_39:                                ; %direct.true173.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w19, s2
	add	x4, x12, x3
	add	x26, x21, x3
	ldp	q20, q21, [x26]
	tbnz	w19, #0, LBB1_47
; %bb.40:                               ; %else109
                                        ;   in Loop: Header=BB1_39 Depth=2
	and	w19, w19, #0xff
	tbnz	w19, #1, LBB1_48
LBB1_41:                                ; %else112
                                        ;   in Loop: Header=BB1_39 Depth=2
	tbnz	w19, #2, LBB1_49
LBB1_42:                                ; %else115
                                        ;   in Loop: Header=BB1_39 Depth=2
	tbnz	w19, #3, LBB1_50
LBB1_43:                                ; %else118
                                        ;   in Loop: Header=BB1_39 Depth=2
	tbnz	w19, #4, LBB1_51
LBB1_44:                                ; %else121
                                        ;   in Loop: Header=BB1_39 Depth=2
	tbnz	w19, #5, LBB1_52
LBB1_45:                                ; %else124
                                        ;   in Loop: Header=BB1_39 Depth=2
	tbnz	w19, #6, LBB1_53
LBB1_46:                                ; %else127
                                        ;   in Loop: Header=BB1_39 Depth=2
	tbz	w19, #7, LBB1_38
	b	LBB1_54
LBB1_47:                                ; %cond.load108
                                        ;   in Loop: Header=BB1_39 Depth=2
	ld1.s	{ v20 }[0], [x4]
	and	w19, w19, #0xff
	tbz	w19, #1, LBB1_41
LBB1_48:                                ; %cond.load111
                                        ;   in Loop: Header=BB1_39 Depth=2
	add	x26, x4, #4
	ld1.s	{ v20 }[1], [x26]
	tbz	w19, #2, LBB1_42
LBB1_49:                                ; %cond.load114
                                        ;   in Loop: Header=BB1_39 Depth=2
	add	x26, x4, #8
	ld1.s	{ v20 }[2], [x26]
	tbz	w19, #3, LBB1_43
LBB1_50:                                ; %cond.load117
                                        ;   in Loop: Header=BB1_39 Depth=2
	add	x26, x4, #12
	ld1.s	{ v20 }[3], [x26]
	tbz	w19, #4, LBB1_44
LBB1_51:                                ; %cond.load120
                                        ;   in Loop: Header=BB1_39 Depth=2
	add	x26, x4, #16
	ld1.s	{ v21 }[0], [x26]
	tbz	w19, #5, LBB1_45
LBB1_52:                                ; %cond.load123
                                        ;   in Loop: Header=BB1_39 Depth=2
	add	x26, x4, #20
	ld1.s	{ v21 }[1], [x26]
	tbz	w19, #6, LBB1_46
LBB1_53:                                ; %cond.load126
                                        ;   in Loop: Header=BB1_39 Depth=2
	add	x26, x4, #24
	ld1.s	{ v21 }[2], [x26]
	tbz	w19, #7, LBB1_38
LBB1_54:                                ; %cond.load129
                                        ;   in Loop: Header=BB1_39 Depth=2
	add	x4, x4, #28
	ld1.s	{ v21 }[3], [x4]
	b	LBB1_38
LBB1_55:                                ; %direct.false174.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
Lloh6:
	adrp	x12, lCPI1_3@PAGE
Lloh7:
	ldr	q20, [x12, lCPI1_3@PAGEOFF]
	and.16b	v21, v0, v20
Lloh8:
	adrp	x12, lCPI1_4@PAGE
Lloh9:
	ldr	q20, [x12, lCPI1_4@PAGEOFF]
	and.16b	v22, v1, v20
Lloh10:
	adrp	x12, lCPI1_6@PAGE
Lloh11:
	ldr	q20, [x12, lCPI1_6@PAGEOFF]
	and.16b	v20, v1, v20
	fadd.4s	v5, v5, v18
	fadd.4s	v4, v4, v17
	fadd.4s	v17, v4, v19
	fadd.4s	v4, v5, v6
	fadd.4s	v4, v4, v16
	fadd.4s	v5, v17, v7
	fmov	w12, s22
	add	x3, sp, #136
	bfxil	x3, x12, #0, #3
	str	d3, [sp, #136]
	ldrb	w3, [x3]
	add	x4, sp, #688
	orr	x12, x4, x12, lsl #2
	stp	q5, q4, [x23, #416]
	ldr	s3, [x12]
	tst	w9, w3
	mov.s	w12, v22[1]
	fcsel	s6, s3, s8, ne
	add	x3, sp, #136
	bfxil	x3, x12, #0, #3
	ldrb	w12, [x3]
	and	w12, w14, w12
	str	q5, [x23, #384]
	ldr	s3, [sp, #656]
	tst	w12, #0x1
	fcsel	s3, s3, s8, ne
	mov.s	w12, v22[2]
	add	x3, sp, #136
	bfxil	x3, x12, #0, #3
	add	x4, sp, #624
	orr	x12, x4, x12, lsl #2
	ldrb	w3, [x3]
	and	w3, w1, w3
	stp	q5, q4, [x23, #352]
	ldr	s7, [x12]
	tst	w3, #0x1
	fcsel	s7, s7, s8, ne
	mov.s	w12, v22[3]
	add	x3, sp, #136
	bfxil	x3, x12, #0, #3
	add	x4, sp, #592
	orr	x12, x4, x12, lsl #2
	ldrb	w3, [x3]
	and	w3, w2, w3
	stp	q5, q4, [x23, #320]
	ldr	s16, [x12]
	tst	w3, #0x1
	fcsel	s16, s16, s8, ne
	fmov	w12, s21
	add	x3, sp, #136
	bfxil	x3, x12, #0, #3
	ldrb	w3, [x3]
	and	w3, w15, w3
	stp	q5, q4, [x23, #288]
	add	x4, sp, #560
	ldr	s17, [x4, w12, uxtw #2]
	tst	w3, #0x1
	fcsel	s17, s17, s8, ne
	mov.s	w12, v21[1]
	add	x3, sp, #136
	bfxil	x3, x12, #0, #3
	ldrb	w3, [x3]
	and	w3, w16, w3
	stp	q5, q4, [x23, #256]
	add	x4, sp, #528
	ldr	s18, [x4, w12, uxtw #2]
	tst	w3, #0x1
	fcsel	s18, s18, s8, ne
	mov.s	w12, v21[2]
	add	x3, sp, #136
	bfxil	x3, x12, #0, #3
	ldrb	w3, [x3]
	and	w3, w17, w3
	stp	q5, q4, [x23, #224]
	add	x4, sp, #496
	ldr	s19, [x4, w12, uxtw #2]
	tst	w3, #0x1
	fcsel	s19, s19, s8, ne
	mov.s	w12, v21[3]
	add	x3, sp, #136
	bfxil	x3, x12, #0, #3
	ldrb	w3, [x3]
	and	w3, w0, w3
	stp	q5, q4, [x23, #192]
	add	x4, sp, #464
	ldr	s21, [x4, w12, uxtw #2]
	tst	w3, #0x1
	fcsel	s21, s21, s8, ne
	mov.s	v6[1], v3[0]
	mov.s	v6[2], v7[0]
	mov.s	v6[3], v16[0]
	mov.s	v17[1], v18[0]
	mov.s	v17[2], v19[0]
	mov.s	v17[3], v21[0]
	fadd.4s	v3, v4, v17
	fadd.4s	v4, v5, v6
	fmov	w12, s20
	add	x3, sp, #136
	bfxil	x3, x12, #0, #3
	ldrb	w3, [x3]
	add	x4, sp, #432
	orr	x12, x4, x12, lsl #2
	stp	q4, q3, [x23, #160]
	ldr	s5, [x12]
	tst	w9, w3
	mov.s	w12, v20[1]
	add	x3, sp, #136
	bfxil	x3, x12, #0, #3
	ldrb	w3, [x3]
	and	w14, w14, w3
	fcsel	s5, s5, s8, ne
	add	x3, sp, #400
	orr	x12, x3, x12, lsl #2
	stp	q4, q3, [x23, #128]
	ldr	s6, [x12]
	tst	w14, #0x1
	mov.s	w12, v20[2]
	add	x14, sp, #136
	bfxil	x14, x12, #0, #3
	fcsel	s6, s6, s8, ne
	ldrb	w12, [x14]
	and	w12, w1, w12
	str	q4, [x23, #96]
	tst	w12, #0x1
	mov.s	w12, v20[3]
	add	x14, sp, #136
	bfxil	x14, x12, #0, #3
	ldrb	w14, [x14]
	and	w14, w2, w14
Lloh12:
	adrp	x1, lCPI1_5@PAGE
Lloh13:
	ldr	q7, [x1, lCPI1_5@PAGEOFF]
	and.16b	v18, v0, v7
	ldr	s7, [sp, #368]
	fcsel	s7, s7, s8, ne
	add	x1, sp, #336
	orr	x12, x1, x12, lsl #2
	stp	q4, q3, [x23, #64]
	ldr	s16, [x12]
	tst	w14, #0x1
	fmov	w12, s18
	add	x14, sp, #136
	bfxil	x14, x12, #0, #3
	ldrb	w14, [x14]
	and	w14, w15, w14
	fcsel	s16, s16, s8, ne
	stp	q4, q3, [x23, #32]
	add	x15, sp, #304
	ldr	s17, [x15, w12, uxtw #2]
	tst	w14, #0x1
	mov.s	w12, v18[1]
	add	x14, sp, #136
	bfxil	x14, x12, #0, #3
	ldrb	w14, [x14]
	and	w14, w16, w14
	fcsel	s17, s17, s8, ne
	stp	q4, q3, [x23]
	ldr	s19, [x23, w12, uxtw #2]
	tst	w14, #0x1
	mov.s	w12, v18[2]
	add	x14, sp, #136
	bfxil	x14, x12, #0, #3
	ldrb	w14, [x14]
	and	w14, w17, w14
	fcsel	s19, s19, s8, ne
	stp	q4, q3, [sp, #240]
	add	x15, sp, #240
	ldr	s20, [x15, w12, uxtw #2]
	tst	w14, #0x1
	mov.s	w12, v18[3]
	add	x14, sp, #136
	bfxil	x14, x12, #0, #3
	ldrb	w14, [x14]
	and	w14, w0, w14
	movi.4s	v18, #4
	and.16b	v18, v1, v18
	fcsel	s20, s20, s8, ne
	stp	q4, q3, [sp, #208]
	add	x15, sp, #208
	ldr	s21, [x15, w12, uxtw #2]
	tst	w14, #0x1
	fcsel	s21, s21, s8, ne
	fmov	w12, s18
	add	x14, sp, #136
	orr	x14, x14, x12
	ldrb	w14, [x14]
	tst	w9, w14
	mov.s	v17[1], v19[0]
	mov.s	v17[2], v20[0]
	mov.s	v17[3], v21[0]
	mov.s	v5[1], v6[0]
	mov.s	v5[2], v7[0]
	mov.s	v5[3], v16[0]
	fadd.4s	v4, v4, v5
	fadd.4s	v3, v3, v17
	stp	q4, q3, [sp, #176]
	add	x9, sp, #176
	ldr	s3, [x9, w12, uxtw #2]
	fcsel	s3, s3, s8, ne
	tst	w11, #0x1
	fadd	s3, s4, s3
	fcsel	s4, s3, s8, ne
	ldp	w9, w11, [sp, #32]              ; 8-byte Folded Reload
	tst	w11, #0x1
	fcsel	s5, s3, s8, ne
	tst	w9, #0x1
	fcsel	s6, s3, s8, ne
	tst	w5, #0x1
	fcsel	s7, s3, s8, ne
	tst	w13, #0x1
	fcsel	s16, s3, s8, ne
	tst	w6, #0x1
	fcsel	s17, s3, s8, ne
	tst	w7, #0x1
	fcsel	s18, s3, s8, ne
	tst	w30, #0x1
	fcsel	s3, s3, s8, ne
	mov.s	v4[1], v5[0]
	mov.s	v4[2], v6[0]
	mov.s	v4[3], v7[0]
	mov.s	v16[1], v17[0]
	mov.s	v16[2], v18[0]
	mov.s	v16[3], v3[0]
	stp	q4, q16, [sp, #144]
	and	x9, x10, #0x7
	add	x10, sp, #144
	ldr	s3, [x10, x9, lsl #2]
	ldr	x15, [sp, #48]                  ; 8-byte Reload
	subs	x9, x15, x8
	cset	w10, hs
	cmp	x9, #3071
	csel	w9, wzr, w10, ls
	subs	x10, x8, x15
	lsr	x10, x10, #10
	mov	w11, #386                       ; =0x182
	ccmp	x10, x11, #0, hs
	fadd	s3, s3, s8
	mov	w10, #1145044992                ; =0x44400000
	fmov	s4, w10
	fdiv	s3, s3, s4
	mov	w10, #50604                     ; =0xc5ac
	movk	w10, #14119, lsl #16
	fmov	s4, w10
	fadd	s3, s3, s4
	fsqrt	s3, s3
	b.hi	LBB1_75
; %bb.56:                               ; %direct.false174.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #0, LBB1_75
; %bb.57:                               ; %direct.true225.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	add	x14, sp, #1104
	b	LBB1_59
LBB1_58:                                ; %else196
                                        ;   in Loop: Header=BB1_59 Depth=2
	add	x10, x14, x9
	stp	q4, q5, [x10]
	add	x9, x9, #32
	cmp	x9, #3072
	b.eq	LBB1_109
LBB1_59:                                ; %direct.true225.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s2
	add	x10, x8, x9
	add	x12, x14, x9
	ldr	q4, [x12]
	tbnz	w11, #0, LBB1_67
; %bb.60:                               ; %else175
                                        ;   in Loop: Header=BB1_59 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_68
LBB1_61:                                ; %else178
                                        ;   in Loop: Header=BB1_59 Depth=2
	tbnz	w11, #2, LBB1_69
LBB1_62:                                ; %else181
                                        ;   in Loop: Header=BB1_59 Depth=2
	tbnz	w11, #3, LBB1_70
LBB1_63:                                ; %else184
                                        ;   in Loop: Header=BB1_59 Depth=2
	ldr	q5, [x12, #16]
	tbnz	w11, #4, LBB1_71
LBB1_64:                                ; %else187
                                        ;   in Loop: Header=BB1_59 Depth=2
	tbnz	w11, #5, LBB1_72
LBB1_65:                                ; %else190
                                        ;   in Loop: Header=BB1_59 Depth=2
	tbnz	w11, #6, LBB1_73
LBB1_66:                                ; %else193
                                        ;   in Loop: Header=BB1_59 Depth=2
	tbz	w11, #7, LBB1_58
	b	LBB1_74
LBB1_67:                                ; %cond.load174
                                        ;   in Loop: Header=BB1_59 Depth=2
	ld1.s	{ v4 }[0], [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_61
LBB1_68:                                ; %cond.load177
                                        ;   in Loop: Header=BB1_59 Depth=2
	add	x13, x10, #4
	ld1.s	{ v4 }[1], [x13]
	tbz	w11, #2, LBB1_62
LBB1_69:                                ; %cond.load180
                                        ;   in Loop: Header=BB1_59 Depth=2
	add	x13, x10, #8
	ld1.s	{ v4 }[2], [x13]
	tbz	w11, #3, LBB1_63
LBB1_70:                                ; %cond.load183
                                        ;   in Loop: Header=BB1_59 Depth=2
	add	x13, x10, #12
	ld1.s	{ v4 }[3], [x13]
	ldr	q5, [x12, #16]
	tbz	w11, #4, LBB1_64
LBB1_71:                                ; %cond.load186
                                        ;   in Loop: Header=BB1_59 Depth=2
	add	x12, x10, #16
	ld1.s	{ v5 }[0], [x12]
	tbz	w11, #5, LBB1_65
LBB1_72:                                ; %cond.load189
                                        ;   in Loop: Header=BB1_59 Depth=2
	add	x12, x10, #20
	ld1.s	{ v5 }[1], [x12]
	tbz	w11, #6, LBB1_66
LBB1_73:                                ; %cond.load192
                                        ;   in Loop: Header=BB1_59 Depth=2
	add	x12, x10, #24
	ld1.s	{ v5 }[2], [x12]
	tbz	w11, #7, LBB1_58
LBB1_74:                                ; %cond.load195
                                        ;   in Loop: Header=BB1_59 Depth=2
	add	x10, x10, #28
	ld1.s	{ v5 }[3], [x10]
	b	LBB1_58
LBB1_75:                                ; %direct.schedule.17.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	dup.4s	v3, v3[0]
	ldr	x10, [sp, #40]                  ; 8-byte Reload
	add	x10, x15, x10
	b	LBB1_77
LBB1_76:                                ; %else172
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x9, x9, #32
	cmp	x9, #3072
	b.eq	LBB1_2
LBB1_77:                                ; %direct.true195.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w12, s2
	add	x11, x8, x9
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w12, #0, LBB1_94
; %bb.78:                               ; %else134
                                        ;   in Loop: Header=BB1_77 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_95
LBB1_79:                                ; %else137
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w12, #2, LBB1_96
LBB1_80:                                ; %else140
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w12, #3, LBB1_97
LBB1_81:                                ; %else143
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w12, #4, LBB1_98
LBB1_82:                                ; %else146
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w12, #5, LBB1_99
LBB1_83:                                ; %else149
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w12, #6, LBB1_100
LBB1_84:                                ; %else152
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbz	w12, #7, LBB1_86
LBB1_85:                                ; %cond.load154
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x11, x11, #28
	ld1.s	{ v4 }[3], [x11]
LBB1_86:                                ; %else155
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x13, x25, x9
	ldr	q6, [x13]
	and.16b	v6, v1, v6
	fdiv.4s	v6, v6, v3
	add	x14, x21, x9
	ldr	q7, [x14]
	and.16b	v7, v1, v7
	fmul.4s	v6, v6, v7
	fmov	w12, s2
	fadd.4s	v5, v5, v6
	add	x11, x10, x9
	tbnz	w12, #0, LBB1_101
; %bb.87:                               ; %else158
                                        ;   in Loop: Header=BB1_77 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_102
LBB1_88:                                ; %else160
                                        ;   in Loop: Header=BB1_77 Depth=2
	ldr	q7, [x13, #16]
	ldr	q6, [x14, #16]
	tbnz	w12, #2, LBB1_103
LBB1_89:                                ; %else162
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w12, #3, LBB1_104
LBB1_90:                                ; %else164
                                        ;   in Loop: Header=BB1_77 Depth=2
	and.16b	v5, v0, v7
	fdiv.4s	v5, v5, v3
	and.16b	v6, v0, v6
	fmul.4s	v5, v5, v6
	fadd.4s	v4, v4, v5
	tbnz	w12, #4, LBB1_105
LBB1_91:                                ; %else166
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w12, #5, LBB1_106
LBB1_92:                                ; %else168
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w12, #6, LBB1_107
LBB1_93:                                ; %else170
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbz	w12, #7, LBB1_76
	b	LBB1_108
LBB1_94:                                ; %cond.load133
                                        ;   in Loop: Header=BB1_77 Depth=2
	ldr	s5, [x11]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_79
LBB1_95:                                ; %cond.load136
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x13, x11, #4
	ld1.s	{ v5 }[1], [x13]
	tbz	w12, #2, LBB1_80
LBB1_96:                                ; %cond.load139
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x13, x11, #8
	ld1.s	{ v5 }[2], [x13]
	tbz	w12, #3, LBB1_81
LBB1_97:                                ; %cond.load142
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x13, x11, #12
	ld1.s	{ v5 }[3], [x13]
	tbz	w12, #4, LBB1_82
LBB1_98:                                ; %cond.load145
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x13, x11, #16
	ld1.s	{ v4 }[0], [x13]
	tbz	w12, #5, LBB1_83
LBB1_99:                                ; %cond.load148
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x13, x11, #20
	ld1.s	{ v4 }[1], [x13]
	tbz	w12, #6, LBB1_84
LBB1_100:                               ; %cond.load151
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x13, x11, #24
	ld1.s	{ v4 }[2], [x13]
	tbnz	w12, #7, LBB1_85
	b	LBB1_86
LBB1_101:                               ; %cond.store
                                        ;   in Loop: Header=BB1_77 Depth=2
	str	s5, [x11]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_88
LBB1_102:                               ; %cond.store159
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x15, x11, #4
	st1.s	{ v5 }[1], [x15]
	ldr	q7, [x13, #16]
	ldr	q6, [x14, #16]
	tbz	w12, #2, LBB1_89
LBB1_103:                               ; %cond.store161
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x13, x11, #8
	st1.s	{ v5 }[2], [x13]
	tbz	w12, #3, LBB1_90
LBB1_104:                               ; %cond.store163
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x13, x11, #12
	st1.s	{ v5 }[3], [x13]
	and.16b	v5, v0, v7
	fdiv.4s	v5, v5, v3
	and.16b	v6, v0, v6
	fmul.4s	v5, v5, v6
	fadd.4s	v4, v4, v5
	tbz	w12, #4, LBB1_91
LBB1_105:                               ; %cond.store165
                                        ;   in Loop: Header=BB1_77 Depth=2
	str	s4, [x11, #16]
	tbz	w12, #5, LBB1_92
LBB1_106:                               ; %cond.store167
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x13, x11, #20
	st1.s	{ v4 }[1], [x13]
	tbz	w12, #6, LBB1_93
LBB1_107:                               ; %cond.store169
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x13, x11, #24
	st1.s	{ v4 }[2], [x13]
	tbz	w12, #7, LBB1_76
LBB1_108:                               ; %cond.store171
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x11, x11, #28
	st1.s	{ v4 }[3], [x11]
	b	LBB1_76
LBB1_109:                               ; %direct.schedule.24.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	dup.4s	v3, v3[0]
	ldr	x9, [sp, #40]                   ; 8-byte Reload
	add	x9, x15, x9
	b	LBB1_111
LBB1_110:                               ; %else214
                                        ;   in Loop: Header=BB1_111 Depth=2
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB1_2
LBB1_111:                               ; %direct.true244.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s2
	add	x12, x25, x8
	ldr	q4, [x12]
	and.16b	v4, v1, v4
	fdiv.4s	v4, v4, v3
	add	x13, x21, x8
	ldr	q5, [x13]
	and.16b	v5, v1, v5
	fmul.4s	v5, v4, v5
	add	x10, x14, x8
	ldp	q6, q4, [x10]
	and.16b	v6, v1, v6
	fadd.4s	v5, v5, v6
	add	x10, x9, x8
	tbnz	w11, #0, LBB1_120
; %bb.112:                              ; %else200
                                        ;   in Loop: Header=BB1_111 Depth=2
	and	w11, w11, #0xff
	ldr	q7, [x12, #16]
	ldr	q6, [x13, #16]
	tbnz	w11, #1, LBB1_121
LBB1_113:                               ; %else202
                                        ;   in Loop: Header=BB1_111 Depth=2
	tbnz	w11, #2, LBB1_122
LBB1_114:                               ; %else204
                                        ;   in Loop: Header=BB1_111 Depth=2
	tbz	w11, #3, LBB1_116
LBB1_115:                               ; %cond.store205
                                        ;   in Loop: Header=BB1_111 Depth=2
	add	x12, x10, #12
	st1.s	{ v5 }[3], [x12]
LBB1_116:                               ; %else206
                                        ;   in Loop: Header=BB1_111 Depth=2
	and.16b	v5, v0, v7
	fdiv.4s	v5, v5, v3
	and.16b	v6, v0, v6
	fmul.4s	v5, v5, v6
	and.16b	v4, v0, v4
	fadd.4s	v4, v5, v4
	tbnz	w11, #4, LBB1_123
; %bb.117:                              ; %else208
                                        ;   in Loop: Header=BB1_111 Depth=2
	tbnz	w11, #5, LBB1_124
LBB1_118:                               ; %else210
                                        ;   in Loop: Header=BB1_111 Depth=2
	tbnz	w11, #6, LBB1_125
LBB1_119:                               ; %else212
                                        ;   in Loop: Header=BB1_111 Depth=2
	tbz	w11, #7, LBB1_110
	b	LBB1_126
LBB1_120:                               ; %cond.store199
                                        ;   in Loop: Header=BB1_111 Depth=2
	str	s5, [x10]
	and	w11, w11, #0xff
	ldr	q7, [x12, #16]
	ldr	q6, [x13, #16]
	tbz	w11, #1, LBB1_113
LBB1_121:                               ; %cond.store201
                                        ;   in Loop: Header=BB1_111 Depth=2
	add	x12, x10, #4
	st1.s	{ v5 }[1], [x12]
	tbz	w11, #2, LBB1_114
LBB1_122:                               ; %cond.store203
                                        ;   in Loop: Header=BB1_111 Depth=2
	add	x12, x10, #8
	st1.s	{ v5 }[2], [x12]
	tbnz	w11, #3, LBB1_115
	b	LBB1_116
LBB1_123:                               ; %cond.store207
                                        ;   in Loop: Header=BB1_111 Depth=2
	str	s4, [x10, #16]
	tbz	w11, #5, LBB1_118
LBB1_124:                               ; %cond.store209
                                        ;   in Loop: Header=BB1_111 Depth=2
	add	x12, x10, #20
	st1.s	{ v4 }[1], [x12]
	tbz	w11, #6, LBB1_119
LBB1_125:                               ; %cond.store211
                                        ;   in Loop: Header=BB1_111 Depth=2
	add	x12, x10, #24
	st1.s	{ v4 }[2], [x12]
	tbz	w11, #7, LBB1_110
LBB1_126:                               ; %cond.store213
                                        ;   in Loop: Header=BB1_111 Depth=2
	add	x10, x10, #28
	st1.s	{ v4 }[3], [x10]
	b	LBB1_110
LBB1_127:                               ; %block.batch.exit
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #1104
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #112              ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
.subsections_via_symbols

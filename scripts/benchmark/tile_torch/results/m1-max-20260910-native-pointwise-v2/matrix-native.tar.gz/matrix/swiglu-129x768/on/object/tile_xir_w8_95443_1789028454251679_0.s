	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d9, d8, [sp, #-80]!             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #16]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2048
	ldr	x11, [x0]
	ldr	x22, [x0, #16]
	ldr	x21, [x0, #48]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	subs	x9, x11, x21
	cset	w10, hs
	lsr	x9, x9, #10
	cmp	x9, #386
	csel	w9, wzr, w10, ls
	subs	x10, x21, x11
	cset	w12, hs
	lsr	x10, x10, #10
	cmp	x10, #386
	csel	w10, wzr, w12, ls
	orr	w9, w9, w10
	subs	x10, x22, x21
	cset	w12, hs
	lsr	x10, x10, #10
	cmp	x10, #386
	csel	w10, wzr, w12, ls
	subs	x12, x21, x22
	cset	w13, hs
	lsr	x12, x12, #10
	cmp	x12, #386
	csel	w12, wzr, w13, ls
	orr	w10, w10, w12
	mov	w12, #3072                      ; =0xc00
	umull	x23, w8, w12
	cmp	w9, #1
	ccmp	w10, #0, #4, eq
	b.ne	LBB0_3
; %bb.1:                                ; %direct.schedule.6.preheader
	add	x19, sp, #3072
	add	x0, sp, #3072
	add	x1, x11, x23
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	x20, sp
	mov	x0, sp
	add	x1, x22, x23
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	mov	w9, #1120927744                 ; =0x42d00000
	dup.4s	v0, w9
	mov	w9, #-1027080192                ; =0xc2c80000
	dup.4s	v1, w9
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v2, w9
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v3, w9
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v4, w9
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v5, w9
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v6, w9
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v7, w9
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v16, w9
	add	x9, x21, x23
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v17, w10
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	movi.4s	v20, #63, lsl #24
	fmov.4s	v21, #1.00000000
	mvni.4s	v22, #127, msl #16
	fneg.4s	v22, v22
	mvni.4s	v23, #63, msl #16
	fneg.4s	v23, v23
LBB0_2:                                 ; %direct.true61
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x19, x8
	ldp	q24, q25, [x10]
	fneg.4s	v26, v25
	fneg.4s	v27, v24
	fcmge.4s	v28, v0, v24
	fcmge.4s	v29, v0, v25
	fcmge.4s	v30, v24, v1
	fcmge.4s	v31, v25, v1
	and.16b	v29, v29, v31
	and.16b	v28, v28, v30
	and.16b	v27, v28, v27
	and.16b	v26, v29, v26
	fmul.4s	v28, v26, v2
	fmul.4s	v29, v27, v2
	mov.16b	v30, v19
	bsl.16b	v30, v18, v29
	mov.16b	v31, v19
	bsl.16b	v31, v18, v28
	fadd.4s	v28, v28, v31
	fadd.4s	v29, v29, v30
	fsub.4s	v29, v29, v30
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v28, v28
	fcvtzs.4s	v29, v29
	scvtf.4s	v30, v29
	scvtf.4s	v31, v28
	fmul.4s	v8, v31, v3
	fmul.4s	v9, v30, v3
	fadd.4s	v27, v27, v9
	fadd.4s	v26, v26, v8
	fmul.4s	v30, v30, v4
	fmul.4s	v31, v31, v4
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	fmul.4s	v30, v27, v5
	fmul.4s	v31, v26, v5
	fadd.4s	v31, v31, v6
	fadd.4s	v30, v30, v6
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v7
	fadd.4s	v30, v30, v7
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v16
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v17
	fadd.4s	v30, v30, v17
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v20
	fadd.4s	v30, v30, v20
	fmul.4s	v8, v26, v26
	fmul.4s	v9, v27, v27
	fmul.4s	v30, v9, v30
	fmul.4s	v31, v8, v31
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	sshr.4s	v30, v29, #1
	fadd.4s	v27, v27, v21
	sshr.4s	v31, v28, #1
	shl.4s	v8, v31, #23
	shl.4s	v9, v30, #23
	add.4s	v9, v9, v21
	add.4s	v8, v8, v21
	fadd.4s	v26, v26, v21
	fmul.4s	v26, v26, v8
	sub.4s	v28, v28, v31
	sub.4s	v29, v29, v30
	shl.4s	v29, v29, #23
	shl.4s	v28, v28, #23
	fmul.4s	v27, v27, v9
	add.4s	v28, v28, v21
	add.4s	v29, v29, v21
	fmul.4s	v27, v27, v29
	fmul.4s	v26, v26, v28
	fcmgt.4s	v28, v25, v0
	fcmgt.4s	v29, v24, v0
	fcmgt.4s	v30, v1, v24
	fcmgt.4s	v31, v1, v25
	fcmeq.4s	v8, v25, v25
	fadd.4s	v26, v26, v21
	fadd.4s	v27, v27, v21
	fcmeq.4s	v9, v24, v24
	bit.16b	v27, v21, v29
	bit.16b	v26, v21, v28
	bit.16b	v26, v22, v31
	bit.16b	v27, v22, v30
	bif.16b	v27, v23, v9
	bif.16b	v26, v23, v8
	fdiv.4s	v25, v25, v26
	fdiv.4s	v24, v24, v27
	add	x10, x20, x8
	ldp	q27, q26, [x10]
	fmul.4s	v24, v27, v24
	fmul.4s	v25, v26, v25
	add	x10, x9, x8
	stp	q24, q25, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_2
	b	LBB0_5
LBB0_3:                                 ; %direct.true19.preheader
	mov	x8, #0                          ; =0x0
	mov	w9, #1120927744                 ; =0x42d00000
	dup.4s	v0, w9
	mov	w9, #-1027080192                ; =0xc2c80000
	dup.4s	v1, w9
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v2, w9
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v3, w9
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v4, w9
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v5, w9
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v6, w9
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v7, w9
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v16, w9
	add	x9, x21, x23
	add	x10, x22, x23
	add	x11, x11, x23
	mov	w12, #43691                     ; =0xaaab
	movk	w12, #15914, lsl #16
	dup.4s	v17, w12
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	movi.4s	v20, #63, lsl #24
	fmov.4s	v21, #1.00000000
	mvni.4s	v22, #127, msl #16
	fneg.4s	v22, v22
	mvni.4s	v23, #63, msl #16
	fneg.4s	v23, v23
LBB0_4:                                 ; %direct.true19
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x11, x8
	ldp	q24, q25, [x12]
	fneg.4s	v26, v25
	fneg.4s	v27, v24
	fcmge.4s	v28, v0, v24
	fcmge.4s	v29, v0, v25
	fcmge.4s	v30, v24, v1
	fcmge.4s	v31, v25, v1
	and.16b	v29, v29, v31
	and.16b	v28, v28, v30
	and.16b	v27, v28, v27
	and.16b	v26, v29, v26
	fmul.4s	v28, v26, v2
	fmul.4s	v29, v27, v2
	mov.16b	v30, v19
	bsl.16b	v30, v18, v29
	mov.16b	v31, v19
	bsl.16b	v31, v18, v28
	fadd.4s	v28, v28, v31
	fadd.4s	v29, v29, v30
	fsub.4s	v29, v29, v30
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v28, v28
	fcvtzs.4s	v29, v29
	scvtf.4s	v30, v29
	scvtf.4s	v31, v28
	fmul.4s	v8, v31, v3
	fmul.4s	v9, v30, v3
	fadd.4s	v27, v27, v9
	fadd.4s	v26, v26, v8
	fmul.4s	v30, v30, v4
	fmul.4s	v31, v31, v4
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	fmul.4s	v30, v27, v5
	fmul.4s	v31, v26, v5
	fadd.4s	v31, v31, v6
	fadd.4s	v30, v30, v6
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v7
	fadd.4s	v30, v30, v7
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v16
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v17
	fadd.4s	v30, v30, v17
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v20
	fadd.4s	v30, v30, v20
	fmul.4s	v8, v26, v26
	fmul.4s	v9, v27, v27
	fmul.4s	v30, v9, v30
	fmul.4s	v31, v8, v31
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	sshr.4s	v30, v29, #1
	fadd.4s	v27, v27, v21
	sshr.4s	v31, v28, #1
	shl.4s	v8, v31, #23
	shl.4s	v9, v30, #23
	add.4s	v9, v9, v21
	add.4s	v8, v8, v21
	fadd.4s	v26, v26, v21
	fmul.4s	v26, v26, v8
	sub.4s	v28, v28, v31
	sub.4s	v29, v29, v30
	shl.4s	v29, v29, #23
	shl.4s	v28, v28, #23
	fmul.4s	v27, v27, v9
	add.4s	v28, v28, v21
	add.4s	v29, v29, v21
	fmul.4s	v27, v27, v29
	fmul.4s	v26, v26, v28
	fcmgt.4s	v28, v25, v0
	fcmgt.4s	v29, v24, v0
	fcmgt.4s	v30, v1, v24
	fcmgt.4s	v31, v1, v25
	fcmeq.4s	v8, v25, v25
	fadd.4s	v26, v26, v21
	fadd.4s	v27, v27, v21
	fcmeq.4s	v9, v24, v24
	bit.16b	v27, v21, v29
	bit.16b	v26, v21, v28
	bit.16b	v26, v22, v31
	bit.16b	v27, v22, v30
	bif.16b	v27, v23, v9
	bif.16b	v26, v23, v8
	fdiv.4s	v25, v25, v26
	fdiv.4s	v24, v24, v27
	add	x12, x10, x8
	ldp	q27, q26, [x12]
	fmul.4s	v24, v27, v24
	fmul.4s	v25, v26, v25
	add	x12, x9, x8
	stp	q24, q25, [x12]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_4
LBB0_5:                                 ; %common.ret
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2048
	ldp	x29, x30, [sp, #64]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #48]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #80               ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d13, d12, [sp, #-144]!          ; 16-byte Folded Spill
	stp	d11, d10, [sp, #16]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #32]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2192
	str	x0, [sp, #128]                  ; 8-byte Spill
	cbz	w3, LBB1_119
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x19, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	ldp	w28, w8, [x2, #44]
	str	w8, [sp, #124]                  ; 4-byte Spill
	ldp	w27, w25, [x2]
	ldp	w26, w8, [x2, #8]
	str	x8, [sp, #112]                  ; 8-byte Spill
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q8, [x8, lCPI1_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh4:
	adrp	x8, lCPI1_2@PAGE
Lloh5:
	ldr	q9, [x8, lCPI1_2@PAGEOFF]
	mvni.4s	v0, #127, msl #16
	fneg.4s	v12, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v13, v0
	add	x23, sp, #3216
	add	x24, sp, #144
	str	w3, [sp, #108]                  ; 4-byte Spill
	str	w28, [sp, #12]                  ; 4-byte Spill
	stp	q9, q8, [sp, #64]               ; 32-byte Folded Spill
	stp	q13, q12, [sp, #32]             ; 32-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w19, [sp, #108]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w27, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w27, wzr, w27, eq
	cinc	w9, w25, eq
	ldr	w10, [sp, #124]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w25, wzr, w9, ne
	add	w26, w26, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_119
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_67 Depth 2
                                        ;     Child Loop BB1_85 Depth 2
                                        ;     Child Loop BB1_103 Depth 2
                                        ;     Child Loop BB1_17 Depth 2
	ubfiz	x8, x27, #5, #32
	ldr	x12, [sp, #112]                 ; 8-byte Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	stp	w27, w25, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x12, #2, hi
	csel	x21, x10, xzr, ls
	cmp	x21, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x21, [sp, #128]                 ; 8-byte Reload
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x19, x21, #3
	cbz	x19, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #128]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #128]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #128]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x28, [sp, #128]                 ; 8-byte Reload
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x28
	ldr	w28, [sp, #12]                  ; 4-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w21, #0x7
	movi.4s	v30, #75, lsl #24
	mvni.4s	v31, #128, lsl #24
	ldp	q9, q8, [sp, #64]               ; 32-byte Folded Reload
	movi.4s	v10, #63, lsl #24
	fmov.4s	v11, #1.00000000
	ldp	q13, q12, [sp, #32]             ; 32-byte Folded Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v0, w8
	ldr	q1, [sp, #16]                   ; 16-byte Reload
	cmhi.4s	v1, v0, v1
	cmhi.4s	v2, v0, v8
	uzp1.8h	v21, v2, v1
	umaxv.8h	h3, v21
	fmov	w8, s3
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #128]                  ; 8-byte Reload
	ldr	x12, [x8]
	ldr	x10, [x8, #16]
	ldr	x9, [x8, #48]
	ubfiz	w8, w27, #2, #27
	orr	w8, w8, w19
	fmov	s3, w8
	and.16b	v2, v2, v3
	subs	x8, x12, x9
	cset	w11, hs
	mov	w15, #3071                      ; =0xbff
	movk	w15, #6, lsl #16
	cmp	x8, x15
	csel	w8, wzr, w11, ls
	subs	x11, x9, x12
	cset	w13, hs
	cmp	x11, x15
	csel	w11, wzr, w13, ls
	orr	w14, w8, w11
	subs	x8, x10, x9
	cset	w11, hs
	cmp	x8, x15
	csel	w8, wzr, w11, ls
	subs	x11, x9, x10
	cset	w13, hs
	cmp	x11, x15
	csel	w13, wzr, w13, ls
	fmov	w11, s2
	mov	w15, #-1026555904               ; =0xc2d00000
	dup.4s	v2, w15
	mov	w15, #1120403456                ; =0x42c80000
	dup.4s	v3, w15
	mov	w15, #43579                     ; =0xaa3b
	movk	w15, #16312, lsl #16
	dup.4s	v4, w15
	mov	w15, #29184                     ; =0x7200
	movk	w15, #48945, lsl #16
	dup.4s	v5, w15
	mov	w15, #48782                     ; =0xbe8e
	movk	w15, #46527, lsl #16
	dup.4s	v6, w15
	mov	w15, #11226                     ; =0x2bda
	movk	w15, #14672, lsl #16
	dup.4s	v7, w15
	mov	w15, #38601                     ; =0x96c9
	movk	w15, #15030, lsl #16
	dup.4s	v16, w15
	mov	w15, #34982                     ; =0x88a6
	movk	w15, #15368, lsl #16
	dup.4s	v17, w15
	mov	w15, #3072                      ; =0xc00
	umull	x11, w11, w15
	mov	w15, #43642                     ; =0xaa7a
	movk	w15, #15658, lsl #16
	dup.4s	v18, w15
	mov	w15, #43691                     ; =0xaaab
	movk	w15, #15914, lsl #16
	dup.4s	v19, w15
	cmp	w14, #1
	b.ne	LBB1_65
; %bb.14:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w8, w8, w13
	cbz	w8, LBB1_65
; %bb.15:                               ; %direct.true19.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x9, x11
	add	x10, x10, x11
	add	x11, x12, x11
	and.16b	v20, v21, v9
	addv.8h	h20, v20
	fmov	w12, s20
	b	LBB1_17
LBB1_16:                                ; %else86
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB1_2
LBB1_17:                                ; %direct.true19.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x13, x11, x8
	movi.2d	v21, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w12, #0, LBB1_44
; %bb.18:                               ; %else
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w14, w12, #0xff
	tbnz	w14, #1, LBB1_45
LBB1_19:                                ; %else26
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #2, LBB1_46
LBB1_20:                                ; %else29
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #3, LBB1_47
LBB1_21:                                ; %else32
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #4, LBB1_48
LBB1_22:                                ; %else35
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #5, LBB1_49
LBB1_23:                                ; %else38
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #6, LBB1_50
LBB1_24:                                ; %else41
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w14, #7, LBB1_26
LBB1_25:                                ; %cond.load43
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x13, x13, #28
	ld1.s	{ v20 }[3], [x13]
LBB1_26:                                ; %else44
                                        ;   in Loop: Header=BB1_17 Depth=2
	cmhi.4s	v25, v0, v8
	uzp1.8h	v22, v25, v1
	and.16b	v22, v22, v9
	addv.8h	h23, v22
	fmov	w14, s23
	add	x13, x10, x8
	movi.2d	v24, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbnz	w14, #0, LBB1_51
; %bb.27:                               ; %else48
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_52
LBB1_28:                                ; %else51
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #2, LBB1_53
LBB1_29:                                ; %else54
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #3, LBB1_54
LBB1_30:                                ; %else57
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #4, LBB1_55
LBB1_31:                                ; %else60
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #5, LBB1_56
LBB1_32:                                ; %else63
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #6, LBB1_57
LBB1_33:                                ; %else66
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w14, #7, LBB1_35
LBB1_34:                                ; %cond.load68
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x13, x13, #28
	ld1.s	{ v22 }[3], [x13]
LBB1_35:                                ; %else69
                                        ;   in Loop: Header=BB1_17 Depth=2
	fneg.4s	v26, v21
	and.16b	v25, v25, v26
	fcmge.4s	v26, v25, v2
	fcmge.4s	v27, v3, v25
	and.16b	v26, v26, v27
	and.16b	v26, v26, v25
	fmul.4s	v27, v26, v4
	mov.16b	v28, v31
	bsl.16b	v28, v30, v27
	fadd.4s	v27, v27, v28
	fsub.4s	v27, v27, v28
	fcvtzs.4s	v27, v27
	scvtf.4s	v28, v27
	fmul.4s	v29, v28, v5
	fadd.4s	v26, v26, v29
	fmul.4s	v28, v28, v6
	fadd.4s	v26, v26, v28
	fmul.4s	v28, v26, v7
	fadd.4s	v28, v28, v16
	fmul.4s	v28, v26, v28
	fadd.4s	v28, v28, v17
	fmul.4s	v28, v26, v28
	fadd.4s	v28, v28, v18
	fmul.4s	v28, v26, v28
	fadd.4s	v28, v28, v19
	fmul.4s	v28, v26, v28
	fadd.4s	v28, v28, v10
	fmul.4s	v29, v26, v26
	fmul.4s	v28, v29, v28
	fadd.4s	v26, v26, v28
	fadd.4s	v26, v26, v11
	sshr.4s	v28, v27, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v11
	fmul.4s	v26, v26, v29
	sub.4s	v27, v27, v28
	shl.4s	v27, v27, #23
	add.4s	v27, v27, v11
	fmul.4s	v26, v26, v27
	fcmgt.4s	v27, v2, v25
	fcmgt.4s	v28, v25, v3
	fcmeq.4s	v25, v25, v25
	fadd.4s	v26, v26, v11
	bit.16b	v26, v11, v27
	bit.16b	v26, v12, v28
	bsl.16b	v25, v26, v13
	fdiv.4s	v21, v21, v25
	fmov	w14, s23
	fmul.4s	v21, v24, v21
	add	x13, x9, x8
	tbnz	w14, #0, LBB1_58
; %bb.36:                               ; %else72
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_59
LBB1_37:                                ; %else74
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #2, LBB1_60
LBB1_38:                                ; %else76
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w14, #3, LBB1_40
LBB1_39:                                ; %cond.store77
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #12
	st1.s	{ v21 }[3], [x15]
LBB1_40:                                ; %else78
                                        ;   in Loop: Header=BB1_17 Depth=2
	fneg.4s	v21, v20
	and.16b	v21, v1, v21
	fcmge.4s	v23, v21, v2
	fcmge.4s	v24, v3, v21
	and.16b	v23, v23, v24
	and.16b	v23, v23, v21
	fmul.4s	v24, v23, v4
	mov.16b	v25, v31
	bsl.16b	v25, v30, v24
	fadd.4s	v24, v24, v25
	fsub.4s	v24, v24, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v5
	fadd.4s	v23, v23, v26
	fmul.4s	v25, v25, v6
	fadd.4s	v23, v23, v25
	fmul.4s	v25, v23, v7
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v18
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v19
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v10
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v23, v23, v11
	sshr.4s	v25, v24, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v11
	fmul.4s	v23, v23, v26
	sub.4s	v24, v24, v25
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v11
	fmul.4s	v23, v23, v24
	fcmgt.4s	v24, v2, v21
	fcmgt.4s	v25, v21, v3
	fcmeq.4s	v21, v21, v21
	fadd.4s	v23, v23, v11
	bit.16b	v23, v11, v24
	bit.16b	v23, v12, v25
	bsl.16b	v21, v23, v13
	fdiv.4s	v20, v20, v21
	fmul.4s	v20, v22, v20
	tbnz	w14, #4, LBB1_61
; %bb.41:                               ; %else80
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #5, LBB1_62
LBB1_42:                                ; %else82
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #6, LBB1_63
LBB1_43:                                ; %else84
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w14, #7, LBB1_16
	b	LBB1_64
LBB1_44:                                ; %cond.load
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldr	s21, [x13]
	and	w14, w12, #0xff
	tbz	w14, #1, LBB1_19
LBB1_45:                                ; %cond.load25
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #4
	ld1.s	{ v21 }[1], [x15]
	tbz	w14, #2, LBB1_20
LBB1_46:                                ; %cond.load28
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #8
	ld1.s	{ v21 }[2], [x15]
	tbz	w14, #3, LBB1_21
LBB1_47:                                ; %cond.load31
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #12
	ld1.s	{ v21 }[3], [x15]
	tbz	w14, #4, LBB1_22
LBB1_48:                                ; %cond.load34
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #16
	ld1.s	{ v20 }[0], [x15]
	tbz	w14, #5, LBB1_23
LBB1_49:                                ; %cond.load37
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #20
	ld1.s	{ v20 }[1], [x15]
	tbz	w14, #6, LBB1_24
LBB1_50:                                ; %cond.load40
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #24
	ld1.s	{ v20 }[2], [x15]
	tbnz	w14, #7, LBB1_25
	b	LBB1_26
LBB1_51:                                ; %cond.load47
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldr	s24, [x13]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_28
LBB1_52:                                ; %cond.load50
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #4
	ld1.s	{ v24 }[1], [x15]
	tbz	w14, #2, LBB1_29
LBB1_53:                                ; %cond.load53
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #8
	ld1.s	{ v24 }[2], [x15]
	tbz	w14, #3, LBB1_30
LBB1_54:                                ; %cond.load56
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #12
	ld1.s	{ v24 }[3], [x15]
	tbz	w14, #4, LBB1_31
LBB1_55:                                ; %cond.load59
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #16
	ld1.s	{ v22 }[0], [x15]
	tbz	w14, #5, LBB1_32
LBB1_56:                                ; %cond.load62
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #20
	ld1.s	{ v22 }[1], [x15]
	tbz	w14, #6, LBB1_33
LBB1_57:                                ; %cond.load65
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #24
	ld1.s	{ v22 }[2], [x15]
	tbnz	w14, #7, LBB1_34
	b	LBB1_35
LBB1_58:                                ; %cond.store
                                        ;   in Loop: Header=BB1_17 Depth=2
	str	s21, [x13]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_37
LBB1_59:                                ; %cond.store73
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #4
	st1.s	{ v21 }[1], [x15]
	tbz	w14, #2, LBB1_38
LBB1_60:                                ; %cond.store75
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #8
	st1.s	{ v21 }[2], [x15]
	tbnz	w14, #3, LBB1_39
	b	LBB1_40
LBB1_61:                                ; %cond.store79
                                        ;   in Loop: Header=BB1_17 Depth=2
	str	s20, [x13, #16]
	tbz	w14, #5, LBB1_42
LBB1_62:                                ; %cond.store81
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #20
	st1.s	{ v20 }[1], [x15]
	tbz	w14, #6, LBB1_43
LBB1_63:                                ; %cond.store83
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #24
	st1.s	{ v20 }[2], [x15]
	tbz	w14, #7, LBB1_16
LBB1_64:                                ; %cond.store85
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x13, x13, #28
	st1.s	{ v20 }[3], [x13]
	b	LBB1_16
LBB1_65:                                ; %direct.schedule.6.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	add	x12, x12, x11
	b	LBB1_67
LBB1_66:                                ; %else110
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x13, x23, x8
	stp	q22, q23, [x13]
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB1_83
LBB1_67:                                ; %direct.true30.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and.16b	v20, v21, v9
	addv.8h	h20, v20
	fmov	w14, s20
	add	x13, x12, x8
	add	x15, x23, x8
	ldr	q22, [x15]
	tbnz	w14, #0, LBB1_75
; %bb.68:                               ; %else89
                                        ;   in Loop: Header=BB1_67 Depth=2
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_76
LBB1_69:                                ; %else92
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbnz	w14, #2, LBB1_77
LBB1_70:                                ; %else95
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbnz	w14, #3, LBB1_78
LBB1_71:                                ; %else98
                                        ;   in Loop: Header=BB1_67 Depth=2
	ldr	q23, [x15, #16]
	tbnz	w14, #4, LBB1_79
LBB1_72:                                ; %else101
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbnz	w14, #5, LBB1_80
LBB1_73:                                ; %else104
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbnz	w14, #6, LBB1_81
LBB1_74:                                ; %else107
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #7, LBB1_66
	b	LBB1_82
LBB1_75:                                ; %cond.load88
                                        ;   in Loop: Header=BB1_67 Depth=2
	ld1.s	{ v22 }[0], [x13]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_69
LBB1_76:                                ; %cond.load91
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #4
	ld1.s	{ v22 }[1], [x16]
	tbz	w14, #2, LBB1_70
LBB1_77:                                ; %cond.load94
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #8
	ld1.s	{ v22 }[2], [x16]
	tbz	w14, #3, LBB1_71
LBB1_78:                                ; %cond.load97
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #12
	ld1.s	{ v22 }[3], [x16]
	ldr	q23, [x15, #16]
	tbz	w14, #4, LBB1_72
LBB1_79:                                ; %cond.load100
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #16
	ld1.s	{ v23 }[0], [x15]
	tbz	w14, #5, LBB1_73
LBB1_80:                                ; %cond.load103
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #20
	ld1.s	{ v23 }[1], [x15]
	tbz	w14, #6, LBB1_74
LBB1_81:                                ; %cond.load106
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #24
	ld1.s	{ v23 }[2], [x15]
	tbz	w14, #7, LBB1_66
LBB1_82:                                ; %cond.load109
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x13, x13, #28
	ld1.s	{ v23 }[3], [x13]
	b	LBB1_66
LBB1_83:                                ; %direct.schedule.9.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	add	x10, x10, x11
	b	LBB1_85
LBB1_84:                                ; %else135
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x12, x24, x8
	stp	q21, q22, [x12]
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB1_101
LBB1_85:                                ; %direct.true44.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s20
	add	x12, x10, x8
	add	x14, x24, x8
	ldr	q21, [x14]
	tbnz	w13, #0, LBB1_93
; %bb.86:                               ; %else114
                                        ;   in Loop: Header=BB1_85 Depth=2
	and	w13, w13, #0xff
	ldr	q22, [x14, #16]
	tbnz	w13, #1, LBB1_94
LBB1_87:                                ; %else117
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w13, #2, LBB1_95
LBB1_88:                                ; %else120
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w13, #3, LBB1_96
LBB1_89:                                ; %else123
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w13, #4, LBB1_97
LBB1_90:                                ; %else126
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w13, #5, LBB1_98
LBB1_91:                                ; %else129
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w13, #6, LBB1_99
LBB1_92:                                ; %else132
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbz	w13, #7, LBB1_84
	b	LBB1_100
LBB1_93:                                ; %cond.load113
                                        ;   in Loop: Header=BB1_85 Depth=2
	ld1.s	{ v21 }[0], [x12]
	and	w13, w13, #0xff
	ldr	q22, [x14, #16]
	tbz	w13, #1, LBB1_87
LBB1_94:                                ; %cond.load116
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #4
	ld1.s	{ v21 }[1], [x14]
	tbz	w13, #2, LBB1_88
LBB1_95:                                ; %cond.load119
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #8
	ld1.s	{ v21 }[2], [x14]
	tbz	w13, #3, LBB1_89
LBB1_96:                                ; %cond.load122
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #12
	ld1.s	{ v21 }[3], [x14]
	tbz	w13, #4, LBB1_90
LBB1_97:                                ; %cond.load125
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #16
	ld1.s	{ v22 }[0], [x14]
	tbz	w13, #5, LBB1_91
LBB1_98:                                ; %cond.load128
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #20
	ld1.s	{ v22 }[1], [x14]
	tbz	w13, #6, LBB1_92
LBB1_99:                                ; %cond.load131
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #24
	ld1.s	{ v22 }[2], [x14]
	tbz	w13, #7, LBB1_84
LBB1_100:                               ; %cond.load134
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x12, x12, #28
	ld1.s	{ v22 }[3], [x12]
	b	LBB1_84
LBB1_101:                               ; %direct.schedule.12.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x9, x11
	b	LBB1_103
LBB1_102:                               ; %else153
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB1_2
LBB1_103:                               ; %direct.true61.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmhi.4s	v22, v0, v8
	uzp1.8h	v20, v22, v1
	and.16b	v20, v20, v9
	addv.8h	h20, v20
	fmov	w11, s20
	add	x10, x23, x8
	ldp	q21, q20, [x10]
	and.16b	v21, v22, v21
	fneg.4s	v23, v21
	and.16b	v23, v22, v23
	fcmge.4s	v24, v23, v2
	fcmge.4s	v25, v3, v23
	and.16b	v24, v24, v25
	and.16b	v24, v24, v23
	fmul.4s	v25, v24, v4
	mov.16b	v26, v31
	bsl.16b	v26, v30, v25
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v5
	fadd.4s	v24, v24, v27
	fmul.4s	v26, v26, v6
	fadd.4s	v24, v24, v26
	fmul.4s	v26, v24, v7
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v19
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v24, v24, v11
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v11
	fmul.4s	v24, v24, v27
	sub.4s	v25, v25, v26
	shl.4s	v25, v25, #23
	add.4s	v25, v25, v11
	fmul.4s	v24, v24, v25
	fcmgt.4s	v25, v2, v23
	fcmgt.4s	v26, v23, v3
	fcmeq.4s	v23, v23, v23
	fadd.4s	v24, v24, v11
	bit.16b	v24, v11, v25
	bit.16b	v24, v12, v26
	bsl.16b	v23, v24, v13
	fdiv.4s	v23, v21, v23
	add	x10, x24, x8
	ldp	q24, q21, [x10]
	and.16b	v22, v22, v24
	fmul.4s	v22, v22, v23
	add	x10, x9, x8
	tbnz	w11, #0, LBB1_112
; %bb.104:                              ; %else139
                                        ;   in Loop: Header=BB1_103 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_113
LBB1_105:                               ; %else141
                                        ;   in Loop: Header=BB1_103 Depth=2
	tbnz	w11, #2, LBB1_114
LBB1_106:                               ; %else143
                                        ;   in Loop: Header=BB1_103 Depth=2
	tbz	w11, #3, LBB1_108
LBB1_107:                               ; %cond.store144
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x12, x10, #12
	st1.s	{ v22 }[3], [x12]
LBB1_108:                               ; %else145
                                        ;   in Loop: Header=BB1_103 Depth=2
	and.16b	v20, v1, v20
	fneg.4s	v22, v20
	and.16b	v22, v1, v22
	fcmge.4s	v23, v22, v2
	fcmge.4s	v24, v3, v22
	and.16b	v23, v23, v24
	and.16b	v23, v23, v22
	fmul.4s	v24, v23, v4
	mov.16b	v25, v31
	bsl.16b	v25, v30, v24
	fadd.4s	v24, v24, v25
	fsub.4s	v24, v24, v25
	fcvtzs.4s	v24, v24
	scvtf.4s	v25, v24
	fmul.4s	v26, v25, v5
	fadd.4s	v23, v23, v26
	fmul.4s	v25, v25, v6
	fadd.4s	v23, v23, v25
	fmul.4s	v25, v23, v7
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v18
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v19
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v10
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v23, v23, v11
	sshr.4s	v25, v24, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v11
	fmul.4s	v23, v23, v26
	sub.4s	v24, v24, v25
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v11
	fmul.4s	v23, v23, v24
	fcmgt.4s	v24, v2, v22
	fcmgt.4s	v25, v22, v3
	fcmeq.4s	v22, v22, v22
	fadd.4s	v23, v23, v11
	bit.16b	v23, v11, v24
	bit.16b	v23, v12, v25
	bsl.16b	v22, v23, v13
	fdiv.4s	v20, v20, v22
	and.16b	v21, v1, v21
	fmul.4s	v20, v21, v20
	tbnz	w11, #4, LBB1_115
; %bb.109:                              ; %else147
                                        ;   in Loop: Header=BB1_103 Depth=2
	tbnz	w11, #5, LBB1_116
LBB1_110:                               ; %else149
                                        ;   in Loop: Header=BB1_103 Depth=2
	tbnz	w11, #6, LBB1_117
LBB1_111:                               ; %else151
                                        ;   in Loop: Header=BB1_103 Depth=2
	tbz	w11, #7, LBB1_102
	b	LBB1_118
LBB1_112:                               ; %cond.store138
                                        ;   in Loop: Header=BB1_103 Depth=2
	str	s22, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_105
LBB1_113:                               ; %cond.store140
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x12, x10, #4
	st1.s	{ v22 }[1], [x12]
	tbz	w11, #2, LBB1_106
LBB1_114:                               ; %cond.store142
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x12, x10, #8
	st1.s	{ v22 }[2], [x12]
	tbnz	w11, #3, LBB1_107
	b	LBB1_108
LBB1_115:                               ; %cond.store146
                                        ;   in Loop: Header=BB1_103 Depth=2
	str	s20, [x10, #16]
	tbz	w11, #5, LBB1_110
LBB1_116:                               ; %cond.store148
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x12, x10, #20
	st1.s	{ v20 }[1], [x12]
	tbz	w11, #6, LBB1_111
LBB1_117:                               ; %cond.store150
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x12, x10, #24
	st1.s	{ v20 }[2], [x12]
	tbz	w11, #7, LBB1_102
LBB1_118:                               ; %cond.store152
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x10, x10, #28
	st1.s	{ v20 }[3], [x10]
	b	LBB1_102
LBB1_119:                               ; %block.batch.exit
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2192
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp], #144            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

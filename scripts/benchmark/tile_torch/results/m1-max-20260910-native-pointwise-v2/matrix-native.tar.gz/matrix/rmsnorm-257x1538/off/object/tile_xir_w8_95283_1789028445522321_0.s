	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
lCPI0_12:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3, lsl #12             ; =12288
	sub	sp, sp, #1040
	str	x0, [sp, #104]                  ; 8-byte Spill
	cbz	w3, LBB0_135
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w26, #0                         ; =0x0
	add	x24, sp, #1, lsl #12            ; =4096
	add	x24, x24, #3056
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #92]               ; 8-byte Folded Spill
	add	x27, sp, #976
	ldp	w8, w9, [x2]
	ldp	w10, w11, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Spill
	str	x11, [sp, #80]                  ; 8-byte Spill
	movi.2d	v8, #0000000000000000
	str	w3, [sp, #100]                  ; 4-byte Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w8, w19, #1
	ldp	w11, w9, [sp, #92]              ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w9, eq
	csinc	w8, wzr, w19, eq
	ldr	w12, [sp, #112]                 ; 4-byte Reload
	cinc	w10, w12, eq
	cmp	w10, w11
	cset	w11, eq
	ands	w11, w9, w11
	csel	w9, wzr, w10, ne
	add	w10, w7, w11
	add	w26, w26, #1
	cmp	w26, w3
	b.eq	LBB0_134
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_23 Depth 2
                                        ;       Child Loop BB0_24 Depth 3
                                        ;       Child Loop BB0_26 Depth 3
                                        ;     Child Loop BB0_32 Depth 2
                                        ;     Child Loop BB0_58 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_88 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
	mov	x23, x10
	mov	x13, x9
	mov	x14, x8
	ubfiz	x8, x8, #5, #32
	ldr	x12, [sp, #80]                  ; 8-byte Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	ccmp	x8, x12, #2, hi
	csel	x8, x10, xzr, ls
	cmp	x8, #32
	stp	w13, w23, [sp, #112]            ; 8-byte Folded Spill
	str	x14, [sp, #120]                 ; 8-byte Spill
	b.lo	LBB0_21
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	ldr	x20, [x8]
	ldr	x22, [x8, #16]
	ldr	x25, [x8, #48]
	ubfiz	w28, w14, #2, #27
	mov	w19, #6152                      ; =0x1808
	umull	x21, w28, w19
	umaddl	x1, w28, w19, x20
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #3056
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	w8, #6144                       ; =0x1800
	umaddl	x19, w28, w19, x8
	add	x8, x20, x19
	add	x9, x8, #4
	ldr	s0, [x8]
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #288]                  ; 16-byte Spill
	str	q0, [sp, #13296]
	ldr	q0, [sp, #7152]
	ldr	q1, [sp, #7168]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #7184]
	ldr	q1, [sp, #7200]
	fmul.4s	v5, v1, v1
	fmul.4s	v4, v0, v0
	ldr	q0, [sp, #7216]
	ldr	q1, [sp, #7232]
	fmul.4s	v6, v1, v1
	fmul.4s	v7, v0, v0
	ldr	q0, [sp, #7248]
	ldr	q1, [sp, #7264]
	fmul.4s	v17, v1, v1
	fmul.4s	v16, v0, v0
	add	x8, x24, #224
	mov	w9, #4                          ; =0x4
LBB0_5:                                 ; %direct.true56.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v5, v5, v0
	fadd.4s	v4, v4, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v6, v6, v0
	fadd.4s	v7, v7, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v17, v17, v0
	fadd.4s	v16, v16, v1
	cmp	x9, #188
	add	x9, x9, #4
	b.lo	LBB0_5
; %bb.6:                                ; %direct.false57.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, sp, #976
	mov	x1, x22
	mov	w2, #6144                       ; =0x1800
	stp	q5, q2, [sp, #192]              ; 32-byte Folded Spill
	str	q3, [sp, #176]                  ; 16-byte Spill
	stp	q7, q4, [sp, #224]              ; 32-byte Folded Spill
	stp	q17, q6, [sp, #256]             ; 32-byte Folded Spill
	str	q16, [sp, #304]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q6, [sp, #288]                  ; 16-byte Reload
	fmul.4s	v0, v6, v6
	ldp	q1, q2, [sp, #176]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	mov.d	v0[1], v1[1]
	ldr	q1, [sp, #208]                  ; 16-byte Reload
	fadd.4s	v1, v2, v1
	ldp	q2, q3, [sp, #224]              ; 32-byte Folded Reload
	fadd.4s	v0, v3, v0
	fadd.4s	v0, v2, v0
	ldp	q2, q3, [sp, #256]              ; 32-byte Folded Reload
	fadd.4s	v1, v3, v1
	fadd.4s	v1, v2, v1
	ldr	q2, [sp, #304]                  ; 16-byte Reload
	fadd.4s	v0, v2, v0
	rev64.4s	v2, v0
	rev64.4s	v3, v1
	fadd.4s	v1, v1, v3
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[2]
	dup.4s	v3, v1[2]
	fadd.4s	v1, v1, v3
	fadd.4s	v0, v0, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s1, w9
	fdiv	s1, s0, s1
	mov	w9, #6148                       ; =0x1804
	add	x9, x22, x9
	ldr	s0, [x22, #6144]
	ld1.s	{ v0 }[1], [x9]
	mov	w9, #6144                       ; =0x1800
	add	x9, x22, x9
	str	x9, [sp, #304]                  ; 8-byte Spill
	str	q0, [sp, #7120]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s2, w9
	fadd	s1, s1, s2
	fsqrt	s1, s1
	dup.4s	v1, v1[0]
	add	x9, x25, x21
LBB0_7:                                 ; %direct.true117.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #5
	add	x11, x24, x10
	ldp	q2, q3, [x11]
	fdiv.4s	v3, v3, v1
	fdiv.4s	v2, v2, v1
	add	x11, x27, x10
	ldp	q5, q4, [x11]
	fmul.4s	v2, v2, v5
	fmul.4s	v3, v3, v4
	add	x10, x9, x10
	stp	q2, q3, [x10]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_7
; %bb.8:                                ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.2s	v1, v1[0]
	fdiv.2s	v1, v6, v1
	fmul.2s	v0, v1, v0
	str	d0, [x25, x19]
	orr	w19, w28, #0x1
	mov	w23, #6152                      ; =0x1808
	umull	x21, w19, w23
	umaddl	x1, w19, w23, x20
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #3056
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	w8, #6144                       ; =0x1800
	umaddl	x19, w19, w23, x8
	add	x8, x20, x19
	add	x9, x8, #4
	ldr	s0, [x8]
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #288]                  ; 16-byte Spill
	str	q0, [sp, #13296]
	ldr	q0, [sp, #7152]
	ldr	q1, [sp, #7168]
	fmul.4s	v2, v1, v1
	fmul.4s	v17, v0, v0
	ldr	q0, [sp, #7184]
	ldr	q1, [sp, #7200]
	fmul.4s	v4, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #7216]
	ldr	q1, [sp, #7232]
	fmul.4s	v5, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #7248]
	ldr	q1, [sp, #7264]
	fmul.4s	v16, v1, v1
	fmul.4s	v7, v0, v0
	add	x8, x24, #224
	mov	w9, #4                          ; =0x4
LBB0_9:                                 ; %direct.true56.i18.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v17, v17, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v5, v5, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v7, v7, v1
	cmp	x9, #188
	add	x9, x9, #4
	b.lo	LBB0_9
; %bb.10:                               ; %direct.false57.i31.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, sp, #976
	mov	x1, x22
	mov	w2, #6144                       ; =0x1800
	stp	q4, q2, [sp, #176]              ; 32-byte Folded Spill
	stp	q6, q3, [sp, #208]              ; 32-byte Folded Spill
	stp	q5, q7, [sp, #256]              ; 32-byte Folded Spill
	str	q16, [sp, #240]                 ; 16-byte Spill
	str	q17, [sp, #160]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q6, [sp, #288]                  ; 16-byte Reload
	fmul.4s	v0, v6, v6
	ldp	q2, q3, [sp, #160]              ; 32-byte Folded Reload
	fadd.4s	v1, v0, v2
	mov.d	v1[1], v2[1]
	mov	w9, #6148                       ; =0x1804
	add	x9, x22, x9
	ldr	x10, [sp, #304]                 ; 8-byte Reload
	ldr	s0, [x10]
	ld1.s	{ v0 }[1], [x9]
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldp	q3, q4, [sp, #208]              ; 32-byte Folded Reload
	fadd.4s	v1, v4, v1
	fadd.4s	v1, v3, v1
	ldp	q3, q4, [sp, #240]              ; 32-byte Folded Reload
	fadd.4s	v2, v4, v2
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #272]                  ; 16-byte Reload
	fadd.4s	v1, v3, v1
	rev64.4s	v3, v1
	rev64.4s	v4, v2
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	dup.4s	v4, v2[2]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	fadd.4s	v1, v1, v2
	fadd	s1, s1, s8
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s2, w9
	fdiv	s1, s1, s2
	str	q0, [sp, #7120]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s2, w9
	fadd	s1, s1, s2
	fsqrt	s1, s1
	dup.4s	v1, v1[0]
	add	x9, x25, x21
LBB0_11:                                ; %direct.true117.i38.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #5
	add	x11, x24, x10
	ldp	q2, q3, [x11]
	fdiv.4s	v3, v3, v1
	fdiv.4s	v2, v2, v1
	add	x11, x27, x10
	ldp	q5, q4, [x11]
	fmul.4s	v2, v2, v5
	fmul.4s	v3, v3, v4
	add	x10, x9, x10
	stp	q2, q3, [x10]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_11
; %bb.12:                               ; %llm_rows.full_packet.exit47.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.2s	v1, v1[0]
	fdiv.2s	v1, v6, v1
	fmul.2s	v0, v1, v0
	str	d0, [x25, x19]
	orr	w19, w28, #0x2
	mov	w23, #6152                      ; =0x1808
	umull	x21, w19, w23
	umaddl	x1, w19, w23, x20
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #3056
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	w8, #6144                       ; =0x1800
	umaddl	x19, w19, w23, x8
	add	x8, x20, x19
	add	x9, x8, #4
	ldr	s0, [x8]
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #288]                  ; 16-byte Spill
	str	q0, [sp, #13296]
	ldr	q0, [sp, #7152]
	ldr	q1, [sp, #7168]
	fmul.4s	v2, v1, v1
	fmul.4s	v17, v0, v0
	ldr	q0, [sp, #7184]
	ldr	q1, [sp, #7200]
	fmul.4s	v4, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #7216]
	ldr	q1, [sp, #7232]
	fmul.4s	v5, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #7248]
	ldr	q1, [sp, #7264]
	fmul.4s	v16, v1, v1
	fmul.4s	v7, v0, v0
	add	x8, x24, #224
	mov	w9, #4                          ; =0x4
LBB0_13:                                ; %direct.true56.i63.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v17, v17, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v5, v5, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v7, v7, v1
	cmp	x9, #188
	add	x9, x9, #4
	b.lo	LBB0_13
; %bb.14:                               ; %direct.false57.i76.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, sp, #976
	mov	x1, x22
	mov	w2, #6144                       ; =0x1800
	stp	q4, q2, [sp, #176]              ; 32-byte Folded Spill
	stp	q6, q3, [sp, #208]              ; 32-byte Folded Spill
	stp	q5, q7, [sp, #256]              ; 32-byte Folded Spill
	str	q16, [sp, #240]                 ; 16-byte Spill
	str	q17, [sp, #160]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q6, [sp, #288]                  ; 16-byte Reload
	fmul.4s	v0, v6, v6
	ldp	q2, q3, [sp, #160]              ; 32-byte Folded Reload
	fadd.4s	v1, v0, v2
	mov.d	v1[1], v2[1]
	mov	w9, #6148                       ; =0x1804
	add	x9, x22, x9
	ldr	x10, [sp, #304]                 ; 8-byte Reload
	ldr	s0, [x10]
	ld1.s	{ v0 }[1], [x9]
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldp	q3, q4, [sp, #208]              ; 32-byte Folded Reload
	fadd.4s	v1, v4, v1
	fadd.4s	v1, v3, v1
	ldp	q3, q4, [sp, #240]              ; 32-byte Folded Reload
	fadd.4s	v2, v4, v2
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #272]                  ; 16-byte Reload
	fadd.4s	v1, v3, v1
	rev64.4s	v3, v1
	rev64.4s	v4, v2
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	dup.4s	v4, v2[2]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	fadd.4s	v1, v1, v2
	fadd	s1, s1, s8
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s2, w9
	fdiv	s1, s1, s2
	str	q0, [sp, #7120]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s2, w9
	fadd	s1, s1, s2
	fsqrt	s1, s1
	dup.4s	v1, v1[0]
	add	x9, x25, x21
LBB0_15:                                ; %direct.true117.i83.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #5
	add	x11, x24, x10
	ldp	q2, q3, [x11]
	fdiv.4s	v3, v3, v1
	fdiv.4s	v2, v2, v1
	add	x11, x27, x10
	ldp	q5, q4, [x11]
	fmul.4s	v2, v2, v5
	fmul.4s	v3, v3, v4
	add	x10, x9, x10
	stp	q2, q3, [x10]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_15
; %bb.16:                               ; %llm_rows.full_packet.exit92.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.2s	v1, v1[0]
	fdiv.2s	v1, v6, v1
	fmul.2s	v0, v1, v0
	str	d0, [x25, x19]
	orr	w19, w28, #0x3
	mov	w23, #6152                      ; =0x1808
	umull	x21, w19, w23
	umaddl	x1, w19, w23, x20
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #3056
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	w8, #6144                       ; =0x1800
	umaddl	x19, w19, w23, x8
	add	x8, x20, x19
	add	x9, x8, #4
	ldr	s0, [x8]
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #288]                  ; 16-byte Spill
	str	q0, [sp, #13296]
	ldr	q0, [sp, #7152]
	ldr	q1, [sp, #7168]
	fmul.4s	v2, v1, v1
	fmul.4s	v17, v0, v0
	ldr	q0, [sp, #7184]
	ldr	q1, [sp, #7200]
	fmul.4s	v4, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #7216]
	ldr	q1, [sp, #7232]
	fmul.4s	v5, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #7248]
	ldr	q1, [sp, #7264]
	fmul.4s	v16, v1, v1
	fmul.4s	v7, v0, v0
	add	x8, x24, #224
	mov	w9, #4                          ; =0x4
LBB0_17:                                ; %direct.true56.i108.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v17, v17, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v5, v5, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v7, v7, v1
	cmp	x9, #188
	add	x9, x9, #4
	b.lo	LBB0_17
; %bb.18:                               ; %direct.false57.i121.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, sp, #976
	mov	x1, x22
	mov	w2, #6144                       ; =0x1800
	stp	q4, q2, [sp, #176]              ; 32-byte Folded Spill
	stp	q6, q3, [sp, #208]              ; 32-byte Folded Spill
	stp	q5, q7, [sp, #256]              ; 32-byte Folded Spill
	str	q16, [sp, #240]                 ; 16-byte Spill
	str	q17, [sp, #160]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q6, [sp, #288]                  ; 16-byte Reload
	fmul.4s	v0, v6, v6
	ldp	q2, q3, [sp, #160]              ; 32-byte Folded Reload
	fadd.4s	v1, v0, v2
	mov.d	v1[1], v2[1]
	ldr	x9, [sp, #304]                  ; 8-byte Reload
	ldr	s0, [x9]
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldp	q3, q4, [sp, #208]              ; 32-byte Folded Reload
	fadd.4s	v1, v4, v1
	fadd.4s	v1, v3, v1
	ldp	q3, q4, [sp, #240]              ; 32-byte Folded Reload
	fadd.4s	v2, v4, v2
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #272]                  ; 16-byte Reload
	fadd.4s	v1, v3, v1
	rev64.4s	v3, v1
	rev64.4s	v4, v2
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	dup.4s	v4, v2[2]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	fadd.4s	v1, v1, v2
	fadd	s1, s1, s8
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s2, w9
	fdiv	s1, s1, s2
	mov	w9, #6148                       ; =0x1804
	add	x9, x22, x9
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #7120]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s2, w9
	fadd	s1, s1, s2
	fsqrt	s1, s1
	dup.4s	v1, v1[0]
	add	x9, x25, x21
	ldr	w7, [sp, #116]                  ; 4-byte Reload
	ldr	w3, [sp, #100]                  ; 4-byte Reload
LBB0_19:                                ; %direct.true117.i128.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #5
	add	x11, x24, x10
	ldp	q2, q3, [x11]
	fdiv.4s	v3, v3, v1
	fdiv.4s	v2, v2, v1
	add	x11, x27, x10
	ldp	q5, q4, [x11]
	fmul.4s	v2, v2, v5
	fmul.4s	v3, v3, v4
	add	x10, x9, x10
	stp	q2, q3, [x10]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_19
; %bb.20:                               ; %llm_rows.full_packet.exit137.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.2s	v1, v1[0]
	fdiv.2s	v1, v6, v1
	fmul.2s	v0, v1, v0
	str	d0, [x25, x19]
	ldr	x19, [sp, #120]                 ; 8-byte Reload
	b	LBB0_2
LBB0_21:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	w26, [sp, #76]                  ; 4-byte Spill
	str	x8, [sp, #48]                   ; 8-byte Spill
	lsr	x8, x8, #3
	str	x8, [sp, #160]                  ; 8-byte Spill
	cbz	x8, LBB0_28
; %bb.22:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w28, #0                         ; =0x0
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	ldr	x21, [x8]
	ldr	x22, [x8, #16]
	ldr	x19, [x8, #48]
	mov	w8, #6144                       ; =0x1800
	add	x8, x22, x8
	str	x8, [sp, #144]                  ; 8-byte Spill
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	lsl	w8, w8, #2
	str	w8, [sp, #128]                  ; 4-byte Spill
	mov	x25, x8
LBB0_23:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_24 Depth 3
                                        ;       Child Loop BB0_26 Depth 3
	and	x8, x25, #0x1fffffff
	mov	w26, #6152                      ; =0x1808
	umaddl	x23, w8, w26, x19
	ldr	w8, [sp, #128]                  ; 4-byte Reload
	add	w8, w28, w8
	and	w20, w8, #0x1fffffff
	umaddl	x1, w20, w26, x21
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #3056
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	w8, #6144                       ; =0x1800
	umaddl	x20, w20, w26, x8
	add	x8, x21, x20
	add	x9, x8, #4
	ldr	s0, [x8]
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #304]                  ; 16-byte Spill
	str	q0, [sp, #13296]
	ldr	q0, [sp, #7152]
	ldr	q1, [sp, #7168]
	fmul.4s	v2, v1, v1
	fmul.4s	v17, v0, v0
	ldr	q0, [sp, #7184]
	ldr	q1, [sp, #7200]
	fmul.4s	v4, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #7216]
	ldr	q1, [sp, #7232]
	fmul.4s	v5, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [sp, #7248]
	ldr	q1, [sp, #7264]
	fmul.4s	v16, v1, v1
	fmul.4s	v7, v0, v0
	add	x8, x24, #224
	mov	w9, #4                          ; =0x4
LBB0_24:                                ; %direct.true56.i153.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v17, v17, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v5, v5, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v7, v7, v1
	cmp	x9, #188
	add	x9, x9, #4
	b.lo	LBB0_24
; %bb.25:                               ; %direct.false57.i166.i
                                        ;   in Loop: Header=BB0_23 Depth=2
	add	x0, sp, #976
	mov	x1, x22
	mov	w2, #6144                       ; =0x1800
	stp	q4, q2, [sp, #192]              ; 32-byte Folded Spill
	stp	q6, q3, [sp, #224]              ; 32-byte Folded Spill
	stp	q5, q7, [sp, #272]              ; 32-byte Folded Spill
	str	q16, [sp, #256]                 ; 16-byte Spill
	str	q17, [sp, #176]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q6, [sp, #304]                  ; 16-byte Reload
	fmul.4s	v0, v6, v6
	ldp	q2, q3, [sp, #176]              ; 32-byte Folded Reload
	fadd.4s	v1, v0, v2
	mov.d	v1[1], v2[1]
	mov	w9, #6148                       ; =0x1804
	add	x9, x22, x9
	ldr	x10, [sp, #144]                 ; 8-byte Reload
	ldr	s0, [x10]
	ld1.s	{ v0 }[1], [x9]
	ldr	q2, [sp, #208]                  ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldp	q3, q4, [sp, #224]              ; 32-byte Folded Reload
	fadd.4s	v1, v4, v1
	fadd.4s	v1, v3, v1
	ldp	q3, q4, [sp, #256]              ; 32-byte Folded Reload
	fadd.4s	v2, v4, v2
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #288]                  ; 16-byte Reload
	fadd.4s	v1, v3, v1
	rev64.4s	v3, v1
	rev64.4s	v4, v2
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	dup.4s	v4, v2[2]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	fadd.4s	v1, v1, v2
	fadd	s1, s1, s8
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s2, w9
	fdiv	s1, s1, s2
	str	q0, [sp, #7120]
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s2, w9
	fadd	s1, s1, s2
	fsqrt	s1, s1
	dup.4s	v1, v1[0]
LBB0_26:                                ; %direct.true117.i173.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x9, x8, #5
	add	x10, x24, x9
	ldp	q2, q3, [x10]
	fdiv.4s	v3, v3, v1
	fdiv.4s	v2, v2, v1
	add	x10, x27, x9
	ldp	q5, q4, [x10]
	fmul.4s	v2, v2, v5
	fmul.4s	v3, v3, v4
	add	x9, x23, x9
	stp	q2, q3, [x9]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_26
; %bb.27:                               ; %llm_rows.full_packet.exit182.i
                                        ;   in Loop: Header=BB0_23 Depth=2
	dup.2s	v1, v1[0]
	fdiv.2s	v1, v6, v1
	fmul.2s	v0, v1, v0
	str	d0, [x19, x20]
	add	w28, w28, #1
	add	w25, w25, #1
	ldr	x8, [sp, #160]                  ; 8-byte Reload
	cmp	w28, w8
	b.ne	LBB0_23
LBB0_28:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #48]                   ; 8-byte Reload
	and	w8, w8, #0x7
	ldr	w3, [sp, #100]                  ; 4-byte Reload
	ldr	w26, [sp, #76]                  ; 4-byte Reload
	mov	w0, #4                          ; =0x4
	ldr	w7, [sp, #116]                  ; 4-byte Reload
	ldr	x19, [sp, #120]                 ; 8-byte Reload
	cbz	w8, LBB0_2
; %bb.29:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v1, w8
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB0_2
; %bb.30:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	ldr	x12, [x8]
	ldr	x10, [x8, #16]
	ldr	x8, [x8, #48]
Lloh4:
	adrp	x11, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x11, lCPI0_0@PAGEOFF]
	and.16b	v2, v3, v2
	addv.8h	h2, v2
	ubfiz	w11, w19, #2, #27
	ldr	x13, [sp, #160]                 ; 8-byte Reload
	orr	w13, w11, w13
	fmov	w11, s2
	and	w11, w11, #0xff
	dup.4s	v4, w13
	and.16b	v16, v1, v4
	and.16b	v4, v0, v4
	ushll2.2d	v5, v4, #0
	ushll2.2d	v6, v16, #0
	ushll.2d	v7, v4, #0
	ushll.2d	v4, v16, #0
	fmov	x13, d4
	mov	w14, #6152                      ; =0x1808
	umaddl	x13, w13, w14, x12
	b	LBB0_32
LBB0_31:                                ; %else212
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x14, x24, x9, lsl #5
	stp	q16, q17, [x14]
	add	x9, x9, #1
	cmp	x9, #192
	b.eq	LBB0_48
LBB0_32:                                ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w15, s2
	lsl	x16, x9, #5
	add	x14, x13, x16
	add	x16, x24, x16
	ldr	q16, [x16]
	tbnz	w15, #0, LBB0_40
; %bb.33:                               ; %else
                                        ;   in Loop: Header=BB0_32 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_41
LBB0_34:                                ; %else194
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w15, #2, LBB0_42
LBB0_35:                                ; %else197
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w15, #3, LBB0_43
LBB0_36:                                ; %else200
                                        ;   in Loop: Header=BB0_32 Depth=2
	ldr	q17, [x16, #16]
	tbnz	w15, #4, LBB0_44
LBB0_37:                                ; %else203
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w15, #5, LBB0_45
LBB0_38:                                ; %else206
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w15, #6, LBB0_46
LBB0_39:                                ; %else209
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbz	w15, #7, LBB0_31
	b	LBB0_47
LBB0_40:                                ; %cond.load
                                        ;   in Loop: Header=BB0_32 Depth=2
	ld1.s	{ v16 }[0], [x14]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_34
LBB0_41:                                ; %cond.load193
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x17, x14, #4
	ld1.s	{ v16 }[1], [x17]
	tbz	w15, #2, LBB0_35
LBB0_42:                                ; %cond.load196
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x17, x14, #8
	ld1.s	{ v16 }[2], [x17]
	tbz	w15, #3, LBB0_36
LBB0_43:                                ; %cond.load199
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x17, x14, #12
	ld1.s	{ v16 }[3], [x17]
	ldr	q17, [x16, #16]
	tbz	w15, #4, LBB0_37
LBB0_44:                                ; %cond.load202
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x16, x14, #16
	ld1.s	{ v17 }[0], [x16]
	tbz	w15, #5, LBB0_38
LBB0_45:                                ; %cond.load205
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x16, x14, #20
	ld1.s	{ v17 }[1], [x16]
	tbz	w15, #6, LBB0_39
LBB0_46:                                ; %cond.load208
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x16, x14, #24
	ld1.s	{ v17 }[2], [x16]
	tbz	w15, #7, LBB0_31
LBB0_47:                                ; %cond.load211
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x14, x14, #28
	ld1.s	{ v17 }[3], [x14]
	b	LBB0_31
LBB0_48:                                ; %direct.true56.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	xtn.8b	v22, v3
	sshll.2d	v3, v1, #0
	sshll.2d	v17, v0, #0
	sshll2.2d	v18, v1, #0
	sshll2.2d	v19, v0, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q16, [x9, lCPI0_6@PAGEOFF]
	and.16b	v26, v3, v16
Lloh8:
	adrp	x9, lCPI0_7@PAGE
Lloh9:
	ldr	q16, [x9, lCPI0_7@PAGEOFF]
	and.16b	v16, v3, v16
Lloh10:
	adrp	x9, lCPI0_8@PAGE
Lloh11:
	ldr	q3, [x9, lCPI0_8@PAGEOFF]
	and.16b	v23, v17, v3
Lloh12:
	adrp	x9, lCPI0_9@PAGE
Lloh13:
	ldr	q3, [x9, lCPI0_9@PAGEOFF]
	and.16b	v24, v18, v3
Lloh14:
	adrp	x9, lCPI0_10@PAGE
Lloh15:
	ldr	q3, [x9, lCPI0_10@PAGEOFF]
	and.16b	v25, v19, v3
	movi	d3, #0x0000000000ffff
	and.8b	v27, v22, v3
Lloh16:
	adrp	x9, lCPI0_11@PAGE
Lloh17:
	ldr	d20, [x9, lCPI0_11@PAGEOFF]
	and.8b	v20, v22, v20
	addv.8b	b20, v20
	fmov	w13, s20
	umaxv.8b	b20, v27
	fmov	w9, s20
	rbit	w14, w13
	clz	w14, w14
	tst	w9, #0x1
	mov	w9, #1536                       ; =0x600
	dup.2d	v21, x9
	csel	w9, w14, wzr, ne
	str	q26, [sp, #144]                 ; 16-byte Spill
	orr.16b	v3, v26, v21
	mov	w14, #1538                      ; =0x602
	dup.2s	v20, w14
	xtn.2s	v9, v4
	str	q3, [sp, #208]                  ; 16-byte Spill
	umlal.2d	v3, v9, v20
	mov	b4, v27[0]
	mov.b	v4[4], v27[1]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	str	q3, [sp, #288]                  ; 16-byte Spill
	and.16b	v4, v4, v3
	movi.2d	v3, #0000000000000000
	stp	q3, q3, [sp, #864]
	stp	q4, q3, [sp, #832]
	ubfiz	x15, x9, #3, #3
	add	x14, sp, #832
	ldr	x14, [x14, x15]
	sub	x14, x14, x9
	add	x14, x12, x14, lsl #2
	stp	q23, q25, [sp, #928]
	stp	q16, q24, [sp, #896]
	add	x12, sp, #896
	ldr	x12, [x12, x15]
	orr	x12, x12, #0x1800
	sub	x12, x12, w9, uxtw #2
	tst	w13, #0xff
	csel	x12, xzr, x12, eq
	add	x15, x24, x12
	ldp	q25, q26, [x15]
	tbnz	w13, #0, LBB0_113
; %bb.49:                               ; %else216
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #1, LBB0_114
LBB0_50:                                ; %else219
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #2, LBB0_115
LBB0_51:                                ; %else222
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #3, LBB0_116
LBB0_52:                                ; %else225
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #4, LBB0_117
LBB0_53:                                ; %else228
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #5, LBB0_118
LBB0_54:                                ; %else231
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #6, LBB0_119
LBB0_55:                                ; %else234
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	q27, [sp, #304]                 ; 16-byte Spill
	tbz	w13, #7, LBB0_57
LBB0_56:                                ; %cond.load236
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x14, #28
	ld1.s	{ v26 }[3], [x13]
LBB0_57:                                ; %else237
                                        ;   in Loop: Header=BB0_3 Depth=1
Lloh18:
	adrp	x13, lCPI0_3@PAGE
Lloh19:
	ldr	q4, [x13, lCPI0_3@PAGEOFF]
	and.16b	v3, v19, v4
Lloh20:
	adrp	x13, lCPI0_4@PAGE
Lloh21:
	ldr	q4, [x13, lCPI0_4@PAGEOFF]
	and.16b	v24, v18, v4
Lloh22:
	adrp	x13, lCPI0_5@PAGE
Lloh23:
	ldr	q4, [x13, lCPI0_5@PAGEOFF]
	and.16b	v4, v17, v4
	stp	q4, q24, [sp, #16]              ; 32-byte Folded Spill
	orr.16b	v23, v4, v21
	orr.16b	v24, v24, v21
	str	q3, [sp, #48]                   ; 16-byte Spill
	orr.16b	v17, v3, v21
	umull.2d	v3, v9, v20
	str	q3, [sp, #224]                  ; 16-byte Spill
	xtn.2s	v4, v6
	xtn.2s	v6, v7
	xtn.2s	v5, v5
	stp	q23, q17, [sp, #176]            ; 32-byte Folded Spill
	mov.16b	v3, v17
	umlal.2d	v3, v5, v20
	str	q3, [sp, #272]                  ; 16-byte Spill
	str	q24, [sp, #160]                 ; 16-byte Spill
	mov.16b	v3, v24
	umlal.2d	v3, v4, v20
	str	q3, [sp, #256]                  ; 16-byte Spill
	mov.16b	v3, v23
	umlal.2d	v3, v6, v20
	str	q3, [sp, #240]                  ; 16-byte Spill
	sshll.2d	v4, v1, #0
	sshll.2d	v5, v0, #0
	add	x13, x24, x12
	stp	q25, q26, [x13]
	str	q25, [sp, #128]                 ; 16-byte Spill
	dup.2d	v17, x0
	and.16b	v6, v19, v17
	and.16b	v7, v18, v17
	and.16b	v20, v5, v17
	and.16b	v21, v4, v17
	fmov	x13, d21
	ldr	q4, [sp, #7264]
	ldr	q5, [sp, #7248]
	fmul.4s	v5, v5, v5
	fmul.4s	v4, v4, v4
	and.16b	v11, v0, v4
	and.16b	v12, v1, v5
	ldr	q4, [sp, #7232]
	ldr	q5, [sp, #7216]
	fmul.4s	v5, v5, v5
	fmul.4s	v4, v4, v4
	and.16b	v14, v0, v4
	and.16b	v13, v1, v5
	ldr	q4, [sp, #7200]
	ldr	q5, [sp, #7184]
	fmul.4s	v5, v5, v5
	fmul.4s	v4, v4, v4
	and.16b	v15, v0, v4
	and.16b	v9, v1, v5
	fmov	x14, d16
	add	x14, x24, x14
	ldp	q5, q4, [x14]
	fmul.4s	v5, v5, v5
	fmul.4s	v4, v4, v4
	and.16b	v16, v0, v4
	and.16b	v10, v1, v5
LBB0_58:                                ; %direct.true56.i197.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v4, v1, #0
	sshll.2d	v23, v0, #0
	add	x13, x24, x13, lsl #5
	ldp	q17, q5, [x13]
	and.16b	v17, v1, v17
	and.16b	v5, v0, v5
	fmul.4s	v5, v5, v5
	fmul.4s	v17, v17, v17
	fadd.4s	v17, v10, v17
	fadd.4s	v5, v16, v5
	ldp	q25, q24, [x13, #32]
	and.16b	v25, v1, v25
	and.16b	v24, v0, v24
	fmul.4s	v24, v24, v24
	fmul.4s	v25, v25, v25
	fadd.4s	v25, v9, v25
	fadd.4s	v24, v15, v24
	ldp	q29, q28, [x13, #64]
	and.16b	v29, v1, v29
	and.16b	v28, v0, v28
	fmul.4s	v28, v28, v28
	fmul.4s	v29, v29, v29
	fadd.4s	v29, v13, v29
	fadd.4s	v28, v14, v28
	ldp	q31, q30, [x13, #96]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	fmul.4s	v30, v30, v30
	fmul.4s	v31, v31, v31
	fadd.4s	v31, v12, v31
	fadd.4s	v30, v11, v30
	dup.2d	v3, x0
	and.16b	v27, v19, v3
	add.2d	v6, v6, v27
	and.16b	v27, v18, v3
	add.2d	v7, v7, v27
	and.16b	v23, v23, v3
	add.2d	v20, v20, v23
	and.16b	v3, v4, v3
	add.2d	v21, v21, v3
	bit.16b	v16, v5, v0
	bit.16b	v10, v17, v1
	bit.16b	v15, v24, v0
	bit.16b	v9, v25, v1
	bit.16b	v14, v28, v0
	bit.16b	v13, v29, v1
	bit.16b	v11, v30, v0
	bit.16b	v12, v31, v1
	fmov	x13, d21
	cmp	x13, #192
	b.lt	LBB0_58
; %bb.59:                               ; %direct.false57.i206.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	mov	w14, #1                         ; =0x1
	dup.2d	v3, x14
	ushll2.2d	v4, v0, #0
	and.16b	v18, v4, v3
	ushll2.2d	v4, v1, #0
	and.16b	v19, v4, v3
	ushll.2d	v4, v0, #0
	and.16b	v20, v4, v3
	ushll.2d	v4, v1, #0
	and.16b	v21, v4, v3
	movi.2d	v23, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v24, #0000000000000000
	ldr	q29, [sp, #304]                 ; 16-byte Reload
	b	LBB0_61
LBB0_60:                                ; %else262
                                        ;   in Loop: Header=BB0_61 Depth=2
	add	x13, x27, x13
	stp	q25, q4, [x13]
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v24, v24, v18
	add.2d	v23, v23, v21
	fmov	x13, d23
	cmp	x13, #192
	b.ge	LBB0_77
LBB0_61:                                ; %direct.true91.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w15, s2
	lsl	x13, x13, #5
	add	x14, x10, x13
	add	x16, x27, x13
	ldp	q25, q4, [x16]
	tbnz	w15, #0, LBB0_69
; %bb.62:                               ; %else241
                                        ;   in Loop: Header=BB0_61 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_70
LBB0_63:                                ; %else244
                                        ;   in Loop: Header=BB0_61 Depth=2
	tbnz	w15, #2, LBB0_71
LBB0_64:                                ; %else247
                                        ;   in Loop: Header=BB0_61 Depth=2
	tbnz	w15, #3, LBB0_72
LBB0_65:                                ; %else250
                                        ;   in Loop: Header=BB0_61 Depth=2
	tbnz	w15, #4, LBB0_73
LBB0_66:                                ; %else253
                                        ;   in Loop: Header=BB0_61 Depth=2
	tbnz	w15, #5, LBB0_74
LBB0_67:                                ; %else256
                                        ;   in Loop: Header=BB0_61 Depth=2
	tbnz	w15, #6, LBB0_75
LBB0_68:                                ; %else259
                                        ;   in Loop: Header=BB0_61 Depth=2
	tbz	w15, #7, LBB0_60
	b	LBB0_76
LBB0_69:                                ; %cond.load240
                                        ;   in Loop: Header=BB0_61 Depth=2
	ld1.s	{ v25 }[0], [x14]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_63
LBB0_70:                                ; %cond.load243
                                        ;   in Loop: Header=BB0_61 Depth=2
	add	x16, x14, #4
	ld1.s	{ v25 }[1], [x16]
	tbz	w15, #2, LBB0_64
LBB0_71:                                ; %cond.load246
                                        ;   in Loop: Header=BB0_61 Depth=2
	add	x16, x14, #8
	ld1.s	{ v25 }[2], [x16]
	tbz	w15, #3, LBB0_65
LBB0_72:                                ; %cond.load249
                                        ;   in Loop: Header=BB0_61 Depth=2
	add	x16, x14, #12
	ld1.s	{ v25 }[3], [x16]
	tbz	w15, #4, LBB0_66
LBB0_73:                                ; %cond.load252
                                        ;   in Loop: Header=BB0_61 Depth=2
	add	x16, x14, #16
	ld1.s	{ v4 }[0], [x16]
	tbz	w15, #5, LBB0_67
LBB0_74:                                ; %cond.load255
                                        ;   in Loop: Header=BB0_61 Depth=2
	add	x16, x14, #20
	ld1.s	{ v4 }[1], [x16]
	tbz	w15, #6, LBB0_68
LBB0_75:                                ; %cond.load258
                                        ;   in Loop: Header=BB0_61 Depth=2
	add	x16, x14, #24
	ld1.s	{ v4 }[2], [x16]
	tbz	w15, #7, LBB0_60
LBB0_76:                                ; %cond.load261
                                        ;   in Loop: Header=BB0_61 Depth=2
	add	x14, x14, #28
	ld1.s	{ v4 }[3], [x14]
	b	LBB0_60
LBB0_77:                                ; %direct.false92.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	movi	d3, #0xffffffffffff0000
	and.8b	v3, v22, v3
	zip2.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v26, v4, v26
	zip1.8b	v6, v29, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #128]                  ; 16-byte Reload
	and.16b	v27, v6, v7
	fmul.4s	v7, v27, v27
	fmul.4s	v23, v26, v26
	fadd.4s	v16, v23, v16
	fadd.4s	v7, v7, v10
	and.16b	v6, v6, v7
	and.16b	v4, v4, v16
	zip2.8b	v7, v3, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v4, v5, v7
	zip1.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v17, v6
	fadd.4s	v3, v9, v3
	fadd.4s	v4, v15, v4
	fadd.4s	v4, v14, v4
	fadd.4s	v3, v13, v3
	fadd.4s	v16, v12, v3
	fadd.4s	v17, v11, v4
	ldr	q3, [sp, #144]                  ; 16-byte Reload
	ldp	q4, q6, [sp, #16]               ; 32-byte Folded Reload
	uzp1.4s	v5, v3, v6
	ldr	q3, [sp, #48]                   ; 16-byte Reload
	uzp1.4s	v28, v4, v3
	movi.4s	v4, #1
	eor.16b	v3, v5, v4
	mov.s	w14, v3[1]
	mov.s	w16, v3[2]
	mov.s	w17, v3[3]
	fmov	w13, s3
	add	x15, sp, #392
	bfxil	x15, x13, #0, #3
	str	d22, [sp, #392]
	ldrb	w0, [x15]
	and	x15, x13, #0x7
	umov.b	w13, v22[0]
	stp	q16, q17, [sp, #656]
	add	x1, sp, #656
	ldr	s3, [x1, x15, lsl #2]
	eor.16b	v4, v28, v4
	ands	w15, w13, #0x1
	tst	w15, w0
	fcsel	s23, s3, s8, ne
	add	x0, sp, #392
	bfxil	x0, x14, #0, #3
	ldrb	w0, [x0]
	and	x1, x14, #0x7
	umov.b	w14, v22[1]
	stp	q16, q17, [sp, #624]
	add	x2, sp, #624
	ldr	s3, [x2, x1, lsl #2]
	ands	w1, w14, #0x1
	tst	w1, w0
	fcsel	s6, s3, s8, ne
	add	x0, sp, #392
	bfxil	x0, x16, #0, #3
	ldrb	w0, [x0]
	and	x1, x16, #0x7
	umov.b	w16, v22[2]
	stp	q16, q17, [sp, #592]
	add	x2, sp, #592
	ldr	s3, [x2, x1, lsl #2]
	ands	w1, w16, #0x1
	tst	w1, w0
	fcsel	s7, s3, s8, ne
	add	x0, sp, #392
	bfxil	x0, x17, #0, #3
	ldrb	w0, [x0]
	and	x1, x17, #0x7
	umov.b	w17, v22[3]
	stp	q16, q17, [sp, #560]
	add	x2, sp, #560
	ldr	s3, [x2, x1, lsl #2]
	ands	w1, w17, #0x1
	tst	w1, w0
	mov.s	w1, v4[1]
	mov.s	w2, v4[2]
	mov.s	w20, v4[3]
	fcsel	s24, s3, s8, ne
	fmov	w0, s4
	and	x4, x0, #0x7
	add	x5, sp, #392
	bfxil	x5, x0, #0, #3
	ldrb	w5, [x5]
	umov.b	w0, v22[4]
	stp	q16, q17, [sp, #784]
	add	x6, sp, #784
	ldr	s3, [x6, x4, lsl #2]
	and	w4, w0, w5
	tst	w4, #0x1
	add	x4, sp, #392
	bfxil	x4, x1, #0, #3
	ldrb	w4, [x4]
	and	x5, x1, #0x7
	umov.b	w1, v22[5]
	stp	q16, q17, [sp, #752]
	add	x6, sp, #752
	ldr	s4, [x6, x5, lsl #2]
	fcsel	s3, s3, s8, ne
	ands	w5, w1, #0x1
	tst	w5, w4
	fcsel	s4, s4, s8, ne
	add	x4, sp, #392
	bfxil	x4, x2, #0, #3
	ldrb	w4, [x4]
	and	x5, x2, #0x7
	umov.b	w2, v22[6]
	stp	q16, q17, [sp, #720]
	add	x6, sp, #720
	ldr	s25, [x6, x5, lsl #2]
	ands	w5, w2, #0x1
	tst	w5, w4
	fcsel	s25, s25, s8, ne
	add	x4, sp, #392
	bfxil	x4, x20, #0, #3
	ldrb	w4, [x4]
	and	x5, x20, #0x7
	umov.b	w20, v22[7]
	stp	q16, q17, [sp, #688]
	add	x6, sp, #688
	ldr	s22, [x6, x5, lsl #2]
	ands	w5, w20, #0x1
	tst	w5, w4
	fcsel	s22, s22, s8, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v25[0]
	mov.s	v3[3], v22[0]
	mov.s	v23[1], v6[0]
	mov.s	v23[2], v7[0]
	mov.s	v23[3], v24[0]
	fadd.4s	v4, v16, v23
	fadd.4s	v3, v17, v3
	movi.4s	v7, #2
	eor.16b	v6, v28, v7
	eor.16b	v5, v5, v7
	fmov	w4, s5
	add	x5, sp, #392
	bfxil	x5, x4, #0, #3
	ldrb	w5, [x5]
	and	x4, x4, #0x7
	stp	q4, q3, [sp, #528]
	add	x6, sp, #528
	ldr	s5, [x6, x4, lsl #2]
	tst	w15, w5
	fcsel	s5, s5, s8, ne
	fmov	w4, s6
	and	x5, x4, #0x7
	add	x6, sp, #392
	bfxil	x6, x4, #0, #3
	ldrb	w4, [x6]
	and	w4, w0, w4
	stp	q4, q3, [sp, #496]
	add	x6, sp, #496
	ldr	s6, [x6, x5, lsl #2]
	tst	w4, #0x1
	fcsel	s6, s6, s8, ne
	fadd.4s	v3, v3, v6
	tst	w15, w0
	fcsel	s3, s3, s8, ne
	ands	w13, w13, #0x1
	fadd.4s	v4, v4, v5
	fadd	s3, s4, s3
	fcsel	s4, s3, s8, ne
	tst	w14, #0x1
	fcsel	s5, s4, s8, ne
	tst	w16, #0x1
	fcsel	s6, s4, s8, ne
	tst	w17, #0x1
	fcsel	s7, s4, s8, ne
	tst	w13, w0
	fcsel	s3, s3, s8, ne
	tst	w1, #0x1
	fcsel	s16, s4, s8, ne
	tst	w2, #0x1
	fcsel	s17, s4, s8, ne
	tst	w20, #0x1
Lloh24:
	adrp	x13, lCPI0_12@PAGE
Lloh25:
	ldr	d22, [x13, lCPI0_12@PAGEOFF]
	shl.8b	v23, v29, #7
	cmlt.8b	v23, v23, #0
	fcsel	s24, s4, s8, ne
	mov.s	v4[1], v5[0]
	mov.s	v4[2], v6[0]
	mov.s	v4[3], v7[0]
	mov.s	v3[1], v16[0]
	and.8b	v5, v23, v22
	mov.s	v3[2], v17[0]
	mov.s	v3[3], v24[0]
	rbit	w11, w11
	clz	w11, w11
	stp	q4, q3, [sp, #464]
	and	x11, x11, #0x7
	add	x13, sp, #464
	ldr	s17, [x13, x11, lsl #2]
	addv.8b	b22, v5
	mov	b3, v29[0]
	mov.b	v3[4], v29[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #208]                  ; 16-byte Reload
	and.16b	v3, v3, v4
	mov	b4, v29[2]
	mov.b	v4[4], v29[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldp	q5, q7, [sp, #160]              ; 32-byte Folded Reload
	and.16b	v4, v4, v5
	mov	b5, v29[4]
	mov.b	v5[4], v29[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	mov	b6, v29[6]
	mov.b	v6[4], v29[7]
	and.16b	v5, v5, v7
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldr	q7, [sp, #192]                  ; 16-byte Reload
	and.16b	v6, v6, v7
	stp	q5, q6, [sp, #432]
	stp	q3, q4, [sp, #400]
	and	x11, x9, #0x7
	add	x13, sp, #400
	ldr	x13, [x13, x11, lsl #3]
	fmov	w11, s22
	sub	x13, x13, x9
	add	x10, x10, x13, lsl #2
	add	x13, x27, x12
	ldp	q5, q16, [x13]
	tbnz	w11, #0, LBB0_120
; %bb.78:                               ; %else266
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w11, #1, LBB0_121
LBB0_79:                                ; %else269
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w11, #2, LBB0_122
LBB0_80:                                ; %else272
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w11, #3, LBB0_123
LBB0_81:                                ; %else275
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w11, #4, LBB0_124
LBB0_82:                                ; %else278
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w11, #5, LBB0_125
LBB0_83:                                ; %else281
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w11, #6, LBB0_126
LBB0_84:                                ; %else284
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w11, #7, LBB0_86
LBB0_85:                                ; %cond.load286
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x10, x10, #28
	ld1.s	{ v16 }[3], [x10]
LBB0_86:                                ; %else287
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	fadd	s3, s17, s8
	mov	w10, #16384                     ; =0x4000
	movk	w10, #17600, lsl #16
	fmov	s4, w10
	fdiv	s3, s3, s4
	add	x10, x27, x12
	stp	q5, q16, [x10]
	mov	w10, #50604                     ; =0xc5ac
	movk	w10, #14119, lsl #16
	fmov	s4, w10
	fadd	s3, s3, s4
	fsqrt	s3, s3
	dup.4s	v17, v3[0]
	ldr	q3, [sp, #224]                  ; 16-byte Reload
	fmov	x10, d3
	add	x10, x8, x10, lsl #2
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v23, #0000000000000000
	b	LBB0_88
LBB0_87:                                ; %else304
                                        ;   in Loop: Header=BB0_88 Depth=2
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v23, v23, v18
	add.2d	v4, v4, v21
	fmov	x11, d4
	cmp	x11, #192
	b.ge	LBB0_104
LBB0_88:                                ; %direct.true117.i211.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w12, s2
	lsl	x11, x11, #5
	add	x13, x24, x11
	ldp	q3, q24, [x13]
	and.16b	v3, v1, v3
	fdiv.4s	v3, v3, v17
	add	x13, x27, x11
	ldp	q28, q25, [x13]
	and.16b	v28, v1, v28
	fmul.4s	v28, v3, v28
	add	x11, x10, x11
	tbnz	w12, #0, LBB0_96
; %bb.89:                               ; %else290
                                        ;   in Loop: Header=BB0_88 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_97
LBB0_90:                                ; %else292
                                        ;   in Loop: Header=BB0_88 Depth=2
	tbnz	w12, #2, LBB0_98
LBB0_91:                                ; %else294
                                        ;   in Loop: Header=BB0_88 Depth=2
	tbnz	w12, #3, LBB0_99
LBB0_92:                                ; %else296
                                        ;   in Loop: Header=BB0_88 Depth=2
	and.16b	v3, v0, v24
	fdiv.4s	v3, v3, v17
	and.16b	v24, v0, v25
	fmul.4s	v24, v3, v24
	tbnz	w12, #4, LBB0_100
LBB0_93:                                ; %else298
                                        ;   in Loop: Header=BB0_88 Depth=2
	tbnz	w12, #5, LBB0_101
LBB0_94:                                ; %else300
                                        ;   in Loop: Header=BB0_88 Depth=2
	tbnz	w12, #6, LBB0_102
LBB0_95:                                ; %else302
                                        ;   in Loop: Header=BB0_88 Depth=2
	tbz	w12, #7, LBB0_87
	b	LBB0_103
LBB0_96:                                ; %cond.store
                                        ;   in Loop: Header=BB0_88 Depth=2
	str	s28, [x11]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_90
LBB0_97:                                ; %cond.store291
                                        ;   in Loop: Header=BB0_88 Depth=2
	add	x13, x11, #4
	st1.s	{ v28 }[1], [x13]
	tbz	w12, #2, LBB0_91
LBB0_98:                                ; %cond.store293
                                        ;   in Loop: Header=BB0_88 Depth=2
	add	x13, x11, #8
	st1.s	{ v28 }[2], [x13]
	tbz	w12, #3, LBB0_92
LBB0_99:                                ; %cond.store295
                                        ;   in Loop: Header=BB0_88 Depth=2
	add	x13, x11, #12
	st1.s	{ v28 }[3], [x13]
	and.16b	v3, v0, v24
	fdiv.4s	v3, v3, v17
	and.16b	v24, v0, v25
	fmul.4s	v24, v3, v24
	tbz	w12, #4, LBB0_93
LBB0_100:                               ; %cond.store297
                                        ;   in Loop: Header=BB0_88 Depth=2
	str	s24, [x11, #16]
	tbz	w12, #5, LBB0_94
LBB0_101:                               ; %cond.store299
                                        ;   in Loop: Header=BB0_88 Depth=2
	add	x13, x11, #20
	st1.s	{ v24 }[1], [x13]
	tbz	w12, #6, LBB0_95
LBB0_102:                               ; %cond.store301
                                        ;   in Loop: Header=BB0_88 Depth=2
	add	x13, x11, #24
	st1.s	{ v24 }[2], [x13]
	tbz	w12, #7, LBB0_87
LBB0_103:                               ; %cond.store303
                                        ;   in Loop: Header=BB0_88 Depth=2
	add	x11, x11, #28
	st1.s	{ v24 }[3], [x11]
	b	LBB0_87
LBB0_104:                               ; %direct.false118.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	fdiv.4s	v0, v27, v17
	fmov	w10, s22
	zip1.8b	v1, v29, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v1, v1, v5
	fmul.4s	v0, v0, v1
	ldp	q1, q2, [sp, #272]              ; 32-byte Folded Reload
	ldp	q4, q3, [sp, #240]              ; 32-byte Folded Reload
	stp	q2, q3, [sp, #320]
	stp	q4, q1, [sp, #352]
	and	x11, x9, #0x7
	add	x12, sp, #320
	ldr	x11, [x12, x11, lsl #3]
	sub	x9, x11, x9
	add	x8, x8, x9, lsl #2
	tbnz	w10, #0, LBB0_127
; %bb.105:                              ; %else307
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #1, LBB0_128
LBB0_106:                               ; %else309
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #2, LBB0_129
LBB0_107:                               ; %else311
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w10, #3, LBB0_109
LBB0_108:                               ; %cond.store312
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #12
	st1.s	{ v0 }[3], [x9]
LBB0_109:                               ; %else313
                                        ;   in Loop: Header=BB0_3 Depth=1
	fdiv.4s	v0, v26, v17
	zip2.8b	v1, v29, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v1, v1, v16
	fmul.4s	v0, v0, v1
	tbnz	w10, #4, LBB0_130
; %bb.110:                              ; %else315
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #5, LBB0_131
LBB0_111:                               ; %else317
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w10, #6, LBB0_132
LBB0_112:                               ; %else319
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w10, #7, LBB0_2
	b	LBB0_133
LBB0_113:                               ; %cond.load215
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v25 }[0], [x14]
	tbz	w13, #1, LBB0_50
LBB0_114:                               ; %cond.load218
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x14, #4
	ld1.s	{ v25 }[1], [x15]
	tbz	w13, #2, LBB0_51
LBB0_115:                               ; %cond.load221
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x14, #8
	ld1.s	{ v25 }[2], [x15]
	tbz	w13, #3, LBB0_52
LBB0_116:                               ; %cond.load224
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x14, #12
	ld1.s	{ v25 }[3], [x15]
	tbz	w13, #4, LBB0_53
LBB0_117:                               ; %cond.load227
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x14, #16
	ld1.s	{ v26 }[0], [x15]
	tbz	w13, #5, LBB0_54
LBB0_118:                               ; %cond.load230
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x14, #20
	ld1.s	{ v26 }[1], [x15]
	tbz	w13, #6, LBB0_55
LBB0_119:                               ; %cond.load233
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x14, #24
	ld1.s	{ v26 }[2], [x15]
	str	q27, [sp, #304]                 ; 16-byte Spill
	tbnz	w13, #7, LBB0_56
	b	LBB0_57
LBB0_120:                               ; %cond.load265
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v5 }[0], [x10]
	tbz	w11, #1, LBB0_79
LBB0_121:                               ; %cond.load268
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x10, #4
	ld1.s	{ v5 }[1], [x13]
	tbz	w11, #2, LBB0_80
LBB0_122:                               ; %cond.load271
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x10, #8
	ld1.s	{ v5 }[2], [x13]
	tbz	w11, #3, LBB0_81
LBB0_123:                               ; %cond.load274
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x10, #12
	ld1.s	{ v5 }[3], [x13]
	tbz	w11, #4, LBB0_82
LBB0_124:                               ; %cond.load277
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x10, #16
	ld1.s	{ v16 }[0], [x13]
	tbz	w11, #5, LBB0_83
LBB0_125:                               ; %cond.load280
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x10, #20
	ld1.s	{ v16 }[1], [x13]
	tbz	w11, #6, LBB0_84
LBB0_126:                               ; %cond.load283
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x10, #24
	ld1.s	{ v16 }[2], [x13]
	tbnz	w11, #7, LBB0_85
	b	LBB0_86
LBB0_127:                               ; %cond.store306
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s0, [x8]
	tbz	w10, #1, LBB0_106
LBB0_128:                               ; %cond.store308
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #4
	st1.s	{ v0 }[1], [x9]
	tbz	w10, #2, LBB0_107
LBB0_129:                               ; %cond.store310
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #8
	st1.s	{ v0 }[2], [x9]
	tbnz	w10, #3, LBB0_108
	b	LBB0_109
LBB0_130:                               ; %cond.store314
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	s0, [x8, #16]
	tbz	w10, #5, LBB0_111
LBB0_131:                               ; %cond.store316
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #20
	st1.s	{ v0 }[1], [x9]
	tbz	w10, #6, LBB0_112
LBB0_132:                               ; %cond.store318
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x9, x8, #24
	st1.s	{ v0 }[2], [x9]
	tbz	w10, #7, LBB0_2
LBB0_133:                               ; %cond.store320
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB0_2
LBB0_134:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Reload
	stp	w19, w12, [x9]
	str	w7, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
LBB0_135:                               ; %block.batch.exit
	add	sp, sp, #3, lsl #12             ; =12288
	add	sp, sp, #1040
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh24, Lloh25
                                        ; -- End function
.subsections_via_symbols

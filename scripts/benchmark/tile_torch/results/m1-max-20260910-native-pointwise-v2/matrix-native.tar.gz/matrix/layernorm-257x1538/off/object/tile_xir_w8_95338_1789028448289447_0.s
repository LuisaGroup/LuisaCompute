	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #6, lsl #12             ; =24576
	sub	sp, sp, #304
	ldr	x24, [x0]
	ldr	x20, [x0, #16]
	ldr	x19, [x0, #32]
	ldr	x21, [x0, #48]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	fmov	s0, w8
	ushll.2d	v0, v0, #0
	fmov	x22, d0
	mov	w25, #6152                      ; =0x1808
	umull	x23, w22, w25
	umaddl	x1, w22, w25, x24
	mov	w26, #6144                      ; =0x1800
	add	x27, sp, #4, lsl #12            ; =16384
	add	x27, x27, #2320
	add	x0, sp, #4, lsl #12             ; =16384
	add	x0, x0, #2320
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	umaddl	x22, w22, w25, x26
	add	x8, x24, x22
	add	x9, x8, #4
	ldr	s0, [x8]
	ld1.s	{ v0 }[1], [x9]
	str	q0, [sp, #24848]
	ldr	q1, [sp, #18720]
	ldr	q7, [sp, #18704]
	ldr	q6, [sp, #18752]
	ldr	q5, [sp, #18736]
	ldr	q2, [sp, #18784]
	ldr	q16, [sp, #18768]
	ldr	q4, [sp, #18816]
	ldr	q3, [sp, #18800]
	add	x8, x27, #224
	mov	w9, #4                          ; =0x4
LBB0_1:                                 ; %direct.true76
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q17, q18, [x8, #-96]
	fadd.4s	v1, v1, v18
	fadd.4s	v7, v7, v17
	ldp	q17, q18, [x8, #-64]
	fadd.4s	v6, v6, v18
	fadd.4s	v5, v5, v17
	ldp	q17, q18, [x8, #-32]
	fadd.4s	v2, v2, v18
	fadd.4s	v16, v16, v17
	ldp	q17, q18, [x8], #128
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v17
	cmp	x9, #188
	add	x9, x9, #4
	b.lo	LBB0_1
; %bb.2:                                ; %direct.false77
	mov	x8, #0                          ; =0x0
	fadd.4s	v17, v0, v7
	mov.d	v17[1], v7[1]
	fadd.4s	v1, v6, v1
	fadd.4s	v5, v5, v17
	fadd.4s	v5, v16, v5
	fadd.4s	v1, v2, v1
	fadd.4s	v1, v4, v1
	fadd.4s	v2, v3, v5
	rev64.4s	v3, v2
	rev64.4s	v4, v1
	fadd.4s	v1, v1, v4
	fadd.4s	v2, v2, v3
	dup.4s	v3, v2[2]
	dup.4s	v4, v1[2]
	fadd.4s	v1, v1, v4
	fadd.4s	v2, v2, v3
	fadd.4s	v1, v2, v1
	movi.2d	v2, #0000000000000000
	fadd	s1, s1, s2
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s2, w9
	fdiv	s1, s1, s2
	dup.4s	v1, v1[0]
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2320
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #240
LBB0_3:                                 ; %direct.true111
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x11, x8, #5
	add	x12, x9, x11
	ldp	q3, q2, [x12]
	fsub.4s	v3, v3, v1
	fsub.4s	v2, v2, v1
	add	x11, x10, x11
	stp	q3, q2, [x11]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_3
; %bb.4:                                ; %direct.false112
	dup.4s	v1, v1[0]
	fsub.4s	v1, v0, v1
	ldr	q0, [sp, #18672]
	str	q1, [sp, #144]                  ; 16-byte Spill
	mov.d	v1[1], v0[1]
	str	q1, [sp, #160]                  ; 16-byte Spill
	str	q1, [sp, #18672]
	ldr	q0, [sp, #12528]
	ldr	q1, [sp, #12544]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [sp, #12560]
	ldr	q1, [sp, #12576]
	fmul.4s	v5, v1, v1
	fmul.4s	v4, v0, v0
	ldr	q0, [sp, #12592]
	ldr	q1, [sp, #12608]
	fmul.4s	v6, v1, v1
	fmul.4s	v7, v0, v0
	ldr	q0, [sp, #12624]
	ldr	q1, [sp, #12640]
	fmul.4s	v17, v1, v1
	fmul.4s	v16, v0, v0
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #240
	add	x8, x8, #224
	mov	w9, #4                          ; =0x4
LBB0_5:                                 ; %direct.true148
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v5, v5, v0
	fadd.4s	v4, v4, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v6, v6, v0
	fadd.4s	v7, v7, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v17, v17, v0
	fadd.4s	v16, v16, v1
	cmp	x9, #188
	add	x9, x9, #4
	b.lo	LBB0_5
; %bb.6:                                ; %direct.false149
	add	x24, sp, #1, lsl #12            ; =4096
	add	x24, x24, #2256
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #2256
	mov	x1, x20
	mov	w2, #6144                       ; =0x1800
	stp	q5, q2, [sp, #16]               ; 32-byte Folded Spill
	str	q3, [sp]                        ; 16-byte Spill
	stp	q7, q4, [sp, #48]               ; 32-byte Folded Spill
	stp	q6, q16, [sp, #96]              ; 32-byte Folded Spill
	str	q17, [sp, #80]                  ; 16-byte Spill
	bl	_memcpy
	mov	w25, #6148                      ; =0x1804
	add	x8, x20, x25
	ldr	s0, [x20, #6144]
	ld1.s	{ v0 }[1], [x8]
	str	q0, [sp, #128]                  ; 16-byte Spill
	str	q0, [sp, #12496]
	add	x20, sp, #176
	add	x0, sp, #176
	mov	x1, x19
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	q0, [sp, #144]                  ; 16-byte Reload
	fmul.4s	v0, v0, v0
	ldp	q1, q2, [sp]                    ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	mov.d	v0[1], v1[1]
	ldr	q1, [sp, #32]                   ; 16-byte Reload
	fadd.4s	v1, v2, v1
	ldp	q2, q3, [sp, #48]               ; 32-byte Folded Reload
	fadd.4s	v0, v3, v0
	fadd.4s	v0, v2, v0
	ldp	q2, q3, [sp, #80]               ; 32-byte Folded Reload
	fadd.4s	v1, v3, v1
	fadd.4s	v1, v2, v1
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	fadd.4s	v0, v2, v0
	rev64.4s	v2, v0
	rev64.4s	v3, v1
	fadd.4s	v0, v0, v2
	dup.4s	v2, v0[2]
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	mov	w9, #16384                      ; =0x4000
	movk	w9, #17600, lsl #16
	fmov	s4, w9
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s5, w9
	fadd.4s	v1, v1, v3
	fadd.4s	v0, v0, v2
	fadd.4s	v0, v0, v1
	movi.2d	v1, #0000000000000000
	fadd	s0, s0, s1
	fdiv	s0, s0, s4
	fadd	s1, s0, s5
	add	x9, x19, x25
	ldr	s0, [x19, #6144]
	ld1.s	{ v0 }[1], [x9]
	fsqrt	s1, s1
	str	q0, [sp, #6320]
	dup.4s	v1, v1[0]
	add	x9, x21, x23
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #240
LBB0_7:                                 ; %direct.true236
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x11, x8, #5
	add	x12, x10, x11
	ldp	q3, q2, [x12]
	fdiv.4s	v3, v3, v1
	fdiv.4s	v2, v2, v1
	add	x12, x24, x11
	ldp	q4, q5, [x12]
	fmul.4s	v2, v2, v5
	fmul.4s	v3, v3, v4
	add	x12, x20, x11
	ldp	q5, q4, [x12]
	fadd.4s	v3, v3, v5
	fadd.4s	v2, v2, v4
	add	x11, x9, x11
	stp	q3, q2, [x11]
	add	x8, x8, #1
	cmp	x8, #192
	b.ne	LBB0_7
; %bb.8:                                ; %direct.false237
	dup.2s	v1, v1[0]
	ldr	q2, [sp, #160]                  ; 16-byte Reload
	fdiv.2s	v1, v2, v1
	ldr	q2, [sp, #128]                  ; 16-byte Reload
	fmul.2s	v1, v1, v2
	fadd.2s	v0, v1, v0
	str	d0, [x21, x22]
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #304
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_13:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI1_14:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI1_15:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI1_16:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
lCPI1_12:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #6, lsl #12             ; =24576
	sub	sp, sp, #1808
	str	x0, [sp, #416]                  ; 8-byte Spill
	cbz	w3, LBB1_155
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x23, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	ldp	w9, w8, [x2, #44]
	str	w9, [sp, #412]                  ; 4-byte Spill
	str	w8, [sp, #408]                  ; 4-byte Spill
	add	x25, sp, #4, lsl #12            ; =16384
	add	x25, x25, #3824
	ldp	w24, w12, [x2]
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Spill
Lloh4:
	adrp	x8, lCPI1_2@PAGE
Lloh5:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Spill
	ldp	w13, w8, [x2, #8]
	str	x8, [sp, #400]                  ; 8-byte Spill
	add	x19, sp, #3, lsl #12            ; =12288
	add	x19, x19, #1744
	add	x21, sp, #1, lsl #12            ; =4096
	add	x21, x21, #3760
	add	x27, sp, #1680
	str	w3, [sp, #364]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w23, [sp, #364]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w24, #1
	ldr	w9, [sp, #412]                  ; 4-byte Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w24, wzr, w24, eq
	cinc	w9, w28, eq
	ldr	w10, [sp, #408]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w12, wzr, w9, ne
	ldr	w13, [sp, #428]                 ; 4-byte Reload
	add	w13, w13, w8
	add	w22, w22, #1
	cmp	w22, w23
	b.eq	LBB1_155
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_41 Depth 2
                                        ;     Child Loop BB1_43 Depth 2
                                        ;     Child Loop BB1_45 Depth 2
                                        ;     Child Loop BB1_48 Depth 2
                                        ;     Child Loop BB1_75 Depth 2
                                        ;     Child Loop BB1_102 Depth 2
	ubfiz	x8, x24, #5, #32
	ldr	x14, [sp, #400]                 ; 8-byte Reload
	cmp	x8, x14
	csel	x9, x8, xzr, ls
	subs	x10, x14, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x14, x9
	stp	w24, w12, [x20]
	mov	x26, x12
	str	w13, [sp, #428]                 ; 4-byte Spill
	str	w13, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x14, #2, hi
	csel	x28, x10, xzr, ls
	cmp	x28, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x28, [sp, #416]                 ; 8-byte Reload
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	x28, x26
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x23, x28, #3
	cbz	x23, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #416]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x23, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #416]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x23, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #416]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x23, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	str	w22, [sp, #384]                 ; 4-byte Spill
	ldr	x22, [sp, #416]                 ; 8-byte Reload
	mov	x0, x22
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x22
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x22
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x22
	ldr	w22, [sp, #384]                 ; 4-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w28, #0x7
	mov	x28, x26
	mov	w26, #4                         ; =0x4
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v1, w8
	ldp	q0, q2, [sp, #32]               ; 32-byte Folded Reload
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x11, [sp, #416]                 ; 8-byte Reload
	ldr	x8, [x11]
	ldr	x13, [x11, #16]
	ldr	x10, [x11, #32]
	ldr	x11, [x11, #48]
	str	x11, [sp, #352]                 ; 8-byte Spill
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v2, v3, v2
	addv.8h	h17, v2
	fmov	w11, s17
	and	w30, w11, #0xff
	ubfiz	w11, w24, #2, #27
	orr	w11, w11, w23
	dup.4s	v4, w11
	and.16b	v16, v1, v4
	and.16b	v4, v0, v4
	ushll2.2d	v5, v4, #0
	ushll2.2d	v6, v16, #0
	ushll.2d	v7, v4, #0
	ushll.2d	v19, v16, #0
	fmov	x11, d19
	mov	w12, #6152                      ; =0x1808
	umaddl	x11, w11, w12, x8
	fmov	w12, s17
	b	LBB1_15
LBB1_14:                                ; %else76
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x25, x9, lsl #5
	stp	q4, q16, [x14]
	add	x9, x9, #1
	cmp	x9, #192
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x15, x9, #5
	add	x14, x11, x15
	add	x16, x25, x15
	ldr	q4, [x16]
	tbnz	w12, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB1_24
LBB1_17:                                ; %else58
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #2, LBB1_25
LBB1_18:                                ; %else61
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #3, LBB1_26
LBB1_19:                                ; %else64
                                        ;   in Loop: Header=BB1_15 Depth=2
	ldr	q16, [x16, #16]
	tbnz	w15, #4, LBB1_27
LBB1_20:                                ; %else67
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #5, LBB1_28
LBB1_21:                                ; %else70
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #6, LBB1_29
LBB1_22:                                ; %else73
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w15, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	ld1.s	{ v4 }[0], [x14]
	and	w15, w12, #0xff
	tbz	w15, #1, LBB1_17
LBB1_24:                                ; %cond.load57
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x14, #4
	ld1.s	{ v4 }[1], [x17]
	tbz	w15, #2, LBB1_18
LBB1_25:                                ; %cond.load60
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x14, #8
	ld1.s	{ v4 }[2], [x17]
	tbz	w15, #3, LBB1_19
LBB1_26:                                ; %cond.load63
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x14, #12
	ld1.s	{ v4 }[3], [x17]
	ldr	q16, [x16, #16]
	tbz	w15, #4, LBB1_20
LBB1_27:                                ; %cond.load66
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x16, x14, #16
	ld1.s	{ v16 }[0], [x16]
	tbz	w15, #5, LBB1_21
LBB1_28:                                ; %cond.load69
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x16, x14, #20
	ld1.s	{ v16 }[1], [x16]
	tbz	w15, #6, LBB1_22
LBB1_29:                                ; %cond.load72
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x16, x14, #24
	ld1.s	{ v16 }[2], [x16]
	tbz	w15, #7, LBB1_14
LBB1_30:                                ; %cond.load75
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x14, #28
	ld1.s	{ v16 }[3], [x14]
	b	LBB1_14
LBB1_31:                                ; %direct.true76.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v22, v3
	sshll.2d	v3, v1, #0
	sshll.2d	v18, v0, #0
	sshll2.2d	v26, v1, #0
	sshll2.2d	v27, v0, #0
Lloh6:
	adrp	x9, lCPI1_6@PAGE
Lloh7:
	ldr	q4, [x9, lCPI1_6@PAGEOFF]
	and.16b	v4, v3, v4
Lloh8:
	adrp	x9, lCPI1_7@PAGE
Lloh9:
	ldr	q16, [x9, lCPI1_7@PAGEOFF]
	and.16b	v16, v3, v16
Lloh10:
	adrp	x9, lCPI1_8@PAGE
Lloh11:
	ldr	q3, [x9, lCPI1_8@PAGEOFF]
	and.16b	v20, v18, v3
Lloh12:
	adrp	x9, lCPI1_9@PAGE
Lloh13:
	ldr	q3, [x9, lCPI1_9@PAGEOFF]
	and.16b	v23, v26, v3
Lloh14:
	adrp	x9, lCPI1_10@PAGE
Lloh15:
	ldr	q3, [x9, lCPI1_10@PAGEOFF]
	and.16b	v24, v27, v3
	movi	d2, #0x0000000000ffff
	and.8b	v3, v22, v2
Lloh16:
	adrp	x9, lCPI1_11@PAGE
Lloh17:
	ldr	d21, [x9, lCPI1_11@PAGEOFF]
	str	q22, [sp, #368]                 ; 16-byte Spill
	and.8b	v21, v22, v21
	addv.8b	b21, v21
	fmov	w12, s21
	umaxv.8b	b21, v3
	fmov	w9, s21
	rbit	w11, w12
	clz	w11, w11
	tst	w9, #0x1
	mov	w9, #1536                       ; =0x600
	dup.2d	v22, x9
	csel	w9, w11, wzr, ne
	str	q4, [sp, #240]                  ; 16-byte Spill
	orr.16b	v2, v4, v22
	mov	w11, #1538                      ; =0x602
	dup.2s	v21, w11
	xtn.2s	v28, v19
	str	q2, [sp, #144]                  ; 16-byte Spill
	umlal.2d	v2, v28, v21
	mov	b19, v3[0]
	mov.b	v19[4], v3[1]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	str	q2, [sp, #320]                  ; 16-byte Spill
	and.16b	v19, v19, v2
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #1584]
	str	q2, [sp, #1568]
	str	q2, [sp, #1552]
	str	q19, [sp, #1536]
	ubfiz	x11, x9, #3, #3
	add	x14, sp, #1536
	ldr	x14, [x14, x11]
	sub	x14, x14, x9
	add	x8, x8, x14, lsl #2
	str	q24, [sp, #1648]
	str	q20, [sp, #1632]
	str	q23, [sp, #1616]
	str	q16, [sp, #1600]
	add	x14, sp, #1600
	ldr	x11, [x14, x11]
	orr	x11, x11, #0x1800
	sub	x11, x11, w9, uxtw #2
	tst	w12, #0xff
	csel	x11, xzr, x11, eq
	add	x14, x25, x11
	ldp	q25, q24, [x14]
	tbnz	w12, #0, LBB1_127
; %bb.32:                               ; %else80
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #1, LBB1_128
LBB1_33:                                ; %else83
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #2, LBB1_129
LBB1_34:                                ; %else86
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #3, LBB1_130
LBB1_35:                                ; %else89
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #4, LBB1_131
LBB1_36:                                ; %else92
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #5, LBB1_132
LBB1_37:                                ; %else95
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #6, LBB1_133
LBB1_38:                                ; %else98
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q3, [sp, #384]                  ; 16-byte Spill
	str	q17, [sp, #336]                 ; 16-byte Spill
	tbz	w12, #7, LBB1_40
LBB1_39:                                ; %cond.load100
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x8, #28
	ld1.s	{ v24 }[3], [x8]
LBB1_40:                                ; %else101
                                        ;   in Loop: Header=BB1_4 Depth=1
Lloh18:
	adrp	x8, lCPI1_3@PAGE
Lloh19:
	ldr	q19, [x8, lCPI1_3@PAGEOFF]
	and.16b	v2, v27, v19
Lloh20:
	adrp	x8, lCPI1_4@PAGE
Lloh21:
	ldr	q20, [x8, lCPI1_4@PAGEOFF]
	and.16b	v3, v26, v20
Lloh22:
	adrp	x8, lCPI1_5@PAGE
Lloh23:
	ldr	q23, [x8, lCPI1_5@PAGEOFF]
	and.16b	v4, v18, v23
	stp	q4, q3, [sp, #192]              ; 32-byte Folded Spill
	orr.16b	v4, v4, v22
	orr.16b	v17, v3, v22
	str	q2, [sp, #224]                  ; 16-byte Spill
	orr.16b	v3, v2, v22
	umull.2d	v2, v28, v21
	str	q2, [sp, #256]                  ; 16-byte Spill
	xtn.2s	v6, v6
	xtn.2s	v7, v7
	xtn.2s	v5, v5
	stp	q4, q3, [sp, #112]              ; 32-byte Folded Spill
	mov.16b	v2, v3
	umlal.2d	v2, v5, v21
	str	q2, [sp, #304]                  ; 16-byte Spill
	stp	q24, q17, [sp, #80]             ; 32-byte Folded Spill
	mov.16b	v2, v17
	umlal.2d	v2, v6, v21
	str	q2, [sp, #288]                  ; 16-byte Spill
	mov.16b	v2, v4
	umlal.2d	v2, v7, v21
	str	q2, [sp, #272]                  ; 16-byte Spill
	sshll.2d	v5, v1, #0
	sshll.2d	v6, v0, #0
	add	x8, x25, x11
	stp	q25, q24, [x8]
	str	q25, [sp, #64]                  ; 16-byte Spill
	fmov	x7, d16
	dup.2d	v7, x26
	and.16b	v25, v27, v7
	and.16b	v11, v26, v7
	and.16b	v24, v6, v7
	and.16b	v14, v5, v7
	fmov	x6, d14
	ldr	q5, [sp, #20304]
	ldr	q6, [sp, #20320]
	and.16b	v6, v0, v6
	and.16b	v5, v1, v5
	ldr	q7, [sp, #20272]
	ldr	q16, [sp, #20288]
	and.16b	v16, v0, v16
	and.16b	v7, v1, v7
	ldr	q22, [sp, #20240]
	ldr	q21, [sp, #20256]
	and.16b	v21, v0, v21
	and.16b	v28, v1, v22
	add	x8, x25, x7
	ldp	q22, q23, [x8]
	and.16b	v8, v0, v23
	mov	x8, x6
	and.16b	v9, v1, v22
	mov.16b	v22, v14
	mov.16b	v15, v11
	mov.16b	v13, v24
	mov.16b	v30, v25
LBB1_41:                                ; %direct.true76.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v4, v1, #0
	sshll.2d	v10, v0, #0
	add	x8, x25, x8, lsl #5
	ldp	q12, q23, [x8]
	fadd.4s	v12, v9, v12
	fadd.4s	v23, v8, v23
	ldp	q3, q17, [x8, #32]
	fadd.4s	v3, v28, v3
	fadd.4s	v17, v21, v17
	ldp	q31, q29, [x8, #64]
	fadd.4s	v31, v7, v31
	fadd.4s	v29, v16, v29
	ldp	q20, q19, [x8, #96]
	fadd.4s	v20, v5, v20
	fadd.4s	v19, v6, v19
	dup.2d	v18, x26
	and.16b	v2, v27, v18
	add.2d	v30, v30, v2
	and.16b	v2, v26, v18
	add.2d	v15, v15, v2
	and.16b	v2, v10, v18
	add.2d	v13, v13, v2
	and.16b	v2, v4, v18
	add.2d	v22, v22, v2
	bit.16b	v8, v23, v0
	bit.16b	v9, v12, v1
	bit.16b	v21, v17, v0
	bit.16b	v28, v3, v1
	bit.16b	v16, v29, v0
	bit.16b	v7, v31, v1
	bit.16b	v6, v19, v0
	bit.16b	v5, v20, v1
	fmov	x8, d22
	cmp	x8, #192
	b.lt	LBB1_41
; %bb.42:                               ; %direct.false77.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	movi	d2, #0xffffffffffff0000
	ldp	q30, q29, [sp, #368]            ; 32-byte Folded Reload
	and.8b	v17, v30, v2
	ldr	q31, [sp, #80]                  ; 16-byte Reload
	fadd.4s	v2, v31, v8
	ldr	q8, [sp, #64]                   ; 16-byte Reload
	fadd.4s	v3, v8, v9
	zip1.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v3, v4, v3
	zip2.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v2, v4, v2
	zip2.8b	v4, v17, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v2, v23, v4
	str	d17, [sp, #168]                 ; 8-byte Spill
	zip1.8b	v4, v17, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v3, v12, v4
	fadd.4s	v3, v28, v3
	fadd.4s	v2, v21, v2
	fadd.4s	v2, v16, v2
	fadd.4s	v3, v7, v3
	fadd.4s	v5, v5, v3
	fadd.4s	v6, v6, v2
	ldp	q2, q7, [sp, #224]              ; 32-byte Folded Reload
	ldr	q3, [sp, #208]                  ; 16-byte Reload
	uzp1.4s	v4, v7, v3
	ldr	q3, [sp, #192]                  ; 16-byte Reload
	uzp1.4s	v7, v3, v2
	movi.4s	v3, #1
	eor.16b	v2, v4, v3
	mov.s	w14, v2[1]
	mov.s	w15, v2[2]
	eor.16b	v20, v7, v3
	mov.s	w0, v2[3]
	fmov	w12, s2
	add	x16, sp, #1176
	bfxil	x16, x12, #0, #3
	str	d30, [sp, #1176]
	ldrb	w16, [x16]
	and	x17, x12, #0x7
	umov.b	w12, v30[0]
	str	q6, [sp, #1392]
	str	q5, [sp, #1376]
	add	x1, sp, #1376
	ldr	s2, [x1, x17, lsl #2]
	ands	w17, w12, #0x1
	tst	w17, w16
	movi.2d	v22, #0000000000000000
	fcsel	s16, s2, s22, ne
	and	x1, x14, #0x7
	add	x16, sp, #1176
	bfxil	x16, x14, #0, #3
	ldrb	w14, [x16]
	umov.b	w16, v30[1]
	and	w14, w16, w14
	str	q6, [sp, #1360]
	str	q5, [sp, #1344]
	add	x2, sp, #1344
	ldr	s2, [x2, x1, lsl #2]
	tst	w14, #0x1
	fcsel	s18, s2, s22, ne
	and	x1, x15, #0x7
	add	x2, sp, #1176
	bfxil	x2, x15, #0, #3
	umov.b	w14, v30[2]
	ldrb	w15, [x2]
	and	w15, w14, w15
	str	q6, [sp, #1328]
	str	q5, [sp, #1312]
	add	x2, sp, #1312
	ldr	s2, [x2, x1, lsl #2]
	tst	w15, #0x1
	fcsel	s19, s2, s22, ne
	and	x1, x0, #0x7
	add	x15, sp, #1176
	bfxil	x15, x0, #0, #3
	ldrb	w0, [x15]
	umov.b	w15, v30[3]
	str	q6, [sp, #1296]
	str	q5, [sp, #1280]
	add	x2, sp, #1280
	ldr	s2, [x2, x1, lsl #2]
	and	w0, w15, w0
	tst	w0, #0x1
	mov.s	w0, v20[1]
	mov.s	w1, v20[2]
	fcsel	s21, s2, s22, ne
	mov.s	w4, v20[3]
	fmov	w2, s20
	and	x5, x2, #0x7
	add	x3, sp, #1176
	bfxil	x3, x2, #0, #3
	ldrb	w2, [x3]
	umov.b	w3, v30[4]
	and	w2, w3, w2
	str	q6, [sp, #1520]
	str	q5, [sp, #1504]
	add	x23, sp, #1504
	ldr	s2, [x23, x5, lsl #2]
	tst	w2, #0x1
	fcsel	s2, s2, s22, ne
	and	x5, x0, #0x7
	add	x2, sp, #1176
	bfxil	x2, x0, #0, #3
	ldrb	w0, [x2]
	umov.b	w2, v30[5]
	and	w0, w2, w0
	str	q6, [sp, #1488]
	str	q5, [sp, #1472]
	add	x23, sp, #1472
	ldr	s3, [x23, x5, lsl #2]
	tst	w0, #0x1
	fcsel	s3, s3, s22, ne
	and	x5, x1, #0x7
	add	x0, sp, #1176
	bfxil	x0, x1, #0, #3
	ldrb	w1, [x0]
	umov.b	w0, v30[6]
	and	w1, w0, w1
	str	q6, [sp, #1456]
	str	q5, [sp, #1440]
	add	x23, sp, #1440
	ldr	s17, [x23, x5, lsl #2]
	tst	w1, #0x1
	fcsel	s17, s17, s22, ne
	and	x5, x4, #0x7
	add	x23, sp, #1176
	bfxil	x23, x4, #0, #3
	umov.b	w1, v30[7]
	ldrb	w4, [x23]
	and	w4, w1, w4
	str	q6, [sp, #1424]
	str	q5, [sp, #1408]
	add	x23, sp, #1408
	ldr	s20, [x23, x5, lsl #2]
	tst	w4, #0x1
	fcsel	s20, s20, s22, ne
	mov.s	v2[1], v3[0]
	mov.s	v2[2], v17[0]
	mov.s	v2[3], v20[0]
	mov.s	v16[1], v18[0]
	mov.s	v16[2], v19[0]
	mov.s	v16[3], v21[0]
	fadd.4s	v3, v5, v16
	fadd.4s	v2, v6, v2
	movi.4s	v6, #2
	eor.16b	v5, v7, v6
	eor.16b	v4, v4, v6
	fmov	w4, s4
	add	x5, sp, #1176
	bfxil	x5, x4, #0, #3
	ldrb	w5, [x5]
	and	x4, x4, #0x7
	str	q2, [sp, #1264]
	str	q3, [sp, #1248]
	add	x23, sp, #1248
	ldr	s4, [x23, x4, lsl #2]
	tst	w17, w5
	fcsel	s4, s4, s22, ne
	fmov	w17, s5
	and	x4, x17, #0x7
	add	x5, sp, #1176
	bfxil	x5, x17, #0, #3
	ldrb	w17, [x5]
	and	w17, w3, w17
	str	q2, [sp, #1232]
	str	q3, [sp, #1216]
	add	x5, sp, #1216
	ldr	s5, [x5, x4, lsl #2]
	tst	w17, #0x1
	fcsel	s5, s5, s22, ne
	fadd.4s	v2, v2, v5
	and	w17, w12, w3
	tst	w17, #0x1
	fcsel	s2, s2, s22, ne
	ands	w5, w12, #0x1
	fadd.4s	v3, v3, v4
	fadd	s2, s3, s2
	fcsel	s3, s2, s22, ne
	tst	w17, #0x1
	and	w23, w16, w12
	fcsel	s4, s2, s22, ne
	and	w4, w16, w12
	str	w4, [sp, #240]                  ; 4-byte Spill
	tst	w23, #0x1
	and	w23, w14, w12
	fcsel	s5, s2, s22, ne
	and	w4, w14, w12
	str	w4, [sp, #224]                  ; 4-byte Spill
	tst	w23, #0x1
	and	w23, w15, w12
	fcsel	s6, s2, s22, ne
	and	w4, w15, w12
	str	w4, [sp, #208]                  ; 4-byte Spill
	tst	w23, #0x1
	fcsel	s7, s2, s22, ne
	and	w23, w2, w12
	and	w4, w2, w12
	str	w4, [sp, #192]                  ; 4-byte Spill
	tst	w23, #0x1
	fcsel	s16, s2, s22, ne
	and	w23, w0, w12
	and	w4, w0, w12
	str	w4, [sp, #188]                  ; 4-byte Spill
	tst	w23, #0x1
	fcsel	s17, s2, s22, ne
	and	w4, w1, w12
	tst	w4, #0x1
	fcsel	s2, s2, s22, ne
	mov.s	v3[1], v5[0]
	mov.s	v3[2], v6[0]
	mov.s	v3[3], v7[0]
	mov.s	v4[1], v16[0]
	mov.s	v4[2], v17[0]
	mov.s	v4[3], v2[0]
	rbit	w23, w30
	clz	w23, w23
	str	q4, [sp, #1200]
	str	q3, [sp, #1184]
	str	x23, [sp, #176]                 ; 8-byte Spill
	and	x23, x23, #0x7
	add	x30, sp, #1184
	ldr	s2, [x30, x23, lsl #2]
	fadd	s2, s2, s22
	mov	w23, #16384                     ; =0x4000
	movk	w23, #17600, lsl #16
	fmov	s3, w23
	fdiv	s2, s2, s3
	dup.4s	v4, v2[0]
	mov	w23, #1                         ; =0x1
	dup.2d	v2, x23
	ushll2.2d	v3, v0, #0
	and.16b	v18, v3, v2
	ushll2.2d	v3, v1, #0
	and.16b	v19, v3, v2
	ushll.2d	v3, v0, #0
	and.16b	v20, v3, v2
	ushll.2d	v3, v1, #0
	and.16b	v21, v3, v2
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
LBB1_43:                                ; %direct.true111.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x8, x8, #5
	add	x23, x25, x8
	ldp	q3, q2, [x23]
	fsub.4s	v3, v3, v4
	fsub.4s	v2, v2, v4
	add	x8, x19, x8
	ldp	q17, q23, [x8]
	bif.16b	v2, v23, v0
	bif.16b	v3, v17, v1
	stp	q3, q2, [x8]
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v16, v16, v18
	add.2d	v5, v5, v21
	fmov	x8, d5
	cmp	x8, #192
	b.lt	LBB1_43
; %bb.44:                               ; %direct.true148.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fsub.4s	v5, v8, v4
	fsub.4s	v6, v31, v4
	add	x8, x19, x11
	ldp	q2, q3, [x8]
	zip2.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	stp	q6, q5, [sp, #64]               ; 32-byte Folded Spill
	bit.16b	v3, v6, v4
	zip1.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v2, v5, v4
	stp	q2, q3, [x8]
	ldr	q2, [sp, #14144]
	ldr	q3, [sp, #14128]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v29, v0, v2
	and.16b	v12, v1, v3
	ldr	q2, [sp, #14112]
	ldr	q3, [sp, #14096]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v9, v0, v2
	and.16b	v8, v1, v3
	ldr	q2, [sp, #14080]
	ldr	q3, [sp, #14064]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v16, v0, v2
	and.16b	v5, v1, v3
	add	x8, x19, x7
	ldp	q3, q2, [x8]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v7, v0, v2
	and.16b	v6, v1, v3
LBB1_45:                                ; %direct.true148.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	add	x8, x19, x6, lsl #5
	ldp	q17, q4, [x8]
	and.16b	v17, v1, v17
	and.16b	v4, v0, v4
	fmul.4s	v23, v4, v4
	fmul.4s	v4, v17, v17
	fadd.4s	v4, v6, v4
	fadd.4s	v28, v7, v23
	ldp	q23, q17, [x8, #32]
	and.16b	v23, v1, v23
	and.16b	v17, v0, v17
	fmul.4s	v17, v17, v17
	fmul.4s	v23, v23, v23
	fadd.4s	v23, v5, v23
	fadd.4s	v17, v16, v17
	ldp	q10, q30, [x8, #64]
	and.16b	v10, v1, v10
	and.16b	v30, v0, v30
	fmul.4s	v30, v30, v30
	fmul.4s	v10, v10, v10
	fadd.4s	v10, v8, v10
	fadd.4s	v30, v9, v30
	ldp	q31, q13, [x8, #96]
	and.16b	v31, v1, v31
	and.16b	v13, v0, v13
	fmul.4s	v13, v13, v13
	fmul.4s	v31, v31, v31
	fadd.4s	v31, v12, v31
	fadd.4s	v13, v29, v13
	dup.2d	v15, x26
	and.16b	v22, v27, v15
	add.2d	v25, v25, v22
	and.16b	v22, v26, v15
	add.2d	v11, v11, v22
	and.16b	v3, v3, v15
	add.2d	v24, v24, v3
	and.16b	v2, v2, v15
	add.2d	v14, v14, v2
	bit.16b	v7, v28, v0
	bit.16b	v6, v4, v1
	bit.16b	v16, v17, v0
	bit.16b	v5, v23, v1
	bit.16b	v9, v30, v0
	bit.16b	v8, v10, v1
	bit.16b	v29, v13, v0
	bit.16b	v12, v31, v1
	fmov	x6, d14
	cmp	x6, #192
	b.lt	LBB1_45
; %bb.46:                               ; %direct.true185.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v11, #0000000000000000
	ldr	q10, [sp, #336]                 ; 16-byte Reload
	ldr	q15, [sp, #384]                 ; 16-byte Reload
	b	LBB1_48
LBB1_47:                                ; %else126
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x8, x21, x8
	stp	q13, q14, [x8]
	add.2d	v27, v27, v19
	add.2d	v30, v30, v20
	add.2d	v11, v11, v18
	add.2d	v26, v26, v21
	fmov	x8, d26
	cmp	x8, #192
	b.ge	LBB1_64
LBB1_48:                                ; %direct.true185.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w7, s10
	lsl	x8, x8, #5
	add	x6, x13, x8
	add	x23, x21, x8
	ldp	q13, q14, [x23]
	tbnz	w7, #0, LBB1_56
; %bb.49:                               ; %else105
                                        ;   in Loop: Header=BB1_48 Depth=2
	and	w7, w7, #0xff
	tbnz	w7, #1, LBB1_57
LBB1_50:                                ; %else108
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w7, #2, LBB1_58
LBB1_51:                                ; %else111
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w7, #3, LBB1_59
LBB1_52:                                ; %else114
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w7, #4, LBB1_60
LBB1_53:                                ; %else117
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w7, #5, LBB1_61
LBB1_54:                                ; %else120
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w7, #6, LBB1_62
LBB1_55:                                ; %else123
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbz	w7, #7, LBB1_47
	b	LBB1_63
LBB1_56:                                ; %cond.load104
                                        ;   in Loop: Header=BB1_48 Depth=2
	ld1.s	{ v13 }[0], [x6]
	and	w7, w7, #0xff
	tbz	w7, #1, LBB1_50
LBB1_57:                                ; %cond.load107
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #4
	ld1.s	{ v13 }[1], [x23]
	tbz	w7, #2, LBB1_51
LBB1_58:                                ; %cond.load110
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #8
	ld1.s	{ v13 }[2], [x23]
	tbz	w7, #3, LBB1_52
LBB1_59:                                ; %cond.load113
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #12
	ld1.s	{ v13 }[3], [x23]
	tbz	w7, #4, LBB1_53
LBB1_60:                                ; %cond.load116
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #16
	ld1.s	{ v14 }[0], [x23]
	tbz	w7, #5, LBB1_54
LBB1_61:                                ; %cond.load119
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #20
	ld1.s	{ v14 }[1], [x23]
	tbz	w7, #6, LBB1_55
LBB1_62:                                ; %cond.load122
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #24
	ld1.s	{ v14 }[2], [x23]
	tbz	w7, #7, LBB1_47
LBB1_63:                                ; %cond.load125
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x6, x6, #28
	ld1.s	{ v14 }[3], [x6]
	b	LBB1_47
LBB1_64:                                ; %direct.false186.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	b2, v15[0]
	mov.b	v2[4], v15[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	ldr	q3, [sp, #144]                  ; 16-byte Reload
	and.16b	v2, v2, v3
	mov	b3, v15[2]
	mov.b	v3[4], v15[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldp	q17, q23, [sp, #96]             ; 32-byte Folded Reload
	and.16b	v3, v3, v17
	mov	b17, v15[4]
	mov.b	v17[4], v15[5]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	mov	b22, v15[6]
	mov.b	v22[4], v15[7]
	and.16b	v17, v17, v23
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	ldr	q23, [sp, #128]                 ; 16-byte Reload
	and.16b	v22, v22, v23
Lloh24:
	adrp	x8, lCPI1_12@PAGE
Lloh25:
	ldr	d23, [x8, lCPI1_12@PAGEOFF]
	shl.8b	v24, v15, #7
	cmlt.8b	v24, v24, #0
	and.8b	v23, v24, v23
	addv.8b	b24, v23
	fmov	w8, s24
	str	q22, [sp, #1152]
	str	q17, [sp, #1136]
	str	q3, [sp, #1120]
	str	q2, [sp, #1104]
	and	x6, x9, #0x7
	add	x7, sp, #1104
	ldr	x6, [x7, x6, lsl #3]
	sub	x6, x6, x9
	lsl	x6, x6, #2
	add	x13, x13, x6
	add	x7, x21, x11
	ldp	q25, q23, [x7]
	tbnz	w8, #0, LBB1_134
; %bb.65:                               ; %else130
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #1, LBB1_135
LBB1_66:                                ; %else133
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #2, LBB1_136
LBB1_67:                                ; %else136
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #3, LBB1_137
LBB1_68:                                ; %else139
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #4, LBB1_138
LBB1_69:                                ; %else142
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #5, LBB1_139
LBB1_70:                                ; %else145
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #6, LBB1_140
LBB1_71:                                ; %else148
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #7, LBB1_73
LBB1_72:                                ; %cond.load150
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x13, #28
	ld1.s	{ v23 }[3], [x8]
LBB1_73:                                ; %else151
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	add	x13, x21, x11
	stp	q25, q23, [x13]
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v11, #0000000000000000
	b	LBB1_75
LBB1_74:                                ; %else176
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x8, x27, x8
	stp	q13, q14, [x8]
	add.2d	v27, v27, v19
	add.2d	v30, v30, v20
	add.2d	v11, v11, v18
	add.2d	v26, v26, v21
	fmov	x8, d26
	cmp	x8, #192
	b.ge	LBB1_91
LBB1_75:                                ; %direct.true211.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w7, s10
	lsl	x8, x8, #5
	add	x13, x10, x8
	add	x23, x27, x8
	ldp	q13, q14, [x23]
	tbnz	w7, #0, LBB1_83
; %bb.76:                               ; %else155
                                        ;   in Loop: Header=BB1_75 Depth=2
	and	w7, w7, #0xff
	tbnz	w7, #1, LBB1_84
LBB1_77:                                ; %else158
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbnz	w7, #2, LBB1_85
LBB1_78:                                ; %else161
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbnz	w7, #3, LBB1_86
LBB1_79:                                ; %else164
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbnz	w7, #4, LBB1_87
LBB1_80:                                ; %else167
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbnz	w7, #5, LBB1_88
LBB1_81:                                ; %else170
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbnz	w7, #6, LBB1_89
LBB1_82:                                ; %else173
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbz	w7, #7, LBB1_74
	b	LBB1_90
LBB1_83:                                ; %cond.load154
                                        ;   in Loop: Header=BB1_75 Depth=2
	ld1.s	{ v13 }[0], [x13]
	and	w7, w7, #0xff
	tbz	w7, #1, LBB1_77
LBB1_84:                                ; %cond.load157
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x23, x13, #4
	ld1.s	{ v13 }[1], [x23]
	tbz	w7, #2, LBB1_78
LBB1_85:                                ; %cond.load160
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x23, x13, #8
	ld1.s	{ v13 }[2], [x23]
	tbz	w7, #3, LBB1_79
LBB1_86:                                ; %cond.load163
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x23, x13, #12
	ld1.s	{ v13 }[3], [x23]
	tbz	w7, #4, LBB1_80
LBB1_87:                                ; %cond.load166
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x23, x13, #16
	ld1.s	{ v14 }[0], [x23]
	tbz	w7, #5, LBB1_81
LBB1_88:                                ; %cond.load169
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x23, x13, #20
	ld1.s	{ v14 }[1], [x23]
	tbz	w7, #6, LBB1_82
LBB1_89:                                ; %cond.load172
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x23, x13, #24
	ld1.s	{ v14 }[2], [x23]
	tbz	w7, #7, LBB1_74
LBB1_90:                                ; %cond.load175
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x13, x13, #28
	ld1.s	{ v14 }[3], [x13]
	b	LBB1_74
LBB1_91:                                ; %direct.false212.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
Lloh26:
	adrp	x8, lCPI1_13@PAGE
Lloh27:
	ldr	q2, [x8, lCPI1_13@PAGEOFF]
	and.16b	v11, v0, v2
Lloh28:
	adrp	x8, lCPI1_14@PAGE
Lloh29:
	ldr	q2, [x8, lCPI1_14@PAGEOFF]
	and.16b	v13, v1, v2
Lloh30:
	adrp	x8, lCPI1_16@PAGE
Lloh31:
	ldr	q2, [x8, lCPI1_16@PAGEOFF]
	and.16b	v30, v1, v2
	zip2.8b	v2, v15, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldp	q3, q17, [sp, #64]              ; 32-byte Folded Reload
	and.16b	v26, v2, v3
	zip1.8b	v3, v15, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v27, v3, v17
	fmul.4s	v17, v27, v27
	fmul.4s	v22, v26, v26
	fadd.4s	v7, v22, v7
	fadd.4s	v6, v17, v6
	and.16b	v3, v3, v6
	and.16b	v2, v2, v7
	ldr	d7, [sp, #168]                  ; 8-byte Reload
	zip2.8b	v6, v7, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bit.16b	v2, v28, v6
	zip1.8b	v6, v7, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	bit.16b	v3, v4, v6
	fadd.4s	v3, v5, v3
	fadd.4s	v2, v16, v2
	fadd.4s	v2, v9, v2
	fadd.4s	v3, v8, v3
	fadd.4s	v4, v12, v3
	fadd.4s	v5, v29, v2
	fmov	w8, s13
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldr	q2, [sp, #368]                  ; 16-byte Reload
	str	d2, [sp, #504]
	ldrb	w13, [x13]
	add	x7, sp, #1056
	orr	x8, x7, x8, lsl #2
	str	q5, [sp, #1072]
	str	q4, [sp, #1056]
	ldr	s2, [x8]
	tst	w5, w13
	mov.s	w8, v13[1]
	movi.2d	v31, #0000000000000000
	fcsel	s6, s2, s31, ne
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w16, w8
	str	q4, [sp, #1024]
	ldr	s2, [sp, #1024]
	tst	w8, #0x1
	fcsel	s7, s2, s31, ne
	mov.s	w8, v13[2]
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	add	x7, sp, #992
	orr	x8, x7, x8, lsl #2
	ldrb	w13, [x13]
	and	w13, w14, w13
	stp	q4, q5, [sp, #992]
	ldr	s2, [x8]
	tst	w13, #0x1
	fcsel	s16, s2, s31, ne
	mov.s	w8, v13[3]
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	add	x7, sp, #960
	orr	x8, x7, x8, lsl #2
	ldrb	w13, [x13]
	and	w13, w15, w13
	stp	q4, q5, [sp, #960]
	ldr	s2, [x8]
	tst	w13, #0x1
	fcsel	s17, s2, s31, ne
	fmov	w8, s11
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w13, [x13]
	and	w13, w3, w13
	stp	q4, q5, [sp, #928]
	add	x7, sp, #928
	ldr	s2, [x7, w8, uxtw #2]
	tst	w13, #0x1
	fcsel	s2, s2, s31, ne
	mov.s	w8, v11[1]
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w13, [x13]
	and	w13, w2, w13
	stp	q4, q5, [sp, #896]
	add	x7, sp, #896
	ldr	s3, [x7, w8, uxtw #2]
	tst	w13, #0x1
	fcsel	s3, s3, s31, ne
	mov.s	w8, v11[2]
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w13, [x13]
	and	w13, w0, w13
	stp	q4, q5, [sp, #864]
	add	x7, sp, #864
	ldr	s22, [x7, w8, uxtw #2]
	tst	w13, #0x1
	fcsel	s22, s22, s31, ne
	mov.s	w8, v11[3]
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w13, [x13]
	and	w13, w1, w13
	stp	q4, q5, [sp, #832]
	add	x7, sp, #832
	ldr	s28, [x7, w8, uxtw #2]
	tst	w13, #0x1
	fcsel	s28, s28, s31, ne
	mov.s	v2[1], v3[0]
	mov.s	v2[2], v22[0]
	mov.s	v2[3], v28[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v17[0]
	fadd.4s	v4, v4, v6
	fadd.4s	v5, v5, v2
	fmov	w8, s30
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w13, [x13]
	add	x7, sp, #800
	orr	x8, x7, x8, lsl #2
	stp	q4, q5, [sp, #800]
	ldr	s2, [x8]
	tst	w5, w13
	mov.s	w8, v30[1]
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w13, [x13]
	and	w13, w16, w13
	fcsel	s6, s2, s31, ne
	add	x16, sp, #768
	orr	x8, x16, x8, lsl #2
	stp	q4, q5, [sp, #768]
	ldr	s2, [x8]
	tst	w13, #0x1
	mov.s	w8, v30[2]
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	fcsel	s7, s2, s31, ne
	ldrb	w8, [x13]
	and	w8, w14, w8
	str	q4, [sp, #736]
	tst	w8, #0x1
	mov.s	w8, v30[3]
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w13, [x13]
	and	w13, w15, w13
Lloh32:
	adrp	x14, lCPI1_15@PAGE
Lloh33:
	ldr	q2, [x14, lCPI1_15@PAGEOFF]
	and.16b	v2, v0, v2
	ldr	s3, [sp, #736]
	fcsel	s16, s3, s31, ne
	add	x14, sp, #704
	orr	x8, x14, x8, lsl #2
	stp	q4, q5, [sp, #704]
	ldr	s3, [x8]
	tst	w13, #0x1
	fmov	w8, s2
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w13, [x13]
	and	w13, w3, w13
	fcsel	s17, s3, s31, ne
	stp	q4, q5, [sp, #672]
	add	x14, sp, #672
	ldr	s3, [x14, w8, uxtw #2]
	tst	w13, #0x1
	mov.s	w8, v2[1]
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w13, [x13]
	and	w13, w2, w13
	fcsel	s22, s3, s31, ne
	stp	q4, q5, [sp, #640]
	add	x14, sp, #640
	ldr	s3, [x14, w8, uxtw #2]
	tst	w13, #0x1
	mov.s	w8, v2[2]
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w13, [x13]
	and	w13, w0, w13
	fcsel	s3, s3, s31, ne
	stp	q4, q5, [sp, #608]
	add	x14, sp, #608
	ldr	s28, [x14, w8, uxtw #2]
	tst	w13, #0x1
	mov.s	w8, v2[3]
	add	x13, sp, #504
	bfxil	x13, x8, #0, #3
	ldrb	w13, [x13]
	and	w13, w1, w13
	movi.4s	v2, #4
	and.16b	v2, v1, v2
	fcsel	s28, s28, s31, ne
	stp	q4, q5, [sp, #576]
	add	x14, sp, #576
	ldr	s29, [x14, w8, uxtw #2]
	tst	w13, #0x1
	fcsel	s29, s29, s31, ne
	fmov	w8, s2
	add	x13, sp, #504
	orr	x13, x13, x8
	ldrb	w13, [x13]
	tst	w5, w13
	mov.s	v22[1], v3[0]
	mov.s	v22[2], v28[0]
	mov.s	v22[3], v29[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v17[0]
	fadd.4s	v2, v4, v6
	fadd.4s	v3, v5, v22
	stp	q2, q3, [sp, #544]
	add	x13, sp, #544
	ldr	s3, [x13, w8, uxtw #2]
	fcsel	s3, s3, s31, ne
	tst	w12, #0x1
	fadd	s2, s2, s3
	fcsel	s3, s2, s31, ne
	ldr	w8, [sp, #240]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s4, s2, s31, ne
	ldr	w8, [sp, #224]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s5, s2, s31, ne
	ldr	w8, [sp, #208]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s6, s2, s31, ne
	tst	w17, #0x1
	fcsel	s7, s2, s31, ne
	ldr	w8, [sp, #192]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s16, s2, s31, ne
	ldr	w8, [sp, #188]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s17, s2, s31, ne
	tst	w4, #0x1
	movi.2d	v22, #0000000000000000
	fcsel	s2, s2, s31, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v5[0]
	mov.s	v3[3], v6[0]
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v2[0]
	stp	q3, q7, [sp, #512]
	ldr	x8, [sp, #176]                  ; 8-byte Reload
	and	x8, x8, #0x7
	add	x12, sp, #512
	ldr	s6, [x12, x8, lsl #2]
	add	x8, x10, x6
	add	x10, x27, x11
	ldp	q5, q4, [x10]
	fmov	w10, s24
	tbnz	w10, #0, LBB1_141
; %bb.92:                               ; %else180
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x13, [sp, #352]                 ; 8-byte Reload
	tbnz	w10, #1, LBB1_142
LBB1_93:                                ; %else183
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #2, LBB1_143
LBB1_94:                                ; %else186
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #3, LBB1_144
LBB1_95:                                ; %else189
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #4, LBB1_145
LBB1_96:                                ; %else192
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #5, LBB1_146
LBB1_97:                                ; %else195
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #6, LBB1_147
LBB1_98:                                ; %else198
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_100
LBB1_99:                                ; %cond.load200
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x8, #28
	ld1.s	{ v4 }[3], [x8]
LBB1_100:                               ; %else201
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	fadd	s2, s6, s22
	mov	w8, #16384                      ; =0x4000
	movk	w8, #17600, lsl #16
	fmov	s3, w8
	fdiv	s2, s2, s3
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s3, w8
	fadd	s2, s2, s3
	fsqrt	s2, s2
	add	x8, x27, x11
	stp	q5, q4, [x8]
	dup.4s	v6, v2[0]
	ldr	q2, [sp, #256]                  ; 16-byte Reload
	fmov	x8, d2
	add	x8, x13, x8, lsl #2
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v22, #0000000000000000
	b	LBB1_102
LBB1_101:                               ; %else218
                                        ;   in Loop: Header=BB1_102 Depth=2
	add.2d	v16, v16, v19
	add.2d	v17, v17, v20
	add.2d	v22, v22, v18
	add.2d	v7, v7, v21
	fmov	x10, d7
	cmp	x10, #192
	b.ge	LBB1_118
LBB1_102:                               ; %direct.true236.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s10
	lsl	x10, x10, #5
	add	x12, x19, x10
	ldp	q2, q28, [x12]
	and.16b	v2, v1, v2
	fdiv.4s	v2, v2, v6
	add	x12, x21, x10
	ldp	q3, q29, [x12]
	and.16b	v3, v1, v3
	fmul.4s	v2, v2, v3
	add	x12, x27, x10
	ldp	q3, q30, [x12]
	and.16b	v3, v1, v3
	fadd.4s	v31, v2, v3
	add	x10, x8, x10
	tbnz	w11, #0, LBB1_111
; %bb.103:                              ; %else204
                                        ;   in Loop: Header=BB1_102 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_112
LBB1_104:                               ; %else206
                                        ;   in Loop: Header=BB1_102 Depth=2
	tbnz	w11, #2, LBB1_113
LBB1_105:                               ; %else208
                                        ;   in Loop: Header=BB1_102 Depth=2
	tbz	w11, #3, LBB1_107
LBB1_106:                               ; %cond.store209
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x12, x10, #12
	st1.s	{ v31 }[3], [x12]
LBB1_107:                               ; %else210
                                        ;   in Loop: Header=BB1_102 Depth=2
	and.16b	v2, v0, v28
	fdiv.4s	v2, v2, v6
	and.16b	v3, v0, v29
	fmul.4s	v2, v2, v3
	and.16b	v3, v0, v30
	fadd.4s	v28, v2, v3
	tbnz	w11, #4, LBB1_114
; %bb.108:                              ; %else212
                                        ;   in Loop: Header=BB1_102 Depth=2
	tbnz	w11, #5, LBB1_115
LBB1_109:                               ; %else214
                                        ;   in Loop: Header=BB1_102 Depth=2
	tbnz	w11, #6, LBB1_116
LBB1_110:                               ; %else216
                                        ;   in Loop: Header=BB1_102 Depth=2
	tbz	w11, #7, LBB1_101
	b	LBB1_117
LBB1_111:                               ; %cond.store
                                        ;   in Loop: Header=BB1_102 Depth=2
	str	s31, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_104
LBB1_112:                               ; %cond.store205
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x12, x10, #4
	st1.s	{ v31 }[1], [x12]
	tbz	w11, #2, LBB1_105
LBB1_113:                               ; %cond.store207
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x12, x10, #8
	st1.s	{ v31 }[2], [x12]
	tbnz	w11, #3, LBB1_106
	b	LBB1_107
LBB1_114:                               ; %cond.store211
                                        ;   in Loop: Header=BB1_102 Depth=2
	str	s28, [x10, #16]
	tbz	w11, #5, LBB1_109
LBB1_115:                               ; %cond.store213
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x12, x10, #20
	st1.s	{ v28 }[1], [x12]
	tbz	w11, #6, LBB1_110
LBB1_116:                               ; %cond.store215
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x12, x10, #24
	st1.s	{ v28 }[2], [x12]
	tbz	w11, #7, LBB1_101
LBB1_117:                               ; %cond.store217
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x10, x10, #28
	st1.s	{ v28 }[3], [x10]
	b	LBB1_101
LBB1_118:                               ; %direct.false237.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fdiv.4s	v0, v27, v6
	fmov	w8, s24
	zip1.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v2, v1, v25
	fmul.4s	v0, v0, v2
	and.16b	v1, v1, v5
	fadd.4s	v0, v0, v1
	ldp	q1, q2, [sp, #304]              ; 32-byte Folded Reload
	ldp	q5, q3, [sp, #272]              ; 32-byte Folded Reload
	stp	q2, q3, [sp, #432]
	stp	q5, q1, [sp, #464]
	and	x10, x9, #0x7
	add	x11, sp, #432
	ldr	x10, [x11, x10, lsl #3]
	sub	x9, x10, x9
	add	x9, x13, x9, lsl #2
	tbnz	w8, #0, LBB1_148
; %bb.119:                              ; %else221
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #1, LBB1_149
LBB1_120:                               ; %else223
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #2, LBB1_150
LBB1_121:                               ; %else225
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #3, LBB1_123
LBB1_122:                               ; %cond.store226
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #12
	st1.s	{ v0 }[3], [x10]
LBB1_123:                               ; %else227
                                        ;   in Loop: Header=BB1_4 Depth=1
	fdiv.4s	v0, v26, v6
	zip2.8b	v1, v15, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v2, v1, v23
	fmul.4s	v0, v0, v2
	and.16b	v1, v1, v4
	fadd.4s	v0, v0, v1
	tbnz	w8, #4, LBB1_151
; %bb.124:                              ; %else229
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #5, LBB1_152
LBB1_125:                               ; %else231
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #6, LBB1_153
LBB1_126:                               ; %else233
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #7, LBB1_2
	b	LBB1_154
LBB1_127:                               ; %cond.load79
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v25 }[0], [x8]
	tbz	w12, #1, LBB1_33
LBB1_128:                               ; %cond.load82
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x8, #4
	ld1.s	{ v25 }[1], [x14]
	tbz	w12, #2, LBB1_34
LBB1_129:                               ; %cond.load85
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x8, #8
	ld1.s	{ v25 }[2], [x14]
	tbz	w12, #3, LBB1_35
LBB1_130:                               ; %cond.load88
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x8, #12
	ld1.s	{ v25 }[3], [x14]
	tbz	w12, #4, LBB1_36
LBB1_131:                               ; %cond.load91
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x8, #16
	ld1.s	{ v24 }[0], [x14]
	tbz	w12, #5, LBB1_37
LBB1_132:                               ; %cond.load94
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x8, #20
	ld1.s	{ v24 }[1], [x14]
	tbz	w12, #6, LBB1_38
LBB1_133:                               ; %cond.load97
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x8, #24
	ld1.s	{ v24 }[2], [x14]
	str	q3, [sp, #384]                  ; 16-byte Spill
	str	q17, [sp, #336]                 ; 16-byte Spill
	tbnz	w12, #7, LBB1_39
	b	LBB1_40
LBB1_134:                               ; %cond.load129
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v25 }[0], [x13]
	tbz	w8, #1, LBB1_66
LBB1_135:                               ; %cond.load132
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x7, x13, #4
	ld1.s	{ v25 }[1], [x7]
	tbz	w8, #2, LBB1_67
LBB1_136:                               ; %cond.load135
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x7, x13, #8
	ld1.s	{ v25 }[2], [x7]
	tbz	w8, #3, LBB1_68
LBB1_137:                               ; %cond.load138
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x7, x13, #12
	ld1.s	{ v25 }[3], [x7]
	tbz	w8, #4, LBB1_69
LBB1_138:                               ; %cond.load141
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x7, x13, #16
	ld1.s	{ v23 }[0], [x7]
	tbz	w8, #5, LBB1_70
LBB1_139:                               ; %cond.load144
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x7, x13, #20
	ld1.s	{ v23 }[1], [x7]
	tbz	w8, #6, LBB1_71
LBB1_140:                               ; %cond.load147
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x7, x13, #24
	ld1.s	{ v23 }[2], [x7]
	tbnz	w8, #7, LBB1_72
	b	LBB1_73
LBB1_141:                               ; %cond.load179
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v5 }[0], [x8]
	ldr	x13, [sp, #352]                 ; 8-byte Reload
	tbz	w10, #1, LBB1_93
LBB1_142:                               ; %cond.load182
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #4
	ld1.s	{ v5 }[1], [x12]
	tbz	w10, #2, LBB1_94
LBB1_143:                               ; %cond.load185
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #8
	ld1.s	{ v5 }[2], [x12]
	tbz	w10, #3, LBB1_95
LBB1_144:                               ; %cond.load188
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #12
	ld1.s	{ v5 }[3], [x12]
	tbz	w10, #4, LBB1_96
LBB1_145:                               ; %cond.load191
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #16
	ld1.s	{ v4 }[0], [x12]
	tbz	w10, #5, LBB1_97
LBB1_146:                               ; %cond.load194
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #20
	ld1.s	{ v4 }[1], [x12]
	tbz	w10, #6, LBB1_98
LBB1_147:                               ; %cond.load197
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #24
	ld1.s	{ v4 }[2], [x12]
	tbnz	w10, #7, LBB1_99
	b	LBB1_100
LBB1_148:                               ; %cond.store220
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9]
	tbz	w8, #1, LBB1_120
LBB1_149:                               ; %cond.store222
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #4
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #2, LBB1_121
LBB1_150:                               ; %cond.store224
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #8
	st1.s	{ v0 }[2], [x10]
	tbnz	w8, #3, LBB1_122
	b	LBB1_123
LBB1_151:                               ; %cond.store228
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9, #16]
	tbz	w8, #5, LBB1_125
LBB1_152:                               ; %cond.store230
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #6, LBB1_126
LBB1_153:                               ; %cond.store232
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w8, #7, LBB1_2
LBB1_154:                               ; %cond.store234
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x9, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB1_2
LBB1_155:                               ; %block.batch.exit
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #1808
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d9, d8, [sp, #-112]!            ; 16-byte Folded Spill
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2640
	str	x0, [sp, #56]                   ; 8-byte Spill
	cbz	w3, LBB0_87
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w24, #0                         ; =0x0
	add	x25, sp, #3664
	ldp	w23, w8, [x2, #44]
	stp	w8, w3, [sp, #48]               ; 8-byte Folded Spill
	add	x28, sp, #592
	ldp	w8, w9, [x2]
	ldp	w10, w11, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Spill
	str	x11, [sp, #40]                  ; 8-byte Spill
	movi.2d	v8, #0000000000000000
	str	w23, [sp, #20]                  ; 4-byte Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w8, w27, #1
	cmp	w8, w23
	cset	w9, eq
	csinc	w8, wzr, w27, eq
	cinc	w10, w7, eq
	ldr	w11, [sp, #48]                  ; 4-byte Reload
	cmp	w10, w11
	cset	w11, eq
	ands	w11, w9, w11
	csel	w9, wzr, w10, ne
	add	w10, w6, w11
	add	w24, w24, #1
	cmp	w24, w22
	b.eq	LBB0_86
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_23 Depth 2
                                        ;       Child Loop BB0_24 Depth 3
                                        ;       Child Loop BB0_26 Depth 3
                                        ;     Child Loop BB0_32 Depth 2
                                        ;     Child Loop BB0_49 Depth 2
                                        ;     Child Loop BB0_52 Depth 2
                                        ;     Child Loop BB0_70 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
	stp	w9, w10, [sp, #72]              ; 8-byte Folded Spill
	mov	x13, x8
	ubfiz	x8, x8, #5, #32
	ldr	x12, [sp, #40]                  ; 8-byte Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	ccmp	x8, x12, #2, hi
	csel	x8, x10, xzr, ls
	cmp	x8, #32
	b.lo	LBB0_21
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #56]                   ; 8-byte Reload
	ldr	x21, [x8]
	ldr	x22, [x8, #16]
	ldr	x20, [x8, #48]
	mov	x27, x13
	ubfiz	w26, w13, #2, #27
	mov	w8, #3072                       ; =0xc00
	umull	x19, w26, w8
	umaddl	x1, w26, w8, x21
	add	x0, sp, #3664
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x8, sp, #352
	ldr	q0, [x8, #3312]
	ldr	q1, [x8, #3328]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [x8, #3344]
	ldr	q1, [x8, #3360]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [x8, #3376]
	ldr	q1, [x8, #3392]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [x8, #3408]
	ldr	q1, [x8, #3424]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, x25, #224
	mov	w9, #4                          ; =0x4
LBB0_5:                                 ; %direct.true46.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB0_5
; %bb.6:                                ; %direct.false47.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, sp, #592
	mov	x1, x22
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #128]              ; 32-byte Folded Spill
	stp	q5, q3, [sp, #80]               ; 32-byte Folded Spill
	stp	q6, q16, [sp, #176]             ; 32-byte Folded Spill
	str	q7, [sp, #112]                  ; 16-byte Spill
	str	q17, [sp, #160]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldp	q1, q0, [sp, #80]               ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #128]              ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #160]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w9, #1145044992                 ; =0x44400000
	fmov	s1, w9
	fdiv	s0, s0, s1
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s1, w9
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v0, v0[0]
	add	x9, x20, x19
LBB0_7:                                 ; %direct.true103.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x25, x8
	ldp	q1, q2, [x10]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x10, x28, x8
	ldp	q4, q3, [x10]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_7
; %bb.8:                                ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	orr	w8, w26, #0x1
	mov	w9, #3072                       ; =0xc00
	umull	x19, w8, w9
	umaddl	x1, w8, w9, x21
	add	x0, sp, #3664
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x8, sp, #352
	ldr	q0, [x8, #3312]
	ldr	q1, [x8, #3328]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [x8, #3344]
	ldr	q1, [x8, #3360]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [x8, #3376]
	ldr	q1, [x8, #3392]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [x8, #3408]
	ldr	q1, [x8, #3424]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, x25, #224
	mov	w9, #4                          ; =0x4
LBB0_9:                                 ; %direct.true46.i15.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB0_9
; %bb.10:                               ; %direct.false47.i29.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, sp, #592
	mov	x1, x22
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #128]              ; 32-byte Folded Spill
	stp	q5, q3, [sp, #80]               ; 32-byte Folded Spill
	stp	q6, q16, [sp, #176]             ; 32-byte Folded Spill
	str	q7, [sp, #112]                  ; 16-byte Spill
	str	q17, [sp, #160]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldp	q1, q0, [sp, #80]               ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #128]              ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #160]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w9, #1145044992                 ; =0x44400000
	fmov	s1, w9
	fdiv	s0, s0, s1
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s1, w9
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v0, v0[0]
	add	x9, x20, x19
LBB0_11:                                ; %direct.true103.i33.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x25, x8
	ldp	q1, q2, [x10]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x10, x28, x8
	ldp	q4, q3, [x10]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_11
; %bb.12:                               ; %llm_rows.full_packet.exit41.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	orr	w8, w26, #0x2
	mov	w9, #3072                       ; =0xc00
	umull	x19, w8, w9
	umaddl	x1, w8, w9, x21
	add	x0, sp, #3664
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x8, sp, #352
	ldr	q0, [x8, #3312]
	ldr	q1, [x8, #3328]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [x8, #3344]
	ldr	q1, [x8, #3360]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [x8, #3376]
	ldr	q1, [x8, #3392]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [x8, #3408]
	ldr	q1, [x8, #3424]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, x25, #224
	mov	w9, #4                          ; =0x4
LBB0_13:                                ; %direct.true46.i54.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB0_13
; %bb.14:                               ; %direct.false47.i68.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, sp, #592
	mov	x1, x22
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #128]              ; 32-byte Folded Spill
	stp	q5, q3, [sp, #80]               ; 32-byte Folded Spill
	stp	q6, q16, [sp, #176]             ; 32-byte Folded Spill
	str	q7, [sp, #112]                  ; 16-byte Spill
	str	q17, [sp, #160]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldp	q1, q0, [sp, #80]               ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #128]              ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #160]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w9, #1145044992                 ; =0x44400000
	fmov	s1, w9
	fdiv	s0, s0, s1
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s1, w9
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v0, v0[0]
	add	x9, x20, x19
LBB0_15:                                ; %direct.true103.i72.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x25, x8
	ldp	q1, q2, [x10]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x10, x28, x8
	ldp	q4, q3, [x10]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_15
; %bb.16:                               ; %llm_rows.full_packet.exit80.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	orr	w8, w26, #0x3
	mov	w9, #3072                       ; =0xc00
	umull	x19, w8, w9
	umaddl	x1, w8, w9, x21
	add	x0, sp, #3664
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x8, sp, #352
	ldr	q0, [x8, #3312]
	ldr	q1, [x8, #3328]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [x8, #3344]
	ldr	q1, [x8, #3360]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [x8, #3376]
	ldr	q1, [x8, #3392]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [x8, #3408]
	ldr	q1, [x8, #3424]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, x25, #224
	mov	w9, #4                          ; =0x4
LBB0_17:                                ; %direct.true46.i93.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB0_17
; %bb.18:                               ; %direct.false47.i107.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, sp, #592
	mov	x1, x22
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #128]              ; 32-byte Folded Spill
	stp	q5, q3, [sp, #80]               ; 32-byte Folded Spill
	stp	q6, q16, [sp, #176]             ; 32-byte Folded Spill
	str	q7, [sp, #112]                  ; 16-byte Spill
	str	q17, [sp, #160]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldp	q1, q0, [sp, #80]               ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #128]              ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #160]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	add	x9, x20, x19
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w10, #1145044992                ; =0x44400000
	fmov	s1, w10
	fdiv	s0, s0, s1
	mov	w10, #50604                     ; =0xc5ac
	movk	w10, #14119, lsl #16
	fmov	s1, w10
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v0, v0[0]
LBB0_19:                                ; %direct.true103.i111.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x25, x8
	ldp	q1, q2, [x10]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x10, x28, x8
	ldp	q4, q3, [x10]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_19
; %bb.20:                               ; %llm_rows.full_packet.exit119.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	w7, w6, [sp, #72]               ; 8-byte Folded Reload
	ldr	w22, [sp, #52]                  ; 4-byte Reload
	b	LBB0_2
LBB0_21:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	x13, [sp, #64]                  ; 8-byte Spill
	str	w24, [sp, #36]                  ; 4-byte Spill
	str	x8, [sp, #24]                   ; 8-byte Spill
	lsr	x20, x8, #3
	cbz	x20, LBB0_28
; %bb.22:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w26, #0                         ; =0x0
	ldp	x9, x8, [sp, #56]               ; 16-byte Folded Reload
	ldr	x27, [x9]
	ldr	x22, [x9, #16]
	ldr	x23, [x9, #48]
	lsl	w19, w8, #2
	mov	x21, x19
LBB0_23:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_24 Depth 3
                                        ;       Child Loop BB0_26 Depth 3
	and	x8, x21, #0x1fffffff
	mov	w9, #3072                       ; =0xc00
	umaddl	x24, w8, w9, x23
	add	w8, w26, w19
	and	w8, w8, #0x1fffffff
	umaddl	x1, w8, w9, x27
	add	x0, sp, #3664
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x8, sp, #352
	ldr	q0, [x8, #3312]
	ldr	q1, [x8, #3328]
	fmul.4s	v2, v1, v1
	fmul.4s	v3, v0, v0
	ldr	q0, [x8, #3344]
	ldr	q1, [x8, #3360]
	fmul.4s	v4, v1, v1
	fmul.4s	v5, v0, v0
	ldr	q0, [x8, #3376]
	ldr	q1, [x8, #3392]
	fmul.4s	v7, v1, v1
	fmul.4s	v6, v0, v0
	ldr	q0, [x8, #3408]
	ldr	q1, [x8, #3424]
	fmul.4s	v16, v1, v1
	fmul.4s	v17, v0, v0
	add	x8, x25, #224
	mov	w9, #4                          ; =0x4
LBB0_24:                                ; %direct.true46.i132.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q1, q0, [x8, #-96]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v2, v2, v0
	fadd.4s	v3, v3, v1
	ldp	q1, q0, [x8, #-64]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v4, v4, v0
	fadd.4s	v5, v5, v1
	ldp	q1, q0, [x8, #-32]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v7, v7, v0
	fadd.4s	v6, v6, v1
	ldp	q1, q0, [x8], #128
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	fadd.4s	v16, v16, v0
	fadd.4s	v17, v17, v1
	cmp	x9, #92
	add	x9, x9, #4
	b.lo	LBB0_24
; %bb.25:                               ; %direct.false47.i146.i
                                        ;   in Loop: Header=BB0_23 Depth=2
	add	x0, sp, #592
	mov	x1, x22
	mov	w2, #3072                       ; =0xc00
	stp	q4, q2, [sp, #128]              ; 32-byte Folded Spill
	stp	q5, q3, [sp, #80]               ; 32-byte Folded Spill
	stp	q6, q16, [sp, #176]             ; 32-byte Folded Spill
	str	q7, [sp, #112]                  ; 16-byte Spill
	str	q17, [sp, #160]                 ; 16-byte Spill
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldp	q1, q0, [sp, #80]               ; 32-byte Folded Reload
	fadd.4s	v0, v0, v1
	ldp	q2, q1, [sp, #128]              ; 32-byte Folded Reload
	fadd.4s	v1, v1, v2
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldp	q2, q3, [sp, #160]              ; 32-byte Folded Reload
	fadd.4s	v0, v0, v3
	fadd.4s	v0, v0, v2
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	fadd.4s	v1, v1, v2
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s8
	mov	w9, #1145044992                 ; =0x44400000
	fmov	s1, w9
	fdiv	s0, s0, s1
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s1, w9
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v0, v0[0]
LBB0_26:                                ; %direct.true103.i150.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_23 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x25, x8
	ldp	q1, q2, [x9]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x9, x28, x8
	ldp	q4, q3, [x9]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	add	x9, x24, x8
	stp	q1, q2, [x9]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_26
; %bb.27:                               ; %llm_rows.full_packet.exit158.i
                                        ;   in Loop: Header=BB0_23 Depth=2
	add	w26, w26, #1
	add	w21, w21, #1
	cmp	w26, w20
	b.ne	LBB0_23
LBB0_28:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #24]                   ; 8-byte Reload
	and	w8, w8, #0x7
	ldr	w22, [sp, #52]                  ; 4-byte Reload
	ldr	w24, [sp, #36]                  ; 4-byte Reload
	ldr	w23, [sp, #20]                  ; 4-byte Reload
	ldp	w7, w6, [sp, #72]               ; 8-byte Folded Reload
	ldr	x27, [sp, #64]                  ; 8-byte Reload
	cbz	w8, LBB0_2
; %bb.29:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v1, w8
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v4
	cmhi.4s	v1, v1, v3
	uzp1.8h	v5, v1, v0
	umaxv.8h	h2, v5
	fmov	w8, s2
	tbz	w8, #0, LBB0_2
; %bb.30:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	ldr	x13, [sp, #56]                  ; 8-byte Reload
	ldr	x11, [x13, #16]
	ldr	x8, [x13, #48]
Lloh4:
	adrp	x9, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x9, lCPI0_0@PAGEOFF]
	and.16b	v2, v5, v2
	addv.8h	h2, v2
	fmov	w9, s2
	and	w10, w9, #0xff
	ubfiz	w9, w27, #2, #27
	orr	w9, w9, w20
	ldr	x13, [x13]
	fmov	s6, w9
	and.16b	v6, v1, v6
	fmov	w9, s6
	mov	w14, #3072                      ; =0xc00
	umaddl	x13, w9, w14, x13
	umull	x9, w9, w14
	b	LBB0_32
LBB0_31:                                ; %else232
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x14, x25, x12
	stp	q6, q7, [x14]
	add	x12, x12, #32
	cmp	x12, #3072
	b.eq	LBB0_48
LBB0_32:                                ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w15, s2
	add	x14, x13, x12
	add	x16, x25, x12
	ldr	q6, [x16]
	tbnz	w15, #0, LBB0_40
; %bb.33:                               ; %else
                                        ;   in Loop: Header=BB0_32 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_41
LBB0_34:                                ; %else214
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w15, #2, LBB0_42
LBB0_35:                                ; %else217
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w15, #3, LBB0_43
LBB0_36:                                ; %else220
                                        ;   in Loop: Header=BB0_32 Depth=2
	ldr	q7, [x16, #16]
	tbnz	w15, #4, LBB0_44
LBB0_37:                                ; %else223
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w15, #5, LBB0_45
LBB0_38:                                ; %else226
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbnz	w15, #6, LBB0_46
LBB0_39:                                ; %else229
                                        ;   in Loop: Header=BB0_32 Depth=2
	tbz	w15, #7, LBB0_31
	b	LBB0_47
LBB0_40:                                ; %cond.load
                                        ;   in Loop: Header=BB0_32 Depth=2
	ld1.s	{ v6 }[0], [x14]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_34
LBB0_41:                                ; %cond.load213
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x17, x14, #4
	ld1.s	{ v6 }[1], [x17]
	tbz	w15, #2, LBB0_35
LBB0_42:                                ; %cond.load216
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x17, x14, #8
	ld1.s	{ v6 }[2], [x17]
	tbz	w15, #3, LBB0_36
LBB0_43:                                ; %cond.load219
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x17, x14, #12
	ld1.s	{ v6 }[3], [x17]
	ldr	q7, [x16, #16]
	tbz	w15, #4, LBB0_37
LBB0_44:                                ; %cond.load222
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x16, x14, #16
	ld1.s	{ v7 }[0], [x16]
	tbz	w15, #5, LBB0_38
LBB0_45:                                ; %cond.load225
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x16, x14, #20
	ld1.s	{ v7 }[1], [x16]
	tbz	w15, #6, LBB0_39
LBB0_46:                                ; %cond.load228
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x16, x14, #24
	ld1.s	{ v7 }[2], [x16]
	tbz	w15, #7, LBB0_31
LBB0_47:                                ; %cond.load231
                                        ;   in Loop: Header=BB0_32 Depth=2
	add	x14, x14, #28
	ld1.s	{ v7 }[3], [x14]
	b	LBB0_31
LBB0_48:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x12, sp, #352
	ldr	q6, [x12, #3328]
	ldr	q7, [x12, #3312]
	fmul.4s	v16, v7, v7
	fmul.4s	v6, v6, v6
	ldr	q7, [x12, #3360]
	ldr	q17, [x12, #3344]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v7, v7
	ldr	q7, [x12, #3392]
	ldr	q19, [x12, #3376]
	fmul.4s	v21, v19, v19
	fmul.4s	v22, v7, v7
	ldr	q7, [x12, #3424]
	ldr	q19, [x12, #3408]
	fmul.4s	v23, v19, v19
	fmul.4s	v24, v7, v7
	and.16b	v7, v0, v6
	and.16b	v6, v1, v16
	and.16b	v20, v0, v18
	and.16b	v19, v1, v17
	and.16b	v16, v0, v22
	and.16b	v21, v1, v21
	and.16b	v18, v0, v24
	and.16b	v17, v1, v23
	add	x12, x25, #224
	mov	w13, #4                         ; =0x4
LBB0_49:                                ; %direct.true46.i171.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q23, q22, [x12, #-96]
	and.16b	v23, v1, v23
	and.16b	v22, v0, v22
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	fadd.4s	v23, v6, v23
	fadd.4s	v22, v7, v22
	ldp	q25, q24, [x12, #-64]
	and.16b	v25, v1, v25
	and.16b	v24, v0, v24
	fmul.4s	v24, v24, v24
	fmul.4s	v25, v25, v25
	fadd.4s	v25, v19, v25
	fadd.4s	v24, v20, v24
	ldp	q27, q26, [x12, #-32]
	and.16b	v27, v1, v27
	and.16b	v26, v0, v26
	fmul.4s	v26, v26, v26
	fmul.4s	v27, v27, v27
	fadd.4s	v27, v21, v27
	fadd.4s	v26, v16, v26
	ldp	q29, q28, [x12], #128
	and.16b	v29, v1, v29
	and.16b	v28, v0, v28
	fmul.4s	v28, v28, v28
	fmul.4s	v29, v29, v29
	fadd.4s	v29, v17, v29
	fadd.4s	v28, v18, v28
	bit.16b	v7, v22, v0
	bit.16b	v6, v23, v1
	bit.16b	v20, v24, v0
	bit.16b	v19, v25, v1
	bit.16b	v16, v26, v0
	bit.16b	v21, v27, v1
	bit.16b	v18, v28, v0
	bit.16b	v17, v29, v1
	cmp	x13, #92
	add	x13, x13, #4
	b.lo	LBB0_49
; %bb.50:                               ; %direct.true83.i.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x12, #0                         ; =0x0
	b	LBB0_52
LBB0_51:                                ; %else257
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x13, x28, x12
	stp	q22, q23, [x13]
	add	x12, x12, #32
	cmp	x12, #3072
	b.eq	LBB0_68
LBB0_52:                                ; %direct.true83.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w14, s2
	add	x13, x11, x12
	add	x15, x28, x12
	ldp	q22, q23, [x15]
	tbnz	w14, #0, LBB0_60
; %bb.53:                               ; %else236
                                        ;   in Loop: Header=BB0_52 Depth=2
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_61
LBB0_54:                                ; %else239
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w14, #2, LBB0_62
LBB0_55:                                ; %else242
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w14, #3, LBB0_63
LBB0_56:                                ; %else245
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w14, #4, LBB0_64
LBB0_57:                                ; %else248
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w14, #5, LBB0_65
LBB0_58:                                ; %else251
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbnz	w14, #6, LBB0_66
LBB0_59:                                ; %else254
                                        ;   in Loop: Header=BB0_52 Depth=2
	tbz	w14, #7, LBB0_51
	b	LBB0_67
LBB0_60:                                ; %cond.load235
                                        ;   in Loop: Header=BB0_52 Depth=2
	ld1.s	{ v22 }[0], [x13]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_54
LBB0_61:                                ; %cond.load238
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x13, #4
	ld1.s	{ v22 }[1], [x15]
	tbz	w14, #2, LBB0_55
LBB0_62:                                ; %cond.load241
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x13, #8
	ld1.s	{ v22 }[2], [x15]
	tbz	w14, #3, LBB0_56
LBB0_63:                                ; %cond.load244
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x13, #12
	ld1.s	{ v22 }[3], [x15]
	tbz	w14, #4, LBB0_57
LBB0_64:                                ; %cond.load247
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x13, #16
	ld1.s	{ v23 }[0], [x15]
	tbz	w14, #5, LBB0_58
LBB0_65:                                ; %cond.load250
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x13, #20
	ld1.s	{ v23 }[1], [x15]
	tbz	w14, #6, LBB0_59
LBB0_66:                                ; %cond.load253
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x15, x13, #24
	ld1.s	{ v23 }[2], [x15]
	tbz	w14, #7, LBB0_51
LBB0_67:                                ; %cond.load256
                                        ;   in Loop: Header=BB0_52 Depth=2
	add	x13, x13, #28
	ld1.s	{ v23 }[3], [x13]
	b	LBB0_51
LBB0_68:                                ; %direct.false84.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	xtn.8b	v22, v5
	fadd.4s	v5, v7, v20
	fadd.4s	v6, v6, v19
	fadd.4s	v6, v6, v21
	fadd.4s	v5, v5, v16
	fadd.4s	v5, v5, v18
	fadd.4s	v6, v6, v17
	and.16b	v16, v1, v3
	and.16b	v3, v0, v4
	movi.4s	v4, #1
	eor.16b	v7, v3, v4
	eor.16b	v18, v16, v4
	umov.b	w13, v22[0]
	add	x4, sp, #352
	str	q6, [x4, #192]
	ldr	s4, [x4, #196]
	umov.b	w12, v22[1]
	ands	w14, w13, #0x1
	tst	w14, w12
	mov.s	w15, v18[1]
	fcsel	s4, s4, s8, ne
	add	x16, sp, #216
	bfxil	x16, x15, #0, #3
	str	d22, [sp, #216]
	ldrb	w16, [x16]
	add	x17, sp, #512
	orr	x15, x17, x15, lsl #2
	stp	q6, q5, [x4, #160]
	ldr	s16, [x15]
	ands	w15, w12, #0x1
	tst	w15, w16
	fcsel	s16, s16, s8, ne
	mov.s	w15, v18[2]
	add	x16, sp, #216
	bfxil	x16, x15, #0, #3
	ldrb	w16, [x16]
	add	x17, sp, #480
	orr	x17, x17, x15, lsl #2
	umov.b	w15, v22[2]
	stp	q6, q5, [x4, #128]
	ldr	s17, [x17]
	ands	w17, w15, #0x1
	tst	w17, w16
	fcsel	s17, s17, s8, ne
	mov.s	w16, v18[3]
	add	x17, sp, #216
	bfxil	x17, x16, #0, #3
	ldrb	w17, [x17]
	add	x0, sp, #448
	orr	x0, x0, x16, lsl #2
	umov.b	w16, v22[3]
	stp	q6, q5, [x4, #96]
	ldr	s18, [x0]
	ands	w0, w16, #0x1
	tst	w0, w17
	fcsel	s18, s18, s8, ne
	fmov	w0, s7
	add	x17, sp, #216
	bfxil	x17, x0, #0, #3
	ldrb	w1, [x17]
	umov.b	w17, v22[4]
	and	w1, w17, w1
	stp	q6, q5, [x4, #64]
	add	x2, sp, #416
	ldr	s19, [x2, w0, uxtw #2]
	tst	w1, #0x1
	mov.s	w1, v7[1]
	fcsel	s19, s19, s8, ne
	add	x0, sp, #216
	bfxil	x0, x1, #0, #3
	ldrb	w2, [x0]
	umov.b	w0, v22[5]
	stp	q6, q5, [x4, #32]
	add	x3, sp, #384
	ldr	s20, [x3, w1, uxtw #2]
	ands	w1, w0, #0x1
	tst	w1, w2
	fcsel	s20, s20, s8, ne
	mov.s	w2, v7[2]
	add	x1, sp, #216
	bfxil	x1, x2, #0, #3
	ldrb	w3, [x1]
	umov.b	w1, v22[6]
	stp	q6, q5, [x4]
	ldr	s21, [x4, w2, uxtw #2]
	ands	w2, w1, #0x1
	tst	w2, w3
	fcsel	s21, s21, s8, ne
	mov.s	w3, v7[3]
	add	x2, sp, #216
	bfxil	x2, x3, #0, #3
	ldrb	w4, [x2]
	umov.b	w2, v22[7]
	stp	q6, q5, [sp, #320]
	add	x5, sp, #320
	ldr	s7, [x5, w3, uxtw #2]
	ands	w3, w2, #0x1
	tst	w3, w4
	mov.s	v4[1], v16[0]
	mov.s	v4[2], v17[0]
	mov.s	v4[3], v18[0]
	mov.s	v19[1], v20[0]
	fcsel	s7, s7, s8, ne
	mov.s	v19[2], v21[0]
	mov.s	v19[3], v7[0]
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v6, v4
	movi.4s	v6, #2
	eor.16b	v3, v3, v6
	str	q4, [sp, #288]
	ldr	s6, [sp, #296]
	fmov	w3, s3
	add	x4, sp, #216
	bfxil	x4, x3, #0, #3
	ldrb	w4, [x4]
	stp	q4, q5, [sp, #256]
	add	x5, sp, #256
	ldr	s3, [x5, w3, uxtw #2]
	tst	w14, w15
	fcsel	s6, s6, s8, ne
	and	w3, w17, w4
	tst	w3, #0x1
	fcsel	s3, s3, s8, ne
	fadd.4s	v3, v5, v3
	tst	w14, w17
	fcsel	s3, s3, s8, ne
	ands	w13, w13, #0x1
	fadd.4s	v4, v4, v6
	fadd	s3, s4, s3
	fcsel	s4, s3, s8, ne
	tst	w12, #0x1
	fcsel	s5, s4, s8, ne
	tst	w15, #0x1
	fcsel	s6, s4, s8, ne
	tst	w16, #0x1
	fcsel	s7, s4, s8, ne
	tst	w13, w17
	fcsel	s3, s3, s8, ne
	tst	w0, #0x1
	fcsel	s16, s4, s8, ne
	tst	w1, #0x1
	fcsel	s17, s4, s8, ne
	tst	w2, #0x1
	fcsel	s18, s4, s8, ne
	mov.s	v4[1], v5[0]
	mov.s	v4[2], v6[0]
	mov.s	v4[3], v7[0]
	mov.s	v3[1], v16[0]
	mov.s	v3[2], v17[0]
	mov.s	v3[3], v18[0]
	rbit	w10, w10
	clz	w10, w10
	stp	q4, q3, [sp, #224]
	and	x10, x10, #0x7
	add	x12, sp, #224
	ldr	s3, [x12, x10, lsl #2]
	fadd	s3, s3, s8
	mov	w10, #1145044992                ; =0x44400000
	fmov	s4, w10
	fdiv	s3, s3, s4
	mov	w10, #50604                     ; =0xc5ac
	movk	w10, #14119, lsl #16
	fmov	s4, w10
	fadd	s3, s3, s4
	fsqrt	s3, s3
	dup.4s	v3, v3[0]
	add	x8, x8, x9
	b	LBB0_70
LBB0_69:                                ; %else274
                                        ;   in Loop: Header=BB0_70 Depth=2
	add	x11, x11, #32
	cmp	x11, #3072
	b.eq	LBB0_2
LBB0_70:                                ; %direct.true103.i183.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w10, s2
	add	x9, x25, x11
	ldp	q5, q4, [x9]
	and.16b	v5, v1, v5
	fdiv.4s	v6, v5, v3
	add	x9, x28, x11
	ldp	q7, q5, [x9]
	and.16b	v7, v1, v7
	fmul.4s	v6, v6, v7
	add	x9, x8, x11
	tbnz	w10, #0, LBB0_78
; %bb.71:                               ; %else260
                                        ;   in Loop: Header=BB0_70 Depth=2
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_79
LBB0_72:                                ; %else262
                                        ;   in Loop: Header=BB0_70 Depth=2
	tbnz	w10, #2, LBB0_80
LBB0_73:                                ; %else264
                                        ;   in Loop: Header=BB0_70 Depth=2
	tbnz	w10, #3, LBB0_81
LBB0_74:                                ; %else266
                                        ;   in Loop: Header=BB0_70 Depth=2
	and.16b	v4, v0, v4
	fdiv.4s	v4, v4, v3
	and.16b	v5, v0, v5
	fmul.4s	v4, v4, v5
	tbnz	w10, #4, LBB0_82
LBB0_75:                                ; %else268
                                        ;   in Loop: Header=BB0_70 Depth=2
	tbnz	w10, #5, LBB0_83
LBB0_76:                                ; %else270
                                        ;   in Loop: Header=BB0_70 Depth=2
	tbnz	w10, #6, LBB0_84
LBB0_77:                                ; %else272
                                        ;   in Loop: Header=BB0_70 Depth=2
	tbz	w10, #7, LBB0_69
	b	LBB0_85
LBB0_78:                                ; %cond.store
                                        ;   in Loop: Header=BB0_70 Depth=2
	str	s6, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_72
LBB0_79:                                ; %cond.store261
                                        ;   in Loop: Header=BB0_70 Depth=2
	add	x12, x9, #4
	st1.s	{ v6 }[1], [x12]
	tbz	w10, #2, LBB0_73
LBB0_80:                                ; %cond.store263
                                        ;   in Loop: Header=BB0_70 Depth=2
	add	x12, x9, #8
	st1.s	{ v6 }[2], [x12]
	tbz	w10, #3, LBB0_74
LBB0_81:                                ; %cond.store265
                                        ;   in Loop: Header=BB0_70 Depth=2
	add	x12, x9, #12
	st1.s	{ v6 }[3], [x12]
	and.16b	v4, v0, v4
	fdiv.4s	v4, v4, v3
	and.16b	v5, v0, v5
	fmul.4s	v4, v4, v5
	tbz	w10, #4, LBB0_75
LBB0_82:                                ; %cond.store267
                                        ;   in Loop: Header=BB0_70 Depth=2
	str	s4, [x9, #16]
	tbz	w10, #5, LBB0_76
LBB0_83:                                ; %cond.store269
                                        ;   in Loop: Header=BB0_70 Depth=2
	add	x12, x9, #20
	st1.s	{ v4 }[1], [x12]
	tbz	w10, #6, LBB0_77
LBB0_84:                                ; %cond.store271
                                        ;   in Loop: Header=BB0_70 Depth=2
	add	x12, x9, #24
	st1.s	{ v4 }[2], [x12]
	tbz	w10, #7, LBB0_69
LBB0_85:                                ; %cond.store273
                                        ;   in Loop: Header=BB0_70 Depth=2
	add	x9, x9, #28
	st1.s	{ v4 }[3], [x9]
	b	LBB0_69
LBB0_86:                                ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Reload
	stp	w27, w7, [x9]
	str	w6, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
LBB0_87:                                ; %block.batch.exit
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2640
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #112              ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
.subsections_via_symbols

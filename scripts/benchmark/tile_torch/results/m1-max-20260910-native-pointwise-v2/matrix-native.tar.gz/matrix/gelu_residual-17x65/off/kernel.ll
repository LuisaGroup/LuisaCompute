; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot7, align 64
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat12, %41
  %44 = mul i32 %32, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat14, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat16, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 8
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state19 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state19, 8
  %.splatinsert20 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat21 = shufflevector <8 x i64> %.splatinsert20, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat21, %.spill.load
  %.spill.load22 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load22, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 65)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state23 = load i64, ptr %.slot, align 4
  %.splatinsert24 = insertelement <8 x i64> poison, i64 %.state23, i64 0
  %.splat25 = shufflevector <8 x i64> %.splatinsert24, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat25, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state26 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state26, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load27 = load <8 x i64>, ptr %.spill, align 64
  %102 = icmp slt <8 x i64> %.spill.load27, splat (i64 1)
  %103 = load <8 x i1>, ptr %.spill5, align 1
  %104 = select <8 x i1> %51, <8 x i1> %102, <8 x i1> %103
  store <8 x i1> %104, ptr %.spill5, align 1
  %105 = and <8 x i1> %51, %102
  %106 = xor <8 x i1> %102, splat (i1 true)
  %107 = and <8 x i1> %51, %106
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %109 = bitcast <8 x i1> %105 to i8
  %110 = call i8 @llvm.cttz.i8(i8 %109, i1 false)
  %111 = zext i8 %110 to i32
  %112 = select i1 %108, i32 %111, i32 0
  %.spill.load28 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> splat (i64 64), %.spill.load28
  %.spill.load29 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load29, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 65)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = select <8 x i1> %105, <8 x i64> %118, <8 x i64> zeroinitializer
  %121 = extractelement <8 x i64> %120, i32 %112
  %122 = zext i32 %112 to i64
  %123 = sub i64 %121, %122
  %124 = mul i64 %123, 4
  %buffer.contiguous.address30 = getelementptr i8, ptr %119, i64 %124
  %buffer.contiguous.load31 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address30, <8 x i1> %105, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load32 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load32, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load32, 1
  %127 = add <8 x i64> %126, splat (i64 256)
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %132 = extractelement <8 x ptr> %130, i32 0
  %133 = extractelement <8 x i64> %131, i32 %112
  %134 = zext i32 %112 to i64
  %135 = mul i64 %134, 4
  %136 = sub i64 %133, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %138 = select i1 %137, i64 %136, i64 0
  %private.contiguous.address33 = getelementptr i8, ptr %132, i64 %138
  %private.contiguous.preserve34 = load <8 x float>, ptr %private.contiguous.address33, align 4
  %139 = select <8 x i1> %105, <8 x float> %buffer.contiguous.load31, <8 x float> %private.contiguous.preserve34
  store <8 x float> %139, ptr %private.contiguous.address33, align 4
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %107)
  %141 = bitcast <8 x i1> %107 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  %145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 0
  %148 = select <8 x i1> %51, <8 x ptr> %146, <8 x ptr> %147
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %151 = select <8 x i1> %51, <8 x i64> %149, <8 x i64> %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  store { <8 x ptr>, <8 x i64> } %153, ptr %tile_snapshot.spill6, align 64
  %154 = load <8 x i64>, ptr %.slot7, align 64
  %155 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %154
  store <8 x i64> %155, ptr %.slot7, align 64
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state35 = load <8 x i64>, ptr %.slot7, align 64
  %156 = icmp slt <8 x i64> %.state35, splat (i64 8)
  %157 = extractelement <8 x i1> %156, i32 0
  br i1 %157, label %direct.true36, label %direct.false37

direct.schedule.7:                                ; preds = %direct.true36
  %.state38 = load <8 x i64>, ptr %.slot7, align 64
  %158 = mul <8 x i64> %.state38, splat (i64 8)
  %.spill.load39 = load <8 x i64>, ptr %.spill, align 64
  %159 = add <8 x i64> %158, %.spill.load39
  %.spill.load40 = load <8 x i64>, ptr %.spill4, align 64
  %160 = add <8 x i64> %.spill.load40, zeroinitializer
  %161 = add <8 x i64> zeroinitializer, %160
  %162 = add <8 x i64> zeroinitializer, %159
  %163 = mul <8 x i64> %161, splat (i64 65)
  %164 = add <8 x i64> %163, %162
  %165 = extractvalue { ptr, i64 } %15, 0
  %166 = extractelement <8 x i64> %164, i32 0
  %167 = sub i64 %166, 0
  %168 = mul i64 %167, 4
  %buffer.contiguous.address41 = getelementptr i8, ptr %165, i64 %168
  %buffer.contiguous.load42 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address41, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load43 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 0
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 1
  %.state44 = load <8 x i64>, ptr %.slot7, align 64
  %171 = mul <8 x i64> %.state44, splat (i64 32)
  %172 = add <8 x i64> %170, %171
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %169, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %177 = extractelement <8 x ptr> %175, i32 0
  %178 = extractelement <8 x i64> %176, i32 0
  %179 = sub i64 %178, 0
  %180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %181 = select i1 %180, i64 %179, i64 0
  %private.contiguous.address45 = getelementptr i8, ptr %177, i64 %181
  %private.contiguous.preserve46 = load <8 x float>, ptr %private.contiguous.address45, align 4
  %182 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load42, <8 x float> %private.contiguous.preserve46
  store <8 x float> %182, ptr %private.contiguous.address45, align 4
  %.state47 = load <8 x i64>, ptr %.slot7, align 64
  %183 = add <8 x i64> %.state47, splat (i64 1)
  %184 = load <8 x i64>, ptr %.slot7, align 64
  %185 = select <8 x i1> %51, <8 x i64> %183, <8 x i64> %184
  store <8 x i64> %185, ptr %.slot7, align 64
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false37
  %.spill.load48 = load <8 x i1>, ptr %.spill5, align 1
  %186 = and <8 x i1> %51, %.spill.load48
  %187 = xor <8 x i1> %.spill.load48, splat (i1 true)
  %188 = and <8 x i1> %51, %187
  %189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %186)
  %190 = bitcast <8 x i1> %186 to i8
  %191 = call i8 @llvm.cttz.i8(i8 %190, i1 false)
  %192 = zext i8 %191 to i32
  %193 = select i1 %189, i32 %192, i32 0
  %.spill.load49 = load <8 x i64>, ptr %.spill, align 64
  %194 = add <8 x i64> splat (i64 64), %.spill.load49
  %.spill.load50 = load <8 x i64>, ptr %.spill4, align 64
  %195 = add <8 x i64> %.spill.load50, zeroinitializer
  %196 = add <8 x i64> zeroinitializer, %195
  %197 = add <8 x i64> zeroinitializer, %194
  %198 = mul <8 x i64> %196, splat (i64 65)
  %199 = add <8 x i64> %198, %197
  %200 = extractvalue { ptr, i64 } %15, 0
  %201 = select <8 x i1> %186, <8 x i64> %199, <8 x i64> zeroinitializer
  %202 = extractelement <8 x i64> %201, i32 %193
  %203 = zext i32 %193 to i64
  %204 = sub i64 %202, %203
  %205 = mul i64 %204, 4
  %buffer.contiguous.address51 = getelementptr i8, ptr %200, i64 %205
  %buffer.contiguous.load52 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address51, <8 x i1> %186, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %208 = add <8 x i64> %207, splat (i64 256)
  %209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %206, 0
  %210 = insertvalue { <8 x ptr>, <8 x i64> } %209, <8 x i64> %208, 1
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %210, 1
  %213 = extractelement <8 x ptr> %211, i32 0
  %214 = extractelement <8 x i64> %212, i32 %193
  %215 = zext i32 %193 to i64
  %216 = mul i64 %215, 4
  %217 = sub i64 %214, %216
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %186)
  %219 = select i1 %218, i64 %217, i64 0
  %private.contiguous.address54 = getelementptr i8, ptr %213, i64 %219
  %private.contiguous.preserve55 = load <8 x float>, ptr %private.contiguous.address54, align 4
  %220 = select <8 x i1> %186, <8 x float> %buffer.contiguous.load52, <8 x float> %private.contiguous.preserve55
  store <8 x float> %220, ptr %private.contiguous.address54, align 4
  %221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %188)
  %222 = bitcast <8 x i1> %188 to i8
  %223 = call i8 @llvm.cttz.i8(i8 %222, i1 false)
  %224 = zext i8 %223 to i32
  %225 = select i1 %221, i32 %224, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %226 = load <8 x i64>, ptr %.slot8, align 64
  %227 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %226
  store <8 x i64> %227, ptr %.slot8, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state56 = load <8 x i64>, ptr %.slot8, align 64
  %228 = icmp slt <8 x i64> %.state56, splat (i64 8)
  %229 = extractelement <8 x i1> %228, i32 0
  br i1 %229, label %direct.true57, label %direct.false58

direct.schedule.12:                               ; preds = %direct.true57
  %.state59 = load <8 x i64>, ptr %.slot8, align 64
  %230 = mul <8 x i64> %.state59, splat (i64 8)
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %231 = add <8 x i64> %230, %.spill.load60
  %.spill.load61 = load <8 x i64>, ptr %.spill4, align 64
  %232 = add <8 x i64> %.spill.load61, zeroinitializer
  %233 = add <8 x i64> zeroinitializer, %232
  %234 = add <8 x i64> zeroinitializer, %231
  %235 = mul <8 x i64> %233, splat (i64 65)
  %236 = add <8 x i64> %235, %234
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %.state63 = load <8 x i64>, ptr %.slot8, align 64
  %239 = mul <8 x i64> %.state63, splat (i64 32)
  %240 = add <8 x i64> %238, %239
  %241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %237, 0
  %242 = insertvalue { <8 x ptr>, <8 x i64> } %241, <8 x i64> %240, 1
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %245 = extractelement <8 x ptr> %243, i32 0
  %246 = extractelement <8 x i64> %244, i32 0
  %247 = sub i64 %246, 0
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %249 = select i1 %248, i64 %247, i64 0
  %private.contiguous.address64 = getelementptr i8, ptr %245, i64 %249
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address64, align 4
  %250 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %251 = fmul <8 x float> splat (float 5.000000e-01), %250
  %252 = fmul <8 x float> splat (float 0x3FA6E4E260000000), %250
  %253 = fmul <8 x float> %252, %250
  %254 = fmul <8 x float> %253, %250
  %255 = fadd <8 x float> %250, %254
  %256 = fmul <8 x float> splat (float 0x3FE9884540000000), %255
  %257 = select <8 x i1> %51, <8 x float> %256, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %257)
  %258 = fadd <8 x float> splat (float 1.000000e+00), %native.tanh
  %259 = fmul <8 x float> %251, %258
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %.state66 = load <8 x i64>, ptr %.slot8, align 64
  %262 = mul <8 x i64> %.state66, splat (i64 32)
  %263 = add <8 x i64> %261, %262
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %260, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = extractelement <8 x ptr> %266, i32 0
  %269 = extractelement <8 x i64> %267, i32 0
  %270 = sub i64 %269, 0
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %272 = select i1 %271, i64 %270, i64 0
  %private.contiguous.address67 = getelementptr i8, ptr %268, i64 %272
  %private.contiguous.load68 = load <8 x float>, ptr %private.contiguous.address67, align 4
  %273 = select <8 x i1> %51, <8 x float> %private.contiguous.load68, <8 x float> zeroinitializer
  %274 = fadd <8 x float> %259, %273
  %275 = extractvalue { ptr, i64 } %27, 0
  %276 = extractelement <8 x i64> %236, i32 0
  %277 = sub i64 %276, 0
  %278 = mul i64 %277, 4
  %buffer.contiguous.address69 = getelementptr i8, ptr %275, i64 %278
  call void @llvm.masked.store.v8f32.p0(<8 x float> %274, ptr align 1 %buffer.contiguous.address69, <8 x i1> %51)
  %.state70 = load <8 x i64>, ptr %.slot8, align 64
  %279 = add <8 x i64> %.state70, splat (i64 1)
  %280 = load <8 x i64>, ptr %.slot8, align 64
  %281 = select <8 x i1> %51, <8 x i64> %279, <8 x i64> %280
  store <8 x i64> %281, ptr %.slot8, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false58
  %.spill.load71 = load <8 x i1>, ptr %.spill5, align 1
  %282 = and <8 x i1> %51, %.spill.load71
  %283 = xor <8 x i1> %.spill.load71, splat (i1 true)
  %284 = and <8 x i1> %51, %283
  %285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %282)
  %286 = bitcast <8 x i1> %282 to i8
  %287 = call i8 @llvm.cttz.i8(i8 %286, i1 false)
  %288 = zext i8 %287 to i32
  %289 = select i1 %285, i32 %288, i32 0
  %.spill.load72 = load <8 x i64>, ptr %.spill, align 64
  %290 = add <8 x i64> splat (i64 64), %.spill.load72
  %.spill.load73 = load <8 x i64>, ptr %.spill4, align 64
  %291 = add <8 x i64> %.spill.load73, zeroinitializer
  %292 = add <8 x i64> zeroinitializer, %291
  %293 = add <8 x i64> zeroinitializer, %290
  %294 = mul <8 x i64> %292, splat (i64 65)
  %295 = add <8 x i64> %294, %293
  %tile_snapshot.spill.load74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 1
  %298 = add <8 x i64> %297, splat (i64 256)
  %299 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %296, 0
  %300 = insertvalue { <8 x ptr>, <8 x i64> } %299, <8 x i64> %298, 1
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %300, 1
  %303 = extractelement <8 x ptr> %301, i32 0
  %304 = extractelement <8 x i64> %302, i32 %289
  %305 = zext i32 %289 to i64
  %306 = mul i64 %305, 4
  %307 = sub i64 %304, %306
  %308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %282)
  %309 = select i1 %308, i64 %307, i64 0
  %private.contiguous.address75 = getelementptr i8, ptr %303, i64 %309
  %private.contiguous.load76 = load <8 x float>, ptr %private.contiguous.address75, align 4
  %310 = select <8 x i1> %282, <8 x float> %private.contiguous.load76, <8 x float> zeroinitializer
  %311 = fmul <8 x float> splat (float 5.000000e-01), %310
  %312 = fmul <8 x float> splat (float 0x3FA6E4E260000000), %310
  %313 = fmul <8 x float> %312, %310
  %314 = fmul <8 x float> %313, %310
  %315 = fadd <8 x float> %310, %314
  %316 = fmul <8 x float> splat (float 0x3FE9884540000000), %315
  %317 = select <8 x i1> %282, <8 x float> %316, <8 x float> zeroinitializer
  %native.tanh77 = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %317)
  %318 = fadd <8 x float> splat (float 1.000000e+00), %native.tanh77
  %319 = fmul <8 x float> %311, %318
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %322 = add <8 x i64> %321, splat (i64 256)
  %323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %320, 0
  %324 = insertvalue { <8 x ptr>, <8 x i64> } %323, <8 x i64> %322, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %324, 1
  %327 = extractelement <8 x ptr> %325, i32 0
  %328 = extractelement <8 x i64> %326, i32 %289
  %329 = zext i32 %289 to i64
  %330 = mul i64 %329, 4
  %331 = sub i64 %328, %330
  %332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %282)
  %333 = select i1 %332, i64 %331, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %327, i64 %333
  %private.contiguous.load80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %334 = select <8 x i1> %282, <8 x float> %private.contiguous.load80, <8 x float> zeroinitializer
  %335 = fadd <8 x float> %319, %334
  %336 = extractvalue { ptr, i64 } %27, 0
  %337 = extractelement <8 x i64> %295, i32 %289
  %338 = zext i32 %289 to i64
  %339 = sub i64 %337, %338
  %340 = mul i64 %339, 4
  %buffer.contiguous.address81 = getelementptr i8, ptr %336, i64 %340
  call void @llvm.masked.store.v8f32.p0(<8 x float> %335, ptr align 1 %buffer.contiguous.address81, <8 x i1> %282)
  %341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %284)
  %342 = bitcast <8 x i1> %284 to i8
  %343 = call i8 @llvm.cttz.i8(i8 %342, i1 false)
  %344 = zext i8 %343 to i32
  %345 = select i1 %341, i32 %344, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true36:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false37:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true57:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false58:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %x) #2 {
entry:
  %0 = bitcast <8 x float> %x to <8 x i32>
  %1 = and <8 x i32> %0, splat (i32 2147483647)
  %2 = bitcast <8 x i32> %1 to <8 x float>
  %3 = fcmp contract ole <8 x float> %2, splat (float 1.000000e+00)
  %4 = fmul contract <8 x float> %2, %2
  %5 = fmul contract <8 x float> splat (float 0x3DE6124620000000), %4
  %6 = fadd contract <8 x float> %5, splat (float 0x3E5AE64560000000)
  %7 = fmul contract <8 x float> %6, %4
  %8 = fadd contract <8 x float> %7, splat (float 0x3EC71DE3A0000000)
  %9 = fmul contract <8 x float> %8, %4
  %10 = fadd contract <8 x float> %9, splat (float 0x3F2A01A020000000)
  %11 = fmul contract <8 x float> %10, %4
  %12 = fadd contract <8 x float> %11, splat (float 0x3F81111120000000)
  %13 = fmul contract <8 x float> %12, %4
  %14 = fadd contract <8 x float> %13, splat (float 0x3FC5555560000000)
  %15 = fmul contract <8 x float> %14, %4
  %16 = fadd contract <8 x float> %15, splat (float 1.000000e+00)
  %17 = fmul contract <8 x float> %2, %16
  %18 = fmul contract <8 x float> %2, %2
  %19 = fmul contract <8 x float> splat (float 0x3E21EED8E0000000), %18
  %20 = fadd contract <8 x float> %19, splat (float 0x3E927E4FC0000000)
  %21 = fmul contract <8 x float> %20, %18
  %22 = fadd contract <8 x float> %21, splat (float 0x3EFA01A020000000)
  %23 = fmul contract <8 x float> %22, %18
  %24 = fadd contract <8 x float> %23, splat (float 0x3F56C16C20000000)
  %25 = fmul contract <8 x float> %24, %18
  %26 = fadd contract <8 x float> %25, splat (float 0x3FA5555560000000)
  %27 = fmul contract <8 x float> %26, %18
  %28 = fadd contract <8 x float> %27, splat (float 5.000000e-01)
  %29 = fmul contract <8 x float> %28, %18
  %30 = fadd contract <8 x float> %29, splat (float 1.000000e+00)
  %31 = fdiv contract <8 x float> %17, %30
  %32 = fcmp contract ole <8 x float> %2, splat (float 9.000000e+00)
  %33 = select contract <8 x i1> %32, <8 x float> %2, <8 x float> zeroinitializer
  %exp.half = call contract <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %33)
  %34 = fdiv contract <8 x float> splat (float 2.500000e-01), %exp.half
  %35 = fsub contract <8 x float> %exp.half, %34
  %36 = fadd contract <8 x float> %exp.half, %34
  %37 = fdiv contract <8 x float> %35, %36
  %38 = select contract <8 x i1> %32, <8 x float> %37, <8 x float> splat (float 1.000000e+00)
  %39 = select contract <8 x i1> %3, <8 x float> %31, <8 x float> %38
  %40 = bitcast <8 x float> %39 to <8 x i32>
  %41 = and <8 x i32> %40, splat (i32 2147483647)
  %42 = bitcast <8 x float> %x to <8 x i32>
  %43 = and <8 x i32> %42, splat (i32 -2147483648)
  %44 = or <8 x i32> %41, %43
  %45 = bitcast <8 x i32> %44 to <8 x float>
  %46 = fcmp contract uno <8 x float> %x, %x
  %47 = select contract <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %x) #2 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = sub <8 x i32> %11, splat (i32 1)
  %32 = ashr <8 x i32> %31, splat (i32 1)
  %33 = add <8 x i32> %32, splat (i32 127)
  %34 = shl <8 x i32> %33, splat (i32 23)
  %35 = bitcast <8 x i32> %34 to <8 x float>
  %36 = fmul <8 x float> %30, %35
  %37 = sub <8 x i32> %31, %32
  %38 = add <8 x i32> %37, splat (i32 127)
  %39 = shl <8 x i32> %38, splat (i32 23)
  %40 = bitcast <8 x i32> %39 to <8 x float>
  %41 = fmul <8 x float> %36, %40
  %42 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %43 = select <8 x i1> %42, <8 x float> zeroinitializer, <8 x float> %41
  %44 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %45 = select <8 x i1> %44, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %43
  %46 = fcmp uno <8 x float> %x, %x
  %47 = select <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #3

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot7, align 64
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat12, %41
  %44 = mul i32 %32, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat14, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat16, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 8
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state19 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state19, 8
  %.splatinsert20 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat21 = shufflevector <8 x i64> %.splatinsert20, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat21, %.spill.load
  %.spill.load22 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load22, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 65)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state23 = load i64, ptr %.slot, align 4
  %.splatinsert24 = insertelement <8 x i64> poison, i64 %.state23, i64 0
  %.splat25 = shufflevector <8 x i64> %.splatinsert24, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat25, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state26 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state26, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load27 = load <8 x i64>, ptr %.spill, align 64
  %102 = icmp slt <8 x i64> %.spill.load27, splat (i64 1)
  %103 = load <8 x i1>, ptr %.spill5, align 1
  %104 = select <8 x i1> %51, <8 x i1> %102, <8 x i1> %103
  store <8 x i1> %104, ptr %.spill5, align 1
  %105 = and <8 x i1> %51, %102
  %106 = xor <8 x i1> %102, splat (i1 true)
  %107 = and <8 x i1> %51, %106
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %109 = bitcast <8 x i1> %105 to i8
  %110 = call i8 @llvm.cttz.i8(i8 %109, i1 false)
  %111 = zext i8 %110 to i32
  %112 = select i1 %108, i32 %111, i32 0
  %.spill.load28 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> splat (i64 64), %.spill.load28
  %.spill.load29 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load29, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 65)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = select <8 x i1> %105, <8 x i64> %118, <8 x i64> zeroinitializer
  %121 = extractelement <8 x i64> %120, i32 %112
  %122 = zext i32 %112 to i64
  %123 = sub i64 %121, %122
  %124 = mul i64 %123, 4
  %buffer.contiguous.address30 = getelementptr i8, ptr %119, i64 %124
  %buffer.contiguous.load31 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address30, <8 x i1> %105, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load32 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load32, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load32, 1
  %127 = add <8 x i64> %126, splat (i64 256)
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %132 = extractelement <8 x ptr> %130, i32 0
  %133 = extractelement <8 x i64> %131, i32 %112
  %134 = zext i32 %112 to i64
  %135 = mul i64 %134, 4
  %136 = sub i64 %133, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %138 = select i1 %137, i64 %136, i64 0
  %private.contiguous.address33 = getelementptr i8, ptr %132, i64 %138
  %private.contiguous.preserve34 = load <8 x float>, ptr %private.contiguous.address33, align 4
  %139 = select <8 x i1> %105, <8 x float> %buffer.contiguous.load31, <8 x float> %private.contiguous.preserve34
  store <8 x float> %139, ptr %private.contiguous.address33, align 4
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %107)
  %141 = bitcast <8 x i1> %107 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  %145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 0
  %148 = select <8 x i1> %51, <8 x ptr> %146, <8 x ptr> %147
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %151 = select <8 x i1> %51, <8 x i64> %149, <8 x i64> %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  store { <8 x ptr>, <8 x i64> } %153, ptr %tile_snapshot.spill6, align 64
  %154 = load <8 x i64>, ptr %.slot7, align 64
  %155 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %154
  store <8 x i64> %155, ptr %.slot7, align 64
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state35 = load <8 x i64>, ptr %.slot7, align 64
  %156 = icmp slt <8 x i64> %.state35, splat (i64 8)
  %157 = extractelement <8 x i1> %156, i32 0
  br i1 %157, label %direct.true36, label %direct.false37

direct.schedule.7:                                ; preds = %direct.true36
  %.state38 = load <8 x i64>, ptr %.slot7, align 64
  %158 = mul <8 x i64> %.state38, splat (i64 8)
  %.spill.load39 = load <8 x i64>, ptr %.spill, align 64
  %159 = add <8 x i64> %158, %.spill.load39
  %.spill.load40 = load <8 x i64>, ptr %.spill4, align 64
  %160 = add <8 x i64> %.spill.load40, zeroinitializer
  %161 = add <8 x i64> zeroinitializer, %160
  %162 = add <8 x i64> zeroinitializer, %159
  %163 = mul <8 x i64> %161, splat (i64 65)
  %164 = add <8 x i64> %163, %162
  %165 = extractvalue { ptr, i64 } %15, 0
  %166 = extractelement <8 x i64> %164, i32 0
  %167 = sub i64 %166, 0
  %168 = mul i64 %167, 4
  %buffer.contiguous.address41 = getelementptr i8, ptr %165, i64 %168
  %buffer.contiguous.load42 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address41, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load43 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 0
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 1
  %.state44 = load <8 x i64>, ptr %.slot7, align 64
  %171 = mul <8 x i64> %.state44, splat (i64 32)
  %172 = add <8 x i64> %170, %171
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %169, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %177 = extractelement <8 x ptr> %175, i32 0
  %178 = extractelement <8 x i64> %176, i32 0
  %179 = sub i64 %178, 0
  %180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %181 = select i1 %180, i64 %179, i64 0
  %private.contiguous.address45 = getelementptr i8, ptr %177, i64 %181
  %private.contiguous.preserve46 = load <8 x float>, ptr %private.contiguous.address45, align 4
  %182 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load42, <8 x float> %private.contiguous.preserve46
  store <8 x float> %182, ptr %private.contiguous.address45, align 4
  %.state47 = load <8 x i64>, ptr %.slot7, align 64
  %183 = add <8 x i64> %.state47, splat (i64 1)
  %184 = load <8 x i64>, ptr %.slot7, align 64
  %185 = select <8 x i1> %51, <8 x i64> %183, <8 x i64> %184
  store <8 x i64> %185, ptr %.slot7, align 64
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false37
  %.spill.load48 = load <8 x i1>, ptr %.spill5, align 1
  %186 = and <8 x i1> %51, %.spill.load48
  %187 = xor <8 x i1> %.spill.load48, splat (i1 true)
  %188 = and <8 x i1> %51, %187
  %189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %186)
  %190 = bitcast <8 x i1> %186 to i8
  %191 = call i8 @llvm.cttz.i8(i8 %190, i1 false)
  %192 = zext i8 %191 to i32
  %193 = select i1 %189, i32 %192, i32 0
  %.spill.load49 = load <8 x i64>, ptr %.spill, align 64
  %194 = add <8 x i64> splat (i64 64), %.spill.load49
  %.spill.load50 = load <8 x i64>, ptr %.spill4, align 64
  %195 = add <8 x i64> %.spill.load50, zeroinitializer
  %196 = add <8 x i64> zeroinitializer, %195
  %197 = add <8 x i64> zeroinitializer, %194
  %198 = mul <8 x i64> %196, splat (i64 65)
  %199 = add <8 x i64> %198, %197
  %200 = extractvalue { ptr, i64 } %15, 0
  %201 = select <8 x i1> %186, <8 x i64> %199, <8 x i64> zeroinitializer
  %202 = extractelement <8 x i64> %201, i32 %193
  %203 = zext i32 %193 to i64
  %204 = sub i64 %202, %203
  %205 = mul i64 %204, 4
  %buffer.contiguous.address51 = getelementptr i8, ptr %200, i64 %205
  %buffer.contiguous.load52 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address51, <8 x i1> %186, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %208 = add <8 x i64> %207, splat (i64 256)
  %209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %206, 0
  %210 = insertvalue { <8 x ptr>, <8 x i64> } %209, <8 x i64> %208, 1
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %210, 1
  %213 = extractelement <8 x ptr> %211, i32 0
  %214 = extractelement <8 x i64> %212, i32 %193
  %215 = zext i32 %193 to i64
  %216 = mul i64 %215, 4
  %217 = sub i64 %214, %216
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %186)
  %219 = select i1 %218, i64 %217, i64 0
  %private.contiguous.address54 = getelementptr i8, ptr %213, i64 %219
  %private.contiguous.preserve55 = load <8 x float>, ptr %private.contiguous.address54, align 4
  %220 = select <8 x i1> %186, <8 x float> %buffer.contiguous.load52, <8 x float> %private.contiguous.preserve55
  store <8 x float> %220, ptr %private.contiguous.address54, align 4
  %221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %188)
  %222 = bitcast <8 x i1> %188 to i8
  %223 = call i8 @llvm.cttz.i8(i8 %222, i1 false)
  %224 = zext i8 %223 to i32
  %225 = select i1 %221, i32 %224, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %226 = load <8 x i64>, ptr %.slot8, align 64
  %227 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %226
  store <8 x i64> %227, ptr %.slot8, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state56 = load <8 x i64>, ptr %.slot8, align 64
  %228 = icmp slt <8 x i64> %.state56, splat (i64 8)
  %229 = extractelement <8 x i1> %228, i32 0
  br i1 %229, label %direct.true57, label %direct.false58

direct.schedule.12:                               ; preds = %direct.true57
  %.state59 = load <8 x i64>, ptr %.slot8, align 64
  %230 = mul <8 x i64> %.state59, splat (i64 8)
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %231 = add <8 x i64> %230, %.spill.load60
  %.spill.load61 = load <8 x i64>, ptr %.spill4, align 64
  %232 = add <8 x i64> %.spill.load61, zeroinitializer
  %233 = add <8 x i64> zeroinitializer, %232
  %234 = add <8 x i64> zeroinitializer, %231
  %235 = mul <8 x i64> %233, splat (i64 65)
  %236 = add <8 x i64> %235, %234
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %.state63 = load <8 x i64>, ptr %.slot8, align 64
  %239 = mul <8 x i64> %.state63, splat (i64 32)
  %240 = add <8 x i64> %238, %239
  %241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %237, 0
  %242 = insertvalue { <8 x ptr>, <8 x i64> } %241, <8 x i64> %240, 1
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %245 = extractelement <8 x ptr> %243, i32 0
  %246 = extractelement <8 x i64> %244, i32 0
  %247 = sub i64 %246, 0
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %249 = select i1 %248, i64 %247, i64 0
  %private.contiguous.address64 = getelementptr i8, ptr %245, i64 %249
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address64, align 4
  %250 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %251 = fmul <8 x float> splat (float 5.000000e-01), %250
  %252 = fmul <8 x float> splat (float 0x3FA6E4E260000000), %250
  %253 = fmul <8 x float> %252, %250
  %254 = fmul <8 x float> %253, %250
  %255 = fadd <8 x float> %250, %254
  %256 = fmul <8 x float> splat (float 0x3FE9884540000000), %255
  %257 = select <8 x i1> %51, <8 x float> %256, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %257)
  %258 = fadd <8 x float> splat (float 1.000000e+00), %native.tanh
  %259 = fmul <8 x float> %251, %258
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %.state66 = load <8 x i64>, ptr %.slot8, align 64
  %262 = mul <8 x i64> %.state66, splat (i64 32)
  %263 = add <8 x i64> %261, %262
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %260, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = extractelement <8 x ptr> %266, i32 0
  %269 = extractelement <8 x i64> %267, i32 0
  %270 = sub i64 %269, 0
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %272 = select i1 %271, i64 %270, i64 0
  %private.contiguous.address67 = getelementptr i8, ptr %268, i64 %272
  %private.contiguous.load68 = load <8 x float>, ptr %private.contiguous.address67, align 4
  %273 = select <8 x i1> %51, <8 x float> %private.contiguous.load68, <8 x float> zeroinitializer
  %274 = fadd <8 x float> %259, %273
  %275 = extractvalue { ptr, i64 } %27, 0
  %276 = extractelement <8 x i64> %236, i32 0
  %277 = sub i64 %276, 0
  %278 = mul i64 %277, 4
  %buffer.contiguous.address69 = getelementptr i8, ptr %275, i64 %278
  call void @llvm.masked.store.v8f32.p0(<8 x float> %274, ptr align 1 %buffer.contiguous.address69, <8 x i1> %51)
  %.state70 = load <8 x i64>, ptr %.slot8, align 64
  %279 = add <8 x i64> %.state70, splat (i64 1)
  %280 = load <8 x i64>, ptr %.slot8, align 64
  %281 = select <8 x i1> %51, <8 x i64> %279, <8 x i64> %280
  store <8 x i64> %281, ptr %.slot8, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false58
  %.spill.load71 = load <8 x i1>, ptr %.spill5, align 1
  %282 = and <8 x i1> %51, %.spill.load71
  %283 = xor <8 x i1> %.spill.load71, splat (i1 true)
  %284 = and <8 x i1> %51, %283
  %285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %282)
  %286 = bitcast <8 x i1> %282 to i8
  %287 = call i8 @llvm.cttz.i8(i8 %286, i1 false)
  %288 = zext i8 %287 to i32
  %289 = select i1 %285, i32 %288, i32 0
  %.spill.load72 = load <8 x i64>, ptr %.spill, align 64
  %290 = add <8 x i64> splat (i64 64), %.spill.load72
  %.spill.load73 = load <8 x i64>, ptr %.spill4, align 64
  %291 = add <8 x i64> %.spill.load73, zeroinitializer
  %292 = add <8 x i64> zeroinitializer, %291
  %293 = add <8 x i64> zeroinitializer, %290
  %294 = mul <8 x i64> %292, splat (i64 65)
  %295 = add <8 x i64> %294, %293
  %tile_snapshot.spill.load74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 1
  %298 = add <8 x i64> %297, splat (i64 256)
  %299 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %296, 0
  %300 = insertvalue { <8 x ptr>, <8 x i64> } %299, <8 x i64> %298, 1
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %300, 1
  %303 = extractelement <8 x ptr> %301, i32 0
  %304 = extractelement <8 x i64> %302, i32 %289
  %305 = zext i32 %289 to i64
  %306 = mul i64 %305, 4
  %307 = sub i64 %304, %306
  %308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %282)
  %309 = select i1 %308, i64 %307, i64 0
  %private.contiguous.address75 = getelementptr i8, ptr %303, i64 %309
  %private.contiguous.load76 = load <8 x float>, ptr %private.contiguous.address75, align 4
  %310 = select <8 x i1> %282, <8 x float> %private.contiguous.load76, <8 x float> zeroinitializer
  %311 = fmul <8 x float> splat (float 5.000000e-01), %310
  %312 = fmul <8 x float> splat (float 0x3FA6E4E260000000), %310
  %313 = fmul <8 x float> %312, %310
  %314 = fmul <8 x float> %313, %310
  %315 = fadd <8 x float> %310, %314
  %316 = fmul <8 x float> splat (float 0x3FE9884540000000), %315
  %317 = select <8 x i1> %282, <8 x float> %316, <8 x float> zeroinitializer
  %native.tanh77 = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %317)
  %318 = fadd <8 x float> splat (float 1.000000e+00), %native.tanh77
  %319 = fmul <8 x float> %311, %318
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %322 = add <8 x i64> %321, splat (i64 256)
  %323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %320, 0
  %324 = insertvalue { <8 x ptr>, <8 x i64> } %323, <8 x i64> %322, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %324, 1
  %327 = extractelement <8 x ptr> %325, i32 0
  %328 = extractelement <8 x i64> %326, i32 %289
  %329 = zext i32 %289 to i64
  %330 = mul i64 %329, 4
  %331 = sub i64 %328, %330
  %332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %282)
  %333 = select i1 %332, i64 %331, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %327, i64 %333
  %private.contiguous.load80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %334 = select <8 x i1> %282, <8 x float> %private.contiguous.load80, <8 x float> zeroinitializer
  %335 = fadd <8 x float> %319, %334
  %336 = extractvalue { ptr, i64 } %27, 0
  %337 = extractelement <8 x i64> %295, i32 %289
  %338 = zext i32 %289 to i64
  %339 = sub i64 %337, %338
  %340 = mul i64 %339, 4
  %buffer.contiguous.address81 = getelementptr i8, ptr %336, i64 %340
  call void @llvm.masked.store.v8f32.p0(<8 x float> %335, ptr align 1 %buffer.contiguous.address81, <8 x i1> %282)
  %341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %284)
  %342 = bitcast <8 x i1> %284 to i8
  %343 = call i8 @llvm.cttz.i8(i8 %342, i1 false)
  %344 = zext i8 %343 to i32
  %345 = select i1 %341, i32 %344, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true36:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false37:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true57:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false58:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

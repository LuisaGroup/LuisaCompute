	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #864
	ldr	x12, [x0]
	ldr	x10, [x0, #16]
	ldr	x8, [x0, #48]
	ldr	w9, [x1]
	ldr	w11, [x1, #36]
	add	w9, w11, w9, lsl #5
	lsr	w9, w9, #3
	dup.2s	v0, w9
	ushll.2d	v0, v0, #0
	subs	x9, x12, x8
	cset	w11, hs
	lsr	x9, x9, #2
	cmp	x9, #1104
	csel	w9, wzr, w11, ls
	subs	x11, x8, x12
	cset	w13, hs
	lsr	x11, x11, #2
	cmp	x11, #1104
	csel	w11, wzr, w13, ls
	orr	w11, w9, w11
	subs	x9, x10, x8
	cset	w13, hs
	lsr	x9, x9, #2
	cmp	x9, #1104
	csel	w9, wzr, w13, ls
	subs	x13, x8, x10
	cset	w14, hs
	lsr	x13, x13, #2
	cmp	x13, #1104
	csel	w13, wzr, w14, ls
	orr	w13, w9, w13
	fmov	x9, d0
	add	x9, x9, x9, lsl #6
	lsl	x9, x9, #2
	cmp	w11, #1
	mov	x11, #0                         ; =0x0
	ccmp	w13, #0, #4, eq
	b.ne	LBB0_4
; %bb.1:                                ; %direct.schedule.8.preheader
	add	x9, x12, x9
	ldp	q1, q2, [x9, #192]
	stp	q1, q2, [sp, #768]
	ldp	q1, q2, [x9, #224]
	stp	q1, q2, [sp, #800]
	ldp	q1, q2, [x9, #128]
	stp	q1, q2, [sp, #704]
	ldp	q1, q2, [x9, #160]
	stp	q1, q2, [sp, #736]
	ldp	q1, q2, [x9, #64]
	stp	q1, q2, [sp, #640]
	ldp	q1, q2, [x9, #96]
	stp	q1, q2, [sp, #672]
	ldp	q1, q2, [x9]
	stp	q1, q2, [sp, #576]
	ldp	q1, q2, [x9, #32]
	stp	q1, q2, [sp, #608]
	fmov	x9, d0
	add	x9, x9, x9, lsl #6
	lsl	x13, x9, #2
	add	x9, x13, #256
	ldr	s5, [x12, x9]
	add	x12, x10, x13
	ldp	q0, q1, [x12, #192]
	stp	q0, q1, [sp, #480]
	ldp	q0, q1, [x12, #224]
	stp	q0, q1, [sp, #512]
	ldp	q0, q1, [x12, #128]
	stp	q0, q1, [sp, #416]
	ldp	q0, q1, [x12, #160]
	stp	q0, q1, [sp, #448]
	ldp	q0, q1, [x12, #64]
	stp	q0, q1, [sp, #352]
	ldp	q0, q1, [x12, #96]
	stp	q0, q1, [sp, #384]
	ldp	q2, q3, [x12]
	ldp	q0, q1, [x12, #32]
	ldr	s4, [x10, x9]
	add	x10, x8, x13
	add	x12, sp, #576
	mov	w13, #10003                     ; =0x2713
	movk	w13, #15671, lsl #16
	dup.4s	v7, w13
	mov	w13, #16938                     ; =0x422a
	movk	w13, #16204, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #256]              ; 32-byte Folded Spill
	mov	w13, #37425                     ; =0x9231
	movk	w13, #12080, lsl #16
	dup.4s	v7, w13
	mov	w13, #12843                     ; =0x322b
	movk	w13, #13015, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #224]              ; 32-byte Folded Spill
	mov	w13, #61213                     ; =0xef1d
	movk	w13, #13880, lsl #16
	dup.4s	v7, w13
	mov	w13, #3329                      ; =0xd01
	movk	w13, #14672, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #192]              ; 32-byte Folded Spill
	mov	w13, #34953                     ; =0x8889
	movk	w13, #15368, lsl #16
	dup.4s	v7, w13
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15914, lsl #16
	dup.4s	v20, w13
	mov	w13, #30407                     ; =0x76c7
	movk	w13, #12559, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #160]              ; 32-byte Folded Spill
	mov	w13, #62078                     ; =0xf27e
	movk	w13, #13459, lsl #16
	dup.4s	v7, w13
	mov	w13, #3329                      ; =0xd01
	movk	w13, #14288, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #128]              ; 32-byte Folded Spill
	mov	w13, #2913                      ; =0xb61
	movk	w13, #15030, lsl #16
	dup.4s	v7, w13
	fmov.4s	v23, #1.00000000
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15658, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #96]               ; 32-byte Folded Spill
	mov	w13, #-1026555904               ; =0xc2d00000
	dup.4s	v7, w13
	mov	w13, #1120403456                ; =0x42c80000
	dup.4s	v27, w13
	mov	w13, #43579                     ; =0xaa3b
	movk	w13, #16312, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #64]               ; 32-byte Folded Spill
	mov	w13, #29184                     ; =0x7200
	movk	w13, #48945, lsl #16
	dup.4s	v7, w13
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #46527, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #32]               ; 32-byte Folded Spill
	mov	w13, #11226                     ; =0x2bda
	movk	w13, #14672, lsl #16
	dup.4s	v8, w13
	mov	w13, #38601                     ; =0x96c9
	movk	w13, #15030, lsl #16
	dup.4s	v9, w13
	mov	w13, #34982                     ; =0x88a6
	movk	w13, #15368, lsl #16
	dup.4s	v10, w13
	mov	w13, #43642                     ; =0xaa7a
	movk	w13, #15658, lsl #16
	stp	q2, q3, [sp, #288]
	mvni.4s	v2, #127, msl #16
	fneg.4s	v13, v2
	stp	q0, q1, [sp, #320]
	dup.4s	v14, w13
	mvni.4s	v0, #63, msl #16
	fneg.4s	v15, v0
	add	x13, sp, #288
	stp	q5, q4, [sp]                    ; 32-byte Folded Spill
	str	q5, [sp, #832]
	str	q4, [sp, #544]
LBB0_2:                                 ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x12, x11
	ldp	q25, q29, [x14]
	ldp	q2, q1, [sp, #256]              ; 32-byte Folded Reload
	fmul.4s	v0, v25, v1
	fmul.4s	v1, v29, v1
	fmul.4s	v1, v29, v1
	fmul.4s	v0, v25, v0
	fmul.4s	v0, v25, v0
	fmul.4s	v1, v29, v1
	fadd.4s	v1, v29, v1
	fadd.4s	v0, v25, v0
	fmul.4s	v12, v0, v2
	fmul.4s	v11, v1, v2
	fabs.4s	v1, v11
	fabs.4s	v0, v12
	fmul.4s	v7, v12, v12
	fmul.4s	v17, v11, v11
	ldp	q3, q4, [sp, #224]              ; 32-byte Folded Reload
	mov.16b	v2, v3
	fmla.4s	v2, v7, v4
	fmla.4s	v3, v17, v4
	ldr	q5, [sp, #208]                  ; 16-byte Reload
	mov.16b	v4, v5
	fmla.4s	v4, v7, v2
	mov.16b	v2, v5
	fmla.4s	v2, v17, v3
	ldp	q6, q5, [sp, #176]              ; 32-byte Folded Reload
	mov.16b	v3, v5
	fmla.4s	v3, v7, v4
	mov.16b	v4, v5
	fmla.4s	v4, v17, v2
	mov.16b	v5, v6
	mov.16b	v18, v20
	mov.16b	v19, v20
	fmov.4s	v2, #1.00000000
	fmla.4s	v5, v7, v3
	ldp	q16, q21, [sp, #144]            ; 32-byte Folded Reload
	mov.16b	v3, v16
	fmla.4s	v3, v17, v21
	fmla.4s	v16, v7, v21
	ldr	q22, [sp, #128]                 ; 16-byte Reload
	mov.16b	v21, v22
	fmla.4s	v6, v17, v4
	fmla.4s	v21, v17, v3
	mov.16b	v3, v22
	fmla.4s	v3, v7, v16
	ldr	q16, [sp, #112]                 ; 16-byte Reload
	mov.16b	v4, v16
	fmla.4s	v4, v17, v21
	fmla.4s	v18, v7, v5
	mov.16b	v5, v16
	fmla.4s	v5, v7, v3
	ldp	q28, q21, [sp, #80]             ; 32-byte Folded Reload
	mov.16b	v16, v21
	fmla.4s	v16, v17, v4
	fmla.4s	v19, v17, v6
	fmla.4s	v21, v7, v5
	movi.4s	v22, #63, lsl #24
	movi.4s	v24, #63, lsl #24
	fmov.4s	v5, #1.00000000
	fmov.4s	v4, #9.00000000
	fcmge.4s	v3, v4, v0
	fmla.4s	v22, v17, v16
	fcmge.4s	v4, v4, v1
	and.16b	v6, v4, v1
	and.16b	v16, v3, v0
	fcmge.4s	v26, v16, v28
	fcmge.4s	v28, v6, v28
	fcmge.4s	v30, v27, v6
	and.16b	v28, v28, v30
	fcmge.4s	v30, v27, v16
	and.16b	v26, v26, v30
	and.16b	v26, v26, v16
	and.16b	v28, v28, v6
	fmla.4s	v2, v17, v19
	ldr	q30, [sp, #64]                  ; 16-byte Reload
	fmul.4s	v19, v28, v30
	fmul.4s	v30, v26, v30
	movi.4s	v31, #75, lsl #24
	fadd.4s	v30, v30, v31
	fadd.4s	v19, v19, v31
	movi.4s	v31, #203, lsl #24
	fadd.4s	v19, v19, v31
	fmla.4s	v5, v17, v22
	fadd.4s	v17, v30, v31
	fcvtzs.4s	v17, v17
	fcvtzs.4s	v19, v19
	scvtf.4s	v22, v19
	scvtf.4s	v30, v17
	fmla.4s	v24, v7, v21
	ldr	q31, [sp, #48]                  ; 16-byte Reload
	fmul.4s	v21, v22, v31
	fadd.4s	v21, v28, v21
	fmul.4s	v28, v30, v31
	fadd.4s	v26, v26, v28
	fmov.4s	v28, #1.00000000
	fmla.4s	v28, v7, v18
	ldr	q31, [sp, #32]                  ; 16-byte Reload
	fmul.4s	v18, v30, v31
	fadd.4s	v18, v26, v18
	fmul.4s	v22, v22, v31
	fadd.4s	v21, v21, v22
	fmov.4s	v22, #1.00000000
	fmla.4s	v22, v7, v24
	fmul.4s	v7, v21, v8
	fmul.4s	v24, v18, v8
	fadd.4s	v24, v24, v9
	fadd.4s	v7, v7, v9
	fmul.4s	v7, v21, v7
	fmul.4s	v26, v0, v28
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v24, v10
	fadd.4s	v7, v7, v10
	fmul.4s	v7, v21, v7
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v24, v14
	fadd.4s	v7, v7, v14
	fmul.4s	v7, v21, v7
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v24, v20
	fadd.4s	v28, v7, v20
	fdiv.4s	v7, v26, v22
	fmul.4s	v22, v21, v28
	fmul.4s	v24, v18, v24
	movi.4s	v28, #63, lsl #24
	fadd.4s	v24, v24, v28
	fadd.4s	v22, v22, v28
	fmul.4s	v26, v21, v21
	fmul.4s	v22, v26, v22
	fmul.4s	v26, v18, v18
	fmul.4s	v24, v26, v24
	fadd.4s	v18, v18, v24
	fadd.4s	v21, v21, v22
	movi.2d	v26, #0xffffffffffffffff
	add.4s	v17, v17, v26
	fadd.4s	v18, v18, v23
	sshr.4s	v22, v17, #1
	shl.4s	v24, v22, #23
	add.4s	v24, v24, v23
	fmul.4s	v18, v18, v24
	add.4s	v19, v19, v26
	fadd.4s	v21, v21, v23
	sub.4s	v17, v17, v22
	sshr.4s	v22, v19, #1
	sub.4s	v19, v19, v22
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v23
	fmul.4s	v21, v21, v22
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v23
	fmul.4s	v19, v21, v19
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v23
	fmul.4s	v17, v18, v17
	fcmgt.4s	v16, v16, v27
	bsl.16b	v16, v13, v17
	fmul.4s	v2, v1, v2
	fcmgt.4s	v6, v6, v27
	bsl.16b	v6, v13, v19
	fdiv.4s	v2, v2, v5
	fmov.4s	v18, #0.25000000
	fdiv.4s	v5, v18, v6
	fsub.4s	v17, v6, v5
	fadd.4s	v5, v6, v5
	fdiv.4s	v5, v17, v5
	bsl.16b	v4, v5, v23
	fcmge.4s	v1, v23, v1
	bsl.16b	v1, v2, v4
	fdiv.4s	v2, v18, v16
	fsub.4s	v4, v16, v2
	fadd.4s	v2, v16, v2
	fdiv.4s	v2, v4, v2
	bif.16b	v2, v23, v3
	fcmge.4s	v0, v23, v0
	bsl.16b	v0, v7, v2
	mvni.4s	v3, #128, lsl #24
	bif.16b	v0, v12, v3
	fcmeq.4s	v2, v12, v12
	fadd.4s	v0, v0, v23
	bif.16b	v0, v15, v2
	bif.16b	v1, v11, v3
	fcmeq.4s	v2, v11, v11
	fadd.4s	v1, v1, v23
	bif.16b	v1, v15, v2
	fmul.4s	v2, v29, v28
	fmul.4s	v1, v2, v1
	fmul.4s	v2, v25, v28
	fmul.4s	v0, v2, v0
	add	x14, x13, x11
	ldp	q3, q2, [x14]
	fadd.4s	v0, v3, v0
	fadd.4s	v1, v2, v1
	add	x14, x10, x11
	stp	q0, q1, [x14]
	add	x11, x11, #32
	cmp	x11, #256
	b.ne	LBB0_2
; %bb.3:                                ; %direct.false84
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], v0[0]
	mov.16b	v2, v0
	ldr	q4, [sp]                        ; 16-byte Reload
	mov.s	v2[0], v4[0]
	movi.4s	v1, #63, lsl #24
	mov	w10, #10003                     ; =0x2713
	movk	w10, #15671, lsl #16
	fmov	s3, w10
	fmul.4s	v3, v2, v3[0]
	fmul.4s	v3, v4, v3
	fmul.4s	v3, v4, v3
	fadd.4s	v3, v4, v3
	mov	w10, #16938                     ; =0x422a
	movk	w10, #16204, lsl #16
	fmov	s4, w10
	fmul.4s	v3, v3, v4
	mov.s	v0[0], v3[0]
	fabs.4s	v3, v0
	mov	w10, #37425                     ; =0x9231
	movk	w10, #12080, lsl #16
	dup.4s	v5, w10
	mov	w10, #12843                     ; =0x322b
	movk	w10, #13015, lsl #16
	dup.4s	v6, w10
	fmul.4s	v4, v0, v0
	fmla.4s	v6, v4, v5
	mov	w10, #61213                     ; =0xef1d
	movk	w10, #13880, lsl #16
	dup.4s	v5, w10
	fmla.4s	v5, v4, v6
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14672, lsl #16
	dup.4s	v6, w10
	mov	w10, #34953                     ; =0x8889
	movk	w10, #15368, lsl #16
	dup.4s	v16, w10
	fmla.4s	v6, v4, v5
	fmla.4s	v16, v4, v6
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v17, w10
	fmov.4s	v5, #9.00000000
	fcmge.4s	v5, v5, v3
	and.16b	v6, v5, v3
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v7, w10
	fcmge.4s	v18, v6, v7
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v7, w10
	fcmge.4s	v19, v7, v6
	and.16b	v18, v18, v19
	and.16b	v18, v18, v6
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v19, w10
	fmul.4s	v19, v18, v19
	movi.4s	v20, #75, lsl #24
	fadd.4s	v19, v19, v20
	movi.4s	v20, #203, lsl #24
	fadd.4s	v19, v19, v20
	fcvtzs.4s	v19, v19
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v20, w10
	scvtf.4s	v21, v19
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v20, w10
	fmul.4s	v20, v21, v20
	fadd.4s	v18, v18, v20
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v20, w10
	fmul.4s	v20, v18, v20
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v21, w10
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v21, w10
	fadd.4s	v20, v20, v21
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v21, w10
	fmul.4s	v20, v18, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	fadd.4s	v20, v20, v17
	fmla.4s	v17, v4, v16
	fmov.4s	v16, #1.00000000
	fmla.4s	v16, v4, v17
	mov	w10, #30407                     ; =0x76c7
	movk	w10, #12559, lsl #16
	dup.4s	v17, w10
	mov	w10, #62078                     ; =0xf27e
	movk	w10, #13459, lsl #16
	dup.4s	v21, w10
	fmla.4s	v21, v4, v17
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14288, lsl #16
	dup.4s	v17, w10
	fmul.4s	v2, v2, v1
	fmla.4s	v17, v4, v21
	mov	w10, #2913                      ; =0xb61
	movk	w10, #15030, lsl #16
	dup.4s	v21, w10
	fmla.4s	v21, v4, v17
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15658, lsl #16
	dup.4s	v17, w10
	fmla.4s	v17, v4, v21
	movi.4s	v21, #63, lsl #24
	fmla.4s	v21, v4, v17
	fmov.4s	v17, #1.00000000
	fmla.4s	v17, v4, v21
	fmov.4s	v4, #1.00000000
	fcmge.4s	v21, v4, v3
	fmul.4s	v3, v3, v16
	fdiv.4s	v3, v3, v17
	fmul.4s	v16, v18, v20
	fadd.4s	v1, v16, v1
	fmul.4s	v16, v18, v18
	fmul.4s	v1, v16, v1
	fadd.4s	v1, v18, v1
	fadd.4s	v1, v1, v4
	movi.2d	v16, #0xffffffffffffffff
	add.4s	v16, v19, v16
	sshr.4s	v17, v16, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v4
	fmul.4s	v1, v1, v18
	sub.4s	v16, v16, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v4
	fmul.4s	v1, v1, v16
	fcmgt.4s	v6, v6, v7
	mvni.4s	v7, #127, msl #16
	fneg.4s	v7, v7
	bit.16b	v1, v7, v6
	fmov.4s	v6, #0.25000000
	fdiv.4s	v6, v6, v1
	fsub.4s	v7, v1, v6
	fadd.4s	v1, v1, v6
	fdiv.4s	v1, v7, v1
	bif.16b	v1, v4, v5
	bit.16b	v1, v3, v21
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v0, v3
	fcmeq.4s	v0, v0, v0
	fadd.4s	v1, v1, v4
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	bsl.16b	v0, v1, v3
	fmul.4s	v0, v2, v0
	ldr	q1, [sp, #16]                   ; 16-byte Reload
	fadd.4s	v0, v0, v1
	b	LBB0_7
LBB0_4:                                 ; %direct.true20.preheader
	mov	w13, #10003                     ; =0x2713
	movk	w13, #15671, lsl #16
	dup.4s	v1, w13
	mov	w13, #16938                     ; =0x422a
	movk	w13, #16204, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #256]              ; 32-byte Folded Spill
	mov	w13, #37425                     ; =0x9231
	movk	w13, #12080, lsl #16
	dup.4s	v1, w13
	mov	w13, #12843                     ; =0x322b
	movk	w13, #13015, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #224]              ; 32-byte Folded Spill
	mov	w13, #61213                     ; =0xef1d
	movk	w13, #13880, lsl #16
	dup.4s	v1, w13
	mov	w13, #3329                      ; =0xd01
	movk	w13, #14672, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #192]              ; 32-byte Folded Spill
	mov	w13, #34953                     ; =0x8889
	movk	w13, #15368, lsl #16
	dup.4s	v1, w13
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15914, lsl #16
	dup.4s	v18, w13
	mov	w13, #30407                     ; =0x76c7
	movk	w13, #12559, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #160]              ; 32-byte Folded Spill
	mov	w13, #62078                     ; =0xf27e
	movk	w13, #13459, lsl #16
	dup.4s	v1, w13
	mov	w13, #3329                      ; =0xd01
	movk	w13, #14288, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #128]              ; 32-byte Folded Spill
	mov	w13, #2913                      ; =0xb61
	movk	w13, #15030, lsl #16
	dup.4s	v1, w13
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15658, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #96]               ; 32-byte Folded Spill
	mov	w13, #-1026555904               ; =0xc2d00000
	dup.4s	v1, w13
	mov	w13, #1120403456                ; =0x42c80000
	dup.4s	v22, w13
	mov	w13, #43579                     ; =0xaa3b
	movk	w13, #16312, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #64]               ; 32-byte Folded Spill
	mov	w13, #29184                     ; =0x7200
	movk	w13, #48945, lsl #16
	dup.4s	v1, w13
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #46527, lsl #16
	dup.4s	v0, w13
	stp	q0, q1, [sp, #32]               ; 32-byte Folded Spill
	mov	w13, #11226                     ; =0x2bda
	movk	w13, #14672, lsl #16
	dup.4s	v0, w13
	str	q0, [sp, #16]                   ; 16-byte Spill
	mov	w13, #38601                     ; =0x96c9
	movk	w13, #15030, lsl #16
	dup.4s	v27, w13
	mov	w13, #34982                     ; =0x88a6
	movk	w13, #15368, lsl #16
	dup.4s	v28, w13
	mov	w13, #43642                     ; =0xaa7a
	movk	w13, #15658, lsl #16
	dup.4s	v29, w13
	add	x13, x8, x9
	add	x14, x10, x9
	add	x15, x12, x9
	movi.4s	v30, #63, lsl #24
	fmov.4s	v31, #1.00000000
	mvni.4s	v0, #127, msl #16
	fneg.4s	v12, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v15, v0
LBB0_5:                                 ; %direct.true20
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x15, x11
	ldp	q8, q9, [x16]
	ldp	q2, q1, [sp, #256]              ; 32-byte Folded Reload
	fmul.4s	v0, v8, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v0, v8, v0
	fmul.4s	v0, v8, v0
	fmul.4s	v1, v9, v1
	fadd.4s	v1, v9, v1
	fadd.4s	v0, v8, v0
	fmul.4s	v11, v0, v2
	fmul.4s	v10, v1, v2
	fabs.4s	v14, v10
	fabs.4s	v13, v11
	fmul.4s	v5, v11, v11
	fmul.4s	v16, v10, v10
	ldp	q1, q2, [sp, #224]              ; 32-byte Folded Reload
	mov.16b	v0, v1
	fmla.4s	v0, v5, v2
	fmla.4s	v1, v16, v2
	ldr	q3, [sp, #208]                  ; 16-byte Reload
	mov.16b	v2, v3
	fmla.4s	v2, v5, v0
	mov.16b	v0, v3
	fmla.4s	v0, v16, v1
	ldp	q4, q3, [sp, #176]              ; 32-byte Folded Reload
	mov.16b	v1, v3
	fmla.4s	v1, v5, v2
	mov.16b	v2, v3
	fmla.4s	v2, v16, v0
	mov.16b	v3, v4
	mov.16b	v7, v18
	mov.16b	v17, v18
	fmov.4s	v0, #1.00000000
	fmla.4s	v3, v5, v1
	ldp	q6, q19, [sp, #144]             ; 32-byte Folded Reload
	mov.16b	v1, v6
	fmla.4s	v1, v16, v19
	fmla.4s	v6, v5, v19
	ldr	q20, [sp, #128]                 ; 16-byte Reload
	mov.16b	v19, v20
	fmla.4s	v4, v16, v2
	fmla.4s	v19, v16, v1
	mov.16b	v1, v20
	fmla.4s	v1, v5, v6
	ldr	q6, [sp, #112]                  ; 16-byte Reload
	mov.16b	v2, v6
	fmla.4s	v2, v16, v19
	fmla.4s	v7, v5, v3
	mov.16b	v3, v6
	fmla.4s	v3, v5, v1
	ldp	q24, q19, [sp, #80]             ; 32-byte Folded Reload
	mov.16b	v6, v19
	fmla.4s	v6, v16, v2
	fmla.4s	v17, v16, v4
	fmla.4s	v19, v5, v3
	movi.4s	v20, #63, lsl #24
	movi.4s	v21, #63, lsl #24
	fmov.4s	v3, #1.00000000
	fmov.4s	v2, #9.00000000
	fcmge.4s	v1, v2, v13
	fmla.4s	v20, v16, v6
	fcmge.4s	v2, v2, v14
	and.16b	v4, v2, v14
	and.16b	v6, v1, v13
	fcmge.4s	v23, v6, v24
	fcmge.4s	v24, v4, v24
	fcmge.4s	v25, v22, v4
	and.16b	v24, v24, v25
	fcmge.4s	v25, v22, v6
	and.16b	v23, v23, v25
	and.16b	v23, v23, v6
	and.16b	v24, v24, v4
	fmla.4s	v0, v16, v17
	ldr	q25, [sp, #64]                  ; 16-byte Reload
	fmul.4s	v17, v24, v25
	fmul.4s	v25, v23, v25
	movi.4s	v26, #75, lsl #24
	fadd.4s	v25, v25, v26
	fadd.4s	v17, v17, v26
	movi.4s	v26, #203, lsl #24
	fadd.4s	v17, v17, v26
	fmla.4s	v3, v16, v20
	fadd.4s	v16, v25, v26
	fcvtzs.4s	v16, v16
	fcvtzs.4s	v17, v17
	scvtf.4s	v20, v17
	scvtf.4s	v25, v16
	fmla.4s	v21, v5, v19
	ldr	q26, [sp, #48]                  ; 16-byte Reload
	fmul.4s	v19, v20, v26
	fadd.4s	v19, v24, v19
	fmul.4s	v24, v25, v26
	fadd.4s	v23, v23, v24
	fmov.4s	v24, #1.00000000
	fmla.4s	v24, v5, v7
	ldr	q26, [sp, #32]                  ; 16-byte Reload
	fmul.4s	v7, v25, v26
	fadd.4s	v7, v23, v7
	fmul.4s	v20, v20, v26
	fadd.4s	v19, v19, v20
	fmov.4s	v20, #1.00000000
	fmla.4s	v20, v5, v21
	ldr	q21, [sp, #16]                  ; 16-byte Reload
	fmul.4s	v5, v19, v21
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v27
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v19, v5
	fmul.4s	v23, v13, v24
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v28
	fadd.4s	v5, v5, v28
	fmul.4s	v5, v19, v5
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v29
	fadd.4s	v5, v5, v29
	fmul.4s	v5, v19, v5
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v18
	fadd.4s	v24, v5, v18
	fdiv.4s	v5, v23, v20
	fmul.4s	v20, v19, v24
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v30
	fadd.4s	v20, v20, v30
	fmul.4s	v23, v19, v19
	fmul.4s	v20, v23, v20
	fmul.4s	v23, v7, v7
	fmul.4s	v21, v23, v21
	fadd.4s	v7, v7, v21
	fadd.4s	v19, v19, v20
	movi.2d	v23, #0xffffffffffffffff
	add.4s	v16, v16, v23
	fadd.4s	v7, v7, v31
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v31
	fmul.4s	v7, v7, v21
	add.4s	v17, v17, v23
	fadd.4s	v19, v19, v31
	sub.4s	v16, v16, v20
	sshr.4s	v20, v17, #1
	sub.4s	v17, v17, v20
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v31
	fmul.4s	v19, v19, v20
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v31
	fmul.4s	v17, v19, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v31
	fmul.4s	v7, v7, v16
	fcmgt.4s	v6, v6, v22
	bsl.16b	v6, v12, v7
	fmul.4s	v0, v14, v0
	fcmgt.4s	v4, v4, v22
	bsl.16b	v4, v12, v17
	fdiv.4s	v0, v0, v3
	fmov.4s	v16, #0.25000000
	fdiv.4s	v3, v16, v4
	fsub.4s	v7, v4, v3
	fadd.4s	v3, v4, v3
	fdiv.4s	v3, v7, v3
	bsl.16b	v2, v3, v31
	fcmge.4s	v3, v31, v14
	bif.16b	v0, v2, v3
	fdiv.4s	v2, v16, v6
	fsub.4s	v3, v6, v2
	fadd.4s	v2, v6, v2
	fdiv.4s	v2, v3, v2
	bsl.16b	v1, v2, v31
	fcmge.4s	v2, v31, v13
	bit.16b	v1, v5, v2
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v11, v3
	fcmeq.4s	v2, v11, v11
	fadd.4s	v1, v1, v31
	bif.16b	v1, v15, v2
	bif.16b	v0, v10, v3
	fcmeq.4s	v2, v10, v10
	fadd.4s	v0, v0, v31
	bif.16b	v0, v15, v2
	fmul.4s	v2, v9, v30
	fmul.4s	v0, v2, v0
	fmul.4s	v2, v8, v30
	fmul.4s	v1, v2, v1
	add	x16, x14, x11
	ldp	q3, q2, [x16]
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x16, x13, x11
	stp	q1, q0, [x16]
	add	x11, x11, #32
	cmp	x11, #256
	b.ne	LBB0_5
; %bb.6:                                ; %direct.false21
	add	x9, x9, #256
	ldr	s2, [x12, x9]
	movi.2d	v0, #0000000000000000
	movi.4s	v1, #63, lsl #24
	mov	w11, #10003                     ; =0x2713
	movk	w11, #15671, lsl #16
	fmov	s3, w11
	fmul.4s	v3, v2, v3
	fmul.4s	v3, v2, v3
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v2, v3
	mov	w11, #16938                     ; =0x422a
	movk	w11, #16204, lsl #16
	fmov	s4, w11
	fmul.4s	v3, v3, v4
	mov.s	v0[0], v3[0]
	fabs.4s	v3, v0
	fmul.4s	v4, v0, v0
	mov	w11, #37425                     ; =0x9231
	movk	w11, #12080, lsl #16
	dup.4s	v5, w11
	mov	w11, #12843                     ; =0x322b
	movk	w11, #13015, lsl #16
	dup.4s	v6, w11
	fmla.4s	v6, v4, v5
	mov	w11, #61213                     ; =0xef1d
	movk	w11, #13880, lsl #16
	dup.4s	v5, w11
	mov	w11, #3329                      ; =0xd01
	movk	w11, #14672, lsl #16
	dup.4s	v7, w11
	fmla.4s	v5, v4, v6
	fmla.4s	v7, v4, v5
	mov	w11, #34953                     ; =0x8889
	movk	w11, #15368, lsl #16
	dup.4s	v16, w11
	fmla.4s	v16, v4, v7
	mov	w11, #43691                     ; =0xaaab
	movk	w11, #15914, lsl #16
	dup.4s	v17, w11
	fmov.4s	v5, #9.00000000
	fcmge.4s	v5, v5, v3
	and.16b	v6, v5, v3
	mov	w11, #-1026555904               ; =0xc2d00000
	dup.4s	v18, w11
	mov	w11, #1120403456                ; =0x42c80000
	dup.4s	v7, w11
	fcmge.4s	v18, v6, v18
	fcmge.4s	v19, v7, v6
	and.16b	v18, v18, v19
	mov	w11, #43579                     ; =0xaa3b
	movk	w11, #16312, lsl #16
	dup.4s	v19, w11
	and.16b	v18, v18, v6
	fmul.4s	v19, v18, v19
	movi.4s	v20, #75, lsl #24
	fadd.4s	v19, v19, v20
	movi.4s	v20, #203, lsl #24
	fadd.4s	v19, v19, v20
	fcvtzs.4s	v19, v19
	scvtf.4s	v20, v19
	mov	w11, #29184                     ; =0x7200
	movk	w11, #48945, lsl #16
	dup.4s	v21, w11
	fmul.4s	v21, v20, v21
	fadd.4s	v18, v18, v21
	mov	w11, #48782                     ; =0xbe8e
	movk	w11, #46527, lsl #16
	dup.4s	v21, w11
	fmul.4s	v20, v20, v21
	fadd.4s	v18, v18, v20
	mov	w11, #11226                     ; =0x2bda
	movk	w11, #14672, lsl #16
	dup.4s	v20, w11
	mov	w11, #38601                     ; =0x96c9
	movk	w11, #15030, lsl #16
	dup.4s	v21, w11
	fmul.4s	v20, v18, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	mov	w11, #34982                     ; =0x88a6
	movk	w11, #15368, lsl #16
	dup.4s	v21, w11
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	mov	w11, #43642                     ; =0xaa7a
	movk	w11, #15658, lsl #16
	dup.4s	v21, w11
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v18, v20
	fadd.4s	v20, v20, v17
	fmla.4s	v17, v4, v16
	fmov.4s	v16, #1.00000000
	fmla.4s	v16, v4, v17
	mov	w11, #30407                     ; =0x76c7
	movk	w11, #12559, lsl #16
	dup.4s	v17, w11
	mov	w11, #62078                     ; =0xf27e
	movk	w11, #13459, lsl #16
	dup.4s	v21, w11
	fmla.4s	v21, v4, v17
	mov	w11, #3329                      ; =0xd01
	movk	w11, #14288, lsl #16
	dup.4s	v17, w11
	fmla.4s	v17, v4, v21
	mov	w11, #2913                      ; =0xb61
	movk	w11, #15030, lsl #16
	dup.4s	v21, w11
	fmla.4s	v21, v4, v17
	mov	w11, #43691                     ; =0xaaab
	movk	w11, #15658, lsl #16
	dup.4s	v17, w11
	fmul.4s	v2, v2, v1
	fmla.4s	v17, v4, v21
	movi.4s	v21, #63, lsl #24
	fmla.4s	v21, v4, v17
	fmov.4s	v17, #1.00000000
	fmla.4s	v17, v4, v21
	fmov.4s	v4, #1.00000000
	fcmge.4s	v21, v4, v3
	fmul.4s	v3, v3, v16
	fdiv.4s	v3, v3, v17
	fmul.4s	v16, v18, v20
	fadd.4s	v1, v16, v1
	fmul.4s	v16, v18, v18
	fmul.4s	v1, v16, v1
	fadd.4s	v1, v18, v1
	fadd.4s	v1, v1, v4
	movi.2d	v16, #0xffffffffffffffff
	add.4s	v16, v19, v16
	sshr.4s	v17, v16, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v4
	fmul.4s	v1, v1, v18
	sub.4s	v16, v16, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v4
	fmul.4s	v1, v1, v16
	fcmgt.4s	v6, v6, v7
	mvni.4s	v7, #127, msl #16
	fneg.4s	v7, v7
	bit.16b	v1, v7, v6
	fmov.4s	v6, #0.25000000
	fdiv.4s	v6, v6, v1
	fsub.4s	v7, v1, v6
	fadd.4s	v1, v1, v6
	fdiv.4s	v1, v7, v1
	bif.16b	v1, v4, v5
	bit.16b	v1, v3, v21
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v0, v3
	fcmeq.4s	v0, v0, v0
	fadd.4s	v1, v1, v4
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	bsl.16b	v0, v1, v3
	fmul.4s	v0, v2, v0
	ldr	s1, [x10, x9]
	fadd.4s	v0, v1, v0
LBB0_7:                                 ; %common.ret
	str	s0, [x8, x9]
	add	sp, sp, #864
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_7:
	.quad	256                             ; 0x100
	.quad	260                             ; 0x104
lCPI1_8:
	.quad	272                             ; 0x110
	.quad	276                             ; 0x114
lCPI1_9:
	.quad	264                             ; 0x108
	.quad	268                             ; 0x10c
lCPI1_10:
	.quad	280                             ; 0x118
	.quad	284                             ; 0x11c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1568
	str	x0, [sp, #296]                  ; 8-byte Spill
	cbz	w3, LBB1_208
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x19, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	ldp	w23, w8, [x2, #44]
	str	w8, [sp, #292]                  ; 4-byte Spill
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [sp, #320]                  ; 16-byte Spill
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #160]                  ; 16-byte Spill
Lloh4:
	adrp	x8, lCPI1_2@PAGE
Lloh5:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Spill
Lloh6:
	adrp	x8, lCPI1_3@PAGE
Lloh7:
	ldr	q0, [x8, lCPI1_3@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Spill
Lloh8:
	adrp	x8, lCPI1_4@PAGE
Lloh9:
	ldr	q0, [x8, lCPI1_4@PAGEOFF]
	str	q0, [sp, #112]                  ; 16-byte Spill
Lloh10:
	adrp	x8, lCPI1_5@PAGE
Lloh11:
	ldr	q0, [x8, lCPI1_5@PAGEOFF]
	str	q0, [sp, #96]                   ; 16-byte Spill
Lloh12:
	adrp	x8, lCPI1_6@PAGE
Lloh13:
	ldr	q0, [x8, lCPI1_6@PAGEOFF]
	str	q0, [sp, #336]                  ; 16-byte Spill
	mvni.4s	v0, #127, msl #16
	fneg.4s	v1, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q1, [sp, #432]              ; 32-byte Folded Spill
	ldp	w27, w26, [x2]
	add	x25, sp, #1280
	ldp	w28, w8, [x2, #8]
	str	x8, [sp, #280]                  ; 8-byte Spill
	add	x24, sp, #992
	str	w3, [sp, #252]                  ; 4-byte Spill
	str	w23, [sp, #20]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w19, [sp, #252]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w27, #1
	cmp	w8, w23
	cset	w8, eq
	csinc	w27, wzr, w27, eq
	cinc	w9, w26, eq
	ldr	w10, [sp, #292]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w26, wzr, w9, ne
	add	w28, w28, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_208
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_67 Depth 2
                                        ;     Child Loop BB1_101 Depth 2
                                        ;     Child Loop BB1_129 Depth 2
                                        ;     Child Loop BB1_17 Depth 2
	ubfiz	x8, x27, #5, #32
	ldr	x12, [sp, #280]                 ; 8-byte Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	stp	w27, w26, [x20]
	str	w28, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x12, #2, hi
	csel	x21, x10, xzr, ls
	cmp	x21, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x21, [sp, #296]                 ; 8-byte Reload
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x19, x21, #3
	cbz	x19, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #296]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #296]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #296]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x23, [sp, #296]                 ; 8-byte Reload
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x23
	ldr	w23, [sp, #20]                  ; 4-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w21, #0x7
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v1, w8
	ldr	q0, [sp, #160]                  ; 16-byte Reload
	cmhi.4s	v23, v1, v0
	ldr	q0, [sp, #320]                  ; 16-byte Reload
	str	q1, [sp, #304]                  ; 16-byte Spill
	cmhi.4s	v17, v1, v0
	uzp1.8h	v9, v17, v23
	umaxv.8h	h0, v9
	fmov	w8, s0
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #296]                  ; 8-byte Reload
	ldr	x10, [x8]
	ldr	x9, [x8, #16]
	ldr	x8, [x8, #48]
	sshll.2d	v0, v17, #0
	sshll.2d	v1, v23, #0
	sshll2.2d	v12, v17, #0
	sshll2.2d	v31, v23, #0
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	and.16b	v2, v31, v2
	str	q2, [sp, #400]                  ; 16-byte Spill
	ldr	q2, [sp, #128]                  ; 16-byte Reload
	and.16b	v2, v12, v2
	str	q2, [sp, #256]                  ; 16-byte Spill
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	and.16b	v1, v1, v2
	str	q1, [sp, #368]                  ; 16-byte Spill
	ldr	q1, [sp, #96]                   ; 16-byte Reload
	and.16b	v19, v0, v1
	ubfiz	w11, w27, #2, #27
	orr	w11, w11, w19
	dup.4s	v0, w11
	and.16b	v1, v17, v0
	and.16b	v0, v23, v0
	ushll2.2d	v3, v0, #0
	ushll2.2d	v2, v1, #0
	ushll.2d	v4, v0, #0
	ushll.2d	v24, v1, #0
	subs	x11, x10, x8
	cset	w12, hs
	lsr	x11, x11, #2
	cmp	x11, #1104
	csel	w11, wzr, w12, ls
	subs	x12, x8, x10
	cset	w13, hs
	lsr	x12, x12, #2
	mov	w14, #10003                     ; =0x2713
	movk	w14, #15671, lsl #16
	dup.4s	v5, w14
	mov	w14, #16938                     ; =0x422a
	movk	w14, #16204, lsl #16
	dup.4s	v0, w14
	stp	q5, q0, [sp, #480]              ; 32-byte Folded Spill
	cmp	x12, #1104
	csel	w12, wzr, w13, ls
	mov	w13, #37425                     ; =0x9231
	movk	w13, #12080, lsl #16
	dup.4s	v5, w13
	mov	w13, #12843                     ; =0x322b
	movk	w13, #13015, lsl #16
	dup.4s	v0, w13
	stp	q5, q0, [sp, #512]              ; 32-byte Folded Spill
	orr	w13, w11, w12
	subs	x11, x9, x8
	mov	w12, #61213                     ; =0xef1d
	movk	w12, #13880, lsl #16
	dup.4s	v0, w12
	str	q0, [sp, #544]                  ; 16-byte Spill
	mov	w12, #3329                      ; =0xd01
	movk	w12, #14672, lsl #16
	dup.4s	v0, w12
	str	q0, [sp, #576]                  ; 16-byte Spill
	cset	w12, hs
	lsr	x11, x11, #2
	mov	w14, #34953                     ; =0x8889
	movk	w14, #15368, lsl #16
	dup.4s	v5, w14
	mov	w14, #43691                     ; =0xaaab
	movk	w14, #15914, lsl #16
	dup.4s	v1, w14
	cmp	x11, #1104
	csel	w11, wzr, w12, ls
	subs	x12, x8, x9
	cset	w14, hs
	lsr	x12, x12, #2
	cmp	x12, #1104
	csel	w12, wzr, w14, ls
	fmov	x14, d24
	add	x14, x14, x14, lsl #6
	lsl	x14, x14, #2
	mov	w15, #30407                     ; =0x76c7
	movk	w15, #12559, lsl #16
	dup.4s	v0, w15
	str	q0, [sp, #560]                  ; 16-byte Spill
	mov	w15, #62078                     ; =0xf27e
	movk	w15, #13459, lsl #16
	dup.4s	v6, w15
	mov	w15, #3329                      ; =0xd01
	movk	w15, #14288, lsl #16
	dup.4s	v0, w15
	stp	q6, q0, [sp, #592]              ; 32-byte Folded Spill
	mov	w15, #2913                      ; =0xb61
	movk	w15, #15030, lsl #16
	dup.4s	v6, w15
	mov	w15, #43691                     ; =0xaaab
	movk	w15, #15658, lsl #16
	dup.4s	v30, w15
	mov	w15, #-1026555904               ; =0xc2d00000
	dup.4s	v18, w15
	mov	w15, #1120403456                ; =0x42c80000
	dup.4s	v0, w15
	mov	w15, #43579                     ; =0xaa3b
	movk	w15, #16312, lsl #16
	dup.4s	v16, w15
	mov	w15, #29184                     ; =0x7200
	movk	w15, #48945, lsl #16
	dup.4s	v27, w15
	mov	w15, #48782                     ; =0xbe8e
	movk	w15, #46527, lsl #16
	dup.4s	v22, w15
	mov	w15, #11226                     ; =0x2bda
	movk	w15, #14672, lsl #16
	dup.4s	v21, w15
	mov	w15, #38601                     ; =0x96c9
	movk	w15, #15030, lsl #16
	dup.4s	v7, w15
	str	q7, [sp, #464]                  ; 16-byte Spill
	mov	w15, #34982                     ; =0x88a6
	movk	w15, #15368, lsl #16
	dup.4s	v29, w15
	mov	w15, #43642                     ; =0xaa7a
	movk	w15, #15658, lsl #16
	dup.4s	v28, w15
	xtn.2s	v3, v3
	str	d3, [sp, #224]                  ; 8-byte Spill
	xtn.2s	v3, v4
	str	d3, [sp, #208]                  ; 8-byte Spill
	xtn.2s	v2, v2
	str	d2, [sp, #192]                  ; 8-byte Spill
	cmp	w13, #1
	b.ne	LBB1_65
; %bb.14:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w11, w11, w12
	cbz	w11, LBB1_65
; %bb.15:                               ; %direct.true20.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q24, [sp, #304]                 ; 16-byte Spill
	str	q19, [sp, #416]                 ; 16-byte Spill
	mov	x11, #0                         ; =0x0
	add	x12, x8, x14
	add	x13, x9, x14
	add	x14, x10, x14
	ldr	q2, [sp, #336]                  ; 16-byte Reload
	and.16b	v2, v9, v2
	addv.8h	h14, v2
	fmov	w15, s14
	b	LBB1_17
LBB1_16:                                ; %else71
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x11, x11, #32
	cmp	x11, #256
	b.eq	LBB1_163
LBB1_17:                                ; %direct.true20.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x14, x11
	movi.2d	v12, #0000000000000000
	movi.2d	v15, #0000000000000000
	tbz	w15, #0, LBB1_33
; %bb.18:                               ; %cond.load
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldr	s12, [x16]
	and	w17, w15, #0xff
	tbnz	w17, #1, LBB1_34
LBB1_19:                                ; %else11
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #2, LBB1_35
LBB1_20:                                ; %cond.load13
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #8
	ld1.s	{ v12 }[2], [x0]
	tbnz	w17, #3, LBB1_36
LBB1_21:                                ; %else17
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #4, LBB1_37
LBB1_22:                                ; %cond.load19
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #16
	ld1.s	{ v15 }[0], [x0]
	tbnz	w17, #5, LBB1_38
LBB1_23:                                ; %else23
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #6, LBB1_39
LBB1_24:                                ; %cond.load25
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #24
	ld1.s	{ v15 }[2], [x0]
	tbnz	w17, #7, LBB1_40
LBB1_25:                                ; %else29
                                        ;   in Loop: Header=BB1_17 Depth=2
	fmov	w17, s14
	add	x16, x13, x11
	movi.2d	v10, #0000000000000000
	movi.2d	v31, #0000000000000000
	tbz	w17, #0, LBB1_41
LBB1_26:                                ; %cond.load32
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldr	s10, [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_42
LBB1_27:                                ; %else36
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #2, LBB1_43
LBB1_28:                                ; %cond.load38
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #8
	ld1.s	{ v10 }[2], [x0]
	tbnz	w17, #3, LBB1_44
LBB1_29:                                ; %else42
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #4, LBB1_45
LBB1_30:                                ; %cond.load44
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #16
	ld1.s	{ v31 }[0], [x0]
	tbnz	w17, #5, LBB1_46
LBB1_31:                                ; %else48
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #6, LBB1_47
LBB1_32:                                ; %cond.load50
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #24
	ld1.s	{ v31 }[2], [x0]
	tbnz	w17, #7, LBB1_48
	b	LBB1_49
LBB1_33:                                ; %else
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w17, w15, #0xff
	tbz	w17, #1, LBB1_19
LBB1_34:                                ; %cond.load10
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #4
	ld1.s	{ v12 }[1], [x0]
	tbnz	w17, #2, LBB1_20
LBB1_35:                                ; %else14
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #3, LBB1_21
LBB1_36:                                ; %cond.load16
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #12
	ld1.s	{ v12 }[3], [x0]
	tbnz	w17, #4, LBB1_22
LBB1_37:                                ; %else20
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #5, LBB1_23
LBB1_38:                                ; %cond.load22
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #20
	ld1.s	{ v15 }[1], [x0]
	tbnz	w17, #6, LBB1_24
LBB1_39:                                ; %else26
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #7, LBB1_25
LBB1_40:                                ; %cond.load28
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x16, x16, #28
	ld1.s	{ v15 }[3], [x16]
	fmov	w17, s14
	add	x16, x13, x11
	movi.2d	v10, #0000000000000000
	movi.2d	v31, #0000000000000000
	tbnz	w17, #0, LBB1_26
LBB1_41:                                ; %else33
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_27
LBB1_42:                                ; %cond.load35
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #4
	ld1.s	{ v10 }[1], [x0]
	tbnz	w17, #2, LBB1_28
LBB1_43:                                ; %else39
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #3, LBB1_29
LBB1_44:                                ; %cond.load41
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #12
	ld1.s	{ v10 }[3], [x0]
	tbnz	w17, #4, LBB1_30
LBB1_45:                                ; %else45
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #5, LBB1_31
LBB1_46:                                ; %cond.load47
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #20
	ld1.s	{ v31 }[1], [x0]
	tbnz	w17, #6, LBB1_32
LBB1_47:                                ; %else51
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #7, LBB1_49
LBB1_48:                                ; %cond.load53
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x16, x16, #28
	ld1.s	{ v31 }[3], [x16]
LBB1_49:                                ; %else54
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldp	q2, q3, [sp, #480]              ; 32-byte Folded Reload
	fmul.4s	v2, v12, v2
	fmul.4s	v2, v12, v2
	fmul.4s	v2, v12, v2
	fadd.4s	v2, v12, v2
	fmul.4s	v2, v2, v3
	mov.16b	v19, v17
	and.16b	v2, v17, v2
	fabs.4s	v3, v2
	fmul.4s	v4, v2, v2
	ldp	q7, q26, [sp, #512]             ; 32-byte Folded Reload
	fmla.4s	v26, v4, v7
	ldp	q25, q7, [sp, #544]             ; 32-byte Folded Reload
	fmla.4s	v25, v4, v26
	ldr	q26, [sp, #576]                 ; 16-byte Reload
	fmla.4s	v26, v4, v25
	mov.16b	v25, v5
	fmla.4s	v25, v4, v26
	mov.16b	v26, v1
	fmla.4s	v26, v4, v25
	fmov.4s	v25, #1.00000000
	fmla.4s	v25, v4, v26
	fmul.4s	v25, v3, v25
	ldp	q26, q20, [sp, #592]            ; 32-byte Folded Reload
	fmla.4s	v26, v4, v7
	fmla.4s	v20, v4, v26
	mov.16b	v26, v6
	fmla.4s	v26, v4, v20
	mov.16b	v20, v30
	fmla.4s	v20, v4, v26
	movi.4s	v26, #63, lsl #24
	fmla.4s	v26, v4, v20
	fmov.4s	v20, #1.00000000
	fmla.4s	v20, v4, v26
	fdiv.4s	v4, v25, v20
	fmov.4s	v7, #9.00000000
	fcmge.4s	v20, v7, v3
	and.16b	v25, v20, v3
	fcmge.4s	v26, v25, v18
	fcmge.4s	v11, v0, v25
	and.16b	v26, v26, v11
	and.16b	v26, v26, v25
	fmul.4s	v11, v26, v16
	movi.4s	v7, #75, lsl #24
	fadd.4s	v11, v11, v7
	movi.4s	v7, #203, lsl #24
	fadd.4s	v11, v11, v7
	fcvtzs.4s	v11, v11
	scvtf.4s	v13, v11
	fmul.4s	v8, v13, v27
	fadd.4s	v26, v26, v8
	fmul.4s	v8, v13, v22
	fadd.4s	v26, v26, v8
	fmul.4s	v8, v26, v21
	ldr	q7, [sp, #464]                  ; 16-byte Reload
	fadd.4s	v8, v8, v7
	fmul.4s	v8, v26, v8
	fadd.4s	v8, v8, v29
	fmul.4s	v8, v26, v8
	fadd.4s	v8, v8, v28
	fmul.4s	v8, v26, v8
	fadd.4s	v8, v8, v1
	fmul.4s	v8, v26, v8
	movi.4s	v7, #63, lsl #24
	fadd.4s	v8, v8, v7
	fmul.4s	v13, v26, v26
	fmul.4s	v8, v13, v8
	fadd.4s	v26, v26, v8
	fmov.4s	v17, #1.00000000
	fadd.4s	v26, v26, v17
	movi.2d	v24, #0xffffffffffffffff
	add.4s	v8, v11, v24
	sshr.4s	v11, v8, #1
	shl.4s	v13, v11, #23
	add.4s	v13, v13, v17
	fmul.4s	v26, v26, v13
	sub.4s	v8, v8, v11
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v17
	fmul.4s	v26, v26, v8
	fcmgt.4s	v25, v25, v0
	ldr	q24, [sp, #448]                 ; 16-byte Reload
	bsl.16b	v25, v24, v26
	fmov.4s	v24, #0.25000000
	fdiv.4s	v26, v24, v25
	fsub.4s	v8, v25, v26
	fadd.4s	v25, v25, v26
	fdiv.4s	v25, v8, v25
	bsl.16b	v20, v25, v17
	fcmge.4s	v3, v17, v3
	bsl.16b	v3, v4, v20
	mvni.4s	v4, #128, lsl #24
	bif.16b	v3, v2, v4
	fcmeq.4s	v2, v2, v2
	fadd.4s	v3, v3, v17
	ldr	q4, [sp, #432]                  ; 16-byte Reload
	bsl.16b	v2, v3, v4
	fmul.4s	v3, v12, v7
	fmul.4s	v2, v3, v2
	fadd.4s	v2, v10, v2
	fmov	w17, s14
	add	x16, x12, x11
	tbz	w17, #0, LBB1_53
; %bb.50:                               ; %cond.store
                                        ;   in Loop: Header=BB1_17 Depth=2
	str	s2, [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_54
LBB1_51:                                ; %else59
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #2, LBB1_55
LBB1_52:                                ; %cond.store60
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #8
	st1.s	{ v2 }[2], [x0]
	tbnz	w17, #3, LBB1_56
	b	LBB1_57
LBB1_53:                                ; %else57
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_51
LBB1_54:                                ; %cond.store58
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #4
	st1.s	{ v2 }[1], [x0]
	tbnz	w17, #2, LBB1_52
LBB1_55:                                ; %else61
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #3, LBB1_57
LBB1_56:                                ; %cond.store62
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #12
	st1.s	{ v2 }[3], [x0]
LBB1_57:                                ; %else63
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldp	q2, q3, [sp, #480]              ; 32-byte Folded Reload
	fmul.4s	v2, v15, v2
	fmul.4s	v2, v15, v2
	fmul.4s	v2, v15, v2
	fadd.4s	v2, v15, v2
	fmul.4s	v2, v2, v3
	and.16b	v2, v23, v2
	fabs.4s	v3, v2
	fmul.4s	v4, v2, v2
	ldp	q7, q20, [sp, #512]             ; 32-byte Folded Reload
	fmla.4s	v20, v4, v7
	ldp	q25, q7, [sp, #544]             ; 32-byte Folded Reload
	fmla.4s	v25, v4, v20
	ldr	q20, [sp, #576]                 ; 16-byte Reload
	fmla.4s	v20, v4, v25
	mov.16b	v25, v5
	fmla.4s	v25, v4, v20
	mov.16b	v20, v1
	fmla.4s	v20, v4, v25
	fmov.4s	v25, #1.00000000
	fmla.4s	v25, v4, v20
	fmul.4s	v20, v3, v25
	ldp	q25, q26, [sp, #592]            ; 32-byte Folded Reload
	fmla.4s	v25, v4, v7
	fmla.4s	v26, v4, v25
	mov.16b	v25, v6
	fmla.4s	v25, v4, v26
	mov.16b	v26, v30
	fmla.4s	v26, v4, v25
	movi.4s	v25, #63, lsl #24
	fmla.4s	v25, v4, v26
	fmov.4s	v26, #1.00000000
	fmla.4s	v26, v4, v25
	fdiv.4s	v4, v20, v26
	fmov.4s	v7, #9.00000000
	fcmge.4s	v20, v7, v3
	and.16b	v25, v20, v3
	fcmge.4s	v26, v25, v18
	fcmge.4s	v8, v0, v25
	and.16b	v26, v26, v8
	and.16b	v26, v26, v25
	fmul.4s	v8, v26, v16
	movi.4s	v7, #75, lsl #24
	fadd.4s	v8, v8, v7
	movi.4s	v7, #203, lsl #24
	fadd.4s	v8, v8, v7
	fcvtzs.4s	v8, v8
	scvtf.4s	v10, v8
	fmul.4s	v11, v10, v27
	fadd.4s	v26, v26, v11
	fmul.4s	v10, v10, v22
	fadd.4s	v26, v26, v10
	fmul.4s	v10, v26, v21
	ldr	q7, [sp, #464]                  ; 16-byte Reload
	fadd.4s	v10, v10, v7
	fmul.4s	v10, v26, v10
	fadd.4s	v10, v10, v29
	fmul.4s	v10, v26, v10
	fadd.4s	v10, v10, v28
	fmul.4s	v10, v26, v10
	fadd.4s	v10, v10, v1
	fmul.4s	v10, v26, v10
	movi.4s	v7, #63, lsl #24
	fadd.4s	v10, v10, v7
	fmul.4s	v11, v26, v26
	fmul.4s	v10, v11, v10
	fadd.4s	v26, v26, v10
	fadd.4s	v26, v26, v17
	movi.2d	v24, #0xffffffffffffffff
	add.4s	v8, v8, v24
	sshr.4s	v10, v8, #1
	shl.4s	v11, v10, #23
	add.4s	v11, v11, v17
	fmul.4s	v26, v26, v11
	sub.4s	v8, v8, v10
	shl.4s	v8, v8, #23
	add.4s	v8, v8, v17
	fmul.4s	v26, v26, v8
	fcmgt.4s	v25, v25, v0
	ldr	q24, [sp, #448]                 ; 16-byte Reload
	bsl.16b	v25, v24, v26
	fmov.4s	v24, #0.25000000
	fdiv.4s	v26, v24, v25
	fsub.4s	v8, v25, v26
	fadd.4s	v25, v25, v26
	fdiv.4s	v25, v8, v25
	bsl.16b	v20, v25, v17
	fcmge.4s	v3, v17, v3
	bsl.16b	v3, v4, v20
	mvni.4s	v4, #128, lsl #24
	bif.16b	v3, v2, v4
	fcmeq.4s	v2, v2, v2
	fadd.4s	v3, v3, v17
	ldr	q4, [sp, #432]                  ; 16-byte Reload
	bsl.16b	v2, v3, v4
	fmul.4s	v3, v15, v7
	fmul.4s	v2, v3, v2
	fadd.4s	v2, v31, v2
	tbz	w17, #4, LBB1_61
; %bb.58:                               ; %cond.store64
                                        ;   in Loop: Header=BB1_17 Depth=2
	str	s2, [x16, #16]
	mov.16b	v17, v19
	tbnz	w17, #5, LBB1_62
LBB1_59:                                ; %else67
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #6, LBB1_63
LBB1_60:                                ; %cond.store68
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #24
	st1.s	{ v2 }[2], [x0]
	tbz	w17, #7, LBB1_16
	b	LBB1_64
LBB1_61:                                ; %else65
                                        ;   in Loop: Header=BB1_17 Depth=2
	mov.16b	v17, v19
	tbz	w17, #5, LBB1_59
LBB1_62:                                ; %cond.store66
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #20
	st1.s	{ v2 }[1], [x0]
	tbnz	w17, #6, LBB1_60
LBB1_63:                                ; %else69
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #7, LBB1_16
LBB1_64:                                ; %cond.store70
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x16, x16, #28
	st1.s	{ v2 }[3], [x16]
	b	LBB1_16
LBB1_65:                                ; %direct.schedule.8.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	add	x12, x10, x14
	b	LBB1_67
LBB1_66:                                ; %else162
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x13, x25, x11
	stp	q10, q2, [x13]
	add	x11, x11, #32
	cmp	x11, #256
	b.eq	LBB1_83
LBB1_67:                                ; %direct.true40.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [sp, #336]                  ; 16-byte Reload
	and.16b	v2, v9, v2
	addv.8h	h14, v2
	fmov	w14, s14
	add	x13, x12, x11
	add	x15, x25, x11
	ldr	q10, [x15]
	tbz	w14, #0, LBB1_75
; %bb.68:                               ; %cond.load140
                                        ;   in Loop: Header=BB1_67 Depth=2
	ld1.s	{ v10 }[0], [x13]
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_76
LBB1_69:                                ; %else144
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #2, LBB1_77
LBB1_70:                                ; %cond.load146
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #8
	ld1.s	{ v10 }[2], [x16]
	tbnz	w14, #3, LBB1_78
LBB1_71:                                ; %else150
                                        ;   in Loop: Header=BB1_67 Depth=2
	ldr	q2, [x15, #16]
	tbz	w14, #4, LBB1_79
LBB1_72:                                ; %cond.load152
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #16
	ld1.s	{ v2 }[0], [x15]
	tbnz	w14, #5, LBB1_80
LBB1_73:                                ; %else156
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #6, LBB1_81
LBB1_74:                                ; %cond.load158
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #24
	ld1.s	{ v2 }[2], [x15]
	tbz	w14, #7, LBB1_66
	b	LBB1_82
LBB1_75:                                ; %else141
                                        ;   in Loop: Header=BB1_67 Depth=2
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_69
LBB1_76:                                ; %cond.load143
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #4
	ld1.s	{ v10 }[1], [x16]
	tbnz	w14, #2, LBB1_70
LBB1_77:                                ; %else147
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #3, LBB1_71
LBB1_78:                                ; %cond.load149
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #12
	ld1.s	{ v10 }[3], [x16]
	ldr	q2, [x15, #16]
	tbnz	w14, #4, LBB1_72
LBB1_79:                                ; %else153
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #5, LBB1_73
LBB1_80:                                ; %cond.load155
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #20
	ld1.s	{ v2 }[1], [x15]
	tbnz	w14, #6, LBB1_74
LBB1_81:                                ; %else159
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #7, LBB1_66
LBB1_82:                                ; %cond.load161
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x13, x13, #28
	ld1.s	{ v2 }[3], [x13]
	b	LBB1_66
LBB1_83:                                ; %direct.false41.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v2, v9
	sshll.2d	v3, v23, #0
	sshll.2d	v4, v17, #0
	movi.8b	v7, #1
	and.8b	v20, v2, v7
	umov.b	w13, v20[0]
	movi.2d	v7, #0000000000000000
	mov.b	v7[0], v2[0]
	str	q7, [sp, #176]                  ; 16-byte Spill
	umaxv.8b	b20, v7
	fmov	w15, s20
	rbit	w11, w13
	clz	w11, w11
	tst	w15, #0x1
	mov	w12, #64                        ; =0x40
	dup.2d	v10, x12
	fmov	x12, d24
	add	x12, x12, x12, lsl #6
	fmov	d9, x12
	mov.d	x12, v24[1]
	add	x12, x12, x12, lsl #6
	mov.d	v9[1], x12
	csel	w11, w11, wzr, ne
	add.2d	v20, v9, v19
	add.2d	v7, v20, v10
	movi.2d	v20, #0000000000000000
	mov.b	v20[0], v2[0]
	ushll.2d	v2, v20, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	str	q7, [sp, #80]                   ; 16-byte Spill
	and.16b	v2, v2, v7
	movi.2d	v7, #0000000000000000
	stp	q7, q7, [sp, #880]
	stp	q2, q7, [sp, #848]
	ubfiz	x16, x11, #3, #3
	add	x12, sp, #848
	ldr	x12, [x12, x16]
	sub	x12, x12, x11
	lsl	x12, x12, #2
	add	x14, x10, x12
Lloh14:
	adrp	x10, lCPI1_7@PAGE
Lloh15:
	ldr	q2, [x10, lCPI1_7@PAGEOFF]
	mov	w10, #256                       ; =0x100
	dup.2d	v20, x10
	bif.16b	v2, v20, v4
Lloh16:
	adrp	x10, lCPI1_8@PAGE
Lloh17:
	ldr	q4, [x10, lCPI1_8@PAGEOFF]
	bsl.16b	v3, v4, v20
Lloh18:
	adrp	x10, lCPI1_9@PAGE
Lloh19:
	ldr	q4, [x10, lCPI1_9@PAGEOFF]
	bif.16b	v4, v20, v12
Lloh20:
	adrp	x10, lCPI1_10@PAGE
Lloh21:
	ldr	q25, [x10, lCPI1_10@PAGEOFF]
	bit.16b	v20, v25, v31
	stp	q3, q20, [sp, #944]
	stp	q2, q4, [sp, #912]
	add	x10, sp, #912
	ldr	x10, [x10, x16]
	sub	x10, x10, w11, uxtw #2
	tst	w13, #0x1
	csel	x10, xzr, x10, eq
	add	x16, x25, x10
	ldp	q19, q7, [x16]
	tbz	w15, #0, LBB1_91
; %bb.84:                               ; %cond.load165
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v19 }[0], [x14]
	tbnz	w13, #1, LBB1_92
LBB1_85:                                ; %else169
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_93
LBB1_86:                                ; %cond.load171
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #8
	ld1.s	{ v19 }[2], [x15]
	tbnz	w13, #3, LBB1_94
LBB1_87:                                ; %else175
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_95
LBB1_88:                                ; %cond.load177
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #16
	ld1.s	{ v7 }[0], [x15]
	tbnz	w13, #5, LBB1_96
LBB1_89:                                ; %else181
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_97
LBB1_90:                                ; %cond.load183
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #24
	ld1.s	{ v7 }[2], [x15]
	str	q16, [sp, #416]                 ; 16-byte Spill
	str	q5, [sp, #352]                  ; 16-byte Spill
	tbnz	w13, #7, LBB1_98
	b	LBB1_99
LBB1_91:                                ; %else166
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #1, LBB1_85
LBB1_92:                                ; %cond.load168
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #4
	ld1.s	{ v19 }[1], [x15]
	tbnz	w13, #2, LBB1_86
LBB1_93:                                ; %else172
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_87
LBB1_94:                                ; %cond.load174
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #12
	ld1.s	{ v19 }[3], [x15]
	tbnz	w13, #4, LBB1_88
LBB1_95:                                ; %else178
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #5, LBB1_89
LBB1_96:                                ; %cond.load180
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #20
	ld1.s	{ v7 }[1], [x15]
	tbnz	w13, #6, LBB1_90
LBB1_97:                                ; %else184
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q16, [sp, #416]                 ; 16-byte Spill
	str	q5, [sp, #352]                  ; 16-byte Spill
	tbz	w13, #7, LBB1_99
LBB1_98:                                ; %cond.load186
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x14, #28
	ld1.s	{ v7 }[3], [x13]
LBB1_99:                                ; %else187
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x15, #0                         ; =0x0
	movi.2s	v2, #65
	ldr	q3, [sp, #256]                  ; 16-byte Reload
	ldr	d4, [sp, #192]                  ; 8-byte Reload
	umlal.2d	v3, v4, v2
	add.2d	v5, v3, v10
	ldr	q3, [sp, #368]                  ; 16-byte Reload
	ldr	d4, [sp, #208]                  ; 8-byte Reload
	umlal.2d	v3, v4, v2
	add.2d	v3, v3, v10
	stp	q5, q3, [sp, #192]              ; 32-byte Folded Spill
	ldr	q3, [sp, #400]                  ; 16-byte Reload
	ldr	d4, [sp, #224]                  ; 8-byte Reload
	umlal.2d	v3, v4, v2
	add.2d	v2, v3, v10
	str	q2, [sp, #224]                  ; 16-byte Spill
	add	x13, x25, x10
	stp	q19, q7, [x13]
	fmov	x13, d9
	mov	w14, #1                         ; =0x1
	dup.2d	v2, x14
	lsl	x13, x13, #2
	add	x14, x9, x13
	ushll2.2d	v3, v23, #0
	and.16b	v20, v3, v2
	ushll2.2d	v3, v17, #0
	and.16b	v5, v3, v2
	ushll.2d	v3, v23, #0
	and.16b	v12, v3, v2
	ushll.2d	v3, v17, #0
	and.16b	v17, v3, v2
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v15, #0000000000000000
	b	LBB1_101
LBB1_100:                               ; %else212
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x15, x24, x15
	stp	q2, q3, [x15]
	add.2d	v9, v9, v5
	add.2d	v13, v13, v12
	add.2d	v15, v15, v20
	add.2d	v8, v8, v17
	fmov	x15, d8
	cmp	x15, #8
	b.ge	LBB1_117
LBB1_101:                               ; %direct.true62.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w17, s14
	lsl	x15, x15, #5
	add	x16, x14, x15
	add	x0, x24, x15
	ldp	q2, q3, [x0]
	tbz	w17, #0, LBB1_109
; %bb.102:                              ; %cond.load190
                                        ;   in Loop: Header=BB1_101 Depth=2
	ld1.s	{ v2 }[0], [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_110
LBB1_103:                               ; %else194
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #2, LBB1_111
LBB1_104:                               ; %cond.load196
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #8
	ld1.s	{ v2 }[2], [x0]
	tbnz	w17, #3, LBB1_112
LBB1_105:                               ; %else200
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #4, LBB1_113
LBB1_106:                               ; %cond.load202
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #16
	ld1.s	{ v3 }[0], [x0]
	tbnz	w17, #5, LBB1_114
LBB1_107:                               ; %else206
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #6, LBB1_115
LBB1_108:                               ; %cond.load208
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #24
	ld1.s	{ v3 }[2], [x0]
	tbz	w17, #7, LBB1_100
	b	LBB1_116
LBB1_109:                               ; %else191
                                        ;   in Loop: Header=BB1_101 Depth=2
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_103
LBB1_110:                               ; %cond.load193
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #4
	ld1.s	{ v2 }[1], [x0]
	tbnz	w17, #2, LBB1_104
LBB1_111:                               ; %else197
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #3, LBB1_105
LBB1_112:                               ; %cond.load199
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #12
	ld1.s	{ v2 }[3], [x0]
	tbnz	w17, #4, LBB1_106
LBB1_113:                               ; %else203
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #5, LBB1_107
LBB1_114:                               ; %cond.load205
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #20
	ld1.s	{ v3 }[1], [x0]
	tbnz	w17, #6, LBB1_108
LBB1_115:                               ; %else209
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #7, LBB1_100
LBB1_116:                               ; %cond.load211
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x16, x16, #28
	ld1.s	{ v3 }[3], [x16]
	b	LBB1_100
LBB1_117:                               ; %direct.false63.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, x12
	add	x12, x24, x10
	ldp	q24, q4, [x12]
Lloh22:
	adrp	x12, lCPI1_11@PAGE
Lloh23:
	ldr	d2, [x12, lCPI1_11@PAGEOFF]
	ldr	q3, [sp, #176]                  ; 16-byte Reload
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	and.8b	v2, v3, v2
	addv.8b	b2, v2
	str	d2, [sp, #24]                   ; 8-byte Spill
	fmov	w12, s2
	tbz	w12, #0, LBB1_145
; %bb.118:                              ; %cond.load215
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v24 }[0], [x9]
	tbnz	w12, #1, LBB1_146
LBB1_119:                               ; %else219
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #2, LBB1_147
LBB1_120:                               ; %cond.load221
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #8
	ld1.s	{ v24 }[2], [x14]
	tbnz	w12, #3, LBB1_148
LBB1_121:                               ; %else225
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #4, LBB1_149
LBB1_122:                               ; %cond.load227
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #16
	ld1.s	{ v4 }[0], [x14]
	mov.16b	v2, v23
	tbnz	w12, #5, LBB1_150
LBB1_123:                               ; %else231
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.16b	v23, v1
	tbz	w12, #6, LBB1_125
LBB1_124:                               ; %cond.load233
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #24
	ld1.s	{ v4 }[2], [x14]
LBB1_125:                               ; %else234
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.16b	v31, v6
	stp	q30, q21, [sp, #368]            ; 32-byte Folded Spill
	str	q22, [sp, #400]                 ; 16-byte Spill
	mov.16b	v1, v2
	str	q19, [sp, #64]                  ; 16-byte Spill
	mov.16b	v6, v18
	tbz	w12, #7, LBB1_127
; %bb.126:                              ; %cond.load236
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v4 }[3], [x9]
LBB1_127:                               ; %else237
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q7, [sp, #256]                  ; 16-byte Spill
	mov	x12, #0                         ; =0x0
	add	x9, x24, x10
	stp	q24, q4, [sp, #32]              ; 32-byte Folded Spill
	stp	q24, q4, [x9]
	add	x9, x8, x13
	movi.2d	v14, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	b	LBB1_129
LBB1_128:                               ; %else255
                                        ;   in Loop: Header=BB1_129 Depth=2
	add.2d	v13, v13, v5
	add.2d	v8, v8, v12
	add.2d	v9, v9, v20
	add.2d	v14, v14, v17
	fmov	x12, d14
	cmp	x12, #8
	b.ge	LBB1_151
LBB1_129:                               ; %direct.true83.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v30, v17
	mov.16b	v16, v5
	mov.16b	v5, v20
	ldp	q3, q2, [sp, #304]              ; 32-byte Folded Reload
	cmhi.4s	v2, v3, v2
	lsl	x10, x12, #5
	add	x12, x25, x10
	ldr	q3, [x12]
	and.16b	v3, v2, v3
	ldp	q4, q7, [sp, #480]              ; 32-byte Folded Reload
	fmul.4s	v4, v3, v4
	fmul.4s	v4, v3, v4
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v3, v4
	fmul.4s	v4, v4, v7
	and.16b	v15, v2, v4
	fabs.4s	v4, v15
	fmul.4s	v20, v15, v15
	ldp	q7, q25, [sp, #512]             ; 32-byte Folded Reload
	fmla.4s	v25, v20, v7
	ldp	q26, q7, [sp, #544]             ; 32-byte Folded Reload
	fmla.4s	v26, v20, v25
	ldr	q25, [sp, #576]                 ; 16-byte Reload
	fmla.4s	v25, v20, v26
	ldr	q26, [sp, #352]                 ; 16-byte Reload
	fmla.4s	v26, v20, v25
	mov.16b	v25, v23
	fmla.4s	v25, v20, v26
	fmov.4s	v26, #1.00000000
	fmla.4s	v26, v20, v25
	fmul.4s	v25, v4, v26
	ldr	q26, [sp, #592]                 ; 16-byte Reload
	fmla.4s	v26, v20, v7
	ldr	q7, [sp, #608]                  ; 16-byte Reload
	fmla.4s	v7, v20, v26
	mov.16b	v26, v31
	fmla.4s	v26, v20, v7
	ldr	q7, [sp, #368]                  ; 16-byte Reload
	fmla.4s	v7, v20, v26
	movi.4s	v26, #63, lsl #24
	fmla.4s	v26, v20, v7
	fmov.4s	v7, #1.00000000
	fmla.4s	v7, v20, v26
	fdiv.4s	v7, v25, v7
	fmov.4s	v17, #9.00000000
	fcmge.4s	v20, v17, v4
	and.16b	v25, v20, v4
	fcmge.4s	v26, v25, v6
	fcmge.4s	v17, v0, v25
	and.16b	v17, v26, v17
	and.16b	v17, v17, v25
	ldp	q19, q18, [sp, #400]            ; 32-byte Folded Reload
	fmul.4s	v26, v17, v18
	movi.4s	v24, #75, lsl #24
	fadd.4s	v26, v26, v24
	movi.4s	v24, #203, lsl #24
	fadd.4s	v26, v26, v24
	fcvtzs.4s	v26, v26
	scvtf.4s	v24, v26
	mov.16b	v18, v27
	fmul.4s	v27, v24, v27
	fadd.4s	v17, v17, v27
	fmul.4s	v24, v24, v19
	fadd.4s	v17, v17, v24
	ldr	q19, [sp, #384]                 ; 16-byte Reload
	fmul.4s	v24, v17, v19
	ldr	q19, [sp, #464]                 ; 16-byte Reload
	fadd.4s	v24, v24, v19
	fmul.4s	v24, v17, v24
	mov.16b	v19, v29
	fadd.4s	v24, v24, v29
	fmul.4s	v24, v17, v24
	mov.16b	v21, v28
	fadd.4s	v24, v24, v28
	fmul.4s	v24, v17, v24
	fadd.4s	v24, v24, v23
	fmul.4s	v24, v17, v24
	movi.4s	v28, #63, lsl #24
	fadd.4s	v24, v24, v28
	fmul.4s	v27, v17, v17
	fmul.4s	v24, v27, v24
	fadd.4s	v17, v17, v24
	fmov.4s	v29, #1.00000000
	fadd.4s	v17, v17, v29
	movi.2d	v24, #0xffffffffffffffff
	add.4s	v24, v26, v24
	sshr.4s	v26, v24, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v29
	fmul.4s	v17, v17, v27
	sub.4s	v24, v24, v26
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v29
	fmul.4s	v17, v17, v24
	fcmgt.4s	v24, v25, v0
	ldr	q25, [sp, #448]                 ; 16-byte Reload
	bit.16b	v17, v25, v24
	fmov.4s	v24, #0.25000000
	fdiv.4s	v24, v24, v17
	fsub.4s	v25, v17, v24
	fadd.4s	v17, v17, v24
	fdiv.4s	v17, v25, v17
	bif.16b	v17, v29, v20
	fcmge.4s	v4, v29, v4
	bsl.16b	v4, v7, v17
	uzp1.8h	v7, v2, v1
	ldr	q17, [sp, #336]                 ; 16-byte Reload
	and.16b	v7, v7, v17
	addv.8h	h7, v7
	fmov	w13, s7
	mvni.4s	v7, #128, lsl #24
	bif.16b	v4, v15, v7
	fcmeq.4s	v7, v15, v15
	fadd.4s	v4, v4, v29
	ldr	q17, [sp, #432]                 ; 16-byte Reload
	bif.16b	v4, v17, v7
	fmul.4s	v3, v3, v28
	fmul.4s	v3, v3, v4
	add	x14, x24, x10
	ldp	q4, q15, [x14]
	and.16b	v4, v2, v4
	ldr	q2, [x12, #16]
	fadd.4s	v3, v4, v3
	add	x10, x9, x10
	tbz	w13, #0, LBB1_133
; %bb.130:                              ; %cond.store240
                                        ;   in Loop: Header=BB1_129 Depth=2
	str	s3, [x10]
	and	w12, w13, #0xff
	tbnz	w12, #1, LBB1_134
LBB1_131:                               ; %else243
                                        ;   in Loop: Header=BB1_129 Depth=2
	mov.16b	v28, v21
	mov.16b	v29, v19
	mov.16b	v27, v18
	tbz	w12, #2, LBB1_135
LBB1_132:                               ; %cond.store244
                                        ;   in Loop: Header=BB1_129 Depth=2
	add	x13, x10, #8
	st1.s	{ v3 }[2], [x13]
	mov.16b	v22, v0
	tbnz	w12, #3, LBB1_136
	b	LBB1_137
LBB1_133:                               ; %else241
                                        ;   in Loop: Header=BB1_129 Depth=2
	and	w12, w13, #0xff
	tbz	w12, #1, LBB1_131
LBB1_134:                               ; %cond.store242
                                        ;   in Loop: Header=BB1_129 Depth=2
	add	x13, x10, #4
	st1.s	{ v3 }[1], [x13]
	mov.16b	v28, v21
	mov.16b	v29, v19
	mov.16b	v27, v18
	tbnz	w12, #2, LBB1_132
LBB1_135:                               ; %else245
                                        ;   in Loop: Header=BB1_129 Depth=2
	mov.16b	v22, v0
	tbz	w12, #3, LBB1_137
LBB1_136:                               ; %cond.store246
                                        ;   in Loop: Header=BB1_129 Depth=2
	add	x13, x10, #12
	st1.s	{ v3 }[3], [x13]
LBB1_137:                               ; %else247
                                        ;   in Loop: Header=BB1_129 Depth=2
	and.16b	v2, v1, v2
	ldp	q3, q4, [sp, #480]              ; 32-byte Folded Reload
	fmul.4s	v3, v2, v3
	fmul.4s	v3, v2, v3
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v2, v3
	fmul.4s	v3, v3, v4
	and.16b	v3, v1, v3
	fabs.4s	v4, v3
	fmul.4s	v7, v3, v3
	ldp	q20, q17, [sp, #512]            ; 32-byte Folded Reload
	fmla.4s	v17, v7, v20
	ldp	q20, q24, [sp, #544]            ; 32-byte Folded Reload
	fmla.4s	v20, v7, v17
	ldr	q17, [sp, #576]                 ; 16-byte Reload
	fmla.4s	v17, v7, v20
	ldr	q20, [sp, #352]                 ; 16-byte Reload
	fmla.4s	v20, v7, v17
	mov.16b	v17, v23
	fmla.4s	v17, v7, v20
	fmov.4s	v20, #1.00000000
	fmla.4s	v20, v7, v17
	fmul.4s	v17, v4, v20
	ldr	q20, [sp, #592]                 ; 16-byte Reload
	fmla.4s	v20, v7, v24
	ldr	q24, [sp, #608]                 ; 16-byte Reload
	fmla.4s	v24, v7, v20
	mov.16b	v20, v31
	fmla.4s	v20, v7, v24
	ldr	q24, [sp, #368]                 ; 16-byte Reload
	fmla.4s	v24, v7, v20
	movi.4s	v20, #63, lsl #24
	fmla.4s	v20, v7, v24
	fmov.4s	v24, #1.00000000
	fmla.4s	v24, v7, v20
	fdiv.4s	v7, v17, v24
	fmov.4s	v17, #9.00000000
	fcmge.4s	v17, v17, v4
	and.16b	v20, v17, v4
	fcmge.4s	v24, v20, v6
	fcmge.4s	v25, v22, v20
	and.16b	v24, v24, v25
	and.16b	v24, v24, v20
	ldr	q25, [sp, #416]                 ; 16-byte Reload
	fmul.4s	v25, v24, v25
	movi.4s	v26, #75, lsl #24
	fadd.4s	v25, v25, v26
	movi.4s	v26, #203, lsl #24
	fadd.4s	v25, v25, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v27
	fadd.4s	v24, v24, v27
	ldr	q27, [sp, #400]                 ; 16-byte Reload
	fmul.4s	v26, v26, v27
	fadd.4s	v24, v24, v26
	ldr	q26, [sp, #384]                 ; 16-byte Reload
	fmul.4s	v26, v24, v26
	ldr	q27, [sp, #464]                 ; 16-byte Reload
	fadd.4s	v26, v26, v27
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v29
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v28
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v23
	fmul.4s	v26, v24, v26
	movi.4s	v28, #63, lsl #24
	fadd.4s	v26, v26, v28
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fmov.4s	v29, #1.00000000
	fadd.4s	v24, v24, v29
	movi.2d	v26, #0xffffffffffffffff
	add.4s	v25, v25, v26
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v29
	fmul.4s	v24, v24, v27
	sub.4s	v25, v25, v26
	shl.4s	v25, v25, #23
	add.4s	v25, v25, v29
	fmul.4s	v24, v24, v25
	fcmgt.4s	v20, v20, v22
	ldr	q25, [sp, #448]                 ; 16-byte Reload
	bsl.16b	v20, v25, v24
	fmov.4s	v24, #0.25000000
	fdiv.4s	v24, v24, v20
	fsub.4s	v25, v20, v24
	fadd.4s	v20, v20, v24
	fdiv.4s	v20, v25, v20
	bsl.16b	v17, v20, v29
	fcmge.4s	v4, v29, v4
	bsl.16b	v4, v7, v17
	mvni.4s	v7, #128, lsl #24
	bif.16b	v4, v3, v7
	fcmeq.4s	v3, v3, v3
	fadd.4s	v4, v4, v29
	ldr	q7, [sp, #432]                  ; 16-byte Reload
	bsl.16b	v3, v4, v7
	fmul.4s	v2, v2, v28
	fmul.4s	v2, v2, v3
	and.16b	v3, v1, v15
	fadd.4s	v2, v3, v2
	tbz	w12, #4, LBB1_141
; %bb.138:                              ; %cond.store248
                                        ;   in Loop: Header=BB1_129 Depth=2
	str	s2, [x10, #16]
	mov.16b	v20, v5
	mov.16b	v17, v30
	tbnz	w12, #5, LBB1_142
LBB1_139:                               ; %else251
                                        ;   in Loop: Header=BB1_129 Depth=2
	mov.16b	v28, v21
	mov.16b	v29, v19
	mov.16b	v27, v18
	mov.16b	v5, v16
	mov.16b	v0, v22
	tbz	w12, #6, LBB1_143
LBB1_140:                               ; %cond.store252
                                        ;   in Loop: Header=BB1_129 Depth=2
	add	x13, x10, #24
	st1.s	{ v2 }[2], [x13]
	tbz	w12, #7, LBB1_128
	b	LBB1_144
LBB1_141:                               ; %else249
                                        ;   in Loop: Header=BB1_129 Depth=2
	mov.16b	v20, v5
	mov.16b	v17, v30
	tbz	w12, #5, LBB1_139
LBB1_142:                               ; %cond.store250
                                        ;   in Loop: Header=BB1_129 Depth=2
	add	x13, x10, #20
	st1.s	{ v2 }[1], [x13]
	mov.16b	v28, v21
	mov.16b	v29, v19
	mov.16b	v27, v18
	mov.16b	v5, v16
	mov.16b	v0, v22
	tbnz	w12, #6, LBB1_140
LBB1_143:                               ; %else253
                                        ;   in Loop: Header=BB1_129 Depth=2
	tbz	w12, #7, LBB1_128
LBB1_144:                               ; %cond.store254
                                        ;   in Loop: Header=BB1_129 Depth=2
	add	x10, x10, #28
	st1.s	{ v2 }[3], [x10]
	b	LBB1_128
LBB1_145:                               ; %else216
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #1, LBB1_119
LBB1_146:                               ; %cond.load218
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #4
	ld1.s	{ v24 }[1], [x14]
	tbnz	w12, #2, LBB1_120
LBB1_147:                               ; %else222
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #3, LBB1_121
LBB1_148:                               ; %cond.load224
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #12
	ld1.s	{ v24 }[3], [x14]
	tbnz	w12, #4, LBB1_122
LBB1_149:                               ; %else228
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.16b	v2, v23
	tbz	w12, #5, LBB1_123
LBB1_150:                               ; %cond.load230
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #20
	ld1.s	{ v4 }[1], [x14]
	mov.16b	v23, v1
	tbnz	w12, #6, LBB1_124
	b	LBB1_125
LBB1_151:                               ; %direct.false84.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q2, [sp, #176]                  ; 16-byte Reload
	zip1.8b	v2, v2, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #64]                   ; 16-byte Reload
	and.16b	v3, v2, v3
	ldp	q4, q5, [sp, #480]              ; 32-byte Folded Reload
	fmul.4s	v4, v3, v4
	fmul.4s	v4, v3, v4
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v3, v4
	fmul.4s	v4, v4, v5
	and.16b	v30, v2, v4
	fabs.4s	v4, v30
	fmul.4s	v7, v30, v30
	ldp	q5, q17, [sp, #512]             ; 32-byte Folded Reload
	fmla.4s	v17, v7, v5
	ldp	q20, q16, [sp, #544]            ; 32-byte Folded Reload
	fmla.4s	v20, v7, v17
	ldr	q17, [sp, #576]                 ; 16-byte Reload
	fmla.4s	v17, v7, v20
	ldr	q5, [sp, #352]                  ; 16-byte Reload
	mov.16b	v20, v5
	fmla.4s	v20, v7, v17
	mov.16b	v17, v23
	fmla.4s	v17, v7, v20
	fmov.4s	v20, #1.00000000
	fmla.4s	v20, v7, v17
	fmul.4s	v17, v4, v20
	ldp	q20, q24, [sp, #592]            ; 32-byte Folded Reload
	fmla.4s	v20, v7, v16
	fmla.4s	v24, v7, v20
	mov.16b	v20, v31
	fmla.4s	v20, v7, v24
	ldr	q24, [sp, #368]                 ; 16-byte Reload
	fmla.4s	v24, v7, v20
	movi.4s	v20, #63, lsl #24
	fmla.4s	v20, v7, v24
	fmov.4s	v24, #1.00000000
	fmla.4s	v24, v7, v20
	fdiv.4s	v7, v17, v24
	fmov.4s	v17, #9.00000000
	fcmge.4s	v17, v17, v4
	and.16b	v20, v17, v4
	fcmge.4s	v24, v20, v6
	fcmge.4s	v25, v0, v20
	and.16b	v24, v24, v25
	and.16b	v24, v24, v20
	ldp	q1, q16, [sp, #400]             ; 32-byte Folded Reload
	fmul.4s	v25, v24, v16
	movi.4s	v26, #75, lsl #24
	fadd.4s	v25, v25, v26
	movi.4s	v26, #203, lsl #24
	fadd.4s	v25, v25, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v27
	fadd.4s	v24, v24, v27
	fmul.4s	v26, v26, v1
	fadd.4s	v24, v24, v26
	ldr	q1, [sp, #384]                  ; 16-byte Reload
	fmul.4s	v26, v24, v1
	ldr	q1, [sp, #464]                  ; 16-byte Reload
	fadd.4s	v26, v26, v1
	mov.16b	v1, v23
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v29
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v28
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v23
	fmul.4s	v26, v24, v26
	movi.4s	v28, #63, lsl #24
	fadd.4s	v26, v26, v28
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fmov.4s	v29, #1.00000000
	fadd.4s	v24, v24, v29
	movi.2d	v26, #0xffffffffffffffff
	add.4s	v25, v25, v26
	sshr.4s	v26, v25, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v29
	fmul.4s	v24, v24, v27
	sub.4s	v25, v25, v26
	shl.4s	v25, v25, #23
	add.4s	v25, v25, v29
	fmul.4s	v24, v24, v25
	fcmgt.4s	v20, v20, v0
	ldr	q25, [sp, #448]                 ; 16-byte Reload
	bsl.16b	v20, v25, v24
	fmov.4s	v24, #0.25000000
	fdiv.4s	v24, v24, v20
	fsub.4s	v25, v20, v24
	fadd.4s	v20, v20, v24
	fdiv.4s	v20, v25, v20
	bsl.16b	v17, v20, v29
	fcmge.4s	v4, v29, v4
	bsl.16b	v4, v7, v17
	ldr	d7, [sp, #24]                   ; 8-byte Reload
	fmov	w9, s7
	mvni.4s	v7, #128, lsl #24
	bif.16b	v4, v30, v7
	fcmeq.4s	v7, v30, v30
	fadd.4s	v4, v4, v29
	ldr	q17, [sp, #432]                 ; 16-byte Reload
	bif.16b	v4, v17, v7
	fmul.4s	v3, v3, v28
	fmul.4s	v3, v3, v4
	ldr	q4, [sp, #32]                   ; 16-byte Reload
	and.16b	v2, v2, v4
	fadd.4s	v2, v3, v2
	ldr	q4, [sp, #80]                   ; 16-byte Reload
	ldp	q7, q3, [sp, #192]              ; 32-byte Folded Reload
	stp	q4, q7, [sp, #768]
	str	q3, [sp, #800]
	ldr	q3, [sp, #224]                  ; 16-byte Reload
	str	q3, [sp, #816]
	and	x10, x11, #0x7
	add	x12, sp, #768
	ldr	x10, [x12, x10, lsl #3]
	sub	x10, x10, x11
	add	x8, x8, x10, lsl #2
	tbz	w9, #0, LBB1_155
; %bb.152:                              ; %cond.store257
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s2, [x8]
	ldr	q3, [sp, #256]                  ; 16-byte Reload
	tbnz	w9, #1, LBB1_156
LBB1_153:                               ; %else260
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.16b	v20, v19
	mov.16b	v19, v18
	tbz	w9, #2, LBB1_157
LBB1_154:                               ; %cond.store261
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #8
	st1.s	{ v2 }[2], [x10]
	mov.16b	v17, v6
	tbnz	w9, #3, LBB1_158
	b	LBB1_159
LBB1_155:                               ; %else258
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q3, [sp, #256]                  ; 16-byte Reload
	tbz	w9, #1, LBB1_153
LBB1_156:                               ; %cond.store259
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #4
	st1.s	{ v2 }[1], [x10]
	mov.16b	v20, v19
	mov.16b	v19, v18
	tbnz	w9, #2, LBB1_154
LBB1_157:                               ; %else262
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.16b	v17, v6
	tbz	w9, #3, LBB1_159
LBB1_158:                               ; %cond.store263
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #12
	st1.s	{ v2 }[3], [x10]
LBB1_159:                               ; %else264
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q2, [sp, #176]                  ; 16-byte Reload
	zip2.8b	v2, v2, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v3, v2, v3
	ldp	q4, q6, [sp, #480]              ; 32-byte Folded Reload
	fmul.4s	v4, v3, v4
	fmul.4s	v4, v3, v4
	fmul.4s	v4, v3, v4
	fadd.4s	v4, v3, v4
	fmul.4s	v4, v4, v6
	and.16b	v28, v2, v4
	fmul.4s	v4, v28, v28
	ldp	q7, q6, [sp, #512]              ; 32-byte Folded Reload
	fmla.4s	v6, v4, v7
	ldr	q7, [sp, #544]                  ; 16-byte Reload
	fmla.4s	v7, v4, v6
	ldr	q6, [sp, #576]                  ; 16-byte Reload
	fmla.4s	v6, v4, v7
	fmla.4s	v5, v4, v6
	mov.16b	v6, v5
	mov.16b	v5, v1
	fmla.4s	v5, v4, v6
	fmov.4s	v6, #1.00000000
	fmla.4s	v6, v4, v5
	ldr	q7, [sp, #592]                  ; 16-byte Reload
	ldr	q5, [sp, #560]                  ; 16-byte Reload
	fmla.4s	v7, v4, v5
	ldr	q5, [sp, #608]                  ; 16-byte Reload
	fmla.4s	v5, v4, v7
	fmla.4s	v31, v4, v5
	fabs.4s	v5, v28
	fmul.4s	v6, v5, v6
	ldr	q23, [sp, #368]                 ; 16-byte Reload
	fmla.4s	v23, v4, v31
	movi.4s	v7, #63, lsl #24
	fmla.4s	v7, v4, v23
	fmov.4s	v16, #1.00000000
	fmla.4s	v16, v4, v7
	fdiv.4s	v4, v6, v16
	fmov.4s	v6, #9.00000000
	fcmge.4s	v6, v6, v5
	and.16b	v7, v6, v5
	fcmge.4s	v16, v7, v17
	fcmge.4s	v17, v0, v7
	and.16b	v16, v16, v17
	and.16b	v16, v16, v7
	ldr	q17, [sp, #416]                 ; 16-byte Reload
	fmul.4s	v17, v16, v17
	movi.4s	v18, #75, lsl #24
	fadd.4s	v17, v17, v18
	movi.4s	v18, #203, lsl #24
	fadd.4s	v17, v17, v18
	fcvtzs.4s	v17, v17
	scvtf.4s	v18, v17
	fmul.4s	v19, v18, v19
	fadd.4s	v16, v16, v19
	mov.16b	v19, v1
	ldr	q1, [sp, #400]                  ; 16-byte Reload
	fmul.4s	v18, v18, v1
	fadd.4s	v16, v16, v18
	ldr	q1, [sp, #384]                  ; 16-byte Reload
	fmul.4s	v18, v16, v1
	ldr	q1, [sp, #464]                  ; 16-byte Reload
	fadd.4s	v18, v18, v1
	fmul.4s	v18, v16, v18
	fadd.4s	v18, v18, v20
	fmul.4s	v18, v16, v18
	fadd.4s	v18, v18, v21
	fmul.4s	v18, v16, v18
	fadd.4s	v1, v18, v19
	fmul.4s	v1, v16, v1
	movi.4s	v19, #63, lsl #24
	fadd.4s	v1, v1, v19
	fmul.4s	v18, v16, v16
	fmul.4s	v1, v18, v1
	fadd.4s	v1, v16, v1
	fmov.4s	v20, #1.00000000
	fadd.4s	v1, v1, v20
	movi.2d	v16, #0xffffffffffffffff
	add.4s	v16, v17, v16
	sshr.4s	v17, v16, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v20
	fmul.4s	v1, v1, v18
	sub.4s	v16, v16, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v20
	fmul.4s	v1, v1, v16
	fcmgt.4s	v0, v7, v0
	ldr	q7, [sp, #448]                  ; 16-byte Reload
	bsl.16b	v0, v7, v1
	fmov.4s	v1, #0.25000000
	fdiv.4s	v1, v1, v0
	fsub.4s	v7, v0, v1
	fadd.4s	v0, v0, v1
	fdiv.4s	v0, v7, v0
	bif.16b	v0, v20, v6
	fcmge.4s	v1, v20, v5
	bit.16b	v0, v4, v1
	mvni.4s	v1, #128, lsl #24
	bif.16b	v0, v28, v1
	fcmeq.4s	v1, v28, v28
	fadd.4s	v0, v0, v20
	ldr	q4, [sp, #432]                  ; 16-byte Reload
	bif.16b	v0, v4, v1
	fmul.4s	v1, v3, v19
	fmul.4s	v0, v1, v0
	ldr	q1, [sp, #48]                   ; 16-byte Reload
	and.16b	v1, v2, v1
	fadd.4s	v0, v0, v1
	tbz	w9, #4, LBB1_204
LBB1_160:                               ; %cond.store265
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x8, #16]
	tbnz	w9, #5, LBB1_205
LBB1_161:                               ; %else134
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #6, LBB1_206
LBB1_162:                               ; %cond.store135
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB1_207
	b	LBB1_2
LBB1_163:                               ; %direct.false21.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v2, v9
	movi.8b	v3, #1
	and.8b	v3, v2, v3
	umov.b	w12, v3[0]
	movi.2d	v8, #0000000000000000
	mov.b	v8[0], v2[0]
	umaxv.8b	b3, v8
	fmov	w14, s3
	rbit	w11, w12
	clz	w11, w11
	tst	w14, #0x1
	csel	w11, w11, wzr, ne
	mov	w13, #64                        ; =0x40
	dup.2d	v9, x13
	ldr	q4, [sp, #304]                  ; 16-byte Reload
	fmov	x13, d4
	add	x13, x13, x13, lsl #6
	fmov	d3, x13
	mov.d	x13, v4[1]
	add	x13, x13, x13, lsl #6
	mov.d	v3[1], x13
	ldr	q4, [sp, #416]                  ; 16-byte Reload
	add.2d	v3, v3, v4
	movi.2d	v4, #0000000000000000
	mov.b	v4[0], v2[0]
	add.2d	v19, v3, v9
	ushll.2d	v2, v4, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	and.16b	v2, v2, v19
	movi.2d	v3, #0000000000000000
	stp	q3, q3, [sp, #720]
	stp	q2, q3, [sp, #688]
	and	x13, x11, #0x7
	add	x15, sp, #688
	ldr	x13, [x15, x13, lsl #3]
	sub	x13, x13, x11
	lsl	x13, x13, #2
	add	x10, x10, x13
	movi.2d	v14, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbz	w14, #0, LBB1_171
; %bb.164:                              ; %cond.load73
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s14, [x10]
	tbnz	w12, #1, LBB1_172
LBB1_165:                               ; %else77
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #2, LBB1_173
LBB1_166:                               ; %cond.load79
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #8
	ld1.s	{ v14 }[2], [x14]
	tbnz	w12, #3, LBB1_174
LBB1_167:                               ; %else83
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #4, LBB1_175
LBB1_168:                               ; %cond.load85
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #16
	ld1.s	{ v23 }[0], [x14]
	tbnz	w12, #5, LBB1_176
LBB1_169:                               ; %else89
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #6, LBB1_177
LBB1_170:                               ; %cond.load91
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #24
	ld1.s	{ v23 }[2], [x14]
	tbnz	w12, #7, LBB1_178
	b	LBB1_179
LBB1_171:                               ; %else74
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #1, LBB1_165
LBB1_172:                               ; %cond.load76
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #4
	ld1.s	{ v14 }[1], [x14]
	tbnz	w12, #2, LBB1_166
LBB1_173:                               ; %else80
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #3, LBB1_167
LBB1_174:                               ; %cond.load82
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #12
	ld1.s	{ v14 }[3], [x14]
	tbnz	w12, #4, LBB1_168
LBB1_175:                               ; %else86
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #5, LBB1_169
LBB1_176:                               ; %cond.load88
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #20
	ld1.s	{ v23 }[1], [x14]
	tbnz	w12, #6, LBB1_170
LBB1_177:                               ; %else92
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #7, LBB1_179
LBB1_178:                               ; %cond.load94
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v23 }[3], [x10]
LBB1_179:                               ; %else95
                                        ;   in Loop: Header=BB1_4 Depth=1
Lloh24:
	adrp	x10, lCPI1_11@PAGE
Lloh25:
	ldr	d2, [x10, lCPI1_11@PAGEOFF]
	shl.8b	v3, v8, #7
	cmlt.8b	v3, v3, #0
	and.8b	v2, v3, v2
	addv.8b	b31, v2
	fmov	w10, s31
	add	x9, x9, x13
	movi.2d	v15, #0000000000000000
	movi.2d	v13, #0000000000000000
	tbz	w10, #0, LBB1_193
; %bb.180:                              ; %cond.load98
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s15, [x9]
	tbnz	w10, #1, LBB1_194
LBB1_181:                               ; %else102
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_195
LBB1_182:                               ; %cond.load104
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #8
	ld1.s	{ v15 }[2], [x12]
	tbnz	w10, #3, LBB1_196
LBB1_183:                               ; %else108
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #4, LBB1_197
LBB1_184:                               ; %cond.load110
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #16
	ld1.s	{ v13 }[0], [x12]
	tbnz	w10, #5, LBB1_198
LBB1_185:                               ; %else114
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_187
LBB1_186:                               ; %cond.load116
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #24
	ld1.s	{ v13 }[2], [x12]
LBB1_187:                               ; %else117
                                        ;   in Loop: Header=BB1_4 Depth=1
	movi.2s	v2, #65
	ldr	q3, [sp, #256]                  ; 16-byte Reload
	ldr	d4, [sp, #192]                  ; 8-byte Reload
	umlal.2d	v3, v4, v2
	str	q3, [sp, #256]                  ; 16-byte Spill
	ldr	q3, [sp, #368]                  ; 16-byte Reload
	ldr	d4, [sp, #208]                  ; 8-byte Reload
	umlal.2d	v3, v4, v2
	str	q3, [sp, #368]                  ; 16-byte Spill
	ldr	q3, [sp, #400]                  ; 16-byte Reload
	ldr	d4, [sp, #224]                  ; 8-byte Reload
	umlal.2d	v3, v4, v2
	str	q3, [sp, #400]                  ; 16-byte Spill
	tbz	w10, #7, LBB1_189
; %bb.188:                              ; %cond.load119
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v13 }[3], [x9]
LBB1_189:                               ; %else120
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldp	q2, q3, [sp, #480]              ; 32-byte Folded Reload
	fmul.4s	v2, v14, v2
	fmul.4s	v2, v14, v2
	fmul.4s	v2, v14, v2
	fadd.4s	v2, v14, v2
	fmul.4s	v2, v2, v3
	zip1.8b	v3, v8, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v2, v3, v2
	fabs.4s	v3, v2
	fmul.4s	v4, v2, v2
	ldp	q7, q20, [sp, #512]             ; 32-byte Folded Reload
	fmla.4s	v20, v4, v7
	ldp	q25, q7, [sp, #544]             ; 32-byte Folded Reload
	fmla.4s	v25, v4, v20
	ldr	q20, [sp, #576]                 ; 16-byte Reload
	fmla.4s	v20, v4, v25
	mov.16b	v25, v5
	fmla.4s	v25, v4, v20
	mov.16b	v20, v1
	fmla.4s	v20, v4, v25
	fmov.4s	v25, #1.00000000
	fmla.4s	v25, v4, v20
	fmul.4s	v20, v3, v25
	ldp	q25, q26, [sp, #592]            ; 32-byte Folded Reload
	fmla.4s	v25, v4, v7
	fmla.4s	v26, v4, v25
	mov.16b	v25, v6
	fmla.4s	v25, v4, v26
	mov.16b	v26, v30
	fmla.4s	v26, v4, v25
	movi.4s	v25, #63, lsl #24
	fmla.4s	v25, v4, v26
	fmov.4s	v26, #1.00000000
	fmla.4s	v26, v4, v25
	fdiv.4s	v4, v20, v26
	fmov.4s	v7, #9.00000000
	fcmge.4s	v20, v7, v3
	and.16b	v25, v20, v3
	fcmge.4s	v26, v25, v18
	fcmge.4s	v10, v0, v25
	and.16b	v26, v26, v10
	and.16b	v26, v26, v25
	fmul.4s	v10, v26, v16
	movi.4s	v7, #75, lsl #24
	fadd.4s	v10, v10, v7
	movi.4s	v7, #203, lsl #24
	fadd.4s	v10, v10, v7
	fcvtzs.4s	v10, v10
	scvtf.4s	v11, v10
	fmul.4s	v12, v11, v27
	fadd.4s	v26, v26, v12
	fmul.4s	v11, v11, v22
	fadd.4s	v26, v26, v11
	fmul.4s	v11, v26, v21
	ldr	q7, [sp, #464]                  ; 16-byte Reload
	fadd.4s	v11, v11, v7
	fmul.4s	v11, v26, v11
	fadd.4s	v11, v11, v29
	fmul.4s	v11, v26, v11
	fadd.4s	v11, v11, v28
	fmul.4s	v11, v26, v11
	fadd.4s	v11, v11, v1
	fmul.4s	v11, v26, v11
	movi.4s	v7, #63, lsl #24
	fadd.4s	v11, v11, v7
	fmul.4s	v12, v26, v26
	fmul.4s	v11, v12, v11
	fadd.4s	v26, v26, v11
	fmov.4s	v17, #1.00000000
	fadd.4s	v26, v26, v17
	movi.2d	v24, #0xffffffffffffffff
	add.4s	v10, v10, v24
	sshr.4s	v11, v10, #1
	shl.4s	v12, v11, #23
	add.4s	v12, v12, v17
	fmul.4s	v26, v26, v12
	sub.4s	v10, v10, v11
	shl.4s	v10, v10, #23
	add.4s	v10, v10, v17
	fmul.4s	v26, v26, v10
	fcmgt.4s	v25, v25, v0
	ldr	q24, [sp, #448]                 ; 16-byte Reload
	bsl.16b	v25, v24, v26
	fmov.4s	v24, #0.25000000
	fdiv.4s	v26, v24, v25
	fsub.4s	v10, v25, v26
	fadd.4s	v25, v25, v26
	fdiv.4s	v25, v10, v25
	bsl.16b	v20, v25, v17
	fcmge.4s	v3, v17, v3
	bsl.16b	v3, v4, v20
	ldr	q4, [sp, #256]                  ; 16-byte Reload
	add.2d	v4, v4, v9
	ldr	q20, [sp, #368]                 ; 16-byte Reload
	add.2d	v20, v20, v9
	ldr	q24, [sp, #400]                 ; 16-byte Reload
	add.2d	v25, v24, v9
	mvni.4s	v24, #128, lsl #24
	bif.16b	v3, v2, v24
	fcmeq.4s	v2, v2, v2
	fadd.4s	v3, v3, v17
	ldr	q17, [sp, #432]                 ; 16-byte Reload
	bsl.16b	v2, v3, v17
	fmul.4s	v3, v14, v7
	fmul.4s	v2, v3, v2
	fadd.4s	v2, v15, v2
	stp	q19, q4, [sp, #624]
	stp	q20, q25, [sp, #656]
	fmov	w9, s31
	and	x10, x11, #0x7
	add	x12, sp, #624
	ldr	x10, [x12, x10, lsl #3]
	sub	x10, x10, x11
	add	x8, x8, x10, lsl #2
	tbz	w9, #0, LBB1_199
; %bb.190:                              ; %cond.store123
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s2, [x8]
	tbnz	w9, #1, LBB1_200
LBB1_191:                               ; %else126
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #2, LBB1_201
LBB1_192:                               ; %cond.store127
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #8
	st1.s	{ v2 }[2], [x10]
	tbnz	w9, #3, LBB1_202
	b	LBB1_203
LBB1_193:                               ; %else99
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #1, LBB1_181
LBB1_194:                               ; %cond.load101
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #4
	ld1.s	{ v15 }[1], [x12]
	tbnz	w10, #2, LBB1_182
LBB1_195:                               ; %else105
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_183
LBB1_196:                               ; %cond.load107
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #12
	ld1.s	{ v15 }[3], [x12]
	tbnz	w10, #4, LBB1_184
LBB1_197:                               ; %else111
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_185
LBB1_198:                               ; %cond.load113
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #20
	ld1.s	{ v13 }[1], [x12]
	tbnz	w10, #6, LBB1_186
	b	LBB1_187
LBB1_199:                               ; %else124
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #1, LBB1_191
LBB1_200:                               ; %cond.store125
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #4
	st1.s	{ v2 }[1], [x10]
	tbnz	w9, #2, LBB1_192
LBB1_201:                               ; %else128
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #3, LBB1_203
LBB1_202:                               ; %cond.store129
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #12
	st1.s	{ v2 }[3], [x10]
LBB1_203:                               ; %else130
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldp	q2, q3, [sp, #480]              ; 32-byte Folded Reload
	fmul.4s	v2, v23, v2
	fmul.4s	v2, v23, v2
	fmul.4s	v2, v23, v2
	fadd.4s	v2, v23, v2
	fmul.4s	v2, v2, v3
	zip2.8b	v3, v8, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v2, v3, v2
	fmul.4s	v3, v2, v2
	ldp	q7, q4, [sp, #512]              ; 32-byte Folded Reload
	fmla.4s	v4, v3, v7
	ldr	q7, [sp, #544]                  ; 16-byte Reload
	fmla.4s	v7, v3, v4
	ldr	q4, [sp, #576]                  ; 16-byte Reload
	fmla.4s	v4, v3, v7
	fmla.4s	v5, v3, v4
	mov.16b	v4, v1
	fmla.4s	v4, v3, v5
	fmov.4s	v5, #1.00000000
	fmla.4s	v5, v3, v4
	ldr	q7, [sp, #592]                  ; 16-byte Reload
	ldr	q4, [sp, #560]                  ; 16-byte Reload
	fmla.4s	v7, v3, v4
	ldr	q4, [sp, #608]                  ; 16-byte Reload
	fmla.4s	v4, v3, v7
	fmla.4s	v6, v3, v4
	fabs.4s	v4, v2
	fmul.4s	v5, v4, v5
	fmla.4s	v30, v3, v6
	movi.4s	v6, #63, lsl #24
	fmla.4s	v6, v3, v30
	fmov.4s	v7, #1.00000000
	fmla.4s	v7, v3, v6
	fdiv.4s	v3, v5, v7
	fmov.4s	v5, #9.00000000
	fcmge.4s	v5, v5, v4
	and.16b	v6, v5, v4
	fcmge.4s	v7, v6, v18
	fcmge.4s	v17, v0, v6
	and.16b	v7, v7, v17
	and.16b	v7, v7, v6
	fmul.4s	v16, v7, v16
	movi.4s	v17, #75, lsl #24
	fadd.4s	v16, v16, v17
	movi.4s	v17, #203, lsl #24
	fadd.4s	v16, v16, v17
	fcvtzs.4s	v16, v16
	scvtf.4s	v17, v16
	fmul.4s	v18, v17, v27
	fadd.4s	v7, v7, v18
	fmul.4s	v17, v17, v22
	fadd.4s	v7, v7, v17
	fmul.4s	v17, v7, v21
	ldr	q18, [sp, #464]                 ; 16-byte Reload
	fadd.4s	v17, v17, v18
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v29
	fmul.4s	v17, v7, v17
	fadd.4s	v17, v17, v28
	fmul.4s	v17, v7, v17
	fadd.4s	v1, v17, v1
	fmul.4s	v1, v7, v1
	movi.4s	v18, #63, lsl #24
	fadd.4s	v1, v1, v18
	fmul.4s	v17, v7, v7
	fmul.4s	v1, v17, v1
	fadd.4s	v1, v7, v1
	fmov.4s	v19, #1.00000000
	fadd.4s	v1, v1, v19
	movi.2d	v7, #0xffffffffffffffff
	add.4s	v7, v16, v7
	sshr.4s	v16, v7, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v19
	fmul.4s	v1, v1, v17
	sub.4s	v7, v7, v16
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v19
	fmul.4s	v1, v1, v7
	fcmgt.4s	v0, v6, v0
	ldr	q6, [sp, #448]                  ; 16-byte Reload
	bsl.16b	v0, v6, v1
	fmov.4s	v1, #0.25000000
	fdiv.4s	v1, v1, v0
	fsub.4s	v6, v0, v1
	fadd.4s	v0, v0, v1
	fdiv.4s	v0, v6, v0
	bif.16b	v0, v19, v5
	fcmge.4s	v1, v19, v4
	bit.16b	v0, v3, v1
	mvni.4s	v1, #128, lsl #24
	bif.16b	v0, v2, v1
	fcmeq.4s	v1, v2, v2
	fadd.4s	v0, v0, v19
	ldr	q2, [sp, #432]                  ; 16-byte Reload
	bif.16b	v0, v2, v1
	fmul.4s	v1, v23, v18
	fmul.4s	v0, v1, v0
	fadd.4s	v0, v13, v0
	tbnz	w9, #4, LBB1_160
LBB1_204:                               ; %else132
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #5, LBB1_161
LBB1_205:                               ; %cond.store267
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbnz	w9, #6, LBB1_162
LBB1_206:                               ; %else136
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #7, LBB1_2
LBB1_207:                               ; %cond.store271
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB1_2
LBB1_208:                               ; %block.batch.exit
	add	sp, sp, #1568
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh24, Lloh25
                                        ; -- End function
.subsections_via_symbols

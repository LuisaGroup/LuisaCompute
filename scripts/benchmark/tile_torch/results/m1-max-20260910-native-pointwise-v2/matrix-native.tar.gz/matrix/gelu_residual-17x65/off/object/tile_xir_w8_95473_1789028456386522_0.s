	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #864
	mov	x10, #0                         ; =0x0
	ldr	x13, [x0]
	ldr	x11, [x0, #16]
	ldr	x8, [x0, #48]
	ldr	w9, [x1]
	ldr	w12, [x1, #36]
	add	w9, w12, w9, lsl #5
	lsr	w9, w9, #3
	fmov	s0, w9
	ushll.2d	v0, v0, #0
	fmov	x9, d0
	add	x9, x9, x9, lsl #6
	lsl	x12, x9, #2
	add	x9, x13, x12
	ldp	q0, q1, [x9, #192]
	stp	q0, q1, [sp, #768]
	ldp	q0, q1, [x9, #224]
	stp	q0, q1, [sp, #800]
	ldp	q0, q1, [x9, #128]
	stp	q0, q1, [sp, #704]
	ldp	q0, q1, [x9, #160]
	stp	q0, q1, [sp, #736]
	ldp	q0, q1, [x9, #64]
	stp	q0, q1, [sp, #640]
	ldp	q0, q1, [x9, #96]
	stp	q0, q1, [sp, #672]
	ldp	q0, q1, [x9]
	stp	q0, q1, [sp, #576]
	ldp	q0, q1, [x9, #32]
	stp	q0, q1, [sp, #608]
	add	x9, x12, #256
	ldr	s5, [x13, x9]
	add	x13, x11, x12
	ldp	q0, q1, [x13, #192]
	stp	q0, q1, [sp, #480]
	ldp	q0, q1, [x13, #224]
	stp	q0, q1, [sp, #512]
	ldp	q0, q1, [x13, #128]
	stp	q0, q1, [sp, #416]
	ldp	q0, q1, [x13, #160]
	stp	q0, q1, [sp, #448]
	ldp	q0, q1, [x13, #64]
	stp	q0, q1, [sp, #352]
	ldp	q0, q1, [x13, #96]
	stp	q0, q1, [sp, #384]
	ldp	q2, q3, [x13]
	ldp	q0, q1, [x13, #32]
	ldr	s4, [x11, x9]
	add	x11, x8, x12
	add	x12, sp, #576
	mov	w13, #10003                     ; =0x2713
	movk	w13, #15671, lsl #16
	dup.4s	v7, w13
	mov	w13, #16938                     ; =0x422a
	movk	w13, #16204, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #256]              ; 32-byte Folded Spill
	mov	w13, #37425                     ; =0x9231
	movk	w13, #12080, lsl #16
	dup.4s	v7, w13
	mov	w13, #12843                     ; =0x322b
	movk	w13, #13015, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #224]              ; 32-byte Folded Spill
	mov	w13, #61213                     ; =0xef1d
	movk	w13, #13880, lsl #16
	dup.4s	v7, w13
	mov	w13, #3329                      ; =0xd01
	movk	w13, #14672, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #192]              ; 32-byte Folded Spill
	mov	w13, #34953                     ; =0x8889
	movk	w13, #15368, lsl #16
	dup.4s	v7, w13
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15914, lsl #16
	dup.4s	v20, w13
	mov	w13, #30407                     ; =0x76c7
	movk	w13, #12559, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #160]              ; 32-byte Folded Spill
	mov	w13, #62078                     ; =0xf27e
	movk	w13, #13459, lsl #16
	dup.4s	v7, w13
	mov	w13, #3329                      ; =0xd01
	movk	w13, #14288, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #128]              ; 32-byte Folded Spill
	mov	w13, #2913                      ; =0xb61
	movk	w13, #15030, lsl #16
	dup.4s	v7, w13
	fmov.4s	v23, #1.00000000
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15658, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #96]               ; 32-byte Folded Spill
	mov	w13, #-1026555904               ; =0xc2d00000
	dup.4s	v7, w13
	mov	w13, #1120403456                ; =0x42c80000
	dup.4s	v27, w13
	mov	w13, #43579                     ; =0xaa3b
	movk	w13, #16312, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #64]               ; 32-byte Folded Spill
	mov	w13, #29184                     ; =0x7200
	movk	w13, #48945, lsl #16
	dup.4s	v7, w13
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #46527, lsl #16
	dup.4s	v6, w13
	stp	q6, q7, [sp, #32]               ; 32-byte Folded Spill
	mov	w13, #11226                     ; =0x2bda
	movk	w13, #14672, lsl #16
	dup.4s	v8, w13
	mov	w13, #38601                     ; =0x96c9
	movk	w13, #15030, lsl #16
	dup.4s	v9, w13
	mov	w13, #34982                     ; =0x88a6
	movk	w13, #15368, lsl #16
	dup.4s	v10, w13
	mov	w13, #43642                     ; =0xaa7a
	movk	w13, #15658, lsl #16
	stp	q2, q3, [sp, #288]
	mvni.4s	v2, #127, msl #16
	fneg.4s	v13, v2
	stp	q0, q1, [sp, #320]
	dup.4s	v14, w13
	mvni.4s	v0, #63, msl #16
	fneg.4s	v15, v0
	add	x13, sp, #288
	stp	q5, q4, [sp]                    ; 32-byte Folded Spill
	str	q5, [sp, #832]
	str	q4, [sp, #544]
LBB0_1:                                 ; %direct.true57
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x12, x10
	ldp	q25, q29, [x14]
	ldp	q2, q1, [sp, #256]              ; 32-byte Folded Reload
	fmul.4s	v0, v25, v1
	fmul.4s	v1, v29, v1
	fmul.4s	v1, v29, v1
	fmul.4s	v0, v25, v0
	fmul.4s	v0, v25, v0
	fmul.4s	v1, v29, v1
	fadd.4s	v1, v29, v1
	fadd.4s	v0, v25, v0
	fmul.4s	v12, v0, v2
	fmul.4s	v11, v1, v2
	fabs.4s	v1, v11
	fabs.4s	v0, v12
	fmul.4s	v7, v12, v12
	fmul.4s	v17, v11, v11
	ldp	q3, q4, [sp, #224]              ; 32-byte Folded Reload
	mov.16b	v2, v3
	fmla.4s	v2, v7, v4
	fmla.4s	v3, v17, v4
	ldr	q5, [sp, #208]                  ; 16-byte Reload
	mov.16b	v4, v5
	fmla.4s	v4, v7, v2
	mov.16b	v2, v5
	fmla.4s	v2, v17, v3
	ldp	q6, q5, [sp, #176]              ; 32-byte Folded Reload
	mov.16b	v3, v5
	fmla.4s	v3, v7, v4
	mov.16b	v4, v5
	fmla.4s	v4, v17, v2
	mov.16b	v5, v6
	mov.16b	v18, v20
	mov.16b	v19, v20
	fmov.4s	v2, #1.00000000
	fmla.4s	v5, v7, v3
	ldp	q16, q21, [sp, #144]            ; 32-byte Folded Reload
	mov.16b	v3, v16
	fmla.4s	v3, v17, v21
	fmla.4s	v16, v7, v21
	ldr	q22, [sp, #128]                 ; 16-byte Reload
	mov.16b	v21, v22
	fmla.4s	v6, v17, v4
	fmla.4s	v21, v17, v3
	mov.16b	v3, v22
	fmla.4s	v3, v7, v16
	ldr	q16, [sp, #112]                 ; 16-byte Reload
	mov.16b	v4, v16
	fmla.4s	v4, v17, v21
	fmla.4s	v18, v7, v5
	mov.16b	v5, v16
	fmla.4s	v5, v7, v3
	ldp	q28, q21, [sp, #80]             ; 32-byte Folded Reload
	mov.16b	v16, v21
	fmla.4s	v16, v17, v4
	fmla.4s	v19, v17, v6
	fmla.4s	v21, v7, v5
	movi.4s	v22, #63, lsl #24
	movi.4s	v24, #63, lsl #24
	fmov.4s	v5, #1.00000000
	fmov.4s	v4, #9.00000000
	fcmge.4s	v3, v4, v0
	fmla.4s	v22, v17, v16
	fcmge.4s	v4, v4, v1
	and.16b	v6, v4, v1
	and.16b	v16, v3, v0
	fcmge.4s	v26, v16, v28
	fcmge.4s	v28, v6, v28
	fcmge.4s	v30, v27, v6
	and.16b	v28, v28, v30
	fcmge.4s	v30, v27, v16
	and.16b	v26, v26, v30
	and.16b	v26, v26, v16
	and.16b	v28, v28, v6
	fmla.4s	v2, v17, v19
	ldr	q30, [sp, #64]                  ; 16-byte Reload
	fmul.4s	v19, v28, v30
	fmul.4s	v30, v26, v30
	movi.4s	v31, #75, lsl #24
	fadd.4s	v30, v30, v31
	fadd.4s	v19, v19, v31
	movi.4s	v31, #203, lsl #24
	fadd.4s	v19, v19, v31
	fmla.4s	v5, v17, v22
	fadd.4s	v17, v30, v31
	fcvtzs.4s	v17, v17
	fcvtzs.4s	v19, v19
	scvtf.4s	v22, v19
	scvtf.4s	v30, v17
	fmla.4s	v24, v7, v21
	ldr	q31, [sp, #48]                  ; 16-byte Reload
	fmul.4s	v21, v22, v31
	fadd.4s	v21, v28, v21
	fmul.4s	v28, v30, v31
	fadd.4s	v26, v26, v28
	fmov.4s	v28, #1.00000000
	fmla.4s	v28, v7, v18
	ldr	q31, [sp, #32]                  ; 16-byte Reload
	fmul.4s	v18, v30, v31
	fadd.4s	v18, v26, v18
	fmul.4s	v22, v22, v31
	fadd.4s	v21, v21, v22
	fmov.4s	v22, #1.00000000
	fmla.4s	v22, v7, v24
	fmul.4s	v7, v21, v8
	fmul.4s	v24, v18, v8
	fadd.4s	v24, v24, v9
	fadd.4s	v7, v7, v9
	fmul.4s	v7, v21, v7
	fmul.4s	v26, v0, v28
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v24, v10
	fadd.4s	v7, v7, v10
	fmul.4s	v7, v21, v7
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v24, v14
	fadd.4s	v7, v7, v14
	fmul.4s	v7, v21, v7
	fmul.4s	v24, v18, v24
	fadd.4s	v24, v24, v20
	fadd.4s	v28, v7, v20
	fdiv.4s	v7, v26, v22
	fmul.4s	v22, v21, v28
	fmul.4s	v24, v18, v24
	movi.4s	v28, #63, lsl #24
	fadd.4s	v24, v24, v28
	fadd.4s	v22, v22, v28
	fmul.4s	v26, v21, v21
	fmul.4s	v22, v26, v22
	fmul.4s	v26, v18, v18
	fmul.4s	v24, v26, v24
	fadd.4s	v18, v18, v24
	fadd.4s	v21, v21, v22
	movi.2d	v26, #0xffffffffffffffff
	add.4s	v17, v17, v26
	fadd.4s	v18, v18, v23
	sshr.4s	v22, v17, #1
	shl.4s	v24, v22, #23
	add.4s	v24, v24, v23
	fmul.4s	v18, v18, v24
	add.4s	v19, v19, v26
	fadd.4s	v21, v21, v23
	sub.4s	v17, v17, v22
	sshr.4s	v22, v19, #1
	sub.4s	v19, v19, v22
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v23
	fmul.4s	v21, v21, v22
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v23
	fmul.4s	v19, v21, v19
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v23
	fmul.4s	v17, v18, v17
	fcmgt.4s	v16, v16, v27
	bsl.16b	v16, v13, v17
	fmul.4s	v2, v1, v2
	fcmgt.4s	v6, v6, v27
	bsl.16b	v6, v13, v19
	fdiv.4s	v2, v2, v5
	fmov.4s	v18, #0.25000000
	fdiv.4s	v5, v18, v6
	fsub.4s	v17, v6, v5
	fadd.4s	v5, v6, v5
	fdiv.4s	v5, v17, v5
	bsl.16b	v4, v5, v23
	fcmge.4s	v1, v23, v1
	bsl.16b	v1, v2, v4
	fdiv.4s	v2, v18, v16
	fsub.4s	v4, v16, v2
	fadd.4s	v2, v16, v2
	fdiv.4s	v2, v4, v2
	bif.16b	v2, v23, v3
	fcmge.4s	v0, v23, v0
	bsl.16b	v0, v7, v2
	mvni.4s	v3, #128, lsl #24
	bif.16b	v0, v12, v3
	fcmeq.4s	v2, v12, v12
	fadd.4s	v0, v0, v23
	bif.16b	v0, v15, v2
	bif.16b	v1, v11, v3
	fcmeq.4s	v2, v11, v11
	fadd.4s	v1, v1, v23
	bif.16b	v1, v15, v2
	fmul.4s	v2, v29, v28
	fmul.4s	v1, v2, v1
	fmul.4s	v2, v25, v28
	fmul.4s	v0, v2, v0
	add	x14, x13, x10
	ldp	q3, q2, [x14]
	fadd.4s	v0, v3, v0
	fadd.4s	v1, v2, v1
	add	x14, x11, x10
	stp	q0, q1, [x14]
	add	x10, x10, #32
	cmp	x10, #256
	b.ne	LBB0_1
; %bb.2:                                ; %direct.false58
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], v0[0]
	mov.16b	v2, v0
	ldr	q21, [sp]                       ; 16-byte Reload
	mov.s	v2[0], v21[0]
	movi.4s	v1, #63, lsl #24
	mov	w10, #10003                     ; =0x2713
	movk	w10, #15671, lsl #16
	fmov	s3, w10
	fmul.4s	v2, v2, v3[0]
	fmul.4s	v2, v21, v2
	fmul.4s	v2, v21, v2
	fadd.4s	v2, v21, v2
	mov	w10, #16938                     ; =0x422a
	movk	w10, #16204, lsl #16
	fmov	s3, w10
	fmul.4s	v2, v2, v3
	mov.s	v0[0], v2[0]
	fabs.4s	v2, v0
	fmul.4s	v3, v0, v0
	mov	w10, #37425                     ; =0x9231
	movk	w10, #12080, lsl #16
	dup.4s	v4, w10
	mov	w10, #12843                     ; =0x322b
	movk	w10, #13015, lsl #16
	dup.4s	v5, w10
	fmla.4s	v5, v3, v4
	mov	w10, #61213                     ; =0xef1d
	movk	w10, #13880, lsl #16
	dup.4s	v4, w10
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14672, lsl #16
	dup.4s	v6, w10
	fmla.4s	v4, v3, v5
	fmla.4s	v6, v3, v4
	mov	w10, #34953                     ; =0x8889
	movk	w10, #15368, lsl #16
	dup.4s	v7, w10
	fmla.4s	v7, v3, v6
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v16, w10
	fmov.4s	v4, #9.00000000
	fcmge.4s	v4, v4, v2
	and.16b	v5, v4, v2
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v17, w10
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v6, w10
	fcmge.4s	v17, v5, v17
	fcmge.4s	v18, v6, v5
	and.16b	v17, v17, v18
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v18, w10
	and.16b	v17, v17, v5
	fmul.4s	v18, v17, v18
	movi.4s	v19, #75, lsl #24
	fadd.4s	v18, v18, v19
	movi.4s	v19, #203, lsl #24
	fadd.4s	v18, v18, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v20, w10
	fmul.4s	v20, v19, v20
	fadd.4s	v17, v17, v20
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v20, w10
	fmul.4s	v19, v19, v20
	fadd.4s	v17, v17, v19
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v19, w10
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v20, w10
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v17, v19
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v20, w10
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v17, v19
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v20, w10
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v17, v19
	fadd.4s	v19, v19, v16
	fmla.4s	v16, v3, v7
	fmov.4s	v7, #1.00000000
	fmla.4s	v7, v3, v16
	mov	w10, #30407                     ; =0x76c7
	movk	w10, #12559, lsl #16
	dup.4s	v16, w10
	mov	w10, #62078                     ; =0xf27e
	movk	w10, #13459, lsl #16
	dup.4s	v20, w10
	fmla.4s	v20, v3, v16
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14288, lsl #16
	dup.4s	v16, w10
	fmla.4s	v16, v3, v20
	mov	w10, #2913                      ; =0xb61
	movk	w10, #15030, lsl #16
	dup.4s	v20, w10
	fmla.4s	v20, v3, v16
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15658, lsl #16
	dup.4s	v16, w10
	fmul.4s	v21, v21, v1
	fmla.4s	v16, v3, v20
	movi.4s	v20, #63, lsl #24
	fmla.4s	v20, v3, v16
	fmov.4s	v16, #1.00000000
	fmla.4s	v16, v3, v20
	fmov.4s	v3, #1.00000000
	fcmge.4s	v20, v3, v2
	fmul.4s	v2, v2, v7
	fdiv.4s	v2, v2, v16
	fmul.4s	v7, v17, v19
	fadd.4s	v1, v7, v1
	fmul.4s	v7, v17, v17
	fmul.4s	v1, v7, v1
	fadd.4s	v1, v17, v1
	fadd.4s	v1, v1, v3
	movi.2d	v7, #0xffffffffffffffff
	add.4s	v7, v18, v7
	sshr.4s	v16, v7, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v3
	fmul.4s	v1, v1, v17
	sub.4s	v7, v7, v16
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v1, v1, v7
	fcmgt.4s	v5, v5, v6
	mvni.4s	v6, #127, msl #16
	fneg.4s	v6, v6
	bit.16b	v1, v6, v5
	fmov.4s	v5, #0.25000000
	fdiv.4s	v5, v5, v1
	fsub.4s	v6, v1, v5
	fadd.4s	v1, v1, v5
	fdiv.4s	v1, v6, v1
	bif.16b	v1, v3, v4
	bit.16b	v1, v2, v20
	mvni.4s	v2, #128, lsl #24
	bif.16b	v1, v0, v2
	fcmeq.4s	v0, v0, v0
	fadd.4s	v1, v1, v3
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	bsl.16b	v0, v1, v2
	fmul.4s	v0, v21, v0
	ldr	q1, [sp, #16]                   ; 16-byte Reload
	fadd.4s	v0, v0, v1
	str	s0, [x8, x9]
	add	sp, sp, #864
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_3:
	.quad	64                              ; 0x40
	.quad	65                              ; 0x41
lCPI1_4:
	.quad	68                              ; 0x44
	.quad	69                              ; 0x45
lCPI1_5:
	.quad	66                              ; 0x42
	.quad	67                              ; 0x43
lCPI1_6:
	.quad	70                              ; 0x46
	.quad	71                              ; 0x47
lCPI1_7:
	.quad	256                             ; 0x100
	.quad	260                             ; 0x104
lCPI1_8:
	.quad	272                             ; 0x110
	.quad	276                             ; 0x114
lCPI1_9:
	.quad	264                             ; 0x108
	.quad	268                             ; 0x10c
lCPI1_10:
	.quad	280                             ; 0x118
	.quad	284                             ; 0x11c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1312
	str	x0, [sp, #232]                  ; 8-byte Spill
	cbz	w3, LBB1_115
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x21, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	mov	w24, #32                        ; =0x20
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [sp, #336]                  ; 16-byte Spill
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh4:
	adrp	x8, lCPI1_2@PAGE
Lloh5:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #304]                  ; 16-byte Spill
	add	x28, sp, #1024
	movi.2s	v8, #65
	add	x27, sp, #736
	mvni.4s	v0, #127, msl #16
	fneg.4s	v1, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q1, [sp, #480]              ; 32-byte Folded Spill
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #224]              ; 8-byte Folded Spill
	ldp	w19, w26, [x2]
	ldp	w25, w8, [x2, #8]
	str	x8, [sp, #216]                  ; 8-byte Spill
	str	w3, [sp, #188]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w21, [sp, #188]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w19, #1
	ldp	w10, w9, [sp, #224]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w19, wzr, w19, eq
	cinc	w9, w26, eq
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w26, wzr, w9, ne
	add	w25, w25, w8
	add	w22, w22, #1
	cmp	w22, w21
	b.eq	LBB1_115
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_43 Depth 2
                                        ;     Child Loop BB1_70 Depth 2
	ubfiz	x8, x19, #5, #32
	ldr	x11, [sp, #216]                 ; 8-byte Reload
	cmp	x8, x11
	csel	x9, x8, xzr, ls
	subs	x10, x11, x9
	cmp	x10, #32
	csel	x10, x10, x24, lo
	cmp	x11, x9
	stp	w19, w26, [x20]
	str	w25, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x11, #2, hi
	csel	x23, x10, xzr, ls
	cmp	x23, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x23, [sp, #232]                 ; 8-byte Reload
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x21, x23, #3
	cbz	x21, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #232]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #232]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #232]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x24, [sp, #232]                 ; 8-byte Reload
	mov	x0, x24
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x24
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x24
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x24
	mov	w24, #32                        ; =0x20
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w23, #0x7
	mov	w23, #30407                     ; =0x76c7
	movk	w23, #12559, lsl #16
	mov	w30, #62078                     ; =0xf27e
	movk	w30, #13459, lsl #16
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v1, w8
	ldr	q0, [sp, #16]                   ; 16-byte Reload
	cmhi.4s	v9, v1, v0
	ldr	q0, [sp, #336]                  ; 16-byte Reload
	str	q1, [sp, #320]                  ; 16-byte Spill
	cmhi.4s	v2, v1, v0
	uzp1.8h	v4, v2, v9
	umaxv.8h	h0, v4
	fmov	w8, s0
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	x12, [sp, #232]                 ; 8-byte Reload
	ldr	x11, [x12]
	ldr	x10, [x12, #16]
	ubfiz	w8, w19, #2, #27
	orr	w8, w8, w21
	dup.4s	v0, w8
	ldr	x8, [x12, #48]
	and.16b	v5, v2, v0
	and.16b	v0, v9, v0
	ushll2.2d	v3, v0, #0
	ushll2.2d	v6, v5, #0
	ushll.2d	v7, v0, #0
	ushll.2d	v18, v5, #0
	fmov	x12, d18
	mov	w13, #260                       ; =0x104
	umaddl	x12, w12, w13, x11
	ldr	q0, [sp, #304]                  ; 16-byte Reload
	and.16b	v0, v4, v0
	addv.8h	h17, v0
	fmov	w13, s17
	b	LBB1_15
LBB1_14:                                ; %else21
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x28, x9
	stp	q0, q5, [x14]
	add	x9, x9, #32
	cmp	x9, #256
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x14, x12, x9
	add	x16, x28, x9
	ldr	q0, [x16]
	tbnz	w13, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w15, w13, #0xff
	tbnz	w15, #1, LBB1_24
LBB1_17:                                ; %else3
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #2, LBB1_25
LBB1_18:                                ; %else6
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #3, LBB1_26
LBB1_19:                                ; %else9
                                        ;   in Loop: Header=BB1_15 Depth=2
	ldr	q5, [x16, #16]
	tbnz	w15, #4, LBB1_27
LBB1_20:                                ; %else12
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #5, LBB1_28
LBB1_21:                                ; %else15
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w15, #6, LBB1_29
LBB1_22:                                ; %else18
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w15, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	ld1.s	{ v0 }[0], [x14]
	and	w15, w13, #0xff
	tbz	w15, #1, LBB1_17
LBB1_24:                                ; %cond.load2
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x14, #4
	ld1.s	{ v0 }[1], [x17]
	tbz	w15, #2, LBB1_18
LBB1_25:                                ; %cond.load5
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x14, #8
	ld1.s	{ v0 }[2], [x17]
	tbz	w15, #3, LBB1_19
LBB1_26:                                ; %cond.load8
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x14, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q5, [x16, #16]
	tbz	w15, #4, LBB1_20
LBB1_27:                                ; %cond.load11
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x16, x14, #16
	ld1.s	{ v5 }[0], [x16]
	tbz	w15, #5, LBB1_21
LBB1_28:                                ; %cond.load14
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x16, x14, #20
	ld1.s	{ v5 }[1], [x16]
	tbz	w15, #6, LBB1_22
LBB1_29:                                ; %cond.load17
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x16, x14, #24
	ld1.s	{ v5 }[2], [x16]
	tbz	w15, #7, LBB1_14
LBB1_30:                                ; %cond.load20
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x14, #28
	ld1.s	{ v5 }[3], [x14]
	b	LBB1_14
LBB1_31:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v0, v4
	sshll2.2d	v4, v9, #0
	sshll2.2d	v5, v2, #0
	sshll.2d	v16, v9, #0
	sshll.2d	v20, v2, #0
	movi.8b	v1, #1
	and.8b	v19, v0, v1
	umov.b	w13, v19[0]
	movi.2d	v1, #0000000000000000
	mov.b	v1[0], v0[0]
	str	q1, [sp, #192]                  ; 16-byte Spill
	umaxv.8b	b19, v1
	fmov	w15, s19
	rbit	w9, w13
	clz	w9, w9
	tst	w15, #0x1
	csel	w9, w9, wzr, ne
Lloh6:
	adrp	x12, lCPI1_3@PAGE
Lloh7:
	ldr	q21, [x12, lCPI1_3@PAGEOFF]
	mov	w12, #64                        ; =0x40
	dup.2d	v19, x12
	mov.16b	v1, v20
	bsl.16b	v1, v21, v19
	xtn.2s	v18, v18
	umlal.2d	v1, v18, v8
	movi.2d	v21, #0000000000000000
	mov.b	v21[0], v0[0]
	ushll.2d	v0, v21, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	str	q1, [sp, #160]                  ; 16-byte Spill
	and.16b	v0, v0, v1
	movi.2d	v1, #0000000000000000
	stp	q1, q1, [sp, #624]
	stp	q0, q1, [sp, #592]
	ubfiz	x16, x9, #3, #3
	add	x12, sp, #592
	ldr	x12, [x12, x16]
	sub	x12, x12, x9
	lsl	x12, x12, #2
	add	x14, x11, x12
Lloh8:
	adrp	x11, lCPI1_7@PAGE
Lloh9:
	ldr	q0, [x11, lCPI1_7@PAGEOFF]
	mov	w11, #256                       ; =0x100
	dup.2d	v21, x11
	bif.16b	v0, v21, v20
Lloh10:
	adrp	x11, lCPI1_8@PAGE
Lloh11:
	ldr	q20, [x11, lCPI1_8@PAGEOFF]
	bif.16b	v20, v21, v16
Lloh12:
	adrp	x11, lCPI1_9@PAGE
Lloh13:
	ldr	q22, [x11, lCPI1_9@PAGEOFF]
	bif.16b	v22, v21, v5
Lloh14:
	adrp	x11, lCPI1_10@PAGE
Lloh15:
	ldr	q23, [x11, lCPI1_10@PAGEOFF]
	bit.16b	v21, v23, v4
	stp	q20, q21, [sp, #688]
	stp	q0, q22, [sp, #656]
	add	x11, sp, #656
	ldr	x11, [x11, x16]
	sub	x11, x11, w9, uxtw #2
	tst	w13, #0x1
	csel	x11, xzr, x11, eq
	add	x16, x28, x11
	ldp	q20, q1, [x16]
	tbz	w15, #0, LBB1_33
; %bb.32:                               ; %cond.load24
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v20 }[0], [x14]
LBB1_33:                                ; %else25
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w1, #10003                      ; =0x2713
	movk	w1, #15671, lsl #16
	mov	w2, #16938                      ; =0x422a
	movk	w2, #16204, lsl #16
	mov	w3, #37425                      ; =0x9231
	movk	w3, #12080, lsl #16
	mov	w4, #12843                      ; =0x322b
	movk	w4, #13015, lsl #16
	mov	w5, #61213                      ; =0xef1d
	movk	w5, #13880, lsl #16
	mov	w6, #3329                       ; =0xd01
	movk	w6, #14672, lsl #16
	mov	w7, #34953                      ; =0x8889
	movk	w7, #15368, lsl #16
	mov	w21, #43691                     ; =0xaaab
	movk	w21, #15914, lsl #16
	tbnz	w13, #1, LBB1_95
; %bb.34:                               ; %else28
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w13, #2, LBB1_96
LBB1_35:                                ; %else31
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w13, #3, LBB1_97
LBB1_36:                                ; %else34
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w13, #4, LBB1_98
LBB1_37:                                ; %else37
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w13, #5, LBB1_99
LBB1_38:                                ; %else40
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w13, #6, LBB1_100
LBB1_39:                                ; %else43
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_41
LBB1_40:                                ; %cond.load45
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x14, #28
	ld1.s	{ v1 }[3], [x13]
LBB1_41:                                ; %else46
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x15, #0                         ; =0x0
Lloh16:
	adrp	x13, lCPI1_4@PAGE
Lloh17:
	ldr	q0, [x13, lCPI1_4@PAGEOFF]
	bsl.16b	v16, v0, v19
Lloh18:
	adrp	x13, lCPI1_5@PAGE
Lloh19:
	ldr	q0, [x13, lCPI1_5@PAGEOFF]
	mov.16b	v21, v5
	bsl.16b	v21, v0, v19
Lloh20:
	adrp	x13, lCPI1_6@PAGE
Lloh21:
	ldr	q0, [x13, lCPI1_6@PAGEOFF]
	bit.16b	v19, v0, v4
	umull.2d	v0, v18, v8
	xtn.2s	v4, v6
	xtn.2s	v5, v7
	xtn.2s	v3, v3
	umlal.2d	v19, v3, v8
	umlal.2d	v21, v4, v8
	stp	q19, q21, [sp, #80]             ; 32-byte Folded Spill
	umlal.2d	v16, v5, v8
	str	q16, [sp, #112]                 ; 16-byte Spill
	add	x13, x28, x11
	stp	q20, q1, [x13]
	fmov	x13, d0
	lsl	x13, x13, #2
	mov	w14, #1                         ; =0x1
	dup.2d	v0, x14
	add	x14, x10, x13
	ushll2.2d	v3, v9, #0
	and.16b	v18, v3, v0
	ushll2.2d	v3, v2, #0
	and.16b	v19, v3, v0
	ushll.2d	v3, v9, #0
	and.16b	v21, v3, v0
	ushll.2d	v2, v2, #0
	and.16b	v27, v2, v0
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	b	LBB1_43
LBB1_42:                                ; %else71
                                        ;   in Loop: Header=BB1_43 Depth=2
	add	x15, x27, x15
	stp	q0, q6, [x15]
	add.2d	v3, v3, v19
	add.2d	v4, v4, v21
	add.2d	v5, v5, v18
	add.2d	v2, v2, v27
	fmov	x15, d2
	cmp	x15, #8
	b.ge	LBB1_59
LBB1_43:                                ; %direct.true36.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w17, s17
	lsl	x15, x15, #5
	add	x16, x14, x15
	add	x0, x27, x15
	ldp	q0, q6, [x0]
	tbnz	w17, #0, LBB1_51
; %bb.44:                               ; %else50
                                        ;   in Loop: Header=BB1_43 Depth=2
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_52
LBB1_45:                                ; %else53
                                        ;   in Loop: Header=BB1_43 Depth=2
	tbnz	w17, #2, LBB1_53
LBB1_46:                                ; %else56
                                        ;   in Loop: Header=BB1_43 Depth=2
	tbnz	w17, #3, LBB1_54
LBB1_47:                                ; %else59
                                        ;   in Loop: Header=BB1_43 Depth=2
	tbnz	w17, #4, LBB1_55
LBB1_48:                                ; %else62
                                        ;   in Loop: Header=BB1_43 Depth=2
	tbnz	w17, #5, LBB1_56
LBB1_49:                                ; %else65
                                        ;   in Loop: Header=BB1_43 Depth=2
	tbnz	w17, #6, LBB1_57
LBB1_50:                                ; %else68
                                        ;   in Loop: Header=BB1_43 Depth=2
	tbz	w17, #7, LBB1_42
	b	LBB1_58
LBB1_51:                                ; %cond.load49
                                        ;   in Loop: Header=BB1_43 Depth=2
	ld1.s	{ v0 }[0], [x16]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_45
LBB1_52:                                ; %cond.load52
                                        ;   in Loop: Header=BB1_43 Depth=2
	add	x0, x16, #4
	ld1.s	{ v0 }[1], [x0]
	tbz	w17, #2, LBB1_46
LBB1_53:                                ; %cond.load55
                                        ;   in Loop: Header=BB1_43 Depth=2
	add	x0, x16, #8
	ld1.s	{ v0 }[2], [x0]
	tbz	w17, #3, LBB1_47
LBB1_54:                                ; %cond.load58
                                        ;   in Loop: Header=BB1_43 Depth=2
	add	x0, x16, #12
	ld1.s	{ v0 }[3], [x0]
	tbz	w17, #4, LBB1_48
LBB1_55:                                ; %cond.load61
                                        ;   in Loop: Header=BB1_43 Depth=2
	add	x0, x16, #16
	ld1.s	{ v6 }[0], [x0]
	tbz	w17, #5, LBB1_49
LBB1_56:                                ; %cond.load64
                                        ;   in Loop: Header=BB1_43 Depth=2
	add	x0, x16, #20
	ld1.s	{ v6 }[1], [x0]
	tbz	w17, #6, LBB1_50
LBB1_57:                                ; %cond.load67
                                        ;   in Loop: Header=BB1_43 Depth=2
	add	x0, x16, #24
	ld1.s	{ v6 }[2], [x0]
	tbz	w17, #7, LBB1_42
LBB1_58:                                ; %cond.load70
                                        ;   in Loop: Header=BB1_43 Depth=2
	add	x16, x16, #28
	ld1.s	{ v6 }[3], [x16]
	b	LBB1_42
LBB1_59:                                ; %direct.false37.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q1, [sp, #144]                  ; 16-byte Spill
	add	x10, x10, x12
	add	x12, x27, x11
	ldp	q4, q3, [x12]
Lloh22:
	adrp	x12, lCPI1_11@PAGE
Lloh23:
	ldr	d0, [x12, lCPI1_11@PAGEOFF]
	ldr	q1, [sp, #192]                  ; 16-byte Reload
	shl.8b	v2, v1, #7
	cmlt.8b	v2, v2, #0
	and.8b	v0, v2, v0
	addv.8b	b0, v0
	str	d0, [sp, #40]                   ; 8-byte Spill
	fmov	w12, s0
	tbnz	w12, #0, LBB1_101
; %bb.60:                               ; %else75
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #1, LBB1_102
LBB1_61:                                ; %else78
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #2, LBB1_103
LBB1_62:                                ; %else81
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #3, LBB1_104
LBB1_63:                                ; %else84
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #4, LBB1_105
LBB1_64:                                ; %else87
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #5, LBB1_106
LBB1_65:                                ; %else90
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #6, LBB1_107
LBB1_66:                                ; %else93
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q20, [sp, #128]                 ; 16-byte Spill
	tbz	w12, #7, LBB1_68
LBB1_67:                                ; %cond.load95
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v3 }[3], [x10]
LBB1_68:                                ; %else96
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	add	x10, x27, x11
	stp	q4, q3, [sp, #48]               ; 32-byte Folded Spill
	stp	q4, q3, [x10]
	add	x10, x8, x13
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v22, #0000000000000000
	stp	q19, q18, [sp, #272]            ; 32-byte Folded Spill
	stp	q27, q21, [sp, #240]            ; 32-byte Folded Spill
	b	LBB1_70
LBB1_69:                                ; %else113
                                        ;   in Loop: Header=BB1_70 Depth=2
	add.2d	v5, v5, v19
	add.2d	v17, v17, v21
	add.2d	v22, v22, v18
	add.2d	v4, v4, v27
	fmov	x12, d4
	cmp	x12, #8
	b.ge	LBB1_86
LBB1_70:                                ; %direct.true57.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q1, q0, [sp, #320]              ; 32-byte Folded Reload
	cmhi.4s	v0, v1, v0
	lsl	x11, x12, #5
	add	x12, x28, x11
	ldr	q2, [x12]
	and.16b	v18, v0, v2
	dup.4s	v1, w1
	str	q1, [sp, #464]                  ; 16-byte Spill
	fmul.4s	v2, v18, v1
	fmul.4s	v2, v18, v2
	fmul.4s	v2, v18, v2
	fadd.4s	v2, v18, v2
	dup.4s	v1, w2
	str	q1, [sp, #432]                  ; 16-byte Spill
	fmul.4s	v2, v2, v1
	and.16b	v19, v0, v2
	fabs.4s	v20, v19
	fmul.4s	v2, v19, v19
	dup.4s	v1, w3
	dup.4s	v3, w4
	str	q3, [sp, #448]                  ; 16-byte Spill
	fmla.4s	v3, v2, v1
	dup.4s	v6, w5
	stp	q6, q1, [sp, #400]              ; 32-byte Folded Spill
	fmla.4s	v6, v2, v3
	dup.4s	v31, w6
	mov.16b	v3, v31
	fmla.4s	v3, v2, v6
	dup.4s	v10, w7
	mov.16b	v6, v10
	fmla.4s	v6, v2, v3
	dup.4s	v24, w21
	mov.16b	v3, v24
	fmla.4s	v3, v2, v6
	fmov.4s	v6, #1.00000000
	fmla.4s	v6, v2, v3
	dup.4s	v1, w23
	dup.4s	v11, w30
	fmul.4s	v3, v20, v6
	mov.16b	v6, v11
	str	q1, [sp, #384]                  ; 16-byte Spill
	fmla.4s	v6, v2, v1
	mov	w13, #3329                      ; =0xd01
	movk	w13, #14288, lsl #16
	dup.4s	v14, w13
	mov.16b	v7, v14
	fmla.4s	v7, v2, v6
	mov	w13, #2913                      ; =0xb61
	movk	w13, #15030, lsl #16
	dup.4s	v13, w13
	mov.16b	v6, v13
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15658, lsl #16
	dup.4s	v15, w13
	fmla.4s	v6, v2, v7
	mov.16b	v7, v15
	fmla.4s	v7, v2, v6
	movi.4s	v6, #63, lsl #24
	fmla.4s	v6, v2, v7
	fmov.4s	v7, #1.00000000
	fmla.4s	v7, v2, v6
	fdiv.4s	v21, v3, v7
	fmov.4s	v1, #9.00000000
	fcmge.4s	v1, v1, v20
	and.16b	v26, v1, v20
	mov	w13, #-1026555904               ; =0xc2d00000
	dup.4s	v2, w13
	str	q2, [sp, #368]                  ; 16-byte Spill
	fcmge.4s	v2, v26, v2
	mov	w13, #1120403456                ; =0x42c80000
	dup.4s	v25, w13
	fcmge.4s	v3, v25, v26
	and.16b	v2, v2, v3
	and.16b	v2, v2, v26
	mov	w13, #43579                     ; =0xaa3b
	movk	w13, #16312, lsl #16
	dup.4s	v3, w13
	str	q3, [sp, #352]                  ; 16-byte Spill
	fmul.4s	v3, v2, v3
	movi.4s	v6, #75, lsl #24
	fadd.4s	v3, v3, v6
	movi.4s	v6, #203, lsl #24
	fadd.4s	v3, v3, v6
	fcvtzs.4s	v28, v3
	scvtf.4s	v3, v28
	mov	w13, #29184                     ; =0x7200
	movk	w13, #48945, lsl #16
	dup.4s	v6, w13
	fmul.4s	v16, v3, v6
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #46527, lsl #16
	dup.4s	v7, w13
	fadd.4s	v2, v2, v16
	fmul.4s	v3, v3, v7
	fadd.4s	v29, v2, v3
	mov	w13, #11226                     ; =0x2bda
	movk	w13, #14672, lsl #16
	dup.4s	v16, w13
	fmul.4s	v2, v29, v16
	mov	w13, #38601                     ; =0x96c9
	movk	w13, #15030, lsl #16
	dup.4s	v23, w13
	fadd.4s	v2, v2, v23
	fmul.4s	v2, v29, v2
	mov	w13, #34982                     ; =0x88a6
	movk	w13, #15368, lsl #16
	dup.4s	v3, w13
	fadd.4s	v2, v2, v3
	fmul.4s	v12, v29, v2
	mov	w13, #43642                     ; =0xaa7a
	movk	w13, #15658, lsl #16
	dup.4s	v2, w13
	fadd.4s	v12, v12, v2
	fmul.4s	v12, v29, v12
	fadd.4s	v12, v12, v24
	fmul.4s	v12, v29, v12
	movi.4s	v27, #63, lsl #24
	fadd.4s	v12, v12, v27
	fmul.4s	v8, v29, v29
	fmul.4s	v8, v8, v12
	fadd.4s	v29, v29, v8
	fmov.4s	v30, #1.00000000
	fadd.4s	v29, v29, v30
	movi.2d	v8, #0xffffffffffffffff
	add.4s	v28, v28, v8
	sshr.4s	v8, v28, #1
	shl.4s	v12, v8, #23
	add.4s	v12, v12, v30
	fmul.4s	v29, v29, v12
	sub.4s	v28, v28, v8
	shl.4s	v28, v28, #23
	add.4s	v28, v28, v30
	fmul.4s	v28, v29, v28
	fcmgt.4s	v26, v26, v25
	ldr	q29, [sp, #496]                 ; 16-byte Reload
	bsl.16b	v26, v29, v28
	fmov.4s	v28, #0.25000000
	fdiv.4s	v28, v28, v26
	fsub.4s	v29, v26, v28
	fadd.4s	v26, v26, v28
	fdiv.4s	v26, v29, v26
	bsl.16b	v1, v26, v30
	mov.16b	v26, v9
	fcmge.4s	v20, v30, v20
	bit.16b	v1, v21, v20
	uzp1.8h	v20, v0, v9
	ldr	q21, [sp, #304]                 ; 16-byte Reload
	and.16b	v20, v20, v21
	addv.8h	h20, v20
	fmov	w13, s20
	mvni.4s	v20, #128, lsl #24
	bif.16b	v1, v19, v20
	fcmeq.4s	v19, v19, v19
	fadd.4s	v1, v1, v30
	ldr	q20, [sp, #480]                 ; 16-byte Reload
	bif.16b	v1, v20, v19
	fmul.4s	v18, v18, v27
	fmul.4s	v1, v18, v1
	add	x14, x27, x11
	ldr	q18, [x14]
	and.16b	v0, v0, v18
	ldr	q18, [x12, #16]
	fadd.4s	v19, v0, v1
	ldr	q0, [x14, #16]
	add	x11, x10, x11
	tbnz	w13, #0, LBB1_79
; %bb.71:                               ; %else99
                                        ;   in Loop: Header=BB1_70 Depth=2
	and	w12, w13, #0xff
	tbnz	w12, #1, LBB1_80
LBB1_72:                                ; %else101
                                        ;   in Loop: Header=BB1_70 Depth=2
	tbnz	w12, #2, LBB1_81
LBB1_73:                                ; %else103
                                        ;   in Loop: Header=BB1_70 Depth=2
	tbz	w12, #3, LBB1_75
LBB1_74:                                ; %cond.store104
                                        ;   in Loop: Header=BB1_70 Depth=2
	add	x13, x11, #12
	st1.s	{ v19 }[3], [x13]
LBB1_75:                                ; %else105
                                        ;   in Loop: Header=BB1_70 Depth=2
	and.16b	v18, v26, v18
	ldp	q21, q1, [sp, #448]             ; 32-byte Folded Reload
	fmul.4s	v1, v18, v1
	fmul.4s	v1, v18, v1
	fmul.4s	v1, v18, v1
	fadd.4s	v1, v18, v1
	ldr	q19, [sp, #432]                 ; 16-byte Reload
	fmul.4s	v1, v1, v19
	and.16b	v19, v26, v1
	fabs.4s	v20, v19
	fmul.4s	v1, v19, v19
	ldp	q26, q27, [sp, #400]            ; 32-byte Folded Reload
	fmla.4s	v21, v1, v27
	fmla.4s	v26, v1, v21
	mov.16b	v21, v31
	fmla.4s	v21, v1, v26
	mov.16b	v26, v10
	fmla.4s	v26, v1, v21
	mov.16b	v21, v24
	fmla.4s	v21, v1, v26
	fmov.4s	v26, #1.00000000
	fmla.4s	v26, v1, v21
	fmul.4s	v21, v20, v26
	mov.16b	v26, v11
	ldp	q27, q29, [sp, #368]            ; 32-byte Folded Reload
	fmla.4s	v26, v1, v29
	mov.16b	v28, v14
	fmla.4s	v28, v1, v26
	mov.16b	v26, v13
	fmla.4s	v26, v1, v28
	mov.16b	v28, v15
	fmla.4s	v28, v1, v26
	movi.4s	v26, #63, lsl #24
	fmla.4s	v26, v1, v28
	fmov.4s	v28, #1.00000000
	fmla.4s	v28, v1, v26
	fdiv.4s	v1, v21, v28
	fmov.4s	v21, #9.00000000
	fcmge.4s	v21, v21, v20
	and.16b	v26, v21, v20
	fcmge.4s	v28, v26, v27
	fcmge.4s	v29, v25, v26
	and.16b	v28, v28, v29
	and.16b	v28, v28, v26
	ldr	q27, [sp, #352]                 ; 16-byte Reload
	fmul.4s	v29, v28, v27
	movi.4s	v27, #75, lsl #24
	fadd.4s	v29, v29, v27
	movi.4s	v27, #203, lsl #24
	fadd.4s	v29, v29, v27
	fcvtzs.4s	v29, v29
	scvtf.4s	v8, v29
	fmul.4s	v12, v8, v6
	fadd.4s	v28, v28, v12
	fmul.4s	v8, v8, v7
	fadd.4s	v28, v28, v8
	fmul.4s	v8, v28, v16
	fadd.4s	v8, v8, v23
	fmul.4s	v8, v28, v8
	fadd.4s	v8, v8, v3
	fmul.4s	v8, v28, v8
	fadd.4s	v8, v8, v2
	fmul.4s	v8, v28, v8
	fadd.4s	v8, v8, v24
	fmul.4s	v8, v28, v8
	movi.4s	v27, #63, lsl #24
	fadd.4s	v8, v8, v27
	fmul.4s	v12, v28, v28
	fmul.4s	v8, v12, v8
	fadd.4s	v28, v28, v8
	fadd.4s	v28, v28, v30
	movi.2d	v8, #0xffffffffffffffff
	add.4s	v29, v29, v8
	sshr.4s	v8, v29, #1
	shl.4s	v12, v8, #23
	add.4s	v12, v12, v30
	fmul.4s	v28, v28, v12
	sub.4s	v29, v29, v8
	shl.4s	v29, v29, #23
	add.4s	v29, v29, v30
	fmul.4s	v28, v28, v29
	fcmgt.4s	v26, v26, v25
	ldr	q29, [sp, #496]                 ; 16-byte Reload
	bsl.16b	v26, v29, v28
	fmov.4s	v28, #0.25000000
	fdiv.4s	v28, v28, v26
	fsub.4s	v29, v26, v28
	fadd.4s	v26, v26, v28
	fdiv.4s	v26, v29, v26
	bsl.16b	v21, v26, v30
	fcmge.4s	v20, v30, v20
	bif.16b	v1, v21, v20
	mvni.4s	v20, #128, lsl #24
	bif.16b	v1, v19, v20
	fcmeq.4s	v19, v19, v19
	fadd.4s	v1, v1, v30
	ldr	q20, [sp, #480]                 ; 16-byte Reload
	bif.16b	v1, v20, v19
	fmul.4s	v18, v18, v27
	fmul.4s	v1, v18, v1
	and.16b	v0, v9, v0
	fadd.4s	v0, v0, v1
	tbnz	w12, #4, LBB1_82
; %bb.76:                               ; %else107
                                        ;   in Loop: Header=BB1_70 Depth=2
	ldp	q19, q18, [sp, #272]            ; 32-byte Folded Reload
	ldp	q27, q21, [sp, #240]            ; 32-byte Folded Reload
	tbnz	w12, #5, LBB1_83
LBB1_77:                                ; %else109
                                        ;   in Loop: Header=BB1_70 Depth=2
	tbnz	w12, #6, LBB1_84
LBB1_78:                                ; %else111
                                        ;   in Loop: Header=BB1_70 Depth=2
	tbz	w12, #7, LBB1_69
	b	LBB1_85
LBB1_79:                                ; %cond.store
                                        ;   in Loop: Header=BB1_70 Depth=2
	str	s19, [x11]
	and	w12, w13, #0xff
	tbz	w12, #1, LBB1_72
LBB1_80:                                ; %cond.store100
                                        ;   in Loop: Header=BB1_70 Depth=2
	add	x13, x11, #4
	st1.s	{ v19 }[1], [x13]
	tbz	w12, #2, LBB1_73
LBB1_81:                                ; %cond.store102
                                        ;   in Loop: Header=BB1_70 Depth=2
	add	x13, x11, #8
	st1.s	{ v19 }[2], [x13]
	tbnz	w12, #3, LBB1_74
	b	LBB1_75
LBB1_82:                                ; %cond.store106
                                        ;   in Loop: Header=BB1_70 Depth=2
	str	s0, [x11, #16]
	ldp	q19, q18, [sp, #272]            ; 32-byte Folded Reload
	ldp	q27, q21, [sp, #240]            ; 32-byte Folded Reload
	tbz	w12, #5, LBB1_77
LBB1_83:                                ; %cond.store108
                                        ;   in Loop: Header=BB1_70 Depth=2
	add	x13, x11, #20
	st1.s	{ v0 }[1], [x13]
	tbz	w12, #6, LBB1_78
LBB1_84:                                ; %cond.store110
                                        ;   in Loop: Header=BB1_70 Depth=2
	add	x13, x11, #24
	st1.s	{ v0 }[2], [x13]
	tbz	w12, #7, LBB1_69
LBB1_85:                                ; %cond.store112
                                        ;   in Loop: Header=BB1_70 Depth=2
	add	x11, x11, #28
	st1.s	{ v0 }[3], [x11]
	b	LBB1_69
LBB1_86:                                ; %direct.false58.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q0, [sp, #192]                  ; 16-byte Reload
	zip1.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q1, [sp, #128]                  ; 16-byte Reload
	and.16b	v1, v0, v1
	ldp	q18, q4, [sp, #448]             ; 32-byte Folded Reload
	fmul.4s	v4, v1, v4
	fmul.4s	v4, v1, v4
	fmul.4s	v4, v1, v4
	fadd.4s	v4, v1, v4
	ldp	q19, q5, [sp, #416]             ; 32-byte Folded Reload
	fmul.4s	v4, v4, v5
	and.16b	v4, v0, v4
	fabs.4s	v5, v4
	fmul.4s	v17, v4, v4
	fmla.4s	v18, v17, v19
	ldp	q20, q19, [sp, #384]            ; 32-byte Folded Reload
	fmla.4s	v19, v17, v18
	mov.16b	v18, v31
	fmla.4s	v18, v17, v19
	mov.16b	v19, v10
	fmla.4s	v19, v17, v18
	mov.16b	v18, v24
	fmla.4s	v18, v17, v19
	fmov.4s	v19, #1.00000000
	fmla.4s	v19, v17, v18
	fmul.4s	v18, v5, v19
	mov.16b	v19, v11
	fmla.4s	v19, v17, v20
	mov.16b	v20, v14
	fmla.4s	v20, v17, v19
	mov.16b	v19, v13
	fmla.4s	v19, v17, v20
	mov.16b	v20, v15
	fmla.4s	v20, v17, v19
	movi.4s	v19, #63, lsl #24
	fmla.4s	v19, v17, v20
	fmov.4s	v20, #1.00000000
	fmla.4s	v20, v17, v19
	fdiv.4s	v17, v18, v20
	fmov.4s	v18, #9.00000000
	fcmge.4s	v18, v18, v5
	and.16b	v19, v18, v5
	ldr	q20, [sp, #368]                 ; 16-byte Reload
	fcmge.4s	v20, v19, v20
	fcmge.4s	v21, v25, v19
	and.16b	v20, v20, v21
	and.16b	v20, v20, v19
	ldr	q21, [sp, #352]                 ; 16-byte Reload
	fmul.4s	v21, v20, v21
	movi.4s	v22, #75, lsl #24
	fadd.4s	v21, v21, v22
	movi.4s	v22, #203, lsl #24
	fadd.4s	v21, v21, v22
	fcvtzs.4s	v21, v21
	scvtf.4s	v22, v21
	fmul.4s	v26, v22, v6
	fadd.4s	v20, v20, v26
	fmul.4s	v22, v22, v7
	fadd.4s	v20, v20, v22
	fmul.4s	v22, v20, v16
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v3
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v2
	fmul.4s	v22, v20, v22
	fadd.4s	v22, v22, v24
	fmul.4s	v22, v20, v22
	movi.4s	v27, #63, lsl #24
	fadd.4s	v22, v22, v27
	fmul.4s	v26, v20, v20
	fmul.4s	v22, v26, v22
	fadd.4s	v20, v20, v22
	fmov.4s	v28, #1.00000000
	fadd.4s	v20, v20, v28
	movi.2d	v22, #0xffffffffffffffff
	add.4s	v21, v21, v22
	sshr.4s	v22, v21, #1
	shl.4s	v26, v22, #23
	add.4s	v26, v26, v28
	fmul.4s	v20, v20, v26
	sub.4s	v21, v21, v22
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v28
	fmul.4s	v20, v20, v21
	fcmgt.4s	v19, v19, v25
	ldr	q21, [sp, #496]                 ; 16-byte Reload
	bsl.16b	v19, v21, v20
	fmov.4s	v20, #0.25000000
	fdiv.4s	v20, v20, v19
	fsub.4s	v21, v19, v20
	fadd.4s	v19, v19, v20
	fdiv.4s	v19, v21, v19
	bsl.16b	v18, v19, v28
	fcmge.4s	v5, v28, v5
	bsl.16b	v5, v17, v18
	ldr	d17, [sp, #40]                  ; 8-byte Reload
	fmov	w10, s17
	mvni.4s	v17, #128, lsl #24
	bif.16b	v5, v4, v17
	fcmeq.4s	v4, v4, v4
	fadd.4s	v5, v5, v28
	ldr	q17, [sp, #480]                 ; 16-byte Reload
	bsl.16b	v4, v5, v17
	fmul.4s	v1, v1, v27
	fmul.4s	v1, v1, v4
	ldr	q4, [sp, #48]                   ; 16-byte Reload
	and.16b	v0, v0, v4
	fadd.4s	v0, v1, v0
	ldr	q4, [sp, #160]                  ; 16-byte Reload
	ldp	q5, q1, [sp, #96]               ; 32-byte Folded Reload
	stp	q4, q5, [sp, #512]
	str	q1, [sp, #544]
	ldr	q1, [sp, #80]                   ; 16-byte Reload
	str	q1, [sp, #560]
	and	x11, x9, #0x7
	add	x12, sp, #512
	ldr	x11, [x12, x11, lsl #3]
	sub	x9, x11, x9
	add	x8, x8, x9, lsl #2
	tbnz	w10, #0, LBB1_108
; %bb.87:                               ; %else116
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q1, [sp, #144]                  ; 16-byte Reload
	tbnz	w10, #1, LBB1_109
LBB1_88:                                ; %else118
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #2, LBB1_110
LBB1_89:                                ; %else120
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_91
LBB1_90:                                ; %cond.store121
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x8, #12
	st1.s	{ v0 }[3], [x9]
LBB1_91:                                ; %else122
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q0, [sp, #192]                  ; 16-byte Reload
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v1, v0, v1
	ldp	q17, q4, [sp, #448]             ; 32-byte Folded Reload
	fmul.4s	v4, v1, v4
	fmul.4s	v4, v1, v4
	fmul.4s	v4, v1, v4
	fadd.4s	v4, v1, v4
	ldp	q18, q5, [sp, #416]             ; 32-byte Folded Reload
	fmul.4s	v4, v4, v5
	and.16b	v4, v0, v4
	fmul.4s	v5, v4, v4
	fmla.4s	v17, v5, v18
	ldr	q18, [sp, #400]                 ; 16-byte Reload
	fmla.4s	v18, v5, v17
	fmla.4s	v31, v5, v18
	fmla.4s	v10, v5, v31
	mov.16b	v17, v24
	fmla.4s	v17, v5, v10
	fmov.4s	v18, #1.00000000
	fmla.4s	v18, v5, v17
	ldr	q17, [sp, #384]                 ; 16-byte Reload
	fmla.4s	v11, v5, v17
	fmla.4s	v14, v5, v11
	fmla.4s	v13, v5, v14
	fabs.4s	v17, v4
	fmul.4s	v18, v17, v18
	fmla.4s	v15, v5, v13
	movi.4s	v19, #63, lsl #24
	fmla.4s	v19, v5, v15
	fmov.4s	v20, #1.00000000
	fmla.4s	v20, v5, v19
	fdiv.4s	v5, v18, v20
	fmov.4s	v18, #9.00000000
	fcmge.4s	v18, v18, v17
	and.16b	v19, v18, v17
	ldr	q20, [sp, #368]                 ; 16-byte Reload
	fcmge.4s	v20, v19, v20
	fcmge.4s	v21, v25, v19
	and.16b	v20, v20, v21
	and.16b	v20, v20, v19
	ldr	q21, [sp, #352]                 ; 16-byte Reload
	fmul.4s	v21, v20, v21
	movi.4s	v22, #75, lsl #24
	fadd.4s	v21, v21, v22
	movi.4s	v22, #203, lsl #24
	fadd.4s	v21, v21, v22
	fcvtzs.4s	v21, v21
	scvtf.4s	v22, v21
	fmul.4s	v6, v22, v6
	fadd.4s	v6, v20, v6
	fmul.4s	v7, v22, v7
	fadd.4s	v6, v6, v7
	fmul.4s	v7, v6, v16
	fadd.4s	v7, v7, v23
	fmul.4s	v7, v6, v7
	fadd.4s	v3, v7, v3
	fmul.4s	v3, v6, v3
	fadd.4s	v2, v3, v2
	fmul.4s	v2, v6, v2
	fadd.4s	v2, v2, v24
	fmul.4s	v2, v6, v2
	movi.4s	v16, #63, lsl #24
	fadd.4s	v2, v2, v16
	fmul.4s	v3, v6, v6
	fmul.4s	v2, v3, v2
	fadd.4s	v2, v6, v2
	fmov.4s	v20, #1.00000000
	fadd.4s	v2, v2, v20
	movi.2d	v3, #0xffffffffffffffff
	add.4s	v3, v21, v3
	sshr.4s	v6, v3, #1
	shl.4s	v7, v6, #23
	add.4s	v7, v7, v20
	fmul.4s	v2, v2, v7
	sub.4s	v3, v3, v6
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v20
	fmul.4s	v2, v2, v3
	fcmgt.4s	v3, v19, v25
	ldr	q6, [sp, #496]                  ; 16-byte Reload
	bit.16b	v2, v6, v3
	fmov.4s	v3, #0.25000000
	fdiv.4s	v3, v3, v2
	fsub.4s	v6, v2, v3
	fadd.4s	v2, v2, v3
	fdiv.4s	v2, v6, v2
	bif.16b	v2, v20, v18
	fcmge.4s	v3, v20, v17
	bit.16b	v2, v5, v3
	mvni.4s	v3, #128, lsl #24
	bif.16b	v2, v4, v3
	fcmeq.4s	v3, v4, v4
	fadd.4s	v2, v2, v20
	ldr	q4, [sp, #480]                  ; 16-byte Reload
	bif.16b	v2, v4, v3
	fmul.4s	v1, v1, v16
	fmul.4s	v1, v1, v2
	ldr	q2, [sp, #64]                   ; 16-byte Reload
	and.16b	v0, v0, v2
	fadd.4s	v0, v1, v0
	tbnz	w10, #4, LBB1_111
; %bb.92:                               ; %else124
                                        ;   in Loop: Header=BB1_4 Depth=1
	movi.2s	v8, #65
	tbnz	w10, #5, LBB1_112
LBB1_93:                                ; %else126
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #6, LBB1_113
LBB1_94:                                ; %else128
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_2
	b	LBB1_114
LBB1_95:                                ; %cond.load27
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #4
	ld1.s	{ v20 }[1], [x15]
	tbz	w13, #2, LBB1_35
LBB1_96:                                ; %cond.load30
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #8
	ld1.s	{ v20 }[2], [x15]
	tbz	w13, #3, LBB1_36
LBB1_97:                                ; %cond.load33
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #12
	ld1.s	{ v20 }[3], [x15]
	tbz	w13, #4, LBB1_37
LBB1_98:                                ; %cond.load36
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #16
	ld1.s	{ v1 }[0], [x15]
	tbz	w13, #5, LBB1_38
LBB1_99:                                ; %cond.load39
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #20
	ld1.s	{ v1 }[1], [x15]
	tbz	w13, #6, LBB1_39
LBB1_100:                               ; %cond.load42
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #24
	ld1.s	{ v1 }[2], [x15]
	tbnz	w13, #7, LBB1_40
	b	LBB1_41
LBB1_101:                               ; %cond.load74
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v4 }[0], [x10]
	tbz	w12, #1, LBB1_61
LBB1_102:                               ; %cond.load77
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #4
	ld1.s	{ v4 }[1], [x14]
	tbz	w12, #2, LBB1_62
LBB1_103:                               ; %cond.load80
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #8
	ld1.s	{ v4 }[2], [x14]
	tbz	w12, #3, LBB1_63
LBB1_104:                               ; %cond.load83
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #12
	ld1.s	{ v4 }[3], [x14]
	tbz	w12, #4, LBB1_64
LBB1_105:                               ; %cond.load86
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #16
	ld1.s	{ v3 }[0], [x14]
	tbz	w12, #5, LBB1_65
LBB1_106:                               ; %cond.load89
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #20
	ld1.s	{ v3 }[1], [x14]
	tbz	w12, #6, LBB1_66
LBB1_107:                               ; %cond.load92
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #24
	ld1.s	{ v3 }[2], [x14]
	str	q20, [sp, #128]                 ; 16-byte Spill
	tbnz	w12, #7, LBB1_67
	b	LBB1_68
LBB1_108:                               ; %cond.store115
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x8]
	ldr	q1, [sp, #144]                  ; 16-byte Reload
	tbz	w10, #1, LBB1_88
LBB1_109:                               ; %cond.store117
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x8, #4
	st1.s	{ v0 }[1], [x9]
	tbz	w10, #2, LBB1_89
LBB1_110:                               ; %cond.store119
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x8, #8
	st1.s	{ v0 }[2], [x9]
	tbnz	w10, #3, LBB1_90
	b	LBB1_91
LBB1_111:                               ; %cond.store123
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x8, #16]
	movi.2s	v8, #65
	tbz	w10, #5, LBB1_93
LBB1_112:                               ; %cond.store125
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x8, #20
	st1.s	{ v0 }[1], [x9]
	tbz	w10, #6, LBB1_94
LBB1_113:                               ; %cond.store127
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x8, #24
	st1.s	{ v0 }[2], [x9]
	tbz	w10, #7, LBB1_2
LBB1_114:                               ; %cond.store129
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB1_2
LBB1_115:                               ; %block.batch.exit
	add	sp, sp, #1312
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh22, Lloh23
                                        ; -- End function
.subsections_via_symbols

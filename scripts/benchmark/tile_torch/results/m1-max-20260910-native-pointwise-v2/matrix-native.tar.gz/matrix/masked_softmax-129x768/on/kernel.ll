; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [6144 x i8], align 8
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local4 = alloca [768 x i8], align 1
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 96, i64 192, i64 288, i64 384, i64 480, i64 576, i64 672>, 1
  %tile_snapshot.local7 = alloca [3072 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [3072 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill13, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca i64, align 8
  store i64 0, ptr %.slot15, align 4
  %.spill16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill16, align 64
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %tile_snapshot.spill19 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill19, align 64
  %.slot20 = alloca i64, align 8
  store i64 0, ptr %.slot20, align 4
  %.slot21 = alloca i64, align 8
  store i64 0, ptr %.slot21, align 4
  %.slot22 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.slot23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot23, align 32
  %.slot24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot24, align 32
  %.slot25 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot25, align 32
  %.spill26 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill26, align 32
  %.spill27 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill27, align 32
  %.spill28 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill28, align 32
  %.spill29 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill29, align 4
  %tile_snapshot.spill30 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill30, align 64
  %.slot31 = alloca i64, align 8
  store i64 0, ptr %.slot31, align 4
  %.slot32 = alloca i64, align 8
  store i64 0, ptr %.slot32, align 4
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill37, align 4
  %.slot38 = alloca i64, align 8
  store i64 0, ptr %.slot38, align 4
  %10 = getelementptr i8, ptr %argument_buffer, i64 0
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 16
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 32
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = getelementptr i8, ptr %argument_buffer, i64 48
  %29 = load ptr, ptr %28, align 16
  %30 = getelementptr i8, ptr %28, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = insertvalue { ptr, i64 } poison, ptr %29, 0
  %33 = insertvalue { ptr, i64 } %32, i64 %31, 1
  %34 = load i32, ptr %launch_config, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 12
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 4
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 16
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 8
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 20
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 36
  %46 = load i32, ptr %45, align 4
  %.splatinsert39 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat40 = shufflevector <8 x i32> %.splatinsert39, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat40, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %48 = mul i32 %34, 32
  %.splatinsert41 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat42 = shufflevector <8 x i32> %.splatinsert41, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat42, %47
  %50 = mul i32 %38, 1
  %.splatinsert43 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat44 = shufflevector <8 x i32> %.splatinsert43, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat44, zeroinitializer
  %52 = mul i32 %42, 1
  %.splatinsert45 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat46 = shufflevector <8 x i32> %.splatinsert45, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat46, zeroinitializer
  %54 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %49, 0
  %55 = insertvalue [3 x <8 x i32>] %54, <8 x i32> %51, 1
  %56 = insertvalue [3 x <8 x i32>] %55, <8 x i32> %53, 2
  %.splatinsert47 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat48 = shufflevector <8 x i32> %.splatinsert47, <8 x i32> poison, <8 x i32> zeroinitializer
  %57 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat48
  %58 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  br i1 %58, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %59 = extractvalue [3 x <8 x i32>] %56, 0
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %57, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = sub <8 x i32> %59, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %63 = select <8 x i1> %57, <8 x i32> %62, <8 x i32> zeroinitializer
  %64 = select <8 x i1> %57, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %65 = lshr <8 x i32> %63, %64
  %66 = zext <8 x i32> %65 to <8 x i64>
  %67 = select <8 x i1> %57, <8 x i64> %66, <8 x i64> zeroinitializer
  %68 = select <8 x i1> %57, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %69 = sdiv <8 x i64> %67, %68
  %70 = load <8 x i64>, ptr %.spill13, align 64
  %71 = select <8 x i1> %57, <8 x i64> %69, <8 x i64> %70
  store <8 x i64> %71, ptr %.spill13, align 64
  %72 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %72, 0
  %75 = select <8 x i1> %57, <8 x ptr> %73, <8 x ptr> %74
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %77 = extractvalue { <8 x ptr>, <8 x i64> } %72, 1
  %78 = select <8 x i1> %57, <8 x i64> %76, <8 x i64> %77
  %79 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %75, 0
  %80 = insertvalue { <8 x ptr>, <8 x i64> } %79, <8 x i64> %78, 1
  store { <8 x ptr>, <8 x i64> } %80, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %81 = icmp slt i64 %.state, 96
  br i1 %81, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state49 = load i64, ptr %.slot, align 4
  %82 = mul i64 %.state49, 8
  %.splatinsert50 = insertelement <8 x i64> poison, i64 %82, i64 0
  %.splat51 = shufflevector <8 x i64> %.splatinsert50, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %83 = add <8 x i64> %.splat51, %.spill.load
  %.spill.load52 = load <8 x i64>, ptr %.spill13, align 64
  %84 = add <8 x i64> %.spill.load52, zeroinitializer
  %85 = add <8 x i64> zeroinitializer, %84
  %86 = add <8 x i64> zeroinitializer, %83
  %87 = mul <8 x i64> %85, splat (i64 768)
  %88 = add <8 x i64> %87, %86
  %89 = extractvalue { ptr, i64 } %15, 0
  %90 = extractelement <8 x i64> %88, i32 0
  %91 = sub i64 %90, 0
  %92 = mul i64 %91, 4
  %buffer.contiguous.address = getelementptr i8, ptr %89, i64 %92
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %57, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state53 = load i64, ptr %.slot, align 4
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %.state53, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %95 = mul <8 x i64> %.splat55, splat (i64 32)
  %96 = add <8 x i64> %94, %95
  %97 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %93, 0
  %98 = insertvalue { <8 x ptr>, <8 x i64> } %97, <8 x i64> %96, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %98, 1
  %101 = extractelement <8 x ptr> %99, i32 0
  %102 = extractelement <8 x i64> %100, i32 0
  %103 = sub i64 %102, 0
  %104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %105 = select i1 %104, i64 %103, i64 0
  %private.contiguous.address = getelementptr i8, ptr %101, i64 %105
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %106 = select <8 x i1> %57, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %106, ptr %private.contiguous.address, align 4
  %.state56 = load i64, ptr %.slot, align 4
  %107 = add i64 %.state56, 1
  store i64 %107, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %108, 0
  %111 = select <8 x i1> %57, <8 x ptr> %109, <8 x ptr> %110
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %113 = extractvalue { <8 x ptr>, <8 x i64> } %108, 1
  %114 = select <8 x i1> %57, <8 x i64> %112, <8 x i64> %113
  %115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %111, 0
  %116 = insertvalue { <8 x ptr>, <8 x i64> } %115, <8 x i64> %114, 1
  store { <8 x ptr>, <8 x i64> } %116, ptr %tile_snapshot.spill14, align 64
  store i64 0, ptr %.slot15, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state57 = load i64, ptr %.slot15, align 4
  %117 = icmp slt i64 %.state57, 96
  br i1 %117, label %direct.true58, label %direct.false59

direct.schedule.5:                                ; preds = %direct.true58
  %.state60 = load i64, ptr %.slot15, align 4
  %118 = mul i64 %.state60, 8
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %118, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load63 = load <8 x i64>, ptr %.spill, align 64
  %119 = add <8 x i64> %.splat62, %.spill.load63
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %.state65 = load i64, ptr %.slot15, align 4
  %.splatinsert66 = insertelement <8 x i64> poison, i64 %.state65, i64 0
  %.splat67 = shufflevector <8 x i64> %.splatinsert66, <8 x i64> poison, <8 x i32> zeroinitializer
  %122 = mul <8 x i64> %.splat67, splat (i64 64)
  %123 = add <8 x i64> %121, %122
  %124 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %120, 0
  %125 = insertvalue { <8 x ptr>, <8 x i64> } %124, <8 x i64> %123, 1
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %125, 1
  %128 = extractelement <8 x ptr> %126, i32 0
  %129 = extractelement <8 x i64> %127, i32 0
  %130 = sub i64 %129, 0
  %131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %132 = select i1 %131, i64 %130, i64 0
  %private.contiguous.address68 = getelementptr i8, ptr %128, i64 %132
  %private.contiguous.preserve69 = load <8 x i64>, ptr %private.contiguous.address68, align 8
  %133 = select <8 x i1> %57, <8 x i64> %119, <8 x i64> %private.contiguous.preserve69
  store <8 x i64> %133, ptr %private.contiguous.address68, align 8
  %.state70 = load i64, ptr %.slot15, align 4
  %134 = add i64 %.state70, 1
  store i64 %134, ptr %.slot15, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false59
  %.spill.load71 = load <8 x i64>, ptr %.spill13, align 64
  %135 = select <8 x i1> %57, <8 x i64> %.spill.load71, <8 x i64> zeroinitializer
  %136 = select <8 x i1> %57, <8 x i64> splat (i64 768), <8 x i64> splat (i64 1)
  %137 = srem <8 x i64> %135, %136
  %138 = load <8 x i64>, ptr %.spill16, align 64
  %139 = select <8 x i1> %57, <8 x i64> %137, <8 x i64> %138
  store <8 x i64> %139, ptr %.spill16, align 64
  %140 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 0
  %143 = select <8 x i1> %57, <8 x ptr> %141, <8 x ptr> %142
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %146 = select <8 x i1> %57, <8 x i64> %144, <8 x i64> %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  store { <8 x ptr>, <8 x i64> } %148, ptr %tile_snapshot.spill17, align 64
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state72 = load i64, ptr %.slot18, align 4
  %149 = icmp slt i64 %.state72, 96
  br i1 %149, label %direct.true73, label %direct.false74

direct.schedule.8:                                ; preds = %direct.true73
  %tile_snapshot.spill.load75 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 1
  %.state76 = load i64, ptr %.slot18, align 4
  %.splatinsert77 = insertelement <8 x i64> poison, i64 %.state76, i64 0
  %.splat78 = shufflevector <8 x i64> %.splatinsert77, <8 x i64> poison, <8 x i32> zeroinitializer
  %152 = mul <8 x i64> %.splat78, splat (i64 64)
  %153 = add <8 x i64> %151, %152
  %154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %150, 0
  %155 = insertvalue { <8 x ptr>, <8 x i64> } %154, <8 x i64> %153, 1
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %155, 1
  %158 = extractelement <8 x ptr> %156, i32 0
  %159 = extractelement <8 x i64> %157, i32 0
  %160 = sub i64 %159, 0
  %161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %162 = select i1 %161, i64 %160, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %158, i64 %162
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address79, align 8
  %163 = select <8 x i1> %57, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load80 = load <8 x i64>, ptr %.spill16, align 64
  %164 = icmp sle <8 x i64> %163, %.spill.load80
  %tile_snapshot.spill.load81 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 0
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 1
  %.state82 = load i64, ptr %.slot18, align 4
  %.splatinsert83 = insertelement <8 x i64> poison, i64 %.state82, i64 0
  %.splat84 = shufflevector <8 x i64> %.splatinsert83, <8 x i64> poison, <8 x i32> zeroinitializer
  %167 = add <8 x i64> %166, %.splat84
  %168 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %165, 0
  %169 = insertvalue { <8 x ptr>, <8 x i64> } %168, <8 x i64> %167, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %169, 0
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %169, 1
  %172 = getelementptr i8, <8 x ptr> %170, <8 x i64> %171
  %173 = zext <8 x i1> %164 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %173, <8 x ptr> align 1 %172, <8 x i1> %57)
  %.state85 = load i64, ptr %.slot18, align 4
  %174 = add i64 %.state85, 1
  store i64 %174, ptr %.slot18, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false74
  %175 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %175, 0
  %178 = select <8 x i1> %57, <8 x ptr> %176, <8 x ptr> %177
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %175, 1
  %181 = select <8 x i1> %57, <8 x i64> %179, <8 x i64> %180
  %182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %178, 0
  %183 = insertvalue { <8 x ptr>, <8 x i64> } %182, <8 x i64> %181, 1
  store { <8 x ptr>, <8 x i64> } %183, ptr %tile_snapshot.spill19, align 64
  store i64 0, ptr %.slot20, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state86 = load i64, ptr %.slot20, align 4
  %184 = icmp slt i64 %.state86, 96
  br i1 %184, label %direct.true87, label %direct.false88

direct.schedule.11:                               ; preds = %direct.true87
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.state90 = load i64, ptr %.slot20, align 4
  %.splatinsert91 = insertelement <8 x i64> poison, i64 %.state90, i64 0
  %.splat92 = shufflevector <8 x i64> %.splatinsert91, <8 x i64> poison, <8 x i32> zeroinitializer
  %187 = add <8 x i64> %186, %.splat92
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %185, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %189, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = getelementptr i8, <8 x ptr> %190, <8 x i64> %191
  %193 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %192, <8 x i1> %57, <8 x i8> zeroinitializer)
  %194 = icmp ne <8 x i8> %193, zeroinitializer
  %tile_snapshot.spill.load93 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 1
  %.state94 = load i64, ptr %.slot20, align 4
  %.splatinsert95 = insertelement <8 x i64> poison, i64 %.state94, i64 0
  %.splat96 = shufflevector <8 x i64> %.splatinsert95, <8 x i64> poison, <8 x i32> zeroinitializer
  %197 = mul <8 x i64> %.splat96, splat (i64 32)
  %198 = add <8 x i64> %196, %197
  %199 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %195, 0
  %200 = insertvalue { <8 x ptr>, <8 x i64> } %199, <8 x i64> %198, 1
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %200, 1
  %203 = extractelement <8 x ptr> %201, i32 0
  %204 = extractelement <8 x i64> %202, i32 0
  %205 = sub i64 %204, 0
  %206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %207 = select i1 %206, i64 %205, i64 0
  %private.contiguous.address97 = getelementptr i8, ptr %203, i64 %207
  %private.contiguous.load98 = load <8 x float>, ptr %private.contiguous.address97, align 4
  %208 = select <8 x i1> %57, <8 x float> %private.contiguous.load98, <8 x float> zeroinitializer
  %209 = select <8 x i1> %194, <8 x float> %208, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %.state100 = load i64, ptr %.slot20, align 4
  %.splatinsert101 = insertelement <8 x i64> poison, i64 %.state100, i64 0
  %.splat102 = shufflevector <8 x i64> %.splatinsert101, <8 x i64> poison, <8 x i32> zeroinitializer
  %212 = mul <8 x i64> %.splat102, splat (i64 32)
  %213 = add <8 x i64> %211, %212
  %214 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %210, 0
  %215 = insertvalue { <8 x ptr>, <8 x i64> } %214, <8 x i64> %213, 1
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %215, 1
  %218 = extractelement <8 x ptr> %216, i32 0
  %219 = extractelement <8 x i64> %217, i32 0
  %220 = sub i64 %219, 0
  %221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %222 = select i1 %221, i64 %220, i64 0
  %private.contiguous.address103 = getelementptr i8, ptr %218, i64 %222
  %private.contiguous.preserve104 = load <8 x float>, ptr %private.contiguous.address103, align 4
  %223 = select <8 x i1> %57, <8 x float> %209, <8 x float> %private.contiguous.preserve104
  store <8 x float> %223, ptr %private.contiguous.address103, align 4
  %.state105 = load i64, ptr %.slot20, align 4
  %224 = add i64 %.state105, 1
  store i64 %224, ptr %.slot20, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false88
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %227 = add <8 x i64> %226, zeroinitializer
  %228 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %225, 0
  %229 = insertvalue { <8 x ptr>, <8 x i64> } %228, <8 x i64> %227, 1
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %229, 1
  %232 = extractelement <8 x ptr> %230, i32 0
  %233 = extractelement <8 x i64> %231, i32 0
  %234 = sub i64 %233, 0
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %236 = select i1 %235, i64 %234, i64 0
  %private.contiguous.address107 = getelementptr i8, ptr %232, i64 %236
  %private.contiguous.load108 = load <8 x float>, ptr %private.contiguous.address107, align 4
  %237 = select <8 x i1> %57, <8 x float> %private.contiguous.load108, <8 x float> zeroinitializer
  %tile_snapshot.spill.load109 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 0
  %239 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 1
  %240 = add <8 x i64> %239, splat (i64 32)
  %241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %238, 0
  %242 = insertvalue { <8 x ptr>, <8 x i64> } %241, <8 x i64> %240, 1
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %245 = extractelement <8 x ptr> %243, i32 0
  %246 = extractelement <8 x i64> %244, i32 0
  %247 = sub i64 %246, 0
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %249 = select i1 %248, i64 %247, i64 0
  %private.contiguous.address110 = getelementptr i8, ptr %245, i64 %249
  %private.contiguous.load111 = load <8 x float>, ptr %private.contiguous.address110, align 4
  %250 = select <8 x i1> %57, <8 x float> %private.contiguous.load111, <8 x float> zeroinitializer
  %tile_snapshot.spill.load112 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load112, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load112, 1
  %253 = add <8 x i64> %252, splat (i64 64)
  %254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %251, 0
  %255 = insertvalue { <8 x ptr>, <8 x i64> } %254, <8 x i64> %253, 1
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %255, 1
  %258 = extractelement <8 x ptr> %256, i32 0
  %259 = extractelement <8 x i64> %257, i32 0
  %260 = sub i64 %259, 0
  %261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %262 = select i1 %261, i64 %260, i64 0
  %private.contiguous.address113 = getelementptr i8, ptr %258, i64 %262
  %private.contiguous.load114 = load <8 x float>, ptr %private.contiguous.address113, align 4
  %263 = select <8 x i1> %57, <8 x float> %private.contiguous.load114, <8 x float> zeroinitializer
  %tile_snapshot.spill.load115 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 0
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 1
  %266 = add <8 x i64> %265, splat (i64 96)
  %267 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %264, 0
  %268 = insertvalue { <8 x ptr>, <8 x i64> } %267, <8 x i64> %266, 1
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %268, 1
  %271 = extractelement <8 x ptr> %269, i32 0
  %272 = extractelement <8 x i64> %270, i32 0
  %273 = sub i64 %272, 0
  %274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %275 = select i1 %274, i64 %273, i64 0
  %private.contiguous.address116 = getelementptr i8, ptr %271, i64 %275
  %private.contiguous.load117 = load <8 x float>, ptr %private.contiguous.address116, align 4
  %276 = select <8 x i1> %57, <8 x float> %private.contiguous.load117, <8 x float> zeroinitializer
  store i64 4, ptr %.slot21, align 4
  %277 = load <8 x float>, ptr %.slot22, align 32
  %278 = select <8 x i1> %57, <8 x float> %237, <8 x float> %277
  store <8 x float> %278, ptr %.slot22, align 32
  %279 = load <8 x float>, ptr %.slot23, align 32
  %280 = select <8 x i1> %57, <8 x float> %250, <8 x float> %279
  store <8 x float> %280, ptr %.slot23, align 32
  %281 = load <8 x float>, ptr %.slot24, align 32
  %282 = select <8 x i1> %57, <8 x float> %263, <8 x float> %281
  store <8 x float> %282, ptr %.slot24, align 32
  %283 = load <8 x float>, ptr %.slot25, align 32
  %284 = select <8 x i1> %57, <8 x float> %276, <8 x float> %283
  store <8 x float> %284, ptr %.slot25, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state118 = load i64, ptr %.slot21, align 4
  %285 = icmp slt i64 %.state118, 96
  br i1 %285, label %direct.true119, label %direct.false120

direct.schedule.14:                               ; preds = %direct.true119
  %.state121 = load i64, ptr %.slot21, align 4
  %286 = add i64 %.state121, 0
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %.splatinsert123 = insertelement <8 x i64> poison, i64 %286, i64 0
  %.splat124 = shufflevector <8 x i64> %.splatinsert123, <8 x i64> poison, <8 x i32> zeroinitializer
  %289 = mul <8 x i64> %.splat124, splat (i64 32)
  %290 = add <8 x i64> %288, %289
  %291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %287, 0
  %292 = insertvalue { <8 x ptr>, <8 x i64> } %291, <8 x i64> %290, 1
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %292, 1
  %295 = extractelement <8 x ptr> %293, i32 0
  %296 = extractelement <8 x i64> %294, i32 0
  %297 = sub i64 %296, 0
  %298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %299 = select i1 %298, i64 %297, i64 0
  %private.contiguous.address125 = getelementptr i8, ptr %295, i64 %299
  %private.contiguous.load126 = load <8 x float>, ptr %private.contiguous.address125, align 4
  %300 = select <8 x i1> %57, <8 x float> %private.contiguous.load126, <8 x float> zeroinitializer
  %.state127 = load <8 x float>, ptr %.slot22, align 32
  %301 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state127, <8 x float> %300)
  %.state128 = load i64, ptr %.slot21, align 4
  %302 = add i64 %.state128, 1
  %tile_snapshot.spill.load129 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 0
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 1
  %.splatinsert130 = insertelement <8 x i64> poison, i64 %302, i64 0
  %.splat131 = shufflevector <8 x i64> %.splatinsert130, <8 x i64> poison, <8 x i32> zeroinitializer
  %305 = mul <8 x i64> %.splat131, splat (i64 32)
  %306 = add <8 x i64> %304, %305
  %307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %303, 0
  %308 = insertvalue { <8 x ptr>, <8 x i64> } %307, <8 x i64> %306, 1
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %308, 1
  %311 = extractelement <8 x ptr> %309, i32 0
  %312 = extractelement <8 x i64> %310, i32 0
  %313 = sub i64 %312, 0
  %314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %315 = select i1 %314, i64 %313, i64 0
  %private.contiguous.address132 = getelementptr i8, ptr %311, i64 %315
  %private.contiguous.load133 = load <8 x float>, ptr %private.contiguous.address132, align 4
  %316 = select <8 x i1> %57, <8 x float> %private.contiguous.load133, <8 x float> zeroinitializer
  %.state134 = load <8 x float>, ptr %.slot23, align 32
  %317 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state134, <8 x float> %316)
  %.state135 = load i64, ptr %.slot21, align 4
  %318 = add i64 %.state135, 2
  %tile_snapshot.spill.load136 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 0
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 1
  %.splatinsert137 = insertelement <8 x i64> poison, i64 %318, i64 0
  %.splat138 = shufflevector <8 x i64> %.splatinsert137, <8 x i64> poison, <8 x i32> zeroinitializer
  %321 = mul <8 x i64> %.splat138, splat (i64 32)
  %322 = add <8 x i64> %320, %321
  %323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %319, 0
  %324 = insertvalue { <8 x ptr>, <8 x i64> } %323, <8 x i64> %322, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %324, 1
  %327 = extractelement <8 x ptr> %325, i32 0
  %328 = extractelement <8 x i64> %326, i32 0
  %329 = sub i64 %328, 0
  %330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %331 = select i1 %330, i64 %329, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %327, i64 %331
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %332 = select <8 x i1> %57, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %.state141 = load <8 x float>, ptr %.slot24, align 32
  %333 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state141, <8 x float> %332)
  %.state142 = load i64, ptr %.slot21, align 4
  %334 = add i64 %.state142, 3
  %tile_snapshot.spill.load143 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 0
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 1
  %.splatinsert144 = insertelement <8 x i64> poison, i64 %334, i64 0
  %.splat145 = shufflevector <8 x i64> %.splatinsert144, <8 x i64> poison, <8 x i32> zeroinitializer
  %337 = mul <8 x i64> %.splat145, splat (i64 32)
  %338 = add <8 x i64> %336, %337
  %339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %335, 0
  %340 = insertvalue { <8 x ptr>, <8 x i64> } %339, <8 x i64> %338, 1
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %340, 1
  %343 = extractelement <8 x ptr> %341, i32 0
  %344 = extractelement <8 x i64> %342, i32 0
  %345 = sub i64 %344, 0
  %346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %347 = select i1 %346, i64 %345, i64 0
  %private.contiguous.address146 = getelementptr i8, ptr %343, i64 %347
  %private.contiguous.load147 = load <8 x float>, ptr %private.contiguous.address146, align 4
  %348 = select <8 x i1> %57, <8 x float> %private.contiguous.load147, <8 x float> zeroinitializer
  %.state148 = load <8 x float>, ptr %.slot25, align 32
  %349 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state148, <8 x float> %348)
  %.state149 = load i64, ptr %.slot21, align 4
  %350 = add i64 %.state149, 4
  store i64 %350, ptr %.slot21, align 4
  %351 = load <8 x float>, ptr %.slot22, align 32
  %352 = select <8 x i1> %57, <8 x float> %301, <8 x float> %351
  store <8 x float> %352, ptr %.slot22, align 32
  %353 = load <8 x float>, ptr %.slot23, align 32
  %354 = select <8 x i1> %57, <8 x float> %317, <8 x float> %353
  store <8 x float> %354, ptr %.slot23, align 32
  %355 = load <8 x float>, ptr %.slot24, align 32
  %356 = select <8 x i1> %57, <8 x float> %333, <8 x float> %355
  store <8 x float> %356, ptr %.slot24, align 32
  %357 = load <8 x float>, ptr %.slot25, align 32
  %358 = select <8 x i1> %57, <8 x float> %349, <8 x float> %357
  store <8 x float> %358, ptr %.slot25, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false120
  %.state150 = load <8 x float>, ptr %.slot22, align 32
  %.state151 = load <8 x float>, ptr %.slot23, align 32
  %359 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state150, <8 x float> %.state151)
  %.state152 = load <8 x float>, ptr %.slot24, align 32
  %360 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %359, <8 x float> %.state152)
  %.state153 = load <8 x float>, ptr %.slot25, align 32
  %361 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %360, <8 x float> %.state153)
  %.spill.load154 = load <8 x i64>, ptr %.spill, align 64
  %362 = trunc <8 x i64> %.spill.load154 to <8 x i32>
  %363 = xor <8 x i32> %362, splat (i32 1)
  %364 = load <8 x i32>, ptr %.spill26, align 32
  %365 = select <8 x i1> %57, <8 x i32> %363, <8 x i32> %364
  store <8 x i32> %365, ptr %.spill26, align 32
  %366 = extractelement <8 x i32> %363, i64 0
  %367 = icmp ult i32 %366, 8
  %368 = select i1 %367, i32 %366, i32 0
  %369 = extractelement <8 x i1> %57, i32 %368
  %370 = extractelement <8 x i1> %57, i64 0
  %371 = and i1 %367, %369
  %372 = and i1 %370, %371
  %373 = extractelement <8 x float> %361, i32 %368
  %374 = select i1 %372, float %373, float 0.000000e+00
  %375 = insertelement <8 x float> poison, float %374, i64 0
  %376 = xor i1 %372, true
  %377 = and i1 %370, %376
  %378 = insertelement <8 x i1> poison, i1 %377, i64 0
  %379 = extractelement <8 x i32> %363, i64 1
  %380 = icmp ult i32 %379, 8
  %381 = select i1 %380, i32 %379, i32 0
  %382 = extractelement <8 x i1> %57, i32 %381
  %383 = extractelement <8 x i1> %57, i64 1
  %384 = and i1 %380, %382
  %385 = and i1 %383, %384
  %386 = extractelement <8 x float> %361, i32 %381
  %387 = select i1 %385, float %386, float 0.000000e+00
  %388 = insertelement <8 x float> %375, float %387, i64 1
  %389 = xor i1 %385, true
  %390 = and i1 %383, %389
  %391 = insertelement <8 x i1> %378, i1 %390, i64 1
  %392 = extractelement <8 x i32> %363, i64 2
  %393 = icmp ult i32 %392, 8
  %394 = select i1 %393, i32 %392, i32 0
  %395 = extractelement <8 x i1> %57, i32 %394
  %396 = extractelement <8 x i1> %57, i64 2
  %397 = and i1 %393, %395
  %398 = and i1 %396, %397
  %399 = extractelement <8 x float> %361, i32 %394
  %400 = select i1 %398, float %399, float 0.000000e+00
  %401 = insertelement <8 x float> %388, float %400, i64 2
  %402 = xor i1 %398, true
  %403 = and i1 %396, %402
  %404 = insertelement <8 x i1> %391, i1 %403, i64 2
  %405 = extractelement <8 x i32> %363, i64 3
  %406 = icmp ult i32 %405, 8
  %407 = select i1 %406, i32 %405, i32 0
  %408 = extractelement <8 x i1> %57, i32 %407
  %409 = extractelement <8 x i1> %57, i64 3
  %410 = and i1 %406, %408
  %411 = and i1 %409, %410
  %412 = extractelement <8 x float> %361, i32 %407
  %413 = select i1 %411, float %412, float 0.000000e+00
  %414 = insertelement <8 x float> %401, float %413, i64 3
  %415 = xor i1 %411, true
  %416 = and i1 %409, %415
  %417 = insertelement <8 x i1> %404, i1 %416, i64 3
  %418 = extractelement <8 x i32> %363, i64 4
  %419 = icmp ult i32 %418, 8
  %420 = select i1 %419, i32 %418, i32 0
  %421 = extractelement <8 x i1> %57, i32 %420
  %422 = extractelement <8 x i1> %57, i64 4
  %423 = and i1 %419, %421
  %424 = and i1 %422, %423
  %425 = extractelement <8 x float> %361, i32 %420
  %426 = select i1 %424, float %425, float 0.000000e+00
  %427 = insertelement <8 x float> %414, float %426, i64 4
  %428 = xor i1 %424, true
  %429 = and i1 %422, %428
  %430 = insertelement <8 x i1> %417, i1 %429, i64 4
  %431 = extractelement <8 x i32> %363, i64 5
  %432 = icmp ult i32 %431, 8
  %433 = select i1 %432, i32 %431, i32 0
  %434 = extractelement <8 x i1> %57, i32 %433
  %435 = extractelement <8 x i1> %57, i64 5
  %436 = and i1 %432, %434
  %437 = and i1 %435, %436
  %438 = extractelement <8 x float> %361, i32 %433
  %439 = select i1 %437, float %438, float 0.000000e+00
  %440 = insertelement <8 x float> %427, float %439, i64 5
  %441 = xor i1 %437, true
  %442 = and i1 %435, %441
  %443 = insertelement <8 x i1> %430, i1 %442, i64 5
  %444 = extractelement <8 x i32> %363, i64 6
  %445 = icmp ult i32 %444, 8
  %446 = select i1 %445, i32 %444, i32 0
  %447 = extractelement <8 x i1> %57, i32 %446
  %448 = extractelement <8 x i1> %57, i64 6
  %449 = and i1 %445, %447
  %450 = and i1 %448, %449
  %451 = extractelement <8 x float> %361, i32 %446
  %452 = select i1 %450, float %451, float 0.000000e+00
  %453 = insertelement <8 x float> %440, float %452, i64 6
  %454 = xor i1 %450, true
  %455 = and i1 %448, %454
  %456 = insertelement <8 x i1> %443, i1 %455, i64 6
  %457 = extractelement <8 x i32> %363, i64 7
  %458 = icmp ult i32 %457, 8
  %459 = select i1 %458, i32 %457, i32 0
  %460 = extractelement <8 x i1> %57, i32 %459
  %461 = extractelement <8 x i1> %57, i64 7
  %462 = and i1 %458, %460
  %463 = and i1 %461, %462
  %464 = extractelement <8 x float> %361, i32 %459
  %465 = select i1 %463, float %464, float 0.000000e+00
  %466 = insertelement <8 x float> %453, float %465, i64 7
  %467 = xor i1 %463, true
  %468 = and i1 %461, %467
  %469 = insertelement <8 x i1> %456, i1 %468, i64 7
  %470 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %361, <8 x float> %466)
  %471 = xor <8 x i32> %362, splat (i32 2)
  %472 = load <8 x i32>, ptr %.spill27, align 32
  %473 = select <8 x i1> %57, <8 x i32> %471, <8 x i32> %472
  store <8 x i32> %473, ptr %.spill27, align 32
  %474 = extractelement <8 x i32> %471, i64 0
  %475 = icmp ult i32 %474, 8
  %476 = select i1 %475, i32 %474, i32 0
  %477 = extractelement <8 x i1> %57, i32 %476
  %478 = extractelement <8 x i1> %57, i64 0
  %479 = and i1 %475, %477
  %480 = and i1 %478, %479
  %481 = extractelement <8 x float> %470, i32 %476
  %482 = select i1 %480, float %481, float 0.000000e+00
  %483 = insertelement <8 x float> poison, float %482, i64 0
  %484 = xor i1 %480, true
  %485 = and i1 %478, %484
  %486 = insertelement <8 x i1> poison, i1 %485, i64 0
  %487 = extractelement <8 x i32> %471, i64 1
  %488 = icmp ult i32 %487, 8
  %489 = select i1 %488, i32 %487, i32 0
  %490 = extractelement <8 x i1> %57, i32 %489
  %491 = extractelement <8 x i1> %57, i64 1
  %492 = and i1 %488, %490
  %493 = and i1 %491, %492
  %494 = extractelement <8 x float> %470, i32 %489
  %495 = select i1 %493, float %494, float 0.000000e+00
  %496 = insertelement <8 x float> %483, float %495, i64 1
  %497 = xor i1 %493, true
  %498 = and i1 %491, %497
  %499 = insertelement <8 x i1> %486, i1 %498, i64 1
  %500 = extractelement <8 x i32> %471, i64 2
  %501 = icmp ult i32 %500, 8
  %502 = select i1 %501, i32 %500, i32 0
  %503 = extractelement <8 x i1> %57, i32 %502
  %504 = extractelement <8 x i1> %57, i64 2
  %505 = and i1 %501, %503
  %506 = and i1 %504, %505
  %507 = extractelement <8 x float> %470, i32 %502
  %508 = select i1 %506, float %507, float 0.000000e+00
  %509 = insertelement <8 x float> %496, float %508, i64 2
  %510 = xor i1 %506, true
  %511 = and i1 %504, %510
  %512 = insertelement <8 x i1> %499, i1 %511, i64 2
  %513 = extractelement <8 x i32> %471, i64 3
  %514 = icmp ult i32 %513, 8
  %515 = select i1 %514, i32 %513, i32 0
  %516 = extractelement <8 x i1> %57, i32 %515
  %517 = extractelement <8 x i1> %57, i64 3
  %518 = and i1 %514, %516
  %519 = and i1 %517, %518
  %520 = extractelement <8 x float> %470, i32 %515
  %521 = select i1 %519, float %520, float 0.000000e+00
  %522 = insertelement <8 x float> %509, float %521, i64 3
  %523 = xor i1 %519, true
  %524 = and i1 %517, %523
  %525 = insertelement <8 x i1> %512, i1 %524, i64 3
  %526 = extractelement <8 x i32> %471, i64 4
  %527 = icmp ult i32 %526, 8
  %528 = select i1 %527, i32 %526, i32 0
  %529 = extractelement <8 x i1> %57, i32 %528
  %530 = extractelement <8 x i1> %57, i64 4
  %531 = and i1 %527, %529
  %532 = and i1 %530, %531
  %533 = extractelement <8 x float> %470, i32 %528
  %534 = select i1 %532, float %533, float 0.000000e+00
  %535 = insertelement <8 x float> %522, float %534, i64 4
  %536 = xor i1 %532, true
  %537 = and i1 %530, %536
  %538 = insertelement <8 x i1> %525, i1 %537, i64 4
  %539 = extractelement <8 x i32> %471, i64 5
  %540 = icmp ult i32 %539, 8
  %541 = select i1 %540, i32 %539, i32 0
  %542 = extractelement <8 x i1> %57, i32 %541
  %543 = extractelement <8 x i1> %57, i64 5
  %544 = and i1 %540, %542
  %545 = and i1 %543, %544
  %546 = extractelement <8 x float> %470, i32 %541
  %547 = select i1 %545, float %546, float 0.000000e+00
  %548 = insertelement <8 x float> %535, float %547, i64 5
  %549 = xor i1 %545, true
  %550 = and i1 %543, %549
  %551 = insertelement <8 x i1> %538, i1 %550, i64 5
  %552 = extractelement <8 x i32> %471, i64 6
  %553 = icmp ult i32 %552, 8
  %554 = select i1 %553, i32 %552, i32 0
  %555 = extractelement <8 x i1> %57, i32 %554
  %556 = extractelement <8 x i1> %57, i64 6
  %557 = and i1 %553, %555
  %558 = and i1 %556, %557
  %559 = extractelement <8 x float> %470, i32 %554
  %560 = select i1 %558, float %559, float 0.000000e+00
  %561 = insertelement <8 x float> %548, float %560, i64 6
  %562 = xor i1 %558, true
  %563 = and i1 %556, %562
  %564 = insertelement <8 x i1> %551, i1 %563, i64 6
  %565 = extractelement <8 x i32> %471, i64 7
  %566 = icmp ult i32 %565, 8
  %567 = select i1 %566, i32 %565, i32 0
  %568 = extractelement <8 x i1> %57, i32 %567
  %569 = extractelement <8 x i1> %57, i64 7
  %570 = and i1 %566, %568
  %571 = and i1 %569, %570
  %572 = extractelement <8 x float> %470, i32 %567
  %573 = select i1 %571, float %572, float 0.000000e+00
  %574 = insertelement <8 x float> %561, float %573, i64 7
  %575 = xor i1 %571, true
  %576 = and i1 %569, %575
  %577 = insertelement <8 x i1> %564, i1 %576, i64 7
  %578 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %470, <8 x float> %574)
  %579 = xor <8 x i32> %362, splat (i32 4)
  %580 = load <8 x i32>, ptr %.spill28, align 32
  %581 = select <8 x i1> %57, <8 x i32> %579, <8 x i32> %580
  store <8 x i32> %581, ptr %.spill28, align 32
  %582 = extractelement <8 x i32> %579, i64 0
  %583 = icmp ult i32 %582, 8
  %584 = select i1 %583, i32 %582, i32 0
  %585 = extractelement <8 x i1> %57, i32 %584
  %586 = extractelement <8 x i1> %57, i64 0
  %587 = and i1 %583, %585
  %588 = and i1 %586, %587
  %589 = extractelement <8 x float> %578, i32 %584
  %590 = select i1 %588, float %589, float 0.000000e+00
  %591 = insertelement <8 x float> poison, float %590, i64 0
  %592 = xor i1 %588, true
  %593 = and i1 %586, %592
  %594 = insertelement <8 x i1> poison, i1 %593, i64 0
  %595 = extractelement <8 x i32> %579, i64 1
  %596 = icmp ult i32 %595, 8
  %597 = select i1 %596, i32 %595, i32 0
  %598 = extractelement <8 x i1> %57, i32 %597
  %599 = extractelement <8 x i1> %57, i64 1
  %600 = and i1 %596, %598
  %601 = and i1 %599, %600
  %602 = extractelement <8 x float> %578, i32 %597
  %603 = select i1 %601, float %602, float 0.000000e+00
  %604 = insertelement <8 x float> %591, float %603, i64 1
  %605 = xor i1 %601, true
  %606 = and i1 %599, %605
  %607 = insertelement <8 x i1> %594, i1 %606, i64 1
  %608 = extractelement <8 x i32> %579, i64 2
  %609 = icmp ult i32 %608, 8
  %610 = select i1 %609, i32 %608, i32 0
  %611 = extractelement <8 x i1> %57, i32 %610
  %612 = extractelement <8 x i1> %57, i64 2
  %613 = and i1 %609, %611
  %614 = and i1 %612, %613
  %615 = extractelement <8 x float> %578, i32 %610
  %616 = select i1 %614, float %615, float 0.000000e+00
  %617 = insertelement <8 x float> %604, float %616, i64 2
  %618 = xor i1 %614, true
  %619 = and i1 %612, %618
  %620 = insertelement <8 x i1> %607, i1 %619, i64 2
  %621 = extractelement <8 x i32> %579, i64 3
  %622 = icmp ult i32 %621, 8
  %623 = select i1 %622, i32 %621, i32 0
  %624 = extractelement <8 x i1> %57, i32 %623
  %625 = extractelement <8 x i1> %57, i64 3
  %626 = and i1 %622, %624
  %627 = and i1 %625, %626
  %628 = extractelement <8 x float> %578, i32 %623
  %629 = select i1 %627, float %628, float 0.000000e+00
  %630 = insertelement <8 x float> %617, float %629, i64 3
  %631 = xor i1 %627, true
  %632 = and i1 %625, %631
  %633 = insertelement <8 x i1> %620, i1 %632, i64 3
  %634 = extractelement <8 x i32> %579, i64 4
  %635 = icmp ult i32 %634, 8
  %636 = select i1 %635, i32 %634, i32 0
  %637 = extractelement <8 x i1> %57, i32 %636
  %638 = extractelement <8 x i1> %57, i64 4
  %639 = and i1 %635, %637
  %640 = and i1 %638, %639
  %641 = extractelement <8 x float> %578, i32 %636
  %642 = select i1 %640, float %641, float 0.000000e+00
  %643 = insertelement <8 x float> %630, float %642, i64 4
  %644 = xor i1 %640, true
  %645 = and i1 %638, %644
  %646 = insertelement <8 x i1> %633, i1 %645, i64 4
  %647 = extractelement <8 x i32> %579, i64 5
  %648 = icmp ult i32 %647, 8
  %649 = select i1 %648, i32 %647, i32 0
  %650 = extractelement <8 x i1> %57, i32 %649
  %651 = extractelement <8 x i1> %57, i64 5
  %652 = and i1 %648, %650
  %653 = and i1 %651, %652
  %654 = extractelement <8 x float> %578, i32 %649
  %655 = select i1 %653, float %654, float 0.000000e+00
  %656 = insertelement <8 x float> %643, float %655, i64 5
  %657 = xor i1 %653, true
  %658 = and i1 %651, %657
  %659 = insertelement <8 x i1> %646, i1 %658, i64 5
  %660 = extractelement <8 x i32> %579, i64 6
  %661 = icmp ult i32 %660, 8
  %662 = select i1 %661, i32 %660, i32 0
  %663 = extractelement <8 x i1> %57, i32 %662
  %664 = extractelement <8 x i1> %57, i64 6
  %665 = and i1 %661, %663
  %666 = and i1 %664, %665
  %667 = extractelement <8 x float> %578, i32 %662
  %668 = select i1 %666, float %667, float 0.000000e+00
  %669 = insertelement <8 x float> %656, float %668, i64 6
  %670 = xor i1 %666, true
  %671 = and i1 %664, %670
  %672 = insertelement <8 x i1> %659, i1 %671, i64 6
  %673 = extractelement <8 x i32> %579, i64 7
  %674 = icmp ult i32 %673, 8
  %675 = select i1 %674, i32 %673, i32 0
  %676 = extractelement <8 x i1> %57, i32 %675
  %677 = extractelement <8 x i1> %57, i64 7
  %678 = and i1 %674, %676
  %679 = and i1 %677, %678
  %680 = extractelement <8 x float> %578, i32 %675
  %681 = select i1 %679, float %680, float 0.000000e+00
  %682 = insertelement <8 x float> %669, float %681, i64 7
  %683 = xor i1 %679, true
  %684 = and i1 %677, %683
  %685 = insertelement <8 x i1> %672, i1 %684, i64 7
  %686 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %578, <8 x float> %682)
  %687 = extractelement <8 x i1> %57, i32 0
  %688 = extractelement <8 x i1> %57, i64 0
  %689 = and i1 true, %687
  %690 = and i1 %688, %689
  %691 = extractelement <8 x float> %686, i32 0
  %692 = select i1 %690, float %691, float 0.000000e+00
  %693 = insertelement <8 x float> poison, float %692, i64 0
  %694 = xor i1 %690, true
  %695 = and i1 %688, %694
  %696 = insertelement <8 x i1> poison, i1 %695, i64 0
  %697 = extractelement <8 x i1> %57, i32 0
  %698 = extractelement <8 x i1> %57, i64 1
  %699 = and i1 true, %697
  %700 = and i1 %698, %699
  %701 = extractelement <8 x float> %686, i32 0
  %702 = select i1 %700, float %701, float 0.000000e+00
  %703 = insertelement <8 x float> %693, float %702, i64 1
  %704 = xor i1 %700, true
  %705 = and i1 %698, %704
  %706 = insertelement <8 x i1> %696, i1 %705, i64 1
  %707 = extractelement <8 x i1> %57, i32 0
  %708 = extractelement <8 x i1> %57, i64 2
  %709 = and i1 true, %707
  %710 = and i1 %708, %709
  %711 = extractelement <8 x float> %686, i32 0
  %712 = select i1 %710, float %711, float 0.000000e+00
  %713 = insertelement <8 x float> %703, float %712, i64 2
  %714 = xor i1 %710, true
  %715 = and i1 %708, %714
  %716 = insertelement <8 x i1> %706, i1 %715, i64 2
  %717 = extractelement <8 x i1> %57, i32 0
  %718 = extractelement <8 x i1> %57, i64 3
  %719 = and i1 true, %717
  %720 = and i1 %718, %719
  %721 = extractelement <8 x float> %686, i32 0
  %722 = select i1 %720, float %721, float 0.000000e+00
  %723 = insertelement <8 x float> %713, float %722, i64 3
  %724 = xor i1 %720, true
  %725 = and i1 %718, %724
  %726 = insertelement <8 x i1> %716, i1 %725, i64 3
  %727 = extractelement <8 x i1> %57, i32 0
  %728 = extractelement <8 x i1> %57, i64 4
  %729 = and i1 true, %727
  %730 = and i1 %728, %729
  %731 = extractelement <8 x float> %686, i32 0
  %732 = select i1 %730, float %731, float 0.000000e+00
  %733 = insertelement <8 x float> %723, float %732, i64 4
  %734 = xor i1 %730, true
  %735 = and i1 %728, %734
  %736 = insertelement <8 x i1> %726, i1 %735, i64 4
  %737 = extractelement <8 x i1> %57, i32 0
  %738 = extractelement <8 x i1> %57, i64 5
  %739 = and i1 true, %737
  %740 = and i1 %738, %739
  %741 = extractelement <8 x float> %686, i32 0
  %742 = select i1 %740, float %741, float 0.000000e+00
  %743 = insertelement <8 x float> %733, float %742, i64 5
  %744 = xor i1 %740, true
  %745 = and i1 %738, %744
  %746 = insertelement <8 x i1> %736, i1 %745, i64 5
  %747 = extractelement <8 x i1> %57, i32 0
  %748 = extractelement <8 x i1> %57, i64 6
  %749 = and i1 true, %747
  %750 = and i1 %748, %749
  %751 = extractelement <8 x float> %686, i32 0
  %752 = select i1 %750, float %751, float 0.000000e+00
  %753 = insertelement <8 x float> %743, float %752, i64 6
  %754 = xor i1 %750, true
  %755 = and i1 %748, %754
  %756 = insertelement <8 x i1> %746, i1 %755, i64 6
  %757 = extractelement <8 x i1> %57, i32 0
  %758 = extractelement <8 x i1> %57, i64 7
  %759 = and i1 true, %757
  %760 = and i1 %758, %759
  %761 = extractelement <8 x float> %686, i32 0
  %762 = select i1 %760, float %761, float 0.000000e+00
  %763 = insertelement <8 x float> %753, float %762, i64 7
  %764 = xor i1 %760, true
  %765 = and i1 %758, %764
  %766 = insertelement <8 x i1> %756, i1 %765, i64 7
  %767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %768 = bitcast <8 x i1> %57 to i8
  %769 = call i8 @llvm.cttz.i8(i8 %768, i1 false)
  %770 = zext i8 %769 to i32
  %771 = select i1 %767, i32 %770, i32 0
  %772 = extractelement <8 x float> %763, i32 %771
  %773 = call float @llvm.maxnum.f32(float 0xFFF0000000000000, float %772)
  store float %773, ptr %.spill29, align 4
  %774 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %774, 0
  %777 = select <8 x i1> %57, <8 x ptr> %775, <8 x ptr> %776
  %778 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %779 = extractvalue { <8 x ptr>, <8 x i64> } %774, 1
  %780 = select <8 x i1> %57, <8 x i64> %778, <8 x i64> %779
  %781 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %777, 0
  %782 = insertvalue { <8 x ptr>, <8 x i64> } %781, <8 x i64> %780, 1
  store { <8 x ptr>, <8 x i64> } %782, ptr %tile_snapshot.spill30, align 64
  store i64 0, ptr %.slot31, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state155 = load i64, ptr %.slot31, align 4
  %783 = icmp slt i64 %.state155, 96
  br i1 %783, label %direct.true156, label %direct.false157

direct.schedule.17:                               ; preds = %direct.true156
  %tile_snapshot.spill.load158 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %784 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 0
  %785 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 1
  %.state159 = load i64, ptr %.slot31, align 4
  %.splatinsert160 = insertelement <8 x i64> poison, i64 %.state159, i64 0
  %.splat161 = shufflevector <8 x i64> %.splatinsert160, <8 x i64> poison, <8 x i32> zeroinitializer
  %786 = add <8 x i64> %785, %.splat161
  %787 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %784, 0
  %788 = insertvalue { <8 x ptr>, <8 x i64> } %787, <8 x i64> %786, 1
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %788, 0
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %788, 1
  %791 = getelementptr i8, <8 x ptr> %789, <8 x i64> %790
  %792 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %791, <8 x i1> %57, <8 x i8> zeroinitializer)
  %793 = icmp ne <8 x i8> %792, zeroinitializer
  %tile_snapshot.spill.load162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 0
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 1
  %.state163 = load i64, ptr %.slot31, align 4
  %.splatinsert164 = insertelement <8 x i64> poison, i64 %.state163, i64 0
  %.splat165 = shufflevector <8 x i64> %.splatinsert164, <8 x i64> poison, <8 x i32> zeroinitializer
  %796 = mul <8 x i64> %.splat165, splat (i64 32)
  %797 = add <8 x i64> %795, %796
  %798 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %794, 0
  %799 = insertvalue { <8 x ptr>, <8 x i64> } %798, <8 x i64> %797, 1
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %799, 1
  %802 = extractelement <8 x ptr> %800, i32 0
  %803 = extractelement <8 x i64> %801, i32 0
  %804 = sub i64 %803, 0
  %805 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %806 = select i1 %805, i64 %804, i64 0
  %private.contiguous.address166 = getelementptr i8, ptr %802, i64 %806
  %private.contiguous.load167 = load <8 x float>, ptr %private.contiguous.address166, align 4
  %807 = select <8 x i1> %57, <8 x float> %private.contiguous.load167, <8 x float> zeroinitializer
  %.spill.load168 = load float, ptr %.spill29, align 4
  %.splatinsert169 = insertelement <8 x float> poison, float %.spill.load168, i64 0
  %.splat170 = shufflevector <8 x float> %.splatinsert169, <8 x float> poison, <8 x i32> zeroinitializer
  %808 = fsub <8 x float> %807, %.splat170
  %809 = select <8 x i1> %57, <8 x float> %808, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %809)
  %810 = select <8 x i1> %793, <8 x float> %native.exp, <8 x float> zeroinitializer
  %tile_snapshot.spill.load171 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load171, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load171, 1
  %.state172 = load i64, ptr %.slot31, align 4
  %.splatinsert173 = insertelement <8 x i64> poison, i64 %.state172, i64 0
  %.splat174 = shufflevector <8 x i64> %.splatinsert173, <8 x i64> poison, <8 x i32> zeroinitializer
  %813 = mul <8 x i64> %.splat174, splat (i64 32)
  %814 = add <8 x i64> %812, %813
  %815 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %811, 0
  %816 = insertvalue { <8 x ptr>, <8 x i64> } %815, <8 x i64> %814, 1
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %816, 1
  %819 = extractelement <8 x ptr> %817, i32 0
  %820 = extractelement <8 x i64> %818, i32 0
  %821 = sub i64 %820, 0
  %822 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %823 = select i1 %822, i64 %821, i64 0
  %private.contiguous.address175 = getelementptr i8, ptr %819, i64 %823
  %private.contiguous.preserve176 = load <8 x float>, ptr %private.contiguous.address175, align 4
  %824 = select <8 x i1> %57, <8 x float> %810, <8 x float> %private.contiguous.preserve176
  store <8 x float> %824, ptr %private.contiguous.address175, align 4
  %.state177 = load i64, ptr %.slot31, align 4
  %825 = add i64 %.state177, 1
  store i64 %825, ptr %.slot31, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false157
  %tile_snapshot.spill.load178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 0
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 1
  %828 = add <8 x i64> %827, zeroinitializer
  %829 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %826, 0
  %830 = insertvalue { <8 x ptr>, <8 x i64> } %829, <8 x i64> %828, 1
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %830, 1
  %833 = extractelement <8 x ptr> %831, i32 0
  %834 = extractelement <8 x i64> %832, i32 0
  %835 = sub i64 %834, 0
  %836 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %837 = select i1 %836, i64 %835, i64 0
  %private.contiguous.address179 = getelementptr i8, ptr %833, i64 %837
  %private.contiguous.load180 = load <8 x float>, ptr %private.contiguous.address179, align 4
  %838 = select <8 x i1> %57, <8 x float> %private.contiguous.load180, <8 x float> zeroinitializer
  %tile_snapshot.spill.load181 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 0
  %840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 1
  %841 = add <8 x i64> %840, splat (i64 32)
  %842 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %839, 0
  %843 = insertvalue { <8 x ptr>, <8 x i64> } %842, <8 x i64> %841, 1
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %843, 1
  %846 = extractelement <8 x ptr> %844, i32 0
  %847 = extractelement <8 x i64> %845, i32 0
  %848 = sub i64 %847, 0
  %849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %850 = select i1 %849, i64 %848, i64 0
  %private.contiguous.address182 = getelementptr i8, ptr %846, i64 %850
  %private.contiguous.load183 = load <8 x float>, ptr %private.contiguous.address182, align 4
  %851 = select <8 x i1> %57, <8 x float> %private.contiguous.load183, <8 x float> zeroinitializer
  %tile_snapshot.spill.load184 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 0
  %853 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 1
  %854 = add <8 x i64> %853, splat (i64 64)
  %855 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %852, 0
  %856 = insertvalue { <8 x ptr>, <8 x i64> } %855, <8 x i64> %854, 1
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %856, 1
  %859 = extractelement <8 x ptr> %857, i32 0
  %860 = extractelement <8 x i64> %858, i32 0
  %861 = sub i64 %860, 0
  %862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %863 = select i1 %862, i64 %861, i64 0
  %private.contiguous.address185 = getelementptr i8, ptr %859, i64 %863
  %private.contiguous.load186 = load <8 x float>, ptr %private.contiguous.address185, align 4
  %864 = select <8 x i1> %57, <8 x float> %private.contiguous.load186, <8 x float> zeroinitializer
  %tile_snapshot.spill.load187 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 0
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 1
  %867 = add <8 x i64> %866, splat (i64 96)
  %868 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %865, 0
  %869 = insertvalue { <8 x ptr>, <8 x i64> } %868, <8 x i64> %867, 1
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %869, 1
  %872 = extractelement <8 x ptr> %870, i32 0
  %873 = extractelement <8 x i64> %871, i32 0
  %874 = sub i64 %873, 0
  %875 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %876 = select i1 %875, i64 %874, i64 0
  %private.contiguous.address188 = getelementptr i8, ptr %872, i64 %876
  %private.contiguous.load189 = load <8 x float>, ptr %private.contiguous.address188, align 4
  %877 = select <8 x i1> %57, <8 x float> %private.contiguous.load189, <8 x float> zeroinitializer
  store i64 4, ptr %.slot32, align 4
  %878 = load <8 x float>, ptr %.slot33, align 32
  %879 = select <8 x i1> %57, <8 x float> %838, <8 x float> %878
  store <8 x float> %879, ptr %.slot33, align 32
  %880 = load <8 x float>, ptr %.slot34, align 32
  %881 = select <8 x i1> %57, <8 x float> %851, <8 x float> %880
  store <8 x float> %881, ptr %.slot34, align 32
  %882 = load <8 x float>, ptr %.slot35, align 32
  %883 = select <8 x i1> %57, <8 x float> %864, <8 x float> %882
  store <8 x float> %883, ptr %.slot35, align 32
  %884 = load <8 x float>, ptr %.slot36, align 32
  %885 = select <8 x i1> %57, <8 x float> %877, <8 x float> %884
  store <8 x float> %885, ptr %.slot36, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state190 = load i64, ptr %.slot32, align 4
  %886 = icmp slt i64 %.state190, 96
  br i1 %886, label %direct.true191, label %direct.false192

direct.schedule.20:                               ; preds = %direct.true191
  %.state193 = load i64, ptr %.slot32, align 4
  %887 = add i64 %.state193, 0
  %tile_snapshot.spill.load194 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %888 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 0
  %889 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 1
  %.splatinsert195 = insertelement <8 x i64> poison, i64 %887, i64 0
  %.splat196 = shufflevector <8 x i64> %.splatinsert195, <8 x i64> poison, <8 x i32> zeroinitializer
  %890 = mul <8 x i64> %.splat196, splat (i64 32)
  %891 = add <8 x i64> %889, %890
  %892 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %888, 0
  %893 = insertvalue { <8 x ptr>, <8 x i64> } %892, <8 x i64> %891, 1
  %894 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %895 = extractvalue { <8 x ptr>, <8 x i64> } %893, 1
  %896 = extractelement <8 x ptr> %894, i32 0
  %897 = extractelement <8 x i64> %895, i32 0
  %898 = sub i64 %897, 0
  %899 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %900 = select i1 %899, i64 %898, i64 0
  %private.contiguous.address197 = getelementptr i8, ptr %896, i64 %900
  %private.contiguous.load198 = load <8 x float>, ptr %private.contiguous.address197, align 4
  %901 = select <8 x i1> %57, <8 x float> %private.contiguous.load198, <8 x float> zeroinitializer
  %.state199 = load <8 x float>, ptr %.slot33, align 32
  %902 = fadd <8 x float> %.state199, %901
  %.state200 = load i64, ptr %.slot32, align 4
  %903 = add i64 %.state200, 1
  %tile_snapshot.spill.load201 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 0
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 1
  %.splatinsert202 = insertelement <8 x i64> poison, i64 %903, i64 0
  %.splat203 = shufflevector <8 x i64> %.splatinsert202, <8 x i64> poison, <8 x i32> zeroinitializer
  %906 = mul <8 x i64> %.splat203, splat (i64 32)
  %907 = add <8 x i64> %905, %906
  %908 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %904, 0
  %909 = insertvalue { <8 x ptr>, <8 x i64> } %908, <8 x i64> %907, 1
  %910 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %911 = extractvalue { <8 x ptr>, <8 x i64> } %909, 1
  %912 = extractelement <8 x ptr> %910, i32 0
  %913 = extractelement <8 x i64> %911, i32 0
  %914 = sub i64 %913, 0
  %915 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %916 = select i1 %915, i64 %914, i64 0
  %private.contiguous.address204 = getelementptr i8, ptr %912, i64 %916
  %private.contiguous.load205 = load <8 x float>, ptr %private.contiguous.address204, align 4
  %917 = select <8 x i1> %57, <8 x float> %private.contiguous.load205, <8 x float> zeroinitializer
  %.state206 = load <8 x float>, ptr %.slot34, align 32
  %918 = fadd <8 x float> %.state206, %917
  %.state207 = load i64, ptr %.slot32, align 4
  %919 = add i64 %.state207, 2
  %tile_snapshot.spill.load208 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load208, 0
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load208, 1
  %.splatinsert209 = insertelement <8 x i64> poison, i64 %919, i64 0
  %.splat210 = shufflevector <8 x i64> %.splatinsert209, <8 x i64> poison, <8 x i32> zeroinitializer
  %922 = mul <8 x i64> %.splat210, splat (i64 32)
  %923 = add <8 x i64> %921, %922
  %924 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %920, 0
  %925 = insertvalue { <8 x ptr>, <8 x i64> } %924, <8 x i64> %923, 1
  %926 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %927 = extractvalue { <8 x ptr>, <8 x i64> } %925, 1
  %928 = extractelement <8 x ptr> %926, i32 0
  %929 = extractelement <8 x i64> %927, i32 0
  %930 = sub i64 %929, 0
  %931 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %932 = select i1 %931, i64 %930, i64 0
  %private.contiguous.address211 = getelementptr i8, ptr %928, i64 %932
  %private.contiguous.load212 = load <8 x float>, ptr %private.contiguous.address211, align 4
  %933 = select <8 x i1> %57, <8 x float> %private.contiguous.load212, <8 x float> zeroinitializer
  %.state213 = load <8 x float>, ptr %.slot35, align 32
  %934 = fadd <8 x float> %.state213, %933
  %.state214 = load i64, ptr %.slot32, align 4
  %935 = add i64 %.state214, 3
  %tile_snapshot.spill.load215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %936 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %937 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %.splatinsert216 = insertelement <8 x i64> poison, i64 %935, i64 0
  %.splat217 = shufflevector <8 x i64> %.splatinsert216, <8 x i64> poison, <8 x i32> zeroinitializer
  %938 = mul <8 x i64> %.splat217, splat (i64 32)
  %939 = add <8 x i64> %937, %938
  %940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %936, 0
  %941 = insertvalue { <8 x ptr>, <8 x i64> } %940, <8 x i64> %939, 1
  %942 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %943 = extractvalue { <8 x ptr>, <8 x i64> } %941, 1
  %944 = extractelement <8 x ptr> %942, i32 0
  %945 = extractelement <8 x i64> %943, i32 0
  %946 = sub i64 %945, 0
  %947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %948 = select i1 %947, i64 %946, i64 0
  %private.contiguous.address218 = getelementptr i8, ptr %944, i64 %948
  %private.contiguous.load219 = load <8 x float>, ptr %private.contiguous.address218, align 4
  %949 = select <8 x i1> %57, <8 x float> %private.contiguous.load219, <8 x float> zeroinitializer
  %.state220 = load <8 x float>, ptr %.slot36, align 32
  %950 = fadd <8 x float> %.state220, %949
  %.state221 = load i64, ptr %.slot32, align 4
  %951 = add i64 %.state221, 4
  store i64 %951, ptr %.slot32, align 4
  %952 = load <8 x float>, ptr %.slot33, align 32
  %953 = select <8 x i1> %57, <8 x float> %902, <8 x float> %952
  store <8 x float> %953, ptr %.slot33, align 32
  %954 = load <8 x float>, ptr %.slot34, align 32
  %955 = select <8 x i1> %57, <8 x float> %918, <8 x float> %954
  store <8 x float> %955, ptr %.slot34, align 32
  %956 = load <8 x float>, ptr %.slot35, align 32
  %957 = select <8 x i1> %57, <8 x float> %934, <8 x float> %956
  store <8 x float> %957, ptr %.slot35, align 32
  %958 = load <8 x float>, ptr %.slot36, align 32
  %959 = select <8 x i1> %57, <8 x float> %950, <8 x float> %958
  store <8 x float> %959, ptr %.slot36, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false192
  %.state222 = load <8 x float>, ptr %.slot33, align 32
  %.state223 = load <8 x float>, ptr %.slot34, align 32
  %960 = fadd <8 x float> %.state222, %.state223
  %.state224 = load <8 x float>, ptr %.slot35, align 32
  %961 = fadd <8 x float> %960, %.state224
  %.state225 = load <8 x float>, ptr %.slot36, align 32
  %962 = fadd <8 x float> %961, %.state225
  %.spill.load226 = load <8 x i32>, ptr %.spill26, align 32
  %963 = extractelement <8 x i32> %.spill.load226, i64 0
  %964 = icmp ult i32 %963, 8
  %965 = select i1 %964, i32 %963, i32 0
  %966 = extractelement <8 x i1> %57, i32 %965
  %967 = extractelement <8 x i1> %57, i64 0
  %968 = and i1 %964, %966
  %969 = and i1 %967, %968
  %970 = extractelement <8 x float> %962, i32 %965
  %971 = select i1 %969, float %970, float 0.000000e+00
  %972 = insertelement <8 x float> poison, float %971, i64 0
  %973 = xor i1 %969, true
  %974 = and i1 %967, %973
  %975 = insertelement <8 x i1> poison, i1 %974, i64 0
  %976 = extractelement <8 x i32> %.spill.load226, i64 1
  %977 = icmp ult i32 %976, 8
  %978 = select i1 %977, i32 %976, i32 0
  %979 = extractelement <8 x i1> %57, i32 %978
  %980 = extractelement <8 x i1> %57, i64 1
  %981 = and i1 %977, %979
  %982 = and i1 %980, %981
  %983 = extractelement <8 x float> %962, i32 %978
  %984 = select i1 %982, float %983, float 0.000000e+00
  %985 = insertelement <8 x float> %972, float %984, i64 1
  %986 = xor i1 %982, true
  %987 = and i1 %980, %986
  %988 = insertelement <8 x i1> %975, i1 %987, i64 1
  %989 = extractelement <8 x i32> %.spill.load226, i64 2
  %990 = icmp ult i32 %989, 8
  %991 = select i1 %990, i32 %989, i32 0
  %992 = extractelement <8 x i1> %57, i32 %991
  %993 = extractelement <8 x i1> %57, i64 2
  %994 = and i1 %990, %992
  %995 = and i1 %993, %994
  %996 = extractelement <8 x float> %962, i32 %991
  %997 = select i1 %995, float %996, float 0.000000e+00
  %998 = insertelement <8 x float> %985, float %997, i64 2
  %999 = xor i1 %995, true
  %1000 = and i1 %993, %999
  %1001 = insertelement <8 x i1> %988, i1 %1000, i64 2
  %1002 = extractelement <8 x i32> %.spill.load226, i64 3
  %1003 = icmp ult i32 %1002, 8
  %1004 = select i1 %1003, i32 %1002, i32 0
  %1005 = extractelement <8 x i1> %57, i32 %1004
  %1006 = extractelement <8 x i1> %57, i64 3
  %1007 = and i1 %1003, %1005
  %1008 = and i1 %1006, %1007
  %1009 = extractelement <8 x float> %962, i32 %1004
  %1010 = select i1 %1008, float %1009, float 0.000000e+00
  %1011 = insertelement <8 x float> %998, float %1010, i64 3
  %1012 = xor i1 %1008, true
  %1013 = and i1 %1006, %1012
  %1014 = insertelement <8 x i1> %1001, i1 %1013, i64 3
  %1015 = extractelement <8 x i32> %.spill.load226, i64 4
  %1016 = icmp ult i32 %1015, 8
  %1017 = select i1 %1016, i32 %1015, i32 0
  %1018 = extractelement <8 x i1> %57, i32 %1017
  %1019 = extractelement <8 x i1> %57, i64 4
  %1020 = and i1 %1016, %1018
  %1021 = and i1 %1019, %1020
  %1022 = extractelement <8 x float> %962, i32 %1017
  %1023 = select i1 %1021, float %1022, float 0.000000e+00
  %1024 = insertelement <8 x float> %1011, float %1023, i64 4
  %1025 = xor i1 %1021, true
  %1026 = and i1 %1019, %1025
  %1027 = insertelement <8 x i1> %1014, i1 %1026, i64 4
  %1028 = extractelement <8 x i32> %.spill.load226, i64 5
  %1029 = icmp ult i32 %1028, 8
  %1030 = select i1 %1029, i32 %1028, i32 0
  %1031 = extractelement <8 x i1> %57, i32 %1030
  %1032 = extractelement <8 x i1> %57, i64 5
  %1033 = and i1 %1029, %1031
  %1034 = and i1 %1032, %1033
  %1035 = extractelement <8 x float> %962, i32 %1030
  %1036 = select i1 %1034, float %1035, float 0.000000e+00
  %1037 = insertelement <8 x float> %1024, float %1036, i64 5
  %1038 = xor i1 %1034, true
  %1039 = and i1 %1032, %1038
  %1040 = insertelement <8 x i1> %1027, i1 %1039, i64 5
  %1041 = extractelement <8 x i32> %.spill.load226, i64 6
  %1042 = icmp ult i32 %1041, 8
  %1043 = select i1 %1042, i32 %1041, i32 0
  %1044 = extractelement <8 x i1> %57, i32 %1043
  %1045 = extractelement <8 x i1> %57, i64 6
  %1046 = and i1 %1042, %1044
  %1047 = and i1 %1045, %1046
  %1048 = extractelement <8 x float> %962, i32 %1043
  %1049 = select i1 %1047, float %1048, float 0.000000e+00
  %1050 = insertelement <8 x float> %1037, float %1049, i64 6
  %1051 = xor i1 %1047, true
  %1052 = and i1 %1045, %1051
  %1053 = insertelement <8 x i1> %1040, i1 %1052, i64 6
  %1054 = extractelement <8 x i32> %.spill.load226, i64 7
  %1055 = icmp ult i32 %1054, 8
  %1056 = select i1 %1055, i32 %1054, i32 0
  %1057 = extractelement <8 x i1> %57, i32 %1056
  %1058 = extractelement <8 x i1> %57, i64 7
  %1059 = and i1 %1055, %1057
  %1060 = and i1 %1058, %1059
  %1061 = extractelement <8 x float> %962, i32 %1056
  %1062 = select i1 %1060, float %1061, float 0.000000e+00
  %1063 = insertelement <8 x float> %1050, float %1062, i64 7
  %1064 = xor i1 %1060, true
  %1065 = and i1 %1058, %1064
  %1066 = insertelement <8 x i1> %1053, i1 %1065, i64 7
  %1067 = fadd <8 x float> %962, %1063
  %.spill.load227 = load <8 x i32>, ptr %.spill27, align 32
  %1068 = extractelement <8 x i32> %.spill.load227, i64 0
  %1069 = icmp ult i32 %1068, 8
  %1070 = select i1 %1069, i32 %1068, i32 0
  %1071 = extractelement <8 x i1> %57, i32 %1070
  %1072 = extractelement <8 x i1> %57, i64 0
  %1073 = and i1 %1069, %1071
  %1074 = and i1 %1072, %1073
  %1075 = extractelement <8 x float> %1067, i32 %1070
  %1076 = select i1 %1074, float %1075, float 0.000000e+00
  %1077 = insertelement <8 x float> poison, float %1076, i64 0
  %1078 = xor i1 %1074, true
  %1079 = and i1 %1072, %1078
  %1080 = insertelement <8 x i1> poison, i1 %1079, i64 0
  %1081 = extractelement <8 x i32> %.spill.load227, i64 1
  %1082 = icmp ult i32 %1081, 8
  %1083 = select i1 %1082, i32 %1081, i32 0
  %1084 = extractelement <8 x i1> %57, i32 %1083
  %1085 = extractelement <8 x i1> %57, i64 1
  %1086 = and i1 %1082, %1084
  %1087 = and i1 %1085, %1086
  %1088 = extractelement <8 x float> %1067, i32 %1083
  %1089 = select i1 %1087, float %1088, float 0.000000e+00
  %1090 = insertelement <8 x float> %1077, float %1089, i64 1
  %1091 = xor i1 %1087, true
  %1092 = and i1 %1085, %1091
  %1093 = insertelement <8 x i1> %1080, i1 %1092, i64 1
  %1094 = extractelement <8 x i32> %.spill.load227, i64 2
  %1095 = icmp ult i32 %1094, 8
  %1096 = select i1 %1095, i32 %1094, i32 0
  %1097 = extractelement <8 x i1> %57, i32 %1096
  %1098 = extractelement <8 x i1> %57, i64 2
  %1099 = and i1 %1095, %1097
  %1100 = and i1 %1098, %1099
  %1101 = extractelement <8 x float> %1067, i32 %1096
  %1102 = select i1 %1100, float %1101, float 0.000000e+00
  %1103 = insertelement <8 x float> %1090, float %1102, i64 2
  %1104 = xor i1 %1100, true
  %1105 = and i1 %1098, %1104
  %1106 = insertelement <8 x i1> %1093, i1 %1105, i64 2
  %1107 = extractelement <8 x i32> %.spill.load227, i64 3
  %1108 = icmp ult i32 %1107, 8
  %1109 = select i1 %1108, i32 %1107, i32 0
  %1110 = extractelement <8 x i1> %57, i32 %1109
  %1111 = extractelement <8 x i1> %57, i64 3
  %1112 = and i1 %1108, %1110
  %1113 = and i1 %1111, %1112
  %1114 = extractelement <8 x float> %1067, i32 %1109
  %1115 = select i1 %1113, float %1114, float 0.000000e+00
  %1116 = insertelement <8 x float> %1103, float %1115, i64 3
  %1117 = xor i1 %1113, true
  %1118 = and i1 %1111, %1117
  %1119 = insertelement <8 x i1> %1106, i1 %1118, i64 3
  %1120 = extractelement <8 x i32> %.spill.load227, i64 4
  %1121 = icmp ult i32 %1120, 8
  %1122 = select i1 %1121, i32 %1120, i32 0
  %1123 = extractelement <8 x i1> %57, i32 %1122
  %1124 = extractelement <8 x i1> %57, i64 4
  %1125 = and i1 %1121, %1123
  %1126 = and i1 %1124, %1125
  %1127 = extractelement <8 x float> %1067, i32 %1122
  %1128 = select i1 %1126, float %1127, float 0.000000e+00
  %1129 = insertelement <8 x float> %1116, float %1128, i64 4
  %1130 = xor i1 %1126, true
  %1131 = and i1 %1124, %1130
  %1132 = insertelement <8 x i1> %1119, i1 %1131, i64 4
  %1133 = extractelement <8 x i32> %.spill.load227, i64 5
  %1134 = icmp ult i32 %1133, 8
  %1135 = select i1 %1134, i32 %1133, i32 0
  %1136 = extractelement <8 x i1> %57, i32 %1135
  %1137 = extractelement <8 x i1> %57, i64 5
  %1138 = and i1 %1134, %1136
  %1139 = and i1 %1137, %1138
  %1140 = extractelement <8 x float> %1067, i32 %1135
  %1141 = select i1 %1139, float %1140, float 0.000000e+00
  %1142 = insertelement <8 x float> %1129, float %1141, i64 5
  %1143 = xor i1 %1139, true
  %1144 = and i1 %1137, %1143
  %1145 = insertelement <8 x i1> %1132, i1 %1144, i64 5
  %1146 = extractelement <8 x i32> %.spill.load227, i64 6
  %1147 = icmp ult i32 %1146, 8
  %1148 = select i1 %1147, i32 %1146, i32 0
  %1149 = extractelement <8 x i1> %57, i32 %1148
  %1150 = extractelement <8 x i1> %57, i64 6
  %1151 = and i1 %1147, %1149
  %1152 = and i1 %1150, %1151
  %1153 = extractelement <8 x float> %1067, i32 %1148
  %1154 = select i1 %1152, float %1153, float 0.000000e+00
  %1155 = insertelement <8 x float> %1142, float %1154, i64 6
  %1156 = xor i1 %1152, true
  %1157 = and i1 %1150, %1156
  %1158 = insertelement <8 x i1> %1145, i1 %1157, i64 6
  %1159 = extractelement <8 x i32> %.spill.load227, i64 7
  %1160 = icmp ult i32 %1159, 8
  %1161 = select i1 %1160, i32 %1159, i32 0
  %1162 = extractelement <8 x i1> %57, i32 %1161
  %1163 = extractelement <8 x i1> %57, i64 7
  %1164 = and i1 %1160, %1162
  %1165 = and i1 %1163, %1164
  %1166 = extractelement <8 x float> %1067, i32 %1161
  %1167 = select i1 %1165, float %1166, float 0.000000e+00
  %1168 = insertelement <8 x float> %1155, float %1167, i64 7
  %1169 = xor i1 %1165, true
  %1170 = and i1 %1163, %1169
  %1171 = insertelement <8 x i1> %1158, i1 %1170, i64 7
  %1172 = fadd <8 x float> %1067, %1168
  %.spill.load228 = load <8 x i32>, ptr %.spill28, align 32
  %1173 = extractelement <8 x i32> %.spill.load228, i64 0
  %1174 = icmp ult i32 %1173, 8
  %1175 = select i1 %1174, i32 %1173, i32 0
  %1176 = extractelement <8 x i1> %57, i32 %1175
  %1177 = extractelement <8 x i1> %57, i64 0
  %1178 = and i1 %1174, %1176
  %1179 = and i1 %1177, %1178
  %1180 = extractelement <8 x float> %1172, i32 %1175
  %1181 = select i1 %1179, float %1180, float 0.000000e+00
  %1182 = insertelement <8 x float> poison, float %1181, i64 0
  %1183 = xor i1 %1179, true
  %1184 = and i1 %1177, %1183
  %1185 = insertelement <8 x i1> poison, i1 %1184, i64 0
  %1186 = extractelement <8 x i32> %.spill.load228, i64 1
  %1187 = icmp ult i32 %1186, 8
  %1188 = select i1 %1187, i32 %1186, i32 0
  %1189 = extractelement <8 x i1> %57, i32 %1188
  %1190 = extractelement <8 x i1> %57, i64 1
  %1191 = and i1 %1187, %1189
  %1192 = and i1 %1190, %1191
  %1193 = extractelement <8 x float> %1172, i32 %1188
  %1194 = select i1 %1192, float %1193, float 0.000000e+00
  %1195 = insertelement <8 x float> %1182, float %1194, i64 1
  %1196 = xor i1 %1192, true
  %1197 = and i1 %1190, %1196
  %1198 = insertelement <8 x i1> %1185, i1 %1197, i64 1
  %1199 = extractelement <8 x i32> %.spill.load228, i64 2
  %1200 = icmp ult i32 %1199, 8
  %1201 = select i1 %1200, i32 %1199, i32 0
  %1202 = extractelement <8 x i1> %57, i32 %1201
  %1203 = extractelement <8 x i1> %57, i64 2
  %1204 = and i1 %1200, %1202
  %1205 = and i1 %1203, %1204
  %1206 = extractelement <8 x float> %1172, i32 %1201
  %1207 = select i1 %1205, float %1206, float 0.000000e+00
  %1208 = insertelement <8 x float> %1195, float %1207, i64 2
  %1209 = xor i1 %1205, true
  %1210 = and i1 %1203, %1209
  %1211 = insertelement <8 x i1> %1198, i1 %1210, i64 2
  %1212 = extractelement <8 x i32> %.spill.load228, i64 3
  %1213 = icmp ult i32 %1212, 8
  %1214 = select i1 %1213, i32 %1212, i32 0
  %1215 = extractelement <8 x i1> %57, i32 %1214
  %1216 = extractelement <8 x i1> %57, i64 3
  %1217 = and i1 %1213, %1215
  %1218 = and i1 %1216, %1217
  %1219 = extractelement <8 x float> %1172, i32 %1214
  %1220 = select i1 %1218, float %1219, float 0.000000e+00
  %1221 = insertelement <8 x float> %1208, float %1220, i64 3
  %1222 = xor i1 %1218, true
  %1223 = and i1 %1216, %1222
  %1224 = insertelement <8 x i1> %1211, i1 %1223, i64 3
  %1225 = extractelement <8 x i32> %.spill.load228, i64 4
  %1226 = icmp ult i32 %1225, 8
  %1227 = select i1 %1226, i32 %1225, i32 0
  %1228 = extractelement <8 x i1> %57, i32 %1227
  %1229 = extractelement <8 x i1> %57, i64 4
  %1230 = and i1 %1226, %1228
  %1231 = and i1 %1229, %1230
  %1232 = extractelement <8 x float> %1172, i32 %1227
  %1233 = select i1 %1231, float %1232, float 0.000000e+00
  %1234 = insertelement <8 x float> %1221, float %1233, i64 4
  %1235 = xor i1 %1231, true
  %1236 = and i1 %1229, %1235
  %1237 = insertelement <8 x i1> %1224, i1 %1236, i64 4
  %1238 = extractelement <8 x i32> %.spill.load228, i64 5
  %1239 = icmp ult i32 %1238, 8
  %1240 = select i1 %1239, i32 %1238, i32 0
  %1241 = extractelement <8 x i1> %57, i32 %1240
  %1242 = extractelement <8 x i1> %57, i64 5
  %1243 = and i1 %1239, %1241
  %1244 = and i1 %1242, %1243
  %1245 = extractelement <8 x float> %1172, i32 %1240
  %1246 = select i1 %1244, float %1245, float 0.000000e+00
  %1247 = insertelement <8 x float> %1234, float %1246, i64 5
  %1248 = xor i1 %1244, true
  %1249 = and i1 %1242, %1248
  %1250 = insertelement <8 x i1> %1237, i1 %1249, i64 5
  %1251 = extractelement <8 x i32> %.spill.load228, i64 6
  %1252 = icmp ult i32 %1251, 8
  %1253 = select i1 %1252, i32 %1251, i32 0
  %1254 = extractelement <8 x i1> %57, i32 %1253
  %1255 = extractelement <8 x i1> %57, i64 6
  %1256 = and i1 %1252, %1254
  %1257 = and i1 %1255, %1256
  %1258 = extractelement <8 x float> %1172, i32 %1253
  %1259 = select i1 %1257, float %1258, float 0.000000e+00
  %1260 = insertelement <8 x float> %1247, float %1259, i64 6
  %1261 = xor i1 %1257, true
  %1262 = and i1 %1255, %1261
  %1263 = insertelement <8 x i1> %1250, i1 %1262, i64 6
  %1264 = extractelement <8 x i32> %.spill.load228, i64 7
  %1265 = icmp ult i32 %1264, 8
  %1266 = select i1 %1265, i32 %1264, i32 0
  %1267 = extractelement <8 x i1> %57, i32 %1266
  %1268 = extractelement <8 x i1> %57, i64 7
  %1269 = and i1 %1265, %1267
  %1270 = and i1 %1268, %1269
  %1271 = extractelement <8 x float> %1172, i32 %1266
  %1272 = select i1 %1270, float %1271, float 0.000000e+00
  %1273 = insertelement <8 x float> %1260, float %1272, i64 7
  %1274 = xor i1 %1270, true
  %1275 = and i1 %1268, %1274
  %1276 = insertelement <8 x i1> %1263, i1 %1275, i64 7
  %1277 = fadd <8 x float> %1172, %1273
  %1278 = extractelement <8 x i1> %57, i32 0
  %1279 = extractelement <8 x i1> %57, i64 0
  %1280 = and i1 true, %1278
  %1281 = and i1 %1279, %1280
  %1282 = extractelement <8 x float> %1277, i32 0
  %1283 = select i1 %1281, float %1282, float 0.000000e+00
  %1284 = insertelement <8 x float> poison, float %1283, i64 0
  %1285 = xor i1 %1281, true
  %1286 = and i1 %1279, %1285
  %1287 = insertelement <8 x i1> poison, i1 %1286, i64 0
  %1288 = extractelement <8 x i1> %57, i32 0
  %1289 = extractelement <8 x i1> %57, i64 1
  %1290 = and i1 true, %1288
  %1291 = and i1 %1289, %1290
  %1292 = extractelement <8 x float> %1277, i32 0
  %1293 = select i1 %1291, float %1292, float 0.000000e+00
  %1294 = insertelement <8 x float> %1284, float %1293, i64 1
  %1295 = xor i1 %1291, true
  %1296 = and i1 %1289, %1295
  %1297 = insertelement <8 x i1> %1287, i1 %1296, i64 1
  %1298 = extractelement <8 x i1> %57, i32 0
  %1299 = extractelement <8 x i1> %57, i64 2
  %1300 = and i1 true, %1298
  %1301 = and i1 %1299, %1300
  %1302 = extractelement <8 x float> %1277, i32 0
  %1303 = select i1 %1301, float %1302, float 0.000000e+00
  %1304 = insertelement <8 x float> %1294, float %1303, i64 2
  %1305 = xor i1 %1301, true
  %1306 = and i1 %1299, %1305
  %1307 = insertelement <8 x i1> %1297, i1 %1306, i64 2
  %1308 = extractelement <8 x i1> %57, i32 0
  %1309 = extractelement <8 x i1> %57, i64 3
  %1310 = and i1 true, %1308
  %1311 = and i1 %1309, %1310
  %1312 = extractelement <8 x float> %1277, i32 0
  %1313 = select i1 %1311, float %1312, float 0.000000e+00
  %1314 = insertelement <8 x float> %1304, float %1313, i64 3
  %1315 = xor i1 %1311, true
  %1316 = and i1 %1309, %1315
  %1317 = insertelement <8 x i1> %1307, i1 %1316, i64 3
  %1318 = extractelement <8 x i1> %57, i32 0
  %1319 = extractelement <8 x i1> %57, i64 4
  %1320 = and i1 true, %1318
  %1321 = and i1 %1319, %1320
  %1322 = extractelement <8 x float> %1277, i32 0
  %1323 = select i1 %1321, float %1322, float 0.000000e+00
  %1324 = insertelement <8 x float> %1314, float %1323, i64 4
  %1325 = xor i1 %1321, true
  %1326 = and i1 %1319, %1325
  %1327 = insertelement <8 x i1> %1317, i1 %1326, i64 4
  %1328 = extractelement <8 x i1> %57, i32 0
  %1329 = extractelement <8 x i1> %57, i64 5
  %1330 = and i1 true, %1328
  %1331 = and i1 %1329, %1330
  %1332 = extractelement <8 x float> %1277, i32 0
  %1333 = select i1 %1331, float %1332, float 0.000000e+00
  %1334 = insertelement <8 x float> %1324, float %1333, i64 5
  %1335 = xor i1 %1331, true
  %1336 = and i1 %1329, %1335
  %1337 = insertelement <8 x i1> %1327, i1 %1336, i64 5
  %1338 = extractelement <8 x i1> %57, i32 0
  %1339 = extractelement <8 x i1> %57, i64 6
  %1340 = and i1 true, %1338
  %1341 = and i1 %1339, %1340
  %1342 = extractelement <8 x float> %1277, i32 0
  %1343 = select i1 %1341, float %1342, float 0.000000e+00
  %1344 = insertelement <8 x float> %1334, float %1343, i64 6
  %1345 = xor i1 %1341, true
  %1346 = and i1 %1339, %1345
  %1347 = insertelement <8 x i1> %1337, i1 %1346, i64 6
  %1348 = extractelement <8 x i1> %57, i32 0
  %1349 = extractelement <8 x i1> %57, i64 7
  %1350 = and i1 true, %1348
  %1351 = and i1 %1349, %1350
  %1352 = extractelement <8 x float> %1277, i32 0
  %1353 = select i1 %1351, float %1352, float 0.000000e+00
  %1354 = insertelement <8 x float> %1344, float %1353, i64 7
  %1355 = xor i1 %1351, true
  %1356 = and i1 %1349, %1355
  %1357 = insertelement <8 x i1> %1347, i1 %1356, i64 7
  %1358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1359 = bitcast <8 x i1> %57 to i8
  %1360 = call i8 @llvm.cttz.i8(i8 %1359, i1 false)
  %1361 = zext i8 %1360 to i32
  %1362 = select i1 %1358, i32 %1361, i32 0
  %1363 = extractelement <8 x float> %1354, i32 %1362
  %1364 = fadd float 0.000000e+00, %1363
  store float %1364, ptr %.spill37, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.21
  store i64 0, ptr %.slot38, align 4
  br label %direct.schedule.23

direct.schedule.23:                               ; preds = %direct.schedule.24, %direct.schedule.22
  %.state229 = load i64, ptr %.slot38, align 4
  %1365 = icmp slt i64 %.state229, 96
  br i1 %1365, label %direct.true230, label %direct.false231

direct.schedule.24:                               ; preds = %direct.true230
  %.state232 = load i64, ptr %.slot38, align 4
  %1366 = mul i64 %.state232, 8
  %.splatinsert233 = insertelement <8 x i64> poison, i64 %1366, i64 0
  %.splat234 = shufflevector <8 x i64> %.splatinsert233, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load235 = load <8 x i64>, ptr %.spill, align 64
  %1367 = add <8 x i64> %.splat234, %.spill.load235
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %.state237 = load i64, ptr %.slot38, align 4
  %.splatinsert238 = insertelement <8 x i64> poison, i64 %.state237, i64 0
  %.splat239 = shufflevector <8 x i64> %.splatinsert238, <8 x i64> poison, <8 x i32> zeroinitializer
  %1370 = mul <8 x i64> %.splat239, splat (i64 32)
  %1371 = add <8 x i64> %1369, %1370
  %1372 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1368, 0
  %1373 = insertvalue { <8 x ptr>, <8 x i64> } %1372, <8 x i64> %1371, 1
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %1373, 1
  %1376 = extractelement <8 x ptr> %1374, i32 0
  %1377 = extractelement <8 x i64> %1375, i32 0
  %1378 = sub i64 %1377, 0
  %1379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1380 = select i1 %1379, i64 %1378, i64 0
  %private.contiguous.address240 = getelementptr i8, ptr %1376, i64 %1380
  %private.contiguous.load241 = load <8 x float>, ptr %private.contiguous.address240, align 4
  %1381 = select <8 x i1> %57, <8 x float> %private.contiguous.load241, <8 x float> zeroinitializer
  %.spill.load242 = load float, ptr %.spill37, align 4
  %.splatinsert243 = insertelement <8 x float> poison, float %.spill.load242, i64 0
  %.splat244 = shufflevector <8 x float> %.splatinsert243, <8 x float> poison, <8 x i32> zeroinitializer
  %1382 = fdiv <8 x float> %1381, %.splat244
  %.spill.load245 = load <8 x i64>, ptr %.spill13, align 64
  %1383 = add <8 x i64> %.spill.load245, zeroinitializer
  %1384 = add <8 x i64> zeroinitializer, %1383
  %1385 = add <8 x i64> zeroinitializer, %1367
  %1386 = mul <8 x i64> %1384, splat (i64 768)
  %1387 = add <8 x i64> %1386, %1385
  %1388 = extractvalue { ptr, i64 } %33, 0
  %1389 = extractelement <8 x i64> %1387, i32 0
  %1390 = sub i64 %1389, 0
  %1391 = mul i64 %1390, 4
  %buffer.contiguous.address246 = getelementptr i8, ptr %1388, i64 %1391
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1382, ptr align 1 %buffer.contiguous.address246, <8 x i1> %57)
  %.state247 = load i64, ptr %.slot38, align 4
  %1392 = add i64 %.state247, 1
  store i64 %1392, ptr %.slot38, align 4
  br label %direct.schedule.23

direct.schedule.25:                               ; preds = %direct.false231
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true58:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false59:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true73:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false74:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true87:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false88:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true119:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false120:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true156:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false157:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true191:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false192:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true230:                                   ; preds = %direct.schedule.23
  br label %direct.schedule.24

direct.false231:                                  ; preds = %direct.schedule.23
  br label %direct.schedule.25
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maxnum.f32(float, float) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #6

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [6144 x i8], align 8
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local4 = alloca [768 x i8], align 1
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 96, i64 192, i64 288, i64 384, i64 480, i64 576, i64 672>, 1
  %tile_snapshot.local7 = alloca [3072 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [3072 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill13, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca i64, align 8
  store i64 0, ptr %.slot15, align 4
  %.spill16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill16, align 64
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %tile_snapshot.spill19 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill19, align 64
  %.slot20 = alloca i64, align 8
  store i64 0, ptr %.slot20, align 4
  %.slot21 = alloca i64, align 8
  store i64 0, ptr %.slot21, align 4
  %.slot22 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot22, align 32
  %.slot23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot23, align 32
  %.slot24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot24, align 32
  %.slot25 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot25, align 32
  %.spill26 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill26, align 32
  %.spill27 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill27, align 32
  %.spill28 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill28, align 32
  %.spill29 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill29, align 4
  %tile_snapshot.spill30 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill30, align 64
  %.slot31 = alloca i64, align 8
  store i64 0, ptr %.slot31, align 4
  %.slot32 = alloca i64, align 8
  store i64 0, ptr %.slot32, align 4
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.slot34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot34, align 32
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill37, align 4
  %.slot38 = alloca i64, align 8
  store i64 0, ptr %.slot38, align 4
  %10 = getelementptr i8, ptr %argument_buffer, i64 0
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 16
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 32
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = getelementptr i8, ptr %argument_buffer, i64 48
  %29 = load ptr, ptr %28, align 16
  %30 = getelementptr i8, ptr %28, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = insertvalue { ptr, i64 } poison, ptr %29, 0
  %33 = insertvalue { ptr, i64 } %32, i64 %31, 1
  %34 = load i32, ptr %launch_config, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 12
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 4
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 16
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 8
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 20
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 36
  %46 = load i32, ptr %45, align 4
  %.splatinsert39 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat40 = shufflevector <8 x i32> %.splatinsert39, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat40, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %48 = mul i32 %34, 32
  %.splatinsert41 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat42 = shufflevector <8 x i32> %.splatinsert41, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat42, %47
  %50 = mul i32 %38, 1
  %.splatinsert43 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat44 = shufflevector <8 x i32> %.splatinsert43, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat44, zeroinitializer
  %52 = mul i32 %42, 1
  %.splatinsert45 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat46 = shufflevector <8 x i32> %.splatinsert45, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat46, zeroinitializer
  %54 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %49, 0
  %55 = insertvalue [3 x <8 x i32>] %54, <8 x i32> %51, 1
  %56 = insertvalue [3 x <8 x i32>] %55, <8 x i32> %53, 2
  %.splatinsert47 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat48 = shufflevector <8 x i32> %.splatinsert47, <8 x i32> poison, <8 x i32> zeroinitializer
  %57 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat48
  %58 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  br i1 %58, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %59 = extractvalue [3 x <8 x i32>] %56, 0
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %57, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = sub <8 x i32> %59, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %63 = select <8 x i1> %57, <8 x i32> %62, <8 x i32> zeroinitializer
  %64 = select <8 x i1> %57, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %65 = lshr <8 x i32> %63, %64
  %66 = zext <8 x i32> %65 to <8 x i64>
  %67 = select <8 x i1> %57, <8 x i64> %66, <8 x i64> zeroinitializer
  %68 = select <8 x i1> %57, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %69 = sdiv <8 x i64> %67, %68
  %70 = load <8 x i64>, ptr %.spill13, align 64
  %71 = select <8 x i1> %57, <8 x i64> %69, <8 x i64> %70
  store <8 x i64> %71, ptr %.spill13, align 64
  %72 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %72, 0
  %75 = select <8 x i1> %57, <8 x ptr> %73, <8 x ptr> %74
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %77 = extractvalue { <8 x ptr>, <8 x i64> } %72, 1
  %78 = select <8 x i1> %57, <8 x i64> %76, <8 x i64> %77
  %79 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %75, 0
  %80 = insertvalue { <8 x ptr>, <8 x i64> } %79, <8 x i64> %78, 1
  store { <8 x ptr>, <8 x i64> } %80, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %81 = icmp slt i64 %.state, 96
  br i1 %81, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state49 = load i64, ptr %.slot, align 4
  %82 = mul i64 %.state49, 8
  %.splatinsert50 = insertelement <8 x i64> poison, i64 %82, i64 0
  %.splat51 = shufflevector <8 x i64> %.splatinsert50, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %83 = add <8 x i64> %.splat51, %.spill.load
  %.spill.load52 = load <8 x i64>, ptr %.spill13, align 64
  %84 = add <8 x i64> %.spill.load52, zeroinitializer
  %85 = add <8 x i64> zeroinitializer, %84
  %86 = add <8 x i64> zeroinitializer, %83
  %87 = mul <8 x i64> %85, splat (i64 768)
  %88 = add <8 x i64> %87, %86
  %89 = extractvalue { ptr, i64 } %15, 0
  %90 = extractelement <8 x i64> %88, i32 0
  %91 = sub i64 %90, 0
  %92 = mul i64 %91, 4
  %buffer.contiguous.address = getelementptr i8, ptr %89, i64 %92
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %57, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state53 = load i64, ptr %.slot, align 4
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %.state53, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %95 = mul <8 x i64> %.splat55, splat (i64 32)
  %96 = add <8 x i64> %94, %95
  %97 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %93, 0
  %98 = insertvalue { <8 x ptr>, <8 x i64> } %97, <8 x i64> %96, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %98, 1
  %101 = extractelement <8 x ptr> %99, i32 0
  %102 = extractelement <8 x i64> %100, i32 0
  %103 = sub i64 %102, 0
  %104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %105 = select i1 %104, i64 %103, i64 0
  %private.contiguous.address = getelementptr i8, ptr %101, i64 %105
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %106 = select <8 x i1> %57, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %106, ptr %private.contiguous.address, align 4
  %.state56 = load i64, ptr %.slot, align 4
  %107 = add i64 %.state56, 1
  store i64 %107, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %108, 0
  %111 = select <8 x i1> %57, <8 x ptr> %109, <8 x ptr> %110
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %113 = extractvalue { <8 x ptr>, <8 x i64> } %108, 1
  %114 = select <8 x i1> %57, <8 x i64> %112, <8 x i64> %113
  %115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %111, 0
  %116 = insertvalue { <8 x ptr>, <8 x i64> } %115, <8 x i64> %114, 1
  store { <8 x ptr>, <8 x i64> } %116, ptr %tile_snapshot.spill14, align 64
  store i64 0, ptr %.slot15, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state57 = load i64, ptr %.slot15, align 4
  %117 = icmp slt i64 %.state57, 96
  br i1 %117, label %direct.true58, label %direct.false59

direct.schedule.5:                                ; preds = %direct.true58
  %.state60 = load i64, ptr %.slot15, align 4
  %118 = mul i64 %.state60, 8
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %118, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load63 = load <8 x i64>, ptr %.spill, align 64
  %119 = add <8 x i64> %.splat62, %.spill.load63
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %.state65 = load i64, ptr %.slot15, align 4
  %.splatinsert66 = insertelement <8 x i64> poison, i64 %.state65, i64 0
  %.splat67 = shufflevector <8 x i64> %.splatinsert66, <8 x i64> poison, <8 x i32> zeroinitializer
  %122 = mul <8 x i64> %.splat67, splat (i64 64)
  %123 = add <8 x i64> %121, %122
  %124 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %120, 0
  %125 = insertvalue { <8 x ptr>, <8 x i64> } %124, <8 x i64> %123, 1
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %125, 1
  %128 = extractelement <8 x ptr> %126, i32 0
  %129 = extractelement <8 x i64> %127, i32 0
  %130 = sub i64 %129, 0
  %131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %132 = select i1 %131, i64 %130, i64 0
  %private.contiguous.address68 = getelementptr i8, ptr %128, i64 %132
  %private.contiguous.preserve69 = load <8 x i64>, ptr %private.contiguous.address68, align 8
  %133 = select <8 x i1> %57, <8 x i64> %119, <8 x i64> %private.contiguous.preserve69
  store <8 x i64> %133, ptr %private.contiguous.address68, align 8
  %.state70 = load i64, ptr %.slot15, align 4
  %134 = add i64 %.state70, 1
  store i64 %134, ptr %.slot15, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false59
  %.spill.load71 = load <8 x i64>, ptr %.spill13, align 64
  %135 = select <8 x i1> %57, <8 x i64> %.spill.load71, <8 x i64> zeroinitializer
  %136 = select <8 x i1> %57, <8 x i64> splat (i64 768), <8 x i64> splat (i64 1)
  %137 = srem <8 x i64> %135, %136
  %138 = load <8 x i64>, ptr %.spill16, align 64
  %139 = select <8 x i1> %57, <8 x i64> %137, <8 x i64> %138
  store <8 x i64> %139, ptr %.spill16, align 64
  %140 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 0
  %143 = select <8 x i1> %57, <8 x ptr> %141, <8 x ptr> %142
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %146 = select <8 x i1> %57, <8 x i64> %144, <8 x i64> %145
  %147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %143, 0
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %147, <8 x i64> %146, 1
  store { <8 x ptr>, <8 x i64> } %148, ptr %tile_snapshot.spill17, align 64
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state72 = load i64, ptr %.slot18, align 4
  %149 = icmp slt i64 %.state72, 96
  br i1 %149, label %direct.true73, label %direct.false74

direct.schedule.8:                                ; preds = %direct.true73
  %tile_snapshot.spill.load75 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load75, 1
  %.state76 = load i64, ptr %.slot18, align 4
  %.splatinsert77 = insertelement <8 x i64> poison, i64 %.state76, i64 0
  %.splat78 = shufflevector <8 x i64> %.splatinsert77, <8 x i64> poison, <8 x i32> zeroinitializer
  %152 = mul <8 x i64> %.splat78, splat (i64 64)
  %153 = add <8 x i64> %151, %152
  %154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %150, 0
  %155 = insertvalue { <8 x ptr>, <8 x i64> } %154, <8 x i64> %153, 1
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %155, 1
  %158 = extractelement <8 x ptr> %156, i32 0
  %159 = extractelement <8 x i64> %157, i32 0
  %160 = sub i64 %159, 0
  %161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %162 = select i1 %161, i64 %160, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %158, i64 %162
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address79, align 8
  %163 = select <8 x i1> %57, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load80 = load <8 x i64>, ptr %.spill16, align 64
  %164 = icmp sle <8 x i64> %163, %.spill.load80
  %tile_snapshot.spill.load81 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 0
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 1
  %.state82 = load i64, ptr %.slot18, align 4
  %.splatinsert83 = insertelement <8 x i64> poison, i64 %.state82, i64 0
  %.splat84 = shufflevector <8 x i64> %.splatinsert83, <8 x i64> poison, <8 x i32> zeroinitializer
  %167 = add <8 x i64> %166, %.splat84
  %168 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %165, 0
  %169 = insertvalue { <8 x ptr>, <8 x i64> } %168, <8 x i64> %167, 1
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %169, 0
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %169, 1
  %172 = getelementptr i8, <8 x ptr> %170, <8 x i64> %171
  %173 = zext <8 x i1> %164 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %173, <8 x ptr> align 1 %172, <8 x i1> %57)
  %.state85 = load i64, ptr %.slot18, align 4
  %174 = add i64 %.state85, 1
  store i64 %174, ptr %.slot18, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false74
  %175 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %175, 0
  %178 = select <8 x i1> %57, <8 x ptr> %176, <8 x ptr> %177
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %175, 1
  %181 = select <8 x i1> %57, <8 x i64> %179, <8 x i64> %180
  %182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %178, 0
  %183 = insertvalue { <8 x ptr>, <8 x i64> } %182, <8 x i64> %181, 1
  store { <8 x ptr>, <8 x i64> } %183, ptr %tile_snapshot.spill19, align 64
  store i64 0, ptr %.slot20, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state86 = load i64, ptr %.slot20, align 4
  %184 = icmp slt i64 %.state86, 96
  br i1 %184, label %direct.true87, label %direct.false88

direct.schedule.11:                               ; preds = %direct.true87
  %tile_snapshot.spill.load89 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 0
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load89, 1
  %.state90 = load i64, ptr %.slot20, align 4
  %.splatinsert91 = insertelement <8 x i64> poison, i64 %.state90, i64 0
  %.splat92 = shufflevector <8 x i64> %.splatinsert91, <8 x i64> poison, <8 x i32> zeroinitializer
  %187 = add <8 x i64> %186, %.splat92
  %188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %185, 0
  %189 = insertvalue { <8 x ptr>, <8 x i64> } %188, <8 x i64> %187, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %189, 0
  %191 = extractvalue { <8 x ptr>, <8 x i64> } %189, 1
  %192 = getelementptr i8, <8 x ptr> %190, <8 x i64> %191
  %193 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %192, <8 x i1> %57, <8 x i8> zeroinitializer)
  %194 = icmp ne <8 x i8> %193, zeroinitializer
  %tile_snapshot.spill.load93 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 1
  %.state94 = load i64, ptr %.slot20, align 4
  %.splatinsert95 = insertelement <8 x i64> poison, i64 %.state94, i64 0
  %.splat96 = shufflevector <8 x i64> %.splatinsert95, <8 x i64> poison, <8 x i32> zeroinitializer
  %197 = mul <8 x i64> %.splat96, splat (i64 32)
  %198 = add <8 x i64> %196, %197
  %199 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %195, 0
  %200 = insertvalue { <8 x ptr>, <8 x i64> } %199, <8 x i64> %198, 1
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %200, 1
  %203 = extractelement <8 x ptr> %201, i32 0
  %204 = extractelement <8 x i64> %202, i32 0
  %205 = sub i64 %204, 0
  %206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %207 = select i1 %206, i64 %205, i64 0
  %private.contiguous.address97 = getelementptr i8, ptr %203, i64 %207
  %private.contiguous.load98 = load <8 x float>, ptr %private.contiguous.address97, align 4
  %208 = select <8 x i1> %57, <8 x float> %private.contiguous.load98, <8 x float> zeroinitializer
  %209 = select <8 x i1> %194, <8 x float> %208, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %.state100 = load i64, ptr %.slot20, align 4
  %.splatinsert101 = insertelement <8 x i64> poison, i64 %.state100, i64 0
  %.splat102 = shufflevector <8 x i64> %.splatinsert101, <8 x i64> poison, <8 x i32> zeroinitializer
  %212 = mul <8 x i64> %.splat102, splat (i64 32)
  %213 = add <8 x i64> %211, %212
  %214 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %210, 0
  %215 = insertvalue { <8 x ptr>, <8 x i64> } %214, <8 x i64> %213, 1
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %215, 1
  %218 = extractelement <8 x ptr> %216, i32 0
  %219 = extractelement <8 x i64> %217, i32 0
  %220 = sub i64 %219, 0
  %221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %222 = select i1 %221, i64 %220, i64 0
  %private.contiguous.address103 = getelementptr i8, ptr %218, i64 %222
  %private.contiguous.preserve104 = load <8 x float>, ptr %private.contiguous.address103, align 4
  %223 = select <8 x i1> %57, <8 x float> %209, <8 x float> %private.contiguous.preserve104
  store <8 x float> %223, ptr %private.contiguous.address103, align 4
  %.state105 = load i64, ptr %.slot20, align 4
  %224 = add i64 %.state105, 1
  store i64 %224, ptr %.slot20, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false88
  %tile_snapshot.spill.load106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load106, 1
  %227 = add <8 x i64> %226, zeroinitializer
  %228 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %225, 0
  %229 = insertvalue { <8 x ptr>, <8 x i64> } %228, <8 x i64> %227, 1
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %229, 1
  %232 = extractelement <8 x ptr> %230, i32 0
  %233 = extractelement <8 x i64> %231, i32 0
  %234 = sub i64 %233, 0
  %235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %236 = select i1 %235, i64 %234, i64 0
  %private.contiguous.address107 = getelementptr i8, ptr %232, i64 %236
  %private.contiguous.load108 = load <8 x float>, ptr %private.contiguous.address107, align 4
  %237 = select <8 x i1> %57, <8 x float> %private.contiguous.load108, <8 x float> zeroinitializer
  %tile_snapshot.spill.load109 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 0
  %239 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load109, 1
  %240 = add <8 x i64> %239, splat (i64 32)
  %241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %238, 0
  %242 = insertvalue { <8 x ptr>, <8 x i64> } %241, <8 x i64> %240, 1
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %245 = extractelement <8 x ptr> %243, i32 0
  %246 = extractelement <8 x i64> %244, i32 0
  %247 = sub i64 %246, 0
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %249 = select i1 %248, i64 %247, i64 0
  %private.contiguous.address110 = getelementptr i8, ptr %245, i64 %249
  %private.contiguous.load111 = load <8 x float>, ptr %private.contiguous.address110, align 4
  %250 = select <8 x i1> %57, <8 x float> %private.contiguous.load111, <8 x float> zeroinitializer
  %tile_snapshot.spill.load112 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load112, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load112, 1
  %253 = add <8 x i64> %252, splat (i64 64)
  %254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %251, 0
  %255 = insertvalue { <8 x ptr>, <8 x i64> } %254, <8 x i64> %253, 1
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %255, 1
  %258 = extractelement <8 x ptr> %256, i32 0
  %259 = extractelement <8 x i64> %257, i32 0
  %260 = sub i64 %259, 0
  %261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %262 = select i1 %261, i64 %260, i64 0
  %private.contiguous.address113 = getelementptr i8, ptr %258, i64 %262
  %private.contiguous.load114 = load <8 x float>, ptr %private.contiguous.address113, align 4
  %263 = select <8 x i1> %57, <8 x float> %private.contiguous.load114, <8 x float> zeroinitializer
  %tile_snapshot.spill.load115 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 0
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load115, 1
  %266 = add <8 x i64> %265, splat (i64 96)
  %267 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %264, 0
  %268 = insertvalue { <8 x ptr>, <8 x i64> } %267, <8 x i64> %266, 1
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %268, 1
  %271 = extractelement <8 x ptr> %269, i32 0
  %272 = extractelement <8 x i64> %270, i32 0
  %273 = sub i64 %272, 0
  %274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %275 = select i1 %274, i64 %273, i64 0
  %private.contiguous.address116 = getelementptr i8, ptr %271, i64 %275
  %private.contiguous.load117 = load <8 x float>, ptr %private.contiguous.address116, align 4
  %276 = select <8 x i1> %57, <8 x float> %private.contiguous.load117, <8 x float> zeroinitializer
  store i64 4, ptr %.slot21, align 4
  %277 = load <8 x float>, ptr %.slot22, align 32
  %278 = select <8 x i1> %57, <8 x float> %237, <8 x float> %277
  store <8 x float> %278, ptr %.slot22, align 32
  %279 = load <8 x float>, ptr %.slot23, align 32
  %280 = select <8 x i1> %57, <8 x float> %250, <8 x float> %279
  store <8 x float> %280, ptr %.slot23, align 32
  %281 = load <8 x float>, ptr %.slot24, align 32
  %282 = select <8 x i1> %57, <8 x float> %263, <8 x float> %281
  store <8 x float> %282, ptr %.slot24, align 32
  %283 = load <8 x float>, ptr %.slot25, align 32
  %284 = select <8 x i1> %57, <8 x float> %276, <8 x float> %283
  store <8 x float> %284, ptr %.slot25, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state118 = load i64, ptr %.slot21, align 4
  %285 = icmp slt i64 %.state118, 96
  br i1 %285, label %direct.true119, label %direct.false120

direct.schedule.14:                               ; preds = %direct.true119
  %.state121 = load i64, ptr %.slot21, align 4
  %286 = add i64 %.state121, 0
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %.splatinsert123 = insertelement <8 x i64> poison, i64 %286, i64 0
  %.splat124 = shufflevector <8 x i64> %.splatinsert123, <8 x i64> poison, <8 x i32> zeroinitializer
  %289 = mul <8 x i64> %.splat124, splat (i64 32)
  %290 = add <8 x i64> %288, %289
  %291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %287, 0
  %292 = insertvalue { <8 x ptr>, <8 x i64> } %291, <8 x i64> %290, 1
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %292, 1
  %295 = extractelement <8 x ptr> %293, i32 0
  %296 = extractelement <8 x i64> %294, i32 0
  %297 = sub i64 %296, 0
  %298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %299 = select i1 %298, i64 %297, i64 0
  %private.contiguous.address125 = getelementptr i8, ptr %295, i64 %299
  %private.contiguous.load126 = load <8 x float>, ptr %private.contiguous.address125, align 4
  %300 = select <8 x i1> %57, <8 x float> %private.contiguous.load126, <8 x float> zeroinitializer
  %.state127 = load <8 x float>, ptr %.slot22, align 32
  %301 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state127, <8 x float> %300)
  %.state128 = load i64, ptr %.slot21, align 4
  %302 = add i64 %.state128, 1
  %tile_snapshot.spill.load129 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 0
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 1
  %.splatinsert130 = insertelement <8 x i64> poison, i64 %302, i64 0
  %.splat131 = shufflevector <8 x i64> %.splatinsert130, <8 x i64> poison, <8 x i32> zeroinitializer
  %305 = mul <8 x i64> %.splat131, splat (i64 32)
  %306 = add <8 x i64> %304, %305
  %307 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %303, 0
  %308 = insertvalue { <8 x ptr>, <8 x i64> } %307, <8 x i64> %306, 1
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %308, 1
  %311 = extractelement <8 x ptr> %309, i32 0
  %312 = extractelement <8 x i64> %310, i32 0
  %313 = sub i64 %312, 0
  %314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %315 = select i1 %314, i64 %313, i64 0
  %private.contiguous.address132 = getelementptr i8, ptr %311, i64 %315
  %private.contiguous.load133 = load <8 x float>, ptr %private.contiguous.address132, align 4
  %316 = select <8 x i1> %57, <8 x float> %private.contiguous.load133, <8 x float> zeroinitializer
  %.state134 = load <8 x float>, ptr %.slot23, align 32
  %317 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state134, <8 x float> %316)
  %.state135 = load i64, ptr %.slot21, align 4
  %318 = add i64 %.state135, 2
  %tile_snapshot.spill.load136 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 0
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 1
  %.splatinsert137 = insertelement <8 x i64> poison, i64 %318, i64 0
  %.splat138 = shufflevector <8 x i64> %.splatinsert137, <8 x i64> poison, <8 x i32> zeroinitializer
  %321 = mul <8 x i64> %.splat138, splat (i64 32)
  %322 = add <8 x i64> %320, %321
  %323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %319, 0
  %324 = insertvalue { <8 x ptr>, <8 x i64> } %323, <8 x i64> %322, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %324, 1
  %327 = extractelement <8 x ptr> %325, i32 0
  %328 = extractelement <8 x i64> %326, i32 0
  %329 = sub i64 %328, 0
  %330 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %331 = select i1 %330, i64 %329, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %327, i64 %331
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %332 = select <8 x i1> %57, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %.state141 = load <8 x float>, ptr %.slot24, align 32
  %333 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state141, <8 x float> %332)
  %.state142 = load i64, ptr %.slot21, align 4
  %334 = add i64 %.state142, 3
  %tile_snapshot.spill.load143 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 0
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 1
  %.splatinsert144 = insertelement <8 x i64> poison, i64 %334, i64 0
  %.splat145 = shufflevector <8 x i64> %.splatinsert144, <8 x i64> poison, <8 x i32> zeroinitializer
  %337 = mul <8 x i64> %.splat145, splat (i64 32)
  %338 = add <8 x i64> %336, %337
  %339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %335, 0
  %340 = insertvalue { <8 x ptr>, <8 x i64> } %339, <8 x i64> %338, 1
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %340, 1
  %343 = extractelement <8 x ptr> %341, i32 0
  %344 = extractelement <8 x i64> %342, i32 0
  %345 = sub i64 %344, 0
  %346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %347 = select i1 %346, i64 %345, i64 0
  %private.contiguous.address146 = getelementptr i8, ptr %343, i64 %347
  %private.contiguous.load147 = load <8 x float>, ptr %private.contiguous.address146, align 4
  %348 = select <8 x i1> %57, <8 x float> %private.contiguous.load147, <8 x float> zeroinitializer
  %.state148 = load <8 x float>, ptr %.slot25, align 32
  %349 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state148, <8 x float> %348)
  %.state149 = load i64, ptr %.slot21, align 4
  %350 = add i64 %.state149, 4
  store i64 %350, ptr %.slot21, align 4
  %351 = load <8 x float>, ptr %.slot22, align 32
  %352 = select <8 x i1> %57, <8 x float> %301, <8 x float> %351
  store <8 x float> %352, ptr %.slot22, align 32
  %353 = load <8 x float>, ptr %.slot23, align 32
  %354 = select <8 x i1> %57, <8 x float> %317, <8 x float> %353
  store <8 x float> %354, ptr %.slot23, align 32
  %355 = load <8 x float>, ptr %.slot24, align 32
  %356 = select <8 x i1> %57, <8 x float> %333, <8 x float> %355
  store <8 x float> %356, ptr %.slot24, align 32
  %357 = load <8 x float>, ptr %.slot25, align 32
  %358 = select <8 x i1> %57, <8 x float> %349, <8 x float> %357
  store <8 x float> %358, ptr %.slot25, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false120
  %.state150 = load <8 x float>, ptr %.slot22, align 32
  %.state151 = load <8 x float>, ptr %.slot23, align 32
  %359 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state150, <8 x float> %.state151)
  %.state152 = load <8 x float>, ptr %.slot24, align 32
  %360 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %359, <8 x float> %.state152)
  %.state153 = load <8 x float>, ptr %.slot25, align 32
  %361 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %360, <8 x float> %.state153)
  %.spill.load154 = load <8 x i64>, ptr %.spill, align 64
  %362 = trunc <8 x i64> %.spill.load154 to <8 x i32>
  %363 = xor <8 x i32> %362, splat (i32 1)
  %364 = load <8 x i32>, ptr %.spill26, align 32
  %365 = select <8 x i1> %57, <8 x i32> %363, <8 x i32> %364
  store <8 x i32> %365, ptr %.spill26, align 32
  %366 = extractelement <8 x i32> %363, i64 0
  %367 = icmp ult i32 %366, 8
  %368 = select i1 %367, i32 %366, i32 0
  %369 = extractelement <8 x i1> %57, i32 %368
  %370 = extractelement <8 x i1> %57, i64 0
  %371 = and i1 %367, %369
  %372 = and i1 %370, %371
  %373 = extractelement <8 x float> %361, i32 %368
  %374 = select i1 %372, float %373, float 0.000000e+00
  %375 = insertelement <8 x float> poison, float %374, i64 0
  %376 = xor i1 %372, true
  %377 = and i1 %370, %376
  %378 = insertelement <8 x i1> poison, i1 %377, i64 0
  %379 = extractelement <8 x i32> %363, i64 1
  %380 = icmp ult i32 %379, 8
  %381 = select i1 %380, i32 %379, i32 0
  %382 = extractelement <8 x i1> %57, i32 %381
  %383 = extractelement <8 x i1> %57, i64 1
  %384 = and i1 %380, %382
  %385 = and i1 %383, %384
  %386 = extractelement <8 x float> %361, i32 %381
  %387 = select i1 %385, float %386, float 0.000000e+00
  %388 = insertelement <8 x float> %375, float %387, i64 1
  %389 = xor i1 %385, true
  %390 = and i1 %383, %389
  %391 = insertelement <8 x i1> %378, i1 %390, i64 1
  %392 = extractelement <8 x i32> %363, i64 2
  %393 = icmp ult i32 %392, 8
  %394 = select i1 %393, i32 %392, i32 0
  %395 = extractelement <8 x i1> %57, i32 %394
  %396 = extractelement <8 x i1> %57, i64 2
  %397 = and i1 %393, %395
  %398 = and i1 %396, %397
  %399 = extractelement <8 x float> %361, i32 %394
  %400 = select i1 %398, float %399, float 0.000000e+00
  %401 = insertelement <8 x float> %388, float %400, i64 2
  %402 = xor i1 %398, true
  %403 = and i1 %396, %402
  %404 = insertelement <8 x i1> %391, i1 %403, i64 2
  %405 = extractelement <8 x i32> %363, i64 3
  %406 = icmp ult i32 %405, 8
  %407 = select i1 %406, i32 %405, i32 0
  %408 = extractelement <8 x i1> %57, i32 %407
  %409 = extractelement <8 x i1> %57, i64 3
  %410 = and i1 %406, %408
  %411 = and i1 %409, %410
  %412 = extractelement <8 x float> %361, i32 %407
  %413 = select i1 %411, float %412, float 0.000000e+00
  %414 = insertelement <8 x float> %401, float %413, i64 3
  %415 = xor i1 %411, true
  %416 = and i1 %409, %415
  %417 = insertelement <8 x i1> %404, i1 %416, i64 3
  %418 = extractelement <8 x i32> %363, i64 4
  %419 = icmp ult i32 %418, 8
  %420 = select i1 %419, i32 %418, i32 0
  %421 = extractelement <8 x i1> %57, i32 %420
  %422 = extractelement <8 x i1> %57, i64 4
  %423 = and i1 %419, %421
  %424 = and i1 %422, %423
  %425 = extractelement <8 x float> %361, i32 %420
  %426 = select i1 %424, float %425, float 0.000000e+00
  %427 = insertelement <8 x float> %414, float %426, i64 4
  %428 = xor i1 %424, true
  %429 = and i1 %422, %428
  %430 = insertelement <8 x i1> %417, i1 %429, i64 4
  %431 = extractelement <8 x i32> %363, i64 5
  %432 = icmp ult i32 %431, 8
  %433 = select i1 %432, i32 %431, i32 0
  %434 = extractelement <8 x i1> %57, i32 %433
  %435 = extractelement <8 x i1> %57, i64 5
  %436 = and i1 %432, %434
  %437 = and i1 %435, %436
  %438 = extractelement <8 x float> %361, i32 %433
  %439 = select i1 %437, float %438, float 0.000000e+00
  %440 = insertelement <8 x float> %427, float %439, i64 5
  %441 = xor i1 %437, true
  %442 = and i1 %435, %441
  %443 = insertelement <8 x i1> %430, i1 %442, i64 5
  %444 = extractelement <8 x i32> %363, i64 6
  %445 = icmp ult i32 %444, 8
  %446 = select i1 %445, i32 %444, i32 0
  %447 = extractelement <8 x i1> %57, i32 %446
  %448 = extractelement <8 x i1> %57, i64 6
  %449 = and i1 %445, %447
  %450 = and i1 %448, %449
  %451 = extractelement <8 x float> %361, i32 %446
  %452 = select i1 %450, float %451, float 0.000000e+00
  %453 = insertelement <8 x float> %440, float %452, i64 6
  %454 = xor i1 %450, true
  %455 = and i1 %448, %454
  %456 = insertelement <8 x i1> %443, i1 %455, i64 6
  %457 = extractelement <8 x i32> %363, i64 7
  %458 = icmp ult i32 %457, 8
  %459 = select i1 %458, i32 %457, i32 0
  %460 = extractelement <8 x i1> %57, i32 %459
  %461 = extractelement <8 x i1> %57, i64 7
  %462 = and i1 %458, %460
  %463 = and i1 %461, %462
  %464 = extractelement <8 x float> %361, i32 %459
  %465 = select i1 %463, float %464, float 0.000000e+00
  %466 = insertelement <8 x float> %453, float %465, i64 7
  %467 = xor i1 %463, true
  %468 = and i1 %461, %467
  %469 = insertelement <8 x i1> %456, i1 %468, i64 7
  %470 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %361, <8 x float> %466)
  %471 = xor <8 x i32> %362, splat (i32 2)
  %472 = load <8 x i32>, ptr %.spill27, align 32
  %473 = select <8 x i1> %57, <8 x i32> %471, <8 x i32> %472
  store <8 x i32> %473, ptr %.spill27, align 32
  %474 = extractelement <8 x i32> %471, i64 0
  %475 = icmp ult i32 %474, 8
  %476 = select i1 %475, i32 %474, i32 0
  %477 = extractelement <8 x i1> %57, i32 %476
  %478 = extractelement <8 x i1> %57, i64 0
  %479 = and i1 %475, %477
  %480 = and i1 %478, %479
  %481 = extractelement <8 x float> %470, i32 %476
  %482 = select i1 %480, float %481, float 0.000000e+00
  %483 = insertelement <8 x float> poison, float %482, i64 0
  %484 = xor i1 %480, true
  %485 = and i1 %478, %484
  %486 = insertelement <8 x i1> poison, i1 %485, i64 0
  %487 = extractelement <8 x i32> %471, i64 1
  %488 = icmp ult i32 %487, 8
  %489 = select i1 %488, i32 %487, i32 0
  %490 = extractelement <8 x i1> %57, i32 %489
  %491 = extractelement <8 x i1> %57, i64 1
  %492 = and i1 %488, %490
  %493 = and i1 %491, %492
  %494 = extractelement <8 x float> %470, i32 %489
  %495 = select i1 %493, float %494, float 0.000000e+00
  %496 = insertelement <8 x float> %483, float %495, i64 1
  %497 = xor i1 %493, true
  %498 = and i1 %491, %497
  %499 = insertelement <8 x i1> %486, i1 %498, i64 1
  %500 = extractelement <8 x i32> %471, i64 2
  %501 = icmp ult i32 %500, 8
  %502 = select i1 %501, i32 %500, i32 0
  %503 = extractelement <8 x i1> %57, i32 %502
  %504 = extractelement <8 x i1> %57, i64 2
  %505 = and i1 %501, %503
  %506 = and i1 %504, %505
  %507 = extractelement <8 x float> %470, i32 %502
  %508 = select i1 %506, float %507, float 0.000000e+00
  %509 = insertelement <8 x float> %496, float %508, i64 2
  %510 = xor i1 %506, true
  %511 = and i1 %504, %510
  %512 = insertelement <8 x i1> %499, i1 %511, i64 2
  %513 = extractelement <8 x i32> %471, i64 3
  %514 = icmp ult i32 %513, 8
  %515 = select i1 %514, i32 %513, i32 0
  %516 = extractelement <8 x i1> %57, i32 %515
  %517 = extractelement <8 x i1> %57, i64 3
  %518 = and i1 %514, %516
  %519 = and i1 %517, %518
  %520 = extractelement <8 x float> %470, i32 %515
  %521 = select i1 %519, float %520, float 0.000000e+00
  %522 = insertelement <8 x float> %509, float %521, i64 3
  %523 = xor i1 %519, true
  %524 = and i1 %517, %523
  %525 = insertelement <8 x i1> %512, i1 %524, i64 3
  %526 = extractelement <8 x i32> %471, i64 4
  %527 = icmp ult i32 %526, 8
  %528 = select i1 %527, i32 %526, i32 0
  %529 = extractelement <8 x i1> %57, i32 %528
  %530 = extractelement <8 x i1> %57, i64 4
  %531 = and i1 %527, %529
  %532 = and i1 %530, %531
  %533 = extractelement <8 x float> %470, i32 %528
  %534 = select i1 %532, float %533, float 0.000000e+00
  %535 = insertelement <8 x float> %522, float %534, i64 4
  %536 = xor i1 %532, true
  %537 = and i1 %530, %536
  %538 = insertelement <8 x i1> %525, i1 %537, i64 4
  %539 = extractelement <8 x i32> %471, i64 5
  %540 = icmp ult i32 %539, 8
  %541 = select i1 %540, i32 %539, i32 0
  %542 = extractelement <8 x i1> %57, i32 %541
  %543 = extractelement <8 x i1> %57, i64 5
  %544 = and i1 %540, %542
  %545 = and i1 %543, %544
  %546 = extractelement <8 x float> %470, i32 %541
  %547 = select i1 %545, float %546, float 0.000000e+00
  %548 = insertelement <8 x float> %535, float %547, i64 5
  %549 = xor i1 %545, true
  %550 = and i1 %543, %549
  %551 = insertelement <8 x i1> %538, i1 %550, i64 5
  %552 = extractelement <8 x i32> %471, i64 6
  %553 = icmp ult i32 %552, 8
  %554 = select i1 %553, i32 %552, i32 0
  %555 = extractelement <8 x i1> %57, i32 %554
  %556 = extractelement <8 x i1> %57, i64 6
  %557 = and i1 %553, %555
  %558 = and i1 %556, %557
  %559 = extractelement <8 x float> %470, i32 %554
  %560 = select i1 %558, float %559, float 0.000000e+00
  %561 = insertelement <8 x float> %548, float %560, i64 6
  %562 = xor i1 %558, true
  %563 = and i1 %556, %562
  %564 = insertelement <8 x i1> %551, i1 %563, i64 6
  %565 = extractelement <8 x i32> %471, i64 7
  %566 = icmp ult i32 %565, 8
  %567 = select i1 %566, i32 %565, i32 0
  %568 = extractelement <8 x i1> %57, i32 %567
  %569 = extractelement <8 x i1> %57, i64 7
  %570 = and i1 %566, %568
  %571 = and i1 %569, %570
  %572 = extractelement <8 x float> %470, i32 %567
  %573 = select i1 %571, float %572, float 0.000000e+00
  %574 = insertelement <8 x float> %561, float %573, i64 7
  %575 = xor i1 %571, true
  %576 = and i1 %569, %575
  %577 = insertelement <8 x i1> %564, i1 %576, i64 7
  %578 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %470, <8 x float> %574)
  %579 = xor <8 x i32> %362, splat (i32 4)
  %580 = load <8 x i32>, ptr %.spill28, align 32
  %581 = select <8 x i1> %57, <8 x i32> %579, <8 x i32> %580
  store <8 x i32> %581, ptr %.spill28, align 32
  %582 = extractelement <8 x i32> %579, i64 0
  %583 = icmp ult i32 %582, 8
  %584 = select i1 %583, i32 %582, i32 0
  %585 = extractelement <8 x i1> %57, i32 %584
  %586 = extractelement <8 x i1> %57, i64 0
  %587 = and i1 %583, %585
  %588 = and i1 %586, %587
  %589 = extractelement <8 x float> %578, i32 %584
  %590 = select i1 %588, float %589, float 0.000000e+00
  %591 = insertelement <8 x float> poison, float %590, i64 0
  %592 = xor i1 %588, true
  %593 = and i1 %586, %592
  %594 = insertelement <8 x i1> poison, i1 %593, i64 0
  %595 = extractelement <8 x i32> %579, i64 1
  %596 = icmp ult i32 %595, 8
  %597 = select i1 %596, i32 %595, i32 0
  %598 = extractelement <8 x i1> %57, i32 %597
  %599 = extractelement <8 x i1> %57, i64 1
  %600 = and i1 %596, %598
  %601 = and i1 %599, %600
  %602 = extractelement <8 x float> %578, i32 %597
  %603 = select i1 %601, float %602, float 0.000000e+00
  %604 = insertelement <8 x float> %591, float %603, i64 1
  %605 = xor i1 %601, true
  %606 = and i1 %599, %605
  %607 = insertelement <8 x i1> %594, i1 %606, i64 1
  %608 = extractelement <8 x i32> %579, i64 2
  %609 = icmp ult i32 %608, 8
  %610 = select i1 %609, i32 %608, i32 0
  %611 = extractelement <8 x i1> %57, i32 %610
  %612 = extractelement <8 x i1> %57, i64 2
  %613 = and i1 %609, %611
  %614 = and i1 %612, %613
  %615 = extractelement <8 x float> %578, i32 %610
  %616 = select i1 %614, float %615, float 0.000000e+00
  %617 = insertelement <8 x float> %604, float %616, i64 2
  %618 = xor i1 %614, true
  %619 = and i1 %612, %618
  %620 = insertelement <8 x i1> %607, i1 %619, i64 2
  %621 = extractelement <8 x i32> %579, i64 3
  %622 = icmp ult i32 %621, 8
  %623 = select i1 %622, i32 %621, i32 0
  %624 = extractelement <8 x i1> %57, i32 %623
  %625 = extractelement <8 x i1> %57, i64 3
  %626 = and i1 %622, %624
  %627 = and i1 %625, %626
  %628 = extractelement <8 x float> %578, i32 %623
  %629 = select i1 %627, float %628, float 0.000000e+00
  %630 = insertelement <8 x float> %617, float %629, i64 3
  %631 = xor i1 %627, true
  %632 = and i1 %625, %631
  %633 = insertelement <8 x i1> %620, i1 %632, i64 3
  %634 = extractelement <8 x i32> %579, i64 4
  %635 = icmp ult i32 %634, 8
  %636 = select i1 %635, i32 %634, i32 0
  %637 = extractelement <8 x i1> %57, i32 %636
  %638 = extractelement <8 x i1> %57, i64 4
  %639 = and i1 %635, %637
  %640 = and i1 %638, %639
  %641 = extractelement <8 x float> %578, i32 %636
  %642 = select i1 %640, float %641, float 0.000000e+00
  %643 = insertelement <8 x float> %630, float %642, i64 4
  %644 = xor i1 %640, true
  %645 = and i1 %638, %644
  %646 = insertelement <8 x i1> %633, i1 %645, i64 4
  %647 = extractelement <8 x i32> %579, i64 5
  %648 = icmp ult i32 %647, 8
  %649 = select i1 %648, i32 %647, i32 0
  %650 = extractelement <8 x i1> %57, i32 %649
  %651 = extractelement <8 x i1> %57, i64 5
  %652 = and i1 %648, %650
  %653 = and i1 %651, %652
  %654 = extractelement <8 x float> %578, i32 %649
  %655 = select i1 %653, float %654, float 0.000000e+00
  %656 = insertelement <8 x float> %643, float %655, i64 5
  %657 = xor i1 %653, true
  %658 = and i1 %651, %657
  %659 = insertelement <8 x i1> %646, i1 %658, i64 5
  %660 = extractelement <8 x i32> %579, i64 6
  %661 = icmp ult i32 %660, 8
  %662 = select i1 %661, i32 %660, i32 0
  %663 = extractelement <8 x i1> %57, i32 %662
  %664 = extractelement <8 x i1> %57, i64 6
  %665 = and i1 %661, %663
  %666 = and i1 %664, %665
  %667 = extractelement <8 x float> %578, i32 %662
  %668 = select i1 %666, float %667, float 0.000000e+00
  %669 = insertelement <8 x float> %656, float %668, i64 6
  %670 = xor i1 %666, true
  %671 = and i1 %664, %670
  %672 = insertelement <8 x i1> %659, i1 %671, i64 6
  %673 = extractelement <8 x i32> %579, i64 7
  %674 = icmp ult i32 %673, 8
  %675 = select i1 %674, i32 %673, i32 0
  %676 = extractelement <8 x i1> %57, i32 %675
  %677 = extractelement <8 x i1> %57, i64 7
  %678 = and i1 %674, %676
  %679 = and i1 %677, %678
  %680 = extractelement <8 x float> %578, i32 %675
  %681 = select i1 %679, float %680, float 0.000000e+00
  %682 = insertelement <8 x float> %669, float %681, i64 7
  %683 = xor i1 %679, true
  %684 = and i1 %677, %683
  %685 = insertelement <8 x i1> %672, i1 %684, i64 7
  %686 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %578, <8 x float> %682)
  %687 = extractelement <8 x i1> %57, i32 0
  %688 = extractelement <8 x i1> %57, i64 0
  %689 = and i1 true, %687
  %690 = and i1 %688, %689
  %691 = extractelement <8 x float> %686, i32 0
  %692 = select i1 %690, float %691, float 0.000000e+00
  %693 = insertelement <8 x float> poison, float %692, i64 0
  %694 = xor i1 %690, true
  %695 = and i1 %688, %694
  %696 = insertelement <8 x i1> poison, i1 %695, i64 0
  %697 = extractelement <8 x i1> %57, i32 0
  %698 = extractelement <8 x i1> %57, i64 1
  %699 = and i1 true, %697
  %700 = and i1 %698, %699
  %701 = extractelement <8 x float> %686, i32 0
  %702 = select i1 %700, float %701, float 0.000000e+00
  %703 = insertelement <8 x float> %693, float %702, i64 1
  %704 = xor i1 %700, true
  %705 = and i1 %698, %704
  %706 = insertelement <8 x i1> %696, i1 %705, i64 1
  %707 = extractelement <8 x i1> %57, i32 0
  %708 = extractelement <8 x i1> %57, i64 2
  %709 = and i1 true, %707
  %710 = and i1 %708, %709
  %711 = extractelement <8 x float> %686, i32 0
  %712 = select i1 %710, float %711, float 0.000000e+00
  %713 = insertelement <8 x float> %703, float %712, i64 2
  %714 = xor i1 %710, true
  %715 = and i1 %708, %714
  %716 = insertelement <8 x i1> %706, i1 %715, i64 2
  %717 = extractelement <8 x i1> %57, i32 0
  %718 = extractelement <8 x i1> %57, i64 3
  %719 = and i1 true, %717
  %720 = and i1 %718, %719
  %721 = extractelement <8 x float> %686, i32 0
  %722 = select i1 %720, float %721, float 0.000000e+00
  %723 = insertelement <8 x float> %713, float %722, i64 3
  %724 = xor i1 %720, true
  %725 = and i1 %718, %724
  %726 = insertelement <8 x i1> %716, i1 %725, i64 3
  %727 = extractelement <8 x i1> %57, i32 0
  %728 = extractelement <8 x i1> %57, i64 4
  %729 = and i1 true, %727
  %730 = and i1 %728, %729
  %731 = extractelement <8 x float> %686, i32 0
  %732 = select i1 %730, float %731, float 0.000000e+00
  %733 = insertelement <8 x float> %723, float %732, i64 4
  %734 = xor i1 %730, true
  %735 = and i1 %728, %734
  %736 = insertelement <8 x i1> %726, i1 %735, i64 4
  %737 = extractelement <8 x i1> %57, i32 0
  %738 = extractelement <8 x i1> %57, i64 5
  %739 = and i1 true, %737
  %740 = and i1 %738, %739
  %741 = extractelement <8 x float> %686, i32 0
  %742 = select i1 %740, float %741, float 0.000000e+00
  %743 = insertelement <8 x float> %733, float %742, i64 5
  %744 = xor i1 %740, true
  %745 = and i1 %738, %744
  %746 = insertelement <8 x i1> %736, i1 %745, i64 5
  %747 = extractelement <8 x i1> %57, i32 0
  %748 = extractelement <8 x i1> %57, i64 6
  %749 = and i1 true, %747
  %750 = and i1 %748, %749
  %751 = extractelement <8 x float> %686, i32 0
  %752 = select i1 %750, float %751, float 0.000000e+00
  %753 = insertelement <8 x float> %743, float %752, i64 6
  %754 = xor i1 %750, true
  %755 = and i1 %748, %754
  %756 = insertelement <8 x i1> %746, i1 %755, i64 6
  %757 = extractelement <8 x i1> %57, i32 0
  %758 = extractelement <8 x i1> %57, i64 7
  %759 = and i1 true, %757
  %760 = and i1 %758, %759
  %761 = extractelement <8 x float> %686, i32 0
  %762 = select i1 %760, float %761, float 0.000000e+00
  %763 = insertelement <8 x float> %753, float %762, i64 7
  %764 = xor i1 %760, true
  %765 = and i1 %758, %764
  %766 = insertelement <8 x i1> %756, i1 %765, i64 7
  %767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %768 = bitcast <8 x i1> %57 to i8
  %769 = call i8 @llvm.cttz.i8(i8 %768, i1 false)
  %770 = zext i8 %769 to i32
  %771 = select i1 %767, i32 %770, i32 0
  %772 = extractelement <8 x float> %763, i32 %771
  %773 = call float @llvm.maxnum.f32(float 0xFFF0000000000000, float %772)
  store float %773, ptr %.spill29, align 4
  %774 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %774, 0
  %777 = select <8 x i1> %57, <8 x ptr> %775, <8 x ptr> %776
  %778 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %779 = extractvalue { <8 x ptr>, <8 x i64> } %774, 1
  %780 = select <8 x i1> %57, <8 x i64> %778, <8 x i64> %779
  %781 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %777, 0
  %782 = insertvalue { <8 x ptr>, <8 x i64> } %781, <8 x i64> %780, 1
  store { <8 x ptr>, <8 x i64> } %782, ptr %tile_snapshot.spill30, align 64
  store i64 0, ptr %.slot31, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state155 = load i64, ptr %.slot31, align 4
  %783 = icmp slt i64 %.state155, 96
  br i1 %783, label %direct.true156, label %direct.false157

direct.schedule.17:                               ; preds = %direct.true156
  %tile_snapshot.spill.load158 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %784 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 0
  %785 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 1
  %.state159 = load i64, ptr %.slot31, align 4
  %.splatinsert160 = insertelement <8 x i64> poison, i64 %.state159, i64 0
  %.splat161 = shufflevector <8 x i64> %.splatinsert160, <8 x i64> poison, <8 x i32> zeroinitializer
  %786 = add <8 x i64> %785, %.splat161
  %787 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %784, 0
  %788 = insertvalue { <8 x ptr>, <8 x i64> } %787, <8 x i64> %786, 1
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %788, 0
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %788, 1
  %791 = getelementptr i8, <8 x ptr> %789, <8 x i64> %790
  %792 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %791, <8 x i1> %57, <8 x i8> zeroinitializer)
  %793 = icmp ne <8 x i8> %792, zeroinitializer
  %tile_snapshot.spill.load162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill19, align 64
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 0
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 1
  %.state163 = load i64, ptr %.slot31, align 4
  %.splatinsert164 = insertelement <8 x i64> poison, i64 %.state163, i64 0
  %.splat165 = shufflevector <8 x i64> %.splatinsert164, <8 x i64> poison, <8 x i32> zeroinitializer
  %796 = mul <8 x i64> %.splat165, splat (i64 32)
  %797 = add <8 x i64> %795, %796
  %798 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %794, 0
  %799 = insertvalue { <8 x ptr>, <8 x i64> } %798, <8 x i64> %797, 1
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %799, 1
  %802 = extractelement <8 x ptr> %800, i32 0
  %803 = extractelement <8 x i64> %801, i32 0
  %804 = sub i64 %803, 0
  %805 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %806 = select i1 %805, i64 %804, i64 0
  %private.contiguous.address166 = getelementptr i8, ptr %802, i64 %806
  %private.contiguous.load167 = load <8 x float>, ptr %private.contiguous.address166, align 4
  %807 = select <8 x i1> %57, <8 x float> %private.contiguous.load167, <8 x float> zeroinitializer
  %.spill.load168 = load float, ptr %.spill29, align 4
  %.splatinsert169 = insertelement <8 x float> poison, float %.spill.load168, i64 0
  %.splat170 = shufflevector <8 x float> %.splatinsert169, <8 x float> poison, <8 x i32> zeroinitializer
  %808 = fsub <8 x float> %807, %.splat170
  %809 = select <8 x i1> %57, <8 x float> %808, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %809)
  %810 = select <8 x i1> %793, <8 x float> %native.exp, <8 x float> zeroinitializer
  %tile_snapshot.spill.load171 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load171, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load171, 1
  %.state172 = load i64, ptr %.slot31, align 4
  %.splatinsert173 = insertelement <8 x i64> poison, i64 %.state172, i64 0
  %.splat174 = shufflevector <8 x i64> %.splatinsert173, <8 x i64> poison, <8 x i32> zeroinitializer
  %813 = mul <8 x i64> %.splat174, splat (i64 32)
  %814 = add <8 x i64> %812, %813
  %815 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %811, 0
  %816 = insertvalue { <8 x ptr>, <8 x i64> } %815, <8 x i64> %814, 1
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %816, 1
  %819 = extractelement <8 x ptr> %817, i32 0
  %820 = extractelement <8 x i64> %818, i32 0
  %821 = sub i64 %820, 0
  %822 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %823 = select i1 %822, i64 %821, i64 0
  %private.contiguous.address175 = getelementptr i8, ptr %819, i64 %823
  %private.contiguous.preserve176 = load <8 x float>, ptr %private.contiguous.address175, align 4
  %824 = select <8 x i1> %57, <8 x float> %810, <8 x float> %private.contiguous.preserve176
  store <8 x float> %824, ptr %private.contiguous.address175, align 4
  %.state177 = load i64, ptr %.slot31, align 4
  %825 = add i64 %.state177, 1
  store i64 %825, ptr %.slot31, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false157
  %tile_snapshot.spill.load178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 0
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 1
  %828 = add <8 x i64> %827, zeroinitializer
  %829 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %826, 0
  %830 = insertvalue { <8 x ptr>, <8 x i64> } %829, <8 x i64> %828, 1
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %830, 1
  %833 = extractelement <8 x ptr> %831, i32 0
  %834 = extractelement <8 x i64> %832, i32 0
  %835 = sub i64 %834, 0
  %836 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %837 = select i1 %836, i64 %835, i64 0
  %private.contiguous.address179 = getelementptr i8, ptr %833, i64 %837
  %private.contiguous.load180 = load <8 x float>, ptr %private.contiguous.address179, align 4
  %838 = select <8 x i1> %57, <8 x float> %private.contiguous.load180, <8 x float> zeroinitializer
  %tile_snapshot.spill.load181 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 0
  %840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 1
  %841 = add <8 x i64> %840, splat (i64 32)
  %842 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %839, 0
  %843 = insertvalue { <8 x ptr>, <8 x i64> } %842, <8 x i64> %841, 1
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %843, 1
  %846 = extractelement <8 x ptr> %844, i32 0
  %847 = extractelement <8 x i64> %845, i32 0
  %848 = sub i64 %847, 0
  %849 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %850 = select i1 %849, i64 %848, i64 0
  %private.contiguous.address182 = getelementptr i8, ptr %846, i64 %850
  %private.contiguous.load183 = load <8 x float>, ptr %private.contiguous.address182, align 4
  %851 = select <8 x i1> %57, <8 x float> %private.contiguous.load183, <8 x float> zeroinitializer
  %tile_snapshot.spill.load184 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 0
  %853 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 1
  %854 = add <8 x i64> %853, splat (i64 64)
  %855 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %852, 0
  %856 = insertvalue { <8 x ptr>, <8 x i64> } %855, <8 x i64> %854, 1
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %856, 1
  %859 = extractelement <8 x ptr> %857, i32 0
  %860 = extractelement <8 x i64> %858, i32 0
  %861 = sub i64 %860, 0
  %862 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %863 = select i1 %862, i64 %861, i64 0
  %private.contiguous.address185 = getelementptr i8, ptr %859, i64 %863
  %private.contiguous.load186 = load <8 x float>, ptr %private.contiguous.address185, align 4
  %864 = select <8 x i1> %57, <8 x float> %private.contiguous.load186, <8 x float> zeroinitializer
  %tile_snapshot.spill.load187 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 0
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 1
  %867 = add <8 x i64> %866, splat (i64 96)
  %868 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %865, 0
  %869 = insertvalue { <8 x ptr>, <8 x i64> } %868, <8 x i64> %867, 1
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %871 = extractvalue { <8 x ptr>, <8 x i64> } %869, 1
  %872 = extractelement <8 x ptr> %870, i32 0
  %873 = extractelement <8 x i64> %871, i32 0
  %874 = sub i64 %873, 0
  %875 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %876 = select i1 %875, i64 %874, i64 0
  %private.contiguous.address188 = getelementptr i8, ptr %872, i64 %876
  %private.contiguous.load189 = load <8 x float>, ptr %private.contiguous.address188, align 4
  %877 = select <8 x i1> %57, <8 x float> %private.contiguous.load189, <8 x float> zeroinitializer
  store i64 4, ptr %.slot32, align 4
  %878 = load <8 x float>, ptr %.slot33, align 32
  %879 = select <8 x i1> %57, <8 x float> %838, <8 x float> %878
  store <8 x float> %879, ptr %.slot33, align 32
  %880 = load <8 x float>, ptr %.slot34, align 32
  %881 = select <8 x i1> %57, <8 x float> %851, <8 x float> %880
  store <8 x float> %881, ptr %.slot34, align 32
  %882 = load <8 x float>, ptr %.slot35, align 32
  %883 = select <8 x i1> %57, <8 x float> %864, <8 x float> %882
  store <8 x float> %883, ptr %.slot35, align 32
  %884 = load <8 x float>, ptr %.slot36, align 32
  %885 = select <8 x i1> %57, <8 x float> %877, <8 x float> %884
  store <8 x float> %885, ptr %.slot36, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state190 = load i64, ptr %.slot32, align 4
  %886 = icmp slt i64 %.state190, 96
  br i1 %886, label %direct.true191, label %direct.false192

direct.schedule.20:                               ; preds = %direct.true191
  %.state193 = load i64, ptr %.slot32, align 4
  %887 = add i64 %.state193, 0
  %tile_snapshot.spill.load194 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %888 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 0
  %889 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 1
  %.splatinsert195 = insertelement <8 x i64> poison, i64 %887, i64 0
  %.splat196 = shufflevector <8 x i64> %.splatinsert195, <8 x i64> poison, <8 x i32> zeroinitializer
  %890 = mul <8 x i64> %.splat196, splat (i64 32)
  %891 = add <8 x i64> %889, %890
  %892 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %888, 0
  %893 = insertvalue { <8 x ptr>, <8 x i64> } %892, <8 x i64> %891, 1
  %894 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %895 = extractvalue { <8 x ptr>, <8 x i64> } %893, 1
  %896 = extractelement <8 x ptr> %894, i32 0
  %897 = extractelement <8 x i64> %895, i32 0
  %898 = sub i64 %897, 0
  %899 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %900 = select i1 %899, i64 %898, i64 0
  %private.contiguous.address197 = getelementptr i8, ptr %896, i64 %900
  %private.contiguous.load198 = load <8 x float>, ptr %private.contiguous.address197, align 4
  %901 = select <8 x i1> %57, <8 x float> %private.contiguous.load198, <8 x float> zeroinitializer
  %.state199 = load <8 x float>, ptr %.slot33, align 32
  %902 = fadd <8 x float> %.state199, %901
  %.state200 = load i64, ptr %.slot32, align 4
  %903 = add i64 %.state200, 1
  %tile_snapshot.spill.load201 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 0
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 1
  %.splatinsert202 = insertelement <8 x i64> poison, i64 %903, i64 0
  %.splat203 = shufflevector <8 x i64> %.splatinsert202, <8 x i64> poison, <8 x i32> zeroinitializer
  %906 = mul <8 x i64> %.splat203, splat (i64 32)
  %907 = add <8 x i64> %905, %906
  %908 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %904, 0
  %909 = insertvalue { <8 x ptr>, <8 x i64> } %908, <8 x i64> %907, 1
  %910 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %911 = extractvalue { <8 x ptr>, <8 x i64> } %909, 1
  %912 = extractelement <8 x ptr> %910, i32 0
  %913 = extractelement <8 x i64> %911, i32 0
  %914 = sub i64 %913, 0
  %915 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %916 = select i1 %915, i64 %914, i64 0
  %private.contiguous.address204 = getelementptr i8, ptr %912, i64 %916
  %private.contiguous.load205 = load <8 x float>, ptr %private.contiguous.address204, align 4
  %917 = select <8 x i1> %57, <8 x float> %private.contiguous.load205, <8 x float> zeroinitializer
  %.state206 = load <8 x float>, ptr %.slot34, align 32
  %918 = fadd <8 x float> %.state206, %917
  %.state207 = load i64, ptr %.slot32, align 4
  %919 = add i64 %.state207, 2
  %tile_snapshot.spill.load208 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load208, 0
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load208, 1
  %.splatinsert209 = insertelement <8 x i64> poison, i64 %919, i64 0
  %.splat210 = shufflevector <8 x i64> %.splatinsert209, <8 x i64> poison, <8 x i32> zeroinitializer
  %922 = mul <8 x i64> %.splat210, splat (i64 32)
  %923 = add <8 x i64> %921, %922
  %924 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %920, 0
  %925 = insertvalue { <8 x ptr>, <8 x i64> } %924, <8 x i64> %923, 1
  %926 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %927 = extractvalue { <8 x ptr>, <8 x i64> } %925, 1
  %928 = extractelement <8 x ptr> %926, i32 0
  %929 = extractelement <8 x i64> %927, i32 0
  %930 = sub i64 %929, 0
  %931 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %932 = select i1 %931, i64 %930, i64 0
  %private.contiguous.address211 = getelementptr i8, ptr %928, i64 %932
  %private.contiguous.load212 = load <8 x float>, ptr %private.contiguous.address211, align 4
  %933 = select <8 x i1> %57, <8 x float> %private.contiguous.load212, <8 x float> zeroinitializer
  %.state213 = load <8 x float>, ptr %.slot35, align 32
  %934 = fadd <8 x float> %.state213, %933
  %.state214 = load i64, ptr %.slot32, align 4
  %935 = add i64 %.state214, 3
  %tile_snapshot.spill.load215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %936 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 0
  %937 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load215, 1
  %.splatinsert216 = insertelement <8 x i64> poison, i64 %935, i64 0
  %.splat217 = shufflevector <8 x i64> %.splatinsert216, <8 x i64> poison, <8 x i32> zeroinitializer
  %938 = mul <8 x i64> %.splat217, splat (i64 32)
  %939 = add <8 x i64> %937, %938
  %940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %936, 0
  %941 = insertvalue { <8 x ptr>, <8 x i64> } %940, <8 x i64> %939, 1
  %942 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %943 = extractvalue { <8 x ptr>, <8 x i64> } %941, 1
  %944 = extractelement <8 x ptr> %942, i32 0
  %945 = extractelement <8 x i64> %943, i32 0
  %946 = sub i64 %945, 0
  %947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %948 = select i1 %947, i64 %946, i64 0
  %private.contiguous.address218 = getelementptr i8, ptr %944, i64 %948
  %private.contiguous.load219 = load <8 x float>, ptr %private.contiguous.address218, align 4
  %949 = select <8 x i1> %57, <8 x float> %private.contiguous.load219, <8 x float> zeroinitializer
  %.state220 = load <8 x float>, ptr %.slot36, align 32
  %950 = fadd <8 x float> %.state220, %949
  %.state221 = load i64, ptr %.slot32, align 4
  %951 = add i64 %.state221, 4
  store i64 %951, ptr %.slot32, align 4
  %952 = load <8 x float>, ptr %.slot33, align 32
  %953 = select <8 x i1> %57, <8 x float> %902, <8 x float> %952
  store <8 x float> %953, ptr %.slot33, align 32
  %954 = load <8 x float>, ptr %.slot34, align 32
  %955 = select <8 x i1> %57, <8 x float> %918, <8 x float> %954
  store <8 x float> %955, ptr %.slot34, align 32
  %956 = load <8 x float>, ptr %.slot35, align 32
  %957 = select <8 x i1> %57, <8 x float> %934, <8 x float> %956
  store <8 x float> %957, ptr %.slot35, align 32
  %958 = load <8 x float>, ptr %.slot36, align 32
  %959 = select <8 x i1> %57, <8 x float> %950, <8 x float> %958
  store <8 x float> %959, ptr %.slot36, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false192
  %.state222 = load <8 x float>, ptr %.slot33, align 32
  %.state223 = load <8 x float>, ptr %.slot34, align 32
  %960 = fadd <8 x float> %.state222, %.state223
  %.state224 = load <8 x float>, ptr %.slot35, align 32
  %961 = fadd <8 x float> %960, %.state224
  %.state225 = load <8 x float>, ptr %.slot36, align 32
  %962 = fadd <8 x float> %961, %.state225
  %.spill.load226 = load <8 x i32>, ptr %.spill26, align 32
  %963 = extractelement <8 x i32> %.spill.load226, i64 0
  %964 = icmp ult i32 %963, 8
  %965 = select i1 %964, i32 %963, i32 0
  %966 = extractelement <8 x i1> %57, i32 %965
  %967 = extractelement <8 x i1> %57, i64 0
  %968 = and i1 %964, %966
  %969 = and i1 %967, %968
  %970 = extractelement <8 x float> %962, i32 %965
  %971 = select i1 %969, float %970, float 0.000000e+00
  %972 = insertelement <8 x float> poison, float %971, i64 0
  %973 = xor i1 %969, true
  %974 = and i1 %967, %973
  %975 = insertelement <8 x i1> poison, i1 %974, i64 0
  %976 = extractelement <8 x i32> %.spill.load226, i64 1
  %977 = icmp ult i32 %976, 8
  %978 = select i1 %977, i32 %976, i32 0
  %979 = extractelement <8 x i1> %57, i32 %978
  %980 = extractelement <8 x i1> %57, i64 1
  %981 = and i1 %977, %979
  %982 = and i1 %980, %981
  %983 = extractelement <8 x float> %962, i32 %978
  %984 = select i1 %982, float %983, float 0.000000e+00
  %985 = insertelement <8 x float> %972, float %984, i64 1
  %986 = xor i1 %982, true
  %987 = and i1 %980, %986
  %988 = insertelement <8 x i1> %975, i1 %987, i64 1
  %989 = extractelement <8 x i32> %.spill.load226, i64 2
  %990 = icmp ult i32 %989, 8
  %991 = select i1 %990, i32 %989, i32 0
  %992 = extractelement <8 x i1> %57, i32 %991
  %993 = extractelement <8 x i1> %57, i64 2
  %994 = and i1 %990, %992
  %995 = and i1 %993, %994
  %996 = extractelement <8 x float> %962, i32 %991
  %997 = select i1 %995, float %996, float 0.000000e+00
  %998 = insertelement <8 x float> %985, float %997, i64 2
  %999 = xor i1 %995, true
  %1000 = and i1 %993, %999
  %1001 = insertelement <8 x i1> %988, i1 %1000, i64 2
  %1002 = extractelement <8 x i32> %.spill.load226, i64 3
  %1003 = icmp ult i32 %1002, 8
  %1004 = select i1 %1003, i32 %1002, i32 0
  %1005 = extractelement <8 x i1> %57, i32 %1004
  %1006 = extractelement <8 x i1> %57, i64 3
  %1007 = and i1 %1003, %1005
  %1008 = and i1 %1006, %1007
  %1009 = extractelement <8 x float> %962, i32 %1004
  %1010 = select i1 %1008, float %1009, float 0.000000e+00
  %1011 = insertelement <8 x float> %998, float %1010, i64 3
  %1012 = xor i1 %1008, true
  %1013 = and i1 %1006, %1012
  %1014 = insertelement <8 x i1> %1001, i1 %1013, i64 3
  %1015 = extractelement <8 x i32> %.spill.load226, i64 4
  %1016 = icmp ult i32 %1015, 8
  %1017 = select i1 %1016, i32 %1015, i32 0
  %1018 = extractelement <8 x i1> %57, i32 %1017
  %1019 = extractelement <8 x i1> %57, i64 4
  %1020 = and i1 %1016, %1018
  %1021 = and i1 %1019, %1020
  %1022 = extractelement <8 x float> %962, i32 %1017
  %1023 = select i1 %1021, float %1022, float 0.000000e+00
  %1024 = insertelement <8 x float> %1011, float %1023, i64 4
  %1025 = xor i1 %1021, true
  %1026 = and i1 %1019, %1025
  %1027 = insertelement <8 x i1> %1014, i1 %1026, i64 4
  %1028 = extractelement <8 x i32> %.spill.load226, i64 5
  %1029 = icmp ult i32 %1028, 8
  %1030 = select i1 %1029, i32 %1028, i32 0
  %1031 = extractelement <8 x i1> %57, i32 %1030
  %1032 = extractelement <8 x i1> %57, i64 5
  %1033 = and i1 %1029, %1031
  %1034 = and i1 %1032, %1033
  %1035 = extractelement <8 x float> %962, i32 %1030
  %1036 = select i1 %1034, float %1035, float 0.000000e+00
  %1037 = insertelement <8 x float> %1024, float %1036, i64 5
  %1038 = xor i1 %1034, true
  %1039 = and i1 %1032, %1038
  %1040 = insertelement <8 x i1> %1027, i1 %1039, i64 5
  %1041 = extractelement <8 x i32> %.spill.load226, i64 6
  %1042 = icmp ult i32 %1041, 8
  %1043 = select i1 %1042, i32 %1041, i32 0
  %1044 = extractelement <8 x i1> %57, i32 %1043
  %1045 = extractelement <8 x i1> %57, i64 6
  %1046 = and i1 %1042, %1044
  %1047 = and i1 %1045, %1046
  %1048 = extractelement <8 x float> %962, i32 %1043
  %1049 = select i1 %1047, float %1048, float 0.000000e+00
  %1050 = insertelement <8 x float> %1037, float %1049, i64 6
  %1051 = xor i1 %1047, true
  %1052 = and i1 %1045, %1051
  %1053 = insertelement <8 x i1> %1040, i1 %1052, i64 6
  %1054 = extractelement <8 x i32> %.spill.load226, i64 7
  %1055 = icmp ult i32 %1054, 8
  %1056 = select i1 %1055, i32 %1054, i32 0
  %1057 = extractelement <8 x i1> %57, i32 %1056
  %1058 = extractelement <8 x i1> %57, i64 7
  %1059 = and i1 %1055, %1057
  %1060 = and i1 %1058, %1059
  %1061 = extractelement <8 x float> %962, i32 %1056
  %1062 = select i1 %1060, float %1061, float 0.000000e+00
  %1063 = insertelement <8 x float> %1050, float %1062, i64 7
  %1064 = xor i1 %1060, true
  %1065 = and i1 %1058, %1064
  %1066 = insertelement <8 x i1> %1053, i1 %1065, i64 7
  %1067 = fadd <8 x float> %962, %1063
  %.spill.load227 = load <8 x i32>, ptr %.spill27, align 32
  %1068 = extractelement <8 x i32> %.spill.load227, i64 0
  %1069 = icmp ult i32 %1068, 8
  %1070 = select i1 %1069, i32 %1068, i32 0
  %1071 = extractelement <8 x i1> %57, i32 %1070
  %1072 = extractelement <8 x i1> %57, i64 0
  %1073 = and i1 %1069, %1071
  %1074 = and i1 %1072, %1073
  %1075 = extractelement <8 x float> %1067, i32 %1070
  %1076 = select i1 %1074, float %1075, float 0.000000e+00
  %1077 = insertelement <8 x float> poison, float %1076, i64 0
  %1078 = xor i1 %1074, true
  %1079 = and i1 %1072, %1078
  %1080 = insertelement <8 x i1> poison, i1 %1079, i64 0
  %1081 = extractelement <8 x i32> %.spill.load227, i64 1
  %1082 = icmp ult i32 %1081, 8
  %1083 = select i1 %1082, i32 %1081, i32 0
  %1084 = extractelement <8 x i1> %57, i32 %1083
  %1085 = extractelement <8 x i1> %57, i64 1
  %1086 = and i1 %1082, %1084
  %1087 = and i1 %1085, %1086
  %1088 = extractelement <8 x float> %1067, i32 %1083
  %1089 = select i1 %1087, float %1088, float 0.000000e+00
  %1090 = insertelement <8 x float> %1077, float %1089, i64 1
  %1091 = xor i1 %1087, true
  %1092 = and i1 %1085, %1091
  %1093 = insertelement <8 x i1> %1080, i1 %1092, i64 1
  %1094 = extractelement <8 x i32> %.spill.load227, i64 2
  %1095 = icmp ult i32 %1094, 8
  %1096 = select i1 %1095, i32 %1094, i32 0
  %1097 = extractelement <8 x i1> %57, i32 %1096
  %1098 = extractelement <8 x i1> %57, i64 2
  %1099 = and i1 %1095, %1097
  %1100 = and i1 %1098, %1099
  %1101 = extractelement <8 x float> %1067, i32 %1096
  %1102 = select i1 %1100, float %1101, float 0.000000e+00
  %1103 = insertelement <8 x float> %1090, float %1102, i64 2
  %1104 = xor i1 %1100, true
  %1105 = and i1 %1098, %1104
  %1106 = insertelement <8 x i1> %1093, i1 %1105, i64 2
  %1107 = extractelement <8 x i32> %.spill.load227, i64 3
  %1108 = icmp ult i32 %1107, 8
  %1109 = select i1 %1108, i32 %1107, i32 0
  %1110 = extractelement <8 x i1> %57, i32 %1109
  %1111 = extractelement <8 x i1> %57, i64 3
  %1112 = and i1 %1108, %1110
  %1113 = and i1 %1111, %1112
  %1114 = extractelement <8 x float> %1067, i32 %1109
  %1115 = select i1 %1113, float %1114, float 0.000000e+00
  %1116 = insertelement <8 x float> %1103, float %1115, i64 3
  %1117 = xor i1 %1113, true
  %1118 = and i1 %1111, %1117
  %1119 = insertelement <8 x i1> %1106, i1 %1118, i64 3
  %1120 = extractelement <8 x i32> %.spill.load227, i64 4
  %1121 = icmp ult i32 %1120, 8
  %1122 = select i1 %1121, i32 %1120, i32 0
  %1123 = extractelement <8 x i1> %57, i32 %1122
  %1124 = extractelement <8 x i1> %57, i64 4
  %1125 = and i1 %1121, %1123
  %1126 = and i1 %1124, %1125
  %1127 = extractelement <8 x float> %1067, i32 %1122
  %1128 = select i1 %1126, float %1127, float 0.000000e+00
  %1129 = insertelement <8 x float> %1116, float %1128, i64 4
  %1130 = xor i1 %1126, true
  %1131 = and i1 %1124, %1130
  %1132 = insertelement <8 x i1> %1119, i1 %1131, i64 4
  %1133 = extractelement <8 x i32> %.spill.load227, i64 5
  %1134 = icmp ult i32 %1133, 8
  %1135 = select i1 %1134, i32 %1133, i32 0
  %1136 = extractelement <8 x i1> %57, i32 %1135
  %1137 = extractelement <8 x i1> %57, i64 5
  %1138 = and i1 %1134, %1136
  %1139 = and i1 %1137, %1138
  %1140 = extractelement <8 x float> %1067, i32 %1135
  %1141 = select i1 %1139, float %1140, float 0.000000e+00
  %1142 = insertelement <8 x float> %1129, float %1141, i64 5
  %1143 = xor i1 %1139, true
  %1144 = and i1 %1137, %1143
  %1145 = insertelement <8 x i1> %1132, i1 %1144, i64 5
  %1146 = extractelement <8 x i32> %.spill.load227, i64 6
  %1147 = icmp ult i32 %1146, 8
  %1148 = select i1 %1147, i32 %1146, i32 0
  %1149 = extractelement <8 x i1> %57, i32 %1148
  %1150 = extractelement <8 x i1> %57, i64 6
  %1151 = and i1 %1147, %1149
  %1152 = and i1 %1150, %1151
  %1153 = extractelement <8 x float> %1067, i32 %1148
  %1154 = select i1 %1152, float %1153, float 0.000000e+00
  %1155 = insertelement <8 x float> %1142, float %1154, i64 6
  %1156 = xor i1 %1152, true
  %1157 = and i1 %1150, %1156
  %1158 = insertelement <8 x i1> %1145, i1 %1157, i64 6
  %1159 = extractelement <8 x i32> %.spill.load227, i64 7
  %1160 = icmp ult i32 %1159, 8
  %1161 = select i1 %1160, i32 %1159, i32 0
  %1162 = extractelement <8 x i1> %57, i32 %1161
  %1163 = extractelement <8 x i1> %57, i64 7
  %1164 = and i1 %1160, %1162
  %1165 = and i1 %1163, %1164
  %1166 = extractelement <8 x float> %1067, i32 %1161
  %1167 = select i1 %1165, float %1166, float 0.000000e+00
  %1168 = insertelement <8 x float> %1155, float %1167, i64 7
  %1169 = xor i1 %1165, true
  %1170 = and i1 %1163, %1169
  %1171 = insertelement <8 x i1> %1158, i1 %1170, i64 7
  %1172 = fadd <8 x float> %1067, %1168
  %.spill.load228 = load <8 x i32>, ptr %.spill28, align 32
  %1173 = extractelement <8 x i32> %.spill.load228, i64 0
  %1174 = icmp ult i32 %1173, 8
  %1175 = select i1 %1174, i32 %1173, i32 0
  %1176 = extractelement <8 x i1> %57, i32 %1175
  %1177 = extractelement <8 x i1> %57, i64 0
  %1178 = and i1 %1174, %1176
  %1179 = and i1 %1177, %1178
  %1180 = extractelement <8 x float> %1172, i32 %1175
  %1181 = select i1 %1179, float %1180, float 0.000000e+00
  %1182 = insertelement <8 x float> poison, float %1181, i64 0
  %1183 = xor i1 %1179, true
  %1184 = and i1 %1177, %1183
  %1185 = insertelement <8 x i1> poison, i1 %1184, i64 0
  %1186 = extractelement <8 x i32> %.spill.load228, i64 1
  %1187 = icmp ult i32 %1186, 8
  %1188 = select i1 %1187, i32 %1186, i32 0
  %1189 = extractelement <8 x i1> %57, i32 %1188
  %1190 = extractelement <8 x i1> %57, i64 1
  %1191 = and i1 %1187, %1189
  %1192 = and i1 %1190, %1191
  %1193 = extractelement <8 x float> %1172, i32 %1188
  %1194 = select i1 %1192, float %1193, float 0.000000e+00
  %1195 = insertelement <8 x float> %1182, float %1194, i64 1
  %1196 = xor i1 %1192, true
  %1197 = and i1 %1190, %1196
  %1198 = insertelement <8 x i1> %1185, i1 %1197, i64 1
  %1199 = extractelement <8 x i32> %.spill.load228, i64 2
  %1200 = icmp ult i32 %1199, 8
  %1201 = select i1 %1200, i32 %1199, i32 0
  %1202 = extractelement <8 x i1> %57, i32 %1201
  %1203 = extractelement <8 x i1> %57, i64 2
  %1204 = and i1 %1200, %1202
  %1205 = and i1 %1203, %1204
  %1206 = extractelement <8 x float> %1172, i32 %1201
  %1207 = select i1 %1205, float %1206, float 0.000000e+00
  %1208 = insertelement <8 x float> %1195, float %1207, i64 2
  %1209 = xor i1 %1205, true
  %1210 = and i1 %1203, %1209
  %1211 = insertelement <8 x i1> %1198, i1 %1210, i64 2
  %1212 = extractelement <8 x i32> %.spill.load228, i64 3
  %1213 = icmp ult i32 %1212, 8
  %1214 = select i1 %1213, i32 %1212, i32 0
  %1215 = extractelement <8 x i1> %57, i32 %1214
  %1216 = extractelement <8 x i1> %57, i64 3
  %1217 = and i1 %1213, %1215
  %1218 = and i1 %1216, %1217
  %1219 = extractelement <8 x float> %1172, i32 %1214
  %1220 = select i1 %1218, float %1219, float 0.000000e+00
  %1221 = insertelement <8 x float> %1208, float %1220, i64 3
  %1222 = xor i1 %1218, true
  %1223 = and i1 %1216, %1222
  %1224 = insertelement <8 x i1> %1211, i1 %1223, i64 3
  %1225 = extractelement <8 x i32> %.spill.load228, i64 4
  %1226 = icmp ult i32 %1225, 8
  %1227 = select i1 %1226, i32 %1225, i32 0
  %1228 = extractelement <8 x i1> %57, i32 %1227
  %1229 = extractelement <8 x i1> %57, i64 4
  %1230 = and i1 %1226, %1228
  %1231 = and i1 %1229, %1230
  %1232 = extractelement <8 x float> %1172, i32 %1227
  %1233 = select i1 %1231, float %1232, float 0.000000e+00
  %1234 = insertelement <8 x float> %1221, float %1233, i64 4
  %1235 = xor i1 %1231, true
  %1236 = and i1 %1229, %1235
  %1237 = insertelement <8 x i1> %1224, i1 %1236, i64 4
  %1238 = extractelement <8 x i32> %.spill.load228, i64 5
  %1239 = icmp ult i32 %1238, 8
  %1240 = select i1 %1239, i32 %1238, i32 0
  %1241 = extractelement <8 x i1> %57, i32 %1240
  %1242 = extractelement <8 x i1> %57, i64 5
  %1243 = and i1 %1239, %1241
  %1244 = and i1 %1242, %1243
  %1245 = extractelement <8 x float> %1172, i32 %1240
  %1246 = select i1 %1244, float %1245, float 0.000000e+00
  %1247 = insertelement <8 x float> %1234, float %1246, i64 5
  %1248 = xor i1 %1244, true
  %1249 = and i1 %1242, %1248
  %1250 = insertelement <8 x i1> %1237, i1 %1249, i64 5
  %1251 = extractelement <8 x i32> %.spill.load228, i64 6
  %1252 = icmp ult i32 %1251, 8
  %1253 = select i1 %1252, i32 %1251, i32 0
  %1254 = extractelement <8 x i1> %57, i32 %1253
  %1255 = extractelement <8 x i1> %57, i64 6
  %1256 = and i1 %1252, %1254
  %1257 = and i1 %1255, %1256
  %1258 = extractelement <8 x float> %1172, i32 %1253
  %1259 = select i1 %1257, float %1258, float 0.000000e+00
  %1260 = insertelement <8 x float> %1247, float %1259, i64 6
  %1261 = xor i1 %1257, true
  %1262 = and i1 %1255, %1261
  %1263 = insertelement <8 x i1> %1250, i1 %1262, i64 6
  %1264 = extractelement <8 x i32> %.spill.load228, i64 7
  %1265 = icmp ult i32 %1264, 8
  %1266 = select i1 %1265, i32 %1264, i32 0
  %1267 = extractelement <8 x i1> %57, i32 %1266
  %1268 = extractelement <8 x i1> %57, i64 7
  %1269 = and i1 %1265, %1267
  %1270 = and i1 %1268, %1269
  %1271 = extractelement <8 x float> %1172, i32 %1266
  %1272 = select i1 %1270, float %1271, float 0.000000e+00
  %1273 = insertelement <8 x float> %1260, float %1272, i64 7
  %1274 = xor i1 %1270, true
  %1275 = and i1 %1268, %1274
  %1276 = insertelement <8 x i1> %1263, i1 %1275, i64 7
  %1277 = fadd <8 x float> %1172, %1273
  %1278 = extractelement <8 x i1> %57, i32 0
  %1279 = extractelement <8 x i1> %57, i64 0
  %1280 = and i1 true, %1278
  %1281 = and i1 %1279, %1280
  %1282 = extractelement <8 x float> %1277, i32 0
  %1283 = select i1 %1281, float %1282, float 0.000000e+00
  %1284 = insertelement <8 x float> poison, float %1283, i64 0
  %1285 = xor i1 %1281, true
  %1286 = and i1 %1279, %1285
  %1287 = insertelement <8 x i1> poison, i1 %1286, i64 0
  %1288 = extractelement <8 x i1> %57, i32 0
  %1289 = extractelement <8 x i1> %57, i64 1
  %1290 = and i1 true, %1288
  %1291 = and i1 %1289, %1290
  %1292 = extractelement <8 x float> %1277, i32 0
  %1293 = select i1 %1291, float %1292, float 0.000000e+00
  %1294 = insertelement <8 x float> %1284, float %1293, i64 1
  %1295 = xor i1 %1291, true
  %1296 = and i1 %1289, %1295
  %1297 = insertelement <8 x i1> %1287, i1 %1296, i64 1
  %1298 = extractelement <8 x i1> %57, i32 0
  %1299 = extractelement <8 x i1> %57, i64 2
  %1300 = and i1 true, %1298
  %1301 = and i1 %1299, %1300
  %1302 = extractelement <8 x float> %1277, i32 0
  %1303 = select i1 %1301, float %1302, float 0.000000e+00
  %1304 = insertelement <8 x float> %1294, float %1303, i64 2
  %1305 = xor i1 %1301, true
  %1306 = and i1 %1299, %1305
  %1307 = insertelement <8 x i1> %1297, i1 %1306, i64 2
  %1308 = extractelement <8 x i1> %57, i32 0
  %1309 = extractelement <8 x i1> %57, i64 3
  %1310 = and i1 true, %1308
  %1311 = and i1 %1309, %1310
  %1312 = extractelement <8 x float> %1277, i32 0
  %1313 = select i1 %1311, float %1312, float 0.000000e+00
  %1314 = insertelement <8 x float> %1304, float %1313, i64 3
  %1315 = xor i1 %1311, true
  %1316 = and i1 %1309, %1315
  %1317 = insertelement <8 x i1> %1307, i1 %1316, i64 3
  %1318 = extractelement <8 x i1> %57, i32 0
  %1319 = extractelement <8 x i1> %57, i64 4
  %1320 = and i1 true, %1318
  %1321 = and i1 %1319, %1320
  %1322 = extractelement <8 x float> %1277, i32 0
  %1323 = select i1 %1321, float %1322, float 0.000000e+00
  %1324 = insertelement <8 x float> %1314, float %1323, i64 4
  %1325 = xor i1 %1321, true
  %1326 = and i1 %1319, %1325
  %1327 = insertelement <8 x i1> %1317, i1 %1326, i64 4
  %1328 = extractelement <8 x i1> %57, i32 0
  %1329 = extractelement <8 x i1> %57, i64 5
  %1330 = and i1 true, %1328
  %1331 = and i1 %1329, %1330
  %1332 = extractelement <8 x float> %1277, i32 0
  %1333 = select i1 %1331, float %1332, float 0.000000e+00
  %1334 = insertelement <8 x float> %1324, float %1333, i64 5
  %1335 = xor i1 %1331, true
  %1336 = and i1 %1329, %1335
  %1337 = insertelement <8 x i1> %1327, i1 %1336, i64 5
  %1338 = extractelement <8 x i1> %57, i32 0
  %1339 = extractelement <8 x i1> %57, i64 6
  %1340 = and i1 true, %1338
  %1341 = and i1 %1339, %1340
  %1342 = extractelement <8 x float> %1277, i32 0
  %1343 = select i1 %1341, float %1342, float 0.000000e+00
  %1344 = insertelement <8 x float> %1334, float %1343, i64 6
  %1345 = xor i1 %1341, true
  %1346 = and i1 %1339, %1345
  %1347 = insertelement <8 x i1> %1337, i1 %1346, i64 6
  %1348 = extractelement <8 x i1> %57, i32 0
  %1349 = extractelement <8 x i1> %57, i64 7
  %1350 = and i1 true, %1348
  %1351 = and i1 %1349, %1350
  %1352 = extractelement <8 x float> %1277, i32 0
  %1353 = select i1 %1351, float %1352, float 0.000000e+00
  %1354 = insertelement <8 x float> %1344, float %1353, i64 7
  %1355 = xor i1 %1351, true
  %1356 = and i1 %1349, %1355
  %1357 = insertelement <8 x i1> %1347, i1 %1356, i64 7
  %1358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1359 = bitcast <8 x i1> %57 to i8
  %1360 = call i8 @llvm.cttz.i8(i8 %1359, i1 false)
  %1361 = zext i8 %1360 to i32
  %1362 = select i1 %1358, i32 %1361, i32 0
  %1363 = extractelement <8 x float> %1354, i32 %1362
  %1364 = fadd float 0.000000e+00, %1363
  store float %1364, ptr %.spill37, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.21
  store i64 0, ptr %.slot38, align 4
  br label %direct.schedule.23

direct.schedule.23:                               ; preds = %direct.schedule.24, %direct.schedule.22
  %.state229 = load i64, ptr %.slot38, align 4
  %1365 = icmp slt i64 %.state229, 96
  br i1 %1365, label %direct.true230, label %direct.false231

direct.schedule.24:                               ; preds = %direct.true230
  %.state232 = load i64, ptr %.slot38, align 4
  %1366 = mul i64 %.state232, 8
  %.splatinsert233 = insertelement <8 x i64> poison, i64 %1366, i64 0
  %.splat234 = shufflevector <8 x i64> %.splatinsert233, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load235 = load <8 x i64>, ptr %.spill, align 64
  %1367 = add <8 x i64> %.splat234, %.spill.load235
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %1368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %.state237 = load i64, ptr %.slot38, align 4
  %.splatinsert238 = insertelement <8 x i64> poison, i64 %.state237, i64 0
  %.splat239 = shufflevector <8 x i64> %.splatinsert238, <8 x i64> poison, <8 x i32> zeroinitializer
  %1370 = mul <8 x i64> %.splat239, splat (i64 32)
  %1371 = add <8 x i64> %1369, %1370
  %1372 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1368, 0
  %1373 = insertvalue { <8 x ptr>, <8 x i64> } %1372, <8 x i64> %1371, 1
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %1373, 1
  %1376 = extractelement <8 x ptr> %1374, i32 0
  %1377 = extractelement <8 x i64> %1375, i32 0
  %1378 = sub i64 %1377, 0
  %1379 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1380 = select i1 %1379, i64 %1378, i64 0
  %private.contiguous.address240 = getelementptr i8, ptr %1376, i64 %1380
  %private.contiguous.load241 = load <8 x float>, ptr %private.contiguous.address240, align 4
  %1381 = select <8 x i1> %57, <8 x float> %private.contiguous.load241, <8 x float> zeroinitializer
  %.spill.load242 = load float, ptr %.spill37, align 4
  %.splatinsert243 = insertelement <8 x float> poison, float %.spill.load242, i64 0
  %.splat244 = shufflevector <8 x float> %.splatinsert243, <8 x float> poison, <8 x i32> zeroinitializer
  %1382 = fdiv <8 x float> %1381, %.splat244
  %.spill.load245 = load <8 x i64>, ptr %.spill13, align 64
  %1383 = add <8 x i64> %.spill.load245, zeroinitializer
  %1384 = add <8 x i64> zeroinitializer, %1383
  %1385 = add <8 x i64> zeroinitializer, %1367
  %1386 = mul <8 x i64> %1384, splat (i64 768)
  %1387 = add <8 x i64> %1386, %1385
  %1388 = extractvalue { ptr, i64 } %33, 0
  %1389 = extractelement <8 x i64> %1387, i32 0
  %1390 = sub i64 %1389, 0
  %1391 = mul i64 %1390, 4
  %buffer.contiguous.address246 = getelementptr i8, ptr %1388, i64 %1391
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1382, ptr align 1 %buffer.contiguous.address246, <8 x i1> %57)
  %.state247 = load i64, ptr %.slot38, align 4
  %1392 = add i64 %.state247, 1
  store i64 %1392, ptr %.slot38, align 4
  br label %direct.schedule.23

direct.schedule.25:                               ; preds = %direct.false231
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true58:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false59:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true73:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false74:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true87:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false88:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true119:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false120:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true156:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false157:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true191:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false192:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true230:                                   ; preds = %direct.schedule.23
  br label %direct.schedule.24

direct.false231:                                  ; preds = %direct.schedule.23
  br label %direct.schedule.25
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB0_115
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1504
	mov	w8, #0                          ; =0x0
	mov	w1, #32                         ; =0x20
	mov	w10, #260                       ; =0x104
	mov	w11, #1115815936                ; =0x42820000
	ldr	w9, [x2, #44]
	str	w9, [sp, #260]                  ; 4-byte Spill
	ldr	w9, [x2, #48]
	str	w9, [sp, #256]                  ; 4-byte Spill
	str	w11, [sp, #268]                 ; 4-byte Spill
	mov	w14, #50604                     ; =0xc5ac
	movk	w14, #14119, lsl #16
	str	w14, [sp, #264]                 ; 4-byte Spill
	ldp	w9, w15, [x2]
	add	x4, sp, #1216
	ldp	w17, w5, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Spill
	movi.2d	v14, #0000000000000000
	mov	w28, #4                         ; =0x4
	add	x30, sp, #928
	b	LBB0_4
LBB0_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	x21, [x0]
	ldr	x20, [x0, #16]
	ldr	x19, [x0, #48]
	ubfiz	w22, w7, #2, #27
	umull	x9, w22, w10
	umaddl	x15, w22, w10, x21
	ldp	q25, q1, [x15]
	ldp	q23, q24, [x15, #32]
	ldp	q22, q21, [x15, #64]
	ldp	q19, q20, [x15, #96]
	ldp	q18, q17, [x15, #128]
	ldp	q7, q16, [x15, #160]
	ldp	q6, q5, [x15, #192]
	ldp	q3, q4, [x15, #224]
	add	x15, x9, #256
	ldr	s26, [x21, x15]
	ldp	q31, q30, [x20]
	ldp	q29, q28, [x20, #32]
	ldp	q27, q0, [x20, #64]
	str	q0, [sp, #240]                  ; 16-byte Spill
	fmul.4s	v8, v25, v25
	fmul.4s	v9, v1, v1
	fmul.4s	v10, v24, v24
	fmul.4s	v11, v23, v23
	fmul.4s	v12, v22, v22
	fmul.4s	v13, v21, v21
	fmul.4s	v14, v20, v20
	fmul.4s	v15, v19, v19
	fmul.4s	v2, v3, v3
	fadd.4s	v2, v15, v2
	fmul.4s	v15, v4, v4
	fadd.4s	v14, v14, v15
	fmul.4s	v15, v5, v5
	fadd.4s	v13, v13, v15
	fmul.4s	v15, v6, v6
	fadd.4s	v12, v12, v15
	fmul.4s	v15, v7, v7
	fadd.4s	v11, v11, v15
	fmul.4s	v15, v16, v16
	fadd.4s	v10, v10, v15
	fmul.4s	v15, v17, v17
	fadd.4s	v9, v9, v15
	fmul.4s	v15, v18, v18
	fadd.4s	v8, v8, v15
	fmul.4s	v15, v26, v26
	fadd.4s	v15, v8, v15
	mov.s	v8[0], v15[0]
	fadd.4s	v9, v10, v9
	ldp	q15, q10, [x20, #96]
	fadd.4s	v8, v11, v8
	fadd.4s	v8, v12, v8
	ldp	q12, q11, [x20, #128]
	fadd.4s	v9, v13, v9
	fadd.4s	v9, v14, v9
	ldp	q14, q13, [x20, #160]
	fadd.4s	v2, v2, v8
	rev64.4s	v8, v9
	fadd.4s	v8, v9, v8
	rev64.4s	v9, v2
	fadd.4s	v2, v2, v9
	dup.4s	v9, v8[2]
	fadd.4s	v8, v8, v9
	dup.4s	v9, v2[2]
	fadd.4s	v2, v2, v9
	fadd.4s	v2, v2, v8
	ldp	q9, q8, [x20, #192]
	movi.2d	v0, #0000000000000000
	fadd	s2, s2, s0
	ldr	s0, [sp, #268]                  ; 4-byte Reload
	fdiv	s2, s2, s0
	ldr	s0, [sp, #264]                  ; 4-byte Reload
	fadd	s2, s2, s0
	fsqrt	s2, s2
	dup.4s	v2, v2[0]
	fdiv.4s	v1, v1, v2
	fdiv.4s	v25, v25, v2
	fmul.4s	v25, v31, v25
	fmul.4s	v1, v30, v1
	ldp	q31, q30, [x20, #224]
	umaddl	x9, w22, w10, x19
	ldr	s0, [x20, #256]
	stp	q25, q1, [x9]
	fdiv.4s	v1, v24, v2
	fdiv.4s	v23, v23, v2
	fmul.4s	v23, v29, v23
	fmul.4s	v1, v28, v1
	stp	q23, q1, [x9, #32]
	fdiv.4s	v1, v21, v2
	fdiv.4s	v21, v22, v2
	fmul.4s	v21, v27, v21
	ldr	q22, [sp, #240]                 ; 16-byte Reload
	fmul.4s	v1, v22, v1
	stp	q21, q1, [x9, #64]
	fdiv.4s	v1, v20, v2
	fdiv.4s	v19, v19, v2
	fmul.4s	v19, v15, v19
	fmul.4s	v1, v10, v1
	stp	q19, q1, [x9, #96]
	fdiv.4s	v1, v17, v2
	fdiv.4s	v17, v18, v2
	fmul.4s	v17, v12, v17
	fmul.4s	v1, v11, v1
	stp	q17, q1, [x9, #128]
	fdiv.4s	v1, v16, v2
	fdiv.4s	v7, v7, v2
	fmul.4s	v7, v14, v7
	fmul.4s	v1, v13, v1
	stp	q7, q1, [x9, #160]
	fdiv.4s	v1, v5, v2
	fdiv.4s	v5, v6, v2
	fmul.4s	v5, v9, v5
	fmul.4s	v1, v8, v1
	stp	q5, q1, [x9, #192]
	fdiv.4s	v1, v4, v2
	fdiv.4s	v3, v3, v2
	fmul.4s	v3, v31, v3
	fmul.4s	v1, v30, v1
	stp	q3, q1, [x9, #224]
	fdiv.4s	v1, v26, v2
	fmul.4s	v0, v0, v1
	str	s0, [x19, x15]
	mov	w22, #1                         ; =0x1
	bfi	w22, w7, #2, #27
	umull	x9, w22, w10
	umaddl	x15, w22, w10, x21
	ldp	q25, q1, [x15]
	ldp	q23, q24, [x15, #32]
	ldp	q22, q21, [x15, #64]
	ldp	q19, q20, [x15, #96]
	ldp	q18, q17, [x15, #128]
	ldp	q7, q16, [x15, #160]
	ldp	q3, q5, [x15, #192]
	ldp	q27, q26, [x15, #224]
	add	x15, x9, #256
	ldr	s28, [x21, x15]
	ldp	q31, q30, [x20]
	ldp	q29, q2, [x20, #32]
	ldp	q0, q4, [x20, #64]
	str	q4, [sp, #240]                  ; 16-byte Spill
	stp	q2, q0, [sp, #208]              ; 32-byte Folded Spill
	fmul.4s	v2, v25, v25
	fmul.4s	v8, v1, v1
	fmul.4s	v9, v24, v24
	fmul.4s	v10, v23, v23
	fmul.4s	v11, v22, v22
	fmul.4s	v12, v21, v21
	fmul.4s	v13, v20, v20
	fmul.4s	v14, v19, v19
	fmul.4s	v15, v27, v27
	fadd.4s	v14, v14, v15
	fmul.4s	v15, v26, v26
	fadd.4s	v13, v13, v15
	fmul.4s	v15, v5, v5
	fadd.4s	v12, v12, v15
	fmul.4s	v15, v3, v3
	fadd.4s	v11, v11, v15
	fmul.4s	v15, v7, v7
	fadd.4s	v10, v10, v15
	fmul.4s	v15, v16, v16
	fadd.4s	v9, v9, v15
	fmul.4s	v15, v17, v17
	fadd.4s	v8, v8, v15
	fmul.4s	v15, v18, v18
	fadd.4s	v2, v2, v15
	fmul.4s	v15, v28, v28
	fadd.4s	v15, v2, v15
	mov.s	v2[0], v15[0]
	fadd.4s	v8, v9, v8
	ldp	q15, q9, [x20, #96]
	fadd.4s	v2, v10, v2
	fadd.4s	v2, v11, v2
	ldp	q11, q10, [x20, #128]
	fadd.4s	v8, v12, v8
	fadd.4s	v8, v13, v8
	ldp	q13, q12, [x20, #160]
	fadd.4s	v2, v14, v2
	rev64.4s	v14, v8
	fadd.4s	v8, v8, v14
	rev64.4s	v14, v2
	fadd.4s	v2, v2, v14
	dup.4s	v14, v8[2]
	fadd.4s	v8, v8, v14
	dup.4s	v14, v2[2]
	fadd.4s	v2, v2, v14
	fadd.4s	v2, v2, v8
	ldp	q14, q8, [x20, #192]
	movi.2d	v0, #0000000000000000
	fadd	s2, s2, s0
	ldr	s4, [sp, #268]                  ; 4-byte Reload
	fdiv	s2, s2, s4
	ldr	s6, [sp, #264]                  ; 4-byte Reload
	fadd	s2, s2, s6
	fsqrt	s2, s2
	dup.4s	v2, v2[0]
	fdiv.4s	v1, v1, v2
	fdiv.4s	v25, v25, v2
	fmul.4s	v25, v31, v25
	fmul.4s	v1, v30, v1
	ldp	q31, q30, [x20, #224]
	umaddl	x9, w22, w10, x19
	ldr	s0, [x20, #256]
	stp	q25, q1, [x9]
	fdiv.4s	v1, v24, v2
	fdiv.4s	v23, v23, v2
	fmul.4s	v23, v29, v23
	ldr	q24, [sp, #208]                 ; 16-byte Reload
	fmul.4s	v1, v24, v1
	stp	q23, q1, [x9, #32]
	fdiv.4s	v1, v21, v2
	fdiv.4s	v21, v22, v2
	ldp	q23, q22, [sp, #224]            ; 32-byte Folded Reload
	fmul.4s	v21, v23, v21
	fmul.4s	v1, v22, v1
	stp	q21, q1, [x9, #64]
	fdiv.4s	v1, v20, v2
	fdiv.4s	v19, v19, v2
	fmul.4s	v19, v15, v19
	fmul.4s	v1, v9, v1
	stp	q19, q1, [x9, #96]
	fdiv.4s	v1, v17, v2
	fdiv.4s	v17, v18, v2
	fmul.4s	v17, v11, v17
	fmul.4s	v1, v10, v1
	stp	q17, q1, [x9, #128]
	fdiv.4s	v1, v16, v2
	fdiv.4s	v7, v7, v2
	fmul.4s	v7, v13, v7
	fmul.4s	v1, v12, v1
	stp	q7, q1, [x9, #160]
	fdiv.4s	v1, v5, v2
	fdiv.4s	v5, v3, v2
	fmul.4s	v5, v14, v5
	fmul.4s	v1, v8, v1
	stp	q5, q1, [x9, #192]
	fdiv.4s	v1, v26, v2
	fdiv.4s	v3, v27, v2
	fmul.4s	v3, v31, v3
	fmul.4s	v1, v30, v1
	stp	q3, q1, [x9, #224]
	fdiv.4s	v1, v28, v2
	fmul.4s	v0, v0, v1
	str	s0, [x19, x15]
	mov	w22, #2                         ; =0x2
	bfi	w22, w7, #2, #27
	umull	x9, w22, w10
	umaddl	x15, w22, w10, x21
	ldp	q25, q1, [x15]
	ldp	q24, q23, [x15, #32]
	ldp	q22, q21, [x15, #64]
	ldp	q19, q20, [x15, #96]
	ldp	q18, q17, [x15, #128]
	ldp	q7, q16, [x15, #160]
	ldp	q3, q5, [x15, #192]
	ldp	q27, q26, [x15, #224]
	add	x15, x9, #256
	ldr	s28, [x21, x15]
	ldp	q31, q30, [x20]
	ldp	q29, q2, [x20, #32]
	ldr	q0, [x20, #80]
	str	q0, [sp, #240]                  ; 16-byte Spill
	ldr	q0, [x20, #64]
	stp	q2, q0, [sp, #208]              ; 32-byte Folded Spill
	fmul.4s	v2, v25, v25
	fmul.4s	v8, v1, v1
	fmul.4s	v9, v23, v23
	fmul.4s	v10, v24, v24
	fmul.4s	v11, v22, v22
	fmul.4s	v12, v21, v21
	fmul.4s	v13, v20, v20
	fmul.4s	v14, v19, v19
	fmul.4s	v15, v27, v27
	fadd.4s	v14, v14, v15
	fmul.4s	v15, v26, v26
	fadd.4s	v13, v13, v15
	fmul.4s	v15, v5, v5
	fadd.4s	v12, v12, v15
	fmul.4s	v15, v3, v3
	fadd.4s	v11, v11, v15
	fmul.4s	v15, v7, v7
	fadd.4s	v10, v10, v15
	fmul.4s	v15, v16, v16
	fadd.4s	v9, v9, v15
	fmul.4s	v15, v17, v17
	fadd.4s	v8, v8, v15
	fmul.4s	v15, v18, v18
	fadd.4s	v2, v2, v15
	fmul.4s	v15, v28, v28
	fadd.4s	v15, v2, v15
	mov.s	v2[0], v15[0]
	fadd.4s	v8, v9, v8
	ldp	q15, q9, [x20, #96]
	fadd.4s	v2, v10, v2
	fadd.4s	v2, v11, v2
	ldp	q11, q10, [x20, #128]
	fadd.4s	v8, v12, v8
	fadd.4s	v8, v13, v8
	ldp	q13, q12, [x20, #160]
	fadd.4s	v2, v14, v2
	rev64.4s	v14, v8
	fadd.4s	v8, v8, v14
	rev64.4s	v14, v2
	fadd.4s	v2, v2, v14
	dup.4s	v14, v8[2]
	fadd.4s	v8, v8, v14
	dup.4s	v14, v2[2]
	fadd.4s	v2, v2, v14
	fadd.4s	v2, v2, v8
	ldp	q14, q8, [x20, #192]
	movi.2d	v0, #0000000000000000
	fadd	s2, s2, s0
	fdiv	s2, s2, s4
	fadd	s2, s2, s6
	fsqrt	s2, s2
	dup.4s	v2, v2[0]
	fdiv.4s	v1, v1, v2
	fdiv.4s	v25, v25, v2
	fmul.4s	v25, v31, v25
	fmul.4s	v1, v30, v1
	ldp	q31, q30, [x20, #224]
	umaddl	x9, w22, w10, x19
	ldr	s0, [x20, #256]
	stp	q25, q1, [x9]
	fdiv.4s	v1, v24, v2
	fmul.4s	v1, v29, v1
	fdiv.4s	v23, v23, v2
	ldp	q6, q4, [sp, #208]              ; 32-byte Folded Reload
	fmul.4s	v23, v6, v23
	stp	q1, q23, [x9, #32]
	fdiv.4s	v1, v21, v2
	fdiv.4s	v21, v22, v2
	fmul.4s	v21, v4, v21
	ldr	q4, [sp, #240]                  ; 16-byte Reload
	fmul.4s	v1, v4, v1
	stp	q21, q1, [x9, #64]
	fdiv.4s	v1, v20, v2
	fdiv.4s	v19, v19, v2
	fmul.4s	v19, v15, v19
	fmul.4s	v1, v9, v1
	stp	q19, q1, [x9, #96]
	fdiv.4s	v1, v17, v2
	fdiv.4s	v17, v18, v2
	fmul.4s	v17, v11, v17
	fmul.4s	v1, v10, v1
	stp	q17, q1, [x9, #128]
	fdiv.4s	v1, v16, v2
	fdiv.4s	v7, v7, v2
	fmul.4s	v7, v13, v7
	fmul.4s	v1, v12, v1
	stp	q7, q1, [x9, #160]
	fdiv.4s	v1, v5, v2
	fdiv.4s	v5, v3, v2
	fmul.4s	v5, v14, v5
	movi.2d	v14, #0000000000000000
	fmul.4s	v1, v8, v1
	stp	q5, q1, [x9, #192]
	fdiv.4s	v1, v26, v2
	fdiv.4s	v3, v27, v2
	fmul.4s	v3, v31, v3
	fmul.4s	v1, v30, v1
	stp	q3, q1, [x9, #224]
	fdiv.4s	v1, v28, v2
	fmul.4s	v0, v0, v1
	str	s0, [x19, x15]
	mov	w15, #3                         ; =0x3
	bfi	w15, w7, #2, #27
	umull	x9, w15, w10
	umaddl	x17, w15, w10, x21
	ldp	q25, q24, [x17]
	ldp	q23, q1, [x17, #32]
	ldp	q22, q21, [x17, #64]
	ldp	q20, q19, [x17, #96]
	ldp	q0, q18, [x17, #128]
	ldp	q17, q16, [x17, #160]
	ldp	q7, q6, [x17, #192]
	ldp	q5, q4, [x17, #224]
	add	x22, x9, #256
	ldr	s3, [x21, x22]
	ldp	q29, q28, [x20]
	ldp	q27, q26, [x20, #32]
	fmul.4s	v2, v25, v25
	fmul.4s	v30, v24, v24
	fmul.4s	v31, v1, v1
	fmul.4s	v8, v23, v23
	fmul.4s	v9, v22, v22
	fmul.4s	v10, v21, v21
	fmul.4s	v11, v19, v19
	fmul.4s	v12, v20, v20
	fmul.4s	v13, v5, v5
	fadd.4s	v12, v12, v13
	fmul.4s	v13, v4, v4
	fadd.4s	v11, v11, v13
	fmul.4s	v13, v6, v6
	fadd.4s	v10, v10, v13
	fmul.4s	v13, v7, v7
	fadd.4s	v9, v9, v13
	fmul.4s	v13, v17, v17
	fadd.4s	v8, v8, v13
	fmul.4s	v13, v16, v16
	fadd.4s	v31, v31, v13
	fmul.4s	v13, v0, v0
	fadd.4s	v2, v2, v13
	fmul.4s	v13, v3, v3
	fadd.4s	v13, v2, v13
	mov.s	v2[0], v13[0]
	fmul.4s	v13, v18, v18
	fadd.4s	v30, v30, v13
	fadd.4s	v30, v31, v30
	ldp	q13, q31, [x20, #64]
	fadd.4s	v2, v8, v2
	fadd.4s	v2, v9, v2
	ldp	q9, q8, [x20, #96]
	fadd.4s	v30, v10, v30
	fadd.4s	v30, v11, v30
	fadd.4s	v2, v12, v2
	rev64.4s	v10, v2
	rev64.4s	v11, v30
	fadd.4s	v30, v30, v11
	fadd.4s	v2, v2, v10
	dup.4s	v10, v30[2]
	ldp	q12, q11, [x20, #128]
	fadd.4s	v30, v30, v10
	dup.4s	v10, v2[2]
	fadd.4s	v2, v2, v10
	fadd.4s	v2, v2, v30
	fadd	s2, s2, s14
	ldr	s30, [sp, #268]                 ; 4-byte Reload
	fdiv	s2, s2, s30
	ldr	s30, [sp, #264]                 ; 4-byte Reload
	fadd	s2, s2, s30
	fsqrt	s2, s2
	dup.4s	v30, v2[0]
	ldp	q10, q2, [x20, #160]
	fdiv.4s	v24, v24, v30
	fdiv.4s	v25, v25, v30
	fmul.4s	v25, v29, v25
	fmul.4s	v24, v28, v24
	ldp	q29, q28, [x20, #192]
	fdiv.4s	v1, v1, v30
	fdiv.4s	v23, v23, v30
	fmul.4s	v23, v27, v23
	fmul.4s	v1, v26, v1
	ldp	q27, q26, [x20, #224]
	fdiv.4s	v22, v22, v30
	fmul.4s	v22, v13, v22
	ldr	s13, [x20, #256]
	umaddl	x9, w15, w10, x19
	stp	q25, q24, [x9]
	fdiv.4s	v21, v21, v30
	fmul.4s	v21, v31, v21
	fdiv.4s	v20, v20, v30
	fmul.4s	v20, v9, v20
	stp	q23, q1, [x9, #32]
	fdiv.4s	v1, v19, v30
	fmul.4s	v1, v8, v1
	stp	q22, q21, [x9, #64]
	fdiv.4s	v0, v0, v30
	fmul.4s	v0, v12, v0
	stp	q20, q1, [x9, #96]
	fdiv.4s	v1, v18, v30
	fmul.4s	v1, v11, v1
	stp	q0, q1, [x9, #128]
	fdiv.4s	v0, v17, v30
	fmul.4s	v0, v10, v0
	fdiv.4s	v1, v16, v30
	fmul.4s	v1, v2, v1
	stp	q0, q1, [x9, #160]
	fdiv.4s	v0, v7, v30
	fmul.4s	v0, v29, v0
	fdiv.4s	v1, v6, v30
	fmul.4s	v1, v28, v1
	stp	q0, q1, [x9, #192]
	fdiv.4s	v0, v5, v30
	fmul.4s	v0, v27, v0
	fdiv.4s	v1, v4, v30
	fmul.4s	v1, v26, v1
	stp	q0, q1, [x9, #224]
	fdiv.4s	v0, v3, v30
	fmul.4s	v0, v13, v0
	str	s0, [x19, x22]
LBB0_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	w9, w7, #1
	ldr	w12, [sp, #260]                 ; 4-byte Reload
	cmp	w9, w12
	cset	w12, eq
	csinc	w9, wzr, w7, eq
	cinc	w13, w6, eq
	ldr	w15, [sp, #256]                 ; 4-byte Reload
	cmp	w13, w15
	cset	w15, eq
	ands	w12, w12, w15
	csel	w15, wzr, w13, ne
	add	w17, w16, w12
	add	w8, w8, #1
	cmp	w8, w3
	b.eq	LBB0_114
LBB0_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_12 Depth 2
                                        ;     Child Loop BB0_38 Depth 2
                                        ;     Child Loop BB0_41 Depth 2
                                        ;     Child Loop BB0_68 Depth 2
	mov	x16, x17
	mov	x6, x15
	mov	x7, x9
	ubfiz	x9, x9, #5, #32
	cmp	x9, x5
	csel	x15, x9, xzr, ls
	subs	x17, x5, x15
	cmp	x17, #32
	csel	x17, x17, x1, lo
	cmp	x5, x15
	ccmp	x9, x5, #2, hi
	csel	x19, x17, xzr, ls
	cmp	x19, #32
	b.hs	LBB0_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	lsr	x20, x19, #3
	cbz	x20, LBB0_8
; %bb.6:                                ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	x21, [x0]
	ldr	x22, [x0, #16]
	ldr	x23, [x0, #48]
	add	x24, x22, #256
	lsl	w25, w7, #2
	mov	x26, x20
LBB0_7:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w15, w25, #0x1fffffff
	umaddl	x9, w15, w10, x21
	umull	x17, w15, w10
	ldp	q25, q24, [x9]
	ldp	q23, q1, [x9, #32]
	ldp	q22, q21, [x9, #64]
	ldp	q20, q19, [x9, #96]
	ldp	q0, q18, [x9, #128]
	ldp	q17, q16, [x9, #160]
	ldp	q7, q4, [x9, #192]
	add	x27, x17, #256
	ldr	s3, [x21, x27]
	ldp	q6, q5, [x9, #224]
	ldp	q27, q26, [x22]
	fmul.4s	v2, v25, v25
	fmul.4s	v28, v24, v24
	fmul.4s	v29, v1, v1
	fmul.4s	v30, v23, v23
	fmul.4s	v31, v22, v22
	fmul.4s	v8, v21, v21
	fmul.4s	v9, v19, v19
	fmul.4s	v10, v20, v20
	fmul.4s	v11, v5, v5
	fmul.4s	v12, v6, v6
	fadd.4s	v10, v10, v12
	fadd.4s	v9, v9, v11
	fmul.4s	v11, v7, v7
	fmul.4s	v12, v4, v4
	fadd.4s	v8, v8, v12
	fadd.4s	v31, v31, v11
	fmul.4s	v11, v16, v16
	fmul.4s	v12, v17, v17
	fadd.4s	v30, v30, v12
	fmul.4s	v12, v0, v0
	fadd.4s	v29, v29, v11
	fmul.4s	v11, v18, v18
	fadd.4s	v28, v28, v11
	fadd.4s	v2, v2, v12
	fmul.4s	v11, v3, v3
	ldp	q13, q12, [x22, #32]
	fadd.4s	v11, v2, v11
	mov.s	v2[0], v11[0]
	fadd.4s	v28, v29, v28
	fadd.4s	v2, v30, v2
	fadd.4s	v2, v31, v2
	fadd.4s	v28, v8, v28
	fadd.4s	v28, v9, v28
	fadd.4s	v2, v10, v2
	rev64.4s	v29, v2
	rev64.4s	v30, v28
	fadd.4s	v28, v28, v30
	fadd.4s	v2, v2, v29
	dup.4s	v29, v2[2]
	dup.4s	v30, v28[2]
	ldp	q8, q31, [x22, #64]
	fadd.4s	v28, v28, v30
	fadd.4s	v2, v2, v29
	fadd.4s	v2, v2, v28
	ldp	q30, q29, [x22, #96]
	fadd	s2, s2, s14
	fmov	s28, w11
	fdiv	s2, s2, s28
	fmov	s28, w14
	ldp	q10, q9, [x22, #128]
	fadd	s2, s2, s28
	fsqrt	s2, s2
	dup.4s	v28, v2[0]
	ldp	q11, q2, [x22, #160]
	fdiv.4s	v24, v24, v28
	fdiv.4s	v25, v25, v28
	fmul.4s	v25, v27, v25
	fmul.4s	v24, v26, v24
	ldp	q27, q26, [x22, #192]
	fdiv.4s	v1, v1, v28
	fdiv.4s	v23, v23, v28
	fmul.4s	v23, v13, v23
	fmul.4s	v1, v12, v1
	ldp	q13, q12, [x22, #224]
	fdiv.4s	v22, v22, v28
	fmul.4s	v22, v8, v22
	ldr	s8, [x24]
	umaddl	x9, w15, w10, x23
	stp	q25, q24, [x9]
	fdiv.4s	v21, v21, v28
	fmul.4s	v21, v31, v21
	fdiv.4s	v20, v20, v28
	fmul.4s	v20, v30, v20
	stp	q23, q1, [x9, #32]
	fdiv.4s	v1, v19, v28
	fmul.4s	v1, v29, v1
	fdiv.4s	v0, v0, v28
	fmul.4s	v0, v10, v0
	stp	q22, q21, [x9, #64]
	stp	q20, q1, [x9, #96]
	fdiv.4s	v1, v18, v28
	fmul.4s	v1, v9, v1
	stp	q0, q1, [x9, #128]
	fdiv.4s	v0, v17, v28
	fmul.4s	v0, v11, v0
	fdiv.4s	v1, v16, v28
	fmul.4s	v1, v2, v1
	stp	q0, q1, [x9, #160]
	fdiv.4s	v0, v7, v28
	fmul.4s	v0, v27, v0
	fdiv.4s	v1, v4, v28
	fmul.4s	v1, v26, v1
	stp	q0, q1, [x9, #192]
	fdiv.4s	v0, v6, v28
	fmul.4s	v0, v13, v0
	fdiv.4s	v1, v5, v28
	fmul.4s	v1, v12, v1
	stp	q0, q1, [x9, #224]
	fdiv.4s	v0, v3, v28
	fmul.4s	v0, v8, v0
	str	s0, [x23, x27]
	add	w25, w25, #1
	subs	w26, w26, #1
	b.ne	LBB0_7
LBB0_8:                                 ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w9, w19, #0x7
	cbz	w9, LBB0_3
; %bb.9:                                ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	dup.4s	v0, w9
Lloh0:
	adrp	x9, lCPI0_1@PAGE
Lloh1:
	ldr	q1, [x9, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x9, lCPI0_2@PAGE
Lloh3:
	ldr	q2, [x9, lCPI0_2@PAGEOFF]
	cmhi.4s	v16, v0, v2
	cmhi.4s	v17, v0, v1
	uzp1.8h	v3, v17, v16
	umaxv.8h	h0, v3
	fmov	w9, s0
	tbz	w9, #0, LBB0_3
; %bb.10:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x15, #0                         ; =0x0
	ldr	x23, [x0]
	ldr	x21, [x0, #16]
	ldr	x19, [x0, #48]
Lloh4:
	adrp	x9, lCPI0_0@PAGE
Lloh5:
	ldr	q0, [x9, lCPI0_0@PAGEOFF]
	and.16b	v0, v3, v0
	addv.8h	h18, v0
	ubfiz	w9, w7, #2, #27
	orr	w9, w9, w20
	fmov	w17, s18
	and	w12, w17, #0xff
	str	w12, [sp, #208]                 ; 4-byte Spill
	dup.4s	v0, w9
	and.16b	v1, v17, v0
	and.16b	v0, v16, v0
	ushll2.2d	v21, v0, #0
	ushll2.2d	v4, v1, #0
	ushll.2d	v6, v0, #0
	ushll.2d	v5, v1, #0
	fmov	x9, d5
	umaddl	x20, w9, w10, x23
	b	LBB0_12
LBB0_11:                                ; %else50
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x9, x4, x15
	stp	q0, q1, [x9]
	add	x15, x15, #32
	cmp	x15, #256
	b.eq	LBB0_28
LBB0_12:                                ; %direct.true.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s18
	add	x17, x20, x15
	add	x1, x4, x15
	ldr	q0, [x1]
	tbnz	w9, #0, LBB0_20
; %bb.13:                               ; %else
                                        ;   in Loop: Header=BB0_12 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_21
LBB0_14:                                ; %else32
                                        ;   in Loop: Header=BB0_12 Depth=2
	tbnz	w9, #2, LBB0_22
LBB0_15:                                ; %else35
                                        ;   in Loop: Header=BB0_12 Depth=2
	tbnz	w9, #3, LBB0_23
LBB0_16:                                ; %else38
                                        ;   in Loop: Header=BB0_12 Depth=2
	ldr	q1, [x1, #16]
	tbnz	w9, #4, LBB0_24
LBB0_17:                                ; %else41
                                        ;   in Loop: Header=BB0_12 Depth=2
	tbnz	w9, #5, LBB0_25
LBB0_18:                                ; %else44
                                        ;   in Loop: Header=BB0_12 Depth=2
	tbnz	w9, #6, LBB0_26
LBB0_19:                                ; %else47
                                        ;   in Loop: Header=BB0_12 Depth=2
	tbz	w9, #7, LBB0_11
	b	LBB0_27
LBB0_20:                                ; %cond.load
                                        ;   in Loop: Header=BB0_12 Depth=2
	ld1.s	{ v0 }[0], [x17]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_14
LBB0_21:                                ; %cond.load31
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x2, x17, #4
	ld1.s	{ v0 }[1], [x2]
	tbz	w9, #2, LBB0_15
LBB0_22:                                ; %cond.load34
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x2, x17, #8
	ld1.s	{ v0 }[2], [x2]
	tbz	w9, #3, LBB0_16
LBB0_23:                                ; %cond.load37
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x2, x17, #12
	ld1.s	{ v0 }[3], [x2]
	ldr	q1, [x1, #16]
	tbz	w9, #4, LBB0_17
LBB0_24:                                ; %cond.load40
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x1, x17, #16
	ld1.s	{ v1 }[0], [x1]
	tbz	w9, #5, LBB0_18
LBB0_25:                                ; %cond.load43
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x1, x17, #20
	ld1.s	{ v1 }[1], [x1]
	tbz	w9, #6, LBB0_19
LBB0_26:                                ; %cond.load46
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x1, x17, #24
	ld1.s	{ v1 }[2], [x1]
	tbz	w9, #7, LBB0_11
LBB0_27:                                ; %cond.load49
                                        ;   in Loop: Header=BB0_12 Depth=2
	add	x9, x17, #28
	ld1.s	{ v1 }[3], [x9]
	b	LBB0_11
LBB0_28:                                ; %direct.true56.preheader.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	xtn.8b	v30, v3
	sshll.2d	v0, v17, #0
	sshll.2d	v3, v16, #0
	sshll2.2d	v26, v17, #0
	sshll2.2d	v27, v16, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q1, [x9, lCPI0_6@PAGEOFF]
	and.16b	v19, v0, v1
Lloh8:
	adrp	x9, lCPI0_7@PAGE
Lloh9:
	ldr	q1, [x9, lCPI0_7@PAGEOFF]
	and.16b	v25, v0, v1
Lloh10:
	adrp	x9, lCPI0_8@PAGE
Lloh11:
	ldr	q0, [x9, lCPI0_8@PAGEOFF]
	and.16b	v0, v3, v0
Lloh12:
	adrp	x9, lCPI0_9@PAGE
Lloh13:
	ldr	q1, [x9, lCPI0_9@PAGEOFF]
	and.16b	v1, v26, v1
Lloh14:
	adrp	x9, lCPI0_10@PAGE
Lloh15:
	ldr	q2, [x9, lCPI0_10@PAGEOFF]
	movi.8b	v7, #1
	and.8b	v7, v30, v7
	umov.b	w15, v7[0]
	movi.2d	v22, #0000000000000000
	mov.b	v22[0], v30[0]
	and.16b	v2, v27, v2
	umaxv.8b	b7, v22
	fmov	w9, s7
	rbit	w17, w15
	clz	w17, w17
	tst	w9, #0x1
	csel	w20, w17, wzr, ne
	mov	w12, #64                        ; =0x40
	dup.2d	v7, x12
	str	q19, [sp, #64]                  ; 16-byte Spill
	orr.16b	v23, v19, v7
	xtn.2s	v5, v5
	str	q23, [sp, #128]                 ; 16-byte Spill
	movi.2s	v19, #65
	umlal.2d	v23, v5, v19
	movi.2d	v20, #0000000000000000
	mov.b	v20[0], v30[0]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	str	q23, [sp, #224]                 ; 16-byte Spill
	and.16b	v20, v20, v23
	movi.2d	v19, #0000000000000000
	stp	q19, q19, [sp, #816]
	stp	q20, q19, [sp, #784]
	ubfiz	x17, x20, #3, #3
	add	x12, sp, #784
	ldr	x1, [x12, x17]
	sub	x1, x1, x20
	add	x24, x23, x1, lsl #2
	stp	q0, q2, [sp, #880]
	stp	q25, q1, [sp, #848]
	add	x12, sp, #848
	ldr	x17, [x12, x17]
	orr	x17, x17, #0x100
	sub	x17, x17, w20, uxtw #2
	tst	w15, #0x1
	csel	x23, xzr, x17, eq
	add	x17, x4, x23
	ldp	q11, q10, [x17]
	tbnz	w9, #0, LBB0_93
; %bb.29:                               ; %else54
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #1, LBB0_94
LBB0_30:                                ; %else57
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #2, LBB0_95
LBB0_31:                                ; %else60
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #3, LBB0_96
LBB0_32:                                ; %else63
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #4, LBB0_97
LBB0_33:                                ; %else66
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #5, LBB0_98
LBB0_34:                                ; %else69
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #6, LBB0_99
LBB0_35:                                ; %else72
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w15, #7, LBB0_37
LBB0_36:                                ; %cond.load74
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x24, #28
	ld1.s	{ v10 }[3], [x9]
LBB0_37:                                ; %else75
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q22, [sp, #240]                 ; 16-byte Spill
Lloh16:
	adrp	x9, lCPI0_3@PAGE
Lloh17:
	ldr	q0, [x9, lCPI0_3@PAGEOFF]
	and.16b	v1, v27, v0
Lloh18:
	adrp	x9, lCPI0_4@PAGE
Lloh19:
	ldr	q0, [x9, lCPI0_4@PAGEOFF]
	and.16b	v2, v26, v0
Lloh20:
	adrp	x9, lCPI0_5@PAGE
Lloh21:
	ldr	q0, [x9, lCPI0_5@PAGEOFF]
	and.16b	v0, v3, v0
	stp	q0, q2, [sp, #16]               ; 32-byte Folded Spill
	orr.16b	v19, v0, v7
	orr.16b	v20, v2, v7
	str	q1, [sp, #48]                   ; 16-byte Spill
	orr.16b	v7, v1, v7
	movi.2s	v3, #65
	umull.2d	v0, v5, v3
	str	q0, [sp, #144]                  ; 16-byte Spill
	xtn.2s	v0, v4
	xtn.2s	v1, v6
	xtn.2s	v2, v21
	stp	q19, q7, [sp, #96]              ; 32-byte Folded Spill
	mov.16b	v4, v7
	umlal.2d	v4, v2, v3
	str	q20, [sp, #80]                  ; 16-byte Spill
	mov.16b	v2, v20
	umlal.2d	v2, v0, v3
	stp	q2, q4, [sp, #176]              ; 32-byte Folded Spill
	mov.16b	v0, v19
	umlal.2d	v0, v1, v3
	str	q0, [sp, #160]                  ; 16-byte Spill
	sshll.2d	v1, v17, #0
	sshll.2d	v2, v16, #0
	add	x9, x4, x23
	stp	q11, q10, [x9]
	dup.2d	v3, x28
	and.16b	v0, v27, v3
	and.16b	v22, v26, v3
	and.16b	v23, v2, v3
	and.16b	v28, v1, v3
	fmov	x9, d28
	ldr	q1, [sp, #1328]
	ldr	q2, [sp, #1312]
	fmul.4s	v2, v2, v2
	fmul.4s	v1, v1, v1
	and.16b	v4, v16, v1
	and.16b	v6, v17, v2
	ldr	q1, [sp, #1296]
	ldr	q2, [sp, #1280]
	fmul.4s	v2, v2, v2
	fmul.4s	v1, v1, v1
	and.16b	v3, v16, v1
	and.16b	v7, v17, v2
	ldr	q1, [sp, #1264]
	ldr	q2, [sp, #1248]
	fmul.4s	v2, v2, v2
	fmul.4s	v1, v1, v1
	and.16b	v5, v16, v1
	and.16b	v24, v17, v2
	fmov	x15, d25
	add	x15, x4, x15
	ldp	q2, q1, [x15]
	fmul.4s	v2, v2, v2
	fmul.4s	v1, v1, v1
	and.16b	v31, v16, v1
	and.16b	v25, v17, v2
LBB0_38:                                ; %direct.true56.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v1, v17, #0
	sshll.2d	v2, v16, #0
	add	x9, x4, x9, lsl #5
	ldp	q21, q20, [x9]
	and.16b	v21, v17, v21
	and.16b	v20, v16, v20
	fmul.4s	v20, v20, v20
	fmul.4s	v21, v21, v21
	fadd.4s	v21, v25, v21
	fadd.4s	v8, v31, v20
	ldp	q29, q20, [x9, #32]
	and.16b	v29, v17, v29
	and.16b	v20, v16, v20
	fmul.4s	v20, v20, v20
	fmul.4s	v29, v29, v29
	fadd.4s	v29, v24, v29
	fadd.4s	v20, v5, v20
	ldp	q12, q9, [x9, #64]
	and.16b	v12, v17, v12
	and.16b	v9, v16, v9
	fmul.4s	v9, v9, v9
	fmul.4s	v12, v12, v12
	fadd.4s	v12, v7, v12
	fadd.4s	v9, v3, v9
	ldp	q14, q13, [x9, #96]
	and.16b	v14, v17, v14
	and.16b	v13, v16, v13
	fmul.4s	v13, v13, v13
	fmul.4s	v14, v14, v14
	fadd.4s	v14, v6, v14
	fadd.4s	v13, v4, v13
	dup.2d	v15, x28
	and.16b	v19, v27, v15
	add.2d	v0, v0, v19
	and.16b	v19, v26, v15
	add.2d	v22, v22, v19
	and.16b	v2, v2, v15
	add.2d	v23, v23, v2
	and.16b	v1, v1, v15
	add.2d	v28, v28, v1
	bit.16b	v31, v8, v16
	bit.16b	v25, v21, v17
	bit.16b	v5, v20, v16
	bit.16b	v24, v29, v17
	bit.16b	v3, v9, v16
	bit.16b	v7, v12, v17
	bit.16b	v4, v13, v16
	bit.16b	v6, v14, v17
	fmov	x9, d28
	cmp	x9, #8
	b.lt	LBB0_38
; %bb.39:                               ; %direct.false57.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x9, #0                          ; =0x0
	mov	w12, #1                         ; =0x1
	dup.2d	v0, x12
	ushll2.2d	v1, v16, #0
	and.16b	v26, v1, v0
	ushll2.2d	v1, v17, #0
	and.16b	v27, v1, v0
	ushll.2d	v1, v16, #0
	and.16b	v28, v1, v0
	ushll.2d	v1, v17, #0
	and.16b	v29, v1, v0
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v0, #0000000000000000
	movi.2d	v14, #0000000000000000
	b	LBB0_41
LBB0_40:                                ; %else100
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x9, x30, x15
	stp	q1, q20, [x9]
	add.2d	v23, v23, v27
	add.2d	v9, v9, v28
	add.2d	v0, v0, v26
	add.2d	v22, v22, v29
	fmov	x9, d22
	cmp	x9, #8
	b.ge	LBB0_57
LBB0_41:                                ; %direct.true91.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w1, s18
	lsl	x15, x9, #5
	add	x17, x21, x15
	add	x9, x30, x15
	ldp	q1, q20, [x9]
	tbnz	w1, #0, LBB0_49
; %bb.42:                               ; %else79
                                        ;   in Loop: Header=BB0_41 Depth=2
	and	w9, w1, #0xff
	tbnz	w9, #1, LBB0_50
LBB0_43:                                ; %else82
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbnz	w9, #2, LBB0_51
LBB0_44:                                ; %else85
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbnz	w9, #3, LBB0_52
LBB0_45:                                ; %else88
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbnz	w9, #4, LBB0_53
LBB0_46:                                ; %else91
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbnz	w9, #5, LBB0_54
LBB0_47:                                ; %else94
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbnz	w9, #6, LBB0_55
LBB0_48:                                ; %else97
                                        ;   in Loop: Header=BB0_41 Depth=2
	tbz	w9, #7, LBB0_40
	b	LBB0_56
LBB0_49:                                ; %cond.load78
                                        ;   in Loop: Header=BB0_41 Depth=2
	ld1.s	{ v1 }[0], [x17]
	and	w9, w1, #0xff
	tbz	w9, #1, LBB0_43
LBB0_50:                                ; %cond.load81
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x1, x17, #4
	ld1.s	{ v1 }[1], [x1]
	tbz	w9, #2, LBB0_44
LBB0_51:                                ; %cond.load84
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x1, x17, #8
	ld1.s	{ v1 }[2], [x1]
	tbz	w9, #3, LBB0_45
LBB0_52:                                ; %cond.load87
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x1, x17, #12
	ld1.s	{ v1 }[3], [x1]
	tbz	w9, #4, LBB0_46
LBB0_53:                                ; %cond.load90
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x1, x17, #16
	ld1.s	{ v20 }[0], [x1]
	tbz	w9, #5, LBB0_47
LBB0_54:                                ; %cond.load93
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x1, x17, #20
	ld1.s	{ v20 }[1], [x1]
	tbz	w9, #6, LBB0_48
LBB0_55:                                ; %cond.load96
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x1, x17, #24
	ld1.s	{ v20 }[2], [x1]
	tbz	w9, #7, LBB0_40
LBB0_56:                                ; %cond.load99
                                        ;   in Loop: Header=BB0_41 Depth=2
	add	x9, x17, #28
	ld1.s	{ v20 }[3], [x9]
	b	LBB0_40
LBB0_57:                                ; %direct.false92.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q9, [sp, #240]                  ; 16-byte Reload
	zip2.8b	v0, v9, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v10, v0, v10
	zip1.8b	v1, v9, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v11, v1, v11
	fmul.4s	v2, v11, v11
	fmul.4s	v19, v10, v10
	fadd.4s	v19, v19, v31
	fadd.4s	v2, v2, v25
	and.16b	v1, v1, v2
	and.16b	v0, v0, v19
	zip2.8b	v2, v30, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	movi.2d	v19, #0000000000000000
	mov.b	v19[2], v30[1]
	bit.16b	v0, v8, v2
	mov.b	v19[4], v30[2]
	mov.b	v19[6], v30[3]
	ushll.4s	v2, v19, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v1, v21, v2
	fadd.4s	v1, v24, v1
	fadd.4s	v0, v5, v0
	fadd.4s	v0, v3, v0
	fadd.4s	v1, v7, v1
	fadd.4s	v5, v6, v1
	fadd.4s	v4, v4, v0
	ldp	q0, q2, [sp, #48]               ; 32-byte Folded Reload
	ldp	q1, q6, [sp, #16]               ; 32-byte Folded Reload
	uzp1.4s	v3, v2, v6
	uzp1.4s	v6, v1, v0
	movi.4s	v1, #1
	eor.16b	v0, v3, v1
	mov.s	w9, v0[1]
	mov.s	w15, v0[2]
	mov.s	w17, v0[3]
	fmov	w1, s0
	add	x2, sp, #344
	bfxil	x2, x1, #0, #3
	str	d30, [sp, #344]
	ldrb	w2, [x2]
	and	x1, x1, #0x7
	umov.b	w24, v30[0]
	stp	q5, q4, [sp, #608]
	add	x12, sp, #608
	ldr	s0, [x12, x1, lsl #2]
	eor.16b	v1, v6, v1
	ands	w26, w24, #0x1
	tst	w26, w2
	fcsel	s7, s0, s14, ne
	add	x1, sp, #344
	bfxil	x1, x9, #0, #3
	ldrb	w1, [x1]
	and	x9, x9, #0x7
	umov.b	w25, v30[1]
	stp	q5, q4, [sp, #576]
	add	x12, sp, #576
	ldr	s0, [x12, x9, lsl #2]
	ands	w9, w25, #0x1
	tst	w9, w1
	fcsel	s0, s0, s14, ne
	add	x9, sp, #344
	bfxil	x9, x15, #0, #3
	ldrb	w9, [x9]
	and	x15, x15, #0x7
	umov.b	w27, v30[2]
	stp	q5, q4, [sp, #544]
	add	x12, sp, #544
	ldr	s2, [x12, x15, lsl #2]
	ands	w15, w27, #0x1
	tst	w15, w9
	fcsel	s21, s2, s14, ne
	add	x9, sp, #344
	bfxil	x9, x17, #0, #3
	ldrb	w9, [x9]
	and	x17, x17, #0x7
	umov.b	w15, v30[3]
	stp	q5, q4, [sp, #512]
	add	x12, sp, #512
	ldr	s2, [x12, x17, lsl #2]
	ands	w17, w15, #0x1
	tst	w17, w9
	mov.s	w9, v1[1]
	mov.s	w2, v1[2]
	mov.s	w22, v1[3]
	fcsel	s20, s2, s14, ne
	fmov	w17, s1
	and	x1, x17, #0x7
	add	x12, sp, #344
	bfxil	x12, x17, #0, #3
	ldrb	w12, [x12]
	umov.b	w17, v30[4]
	stp	q5, q4, [sp, #736]
	add	x13, sp, #736
	ldr	s1, [x13, x1, lsl #2]
	and	w12, w17, w12
	tst	w12, #0x1
	add	x12, sp, #344
	bfxil	x12, x9, #0, #3
	ldrb	w12, [x12]
	and	x9, x9, #0x7
	umov.b	w1, v30[5]
	stp	q5, q4, [sp, #704]
	add	x13, sp, #704
	ldr	s2, [x13, x9, lsl #2]
	fcsel	s1, s1, s14, ne
	ands	w9, w1, #0x1
	tst	w9, w12
	fcsel	s2, s2, s14, ne
	add	x9, sp, #344
	bfxil	x9, x2, #0, #3
	ldrb	w12, [x9]
	and	x2, x2, #0x7
	umov.b	w9, v30[6]
	stp	q5, q4, [sp, #672]
	add	x13, sp, #672
	ldr	s19, [x13, x2, lsl #2]
	ands	w2, w9, #0x1
	tst	w2, w12
	fcsel	s19, s19, s14, ne
	add	x12, sp, #344
	bfxil	x12, x22, #0, #3
	ldrb	w12, [x12]
	and	x22, x22, #0x7
	umov.b	w2, v30[7]
	stp	q5, q4, [sp, #640]
	add	x13, sp, #640
	ldr	s22, [x13, x22, lsl #2]
	ands	w22, w2, #0x1
	tst	w22, w12
	fcsel	s22, s22, s14, ne
	mov.s	v1[1], v2[0]
	mov.s	v1[2], v19[0]
	mov.s	v1[3], v22[0]
	mov.s	v7[1], v0[0]
	mov.s	v7[2], v21[0]
	mov.s	v7[3], v20[0]
	fadd.4s	v0, v5, v7
	fadd.4s	v1, v4, v1
	movi.4s	v4, #2
	eor.16b	v2, v6, v4
	eor.16b	v3, v3, v4
	fmov	w12, s3
	add	x22, sp, #344
	bfxil	x22, x12, #0, #3
	ldrb	w22, [x22]
	and	x12, x12, #0x7
	stp	q0, q1, [sp, #480]
	add	x13, sp, #480
	ldr	s3, [x13, x12, lsl #2]
	tst	w26, w22
	fcsel	s3, s3, s14, ne
	fmov	w12, s2
	and	x22, x12, #0x7
	add	x13, sp, #344
	bfxil	x13, x12, #0, #3
	ldrb	w12, [x13]
	and	w12, w17, w12
	stp	q0, q1, [sp, #448]
	add	x13, sp, #448
	ldr	s2, [x13, x22, lsl #2]
	tst	w12, #0x1
	fcsel	s2, s2, s14, ne
	fadd.4s	v1, v1, v2
	tst	w26, w17
	fcsel	s1, s1, s14, ne
	ands	w12, w24, #0x1
	fadd.4s	v0, v0, v3
	fadd	s0, s0, s1
	fcsel	s1, s0, s14, ne
	tst	w25, #0x1
	fcsel	s2, s1, s14, ne
	tst	w27, #0x1
	fcsel	s3, s1, s14, ne
	tst	w15, #0x1
	fcsel	s4, s1, s14, ne
	tst	w12, w17
	fcsel	s0, s0, s14, ne
	tst	w1, #0x1
	fcsel	s5, s1, s14, ne
	tst	w9, #0x1
	fcsel	s6, s1, s14, ne
	tst	w2, #0x1
Lloh22:
	adrp	x9, lCPI0_11@PAGE
Lloh23:
	ldr	d7, [x9, lCPI0_11@PAGEOFF]
	shl.8b	v19, v9, #7
	cmlt.8b	v19, v19, #0
	fcsel	s20, s1, s14, ne
	mov.s	v1[1], v2[0]
	mov.s	v1[2], v3[0]
	mov.s	v1[3], v4[0]
	mov.s	v0[1], v5[0]
	and.8b	v2, v19, v7
	mov.s	v0[2], v6[0]
	mov.s	v0[3], v20[0]
	ldr	w9, [sp, #208]                  ; 4-byte Reload
	rbit	w9, w9
	clz	w9, w9
	stp	q1, q0, [sp, #416]
	and	x9, x9, #0x7
	add	x12, sp, #416
	ldr	s6, [x12, x9, lsl #2]
	addv.8b	b3, v2
	mov	b0, v9[0]
	mov.b	v0[4], v9[1]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	ldr	q1, [sp, #128]                  ; 16-byte Reload
	and.16b	v0, v0, v1
	mov	b1, v9[2]
	mov.b	v1[4], v9[3]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldp	q2, q5, [sp, #80]               ; 32-byte Folded Reload
	and.16b	v1, v1, v2
	mov	b2, v9[4]
	mov.b	v2[4], v9[5]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	mov	b4, v9[6]
	mov.b	v4[4], v9[7]
	and.16b	v2, v2, v5
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q5, [sp, #112]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	stp	q2, q4, [sp, #384]
	stp	q0, q1, [sp, #352]
	and	x9, x20, #0x7
	add	x12, sp, #352
	ldr	x9, [x12, x9, lsl #3]
	fmov	w15, s3
	sub	x9, x9, x20
	add	x17, x21, x9, lsl #2
	add	x9, x30, x23
	ldp	q5, q4, [x9]
	tbnz	w15, #0, LBB0_100
; %bb.58:                               ; %else104
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w1, #32                         ; =0x20
	tbnz	w15, #1, LBB0_101
LBB0_59:                                ; %else107
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #2, LBB0_102
LBB0_60:                                ; %else110
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #3, LBB0_103
LBB0_61:                                ; %else113
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #4, LBB0_104
LBB0_62:                                ; %else116
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #5, LBB0_105
LBB0_63:                                ; %else119
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #6, LBB0_106
LBB0_64:                                ; %else122
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w15, #7, LBB0_66
LBB0_65:                                ; %cond.load124
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x17, #28
	ld1.s	{ v4 }[3], [x9]
LBB0_66:                                ; %else125
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x9, #0                          ; =0x0
	fadd	s0, s6, s14
	fmov	s1, w11
	fdiv	s0, s0, s1
	add	x12, x30, x23
	stp	q5, q4, [x12]
	fmov	s1, w14
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v6, v0[0]
	ldr	q0, [sp, #144]                  ; 16-byte Reload
	fmov	x12, d0
	add	x15, x19, x12, lsl #2
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v20, #0000000000000000
	b	LBB0_68
LBB0_67:                                ; %else142
                                        ;   in Loop: Header=BB0_68 Depth=2
	add.2d	v1, v1, v27
	add.2d	v7, v7, v28
	add.2d	v20, v20, v26
	add.2d	v0, v0, v29
	fmov	x9, d0
	cmp	x9, #8
	b.ge	LBB0_84
LBB0_68:                                ; %direct.true117.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w17, s18
	lsl	x9, x9, #5
	add	x12, x4, x9
	ldp	q2, q21, [x12]
	and.16b	v2, v17, v2
	fdiv.4s	v2, v2, v6
	add	x12, x30, x9
	ldp	q19, q22, [x12]
	and.16b	v19, v17, v19
	fmul.4s	v23, v2, v19
	add	x9, x15, x9
	tbnz	w17, #0, LBB0_76
; %bb.69:                               ; %else128
                                        ;   in Loop: Header=BB0_68 Depth=2
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB0_77
LBB0_70:                                ; %else130
                                        ;   in Loop: Header=BB0_68 Depth=2
	tbnz	w17, #2, LBB0_78
LBB0_71:                                ; %else132
                                        ;   in Loop: Header=BB0_68 Depth=2
	tbnz	w17, #3, LBB0_79
LBB0_72:                                ; %else134
                                        ;   in Loop: Header=BB0_68 Depth=2
	and.16b	v2, v16, v21
	fdiv.4s	v2, v2, v6
	and.16b	v19, v16, v22
	fmul.4s	v21, v2, v19
	tbnz	w17, #4, LBB0_80
LBB0_73:                                ; %else136
                                        ;   in Loop: Header=BB0_68 Depth=2
	tbnz	w17, #5, LBB0_81
LBB0_74:                                ; %else138
                                        ;   in Loop: Header=BB0_68 Depth=2
	tbnz	w17, #6, LBB0_82
LBB0_75:                                ; %else140
                                        ;   in Loop: Header=BB0_68 Depth=2
	tbz	w17, #7, LBB0_67
	b	LBB0_83
LBB0_76:                                ; %cond.store
                                        ;   in Loop: Header=BB0_68 Depth=2
	str	s23, [x9]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB0_70
LBB0_77:                                ; %cond.store129
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x12, x9, #4
	st1.s	{ v23 }[1], [x12]
	tbz	w17, #2, LBB0_71
LBB0_78:                                ; %cond.store131
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x12, x9, #8
	st1.s	{ v23 }[2], [x12]
	tbz	w17, #3, LBB0_72
LBB0_79:                                ; %cond.store133
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x12, x9, #12
	st1.s	{ v23 }[3], [x12]
	and.16b	v2, v16, v21
	fdiv.4s	v2, v2, v6
	and.16b	v19, v16, v22
	fmul.4s	v21, v2, v19
	tbz	w17, #4, LBB0_73
LBB0_80:                                ; %cond.store135
                                        ;   in Loop: Header=BB0_68 Depth=2
	str	s21, [x9, #16]
	tbz	w17, #5, LBB0_74
LBB0_81:                                ; %cond.store137
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x12, x9, #20
	st1.s	{ v21 }[1], [x12]
	tbz	w17, #6, LBB0_75
LBB0_82:                                ; %cond.store139
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x12, x9, #24
	st1.s	{ v21 }[2], [x12]
	tbz	w17, #7, LBB0_67
LBB0_83:                                ; %cond.store141
                                        ;   in Loop: Header=BB0_68 Depth=2
	add	x9, x9, #28
	st1.s	{ v21 }[3], [x9]
	b	LBB0_67
LBB0_84:                                ; %direct.false118.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	fdiv.4s	v0, v11, v6
	fmov	w9, s3
	zip1.8b	v1, v9, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v1, v1, v5
	fmul.4s	v0, v0, v1
	ldr	q2, [sp, #224]                  ; 16-byte Reload
	ldp	q7, q5, [sp, #160]              ; 32-byte Folded Reload
	stp	q2, q5, [sp, #272]
	ldr	q1, [sp, #192]                  ; 16-byte Reload
	stp	q7, q1, [sp, #304]
	and	x12, x20, #0x7
	add	x13, sp, #272
	ldr	x12, [x13, x12, lsl #3]
	sub	x12, x12, x20
	add	x15, x19, x12, lsl #2
	tbnz	w9, #0, LBB0_107
; %bb.85:                               ; %else145
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #1, LBB0_108
LBB0_86:                                ; %else147
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #2, LBB0_109
LBB0_87:                                ; %else149
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w9, #3, LBB0_89
LBB0_88:                                ; %cond.store150
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x12, x15, #12
	st1.s	{ v0 }[3], [x12]
LBB0_89:                                ; %else151
                                        ;   in Loop: Header=BB0_4 Depth=1
	fdiv.4s	v0, v10, v6
	zip2.8b	v1, v9, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v1, v1, v4
	fmul.4s	v0, v0, v1
	tbnz	w9, #4, LBB0_110
; %bb.90:                               ; %else153
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #5, LBB0_111
LBB0_91:                                ; %else155
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #6, LBB0_112
LBB0_92:                                ; %else157
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w9, #7, LBB0_3
	b	LBB0_113
LBB0_93:                                ; %cond.load53
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v11 }[0], [x24]
	tbz	w15, #1, LBB0_30
LBB0_94:                                ; %cond.load56
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x24, #4
	ld1.s	{ v11 }[1], [x9]
	tbz	w15, #2, LBB0_31
LBB0_95:                                ; %cond.load59
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x24, #8
	ld1.s	{ v11 }[2], [x9]
	tbz	w15, #3, LBB0_32
LBB0_96:                                ; %cond.load62
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x24, #12
	ld1.s	{ v11 }[3], [x9]
	tbz	w15, #4, LBB0_33
LBB0_97:                                ; %cond.load65
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x24, #16
	ld1.s	{ v10 }[0], [x9]
	tbz	w15, #5, LBB0_34
LBB0_98:                                ; %cond.load68
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x24, #20
	ld1.s	{ v10 }[1], [x9]
	tbz	w15, #6, LBB0_35
LBB0_99:                                ; %cond.load71
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x24, #24
	ld1.s	{ v10 }[2], [x9]
	tbnz	w15, #7, LBB0_36
	b	LBB0_37
LBB0_100:                               ; %cond.load103
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v5 }[0], [x17]
	mov	w1, #32                         ; =0x20
	tbz	w15, #1, LBB0_59
LBB0_101:                               ; %cond.load106
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x17, #4
	ld1.s	{ v5 }[1], [x9]
	tbz	w15, #2, LBB0_60
LBB0_102:                               ; %cond.load109
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x17, #8
	ld1.s	{ v5 }[2], [x9]
	tbz	w15, #3, LBB0_61
LBB0_103:                               ; %cond.load112
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x17, #12
	ld1.s	{ v5 }[3], [x9]
	tbz	w15, #4, LBB0_62
LBB0_104:                               ; %cond.load115
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x17, #16
	ld1.s	{ v4 }[0], [x9]
	tbz	w15, #5, LBB0_63
LBB0_105:                               ; %cond.load118
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x17, #20
	ld1.s	{ v4 }[1], [x9]
	tbz	w15, #6, LBB0_64
LBB0_106:                               ; %cond.load121
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x17, #24
	ld1.s	{ v4 }[2], [x9]
	tbnz	w15, #7, LBB0_65
	b	LBB0_66
LBB0_107:                               ; %cond.store144
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x15]
	tbz	w9, #1, LBB0_86
LBB0_108:                               ; %cond.store146
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x12, x15, #4
	st1.s	{ v0 }[1], [x12]
	tbz	w9, #2, LBB0_87
LBB0_109:                               ; %cond.store148
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x12, x15, #8
	st1.s	{ v0 }[2], [x12]
	tbnz	w9, #3, LBB0_88
	b	LBB0_89
LBB0_110:                               ; %cond.store152
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x15, #16]
	tbz	w9, #5, LBB0_91
LBB0_111:                               ; %cond.store154
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x12, x15, #20
	st1.s	{ v0 }[1], [x12]
	tbz	w9, #6, LBB0_92
LBB0_112:                               ; %cond.store156
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x12, x15, #24
	st1.s	{ v0 }[2], [x12]
	tbz	w9, #7, LBB0_3
LBB0_113:                               ; %cond.store158
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x15, #28
	st1.s	{ v0 }[3], [x9]
	b	LBB0_3
LBB0_114:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Reload
	stp	w7, w6, [x9]
	str	w16, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
	add	sp, sp, #1504
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_115:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh22, Lloh23
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2240
	str	x0, [sp, #96]                   ; 8-byte Spill
	str	w3, [sp, #92]                   ; 4-byte Spill
	cbz	w3, LBB0_138
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w6, #0                          ; =0x0
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #84]               ; 8-byte Folded Spill
	ldp	w8, w9, [x2]
	add	x27, sp, #1, lsl #12            ; =4096
	add	x27, x27, #704
	add	x28, sp, #3264
	add	x19, sp, #1728
	add	x26, sp, #192
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x10, lCPI0_0@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Spill
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q0, [x10, lCPI0_1@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Spill
Lloh4:
	adrp	x10, lCPI0_2@PAGE
Lloh5:
	ldr	q0, [x10, lCPI0_2@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
	ldp	w10, w11, [x2, #8]
	str	x2, [sp, #8]                    ; 8-byte Spill
	str	x11, [sp, #72]                  ; 8-byte Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w8, w5, #1
	ldp	w11, w9, [sp, #84]              ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w9, eq
	csinc	w8, wzr, w5, eq
	cinc	w10, w4, eq
	cmp	w10, w11
	cset	w11, eq
	ands	w11, w9, w11
	csel	w9, wzr, w10, ne
	add	w10, w3, w11
	add	w6, w6, #1
	ldr	w11, [sp, #92]                  ; 4-byte Reload
	cmp	w6, w11
	b.eq	LBB0_137
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_22 Depth 2
                                        ;       Child Loop BB0_23 Depth 3
                                        ;       Child Loop BB0_25 Depth 3
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_49 Depth 2
                                        ;     Child Loop BB0_67 Depth 2
                                        ;     Child Loop BB0_85 Depth 2
                                        ;     Child Loop BB0_103 Depth 2
                                        ;     Child Loop BB0_121 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
	stp	w9, w10, [sp, #108]             ; 8-byte Folded Spill
	mov	x13, x8
	ubfiz	x8, x8, #5, #32
	ldr	x12, [sp, #72]                  ; 8-byte Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	ccmp	x8, x12, #2, hi
	csel	x8, x10, xzr, ls
	cmp	x8, #32
	str	w6, [sp, #116]                  ; 4-byte Spill
	str	x13, [sp, #120]                 ; 8-byte Spill
	b.lo	LBB0_20
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #96]                   ; 8-byte Reload
	ldr	x9, [x8]
	ldr	x21, [x8, #16]
	ldr	x23, [x8, #32]
	ldr	x22, [x8, #48]
	ubfiz	w8, w13, #2, #27
	stp	x9, x8, [sp, #152]              ; 16-byte Folded Spill
	add	x24, x8, w8, uxtw #1
	lsl	x25, x24, #10
	add	x20, x9, x25
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #704
	add	x1, x9, x25
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #3264
	add	x1, x20, #1536
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	lsl	x20, x24, #9
	add	x0, sp, #1728
	str	x21, [sp, #168]                 ; 8-byte Spill
	add	x1, x21, x20
	mov	x21, x22
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #192
	str	x23, [sp, #176]                 ; 8-byte Spill
	add	x1, x23, x20
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	mov	x11, x25
	add	x9, x22, x25
LBB0_5:                                 ; %direct.true89.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q0, q1, [x10]
	add	x10, x19, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x28, x8
	ldp	q2, q3, [x10]
	add	x10, x26, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fsub.4s	v0, v0, v2
	fsub.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_5
; %bb.6:                                ; %direct.true122.i.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x25, x11
	add	x9, x21, x11
	add	x9, x9, #1536
LBB0_7:                                 ; %direct.true122.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q0, q1, [x10]
	add	x10, x26, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x28, x8
	ldp	q2, q3, [x10]
	add	x10, x19, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_7
; %bb.8:                                ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	x22, x8, [sp, #152]             ; 16-byte Folded Reload
	orr	w8, w8, #0x1
	add	x20, x8, w8, uxtw #1
	lsl	x24, x20, #10
	add	x23, x22, x24
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #704
	add	x1, x22, x24
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #3264
	add	x1, x23, #1536
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	lsl	x20, x20, #9
	add	x0, sp, #1728
	ldr	x8, [sp, #168]                  ; 8-byte Reload
	add	x1, x8, x20
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #192
	ldr	x8, [sp, #176]                  ; 8-byte Reload
	add	x1, x8, x20
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	add	x9, x21, x24
LBB0_9:                                 ; %direct.true89.i14.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q0, q1, [x10]
	add	x10, x19, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x28, x8
	ldp	q2, q3, [x10]
	add	x10, x26, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fsub.4s	v0, v0, v2
	fsub.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_9
; %bb.10:                               ; %direct.true122.i28.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x21, x25
	mov	w10, #4608                      ; =0x1200
	add	x9, x9, x10
LBB0_11:                                ; %direct.true122.i28.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q0, q1, [x10]
	add	x10, x26, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x28, x8
	ldp	q2, q3, [x10]
	add	x10, x19, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_11
; %bb.12:                               ; %llm_rows.full_packet.exit41.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #160]                  ; 8-byte Reload
	orr	w8, w8, #0x2
	add	x20, x8, w8, uxtw #1
	lsl	x23, x20, #10
	add	x24, x22, x23
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #704
	add	x1, x22, x23
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #3264
	add	x1, x24, #1536
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	lsl	x20, x20, #9
	add	x0, sp, #1728
	ldr	x8, [sp, #168]                  ; 8-byte Reload
	add	x1, x8, x20
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #192
	ldr	x8, [sp, #176]                  ; 8-byte Reload
	add	x1, x8, x20
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	add	x9, x21, x23
LBB0_13:                                ; %direct.true89.i53.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q0, q1, [x10]
	add	x10, x19, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x28, x8
	ldp	q2, q3, [x10]
	add	x10, x26, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fsub.4s	v0, v0, v2
	fsub.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_13
; %bb.14:                               ; %direct.true122.i67.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x21, x25
	mov	w10, #7680                      ; =0x1e00
	add	x9, x9, x10
LBB0_15:                                ; %direct.true122.i67.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q0, q1, [x10]
	add	x10, x26, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x28, x8
	ldp	q2, q3, [x10]
	add	x10, x19, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_15
; %bb.16:                               ; %llm_rows.full_packet.exit80.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #160]                  ; 8-byte Reload
	orr	w8, w8, #0x3
	add	x20, x8, w8, uxtw #1
	lsl	x23, x20, #10
	add	x22, x22, x23
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #704
	mov	x1, x22
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #3264
	add	x1, x22, #1536
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	lsl	x20, x20, #9
	add	x0, sp, #1728
	ldr	x8, [sp, #168]                  ; 8-byte Reload
	add	x1, x8, x20
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #192
	ldr	x8, [sp, #176]                  ; 8-byte Reload
	add	x1, x8, x20
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	add	x9, x21, x23
LBB0_17:                                ; %direct.true89.i92.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q0, q1, [x10]
	add	x10, x19, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x28, x8
	ldp	q2, q3, [x10]
	add	x10, x26, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fsub.4s	v0, v0, v2
	fsub.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_17
; %bb.18:                               ; %direct.true122.i106.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x21, x25
	mov	w10, #10752                     ; =0x2a00
	add	x9, x9, x10
	ldp	w3, w6, [sp, #112]              ; 8-byte Folded Reload
	ldr	w4, [sp, #108]                  ; 4-byte Reload
	ldr	x5, [sp, #120]                  ; 8-byte Reload
LBB0_19:                                ; %direct.true122.i106.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q0, q1, [x10]
	add	x10, x26, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x28, x8
	ldp	q2, q3, [x10]
	add	x10, x19, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_19
	b	LBB0_2
LBB0_20:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	str	x8, [sp, #64]                   ; 8-byte Spill
	lsr	x8, x8, #3
	str	x8, [sp, #176]                  ; 8-byte Spill
	cbz	x8, LBB0_27
; %bb.21:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w23, #0                         ; =0x0
	ldr	x8, [sp, #96]                   ; 8-byte Reload
	ldr	x10, [x8]
	ldr	x9, [x8, #16]
	stp	x9, x10, [sp, #160]             ; 16-byte Folded Spill
	ldr	x10, [x8, #32]
	ldr	x9, [x8, #48]
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	lsl	w8, w8, #2
	stp	x9, x10, [sp, #144]             ; 16-byte Folded Spill
	add	x9, x9, #1536
	str	x9, [sp, #128]                  ; 8-byte Spill
	str	w8, [sp, #140]                  ; 4-byte Spill
	mov	x25, x8
LBB0_22:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_23 Depth 3
                                        ;       Child Loop BB0_25 Depth 3
	and	x8, x25, #0x1fffffff
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #10
	ldr	x9, [sp, #128]                  ; 8-byte Reload
	add	x21, x9, x8
	ldr	x9, [sp, #144]                  ; 8-byte Reload
	add	x20, x9, x8
	ldr	w8, [sp, #140]                  ; 4-byte Reload
	add	w8, w23, w8
	and	w24, w8, #0x1fffffff
	mov	w8, #3072                       ; =0xc00
	ldr	x9, [sp, #168]                  ; 8-byte Reload
	umaddl	x22, w24, w8, x9
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #704
	mov	x1, x22
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #3264
	add	x1, x22, #1536
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x8, x24, w24, uxtw #1
	lsl	x22, x8, #9
	add	x0, sp, #1728
	ldr	x8, [sp, #160]                  ; 8-byte Reload
	add	x1, x8, x22
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x0, sp, #192
	ldr	x8, [sp, #152]                  ; 8-byte Reload
	add	x1, x8, x22
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	mov	x8, #0                          ; =0x0
LBB0_23:                                ; %direct.true89.i131.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_22 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x27, x8
	ldp	q0, q1, [x9]
	add	x9, x19, x8
	ldp	q2, q3, [x9]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x9, x28, x8
	ldp	q2, q3, [x9]
	add	x9, x26, x8
	ldp	q4, q5, [x9]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fsub.4s	v0, v0, v2
	fsub.4s	v1, v1, v3
	add	x9, x20, x8
	stp	q0, q1, [x9]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_23
; %bb.24:                               ; %direct.true122.i145.i.preheader
                                        ;   in Loop: Header=BB0_22 Depth=2
	mov	x8, #0                          ; =0x0
LBB0_25:                                ; %direct.true122.i145.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_22 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x27, x8
	ldp	q0, q1, [x9]
	add	x9, x26, x8
	ldp	q2, q3, [x9]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x9, x28, x8
	ldp	q2, q3, [x9]
	add	x9, x19, x8
	ldp	q4, q5, [x9]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x9, x21, x8
	stp	q0, q1, [x9]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_25
; %bb.26:                               ; %llm_rows.full_packet.exit158.i
                                        ;   in Loop: Header=BB0_22 Depth=2
	add	w23, w23, #1
	add	w25, w25, #1
	ldr	x8, [sp, #176]                  ; 8-byte Reload
	cmp	w23, w8
	b.ne	LBB0_22
LBB0_27:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #64]                   ; 8-byte Reload
	and	w8, w8, #0x7
	ldp	w3, w6, [sp, #112]              ; 8-byte Folded Reload
	ldr	w4, [sp, #108]                  ; 4-byte Reload
	ldr	x5, [sp, #120]                  ; 8-byte Reload
	cbz	w8, LBB0_2
; %bb.28:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v1, w8
	ldp	q0, q2, [sp, #32]               ; 32-byte Folded Reload
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v2, v1, v0
	umaxv.8h	h3, v2
	fmov	w8, s3
	tbz	w8, #0, LBB0_2
; %bb.29:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	ldr	x9, [sp, #96]                   ; 8-byte Reload
	ldr	x11, [x9, #16]
	ldr	x10, [x9, #32]
	ldr	x8, [x9, #48]
	ldr	x14, [x9]
	ubfiz	w9, w5, #2, #27
	ldr	x12, [sp, #176]                 ; 8-byte Reload
	orr	w9, w9, w12
	fmov	s3, w9
	and.16b	v3, v1, v3
	fmov	w12, s3
	add	x9, x12, w12, uxtw #1
	lsl	x9, x9, #10
	add	x15, x14, x9
	ldr	q3, [sp, #16]                   ; 16-byte Reload
	and.16b	v2, v2, v3
	addv.8h	h2, v2
	fmov	w16, s2
	b	LBB0_31
LBB0_30:                                ; %else134
                                        ;   in Loop: Header=BB0_31 Depth=2
	add	x17, x27, x13
	stp	q3, q4, [x17]
	add	x13, x13, #32
	cmp	x13, #1536
	b.eq	LBB0_47
LBB0_31:                                ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x17, x15, x13
	add	x1, x27, x13
	ldr	q3, [x1]
	tbnz	w16, #0, LBB0_39
; %bb.32:                               ; %else
                                        ;   in Loop: Header=BB0_31 Depth=2
	and	w0, w16, #0xff
	tbnz	w0, #1, LBB0_40
LBB0_33:                                ; %else116
                                        ;   in Loop: Header=BB0_31 Depth=2
	tbnz	w0, #2, LBB0_41
LBB0_34:                                ; %else119
                                        ;   in Loop: Header=BB0_31 Depth=2
	tbnz	w0, #3, LBB0_42
LBB0_35:                                ; %else122
                                        ;   in Loop: Header=BB0_31 Depth=2
	ldr	q4, [x1, #16]
	tbnz	w0, #4, LBB0_43
LBB0_36:                                ; %else125
                                        ;   in Loop: Header=BB0_31 Depth=2
	tbnz	w0, #5, LBB0_44
LBB0_37:                                ; %else128
                                        ;   in Loop: Header=BB0_31 Depth=2
	tbnz	w0, #6, LBB0_45
LBB0_38:                                ; %else131
                                        ;   in Loop: Header=BB0_31 Depth=2
	tbz	w0, #7, LBB0_30
	b	LBB0_46
LBB0_39:                                ; %cond.load
                                        ;   in Loop: Header=BB0_31 Depth=2
	ld1.s	{ v3 }[0], [x17]
	and	w0, w16, #0xff
	tbz	w0, #1, LBB0_33
LBB0_40:                                ; %cond.load115
                                        ;   in Loop: Header=BB0_31 Depth=2
	add	x2, x17, #4
	ld1.s	{ v3 }[1], [x2]
	tbz	w0, #2, LBB0_34
LBB0_41:                                ; %cond.load118
                                        ;   in Loop: Header=BB0_31 Depth=2
	add	x2, x17, #8
	ld1.s	{ v3 }[2], [x2]
	tbz	w0, #3, LBB0_35
LBB0_42:                                ; %cond.load121
                                        ;   in Loop: Header=BB0_31 Depth=2
	add	x2, x17, #12
	ld1.s	{ v3 }[3], [x2]
	ldr	q4, [x1, #16]
	tbz	w0, #4, LBB0_36
LBB0_43:                                ; %cond.load124
                                        ;   in Loop: Header=BB0_31 Depth=2
	add	x1, x17, #16
	ld1.s	{ v4 }[0], [x1]
	tbz	w0, #5, LBB0_37
LBB0_44:                                ; %cond.load127
                                        ;   in Loop: Header=BB0_31 Depth=2
	add	x1, x17, #20
	ld1.s	{ v4 }[1], [x1]
	tbz	w0, #6, LBB0_38
LBB0_45:                                ; %cond.load130
                                        ;   in Loop: Header=BB0_31 Depth=2
	add	x1, x17, #24
	ld1.s	{ v4 }[2], [x1]
	tbz	w0, #7, LBB0_30
LBB0_46:                                ; %cond.load133
                                        ;   in Loop: Header=BB0_31 Depth=2
	add	x17, x17, #28
	ld1.s	{ v4 }[3], [x17]
	b	LBB0_30
LBB0_47:                                ; %direct.true38.i.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	add	x14, x14, x9
	add	x14, x14, #1536
	fmov	w15, s2
	b	LBB0_49
LBB0_48:                                ; %else159
                                        ;   in Loop: Header=BB0_49 Depth=2
	add	x16, x28, x13
	stp	q3, q4, [x16]
	add	x13, x13, #32
	cmp	x13, #1536
	b.eq	LBB0_65
LBB0_49:                                ; %direct.true38.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x14, x13
	add	x0, x28, x13
	ldr	q3, [x0]
	tbnz	w15, #0, LBB0_57
; %bb.50:                               ; %else138
                                        ;   in Loop: Header=BB0_49 Depth=2
	and	w17, w15, #0xff
	ldr	q4, [x0, #16]
	tbnz	w17, #1, LBB0_58
LBB0_51:                                ; %else141
                                        ;   in Loop: Header=BB0_49 Depth=2
	tbnz	w17, #2, LBB0_59
LBB0_52:                                ; %else144
                                        ;   in Loop: Header=BB0_49 Depth=2
	tbnz	w17, #3, LBB0_60
LBB0_53:                                ; %else147
                                        ;   in Loop: Header=BB0_49 Depth=2
	tbnz	w17, #4, LBB0_61
LBB0_54:                                ; %else150
                                        ;   in Loop: Header=BB0_49 Depth=2
	tbnz	w17, #5, LBB0_62
LBB0_55:                                ; %else153
                                        ;   in Loop: Header=BB0_49 Depth=2
	tbnz	w17, #6, LBB0_63
LBB0_56:                                ; %else156
                                        ;   in Loop: Header=BB0_49 Depth=2
	tbz	w17, #7, LBB0_48
	b	LBB0_64
LBB0_57:                                ; %cond.load137
                                        ;   in Loop: Header=BB0_49 Depth=2
	ld1.s	{ v3 }[0], [x16]
	and	w17, w15, #0xff
	ldr	q4, [x0, #16]
	tbz	w17, #1, LBB0_51
LBB0_58:                                ; %cond.load140
                                        ;   in Loop: Header=BB0_49 Depth=2
	add	x0, x16, #4
	ld1.s	{ v3 }[1], [x0]
	tbz	w17, #2, LBB0_52
LBB0_59:                                ; %cond.load143
                                        ;   in Loop: Header=BB0_49 Depth=2
	add	x0, x16, #8
	ld1.s	{ v3 }[2], [x0]
	tbz	w17, #3, LBB0_53
LBB0_60:                                ; %cond.load146
                                        ;   in Loop: Header=BB0_49 Depth=2
	add	x0, x16, #12
	ld1.s	{ v3 }[3], [x0]
	tbz	w17, #4, LBB0_54
LBB0_61:                                ; %cond.load149
                                        ;   in Loop: Header=BB0_49 Depth=2
	add	x0, x16, #16
	ld1.s	{ v4 }[0], [x0]
	tbz	w17, #5, LBB0_55
LBB0_62:                                ; %cond.load152
                                        ;   in Loop: Header=BB0_49 Depth=2
	add	x0, x16, #20
	ld1.s	{ v4 }[1], [x0]
	tbz	w17, #6, LBB0_56
LBB0_63:                                ; %cond.load155
                                        ;   in Loop: Header=BB0_49 Depth=2
	add	x0, x16, #24
	ld1.s	{ v4 }[2], [x0]
	tbz	w17, #7, LBB0_48
LBB0_64:                                ; %cond.load158
                                        ;   in Loop: Header=BB0_49 Depth=2
	add	x16, x16, #28
	ld1.s	{ v4 }[3], [x16]
	b	LBB0_48
LBB0_65:                                ; %direct.schedule.7.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x13, #0                         ; =0x0
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #9
	add	x11, x11, x12
	b	LBB0_67
LBB0_66:                                ; %else184
                                        ;   in Loop: Header=BB0_67 Depth=2
	add	x14, x19, x13
	stp	q3, q4, [x14]
	add	x13, x13, #32
	cmp	x13, #1536
	b.eq	LBB0_83
LBB0_67:                                ; %direct.true55.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w15, s2
	add	x14, x11, x13
	add	x16, x19, x13
	ldp	q3, q4, [x16]
	tbnz	w15, #0, LBB0_75
; %bb.68:                               ; %else163
                                        ;   in Loop: Header=BB0_67 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB0_76
LBB0_69:                                ; %else166
                                        ;   in Loop: Header=BB0_67 Depth=2
	tbnz	w15, #2, LBB0_77
LBB0_70:                                ; %else169
                                        ;   in Loop: Header=BB0_67 Depth=2
	tbnz	w15, #3, LBB0_78
LBB0_71:                                ; %else172
                                        ;   in Loop: Header=BB0_67 Depth=2
	tbnz	w15, #4, LBB0_79
LBB0_72:                                ; %else175
                                        ;   in Loop: Header=BB0_67 Depth=2
	tbnz	w15, #5, LBB0_80
LBB0_73:                                ; %else178
                                        ;   in Loop: Header=BB0_67 Depth=2
	tbnz	w15, #6, LBB0_81
LBB0_74:                                ; %else181
                                        ;   in Loop: Header=BB0_67 Depth=2
	tbz	w15, #7, LBB0_66
	b	LBB0_82
LBB0_75:                                ; %cond.load162
                                        ;   in Loop: Header=BB0_67 Depth=2
	ld1.s	{ v3 }[0], [x14]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB0_69
LBB0_76:                                ; %cond.load165
                                        ;   in Loop: Header=BB0_67 Depth=2
	add	x16, x14, #4
	ld1.s	{ v3 }[1], [x16]
	tbz	w15, #2, LBB0_70
LBB0_77:                                ; %cond.load168
                                        ;   in Loop: Header=BB0_67 Depth=2
	add	x16, x14, #8
	ld1.s	{ v3 }[2], [x16]
	tbz	w15, #3, LBB0_71
LBB0_78:                                ; %cond.load171
                                        ;   in Loop: Header=BB0_67 Depth=2
	add	x16, x14, #12
	ld1.s	{ v3 }[3], [x16]
	tbz	w15, #4, LBB0_72
LBB0_79:                                ; %cond.load174
                                        ;   in Loop: Header=BB0_67 Depth=2
	add	x16, x14, #16
	ld1.s	{ v4 }[0], [x16]
	tbz	w15, #5, LBB0_73
LBB0_80:                                ; %cond.load177
                                        ;   in Loop: Header=BB0_67 Depth=2
	add	x16, x14, #20
	ld1.s	{ v4 }[1], [x16]
	tbz	w15, #6, LBB0_74
LBB0_81:                                ; %cond.load180
                                        ;   in Loop: Header=BB0_67 Depth=2
	add	x16, x14, #24
	ld1.s	{ v4 }[2], [x16]
	tbz	w15, #7, LBB0_66
LBB0_82:                                ; %cond.load183
                                        ;   in Loop: Header=BB0_67 Depth=2
	add	x14, x14, #28
	ld1.s	{ v4 }[3], [x14]
	b	LBB0_66
LBB0_83:                                ; %direct.schedule.10.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	add	x10, x10, x12
	b	LBB0_85
LBB0_84:                                ; %else209
                                        ;   in Loop: Header=BB0_85 Depth=2
	add	x12, x26, x11
	stp	q3, q4, [x12]
	add	x11, x11, #32
	cmp	x11, #1536
	b.eq	LBB0_101
LBB0_85:                                ; %direct.true72.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s2
	add	x12, x10, x11
	add	x14, x26, x11
	ldp	q3, q4, [x14]
	tbnz	w13, #0, LBB0_93
; %bb.86:                               ; %else188
                                        ;   in Loop: Header=BB0_85 Depth=2
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_94
LBB0_87:                                ; %else191
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbnz	w13, #2, LBB0_95
LBB0_88:                                ; %else194
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbnz	w13, #3, LBB0_96
LBB0_89:                                ; %else197
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbnz	w13, #4, LBB0_97
LBB0_90:                                ; %else200
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbnz	w13, #5, LBB0_98
LBB0_91:                                ; %else203
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbnz	w13, #6, LBB0_99
LBB0_92:                                ; %else206
                                        ;   in Loop: Header=BB0_85 Depth=2
	tbz	w13, #7, LBB0_84
	b	LBB0_100
LBB0_93:                                ; %cond.load187
                                        ;   in Loop: Header=BB0_85 Depth=2
	ld1.s	{ v3 }[0], [x12]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_87
LBB0_94:                                ; %cond.load190
                                        ;   in Loop: Header=BB0_85 Depth=2
	add	x14, x12, #4
	ld1.s	{ v3 }[1], [x14]
	tbz	w13, #2, LBB0_88
LBB0_95:                                ; %cond.load193
                                        ;   in Loop: Header=BB0_85 Depth=2
	add	x14, x12, #8
	ld1.s	{ v3 }[2], [x14]
	tbz	w13, #3, LBB0_89
LBB0_96:                                ; %cond.load196
                                        ;   in Loop: Header=BB0_85 Depth=2
	add	x14, x12, #12
	ld1.s	{ v3 }[3], [x14]
	tbz	w13, #4, LBB0_90
LBB0_97:                                ; %cond.load199
                                        ;   in Loop: Header=BB0_85 Depth=2
	add	x14, x12, #16
	ld1.s	{ v4 }[0], [x14]
	tbz	w13, #5, LBB0_91
LBB0_98:                                ; %cond.load202
                                        ;   in Loop: Header=BB0_85 Depth=2
	add	x14, x12, #20
	ld1.s	{ v4 }[1], [x14]
	tbz	w13, #6, LBB0_92
LBB0_99:                                ; %cond.load205
                                        ;   in Loop: Header=BB0_85 Depth=2
	add	x14, x12, #24
	ld1.s	{ v4 }[2], [x14]
	tbz	w13, #7, LBB0_84
LBB0_100:                               ; %cond.load208
                                        ;   in Loop: Header=BB0_85 Depth=2
	add	x12, x12, #28
	ld1.s	{ v4 }[3], [x12]
	b	LBB0_84
LBB0_101:                               ; %direct.schedule.13.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x10, #0                         ; =0x0
	add	x11, x8, x9
	b	LBB0_103
LBB0_102:                               ; %else226
                                        ;   in Loop: Header=BB0_103 Depth=2
	add	x10, x10, #32
	cmp	x10, #1536
	b.eq	LBB0_119
LBB0_103:                               ; %direct.true89.i169.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s2
	add	x12, x27, x10
	ldp	q5, q3, [x12]
	add	x12, x19, x10
	ldp	q6, q4, [x12]
	fmul.4s	v7, v5, v6
	add	x12, x28, x10
	ldp	q16, q5, [x12]
	add	x12, x26, x10
	ldp	q17, q6, [x12]
	fmul.4s	v16, v16, v17
	fsub.4s	v7, v7, v16
	and.16b	v7, v1, v7
	add	x12, x11, x10
	tbnz	w13, #0, LBB0_111
; %bb.104:                              ; %else212
                                        ;   in Loop: Header=BB0_103 Depth=2
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_112
LBB0_105:                               ; %else214
                                        ;   in Loop: Header=BB0_103 Depth=2
	tbnz	w13, #2, LBB0_113
LBB0_106:                               ; %else216
                                        ;   in Loop: Header=BB0_103 Depth=2
	tbnz	w13, #3, LBB0_114
LBB0_107:                               ; %else218
                                        ;   in Loop: Header=BB0_103 Depth=2
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fsub.4s	v3, v3, v4
	and.16b	v3, v0, v3
	tbnz	w13, #4, LBB0_115
LBB0_108:                               ; %else220
                                        ;   in Loop: Header=BB0_103 Depth=2
	tbnz	w13, #5, LBB0_116
LBB0_109:                               ; %else222
                                        ;   in Loop: Header=BB0_103 Depth=2
	tbnz	w13, #6, LBB0_117
LBB0_110:                               ; %else224
                                        ;   in Loop: Header=BB0_103 Depth=2
	tbz	w13, #7, LBB0_102
	b	LBB0_118
LBB0_111:                               ; %cond.store
                                        ;   in Loop: Header=BB0_103 Depth=2
	str	s7, [x12]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_105
LBB0_112:                               ; %cond.store213
                                        ;   in Loop: Header=BB0_103 Depth=2
	add	x14, x12, #4
	st1.s	{ v7 }[1], [x14]
	tbz	w13, #2, LBB0_106
LBB0_113:                               ; %cond.store215
                                        ;   in Loop: Header=BB0_103 Depth=2
	add	x14, x12, #8
	st1.s	{ v7 }[2], [x14]
	tbz	w13, #3, LBB0_107
LBB0_114:                               ; %cond.store217
                                        ;   in Loop: Header=BB0_103 Depth=2
	add	x14, x12, #12
	st1.s	{ v7 }[3], [x14]
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fsub.4s	v3, v3, v4
	and.16b	v3, v0, v3
	tbz	w13, #4, LBB0_108
LBB0_115:                               ; %cond.store219
                                        ;   in Loop: Header=BB0_103 Depth=2
	str	s3, [x12, #16]
	tbz	w13, #5, LBB0_109
LBB0_116:                               ; %cond.store221
                                        ;   in Loop: Header=BB0_103 Depth=2
	add	x14, x12, #20
	st1.s	{ v3 }[1], [x14]
	tbz	w13, #6, LBB0_110
LBB0_117:                               ; %cond.store223
                                        ;   in Loop: Header=BB0_103 Depth=2
	add	x14, x12, #24
	st1.s	{ v3 }[2], [x14]
	tbz	w13, #7, LBB0_102
LBB0_118:                               ; %cond.store225
                                        ;   in Loop: Header=BB0_103 Depth=2
	add	x12, x12, #28
	st1.s	{ v3 }[3], [x12]
	b	LBB0_102
LBB0_119:                               ; %direct.true122.i180.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x10, #0                         ; =0x0
	add	x8, x8, x9
	add	x8, x8, #1536
	b	LBB0_121
LBB0_120:                               ; %else243
                                        ;   in Loop: Header=BB0_121 Depth=2
	add	x10, x10, #32
	cmp	x10, #1536
	b.eq	LBB0_2
LBB0_121:                               ; %direct.true122.i180.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s2
	add	x9, x27, x10
	ldp	q5, q3, [x9]
	add	x9, x26, x10
	ldp	q6, q4, [x9]
	fmul.4s	v7, v5, v6
	add	x9, x28, x10
	ldp	q16, q5, [x9]
	add	x9, x19, x10
	ldp	q17, q6, [x9]
	fmul.4s	v16, v16, v17
	fadd.4s	v7, v7, v16
	and.16b	v7, v1, v7
	add	x9, x8, x10
	tbnz	w11, #0, LBB0_129
; %bb.122:                              ; %else229
                                        ;   in Loop: Header=BB0_121 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_130
LBB0_123:                               ; %else231
                                        ;   in Loop: Header=BB0_121 Depth=2
	tbnz	w11, #2, LBB0_131
LBB0_124:                               ; %else233
                                        ;   in Loop: Header=BB0_121 Depth=2
	tbnz	w11, #3, LBB0_132
LBB0_125:                               ; %else235
                                        ;   in Loop: Header=BB0_121 Depth=2
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fadd.4s	v3, v3, v4
	and.16b	v3, v0, v3
	tbnz	w11, #4, LBB0_133
LBB0_126:                               ; %else237
                                        ;   in Loop: Header=BB0_121 Depth=2
	tbnz	w11, #5, LBB0_134
LBB0_127:                               ; %else239
                                        ;   in Loop: Header=BB0_121 Depth=2
	tbnz	w11, #6, LBB0_135
LBB0_128:                               ; %else241
                                        ;   in Loop: Header=BB0_121 Depth=2
	tbz	w11, #7, LBB0_120
	b	LBB0_136
LBB0_129:                               ; %cond.store228
                                        ;   in Loop: Header=BB0_121 Depth=2
	str	s7, [x9]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_123
LBB0_130:                               ; %cond.store230
                                        ;   in Loop: Header=BB0_121 Depth=2
	add	x12, x9, #4
	st1.s	{ v7 }[1], [x12]
	tbz	w11, #2, LBB0_124
LBB0_131:                               ; %cond.store232
                                        ;   in Loop: Header=BB0_121 Depth=2
	add	x12, x9, #8
	st1.s	{ v7 }[2], [x12]
	tbz	w11, #3, LBB0_125
LBB0_132:                               ; %cond.store234
                                        ;   in Loop: Header=BB0_121 Depth=2
	add	x12, x9, #12
	st1.s	{ v7 }[3], [x12]
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fadd.4s	v3, v3, v4
	and.16b	v3, v0, v3
	tbz	w11, #4, LBB0_126
LBB0_133:                               ; %cond.store236
                                        ;   in Loop: Header=BB0_121 Depth=2
	str	s3, [x9, #16]
	tbz	w11, #5, LBB0_127
LBB0_134:                               ; %cond.store238
                                        ;   in Loop: Header=BB0_121 Depth=2
	add	x12, x9, #20
	st1.s	{ v3 }[1], [x12]
	tbz	w11, #6, LBB0_128
LBB0_135:                               ; %cond.store240
                                        ;   in Loop: Header=BB0_121 Depth=2
	add	x12, x9, #24
	st1.s	{ v3 }[2], [x12]
	tbz	w11, #7, LBB0_120
LBB0_136:                               ; %cond.store242
                                        ;   in Loop: Header=BB0_121 Depth=2
	add	x9, x9, #28
	st1.s	{ v3 }[3], [x9]
	b	LBB0_120
LBB0_137:                               ; %block.batch.exit.loopexit
	ldr	x9, [sp, #8]                    ; 8-byte Reload
	stp	w5, w4, [x9]
	str	w3, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
LBB0_138:                               ; %block.batch.exit
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2240
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

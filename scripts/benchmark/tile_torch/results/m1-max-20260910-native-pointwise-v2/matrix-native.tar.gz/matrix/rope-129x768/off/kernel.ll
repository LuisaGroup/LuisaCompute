; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [1536 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [1536 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [1536 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [1536 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill11 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill11, align 64
  %.slot12 = alloca i64, align 8
  store i64 0, ptr %.slot12, align 4
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat20, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat22, %45
  %48 = mul i32 %36, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat24, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat26, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert27 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat28
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %70, 0
  %73 = select <8 x i1> %55, <8 x ptr> %71, <8 x ptr> %72
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %70, 1
  %76 = select <8 x i1> %55, <8 x i64> %74, <8 x i64> %75
  %77 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %73, 0
  %78 = insertvalue { <8 x ptr>, <8 x i64> } %77, <8 x i64> %76, 1
  store { <8 x ptr>, <8 x i64> } %78, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %79 = icmp slt i64 %.state, 48
  br i1 %79, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state29 = load i64, ptr %.slot, align 4
  %80 = mul i64 %.state29, 8
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.splat31, %.spill.load
  %.spill.load32 = load <8 x i64>, ptr %.spill10, align 64
  %82 = add <8 x i64> %.spill.load32, zeroinitializer
  %83 = add <8 x i64> zeroinitializer, %82
  %84 = add <8 x i64> zeroinitializer, %81
  %85 = mul <8 x i64> %83, splat (i64 768)
  %86 = add <8 x i64> %85, %84
  %87 = extractvalue { ptr, i64 } %13, 0
  %88 = extractelement <8 x i64> %86, i32 0
  %89 = sub i64 %88, 0
  %90 = mul i64 %89, 4
  %buffer.contiguous.address = getelementptr i8, ptr %87, i64 %90
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %92 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state33 = load i64, ptr %.slot, align 4
  %.splatinsert34 = insertelement <8 x i64> poison, i64 %.state33, i64 0
  %.splat35 = shufflevector <8 x i64> %.splatinsert34, <8 x i64> poison, <8 x i32> zeroinitializer
  %93 = mul <8 x i64> %.splat35, splat (i64 32)
  %94 = add <8 x i64> %92, %93
  %95 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %91, 0
  %96 = insertvalue { <8 x ptr>, <8 x i64> } %95, <8 x i64> %94, 1
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %99 = extractelement <8 x ptr> %97, i32 0
  %100 = extractelement <8 x i64> %98, i32 0
  %101 = sub i64 %100, 0
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %103 = select i1 %102, i64 %101, i64 0
  %private.contiguous.address = getelementptr i8, ptr %99, i64 %103
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %104 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %104, ptr %private.contiguous.address, align 4
  %.state36 = load i64, ptr %.slot, align 4
  %105 = add i64 %.state36, 1
  store i64 %105, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 0
  %109 = select <8 x i1> %55, <8 x ptr> %107, <8 x ptr> %108
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %112 = select <8 x i1> %55, <8 x i64> %110, <8 x i64> %111
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  store { <8 x ptr>, <8 x i64> } %114, ptr %tile_snapshot.spill11, align 64
  store i64 0, ptr %.slot12, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state37 = load i64, ptr %.slot12, align 4
  %115 = icmp slt i64 %.state37, 48
  br i1 %115, label %direct.true38, label %direct.false39

direct.schedule.5:                                ; preds = %direct.true38
  %.state40 = load i64, ptr %.slot12, align 4
  %116 = mul i64 %.state40, 8
  %.splatinsert41 = insertelement <8 x i64> poison, i64 %116, i64 0
  %.splat42 = shufflevector <8 x i64> %.splatinsert41, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load43 = load <8 x i64>, ptr %.spill, align 64
  %117 = add <8 x i64> %.splat42, %.spill.load43
  %.spill.load44 = load <8 x i64>, ptr %.spill10, align 64
  %118 = add <8 x i64> %.spill.load44, zeroinitializer
  %119 = add <8 x i64> zeroinitializer, %118
  %120 = add <8 x i64> splat (i64 384), %117
  %121 = mul <8 x i64> %119, splat (i64 768)
  %122 = add <8 x i64> %121, %120
  %123 = extractvalue { ptr, i64 } %13, 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = mul i64 %125, 4
  %buffer.contiguous.address45 = getelementptr i8, ptr %123, i64 %126
  %buffer.contiguous.load46 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address45, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load47 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 0
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 1
  %.state48 = load i64, ptr %.slot12, align 4
  %.splatinsert49 = insertelement <8 x i64> poison, i64 %.state48, i64 0
  %.splat50 = shufflevector <8 x i64> %.splatinsert49, <8 x i64> poison, <8 x i32> zeroinitializer
  %129 = mul <8 x i64> %.splat50, splat (i64 32)
  %130 = add <8 x i64> %128, %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %135 = extractelement <8 x ptr> %133, i32 0
  %136 = extractelement <8 x i64> %134, i32 0
  %137 = sub i64 %136, 0
  %138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %139 = select i1 %138, i64 %137, i64 0
  %private.contiguous.address51 = getelementptr i8, ptr %135, i64 %139
  %private.contiguous.preserve52 = load <8 x float>, ptr %private.contiguous.address51, align 4
  %140 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load46, <8 x float> %private.contiguous.preserve52
  store <8 x float> %140, ptr %private.contiguous.address51, align 4
  %.state53 = load i64, ptr %.slot12, align 4
  %141 = add i64 %.state53, 1
  store i64 %141, ptr %.slot12, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false39
  %142 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %142, 0
  %145 = select <8 x i1> %55, <8 x ptr> %143, <8 x ptr> %144
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %142, 1
  %148 = select <8 x i1> %55, <8 x i64> %146, <8 x i64> %147
  %149 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %150 = insertvalue { <8 x ptr>, <8 x i64> } %149, <8 x i64> %148, 1
  store { <8 x ptr>, <8 x i64> } %150, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state54 = load i64, ptr %.slot14, align 4
  %151 = icmp slt i64 %.state54, 48
  br i1 %151, label %direct.true55, label %direct.false56

direct.schedule.8:                                ; preds = %direct.true55
  %.state57 = load i64, ptr %.slot14, align 4
  %152 = mul i64 %.state57, 8
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %152, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %153 = add <8 x i64> %.splat59, %.spill.load60
  %.spill.load61 = load <8 x i64>, ptr %.spill10, align 64
  %154 = add <8 x i64> %.spill.load61, zeroinitializer
  %155 = add <8 x i64> zeroinitializer, %154
  %156 = add <8 x i64> zeroinitializer, %153
  %157 = mul <8 x i64> %155, splat (i64 384)
  %158 = add <8 x i64> %157, %156
  %159 = extractvalue { ptr, i64 } %19, 0
  %160 = extractelement <8 x i64> %158, i32 0
  %161 = sub i64 %160, 0
  %162 = mul i64 %161, 4
  %buffer.contiguous.address62 = getelementptr i8, ptr %159, i64 %162
  %buffer.contiguous.load63 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address62, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %.state65 = load i64, ptr %.slot14, align 4
  %.splatinsert66 = insertelement <8 x i64> poison, i64 %.state65, i64 0
  %.splat67 = shufflevector <8 x i64> %.splatinsert66, <8 x i64> poison, <8 x i32> zeroinitializer
  %165 = mul <8 x i64> %.splat67, splat (i64 32)
  %166 = add <8 x i64> %164, %165
  %167 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %163, 0
  %168 = insertvalue { <8 x ptr>, <8 x i64> } %167, <8 x i64> %166, 1
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %168, 1
  %171 = extractelement <8 x ptr> %169, i32 0
  %172 = extractelement <8 x i64> %170, i32 0
  %173 = sub i64 %172, 0
  %174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %175 = select i1 %174, i64 %173, i64 0
  %private.contiguous.address68 = getelementptr i8, ptr %171, i64 %175
  %private.contiguous.preserve69 = load <8 x float>, ptr %private.contiguous.address68, align 4
  %176 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load63, <8 x float> %private.contiguous.preserve69
  store <8 x float> %176, ptr %private.contiguous.address68, align 4
  %.state70 = load i64, ptr %.slot14, align 4
  %177 = add i64 %.state70, 1
  store i64 %177, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false56
  %178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %178, 0
  %181 = select <8 x i1> %55, <8 x ptr> %179, <8 x ptr> %180
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %178, 1
  %184 = select <8 x i1> %55, <8 x i64> %182, <8 x i64> %183
  %185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %181, 0
  %186 = insertvalue { <8 x ptr>, <8 x i64> } %185, <8 x i64> %184, 1
  store { <8 x ptr>, <8 x i64> } %186, ptr %tile_snapshot.spill15, align 64
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state71 = load i64, ptr %.slot16, align 4
  %187 = icmp slt i64 %.state71, 48
  br i1 %187, label %direct.true72, label %direct.false73

direct.schedule.11:                               ; preds = %direct.true72
  %.state74 = load i64, ptr %.slot16, align 4
  %188 = mul i64 %.state74, 8
  %.splatinsert75 = insertelement <8 x i64> poison, i64 %188, i64 0
  %.splat76 = shufflevector <8 x i64> %.splatinsert75, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load77 = load <8 x i64>, ptr %.spill, align 64
  %189 = add <8 x i64> %.splat76, %.spill.load77
  %.spill.load78 = load <8 x i64>, ptr %.spill10, align 64
  %190 = add <8 x i64> %.spill.load78, zeroinitializer
  %191 = add <8 x i64> zeroinitializer, %190
  %192 = add <8 x i64> zeroinitializer, %189
  %193 = mul <8 x i64> %191, splat (i64 384)
  %194 = add <8 x i64> %193, %192
  %195 = extractvalue { ptr, i64 } %25, 0
  %196 = extractelement <8 x i64> %194, i32 0
  %197 = sub i64 %196, 0
  %198 = mul i64 %197, 4
  %buffer.contiguous.address79 = getelementptr i8, ptr %195, i64 %198
  %buffer.contiguous.load80 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address79, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load81 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 1
  %.state82 = load i64, ptr %.slot16, align 4
  %.splatinsert83 = insertelement <8 x i64> poison, i64 %.state82, i64 0
  %.splat84 = shufflevector <8 x i64> %.splatinsert83, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = mul <8 x i64> %.splat84, splat (i64 32)
  %202 = add <8 x i64> %200, %201
  %203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %199, 0
  %204 = insertvalue { <8 x ptr>, <8 x i64> } %203, <8 x i64> %202, 1
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %204, 1
  %207 = extractelement <8 x ptr> %205, i32 0
  %208 = extractelement <8 x i64> %206, i32 0
  %209 = sub i64 %208, 0
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %211 = select i1 %210, i64 %209, i64 0
  %private.contiguous.address85 = getelementptr i8, ptr %207, i64 %211
  %private.contiguous.preserve86 = load <8 x float>, ptr %private.contiguous.address85, align 4
  %212 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load80, <8 x float> %private.contiguous.preserve86
  store <8 x float> %212, ptr %private.contiguous.address85, align 4
  %.state87 = load i64, ptr %.slot16, align 4
  %213 = add i64 %.state87, 1
  store i64 %213, ptr %.slot16, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false73
  store i64 0, ptr %.slot17, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state88 = load i64, ptr %.slot17, align 4
  %214 = icmp slt i64 %.state88, 48
  br i1 %214, label %direct.true89, label %direct.false90

direct.schedule.14:                               ; preds = %direct.true89
  %.state91 = load i64, ptr %.slot17, align 4
  %215 = mul i64 %.state91, 8
  %.splatinsert92 = insertelement <8 x i64> poison, i64 %215, i64 0
  %.splat93 = shufflevector <8 x i64> %.splatinsert92, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load94 = load <8 x i64>, ptr %.spill, align 64
  %216 = add <8 x i64> %.splat93, %.spill.load94
  %.spill.load95 = load <8 x i64>, ptr %.spill10, align 64
  %217 = add <8 x i64> %.spill.load95, zeroinitializer
  %218 = add <8 x i64> zeroinitializer, %217
  %219 = add <8 x i64> zeroinitializer, %216
  %220 = mul <8 x i64> %218, splat (i64 768)
  %221 = add <8 x i64> %220, %219
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.state97 = load i64, ptr %.slot17, align 4
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %.state97, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %224 = mul <8 x i64> %.splat99, splat (i64 32)
  %225 = add <8 x i64> %223, %224
  %226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %227 = insertvalue { <8 x ptr>, <8 x i64> } %226, <8 x i64> %225, 1
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %227, 1
  %230 = extractelement <8 x ptr> %228, i32 0
  %231 = extractelement <8 x i64> %229, i32 0
  %232 = sub i64 %231, 0
  %233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %234 = select i1 %233, i64 %232, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %230, i64 %234
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address100, align 4
  %235 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %.state102 = load i64, ptr %.slot17, align 4
  %.splatinsert103 = insertelement <8 x i64> poison, i64 %.state102, i64 0
  %.splat104 = shufflevector <8 x i64> %.splatinsert103, <8 x i64> poison, <8 x i32> zeroinitializer
  %238 = mul <8 x i64> %.splat104, splat (i64 32)
  %239 = add <8 x i64> %237, %238
  %240 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %236, 0
  %241 = insertvalue { <8 x ptr>, <8 x i64> } %240, <8 x i64> %239, 1
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %241, 1
  %244 = extractelement <8 x ptr> %242, i32 0
  %245 = extractelement <8 x i64> %243, i32 0
  %246 = sub i64 %245, 0
  %247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %248 = select i1 %247, i64 %246, i64 0
  %private.contiguous.address105 = getelementptr i8, ptr %244, i64 %248
  %private.contiguous.load106 = load <8 x float>, ptr %private.contiguous.address105, align 4
  %249 = select <8 x i1> %55, <8 x float> %private.contiguous.load106, <8 x float> zeroinitializer
  %250 = fmul <8 x float> %235, %249
  %tile_snapshot.spill.load107 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 1
  %.state108 = load i64, ptr %.slot17, align 4
  %.splatinsert109 = insertelement <8 x i64> poison, i64 %.state108, i64 0
  %.splat110 = shufflevector <8 x i64> %.splatinsert109, <8 x i64> poison, <8 x i32> zeroinitializer
  %253 = mul <8 x i64> %.splat110, splat (i64 32)
  %254 = add <8 x i64> %252, %253
  %255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %251, 0
  %256 = insertvalue { <8 x ptr>, <8 x i64> } %255, <8 x i64> %254, 1
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %256, 1
  %259 = extractelement <8 x ptr> %257, i32 0
  %260 = extractelement <8 x i64> %258, i32 0
  %261 = sub i64 %260, 0
  %262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %263 = select i1 %262, i64 %261, i64 0
  %private.contiguous.address111 = getelementptr i8, ptr %259, i64 %263
  %private.contiguous.load112 = load <8 x float>, ptr %private.contiguous.address111, align 4
  %264 = select <8 x i1> %55, <8 x float> %private.contiguous.load112, <8 x float> zeroinitializer
  %tile_snapshot.spill.load113 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load113, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load113, 1
  %.state114 = load i64, ptr %.slot17, align 4
  %.splatinsert115 = insertelement <8 x i64> poison, i64 %.state114, i64 0
  %.splat116 = shufflevector <8 x i64> %.splatinsert115, <8 x i64> poison, <8 x i32> zeroinitializer
  %267 = mul <8 x i64> %.splat116, splat (i64 32)
  %268 = add <8 x i64> %266, %267
  %269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %270 = insertvalue { <8 x ptr>, <8 x i64> } %269, <8 x i64> %268, 1
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %270, 1
  %273 = extractelement <8 x ptr> %271, i32 0
  %274 = extractelement <8 x i64> %272, i32 0
  %275 = sub i64 %274, 0
  %276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %277 = select i1 %276, i64 %275, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %273, i64 %277
  %private.contiguous.load118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %278 = select <8 x i1> %55, <8 x float> %private.contiguous.load118, <8 x float> zeroinitializer
  %279 = fmul <8 x float> %264, %278
  %280 = fsub <8 x float> %250, %279
  %281 = extractvalue { ptr, i64 } %31, 0
  %282 = extractelement <8 x i64> %221, i32 0
  %283 = sub i64 %282, 0
  %284 = mul i64 %283, 4
  %buffer.contiguous.address119 = getelementptr i8, ptr %281, i64 %284
  call void @llvm.masked.store.v8f32.p0(<8 x float> %280, ptr align 1 %buffer.contiguous.address119, <8 x i1> %55)
  %.state120 = load i64, ptr %.slot17, align 4
  %285 = add i64 %.state120, 1
  store i64 %285, ptr %.slot17, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false90
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state121 = load i64, ptr %.slot18, align 4
  %286 = icmp slt i64 %.state121, 48
  br i1 %286, label %direct.true122, label %direct.false123

direct.schedule.17:                               ; preds = %direct.true122
  %.state124 = load i64, ptr %.slot18, align 4
  %287 = mul i64 %.state124, 8
  %.splatinsert125 = insertelement <8 x i64> poison, i64 %287, i64 0
  %.splat126 = shufflevector <8 x i64> %.splatinsert125, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load127 = load <8 x i64>, ptr %.spill, align 64
  %288 = add <8 x i64> %.splat126, %.spill.load127
  %.spill.load128 = load <8 x i64>, ptr %.spill10, align 64
  %289 = add <8 x i64> %.spill.load128, zeroinitializer
  %290 = add <8 x i64> zeroinitializer, %289
  %291 = add <8 x i64> splat (i64 384), %288
  %292 = mul <8 x i64> %290, splat (i64 768)
  %293 = add <8 x i64> %292, %291
  %tile_snapshot.spill.load129 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 1
  %.state130 = load i64, ptr %.slot18, align 4
  %.splatinsert131 = insertelement <8 x i64> poison, i64 %.state130, i64 0
  %.splat132 = shufflevector <8 x i64> %.splatinsert131, <8 x i64> poison, <8 x i32> zeroinitializer
  %296 = mul <8 x i64> %.splat132, splat (i64 32)
  %297 = add <8 x i64> %295, %296
  %298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %294, 0
  %299 = insertvalue { <8 x ptr>, <8 x i64> } %298, <8 x i64> %297, 1
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %299, 1
  %302 = extractelement <8 x ptr> %300, i32 0
  %303 = extractelement <8 x i64> %301, i32 0
  %304 = sub i64 %303, 0
  %305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %306 = select i1 %305, i64 %304, i64 0
  %private.contiguous.address133 = getelementptr i8, ptr %302, i64 %306
  %private.contiguous.load134 = load <8 x float>, ptr %private.contiguous.address133, align 4
  %307 = select <8 x i1> %55, <8 x float> %private.contiguous.load134, <8 x float> zeroinitializer
  %tile_snapshot.spill.load135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 1
  %.state136 = load i64, ptr %.slot18, align 4
  %.splatinsert137 = insertelement <8 x i64> poison, i64 %.state136, i64 0
  %.splat138 = shufflevector <8 x i64> %.splatinsert137, <8 x i64> poison, <8 x i32> zeroinitializer
  %310 = mul <8 x i64> %.splat138, splat (i64 32)
  %311 = add <8 x i64> %309, %310
  %312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %313 = insertvalue { <8 x ptr>, <8 x i64> } %312, <8 x i64> %311, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %316 = extractelement <8 x ptr> %314, i32 0
  %317 = extractelement <8 x i64> %315, i32 0
  %318 = sub i64 %317, 0
  %319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %320 = select i1 %319, i64 %318, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %316, i64 %320
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %321 = select <8 x i1> %55, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %322 = fmul <8 x float> %307, %321
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %.state142 = load i64, ptr %.slot18, align 4
  %.splatinsert143 = insertelement <8 x i64> poison, i64 %.state142, i64 0
  %.splat144 = shufflevector <8 x i64> %.splatinsert143, <8 x i64> poison, <8 x i32> zeroinitializer
  %325 = mul <8 x i64> %.splat144, splat (i64 32)
  %326 = add <8 x i64> %324, %325
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %323, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = extractelement <8 x ptr> %329, i32 0
  %332 = extractelement <8 x i64> %330, i32 0
  %333 = sub i64 %332, 0
  %334 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %335 = select i1 %334, i64 %333, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %331, i64 %335
  %private.contiguous.load146 = load <8 x float>, ptr %private.contiguous.address145, align 4
  %336 = select <8 x i1> %55, <8 x float> %private.contiguous.load146, <8 x float> zeroinitializer
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %.state148 = load i64, ptr %.slot18, align 4
  %.splatinsert149 = insertelement <8 x i64> poison, i64 %.state148, i64 0
  %.splat150 = shufflevector <8 x i64> %.splatinsert149, <8 x i64> poison, <8 x i32> zeroinitializer
  %339 = mul <8 x i64> %.splat150, splat (i64 32)
  %340 = add <8 x i64> %338, %339
  %341 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %337, 0
  %342 = insertvalue { <8 x ptr>, <8 x i64> } %341, <8 x i64> %340, 1
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %342, 1
  %345 = extractelement <8 x ptr> %343, i32 0
  %346 = extractelement <8 x i64> %344, i32 0
  %347 = sub i64 %346, 0
  %348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %349 = select i1 %348, i64 %347, i64 0
  %private.contiguous.address151 = getelementptr i8, ptr %345, i64 %349
  %private.contiguous.load152 = load <8 x float>, ptr %private.contiguous.address151, align 4
  %350 = select <8 x i1> %55, <8 x float> %private.contiguous.load152, <8 x float> zeroinitializer
  %351 = fmul <8 x float> %336, %350
  %352 = fadd <8 x float> %322, %351
  %353 = extractvalue { ptr, i64 } %31, 0
  %354 = extractelement <8 x i64> %293, i32 0
  %355 = sub i64 %354, 0
  %356 = mul i64 %355, 4
  %buffer.contiguous.address153 = getelementptr i8, ptr %353, i64 %356
  call void @llvm.masked.store.v8f32.p0(<8 x float> %352, ptr align 1 %buffer.contiguous.address153, <8 x i1> %55)
  %.state154 = load i64, ptr %.slot18, align 4
  %357 = add i64 %.state154, 1
  store i64 %357, ptr %.slot18, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false123
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true38:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false39:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true55:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false56:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true72:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false73:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true89:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false90:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true122:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false123:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #2

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [1536 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [1536 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [1536 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [1536 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill11 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill11, align 64
  %.slot12 = alloca i64, align 8
  store i64 0, ptr %.slot12, align 4
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat20, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat22, %45
  %48 = mul i32 %36, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat24, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat26, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert27 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat28 = shufflevector <8 x i32> %.splatinsert27, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat28
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %70, 0
  %73 = select <8 x i1> %55, <8 x ptr> %71, <8 x ptr> %72
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %70, 1
  %76 = select <8 x i1> %55, <8 x i64> %74, <8 x i64> %75
  %77 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %73, 0
  %78 = insertvalue { <8 x ptr>, <8 x i64> } %77, <8 x i64> %76, 1
  store { <8 x ptr>, <8 x i64> } %78, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %79 = icmp slt i64 %.state, 48
  br i1 %79, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state29 = load i64, ptr %.slot, align 4
  %80 = mul i64 %.state29, 8
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.splat31, %.spill.load
  %.spill.load32 = load <8 x i64>, ptr %.spill10, align 64
  %82 = add <8 x i64> %.spill.load32, zeroinitializer
  %83 = add <8 x i64> zeroinitializer, %82
  %84 = add <8 x i64> zeroinitializer, %81
  %85 = mul <8 x i64> %83, splat (i64 768)
  %86 = add <8 x i64> %85, %84
  %87 = extractvalue { ptr, i64 } %13, 0
  %88 = extractelement <8 x i64> %86, i32 0
  %89 = sub i64 %88, 0
  %90 = mul i64 %89, 4
  %buffer.contiguous.address = getelementptr i8, ptr %87, i64 %90
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %92 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state33 = load i64, ptr %.slot, align 4
  %.splatinsert34 = insertelement <8 x i64> poison, i64 %.state33, i64 0
  %.splat35 = shufflevector <8 x i64> %.splatinsert34, <8 x i64> poison, <8 x i32> zeroinitializer
  %93 = mul <8 x i64> %.splat35, splat (i64 32)
  %94 = add <8 x i64> %92, %93
  %95 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %91, 0
  %96 = insertvalue { <8 x ptr>, <8 x i64> } %95, <8 x i64> %94, 1
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %99 = extractelement <8 x ptr> %97, i32 0
  %100 = extractelement <8 x i64> %98, i32 0
  %101 = sub i64 %100, 0
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %103 = select i1 %102, i64 %101, i64 0
  %private.contiguous.address = getelementptr i8, ptr %99, i64 %103
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %104 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %104, ptr %private.contiguous.address, align 4
  %.state36 = load i64, ptr %.slot, align 4
  %105 = add i64 %.state36, 1
  store i64 %105, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %106 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %106, 0
  %109 = select <8 x i1> %55, <8 x ptr> %107, <8 x ptr> %108
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %106, 1
  %112 = select <8 x i1> %55, <8 x i64> %110, <8 x i64> %111
  %113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %109, 0
  %114 = insertvalue { <8 x ptr>, <8 x i64> } %113, <8 x i64> %112, 1
  store { <8 x ptr>, <8 x i64> } %114, ptr %tile_snapshot.spill11, align 64
  store i64 0, ptr %.slot12, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state37 = load i64, ptr %.slot12, align 4
  %115 = icmp slt i64 %.state37, 48
  br i1 %115, label %direct.true38, label %direct.false39

direct.schedule.5:                                ; preds = %direct.true38
  %.state40 = load i64, ptr %.slot12, align 4
  %116 = mul i64 %.state40, 8
  %.splatinsert41 = insertelement <8 x i64> poison, i64 %116, i64 0
  %.splat42 = shufflevector <8 x i64> %.splatinsert41, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load43 = load <8 x i64>, ptr %.spill, align 64
  %117 = add <8 x i64> %.splat42, %.spill.load43
  %.spill.load44 = load <8 x i64>, ptr %.spill10, align 64
  %118 = add <8 x i64> %.spill.load44, zeroinitializer
  %119 = add <8 x i64> zeroinitializer, %118
  %120 = add <8 x i64> splat (i64 384), %117
  %121 = mul <8 x i64> %119, splat (i64 768)
  %122 = add <8 x i64> %121, %120
  %123 = extractvalue { ptr, i64 } %13, 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = mul i64 %125, 4
  %buffer.contiguous.address45 = getelementptr i8, ptr %123, i64 %126
  %buffer.contiguous.load46 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address45, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load47 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 0
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load47, 1
  %.state48 = load i64, ptr %.slot12, align 4
  %.splatinsert49 = insertelement <8 x i64> poison, i64 %.state48, i64 0
  %.splat50 = shufflevector <8 x i64> %.splatinsert49, <8 x i64> poison, <8 x i32> zeroinitializer
  %129 = mul <8 x i64> %.splat50, splat (i64 32)
  %130 = add <8 x i64> %128, %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %135 = extractelement <8 x ptr> %133, i32 0
  %136 = extractelement <8 x i64> %134, i32 0
  %137 = sub i64 %136, 0
  %138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %139 = select i1 %138, i64 %137, i64 0
  %private.contiguous.address51 = getelementptr i8, ptr %135, i64 %139
  %private.contiguous.preserve52 = load <8 x float>, ptr %private.contiguous.address51, align 4
  %140 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load46, <8 x float> %private.contiguous.preserve52
  store <8 x float> %140, ptr %private.contiguous.address51, align 4
  %.state53 = load i64, ptr %.slot12, align 4
  %141 = add i64 %.state53, 1
  store i64 %141, ptr %.slot12, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false39
  %142 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %144 = extractvalue { <8 x ptr>, <8 x i64> } %142, 0
  %145 = select <8 x i1> %55, <8 x ptr> %143, <8 x ptr> %144
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %142, 1
  %148 = select <8 x i1> %55, <8 x i64> %146, <8 x i64> %147
  %149 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %150 = insertvalue { <8 x ptr>, <8 x i64> } %149, <8 x i64> %148, 1
  store { <8 x ptr>, <8 x i64> } %150, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state54 = load i64, ptr %.slot14, align 4
  %151 = icmp slt i64 %.state54, 48
  br i1 %151, label %direct.true55, label %direct.false56

direct.schedule.8:                                ; preds = %direct.true55
  %.state57 = load i64, ptr %.slot14, align 4
  %152 = mul i64 %.state57, 8
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %152, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %153 = add <8 x i64> %.splat59, %.spill.load60
  %.spill.load61 = load <8 x i64>, ptr %.spill10, align 64
  %154 = add <8 x i64> %.spill.load61, zeroinitializer
  %155 = add <8 x i64> zeroinitializer, %154
  %156 = add <8 x i64> zeroinitializer, %153
  %157 = mul <8 x i64> %155, splat (i64 384)
  %158 = add <8 x i64> %157, %156
  %159 = extractvalue { ptr, i64 } %19, 0
  %160 = extractelement <8 x i64> %158, i32 0
  %161 = sub i64 %160, 0
  %162 = mul i64 %161, 4
  %buffer.contiguous.address62 = getelementptr i8, ptr %159, i64 %162
  %buffer.contiguous.load63 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address62, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %.state65 = load i64, ptr %.slot14, align 4
  %.splatinsert66 = insertelement <8 x i64> poison, i64 %.state65, i64 0
  %.splat67 = shufflevector <8 x i64> %.splatinsert66, <8 x i64> poison, <8 x i32> zeroinitializer
  %165 = mul <8 x i64> %.splat67, splat (i64 32)
  %166 = add <8 x i64> %164, %165
  %167 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %163, 0
  %168 = insertvalue { <8 x ptr>, <8 x i64> } %167, <8 x i64> %166, 1
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %168, 1
  %171 = extractelement <8 x ptr> %169, i32 0
  %172 = extractelement <8 x i64> %170, i32 0
  %173 = sub i64 %172, 0
  %174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %175 = select i1 %174, i64 %173, i64 0
  %private.contiguous.address68 = getelementptr i8, ptr %171, i64 %175
  %private.contiguous.preserve69 = load <8 x float>, ptr %private.contiguous.address68, align 4
  %176 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load63, <8 x float> %private.contiguous.preserve69
  store <8 x float> %176, ptr %private.contiguous.address68, align 4
  %.state70 = load i64, ptr %.slot14, align 4
  %177 = add i64 %.state70, 1
  store i64 %177, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false56
  %178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %178, 0
  %181 = select <8 x i1> %55, <8 x ptr> %179, <8 x ptr> %180
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %178, 1
  %184 = select <8 x i1> %55, <8 x i64> %182, <8 x i64> %183
  %185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %181, 0
  %186 = insertvalue { <8 x ptr>, <8 x i64> } %185, <8 x i64> %184, 1
  store { <8 x ptr>, <8 x i64> } %186, ptr %tile_snapshot.spill15, align 64
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state71 = load i64, ptr %.slot16, align 4
  %187 = icmp slt i64 %.state71, 48
  br i1 %187, label %direct.true72, label %direct.false73

direct.schedule.11:                               ; preds = %direct.true72
  %.state74 = load i64, ptr %.slot16, align 4
  %188 = mul i64 %.state74, 8
  %.splatinsert75 = insertelement <8 x i64> poison, i64 %188, i64 0
  %.splat76 = shufflevector <8 x i64> %.splatinsert75, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load77 = load <8 x i64>, ptr %.spill, align 64
  %189 = add <8 x i64> %.splat76, %.spill.load77
  %.spill.load78 = load <8 x i64>, ptr %.spill10, align 64
  %190 = add <8 x i64> %.spill.load78, zeroinitializer
  %191 = add <8 x i64> zeroinitializer, %190
  %192 = add <8 x i64> zeroinitializer, %189
  %193 = mul <8 x i64> %191, splat (i64 384)
  %194 = add <8 x i64> %193, %192
  %195 = extractvalue { ptr, i64 } %25, 0
  %196 = extractelement <8 x i64> %194, i32 0
  %197 = sub i64 %196, 0
  %198 = mul i64 %197, 4
  %buffer.contiguous.address79 = getelementptr i8, ptr %195, i64 %198
  %buffer.contiguous.load80 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address79, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load81 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 0
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 1
  %.state82 = load i64, ptr %.slot16, align 4
  %.splatinsert83 = insertelement <8 x i64> poison, i64 %.state82, i64 0
  %.splat84 = shufflevector <8 x i64> %.splatinsert83, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = mul <8 x i64> %.splat84, splat (i64 32)
  %202 = add <8 x i64> %200, %201
  %203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %199, 0
  %204 = insertvalue { <8 x ptr>, <8 x i64> } %203, <8 x i64> %202, 1
  %205 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %204, 1
  %207 = extractelement <8 x ptr> %205, i32 0
  %208 = extractelement <8 x i64> %206, i32 0
  %209 = sub i64 %208, 0
  %210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %211 = select i1 %210, i64 %209, i64 0
  %private.contiguous.address85 = getelementptr i8, ptr %207, i64 %211
  %private.contiguous.preserve86 = load <8 x float>, ptr %private.contiguous.address85, align 4
  %212 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load80, <8 x float> %private.contiguous.preserve86
  store <8 x float> %212, ptr %private.contiguous.address85, align 4
  %.state87 = load i64, ptr %.slot16, align 4
  %213 = add i64 %.state87, 1
  store i64 %213, ptr %.slot16, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false73
  store i64 0, ptr %.slot17, align 4
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state88 = load i64, ptr %.slot17, align 4
  %214 = icmp slt i64 %.state88, 48
  br i1 %214, label %direct.true89, label %direct.false90

direct.schedule.14:                               ; preds = %direct.true89
  %.state91 = load i64, ptr %.slot17, align 4
  %215 = mul i64 %.state91, 8
  %.splatinsert92 = insertelement <8 x i64> poison, i64 %215, i64 0
  %.splat93 = shufflevector <8 x i64> %.splatinsert92, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load94 = load <8 x i64>, ptr %.spill, align 64
  %216 = add <8 x i64> %.splat93, %.spill.load94
  %.spill.load95 = load <8 x i64>, ptr %.spill10, align 64
  %217 = add <8 x i64> %.spill.load95, zeroinitializer
  %218 = add <8 x i64> zeroinitializer, %217
  %219 = add <8 x i64> zeroinitializer, %216
  %220 = mul <8 x i64> %218, splat (i64 768)
  %221 = add <8 x i64> %220, %219
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.state97 = load i64, ptr %.slot17, align 4
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %.state97, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %224 = mul <8 x i64> %.splat99, splat (i64 32)
  %225 = add <8 x i64> %223, %224
  %226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %227 = insertvalue { <8 x ptr>, <8 x i64> } %226, <8 x i64> %225, 1
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %227, 1
  %230 = extractelement <8 x ptr> %228, i32 0
  %231 = extractelement <8 x i64> %229, i32 0
  %232 = sub i64 %231, 0
  %233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %234 = select i1 %233, i64 %232, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %230, i64 %234
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address100, align 4
  %235 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %.state102 = load i64, ptr %.slot17, align 4
  %.splatinsert103 = insertelement <8 x i64> poison, i64 %.state102, i64 0
  %.splat104 = shufflevector <8 x i64> %.splatinsert103, <8 x i64> poison, <8 x i32> zeroinitializer
  %238 = mul <8 x i64> %.splat104, splat (i64 32)
  %239 = add <8 x i64> %237, %238
  %240 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %236, 0
  %241 = insertvalue { <8 x ptr>, <8 x i64> } %240, <8 x i64> %239, 1
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %241, 1
  %244 = extractelement <8 x ptr> %242, i32 0
  %245 = extractelement <8 x i64> %243, i32 0
  %246 = sub i64 %245, 0
  %247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %248 = select i1 %247, i64 %246, i64 0
  %private.contiguous.address105 = getelementptr i8, ptr %244, i64 %248
  %private.contiguous.load106 = load <8 x float>, ptr %private.contiguous.address105, align 4
  %249 = select <8 x i1> %55, <8 x float> %private.contiguous.load106, <8 x float> zeroinitializer
  %250 = fmul <8 x float> %235, %249
  %tile_snapshot.spill.load107 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 1
  %.state108 = load i64, ptr %.slot17, align 4
  %.splatinsert109 = insertelement <8 x i64> poison, i64 %.state108, i64 0
  %.splat110 = shufflevector <8 x i64> %.splatinsert109, <8 x i64> poison, <8 x i32> zeroinitializer
  %253 = mul <8 x i64> %.splat110, splat (i64 32)
  %254 = add <8 x i64> %252, %253
  %255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %251, 0
  %256 = insertvalue { <8 x ptr>, <8 x i64> } %255, <8 x i64> %254, 1
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %256, 1
  %259 = extractelement <8 x ptr> %257, i32 0
  %260 = extractelement <8 x i64> %258, i32 0
  %261 = sub i64 %260, 0
  %262 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %263 = select i1 %262, i64 %261, i64 0
  %private.contiguous.address111 = getelementptr i8, ptr %259, i64 %263
  %private.contiguous.load112 = load <8 x float>, ptr %private.contiguous.address111, align 4
  %264 = select <8 x i1> %55, <8 x float> %private.contiguous.load112, <8 x float> zeroinitializer
  %tile_snapshot.spill.load113 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load113, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load113, 1
  %.state114 = load i64, ptr %.slot17, align 4
  %.splatinsert115 = insertelement <8 x i64> poison, i64 %.state114, i64 0
  %.splat116 = shufflevector <8 x i64> %.splatinsert115, <8 x i64> poison, <8 x i32> zeroinitializer
  %267 = mul <8 x i64> %.splat116, splat (i64 32)
  %268 = add <8 x i64> %266, %267
  %269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %270 = insertvalue { <8 x ptr>, <8 x i64> } %269, <8 x i64> %268, 1
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %270, 1
  %273 = extractelement <8 x ptr> %271, i32 0
  %274 = extractelement <8 x i64> %272, i32 0
  %275 = sub i64 %274, 0
  %276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %277 = select i1 %276, i64 %275, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %273, i64 %277
  %private.contiguous.load118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %278 = select <8 x i1> %55, <8 x float> %private.contiguous.load118, <8 x float> zeroinitializer
  %279 = fmul <8 x float> %264, %278
  %280 = fsub <8 x float> %250, %279
  %281 = extractvalue { ptr, i64 } %31, 0
  %282 = extractelement <8 x i64> %221, i32 0
  %283 = sub i64 %282, 0
  %284 = mul i64 %283, 4
  %buffer.contiguous.address119 = getelementptr i8, ptr %281, i64 %284
  call void @llvm.masked.store.v8f32.p0(<8 x float> %280, ptr align 1 %buffer.contiguous.address119, <8 x i1> %55)
  %.state120 = load i64, ptr %.slot17, align 4
  %285 = add i64 %.state120, 1
  store i64 %285, ptr %.slot17, align 4
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false90
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state121 = load i64, ptr %.slot18, align 4
  %286 = icmp slt i64 %.state121, 48
  br i1 %286, label %direct.true122, label %direct.false123

direct.schedule.17:                               ; preds = %direct.true122
  %.state124 = load i64, ptr %.slot18, align 4
  %287 = mul i64 %.state124, 8
  %.splatinsert125 = insertelement <8 x i64> poison, i64 %287, i64 0
  %.splat126 = shufflevector <8 x i64> %.splatinsert125, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load127 = load <8 x i64>, ptr %.spill, align 64
  %288 = add <8 x i64> %.splat126, %.spill.load127
  %.spill.load128 = load <8 x i64>, ptr %.spill10, align 64
  %289 = add <8 x i64> %.spill.load128, zeroinitializer
  %290 = add <8 x i64> zeroinitializer, %289
  %291 = add <8 x i64> splat (i64 384), %288
  %292 = mul <8 x i64> %290, splat (i64 768)
  %293 = add <8 x i64> %292, %291
  %tile_snapshot.spill.load129 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 1
  %.state130 = load i64, ptr %.slot18, align 4
  %.splatinsert131 = insertelement <8 x i64> poison, i64 %.state130, i64 0
  %.splat132 = shufflevector <8 x i64> %.splatinsert131, <8 x i64> poison, <8 x i32> zeroinitializer
  %296 = mul <8 x i64> %.splat132, splat (i64 32)
  %297 = add <8 x i64> %295, %296
  %298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %294, 0
  %299 = insertvalue { <8 x ptr>, <8 x i64> } %298, <8 x i64> %297, 1
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %299, 1
  %302 = extractelement <8 x ptr> %300, i32 0
  %303 = extractelement <8 x i64> %301, i32 0
  %304 = sub i64 %303, 0
  %305 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %306 = select i1 %305, i64 %304, i64 0
  %private.contiguous.address133 = getelementptr i8, ptr %302, i64 %306
  %private.contiguous.load134 = load <8 x float>, ptr %private.contiguous.address133, align 4
  %307 = select <8 x i1> %55, <8 x float> %private.contiguous.load134, <8 x float> zeroinitializer
  %tile_snapshot.spill.load135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load135, 1
  %.state136 = load i64, ptr %.slot18, align 4
  %.splatinsert137 = insertelement <8 x i64> poison, i64 %.state136, i64 0
  %.splat138 = shufflevector <8 x i64> %.splatinsert137, <8 x i64> poison, <8 x i32> zeroinitializer
  %310 = mul <8 x i64> %.splat138, splat (i64 32)
  %311 = add <8 x i64> %309, %310
  %312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %313 = insertvalue { <8 x ptr>, <8 x i64> } %312, <8 x i64> %311, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %316 = extractelement <8 x ptr> %314, i32 0
  %317 = extractelement <8 x i64> %315, i32 0
  %318 = sub i64 %317, 0
  %319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %320 = select i1 %319, i64 %318, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %316, i64 %320
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %321 = select <8 x i1> %55, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %322 = fmul <8 x float> %307, %321
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill11, align 64
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %.state142 = load i64, ptr %.slot18, align 4
  %.splatinsert143 = insertelement <8 x i64> poison, i64 %.state142, i64 0
  %.splat144 = shufflevector <8 x i64> %.splatinsert143, <8 x i64> poison, <8 x i32> zeroinitializer
  %325 = mul <8 x i64> %.splat144, splat (i64 32)
  %326 = add <8 x i64> %324, %325
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %323, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = extractelement <8 x ptr> %329, i32 0
  %332 = extractelement <8 x i64> %330, i32 0
  %333 = sub i64 %332, 0
  %334 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %335 = select i1 %334, i64 %333, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %331, i64 %335
  %private.contiguous.load146 = load <8 x float>, ptr %private.contiguous.address145, align 4
  %336 = select <8 x i1> %55, <8 x float> %private.contiguous.load146, <8 x float> zeroinitializer
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %.state148 = load i64, ptr %.slot18, align 4
  %.splatinsert149 = insertelement <8 x i64> poison, i64 %.state148, i64 0
  %.splat150 = shufflevector <8 x i64> %.splatinsert149, <8 x i64> poison, <8 x i32> zeroinitializer
  %339 = mul <8 x i64> %.splat150, splat (i64 32)
  %340 = add <8 x i64> %338, %339
  %341 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %337, 0
  %342 = insertvalue { <8 x ptr>, <8 x i64> } %341, <8 x i64> %340, 1
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %342, 1
  %345 = extractelement <8 x ptr> %343, i32 0
  %346 = extractelement <8 x i64> %344, i32 0
  %347 = sub i64 %346, 0
  %348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %349 = select i1 %348, i64 %347, i64 0
  %private.contiguous.address151 = getelementptr i8, ptr %345, i64 %349
  %private.contiguous.load152 = load <8 x float>, ptr %private.contiguous.address151, align 4
  %350 = select <8 x i1> %55, <8 x float> %private.contiguous.load152, <8 x float> zeroinitializer
  %351 = fmul <8 x float> %336, %350
  %352 = fadd <8 x float> %322, %351
  %353 = extractvalue { ptr, i64 } %31, 0
  %354 = extractelement <8 x i64> %293, i32 0
  %355 = sub i64 %354, 0
  %356 = mul i64 %355, 4
  %buffer.contiguous.address153 = getelementptr i8, ptr %353, i64 %356
  call void @llvm.masked.store.v8f32.p0(<8 x float> %352, ptr align 1 %buffer.contiguous.address153, <8 x i1> %55)
  %.state154 = load i64, ptr %.slot18, align 4
  %357 = add i64 %.state154, 1
  store i64 %357, ptr %.slot18, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false123
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true38:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false39:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true55:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false56:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true72:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false73:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true89:                                    ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false90:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true122:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false123:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

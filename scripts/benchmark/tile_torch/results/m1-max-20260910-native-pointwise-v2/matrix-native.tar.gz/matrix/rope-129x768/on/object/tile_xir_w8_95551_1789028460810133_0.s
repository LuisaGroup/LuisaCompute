	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2048
	ldr	x8, [x0]
	ldr	x22, [x0, #16]
	ldr	x21, [x0, #32]
	ldr	x20, [x0, #48]
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	add	w9, w10, w9, lsl #5
	lsr	w9, w9, #3
	dup.2s	v0, w9
	ushll.2d	v1, v0, #0
	subs	x9, x8, x20
	cset	w10, hs
	lsr	x9, x9, #10
	cmp	x9, #386
	csel	w9, wzr, w10, ls
	subs	x10, x20, x8
	cset	w11, hs
	lsr	x10, x10, #10
	cmp	x10, #386
	csel	w10, wzr, w11, ls
	subs	x11, x22, x20
	cset	w12, hs
	lsr	x11, x11, #10
	cmp	x11, #386
	csel	w11, wzr, w12, ls
	subs	x12, x20, x22
	cset	w13, hs
	lsr	x12, x12, #9
	cmp	x12, #386
	csel	w12, wzr, w13, ls
	subs	x13, x21, x20
	cset	w14, hs
	lsr	x13, x13, #10
	cmp	x13, #386
	csel	w13, wzr, w14, ls
	subs	x14, x20, x21
	cset	w15, hs
	lsr	x14, x14, #9
	cmp	x14, #386
	csel	w14, wzr, w15, ls
	orr	w13, w13, w14
	cmp	w13, #1
	b.ne	LBB0_5
; %bb.1:                                ; %prologue
	orr	w9, w9, w10
	cbz	w9, LBB0_5
; %bb.2:                                ; %prologue
	orr	w9, w11, w12
	tbz	w9, #0, LBB0_5
; %bb.3:                                ; %direct.schedule.2.preheader
	mov	x9, #0                          ; =0x0
	movi.2s	v0, #3, lsl #8
	xtn.2s	v2, v1
	umull.2d	v0, v2, v0
	fmov	x11, d0
	fmov	x10, d1
	add	x10, x10, x10, lsl #1
	lsl	x10, x10, #7
	lsl	x11, x11, #2
	add	x12, x11, #1536
	add	x11, x8, x12
	add	x12, x20, x12
LBB0_4:                                 ; %direct.true30
                                        ; =>This Inner Loop Header: Depth=1
	fmov	d1, x9
	add.2d	v1, v1, v0
	fmov	x13, d1
	lsl	x13, x13, #2
	add	x14, x8, x13
	ldp	q1, q2, [x14]
	ldp	q3, q4, [x11], #32
	add	x14, x9, x10
	lsl	x14, x14, #2
	add	x15, x22, x14
	ldp	q5, q6, [x15]
	add	x14, x21, x14
	ldp	q7, q16, [x14]
	fmul.4s	v17, v2, v6
	fmul.4s	v18, v1, v5
	fmul.4s	v19, v4, v16
	fmul.4s	v20, v3, v7
	fsub.4s	v18, v18, v20
	fsub.4s	v17, v17, v19
	add	x13, x20, x13
	stp	q18, q17, [x13]
	fmul.4s	v2, v2, v16
	fmul.4s	v1, v1, v7
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v3, v1
	fadd.4s	v2, v4, v2
	stp	q1, q2, [x12], #32
	add	x9, x9, #8
	cmp	x9, #384
	b.ne	LBB0_4
	b	LBB0_9
LBB0_5:                                 ; %direct.schedule.6.preheader
	fmov	x9, d1
	add	x26, x9, x9, lsl #1
	lsl	x23, x26, #10
	add	x19, x8, x23
	add	x24, sp, #1, lsl #12            ; =4096
	add	x24, x24, #512
	add	x0, sp, #1, lsl #12             ; =4096
	add	x0, x0, #512
	mov	x1, x19
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	add	x25, sp, #3072
	add	x0, sp, #3072
	add	x1, x19, #1536
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	lsl	x26, x26, #9
	add	x19, sp, #1536
	add	x0, sp, #1536
	add	x1, x22, x26
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	mov	x22, sp
	mov	x0, sp
	add	x1, x21, x26
	mov	w2, #1536                       ; =0x600
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	add	x9, x20, x23
LBB0_6:                                 ; %direct.true111
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x24, x8
	ldp	q0, q1, [x10]
	add	x10, x19, x8
	ldp	q2, q3, [x10]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x10, x25, x8
	ldp	q2, q3, [x10]
	add	x10, x22, x8
	ldp	q4, q5, [x10]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fsub.4s	v0, v0, v2
	fsub.4s	v1, v1, v3
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_6
; %bb.7:                                ; %direct.schedule.21.preheader
	mov	x8, #0                          ; =0x0
	add	x9, x23, x20
	add	x9, x9, #1536
	add	x10, sp, #1, lsl #12            ; =4096
	add	x10, x10, #512
	mov	x11, sp
	add	x12, sp, #3072
	add	x13, sp, #1536
LBB0_8:                                 ; %direct.true144
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x10, x8
	ldp	q0, q1, [x14]
	add	x14, x11, x8
	ldp	q2, q3, [x14]
	fmul.4s	v1, v1, v3
	fmul.4s	v0, v0, v2
	add	x14, x12, x8
	ldp	q2, q3, [x14]
	add	x14, x13, x8
	ldp	q4, q5, [x14]
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
	add	x14, x9, x8
	stp	q0, q1, [x14]
	add	x8, x8, #32
	cmp	x8, #1536
	b.ne	LBB0_8
LBB0_9:                                 ; %common.ret
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2048
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d9, d8, [sp, #-112]!            ; 16-byte Folded Spill
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2176
	str	x0, [sp, #104]                  ; 8-byte Spill
	cbz	w3, LBB1_222
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x21, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	ldp	w27, w8, [x2, #44]
	str	w8, [sp, #100]                  ; 4-byte Spill
	ldp	w28, w12, [x2]
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Spill
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Spill
	movi.2s	v8, #3, lsl #8
Lloh4:
	adrp	x8, lCPI1_5@PAGE
Lloh5:
	ldr	q0, [x8, lCPI1_5@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh6:
	adrp	x8, lCPI1_6@PAGE
Lloh7:
	ldr	q21, [x8, lCPI1_6@PAGEOFF]
	add	x23, sp, #1664
	add	x24, sp, #128
	ldp	w19, w8, [x2, #8]
	str	x8, [sp, #88]                   ; 8-byte Spill
	str	w3, [sp, #84]                   ; 4-byte Spill
	str	w27, [sp, #12]                  ; 4-byte Spill
	str	q21, [sp, #64]                  ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w21, [sp, #84]                  ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w28, #1
	cmp	w8, w27
	cset	w8, eq
	csinc	w28, wzr, w28, eq
	cinc	w9, w25, eq
	ldr	w10, [sp, #100]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w12, wzr, w9, ne
	add	w19, w19, w8
	add	w22, w22, #1
	cmp	w22, w21
	b.eq	LBB1_222
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_116 Depth 2
                                        ;     Child Loop BB1_134 Depth 2
                                        ;     Child Loop BB1_152 Depth 2
                                        ;     Child Loop BB1_170 Depth 2
                                        ;     Child Loop BB1_188 Depth 2
                                        ;     Child Loop BB1_206 Depth 2
                                        ;     Child Loop BB1_18 Depth 2
	ubfiz	x8, x28, #5, #32
	ldr	x13, [sp, #88]                  ; 8-byte Reload
	cmp	x8, x13
	csel	x9, x8, xzr, ls
	subs	x10, x13, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x13, x9
	stp	w28, w12, [x20]
	mov	x25, x12
	str	w19, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x13, #2, hi
	csel	x26, x10, xzr, ls
	cmp	x26, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x26, [sp, #104]                 ; 8-byte Reload
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x21, x26, #3
	cbz	x21, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #104]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #104]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #104]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x27, [sp, #104]                 ; 8-byte Reload
	mov	x0, x27
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x27
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x27
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x27
	ldr	w27, [sp, #12]                  ; 4-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w26, #0x7
	add	x2, sp, #1, lsl #12             ; =4096
	add	x2, x2, #640
	ldr	q21, [sp, #64]                  ; 16-byte Reload
	add	x3, sp, #3200
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v0, w8
	ldp	q1, q2, [sp, #32]               ; 32-byte Folded Reload
	cmhi.4s	v1, v0, v1
	cmhi.4s	v0, v0, v2
	uzp1.8h	v3, v0, v1
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	ldr	x11, [x8]
	ldr	x10, [x8, #16]
	ldr	x9, [x8, #32]
	ldr	x8, [x8, #48]
	ubfiz	w12, w28, #2, #27
	orr	w12, w12, w21
	dup.4s	v2, w12
	and.16b	v2, v0, v2
	ushll.2d	v2, v2, #0
	subs	x12, x11, x8
	cset	w13, hs
	mov	w0, #3071                       ; =0xbff
	movk	w0, #6, lsl #16
	cmp	x12, x0
	csel	w12, wzr, w13, ls
	subs	x13, x8, x11
	cset	w14, hs
	cmp	x13, x0
	csel	w13, wzr, w14, ls
	subs	x14, x10, x8
	cset	w15, hs
	cmp	x14, x0
	csel	w14, wzr, w15, ls
	subs	x15, x8, x10
	cset	w16, hs
	mov	w1, #1535                       ; =0x5ff
	movk	w1, #3, lsl #16
	cmp	x15, x1
	csel	w15, wzr, w16, ls
	subs	x16, x9, x8
	cset	w17, hs
	cmp	x16, x0
	csel	w16, wzr, w17, ls
	subs	x17, x8, x9
	cset	w0, hs
	cmp	x17, x1
	csel	w17, wzr, w0, ls
	orr	w16, w16, w17
	cmp	w16, #1
	b.ne	LBB1_114
; %bb.14:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w12, w12, w13
	cbz	w12, LBB1_114
; %bb.15:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w12, w14, w15
	tbz	w12, #0, LBB1_114
; %bb.16:                               ; %direct.schedule.2.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	sshll.2d	v0, v0, #0
	ldr	q1, [sp, #16]                   ; 16-byte Reload
	and.16b	v0, v0, v1
	xtn.2s	v1, v2
	umull.2d	v1, v1, v8
	fmov	x13, d1
	add	x13, x13, #384
	fmov	x14, d2
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #7
	and.16b	v2, v3, v21
	addv.8h	h2, v2
	fmov	w15, s2
	b	LBB1_18
LBB1_17:                                ; %else169
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x12, x12, #8
	cmp	x12, #384
	b.eq	LBB1_2
LBB1_18:                                ; %direct.true30.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v3, x12
	orr.16b	v5, v3, v0
	add.2d	v3, v5, v1
	fmov	x16, d3
	lsl	x16, x16, #2
	add	x17, x11, x16
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w15, #0, LBB1_68
; %bb.19:                               ; %else
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB1_69
LBB1_20:                                ; %else42
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w0, #2, LBB1_70
LBB1_21:                                ; %else45
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w0, #3, LBB1_71
LBB1_22:                                ; %else48
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w0, #4, LBB1_72
LBB1_23:                                ; %else51
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w0, #5, LBB1_73
LBB1_24:                                ; %else54
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w0, #6, LBB1_74
LBB1_25:                                ; %else57
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #7, LBB1_27
LBB1_26:                                ; %cond.load59
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x17, x17, #28
	ld1.s	{ v3 }[3], [x17]
LBB1_27:                                ; %else60
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmov	w2, s2
	fmov	x0, d5
	add	x17, x13, x0
	lsl	x17, x17, #2
	add	x1, x11, x17
	movi.2d	v6, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w2, #0, LBB1_75
; %bb.28:                               ; %else64
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB1_76
LBB1_29:                                ; %else67
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w2, #2, LBB1_77
LBB1_30:                                ; %else70
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w2, #3, LBB1_78
LBB1_31:                                ; %else73
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w2, #4, LBB1_79
LBB1_32:                                ; %else76
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w2, #5, LBB1_80
LBB1_33:                                ; %else79
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w2, #6, LBB1_81
LBB1_34:                                ; %else82
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #7, LBB1_36
LBB1_35:                                ; %cond.load84
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x1, #28
	ld1.s	{ v5 }[3], [x1]
LBB1_36:                                ; %else85
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmov	w2, s2
	add	x0, x0, x14
	lsl	x0, x0, #2
	add	x1, x10, x0
	movi.2d	v16, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w2, #0, LBB1_82
; %bb.37:                               ; %else89
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB1_83
LBB1_38:                                ; %else92
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w2, #2, LBB1_84
LBB1_39:                                ; %else95
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w2, #3, LBB1_85
LBB1_40:                                ; %else98
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w2, #4, LBB1_86
LBB1_41:                                ; %else101
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w2, #5, LBB1_87
LBB1_42:                                ; %else104
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w2, #6, LBB1_88
LBB1_43:                                ; %else107
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w2, #7, LBB1_89
LBB1_44:                                ; %else110
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmov	w1, s2
	add	x0, x9, x0
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w1, #0, LBB1_90
LBB1_45:                                ; %else114
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB1_91
LBB1_46:                                ; %else117
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w1, #2, LBB1_92
LBB1_47:                                ; %else120
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w1, #3, LBB1_93
LBB1_48:                                ; %else123
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w1, #4, LBB1_94
LBB1_49:                                ; %else126
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w1, #5, LBB1_95
LBB1_50:                                ; %else129
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w1, #6, LBB1_96
LBB1_51:                                ; %else132
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w1, #7, LBB1_97
LBB1_52:                                ; %else135
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmov	w0, s2
	fmul.4s	v19, v4, v16
	fmul.4s	v20, v6, v18
	fsub.4s	v19, v19, v20
	add	x16, x8, x16
	tbnz	w0, #0, LBB1_98
LBB1_53:                                ; %else138
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w0, w0, #0xff
	tbnz	w0, #1, LBB1_99
LBB1_54:                                ; %else140
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w0, #2, LBB1_100
LBB1_55:                                ; %else142
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w0, #3, LBB1_101
LBB1_56:                                ; %else144
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmul.4s	v19, v3, v7
	fmul.4s	v20, v5, v17
	fsub.4s	v19, v19, v20
	tbnz	w0, #4, LBB1_102
LBB1_57:                                ; %else146
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w0, #5, LBB1_103
LBB1_58:                                ; %else148
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w0, #6, LBB1_104
LBB1_59:                                ; %else150
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w0, #7, LBB1_105
LBB1_60:                                ; %else152
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmov	w0, s2
	fmul.4s	v4, v4, v18
	fmul.4s	v6, v6, v16
	fadd.4s	v4, v6, v4
	add	x16, x8, x17
	tbnz	w0, #0, LBB1_106
LBB1_61:                                ; %else155
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w17, w0, #0xff
	tbnz	w17, #1, LBB1_107
LBB1_62:                                ; %else157
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w17, #2, LBB1_108
LBB1_63:                                ; %else159
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w17, #3, LBB1_109
LBB1_64:                                ; %else161
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmul.4s	v3, v3, v17
	fmul.4s	v4, v5, v7
	fadd.4s	v3, v4, v3
	tbnz	w17, #4, LBB1_110
LBB1_65:                                ; %else163
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w17, #5, LBB1_111
LBB1_66:                                ; %else165
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbnz	w17, #6, LBB1_112
LBB1_67:                                ; %else167
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w17, #7, LBB1_17
	b	LBB1_113
LBB1_68:                                ; %cond.load
                                        ;   in Loop: Header=BB1_18 Depth=2
	ldr	s4, [x17]
	and	w0, w15, #0xff
	tbz	w0, #1, LBB1_20
LBB1_69:                                ; %cond.load41
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #4
	ld1.s	{ v4 }[1], [x1]
	tbz	w0, #2, LBB1_21
LBB1_70:                                ; %cond.load44
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #8
	ld1.s	{ v4 }[2], [x1]
	tbz	w0, #3, LBB1_22
LBB1_71:                                ; %cond.load47
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #12
	ld1.s	{ v4 }[3], [x1]
	tbz	w0, #4, LBB1_23
LBB1_72:                                ; %cond.load50
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #16
	ld1.s	{ v3 }[0], [x1]
	tbz	w0, #5, LBB1_24
LBB1_73:                                ; %cond.load53
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #20
	ld1.s	{ v3 }[1], [x1]
	tbz	w0, #6, LBB1_25
LBB1_74:                                ; %cond.load56
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #24
	ld1.s	{ v3 }[2], [x1]
	tbnz	w0, #7, LBB1_26
	b	LBB1_27
LBB1_75:                                ; %cond.load63
                                        ;   in Loop: Header=BB1_18 Depth=2
	ldr	s6, [x1]
	and	w2, w2, #0xff
	tbz	w2, #1, LBB1_29
LBB1_76:                                ; %cond.load66
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #4
	ld1.s	{ v6 }[1], [x3]
	tbz	w2, #2, LBB1_30
LBB1_77:                                ; %cond.load69
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #8
	ld1.s	{ v6 }[2], [x3]
	tbz	w2, #3, LBB1_31
LBB1_78:                                ; %cond.load72
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #12
	ld1.s	{ v6 }[3], [x3]
	tbz	w2, #4, LBB1_32
LBB1_79:                                ; %cond.load75
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #16
	ld1.s	{ v5 }[0], [x3]
	tbz	w2, #5, LBB1_33
LBB1_80:                                ; %cond.load78
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #20
	ld1.s	{ v5 }[1], [x3]
	tbz	w2, #6, LBB1_34
LBB1_81:                                ; %cond.load81
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #24
	ld1.s	{ v5 }[2], [x3]
	tbnz	w2, #7, LBB1_35
	b	LBB1_36
LBB1_82:                                ; %cond.load88
                                        ;   in Loop: Header=BB1_18 Depth=2
	ldr	s16, [x1]
	and	w2, w2, #0xff
	tbz	w2, #1, LBB1_38
LBB1_83:                                ; %cond.load91
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #4
	ld1.s	{ v16 }[1], [x3]
	tbz	w2, #2, LBB1_39
LBB1_84:                                ; %cond.load94
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #8
	ld1.s	{ v16 }[2], [x3]
	tbz	w2, #3, LBB1_40
LBB1_85:                                ; %cond.load97
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #12
	ld1.s	{ v16 }[3], [x3]
	tbz	w2, #4, LBB1_41
LBB1_86:                                ; %cond.load100
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #16
	ld1.s	{ v7 }[0], [x3]
	tbz	w2, #5, LBB1_42
LBB1_87:                                ; %cond.load103
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #20
	ld1.s	{ v7 }[1], [x3]
	tbz	w2, #6, LBB1_43
LBB1_88:                                ; %cond.load106
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #24
	ld1.s	{ v7 }[2], [x3]
	tbz	w2, #7, LBB1_44
LBB1_89:                                ; %cond.load109
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x1, #28
	ld1.s	{ v7 }[3], [x1]
	fmov	w1, s2
	add	x0, x9, x0
	movi.2d	v18, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w1, #0, LBB1_45
LBB1_90:                                ; %cond.load113
                                        ;   in Loop: Header=BB1_18 Depth=2
	ldr	s18, [x0]
	and	w1, w1, #0xff
	tbz	w1, #1, LBB1_46
LBB1_91:                                ; %cond.load116
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #4
	ld1.s	{ v18 }[1], [x2]
	tbz	w1, #2, LBB1_47
LBB1_92:                                ; %cond.load119
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #8
	ld1.s	{ v18 }[2], [x2]
	tbz	w1, #3, LBB1_48
LBB1_93:                                ; %cond.load122
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #12
	ld1.s	{ v18 }[3], [x2]
	tbz	w1, #4, LBB1_49
LBB1_94:                                ; %cond.load125
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #16
	ld1.s	{ v17 }[0], [x2]
	tbz	w1, #5, LBB1_50
LBB1_95:                                ; %cond.load128
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #20
	ld1.s	{ v17 }[1], [x2]
	tbz	w1, #6, LBB1_51
LBB1_96:                                ; %cond.load131
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #24
	ld1.s	{ v17 }[2], [x2]
	tbz	w1, #7, LBB1_52
LBB1_97:                                ; %cond.load134
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x0, #28
	ld1.s	{ v17 }[3], [x0]
	fmov	w0, s2
	fmul.4s	v19, v4, v16
	fmul.4s	v20, v6, v18
	fsub.4s	v19, v19, v20
	add	x16, x8, x16
	tbz	w0, #0, LBB1_53
LBB1_98:                                ; %cond.store
                                        ;   in Loop: Header=BB1_18 Depth=2
	str	s19, [x16]
	and	w0, w0, #0xff
	tbz	w0, #1, LBB1_54
LBB1_99:                                ; %cond.store139
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x16, #4
	st1.s	{ v19 }[1], [x1]
	tbz	w0, #2, LBB1_55
LBB1_100:                               ; %cond.store141
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x16, #8
	st1.s	{ v19 }[2], [x1]
	tbz	w0, #3, LBB1_56
LBB1_101:                               ; %cond.store143
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x16, #12
	st1.s	{ v19 }[3], [x1]
	fmul.4s	v19, v3, v7
	fmul.4s	v20, v5, v17
	fsub.4s	v19, v19, v20
	tbz	w0, #4, LBB1_57
LBB1_102:                               ; %cond.store145
                                        ;   in Loop: Header=BB1_18 Depth=2
	str	s19, [x16, #16]
	tbz	w0, #5, LBB1_58
LBB1_103:                               ; %cond.store147
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x16, #20
	st1.s	{ v19 }[1], [x1]
	tbz	w0, #6, LBB1_59
LBB1_104:                               ; %cond.store149
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x16, #24
	st1.s	{ v19 }[2], [x1]
	tbz	w0, #7, LBB1_60
LBB1_105:                               ; %cond.store151
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x16, x16, #28
	st1.s	{ v19 }[3], [x16]
	fmov	w0, s2
	fmul.4s	v4, v4, v18
	fmul.4s	v6, v6, v16
	fadd.4s	v4, v6, v4
	add	x16, x8, x17
	tbz	w0, #0, LBB1_61
LBB1_106:                               ; %cond.store154
                                        ;   in Loop: Header=BB1_18 Depth=2
	str	s4, [x16]
	and	w17, w0, #0xff
	tbz	w17, #1, LBB1_62
LBB1_107:                               ; %cond.store156
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x16, #4
	st1.s	{ v4 }[1], [x0]
	tbz	w17, #2, LBB1_63
LBB1_108:                               ; %cond.store158
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x16, #8
	st1.s	{ v4 }[2], [x0]
	tbz	w17, #3, LBB1_64
LBB1_109:                               ; %cond.store160
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x16, #12
	st1.s	{ v4 }[3], [x0]
	fmul.4s	v3, v3, v17
	fmul.4s	v4, v5, v7
	fadd.4s	v3, v4, v3
	tbz	w17, #4, LBB1_65
LBB1_110:                               ; %cond.store162
                                        ;   in Loop: Header=BB1_18 Depth=2
	str	s3, [x16, #16]
	tbz	w17, #5, LBB1_66
LBB1_111:                               ; %cond.store164
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x16, #20
	st1.s	{ v3 }[1], [x0]
	tbz	w17, #6, LBB1_67
LBB1_112:                               ; %cond.store166
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x16, #24
	st1.s	{ v3 }[2], [x0]
	tbz	w17, #7, LBB1_17
LBB1_113:                               ; %cond.store168
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x16, x16, #28
	st1.s	{ v3 }[3], [x16]
	b	LBB1_17
LBB1_114:                               ; %direct.schedule.6.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x14, #0                         ; =0x0
	fmov	x12, d2
	add	x13, x12, x12, lsl #1
	lsl	x12, x13, #10
	add	x15, x11, x12
	b	LBB1_116
LBB1_115:                               ; %else193
                                        ;   in Loop: Header=BB1_116 Depth=2
	add	x16, x2, x14
	stp	q4, q5, [x16]
	add	x14, x14, #32
	cmp	x14, #1536
	b.eq	LBB1_132
LBB1_116:                               ; %direct.true46.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and.16b	v2, v3, v21
	addv.8h	h2, v2
	fmov	w17, s2
	add	x16, x15, x14
	add	x0, x2, x14
	ldr	q4, [x0]
	tbnz	w17, #0, LBB1_124
; %bb.117:                              ; %else172
                                        ;   in Loop: Header=BB1_116 Depth=2
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_125
LBB1_118:                               ; %else175
                                        ;   in Loop: Header=BB1_116 Depth=2
	tbnz	w17, #2, LBB1_126
LBB1_119:                               ; %else178
                                        ;   in Loop: Header=BB1_116 Depth=2
	tbnz	w17, #3, LBB1_127
LBB1_120:                               ; %else181
                                        ;   in Loop: Header=BB1_116 Depth=2
	ldr	q5, [x0, #16]
	tbnz	w17, #4, LBB1_128
LBB1_121:                               ; %else184
                                        ;   in Loop: Header=BB1_116 Depth=2
	tbnz	w17, #5, LBB1_129
LBB1_122:                               ; %else187
                                        ;   in Loop: Header=BB1_116 Depth=2
	tbnz	w17, #6, LBB1_130
LBB1_123:                               ; %else190
                                        ;   in Loop: Header=BB1_116 Depth=2
	tbz	w17, #7, LBB1_115
	b	LBB1_131
LBB1_124:                               ; %cond.load171
                                        ;   in Loop: Header=BB1_116 Depth=2
	ld1.s	{ v4 }[0], [x16]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_118
LBB1_125:                               ; %cond.load174
                                        ;   in Loop: Header=BB1_116 Depth=2
	add	x1, x16, #4
	ld1.s	{ v4 }[1], [x1]
	tbz	w17, #2, LBB1_119
LBB1_126:                               ; %cond.load177
                                        ;   in Loop: Header=BB1_116 Depth=2
	add	x1, x16, #8
	ld1.s	{ v4 }[2], [x1]
	tbz	w17, #3, LBB1_120
LBB1_127:                               ; %cond.load180
                                        ;   in Loop: Header=BB1_116 Depth=2
	add	x1, x16, #12
	ld1.s	{ v4 }[3], [x1]
	ldr	q5, [x0, #16]
	tbz	w17, #4, LBB1_121
LBB1_128:                               ; %cond.load183
                                        ;   in Loop: Header=BB1_116 Depth=2
	add	x0, x16, #16
	ld1.s	{ v5 }[0], [x0]
	tbz	w17, #5, LBB1_122
LBB1_129:                               ; %cond.load186
                                        ;   in Loop: Header=BB1_116 Depth=2
	add	x0, x16, #20
	ld1.s	{ v5 }[1], [x0]
	tbz	w17, #6, LBB1_123
LBB1_130:                               ; %cond.load189
                                        ;   in Loop: Header=BB1_116 Depth=2
	add	x0, x16, #24
	ld1.s	{ v5 }[2], [x0]
	tbz	w17, #7, LBB1_115
LBB1_131:                               ; %cond.load192
                                        ;   in Loop: Header=BB1_116 Depth=2
	add	x16, x16, #28
	ld1.s	{ v5 }[3], [x16]
	b	LBB1_115
LBB1_132:                               ; %direct.true60.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x14, #0                         ; =0x0
	add	x11, x11, x12
	add	x11, x11, #1536
	b	LBB1_134
LBB1_133:                               ; %else218
                                        ;   in Loop: Header=BB1_134 Depth=2
	add	x15, x3, x14
	stp	q3, q4, [x15]
	add	x14, x14, #32
	cmp	x14, #1536
	b.eq	LBB1_150
LBB1_134:                               ; %direct.true60.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s2
	add	x15, x11, x14
	add	x17, x3, x14
	ldr	q3, [x17]
	tbnz	w16, #0, LBB1_142
; %bb.135:                              ; %else197
                                        ;   in Loop: Header=BB1_134 Depth=2
	and	w16, w16, #0xff
	ldr	q4, [x17, #16]
	tbnz	w16, #1, LBB1_143
LBB1_136:                               ; %else200
                                        ;   in Loop: Header=BB1_134 Depth=2
	tbnz	w16, #2, LBB1_144
LBB1_137:                               ; %else203
                                        ;   in Loop: Header=BB1_134 Depth=2
	tbnz	w16, #3, LBB1_145
LBB1_138:                               ; %else206
                                        ;   in Loop: Header=BB1_134 Depth=2
	tbnz	w16, #4, LBB1_146
LBB1_139:                               ; %else209
                                        ;   in Loop: Header=BB1_134 Depth=2
	tbnz	w16, #5, LBB1_147
LBB1_140:                               ; %else212
                                        ;   in Loop: Header=BB1_134 Depth=2
	tbnz	w16, #6, LBB1_148
LBB1_141:                               ; %else215
                                        ;   in Loop: Header=BB1_134 Depth=2
	tbz	w16, #7, LBB1_133
	b	LBB1_149
LBB1_142:                               ; %cond.load196
                                        ;   in Loop: Header=BB1_134 Depth=2
	ld1.s	{ v3 }[0], [x15]
	and	w16, w16, #0xff
	ldr	q4, [x17, #16]
	tbz	w16, #1, LBB1_136
LBB1_143:                               ; %cond.load199
                                        ;   in Loop: Header=BB1_134 Depth=2
	add	x17, x15, #4
	ld1.s	{ v3 }[1], [x17]
	tbz	w16, #2, LBB1_137
LBB1_144:                               ; %cond.load202
                                        ;   in Loop: Header=BB1_134 Depth=2
	add	x17, x15, #8
	ld1.s	{ v3 }[2], [x17]
	tbz	w16, #3, LBB1_138
LBB1_145:                               ; %cond.load205
                                        ;   in Loop: Header=BB1_134 Depth=2
	add	x17, x15, #12
	ld1.s	{ v3 }[3], [x17]
	tbz	w16, #4, LBB1_139
LBB1_146:                               ; %cond.load208
                                        ;   in Loop: Header=BB1_134 Depth=2
	add	x17, x15, #16
	ld1.s	{ v4 }[0], [x17]
	tbz	w16, #5, LBB1_140
LBB1_147:                               ; %cond.load211
                                        ;   in Loop: Header=BB1_134 Depth=2
	add	x17, x15, #20
	ld1.s	{ v4 }[1], [x17]
	tbz	w16, #6, LBB1_141
LBB1_148:                               ; %cond.load214
                                        ;   in Loop: Header=BB1_134 Depth=2
	add	x17, x15, #24
	ld1.s	{ v4 }[2], [x17]
	tbz	w16, #7, LBB1_133
LBB1_149:                               ; %cond.load217
                                        ;   in Loop: Header=BB1_134 Depth=2
	add	x15, x15, #28
	ld1.s	{ v4 }[3], [x15]
	b	LBB1_133
LBB1_150:                               ; %direct.schedule.12.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x14, #0                         ; =0x0
	lsl	x11, x13, #9
	add	x10, x10, x11
	b	LBB1_152
LBB1_151:                               ; %else243
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x13, x23, x14
	stp	q3, q4, [x13]
	add	x14, x14, #32
	cmp	x14, #1536
	b.eq	LBB1_168
LBB1_152:                               ; %direct.true77.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w15, s2
	add	x13, x10, x14
	add	x16, x23, x14
	ldp	q3, q4, [x16]
	tbnz	w15, #0, LBB1_160
; %bb.153:                              ; %else222
                                        ;   in Loop: Header=BB1_152 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_161
LBB1_154:                               ; %else225
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbnz	w15, #2, LBB1_162
LBB1_155:                               ; %else228
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbnz	w15, #3, LBB1_163
LBB1_156:                               ; %else231
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbnz	w15, #4, LBB1_164
LBB1_157:                               ; %else234
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbnz	w15, #5, LBB1_165
LBB1_158:                               ; %else237
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbnz	w15, #6, LBB1_166
LBB1_159:                               ; %else240
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbz	w15, #7, LBB1_151
	b	LBB1_167
LBB1_160:                               ; %cond.load221
                                        ;   in Loop: Header=BB1_152 Depth=2
	ld1.s	{ v3 }[0], [x13]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_154
LBB1_161:                               ; %cond.load224
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x16, x13, #4
	ld1.s	{ v3 }[1], [x16]
	tbz	w15, #2, LBB1_155
LBB1_162:                               ; %cond.load227
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x16, x13, #8
	ld1.s	{ v3 }[2], [x16]
	tbz	w15, #3, LBB1_156
LBB1_163:                               ; %cond.load230
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x16, x13, #12
	ld1.s	{ v3 }[3], [x16]
	tbz	w15, #4, LBB1_157
LBB1_164:                               ; %cond.load233
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x16, x13, #16
	ld1.s	{ v4 }[0], [x16]
	tbz	w15, #5, LBB1_158
LBB1_165:                               ; %cond.load236
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x16, x13, #20
	ld1.s	{ v4 }[1], [x16]
	tbz	w15, #6, LBB1_159
LBB1_166:                               ; %cond.load239
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x16, x13, #24
	ld1.s	{ v4 }[2], [x16]
	tbz	w15, #7, LBB1_151
LBB1_167:                               ; %cond.load242
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x13, x13, #28
	ld1.s	{ v4 }[3], [x13]
	b	LBB1_151
LBB1_168:                               ; %direct.schedule.15.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	add	x9, x9, x11
	b	LBB1_170
LBB1_169:                               ; %else268
                                        ;   in Loop: Header=BB1_170 Depth=2
	add	x11, x24, x10
	stp	q3, q4, [x11]
	add	x10, x10, #32
	cmp	x10, #1536
	b.eq	LBB1_186
LBB1_170:                               ; %direct.true94.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s2
	add	x11, x9, x10
	add	x14, x24, x10
	ldp	q3, q4, [x14]
	tbnz	w13, #0, LBB1_178
; %bb.171:                              ; %else247
                                        ;   in Loop: Header=BB1_170 Depth=2
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_179
LBB1_172:                               ; %else250
                                        ;   in Loop: Header=BB1_170 Depth=2
	tbnz	w13, #2, LBB1_180
LBB1_173:                               ; %else253
                                        ;   in Loop: Header=BB1_170 Depth=2
	tbnz	w13, #3, LBB1_181
LBB1_174:                               ; %else256
                                        ;   in Loop: Header=BB1_170 Depth=2
	tbnz	w13, #4, LBB1_182
LBB1_175:                               ; %else259
                                        ;   in Loop: Header=BB1_170 Depth=2
	tbnz	w13, #5, LBB1_183
LBB1_176:                               ; %else262
                                        ;   in Loop: Header=BB1_170 Depth=2
	tbnz	w13, #6, LBB1_184
LBB1_177:                               ; %else265
                                        ;   in Loop: Header=BB1_170 Depth=2
	tbz	w13, #7, LBB1_169
	b	LBB1_185
LBB1_178:                               ; %cond.load246
                                        ;   in Loop: Header=BB1_170 Depth=2
	ld1.s	{ v3 }[0], [x11]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_172
LBB1_179:                               ; %cond.load249
                                        ;   in Loop: Header=BB1_170 Depth=2
	add	x14, x11, #4
	ld1.s	{ v3 }[1], [x14]
	tbz	w13, #2, LBB1_173
LBB1_180:                               ; %cond.load252
                                        ;   in Loop: Header=BB1_170 Depth=2
	add	x14, x11, #8
	ld1.s	{ v3 }[2], [x14]
	tbz	w13, #3, LBB1_174
LBB1_181:                               ; %cond.load255
                                        ;   in Loop: Header=BB1_170 Depth=2
	add	x14, x11, #12
	ld1.s	{ v3 }[3], [x14]
	tbz	w13, #4, LBB1_175
LBB1_182:                               ; %cond.load258
                                        ;   in Loop: Header=BB1_170 Depth=2
	add	x14, x11, #16
	ld1.s	{ v4 }[0], [x14]
	tbz	w13, #5, LBB1_176
LBB1_183:                               ; %cond.load261
                                        ;   in Loop: Header=BB1_170 Depth=2
	add	x14, x11, #20
	ld1.s	{ v4 }[1], [x14]
	tbz	w13, #6, LBB1_177
LBB1_184:                               ; %cond.load264
                                        ;   in Loop: Header=BB1_170 Depth=2
	add	x14, x11, #24
	ld1.s	{ v4 }[2], [x14]
	tbz	w13, #7, LBB1_169
LBB1_185:                               ; %cond.load267
                                        ;   in Loop: Header=BB1_170 Depth=2
	add	x11, x11, #28
	ld1.s	{ v4 }[3], [x11]
	b	LBB1_169
LBB1_186:                               ; %direct.schedule.18.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	add	x10, x8, x12
	b	LBB1_188
LBB1_187:                               ; %else286
                                        ;   in Loop: Header=BB1_188 Depth=2
	add	x9, x9, #32
	cmp	x9, #1536
	b.eq	LBB1_204
LBB1_188:                               ; %direct.true111.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s2
	add	x11, x2, x9
	ldp	q5, q3, [x11]
	add	x11, x23, x9
	ldp	q6, q4, [x11]
	fmul.4s	v7, v5, v6
	add	x11, x3, x9
	ldp	q16, q5, [x11]
	add	x11, x24, x9
	ldp	q17, q6, [x11]
	fmul.4s	v16, v16, v17
	fsub.4s	v7, v7, v16
	and.16b	v7, v0, v7
	add	x11, x10, x9
	tbnz	w13, #0, LBB1_196
; %bb.189:                              ; %else272
                                        ;   in Loop: Header=BB1_188 Depth=2
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_197
LBB1_190:                               ; %else274
                                        ;   in Loop: Header=BB1_188 Depth=2
	tbnz	w13, #2, LBB1_198
LBB1_191:                               ; %else276
                                        ;   in Loop: Header=BB1_188 Depth=2
	tbnz	w13, #3, LBB1_199
LBB1_192:                               ; %else278
                                        ;   in Loop: Header=BB1_188 Depth=2
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fsub.4s	v3, v3, v4
	and.16b	v3, v1, v3
	tbnz	w13, #4, LBB1_200
LBB1_193:                               ; %else280
                                        ;   in Loop: Header=BB1_188 Depth=2
	tbnz	w13, #5, LBB1_201
LBB1_194:                               ; %else282
                                        ;   in Loop: Header=BB1_188 Depth=2
	tbnz	w13, #6, LBB1_202
LBB1_195:                               ; %else284
                                        ;   in Loop: Header=BB1_188 Depth=2
	tbz	w13, #7, LBB1_187
	b	LBB1_203
LBB1_196:                               ; %cond.store271
                                        ;   in Loop: Header=BB1_188 Depth=2
	str	s7, [x11]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_190
LBB1_197:                               ; %cond.store273
                                        ;   in Loop: Header=BB1_188 Depth=2
	add	x14, x11, #4
	st1.s	{ v7 }[1], [x14]
	tbz	w13, #2, LBB1_191
LBB1_198:                               ; %cond.store275
                                        ;   in Loop: Header=BB1_188 Depth=2
	add	x14, x11, #8
	st1.s	{ v7 }[2], [x14]
	tbz	w13, #3, LBB1_192
LBB1_199:                               ; %cond.store277
                                        ;   in Loop: Header=BB1_188 Depth=2
	add	x14, x11, #12
	st1.s	{ v7 }[3], [x14]
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fsub.4s	v3, v3, v4
	and.16b	v3, v1, v3
	tbz	w13, #4, LBB1_193
LBB1_200:                               ; %cond.store279
                                        ;   in Loop: Header=BB1_188 Depth=2
	str	s3, [x11, #16]
	tbz	w13, #5, LBB1_194
LBB1_201:                               ; %cond.store281
                                        ;   in Loop: Header=BB1_188 Depth=2
	add	x14, x11, #20
	st1.s	{ v3 }[1], [x14]
	tbz	w13, #6, LBB1_195
LBB1_202:                               ; %cond.store283
                                        ;   in Loop: Header=BB1_188 Depth=2
	add	x14, x11, #24
	st1.s	{ v3 }[2], [x14]
	tbz	w13, #7, LBB1_187
LBB1_203:                               ; %cond.store285
                                        ;   in Loop: Header=BB1_188 Depth=2
	add	x11, x11, #28
	st1.s	{ v3 }[3], [x11]
	b	LBB1_187
LBB1_204:                               ; %direct.true144.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	add	x8, x8, x12
	add	x8, x8, #1536
	b	LBB1_206
LBB1_205:                               ; %else303
                                        ;   in Loop: Header=BB1_206 Depth=2
	add	x9, x9, #32
	cmp	x9, #1536
	b.eq	LBB1_2
LBB1_206:                               ; %direct.true144.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s2
	add	x10, x2, x9
	ldp	q5, q3, [x10]
	add	x10, x24, x9
	ldp	q6, q4, [x10]
	fmul.4s	v7, v5, v6
	add	x10, x3, x9
	ldp	q16, q5, [x10]
	add	x10, x23, x9
	ldp	q17, q6, [x10]
	fmul.4s	v16, v16, v17
	fadd.4s	v7, v7, v16
	and.16b	v7, v0, v7
	add	x10, x8, x9
	tbnz	w11, #0, LBB1_214
; %bb.207:                              ; %else289
                                        ;   in Loop: Header=BB1_206 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_215
LBB1_208:                               ; %else291
                                        ;   in Loop: Header=BB1_206 Depth=2
	tbnz	w11, #2, LBB1_216
LBB1_209:                               ; %else293
                                        ;   in Loop: Header=BB1_206 Depth=2
	tbnz	w11, #3, LBB1_217
LBB1_210:                               ; %else295
                                        ;   in Loop: Header=BB1_206 Depth=2
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fadd.4s	v3, v3, v4
	and.16b	v3, v1, v3
	tbnz	w11, #4, LBB1_218
LBB1_211:                               ; %else297
                                        ;   in Loop: Header=BB1_206 Depth=2
	tbnz	w11, #5, LBB1_219
LBB1_212:                               ; %else299
                                        ;   in Loop: Header=BB1_206 Depth=2
	tbnz	w11, #6, LBB1_220
LBB1_213:                               ; %else301
                                        ;   in Loop: Header=BB1_206 Depth=2
	tbz	w11, #7, LBB1_205
	b	LBB1_221
LBB1_214:                               ; %cond.store288
                                        ;   in Loop: Header=BB1_206 Depth=2
	str	s7, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_208
LBB1_215:                               ; %cond.store290
                                        ;   in Loop: Header=BB1_206 Depth=2
	add	x12, x10, #4
	st1.s	{ v7 }[1], [x12]
	tbz	w11, #2, LBB1_209
LBB1_216:                               ; %cond.store292
                                        ;   in Loop: Header=BB1_206 Depth=2
	add	x12, x10, #8
	st1.s	{ v7 }[2], [x12]
	tbz	w11, #3, LBB1_210
LBB1_217:                               ; %cond.store294
                                        ;   in Loop: Header=BB1_206 Depth=2
	add	x12, x10, #12
	st1.s	{ v7 }[3], [x12]
	fmul.4s	v3, v3, v4
	fmul.4s	v4, v5, v6
	fadd.4s	v3, v3, v4
	and.16b	v3, v1, v3
	tbz	w11, #4, LBB1_211
LBB1_218:                               ; %cond.store296
                                        ;   in Loop: Header=BB1_206 Depth=2
	str	s3, [x10, #16]
	tbz	w11, #5, LBB1_212
LBB1_219:                               ; %cond.store298
                                        ;   in Loop: Header=BB1_206 Depth=2
	add	x12, x10, #20
	st1.s	{ v3 }[1], [x12]
	tbz	w11, #6, LBB1_213
LBB1_220:                               ; %cond.store300
                                        ;   in Loop: Header=BB1_206 Depth=2
	add	x12, x10, #24
	st1.s	{ v3 }[2], [x12]
	tbz	w11, #7, LBB1_205
LBB1_221:                               ; %cond.store302
                                        ;   in Loop: Header=BB1_206 Depth=2
	add	x10, x10, #28
	st1.s	{ v3 }[3], [x10]
	b	LBB1_205
LBB1_222:                               ; %block.batch.exit
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2176
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #112              ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.full_packet
lCPI0_0:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_1:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_2:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_3:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_4:
	.quad	0                               ; 0x0
	.quad	513                             ; 0x201
lCPI0_5:
	.quad	1026                            ; 0x402
	.quad	1539                            ; 0x603
lCPI0_6:
	.quad	2052                            ; 0x804
	.quad	2565                            ; 0xa05
lCPI0_7:
	.quad	3078                            ; 0xc06
	.quad	3591                            ; 0xe07
lCPI0_8:
	.quad	3590                            ; 0xe06
	.quad	4103                            ; 0x1007
lCPI0_9:
	.quad	2564                            ; 0xa04
	.quad	3077                            ; 0xc05
lCPI0_10:
	.quad	1538                            ; 0x602
	.quad	2051                            ; 0x803
lCPI0_11:
	.quad	512                             ; 0x200
	.quad	1025                            ; 0x401
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	sub	sp, sp, #128
	stp	d15, d14, [sp, #16]             ; 16-byte Folded Spill
	stp	d13, d12, [sp, #32]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #48]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #64]               ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	mov	x11, #0                         ; =0x0
	ldr	x8, [x1, #136]
	mov	w9, #20616                      ; =0x5088
	movk	w9, #1, lsl #16
	add	x10, x8, #17, lsl #12           ; =69632
	add	x13, x10, #104
	mov	w10, #53352                     ; =0xd068
	add	x14, x8, x10
	ldr	x16, [x0]
	ldr	w10, [x1]
	ldr	w12, [x1, #36]
	add	w10, w12, w10, lsl #5
	lsr	w10, w10, #3
	dup.4s	v0, w10
	ushll.2d	v1, v0, #0
	fmov	x10, d1
	mov	w12, #16388                     ; =0x4004
	umaddl	x12, w10, w12, x16
	mov	w15, #49184                     ; =0xc020
	ldr	x10, [x0, #48]
LBB0_1:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x12, x11
	ldp	q2, q3, [x17]
	add	x17, x8, x11
	stp	q2, q3, [x17]
	add	x11, x11, #32
	cmp	x11, #4, lsl #12                ; =16384
	b.ne	LBB0_1
; %bb.2:                                ; %direct.false
	mov	x17, #0                         ; =0x0
	fmov	x11, d1
	add	x11, x11, x11, lsl #12
	lsl	x12, x11, #2
	add	x11, x12, #4, lsl #12           ; =16384
	ldr	s1, [x16, x11]
	mov	w16, #16384                     ; =0x4000
	str	s1, [x8, x16]
Lloh0:
	adrp	x16, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x16, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x16, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x16, lCPI0_1@PAGEOFF]
Lloh4:
	adrp	x16, lCPI0_2@PAGE
Lloh5:
	ldr	q3, [x16, lCPI0_2@PAGEOFF]
Lloh6:
	adrp	x16, lCPI0_3@PAGE
Lloh7:
	ldr	q4, [x16, lCPI0_3@PAGEOFF]
	mov	w16, #1                         ; =0x1
	dup.2d	v5, x16
	mov	w16, #16416                     ; =0x4020
	add	x16, x8, x16
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB0_3:                                 ; %direct.true73
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v18, v6, #3
	shl.2d	v19, v7, #3
	shl.2d	v20, v16, #3
	shl.2d	v21, v17, #3
	orr.16b	v21, v21, v1
	orr.16b	v20, v20, v2
	orr.16b	v19, v19, v3
	orr.16b	v18, v18, v4
	add	x17, x16, x17, lsl #6
	stp	q18, q19, [x17]
	stp	q20, q21, [x17, #32]
	add.2d	v16, v16, v5
	add.2d	v7, v7, v5
	add.2d	v17, v17, v5
	add.2d	v6, v6, v5
	fmov	x17, d6
	cmp	x17, #512
	b.lt	LBB0_3
; %bb.4:                                ; %direct.false74
	mov	x17, #0                         ; =0x0
	mov	w0, #4096                       ; =0x1000
	str	x0, [x8, x15]
	mov	w0, #61441                      ; =0xf001
	movk	w0, #255, lsl #16
	dup.4s	v1, w0
	mov	w0, #4097                       ; =0x1001
	dup.4s	v2, w0
	mov	w0, #49248                      ; =0xc060
	add	x0, x8, x0
	umull2.2d	v3, v0, v1
	umull.2d	v4, v0, v1
	uzp2.4s	v4, v4, v3
	ushr.4s	v4, v4, #4
	mov.16b	v6, v0
	mls.4s	v6, v4, v2
	umull.2d	v1, v0, v1
	uzp2.4s	v1, v1, v3
	ushr.4s	v1, v1, #4
	mls.4s	v0, v1, v2
	ushll2.2d	v5, v0, #0
	ushll2.2d	v7, v6, #0
	ushll.2d	v16, v0, #0
	ushll.2d	v6, v6, #0
	movi.2d	v17, #0000000000000000
	dup.2d	v0, x0
Lloh8:
	adrp	x0, lCPI0_4@PAGE
Lloh9:
	ldr	q1, [x0, lCPI0_4@PAGEOFF]
Lloh10:
	adrp	x0, lCPI0_5@PAGE
Lloh11:
	ldr	q2, [x0, lCPI0_5@PAGEOFF]
Lloh12:
	adrp	x0, lCPI0_6@PAGE
Lloh13:
	ldr	q3, [x0, lCPI0_6@PAGEOFF]
Lloh14:
	adrp	x0, lCPI0_7@PAGE
Lloh15:
	ldr	q4, [x0, lCPI0_7@PAGEOFF]
	movi.8b	v18, #1
	mov	w0, #1                          ; =0x1
	dup.2d	v19, x0
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
LBB0_5:                                 ; %direct.true89
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x16, x17, lsl #6
	ldp	q24, q23, [x17, #32]
	ldp	q25, q26, [x17]
	add.2d	v27, v22, v4
	add.2d	v27, v27, v0
	add.2d	v28, v21, v3
	add.2d	v29, v20, v2
	add.2d	v30, v17, v1
	add.2d	v30, v30, v0
	cmge.2d	v26, v7, v26
	cmge.2d	v25, v6, v25
	uzp1.4s	v25, v25, v26
	cmge.2d	v24, v16, v24
	cmge.2d	v23, v5, v23
	uzp1.4s	v23, v24, v23
	uzp1.8h	v23, v25, v23
	xtn.8b	v23, v23
	and.8b	v23, v23, v18
	mov.d	x17, v30[1]
	fmov	x0, d30
	str	b23, [x0]
	st1.b	{ v23 }[1], [x17]
	add.2d	v24, v29, v0
	mov.d	x17, v24[1]
	fmov	x0, d24
	st1.b	{ v23 }[2], [x0]
	add.2d	v24, v28, v0
	st1.b	{ v23 }[3], [x17]
	mov.d	x17, v24[1]
	fmov	x0, d24
	st1.b	{ v23 }[4], [x0]
	st1.b	{ v23 }[5], [x17]
	mov.d	x17, v27[1]
	fmov	x0, d27
	st1.b	{ v23 }[6], [x0]
	st1.b	{ v23 }[7], [x17]
	add.2d	v21, v21, v19
	add.2d	v20, v20, v19
	add.2d	v22, v22, v19
	add.2d	v17, v17, v19
	fmov	x17, d17
	cmp	x17, #512
	b.lt	LBB0_5
; %bb.6:                                ; %direct.false90
	mov	x16, #0                         ; =0x0
	ldr	d7, [x8, x15]
Lloh16:
	adrp	x15, lCPI0_11@PAGE
Lloh17:
	ldr	q5, [x15, lCPI0_11@PAGEOFF]
	add.2d	v5, v0, v5
	cmge.2d	v6, v6, v7
	xtn.2s	v6, v6
	uzp1.4h	v6, v6, v0
	uzp1.8b	v6, v6, v0
	movi.8b	v7, #1
	and.8b	v6, v6, v7
	fmov	x15, d5
	str	b6, [x15]
	mov	w15, #62154                     ; =0xf2ca
	movk	w15, #61769, lsl #16
	dup.4s	v6, w15
	mov	w15, #1                         ; =0x1
	dup.2d	v7, x15
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
LBB0_7:                                 ; %direct.true105
                                        ; =>This Inner Loop Header: Depth=1
	add.2d	v20, v19, v4
	add.2d	v20, v20, v0
	add.2d	v21, v18, v3
	add.2d	v21, v21, v0
	add.2d	v22, v17, v2
	add.2d	v22, v22, v0
	add.2d	v23, v16, v1
	add.2d	v23, v23, v0
	mov.d	x15, v23[1]
	mov.d	x17, v22[1]
	fmov	x0, d23
	fmov	x1, d22
	mov.d	x2, v21[1]
	fmov	x3, d21
	ldr	b21, [x0]
	ld1.b	{ v21 }[1], [x15]
	ld1.b	{ v21 }[2], [x1]
	mov.d	x15, v20[1]
	ld1.b	{ v21 }[3], [x17]
	ld1.b	{ v21 }[4], [x3]
	ld1.b	{ v21 }[5], [x2]
	fmov	x17, d20
	ld1.b	{ v21 }[6], [x17]
	ld1.b	{ v21 }[7], [x15]
	cmeq.8b	v20, v21, #0
	sshll.8h	v20, v20, #0
	sshll2.4s	v21, v20, #0
	lsl	x15, x16, #5
	add	x16, x8, x15
	ldp	q23, q22, [x16]
	sshll.4s	v20, v20, #0
	bsl.16b	v20, v6, v23
	bsl.16b	v21, v6, v22
	add	x15, x14, x15
	stp	q20, q21, [x15]
	add.2d	v18, v18, v7
	add.2d	v17, v17, v7
	add.2d	v19, v19, v7
	add.2d	v16, v16, v7
	fmov	x16, d16
	cmp	x16, #512
	b.lt	LBB0_7
; %bb.8:                                ; %direct.false106
	mov	x15, #0                         ; =0x0
	str	q5, [sp]                        ; 16-byte Spill
	fmov	x16, d5
	ldr	b6, [x16]
	cmeq.8b	v6, v6, #0
	sshll.8h	v6, v6, #0
	sshll.4s	v6, v6, #0
	ldr	q7, [x8, #16384]
	mov	w16, #62154                     ; =0xf2ca
	movk	w16, #61769, lsl #16
	fmov	s16, w16
	bsl.16b	v6, v16, v7
	ldr	q7, [x13]
	mov.s	v7[0], v6[0]
	str	q7, [x13]
	ldp	q7, q16, [x14]
	ldp	q20, q21, [x14, #32]
	ldp	q22, q17, [x14, #64]
	ldp	q18, q19, [x14, #96]
	mov	w16, #53544                     ; =0xd128
	add	x16, x8, x16
LBB0_9:                                 ; %direct.true139
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x16, x15, lsl #5
	ldp	q23, q24, [x17, #-64]
	fmaxnm.4s	v16, v16, v24
	fmaxnm.4s	v7, v7, v23
	ldp	q23, q24, [x17, #-32]
	fmaxnm.4s	v21, v21, v24
	fmaxnm.4s	v20, v20, v23
	ldp	q23, q24, [x17]
	fmaxnm.4s	v17, v17, v24
	fmaxnm.4s	v22, v22, v23
	ldp	q23, q24, [x17, #32]
	fmaxnm.4s	v19, v19, v24
	fmaxnm.4s	v18, v18, v23
	add	x15, x15, #4
	cmp	x15, #508
	b.lo	LBB0_9
; %bb.10:                               ; %direct.false140
	mov	x5, #0                          ; =0x0
	add	x15, x13, #32
	movi.2d	v23, #0000000000000000
	mov.s	v23[0], v6[0]
	movi.2d	v6, #0000000000000000
	fmaxnm.4s	v23, v7, v23
	mov.s	v7[0], v23[0]
	fmaxnm.4s	v16, v16, v21
	fmaxnm.4s	v7, v7, v20
	fmaxnm.4s	v7, v7, v22
	fmaxnm.4s	v16, v16, v17
	fmaxnm.4s	v16, v16, v19
	fmaxnm.4s	v7, v7, v18
	rev64.4s	v17, v7
	rev64.4s	v18, v16
	fmaxnm.4s	v16, v16, v18
	fmaxnm.4s	v7, v7, v17
	ext.16b	v17, v7, v7, #8
	ext.16b	v18, v16, v16, #8
	fmaxnm.4s	v16, v16, v18
	fmaxnm.4s	v7, v7, v17
	fmaxnm.4s	v7, v7, v16
	mov	w16, #-8388608                  ; =0xff800000
	fmov	s16, w16
	fmaxnm	s7, s7, s16
	dup.4s	v7, v7[0]
	mov	w16, #-1026555904               ; =0xc2d00000
	dup.4s	v16, w16
	mov	w16, #1120403456                ; =0x42c80000
	dup.4s	v17, w16
	mov	w16, #43579                     ; =0xaa3b
	movk	w16, #16312, lsl #16
	dup.4s	v18, w16
	mvni.4s	v20, #128, lsl #24
	mov	w16, #29184                     ; =0x7200
	movk	w16, #48945, lsl #16
	dup.4s	v21, w16
	mov	w16, #48782                     ; =0xbe8e
	movk	w16, #46527, lsl #16
	mov	w17, #11226                     ; =0x2bda
	movk	w17, #14672, lsl #16
	mov	w0, #38601                      ; =0x96c9
	movk	w0, #15030, lsl #16
	mov	w1, #34982                      ; =0x88a6
	movk	w1, #15368, lsl #16
	mov	w2, #43642                      ; =0xaa7a
	movk	w2, #15658, lsl #16
	mov	w3, #43691                      ; =0xaaab
	movk	w3, #15914, lsl #16
	movi.4s	v22, #63, lsl #24
	fmov.4s	v23, #1.00000000
	mvni.4s	v24, #127, msl #16
	fneg.4s	v24, v24
	mvni.4s	v25, #63, msl #16
	fneg.4s	v25, v25
	mov	w4, #1                          ; =0x1
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
LBB0_11:                                ; %direct.true174
                                        ; =>This Inner Loop Header: Depth=1
	add.2d	v29, v28, v4
	add.2d	v29, v29, v0
	add.2d	v30, v27, v3
	add.2d	v30, v30, v0
	add.2d	v31, v26, v2
	add.2d	v31, v31, v0
	add.2d	v8, v6, v1
	add.2d	v8, v8, v0
	mov.d	x6, v8[1]
	fmov	x7, d8
	mov.d	x19, v31[1]
	fmov	x20, d31
	mov.d	x21, v30[1]
	fmov	x22, d30
	mov.d	x23, v29[1]
	ldr	b31, [x7]
	ld1.b	{ v31 }[1], [x6]
	ld1.b	{ v31 }[2], [x20]
	ld1.b	{ v31 }[3], [x19]
	ld1.b	{ v31 }[4], [x22]
	fmov	x6, d29
	ld1.b	{ v31 }[5], [x21]
	lsl	x5, x5, #5
	ld1.b	{ v31 }[6], [x6]
	add	x6, x14, x5
	ldp	q30, q29, [x6]
	fsub.4s	v29, v29, v7
	ld1.b	{ v31 }[7], [x23]
	fsub.4s	v30, v30, v7
	fcmge.4s	v8, v30, v16
	fcmge.4s	v9, v29, v16
	fcmge.4s	v10, v17, v30
	fcmge.4s	v11, v17, v29
	cmeq.8b	v31, v31, #0
	and.16b	v9, v9, v11
	and.16b	v8, v8, v10
	and.16b	v10, v8, v30
	and.16b	v9, v9, v29
	fmul.4s	v8, v9, v18
	sshll.8h	v11, v31, #0
	fmul.4s	v31, v10, v18
	movi.4s	v5, #75, lsl #24
	mov.16b	v12, v20
	bsl.16b	v12, v5, v31
	mov.16b	v13, v20
	bsl.16b	v13, v5, v8
	fadd.4s	v8, v8, v13
	fadd.4s	v14, v31, v12
	sshll2.4s	v31, v11, #0
	fsub.4s	v12, v14, v12
	fsub.4s	v8, v8, v13
	fcvtzs.4s	v13, v8
	fcvtzs.4s	v12, v12
	scvtf.4s	v14, v12
	sshll.4s	v8, v11, #0
	scvtf.4s	v11, v13
	fmul.4s	v15, v11, v21
	fmul.4s	v5, v14, v21
	dup.4s	v19, w16
	fadd.4s	v5, v10, v5
	fadd.4s	v9, v9, v15
	fmul.4s	v10, v14, v19
	fmul.4s	v19, v11, v19
	dup.4s	v11, w17
	fadd.4s	v19, v9, v19
	fadd.4s	v5, v5, v10
	fmul.4s	v9, v5, v11
	fmul.4s	v10, v19, v11
	dup.4s	v11, w0
	fadd.4s	v10, v10, v11
	fadd.4s	v9, v9, v11
	fmul.4s	v9, v5, v9
	fmul.4s	v10, v19, v10
	dup.4s	v11, w1
	fadd.4s	v10, v10, v11
	fadd.4s	v9, v9, v11
	fmul.4s	v9, v5, v9
	fmul.4s	v10, v19, v10
	dup.4s	v11, w2
	fadd.4s	v10, v10, v11
	fadd.4s	v9, v9, v11
	fmul.4s	v9, v5, v9
	fmul.4s	v10, v19, v10
	dup.4s	v11, w3
	fadd.4s	v10, v10, v11
	fadd.4s	v9, v9, v11
	fmul.4s	v9, v5, v9
	fmul.4s	v10, v19, v10
	fadd.4s	v10, v10, v22
	fadd.4s	v9, v9, v22
	fmul.4s	v11, v19, v19
	fmul.4s	v14, v5, v5
	fmul.4s	v9, v14, v9
	fmul.4s	v10, v11, v10
	fadd.4s	v19, v19, v10
	fadd.4s	v5, v5, v9
	fadd.4s	v5, v5, v23
	sshr.4s	v9, v12, #1
	sshr.4s	v10, v13, #1
	shl.4s	v11, v10, #23
	shl.4s	v14, v9, #23
	add.4s	v14, v14, v23
	fadd.4s	v19, v19, v23
	add.4s	v11, v11, v23
	fmul.4s	v19, v19, v11
	sub.4s	v10, v13, v10
	sub.4s	v9, v12, v9
	shl.4s	v9, v9, #23
	fmul.4s	v5, v5, v14
	shl.4s	v10, v10, #23
	add.4s	v10, v10, v23
	add.4s	v9, v9, v23
	fmul.4s	v5, v5, v9
	fcmgt.4s	v9, v16, v29
	fmul.4s	v19, v19, v10
	bic.16b	v19, v19, v9
	fcmgt.4s	v9, v16, v30
	bic.16b	v5, v5, v9
	fcmgt.4s	v9, v29, v17
	fcmgt.4s	v10, v30, v17
	bit.16b	v5, v24, v10
	bit.16b	v19, v24, v9
	fcmeq.4s	v30, v30, v30
	fcmeq.4s	v29, v29, v29
	bif.16b	v19, v25, v29
	bif.16b	v5, v25, v30
	bic.16b	v5, v5, v8
	bic.16b	v19, v19, v31
	add	x5, x15, x5
	dup.2d	v29, x4
	stp	q5, q19, [x5]
	add.2d	v27, v27, v29
	add.2d	v26, v26, v29
	add.2d	v28, v28, v29
	add.2d	v6, v6, v29
	fmov	x5, d6
	cmp	x5, #512
	b.lt	LBB0_11
; %bb.12:                               ; %direct.false175
	mov	x14, #0                         ; =0x0
	ldr	q0, [sp]                        ; 16-byte Reload
	fmov	x16, d0
	ldr	b3, [x16]
	ldr	q0, [x13]
	fsub.4s	v1, v0, v7
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], v1[0]
	mov	w16, #-1026555904               ; =0xc2d00000
	dup.4s	v1, w16
	fcmge.4s	v4, v0, v1
	mov	w16, #1120403456                ; =0x42c80000
	dup.4s	v2, w16
	fcmge.4s	v5, v2, v0
	and.16b	v4, v4, v5
	and.16b	v4, v4, v0
	mov	w16, #43579                     ; =0xaa3b
	movk	w16, #16312, lsl #16
	dup.4s	v5, w16
	fmul.4s	v5, v4, v5
	movi.4s	v6, #75, lsl #24
	mvni.4s	v7, #128, lsl #24
	bif.16b	v6, v5, v7
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	mov	w16, #29184                     ; =0x7200
	movk	w16, #48945, lsl #16
	dup.4s	v7, w16
	fmul.4s	v7, v6, v7
	mov	w16, #48782                     ; =0xbe8e
	movk	w16, #46527, lsl #16
	dup.4s	v16, w16
	fadd.4s	v4, v4, v7
	fmul.4s	v6, v6, v16
	fadd.4s	v4, v4, v6
	mov	w16, #11226                     ; =0x2bda
	movk	w16, #14672, lsl #16
	dup.4s	v6, w16
	fmul.4s	v6, v4, v6
	mov	w16, #38601                     ; =0x96c9
	movk	w16, #15030, lsl #16
	dup.4s	v7, w16
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v4, v6
	mov	w16, #34982                     ; =0x88a6
	movk	w16, #15368, lsl #16
	dup.4s	v7, w16
	mov	w16, #43642                     ; =0xaa7a
	movk	w16, #15658, lsl #16
	dup.4s	v16, w16
	fadd.4s	v6, v6, v7
	mov	w16, #43691                     ; =0xaaab
	movk	w16, #15914, lsl #16
	dup.4s	v7, w16
	cmeq.8b	v3, v3, #0
	sshll.8h	v3, v3, #0
	sshll.4s	v3, v3, #0
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v16
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v4, v6
	movi.4s	v7, #63, lsl #24
	fadd.4s	v6, v6, v7
	fmul.4s	v7, v4, v4
	fmul.4s	v6, v7, v6
	fadd.4s	v4, v4, v6
	fmov.4s	v6, #1.00000000
	fadd.4s	v4, v4, v6
	sshr.4s	v7, v5, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v6
	fmul.4s	v4, v4, v16
	sub.4s	v5, v5, v7
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v6
	fmul.4s	v4, v4, v5
	fcmgt.4s	v1, v1, v0
	bic.16b	v1, v4, v1
	fcmgt.4s	v2, v0, v2
	mvni.4s	v4, #127, msl #16
	fneg.4s	v4, v4
	bit.16b	v1, v4, v2
	fcmeq.4s	v0, v0, v0
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	bsl.16b	v0, v1, v2
	bic.16b	v1, v0, v3
	ldr	q0, [x8, x9]
	mov.s	v0[0], v1[0]
	str	q0, [x8, x9]
	ldp	q1, q2, [x13, #32]
	ldp	q6, q7, [x13, #64]
	ldp	q16, q3, [x13, #96]
	ldp	q4, q5, [x13, #128]
	add	x13, x8, #17, lsl #12           ; =69632
	add	x13, x13, #328
LBB0_13:                                ; %direct.true215
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x14, lsl #5
	ldp	q17, q18, [x16, #-64]
	fadd.4s	v2, v2, v18
	fadd.4s	v1, v1, v17
	ldp	q17, q18, [x16, #-32]
	fadd.4s	v7, v7, v18
	fadd.4s	v6, v6, v17
	ldp	q17, q18, [x16]
	fadd.4s	v3, v3, v18
	fadd.4s	v16, v16, v17
	ldp	q17, q18, [x16, #32]
	fadd.4s	v5, v5, v18
	fadd.4s	v4, v4, v17
	add	x14, x14, #4
	cmp	x14, #508
	b.lo	LBB0_13
; %bb.14:                               ; %direct.false216
	mov	x13, #0                         ; =0x0
	fadd.4s	v0, v0, v1
	mov.s	v1[0], v0[0]
	fadd.4s	v0, v7, v2
	fadd.4s	v1, v6, v1
	fadd.4s	v1, v16, v1
	fadd.4s	v0, v3, v0
	fadd.4s	v0, v5, v0
	fadd.4s	v1, v4, v1
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v1, v0
	movi.2d	v1, #0000000000000000
	fadd	s0, s0, s1
	dup.4s	v0, v0[0]
	add	x12, x10, x12
LBB0_15:                                ; %direct.true252
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x15, x13
	ldp	q2, q1, [x14]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	add	x14, x12, x13
	stp	q2, q1, [x14]
	add	x13, x13, #32
	cmp	x13, #4, lsl #12                ; =16384
	b.ne	LBB0_15
; %bb.16:                               ; %direct.false253
	ldr	q1, [x8, x9]
	fdiv.4s	v0, v1, v0
	str	s0, [x10, x11]
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #64]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #48]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #32]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #128
	ret
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh16, Lloh17
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_11:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI1_12:
	.quad	32                              ; 0x20
	.quad	40                              ; 0x28
lCPI1_13:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI1_14:
	.quad	48                              ; 0x30
	.quad	56                              ; 0x38
lCPI1_15:
	.quad	3078                            ; 0xc06
	.quad	3591                            ; 0xe07
lCPI1_16:
	.quad	1026                            ; 0x402
	.quad	1539                            ; 0x603
lCPI1_17:
	.quad	2052                            ; 0x804
	.quad	2565                            ; 0xa05
lCPI1_18:
	.quad	0                               ; 0x0
	.quad	513                             ; 0x201
lCPI1_20:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI1_21:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI1_22:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI1_23:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_19:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2528
	str	x0, [sp, #536]                  ; 8-byte Spill
	cbz	w3, LBB1_189
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x27, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	mov	w19, #32                        ; =0x20
Lloh18:
	adrp	x8, lCPI1_0@PAGE
Lloh19:
	ldr	q18, [x8, lCPI1_0@PAGEOFF]
Lloh20:
	adrp	x8, lCPI1_1@PAGE
Lloh21:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #752]                  ; 16-byte Spill
Lloh22:
	adrp	x8, lCPI1_2@PAGE
Lloh23:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	stp	q0, q18, [sp, #432]             ; 32-byte Folded Spill
	movi.8b	v10, #1
	mvni.4s	v0, #127, msl #16
	fneg.4s	v1, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q1, [sp, #672]              ; 32-byte Folded Spill
	ldp	w9, w8, [x2, #44]
	str	w9, [sp, #532]                  ; 4-byte Spill
	str	w8, [sp, #528]                  ; 4-byte Spill
	mov	w24, #4                         ; =0x4
	ldp	w23, w26, [x2]
	ldp	w28, w8, [x2, #8]
	str	x8, [sp, #520]                  ; 8-byte Spill
	str	w3, [sp, #12]                   ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w23, #1
	ldr	w9, [sp, #532]                  ; 4-byte Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w23, wzr, w23, eq
	cinc	w9, w26, eq
	ldr	w10, [sp, #528]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w26, wzr, w9, ne
	add	w28, w28, w8
	add	w22, w22, #1
	cmp	w22, w27
	b.eq	LBB1_189
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_41 Depth 2
                                        ;     Child Loop BB1_44 Depth 2
                                        ;     Child Loop BB1_71 Depth 2
                                        ;     Child Loop BB1_114 Depth 2
                                        ;     Child Loop BB1_117 Depth 2
                                        ;     Child Loop BB1_149 Depth 2
                                        ;     Child Loop BB1_152 Depth 2
	ubfiz	x8, x23, #5, #32
	ldr	x11, [sp, #520]                 ; 8-byte Reload
	cmp	x8, x11
	csel	x9, x8, xzr, ls
	subs	x10, x11, x9
	cmp	x10, #32
	csel	x10, x10, x19, lo
	cmp	x11, x9
	stp	w23, w26, [x20]
	str	w28, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x11, #2, hi
	csel	x25, x10, xzr, ls
	cmp	x25, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x21, [sp, #536]                 ; 8-byte Reload
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x21, x25, #3
	cbz	x21, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #536]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #536]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #536]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x19, [sp, #536]                 ; 8-byte Reload
	mov	x0, x19
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x19
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x19
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x19
	mov	w19, #32                        ; =0x20
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w25, #0x7
	ldr	q18, [sp, #448]                 ; 16-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v2, w8
	ldr	q0, [sp, #432]                  ; 16-byte Reload
	cmhi.4s	v0, v2, v0
	ldr	q1, [sp, #752]                  ; 16-byte Reload
	str	q2, [sp, #736]                  ; 16-byte Spill
	cmhi.4s	v14, v2, v1
	uzp1.8h	v1, v14, v0
	umaxv.8h	h2, v1
	fmov	w8, s2
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	x8, [x20, #136]
	mov	w9, #4264                       ; =0x10a8
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #312]                  ; 8-byte Spill
	mov	w9, #53384                      ; =0xd088
	add	x17, x8, x9
	mov	w9, #16416                      ; =0x4020
	add	x10, x8, x9
	mov	w9, #49248                      ; =0xc060
	add	x9, x8, x9
	dup.2d	v4, x9
	mov	w9, #53352                      ; =0xd068
	add	x13, x8, x9
	mov	w9, #4232                       ; =0x1088
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	ldr	x14, [sp, #536]                 ; 8-byte Reload
	ldr	x12, [x14]
	ldr	x14, [x14, #48]
	str	x14, [sp, #424]                 ; 8-byte Spill
	and.16b	v2, v1, v18
	addv.8h	h3, v2
	fmov	w14, s3
	and	w14, w14, #0xff
	str	w14, [sp, #308]                 ; 4-byte Spill
	ubfiz	w14, w23, #2, #27
	orr	w14, w14, w21
	dup.4s	v2, w14
	and.16b	v18, v14, v2
	and.16b	v24, v0, v2
	ushll2.2d	v6, v24, #0
	ushll2.2d	v7, v18, #0
	ushll.2d	v16, v24, #0
	ushll.2d	v5, v18, #0
	fmov	x14, d5
	mov	w15, #16388                     ; =0x4004
	umaddl	x14, w14, w15, x12
	str	q3, [sp, #704]                  ; 16-byte Spill
	fmov	w15, s3
	mov	w3, #62154                      ; =0xf2ca
	movk	w3, #61769, lsl #16
	b	LBB1_15
LBB1_14:                                ; %else77
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x16, x8, x11
	stp	q2, q3, [x16]
	add	x11, x11, #32
	cmp	x11, #4, lsl #12                ; =16384
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x14, x11
	add	x1, x8, x11
	ldr	q2, [x1]
	tbnz	w15, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB1_24
LBB1_17:                                ; %else59
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w0, #2, LBB1_25
LBB1_18:                                ; %else62
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w0, #3, LBB1_26
LBB1_19:                                ; %else65
                                        ;   in Loop: Header=BB1_15 Depth=2
	ldr	q3, [x1, #16]
	tbnz	w0, #4, LBB1_27
LBB1_20:                                ; %else68
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w0, #5, LBB1_28
LBB1_21:                                ; %else71
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w0, #6, LBB1_29
LBB1_22:                                ; %else74
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w0, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	ld1.s	{ v2 }[0], [x16]
	and	w0, w15, #0xff
	tbz	w0, #1, LBB1_17
LBB1_24:                                ; %cond.load58
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x2, x16, #4
	ld1.s	{ v2 }[1], [x2]
	tbz	w0, #2, LBB1_18
LBB1_25:                                ; %cond.load61
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x2, x16, #8
	ld1.s	{ v2 }[2], [x2]
	tbz	w0, #3, LBB1_19
LBB1_26:                                ; %cond.load64
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x2, x16, #12
	ld1.s	{ v2 }[3], [x2]
	ldr	q3, [x1, #16]
	tbz	w0, #4, LBB1_20
LBB1_27:                                ; %cond.load67
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x1, x16, #16
	ld1.s	{ v3 }[0], [x1]
	tbz	w0, #5, LBB1_21
LBB1_28:                                ; %cond.load70
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x1, x16, #20
	ld1.s	{ v3 }[1], [x1]
	tbz	w0, #6, LBB1_22
LBB1_29:                                ; %cond.load73
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x1, x16, #24
	ld1.s	{ v3 }[2], [x1]
	tbz	w0, #7, LBB1_14
LBB1_30:                                ; %cond.load76
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x16, x16, #28
	ld1.s	{ v3 }[3], [x16]
	b	LBB1_14
LBB1_31:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v27, v1
	sshll.2d	v3, v14, #0
	sshll.2d	v1, v0, #0
	sshll2.2d	v31, v14, #0
	sshll2.2d	v15, v0, #0
Lloh24:
	adrp	x11, lCPI1_6@PAGE
Lloh25:
	ldr	q28, [x11, lCPI1_6@PAGEOFF]
	and.16b	v2, v3, v28
Lloh26:
	adrp	x11, lCPI1_7@PAGE
Lloh27:
	ldr	q17, [x11, lCPI1_7@PAGEOFF]
	and.16b	v3, v3, v17
Lloh28:
	adrp	x11, lCPI1_8@PAGE
Lloh29:
	ldr	q17, [x11, lCPI1_8@PAGEOFF]
	and.16b	v21, v1, v17
Lloh30:
	adrp	x11, lCPI1_9@PAGE
Lloh31:
	ldr	q17, [x11, lCPI1_9@PAGEOFF]
	and.16b	v22, v31, v17
Lloh32:
	adrp	x11, lCPI1_10@PAGE
Lloh33:
	ldr	q17, [x11, lCPI1_10@PAGEOFF]
	and.16b	v23, v15, v17
	and.8b	v17, v27, v10
	umov.b	w11, v17[0]
	movi.2d	v26, #0000000000000000
	mov.b	v26[0], v27[0]
	umaxv.8b	b17, v26
	fmov	w14, s17
	rbit	w15, w11
	clz	w15, w15
	tst	w14, #0x1
	mov	w16, #4096                      ; =0x1000
	dup.2d	v19, x16
	csel	w4, w15, wzr, ne
	str	q2, [sp, #288]                  ; 16-byte Spill
	orr.16b	v25, v2, v19
	mov	w15, #4097                      ; =0x1001
	dup.2s	v17, w15
	xtn.2s	v20, v5
	mov.16b	v2, v25
	umlal.2d	v2, v20, v17
	movi.2d	v5, #0000000000000000
	str	q27, [sp, #480]                 ; 16-byte Spill
	mov.b	v5[0], v27[0]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	str	q2, [sp, #400]                  ; 16-byte Spill
	and.16b	v5, v5, v2
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #2432]
	str	q2, [sp, #2416]
	str	q2, [sp, #2400]
	str	q5, [sp, #2384]
	ubfiz	x15, x4, #3, #3
	add	x16, sp, #2384
	ldr	x16, [x16, x15]
	sub	x16, x16, x4
	add	x12, x12, x16, lsl #2
	str	q23, [sp, #2496]
	str	q21, [sp, #2480]
	str	q22, [sp, #2464]
	str	q3, [sp, #272]                  ; 16-byte Spill
	str	q3, [sp, #2448]
	add	x16, sp, #2448
	ldr	x15, [x16, x15]
	orr	x15, x15, #0x4000
	sub	x15, x15, w4, uxtw #2
	tst	w11, #0x1
	csel	x5, xzr, x15, eq
	add	x15, x8, x5
	ldp	q5, q21, [x15]
	tbnz	w14, #0, LBB1_89
; %bb.32:                               ; %else81
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #1, LBB1_90
LBB1_33:                                ; %else84
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #2, LBB1_91
LBB1_34:                                ; %else87
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #3, LBB1_92
LBB1_35:                                ; %else90
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #4, LBB1_93
LBB1_36:                                ; %else93
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #5, LBB1_94
LBB1_37:                                ; %else96
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #6, LBB1_95
LBB1_38:                                ; %else99
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q26, [sp, #496]                 ; 16-byte Spill
	tbz	w11, #7, LBB1_40
LBB1_39:                                ; %cond.load101
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x12, #28
	ld1.s	{ v21 }[3], [x12]
LBB1_40:                                ; %else102
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	add	x14, x8, x5
	stp	q5, q21, [x14]
Lloh34:
	adrp	x14, lCPI1_3@PAGE
Lloh35:
	ldr	q21, [x14, lCPI1_3@PAGEOFF]
	and.16b	v2, v15, v21
Lloh36:
	adrp	x14, lCPI1_4@PAGE
Lloh37:
	ldr	q22, [x14, lCPI1_4@PAGEOFF]
	and.16b	v3, v31, v22
Lloh38:
	adrp	x14, lCPI1_5@PAGE
Lloh39:
	ldr	q30, [x14, lCPI1_5@PAGEOFF]
	and.16b	v1, v1, v30
	stp	q1, q3, [sp, #208]              ; 32-byte Folded Spill
	orr.16b	v26, v1, v19
	orr.16b	v29, v3, v19
	str	q2, [sp, #256]                  ; 16-byte Spill
	orr.16b	v27, v2, v19
	umull.2d	v3, v20, v17
	xtn.2s	v1, v7
	xtn.2s	v7, v16
	xtn.2s	v6, v6
	mov.16b	v2, v27
	umlal.2d	v2, v6, v17
	str	q2, [sp, #368]                  ; 16-byte Spill
	mov.16b	v2, v29
	umlal.2d	v2, v1, v17
	str	q2, [sp, #352]                  ; 16-byte Spill
	mov.16b	v1, v26
	umlal.2d	v1, v7, v17
	stp	q3, q1, [sp, #320]              ; 32-byte Folded Spill
	mov	w14, #1                         ; =0x1
	dup.2d	v1, x14
	ushll2.2d	v6, v0, #0
	and.16b	v23, v6, v1
	ushll2.2d	v6, v14, #0
	mov.16b	v3, v31
	and.16b	v31, v6, v1
	ushll.2d	v6, v0, #0
	and.16b	v8, v6, v1
	ushll.2d	v6, v14, #0
	and.16b	v9, v6, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	stp	q8, q31, [sp, #800]             ; 32-byte Folded Spill
	stp	q15, q9, [sp, #768]             ; 32-byte Folded Spill
LBB1_41:                                ; %direct.true73.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v17, v0, #0
	sshll.2d	v19, v14, #0
	shl.2d	v20, v16, #3
	shl.2d	v31, v1, #3
	shl.2d	v8, v7, #3
	shl.2d	v9, v6, #3
	orr.16b	v9, v9, v22
	orr.16b	v8, v8, v30
	orr.16b	v31, v31, v28
	orr.16b	v20, v20, v21
	add	x12, x10, x12, lsl #6
	ldp	q12, q11, [x12]
	ldp	q13, q15, [x12, #32]
	ldr	q2, [sp, #768]                  ; 16-byte Reload
	bif.16b	v20, v15, v2
	bsl.16b	v19, v31, v12
	bsl.16b	v17, v8, v13
	mov.16b	v31, v3
	bsl.16b	v31, v9, v11
	ldp	q15, q9, [sp, #768]             ; 32-byte Folded Reload
	stp	q19, q31, [x12]
	ldp	q8, q31, [sp, #800]             ; 32-byte Folded Reload
	stp	q17, q20, [x12, #32]
	add.2d	v6, v6, v31
	add.2d	v7, v7, v8
	add.2d	v16, v16, v23
	add.2d	v1, v1, v9
	fmov	x12, d1
	cmp	x12, #512
	b.lt	LBB1_41
; %bb.42:                               ; %direct.false74.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	mov	w14, #4097                      ; =0x1001
	dup.4s	v1, w14
	and.16b	v6, v0, v1
	mvn.16b	v7, v0
	sub.4s	v6, v6, v7
	mov.s	w14, v6[1]
	mov.s	w15, v24[1]
	and.16b	v7, v14, v1
	udiv	w16, w15, w14
	mul	w14, w16, w14
	sub	w14, w15, w14
	mov.s	w15, v6[2]
	mov.s	w16, v6[3]
	fmov	w0, s6
	fmov	w1, s24
	udiv	w2, w1, w0
	mul	w0, w2, w0
	sub	w0, w1, w0
	fmov	s1, w0
	mov.s	v1[1], w14
	mov.s	w14, v24[2]
	mvn.16b	v6, v14
	udiv	w0, w14, w15
	mul	w15, w0, w15
	sub	w14, w14, w15
	mov.s	v1[2], w14
	sub.4s	v6, v7, v6
	mov.s	w14, v24[3]
	udiv	w15, w14, w16
	mul	w15, w15, w16
	sub	w14, w14, w15
	mov.s	v1[3], w14
	mov.s	w14, v6[1]
	mov.s	w15, v18[1]
	udiv	w16, w15, w14
	mul	w14, w16, w14
	sub	w14, w15, w14
	mov.s	w15, v6[2]
	mov.s	w16, v6[3]
	fmov	w0, s6
	fmov	w1, s18
	udiv	w2, w1, w0
	mul	w0, w2, w0
	sub	w0, w1, w0
	fmov	s6, w0
	sshll.2d	v17, v0, #0
	sshll.2d	v16, v14, #0
Lloh40:
	adrp	x0, lCPI1_11@PAGE
Lloh41:
	ldr	q7, [x0, lCPI1_11@PAGEOFF]
	and.16b	v7, v16, v7
Lloh42:
	adrp	x0, lCPI1_12@PAGE
Lloh43:
	ldr	q19, [x0, lCPI1_12@PAGEOFF]
	and.16b	v19, v17, v19
Lloh44:
	adrp	x0, lCPI1_13@PAGE
Lloh45:
	ldr	q20, [x0, lCPI1_13@PAGEOFF]
	and.16b	v20, v3, v20
Lloh46:
	adrp	x0, lCPI1_14@PAGE
Lloh47:
	ldr	q21, [x0, lCPI1_14@PAGEOFF]
	and.16b	v21, v15, v21
	str	q21, [sp, #2368]
	str	q19, [sp, #2352]
	str	q20, [sp, #2336]
	str	q7, [sp, #2320]
	mov.s	v6[1], w14
	tst	w11, #0xff
	mov.s	w14, v18[2]
	udiv	w11, w14, w15
	mul	w15, w11, w15
	and	x11, x4, #0x7
	add	x0, sp, #2320
	ldr	x11, [x0, x11, lsl #3]
	orr	x11, x11, #0x8000
	sub	x11, x11, x4, lsl #3
	csel	x11, xzr, x11, eq
	sub	w14, w14, w15
	mov.s	v6[2], w14
	mov.s	w14, v18[3]
	udiv	w15, w14, w16
	mul	w15, w15, w16
	add	x16, x10, x11
	ldp	q7, q18, [x16, #32]
	ldp	q19, q20, [x16]
	ldr	q5, [sp, #496]                  ; 16-byte Reload
	mov	b21, v5[2]
	mov.b	v21[4], v5[3]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	bit.16b	v20, v29, v21
	mov	b21, v5[0]
	mov.b	v21[4], v5[1]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	bit.16b	v19, v25, v21
	mov	b21, v5[6]
	mov.b	v21[4], v5[7]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	bit.16b	v18, v27, v21
	mov	b21, v5[4]
	mov.b	v21[4], v5[5]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	bit.16b	v7, v26, v21
	sub	w14, w14, w15
	mov.s	v6[3], w14
	and.16b	v21, v14, v6
	stp	q7, q18, [x16, #32]
	stp	q19, q20, [x16]
	and.16b	v6, v0, v1
	ushll2.2d	v1, v6, #0
	ushll2.2d	v7, v21, #0
	ushll.2d	v6, v6, #0
	ushll.2d	v18, v21, #0
	and.16b	v24, v15, v4
	and.16b	v25, v3, v4
	and.16b	v28, v17, v4
	and.16b	v29, v16, v4
Lloh48:
	adrp	x14, lCPI1_15@PAGE
Lloh49:
	ldr	q4, [x14, lCPI1_15@PAGEOFF]
	and.16b	v30, v15, v4
Lloh50:
	adrp	x14, lCPI1_16@PAGE
Lloh51:
	ldr	q4, [x14, lCPI1_16@PAGEOFF]
	str	q3, [sp, #656]                  ; 16-byte Spill
	and.16b	v11, v3, v4
Lloh52:
	adrp	x14, lCPI1_17@PAGE
Lloh53:
	ldr	q4, [x14, lCPI1_17@PAGEOFF]
	and.16b	v12, v17, v4
Lloh54:
	adrp	x14, lCPI1_18@PAGE
Lloh55:
	ldr	q4, [x14, lCPI1_18@PAGEOFF]
	and.16b	v13, v16, v4
	ldr	q2, [sp, #432]                  ; 16-byte Reload
	ldr	q16, [sp, #736]                 ; 16-byte Reload
	cmhs.4s	v4, v2, v16
	ldr	q2, [sp, #752]                  ; 16-byte Reload
	cmhs.4s	v16, v2, v16
	uzp1.8h	v4, v16, v4
	xtn.8b	v4, v4
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v21, #0000000000000000
	ldr	q2, [sp, #704]                  ; 16-byte Reload
	b	LBB1_44
LBB1_43:                                ; %else119
                                        ;   in Loop: Header=BB1_44 Depth=2
	add.2d	v20, v20, v31
	add.2d	v16, v16, v8
	add.2d	v21, v21, v23
	add.2d	v19, v19, v9
	fmov	x12, d19
	cmp	x12, #512
	b.ge	LBB1_60
LBB1_44:                                ; %direct.true89.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w14, s2
	add	x12, x10, x12, lsl #6
	ldp	q22, q17, [x12, #32]
	ldp	q26, q27, [x12]
	cmge.2d	v27, v7, v27
	cmge.2d	v26, v18, v26
	uzp1.4s	v26, v26, v27
	cmge.2d	v22, v6, v22
	cmge.2d	v17, v1, v17
	uzp1.4s	v17, v22, v17
	uzp1.8h	v17, v26, v17
	xtn.8b	v17, v17
	orr.8b	v17, v4, v17
	add.2d	v22, v19, v13
	add.2d	v22, v29, v22
	and.8b	v17, v17, v10
	tbnz	w14, #0, LBB1_52
; %bb.45:                               ; %else105
                                        ;   in Loop: Header=BB1_44 Depth=2
	and	w12, w14, #0xff
	tbnz	w12, #1, LBB1_53
LBB1_46:                                ; %else107
                                        ;   in Loop: Header=BB1_44 Depth=2
	add.2d	v22, v20, v11
	add.2d	v22, v25, v22
	tbnz	w12, #2, LBB1_54
LBB1_47:                                ; %else109
                                        ;   in Loop: Header=BB1_44 Depth=2
	tbnz	w12, #3, LBB1_55
LBB1_48:                                ; %else111
                                        ;   in Loop: Header=BB1_44 Depth=2
	add.2d	v22, v16, v12
	add.2d	v22, v28, v22
	tbnz	w12, #4, LBB1_56
LBB1_49:                                ; %else113
                                        ;   in Loop: Header=BB1_44 Depth=2
	tbnz	w12, #5, LBB1_57
LBB1_50:                                ; %else115
                                        ;   in Loop: Header=BB1_44 Depth=2
	add.2d	v22, v21, v30
	add.2d	v22, v24, v22
	tbnz	w12, #6, LBB1_58
LBB1_51:                                ; %else117
                                        ;   in Loop: Header=BB1_44 Depth=2
	tbz	w12, #7, LBB1_43
	b	LBB1_59
LBB1_52:                                ; %cond.store
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x12, d22
	str	b17, [x12]
	and	w12, w14, #0xff
	tbz	w12, #1, LBB1_46
LBB1_53:                                ; %cond.store106
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x14, v22[1]
	st1.b	{ v17 }[1], [x14]
	add.2d	v22, v20, v11
	add.2d	v22, v25, v22
	tbz	w12, #2, LBB1_47
LBB1_54:                                ; %cond.store108
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x14, d22
	st1.b	{ v17 }[2], [x14]
	tbz	w12, #3, LBB1_48
LBB1_55:                                ; %cond.store110
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x14, v22[1]
	st1.b	{ v17 }[3], [x14]
	add.2d	v22, v16, v12
	add.2d	v22, v28, v22
	tbz	w12, #4, LBB1_49
LBB1_56:                                ; %cond.store112
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x14, d22
	st1.b	{ v17 }[4], [x14]
	tbz	w12, #5, LBB1_50
LBB1_57:                                ; %cond.store114
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x14, v22[1]
	st1.b	{ v17 }[5], [x14]
	add.2d	v22, v21, v30
	add.2d	v22, v24, v22
	tbz	w12, #6, LBB1_51
LBB1_58:                                ; %cond.store116
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x14, d22
	st1.b	{ v17 }[6], [x14]
	tbz	w12, #7, LBB1_43
LBB1_59:                                ; %cond.store118
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x12, v22[1]
	st1.b	{ v17 }[7], [x12]
	b	LBB1_43
LBB1_60:                                ; %direct.false90.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, x11
	ldp	q16, q4, [x10, #32]
	ldp	q17, q19, [x10]
	cmge.2d	v7, v7, v19
	cmge.2d	v17, v18, v17
	uzp1.4s	v7, v17, v7
	cmge.2d	v6, v6, v16
	cmge.2d	v1, v1, v4
	uzp1.4s	v1, v6, v1
	uzp1.8h	v1, v7, v1
	xtn.8b	v1, v1
Lloh56:
	adrp	x10, lCPI1_19@PAGE
Lloh57:
	ldr	d4, [x10, lCPI1_19@PAGEOFF]
	shl.8b	v6, v5, #7
	cmlt.8b	v6, v6, #0
	and.8b	v4, v6, v4
	addv.8b	b4, v4
	str	d4, [sp, #472]                  ; 8-byte Spill
	fmov	w10, s4
	orn.8b	v1, v1, v5
	add.2d	v6, v13, v29
	mov	w11, #512                       ; =0x200
	dup.2d	v4, x11
	add.2d	v27, v6, v4
	and.8b	v1, v1, v10
	tbnz	w10, #0, LBB1_96
; %bb.61:                               ; %else124
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x0, v27[1]
	tbnz	w10, #1, LBB1_97
LBB1_62:                                ; %else128
                                        ;   in Loop: Header=BB1_4 Depth=1
	add.2d	v6, v11, v25
	add.2d	v26, v6, v4
	tbnz	w10, #2, LBB1_98
LBB1_63:                                ; %else132
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x16, v26[1]
	tbnz	w10, #3, LBB1_99
LBB1_64:                                ; %else136
                                        ;   in Loop: Header=BB1_4 Depth=1
	add.2d	v6, v12, v28
	add.2d	v22, v6, v4
	tbnz	w10, #4, LBB1_100
LBB1_65:                                ; %else140
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x15, v22[1]
	tbnz	w10, #5, LBB1_101
LBB1_66:                                ; %else144
                                        ;   in Loop: Header=BB1_4 Depth=1
	add.2d	v6, v30, v24
	add.2d	v21, v6, v4
	tbnz	w10, #6, LBB1_102
LBB1_67:                                ; %else148
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x14, v21[1]
	tbz	w10, #7, LBB1_69
LBB1_68:                                ; %cond.store149
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[7], [x14]
LBB1_69:                                ; %else152
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	movi.2d	v1, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	b	LBB1_71
LBB1_70:                                ; %else184
                                        ;   in Loop: Header=BB1_71 Depth=2
	cmeq.8b	v16, v18, #0
	sshll.8h	v16, v16, #0
	sshll2.4s	v17, v16, #0
	sshll.4s	v16, v16, #0
	lsl	x10, x10, #5
	add	x11, x8, x10
	ldp	q18, q19, [x11]
	and.16b	v19, v0, v19
	and.16b	v20, v14, v18
	dup.4s	v18, w3
	bsl.16b	v16, v18, v20
	bsl.16b	v17, v18, v19
	add	x10, x13, x10
	ldp	q19, q20, [x10]
	bif.16b	v17, v20, v0
	bif.16b	v16, v19, v14
	stp	q16, q17, [x10]
	add.2d	v4, v4, v31
	add.2d	v6, v6, v8
	add.2d	v7, v7, v23
	add.2d	v1, v1, v9
	fmov	x10, d1
	cmp	x10, #512
	b.ge	LBB1_87
LBB1_71:                                ; %direct.true105.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s2
	add.2d	v16, v1, v13
	add.2d	v16, v29, v16
	tbz	w11, #0, LBB1_73
; %bb.72:                               ; %cond.load154
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x12, d16
	ldr	b18, [x12]
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_74
	b	LBB1_75
LBB1_73:                                ;   in Loop: Header=BB1_71 Depth=2
	movi.2d	v18, #0000000000000000
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_75
LBB1_74:                                ; %cond.load158
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x12, v16[1]
	ld1.b	{ v18 }[1], [x12]
LBB1_75:                                ; %else160
                                        ;   in Loop: Header=BB1_71 Depth=2
	add.2d	v16, v4, v11
	add.2d	v16, v25, v16
	tbnz	w11, #2, LBB1_81
; %bb.76:                               ; %else164
                                        ;   in Loop: Header=BB1_71 Depth=2
	tbnz	w11, #3, LBB1_82
LBB1_77:                                ; %else168
                                        ;   in Loop: Header=BB1_71 Depth=2
	add.2d	v16, v6, v12
	add.2d	v16, v28, v16
	tbnz	w11, #4, LBB1_83
LBB1_78:                                ; %else172
                                        ;   in Loop: Header=BB1_71 Depth=2
	tbnz	w11, #5, LBB1_84
LBB1_79:                                ; %else176
                                        ;   in Loop: Header=BB1_71 Depth=2
	add.2d	v16, v7, v30
	add.2d	v16, v24, v16
	tbnz	w11, #6, LBB1_85
LBB1_80:                                ; %else180
                                        ;   in Loop: Header=BB1_71 Depth=2
	tbz	w11, #7, LBB1_70
	b	LBB1_86
LBB1_81:                                ; %cond.load162
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x12, d16
	ld1.b	{ v18 }[2], [x12]
	tbz	w11, #3, LBB1_77
LBB1_82:                                ; %cond.load166
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x12, v16[1]
	ld1.b	{ v18 }[3], [x12]
	add.2d	v16, v6, v12
	add.2d	v16, v28, v16
	tbz	w11, #4, LBB1_78
LBB1_83:                                ; %cond.load170
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x12, d16
	ld1.b	{ v18 }[4], [x12]
	tbz	w11, #5, LBB1_79
LBB1_84:                                ; %cond.load174
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x12, v16[1]
	ld1.b	{ v18 }[5], [x12]
	add.2d	v16, v7, v30
	add.2d	v16, v24, v16
	tbz	w11, #6, LBB1_80
LBB1_85:                                ; %cond.load178
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x12, d16
	ld1.b	{ v18 }[6], [x12]
	tbz	w11, #7, LBB1_70
LBB1_86:                                ; %cond.load182
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x11, v16[1]
	ld1.b	{ v18 }[7], [x11]
	b	LBB1_70
LBB1_87:                                ; %direct.true139.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	d1, [sp, #472]                  ; 8-byte Reload
	fmov	w10, s1
	tbz	w10, #0, LBB1_103
; %bb.88:                               ; %cond.load187
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x11, d27
	ldr	b1, [x11]
	ldr	q31, [sp, #656]                 ; 16-byte Reload
	tbnz	w10, #1, LBB1_104
	b	LBB1_105
LBB1_89:                                ; %cond.load80
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v5 }[0], [x12]
	tbz	w11, #1, LBB1_33
LBB1_90:                                ; %cond.load83
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #4
	ld1.s	{ v5 }[1], [x14]
	tbz	w11, #2, LBB1_34
LBB1_91:                                ; %cond.load86
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #8
	ld1.s	{ v5 }[2], [x14]
	tbz	w11, #3, LBB1_35
LBB1_92:                                ; %cond.load89
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #12
	ld1.s	{ v5 }[3], [x14]
	tbz	w11, #4, LBB1_36
LBB1_93:                                ; %cond.load92
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #16
	ld1.s	{ v21 }[0], [x14]
	tbz	w11, #5, LBB1_37
LBB1_94:                                ; %cond.load95
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #20
	ld1.s	{ v21 }[1], [x14]
	tbz	w11, #6, LBB1_38
LBB1_95:                                ; %cond.load98
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #24
	ld1.s	{ v21 }[2], [x14]
	str	q26, [sp, #496]                 ; 16-byte Spill
	tbnz	w11, #7, LBB1_39
	b	LBB1_40
LBB1_96:                                ; %cond.store121
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x11, d27
	str	b1, [x11]
	mov.d	x0, v27[1]
	tbz	w10, #1, LBB1_62
LBB1_97:                                ; %cond.store125
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[1], [x0]
	add.2d	v6, v11, v25
	add.2d	v26, v6, v4
	tbz	w10, #2, LBB1_63
LBB1_98:                                ; %cond.store129
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x11, d26
	st1.b	{ v1 }[2], [x11]
	mov.d	x16, v26[1]
	tbz	w10, #3, LBB1_64
LBB1_99:                                ; %cond.store133
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[3], [x16]
	add.2d	v6, v12, v28
	add.2d	v22, v6, v4
	tbz	w10, #4, LBB1_65
LBB1_100:                               ; %cond.store137
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x11, d22
	st1.b	{ v1 }[4], [x11]
	mov.d	x15, v22[1]
	tbz	w10, #5, LBB1_66
LBB1_101:                               ; %cond.store141
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[5], [x15]
	add.2d	v6, v30, v24
	add.2d	v21, v6, v4
	tbz	w10, #6, LBB1_67
LBB1_102:                               ; %cond.store145
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x11, d21
	st1.b	{ v1 }[6], [x11]
	mov.d	x14, v21[1]
	tbnz	w10, #7, LBB1_68
	b	LBB1_69
LBB1_103:                               ;   in Loop: Header=BB1_4 Depth=1
	movi.2d	v1, #0000000000000000
	ldr	q31, [sp, #656]                 ; 16-byte Reload
	tbz	w10, #1, LBB1_105
LBB1_104:                               ; %cond.load193
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[1], [x0]
LBB1_105:                               ; %else197
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #2, LBB1_135
; %bb.106:                              ; %else203
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #3, LBB1_136
LBB1_107:                               ; %else209
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #4, LBB1_137
LBB1_108:                               ; %else215
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #5, LBB1_138
LBB1_109:                               ; %else221
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_111
LBB1_110:                               ; %cond.load223
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x11, d21
	ld1.b	{ v1 }[6], [x11]
LBB1_111:                               ; %else227
                                        ;   in Loop: Header=BB1_4 Depth=1
	stp	q25, q24, [sp, #640]            ; 32-byte Folded Spill
	stp	q29, q28, [sp, #608]            ; 32-byte Folded Spill
	stp	q11, q30, [sp, #576]            ; 32-byte Folded Spill
	str	q23, [sp, #720]                 ; 16-byte Spill
	stp	q13, q12, [sp, #544]            ; 32-byte Folded Spill
	str	q21, [sp, #112]                 ; 16-byte Spill
	str	q22, [sp, #80]                  ; 16-byte Spill
	str	q26, [sp, #48]                  ; 16-byte Spill
	str	q27, [sp, #16]                  ; 16-byte Spill
	tbz	w10, #7, LBB1_113
; %bb.112:                              ; %cond.load229
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[7], [x14]
LBB1_113:                               ; %else233
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w28, [sp, #172]                 ; 4-byte Spill
	str	w22, [sp, #204]                 ; 4-byte Spill
	str	w26, [sp, #252]                 ; 4-byte Spill
	str	x0, [sp, #40]                   ; 8-byte Spill
	str	x16, [sp, #72]                  ; 8-byte Spill
	str	x15, [sp, #104]                 ; 8-byte Spill
	str	x14, [sp, #128]                 ; 8-byte Spill
	str	x4, [sp, #416]                  ; 8-byte Spill
	sshll.2d	v4, v14, #0
	sshll.2d	v6, v0, #0
	cmeq.8b	v1, v1, #0
	sshll.8h	v1, v1, #0
	sshll2.4s	v7, v1, #0
	sshll.4s	v1, v1, #0
	add	x8, x8, x5
	ldp	q16, q17, [x8]
	zip2.8b	v19, v5, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	and.16b	v17, v19, v17
	zip1.8b	v20, v5, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmlt.4s	v20, v20, #0
	and.16b	v16, v20, v16
	mov.16b	v3, v1
	bsl.16b	v3, v18, v16
	mov.16b	v2, v7
	bsl.16b	v2, v18, v17
	str	x5, [sp, #392]                  ; 8-byte Spill
	add	x8, x13, x5
	ldp	q1, q7, [x8]
	str	q2, [sp, #176]                  ; 16-byte Spill
	bit.16b	v7, v2, v19
	str	q3, [sp, #144]                  ; 16-byte Spill
	bit.16b	v1, v3, v20
	stp	q1, q7, [x8]
	ldr	q1, [sp, #272]                  ; 16-byte Reload
	fmov	x8, d1
	dup.2d	v1, x24
	and.16b	v27, v15, v1
	and.16b	v18, v31, v1
	and.16b	v26, v6, v1
	and.16b	v4, v4, v1
	fmov	x3, d4
	ldp	q3, q1, [x17, #64]
	and.16b	v1, v0, v1
	and.16b	v6, v14, v3
	ldp	q3, q7, [x17, #32]
	and.16b	v19, v0, v7
	and.16b	v7, v14, v3
	ldp	q3, q16, [x17]
	and.16b	v20, v0, v16
	and.16b	v21, v14, v3
	str	x8, [sp, #160]                  ; 8-byte Spill
	add	x8, x13, x8
	ldp	q3, q16, [x8]
	and.16b	v9, v0, v16
	mov	x8, x3
	and.16b	v16, v14, v3
	mov.16b	v12, v4
	mov.16b	v13, v18
	mov.16b	v3, v26
	mov.16b	v30, v15
	mov.16b	v15, v27
LBB1_114:                               ; %direct.true139.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v23, v14, #0
	sshll.2d	v5, v0, #0
	add	x8, x13, x8, lsl #5
	ldp	q17, q11, [x8]
	and.16b	v11, v0, v11
	and.16b	v17, v14, v17
	fmaxnm.4s	v17, v16, v17
	fmaxnm.4s	v11, v9, v11
	ldp	q10, q22, [x8, #32]
	and.16b	v22, v0, v22
	and.16b	v10, v14, v10
	fmaxnm.4s	v10, v21, v10
	fmaxnm.4s	v22, v20, v22
	ldp	q8, q2, [x8, #64]
	and.16b	v2, v0, v2
	and.16b	v8, v14, v8
	fmaxnm.4s	v8, v7, v8
	fmaxnm.4s	v2, v19, v2
	ldp	q24, q25, [x8, #96]
	and.16b	v25, v0, v25
	and.16b	v24, v14, v24
	fmaxnm.4s	v24, v6, v24
	fmaxnm.4s	v25, v1, v25
	dup.2d	v28, x24
	and.16b	v29, v30, v28
	add.2d	v15, v15, v29
	and.16b	v29, v31, v28
	add.2d	v13, v13, v29
	and.16b	v5, v5, v28
	add.2d	v3, v3, v5
	and.16b	v5, v23, v28
	add.2d	v12, v12, v5
	bit.16b	v9, v11, v0
	bit.16b	v16, v17, v14
	bit.16b	v20, v22, v0
	bit.16b	v21, v10, v14
	bit.16b	v19, v2, v0
	bit.16b	v7, v8, v14
	bit.16b	v1, v25, v0
	bit.16b	v6, v24, v14
	fmov	x8, d12
	cmp	x8, #512
	b.lt	LBB1_114
; %bb.115:                              ; %direct.false140.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x16, #0                         ; =0x0
	ldp	q24, q5, [sp, #480]             ; 32-byte Folded Reload
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #144]                  ; 16-byte Reload
	and.16b	v3, v2, v3
	zip2.8b	v5, v5, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q22, [sp, #176]                 ; 16-byte Reload
	and.16b	v22, v5, v22
	fmaxnm.4s	v22, v9, v22
	fmaxnm.4s	v3, v16, v3
	and.16b	v2, v2, v3
	and.16b	v3, v5, v22
	zip2.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	movi.2d	v16, #0000000000000000
	mov.b	v16[2], v24[1]
	mov.b	v16[4], v24[2]
	mov.b	v16[6], v24[3]
	bit.16b	v3, v11, v5
	ushll.4s	v5, v16, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bit.16b	v2, v17, v5
	fmaxnm.4s	v2, v2, v21
	fmaxnm.4s	v3, v3, v20
	fmaxnm.4s	v3, v3, v19
	fmaxnm.4s	v2, v2, v7
	fmaxnm.4s	v6, v2, v6
	fmaxnm.4s	v7, v3, v1
	ldr	q1, [sp, #288]                  ; 16-byte Reload
	ldp	q3, q2, [sp, #208]              ; 32-byte Folded Reload
	uzp1.4s	v2, v1, v2
	ldr	q1, [sp, #256]                  ; 16-byte Reload
	uzp1.4s	v1, v3, v1
	movi.4s	v5, #1
	eor.16b	v3, v2, v5
	mov.s	w8, v3[1]
	mov.s	w11, v3[2]
	eor.16b	v16, v1, v5
	mov.s	w12, v3[3]
	fmov	w10, s3
	add	x14, sp, #1496
	bfxil	x14, x10, #0, #3
	str	d24, [sp, #1496]
	ldrb	w14, [x14]
	and	x10, x10, #0x7
	umov.b	w5, v24[0]
	str	q7, [sp, #2160]
	str	q6, [sp, #2144]
	add	x15, sp, #2144
	ldr	s3, [x15, x10, lsl #2]
	ands	w10, w5, #0x1
	tst	w10, w14
	movi.2d	v23, #0000000000000000
	fcsel	s5, s3, s23, ne
	and	x14, x8, #0x7
	add	x15, sp, #1496
	bfxil	x15, x8, #0, #3
	ldrb	w8, [x15]
	umov.b	w17, v24[1]
	and	w8, w17, w8
	str	q7, [sp, #2128]
	str	q6, [sp, #2112]
	add	x15, sp, #2112
	ldr	s3, [x15, x14, lsl #2]
	tst	w8, #0x1
	fcsel	s19, s3, s23, ne
	and	x8, x11, #0x7
	add	x14, sp, #1496
	bfxil	x14, x11, #0, #3
	umov.b	w4, v24[2]
	ldrb	w11, [x14]
	and	w11, w4, w11
	str	q7, [sp, #2096]
	str	q6, [sp, #2080]
	add	x14, sp, #2080
	ldr	s3, [x14, x8, lsl #2]
	tst	w11, #0x1
	fcsel	s20, s3, s23, ne
	and	x8, x12, #0x7
	add	x11, sp, #1496
	bfxil	x11, x12, #0, #3
	ldrb	w11, [x11]
	umov.b	w26, v24[3]
	str	q7, [sp, #2064]
	str	q6, [sp, #2048]
	add	x12, sp, #2048
	ldr	s3, [x12, x8, lsl #2]
	and	w8, w26, w11
	tst	w8, #0x1
	mov.s	w8, v16[1]
	mov.s	w11, v16[2]
	fcsel	s17, s3, s23, ne
	mov.s	w12, v16[3]
	fmov	w14, s16
	and	x15, x14, #0x7
	add	x0, sp, #1496
	bfxil	x0, x14, #0, #3
	ldrb	w14, [x0]
	umov.b	w2, v24[4]
	and	w14, w2, w14
	str	q7, [sp, #2288]
	str	q6, [sp, #2272]
	add	x0, sp, #2272
	ldr	s3, [x0, x15, lsl #2]
	tst	w14, #0x1
	fcsel	s3, s3, s23, ne
	and	x14, x8, #0x7
	add	x15, sp, #1496
	bfxil	x15, x8, #0, #3
	ldrb	w8, [x15]
	umov.b	w24, v24[5]
	and	w8, w24, w8
	str	q7, [sp, #2256]
	str	q6, [sp, #2240]
	add	x15, sp, #2240
	ldr	s16, [x15, x14, lsl #2]
	tst	w8, #0x1
	fcsel	s16, s16, s23, ne
	and	x8, x11, #0x7
	add	x14, sp, #1496
	bfxil	x14, x11, #0, #3
	ldrb	w11, [x14]
	umov.b	w22, v24[6]
	and	w11, w22, w11
	str	q7, [sp, #2224]
	str	q6, [sp, #2208]
	add	x14, sp, #2208
	ldr	s21, [x14, x8, lsl #2]
	tst	w11, #0x1
	fcsel	s21, s21, s23, ne
	and	x11, x12, #0x7
	add	x14, sp, #1496
	bfxil	x14, x12, #0, #3
	umov.b	w28, v24[7]
	ldrb	w12, [x14]
	and	w12, w28, w12
	str	q7, [sp, #2192]
	str	q6, [sp, #2176]
	add	x8, sp, #2176
	ldr	s22, [x8, x11, lsl #2]
	tst	w12, #0x1
	fcsel	s22, s22, s23, ne
	mov.s	v3[1], v16[0]
	mov.s	v3[2], v21[0]
	mov.s	v3[3], v22[0]
	mov.s	v5[1], v19[0]
	mov.s	v5[2], v20[0]
	mov.s	v5[3], v17[0]
	fmaxnm.4s	v5, v6, v5
	fmaxnm.4s	v6, v7, v3
	movi.4s	v7, #2
	eor.16b	v3, v2, v7
	mov.s	w11, v3[1]
	mov.s	w12, v3[2]
	mov.s	w14, v3[3]
	eor.16b	v20, v1, v7
	fmov	w15, s3
	add	x0, sp, #1496
	bfxil	x0, x15, #0, #3
	ldrb	w0, [x0]
	and	x15, x15, #0x7
	str	q6, [sp, #2032]
	str	q5, [sp, #2016]
	add	x8, sp, #2016
	ldr	s1, [x8, x15, lsl #2]
	tst	w10, w0
	fcsel	s1, s1, s23, ne
	and	x15, x11, #0x7
	add	x0, sp, #1496
	bfxil	x0, x11, #0, #3
	ldrb	w11, [x0]
	and	w11, w17, w11
	str	q6, [sp, #2000]
	str	q5, [sp, #1984]
	add	x8, sp, #1984
	ldr	s3, [x8, x15, lsl #2]
	tst	w11, #0x1
	fcsel	s7, s3, s23, ne
	and	x11, x12, #0x7
	add	x15, sp, #1496
	bfxil	x15, x12, #0, #3
	ldrb	w12, [x15]
	and	w12, w4, w12
	str	q6, [sp, #1968]
	str	q5, [sp, #1952]
	add	x8, sp, #1952
	ldr	s3, [x8, x11, lsl #2]
	tst	w12, #0x1
	fcsel	s19, s3, s23, ne
	and	x11, x14, #0x7
	add	x12, sp, #1496
	bfxil	x12, x14, #0, #3
	ldrb	w12, [x12]
	str	q6, [sp, #1936]
	str	q5, [sp, #1920]
	add	x8, sp, #1920
	ldr	s16, [x8, x11, lsl #2]
	and	w11, w26, w12
	tst	w11, #0x1
	mov.s	w14, v20[3]
	mov.s	w30, v20[1]
	fmov	w11, s20
	and	x8, x11, #0x7
	add	x19, sp, #1496
	bfxil	x19, x11, #0, #3
	add	x11, sp, #1496
	bfxil	x11, x14, #0, #3
	ldrb	w25, [x11]
	movi.4s	v3, #4
	eor.16b	v2, v2, v3
	mov.s	w15, v2[1]
	mov.s	w12, v2[2]
	mov.s	w11, v2[3]
	fmov	w7, s2
	add	x0, sp, #1496
	bfxil	x0, x7, #0, #3
	ldrb	w21, [x0]
	add	x0, sp, #1496
	bfxil	x0, x15, #0, #3
	ldrb	w6, [x0]
	add	x0, sp, #1496
	bfxil	x0, x12, #0, #3
	ldrb	w1, [x0]
	add	x0, sp, #1496
	bfxil	x0, x11, #0, #3
	ldrb	w0, [x0]
	ldrb	w19, [x19]
	str	q6, [sp, #1904]
	str	q5, [sp, #1888]
	add	x27, sp, #1888
	ldr	s2, [x27, x8, lsl #2]
	add	x8, sp, #1496
	bfxil	x8, x30, #0, #3
	and	x30, x30, #0x7
	ldrb	w8, [x8]
	str	q6, [sp, #1872]
	str	q5, [sp, #1856]
	add	x27, sp, #1856
	ldr	s3, [x27, x30, lsl #2]
	fcsel	s16, s16, s23, ne
	and	w19, w2, w19
	tst	w19, #0x1
	mov.s	w19, v20[2]
	fcsel	s2, s2, s23, ne
	and	w8, w24, w8
	tst	w8, #0x1
	add	x8, sp, #1496
	bfxil	x8, x19, #0, #3
	and	x19, x19, #0x7
	ldrb	w8, [x8]
	str	q6, [sp, #1840]
	str	q5, [sp, #1824]
	add	x27, sp, #1824
	ldr	s17, [x27, x19, lsl #2]
	fcsel	s3, s3, s23, ne
	and	w8, w22, w8
	tst	w8, #0x1
	and	x8, x14, #0x7
	str	q6, [sp, #1808]
	str	q5, [sp, #1792]
	add	x14, sp, #1792
	ldr	s20, [x14, x8, lsl #2]
	fcsel	s17, s17, s23, ne
	and	w8, w28, w25
	tst	w8, #0x1
	fcsel	s20, s20, s23, ne
	mov.s	v2[1], v3[0]
	mov.s	v2[2], v17[0]
	mov.s	v2[3], v20[0]
	mov.s	v1[1], v7[0]
	mov.s	v1[2], v19[0]
	mov.s	v1[3], v16[0]
	fmaxnm.4s	v1, v5, v1
	fmaxnm.4s	v2, v6, v2
	and	x8, x7, #0x7
	str	q2, [sp, #1776]
	str	q1, [sp, #1760]
	add	x14, sp, #1760
	ldr	s3, [x14, x8, lsl #2]
	tst	w10, w21
	fcsel	s3, s3, s23, ne
	and	x8, x15, #0x7
	and	w10, w17, w6
	str	q2, [sp, #1744]
	str	q1, [sp, #1728]
	add	x14, sp, #1728
	ldr	s5, [x14, x8, lsl #2]
	tst	w10, #0x1
	fcsel	s5, s5, s23, ne
	and	x8, x12, #0x7
	and	w10, w4, w1
	str	q2, [sp, #1712]
	str	q1, [sp, #1696]
	add	x12, sp, #1696
	ldr	s6, [x12, x8, lsl #2]
	tst	w10, #0x1
	fcsel	s6, s6, s23, ne
	and	x8, x11, #0x7
	and	w10, w26, w0
	str	q2, [sp, #1680]
	str	q1, [sp, #1664]
	add	x11, sp, #1664
	ldr	s2, [x11, x8, lsl #2]
	tst	w10, #0x1
	fcsel	s2, s2, s23, ne
	mov.s	v3[1], v5[0]
	mov.s	v3[2], v6[0]
	mov.s	v3[3], v2[0]
	ands	w0, w5, #0x1
	fmaxnm.4s	v1, v1, v3
	fcsel	s2, s1, s23, ne
	str	w17, [sp, #256]                 ; 4-byte Spill
	and	w8, w17, w5
	str	w8, [sp, #144]                  ; 4-byte Spill
	tst	w8, #0x1
	fcsel	s3, s1, s23, ne
	str	w4, [sp, #272]                  ; 4-byte Spill
	and	w8, w4, w5
	mov	x4, x26
	str	w8, [sp, #140]                  ; 4-byte Spill
	tst	w8, #0x1
	fcsel	s5, s1, s23, ne
	and	w10, w26, w5
	and	w8, w26, w5
	str	w8, [sp, #136]                  ; 4-byte Spill
	tst	w10, #0x1
	fcsel	s6, s1, s23, ne
	str	w2, [sp, #288]                  ; 4-byte Spill
	and	w14, w2, w5
	tst	w14, #0x1
	fcsel	s7, s1, s23, ne
	str	w24, [sp, #224]                 ; 4-byte Spill
	and	w10, w24, w5
	tst	w10, #0x1
	fcsel	s16, s1, s23, ne
	str	w22, [sp, #208]                 ; 4-byte Spill
	and	w12, w22, w5
	tst	w12, #0x1
	fcsel	s17, s1, s23, ne
	str	w28, [sp, #176]                 ; 4-byte Spill
	and	w15, w28, w5
	tst	w15, #0x1
	fcsel	s1, s1, s23, ne
	mov.s	v2[1], v3[0]
	mov.s	v2[2], v5[0]
	mov.s	v2[3], v6[0]
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v1[0]
	ldr	w8, [sp, #308]                  ; 4-byte Reload
	rbit	w8, w8
	clz	w11, w8
	str	q7, [sp, #1520]
	str	q2, [sp, #1504]
	and	x8, x11, #0x7
	add	x6, sp, #1504
	ldr	s1, [x6, x8, lsl #2]
	mov.b	v24[0], wzr
	str	q24, [sp, #480]                 ; 16-byte Spill
	mov	w8, #-8388608                   ; =0xff800000
	fmov	s2, w8
	fmaxnm	s1, s1, s2
	dup.4s	v5, v1[0]
	movi.2d	v14, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	ldr	w1, [sp, #12]                   ; 4-byte Reload
	mov	w19, #32                        ; =0x20
	mov	w7, #-1026555904                ; =0xc2d00000
	mov	w25, #1120403456                ; =0x42c80000
	mov	w27, #43579                     ; =0xaa3b
	movk	w27, #16312, lsl #16
	mov	w30, #29184                     ; =0x7200
	movk	w30, #48945, lsl #16
	ldr	w26, [sp, #252]                 ; 4-byte Reload
	ldr	w22, [sp, #204]                 ; 4-byte Reload
	ldr	w28, [sp, #172]                 ; 4-byte Reload
	b	LBB1_117
LBB1_116:                               ; %else282
                                        ;   in Loop: Header=BB1_117 Depth=2
	ldp	q2, q1, [sp, #736]              ; 32-byte Folded Reload
	cmhi.4s	v2, v2, v1
	lsl	x16, x16, #5
	add	x8, x13, x16
	ldp	q3, q1, [x8]
	fsub.4s	v3, v3, v5
	fsub.4s	v1, v1, v5
	and.16b	v17, v0, v1
	and.16b	v16, v2, v3
	dup.4s	v23, w7
	fcmge.4s	v1, v16, v23
	fcmge.4s	v3, v17, v23
	dup.4s	v10, w25
	fcmge.4s	v6, v10, v16
	fcmge.4s	v19, v10, v17
	and.16b	v3, v3, v19
	and.16b	v1, v1, v6
	and.16b	v1, v1, v16
	and.16b	v3, v3, v17
	dup.4s	v8, w27
	fmul.4s	v6, v3, v8
	fmul.4s	v19, v1, v8
	movi.4s	v21, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	mov.16b	v20, v22
	bsl.16b	v20, v21, v19
	bif.16b	v21, v6, v22
	fadd.4s	v6, v6, v21
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fsub.4s	v6, v6, v21
	fcvtzs.4s	v24, v6
	fcvtzs.4s	v25, v19
	scvtf.4s	v6, v25
	dup.4s	v9, w30
	scvtf.4s	v19, v24
	fmul.4s	v20, v19, v9
	fmul.4s	v21, v6, v9
	fadd.4s	v21, v1, v21
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	dup.4s	v1, w8
	fadd.4s	v3, v3, v20
	fmul.4s	v6, v6, v1
	fmul.4s	v19, v19, v1
	fadd.4s	v3, v3, v19
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v19, w8
	fadd.4s	v28, v21, v6
	fmul.4s	v6, v28, v19
	fmul.4s	v20, v3, v19
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v21, w8
	fadd.4s	v20, v20, v21
	fadd.4s	v6, v6, v21
	fmul.4s	v6, v28, v6
	fmul.4s	v22, v3, v20
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v20, w8
	fadd.4s	v22, v22, v20
	fadd.4s	v6, v6, v20
	fmul.4s	v6, v28, v6
	fmul.4s	v29, v3, v22
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v22, w8
	fadd.4s	v29, v29, v22
	fadd.4s	v6, v6, v22
	fmul.4s	v15, v28, v6
	fmul.4s	v29, v3, v29
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v6, w8
	fadd.4s	v29, v29, v6
	fadd.4s	v15, v15, v6
	fmul.4s	v15, v28, v15
	fmul.4s	v29, v3, v29
	movi.4s	v30, #63, lsl #24
	fadd.4s	v29, v29, v30
	fadd.4s	v15, v15, v30
	fmul.4s	v30, v28, v28
	fmul.4s	v30, v30, v15
	fmul.4s	v15, v3, v3
	fmul.4s	v29, v15, v29
	fadd.4s	v3, v3, v29
	fadd.4s	v28, v28, v30
	fmov.4s	v31, #1.00000000
	fadd.4s	v28, v28, v31
	fadd.4s	v3, v3, v31
	sshr.4s	v29, v25, #1
	sshr.4s	v30, v24, #1
	shl.4s	v15, v30, #23
	add.4s	v15, v15, v31
	fmul.4s	v3, v3, v15
	shl.4s	v15, v29, #23
	add.4s	v15, v15, v31
	fmul.4s	v28, v28, v15
	sub.4s	v24, v24, v30
	sub.4s	v25, v25, v29
	shl.4s	v25, v25, #23
	add.4s	v25, v25, v31
	fmul.4s	v25, v28, v25
	shl.4s	v24, v24, #23
	add.4s	v24, v24, v31
	fmul.4s	v3, v3, v24
	fcmgt.4s	v24, v23, v17
	bic.16b	v3, v3, v24
	fcmgt.4s	v24, v23, v16
	bic.16b	v24, v25, v24
	fcmgt.4s	v25, v16, v10
	ldr	q28, [sp, #688]                 ; 16-byte Reload
	bit.16b	v24, v28, v25
	fcmgt.4s	v25, v17, v10
	bit.16b	v3, v28, v25
	fcmeq.4s	v17, v17, v17
	ldr	q25, [sp, #672]                 ; 16-byte Reload
	bif.16b	v3, v25, v17
	cmeq.8b	v7, v7, #0
	sshll.8h	v7, v7, #0
	fcmeq.4s	v16, v16, v16
	bsl.16b	v16, v24, v25
	sshll.4s	v17, v7, #0
	bic.16b	v16, v16, v17
	sshll2.4s	v7, v7, #0
	bic.16b	v3, v3, v7
	add	x8, x9, x16
	ldr	q7, [x8, #16]
	bif.16b	v3, v7, v0
	ldr	q7, [x8]
	bit.16b	v7, v16, v2
	stp	q7, q3, [x8]
	ldp	q3, q7, [sp, #800]              ; 32-byte Folded Reload
	add.2d	v11, v11, v7
	add.2d	v12, v12, v3
	ldr	q3, [sp, #720]                  ; 16-byte Reload
	add.2d	v13, v13, v3
	ldr	q3, [sp, #784]                  ; 16-byte Reload
	add.2d	v14, v14, v3
	fmov	x16, d14
	cmp	x16, #512
	b.ge	LBB1_133
LBB1_117:                               ; %direct.true174.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	fmov	w6, s1
	ldr	q1, [sp, #544]                  ; 16-byte Reload
	add.2d	v1, v14, v1
	ldr	q2, [sp, #608]                  ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w6, #0, LBB1_119
; %bb.118:                              ; %cond.load236
                                        ;   in Loop: Header=BB1_117 Depth=2
	fmov	x8, d1
	ldr	b7, [x8]
	ldp	q3, q2, [sp, #640]              ; 32-byte Folded Reload
	ldr	q6, [sp, #624]                  ; 16-byte Reload
	ldr	q16, [sp, #592]                 ; 16-byte Reload
	and	w21, w6, #0xff
	tbnz	w21, #1, LBB1_120
	b	LBB1_121
LBB1_119:                               ;   in Loop: Header=BB1_117 Depth=2
	movi.2d	v7, #0000000000000000
	ldp	q3, q2, [sp, #640]              ; 32-byte Folded Reload
	ldr	q6, [sp, #624]                  ; 16-byte Reload
	ldr	q16, [sp, #592]                 ; 16-byte Reload
	and	w21, w6, #0xff
	tbz	w21, #1, LBB1_121
LBB1_120:                               ; %cond.load242
                                        ;   in Loop: Header=BB1_117 Depth=2
	mov.d	x8, v1[1]
	ld1.b	{ v7 }[1], [x8]
LBB1_121:                               ; %else246
                                        ;   in Loop: Header=BB1_117 Depth=2
	ldr	q1, [sp, #576]                  ; 16-byte Reload
	add.2d	v1, v11, v1
	add.2d	v1, v3, v1
	tbnz	w21, #2, LBB1_127
; %bb.122:                              ; %else252
                                        ;   in Loop: Header=BB1_117 Depth=2
	tbnz	w21, #3, LBB1_128
LBB1_123:                               ; %else258
                                        ;   in Loop: Header=BB1_117 Depth=2
	ldr	q1, [sp, #560]                  ; 16-byte Reload
	add.2d	v1, v12, v1
	add.2d	v1, v6, v1
	tbnz	w21, #4, LBB1_129
LBB1_124:                               ; %else264
                                        ;   in Loop: Header=BB1_117 Depth=2
	tbnz	w21, #5, LBB1_130
LBB1_125:                               ; %else270
                                        ;   in Loop: Header=BB1_117 Depth=2
	add.2d	v1, v13, v16
	add.2d	v1, v2, v1
	tbnz	w21, #6, LBB1_131
LBB1_126:                               ; %else276
                                        ;   in Loop: Header=BB1_117 Depth=2
	tbz	w21, #7, LBB1_116
	b	LBB1_132
LBB1_127:                               ; %cond.load248
                                        ;   in Loop: Header=BB1_117 Depth=2
	fmov	x8, d1
	ld1.b	{ v7 }[2], [x8]
	tbz	w21, #3, LBB1_123
LBB1_128:                               ; %cond.load254
                                        ;   in Loop: Header=BB1_117 Depth=2
	mov.d	x8, v1[1]
	ld1.b	{ v7 }[3], [x8]
	ldr	q1, [sp, #560]                  ; 16-byte Reload
	add.2d	v1, v12, v1
	add.2d	v1, v6, v1
	tbz	w21, #4, LBB1_124
LBB1_129:                               ; %cond.load260
                                        ;   in Loop: Header=BB1_117 Depth=2
	fmov	x8, d1
	ld1.b	{ v7 }[4], [x8]
	tbz	w21, #5, LBB1_125
LBB1_130:                               ; %cond.load266
                                        ;   in Loop: Header=BB1_117 Depth=2
	mov.d	x8, v1[1]
	ld1.b	{ v7 }[5], [x8]
	add.2d	v1, v13, v16
	add.2d	v1, v2, v1
	tbz	w21, #6, LBB1_126
LBB1_131:                               ; %cond.load272
                                        ;   in Loop: Header=BB1_117 Depth=2
	fmov	x8, d1
	ld1.b	{ v7 }[6], [x8]
	tbz	w21, #7, LBB1_116
LBB1_132:                               ; %cond.load278
                                        ;   in Loop: Header=BB1_117 Depth=2
	mov.d	x8, v1[1]
	ld1.b	{ v7 }[7], [x8]
	b	LBB1_116
LBB1_133:                               ; %direct.true215.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	d3, [sp, #472]                  ; 8-byte Reload
	fmov	w16, s3
	ldr	q14, [sp, #768]                 ; 16-byte Reload
	tbz	w16, #0, LBB1_139
; %bb.134:                              ; %cond.load285
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q3, [sp, #16]                   ; 16-byte Reload
	fmov	x8, d3
	ldr	b7, [x8]
	ldr	q13, [sp, #496]                 ; 16-byte Reload
	ldr	x6, [sp, #392]                  ; 8-byte Reload
	mov	x27, x1
	mov	w24, #4                         ; =0x4
	tbnz	w16, #1, LBB1_140
	b	LBB1_141
LBB1_135:                               ; %cond.load199
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x11, d26
	ld1.b	{ v1 }[2], [x11]
	tbz	w10, #3, LBB1_107
LBB1_136:                               ; %cond.load205
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[3], [x16]
	tbz	w10, #4, LBB1_108
LBB1_137:                               ; %cond.load211
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x11, d22
	ld1.b	{ v1 }[4], [x11]
	tbz	w10, #5, LBB1_109
LBB1_138:                               ; %cond.load217
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[5], [x15]
	tbnz	w10, #6, LBB1_110
	b	LBB1_111
LBB1_139:                               ;   in Loop: Header=BB1_4 Depth=1
	movi.2d	v7, #0000000000000000
	ldr	q13, [sp, #496]                 ; 16-byte Reload
	ldr	x6, [sp, #392]                  ; 8-byte Reload
	mov	x27, x1
	mov	w24, #4                         ; =0x4
	tbz	w16, #1, LBB1_141
LBB1_140:                               ; %cond.load291
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #40]                   ; 8-byte Reload
	ld1.b	{ v7 }[1], [x8]
LBB1_141:                               ; %else295
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #2, LBB1_177
; %bb.142:                              ; %else301
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #3, LBB1_178
LBB1_143:                               ; %else307
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #4, LBB1_179
LBB1_144:                               ; %else313
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #5, LBB1_180
LBB1_145:                               ; %else319
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #6, LBB1_181
LBB1_146:                               ; %else325
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_148
LBB1_147:                               ; %cond.load327
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #128]                  ; 8-byte Reload
	ld1.b	{ v7 }[7], [x8]
LBB1_148:                               ; %else331
                                        ;   in Loop: Header=BB1_4 Depth=1
	cmeq.8b	v3, v7, #0
	sshll.8h	v3, v3, #0
	sshll2.4s	v7, v3, #0
	sshll.4s	v16, v3, #0
	add	x8, x13, x6
	ldp	q17, q3, [x8]
	fsub.4s	v25, v17, v5
	fsub.4s	v3, v3, v5
	zip2.8b	v5, v13, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v24, v5, v3
	zip1.8b	v3, v13, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v17, v3, #0
	and.16b	v25, v17, v25
	fcmge.4s	v3, v25, v23
	fcmge.4s	v28, v24, v23
	fcmge.4s	v29, v10, v25
	fcmge.4s	v30, v10, v24
	and.16b	v28, v28, v30
	and.16b	v3, v3, v29
	and.16b	v3, v3, v25
	and.16b	v28, v28, v24
	fmul.4s	v29, v28, v8
	fmul.4s	v30, v3, v8
	movi.4s	v8, #75, lsl #24
	mvni.4s	v11, #128, lsl #24
	mov.16b	v31, v11
	bsl.16b	v31, v8, v30
	bif.16b	v8, v29, v11
	fadd.4s	v29, v29, v8
	fadd.4s	v30, v30, v31
	fsub.4s	v30, v30, v31
	fsub.4s	v29, v29, v8
	fcvtzs.4s	v29, v29
	fcvtzs.4s	v30, v30
	scvtf.4s	v31, v30
	scvtf.4s	v8, v29
	fmul.4s	v11, v8, v9
	fmul.4s	v9, v31, v9
	fadd.4s	v3, v3, v9
	fadd.4s	v28, v28, v11
	fmul.4s	v31, v31, v1
	fmul.4s	v1, v8, v1
	fadd.4s	v1, v28, v1
	fadd.4s	v3, v3, v31
	fmul.4s	v28, v3, v19
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v21
	fadd.4s	v21, v28, v21
	fmul.4s	v21, v3, v21
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v20
	fadd.4s	v20, v21, v20
	fmul.4s	v20, v3, v20
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v22
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v3, v20
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v6
	fadd.4s	v6, v20, v6
	fmul.4s	v6, v3, v6
	fmul.4s	v19, v1, v19
	movi.4s	v20, #63, lsl #24
	fadd.4s	v19, v19, v20
	fadd.4s	v6, v6, v20
	fmul.4s	v20, v1, v1
	fmul.4s	v21, v3, v3
	fmul.4s	v6, v21, v6
	fmul.4s	v19, v20, v19
	fadd.4s	v1, v1, v19
	fadd.4s	v3, v3, v6
	fmov.4s	v22, #1.00000000
	fadd.4s	v3, v3, v22
	fadd.4s	v1, v1, v22
	sshr.4s	v6, v30, #1
	sshr.4s	v19, v29, #1
	shl.4s	v20, v19, #23
	shl.4s	v21, v6, #23
	add.4s	v21, v21, v22
	add.4s	v20, v20, v22
	fmul.4s	v1, v1, v20
	fmul.4s	v3, v3, v21
	sub.4s	v19, v29, v19
	sub.4s	v6, v30, v6
	shl.4s	v6, v6, #23
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v22
	add.4s	v6, v6, v22
	fmul.4s	v3, v3, v6
	fmul.4s	v1, v1, v19
	fcmgt.4s	v6, v23, v24
	bic.16b	v1, v1, v6
	fcmgt.4s	v6, v23, v25
	bic.16b	v3, v3, v6
	fcmgt.4s	v6, v24, v10
	fcmgt.4s	v19, v25, v10
	ldp	q20, q21, [sp, #672]            ; 32-byte Folded Reload
	bit.16b	v3, v21, v19
	bit.16b	v1, v21, v6
	fcmeq.4s	v6, v25, v25
	fcmeq.4s	v19, v24, v24
	bif.16b	v1, v20, v19
	bif.16b	v3, v20, v6
	bic.16b	v22, v3, v16
	bic.16b	v23, v1, v7
	add	x8, x9, x6
	ldp	q1, q3, [x8]
	bit.16b	v3, v23, v5
	bit.16b	v1, v22, v17
	stp	q1, q3, [x8]
	ldr	x8, [sp, #312]                  ; 8-byte Reload
	ldp	q1, q3, [x8, #64]
	and.16b	v5, v0, v3
	and.16b	v6, v2, v1
	ldp	q1, q3, [x8, #32]
	and.16b	v19, v0, v3
	and.16b	v7, v2, v1
	ldp	q1, q3, [x8]
	and.16b	v20, v0, v3
	and.16b	v21, v2, v1
	ldr	x8, [sp, #160]                  ; 8-byte Reload
	add	x8, x9, x8
	ldp	q1, q3, [x8]
	and.16b	v17, v0, v3
	and.16b	v16, v2, v1
LBB1_149:                               ; %direct.true215.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v1, v2, #0
	sshll.2d	v3, v0, #0
	sshll2.2d	v28, v2, #0
	add	x8, x9, x3, lsl #5
	ldp	q24, q25, [x8]
	fadd.4s	v24, v16, v24
	fadd.4s	v25, v17, v25
	ldp	q30, q29, [x8, #32]
	fadd.4s	v30, v21, v30
	fadd.4s	v29, v20, v29
	ldp	q8, q31, [x8, #64]
	fadd.4s	v8, v7, v8
	fadd.4s	v31, v19, v31
	ldp	q10, q9, [x8, #96]
	fadd.4s	v10, v6, v10
	fadd.4s	v9, v5, v9
	dup.2d	v11, x24
	and.16b	v12, v14, v11
	add.2d	v27, v27, v12
	and.16b	v28, v28, v11
	add.2d	v18, v18, v28
	and.16b	v3, v3, v11
	add.2d	v26, v26, v3
	and.16b	v1, v1, v11
	add.2d	v4, v4, v1
	bit.16b	v17, v25, v0
	bit.16b	v16, v24, v2
	bit.16b	v20, v29, v0
	bit.16b	v21, v30, v2
	bit.16b	v19, v31, v0
	bit.16b	v7, v8, v2
	bit.16b	v5, v9, v0
	bit.16b	v6, v10, v2
	fmov	x3, d4
	cmp	x3, #512
	b.lt	LBB1_149
; %bb.150:                              ; %direct.false216.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x13, #0                         ; =0x0
	uzp1.8h	v3, v2, v0
	xtn.8b	v26, v3
Lloh58:
	adrp	x8, lCPI1_20@PAGE
Lloh59:
	ldr	q1, [x8, lCPI1_20@PAGEOFF]
	and.16b	v4, v0, v1
Lloh60:
	adrp	x8, lCPI1_21@PAGE
Lloh61:
	ldr	q1, [x8, lCPI1_21@PAGEOFF]
	and.16b	v18, v2, v1
Lloh62:
	adrp	x8, lCPI1_23@PAGE
Lloh63:
	ldr	q1, [x8, lCPI1_23@PAGEOFF]
	and.16b	v1, v2, v1
	fadd.4s	v17, v23, v17
	fadd.4s	v16, v22, v16
	zip1.8b	v22, v13, v0
	ushll.4s	v22, v22, #0
	shl.4s	v22, v22, #31
	cmlt.4s	v22, v22, #0
	and.16b	v16, v22, v16
	zip2.8b	v22, v13, v0
	ushll.4s	v22, v22, #0
	shl.4s	v22, v22, #31
	cmlt.4s	v22, v22, #0
	and.16b	v17, v22, v17
	ldr	q23, [sp, #480]                 ; 16-byte Reload
	zip2.8b	v22, v23, v0
	ushll.4s	v22, v22, #0
	shl.4s	v22, v22, #31
	cmlt.4s	v22, v22, #0
	bit.16b	v17, v25, v22
	zip1.8b	v22, v23, v0
	ushll.4s	v22, v22, #0
	shl.4s	v22, v22, #31
	cmlt.4s	v22, v22, #0
	bit.16b	v16, v24, v22
	fadd.4s	v16, v21, v16
	fadd.4s	v17, v20, v17
	fadd.4s	v17, v19, v17
	fadd.4s	v7, v7, v16
	fadd.4s	v6, v6, v7
	fadd.4s	v5, v5, v17
	fmov	w8, s18
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	str	d26, [sp, #904]
	ldrb	w16, [x16]
	add	x3, sp, #1456
	orr	x8, x3, x8, lsl #2
	str	q5, [sp, #1472]
	str	q6, [sp, #1456]
	ldr	s7, [x8]
	tst	w0, w16
	movi.2d	v22, #0000000000000000
	fcsel	s7, s7, s22, ne
	mov.s	w8, v18[1]
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	ldrb	w8, [x16]
	ldr	w17, [sp, #256]                 ; 4-byte Reload
	and	w8, w17, w8
	str	q6, [sp, #1424]
	ldr	s16, [sp, #1424]
	tst	w8, #0x1
	fcsel	s16, s16, s22, ne
	mov.s	w8, v18[2]
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	add	x3, sp, #1392
	orr	x8, x3, x8, lsl #2
	ldrb	w16, [x16]
	ldr	w2, [sp, #272]                  ; 4-byte Reload
	and	w16, w2, w16
	str	q5, [sp, #1408]
	str	q6, [sp, #1392]
	ldr	s17, [x8]
	tst	w16, #0x1
	fcsel	s17, s17, s22, ne
	mov.s	w8, v18[3]
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	add	x3, sp, #1360
	orr	x8, x3, x8, lsl #2
	ldrb	w16, [x16]
	and	w16, w4, w16
	str	q5, [sp, #1376]
	str	q6, [sp, #1360]
	ldr	s18, [x8]
	tst	w16, #0x1
	fcsel	s18, s18, s22, ne
	fmov	w8, s4
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	ldrb	w16, [x16]
	ldr	w1, [sp, #288]                  ; 4-byte Reload
	and	w16, w1, w16
	str	q5, [sp, #1344]
	str	q6, [sp, #1328]
	add	x3, sp, #1328
	ldr	s19, [x3, w8, uxtw #2]
	tst	w16, #0x1
	fcsel	s19, s19, s22, ne
	mov.s	w8, v4[1]
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	ldrb	w16, [x16]
	ldr	w7, [sp, #224]                  ; 4-byte Reload
	and	w16, w7, w16
	str	q5, [sp, #1312]
	str	q6, [sp, #1296]
	add	x3, sp, #1296
	ldr	s20, [x3, w8, uxtw #2]
	tst	w16, #0x1
	fcsel	s20, s20, s22, ne
	mov.s	w8, v4[2]
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	ldrb	w16, [x16]
	ldr	w21, [sp, #208]                 ; 4-byte Reload
	and	w16, w21, w16
	str	q5, [sp, #1280]
	str	q6, [sp, #1264]
	add	x3, sp, #1264
	ldr	s21, [x3, w8, uxtw #2]
	tst	w16, #0x1
	fcsel	s21, s21, s22, ne
	mov.s	w8, v4[3]
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	ldrb	w16, [x16]
	ldr	w25, [sp, #176]                 ; 4-byte Reload
	and	w16, w25, w16
	str	q5, [sp, #1248]
	str	q6, [sp, #1232]
	add	x3, sp, #1232
	ldr	s4, [x3, w8, uxtw #2]
	tst	w16, #0x1
	fcsel	s4, s4, s22, ne
	mov.s	v19[1], v20[0]
	mov.s	v19[2], v21[0]
	mov.s	v19[3], v4[0]
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v18[0]
	fadd.4s	v4, v6, v7
	fadd.4s	v5, v5, v19
	fmov	w8, s1
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	ldrb	w16, [x16]
	add	x3, sp, #1200
	orr	x8, x3, x8, lsl #2
	str	q5, [sp, #1216]
	str	q4, [sp, #1200]
	ldr	s6, [x8]
	mov.s	w8, v1[1]
	tst	w0, w16
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	ldrb	w16, [x16]
	and	w16, w17, w16
	fcsel	s6, s6, s22, ne
	add	x3, sp, #1168
	orr	x8, x3, x8, lsl #2
	str	q5, [sp, #1184]
	str	q4, [sp, #1168]
	ldr	s16, [x8]
	mov.s	w8, v1[2]
	tst	w16, #0x1
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
Lloh64:
	adrp	x8, lCPI1_22@PAGE
Lloh65:
	ldr	q7, [x8, lCPI1_22@PAGEOFF]
	and.16b	v18, v0, v7
	movi.4s	v7, #4
	and.16b	v7, v2, v7
	fcsel	s16, s16, s22, ne
	ldrb	w8, [x16]
	and	w8, w2, w8
	str	q4, [sp, #1136]
	ldr	s17, [sp, #1136]
	tst	w8, #0x1
	fcsel	s17, s17, s22, ne
	mov.s	w8, v1[3]
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	add	x2, sp, #1104
	orr	x8, x2, x8, lsl #2
	ldrb	w16, [x16]
	and	w16, w4, w16
	str	q5, [sp, #1120]
	str	q4, [sp, #1104]
	ldr	s1, [x8]
	tst	w16, #0x1
	fcsel	s1, s1, s22, ne
	fmov	w8, s18
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	ldrb	w16, [x16]
	and	w16, w1, w16
	str	q5, [sp, #1088]
	str	q4, [sp, #1072]
	add	x2, sp, #1072
	ldr	s19, [x2, w8, uxtw #2]
	tst	w16, #0x1
	fcsel	s19, s19, s22, ne
	mov.s	w8, v18[1]
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	ldrb	w16, [x16]
	and	w16, w7, w16
	str	q5, [sp, #1056]
	str	q4, [sp, #1040]
	add	x2, sp, #1040
	ldr	s20, [x2, w8, uxtw #2]
	tst	w16, #0x1
	fcsel	s20, s20, s22, ne
	mov.s	w8, v18[2]
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	ldrb	w16, [x16]
	and	w16, w21, w16
	stp	q4, q5, [sp, #1008]
	add	x2, sp, #1008
	ldr	s21, [x2, w8, uxtw #2]
	tst	w16, #0x1
	fcsel	s21, s21, s22, ne
	mov.s	w8, v18[3]
	add	x16, sp, #904
	bfxil	x16, x8, #0, #3
	ldrb	w16, [x16]
	and	w16, w25, w16
	stp	q4, q5, [sp, #976]
	add	x2, sp, #976
	ldr	s18, [x2, w8, uxtw #2]
	tst	w16, #0x1
	fcsel	s18, s18, s22, ne
	mov.s	v19[1], v20[0]
	mov.s	v19[2], v21[0]
	mov.s	v19[3], v18[0]
	mov.s	v6[1], v16[0]
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v1[0]
	fadd.4s	v1, v4, v6
	fadd.4s	v4, v5, v19
	fmov	w8, s7
	add	x16, sp, #904
	orr	x16, x16, x8
	ldrb	w16, [x16]
	stp	q1, q4, [sp, #944]
	add	x2, sp, #944
	ldr	s4, [x2, w8, uxtw #2]
	tst	w0, w16
	fcsel	s4, s4, s22, ne
	tst	w5, #0x1
	fadd	s1, s1, s4
	fcsel	s4, s1, s22, ne
	ldr	w8, [sp, #144]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s5, s1, s22, ne
	ldr	w8, [sp, #140]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s6, s1, s22, ne
	ldr	w8, [sp, #136]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s7, s1, s22, ne
	tst	w14, #0x1
	fcsel	s16, s1, s22, ne
	tst	w10, #0x1
	fcsel	s17, s1, s22, ne
	tst	w12, #0x1
	fcsel	s18, s1, s22, ne
	tst	w15, #0x1
	fcsel	s1, s1, s22, ne
	mov.s	v4[1], v5[0]
	mov.s	v4[2], v6[0]
	mov.s	v4[3], v7[0]
	mov.s	v16[1], v17[0]
	mov.s	v16[2], v18[0]
	mov.s	v16[3], v1[0]
	stp	q4, q16, [sp, #912]
	and	x8, x11, #0x7
	add	x10, sp, #912
	ldr	s1, [x10, x8, lsl #2]
	fadd	s1, s1, s22
	dup.4s	v1, v1[0]
	ldr	q4, [sp, #320]                  ; 16-byte Reload
	fmov	x8, d4
	ldp	x15, x14, [sp, #416]            ; 16-byte Folded Reload
	add	x8, x14, x8, lsl #2
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	ldr	q18, [sp, #448]                 ; 16-byte Reload
	movi.8b	v10, #1
	ldr	q19, [sp, #720]                 ; 16-byte Reload
	ldp	q21, q20, [sp, #800]            ; 32-byte Folded Reload
	ldr	q22, [sp, #784]                 ; 16-byte Reload
	b	LBB1_152
LBB1_151:                               ; %else349
                                        ;   in Loop: Header=BB1_152 Depth=2
	add.2d	v5, v5, v20
	add.2d	v6, v6, v21
	add.2d	v7, v7, v19
	add.2d	v4, v4, v22
	fmov	x13, d4
	cmp	x13, #512
	b.ge	LBB1_168
LBB1_152:                               ; %direct.true252.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and.16b	v16, v3, v18
	addv.8h	h16, v16
	fmov	w11, s16
	lsl	x10, x13, #5
	add	x12, x9, x10
	ldp	q17, q16, [x12]
	and.16b	v17, v2, v17
	fdiv.4s	v17, v17, v1
	add	x10, x8, x10
	tbnz	w11, #0, LBB1_160
; %bb.153:                              ; %else335
                                        ;   in Loop: Header=BB1_152 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_161
LBB1_154:                               ; %else337
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbnz	w11, #2, LBB1_162
LBB1_155:                               ; %else339
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbnz	w11, #3, LBB1_163
LBB1_156:                               ; %else341
                                        ;   in Loop: Header=BB1_152 Depth=2
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v1
	tbnz	w11, #4, LBB1_164
LBB1_157:                               ; %else343
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbnz	w11, #5, LBB1_165
LBB1_158:                               ; %else345
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbnz	w11, #6, LBB1_166
LBB1_159:                               ; %else347
                                        ;   in Loop: Header=BB1_152 Depth=2
	tbz	w11, #7, LBB1_151
	b	LBB1_167
LBB1_160:                               ; %cond.store334
                                        ;   in Loop: Header=BB1_152 Depth=2
	str	s17, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_154
LBB1_161:                               ; %cond.store336
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x12, x10, #4
	st1.s	{ v17 }[1], [x12]
	tbz	w11, #2, LBB1_155
LBB1_162:                               ; %cond.store338
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x12, x10, #8
	st1.s	{ v17 }[2], [x12]
	tbz	w11, #3, LBB1_156
LBB1_163:                               ; %cond.store340
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x12, x10, #12
	st1.s	{ v17 }[3], [x12]
	and.16b	v16, v0, v16
	fdiv.4s	v16, v16, v1
	tbz	w11, #4, LBB1_157
LBB1_164:                               ; %cond.store342
                                        ;   in Loop: Header=BB1_152 Depth=2
	str	s16, [x10, #16]
	tbz	w11, #5, LBB1_158
LBB1_165:                               ; %cond.store344
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x12, x10, #20
	st1.s	{ v16 }[1], [x12]
	tbz	w11, #6, LBB1_159
LBB1_166:                               ; %cond.store346
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x12, x10, #24
	st1.s	{ v16 }[2], [x12]
	tbz	w11, #7, LBB1_151
LBB1_167:                               ; %cond.store348
                                        ;   in Loop: Header=BB1_152 Depth=2
	add	x10, x10, #28
	st1.s	{ v16 }[3], [x10]
	b	LBB1_151
LBB1_168:                               ; %direct.false253.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x9, x6
	ldp	q2, q0, [x8]
	zip1.8b	v3, v13, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v2, v3, v2
	ldr	d3, [sp, #472]                  ; 8-byte Reload
	fmov	w8, s3
	fdiv.4s	v2, v2, v1
	ldr	q4, [sp, #400]                  ; 16-byte Reload
	ldp	q6, q5, [sp, #336]              ; 32-byte Folded Reload
	stp	q4, q5, [sp, #832]
	ldr	q3, [sp, #368]                  ; 16-byte Reload
	stp	q6, q3, [sp, #864]
	and	x9, x15, #0x7
	add	x10, sp, #832
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x15
	add	x9, x14, x9, lsl #2
	tbnz	w8, #0, LBB1_182
; %bb.169:                              ; %else352
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #1, LBB1_183
LBB1_170:                               ; %else354
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #2, LBB1_184
LBB1_171:                               ; %else356
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #3, LBB1_173
LBB1_172:                               ; %cond.store357
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #12
	st1.s	{ v2 }[3], [x10]
LBB1_173:                               ; %else358
                                        ;   in Loop: Header=BB1_4 Depth=1
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v0, v2, v0
	fdiv.4s	v0, v0, v1
	tbnz	w8, #4, LBB1_185
; %bb.174:                              ; %else360
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #5, LBB1_186
LBB1_175:                               ; %else362
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #6, LBB1_187
LBB1_176:                               ; %else364
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #7, LBB1_2
	b	LBB1_188
LBB1_177:                               ; %cond.load297
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q3, [sp, #48]                   ; 16-byte Reload
	fmov	x8, d3
	ld1.b	{ v7 }[2], [x8]
	tbz	w16, #3, LBB1_143
LBB1_178:                               ; %cond.load303
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #72]                   ; 8-byte Reload
	ld1.b	{ v7 }[3], [x8]
	tbz	w16, #4, LBB1_144
LBB1_179:                               ; %cond.load309
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q3, [sp, #80]                   ; 16-byte Reload
	fmov	x8, d3
	ld1.b	{ v7 }[4], [x8]
	tbz	w16, #5, LBB1_145
LBB1_180:                               ; %cond.load315
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	ld1.b	{ v7 }[5], [x8]
	tbz	w16, #6, LBB1_146
LBB1_181:                               ; %cond.load321
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q3, [sp, #112]                  ; 16-byte Reload
	fmov	x8, d3
	ld1.b	{ v7 }[6], [x8]
	tbnz	w16, #7, LBB1_147
	b	LBB1_148
LBB1_182:                               ; %cond.store351
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s2, [x9]
	tbz	w8, #1, LBB1_170
LBB1_183:                               ; %cond.store353
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #4
	st1.s	{ v2 }[1], [x10]
	tbz	w8, #2, LBB1_171
LBB1_184:                               ; %cond.store355
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #8
	st1.s	{ v2 }[2], [x10]
	tbnz	w8, #3, LBB1_172
	b	LBB1_173
LBB1_185:                               ; %cond.store359
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9, #16]
	tbz	w8, #5, LBB1_175
LBB1_186:                               ; %cond.store361
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #6, LBB1_176
LBB1_187:                               ; %cond.store363
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w8, #7, LBB1_2
LBB1_188:                               ; %cond.store365
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x9, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB1_2
LBB1_189:                               ; %block.batch.exit
	add	sp, sp, #2528
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdrp	Lloh52, Lloh54
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpAdrp	Lloh48, Lloh50
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdrp	Lloh60, Lloh62
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.full_packet
lCPI0_0:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_1:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_2:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_3:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_4:
	.quad	1536                            ; 0x600
	.quad	1537                            ; 0x601
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	193                             ; 0xc1
lCPI0_6:
	.quad	386                             ; 0x182
	.quad	579                             ; 0x243
lCPI0_7:
	.quad	772                             ; 0x304
	.quad	965                             ; 0x3c5
lCPI0_8:
	.quad	1158                            ; 0x486
	.quad	1351                            ; 0x547
lCPI0_9:
	.long	1536                            ; 0x600
	.long	1537                            ; 0x601
	.long	0                               ; 0x0
	.long	0                               ; 0x0
lCPI0_10:
	.quad	1350                            ; 0x546
	.quad	1543                            ; 0x607
lCPI0_11:
	.quad	964                             ; 0x3c4
	.quad	1157                            ; 0x485
lCPI0_12:
	.quad	578                             ; 0x242
	.quad	771                             ; 0x303
lCPI0_13:
	.quad	192                             ; 0xc0
	.quad	385                             ; 0x181
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-144]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	sub	sp, sp, #7, lsl #12             ; =28672
	sub	sp, sp, #3792
	add	x21, sp, #3, lsl #12            ; =12288
	add	x21, x21, #1648
	ldr	x22, [x0]
	ldr	x19, [x0, #48]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	dup.4s	v0, w8
	str	q0, [sp, #16]                   ; 16-byte Spill
	fmov	s0, w8
	ushll.2d	v0, v0, #0
	fmov	x23, d0
	mov	w24, #6152                      ; =0x1808
	umull	x20, w23, w24
	umaddl	x1, w23, w24, x22
	mov	w25, #6144                      ; =0x1800
	add	x0, sp, #6, lsl #12             ; =24576
	add	x0, x0, #1712
	mov	w2, #6144                       ; =0x1800
	bl	_memcpy
	mov	x9, #0                          ; =0x0
	umaddl	x8, w23, w24, x25
	add	x10, x22, x8
	add	x11, x10, #4
	ldr	s5, [x10]
	ld1.s	{ v5 }[1], [x11]
	str	q5, [x21, #18496]
	movi.2d	v0, #0000000000000000
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x10, lCPI0_1@PAGEOFF]
Lloh4:
	adrp	x10, lCPI0_2@PAGE
Lloh5:
	ldr	q3, [x10, lCPI0_2@PAGEOFF]
Lloh6:
	adrp	x10, lCPI0_3@PAGE
Lloh7:
	ldr	q4, [x10, lCPI0_3@PAGEOFF]
	mov	w10, #1                         ; =0x1
	dup.2d	v6, x10
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB0_1:                                 ; %direct.true69
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v18, v0, #3
	shl.2d	v19, v7, #3
	shl.2d	v20, v16, #3
	shl.2d	v21, v17, #3
	orr.16b	v21, v21, v1
	orr.16b	v20, v20, v2
	orr.16b	v19, v19, v3
	orr.16b	v18, v18, v4
	add	x9, x21, x9, lsl #6
	stp	q18, q19, [x9]
	stp	q20, q21, [x9, #32]
	add.2d	v16, v16, v6
	add.2d	v7, v7, v6
	add.2d	v17, v17, v6
	add.2d	v0, v0, v6
	fmov	x9, d0
	cmp	x9, #192
	b.lt	LBB0_1
; %bb.2:                                ; %direct.false70
	mov	x10, #0                         ; =0x0
Lloh8:
	adrp	x9, lCPI0_4@PAGE
Lloh9:
	ldr	q0, [x9, lCPI0_4@PAGEOFF]
	str	q0, [x21, #12288]
	mov	w9, #7585                       ; =0x1da1
	movk	w9, #2727, lsl #16
	dup.4s	v0, w9
	ldr	q16, [sp, #16]                  ; 16-byte Reload
	umull2.2d	v1, v16, v0
	umull.2d	v2, v16, v0
	uzp2.4s	v2, v2, v1
	ushr.4s	v2, v2, #6
	mov	w9, #1538                       ; =0x602
	dup.4s	v3, w9
	mov.16b	v4, v16
	mls.4s	v4, v2, v3
	umull.2d	v0, v16, v0
	uzp2.4s	v0, v0, v1
	ushr.4s	v0, v0, #6
	mls.4s	v16, v0, v3
	ushll2.2d	v6, v16, #0
	ushll2.2d	v7, v4, #0
	ushll.2d	v16, v16, #0
	ushll.2d	v17, v4, #0
	movi.2d	v18, #0000000000000000
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #104
	dup.2d	v19, x9
Lloh10:
	adrp	x9, lCPI0_5@PAGE
Lloh11:
	ldr	q0, [x9, lCPI0_5@PAGEOFF]
Lloh12:
	adrp	x9, lCPI0_6@PAGE
Lloh13:
	ldr	q1, [x9, lCPI0_6@PAGEOFF]
Lloh14:
	adrp	x9, lCPI0_7@PAGE
Lloh15:
	ldr	q2, [x9, lCPI0_7@PAGEOFF]
	mov	w9, #1                          ; =0x1
	dup.2d	v20, x9
Lloh16:
	adrp	x9, lCPI0_8@PAGE
Lloh17:
	ldr	q3, [x9, lCPI0_8@PAGEOFF]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #1648
	movi.8b	v21, #1
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
LBB0_3:                                 ; %direct.true85
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x9, x10, lsl #6
	ldp	q26, q25, [x10, #32]
	ldp	q27, q28, [x10]
	add.2d	v29, v24, v3
	add.2d	v29, v29, v19
	add.2d	v30, v23, v2
	add.2d	v31, v22, v1
	add.2d	v8, v18, v0
	add.2d	v8, v8, v19
	cmge.2d	v28, v7, v28
	cmge.2d	v27, v17, v27
	uzp1.4s	v27, v27, v28
	cmge.2d	v26, v16, v26
	cmge.2d	v25, v6, v25
	uzp1.4s	v25, v26, v25
	uzp1.8h	v25, v27, v25
	xtn.8b	v25, v25
	and.8b	v25, v25, v21
	mov.d	x10, v8[1]
	fmov	x11, d8
	str	b25, [x11]
	st1.b	{ v25 }[1], [x10]
	add.2d	v26, v31, v19
	mov.d	x10, v26[1]
	fmov	x11, d26
	st1.b	{ v25 }[2], [x11]
	add.2d	v26, v30, v19
	st1.b	{ v25 }[3], [x10]
	mov.d	x10, v26[1]
	fmov	x11, d26
	st1.b	{ v25 }[4], [x11]
	st1.b	{ v25 }[5], [x10]
	mov.d	x10, v29[1]
	fmov	x11, d29
	st1.b	{ v25 }[6], [x11]
	st1.b	{ v25 }[7], [x10]
	add.2d	v23, v23, v20
	add.2d	v22, v22, v20
	add.2d	v24, v24, v20
	add.2d	v18, v18, v20
	fmov	x10, d18
	cmp	x10, #192
	b.lt	LBB0_3
; %bb.4:                                ; %direct.false86
	mov	x10, #0                         ; =0x0
Lloh18:
	adrp	x9, lCPI0_9@PAGE
Lloh19:
	ldr	q16, [x9, lCPI0_9@PAGEOFF]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #104
	dup.2d	v6, x9
Lloh20:
	adrp	x9, lCPI0_13@PAGE
Lloh21:
	ldr	q7, [x9, lCPI0_13@PAGEOFF]
	add.2d	v7, v6, v7
	cmhs.4s	v4, v4, v16
	xtn.4h	v4, v4
	uzp1.8b	v4, v4, v0
	movi.8b	v16, #1
	and.8b	v4, v4, v16
	fmov	x9, d7
	str	b4, [x9]
	mov.d	x9, v7[1]
	st1.b	{ v4 }[1], [x9]
	movi.2d	v4, #0000000000000000
	add	x11, sp, #6, lsl #12            ; =24576
	add	x11, x11, #1712
	mov	w12, #62154                     ; =0xf2ca
	movk	w12, #61769, lsl #16
	dup.4s	v16, w12
	mov	w12, #1                         ; =0x1
	dup.2d	v17, x12
	add	x12, sp, #1, lsl #12            ; =4096
	add	x12, x12, #2120
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB0_5:                                 ; %direct.true101
                                        ; =>This Inner Loop Header: Depth=1
	add.2d	v21, v20, v3
	add.2d	v21, v21, v6
	add.2d	v22, v19, v2
	add.2d	v22, v22, v6
	add.2d	v23, v18, v1
	add.2d	v23, v23, v6
	add.2d	v24, v4, v0
	add.2d	v24, v24, v6
	mov.d	x13, v24[1]
	mov.d	x14, v23[1]
	fmov	x15, d24
	fmov	x16, d23
	mov.d	x17, v22[1]
	fmov	x0, d22
	ldr	b22, [x15]
	ld1.b	{ v22 }[1], [x13]
	ld1.b	{ v22 }[2], [x16]
	mov.d	x13, v21[1]
	ld1.b	{ v22 }[3], [x14]
	ld1.b	{ v22 }[4], [x0]
	ld1.b	{ v22 }[5], [x17]
	fmov	x14, d21
	ld1.b	{ v22 }[6], [x14]
	ld1.b	{ v22 }[7], [x13]
	cmeq.8b	v21, v22, #0
	sshll.8h	v21, v21, #0
	sshll2.4s	v22, v21, #0
	lsl	x10, x10, #5
	add	x13, x11, x10
	ldp	q24, q23, [x13]
	sshll.4s	v21, v21, #0
	bsl.16b	v21, v16, v24
	bsl.16b	v22, v16, v23
	add	x10, x12, x10
	stp	q21, q22, [x10]
	add.2d	v19, v19, v17
	add.2d	v18, v18, v17
	add.2d	v20, v20, v17
	add.2d	v4, v4, v17
	fmov	x10, d4
	cmp	x10, #192
	b.lt	LBB0_5
; %bb.6:                                ; %direct.false102
	fmov	x10, d7
	ldr	b4, [x10]
	ld1.b	{ v4 }[1], [x9]
	cmeq.8b	v4, v4, #0
	sshll.8h	v4, v4, #0
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v6, w9
	str	q4, [sp, #16]                   ; 16-byte Spill
	sshll.4s	v7, v4, #0
	bif.16b	v6, v5, v7
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #3913
	ldur	q7, [x9, #255]
	mov.16b	v4, v6
	mov.d	v4[1], v7[1]
	str	q4, [sp]                        ; 16-byte Spill
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #3913
	stur	q4, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1881
	ldur	q7, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1865
	ldur	q21, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1913
	ldur	q20, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1897
	ldur	q19, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1945
	ldur	q16, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1929
	ldur	q22, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1977
	ldur	q18, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1961
	ldur	q17, [x9, #255]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2120
	add	x9, x9, #224
	mov	w10, #4                         ; =0x4
LBB0_7:                                 ; %direct.true135
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q23, q24, [x9, #-96]
	fmaxnm.4s	v7, v7, v24
	fmaxnm.4s	v21, v21, v23
	ldp	q23, q24, [x9, #-64]
	fmaxnm.4s	v20, v20, v24
	fmaxnm.4s	v19, v19, v23
	ldp	q23, q24, [x9, #-32]
	fmaxnm.4s	v16, v16, v24
	fmaxnm.4s	v22, v22, v23
	ldp	q23, q24, [x9], #128
	fmaxnm.4s	v18, v18, v24
	fmaxnm.4s	v17, v17, v23
	cmp	x10, #188
	add	x10, x10, #4
	b.lo	LBB0_7
; %bb.8:                                ; %direct.false136
	mov	x0, #0                          ; =0x0
	movi.2d	v23, #0000000000000000
	mov.d	v23[0], v6[0]
	fmaxnm.4s	v6, v21, v23
	mov.d	v6[1], v21[1]
	fmaxnm.4s	v7, v7, v20
	fmaxnm.4s	v6, v6, v19
	fmaxnm.4s	v6, v6, v22
	fmaxnm.4s	v7, v7, v16
	fmaxnm.4s	v7, v7, v18
	fmaxnm.4s	v6, v6, v17
	rev64.4s	v16, v6
	rev64.4s	v17, v7
	fmaxnm.4s	v7, v7, v17
	fmaxnm.4s	v6, v6, v16
	ext.16b	v16, v6, v6, #8
	ext.16b	v17, v7, v7, #8
	fmaxnm.4s	v7, v7, v17
	fmaxnm.4s	v6, v6, v16
	fmaxnm.4s	v6, v6, v7
	mov	w9, #-8388608                   ; =0xff800000
	fmov	s7, w9
	fmaxnm	s6, s6, s7
	dup.4s	v6, v6[0]
	movi.2d	v7, #0000000000000000
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #104
	dup.2d	v16, x9
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #2120
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v17, w10
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v18, w10
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v19, w10
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v21, w10
	mvni.4s	v22, #128, lsl #24
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	mov	w11, #11226                     ; =0x2bda
	movk	w11, #14672, lsl #16
	mov	w12, #38601                     ; =0x96c9
	movk	w12, #15030, lsl #16
	mov	w13, #34982                     ; =0x88a6
	movk	w13, #15368, lsl #16
	mov	w14, #43642                     ; =0xaa7a
	movk	w14, #15658, lsl #16
	mov	w15, #43691                     ; =0xaaab
	movk	w15, #15914, lsl #16
	movi.4s	v23, #63, lsl #24
	fmov.4s	v24, #1.00000000
	mvni.4s	v25, #127, msl #16
	fneg.4s	v25, v25
	mvni.4s	v26, #63, msl #16
	fneg.4s	v26, v26
	add	x16, sp, #40
	mov	w17, #1                         ; =0x1
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
LBB0_9:                                 ; %direct.true170
                                        ; =>This Inner Loop Header: Depth=1
	add.2d	v30, v29, v3
	add.2d	v30, v30, v16
	add.2d	v31, v28, v2
	add.2d	v31, v31, v16
	add.2d	v8, v27, v1
	add.2d	v8, v8, v16
	add.2d	v9, v7, v0
	add.2d	v9, v9, v16
	mov.d	x1, v9[1]
	fmov	x2, d9
	mov.d	x3, v8[1]
	fmov	x4, d8
	mov.d	x5, v31[1]
	fmov	x6, d31
	mov.d	x7, v30[1]
	ldr	b8, [x2]
	ld1.b	{ v8 }[1], [x1]
	ld1.b	{ v8 }[2], [x4]
	ld1.b	{ v8 }[3], [x3]
	ld1.b	{ v8 }[4], [x6]
	fmov	x1, d30
	ld1.b	{ v8 }[5], [x5]
	lsl	x0, x0, #5
	ld1.b	{ v8 }[6], [x1]
	add	x1, x9, x0
	ldp	q31, q30, [x1]
	fsub.4s	v30, v30, v6
	ld1.b	{ v8 }[7], [x7]
	fsub.4s	v31, v31, v6
	fcmge.4s	v9, v31, v17
	fcmge.4s	v10, v30, v17
	fcmge.4s	v11, v18, v31
	fcmge.4s	v12, v18, v30
	cmeq.8b	v8, v8, #0
	and.16b	v10, v10, v12
	and.16b	v9, v9, v11
	and.16b	v11, v9, v31
	and.16b	v10, v10, v30
	fmul.4s	v9, v10, v19
	sshll.8h	v12, v8, #0
	fmul.4s	v8, v11, v19
	movi.4s	v4, #75, lsl #24
	mov.16b	v13, v22
	bsl.16b	v13, v4, v8
	mov.16b	v14, v22
	bsl.16b	v14, v4, v9
	fadd.4s	v9, v9, v14
	fadd.4s	v15, v8, v13
	sshll2.4s	v8, v12, #0
	fsub.4s	v13, v15, v13
	fsub.4s	v9, v9, v14
	fcvtzs.4s	v14, v9
	fcvtzs.4s	v13, v13
	scvtf.4s	v15, v13
	sshll.4s	v9, v12, #0
	scvtf.4s	v12, v14
	fmul.4s	v4, v12, v21
	fmul.4s	v5, v15, v21
	dup.4s	v20, w10
	fadd.4s	v5, v11, v5
	fadd.4s	v4, v10, v4
	fmul.4s	v10, v15, v20
	fmul.4s	v20, v12, v20
	dup.4s	v11, w11
	fadd.4s	v4, v4, v20
	fadd.4s	v5, v5, v10
	fmul.4s	v20, v5, v11
	fmul.4s	v10, v4, v11
	dup.4s	v11, w12
	fadd.4s	v10, v10, v11
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v5, v20
	fmul.4s	v10, v4, v10
	dup.4s	v11, w13
	fadd.4s	v10, v10, v11
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v5, v20
	fmul.4s	v10, v4, v10
	dup.4s	v11, w14
	fadd.4s	v10, v10, v11
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v5, v20
	fmul.4s	v10, v4, v10
	dup.4s	v11, w15
	fadd.4s	v10, v10, v11
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v5, v20
	fmul.4s	v10, v4, v10
	fadd.4s	v10, v10, v23
	fadd.4s	v20, v20, v23
	fmul.4s	v11, v4, v4
	fmul.4s	v12, v5, v5
	fmul.4s	v20, v12, v20
	fmul.4s	v10, v11, v10
	fadd.4s	v4, v4, v10
	fadd.4s	v5, v5, v20
	fadd.4s	v5, v5, v24
	sshr.4s	v20, v13, #1
	sshr.4s	v10, v14, #1
	shl.4s	v11, v10, #23
	shl.4s	v12, v20, #23
	add.4s	v12, v12, v24
	fadd.4s	v4, v4, v24
	add.4s	v11, v11, v24
	fmul.4s	v4, v4, v11
	sub.4s	v10, v14, v10
	sub.4s	v20, v13, v20
	shl.4s	v20, v20, #23
	fmul.4s	v5, v5, v12
	shl.4s	v10, v10, #23
	add.4s	v10, v10, v24
	add.4s	v20, v20, v24
	fmul.4s	v5, v5, v20
	fcmgt.4s	v20, v17, v30
	fmul.4s	v4, v4, v10
	bic.16b	v4, v4, v20
	fcmgt.4s	v20, v17, v31
	bic.16b	v5, v5, v20
	fcmgt.4s	v20, v30, v18
	fcmgt.4s	v10, v31, v18
	bit.16b	v5, v25, v10
	bit.16b	v4, v25, v20
	fcmeq.4s	v20, v31, v31
	fcmeq.4s	v30, v30, v30
	bif.16b	v4, v26, v30
	bif.16b	v5, v26, v20
	bic.16b	v5, v5, v9
	bic.16b	v4, v4, v8
	add	x0, x16, x0
	dup.2d	v20, x17
	stp	q5, q4, [x0]
	add.2d	v28, v28, v20
	add.2d	v27, v27, v20
	add.2d	v29, v29, v20
	add.2d	v7, v7, v20
	fmov	x0, d7
	cmp	x0, #192
	b.lt	LBB0_9
; %bb.10:                               ; %direct.false171
	ldp	q2, q0, [sp]                    ; 32-byte Folded Reload
	sshll.4s	v0, v0, #0
	dup.4s	v1, v6[0]
	fsub.4s	v2, v2, v1
	movi.2d	v1, #0000000000000000
	mov.d	v1[0], v2[0]
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v2, w9
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v3, w9
	fcmge.4s	v4, v1, v2
	fcmge.4s	v5, v3, v1
	and.16b	v4, v4, v5
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v5, w9
	and.16b	v4, v4, v1
	fmul.4s	v5, v4, v5
	movi.4s	v6, #75, lsl #24
	mvni.4s	v7, #128, lsl #24
	bif.16b	v6, v5, v7
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v7, w9
	fmul.4s	v7, v6, v7
	fadd.4s	v4, v4, v7
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v7, w9
	fmul.4s	v6, v6, v7
	fadd.4s	v4, v4, v6
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v6, w9
	fmul.4s	v6, v4, v6
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v7, w9
	fadd.4s	v6, v6, v7
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v7, w9
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v4, v6
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v7, w9
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v4, v6
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v7, w9
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v4, v6
	movi.4s	v7, #63, lsl #24
	fadd.4s	v6, v6, v7
	fmul.4s	v7, v4, v4
	fmul.4s	v6, v7, v6
	fadd.4s	v4, v4, v6
	fmov.4s	v6, #1.00000000
	fadd.4s	v4, v4, v6
	sshr.4s	v7, v5, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v6
	fmul.4s	v4, v4, v16
	sub.4s	v5, v5, v7
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v6
	fmul.4s	v4, v4, v5
	fcmgt.4s	v2, v2, v1
	bic.16b	v2, v4, v2
	fcmgt.4s	v3, v1, v3
	mvni.4s	v4, #127, msl #16
	fneg.4s	v4, v4
	bit.16b	v2, v4, v3
	fcmeq.4s	v1, v1, v1
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	bsl.16b	v1, v2, v3
	bic.16b	v0, v1, v0
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1833
	ldur	q1, [x9, #255]
	mov.d	v0[1], v1[1]
	add	x9, sp, #1, lsl #12             ; =4096
	add	x9, x9, #1833
	stur	q0, [x9, #255]
	ldur	q1, [sp, #56]
	ldur	q7, [sp, #40]
	ldur	q6, [sp, #88]
	ldur	q5, [sp, #72]
	ldur	q2, [sp, #120]
	ldur	q16, [sp, #104]
	ldur	q4, [sp, #152]
	ldur	q3, [sp, #136]
	add	x9, sp, #40
	add	x9, x9, #224
	mov	w10, #4                         ; =0x4
LBB0_11:                                ; %direct.true211
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q17, q18, [x9, #-96]
	fadd.4s	v1, v1, v18
	fadd.4s	v7, v7, v17
	ldp	q17, q18, [x9, #-64]
	fadd.4s	v6, v6, v18
	fadd.4s	v5, v5, v17
	ldp	q17, q18, [x9, #-32]
	fadd.4s	v2, v2, v18
	fadd.4s	v16, v16, v17
	ldp	q17, q18, [x9], #128
	fadd.4s	v4, v4, v18
	fadd.4s	v3, v3, v17
	cmp	x10, #188
	add	x10, x10, #4
	b.lo	LBB0_11
; %bb.12:                               ; %direct.false212
	mov	x9, #0                          ; =0x0
	fadd.4s	v17, v0, v7
	mov.d	v17[1], v7[1]
	fadd.4s	v1, v6, v1
	fadd.4s	v5, v5, v17
	fadd.4s	v5, v16, v5
	fadd.4s	v1, v2, v1
	fadd.4s	v1, v4, v1
	fadd.4s	v2, v3, v5
	rev64.4s	v3, v2
	rev64.4s	v4, v1
	fadd.4s	v2, v2, v3
	dup.4s	v3, v2[2]
	fadd.4s	v1, v1, v4
	dup.4s	v4, v1[2]
	fadd.4s	v1, v1, v4
	fadd.4s	v2, v2, v3
	fadd.4s	v1, v2, v1
	movi.2d	v2, #0000000000000000
	fadd	s1, s1, s2
	dup.4s	v1, v1[0]
	add	x10, x19, x20
	add	x11, sp, #40
LBB0_13:                                ; %direct.true248
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x12, x9, #5
	add	x13, x11, x12
	ldp	q3, q2, [x13]
	fdiv.4s	v3, v3, v1
	fdiv.4s	v2, v2, v1
	add	x12, x10, x12
	stp	q3, q2, [x12]
	add	x9, x9, #1
	cmp	x9, #192
	b.ne	LBB0_13
; %bb.14:                               ; %direct.false249
	dup.2s	v1, v1[0]
	fdiv.2s	v0, v0, v1
	str	d0, [x19, x8]
	add	sp, sp, #7, lsl #12             ; =28672
	add	sp, sp, #3792
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #144            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh18, Lloh19
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_12:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI1_13:
	.quad	32                              ; 0x20
	.quad	40                              ; 0x28
lCPI1_14:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI1_15:
	.quad	48                              ; 0x30
	.quad	56                              ; 0x38
lCPI1_16:
	.quad	1158                            ; 0x486
	.quad	1351                            ; 0x547
lCPI1_17:
	.quad	386                             ; 0x182
	.quad	579                             ; 0x243
lCPI1_18:
	.quad	772                             ; 0x304
	.quad	965                             ; 0x3c5
lCPI1_19:
	.quad	0                               ; 0x0
	.quad	193                             ; 0xc1
lCPI1_21:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI1_22:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI1_23:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI1_24:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
lCPI1_20:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #2112
	str	x0, [sp, #480]                  ; 8-byte Spill
	cbz	w3, LBB1_173
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x21, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	add	x23, sp, #2456
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2520
	dup.2d	v0, x8
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh22:
	adrp	x8, lCPI1_0@PAGE
Lloh23:
	ldr	q16, [x8, lCPI1_0@PAGEOFF]
Lloh24:
	adrp	x8, lCPI1_1@PAGE
Lloh25:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #640]                  ; 16-byte Spill
Lloh26:
	adrp	x8, lCPI1_2@PAGE
Lloh27:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #368]                  ; 16-byte Spill
	add	x28, sp, #7, lsl #12            ; =28672
	add	x28, x28, #32
	movi.8b	v14, #1
	mvni.4s	v0, #127, msl #16
	fneg.4s	v1, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q1, [sp, #560]              ; 32-byte Folded Spill
	add	x24, sp, #2, lsl #12            ; =8192
	add	x24, x24, #440
	ldp	w9, w8, [x2, #44]
	str	w9, [sp, #476]                  ; 4-byte Spill
	str	w8, [sp, #472]                  ; 4-byte Spill
	ldp	w19, w11, [x2]
	ldp	w25, w27, [x2, #8]
	str	x27, [sp, #32]                  ; 8-byte Spill
	str	w3, [sp, #364]                  ; 4-byte Spill
	str	q16, [sp, #432]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w21, [sp, #364]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w19, #1
	ldr	w9, [sp, #476]                  ; 4-byte Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w19, wzr, w19, eq
	cinc	w9, w11, eq
	ldr	w10, [sp, #472]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w11, wzr, w9, ne
	add	w25, w25, w8
	add	w22, w22, #1
	cmp	w22, w21
	b.eq	LBB1_173
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_41 Depth 2
                                        ;     Child Loop BB1_44 Depth 2
                                        ;     Child Loop BB1_71 Depth 2
                                        ;     Child Loop BB1_113 Depth 2
                                        ;     Child Loop BB1_116 Depth 2
                                        ;     Child Loop BB1_133 Depth 2
                                        ;     Child Loop BB1_136 Depth 2
	ubfiz	x8, x19, #5, #32
	cmp	x8, x27
	csel	x9, x8, xzr, ls
	subs	x10, x27, x9
	cmp	x10, #32
	mov	w12, #32                        ; =0x20
	csel	x10, x10, x12, lo
	cmp	x27, x9
	stp	w19, w11, [x20]
	str	w11, [sp, #492]                 ; 4-byte Spill
	str	w25, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x27, #2, hi
	csel	x26, x10, xzr, ls
	cmp	x26, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x26, [sp, #480]                 ; 8-byte Reload
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	ldr	w11, [sp, #492]                 ; 4-byte Reload
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x21, x26, #3
	cbz	x21, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #480]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #480]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #480]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x27, [sp, #480]                 ; 8-byte Reload
	mov	x0, x27
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x27
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x27
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x27
	ldr	x27, [sp, #32]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w26, #0x7
	ldr	q16, [sp, #432]                 ; 16-byte Reload
	ldr	w11, [sp, #492]                 ; 4-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v2, w8
	ldr	q0, [sp, #368]                  ; 16-byte Reload
	cmhi.4s	v0, v2, v0
	ldr	q1, [sp, #640]                  ; 16-byte Reload
	str	q2, [sp, #624]                  ; 16-byte Spill
	cmhi.4s	v12, v2, v1
	uzp1.8h	v1, v12, v0
	umaxv.8h	h2, v1
	fmov	w8, s2
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x10, [sp, #480]                 ; 8-byte Reload
	ldr	x9, [x10]
	ldr	x10, [x10, #48]
	str	x10, [sp, #352]                 ; 8-byte Spill
	and.16b	v2, v1, v16
	addv.8h	h5, v2
	fmov	w10, s5
	and	w10, w10, #0xff
	str	w10, [sp, #236]                 ; 4-byte Spill
	ubfiz	w10, w19, #2, #27
	orr	w10, w10, w21
	dup.4s	v2, w10
	and.16b	v3, v12, v2
	and.16b	v22, v0, v2
	ushll2.2d	v6, v22, #0
	ushll2.2d	v7, v3, #0
	ushll.2d	v16, v22, #0
	ushll.2d	v4, v3, #0
	fmov	x10, d4
	mov	w11, #6152                      ; =0x1808
	umaddl	x10, w10, w11, x9
	str	q5, [sp, #592]                  ; 16-byte Spill
	fmov	w11, s5
	add	x16, sp, #3, lsl #12            ; =12288
	add	x16, x16, #4064
	mov	w17, #62154                     ; =0xf2ca
	movk	w17, #61769, lsl #16
	b	LBB1_15
LBB1_14:                                ; %else77
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x12, x28, x8, lsl #5
	stp	q2, q5, [x12]
	add	x8, x8, #1
	cmp	x8, #192
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x13, x8, #5
	add	x12, x10, x13
	add	x14, x28, x13
	ldr	q2, [x14]
	tbnz	w11, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w13, w11, #0xff
	tbnz	w13, #1, LBB1_24
LBB1_17:                                ; %else59
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w13, #2, LBB1_25
LBB1_18:                                ; %else62
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w13, #3, LBB1_26
LBB1_19:                                ; %else65
                                        ;   in Loop: Header=BB1_15 Depth=2
	ldr	q5, [x14, #16]
	tbnz	w13, #4, LBB1_27
LBB1_20:                                ; %else68
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w13, #5, LBB1_28
LBB1_21:                                ; %else71
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w13, #6, LBB1_29
LBB1_22:                                ; %else74
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w13, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	ld1.s	{ v2 }[0], [x12]
	and	w13, w11, #0xff
	tbz	w13, #1, LBB1_17
LBB1_24:                                ; %cond.load58
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x15, x12, #4
	ld1.s	{ v2 }[1], [x15]
	tbz	w13, #2, LBB1_18
LBB1_25:                                ; %cond.load61
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x15, x12, #8
	ld1.s	{ v2 }[2], [x15]
	tbz	w13, #3, LBB1_19
LBB1_26:                                ; %cond.load64
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x15, x12, #12
	ld1.s	{ v2 }[3], [x15]
	ldr	q5, [x14, #16]
	tbz	w13, #4, LBB1_20
LBB1_27:                                ; %cond.load67
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x12, #16
	ld1.s	{ v5 }[0], [x14]
	tbz	w13, #5, LBB1_21
LBB1_28:                                ; %cond.load70
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x12, #20
	ld1.s	{ v5 }[1], [x14]
	tbz	w13, #6, LBB1_22
LBB1_29:                                ; %cond.load73
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x12, #24
	ld1.s	{ v5 }[2], [x14]
	tbz	w13, #7, LBB1_14
LBB1_30:                                ; %cond.load76
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x12, x12, #28
	ld1.s	{ v5 }[3], [x12]
	b	LBB1_14
LBB1_31:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v19, v1
	sshll.2d	v1, v12, #0
	sshll.2d	v2, v0, #0
	sshll2.2d	v10, v12, #0
	sshll2.2d	v8, v0, #0
Lloh28:
	adrp	x8, lCPI1_6@PAGE
Lloh29:
	ldr	q26, [x8, lCPI1_6@PAGEOFF]
	and.16b	v20, v1, v26
Lloh30:
	adrp	x8, lCPI1_7@PAGE
Lloh31:
	ldr	q5, [x8, lCPI1_7@PAGEOFF]
	and.16b	v21, v1, v5
Lloh32:
	adrp	x8, lCPI1_8@PAGE
Lloh33:
	ldr	q1, [x8, lCPI1_8@PAGEOFF]
	and.16b	v1, v2, v1
Lloh34:
	adrp	x8, lCPI1_9@PAGE
Lloh35:
	ldr	q5, [x8, lCPI1_9@PAGEOFF]
	and.16b	v5, v10, v5
Lloh36:
	adrp	x8, lCPI1_10@PAGE
Lloh37:
	ldr	q17, [x8, lCPI1_10@PAGEOFF]
	and.16b	v18, v8, v17
	movi	d17, #0x0000000000ffff
	and.8b	v31, v19, v17
Lloh38:
	adrp	x8, lCPI1_11@PAGE
Lloh39:
	ldr	d17, [x8, lCPI1_11@PAGEOFF]
	stp	q20, q19, [sp, #192]            ; 32-byte Folded Spill
	and.8b	v17, v19, v17
	addv.8b	b17, v17
	fmov	w8, s17
	umaxv.8b	b17, v31
	fmov	w10, s17
	rbit	w11, w8
	clz	w11, w11
	tst	w10, #0x1
	mov	w10, #1536                      ; =0x600
	dup.2d	v25, x10
	csel	w1, w11, wzr, ne
	orr.16b	v19, v20, v25
	mov	w10, #1538                      ; =0x602
	dup.2s	v17, w10
	xtn.2s	v28, v4
	str	q19, [sp, #752]                 ; 16-byte Spill
	umlal.2d	v19, v28, v17
	mov	b4, v31[0]
	mov.b	v4[4], v31[1]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	str	q19, [sp, #320]                 ; 16-byte Spill
	and.16b	v4, v4, v19
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #2368]
	str	q19, [sp, #2352]
	str	q19, [sp, #2336]
	str	q4, [sp, #2320]
	ubfiz	x10, x1, #3, #3
	add	x11, sp, #2320
	ldr	x11, [x11, x10]
	sub	x11, x11, x1
	add	x9, x9, x11, lsl #2
	str	q18, [sp, #2432]
	str	q1, [sp, #2416]
	str	q5, [sp, #2400]
	str	q21, [sp, #176]                 ; 16-byte Spill
	str	q21, [sp, #2384]
	add	x11, sp, #2384
	ldr	x10, [x11, x10]
	orr	x10, x10, #0x1800
	sub	x10, x10, w1, uxtw #2
	tst	w8, #0xff
	csel	x2, xzr, x10, eq
	add	x10, x28, x2
	ldp	q1, q4, [x10]
	tbnz	w8, #0, LBB1_89
; %bb.32:                               ; %else81
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w0, #4                          ; =0x4
	tbnz	w8, #1, LBB1_90
LBB1_33:                                ; %else84
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #2, LBB1_91
LBB1_34:                                ; %else87
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #3, LBB1_92
LBB1_35:                                ; %else90
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #4, LBB1_93
LBB1_36:                                ; %else93
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #5, LBB1_94
LBB1_37:                                ; %else96
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #6, LBB1_95
LBB1_38:                                ; %else99
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #7, LBB1_40
LBB1_39:                                ; %cond.load101
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v4 }[3], [x9]
LBB1_40:                                ; %else102
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	add	x10, x28, x2
	str	q4, [sp, #448]                  ; 16-byte Spill
	stp	q1, q4, [x10]
	str	q1, [sp, #400]                  ; 16-byte Spill
Lloh40:
	adrp	x10, lCPI1_3@PAGE
Lloh41:
	ldr	q1, [x10, lCPI1_3@PAGEOFF]
	and.16b	v18, v8, v1
Lloh42:
	adrp	x10, lCPI1_4@PAGE
Lloh43:
	ldr	q4, [x10, lCPI1_4@PAGEOFF]
	and.16b	v19, v10, v4
Lloh44:
	adrp	x10, lCPI1_5@PAGE
Lloh45:
	ldr	q5, [x10, lCPI1_5@PAGEOFF]
	and.16b	v2, v2, v5
	stp	q2, q19, [sp, #112]             ; 32-byte Folded Spill
	orr.16b	v24, v2, v25
	orr.16b	v27, v19, v25
	str	q18, [sp, #160]                 ; 16-byte Spill
	orr.16b	v25, v18, v25
	umull.2d	v2, v28, v17
	str	q2, [sp, #256]                  ; 16-byte Spill
	xtn.2s	v2, v7
	xtn.2s	v7, v16
	xtn.2s	v6, v6
	mov.16b	v16, v25
	umlal.2d	v16, v6, v17
	mov.16b	v6, v27
	umlal.2d	v6, v2, v17
	stp	q6, q16, [sp, #288]             ; 32-byte Folded Spill
	mov.16b	v2, v24
	umlal.2d	v2, v7, v17
	str	q2, [sp, #272]                  ; 16-byte Spill
	mov	w10, #1                         ; =0x1
	dup.2d	v2, x10
	ushll2.2d	v6, v0, #0
	and.16b	v16, v6, v2
	ushll2.2d	v6, v12, #0
	and.16b	v17, v6, v2
	ushll.2d	v6, v0, #0
	and.16b	v29, v6, v2
	ushll.2d	v6, v12, #0
	and.16b	v30, v6, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	stp	q29, q17, [sp, #672]            ; 32-byte Folded Spill
	str	q30, [sp, #656]                 ; 16-byte Spill
LBB1_41:                                ; %direct.true69.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v20, v0, #0
	sshll.2d	v21, v12, #0
	shl.2d	v28, v19, #3
	shl.2d	v29, v2, #3
	shl.2d	v30, v18, #3
	shl.2d	v9, v6, #3
	orr.16b	v9, v9, v4
	orr.16b	v30, v30, v5
	orr.16b	v29, v29, v26
	orr.16b	v28, v28, v1
	add	x9, x16, x9, lsl #6
	ldp	q13, q11, [x9]
	ldp	q15, q23, [x9, #32]
	bit.16b	v23, v28, v8
	bsl.16b	v21, v29, v13
	bsl.16b	v20, v30, v15
	ldp	q30, q29, [sp, #656]            ; 32-byte Folded Reload
	ldr	q17, [sp, #688]                 ; 16-byte Reload
	mov.16b	v28, v10
	bsl.16b	v28, v9, v11
	stp	q21, q28, [x9]
	stp	q20, q23, [x9, #32]
	add.2d	v6, v6, v17
	add.2d	v18, v18, v29
	add.2d	v19, v19, v16
	add.2d	v2, v2, v30
	fmov	x9, d2
	cmp	x9, #192
	b.lt	LBB1_41
; %bb.42:                               ; %direct.false70.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	mov	w10, #1538                      ; =0x602
	dup.4s	v1, w10
	and.16b	v2, v0, v1
	mvn.16b	v4, v0
	sub.4s	v2, v2, v4
	mov.s	w10, v2[1]
	mov.s	w11, v22[1]
	and.16b	v4, v12, v1
	udiv	w12, w11, w10
	mul	w10, w12, w10
	sub	w10, w11, w10
	mov.s	w11, v2[2]
	mov.s	w12, v2[3]
	fmov	w13, s2
	fmov	w14, s22
	udiv	w15, w14, w13
	mul	w13, w15, w13
	sub	w13, w14, w13
	fmov	s1, w13
	mov.s	v1[1], w10
	mov.s	w10, v22[2]
	mvn.16b	v2, v12
	udiv	w13, w10, w11
	mul	w11, w13, w11
	sub	w10, w10, w11
	mov.s	v1[2], w10
	sub.4s	v2, v4, v2
	mov.s	w10, v22[3]
	udiv	w11, w10, w12
	mul	w11, w11, w12
	sub	w10, w10, w11
	mov.s	v1[3], w10
	mov.s	w10, v2[1]
	mov.s	w11, v3[1]
	udiv	w12, w11, w10
	mul	w10, w12, w10
	sub	w10, w11, w10
	mov.s	w11, v2[2]
	mov.s	w12, v2[3]
	fmov	w13, s2
	fmov	w14, s3
	udiv	w15, w14, w13
	mul	w13, w15, w13
	sub	w13, w14, w13
	fmov	s18, w13
	mov.s	v18[1], w10
	mov.s	w10, v3[2]
	tst	w8, #0xff
	udiv	w8, w10, w11
	mul	w8, w8, w11
	sshll.2d	v21, v0, #0
	sshll.2d	v6, v12, #0
Lloh46:
	adrp	x11, lCPI1_12@PAGE
Lloh47:
	ldr	q2, [x11, lCPI1_12@PAGEOFF]
	and.16b	v2, v6, v2
Lloh48:
	adrp	x11, lCPI1_13@PAGE
Lloh49:
	ldr	q4, [x11, lCPI1_13@PAGEOFF]
	and.16b	v4, v21, v4
Lloh50:
	adrp	x11, lCPI1_14@PAGE
Lloh51:
	ldr	q5, [x11, lCPI1_14@PAGEOFF]
	and.16b	v5, v10, v5
Lloh52:
	adrp	x11, lCPI1_15@PAGE
Lloh53:
	ldr	q19, [x11, lCPI1_15@PAGEOFF]
	and.16b	v19, v8, v19
	str	q19, [sp, #2304]
	str	q4, [sp, #2288]
	str	q5, [sp, #2272]
	str	q2, [sp, #2256]
	sub	w8, w10, w8
	mov.s	v18[2], w8
	mov.s	w8, v3[3]
	udiv	w10, w8, w12
	mul	w10, w10, w12
	and	x11, x1, #0x7
	add	x12, sp, #2256
	ldr	x11, [x12, x11, lsl #3]
	orr	x11, x11, #0x3000
	sub	x11, x11, x1, lsl #3
	csel	x11, xzr, x11, eq
	add	x11, x16, x11
	ldp	q5, q4, [x11, #32]
	ldp	q2, q3, [x11]
	mov	b19, v31[2]
	mov.b	v19[4], v31[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	bit.16b	v3, v27, v19
	mov	b19, v31[0]
	mov.b	v19[4], v31[1]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q7, [sp, #752]                  ; 16-byte Reload
	bit.16b	v2, v7, v19
	mov	b19, v31[6]
	mov.b	v19[4], v31[7]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	bit.16b	v4, v25, v19
	mov	b19, v31[4]
	mov.b	v19[4], v31[5]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	bit.16b	v5, v24, v19
	sub	w8, w8, w10
	mov.s	v18[3], w8
	and.16b	v20, v12, v18
	stp	q5, q4, [x11, #32]
	stp	q2, q3, [x11]
	and.16b	v19, v0, v1
	ushll2.2d	v1, v19, #0
	ushll2.2d	v18, v20, #0
	ushll.2d	v19, v19, #0
	ushll.2d	v20, v20, #0
	ldr	q7, [sp, #16]                   ; 16-byte Reload
	and.16b	v26, v8, v7
	and.16b	v27, v10, v7
	and.16b	v28, v21, v7
	and.16b	v7, v6, v7
Lloh54:
	adrp	x8, lCPI1_16@PAGE
Lloh55:
	ldr	q22, [x8, lCPI1_16@PAGEOFF]
	str	q8, [sp, #416]                  ; 16-byte Spill
	and.16b	v22, v8, v22
	str	q22, [sp, #752]                 ; 16-byte Spill
	mov.16b	v8, v7
Lloh56:
	adrp	x8, lCPI1_17@PAGE
Lloh57:
	ldr	q22, [x8, lCPI1_17@PAGEOFF]
	str	q10, [sp, #608]                 ; 16-byte Spill
	and.16b	v7, v10, v22
	str	q7, [sp, #736]                  ; 16-byte Spill
Lloh58:
	adrp	x8, lCPI1_18@PAGE
Lloh59:
	ldr	q22, [x8, lCPI1_18@PAGEOFF]
	and.16b	v7, v21, v22
	str	q7, [sp, #720]                  ; 16-byte Spill
Lloh60:
	adrp	x8, lCPI1_19@PAGE
Lloh61:
	ldr	q21, [x8, lCPI1_19@PAGEOFF]
	and.16b	v6, v6, v21
	str	q6, [sp, #704]                  ; 16-byte Spill
	ldr	q6, [sp, #368]                  ; 16-byte Reload
	ldp	q21, q7, [sp, #624]             ; 32-byte Folded Reload
	cmhs.4s	v6, v6, v21
	cmhs.4s	v21, v7, v21
	uzp1.8h	v6, v21, v6
	xtn.8b	v21, v6
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v24, #0000000000000000
	ldr	q7, [sp, #592]                  ; 16-byte Reload
	b	LBB1_44
LBB1_43:                                ; %else119
                                        ;   in Loop: Header=BB1_44 Depth=2
	add.2d	v23, v23, v17
	add.2d	v6, v6, v29
	add.2d	v24, v24, v16
	add.2d	v22, v22, v30
	fmov	x9, d22
	cmp	x9, #192
	b.ge	LBB1_60
LBB1_44:                                ; %direct.true85.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w8, s7
	add	x9, x16, x9, lsl #6
	ldp	q9, q25, [x9, #32]
	ldp	q11, q13, [x9]
	cmge.2d	v13, v18, v13
	cmge.2d	v11, v20, v11
	uzp1.4s	v11, v11, v13
	cmge.2d	v9, v19, v9
	cmge.2d	v25, v1, v25
	uzp1.4s	v25, v9, v25
	uzp1.8h	v25, v11, v25
	xtn.8b	v25, v25
	orr.8b	v25, v21, v25
	ldr	q9, [sp, #704]                  ; 16-byte Reload
	add.2d	v9, v22, v9
	add.2d	v9, v8, v9
	and.8b	v25, v25, v14
	tbnz	w8, #0, LBB1_52
; %bb.45:                               ; %else105
                                        ;   in Loop: Header=BB1_44 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB1_53
LBB1_46:                                ; %else107
                                        ;   in Loop: Header=BB1_44 Depth=2
	ldr	q9, [sp, #736]                  ; 16-byte Reload
	add.2d	v9, v23, v9
	add.2d	v9, v27, v9
	tbnz	w8, #2, LBB1_54
LBB1_47:                                ; %else109
                                        ;   in Loop: Header=BB1_44 Depth=2
	tbnz	w8, #3, LBB1_55
LBB1_48:                                ; %else111
                                        ;   in Loop: Header=BB1_44 Depth=2
	ldr	q9, [sp, #720]                  ; 16-byte Reload
	add.2d	v9, v6, v9
	add.2d	v9, v28, v9
	tbnz	w8, #4, LBB1_56
LBB1_49:                                ; %else113
                                        ;   in Loop: Header=BB1_44 Depth=2
	tbnz	w8, #5, LBB1_57
LBB1_50:                                ; %else115
                                        ;   in Loop: Header=BB1_44 Depth=2
	ldr	q9, [sp, #752]                  ; 16-byte Reload
	add.2d	v9, v24, v9
	add.2d	v9, v26, v9
	tbnz	w8, #6, LBB1_58
LBB1_51:                                ; %else117
                                        ;   in Loop: Header=BB1_44 Depth=2
	tbz	w8, #7, LBB1_43
	b	LBB1_59
LBB1_52:                                ; %cond.store
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x9, d9
	str	b25, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB1_46
LBB1_53:                                ; %cond.store106
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x9, v9[1]
	st1.b	{ v25 }[1], [x9]
	ldr	q9, [sp, #736]                  ; 16-byte Reload
	add.2d	v9, v23, v9
	add.2d	v9, v27, v9
	tbz	w8, #2, LBB1_47
LBB1_54:                                ; %cond.store108
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x9, d9
	st1.b	{ v25 }[2], [x9]
	tbz	w8, #3, LBB1_48
LBB1_55:                                ; %cond.store110
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x9, v9[1]
	st1.b	{ v25 }[3], [x9]
	ldr	q9, [sp, #720]                  ; 16-byte Reload
	add.2d	v9, v6, v9
	add.2d	v9, v28, v9
	tbz	w8, #4, LBB1_49
LBB1_56:                                ; %cond.store112
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x9, d9
	st1.b	{ v25 }[4], [x9]
	tbz	w8, #5, LBB1_50
LBB1_57:                                ; %cond.store114
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x9, v9[1]
	st1.b	{ v25 }[5], [x9]
	ldr	q9, [sp, #752]                  ; 16-byte Reload
	add.2d	v9, v24, v9
	add.2d	v9, v26, v9
	tbz	w8, #6, LBB1_51
LBB1_58:                                ; %cond.store116
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x9, d9
	st1.b	{ v25 }[6], [x9]
	tbz	w8, #7, LBB1_43
LBB1_59:                                ; %cond.store118
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x8, v9[1]
	st1.b	{ v25 }[7], [x8]
	b	LBB1_43
LBB1_60:                                ; %direct.false86.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	cmge.2d	v2, v20, v2
	cmge.2d	v3, v18, v3
	uzp1.4s	v2, v2, v3
	cmge.2d	v3, v19, v5
	cmge.2d	v1, v1, v4
	uzp1.4s	v1, v3, v1
	uzp1.8h	v1, v2, v1
	xtn.8b	v1, v1
Lloh62:
	adrp	x8, lCPI1_20@PAGE
Lloh63:
	ldr	d2, [x8, lCPI1_20@PAGEOFF]
	shl.8b	v3, v31, #7
	cmlt.8b	v3, v3, #0
	and.8b	v2, v3, v2
	addv.8b	b21, v2
	fmov	w12, s21
	orn.8b	v1, v1, v31
	ldr	q2, [sp, #704]                  ; 16-byte Reload
	add.2d	v3, v2, v8
	mov	w8, #192                        ; =0xc0
	dup.2d	v2, x8
	add.2d	v15, v3, v2
	and.8b	v1, v1, v14
	tbnz	w12, #0, LBB1_96
; %bb.61:                               ; %else124
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x11, v15[1]
	tbnz	w12, #1, LBB1_97
LBB1_62:                                ; %else128
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	add.2d	v3, v3, v27
	add.2d	v13, v3, v2
	tbnz	w12, #2, LBB1_98
LBB1_63:                                ; %else132
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x10, v13[1]
	tbnz	w12, #3, LBB1_99
LBB1_64:                                ; %else136
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q3, [sp, #720]                  ; 16-byte Reload
	add.2d	v3, v3, v28
	add.2d	v22, v3, v2
	tbnz	w12, #4, LBB1_100
LBB1_65:                                ; %else140
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x9, v22[1]
	tbnz	w12, #5, LBB1_101
LBB1_66:                                ; %else144
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q3, [sp, #752]                  ; 16-byte Reload
	add.2d	v3, v3, v26
	add.2d	v3, v3, v2
	tbnz	w12, #6, LBB1_102
LBB1_67:                                ; %else148
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x8, v3[1]
	tbz	w12, #7, LBB1_69
LBB1_68:                                ; %cond.store149
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[7], [x8]
LBB1_69:                                ; %else152
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	movi.2d	v18, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v2, #0000000000000000
	b	LBB1_71
LBB1_70:                                ; %else184
                                        ;   in Loop: Header=BB1_71 Depth=2
	cmeq.8b	v1, v1, #0
	sshll.8h	v1, v1, #0
	sshll2.4s	v6, v1, #0
	sshll.4s	v1, v1, #0
	lsl	x12, x12, #5
	add	x13, x28, x12
	ldp	q19, q20, [x13]
	and.16b	v20, v0, v20
	and.16b	v19, v12, v19
	dup.4s	v9, w17
	bsl.16b	v1, v9, v19
	bsl.16b	v6, v9, v20
	add	x12, x24, x12
	ldp	q19, q20, [x12]
	bif.16b	v6, v20, v0
	bif.16b	v1, v19, v12
	stp	q1, q6, [x12]
	add.2d	v4, v4, v17
	add.2d	v5, v5, v29
	add.2d	v2, v2, v16
	add.2d	v18, v18, v30
	fmov	x12, d18
	cmp	x12, #192
	b.ge	LBB1_87
LBB1_71:                                ; %direct.true101.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s7
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	add.2d	v1, v18, v1
	add.2d	v6, v8, v1
	tbz	w13, #0, LBB1_73
; %bb.72:                               ; %cond.load154
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x14, d6
	ldr	b1, [x14]
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_74
	b	LBB1_75
LBB1_73:                                ;   in Loop: Header=BB1_71 Depth=2
	movi.2d	v1, #0000000000000000
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_75
LBB1_74:                                ; %cond.load158
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x14, v6[1]
	ld1.b	{ v1 }[1], [x14]
LBB1_75:                                ; %else160
                                        ;   in Loop: Header=BB1_71 Depth=2
	ldr	q6, [sp, #736]                  ; 16-byte Reload
	add.2d	v6, v4, v6
	add.2d	v6, v27, v6
	tbnz	w13, #2, LBB1_81
; %bb.76:                               ; %else164
                                        ;   in Loop: Header=BB1_71 Depth=2
	tbnz	w13, #3, LBB1_82
LBB1_77:                                ; %else168
                                        ;   in Loop: Header=BB1_71 Depth=2
	ldr	q6, [sp, #720]                  ; 16-byte Reload
	add.2d	v6, v5, v6
	add.2d	v6, v28, v6
	tbnz	w13, #4, LBB1_83
LBB1_78:                                ; %else172
                                        ;   in Loop: Header=BB1_71 Depth=2
	tbnz	w13, #5, LBB1_84
LBB1_79:                                ; %else176
                                        ;   in Loop: Header=BB1_71 Depth=2
	ldr	q6, [sp, #752]                  ; 16-byte Reload
	add.2d	v6, v2, v6
	add.2d	v6, v26, v6
	tbnz	w13, #6, LBB1_85
LBB1_80:                                ; %else180
                                        ;   in Loop: Header=BB1_71 Depth=2
	tbz	w13, #7, LBB1_70
	b	LBB1_86
LBB1_81:                                ; %cond.load162
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x14, d6
	ld1.b	{ v1 }[2], [x14]
	tbz	w13, #3, LBB1_77
LBB1_82:                                ; %cond.load166
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x14, v6[1]
	ld1.b	{ v1 }[3], [x14]
	ldr	q6, [sp, #720]                  ; 16-byte Reload
	add.2d	v6, v5, v6
	add.2d	v6, v28, v6
	tbz	w13, #4, LBB1_78
LBB1_83:                                ; %cond.load170
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x14, d6
	ld1.b	{ v1 }[4], [x14]
	tbz	w13, #5, LBB1_79
LBB1_84:                                ; %cond.load174
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x14, v6[1]
	ld1.b	{ v1 }[5], [x14]
	ldr	q6, [sp, #752]                  ; 16-byte Reload
	add.2d	v6, v2, v6
	add.2d	v6, v26, v6
	tbz	w13, #6, LBB1_80
LBB1_85:                                ; %cond.load178
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x14, d6
	ld1.b	{ v1 }[6], [x14]
	tbz	w13, #7, LBB1_70
LBB1_86:                                ; %cond.load182
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x13, v6[1]
	ld1.b	{ v1 }[7], [x13]
	b	LBB1_70
LBB1_87:                                ; %direct.true135.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w12, s21
	tbz	w12, #0, LBB1_103
; %bb.88:                               ; %cond.load187
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x13, d15
	ldr	b1, [x13]
	ldr	q29, [sp, #416]                 ; 16-byte Reload
	ldr	q30, [sp, #608]                 ; 16-byte Reload
	tbnz	w12, #1, LBB1_104
	b	LBB1_105
LBB1_89:                                ; %cond.load80
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v1 }[0], [x9]
	mov	w0, #4                          ; =0x4
	tbz	w8, #1, LBB1_33
LBB1_90:                                ; %cond.load83
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #4
	ld1.s	{ v1 }[1], [x10]
	tbz	w8, #2, LBB1_34
LBB1_91:                                ; %cond.load86
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #8
	ld1.s	{ v1 }[2], [x10]
	tbz	w8, #3, LBB1_35
LBB1_92:                                ; %cond.load89
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #12
	ld1.s	{ v1 }[3], [x10]
	tbz	w8, #4, LBB1_36
LBB1_93:                                ; %cond.load92
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #16
	ld1.s	{ v4 }[0], [x10]
	tbz	w8, #5, LBB1_37
LBB1_94:                                ; %cond.load95
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #20
	ld1.s	{ v4 }[1], [x10]
	tbz	w8, #6, LBB1_38
LBB1_95:                                ; %cond.load98
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #24
	ld1.s	{ v4 }[2], [x10]
	tbnz	w8, #7, LBB1_39
	b	LBB1_40
LBB1_96:                                ; %cond.store121
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x8, d15
	str	b1, [x8]
	mov.d	x11, v15[1]
	tbz	w12, #1, LBB1_62
LBB1_97:                                ; %cond.store125
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[1], [x11]
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	add.2d	v3, v3, v27
	add.2d	v13, v3, v2
	tbz	w12, #2, LBB1_63
LBB1_98:                                ; %cond.store129
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x8, d13
	st1.b	{ v1 }[2], [x8]
	mov.d	x10, v13[1]
	tbz	w12, #3, LBB1_64
LBB1_99:                                ; %cond.store133
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[3], [x10]
	ldr	q3, [sp, #720]                  ; 16-byte Reload
	add.2d	v3, v3, v28
	add.2d	v22, v3, v2
	tbz	w12, #4, LBB1_65
LBB1_100:                               ; %cond.store137
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x8, d22
	st1.b	{ v1 }[4], [x8]
	mov.d	x9, v22[1]
	tbz	w12, #5, LBB1_66
LBB1_101:                               ; %cond.store141
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[5], [x9]
	ldr	q3, [sp, #752]                  ; 16-byte Reload
	add.2d	v3, v3, v26
	add.2d	v3, v3, v2
	tbz	w12, #6, LBB1_67
LBB1_102:                               ; %cond.store145
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x8, d3
	st1.b	{ v1 }[6], [x8]
	mov.d	x8, v3[1]
	tbnz	w12, #7, LBB1_68
	b	LBB1_69
LBB1_103:                               ;   in Loop: Header=BB1_4 Depth=1
	movi.2d	v1, #0000000000000000
	ldr	q29, [sp, #416]                 ; 16-byte Reload
	ldr	q30, [sp, #608]                 ; 16-byte Reload
	tbz	w12, #1, LBB1_105
LBB1_104:                               ; %cond.load193
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[1], [x11]
LBB1_105:                               ; %else197
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #2, LBB1_161
; %bb.106:                              ; %else203
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #3, LBB1_162
LBB1_107:                               ; %else209
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #4, LBB1_163
LBB1_108:                               ; %else215
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #5, LBB1_164
LBB1_109:                               ; %else221
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #6, LBB1_165
LBB1_110:                               ; %else227
                                        ;   in Loop: Header=BB1_4 Depth=1
	stp	q27, q26, [sp, #528]            ; 32-byte Folded Spill
	stp	q8, q28, [sp, #496]             ; 32-byte Folded Spill
	str	d21, [sp, #240]                 ; 8-byte Spill
	tbz	w12, #7, LBB1_112
LBB1_111:                               ; %cond.load229
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[7], [x8]
LBB1_112:                               ; %else233
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w25, [sp, #108]                 ; 4-byte Spill
	str	w22, [sp, #156]                 ; 4-byte Spill
	str	q16, [sp, #608]                 ; 16-byte Spill
	str	x1, [sp, #344]                  ; 8-byte Spill
	sshll.2d	v2, v12, #0
	sshll.2d	v3, v0, #0
	cmeq.8b	v1, v1, #0
	sshll.8h	v1, v1, #0
	sshll2.4s	v7, v1, #0
	str	q1, [sp, #48]                   ; 16-byte Spill
	sshll.4s	v1, v1, #0
	zip2.8b	v4, v31, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q5, [sp, #448]                  ; 16-byte Reload
	and.16b	v5, v4, v5
	str	q31, [sp, #448]                 ; 16-byte Spill
	zip1.8b	v6, v31, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q16, [sp, #400]                 ; 16-byte Reload
	and.16b	v18, v6, v16
	mov.16b	v16, v1
	bsl.16b	v16, v9, v18
	str	q7, [sp, #80]                   ; 16-byte Spill
	bsl.16b	v7, v9, v5
	str	x2, [sp, #248]                  ; 8-byte Spill
	add	x8, x24, x2
	ldp	q1, q5, [x8]
	stp	q7, q16, [sp, #384]             ; 32-byte Folded Spill
	bsl.16b	v4, v7, v5
	bit.16b	v1, v16, v6
	stp	q1, q4, [x8]
	ldr	q1, [sp, #176]                  ; 16-byte Reload
	fmov	x8, d1
	dup.2d	v1, x0
	and.16b	v15, v29, v1
	and.16b	v8, v30, v1
	and.16b	v10, v3, v1
	and.16b	v18, v2, v1
	fmov	x16, d18
	ldr	q2, [x23, #6272]
	ldr	q1, [x23, #6288]
	and.16b	v1, v0, v1
	and.16b	v2, v12, v2
	ldr	q3, [x23, #6240]
	ldr	q4, [x23, #6256]
	and.16b	v4, v0, v4
	and.16b	v3, v12, v3
	ldr	q6, [x23, #6208]
	ldr	q5, [x23, #6224]
	and.16b	v5, v0, v5
	and.16b	v19, v12, v6
	str	x8, [sp, #72]                   ; 8-byte Spill
	add	x8, x24, x8
	ldp	q6, q20, [x8]
	and.16b	v20, v0, v20
	mov	x8, x16
	and.16b	v21, v12, v6
	mov.16b	v22, v18
	mov.16b	v23, v8
	mov.16b	v24, v10
	mov.16b	v25, v15
LBB1_113:                               ; %direct.true135.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v11, v12, #0
	sshll.2d	v13, v0, #0
	add	x8, x24, x8, lsl #5
	ldp	q6, q9, [x8]
	and.16b	v9, v0, v9
	and.16b	v6, v12, v6
	fmaxnm.4s	v6, v21, v6
	fmaxnm.4s	v9, v20, v9
	ldp	q31, q14, [x8, #32]
	and.16b	v14, v0, v14
	and.16b	v31, v12, v31
	fmaxnm.4s	v31, v19, v31
	fmaxnm.4s	v14, v5, v14
	ldp	q26, q7, [x8, #64]
	and.16b	v7, v0, v7
	and.16b	v26, v12, v26
	fmaxnm.4s	v26, v3, v26
	fmaxnm.4s	v7, v4, v7
	ldp	q16, q27, [x8, #96]
	and.16b	v27, v0, v27
	and.16b	v16, v12, v16
	fmaxnm.4s	v16, v2, v16
	fmaxnm.4s	v27, v1, v27
	dup.2d	v17, x0
	and.16b	v28, v29, v17
	add.2d	v25, v25, v28
	and.16b	v28, v30, v17
	add.2d	v23, v23, v28
	and.16b	v28, v13, v17
	add.2d	v24, v24, v28
	and.16b	v17, v11, v17
	add.2d	v22, v22, v17
	bit.16b	v20, v9, v0
	bit.16b	v21, v6, v12
	bit.16b	v5, v14, v0
	bit.16b	v19, v31, v12
	bit.16b	v4, v7, v0
	bit.16b	v3, v26, v12
	bit.16b	v1, v27, v0
	bit.16b	v2, v16, v12
	fmov	x8, d22
	cmp	x8, #192
	b.lt	LBB1_113
; %bb.114:                              ; %direct.false136.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	movi	d7, #0xffffffffffff0000
	ldr	q23, [sp, #208]                 ; 16-byte Reload
	and.8b	v24, v23, v7
	ldr	q17, [sp, #448]                 ; 16-byte Reload
	zip1.8b	v7, v17, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	ldp	q22, q16, [sp, #384]            ; 32-byte Folded Reload
	and.16b	v16, v7, v16
	zip2.8b	v17, v17, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v22, v17, v22
	fmaxnm.4s	v20, v20, v22
	fmaxnm.4s	v16, v21, v16
	and.16b	v7, v7, v16
	and.16b	v16, v17, v20
	zip2.8b	v17, v24, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v16, v9, v17
	str	d24, [sp, #64]                  ; 8-byte Spill
	zip1.8b	v17, v24, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bif.16b	v6, v7, v17
	fmaxnm.4s	v6, v6, v19
	fmaxnm.4s	v5, v16, v5
	fmaxnm.4s	v4, v5, v4
	fmaxnm.4s	v3, v6, v3
	fmaxnm.4s	v3, v3, v2
	fmaxnm.4s	v22, v4, v1
	ldr	q1, [sp, #192]                  ; 16-byte Reload
	ldp	q2, q4, [sp, #112]              ; 32-byte Folded Reload
	uzp1.4s	v5, v1, v4
	ldr	q1, [sp, #160]                  ; 16-byte Reload
	uzp1.4s	v2, v2, v1
	movi.4s	v4, #1
	eor.16b	v1, v5, v4
	mov.s	w10, v1[1]
	eor.16b	v20, v2, v4
	mov.s	w11, v1[2]
	mov.s	w14, v1[3]
	fmov	w8, s1
	add	x12, sp, #1432
	bfxil	x12, x8, #0, #3
	str	d23, [sp, #1432]
	ldrb	w13, [x12]
	umov.b	w22, v23[0]
	and	x8, x8, #0x7
	str	q22, [sp, #2096]
	str	q3, [sp, #2080]
	add	x15, sp, #2080
	ldr	s1, [x15, x8, lsl #2]
	ands	w8, w22, #0x1
	tst	w8, w13
	movi.2d	v21, #0000000000000000
	fcsel	s4, s1, s21, ne
	and	x13, x10, #0x7
	add	x15, sp, #1432
	bfxil	x15, x10, #0, #3
	ldrb	w10, [x15]
	umov.b	w12, v23[1]
	str	q22, [sp, #2064]
	str	q3, [sp, #2048]
	add	x17, sp, #2048
	ldr	s1, [x17, x13, lsl #2]
	and	w10, w12, w10
	tst	w10, #0x1
	fcsel	s1, s1, s21, ne
	and	x10, x11, #0x7
	add	x13, sp, #1432
	bfxil	x13, x11, #0, #3
	ldrb	w11, [x13]
	umov.b	w25, v23[2]
	and	w11, w25, w11
	str	q22, [sp, #2032]
	str	q3, [sp, #2016]
	add	x17, sp, #2016
	ldr	s6, [x17, x10, lsl #2]
	tst	w11, #0x1
	fcsel	s19, s6, s21, ne
	and	x10, x14, #0x7
	add	x11, sp, #1432
	bfxil	x11, x14, #0, #3
	ldrb	w11, [x11]
	umov.b	w15, v23[3]
	and	w11, w15, w11
	str	q22, [sp, #2000]
	str	q3, [sp, #1984]
	add	x17, sp, #1984
	ldr	s6, [x17, x10, lsl #2]
	tst	w11, #0x1
	mov.s	w10, v20[1]
	fcsel	s6, s6, s21, ne
	mov.s	w11, v20[2]
	mov.s	w17, v20[3]
	fmov	w0, s20
	and	x1, x0, #0x7
	add	x2, sp, #1432
	bfxil	x2, x0, #0, #3
	ldrb	w2, [x2]
	umov.b	w14, v23[4]
	and	w2, w14, w2
	str	q22, [sp, #2224]
	str	q3, [sp, #2208]
	add	x0, sp, #2208
	ldr	s7, [x0, x1, lsl #2]
	tst	w2, #0x1
	fcsel	s7, s7, s21, ne
	and	x1, x10, #0x7
	add	x2, sp, #1432
	bfxil	x2, x10, #0, #3
	umov.b	w13, v23[5]
	ldrb	w10, [x2]
	and	w10, w13, w10
	str	q22, [sp, #2192]
	str	q3, [sp, #2176]
	add	x0, sp, #2176
	ldr	s16, [x0, x1, lsl #2]
	tst	w10, #0x1
	fcsel	s16, s16, s21, ne
	and	x10, x11, #0x7
	add	x1, sp, #1432
	bfxil	x1, x11, #0, #3
	ldrb	w11, [x1]
	umov.b	w1, v23[6]
	str	q22, [sp, #2160]
	str	q3, [sp, #2144]
	add	x0, sp, #2144
	ldr	s17, [x0, x10, lsl #2]
	and	w10, w1, w11
	tst	w10, #0x1
	fcsel	s17, s17, s21, ne
	and	x10, x17, #0x7
	add	x11, sp, #1432
	bfxil	x11, x17, #0, #3
	ldrb	w11, [x11]
	umov.b	w2, v23[7]
	and	w11, w2, w11
	str	q22, [sp, #2128]
	str	q3, [sp, #2112]
	add	x17, sp, #2112
	ldr	s20, [x17, x10, lsl #2]
	tst	w11, #0x1
	fcsel	s20, s20, s21, ne
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v20[0]
	mov.s	v4[1], v1[0]
	mov.s	v4[2], v19[0]
	mov.s	v4[3], v6[0]
	fmaxnm.4s	v3, v3, v4
	fmaxnm.4s	v4, v22, v7
	movi.4s	v6, #2
	eor.16b	v1, v5, v6
	mov.s	w10, v1[1]
	mov.s	w11, v1[2]
	eor.16b	v20, v2, v6
	mov.s	w17, v1[3]
	fmov	w3, s1
	add	x4, sp, #1432
	bfxil	x4, x3, #0, #3
	ldrb	w4, [x4]
	and	x3, x3, #0x7
	str	q4, [sp, #1968]
	str	q3, [sp, #1952]
	add	x0, sp, #1952
	ldr	s1, [x0, x3, lsl #2]
	tst	w8, w4
	fcsel	s2, s1, s21, ne
	and	x3, x10, #0x7
	add	x4, sp, #1432
	bfxil	x4, x10, #0, #3
	ldrb	w10, [x4]
	and	w10, w12, w10
	str	q4, [sp, #1936]
	str	q3, [sp, #1920]
	add	x0, sp, #1920
	ldr	s1, [x0, x3, lsl #2]
	tst	w10, #0x1
	fcsel	s1, s1, s21, ne
	and	x10, x11, #0x7
	add	x3, sp, #1432
	bfxil	x3, x11, #0, #3
	ldrb	w11, [x3]
	and	w11, w25, w11
	str	q4, [sp, #1904]
	str	q3, [sp, #1888]
	add	x0, sp, #1888
	ldr	s6, [x0, x10, lsl #2]
	tst	w11, #0x1
	fcsel	s19, s6, s21, ne
	and	x10, x17, #0x7
	add	x11, sp, #1432
	bfxil	x11, x17, #0, #3
	ldrb	w11, [x11]
	and	w11, w15, w11
	str	q4, [sp, #1872]
	str	q3, [sp, #1856]
	add	x17, sp, #1856
	ldr	s6, [x17, x10, lsl #2]
	tst	w11, #0x1
	mov.s	w30, v20[3]
	fmov	w10, s20
	and	x26, x10, #0x7
	add	x0, sp, #1432
	bfxil	x0, x10, #0, #3
	add	x10, sp, #1432
	bfxil	x10, x30, #0, #3
	ldrb	w17, [x10]
	movi.4s	v7, #4
	eor.16b	v5, v5, v7
	mov.s	w3, v5[1]
	mov.s	w11, v5[2]
	mov.s	w10, v5[3]
	fmov	w21, s5
	add	x4, sp, #1432
	bfxil	x4, x21, #0, #3
	ldrb	w6, [x4]
	add	x4, sp, #1432
	bfxil	x4, x3, #0, #3
	ldrb	w7, [x4]
	add	x4, sp, #1432
	bfxil	x4, x11, #0, #3
	ldrb	w5, [x4]
	add	x4, sp, #1432
	bfxil	x4, x10, #0, #3
	ldrb	w4, [x4]
	ldrb	w0, [x0]
	str	q4, [sp, #1840]
	str	q3, [sp, #1824]
	add	x27, sp, #1824
	ldr	s5, [x27, x26, lsl #2]
	mov.s	w26, v20[1]
	fcsel	s6, s6, s21, ne
	and	w0, w14, w0
	tst	w0, #0x1
	add	x0, sp, #1432
	bfxil	x0, x26, #0, #3
	and	x26, x26, #0x7
	ldrb	w0, [x0]
	str	q4, [sp, #1808]
	str	q3, [sp, #1792]
	add	x27, sp, #1792
	ldr	s7, [x27, x26, lsl #2]
	mov.s	w26, v20[2]
	fcsel	s5, s5, s21, ne
	and	w0, w13, w0
	tst	w0, #0x1
	add	x0, sp, #1432
	bfxil	x0, x26, #0, #3
	and	x26, x26, #0x7
	ldrb	w0, [x0]
	str	q4, [sp, #1776]
	str	q3, [sp, #1760]
	add	x27, sp, #1760
	ldr	s16, [x27, x26, lsl #2]
	fcsel	s7, s7, s21, ne
	and	w0, w1, w0
	tst	w0, #0x1
	and	x0, x30, #0x7
	str	q4, [sp, #1744]
	str	q3, [sp, #1728]
	add	x26, sp, #1728
	ldr	s17, [x26, x0, lsl #2]
	fcsel	s16, s16, s21, ne
	and	w17, w2, w17
	tst	w17, #0x1
	fcsel	s17, s17, s21, ne
	mov.s	v5[1], v7[0]
	mov.s	v5[2], v16[0]
	mov.s	v5[3], v17[0]
	mov.s	v2[1], v1[0]
	mov.s	v2[2], v19[0]
	mov.s	v2[3], v6[0]
	fmaxnm.4s	v1, v3, v2
	fmaxnm.4s	v2, v4, v5
	and	x17, x21, #0x7
	str	q2, [sp, #1712]
	str	q1, [sp, #1696]
	add	x0, sp, #1696
	ldr	s3, [x0, x17, lsl #2]
	tst	w8, w6
	fcsel	s3, s3, s21, ne
	and	x8, x3, #0x7
	and	w17, w12, w7
	str	q2, [sp, #1680]
	str	q1, [sp, #1664]
	add	x0, sp, #1664
	ldr	s4, [x0, x8, lsl #2]
	tst	w17, #0x1
	fcsel	s4, s4, s21, ne
	and	x8, x11, #0x7
	and	w11, w25, w5
	str	q2, [sp, #1648]
	str	q1, [sp, #1632]
	add	x17, sp, #1632
	ldr	s5, [x17, x8, lsl #2]
	tst	w11, #0x1
	fcsel	s5, s5, s21, ne
	and	x8, x10, #0x7
	str	q2, [sp, #1616]
	str	q1, [sp, #1600]
	add	x10, sp, #1600
	ldr	s2, [x10, x8, lsl #2]
	and	w8, w15, w4
	tst	w8, #0x1
	fcsel	s2, s2, s21, ne
	ands	w4, w22, #0x1
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v5[0]
	mov.s	v3[3], v2[0]
	fmaxnm.4s	v1, v1, v3
	fcsel	s2, s1, s21, ne
	str	w12, [sp, #176]                 ; 4-byte Spill
	and	w8, w12, w22
	str	w8, [sp, #44]                   ; 4-byte Spill
	tst	w8, #0x1
	fcsel	s3, s1, s21, ne
	str	w25, [sp, #192]                 ; 4-byte Spill
	and	w6, w25, w22
	tst	w6, #0x1
	fcsel	s4, s1, s21, ne
	str	w15, [sp, #112]                 ; 4-byte Spill
	and	w7, w15, w22
	tst	w7, #0x1
	fcsel	s5, s1, s21, ne
	str	w14, [sp, #128]                 ; 4-byte Spill
	and	w30, w14, w22
	tst	w30, #0x1
	fcsel	s6, s1, s21, ne
	str	w13, [sp, #208]                 ; 4-byte Spill
	and	w8, w13, w22
	tst	w8, #0x1
	fcsel	s7, s1, s21, ne
	and	w11, w1, w22
	tst	w11, #0x1
	fcsel	s16, s1, s21, ne
	str	w22, [sp, #160]                 ; 4-byte Spill
	and	w10, w2, w22
	tst	w10, #0x1
	mov.s	v2[1], v3[0]
	mov.s	v2[2], v4[0]
	mov.s	v2[3], v5[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	fcsel	s1, s1, s21, ne
	mov.s	v6[3], v1[0]
	ldr	w17, [sp, #236]                 ; 4-byte Reload
	rbit	w17, w17
	clz	w3, w17
	str	q6, [sp, #1456]
	str	q2, [sp, #1440]
	and	x17, x3, #0x7
	add	x0, sp, #1440
	ldr	s1, [x0, x17, lsl #2]
	mov	w17, #-8388608                  ; =0xff800000
	fmov	s2, w17
	fmaxnm	s1, s1, s2
	dup.4s	v4, v1[0]
	movi.2d	v5, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v22, #0000000000000000
	ldr	x27, [sp, #32]                  ; 8-byte Reload
	mov	w21, #-1026555904               ; =0xc2d00000
	mov	w26, #1120403456                ; =0x42c80000
	ldr	w22, [sp, #156]                 ; 4-byte Reload
	ldr	w25, [sp, #108]                 ; 4-byte Reload
	b	LBB1_116
LBB1_115:                               ; %else282
                                        ;   in Loop: Header=BB1_116 Depth=2
	ldp	q2, q1, [sp, #624]              ; 32-byte Folded Reload
	cmhi.4s	v2, v2, v1
	lsl	x9, x9, #5
	add	x17, x24, x9
	ldp	q6, q1, [x17]
	fsub.4s	v6, v6, v4
	fsub.4s	v1, v1, v4
	and.16b	v25, v0, v1
	and.16b	v6, v2, v6
	dup.4s	v13, w21
	fcmge.4s	v1, v6, v13
	fcmge.4s	v7, v25, v13
	dup.4s	v12, w26
	fcmge.4s	v16, v12, v6
	fcmge.4s	v17, v12, v25
	and.16b	v7, v7, v17
	and.16b	v1, v1, v16
	and.16b	v1, v1, v6
	and.16b	v7, v7, v25
	mov	w17, #43579                     ; =0xaa3b
	movk	w17, #16312, lsl #16
	dup.4s	v9, w17
	fmul.4s	v16, v7, v9
	fmul.4s	v17, v1, v9
	movi.4s	v20, #75, lsl #24
	mvni.4s	v21, #128, lsl #24
	mov.16b	v19, v21
	bsl.16b	v19, v20, v17
	bif.16b	v20, v16, v21
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v19
	fsub.4s	v17, v17, v19
	fsub.4s	v16, v16, v20
	fcvtzs.4s	v16, v16
	fcvtzs.4s	v17, v17
	scvtf.4s	v19, v17
	mov	w17, #29184                     ; =0x7200
	movk	w17, #48945, lsl #16
	dup.4s	v11, w17
	scvtf.4s	v20, v16
	fmul.4s	v21, v20, v11
	fmul.4s	v23, v19, v11
	fadd.4s	v23, v1, v23
	mov	w17, #48782                     ; =0xbe8e
	movk	w17, #46527, lsl #16
	dup.4s	v1, w17
	fadd.4s	v7, v7, v21
	fmul.4s	v19, v19, v1
	fmul.4s	v20, v20, v1
	fadd.4s	v7, v7, v20
	mov	w17, #11226                     ; =0x2bda
	movk	w17, #14672, lsl #16
	dup.4s	v20, w17
	fadd.4s	v26, v23, v19
	fmul.4s	v19, v26, v20
	fmul.4s	v23, v7, v20
	mov	w17, #38601                     ; =0x96c9
	movk	w17, #15030, lsl #16
	dup.4s	v21, w17
	fadd.4s	v23, v23, v21
	fadd.4s	v19, v19, v21
	fmul.4s	v24, v26, v19
	fmul.4s	v23, v7, v23
	mov	w17, #34982                     ; =0x88a6
	movk	w17, #15368, lsl #16
	dup.4s	v19, w17
	fadd.4s	v23, v23, v19
	fadd.4s	v24, v24, v19
	fmul.4s	v24, v26, v24
	fmul.4s	v27, v7, v23
	mov	w17, #43642                     ; =0xaa7a
	movk	w17, #15658, lsl #16
	dup.4s	v23, w17
	fadd.4s	v27, v27, v23
	fadd.4s	v24, v24, v23
	fmul.4s	v28, v26, v24
	fmul.4s	v27, v7, v27
	mov	w17, #43691                     ; =0xaaab
	movk	w17, #15914, lsl #16
	dup.4s	v24, w17
	fadd.4s	v27, v27, v24
	fadd.4s	v28, v28, v24
	fmul.4s	v28, v26, v28
	fmul.4s	v27, v7, v27
	movi.4s	v29, #63, lsl #24
	fadd.4s	v27, v27, v29
	fadd.4s	v28, v28, v29
	fmul.4s	v29, v26, v26
	fmul.4s	v28, v29, v28
	fmul.4s	v29, v7, v7
	fmul.4s	v27, v29, v27
	fadd.4s	v7, v7, v27
	fadd.4s	v26, v26, v28
	fmov.4s	v30, #1.00000000
	fadd.4s	v26, v26, v30
	fadd.4s	v7, v7, v30
	sshr.4s	v27, v17, #1
	sshr.4s	v28, v16, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v30
	fmul.4s	v7, v7, v29
	shl.4s	v29, v27, #23
	add.4s	v29, v29, v30
	fmul.4s	v26, v26, v29
	sub.4s	v16, v16, v28
	sub.4s	v17, v17, v27
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v30
	fmul.4s	v17, v26, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v30
	fmul.4s	v7, v7, v16
	fcmgt.4s	v16, v13, v25
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v13, v6
	bic.16b	v16, v17, v16
	fcmgt.4s	v17, v6, v12
	ldr	q26, [sp, #576]                 ; 16-byte Reload
	bit.16b	v16, v26, v17
	fcmgt.4s	v17, v25, v12
	bit.16b	v7, v26, v17
	fcmeq.4s	v17, v25, v25
	ldr	q25, [sp, #560]                 ; 16-byte Reload
	bif.16b	v7, v25, v17
	cmeq.8b	v3, v3, #0
	sshll.8h	v3, v3, #0
	fcmeq.4s	v6, v6, v6
	bsl.16b	v6, v16, v25
	sshll.4s	v16, v3, #0
	bic.16b	v6, v6, v16
	sshll2.4s	v3, v3, #0
	bic.16b	v3, v7, v3
	add	x9, x23, x9
	ldr	q7, [x9, #16]
	bif.16b	v3, v7, v0
	ldr	q7, [x9]
	bif.16b	v6, v7, v2
	stp	q6, q3, [x9]
	ldp	q3, q6, [sp, #672]              ; 32-byte Folded Reload
	add.2d	v31, v31, v6
	add.2d	v14, v14, v3
	ldr	q3, [sp, #608]                  ; 16-byte Reload
	add.2d	v22, v22, v3
	ldr	q3, [sp, #656]                  ; 16-byte Reload
	add.2d	v5, v5, v3
	fmov	x9, d5
	cmp	x9, #192
	b.ge	LBB1_132
LBB1_116:                               ; %direct.true170.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q1, [sp, #592]                  ; 16-byte Reload
	fmov	w17, s1
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	add.2d	v1, v5, v1
	ldr	q2, [sp, #496]                  ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w17, #0, LBB1_118
; %bb.117:                              ; %cond.load236
                                        ;   in Loop: Header=BB1_116 Depth=2
	fmov	x0, d1
	ldr	b3, [x0]
	ldp	q6, q2, [sp, #528]              ; 32-byte Folded Reload
	ldr	q7, [sp, #512]                  ; 16-byte Reload
	and	w5, w17, #0xff
	tbnz	w5, #1, LBB1_119
	b	LBB1_120
LBB1_118:                               ;   in Loop: Header=BB1_116 Depth=2
	movi.2d	v3, #0000000000000000
	ldp	q6, q2, [sp, #528]              ; 32-byte Folded Reload
	ldr	q7, [sp, #512]                  ; 16-byte Reload
	and	w5, w17, #0xff
	tbz	w5, #1, LBB1_120
LBB1_119:                               ; %cond.load242
                                        ;   in Loop: Header=BB1_116 Depth=2
	mov.d	x17, v1[1]
	ld1.b	{ v3 }[1], [x17]
LBB1_120:                               ; %else246
                                        ;   in Loop: Header=BB1_116 Depth=2
	ldr	q1, [sp, #736]                  ; 16-byte Reload
	add.2d	v1, v31, v1
	add.2d	v1, v6, v1
	tbnz	w5, #2, LBB1_126
; %bb.121:                              ; %else252
                                        ;   in Loop: Header=BB1_116 Depth=2
	tbnz	w5, #3, LBB1_127
LBB1_122:                               ; %else258
                                        ;   in Loop: Header=BB1_116 Depth=2
	ldr	q1, [sp, #720]                  ; 16-byte Reload
	add.2d	v1, v14, v1
	add.2d	v1, v7, v1
	tbnz	w5, #4, LBB1_128
LBB1_123:                               ; %else264
                                        ;   in Loop: Header=BB1_116 Depth=2
	tbnz	w5, #5, LBB1_129
LBB1_124:                               ; %else270
                                        ;   in Loop: Header=BB1_116 Depth=2
	ldr	q1, [sp, #752]                  ; 16-byte Reload
	add.2d	v1, v22, v1
	add.2d	v1, v2, v1
	tbnz	w5, #6, LBB1_130
LBB1_125:                               ; %else276
                                        ;   in Loop: Header=BB1_116 Depth=2
	tbz	w5, #7, LBB1_115
	b	LBB1_131
LBB1_126:                               ; %cond.load248
                                        ;   in Loop: Header=BB1_116 Depth=2
	fmov	x17, d1
	ld1.b	{ v3 }[2], [x17]
	tbz	w5, #3, LBB1_122
LBB1_127:                               ; %cond.load254
                                        ;   in Loop: Header=BB1_116 Depth=2
	mov.d	x17, v1[1]
	ld1.b	{ v3 }[3], [x17]
	ldr	q1, [sp, #720]                  ; 16-byte Reload
	add.2d	v1, v14, v1
	add.2d	v1, v7, v1
	tbz	w5, #4, LBB1_123
LBB1_128:                               ; %cond.load260
                                        ;   in Loop: Header=BB1_116 Depth=2
	fmov	x17, d1
	ld1.b	{ v3 }[4], [x17]
	tbz	w5, #5, LBB1_124
LBB1_129:                               ; %cond.load266
                                        ;   in Loop: Header=BB1_116 Depth=2
	mov.d	x17, v1[1]
	ld1.b	{ v3 }[5], [x17]
	ldr	q1, [sp, #752]                  ; 16-byte Reload
	add.2d	v1, v22, v1
	add.2d	v1, v2, v1
	tbz	w5, #6, LBB1_125
LBB1_130:                               ; %cond.load272
                                        ;   in Loop: Header=BB1_116 Depth=2
	fmov	x17, d1
	ld1.b	{ v3 }[6], [x17]
	tbz	w5, #7, LBB1_115
LBB1_131:                               ; %cond.load278
                                        ;   in Loop: Header=BB1_116 Depth=2
	mov.d	x17, v1[1]
	ld1.b	{ v3 }[7], [x17]
	b	LBB1_115
LBB1_132:                               ; %direct.true211.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q3, [sp, #48]                   ; 16-byte Reload
	sshll.4s	v3, v3, #0
	ldp	q5, q6, [sp, #384]              ; 32-byte Folded Reload
	fsub.4s	v7, v6, v4
	fsub.4s	v4, v5, v4
	ldr	q6, [sp, #448]                  ; 16-byte Reload
	zip2.8b	v5, v6, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v4, v5, v4
	zip1.8b	v6, v6, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v22, v6, v7
	fcmge.4s	v7, v22, v13
	fcmge.4s	v16, v4, v13
	fcmge.4s	v17, v12, v22
	fcmge.4s	v25, v12, v4
	and.16b	v16, v16, v25
	and.16b	v7, v7, v17
	and.16b	v7, v7, v22
	and.16b	v16, v16, v4
	fmul.4s	v17, v16, v9
	fmul.4s	v25, v7, v9
	movi.4s	v27, #75, lsl #24
	mvni.4s	v28, #128, lsl #24
	mov.16b	v26, v28
	bsl.16b	v26, v27, v25
	bif.16b	v27, v17, v28
	fadd.4s	v17, v17, v27
	fadd.4s	v25, v25, v26
	fsub.4s	v25, v25, v26
	fsub.4s	v17, v17, v27
	fcvtzs.4s	v17, v17
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	scvtf.4s	v27, v17
	fmul.4s	v28, v27, v11
	fmul.4s	v29, v26, v11
	fadd.4s	v7, v7, v29
	fadd.4s	v16, v16, v28
	fmul.4s	v26, v26, v1
	fmul.4s	v1, v27, v1
	fadd.4s	v1, v16, v1
	fadd.4s	v7, v7, v26
	fmul.4s	v16, v7, v20
	fmul.4s	v20, v1, v20
	fadd.4s	v20, v20, v21
	fadd.4s	v16, v16, v21
	fmul.4s	v16, v7, v16
	fmul.4s	v20, v1, v20
	fadd.4s	v20, v20, v19
	fadd.4s	v16, v16, v19
	fmul.4s	v16, v7, v16
	fmul.4s	v19, v1, v20
	fadd.4s	v19, v19, v23
	fadd.4s	v16, v16, v23
	fmul.4s	v16, v7, v16
	fmul.4s	v19, v1, v19
	fadd.4s	v19, v19, v24
	fadd.4s	v16, v16, v24
	fmul.4s	v16, v7, v16
	fmul.4s	v19, v1, v19
	movi.4s	v20, #63, lsl #24
	fadd.4s	v19, v19, v20
	fadd.4s	v16, v16, v20
	fmul.4s	v20, v1, v1
	fmul.4s	v21, v7, v7
	fmul.4s	v16, v21, v16
	fmul.4s	v19, v20, v19
	fadd.4s	v1, v1, v19
	fadd.4s	v7, v7, v16
	fmov.4s	v23, #1.00000000
	fadd.4s	v7, v7, v23
	fadd.4s	v1, v1, v23
	sshr.4s	v16, v25, #1
	sshr.4s	v19, v17, #1
	shl.4s	v20, v19, #23
	shl.4s	v21, v16, #23
	add.4s	v21, v21, v23
	add.4s	v20, v20, v23
	fmul.4s	v1, v1, v20
	fmul.4s	v7, v7, v21
	sub.4s	v17, v17, v19
	sub.4s	v16, v25, v16
	shl.4s	v16, v16, #23
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v23
	add.4s	v16, v16, v23
	fmul.4s	v7, v7, v16
	fmul.4s	v1, v1, v17
	fcmgt.4s	v16, v13, v4
	bic.16b	v1, v1, v16
	fcmgt.4s	v16, v13, v22
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v4, v12
	fcmgt.4s	v17, v22, v12
	ldr	q19, [sp, #576]                 ; 16-byte Reload
	bit.16b	v7, v19, v17
	bit.16b	v1, v19, v16
	fcmeq.4s	v16, v22, v22
	fcmeq.4s	v4, v4, v4
	ldr	q17, [sp, #560]                 ; 16-byte Reload
	bif.16b	v1, v17, v4
	mov.16b	v4, v16
	bsl.16b	v4, v7, v17
	bic.16b	v4, v4, v3
	ldr	q3, [sp, #80]                   ; 16-byte Reload
	bic.16b	v3, v1, v3
	ldr	x9, [sp, #248]                  ; 8-byte Reload
	add	x9, x23, x9
	ldp	q1, q7, [x9]
	bsl.16b	v5, v3, v7
	bit.16b	v1, v4, v6
	stp	q1, q5, [x9]
	ldp	q5, q1, [x23, #96]
	and.16b	v1, v0, v1
	and.16b	v19, v2, v5
	ldp	q5, q6, [x23, #64]
	and.16b	v21, v0, v6
	and.16b	v20, v2, v5
	ldp	q5, q6, [x23, #32]
	and.16b	v22, v0, v6
	and.16b	v23, v2, v5
	ldr	x9, [sp, #72]                   ; 8-byte Reload
	add	x9, x23, x9
	ldp	q5, q6, [x9]
	and.16b	v25, v0, v6
	and.16b	v6, v2, v5
	mov	w17, #4                         ; =0x4
	ldr	q12, [sp, #416]                 ; 16-byte Reload
LBB1_133:                               ; %direct.true211.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v5, v2, #0
	sshll.2d	v7, v0, #0
	sshll2.2d	v16, v2, #0
	add	x9, x23, x16, lsl #5
	ldp	q24, q17, [x9]
	fadd.4s	v26, v6, v24
	fadd.4s	v27, v25, v17
	ldp	q24, q17, [x9, #32]
	fadd.4s	v24, v23, v24
	fadd.4s	v17, v22, v17
	ldp	q29, q28, [x9, #64]
	fadd.4s	v29, v20, v29
	fadd.4s	v28, v21, v28
	ldp	q31, q30, [x9, #96]
	fadd.4s	v31, v19, v31
	fadd.4s	v30, v1, v30
	dup.2d	v9, x17
	and.16b	v11, v12, v9
	add.2d	v15, v15, v11
	and.16b	v16, v16, v9
	add.2d	v8, v8, v16
	and.16b	v7, v7, v9
	add.2d	v10, v10, v7
	and.16b	v5, v5, v9
	add.2d	v18, v18, v5
	bit.16b	v25, v27, v0
	bit.16b	v6, v26, v2
	bit.16b	v22, v17, v0
	bit.16b	v23, v24, v2
	bit.16b	v21, v28, v0
	bit.16b	v20, v29, v2
	bit.16b	v1, v30, v0
	bit.16b	v19, v31, v2
	fmov	x16, d18
	cmp	x16, #192
	b.lt	LBB1_133
; %bb.134:                              ; %direct.false212.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	uzp1.8h	v5, v2, v0
	xtn.8b	v7, v5
Lloh64:
	adrp	x16, lCPI1_21@PAGE
Lloh65:
	ldr	q16, [x16, lCPI1_21@PAGEOFF]
	and.16b	v24, v0, v16
Lloh66:
	adrp	x16, lCPI1_22@PAGE
Lloh67:
	ldr	q16, [x16, lCPI1_22@PAGEOFF]
	and.16b	v28, v2, v16
Lloh68:
	adrp	x16, lCPI1_24@PAGE
Lloh69:
	ldr	q16, [x16, lCPI1_24@PAGEOFF]
	and.16b	v18, v2, v16
	fadd.4s	v16, v3, v25
	fadd.4s	v6, v4, v6
	ldr	q29, [sp, #448]                 ; 16-byte Reload
	zip1.8b	v17, v29, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v6, v17, v6
	zip2.8b	v17, v29, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v16, v17, v16
	ldr	d25, [sp, #64]                  ; 8-byte Reload
	zip2.8b	v17, v25, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v16, v27, v17
	zip1.8b	v17, v25, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v6, v26, v17
	fadd.4s	v6, v23, v6
	fadd.4s	v16, v22, v16
	fadd.4s	v16, v21, v16
	fadd.4s	v6, v20, v6
	fadd.4s	v19, v19, v6
	fadd.4s	v20, v1, v16
	fmov	w16, s28
	add	x17, sp, #840
	bfxil	x17, x16, #0, #3
	str	d7, [sp, #840]
	ldrb	w17, [x17]
	add	x0, sp, #1392
	orr	x16, x0, x16, lsl #2
	str	q20, [sp, #1408]
	str	q19, [sp, #1392]
	ldr	s1, [x16]
	tst	w4, w17
	movi.2d	v25, #0000000000000000
	fcsel	s1, s1, s25, ne
	mov.s	w16, v28[1]
	add	x17, sp, #840
	bfxil	x17, x16, #0, #3
	ldrb	w16, [x17]
	ldr	w12, [sp, #176]                 ; 4-byte Reload
	and	w16, w12, w16
	str	q19, [sp, #1360]
	ldr	s6, [sp, #1360]
	tst	w16, #0x1
	fcsel	s6, s6, s25, ne
	mov.s	w16, v28[2]
	add	x17, sp, #840
	bfxil	x17, x16, #0, #3
	add	x0, sp, #1328
	orr	x16, x0, x16, lsl #2
	ldrb	w17, [x17]
	ldr	w13, [sp, #192]                 ; 4-byte Reload
	and	w17, w13, w17
	str	q20, [sp, #1344]
	str	q19, [sp, #1328]
	ldr	s7, [x16]
	tst	w17, #0x1
	fcsel	s21, s7, s25, ne
	mov.s	w16, v28[3]
	add	x17, sp, #840
	bfxil	x17, x16, #0, #3
	add	x0, sp, #1296
	orr	x16, x0, x16, lsl #2
	ldrb	w17, [x17]
	ldr	w14, [sp, #112]                 ; 4-byte Reload
	and	w17, w14, w17
	str	q20, [sp, #1312]
	str	q19, [sp, #1296]
	ldr	s7, [x16]
	tst	w17, #0x1
	fcsel	s22, s7, s25, ne
	fmov	w16, s24
	add	x17, sp, #840
	bfxil	x17, x16, #0, #3
	ldrb	w17, [x17]
	ldr	w21, [sp, #128]                 ; 4-byte Reload
	and	w17, w21, w17
	str	q20, [sp, #1280]
	str	q19, [sp, #1264]
	add	x0, sp, #1264
	ldr	s7, [x0, w16, uxtw #2]
	tst	w17, #0x1
	fcsel	s7, s7, s25, ne
	mov.s	w16, v24[1]
	add	x17, sp, #840
	bfxil	x17, x16, #0, #3
	ldrb	w17, [x17]
	ldr	w5, [sp, #208]                  ; 4-byte Reload
	and	w17, w5, w17
	str	q20, [sp, #1248]
	str	q19, [sp, #1232]
	add	x0, sp, #1232
	ldr	s16, [x0, w16, uxtw #2]
	tst	w17, #0x1
	fcsel	s16, s16, s25, ne
	mov.s	w16, v24[2]
	add	x17, sp, #840
	bfxil	x17, x16, #0, #3
	ldrb	w17, [x17]
	and	w17, w1, w17
	str	q20, [sp, #1216]
	str	q19, [sp, #1200]
	add	x0, sp, #1200
	ldr	s17, [x0, w16, uxtw #2]
	tst	w17, #0x1
	fcsel	s17, s17, s25, ne
	mov.s	w16, v24[3]
	add	x17, sp, #840
	bfxil	x17, x16, #0, #3
	ldrb	w17, [x17]
	and	w17, w2, w17
	str	q20, [sp, #1184]
	str	q19, [sp, #1168]
	add	x0, sp, #1168
	ldr	s23, [x0, w16, uxtw #2]
	tst	w17, #0x1
	fcsel	s23, s23, s25, ne
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v23[0]
	mov.s	v1[1], v6[0]
	mov.s	v1[2], v21[0]
	mov.s	v1[3], v22[0]
	fadd.4s	v1, v19, v1
	fadd.4s	v19, v20, v7
	fmov	w16, s18
	add	x17, sp, #840
	bfxil	x17, x16, #0, #3
	ldrb	w17, [x17]
	add	x0, sp, #1136
	orr	x16, x0, x16, lsl #2
	str	q19, [sp, #1152]
	str	q1, [sp, #1136]
	ldr	s6, [x16]
	mov.s	w16, v18[1]
	tst	w4, w17
	add	x17, sp, #840
	bfxil	x17, x16, #0, #3
	ldrb	w17, [x17]
	and	w15, w12, w17
	fcsel	s6, s6, s25, ne
	add	x17, sp, #1104
	orr	x16, x17, x16, lsl #2
	str	q19, [sp, #1120]
	str	q1, [sp, #1104]
	ldr	s7, [x16]
	mov.s	w16, v18[2]
	tst	w15, #0x1
	add	x15, sp, #840
	bfxil	x15, x16, #0, #3
Lloh70:
	adrp	x16, lCPI1_23@PAGE
Lloh71:
	ldr	q16, [x16, lCPI1_23@PAGEOFF]
	and.16b	v16, v0, v16
	movi.4s	v17, #4
	and.16b	v20, v2, v17
	fcsel	s21, s7, s25, ne
	ldrb	w15, [x15]
	and	w13, w13, w15
	str	q1, [sp, #1072]
	ldr	s7, [sp, #1072]
	tst	w13, #0x1
	fcsel	s22, s7, s25, ne
	mov.s	w13, v18[3]
	add	x15, sp, #840
	bfxil	x15, x13, #0, #3
	add	x16, sp, #1040
	orr	x13, x16, x13, lsl #2
	ldrb	w15, [x15]
	and	w14, w14, w15
	str	q19, [sp, #1056]
	str	q1, [sp, #1040]
	ldr	s7, [x13]
	tst	w14, #0x1
	fcsel	s18, s7, s25, ne
	fmov	w13, s16
	add	x14, sp, #840
	bfxil	x14, x13, #0, #3
	ldrb	w14, [x14]
	and	w14, w21, w14
	stp	q1, q19, [sp, #1008]
	add	x15, sp, #1008
	ldr	s7, [x15, w13, uxtw #2]
	tst	w14, #0x1
	fcsel	s7, s7, s25, ne
	mov.s	w13, v16[1]
	add	x14, sp, #840
	bfxil	x14, x13, #0, #3
	ldrb	w14, [x14]
	and	w14, w5, w14
	stp	q1, q19, [sp, #976]
	add	x15, sp, #976
	ldr	s17, [x15, w13, uxtw #2]
	tst	w14, #0x1
	fcsel	s17, s17, s25, ne
	mov.s	w13, v16[2]
	add	x14, sp, #840
	bfxil	x14, x13, #0, #3
	ldrb	w14, [x14]
	and	w14, w1, w14
	stp	q1, q19, [sp, #944]
	add	x15, sp, #944
	ldr	s23, [x15, w13, uxtw #2]
	tst	w14, #0x1
	fcsel	s23, s23, s25, ne
	mov.s	w13, v16[3]
	add	x14, sp, #840
	bfxil	x14, x13, #0, #3
	ldrb	w14, [x14]
	and	w14, w2, w14
	stp	q1, q19, [sp, #912]
	add	x15, sp, #912
	ldr	s16, [x15, w13, uxtw #2]
	tst	w14, #0x1
	fcsel	s16, s16, s25, ne
	mov.s	v7[1], v17[0]
	mov.s	v7[2], v23[0]
	mov.s	v7[3], v16[0]
	mov.s	v6[1], v21[0]
	mov.s	v6[2], v22[0]
	mov.s	v6[3], v18[0]
	fadd.4s	v1, v1, v6
	fadd.4s	v6, v19, v7
	fmov	w13, s20
	add	x14, sp, #840
	orr	x14, x14, x13
	ldrb	w14, [x14]
	stp	q1, q6, [sp, #880]
	add	x15, sp, #880
	ldr	s6, [x15, w13, uxtw #2]
	tst	w4, w14
	fcsel	s6, s6, s25, ne
	ldr	w12, [sp, #160]                 ; 4-byte Reload
	tst	w12, #0x1
	fadd	s1, s1, s6
	fcsel	s6, s1, s25, ne
	ldr	w12, [sp, #44]                  ; 4-byte Reload
	tst	w12, #0x1
	fcsel	s7, s1, s25, ne
	tst	w6, #0x1
	fcsel	s16, s1, s25, ne
	tst	w7, #0x1
	fcsel	s17, s1, s25, ne
	tst	w30, #0x1
	fcsel	s18, s1, s25, ne
	tst	w8, #0x1
	fcsel	s19, s1, s25, ne
	tst	w11, #0x1
	fcsel	s20, s1, s25, ne
	tst	w10, #0x1
	fcsel	s1, s1, s25, ne
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v17[0]
	mov.s	v18[1], v19[0]
	mov.s	v18[2], v20[0]
	mov.s	v18[3], v1[0]
	stp	q6, q18, [sp, #848]
	and	x8, x3, #0x7
	add	x10, sp, #848
	ldr	s1, [x10, x8, lsl #2]
	fadd	s1, s1, s25
	dup.4s	v18, v1[0]
	ldr	q1, [sp, #256]                  ; 16-byte Reload
	fmov	x8, d1
	ldp	x13, x12, [sp, #344]            ; 16-byte Folded Reload
	add	x8, x12, x8, lsl #2
	movi.2d	v1, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	ldr	q16, [sp, #432]                 ; 16-byte Reload
	movi.8b	v14, #1
	ldr	q17, [sp, #608]                 ; 16-byte Reload
	ldp	q24, q23, [sp, #672]            ; 32-byte Folded Reload
	ldr	q25, [sp, #656]                 ; 16-byte Reload
	b	LBB1_136
LBB1_135:                               ; %else300
                                        ;   in Loop: Header=BB1_136 Depth=2
	add.2d	v6, v6, v23
	add.2d	v19, v19, v24
	add.2d	v20, v20, v17
	add.2d	v1, v1, v25
	fmov	x9, d1
	cmp	x9, #192
	b.ge	LBB1_152
LBB1_136:                               ; %direct.true248.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and.16b	v7, v5, v16
	addv.8h	h7, v7
	fmov	w10, s7
	lsl	x9, x9, #5
	add	x11, x23, x9
	ldp	q7, q21, [x11]
	and.16b	v7, v2, v7
	fdiv.4s	v22, v7, v18
	add	x9, x8, x9
	tbnz	w10, #0, LBB1_144
; %bb.137:                              ; %else286
                                        ;   in Loop: Header=BB1_136 Depth=2
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_145
LBB1_138:                               ; %else288
                                        ;   in Loop: Header=BB1_136 Depth=2
	tbnz	w10, #2, LBB1_146
LBB1_139:                               ; %else290
                                        ;   in Loop: Header=BB1_136 Depth=2
	tbnz	w10, #3, LBB1_147
LBB1_140:                               ; %else292
                                        ;   in Loop: Header=BB1_136 Depth=2
	and.16b	v7, v0, v21
	fdiv.4s	v21, v7, v18
	tbnz	w10, #4, LBB1_148
LBB1_141:                               ; %else294
                                        ;   in Loop: Header=BB1_136 Depth=2
	tbnz	w10, #5, LBB1_149
LBB1_142:                               ; %else296
                                        ;   in Loop: Header=BB1_136 Depth=2
	tbnz	w10, #6, LBB1_150
LBB1_143:                               ; %else298
                                        ;   in Loop: Header=BB1_136 Depth=2
	tbz	w10, #7, LBB1_135
	b	LBB1_151
LBB1_144:                               ; %cond.store285
                                        ;   in Loop: Header=BB1_136 Depth=2
	str	s22, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_138
LBB1_145:                               ; %cond.store287
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x11, x9, #4
	st1.s	{ v22 }[1], [x11]
	tbz	w10, #2, LBB1_139
LBB1_146:                               ; %cond.store289
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x11, x9, #8
	st1.s	{ v22 }[2], [x11]
	tbz	w10, #3, LBB1_140
LBB1_147:                               ; %cond.store291
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x11, x9, #12
	st1.s	{ v22 }[3], [x11]
	and.16b	v7, v0, v21
	fdiv.4s	v21, v7, v18
	tbz	w10, #4, LBB1_141
LBB1_148:                               ; %cond.store293
                                        ;   in Loop: Header=BB1_136 Depth=2
	str	s21, [x9, #16]
	tbz	w10, #5, LBB1_142
LBB1_149:                               ; %cond.store295
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x11, x9, #20
	st1.s	{ v21 }[1], [x11]
	tbz	w10, #6, LBB1_143
LBB1_150:                               ; %cond.store297
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x11, x9, #24
	st1.s	{ v21 }[2], [x11]
	tbz	w10, #7, LBB1_135
LBB1_151:                               ; %cond.store299
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x9, x9, #28
	st1.s	{ v21 }[3], [x9]
	b	LBB1_135
LBB1_152:                               ; %direct.false249.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	d0, [sp, #240]                  ; 8-byte Reload
	fmov	w8, s0
	zip1.8b	v0, v29, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v0, v0, v4
	fdiv.4s	v0, v0, v18
	ldp	q1, q2, [sp, #304]              ; 32-byte Folded Reload
	ldp	q5, q4, [sp, #272]              ; 32-byte Folded Reload
	stp	q2, q4, [sp, #768]
	stp	q5, q1, [sp, #800]
	and	x9, x13, #0x7
	add	x10, sp, #768
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x13
	add	x9, x12, x9, lsl #2
	ldr	w11, [sp, #492]                 ; 4-byte Reload
	tbnz	w8, #0, LBB1_166
; %bb.153:                              ; %else303
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #1, LBB1_167
LBB1_154:                               ; %else305
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #2, LBB1_168
LBB1_155:                               ; %else307
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #3, LBB1_157
LBB1_156:                               ; %cond.store308
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #12
	st1.s	{ v0 }[3], [x10]
LBB1_157:                               ; %else309
                                        ;   in Loop: Header=BB1_4 Depth=1
	zip2.8b	v0, v29, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v0, v0, v3
	fdiv.4s	v0, v0, v18
	tbnz	w8, #4, LBB1_169
; %bb.158:                              ; %else311
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #5, LBB1_170
LBB1_159:                               ; %else313
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #6, LBB1_171
LBB1_160:                               ; %else315
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #7, LBB1_2
	b	LBB1_172
LBB1_161:                               ; %cond.load199
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x11, d13
	ld1.b	{ v1 }[2], [x11]
	tbz	w12, #3, LBB1_107
LBB1_162:                               ; %cond.load205
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[3], [x10]
	tbz	w12, #4, LBB1_108
LBB1_163:                               ; %cond.load211
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x10, d22
	ld1.b	{ v1 }[4], [x10]
	tbz	w12, #5, LBB1_109
LBB1_164:                               ; %cond.load217
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[5], [x9]
	tbz	w12, #6, LBB1_110
LBB1_165:                               ; %cond.load223
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x9, d3
	ld1.b	{ v1 }[6], [x9]
	stp	q27, q26, [sp, #528]            ; 32-byte Folded Spill
	stp	q8, q28, [sp, #496]             ; 32-byte Folded Spill
	str	d21, [sp, #240]                 ; 8-byte Spill
	tbnz	w12, #7, LBB1_111
	b	LBB1_112
LBB1_166:                               ; %cond.store302
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9]
	tbz	w8, #1, LBB1_154
LBB1_167:                               ; %cond.store304
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #4
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #2, LBB1_155
LBB1_168:                               ; %cond.store306
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #8
	st1.s	{ v0 }[2], [x10]
	tbnz	w8, #3, LBB1_156
	b	LBB1_157
LBB1_169:                               ; %cond.store310
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9, #16]
	tbz	w8, #5, LBB1_159
LBB1_170:                               ; %cond.store312
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #6, LBB1_160
LBB1_171:                               ; %cond.store314
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w8, #7, LBB1_2
LBB1_172:                               ; %cond.store316
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x9, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB1_2
LBB1_173:                               ; %block.batch.exit
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #2112
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpAdrp	Lloh56, Lloh58
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpAdrp	Lloh48, Lloh50
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpAdrp	Lloh66, Lloh68
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpAdrp	Lloh64, Lloh66
	.loh AdrpLdr	Lloh64, Lloh65
                                        ; -- End function
.subsections_via_symbols

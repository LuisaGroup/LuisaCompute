	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-128]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2320
	ldr	x11, [x0]
	ldr	x23, [x0, #16]
	ldr	x21, [x0, #48]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	subs	x9, x11, x21
	cset	w10, hs
	lsr	x9, x9, #10
	cmp	x9, #386
	csel	w9, wzr, w10, ls
	subs	x10, x21, x11
	cset	w12, hs
	lsr	x10, x10, #10
	cmp	x10, #386
	csel	w10, wzr, w12, ls
	orr	w9, w9, w10
	subs	x10, x23, x21
	cset	w12, hs
	lsr	x10, x10, #10
	cmp	x10, #386
	csel	w10, wzr, w12, ls
	subs	x12, x21, x23
	cset	w13, hs
	lsr	x12, x12, #10
	cmp	x12, #386
	csel	w12, wzr, w13, ls
	orr	w10, w10, w12
	mov	w12, #3072                      ; =0xc00
	umull	x22, w8, w12
	cmp	w9, #1
	ccmp	w10, #0, #4, eq
	b.ne	LBB0_3
; %bb.1:                                ; %direct.schedule.6.preheader
	add	x19, sp, #3344
	add	x0, sp, #3344
	add	x1, x11, x22
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	add	x20, sp, #272
	add	x0, sp, #272
	add	x1, x23, x22
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	mov	w9, #10003                      ; =0x2713
	movk	w9, #15671, lsl #16
	dup.4s	v1, w9
	mov	w9, #16938                      ; =0x422a
	movk	w9, #16204, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #240]              ; 32-byte Folded Spill
	mov	w9, #37425                      ; =0x9231
	movk	w9, #12080, lsl #16
	dup.4s	v1, w9
	mov	w9, #12843                      ; =0x322b
	movk	w9, #13015, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #208]              ; 32-byte Folded Spill
	mov	w9, #61213                      ; =0xef1d
	movk	w9, #13880, lsl #16
	dup.4s	v1, w9
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14672, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #176]              ; 32-byte Folded Spill
	mov	w9, #34953                      ; =0x8889
	movk	w9, #15368, lsl #16
	dup.4s	v1, w9
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v18, w9
	mov	w9, #30407                      ; =0x76c7
	movk	w9, #12559, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #144]              ; 32-byte Folded Spill
	mov	w9, #62078                      ; =0xf27e
	movk	w9, #13459, lsl #16
	dup.4s	v1, w9
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14288, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #112]              ; 32-byte Folded Spill
	mov	w9, #2913                       ; =0xb61
	movk	w9, #15030, lsl #16
	dup.4s	v1, w9
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15658, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #80]               ; 32-byte Folded Spill
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v1, w9
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v22, w9
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #48]               ; 32-byte Folded Spill
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v1, w9
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #16]               ; 32-byte Folded Spill
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v0, w9
	str	q0, [sp]                        ; 16-byte Spill
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v27, w9
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v28, w9
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v29, w9
	add	x9, x21, x22
	movi.4s	v30, #63, lsl #24
	fmov.4s	v31, #1.00000000
	mvni.4s	v0, #127, msl #16
	fneg.4s	v12, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v15, v0
LBB0_2:                                 ; %direct.true61
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x19, x8
	ldp	q8, q9, [x10]
	ldp	q2, q1, [sp, #240]              ; 32-byte Folded Reload
	fmul.4s	v0, v8, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v0, v8, v0
	fmul.4s	v0, v8, v0
	fmul.4s	v1, v9, v1
	fadd.4s	v1, v9, v1
	fadd.4s	v0, v8, v0
	fmul.4s	v11, v0, v2
	fmul.4s	v10, v1, v2
	fabs.4s	v14, v10
	fabs.4s	v13, v11
	fmul.4s	v5, v11, v11
	fmul.4s	v16, v10, v10
	ldp	q1, q2, [sp, #208]              ; 32-byte Folded Reload
	mov.16b	v0, v1
	fmla.4s	v0, v5, v2
	fmla.4s	v1, v16, v2
	ldr	q3, [sp, #192]                  ; 16-byte Reload
	mov.16b	v2, v3
	fmla.4s	v2, v5, v0
	mov.16b	v0, v3
	fmla.4s	v0, v16, v1
	ldp	q4, q3, [sp, #160]              ; 32-byte Folded Reload
	mov.16b	v1, v3
	fmla.4s	v1, v5, v2
	mov.16b	v2, v3
	fmla.4s	v2, v16, v0
	mov.16b	v3, v4
	mov.16b	v7, v18
	mov.16b	v17, v18
	fmov.4s	v0, #1.00000000
	fmla.4s	v3, v5, v1
	ldp	q6, q19, [sp, #128]             ; 32-byte Folded Reload
	mov.16b	v1, v6
	fmla.4s	v1, v16, v19
	fmla.4s	v6, v5, v19
	ldr	q20, [sp, #112]                 ; 16-byte Reload
	mov.16b	v19, v20
	fmla.4s	v4, v16, v2
	fmla.4s	v19, v16, v1
	mov.16b	v1, v20
	fmla.4s	v1, v5, v6
	ldr	q6, [sp, #96]                   ; 16-byte Reload
	mov.16b	v2, v6
	fmla.4s	v2, v16, v19
	fmla.4s	v7, v5, v3
	mov.16b	v3, v6
	fmla.4s	v3, v5, v1
	ldp	q24, q19, [sp, #64]             ; 32-byte Folded Reload
	mov.16b	v6, v19
	fmla.4s	v6, v16, v2
	fmla.4s	v17, v16, v4
	fmla.4s	v19, v5, v3
	movi.4s	v20, #63, lsl #24
	movi.4s	v21, #63, lsl #24
	fmov.4s	v3, #1.00000000
	fmov.4s	v2, #9.00000000
	fcmge.4s	v1, v2, v13
	fmla.4s	v20, v16, v6
	fcmge.4s	v2, v2, v14
	and.16b	v4, v2, v14
	and.16b	v6, v1, v13
	fcmge.4s	v23, v6, v24
	fcmge.4s	v24, v4, v24
	fcmge.4s	v25, v22, v4
	and.16b	v24, v24, v25
	fcmge.4s	v25, v22, v6
	and.16b	v23, v23, v25
	and.16b	v23, v23, v6
	and.16b	v24, v24, v4
	fmla.4s	v0, v16, v17
	ldr	q25, [sp, #48]                  ; 16-byte Reload
	fmul.4s	v17, v24, v25
	fmul.4s	v25, v23, v25
	movi.4s	v26, #75, lsl #24
	fadd.4s	v25, v25, v26
	fadd.4s	v17, v17, v26
	movi.4s	v26, #203, lsl #24
	fadd.4s	v17, v17, v26
	fmla.4s	v3, v16, v20
	fadd.4s	v16, v25, v26
	fcvtzs.4s	v16, v16
	fcvtzs.4s	v17, v17
	scvtf.4s	v20, v17
	scvtf.4s	v25, v16
	fmla.4s	v21, v5, v19
	ldr	q26, [sp, #32]                  ; 16-byte Reload
	fmul.4s	v19, v20, v26
	fadd.4s	v19, v24, v19
	fmul.4s	v24, v25, v26
	fadd.4s	v23, v23, v24
	fmov.4s	v24, #1.00000000
	fmla.4s	v24, v5, v7
	ldr	q26, [sp, #16]                  ; 16-byte Reload
	fmul.4s	v7, v25, v26
	fadd.4s	v7, v23, v7
	fmul.4s	v20, v20, v26
	fadd.4s	v19, v19, v20
	fmov.4s	v20, #1.00000000
	fmla.4s	v20, v5, v21
	ldr	q21, [sp]                       ; 16-byte Reload
	fmul.4s	v5, v19, v21
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v27
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v19, v5
	fmul.4s	v23, v13, v24
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v28
	fadd.4s	v5, v5, v28
	fmul.4s	v5, v19, v5
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v29
	fadd.4s	v5, v5, v29
	fmul.4s	v5, v19, v5
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v18
	fadd.4s	v24, v5, v18
	fdiv.4s	v5, v23, v20
	fmul.4s	v20, v19, v24
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v30
	fadd.4s	v20, v20, v30
	fmul.4s	v23, v19, v19
	fmul.4s	v20, v23, v20
	fmul.4s	v23, v7, v7
	fmul.4s	v21, v23, v21
	fadd.4s	v7, v7, v21
	fadd.4s	v19, v19, v20
	movi.2d	v23, #0xffffffffffffffff
	add.4s	v16, v16, v23
	fadd.4s	v7, v7, v31
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v31
	fmul.4s	v7, v7, v21
	add.4s	v17, v17, v23
	fadd.4s	v19, v19, v31
	sub.4s	v16, v16, v20
	sshr.4s	v20, v17, #1
	sub.4s	v17, v17, v20
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v31
	fmul.4s	v19, v19, v20
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v31
	fmul.4s	v17, v19, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v31
	fmul.4s	v7, v7, v16
	fcmgt.4s	v6, v6, v22
	bsl.16b	v6, v12, v7
	fmul.4s	v0, v14, v0
	fcmgt.4s	v4, v4, v22
	bsl.16b	v4, v12, v17
	fdiv.4s	v0, v0, v3
	fmov.4s	v16, #0.25000000
	fdiv.4s	v3, v16, v4
	fsub.4s	v7, v4, v3
	fadd.4s	v3, v4, v3
	fdiv.4s	v3, v7, v3
	bsl.16b	v2, v3, v31
	fcmge.4s	v3, v31, v14
	bif.16b	v0, v2, v3
	fdiv.4s	v2, v16, v6
	fsub.4s	v3, v6, v2
	fadd.4s	v2, v6, v2
	fdiv.4s	v2, v3, v2
	bsl.16b	v1, v2, v31
	fcmge.4s	v2, v31, v13
	bit.16b	v1, v5, v2
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v11, v3
	fcmeq.4s	v2, v11, v11
	fadd.4s	v1, v1, v31
	bif.16b	v1, v15, v2
	bif.16b	v0, v10, v3
	fcmeq.4s	v2, v10, v10
	fadd.4s	v0, v0, v31
	bif.16b	v0, v15, v2
	fmul.4s	v2, v9, v30
	fmul.4s	v0, v2, v0
	fmul.4s	v2, v8, v30
	fmul.4s	v1, v2, v1
	add	x10, x20, x8
	ldp	q3, q2, [x10]
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x10, x9, x8
	stp	q1, q0, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_2
	b	LBB0_5
LBB0_3:                                 ; %direct.true19.preheader
	mov	x8, #0                          ; =0x0
	mov	w9, #10003                      ; =0x2713
	movk	w9, #15671, lsl #16
	dup.4s	v1, w9
	mov	w9, #16938                      ; =0x422a
	movk	w9, #16204, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #240]              ; 32-byte Folded Spill
	mov	w9, #37425                      ; =0x9231
	movk	w9, #12080, lsl #16
	dup.4s	v1, w9
	mov	w9, #12843                      ; =0x322b
	movk	w9, #13015, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #208]              ; 32-byte Folded Spill
	mov	w9, #61213                      ; =0xef1d
	movk	w9, #13880, lsl #16
	dup.4s	v1, w9
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14672, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #176]              ; 32-byte Folded Spill
	mov	w9, #34953                      ; =0x8889
	movk	w9, #15368, lsl #16
	dup.4s	v1, w9
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v18, w9
	mov	w9, #30407                      ; =0x76c7
	movk	w9, #12559, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #144]              ; 32-byte Folded Spill
	mov	w9, #62078                      ; =0xf27e
	movk	w9, #13459, lsl #16
	dup.4s	v1, w9
	mov	w9, #3329                       ; =0xd01
	movk	w9, #14288, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #112]              ; 32-byte Folded Spill
	mov	w9, #2913                       ; =0xb61
	movk	w9, #15030, lsl #16
	dup.4s	v1, w9
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15658, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #80]               ; 32-byte Folded Spill
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v1, w9
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v22, w9
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #48]               ; 32-byte Folded Spill
	mov	w9, #29184                      ; =0x7200
	movk	w9, #48945, lsl #16
	dup.4s	v1, w9
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #46527, lsl #16
	dup.4s	v0, w9
	stp	q0, q1, [sp, #16]               ; 32-byte Folded Spill
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v0, w9
	str	q0, [sp]                        ; 16-byte Spill
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v27, w9
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v28, w9
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v29, w9
	add	x9, x21, x22
	add	x10, x23, x22
	add	x11, x11, x22
	movi.4s	v30, #63, lsl #24
	fmov.4s	v31, #1.00000000
	mvni.4s	v0, #127, msl #16
	fneg.4s	v12, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v15, v0
LBB0_4:                                 ; %direct.true19
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x11, x8
	ldp	q8, q9, [x12]
	ldp	q2, q1, [sp, #240]              ; 32-byte Folded Reload
	fmul.4s	v0, v8, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v0, v8, v0
	fmul.4s	v0, v8, v0
	fmul.4s	v1, v9, v1
	fadd.4s	v1, v9, v1
	fadd.4s	v0, v8, v0
	fmul.4s	v11, v0, v2
	fmul.4s	v10, v1, v2
	fabs.4s	v14, v10
	fabs.4s	v13, v11
	fmul.4s	v5, v11, v11
	fmul.4s	v16, v10, v10
	ldp	q1, q2, [sp, #208]              ; 32-byte Folded Reload
	mov.16b	v0, v1
	fmla.4s	v0, v5, v2
	fmla.4s	v1, v16, v2
	ldr	q3, [sp, #192]                  ; 16-byte Reload
	mov.16b	v2, v3
	fmla.4s	v2, v5, v0
	mov.16b	v0, v3
	fmla.4s	v0, v16, v1
	ldp	q4, q3, [sp, #160]              ; 32-byte Folded Reload
	mov.16b	v1, v3
	fmla.4s	v1, v5, v2
	mov.16b	v2, v3
	fmla.4s	v2, v16, v0
	mov.16b	v3, v4
	mov.16b	v7, v18
	mov.16b	v17, v18
	fmov.4s	v0, #1.00000000
	fmla.4s	v3, v5, v1
	ldp	q6, q19, [sp, #128]             ; 32-byte Folded Reload
	mov.16b	v1, v6
	fmla.4s	v1, v16, v19
	fmla.4s	v6, v5, v19
	ldr	q20, [sp, #112]                 ; 16-byte Reload
	mov.16b	v19, v20
	fmla.4s	v4, v16, v2
	fmla.4s	v19, v16, v1
	mov.16b	v1, v20
	fmla.4s	v1, v5, v6
	ldr	q6, [sp, #96]                   ; 16-byte Reload
	mov.16b	v2, v6
	fmla.4s	v2, v16, v19
	fmla.4s	v7, v5, v3
	mov.16b	v3, v6
	fmla.4s	v3, v5, v1
	ldp	q24, q19, [sp, #64]             ; 32-byte Folded Reload
	mov.16b	v6, v19
	fmla.4s	v6, v16, v2
	fmla.4s	v17, v16, v4
	fmla.4s	v19, v5, v3
	movi.4s	v20, #63, lsl #24
	movi.4s	v21, #63, lsl #24
	fmov.4s	v3, #1.00000000
	fmov.4s	v2, #9.00000000
	fcmge.4s	v1, v2, v13
	fmla.4s	v20, v16, v6
	fcmge.4s	v2, v2, v14
	and.16b	v4, v2, v14
	and.16b	v6, v1, v13
	fcmge.4s	v23, v6, v24
	fcmge.4s	v24, v4, v24
	fcmge.4s	v25, v22, v4
	and.16b	v24, v24, v25
	fcmge.4s	v25, v22, v6
	and.16b	v23, v23, v25
	and.16b	v23, v23, v6
	and.16b	v24, v24, v4
	fmla.4s	v0, v16, v17
	ldr	q25, [sp, #48]                  ; 16-byte Reload
	fmul.4s	v17, v24, v25
	fmul.4s	v25, v23, v25
	movi.4s	v26, #75, lsl #24
	fadd.4s	v25, v25, v26
	fadd.4s	v17, v17, v26
	movi.4s	v26, #203, lsl #24
	fadd.4s	v17, v17, v26
	fmla.4s	v3, v16, v20
	fadd.4s	v16, v25, v26
	fcvtzs.4s	v16, v16
	fcvtzs.4s	v17, v17
	scvtf.4s	v20, v17
	scvtf.4s	v25, v16
	fmla.4s	v21, v5, v19
	ldr	q26, [sp, #32]                  ; 16-byte Reload
	fmul.4s	v19, v20, v26
	fadd.4s	v19, v24, v19
	fmul.4s	v24, v25, v26
	fadd.4s	v23, v23, v24
	fmov.4s	v24, #1.00000000
	fmla.4s	v24, v5, v7
	ldr	q26, [sp, #16]                  ; 16-byte Reload
	fmul.4s	v7, v25, v26
	fadd.4s	v7, v23, v7
	fmul.4s	v20, v20, v26
	fadd.4s	v19, v19, v20
	fmov.4s	v20, #1.00000000
	fmla.4s	v20, v5, v21
	ldr	q21, [sp]                       ; 16-byte Reload
	fmul.4s	v5, v19, v21
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v27
	fadd.4s	v5, v5, v27
	fmul.4s	v5, v19, v5
	fmul.4s	v23, v13, v24
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v28
	fadd.4s	v5, v5, v28
	fmul.4s	v5, v19, v5
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v29
	fadd.4s	v5, v5, v29
	fmul.4s	v5, v19, v5
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v18
	fadd.4s	v24, v5, v18
	fdiv.4s	v5, v23, v20
	fmul.4s	v20, v19, v24
	fmul.4s	v21, v7, v21
	fadd.4s	v21, v21, v30
	fadd.4s	v20, v20, v30
	fmul.4s	v23, v19, v19
	fmul.4s	v20, v23, v20
	fmul.4s	v23, v7, v7
	fmul.4s	v21, v23, v21
	fadd.4s	v7, v7, v21
	fadd.4s	v19, v19, v20
	movi.2d	v23, #0xffffffffffffffff
	add.4s	v16, v16, v23
	fadd.4s	v7, v7, v31
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v31
	fmul.4s	v7, v7, v21
	add.4s	v17, v17, v23
	fadd.4s	v19, v19, v31
	sub.4s	v16, v16, v20
	sshr.4s	v20, v17, #1
	sub.4s	v17, v17, v20
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v31
	fmul.4s	v19, v19, v20
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v31
	fmul.4s	v17, v19, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v31
	fmul.4s	v7, v7, v16
	fcmgt.4s	v6, v6, v22
	bsl.16b	v6, v12, v7
	fmul.4s	v0, v14, v0
	fcmgt.4s	v4, v4, v22
	bsl.16b	v4, v12, v17
	fdiv.4s	v0, v0, v3
	fmov.4s	v16, #0.25000000
	fdiv.4s	v3, v16, v4
	fsub.4s	v7, v4, v3
	fadd.4s	v3, v4, v3
	fdiv.4s	v3, v7, v3
	bsl.16b	v2, v3, v31
	fcmge.4s	v3, v31, v14
	bif.16b	v0, v2, v3
	fdiv.4s	v2, v16, v6
	fsub.4s	v3, v6, v2
	fadd.4s	v2, v6, v2
	fdiv.4s	v2, v3, v2
	bsl.16b	v1, v2, v31
	fcmge.4s	v2, v31, v13
	bit.16b	v1, v5, v2
	mvni.4s	v3, #128, lsl #24
	bif.16b	v1, v11, v3
	fcmeq.4s	v2, v11, v11
	fadd.4s	v1, v1, v31
	bif.16b	v1, v15, v2
	bif.16b	v0, v10, v3
	fcmeq.4s	v2, v10, v10
	fadd.4s	v0, v0, v31
	bif.16b	v0, v15, v2
	fmul.4s	v2, v9, v30
	fmul.4s	v0, v2, v0
	fmul.4s	v2, v8, v30
	fmul.4s	v1, v2, v1
	add	x12, x10, x8
	ldp	q3, q2, [x12]
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x12, x9, x8
	stp	q1, q0, [x12]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_4
LBB0_5:                                 ; %common.ret
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2320
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #128            ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2304
	str	x0, [sp, #56]                   ; 8-byte Spill
	cbz	w3, LBB1_119
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x19, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	ldp	w28, w8, [x2, #44]
	str	w8, [sp, #52]                   ; 4-byte Spill
	ldp	w27, w25, [x2]
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [sp, #64]                   ; 16-byte Spill
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh4:
	adrp	x8, lCPI1_2@PAGE
Lloh5:
	ldr	q1, [x8, lCPI1_2@PAGEOFF]
	mvni.4s	v0, #127, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #128]                  ; 16-byte Spill
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q1, q0, [sp, #96]               ; 32-byte Folded Spill
	ldp	w26, w8, [x2, #8]
	str	x8, [sp, #40]                   ; 8-byte Spill
	add	x23, sp, #3328
	add	x24, sp, #256
	str	w3, [sp, #36]                   ; 4-byte Spill
	str	w28, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w19, [sp, #36]                  ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w27, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w27, wzr, w27, eq
	cinc	w9, w25, eq
	ldr	w10, [sp, #52]                  ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w25, wzr, w9, ne
	add	w26, w26, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_119
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_67 Depth 2
                                        ;     Child Loop BB1_85 Depth 2
                                        ;     Child Loop BB1_103 Depth 2
                                        ;     Child Loop BB1_17 Depth 2
	ubfiz	x8, x27, #5, #32
	ldr	x12, [sp, #40]                  ; 8-byte Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	stp	w27, w25, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x12, #2, hi
	csel	x21, x10, xzr, ls
	cmp	x21, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x21, [sp, #56]                  ; 8-byte Reload
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x19, x21, #3
	cbz	x19, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #56]                   ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #56]                   ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #56]                   ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x28, [sp, #56]                  ; 8-byte Reload
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x28
	ldr	w28, [sp, #12]                  ; 4-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w21, #0x7
	movi.4s	v14, #63, lsl #24
	fmov.4s	v15, #1.00000000
	fmov.4s	v6, #9.00000000
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v31, w8
	ldr	q0, [sp, #16]                   ; 16-byte Reload
	cmhi.4s	v0, v31, v0
	ldr	q1, [sp, #64]                   ; 16-byte Reload
	cmhi.4s	v1, v31, v1
	str	q1, [sp, #80]                   ; 16-byte Spill
	uzp1.8h	v9, v1, v0
	umaxv.8h	h1, v9
	fmov	w8, s1
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #56]                   ; 8-byte Reload
	ldr	x12, [x8]
	ldr	x10, [x8, #16]
	ldr	x9, [x8, #48]
	ubfiz	w8, w27, #2, #27
	orr	w8, w8, w19
	fmov	s1, w8
	ldr	q2, [sp, #80]                   ; 16-byte Reload
	and.16b	v17, v2, v1
	subs	x8, x12, x9
	cset	w11, hs
	mov	w13, #10003                     ; =0x2713
	movk	w13, #15671, lsl #16
	dup.4s	v2, w13
	mov	w15, #3071                      ; =0xbff
	movk	w15, #6, lsl #16
	cmp	x8, x15
	mov	w8, #16938                      ; =0x422a
	movk	w8, #16204, lsl #16
	dup.4s	v1, w8
	stp	q1, q2, [sp, #208]              ; 32-byte Folded Spill
	csel	w8, wzr, w11, ls
	mov	w11, #37425                     ; =0x9231
	movk	w11, #12080, lsl #16
	dup.4s	v2, w11
	subs	x11, x9, x12
	mov	w13, #12843                     ; =0x322b
	movk	w13, #13015, lsl #16
	dup.4s	v1, w13
	stp	q1, q2, [sp, #176]              ; 32-byte Folded Spill
	cset	w13, hs
	mov	w14, #61213                     ; =0xef1d
	movk	w14, #13880, lsl #16
	dup.4s	v2, w14
	cmp	x11, x15
	mov	w11, #3329                      ; =0xd01
	movk	w11, #14672, lsl #16
	dup.4s	v1, w11
	stp	q1, q2, [sp, #144]              ; 32-byte Folded Spill
	csel	w11, wzr, w13, ls
	mov	w13, #34953                     ; =0x8889
	movk	w13, #15368, lsl #16
	dup.4s	v7, w13
	orr	w14, w8, w11
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v16, w8
	subs	x8, x10, x9
	cset	w11, hs
	cmp	x8, x15
	csel	w8, wzr, w11, ls
	subs	x11, x9, x10
	cset	w13, hs
	cmp	x11, x15
	csel	w13, wzr, w13, ls
	fmov	w11, s17
	mov	w15, #30407                     ; =0x76c7
	movk	w15, #12559, lsl #16
	dup.4s	v17, w15
	mov	w15, #62078                     ; =0xf27e
	movk	w15, #13459, lsl #16
	dup.4s	v18, w15
	mov	w15, #3329                      ; =0xd01
	movk	w15, #14288, lsl #16
	dup.4s	v3, w15
	mov	w15, #2913                      ; =0xb61
	movk	w15, #15030, lsl #16
	dup.4s	v20, w15
	mov	w15, #43691                     ; =0xaaab
	movk	w15, #15658, lsl #16
	dup.4s	v21, w15
	mov	w15, #-1026555904               ; =0xc2d00000
	dup.4s	v22, w15
	mov	w15, #1120403456                ; =0x42c80000
	dup.4s	v23, w15
	mov	w15, #43579                     ; =0xaa3b
	movk	w15, #16312, lsl #16
	dup.4s	v24, w15
	mov	w15, #29184                     ; =0x7200
	movk	w15, #48945, lsl #16
	dup.4s	v25, w15
	mov	w15, #48782                     ; =0xbe8e
	movk	w15, #46527, lsl #16
	dup.4s	v26, w15
	mov	w15, #11226                     ; =0x2bda
	movk	w15, #14672, lsl #16
	dup.4s	v27, w15
	mov	w15, #38601                     ; =0x96c9
	movk	w15, #15030, lsl #16
	dup.4s	v28, w15
	mov	w15, #3072                      ; =0xc00
	umull	x11, w11, w15
	mov	w15, #34982                     ; =0x88a6
	movk	w15, #15368, lsl #16
	dup.4s	v29, w15
	mov	w15, #43642                     ; =0xaa7a
	movk	w15, #15658, lsl #16
	dup.4s	v30, w15
	cmp	w14, #1
	b.ne	LBB1_65
; %bb.14:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w8, w8, w13
	cbz	w8, LBB1_65
; %bb.15:                               ; %direct.true19.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x9, x11
	add	x10, x10, x11
	add	x11, x12, x11
	ldr	q1, [sp, #96]                   ; 16-byte Reload
	and.16b	v31, v9, v1
	addv.8h	h31, v31
	fmov	w12, s31
	b	LBB1_17
LBB1_16:                                ; %else86
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB1_2
LBB1_17:                                ; %direct.true19.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x13, x11, x8
	movi.2d	v10, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w12, #0, LBB1_43
; %bb.18:                               ; %else
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w14, w12, #0xff
	tbnz	w14, #1, LBB1_44
LBB1_19:                                ; %else26
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #2, LBB1_45
LBB1_20:                                ; %else29
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #3, LBB1_46
LBB1_21:                                ; %else32
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #4, LBB1_47
LBB1_22:                                ; %else35
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #5, LBB1_48
LBB1_23:                                ; %else38
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #6, LBB1_49
LBB1_24:                                ; %else41
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #7, LBB1_50
LBB1_25:                                ; %else44
                                        ;   in Loop: Header=BB1_17 Depth=2
	fmov	w14, s31
	add	x13, x10, x8
	movi.2d	v12, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbnz	w14, #0, LBB1_51
LBB1_26:                                ; %else48
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_52
LBB1_27:                                ; %else51
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #2, LBB1_53
LBB1_28:                                ; %else54
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #3, LBB1_54
LBB1_29:                                ; %else57
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #4, LBB1_55
LBB1_30:                                ; %else60
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #5, LBB1_56
LBB1_31:                                ; %else63
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #6, LBB1_57
LBB1_32:                                ; %else66
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w14, #7, LBB1_34
LBB1_33:                                ; %cond.load68
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x13, x13, #28
	ld1.s	{ v11 }[3], [x13]
LBB1_34:                                ; %else69
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldp	q1, q2, [sp, #208]              ; 32-byte Folded Reload
	fmul.4s	v13, v10, v2
	fmul.4s	v13, v10, v13
	fmul.4s	v13, v10, v13
	fadd.4s	v13, v10, v13
	fmul.4s	v13, v13, v1
	ldr	q1, [sp, #80]                   ; 16-byte Reload
	and.16b	v13, v1, v13
	fabs.4s	v14, v13
	fmul.4s	v15, v13, v13
	ldp	q4, q1, [sp, #176]              ; 32-byte Folded Reload
	fmla.4s	v4, v15, v1
	ldr	q5, [sp, #160]                  ; 16-byte Reload
	fmla.4s	v5, v15, v4
	ldr	q4, [sp, #144]                  ; 16-byte Reload
	fmla.4s	v4, v15, v5
	mov.16b	v5, v7
	fmla.4s	v5, v15, v4
	mov.16b	v4, v16
	fmla.4s	v4, v15, v5
	fmov.4s	v5, #1.00000000
	fmla.4s	v5, v15, v4
	fmul.4s	v4, v14, v5
	mov.16b	v5, v18
	fmla.4s	v5, v15, v17
	mov.16b	v19, v3
	fmla.4s	v19, v15, v5
	mov.16b	v5, v20
	fmla.4s	v5, v15, v19
	mov.16b	v19, v21
	fmla.4s	v19, v15, v5
	movi.4s	v5, #63, lsl #24
	fmla.4s	v5, v15, v19
	fmov.4s	v19, #1.00000000
	fmla.4s	v19, v15, v5
	fdiv.4s	v4, v4, v19
	fcmge.4s	v5, v6, v14
	and.16b	v19, v5, v14
	fcmge.4s	v15, v19, v22
	fcmge.4s	v8, v23, v19
	and.16b	v8, v15, v8
	and.16b	v8, v8, v19
	fmul.4s	v15, v8, v24
	movi.4s	v1, #75, lsl #24
	fadd.4s	v15, v15, v1
	movi.4s	v1, #203, lsl #24
	fadd.4s	v15, v15, v1
	fcvtzs.4s	v15, v15
	scvtf.4s	v1, v15
	fmul.4s	v2, v1, v25
	fadd.4s	v2, v8, v2
	fmul.4s	v1, v1, v26
	fadd.4s	v1, v2, v1
	fmul.4s	v2, v1, v27
	fadd.4s	v2, v2, v28
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v29
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v30
	fmul.4s	v2, v1, v2
	fadd.4s	v2, v2, v16
	fmul.4s	v2, v1, v2
	movi.4s	v8, #63, lsl #24
	fadd.4s	v2, v2, v8
	fmul.4s	v8, v1, v1
	fmul.4s	v2, v8, v2
	fadd.4s	v1, v1, v2
	fmov.4s	v6, #1.00000000
	fadd.4s	v1, v1, v6
	movi.2d	v2, #0xffffffffffffffff
	add.4s	v2, v15, v2
	sshr.4s	v8, v2, #1
	shl.4s	v15, v8, #23
	add.4s	v15, v15, v6
	fmul.4s	v1, v1, v15
	fmov.4s	v15, #1.00000000
	sub.4s	v2, v2, v8
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v15
	fmul.4s	v1, v1, v2
	fcmgt.4s	v2, v19, v23
	ldr	q6, [sp, #128]                  ; 16-byte Reload
	bit.16b	v1, v6, v2
	fmov.4s	v2, #0.25000000
	fdiv.4s	v2, v2, v1
	fsub.4s	v19, v1, v2
	fadd.4s	v1, v1, v2
	fdiv.4s	v1, v19, v1
	bif.16b	v1, v15, v5
	fcmge.4s	v2, v15, v14
	movi.4s	v14, #63, lsl #24
	bit.16b	v1, v4, v2
	mvni.4s	v2, #128, lsl #24
	bif.16b	v1, v13, v2
	fcmeq.4s	v2, v13, v13
	fadd.4s	v1, v1, v15
	ldr	q4, [sp, #112]                  ; 16-byte Reload
	bif.16b	v1, v4, v2
	fmul.4s	v2, v10, v14
	fmul.4s	v1, v2, v1
	fadd.4s	v10, v12, v1
	fmov	w14, s31
	add	x13, x9, x8
	tbnz	w14, #0, LBB1_58
; %bb.35:                               ; %else72
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_59
LBB1_36:                                ; %else74
                                        ;   in Loop: Header=BB1_17 Depth=2
	fmov.4s	v6, #9.00000000
	tbnz	w14, #2, LBB1_60
LBB1_37:                                ; %else76
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w14, #3, LBB1_39
LBB1_38:                                ; %cond.store77
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #12
	st1.s	{ v10 }[3], [x15]
LBB1_39:                                ; %else78
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldp	q2, q1, [sp, #208]              ; 32-byte Folded Reload
	fmul.4s	v1, v9, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v1, v9, v1
	fadd.4s	v1, v9, v1
	fmul.4s	v1, v1, v2
	and.16b	v10, v0, v1
	fabs.4s	v12, v10
	fmul.4s	v1, v10, v10
	ldp	q2, q4, [sp, #176]              ; 32-byte Folded Reload
	fmla.4s	v2, v1, v4
	ldr	q4, [sp, #160]                  ; 16-byte Reload
	fmla.4s	v4, v1, v2
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	fmla.4s	v2, v1, v4
	mov.16b	v4, v7
	fmla.4s	v4, v1, v2
	mov.16b	v2, v16
	fmla.4s	v2, v1, v4
	fmov.4s	v4, #1.00000000
	fmla.4s	v4, v1, v2
	fmul.4s	v2, v12, v4
	mov.16b	v4, v18
	fmla.4s	v4, v1, v17
	mov.16b	v5, v3
	fmla.4s	v5, v1, v4
	mov.16b	v4, v20
	fmla.4s	v4, v1, v5
	mov.16b	v5, v21
	fmla.4s	v5, v1, v4
	movi.4s	v4, #63, lsl #24
	fmla.4s	v4, v1, v5
	fmov.4s	v5, #1.00000000
	fmla.4s	v5, v1, v4
	fdiv.4s	v1, v2, v5
	fcmge.4s	v2, v6, v12
	and.16b	v4, v2, v12
	fcmge.4s	v5, v4, v22
	fcmge.4s	v19, v23, v4
	and.16b	v5, v5, v19
	and.16b	v5, v5, v4
	fmul.4s	v19, v5, v24
	movi.4s	v8, #75, lsl #24
	fadd.4s	v19, v19, v8
	movi.4s	v8, #203, lsl #24
	fadd.4s	v19, v19, v8
	fcvtzs.4s	v19, v19
	scvtf.4s	v8, v19
	fmul.4s	v13, v8, v25
	fadd.4s	v5, v5, v13
	fmul.4s	v8, v8, v26
	fadd.4s	v5, v5, v8
	fmul.4s	v8, v5, v27
	fadd.4s	v8, v8, v28
	fmul.4s	v8, v5, v8
	fadd.4s	v8, v8, v29
	fmul.4s	v8, v5, v8
	fadd.4s	v8, v8, v30
	fmul.4s	v8, v5, v8
	fadd.4s	v8, v8, v16
	fmul.4s	v8, v5, v8
	fadd.4s	v8, v8, v14
	fmul.4s	v13, v5, v5
	fmul.4s	v8, v13, v8
	fadd.4s	v5, v5, v8
	fadd.4s	v5, v5, v15
	movi.2d	v8, #0xffffffffffffffff
	add.4s	v19, v19, v8
	sshr.4s	v8, v19, #1
	shl.4s	v13, v8, #23
	add.4s	v13, v13, v15
	fmul.4s	v5, v5, v13
	sub.4s	v19, v19, v8
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v15
	fmul.4s	v5, v5, v19
	fcmgt.4s	v4, v4, v23
	ldr	q19, [sp, #128]                 ; 16-byte Reload
	bsl.16b	v4, v19, v5
	fmov.4s	v5, #0.25000000
	fdiv.4s	v5, v5, v4
	fsub.4s	v19, v4, v5
	fadd.4s	v4, v4, v5
	fdiv.4s	v4, v19, v4
	bsl.16b	v2, v4, v15
	fcmge.4s	v4, v15, v12
	bif.16b	v1, v2, v4
	mvni.4s	v2, #128, lsl #24
	bif.16b	v1, v10, v2
	fcmeq.4s	v2, v10, v10
	fadd.4s	v1, v1, v15
	ldr	q4, [sp, #112]                  ; 16-byte Reload
	bif.16b	v1, v4, v2
	fmul.4s	v2, v9, v14
	fmul.4s	v1, v2, v1
	fadd.4s	v9, v11, v1
	tbnz	w14, #4, LBB1_61
; %bb.40:                               ; %else80
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #5, LBB1_62
LBB1_41:                                ; %else82
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbnz	w14, #6, LBB1_63
LBB1_42:                                ; %else84
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w14, #7, LBB1_16
	b	LBB1_64
LBB1_43:                                ; %cond.load
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldr	s10, [x13]
	and	w14, w12, #0xff
	tbz	w14, #1, LBB1_19
LBB1_44:                                ; %cond.load25
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #4
	ld1.s	{ v10 }[1], [x15]
	tbz	w14, #2, LBB1_20
LBB1_45:                                ; %cond.load28
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #8
	ld1.s	{ v10 }[2], [x15]
	tbz	w14, #3, LBB1_21
LBB1_46:                                ; %cond.load31
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #12
	ld1.s	{ v10 }[3], [x15]
	tbz	w14, #4, LBB1_22
LBB1_47:                                ; %cond.load34
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #16
	ld1.s	{ v9 }[0], [x15]
	tbz	w14, #5, LBB1_23
LBB1_48:                                ; %cond.load37
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #20
	ld1.s	{ v9 }[1], [x15]
	tbz	w14, #6, LBB1_24
LBB1_49:                                ; %cond.load40
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #24
	ld1.s	{ v9 }[2], [x15]
	tbz	w14, #7, LBB1_25
LBB1_50:                                ; %cond.load43
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x13, x13, #28
	ld1.s	{ v9 }[3], [x13]
	fmov	w14, s31
	add	x13, x10, x8
	movi.2d	v12, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbz	w14, #0, LBB1_26
LBB1_51:                                ; %cond.load47
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldr	s12, [x13]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_27
LBB1_52:                                ; %cond.load50
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #4
	ld1.s	{ v12 }[1], [x15]
	tbz	w14, #2, LBB1_28
LBB1_53:                                ; %cond.load53
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #8
	ld1.s	{ v12 }[2], [x15]
	tbz	w14, #3, LBB1_29
LBB1_54:                                ; %cond.load56
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #12
	ld1.s	{ v12 }[3], [x15]
	tbz	w14, #4, LBB1_30
LBB1_55:                                ; %cond.load59
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #16
	ld1.s	{ v11 }[0], [x15]
	tbz	w14, #5, LBB1_31
LBB1_56:                                ; %cond.load62
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #20
	ld1.s	{ v11 }[1], [x15]
	tbz	w14, #6, LBB1_32
LBB1_57:                                ; %cond.load65
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #24
	ld1.s	{ v11 }[2], [x15]
	tbnz	w14, #7, LBB1_33
	b	LBB1_34
LBB1_58:                                ; %cond.store
                                        ;   in Loop: Header=BB1_17 Depth=2
	str	s10, [x13]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_36
LBB1_59:                                ; %cond.store73
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #4
	st1.s	{ v10 }[1], [x15]
	fmov.4s	v6, #9.00000000
	tbz	w14, #2, LBB1_37
LBB1_60:                                ; %cond.store75
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #8
	st1.s	{ v10 }[2], [x15]
	tbnz	w14, #3, LBB1_38
	b	LBB1_39
LBB1_61:                                ; %cond.store79
                                        ;   in Loop: Header=BB1_17 Depth=2
	str	s9, [x13, #16]
	tbz	w14, #5, LBB1_41
LBB1_62:                                ; %cond.store81
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #20
	st1.s	{ v9 }[1], [x15]
	tbz	w14, #6, LBB1_42
LBB1_63:                                ; %cond.store83
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x15, x13, #24
	st1.s	{ v9 }[2], [x15]
	tbz	w14, #7, LBB1_16
LBB1_64:                                ; %cond.store85
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x13, x13, #28
	st1.s	{ v9 }[3], [x13]
	b	LBB1_16
LBB1_65:                                ; %direct.schedule.6.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	add	x12, x12, x11
	b	LBB1_67
LBB1_66:                                ; %else110
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x13, x23, x8
	stp	q10, q11, [x13]
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB1_83
LBB1_67:                                ; %direct.true30.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q1, [sp, #96]                   ; 16-byte Reload
	and.16b	v1, v9, v1
	addv.8h	h8, v1
	fmov	w14, s8
	add	x13, x12, x8
	add	x15, x23, x8
	ldr	q10, [x15]
	tbnz	w14, #0, LBB1_75
; %bb.68:                               ; %else89
                                        ;   in Loop: Header=BB1_67 Depth=2
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_76
LBB1_69:                                ; %else92
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbnz	w14, #2, LBB1_77
LBB1_70:                                ; %else95
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbnz	w14, #3, LBB1_78
LBB1_71:                                ; %else98
                                        ;   in Loop: Header=BB1_67 Depth=2
	ldr	q11, [x15, #16]
	tbnz	w14, #4, LBB1_79
LBB1_72:                                ; %else101
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbnz	w14, #5, LBB1_80
LBB1_73:                                ; %else104
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbnz	w14, #6, LBB1_81
LBB1_74:                                ; %else107
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #7, LBB1_66
	b	LBB1_82
LBB1_75:                                ; %cond.load88
                                        ;   in Loop: Header=BB1_67 Depth=2
	ld1.s	{ v10 }[0], [x13]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_69
LBB1_76:                                ; %cond.load91
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #4
	ld1.s	{ v10 }[1], [x16]
	tbz	w14, #2, LBB1_70
LBB1_77:                                ; %cond.load94
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #8
	ld1.s	{ v10 }[2], [x16]
	tbz	w14, #3, LBB1_71
LBB1_78:                                ; %cond.load97
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #12
	ld1.s	{ v10 }[3], [x16]
	ldr	q11, [x15, #16]
	tbz	w14, #4, LBB1_72
LBB1_79:                                ; %cond.load100
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #16
	ld1.s	{ v11 }[0], [x15]
	tbz	w14, #5, LBB1_73
LBB1_80:                                ; %cond.load103
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #20
	ld1.s	{ v11 }[1], [x15]
	tbz	w14, #6, LBB1_74
LBB1_81:                                ; %cond.load106
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #24
	ld1.s	{ v11 }[2], [x15]
	tbz	w14, #7, LBB1_66
LBB1_82:                                ; %cond.load109
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x13, x13, #28
	ld1.s	{ v11 }[3], [x13]
	b	LBB1_66
LBB1_83:                                ; %direct.schedule.9.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	add	x10, x10, x11
	b	LBB1_85
LBB1_84:                                ; %else135
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x12, x24, x8
	stp	q9, q10, [x12]
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB1_101
LBB1_85:                                ; %direct.true44.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s8
	add	x12, x10, x8
	add	x14, x24, x8
	ldr	q9, [x14]
	tbnz	w13, #0, LBB1_93
; %bb.86:                               ; %else114
                                        ;   in Loop: Header=BB1_85 Depth=2
	and	w13, w13, #0xff
	ldr	q10, [x14, #16]
	tbnz	w13, #1, LBB1_94
LBB1_87:                                ; %else117
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w13, #2, LBB1_95
LBB1_88:                                ; %else120
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w13, #3, LBB1_96
LBB1_89:                                ; %else123
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w13, #4, LBB1_97
LBB1_90:                                ; %else126
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w13, #5, LBB1_98
LBB1_91:                                ; %else129
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbnz	w13, #6, LBB1_99
LBB1_92:                                ; %else132
                                        ;   in Loop: Header=BB1_85 Depth=2
	tbz	w13, #7, LBB1_84
	b	LBB1_100
LBB1_93:                                ; %cond.load113
                                        ;   in Loop: Header=BB1_85 Depth=2
	ld1.s	{ v9 }[0], [x12]
	and	w13, w13, #0xff
	ldr	q10, [x14, #16]
	tbz	w13, #1, LBB1_87
LBB1_94:                                ; %cond.load116
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #4
	ld1.s	{ v9 }[1], [x14]
	tbz	w13, #2, LBB1_88
LBB1_95:                                ; %cond.load119
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #8
	ld1.s	{ v9 }[2], [x14]
	tbz	w13, #3, LBB1_89
LBB1_96:                                ; %cond.load122
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #12
	ld1.s	{ v9 }[3], [x14]
	tbz	w13, #4, LBB1_90
LBB1_97:                                ; %cond.load125
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #16
	ld1.s	{ v10 }[0], [x14]
	tbz	w13, #5, LBB1_91
LBB1_98:                                ; %cond.load128
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #20
	ld1.s	{ v10 }[1], [x14]
	tbz	w13, #6, LBB1_92
LBB1_99:                                ; %cond.load131
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x14, x12, #24
	ld1.s	{ v10 }[2], [x14]
	tbz	w13, #7, LBB1_84
LBB1_100:                               ; %cond.load134
                                        ;   in Loop: Header=BB1_85 Depth=2
	add	x12, x12, #28
	ld1.s	{ v10 }[3], [x12]
	b	LBB1_84
LBB1_101:                               ; %direct.schedule.12.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x9, x11
	b	LBB1_103
LBB1_102:                               ; %else153
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x8, x8, #32
	cmp	x8, #3072
	b.eq	LBB1_2
LBB1_103:                               ; %direct.true61.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q1, [sp, #64]                   ; 16-byte Reload
	cmhi.4s	v8, v31, v1
	add	x10, x23, x8
	ldr	q1, [x10]
	and.16b	v9, v8, v1
	ldp	q2, q1, [sp, #208]              ; 32-byte Folded Reload
	fmul.4s	v1, v9, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v1, v9, v1
	fadd.4s	v1, v9, v1
	fmul.4s	v1, v1, v2
	and.16b	v10, v8, v1
	fabs.4s	v11, v10
	fmul.4s	v1, v10, v10
	ldp	q2, q4, [sp, #176]              ; 32-byte Folded Reload
	fmla.4s	v2, v1, v4
	ldr	q4, [sp, #160]                  ; 16-byte Reload
	fmla.4s	v4, v1, v2
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	fmla.4s	v2, v1, v4
	mov.16b	v4, v7
	fmla.4s	v4, v1, v2
	mov.16b	v2, v16
	fmla.4s	v2, v1, v4
	fmov.4s	v4, #1.00000000
	fmla.4s	v4, v1, v2
	fmul.4s	v2, v11, v4
	mov.16b	v4, v18
	fmla.4s	v4, v1, v17
	mov.16b	v5, v3
	fmla.4s	v5, v1, v4
	mov.16b	v4, v20
	fmla.4s	v4, v1, v5
	mov.16b	v5, v21
	fmla.4s	v5, v1, v4
	movi.4s	v4, #63, lsl #24
	fmla.4s	v4, v1, v5
	fmov.4s	v5, #1.00000000
	fmla.4s	v5, v1, v4
	fdiv.4s	v1, v2, v5
	fcmge.4s	v2, v6, v11
	and.16b	v4, v2, v11
	fcmge.4s	v5, v4, v22
	fcmge.4s	v19, v23, v4
	and.16b	v5, v5, v19
	and.16b	v5, v5, v4
	fmul.4s	v19, v5, v24
	movi.4s	v12, #75, lsl #24
	fadd.4s	v19, v19, v12
	movi.4s	v12, #203, lsl #24
	fadd.4s	v19, v19, v12
	fcvtzs.4s	v19, v19
	scvtf.4s	v12, v19
	fmul.4s	v13, v12, v25
	fadd.4s	v5, v5, v13
	fmul.4s	v12, v12, v26
	fadd.4s	v5, v5, v12
	fmul.4s	v12, v5, v27
	fadd.4s	v12, v12, v28
	fmul.4s	v12, v5, v12
	fadd.4s	v12, v12, v29
	fmul.4s	v12, v5, v12
	fadd.4s	v12, v12, v30
	fmul.4s	v12, v5, v12
	fadd.4s	v12, v12, v16
	fmul.4s	v12, v5, v12
	fadd.4s	v12, v12, v14
	fmul.4s	v13, v5, v5
	fmul.4s	v12, v13, v12
	fadd.4s	v5, v5, v12
	fadd.4s	v5, v5, v15
	movi.2d	v12, #0xffffffffffffffff
	add.4s	v19, v19, v12
	sshr.4s	v12, v19, #1
	shl.4s	v13, v12, #23
	add.4s	v13, v13, v15
	fmul.4s	v5, v5, v13
	sub.4s	v19, v19, v12
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v15
	fmul.4s	v5, v5, v19
	fcmgt.4s	v4, v4, v23
	ldr	q19, [sp, #128]                 ; 16-byte Reload
	bsl.16b	v4, v19, v5
	fmov.4s	v5, #0.25000000
	fdiv.4s	v5, v5, v4
	fsub.4s	v19, v4, v5
	fadd.4s	v4, v4, v5
	fdiv.4s	v4, v19, v4
	bsl.16b	v2, v4, v15
	fcmge.4s	v4, v15, v11
	bif.16b	v1, v2, v4
	uzp1.8h	v2, v8, v0
	ldp	q5, q4, [sp, #96]               ; 32-byte Folded Reload
	and.16b	v2, v2, v5
	addv.8h	h2, v2
	fmov	w11, s2
	mvni.4s	v2, #128, lsl #24
	bif.16b	v1, v10, v2
	fcmeq.4s	v2, v10, v10
	fadd.4s	v1, v1, v15
	bif.16b	v1, v4, v2
	fmul.4s	v2, v9, v14
	fmul.4s	v1, v2, v1
	add	x12, x24, x8
	ldr	q2, [x12]
	and.16b	v2, v8, v2
	ldr	q9, [x10, #16]
	fadd.4s	v10, v2, v1
	ldr	q8, [x12, #16]
	add	x10, x9, x8
	tbnz	w11, #0, LBB1_112
; %bb.104:                              ; %else139
                                        ;   in Loop: Header=BB1_103 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_113
LBB1_105:                               ; %else141
                                        ;   in Loop: Header=BB1_103 Depth=2
	tbnz	w11, #2, LBB1_114
LBB1_106:                               ; %else143
                                        ;   in Loop: Header=BB1_103 Depth=2
	tbz	w11, #3, LBB1_108
LBB1_107:                               ; %cond.store144
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x12, x10, #12
	st1.s	{ v10 }[3], [x12]
LBB1_108:                               ; %else145
                                        ;   in Loop: Header=BB1_103 Depth=2
	and.16b	v9, v0, v9
	ldp	q2, q1, [sp, #208]              ; 32-byte Folded Reload
	fmul.4s	v1, v9, v1
	fmul.4s	v1, v9, v1
	fmul.4s	v1, v9, v1
	fadd.4s	v1, v9, v1
	fmul.4s	v1, v1, v2
	and.16b	v10, v0, v1
	fabs.4s	v11, v10
	fmul.4s	v1, v10, v10
	ldp	q2, q4, [sp, #176]              ; 32-byte Folded Reload
	fmla.4s	v2, v1, v4
	ldr	q4, [sp, #160]                  ; 16-byte Reload
	fmla.4s	v4, v1, v2
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	fmla.4s	v2, v1, v4
	mov.16b	v4, v7
	fmla.4s	v4, v1, v2
	mov.16b	v2, v16
	fmla.4s	v2, v1, v4
	fmov.4s	v4, #1.00000000
	fmla.4s	v4, v1, v2
	fmul.4s	v2, v11, v4
	mov.16b	v4, v18
	fmla.4s	v4, v1, v17
	mov.16b	v5, v3
	fmla.4s	v5, v1, v4
	mov.16b	v4, v20
	fmla.4s	v4, v1, v5
	mov.16b	v5, v21
	fmla.4s	v5, v1, v4
	movi.4s	v4, #63, lsl #24
	fmla.4s	v4, v1, v5
	fmov.4s	v5, #1.00000000
	fmla.4s	v5, v1, v4
	fdiv.4s	v1, v2, v5
	fcmge.4s	v2, v6, v11
	and.16b	v4, v2, v11
	fcmge.4s	v5, v4, v22
	fcmge.4s	v19, v23, v4
	and.16b	v5, v5, v19
	and.16b	v5, v5, v4
	fmul.4s	v19, v5, v24
	movi.4s	v12, #75, lsl #24
	fadd.4s	v19, v19, v12
	movi.4s	v12, #203, lsl #24
	fadd.4s	v19, v19, v12
	fcvtzs.4s	v19, v19
	scvtf.4s	v12, v19
	fmul.4s	v13, v12, v25
	fadd.4s	v5, v5, v13
	fmul.4s	v12, v12, v26
	fadd.4s	v5, v5, v12
	fmul.4s	v12, v5, v27
	fadd.4s	v12, v12, v28
	fmul.4s	v12, v5, v12
	fadd.4s	v12, v12, v29
	fmul.4s	v12, v5, v12
	fadd.4s	v12, v12, v30
	fmul.4s	v12, v5, v12
	fadd.4s	v12, v12, v16
	fmul.4s	v12, v5, v12
	fadd.4s	v12, v12, v14
	fmul.4s	v13, v5, v5
	fmul.4s	v12, v13, v12
	fadd.4s	v5, v5, v12
	fadd.4s	v5, v5, v15
	movi.2d	v12, #0xffffffffffffffff
	add.4s	v19, v19, v12
	sshr.4s	v12, v19, #1
	shl.4s	v13, v12, #23
	add.4s	v13, v13, v15
	fmul.4s	v5, v5, v13
	sub.4s	v19, v19, v12
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v15
	fmul.4s	v5, v5, v19
	fcmgt.4s	v4, v4, v23
	ldr	q19, [sp, #128]                 ; 16-byte Reload
	bsl.16b	v4, v19, v5
	fmov.4s	v5, #0.25000000
	fdiv.4s	v5, v5, v4
	fsub.4s	v19, v4, v5
	fadd.4s	v4, v4, v5
	fdiv.4s	v4, v19, v4
	bsl.16b	v2, v4, v15
	fcmge.4s	v4, v15, v11
	bif.16b	v1, v2, v4
	mvni.4s	v2, #128, lsl #24
	bif.16b	v1, v10, v2
	fcmeq.4s	v2, v10, v10
	fadd.4s	v1, v1, v15
	ldr	q4, [sp, #112]                  ; 16-byte Reload
	bif.16b	v1, v4, v2
	fmul.4s	v2, v9, v14
	fmul.4s	v1, v2, v1
	and.16b	v2, v0, v8
	fadd.4s	v8, v2, v1
	tbnz	w11, #4, LBB1_115
; %bb.109:                              ; %else147
                                        ;   in Loop: Header=BB1_103 Depth=2
	tbnz	w11, #5, LBB1_116
LBB1_110:                               ; %else149
                                        ;   in Loop: Header=BB1_103 Depth=2
	tbnz	w11, #6, LBB1_117
LBB1_111:                               ; %else151
                                        ;   in Loop: Header=BB1_103 Depth=2
	tbz	w11, #7, LBB1_102
	b	LBB1_118
LBB1_112:                               ; %cond.store138
                                        ;   in Loop: Header=BB1_103 Depth=2
	str	s10, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_105
LBB1_113:                               ; %cond.store140
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x12, x10, #4
	st1.s	{ v10 }[1], [x12]
	tbz	w11, #2, LBB1_106
LBB1_114:                               ; %cond.store142
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x12, x10, #8
	st1.s	{ v10 }[2], [x12]
	tbnz	w11, #3, LBB1_107
	b	LBB1_108
LBB1_115:                               ; %cond.store146
                                        ;   in Loop: Header=BB1_103 Depth=2
	str	s8, [x10, #16]
	tbz	w11, #5, LBB1_110
LBB1_116:                               ; %cond.store148
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x12, x10, #20
	st1.s	{ v8 }[1], [x12]
	tbz	w11, #6, LBB1_111
LBB1_117:                               ; %cond.store150
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x12, x10, #24
	st1.s	{ v8 }[2], [x12]
	tbz	w11, #7, LBB1_102
LBB1_118:                               ; %cond.store152
                                        ;   in Loop: Header=BB1_103 Depth=2
	add	x10, x10, #28
	st1.s	{ v8 }[3], [x10]
	b	LBB1_102
LBB1_119:                               ; %block.batch.exit
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2304
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

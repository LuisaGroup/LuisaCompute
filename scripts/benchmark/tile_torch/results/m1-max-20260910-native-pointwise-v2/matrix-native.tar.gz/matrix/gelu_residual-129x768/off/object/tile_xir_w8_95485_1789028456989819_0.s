	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #2576
	str	x0, [sp, #56]                   ; 8-byte Spill
	cbz	w3, LBB0_75
; %bb.1:                                ; %block.batch.loop.preheader
	mov	w22, #0                         ; =0x0
	ldp	w4, w8, [x2, #44]
	str	w8, [sp, #44]                   ; 4-byte Spill
	add	x27, sp, #3600
	ldp	w8, w9, [x2]
	add	x28, sp, #528
	mov	w10, #10003                     ; =0x2713
	movk	w10, #15671, lsl #16
	mov	w11, #16938                     ; =0x422a
	movk	w11, #16204, lsl #16
	dup.4s	v16, w10
	fmov.4s	v8, #1.00000000
	dup.4s	v9, w11
	mov	w10, #37425                     ; =0x9231
	movk	w10, #12080, lsl #16
	dup.4s	v28, w10
	mov	w10, #12843                     ; =0x322b
	movk	w10, #13015, lsl #16
	dup.4s	v23, w10
	mov	w10, #61213                     ; =0xef1d
	movk	w10, #13880, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #304]                  ; 16-byte Spill
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14672, lsl #16
	dup.4s	v20, w10
	mov	w10, #34953                     ; =0x8889
	movk	w10, #15368, lsl #16
	dup.4s	v22, w10
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #176]                  ; 16-byte Spill
	mov	w10, #30407                     ; =0x76c7
	movk	w10, #12559, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #496]                  ; 16-byte Spill
	mov	w10, #62078                     ; =0xf27e
	movk	w10, #13459, lsl #16
	dup.4s	v15, w10
	mov	w10, #3329                      ; =0xd01
	movk	w10, #14288, lsl #16
	dup.4s	v25, w10
	mov	w10, #2913                      ; =0xb61
	movk	w10, #15030, lsl #16
	dup.4s	v31, w10
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15658, lsl #16
	dup.4s	v12, w10
	mov	w11, #-1026555904               ; =0xc2d00000
	mov	w12, #1120403456                ; =0x42c80000
	mov	w13, #43579                     ; =0xaa3b
	movk	w13, #16312, lsl #16
	ldp	w10, w14, [x2, #8]
	str	x2, [sp, #16]                   ; 8-byte Spill
	str	x14, [sp, #32]                  ; 8-byte Spill
	dup.4s	v2, w11
	dup.4s	v10, w12
	mov	w11, #29184                     ; =0x7200
	movk	w11, #48945, lsl #16
	dup.4s	v1, w13
	mov	w12, #48782                     ; =0xbe8e
	movk	w12, #46527, lsl #16
	dup.4s	v0, w11
	stp	q0, q1, [sp, #464]              ; 32-byte Folded Spill
	mov	w11, #11226                     ; =0x2bda
	movk	w11, #14672, lsl #16
	dup.4s	v29, w12
	mov	w12, #38601                     ; =0x96c9
	movk	w12, #15030, lsl #16
	dup.4s	v30, w11
	mov	w11, #34982                     ; =0x88a6
	movk	w11, #15368, lsl #16
	dup.4s	v26, w12
	mov	w12, #43642                     ; =0xaa7a
	movk	w12, #15658, lsl #16
	dup.4s	v13, w11
	dup.4s	v1, w12
	mvni.4s	v0, #127, msl #16
	fneg.4s	v3, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q3, [sp, #192]              ; 32-byte Folded Spill
	stp	q20, q16, [sp, #144]            ; 32-byte Folded Spill
	stp	q28, q9, [sp, #272]             ; 32-byte Folded Spill
	stp	q10, q23, [sp, #240]            ; 32-byte Folded Spill
	str	q22, [sp, #128]                 ; 16-byte Spill
	str	q1, [sp, #224]                  ; 16-byte Spill
	stp	w4, w3, [sp, #48]               ; 8-byte Folded Spill
	stp	q25, q15, [sp, #368]            ; 32-byte Folded Spill
	stp	q12, q31, [sp, #336]            ; 32-byte Folded Spill
	str	q2, [sp, #320]                  ; 16-byte Spill
	stp	q30, q29, [sp, #432]            ; 32-byte Folded Spill
	stp	q13, q26, [sp, #400]            ; 32-byte Folded Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w8, w2, #1
	cmp	w8, w4
	cset	w9, eq
	csinc	w8, wzr, w2, eq
	cinc	w10, w1, eq
	ldr	w11, [sp, #44]                  ; 4-byte Reload
	cmp	w10, w11
	cset	w11, eq
	ands	w11, w9, w11
	csel	w9, wzr, w10, ne
	add	w10, w20, w11
	add	w22, w22, #1
	cmp	w22, w3
	b.eq	LBB0_74
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_15 Depth 2
                                        ;       Child Loop BB0_16 Depth 3
                                        ;     Child Loop BB0_22 Depth 2
                                        ;     Child Loop BB0_40 Depth 2
                                        ;     Child Loop BB0_58 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
	mov	x20, x10
	mov	x14, x9
	mov	x15, x8
	ubfiz	x8, x8, #5, #32
	ldr	x12, [sp, #32]                  ; 8-byte Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	ccmp	x8, x12, #2, hi
	csel	x8, x10, xzr, ls
	cmp	x8, #32
	str	w14, [sp, #68]                  ; 4-byte Spill
	str	x15, [sp, #72]                  ; 8-byte Spill
	b.lo	LBB0_13
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x8, [sp, #56]                   ; 8-byte Reload
	ldr	x21, [x8]
	ldr	x24, [x8, #16]
	ldr	x23, [x8, #48]
	ubfiz	w25, w15, #2, #27
	mov	w19, #3072                      ; =0xc00
	umaddl	x1, w25, w19, x21
	add	x0, sp, #3600
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	umaddl	x1, w25, w19, x24
	add	x0, sp, #528
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldp	q31, q15, [sp, #160]            ; 32-byte Folded Reload
	ldp	q14, q13, [sp, #128]            ; 32-byte Folded Reload
	ldp	q9, q12, [sp, #288]             ; 32-byte Folded Reload
	ldp	q11, q10, [sp, #256]            ; 32-byte Folded Reload
	fmov.4s	v8, #1.00000000
	mov	x8, #0                          ; =0x0
	umaddl	x9, w25, w19, x23
LBB0_5:                                 ; %direct.true44.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q0, q1, [x10]
	fmul.4s	v2, v0, v31
	fmul.4s	v3, v1, v31
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fmul.4s	v2, v0, v2
	fmul.4s	v3, v1, v3
	fadd.4s	v4, v1, v3
	fadd.4s	v2, v0, v2
	fmul.4s	v3, v2, v9
	fmul.4s	v2, v4, v9
	fabs.4s	v5, v2
	fabs.4s	v4, v3
	fmul.4s	v19, v3, v3
	fmul.4s	v21, v2, v2
	mov.16b	v6, v11
	fmla.4s	v6, v19, v10
	mov.16b	v7, v11
	fmla.4s	v7, v21, v10
	mov.16b	v16, v12
	fmla.4s	v16, v19, v6
	mov.16b	v6, v12
	fmla.4s	v6, v21, v7
	mov.16b	v7, v13
	fmla.4s	v7, v19, v16
	mov.16b	v16, v13
	fmla.4s	v16, v21, v6
	mov.16b	v17, v14
	mov.16b	v18, v14
	mov.16b	v22, v15
	mov.16b	v23, v15
	fmov.4s	v6, #1.00000000
	fmla.4s	v17, v19, v7
	ldp	q25, q20, [sp, #368]            ; 32-byte Folded Reload
	mov.16b	v7, v20
	ldr	q24, [sp, #496]                 ; 16-byte Reload
	fmla.4s	v7, v21, v24
	fmla.4s	v20, v19, v24
	mov.16b	v24, v25
	fmla.4s	v18, v21, v16
	fmla.4s	v24, v21, v7
	mov.16b	v7, v25
	fmla.4s	v7, v19, v20
	ldr	q20, [sp, #352]                 ; 16-byte Reload
	mov.16b	v16, v20
	fmla.4s	v16, v21, v24
	fmla.4s	v22, v19, v17
	mov.16b	v17, v20
	fmla.4s	v17, v19, v7
	ldp	q28, q24, [sp, #320]            ; 32-byte Folded Reload
	mov.16b	v20, v24
	fmla.4s	v20, v21, v16
	fmla.4s	v23, v21, v18
	fmla.4s	v24, v19, v17
	movi.4s	v25, #63, lsl #24
	movi.4s	v26, #63, lsl #24
	fmov.4s	v17, #1.00000000
	fmov.4s	v16, #9.00000000
	fcmge.4s	v7, v16, v4
	fmla.4s	v25, v21, v20
	fcmge.4s	v16, v16, v5
	and.16b	v18, v16, v5
	and.16b	v20, v7, v4
	fcmge.4s	v27, v20, v28
	fcmge.4s	v28, v18, v28
	ldr	q29, [sp, #240]                 ; 16-byte Reload
	fcmge.4s	v29, v29, v18
	and.16b	v28, v28, v29
	ldr	q29, [sp, #240]                 ; 16-byte Reload
	fcmge.4s	v29, v29, v20
	and.16b	v27, v27, v29
	and.16b	v27, v27, v20
	and.16b	v28, v28, v18
	fmla.4s	v6, v21, v23
	ldr	q29, [sp, #480]                 ; 16-byte Reload
	fmul.4s	v23, v28, v29
	fmul.4s	v29, v27, v29
	movi.4s	v30, #75, lsl #24
	fadd.4s	v29, v29, v30
	fadd.4s	v23, v23, v30
	movi.4s	v30, #203, lsl #24
	fadd.4s	v23, v23, v30
	fmla.4s	v17, v21, v25
	fadd.4s	v21, v29, v30
	fcvtzs.4s	v21, v21
	fcvtzs.4s	v23, v23
	scvtf.4s	v25, v23
	scvtf.4s	v29, v21
	fmla.4s	v26, v19, v24
	ldr	q30, [sp, #464]                 ; 16-byte Reload
	fmul.4s	v24, v25, v30
	fadd.4s	v24, v28, v24
	fmul.4s	v28, v29, v30
	fadd.4s	v27, v27, v28
	fmov.4s	v28, #1.00000000
	fmla.4s	v28, v19, v22
	ldr	q30, [sp, #448]                 ; 16-byte Reload
	fmul.4s	v22, v29, v30
	fadd.4s	v22, v27, v22
	fmul.4s	v25, v25, v30
	fadd.4s	v24, v24, v25
	fmov.4s	v25, #1.00000000
	fmla.4s	v25, v19, v26
	ldp	q27, q26, [sp, #416]            ; 32-byte Folded Reload
	fmul.4s	v19, v24, v26
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v27
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v24, v19
	fmul.4s	v27, v4, v28
	fmul.4s	v26, v22, v26
	ldr	q28, [sp, #400]                 ; 16-byte Reload
	fadd.4s	v26, v26, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v24, v19
	fmul.4s	v26, v22, v26
	ldp	q28, q29, [sp, #224]            ; 32-byte Folded Reload
	fadd.4s	v26, v26, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v24, v19
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v15
	fadd.4s	v28, v19, v15
	fdiv.4s	v19, v27, v25
	fmul.4s	v25, v24, v28
	fmul.4s	v26, v22, v26
	movi.4s	v28, #63, lsl #24
	fadd.4s	v26, v26, v28
	fadd.4s	v25, v25, v28
	fmul.4s	v27, v24, v24
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v22, v22
	fmul.4s	v26, v27, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v24, v24, v25
	movi.2d	v27, #0xffffffffffffffff
	add.4s	v21, v21, v27
	fadd.4s	v22, v22, v8
	sshr.4s	v25, v21, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v8
	fmul.4s	v22, v22, v26
	add.4s	v23, v23, v27
	fadd.4s	v24, v24, v8
	sub.4s	v21, v21, v25
	sshr.4s	v25, v23, #1
	sub.4s	v23, v23, v25
	shl.4s	v25, v25, #23
	add.4s	v25, v25, v8
	fmul.4s	v24, v24, v25
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v8
	fmul.4s	v23, v24, v23
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v8
	fmul.4s	v21, v22, v21
	fcmgt.4s	v20, v20, v29
	ldr	q22, [sp, #208]                 ; 16-byte Reload
	bsl.16b	v20, v22, v21
	fmul.4s	v6, v5, v6
	fcmgt.4s	v18, v18, v29
	bsl.16b	v18, v22, v23
	fdiv.4s	v6, v6, v17
	fmov.4s	v22, #0.25000000
	fdiv.4s	v17, v22, v18
	fsub.4s	v21, v18, v17
	fadd.4s	v17, v18, v17
	fdiv.4s	v17, v21, v17
	bsl.16b	v16, v17, v8
	fcmge.4s	v5, v8, v5
	bsl.16b	v5, v6, v16
	fdiv.4s	v6, v22, v20
	fsub.4s	v16, v20, v6
	fadd.4s	v6, v20, v6
	fdiv.4s	v6, v16, v6
	bif.16b	v6, v8, v7
	fcmge.4s	v4, v8, v4
	bsl.16b	v4, v19, v6
	mvni.4s	v6, #128, lsl #24
	bif.16b	v4, v3, v6
	fcmeq.4s	v3, v3, v3
	fadd.4s	v4, v4, v8
	ldr	q7, [sp, #192]                  ; 16-byte Reload
	bsl.16b	v3, v4, v7
	mov.16b	v4, v6
	bsl.16b	v4, v5, v2
	fcmeq.4s	v2, v2, v2
	fadd.4s	v4, v4, v8
	bsl.16b	v2, v4, v7
	fmul.4s	v1, v1, v28
	fmul.4s	v1, v1, v2
	fmul.4s	v0, v0, v28
	fmul.4s	v0, v0, v3
	add	x10, x28, x8
	ldp	q3, q2, [x10]
	fadd.4s	v0, v3, v0
	fadd.4s	v1, v2, v1
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_5
; %bb.6:                                ; %llm_rows.full_packet.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	orr	w19, w25, #0x1
	mov	w26, #3072                      ; =0xc00
	umaddl	x1, w19, w26, x21
	add	x0, sp, #3600
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	umaddl	x1, w19, w26, x24
	add	x0, sp, #528
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldp	q31, q15, [sp, #160]            ; 32-byte Folded Reload
	ldp	q14, q13, [sp, #128]            ; 32-byte Folded Reload
	ldp	q9, q12, [sp, #288]             ; 32-byte Folded Reload
	ldp	q11, q10, [sp, #256]            ; 32-byte Folded Reload
	fmov.4s	v8, #1.00000000
	mov	x8, #0                          ; =0x0
	umaddl	x9, w19, w26, x23
LBB0_7:                                 ; %direct.true44.i10.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q0, q1, [x10]
	fmul.4s	v2, v0, v31
	fmul.4s	v3, v1, v31
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fmul.4s	v2, v0, v2
	fmul.4s	v3, v1, v3
	fadd.4s	v4, v1, v3
	fadd.4s	v2, v0, v2
	fmul.4s	v3, v2, v9
	fmul.4s	v2, v4, v9
	fabs.4s	v5, v2
	fabs.4s	v4, v3
	fmul.4s	v19, v3, v3
	fmul.4s	v21, v2, v2
	mov.16b	v6, v11
	fmla.4s	v6, v19, v10
	mov.16b	v7, v11
	fmla.4s	v7, v21, v10
	mov.16b	v16, v12
	fmla.4s	v16, v19, v6
	mov.16b	v6, v12
	fmla.4s	v6, v21, v7
	mov.16b	v7, v13
	fmla.4s	v7, v19, v16
	mov.16b	v16, v13
	fmla.4s	v16, v21, v6
	mov.16b	v17, v14
	mov.16b	v18, v14
	mov.16b	v22, v15
	mov.16b	v23, v15
	fmov.4s	v6, #1.00000000
	fmla.4s	v17, v19, v7
	ldp	q25, q20, [sp, #368]            ; 32-byte Folded Reload
	mov.16b	v7, v20
	ldr	q24, [sp, #496]                 ; 16-byte Reload
	fmla.4s	v7, v21, v24
	fmla.4s	v20, v19, v24
	mov.16b	v24, v25
	fmla.4s	v18, v21, v16
	fmla.4s	v24, v21, v7
	mov.16b	v7, v25
	fmla.4s	v7, v19, v20
	ldr	q20, [sp, #352]                 ; 16-byte Reload
	mov.16b	v16, v20
	fmla.4s	v16, v21, v24
	fmla.4s	v22, v19, v17
	mov.16b	v17, v20
	fmla.4s	v17, v19, v7
	ldp	q28, q24, [sp, #320]            ; 32-byte Folded Reload
	mov.16b	v20, v24
	fmla.4s	v20, v21, v16
	fmla.4s	v23, v21, v18
	fmla.4s	v24, v19, v17
	movi.4s	v25, #63, lsl #24
	movi.4s	v26, #63, lsl #24
	fmov.4s	v17, #1.00000000
	fmov.4s	v16, #9.00000000
	fcmge.4s	v7, v16, v4
	fmla.4s	v25, v21, v20
	fcmge.4s	v16, v16, v5
	and.16b	v18, v16, v5
	and.16b	v20, v7, v4
	fcmge.4s	v27, v20, v28
	fcmge.4s	v28, v18, v28
	ldr	q29, [sp, #240]                 ; 16-byte Reload
	fcmge.4s	v29, v29, v18
	and.16b	v28, v28, v29
	ldr	q29, [sp, #240]                 ; 16-byte Reload
	fcmge.4s	v29, v29, v20
	and.16b	v27, v27, v29
	and.16b	v27, v27, v20
	and.16b	v28, v28, v18
	fmla.4s	v6, v21, v23
	ldr	q29, [sp, #480]                 ; 16-byte Reload
	fmul.4s	v23, v28, v29
	fmul.4s	v29, v27, v29
	movi.4s	v30, #75, lsl #24
	fadd.4s	v29, v29, v30
	fadd.4s	v23, v23, v30
	movi.4s	v30, #203, lsl #24
	fadd.4s	v23, v23, v30
	fmla.4s	v17, v21, v25
	fadd.4s	v21, v29, v30
	fcvtzs.4s	v21, v21
	fcvtzs.4s	v23, v23
	scvtf.4s	v25, v23
	scvtf.4s	v29, v21
	fmla.4s	v26, v19, v24
	ldr	q30, [sp, #464]                 ; 16-byte Reload
	fmul.4s	v24, v25, v30
	fadd.4s	v24, v28, v24
	fmul.4s	v28, v29, v30
	fadd.4s	v27, v27, v28
	fmov.4s	v28, #1.00000000
	fmla.4s	v28, v19, v22
	ldr	q30, [sp, #448]                 ; 16-byte Reload
	fmul.4s	v22, v29, v30
	fadd.4s	v22, v27, v22
	fmul.4s	v25, v25, v30
	fadd.4s	v24, v24, v25
	fmov.4s	v25, #1.00000000
	fmla.4s	v25, v19, v26
	ldp	q27, q26, [sp, #416]            ; 32-byte Folded Reload
	fmul.4s	v19, v24, v26
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v27
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v24, v19
	fmul.4s	v27, v4, v28
	fmul.4s	v26, v22, v26
	ldr	q28, [sp, #400]                 ; 16-byte Reload
	fadd.4s	v26, v26, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v24, v19
	fmul.4s	v26, v22, v26
	ldp	q28, q29, [sp, #224]            ; 32-byte Folded Reload
	fadd.4s	v26, v26, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v24, v19
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v15
	fadd.4s	v28, v19, v15
	fdiv.4s	v19, v27, v25
	fmul.4s	v25, v24, v28
	fmul.4s	v26, v22, v26
	movi.4s	v28, #63, lsl #24
	fadd.4s	v26, v26, v28
	fadd.4s	v25, v25, v28
	fmul.4s	v27, v24, v24
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v22, v22
	fmul.4s	v26, v27, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v24, v24, v25
	movi.2d	v27, #0xffffffffffffffff
	add.4s	v21, v21, v27
	fadd.4s	v22, v22, v8
	sshr.4s	v25, v21, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v8
	fmul.4s	v22, v22, v26
	add.4s	v23, v23, v27
	fadd.4s	v24, v24, v8
	sub.4s	v21, v21, v25
	sshr.4s	v25, v23, #1
	sub.4s	v23, v23, v25
	shl.4s	v25, v25, #23
	add.4s	v25, v25, v8
	fmul.4s	v24, v24, v25
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v8
	fmul.4s	v23, v24, v23
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v8
	fmul.4s	v21, v22, v21
	fcmgt.4s	v20, v20, v29
	ldr	q22, [sp, #208]                 ; 16-byte Reload
	bsl.16b	v20, v22, v21
	fmul.4s	v6, v5, v6
	fcmgt.4s	v18, v18, v29
	bsl.16b	v18, v22, v23
	fdiv.4s	v6, v6, v17
	fmov.4s	v22, #0.25000000
	fdiv.4s	v17, v22, v18
	fsub.4s	v21, v18, v17
	fadd.4s	v17, v18, v17
	fdiv.4s	v17, v21, v17
	bsl.16b	v16, v17, v8
	fcmge.4s	v5, v8, v5
	bsl.16b	v5, v6, v16
	fdiv.4s	v6, v22, v20
	fsub.4s	v16, v20, v6
	fadd.4s	v6, v20, v6
	fdiv.4s	v6, v16, v6
	bif.16b	v6, v8, v7
	fcmge.4s	v4, v8, v4
	bsl.16b	v4, v19, v6
	mvni.4s	v6, #128, lsl #24
	bif.16b	v4, v3, v6
	fcmeq.4s	v3, v3, v3
	fadd.4s	v4, v4, v8
	ldr	q7, [sp, #192]                  ; 16-byte Reload
	bsl.16b	v3, v4, v7
	mov.16b	v4, v6
	bsl.16b	v4, v5, v2
	fcmeq.4s	v2, v2, v2
	fadd.4s	v4, v4, v8
	bsl.16b	v2, v4, v7
	fmul.4s	v1, v1, v28
	fmul.4s	v1, v1, v2
	fmul.4s	v0, v0, v28
	fmul.4s	v0, v0, v3
	add	x10, x28, x8
	ldp	q3, q2, [x10]
	fadd.4s	v0, v3, v0
	fadd.4s	v1, v2, v1
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_7
; %bb.8:                                ; %llm_rows.full_packet.exit18.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	orr	w19, w25, #0x2
	mov	w26, #3072                      ; =0xc00
	umaddl	x1, w19, w26, x21
	add	x0, sp, #3600
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	umaddl	x1, w19, w26, x24
	add	x0, sp, #528
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldp	q31, q15, [sp, #160]            ; 32-byte Folded Reload
	ldp	q14, q13, [sp, #128]            ; 32-byte Folded Reload
	ldp	q9, q12, [sp, #288]             ; 32-byte Folded Reload
	ldp	q11, q10, [sp, #256]            ; 32-byte Folded Reload
	fmov.4s	v8, #1.00000000
	mov	x8, #0                          ; =0x0
	umaddl	x9, w19, w26, x23
LBB0_9:                                 ; %direct.true44.i26.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q0, q1, [x10]
	fmul.4s	v2, v0, v31
	fmul.4s	v3, v1, v31
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fmul.4s	v2, v0, v2
	fmul.4s	v3, v1, v3
	fadd.4s	v4, v1, v3
	fadd.4s	v2, v0, v2
	fmul.4s	v3, v2, v9
	fmul.4s	v2, v4, v9
	fabs.4s	v5, v2
	fabs.4s	v4, v3
	fmul.4s	v19, v3, v3
	fmul.4s	v21, v2, v2
	mov.16b	v6, v11
	fmla.4s	v6, v19, v10
	mov.16b	v7, v11
	fmla.4s	v7, v21, v10
	mov.16b	v16, v12
	fmla.4s	v16, v19, v6
	mov.16b	v6, v12
	fmla.4s	v6, v21, v7
	mov.16b	v7, v13
	fmla.4s	v7, v19, v16
	mov.16b	v16, v13
	fmla.4s	v16, v21, v6
	mov.16b	v17, v14
	mov.16b	v18, v14
	mov.16b	v22, v15
	mov.16b	v23, v15
	fmov.4s	v6, #1.00000000
	fmla.4s	v17, v19, v7
	ldp	q25, q20, [sp, #368]            ; 32-byte Folded Reload
	mov.16b	v7, v20
	ldr	q24, [sp, #496]                 ; 16-byte Reload
	fmla.4s	v7, v21, v24
	fmla.4s	v20, v19, v24
	mov.16b	v24, v25
	fmla.4s	v18, v21, v16
	fmla.4s	v24, v21, v7
	mov.16b	v7, v25
	fmla.4s	v7, v19, v20
	ldr	q20, [sp, #352]                 ; 16-byte Reload
	mov.16b	v16, v20
	fmla.4s	v16, v21, v24
	fmla.4s	v22, v19, v17
	mov.16b	v17, v20
	fmla.4s	v17, v19, v7
	ldp	q28, q24, [sp, #320]            ; 32-byte Folded Reload
	mov.16b	v20, v24
	fmla.4s	v20, v21, v16
	fmla.4s	v23, v21, v18
	fmla.4s	v24, v19, v17
	movi.4s	v25, #63, lsl #24
	movi.4s	v26, #63, lsl #24
	fmov.4s	v17, #1.00000000
	fmov.4s	v16, #9.00000000
	fcmge.4s	v7, v16, v4
	fmla.4s	v25, v21, v20
	fcmge.4s	v16, v16, v5
	and.16b	v18, v16, v5
	and.16b	v20, v7, v4
	fcmge.4s	v27, v20, v28
	fcmge.4s	v28, v18, v28
	ldr	q29, [sp, #240]                 ; 16-byte Reload
	fcmge.4s	v29, v29, v18
	and.16b	v28, v28, v29
	ldr	q29, [sp, #240]                 ; 16-byte Reload
	fcmge.4s	v29, v29, v20
	and.16b	v27, v27, v29
	and.16b	v27, v27, v20
	and.16b	v28, v28, v18
	fmla.4s	v6, v21, v23
	ldr	q29, [sp, #480]                 ; 16-byte Reload
	fmul.4s	v23, v28, v29
	fmul.4s	v29, v27, v29
	movi.4s	v30, #75, lsl #24
	fadd.4s	v29, v29, v30
	fadd.4s	v23, v23, v30
	movi.4s	v30, #203, lsl #24
	fadd.4s	v23, v23, v30
	fmla.4s	v17, v21, v25
	fadd.4s	v21, v29, v30
	fcvtzs.4s	v21, v21
	fcvtzs.4s	v23, v23
	scvtf.4s	v25, v23
	scvtf.4s	v29, v21
	fmla.4s	v26, v19, v24
	ldr	q30, [sp, #464]                 ; 16-byte Reload
	fmul.4s	v24, v25, v30
	fadd.4s	v24, v28, v24
	fmul.4s	v28, v29, v30
	fadd.4s	v27, v27, v28
	fmov.4s	v28, #1.00000000
	fmla.4s	v28, v19, v22
	ldr	q30, [sp, #448]                 ; 16-byte Reload
	fmul.4s	v22, v29, v30
	fadd.4s	v22, v27, v22
	fmul.4s	v25, v25, v30
	fadd.4s	v24, v24, v25
	fmov.4s	v25, #1.00000000
	fmla.4s	v25, v19, v26
	ldp	q27, q26, [sp, #416]            ; 32-byte Folded Reload
	fmul.4s	v19, v24, v26
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v27
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v24, v19
	fmul.4s	v27, v4, v28
	fmul.4s	v26, v22, v26
	ldr	q28, [sp, #400]                 ; 16-byte Reload
	fadd.4s	v26, v26, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v24, v19
	fmul.4s	v26, v22, v26
	ldp	q28, q29, [sp, #224]            ; 32-byte Folded Reload
	fadd.4s	v26, v26, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v24, v19
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v15
	fadd.4s	v28, v19, v15
	fdiv.4s	v19, v27, v25
	fmul.4s	v25, v24, v28
	fmul.4s	v26, v22, v26
	movi.4s	v28, #63, lsl #24
	fadd.4s	v26, v26, v28
	fadd.4s	v25, v25, v28
	fmul.4s	v27, v24, v24
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v22, v22
	fmul.4s	v26, v27, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v24, v24, v25
	movi.2d	v27, #0xffffffffffffffff
	add.4s	v21, v21, v27
	fadd.4s	v22, v22, v8
	sshr.4s	v25, v21, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v8
	fmul.4s	v22, v22, v26
	add.4s	v23, v23, v27
	fadd.4s	v24, v24, v8
	sub.4s	v21, v21, v25
	sshr.4s	v25, v23, #1
	sub.4s	v23, v23, v25
	shl.4s	v25, v25, #23
	add.4s	v25, v25, v8
	fmul.4s	v24, v24, v25
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v8
	fmul.4s	v23, v24, v23
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v8
	fmul.4s	v21, v22, v21
	fcmgt.4s	v20, v20, v29
	ldr	q22, [sp, #208]                 ; 16-byte Reload
	bsl.16b	v20, v22, v21
	fmul.4s	v6, v5, v6
	fcmgt.4s	v18, v18, v29
	bsl.16b	v18, v22, v23
	fdiv.4s	v6, v6, v17
	fmov.4s	v22, #0.25000000
	fdiv.4s	v17, v22, v18
	fsub.4s	v21, v18, v17
	fadd.4s	v17, v18, v17
	fdiv.4s	v17, v21, v17
	bsl.16b	v16, v17, v8
	fcmge.4s	v5, v8, v5
	bsl.16b	v5, v6, v16
	fdiv.4s	v6, v22, v20
	fsub.4s	v16, v20, v6
	fadd.4s	v6, v20, v6
	fdiv.4s	v6, v16, v6
	bif.16b	v6, v8, v7
	fcmge.4s	v4, v8, v4
	bsl.16b	v4, v19, v6
	mvni.4s	v6, #128, lsl #24
	bif.16b	v4, v3, v6
	fcmeq.4s	v3, v3, v3
	fadd.4s	v4, v4, v8
	ldr	q7, [sp, #192]                  ; 16-byte Reload
	bsl.16b	v3, v4, v7
	mov.16b	v4, v6
	bsl.16b	v4, v5, v2
	fcmeq.4s	v2, v2, v2
	fadd.4s	v4, v4, v8
	bsl.16b	v2, v4, v7
	fmul.4s	v1, v1, v28
	fmul.4s	v1, v1, v2
	fmul.4s	v0, v0, v28
	fmul.4s	v0, v0, v3
	add	x10, x28, x8
	ldp	q3, q2, [x10]
	fadd.4s	v0, v3, v0
	fadd.4s	v1, v2, v1
	add	x10, x9, x8
	stp	q0, q1, [x10]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_9
; %bb.10:                               ; %llm_rows.full_packet.exit34.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	orr	w19, w25, #0x3
	mov	w25, #3072                      ; =0xc00
	umaddl	x1, w19, w25, x21
	add	x0, sp, #3600
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	umaddl	x1, w19, w25, x24
	add	x0, sp, #528
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldp	q16, q29, [sp, #160]            ; 32-byte Folded Reload
	ldp	q22, q20, [sp, #128]            ; 32-byte Folded Reload
	ldp	q23, q28, [sp, #256]            ; 32-byte Folded Reload
	ldr	q9, [sp, #288]                  ; 16-byte Reload
	fmov.4s	v8, #1.00000000
	mov	x8, #0                          ; =0x0
	umaddl	x9, w19, w25, x23
	ldp	q25, q15, [sp, #368]            ; 32-byte Folded Reload
	ldp	q12, q31, [sp, #336]            ; 32-byte Folded Reload
	ldr	q0, [sp, #320]                  ; 16-byte Reload
	ldr	q10, [sp, #240]                 ; 16-byte Reload
	ldr	w1, [sp, #68]                   ; 4-byte Reload
LBB0_11:                                ; %direct.true44.i42.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x27, x8
	ldp	q30, q1, [x10]
	fmul.4s	v2, v30, v16
	fmul.4s	v3, v1, v16
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v30, v2
	fmul.4s	v2, v30, v2
	fmul.4s	v3, v1, v3
	fadd.4s	v4, v1, v3
	fadd.4s	v2, v30, v2
	fmul.4s	v3, v2, v9
	fmul.4s	v2, v4, v9
	fabs.4s	v5, v2
	fabs.4s	v4, v3
	fmul.4s	v19, v3, v3
	fmul.4s	v21, v2, v2
	mov.16b	v6, v23
	fmla.4s	v6, v19, v28
	fmla.4s	v23, v21, v28
	ldr	q17, [sp, #304]                 ; 16-byte Reload
	mov.16b	v16, v17
	fmla.4s	v16, v19, v6
	mov.16b	v6, v17
	fmla.4s	v6, v21, v23
	mov.16b	v7, v20
	fmla.4s	v7, v19, v16
	mov.16b	v16, v20
	fmla.4s	v16, v21, v6
	mov.16b	v17, v22
	mov.16b	v18, v22
	mov.16b	v13, v22
	mov.16b	v22, v29
	mov.16b	v23, v29
	fmov.4s	v6, #1.00000000
	fmla.4s	v17, v19, v7
	mov.16b	v7, v15
	ldr	q24, [sp, #496]                 ; 16-byte Reload
	fmla.4s	v7, v21, v24
	mov.16b	v14, v20
	mov.16b	v20, v15
	fmla.4s	v20, v19, v24
	mov.16b	v24, v25
	fmla.4s	v18, v21, v16
	fmla.4s	v24, v21, v7
	mov.16b	v7, v25
	fmla.4s	v7, v19, v20
	mov.16b	v16, v31
	fmla.4s	v16, v21, v24
	fmla.4s	v22, v19, v17
	mov.16b	v17, v31
	fmla.4s	v17, v19, v7
	mov.16b	v20, v12
	fmla.4s	v20, v21, v16
	mov.16b	v24, v12
	fmla.4s	v23, v21, v18
	fmla.4s	v24, v19, v17
	mov.16b	v9, v31
	mov.16b	v31, v25
	movi.4s	v25, #63, lsl #24
	movi.4s	v26, #63, lsl #24
	fmov.4s	v17, #1.00000000
	fmov.4s	v16, #9.00000000
	fcmge.4s	v7, v16, v4
	fmla.4s	v25, v21, v20
	fcmge.4s	v16, v16, v5
	and.16b	v18, v16, v5
	and.16b	v20, v7, v4
	fcmge.4s	v27, v20, v0
	fcmge.4s	v28, v18, v0
	fcmge.4s	v29, v10, v18
	and.16b	v28, v28, v29
	fcmge.4s	v29, v10, v20
	and.16b	v27, v27, v29
	and.16b	v27, v27, v20
	and.16b	v28, v28, v18
	fmla.4s	v6, v21, v23
	ldr	q29, [sp, #480]                 ; 16-byte Reload
	fmul.4s	v23, v28, v29
	fmul.4s	v29, v27, v29
	movi.4s	v11, #75, lsl #24
	fadd.4s	v29, v29, v11
	fadd.4s	v23, v23, v11
	movi.4s	v11, #203, lsl #24
	fadd.4s	v23, v23, v11
	fmla.4s	v17, v21, v25
	fadd.4s	v21, v29, v11
	fcvtzs.4s	v21, v21
	fcvtzs.4s	v23, v23
	scvtf.4s	v25, v23
	scvtf.4s	v29, v21
	fmla.4s	v26, v19, v24
	mov.16b	v11, v0
	mov.16b	v0, v12
	mov.16b	v12, v15
	ldr	q15, [sp, #464]                 ; 16-byte Reload
	fmul.4s	v24, v25, v15
	fadd.4s	v24, v28, v24
	fmul.4s	v28, v29, v15
	fadd.4s	v27, v27, v28
	fmov.4s	v28, #1.00000000
	fmla.4s	v28, v19, v22
	ldr	q15, [sp, #448]                 ; 16-byte Reload
	fmul.4s	v22, v29, v15
	ldr	q29, [sp, #176]                 ; 16-byte Reload
	fadd.4s	v22, v27, v22
	fmul.4s	v25, v25, v15
	mov.16b	v15, v12
	mov.16b	v12, v0
	fadd.4s	v24, v24, v25
	fmov.4s	v25, #1.00000000
	fmla.4s	v25, v19, v26
	ldp	q27, q26, [sp, #416]            ; 32-byte Folded Reload
	fmul.4s	v19, v24, v26
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v27
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v24, v19
	fmul.4s	v27, v4, v28
	fmul.4s	v26, v22, v26
	ldr	q28, [sp, #400]                 ; 16-byte Reload
	fadd.4s	v26, v26, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v24, v19
	fmul.4s	v26, v22, v26
	ldr	q28, [sp, #224]                 ; 16-byte Reload
	fadd.4s	v26, v26, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v24, v19
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v29
	fadd.4s	v28, v19, v29
	fdiv.4s	v19, v27, v25
	fmul.4s	v25, v24, v28
	fmul.4s	v26, v22, v26
	movi.4s	v0, #63, lsl #24
	fadd.4s	v26, v26, v0
	fadd.4s	v25, v25, v0
	fmul.4s	v27, v24, v24
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v22, v22
	fmul.4s	v26, v27, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v24, v24, v25
	movi.2d	v27, #0xffffffffffffffff
	add.4s	v21, v21, v27
	fadd.4s	v22, v22, v8
	sshr.4s	v25, v21, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v8
	fmul.4s	v22, v22, v26
	add.4s	v23, v23, v27
	fadd.4s	v24, v24, v8
	sub.4s	v21, v21, v25
	sshr.4s	v25, v23, #1
	sub.4s	v23, v23, v25
	shl.4s	v25, v25, #23
	add.4s	v25, v25, v8
	fmul.4s	v24, v24, v25
	mov.16b	v25, v31
	mov.16b	v31, v9
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v8
	fmul.4s	v23, v24, v23
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v8
	fmul.4s	v21, v22, v21
	mov.16b	v22, v13
	fcmgt.4s	v20, v20, v10
	ldr	q24, [sp, #208]                 ; 16-byte Reload
	bsl.16b	v20, v24, v21
	fmul.4s	v6, v5, v6
	fcmgt.4s	v18, v18, v10
	bsl.16b	v18, v24, v23
	fdiv.4s	v6, v6, v17
	fmov.4s	v23, #0.25000000
	fdiv.4s	v17, v23, v18
	fsub.4s	v21, v18, v17
	fadd.4s	v17, v18, v17
	fdiv.4s	v17, v21, v17
	bsl.16b	v16, v17, v8
	fcmge.4s	v5, v8, v5
	bsl.16b	v5, v6, v16
	fdiv.4s	v6, v23, v20
	fsub.4s	v16, v20, v6
	fadd.4s	v6, v20, v6
	mov.16b	v20, v14
	fdiv.4s	v6, v16, v6
	ldr	q16, [sp, #160]                 ; 16-byte Reload
	ldp	q28, q9, [sp, #272]             ; 32-byte Folded Reload
	ldr	q23, [sp, #256]                 ; 16-byte Reload
	bif.16b	v6, v8, v7
	fcmge.4s	v4, v8, v4
	bsl.16b	v4, v19, v6
	mvni.4s	v6, #128, lsl #24
	bif.16b	v4, v3, v6
	fcmeq.4s	v3, v3, v3
	fadd.4s	v4, v4, v8
	ldr	q7, [sp, #192]                  ; 16-byte Reload
	bsl.16b	v3, v4, v7
	mov.16b	v4, v6
	bsl.16b	v4, v5, v2
	fcmeq.4s	v2, v2, v2
	fadd.4s	v4, v4, v8
	bsl.16b	v2, v4, v7
	fmul.4s	v1, v1, v0
	fmul.4s	v1, v1, v2
	fmul.4s	v0, v30, v0
	fmul.4s	v0, v0, v3
	add	x10, x28, x8
	ldp	q3, q2, [x10]
	fadd.4s	v0, v3, v0
	fadd.4s	v1, v2, v1
	add	x10, x9, x8
	stp	q0, q1, [x10]
	mov.16b	v0, v11
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_11
; %bb.12:                               ; %llm_rows.full_packet.exit50.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	x2, [sp, #72]                   ; 8-byte Reload
	ldp	w4, w3, [sp, #48]               ; 8-byte Folded Reload
	b	LBB0_2
LBB0_13:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	stp	w20, w22, [sp, #24]             ; 8-byte Folded Spill
	movi.2d	v24, #0xffffffffffffffff
	str	x8, [sp, #80]                   ; 8-byte Spill
	lsr	x8, x8, #3
	str	x8, [sp, #120]                  ; 8-byte Spill
	cbz	x8, LBB0_18
; %bb.14:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w24, #0                         ; =0x0
	ldr	x8, [sp, #56]                   ; 8-byte Reload
	ldr	x9, [x8]
	str	x9, [sp, #96]                   ; 8-byte Spill
	ldr	x19, [x8, #16]
	ldr	x20, [x8, #48]
	ldr	x8, [sp, #72]                   ; 8-byte Reload
	lsl	w22, w8, #2
	mov	x26, x22
LBB0_15:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_16 Depth 3
	and	x8, x26, #0x1fffffff
	mov	w25, #3072                      ; =0xc00
	umaddl	x23, w8, w25, x20
	add	w8, w24, w22
	and	w21, w8, #0x1fffffff
	ldr	x8, [sp, #96]                   ; 8-byte Reload
	umaddl	x1, w21, w25, x8
	add	x0, sp, #3600
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	umaddl	x1, w21, w25, x19
	add	x0, sp, #528
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldp	q16, q29, [sp, #160]            ; 32-byte Folded Reload
	ldp	q22, q20, [sp, #128]            ; 32-byte Folded Reload
	fmov.4s	v8, #1.00000000
	mov	x8, #0                          ; =0x0
	ldp	q12, q13, [sp, #224]            ; 32-byte Folded Reload
	ldp	q14, q30, [sp, #192]            ; 32-byte Folded Reload
LBB0_16:                                ; %direct.true44.i58.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_15 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x27, x8
	ldp	q0, q1, [x9]
	fmul.4s	v2, v0, v16
	fmul.4s	v3, v1, v16
	fmul.4s	v3, v1, v3
	fmul.4s	v2, v0, v2
	fmul.4s	v2, v0, v2
	fmul.4s	v3, v1, v3
	fadd.4s	v4, v1, v3
	fadd.4s	v2, v0, v2
	ldp	q17, q5, [sp, #272]             ; 32-byte Folded Reload
	fmul.4s	v3, v2, v5
	fmul.4s	v2, v4, v5
	fabs.4s	v5, v2
	fabs.4s	v4, v3
	fmul.4s	v19, v3, v3
	fmul.4s	v21, v2, v2
	ldr	q7, [sp, #256]                  ; 16-byte Reload
	mov.16b	v6, v7
	fmla.4s	v6, v19, v17
	fmla.4s	v7, v21, v17
	mov.16b	v15, v16
	ldr	q17, [sp, #304]                 ; 16-byte Reload
	mov.16b	v16, v17
	fmla.4s	v16, v19, v6
	mov.16b	v6, v17
	fmla.4s	v6, v21, v7
	mov.16b	v7, v20
	fmla.4s	v7, v19, v16
	mov.16b	v16, v20
	fmla.4s	v16, v21, v6
	mov.16b	v17, v22
	mov.16b	v18, v22
	mov.16b	v9, v22
	mov.16b	v22, v29
	mov.16b	v23, v29
	fmov.4s	v6, #1.00000000
	fmla.4s	v17, v19, v7
	ldr	q25, [sp, #384]                 ; 16-byte Reload
	mov.16b	v7, v25
	ldr	q24, [sp, #496]                 ; 16-byte Reload
	fmla.4s	v7, v21, v24
	mov.16b	v31, v20
	mov.16b	v20, v25
	fmla.4s	v20, v19, v24
	ldr	q25, [sp, #368]                 ; 16-byte Reload
	mov.16b	v24, v25
	fmla.4s	v18, v21, v16
	fmla.4s	v24, v21, v7
	mov.16b	v7, v25
	fmla.4s	v7, v19, v20
	ldr	q20, [sp, #352]                 ; 16-byte Reload
	mov.16b	v16, v20
	fmla.4s	v16, v21, v24
	fmla.4s	v22, v19, v17
	mov.16b	v17, v20
	fmla.4s	v17, v19, v7
	ldp	q28, q24, [sp, #320]            ; 32-byte Folded Reload
	mov.16b	v20, v24
	fmla.4s	v20, v21, v16
	fmla.4s	v23, v21, v18
	fmla.4s	v24, v19, v17
	movi.4s	v25, #63, lsl #24
	movi.4s	v26, #63, lsl #24
	fmov.4s	v17, #1.00000000
	fmov.4s	v16, #9.00000000
	fcmge.4s	v7, v16, v4
	fmla.4s	v25, v21, v20
	fcmge.4s	v16, v16, v5
	and.16b	v18, v16, v5
	and.16b	v20, v7, v4
	fcmge.4s	v27, v20, v28
	fcmge.4s	v28, v18, v28
	mov.16b	v10, v29
	fcmge.4s	v29, v13, v18
	and.16b	v28, v28, v29
	fcmge.4s	v29, v13, v20
	and.16b	v27, v27, v29
	and.16b	v27, v27, v20
	and.16b	v28, v28, v18
	fmla.4s	v6, v21, v23
	ldr	q29, [sp, #480]                 ; 16-byte Reload
	fmul.4s	v23, v28, v29
	fmul.4s	v29, v27, v29
	movi.4s	v11, #75, lsl #24
	fadd.4s	v29, v29, v11
	fadd.4s	v23, v23, v11
	movi.4s	v11, #203, lsl #24
	fadd.4s	v23, v23, v11
	fmla.4s	v17, v21, v25
	fadd.4s	v21, v29, v11
	fcvtzs.4s	v21, v21
	fcvtzs.4s	v23, v23
	scvtf.4s	v25, v23
	scvtf.4s	v29, v21
	fmla.4s	v26, v19, v24
	ldr	q11, [sp, #464]                 ; 16-byte Reload
	fmul.4s	v24, v25, v11
	fadd.4s	v24, v28, v24
	fmul.4s	v28, v29, v11
	fadd.4s	v27, v27, v28
	fmov.4s	v28, #1.00000000
	fmla.4s	v28, v19, v22
	ldr	q11, [sp, #448]                 ; 16-byte Reload
	fmul.4s	v22, v29, v11
	mov.16b	v29, v10
	fadd.4s	v22, v27, v22
	fmul.4s	v25, v25, v11
	fadd.4s	v24, v24, v25
	fmov.4s	v25, #1.00000000
	fmla.4s	v25, v19, v26
	ldp	q27, q26, [sp, #416]            ; 32-byte Folded Reload
	fmul.4s	v19, v24, v26
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v27
	fadd.4s	v19, v19, v27
	fmul.4s	v19, v24, v19
	fmul.4s	v27, v4, v28
	fmul.4s	v26, v22, v26
	ldr	q28, [sp, #400]                 ; 16-byte Reload
	fadd.4s	v26, v26, v28
	fadd.4s	v19, v19, v28
	fmul.4s	v19, v24, v19
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v12
	fadd.4s	v19, v19, v12
	fmul.4s	v19, v24, v19
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v10
	fadd.4s	v28, v19, v10
	fdiv.4s	v19, v27, v25
	fmul.4s	v25, v24, v28
	movi.4s	v28, #63, lsl #24
	fmul.4s	v26, v22, v26
	fadd.4s	v26, v26, v28
	fadd.4s	v25, v25, v28
	fmul.4s	v27, v24, v24
	fmul.4s	v25, v27, v25
	fmul.4s	v27, v22, v22
	fmul.4s	v26, v27, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v24, v24, v25
	movi.2d	v27, #0xffffffffffffffff
	add.4s	v21, v21, v27
	fadd.4s	v22, v22, v8
	sshr.4s	v25, v21, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v8
	fmul.4s	v22, v22, v26
	add.4s	v23, v23, v27
	fadd.4s	v24, v24, v8
	sub.4s	v21, v21, v25
	sshr.4s	v25, v23, #1
	sub.4s	v23, v23, v25
	shl.4s	v25, v25, #23
	add.4s	v25, v25, v8
	fmul.4s	v24, v24, v25
	shl.4s	v23, v23, #23
	add.4s	v23, v23, v8
	fmul.4s	v23, v24, v23
	shl.4s	v21, v21, #23
	add.4s	v21, v21, v8
	fmul.4s	v21, v22, v21
	mov.16b	v22, v9
	fcmgt.4s	v20, v20, v13
	bsl.16b	v20, v30, v21
	fmul.4s	v6, v5, v6
	fcmgt.4s	v18, v18, v13
	bsl.16b	v18, v30, v23
	fdiv.4s	v6, v6, v17
	fmov.4s	v23, #0.25000000
	fdiv.4s	v17, v23, v18
	fsub.4s	v21, v18, v17
	fadd.4s	v17, v18, v17
	fdiv.4s	v17, v21, v17
	bsl.16b	v16, v17, v8
	fcmge.4s	v5, v8, v5
	bsl.16b	v5, v6, v16
	fdiv.4s	v6, v23, v20
	fsub.4s	v16, v20, v6
	fadd.4s	v6, v20, v6
	mov.16b	v20, v31
	fdiv.4s	v6, v16, v6
	mov.16b	v16, v15
	bif.16b	v6, v8, v7
	fcmge.4s	v4, v8, v4
	bsl.16b	v4, v19, v6
	mvni.4s	v6, #128, lsl #24
	bif.16b	v4, v3, v6
	fcmeq.4s	v3, v3, v3
	fadd.4s	v4, v4, v8
	bsl.16b	v3, v4, v14
	mov.16b	v4, v6
	bsl.16b	v4, v5, v2
	fcmeq.4s	v2, v2, v2
	fadd.4s	v4, v4, v8
	bsl.16b	v2, v4, v14
	fmul.4s	v1, v1, v28
	fmul.4s	v1, v1, v2
	fmul.4s	v0, v0, v28
	fmul.4s	v0, v0, v3
	add	x9, x28, x8
	ldp	q3, q2, [x9]
	fadd.4s	v0, v3, v0
	fadd.4s	v1, v2, v1
	add	x9, x23, x8
	stp	q0, q1, [x9]
	add	x8, x8, #32
	cmp	x8, #3072
	b.ne	LBB0_16
; %bb.17:                               ; %llm_rows.full_packet.exit66.i
                                        ;   in Loop: Header=BB0_15 Depth=2
	ldp	q23, q28, [sp, #256]            ; 32-byte Folded Reload
	ldr	q9, [sp, #288]                  ; 16-byte Reload
	movi.2d	v24, #0xffffffffffffffff
	add	w24, w24, #1
	add	w26, w26, #1
	ldr	x8, [sp, #120]                  ; 8-byte Reload
	cmp	w24, w8
	b.ne	LBB0_15
LBB0_18:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	x2, x8, [sp, #72]               ; 16-byte Folded Reload
	and	w8, w8, #0x7
	ldp	w4, w3, [sp, #48]               ; 8-byte Folded Reload
	ldp	w20, w22, [sp, #24]             ; 8-byte Folded Reload
	ldp	q25, q15, [sp, #368]            ; 32-byte Folded Reload
	ldp	q12, q31, [sp, #336]            ; 32-byte Folded Reload
	ldr	q0, [sp, #320]                  ; 16-byte Reload
	ldr	q10, [sp, #240]                 ; 16-byte Reload
	ldp	q30, q29, [sp, #432]            ; 32-byte Folded Reload
	ldp	q13, q26, [sp, #400]            ; 32-byte Folded Reload
	adrp	x17, lCPI0_2@PAGE
	ldr	w1, [sp, #68]                   ; 4-byte Reload
	cbz	w8, LBB0_2
; %bb.19:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v3, w8
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v2, v3, v2
	stp	q3, q1, [sp, #80]               ; 32-byte Folded Spill
	cmhi.4s	v3, v3, v1
	uzp1.8h	v5, v3, v2
	umaxv.8h	h4, v5
	fmov	w8, s4
	tbz	w8, #0, LBB0_2
; %bb.20:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.16b	v27, v0
	mov.16b	v11, v12
	mov.16b	v14, v31
	mov.16b	v0, v25
	mov	x11, #0                         ; =0x0
	ldr	x10, [sp, #56]                  ; 8-byte Reload
	ldr	x9, [x10, #16]
	ldr	x8, [x10, #48]
	ldr	x12, [x10]
	ubfiz	w10, w2, #2, #27
	ldr	x13, [sp, #120]                 ; 8-byte Reload
	orr	w10, w10, w13
	fmov	s4, w10
	and.16b	v3, v3, v4
	fmov	w13, s3
	mov	w14, #3072                      ; =0xc00
	umull	x10, w13, w14
	umaddl	x12, w13, w14, x12
	b	LBB0_22
LBB0_21:                                ; %else58
                                        ;   in Loop: Header=BB0_22 Depth=2
	add	x13, x27, x11
	stp	q6, q7, [x13]
	add	x11, x11, #32
	cmp	x11, #3072
	b.eq	LBB0_38
LBB0_22:                                ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x17, lCPI0_2@PAGEOFF]
	and.16b	v4, v5, v3
	addv.8h	h4, v4
	fmov	w14, s4
	add	x13, x12, x11
	add	x15, x27, x11
	ldr	q6, [x15]
	tbnz	w14, #0, LBB0_30
; %bb.23:                               ; %else
                                        ;   in Loop: Header=BB0_22 Depth=2
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_31
LBB0_24:                                ; %else40
                                        ;   in Loop: Header=BB0_22 Depth=2
	tbnz	w14, #2, LBB0_32
LBB0_25:                                ; %else43
                                        ;   in Loop: Header=BB0_22 Depth=2
	tbnz	w14, #3, LBB0_33
LBB0_26:                                ; %else46
                                        ;   in Loop: Header=BB0_22 Depth=2
	ldr	q7, [x15, #16]
	tbnz	w14, #4, LBB0_34
LBB0_27:                                ; %else49
                                        ;   in Loop: Header=BB0_22 Depth=2
	tbnz	w14, #5, LBB0_35
LBB0_28:                                ; %else52
                                        ;   in Loop: Header=BB0_22 Depth=2
	tbnz	w14, #6, LBB0_36
LBB0_29:                                ; %else55
                                        ;   in Loop: Header=BB0_22 Depth=2
	tbz	w14, #7, LBB0_21
	b	LBB0_37
LBB0_30:                                ; %cond.load
                                        ;   in Loop: Header=BB0_22 Depth=2
	ld1.s	{ v6 }[0], [x13]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_24
LBB0_31:                                ; %cond.load39
                                        ;   in Loop: Header=BB0_22 Depth=2
	add	x16, x13, #4
	ld1.s	{ v6 }[1], [x16]
	tbz	w14, #2, LBB0_25
LBB0_32:                                ; %cond.load42
                                        ;   in Loop: Header=BB0_22 Depth=2
	add	x16, x13, #8
	ld1.s	{ v6 }[2], [x16]
	tbz	w14, #3, LBB0_26
LBB0_33:                                ; %cond.load45
                                        ;   in Loop: Header=BB0_22 Depth=2
	add	x16, x13, #12
	ld1.s	{ v6 }[3], [x16]
	ldr	q7, [x15, #16]
	tbz	w14, #4, LBB0_27
LBB0_34:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_22 Depth=2
	add	x15, x13, #16
	ld1.s	{ v7 }[0], [x15]
	tbz	w14, #5, LBB0_28
LBB0_35:                                ; %cond.load51
                                        ;   in Loop: Header=BB0_22 Depth=2
	add	x15, x13, #20
	ld1.s	{ v7 }[1], [x15]
	tbz	w14, #6, LBB0_29
LBB0_36:                                ; %cond.load54
                                        ;   in Loop: Header=BB0_22 Depth=2
	add	x15, x13, #24
	ld1.s	{ v7 }[2], [x15]
	tbz	w14, #7, LBB0_21
LBB0_37:                                ; %cond.load57
                                        ;   in Loop: Header=BB0_22 Depth=2
	add	x13, x13, #28
	ld1.s	{ v7 }[3], [x13]
	b	LBB0_21
LBB0_38:                                ; %direct.schedule.4.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x11, #0                         ; =0x0
	add	x9, x9, x10
	b	LBB0_40
LBB0_39:                                ; %else83
                                        ;   in Loop: Header=BB0_40 Depth=2
	add	x12, x28, x11
	stp	q5, q6, [x12]
	add	x11, x11, #32
	cmp	x11, #3072
	b.eq	LBB0_56
LBB0_40:                                ; %direct.true27.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s4
	add	x12, x9, x11
	add	x14, x28, x11
	ldr	q5, [x14]
	tbnz	w13, #0, LBB0_48
; %bb.41:                               ; %else62
                                        ;   in Loop: Header=BB0_40 Depth=2
	and	w13, w13, #0xff
	ldr	q6, [x14, #16]
	tbnz	w13, #1, LBB0_49
LBB0_42:                                ; %else65
                                        ;   in Loop: Header=BB0_40 Depth=2
	tbnz	w13, #2, LBB0_50
LBB0_43:                                ; %else68
                                        ;   in Loop: Header=BB0_40 Depth=2
	tbnz	w13, #3, LBB0_51
LBB0_44:                                ; %else71
                                        ;   in Loop: Header=BB0_40 Depth=2
	tbnz	w13, #4, LBB0_52
LBB0_45:                                ; %else74
                                        ;   in Loop: Header=BB0_40 Depth=2
	tbnz	w13, #5, LBB0_53
LBB0_46:                                ; %else77
                                        ;   in Loop: Header=BB0_40 Depth=2
	tbnz	w13, #6, LBB0_54
LBB0_47:                                ; %else80
                                        ;   in Loop: Header=BB0_40 Depth=2
	tbz	w13, #7, LBB0_39
	b	LBB0_55
LBB0_48:                                ; %cond.load61
                                        ;   in Loop: Header=BB0_40 Depth=2
	ld1.s	{ v5 }[0], [x12]
	and	w13, w13, #0xff
	ldr	q6, [x14, #16]
	tbz	w13, #1, LBB0_42
LBB0_49:                                ; %cond.load64
                                        ;   in Loop: Header=BB0_40 Depth=2
	add	x14, x12, #4
	ld1.s	{ v5 }[1], [x14]
	tbz	w13, #2, LBB0_43
LBB0_50:                                ; %cond.load67
                                        ;   in Loop: Header=BB0_40 Depth=2
	add	x14, x12, #8
	ld1.s	{ v5 }[2], [x14]
	tbz	w13, #3, LBB0_44
LBB0_51:                                ; %cond.load70
                                        ;   in Loop: Header=BB0_40 Depth=2
	add	x14, x12, #12
	ld1.s	{ v5 }[3], [x14]
	tbz	w13, #4, LBB0_45
LBB0_52:                                ; %cond.load73
                                        ;   in Loop: Header=BB0_40 Depth=2
	add	x14, x12, #16
	ld1.s	{ v6 }[0], [x14]
	tbz	w13, #5, LBB0_46
LBB0_53:                                ; %cond.load76
                                        ;   in Loop: Header=BB0_40 Depth=2
	add	x14, x12, #20
	ld1.s	{ v6 }[1], [x14]
	tbz	w13, #6, LBB0_47
LBB0_54:                                ; %cond.load79
                                        ;   in Loop: Header=BB0_40 Depth=2
	add	x14, x12, #24
	ld1.s	{ v6 }[2], [x14]
	tbz	w13, #7, LBB0_39
LBB0_55:                                ; %cond.load82
                                        ;   in Loop: Header=BB0_40 Depth=2
	add	x12, x12, #28
	ld1.s	{ v6 }[3], [x12]
	b	LBB0_39
LBB0_56:                                ; %direct.schedule.7.preheader.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x9, #0                          ; =0x0
	add	x8, x8, x10
	b	LBB0_58
LBB0_57:                                ; %else100
                                        ;   in Loop: Header=BB0_58 Depth=2
	add	x9, x9, #32
	cmp	x9, #3072
	b.eq	LBB0_2
LBB0_58:                                ; %direct.true44.i72.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q4, q1, [sp, #80]               ; 32-byte Folded Reload
	cmhi.4s	v4, v4, v1
	add	x10, x27, x9
	ldr	q5, [x10]
	and.16b	v5, v4, v5
	mov.16b	v25, v16
	fmul.4s	v6, v5, v16
	fmul.4s	v6, v5, v6
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v5, v6
	fmul.4s	v6, v6, v9
	and.16b	v6, v4, v6
	fabs.4s	v7, v6
	fmul.4s	v16, v6, v6
	mov.16b	v17, v23
	fmla.4s	v17, v16, v28
	ldr	q18, [sp, #304]                 ; 16-byte Reload
	fmla.4s	v18, v16, v17
	mov.16b	v12, v20
	mov.16b	v17, v20
	fmla.4s	v17, v16, v18
	mov.16b	v1, v22
	mov.16b	v18, v22
	fmla.4s	v18, v16, v17
	ldr	q31, [sp, #176]                 ; 16-byte Reload
	mov.16b	v17, v31
	fmla.4s	v17, v16, v18
	fmov.4s	v18, #1.00000000
	fmla.4s	v18, v16, v17
	fmul.4s	v17, v7, v18
	mov.16b	v18, v15
	ldr	q19, [sp, #496]                 ; 16-byte Reload
	fmla.4s	v18, v16, v19
	mov.16b	v19, v0
	fmla.4s	v19, v16, v18
	mov.16b	v18, v14
	fmla.4s	v18, v16, v19
	mov.16b	v19, v11
	fmla.4s	v19, v16, v18
	movi.4s	v18, #63, lsl #24
	fmla.4s	v18, v16, v19
	fmov.4s	v19, #1.00000000
	fmla.4s	v19, v16, v18
	fdiv.4s	v16, v17, v19
	fmov.4s	v17, #9.00000000
	fcmge.4s	v17, v17, v7
	and.16b	v18, v17, v7
	fcmge.4s	v19, v18, v27
	fcmge.4s	v20, v10, v18
	and.16b	v19, v19, v20
	and.16b	v19, v19, v18
	ldp	q22, q20, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v20, v19, v20
	movi.4s	v21, #75, lsl #24
	fadd.4s	v20, v20, v21
	movi.4s	v21, #203, lsl #24
	fadd.4s	v20, v20, v21
	fcvtzs.4s	v20, v20
	scvtf.4s	v21, v20
	fmul.4s	v22, v21, v22
	fadd.4s	v19, v19, v22
	fmul.4s	v21, v21, v29
	fadd.4s	v19, v19, v21
	fmul.4s	v21, v19, v30
	fadd.4s	v21, v21, v26
	fmul.4s	v21, v19, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v19, v21
	ldr	q22, [sp, #224]                 ; 16-byte Reload
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v19, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v21, v19, v21
	movi.4s	v31, #63, lsl #24
	fadd.4s	v21, v21, v31
	fmul.4s	v22, v19, v19
	fmul.4s	v21, v22, v21
	fadd.4s	v19, v19, v21
	fadd.4s	v19, v19, v8
	add.4s	v20, v20, v24
	sshr.4s	v21, v20, #1
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v8
	fmul.4s	v19, v19, v22
	sub.4s	v20, v20, v21
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v8
	fmul.4s	v19, v19, v20
	fcmgt.4s	v18, v18, v10
	ldr	q20, [sp, #208]                 ; 16-byte Reload
	bsl.16b	v18, v20, v19
	fmov.4s	v19, #0.25000000
	fdiv.4s	v19, v19, v18
	fsub.4s	v20, v18, v19
	fadd.4s	v18, v18, v19
	fdiv.4s	v18, v20, v18
	bsl.16b	v17, v18, v8
	fcmge.4s	v7, v8, v7
	bsl.16b	v7, v16, v17
	uzp1.8h	v16, v4, v2
	and.16b	v16, v16, v3
	addv.8h	h16, v16
	fmov	w11, s16
	mvni.4s	v16, #128, lsl #24
	bif.16b	v7, v6, v16
	fcmeq.4s	v6, v6, v6
	fadd.4s	v7, v7, v8
	ldr	q16, [sp, #192]                 ; 16-byte Reload
	bsl.16b	v6, v7, v16
	fmul.4s	v5, v5, v31
	fmul.4s	v6, v5, v6
	add	x12, x28, x9
	ldr	q5, [x12]
	and.16b	v4, v4, v5
	ldr	q5, [x10, #16]
	fadd.4s	v6, v4, v6
	ldr	q4, [x12, #16]
	add	x10, x8, x9
	tbnz	w11, #0, LBB0_67
; %bb.59:                               ; %else86
                                        ;   in Loop: Header=BB0_58 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_68
LBB0_60:                                ; %else88
                                        ;   in Loop: Header=BB0_58 Depth=2
	mov.16b	v7, v25
	mov.16b	v19, v12
	mov.16b	v20, v1
	tbnz	w11, #2, LBB0_69
LBB0_61:                                ; %else90
                                        ;   in Loop: Header=BB0_58 Depth=2
	tbz	w11, #3, LBB0_63
LBB0_62:                                ; %cond.store91
                                        ;   in Loop: Header=BB0_58 Depth=2
	add	x12, x10, #12
	st1.s	{ v6 }[3], [x12]
LBB0_63:                                ; %else92
                                        ;   in Loop: Header=BB0_58 Depth=2
	and.16b	v5, v2, v5
	fmul.4s	v6, v5, v7
	fmul.4s	v6, v5, v6
	fmul.4s	v6, v5, v6
	fadd.4s	v6, v5, v6
	fmul.4s	v6, v6, v9
	and.16b	v6, v2, v6
	fabs.4s	v7, v6
	fmul.4s	v16, v6, v6
	mov.16b	v17, v23
	fmla.4s	v17, v16, v28
	ldr	q18, [sp, #304]                 ; 16-byte Reload
	fmla.4s	v18, v16, v17
	mov.16b	v17, v19
	fmla.4s	v17, v16, v18
	mov.16b	v18, v20
	fmla.4s	v18, v16, v17
	ldr	q31, [sp, #176]                 ; 16-byte Reload
	mov.16b	v17, v31
	fmla.4s	v17, v16, v18
	fmov.4s	v18, #1.00000000
	fmla.4s	v18, v16, v17
	fmul.4s	v17, v7, v18
	mov.16b	v18, v15
	ldr	q19, [sp, #496]                 ; 16-byte Reload
	fmla.4s	v18, v16, v19
	mov.16b	v19, v0
	fmla.4s	v19, v16, v18
	mov.16b	v18, v14
	fmla.4s	v18, v16, v19
	mov.16b	v19, v11
	fmla.4s	v19, v16, v18
	movi.4s	v18, #63, lsl #24
	fmla.4s	v18, v16, v19
	fmov.4s	v19, #1.00000000
	fmla.4s	v19, v16, v18
	fdiv.4s	v16, v17, v19
	fmov.4s	v17, #9.00000000
	fcmge.4s	v17, v17, v7
	and.16b	v18, v17, v7
	fcmge.4s	v19, v18, v27
	fcmge.4s	v20, v10, v18
	and.16b	v19, v19, v20
	and.16b	v19, v19, v18
	ldp	q22, q20, [sp, #464]            ; 32-byte Folded Reload
	fmul.4s	v20, v19, v20
	movi.4s	v21, #75, lsl #24
	fadd.4s	v20, v20, v21
	movi.4s	v21, #203, lsl #24
	fadd.4s	v20, v20, v21
	fcvtzs.4s	v20, v20
	scvtf.4s	v21, v20
	fmul.4s	v22, v21, v22
	fadd.4s	v19, v19, v22
	fmul.4s	v21, v21, v29
	fadd.4s	v19, v19, v21
	fmul.4s	v21, v19, v30
	fadd.4s	v21, v21, v26
	fmul.4s	v21, v19, v21
	fadd.4s	v21, v21, v13
	fmul.4s	v21, v19, v21
	ldr	q22, [sp, #224]                 ; 16-byte Reload
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v19, v21
	fadd.4s	v21, v21, v31
	fmul.4s	v21, v19, v21
	movi.4s	v31, #63, lsl #24
	fadd.4s	v21, v21, v31
	fmul.4s	v22, v19, v19
	fmul.4s	v21, v22, v21
	fadd.4s	v19, v19, v21
	fadd.4s	v19, v19, v8
	add.4s	v20, v20, v24
	sshr.4s	v21, v20, #1
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v8
	fmul.4s	v19, v19, v22
	sub.4s	v20, v20, v21
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v8
	fmul.4s	v19, v19, v20
	fcmgt.4s	v18, v18, v10
	ldr	q20, [sp, #208]                 ; 16-byte Reload
	bsl.16b	v18, v20, v19
	fmov.4s	v19, #0.25000000
	fdiv.4s	v19, v19, v18
	fsub.4s	v20, v18, v19
	fadd.4s	v18, v18, v19
	fdiv.4s	v18, v20, v18
	bsl.16b	v17, v18, v8
	fcmge.4s	v7, v8, v7
	bsl.16b	v7, v16, v17
	mvni.4s	v16, #128, lsl #24
	bif.16b	v7, v6, v16
	fcmeq.4s	v6, v6, v6
	fadd.4s	v7, v7, v8
	ldr	q16, [sp, #192]                 ; 16-byte Reload
	bsl.16b	v6, v7, v16
	fmul.4s	v5, v5, v31
	fmul.4s	v5, v5, v6
	and.16b	v4, v2, v4
	fadd.4s	v4, v4, v5
	tbnz	w11, #4, LBB0_70
; %bb.64:                               ; %else94
                                        ;   in Loop: Header=BB0_58 Depth=2
	tbnz	w11, #5, LBB0_71
LBB0_65:                                ; %else96
                                        ;   in Loop: Header=BB0_58 Depth=2
	mov.16b	v16, v25
	mov.16b	v20, v12
	mov.16b	v22, v1
	tbnz	w11, #6, LBB0_72
LBB0_66:                                ; %else98
                                        ;   in Loop: Header=BB0_58 Depth=2
	tbz	w11, #7, LBB0_57
	b	LBB0_73
LBB0_67:                                ; %cond.store
                                        ;   in Loop: Header=BB0_58 Depth=2
	str	s6, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_60
LBB0_68:                                ; %cond.store87
                                        ;   in Loop: Header=BB0_58 Depth=2
	add	x12, x10, #4
	st1.s	{ v6 }[1], [x12]
	mov.16b	v7, v25
	mov.16b	v19, v12
	mov.16b	v20, v1
	tbz	w11, #2, LBB0_61
LBB0_69:                                ; %cond.store89
                                        ;   in Loop: Header=BB0_58 Depth=2
	add	x12, x10, #8
	st1.s	{ v6 }[2], [x12]
	tbnz	w11, #3, LBB0_62
	b	LBB0_63
LBB0_70:                                ; %cond.store93
                                        ;   in Loop: Header=BB0_58 Depth=2
	str	s4, [x10, #16]
	tbz	w11, #5, LBB0_65
LBB0_71:                                ; %cond.store95
                                        ;   in Loop: Header=BB0_58 Depth=2
	add	x12, x10, #20
	st1.s	{ v4 }[1], [x12]
	mov.16b	v16, v25
	mov.16b	v20, v12
	mov.16b	v22, v1
	tbz	w11, #6, LBB0_66
LBB0_72:                                ; %cond.store97
                                        ;   in Loop: Header=BB0_58 Depth=2
	add	x12, x10, #24
	st1.s	{ v4 }[2], [x12]
	tbz	w11, #7, LBB0_57
LBB0_73:                                ; %cond.store99
                                        ;   in Loop: Header=BB0_58 Depth=2
	add	x10, x10, #28
	st1.s	{ v4 }[3], [x10]
	b	LBB0_57
LBB0_74:                                ; %block.batch.exit.loopexit
	ldr	x9, [sp, #16]                   ; 8-byte Reload
	stp	w2, w1, [x9]
	str	w20, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
LBB0_75:                                ; %block.batch.exit
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #2576
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

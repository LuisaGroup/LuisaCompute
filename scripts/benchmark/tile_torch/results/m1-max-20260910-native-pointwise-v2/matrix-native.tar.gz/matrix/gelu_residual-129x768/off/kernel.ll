; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3072 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill5 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill5, align 64
  %.slot6 = alloca i64, align 8
  store i64 0, ptr %.slot6, align 4
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert8 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat9 = shufflevector <8 x i32> %.splatinsert8, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat9, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert10 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat11 = shufflevector <8 x i32> %.splatinsert10, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat11, %41
  %44 = mul i32 %32, 1
  %.splatinsert12 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat13 = shufflevector <8 x i32> %.splatinsert12, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat13, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert14 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat15 = shufflevector <8 x i32> %.splatinsert14, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat15, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert16 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat17 = shufflevector <8 x i32> %.splatinsert16, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat17
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 96
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state18 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state18, 8
  %.splatinsert19 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat20 = shufflevector <8 x i64> %.splatinsert19, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat20, %.spill.load
  %.spill.load21 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load21, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 768)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state22 = load i64, ptr %.slot, align 4
  %.splatinsert23 = insertelement <8 x i64> poison, i64 %.state22, i64 0
  %.splat24 = shufflevector <8 x i64> %.splatinsert23, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat24, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state25 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state25, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill5, align 64
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %102, 0
  %105 = select <8 x i1> %51, <8 x ptr> %103, <8 x ptr> %104
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %102, 1
  %108 = select <8 x i1> %51, <8 x i64> %106, <8 x i64> %107
  %109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %105, 0
  %110 = insertvalue { <8 x ptr>, <8 x i64> } %109, <8 x i64> %108, 1
  store { <8 x ptr>, <8 x i64> } %110, ptr %tile_snapshot.spill5, align 64
  store i64 0, ptr %.slot6, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state26 = load i64, ptr %.slot6, align 4
  %111 = icmp slt i64 %.state26, 96
  br i1 %111, label %direct.true27, label %direct.false28

direct.schedule.5:                                ; preds = %direct.true27
  %.state29 = load i64, ptr %.slot6, align 4
  %112 = mul i64 %.state29, 8
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %112, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load32 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> %.splat31, %.spill.load32
  %.spill.load33 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load33, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 768)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %15, 0
  %120 = extractelement <8 x i64> %118, i32 0
  %121 = sub i64 %120, 0
  %122 = mul i64 %121, 4
  %buffer.contiguous.address34 = getelementptr i8, ptr %119, i64 %122
  %buffer.contiguous.load35 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address34, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load36 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill5, align 64
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 0
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 1
  %.state37 = load i64, ptr %.slot6, align 4
  %.splatinsert38 = insertelement <8 x i64> poison, i64 %.state37, i64 0
  %.splat39 = shufflevector <8 x i64> %.splatinsert38, <8 x i64> poison, <8 x i32> zeroinitializer
  %125 = mul <8 x i64> %.splat39, splat (i64 32)
  %126 = add <8 x i64> %124, %125
  %127 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %123, 0
  %128 = insertvalue { <8 x ptr>, <8 x i64> } %127, <8 x i64> %126, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %128, 1
  %131 = extractelement <8 x ptr> %129, i32 0
  %132 = extractelement <8 x i64> %130, i32 0
  %133 = sub i64 %132, 0
  %134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %135 = select i1 %134, i64 %133, i64 0
  %private.contiguous.address40 = getelementptr i8, ptr %131, i64 %135
  %private.contiguous.preserve41 = load <8 x float>, ptr %private.contiguous.address40, align 4
  %136 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load35, <8 x float> %private.contiguous.preserve41
  store <8 x float> %136, ptr %private.contiguous.address40, align 4
  %.state42 = load i64, ptr %.slot6, align 4
  %137 = add i64 %.state42, 1
  store i64 %137, ptr %.slot6, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false28
  store i64 0, ptr %.slot7, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state43 = load i64, ptr %.slot7, align 4
  %138 = icmp slt i64 %.state43, 96
  br i1 %138, label %direct.true44, label %direct.false45

direct.schedule.8:                                ; preds = %direct.true44
  %.state46 = load i64, ptr %.slot7, align 4
  %139 = mul i64 %.state46, 8
  %.splatinsert47 = insertelement <8 x i64> poison, i64 %139, i64 0
  %.splat48 = shufflevector <8 x i64> %.splatinsert47, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load49 = load <8 x i64>, ptr %.spill, align 64
  %140 = add <8 x i64> %.splat48, %.spill.load49
  %.spill.load50 = load <8 x i64>, ptr %.spill4, align 64
  %141 = add <8 x i64> %.spill.load50, zeroinitializer
  %142 = add <8 x i64> zeroinitializer, %141
  %143 = add <8 x i64> zeroinitializer, %140
  %144 = mul <8 x i64> %142, splat (i64 768)
  %145 = add <8 x i64> %144, %143
  %tile_snapshot.spill.load51 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load51, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load51, 1
  %.state52 = load i64, ptr %.slot7, align 4
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %.state52, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %148 = mul <8 x i64> %.splat54, splat (i64 32)
  %149 = add <8 x i64> %147, %148
  %150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %146, 0
  %151 = insertvalue { <8 x ptr>, <8 x i64> } %150, <8 x i64> %149, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %154 = extractelement <8 x ptr> %152, i32 0
  %155 = extractelement <8 x i64> %153, i32 0
  %156 = sub i64 %155, 0
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %158 = select i1 %157, i64 %156, i64 0
  %private.contiguous.address55 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address55, align 4
  %159 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %160 = fmul <8 x float> splat (float 5.000000e-01), %159
  %161 = fmul <8 x float> splat (float 0x3FA6E4E260000000), %159
  %162 = fmul <8 x float> %161, %159
  %163 = fmul <8 x float> %162, %159
  %164 = fadd <8 x float> %159, %163
  %165 = fmul <8 x float> splat (float 0x3FE9884540000000), %164
  %166 = select <8 x i1> %51, <8 x float> %165, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %166)
  %167 = fadd <8 x float> splat (float 1.000000e+00), %native.tanh
  %168 = fmul <8 x float> %160, %167
  %tile_snapshot.spill.load56 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill5, align 64
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 0
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 1
  %.state57 = load i64, ptr %.slot7, align 4
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %.state57, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %171 = mul <8 x i64> %.splat59, splat (i64 32)
  %172 = add <8 x i64> %170, %171
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %169, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %177 = extractelement <8 x ptr> %175, i32 0
  %178 = extractelement <8 x i64> %176, i32 0
  %179 = sub i64 %178, 0
  %180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %181 = select i1 %180, i64 %179, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %177, i64 %181
  %private.contiguous.load61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %182 = select <8 x i1> %51, <8 x float> %private.contiguous.load61, <8 x float> zeroinitializer
  %183 = fadd <8 x float> %168, %182
  %184 = extractvalue { ptr, i64 } %27, 0
  %185 = extractelement <8 x i64> %145, i32 0
  %186 = sub i64 %185, 0
  %187 = mul i64 %186, 4
  %buffer.contiguous.address62 = getelementptr i8, ptr %184, i64 %187
  call void @llvm.masked.store.v8f32.p0(<8 x float> %183, ptr align 1 %buffer.contiguous.address62, <8 x i1> %51)
  %.state63 = load i64, ptr %.slot7, align 4
  %188 = add i64 %.state63, 1
  store i64 %188, ptr %.slot7, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false45
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true27:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false28:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true44:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false45:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %x) #2 {
entry:
  %0 = bitcast <8 x float> %x to <8 x i32>
  %1 = and <8 x i32> %0, splat (i32 2147483647)
  %2 = bitcast <8 x i32> %1 to <8 x float>
  %3 = fcmp contract ole <8 x float> %2, splat (float 1.000000e+00)
  %4 = fmul contract <8 x float> %2, %2
  %5 = fmul contract <8 x float> splat (float 0x3DE6124620000000), %4
  %6 = fadd contract <8 x float> %5, splat (float 0x3E5AE64560000000)
  %7 = fmul contract <8 x float> %6, %4
  %8 = fadd contract <8 x float> %7, splat (float 0x3EC71DE3A0000000)
  %9 = fmul contract <8 x float> %8, %4
  %10 = fadd contract <8 x float> %9, splat (float 0x3F2A01A020000000)
  %11 = fmul contract <8 x float> %10, %4
  %12 = fadd contract <8 x float> %11, splat (float 0x3F81111120000000)
  %13 = fmul contract <8 x float> %12, %4
  %14 = fadd contract <8 x float> %13, splat (float 0x3FC5555560000000)
  %15 = fmul contract <8 x float> %14, %4
  %16 = fadd contract <8 x float> %15, splat (float 1.000000e+00)
  %17 = fmul contract <8 x float> %2, %16
  %18 = fmul contract <8 x float> %2, %2
  %19 = fmul contract <8 x float> splat (float 0x3E21EED8E0000000), %18
  %20 = fadd contract <8 x float> %19, splat (float 0x3E927E4FC0000000)
  %21 = fmul contract <8 x float> %20, %18
  %22 = fadd contract <8 x float> %21, splat (float 0x3EFA01A020000000)
  %23 = fmul contract <8 x float> %22, %18
  %24 = fadd contract <8 x float> %23, splat (float 0x3F56C16C20000000)
  %25 = fmul contract <8 x float> %24, %18
  %26 = fadd contract <8 x float> %25, splat (float 0x3FA5555560000000)
  %27 = fmul contract <8 x float> %26, %18
  %28 = fadd contract <8 x float> %27, splat (float 5.000000e-01)
  %29 = fmul contract <8 x float> %28, %18
  %30 = fadd contract <8 x float> %29, splat (float 1.000000e+00)
  %31 = fdiv contract <8 x float> %17, %30
  %32 = fcmp contract ole <8 x float> %2, splat (float 9.000000e+00)
  %33 = select contract <8 x i1> %32, <8 x float> %2, <8 x float> zeroinitializer
  %exp.half = call contract <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %33)
  %34 = fdiv contract <8 x float> splat (float 2.500000e-01), %exp.half
  %35 = fsub contract <8 x float> %exp.half, %34
  %36 = fadd contract <8 x float> %exp.half, %34
  %37 = fdiv contract <8 x float> %35, %36
  %38 = select contract <8 x i1> %32, <8 x float> %37, <8 x float> splat (float 1.000000e+00)
  %39 = select contract <8 x i1> %3, <8 x float> %31, <8 x float> %38
  %40 = bitcast <8 x float> %39 to <8 x i32>
  %41 = and <8 x i32> %40, splat (i32 2147483647)
  %42 = bitcast <8 x float> %x to <8 x i32>
  %43 = and <8 x i32> %42, splat (i32 -2147483648)
  %44 = or <8 x i32> %41, %43
  %45 = bitcast <8 x i32> %44 to <8 x float>
  %46 = fcmp contract uno <8 x float> %x, %x
  %47 = select contract <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %x) #2 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = sub <8 x i32> %11, splat (i32 1)
  %32 = ashr <8 x i32> %31, splat (i32 1)
  %33 = add <8 x i32> %32, splat (i32 127)
  %34 = shl <8 x i32> %33, splat (i32 23)
  %35 = bitcast <8 x i32> %34 to <8 x float>
  %36 = fmul <8 x float> %30, %35
  %37 = sub <8 x i32> %31, %32
  %38 = add <8 x i32> %37, splat (i32 127)
  %39 = shl <8 x i32> %38, splat (i32 23)
  %40 = bitcast <8 x i32> %39 to <8 x float>
  %41 = fmul <8 x float> %36, %40
  %42 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %43 = select <8 x i1> %42, <8 x float> zeroinitializer, <8 x float> %41
  %44 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %45 = select <8 x i1> %44, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %43
  %46 = fcmp uno <8 x float> %x, %x
  %47 = select <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #3

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3072 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill5 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill5, align 64
  %.slot6 = alloca i64, align 8
  store i64 0, ptr %.slot6, align 4
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert8 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat9 = shufflevector <8 x i32> %.splatinsert8, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat9, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert10 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat11 = shufflevector <8 x i32> %.splatinsert10, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat11, %41
  %44 = mul i32 %32, 1
  %.splatinsert12 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat13 = shufflevector <8 x i32> %.splatinsert12, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat13, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert14 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat15 = shufflevector <8 x i32> %.splatinsert14, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat15, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert16 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat17 = shufflevector <8 x i32> %.splatinsert16, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat17
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 96
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state18 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state18, 8
  %.splatinsert19 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat20 = shufflevector <8 x i64> %.splatinsert19, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat20, %.spill.load
  %.spill.load21 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load21, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 768)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state22 = load i64, ptr %.slot, align 4
  %.splatinsert23 = insertelement <8 x i64> poison, i64 %.state22, i64 0
  %.splat24 = shufflevector <8 x i64> %.splatinsert23, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat24, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state25 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state25, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %102 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill5, align 64
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %102, 0
  %105 = select <8 x i1> %51, <8 x ptr> %103, <8 x ptr> %104
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %102, 1
  %108 = select <8 x i1> %51, <8 x i64> %106, <8 x i64> %107
  %109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %105, 0
  %110 = insertvalue { <8 x ptr>, <8 x i64> } %109, <8 x i64> %108, 1
  store { <8 x ptr>, <8 x i64> } %110, ptr %tile_snapshot.spill5, align 64
  store i64 0, ptr %.slot6, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state26 = load i64, ptr %.slot6, align 4
  %111 = icmp slt i64 %.state26, 96
  br i1 %111, label %direct.true27, label %direct.false28

direct.schedule.5:                                ; preds = %direct.true27
  %.state29 = load i64, ptr %.slot6, align 4
  %112 = mul i64 %.state29, 8
  %.splatinsert30 = insertelement <8 x i64> poison, i64 %112, i64 0
  %.splat31 = shufflevector <8 x i64> %.splatinsert30, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load32 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> %.splat31, %.spill.load32
  %.spill.load33 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load33, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 768)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %15, 0
  %120 = extractelement <8 x i64> %118, i32 0
  %121 = sub i64 %120, 0
  %122 = mul i64 %121, 4
  %buffer.contiguous.address34 = getelementptr i8, ptr %119, i64 %122
  %buffer.contiguous.load35 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address34, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load36 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill5, align 64
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 0
  %124 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 1
  %.state37 = load i64, ptr %.slot6, align 4
  %.splatinsert38 = insertelement <8 x i64> poison, i64 %.state37, i64 0
  %.splat39 = shufflevector <8 x i64> %.splatinsert38, <8 x i64> poison, <8 x i32> zeroinitializer
  %125 = mul <8 x i64> %.splat39, splat (i64 32)
  %126 = add <8 x i64> %124, %125
  %127 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %123, 0
  %128 = insertvalue { <8 x ptr>, <8 x i64> } %127, <8 x i64> %126, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %128, 1
  %131 = extractelement <8 x ptr> %129, i32 0
  %132 = extractelement <8 x i64> %130, i32 0
  %133 = sub i64 %132, 0
  %134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %135 = select i1 %134, i64 %133, i64 0
  %private.contiguous.address40 = getelementptr i8, ptr %131, i64 %135
  %private.contiguous.preserve41 = load <8 x float>, ptr %private.contiguous.address40, align 4
  %136 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load35, <8 x float> %private.contiguous.preserve41
  store <8 x float> %136, ptr %private.contiguous.address40, align 4
  %.state42 = load i64, ptr %.slot6, align 4
  %137 = add i64 %.state42, 1
  store i64 %137, ptr %.slot6, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false28
  store i64 0, ptr %.slot7, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state43 = load i64, ptr %.slot7, align 4
  %138 = icmp slt i64 %.state43, 96
  br i1 %138, label %direct.true44, label %direct.false45

direct.schedule.8:                                ; preds = %direct.true44
  %.state46 = load i64, ptr %.slot7, align 4
  %139 = mul i64 %.state46, 8
  %.splatinsert47 = insertelement <8 x i64> poison, i64 %139, i64 0
  %.splat48 = shufflevector <8 x i64> %.splatinsert47, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load49 = load <8 x i64>, ptr %.spill, align 64
  %140 = add <8 x i64> %.splat48, %.spill.load49
  %.spill.load50 = load <8 x i64>, ptr %.spill4, align 64
  %141 = add <8 x i64> %.spill.load50, zeroinitializer
  %142 = add <8 x i64> zeroinitializer, %141
  %143 = add <8 x i64> zeroinitializer, %140
  %144 = mul <8 x i64> %142, splat (i64 768)
  %145 = add <8 x i64> %144, %143
  %tile_snapshot.spill.load51 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load51, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load51, 1
  %.state52 = load i64, ptr %.slot7, align 4
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %.state52, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %148 = mul <8 x i64> %.splat54, splat (i64 32)
  %149 = add <8 x i64> %147, %148
  %150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %146, 0
  %151 = insertvalue { <8 x ptr>, <8 x i64> } %150, <8 x i64> %149, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %154 = extractelement <8 x ptr> %152, i32 0
  %155 = extractelement <8 x i64> %153, i32 0
  %156 = sub i64 %155, 0
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %158 = select i1 %157, i64 %156, i64 0
  %private.contiguous.address55 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address55, align 4
  %159 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %160 = fmul <8 x float> splat (float 5.000000e-01), %159
  %161 = fmul <8 x float> splat (float 0x3FA6E4E260000000), %159
  %162 = fmul <8 x float> %161, %159
  %163 = fmul <8 x float> %162, %159
  %164 = fadd <8 x float> %159, %163
  %165 = fmul <8 x float> splat (float 0x3FE9884540000000), %164
  %166 = select <8 x i1> %51, <8 x float> %165, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %166)
  %167 = fadd <8 x float> splat (float 1.000000e+00), %native.tanh
  %168 = fmul <8 x float> %160, %167
  %tile_snapshot.spill.load56 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill5, align 64
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 0
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load56, 1
  %.state57 = load i64, ptr %.slot7, align 4
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %.state57, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %171 = mul <8 x i64> %.splat59, splat (i64 32)
  %172 = add <8 x i64> %170, %171
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %169, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %177 = extractelement <8 x ptr> %175, i32 0
  %178 = extractelement <8 x i64> %176, i32 0
  %179 = sub i64 %178, 0
  %180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %181 = select i1 %180, i64 %179, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %177, i64 %181
  %private.contiguous.load61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %182 = select <8 x i1> %51, <8 x float> %private.contiguous.load61, <8 x float> zeroinitializer
  %183 = fadd <8 x float> %168, %182
  %184 = extractvalue { ptr, i64 } %27, 0
  %185 = extractelement <8 x i64> %145, i32 0
  %186 = sub i64 %185, 0
  %187 = mul i64 %186, 4
  %buffer.contiguous.address62 = getelementptr i8, ptr %184, i64 %187
  call void @llvm.masked.store.v8f32.p0(<8 x float> %183, ptr align 1 %buffer.contiguous.address62, <8 x i1> %51)
  %.state63 = load i64, ptr %.slot7, align 4
  %188 = add i64 %.state63, 1
  store i64 %188, ptr %.slot7, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false45
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true27:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false28:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true44:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false45:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

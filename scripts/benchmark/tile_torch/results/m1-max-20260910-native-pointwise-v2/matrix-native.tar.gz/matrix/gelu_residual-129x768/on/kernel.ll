; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3072 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot5 = alloca i64, align 8
  store i64 0, ptr %.slot5, align 4
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca i64, align 8
  store i64 0, ptr %.slot8, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat12, %41
  %44 = mul i32 %32, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat14, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat16, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = extractvalue { ptr, i64 } %9, 1
  %67 = extractvalue { ptr, i64 } %9, 0
  %68 = ptrtoint ptr %67 to i64
  %69 = extractvalue { ptr, i64 } %27, 1
  %70 = extractvalue { ptr, i64 } %27, 0
  %71 = ptrtoint ptr %70 to i64
  %72 = icmp uge i64 %68, %71
  %73 = sub i64 %68, %71
  %74 = icmp uge i64 %73, 396288
  %75 = and i1 %72, %74
  %76 = icmp uge i64 %71, %68
  %77 = sub i64 %71, %68
  %78 = icmp uge i64 %77, 396288
  %79 = and i1 %76, %78
  %80 = or i1 %75, %79
  %81 = and i1 true, %80
  %82 = extractvalue { ptr, i64 } %15, 1
  %83 = extractvalue { ptr, i64 } %15, 0
  %84 = ptrtoint ptr %83 to i64
  %85 = icmp uge i64 %84, %71
  %86 = sub i64 %84, %71
  %87 = icmp uge i64 %86, 396288
  %88 = and i1 %85, %87
  %89 = icmp uge i64 %71, %84
  %90 = sub i64 %71, %84
  %91 = icmp uge i64 %90, 396288
  %92 = and i1 %89, %91
  %93 = or i1 %88, %92
  %94 = and i1 %81, %93
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %95 = icmp slt i64 %.state, 96
  br i1 %95, label %direct.true19, label %direct.false20

direct.schedule.3:                                ; preds = %direct.true19
  %.state21 = load i64, ptr %.slot, align 4
  %96 = mul i64 %.state21, 8
  %.splatinsert22 = insertelement <8 x i64> poison, i64 %96, i64 0
  %.splat23 = shufflevector <8 x i64> %.splatinsert22, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %97 = add <8 x i64> %.splat23, %.spill.load
  %.spill.load24 = load <8 x i64>, ptr %.spill4, align 64
  %98 = add <8 x i64> %.spill.load24, zeroinitializer
  %99 = add <8 x i64> zeroinitializer, %98
  %100 = add <8 x i64> zeroinitializer, %97
  %101 = mul <8 x i64> %99, splat (i64 768)
  %102 = add <8 x i64> %101, %100
  %103 = extractvalue { ptr, i64 } %9, 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = mul i64 %105, 4
  %buffer.contiguous.address = getelementptr i8, ptr %103, i64 %106
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %51, <8 x float> zeroinitializer)
  %107 = fmul <8 x float> splat (float 5.000000e-01), %buffer.contiguous.load
  %108 = fmul <8 x float> splat (float 0x3FA6E4E260000000), %buffer.contiguous.load
  %109 = fmul <8 x float> %108, %buffer.contiguous.load
  %110 = fmul <8 x float> %109, %buffer.contiguous.load
  %111 = fadd <8 x float> %buffer.contiguous.load, %110
  %112 = fmul <8 x float> splat (float 0x3FE9884540000000), %111
  %113 = select <8 x i1> %51, <8 x float> %112, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %113)
  %114 = fadd <8 x float> splat (float 1.000000e+00), %native.tanh
  %115 = fmul <8 x float> %107, %114
  %116 = extractvalue { ptr, i64 } %15, 0
  %117 = extractelement <8 x i64> %102, i32 0
  %118 = sub i64 %117, 0
  %119 = mul i64 %118, 4
  %buffer.contiguous.address25 = getelementptr i8, ptr %116, i64 %119
  %buffer.contiguous.load26 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address25, <8 x i1> %51, <8 x float> zeroinitializer)
  %120 = fadd <8 x float> %115, %buffer.contiguous.load26
  %121 = extractvalue { ptr, i64 } %27, 0
  %122 = extractelement <8 x i64> %102, i32 0
  %123 = sub i64 %122, 0
  %124 = mul i64 %123, 4
  %buffer.contiguous.address27 = getelementptr i8, ptr %121, i64 %124
  call void @llvm.masked.store.v8f32.p0(<8 x float> %120, ptr align 1 %buffer.contiguous.address27, <8 x i1> %51)
  %.state28 = load i64, ptr %.slot, align 4
  %125 = add i64 %.state28, 1
  store i64 %125, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false62, %direct.false20
  ret void

direct.schedule.5:                                ; preds = %direct.false
  %126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %126, 0
  %129 = select <8 x i1> %51, <8 x ptr> %127, <8 x ptr> %128
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %126, 1
  %132 = select <8 x i1> %51, <8 x i64> %130, <8 x i64> %131
  %133 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %129, 0
  %134 = insertvalue { <8 x ptr>, <8 x i64> } %133, <8 x i64> %132, 1
  store { <8 x ptr>, <8 x i64> } %134, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot5, align 4
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state29 = load i64, ptr %.slot5, align 4
  %135 = icmp slt i64 %.state29, 96
  br i1 %135, label %direct.true30, label %direct.false31

direct.schedule.7:                                ; preds = %direct.true30
  %.state32 = load i64, ptr %.slot5, align 4
  %136 = mul i64 %.state32, 8
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %136, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load35 = load <8 x i64>, ptr %.spill, align 64
  %137 = add <8 x i64> %.splat34, %.spill.load35
  %.spill.load36 = load <8 x i64>, ptr %.spill4, align 64
  %138 = add <8 x i64> %.spill.load36, zeroinitializer
  %139 = add <8 x i64> zeroinitializer, %138
  %140 = add <8 x i64> zeroinitializer, %137
  %141 = mul <8 x i64> %139, splat (i64 768)
  %142 = add <8 x i64> %141, %140
  %143 = extractvalue { ptr, i64 } %9, 0
  %144 = extractelement <8 x i64> %142, i32 0
  %145 = sub i64 %144, 0
  %146 = mul i64 %145, 4
  %buffer.contiguous.address37 = getelementptr i8, ptr %143, i64 %146
  %buffer.contiguous.load38 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address37, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state39 = load i64, ptr %.slot5, align 4
  %.splatinsert40 = insertelement <8 x i64> poison, i64 %.state39, i64 0
  %.splat41 = shufflevector <8 x i64> %.splatinsert40, <8 x i64> poison, <8 x i32> zeroinitializer
  %149 = mul <8 x i64> %.splat41, splat (i64 32)
  %150 = add <8 x i64> %148, %149
  %151 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %147, 0
  %152 = insertvalue { <8 x ptr>, <8 x i64> } %151, <8 x i64> %150, 1
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %152, 1
  %155 = extractelement <8 x ptr> %153, i32 0
  %156 = extractelement <8 x i64> %154, i32 0
  %157 = sub i64 %156, 0
  %158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %159 = select i1 %158, i64 %157, i64 0
  %private.contiguous.address = getelementptr i8, ptr %155, i64 %159
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %160 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load38, <8 x float> %private.contiguous.preserve
  store <8 x float> %160, ptr %private.contiguous.address, align 4
  %.state42 = load i64, ptr %.slot5, align 4
  %161 = add i64 %.state42, 1
  store i64 %161, ptr %.slot5, align 4
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false31
  %162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %162, 0
  %165 = select <8 x i1> %51, <8 x ptr> %163, <8 x ptr> %164
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %162, 1
  %168 = select <8 x i1> %51, <8 x i64> %166, <8 x i64> %167
  %169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %165, 0
  %170 = insertvalue { <8 x ptr>, <8 x i64> } %169, <8 x i64> %168, 1
  store { <8 x ptr>, <8 x i64> } %170, ptr %tile_snapshot.spill6, align 64
  store i64 0, ptr %.slot7, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.10, %direct.schedule.8
  %.state43 = load i64, ptr %.slot7, align 4
  %171 = icmp slt i64 %.state43, 96
  br i1 %171, label %direct.true44, label %direct.false45

direct.schedule.10:                               ; preds = %direct.true44
  %.state46 = load i64, ptr %.slot7, align 4
  %172 = mul i64 %.state46, 8
  %.splatinsert47 = insertelement <8 x i64> poison, i64 %172, i64 0
  %.splat48 = shufflevector <8 x i64> %.splatinsert47, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load49 = load <8 x i64>, ptr %.spill, align 64
  %173 = add <8 x i64> %.splat48, %.spill.load49
  %.spill.load50 = load <8 x i64>, ptr %.spill4, align 64
  %174 = add <8 x i64> %.spill.load50, zeroinitializer
  %175 = add <8 x i64> zeroinitializer, %174
  %176 = add <8 x i64> zeroinitializer, %173
  %177 = mul <8 x i64> %175, splat (i64 768)
  %178 = add <8 x i64> %177, %176
  %179 = extractvalue { ptr, i64 } %15, 0
  %180 = extractelement <8 x i64> %178, i32 0
  %181 = sub i64 %180, 0
  %182 = mul i64 %181, 4
  %buffer.contiguous.address51 = getelementptr i8, ptr %179, i64 %182
  %buffer.contiguous.load52 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address51, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %.state54 = load i64, ptr %.slot7, align 4
  %.splatinsert55 = insertelement <8 x i64> poison, i64 %.state54, i64 0
  %.splat56 = shufflevector <8 x i64> %.splatinsert55, <8 x i64> poison, <8 x i32> zeroinitializer
  %185 = mul <8 x i64> %.splat56, splat (i64 32)
  %186 = add <8 x i64> %184, %185
  %187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %183, 0
  %188 = insertvalue { <8 x ptr>, <8 x i64> } %187, <8 x i64> %186, 1
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %188, 1
  %191 = extractelement <8 x ptr> %189, i32 0
  %192 = extractelement <8 x i64> %190, i32 0
  %193 = sub i64 %192, 0
  %194 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %195 = select i1 %194, i64 %193, i64 0
  %private.contiguous.address57 = getelementptr i8, ptr %191, i64 %195
  %private.contiguous.preserve58 = load <8 x float>, ptr %private.contiguous.address57, align 4
  %196 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load52, <8 x float> %private.contiguous.preserve58
  store <8 x float> %196, ptr %private.contiguous.address57, align 4
  %.state59 = load i64, ptr %.slot7, align 4
  %197 = add i64 %.state59, 1
  store i64 %197, ptr %.slot7, align 4
  br label %direct.schedule.9

direct.schedule.11:                               ; preds = %direct.false45
  store i64 0, ptr %.slot8, align 4
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.13, %direct.schedule.11
  %.state60 = load i64, ptr %.slot8, align 4
  %198 = icmp slt i64 %.state60, 96
  br i1 %198, label %direct.true61, label %direct.false62

direct.schedule.13:                               ; preds = %direct.true61
  %.state63 = load i64, ptr %.slot8, align 4
  %199 = mul i64 %.state63, 8
  %.splatinsert64 = insertelement <8 x i64> poison, i64 %199, i64 0
  %.splat65 = shufflevector <8 x i64> %.splatinsert64, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load66 = load <8 x i64>, ptr %.spill, align 64
  %200 = add <8 x i64> %.splat65, %.spill.load66
  %.spill.load67 = load <8 x i64>, ptr %.spill4, align 64
  %201 = add <8 x i64> %.spill.load67, zeroinitializer
  %202 = add <8 x i64> zeroinitializer, %201
  %203 = add <8 x i64> zeroinitializer, %200
  %204 = mul <8 x i64> %202, splat (i64 768)
  %205 = add <8 x i64> %204, %203
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %.state69 = load i64, ptr %.slot8, align 4
  %.splatinsert70 = insertelement <8 x i64> poison, i64 %.state69, i64 0
  %.splat71 = shufflevector <8 x i64> %.splatinsert70, <8 x i64> poison, <8 x i32> zeroinitializer
  %208 = mul <8 x i64> %.splat71, splat (i64 32)
  %209 = add <8 x i64> %207, %208
  %210 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %206, 0
  %211 = insertvalue { <8 x ptr>, <8 x i64> } %210, <8 x i64> %209, 1
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %211, 1
  %214 = extractelement <8 x ptr> %212, i32 0
  %215 = extractelement <8 x i64> %213, i32 0
  %216 = sub i64 %215, 0
  %217 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %218 = select i1 %217, i64 %216, i64 0
  %private.contiguous.address72 = getelementptr i8, ptr %214, i64 %218
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address72, align 4
  %219 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %220 = fmul <8 x float> splat (float 5.000000e-01), %219
  %221 = fmul <8 x float> splat (float 0x3FA6E4E260000000), %219
  %222 = fmul <8 x float> %221, %219
  %223 = fmul <8 x float> %222, %219
  %224 = fadd <8 x float> %219, %223
  %225 = fmul <8 x float> splat (float 0x3FE9884540000000), %224
  %226 = select <8 x i1> %51, <8 x float> %225, <8 x float> zeroinitializer
  %native.tanh73 = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %226)
  %227 = fadd <8 x float> splat (float 1.000000e+00), %native.tanh73
  %228 = fmul <8 x float> %220, %227
  %tile_snapshot.spill.load74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 0
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 1
  %.state75 = load i64, ptr %.slot8, align 4
  %.splatinsert76 = insertelement <8 x i64> poison, i64 %.state75, i64 0
  %.splat77 = shufflevector <8 x i64> %.splatinsert76, <8 x i64> poison, <8 x i32> zeroinitializer
  %231 = mul <8 x i64> %.splat77, splat (i64 32)
  %232 = add <8 x i64> %230, %231
  %233 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %229, 0
  %234 = insertvalue { <8 x ptr>, <8 x i64> } %233, <8 x i64> %232, 1
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %234, 1
  %237 = extractelement <8 x ptr> %235, i32 0
  %238 = extractelement <8 x i64> %236, i32 0
  %239 = sub i64 %238, 0
  %240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %241 = select i1 %240, i64 %239, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %237, i64 %241
  %private.contiguous.load79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %242 = select <8 x i1> %51, <8 x float> %private.contiguous.load79, <8 x float> zeroinitializer
  %243 = fadd <8 x float> %228, %242
  %244 = extractvalue { ptr, i64 } %27, 0
  %245 = extractelement <8 x i64> %205, i32 0
  %246 = sub i64 %245, 0
  %247 = mul i64 %246, 4
  %buffer.contiguous.address80 = getelementptr i8, ptr %244, i64 %247
  call void @llvm.masked.store.v8f32.p0(<8 x float> %243, ptr align 1 %buffer.contiguous.address80, <8 x i1> %51)
  %.state81 = load i64, ptr %.slot8, align 4
  %248 = add i64 %.state81, 1
  store i64 %248, ptr %.slot8, align 4
  br label %direct.schedule.12

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.5

direct.true19:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false20:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true30:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false31:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true44:                                    ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false45:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.11

direct.true61:                                    ; preds = %direct.schedule.12
  br label %direct.schedule.13

direct.false62:                                   ; preds = %direct.schedule.12
  br label %direct.schedule.4
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %x) #2 {
entry:
  %0 = bitcast <8 x float> %x to <8 x i32>
  %1 = and <8 x i32> %0, splat (i32 2147483647)
  %2 = bitcast <8 x i32> %1 to <8 x float>
  %3 = fcmp contract ole <8 x float> %2, splat (float 1.000000e+00)
  %4 = fmul contract <8 x float> %2, %2
  %5 = fmul contract <8 x float> splat (float 0x3DE6124620000000), %4
  %6 = fadd contract <8 x float> %5, splat (float 0x3E5AE64560000000)
  %7 = fmul contract <8 x float> %6, %4
  %8 = fadd contract <8 x float> %7, splat (float 0x3EC71DE3A0000000)
  %9 = fmul contract <8 x float> %8, %4
  %10 = fadd contract <8 x float> %9, splat (float 0x3F2A01A020000000)
  %11 = fmul contract <8 x float> %10, %4
  %12 = fadd contract <8 x float> %11, splat (float 0x3F81111120000000)
  %13 = fmul contract <8 x float> %12, %4
  %14 = fadd contract <8 x float> %13, splat (float 0x3FC5555560000000)
  %15 = fmul contract <8 x float> %14, %4
  %16 = fadd contract <8 x float> %15, splat (float 1.000000e+00)
  %17 = fmul contract <8 x float> %2, %16
  %18 = fmul contract <8 x float> %2, %2
  %19 = fmul contract <8 x float> splat (float 0x3E21EED8E0000000), %18
  %20 = fadd contract <8 x float> %19, splat (float 0x3E927E4FC0000000)
  %21 = fmul contract <8 x float> %20, %18
  %22 = fadd contract <8 x float> %21, splat (float 0x3EFA01A020000000)
  %23 = fmul contract <8 x float> %22, %18
  %24 = fadd contract <8 x float> %23, splat (float 0x3F56C16C20000000)
  %25 = fmul contract <8 x float> %24, %18
  %26 = fadd contract <8 x float> %25, splat (float 0x3FA5555560000000)
  %27 = fmul contract <8 x float> %26, %18
  %28 = fadd contract <8 x float> %27, splat (float 5.000000e-01)
  %29 = fmul contract <8 x float> %28, %18
  %30 = fadd contract <8 x float> %29, splat (float 1.000000e+00)
  %31 = fdiv contract <8 x float> %17, %30
  %32 = fcmp contract ole <8 x float> %2, splat (float 9.000000e+00)
  %33 = select contract <8 x i1> %32, <8 x float> %2, <8 x float> zeroinitializer
  %exp.half = call contract <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %33)
  %34 = fdiv contract <8 x float> splat (float 2.500000e-01), %exp.half
  %35 = fsub contract <8 x float> %exp.half, %34
  %36 = fadd contract <8 x float> %exp.half, %34
  %37 = fdiv contract <8 x float> %35, %36
  %38 = select contract <8 x i1> %32, <8 x float> %37, <8 x float> splat (float 1.000000e+00)
  %39 = select contract <8 x i1> %3, <8 x float> %31, <8 x float> %38
  %40 = bitcast <8 x float> %39 to <8 x i32>
  %41 = and <8 x i32> %40, splat (i32 2147483647)
  %42 = bitcast <8 x float> %x to <8 x i32>
  %43 = and <8 x i32> %42, splat (i32 -2147483648)
  %44 = or <8 x i32> %41, %43
  %45 = bitcast <8 x i32> %44 to <8 x float>
  %46 = fcmp contract uno <8 x float> %x, %x
  %47 = select contract <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_half_f32_v8_u10(<8 x float> %x) #2 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = sub <8 x i32> %11, splat (i32 1)
  %32 = ashr <8 x i32> %31, splat (i32 1)
  %33 = add <8 x i32> %32, splat (i32 127)
  %34 = shl <8 x i32> %33, splat (i32 23)
  %35 = bitcast <8 x i32> %34 to <8 x float>
  %36 = fmul <8 x float> %30, %35
  %37 = sub <8 x i32> %31, %32
  %38 = add <8 x i32> %37, splat (i32 127)
  %39 = shl <8 x i32> %38, splat (i32 23)
  %40 = bitcast <8 x i32> %39 to <8 x float>
  %41 = fmul <8 x float> %36, %40
  %42 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %43 = select <8 x i1> %42, <8 x float> zeroinitializer, <8 x float> %41
  %44 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %45 = select <8 x i1> %44, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %43
  %46 = fcmp uno <8 x float> %x, %x
  %47 = select <8 x i1> %46, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %45
  ret <8 x float> %47
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #3

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [3072 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [3072 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot5 = alloca i64, align 8
  store i64 0, ptr %.slot5, align 4
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca i64, align 8
  store i64 0, ptr %.slot8, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat12, %41
  %44 = mul i32 %32, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat14, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat16, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = extractvalue { ptr, i64 } %9, 1
  %67 = extractvalue { ptr, i64 } %9, 0
  %68 = ptrtoint ptr %67 to i64
  %69 = extractvalue { ptr, i64 } %27, 1
  %70 = extractvalue { ptr, i64 } %27, 0
  %71 = ptrtoint ptr %70 to i64
  %72 = icmp uge i64 %68, %71
  %73 = sub i64 %68, %71
  %74 = icmp uge i64 %73, 396288
  %75 = and i1 %72, %74
  %76 = icmp uge i64 %71, %68
  %77 = sub i64 %71, %68
  %78 = icmp uge i64 %77, 396288
  %79 = and i1 %76, %78
  %80 = or i1 %75, %79
  %81 = and i1 true, %80
  %82 = extractvalue { ptr, i64 } %15, 1
  %83 = extractvalue { ptr, i64 } %15, 0
  %84 = ptrtoint ptr %83 to i64
  %85 = icmp uge i64 %84, %71
  %86 = sub i64 %84, %71
  %87 = icmp uge i64 %86, 396288
  %88 = and i1 %85, %87
  %89 = icmp uge i64 %71, %84
  %90 = sub i64 %71, %84
  %91 = icmp uge i64 %90, 396288
  %92 = and i1 %89, %91
  %93 = or i1 %88, %92
  %94 = and i1 %81, %93
  br i1 %94, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.3, %direct.schedule.1
  %.state = load i64, ptr %.slot, align 4
  %95 = icmp slt i64 %.state, 96
  br i1 %95, label %direct.true19, label %direct.false20

direct.schedule.3:                                ; preds = %direct.true19
  %.state21 = load i64, ptr %.slot, align 4
  %96 = mul i64 %.state21, 8
  %.splatinsert22 = insertelement <8 x i64> poison, i64 %96, i64 0
  %.splat23 = shufflevector <8 x i64> %.splatinsert22, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %97 = add <8 x i64> %.splat23, %.spill.load
  %.spill.load24 = load <8 x i64>, ptr %.spill4, align 64
  %98 = add <8 x i64> %.spill.load24, zeroinitializer
  %99 = add <8 x i64> zeroinitializer, %98
  %100 = add <8 x i64> zeroinitializer, %97
  %101 = mul <8 x i64> %99, splat (i64 768)
  %102 = add <8 x i64> %101, %100
  %103 = extractvalue { ptr, i64 } %9, 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = mul i64 %105, 4
  %buffer.contiguous.address = getelementptr i8, ptr %103, i64 %106
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %51, <8 x float> zeroinitializer)
  %107 = fmul <8 x float> splat (float 5.000000e-01), %buffer.contiguous.load
  %108 = fmul <8 x float> splat (float 0x3FA6E4E260000000), %buffer.contiguous.load
  %109 = fmul <8 x float> %108, %buffer.contiguous.load
  %110 = fmul <8 x float> %109, %buffer.contiguous.load
  %111 = fadd <8 x float> %buffer.contiguous.load, %110
  %112 = fmul <8 x float> splat (float 0x3FE9884540000000), %111
  %113 = select <8 x i1> %51, <8 x float> %112, <8 x float> zeroinitializer
  %native.tanh = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %113)
  %114 = fadd <8 x float> splat (float 1.000000e+00), %native.tanh
  %115 = fmul <8 x float> %107, %114
  %116 = extractvalue { ptr, i64 } %15, 0
  %117 = extractelement <8 x i64> %102, i32 0
  %118 = sub i64 %117, 0
  %119 = mul i64 %118, 4
  %buffer.contiguous.address25 = getelementptr i8, ptr %116, i64 %119
  %buffer.contiguous.load26 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address25, <8 x i1> %51, <8 x float> zeroinitializer)
  %120 = fadd <8 x float> %115, %buffer.contiguous.load26
  %121 = extractvalue { ptr, i64 } %27, 0
  %122 = extractelement <8 x i64> %102, i32 0
  %123 = sub i64 %122, 0
  %124 = mul i64 %123, 4
  %buffer.contiguous.address27 = getelementptr i8, ptr %121, i64 %124
  call void @llvm.masked.store.v8f32.p0(<8 x float> %120, ptr align 1 %buffer.contiguous.address27, <8 x i1> %51)
  %.state28 = load i64, ptr %.slot, align 4
  %125 = add i64 %.state28, 1
  store i64 %125, ptr %.slot, align 4
  br label %direct.schedule.2

direct.schedule.4:                                ; preds = %direct.false62, %direct.false20
  ret void

direct.schedule.5:                                ; preds = %direct.false
  %126 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %126, 0
  %129 = select <8 x i1> %51, <8 x ptr> %127, <8 x ptr> %128
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %126, 1
  %132 = select <8 x i1> %51, <8 x i64> %130, <8 x i64> %131
  %133 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %129, 0
  %134 = insertvalue { <8 x ptr>, <8 x i64> } %133, <8 x i64> %132, 1
  store { <8 x ptr>, <8 x i64> } %134, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot5, align 4
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state29 = load i64, ptr %.slot5, align 4
  %135 = icmp slt i64 %.state29, 96
  br i1 %135, label %direct.true30, label %direct.false31

direct.schedule.7:                                ; preds = %direct.true30
  %.state32 = load i64, ptr %.slot5, align 4
  %136 = mul i64 %.state32, 8
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %136, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load35 = load <8 x i64>, ptr %.spill, align 64
  %137 = add <8 x i64> %.splat34, %.spill.load35
  %.spill.load36 = load <8 x i64>, ptr %.spill4, align 64
  %138 = add <8 x i64> %.spill.load36, zeroinitializer
  %139 = add <8 x i64> zeroinitializer, %138
  %140 = add <8 x i64> zeroinitializer, %137
  %141 = mul <8 x i64> %139, splat (i64 768)
  %142 = add <8 x i64> %141, %140
  %143 = extractvalue { ptr, i64 } %9, 0
  %144 = extractelement <8 x i64> %142, i32 0
  %145 = sub i64 %144, 0
  %146 = mul i64 %145, 4
  %buffer.contiguous.address37 = getelementptr i8, ptr %143, i64 %146
  %buffer.contiguous.load38 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address37, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state39 = load i64, ptr %.slot5, align 4
  %.splatinsert40 = insertelement <8 x i64> poison, i64 %.state39, i64 0
  %.splat41 = shufflevector <8 x i64> %.splatinsert40, <8 x i64> poison, <8 x i32> zeroinitializer
  %149 = mul <8 x i64> %.splat41, splat (i64 32)
  %150 = add <8 x i64> %148, %149
  %151 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %147, 0
  %152 = insertvalue { <8 x ptr>, <8 x i64> } %151, <8 x i64> %150, 1
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %152, 1
  %155 = extractelement <8 x ptr> %153, i32 0
  %156 = extractelement <8 x i64> %154, i32 0
  %157 = sub i64 %156, 0
  %158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %159 = select i1 %158, i64 %157, i64 0
  %private.contiguous.address = getelementptr i8, ptr %155, i64 %159
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %160 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load38, <8 x float> %private.contiguous.preserve
  store <8 x float> %160, ptr %private.contiguous.address, align 4
  %.state42 = load i64, ptr %.slot5, align 4
  %161 = add i64 %.state42, 1
  store i64 %161, ptr %.slot5, align 4
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false31
  %162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %162, 0
  %165 = select <8 x i1> %51, <8 x ptr> %163, <8 x ptr> %164
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %162, 1
  %168 = select <8 x i1> %51, <8 x i64> %166, <8 x i64> %167
  %169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %165, 0
  %170 = insertvalue { <8 x ptr>, <8 x i64> } %169, <8 x i64> %168, 1
  store { <8 x ptr>, <8 x i64> } %170, ptr %tile_snapshot.spill6, align 64
  store i64 0, ptr %.slot7, align 4
  br label %direct.schedule.9

direct.schedule.9:                                ; preds = %direct.schedule.10, %direct.schedule.8
  %.state43 = load i64, ptr %.slot7, align 4
  %171 = icmp slt i64 %.state43, 96
  br i1 %171, label %direct.true44, label %direct.false45

direct.schedule.10:                               ; preds = %direct.true44
  %.state46 = load i64, ptr %.slot7, align 4
  %172 = mul i64 %.state46, 8
  %.splatinsert47 = insertelement <8 x i64> poison, i64 %172, i64 0
  %.splat48 = shufflevector <8 x i64> %.splatinsert47, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load49 = load <8 x i64>, ptr %.spill, align 64
  %173 = add <8 x i64> %.splat48, %.spill.load49
  %.spill.load50 = load <8 x i64>, ptr %.spill4, align 64
  %174 = add <8 x i64> %.spill.load50, zeroinitializer
  %175 = add <8 x i64> zeroinitializer, %174
  %176 = add <8 x i64> zeroinitializer, %173
  %177 = mul <8 x i64> %175, splat (i64 768)
  %178 = add <8 x i64> %177, %176
  %179 = extractvalue { ptr, i64 } %15, 0
  %180 = extractelement <8 x i64> %178, i32 0
  %181 = sub i64 %180, 0
  %182 = mul i64 %181, 4
  %buffer.contiguous.address51 = getelementptr i8, ptr %179, i64 %182
  %buffer.contiguous.load52 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address51, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %.state54 = load i64, ptr %.slot7, align 4
  %.splatinsert55 = insertelement <8 x i64> poison, i64 %.state54, i64 0
  %.splat56 = shufflevector <8 x i64> %.splatinsert55, <8 x i64> poison, <8 x i32> zeroinitializer
  %185 = mul <8 x i64> %.splat56, splat (i64 32)
  %186 = add <8 x i64> %184, %185
  %187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %183, 0
  %188 = insertvalue { <8 x ptr>, <8 x i64> } %187, <8 x i64> %186, 1
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %188, 1
  %191 = extractelement <8 x ptr> %189, i32 0
  %192 = extractelement <8 x i64> %190, i32 0
  %193 = sub i64 %192, 0
  %194 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %195 = select i1 %194, i64 %193, i64 0
  %private.contiguous.address57 = getelementptr i8, ptr %191, i64 %195
  %private.contiguous.preserve58 = load <8 x float>, ptr %private.contiguous.address57, align 4
  %196 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load52, <8 x float> %private.contiguous.preserve58
  store <8 x float> %196, ptr %private.contiguous.address57, align 4
  %.state59 = load i64, ptr %.slot7, align 4
  %197 = add i64 %.state59, 1
  store i64 %197, ptr %.slot7, align 4
  br label %direct.schedule.9

direct.schedule.11:                               ; preds = %direct.false45
  store i64 0, ptr %.slot8, align 4
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.13, %direct.schedule.11
  %.state60 = load i64, ptr %.slot8, align 4
  %198 = icmp slt i64 %.state60, 96
  br i1 %198, label %direct.true61, label %direct.false62

direct.schedule.13:                               ; preds = %direct.true61
  %.state63 = load i64, ptr %.slot8, align 4
  %199 = mul i64 %.state63, 8
  %.splatinsert64 = insertelement <8 x i64> poison, i64 %199, i64 0
  %.splat65 = shufflevector <8 x i64> %.splatinsert64, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load66 = load <8 x i64>, ptr %.spill, align 64
  %200 = add <8 x i64> %.splat65, %.spill.load66
  %.spill.load67 = load <8 x i64>, ptr %.spill4, align 64
  %201 = add <8 x i64> %.spill.load67, zeroinitializer
  %202 = add <8 x i64> zeroinitializer, %201
  %203 = add <8 x i64> zeroinitializer, %200
  %204 = mul <8 x i64> %202, splat (i64 768)
  %205 = add <8 x i64> %204, %203
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %.state69 = load i64, ptr %.slot8, align 4
  %.splatinsert70 = insertelement <8 x i64> poison, i64 %.state69, i64 0
  %.splat71 = shufflevector <8 x i64> %.splatinsert70, <8 x i64> poison, <8 x i32> zeroinitializer
  %208 = mul <8 x i64> %.splat71, splat (i64 32)
  %209 = add <8 x i64> %207, %208
  %210 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %206, 0
  %211 = insertvalue { <8 x ptr>, <8 x i64> } %210, <8 x i64> %209, 1
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %211, 1
  %214 = extractelement <8 x ptr> %212, i32 0
  %215 = extractelement <8 x i64> %213, i32 0
  %216 = sub i64 %215, 0
  %217 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %218 = select i1 %217, i64 %216, i64 0
  %private.contiguous.address72 = getelementptr i8, ptr %214, i64 %218
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address72, align 4
  %219 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %220 = fmul <8 x float> splat (float 5.000000e-01), %219
  %221 = fmul <8 x float> splat (float 0x3FA6E4E260000000), %219
  %222 = fmul <8 x float> %221, %219
  %223 = fmul <8 x float> %222, %219
  %224 = fadd <8 x float> %219, %223
  %225 = fmul <8 x float> splat (float 0x3FE9884540000000), %224
  %226 = select <8 x i1> %51, <8 x float> %225, <8 x float> zeroinitializer
  %native.tanh73 = call <8 x float> @__luisa_cpu_native_tanh_f32_v8_precise(<8 x float> %226)
  %227 = fadd <8 x float> splat (float 1.000000e+00), %native.tanh73
  %228 = fmul <8 x float> %220, %227
  %tile_snapshot.spill.load74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 0
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 1
  %.state75 = load i64, ptr %.slot8, align 4
  %.splatinsert76 = insertelement <8 x i64> poison, i64 %.state75, i64 0
  %.splat77 = shufflevector <8 x i64> %.splatinsert76, <8 x i64> poison, <8 x i32> zeroinitializer
  %231 = mul <8 x i64> %.splat77, splat (i64 32)
  %232 = add <8 x i64> %230, %231
  %233 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %229, 0
  %234 = insertvalue { <8 x ptr>, <8 x i64> } %233, <8 x i64> %232, 1
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %234, 1
  %237 = extractelement <8 x ptr> %235, i32 0
  %238 = extractelement <8 x i64> %236, i32 0
  %239 = sub i64 %238, 0
  %240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %241 = select i1 %240, i64 %239, i64 0
  %private.contiguous.address78 = getelementptr i8, ptr %237, i64 %241
  %private.contiguous.load79 = load <8 x float>, ptr %private.contiguous.address78, align 4
  %242 = select <8 x i1> %51, <8 x float> %private.contiguous.load79, <8 x float> zeroinitializer
  %243 = fadd <8 x float> %228, %242
  %244 = extractvalue { ptr, i64 } %27, 0
  %245 = extractelement <8 x i64> %205, i32 0
  %246 = sub i64 %245, 0
  %247 = mul i64 %246, 4
  %buffer.contiguous.address80 = getelementptr i8, ptr %244, i64 %247
  call void @llvm.masked.store.v8f32.p0(<8 x float> %243, ptr align 1 %buffer.contiguous.address80, <8 x i1> %51)
  %.state81 = load i64, ptr %.slot8, align 4
  %248 = add i64 %.state81, 1
  store i64 %248, ptr %.slot8, align 4
  br label %direct.schedule.12

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.5

direct.true19:                                    ; preds = %direct.schedule.2
  br label %direct.schedule.3

direct.false20:                                   ; preds = %direct.schedule.2
  br label %direct.schedule.4

direct.true30:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false31:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true44:                                    ; preds = %direct.schedule.9
  br label %direct.schedule.10

direct.false45:                                   ; preds = %direct.schedule.9
  br label %direct.schedule.11

direct.true61:                                    ; preds = %direct.schedule.12
  br label %direct.schedule.13

direct.false62:                                   ; preds = %direct.schedule.12
  br label %direct.schedule.4
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

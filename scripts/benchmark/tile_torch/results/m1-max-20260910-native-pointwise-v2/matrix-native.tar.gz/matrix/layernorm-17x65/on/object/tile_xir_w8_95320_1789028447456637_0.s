	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #592
	ldr	x9, [x0]
	ldr	x13, [x0, #16]
	ldr	x10, [x0, #32]
	ldr	w8, [x1]
	ldr	w11, [x1, #36]
	add	w8, w11, w8, lsl #5
	lsr	w8, w8, #3
	fmov	s0, w8
	ushll.2d	v0, v0, #0
	fmov	x12, d0
	add	x8, x12, x12, lsl #6
	lsl	x11, x8, #2
	add	x8, x9, x11
	ldp	q6, q7, [x8]
	ldp	q17, q16, [x8, #32]
	ldp	q18, q19, [x8, #64]
	ldp	q29, q28, [x8, #96]
	ldp	q30, q31, [x8, #128]
	ldp	q8, q4, [x8, #160]
	ldp	q2, q3, [x8, #192]
	ldp	q1, q0, [x8, #224]
	add	x8, x11, #256
	ldr	s27, [x9, x8]
	fadd.4s	v5, v29, v1
	fadd.4s	v20, v28, v0
	fadd.4s	v21, v19, v3
	fadd.4s	v22, v18, v2
	fadd.4s	v23, v17, v8
	fadd.4s	v24, v16, v4
	fadd.4s	v25, v7, v31
	fadd.4s	v26, v6, v30
	fadd.4s	v9, v27, v26
	mov.s	v26[0], v9[0]
	fadd.4s	v24, v24, v25
	fadd.4s	v23, v23, v26
	fadd.4s	v22, v22, v23
	fadd.4s	v21, v21, v24
	fadd.4s	v20, v20, v21
	fadd.4s	v5, v5, v22
	rev64.4s	v21, v5
	rev64.4s	v22, v20
	fadd.4s	v20, v20, v22
	fadd.4s	v5, v5, v21
	dup.4s	v21, v5[2]
	dup.4s	v22, v20[2]
	ldr	x9, [x0, #48]
	fadd.4s	v20, v20, v22
	fadd.4s	v5, v5, v21
	fadd.4s	v20, v5, v20
	movi.2d	v5, #0000000000000000
	fadd	s20, s20, s5
	mov	w14, #1115815936                ; =0x42820000
	fmov	s26, w14
	fdiv	s20, s20, s26
	dup.4s	v9, v20[0]
	fsub.4s	v25, v6, v9
	fsub.4s	v24, v7, v9
	stp	q25, q24, [sp, #304]
	fsub.4s	v23, v17, v9
	fsub.4s	v22, v16, v9
	stp	q23, q22, [sp, #336]
	fsub.4s	v21, v18, v9
	fsub.4s	v20, v19, v9
	stp	q21, q20, [sp, #368]
	fsub.4s	v19, v29, v9
	fsub.4s	v18, v28, v9
	stp	q19, q18, [sp, #400]
	fsub.4s	v17, v30, v9
	fsub.4s	v16, v31, v9
	stp	q17, q16, [sp, #432]
	fsub.4s	v7, v8, v9
	fsub.4s	v6, v4, v9
	stp	q7, q6, [sp, #464]
	fsub.4s	v4, v2, v9
	fsub.4s	v3, v3, v9
	stp	q4, q3, [sp, #496]
	fsub.4s	v2, v1, v9
	fsub.4s	v1, v0, v9
	stp	q2, q1, [sp, #528]
	fsub.4s	v13, v27, v9
	str	q13, [sp, #560]
	ldp	q27, q28, [x13, #192]
	stp	q27, q28, [sp, #208]
	ldp	q27, q28, [x13, #224]
	stp	q27, q28, [sp, #240]
	ldp	q27, q28, [x13, #128]
	stp	q27, q28, [sp, #144]
	ldp	q27, q28, [x13, #160]
	stp	q27, q28, [sp, #176]
	ldp	q27, q28, [x13, #64]
	stp	q27, q28, [sp, #80]
	ldp	q27, q28, [x13, #96]
	stp	q27, q28, [sp, #112]
	ldp	q27, q28, [x13]
	stp	q27, q28, [sp, #16]
	ldp	q27, q28, [x13, #32]
	stp	q27, q28, [sp, #48]
	fmul.4s	v27, v25, v25
	fmul.4s	v28, v24, v24
	fmul.4s	v29, v22, v22
	fmul.4s	v30, v23, v23
	fmul.4s	v31, v21, v21
	fmul.4s	v8, v20, v20
	fmul.4s	v9, v18, v18
	fmul.4s	v10, v19, v19
	fmul.4s	v11, v1, v1
	fmul.4s	v12, v2, v2
	fadd.4s	v10, v10, v12
	fadd.4s	v9, v9, v11
	fmul.4s	v11, v4, v4
	fmul.4s	v12, v3, v3
	fadd.4s	v8, v8, v12
	fadd.4s	v31, v31, v11
	fmul.4s	v11, v6, v6
	fmul.4s	v12, v7, v7
	fadd.4s	v30, v30, v12
	fadd.4s	v29, v29, v11
	fmul.4s	v11, v17, v17
	fmul.4s	v12, v16, v16
	fadd.4s	v28, v28, v12
	fadd.4s	v27, v27, v11
	fmul.4s	v11, v13, v13
	fadd.4s	v11, v11, v27
	mov.s	v27[0], v11[0]
	fadd.4s	v28, v29, v28
	fadd.4s	v27, v30, v27
	fadd.4s	v27, v31, v27
	fadd.4s	v28, v8, v28
	fadd.4s	v28, v9, v28
	fadd.4s	v27, v10, v27
	rev64.4s	v29, v27
	rev64.4s	v30, v28
	fadd.4s	v28, v28, v30
	fadd.4s	v27, v27, v29
	dup.4s	v29, v27[2]
	dup.4s	v30, v28[2]
	fadd.4s	v28, v28, v30
	fadd.4s	v27, v27, v29
	fadd.4s	v27, v27, v28
	fadd	s5, s27, s5
	fdiv	s26, s5, s26
	ldr	s5, [x13, #256]
	str	q5, [sp, #272]
	mov	w13, #50604                     ; =0xc5ac
	movk	w13, #14119, lsl #16
	fmov	s27, w13
	fadd	s26, s26, s27
	fsqrt	s26, s26
	subs	x13, x9, x10
	cset	w14, hs
	cmp	x13, #259
	csel	w13, wzr, w14, ls
	subs	x14, x10, x9
	lsr	x14, x14, #2
	mov	w15, #1104                      ; =0x450
	ccmp	x14, x15, #0, hs
	b.hi	LBB0_3
; %bb.1:                                ; %prologue
	tbnz	w13, #0, LBB0_3
; %bb.2:                                ; %direct.true256.preheader
	ldp	q30, q10, [x10]
	ldp	q11, q12, [x10, #32]
	str	q13, [sp]                       ; 16-byte Spill
	ldp	q13, q14, [x10, #64]
	ldp	q8, q9, [x10, #96]
	ldp	q27, q28, [x10, #128]
	dup.4s	v26, v26[0]
	fdiv.4s	v25, v25, v26
	ldp	q29, q15, [sp, #16]
	fmul.4s	v25, v25, v29
	ldp	q29, q31, [x10, #160]
	fdiv.4s	v24, v24, v26
	fmul.4s	v24, v24, v15
	fadd.4s	v10, v24, v10
	fadd.4s	v15, v25, v30
	fdiv.4s	v23, v23, v26
	ldp	q25, q24, [sp, #48]
	fmul.4s	v23, v23, v25
	ldp	q25, q30, [x10, #192]
	fdiv.4s	v22, v22, v26
	fmul.4s	v22, v22, v24
	fadd.4s	v0, v22, v12
	ldp	q12, q24, [x10, #224]
	add	x11, x9, x11
	ldr	s22, [x10, #256]
	stp	q15, q10, [x11]
	fadd.4s	v23, v23, v11
	fdiv.4s	v21, v21, v26
	ldr	q10, [sp, #80]
	fmul.4s	v21, v21, v10
	ldr	q10, [sp, #96]
	fdiv.4s	v20, v20, v26
	fmul.4s	v20, v20, v10
	fadd.4s	v20, v20, v14
	fadd.4s	v21, v21, v13
	stp	q23, q0, [x11, #32]
	stp	q21, q20, [x11, #64]
	fdiv.4s	v0, v19, v26
	ldp	q20, q19, [sp, #112]
	fmul.4s	v0, v0, v20
	fdiv.4s	v18, v18, v26
	fmul.4s	v18, v18, v19
	fadd.4s	v18, v18, v9
	fadd.4s	v0, v0, v8
	fdiv.4s	v17, v17, v26
	ldp	q20, q19, [sp, #144]
	fmul.4s	v17, v17, v20
	fdiv.4s	v16, v16, v26
	fmul.4s	v16, v16, v19
	fadd.4s	v16, v16, v28
	stp	q0, q18, [x11, #96]
	fadd.4s	v0, v17, v27
	fdiv.4s	v7, v7, v26
	ldp	q18, q17, [sp, #176]
	fmul.4s	v7, v7, v18
	fdiv.4s	v6, v6, v26
	fmul.4s	v6, v6, v17
	fadd.4s	v6, v6, v31
	stp	q0, q16, [x11, #128]
	fadd.4s	v0, v7, v29
	fdiv.4s	v4, v4, v26
	ldr	q7, [sp, #208]
	fmul.4s	v4, v4, v7
	ldr	q7, [sp, #224]
	fdiv.4s	v3, v3, v26
	fmul.4s	v3, v3, v7
	fadd.4s	v3, v3, v30
	stp	q0, q6, [x11, #160]
	fadd.4s	v0, v4, v25
	fdiv.4s	v2, v2, v26
	ldp	q6, q4, [sp, #240]
	fmul.4s	v2, v2, v6
	fdiv.4s	v1, v1, v26
	fmul.4s	v1, v1, v4
	fadd.4s	v1, v1, v24
	stp	q0, q3, [x11, #192]
	fadd.4s	v2, v2, v12
	ldr	q0, [sp]                        ; 16-byte Reload
	fdiv.4s	v0, v0, v26
	fmul.4s	v0, v0, v5
	fadd.4s	v0, v0, v22
	stp	q2, q1, [x11, #224]
	b	LBB0_6
LBB0_3:                                 ; %direct.schedule.27.preheader
	mov	x14, #0                         ; =0x0
	dup.4s	v1, v26[0]
	mov	w11, #260                       ; =0x104
	umaddl	x11, w12, w11, x9
	movi.2d	v2, #0000000000000000
	add	x12, sp, #304
	add	x13, sp, #16
	mov	w15, #1                         ; =0x1
	dup.2d	v3, x15
	movi.2d	v4, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
LBB0_4:                                 ; %direct.true214
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x14, x14, #5
	add	x15, x12, x14
	ldp	q16, q0, [x15]
	fdiv.4s	v16, v16, v1
	fdiv.4s	v0, v0, v1
	add	x14, x13, x14
	ldp	q17, q18, [x14]
	fmul.4s	v0, v0, v18
	fmul.4s	v16, v16, v17
	fmov	x14, d2
	lsl	x14, x14, #5
	add	x15, x10, x14
	ldp	q18, q17, [x15]
	fadd.4s	v16, v16, v18
	fadd.4s	v0, v0, v17
	add	x14, x11, x14
	stp	q16, q0, [x14]
	add.2d	v6, v6, v3
	add.2d	v4, v4, v3
	add.2d	v7, v7, v3
	add.2d	v2, v2, v3
	fmov	x14, d2
	cmp	x14, #8
	b.lt	LBB0_4
; %bb.5:                                ; %direct.false215
	fdiv.4s	v0, v13, v1
	fmul.4s	v0, v0, v5
	ldr	s1, [x10, #256]
	fadd.4s	v0, v0, v1
LBB0_6:                                 ; %common.ret
	str	s0, [x9, x8]
	add	sp, sp, #592
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_11:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI1_12:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI1_13:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI1_14:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_15:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2848
	str	x0, [sp, #448]                  ; 8-byte Spill
	cbz	w3, LBB1_209
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x27, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	ldp	w9, w8, [x2, #44]
	str	w9, [sp, #444]                  ; 4-byte Spill
	str	w8, [sp, #440]                  ; 4-byte Spill
	add	x25, sp, #2560
	ldp	w24, w11, [x2]
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Spill
Lloh4:
	adrp	x8, lCPI1_2@PAGE
Lloh5:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Spill
	movi.2s	v8, #65
	ldp	w26, w8, [x2, #8]
	str	x8, [sp, #432]                  ; 8-byte Spill
	add	x19, sp, #2272
	add	x21, sp, #1984
	str	w3, [sp, #380]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w27, [sp, #380]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w24, #1
	ldr	w9, [sp, #444]                  ; 4-byte Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w24, wzr, w24, eq
	cinc	w9, w11, eq
	ldr	w10, [sp, #440]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w11, wzr, w9, ne
	add	w26, w26, w8
	add	w22, w22, #1
	cmp	w22, w27
	b.eq	LBB1_209
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_41 Depth 2
                                        ;     Child Loop BB1_43 Depth 2
                                        ;     Child Loop BB1_45 Depth 2
                                        ;     Child Loop BB1_48 Depth 2
                                        ;     Child Loop BB1_77 Depth 2
                                        ;     Child Loop BB1_162 Depth 2
                                        ;     Child Loop BB1_95 Depth 2
	ubfiz	x8, x24, #5, #32
	ldr	x12, [sp, #432]                 ; 8-byte Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w13, #32                        ; =0x20
	csel	x10, x10, x13, lo
	cmp	x12, x9
	stp	w24, w11, [x20]
	str	w11, [sp, #460]                 ; 4-byte Spill
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x12, #2, hi
	csel	x23, x10, xzr, ls
	cmp	x23, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x23, [sp, #448]                 ; 8-byte Reload
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	ldr	w11, [sp, #460]                 ; 4-byte Reload
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x27, x23, #3
	cbz	x27, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #448]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x27, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #448]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x27, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #448]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x27, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x28, [sp, #448]                 ; 8-byte Reload
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x28
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w23, #0x7
	ldr	w11, [sp, #460]                 ; 4-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v1, w8
	ldp	q0, q2, [sp, #32]               ; 32-byte Folded Reload
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	x8, [sp, #448]                  ; 8-byte Reload
	ldr	x9, [x8]
	ldr	x12, [x8, #16]
	ldr	x10, [x8, #32]
	ldr	x8, [x8, #48]
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v2, v3, v2
	addv.8h	h26, v2
	fmov	w13, s26
	and	w13, w13, #0xff
	str	w13, [sp, #168]                 ; 4-byte Spill
	ubfiz	w13, w24, #2, #27
	orr	w13, w13, w27
	dup.4s	v4, w13
	and.16b	v16, v1, v4
	and.16b	v4, v0, v4
	ushll2.2d	v5, v4, #0
	ushll2.2d	v6, v16, #0
	ushll.2d	v7, v4, #0
	ushll.2d	v17, v16, #0
	fmov	x13, d17
	mov	w14, #260                       ; =0x104
	umaddl	x13, w13, w14, x9
	fmov	w14, s26
	mov	w27, #4                         ; =0x4
	b	LBB1_15
LBB1_14:                                ; %else92
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x15, x25, x11
	stp	q4, q16, [x15]
	add	x11, x11, #32
	cmp	x11, #256
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x15, x13, x11
	add	x17, x25, x11
	ldr	q4, [x17]
	tbnz	w14, #0, LBB1_23
; %bb.16:                               ; %else72
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w16, w14, #0xff
	tbnz	w16, #1, LBB1_24
LBB1_17:                                ; %else74
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w16, #2, LBB1_25
LBB1_18:                                ; %else77
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w16, #3, LBB1_26
LBB1_19:                                ; %else80
                                        ;   in Loop: Header=BB1_15 Depth=2
	ldr	q16, [x17, #16]
	tbnz	w16, #4, LBB1_27
LBB1_20:                                ; %else83
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w16, #5, LBB1_28
LBB1_21:                                ; %else86
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w16, #6, LBB1_29
LBB1_22:                                ; %else89
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w16, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	ld1.s	{ v4 }[0], [x15]
	and	w16, w14, #0xff
	tbz	w16, #1, LBB1_17
LBB1_24:                                ; %cond.load73
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x0, x15, #4
	ld1.s	{ v4 }[1], [x0]
	tbz	w16, #2, LBB1_18
LBB1_25:                                ; %cond.load76
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x0, x15, #8
	ld1.s	{ v4 }[2], [x0]
	tbz	w16, #3, LBB1_19
LBB1_26:                                ; %cond.load79
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x0, x15, #12
	ld1.s	{ v4 }[3], [x0]
	ldr	q16, [x17, #16]
	tbz	w16, #4, LBB1_20
LBB1_27:                                ; %cond.load82
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x15, #16
	ld1.s	{ v16 }[0], [x17]
	tbz	w16, #5, LBB1_21
LBB1_28:                                ; %cond.load85
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x15, #20
	ld1.s	{ v16 }[1], [x17]
	tbz	w16, #6, LBB1_22
LBB1_29:                                ; %cond.load88
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x15, #24
	ld1.s	{ v16 }[2], [x17]
	tbz	w16, #7, LBB1_14
LBB1_30:                                ; %cond.load91
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x15, x15, #28
	ld1.s	{ v16 }[3], [x15]
	b	LBB1_14
LBB1_31:                                ; %direct.true77.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v27, v3
	sshll.2d	v3, v1, #0
	sshll.2d	v19, v0, #0
	sshll2.2d	v23, v1, #0
	sshll2.2d	v24, v0, #0
Lloh6:
	adrp	x11, lCPI1_6@PAGE
Lloh7:
	ldr	q4, [x11, lCPI1_6@PAGEOFF]
	and.16b	v16, v3, v4
Lloh8:
	adrp	x11, lCPI1_7@PAGE
Lloh9:
	ldr	q4, [x11, lCPI1_7@PAGEOFF]
	and.16b	v3, v3, v4
Lloh10:
	adrp	x11, lCPI1_8@PAGE
Lloh11:
	ldr	q4, [x11, lCPI1_8@PAGEOFF]
	and.16b	v18, v19, v4
Lloh12:
	adrp	x11, lCPI1_9@PAGE
Lloh13:
	ldr	q4, [x11, lCPI1_9@PAGEOFF]
	and.16b	v22, v23, v4
Lloh14:
	adrp	x11, lCPI1_10@PAGE
Lloh15:
	ldr	q20, [x11, lCPI1_10@PAGEOFF]
	movi.8b	v2, #1
	and.8b	v4, v27, v2
	umov.b	w11, v4[0]
	movi.2d	v4, #0000000000000000
	mov.b	v4[0], v27[0]
	and.16b	v25, v24, v20
	umaxv.8b	b20, v4
	fmov	w13, s20
	rbit	w14, w11
	clz	w14, w14
	tst	w13, #0x1
	csel	w16, w14, wzr, ne
	mov	w14, #64                        ; =0x40
	dup.2d	v20, x14
	orr.16b	v2, v16, v20
	xtn.2s	v21, v17
	str	q2, [sp, #224]                  ; 16-byte Spill
	umlal.2d	v2, v21, v8
	movi.2d	v17, #0000000000000000
	str	q27, [sp, #384]                 ; 16-byte Spill
	mov.b	v17[0], v27[0]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	str	q2, [sp, #320]                  ; 16-byte Spill
	and.16b	v17, v17, v2
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #1600]
	str	q2, [sp, #1584]
	str	q2, [sp, #1568]
	str	q17, [sp, #1552]
	ubfiz	x14, x16, #3, #3
	add	x15, sp, #1552
	ldr	x15, [x15, x14]
	sub	x15, x15, x16
	add	x9, x9, x15, lsl #2
	str	q25, [sp, #1664]
	str	q18, [sp, #1648]
	str	q22, [sp, #1632]
	str	q3, [sp, #1616]
	add	x15, sp, #1616
	ldr	x14, [x15, x14]
	orr	x14, x14, #0x100
	sub	x14, x14, w16, uxtw #2
	tst	w11, #0x1
	csel	x15, xzr, x14, eq
	add	x14, x25, x15
	ldp	q27, q25, [x14]
	tbnz	w13, #0, LBB1_137
; %bb.32:                               ; %else96
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #1, LBB1_138
LBB1_33:                                ; %else99
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #2, LBB1_139
LBB1_34:                                ; %else102
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #3, LBB1_140
LBB1_35:                                ; %else105
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #4, LBB1_141
LBB1_36:                                ; %else108
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #5, LBB1_142
LBB1_37:                                ; %else111
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #6, LBB1_143
LBB1_38:                                ; %else114
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q4, [sp, #416]                  ; 16-byte Spill
	str	q26, [sp, #352]                 ; 16-byte Spill
	tbz	w11, #7, LBB1_40
LBB1_39:                                ; %cond.load116
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v25 }[3], [x9]
LBB1_40:                                ; %else117
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q16, [sp, #400]                 ; 16-byte Spill
	str	x16, [sp, #344]                 ; 8-byte Spill
Lloh16:
	adrp	x9, lCPI1_3@PAGE
Lloh17:
	ldr	q17, [x9, lCPI1_3@PAGEOFF]
	and.16b	v2, v24, v17
Lloh18:
	adrp	x9, lCPI1_4@PAGE
Lloh19:
	ldr	q18, [x9, lCPI1_4@PAGEOFF]
	and.16b	v4, v23, v18
Lloh20:
	adrp	x9, lCPI1_5@PAGE
Lloh21:
	ldr	q22, [x9, lCPI1_5@PAGEOFF]
	and.16b	v16, v19, v22
	stp	q16, q4, [sp, #112]             ; 32-byte Folded Spill
	orr.16b	v16, v16, v20
	orr.16b	v17, v4, v20
	str	q2, [sp, #144]                  ; 16-byte Spill
	orr.16b	v4, v2, v20
	umull.2d	v2, v21, v8
	str	q2, [sp, #240]                  ; 16-byte Spill
	xtn.2s	v6, v6
	xtn.2s	v7, v7
	xtn.2s	v5, v5
	stp	q16, q4, [sp, #192]             ; 32-byte Folded Spill
	mov.16b	v2, v4
	umlal.2d	v2, v5, v8
	str	q2, [sp, #304]                  ; 16-byte Spill
	str	q17, [sp, #176]                 ; 16-byte Spill
	mov.16b	v2, v17
	umlal.2d	v2, v6, v8
	str	q2, [sp, #288]                  ; 16-byte Spill
	mov.16b	v2, v16
	umlal.2d	v2, v7, v8
	str	q2, [sp, #272]                  ; 16-byte Spill
	sshll.2d	v5, v1, #0
	sshll.2d	v6, v0, #0
	str	x15, [sp, #264]                 ; 8-byte Spill
	add	x9, x25, x15
	stp	q27, q25, [sp, #80]             ; 32-byte Folded Spill
	stp	q27, q25, [x9]
	fmov	x6, d3
	dup.2d	v3, x27
	and.16b	v26, v24, v3
	and.16b	v30, v23, v3
	and.16b	v31, v6, v3
	and.16b	v11, v5, v3
	fmov	x5, d11
	ldr	q5, [sp, #2656]
	ldr	q3, [sp, #2672]
	and.16b	v3, v0, v3
	and.16b	v5, v1, v5
	ldr	q6, [sp, #2624]
	ldr	q7, [sp, #2640]
	and.16b	v7, v0, v7
	and.16b	v6, v1, v6
	ldr	q21, [sp, #2592]
	ldr	q20, [sp, #2608]
	and.16b	v20, v0, v20
	and.16b	v21, v1, v21
	add	x9, x25, x6
	ldp	q22, q25, [x9]
	and.16b	v25, v0, v25
	mov	x9, x5
	and.16b	v8, v1, v22
	mov.16b	v9, v11
	mov.16b	v14, v30
	mov.16b	v15, v31
	mov.16b	v29, v26
LBB1_41:                                ; %direct.true77.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v10, v1, #0
	sshll.2d	v4, v0, #0
	add	x9, x25, x9, lsl #5
	ldp	q22, q27, [x9]
	fadd.4s	v22, v8, v22
	fadd.4s	v27, v25, v27
	ldp	q12, q16, [x9, #32]
	fadd.4s	v12, v21, v12
	fadd.4s	v16, v20, v16
	ldp	q17, q13, [x9, #64]
	fadd.4s	v17, v6, v17
	fadd.4s	v13, v7, v13
	ldp	q19, q18, [x9, #96]
	fadd.4s	v19, v5, v19
	fadd.4s	v18, v3, v18
	dup.2d	v28, x27
	and.16b	v2, v24, v28
	add.2d	v29, v29, v2
	and.16b	v2, v23, v28
	add.2d	v14, v14, v2
	and.16b	v2, v4, v28
	add.2d	v15, v15, v2
	and.16b	v2, v10, v28
	add.2d	v9, v9, v2
	bit.16b	v25, v27, v0
	bit.16b	v8, v22, v1
	bit.16b	v20, v16, v0
	bit.16b	v21, v12, v1
	bit.16b	v7, v13, v0
	bit.16b	v6, v17, v1
	bit.16b	v3, v18, v0
	bit.16b	v5, v19, v1
	fmov	x9, d9
	cmp	x9, #8
	b.lt	LBB1_41
; %bb.42:                               ; %direct.false78.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x7, #0                          ; =0x0
	ldp	q9, q29, [sp, #80]              ; 32-byte Folded Reload
	fadd.4s	v2, v29, v25
	fadd.4s	v4, v9, v8
	ldr	q25, [sp, #416]                 ; 16-byte Reload
	zip2.8b	v16, v25, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v2, v16, v2
	ldr	q28, [sp, #384]                 ; 16-byte Reload
	zip2.8b	v16, v28, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bit.16b	v2, v27, v16
	zip1.8b	v16, v25, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	movi.2d	v17, #0000000000000000
	mov.b	v17[2], v28[1]
	mov.b	v17[4], v28[2]
	and.16b	v4, v16, v4
	mov.b	v17[6], v28[3]
	ushll.4s	v16, v17, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bit.16b	v4, v22, v16
	fadd.4s	v4, v21, v4
	fadd.4s	v2, v20, v2
	fadd.4s	v2, v7, v2
	fadd.4s	v4, v6, v4
	fadd.4s	v5, v5, v4
	fadd.4s	v6, v3, v2
	ldr	q2, [sp, #400]                  ; 16-byte Reload
	ldp	q4, q3, [sp, #112]              ; 32-byte Folded Reload
	uzp1.4s	v3, v2, v3
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	uzp1.4s	v7, v4, v2
	movi.4s	v4, #1
	eor.16b	v2, v3, v4
	mov.s	w11, v2[1]
	eor.16b	v20, v7, v4
	mov.s	w14, v2[2]
	mov.s	w16, v2[3]
	fmov	w9, s2
	add	x13, sp, #1192
	bfxil	x13, x9, #0, #3
	str	d28, [sp, #1192]
	ldrb	w15, [x13]
	umov.b	w13, v28[0]
	and	x9, x9, #0x7
	str	q6, [sp, #1408]
	str	q5, [sp, #1392]
	add	x17, sp, #1392
	ldr	s2, [x17, x9, lsl #2]
	ands	w9, w13, #0x1
	tst	w9, w15
	movi.2d	v22, #0000000000000000
	fcsel	s17, s2, s22, ne
	and	x15, x11, #0x7
	add	x17, sp, #1192
	bfxil	x17, x11, #0, #3
	ldrb	w11, [x17]
	umov.b	w17, v28[1]
	str	q6, [sp, #1376]
	str	q5, [sp, #1360]
	add	x0, sp, #1360
	ldr	s2, [x0, x15, lsl #2]
	and	w11, w17, w11
	tst	w11, #0x1
	fcsel	s18, s2, s22, ne
	and	x11, x14, #0x7
	add	x15, sp, #1192
	bfxil	x15, x14, #0, #3
	ldrb	w14, [x15]
	umov.b	w15, v28[2]
	and	w14, w15, w14
	str	q6, [sp, #1344]
	str	q5, [sp, #1328]
	add	x0, sp, #1328
	ldr	s2, [x0, x11, lsl #2]
	tst	w14, #0x1
	fcsel	s19, s2, s22, ne
	and	x11, x16, #0x7
	add	x14, sp, #1192
	bfxil	x14, x16, #0, #3
	ldrb	w14, [x14]
	umov.b	w16, v28[3]
	and	w14, w16, w14
	str	q6, [sp, #1312]
	str	q5, [sp, #1296]
	add	x0, sp, #1296
	ldr	s2, [x0, x11, lsl #2]
	tst	w14, #0x1
	mov.s	w11, v20[1]
	fcsel	s21, s2, s22, ne
	mov.s	w14, v20[2]
	mov.s	w0, v20[3]
	fmov	w1, s20
	and	x2, x1, #0x7
	add	x3, sp, #1192
	bfxil	x3, x1, #0, #3
	ldrb	w1, [x3]
	umov.b	w3, v28[4]
	and	w1, w3, w1
	str	q6, [sp, #1536]
	str	q5, [sp, #1520]
	add	x4, sp, #1520
	ldr	s2, [x4, x2, lsl #2]
	tst	w1, #0x1
	fcsel	s2, s2, s22, ne
	and	x1, x11, #0x7
	add	x4, sp, #1192
	bfxil	x4, x11, #0, #3
	umov.b	w2, v28[5]
	ldrb	w11, [x4]
	and	w11, w2, w11
	str	q6, [sp, #1504]
	str	q5, [sp, #1488]
	add	x4, sp, #1488
	ldr	s4, [x4, x1, lsl #2]
	tst	w11, #0x1
	fcsel	s4, s4, s22, ne
	and	x11, x14, #0x7
	add	x1, sp, #1192
	bfxil	x1, x14, #0, #3
	ldrb	w14, [x1]
	umov.b	w1, v28[6]
	str	q6, [sp, #1472]
	str	q5, [sp, #1456]
	add	x4, sp, #1456
	ldr	s16, [x4, x11, lsl #2]
	and	w11, w1, w14
	tst	w11, #0x1
	fcsel	s16, s16, s22, ne
	and	x11, x0, #0x7
	add	x14, sp, #1192
	bfxil	x14, x0, #0, #3
	ldrb	w14, [x14]
	umov.b	w4, v28[7]
	and	w14, w4, w14
	str	q6, [sp, #1440]
	str	q5, [sp, #1424]
	add	x0, sp, #1424
	ldr	s20, [x0, x11, lsl #2]
	tst	w14, #0x1
	fcsel	s20, s20, s22, ne
	mov.s	v2[1], v4[0]
	mov.s	v2[2], v16[0]
	mov.s	v2[3], v20[0]
	mov.s	v17[1], v18[0]
	mov.s	v17[2], v19[0]
	mov.s	v17[3], v21[0]
	fadd.4s	v4, v5, v17
	fadd.4s	v2, v6, v2
	movi.4s	v6, #2
	eor.16b	v5, v7, v6
	eor.16b	v3, v3, v6
	fmov	w11, s3
	add	x14, sp, #1192
	bfxil	x14, x11, #0, #3
	ldrb	w14, [x14]
	and	x11, x11, #0x7
	str	q2, [sp, #1280]
	str	q4, [sp, #1264]
	add	x0, sp, #1264
	ldr	s3, [x0, x11, lsl #2]
	tst	w9, w14
	fcsel	s3, s3, s22, ne
	fmov	w9, s5
	and	x11, x9, #0x7
	add	x14, sp, #1192
	bfxil	x14, x9, #0, #3
	ldrb	w9, [x14]
	and	w9, w3, w9
	str	q2, [sp, #1248]
	str	q4, [sp, #1232]
	add	x14, sp, #1232
	ldr	s5, [x14, x11, lsl #2]
	tst	w9, #0x1
	fcsel	s5, s5, s22, ne
	fadd.4s	v2, v2, v5
	and	w0, w13, w3
	tst	w0, #0x1
	fcsel	s2, s2, s22, ne
	ands	w14, w13, #0x1
	fadd.4s	v3, v4, v3
	fadd	s2, s3, s2
	fcsel	s3, s2, s22, ne
	tst	w0, #0x1
	and	w11, w17, w13
	fcsel	s4, s2, s22, ne
	and	w9, w17, w13
	str	w9, [sp, #144]                  ; 4-byte Spill
	tst	w11, #0x1
	and	w11, w15, w13
	fcsel	s5, s2, s22, ne
	and	w9, w15, w13
	str	w9, [sp, #112]                  ; 4-byte Spill
	tst	w11, #0x1
	and	w30, w16, w13
	fcsel	s6, s2, s22, ne
	tst	w30, #0x1
	fcsel	s7, s2, s22, ne
	and	w9, w2, w13
	tst	w9, #0x1
	fcsel	s16, s2, s22, ne
	and	w11, w1, w13
	tst	w11, #0x1
	fcsel	s17, s2, s22, ne
	and	w23, w4, w13
	and	w28, w4, w13
	str	w28, [sp, #128]                 ; 4-byte Spill
	tst	w23, #0x1
	fcsel	s2, s2, s22, ne
	mov.s	v3[1], v5[0]
	mov.s	v3[2], v6[0]
	mov.s	v3[3], v7[0]
	mov.s	v4[1], v16[0]
	mov.s	v4[2], v17[0]
	mov.s	v4[3], v2[0]
	ldr	w23, [sp, #168]                 ; 4-byte Reload
	rbit	w23, w23
	clz	w23, w23
	str	q4, [sp, #1216]
	str	q3, [sp, #1200]
	str	x23, [sp, #168]                 ; 8-byte Spill
	and	x23, x23, #0x7
	add	x28, sp, #1200
	ldr	s2, [x28, x23, lsl #2]
	mov.b	v28[0], wzr
	str	q28, [sp, #64]                  ; 16-byte Spill
	fadd	s2, s2, s22
	mov	w23, #1115815936                ; =0x42820000
	fmov	s3, w23
	fdiv	s2, s2, s3
	dup.4s	v3, v2[0]
	mov	w23, #1                         ; =0x1
	dup.2d	v2, x23
	ushll2.2d	v4, v0, #0
	and.16b	v18, v4, v2
	ushll2.2d	v4, v1, #0
	and.16b	v19, v4, v2
	ushll.2d	v4, v0, #0
	and.16b	v20, v4, v2
	ushll.2d	v4, v1, #0
	and.16b	v21, v4, v2
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB1_43:                                ; %direct.true112.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x7, x7, #5
	add	x23, x25, x7
	ldp	q4, q2, [x23]
	fsub.4s	v4, v4, v3
	fsub.4s	v2, v2, v3
	add	x7, x19, x7
	ldp	q16, q22, [x7]
	bif.16b	v2, v22, v0
	bif.16b	v4, v16, v1
	stp	q4, q2, [x7]
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v17, v17, v18
	add.2d	v5, v5, v21
	fmov	x7, d5
	cmp	x7, #8
	b.lt	LBB1_43
; %bb.44:                               ; %direct.true149.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fsub.4s	v5, v9, v3
	fsub.4s	v6, v29, v3
	ldr	x28, [sp, #264]                 ; 8-byte Reload
	add	x7, x19, x28
	ldp	q2, q3, [x7]
	zip2.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	stp	q6, q5, [sp, #80]               ; 32-byte Folded Spill
	bit.16b	v3, v6, v4
	zip1.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v2, v5, v4
	stp	q2, q3, [x7]
	ldr	q2, [sp, #2384]
	ldr	q3, [sp, #2368]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v12, v0, v2
	and.16b	v15, v1, v3
	ldr	q2, [sp, #2352]
	ldr	q3, [sp, #2336]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v17, v0, v2
	and.16b	v9, v1, v3
	ldr	q2, [sp, #2320]
	ldr	q3, [sp, #2304]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v5, v0, v2
	and.16b	v6, v1, v3
	add	x6, x19, x6
	ldp	q3, q2, [x6]
	fmul.4s	v4, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v3, v0, v2
	and.16b	v7, v1, v4
LBB1_45:                                ; %direct.true149.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v1, #0
	sshll.2d	v4, v0, #0
	add	x5, x19, x5, lsl #5
	ldp	q22, q16, [x5]
	and.16b	v22, v1, v22
	and.16b	v16, v0, v16
	fmul.4s	v16, v16, v16
	fmul.4s	v22, v22, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v25, v3, v16
	ldp	q27, q16, [x5, #32]
	and.16b	v27, v1, v27
	and.16b	v16, v0, v16
	fmul.4s	v16, v16, v16
	fmul.4s	v27, v27, v27
	fadd.4s	v27, v6, v27
	fadd.4s	v16, v5, v16
	ldp	q29, q28, [x5, #64]
	and.16b	v29, v1, v29
	and.16b	v28, v0, v28
	fmul.4s	v28, v28, v28
	fmul.4s	v29, v29, v29
	fadd.4s	v29, v9, v29
	fadd.4s	v28, v17, v28
	ldp	q13, q10, [x5, #96]
	and.16b	v13, v1, v13
	and.16b	v10, v0, v10
	fmul.4s	v10, v10, v10
	fmul.4s	v13, v13, v13
	fadd.4s	v13, v15, v13
	fadd.4s	v10, v12, v10
	dup.2d	v8, x27
	and.16b	v14, v24, v8
	add.2d	v26, v26, v14
	and.16b	v14, v23, v8
	add.2d	v30, v30, v14
	and.16b	v4, v4, v8
	add.2d	v31, v31, v4
	and.16b	v2, v2, v8
	add.2d	v11, v11, v2
	bit.16b	v3, v25, v0
	bit.16b	v7, v22, v1
	bit.16b	v5, v16, v0
	bit.16b	v6, v27, v1
	bit.16b	v17, v28, v0
	bit.16b	v9, v29, v1
	bit.16b	v12, v10, v0
	bit.16b	v15, v13, v1
	fmov	x5, d11
	cmp	x5, #8
	b.lt	LBB1_45
; %bb.46:                               ; %direct.true186.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x5, #0                          ; =0x0
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2s	v8, #65
	add	x27, sp, #1696
	ldr	q10, [sp, #352]                 ; 16-byte Reload
	ldr	q13, [sp, #416]                 ; 16-byte Reload
	b	LBB1_48
LBB1_47:                                ; %else142
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x5, x21, x5
	stp	q31, q11, [x5]
	add.2d	v24, v24, v19
	add.2d	v29, v29, v20
	add.2d	v30, v30, v18
	add.2d	v23, v23, v21
	fmov	x5, d23
	cmp	x5, #8
	b.ge	LBB1_64
LBB1_48:                                ; %direct.true186.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w7, s10
	lsl	x5, x5, #5
	add	x6, x12, x5
	add	x23, x21, x5
	ldp	q31, q11, [x23]
	tbnz	w7, #0, LBB1_56
; %bb.49:                               ; %else121
                                        ;   in Loop: Header=BB1_48 Depth=2
	and	w7, w7, #0xff
	tbnz	w7, #1, LBB1_57
LBB1_50:                                ; %else124
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w7, #2, LBB1_58
LBB1_51:                                ; %else127
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w7, #3, LBB1_59
LBB1_52:                                ; %else130
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w7, #4, LBB1_60
LBB1_53:                                ; %else133
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w7, #5, LBB1_61
LBB1_54:                                ; %else136
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w7, #6, LBB1_62
LBB1_55:                                ; %else139
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbz	w7, #7, LBB1_47
	b	LBB1_63
LBB1_56:                                ; %cond.load120
                                        ;   in Loop: Header=BB1_48 Depth=2
	ld1.s	{ v31 }[0], [x6]
	and	w7, w7, #0xff
	tbz	w7, #1, LBB1_50
LBB1_57:                                ; %cond.load123
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #4
	ld1.s	{ v31 }[1], [x23]
	tbz	w7, #2, LBB1_51
LBB1_58:                                ; %cond.load126
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #8
	ld1.s	{ v31 }[2], [x23]
	tbz	w7, #3, LBB1_52
LBB1_59:                                ; %cond.load129
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #12
	ld1.s	{ v31 }[3], [x23]
	tbz	w7, #4, LBB1_53
LBB1_60:                                ; %cond.load132
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #16
	ld1.s	{ v11 }[0], [x23]
	tbz	w7, #5, LBB1_54
LBB1_61:                                ; %cond.load135
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #20
	ld1.s	{ v11 }[1], [x23]
	tbz	w7, #6, LBB1_55
LBB1_62:                                ; %cond.load138
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x23, x6, #24
	ld1.s	{ v11 }[2], [x23]
	tbz	w7, #7, LBB1_47
LBB1_63:                                ; %cond.load141
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x6, x6, #28
	ld1.s	{ v11 }[3], [x6]
	b	LBB1_47
LBB1_64:                                ; %direct.false187.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
Lloh22:
	adrp	x5, lCPI1_11@PAGE
Lloh23:
	ldr	q2, [x5, lCPI1_11@PAGEOFF]
	and.16b	v30, v0, v2
Lloh24:
	adrp	x5, lCPI1_12@PAGE
Lloh25:
	ldr	q2, [x5, lCPI1_12@PAGEOFF]
	and.16b	v31, v1, v2
Lloh26:
	adrp	x5, lCPI1_14@PAGE
Lloh27:
	ldr	q2, [x5, lCPI1_14@PAGEOFF]
	and.16b	v29, v1, v2
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldp	q4, q16, [sp, #80]              ; 32-byte Folded Reload
	and.16b	v23, v2, v4
	zip1.8b	v4, v13, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v24, v4, v16
	fmul.4s	v16, v24, v24
	fmul.4s	v26, v23, v23
	fadd.4s	v3, v26, v3
	fadd.4s	v7, v16, v7
	and.16b	v4, v4, v7
	and.16b	v2, v2, v3
	ldr	q7, [sp, #64]                   ; 16-byte Reload
	zip2.8b	v3, v7, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v2, v25, v3
	zip1.8b	v3, v7, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v22, v4
	fadd.4s	v3, v6, v3
	fadd.4s	v2, v5, v2
	fadd.4s	v2, v17, v2
	fadd.4s	v3, v9, v3
	fadd.4s	v3, v15, v3
	fadd.4s	v5, v12, v2
	fmov	w5, s31
	add	x6, sp, #536
	bfxil	x6, x5, #0, #3
	ldr	q2, [sp, #384]                  ; 16-byte Reload
	str	d2, [sp, #536]
	ldrb	w6, [x6]
	add	x7, sp, #1152
	orr	x5, x7, x5, lsl #2
	str	q5, [sp, #1168]
	str	q3, [sp, #1152]
	ldr	s2, [x5]
	tst	w14, w6
	movi.2d	v27, #0000000000000000
	fcsel	s6, s2, s27, ne
	mov.s	w5, v31[1]
	add	x6, sp, #536
	bfxil	x6, x5, #0, #3
	ldrb	w5, [x6]
	and	w5, w17, w5
	str	q3, [sp, #1120]
	ldr	s2, [sp, #1120]
	tst	w5, #0x1
	mov.s	w5, v31[2]
	fcsel	s7, s2, s27, ne
	add	x6, sp, #536
	bfxil	x6, x5, #0, #3
	add	x7, sp, #1088
	orr	x5, x7, x5, lsl #2
	ldrb	w6, [x6]
	and	w6, w15, w6
	str	q5, [sp, #1104]
	str	q3, [sp, #1088]
	ldr	s2, [x5]
	tst	w6, #0x1
	mov.s	w5, v31[3]
	fcsel	s17, s2, s27, ne
	add	x6, sp, #536
	bfxil	x6, x5, #0, #3
	add	x7, sp, #1056
	orr	x5, x7, x5, lsl #2
	ldrb	w6, [x6]
	and	w6, w16, w6
	str	q5, [sp, #1072]
	str	q3, [sp, #1056]
	ldr	s2, [x5]
	tst	w6, #0x1
	fcsel	s22, s2, s27, ne
	fmov	w5, s30
	add	x6, sp, #536
	bfxil	x6, x5, #0, #3
	ldrb	w6, [x6]
	and	w6, w3, w6
	str	q5, [sp, #1040]
	str	q3, [sp, #1024]
	add	x7, sp, #1024
	ldr	s2, [x7, w5, uxtw #2]
	tst	w6, #0x1
	fcsel	s2, s2, s27, ne
	mov.s	w5, v30[1]
	add	x6, sp, #536
	bfxil	x6, x5, #0, #3
	ldrb	w6, [x6]
	and	w6, w2, w6
	stp	q3, q5, [sp, #992]
	add	x7, sp, #992
	ldr	s4, [x7, w5, uxtw #2]
	tst	w6, #0x1
	fcsel	s4, s4, s27, ne
	mov.s	w5, v30[2]
	add	x6, sp, #536
	bfxil	x6, x5, #0, #3
	ldrb	w6, [x6]
	and	w6, w1, w6
	stp	q3, q5, [sp, #960]
	add	x7, sp, #960
	ldr	s16, [x7, w5, uxtw #2]
	tst	w6, #0x1
	fcsel	s16, s16, s27, ne
	mov.s	w5, v30[3]
	add	x6, sp, #536
	bfxil	x6, x5, #0, #3
	ldrb	w6, [x6]
	and	w6, w4, w6
	stp	q3, q5, [sp, #928]
	add	x7, sp, #928
	ldr	s25, [x7, w5, uxtw #2]
	tst	w6, #0x1
	fcsel	s25, s25, s27, ne
	mov.s	v2[1], v4[0]
	mov.s	v2[2], v16[0]
	mov.s	v2[3], v25[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v22[0]
	fadd.4s	v3, v3, v6
	fadd.4s	v5, v5, v2
	fmov	w5, s29
	add	x6, sp, #536
	bfxil	x6, x5, #0, #3
	ldrb	w6, [x6]
	add	x7, sp, #896
	orr	x5, x7, x5, lsl #2
	stp	q3, q5, [sp, #896]
	ldr	s2, [x5]
	tst	w14, w6
	mov.s	w5, v29[1]
	add	x6, sp, #536
	bfxil	x6, x5, #0, #3
	ldrb	w6, [x6]
	and	w17, w17, w6
	fcsel	s6, s2, s27, ne
	add	x6, sp, #864
	orr	x5, x6, x5, lsl #2
	stp	q3, q5, [sp, #864]
	ldr	s2, [x5]
	tst	w17, #0x1
	mov.s	w17, v29[2]
	add	x5, sp, #536
	bfxil	x5, x17, #0, #3
	fcsel	s7, s2, s27, ne
	ldrb	w17, [x5]
	and	w15, w15, w17
	str	q3, [sp, #832]
	tst	w15, #0x1
	mov.s	w15, v29[3]
	add	x17, sp, #536
	bfxil	x17, x15, #0, #3
	ldrb	w17, [x17]
	and	w16, w16, w17
Lloh28:
	adrp	x17, lCPI1_13@PAGE
Lloh29:
	ldr	q2, [x17, lCPI1_13@PAGEOFF]
	and.16b	v2, v0, v2
	ldr	s4, [sp, #832]
	fcsel	s17, s4, s27, ne
	add	x17, sp, #800
	orr	x15, x17, x15, lsl #2
	stp	q3, q5, [sp, #800]
	ldr	s4, [x15]
	tst	w16, #0x1
	fmov	w15, s2
	add	x16, sp, #536
	bfxil	x16, x15, #0, #3
	ldrb	w16, [x16]
	stp	q3, q5, [sp, #768]
	add	x17, sp, #768
	ldr	s16, [x17, w15, uxtw #2]
	fcsel	s22, s4, s27, ne
	and	w15, w3, w16
	tst	w15, #0x1
	mov.s	w15, v2[1]
	add	x16, sp, #536
	bfxil	x16, x15, #0, #3
	ldrb	w16, [x16]
	stp	q3, q5, [sp, #736]
	add	x17, sp, #736
	ldr	s4, [x17, w15, uxtw #2]
	fcsel	s25, s16, s27, ne
	and	w15, w2, w16
	tst	w15, #0x1
	mov.s	w15, v2[2]
	add	x16, sp, #536
	bfxil	x16, x15, #0, #3
	ldrb	w16, [x16]
	stp	q3, q5, [sp, #704]
	add	x17, sp, #704
	ldr	s16, [x17, w15, uxtw #2]
	fcsel	s4, s4, s27, ne
	and	w15, w1, w16
	tst	w15, #0x1
	mov.s	w15, v2[3]
	add	x16, sp, #536
	bfxil	x16, x15, #0, #3
	ldrb	w16, [x16]
	and	w16, w4, w16
	movi.4s	v2, #4
	and.16b	v2, v1, v2
	fcsel	s16, s16, s27, ne
	stp	q3, q5, [sp, #672]
	add	x17, sp, #672
	ldr	s26, [x17, w15, uxtw #2]
	tst	w16, #0x1
	fcsel	s26, s26, s27, ne
	fmov	w15, s2
	add	x16, sp, #536
	orr	x16, x16, x15
	ldrb	w16, [x16]
	tst	w14, w16
	mov.s	v25[1], v4[0]
	mov.s	v25[2], v16[0]
	mov.s	v25[3], v26[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v22[0]
	fadd.4s	v2, v3, v6
	fadd.4s	v3, v5, v25
	stp	q2, q3, [sp, #640]
	add	x14, sp, #640
	ldr	s3, [x14, w15, uxtw #2]
	fcsel	s3, s3, s27, ne
	tst	w13, #0x1
	fadd	s2, s2, s3
	fcsel	s3, s2, s27, ne
	ldr	w13, [sp, #144]                 ; 4-byte Reload
	tst	w13, #0x1
	fcsel	s4, s2, s27, ne
	ldr	w13, [sp, #112]                 ; 4-byte Reload
	tst	w13, #0x1
	fcsel	s5, s2, s27, ne
	tst	w30, #0x1
	fcsel	s6, s2, s27, ne
	tst	w0, #0x1
	fcsel	s7, s2, s27, ne
	tst	w9, #0x1
	fcsel	s16, s2, s27, ne
	tst	w11, #0x1
Lloh30:
	adrp	x9, lCPI1_15@PAGE
Lloh31:
	ldr	d17, [x9, lCPI1_15@PAGEOFF]
	shl.8b	v22, v13, #7
	cmlt.8b	v22, v22, #0
	and.8b	v17, v22, v17
	fcsel	s22, s2, s27, ne
	ldr	w9, [sp, #128]                  ; 4-byte Reload
	tst	w9, #0x1
	movi.2d	v26, #0000000000000000
	fcsel	s2, s2, s27, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v5[0]
	mov.s	v3[3], v6[0]
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v22[0]
	mov.s	v7[3], v2[0]
	addv.8b	b28, v17
	stp	q3, q7, [sp, #608]
	ldr	x9, [sp, #168]                  ; 8-byte Reload
	and	x9, x9, #0x7
	add	x11, sp, #608
	ldr	s3, [x11, x9, lsl #2]
	fmov	w11, s28
	mov	b2, v13[0]
	mov.b	v2[4], v13[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	ldr	q4, [sp, #224]                  ; 16-byte Reload
	and.16b	v2, v2, v4
	mov	b4, v13[2]
	mov.b	v4[4], v13[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldp	q5, q7, [sp, #176]              ; 32-byte Folded Reload
	and.16b	v4, v4, v5
	mov	b5, v13[4]
	mov.b	v5[4], v13[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	mov	b6, v13[6]
	mov.b	v6[4], v13[7]
	and.16b	v5, v5, v7
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldr	q7, [sp, #208]                  ; 16-byte Reload
	and.16b	v6, v6, v7
	stp	q5, q6, [sp, #576]
	stp	q2, q4, [sp, #544]
	add	x9, x21, x28
	ldp	q25, q22, [x9]
	ldr	x16, [sp, #344]                 ; 8-byte Reload
	and	x9, x16, #0x7
	add	x13, sp, #544
	ldr	x9, [x13, x9, lsl #3]
	sub	x9, x9, x16
	lsl	x9, x9, #2
	add	x12, x12, x9
	tbnz	w11, #0, LBB1_144
; %bb.65:                               ; %else146
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q16, [sp, #400]                 ; 16-byte Reload
	tbnz	w11, #1, LBB1_145
LBB1_66:                                ; %else149
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #2, LBB1_146
LBB1_67:                                ; %else152
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #3, LBB1_147
LBB1_68:                                ; %else155
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #4, LBB1_148
LBB1_69:                                ; %else158
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #5, LBB1_149
LBB1_70:                                ; %else161
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #6, LBB1_150
LBB1_71:                                ; %else164
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w11, #7, LBB1_73
LBB1_72:                                ; %cond.load166
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x12, #28
	ld1.s	{ v22 }[3], [x11]
LBB1_73:                                ; %else167
                                        ;   in Loop: Header=BB1_4 Depth=1
	fadd	s2, s3, s26
	mov	w11, #1115815936                ; =0x42820000
	fmov	s3, w11
	fdiv	s2, s2, s3
	add	x11, x21, x28
	stp	q25, q22, [x11]
	mov	w11, #50604                     ; =0xc5ac
	movk	w11, #14119, lsl #16
	fmov	s3, w11
	fadd	s2, s2, s3
	fsqrt	s5, s2
	subs	x11, x8, x10
	cset	w12, hs
	cmp	x11, #259
	csel	w11, wzr, w12, ls
	subs	x12, x10, x8
	lsr	x12, x12, #2
	mov	w13, #1104                      ; =0x450
	ccmp	x12, x13, #0, hs
	b.hi	LBB1_93
; %bb.74:                               ; %else167
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #0, LBB1_93
; %bb.75:                               ; %direct.true256.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	movi.2d	v3, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	b	LBB1_77
LBB1_76:                                ; %else259
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x11, x27, x11
	stp	q17, q26, [x11]
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v16, v16, v18
	add.2d	v3, v3, v21
	fmov	x11, d3
	cmp	x11, #8
	b.ge	LBB1_151
LBB1_77:                                ; %direct.true256.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s10
	lsl	x11, x11, #5
	add	x12, x10, x11
	add	x14, x27, x11
	ldr	q17, [x14]
	tbnz	w13, #0, LBB1_85
; %bb.78:                               ; %else238
                                        ;   in Loop: Header=BB1_77 Depth=2
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_86
LBB1_79:                                ; %else241
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w13, #2, LBB1_87
LBB1_80:                                ; %else244
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w13, #3, LBB1_88
LBB1_81:                                ; %else247
                                        ;   in Loop: Header=BB1_77 Depth=2
	ldr	q26, [x14, #16]
	tbnz	w13, #4, LBB1_89
LBB1_82:                                ; %else250
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w13, #5, LBB1_90
LBB1_83:                                ; %else253
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w13, #6, LBB1_91
LBB1_84:                                ; %else256
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbz	w13, #7, LBB1_76
	b	LBB1_92
LBB1_85:                                ; %cond.load237
                                        ;   in Loop: Header=BB1_77 Depth=2
	ld1.s	{ v17 }[0], [x12]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_79
LBB1_86:                                ; %cond.load240
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x15, x12, #4
	ld1.s	{ v17 }[1], [x15]
	tbz	w13, #2, LBB1_80
LBB1_87:                                ; %cond.load243
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x15, x12, #8
	ld1.s	{ v17 }[2], [x15]
	tbz	w13, #3, LBB1_81
LBB1_88:                                ; %cond.load246
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x15, x12, #12
	ld1.s	{ v17 }[3], [x15]
	ldr	q26, [x14, #16]
	tbz	w13, #4, LBB1_82
LBB1_89:                                ; %cond.load249
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x14, x12, #16
	ld1.s	{ v26 }[0], [x14]
	tbz	w13, #5, LBB1_83
LBB1_90:                                ; %cond.load252
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x14, x12, #20
	ld1.s	{ v26 }[1], [x14]
	tbz	w13, #6, LBB1_84
LBB1_91:                                ; %cond.load255
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x14, x12, #24
	ld1.s	{ v26 }[2], [x14]
	tbz	w13, #7, LBB1_76
LBB1_92:                                ; %cond.load258
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x12, x12, #28
	ld1.s	{ v26 }[3], [x12]
	b	LBB1_76
LBB1_93:                                ; %direct.schedule.27.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	ldr	q2, [sp, #240]                  ; 16-byte Reload
	add.2d	v3, v2, v16
	dup.4s	v17, v5[0]
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v26, #0000000000000000
	b	LBB1_95
LBB1_94:                                ; %else210
                                        ;   in Loop: Header=BB1_95 Depth=2
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v26, v26, v18
	add.2d	v5, v5, v21
	fmov	x11, d5
	cmp	x11, #8
	b.ge	LBB1_127
LBB1_95:                                ; %direct.true214.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s10
	shl.2d	v29, v5, #3
	orr.16b	v2, v29, v16
	fmov	x12, d2
	add	x12, x10, x12, lsl #2
	movi.2d	v30, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w13, #0, LBB1_112
; %bb.96:                               ; %else171
                                        ;   in Loop: Header=BB1_95 Depth=2
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_113
LBB1_97:                                ; %else174
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w13, #2, LBB1_114
LBB1_98:                                ; %else177
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w13, #3, LBB1_115
LBB1_99:                                ; %else180
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w13, #4, LBB1_116
LBB1_100:                               ; %else183
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w13, #5, LBB1_117
LBB1_101:                               ; %else186
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w13, #6, LBB1_118
LBB1_102:                               ; %else189
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbz	w13, #7, LBB1_104
LBB1_103:                               ; %cond.load191
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x12, #28
	ld1.s	{ v27 }[3], [x12]
LBB1_104:                               ; %else192
                                        ;   in Loop: Header=BB1_95 Depth=2
	lsl	x11, x11, #5
	add	x13, x19, x11
	ldr	q2, [x13]
	and.16b	v2, v1, v2
	fdiv.4s	v2, v2, v17
	add	x14, x21, x11
	ldr	q4, [x14]
	and.16b	v4, v1, v4
	fmul.4s	v2, v2, v4
	fmov	w12, s10
	fadd.4s	v30, v30, v2
	add.2d	v2, v3, v29
	fmov	x11, d2
	add	x11, x8, x11, lsl #2
	tbnz	w12, #0, LBB1_119
; %bb.105:                              ; %else196
                                        ;   in Loop: Header=BB1_95 Depth=2
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_120
LBB1_106:                               ; %else198
                                        ;   in Loop: Header=BB1_95 Depth=2
	ldr	q31, [x13, #16]
	ldr	q29, [x14, #16]
	tbnz	w12, #2, LBB1_121
LBB1_107:                               ; %else200
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w12, #3, LBB1_122
LBB1_108:                               ; %else202
                                        ;   in Loop: Header=BB1_95 Depth=2
	and.16b	v2, v0, v31
	fdiv.4s	v2, v2, v17
	and.16b	v4, v0, v29
	fmul.4s	v2, v2, v4
	fadd.4s	v27, v27, v2
	tbnz	w12, #4, LBB1_123
LBB1_109:                               ; %else204
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w12, #5, LBB1_124
LBB1_110:                               ; %else206
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w12, #6, LBB1_125
LBB1_111:                               ; %else208
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbz	w12, #7, LBB1_94
	b	LBB1_126
LBB1_112:                               ; %cond.load170
                                        ;   in Loop: Header=BB1_95 Depth=2
	ldr	s30, [x12]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_97
LBB1_113:                               ; %cond.load173
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x14, x12, #4
	ld1.s	{ v30 }[1], [x14]
	tbz	w13, #2, LBB1_98
LBB1_114:                               ; %cond.load176
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x14, x12, #8
	ld1.s	{ v30 }[2], [x14]
	tbz	w13, #3, LBB1_99
LBB1_115:                               ; %cond.load179
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x14, x12, #12
	ld1.s	{ v30 }[3], [x14]
	tbz	w13, #4, LBB1_100
LBB1_116:                               ; %cond.load182
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x14, x12, #16
	ld1.s	{ v27 }[0], [x14]
	tbz	w13, #5, LBB1_101
LBB1_117:                               ; %cond.load185
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x14, x12, #20
	ld1.s	{ v27 }[1], [x14]
	tbz	w13, #6, LBB1_102
LBB1_118:                               ; %cond.load188
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x14, x12, #24
	ld1.s	{ v27 }[2], [x14]
	tbnz	w13, #7, LBB1_103
	b	LBB1_104
LBB1_119:                               ; %cond.store195
                                        ;   in Loop: Header=BB1_95 Depth=2
	str	s30, [x11]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_106
LBB1_120:                               ; %cond.store197
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x15, x11, #4
	st1.s	{ v30 }[1], [x15]
	ldr	q31, [x13, #16]
	ldr	q29, [x14, #16]
	tbz	w12, #2, LBB1_107
LBB1_121:                               ; %cond.store199
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x13, x11, #8
	st1.s	{ v30 }[2], [x13]
	tbz	w12, #3, LBB1_108
LBB1_122:                               ; %cond.store201
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x13, x11, #12
	st1.s	{ v30 }[3], [x13]
	and.16b	v2, v0, v31
	fdiv.4s	v2, v2, v17
	and.16b	v4, v0, v29
	fmul.4s	v2, v2, v4
	fadd.4s	v27, v27, v2
	tbz	w12, #4, LBB1_109
LBB1_123:                               ; %cond.store203
                                        ;   in Loop: Header=BB1_95 Depth=2
	str	s27, [x11, #16]
	tbz	w12, #5, LBB1_110
LBB1_124:                               ; %cond.store205
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x13, x11, #20
	st1.s	{ v27 }[1], [x13]
	tbz	w12, #6, LBB1_111
LBB1_125:                               ; %cond.store207
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x13, x11, #24
	st1.s	{ v27 }[2], [x13]
	tbz	w12, #7, LBB1_94
LBB1_126:                               ; %cond.store209
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x11, x11, #28
	st1.s	{ v27 }[3], [x11]
	b	LBB1_94
LBB1_127:                               ; %direct.false215.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w11, s28
	add	x9, x10, x9
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w11, #0, LBB1_195
; %bb.128:                              ; %else213
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #1, LBB1_196
LBB1_129:                               ; %else216
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #2, LBB1_197
LBB1_130:                               ; %else219
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #3, LBB1_198
LBB1_131:                               ; %else222
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #4, LBB1_199
LBB1_132:                               ; %else225
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #5, LBB1_200
LBB1_133:                               ; %else228
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #6, LBB1_201
LBB1_134:                               ; %else231
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w11, #7, LBB1_136
LBB1_135:                               ; %cond.load233
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v1 }[3], [x9]
LBB1_136:                               ; %else234
                                        ;   in Loop: Header=BB1_4 Depth=1
	fdiv.4s	v2, v24, v17
	fdiv.4s	v3, v23, v17
	zip1.8b	v4, v13, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v4, v4, v25
	zip2.8b	v5, v13, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v5, v5, v22
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v2, v2, v0
	fadd.4s	v0, v3, v1
	b	LBB1_179
LBB1_137:                               ; %cond.load95
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v27 }[0], [x9]
	tbz	w11, #1, LBB1_33
LBB1_138:                               ; %cond.load98
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x9, #4
	ld1.s	{ v27 }[1], [x13]
	tbz	w11, #2, LBB1_34
LBB1_139:                               ; %cond.load101
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x9, #8
	ld1.s	{ v27 }[2], [x13]
	tbz	w11, #3, LBB1_35
LBB1_140:                               ; %cond.load104
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x9, #12
	ld1.s	{ v27 }[3], [x13]
	tbz	w11, #4, LBB1_36
LBB1_141:                               ; %cond.load107
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x9, #16
	ld1.s	{ v25 }[0], [x13]
	tbz	w11, #5, LBB1_37
LBB1_142:                               ; %cond.load110
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x9, #20
	ld1.s	{ v25 }[1], [x13]
	tbz	w11, #6, LBB1_38
LBB1_143:                               ; %cond.load113
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x9, #24
	ld1.s	{ v25 }[2], [x13]
	str	q4, [sp, #416]                  ; 16-byte Spill
	str	q26, [sp, #352]                 ; 16-byte Spill
	tbnz	w11, #7, LBB1_39
	b	LBB1_40
LBB1_144:                               ; %cond.load145
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v25 }[0], [x12]
	ldr	q16, [sp, #400]                 ; 16-byte Reload
	tbz	w11, #1, LBB1_66
LBB1_145:                               ; %cond.load148
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x12, #4
	ld1.s	{ v25 }[1], [x13]
	tbz	w11, #2, LBB1_67
LBB1_146:                               ; %cond.load151
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x12, #8
	ld1.s	{ v25 }[2], [x13]
	tbz	w11, #3, LBB1_68
LBB1_147:                               ; %cond.load154
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x12, #12
	ld1.s	{ v25 }[3], [x13]
	tbz	w11, #4, LBB1_69
LBB1_148:                               ; %cond.load157
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x12, #16
	ld1.s	{ v22 }[0], [x13]
	tbz	w11, #5, LBB1_70
LBB1_149:                               ; %cond.load160
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x12, #20
	ld1.s	{ v22 }[1], [x13]
	tbz	w11, #6, LBB1_71
LBB1_150:                               ; %cond.load163
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x12, #24
	ld1.s	{ v22 }[2], [x13]
	tbnz	w11, #7, LBB1_72
	b	LBB1_73
LBB1_151:                               ; %direct.false257.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x10, x9
	add	x10, x27, x28
	ldp	q6, q3, [x10]
	fmov	w10, s28
	tbnz	w10, #0, LBB1_202
; %bb.152:                              ; %else263
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #1, LBB1_203
LBB1_153:                               ; %else266
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #2, LBB1_204
LBB1_154:                               ; %else269
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #3, LBB1_205
LBB1_155:                               ; %else272
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #4, LBB1_206
LBB1_156:                               ; %else275
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #5, LBB1_207
LBB1_157:                               ; %else278
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w10, #6, LBB1_208
LBB1_158:                               ; %else281
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_160
LBB1_159:                               ; %cond.load283
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v3 }[3], [x9]
LBB1_160:                               ; %else284
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	add	x9, x27, x28
	stp	q6, q3, [x9]
	dup.4s	v5, v5[0]
	ldr	q2, [sp, #240]                  ; 16-byte Reload
	fmov	x9, d2
	add	x9, x8, x9, lsl #2
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v26, #0000000000000000
	b	LBB1_162
LBB1_161:                               ; %else302
                                        ;   in Loop: Header=BB1_162 Depth=2
	add.2d	v16, v16, v19
	add.2d	v17, v17, v20
	add.2d	v26, v26, v18
	add.2d	v7, v7, v21
	fmov	x10, d7
	cmp	x10, #8
	b.ge	LBB1_178
LBB1_162:                               ; %direct.true281.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s10
	lsl	x10, x10, #5
	add	x12, x19, x10
	ldp	q2, q27, [x12]
	and.16b	v2, v1, v2
	fdiv.4s	v2, v2, v5
	add	x12, x21, x10
	ldp	q4, q29, [x12]
	and.16b	v4, v1, v4
	fmul.4s	v2, v2, v4
	add	x12, x27, x10
	ldp	q4, q30, [x12]
	and.16b	v4, v1, v4
	fadd.4s	v31, v2, v4
	add	x10, x9, x10
	tbnz	w11, #0, LBB1_171
; %bb.163:                              ; %else288
                                        ;   in Loop: Header=BB1_162 Depth=2
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_172
LBB1_164:                               ; %else290
                                        ;   in Loop: Header=BB1_162 Depth=2
	tbnz	w11, #2, LBB1_173
LBB1_165:                               ; %else292
                                        ;   in Loop: Header=BB1_162 Depth=2
	tbz	w11, #3, LBB1_167
LBB1_166:                               ; %cond.store293
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x12, x10, #12
	st1.s	{ v31 }[3], [x12]
LBB1_167:                               ; %else294
                                        ;   in Loop: Header=BB1_162 Depth=2
	and.16b	v2, v0, v27
	fdiv.4s	v2, v2, v5
	and.16b	v4, v0, v29
	fmul.4s	v2, v2, v4
	and.16b	v4, v0, v30
	fadd.4s	v27, v2, v4
	tbnz	w11, #4, LBB1_174
; %bb.168:                              ; %else296
                                        ;   in Loop: Header=BB1_162 Depth=2
	tbnz	w11, #5, LBB1_175
LBB1_169:                               ; %else298
                                        ;   in Loop: Header=BB1_162 Depth=2
	tbnz	w11, #6, LBB1_176
LBB1_170:                               ; %else300
                                        ;   in Loop: Header=BB1_162 Depth=2
	tbz	w11, #7, LBB1_161
	b	LBB1_177
LBB1_171:                               ; %cond.store287
                                        ;   in Loop: Header=BB1_162 Depth=2
	str	s31, [x10]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_164
LBB1_172:                               ; %cond.store289
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x12, x10, #4
	st1.s	{ v31 }[1], [x12]
	tbz	w11, #2, LBB1_165
LBB1_173:                               ; %cond.store291
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x12, x10, #8
	st1.s	{ v31 }[2], [x12]
	tbnz	w11, #3, LBB1_166
	b	LBB1_167
LBB1_174:                               ; %cond.store295
                                        ;   in Loop: Header=BB1_162 Depth=2
	str	s27, [x10, #16]
	tbz	w11, #5, LBB1_169
LBB1_175:                               ; %cond.store297
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x12, x10, #20
	st1.s	{ v27 }[1], [x12]
	tbz	w11, #6, LBB1_170
LBB1_176:                               ; %cond.store299
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x12, x10, #24
	st1.s	{ v27 }[2], [x12]
	tbz	w11, #7, LBB1_161
LBB1_177:                               ; %cond.store301
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x10, x10, #28
	st1.s	{ v27 }[3], [x10]
	b	LBB1_161
LBB1_178:                               ; %direct.false282.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fdiv.4s	v0, v23, v5
	fdiv.4s	v1, v24, v5
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v4, v2, v22
	zip1.8b	v5, v13, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v7, v5, v25
	fmul.4s	v1, v1, v7
	fmul.4s	v0, v0, v4
	and.16b	v4, v5, v6
	and.16b	v2, v2, v3
	fadd.4s	v0, v0, v2
	fadd.4s	v2, v1, v4
LBB1_179:                               ; %common.ret.sink.split.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	w11, [sp, #460]                 ; 4-byte Reload
	ldp	q1, q3, [sp, #304]              ; 32-byte Folded Reload
	ldp	q5, q4, [sp, #272]              ; 32-byte Folded Reload
	stp	q3, q4, [sp, #464]
	stp	q5, q1, [sp, #496]
	and	x9, x16, #0x7
	add	x10, sp, #464
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x16
	add	x8, x8, x9, lsl #2
	fmov	w9, s28
	tbnz	w9, #0, LBB1_187
; %bb.180:                              ; %else
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #1, LBB1_188
LBB1_181:                               ; %else58
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #2, LBB1_189
LBB1_182:                               ; %else60
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #3, LBB1_190
LBB1_183:                               ; %else62
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #4, LBB1_191
LBB1_184:                               ; %else64
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #5, LBB1_192
LBB1_185:                               ; %else66
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #6, LBB1_193
LBB1_186:                               ; %else68
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #7, LBB1_2
	b	LBB1_194
LBB1_187:                               ; %cond.store
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s2, [x8]
	tbz	w9, #1, LBB1_181
LBB1_188:                               ; %cond.store57
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #4
	st1.s	{ v2 }[1], [x10]
	tbz	w9, #2, LBB1_182
LBB1_189:                               ; %cond.store59
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #8
	st1.s	{ v2 }[2], [x10]
	tbz	w9, #3, LBB1_183
LBB1_190:                               ; %cond.store61
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #12
	st1.s	{ v2 }[3], [x10]
	tbz	w9, #4, LBB1_184
LBB1_191:                               ; %cond.store63
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x8, #16]
	tbz	w9, #5, LBB1_185
LBB1_192:                               ; %cond.store65
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w9, #6, LBB1_186
LBB1_193:                               ; %cond.store67
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB1_2
LBB1_194:                               ; %cond.store69
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB1_2
LBB1_195:                               ; %cond.load212
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s0, [x9]
	tbz	w11, #1, LBB1_129
LBB1_196:                               ; %cond.load215
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #4
	ld1.s	{ v0 }[1], [x10]
	tbz	w11, #2, LBB1_130
LBB1_197:                               ; %cond.load218
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #8
	ld1.s	{ v0 }[2], [x10]
	tbz	w11, #3, LBB1_131
LBB1_198:                               ; %cond.load221
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #12
	ld1.s	{ v0 }[3], [x10]
	tbz	w11, #4, LBB1_132
LBB1_199:                               ; %cond.load224
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #16
	ld1.s	{ v1 }[0], [x10]
	tbz	w11, #5, LBB1_133
LBB1_200:                               ; %cond.load227
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #20
	ld1.s	{ v1 }[1], [x10]
	tbz	w11, #6, LBB1_134
LBB1_201:                               ; %cond.load230
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #24
	ld1.s	{ v1 }[2], [x10]
	tbnz	w11, #7, LBB1_135
	b	LBB1_136
LBB1_202:                               ; %cond.load262
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v6 }[0], [x9]
	tbz	w10, #1, LBB1_153
LBB1_203:                               ; %cond.load265
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v6 }[1], [x11]
	tbz	w10, #2, LBB1_154
LBB1_204:                               ; %cond.load268
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v6 }[2], [x11]
	tbz	w10, #3, LBB1_155
LBB1_205:                               ; %cond.load271
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v6 }[3], [x11]
	tbz	w10, #4, LBB1_156
LBB1_206:                               ; %cond.load274
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v3 }[0], [x11]
	tbz	w10, #5, LBB1_157
LBB1_207:                               ; %cond.load277
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v3 }[1], [x11]
	tbz	w10, #6, LBB1_158
LBB1_208:                               ; %cond.load280
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v3 }[2], [x11]
	tbnz	w10, #7, LBB1_159
	b	LBB1_160
LBB1_209:                               ; %block.batch.exit
	add	sp, sp, #2848
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
                                        ; -- End function
.subsections_via_symbols

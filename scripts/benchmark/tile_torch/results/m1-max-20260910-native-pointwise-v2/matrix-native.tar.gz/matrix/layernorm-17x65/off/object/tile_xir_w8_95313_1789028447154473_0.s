	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_12:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI0_13:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI0_14:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI0_15:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB0_154
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2864
	mov	x30, x3
	mov	w8, #0                          ; =0x0
	mov	w5, #32                         ; =0x20
	mov	w10, #260                       ; =0x104
	mov	w11, #1115815936                ; =0x42820000
	ldr	w9, [x2, #44]
	str	w9, [sp, #196]                  ; 4-byte Spill
	ldr	w9, [x2, #48]
	str	w9, [sp, #192]                  ; 4-byte Spill
	mov	w14, #50604                     ; =0xc5ac
	movk	w14, #14119, lsl #16
	stp	w14, w11, [sp, #200]            ; 8-byte Folded Spill
	ldp	w16, w1, [x2]
	ldp	w7, w19, [x2, #8]
	add	x20, sp, #2576
	movi.2d	v10, #0000000000000000
	mov	w21, #4                         ; =0x4
	add	x23, sp, #2288
	add	x24, sp, #2000
	add	x27, sp, #1712
	str	w3, [sp, #36]                   ; 4-byte Spill
	stp	x0, x19, [sp, #16]              ; 16-byte Folded Spill
	b	LBB0_4
LBB0_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w9, #24                         ; =0x18
	str	w9, [x2, #36]
	mov	w5, #32                         ; =0x20
LBB0_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	w9, w16, #1
	ldp	w13, w12, [sp, #192]            ; 8-byte Folded Reload
	cmp	w9, w12
	cset	w9, eq
	csinc	w16, wzr, w16, eq
	cinc	w12, w1, eq
	cmp	w12, w13
	cset	w13, eq
	ands	w9, w9, w13
	csel	w1, wzr, w12, ne
	add	w7, w7, w9
	add	w8, w8, #1
	cmp	w8, w30
	b.eq	LBB0_153
LBB0_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_8 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_39 Depth 2
                                        ;     Child Loop BB0_41 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_46 Depth 2
                                        ;     Child Loop BB0_73 Depth 2
                                        ;     Child Loop BB0_100 Depth 2
	ubfiz	x9, x16, #5, #32
	cmp	x9, x19
	csel	x12, x9, xzr, ls
	subs	x13, x19, x12
	cmp	x13, #32
	csel	x13, x13, x5, lo
	cmp	x19, x12
	stp	w16, w1, [x2]
	str	w7, [x2, #8]
	str	wzr, [x2, #36]
	ccmp	x9, x19, #2, hi
	csel	x12, x13, xzr, ls
	cmp	x12, #32
	b.lo	LBB0_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	x15, [x0]
	ldr	x13, [x0, #16]
	ldr	x12, [x0, #32]
	ubfiz	w3, w16, #2, #27
	umull	x9, w3, w10
	umaddl	x17, w3, w10, x15
	ldp	q0, q1, [x17]
	ldp	q3, q2, [x17, #32]
	ldp	q4, q5, [x17, #64]
	ldp	q7, q6, [x17, #96]
	ldp	q16, q17, [x17, #128]
	ldp	q26, q25, [x17, #160]
	ldp	q27, q28, [x17, #192]
	ldp	q8, q31, [x17, #224]
	add	x17, x9, #256
	ldr	s9, [x15, x17]
	fadd.4s	v18, v7, v8
	fadd.4s	v19, v6, v31
	fadd.4s	v20, v5, v28
	fadd.4s	v21, v4, v27
	fadd.4s	v22, v3, v26
	fadd.4s	v23, v2, v25
	fadd.4s	v24, v1, v17
	fadd.4s	v29, v0, v16
	fadd.4s	v30, v29, v9
	mov.s	v29[0], v30[0]
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v29
	fadd.4s	v21, v21, v22
	fadd.4s	v20, v20, v23
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v21
	rev64.4s	v20, v18
	rev64.4s	v21, v19
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	dup.4s	v20, v18[2]
	dup.4s	v21, v19[2]
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	fadd	s18, s18, s10
	ldr	s19, [sp, #204]                 ; 4-byte Reload
	fdiv	s18, s18, s19
	dup.4s	v10, v18[0]
	ldr	x9, [x0, #48]
	fsub.4s	v29, v1, v10
	fsub.4s	v30, v0, v10
	fsub.4s	v24, v3, v10
	fsub.4s	v11, v2, v10
	fsub.4s	v23, v5, v10
	fsub.4s	v22, v4, v10
	stp	q23, q22, [sp, #224]            ; 32-byte Folded Spill
	fsub.4s	v20, v7, v10
	fsub.4s	v21, v6, v10
	stp	q21, q20, [sp, #256]            ; 32-byte Folded Spill
	fsub.4s	v7, v17, v10
	str	q7, [sp, #208]                  ; 16-byte Spill
	fsub.4s	v18, v16, v10
	fsub.4s	v16, v26, v10
	fsub.4s	v5, v25, v10
	stp	q5, q16, [sp, #288]             ; 32-byte Folded Spill
	fsub.4s	v6, v28, v10
	fsub.4s	v17, v27, v10
	stp	q17, q6, [sp, #320]             ; 32-byte Folded Spill
	fsub.4s	v0, v8, v10
	fsub.4s	v4, v31, v10
	stp	q4, q0, [sp, #416]              ; 32-byte Folded Spill
	fsub.4s	v3, v9, v10
	ldp	q31, q8, [x13]
	ldp	q2, q1, [x13, #32]
	stp	q3, q1, [sp, #352]              ; 32-byte Folded Spill
	ldr	q1, [x13, #64]
	str	q1, [sp, #448]                  ; 16-byte Spill
	ldr	q1, [x13, #80]
	stp	q2, q1, [sp, #384]              ; 32-byte Folded Spill
	fmul.4s	v1, v30, v30
	fmul.4s	v2, v29, v29
	fmul.4s	v9, v11, v11
	mov.16b	v26, v11
	fmul.4s	v10, v24, v24
	mov.16b	v27, v24
	fmul.4s	v11, v22, v22
	fmul.4s	v12, v23, v23
	fmul.4s	v13, v21, v21
	fmul.4s	v14, v20, v20
	fmul.4s	v15, v0, v0
	fadd.4s	v15, v14, v15
	fmul.4s	v14, v4, v4
	fadd.4s	v13, v13, v14
	fmul.4s	v14, v6, v6
	fadd.4s	v0, v12, v14
	fmul.4s	v12, v17, v17
	fadd.4s	v11, v11, v12
	fmul.4s	v12, v16, v16
	fadd.4s	v10, v10, v12
	fmul.4s	v12, v5, v5
	fadd.4s	v9, v9, v12
	fmul.4s	v12, v7, v7
	fadd.4s	v2, v2, v12
	fmul.4s	v12, v18, v18
	mov.16b	v28, v18
	fadd.4s	v1, v1, v12
	fmul.4s	v12, v3, v3
	fadd.4s	v12, v12, v1
	mov.s	v1[0], v12[0]
	fadd.4s	v9, v9, v2
	ldp	q14, q24, [x13, #96]
	fadd.4s	v1, v10, v1
	fadd.4s	v1, v11, v1
	ldp	q10, q12, [x13, #128]
	fadd.4s	v0, v0, v9
	fadd.4s	v0, v13, v0
	fadd.4s	v1, v15, v1
	rev64.4s	v9, v1
	rev64.4s	v11, v0
	fadd.4s	v0, v0, v11
	fadd.4s	v1, v1, v9
	dup.4s	v9, v1[2]
	dup.4s	v11, v0[2]
	fadd.4s	v11, v0, v11
	ldp	q15, q25, [x13, #160]
	fadd.4s	v1, v1, v9
	fadd.4s	v1, v1, v11
	ldp	q11, q13, [x13, #192]
	movi.2d	v0, #0000000000000000
	fadd	s1, s1, s0
	fdiv	s1, s1, s19
	ldr	s0, [sp, #200]                  ; 4-byte Reload
	fadd	s1, s1, s0
	fsqrt	s1, s1
	dup.4s	v9, v1[0]
	fdiv.4s	v1, v30, v9
	fdiv.4s	v29, v29, v9
	fmul.4s	v29, v8, v29
	fmul.4s	v1, v31, v1
	ldp	q31, q30, [x12]
	fadd.4s	v1, v31, v1
	fadd.4s	v8, v30, v29
	ldp	q30, q31, [x13, #224]
	umaddl	x3, w3, w10, x9
	ldr	s29, [x13, #256]
	ldp	q0, q2, [x12, #32]
	ldp	q3, q4, [x12, #64]
	ldp	q5, q6, [x12, #96]
	ldp	q7, q16, [x12, #128]
	ldp	q17, q18, [x12, #160]
	ldp	q19, q20, [x12, #192]
	ldp	q21, q22, [x12, #224]
	ldr	s23, [x12, #256]
	stp	q1, q8, [x3]
	fdiv.4s	v1, v26, v9
	ldr	q26, [sp, #368]                 ; 16-byte Reload
	fmul.4s	v1, v26, v1
	fdiv.4s	v8, v27, v9
	ldr	q26, [sp, #384]                 ; 16-byte Reload
	fmul.4s	v8, v26, v8
	fadd.4s	v0, v0, v8
	fadd.4s	v1, v2, v1
	stp	q0, q1, [x3, #32]
	ldr	q0, [sp, #224]                  ; 16-byte Reload
	fdiv.4s	v0, v0, v9
	ldr	q1, [sp, #400]                  ; 16-byte Reload
	fmul.4s	v0, v1, v0
	ldr	q1, [sp, #240]                  ; 16-byte Reload
	fdiv.4s	v1, v1, v9
	ldr	q2, [sp, #448]                  ; 16-byte Reload
	fmul.4s	v1, v2, v1
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v4, v0
	stp	q1, q0, [x3, #64]
	ldp	q0, q1, [sp, #256]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v24, v0
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v14, v1
	fadd.4s	v1, v5, v1
	fadd.4s	v0, v6, v0
	stp	q1, q0, [x3, #96]
	fdiv.4s	v0, v28, v9
	ldr	q1, [sp, #208]                  ; 16-byte Reload
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v12, v1
	fmul.4s	v0, v10, v0
	fadd.4s	v0, v7, v0
	fadd.4s	v1, v16, v1
	stp	q0, q1, [x3, #128]
	ldp	q1, q0, [sp, #288]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v25, v1
	fmul.4s	v0, v15, v0
	fadd.4s	v0, v17, v0
	fadd.4s	v1, v18, v1
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [sp, #320]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v13, v1
	fmul.4s	v0, v11, v0
	fadd.4s	v0, v19, v0
	fadd.4s	v1, v20, v1
	stp	q0, q1, [x3, #192]
	ldp	q1, q0, [sp, #416]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v31, v1
	fmul.4s	v0, v30, v0
	fadd.4s	v0, v21, v0
	fadd.4s	v1, v22, v1
	stp	q0, q1, [x3, #224]
	ldr	q0, [sp, #352]                  ; 16-byte Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v23, v0
	str	s0, [x9, x17]
	mov	w3, #1                          ; =0x1
	bfi	w3, w16, #2, #27
	umull	x17, w3, w10
	umaddl	x4, w3, w10, x15
	ldp	q0, q1, [x4]
	ldp	q3, q2, [x4, #32]
	ldp	q4, q5, [x4, #64]
	ldp	q7, q6, [x4, #96]
	ldp	q16, q17, [x4, #128]
	ldp	q26, q25, [x4, #160]
	ldp	q27, q28, [x4, #192]
	ldp	q8, q31, [x4, #224]
	add	x17, x17, #256
	ldr	s9, [x15, x17]
	fadd.4s	v18, v7, v8
	fadd.4s	v19, v6, v31
	fadd.4s	v20, v5, v28
	fadd.4s	v21, v4, v27
	fadd.4s	v22, v3, v26
	fadd.4s	v23, v2, v25
	fadd.4s	v24, v1, v17
	fadd.4s	v29, v0, v16
	fadd.4s	v30, v29, v9
	mov.s	v29[0], v30[0]
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v29
	fadd.4s	v21, v21, v22
	fadd.4s	v20, v20, v23
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v21
	rev64.4s	v20, v18
	rev64.4s	v21, v19
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	dup.4s	v20, v18[2]
	dup.4s	v21, v19[2]
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	movi.2d	v19, #0000000000000000
	fadd	s18, s18, s19
	ldr	s19, [sp, #204]                 ; 4-byte Reload
	fdiv	s18, s18, s19
	dup.4s	v10, v18[0]
	fsub.4s	v29, v1, v10
	fsub.4s	v30, v0, v10
	fsub.4s	v24, v3, v10
	fsub.4s	v11, v2, v10
	fsub.4s	v23, v5, v10
	fsub.4s	v22, v4, v10
	stp	q23, q22, [sp, #224]            ; 32-byte Folded Spill
	fsub.4s	v20, v7, v10
	fsub.4s	v21, v6, v10
	stp	q21, q20, [sp, #256]            ; 32-byte Folded Spill
	fsub.4s	v7, v17, v10
	str	q7, [sp, #208]                  ; 16-byte Spill
	fsub.4s	v18, v16, v10
	fsub.4s	v16, v26, v10
	fsub.4s	v5, v25, v10
	stp	q5, q16, [sp, #288]             ; 32-byte Folded Spill
	fsub.4s	v6, v28, v10
	fsub.4s	v17, v27, v10
	stp	q17, q6, [sp, #320]             ; 32-byte Folded Spill
	fsub.4s	v0, v8, v10
	fsub.4s	v4, v31, v10
	stp	q4, q0, [sp, #416]              ; 32-byte Folded Spill
	fsub.4s	v3, v9, v10
	ldp	q31, q8, [x13]
	ldp	q2, q1, [x13, #32]
	stp	q3, q1, [sp, #352]              ; 32-byte Folded Spill
	ldr	q1, [x13, #64]
	str	q1, [sp, #448]                  ; 16-byte Spill
	ldr	q1, [x13, #80]
	stp	q2, q1, [sp, #384]              ; 32-byte Folded Spill
	fmul.4s	v1, v30, v30
	fmul.4s	v2, v29, v29
	fmul.4s	v9, v11, v11
	mov.16b	v26, v11
	fmul.4s	v10, v24, v24
	mov.16b	v27, v24
	fmul.4s	v11, v22, v22
	fmul.4s	v12, v23, v23
	fmul.4s	v13, v21, v21
	fmul.4s	v14, v20, v20
	fmul.4s	v15, v0, v0
	fadd.4s	v15, v14, v15
	fmul.4s	v14, v4, v4
	fadd.4s	v13, v13, v14
	fmul.4s	v14, v6, v6
	fadd.4s	v0, v12, v14
	fmul.4s	v12, v17, v17
	fadd.4s	v11, v11, v12
	fmul.4s	v12, v16, v16
	fadd.4s	v10, v10, v12
	fmul.4s	v12, v5, v5
	fadd.4s	v9, v9, v12
	fmul.4s	v12, v7, v7
	fadd.4s	v2, v2, v12
	fmul.4s	v12, v18, v18
	mov.16b	v28, v18
	fadd.4s	v1, v1, v12
	fmul.4s	v12, v3, v3
	fadd.4s	v12, v12, v1
	mov.s	v1[0], v12[0]
	fadd.4s	v9, v9, v2
	ldp	q14, q24, [x13, #96]
	fadd.4s	v1, v10, v1
	fadd.4s	v1, v11, v1
	ldp	q10, q12, [x13, #128]
	fadd.4s	v0, v0, v9
	fadd.4s	v0, v13, v0
	fadd.4s	v1, v15, v1
	rev64.4s	v9, v1
	rev64.4s	v11, v0
	fadd.4s	v0, v0, v11
	fadd.4s	v1, v1, v9
	dup.4s	v9, v1[2]
	dup.4s	v11, v0[2]
	fadd.4s	v11, v0, v11
	ldp	q15, q25, [x13, #160]
	fadd.4s	v1, v1, v9
	fadd.4s	v1, v1, v11
	ldp	q11, q13, [x13, #192]
	movi.2d	v0, #0000000000000000
	fadd	s1, s1, s0
	fdiv	s1, s1, s19
	ldr	s0, [sp, #200]                  ; 4-byte Reload
	fadd	s1, s1, s0
	fsqrt	s1, s1
	dup.4s	v9, v1[0]
	fdiv.4s	v1, v30, v9
	fdiv.4s	v29, v29, v9
	fmul.4s	v29, v8, v29
	fmul.4s	v1, v31, v1
	ldp	q31, q30, [x12]
	fadd.4s	v1, v31, v1
	fadd.4s	v8, v30, v29
	ldp	q30, q31, [x13, #224]
	umaddl	x3, w3, w10, x9
	ldr	s29, [x13, #256]
	ldp	q0, q2, [x12, #32]
	ldp	q3, q4, [x12, #64]
	ldp	q5, q6, [x12, #96]
	ldp	q7, q16, [x12, #128]
	ldp	q17, q18, [x12, #160]
	ldp	q19, q20, [x12, #192]
	ldp	q21, q22, [x12, #224]
	ldr	s23, [x12, #256]
	stp	q1, q8, [x3]
	fdiv.4s	v1, v26, v9
	ldr	q26, [sp, #368]                 ; 16-byte Reload
	fmul.4s	v1, v26, v1
	fdiv.4s	v8, v27, v9
	ldr	q26, [sp, #384]                 ; 16-byte Reload
	fmul.4s	v8, v26, v8
	fadd.4s	v0, v0, v8
	fadd.4s	v1, v2, v1
	stp	q0, q1, [x3, #32]
	ldr	q0, [sp, #224]                  ; 16-byte Reload
	fdiv.4s	v0, v0, v9
	ldr	q1, [sp, #400]                  ; 16-byte Reload
	fmul.4s	v0, v1, v0
	ldr	q1, [sp, #240]                  ; 16-byte Reload
	fdiv.4s	v1, v1, v9
	ldr	q2, [sp, #448]                  ; 16-byte Reload
	fmul.4s	v1, v2, v1
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v4, v0
	stp	q1, q0, [x3, #64]
	ldp	q0, q1, [sp, #256]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v24, v0
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v14, v1
	fadd.4s	v1, v5, v1
	fadd.4s	v0, v6, v0
	stp	q1, q0, [x3, #96]
	fdiv.4s	v0, v28, v9
	ldr	q1, [sp, #208]                  ; 16-byte Reload
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v12, v1
	fmul.4s	v0, v10, v0
	fadd.4s	v0, v7, v0
	fadd.4s	v1, v16, v1
	stp	q0, q1, [x3, #128]
	ldp	q1, q0, [sp, #288]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v25, v1
	fmul.4s	v0, v15, v0
	fadd.4s	v0, v17, v0
	fadd.4s	v1, v18, v1
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [sp, #320]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v13, v1
	fmul.4s	v0, v11, v0
	fadd.4s	v0, v19, v0
	fadd.4s	v1, v20, v1
	stp	q0, q1, [x3, #192]
	ldp	q1, q0, [sp, #416]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v31, v1
	fmul.4s	v0, v30, v0
	fadd.4s	v0, v21, v0
	fadd.4s	v1, v22, v1
	stp	q0, q1, [x3, #224]
	ldr	q0, [sp, #352]                  ; 16-byte Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v23, v0
	str	s0, [x9, x17]
	mov	w3, #2                          ; =0x2
	bfi	w3, w16, #2, #27
	umull	x17, w3, w10
	umaddl	x4, w3, w10, x15
	ldp	q0, q1, [x4]
	ldp	q3, q2, [x4, #32]
	ldp	q4, q5, [x4, #64]
	ldp	q7, q6, [x4, #96]
	ldp	q16, q17, [x4, #128]
	ldp	q26, q25, [x4, #160]
	ldp	q27, q28, [x4, #192]
	ldp	q8, q31, [x4, #224]
	add	x17, x17, #256
	ldr	s9, [x15, x17]
	fadd.4s	v18, v7, v8
	fadd.4s	v19, v6, v31
	fadd.4s	v20, v5, v28
	fadd.4s	v21, v4, v27
	fadd.4s	v22, v3, v26
	fadd.4s	v23, v2, v25
	fadd.4s	v24, v1, v17
	fadd.4s	v29, v0, v16
	fadd.4s	v30, v29, v9
	mov.s	v29[0], v30[0]
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v29
	fadd.4s	v21, v21, v22
	fadd.4s	v20, v20, v23
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v21
	rev64.4s	v20, v18
	rev64.4s	v21, v19
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	dup.4s	v20, v18[2]
	dup.4s	v21, v19[2]
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	movi.2d	v19, #0000000000000000
	fadd	s18, s18, s19
	ldr	s19, [sp, #204]                 ; 4-byte Reload
	fdiv	s18, s18, s19
	dup.4s	v10, v18[0]
	fsub.4s	v29, v1, v10
	fsub.4s	v30, v0, v10
	fsub.4s	v24, v3, v10
	fsub.4s	v11, v2, v10
	fsub.4s	v23, v5, v10
	fsub.4s	v22, v4, v10
	stp	q23, q22, [sp, #224]            ; 32-byte Folded Spill
	fsub.4s	v20, v7, v10
	fsub.4s	v21, v6, v10
	stp	q21, q20, [sp, #256]            ; 32-byte Folded Spill
	fsub.4s	v7, v17, v10
	str	q7, [sp, #208]                  ; 16-byte Spill
	fsub.4s	v18, v16, v10
	fsub.4s	v16, v26, v10
	fsub.4s	v5, v25, v10
	stp	q5, q16, [sp, #288]             ; 32-byte Folded Spill
	fsub.4s	v6, v28, v10
	fsub.4s	v17, v27, v10
	stp	q17, q6, [sp, #320]             ; 32-byte Folded Spill
	fsub.4s	v0, v8, v10
	fsub.4s	v4, v31, v10
	stp	q4, q0, [sp, #416]              ; 32-byte Folded Spill
	fsub.4s	v3, v9, v10
	ldp	q31, q8, [x13]
	ldp	q2, q1, [x13, #32]
	stp	q3, q1, [sp, #352]              ; 32-byte Folded Spill
	ldr	q1, [x13, #64]
	str	q1, [sp, #448]                  ; 16-byte Spill
	ldr	q1, [x13, #80]
	stp	q2, q1, [sp, #384]              ; 32-byte Folded Spill
	fmul.4s	v1, v30, v30
	fmul.4s	v2, v29, v29
	fmul.4s	v9, v11, v11
	mov.16b	v26, v11
	fmul.4s	v10, v24, v24
	mov.16b	v27, v24
	fmul.4s	v11, v22, v22
	fmul.4s	v12, v23, v23
	fmul.4s	v13, v21, v21
	fmul.4s	v14, v20, v20
	fmul.4s	v15, v0, v0
	fadd.4s	v15, v14, v15
	fmul.4s	v14, v4, v4
	fadd.4s	v13, v13, v14
	fmul.4s	v14, v6, v6
	fadd.4s	v0, v12, v14
	fmul.4s	v12, v17, v17
	fadd.4s	v11, v11, v12
	fmul.4s	v12, v16, v16
	fadd.4s	v10, v10, v12
	fmul.4s	v12, v5, v5
	fadd.4s	v9, v9, v12
	fmul.4s	v12, v7, v7
	fadd.4s	v2, v2, v12
	fmul.4s	v12, v18, v18
	mov.16b	v28, v18
	fadd.4s	v1, v1, v12
	fmul.4s	v12, v3, v3
	fadd.4s	v12, v12, v1
	mov.s	v1[0], v12[0]
	fadd.4s	v9, v9, v2
	ldp	q14, q24, [x13, #96]
	fadd.4s	v1, v10, v1
	fadd.4s	v1, v11, v1
	ldp	q10, q12, [x13, #128]
	fadd.4s	v0, v0, v9
	fadd.4s	v0, v13, v0
	fadd.4s	v1, v15, v1
	rev64.4s	v9, v1
	rev64.4s	v11, v0
	fadd.4s	v0, v0, v11
	fadd.4s	v1, v1, v9
	dup.4s	v9, v1[2]
	dup.4s	v11, v0[2]
	fadd.4s	v11, v0, v11
	ldp	q15, q25, [x13, #160]
	fadd.4s	v1, v1, v9
	fadd.4s	v1, v1, v11
	ldp	q11, q13, [x13, #192]
	movi.2d	v0, #0000000000000000
	fadd	s1, s1, s0
	fdiv	s1, s1, s19
	ldr	s0, [sp, #200]                  ; 4-byte Reload
	fadd	s1, s1, s0
	fsqrt	s1, s1
	dup.4s	v9, v1[0]
	fdiv.4s	v1, v30, v9
	fdiv.4s	v29, v29, v9
	fmul.4s	v29, v8, v29
	fmul.4s	v1, v31, v1
	ldp	q31, q30, [x12]
	fadd.4s	v1, v31, v1
	fadd.4s	v8, v30, v29
	ldp	q30, q31, [x13, #224]
	umaddl	x3, w3, w10, x9
	ldr	s29, [x13, #256]
	ldp	q0, q2, [x12, #32]
	ldp	q3, q4, [x12, #64]
	ldp	q5, q6, [x12, #96]
	ldp	q7, q16, [x12, #128]
	ldp	q17, q18, [x12, #160]
	ldp	q19, q20, [x12, #192]
	ldp	q21, q22, [x12, #224]
	ldr	s23, [x12, #256]
	stp	q1, q8, [x3]
	fdiv.4s	v1, v26, v9
	ldr	q26, [sp, #368]                 ; 16-byte Reload
	fmul.4s	v1, v26, v1
	fdiv.4s	v8, v27, v9
	ldr	q26, [sp, #384]                 ; 16-byte Reload
	fmul.4s	v8, v26, v8
	fadd.4s	v0, v0, v8
	fadd.4s	v1, v2, v1
	stp	q0, q1, [x3, #32]
	ldr	q0, [sp, #224]                  ; 16-byte Reload
	fdiv.4s	v0, v0, v9
	ldr	q1, [sp, #400]                  ; 16-byte Reload
	fmul.4s	v0, v1, v0
	ldr	q1, [sp, #240]                  ; 16-byte Reload
	fdiv.4s	v1, v1, v9
	ldr	q2, [sp, #448]                  ; 16-byte Reload
	fmul.4s	v1, v2, v1
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v4, v0
	stp	q1, q0, [x3, #64]
	ldp	q0, q1, [sp, #256]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v24, v0
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v14, v1
	fadd.4s	v1, v5, v1
	fadd.4s	v0, v6, v0
	stp	q1, q0, [x3, #96]
	fdiv.4s	v0, v28, v9
	ldr	q1, [sp, #208]                  ; 16-byte Reload
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v12, v1
	fmul.4s	v0, v10, v0
	fadd.4s	v0, v7, v0
	fadd.4s	v1, v16, v1
	stp	q0, q1, [x3, #128]
	ldp	q1, q0, [sp, #288]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v25, v1
	fmul.4s	v0, v15, v0
	fadd.4s	v0, v17, v0
	fadd.4s	v1, v18, v1
	stp	q0, q1, [x3, #160]
	ldp	q0, q1, [sp, #320]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v13, v1
	fmul.4s	v0, v11, v0
	fadd.4s	v0, v19, v0
	fadd.4s	v1, v20, v1
	stp	q0, q1, [x3, #192]
	ldp	q1, q0, [sp, #416]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v31, v1
	fmul.4s	v0, v30, v0
	fadd.4s	v0, v21, v0
	fadd.4s	v1, v22, v1
	stp	q0, q1, [x3, #224]
	ldr	q0, [sp, #352]                  ; 16-byte Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v23, v0
	str	s0, [x9, x17]
	mov	w3, #3                          ; =0x3
	bfi	w3, w16, #2, #27
	umull	x17, w3, w10
	umaddl	x4, w3, w10, x15
	ldp	q0, q1, [x4]
	ldp	q3, q2, [x4, #32]
	ldp	q4, q5, [x4, #64]
	ldp	q7, q6, [x4, #96]
	ldp	q16, q17, [x4, #128]
	ldp	q26, q25, [x4, #160]
	ldp	q27, q28, [x4, #192]
	ldp	q8, q31, [x4, #224]
	add	x17, x17, #256
	ldr	s9, [x15, x17]
	fadd.4s	v18, v7, v8
	fadd.4s	v19, v6, v31
	fadd.4s	v20, v5, v28
	fadd.4s	v21, v4, v27
	fadd.4s	v22, v3, v26
	fadd.4s	v23, v2, v25
	fadd.4s	v24, v1, v17
	fadd.4s	v29, v0, v16
	fadd.4s	v30, v29, v9
	mov.s	v29[0], v30[0]
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v29
	fadd.4s	v21, v21, v22
	fadd.4s	v20, v20, v23
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v21
	rev64.4s	v20, v18
	rev64.4s	v21, v19
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	dup.4s	v20, v18[2]
	dup.4s	v21, v19[2]
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	movi.2d	v19, #0000000000000000
	fadd	s18, s18, s19
	ldr	s19, [sp, #204]                 ; 4-byte Reload
	fdiv	s18, s18, s19
	dup.4s	v10, v18[0]
	fsub.4s	v29, v1, v10
	fsub.4s	v30, v0, v10
	fsub.4s	v24, v3, v10
	fsub.4s	v11, v2, v10
	fsub.4s	v23, v5, v10
	fsub.4s	v22, v4, v10
	stp	q23, q22, [sp, #224]            ; 32-byte Folded Spill
	fsub.4s	v20, v7, v10
	fsub.4s	v21, v6, v10
	stp	q21, q20, [sp, #256]            ; 32-byte Folded Spill
	fsub.4s	v17, v17, v10
	str	q17, [sp, #208]                 ; 16-byte Spill
	fsub.4s	v6, v16, v10
	fsub.4s	v5, v26, v10
	fsub.4s	v7, v25, v10
	stp	q7, q5, [sp, #288]              ; 32-byte Folded Spill
	fsub.4s	v18, v28, v10
	fsub.4s	v16, v27, v10
	stp	q18, q16, [sp, #320]            ; 32-byte Folded Spill
	fsub.4s	v0, v8, v10
	fsub.4s	v4, v31, v10
	stp	q4, q0, [sp, #432]              ; 32-byte Folded Spill
	fsub.4s	v3, v9, v10
	ldp	q31, q8, [x13]
	ldp	q2, q1, [x13, #32]
	stp	q3, q2, [sp, #368]              ; 32-byte Folded Spill
	str	q1, [sp, #352]                  ; 16-byte Spill
	ldp	q2, q1, [x13, #64]
	stp	q1, q2, [sp, #400]              ; 32-byte Folded Spill
	fmul.4s	v15, v30, v30
	fmul.4s	v1, v29, v29
	fmul.4s	v2, v11, v11
	mov.16b	v26, v11
	fmul.4s	v9, v24, v24
	mov.16b	v27, v24
	fmul.4s	v10, v22, v22
	fmul.4s	v11, v23, v23
	fmul.4s	v12, v21, v21
	fmul.4s	v13, v20, v20
	fmul.4s	v14, v0, v0
	fadd.4s	v14, v13, v14
	fmul.4s	v13, v4, v4
	fadd.4s	v12, v12, v13
	fmul.4s	v13, v18, v18
	fadd.4s	v0, v11, v13
	fmul.4s	v11, v16, v16
	fadd.4s	v10, v10, v11
	fmul.4s	v11, v5, v5
	fadd.4s	v9, v9, v11
	fmul.4s	v11, v7, v7
	fadd.4s	v2, v2, v11
	fmul.4s	v11, v17, v17
	fadd.4s	v1, v1, v11
	fmul.4s	v11, v6, v6
	mov.16b	v28, v6
	fadd.4s	v11, v15, v11
	fmul.4s	v13, v3, v3
	fadd.4s	v13, v13, v11
	mov.s	v11[0], v13[0]
	fadd.4s	v1, v2, v1
	ldp	q15, q24, [x13, #96]
	fadd.4s	v9, v9, v11
	fadd.4s	v9, v10, v9
	ldp	q11, q13, [x13, #128]
	fadd.4s	v0, v0, v1
	fadd.4s	v0, v12, v0
	fadd.4s	v1, v14, v9
	rev64.4s	v9, v1
	rev64.4s	v10, v0
	fadd.4s	v0, v0, v10
	fadd.4s	v9, v1, v9
	dup.4s	v10, v9[2]
	dup.4s	v1, v0[2]
	fadd.4s	v0, v0, v1
	ldp	q14, q25, [x13, #160]
	fadd.4s	v9, v9, v10
	fadd.4s	v0, v9, v0
	ldp	q10, q12, [x13, #192]
	movi.2d	v1, #0000000000000000
	fadd	s0, s0, s1
	fdiv	s0, s0, s19
	ldr	s1, [sp, #200]                  ; 4-byte Reload
	fadd	s0, s0, s1
	fsqrt	s0, s0
	dup.4s	v9, v0[0]
	fdiv.4s	v0, v30, v9
	fdiv.4s	v29, v29, v9
	fmul.4s	v29, v8, v29
	fmul.4s	v0, v31, v0
	ldp	q31, q30, [x12]
	fadd.4s	v2, v31, v0
	fadd.4s	v0, v30, v29
	ldp	q30, q31, [x13, #224]
	umaddl	x15, w3, w10, x9
	ldr	s29, [x13, #256]
	ldp	q1, q3, [x12, #32]
	ldp	q4, q5, [x12, #64]
	ldp	q6, q7, [x12, #96]
	ldp	q16, q17, [x12, #128]
	ldp	q18, q19, [x12, #160]
	ldp	q20, q21, [x12, #192]
	ldp	q22, q23, [x12, #224]
	ldr	s8, [x12, #256]
	stp	q2, q0, [x15]
	fdiv.4s	v0, v26, v9
	ldr	q2, [sp, #352]                  ; 16-byte Reload
	fmul.4s	v0, v2, v0
	fdiv.4s	v2, v27, v9
	ldr	q26, [sp, #384]                 ; 16-byte Reload
	fmul.4s	v2, v26, v2
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v3, v0
	stp	q1, q0, [x15, #32]
	ldr	q0, [sp, #224]                  ; 16-byte Reload
	fdiv.4s	v0, v0, v9
	ldp	q1, q2, [sp, #400]              ; 32-byte Folded Reload
	fmul.4s	v0, v1, v0
	ldr	q1, [sp, #240]                  ; 16-byte Reload
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v2, v1
	fadd.4s	v1, v4, v1
	fadd.4s	v0, v5, v0
	stp	q1, q0, [x15, #64]
	ldp	q0, q1, [sp, #256]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v24, v0
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v15, v1
	fadd.4s	v1, v6, v1
	fadd.4s	v0, v7, v0
	stp	q1, q0, [x15, #96]
	ldr	q0, [sp, #208]                  ; 16-byte Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v13, v0
	fdiv.4s	v1, v28, v9
	fmul.4s	v1, v11, v1
	fadd.4s	v1, v16, v1
	fadd.4s	v0, v17, v0
	stp	q1, q0, [x15, #128]
	ldp	q0, q1, [sp, #288]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v25, v0
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v14, v1
	fadd.4s	v1, v18, v1
	fadd.4s	v0, v19, v0
	stp	q1, q0, [x15, #160]
	ldp	q0, q1, [sp, #320]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v12, v0
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v10, v1
	movi.2d	v10, #0000000000000000
	fadd.4s	v1, v20, v1
	fadd.4s	v0, v21, v0
	stp	q1, q0, [x15, #192]
	ldp	q0, q1, [sp, #432]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v31, v0
	fdiv.4s	v1, v1, v9
	fmul.4s	v1, v30, v1
	fadd.4s	v1, v22, v1
	fadd.4s	v0, v23, v0
	stp	q1, q0, [x15, #224]
	ldr	q0, [sp, #368]                  ; 16-byte Reload
	fdiv.4s	v0, v0, v9
	fmul.4s	v0, v29, v0
	fadd.4s	v0, v8, v0
	str	s0, [x9, x17]
	mov	w9, #24                         ; =0x18
	str	w9, [x2, #36]
	b	LBB0_3
LBB0_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	lsr	x9, x12, #3
	movi.2d	v28, #0000000000000000
	cbz	x9, LBB0_9
; %bb.7:                                ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	x13, [x0]
	ldr	x15, [x0, #16]
	ldr	x17, [x0, #32]
	ldr	x3, [x0, #48]
	add	x4, x15, #256
	add	x5, x17, #256
	lsl	w6, w16, #2
	mov	x22, x9
LBB0_8:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w26, w6, #0x1fffffff
	umull	x25, w26, w10
	umaddl	x28, w26, w10, x13
	ldp	q0, q1, [x28]
	ldp	q3, q2, [x28, #32]
	ldp	q4, q5, [x28, #64]
	ldp	q7, q6, [x28, #96]
	ldp	q16, q17, [x28, #128]
	ldp	q26, q25, [x28, #160]
	ldp	q30, q31, [x28, #192]
	add	x25, x25, #256
	ldp	q9, q8, [x28, #224]
	ldr	s10, [x13, x25]
	fadd.4s	v18, v7, v9
	fadd.4s	v19, v6, v8
	fadd.4s	v20, v5, v31
	fadd.4s	v21, v4, v30
	fadd.4s	v22, v3, v26
	fadd.4s	v23, v0, v16
	fadd.4s	v24, v23, v10
	mov.s	v23[0], v24[0]
	fadd.4s	v24, v2, v25
	fadd.4s	v27, v1, v17
	fadd.4s	v24, v24, v27
	fadd.4s	v22, v22, v23
	fadd.4s	v21, v21, v22
	fadd.4s	v20, v20, v24
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v21
	rev64.4s	v20, v18
	rev64.4s	v21, v19
	fadd.4s	v18, v18, v20
	dup.4s	v20, v18[2]
	fadd.4s	v19, v19, v21
	dup.4s	v21, v19[2]
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v19
	fadd	s18, s18, s28
	fmov	s29, w11
	fdiv	s18, s18, s29
	dup.4s	v11, v18[0]
	fsub.4s	v27, v1, v11
	movi.2d	v18, #0000000000000000
	fsub.4s	v28, v0, v11
	fsub.4s	v13, v3, v11
	fsub.4s	v3, v2, v11
	fsub.4s	v12, v5, v11
	stp	q13, q12, [sp, #208]            ; 32-byte Folded Spill
	fsub.4s	v24, v4, v11
	fsub.4s	v22, v7, v11
	fsub.4s	v23, v6, v11
	stp	q23, q22, [sp, #288]            ; 32-byte Folded Spill
	fsub.4s	v21, v17, v11
	stp	q24, q21, [sp, #240]            ; 32-byte Folded Spill
	fsub.4s	v19, v16, v11
	str	q19, [sp, #272]                 ; 16-byte Spill
	fsub.4s	v17, v26, v11
	fsub.4s	v20, v25, v11
	stp	q20, q17, [sp, #320]            ; 32-byte Folded Spill
	fsub.4s	v16, v31, v11
	fsub.4s	v7, v30, v11
	fsub.4s	v5, v9, v11
	fsub.4s	v6, v8, v11
	stp	q6, q5, [sp, #432]              ; 32-byte Folded Spill
	ldp	q30, q31, [x15]
	fsub.4s	v4, v10, v11
	str	q4, [sp, #416]                  ; 16-byte Spill
	ldp	q1, q0, [x15, #32]
	stp	q16, q1, [sp, #384]             ; 32-byte Folded Spill
	stp	q7, q0, [sp, #352]              ; 32-byte Folded Spill
	fmul.4s	v0, v28, v28
	fmul.4s	v1, v27, v27
	fmul.4s	v2, v3, v3
	mov.16b	v26, v3
	fmul.4s	v3, v13, v13
	fmul.4s	v8, v24, v24
	fmul.4s	v9, v12, v12
	fmul.4s	v10, v23, v23
	fmul.4s	v11, v22, v22
	fmul.4s	v12, v6, v6
	fmul.4s	v13, v5, v5
	fadd.4s	v11, v11, v13
	fadd.4s	v10, v10, v12
	fmul.4s	v12, v16, v16
	fadd.4s	v9, v9, v12
	fmul.4s	v12, v20, v20
	fmul.4s	v13, v17, v17
	fadd.4s	v3, v3, v13
	fadd.4s	v12, v2, v12
	fmul.4s	v2, v19, v19
	fmul.4s	v13, v21, v21
	fadd.4s	v1, v1, v13
	fmul.4s	v13, v7, v7
	fadd.4s	v0, v0, v2
	fmul.4s	v2, v4, v4
	fadd.4s	v2, v2, v0
	mov.s	v0[0], v2[0]
	fadd.4s	v8, v8, v13
	ldp	q24, q15, [x15, #64]
	fadd.4s	v1, v12, v1
	fadd.4s	v0, v3, v0
	ldp	q14, q25, [x15, #96]
	fadd.4s	v0, v8, v0
	fadd.4s	v1, v9, v1
	fadd.4s	v1, v10, v1
	fadd.4s	v0, v11, v0
	ldp	q8, q11, [x15, #128]
	rev64.4s	v9, v0
	rev64.4s	v10, v1
	fadd.4s	v1, v1, v10
	fadd.4s	v0, v0, v9
	dup.4s	v9, v0[2]
	dup.4s	v10, v1[2]
	fadd.4s	v1, v1, v10
	fadd.4s	v0, v0, v9
	ldp	q10, q13, [x15, #160]
	fadd.4s	v0, v0, v1
	fadd	s0, s0, s18
	fdiv	s0, s0, s29
	fmov	s1, w14
	fadd	s0, s0, s1
	ldp	q9, q12, [x15, #192]
	fsqrt	s0, s0
	dup.4s	v29, v0[0]
	fdiv.4s	v0, v28, v29
	fdiv.4s	v1, v27, v29
	fmul.4s	v1, v31, v1
	fmul.4s	v0, v30, v0
	ldp	q28, q27, [x17]
	fadd.4s	v2, v28, v0
	fadd.4s	v0, v27, v1
	ldp	q28, q30, [x15, #224]
	umaddl	x26, w26, w10, x3
	ldr	s27, [x4]
	ldp	q1, q3, [x17, #32]
	ldp	q4, q5, [x17, #64]
	ldp	q6, q7, [x17, #96]
	ldp	q16, q17, [x17, #128]
	ldp	q18, q19, [x17, #160]
	ldp	q20, q21, [x17, #192]
	ldp	q22, q23, [x17, #224]
	ldr	s31, [x5]
	stp	q2, q0, [x26]
	fdiv.4s	v0, v26, v29
	ldr	q2, [sp, #368]                  ; 16-byte Reload
	fmul.4s	v0, v2, v0
	ldr	q2, [sp, #208]                  ; 16-byte Reload
	fdiv.4s	v2, v2, v29
	ldr	q26, [sp, #400]                 ; 16-byte Reload
	fmul.4s	v2, v26, v2
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v3, v0
	stp	q1, q0, [x26, #32]
	ldp	q0, q1, [sp, #224]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v29
	fmul.4s	v0, v15, v0
	fdiv.4s	v1, v1, v29
	fmul.4s	v1, v24, v1
	fadd.4s	v1, v4, v1
	fadd.4s	v0, v5, v0
	ldp	q2, q3, [sp, #288]              ; 32-byte Folded Reload
	fdiv.4s	v2, v2, v29
	fmul.4s	v2, v25, v2
	fdiv.4s	v3, v3, v29
	fmul.4s	v3, v14, v3
	fadd.4s	v3, v6, v3
	stp	q1, q0, [x26, #64]
	fadd.4s	v0, v7, v2
	stp	q3, q0, [x26, #96]
	ldp	q0, q1, [sp, #256]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v29
	fmul.4s	v0, v11, v0
	fdiv.4s	v1, v1, v29
	fmul.4s	v1, v8, v1
	fadd.4s	v1, v16, v1
	fadd.4s	v0, v17, v0
	stp	q1, q0, [x26, #128]
	ldp	q0, q1, [sp, #320]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v29
	fmul.4s	v0, v13, v0
	fdiv.4s	v1, v1, v29
	fmul.4s	v1, v10, v1
	fadd.4s	v1, v18, v1
	fadd.4s	v0, v19, v0
	ldr	q2, [sp, #384]                  ; 16-byte Reload
	fdiv.4s	v2, v2, v29
	fmul.4s	v2, v12, v2
	ldr	q3, [sp, #352]                  ; 16-byte Reload
	fdiv.4s	v3, v3, v29
	fmul.4s	v3, v9, v3
	fadd.4s	v3, v20, v3
	stp	q1, q0, [x26, #160]
	fadd.4s	v0, v21, v2
	stp	q3, q0, [x26, #192]
	ldp	q0, q1, [sp, #432]              ; 32-byte Folded Reload
	fdiv.4s	v0, v0, v29
	fmul.4s	v0, v30, v0
	fdiv.4s	v1, v1, v29
	fmul.4s	v1, v28, v1
	movi.2d	v28, #0000000000000000
	fadd.4s	v1, v22, v1
	fadd.4s	v0, v23, v0
	ldr	q2, [sp, #416]                  ; 16-byte Reload
	fdiv.4s	v2, v2, v29
	stp	q1, q0, [x26, #224]
	fmul.4s	v0, v27, v2
	fadd.4s	v0, v31, v0
	str	s0, [x3, x25]
	add	w6, w6, #1
	subs	w22, w22, #1
	b.ne	LBB0_8
LBB0_9:                                 ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w12, w12, #0x7
	movi.2d	v10, #0000000000000000
	cbz	w12, LBB0_2
; %bb.10:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	dup.4s	v0, w12
Lloh0:
	adrp	x12, lCPI0_1@PAGE
Lloh1:
	ldr	q1, [x12, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x12, lCPI0_2@PAGE
Lloh3:
	ldr	q2, [x12, lCPI0_2@PAGEOFF]
	cmhi.4s	v17, v0, v2
	cmhi.4s	v18, v0, v1
	uzp1.8h	v1, v18, v17
	umaxv.8h	h0, v1
	fmov	w12, s0
	tbz	w12, #0, LBB0_2
; %bb.11:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x13, #0                         ; =0x0
	ldr	x12, [x0]
	ldr	x25, [x0, #16]
	ldr	x4, [x0, #32]
	ldr	x15, [x0, #48]
	str	x15, [sp, #416]                 ; 8-byte Spill
Lloh4:
	adrp	x15, lCPI0_0@PAGE
Lloh5:
	ldr	q0, [x15, lCPI0_0@PAGEOFF]
	and.16b	v0, v1, v0
	addv.8h	h19, v0
	ubfiz	w15, w16, #2, #27
	orr	w9, w15, w9
	fmov	w15, s19
	and	w15, w15, #0xff
	str	w15, [sp, #80]                  ; 4-byte Spill
	dup.4s	v0, w9
	and.16b	v2, v18, v0
	and.16b	v0, v17, v0
	ushll2.2d	v3, v0, #0
	ushll2.2d	v4, v2, #0
	ushll.2d	v5, v0, #0
	ushll.2d	v6, v2, #0
	fmov	x9, d6
	umaddl	x9, w9, w10, x12
	b	LBB0_13
LBB0_12:                                ; %else80
                                        ;   in Loop: Header=BB0_13 Depth=2
	add	x15, x20, x13
	stp	q7, q0, [x15]
	add	x13, x13, #32
	cmp	x13, #256
	b.eq	LBB0_29
LBB0_13:                                ; %direct.true.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w17, s19
	add	x15, x9, x13
	add	x3, x20, x13
	ldr	q7, [x3]
	tbnz	w17, #0, LBB0_21
; %bb.14:                               ; %else
                                        ;   in Loop: Header=BB0_13 Depth=2
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB0_22
LBB0_15:                                ; %else62
                                        ;   in Loop: Header=BB0_13 Depth=2
	tbnz	w17, #2, LBB0_23
LBB0_16:                                ; %else65
                                        ;   in Loop: Header=BB0_13 Depth=2
	tbnz	w17, #3, LBB0_24
LBB0_17:                                ; %else68
                                        ;   in Loop: Header=BB0_13 Depth=2
	ldr	q0, [x3, #16]
	tbnz	w17, #4, LBB0_25
LBB0_18:                                ; %else71
                                        ;   in Loop: Header=BB0_13 Depth=2
	tbnz	w17, #5, LBB0_26
LBB0_19:                                ; %else74
                                        ;   in Loop: Header=BB0_13 Depth=2
	tbnz	w17, #6, LBB0_27
LBB0_20:                                ; %else77
                                        ;   in Loop: Header=BB0_13 Depth=2
	tbz	w17, #7, LBB0_12
	b	LBB0_28
LBB0_21:                                ; %cond.load
                                        ;   in Loop: Header=BB0_13 Depth=2
	ld1.s	{ v7 }[0], [x15]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB0_15
LBB0_22:                                ; %cond.load61
                                        ;   in Loop: Header=BB0_13 Depth=2
	add	x5, x15, #4
	ld1.s	{ v7 }[1], [x5]
	tbz	w17, #2, LBB0_16
LBB0_23:                                ; %cond.load64
                                        ;   in Loop: Header=BB0_13 Depth=2
	add	x5, x15, #8
	ld1.s	{ v7 }[2], [x5]
	tbz	w17, #3, LBB0_17
LBB0_24:                                ; %cond.load67
                                        ;   in Loop: Header=BB0_13 Depth=2
	add	x5, x15, #12
	ld1.s	{ v7 }[3], [x5]
	ldr	q0, [x3, #16]
	tbz	w17, #4, LBB0_18
LBB0_25:                                ; %cond.load70
                                        ;   in Loop: Header=BB0_13 Depth=2
	add	x3, x15, #16
	ld1.s	{ v0 }[0], [x3]
	tbz	w17, #5, LBB0_19
LBB0_26:                                ; %cond.load73
                                        ;   in Loop: Header=BB0_13 Depth=2
	add	x3, x15, #20
	ld1.s	{ v0 }[1], [x3]
	tbz	w17, #6, LBB0_20
LBB0_27:                                ; %cond.load76
                                        ;   in Loop: Header=BB0_13 Depth=2
	add	x3, x15, #24
	ld1.s	{ v0 }[2], [x3]
	tbz	w17, #7, LBB0_12
LBB0_28:                                ; %cond.load79
                                        ;   in Loop: Header=BB0_13 Depth=2
	add	x15, x15, #28
	ld1.s	{ v0 }[3], [x15]
	b	LBB0_12
LBB0_29:                                ; %direct.true76.preheader.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	xtn.8b	v22, v1
	sshll.2d	v0, v18, #0
	sshll.2d	v23, v17, #0
	sshll2.2d	v10, v18, #0
	sshll2.2d	v11, v17, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q1, [x9, lCPI0_6@PAGEOFF]
	and.16b	v25, v0, v1
Lloh8:
	adrp	x9, lCPI0_7@PAGE
Lloh9:
	ldr	q2, [x9, lCPI0_7@PAGEOFF]
	and.16b	v16, v0, v2
Lloh10:
	adrp	x9, lCPI0_8@PAGE
Lloh11:
	ldr	q0, [x9, lCPI0_8@PAGEOFF]
	and.16b	v0, v23, v0
Lloh12:
	adrp	x9, lCPI0_9@PAGE
Lloh13:
	ldr	q2, [x9, lCPI0_9@PAGEOFF]
	and.16b	v2, v10, v2
Lloh14:
	adrp	x9, lCPI0_10@PAGE
Lloh15:
	ldr	q7, [x9, lCPI0_10@PAGEOFF]
	movi.8b	v1, #1
	and.8b	v20, v22, v1
	umov.b	w9, v20[0]
	movi.2d	v20, #0000000000000000
	mov.b	v20[0], v22[0]
	and.16b	v7, v11, v7
	umaxv.8b	b21, v20
	fmov	w13, s21
	rbit	w15, w9
	clz	w15, w15
	tst	w13, #0x1
	csel	w3, w15, wzr, ne
	mov	w15, #64                        ; =0x40
	dup.2d	v24, x15
	str	q25, [sp, #272]                 ; 16-byte Spill
	orr.16b	v21, v25, v24
	xtn.2s	v25, v6
	str	q21, [sp, #144]                 ; 16-byte Spill
	movi.2s	v1, #65
	umlal.2d	v21, v25, v1
	movi.2d	v6, #0000000000000000
	str	q22, [sp, #432]                 ; 16-byte Spill
	mov.b	v6[0], v22[0]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	str	q21, [sp, #368]                 ; 16-byte Spill
	and.16b	v6, v6, v21
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #1616]
	str	q1, [sp, #1600]
	str	q1, [sp, #1584]
	str	q6, [sp, #1568]
	ubfiz	x15, x3, #3, #3
	add	x17, sp, #1568
	ldr	x17, [x17, x15]
	sub	x17, x17, x3
	add	x12, x12, x17, lsl #2
	str	q7, [sp, #1680]
	str	q0, [sp, #1664]
	str	q2, [sp, #1648]
	str	q16, [sp, #1632]
	add	x17, sp, #1632
	ldr	x15, [x17, x15]
	orr	x15, x15, #0x100
	sub	x15, x15, w3, uxtw #2
	tst	w9, #0x1
	csel	x17, xzr, x15, eq
	add	x15, x20, x17
	ldp	q22, q21, [x15]
	tbnz	w13, #0, LBB0_125
; %bb.30:                               ; %else84
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #1, LBB0_126
LBB0_31:                                ; %else87
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #2, LBB0_127
LBB0_32:                                ; %else90
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #3, LBB0_128
LBB0_33:                                ; %else93
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #4, LBB0_129
LBB0_34:                                ; %else96
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #5, LBB0_130
LBB0_35:                                ; %else99
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #6, LBB0_131
LBB0_36:                                ; %else102
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q20, [sp, #448]                 ; 16-byte Spill
	str	q19, [sp, #400]                 ; 16-byte Spill
	tbz	w9, #7, LBB0_38
LBB0_37:                                ; %cond.load104
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x12, #28
	ld1.s	{ v21 }[3], [x9]
LBB0_38:                                ; %else105
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	w1, [sp, #240]                  ; 4-byte Spill
	str	x3, [sp, #384]                  ; 8-byte Spill
Lloh16:
	adrp	x9, lCPI0_3@PAGE
Lloh17:
	ldr	q0, [x9, lCPI0_3@PAGEOFF]
	and.16b	v1, v11, v0
Lloh18:
	adrp	x9, lCPI0_4@PAGE
Lloh19:
	ldr	q0, [x9, lCPI0_4@PAGEOFF]
	and.16b	v2, v10, v0
Lloh20:
	adrp	x9, lCPI0_5@PAGE
Lloh21:
	ldr	q0, [x9, lCPI0_5@PAGEOFF]
	and.16b	v0, v23, v0
	stp	q0, q2, [sp, #208]              ; 32-byte Folded Spill
	orr.16b	v7, v0, v24
	orr.16b	v19, v2, v24
	str	q1, [sp, #256]                  ; 16-byte Spill
	orr.16b	v6, v1, v24
	movi.2s	v1, #65
	umull.2d	v0, v25, v1
	str	q0, [sp, #288]                  ; 16-byte Spill
	xtn.2s	v0, v4
	xtn.2s	v2, v5
	xtn.2s	v3, v3
	stp	q7, q6, [sp, #112]              ; 32-byte Folded Spill
	mov.16b	v4, v6
	umlal.2d	v4, v3, v1
	str	q19, [sp, #96]                  ; 16-byte Spill
	mov.16b	v3, v19
	umlal.2d	v3, v0, v1
	stp	q3, q4, [sp, #336]              ; 32-byte Folded Spill
	mov.16b	v0, v7
	umlal.2d	v0, v2, v1
	str	q0, [sp, #304]                  ; 16-byte Spill
	sshll.2d	v0, v18, #0
	sshll.2d	v2, v17, #0
	str	x17, [sp, #320]                 ; 8-byte Spill
	add	x9, x20, x17
	stp	q22, q21, [sp, #48]             ; 32-byte Folded Spill
	stp	q22, q21, [x9]
	fmov	x12, d16
	dup.2d	v3, x21
	and.16b	v14, v11, v3
	and.16b	v15, v10, v3
	and.16b	v4, v2, v3
	and.16b	v16, v0, v3
	fmov	x9, d16
	ldr	q0, [sp, #2672]
	ldr	q2, [sp, #2688]
	and.16b	v5, v17, v2
	and.16b	v3, v18, v0
	ldr	q0, [sp, #2640]
	ldr	q2, [sp, #2656]
	and.16b	v25, v17, v2
	and.16b	v24, v18, v0
	ldr	q0, [sp, #2608]
	ldr	q2, [sp, #2624]
	and.16b	v27, v17, v2
	and.16b	v28, v18, v0
	str	x12, [sp, #40]                  ; 8-byte Spill
	add	x12, x20, x12
	ldp	q0, q2, [x12]
	and.16b	v30, v17, v2
	mov	x12, x9
	and.16b	v8, v18, v0
	mov.16b	v0, v16
	mov.16b	v2, v15
	mov.16b	v12, v4
	mov.16b	v13, v14
LBB0_39:                                ; %direct.true76.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v31, v18, #0
	sshll.2d	v1, v17, #0
	add	x12, x20, x12, lsl #5
	ldp	q29, q9, [x12]
	fadd.4s	v29, v8, v29
	fadd.4s	v9, v30, v9
	ldp	q6, q20, [x12, #32]
	fadd.4s	v6, v28, v6
	fadd.4s	v20, v27, v20
	ldp	q26, q7, [x12, #64]
	fadd.4s	v26, v24, v26
	fadd.4s	v7, v25, v7
	ldp	q22, q21, [x12, #96]
	fadd.4s	v22, v3, v22
	fadd.4s	v21, v5, v21
	dup.2d	v23, x21
	and.16b	v19, v11, v23
	add.2d	v13, v13, v19
	and.16b	v19, v10, v23
	add.2d	v2, v2, v19
	and.16b	v1, v1, v23
	add.2d	v12, v12, v1
	and.16b	v1, v31, v23
	add.2d	v0, v0, v1
	bit.16b	v30, v9, v17
	bit.16b	v8, v29, v18
	bit.16b	v27, v20, v17
	bit.16b	v28, v6, v18
	bit.16b	v25, v7, v17
	bit.16b	v24, v26, v18
	bit.16b	v5, v21, v17
	bit.16b	v3, v22, v18
	fmov	x12, d0
	cmp	x12, #8
	b.lt	LBB0_39
; %bb.40:                               ; %direct.false77.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x15, #0                         ; =0x0
	ldp	q2, q31, [sp, #48]              ; 32-byte Folded Reload
	fadd.4s	v0, v31, v30
	fadd.4s	v1, v2, v8
	mov.16b	v8, v2
	ldp	q30, q26, [sp, #432]            ; 32-byte Folded Reload
	zip2.8b	v2, v26, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v0, v2, v0
	zip2.8b	v2, v30, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v0, v9, v2
	zip1.8b	v2, v26, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	movi.2d	v6, #0000000000000000
	mov.b	v6[2], v30[1]
	mov.b	v6[4], v30[2]
	and.16b	v1, v2, v1
	mov.b	v6[6], v30[3]
	ushll.4s	v2, v6, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v1, v29, v2
	fadd.4s	v1, v28, v1
	fadd.4s	v0, v27, v0
	fadd.4s	v0, v25, v0
	fadd.4s	v1, v24, v1
	fadd.4s	v3, v3, v1
	fadd.4s	v5, v5, v0
	ldp	q0, q2, [sp, #256]              ; 32-byte Folded Reload
	ldr	q1, [sp, #224]                  ; 16-byte Reload
	uzp1.4s	v1, v2, v1
	ldr	q2, [sp, #208]                  ; 16-byte Reload
	uzp1.4s	v21, v2, v0
	movi.4s	v2, #1
	eor.16b	v0, v1, v2
	mov.s	w12, v0[1]
	eor.16b	v25, v21, v2
	mov.s	w13, v0[2]
	mov.s	w17, v0[3]
	fmov	w5, s0
	add	x6, sp, #1208
	bfxil	x6, x5, #0, #3
	str	d30, [sp, #1208]
	ldrb	w6, [x6]
	umov.b	w26, v30[0]
	and	x5, x5, #0x7
	str	q5, [sp, #1424]
	str	q3, [sp, #1408]
	add	x22, sp, #1408
	ldr	s0, [x22, x5, lsl #2]
	ands	w3, w26, #0x1
	tst	w3, w6
	movi.2d	v20, #0000000000000000
	fcsel	s22, s0, s20, ne
	and	x5, x12, #0x7
	add	x6, sp, #1208
	bfxil	x6, x12, #0, #3
	ldrb	w12, [x6]
	umov.b	w1, v30[1]
	str	q5, [sp, #1392]
	str	q3, [sp, #1376]
	add	x6, sp, #1376
	ldr	s0, [x6, x5, lsl #2]
	and	w12, w1, w12
	tst	w12, #0x1
	fcsel	s23, s0, s20, ne
	and	x12, x13, #0x7
	add	x5, sp, #1208
	bfxil	x5, x13, #0, #3
	ldrb	w13, [x5]
	umov.b	w28, v30[2]
	and	w13, w28, w13
	str	q5, [sp, #1360]
	str	q3, [sp, #1344]
	add	x5, sp, #1344
	ldr	s0, [x5, x12, lsl #2]
	tst	w13, #0x1
	fcsel	s24, s0, s20, ne
	and	x12, x17, #0x7
	add	x13, sp, #1208
	bfxil	x13, x17, #0, #3
	ldrb	w13, [x13]
	umov.b	w19, v30[3]
	and	w13, w19, w13
	str	q5, [sp, #1328]
	str	q3, [sp, #1312]
	add	x17, sp, #1312
	ldr	s0, [x17, x12, lsl #2]
	tst	w13, #0x1
	mov.s	w12, v25[1]
	fcsel	s27, s0, s20, ne
	mov.s	w13, v25[2]
	mov.s	w5, v25[3]
	fmov	w17, s25
	and	x6, x17, #0x7
	add	x30, sp, #1208
	bfxil	x30, x17, #0, #3
	ldrb	w17, [x30]
	umov.b	w30, v30[4]
	and	w17, w30, w17
	str	q5, [sp, #1552]
	str	q3, [sp, #1536]
	add	x22, sp, #1536
	ldr	s0, [x22, x6, lsl #2]
	tst	w17, #0x1
	fcsel	s0, s0, s20, ne
	and	x6, x12, #0x7
	add	x22, sp, #1208
	bfxil	x22, x12, #0, #3
	umov.b	w17, v30[5]
	ldrb	w12, [x22]
	and	w12, w17, w12
	str	q5, [sp, #1520]
	str	q3, [sp, #1504]
	add	x22, sp, #1504
	ldr	s2, [x22, x6, lsl #2]
	tst	w12, #0x1
	fcsel	s2, s2, s20, ne
	and	x6, x13, #0x7
	add	x12, sp, #1208
	bfxil	x12, x13, #0, #3
	ldrb	w13, [x12]
	umov.b	w12, v30[6]
	str	q5, [sp, #1488]
	str	q3, [sp, #1472]
	add	x22, sp, #1472
	ldr	s6, [x22, x6, lsl #2]
	and	w13, w12, w13
	tst	w13, #0x1
	fcsel	s6, s6, s20, ne
	and	x6, x5, #0x7
	add	x13, sp, #1208
	bfxil	x13, x5, #0, #3
	ldrb	w5, [x13]
	umov.b	w13, v30[7]
	and	w5, w13, w5
	str	q5, [sp, #1456]
	str	q3, [sp, #1440]
	add	x22, sp, #1440
	ldr	s7, [x22, x6, lsl #2]
	tst	w5, #0x1
	fcsel	s7, s7, s20, ne
	mov.s	v0[1], v2[0]
	mov.s	v0[2], v6[0]
	mov.s	v0[3], v7[0]
	mov.s	v22[1], v23[0]
	mov.s	v22[2], v24[0]
	mov.s	v22[3], v27[0]
	fadd.4s	v2, v3, v22
	fadd.4s	v0, v5, v0
	movi.4s	v5, #2
	eor.16b	v3, v21, v5
	eor.16b	v1, v1, v5
	fmov	w5, s1
	add	x6, sp, #1208
	bfxil	x6, x5, #0, #3
	ldrb	w6, [x6]
	and	x5, x5, #0x7
	str	q0, [sp, #1296]
	str	q2, [sp, #1280]
	add	x22, sp, #1280
	ldr	s1, [x22, x5, lsl #2]
	tst	w3, w6
	fcsel	s1, s1, s20, ne
	fmov	w5, s3
	and	x6, x5, #0x7
	add	x22, sp, #1208
	bfxil	x22, x5, #0, #3
	ldrb	w5, [x22]
	and	w5, w30, w5
	str	q0, [sp, #1264]
	str	q2, [sp, #1248]
	add	x22, sp, #1248
	ldr	s3, [x22, x6, lsl #2]
	tst	w5, #0x1
	fcsel	s3, s3, s20, ne
	fadd.4s	v0, v0, v3
	and	w3, w26, w30
	tst	w3, #0x1
	fcsel	s0, s0, s20, ne
	ands	w0, w26, #0x1
	str	w0, [sp, #168]                  ; 4-byte Spill
	fadd.4s	v1, v2, v1
	fadd	s0, s1, s0
	fcsel	s1, s0, s20, ne
	and	w0, w26, w30
	str	w0, [sp, #224]                  ; 4-byte Spill
	tst	w3, #0x1
	str	w1, [sp, #256]                  ; 4-byte Spill
	and	w1, w1, w26
	fcsel	s2, s0, s20, ne
	str	w1, [sp, #188]                  ; 4-byte Spill
	tst	w1, #0x1
	and	w3, w28, w26
	fcsel	s3, s0, s20, ne
	and	w1, w28, w26
	str	w1, [sp, #208]                  ; 4-byte Spill
	tst	w3, #0x1
	str	w19, [sp, #272]                 ; 4-byte Spill
	and	w1, w19, w26
	fcsel	s5, s0, s20, ne
	str	w1, [sp, #176]                  ; 4-byte Spill
	tst	w1, #0x1
	fcsel	s6, s0, s20, ne
	and	w3, w17, w26
	and	w1, w17, w26
	str	w1, [sp, #184]                  ; 4-byte Spill
	tst	w3, #0x1
	fcsel	s7, s0, s20, ne
	and	w3, w12, w26
	and	w1, w12, w26
	str	w1, [sp, #180]                  ; 4-byte Spill
	tst	w3, #0x1
	fcsel	s19, s0, s20, ne
	and	w1, w13, w26
	and	w0, w13, w26
	str	w0, [sp, #172]                  ; 4-byte Spill
	tst	w1, #0x1
	fcsel	s0, s0, s20, ne
	mov.s	v1[1], v3[0]
	mov.s	v1[2], v5[0]
	mov.s	v1[3], v6[0]
	mov.s	v2[1], v7[0]
	mov.s	v2[2], v19[0]
	mov.s	v2[3], v0[0]
	ldr	w0, [sp, #80]                   ; 4-byte Reload
	rbit	w5, w0
	clz	w1, w5
	str	q2, [sp, #1232]
	str	q1, [sp, #1216]
	mov	x0, x1
	and	x5, x1, #0x7
	add	x6, sp, #1216
	ldr	s0, [x6, x5, lsl #2]
	mov.b	v30[0], wzr
	str	q30, [sp, #80]                  ; 16-byte Spill
	fadd	s0, s0, s20
	fmov	s1, w11
	fdiv	s0, s0, s1
	dup.4s	v0, v0[0]
	mov	w5, #1                          ; =0x1
	dup.2d	v1, x5
	ushll2.2d	v2, v17, #0
	and.16b	v27, v2, v1
	ushll2.2d	v2, v18, #0
	and.16b	v28, v2, v1
	ushll.2d	v2, v17, #0
	and.16b	v29, v2, v1
	ushll.2d	v2, v18, #0
	and.16b	v30, v2, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
LBB0_41:                                ; %direct.true111.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x15, x15, #5
	add	x5, x20, x15
	ldp	q7, q6, [x5]
	fsub.4s	v7, v7, v0
	fsub.4s	v6, v6, v0
	add	x15, x23, x15
	ldp	q19, q20, [x15]
	bif.16b	v6, v20, v17
	bif.16b	v7, v19, v18
	stp	q7, q6, [x15]
	add.2d	v2, v2, v28
	add.2d	v3, v3, v29
	add.2d	v5, v5, v27
	add.2d	v1, v1, v30
	fmov	x15, d1
	cmp	x15, #8
	b.lt	LBB0_41
; %bb.42:                               ; %direct.true148.preheader.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	fsub.4s	v3, v8, v0
	fsub.4s	v5, v31, v0
	ldr	x22, [sp, #320]                 ; 8-byte Reload
	add	x15, x23, x22
	ldp	q0, q1, [x15]
	zip2.8b	v2, v26, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	stp	q5, q3, [sp, #48]               ; 32-byte Folded Spill
	bit.16b	v1, v5, v2
	zip1.8b	v2, v26, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v0, v3, v2
	stp	q0, q1, [x15]
	ldr	q0, [sp, #2400]
	ldr	q1, [sp, #2384]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	and.16b	v6, v17, v0
	and.16b	v3, v18, v1
	ldr	q0, [sp, #2368]
	ldr	q1, [sp, #2352]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	and.16b	v22, v17, v0
	and.16b	v25, v18, v1
	ldr	q0, [sp, #2336]
	ldr	q1, [sp, #2320]
	fmul.4s	v1, v1, v1
	fmul.4s	v0, v0, v0
	and.16b	v23, v17, v0
	and.16b	v24, v18, v1
	ldr	x15, [sp, #40]                  ; 8-byte Reload
	add	x15, x23, x15
	ldp	q1, q0, [x15]
	fmul.4s	v2, v1, v1
	fmul.4s	v0, v0, v0
	and.16b	v1, v17, v0
	and.16b	v21, v18, v2
	ldr	x6, [sp, #384]                  ; 8-byte Reload
LBB0_43:                                ; %direct.true148.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v18, #0
	sshll.2d	v2, v17, #0
	add	x9, x23, x9, lsl #5
	ldp	q20, q19, [x9]
	and.16b	v20, v18, v20
	and.16b	v19, v17, v19
	fmul.4s	v19, v19, v19
	fmul.4s	v20, v20, v20
	fadd.4s	v12, v21, v20
	fadd.4s	v8, v1, v19
	ldp	q20, q19, [x9, #32]
	and.16b	v20, v18, v20
	and.16b	v19, v17, v19
	fmul.4s	v19, v19, v19
	fmul.4s	v20, v20, v20
	fadd.4s	v20, v24, v20
	fadd.4s	v19, v23, v19
	ldp	q31, q26, [x9, #64]
	and.16b	v31, v18, v31
	and.16b	v26, v17, v26
	fmul.4s	v26, v26, v26
	fmul.4s	v31, v31, v31
	fadd.4s	v31, v25, v31
	fadd.4s	v26, v22, v26
	ldp	q7, q9, [x9, #96]
	and.16b	v7, v18, v7
	and.16b	v9, v17, v9
	fmul.4s	v9, v9, v9
	fmul.4s	v7, v7, v7
	fadd.4s	v7, v3, v7
	fadd.4s	v9, v6, v9
	dup.2d	v5, x21
	and.16b	v13, v11, v5
	add.2d	v14, v14, v13
	and.16b	v13, v10, v5
	add.2d	v15, v15, v13
	and.16b	v2, v2, v5
	add.2d	v4, v4, v2
	and.16b	v0, v0, v5
	add.2d	v16, v16, v0
	bit.16b	v1, v8, v17
	bit.16b	v21, v12, v18
	bit.16b	v23, v19, v17
	bit.16b	v24, v20, v18
	bit.16b	v22, v26, v17
	bit.16b	v25, v31, v18
	bit.16b	v6, v9, v17
	bit.16b	v3, v7, v18
	fmov	x9, d16
	cmp	x9, #8
	b.lt	LBB0_43
; %bb.44:                               ; %direct.true185.i.i.preheader
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x9, #0                          ; =0x0
	movi.2d	v4, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	ldr	q26, [sp, #400]                 ; 16-byte Reload
	ldr	q13, [sp, #448]                 ; 16-byte Reload
	b	LBB0_46
LBB0_45:                                ; %else130
                                        ;   in Loop: Header=BB0_46 Depth=2
	add	x9, x24, x9
	stp	q14, q15, [x9]
	add.2d	v16, v16, v28
	add.2d	v10, v10, v29
	add.2d	v11, v11, v27
	add.2d	v4, v4, v30
	fmov	x9, d4
	cmp	x9, #8
	b.ge	LBB0_62
LBB0_46:                                ; %direct.true185.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w3, s26
	lsl	x9, x9, #5
	add	x15, x25, x9
	add	x5, x24, x9
	ldp	q14, q15, [x5]
	tbnz	w3, #0, LBB0_54
; %bb.47:                               ; %else109
                                        ;   in Loop: Header=BB0_46 Depth=2
	and	w3, w3, #0xff
	tbnz	w3, #1, LBB0_55
LBB0_48:                                ; %else112
                                        ;   in Loop: Header=BB0_46 Depth=2
	tbnz	w3, #2, LBB0_56
LBB0_49:                                ; %else115
                                        ;   in Loop: Header=BB0_46 Depth=2
	tbnz	w3, #3, LBB0_57
LBB0_50:                                ; %else118
                                        ;   in Loop: Header=BB0_46 Depth=2
	tbnz	w3, #4, LBB0_58
LBB0_51:                                ; %else121
                                        ;   in Loop: Header=BB0_46 Depth=2
	tbnz	w3, #5, LBB0_59
LBB0_52:                                ; %else124
                                        ;   in Loop: Header=BB0_46 Depth=2
	tbnz	w3, #6, LBB0_60
LBB0_53:                                ; %else127
                                        ;   in Loop: Header=BB0_46 Depth=2
	tbz	w3, #7, LBB0_45
	b	LBB0_61
LBB0_54:                                ; %cond.load108
                                        ;   in Loop: Header=BB0_46 Depth=2
	ld1.s	{ v14 }[0], [x15]
	and	w3, w3, #0xff
	tbz	w3, #1, LBB0_48
LBB0_55:                                ; %cond.load111
                                        ;   in Loop: Header=BB0_46 Depth=2
	add	x5, x15, #4
	ld1.s	{ v14 }[1], [x5]
	tbz	w3, #2, LBB0_49
LBB0_56:                                ; %cond.load114
                                        ;   in Loop: Header=BB0_46 Depth=2
	add	x5, x15, #8
	ld1.s	{ v14 }[2], [x5]
	tbz	w3, #3, LBB0_50
LBB0_57:                                ; %cond.load117
                                        ;   in Loop: Header=BB0_46 Depth=2
	add	x5, x15, #12
	ld1.s	{ v14 }[3], [x5]
	tbz	w3, #4, LBB0_51
LBB0_58:                                ; %cond.load120
                                        ;   in Loop: Header=BB0_46 Depth=2
	add	x5, x15, #16
	ld1.s	{ v15 }[0], [x5]
	tbz	w3, #5, LBB0_52
LBB0_59:                                ; %cond.load123
                                        ;   in Loop: Header=BB0_46 Depth=2
	add	x5, x15, #20
	ld1.s	{ v15 }[1], [x5]
	tbz	w3, #6, LBB0_53
LBB0_60:                                ; %cond.load126
                                        ;   in Loop: Header=BB0_46 Depth=2
	add	x5, x15, #24
	ld1.s	{ v15 }[2], [x5]
	tbz	w3, #7, LBB0_45
LBB0_61:                                ; %cond.load129
                                        ;   in Loop: Header=BB0_46 Depth=2
	add	x15, x15, #28
	ld1.s	{ v15 }[3], [x15]
	b	LBB0_45
LBB0_62:                                ; %direct.false186.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	b0, v13[0]
	mov.b	v0[4], v13[1]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	and.16b	v0, v0, v2
	mov	b2, v13[2]
	mov.b	v2[4], v13[3]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	ldp	q4, q7, [sp, #96]               ; 32-byte Folded Reload
	and.16b	v2, v2, v4
	mov	b4, v13[4]
	mov.b	v4[4], v13[5]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	mov	b5, v13[6]
	mov.b	v5[4], v13[7]
	and.16b	v4, v4, v7
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q7, [sp, #128]                  ; 16-byte Reload
	and.16b	v5, v5, v7
Lloh22:
	adrp	x9, lCPI0_11@PAGE
Lloh23:
	ldr	d7, [x9, lCPI0_11@PAGEOFF]
	shl.8b	v16, v13, #7
	cmlt.8b	v16, v16, #0
	and.8b	v7, v16, v7
	addv.8b	b7, v7
	str	d7, [sp, #144]                  ; 8-byte Spill
	fmov	w15, s7
	str	q5, [sp, #1184]
	str	q4, [sp, #1168]
	str	q2, [sp, #1152]
	str	q0, [sp, #1136]
	and	x9, x6, #0x7
	add	x3, sp, #1136
	ldr	x9, [x3, x9, lsl #3]
	sub	x9, x9, x6
	lsl	x9, x9, #2
	add	x3, x25, x9
	add	x5, x24, x22
	ldp	q9, q31, [x5]
	tbnz	w15, #0, LBB0_132
; %bb.63:                               ; %else134
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #1, LBB0_133
LBB0_64:                                ; %else137
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #2, LBB0_134
LBB0_65:                                ; %else140
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #3, LBB0_135
LBB0_66:                                ; %else143
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #4, LBB0_136
LBB0_67:                                ; %else146
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #5, LBB0_137
LBB0_68:                                ; %else149
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w15, #6, LBB0_138
LBB0_69:                                ; %else152
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w15, #7, LBB0_71
LBB0_70:                                ; %cond.load154
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x15, x3, #28
	ld1.s	{ v31 }[3], [x15]
LBB0_71:                                ; %else155
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x15, #0                         ; =0x0
	add	x3, x24, x22
	stp	q9, q31, [x3]
	movi.2d	v4, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v14, #0000000000000000
	b	LBB0_73
LBB0_72:                                ; %else180
                                        ;   in Loop: Header=BB0_73 Depth=2
	add	x15, x27, x15
	stp	q15, q16, [x15]
	add.2d	v10, v10, v28
	add.2d	v11, v11, v29
	add.2d	v14, v14, v27
	add.2d	v4, v4, v30
	fmov	x15, d4
	cmp	x15, #8
	b.ge	LBB0_89
LBB0_73:                                ; %direct.true211.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w25, s26
	lsl	x15, x15, #5
	add	x3, x4, x15
	add	x5, x27, x15
	ldp	q15, q16, [x5]
	tbnz	w25, #0, LBB0_81
; %bb.74:                               ; %else159
                                        ;   in Loop: Header=BB0_73 Depth=2
	and	w25, w25, #0xff
	tbnz	w25, #1, LBB0_82
LBB0_75:                                ; %else162
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbnz	w25, #2, LBB0_83
LBB0_76:                                ; %else165
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbnz	w25, #3, LBB0_84
LBB0_77:                                ; %else168
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbnz	w25, #4, LBB0_85
LBB0_78:                                ; %else171
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbnz	w25, #5, LBB0_86
LBB0_79:                                ; %else174
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbnz	w25, #6, LBB0_87
LBB0_80:                                ; %else177
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbz	w25, #7, LBB0_72
	b	LBB0_88
LBB0_81:                                ; %cond.load158
                                        ;   in Loop: Header=BB0_73 Depth=2
	ld1.s	{ v15 }[0], [x3]
	and	w25, w25, #0xff
	tbz	w25, #1, LBB0_75
LBB0_82:                                ; %cond.load161
                                        ;   in Loop: Header=BB0_73 Depth=2
	add	x5, x3, #4
	ld1.s	{ v15 }[1], [x5]
	tbz	w25, #2, LBB0_76
LBB0_83:                                ; %cond.load164
                                        ;   in Loop: Header=BB0_73 Depth=2
	add	x5, x3, #8
	ld1.s	{ v15 }[2], [x5]
	tbz	w25, #3, LBB0_77
LBB0_84:                                ; %cond.load167
                                        ;   in Loop: Header=BB0_73 Depth=2
	add	x5, x3, #12
	ld1.s	{ v15 }[3], [x5]
	tbz	w25, #4, LBB0_78
LBB0_85:                                ; %cond.load170
                                        ;   in Loop: Header=BB0_73 Depth=2
	add	x5, x3, #16
	ld1.s	{ v16 }[0], [x5]
	tbz	w25, #5, LBB0_79
LBB0_86:                                ; %cond.load173
                                        ;   in Loop: Header=BB0_73 Depth=2
	add	x5, x3, #20
	ld1.s	{ v16 }[1], [x5]
	tbz	w25, #6, LBB0_80
LBB0_87:                                ; %cond.load176
                                        ;   in Loop: Header=BB0_73 Depth=2
	add	x5, x3, #24
	ld1.s	{ v16 }[2], [x5]
	tbz	w25, #7, LBB0_72
LBB0_88:                                ; %cond.load179
                                        ;   in Loop: Header=BB0_73 Depth=2
	add	x3, x3, #28
	ld1.s	{ v16 }[3], [x3]
	b	LBB0_72
LBB0_89:                                ; %direct.false212.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
Lloh24:
	adrp	x15, lCPI0_12@PAGE
Lloh25:
	ldr	q0, [x15, lCPI0_12@PAGEOFF]
	and.16b	v11, v17, v0
Lloh26:
	adrp	x15, lCPI0_13@PAGE
Lloh27:
	ldr	q0, [x15, lCPI0_13@PAGEOFF]
	and.16b	v0, v18, v0
Lloh28:
	adrp	x15, lCPI0_15@PAGE
Lloh29:
	ldr	q2, [x15, lCPI0_15@PAGEOFF]
	and.16b	v10, v18, v2
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #48]                   ; 16-byte Reload
	and.16b	v4, v2, v4
	zip1.8b	v5, v13, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v7, v5, #0
	ldr	q5, [sp, #64]                   ; 16-byte Reload
	and.16b	v5, v7, v5
	fmul.4s	v16, v5, v5
	fmul.4s	v19, v4, v4
	fadd.4s	v1, v19, v1
	fadd.4s	v16, v16, v21
	and.16b	v7, v7, v16
	and.16b	v1, v2, v1
	ldr	q16, [sp, #80]                  ; 16-byte Reload
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v1, v8, v2
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bsl.16b	v2, v12, v7
	fadd.4s	v2, v24, v2
	fadd.4s	v1, v23, v1
	fadd.4s	v7, v22, v1
	fadd.4s	v1, v25, v2
	fadd.4s	v1, v3, v1
	fadd.4s	v3, v6, v7
	fmov	w15, s0
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	ldr	q2, [sp, #432]                  ; 16-byte Reload
	str	d2, [sp, #536]
	ldrb	w3, [x3]
	add	x5, sp, #1088
	orr	x15, x5, x15, lsl #2
	str	q3, [sp, #1104]
	str	q1, [sp, #1088]
	ldr	s2, [x15]
	ldr	w25, [sp, #168]                 ; 4-byte Reload
	tst	w25, w3
	mov.s	w15, v0[1]
	movi.2d	v22, #0000000000000000
	fcsel	s6, s2, s22, ne
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	ldrb	w15, [x3]
	ldr	w1, [sp, #256]                  ; 4-byte Reload
	and	w15, w1, w15
	str	q1, [sp, #1056]
	ldr	s2, [sp, #1056]
	tst	w15, #0x1
	fcsel	s7, s2, s22, ne
	mov.s	w15, v0[2]
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	add	x5, sp, #1024
	orr	x15, x5, x15, lsl #2
	ldrb	w3, [x3]
	and	w3, w28, w3
	str	q3, [sp, #1040]
	str	q1, [sp, #1024]
	ldr	s2, [x15]
	tst	w3, #0x1
	fcsel	s2, s2, s22, ne
	mov.s	w15, v0[3]
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	add	x5, sp, #992
	orr	x15, x5, x15, lsl #2
	ldrb	w3, [x3]
	ldr	w19, [sp, #272]                 ; 4-byte Reload
	and	w3, w19, w3
	stp	q1, q3, [sp, #992]
	ldr	s0, [x15]
	tst	w3, #0x1
	fcsel	s0, s0, s22, ne
	fmov	w15, s11
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	ldrb	w3, [x3]
	and	w3, w30, w3
	stp	q1, q3, [sp, #960]
	add	x5, sp, #960
	ldr	s16, [x5, w15, uxtw #2]
	tst	w3, #0x1
	fcsel	s16, s16, s22, ne
	mov.s	w15, v11[1]
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	ldrb	w3, [x3]
	and	w3, w17, w3
	stp	q1, q3, [sp, #928]
	add	x5, sp, #928
	ldr	s19, [x5, w15, uxtw #2]
	tst	w3, #0x1
	fcsel	s19, s19, s22, ne
	mov.s	w15, v11[2]
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	ldrb	w3, [x3]
	and	w3, w12, w3
	stp	q1, q3, [sp, #896]
	add	x5, sp, #896
	ldr	s20, [x5, w15, uxtw #2]
	tst	w3, #0x1
	fcsel	s20, s20, s22, ne
	mov.s	w15, v11[3]
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	ldrb	w3, [x3]
	and	w3, w13, w3
	stp	q1, q3, [sp, #864]
	add	x5, sp, #864
	ldr	s21, [x5, w15, uxtw #2]
	tst	w3, #0x1
	fcsel	s21, s21, s22, ne
	mov.s	v16[1], v19[0]
	mov.s	v16[2], v20[0]
	mov.s	v16[3], v21[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v2[0]
	mov.s	v6[3], v0[0]
	fadd.4s	v1, v1, v6
	fadd.4s	v3, v3, v16
	fmov	w15, s10
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	ldrb	w3, [x3]
	add	x5, sp, #832
	orr	x15, x5, x15, lsl #2
	stp	q1, q3, [sp, #832]
	ldr	s0, [x15]
	tst	w25, w3
	mov.s	w15, v10[1]
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	ldrb	w3, [x3]
	and	w3, w1, w3
	fcsel	s6, s0, s22, ne
	add	x5, sp, #800
	orr	x15, x5, x15, lsl #2
	stp	q1, q3, [sp, #800]
	ldr	s0, [x15]
	tst	w3, #0x1
	mov.s	w15, v10[2]
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	fcsel	s7, s0, s22, ne
	ldrb	w15, [x3]
	and	w15, w28, w15
	str	q1, [sp, #768]
	tst	w15, #0x1
	mov.s	w15, v10[3]
	movi.2d	v10, #0000000000000000
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	ldrb	w3, [x3]
	and	w3, w19, w3
Lloh30:
	adrp	x5, lCPI0_14@PAGE
Lloh31:
	ldr	q0, [x5, lCPI0_14@PAGEOFF]
	and.16b	v19, v17, v0
	ldr	s0, [sp, #768]
	fcsel	s16, s0, s10, ne
	add	x5, sp, #736
	orr	x15, x5, x15, lsl #2
	stp	q1, q3, [sp, #736]
	ldr	s0, [x15]
	tst	w3, #0x1
	fmov	w15, s19
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	ldrb	w3, [x3]
	and	w3, w30, w3
	fcsel	s0, s0, s10, ne
	stp	q1, q3, [sp, #704]
	add	x5, sp, #704
	ldr	s2, [x5, w15, uxtw #2]
	tst	w3, #0x1
	mov.s	w15, v19[1]
	add	x3, sp, #536
	bfxil	x3, x15, #0, #3
	ldrb	w3, [x3]
	and	w17, w17, w3
	fcsel	s2, s2, s10, ne
	stp	q1, q3, [sp, #672]
	add	x3, sp, #672
	ldr	s20, [x3, w15, uxtw #2]
	tst	w17, #0x1
	mov.s	w15, v19[2]
	add	x17, sp, #536
	bfxil	x17, x15, #0, #3
	ldrb	w17, [x17]
	and	w12, w12, w17
	fcsel	s20, s20, s10, ne
	stp	q1, q3, [sp, #640]
	add	x17, sp, #640
	ldr	s21, [x17, w15, uxtw #2]
	tst	w12, #0x1
	mov.s	w12, v19[3]
	add	x15, sp, #536
	bfxil	x15, x12, #0, #3
	ldrb	w15, [x15]
	and	w13, w13, w15
	movi.4s	v19, #4
	and.16b	v19, v18, v19
	fcsel	s21, s21, s10, ne
	stp	q1, q3, [sp, #608]
	add	x15, sp, #608
	ldr	s22, [x15, w12, uxtw #2]
	tst	w13, #0x1
	fcsel	s22, s22, s10, ne
	fmov	w12, s19
	add	x13, sp, #536
	orr	x13, x13, x12
	ldrb	w13, [x13]
	tst	w25, w13
	mov.s	v2[1], v20[0]
	mov.s	v2[2], v21[0]
	mov.s	v2[3], v22[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v0[0]
	fadd.4s	v0, v1, v6
	fadd.4s	v1, v3, v2
	stp	q0, q1, [sp, #576]
	add	x13, sp, #576
	ldr	s1, [x13, w12, uxtw #2]
	fcsel	s1, s1, s10, ne
	tst	w26, #0x1
	fadd	s0, s0, s1
	fcsel	s1, s0, s10, ne
	ldr	w12, [sp, #188]                 ; 4-byte Reload
	tst	w12, #0x1
	fcsel	s2, s0, s10, ne
	ldr	w12, [sp, #208]                 ; 4-byte Reload
	tst	w12, #0x1
	fcsel	s3, s0, s10, ne
	ldr	w12, [sp, #176]                 ; 4-byte Reload
	tst	w12, #0x1
	fcsel	s6, s0, s10, ne
	ldr	w12, [sp, #224]                 ; 4-byte Reload
	tst	w12, #0x1
	fcsel	s7, s0, s10, ne
	ldp	w12, w13, [sp, #180]            ; 8-byte Folded Reload
	tst	w13, #0x1
	fcsel	s16, s0, s10, ne
	tst	w12, #0x1
	fcsel	s19, s0, s10, ne
	ldr	w12, [sp, #172]                 ; 4-byte Reload
	tst	w12, #0x1
	fcsel	s0, s0, s10, ne
	mov.s	v1[1], v2[0]
	mov.s	v1[2], v3[0]
	mov.s	v1[3], v6[0]
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v19[0]
	mov.s	v7[3], v0[0]
	stp	q1, q7, [sp, #544]
	and	x12, x0, #0x7
	add	x13, sp, #544
	ldr	s6, [x13, x12, lsl #2]
	add	x9, x4, x9
	add	x12, x27, x22
	ldp	q3, q1, [x12]
	ldr	d25, [sp, #144]                 ; 8-byte Reload
	fmov	w12, s25
	tbnz	w12, #0, LBB0_139
; %bb.90:                               ; %else184
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	w30, [sp, #36]                  ; 4-byte Reload
	ldr	x17, [sp, #416]                 ; 8-byte Reload
	ldp	x0, x19, [sp, #16]              ; 16-byte Folded Reload
	ldr	w1, [sp, #240]                  ; 4-byte Reload
	tbnz	w12, #1, LBB0_140
LBB0_91:                                ; %else187
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w12, #2, LBB0_141
LBB0_92:                                ; %else190
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w12, #3, LBB0_142
LBB0_93:                                ; %else193
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w12, #4, LBB0_143
LBB0_94:                                ; %else196
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w12, #5, LBB0_144
LBB0_95:                                ; %else199
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w12, #6, LBB0_145
LBB0_96:                                ; %else202
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w12, #7, LBB0_98
LBB0_97:                                ; %cond.load204
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v1 }[3], [x9]
LBB0_98:                                ; %else205
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	x12, #0                         ; =0x0
	fadd	s0, s6, s10
	fmov	s2, w11
	fdiv	s0, s0, s2
	fmov	s2, w14
	fadd	s0, s0, s2
	fsqrt	s0, s0
	add	x9, x27, x22
	stp	q3, q1, [x9]
	dup.4s	v6, v0[0]
	ldr	q0, [sp, #288]                  ; 16-byte Reload
	fmov	x9, d0
	add	x9, x17, x9, lsl #2
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	b	LBB0_100
LBB0_99:                                ; %else222
                                        ;   in Loop: Header=BB0_100 Depth=2
	add.2d	v16, v16, v28
	add.2d	v21, v21, v29
	add.2d	v22, v22, v27
	add.2d	v7, v7, v30
	fmov	x12, d7
	cmp	x12, #8
	b.ge	LBB0_116
LBB0_100:                               ; %direct.true236.i.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s26
	lsl	x12, x12, #5
	add	x15, x23, x12
	ldp	q2, q0, [x15]
	and.16b	v2, v18, v2
	fdiv.4s	v19, v2, v6
	add	x15, x24, x12
	ldp	q20, q2, [x15]
	and.16b	v20, v18, v20
	fmul.4s	v19, v19, v20
	add	x15, x27, x12
	ldp	q20, q23, [x15]
	and.16b	v20, v18, v20
	fadd.4s	v24, v19, v20
	add	x12, x9, x12
	tbnz	w13, #0, LBB0_109
; %bb.101:                              ; %else208
                                        ;   in Loop: Header=BB0_100 Depth=2
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_110
LBB0_102:                               ; %else210
                                        ;   in Loop: Header=BB0_100 Depth=2
	tbnz	w13, #2, LBB0_111
LBB0_103:                               ; %else212
                                        ;   in Loop: Header=BB0_100 Depth=2
	tbz	w13, #3, LBB0_105
LBB0_104:                               ; %cond.store213
                                        ;   in Loop: Header=BB0_100 Depth=2
	add	x15, x12, #12
	st1.s	{ v24 }[3], [x15]
LBB0_105:                               ; %else214
                                        ;   in Loop: Header=BB0_100 Depth=2
	and.16b	v0, v17, v0
	fdiv.4s	v0, v0, v6
	and.16b	v2, v17, v2
	fmul.4s	v0, v0, v2
	and.16b	v2, v17, v23
	fadd.4s	v0, v0, v2
	tbnz	w13, #4, LBB0_112
; %bb.106:                              ; %else216
                                        ;   in Loop: Header=BB0_100 Depth=2
	tbnz	w13, #5, LBB0_113
LBB0_107:                               ; %else218
                                        ;   in Loop: Header=BB0_100 Depth=2
	tbnz	w13, #6, LBB0_114
LBB0_108:                               ; %else220
                                        ;   in Loop: Header=BB0_100 Depth=2
	tbz	w13, #7, LBB0_99
	b	LBB0_115
LBB0_109:                               ; %cond.store
                                        ;   in Loop: Header=BB0_100 Depth=2
	str	s24, [x12]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_102
LBB0_110:                               ; %cond.store209
                                        ;   in Loop: Header=BB0_100 Depth=2
	add	x15, x12, #4
	st1.s	{ v24 }[1], [x15]
	tbz	w13, #2, LBB0_103
LBB0_111:                               ; %cond.store211
                                        ;   in Loop: Header=BB0_100 Depth=2
	add	x15, x12, #8
	st1.s	{ v24 }[2], [x15]
	tbnz	w13, #3, LBB0_104
	b	LBB0_105
LBB0_112:                               ; %cond.store215
                                        ;   in Loop: Header=BB0_100 Depth=2
	str	s0, [x12, #16]
	tbz	w13, #5, LBB0_107
LBB0_113:                               ; %cond.store217
                                        ;   in Loop: Header=BB0_100 Depth=2
	add	x15, x12, #20
	st1.s	{ v0 }[1], [x15]
	tbz	w13, #6, LBB0_108
LBB0_114:                               ; %cond.store219
                                        ;   in Loop: Header=BB0_100 Depth=2
	add	x15, x12, #24
	st1.s	{ v0 }[2], [x15]
	tbz	w13, #7, LBB0_99
LBB0_115:                               ; %cond.store221
                                        ;   in Loop: Header=BB0_100 Depth=2
	add	x12, x12, #28
	st1.s	{ v0 }[3], [x12]
	b	LBB0_99
LBB0_116:                               ; %direct.false237.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	fdiv.4s	v0, v5, v6
	fmov	w9, s25
	zip1.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v5, v2, v9
	fmul.4s	v0, v0, v5
	and.16b	v2, v2, v3
	fadd.4s	v0, v0, v2
	ldr	q3, [sp, #368]                  ; 16-byte Reload
	ldp	q5, q2, [sp, #336]              ; 32-byte Folded Reload
	stp	q3, q5, [sp, #464]
	ldr	q3, [sp, #304]                  ; 16-byte Reload
	stp	q3, q2, [sp, #496]
	and	x12, x6, #0x7
	add	x13, sp, #464
	ldr	x12, [x13, x12, lsl #3]
	sub	x12, x12, x6
	add	x12, x17, x12, lsl #2
	tbnz	w9, #0, LBB0_146
; %bb.117:                              ; %else225
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #1, LBB0_147
LBB0_118:                               ; %else227
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #2, LBB0_148
LBB0_119:                               ; %else229
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w9, #3, LBB0_121
LBB0_120:                               ; %cond.store230
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x12, #12
	st1.s	{ v0 }[3], [x13]
LBB0_121:                               ; %else231
                                        ;   in Loop: Header=BB0_4 Depth=1
	fdiv.4s	v0, v4, v6
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v3, v2, v31
	fmul.4s	v0, v0, v3
	and.16b	v1, v2, v1
	fadd.4s	v0, v0, v1
	tbnz	w9, #4, LBB0_149
; %bb.122:                              ; %else233
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #5, LBB0_150
LBB0_123:                               ; %else235
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #6, LBB0_151
LBB0_124:                               ; %else237
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w9, #7, LBB0_2
	b	LBB0_152
LBB0_125:                               ; %cond.load83
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v22 }[0], [x12]
	tbz	w9, #1, LBB0_31
LBB0_126:                               ; %cond.load86
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x12, #4
	ld1.s	{ v22 }[1], [x13]
	tbz	w9, #2, LBB0_32
LBB0_127:                               ; %cond.load89
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x12, #8
	ld1.s	{ v22 }[2], [x13]
	tbz	w9, #3, LBB0_33
LBB0_128:                               ; %cond.load92
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x12, #12
	ld1.s	{ v22 }[3], [x13]
	tbz	w9, #4, LBB0_34
LBB0_129:                               ; %cond.load95
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x12, #16
	ld1.s	{ v21 }[0], [x13]
	tbz	w9, #5, LBB0_35
LBB0_130:                               ; %cond.load98
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x12, #20
	ld1.s	{ v21 }[1], [x13]
	tbz	w9, #6, LBB0_36
LBB0_131:                               ; %cond.load101
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x12, #24
	ld1.s	{ v21 }[2], [x13]
	str	q20, [sp, #448]                 ; 16-byte Spill
	str	q19, [sp, #400]                 ; 16-byte Spill
	tbnz	w9, #7, LBB0_37
	b	LBB0_38
LBB0_132:                               ; %cond.load133
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v9 }[0], [x3]
	tbz	w15, #1, LBB0_64
LBB0_133:                               ; %cond.load136
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x5, x3, #4
	ld1.s	{ v9 }[1], [x5]
	tbz	w15, #2, LBB0_65
LBB0_134:                               ; %cond.load139
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x5, x3, #8
	ld1.s	{ v9 }[2], [x5]
	tbz	w15, #3, LBB0_66
LBB0_135:                               ; %cond.load142
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x5, x3, #12
	ld1.s	{ v9 }[3], [x5]
	tbz	w15, #4, LBB0_67
LBB0_136:                               ; %cond.load145
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x5, x3, #16
	ld1.s	{ v31 }[0], [x5]
	tbz	w15, #5, LBB0_68
LBB0_137:                               ; %cond.load148
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x5, x3, #20
	ld1.s	{ v31 }[1], [x5]
	tbz	w15, #6, LBB0_69
LBB0_138:                               ; %cond.load151
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x5, x3, #24
	ld1.s	{ v31 }[2], [x5]
	tbnz	w15, #7, LBB0_70
	b	LBB0_71
LBB0_139:                               ; %cond.load183
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v3 }[0], [x9]
	ldr	w30, [sp, #36]                  ; 4-byte Reload
	ldr	x17, [sp, #416]                 ; 8-byte Reload
	ldp	x0, x19, [sp, #16]              ; 16-byte Folded Reload
	ldr	w1, [sp, #240]                  ; 4-byte Reload
	tbz	w12, #1, LBB0_91
LBB0_140:                               ; %cond.load186
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x9, #4
	ld1.s	{ v3 }[1], [x13]
	tbz	w12, #2, LBB0_92
LBB0_141:                               ; %cond.load189
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x9, #8
	ld1.s	{ v3 }[2], [x13]
	tbz	w12, #3, LBB0_93
LBB0_142:                               ; %cond.load192
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x9, #12
	ld1.s	{ v3 }[3], [x13]
	tbz	w12, #4, LBB0_94
LBB0_143:                               ; %cond.load195
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x9, #16
	ld1.s	{ v1 }[0], [x13]
	tbz	w12, #5, LBB0_95
LBB0_144:                               ; %cond.load198
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x9, #20
	ld1.s	{ v1 }[1], [x13]
	tbz	w12, #6, LBB0_96
LBB0_145:                               ; %cond.load201
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x9, #24
	ld1.s	{ v1 }[2], [x13]
	tbnz	w12, #7, LBB0_97
	b	LBB0_98
LBB0_146:                               ; %cond.store224
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x12]
	tbz	w9, #1, LBB0_118
LBB0_147:                               ; %cond.store226
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x12, #4
	st1.s	{ v0 }[1], [x13]
	tbz	w9, #2, LBB0_119
LBB0_148:                               ; %cond.store228
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x12, #8
	st1.s	{ v0 }[2], [x13]
	tbnz	w9, #3, LBB0_120
	b	LBB0_121
LBB0_149:                               ; %cond.store232
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x12, #16]
	tbz	w9, #5, LBB0_123
LBB0_150:                               ; %cond.store234
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x12, #20
	st1.s	{ v0 }[1], [x13]
	tbz	w9, #6, LBB0_124
LBB0_151:                               ; %cond.store236
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x13, x12, #24
	st1.s	{ v0 }[2], [x13]
	tbz	w9, #7, LBB0_2
LBB0_152:                               ; %cond.store238
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x12, #28
	st1.s	{ v0 }[3], [x9]
	b	LBB0_2
LBB0_153:
	add	sp, sp, #2864
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_154:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
                                        ; -- End function
.subsections_via_symbols

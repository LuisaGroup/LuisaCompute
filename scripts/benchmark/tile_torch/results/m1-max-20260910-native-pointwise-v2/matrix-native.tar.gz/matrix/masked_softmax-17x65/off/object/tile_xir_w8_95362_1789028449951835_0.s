	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.full_packet
lCPI0_0:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_1:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_2:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_3:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_4:
	.quad	0                               ; 0x0
	.quad	9                               ; 0x9
lCPI0_5:
	.quad	18                              ; 0x12
	.quad	27                              ; 0x1b
lCPI0_6:
	.quad	36                              ; 0x24
	.quad	45                              ; 0x2d
lCPI0_7:
	.quad	54                              ; 0x36
	.quad	63                              ; 0x3f
lCPI0_8:
	.quad	63                              ; 0x3f
	.quad	-1                              ; 0xffffffffffffffff
lCPI0_9:
	.quad	62                              ; 0x3e
	.quad	71                              ; 0x47
lCPI0_10:
	.quad	44                              ; 0x2c
	.quad	53                              ; 0x35
lCPI0_11:
	.quad	26                              ; 0x1a
	.quad	35                              ; 0x23
lCPI0_12:
	.quad	8                               ; 0x8
	.quad	17                              ; 0x11
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-128]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	sub	sp, sp, #1520
	mov	x11, #0                         ; =0x0
	ldr	x10, [x0]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	dup.4s	v0, w8
	fmov	s1, w8
	ushll.2d	v1, v1, #0
	fmov	x8, d1
	add	x8, x8, x8, lsl #6
	lsl	x8, x8, #2
	add	x9, x10, x8
	ldp	q1, q2, [x9, #192]
	add	x12, sp, #1232
	stp	q1, q2, [x12, #192]
	ldp	q1, q2, [x9, #224]
	stp	q1, q2, [x12, #224]
	ldp	q1, q2, [x9, #128]
	stp	q1, q2, [x12, #128]
	ldp	q1, q2, [x9, #160]
	ldp	q3, q5, [x9, #64]
	ldp	q6, q7, [x9, #96]
	ldp	q16, q17, [x9]
	ldp	q18, q19, [x9, #32]
	add	x9, x8, #256
	ldr	s4, [x10, x9]
	ldr	x10, [x0, #48]
	stp	q1, q2, [x12, #160]
	stp	q3, q5, [x12, #64]
	stp	q6, q7, [x12, #96]
	stp	q16, q17, [x12]
	stp	q18, q19, [x12, #32]
	str	q4, [x12, #256]
	movi.2d	v1, #0000000000000000
Lloh0:
	adrp	x12, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x12, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x12, lCPI0_1@PAGE
Lloh3:
	ldr	q3, [x12, lCPI0_1@PAGEOFF]
Lloh4:
	adrp	x12, lCPI0_2@PAGE
Lloh5:
	ldr	q5, [x12, lCPI0_2@PAGEOFF]
Lloh6:
	adrp	x12, lCPI0_3@PAGE
Lloh7:
	ldr	q6, [x12, lCPI0_3@PAGEOFF]
	mov	w12, #1                         ; =0x1
	dup.2d	v7, x12
	add	x12, sp, #656
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
LBB0_1:                                 ; %direct.true69
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v19, v1, #3
	shl.2d	v20, v16, #3
	shl.2d	v21, v17, #3
	shl.2d	v22, v18, #3
	orr.16b	v22, v22, v2
	orr.16b	v21, v21, v3
	orr.16b	v20, v20, v5
	orr.16b	v19, v19, v6
	add	x11, x12, x11, lsl #6
	stp	q19, q20, [x11]
	stp	q21, q22, [x11, #32]
	add.2d	v17, v17, v7
	add.2d	v16, v16, v7
	add.2d	v18, v18, v7
	add.2d	v1, v1, v7
	fmov	x11, d1
	cmp	x11, #8
	b.lt	LBB0_1
; %bb.2:                                ; %direct.false70
	mov	x12, #0                         ; =0x0
	mov	w11, #64                        ; =0x40
	str	x11, [sp, #1168]
	mov	w11, #16132                     ; =0x3f04
	movk	w11, #1008, lsl #16
	dup.4s	v1, w11
	umull2.2d	v2, v0, v1
	umull.2d	v3, v0, v1
	uzp2.4s	v3, v3, v2
	movi.4s	v5, #65
	mov.16b	v7, v0
	mls.4s	v7, v3, v5
	umull.2d	v1, v0, v1
	uzp2.4s	v1, v1, v2
	mls.4s	v0, v1, v5
	ushll2.2d	v5, v0, #0
	ushll2.2d	v6, v7, #0
	ushll.2d	v16, v0, #0
	ushll.2d	v7, v7, #0
	movi.2d	v17, #0000000000000000
	add	x11, sp, #584
	dup.2d	v18, x11
Lloh8:
	adrp	x11, lCPI0_4@PAGE
Lloh9:
	ldr	q0, [x11, lCPI0_4@PAGEOFF]
Lloh10:
	adrp	x11, lCPI0_5@PAGE
Lloh11:
	ldr	q1, [x11, lCPI0_5@PAGEOFF]
Lloh12:
	adrp	x11, lCPI0_6@PAGE
Lloh13:
	ldr	q2, [x11, lCPI0_6@PAGEOFF]
	mov	w11, #1                         ; =0x1
	dup.2d	v19, x11
Lloh14:
	adrp	x11, lCPI0_7@PAGE
Lloh15:
	ldr	q3, [x11, lCPI0_7@PAGEOFF]
	add	x11, sp, #656
	movi.8b	v20, #1
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
LBB0_3:                                 ; %direct.true85
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x11, x12, lsl #6
	ldp	q25, q24, [x12, #32]
	ldp	q26, q27, [x12]
	add.2d	v28, v23, v3
	add.2d	v28, v28, v18
	add.2d	v29, v22, v2
	add.2d	v30, v21, v1
	add.2d	v31, v17, v0
	add.2d	v31, v31, v18
	cmge.2d	v27, v6, v27
	cmge.2d	v26, v7, v26
	uzp1.4s	v26, v26, v27
	cmge.2d	v25, v16, v25
	cmge.2d	v24, v5, v24
	uzp1.4s	v24, v25, v24
	uzp1.8h	v24, v26, v24
	xtn.8b	v24, v24
	and.8b	v24, v24, v20
	mov.d	x12, v31[1]
	fmov	x13, d31
	str	b24, [x13]
	st1.b	{ v24 }[1], [x12]
	add.2d	v25, v30, v18
	mov.d	x12, v25[1]
	fmov	x13, d25
	st1.b	{ v24 }[2], [x13]
	add.2d	v25, v29, v18
	st1.b	{ v24 }[3], [x12]
	mov.d	x12, v25[1]
	fmov	x13, d25
	st1.b	{ v24 }[4], [x13]
	st1.b	{ v24 }[5], [x12]
	mov.d	x12, v28[1]
	fmov	x13, d28
	st1.b	{ v24 }[6], [x13]
	st1.b	{ v24 }[7], [x12]
	add.2d	v22, v22, v19
	add.2d	v21, v21, v19
	add.2d	v23, v23, v19
	add.2d	v17, v17, v19
	fmov	x12, d17
	cmp	x12, #8
	b.lt	LBB0_3
; %bb.4:                                ; %direct.false86
	mov	x11, #0                         ; =0x0
	add	x12, sp, #584
	dup.2d	v5, x12
Lloh16:
	adrp	x12, lCPI0_8@PAGE
Lloh17:
	ldr	q16, [x12, lCPI0_8@PAGEOFF]
Lloh18:
	adrp	x12, lCPI0_12@PAGE
Lloh19:
	ldr	q6, [x12, lCPI0_12@PAGEOFF]
	add.2d	v6, v5, v6
	cmgt.2d	v7, v7, v16
	xtn.2s	v7, v7
	uzp1.4h	v7, v7, v0
	uzp1.8b	v7, v7, v0
	movi.8b	v16, #1
	and.8b	v7, v7, v16
	fmov	x12, d6
	str	b7, [x12]
	movi.2d	v7, #0000000000000000
	add	x12, sp, #1232
	mov	w13, #62154                     ; =0xf2ca
	movk	w13, #61769, lsl #16
	dup.4s	v16, w13
	mov	w13, #1                         ; =0x1
	dup.2d	v17, x13
	add	x13, sp, #296
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB0_5:                                 ; %direct.true101
                                        ; =>This Inner Loop Header: Depth=1
	add.2d	v21, v20, v3
	add.2d	v21, v21, v5
	add.2d	v22, v19, v2
	add.2d	v22, v22, v5
	add.2d	v23, v18, v1
	add.2d	v23, v23, v5
	add.2d	v24, v7, v0
	add.2d	v24, v24, v5
	mov.d	x14, v24[1]
	mov.d	x15, v23[1]
	fmov	x16, d24
	fmov	x17, d23
	mov.d	x0, v22[1]
	fmov	x1, d22
	ldr	b22, [x16]
	ld1.b	{ v22 }[1], [x14]
	ld1.b	{ v22 }[2], [x17]
	mov.d	x14, v21[1]
	ld1.b	{ v22 }[3], [x15]
	ld1.b	{ v22 }[4], [x1]
	ld1.b	{ v22 }[5], [x0]
	fmov	x15, d21
	ld1.b	{ v22 }[6], [x15]
	ld1.b	{ v22 }[7], [x14]
	cmeq.8b	v21, v22, #0
	sshll.8h	v21, v21, #0
	sshll2.4s	v22, v21, #0
	lsl	x11, x11, #5
	add	x14, x12, x11
	ldp	q24, q23, [x14]
	sshll.4s	v21, v21, #0
	bsl.16b	v21, v16, v24
	bsl.16b	v22, v16, v23
	add	x11, x13, x11
	stp	q21, q22, [x11]
	add.2d	v19, v19, v17
	add.2d	v18, v18, v17
	add.2d	v20, v20, v17
	add.2d	v7, v7, v17
	fmov	x11, d7
	cmp	x11, #8
	b.lt	LBB0_5
; %bb.6:                                ; %direct.false102
	mov	x7, #0                          ; =0x0
	fmov	x11, d6
	ldr	b5, [x11]
	cmeq.8b	v5, v5, #0
	sshll.8h	v5, v5, #0
	sshll.4s	v6, v5, #0
	mov	w11, #62154                     ; =0xf2ca
	movk	w11, #61769, lsl #16
	dup.4s	v7, w11
	bif.16b	v7, v4, v6
	add	x11, sp, #297
	ldur	q4, [x11, #255]
	mov.s	v4[0], v7[0]
	stur	q4, [x11, #255]
	add	x11, sp, #41
	ldur	q6, [x11, #255]
	add	x11, sp, #57
	ldur	q16, [x11, #255]
	add	x11, sp, #89
	ldur	q17, [x11, #255]
	add	x11, sp, #73
	ldur	q18, [x11, #255]
	add	x11, sp, #105
	ldur	q19, [x11, #255]
	add	x11, sp, #121
	ldur	q20, [x11, #255]
	add	x11, sp, #153
	ldur	q21, [x11, #255]
	add	x11, sp, #137
	ldur	q22, [x11, #255]
	add	x11, sp, #281
	ldur	q23, [x11, #255]
	add	x11, sp, #265
	ldur	q24, [x11, #255]
	fmaxnm.4s	v22, v22, v24
	fmaxnm.4s	v21, v21, v23
	add	x11, sp, #233
	ldur	q23, [x11, #255]
	add	x11, sp, #249
	ldur	q24, [x11, #255]
	fmaxnm.4s	v20, v20, v24
	fmaxnm.4s	v19, v19, v23
	add	x11, sp, #217
	ldur	q23, [x11, #255]
	add	x11, sp, #201
	ldur	q24, [x11, #255]
	fmaxnm.4s	v18, v18, v24
	fmaxnm.4s	v17, v17, v23
	add	x11, sp, #169
	ldur	q23, [x11, #255]
	add	x11, sp, #185
	ldur	q24, [x11, #255]
	fmaxnm.4s	v16, v16, v24
	fmaxnm.4s	v23, v6, v23
	movi.2d	v6, #0000000000000000
	movi.2d	v24, #0000000000000000
	mov.s	v24[0], v7[0]
	fmaxnm.4s	v7, v23, v24
	mov.s	v23[0], v7[0]
	fmaxnm.4s	v7, v16, v17
	fmaxnm.4s	v16, v23, v18
	fmaxnm.4s	v16, v16, v19
	fmaxnm.4s	v7, v7, v20
	fmaxnm.4s	v7, v7, v21
	fmaxnm.4s	v16, v16, v22
	rev64.4s	v17, v16
	rev64.4s	v18, v7
	fmaxnm.4s	v7, v7, v18
	fmaxnm.4s	v16, v16, v17
	ext.16b	v17, v16, v16, #8
	ext.16b	v18, v7, v7, #8
	fmaxnm.4s	v7, v7, v18
	fmaxnm.4s	v16, v16, v17
	fmaxnm.4s	v7, v16, v7
	mov	w11, #-8388608                  ; =0xff800000
	fmov	s16, w11
	fmaxnm	s7, s7, s16
	dup.4s	v7, v7[0]
	add	x11, sp, #584
	add	x12, sp, #296
	mov	w13, #-1026555904               ; =0xc2d00000
	mov	w14, #1120403456                ; =0x42c80000
	mov	w15, #43579                     ; =0xaa3b
	movk	w15, #16312, lsl #16
	movi.4s	v16, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov	w16, #29184                     ; =0x7200
	movk	w16, #48945, lsl #16
	mov	w17, #48782                     ; =0xbe8e
	movk	w17, #46527, lsl #16
	mov	w0, #11226                      ; =0x2bda
	movk	w0, #14672, lsl #16
	mov	w1, #38601                      ; =0x96c9
	movk	w1, #15030, lsl #16
	mov	w2, #34982                      ; =0x88a6
	movk	w2, #15368, lsl #16
	mov	w3, #43642                      ; =0xaa7a
	movk	w3, #15658, lsl #16
	mov	w4, #43691                      ; =0xaaab
	movk	w4, #15914, lsl #16
	movi.4s	v18, #63, lsl #24
	fmov.4s	v19, #1.00000000
	mvni.4s	v20, #127, msl #16
	fneg.4s	v20, v20
	mvni.4s	v21, #63, msl #16
	fneg.4s	v21, v21
	add	x5, sp, #8
	mov	w6, #1                          ; =0x1
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
LBB0_7:                                 ; %direct.true170
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v25, x11
	add.2d	v26, v24, v3
	add.2d	v26, v26, v25
	add.2d	v27, v23, v2
	add.2d	v27, v27, v25
	add.2d	v28, v22, v1
	add.2d	v28, v28, v25
	add.2d	v29, v6, v0
	add.2d	v25, v29, v25
	mov.d	x20, v25[1]
	mov.d	x21, v28[1]
	fmov	x22, d25
	fmov	x23, d28
	mov.d	x24, v27[1]
	mov.d	x19, v26[1]
	fmov	x25, d27
	ldr	b29, [x22]
	ld1.b	{ v29 }[1], [x20]
	ld1.b	{ v29 }[2], [x23]
	fmov	x20, d26
	lsl	x7, x7, #5
	add	x22, x12, x7
	ldp	q26, q25, [x22]
	ld1.b	{ v29 }[3], [x21]
	fsub.4s	v25, v25, v7
	dup.4s	v27, w13
	ld1.b	{ v29 }[4], [x25]
	fsub.4s	v26, v26, v7
	fcmge.4s	v30, v26, v27
	dup.4s	v28, w14
	ld1.b	{ v29 }[5], [x24]
	fcmge.4s	v31, v25, v27
	fcmge.4s	v8, v28, v26
	fcmge.4s	v9, v28, v25
	and.16b	v31, v31, v9
	ld1.b	{ v29 }[6], [x20]
	and.16b	v30, v30, v8
	and.16b	v30, v30, v26
	dup.4s	v8, w15
	ld1.b	{ v29 }[7], [x19]
	and.16b	v31, v31, v25
	fmul.4s	v9, v31, v8
	fmul.4s	v8, v30, v8
	mov.16b	v10, v17
	bsl.16b	v10, v16, v8
	mov.16b	v11, v17
	bsl.16b	v11, v16, v9
	cmeq.8b	v29, v29, #0
	fadd.4s	v9, v9, v11
	fadd.4s	v8, v8, v10
	fsub.4s	v8, v8, v10
	fsub.4s	v9, v9, v11
	fcvtzs.4s	v9, v9
	sshll.8h	v10, v29, #0
	fcvtzs.4s	v8, v8
	scvtf.4s	v11, v8
	scvtf.4s	v12, v9
	dup.4s	v13, w16
	sshll2.4s	v29, v10, #0
	fmul.4s	v14, v12, v13
	fmul.4s	v13, v11, v13
	fadd.4s	v13, v30, v13
	dup.4s	v15, w17
	sshll.4s	v30, v10, #0
	fadd.4s	v31, v31, v14
	fmul.4s	v10, v11, v15
	fmul.4s	v11, v12, v15
	dup.4s	v12, w0
	fadd.4s	v31, v31, v11
	fadd.4s	v10, v13, v10
	fmul.4s	v11, v10, v12
	fmul.4s	v12, v31, v12
	dup.4s	v13, w1
	fadd.4s	v12, v12, v13
	fadd.4s	v11, v11, v13
	fmul.4s	v11, v10, v11
	fmul.4s	v12, v31, v12
	dup.4s	v13, w2
	fadd.4s	v12, v12, v13
	fadd.4s	v11, v11, v13
	fmul.4s	v11, v10, v11
	fmul.4s	v12, v31, v12
	dup.4s	v13, w3
	fadd.4s	v12, v12, v13
	fadd.4s	v11, v11, v13
	fmul.4s	v11, v10, v11
	fmul.4s	v12, v31, v12
	dup.4s	v13, w4
	fadd.4s	v12, v12, v13
	fadd.4s	v11, v11, v13
	fmul.4s	v11, v10, v11
	fmul.4s	v12, v31, v12
	fadd.4s	v12, v12, v18
	fadd.4s	v11, v11, v18
	fmul.4s	v13, v31, v31
	fmul.4s	v14, v10, v10
	fmul.4s	v11, v14, v11
	fmul.4s	v12, v13, v12
	fadd.4s	v31, v31, v12
	fadd.4s	v10, v10, v11
	fadd.4s	v10, v10, v19
	sshr.4s	v11, v8, #1
	sshr.4s	v12, v9, #1
	shl.4s	v13, v12, #23
	shl.4s	v14, v11, #23
	add.4s	v14, v14, v19
	fadd.4s	v31, v31, v19
	add.4s	v13, v13, v19
	fmul.4s	v31, v31, v13
	sub.4s	v9, v9, v12
	sub.4s	v8, v8, v11
	shl.4s	v8, v8, #23
	fmul.4s	v10, v10, v14
	shl.4s	v9, v9, #23
	add.4s	v9, v9, v19
	add.4s	v8, v8, v19
	fmul.4s	v8, v10, v8
	fcmgt.4s	v10, v27, v25
	fmul.4s	v31, v31, v9
	bic.16b	v31, v31, v10
	fcmgt.4s	v27, v27, v26
	bic.16b	v27, v8, v27
	fcmgt.4s	v8, v25, v28
	fcmgt.4s	v28, v26, v28
	bit.16b	v27, v20, v28
	mov.16b	v28, v8
	bsl.16b	v28, v20, v31
	fcmeq.4s	v26, v26, v26
	fcmeq.4s	v25, v25, v25
	bsl.16b	v25, v28, v21
	bsl.16b	v26, v27, v21
	bic.16b	v26, v26, v30
	bic.16b	v25, v25, v29
	add	x7, x5, x7
	dup.2d	v27, x6
	stp	q26, q25, [x7]
	add.2d	v23, v23, v27
	add.2d	v22, v22, v27
	add.2d	v24, v24, v27
	add.2d	v6, v6, v27
	fmov	x7, d6
	cmp	x7, #8
	b.lt	LBB0_7
; %bb.8:                                ; %direct.false171
	sshll.4s	v0, v5, #0
	fsub.4s	v2, v4, v7
	movi.2d	v1, #0000000000000000
	mov.s	v1[0], v2[0]
	mov	w11, #-1026555904               ; =0xc2d00000
	dup.4s	v2, w11
	fcmge.4s	v3, v1, v2
	mov	w11, #1120403456                ; =0x42c80000
	dup.4s	v4, w11
	fcmge.4s	v5, v4, v1
	and.16b	v3, v3, v5
	and.16b	v3, v3, v1
	mov	w11, #43579                     ; =0xaa3b
	movk	w11, #16312, lsl #16
	dup.4s	v5, w11
	fmul.4s	v5, v3, v5
	movi.4s	v6, #75, lsl #24
	mvni.4s	v7, #128, lsl #24
	bif.16b	v6, v5, v7
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	mov	w11, #29184                     ; =0x7200
	movk	w11, #48945, lsl #16
	dup.4s	v7, w11
	fmul.4s	v7, v6, v7
	fadd.4s	v3, v3, v7
	mov	w11, #48782                     ; =0xbe8e
	movk	w11, #46527, lsl #16
	dup.4s	v7, w11
	fmul.4s	v6, v6, v7
	mov	w11, #11226                     ; =0x2bda
	movk	w11, #14672, lsl #16
	dup.4s	v7, w11
	fadd.4s	v3, v3, v6
	fmul.4s	v6, v3, v7
	mov	w11, #38601                     ; =0x96c9
	movk	w11, #15030, lsl #16
	dup.4s	v7, w11
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v3, v6
	mov	w11, #34982                     ; =0x88a6
	movk	w11, #15368, lsl #16
	dup.4s	v7, w11
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v3, v6
	mov	w11, #43642                     ; =0xaa7a
	movk	w11, #15658, lsl #16
	dup.4s	v7, w11
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v3, v6
	mov	w11, #43691                     ; =0xaaab
	movk	w11, #15914, lsl #16
	dup.4s	v7, w11
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v3, v6
	movi.4s	v7, #63, lsl #24
	fadd.4s	v6, v6, v7
	fmul.4s	v7, v3, v3
	fmul.4s	v6, v7, v6
	fadd.4s	v3, v3, v6
	fmov.4s	v6, #1.00000000
	fadd.4s	v3, v3, v6
	sshr.4s	v7, v5, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v6
	fmul.4s	v3, v3, v16
	sub.4s	v5, v5, v7
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v6
	fmul.4s	v3, v3, v5
	fcmgt.4s	v2, v2, v1
	bic.16b	v2, v3, v2
	fcmgt.4s	v3, v1, v4
	mvni.4s	v4, #127, msl #16
	fneg.4s	v4, v4
	bit.16b	v2, v4, v3
	fcmeq.4s	v1, v1, v1
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	bsl.16b	v1, v2, v3
	bic.16b	v0, v1, v0
	ldur	q3, [sp, #8]
	ldur	q4, [sp, #24]
	ldur	q5, [sp, #40]
	ldur	q6, [sp, #56]
	ldur	q7, [sp, #72]
	ldur	q16, [sp, #88]
	ldur	q17, [sp, #104]
	ldur	q18, [sp, #120]
	ldur	q1, [sp, #232]
	ldur	q2, [sp, #248]
	fadd.4s	v19, v18, v2
	fadd.4s	v20, v17, v1
	ldur	q21, [sp, #200]
	ldur	q22, [sp, #216]
	fadd.4s	v23, v16, v22
	fadd.4s	v24, v7, v21
	ldur	q25, [sp, #168]
	ldur	q26, [sp, #184]
	fadd.4s	v27, v6, v26
	fadd.4s	v28, v5, v25
	ldur	q29, [sp, #136]
	ldur	q30, [sp, #152]
	fadd.4s	v31, v4, v30
	fadd.4s	v8, v3, v29
	fadd.4s	v9, v0, v8
	mov.s	v8[0], v9[0]
	fadd.4s	v28, v28, v8
	fadd.4s	v27, v27, v31
	fadd.4s	v24, v24, v28
	fadd.4s	v23, v23, v27
	fadd.4s	v20, v20, v24
	fadd.4s	v19, v19, v23
	rev64.4s	v23, v20
	rev64.4s	v24, v19
	fadd.4s	v20, v20, v23
	fadd.4s	v19, v19, v24
	dup.4s	v23, v20[2]
	dup.4s	v24, v19[2]
	fadd.4s	v20, v20, v23
	fadd.4s	v19, v19, v24
	fadd.4s	v19, v20, v19
	movi.2d	v20, #0000000000000000
	fadd	s19, s19, s20
	dup.4s	v19, v19[0]
	add	x8, x10, x8
	fdiv.4s	v3, v3, v19
	fdiv.4s	v4, v4, v19
	stp	q3, q4, [x8]
	fdiv.4s	v3, v5, v19
	fdiv.4s	v4, v6, v19
	stp	q3, q4, [x8, #32]
	fdiv.4s	v3, v7, v19
	fdiv.4s	v4, v16, v19
	stp	q3, q4, [x8, #64]
	fdiv.4s	v3, v17, v19
	fdiv.4s	v4, v18, v19
	stp	q3, q4, [x8, #96]
	fdiv.4s	v3, v29, v19
	fdiv.4s	v4, v30, v19
	stp	q3, q4, [x8, #128]
	fdiv.4s	v3, v25, v19
	fdiv.4s	v4, v26, v19
	stp	q3, q4, [x8, #160]
	fdiv.4s	v3, v21, v19
	fdiv.4s	v4, v22, v19
	stp	q3, q4, [x8, #192]
	fdiv.4s	v1, v1, v19
	fdiv.4s	v2, v2, v19
	stp	q1, q2, [x8, #224]
	fdiv.4s	v0, v0, v19
	str	s0, [x10, x9]
	add	sp, sp, #1520
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #128            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_11:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI1_12:
	.quad	32                              ; 0x20
	.quad	40                              ; 0x28
lCPI1_13:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI1_14:
	.quad	48                              ; 0x30
	.quad	56                              ; 0x38
lCPI1_15:
	.quad	54                              ; 0x36
	.quad	63                              ; 0x3f
lCPI1_16:
	.quad	18                              ; 0x12
	.quad	27                              ; 0x1b
lCPI1_17:
	.quad	36                              ; 0x24
	.quad	45                              ; 0x2d
lCPI1_18:
	.quad	0                               ; 0x0
	.quad	9                               ; 0x9
lCPI1_20:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI1_21:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI1_22:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI1_23:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_19:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3968
	str	x0, [sp, #472]                  ; 8-byte Spill
	cbz	w3, LBB1_173
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x21, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	add	x23, sp, #2456
	add	x8, sp, #3032
	dup.2d	v0, x8
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh20:
	adrp	x8, lCPI1_0@PAGE
Lloh21:
	ldr	q7, [x8, lCPI1_0@PAGEOFF]
Lloh22:
	adrp	x8, lCPI1_1@PAGE
Lloh23:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #608]                  ; 16-byte Spill
Lloh24:
	adrp	x8, lCPI1_2@PAGE
Lloh25:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #336]                  ; 16-byte Spill
	add	x28, sp, #3680
	movi.8b	v8, #1
	movi.2s	v9, #65
	mvni.4s	v0, #127, msl #16
	fneg.4s	v1, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q1, [sp, #544]              ; 32-byte Folded Spill
	add	x24, sp, #2744
	ldp	w9, w8, [x2, #44]
	str	w9, [sp, #468]                  ; 4-byte Spill
	str	w8, [sp, #464]                  ; 4-byte Spill
	ldp	w19, w27, [x2]
	ldp	w25, w8, [x2, #8]
	str	x8, [sp, #456]                  ; 8-byte Spill
	str	w3, [sp, #332]                  ; 4-byte Spill
	str	q7, [sp, #400]                  ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w21, [sp, #332]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w19, #1
	ldr	w9, [sp, #468]                  ; 4-byte Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w19, wzr, w19, eq
	cinc	w9, w27, eq
	ldr	w10, [sp, #464]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w25, w25, w8
	add	w22, w22, #1
	cmp	w22, w21
	b.eq	LBB1_173
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_41 Depth 2
                                        ;     Child Loop BB1_44 Depth 2
                                        ;     Child Loop BB1_71 Depth 2
                                        ;     Child Loop BB1_113 Depth 2
                                        ;     Child Loop BB1_116 Depth 2
                                        ;     Child Loop BB1_133 Depth 2
                                        ;     Child Loop BB1_136 Depth 2
	ubfiz	x8, x19, #5, #32
	ldr	x12, [sp, #456]                 ; 8-byte Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	stp	w19, w27, [x20]
	str	w25, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x12, #2, hi
	csel	x26, x10, xzr, ls
	cmp	x26, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x26, [sp, #472]                 ; 8-byte Reload
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x21, x26, #3
	cbz	x21, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #472]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #472]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #472]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x21, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	str	w27, [sp, #328]                 ; 4-byte Spill
	ldr	x27, [sp, #472]                 ; 8-byte Reload
	mov	x0, x27
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x27
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x27
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x27
	ldr	w27, [sp, #328]                 ; 4-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w26, #0x7
	ldr	q7, [sp, #400]                  ; 16-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v2, w8
	ldr	q0, [sp, #336]                  ; 16-byte Reload
	cmhi.4s	v0, v2, v0
	ldr	q1, [sp, #608]                  ; 16-byte Reload
	str	q2, [sp, #592]                  ; 16-byte Spill
	cmhi.4s	v11, v2, v1
	uzp1.8h	v1, v11, v0
	umaxv.8h	h2, v1
	fmov	w8, s2
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	x10, [sp, #472]                 ; 8-byte Reload
	ldr	x9, [x10]
	ldr	x10, [x10, #48]
	str	x10, [sp, #320]                 ; 8-byte Spill
	and.16b	v2, v1, v7
	addv.8h	h4, v2
	fmov	w10, s4
	and	w10, w10, #0xff
	str	w10, [sp, #204]                 ; 4-byte Spill
	ubfiz	w10, w19, #2, #27
	orr	w10, w10, w21
	dup.4s	v2, w10
	and.16b	v23, v11, v2
	and.16b	v24, v0, v2
	ushll2.2d	v6, v24, #0
	ushll2.2d	v7, v23, #0
	ushll.2d	v16, v24, #0
	ushll.2d	v3, v23, #0
	fmov	x10, d3
	mov	w11, #260                       ; =0x104
	umaddl	x10, w10, w11, x9
	str	q4, [sp, #576]                  ; 16-byte Spill
	fmov	w11, s4
	add	x16, sp, #3104
	mov	w17, #62154                     ; =0xf2ca
	movk	w17, #61769, lsl #16
	b	LBB1_15
LBB1_14:                                ; %else77
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x12, x28, x8
	stp	q2, q4, [x12]
	add	x8, x8, #32
	cmp	x8, #256
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x10, x8
	add	x14, x28, x8
	ldr	q2, [x14]
	tbnz	w11, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w13, w11, #0xff
	tbnz	w13, #1, LBB1_24
LBB1_17:                                ; %else59
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w13, #2, LBB1_25
LBB1_18:                                ; %else62
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w13, #3, LBB1_26
LBB1_19:                                ; %else65
                                        ;   in Loop: Header=BB1_15 Depth=2
	ldr	q4, [x14, #16]
	tbnz	w13, #4, LBB1_27
LBB1_20:                                ; %else68
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w13, #5, LBB1_28
LBB1_21:                                ; %else71
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w13, #6, LBB1_29
LBB1_22:                                ; %else74
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w13, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	ld1.s	{ v2 }[0], [x12]
	and	w13, w11, #0xff
	tbz	w13, #1, LBB1_17
LBB1_24:                                ; %cond.load58
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x15, x12, #4
	ld1.s	{ v2 }[1], [x15]
	tbz	w13, #2, LBB1_18
LBB1_25:                                ; %cond.load61
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x15, x12, #8
	ld1.s	{ v2 }[2], [x15]
	tbz	w13, #3, LBB1_19
LBB1_26:                                ; %cond.load64
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x15, x12, #12
	ld1.s	{ v2 }[3], [x15]
	ldr	q4, [x14, #16]
	tbz	w13, #4, LBB1_20
LBB1_27:                                ; %cond.load67
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x12, #16
	ld1.s	{ v4 }[0], [x14]
	tbz	w13, #5, LBB1_21
LBB1_28:                                ; %cond.load70
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x12, #20
	ld1.s	{ v4 }[1], [x14]
	tbz	w13, #6, LBB1_22
LBB1_29:                                ; %cond.load73
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x14, x12, #24
	ld1.s	{ v4 }[2], [x14]
	tbz	w13, #7, LBB1_14
LBB1_30:                                ; %cond.load76
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x12, x12, #28
	ld1.s	{ v4 }[3], [x12]
	b	LBB1_14
LBB1_31:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v19, v1
	sshll.2d	v1, v11, #0
	sshll.2d	v2, v0, #0
	sshll2.2d	v5, v11, #0
	sshll2.2d	v18, v0, #0
Lloh26:
	adrp	x8, lCPI1_6@PAGE
Lloh27:
	ldr	q28, [x8, lCPI1_6@PAGEOFF]
	and.16b	v20, v1, v28
Lloh28:
	adrp	x8, lCPI1_7@PAGE
Lloh29:
	ldr	q4, [x8, lCPI1_7@PAGEOFF]
	and.16b	v21, v1, v4
Lloh30:
	adrp	x8, lCPI1_8@PAGE
Lloh31:
	ldr	q1, [x8, lCPI1_8@PAGEOFF]
	and.16b	v1, v2, v1
Lloh32:
	adrp	x8, lCPI1_9@PAGE
Lloh33:
	ldr	q4, [x8, lCPI1_9@PAGEOFF]
	str	q5, [sp, #528]                  ; 16-byte Spill
	and.16b	v4, v5, v4
Lloh34:
	adrp	x8, lCPI1_10@PAGE
Lloh35:
	ldr	q5, [x8, lCPI1_10@PAGEOFF]
	and.8b	v17, v19, v8
	umov.b	w8, v17[0]
	movi.2d	v17, #0000000000000000
	mov.b	v17[0], v19[0]
	stp	q18, q19, [sp, #416]            ; 32-byte Folded Spill
	and.16b	v5, v18, v5
	str	q17, [sp, #480]                 ; 16-byte Spill
	umaxv.8b	b17, v17
	fmov	w10, s17
	rbit	w11, w8
	clz	w11, w11
	tst	w10, #0x1
	csel	w1, w11, wzr, ne
	mov	w11, #64                        ; =0x40
	dup.2d	v17, x11
	str	q20, [sp, #384]                 ; 16-byte Spill
	orr.16b	v18, v20, v17
	xtn.2s	v30, v3
	str	q18, [sp, #752]                 ; 16-byte Spill
	umlal.2d	v18, v30, v9
	movi.2d	v3, #0000000000000000
	mov.b	v3[0], v19[0]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	str	q18, [sp, #288]                 ; 16-byte Spill
	and.16b	v3, v3, v18
	movi.2d	v18, #0000000000000000
	str	q18, [sp, #2368]
	str	q18, [sp, #2352]
	str	q18, [sp, #2336]
	str	q3, [sp, #2320]
	ubfiz	x11, x1, #3, #3
	add	x12, sp, #2320
	ldr	x12, [x12, x11]
	sub	x12, x12, x1
	add	x9, x9, x12, lsl #2
	str	q5, [sp, #2432]
	str	q1, [sp, #2416]
	str	q4, [sp, #2400]
	str	q21, [sp, #176]                 ; 16-byte Spill
	str	q21, [sp, #2384]
	add	x12, sp, #2384
	ldr	x11, [x12, x11]
	orr	x11, x11, #0x100
	sub	x11, x11, w1, uxtw #2
	tst	w8, #0x1
	csel	x2, xzr, x11, eq
	add	x11, x28, x2
	ldp	q3, q12, [x11]
	tbnz	w10, #0, LBB1_89
; %bb.32:                               ; %else81
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w0, #4                          ; =0x4
	tbnz	w8, #1, LBB1_90
LBB1_33:                                ; %else84
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #2, LBB1_91
LBB1_34:                                ; %else87
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #3, LBB1_92
LBB1_35:                                ; %else90
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #4, LBB1_93
LBB1_36:                                ; %else93
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #5, LBB1_94
LBB1_37:                                ; %else96
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #6, LBB1_95
LBB1_38:                                ; %else99
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #7, LBB1_40
LBB1_39:                                ; %cond.load101
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v12 }[3], [x9]
LBB1_40:                                ; %else102
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	add	x10, x28, x2
	stp	q3, q12, [x10]
Lloh36:
	adrp	x10, lCPI1_3@PAGE
Lloh37:
	ldr	q1, [x10, lCPI1_3@PAGEOFF]
	ldr	q19, [sp, #416]                 ; 16-byte Reload
	and.16b	v18, v19, v1
Lloh38:
	adrp	x10, lCPI1_4@PAGE
Lloh39:
	ldr	q4, [x10, lCPI1_4@PAGEOFF]
	ldr	q20, [sp, #528]                 ; 16-byte Reload
	and.16b	v21, v20, v4
Lloh40:
	adrp	x10, lCPI1_5@PAGE
Lloh41:
	ldr	q5, [x10, lCPI1_5@PAGEOFF]
	and.16b	v2, v2, v5
	str	q2, [sp, #112]                  ; 16-byte Spill
	orr.16b	v26, v2, v17
	stp	q21, q18, [sp, #144]            ; 32-byte Folded Spill
	orr.16b	v29, v21, v17
	orr.16b	v27, v18, v17
	umull.2d	v2, v30, v9
	str	q2, [sp, #224]                  ; 16-byte Spill
	xtn.2s	v2, v7
	xtn.2s	v7, v16
	xtn.2s	v6, v6
	mov.16b	v16, v27
	umlal.2d	v16, v6, v9
	mov.16b	v6, v29
	umlal.2d	v6, v2, v9
	stp	q6, q16, [sp, #256]             ; 32-byte Folded Spill
	mov.16b	v2, v26
	umlal.2d	v2, v7, v9
	str	q2, [sp, #240]                  ; 16-byte Spill
	mov	w10, #1                         ; =0x1
	dup.2d	v2, x10
	ushll2.2d	v6, v0, #0
	and.16b	v6, v6, v2
	ushll2.2d	v7, v11, #0
	and.16b	v7, v7, v2
	ushll.2d	v16, v0, #0
	and.16b	v18, v16, v2
	mov.16b	v16, v20
	ushll.2d	v17, v11, #0
	and.16b	v30, v17, v2
	mov.16b	v17, v6
	mov.16b	v6, v19
	movi.2d	v2, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	str	q30, [sp, #672]                 ; 16-byte Spill
LBB1_41:                                ; %direct.true69.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v22, v0, #0
	sshll.2d	v30, v11, #0
	shl.2d	v31, v21, #3
	shl.2d	v8, v2, #3
	shl.2d	v9, v20, #3
	shl.2d	v10, v19, #3
	orr.16b	v10, v10, v4
	orr.16b	v9, v9, v5
	orr.16b	v8, v8, v28
	orr.16b	v31, v31, v1
	add	x9, x16, x9, lsl #6
	ldp	q14, q13, [x9]
	ldp	q15, q25, [x9, #32]
	bit.16b	v25, v31, v6
	bsl.16b	v30, v8, v14
	bsl.16b	v22, v9, v15
	mov.16b	v31, v16
	bsl.16b	v31, v10, v13
	stp	q30, q31, [x9]
	ldr	q30, [sp, #672]                 ; 16-byte Reload
	stp	q22, q25, [x9, #32]
	add.2d	v19, v19, v7
	add.2d	v20, v20, v18
	add.2d	v21, v21, v17
	add.2d	v2, v2, v30
	fmov	x9, d2
	cmp	x9, #8
	b.lt	LBB1_41
; %bb.42:                               ; %direct.false70.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	movi.4s	v4, #65
	and.16b	v1, v0, v4
	mvn.16b	v2, v0
	sub.4s	v1, v1, v2
	mov.s	w10, v1[1]
	mov.s	w11, v24[1]
	and.16b	v2, v11, v4
	udiv	w12, w11, w10
	mul	w10, w12, w10
	sub	w10, w11, w10
	mov.s	w11, v1[2]
	mov.s	w12, v1[3]
	fmov	w13, s1
	fmov	w14, s24
	udiv	w15, w14, w13
	mul	w13, w15, w13
	sub	w13, w14, w13
	fmov	s1, w13
	mov.s	v1[1], w10
	mov.s	w10, v24[2]
	mvn.16b	v4, v11
	udiv	w13, w10, w11
	mul	w11, w13, w11
	sub	w10, w10, w11
	mov.s	v1[2], w10
	sub.4s	v2, v2, v4
	mov.s	w10, v24[3]
	udiv	w11, w10, w12
	mul	w11, w11, w12
	sub	w10, w10, w11
	mov.s	v1[3], w10
	mov.s	w10, v2[1]
	mov.s	w11, v23[1]
	udiv	w12, w11, w10
	mul	w10, w12, w10
	sub	w10, w11, w10
	mov.s	w11, v2[2]
	mov.s	w12, v2[3]
	fmov	w13, s2
	fmov	w14, s23
	udiv	w15, w14, w13
	mul	w13, w15, w13
	sub	w13, w14, w13
	fmov	s2, w13
	mov.s	v2[1], w10
	mov.s	w10, v23[2]
	tst	w8, #0xff
	udiv	w8, w10, w11
	mul	w8, w8, w11
	sshll.2d	v22, v0, #0
	sshll.2d	v21, v11, #0
Lloh42:
	adrp	x11, lCPI1_11@PAGE
Lloh43:
	ldr	q4, [x11, lCPI1_11@PAGEOFF]
	and.16b	v4, v21, v4
Lloh44:
	adrp	x11, lCPI1_12@PAGE
Lloh45:
	ldr	q5, [x11, lCPI1_12@PAGEOFF]
	and.16b	v5, v22, v5
Lloh46:
	adrp	x11, lCPI1_13@PAGE
Lloh47:
	ldr	q19, [x11, lCPI1_13@PAGEOFF]
	and.16b	v19, v16, v19
Lloh48:
	adrp	x11, lCPI1_14@PAGE
Lloh49:
	ldr	q20, [x11, lCPI1_14@PAGEOFF]
	and.16b	v20, v6, v20
	str	q20, [sp, #2304]
	str	q5, [sp, #2288]
	str	q19, [sp, #2272]
	str	q4, [sp, #2256]
	sub	w8, w10, w8
	mov.s	v2[2], w8
	mov.s	w8, v23[3]
	udiv	w10, w8, w12
	mul	w10, w10, w12
	and	x11, x1, #0x7
	add	x12, sp, #2256
	ldr	x11, [x12, x11, lsl #3]
	orr	x11, x11, #0x200
	sub	x11, x11, x1, lsl #3
	csel	x11, xzr, x11, eq
	add	x11, x16, x11
	ldp	q19, q5, [x11, #32]
	ldp	q4, q20, [x11]
	ldr	q24, [sp, #480]                 ; 16-byte Reload
	mov	b23, v24[2]
	mov.b	v23[4], v24[3]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	bsl.16b	v23, v29, v20
	mov	b20, v24[0]
	mov.b	v20[4], v24[1]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	ldr	q25, [sp, #752]                 ; 16-byte Reload
	bit.16b	v4, v25, v20
	mov	b20, v24[6]
	mov.b	v20[4], v24[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	bit.16b	v5, v27, v20
	mov	b20, v24[4]
	mov.b	v20[4], v24[5]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	mov.16b	v8, v20
	bsl.16b	v8, v26, v19
	sub	w8, w8, w10
	mov.s	v2[3], w8
	and.16b	v20, v11, v2
	stp	q8, q5, [x11, #32]
	stp	q4, q23, [x11]
	and.16b	v19, v0, v1
	ushll2.2d	v1, v19, #0
	ushll2.2d	v2, v20, #0
	ushll.2d	v19, v19, #0
	ushll.2d	v20, v20, #0
	str	q17, [sp, #624]                 ; 16-byte Spill
	mov.16b	v17, v16
	mov.16b	v16, v6
	ldr	q6, [sp, #16]                   ; 16-byte Reload
	and.16b	v28, v16, v6
	and.16b	v29, v17, v6
	and.16b	v31, v22, v6
	and.16b	v6, v21, v6
	str	q6, [sp, #752]                  ; 16-byte Spill
Lloh50:
	adrp	x8, lCPI1_15@PAGE
Lloh51:
	ldr	q24, [x8, lCPI1_15@PAGEOFF]
	and.16b	v6, v16, v24
	str	q6, [sp, #736]                  ; 16-byte Spill
Lloh52:
	adrp	x8, lCPI1_16@PAGE
Lloh53:
	ldr	q24, [x8, lCPI1_16@PAGEOFF]
	and.16b	v6, v17, v24
	str	q6, [sp, #720]                  ; 16-byte Spill
Lloh54:
	adrp	x8, lCPI1_17@PAGE
Lloh55:
	ldr	q24, [x8, lCPI1_17@PAGEOFF]
	and.16b	v6, v22, v24
	str	q6, [sp, #704]                  ; 16-byte Spill
Lloh56:
	adrp	x8, lCPI1_18@PAGE
Lloh57:
	ldr	q22, [x8, lCPI1_18@PAGEOFF]
	and.16b	v6, v21, v22
	str	q6, [sp, #688]                  ; 16-byte Spill
	ldr	q6, [sp, #336]                  ; 16-byte Reload
	ldp	q16, q27, [sp, #576]            ; 32-byte Folded Reload
	cmhs.4s	v21, v6, v27
	ldp	q6, q17, [sp, #608]             ; 32-byte Folded Reload
	cmhs.4s	v22, v6, v27
	uzp1.8h	v21, v22, v21
	xtn.8b	v21, v21
	movi.2d	v22, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.8b	v6, #1
	b	LBB1_44
LBB1_43:                                ; %else119
                                        ;   in Loop: Header=BB1_44 Depth=2
	add.2d	v24, v24, v7
	add.2d	v25, v25, v18
	add.2d	v26, v26, v17
	add.2d	v22, v22, v30
	fmov	x9, d22
	cmp	x9, #8
	b.ge	LBB1_60
LBB1_44:                                ; %direct.true85.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w8, s16
	add	x9, x16, x9, lsl #6
	ldp	q9, q27, [x9, #32]
	ldp	q10, q13, [x9]
	cmge.2d	v13, v2, v13
	cmge.2d	v10, v20, v10
	uzp1.4s	v10, v10, v13
	cmge.2d	v9, v19, v9
	cmge.2d	v27, v1, v27
	uzp1.4s	v27, v9, v27
	uzp1.8h	v27, v10, v27
	xtn.8b	v27, v27
	orr.8b	v27, v21, v27
	ldr	q9, [sp, #688]                  ; 16-byte Reload
	add.2d	v9, v22, v9
	ldr	q10, [sp, #752]                 ; 16-byte Reload
	add.2d	v9, v10, v9
	and.8b	v27, v27, v6
	tbnz	w8, #0, LBB1_52
; %bb.45:                               ; %else105
                                        ;   in Loop: Header=BB1_44 Depth=2
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB1_53
LBB1_46:                                ; %else107
                                        ;   in Loop: Header=BB1_44 Depth=2
	ldr	q9, [sp, #720]                  ; 16-byte Reload
	add.2d	v9, v24, v9
	add.2d	v9, v29, v9
	tbnz	w8, #2, LBB1_54
LBB1_47:                                ; %else109
                                        ;   in Loop: Header=BB1_44 Depth=2
	tbnz	w8, #3, LBB1_55
LBB1_48:                                ; %else111
                                        ;   in Loop: Header=BB1_44 Depth=2
	ldr	q9, [sp, #704]                  ; 16-byte Reload
	add.2d	v9, v25, v9
	add.2d	v9, v31, v9
	tbnz	w8, #4, LBB1_56
LBB1_49:                                ; %else113
                                        ;   in Loop: Header=BB1_44 Depth=2
	tbnz	w8, #5, LBB1_57
LBB1_50:                                ; %else115
                                        ;   in Loop: Header=BB1_44 Depth=2
	ldr	q9, [sp, #736]                  ; 16-byte Reload
	add.2d	v9, v26, v9
	add.2d	v9, v28, v9
	tbnz	w8, #6, LBB1_58
LBB1_51:                                ; %else117
                                        ;   in Loop: Header=BB1_44 Depth=2
	tbz	w8, #7, LBB1_43
	b	LBB1_59
LBB1_52:                                ; %cond.store
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x9, d9
	str	b27, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB1_46
LBB1_53:                                ; %cond.store106
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x9, v9[1]
	st1.b	{ v27 }[1], [x9]
	ldr	q9, [sp, #720]                  ; 16-byte Reload
	add.2d	v9, v24, v9
	add.2d	v9, v29, v9
	tbz	w8, #2, LBB1_47
LBB1_54:                                ; %cond.store108
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x9, d9
	st1.b	{ v27 }[2], [x9]
	tbz	w8, #3, LBB1_48
LBB1_55:                                ; %cond.store110
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x9, v9[1]
	st1.b	{ v27 }[3], [x9]
	ldr	q9, [sp, #704]                  ; 16-byte Reload
	add.2d	v9, v25, v9
	add.2d	v9, v31, v9
	tbz	w8, #4, LBB1_49
LBB1_56:                                ; %cond.store112
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x9, d9
	st1.b	{ v27 }[4], [x9]
	tbz	w8, #5, LBB1_50
LBB1_57:                                ; %cond.store114
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x9, v9[1]
	st1.b	{ v27 }[5], [x9]
	ldr	q9, [sp, #736]                  ; 16-byte Reload
	add.2d	v9, v26, v9
	add.2d	v9, v28, v9
	tbz	w8, #6, LBB1_51
LBB1_58:                                ; %cond.store116
                                        ;   in Loop: Header=BB1_44 Depth=2
	fmov	x9, d9
	st1.b	{ v27 }[6], [x9]
	tbz	w8, #7, LBB1_43
LBB1_59:                                ; %cond.store118
                                        ;   in Loop: Header=BB1_44 Depth=2
	mov.d	x8, v9[1]
	st1.b	{ v27 }[7], [x8]
	b	LBB1_43
LBB1_60:                                ; %direct.false86.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	cmge.2d	v4, v20, v4
	cmge.2d	v2, v2, v23
	uzp1.4s	v2, v4, v2
	cmge.2d	v4, v19, v8
	cmge.2d	v1, v1, v5
	uzp1.4s	v1, v4, v1
	uzp1.8h	v1, v2, v1
	xtn.8b	v1, v1
Lloh58:
	adrp	x8, lCPI1_19@PAGE
Lloh59:
	ldr	d2, [x8, lCPI1_19@PAGEOFF]
	ldr	q5, [sp, #480]                  ; 16-byte Reload
	shl.8b	v4, v5, #7
	cmlt.8b	v4, v4, #0
	and.8b	v2, v4, v2
	addv.8b	b22, v2
	fmov	w12, s22
	orn.8b	v1, v1, v5
	ldr	q2, [sp, #752]                  ; 16-byte Reload
	ldr	q4, [sp, #688]                  ; 16-byte Reload
	add.2d	v4, v4, v2
	mov	w8, #8                          ; =0x8
	dup.2d	v2, x8
	add.2d	v15, v4, v2
	and.8b	v1, v1, v6
	tbnz	w12, #0, LBB1_96
; %bb.61:                               ; %else124
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x11, v15[1]
	ldr	q6, [sp, #416]                  ; 16-byte Reload
	tbnz	w12, #1, LBB1_97
LBB1_62:                                ; %else128
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q4, [sp, #720]                  ; 16-byte Reload
	add.2d	v4, v4, v29
	add.2d	v14, v4, v2
	tbnz	w12, #2, LBB1_98
LBB1_63:                                ; %else132
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x10, v14[1]
	tbnz	w12, #3, LBB1_99
LBB1_64:                                ; %else136
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q4, [sp, #704]                  ; 16-byte Reload
	add.2d	v4, v4, v31
	add.2d	v13, v4, v2
	tbnz	w12, #4, LBB1_100
LBB1_65:                                ; %else140
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x9, v13[1]
	tbnz	w12, #5, LBB1_101
LBB1_66:                                ; %else144
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q4, [sp, #736]                  ; 16-byte Reload
	add.2d	v4, v4, v28
	add.2d	v23, v4, v2
	tbnz	w12, #6, LBB1_102
LBB1_67:                                ; %else148
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x8, v23[1]
	tbz	w12, #7, LBB1_69
LBB1_68:                                ; %cond.store149
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[7], [x8]
LBB1_69:                                ; %else152
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	b	LBB1_71
LBB1_70:                                ; %else184
                                        ;   in Loop: Header=BB1_71 Depth=2
	cmeq.8b	v1, v1, #0
	sshll.8h	v1, v1, #0
	sshll2.4s	v19, v1, #0
	sshll.4s	v1, v1, #0
	lsl	x12, x12, #5
	add	x13, x28, x12
	ldp	q2, q20, [x13]
	and.16b	v20, v0, v20
	and.16b	v21, v11, v2
	dup.4s	v2, w17
	bsl.16b	v1, v2, v21
	bsl.16b	v19, v2, v20
	add	x12, x24, x12
	ldp	q20, q21, [x12]
	bif.16b	v19, v21, v0
	bif.16b	v1, v20, v11
	stp	q1, q19, [x12]
	add.2d	v9, v9, v7
	add.2d	v4, v4, v18
	add.2d	v5, v5, v17
	add.2d	v8, v8, v30
	fmov	x12, d8
	cmp	x12, #8
	b.ge	LBB1_87
LBB1_71:                                ; %direct.true101.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w13, s16
	ldr	q1, [sp, #688]                  ; 16-byte Reload
	add.2d	v1, v8, v1
	ldr	q2, [sp, #752]                  ; 16-byte Reload
	add.2d	v2, v2, v1
	tbz	w13, #0, LBB1_73
; %bb.72:                               ; %cond.load154
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x14, d2
	ldr	b1, [x14]
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_74
	b	LBB1_75
LBB1_73:                                ;   in Loop: Header=BB1_71 Depth=2
	movi.2d	v1, #0000000000000000
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_75
LBB1_74:                                ; %cond.load158
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x14, v2[1]
	ld1.b	{ v1 }[1], [x14]
LBB1_75:                                ; %else160
                                        ;   in Loop: Header=BB1_71 Depth=2
	ldr	q2, [sp, #720]                  ; 16-byte Reload
	add.2d	v2, v9, v2
	add.2d	v2, v29, v2
	tbnz	w13, #2, LBB1_81
; %bb.76:                               ; %else164
                                        ;   in Loop: Header=BB1_71 Depth=2
	tbnz	w13, #3, LBB1_82
LBB1_77:                                ; %else168
                                        ;   in Loop: Header=BB1_71 Depth=2
	ldr	q2, [sp, #704]                  ; 16-byte Reload
	add.2d	v2, v4, v2
	add.2d	v2, v31, v2
	tbnz	w13, #4, LBB1_83
LBB1_78:                                ; %else172
                                        ;   in Loop: Header=BB1_71 Depth=2
	tbnz	w13, #5, LBB1_84
LBB1_79:                                ; %else176
                                        ;   in Loop: Header=BB1_71 Depth=2
	ldr	q2, [sp, #736]                  ; 16-byte Reload
	add.2d	v2, v5, v2
	add.2d	v2, v28, v2
	tbnz	w13, #6, LBB1_85
LBB1_80:                                ; %else180
                                        ;   in Loop: Header=BB1_71 Depth=2
	tbz	w13, #7, LBB1_70
	b	LBB1_86
LBB1_81:                                ; %cond.load162
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x14, d2
	ld1.b	{ v1 }[2], [x14]
	tbz	w13, #3, LBB1_77
LBB1_82:                                ; %cond.load166
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x14, v2[1]
	ld1.b	{ v1 }[3], [x14]
	ldr	q2, [sp, #704]                  ; 16-byte Reload
	add.2d	v2, v4, v2
	add.2d	v2, v31, v2
	tbz	w13, #4, LBB1_78
LBB1_83:                                ; %cond.load170
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x14, d2
	ld1.b	{ v1 }[4], [x14]
	tbz	w13, #5, LBB1_79
LBB1_84:                                ; %cond.load174
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x14, v2[1]
	ld1.b	{ v1 }[5], [x14]
	ldr	q2, [sp, #736]                  ; 16-byte Reload
	add.2d	v2, v5, v2
	add.2d	v2, v28, v2
	tbz	w13, #6, LBB1_80
LBB1_85:                                ; %cond.load178
                                        ;   in Loop: Header=BB1_71 Depth=2
	fmov	x14, d2
	ld1.b	{ v1 }[6], [x14]
	tbz	w13, #7, LBB1_70
LBB1_86:                                ; %cond.load182
                                        ;   in Loop: Header=BB1_71 Depth=2
	mov.d	x13, v2[1]
	ld1.b	{ v1 }[7], [x13]
	b	LBB1_70
LBB1_87:                                ; %direct.true135.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w12, s22
	tbz	w12, #0, LBB1_103
; %bb.88:                               ; %cond.load187
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x13, d15
	ldr	b1, [x13]
	ldr	q16, [sp, #528]                 ; 16-byte Reload
	tbnz	w12, #1, LBB1_104
	b	LBB1_105
LBB1_89:                                ; %cond.load80
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v3 }[0], [x9]
	mov	w0, #4                          ; =0x4
	tbz	w8, #1, LBB1_33
LBB1_90:                                ; %cond.load83
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #4
	ld1.s	{ v3 }[1], [x10]
	tbz	w8, #2, LBB1_34
LBB1_91:                                ; %cond.load86
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #8
	ld1.s	{ v3 }[2], [x10]
	tbz	w8, #3, LBB1_35
LBB1_92:                                ; %cond.load89
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #12
	ld1.s	{ v3 }[3], [x10]
	tbz	w8, #4, LBB1_36
LBB1_93:                                ; %cond.load92
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #16
	ld1.s	{ v12 }[0], [x10]
	tbz	w8, #5, LBB1_37
LBB1_94:                                ; %cond.load95
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #20
	ld1.s	{ v12 }[1], [x10]
	tbz	w8, #6, LBB1_38
LBB1_95:                                ; %cond.load98
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #24
	ld1.s	{ v12 }[2], [x10]
	tbnz	w8, #7, LBB1_39
	b	LBB1_40
LBB1_96:                                ; %cond.store121
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x8, d15
	str	b1, [x8]
	mov.d	x11, v15[1]
	ldr	q6, [sp, #416]                  ; 16-byte Reload
	tbz	w12, #1, LBB1_62
LBB1_97:                                ; %cond.store125
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[1], [x11]
	ldr	q4, [sp, #720]                  ; 16-byte Reload
	add.2d	v4, v4, v29
	add.2d	v14, v4, v2
	tbz	w12, #2, LBB1_63
LBB1_98:                                ; %cond.store129
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x8, d14
	st1.b	{ v1 }[2], [x8]
	mov.d	x10, v14[1]
	tbz	w12, #3, LBB1_64
LBB1_99:                                ; %cond.store133
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[3], [x10]
	ldr	q4, [sp, #704]                  ; 16-byte Reload
	add.2d	v4, v4, v31
	add.2d	v13, v4, v2
	tbz	w12, #4, LBB1_65
LBB1_100:                               ; %cond.store137
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x8, d13
	st1.b	{ v1 }[4], [x8]
	mov.d	x9, v13[1]
	tbz	w12, #5, LBB1_66
LBB1_101:                               ; %cond.store141
                                        ;   in Loop: Header=BB1_4 Depth=1
	st1.b	{ v1 }[5], [x9]
	ldr	q4, [sp, #736]                  ; 16-byte Reload
	add.2d	v4, v4, v28
	add.2d	v23, v4, v2
	tbz	w12, #6, LBB1_67
LBB1_102:                               ; %cond.store145
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x8, d23
	st1.b	{ v1 }[6], [x8]
	mov.d	x8, v23[1]
	tbnz	w12, #7, LBB1_68
	b	LBB1_69
LBB1_103:                               ;   in Loop: Header=BB1_4 Depth=1
	movi.2d	v1, #0000000000000000
	ldr	q16, [sp, #528]                 ; 16-byte Reload
	tbz	w12, #1, LBB1_105
LBB1_104:                               ; %cond.load193
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[1], [x11]
LBB1_105:                               ; %else197
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #2, LBB1_161
; %bb.106:                              ; %else203
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #3, LBB1_162
LBB1_107:                               ; %else209
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #4, LBB1_163
LBB1_108:                               ; %else215
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #5, LBB1_164
LBB1_109:                               ; %else221
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w12, #6, LBB1_165
LBB1_110:                               ; %else227
                                        ;   in Loop: Header=BB1_4 Depth=1
	stp	q29, q28, [sp, #512]            ; 32-byte Folded Spill
	str	q31, [sp, #496]                 ; 16-byte Spill
	stp	q18, q7, [sp, #640]             ; 32-byte Folded Spill
	str	d22, [sp, #208]                 ; 8-byte Spill
	tbz	w12, #7, LBB1_112
LBB1_111:                               ; %cond.load229
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[7], [x8]
LBB1_112:                               ; %else233
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w25, [sp, #104]                 ; 4-byte Spill
	str	w22, [sp, #140]                 ; 4-byte Spill
	str	x1, [sp, #312]                  ; 8-byte Spill
	str	w27, [sp, #328]                 ; 4-byte Spill
	sshll.2d	v4, v11, #0
	sshll.2d	v5, v0, #0
	cmeq.8b	v1, v1, #0
	sshll.8h	v1, v1, #0
	sshll2.4s	v7, v1, #0
	str	q1, [sp, #48]                   ; 16-byte Spill
	sshll.4s	v1, v1, #0
	ldr	q17, [sp, #480]                 ; 16-byte Reload
	zip2.8b	v19, v17, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	and.16b	v20, v19, v12
	zip1.8b	v21, v17, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	and.16b	v3, v21, v3
	bit.16b	v3, v2, v1
	str	q7, [sp, #80]                   ; 16-byte Spill
	bsl.16b	v7, v2, v20
	str	x2, [sp, #216]                  ; 8-byte Spill
	add	x8, x24, x2
	ldp	q1, q2, [x8]
	stp	q7, q3, [sp, #352]              ; 32-byte Folded Spill
	bit.16b	v2, v7, v19
	bit.16b	v1, v3, v21
	stp	q1, q2, [x8]
	ldr	q1, [sp, #176]                  ; 16-byte Reload
	fmov	x8, d1
	dup.2d	v1, x0
	and.16b	v13, v6, v1
	and.16b	v14, v16, v1
	and.16b	v15, v5, v1
	and.16b	v9, v4, v1
	fmov	x14, d9
	ldp	q1, q2, [x23, #384]
	and.16b	v4, v0, v2
	and.16b	v3, v11, v1
	ldp	q1, q2, [x23, #352]
	and.16b	v5, v0, v2
	and.16b	v2, v11, v1
	ldp	q19, q1, [x23, #320]
	and.16b	v1, v0, v1
	and.16b	v19, v11, v19
	str	x8, [sp, #72]                   ; 8-byte Spill
	add	x8, x24, x8
	ldp	q21, q20, [x8]
	and.16b	v20, v0, v20
	mov	x8, x14
	and.16b	v21, v11, v21
	mov.16b	v24, v9
	mov.16b	v25, v14
	mov.16b	v26, v15
	mov.16b	v27, v13
	mov.16b	v17, v16
	mov.16b	v16, v6
LBB1_113:                               ; %direct.true135.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v8, v11, #0
	sshll.2d	v10, v0, #0
	add	x8, x24, x8, lsl #5
	ldp	q22, q23, [x8]
	and.16b	v23, v0, v23
	and.16b	v22, v11, v22
	fmaxnm.4s	v22, v21, v22
	fmaxnm.4s	v23, v20, v23
	ldp	q12, q18, [x8, #32]
	and.16b	v18, v0, v18
	and.16b	v12, v11, v12
	fmaxnm.4s	v12, v19, v12
	fmaxnm.4s	v18, v1, v18
	ldp	q28, q29, [x8, #64]
	and.16b	v29, v0, v29
	and.16b	v28, v11, v28
	fmaxnm.4s	v28, v2, v28
	fmaxnm.4s	v29, v5, v29
	ldp	q30, q31, [x8, #96]
	and.16b	v31, v0, v31
	and.16b	v30, v11, v30
	fmaxnm.4s	v30, v3, v30
	fmaxnm.4s	v31, v4, v31
	dup.2d	v6, x0
	and.16b	v7, v16, v6
	add.2d	v27, v27, v7
	and.16b	v7, v17, v6
	add.2d	v25, v25, v7
	and.16b	v7, v10, v6
	add.2d	v26, v26, v7
	and.16b	v6, v8, v6
	add.2d	v24, v24, v6
	bit.16b	v20, v23, v0
	bit.16b	v21, v22, v11
	bit.16b	v1, v18, v0
	bit.16b	v19, v12, v11
	bit.16b	v5, v29, v0
	bit.16b	v2, v28, v11
	bit.16b	v4, v31, v0
	bit.16b	v3, v30, v11
	fmov	x8, d24
	cmp	x8, #8
	b.lt	LBB1_113
; %bb.114:                              ; %direct.false136.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	ldr	q16, [sp, #480]                 ; 16-byte Reload
	zip1.8b	v6, v16, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q7, [sp, #368]                  ; 16-byte Reload
	and.16b	v7, v6, v7
	zip2.8b	v18, v16, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	ldr	q16, [sp, #352]                 ; 16-byte Reload
	and.16b	v24, v18, v16
	fmaxnm.4s	v20, v20, v24
	fmaxnm.4s	v7, v21, v7
	and.16b	v6, v6, v7
	and.16b	v7, v18, v20
	ldr	q24, [sp, #432]                 ; 16-byte Reload
	zip2.8b	v18, v24, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	movi.2d	v20, #0000000000000000
	mov.b	v20[2], v24[1]
	mov.b	v20[4], v24[2]
	mov.b	v20[6], v24[3]
	bit.16b	v7, v23, v18
	ushll.4s	v18, v20, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	bit.16b	v6, v22, v18
	fmaxnm.4s	v6, v6, v19
	fmaxnm.4s	v1, v7, v1
	fmaxnm.4s	v1, v1, v5
	fmaxnm.4s	v2, v6, v2
	fmaxnm.4s	v3, v2, v3
	fmaxnm.4s	v18, v1, v4
	ldr	q1, [sp, #384]                  ; 16-byte Reload
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	uzp1.4s	v5, v1, v2
	ldr	q1, [sp, #160]                  ; 16-byte Reload
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	uzp1.4s	v2, v2, v1
	movi.4s	v4, #1
	eor.16b	v1, v5, v4
	mov.s	w10, v1[1]
	mov.s	w11, v1[2]
	eor.16b	v20, v2, v4
	mov.s	w15, v1[3]
	fmov	w8, s1
	add	x12, sp, #1432
	bfxil	x12, x8, #0, #3
	str	d24, [sp, #1432]
	ldrb	w13, [x12]
	and	x8, x8, #0x7
	umov.b	w22, v24[0]
	str	q18, [sp, #2096]
	str	q3, [sp, #2080]
	add	x16, sp, #2080
	ldr	s1, [x16, x8, lsl #2]
	ands	w8, w22, #0x1
	tst	w8, w13
	movi.2d	v16, #0000000000000000
	fcsel	s4, s1, s16, ne
	and	x13, x10, #0x7
	add	x16, sp, #1432
	bfxil	x16, x10, #0, #3
	ldrb	w10, [x16]
	umov.b	w6, v24[1]
	and	w10, w6, w10
	str	w6, [sp, #384]                  ; 4-byte Spill
	str	q18, [sp, #2064]
	str	q3, [sp, #2048]
	add	x17, sp, #2048
	ldr	s1, [x17, x13, lsl #2]
	tst	w10, #0x1
	fcsel	s1, s1, s16, ne
	and	x10, x11, #0x7
	add	x17, sp, #1432
	bfxil	x17, x11, #0, #3
	umov.b	w25, v24[2]
	ldrb	w11, [x17]
	and	w11, w25, w11
	str	q18, [sp, #2032]
	str	q3, [sp, #2016]
	add	x17, sp, #2016
	ldr	s6, [x17, x10, lsl #2]
	tst	w11, #0x1
	fcsel	s19, s6, s16, ne
	and	x10, x15, #0x7
	add	x11, sp, #1432
	bfxil	x11, x15, #0, #3
	ldrb	w11, [x11]
	umov.b	w16, v24[3]
	str	q18, [sp, #2000]
	str	q3, [sp, #1984]
	add	x17, sp, #1984
	ldr	s6, [x17, x10, lsl #2]
	and	w10, w16, w11
	tst	w10, #0x1
	mov.s	w10, v20[1]
	mov.s	w11, v20[2]
	fcsel	s21, s6, s16, ne
	mov.s	w2, v20[3]
	fmov	w17, s20
	and	x0, x17, #0x7
	add	x1, sp, #1432
	bfxil	x1, x17, #0, #3
	ldrb	w1, [x1]
	umov.b	w13, v24[4]
	and	w1, w13, w1
	str	q18, [sp, #2224]
	str	q3, [sp, #2208]
	add	x17, sp, #2208
	ldr	s6, [x17, x0, lsl #2]
	tst	w1, #0x1
	fcsel	s6, s6, s16, ne
	and	x1, x10, #0x7
	add	x0, sp, #1432
	bfxil	x0, x10, #0, #3
	ldrb	w10, [x0]
	umov.b	w15, v24[5]
	and	w10, w15, w10
	str	q18, [sp, #2192]
	str	q3, [sp, #2176]
	add	x17, sp, #2176
	ldr	s7, [x17, x1, lsl #2]
	tst	w10, #0x1
	fcsel	s7, s7, s16, ne
	and	x10, x11, #0x7
	add	x1, sp, #1432
	bfxil	x1, x11, #0, #3
	ldrb	w11, [x1]
	umov.b	w12, v24[6]
	and	w11, w12, w11
	str	q18, [sp, #2160]
	str	q3, [sp, #2144]
	add	x17, sp, #2144
	ldr	s20, [x17, x10, lsl #2]
	tst	w11, #0x1
	fcsel	s20, s20, s16, ne
	and	x10, x2, #0x7
	add	x11, sp, #1432
	bfxil	x11, x2, #0, #3
	umov.b	w2, v24[7]
	ldrb	w11, [x11]
	and	w11, w2, w11
	str	q18, [sp, #2128]
	str	q3, [sp, #2112]
	add	x17, sp, #2112
	ldr	s22, [x17, x10, lsl #2]
	tst	w11, #0x1
	fcsel	s22, s22, s16, ne
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v20[0]
	mov.s	v6[3], v22[0]
	mov.s	v4[1], v1[0]
	mov.s	v4[2], v19[0]
	mov.s	v4[3], v21[0]
	fmaxnm.4s	v3, v3, v4
	fmaxnm.4s	v4, v18, v6
	movi.4s	v6, #2
	eor.16b	v1, v5, v6
	mov.s	w10, v1[1]
	mov.s	w11, v1[2]
	mov.s	w3, v1[3]
	eor.16b	v19, v2, v6
	fmov	w4, s1
	add	x5, sp, #1432
	bfxil	x5, x4, #0, #3
	ldrb	w5, [x5]
	and	x4, x4, #0x7
	str	q4, [sp, #1968]
	str	q3, [sp, #1952]
	add	x17, sp, #1952
	ldr	s1, [x17, x4, lsl #2]
	tst	w8, w5
	fcsel	s2, s1, s16, ne
	and	x4, x10, #0x7
	add	x5, sp, #1432
	bfxil	x5, x10, #0, #3
	ldrb	w10, [x5]
	and	w10, w6, w10
	str	q4, [sp, #1936]
	str	q3, [sp, #1920]
	add	x17, sp, #1920
	ldr	s1, [x17, x4, lsl #2]
	tst	w10, #0x1
	fcsel	s18, s1, s16, ne
	and	x10, x11, #0x7
	add	x4, sp, #1432
	bfxil	x4, x11, #0, #3
	ldrb	w11, [x4]
	and	w11, w25, w11
	str	q4, [sp, #1904]
	str	q3, [sp, #1888]
	add	x17, sp, #1888
	ldr	s1, [x17, x10, lsl #2]
	tst	w11, #0x1
	fcsel	s1, s1, s16, ne
	and	x10, x3, #0x7
	add	x11, sp, #1432
	bfxil	x11, x3, #0, #3
	ldrb	w11, [x11]
	str	q4, [sp, #1872]
	str	q3, [sp, #1856]
	add	x17, sp, #1856
	ldr	s20, [x17, x10, lsl #2]
	and	w10, w16, w11
	tst	w10, #0x1
	mov.s	w3, v19[3]
	mov.s	w17, v19[1]
	fmov	w10, s19
	and	x0, x10, #0x7
	add	x1, sp, #1432
	bfxil	x1, x10, #0, #3
	add	x10, sp, #1432
	bfxil	x10, x3, #0, #3
	ldrb	w26, [x10]
	movi.4s	v6, #4
	eor.16b	v5, v5, v6
	mov.s	w4, v5[1]
	mov.s	w11, v5[2]
	mov.s	w10, v5[3]
	fmov	w30, s5
	add	x5, sp, #1432
	bfxil	x5, x30, #0, #3
	ldrb	w7, [x5]
	add	x5, sp, #1432
	bfxil	x5, x4, #0, #3
	ldrb	w21, [x5]
	add	x5, sp, #1432
	bfxil	x5, x11, #0, #3
	ldrb	w6, [x5]
	add	x5, sp, #1432
	bfxil	x5, x10, #0, #3
	ldrb	w5, [x5]
	ldrb	w1, [x1]
	str	q4, [sp, #1840]
	str	q3, [sp, #1824]
	add	x27, sp, #1824
	ldr	s5, [x27, x0, lsl #2]
	add	x0, sp, #1432
	bfxil	x0, x17, #0, #3
	and	x17, x17, #0x7
	ldrb	w0, [x0]
	str	q4, [sp, #1808]
	str	q3, [sp, #1792]
	add	x27, sp, #1792
	ldr	s6, [x27, x17, lsl #2]
	fcsel	s7, s20, s16, ne
	and	w17, w13, w1
	tst	w17, #0x1
	mov.s	w17, v19[2]
	fcsel	s5, s5, s16, ne
	and	w0, w15, w0
	tst	w0, #0x1
	add	x0, sp, #1432
	bfxil	x0, x17, #0, #3
	and	x17, x17, #0x7
	ldrb	w0, [x0]
	str	q4, [sp, #1776]
	str	q3, [sp, #1760]
	add	x1, sp, #1760
	ldr	s19, [x1, x17, lsl #2]
	fcsel	s6, s6, s16, ne
	and	w17, w12, w0
	tst	w17, #0x1
	and	x17, x3, #0x7
	str	q4, [sp, #1744]
	str	q3, [sp, #1728]
	add	x0, sp, #1728
	ldr	s20, [x0, x17, lsl #2]
	fcsel	s19, s19, s16, ne
	and	w17, w2, w26
	tst	w17, #0x1
	fcsel	s20, s20, s16, ne
	mov.s	v5[1], v6[0]
	mov.s	v5[2], v19[0]
	mov.s	v5[3], v20[0]
	mov.s	v2[1], v18[0]
	mov.s	v2[2], v1[0]
	mov.s	v2[3], v7[0]
	fmaxnm.4s	v1, v3, v2
	fmaxnm.4s	v2, v4, v5
	and	x17, x30, #0x7
	str	q2, [sp, #1712]
	str	q1, [sp, #1696]
	add	x0, sp, #1696
	ldr	s3, [x0, x17, lsl #2]
	tst	w8, w7
	fcsel	s3, s3, s16, ne
	and	x8, x4, #0x7
	ldr	w1, [sp, #384]                  ; 4-byte Reload
	and	w17, w1, w21
	str	q2, [sp, #1680]
	str	q1, [sp, #1664]
	add	x0, sp, #1664
	ldr	s4, [x0, x8, lsl #2]
	tst	w17, #0x1
	fcsel	s4, s4, s16, ne
	and	x8, x11, #0x7
	and	w11, w25, w6
	str	q2, [sp, #1648]
	str	q1, [sp, #1632]
	add	x17, sp, #1632
	ldr	s5, [x17, x8, lsl #2]
	tst	w11, #0x1
	fcsel	s5, s5, s16, ne
	and	x8, x10, #0x7
	and	w10, w16, w5
	str	q2, [sp, #1616]
	str	q1, [sp, #1600]
	add	x11, sp, #1600
	ldr	s2, [x11, x8, lsl #2]
	tst	w10, #0x1
	fcsel	s2, s2, s16, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v5[0]
	mov.s	v3[3], v2[0]
	ands	w6, w22, #0x1
	fmaxnm.4s	v1, v1, v3
	fcsel	s2, s1, s16, ne
	and	w8, w1, w22
	str	w8, [sp, #44]                   ; 4-byte Spill
	tst	w8, #0x1
	fcsel	s3, s1, s16, ne
	str	w25, [sp, #160]                 ; 4-byte Spill
	and	w5, w25, w22
	tst	w5, #0x1
	fcsel	s4, s1, s16, ne
	stp	w16, w15, [sp, #108]            ; 8-byte Folded Spill
	and	w7, w16, w22
	tst	w7, #0x1
	fcsel	s5, s1, s16, ne
	str	w13, [sp, #176]                 ; 4-byte Spill
	and	w30, w13, w22
	tst	w30, #0x1
	fcsel	s6, s1, s16, ne
	and	w8, w15, w22
	tst	w8, #0x1
	fcsel	s7, s1, s16, ne
	mov	x16, x12
	and	w11, w12, w22
	tst	w11, #0x1
	fcsel	s18, s1, s16, ne
	str	w22, [sp, #144]                 ; 4-byte Spill
	and	w3, w2, w22
	tst	w3, #0x1
	fcsel	s1, s1, s16, ne
	mov.s	v2[1], v3[0]
	mov.s	v2[2], v4[0]
	mov.s	v2[3], v5[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v18[0]
	mov.s	v6[3], v1[0]
	ldr	w10, [sp, #204]                 ; 4-byte Reload
	rbit	w10, w10
	clz	w10, w10
	str	q6, [sp, #1456]
	str	q2, [sp, #1440]
	and	x17, x10, #0x7
	add	x0, sp, #1440
	ldr	s1, [x0, x17, lsl #2]
	mov.b	v24[0], wzr
	str	q24, [sp, #432]                 ; 16-byte Spill
	mov	w17, #-8388608                  ; =0xff800000
	fmov	s2, w17
	fmaxnm	s1, s1, s2
	dup.4s	v4, v1[0]
	movi.2d	v5, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v23, #0000000000000000
	ldr	w27, [sp, #328]                 ; 4-byte Reload
	mov	w0, #-1026555904                ; =0xc2d00000
	mov	w1, #1120403456                 ; =0x42c80000
	mov	w21, #43579                     ; =0xaa3b
	movk	w21, #16312, lsl #16
	mov	w26, #29184                     ; =0x7200
	movk	w26, #48945, lsl #16
	ldr	w22, [sp, #140]                 ; 4-byte Reload
	ldr	w25, [sp, #104]                 ; 4-byte Reload
	b	LBB1_116
LBB1_115:                               ; %else282
                                        ;   in Loop: Header=BB1_116 Depth=2
	ldp	q2, q1, [sp, #592]              ; 32-byte Folded Reload
	cmhi.4s	v2, v2, v1
	lsl	x9, x9, #5
	add	x17, x24, x9
	ldp	q6, q1, [x17]
	fsub.4s	v6, v6, v4
	fsub.4s	v1, v1, v4
	and.16b	v27, v0, v1
	and.16b	v26, v2, v6
	dup.4s	v12, w0
	fcmge.4s	v1, v26, v12
	fcmge.4s	v6, v27, v12
	dup.4s	v8, w1
	fcmge.4s	v7, v8, v26
	fcmge.4s	v19, v8, v27
	and.16b	v6, v6, v19
	and.16b	v1, v1, v7
	and.16b	v7, v1, v26
	and.16b	v6, v6, v27
	dup.4s	v10, w21
	fmul.4s	v1, v6, v10
	fmul.4s	v19, v7, v10
	movi.4s	v16, #75, lsl #24
	mvni.4s	v21, #128, lsl #24
	mov.16b	v20, v21
	bsl.16b	v20, v16, v19
	bsl.16b	v21, v16, v1
	fadd.4s	v1, v1, v21
	fadd.4s	v19, v19, v20
	fsub.4s	v19, v19, v20
	fsub.4s	v1, v1, v21
	fcvtzs.4s	v28, v1
	fcvtzs.4s	v29, v19
	scvtf.4s	v20, v29
	dup.4s	v1, w26
	scvtf.4s	v21, v28
	fmul.4s	v22, v21, v1
	fmul.4s	v19, v20, v1
	fadd.4s	v7, v7, v19
	mov	w17, #48782                     ; =0xbe8e
	movk	w17, #46527, lsl #16
	dup.4s	v19, w17
	fadd.4s	v6, v6, v22
	fmul.4s	v20, v20, v19
	fmul.4s	v21, v21, v19
	fadd.4s	v6, v6, v21
	mov	w17, #11226                     ; =0x2bda
	movk	w17, #14672, lsl #16
	dup.4s	v21, w17
	fadd.4s	v7, v7, v20
	fmul.4s	v20, v7, v21
	fmul.4s	v24, v6, v21
	mov	w17, #38601                     ; =0x96c9
	movk	w17, #15030, lsl #16
	dup.4s	v22, w17
	fadd.4s	v24, v24, v22
	fadd.4s	v20, v20, v22
	fmul.4s	v25, v7, v20
	fmul.4s	v24, v6, v24
	mov	w17, #34982                     ; =0x88a6
	movk	w17, #15368, lsl #16
	dup.4s	v20, w17
	fadd.4s	v24, v24, v20
	fadd.4s	v25, v25, v20
	fmul.4s	v25, v7, v25
	fmul.4s	v30, v6, v24
	mov	w17, #43642                     ; =0xaa7a
	movk	w17, #15658, lsl #16
	dup.4s	v24, w17
	fadd.4s	v30, v30, v24
	fadd.4s	v25, v25, v24
	fmul.4s	v31, v7, v25
	fmul.4s	v30, v6, v30
	mov	w17, #43691                     ; =0xaaab
	movk	w17, #15914, lsl #16
	dup.4s	v25, w17
	fadd.4s	v30, v30, v25
	fadd.4s	v31, v31, v25
	fmul.4s	v31, v7, v31
	fmul.4s	v30, v6, v30
	movi.4s	v16, #63, lsl #24
	fadd.4s	v30, v30, v16
	fadd.4s	v31, v31, v16
	fmul.4s	v16, v7, v7
	fmul.4s	v16, v16, v31
	fmul.4s	v31, v6, v6
	fmul.4s	v30, v31, v30
	fadd.4s	v6, v6, v30
	fadd.4s	v7, v7, v16
	fmov.4s	v17, #1.00000000
	fadd.4s	v7, v7, v17
	fadd.4s	v6, v6, v17
	sshr.4s	v16, v29, #1
	sshr.4s	v30, v28, #1
	shl.4s	v31, v30, #23
	add.4s	v31, v31, v17
	fmul.4s	v6, v6, v31
	shl.4s	v31, v16, #23
	add.4s	v31, v31, v17
	fmul.4s	v7, v7, v31
	sub.4s	v28, v28, v30
	sub.4s	v16, v29, v16
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v17
	fmul.4s	v7, v7, v16
	shl.4s	v16, v28, #23
	add.4s	v16, v16, v17
	fmul.4s	v6, v6, v16
	fcmgt.4s	v16, v12, v27
	bic.16b	v6, v6, v16
	fcmgt.4s	v16, v12, v26
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v26, v8
	ldp	q17, q28, [sp, #544]            ; 32-byte Folded Reload
	bit.16b	v7, v28, v16
	fcmgt.4s	v16, v27, v8
	bit.16b	v6, v28, v16
	fcmeq.4s	v16, v27, v27
	bif.16b	v6, v17, v16
	cmeq.8b	v3, v3, #0
	sshll.8h	v3, v3, #0
	fcmeq.4s	v16, v26, v26
	bif.16b	v7, v17, v16
	sshll.4s	v16, v3, #0
	bic.16b	v7, v7, v16
	sshll2.4s	v3, v3, #0
	bic.16b	v3, v6, v3
	add	x9, x23, x9
	ldr	q6, [x9, #16]
	bif.16b	v3, v6, v0
	ldr	q6, [x9]
	bit.16b	v6, v7, v2
	stp	q6, q3, [x9]
	ldp	q3, q6, [sp, #640]              ; 32-byte Folded Reload
	add.2d	v18, v18, v6
	add.2d	v11, v11, v3
	ldr	q3, [sp, #624]                  ; 16-byte Reload
	add.2d	v23, v23, v3
	ldr	q3, [sp, #672]                  ; 16-byte Reload
	add.2d	v5, v5, v3
	fmov	x9, d5
	cmp	x9, #8
	b.ge	LBB1_132
LBB1_116:                               ; %direct.true170.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q1, [sp, #576]                  ; 16-byte Reload
	fmov	w4, s1
	ldr	q1, [sp, #688]                  ; 16-byte Reload
	add.2d	v1, v5, v1
	ldr	q2, [sp, #752]                  ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w4, #0, LBB1_118
; %bb.117:                              ; %cond.load236
                                        ;   in Loop: Header=BB1_116 Depth=2
	fmov	x17, d1
	ldr	b3, [x17]
	ldp	q6, q2, [sp, #512]              ; 32-byte Folded Reload
	ldr	q7, [sp, #496]                  ; 16-byte Reload
	and	w4, w4, #0xff
	tbnz	w4, #1, LBB1_119
	b	LBB1_120
LBB1_118:                               ;   in Loop: Header=BB1_116 Depth=2
	movi.2d	v3, #0000000000000000
	ldp	q6, q2, [sp, #512]              ; 32-byte Folded Reload
	ldr	q7, [sp, #496]                  ; 16-byte Reload
	and	w4, w4, #0xff
	tbz	w4, #1, LBB1_120
LBB1_119:                               ; %cond.load242
                                        ;   in Loop: Header=BB1_116 Depth=2
	mov.d	x17, v1[1]
	ld1.b	{ v3 }[1], [x17]
LBB1_120:                               ; %else246
                                        ;   in Loop: Header=BB1_116 Depth=2
	ldr	q1, [sp, #720]                  ; 16-byte Reload
	add.2d	v1, v18, v1
	add.2d	v1, v6, v1
	tbnz	w4, #2, LBB1_126
; %bb.121:                              ; %else252
                                        ;   in Loop: Header=BB1_116 Depth=2
	tbnz	w4, #3, LBB1_127
LBB1_122:                               ; %else258
                                        ;   in Loop: Header=BB1_116 Depth=2
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	add.2d	v1, v11, v1
	add.2d	v1, v7, v1
	tbnz	w4, #4, LBB1_128
LBB1_123:                               ; %else264
                                        ;   in Loop: Header=BB1_116 Depth=2
	tbnz	w4, #5, LBB1_129
LBB1_124:                               ; %else270
                                        ;   in Loop: Header=BB1_116 Depth=2
	ldr	q1, [sp, #736]                  ; 16-byte Reload
	add.2d	v1, v23, v1
	add.2d	v1, v2, v1
	tbnz	w4, #6, LBB1_130
LBB1_125:                               ; %else276
                                        ;   in Loop: Header=BB1_116 Depth=2
	tbz	w4, #7, LBB1_115
	b	LBB1_131
LBB1_126:                               ; %cond.load248
                                        ;   in Loop: Header=BB1_116 Depth=2
	fmov	x17, d1
	ld1.b	{ v3 }[2], [x17]
	tbz	w4, #3, LBB1_122
LBB1_127:                               ; %cond.load254
                                        ;   in Loop: Header=BB1_116 Depth=2
	mov.d	x17, v1[1]
	ld1.b	{ v3 }[3], [x17]
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	add.2d	v1, v11, v1
	add.2d	v1, v7, v1
	tbz	w4, #4, LBB1_123
LBB1_128:                               ; %cond.load260
                                        ;   in Loop: Header=BB1_116 Depth=2
	fmov	x17, d1
	ld1.b	{ v3 }[4], [x17]
	tbz	w4, #5, LBB1_124
LBB1_129:                               ; %cond.load266
                                        ;   in Loop: Header=BB1_116 Depth=2
	mov.d	x17, v1[1]
	ld1.b	{ v3 }[5], [x17]
	ldr	q1, [sp, #736]                  ; 16-byte Reload
	add.2d	v1, v23, v1
	add.2d	v1, v2, v1
	tbz	w4, #6, LBB1_125
LBB1_130:                               ; %cond.load272
                                        ;   in Loop: Header=BB1_116 Depth=2
	fmov	x17, d1
	ld1.b	{ v3 }[6], [x17]
	tbz	w4, #7, LBB1_115
LBB1_131:                               ; %cond.load278
                                        ;   in Loop: Header=BB1_116 Depth=2
	mov.d	x17, v1[1]
	ld1.b	{ v3 }[7], [x17]
	b	LBB1_115
LBB1_132:                               ; %direct.true211.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q3, [sp, #48]                   ; 16-byte Reload
	sshll.4s	v3, v3, #0
	ldp	q5, q7, [sp, #352]              ; 32-byte Folded Reload
	fsub.4s	v6, v7, v4
	fsub.4s	v4, v5, v4
	ldr	q7, [sp, #480]                  ; 16-byte Reload
	zip2.8b	v5, v7, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v4, v5, v4
	zip1.8b	v7, v7, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v18, v7, #0
	and.16b	v23, v18, v6
	fcmge.4s	v6, v23, v12
	fcmge.4s	v7, v4, v12
	fcmge.4s	v16, v8, v23
	fcmge.4s	v26, v8, v4
	and.16b	v7, v7, v26
	and.16b	v6, v6, v16
	and.16b	v6, v6, v23
	and.16b	v7, v7, v4
	fmul.4s	v16, v7, v10
	fmul.4s	v26, v6, v10
	movi.4s	v28, #75, lsl #24
	mvni.4s	v29, #128, lsl #24
	mov.16b	v27, v29
	bsl.16b	v27, v28, v26
	bif.16b	v28, v16, v29
	fadd.4s	v16, v16, v28
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fsub.4s	v16, v16, v28
	fcvtzs.4s	v16, v16
	fcvtzs.4s	v26, v26
	scvtf.4s	v27, v26
	scvtf.4s	v28, v16
	fmul.4s	v29, v28, v1
	fmul.4s	v1, v27, v1
	fadd.4s	v1, v6, v1
	fadd.4s	v6, v7, v29
	fmul.4s	v7, v27, v19
	fmul.4s	v19, v28, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v1, v1, v7
	fmul.4s	v7, v1, v21
	fmul.4s	v19, v6, v21
	fadd.4s	v19, v19, v22
	fadd.4s	v7, v7, v22
	fmul.4s	v7, v1, v7
	fmul.4s	v19, v6, v19
	fadd.4s	v19, v19, v20
	fadd.4s	v7, v7, v20
	fmul.4s	v7, v1, v7
	fmul.4s	v19, v6, v19
	fadd.4s	v19, v19, v24
	fadd.4s	v7, v7, v24
	fmul.4s	v7, v1, v7
	fmul.4s	v19, v6, v19
	fadd.4s	v19, v19, v25
	fadd.4s	v7, v7, v25
	fmul.4s	v7, v1, v7
	fmul.4s	v19, v6, v19
	movi.4s	v20, #63, lsl #24
	fadd.4s	v19, v19, v20
	fadd.4s	v7, v7, v20
	fmul.4s	v20, v6, v6
	fmul.4s	v21, v1, v1
	fmul.4s	v7, v21, v7
	fmul.4s	v19, v20, v19
	fadd.4s	v6, v6, v19
	fadd.4s	v1, v1, v7
	fmov.4s	v17, #1.00000000
	fadd.4s	v1, v1, v17
	fadd.4s	v6, v6, v17
	sshr.4s	v7, v26, #1
	sshr.4s	v19, v16, #1
	shl.4s	v20, v19, #23
	shl.4s	v21, v7, #23
	add.4s	v21, v21, v17
	add.4s	v20, v20, v17
	fmul.4s	v6, v6, v20
	fmul.4s	v1, v1, v21
	sub.4s	v16, v16, v19
	sub.4s	v7, v26, v7
	shl.4s	v7, v7, #23
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v17
	add.4s	v7, v7, v17
	fmul.4s	v1, v1, v7
	fmul.4s	v6, v6, v16
	fcmgt.4s	v7, v12, v4
	bic.16b	v6, v6, v7
	fcmgt.4s	v7, v12, v23
	bic.16b	v1, v1, v7
	fcmgt.4s	v7, v4, v8
	fcmgt.4s	v16, v23, v8
	ldr	q17, [sp, #560]                 ; 16-byte Reload
	bit.16b	v1, v17, v16
	bit.16b	v6, v17, v7
	fcmeq.4s	v7, v23, v23
	fcmeq.4s	v4, v4, v4
	ldr	q16, [sp, #544]                 ; 16-byte Reload
	bif.16b	v6, v16, v4
	bif.16b	v1, v16, v7
	bic.16b	v4, v1, v3
	ldr	q1, [sp, #80]                   ; 16-byte Reload
	bic.16b	v3, v6, v1
	ldr	x9, [sp, #216]                  ; 8-byte Reload
	add	x9, x23, x9
	ldp	q1, q6, [x9]
	bsl.16b	v5, v3, v6
	bit.16b	v1, v4, v18
	stp	q1, q5, [x9]
	ldp	q5, q1, [x23, #96]
	and.16b	v1, v0, v1
	and.16b	v19, v2, v5
	ldp	q5, q6, [x23, #64]
	and.16b	v21, v0, v6
	and.16b	v20, v2, v5
	ldp	q5, q6, [x23, #32]
	and.16b	v22, v0, v6
	and.16b	v23, v2, v5
	ldr	x9, [sp, #72]                   ; 8-byte Reload
	add	x9, x23, x9
	ldp	q5, q6, [x9]
	and.16b	v26, v0, v6
	and.16b	v25, v2, v5
	mov	w17, #4                         ; =0x4
	ldr	q17, [sp, #416]                 ; 16-byte Reload
LBB1_133:                               ; %direct.true211.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v5, v2, #0
	sshll.2d	v6, v0, #0
	sshll2.2d	v7, v2, #0
	add	x9, x23, x14, lsl #5
	ldp	q18, q16, [x9]
	fadd.4s	v27, v25, v18
	fadd.4s	v28, v26, v16
	ldp	q18, q16, [x9, #32]
	fadd.4s	v18, v23, v18
	fadd.4s	v16, v22, v16
	ldp	q29, q24, [x9, #64]
	fadd.4s	v29, v20, v29
	fadd.4s	v24, v21, v24
	ldp	q31, q30, [x9, #96]
	fadd.4s	v31, v19, v31
	fadd.4s	v30, v1, v30
	dup.2d	v8, x17
	and.16b	v10, v17, v8
	add.2d	v13, v13, v10
	and.16b	v7, v7, v8
	add.2d	v14, v14, v7
	and.16b	v6, v6, v8
	add.2d	v15, v15, v6
	and.16b	v5, v5, v8
	add.2d	v9, v9, v5
	bit.16b	v26, v28, v0
	bit.16b	v25, v27, v2
	bit.16b	v22, v16, v0
	bit.16b	v23, v18, v2
	bit.16b	v21, v24, v0
	bit.16b	v20, v29, v2
	bit.16b	v1, v30, v0
	bit.16b	v19, v31, v2
	fmov	x14, d9
	cmp	x14, #8
	b.lt	LBB1_133
; %bb.134:                              ; %direct.false212.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	uzp1.8h	v5, v2, v0
	xtn.8b	v6, v5
Lloh60:
	adrp	x14, lCPI1_20@PAGE
Lloh61:
	ldr	q7, [x14, lCPI1_20@PAGEOFF]
	and.16b	v24, v0, v7
Lloh62:
	adrp	x14, lCPI1_21@PAGE
Lloh63:
	ldr	q7, [x14, lCPI1_21@PAGEOFF]
	and.16b	v29, v2, v7
Lloh64:
	adrp	x14, lCPI1_23@PAGE
Lloh65:
	ldr	q7, [x14, lCPI1_23@PAGEOFF]
	and.16b	v18, v2, v7
	fadd.4s	v7, v3, v26
	fadd.4s	v16, v4, v25
	ldr	q17, [sp, #480]                 ; 16-byte Reload
	zip1.8b	v25, v17, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	and.16b	v16, v25, v16
	zip2.8b	v25, v17, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	and.16b	v7, v25, v7
	ldr	q17, [sp, #432]                 ; 16-byte Reload
	zip2.8b	v25, v17, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	bit.16b	v7, v28, v25
	zip1.8b	v25, v17, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	bit.16b	v16, v27, v25
	fadd.4s	v16, v23, v16
	fadd.4s	v7, v22, v7
	fadd.4s	v7, v21, v7
	fadd.4s	v16, v20, v16
	fadd.4s	v19, v19, v16
	fadd.4s	v20, v1, v7
	fmov	w14, s29
	add	x17, sp, #840
	bfxil	x17, x14, #0, #3
	str	d6, [sp, #840]
	ldrb	w17, [x17]
	add	x0, sp, #1392
	orr	x14, x0, x14, lsl #2
	str	q20, [sp, #1408]
	str	q19, [sp, #1392]
	ldr	s1, [x14]
	tst	w6, w17
	movi.2d	v25, #0000000000000000
	fcsel	s1, s1, s25, ne
	mov.s	w14, v29[1]
	add	x17, sp, #840
	bfxil	x17, x14, #0, #3
	ldrb	w14, [x17]
	ldr	w12, [sp, #384]                 ; 4-byte Reload
	and	w14, w12, w14
	str	q19, [sp, #1360]
	ldr	s6, [sp, #1360]
	tst	w14, #0x1
	fcsel	s21, s6, s25, ne
	mov.s	w14, v29[2]
	add	x17, sp, #840
	bfxil	x17, x14, #0, #3
	add	x0, sp, #1328
	orr	x14, x0, x14, lsl #2
	ldrb	w17, [x17]
	ldr	w13, [sp, #160]                 ; 4-byte Reload
	and	w17, w13, w17
	str	q20, [sp, #1344]
	str	q19, [sp, #1328]
	ldr	s6, [x14]
	tst	w17, #0x1
	fcsel	s22, s6, s25, ne
	mov.s	w14, v29[3]
	add	x17, sp, #840
	bfxil	x17, x14, #0, #3
	add	x0, sp, #1296
	orr	x14, x0, x14, lsl #2
	ldrb	w17, [x17]
	ldr	w15, [sp, #108]                 ; 4-byte Reload
	and	w17, w15, w17
	str	q20, [sp, #1312]
	str	q19, [sp, #1296]
	ldr	s6, [x14]
	tst	w17, #0x1
	fcsel	s23, s6, s25, ne
	fmov	w14, s24
	add	x17, sp, #840
	bfxil	x17, x14, #0, #3
	ldrb	w17, [x17]
	ldr	w1, [sp, #176]                  ; 4-byte Reload
	and	w17, w1, w17
	str	q20, [sp, #1280]
	str	q19, [sp, #1264]
	add	x0, sp, #1264
	ldr	s6, [x0, w14, uxtw #2]
	tst	w17, #0x1
	fcsel	s6, s6, s25, ne
	mov.s	w14, v24[1]
	add	x17, sp, #840
	bfxil	x17, x14, #0, #3
	ldrb	w17, [x17]
	ldr	w4, [sp, #112]                  ; 4-byte Reload
	and	w17, w4, w17
	str	q20, [sp, #1248]
	str	q19, [sp, #1232]
	add	x0, sp, #1232
	ldr	s7, [x0, w14, uxtw #2]
	tst	w17, #0x1
	fcsel	s7, s7, s25, ne
	mov.s	w14, v24[2]
	add	x17, sp, #840
	bfxil	x17, x14, #0, #3
	ldrb	w17, [x17]
	mov	x21, x16
	and	w17, w16, w17
	str	q20, [sp, #1216]
	str	q19, [sp, #1200]
	add	x0, sp, #1200
	ldr	s16, [x0, w14, uxtw #2]
	tst	w17, #0x1
	fcsel	s16, s16, s25, ne
	mov.s	w14, v24[3]
	add	x17, sp, #840
	bfxil	x17, x14, #0, #3
	ldrb	w17, [x17]
	and	w17, w2, w17
	str	q20, [sp, #1184]
	str	q19, [sp, #1168]
	add	x0, sp, #1168
	ldr	s24, [x0, w14, uxtw #2]
	tst	w17, #0x1
	fcsel	s24, s24, s25, ne
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v24[0]
	mov.s	v1[1], v21[0]
	mov.s	v1[2], v22[0]
	mov.s	v1[3], v23[0]
	fadd.4s	v1, v19, v1
	fadd.4s	v19, v20, v6
	fmov	w14, s18
	add	x17, sp, #840
	bfxil	x17, x14, #0, #3
	ldrb	w17, [x17]
	add	x0, sp, #1136
	orr	x14, x0, x14, lsl #2
	str	q19, [sp, #1152]
	str	q1, [sp, #1136]
	ldr	s6, [x14]
	mov.s	w14, v18[1]
	tst	w6, w17
	add	x17, sp, #840
	bfxil	x17, x14, #0, #3
	ldrb	w17, [x17]
	and	w16, w12, w17
	fcsel	s20, s6, s25, ne
	add	x17, sp, #1104
	orr	x14, x17, x14, lsl #2
	str	q19, [sp, #1120]
	str	q1, [sp, #1104]
	ldr	s6, [x14]
	mov.s	w14, v18[2]
	tst	w16, #0x1
	add	x16, sp, #840
	bfxil	x16, x14, #0, #3
Lloh66:
	adrp	x14, lCPI1_22@PAGE
Lloh67:
	ldr	q7, [x14, lCPI1_22@PAGEOFF]
	and.16b	v7, v0, v7
	movi.4s	v16, #4
	and.16b	v21, v2, v16
	fcsel	s22, s6, s25, ne
	ldrb	w14, [x16]
	and	w13, w13, w14
	str	q1, [sp, #1072]
	ldr	s6, [sp, #1072]
	tst	w13, #0x1
	fcsel	s23, s6, s25, ne
	mov.s	w13, v18[3]
	add	x14, sp, #840
	bfxil	x14, x13, #0, #3
	add	x16, sp, #1040
	orr	x13, x16, x13, lsl #2
	ldrb	w14, [x14]
	and	w14, w15, w14
	str	q19, [sp, #1056]
	str	q1, [sp, #1040]
	ldr	s6, [x13]
	tst	w14, #0x1
	fcsel	s18, s6, s25, ne
	fmov	w13, s7
	add	x14, sp, #840
	bfxil	x14, x13, #0, #3
	ldrb	w14, [x14]
	and	w14, w1, w14
	stp	q1, q19, [sp, #1008]
	add	x15, sp, #1008
	ldr	s6, [x15, w13, uxtw #2]
	tst	w14, #0x1
	fcsel	s6, s6, s25, ne
	mov.s	w13, v7[1]
	add	x14, sp, #840
	bfxil	x14, x13, #0, #3
	ldrb	w14, [x14]
	and	w14, w4, w14
	stp	q1, q19, [sp, #976]
	add	x15, sp, #976
	ldr	s16, [x15, w13, uxtw #2]
	tst	w14, #0x1
	fcsel	s16, s16, s25, ne
	mov.s	w13, v7[2]
	add	x14, sp, #840
	bfxil	x14, x13, #0, #3
	ldrb	w14, [x14]
	and	w14, w21, w14
	stp	q1, q19, [sp, #944]
	add	x15, sp, #944
	ldr	s24, [x15, w13, uxtw #2]
	tst	w14, #0x1
	fcsel	s24, s24, s25, ne
	mov.s	w13, v7[3]
	add	x14, sp, #840
	bfxil	x14, x13, #0, #3
	ldrb	w14, [x14]
	and	w14, w2, w14
	stp	q1, q19, [sp, #912]
	add	x15, sp, #912
	ldr	s7, [x15, w13, uxtw #2]
	tst	w14, #0x1
	fcsel	s7, s7, s25, ne
	mov.s	v6[1], v16[0]
	mov.s	v6[2], v24[0]
	mov.s	v6[3], v7[0]
	mov.s	v20[1], v22[0]
	mov.s	v20[2], v23[0]
	mov.s	v20[3], v18[0]
	fadd.4s	v1, v1, v20
	fadd.4s	v6, v19, v6
	fmov	w13, s21
	add	x14, sp, #840
	orr	x14, x14, x13
	ldrb	w14, [x14]
	stp	q1, q6, [sp, #880]
	add	x15, sp, #880
	ldr	s6, [x15, w13, uxtw #2]
	tst	w6, w14
	fcsel	s6, s6, s25, ne
	ldr	w12, [sp, #144]                 ; 4-byte Reload
	tst	w12, #0x1
	fadd	s1, s1, s6
	fcsel	s6, s1, s25, ne
	ldr	w12, [sp, #44]                  ; 4-byte Reload
	tst	w12, #0x1
	fcsel	s7, s1, s25, ne
	tst	w5, #0x1
	fcsel	s16, s1, s25, ne
	tst	w7, #0x1
	fcsel	s18, s1, s25, ne
	tst	w30, #0x1
	fcsel	s19, s1, s25, ne
	tst	w8, #0x1
	fcsel	s20, s1, s25, ne
	tst	w11, #0x1
	fcsel	s21, s1, s25, ne
	tst	w3, #0x1
	fcsel	s1, s1, s25, ne
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v18[0]
	mov.s	v19[1], v20[0]
	mov.s	v19[2], v21[0]
	mov.s	v19[3], v1[0]
	stp	q6, q19, [sp, #848]
	and	x8, x10, #0x7
	add	x10, sp, #848
	ldr	s1, [x10, x8, lsl #2]
	fadd	s1, s1, s25
	dup.4s	v1, v1[0]
	ldr	q6, [sp, #224]                  ; 16-byte Reload
	fmov	x8, d6
	ldp	x13, x12, [sp, #312]            ; 16-byte Folded Reload
	add	x8, x12, x8, lsl #2
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	ldr	q7, [sp, #400]                  ; 16-byte Reload
	movi.8b	v8, #1
	movi.2s	v9, #65
	ldr	q16, [sp, #624]                 ; 16-byte Reload
	ldr	q17, [sp, #672]                 ; 16-byte Reload
	b	LBB1_136
LBB1_135:                               ; %else300
                                        ;   in Loop: Header=BB1_136 Depth=2
	ldr	q6, [sp, #656]                  ; 16-byte Reload
	add.2d	v19, v19, v6
	ldr	q6, [sp, #640]                  ; 16-byte Reload
	add.2d	v20, v20, v6
	add.2d	v21, v21, v16
	add.2d	v18, v18, v17
	fmov	x9, d18
	cmp	x9, #8
	b.ge	LBB1_152
LBB1_136:                               ; %direct.true248.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and.16b	v6, v5, v7
	addv.8h	h6, v6
	fmov	w10, s6
	lsl	x9, x9, #5
	add	x11, x23, x9
	ldp	q6, q22, [x11]
	and.16b	v6, v2, v6
	fdiv.4s	v23, v6, v1
	add	x9, x8, x9
	tbnz	w10, #0, LBB1_144
; %bb.137:                              ; %else286
                                        ;   in Loop: Header=BB1_136 Depth=2
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_145
LBB1_138:                               ; %else288
                                        ;   in Loop: Header=BB1_136 Depth=2
	tbnz	w10, #2, LBB1_146
LBB1_139:                               ; %else290
                                        ;   in Loop: Header=BB1_136 Depth=2
	tbnz	w10, #3, LBB1_147
LBB1_140:                               ; %else292
                                        ;   in Loop: Header=BB1_136 Depth=2
	and.16b	v6, v0, v22
	fdiv.4s	v22, v6, v1
	tbnz	w10, #4, LBB1_148
LBB1_141:                               ; %else294
                                        ;   in Loop: Header=BB1_136 Depth=2
	tbnz	w10, #5, LBB1_149
LBB1_142:                               ; %else296
                                        ;   in Loop: Header=BB1_136 Depth=2
	tbnz	w10, #6, LBB1_150
LBB1_143:                               ; %else298
                                        ;   in Loop: Header=BB1_136 Depth=2
	tbz	w10, #7, LBB1_135
	b	LBB1_151
LBB1_144:                               ; %cond.store285
                                        ;   in Loop: Header=BB1_136 Depth=2
	str	s23, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_138
LBB1_145:                               ; %cond.store287
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x11, x9, #4
	st1.s	{ v23 }[1], [x11]
	tbz	w10, #2, LBB1_139
LBB1_146:                               ; %cond.store289
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x11, x9, #8
	st1.s	{ v23 }[2], [x11]
	tbz	w10, #3, LBB1_140
LBB1_147:                               ; %cond.store291
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x11, x9, #12
	st1.s	{ v23 }[3], [x11]
	and.16b	v6, v0, v22
	fdiv.4s	v22, v6, v1
	tbz	w10, #4, LBB1_141
LBB1_148:                               ; %cond.store293
                                        ;   in Loop: Header=BB1_136 Depth=2
	str	s22, [x9, #16]
	tbz	w10, #5, LBB1_142
LBB1_149:                               ; %cond.store295
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x11, x9, #20
	st1.s	{ v22 }[1], [x11]
	tbz	w10, #6, LBB1_143
LBB1_150:                               ; %cond.store297
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x11, x9, #24
	st1.s	{ v22 }[2], [x11]
	tbz	w10, #7, LBB1_135
LBB1_151:                               ; %cond.store299
                                        ;   in Loop: Header=BB1_136 Depth=2
	add	x9, x9, #28
	st1.s	{ v22 }[3], [x9]
	b	LBB1_135
LBB1_152:                               ; %direct.false249.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	d0, [sp, #208]                  ; 8-byte Reload
	fmov	w8, s0
	ldr	q2, [sp, #480]                  ; 16-byte Reload
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v0, v0, v4
	fdiv.4s	v0, v0, v1
	ldp	q4, q5, [sp, #272]              ; 32-byte Folded Reload
	ldp	q7, q6, [sp, #240]              ; 32-byte Folded Reload
	stp	q5, q6, [sp, #768]
	stp	q7, q4, [sp, #800]
	and	x9, x13, #0x7
	add	x10, sp, #768
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x13
	add	x9, x12, x9, lsl #2
	tbnz	w8, #0, LBB1_166
; %bb.153:                              ; %else303
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #1, LBB1_167
LBB1_154:                               ; %else305
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #2, LBB1_168
LBB1_155:                               ; %else307
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #3, LBB1_157
LBB1_156:                               ; %cond.store308
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #12
	st1.s	{ v0 }[3], [x10]
LBB1_157:                               ; %else309
                                        ;   in Loop: Header=BB1_4 Depth=1
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	and.16b	v0, v0, v3
	fdiv.4s	v0, v0, v1
	tbnz	w8, #4, LBB1_169
; %bb.158:                              ; %else311
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #5, LBB1_170
LBB1_159:                               ; %else313
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #6, LBB1_171
LBB1_160:                               ; %else315
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #7, LBB1_2
	b	LBB1_172
LBB1_161:                               ; %cond.load199
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x11, d14
	ld1.b	{ v1 }[2], [x11]
	tbz	w12, #3, LBB1_107
LBB1_162:                               ; %cond.load205
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[3], [x10]
	tbz	w12, #4, LBB1_108
LBB1_163:                               ; %cond.load211
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x10, d13
	ld1.b	{ v1 }[4], [x10]
	tbz	w12, #5, LBB1_109
LBB1_164:                               ; %cond.load217
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.b	{ v1 }[5], [x9]
	tbz	w12, #6, LBB1_110
LBB1_165:                               ; %cond.load223
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x9, d23
	ld1.b	{ v1 }[6], [x9]
	stp	q29, q28, [sp, #512]            ; 32-byte Folded Spill
	str	q31, [sp, #496]                 ; 16-byte Spill
	stp	q18, q7, [sp, #640]             ; 32-byte Folded Spill
	str	d22, [sp, #208]                 ; 8-byte Spill
	tbnz	w12, #7, LBB1_111
	b	LBB1_112
LBB1_166:                               ; %cond.store302
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9]
	tbz	w8, #1, LBB1_154
LBB1_167:                               ; %cond.store304
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #4
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #2, LBB1_155
LBB1_168:                               ; %cond.store306
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #8
	st1.s	{ v0 }[2], [x10]
	tbnz	w8, #3, LBB1_156
	b	LBB1_157
LBB1_169:                               ; %cond.store310
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9, #16]
	tbz	w8, #5, LBB1_159
LBB1_170:                               ; %cond.store312
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #6, LBB1_160
LBB1_171:                               ; %cond.store314
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w8, #7, LBB1_2
LBB1_172:                               ; %cond.store316
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x9, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB1_2
LBB1_173:                               ; %block.batch.exit
	add	sp, sp, #3968
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpAdrp	Lloh54, Lloh56
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpAdrp	Lloh52, Lloh54
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpAdrp	Lloh50, Lloh52
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh66, Lloh67
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdrp	Lloh60, Lloh62
	.loh AdrpLdr	Lloh60, Lloh61
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	mov	x10, #0                         ; =0x0
	ldr	x8, [x1, #136]
	ldr	x15, [x0]
	ldr	x13, [x0, #16]
	ldr	w9, [x1]
	ldr	w11, [x1, #36]
	add	w9, w11, w9, lsl #5
	lsr	w9, w9, #3
	dup.2s	v0, w9
	ushll.2d	v0, v0, #0
	fmov	x9, d0
	mov	w11, #16388                     ; =0x4004
	umaddl	x12, w9, w11, x15
	ldr	x11, [x0, #32]
	ldr	x9, [x0, #48]
LBB0_1:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x12, x10
	ldp	q1, q2, [x14]
	add	x14, x8, x10
	stp	q1, q2, [x14]
	add	x10, x10, #32
	cmp	x10, #4, lsl #12                ; =16384
	b.ne	LBB0_1
; %bb.2:                                ; %direct.false
	fmov	x14, d0
	add	x10, x14, x14, lsl #12
	lsl	x12, x10, #2
	add	x10, x12, #4, lsl #12           ; =16384
	add	x15, x15, x10
	ldr	q0, [x8, #16384]
	ld1.s	{ v0 }[0], [x15]
	str	q0, [x8, #16384]
	ldp	q1, q2, [x8]
	ldp	q6, q7, [x8, #32]
	ldp	q16, q3, [x8, #64]
	ldp	q4, q5, [x8, #96]
	add	x15, x8, #224
	mov	w16, #4                         ; =0x4
LBB0_3:                                 ; %direct.true80
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q17, q18, [x15, #-96]
	fadd.4s	v2, v2, v18
	fadd.4s	v1, v1, v17
	ldp	q17, q18, [x15, #-64]
	fadd.4s	v7, v7, v18
	fadd.4s	v6, v6, v17
	ldp	q17, q18, [x15, #-32]
	fadd.4s	v3, v3, v18
	fadd.4s	v16, v16, v17
	ldp	q17, q18, [x15], #128
	fadd.4s	v5, v5, v18
	fadd.4s	v4, v4, v17
	cmp	x16, #508
	add	x16, x16, #4
	b.lo	LBB0_3
; %bb.4:                                ; %direct.false81
	mov	w15, #16416                     ; =0x4020
	add	x15, x8, x15
	fadd.4s	v17, v0, v1
	mov.s	v1[0], v17[0]
	fadd.4s	v2, v7, v2
	fadd.4s	v1, v6, v1
	fadd.4s	v1, v16, v1
	fadd.4s	v2, v3, v2
	fadd.4s	v2, v5, v2
	fadd.4s	v1, v4, v1
	rev64.4s	v3, v1
	rev64.4s	v4, v2
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	dup.4s	v4, v2[2]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	fadd.4s	v1, v1, v2
	movi.2d	v2, #0000000000000000
	fadd	s1, s1, s2
	mov	w16, #2048                      ; =0x800
	movk	w16, #17792, lsl #16
	fmov	s2, w16
	fdiv	s1, s1, s2
	dup.4s	v1, v1[0]
	mov	w16, #512                       ; =0x200
	mov	x17, x8
LBB0_5:                                 ; %direct.true115
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q3, q2, [x17]
	fsub.4s	v3, v3, v1
	fsub.4s	v2, v2, v1
	str	q2, [x17, #16432]
	str	q3, [x17, #16416]
	add	x17, x17, #32
	subs	x16, x16, #1
	b.ne	LBB0_5
; %bb.6:                                ; %direct.false116
	fsub.4s	v0, v0, v1
	ldr	q1, [x8, #32800]
	mov.s	v1[0], v0[0]
	str	q1, [x8, #32800]
	ldr	q1, [x8, #16416]
	ldr	q2, [x8, #16432]
	fmul.4s	v2, v2, v2
	fmul.4s	v1, v1, v1
	ldr	q3, [x8, #16448]
	ldr	q4, [x8, #16464]
	fmul.4s	v4, v4, v4
	fmul.4s	v3, v3, v3
	ldr	q6, [x8, #16480]
	ldr	q5, [x8, #16496]
	fmul.4s	v5, v5, v5
	fmul.4s	v6, v6, v6
	ldr	q7, [x8, #16512]
	ldr	q16, [x8, #16528]
	fmul.4s	v16, v16, v16
	fmul.4s	v7, v7, v7
	mov	w16, #16640                     ; =0x4100
	add	x16, x8, x16
	mov	w17, #517                       ; =0x205
LBB0_7:                                 ; %direct.true152
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q18, q17, [x16, #-96]
	fmul.4s	v18, v18, v18
	fmul.4s	v17, v17, v17
	fadd.4s	v2, v2, v17
	fadd.4s	v1, v1, v18
	ldp	q18, q17, [x16, #-64]
	fmul.4s	v18, v18, v18
	fmul.4s	v17, v17, v17
	fadd.4s	v4, v4, v17
	fadd.4s	v3, v3, v18
	ldp	q18, q17, [x16, #-32]
	fmul.4s	v18, v18, v18
	fmul.4s	v17, v17, v17
	fadd.4s	v5, v5, v17
	fadd.4s	v6, v6, v18
	ldp	q18, q17, [x16], #128
	fmul.4s	v18, v18, v18
	fmul.4s	v17, v17, v17
	fadd.4s	v16, v16, v17
	fadd.4s	v7, v7, v18
	sub	x0, x17, #513
	add	x17, x17, #4
	cmp	x0, #508
	b.lo	LBB0_7
; %bb.8:                                ; %direct.false153
	mov	x17, #0                         ; =0x0
	mov	w16, #32832                     ; =0x8040
	add	x16, x8, x16
LBB0_9:                                 ; %direct.true189
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, x13, x17
	ldp	q17, q18, [x0]
	add	x0, x16, x17
	stp	q17, q18, [x0]
	add	x17, x17, #32
	cmp	x17, #4, lsl #12                ; =16384
	b.ne	LBB0_9
; %bb.10:                               ; %direct.false190
	fmul.4s	v0, v0, v0
	fadd.4s	v0, v0, v1
	mov.s	v1[0], v0[0]
	fadd.4s	v0, v4, v2
	fadd.4s	v1, v3, v1
	fadd.4s	v1, v6, v1
	fadd.4s	v0, v5, v0
	fadd.4s	v0, v16, v0
	fadd.4s	v1, v7, v1
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v1, v0
	movi.2d	v1, #0000000000000000
	fadd	s0, s0, s1
	mov	w17, #2048                      ; =0x800
	movk	w17, #17792, lsl #16
	fmov	s1, w17
	fdiv	s0, s0, s1
	mov	w17, #16384                     ; =0x4000
	ldr	s1, [x13, x17]
	mov	w13, #49216                     ; =0xc040
	str	s1, [x8, x13]
	mov	w13, #50604                     ; =0xc5ac
	movk	w13, #14119, lsl #16
	fmov	s1, w13
	fadd	s0, s0, s1
	fsqrt	s0, s0
	subs	x13, x9, x11
	cset	w17, hs
	mov	w0, #16387                      ; =0x4003
	cmp	x13, x0
	csel	w13, wzr, w17, ls
	subs	x17, x11, x9
	mov	w0, #4095                       ; =0xfff
	movk	w0, #256, lsl #16
	ccmp	x17, x0, #0, hs
	b.hi	LBB0_17
; %bb.11:                               ; %direct.false190
	tbnz	w13, #0, LBB0_17
; %bb.12:                               ; %direct.true259.preheader
	mov	x13, #0                         ; =0x0
	mov	w14, #49248                     ; =0xc060
	add	x14, x8, x14
LBB0_13:                                ; %direct.true259
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x11, x13
	ldp	q1, q2, [x15]
	add	x15, x14, x13
	stp	q1, q2, [x15]
	add	x13, x13, #32
	cmp	x13, #4, lsl #12                ; =16384
	b.ne	LBB0_13
; %bb.14:                               ; %direct.false260
	ldr	s1, [x11, x13]
	mov	w11, #96                        ; =0x60
	movk	w11, #1, lsl #16
	str	s1, [x8, x11]
	dup.4s	v0, v0[0]
	add	x11, x9, x12
	mov	w12, #512                       ; =0x200
	mov	x13, x8
LBB0_15:                                ; %direct.true284
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q1, [x13, #16432]
	ldr	q2, [x13, #16416]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	ldr	q3, [x13, #32832]
	ldr	q4, [x13, #32848]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	ldr	q3, [x13, #49264]
	ldr	q4, [x13, #49248]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	stp	q2, q1, [x11], #32
	add	x13, x13, #32
	subs	x12, x12, #1
	b.ne	LBB0_15
; %bb.16:                               ; %direct.false285
	ldr	q1, [x8, #32800]
	fdiv.4s	v0, v1, v0
	ldr	q1, [x8, #49216]
	fmul.4s	v0, v0, v1
	add	x11, x8, #16, lsl #12           ; =65536
	ldr	q1, [x11, #96]
	fadd.4s	v0, v0, v1
	str	s0, [x9, x10]
	ret
LBB0_17:                                ; %direct.schedule.27.preheader
	mov	x13, #0                         ; =0x0
	dup.4s	v0, v0[0]
	mov	w12, #16388                     ; =0x4004
	umaddl	x12, w14, w12, x9
	movi.2d	v1, #0000000000000000
	mov	w14, #1                         ; =0x1
	dup.2d	v2, x14
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
LBB0_18:                                ; %direct.true217
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x13, x13, #5
	add	x14, x15, x13
	ldp	q7, q6, [x14]
	fdiv.4s	v7, v7, v0
	fdiv.4s	v6, v6, v0
	add	x13, x16, x13
	ldp	q16, q17, [x13]
	fmul.4s	v6, v6, v17
	fmul.4s	v7, v7, v16
	fmov	x13, d1
	lsl	x13, x13, #5
	add	x14, x11, x13
	ldp	q17, q16, [x14]
	fadd.4s	v7, v7, v17
	fadd.4s	v6, v6, v16
	add	x13, x12, x13
	stp	q7, q6, [x13]
	add.2d	v4, v4, v2
	add.2d	v3, v3, v2
	add.2d	v5, v5, v2
	add.2d	v1, v1, v2
	fmov	x13, d1
	cmp	x13, #512
	b.lt	LBB0_18
; %bb.19:                               ; %direct.false218
	ldr	q1, [x8, #32800]
	fdiv.4s	v0, v1, v0
	ldr	q1, [x8, #49216]
	fmul.4s	v0, v0, v1
	mov	w8, #16384                      ; =0x4000
	ldr	s1, [x11, x8]
	fadd.4s	v0, v0, v1
	str	s0, [x9, x10]
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_11:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI1_12:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI1_13:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI1_14:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_15:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_210
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1712
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	mov	w22, #0                         ; =0x0
	ldp	w9, w8, [x2, #44]
	str	w9, [sp, #476]                  ; 4-byte Spill
	str	w8, [sp, #472]                  ; 4-byte Spill
	ldp	w25, w24, [x2]
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Spill
Lloh4:
	adrp	x8, lCPI1_2@PAGE
Lloh5:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Spill
	mov	w23, #4                         ; =0x4
	ldp	w28, w26, [x2, #8]
	str	w3, [sp, #412]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w19, [sp, #412]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	ldr	w9, [sp, #476]                  ; 4-byte Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w24, eq
	ldr	w10, [sp, #472]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w24, wzr, w9, ne
	add	w28, w28, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_209
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_41 Depth 2
                                        ;     Child Loop BB1_43 Depth 2
                                        ;     Child Loop BB1_45 Depth 2
                                        ;     Child Loop BB1_48 Depth 2
                                        ;     Child Loop BB1_77 Depth 2
                                        ;     Child Loop BB1_162 Depth 2
                                        ;     Child Loop BB1_95 Depth 2
	ubfiz	x8, x25, #5, #32
	cmp	x8, x26
	csel	x9, x8, xzr, ls
	subs	x10, x26, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x26, x9
	stp	w25, w24, [x20]
	str	w28, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x26, #2, hi
	csel	x27, x10, xzr, ls
	cmp	x27, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x19, x27, #3
	cbz	x19, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w27, #0x7
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v1, w8
	ldp	q0, q2, [sp, #32]               ; 32-byte Folded Reload
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v4, v1, v0
	umaxv.8h	h2, v4
	fmov	w8, s2
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	ldr	x17, [x20, #136]
	mov	w8, #16416                      ; =0x4020
	add	x11, x17, x8
	mov	w8, #32832                      ; =0x8040
	add	x9, x17, x8
	mov	w8, #49248                      ; =0xc060
	add	x13, x17, x8
	ldr	x10, [x21]
	ldr	x15, [x21, #16]
	ldr	x14, [x21, #32]
	ldr	x8, [x21, #48]
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v2, v4, v2
	addv.8h	h24, v2
	fmov	w16, s24
	and	w16, w16, #0xff
	str	w16, [sp, #216]                 ; 4-byte Spill
	ubfiz	w16, w25, #2, #27
	orr	w16, w16, w19
	dup.4s	v2, w16
	and.16b	v16, v1, v2
	and.16b	v2, v0, v2
	ushll2.2d	v5, v2, #0
	ushll2.2d	v6, v16, #0
	ushll.2d	v7, v2, #0
	ushll.2d	v2, v16, #0
	fmov	x16, d2
	mov	w0, #16388                      ; =0x4004
	umaddl	x16, w16, w0, x10
	fmov	w0, s24
	b	LBB1_15
LBB1_14:                                ; %else92
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x1, x17, x12
	stp	q16, q17, [x1]
	add	x12, x12, #32
	cmp	x12, #4, lsl #12                ; =16384
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x1, x16, x12
	add	x3, x17, x12
	ldr	q16, [x3]
	tbnz	w0, #0, LBB1_23
; %bb.16:                               ; %else72
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w2, w0, #0xff
	tbnz	w2, #1, LBB1_24
LBB1_17:                                ; %else74
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w2, #2, LBB1_25
LBB1_18:                                ; %else77
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w2, #3, LBB1_26
LBB1_19:                                ; %else80
                                        ;   in Loop: Header=BB1_15 Depth=2
	ldr	q17, [x3, #16]
	tbnz	w2, #4, LBB1_27
LBB1_20:                                ; %else83
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w2, #5, LBB1_28
LBB1_21:                                ; %else86
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w2, #6, LBB1_29
LBB1_22:                                ; %else89
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w2, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	ld1.s	{ v16 }[0], [x1]
	and	w2, w0, #0xff
	tbz	w2, #1, LBB1_17
LBB1_24:                                ; %cond.load73
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x4, x1, #4
	ld1.s	{ v16 }[1], [x4]
	tbz	w2, #2, LBB1_18
LBB1_25:                                ; %cond.load76
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x4, x1, #8
	ld1.s	{ v16 }[2], [x4]
	tbz	w2, #3, LBB1_19
LBB1_26:                                ; %cond.load79
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x4, x1, #12
	ld1.s	{ v16 }[3], [x4]
	ldr	q17, [x3, #16]
	tbz	w2, #4, LBB1_20
LBB1_27:                                ; %cond.load82
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x3, x1, #16
	ld1.s	{ v17 }[0], [x3]
	tbz	w2, #5, LBB1_21
LBB1_28:                                ; %cond.load85
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x3, x1, #20
	ld1.s	{ v17 }[1], [x3]
	tbz	w2, #6, LBB1_22
LBB1_29:                                ; %cond.load88
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x3, x1, #24
	ld1.s	{ v17 }[2], [x3]
	tbz	w2, #7, LBB1_14
LBB1_30:                                ; %cond.load91
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x1, x1, #28
	ld1.s	{ v17 }[3], [x1]
	b	LBB1_14
LBB1_31:                                ; %direct.true80.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v25, v4
	sshll.2d	v4, v1, #0
	sshll.2d	v20, v0, #0
	sshll2.2d	v27, v1, #0
	sshll2.2d	v28, v0, #0
Lloh6:
	adrp	x12, lCPI1_6@PAGE
Lloh7:
	ldr	q16, [x12, lCPI1_6@PAGEOFF]
	and.16b	v16, v4, v16
Lloh8:
	adrp	x12, lCPI1_7@PAGE
Lloh9:
	ldr	q17, [x12, lCPI1_7@PAGEOFF]
	and.16b	v18, v4, v17
Lloh10:
	adrp	x12, lCPI1_8@PAGE
Lloh11:
	ldr	q4, [x12, lCPI1_8@PAGEOFF]
	and.16b	v17, v20, v4
Lloh12:
	adrp	x12, lCPI1_9@PAGE
Lloh13:
	ldr	q4, [x12, lCPI1_9@PAGEOFF]
	and.16b	v19, v27, v4
Lloh14:
	adrp	x12, lCPI1_10@PAGE
Lloh15:
	ldr	q4, [x12, lCPI1_10@PAGEOFF]
	and.16b	v21, v28, v4
	movi.8b	v3, #1
	and.8b	v4, v25, v3
	umov.b	w16, v4[0]
	movi.2d	v4, #0000000000000000
	mov.b	v4[0], v25[0]
	umaxv.8b	b22, v4
	fmov	w0, s22
	rbit	w12, w16
	clz	w12, w12
	tst	w0, #0x1
	mov	w1, #4096                       ; =0x1000
	dup.2d	v23, x1
	csel	w2, w12, wzr, ne
	orr.16b	v3, v16, v23
	mov	w12, #4097                      ; =0x1001
	dup.2s	v22, w12
	xtn.2s	v29, v2
	str	q3, [sp, #272]                  ; 16-byte Spill
	umlal.2d	v3, v29, v22
	movi.2d	v2, #0000000000000000
	str	q25, [sp, #416]                 ; 16-byte Spill
	mov.b	v2[0], v25[0]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	str	q3, [sp, #384]                  ; 16-byte Spill
	and.16b	v2, v2, v3
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #1616]
	str	q3, [sp, #1600]
	str	q3, [sp, #1584]
	str	q2, [sp, #1568]
	ubfiz	x12, x2, #3, #3
	add	x1, sp, #1568
	ldr	x1, [x1, x12]
	sub	x1, x1, x2
	add	x10, x10, x1, lsl #2
	str	q21, [sp, #1680]
	str	q17, [sp, #1664]
	str	q19, [sp, #1648]
	str	q18, [sp, #1632]
	add	x1, sp, #1632
	ldr	x12, [x1, x12]
	orr	x12, x12, #0x4000
	str	x2, [sp, #400]                  ; 8-byte Spill
	sub	x12, x12, w2, uxtw #2
	tst	w16, #0x1
	csel	x12, xzr, x12, eq
	add	x1, x17, x12
	ldp	q17, q25, [x1]
	tbnz	w0, #0, LBB1_137
; %bb.32:                               ; %else96
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #1, LBB1_138
LBB1_33:                                ; %else99
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #2, LBB1_139
LBB1_34:                                ; %else102
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #3, LBB1_140
LBB1_35:                                ; %else105
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #4, LBB1_141
LBB1_36:                                ; %else108
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #5, LBB1_142
LBB1_37:                                ; %else111
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #6, LBB1_143
LBB1_38:                                ; %else114
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q4, [sp, #448]                  ; 16-byte Spill
	str	q24, [sp, #368]                 ; 16-byte Spill
	tbz	w16, #7, LBB1_40
LBB1_39:                                ; %cond.load116
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v25 }[3], [x10]
LBB1_40:                                ; %else117
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q16, [sp, #432]                 ; 16-byte Spill
Lloh16:
	adrp	x10, lCPI1_3@PAGE
Lloh17:
	ldr	q19, [x10, lCPI1_3@PAGEOFF]
	and.16b	v2, v28, v19
Lloh18:
	adrp	x10, lCPI1_4@PAGE
Lloh19:
	ldr	q21, [x10, lCPI1_4@PAGEOFF]
	and.16b	v3, v27, v21
Lloh20:
	adrp	x10, lCPI1_5@PAGE
Lloh21:
	ldr	q24, [x10, lCPI1_5@PAGEOFF]
	and.16b	v4, v20, v24
	stp	q4, q3, [sp, #128]              ; 32-byte Folded Spill
	orr.16b	v4, v4, v23
	orr.16b	v16, v3, v23
	str	q2, [sp, #160]                  ; 16-byte Spill
	orr.16b	v3, v2, v23
	umull.2d	v2, v29, v22
	str	q2, [sp, #288]                  ; 16-byte Spill
	xtn.2s	v6, v6
	xtn.2s	v7, v7
	xtn.2s	v5, v5
	stp	q4, q3, [sp, #240]              ; 32-byte Folded Spill
	mov.16b	v2, v3
	umlal.2d	v2, v5, v22
	str	q2, [sp, #352]                  ; 16-byte Spill
	str	q16, [sp, #224]                 ; 16-byte Spill
	mov.16b	v2, v16
	umlal.2d	v2, v6, v22
	str	q2, [sp, #336]                  ; 16-byte Spill
	mov.16b	v2, v4
	umlal.2d	v2, v7, v22
	str	q2, [sp, #320]                  ; 16-byte Spill
	sshll.2d	v5, v1, #0
	sshll.2d	v6, v0, #0
	str	x12, [sp, #312]                 ; 8-byte Spill
	add	x10, x17, x12
	stp	q25, q17, [sp, #176]            ; 32-byte Folded Spill
	stp	q17, q25, [x10]
	fmov	x10, d18
	dup.2d	v7, x23
	and.16b	v25, v28, v7
	and.16b	v30, v27, v7
	and.16b	v24, v6, v7
	and.16b	v10, v5, v7
	fmov	x0, d10
	ldp	q5, q6, [x17, #96]
	and.16b	v6, v0, v6
	and.16b	v5, v1, v5
	ldp	q7, q18, [x17, #64]
	and.16b	v18, v0, v18
	and.16b	v7, v1, v7
	ldp	q23, q22, [x17, #32]
	and.16b	v22, v0, v22
	and.16b	v23, v1, v23
	str	x10, [sp, #112]                 ; 8-byte Spill
	add	x10, x17, x10
	ldp	q29, q31, [x10]
	and.16b	v8, v0, v31
	mov	x10, x0
	and.16b	v11, v1, v29
	mov.16b	v14, v10
	mov.16b	v15, v30
	mov.16b	v31, v24
	mov.16b	v29, v25
LBB1_41:                                ; %direct.true80.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v9, v1, #0
	sshll.2d	v4, v0, #0
	add	x10, x17, x10, lsl #5
	ldp	q12, q13, [x10]
	fadd.4s	v12, v11, v12
	fadd.4s	v13, v8, v13
	ldp	q19, q16, [x10, #32]
	fadd.4s	v19, v23, v19
	fadd.4s	v16, v22, v16
	ldp	q20, q21, [x10, #64]
	fadd.4s	v20, v7, v20
	fadd.4s	v21, v18, v21
	ldp	q2, q26, [x10, #96]
	fadd.4s	v2, v5, v2
	fadd.4s	v26, v6, v26
	dup.2d	v17, x23
	and.16b	v3, v28, v17
	add.2d	v29, v29, v3
	and.16b	v3, v27, v17
	add.2d	v15, v15, v3
	and.16b	v3, v4, v17
	add.2d	v31, v31, v3
	and.16b	v3, v9, v17
	add.2d	v14, v14, v3
	bit.16b	v8, v13, v0
	bit.16b	v11, v12, v1
	bit.16b	v22, v16, v0
	bit.16b	v23, v19, v1
	bit.16b	v18, v21, v0
	bit.16b	v7, v20, v1
	bit.16b	v6, v26, v0
	bit.16b	v5, v2, v1
	fmov	x10, d14
	cmp	x10, #512
	b.lt	LBB1_41
; %bb.42:                               ; %direct.false81.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x27, #0                         ; =0x0
	ldp	q2, q3, [sp, #176]              ; 32-byte Folded Reload
	fadd.4s	v2, v2, v8
	fadd.4s	v3, v3, v11
	ldr	q26, [sp, #448]                 ; 16-byte Reload
	zip1.8b	v4, v26, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v3, v4, v3
	zip2.8b	v4, v26, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v2, v4, v2
	ldr	q29, [sp, #416]                 ; 16-byte Reload
	zip2.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	movi.2d	v16, #0000000000000000
	mov.b	v16[2], v29[1]
	mov.b	v16[4], v29[2]
	bit.16b	v2, v13, v4
	mov.b	v16[6], v29[3]
	ushll.4s	v4, v16, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v3, v12, v4
	fadd.4s	v3, v23, v3
	fadd.4s	v2, v22, v2
	fadd.4s	v2, v18, v2
	fadd.4s	v3, v7, v3
	fadd.4s	v5, v5, v3
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #432]                  ; 16-byte Reload
	ldp	q4, q3, [sp, #144]              ; 32-byte Folded Reload
	uzp1.4s	v2, v2, v4
	ldr	q4, [sp, #128]                  ; 16-byte Reload
	uzp1.4s	v7, v4, v3
	movi.4s	v4, #1
	eor.16b	v3, v2, v4
	mov.s	w1, v3[1]
	eor.16b	v20, v7, v4
	mov.s	w2, v3[2]
	mov.s	w4, v3[3]
	fmov	w10, s3
	add	x16, sp, #1208
	bfxil	x16, x10, #0, #3
	str	d29, [sp, #1208]
	ldrb	w3, [x16]
	umov.b	w16, v29[0]
	and	x10, x10, #0x7
	str	q6, [sp, #1424]
	str	q5, [sp, #1408]
	add	x12, sp, #1408
	ldr	s3, [x12, x10, lsl #2]
	ands	w10, w16, #0x1
	tst	w10, w3
	movi.2d	v22, #0000000000000000
	fcsel	s17, s3, s22, ne
	and	x5, x1, #0x7
	add	x3, sp, #1208
	bfxil	x3, x1, #0, #3
	ldrb	w1, [x3]
	umov.b	w3, v29[1]
	str	q6, [sp, #1392]
	str	q5, [sp, #1376]
	add	x12, sp, #1376
	ldr	s3, [x12, x5, lsl #2]
	and	w1, w3, w1
	tst	w1, #0x1
	fcsel	s18, s3, s22, ne
	and	x5, x2, #0x7
	add	x1, sp, #1208
	bfxil	x1, x2, #0, #3
	ldrb	w2, [x1]
	umov.b	w1, v29[2]
	and	w2, w1, w2
	str	q6, [sp, #1360]
	str	q5, [sp, #1344]
	add	x12, sp, #1344
	ldr	s3, [x12, x5, lsl #2]
	tst	w2, #0x1
	fcsel	s19, s3, s22, ne
	and	x5, x4, #0x7
	add	x2, sp, #1208
	bfxil	x2, x4, #0, #3
	ldrb	w4, [x2]
	umov.b	w2, v29[3]
	and	w4, w2, w4
	str	q6, [sp, #1328]
	str	q5, [sp, #1312]
	add	x12, sp, #1312
	ldr	s3, [x12, x5, lsl #2]
	tst	w4, #0x1
	mov.s	w4, v20[1]
	fcsel	s21, s3, s22, ne
	mov.s	w5, v20[2]
	mov.s	w30, v20[3]
	fmov	w6, s20
	and	x12, x6, #0x7
	add	x7, sp, #1208
	bfxil	x7, x6, #0, #3
	ldrb	w6, [x7]
	umov.b	w7, v29[4]
	and	w6, w7, w6
	str	q6, [sp, #1552]
	str	q5, [sp, #1536]
	add	x19, sp, #1536
	ldr	s3, [x19, x12, lsl #2]
	tst	w6, #0x1
	fcsel	s3, s3, s22, ne
	and	x12, x4, #0x7
	add	x19, sp, #1208
	bfxil	x19, x4, #0, #3
	umov.b	w6, v29[5]
	ldrb	w4, [x19]
	and	w4, w6, w4
	str	q6, [sp, #1520]
	str	q5, [sp, #1504]
	add	x19, sp, #1504
	ldr	s4, [x19, x12, lsl #2]
	tst	w4, #0x1
	fcsel	s4, s4, s22, ne
	and	x12, x5, #0x7
	add	x4, sp, #1208
	bfxil	x4, x5, #0, #3
	ldrb	w4, [x4]
	umov.b	w5, v29[6]
	str	q6, [sp, #1488]
	str	q5, [sp, #1472]
	add	x19, sp, #1472
	ldr	s16, [x19, x12, lsl #2]
	and	w12, w5, w4
	tst	w12, #0x1
	fcsel	s16, s16, s22, ne
	and	x12, x30, #0x7
	add	x4, sp, #1208
	bfxil	x4, x30, #0, #3
	ldrb	w4, [x4]
	umov.b	w30, v29[7]
	and	w4, w30, w4
	str	q6, [sp, #1456]
	str	q5, [sp, #1440]
	add	x19, sp, #1440
	ldr	s20, [x19, x12, lsl #2]
	tst	w4, #0x1
	fcsel	s20, s20, s22, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v16[0]
	mov.s	v3[3], v20[0]
	mov.s	v17[1], v18[0]
	mov.s	v17[2], v19[0]
	mov.s	v17[3], v21[0]
	fadd.4s	v4, v5, v17
	fadd.4s	v3, v6, v3
	movi.4s	v6, #2
	eor.16b	v5, v7, v6
	eor.16b	v2, v2, v6
	fmov	w12, s2
	add	x4, sp, #1208
	bfxil	x4, x12, #0, #3
	ldrb	w4, [x4]
	and	x12, x12, #0x7
	str	q3, [sp, #1296]
	str	q4, [sp, #1280]
	add	x19, sp, #1280
	ldr	s2, [x19, x12, lsl #2]
	tst	w10, w4
	fcsel	s2, s2, s22, ne
	fmov	w10, s5
	and	x12, x10, #0x7
	add	x4, sp, #1208
	bfxil	x4, x10, #0, #3
	ldrb	w10, [x4]
	and	w10, w7, w10
	str	q3, [sp, #1264]
	str	q4, [sp, #1248]
	add	x4, sp, #1248
	ldr	s5, [x4, x12, lsl #2]
	tst	w10, #0x1
	fcsel	s5, s5, s22, ne
	fadd.4s	v3, v3, v5
	and	w4, w16, w7
	tst	w4, #0x1
	fcsel	s3, s3, s22, ne
	ands	w10, w16, #0x1
	fadd.4s	v2, v4, v2
	fadd	s2, s2, s3
	fcsel	s3, s2, s22, ne
	tst	w4, #0x1
	and	w19, w3, w16
	fcsel	s4, s2, s22, ne
	and	w12, w3, w16
	str	w12, [sp, #192]                 ; 4-byte Spill
	tst	w19, #0x1
	and	w19, w1, w16
	fcsel	s5, s2, s22, ne
	and	w12, w1, w16
	str	w12, [sp, #160]                 ; 4-byte Spill
	tst	w19, #0x1
	and	w19, w2, w16
	fcsel	s6, s2, s22, ne
	and	w12, w2, w16
	str	w12, [sp, #144]                 ; 4-byte Spill
	tst	w19, #0x1
	fcsel	s7, s2, s22, ne
	and	w19, w6, w16
	and	w12, w6, w16
	str	w12, [sp, #128]                 ; 4-byte Spill
	tst	w19, #0x1
	fcsel	s16, s2, s22, ne
	and	w19, w5, w16
	and	w12, w5, w16
	str	w12, [sp, #124]                 ; 4-byte Spill
	tst	w19, #0x1
	fcsel	s17, s2, s22, ne
	and	w19, w30, w16
	and	w12, w30, w16
	str	w12, [sp, #176]                 ; 4-byte Spill
	tst	w19, #0x1
	fcsel	s2, s2, s22, ne
	mov.s	v3[1], v5[0]
	mov.s	v3[2], v6[0]
	mov.s	v3[3], v7[0]
	mov.s	v4[1], v16[0]
	mov.s	v4[2], v17[0]
	mov.s	v4[3], v2[0]
	ldr	w12, [sp, #216]                 ; 4-byte Reload
	rbit	w12, w12
	clz	w12, w12
	str	q4, [sp, #1232]
	str	q3, [sp, #1216]
	str	x12, [sp, #216]                 ; 8-byte Spill
	and	x12, x12, #0x7
	add	x19, sp, #1216
	ldr	s2, [x19, x12, lsl #2]
	mov.b	v29[0], wzr
	str	q29, [sp, #96]                  ; 16-byte Spill
	fadd	s2, s2, s22
	mov	w12, #2048                      ; =0x800
	movk	w12, #17792, lsl #16
	fmov	s3, w12
	fdiv	s2, s2, s3
	dup.4s	v2, v2[0]
	mov	w12, #1                         ; =0x1
	dup.2d	v3, x12
	ushll2.2d	v4, v0, #0
	and.16b	v18, v4, v3
	ushll2.2d	v4, v1, #0
	and.16b	v19, v4, v3
	ushll.2d	v4, v0, #0
	and.16b	v20, v4, v3
	ushll.2d	v4, v1, #0
	and.16b	v21, v4, v3
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB1_43:                                ; %direct.true115.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x12, x27, #5
	add	x19, x17, x12
	ldp	q4, q3, [x19]
	fsub.4s	v4, v4, v2
	fsub.4s	v3, v3, v2
	add	x12, x11, x12
	ldp	q16, q22, [x12]
	bif.16b	v3, v22, v0
	bif.16b	v4, v16, v1
	stp	q4, q3, [x12]
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v17, v17, v18
	add.2d	v5, v5, v21
	fmov	x27, d5
	cmp	x27, #512
	b.lt	LBB1_43
; %bb.44:                               ; %direct.true152.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x27, [sp, #312]                 ; 8-byte Reload
	add	x12, x17, x27
	ldp	q4, q3, [x12]
	fsub.4s	v5, v4, v2
	fsub.4s	v6, v3, v2
	add	x12, x11, x27
	ldp	q2, q3, [x12]
	zip2.8b	v4, v26, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	stp	q6, q5, [sp, #64]               ; 32-byte Folded Spill
	bit.16b	v3, v6, v4
	zip1.8b	v4, v26, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v2, v5, v4
	stp	q2, q3, [x12]
	ldr	q2, [x17, #16528]
	ldr	q3, [x17, #16512]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v12, v0, v2
	and.16b	v14, v1, v3
	ldr	q2, [x17, #16496]
	ldr	q3, [x17, #16480]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v17, v0, v2
	and.16b	v8, v1, v3
	ldr	q2, [x17, #16464]
	ldr	q3, [x17, #16448]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v5, v0, v2
	and.16b	v6, v1, v3
	ldr	x12, [sp, #112]                 ; 8-byte Reload
	add	x12, x11, x12
	ldp	q3, q2, [x12]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v2, v0, v2
	and.16b	v7, v1, v3
LBB1_45:                                ; %direct.true152.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v3, v1, #0
	sshll.2d	v4, v0, #0
	add	x12, x11, x0, lsl #5
	ldp	q22, q16, [x12]
	and.16b	v22, v1, v22
	and.16b	v16, v0, v16
	fmul.4s	v16, v16, v16
	fmul.4s	v22, v22, v22
	fadd.4s	v22, v7, v22
	fadd.4s	v23, v2, v16
	ldp	q26, q16, [x12, #32]
	and.16b	v26, v1, v26
	and.16b	v16, v0, v16
	fmul.4s	v16, v16, v16
	fmul.4s	v26, v26, v26
	fadd.4s	v26, v6, v26
	fadd.4s	v16, v5, v16
	ldp	q31, q29, [x12, #64]
	and.16b	v31, v1, v31
	and.16b	v29, v0, v29
	fmul.4s	v29, v29, v29
	fmul.4s	v31, v31, v31
	fadd.4s	v31, v8, v31
	fadd.4s	v29, v17, v29
	ldp	q13, q9, [x12, #96]
	and.16b	v13, v1, v13
	and.16b	v9, v0, v9
	fmul.4s	v9, v9, v9
	fmul.4s	v13, v13, v13
	fadd.4s	v13, v14, v13
	fadd.4s	v9, v12, v9
	dup.2d	v15, x23
	and.16b	v11, v28, v15
	add.2d	v25, v25, v11
	and.16b	v11, v27, v15
	add.2d	v30, v30, v11
	and.16b	v4, v4, v15
	add.2d	v24, v24, v4
	and.16b	v3, v3, v15
	add.2d	v10, v10, v3
	bit.16b	v2, v23, v0
	bit.16b	v7, v22, v1
	bit.16b	v5, v16, v0
	bit.16b	v6, v26, v1
	bit.16b	v17, v29, v0
	bit.16b	v8, v31, v1
	bit.16b	v12, v9, v0
	bit.16b	v14, v13, v1
	fmov	x0, d10
	cmp	x0, #512
	b.lt	LBB1_45
; %bb.46:                               ; %direct.true189.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x17, #0                         ; =0x0
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	ldr	q9, [sp, #368]                  ; 16-byte Reload
	b	LBB1_48
LBB1_47:                                ; %else142
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x9, x17
	stp	q31, q10, [x12]
	add.2d	v28, v28, v19
	add.2d	v29, v29, v20
	add.2d	v30, v30, v18
	add.2d	v27, v27, v21
	fmov	x17, d27
	cmp	x17, #512
	b.ge	LBB1_64
LBB1_48:                                ; %direct.true189.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w19, s9
	lsl	x17, x17, #5
	add	x0, x15, x17
	add	x12, x9, x17
	ldp	q31, q10, [x12]
	tbnz	w19, #0, LBB1_56
; %bb.49:                               ; %else121
                                        ;   in Loop: Header=BB1_48 Depth=2
	and	w19, w19, #0xff
	tbnz	w19, #1, LBB1_57
LBB1_50:                                ; %else124
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w19, #2, LBB1_58
LBB1_51:                                ; %else127
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w19, #3, LBB1_59
LBB1_52:                                ; %else130
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w19, #4, LBB1_60
LBB1_53:                                ; %else133
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w19, #5, LBB1_61
LBB1_54:                                ; %else136
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w19, #6, LBB1_62
LBB1_55:                                ; %else139
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbz	w19, #7, LBB1_47
	b	LBB1_63
LBB1_56:                                ; %cond.load120
                                        ;   in Loop: Header=BB1_48 Depth=2
	ld1.s	{ v31 }[0], [x0]
	and	w19, w19, #0xff
	tbz	w19, #1, LBB1_50
LBB1_57:                                ; %cond.load123
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x0, #4
	ld1.s	{ v31 }[1], [x12]
	tbz	w19, #2, LBB1_51
LBB1_58:                                ; %cond.load126
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x0, #8
	ld1.s	{ v31 }[2], [x12]
	tbz	w19, #3, LBB1_52
LBB1_59:                                ; %cond.load129
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x0, #12
	ld1.s	{ v31 }[3], [x12]
	tbz	w19, #4, LBB1_53
LBB1_60:                                ; %cond.load132
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x0, #16
	ld1.s	{ v10 }[0], [x12]
	tbz	w19, #5, LBB1_54
LBB1_61:                                ; %cond.load135
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x0, #20
	ld1.s	{ v10 }[1], [x12]
	tbz	w19, #6, LBB1_55
LBB1_62:                                ; %cond.load138
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x0, #24
	ld1.s	{ v10 }[2], [x12]
	tbz	w19, #7, LBB1_47
LBB1_63:                                ; %cond.load141
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x0, #28
	ld1.s	{ v10 }[3], [x12]
	b	LBB1_47
LBB1_64:                                ; %direct.false190.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
Lloh22:
	adrp	x12, lCPI1_11@PAGE
Lloh23:
	ldr	q3, [x12, lCPI1_11@PAGEOFF]
	and.16b	v28, v0, v3
Lloh24:
	adrp	x12, lCPI1_12@PAGE
Lloh25:
	ldr	q3, [x12, lCPI1_12@PAGEOFF]
	and.16b	v29, v1, v3
Lloh26:
	adrp	x12, lCPI1_14@PAGE
Lloh27:
	ldr	q3, [x12, lCPI1_14@PAGEOFF]
	and.16b	v27, v1, v3
	ldr	q30, [sp, #448]                 ; 16-byte Reload
	zip2.8b	v3, v30, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldp	q4, q24, [sp, #64]              ; 32-byte Folded Reload
	and.16b	v4, v3, v4
	zip1.8b	v16, v30, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v24, v16, v24
	fmul.4s	v24, v24, v24
	fmul.4s	v4, v4, v4
	fadd.4s	v2, v4, v2
	fadd.4s	v4, v24, v7
	and.16b	v4, v16, v4
	and.16b	v2, v3, v2
	ldr	q7, [sp, #96]                   ; 16-byte Reload
	zip2.8b	v3, v7, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v2, v23, v3
	zip1.8b	v3, v7, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v22, v4
	fadd.4s	v3, v6, v3
	fadd.4s	v2, v5, v2
	fadd.4s	v4, v17, v2
	fadd.4s	v2, v8, v3
	fadd.4s	v2, v14, v2
	fadd.4s	v5, v12, v4
	fmov	w12, s29
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldr	q3, [sp, #416]                  ; 16-byte Reload
	str	d3, [sp, #552]
	ldrb	w17, [x17]
	add	x0, sp, #1168
	orr	x12, x0, x12, lsl #2
	str	q5, [sp, #1184]
	str	q2, [sp, #1168]
	ldr	s3, [x12]
	tst	w10, w17
	movi.2d	v25, #0000000000000000
	fcsel	s6, s3, s25, ne
	mov.s	w12, v29[1]
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w12, [x17]
	and	w12, w3, w12
	str	q2, [sp, #1136]
	ldr	s3, [sp, #1136]
	tst	w12, #0x1
	mov.s	w12, v29[2]
	fcsel	s7, s3, s25, ne
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	add	x0, sp, #1104
	orr	x12, x0, x12, lsl #2
	ldrb	w17, [x17]
	and	w17, w1, w17
	str	q5, [sp, #1120]
	str	q2, [sp, #1104]
	ldr	s3, [x12]
	tst	w17, #0x1
	mov.s	w12, v29[3]
	fcsel	s17, s3, s25, ne
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	add	x0, sp, #1072
	orr	x12, x0, x12, lsl #2
	ldrb	w17, [x17]
	and	w17, w2, w17
	str	q5, [sp, #1088]
	str	q2, [sp, #1072]
	ldr	s3, [x12]
	tst	w17, #0x1
	fcsel	s22, s3, s25, ne
	fmov	w12, s28
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	and	w17, w7, w17
	str	q5, [sp, #1056]
	str	q2, [sp, #1040]
	add	x0, sp, #1040
	ldr	s3, [x0, w12, uxtw #2]
	tst	w17, #0x1
	fcsel	s3, s3, s25, ne
	mov.s	w12, v28[1]
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	and	w17, w6, w17
	stp	q2, q5, [sp, #1008]
	add	x0, sp, #1008
	ldr	s4, [x0, w12, uxtw #2]
	tst	w17, #0x1
	fcsel	s4, s4, s25, ne
	mov.s	w12, v28[2]
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	and	w17, w5, w17
	stp	q2, q5, [sp, #976]
	add	x0, sp, #976
	ldr	s16, [x0, w12, uxtw #2]
	tst	w17, #0x1
	fcsel	s16, s16, s25, ne
	mov.s	w12, v28[3]
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	and	w17, w30, w17
	stp	q2, q5, [sp, #944]
	add	x0, sp, #944
	ldr	s23, [x0, w12, uxtw #2]
	tst	w17, #0x1
	fcsel	s23, s23, s25, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v16[0]
	mov.s	v3[3], v23[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v22[0]
	fadd.4s	v2, v2, v6
	fadd.4s	v5, v5, v3
	fmov	w12, s27
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	add	x0, sp, #912
	orr	x12, x0, x12, lsl #2
	stp	q2, q5, [sp, #912]
	ldr	s3, [x12]
	tst	w10, w17
	mov.s	w12, v27[1]
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	and	w17, w3, w17
	fcsel	s6, s3, s25, ne
	add	x0, sp, #880
	orr	x12, x0, x12, lsl #2
	stp	q2, q5, [sp, #880]
	ldr	s3, [x12]
	tst	w17, #0x1
	mov.s	w12, v27[2]
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	fcsel	s7, s3, s25, ne
	ldrb	w12, [x17]
	and	w12, w1, w12
	str	q2, [sp, #848]
	tst	w12, #0x1
	mov.s	w12, v27[3]
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	and	w17, w2, w17
Lloh28:
	adrp	x0, lCPI1_13@PAGE
Lloh29:
	ldr	q3, [x0, lCPI1_13@PAGEOFF]
	and.16b	v3, v0, v3
	ldr	s4, [sp, #848]
	fcsel	s17, s4, s25, ne
	add	x0, sp, #816
	orr	x12, x0, x12, lsl #2
	stp	q2, q5, [sp, #816]
	ldr	s4, [x12]
	tst	w17, #0x1
	fmov	w12, s3
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	stp	q2, q5, [sp, #784]
	add	x0, sp, #784
	ldr	s16, [x0, w12, uxtw #2]
	fcsel	s22, s4, s25, ne
	and	w12, w7, w17
	tst	w12, #0x1
	mov.s	w12, v3[1]
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	stp	q2, q5, [sp, #752]
	add	x0, sp, #752
	ldr	s4, [x0, w12, uxtw #2]
	fcsel	s23, s16, s25, ne
	and	w12, w6, w17
	tst	w12, #0x1
	mov.s	w12, v3[2]
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	stp	q2, q5, [sp, #720]
	add	x0, sp, #720
	ldr	s16, [x0, w12, uxtw #2]
	fcsel	s4, s4, s25, ne
	and	w12, w5, w17
	tst	w12, #0x1
	mov.s	w12, v3[3]
	add	x17, sp, #552
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	and	w17, w30, w17
	movi.4s	v3, #4
	and.16b	v3, v1, v3
	fcsel	s16, s16, s25, ne
	stp	q2, q5, [sp, #688]
	add	x0, sp, #688
	ldr	s24, [x0, w12, uxtw #2]
	tst	w17, #0x1
	fcsel	s24, s24, s25, ne
	fmov	w12, s3
	add	x17, sp, #552
	orr	x17, x17, x12
	ldrb	w17, [x17]
	tst	w10, w17
	mov.s	v23[1], v4[0]
	mov.s	v23[2], v16[0]
	mov.s	v23[3], v24[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v22[0]
	fadd.4s	v2, v2, v6
	fadd.4s	v3, v5, v23
	stp	q2, q3, [sp, #656]
	add	x10, sp, #656
	ldr	s3, [x10, w12, uxtw #2]
	fcsel	s3, s3, s25, ne
	tst	w16, #0x1
	fadd	s2, s2, s3
	fcsel	s3, s2, s25, ne
	ldr	w10, [sp, #192]                 ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s4, s2, s25, ne
	ldr	w10, [sp, #160]                 ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s5, s2, s25, ne
	ldr	w10, [sp, #144]                 ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s6, s2, s25, ne
	tst	w4, #0x1
	fcsel	s7, s2, s25, ne
	ldr	w10, [sp, #128]                 ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s16, s2, s25, ne
	ldr	w10, [sp, #124]                 ; 4-byte Reload
	tst	w10, #0x1
Lloh30:
	adrp	x10, lCPI1_15@PAGE
Lloh31:
	ldr	d17, [x10, lCPI1_15@PAGEOFF]
	shl.8b	v22, v30, #7
	cmlt.8b	v22, v22, #0
	and.8b	v17, v22, v17
	fcsel	s22, s2, s25, ne
	ldr	w10, [sp, #176]                 ; 4-byte Reload
	tst	w10, #0x1
	movi.2d	v23, #0000000000000000
	fcsel	s2, s2, s25, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v5[0]
	mov.s	v3[3], v6[0]
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v22[0]
	mov.s	v7[3], v2[0]
	addv.8b	b26, v17
	stp	q3, q7, [sp, #624]
	ldr	x10, [sp, #216]                 ; 8-byte Reload
	and	x10, x10, #0x7
	add	x12, sp, #624
	ldr	s2, [x12, x10, lsl #2]
	fmov	w16, s26
	mov	b3, v30[0]
	mov.b	v3[4], v30[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #272]                  ; 16-byte Reload
	and.16b	v3, v3, v4
	mov	b4, v30[2]
	mov.b	v4[4], v30[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldp	q5, q7, [sp, #224]              ; 32-byte Folded Reload
	and.16b	v4, v4, v5
	mov	b5, v30[4]
	mov.b	v5[4], v30[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	mov	b6, v30[6]
	mov.b	v6[4], v30[7]
	and.16b	v5, v5, v7
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldr	q7, [sp, #256]                  ; 16-byte Reload
	and.16b	v6, v6, v7
	stp	q5, q6, [sp, #592]
	stp	q3, q4, [sp, #560]
	add	x10, x9, x27
	ldp	q5, q6, [x10]
	ldr	x1, [sp, #400]                  ; 8-byte Reload
	and	x10, x1, #0x7
	add	x12, sp, #560
	ldr	x10, [x12, x10, lsl #3]
	sub	x10, x10, x1
	lsl	x10, x10, #2
	add	x15, x15, x10
	tbnz	w16, #0, LBB1_144
; %bb.65:                               ; %else146
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q16, [sp, #432]                 ; 16-byte Reload
	tbnz	w16, #1, LBB1_145
LBB1_66:                                ; %else149
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #2, LBB1_146
LBB1_67:                                ; %else152
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #3, LBB1_147
LBB1_68:                                ; %else155
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #4, LBB1_148
LBB1_69:                                ; %else158
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #5, LBB1_149
LBB1_70:                                ; %else161
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w16, #6, LBB1_150
LBB1_71:                                ; %else164
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_73
LBB1_72:                                ; %cond.load166
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x15, #28
	ld1.s	{ v6 }[3], [x12]
LBB1_73:                                ; %else167
                                        ;   in Loop: Header=BB1_4 Depth=1
	fadd	s2, s2, s23
	mov	w12, #2048                      ; =0x800
	movk	w12, #17792, lsl #16
	fmov	s3, w12
	fdiv	s2, s2, s3
	add	x12, x9, x27
	stp	q5, q6, [x12]
	mov	w12, #50604                     ; =0xc5ac
	movk	w12, #14119, lsl #16
	fmov	s3, w12
	fadd	s2, s2, s3
	fsqrt	s5, s2
	subs	x12, x8, x14
	cset	w15, hs
	mov	w16, #16387                     ; =0x4003
	cmp	x12, x16
	csel	w15, wzr, w15, ls
	subs	x12, x14, x8
	mov	w16, #4095                      ; =0xfff
	movk	w16, #256, lsl #16
	ccmp	x12, x16, #0, hs
	b.hi	LBB1_93
; %bb.74:                               ; %else167
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w15, #0, LBB1_93
; %bb.75:                               ; %direct.true259.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x15, #0                         ; =0x0
	movi.2d	v2, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	b	LBB1_77
LBB1_76:                                ; %else259
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x12, x13, x15
	stp	q17, q22, [x12]
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v16, v16, v18
	add.2d	v2, v2, v21
	fmov	x15, d2
	cmp	x15, #512
	b.ge	LBB1_151
LBB1_77:                                ; %direct.true259.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w17, s9
	lsl	x15, x15, #5
	add	x16, x14, x15
	add	x0, x13, x15
	ldr	q17, [x0]
	tbnz	w17, #0, LBB1_85
; %bb.78:                               ; %else238
                                        ;   in Loop: Header=BB1_77 Depth=2
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_86
LBB1_79:                                ; %else241
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w17, #2, LBB1_87
LBB1_80:                                ; %else244
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w17, #3, LBB1_88
LBB1_81:                                ; %else247
                                        ;   in Loop: Header=BB1_77 Depth=2
	ldr	q22, [x0, #16]
	tbnz	w17, #4, LBB1_89
LBB1_82:                                ; %else250
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w17, #5, LBB1_90
LBB1_83:                                ; %else253
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbnz	w17, #6, LBB1_91
LBB1_84:                                ; %else256
                                        ;   in Loop: Header=BB1_77 Depth=2
	tbz	w17, #7, LBB1_76
	b	LBB1_92
LBB1_85:                                ; %cond.load237
                                        ;   in Loop: Header=BB1_77 Depth=2
	ld1.s	{ v17 }[0], [x16]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_79
LBB1_86:                                ; %cond.load240
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x12, x16, #4
	ld1.s	{ v17 }[1], [x12]
	tbz	w17, #2, LBB1_80
LBB1_87:                                ; %cond.load243
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x12, x16, #8
	ld1.s	{ v17 }[2], [x12]
	tbz	w17, #3, LBB1_81
LBB1_88:                                ; %cond.load246
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x12, x16, #12
	ld1.s	{ v17 }[3], [x12]
	ldr	q22, [x0, #16]
	tbz	w17, #4, LBB1_82
LBB1_89:                                ; %cond.load249
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x12, x16, #16
	ld1.s	{ v22 }[0], [x12]
	tbz	w17, #5, LBB1_83
LBB1_90:                                ; %cond.load252
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x12, x16, #20
	ld1.s	{ v22 }[1], [x12]
	tbz	w17, #6, LBB1_84
LBB1_91:                                ; %cond.load255
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x12, x16, #24
	ld1.s	{ v22 }[2], [x12]
	tbz	w17, #7, LBB1_76
LBB1_92:                                ; %cond.load258
                                        ;   in Loop: Header=BB1_77 Depth=2
	add	x12, x16, #28
	ld1.s	{ v22 }[3], [x12]
	b	LBB1_76
LBB1_93:                                ; %direct.schedule.27.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x13, #0                         ; =0x0
	ldr	q2, [sp, #288]                  ; 16-byte Reload
	add.2d	v2, v2, v16
	dup.4s	v17, v5[0]
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v22, #0000000000000000
	b	LBB1_95
LBB1_94:                                ; %else210
                                        ;   in Loop: Header=BB1_95 Depth=2
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v22, v22, v18
	add.2d	v5, v5, v21
	fmov	x13, d5
	cmp	x13, #512
	b.ge	LBB1_127
LBB1_95:                                ; %direct.true217.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w16, s9
	shl.2d	v24, v5, #3
	orr.16b	v3, v24, v16
	fmov	x12, d3
	add	x15, x14, x12, lsl #2
	movi.2d	v25, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w16, #0, LBB1_112
; %bb.96:                               ; %else171
                                        ;   in Loop: Header=BB1_95 Depth=2
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_113
LBB1_97:                                ; %else174
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w16, #2, LBB1_114
LBB1_98:                                ; %else177
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w16, #3, LBB1_115
LBB1_99:                                ; %else180
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w16, #4, LBB1_116
LBB1_100:                               ; %else183
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w16, #5, LBB1_117
LBB1_101:                               ; %else186
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w16, #6, LBB1_118
LBB1_102:                               ; %else189
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbz	w16, #7, LBB1_104
LBB1_103:                               ; %cond.load191
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x15, #28
	ld1.s	{ v23 }[3], [x12]
LBB1_104:                               ; %else192
                                        ;   in Loop: Header=BB1_95 Depth=2
	lsl	x12, x13, #5
	add	x13, x11, x12
	ldp	q3, q27, [x13]
	and.16b	v3, v1, v3
	fdiv.4s	v3, v3, v17
	add	x12, x9, x12
	ldp	q4, q28, [x12]
	and.16b	v4, v1, v4
	fmul.4s	v3, v3, v4
	fmov	w15, s9
	fadd.4s	v25, v25, v3
	add.2d	v3, v2, v24
	fmov	x12, d3
	add	x13, x8, x12, lsl #2
	tbnz	w15, #0, LBB1_119
; %bb.105:                              ; %else196
                                        ;   in Loop: Header=BB1_95 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_120
LBB1_106:                               ; %else198
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w15, #2, LBB1_121
LBB1_107:                               ; %else200
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w15, #3, LBB1_122
LBB1_108:                               ; %else202
                                        ;   in Loop: Header=BB1_95 Depth=2
	and.16b	v3, v0, v27
	fdiv.4s	v3, v3, v17
	and.16b	v4, v0, v28
	fmul.4s	v3, v3, v4
	fadd.4s	v23, v23, v3
	tbnz	w15, #4, LBB1_123
LBB1_109:                               ; %else204
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w15, #5, LBB1_124
LBB1_110:                               ; %else206
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbnz	w15, #6, LBB1_125
LBB1_111:                               ; %else208
                                        ;   in Loop: Header=BB1_95 Depth=2
	tbz	w15, #7, LBB1_94
	b	LBB1_126
LBB1_112:                               ; %cond.load170
                                        ;   in Loop: Header=BB1_95 Depth=2
	ldr	s25, [x15]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_97
LBB1_113:                               ; %cond.load173
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x15, #4
	ld1.s	{ v25 }[1], [x12]
	tbz	w16, #2, LBB1_98
LBB1_114:                               ; %cond.load176
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x15, #8
	ld1.s	{ v25 }[2], [x12]
	tbz	w16, #3, LBB1_99
LBB1_115:                               ; %cond.load179
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x15, #12
	ld1.s	{ v25 }[3], [x12]
	tbz	w16, #4, LBB1_100
LBB1_116:                               ; %cond.load182
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x15, #16
	ld1.s	{ v23 }[0], [x12]
	tbz	w16, #5, LBB1_101
LBB1_117:                               ; %cond.load185
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x15, #20
	ld1.s	{ v23 }[1], [x12]
	tbz	w16, #6, LBB1_102
LBB1_118:                               ; %cond.load188
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x15, #24
	ld1.s	{ v23 }[2], [x12]
	tbnz	w16, #7, LBB1_103
	b	LBB1_104
LBB1_119:                               ; %cond.store195
                                        ;   in Loop: Header=BB1_95 Depth=2
	str	s25, [x13]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_106
LBB1_120:                               ; %cond.store197
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x13, #4
	st1.s	{ v25 }[1], [x12]
	tbz	w15, #2, LBB1_107
LBB1_121:                               ; %cond.store199
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x13, #8
	st1.s	{ v25 }[2], [x12]
	tbz	w15, #3, LBB1_108
LBB1_122:                               ; %cond.store201
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x13, #12
	st1.s	{ v25 }[3], [x12]
	and.16b	v3, v0, v27
	fdiv.4s	v3, v3, v17
	and.16b	v4, v0, v28
	fmul.4s	v3, v3, v4
	fadd.4s	v23, v23, v3
	tbz	w15, #4, LBB1_109
LBB1_123:                               ; %cond.store203
                                        ;   in Loop: Header=BB1_95 Depth=2
	str	s23, [x13, #16]
	tbz	w15, #5, LBB1_110
LBB1_124:                               ; %cond.store205
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x13, #20
	st1.s	{ v23 }[1], [x12]
	tbz	w15, #6, LBB1_111
LBB1_125:                               ; %cond.store207
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x13, #24
	st1.s	{ v23 }[2], [x12]
	tbz	w15, #7, LBB1_94
LBB1_126:                               ; %cond.store209
                                        ;   in Loop: Header=BB1_95 Depth=2
	add	x12, x13, #28
	st1.s	{ v23 }[3], [x12]
	b	LBB1_94
LBB1_127:                               ; %direct.false218.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x11, x27
	ldp	q0, q5, [x11]
	fmov	w11, s26
	add	x9, x9, x27
	ldp	q2, q1, [x9]
	add	x9, x14, x10
	movi.2d	v3, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w11, #0, LBB1_195
; %bb.128:                              ; %else213
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #1, LBB1_196
LBB1_129:                               ; %else216
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #2, LBB1_197
LBB1_130:                               ; %else219
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #3, LBB1_198
LBB1_131:                               ; %else222
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #4, LBB1_199
LBB1_132:                               ; %else225
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #5, LBB1_200
LBB1_133:                               ; %else228
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w11, #6, LBB1_201
LBB1_134:                               ; %else231
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w11, #7, LBB1_136
LBB1_135:                               ; %cond.load233
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v6 }[3], [x9]
LBB1_136:                               ; %else234
                                        ;   in Loop: Header=BB1_4 Depth=1
	zip2.8b	v4, v30, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v5, v4, v5
	zip1.8b	v7, v30, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v0, v7, v0
	fdiv.4s	v0, v0, v17
	fdiv.4s	v5, v5, v17
	and.16b	v2, v7, v2
	and.16b	v1, v4, v1
	fmul.4s	v4, v5, v1
	fmul.4s	v0, v0, v2
	fadd.4s	v1, v3, v0
	fadd.4s	v0, v6, v4
	b	LBB1_179
LBB1_137:                               ; %cond.load95
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v17 }[0], [x10]
	tbz	w16, #1, LBB1_33
LBB1_138:                               ; %cond.load98
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x10, #4
	ld1.s	{ v17 }[1], [x0]
	tbz	w16, #2, LBB1_34
LBB1_139:                               ; %cond.load101
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x10, #8
	ld1.s	{ v17 }[2], [x0]
	tbz	w16, #3, LBB1_35
LBB1_140:                               ; %cond.load104
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x10, #12
	ld1.s	{ v17 }[3], [x0]
	tbz	w16, #4, LBB1_36
LBB1_141:                               ; %cond.load107
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x10, #16
	ld1.s	{ v25 }[0], [x0]
	tbz	w16, #5, LBB1_37
LBB1_142:                               ; %cond.load110
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x10, #20
	ld1.s	{ v25 }[1], [x0]
	tbz	w16, #6, LBB1_38
LBB1_143:                               ; %cond.load113
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x10, #24
	ld1.s	{ v25 }[2], [x0]
	str	q4, [sp, #448]                  ; 16-byte Spill
	str	q24, [sp, #368]                 ; 16-byte Spill
	tbnz	w16, #7, LBB1_39
	b	LBB1_40
LBB1_144:                               ; %cond.load145
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v5 }[0], [x15]
	ldr	q16, [sp, #432]                 ; 16-byte Reload
	tbz	w16, #1, LBB1_66
LBB1_145:                               ; %cond.load148
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x15, #4
	ld1.s	{ v5 }[1], [x12]
	tbz	w16, #2, LBB1_67
LBB1_146:                               ; %cond.load151
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x15, #8
	ld1.s	{ v5 }[2], [x12]
	tbz	w16, #3, LBB1_68
LBB1_147:                               ; %cond.load154
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x15, #12
	ld1.s	{ v5 }[3], [x12]
	tbz	w16, #4, LBB1_69
LBB1_148:                               ; %cond.load157
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x15, #16
	ld1.s	{ v6 }[0], [x12]
	tbz	w16, #5, LBB1_70
LBB1_149:                               ; %cond.load160
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x15, #20
	ld1.s	{ v6 }[1], [x12]
	tbz	w16, #6, LBB1_71
LBB1_150:                               ; %cond.load163
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x15, #24
	ld1.s	{ v6 }[2], [x12]
	tbnz	w16, #7, LBB1_72
	b	LBB1_73
LBB1_151:                               ; %direct.false260.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x14, x10
	add	x12, x13, x27
	ldp	q2, q6, [x12]
	fmov	w14, s26
	tbnz	w14, #0, LBB1_202
; %bb.152:                              ; %else263
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w14, #1, LBB1_203
LBB1_153:                               ; %else266
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w14, #2, LBB1_204
LBB1_154:                               ; %else269
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w14, #3, LBB1_205
LBB1_155:                               ; %else272
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w14, #4, LBB1_206
LBB1_156:                               ; %else275
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w14, #5, LBB1_207
LBB1_157:                               ; %else278
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w14, #6, LBB1_208
LBB1_158:                               ; %else281
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #7, LBB1_160
LBB1_159:                               ; %cond.load283
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v6 }[3], [x10]
LBB1_160:                               ; %else284
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x14, #0                         ; =0x0
	add	x10, x13, x27
	stp	q2, q6, [x10]
	dup.4s	v2, v5[0]
	ldr	q3, [sp, #288]                  ; 16-byte Reload
	fmov	x10, d3
	add	x10, x8, x10, lsl #2
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	b	LBB1_162
LBB1_161:                               ; %else302
                                        ;   in Loop: Header=BB1_162 Depth=2
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v16, v16, v18
	add.2d	v5, v5, v21
	fmov	x14, d5
	cmp	x14, #512
	b.ge	LBB1_178
LBB1_162:                               ; %direct.true284.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w15, s9
	lsl	x12, x14, #5
	add	x14, x11, x12
	ldp	q3, q17, [x14]
	and.16b	v3, v1, v3
	fdiv.4s	v3, v3, v2
	add	x14, x9, x12
	ldp	q4, q22, [x14]
	and.16b	v4, v1, v4
	fmul.4s	v3, v3, v4
	add	x14, x13, x12
	ldp	q4, q23, [x14]
	and.16b	v4, v1, v4
	fadd.4s	v24, v3, v4
	add	x14, x10, x12
	tbnz	w15, #0, LBB1_171
; %bb.163:                              ; %else288
                                        ;   in Loop: Header=BB1_162 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_172
LBB1_164:                               ; %else290
                                        ;   in Loop: Header=BB1_162 Depth=2
	tbnz	w15, #2, LBB1_173
LBB1_165:                               ; %else292
                                        ;   in Loop: Header=BB1_162 Depth=2
	tbz	w15, #3, LBB1_167
LBB1_166:                               ; %cond.store293
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x12, x14, #12
	st1.s	{ v24 }[3], [x12]
LBB1_167:                               ; %else294
                                        ;   in Loop: Header=BB1_162 Depth=2
	and.16b	v3, v0, v17
	fdiv.4s	v3, v3, v2
	and.16b	v4, v0, v22
	fmul.4s	v3, v3, v4
	and.16b	v4, v0, v23
	fadd.4s	v17, v3, v4
	tbnz	w15, #4, LBB1_174
; %bb.168:                              ; %else296
                                        ;   in Loop: Header=BB1_162 Depth=2
	tbnz	w15, #5, LBB1_175
LBB1_169:                               ; %else298
                                        ;   in Loop: Header=BB1_162 Depth=2
	tbnz	w15, #6, LBB1_176
LBB1_170:                               ; %else300
                                        ;   in Loop: Header=BB1_162 Depth=2
	tbz	w15, #7, LBB1_161
	b	LBB1_177
LBB1_171:                               ; %cond.store287
                                        ;   in Loop: Header=BB1_162 Depth=2
	str	s24, [x14]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_164
LBB1_172:                               ; %cond.store289
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x12, x14, #4
	st1.s	{ v24 }[1], [x12]
	tbz	w15, #2, LBB1_165
LBB1_173:                               ; %cond.store291
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x12, x14, #8
	st1.s	{ v24 }[2], [x12]
	tbnz	w15, #3, LBB1_166
	b	LBB1_167
LBB1_174:                               ; %cond.store295
                                        ;   in Loop: Header=BB1_162 Depth=2
	str	s17, [x14, #16]
	tbz	w15, #5, LBB1_169
LBB1_175:                               ; %cond.store297
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x12, x14, #20
	st1.s	{ v17 }[1], [x12]
	tbz	w15, #6, LBB1_170
LBB1_176:                               ; %cond.store299
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x12, x14, #24
	st1.s	{ v17 }[2], [x12]
	tbz	w15, #7, LBB1_161
LBB1_177:                               ; %cond.store301
                                        ;   in Loop: Header=BB1_162 Depth=2
	add	x12, x14, #28
	st1.s	{ v17 }[3], [x12]
	b	LBB1_161
LBB1_178:                               ; %direct.false285.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x11, x27
	ldp	q1, q0, [x10]
	zip1.8b	v3, v30, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v1, v3, v1
	zip2.8b	v4, v30, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v0, v4, v0
	fdiv.4s	v0, v0, v2
	fdiv.4s	v1, v1, v2
	add	x9, x9, x27
	ldp	q2, q5, [x9]
	and.16b	v5, v4, v5
	and.16b	v2, v3, v2
	fmul.4s	v1, v1, v2
	fmul.4s	v0, v0, v5
	add	x9, x13, x27
	ldp	q5, q2, [x9]
	and.16b	v3, v3, v5
	and.16b	v2, v4, v2
	fadd.4s	v0, v0, v2
	fadd.4s	v1, v1, v3
LBB1_179:                               ; %common.ret.sink.split.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q3, [sp, #384]                  ; 16-byte Reload
	ldp	q5, q4, [sp, #320]              ; 32-byte Folded Reload
	stp	q3, q4, [sp, #480]
	ldr	q2, [sp, #352]                  ; 16-byte Reload
	stp	q5, q2, [sp, #512]
	and	x9, x1, #0x7
	add	x10, sp, #480
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x1
	add	x8, x8, x9, lsl #2
	fmov	w9, s26
	tbnz	w9, #0, LBB1_187
; %bb.180:                              ; %else
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #1, LBB1_188
LBB1_181:                               ; %else58
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #2, LBB1_189
LBB1_182:                               ; %else60
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #3, LBB1_190
LBB1_183:                               ; %else62
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #4, LBB1_191
LBB1_184:                               ; %else64
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #5, LBB1_192
LBB1_185:                               ; %else66
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w9, #6, LBB1_193
LBB1_186:                               ; %else68
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #7, LBB1_2
	b	LBB1_194
LBB1_187:                               ; %cond.store
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x8]
	tbz	w9, #1, LBB1_181
LBB1_188:                               ; %cond.store57
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #4
	st1.s	{ v1 }[1], [x10]
	tbz	w9, #2, LBB1_182
LBB1_189:                               ; %cond.store59
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #8
	st1.s	{ v1 }[2], [x10]
	tbz	w9, #3, LBB1_183
LBB1_190:                               ; %cond.store61
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #12
	st1.s	{ v1 }[3], [x10]
	tbz	w9, #4, LBB1_184
LBB1_191:                               ; %cond.store63
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x8, #16]
	tbz	w9, #5, LBB1_185
LBB1_192:                               ; %cond.store65
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w9, #6, LBB1_186
LBB1_193:                               ; %cond.store67
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB1_2
LBB1_194:                               ; %cond.store69
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB1_2
LBB1_195:                               ; %cond.load212
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s3, [x9]
	tbz	w11, #1, LBB1_129
LBB1_196:                               ; %cond.load215
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #4
	ld1.s	{ v3 }[1], [x10]
	tbz	w11, #2, LBB1_130
LBB1_197:                               ; %cond.load218
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #8
	ld1.s	{ v3 }[2], [x10]
	tbz	w11, #3, LBB1_131
LBB1_198:                               ; %cond.load221
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #12
	ld1.s	{ v3 }[3], [x10]
	tbz	w11, #4, LBB1_132
LBB1_199:                               ; %cond.load224
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #16
	ld1.s	{ v6 }[0], [x10]
	tbz	w11, #5, LBB1_133
LBB1_200:                               ; %cond.load227
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #20
	ld1.s	{ v6 }[1], [x10]
	tbz	w11, #6, LBB1_134
LBB1_201:                               ; %cond.load230
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #24
	ld1.s	{ v6 }[2], [x10]
	tbnz	w11, #7, LBB1_135
	b	LBB1_136
LBB1_202:                               ; %cond.load262
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v2 }[0], [x10]
	tbz	w14, #1, LBB1_153
LBB1_203:                               ; %cond.load265
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x10, #4
	ld1.s	{ v2 }[1], [x12]
	tbz	w14, #2, LBB1_154
LBB1_204:                               ; %cond.load268
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x10, #8
	ld1.s	{ v2 }[2], [x12]
	tbz	w14, #3, LBB1_155
LBB1_205:                               ; %cond.load271
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x10, #12
	ld1.s	{ v2 }[3], [x12]
	tbz	w14, #4, LBB1_156
LBB1_206:                               ; %cond.load274
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x10, #16
	ld1.s	{ v6 }[0], [x12]
	tbz	w14, #5, LBB1_157
LBB1_207:                               ; %cond.load277
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x10, #20
	ld1.s	{ v6 }[1], [x12]
	tbz	w14, #6, LBB1_158
LBB1_208:                               ; %cond.load280
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x10, #24
	ld1.s	{ v6 }[2], [x12]
	tbnz	w14, #7, LBB1_159
	b	LBB1_160
LBB1_209:
	add	sp, sp, #1712
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB1_210:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
                                        ; -- End function
.subsections_via_symbols

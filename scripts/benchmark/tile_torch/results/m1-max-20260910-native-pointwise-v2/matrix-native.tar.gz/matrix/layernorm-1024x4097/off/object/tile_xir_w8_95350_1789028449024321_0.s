	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	mov	x10, #0                         ; =0x0
	ldr	x8, [x1, #136]
	ldr	x14, [x0]
	ldr	x13, [x0, #16]
	ldr	w9, [x1]
	ldr	w11, [x1, #36]
	add	w9, w11, w9, lsl #5
	lsr	w9, w9, #3
	dup.2s	v0, w9
	ushll.2d	v0, v0, #0
	fmov	x9, d0
	mov	w11, #16388                     ; =0x4004
	umaddl	x12, w9, w11, x14
	ldr	x11, [x0, #32]
	ldr	x9, [x0, #48]
LBB0_1:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x12, x10
	ldp	q1, q2, [x15]
	add	x15, x8, x10
	stp	q1, q2, [x15]
	add	x10, x10, #32
	cmp	x10, #4, lsl #12                ; =16384
	b.ne	LBB0_1
; %bb.2:                                ; %direct.false
	fmov	x10, d0
	add	x10, x10, x10, lsl #12
	lsl	x12, x10, #2
	add	x10, x12, #4, lsl #12           ; =16384
	add	x14, x14, x10
	ldr	q0, [x8, #16384]
	ld1.s	{ v0 }[0], [x14]
	str	q0, [x8, #16384]
	ldp	q1, q2, [x8]
	ldp	q6, q7, [x8, #32]
	ldp	q16, q3, [x8, #64]
	ldp	q4, q5, [x8, #96]
	add	x14, x8, #224
	mov	w15, #4                         ; =0x4
LBB0_3:                                 ; %direct.true79
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q17, q18, [x14, #-96]
	fadd.4s	v2, v2, v18
	fadd.4s	v1, v1, v17
	ldp	q17, q18, [x14, #-64]
	fadd.4s	v7, v7, v18
	fadd.4s	v6, v6, v17
	ldp	q17, q18, [x14, #-32]
	fadd.4s	v3, v3, v18
	fadd.4s	v16, v16, v17
	ldp	q17, q18, [x14], #128
	fadd.4s	v5, v5, v18
	fadd.4s	v4, v4, v17
	cmp	x15, #508
	add	x15, x15, #4
	b.lo	LBB0_3
; %bb.4:                                ; %direct.false80
	fadd.4s	v17, v0, v1
	mov.s	v1[0], v17[0]
	fadd.4s	v2, v7, v2
	fadd.4s	v1, v6, v1
	fadd.4s	v1, v16, v1
	fadd.4s	v2, v3, v2
	fadd.4s	v2, v5, v2
	fadd.4s	v1, v4, v1
	rev64.4s	v3, v1
	rev64.4s	v4, v2
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	dup.4s	v3, v1[2]
	dup.4s	v4, v2[2]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	fadd.4s	v1, v1, v2
	movi.2d	v2, #0000000000000000
	fadd	s1, s1, s2
	mov	w14, #2048                      ; =0x800
	movk	w14, #17792, lsl #16
	fmov	s2, w14
	fdiv	s1, s1, s2
	dup.4s	v1, v1[0]
	mov	w14, #512                       ; =0x200
	mov	x15, x8
LBB0_5:                                 ; %direct.true114
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q3, q2, [x15]
	fsub.4s	v3, v3, v1
	fsub.4s	v2, v2, v1
	str	q2, [x15, #16432]
	str	q3, [x15, #16416]
	add	x15, x15, #32
	subs	x14, x14, #1
	b.ne	LBB0_5
; %bb.6:                                ; %direct.false115
	fsub.4s	v0, v0, v1
	ldr	q1, [x8, #32800]
	mov.s	v1[0], v0[0]
	str	q1, [x8, #32800]
	ldr	q1, [x8, #16416]
	ldr	q2, [x8, #16432]
	fmul.4s	v2, v2, v2
	fmul.4s	v1, v1, v1
	ldr	q3, [x8, #16448]
	ldr	q4, [x8, #16464]
	fmul.4s	v4, v4, v4
	fmul.4s	v3, v3, v3
	ldr	q6, [x8, #16480]
	ldr	q5, [x8, #16496]
	fmul.4s	v5, v5, v5
	fmul.4s	v6, v6, v6
	ldr	q7, [x8, #16512]
	ldr	q16, [x8, #16528]
	fmul.4s	v16, v16, v16
	fmul.4s	v7, v7, v7
	mov	w14, #16640                     ; =0x4100
	add	x14, x8, x14
	mov	w15, #517                       ; =0x205
LBB0_7:                                 ; %direct.true151
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q18, q17, [x14, #-96]
	fmul.4s	v18, v18, v18
	fmul.4s	v17, v17, v17
	fadd.4s	v2, v2, v17
	fadd.4s	v1, v1, v18
	ldp	q18, q17, [x14, #-64]
	fmul.4s	v18, v18, v18
	fmul.4s	v17, v17, v17
	fadd.4s	v4, v4, v17
	fadd.4s	v3, v3, v18
	ldp	q18, q17, [x14, #-32]
	fmul.4s	v18, v18, v18
	fmul.4s	v17, v17, v17
	fadd.4s	v5, v5, v17
	fadd.4s	v6, v6, v18
	ldp	q18, q17, [x14], #128
	fmul.4s	v18, v18, v18
	fmul.4s	v17, v17, v17
	fadd.4s	v16, v16, v17
	fadd.4s	v7, v7, v18
	sub	x16, x15, #513
	add	x15, x15, #4
	cmp	x16, #508
	b.lo	LBB0_7
; %bb.8:                                ; %direct.false152
	mov	x14, #0                         ; =0x0
	mov	w15, #32832                     ; =0x8040
	add	x15, x8, x15
LBB0_9:                                 ; %direct.true188
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x14
	ldp	q17, q18, [x16]
	add	x16, x15, x14
	stp	q17, q18, [x16]
	add	x14, x14, #32
	cmp	x14, #4, lsl #12                ; =16384
	b.ne	LBB0_9
; %bb.10:                               ; %direct.false189
	mov	x14, #0                         ; =0x0
	mov	w15, #49248                     ; =0xc060
	add	x15, x8, x15
	mov	w16, #16384                     ; =0x4000
	ldr	s17, [x13, x16]
	mov	w13, #49216                     ; =0xc040
	str	s17, [x8, x13]
LBB0_11:                                ; %direct.true214
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x11, x14
	ldp	q17, q18, [x13]
	add	x13, x15, x14
	stp	q17, q18, [x13]
	add	x14, x14, #32
	cmp	x14, #4, lsl #12                ; =16384
	b.ne	LBB0_11
; %bb.12:                               ; %direct.false215
	fmul.4s	v0, v0, v0
	fadd.4s	v0, v0, v1
	mov.s	v1[0], v0[0]
	fadd.4s	v0, v4, v2
	fadd.4s	v1, v3, v1
	fadd.4s	v1, v6, v1
	fadd.4s	v0, v5, v0
	fadd.4s	v0, v16, v0
	fadd.4s	v1, v7, v1
	rev64.4s	v2, v1
	rev64.4s	v3, v0
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	dup.4s	v2, v1[2]
	dup.4s	v3, v0[2]
	fadd.4s	v0, v0, v3
	fadd.4s	v1, v1, v2
	fadd.4s	v0, v1, v0
	movi.2d	v1, #0000000000000000
	fadd	s0, s0, s1
	mov	w13, #2048                      ; =0x800
	movk	w13, #17792, lsl #16
	fmov	s1, w13
	fdiv	s0, s0, s1
	mov	w13, #50604                     ; =0xc5ac
	movk	w13, #14119, lsl #16
	fmov	s1, w13
	fadd	s0, s0, s1
	mov	w13, #16384                     ; =0x4000
	ldr	s1, [x11, x13]
	mov	w11, #96                        ; =0x60
	movk	w11, #1, lsl #16
	str	s1, [x8, x11]
	fsqrt	s0, s0
	dup.4s	v0, v0[0]
	add	x11, x9, x12
	mov	w12, #512                       ; =0x200
	mov	x13, x8
LBB0_13:                                ; %direct.true239
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q1, [x13, #16432]
	ldr	q2, [x13, #16416]
	fdiv.4s	v2, v2, v0
	fdiv.4s	v1, v1, v0
	ldr	q3, [x13, #32832]
	ldr	q4, [x13, #32848]
	fmul.4s	v1, v1, v4
	fmul.4s	v2, v2, v3
	ldr	q3, [x13, #49264]
	ldr	q4, [x13, #49248]
	fadd.4s	v2, v2, v4
	fadd.4s	v1, v1, v3
	stp	q2, q1, [x11], #32
	add	x13, x13, #32
	subs	x12, x12, #1
	b.ne	LBB0_13
; %bb.14:                               ; %direct.false240
	ldr	q1, [x8, #32800]
	fdiv.4s	v0, v1, v0
	ldr	q1, [x8, #49216]
	fmul.4s	v0, v0, v1
	add	x11, x8, #16, lsl #12           ; =65536
	ldr	q1, [x11, #96]
	fadd.4s	v0, v0, v1
	str	s0, [x9, x10]
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_12:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI1_13:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI1_14:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI1_15:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_156
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1744
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	mov	w22, #0                         ; =0x0
	ldp	w9, w8, [x2, #44]
	str	w9, [sp, #492]                  ; 4-byte Spill
	str	w8, [sp, #488]                  ; 4-byte Spill
	ldp	w25, w24, [x2]
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Spill
Lloh4:
	adrp	x8, lCPI1_2@PAGE
Lloh5:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Spill
	mov	w23, #4                         ; =0x4
	ldp	w28, w26, [x2, #8]
	str	w3, [sp, #444]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w19, [sp, #444]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	ldr	w9, [sp, #492]                  ; 4-byte Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w24, eq
	ldr	w10, [sp, #488]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w24, wzr, w9, ne
	add	w28, w28, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_155
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_41 Depth 2
                                        ;     Child Loop BB1_43 Depth 2
                                        ;     Child Loop BB1_45 Depth 2
                                        ;     Child Loop BB1_48 Depth 2
                                        ;     Child Loop BB1_75 Depth 2
                                        ;     Child Loop BB1_102 Depth 2
	ubfiz	x8, x25, #5, #32
	cmp	x8, x26
	csel	x9, x8, xzr, ls
	subs	x10, x26, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x26, x9
	stp	w25, w24, [x20]
	str	w28, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x26, #2, hi
	csel	x27, x10, xzr, ls
	cmp	x27, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x19, x27, #3
	cbz	x19, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w27, #0x7
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v1, w8
	ldp	q0, q2, [sp, #32]               ; 32-byte Folded Reload
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	ldr	x27, [x20, #136]
	mov	w8, #16416                      ; =0x4020
	add	x11, x27, x8
	mov	w8, #32832                      ; =0x8040
	add	x10, x27, x8
	mov	w8, #49248                      ; =0xc060
	add	x9, x27, x8
	ldr	x8, [x21]
	ldr	x16, [x21, #16]
	ldr	x14, [x21, #32]
	ldr	x13, [x21, #48]
	str	x13, [sp, #432]                 ; 8-byte Spill
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v2, v3, v2
	addv.8h	h2, v2
	fmov	w13, s2
	and	w13, w13, #0xff
	str	w13, [sp, #208]                 ; 4-byte Spill
	ubfiz	w13, w25, #2, #27
	orr	w13, w13, w19
	dup.4s	v4, w13
	and.16b	v16, v1, v4
	and.16b	v4, v0, v4
	ushll2.2d	v5, v4, #0
	ushll2.2d	v6, v16, #0
	ushll.2d	v7, v4, #0
	ushll.2d	v16, v16, #0
	fmov	x13, d16
	mov	w15, #16388                     ; =0x4004
	umaddl	x13, w13, w15, x8
	fmov	w15, s2
	b	LBB1_15
LBB1_14:                                ; %else76
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x27, x12
	stp	q4, q17, [x17]
	add	x12, x12, #32
	cmp	x12, #4, lsl #12                ; =16384
	b.eq	LBB1_31
LBB1_15:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x17, x13, x12
	add	x1, x27, x12
	ldr	q4, [x1]
	tbnz	w15, #0, LBB1_23
; %bb.16:                               ; %else
                                        ;   in Loop: Header=BB1_15 Depth=2
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB1_24
LBB1_17:                                ; %else58
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w0, #2, LBB1_25
LBB1_18:                                ; %else61
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w0, #3, LBB1_26
LBB1_19:                                ; %else64
                                        ;   in Loop: Header=BB1_15 Depth=2
	ldr	q17, [x1, #16]
	tbnz	w0, #4, LBB1_27
LBB1_20:                                ; %else67
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w0, #5, LBB1_28
LBB1_21:                                ; %else70
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbnz	w0, #6, LBB1_29
LBB1_22:                                ; %else73
                                        ;   in Loop: Header=BB1_15 Depth=2
	tbz	w0, #7, LBB1_14
	b	LBB1_30
LBB1_23:                                ; %cond.load
                                        ;   in Loop: Header=BB1_15 Depth=2
	ld1.s	{ v4 }[0], [x17]
	and	w0, w15, #0xff
	tbz	w0, #1, LBB1_17
LBB1_24:                                ; %cond.load57
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x2, x17, #4
	ld1.s	{ v4 }[1], [x2]
	tbz	w0, #2, LBB1_18
LBB1_25:                                ; %cond.load60
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x2, x17, #8
	ld1.s	{ v4 }[2], [x2]
	tbz	w0, #3, LBB1_19
LBB1_26:                                ; %cond.load63
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x2, x17, #12
	ld1.s	{ v4 }[3], [x2]
	ldr	q17, [x1, #16]
	tbz	w0, #4, LBB1_20
LBB1_27:                                ; %cond.load66
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x1, x17, #16
	ld1.s	{ v17 }[0], [x1]
	tbz	w0, #5, LBB1_21
LBB1_28:                                ; %cond.load69
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x1, x17, #20
	ld1.s	{ v17 }[1], [x1]
	tbz	w0, #6, LBB1_22
LBB1_29:                                ; %cond.load72
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x1, x17, #24
	ld1.s	{ v17 }[2], [x1]
	tbz	w0, #7, LBB1_14
LBB1_30:                                ; %cond.load75
                                        ;   in Loop: Header=BB1_15 Depth=2
	add	x17, x17, #28
	ld1.s	{ v17 }[3], [x17]
	b	LBB1_14
LBB1_31:                                ; %direct.true79.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q2, [sp, #416]                  ; 16-byte Spill
	xtn.8b	v17, v3
	sshll.2d	v3, v1, #0
	sshll.2d	v21, v0, #0
	sshll2.2d	v25, v1, #0
	sshll2.2d	v26, v0, #0
Lloh6:
	adrp	x12, lCPI1_6@PAGE
Lloh7:
	ldr	q4, [x12, lCPI1_6@PAGEOFF]
	and.16b	v4, v3, v4
Lloh8:
	adrp	x12, lCPI1_7@PAGE
Lloh9:
	ldr	q18, [x12, lCPI1_7@PAGEOFF]
	and.16b	v19, v3, v18
Lloh10:
	adrp	x12, lCPI1_8@PAGE
Lloh11:
	ldr	q3, [x12, lCPI1_8@PAGEOFF]
	and.16b	v18, v21, v3
Lloh12:
	adrp	x12, lCPI1_9@PAGE
Lloh13:
	ldr	q3, [x12, lCPI1_9@PAGEOFF]
	and.16b	v20, v25, v3
Lloh14:
	adrp	x12, lCPI1_10@PAGE
Lloh15:
	ldr	q3, [x12, lCPI1_10@PAGEOFF]
	and.16b	v23, v26, v3
	movi.8b	v2, #1
	and.8b	v3, v17, v2
	umov.b	w15, v3[0]
	movi.2d	v3, #0000000000000000
	mov.b	v3[0], v17[0]
	umaxv.8b	b22, v3
	fmov	w17, s22
	rbit	w12, w15
	clz	w12, w12
	tst	w17, #0x1
	mov	w13, #4096                      ; =0x1000
	dup.2d	v22, x13
	csel	w1, w12, wzr, ne
	str	q4, [sp, #304]                  ; 16-byte Spill
	orr.16b	v2, v4, v22
	mov	w12, #4097                      ; =0x1001
	dup.2s	v28, w12
	xtn.2s	v29, v16
	str	q2, [sp, #176]                  ; 16-byte Spill
	umlal.2d	v2, v29, v28
	movi.2d	v16, #0000000000000000
	str	q17, [sp, #448]                 ; 16-byte Spill
	mov.b	v16[0], v17[0]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	str	q2, [sp, #384]                  ; 16-byte Spill
	and.16b	v16, v16, v2
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #1648]
	str	q2, [sp, #1632]
	str	q2, [sp, #1616]
	str	q16, [sp, #1600]
	ubfiz	x13, x1, #3, #3
	add	x12, sp, #1600
	ldr	x0, [x12, x13]
	sub	x0, x0, x1
	add	x8, x8, x0, lsl #2
	str	q23, [sp, #1712]
	str	q18, [sp, #1696]
	str	q20, [sp, #1680]
	str	q19, [sp, #1664]
	add	x12, sp, #1664
	ldr	x13, [x12, x13]
	orr	x13, x13, #0x4000
	sub	x13, x13, w1, uxtw #2
	tst	w15, #0x1
	csel	x13, xzr, x13, eq
	add	x0, x27, x13
	ldp	q17, q18, [x0]
	tbnz	w17, #0, LBB1_127
; %bb.32:                               ; %else80
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w15, #1, LBB1_128
LBB1_33:                                ; %else83
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w15, #2, LBB1_129
LBB1_34:                                ; %else86
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w15, #3, LBB1_130
LBB1_35:                                ; %else89
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w15, #4, LBB1_131
LBB1_36:                                ; %else92
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w15, #5, LBB1_132
LBB1_37:                                ; %else95
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w15, #6, LBB1_133
LBB1_38:                                ; %else98
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q3, [sp, #464]                  ; 16-byte Spill
	tbz	w15, #7, LBB1_40
LBB1_39:                                ; %cond.load100
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x8, #28
	ld1.s	{ v18 }[3], [x8]
LBB1_40:                                ; %else101
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	x1, [sp, #408]                  ; 8-byte Spill
Lloh16:
	adrp	x8, lCPI1_3@PAGE
Lloh17:
	ldr	q20, [x8, lCPI1_3@PAGEOFF]
	and.16b	v2, v26, v20
Lloh18:
	adrp	x8, lCPI1_4@PAGE
Lloh19:
	ldr	q23, [x8, lCPI1_4@PAGEOFF]
	and.16b	v3, v25, v23
Lloh20:
	adrp	x8, lCPI1_5@PAGE
Lloh21:
	ldr	q24, [x8, lCPI1_5@PAGEOFF]
	and.16b	v4, v21, v24
	stp	q4, q3, [sp, #224]              ; 32-byte Folded Spill
	orr.16b	v4, v4, v22
	orr.16b	v16, v3, v22
	str	q2, [sp, #256]                  ; 16-byte Spill
	orr.16b	v3, v2, v22
	umull.2d	v2, v29, v28
	str	q2, [sp, #320]                  ; 16-byte Spill
	xtn.2s	v6, v6
	xtn.2s	v7, v7
	xtn.2s	v5, v5
	stp	q4, q3, [sp, #144]              ; 32-byte Folded Spill
	mov.16b	v2, v3
	umlal.2d	v2, v5, v28
	str	q2, [sp, #368]                  ; 16-byte Spill
	str	q16, [sp, #128]                 ; 16-byte Spill
	mov.16b	v2, v16
	umlal.2d	v2, v6, v28
	str	q2, [sp, #352]                  ; 16-byte Spill
	mov.16b	v2, v4
	umlal.2d	v2, v7, v28
	str	q2, [sp, #336]                  ; 16-byte Spill
	sshll.2d	v5, v1, #0
	sshll.2d	v6, v0, #0
	add	x8, x27, x13
	stp	q18, q17, [sp, #272]            ; 32-byte Folded Spill
	stp	q17, q18, [x8]
	fmov	x8, d19
	dup.2d	v7, x23
	and.16b	v27, v26, v7
	and.16b	v22, v25, v7
	and.16b	v24, v6, v7
	and.16b	v10, v5, v7
	fmov	x7, d10
	ldp	q5, q6, [x27, #96]
	and.16b	v6, v0, v6
	and.16b	v5, v1, v5
	ldp	q7, q19, [x27, #64]
	and.16b	v19, v0, v19
	and.16b	v7, v1, v7
	ldp	q29, q28, [x27, #32]
	and.16b	v28, v0, v28
	and.16b	v8, v1, v29
	str	x8, [sp, #72]                   ; 8-byte Spill
	add	x8, x27, x8
	ldp	q29, q30, [x8]
	and.16b	v11, v0, v30
	mov	x8, x7
	and.16b	v12, v1, v29
	mov.16b	v15, v10
	mov.16b	v30, v22
	mov.16b	v31, v24
	mov.16b	v29, v27
LBB1_41:                                ; %direct.true79.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v4, v1, #0
	sshll.2d	v9, v0, #0
	add	x8, x27, x8, lsl #5
	ldp	q13, q14, [x8]
	fadd.4s	v13, v12, v13
	fadd.4s	v14, v11, v14
	ldp	q17, q3, [x8, #32]
	fadd.4s	v17, v8, v17
	fadd.4s	v3, v28, v3
	ldp	q23, q20, [x8, #64]
	fadd.4s	v23, v7, v23
	fadd.4s	v20, v19, v20
	ldp	q16, q21, [x8, #96]
	fadd.4s	v16, v5, v16
	fadd.4s	v21, v6, v21
	dup.2d	v18, x23
	and.16b	v2, v26, v18
	add.2d	v29, v29, v2
	and.16b	v2, v25, v18
	add.2d	v30, v30, v2
	and.16b	v2, v9, v18
	add.2d	v31, v31, v2
	and.16b	v2, v4, v18
	add.2d	v15, v15, v2
	bit.16b	v11, v14, v0
	bit.16b	v12, v13, v1
	bit.16b	v28, v3, v0
	bit.16b	v8, v17, v1
	bit.16b	v19, v20, v0
	bit.16b	v7, v23, v1
	bit.16b	v6, v21, v0
	bit.16b	v5, v16, v1
	fmov	x8, d15
	cmp	x8, #512
	b.lt	LBB1_41
; %bb.42:                               ; %direct.false80.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x30, #0                         ; =0x0
	ldp	q2, q3, [sp, #272]              ; 32-byte Folded Reload
	fadd.4s	v2, v2, v11
	fadd.4s	v3, v3, v12
	ldp	q30, q29, [sp, #448]            ; 32-byte Folded Reload
	zip1.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v3, v4, v3
	zip2.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v2, v4, v2
	zip2.8b	v4, v30, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	movi.2d	v16, #0000000000000000
	mov.b	v16[2], v30[1]
	mov.b	v16[4], v30[2]
	bit.16b	v2, v14, v4
	mov.b	v16[6], v30[3]
	ushll.4s	v4, v16, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v3, v13, v4
	fadd.4s	v3, v8, v3
	fadd.4s	v2, v28, v2
	fadd.4s	v2, v19, v2
	fadd.4s	v3, v7, v3
	fadd.4s	v5, v5, v3
	fadd.4s	v6, v6, v2
	ldr	q2, [sp, #304]                  ; 16-byte Reload
	ldp	q3, q7, [sp, #224]              ; 32-byte Folded Reload
	uzp1.4s	v4, v2, v7
	ldr	q2, [sp, #256]                  ; 16-byte Reload
	uzp1.4s	v7, v3, v2
	movi.4s	v3, #1
	eor.16b	v2, v4, v3
	mov.s	w17, v2[1]
	eor.16b	v20, v7, v3
	mov.s	w0, v2[2]
	mov.s	w2, v2[3]
	fmov	w8, s2
	add	x15, sp, #1240
	bfxil	x15, x8, #0, #3
	str	d30, [sp, #1240]
	ldrb	w1, [x15]
	umov.b	w15, v30[0]
	and	x8, x8, #0x7
	str	q6, [sp, #1456]
	str	q5, [sp, #1440]
	add	x12, sp, #1440
	ldr	s2, [x12, x8, lsl #2]
	ands	w8, w15, #0x1
	tst	w8, w1
	movi.2d	v23, #0000000000000000
	fcsel	s16, s2, s23, ne
	and	x3, x17, #0x7
	add	x1, sp, #1240
	bfxil	x1, x17, #0, #3
	ldrb	w17, [x1]
	umov.b	w19, v30[1]
	str	q6, [sp, #1424]
	str	q5, [sp, #1408]
	add	x12, sp, #1408
	ldr	s2, [x12, x3, lsl #2]
	and	w17, w19, w17
	tst	w17, #0x1
	fcsel	s18, s2, s23, ne
	and	x3, x0, #0x7
	add	x17, sp, #1240
	bfxil	x17, x0, #0, #3
	ldrb	w0, [x17]
	umov.b	w1, v30[2]
	and	w0, w1, w0
	str	q6, [sp, #1392]
	str	q5, [sp, #1376]
	add	x12, sp, #1376
	ldr	s2, [x12, x3, lsl #2]
	tst	w0, #0x1
	fcsel	s19, s2, s23, ne
	and	x3, x2, #0x7
	add	x0, sp, #1240
	bfxil	x0, x2, #0, #3
	ldrb	w2, [x0]
	umov.b	w0, v30[3]
	and	w2, w0, w2
	str	q6, [sp, #1360]
	str	q5, [sp, #1344]
	add	x12, sp, #1344
	ldr	s2, [x12, x3, lsl #2]
	tst	w2, #0x1
	mov.s	w2, v20[1]
	fcsel	s21, s2, s23, ne
	mov.s	w4, v20[2]
	mov.s	w5, v20[3]
	fmov	w3, s20
	and	x12, x3, #0x7
	add	x6, sp, #1240
	bfxil	x6, x3, #0, #3
	ldrb	w3, [x6]
	umov.b	w6, v30[4]
	and	w3, w6, w3
	str	q6, [sp, #1584]
	str	q5, [sp, #1568]
	add	x17, sp, #1568
	ldr	s2, [x17, x12, lsl #2]
	tst	w3, #0x1
	fcsel	s2, s2, s23, ne
	and	x12, x2, #0x7
	add	x17, sp, #1240
	bfxil	x17, x2, #0, #3
	umov.b	w3, v30[5]
	ldrb	w17, [x17]
	and	w17, w3, w17
	str	q6, [sp, #1552]
	str	q5, [sp, #1536]
	add	x2, sp, #1536
	ldr	s3, [x2, x12, lsl #2]
	tst	w17, #0x1
	fcsel	s3, s3, s23, ne
	and	x12, x4, #0x7
	add	x17, sp, #1240
	bfxil	x17, x4, #0, #3
	ldrb	w17, [x17]
	umov.b	w4, v30[6]
	str	q6, [sp, #1520]
	str	q5, [sp, #1504]
	add	x2, sp, #1504
	ldr	s17, [x2, x12, lsl #2]
	and	w12, w4, w17
	tst	w12, #0x1
	fcsel	s17, s17, s23, ne
	and	x12, x5, #0x7
	add	x17, sp, #1240
	bfxil	x17, x5, #0, #3
	ldrb	w17, [x17]
	umov.b	w5, v30[7]
	and	w17, w5, w17
	str	q6, [sp, #1488]
	str	q5, [sp, #1472]
	add	x2, sp, #1472
	ldr	s20, [x2, x12, lsl #2]
	tst	w17, #0x1
	fcsel	s20, s20, s23, ne
	mov.s	v2[1], v3[0]
	mov.s	v2[2], v17[0]
	mov.s	v2[3], v20[0]
	mov.s	v16[1], v18[0]
	mov.s	v16[2], v19[0]
	mov.s	v16[3], v21[0]
	fadd.4s	v3, v5, v16
	fadd.4s	v2, v6, v2
	movi.4s	v6, #2
	eor.16b	v5, v7, v6
	eor.16b	v4, v4, v6
	fmov	w12, s4
	add	x17, sp, #1240
	bfxil	x17, x12, #0, #3
	ldrb	w17, [x17]
	and	x12, x12, #0x7
	str	q2, [sp, #1328]
	str	q3, [sp, #1312]
	add	x2, sp, #1312
	ldr	s4, [x2, x12, lsl #2]
	tst	w8, w17
	fcsel	s4, s4, s23, ne
	fmov	w8, s5
	and	x12, x8, #0x7
	add	x17, sp, #1240
	bfxil	x17, x8, #0, #3
	ldrb	w8, [x17]
	and	w8, w6, w8
	str	q2, [sp, #1296]
	str	q3, [sp, #1280]
	add	x17, sp, #1280
	ldr	s5, [x17, x12, lsl #2]
	tst	w8, #0x1
	fcsel	s5, s5, s23, ne
	fadd.4s	v2, v2, v5
	and	w2, w15, w6
	tst	w2, #0x1
	fcsel	s2, s2, s23, ne
	ands	w8, w15, #0x1
	fadd.4s	v3, v3, v4
	fadd	s2, s3, s2
	fcsel	s3, s2, s23, ne
	tst	w2, #0x1
	str	w19, [sp, #288]                 ; 4-byte Spill
	and	w12, w19, w15
	fcsel	s4, s2, s23, ne
	str	w12, [sp, #272]                 ; 4-byte Spill
	tst	w12, #0x1
	str	w1, [sp, #304]                  ; 4-byte Spill
	and	w12, w1, w15
	fcsel	s5, s2, s23, ne
	str	w12, [sp, #256]                 ; 4-byte Spill
	tst	w12, #0x1
	and	w17, w0, w15
	fcsel	s6, s2, s23, ne
	and	w12, w0, w15
	str	w12, [sp, #240]                 ; 4-byte Spill
	tst	w17, #0x1
	fcsel	s7, s2, s23, ne
	and	w17, w3, w15
	and	w12, w3, w15
	str	w12, [sp, #224]                 ; 4-byte Spill
	tst	w17, #0x1
	fcsel	s16, s2, s23, ne
	and	w17, w4, w15
	and	w12, w4, w15
	str	w12, [sp, #220]                 ; 4-byte Spill
	tst	w17, #0x1
	fcsel	s17, s2, s23, ne
	and	w17, w5, w15
	and	w12, w5, w15
	str	w12, [sp, #204]                 ; 4-byte Spill
	tst	w17, #0x1
	fcsel	s2, s2, s23, ne
	mov.s	v3[1], v5[0]
	mov.s	v3[2], v6[0]
	mov.s	v3[3], v7[0]
	mov.s	v4[1], v16[0]
	mov.s	v4[2], v17[0]
	mov.s	v4[3], v2[0]
	ldr	w12, [sp, #208]                 ; 4-byte Reload
	rbit	w12, w12
	clz	w12, w12
	str	q4, [sp, #1264]
	str	q3, [sp, #1248]
	str	x12, [sp, #208]                 ; 8-byte Spill
	and	x12, x12, #0x7
	add	x17, sp, #1248
	ldr	s2, [x17, x12, lsl #2]
	mov.b	v30[0], wzr
	str	q30, [sp, #112]                 ; 16-byte Spill
	fadd	s2, s2, s23
	mov	w12, #2048                      ; =0x800
	movk	w12, #17792, lsl #16
	fmov	s3, w12
	fdiv	s2, s2, s3
	dup.4s	v4, v2[0]
	mov	w12, #1                         ; =0x1
	dup.2d	v2, x12
	ushll2.2d	v3, v0, #0
	and.16b	v18, v3, v2
	ushll2.2d	v3, v1, #0
	and.16b	v19, v3, v2
	ushll.2d	v3, v0, #0
	and.16b	v20, v3, v2
	ushll.2d	v3, v1, #0
	and.16b	v21, v3, v2
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
LBB1_43:                                ; %direct.true114.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x12, x30, #5
	add	x17, x27, x12
	ldp	q3, q2, [x17]
	fsub.4s	v3, v3, v4
	fsub.4s	v2, v2, v4
	add	x12, x11, x12
	ldp	q17, q23, [x12]
	bif.16b	v2, v23, v0
	bif.16b	v3, v17, v1
	stp	q3, q2, [x12]
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v16, v16, v18
	add.2d	v5, v5, v21
	fmov	x30, d5
	cmp	x30, #512
	b.lt	LBB1_43
; %bb.44:                               ; %direct.true151.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x27, x13
	ldp	q3, q2, [x12]
	fsub.4s	v5, v3, v4
	fsub.4s	v6, v2, v4
	add	x12, x11, x13
	ldp	q2, q3, [x12]
	zip2.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	stp	q6, q5, [sp, #80]               ; 32-byte Folded Spill
	bit.16b	v3, v6, v4
	zip1.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v2, v5, v4
	stp	q2, q3, [x12]
	ldr	q2, [x27, #16528]
	ldr	q3, [x27, #16512]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v11, v0, v2
	and.16b	v13, v1, v3
	ldr	q2, [x27, #16496]
	ldr	q3, [x27, #16480]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v8, v0, v2
	and.16b	v15, v1, v3
	ldr	q2, [x27, #16464]
	ldr	q3, [x27, #16448]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v16, v0, v2
	and.16b	v5, v1, v3
	ldr	x12, [sp, #72]                  ; 8-byte Reload
	add	x12, x11, x12
	ldp	q3, q2, [x12]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v7, v0, v2
	and.16b	v6, v1, v3
LBB1_45:                                ; %direct.true151.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v1, #0
	sshll.2d	v3, v0, #0
	add	x12, x11, x7, lsl #5
	ldp	q17, q4, [x12]
	and.16b	v17, v1, v17
	and.16b	v4, v0, v4
	fmul.4s	v23, v4, v4
	fmul.4s	v4, v17, v17
	fadd.4s	v4, v6, v4
	fadd.4s	v23, v7, v23
	ldp	q29, q17, [x12, #32]
	and.16b	v29, v1, v29
	and.16b	v17, v0, v17
	fmul.4s	v17, v17, v17
	fmul.4s	v29, v29, v29
	fadd.4s	v29, v5, v29
	fadd.4s	v17, v16, v17
	ldp	q31, q30, [x12, #64]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	fmul.4s	v30, v30, v30
	fmul.4s	v31, v31, v31
	fadd.4s	v31, v15, v31
	fadd.4s	v30, v8, v30
	ldp	q12, q9, [x12, #96]
	and.16b	v12, v1, v12
	and.16b	v9, v0, v9
	fmul.4s	v9, v9, v9
	fmul.4s	v12, v12, v12
	fadd.4s	v12, v13, v12
	fadd.4s	v9, v11, v9
	dup.2d	v14, x23
	and.16b	v28, v26, v14
	add.2d	v27, v27, v28
	and.16b	v28, v25, v14
	add.2d	v22, v22, v28
	and.16b	v3, v3, v14
	add.2d	v24, v24, v3
	and.16b	v2, v2, v14
	add.2d	v10, v10, v2
	bit.16b	v7, v23, v0
	bit.16b	v6, v4, v1
	bit.16b	v16, v17, v0
	bit.16b	v5, v29, v1
	bit.16b	v8, v30, v0
	bit.16b	v15, v31, v1
	bit.16b	v11, v9, v0
	bit.16b	v13, v12, v1
	fmov	x7, d10
	cmp	x7, #512
	b.lt	LBB1_45
; %bb.46:                               ; %direct.true188.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x7, #0                          ; =0x0
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	ldr	q28, [sp, #416]                 ; 16-byte Reload
	ldr	x30, [sp, #408]                 ; 8-byte Reload
	b	LBB1_48
LBB1_47:                                ; %else126
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x10, x7
	stp	q31, q10, [x12]
	add.2d	v26, v26, v19
	add.2d	v29, v29, v20
	add.2d	v30, v30, v18
	add.2d	v25, v25, v21
	fmov	x7, d25
	cmp	x7, #512
	b.ge	LBB1_64
LBB1_48:                                ; %direct.true188.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w27, s28
	lsl	x7, x7, #5
	add	x19, x16, x7
	add	x12, x10, x7
	ldp	q31, q10, [x12]
	tbnz	w27, #0, LBB1_56
; %bb.49:                               ; %else105
                                        ;   in Loop: Header=BB1_48 Depth=2
	and	w27, w27, #0xff
	tbnz	w27, #1, LBB1_57
LBB1_50:                                ; %else108
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w27, #2, LBB1_58
LBB1_51:                                ; %else111
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w27, #3, LBB1_59
LBB1_52:                                ; %else114
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w27, #4, LBB1_60
LBB1_53:                                ; %else117
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w27, #5, LBB1_61
LBB1_54:                                ; %else120
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbnz	w27, #6, LBB1_62
LBB1_55:                                ; %else123
                                        ;   in Loop: Header=BB1_48 Depth=2
	tbz	w27, #7, LBB1_47
	b	LBB1_63
LBB1_56:                                ; %cond.load104
                                        ;   in Loop: Header=BB1_48 Depth=2
	ld1.s	{ v31 }[0], [x19]
	and	w27, w27, #0xff
	tbz	w27, #1, LBB1_50
LBB1_57:                                ; %cond.load107
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x19, #4
	ld1.s	{ v31 }[1], [x12]
	tbz	w27, #2, LBB1_51
LBB1_58:                                ; %cond.load110
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x19, #8
	ld1.s	{ v31 }[2], [x12]
	tbz	w27, #3, LBB1_52
LBB1_59:                                ; %cond.load113
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x19, #12
	ld1.s	{ v31 }[3], [x12]
	tbz	w27, #4, LBB1_53
LBB1_60:                                ; %cond.load116
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x19, #16
	ld1.s	{ v10 }[0], [x12]
	tbz	w27, #5, LBB1_54
LBB1_61:                                ; %cond.load119
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x19, #20
	ld1.s	{ v10 }[1], [x12]
	tbz	w27, #6, LBB1_55
LBB1_62:                                ; %cond.load122
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x19, #24
	ld1.s	{ v10 }[2], [x12]
	tbz	w27, #7, LBB1_47
LBB1_63:                                ; %cond.load125
                                        ;   in Loop: Header=BB1_48 Depth=2
	add	x12, x19, #28
	ld1.s	{ v10 }[3], [x12]
	b	LBB1_47
LBB1_64:                                ; %direct.false189.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q31, [sp, #464]                 ; 16-byte Reload
	mov	b2, v31[0]
	mov.b	v2[4], v31[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	ldr	q3, [sp, #176]                  ; 16-byte Reload
	and.16b	v2, v2, v3
	mov	b3, v31[2]
	mov.b	v3[4], v31[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldp	q17, q24, [sp, #128]            ; 32-byte Folded Reload
	and.16b	v3, v3, v17
	mov	b17, v31[4]
	mov.b	v17[4], v31[5]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	mov	b22, v31[6]
	mov.b	v22[4], v31[7]
	and.16b	v17, v17, v24
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	ldr	q24, [sp, #160]                 ; 16-byte Reload
	and.16b	v24, v22, v24
Lloh22:
	adrp	x12, lCPI1_11@PAGE
Lloh23:
	ldr	d22, [x12, lCPI1_11@PAGEOFF]
	shl.8b	v25, v31, #7
	cmlt.8b	v25, v25, #0
	and.8b	v22, v25, v22
	addv.8b	b22, v22
	fmov	w7, s22
	str	q24, [sp, #1216]
	str	q17, [sp, #1200]
	str	q3, [sp, #1184]
	str	q2, [sp, #1168]
	and	x12, x30, #0x7
	add	x17, sp, #1168
	ldr	x12, [x17, x12, lsl #3]
	sub	x12, x12, x30
	lsl	x27, x12, #2
	add	x16, x16, x27
	add	x12, x10, x13
	ldp	q24, q25, [x12]
	tbnz	w7, #0, LBB1_134
; %bb.65:                               ; %else130
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w7, #1, LBB1_135
LBB1_66:                                ; %else133
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w7, #2, LBB1_136
LBB1_67:                                ; %else136
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w7, #3, LBB1_137
LBB1_68:                                ; %else139
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w7, #4, LBB1_138
LBB1_69:                                ; %else142
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w7, #5, LBB1_139
LBB1_70:                                ; %else145
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w7, #6, LBB1_140
LBB1_71:                                ; %else148
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w7, #7, LBB1_73
LBB1_72:                                ; %cond.load150
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x16, #28
	ld1.s	{ v25 }[3], [x12]
LBB1_73:                                ; %else151
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x16, #0                         ; =0x0
	add	x12, x10, x13
	stp	q24, q25, [x12]
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	b	LBB1_75
LBB1_74:                                ; %else176
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x12, x9, x16
	stp	q29, q30, [x12]
	add.2d	v25, v25, v19
	add.2d	v26, v26, v20
	add.2d	v27, v27, v18
	add.2d	v24, v24, v21
	fmov	x16, d24
	cmp	x16, #512
	b.ge	LBB1_91
LBB1_75:                                ; %direct.true214.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w19, s28
	lsl	x16, x16, #5
	add	x7, x14, x16
	add	x12, x9, x16
	ldp	q29, q30, [x12]
	tbnz	w19, #0, LBB1_83
; %bb.76:                               ; %else155
                                        ;   in Loop: Header=BB1_75 Depth=2
	and	w19, w19, #0xff
	tbnz	w19, #1, LBB1_84
LBB1_77:                                ; %else158
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbnz	w19, #2, LBB1_85
LBB1_78:                                ; %else161
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbnz	w19, #3, LBB1_86
LBB1_79:                                ; %else164
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbnz	w19, #4, LBB1_87
LBB1_80:                                ; %else167
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbnz	w19, #5, LBB1_88
LBB1_81:                                ; %else170
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbnz	w19, #6, LBB1_89
LBB1_82:                                ; %else173
                                        ;   in Loop: Header=BB1_75 Depth=2
	tbz	w19, #7, LBB1_74
	b	LBB1_90
LBB1_83:                                ; %cond.load154
                                        ;   in Loop: Header=BB1_75 Depth=2
	ld1.s	{ v29 }[0], [x7]
	and	w19, w19, #0xff
	tbz	w19, #1, LBB1_77
LBB1_84:                                ; %cond.load157
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x12, x7, #4
	ld1.s	{ v29 }[1], [x12]
	tbz	w19, #2, LBB1_78
LBB1_85:                                ; %cond.load160
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x12, x7, #8
	ld1.s	{ v29 }[2], [x12]
	tbz	w19, #3, LBB1_79
LBB1_86:                                ; %cond.load163
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x12, x7, #12
	ld1.s	{ v29 }[3], [x12]
	tbz	w19, #4, LBB1_80
LBB1_87:                                ; %cond.load166
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x12, x7, #16
	ld1.s	{ v30 }[0], [x12]
	tbz	w19, #5, LBB1_81
LBB1_88:                                ; %cond.load169
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x12, x7, #20
	ld1.s	{ v30 }[1], [x12]
	tbz	w19, #6, LBB1_82
LBB1_89:                                ; %cond.load172
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x12, x7, #24
	ld1.s	{ v30 }[2], [x12]
	tbz	w19, #7, LBB1_74
LBB1_90:                                ; %cond.load175
                                        ;   in Loop: Header=BB1_75 Depth=2
	add	x12, x7, #28
	ld1.s	{ v30 }[3], [x12]
	b	LBB1_74
LBB1_91:                                ; %direct.false215.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
Lloh24:
	adrp	x12, lCPI1_12@PAGE
Lloh25:
	ldr	q2, [x12, lCPI1_12@PAGEOFF]
	and.16b	v25, v0, v2
Lloh26:
	adrp	x12, lCPI1_13@PAGE
Lloh27:
	ldr	q2, [x12, lCPI1_13@PAGEOFF]
	and.16b	v26, v1, v2
Lloh28:
	adrp	x12, lCPI1_15@PAGE
Lloh29:
	ldr	q2, [x12, lCPI1_15@PAGEOFF]
	and.16b	v24, v1, v2
	zip2.8b	v2, v31, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldp	q3, q27, [sp, #80]              ; 32-byte Folded Reload
	and.16b	v3, v2, v3
	zip1.8b	v17, v31, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v27, v17, v27
	fmul.4s	v27, v27, v27
	fmul.4s	v3, v3, v3
	fadd.4s	v3, v3, v7
	fadd.4s	v6, v27, v6
	and.16b	v6, v17, v6
	and.16b	v2, v2, v3
	ldr	q7, [sp, #112]                  ; 16-byte Reload
	zip2.8b	v3, v7, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v2, v23, v3
	zip1.8b	v3, v7, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v4, v6
	fadd.4s	v3, v5, v3
	fadd.4s	v2, v16, v2
	fadd.4s	v2, v8, v2
	fadd.4s	v3, v15, v3
	fadd.4s	v4, v13, v3
	fadd.4s	v5, v11, v2
	fmov	w12, s26
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldr	q2, [sp, #448]                  ; 16-byte Reload
	str	d2, [sp, #568]
	ldrb	w16, [x16]
	add	x17, sp, #1120
	orr	x12, x17, x12, lsl #2
	str	q5, [sp, #1136]
	str	q4, [sp, #1120]
	ldr	s2, [x12]
	tst	w8, w16
	mov.s	w12, v26[1]
	movi.2d	v27, #0000000000000000
	fcsel	s6, s2, s27, ne
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w12, [x16]
	ldr	w7, [sp, #288]                  ; 4-byte Reload
	and	w12, w7, w12
	str	q4, [sp, #1088]
	ldr	s2, [sp, #1088]
	tst	w12, #0x1
	fcsel	s7, s2, s27, ne
	mov.s	w12, v26[2]
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	add	x17, sp, #1056
	orr	x12, x17, x12, lsl #2
	ldrb	w16, [x16]
	ldr	w1, [sp, #304]                  ; 4-byte Reload
	and	w16, w1, w16
	str	q5, [sp, #1072]
	str	q4, [sp, #1056]
	ldr	s2, [x12]
	tst	w16, #0x1
	fcsel	s16, s2, s27, ne
	mov.s	w12, v26[3]
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	add	x17, sp, #1024
	orr	x12, x17, x12, lsl #2
	ldrb	w16, [x16]
	and	w16, w0, w16
	str	q5, [sp, #1040]
	str	q4, [sp, #1024]
	ldr	s2, [x12]
	tst	w16, #0x1
	fcsel	s17, s2, s27, ne
	fmov	w12, s25
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w16, [x16]
	and	w16, w6, w16
	stp	q4, q5, [sp, #992]
	add	x17, sp, #992
	ldr	s2, [x17, w12, uxtw #2]
	tst	w16, #0x1
	fcsel	s2, s2, s27, ne
	mov.s	w12, v25[1]
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w16, [x16]
	and	w16, w3, w16
	stp	q4, q5, [sp, #960]
	add	x17, sp, #960
	ldr	s3, [x17, w12, uxtw #2]
	tst	w16, #0x1
	fcsel	s3, s3, s27, ne
	mov.s	w12, v25[2]
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w16, [x16]
	and	w16, w4, w16
	stp	q4, q5, [sp, #928]
	add	x17, sp, #928
	ldr	s23, [x17, w12, uxtw #2]
	tst	w16, #0x1
	fcsel	s23, s23, s27, ne
	mov.s	w12, v25[3]
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w16, [x16]
	and	w16, w5, w16
	stp	q4, q5, [sp, #896]
	add	x17, sp, #896
	ldr	s25, [x17, w12, uxtw #2]
	tst	w16, #0x1
	fcsel	s25, s25, s27, ne
	mov.s	v2[1], v3[0]
	mov.s	v2[2], v23[0]
	mov.s	v2[3], v25[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v17[0]
	fadd.4s	v4, v4, v6
	fadd.4s	v5, v5, v2
	fmov	w12, s24
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w16, [x16]
	add	x17, sp, #864
	orr	x12, x17, x12, lsl #2
	stp	q4, q5, [sp, #864]
	ldr	s2, [x12]
	tst	w8, w16
	mov.s	w12, v24[1]
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w16, [x16]
	and	w16, w7, w16
	fcsel	s6, s2, s27, ne
	add	x17, sp, #832
	orr	x12, x17, x12, lsl #2
	stp	q4, q5, [sp, #832]
	ldr	s2, [x12]
	tst	w16, #0x1
	mov.s	w12, v24[2]
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	fcsel	s7, s2, s27, ne
	ldrb	w12, [x16]
	and	w12, w1, w12
	str	q4, [sp, #800]
	tst	w12, #0x1
	mov.s	w12, v24[3]
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w16, [x16]
	and	w16, w0, w16
Lloh30:
	adrp	x17, lCPI1_14@PAGE
Lloh31:
	ldr	q2, [x17, lCPI1_14@PAGEOFF]
	and.16b	v2, v0, v2
	ldr	s3, [sp, #800]
	fcsel	s16, s3, s27, ne
	add	x17, sp, #768
	orr	x12, x17, x12, lsl #2
	stp	q4, q5, [sp, #768]
	ldr	s3, [x12]
	tst	w16, #0x1
	fmov	w12, s2
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w16, [x16]
	and	w16, w6, w16
	fcsel	s17, s3, s27, ne
	stp	q4, q5, [sp, #736]
	add	x17, sp, #736
	ldr	s3, [x17, w12, uxtw #2]
	tst	w16, #0x1
	mov.s	w12, v2[1]
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w16, [x16]
	and	w16, w3, w16
	fcsel	s23, s3, s27, ne
	stp	q4, q5, [sp, #704]
	add	x17, sp, #704
	ldr	s3, [x17, w12, uxtw #2]
	tst	w16, #0x1
	mov.s	w12, v2[2]
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w16, [x16]
	and	w16, w4, w16
	fcsel	s3, s3, s27, ne
	stp	q4, q5, [sp, #672]
	add	x17, sp, #672
	ldr	s24, [x17, w12, uxtw #2]
	tst	w16, #0x1
	mov.s	w12, v2[3]
	add	x16, sp, #568
	bfxil	x16, x12, #0, #3
	ldrb	w16, [x16]
	and	w16, w5, w16
	movi.4s	v2, #4
	and.16b	v2, v1, v2
	fcsel	s24, s24, s27, ne
	stp	q4, q5, [sp, #640]
	add	x17, sp, #640
	ldr	s25, [x17, w12, uxtw #2]
	tst	w16, #0x1
	fcsel	s25, s25, s27, ne
	fmov	w12, s2
	add	x16, sp, #568
	orr	x16, x16, x12
	ldrb	w16, [x16]
	tst	w8, w16
	mov.s	v23[1], v3[0]
	mov.s	v23[2], v24[0]
	mov.s	v23[3], v25[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v17[0]
	fadd.4s	v2, v4, v6
	fadd.4s	v3, v5, v23
	stp	q2, q3, [sp, #608]
	add	x8, sp, #608
	ldr	s3, [x8, w12, uxtw #2]
	fcsel	s3, s3, s27, ne
	tst	w15, #0x1
	fadd	s2, s2, s3
	fcsel	s3, s2, s27, ne
	ldr	w8, [sp, #272]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s4, s2, s27, ne
	ldr	w8, [sp, #256]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s5, s2, s27, ne
	ldr	w8, [sp, #240]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s6, s2, s27, ne
	tst	w2, #0x1
	fcsel	s7, s2, s27, ne
	ldr	w8, [sp, #224]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s16, s2, s27, ne
	ldr	w8, [sp, #220]                  ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s17, s2, s27, ne
	ldr	w8, [sp, #204]                  ; 4-byte Reload
	tst	w8, #0x1
	movi.2d	v23, #0000000000000000
	fcsel	s2, s2, s27, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v5[0]
	mov.s	v3[3], v6[0]
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v2[0]
	stp	q3, q7, [sp, #576]
	ldr	x8, [sp, #208]                  ; 8-byte Reload
	and	x8, x8, #0x7
	add	x12, sp, #576
	ldr	s6, [x12, x8, lsl #2]
	add	x8, x14, x27
	add	x12, x9, x13
	ldp	q4, q5, [x12]
	fmov	w14, s22
	tbnz	w14, #0, LBB1_141
; %bb.92:                               ; %else180
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x16, [sp, #432]                 ; 8-byte Reload
	tbnz	w14, #1, LBB1_142
LBB1_93:                                ; %else183
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w14, #2, LBB1_143
LBB1_94:                                ; %else186
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w14, #3, LBB1_144
LBB1_95:                                ; %else189
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w14, #4, LBB1_145
LBB1_96:                                ; %else192
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w14, #5, LBB1_146
LBB1_97:                                ; %else195
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w14, #6, LBB1_147
LBB1_98:                                ; %else198
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #7, LBB1_100
LBB1_99:                                ; %cond.load200
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x8, #28
	ld1.s	{ v5 }[3], [x8]
LBB1_100:                               ; %else201
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x14, #0                         ; =0x0
	fadd	s2, s6, s23
	mov	w8, #2048                       ; =0x800
	movk	w8, #17792, lsl #16
	fmov	s3, w8
	fdiv	s2, s2, s3
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	fmov	s3, w8
	fadd	s2, s2, s3
	fsqrt	s2, s2
	add	x8, x9, x13
	stp	q4, q5, [x8]
	dup.4s	v4, v2[0]
	ldr	q2, [sp, #320]                  ; 16-byte Reload
	fmov	x8, d2
	add	x8, x16, x8, lsl #2
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	b	LBB1_102
LBB1_101:                               ; %else218
                                        ;   in Loop: Header=BB1_102 Depth=2
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v16, v16, v18
	add.2d	v5, v5, v21
	fmov	x14, d5
	cmp	x14, #512
	b.ge	LBB1_118
LBB1_102:                               ; %direct.true239.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w15, s28
	lsl	x12, x14, #5
	add	x14, x11, x12
	ldp	q2, q17, [x14]
	and.16b	v2, v1, v2
	fdiv.4s	v2, v2, v4
	add	x14, x10, x12
	ldp	q3, q23, [x14]
	and.16b	v3, v1, v3
	fmul.4s	v2, v2, v3
	add	x14, x9, x12
	ldp	q3, q24, [x14]
	and.16b	v3, v1, v3
	fadd.4s	v25, v2, v3
	add	x14, x8, x12
	tbnz	w15, #0, LBB1_111
; %bb.103:                              ; %else204
                                        ;   in Loop: Header=BB1_102 Depth=2
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_112
LBB1_104:                               ; %else206
                                        ;   in Loop: Header=BB1_102 Depth=2
	tbnz	w15, #2, LBB1_113
LBB1_105:                               ; %else208
                                        ;   in Loop: Header=BB1_102 Depth=2
	tbz	w15, #3, LBB1_107
LBB1_106:                               ; %cond.store209
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x12, x14, #12
	st1.s	{ v25 }[3], [x12]
LBB1_107:                               ; %else210
                                        ;   in Loop: Header=BB1_102 Depth=2
	and.16b	v2, v0, v17
	fdiv.4s	v2, v2, v4
	and.16b	v3, v0, v23
	fmul.4s	v2, v2, v3
	and.16b	v3, v0, v24
	fadd.4s	v17, v2, v3
	tbnz	w15, #4, LBB1_114
; %bb.108:                              ; %else212
                                        ;   in Loop: Header=BB1_102 Depth=2
	tbnz	w15, #5, LBB1_115
LBB1_109:                               ; %else214
                                        ;   in Loop: Header=BB1_102 Depth=2
	tbnz	w15, #6, LBB1_116
LBB1_110:                               ; %else216
                                        ;   in Loop: Header=BB1_102 Depth=2
	tbz	w15, #7, LBB1_101
	b	LBB1_117
LBB1_111:                               ; %cond.store
                                        ;   in Loop: Header=BB1_102 Depth=2
	str	s25, [x14]
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_104
LBB1_112:                               ; %cond.store205
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x12, x14, #4
	st1.s	{ v25 }[1], [x12]
	tbz	w15, #2, LBB1_105
LBB1_113:                               ; %cond.store207
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x12, x14, #8
	st1.s	{ v25 }[2], [x12]
	tbnz	w15, #3, LBB1_106
	b	LBB1_107
LBB1_114:                               ; %cond.store211
                                        ;   in Loop: Header=BB1_102 Depth=2
	str	s17, [x14, #16]
	tbz	w15, #5, LBB1_109
LBB1_115:                               ; %cond.store213
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x12, x14, #20
	st1.s	{ v17 }[1], [x12]
	tbz	w15, #6, LBB1_110
LBB1_116:                               ; %cond.store215
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x12, x14, #24
	st1.s	{ v17 }[2], [x12]
	tbz	w15, #7, LBB1_101
LBB1_117:                               ; %cond.store217
                                        ;   in Loop: Header=BB1_102 Depth=2
	add	x12, x14, #28
	st1.s	{ v17 }[3], [x12]
	b	LBB1_101
LBB1_118:                               ; %direct.false240.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x11, x13
	ldp	q1, q0, [x8]
	zip1.8b	v2, v31, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v3, v2, #0
	and.16b	v1, v3, v1
	fmov	w8, s22
	fdiv.4s	v2, v1, v4
	add	x10, x10, x13
	ldp	q5, q1, [x10]
	and.16b	v5, v3, v5
	fmul.4s	v5, v2, v5
	add	x9, x9, x13
	ldp	q6, q2, [x9]
	and.16b	v3, v3, v6
	fadd.4s	v5, v5, v3
	ldr	q6, [sp, #384]                  ; 16-byte Reload
	ldp	q3, q7, [sp, #336]              ; 32-byte Folded Reload
	stp	q6, q7, [sp, #496]
	str	q3, [sp, #528]
	ldr	q3, [sp, #368]                  ; 16-byte Reload
	str	q3, [sp, #544]
	and	x9, x30, #0x7
	add	x10, sp, #496
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x30
	add	x9, x16, x9, lsl #2
	tbnz	w8, #0, LBB1_148
; %bb.119:                              ; %else221
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #1, LBB1_149
LBB1_120:                               ; %else223
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #2, LBB1_150
LBB1_121:                               ; %else225
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #3, LBB1_123
LBB1_122:                               ; %cond.store226
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #12
	st1.s	{ v5 }[3], [x10]
LBB1_123:                               ; %else227
                                        ;   in Loop: Header=BB1_4 Depth=1
	zip2.8b	v3, v31, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v0, v3, v0
	fdiv.4s	v0, v0, v4
	and.16b	v1, v3, v1
	fmul.4s	v0, v0, v1
	and.16b	v1, v3, v2
	fadd.4s	v0, v0, v1
	tbnz	w8, #4, LBB1_151
; %bb.124:                              ; %else229
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #5, LBB1_152
LBB1_125:                               ; %else231
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbnz	w8, #6, LBB1_153
LBB1_126:                               ; %else233
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w8, #7, LBB1_2
	b	LBB1_154
LBB1_127:                               ; %cond.load79
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v17 }[0], [x8]
	tbz	w15, #1, LBB1_33
LBB1_128:                               ; %cond.load82
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x8, #4
	ld1.s	{ v17 }[1], [x17]
	tbz	w15, #2, LBB1_34
LBB1_129:                               ; %cond.load85
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x8, #8
	ld1.s	{ v17 }[2], [x17]
	tbz	w15, #3, LBB1_35
LBB1_130:                               ; %cond.load88
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x8, #12
	ld1.s	{ v17 }[3], [x17]
	tbz	w15, #4, LBB1_36
LBB1_131:                               ; %cond.load91
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x8, #16
	ld1.s	{ v18 }[0], [x17]
	tbz	w15, #5, LBB1_37
LBB1_132:                               ; %cond.load94
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x8, #20
	ld1.s	{ v18 }[1], [x17]
	tbz	w15, #6, LBB1_38
LBB1_133:                               ; %cond.load97
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x8, #24
	ld1.s	{ v18 }[2], [x17]
	str	q3, [sp, #464]                  ; 16-byte Spill
	tbnz	w15, #7, LBB1_39
	b	LBB1_40
LBB1_134:                               ; %cond.load129
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v24 }[0], [x16]
	tbz	w7, #1, LBB1_66
LBB1_135:                               ; %cond.load132
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x16, #4
	ld1.s	{ v24 }[1], [x12]
	tbz	w7, #2, LBB1_67
LBB1_136:                               ; %cond.load135
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x16, #8
	ld1.s	{ v24 }[2], [x12]
	tbz	w7, #3, LBB1_68
LBB1_137:                               ; %cond.load138
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x16, #12
	ld1.s	{ v24 }[3], [x12]
	tbz	w7, #4, LBB1_69
LBB1_138:                               ; %cond.load141
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x16, #16
	ld1.s	{ v25 }[0], [x12]
	tbz	w7, #5, LBB1_70
LBB1_139:                               ; %cond.load144
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x16, #20
	ld1.s	{ v25 }[1], [x12]
	tbz	w7, #6, LBB1_71
LBB1_140:                               ; %cond.load147
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x16, #24
	ld1.s	{ v25 }[2], [x12]
	tbnz	w7, #7, LBB1_72
	b	LBB1_73
LBB1_141:                               ; %cond.load179
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v4 }[0], [x8]
	ldr	x16, [sp, #432]                 ; 8-byte Reload
	tbz	w14, #1, LBB1_93
LBB1_142:                               ; %cond.load182
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #4
	ld1.s	{ v4 }[1], [x12]
	tbz	w14, #2, LBB1_94
LBB1_143:                               ; %cond.load185
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #8
	ld1.s	{ v4 }[2], [x12]
	tbz	w14, #3, LBB1_95
LBB1_144:                               ; %cond.load188
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #12
	ld1.s	{ v4 }[3], [x12]
	tbz	w14, #4, LBB1_96
LBB1_145:                               ; %cond.load191
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #16
	ld1.s	{ v5 }[0], [x12]
	tbz	w14, #5, LBB1_97
LBB1_146:                               ; %cond.load194
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #20
	ld1.s	{ v5 }[1], [x12]
	tbz	w14, #6, LBB1_98
LBB1_147:                               ; %cond.load197
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x8, #24
	ld1.s	{ v5 }[2], [x12]
	tbnz	w14, #7, LBB1_99
	b	LBB1_100
LBB1_148:                               ; %cond.store220
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s5, [x9]
	tbz	w8, #1, LBB1_120
LBB1_149:                               ; %cond.store222
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #4
	st1.s	{ v5 }[1], [x10]
	tbz	w8, #2, LBB1_121
LBB1_150:                               ; %cond.store224
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #8
	st1.s	{ v5 }[2], [x10]
	tbnz	w8, #3, LBB1_122
	b	LBB1_123
LBB1_151:                               ; %cond.store228
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9, #16]
	tbz	w8, #5, LBB1_125
LBB1_152:                               ; %cond.store230
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #6, LBB1_126
LBB1_153:                               ; %cond.store232
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x9, #24
	st1.s	{ v0 }[2], [x10]
	tbz	w8, #7, LBB1_2
LBB1_154:                               ; %cond.store234
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x9, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB1_2
LBB1_155:
	add	sp, sp, #1744
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB1_156:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
                                        ; -- End function
.subsections_via_symbols

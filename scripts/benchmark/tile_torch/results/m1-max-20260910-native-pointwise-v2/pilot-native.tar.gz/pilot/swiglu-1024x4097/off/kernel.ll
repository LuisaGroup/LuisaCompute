; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [16416 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16416 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot7, align 64
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat12, %41
  %44 = mul i32 %32, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat14, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat16, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 512
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state19 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state19, 8
  %.splatinsert20 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat21 = shufflevector <8 x i64> %.splatinsert20, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat21, %.spill.load
  %.spill.load22 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load22, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 4097)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state23 = load i64, ptr %.slot, align 4
  %.splatinsert24 = insertelement <8 x i64> poison, i64 %.state23, i64 0
  %.splat25 = shufflevector <8 x i64> %.splatinsert24, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat25, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state26 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state26, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load27 = load <8 x i64>, ptr %.spill, align 64
  %102 = icmp slt <8 x i64> %.spill.load27, splat (i64 1)
  %103 = load <8 x i1>, ptr %.spill5, align 1
  %104 = select <8 x i1> %51, <8 x i1> %102, <8 x i1> %103
  store <8 x i1> %104, ptr %.spill5, align 1
  %105 = and <8 x i1> %51, %102
  %106 = xor <8 x i1> %102, splat (i1 true)
  %107 = and <8 x i1> %51, %106
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %109 = bitcast <8 x i1> %105 to i8
  %110 = call i8 @llvm.cttz.i8(i8 %109, i1 false)
  %111 = zext i8 %110 to i32
  %112 = select i1 %108, i32 %111, i32 0
  %.spill.load28 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> splat (i64 4096), %.spill.load28
  %.spill.load29 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load29, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 4097)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = select <8 x i1> %105, <8 x i64> %118, <8 x i64> zeroinitializer
  %121 = extractelement <8 x i64> %120, i32 %112
  %122 = zext i32 %112 to i64
  %123 = sub i64 %121, %122
  %124 = mul i64 %123, 4
  %buffer.contiguous.address30 = getelementptr i8, ptr %119, i64 %124
  %buffer.contiguous.load31 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address30, <8 x i1> %105, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load32 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load32, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load32, 1
  %127 = add <8 x i64> %126, splat (i64 16384)
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %132 = extractelement <8 x ptr> %130, i32 0
  %133 = extractelement <8 x i64> %131, i32 %112
  %134 = zext i32 %112 to i64
  %135 = mul i64 %134, 4
  %136 = sub i64 %133, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %138 = select i1 %137, i64 %136, i64 0
  %private.contiguous.address33 = getelementptr i8, ptr %132, i64 %138
  %private.contiguous.preserve34 = load <8 x float>, ptr %private.contiguous.address33, align 4
  %139 = select <8 x i1> %105, <8 x float> %buffer.contiguous.load31, <8 x float> %private.contiguous.preserve34
  store <8 x float> %139, ptr %private.contiguous.address33, align 4
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %107)
  %141 = bitcast <8 x i1> %107 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  %145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 0
  %148 = select <8 x i1> %51, <8 x ptr> %146, <8 x ptr> %147
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %151 = select <8 x i1> %51, <8 x i64> %149, <8 x i64> %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  store { <8 x ptr>, <8 x i64> } %153, ptr %tile_snapshot.spill6, align 64
  %154 = load <8 x i64>, ptr %.slot7, align 64
  %155 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %154
  store <8 x i64> %155, ptr %.slot7, align 64
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state35 = load <8 x i64>, ptr %.slot7, align 64
  %156 = icmp slt <8 x i64> %.state35, splat (i64 512)
  %157 = extractelement <8 x i1> %156, i32 0
  br i1 %157, label %direct.true36, label %direct.false37

direct.schedule.7:                                ; preds = %direct.true36
  %.state38 = load <8 x i64>, ptr %.slot7, align 64
  %158 = mul <8 x i64> %.state38, splat (i64 8)
  %.spill.load39 = load <8 x i64>, ptr %.spill, align 64
  %159 = add <8 x i64> %158, %.spill.load39
  %.spill.load40 = load <8 x i64>, ptr %.spill4, align 64
  %160 = add <8 x i64> %.spill.load40, zeroinitializer
  %161 = add <8 x i64> zeroinitializer, %160
  %162 = add <8 x i64> zeroinitializer, %159
  %163 = mul <8 x i64> %161, splat (i64 4097)
  %164 = add <8 x i64> %163, %162
  %165 = extractvalue { ptr, i64 } %15, 0
  %166 = extractelement <8 x i64> %164, i32 0
  %167 = sub i64 %166, 0
  %168 = mul i64 %167, 4
  %buffer.contiguous.address41 = getelementptr i8, ptr %165, i64 %168
  %buffer.contiguous.load42 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address41, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load43 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 0
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 1
  %.state44 = load <8 x i64>, ptr %.slot7, align 64
  %171 = mul <8 x i64> %.state44, splat (i64 32)
  %172 = add <8 x i64> %170, %171
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %169, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %177 = extractelement <8 x ptr> %175, i32 0
  %178 = extractelement <8 x i64> %176, i32 0
  %179 = sub i64 %178, 0
  %180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %181 = select i1 %180, i64 %179, i64 0
  %private.contiguous.address45 = getelementptr i8, ptr %177, i64 %181
  %private.contiguous.preserve46 = load <8 x float>, ptr %private.contiguous.address45, align 4
  %182 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load42, <8 x float> %private.contiguous.preserve46
  store <8 x float> %182, ptr %private.contiguous.address45, align 4
  %.state47 = load <8 x i64>, ptr %.slot7, align 64
  %183 = add <8 x i64> %.state47, splat (i64 1)
  %184 = load <8 x i64>, ptr %.slot7, align 64
  %185 = select <8 x i1> %51, <8 x i64> %183, <8 x i64> %184
  store <8 x i64> %185, ptr %.slot7, align 64
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false37
  %.spill.load48 = load <8 x i1>, ptr %.spill5, align 1
  %186 = and <8 x i1> %51, %.spill.load48
  %187 = xor <8 x i1> %.spill.load48, splat (i1 true)
  %188 = and <8 x i1> %51, %187
  %189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %186)
  %190 = bitcast <8 x i1> %186 to i8
  %191 = call i8 @llvm.cttz.i8(i8 %190, i1 false)
  %192 = zext i8 %191 to i32
  %193 = select i1 %189, i32 %192, i32 0
  %.spill.load49 = load <8 x i64>, ptr %.spill, align 64
  %194 = add <8 x i64> splat (i64 4096), %.spill.load49
  %.spill.load50 = load <8 x i64>, ptr %.spill4, align 64
  %195 = add <8 x i64> %.spill.load50, zeroinitializer
  %196 = add <8 x i64> zeroinitializer, %195
  %197 = add <8 x i64> zeroinitializer, %194
  %198 = mul <8 x i64> %196, splat (i64 4097)
  %199 = add <8 x i64> %198, %197
  %200 = extractvalue { ptr, i64 } %15, 0
  %201 = select <8 x i1> %186, <8 x i64> %199, <8 x i64> zeroinitializer
  %202 = extractelement <8 x i64> %201, i32 %193
  %203 = zext i32 %193 to i64
  %204 = sub i64 %202, %203
  %205 = mul i64 %204, 4
  %buffer.contiguous.address51 = getelementptr i8, ptr %200, i64 %205
  %buffer.contiguous.load52 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address51, <8 x i1> %186, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %208 = add <8 x i64> %207, splat (i64 16384)
  %209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %206, 0
  %210 = insertvalue { <8 x ptr>, <8 x i64> } %209, <8 x i64> %208, 1
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %210, 1
  %213 = extractelement <8 x ptr> %211, i32 0
  %214 = extractelement <8 x i64> %212, i32 %193
  %215 = zext i32 %193 to i64
  %216 = mul i64 %215, 4
  %217 = sub i64 %214, %216
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %186)
  %219 = select i1 %218, i64 %217, i64 0
  %private.contiguous.address54 = getelementptr i8, ptr %213, i64 %219
  %private.contiguous.preserve55 = load <8 x float>, ptr %private.contiguous.address54, align 4
  %220 = select <8 x i1> %186, <8 x float> %buffer.contiguous.load52, <8 x float> %private.contiguous.preserve55
  store <8 x float> %220, ptr %private.contiguous.address54, align 4
  %221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %188)
  %222 = bitcast <8 x i1> %188 to i8
  %223 = call i8 @llvm.cttz.i8(i8 %222, i1 false)
  %224 = zext i8 %223 to i32
  %225 = select i1 %221, i32 %224, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %226 = load <8 x i64>, ptr %.slot8, align 64
  %227 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %226
  store <8 x i64> %227, ptr %.slot8, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state56 = load <8 x i64>, ptr %.slot8, align 64
  %228 = icmp slt <8 x i64> %.state56, splat (i64 512)
  %229 = extractelement <8 x i1> %228, i32 0
  br i1 %229, label %direct.true57, label %direct.false58

direct.schedule.12:                               ; preds = %direct.true57
  %.state59 = load <8 x i64>, ptr %.slot8, align 64
  %230 = mul <8 x i64> %.state59, splat (i64 8)
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %231 = add <8 x i64> %230, %.spill.load60
  %.spill.load61 = load <8 x i64>, ptr %.spill4, align 64
  %232 = add <8 x i64> %.spill.load61, zeroinitializer
  %233 = add <8 x i64> zeroinitializer, %232
  %234 = add <8 x i64> zeroinitializer, %231
  %235 = mul <8 x i64> %233, splat (i64 4097)
  %236 = add <8 x i64> %235, %234
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %.state63 = load <8 x i64>, ptr %.slot8, align 64
  %239 = mul <8 x i64> %.state63, splat (i64 32)
  %240 = add <8 x i64> %238, %239
  %241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %237, 0
  %242 = insertvalue { <8 x ptr>, <8 x i64> } %241, <8 x i64> %240, 1
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %245 = extractelement <8 x ptr> %243, i32 0
  %246 = extractelement <8 x i64> %244, i32 0
  %247 = sub i64 %246, 0
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %249 = select i1 %248, i64 %247, i64 0
  %private.contiguous.address64 = getelementptr i8, ptr %245, i64 %249
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address64, align 4
  %250 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %251 = fneg <8 x float> %250
  %252 = select <8 x i1> %51, <8 x float> %251, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %252)
  %253 = fadd <8 x float> splat (float 1.000000e+00), %native.exp
  %254 = fdiv <8 x float> %250, %253
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %.state66 = load <8 x i64>, ptr %.slot8, align 64
  %257 = mul <8 x i64> %.state66, splat (i64 32)
  %258 = add <8 x i64> %256, %257
  %259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %255, 0
  %260 = insertvalue { <8 x ptr>, <8 x i64> } %259, <8 x i64> %258, 1
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %260, 1
  %263 = extractelement <8 x ptr> %261, i32 0
  %264 = extractelement <8 x i64> %262, i32 0
  %265 = sub i64 %264, 0
  %266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %267 = select i1 %266, i64 %265, i64 0
  %private.contiguous.address67 = getelementptr i8, ptr %263, i64 %267
  %private.contiguous.load68 = load <8 x float>, ptr %private.contiguous.address67, align 4
  %268 = select <8 x i1> %51, <8 x float> %private.contiguous.load68, <8 x float> zeroinitializer
  %269 = fmul <8 x float> %254, %268
  %270 = extractvalue { ptr, i64 } %27, 0
  %271 = extractelement <8 x i64> %236, i32 0
  %272 = sub i64 %271, 0
  %273 = mul i64 %272, 4
  %buffer.contiguous.address69 = getelementptr i8, ptr %270, i64 %273
  call void @llvm.masked.store.v8f32.p0(<8 x float> %269, ptr align 1 %buffer.contiguous.address69, <8 x i1> %51)
  %.state70 = load <8 x i64>, ptr %.slot8, align 64
  %274 = add <8 x i64> %.state70, splat (i64 1)
  %275 = load <8 x i64>, ptr %.slot8, align 64
  %276 = select <8 x i1> %51, <8 x i64> %274, <8 x i64> %275
  store <8 x i64> %276, ptr %.slot8, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false58
  %.spill.load71 = load <8 x i1>, ptr %.spill5, align 1
  %277 = and <8 x i1> %51, %.spill.load71
  %278 = xor <8 x i1> %.spill.load71, splat (i1 true)
  %279 = and <8 x i1> %51, %278
  %280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %277)
  %281 = bitcast <8 x i1> %277 to i8
  %282 = call i8 @llvm.cttz.i8(i8 %281, i1 false)
  %283 = zext i8 %282 to i32
  %284 = select i1 %280, i32 %283, i32 0
  %.spill.load72 = load <8 x i64>, ptr %.spill, align 64
  %285 = add <8 x i64> splat (i64 4096), %.spill.load72
  %.spill.load73 = load <8 x i64>, ptr %.spill4, align 64
  %286 = add <8 x i64> %.spill.load73, zeroinitializer
  %287 = add <8 x i64> zeroinitializer, %286
  %288 = add <8 x i64> zeroinitializer, %285
  %289 = mul <8 x i64> %287, splat (i64 4097)
  %290 = add <8 x i64> %289, %288
  %tile_snapshot.spill.load74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 0
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 1
  %293 = add <8 x i64> %292, splat (i64 16384)
  %294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %291, 0
  %295 = insertvalue { <8 x ptr>, <8 x i64> } %294, <8 x i64> %293, 1
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %295, 1
  %298 = extractelement <8 x ptr> %296, i32 0
  %299 = extractelement <8 x i64> %297, i32 %284
  %300 = zext i32 %284 to i64
  %301 = mul i64 %300, 4
  %302 = sub i64 %299, %301
  %303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %277)
  %304 = select i1 %303, i64 %302, i64 0
  %private.contiguous.address75 = getelementptr i8, ptr %298, i64 %304
  %private.contiguous.load76 = load <8 x float>, ptr %private.contiguous.address75, align 4
  %305 = select <8 x i1> %277, <8 x float> %private.contiguous.load76, <8 x float> zeroinitializer
  %306 = fneg <8 x float> %305
  %307 = select <8 x i1> %277, <8 x float> %306, <8 x float> zeroinitializer
  %native.exp77 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %307)
  %308 = fadd <8 x float> splat (float 1.000000e+00), %native.exp77
  %309 = fdiv <8 x float> %305, %308
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %312 = add <8 x i64> %311, splat (i64 16384)
  %313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %310, 0
  %314 = insertvalue { <8 x ptr>, <8 x i64> } %313, <8 x i64> %312, 1
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %314, 1
  %317 = extractelement <8 x ptr> %315, i32 0
  %318 = extractelement <8 x i64> %316, i32 %284
  %319 = zext i32 %284 to i64
  %320 = mul i64 %319, 4
  %321 = sub i64 %318, %320
  %322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %277)
  %323 = select i1 %322, i64 %321, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %317, i64 %323
  %private.contiguous.load80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %324 = select <8 x i1> %277, <8 x float> %private.contiguous.load80, <8 x float> zeroinitializer
  %325 = fmul <8 x float> %309, %324
  %326 = extractvalue { ptr, i64 } %27, 0
  %327 = extractelement <8 x i64> %290, i32 %284
  %328 = zext i32 %284 to i64
  %329 = sub i64 %327, %328
  %330 = mul i64 %329, 4
  %buffer.contiguous.address81 = getelementptr i8, ptr %326, i64 %330
  call void @llvm.masked.store.v8f32.p0(<8 x float> %325, ptr align 1 %buffer.contiguous.address81, <8 x i1> %277)
  %331 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %279)
  %332 = bitcast <8 x i1> %279 to i8
  %333 = call i8 @llvm.cttz.i8(i8 %332, i1 false)
  %334 = zext i8 %333 to i32
  %335 = select i1 %331, i32 %334, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true36:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false37:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true57:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false58:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #2 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #3

define internal void @llm_rows.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %tile_snapshot.local = alloca [16416 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16416 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %tile_snapshot.spill6 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill6, align 64
  %.slot7 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot7, align 64
  %.slot8 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot8, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert9 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat10 = shufflevector <8 x i32> %.splatinsert9, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat10, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert11 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat12 = shufflevector <8 x i32> %.splatinsert11, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat12, %41
  %44 = mul i32 %32, 1
  %.splatinsert13 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat14 = shufflevector <8 x i32> %.splatinsert13, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat14, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert15 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat16 = shufflevector <8 x i32> %.splatinsert15, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat16, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert17 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat18
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 512
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state19 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state19, 8
  %.splatinsert20 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat21 = shufflevector <8 x i64> %.splatinsert20, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat21, %.spill.load
  %.spill.load22 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load22, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 4097)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state23 = load i64, ptr %.slot, align 4
  %.splatinsert24 = insertelement <8 x i64> poison, i64 %.state23, i64 0
  %.splat25 = shufflevector <8 x i64> %.splatinsert24, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat25, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state26 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state26, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load27 = load <8 x i64>, ptr %.spill, align 64
  %102 = icmp slt <8 x i64> %.spill.load27, splat (i64 1)
  %103 = load <8 x i1>, ptr %.spill5, align 1
  %104 = select <8 x i1> %51, <8 x i1> %102, <8 x i1> %103
  store <8 x i1> %104, ptr %.spill5, align 1
  %105 = and <8 x i1> %51, %102
  %106 = xor <8 x i1> %102, splat (i1 true)
  %107 = and <8 x i1> %51, %106
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %109 = bitcast <8 x i1> %105 to i8
  %110 = call i8 @llvm.cttz.i8(i8 %109, i1 false)
  %111 = zext i8 %110 to i32
  %112 = select i1 %108, i32 %111, i32 0
  %.spill.load28 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> splat (i64 4096), %.spill.load28
  %.spill.load29 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load29, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 4097)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = select <8 x i1> %105, <8 x i64> %118, <8 x i64> zeroinitializer
  %121 = extractelement <8 x i64> %120, i32 %112
  %122 = zext i32 %112 to i64
  %123 = sub i64 %121, %122
  %124 = mul i64 %123, 4
  %buffer.contiguous.address30 = getelementptr i8, ptr %119, i64 %124
  %buffer.contiguous.load31 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address30, <8 x i1> %105, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load32 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load32, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load32, 1
  %127 = add <8 x i64> %126, splat (i64 16384)
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %132 = extractelement <8 x ptr> %130, i32 0
  %133 = extractelement <8 x i64> %131, i32 %112
  %134 = zext i32 %112 to i64
  %135 = mul i64 %134, 4
  %136 = sub i64 %133, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %138 = select i1 %137, i64 %136, i64 0
  %private.contiguous.address33 = getelementptr i8, ptr %132, i64 %138
  %private.contiguous.preserve34 = load <8 x float>, ptr %private.contiguous.address33, align 4
  %139 = select <8 x i1> %105, <8 x float> %buffer.contiguous.load31, <8 x float> %private.contiguous.preserve34
  store <8 x float> %139, ptr %private.contiguous.address33, align 4
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %107)
  %141 = bitcast <8 x i1> %107 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  %145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 0
  %148 = select <8 x i1> %51, <8 x ptr> %146, <8 x ptr> %147
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %151 = select <8 x i1> %51, <8 x i64> %149, <8 x i64> %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  store { <8 x ptr>, <8 x i64> } %153, ptr %tile_snapshot.spill6, align 64
  %154 = load <8 x i64>, ptr %.slot7, align 64
  %155 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %154
  store <8 x i64> %155, ptr %.slot7, align 64
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state35 = load <8 x i64>, ptr %.slot7, align 64
  %156 = icmp slt <8 x i64> %.state35, splat (i64 512)
  %157 = extractelement <8 x i1> %156, i32 0
  br i1 %157, label %direct.true36, label %direct.false37

direct.schedule.7:                                ; preds = %direct.true36
  %.state38 = load <8 x i64>, ptr %.slot7, align 64
  %158 = mul <8 x i64> %.state38, splat (i64 8)
  %.spill.load39 = load <8 x i64>, ptr %.spill, align 64
  %159 = add <8 x i64> %158, %.spill.load39
  %.spill.load40 = load <8 x i64>, ptr %.spill4, align 64
  %160 = add <8 x i64> %.spill.load40, zeroinitializer
  %161 = add <8 x i64> zeroinitializer, %160
  %162 = add <8 x i64> zeroinitializer, %159
  %163 = mul <8 x i64> %161, splat (i64 4097)
  %164 = add <8 x i64> %163, %162
  %165 = extractvalue { ptr, i64 } %15, 0
  %166 = extractelement <8 x i64> %164, i32 0
  %167 = sub i64 %166, 0
  %168 = mul i64 %167, 4
  %buffer.contiguous.address41 = getelementptr i8, ptr %165, i64 %168
  %buffer.contiguous.load42 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address41, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load43 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 0
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load43, 1
  %.state44 = load <8 x i64>, ptr %.slot7, align 64
  %171 = mul <8 x i64> %.state44, splat (i64 32)
  %172 = add <8 x i64> %170, %171
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %169, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %174, 1
  %177 = extractelement <8 x ptr> %175, i32 0
  %178 = extractelement <8 x i64> %176, i32 0
  %179 = sub i64 %178, 0
  %180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %181 = select i1 %180, i64 %179, i64 0
  %private.contiguous.address45 = getelementptr i8, ptr %177, i64 %181
  %private.contiguous.preserve46 = load <8 x float>, ptr %private.contiguous.address45, align 4
  %182 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load42, <8 x float> %private.contiguous.preserve46
  store <8 x float> %182, ptr %private.contiguous.address45, align 4
  %.state47 = load <8 x i64>, ptr %.slot7, align 64
  %183 = add <8 x i64> %.state47, splat (i64 1)
  %184 = load <8 x i64>, ptr %.slot7, align 64
  %185 = select <8 x i1> %51, <8 x i64> %183, <8 x i64> %184
  store <8 x i64> %185, ptr %.slot7, align 64
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false37
  %.spill.load48 = load <8 x i1>, ptr %.spill5, align 1
  %186 = and <8 x i1> %51, %.spill.load48
  %187 = xor <8 x i1> %.spill.load48, splat (i1 true)
  %188 = and <8 x i1> %51, %187
  %189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %186)
  %190 = bitcast <8 x i1> %186 to i8
  %191 = call i8 @llvm.cttz.i8(i8 %190, i1 false)
  %192 = zext i8 %191 to i32
  %193 = select i1 %189, i32 %192, i32 0
  %.spill.load49 = load <8 x i64>, ptr %.spill, align 64
  %194 = add <8 x i64> splat (i64 4096), %.spill.load49
  %.spill.load50 = load <8 x i64>, ptr %.spill4, align 64
  %195 = add <8 x i64> %.spill.load50, zeroinitializer
  %196 = add <8 x i64> zeroinitializer, %195
  %197 = add <8 x i64> zeroinitializer, %194
  %198 = mul <8 x i64> %196, splat (i64 4097)
  %199 = add <8 x i64> %198, %197
  %200 = extractvalue { ptr, i64 } %15, 0
  %201 = select <8 x i1> %186, <8 x i64> %199, <8 x i64> zeroinitializer
  %202 = extractelement <8 x i64> %201, i32 %193
  %203 = zext i32 %193 to i64
  %204 = sub i64 %202, %203
  %205 = mul i64 %204, 4
  %buffer.contiguous.address51 = getelementptr i8, ptr %200, i64 %205
  %buffer.contiguous.load52 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address51, <8 x i1> %186, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load53 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load53, 1
  %208 = add <8 x i64> %207, splat (i64 16384)
  %209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %206, 0
  %210 = insertvalue { <8 x ptr>, <8 x i64> } %209, <8 x i64> %208, 1
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %210, 1
  %213 = extractelement <8 x ptr> %211, i32 0
  %214 = extractelement <8 x i64> %212, i32 %193
  %215 = zext i32 %193 to i64
  %216 = mul i64 %215, 4
  %217 = sub i64 %214, %216
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %186)
  %219 = select i1 %218, i64 %217, i64 0
  %private.contiguous.address54 = getelementptr i8, ptr %213, i64 %219
  %private.contiguous.preserve55 = load <8 x float>, ptr %private.contiguous.address54, align 4
  %220 = select <8 x i1> %186, <8 x float> %buffer.contiguous.load52, <8 x float> %private.contiguous.preserve55
  store <8 x float> %220, ptr %private.contiguous.address54, align 4
  %221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %188)
  %222 = bitcast <8 x i1> %188 to i8
  %223 = call i8 @llvm.cttz.i8(i8 %222, i1 false)
  %224 = zext i8 %223 to i32
  %225 = select i1 %221, i32 %224, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %226 = load <8 x i64>, ptr %.slot8, align 64
  %227 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %226
  store <8 x i64> %227, ptr %.slot8, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state56 = load <8 x i64>, ptr %.slot8, align 64
  %228 = icmp slt <8 x i64> %.state56, splat (i64 512)
  %229 = extractelement <8 x i1> %228, i32 0
  br i1 %229, label %direct.true57, label %direct.false58

direct.schedule.12:                               ; preds = %direct.true57
  %.state59 = load <8 x i64>, ptr %.slot8, align 64
  %230 = mul <8 x i64> %.state59, splat (i64 8)
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %231 = add <8 x i64> %230, %.spill.load60
  %.spill.load61 = load <8 x i64>, ptr %.spill4, align 64
  %232 = add <8 x i64> %.spill.load61, zeroinitializer
  %233 = add <8 x i64> zeroinitializer, %232
  %234 = add <8 x i64> zeroinitializer, %231
  %235 = mul <8 x i64> %233, splat (i64 4097)
  %236 = add <8 x i64> %235, %234
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %.state63 = load <8 x i64>, ptr %.slot8, align 64
  %239 = mul <8 x i64> %.state63, splat (i64 32)
  %240 = add <8 x i64> %238, %239
  %241 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %237, 0
  %242 = insertvalue { <8 x ptr>, <8 x i64> } %241, <8 x i64> %240, 1
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %242, 1
  %245 = extractelement <8 x ptr> %243, i32 0
  %246 = extractelement <8 x i64> %244, i32 0
  %247 = sub i64 %246, 0
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %249 = select i1 %248, i64 %247, i64 0
  %private.contiguous.address64 = getelementptr i8, ptr %245, i64 %249
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address64, align 4
  %250 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %251 = fneg <8 x float> %250
  %252 = select <8 x i1> %51, <8 x float> %251, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %252)
  %253 = fadd <8 x float> splat (float 1.000000e+00), %native.exp
  %254 = fdiv <8 x float> %250, %253
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %.state66 = load <8 x i64>, ptr %.slot8, align 64
  %257 = mul <8 x i64> %.state66, splat (i64 32)
  %258 = add <8 x i64> %256, %257
  %259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %255, 0
  %260 = insertvalue { <8 x ptr>, <8 x i64> } %259, <8 x i64> %258, 1
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %260, 1
  %263 = extractelement <8 x ptr> %261, i32 0
  %264 = extractelement <8 x i64> %262, i32 0
  %265 = sub i64 %264, 0
  %266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %267 = select i1 %266, i64 %265, i64 0
  %private.contiguous.address67 = getelementptr i8, ptr %263, i64 %267
  %private.contiguous.load68 = load <8 x float>, ptr %private.contiguous.address67, align 4
  %268 = select <8 x i1> %51, <8 x float> %private.contiguous.load68, <8 x float> zeroinitializer
  %269 = fmul <8 x float> %254, %268
  %270 = extractvalue { ptr, i64 } %27, 0
  %271 = extractelement <8 x i64> %236, i32 0
  %272 = sub i64 %271, 0
  %273 = mul i64 %272, 4
  %buffer.contiguous.address69 = getelementptr i8, ptr %270, i64 %273
  call void @llvm.masked.store.v8f32.p0(<8 x float> %269, ptr align 1 %buffer.contiguous.address69, <8 x i1> %51)
  %.state70 = load <8 x i64>, ptr %.slot8, align 64
  %274 = add <8 x i64> %.state70, splat (i64 1)
  %275 = load <8 x i64>, ptr %.slot8, align 64
  %276 = select <8 x i1> %51, <8 x i64> %274, <8 x i64> %275
  store <8 x i64> %276, ptr %.slot8, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false58
  %.spill.load71 = load <8 x i1>, ptr %.spill5, align 1
  %277 = and <8 x i1> %51, %.spill.load71
  %278 = xor <8 x i1> %.spill.load71, splat (i1 true)
  %279 = and <8 x i1> %51, %278
  %280 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %277)
  %281 = bitcast <8 x i1> %277 to i8
  %282 = call i8 @llvm.cttz.i8(i8 %281, i1 false)
  %283 = zext i8 %282 to i32
  %284 = select i1 %280, i32 %283, i32 0
  %.spill.load72 = load <8 x i64>, ptr %.spill, align 64
  %285 = add <8 x i64> splat (i64 4096), %.spill.load72
  %.spill.load73 = load <8 x i64>, ptr %.spill4, align 64
  %286 = add <8 x i64> %.spill.load73, zeroinitializer
  %287 = add <8 x i64> zeroinitializer, %286
  %288 = add <8 x i64> zeroinitializer, %285
  %289 = mul <8 x i64> %287, splat (i64 4097)
  %290 = add <8 x i64> %289, %288
  %tile_snapshot.spill.load74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 0
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 1
  %293 = add <8 x i64> %292, splat (i64 16384)
  %294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %291, 0
  %295 = insertvalue { <8 x ptr>, <8 x i64> } %294, <8 x i64> %293, 1
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %295, 1
  %298 = extractelement <8 x ptr> %296, i32 0
  %299 = extractelement <8 x i64> %297, i32 %284
  %300 = zext i32 %284 to i64
  %301 = mul i64 %300, 4
  %302 = sub i64 %299, %301
  %303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %277)
  %304 = select i1 %303, i64 %302, i64 0
  %private.contiguous.address75 = getelementptr i8, ptr %298, i64 %304
  %private.contiguous.load76 = load <8 x float>, ptr %private.contiguous.address75, align 4
  %305 = select <8 x i1> %277, <8 x float> %private.contiguous.load76, <8 x float> zeroinitializer
  %306 = fneg <8 x float> %305
  %307 = select <8 x i1> %277, <8 x float> %306, <8 x float> zeroinitializer
  %native.exp77 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %307)
  %308 = fadd <8 x float> splat (float 1.000000e+00), %native.exp77
  %309 = fdiv <8 x float> %305, %308
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill6, align 64
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %312 = add <8 x i64> %311, splat (i64 16384)
  %313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %310, 0
  %314 = insertvalue { <8 x ptr>, <8 x i64> } %313, <8 x i64> %312, 1
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %314, 1
  %317 = extractelement <8 x ptr> %315, i32 0
  %318 = extractelement <8 x i64> %316, i32 %284
  %319 = zext i32 %284 to i64
  %320 = mul i64 %319, 4
  %321 = sub i64 %318, %320
  %322 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %277)
  %323 = select i1 %322, i64 %321, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %317, i64 %323
  %private.contiguous.load80 = load <8 x float>, ptr %private.contiguous.address79, align 4
  %324 = select <8 x i1> %277, <8 x float> %private.contiguous.load80, <8 x float> zeroinitializer
  %325 = fmul <8 x float> %309, %324
  %326 = extractvalue { ptr, i64 } %27, 0
  %327 = extractelement <8 x i64> %290, i32 %284
  %328 = zext i32 %284 to i64
  %329 = sub i64 %327, %328
  %330 = mul i64 %329, 4
  %buffer.contiguous.address81 = getelementptr i8, ptr %326, i64 %330
  call void @llvm.masked.store.v8f32.p0(<8 x float> %325, ptr align 1 %buffer.contiguous.address81, <8 x i1> %277)
  %331 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %279)
  %332 = bitcast <8 x i1> %279 to i8
  %333 = call i8 @llvm.cttz.i8(i8 %332, i1 false)
  %334 = zext i8 %333 to i32
  %335 = select i1 %331, i32 %334, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true36:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false37:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true57:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false58:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13
}

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	d11, d10, [sp, #-48]!           ; 16-byte Folded Spill
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	sub	sp, sp, #576
	ldr	x12, [x0]
	ldr	x10, [x0, #16]
	ldr	x8, [x0, #48]
	ldr	w9, [x1]
	ldr	w11, [x1, #36]
	add	w9, w11, w9, lsl #5
	lsr	w9, w9, #3
	dup.2s	v0, w9
	ushll.2d	v0, v0, #0
	subs	x9, x12, x8
	cset	w11, hs
	lsr	x9, x9, #2
	cmp	x9, #1104
	csel	w9, wzr, w11, ls
	subs	x11, x8, x12
	cset	w13, hs
	lsr	x11, x11, #2
	cmp	x11, #1104
	csel	w11, wzr, w13, ls
	orr	w11, w9, w11
	subs	x9, x10, x8
	cset	w13, hs
	lsr	x9, x9, #2
	cmp	x9, #1104
	csel	w9, wzr, w13, ls
	subs	x13, x8, x10
	cset	w14, hs
	lsr	x13, x13, #2
	cmp	x13, #1104
	csel	w13, wzr, w14, ls
	orr	w13, w9, w13
	fmov	x9, d0
	add	x9, x9, x9, lsl #6
	lsl	x9, x9, #2
	cmp	w11, #1
	mov	x11, #0                         ; =0x0
	ccmp	w13, #0, #4, eq
	b.ne	LBB0_4
; %bb.1:                                ; %direct.schedule.8.preheader
	add	x9, x12, x9
	ldp	q1, q2, [x9, #192]
	stp	q1, q2, [sp, #480]
	ldp	q1, q2, [x9, #224]
	stp	q1, q2, [sp, #512]
	ldp	q1, q2, [x9, #128]
	stp	q1, q2, [sp, #416]
	ldp	q1, q2, [x9, #160]
	stp	q1, q2, [sp, #448]
	ldp	q1, q2, [x9, #64]
	stp	q1, q2, [sp, #352]
	ldp	q1, q2, [x9, #96]
	stp	q1, q2, [sp, #384]
	ldp	q1, q2, [x9]
	stp	q1, q2, [sp, #288]
	ldp	q1, q2, [x9, #32]
	stp	q1, q2, [sp, #320]
	fmov	x9, d0
	add	x9, x9, x9, lsl #6
	lsl	x13, x9, #2
	add	x9, x13, #256
	ldr	s1, [x12, x9]
	str	q1, [sp, #544]
	add	x12, x10, x13
	ldp	q0, q2, [x12, #192]
	stp	q0, q2, [sp, #192]
	ldp	q0, q2, [x12, #224]
	stp	q0, q2, [sp, #224]
	ldp	q0, q2, [x12, #128]
	stp	q0, q2, [sp, #128]
	ldp	q0, q2, [x12, #160]
	stp	q0, q2, [sp, #160]
	ldp	q0, q2, [x12, #64]
	stp	q0, q2, [sp, #64]
	ldp	q0, q2, [x12, #96]
	stp	q0, q2, [sp, #96]
	ldp	q21, q22, [x12]
	ldp	q23, q24, [x12, #32]
	ldr	s0, [x10, x9]
	add	x10, x8, x13
	mov	w12, #1120927744                ; =0x42d00000
	dup.4s	v2, w12
	mov	w12, #-1027080192               ; =0xc2c80000
	dup.4s	v3, w12
	mov	w12, #43579                     ; =0xaa3b
	movk	w12, #16312, lsl #16
	dup.4s	v4, w12
	add	x12, sp, #288
	movi.4s	v5, #75, lsl #24
	mvni.4s	v6, #128, lsl #24
	mov	w13, #29184                     ; =0x7200
	movk	w13, #48945, lsl #16
	dup.4s	v7, w13
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #46527, lsl #16
	dup.4s	v16, w13
	mov	w13, #11226                     ; =0x2bda
	movk	w13, #14672, lsl #16
	dup.4s	v17, w13
	mov	w13, #38601                     ; =0x96c9
	movk	w13, #15030, lsl #16
	dup.4s	v18, w13
	mov	w13, #34982                     ; =0x88a6
	movk	w13, #15368, lsl #16
	dup.4s	v19, w13
	mov	w13, #43642                     ; =0xaa7a
	movk	w13, #15658, lsl #16
	dup.4s	v20, w13
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15914, lsl #16
	stp	q21, q22, [sp]
	movi.4s	v21, #63, lsl #24
	fmov.4s	v22, #1.00000000
	mvni.4s	v25, #127, msl #16
	stp	q23, q24, [sp, #32]
	fneg.4s	v23, v25
	dup.4s	v24, w13
	mvni.4s	v25, #63, msl #16
	fneg.4s	v25, v25
	mov	x13, sp
	str	q0, [sp, #256]
LBB0_2:                                 ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x12, x11
	ldp	q26, q27, [x14]
	fneg.4s	v28, v27
	fneg.4s	v29, v26
	fcmge.4s	v30, v2, v26
	fcmge.4s	v31, v2, v27
	fcmge.4s	v8, v26, v3
	fcmge.4s	v9, v27, v3
	and.16b	v31, v31, v9
	and.16b	v30, v30, v8
	and.16b	v29, v30, v29
	and.16b	v28, v31, v28
	fmul.4s	v30, v28, v4
	fmul.4s	v31, v29, v4
	mov.16b	v8, v6
	bsl.16b	v8, v5, v31
	mov.16b	v9, v6
	bsl.16b	v9, v5, v30
	fadd.4s	v30, v30, v9
	fadd.4s	v31, v31, v8
	fsub.4s	v31, v31, v8
	fsub.4s	v30, v30, v9
	fcvtzs.4s	v30, v30
	fcvtzs.4s	v31, v31
	scvtf.4s	v8, v31
	scvtf.4s	v9, v30
	fmul.4s	v10, v9, v7
	fmul.4s	v11, v8, v7
	fadd.4s	v29, v29, v11
	fadd.4s	v28, v28, v10
	fmul.4s	v8, v8, v16
	fmul.4s	v9, v9, v16
	fadd.4s	v28, v28, v9
	fadd.4s	v29, v29, v8
	fmul.4s	v8, v29, v17
	fmul.4s	v9, v28, v17
	fadd.4s	v9, v9, v18
	fadd.4s	v8, v8, v18
	fmul.4s	v8, v29, v8
	fmul.4s	v9, v28, v9
	fadd.4s	v9, v9, v19
	fadd.4s	v8, v8, v19
	fmul.4s	v8, v29, v8
	fmul.4s	v9, v28, v9
	fadd.4s	v9, v9, v20
	fadd.4s	v8, v8, v20
	fmul.4s	v8, v29, v8
	fmul.4s	v9, v28, v9
	fadd.4s	v9, v9, v24
	fadd.4s	v8, v8, v24
	fmul.4s	v8, v29, v8
	fmul.4s	v9, v28, v9
	fadd.4s	v9, v9, v21
	fadd.4s	v8, v8, v21
	fmul.4s	v10, v28, v28
	fmul.4s	v11, v29, v29
	fmul.4s	v8, v11, v8
	fmul.4s	v9, v10, v9
	fadd.4s	v28, v28, v9
	fadd.4s	v29, v29, v8
	sshr.4s	v8, v31, #1
	fadd.4s	v29, v29, v22
	sshr.4s	v9, v30, #1
	shl.4s	v10, v9, #23
	shl.4s	v11, v8, #23
	add.4s	v11, v11, v22
	add.4s	v10, v10, v22
	fadd.4s	v28, v28, v22
	fmul.4s	v28, v28, v10
	sub.4s	v30, v30, v9
	sub.4s	v31, v31, v8
	shl.4s	v31, v31, #23
	shl.4s	v30, v30, #23
	fmul.4s	v29, v29, v11
	add.4s	v30, v30, v22
	add.4s	v31, v31, v22
	fmul.4s	v29, v29, v31
	fmul.4s	v28, v28, v30
	fcmgt.4s	v30, v27, v2
	fcmgt.4s	v31, v26, v2
	fcmgt.4s	v8, v3, v26
	fcmgt.4s	v9, v3, v27
	fcmeq.4s	v10, v27, v27
	fadd.4s	v28, v28, v22
	fadd.4s	v29, v29, v22
	fcmeq.4s	v11, v26, v26
	bit.16b	v29, v22, v31
	bit.16b	v28, v22, v30
	bit.16b	v28, v23, v9
	bit.16b	v29, v23, v8
	bif.16b	v29, v25, v11
	bif.16b	v28, v25, v10
	fdiv.4s	v27, v27, v28
	fdiv.4s	v26, v26, v29
	add	x14, x13, x11
	ldp	q29, q28, [x14]
	fmul.4s	v26, v29, v26
	fmul.4s	v27, v28, v27
	add	x14, x10, x11
	stp	q26, q27, [x14]
	add	x11, x11, #32
	cmp	x11, #256
	b.ne	LBB0_2
; %bb.3:                                ; %direct.false84
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	mov.s	v2[0], v1[0]
	fneg.4s	v1, v2
	mov.s	v3[0], v1[0]
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v1, w10
	fcmge.4s	v4, v3, v1
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v5, w10
	fcmge.4s	v6, v5, v3
	and.16b	v4, v4, v6
	and.16b	v4, v4, v3
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v6, w10
	fmul.4s	v6, v4, v6
	movi.4s	v7, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	bif.16b	v7, v6, v16
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	fcvtzs.4s	v6, v6
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v7, w10
	scvtf.4s	v16, v6
	fmul.4s	v7, v16, v7
	fadd.4s	v4, v4, v7
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v7, w10
	fmul.4s	v7, v16, v7
	fadd.4s	v4, v4, v7
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v7, w10
	fmul.4s	v7, v4, v7
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v16, w10
	fadd.4s	v7, v7, v16
	fmul.4s	v7, v4, v7
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v16, w10
	fadd.4s	v7, v7, v16
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v16, w10
	fmul.4s	v7, v4, v7
	fadd.4s	v7, v7, v16
	fmul.4s	v7, v4, v7
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v16, w10
	fadd.4s	v7, v7, v16
	fmul.4s	v7, v4, v7
	movi.4s	v16, #63, lsl #24
	fadd.4s	v7, v7, v16
	fmul.4s	v16, v4, v4
	fmul.4s	v7, v16, v7
	fadd.4s	v4, v4, v7
	fmov.4s	v7, #1.00000000
	fadd.4s	v4, v4, v7
	sshr.4s	v16, v6, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v7
	fmul.4s	v4, v4, v17
	sub.4s	v6, v6, v16
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v7
	fmul.4s	v4, v4, v6
	fcmgt.4s	v1, v1, v3
	fcmgt.4s	v5, v3, v5
	fcmeq.4s	v3, v3, v3
	fadd.4s	v4, v4, v7
	bsl.16b	v1, v7, v4
	mvni.4s	v4, #127, msl #16
	fneg.4s	v4, v4
	bit.16b	v1, v4, v5
	mvni.4s	v4, #63, msl #16
	fneg.4s	v4, v4
	bif.16b	v1, v4, v3
	fdiv.4s	v1, v2, v1
	b	LBB0_7
LBB0_4:                                 ; %direct.true20.preheader
	add	x13, x8, x9
	add	x14, x10, x9
	mov	w15, #1120927744                ; =0x42d00000
	dup.4s	v0, w15
	mov	w15, #-1027080192               ; =0xc2c80000
	dup.4s	v1, w15
	mov	w15, #43579                     ; =0xaa3b
	movk	w15, #16312, lsl #16
	dup.4s	v2, w15
	mov	w15, #29184                     ; =0x7200
	movk	w15, #48945, lsl #16
	dup.4s	v3, w15
	mov	w15, #48782                     ; =0xbe8e
	movk	w15, #46527, lsl #16
	dup.4s	v4, w15
	mov	w15, #11226                     ; =0x2bda
	movk	w15, #14672, lsl #16
	dup.4s	v5, w15
	mov	w15, #38601                     ; =0x96c9
	movk	w15, #15030, lsl #16
	dup.4s	v6, w15
	mov	w15, #34982                     ; =0x88a6
	movk	w15, #15368, lsl #16
	dup.4s	v7, w15
	mov	w15, #43642                     ; =0xaa7a
	movk	w15, #15658, lsl #16
	dup.4s	v16, w15
	mov	w15, #43691                     ; =0xaaab
	movk	w15, #15914, lsl #16
	dup.4s	v17, w15
	add	x15, x12, x9
	movi.4s	v18, #75, lsl #24
	mvni.4s	v19, #128, lsl #24
	movi.4s	v20, #63, lsl #24
	fmov.4s	v21, #1.00000000
	mvni.4s	v22, #127, msl #16
	fneg.4s	v22, v22
	mvni.4s	v23, #63, msl #16
	fneg.4s	v23, v23
LBB0_5:                                 ; %direct.true20
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x15, x11
	ldp	q24, q25, [x16]
	fneg.4s	v26, v25
	fneg.4s	v27, v24
	fcmge.4s	v28, v0, v24
	fcmge.4s	v29, v0, v25
	fcmge.4s	v30, v24, v1
	fcmge.4s	v31, v25, v1
	and.16b	v29, v29, v31
	and.16b	v28, v28, v30
	and.16b	v27, v28, v27
	and.16b	v26, v29, v26
	fmul.4s	v28, v26, v2
	fmul.4s	v29, v27, v2
	mov.16b	v30, v19
	bsl.16b	v30, v18, v29
	mov.16b	v31, v19
	bsl.16b	v31, v18, v28
	fadd.4s	v28, v28, v31
	fadd.4s	v29, v29, v30
	fsub.4s	v29, v29, v30
	fsub.4s	v28, v28, v31
	fcvtzs.4s	v28, v28
	fcvtzs.4s	v29, v29
	scvtf.4s	v30, v29
	scvtf.4s	v31, v28
	fmul.4s	v8, v31, v3
	fmul.4s	v9, v30, v3
	fadd.4s	v27, v27, v9
	fadd.4s	v26, v26, v8
	fmul.4s	v30, v30, v4
	fmul.4s	v31, v31, v4
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	fmul.4s	v30, v27, v5
	fmul.4s	v31, v26, v5
	fadd.4s	v31, v31, v6
	fadd.4s	v30, v30, v6
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v7
	fadd.4s	v30, v30, v7
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v16
	fadd.4s	v30, v30, v16
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v17
	fadd.4s	v30, v30, v17
	fmul.4s	v30, v27, v30
	fmul.4s	v31, v26, v31
	fadd.4s	v31, v31, v20
	fadd.4s	v30, v30, v20
	fmul.4s	v8, v26, v26
	fmul.4s	v9, v27, v27
	fmul.4s	v30, v9, v30
	fmul.4s	v31, v8, v31
	fadd.4s	v26, v26, v31
	fadd.4s	v27, v27, v30
	sshr.4s	v30, v29, #1
	fadd.4s	v27, v27, v21
	sshr.4s	v31, v28, #1
	shl.4s	v8, v31, #23
	shl.4s	v9, v30, #23
	add.4s	v9, v9, v21
	add.4s	v8, v8, v21
	fadd.4s	v26, v26, v21
	fmul.4s	v26, v26, v8
	sub.4s	v28, v28, v31
	sub.4s	v29, v29, v30
	shl.4s	v29, v29, #23
	shl.4s	v28, v28, #23
	fmul.4s	v27, v27, v9
	add.4s	v28, v28, v21
	add.4s	v29, v29, v21
	fmul.4s	v27, v27, v29
	fmul.4s	v26, v26, v28
	fcmgt.4s	v28, v25, v0
	fcmgt.4s	v29, v24, v0
	fcmgt.4s	v30, v1, v24
	fcmgt.4s	v31, v1, v25
	fcmeq.4s	v8, v25, v25
	fadd.4s	v26, v26, v21
	fadd.4s	v27, v27, v21
	fcmeq.4s	v9, v24, v24
	bit.16b	v27, v21, v29
	bit.16b	v26, v21, v28
	bit.16b	v26, v22, v31
	bit.16b	v27, v22, v30
	bif.16b	v27, v23, v9
	bif.16b	v26, v23, v8
	fdiv.4s	v25, v25, v26
	fdiv.4s	v24, v24, v27
	add	x16, x14, x11
	ldp	q27, q26, [x16]
	fmul.4s	v24, v27, v24
	fmul.4s	v25, v26, v25
	add	x16, x13, x11
	stp	q24, q25, [x16]
	add	x11, x11, #32
	cmp	x11, #256
	b.ne	LBB0_5
; %bb.6:                                ; %direct.false21
	add	x9, x9, #256
	ldr	s2, [x12, x9]
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	mov.s	v0[0], v2[0]
	fneg.4s	v2, v0
	mov.s	v1[0], v2[0]
	mov	w11, #-1026555904               ; =0xc2d00000
	dup.4s	v2, w11
	fcmge.4s	v3, v1, v2
	mov	w11, #1120403456                ; =0x42c80000
	dup.4s	v4, w11
	fcmge.4s	v5, v4, v1
	and.16b	v3, v3, v5
	and.16b	v3, v3, v1
	mov	w11, #43579                     ; =0xaa3b
	movk	w11, #16312, lsl #16
	dup.4s	v5, w11
	fmul.4s	v5, v3, v5
	movi.4s	v6, #75, lsl #24
	mvni.4s	v7, #128, lsl #24
	bif.16b	v6, v5, v7
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	fcvtzs.4s	v5, v5
	scvtf.4s	v6, v5
	mov	w11, #29184                     ; =0x7200
	movk	w11, #48945, lsl #16
	dup.4s	v7, w11
	fmul.4s	v7, v6, v7
	fadd.4s	v3, v3, v7
	mov	w11, #48782                     ; =0xbe8e
	movk	w11, #46527, lsl #16
	dup.4s	v7, w11
	fmul.4s	v6, v6, v7
	fadd.4s	v3, v3, v6
	mov	w11, #11226                     ; =0x2bda
	movk	w11, #14672, lsl #16
	dup.4s	v6, w11
	mov	w11, #38601                     ; =0x96c9
	movk	w11, #15030, lsl #16
	dup.4s	v7, w11
	fmul.4s	v6, v3, v6
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v3, v6
	mov	w11, #34982                     ; =0x88a6
	movk	w11, #15368, lsl #16
	dup.4s	v7, w11
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v3, v6
	mov	w11, #43642                     ; =0xaa7a
	movk	w11, #15658, lsl #16
	dup.4s	v7, w11
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v3, v6
	mov	w11, #43691                     ; =0xaaab
	movk	w11, #15914, lsl #16
	dup.4s	v7, w11
	fadd.4s	v6, v6, v7
	fmul.4s	v6, v3, v6
	movi.4s	v7, #63, lsl #24
	fadd.4s	v6, v6, v7
	fmul.4s	v7, v3, v3
	fmul.4s	v6, v7, v6
	fadd.4s	v3, v3, v6
	fmov.4s	v6, #1.00000000
	fadd.4s	v3, v3, v6
	sshr.4s	v7, v5, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v6
	fmul.4s	v3, v3, v16
	sub.4s	v5, v5, v7
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v6
	fmul.4s	v3, v3, v5
	fcmgt.4s	v2, v2, v1
	fcmgt.4s	v4, v1, v4
	fcmeq.4s	v1, v1, v1
	fadd.4s	v3, v3, v6
	bsl.16b	v2, v6, v3
	mvni.4s	v3, #127, msl #16
	fneg.4s	v3, v3
	bit.16b	v2, v3, v4
	mvni.4s	v3, #63, msl #16
	fneg.4s	v3, v3
	bsl.16b	v1, v2, v3
	fdiv.4s	v0, v0, v1
	ldr	s1, [x10, x9]
LBB0_7:                                 ; %common.ret
	fmul.4s	v0, v1, v0
	str	s0, [x8, x9]
	add	sp, sp, #576
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp], #48             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_7:
	.quad	256                             ; 0x100
	.quad	260                             ; 0x104
lCPI1_8:
	.quad	272                             ; 0x110
	.quad	276                             ; 0x114
lCPI1_9:
	.quad	264                             ; 0x108
	.quad	268                             ; 0x10c
lCPI1_10:
	.quad	280                             ; 0x118
	.quad	284                             ; 0x11c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1248
	str	x0, [sp, #232]                  ; 8-byte Spill
	cbz	w3, LBB1_208
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x19, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	ldp	w23, w8, [x2, #44]
	str	w8, [sp, #228]                  ; 4-byte Spill
	ldp	w27, w26, [x2]
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [sp, #256]                  ; 16-byte Spill
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #160]                  ; 16-byte Spill
Lloh4:
	adrp	x8, lCPI1_2@PAGE
Lloh5:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Spill
Lloh6:
	adrp	x8, lCPI1_3@PAGE
Lloh7:
	ldr	q0, [x8, lCPI1_3@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Spill
Lloh8:
	adrp	x8, lCPI1_4@PAGE
Lloh9:
	ldr	q0, [x8, lCPI1_4@PAGEOFF]
	str	q0, [sp, #112]                  ; 16-byte Spill
Lloh10:
	adrp	x8, lCPI1_5@PAGE
Lloh11:
	ldr	q0, [x8, lCPI1_5@PAGEOFF]
	str	q0, [sp, #96]                   ; 16-byte Spill
Lloh12:
	adrp	x8, lCPI1_6@PAGE
Lloh13:
	ldr	q15, [x8, lCPI1_6@PAGEOFF]
	mvni.4s	v0, #127, msl #16
	fneg.4s	v1, v0
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q1, [sp, #272]              ; 32-byte Folded Spill
	add	x25, sp, #960
	ldp	w28, w8, [x2, #8]
	str	x8, [sp, #216]                  ; 8-byte Spill
	add	x24, sp, #672
	str	w3, [sp, #212]                  ; 4-byte Spill
	str	w23, [sp, #20]                  ; 4-byte Spill
	str	q15, [sp, #240]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w19, [sp, #212]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w27, #1
	cmp	w8, w23
	cset	w8, eq
	csinc	w27, wzr, w27, eq
	cinc	w9, w26, eq
	ldr	w10, [sp, #228]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w26, wzr, w9, ne
	add	w28, w28, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_208
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_67 Depth 2
                                        ;     Child Loop BB1_101 Depth 2
                                        ;     Child Loop BB1_135 Depth 2
                                        ;     Child Loop BB1_17 Depth 2
	ubfiz	x8, x27, #5, #32
	ldr	x12, [sp, #216]                 ; 8-byte Reload
	cmp	x8, x12
	csel	x9, x8, xzr, ls
	subs	x10, x12, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x12, x9
	stp	w27, w26, [x20]
	str	w28, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x12, #2, hi
	csel	x21, x10, xzr, ls
	cmp	x21, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x21, [sp, #232]                 ; 8-byte Reload
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x19, x21, #3
	cbz	x19, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #232]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #232]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #232]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x23, [sp, #232]                 ; 8-byte Reload
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x23
	ldr	w23, [sp, #20]                  ; 4-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w21, #0x7
	ldr	q15, [sp, #240]                 ; 16-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v18, w8
	ldr	q0, [sp, #160]                  ; 16-byte Reload
	cmhi.4s	v19, v18, v0
	ldr	q0, [sp, #256]                  ; 16-byte Reload
	cmhi.4s	v31, v18, v0
	uzp1.8h	v26, v31, v19
	umaxv.8h	h0, v26
	fmov	w8, s0
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #232]                  ; 8-byte Reload
	ldr	x10, [x8]
	ldr	x9, [x8, #16]
	ldr	x8, [x8, #48]
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v19, #0
	sshll2.2d	v10, v31, #0
	sshll2.2d	v29, v19, #0
	ldp	q2, q3, [sp, #128]              ; 32-byte Folded Reload
	and.16b	v20, v29, v3
	and.16b	v22, v10, v2
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	and.16b	v21, v1, v2
	ldr	q1, [sp, #96]                   ; 16-byte Reload
	and.16b	v27, v0, v1
	ubfiz	w11, w27, #2, #27
	orr	w11, w11, w19
	dup.4s	v0, w11
	and.16b	v1, v31, v0
	and.16b	v0, v19, v0
	ushll2.2d	v23, v0, #0
	ushll2.2d	v25, v1, #0
	ushll.2d	v24, v0, #0
	ushll.2d	v28, v1, #0
	subs	x11, x10, x8
	cset	w12, hs
	lsr	x11, x11, #2
	cmp	x11, #1104
	csel	w11, wzr, w12, ls
	subs	x12, x8, x10
	cset	w13, hs
	lsr	x12, x12, #2
	cmp	x12, #1104
	csel	w12, wzr, w13, ls
	orr	w13, w11, w12
	subs	x11, x9, x8
	cset	w12, hs
	lsr	x11, x11, #2
	cmp	x11, #1104
	csel	w11, wzr, w12, ls
	subs	x12, x8, x9
	cset	w14, hs
	lsr	x12, x12, #2
	cmp	x12, #1104
	csel	w12, wzr, w14, ls
	fmov	x14, d28
	add	x14, x14, x14, lsl #6
	lsl	x14, x14, #2
	mov	w15, #-1026555904               ; =0xc2d00000
	dup.4s	v1, w15
	mov	w15, #1120403456                ; =0x42c80000
	dup.4s	v0, w15
	mov	w15, #43579                     ; =0xaa3b
	movk	w15, #16312, lsl #16
	dup.4s	v17, w15
	mov	w15, #29184                     ; =0x7200
	movk	w15, #48945, lsl #16
	dup.4s	v16, w15
	mov	w15, #48782                     ; =0xbe8e
	movk	w15, #46527, lsl #16
	dup.4s	v7, w15
	mov	w15, #11226                     ; =0x2bda
	movk	w15, #14672, lsl #16
	dup.4s	v6, w15
	mov	w15, #38601                     ; =0x96c9
	movk	w15, #15030, lsl #16
	dup.4s	v5, w15
	mov	w15, #34982                     ; =0x88a6
	movk	w15, #15368, lsl #16
	dup.4s	v4, w15
	mov	w15, #43642                     ; =0xaa7a
	movk	w15, #15658, lsl #16
	dup.4s	v3, w15
	mov	w15, #43691                     ; =0xaaab
	movk	w15, #15914, lsl #16
	dup.4s	v2, w15
	xtn.2s	v23, v23
	str	d23, [sp, #192]                 ; 8-byte Spill
	xtn.2s	v24, v24
	xtn.2s	v25, v25
	cmp	w13, #1
	b.ne	LBB1_65
; %bb.14:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w11, w11, w12
	cbz	w11, LBB1_65
; %bb.15:                               ; %direct.true20.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	add	x12, x8, x14
	add	x13, x9, x14
	add	x14, x10, x14
	and.16b	v26, v26, v15
	addv.8h	h26, v26
	fmov	w15, s26
	b	LBB1_17
LBB1_16:                                ; %else71
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x11, x11, #32
	cmp	x11, #256
	b.eq	LBB1_163
LBB1_17:                                ; %direct.true20.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x16, x14, x11
	movi.2d	v29, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbz	w15, #0, LBB1_25
; %bb.18:                               ; %cond.load
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldr	s29, [x16]
	and	w17, w15, #0xff
	tbnz	w17, #1, LBB1_26
LBB1_19:                                ; %else11
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #2, LBB1_27
LBB1_20:                                ; %cond.load13
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #8
	ld1.s	{ v29 }[2], [x0]
	tbnz	w17, #3, LBB1_28
LBB1_21:                                ; %else17
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #4, LBB1_29
LBB1_22:                                ; %cond.load19
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #16
	ld1.s	{ v26 }[0], [x0]
	tbnz	w17, #5, LBB1_30
LBB1_23:                                ; %else23
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #6, LBB1_31
LBB1_24:                                ; %cond.load25
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #24
	ld1.s	{ v26 }[2], [x0]
	tbnz	w17, #7, LBB1_32
	b	LBB1_33
LBB1_25:                                ; %else
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w17, w15, #0xff
	tbz	w17, #1, LBB1_19
LBB1_26:                                ; %cond.load10
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #4
	ld1.s	{ v29 }[1], [x0]
	tbnz	w17, #2, LBB1_20
LBB1_27:                                ; %else14
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #3, LBB1_21
LBB1_28:                                ; %cond.load16
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #12
	ld1.s	{ v29 }[3], [x0]
	tbnz	w17, #4, LBB1_22
LBB1_29:                                ; %else20
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #5, LBB1_23
LBB1_30:                                ; %cond.load22
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #20
	ld1.s	{ v26 }[1], [x0]
	tbnz	w17, #6, LBB1_24
LBB1_31:                                ; %else26
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #7, LBB1_33
LBB1_32:                                ; %cond.load28
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x16, x16, #28
	ld1.s	{ v26 }[3], [x16]
LBB1_33:                                ; %else29
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldr	q30, [sp, #256]                 ; 16-byte Reload
	cmhi.4s	v12, v18, v30
	uzp1.8h	v30, v12, v19
	and.16b	v31, v30, v15
	addv.8h	h10, v31
	fmov	w17, s10
	add	x16, x13, x11
	movi.2d	v11, #0000000000000000
	movi.2d	v31, #0000000000000000
	tbz	w17, #0, LBB1_41
; %bb.34:                               ; %cond.load32
                                        ;   in Loop: Header=BB1_17 Depth=2
	ldr	s11, [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_42
LBB1_35:                                ; %else36
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #2, LBB1_43
LBB1_36:                                ; %cond.load38
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #8
	ld1.s	{ v11 }[2], [x0]
	tbnz	w17, #3, LBB1_44
LBB1_37:                                ; %else42
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #4, LBB1_45
LBB1_38:                                ; %cond.load44
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #16
	ld1.s	{ v31 }[0], [x0]
	tbnz	w17, #5, LBB1_46
LBB1_39:                                ; %else48
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #6, LBB1_47
LBB1_40:                                ; %cond.load50
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #24
	ld1.s	{ v31 }[2], [x0]
	tbnz	w17, #7, LBB1_48
	b	LBB1_49
LBB1_41:                                ; %else33
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_35
LBB1_42:                                ; %cond.load35
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #4
	ld1.s	{ v11 }[1], [x0]
	tbnz	w17, #2, LBB1_36
LBB1_43:                                ; %else39
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #3, LBB1_37
LBB1_44:                                ; %cond.load41
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #12
	ld1.s	{ v11 }[3], [x0]
	tbnz	w17, #4, LBB1_38
LBB1_45:                                ; %else45
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #5, LBB1_39
LBB1_46:                                ; %cond.load47
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #20
	ld1.s	{ v31 }[1], [x0]
	tbnz	w17, #6, LBB1_40
LBB1_47:                                ; %else51
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #7, LBB1_49
LBB1_48:                                ; %cond.load53
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x16, x16, #28
	ld1.s	{ v31 }[3], [x16]
LBB1_49:                                ; %else54
                                        ;   in Loop: Header=BB1_17 Depth=2
	fneg.4s	v8, v29
	and.16b	v8, v12, v8
	fcmge.4s	v9, v8, v1
	fcmge.4s	v12, v0, v8
	and.16b	v9, v9, v12
	and.16b	v9, v9, v8
	fmul.4s	v12, v9, v17
	movi.4s	v13, #75, lsl #24
	mvni.4s	v14, #128, lsl #24
	bif.16b	v13, v12, v14
	fadd.4s	v12, v12, v13
	fsub.4s	v12, v12, v13
	fcvtzs.4s	v12, v12
	scvtf.4s	v13, v12
	fmul.4s	v14, v13, v16
	fadd.4s	v9, v9, v14
	fmul.4s	v13, v13, v7
	fadd.4s	v9, v9, v13
	fmul.4s	v13, v9, v6
	fadd.4s	v13, v13, v5
	fmul.4s	v13, v9, v13
	fadd.4s	v13, v13, v4
	fmul.4s	v13, v9, v13
	fadd.4s	v13, v13, v3
	fmul.4s	v13, v9, v13
	fadd.4s	v13, v13, v2
	fmul.4s	v13, v9, v13
	movi.4s	v14, #63, lsl #24
	fadd.4s	v13, v13, v14
	fmul.4s	v14, v9, v9
	fmul.4s	v13, v14, v13
	fadd.4s	v9, v9, v13
	fmov.4s	v23, #1.00000000
	fadd.4s	v9, v9, v23
	sshr.4s	v13, v12, #1
	shl.4s	v14, v13, #23
	add.4s	v14, v14, v23
	fmul.4s	v9, v9, v14
	sub.4s	v12, v12, v13
	shl.4s	v12, v12, #23
	add.4s	v12, v12, v23
	fmul.4s	v9, v9, v12
	fcmgt.4s	v12, v1, v8
	fcmgt.4s	v13, v8, v0
	fcmeq.4s	v8, v8, v8
	fadd.4s	v9, v9, v23
	bit.16b	v9, v23, v12
	ldr	q23, [sp, #288]                 ; 16-byte Reload
	bit.16b	v9, v23, v13
	ldr	q23, [sp, #272]                 ; 16-byte Reload
	bsl.16b	v8, v9, v23
	fdiv.4s	v29, v29, v8
	fmov	w17, s10
	fmul.4s	v29, v11, v29
	add	x16, x12, x11
	tbz	w17, #0, LBB1_53
; %bb.50:                               ; %cond.store
                                        ;   in Loop: Header=BB1_17 Depth=2
	str	s29, [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_54
LBB1_51:                                ; %else59
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #2, LBB1_55
LBB1_52:                                ; %cond.store60
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #8
	st1.s	{ v29 }[2], [x0]
	tbnz	w17, #3, LBB1_56
	b	LBB1_57
LBB1_53:                                ; %else57
                                        ;   in Loop: Header=BB1_17 Depth=2
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_51
LBB1_54:                                ; %cond.store58
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #4
	st1.s	{ v29 }[1], [x0]
	tbnz	w17, #2, LBB1_52
LBB1_55:                                ; %else61
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #3, LBB1_57
LBB1_56:                                ; %cond.store62
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #12
	st1.s	{ v29 }[3], [x0]
LBB1_57:                                ; %else63
                                        ;   in Loop: Header=BB1_17 Depth=2
	fneg.4s	v29, v26
	and.16b	v29, v19, v29
	fcmge.4s	v8, v29, v1
	fcmge.4s	v9, v0, v29
	and.16b	v8, v8, v9
	and.16b	v8, v8, v29
	fmul.4s	v9, v8, v17
	movi.4s	v10, #75, lsl #24
	mvni.4s	v11, #128, lsl #24
	bif.16b	v10, v9, v11
	fadd.4s	v9, v9, v10
	fsub.4s	v9, v9, v10
	fcvtzs.4s	v9, v9
	scvtf.4s	v10, v9
	fmul.4s	v11, v10, v16
	fadd.4s	v8, v8, v11
	fmul.4s	v10, v10, v7
	fadd.4s	v8, v8, v10
	fmul.4s	v10, v8, v6
	fadd.4s	v10, v10, v5
	fmul.4s	v10, v8, v10
	fadd.4s	v10, v10, v4
	fmul.4s	v10, v8, v10
	fadd.4s	v10, v10, v3
	fmul.4s	v10, v8, v10
	fadd.4s	v10, v10, v2
	fmul.4s	v10, v8, v10
	movi.4s	v11, #63, lsl #24
	fadd.4s	v10, v10, v11
	fmul.4s	v11, v8, v8
	fmul.4s	v10, v11, v10
	fadd.4s	v8, v8, v10
	fmov.4s	v23, #1.00000000
	fadd.4s	v8, v8, v23
	sshr.4s	v10, v9, #1
	shl.4s	v11, v10, #23
	add.4s	v11, v11, v23
	fmul.4s	v8, v8, v11
	sub.4s	v9, v9, v10
	shl.4s	v9, v9, #23
	add.4s	v9, v9, v23
	fmul.4s	v8, v8, v9
	fcmgt.4s	v9, v1, v29
	fcmgt.4s	v10, v29, v0
	fcmeq.4s	v29, v29, v29
	fadd.4s	v8, v8, v23
	bit.16b	v8, v23, v9
	ldr	q23, [sp, #288]                 ; 16-byte Reload
	bit.16b	v8, v23, v10
	ldr	q23, [sp, #272]                 ; 16-byte Reload
	bsl.16b	v29, v8, v23
	fdiv.4s	v26, v26, v29
	fmul.4s	v26, v31, v26
	tbz	w17, #4, LBB1_61
; %bb.58:                               ; %cond.store64
                                        ;   in Loop: Header=BB1_17 Depth=2
	str	s26, [x16, #16]
	tbnz	w17, #5, LBB1_62
LBB1_59:                                ; %else67
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #6, LBB1_63
LBB1_60:                                ; %cond.store68
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #24
	st1.s	{ v26 }[2], [x0]
	tbz	w17, #7, LBB1_16
	b	LBB1_64
LBB1_61:                                ; %else65
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #5, LBB1_59
LBB1_62:                                ; %cond.store66
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x0, x16, #20
	st1.s	{ v26 }[1], [x0]
	tbnz	w17, #6, LBB1_60
LBB1_63:                                ; %else69
                                        ;   in Loop: Header=BB1_17 Depth=2
	tbz	w17, #7, LBB1_16
LBB1_64:                                ; %cond.store70
                                        ;   in Loop: Header=BB1_17 Depth=2
	add	x16, x16, #28
	st1.s	{ v26 }[3], [x16]
	b	LBB1_16
LBB1_65:                                ; %direct.schedule.8.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	add	x12, x10, x14
	b	LBB1_67
LBB1_66:                                ; %else162
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x13, x25, x11
	stp	q11, q8, [x13]
	add	x11, x11, #32
	cmp	x11, #256
	b.eq	LBB1_83
LBB1_67:                                ; %direct.true40.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and.16b	v30, v26, v15
	addv.8h	h30, v30
	fmov	w14, s30
	add	x13, x12, x11
	add	x15, x25, x11
	ldr	q11, [x15]
	tbz	w14, #0, LBB1_75
; %bb.68:                               ; %cond.load140
                                        ;   in Loop: Header=BB1_67 Depth=2
	ld1.s	{ v11 }[0], [x13]
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_76
LBB1_69:                                ; %else144
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #2, LBB1_77
LBB1_70:                                ; %cond.load146
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #8
	ld1.s	{ v11 }[2], [x16]
	tbnz	w14, #3, LBB1_78
LBB1_71:                                ; %else150
                                        ;   in Loop: Header=BB1_67 Depth=2
	ldr	q8, [x15, #16]
	tbz	w14, #4, LBB1_79
LBB1_72:                                ; %cond.load152
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #16
	ld1.s	{ v8 }[0], [x15]
	tbnz	w14, #5, LBB1_80
LBB1_73:                                ; %else156
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #6, LBB1_81
LBB1_74:                                ; %cond.load158
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #24
	ld1.s	{ v8 }[2], [x15]
	tbz	w14, #7, LBB1_66
	b	LBB1_82
LBB1_75:                                ; %else141
                                        ;   in Loop: Header=BB1_67 Depth=2
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_69
LBB1_76:                                ; %cond.load143
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #4
	ld1.s	{ v11 }[1], [x16]
	tbnz	w14, #2, LBB1_70
LBB1_77:                                ; %else147
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #3, LBB1_71
LBB1_78:                                ; %cond.load149
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x16, x13, #12
	ld1.s	{ v11 }[3], [x16]
	ldr	q8, [x15, #16]
	tbnz	w14, #4, LBB1_72
LBB1_79:                                ; %else153
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #5, LBB1_73
LBB1_80:                                ; %cond.load155
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x15, x13, #20
	ld1.s	{ v8 }[1], [x15]
	tbnz	w14, #6, LBB1_74
LBB1_81:                                ; %else159
                                        ;   in Loop: Header=BB1_67 Depth=2
	tbz	w14, #7, LBB1_66
LBB1_82:                                ; %cond.load161
                                        ;   in Loop: Header=BB1_67 Depth=2
	add	x13, x13, #28
	ld1.s	{ v8 }[3], [x13]
	b	LBB1_66
LBB1_83:                                ; %direct.false41.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v8, v26
	sshll.2d	v9, v19, #0
	sshll.2d	v13, v31, #0
	movi.8b	v23, #1
	and.8b	v26, v8, v23
	umov.b	w13, v26[0]
	movi.2d	v23, #0000000000000000
	mov.b	v23[0], v8[0]
	str	q23, [sp, #176]                 ; 16-byte Spill
	umaxv.8b	b11, v23
	fmov	w15, s11
	rbit	w11, w13
	clz	w11, w11
	tst	w15, #0x1
	mov	w12, #64                        ; =0x40
	dup.2d	v12, x12
	fmov	x12, d28
	add	x12, x12, x12, lsl #6
	fmov	d11, x12
	mov.d	x12, v28[1]
	add	x12, x12, x12, lsl #6
	mov.d	v11[1], x12
	csel	w11, w11, wzr, ne
	add.2d	v27, v11, v27
	add.2d	v23, v27, v12
	movi.2d	v28, #0000000000000000
	mov.b	v28[0], v8[0]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	str	q23, [sp, #80]                  ; 16-byte Spill
	and.16b	v28, v28, v23
	movi.2d	v23, #0000000000000000
	stp	q23, q23, [sp, #560]
	stp	q28, q23, [sp, #528]
	ubfiz	x16, x11, #3, #3
	add	x12, sp, #528
	ldr	x12, [x12, x16]
	sub	x12, x12, x11
	lsl	x12, x12, #2
	add	x14, x10, x12
Lloh14:
	adrp	x10, lCPI1_7@PAGE
Lloh15:
	ldr	q28, [x10, lCPI1_7@PAGEOFF]
	mov	w10, #256                       ; =0x100
	dup.2d	v8, x10
	bif.16b	v28, v8, v13
Lloh16:
	adrp	x10, lCPI1_8@PAGE
Lloh17:
	ldr	q13, [x10, lCPI1_8@PAGEOFF]
	bsl.16b	v9, v13, v8
Lloh18:
	adrp	x10, lCPI1_9@PAGE
Lloh19:
	ldr	q13, [x10, lCPI1_9@PAGEOFF]
	bsl.16b	v10, v13, v8
Lloh20:
	adrp	x10, lCPI1_10@PAGE
Lloh21:
	ldr	q13, [x10, lCPI1_10@PAGEOFF]
	bsl.16b	v29, v13, v8
	stp	q9, q29, [sp, #624]
	stp	q28, q10, [sp, #592]
	add	x10, sp, #592
	ldr	x10, [x10, x16]
	sub	x10, x10, w11, uxtw #2
	tst	w13, #0x1
	csel	x10, xzr, x10, eq
	add	x16, x25, x10
	ldp	q29, q26, [x16]
	tbz	w15, #0, LBB1_91
; %bb.84:                               ; %cond.load165
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v29 }[0], [x14]
	tbnz	w13, #1, LBB1_92
LBB1_85:                                ; %else169
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_93
LBB1_86:                                ; %cond.load171
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #8
	ld1.s	{ v29 }[2], [x15]
	tbnz	w13, #3, LBB1_94
LBB1_87:                                ; %else175
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_95
LBB1_88:                                ; %cond.load177
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #16
	ld1.s	{ v26 }[0], [x15]
	tbnz	w13, #5, LBB1_96
LBB1_89:                                ; %else181
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_97
LBB1_90:                                ; %cond.load183
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #24
	ld1.s	{ v26 }[2], [x15]
	tbnz	w13, #7, LBB1_98
	b	LBB1_99
LBB1_91:                                ; %else166
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #1, LBB1_85
LBB1_92:                                ; %cond.load168
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #4
	ld1.s	{ v29 }[1], [x15]
	tbnz	w13, #2, LBB1_86
LBB1_93:                                ; %else172
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_87
LBB1_94:                                ; %cond.load174
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #12
	ld1.s	{ v29 }[3], [x15]
	tbnz	w13, #4, LBB1_88
LBB1_95:                                ; %else178
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #5, LBB1_89
LBB1_96:                                ; %cond.load180
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #20
	ld1.s	{ v26 }[1], [x15]
	tbnz	w13, #6, LBB1_90
LBB1_97:                                ; %else184
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_99
LBB1_98:                                ; %cond.load186
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x14, #28
	ld1.s	{ v26 }[3], [x13]
LBB1_99:                                ; %else187
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x15, #0                         ; =0x0
	movi.2s	v23, #65
	umlal.2d	v22, v25, v23
	add.2d	v22, v22, v12
	umlal.2d	v21, v24, v23
	add.2d	v21, v21, v12
	stp	q21, q22, [sp, #48]             ; 32-byte Folded Spill
	ldr	d21, [sp, #192]                 ; 8-byte Reload
	umlal.2d	v20, v21, v23
	add.2d	v20, v20, v12
	str	q20, [sp, #32]                  ; 16-byte Spill
	add	x13, x25, x10
	str	q26, [sp, #192]                 ; 16-byte Spill
	stp	q29, q26, [x13]
	fmov	x13, d11
	mov	w14, #1                         ; =0x1
	dup.2d	v22, x14
	lsl	x13, x13, #2
	add	x14, x9, x13
	ushll2.2d	v23, v19, #0
	and.16b	v23, v23, v22
	ushll2.2d	v24, v31, #0
	and.16b	v24, v24, v22
	ushll.2d	v25, v19, #0
	and.16b	v25, v25, v22
	ushll.2d	v31, v31, #0
	and.16b	v31, v31, v22
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	b	LBB1_101
LBB1_100:                               ; %else212
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x15, x24, x15
	stp	q14, q15, [x15]
	add.2d	v11, v11, v24
	add.2d	v12, v12, v25
	add.2d	v13, v13, v23
	add.2d	v10, v10, v31
	fmov	x15, d10
	cmp	x15, #8
	b.ge	LBB1_117
LBB1_101:                               ; %direct.true62.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w17, s30
	lsl	x15, x15, #5
	add	x16, x14, x15
	add	x0, x24, x15
	ldp	q14, q15, [x0]
	tbz	w17, #0, LBB1_109
; %bb.102:                              ; %cond.load190
                                        ;   in Loop: Header=BB1_101 Depth=2
	ld1.s	{ v14 }[0], [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_110
LBB1_103:                               ; %else194
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #2, LBB1_111
LBB1_104:                               ; %cond.load196
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #8
	ld1.s	{ v14 }[2], [x0]
	tbnz	w17, #3, LBB1_112
LBB1_105:                               ; %else200
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #4, LBB1_113
LBB1_106:                               ; %cond.load202
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #16
	ld1.s	{ v15 }[0], [x0]
	tbnz	w17, #5, LBB1_114
LBB1_107:                               ; %else206
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #6, LBB1_115
LBB1_108:                               ; %cond.load208
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #24
	ld1.s	{ v15 }[2], [x0]
	tbz	w17, #7, LBB1_100
	b	LBB1_116
LBB1_109:                               ; %else191
                                        ;   in Loop: Header=BB1_101 Depth=2
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_103
LBB1_110:                               ; %cond.load193
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #4
	ld1.s	{ v14 }[1], [x0]
	tbnz	w17, #2, LBB1_104
LBB1_111:                               ; %else197
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #3, LBB1_105
LBB1_112:                               ; %cond.load199
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #12
	ld1.s	{ v14 }[3], [x0]
	tbnz	w17, #4, LBB1_106
LBB1_113:                               ; %else203
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #5, LBB1_107
LBB1_114:                               ; %cond.load205
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x0, x16, #20
	ld1.s	{ v15 }[1], [x0]
	tbnz	w17, #6, LBB1_108
LBB1_115:                               ; %else209
                                        ;   in Loop: Header=BB1_101 Depth=2
	tbz	w17, #7, LBB1_100
LBB1_116:                               ; %cond.load211
                                        ;   in Loop: Header=BB1_101 Depth=2
	add	x16, x16, #28
	ld1.s	{ v15 }[3], [x16]
	b	LBB1_100
LBB1_117:                               ; %direct.false63.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, x12
	add	x12, x24, x10
	ldp	q10, q30, [x12]
Lloh22:
	adrp	x12, lCPI1_11@PAGE
Lloh23:
	ldr	d22, [x12, lCPI1_11@PAGEOFF]
	ldr	q20, [sp, #176]                 ; 16-byte Reload
	shl.8b	v8, v20, #7
	cmlt.8b	v8, v8, #0
	and.8b	v22, v8, v22
	addv.8b	b20, v22
	str	d20, [sp, #24]                  ; 8-byte Spill
	fmov	w12, s20
	tbz	w12, #0, LBB1_125
; %bb.118:                              ; %cond.load215
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v10 }[0], [x9]
	tbnz	w12, #1, LBB1_126
LBB1_119:                               ; %else219
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #2, LBB1_127
LBB1_120:                               ; %cond.load221
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #8
	ld1.s	{ v10 }[2], [x14]
	tbnz	w12, #3, LBB1_128
LBB1_121:                               ; %else225
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #4, LBB1_129
LBB1_122:                               ; %cond.load227
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #16
	ld1.s	{ v30 }[0], [x14]
	tbnz	w12, #5, LBB1_130
LBB1_123:                               ; %else231
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #6, LBB1_131
LBB1_124:                               ; %cond.load233
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #24
	ld1.s	{ v30 }[2], [x14]
	tbnz	w12, #7, LBB1_132
	b	LBB1_133
LBB1_125:                               ; %else216
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #1, LBB1_119
LBB1_126:                               ; %cond.load218
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #4
	ld1.s	{ v10 }[1], [x14]
	tbnz	w12, #2, LBB1_120
LBB1_127:                               ; %else222
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #3, LBB1_121
LBB1_128:                               ; %cond.load224
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #12
	ld1.s	{ v10 }[3], [x14]
	tbnz	w12, #4, LBB1_122
LBB1_129:                               ; %else228
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #5, LBB1_123
LBB1_130:                               ; %cond.load230
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x9, #20
	ld1.s	{ v30 }[1], [x14]
	tbnz	w12, #6, LBB1_124
LBB1_131:                               ; %else234
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #7, LBB1_133
LBB1_132:                               ; %cond.load236
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v30 }[3], [x9]
LBB1_133:                               ; %else237
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x14, #0                         ; =0x0
	add	x9, x24, x10
	stp	q10, q30, [x9]
	add	x9, x8, x13
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v15, #0000000000000000
	b	LBB1_135
LBB1_134:                               ; %else255
                                        ;   in Loop: Header=BB1_135 Depth=2
	add.2d	v13, v13, v24
	add.2d	v14, v14, v25
	add.2d	v15, v15, v23
	add.2d	v12, v12, v31
	fmov	x14, d12
	cmp	x14, #8
	b.ge	LBB1_151
LBB1_135:                               ; %direct.true83.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q20, q21, [sp, #240]            ; 32-byte Folded Reload
	cmhi.4s	v22, v18, v21
	uzp1.8h	v8, v22, v19
	and.16b	v8, v8, v20
	addv.8h	h8, v8
	fmov	w12, s8
	lsl	x10, x14, #5
	add	x13, x25, x10
	ldp	q9, q8, [x13]
	and.16b	v9, v22, v9
	fneg.4s	v21, v9
	and.16b	v21, v22, v21
	fcmge.4s	v20, v21, v1
	fcmge.4s	v27, v0, v21
	and.16b	v20, v20, v27
	and.16b	v20, v20, v21
	fmul.4s	v27, v20, v17
	movi.4s	v26, #75, lsl #24
	mvni.4s	v11, #128, lsl #24
	bif.16b	v26, v27, v11
	fadd.4s	v27, v27, v26
	fsub.4s	v26, v27, v26
	fcvtzs.4s	v26, v26
	scvtf.4s	v27, v26
	fmul.4s	v11, v27, v16
	fadd.4s	v20, v20, v11
	fmul.4s	v27, v27, v7
	fadd.4s	v20, v20, v27
	fmul.4s	v27, v20, v6
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v20, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v20, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v20, v27
	fadd.4s	v27, v27, v2
	fmul.4s	v27, v20, v27
	movi.4s	v11, #63, lsl #24
	fadd.4s	v27, v27, v11
	fmul.4s	v11, v20, v20
	fmul.4s	v27, v11, v27
	fadd.4s	v20, v20, v27
	fmov.4s	v28, #1.00000000
	fadd.4s	v20, v20, v28
	sshr.4s	v27, v26, #1
	shl.4s	v11, v27, #23
	add.4s	v11, v11, v28
	fmul.4s	v20, v20, v11
	sub.4s	v26, v26, v27
	shl.4s	v26, v26, #23
	add.4s	v26, v26, v28
	fmul.4s	v20, v20, v26
	fcmgt.4s	v26, v1, v21
	fcmgt.4s	v27, v21, v0
	fcmeq.4s	v21, v21, v21
	fadd.4s	v20, v20, v28
	bit.16b	v20, v28, v26
	ldr	q26, [sp, #288]                 ; 16-byte Reload
	bit.16b	v20, v26, v27
	ldr	q26, [sp, #272]                 ; 16-byte Reload
	bif.16b	v20, v26, v21
	fdiv.4s	v20, v9, v20
	add	x13, x24, x10
	ldp	q21, q9, [x13]
	and.16b	v21, v22, v21
	fmul.4s	v22, v21, v20
	add	x10, x9, x10
	tbz	w12, #0, LBB1_139
; %bb.136:                              ; %cond.store240
                                        ;   in Loop: Header=BB1_135 Depth=2
	str	s22, [x10]
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB1_140
LBB1_137:                               ; %else243
                                        ;   in Loop: Header=BB1_135 Depth=2
	tbz	w12, #2, LBB1_141
LBB1_138:                               ; %cond.store244
                                        ;   in Loop: Header=BB1_135 Depth=2
	add	x13, x10, #8
	st1.s	{ v22 }[2], [x13]
	tbnz	w12, #3, LBB1_142
	b	LBB1_143
LBB1_139:                               ; %else241
                                        ;   in Loop: Header=BB1_135 Depth=2
	and	w12, w12, #0xff
	tbz	w12, #1, LBB1_137
LBB1_140:                               ; %cond.store242
                                        ;   in Loop: Header=BB1_135 Depth=2
	add	x13, x10, #4
	st1.s	{ v22 }[1], [x13]
	tbnz	w12, #2, LBB1_138
LBB1_141:                               ; %else245
                                        ;   in Loop: Header=BB1_135 Depth=2
	tbz	w12, #3, LBB1_143
LBB1_142:                               ; %cond.store246
                                        ;   in Loop: Header=BB1_135 Depth=2
	add	x13, x10, #12
	st1.s	{ v22 }[3], [x13]
LBB1_143:                               ; %else247
                                        ;   in Loop: Header=BB1_135 Depth=2
	and.16b	v20, v19, v8
	fneg.4s	v21, v20
	and.16b	v21, v19, v21
	fcmge.4s	v22, v21, v1
	fcmge.4s	v26, v0, v21
	and.16b	v22, v22, v26
	and.16b	v22, v22, v21
	fmul.4s	v26, v22, v17
	movi.4s	v27, #75, lsl #24
	mvni.4s	v8, #128, lsl #24
	bif.16b	v27, v26, v8
	fadd.4s	v26, v26, v27
	fsub.4s	v26, v26, v27
	fcvtzs.4s	v26, v26
	scvtf.4s	v27, v26
	fmul.4s	v8, v27, v16
	fadd.4s	v22, v22, v8
	fmul.4s	v27, v27, v7
	fadd.4s	v22, v22, v27
	fmul.4s	v27, v22, v6
	fadd.4s	v27, v27, v5
	fmul.4s	v27, v22, v27
	fadd.4s	v27, v27, v4
	fmul.4s	v27, v22, v27
	fadd.4s	v27, v27, v3
	fmul.4s	v27, v22, v27
	fadd.4s	v27, v27, v2
	fmul.4s	v27, v22, v27
	movi.4s	v8, #63, lsl #24
	fadd.4s	v27, v27, v8
	fmul.4s	v8, v22, v22
	fmul.4s	v27, v8, v27
	fadd.4s	v22, v22, v27
	fadd.4s	v22, v22, v28
	sshr.4s	v27, v26, #1
	shl.4s	v8, v27, #23
	add.4s	v8, v8, v28
	fmul.4s	v22, v22, v8
	sub.4s	v26, v26, v27
	shl.4s	v26, v26, #23
	add.4s	v26, v26, v28
	fmul.4s	v22, v22, v26
	fcmgt.4s	v26, v1, v21
	fcmgt.4s	v27, v21, v0
	fcmeq.4s	v21, v21, v21
	fadd.4s	v22, v22, v28
	bit.16b	v22, v28, v26
	ldp	q26, q28, [sp, #272]            ; 32-byte Folded Reload
	bit.16b	v22, v28, v27
	bsl.16b	v21, v22, v26
	fdiv.4s	v20, v20, v21
	and.16b	v21, v19, v9
	fmul.4s	v22, v21, v20
	tbz	w12, #4, LBB1_147
; %bb.144:                              ; %cond.store248
                                        ;   in Loop: Header=BB1_135 Depth=2
	str	s22, [x10, #16]
	tbnz	w12, #5, LBB1_148
LBB1_145:                               ; %else251
                                        ;   in Loop: Header=BB1_135 Depth=2
	tbz	w12, #6, LBB1_149
LBB1_146:                               ; %cond.store252
                                        ;   in Loop: Header=BB1_135 Depth=2
	add	x13, x10, #24
	st1.s	{ v22 }[2], [x13]
	tbz	w12, #7, LBB1_134
	b	LBB1_150
LBB1_147:                               ; %else249
                                        ;   in Loop: Header=BB1_135 Depth=2
	tbz	w12, #5, LBB1_145
LBB1_148:                               ; %cond.store250
                                        ;   in Loop: Header=BB1_135 Depth=2
	add	x13, x10, #20
	st1.s	{ v22 }[1], [x13]
	tbnz	w12, #6, LBB1_146
LBB1_149:                               ; %else253
                                        ;   in Loop: Header=BB1_135 Depth=2
	tbz	w12, #7, LBB1_134
LBB1_150:                               ; %cond.store254
                                        ;   in Loop: Header=BB1_135 Depth=2
	add	x10, x10, #28
	st1.s	{ v22 }[3], [x10]
	b	LBB1_134
LBB1_151:                               ; %direct.false84.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	d18, [sp, #24]                  ; 8-byte Reload
	fmov	w9, s18
	ldr	q18, [sp, #176]                 ; 16-byte Reload
	zip1.8b	v18, v18, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	and.16b	v19, v18, v29
	fneg.4s	v20, v19
	and.16b	v20, v18, v20
	fcmge.4s	v21, v20, v1
	fcmge.4s	v22, v0, v20
	and.16b	v21, v21, v22
	and.16b	v21, v21, v20
	fmul.4s	v22, v21, v17
	movi.4s	v23, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	bif.16b	v23, v22, v24
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v22, v22
	scvtf.4s	v23, v22
	fmul.4s	v24, v23, v16
	fadd.4s	v21, v21, v24
	fmul.4s	v23, v23, v7
	fadd.4s	v21, v21, v23
	fmul.4s	v23, v21, v6
	fadd.4s	v23, v23, v5
	fmul.4s	v23, v21, v23
	fadd.4s	v23, v23, v4
	fmul.4s	v23, v21, v23
	fadd.4s	v23, v23, v3
	fmul.4s	v23, v21, v23
	fadd.4s	v23, v23, v2
	fmul.4s	v23, v21, v23
	movi.4s	v24, #63, lsl #24
	fadd.4s	v23, v23, v24
	fmul.4s	v24, v21, v21
	fmul.4s	v23, v24, v23
	fadd.4s	v21, v21, v23
	fmov.4s	v25, #1.00000000
	fadd.4s	v21, v21, v25
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v25
	fmul.4s	v21, v21, v24
	sub.4s	v22, v22, v23
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v25
	fmul.4s	v21, v21, v22
	fcmgt.4s	v22, v1, v20
	fcmgt.4s	v23, v20, v0
	fcmeq.4s	v20, v20, v20
	fadd.4s	v21, v21, v25
	bit.16b	v21, v25, v22
	ldp	q22, q24, [sp, #272]            ; 32-byte Folded Reload
	bit.16b	v21, v24, v23
	bsl.16b	v20, v21, v22
	fdiv.4s	v19, v19, v20
	and.16b	v18, v18, v10
	fmul.4s	v18, v19, v18
	ldp	q19, q20, [sp, #64]             ; 32-byte Folded Reload
	stp	q20, q19, [sp, #448]
	ldp	q19, q20, [sp, #32]             ; 32-byte Folded Reload
	stp	q20, q19, [sp, #480]
	and	x10, x11, #0x7
	add	x12, sp, #448
	ldr	x10, [x12, x10, lsl #3]
	sub	x10, x10, x11
	add	x8, x8, x10, lsl #2
	tbz	w9, #0, LBB1_155
; %bb.152:                              ; %cond.store257
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s18, [x8]
	ldr	q19, [sp, #192]                 ; 16-byte Reload
	tbnz	w9, #1, LBB1_156
LBB1_153:                               ; %else260
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #2, LBB1_157
LBB1_154:                               ; %cond.store261
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #8
	st1.s	{ v18 }[2], [x10]
	tbnz	w9, #3, LBB1_158
	b	LBB1_159
LBB1_155:                               ; %else258
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q19, [sp, #192]                 ; 16-byte Reload
	tbz	w9, #1, LBB1_153
LBB1_156:                               ; %cond.store259
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #4
	st1.s	{ v18 }[1], [x10]
	tbnz	w9, #2, LBB1_154
LBB1_157:                               ; %else262
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #3, LBB1_159
LBB1_158:                               ; %cond.store263
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #12
	st1.s	{ v18 }[3], [x10]
LBB1_159:                               ; %else264
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q18, [sp, #176]                 ; 16-byte Reload
	zip2.8b	v18, v18, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	and.16b	v19, v18, v19
	fneg.4s	v20, v19
	and.16b	v20, v18, v20
	fcmge.4s	v21, v20, v1
	fcmge.4s	v22, v0, v20
	and.16b	v21, v21, v22
	and.16b	v21, v21, v20
	fmul.4s	v17, v21, v17
	movi.4s	v22, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	bif.16b	v22, v17, v23
	fadd.4s	v17, v17, v22
	fsub.4s	v17, v17, v22
	fcvtzs.4s	v17, v17
	scvtf.4s	v22, v17
	fmul.4s	v16, v22, v16
	fadd.4s	v16, v21, v16
	fmul.4s	v7, v22, v7
	fadd.4s	v7, v16, v7
	fmul.4s	v6, v7, v6
	fadd.4s	v5, v6, v5
	fmul.4s	v5, v7, v5
	fadd.4s	v4, v5, v4
	fmul.4s	v4, v7, v4
	fadd.4s	v3, v4, v3
	fmul.4s	v3, v7, v3
	fadd.4s	v2, v3, v2
	fmul.4s	v2, v7, v2
	movi.4s	v3, #63, lsl #24
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v7, v7
	fmul.4s	v2, v3, v2
	fadd.4s	v2, v7, v2
	fmov.4s	v5, #1.00000000
	fadd.4s	v2, v2, v5
	sshr.4s	v3, v17, #1
	shl.4s	v4, v3, #23
	add.4s	v4, v4, v5
	fmul.4s	v2, v2, v4
	sub.4s	v3, v17, v3
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v5
	fmul.4s	v2, v2, v3
	fcmgt.4s	v1, v1, v20
	fcmgt.4s	v0, v20, v0
	fcmeq.4s	v3, v20, v20
	fadd.4s	v2, v2, v5
	bsl.16b	v1, v5, v2
	ldr	q2, [sp, #288]                  ; 16-byte Reload
	bsl.16b	v0, v2, v1
	ldr	q1, [sp, #272]                  ; 16-byte Reload
	bif.16b	v0, v1, v3
	fdiv.4s	v0, v19, v0
	and.16b	v1, v18, v30
	fmul.4s	v0, v0, v1
	tbz	w9, #4, LBB1_204
LBB1_160:                               ; %cond.store265
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x8, #16]
	tbnz	w9, #5, LBB1_205
LBB1_161:                               ; %else134
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #6, LBB1_206
LBB1_162:                               ; %cond.store135
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB1_207
	b	LBB1_2
LBB1_163:                               ; %direct.false21.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v19, v30
	movi.8b	v18, #1
	and.8b	v18, v19, v18
	umov.b	w12, v18[0]
	movi.2d	v18, #0000000000000000
	mov.b	v18[0], v19[0]
	umaxv.8b	b26, v18
	fmov	w14, s26
	rbit	w11, w12
	clz	w11, w11
	tst	w14, #0x1
	csel	w11, w11, wzr, ne
	mov	w13, #64                        ; =0x40
	dup.2d	v29, x13
	fmov	x13, d28
	add	x13, x13, x13, lsl #6
	fmov	d26, x13
	mov.d	x13, v28[1]
	add	x13, x13, x13, lsl #6
	mov.d	v26[1], x13
	add.2d	v26, v26, v27
	movi.2d	v27, #0000000000000000
	mov.b	v27[0], v19[0]
	add.2d	v26, v26, v29
	ushll.2d	v19, v27, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	and.16b	v19, v19, v26
	movi.2d	v23, #0000000000000000
	stp	q23, q23, [sp, #400]
	stp	q19, q23, [sp, #368]
	and	x13, x11, #0x7
	add	x15, sp, #368
	ldr	x13, [x15, x13, lsl #3]
	sub	x13, x13, x11
	lsl	x13, x13, #2
	add	x10, x10, x13
	movi.2d	v27, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w14, #0, LBB1_171
; %bb.164:                              ; %cond.load73
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s27, [x10]
	tbnz	w12, #1, LBB1_172
LBB1_165:                               ; %else77
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #2, LBB1_173
LBB1_166:                               ; %cond.load79
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #8
	ld1.s	{ v27 }[2], [x14]
	tbnz	w12, #3, LBB1_174
LBB1_167:                               ; %else83
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #4, LBB1_175
LBB1_168:                               ; %cond.load85
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #16
	ld1.s	{ v19 }[0], [x14]
	tbnz	w12, #5, LBB1_176
LBB1_169:                               ; %else89
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #6, LBB1_177
LBB1_170:                               ; %cond.load91
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #24
	ld1.s	{ v19 }[2], [x14]
	tbnz	w12, #7, LBB1_178
	b	LBB1_179
LBB1_171:                               ; %else74
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #1, LBB1_165
LBB1_172:                               ; %cond.load76
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #4
	ld1.s	{ v27 }[1], [x14]
	tbnz	w12, #2, LBB1_166
LBB1_173:                               ; %else80
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #3, LBB1_167
LBB1_174:                               ; %cond.load82
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #12
	ld1.s	{ v27 }[3], [x14]
	tbnz	w12, #4, LBB1_168
LBB1_175:                               ; %else86
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #5, LBB1_169
LBB1_176:                               ; %cond.load88
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #20
	ld1.s	{ v19 }[1], [x14]
	tbnz	w12, #6, LBB1_170
LBB1_177:                               ; %else92
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w12, #7, LBB1_179
LBB1_178:                               ; %cond.load94
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v19 }[3], [x10]
LBB1_179:                               ; %else95
                                        ;   in Loop: Header=BB1_4 Depth=1
Lloh24:
	adrp	x10, lCPI1_11@PAGE
Lloh25:
	ldr	d28, [x10, lCPI1_11@PAGEOFF]
	shl.8b	v30, v18, #7
	cmlt.8b	v30, v30, #0
	and.8b	v28, v30, v28
	addv.8b	b30, v28
	fmov	w10, s30
	add	x9, x9, x13
	movi.2d	v31, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbz	w10, #0, LBB1_187
; %bb.180:                              ; %cond.load98
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s31, [x9]
	tbnz	w10, #1, LBB1_188
LBB1_181:                               ; %else102
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_189
LBB1_182:                               ; %cond.load104
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #8
	ld1.s	{ v31 }[2], [x12]
	tbnz	w10, #3, LBB1_190
LBB1_183:                               ; %else108
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #4, LBB1_191
LBB1_184:                               ; %cond.load110
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #16
	ld1.s	{ v28 }[0], [x12]
	tbnz	w10, #5, LBB1_192
LBB1_185:                               ; %else114
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_193
LBB1_186:                               ; %cond.load116
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #24
	ld1.s	{ v28 }[2], [x12]
	tbnz	w10, #7, LBB1_194
	b	LBB1_195
LBB1_187:                               ; %else99
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #1, LBB1_181
LBB1_188:                               ; %cond.load101
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #4
	ld1.s	{ v31 }[1], [x12]
	tbnz	w10, #2, LBB1_182
LBB1_189:                               ; %else105
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_183
LBB1_190:                               ; %cond.load107
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #12
	ld1.s	{ v31 }[3], [x12]
	tbnz	w10, #4, LBB1_184
LBB1_191:                               ; %else111
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_185
LBB1_192:                               ; %cond.load113
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x9, #20
	ld1.s	{ v28 }[1], [x12]
	tbnz	w10, #6, LBB1_186
LBB1_193:                               ; %else117
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_195
LBB1_194:                               ; %cond.load119
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v28 }[3], [x9]
LBB1_195:                               ; %else120
                                        ;   in Loop: Header=BB1_4 Depth=1
	movi.2s	v23, #65
	umlal.2d	v22, v25, v23
	add.2d	v22, v22, v29
	umlal.2d	v21, v24, v23
	add.2d	v21, v21, v29
	ldr	d24, [sp, #192]                 ; 8-byte Reload
	umlal.2d	v20, v24, v23
	add.2d	v23, v20, v29
	fneg.4s	v20, v27
	zip1.8b	v24, v18, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	and.16b	v20, v24, v20
	fcmge.4s	v24, v20, v1
	fcmge.4s	v25, v0, v20
	and.16b	v24, v24, v25
	and.16b	v24, v24, v20
	fmul.4s	v25, v24, v17
	movi.4s	v29, #75, lsl #24
	mvni.4s	v8, #128, lsl #24
	bif.16b	v29, v25, v8
	fadd.4s	v25, v25, v29
	fsub.4s	v25, v25, v29
	fcvtzs.4s	v25, v25
	scvtf.4s	v29, v25
	fmul.4s	v8, v29, v16
	fadd.4s	v24, v24, v8
	fmul.4s	v29, v29, v7
	fadd.4s	v24, v24, v29
	fmul.4s	v29, v24, v6
	fadd.4s	v29, v29, v5
	fmul.4s	v29, v24, v29
	fadd.4s	v29, v29, v4
	fmul.4s	v29, v24, v29
	fadd.4s	v29, v29, v3
	fmul.4s	v29, v24, v29
	fadd.4s	v29, v29, v2
	fmul.4s	v29, v24, v29
	movi.4s	v8, #63, lsl #24
	fadd.4s	v29, v29, v8
	fmul.4s	v8, v24, v24
	fmul.4s	v29, v8, v29
	fadd.4s	v24, v24, v29
	fmov.4s	v9, #1.00000000
	fadd.4s	v24, v24, v9
	sshr.4s	v29, v25, #1
	shl.4s	v8, v29, #23
	add.4s	v8, v8, v9
	fmul.4s	v24, v24, v8
	sub.4s	v25, v25, v29
	shl.4s	v25, v25, #23
	add.4s	v25, v25, v9
	fmul.4s	v24, v24, v25
	fcmgt.4s	v25, v1, v20
	fcmgt.4s	v29, v20, v0
	fcmeq.4s	v20, v20, v20
	fadd.4s	v24, v24, v9
	bit.16b	v24, v9, v25
	ldr	q25, [sp, #288]                 ; 16-byte Reload
	bit.16b	v24, v25, v29
	ldr	q25, [sp, #272]                 ; 16-byte Reload
	bsl.16b	v20, v24, v25
	fdiv.4s	v20, v27, v20
	fmul.4s	v20, v31, v20
	stp	q26, q22, [sp, #304]
	stp	q21, q23, [sp, #336]
	and	x9, x11, #0x7
	add	x10, sp, #304
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x11
	add	x8, x8, x9, lsl #2
	fmov	w9, s30
	tbz	w9, #0, LBB1_199
; %bb.196:                              ; %cond.store123
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s20, [x8]
	tbnz	w9, #1, LBB1_200
LBB1_197:                               ; %else126
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #2, LBB1_201
LBB1_198:                               ; %cond.store127
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #8
	st1.s	{ v20 }[2], [x10]
	tbnz	w9, #3, LBB1_202
	b	LBB1_203
LBB1_199:                               ; %else124
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #1, LBB1_197
LBB1_200:                               ; %cond.store125
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #4
	st1.s	{ v20 }[1], [x10]
	tbnz	w9, #2, LBB1_198
LBB1_201:                               ; %else128
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #3, LBB1_203
LBB1_202:                               ; %cond.store129
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #12
	st1.s	{ v20 }[3], [x10]
LBB1_203:                               ; %else130
                                        ;   in Loop: Header=BB1_4 Depth=1
	fneg.4s	v20, v19
	zip2.8b	v18, v18, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	and.16b	v18, v18, v20
	fcmge.4s	v20, v18, v1
	fcmge.4s	v21, v0, v18
	and.16b	v20, v20, v21
	and.16b	v20, v20, v18
	fmul.4s	v17, v20, v17
	movi.4s	v21, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	bif.16b	v21, v17, v22
	fadd.4s	v17, v17, v21
	fsub.4s	v17, v17, v21
	fcvtzs.4s	v17, v17
	scvtf.4s	v21, v17
	fmul.4s	v16, v21, v16
	fadd.4s	v16, v20, v16
	fmul.4s	v7, v21, v7
	fadd.4s	v7, v16, v7
	fmul.4s	v6, v7, v6
	fadd.4s	v5, v6, v5
	fmul.4s	v5, v7, v5
	fadd.4s	v4, v5, v4
	fmul.4s	v4, v7, v4
	fadd.4s	v3, v4, v3
	fmul.4s	v3, v7, v3
	fadd.4s	v2, v3, v2
	fmul.4s	v2, v7, v2
	movi.4s	v3, #63, lsl #24
	fadd.4s	v2, v2, v3
	fmul.4s	v3, v7, v7
	fmul.4s	v2, v3, v2
	fadd.4s	v2, v7, v2
	fmov.4s	v5, #1.00000000
	fadd.4s	v2, v2, v5
	sshr.4s	v3, v17, #1
	shl.4s	v4, v3, #23
	add.4s	v4, v4, v5
	fmul.4s	v2, v2, v4
	sub.4s	v3, v17, v3
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v5
	fmul.4s	v2, v2, v3
	fcmgt.4s	v1, v1, v18
	fcmgt.4s	v0, v18, v0
	fcmeq.4s	v3, v18, v18
	fadd.4s	v2, v2, v5
	bsl.16b	v1, v5, v2
	ldr	q2, [sp, #288]                  ; 16-byte Reload
	bsl.16b	v0, v2, v1
	ldr	q1, [sp, #272]                  ; 16-byte Reload
	bif.16b	v0, v1, v3
	fdiv.4s	v0, v19, v0
	fmul.4s	v0, v28, v0
	tbnz	w9, #4, LBB1_160
LBB1_204:                               ; %else132
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #5, LBB1_161
LBB1_205:                               ; %cond.store267
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbnz	w9, #6, LBB1_162
LBB1_206:                               ; %else136
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #7, LBB1_2
LBB1_207:                               ; %cond.store271
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB1_2
LBB1_208:                               ; %block.batch.exit
	add	sp, sp, #1248
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh24, Lloh25
                                        ; -- End function
.subsections_via_symbols

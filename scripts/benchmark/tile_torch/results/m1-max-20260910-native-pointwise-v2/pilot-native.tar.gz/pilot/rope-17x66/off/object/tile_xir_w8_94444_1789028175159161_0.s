	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_4:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_6:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_7:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_8:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_9:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_10:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_11:
	.quad	14                              ; 0xe
	.quad	15                              ; 0xf
lCPI0_12:
	.quad	10                              ; 0xa
	.quad	11                              ; 0xb
lCPI0_13:
	.quad	12                              ; 0xc
	.quad	13                              ; 0xd
lCPI0_14:
	.quad	8                               ; 0x8
	.quad	9                               ; 0x9
lCPI0_15:
	.quad	32                              ; 0x20
	.quad	0                               ; 0x0
lCPI0_16:
	.quad	22                              ; 0x16
	.quad	23                              ; 0x17
lCPI0_17:
	.quad	18                              ; 0x12
	.quad	19                              ; 0x13
lCPI0_18:
	.quad	20                              ; 0x14
	.quad	21                              ; 0x15
lCPI0_19:
	.quad	16                              ; 0x10
	.quad	17                              ; 0x11
lCPI0_20:
	.quad	64                              ; 0x40
	.quad	0                               ; 0x0
lCPI0_21:
	.quad	30                              ; 0x1e
	.quad	31                              ; 0x1f
lCPI0_22:
	.quad	26                              ; 0x1a
	.quad	27                              ; 0x1b
lCPI0_23:
	.quad	28                              ; 0x1c
	.quad	29                              ; 0x1d
lCPI0_24:
	.quad	24                              ; 0x18
	.quad	25                              ; 0x19
lCPI0_25:
	.quad	96                              ; 0x60
	.quad	0                               ; 0x0
lCPI0_26:
	.quad	32                              ; 0x20
	.quad	33                              ; 0x21
lCPI0_27:
	.quad	152                             ; 0x98
	.quad	156                             ; 0x9c
lCPI0_28:
	.quad	144                             ; 0x90
	.quad	148                             ; 0x94
lCPI0_29:
	.quad	136                             ; 0x88
	.quad	140                             ; 0x8c
lCPI0_30:
	.quad	128                             ; 0x80
	.quad	132                             ; 0x84
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_31:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB0_491
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1744
	mov	w8, #0                          ; =0x0
	mov	w28, #32                        ; =0x20
	ldp	w9, w13, [x2, #44]
	str	w9, [sp, #348]                  ; 4-byte Spill
	ldp	w21, w16, [x2, #4]
	ldr	w6, [x2]
	add	x12, sp, #1104
	b	LBB0_4
LBB0_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	x1, [x0, #48]
	ldr	x4, [x0, #32]
	ldr	x5, [x0, #16]
	ldr	x7, [x0]
	ubfiz	w9, w6, #2, #27
	add	x24, x9, x9, lsl #5
	lsl	x19, x24, #3
	add	x9, x7, x19
	ldp	q0, q1, [x9]
	stp	q1, q0, [sp, #416]              ; 32-byte Folded Spill
	add	x9, x19, #32
	add	x10, x7, x9
	ldp	q9, q23, [x10]
	add	x23, x19, #64
	add	x10, x7, x23
	ldp	q30, q7, [x10]
	add	x22, x19, #96
	add	x10, x7, x22
	ldp	q28, q3, [x10]
	add	x20, x19, #128
	ldr	s2, [x7, x20]
	stp	q3, q2, [sp, #544]              ; 32-byte Folded Spill
	add	x17, x19, #132
	add	x10, x7, x17
	ldp	q2, q3, [x10]
	stp	q3, q2, [sp, #384]              ; 32-byte Folded Spill
	add	x15, x19, #164
	add	x10, x7, x15
	ldp	q10, q26, [x10]
	add	x14, x19, #196
	add	x10, x7, x14
	ldp	q31, q24, [x10]
	add	x11, x19, #228
	add	x10, x7, x11
	ldp	q4, q16, [x10]
	stp	q4, q16, [sp, #496]             ; 32-byte Folded Spill
	add	x10, x19, #260
	ldr	s16, [x7, x10]
	str	q16, [sp, #528]                 ; 16-byte Spill
	lsl	x24, x24, #2
	add	x25, x5, x24
	ldp	q21, q16, [x25]
	add	x25, x24, #32
	add	x26, x5, x25
	ldp	q25, q29, [x26]
	add	x26, x24, #64
	add	x30, x5, x26
	ldp	q20, q27, [x30]
	stp	q20, q25, [sp, #352]            ; 32-byte Folded Spill
	add	x30, x24, #96
	add	x27, x5, x30
	ldp	q8, q22, [x27]
	stp	q21, q22, [sp, #448]            ; 32-byte Folded Spill
	add	x27, x24, #128
	ldr	s22, [x5, x27]
	str	q22, [sp, #480]                 ; 16-byte Spill
	add	x24, x4, x24
	ldp	q13, q15, [x24]
	add	x24, x4, x25
	add	x25, x4, x26
	add	x26, x4, x30
	fmul.4s	v11, v1, v16
	fmul.4s	v12, v0, v21
	fmul.4s	v14, v2, v13
	fsub.4s	v1, v12, v14
	fmul.4s	v12, v3, v15
	fsub.4s	v0, v11, v12
	add	x19, x1, x19
	ldp	q3, q2, [x24]
	ldp	q22, q21, [x25]
	ldp	q12, q14, [x26]
	ldr	s11, [x4, x27]
	stp	q1, q0, [x19]
	fmul.4s	v0, v9, v25
	fmul.4s	v1, v10, v3
	fsub.4s	v0, v0, v1
	fmul.4s	v1, v23, v29
	mov.16b	v25, v23
	fmul.4s	v6, v26, v2
	fsub.4s	v1, v1, v6
	add	x9, x1, x9
	stp	q0, q1, [x9]
	fmul.4s	v0, v30, v20
	fmul.4s	v1, v31, v22
	fsub.4s	v0, v0, v1
	fmul.4s	v1, v7, v27
	mov.16b	v23, v7
	fmul.4s	v6, v24, v21
	fsub.4s	v1, v1, v6
	add	x9, x1, x23
	stp	q0, q1, [x9]
	fmul.4s	v0, v28, v8
	ldp	q20, q5, [sp, #496]             ; 32-byte Folded Reload
	fmul.4s	v1, v20, v12
	fsub.4s	v0, v0, v1
	ldp	q4, q17, [sp, #544]             ; 32-byte Folded Reload
	ldp	q7, q19, [sp, #464]             ; 32-byte Folded Reload
	fmul.4s	v1, v4, v7
	fmul.4s	v6, v5, v14
	fsub.4s	v1, v1, v6
	add	x9, x1, x22
	stp	q0, q1, [x9]
	fmul.4s	v0, v17, v19
	ldr	q18, [sp, #528]                 ; 16-byte Reload
	fmul.4s	v1, v18, v11
	fsub.4s	v0, v0, v1
	str	s0, [x1, x20]
	ldp	q0, q1, [sp, #416]              ; 32-byte Folded Reload
	fmul.4s	v0, v0, v15
	fmul.4s	v1, v1, v13
	ldp	q6, q13, [sp, #384]             ; 32-byte Folded Reload
	fmul.4s	v6, v6, v16
	ldr	q16, [sp, #448]                 ; 16-byte Reload
	fmul.4s	v16, v13, v16
	fadd.4s	v1, v16, v1
	fadd.4s	v0, v6, v0
	add	x9, x1, x17
	stp	q1, q0, [x9]
	fmul.4s	v0, v25, v2
	fmul.4s	v1, v9, v3
	fmul.4s	v2, v26, v29
	ldr	q3, [sp, #368]                  ; 16-byte Reload
	fmul.4s	v3, v10, v3
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x9, x1, x15
	stp	q1, q0, [x9]
	fmul.4s	v0, v23, v21
	fmul.4s	v1, v30, v22
	fmul.4s	v2, v24, v27
	ldr	q3, [sp, #352]                  ; 16-byte Reload
	fmul.4s	v3, v31, v3
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x9, x1, x14
	stp	q1, q0, [x9]
	fmul.4s	v0, v4, v14
	fmul.4s	v1, v28, v12
	fmul.4s	v2, v5, v7
	fmul.4s	v3, v20, v8
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x9, x1, x11
	stp	q1, q0, [x9]
	fmul.4s	v0, v17, v11
	fmul.4s	v1, v18, v19
	fadd.4s	v0, v1, v0
	str	s0, [x1, x10]
	mov	w9, #1                          ; =0x1
	bfi	w9, w6, #2, #27
	add	x19, x9, x9, lsl #5
	lsl	x9, x19, #3
	add	x10, x7, x9
	ldp	q2, q1, [x10]
	stp	q1, q2, [sp, #400]              ; 32-byte Folded Spill
	add	x23, x9, #32
	add	x10, x7, x23
	ldp	q3, q24, [x10]
	str	q3, [sp, #432]                  ; 16-byte Spill
	add	x24, x9, #64
	add	x10, x7, x24
	ldp	q28, q22, [x10]
	add	x22, x9, #96
	add	x10, x7, x22
	ldp	q4, q0, [x10]
	stp	q4, q0, [sp, #528]              ; 32-byte Folded Spill
	add	x20, x9, #128
	ldr	s0, [x7, x20]
	str	q0, [sp, #560]                  ; 16-byte Spill
	add	x17, x9, #132
	add	x10, x7, x17
	ldp	q19, q20, [x10]
	stp	q20, q19, [sp, #352]            ; 32-byte Folded Spill
	add	x15, x9, #164
	add	x10, x7, x15
	ldp	q16, q26, [x10]
	str	q16, [sp, #384]                 ; 16-byte Spill
	add	x14, x9, #196
	add	x10, x7, x14
	ldp	q29, q17, [x10]
	add	x10, x9, #228
	add	x11, x7, x10
	ldp	q4, q0, [x11]
	stp	q4, q0, [sp, #480]              ; 32-byte Folded Spill
	add	x11, x9, #260
	ldr	s0, [x7, x11]
	str	q0, [sp, #512]                  ; 16-byte Spill
	lsl	x19, x19, #2
	add	x25, x5, x19
	ldp	q25, q31, [x25]
	add	x25, x19, #32
	add	x26, x5, x25
	ldp	q21, q27, [x26]
	stp	q25, q21, [sp, #448]            ; 32-byte Folded Spill
	add	x26, x19, #64
	add	x27, x5, x26
	ldp	q30, q23, [x27]
	add	x27, x19, #96
	add	x30, x4, x19
	ldp	q12, q15, [x30]
	add	x30, x5, x27
	add	x19, x19, #128
	add	x25, x4, x25
	ldp	q9, q10, [x25]
	add	x25, x4, x26
	add	x26, x4, x27
	fmul.4s	v0, v1, v31
	fmul.4s	v1, v2, v25
	fmul.4s	v8, v20, v15
	fmul.4s	v11, v19, v12
	fsub.4s	v1, v1, v11
	fsub.4s	v0, v0, v8
	add	x9, x1, x9
	fmul.4s	v2, v3, v21
	fmul.4s	v3, v16, v9
	fsub.4s	v2, v2, v3
	ldp	q11, q14, [x30]
	ldr	s8, [x5, x19]
	ldp	q19, q3, [x25]
	ldp	q21, q20, [x26]
	ldr	s13, [x4, x19]
	stp	q1, q0, [x9]
	fmul.4s	v0, v24, v27
	fmul.4s	v1, v26, v10
	fsub.4s	v0, v0, v1
	fmul.4s	v1, v28, v30
	fmul.4s	v7, v29, v19
	fsub.4s	v1, v1, v7
	fmul.4s	v7, v22, v23
	mov.16b	v25, v23
	fmul.4s	v16, v17, v3
	mov.16b	v23, v17
	fsub.4s	v7, v7, v16
	add	x9, x1, x23
	stp	q2, q0, [x9]
	add	x9, x1, x24
	stp	q1, q7, [x9]
	ldp	q18, q4, [sp, #528]             ; 32-byte Folded Reload
	fmul.4s	v0, v18, v11
	ldp	q17, q5, [sp, #480]             ; 32-byte Folded Reload
	fmul.4s	v1, v17, v21
	fsub.4s	v0, v0, v1
	fmul.4s	v1, v4, v14
	fmul.4s	v2, v5, v20
	fsub.4s	v1, v1, v2
	add	x9, x1, x22
	stp	q0, q1, [x9]
	ldr	q16, [sp, #560]                 ; 16-byte Reload
	fmul.4s	v0, v16, v8
	ldr	q6, [sp, #512]                  ; 16-byte Reload
	fmul.4s	v1, v6, v13
	fsub.4s	v0, v0, v1
	str	s0, [x1, x20]
	ldp	q0, q1, [sp, #400]              ; 32-byte Folded Reload
	fmul.4s	v0, v0, v15
	fmul.4s	v1, v1, v12
	ldr	q2, [sp, #352]                  ; 16-byte Reload
	fmul.4s	v2, v2, v31
	ldr	q7, [sp, #448]                  ; 16-byte Reload
	ldr	q31, [sp, #368]                 ; 16-byte Reload
	fmul.4s	v7, v31, v7
	fadd.4s	v1, v7, v1
	fadd.4s	v0, v2, v0
	add	x9, x1, x17
	stp	q1, q0, [x9]
	fmul.4s	v0, v24, v10
	ldr	q1, [sp, #432]                  ; 16-byte Reload
	fmul.4s	v1, v1, v9
	fmul.4s	v2, v26, v27
	ldr	q7, [sp, #464]                  ; 16-byte Reload
	ldr	q24, [sp, #384]                 ; 16-byte Reload
	fmul.4s	v7, v24, v7
	fadd.4s	v1, v7, v1
	fadd.4s	v0, v2, v0
	add	x9, x1, x15
	stp	q1, q0, [x9]
	fmul.4s	v0, v22, v3
	fmul.4s	v1, v28, v19
	fmul.4s	v2, v23, v25
	fmul.4s	v3, v29, v30
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x9, x1, x14
	stp	q1, q0, [x9]
	fmul.4s	v0, v4, v20
	fmul.4s	v1, v18, v21
	fmul.4s	v2, v5, v14
	fmul.4s	v3, v17, v11
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x9, x1, x10
	stp	q1, q0, [x9]
	fmul.4s	v0, v16, v13
	fmul.4s	v1, v6, v8
	fadd.4s	v0, v1, v0
	str	s0, [x1, x11]
	mov	w9, #2                          ; =0x2
	bfi	w9, w6, #2, #27
	add	x19, x9, x9, lsl #5
	lsl	x22, x19, #3
	add	x9, x7, x22
	ldp	q5, q0, [x9]
	stp	q0, q5, [sp, #544]              ; 32-byte Folded Spill
	add	x20, x22, #32
	add	x9, x7, x20
	ldp	q20, q2, [x9]
	str	q2, [sp, #512]                  ; 16-byte Spill
	add	x10, x22, #64
	add	x9, x7, x10
	ldp	q3, q4, [x9]
	add	x17, x22, #96
	add	x9, x7, x17
	add	x14, x22, #132
	add	x11, x7, x14
	ldp	q6, q7, [x11]
	stp	q7, q6, [sp, #416]              ; 32-byte Folded Spill
	add	x11, x22, #164
	add	x15, x7, x11
	ldp	q18, q19, [x15]
	stp	q19, q18, [sp, #448]            ; 32-byte Folded Spill
	add	x15, x22, #196
	add	x23, x7, x15
	ldp	q16, q17, [x23]
	stp	q17, q16, [sp, #480]            ; 32-byte Folded Spill
	lsl	x23, x19, #2
	add	x19, x5, x23
	ldp	q24, q25, [x19]
	add	x19, x23, #32
	add	x24, x5, x19
	ldp	q22, q23, [x24]
	add	x24, x23, #64
	add	x25, x5, x24
	ldp	q11, q21, [x25]
	str	q11, [sp, #528]                 ; 16-byte Spill
	add	x25, x4, x23
	ldp	q27, q29, [x25]
	add	x19, x4, x19
	add	x24, x4, x24
	fmul.4s	v0, v0, v25
	fmul.4s	v8, v5, v24
	ldp	q30, q31, [x19]
	ldp	q26, q28, [x24]
	fmul.4s	v9, v7, v29
	fmul.4s	v10, v6, v27
	fsub.4s	v7, v8, v10
	fsub.4s	v6, v0, v9
	fmul.4s	v0, v2, v23
	fmul.4s	v8, v20, v22
	fmul.4s	v9, v19, v31
	fmul.4s	v10, v18, v30
	fsub.4s	v5, v8, v10
	fsub.4s	v2, v0, v9
	fmul.4s	v1, v4, v21
	mov.16b	v19, v4
	fmul.4s	v8, v3, v11
	mov.16b	v18, v3
	fmul.4s	v9, v17, v28
	fmul.4s	v10, v16, v26
	fsub.4s	v17, v8, v10
	fsub.4s	v16, v1, v9
	ldp	q8, q9, [x9]
	add	x24, x22, #128
	add	x19, x22, #228
	add	x25, x7, x19
	add	x9, x22, #260
	add	x26, x23, #96
	add	x27, x5, x26
	add	x23, x23, #128
	add	x26, x4, x26
	add	x22, x1, x22
	ldr	s10, [x7, x24]
	ldp	q13, q14, [x25]
	ldr	s11, [x7, x9]
	ldp	q4, q3, [x27]
	ldr	s12, [x5, x23]
	ldp	q1, q0, [x26]
	ldr	s15, [x4, x23]
	stp	q7, q6, [x22]
	add	x20, x1, x20
	stp	q5, q2, [x20]
	fmul.4s	v2, v8, v4
	fmul.4s	v5, v13, v1
	fsub.4s	v2, v2, v5
	fmul.4s	v5, v9, v3
	fmul.4s	v6, v14, v0
	fsub.4s	v5, v5, v6
	fmul.4s	v6, v10, v12
	fmul.4s	v7, v11, v15
	fsub.4s	v6, v6, v7
	add	x10, x1, x10
	stp	q17, q16, [x10]
	add	x10, x1, x17
	stp	q2, q5, [x10]
	str	s6, [x1, x24]
	ldp	q2, q5, [sp, #544]              ; 32-byte Folded Reload
	fmul.4s	v2, v2, v29
	fmul.4s	v5, v5, v27
	ldp	q6, q7, [sp, #416]              ; 32-byte Folded Reload
	fmul.4s	v6, v6, v25
	fmul.4s	v7, v7, v24
	fadd.4s	v5, v7, v5
	fadd.4s	v2, v6, v2
	add	x10, x1, x14
	stp	q5, q2, [x10]
	ldp	q16, q2, [sp, #496]             ; 32-byte Folded Reload
	fmul.4s	v2, v2, v31
	fmul.4s	v5, v20, v30
	ldp	q6, q7, [sp, #448]              ; 32-byte Folded Reload
	fmul.4s	v6, v6, v23
	fmul.4s	v7, v7, v22
	fadd.4s	v5, v7, v5
	fadd.4s	v2, v6, v2
	add	x10, x1, x11
	stp	q5, q2, [x10]
	fmul.4s	v2, v19, v28
	fmul.4s	v5, v18, v26
	ldr	q6, [sp, #480]                  ; 16-byte Reload
	fmul.4s	v6, v6, v21
	ldr	q7, [sp, #528]                  ; 16-byte Reload
	fmul.4s	v7, v16, v7
	fadd.4s	v5, v7, v5
	fadd.4s	v2, v6, v2
	add	x10, x1, x15
	stp	q5, q2, [x10]
	fmul.4s	v0, v9, v0
	fmul.4s	v1, v8, v1
	fmul.4s	v2, v14, v3
	fmul.4s	v3, v13, v4
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v2, v0
	add	x10, x1, x19
	stp	q1, q0, [x10]
	fmul.4s	v0, v10, v15
	fmul.4s	v1, v11, v12
	fadd.4s	v0, v1, v0
	str	s0, [x1, x9]
	mov	w9, #3                          ; =0x3
	bfi	w9, w6, #2, #27
	add	x10, x9, x9, lsl #5
	lsl	x11, x10, #3
	add	x9, x7, x11
	ldp	q3, q22, [x9]
	add	x17, x11, #32
	add	x9, x7, x17
	ldp	q6, q7, [x9]
	stp	q7, q6, [sp, #432]              ; 32-byte Folded Spill
	add	x15, x11, #64
	add	x9, x7, x15
	ldp	q0, q5, [x9]
	stp	q5, q0, [sp, #464]              ; 32-byte Folded Spill
	add	x24, x11, #96
	add	x9, x7, x24
	add	x23, x11, #132
	add	x14, x7, x23
	ldp	q19, q20, [x14]
	stp	q19, q3, [sp, #368]             ; 32-byte Folded Spill
	str	q20, [sp, #352]                 ; 16-byte Spill
	add	x22, x11, #164
	add	x14, x7, x22
	ldp	q18, q21, [x14]
	stp	q21, q18, [sp, #400]            ; 32-byte Folded Spill
	add	x20, x11, #196
	add	x14, x7, x20
	ldp	q16, q17, [x14]
	stp	q17, q16, [sp, #512]            ; 32-byte Folded Spill
	lsl	x10, x10, #2
	add	x14, x5, x10
	ldp	q24, q25, [x14]
	add	x14, x10, #32
	add	x19, x5, x14
	add	x25, x10, #64
	add	x26, x5, x25
	ldp	q27, q23, [x19]
	str	q27, [sp, #496]                 ; 16-byte Spill
	ldp	q29, q31, [x26]
	stp	q31, q29, [sp, #544]            ; 32-byte Folded Spill
	add	x19, x4, x10
	add	x14, x4, x14
	add	x25, x4, x25
	fmul.4s	v1, v22, v25
	ldp	q11, q4, [x19]
	fmul.4s	v2, v3, v24
	fmul.4s	v26, v20, v4
	fmul.4s	v3, v19, v11
	fsub.4s	v20, v2, v3
	fsub.4s	v19, v1, v26
	fmul.4s	v1, v7, v23
	fmul.4s	v2, v6, v27
	ldp	q10, q14, [x14]
	ldp	q27, q30, [x25]
	fmul.4s	v26, v21, v14
	fmul.4s	v28, v18, v10
	fsub.4s	v18, v2, v28
	fsub.4s	v7, v1, v26
	fmul.4s	v1, v5, v31
	fmul.4s	v2, v0, v29
	fmul.4s	v26, v17, v30
	fmul.4s	v28, v16, v27
	fsub.4s	v17, v2, v28
	fsub.4s	v16, v1, v26
	ldp	q26, q28, [x9]
	add	x9, x11, #228
	add	x14, x7, x9
	add	x19, x10, #96
	add	x25, x5, x19
	add	x19, x4, x19
	ldp	q29, q31, [x25]
	fmul.4s	v2, v26, v29
	ldp	q8, q9, [x14]
	ldp	q15, q3, [x19]
	fmul.4s	v12, v8, v15
	fsub.4s	v6, v2, v12
	fmul.4s	v2, v28, v31
	fmul.4s	v12, v9, v3
	fsub.4s	v5, v2, v12
	add	x19, x11, #128
	add	x14, x11, #260
	ldr	s12, [x7, x19]
	add	x10, x10, #128
	ldr	s13, [x7, x14]
	ldr	s2, [x5, x10]
	fmul.4s	v0, v12, v2
	ldr	s1, [x4, x10]
	fmul.4s	v21, v13, v1
	fsub.4s	v0, v0, v21
	fmul.4s	v4, v22, v4
	add	x10, x1, x11
	stp	q20, q19, [x10]
	ldp	q21, q19, [sp, #368]            ; 32-byte Folded Reload
	fmul.4s	v19, v19, v11
	ldr	q20, [sp, #352]                 ; 16-byte Reload
	fmul.4s	v20, v20, v25
	fmul.4s	v21, v21, v24
	add	x10, x1, x17
	stp	q18, q7, [x10]
	fadd.4s	v7, v21, v19
	fadd.4s	v4, v20, v4
	ldp	q20, q18, [sp, #416]            ; 32-byte Folded Reload
	fmul.4s	v18, v18, v14
	add	x10, x1, x15
	stp	q17, q16, [x10]
	ldr	q16, [sp, #448]                 ; 16-byte Reload
	fmul.4s	v16, v16, v10
	ldr	q17, [sp, #400]                 ; 16-byte Reload
	fmul.4s	v17, v17, v23
	ldr	q19, [sp, #496]                 ; 16-byte Reload
	fmul.4s	v19, v20, v19
	add	x10, x1, x24
	stp	q6, q5, [x10]
	fadd.4s	v5, v19, v16
	str	s0, [x1, x19]
	fadd.4s	v0, v17, v18
	ldp	q6, q16, [sp, #464]             ; 32-byte Folded Reload
	fmul.4s	v6, v6, v30
	fmul.4s	v16, v16, v27
	add	x10, x1, x23
	stp	q7, q4, [x10]
	ldp	q17, q4, [sp, #528]             ; 32-byte Folded Reload
	ldr	q7, [sp, #512]                  ; 16-byte Reload
	fmul.4s	v4, v7, v4
	ldr	q7, [sp, #560]                  ; 16-byte Reload
	fmul.4s	v7, v17, v7
	fadd.4s	v7, v7, v16
	add	x10, x1, x22
	stp	q5, q0, [x10]
	fadd.4s	v0, v4, v6
	fmul.4s	v3, v28, v3
	fmul.4s	v4, v26, v15
	add	x10, x1, x20
	stp	q7, q0, [x10]
	fmul.4s	v0, v9, v31
	fmul.4s	v5, v8, v29
	fadd.4s	v4, v5, v4
	fadd.4s	v0, v0, v3
	add	x9, x1, x9
	stp	q4, q0, [x9]
	fmul.4s	v0, v12, v1
	fmul.4s	v1, v13, v2
	fadd.4s	v0, v1, v0
	str	s0, [x1, x14]
LBB0_3:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov	w9, #24                         ; =0x18
	str	w9, [x2, #36]
	add	w9, w6, #1
	ldr	w10, [sp, #348]                 ; 4-byte Reload
	cmp	w9, w10
	cset	w9, eq
	csinc	w6, wzr, w6, eq
	cinc	w10, w21, eq
	cmp	w10, w13
	cset	w11, eq
	ands	w9, w9, w11
	csel	w21, wzr, w10, ne
	add	w16, w16, w9
	add	w8, w8, #1
	cmp	w8, w3
	b.eq	LBB0_490
LBB0_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_7 Depth 2
	ldr	w9, [x2, #12]
	ubfiz	x10, x6, #5, #32
	cmp	x10, x9
	csel	x11, x10, xzr, ls
	subs	x14, x9, x11
	cmp	x14, #32
	csel	x14, x14, x28, lo
	cmp	x9, x11
	stp	w6, w21, [x2]
	str	w16, [x2, #8]
	str	wzr, [x2, #36]
	ccmp	x10, x9, #2, hi
	csel	x4, x14, xzr, ls
	cmp	x4, #32
	b.hs	LBB0_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	lsr	x1, x4, #3
	cbz	x1, LBB0_8
; %bb.6:                                ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	x5, [x0, #48]
	ldr	x7, [x0, #32]
	ldr	x20, [x0, #16]
	lsl	w22, w6, #2
	mov	x23, x1
	ldr	x24, [x0]
LBB0_7:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w9, w22, #0x1fffffff
	add	x19, x9, x9, lsl #5
	lsl	x10, x19, #3
	add	x9, x24, x10
	ldp	q20, q22, [x9]
	add	x14, x10, #32
	add	x9, x24, x14
	ldp	q6, q7, [x9]
	stp	q7, q6, [sp, #384]              ; 32-byte Folded Spill
	add	x11, x10, #64
	add	x9, x24, x11
	ldp	q4, q5, [x9]
	add	x17, x10, #96
	add	x9, x24, x17
	add	x15, x10, #132
	add	x25, x24, x15
	ldp	q19, q3, [x25]
	stp	q3, q19, [sp, #352]             ; 32-byte Folded Spill
	add	x30, x10, #164
	add	x25, x24, x30
	ldp	q16, q17, [x25]
	stp	q17, q16, [sp, #416]            ; 32-byte Folded Spill
	add	x26, x10, #196
	add	x25, x24, x26
	ldp	q18, q21, [x25]
	stp	q18, q4, [sp, #512]             ; 32-byte Folded Spill
	stp	q5, q21, [sp, #480]             ; 32-byte Folded Spill
	lsl	x19, x19, #2
	add	x25, x20, x19
	ldp	q25, q27, [x25]
	add	x25, x19, #32
	add	x27, x20, x25
	ldp	q8, q9, [x27]
	stp	q9, q8, [sp, #448]              ; 32-byte Folded Spill
	add	x27, x19, #64
	add	x28, x20, x27
	ldp	q30, q31, [x28]
	stp	q31, q30, [sp, #544]            ; 32-byte Folded Spill
	add	x28, x7, x19
	ldp	q10, q11, [x28]
	add	x25, x7, x25
	ldp	q28, q29, [x25]
	add	x25, x7, x27
	ldp	q24, q26, [x25]
	fmul.4s	v0, v22, v27
	fmul.4s	v1, v20, v25
	fmul.4s	v2, v3, v11
	fmul.4s	v3, v19, v10
	fsub.4s	v23, v1, v3
	fsub.4s	v19, v0, v2
	fmul.4s	v0, v7, v9
	fmul.4s	v1, v6, v8
	fmul.4s	v2, v17, v29
	fmul.4s	v3, v16, v28
	fsub.4s	v17, v1, v3
	fsub.4s	v16, v0, v2
	fmul.4s	v0, v5, v31
	fmul.4s	v1, v4, v30
	fmul.4s	v2, v21, v26
	fmul.4s	v3, v18, v24
	fsub.4s	v18, v1, v3
	fsub.4s	v7, v0, v2
	ldp	q30, q31, [x9]
	add	x9, x10, #228
	add	x25, x24, x9
	add	x27, x19, #96
	add	x28, x20, x27
	add	x27, x7, x27
	ldp	q8, q9, [x28]
	fmul.4s	v1, v30, v8
	ldp	q12, q13, [x25]
	ldp	q4, q3, [x27]
	fmul.4s	v2, v12, v4
	fsub.4s	v6, v1, v2
	fmul.4s	v1, v31, v9
	fmul.4s	v2, v13, v3
	fsub.4s	v5, v1, v2
	add	x27, x10, #128
	add	x25, x10, #260
	add	x19, x19, #128
	ldr	s14, [x24, x27]
	ldr	s15, [x24, x25]
	ldr	s2, [x20, x19]
	ldr	s1, [x7, x19]
	fmul.4s	v0, v14, v2
	fmul.4s	v21, v15, v1
	fsub.4s	v0, v0, v21
	fmul.4s	v21, v22, v11
	fmul.4s	v10, v20, v10
	add	x10, x5, x10
	stp	q23, q19, [x10]
	ldp	q19, q20, [sp, #352]            ; 32-byte Folded Reload
	fmul.4s	v19, v19, v27
	fmul.4s	v20, v20, v25
	fadd.4s	v20, v20, v10
	add	x10, x5, x14
	stp	q17, q16, [x10]
	fadd.4s	v16, v19, v21
	ldp	q17, q19, [sp, #384]            ; 32-byte Folded Reload
	fmul.4s	v17, v17, v29
	fmul.4s	v19, v19, v28
	add	x10, x5, x11
	stp	q18, q7, [x10]
	ldp	q21, q7, [sp, #432]             ; 32-byte Folded Reload
	ldr	q18, [sp, #416]                 ; 16-byte Reload
	fmul.4s	v7, v18, v7
	ldr	q18, [sp, #464]                 ; 16-byte Reload
	fmul.4s	v18, v21, v18
	fadd.4s	v18, v18, v19
	add	x10, x5, x17
	stp	q6, q5, [x10]
	fadd.4s	v5, v7, v17
	ldp	q6, q17, [sp, #480]             ; 32-byte Folded Reload
	fmul.4s	v6, v6, v26
	str	s0, [x5, x27]
	ldp	q0, q7, [sp, #528]              ; 32-byte Folded Reload
	fmul.4s	v0, v0, v24
	fmul.4s	v7, v17, v7
	ldr	q17, [sp, #560]                 ; 16-byte Reload
	ldr	q19, [sp, #512]                 ; 16-byte Reload
	fmul.4s	v17, v19, v17
	add	x10, x5, x15
	stp	q20, q16, [x10]
	fadd.4s	v0, v17, v0
	fadd.4s	v6, v7, v6
	fmul.4s	v3, v31, v3
	add	x10, x5, x30
	stp	q18, q5, [x10]
	fmul.4s	v4, v30, v4
	fmul.4s	v5, v13, v9
	fmul.4s	v7, v12, v8
	add	x10, x5, x26
	stp	q0, q6, [x10]
	fadd.4s	v0, v7, v4
	fadd.4s	v3, v5, v3
	fmul.4s	v1, v14, v1
	fmul.4s	v2, v15, v2
	fadd.4s	v1, v2, v1
	add	x9, x5, x9
	stp	q0, q3, [x9]
	str	s1, [x5, x25]
	add	w22, w22, #1
	subs	w23, w23, #1
	b.ne	LBB0_7
LBB0_8:                                 ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w9, w4, #0x7
	mov	w28, #32                        ; =0x20
	cbz	w9, LBB0_3
; %bb.9:                                ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	dup.4s	v0, w9
Lloh0:
	adrp	x9, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x9, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x9, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x9, lCPI0_1@PAGEOFF]
	cmhi.4s	v14, v0, v2
	cmhi.4s	v2, v0, v1
	uzp1.8h	v2, v2, v14
	umaxv.8h	h2, v2
	fmov	w9, s2
	tbz	w9, #0, LBB0_3
; %bb.10:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_4 Depth=1
	cmhi.4s	v5, v0, v1
	uzp1.8h	v1, v5, v14
Lloh4:
	adrp	x9, lCPI0_2@PAGE
Lloh5:
	ldr	q0, [x9, lCPI0_2@PAGEOFF]
	and.16b	v0, v1, v0
	addv.8h	h6, v0
	fmov	w10, s6
	ldr	x24, [x0]
	ubfiz	w9, w6, #2, #27
	orr	w9, w9, w1
	dup.4s	v2, w9
	and.16b	v0, v5, v2
	movi.2s	v3, #66
	umull.2d	v16, v0, v3
	fmov	x9, d16
	add	x9, x24, x9, lsl #2
                                        ; implicit-def: $q3
	tbnz	w10, #0, LBB0_16
; %bb.11:                               ; %else
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_17
LBB0_12:                                ; %else4
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_18
LBB0_13:                                ; %else7
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_19
LBB0_14:                                ; %else10
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #4, LBB0_20
LBB0_15:                                ; %cond.load12
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v4 }[0], [x11]
	tbnz	w10, #5, LBB0_21
	b	LBB0_22
LBB0_16:                                ; %cond.load
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s3, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_12
LBB0_17:                                ; %cond.load3
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v3 }[1], [x11]
	tbz	w10, #2, LBB0_13
LBB0_18:                                ; %cond.load6
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v3 }[2], [x11]
	tbz	w10, #3, LBB0_14
LBB0_19:                                ; %cond.load9
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v3 }[3], [x11]
	tbnz	w10, #4, LBB0_15
LBB0_20:                                ;   in Loop: Header=BB0_4 Depth=1
                                        ; implicit-def: $q4
	tbz	w10, #5, LBB0_22
LBB0_21:                                ; %cond.load15
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v4 }[1], [x11]
LBB0_22:                                ; %else16
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_31
; %bb.23:                               ; %else19
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_25
LBB0_24:                                ; %cond.load21
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v4 }[3], [x9]
LBB0_25:                                ; %else22
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	x1, [x0, #48]
	ldr	x20, [x0, #32]
	ldr	x23, [x0, #16]
	fmov	w10, s6
	str	q3, [sp, #1584]
	str	q4, [sp, #1600]
Lloh6:
	adrp	x9, lCPI0_14@PAGE
Lloh7:
	ldr	q17, [x9, lCPI0_14@PAGEOFF]
	add.2d	v3, v16, v17
	str	q3, [sp, #384]                  ; 16-byte Spill
	fmov	x9, d3
	add	x9, x24, x9, lsl #2
                                        ; implicit-def: $q3
	tbnz	w10, #0, LBB0_32
; %bb.26:                               ; %else26
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_33
LBB0_27:                                ; %else29
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_34
LBB0_28:                                ; %else32
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_35
LBB0_29:                                ; %else35
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #4, LBB0_36
LBB0_30:                                ; %cond.load37
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v4 }[0], [x11]
	tbnz	w10, #5, LBB0_37
	b	LBB0_38
LBB0_31:                                ; %cond.load18
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v4 }[2], [x11]
	tbnz	w10, #7, LBB0_24
	b	LBB0_25
LBB0_32:                                ; %cond.load25
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s3, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_27
LBB0_33:                                ; %cond.load28
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v3 }[1], [x11]
	tbz	w10, #2, LBB0_28
LBB0_34:                                ; %cond.load31
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v3 }[2], [x11]
	tbz	w10, #3, LBB0_29
LBB0_35:                                ; %cond.load34
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v3 }[3], [x11]
	tbnz	w10, #4, LBB0_30
LBB0_36:                                ;   in Loop: Header=BB0_4 Depth=1
                                        ; implicit-def: $q4
	tbz	w10, #5, LBB0_38
LBB0_37:                                ; %cond.load40
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v4 }[1], [x11]
LBB0_38:                                ; %else41
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_47
; %bb.39:                               ; %else44
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_41
LBB0_40:                                ; %cond.load46
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v4 }[3], [x9]
LBB0_41:                                ; %else47
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w10, s6
	str	q3, [sp, #1616]
	str	q4, [sp, #1632]
Lloh8:
	adrp	x9, lCPI0_19@PAGE
Lloh9:
	ldr	q3, [x9, lCPI0_19@PAGEOFF]
	add.2d	v4, v16, v3
	str	q4, [sp, #272]                  ; 16-byte Spill
	fmov	x9, d4
	add	x9, x24, x9, lsl #2
                                        ; implicit-def: $q4
	tbnz	w10, #0, LBB0_48
; %bb.42:                               ; %else51
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_49
LBB0_43:                                ; %else54
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_50
LBB0_44:                                ; %else57
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_51
LBB0_45:                                ; %else60
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #4, LBB0_52
LBB0_46:                                ; %cond.load62
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v7 }[0], [x11]
	tbnz	w10, #5, LBB0_53
	b	LBB0_54
LBB0_47:                                ; %cond.load43
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v4 }[2], [x11]
	tbnz	w10, #7, LBB0_40
	b	LBB0_41
LBB0_48:                                ; %cond.load50
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s4, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_43
LBB0_49:                                ; %cond.load53
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v4 }[1], [x11]
	tbz	w10, #2, LBB0_44
LBB0_50:                                ; %cond.load56
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v4 }[2], [x11]
	tbz	w10, #3, LBB0_45
LBB0_51:                                ; %cond.load59
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v4 }[3], [x11]
	tbnz	w10, #4, LBB0_46
LBB0_52:                                ;   in Loop: Header=BB0_4 Depth=1
                                        ; implicit-def: $q7
	tbz	w10, #5, LBB0_54
LBB0_53:                                ; %cond.load65
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v7 }[1], [x11]
LBB0_54:                                ; %else66
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_63
; %bb.55:                               ; %else69
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_57
LBB0_56:                                ; %cond.load71
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v7 }[3], [x9]
LBB0_57:                                ; %else72
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w10, s6
	str	q4, [sp, #1648]
	str	q7, [sp, #1664]
Lloh10:
	adrp	x9, lCPI0_24@PAGE
Lloh11:
	ldr	q18, [x9, lCPI0_24@PAGEOFF]
	add.2d	v4, v16, v18
	str	q4, [sp, #256]                  ; 16-byte Spill
	fmov	x9, d4
	add	x9, x24, x9, lsl #2
                                        ; implicit-def: $q4
	tbnz	w10, #0, LBB0_64
; %bb.58:                               ; %else76
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_65
LBB0_59:                                ; %else79
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_66
LBB0_60:                                ; %else82
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_67
LBB0_61:                                ; %else85
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #4, LBB0_68
LBB0_62:                                ; %cond.load87
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v19 }[0], [x11]
	tbnz	w10, #5, LBB0_69
	b	LBB0_70
LBB0_63:                                ; %cond.load68
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v7 }[2], [x11]
	tbnz	w10, #7, LBB0_56
	b	LBB0_57
LBB0_64:                                ; %cond.load75
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s4, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_59
LBB0_65:                                ; %cond.load78
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v4 }[1], [x11]
	tbz	w10, #2, LBB0_60
LBB0_66:                                ; %cond.load81
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v4 }[2], [x11]
	tbz	w10, #3, LBB0_61
LBB0_67:                                ; %cond.load84
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v4 }[3], [x11]
	tbnz	w10, #4, LBB0_62
LBB0_68:                                ;   in Loop: Header=BB0_4 Depth=1
                                        ; implicit-def: $q19
	tbz	w10, #5, LBB0_70
LBB0_69:                                ; %cond.load90
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v19 }[1], [x11]
LBB0_70:                                ; %else91
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_88
; %bb.71:                               ; %else94
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_73
LBB0_72:                                ; %cond.load96
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v19 }[3], [x9]
LBB0_73:                                ; %else97
                                        ;   in Loop: Header=BB0_4 Depth=1
	xtn.8b	v1, v1
	movi.8b	v7, #1
	and.8b	v7, v1, v7
	umov.b	w5, v7[0]
	movi.2d	v7, #0000000000000000
	mov.b	v7[0], v1[0]
	str	q4, [sp, #1680]
	str	q19, [sp, #1696]
	umaxv.8b	b4, v7
	fmov	w9, s4
	rbit	w10, w5
	clz	w10, w10
	tst	w9, #0x1
	csel	w4, w10, wzr, ne
Lloh12:
	adrp	x10, lCPI0_26@PAGE
Lloh13:
	ldr	q4, [x10, lCPI0_26@PAGEOFF]
	add.2d	v4, v16, v4
	movi.2d	v19, #0000000000000000
	mov.b	v19[0], v1[0]
	ushll.2d	v1, v19, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	and.16b	v1, v1, v4
	movi.2d	v4, #0000000000000000
	stp	q4, q4, [sp, #992]
	stp	q1, q4, [sp, #960]
	ubfiz	x11, x4, #3, #3
	add	x10, sp, #960
	ldr	x10, [x10, x11]
	sub	x10, x10, x4
	add	x10, x24, x10, lsl #2
Lloh14:
	adrp	x14, lCPI0_27@PAGE
Lloh15:
	ldr	q1, [x14, lCPI0_27@PAGEOFF]
Lloh16:
	adrp	x14, lCPI0_28@PAGE
Lloh17:
	ldr	q4, [x14, lCPI0_28@PAGEOFF]
	str	q1, [sp, #1072]
	str	q4, [sp, #1056]
Lloh18:
	adrp	x14, lCPI0_29@PAGE
Lloh19:
	ldr	q1, [x14, lCPI0_29@PAGEOFF]
Lloh20:
	adrp	x14, lCPI0_30@PAGE
Lloh21:
	ldr	q4, [x14, lCPI0_30@PAGEOFF]
	str	q1, [sp, #1040]
	str	q4, [sp, #1024]
	add	x14, sp, #1024
	ldr	x11, [x14, x11]
	ubfiz	x7, x4, #2, #32
	sub	x11, x11, x7
	tst	w5, #0x1
	csel	x22, xzr, x11, eq
	add	x11, sp, #1584
	add	x11, x11, x22
	ldp	q4, q19, [x11]
	tbnz	w9, #0, LBB0_89
; %bb.74:                               ; %else101
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w5, #1, LBB0_90
LBB0_75:                                ; %else104
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w5, #2, LBB0_91
LBB0_76:                                ; %else107
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w5, #3, LBB0_92
LBB0_77:                                ; %else110
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w5, #4, LBB0_93
LBB0_78:                                ; %else113
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w5, #5, LBB0_94
LBB0_79:                                ; %else116
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w5, #6, LBB0_95
LBB0_80:                                ; %else119
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w5, #7, LBB0_82
LBB0_81:                                ; %cond.load121
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x10, #28
	ld1.s	{ v19 }[3], [x9]
LBB0_82:                                ; %else122
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v30, v5, #0
Lloh22:
	adrp	x9, lCPI0_5@PAGE
Lloh23:
	ldr	q15, [x9, lCPI0_5@PAGEOFF]
	and.16b	v1, v30, v15
	and.16b	v24, v30, v16
	fmov	w10, s6
	add	x9, sp, #1584
	add	x9, x9, x22
	stp	q4, q19, [x9]
	mov	w9, #33                         ; =0x21
	dup.2d	v4, x9
	add.2d	v4, v24, v4
	add.2d	v19, v4, v1
	str	q19, [sp, #544]                 ; 16-byte Spill
	fmov	x9, d19
	add	x9, x24, x9, lsl #2
                                        ; implicit-def: $q19
	tbnz	w10, #0, LBB0_96
; %bb.83:                               ; %else126
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_97
LBB0_84:                                ; %else129
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_98
LBB0_85:                                ; %else132
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_99
LBB0_86:                                ; %else135
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #4, LBB0_100
LBB0_87:                                ; %cond.load137
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v20 }[0], [x11]
	tbnz	w10, #5, LBB0_101
	b	LBB0_102
LBB0_88:                                ; %cond.load93
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v19 }[2], [x11]
	tbnz	w10, #7, LBB0_72
	b	LBB0_73
LBB0_89:                                ; %cond.load100
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v4 }[0], [x10]
	tbz	w5, #1, LBB0_75
LBB0_90:                                ; %cond.load103
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x10, #4
	ld1.s	{ v4 }[1], [x9]
	tbz	w5, #2, LBB0_76
LBB0_91:                                ; %cond.load106
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x10, #8
	ld1.s	{ v4 }[2], [x9]
	tbz	w5, #3, LBB0_77
LBB0_92:                                ; %cond.load109
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x10, #12
	ld1.s	{ v4 }[3], [x9]
	tbz	w5, #4, LBB0_78
LBB0_93:                                ; %cond.load112
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x10, #16
	ld1.s	{ v19 }[0], [x9]
	tbz	w5, #5, LBB0_79
LBB0_94:                                ; %cond.load115
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x10, #20
	ld1.s	{ v19 }[1], [x9]
	tbz	w5, #6, LBB0_80
LBB0_95:                                ; %cond.load118
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x10, #24
	ld1.s	{ v19 }[2], [x9]
	tbnz	w5, #7, LBB0_81
	b	LBB0_82
LBB0_96:                                ; %cond.load125
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s19, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_84
LBB0_97:                                ; %cond.load128
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v19 }[1], [x11]
	tbz	w10, #2, LBB0_85
LBB0_98:                                ; %cond.load131
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v19 }[2], [x11]
	tbz	w10, #3, LBB0_86
LBB0_99:                                ; %cond.load134
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v19 }[3], [x11]
	tbnz	w10, #4, LBB0_87
LBB0_100:                               ;   in Loop: Header=BB0_4 Depth=1
                                        ; implicit-def: $q20
	tbz	w10, #5, LBB0_102
LBB0_101:                               ; %cond.load140
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v20 }[1], [x11]
LBB0_102:                               ; %else141
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_111
; %bb.103:                              ; %else144
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_105
LBB0_104:                               ; %cond.load146
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v20 }[3], [x9]
LBB0_105:                               ; %else147
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v8, v5, #0
	and.16b	v17, v8, v17
	fmov	w10, s6
	str	q19, [sp, #1424]
	str	q20, [sp, #1440]
	add.2d	v19, v4, v17
	str	q19, [sp, #528]                 ; 16-byte Spill
	fmov	x9, d19
	add	x9, x24, x9, lsl #2
                                        ; implicit-def: $q19
	tbnz	w10, #0, LBB0_112
; %bb.106:                              ; %else151
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_113
LBB0_107:                               ; %else154
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_114
LBB0_108:                               ; %else157
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_115
LBB0_109:                               ; %else160
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #4, LBB0_116
LBB0_110:                               ; %cond.load162
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v20 }[0], [x11]
	tbnz	w10, #5, LBB0_117
	b	LBB0_118
LBB0_111:                               ; %cond.load143
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v20 }[2], [x11]
	tbnz	w10, #7, LBB0_104
	b	LBB0_105
LBB0_112:                               ; %cond.load150
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	s19, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_107
LBB0_113:                               ; %cond.load153
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v19 }[1], [x11]
	tbz	w10, #2, LBB0_108
LBB0_114:                               ; %cond.load156
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v19 }[2], [x11]
	tbz	w10, #3, LBB0_109
LBB0_115:                               ; %cond.load159
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v19 }[3], [x11]
	tbnz	w10, #4, LBB0_110
LBB0_116:                               ;   in Loop: Header=BB0_4 Depth=1
                                        ; implicit-def: $q20
	tbz	w10, #5, LBB0_118
LBB0_117:                               ; %cond.load165
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v20 }[1], [x11]
LBB0_118:                               ; %else166
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_332
; %bb.119:                              ; %else169
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_121
LBB0_120:                               ; %cond.load171
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v20 }[3], [x9]
LBB0_121:                               ; %else172
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v9, v5, #0
	and.16b	v3, v9, v3
	fmov	w10, s6
	str	q19, [sp, #1456]
	str	q20, [sp, #1472]
	add.2d	v19, v4, v3
	str	q19, [sp, #496]                 ; 16-byte Spill
	fmov	x9, d19
	add	x9, x24, x9, lsl #2
	ldr	q19, [sp, #1504]
	ldr	q20, [sp, #1488]
	tbnz	w10, #0, LBB0_333
; %bb.122:                              ; %else176
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_334
LBB0_123:                               ; %else179
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_335
LBB0_124:                               ; %else182
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_336
LBB0_125:                               ; %else185
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_337
LBB0_126:                               ; %else188
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_338
LBB0_127:                               ; %else191
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_339
LBB0_128:                               ; %else194
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_130
LBB0_129:                               ; %cond.load196
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v19 }[3], [x9]
LBB0_130:                               ; %else197
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v10, v5, #0
	and.16b	v18, v10, v18
	fmov	w10, s6
	str	q20, [sp, #1488]
	str	q19, [sp, #1504]
	add.2d	v4, v4, v18
	str	q4, [sp, #480]                  ; 16-byte Spill
	fmov	x9, d4
	add	x9, x24, x9, lsl #2
	ldr	q4, [sp, #1536]
	ldr	q19, [sp, #1520]
	tbnz	w10, #0, LBB0_340
; %bb.131:                              ; %else201
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_341
LBB0_132:                               ; %else204
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_342
LBB0_133:                               ; %else207
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_343
LBB0_134:                               ; %else210
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_344
LBB0_135:                               ; %else213
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_345
LBB0_136:                               ; %else216
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_346
LBB0_137:                               ; %else219
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_139
LBB0_138:                               ; %cond.load221
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v4 }[3], [x9]
LBB0_139:                               ; %else222
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v25, v14, #0
	sshll2.2d	v28, v14, #0
	sshll2.2d	v13, v5, #0
Lloh24:
	adrp	x9, lCPI0_3@PAGE
Lloh25:
	ldr	q20, [x9, lCPI0_3@PAGEOFF]
	and.16b	v21, v13, v20
Lloh26:
	adrp	x9, lCPI0_4@PAGE
Lloh27:
	ldr	q20, [x9, lCPI0_4@PAGEOFF]
	and.16b	v23, v28, v20
Lloh28:
	adrp	x9, lCPI0_6@PAGE
Lloh29:
	ldr	q20, [x9, lCPI0_6@PAGEOFF]
	and.16b	v26, v25, v20
	and.16b	v27, v14, v2
	movi.2s	v2, #66
	umull.2d	v2, v27, v2
	movi.4s	v22, #66
	umull2.2d	v20, v0, v22
	umull2.2d	v22, v27, v22
	mov.16b	v29, v28
	and.16b	v22, v28, v22
	and.16b	v20, v13, v20
	str	q25, [sp, #400]                 ; 16-byte Spill
	and.16b	v25, v25, v2
	str	q19, [sp, #1520]
	str	q4, [sp, #1536]
	str	q24, [sp, #512]                 ; 16-byte Spill
	add.2d	v2, v1, v24
	stp	q22, q20, [sp, #352]            ; 32-byte Folded Spill
	add.2d	v4, v21, v20
	str	q25, [sp, #320]                 ; 16-byte Spill
	add.2d	v19, v26, v25
	add.2d	v20, v23, v22
	mov	w9, #65                         ; =0x41
	dup.2d	v22, x9
	add.2d	v24, v20, v22
	add.2d	v20, v19, v22
	add.2d	v25, v4, v22
	add.2d	v4, v2, v22
	mov	b2, v7[0]
	mov.b	v2[4], v7[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	stp	q4, q25, [sp, #416]             ; 32-byte Folded Spill
	and.16b	v2, v2, v4
	mov	b4, v7[2]
	mov.b	v4[4], v7[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	mov	b19, v7[4]
	mov.b	v19[4], v7[5]
	and.16b	v4, v4, v25
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	stp	q20, q24, [sp, #448]            ; 32-byte Folded Spill
	and.16b	v19, v19, v20
	mov	b20, v7[6]
	mov.b	v20[4], v7[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v20, v20, v24
Lloh30:
	adrp	x9, lCPI0_31@PAGE
Lloh31:
	ldr	d22, [x9, lCPI0_31@PAGEOFF]
	shl.8b	v24, v7, #7
	cmlt.8b	v24, v24, #0
	and.8b	v22, v24, v22
	addv.8b	b11, v22
	stp	q19, q20, [sp, #912]
	stp	q2, q4, [sp, #880]
	and	x9, x4, #0x7
	add	x10, sp, #880
	ldr	x10, [x10, x9, lsl #3]
	fmov	w9, s11
	sub	x10, x10, x4
	add	x10, x24, x10, lsl #2
	add	x11, sp, #1424
	add	x11, x11, x22
	ldp	q2, q4, [x11]
	tbnz	w9, #0, LBB0_347
; %bb.140:                              ; %else226
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #1, LBB0_348
LBB0_141:                               ; %else229
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #2, LBB0_349
LBB0_142:                               ; %else232
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #3, LBB0_350
LBB0_143:                               ; %else235
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #4, LBB0_351
LBB0_144:                               ; %else238
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #5, LBB0_352
LBB0_145:                               ; %else241
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #6, LBB0_353
LBB0_146:                               ; %else244
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w9, #7, LBB0_148
LBB0_147:                               ; %cond.load246
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x10, #28
	ld1.s	{ v4 }[3], [x9]
LBB0_148:                               ; %else247
                                        ;   in Loop: Header=BB0_4 Depth=1
	ushll.2d	v19, v0, #0
	add	x9, sp, #1424
	add	x9, x9, x22
	stp	q2, q4, [x9]
	mov.d	x9, v19[1]
	fmov	x10, d19
	add	x10, x10, x10, lsl #5
	fmov	d2, x10
	fmov	w10, s6
	sshll.2d	v19, v5, #0
	add	x9, x9, x9, lsl #5
	mov.d	v2[1], x9
	and.16b	v28, v19, v2
	add.2d	v25, v28, v1
	fmov	x9, d25
	add	x9, x23, x9, lsl #2
	ldr	q2, [sp, #1280]
	ldr	q4, [sp, #1264]
	tbnz	w10, #0, LBB0_354
; %bb.149:                              ; %else251
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_355
LBB0_150:                               ; %else254
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_356
LBB0_151:                               ; %else257
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_357
LBB0_152:                               ; %else260
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_358
LBB0_153:                               ; %else263
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_359
LBB0_154:                               ; %else266
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_360
LBB0_155:                               ; %else269
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_157
LBB0_156:                               ; %cond.load271
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v2 }[3], [x9]
LBB0_157:                               ; %else272
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w10, s6
	str	q4, [sp, #1264]
	str	q2, [sp, #1280]
	add.2d	v24, v28, v17
	fmov	x9, d24
	add	x9, x23, x9, lsl #2
	ldr	q2, [sp, #1312]
	ldr	q4, [sp, #1296]
	tbnz	w10, #0, LBB0_361
; %bb.158:                              ; %else276
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_362
LBB0_159:                               ; %else279
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_363
LBB0_160:                               ; %else282
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_364
LBB0_161:                               ; %else285
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_365
LBB0_162:                               ; %else288
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_366
LBB0_163:                               ; %else291
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_367
LBB0_164:                               ; %else294
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_166
LBB0_165:                               ; %cond.load296
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v2 }[3], [x9]
LBB0_166:                               ; %else297
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w10, s6
	str	q4, [sp, #1296]
	str	q2, [sp, #1312]
	add.2d	v20, v28, v3
	fmov	x9, d20
	add	x9, x23, x9, lsl #2
	ldr	q2, [sp, #1344]
	ldr	q3, [sp, #1328]
	tbnz	w10, #0, LBB0_368
; %bb.167:                              ; %else301
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_369
LBB0_168:                               ; %else304
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_370
LBB0_169:                               ; %else307
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_371
LBB0_170:                               ; %else310
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_372
LBB0_171:                               ; %else313
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_373
LBB0_172:                               ; %else316
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_374
LBB0_173:                               ; %else319
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_175
LBB0_174:                               ; %cond.load321
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v2 }[3], [x9]
LBB0_175:                               ; %else322
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmov	w10, s6
	str	q3, [sp, #1328]
	str	q2, [sp, #1344]
	add.2d	v18, v28, v18
	fmov	x9, d18
	add	x9, x23, x9, lsl #2
	ldr	q2, [sp, #1376]
	ldr	q3, [sp, #1360]
	tbnz	w10, #0, LBB0_375
; %bb.176:                              ; %else326
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_376
LBB0_177:                               ; %else329
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_377
LBB0_178:                               ; %else332
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_378
LBB0_179:                               ; %else335
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_379
LBB0_180:                               ; %else338
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_380
LBB0_181:                               ; %else341
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_381
LBB0_182:                               ; %else344
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_184
LBB0_183:                               ; %cond.load346
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v2 }[3], [x9]
LBB0_184:                               ; %else347
                                        ;   in Loop: Header=BB0_4 Depth=1
	ushll2.2d	v4, v27, #0
	ushll2.2d	v0, v0, #0
	ushll.2d	v17, v27, #0
	dup.2d	v22, x28
	orr.16b	v12, v26, v22
	orr.16b	v21, v21, v22
	orr.16b	v27, v1, v22
	orr.16b	v22, v23, v22
	mov.d	x9, v0[1]
	fmov	x10, d0
	add	x10, x10, x10, lsl #5
	fmov	d0, x10
	add	x9, x9, x9, lsl #5
	mov.d	v0[1], x9
	mov.d	x9, v17[1]
	fmov	x10, d17
	add	x10, x10, x10, lsl #5
	fmov	d1, x10
	add	x9, x9, x9, lsl #5
	mov.d	v1[1], x9
	sshll.2d	v17, v14, #0
	mov.d	x9, v4[1]
	fmov	x10, d4
	add	x10, x10, x10, lsl #5
	fmov	d4, x10
	add	x9, x9, x9, lsl #5
	mov.d	v4[1], x9
	mov.16b	v26, v29
	and.16b	v4, v29, v4
	and.16b	v1, v17, v1
	and.16b	v0, v13, v0
	str	q3, [sp, #1360]
	str	q2, [sp, #1376]
	mov.16b	v31, v22
	add.2d	v2, v4, v22
	stp	q12, q21, [sp, #288]            ; 32-byte Folded Spill
	add.2d	v1, v1, v12
	add.2d	v0, v0, v21
	add.2d	v3, v28, v27
	mov	b4, v7[0]
	mov.b	v4[4], v7[1]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v3, v4, v3
	mov	b4, v7[2]
	mov.b	v4[4], v7[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v0, v4, v0
	mov	b4, v7[4]
	mov.b	v4[4], v7[5]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v1, v4, v1
	mov	b4, v7[6]
	mov.b	v4[4], v7[7]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v2, v4, v2
	fmov	w10, s11
	stp	q1, q2, [sp, #832]
	stp	q3, q0, [sp, #800]
	and	x9, x4, #0x7
	add	x11, sp, #800
	ldr	x9, [x11, x9, lsl #3]
	sub	x9, x9, x4
	lsl	x24, x9, #2
	add	x9, x23, x24
	add	x11, sp, #1264
	add	x11, x11, x22
	ldp	q0, q1, [x11]
	tbnz	w10, #0, LBB0_382
; %bb.185:                              ; %else351
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #1, LBB0_383
LBB0_186:                               ; %else354
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_384
LBB0_187:                               ; %else357
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_385
LBB0_188:                               ; %else360
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_386
LBB0_189:                               ; %else363
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_387
LBB0_190:                               ; %else366
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_388
LBB0_191:                               ; %else369
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_193
LBB0_192:                               ; %cond.load371
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v1 }[3], [x9]
LBB0_193:                               ; %else372
                                        ;   in Loop: Header=BB0_4 Depth=1
	and.16b	v2, v19, v25
	fmov	w10, s6
	add	x9, sp, #1264
	add	x9, x9, x22
	stp	q0, q1, [x9]
	fmov	x9, d2
	add	x9, x20, x9, lsl #2
	ldr	q0, [sp, #1120]
	ldr	q1, [sp, #1104]
	tbnz	w10, #0, LBB0_389
; %bb.194:                              ; %else376
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_390
LBB0_195:                               ; %else379
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_391
LBB0_196:                               ; %else382
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_392
LBB0_197:                               ; %else385
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_393
LBB0_198:                               ; %else388
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_394
LBB0_199:                               ; %else391
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_395
LBB0_200:                               ; %else394
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_202
LBB0_201:                               ; %cond.load396
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v0 }[3], [x9]
LBB0_202:                               ; %else397
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v2, v5, #0
	and.16b	v2, v2, v24
	fmov	w10, s6
	str	q1, [sp, #1104]
	str	q0, [sp, #1120]
	fmov	x9, d2
	add	x9, x20, x9, lsl #2
	ldr	q0, [sp, #1152]
	ldr	q1, [sp, #1136]
	tbnz	w10, #0, LBB0_396
; %bb.203:                              ; %else401
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_397
LBB0_204:                               ; %else404
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_398
LBB0_205:                               ; %else407
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_399
LBB0_206:                               ; %else410
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_400
LBB0_207:                               ; %else413
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_401
LBB0_208:                               ; %else416
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_402
LBB0_209:                               ; %else419
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_211
LBB0_210:                               ; %cond.load421
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v0 }[3], [x9]
LBB0_211:                               ; %else422
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v2, v5, #0
	and.16b	v2, v2, v20
	fmov	w10, s6
	str	q1, [sp, #1136]
	str	q0, [sp, #1152]
	fmov	x9, d2
	add	x9, x20, x9, lsl #2
	ldr	q0, [sp, #1184]
	ldr	q1, [sp, #1168]
	tbnz	w10, #0, LBB0_403
; %bb.212:                              ; %else426
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_404
LBB0_213:                               ; %else429
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_405
LBB0_214:                               ; %else432
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_406
LBB0_215:                               ; %else435
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_407
LBB0_216:                               ; %else438
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_408
LBB0_217:                               ; %else441
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_409
LBB0_218:                               ; %else444
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_220
LBB0_219:                               ; %cond.load446
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v0 }[3], [x9]
LBB0_220:                               ; %else447
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v2, v5, #0
	and.16b	v2, v2, v18
	fmov	w10, s6
	str	q1, [sp, #1168]
	str	q0, [sp, #1184]
	fmov	x9, d2
	add	x9, x20, x9, lsl #2
	ldr	q0, [sp, #1216]
	ldr	q1, [sp, #1200]
	tbnz	w10, #0, LBB0_410
; %bb.221:                              ; %else451
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_411
LBB0_222:                               ; %else454
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_412
LBB0_223:                               ; %else457
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_413
LBB0_224:                               ; %else460
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_414
LBB0_225:                               ; %else463
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_415
LBB0_226:                               ; %else466
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_416
LBB0_227:                               ; %else469
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_229
LBB0_228:                               ; %cond.load471
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v0 }[3], [x9]
LBB0_229:                               ; %else472
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q1, [sp, #1200]
	str	q0, [sp, #1216]
	add	x9, x20, x24
	add	x10, x12, x22
	ldp	q0, q1, [x10]
	fmov	w10, s11
	tbnz	w10, #0, LBB0_417
; %bb.230:                              ; %else476
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #1, LBB0_418
LBB0_231:                               ; %else479
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_419
LBB0_232:                               ; %else482
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_420
LBB0_233:                               ; %else485
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #4, LBB0_421
LBB0_234:                               ; %else488
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_422
LBB0_235:                               ; %else491
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_423
LBB0_236:                               ; %else494
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_238
LBB0_237:                               ; %cond.load496
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v1 }[3], [x9]
LBB0_238:                               ; %else497
                                        ;   in Loop: Header=BB0_4 Depth=1
Lloh32:
	adrp	x9, lCPI0_9@PAGE
Lloh33:
	ldr	q2, [x9, lCPI0_9@PAGEOFF]
	and.16b	v4, v30, v2
	orr.16b	v2, v16, v15
	and.16b	v2, v30, v2
	fmov	w10, s6
	add	x14, sp, #1104
	add	x9, x14, x22
	stp	q0, q1, [x9]
	fmov	x9, d4
	add	x11, sp, #1584
	add	x11, x11, x9
	ldp	q0, q3, [x11]
	add	x11, sp, #1264
	add	x11, x11, x9
	ldp	q1, q16, [x11]
	str	q0, [sp, #112]                  ; 16-byte Spill
	str	q1, [sp, #80]                   ; 16-byte Spill
	fmul.4s	v0, v0, v1
	add	x11, sp, #1424
	add	x11, x11, x9
	ldp	q1, q17, [x11]
	add	x12, sp, #1104
	add	x9, x14, x9
	ldp	q19, q18, [x9]
	stp	q19, q1, [sp, #48]              ; 32-byte Folded Spill
	fmul.4s	v1, v1, v19
	fsub.4s	v0, v0, v1
	and.16b	v0, v5, v0
	fmov	x9, d2
	add	x9, x1, x9, lsl #2
	tbnz	w10, #0, LBB0_424
; %bb.239:                              ; %else500
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_425
LBB0_240:                               ; %else502
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_426
LBB0_241:                               ; %else504
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_427
LBB0_242:                               ; %else506
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v0, v3, v16
	fmul.4s	v1, v17, v18
	fsub.4s	v0, v0, v1
	and.16b	v0, v14, v0
	tbnz	w10, #4, LBB0_428
LBB0_243:                               ; %else508
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_429
LBB0_244:                               ; %else510
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_430
LBB0_245:                               ; %else512
                                        ;   in Loop: Header=BB0_4 Depth=1
	stp	q17, q16, [sp, #208]            ; 32-byte Folded Spill
	str	q3, [sp, #240]                  ; 16-byte Spill
	str	d11, [sp, #560]                 ; 8-byte Spill
	tbz	w10, #7, LBB0_247
LBB0_246:                               ; %cond.store513
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v0 }[3], [x9]
LBB0_247:                               ; %else514
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q0, [sp, #384]                  ; 16-byte Reload
	and.16b	v1, v8, v0
Lloh34:
	adrp	x9, lCPI0_15@PAGE
Lloh35:
	ldr	q0, [x9, lCPI0_15@PAGEOFF]
	and.16b	v0, v8, v0
	fmov	w10, s6
	fmov	x9, d0
	add	x11, sp, #1584
	add	x11, x11, x9
	ldp	q2, q19, [x11]
	add	x11, sp, #1264
	add	x11, x11, x9
	ldp	q0, q20, [x11]
	str	q0, [sp, #32]                   ; 16-byte Spill
	fmul.4s	v0, v2, v0
	add	x11, sp, #1424
	add	x11, x11, x9
	ldp	q3, q21, [x11]
	add	x9, x12, x9
	ldp	q17, q22, [x9]
	fmul.4s	v16, v3, v17
	fsub.4s	v0, v0, v16
	and.16b	v0, v5, v0
	fmov	x9, d1
	add	x9, x1, x9, lsl #2
	tbnz	w10, #0, LBB0_431
; %bb.248:                              ; %else517
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_432
LBB0_249:                               ; %else519
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_433
LBB0_250:                               ; %else521
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_434
LBB0_251:                               ; %else523
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v0, v19, v20
	fmul.4s	v1, v21, v22
	fsub.4s	v0, v0, v1
	and.16b	v0, v14, v0
	tbnz	w10, #4, LBB0_435
LBB0_252:                               ; %else525
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_436
LBB0_253:                               ; %else527
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_437
LBB0_254:                               ; %else529
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q19, [sp, #192]                 ; 16-byte Spill
	str	q18, [sp, #384]                 ; 16-byte Spill
	tbz	w10, #7, LBB0_256
LBB0_255:                               ; %cond.store530
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v0 }[3], [x9]
LBB0_256:                               ; %else531
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q0, [sp, #272]                  ; 16-byte Reload
	and.16b	v18, v9, v0
Lloh36:
	adrp	x9, lCPI0_20@PAGE
Lloh37:
	ldr	q0, [x9, lCPI0_20@PAGEOFF]
	and.16b	v0, v9, v0
	fmov	w10, s6
	fmov	x9, d0
	add	x11, sp, #1584
	add	x11, x11, x9
	ldp	q1, q23, [x11]
	add	x11, sp, #1264
	add	x11, x11, x9
	ldp	q12, q24, [x11]
	fmul.4s	v0, v1, v12
	add	x11, sp, #1424
	add	x11, x11, x9
	ldp	q29, q25, [x11]
	add	x9, x12, x9
	ldp	q16, q28, [x9]
	fmul.4s	v19, v29, v16
	fsub.4s	v0, v0, v19
	and.16b	v0, v5, v0
	fmov	x9, d18
	add	x9, x1, x9, lsl #2
	tbnz	w10, #0, LBB0_438
; %bb.257:                              ; %else534
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_439
LBB0_258:                               ; %else536
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_440
LBB0_259:                               ; %else538
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_441
LBB0_260:                               ; %else540
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v0, v23, v24
	fmul.4s	v18, v25, v28
	fsub.4s	v0, v0, v18
	and.16b	v0, v14, v0
	tbnz	w10, #4, LBB0_442
LBB0_261:                               ; %else542
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_443
LBB0_262:                               ; %else544
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_444
LBB0_263:                               ; %else546
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q25, [sp, #96]                  ; 16-byte Spill
	stp	q24, q23, [sp, #128]            ; 32-byte Folded Spill
	stp	q22, q21, [sp, #160]            ; 32-byte Folded Spill
	str	q20, [sp, #272]                 ; 16-byte Spill
	tbz	w10, #7, LBB0_265
LBB0_264:                               ; %cond.store547
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v0 }[3], [x9]
LBB0_265:                               ; %else548
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q0, [sp, #256]                  ; 16-byte Reload
	and.16b	v20, v10, v0
Lloh38:
	adrp	x9, lCPI0_25@PAGE
Lloh39:
	ldr	q0, [x9, lCPI0_25@PAGEOFF]
	and.16b	v0, v10, v0
	fmov	w10, s6
	fmov	x9, d0
	add	x11, sp, #1584
	add	x11, x11, x9
	ldp	q19, q22, [x11]
	add	x11, sp, #1264
	add	x11, x11, x9
	ldp	q21, q11, [x11]
	fmul.4s	v18, v19, v21
	add	x11, sp, #1424
	add	x11, x11, x9
	ldp	q23, q0, [x11]
	add	x9, x12, x9
	ldp	q24, q30, [x9]
	fmul.4s	v25, v23, v24
	fsub.4s	v18, v18, v25
	and.16b	v18, v5, v18
	fmov	x9, d20
	add	x9, x1, x9, lsl #2
	tbnz	w10, #0, LBB0_445
; %bb.266:                              ; %else551
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_446
LBB0_267:                               ; %else553
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_447
LBB0_268:                               ; %else555
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_448
LBB0_269:                               ; %else557
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v18, v22, v11
	fmul.4s	v20, v0, v30
	fsub.4s	v18, v18, v20
	and.16b	v18, v14, v18
	tbnz	w10, #4, LBB0_449
LBB0_270:                               ; %else559
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_450
LBB0_271:                               ; %else561
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_451
LBB0_272:                               ; %else563
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	q30, [sp, #16]                  ; 16-byte Spill
	str	q28, [sp, #256]                 ; 16-byte Spill
	mov.16b	v15, v14
	tbz	w10, #7, LBB0_274
LBB0_273:                               ; %cond.store564
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v18 }[3], [x9]
LBB0_274:                               ; %else565
                                        ;   in Loop: Header=BB0_4 Depth=1
Lloh40:
	adrp	x9, lCPI0_7@PAGE
Lloh41:
	ldr	q18, [x9, lCPI0_7@PAGEOFF]
	and.16b	v18, v13, v18
Lloh42:
	adrp	x9, lCPI0_8@PAGE
Lloh43:
	ldr	q20, [x9, lCPI0_8@PAGEOFF]
	and.16b	v20, v26, v20
Lloh44:
	adrp	x9, lCPI0_10@PAGE
Lloh45:
	ldr	q25, [x9, lCPI0_10@PAGEOFF]
	ldr	q26, [sp, #400]                 ; 16-byte Reload
	and.16b	v25, v26, v25
	ldr	q26, [sp, #352]                 ; 16-byte Reload
	add.2d	v31, v26, v31
	ldr	q26, [sp, #320]                 ; 16-byte Reload
	ldp	q30, q28, [sp, #288]            ; 32-byte Folded Reload
	add.2d	v8, v26, v30
	ldr	q26, [sp, #368]                 ; 16-byte Reload
	add.2d	v14, v26, v28
	ldr	q26, [sp, #512]                 ; 16-byte Reload
	add.2d	v9, v26, v27
	stp	q4, q18, [sp, #720]
	stp	q25, q20, [sp, #752]
	ubfiz	x10, x4, #3, #3
	add	x9, sp, #720
	ldr	x9, [x9, x10]
	orr	x9, x9, #0x80
	sub	x9, x9, x7
	tst	w5, #0xff
	csel	x9, xzr, x9, eq
	add	x11, sp, #1584
	add	x11, x11, x9
	ldp	q25, q13, [x11]
	add	x11, sp, #1264
	add	x11, x11, x9
	ldp	q26, q4, [x11]
	fmul.4s	v30, v25, v26
	add	x11, sp, #1424
	add	x11, x11, x9
	ldp	q27, q18, [x11]
	add	x9, x12, x9
	ldp	q28, q20, [x9]
	fmul.4s	v10, v27, v28
	fsub.4s	v30, v30, v10
	zip1.8b	v10, v7, v0
	ushll.4s	v10, v10, #0
	shl.4s	v10, v10, #31
	cmlt.4s	v10, v10, #0
	and.16b	v30, v10, v30
	ldr	d10, [sp, #560]                 ; 8-byte Reload
	fmov	w9, s10
	stp	q9, q14, [sp, #656]
	stp	q8, q31, [sp, #688]
	add	x11, sp, #656
	ldr	x10, [x11, x10]
	sub	x10, x10, x4
	add	x10, x1, x10, lsl #2
	tbnz	w9, #0, LBB0_452
; %bb.275:                              ; %else568
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #1, LBB0_453
LBB0_276:                               ; %else570
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #2, LBB0_454
LBB0_277:                               ; %else572
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w9, #3, LBB0_279
LBB0_278:                               ; %cond.store573
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #12
	st1.s	{ v30 }[3], [x11]
LBB0_279:                               ; %else574
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v30, v13, v4
	fmul.4s	v31, v18, v20
	fsub.4s	v30, v30, v31
	zip2.8b	v31, v7, v0
	ushll.4s	v31, v31, #0
	shl.4s	v31, v31, #31
	cmlt.4s	v31, v31, #0
	and.16b	v30, v31, v30
	tbnz	w9, #4, LBB0_455
; %bb.280:                              ; %else576
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #5, LBB0_456
LBB0_281:                               ; %else578
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #6, LBB0_457
LBB0_282:                               ; %else580
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w9, #7, LBB0_284
LBB0_283:                               ; %cond.store581
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x10, #28
	st1.s	{ v30 }[3], [x9]
LBB0_284:                               ; %else582
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v30, v5, #0
	ldr	q31, [sp, #544]                 ; 16-byte Reload
	and.16b	v31, v30, v31
	fmov	w10, s6
	ldr	q30, [sp, #112]                 ; 16-byte Reload
	ldp	q8, q10, [sp, #48]              ; 32-byte Folded Reload
	fmul.4s	v30, v30, v8
	ldr	q8, [sp, #80]                   ; 16-byte Reload
	fmul.4s	v8, v8, v10
	fadd.4s	v30, v8, v30
	and.16b	v30, v5, v30
	fmov	x9, d31
	add	x9, x1, x9, lsl #2
	tbnz	w10, #0, LBB0_458
; %bb.285:                              ; %else585
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_459
LBB0_286:                               ; %else587
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_460
LBB0_287:                               ; %else589
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #3, LBB0_289
LBB0_288:                               ; %cond.store590
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v30 }[3], [x11]
LBB0_289:                               ; %else591
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q30, [sp, #240]                 ; 16-byte Reload
	ldr	q31, [sp, #384]                 ; 16-byte Reload
	fmul.4s	v30, v30, v31
	ldp	q8, q31, [sp, #208]             ; 32-byte Folded Reload
	fmul.4s	v31, v31, v8
	fadd.4s	v30, v31, v30
	and.16b	v30, v15, v30
	tbnz	w10, #4, LBB0_461
; %bb.290:                              ; %else593
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_462
LBB0_291:                               ; %else595
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_463
LBB0_292:                               ; %else597
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_294
LBB0_293:                               ; %cond.store598
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v30 }[3], [x9]
LBB0_294:                               ; %else599
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v30, v5, #0
	ldr	q31, [sp, #528]                 ; 16-byte Reload
	and.16b	v30, v30, v31
	fmov	w10, s6
	fmul.4s	v2, v2, v17
	ldr	q17, [sp, #32]                  ; 16-byte Reload
	fmul.4s	v3, v17, v3
	fadd.4s	v2, v3, v2
	and.16b	v2, v5, v2
	fmov	x9, d30
	add	x9, x1, x9, lsl #2
	tbnz	w10, #0, LBB0_464
; %bb.295:                              ; %else602
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	ldr	d17, [sp, #560]                 ; 8-byte Reload
	tbnz	w10, #1, LBB0_465
LBB0_296:                               ; %else604
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_466
LBB0_297:                               ; %else606
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #3, LBB0_299
LBB0_298:                               ; %cond.store607
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v2 }[3], [x11]
LBB0_299:                               ; %else608
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldp	q30, q2, [sp, #176]             ; 32-byte Folded Reload
	ldr	q3, [sp, #160]                  ; 16-byte Reload
	fmul.4s	v2, v2, v3
	ldr	q3, [sp, #272]                  ; 16-byte Reload
	fmul.4s	v3, v3, v30
	fadd.4s	v2, v3, v2
	and.16b	v2, v15, v2
	tbnz	w10, #4, LBB0_467
; %bb.300:                              ; %else610
                                        ;   in Loop: Header=BB0_4 Depth=1
	mov.16b	v30, v0
	tbnz	w10, #5, LBB0_468
LBB0_301:                               ; %else612
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_469
LBB0_302:                               ; %else614
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_304
LBB0_303:                               ; %cond.store615
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v2 }[3], [x9]
LBB0_304:                               ; %else616
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v2, v5, #0
	ldr	q3, [sp, #496]                  ; 16-byte Reload
	and.16b	v2, v2, v3
	fmov	w10, s6
	fmul.4s	v1, v1, v16
	fmul.4s	v3, v12, v29
	fadd.4s	v1, v3, v1
	and.16b	v1, v5, v1
	fmov	x9, d2
	add	x9, x1, x9, lsl #2
	tbnz	w10, #0, LBB0_470
; %bb.305:                              ; %else619
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_471
LBB0_306:                               ; %else621
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_472
LBB0_307:                               ; %else623
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #3, LBB0_309
LBB0_308:                               ; %cond.store624
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v1 }[3], [x11]
LBB0_309:                               ; %else625
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q1, [sp, #144]                  ; 16-byte Reload
	ldr	q2, [sp, #256]                  ; 16-byte Reload
	fmul.4s	v1, v1, v2
	ldr	q2, [sp, #128]                  ; 16-byte Reload
	ldr	q3, [sp, #96]                   ; 16-byte Reload
	fmul.4s	v2, v2, v3
	fadd.4s	v1, v2, v1
	and.16b	v1, v15, v1
	tbnz	w10, #4, LBB0_473
; %bb.310:                              ; %else627
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_474
LBB0_311:                               ; %else629
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_475
LBB0_312:                               ; %else631
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_314
LBB0_313:                               ; %cond.store632
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v1 }[3], [x9]
LBB0_314:                               ; %else633
                                        ;   in Loop: Header=BB0_4 Depth=1
	sshll.2d	v1, v5, #0
	ldr	q2, [sp, #480]                  ; 16-byte Reload
	and.16b	v2, v1, v2
	fmov	w10, s6
	fmul.4s	v1, v19, v24
	fmul.4s	v3, v21, v23
	fadd.4s	v1, v3, v1
	and.16b	v1, v5, v1
	fmov	x9, d2
	add	x9, x1, x9, lsl #2
	tbnz	w10, #0, LBB0_476
; %bb.315:                              ; %else636
                                        ;   in Loop: Header=BB0_4 Depth=1
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB0_477
LBB0_316:                               ; %else638
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #2, LBB0_478
LBB0_317:                               ; %else640
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #3, LBB0_479
LBB0_318:                               ; %else642
                                        ;   in Loop: Header=BB0_4 Depth=1
	ldr	q0, [sp, #16]                   ; 16-byte Reload
	fmul.4s	v0, v22, v0
	fmul.4s	v1, v11, v30
	fadd.4s	v0, v1, v0
	and.16b	v0, v15, v0
	tbnz	w10, #4, LBB0_480
LBB0_319:                               ; %else644
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #5, LBB0_481
LBB0_320:                               ; %else646
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w10, #6, LBB0_482
LBB0_321:                               ; %else648
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w10, #7, LBB0_323
LBB0_322:                               ; %cond.store649
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v0 }[3], [x9]
LBB0_323:                               ; %else650
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v0, v25, v28
	fmul.4s	v1, v26, v27
	fadd.4s	v0, v1, v0
	zip1.8b	v1, v7, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v0, v1, v0
	fmov	w9, s17
	ldp	q2, q1, [sp, #416]              ; 32-byte Folded Reload
	stp	q2, q1, [sp, #576]
	ldp	q2, q1, [sp, #448]              ; 32-byte Folded Reload
	stp	q2, q1, [sp, #608]
	and	x10, x4, #0x7
	add	x11, sp, #576
	ldr	x10, [x11, x10, lsl #3]
	sub	x10, x10, x4
	add	x10, x1, x10, lsl #2
	tbnz	w9, #0, LBB0_483
; %bb.324:                              ; %else653
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #1, LBB0_484
LBB0_325:                               ; %else655
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #2, LBB0_485
LBB0_326:                               ; %else657
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w9, #3, LBB0_328
LBB0_327:                               ; %cond.store658
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #12
	st1.s	{ v0 }[3], [x11]
LBB0_328:                               ; %else659
                                        ;   in Loop: Header=BB0_4 Depth=1
	fmul.4s	v0, v13, v20
	fmul.4s	v1, v4, v18
	fadd.4s	v0, v1, v0
	zip2.8b	v1, v7, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v0, v1, v0
	tbnz	w9, #4, LBB0_486
; %bb.329:                              ; %else661
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #5, LBB0_487
LBB0_330:                               ; %else663
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbnz	w9, #6, LBB0_488
LBB0_331:                               ; %else665
                                        ;   in Loop: Header=BB0_4 Depth=1
	tbz	w9, #7, LBB0_3
	b	LBB0_489
LBB0_332:                               ; %cond.load168
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v20 }[2], [x11]
	tbnz	w10, #7, LBB0_120
	b	LBB0_121
LBB0_333:                               ; %cond.load175
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v20 }[0], [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_123
LBB0_334:                               ; %cond.load178
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v20 }[1], [x11]
	tbz	w10, #2, LBB0_124
LBB0_335:                               ; %cond.load181
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v20 }[2], [x11]
	tbz	w10, #3, LBB0_125
LBB0_336:                               ; %cond.load184
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v20 }[3], [x11]
	tbz	w10, #4, LBB0_126
LBB0_337:                               ; %cond.load187
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v19 }[0], [x11]
	tbz	w10, #5, LBB0_127
LBB0_338:                               ; %cond.load190
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v19 }[1], [x11]
	tbz	w10, #6, LBB0_128
LBB0_339:                               ; %cond.load193
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v19 }[2], [x11]
	tbnz	w10, #7, LBB0_129
	b	LBB0_130
LBB0_340:                               ; %cond.load200
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v19 }[0], [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_132
LBB0_341:                               ; %cond.load203
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v19 }[1], [x11]
	tbz	w10, #2, LBB0_133
LBB0_342:                               ; %cond.load206
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v19 }[2], [x11]
	tbz	w10, #3, LBB0_134
LBB0_343:                               ; %cond.load209
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v19 }[3], [x11]
	tbz	w10, #4, LBB0_135
LBB0_344:                               ; %cond.load212
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v4 }[0], [x11]
	tbz	w10, #5, LBB0_136
LBB0_345:                               ; %cond.load215
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v4 }[1], [x11]
	tbz	w10, #6, LBB0_137
LBB0_346:                               ; %cond.load218
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v4 }[2], [x11]
	tbnz	w10, #7, LBB0_138
	b	LBB0_139
LBB0_347:                               ; %cond.load225
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v2 }[0], [x10]
	tbz	w9, #1, LBB0_141
LBB0_348:                               ; %cond.load228
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #4
	ld1.s	{ v2 }[1], [x11]
	tbz	w9, #2, LBB0_142
LBB0_349:                               ; %cond.load231
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #8
	ld1.s	{ v2 }[2], [x11]
	tbz	w9, #3, LBB0_143
LBB0_350:                               ; %cond.load234
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #12
	ld1.s	{ v2 }[3], [x11]
	tbz	w9, #4, LBB0_144
LBB0_351:                               ; %cond.load237
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #16
	ld1.s	{ v4 }[0], [x11]
	tbz	w9, #5, LBB0_145
LBB0_352:                               ; %cond.load240
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #20
	ld1.s	{ v4 }[1], [x11]
	tbz	w9, #6, LBB0_146
LBB0_353:                               ; %cond.load243
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #24
	ld1.s	{ v4 }[2], [x11]
	tbnz	w9, #7, LBB0_147
	b	LBB0_148
LBB0_354:                               ; %cond.load250
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v4 }[0], [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_150
LBB0_355:                               ; %cond.load253
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v4 }[1], [x11]
	tbz	w10, #2, LBB0_151
LBB0_356:                               ; %cond.load256
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v4 }[2], [x11]
	tbz	w10, #3, LBB0_152
LBB0_357:                               ; %cond.load259
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v4 }[3], [x11]
	tbz	w10, #4, LBB0_153
LBB0_358:                               ; %cond.load262
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v2 }[0], [x11]
	tbz	w10, #5, LBB0_154
LBB0_359:                               ; %cond.load265
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v2 }[1], [x11]
	tbz	w10, #6, LBB0_155
LBB0_360:                               ; %cond.load268
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v2 }[2], [x11]
	tbnz	w10, #7, LBB0_156
	b	LBB0_157
LBB0_361:                               ; %cond.load275
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v4 }[0], [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_159
LBB0_362:                               ; %cond.load278
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v4 }[1], [x11]
	tbz	w10, #2, LBB0_160
LBB0_363:                               ; %cond.load281
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v4 }[2], [x11]
	tbz	w10, #3, LBB0_161
LBB0_364:                               ; %cond.load284
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v4 }[3], [x11]
	tbz	w10, #4, LBB0_162
LBB0_365:                               ; %cond.load287
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v2 }[0], [x11]
	tbz	w10, #5, LBB0_163
LBB0_366:                               ; %cond.load290
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v2 }[1], [x11]
	tbz	w10, #6, LBB0_164
LBB0_367:                               ; %cond.load293
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v2 }[2], [x11]
	tbnz	w10, #7, LBB0_165
	b	LBB0_166
LBB0_368:                               ; %cond.load300
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v3 }[0], [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_168
LBB0_369:                               ; %cond.load303
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v3 }[1], [x11]
	tbz	w10, #2, LBB0_169
LBB0_370:                               ; %cond.load306
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v3 }[2], [x11]
	tbz	w10, #3, LBB0_170
LBB0_371:                               ; %cond.load309
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v3 }[3], [x11]
	tbz	w10, #4, LBB0_171
LBB0_372:                               ; %cond.load312
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v2 }[0], [x11]
	tbz	w10, #5, LBB0_172
LBB0_373:                               ; %cond.load315
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v2 }[1], [x11]
	tbz	w10, #6, LBB0_173
LBB0_374:                               ; %cond.load318
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v2 }[2], [x11]
	tbnz	w10, #7, LBB0_174
	b	LBB0_175
LBB0_375:                               ; %cond.load325
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v3 }[0], [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_177
LBB0_376:                               ; %cond.load328
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v3 }[1], [x11]
	tbz	w10, #2, LBB0_178
LBB0_377:                               ; %cond.load331
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v3 }[2], [x11]
	tbz	w10, #3, LBB0_179
LBB0_378:                               ; %cond.load334
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v3 }[3], [x11]
	tbz	w10, #4, LBB0_180
LBB0_379:                               ; %cond.load337
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v2 }[0], [x11]
	tbz	w10, #5, LBB0_181
LBB0_380:                               ; %cond.load340
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v2 }[1], [x11]
	tbz	w10, #6, LBB0_182
LBB0_381:                               ; %cond.load343
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v2 }[2], [x11]
	tbnz	w10, #7, LBB0_183
	b	LBB0_184
LBB0_382:                               ; %cond.load350
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v0 }[0], [x9]
	tbz	w10, #1, LBB0_186
LBB0_383:                               ; %cond.load353
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v0 }[1], [x11]
	tbz	w10, #2, LBB0_187
LBB0_384:                               ; %cond.load356
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v0 }[2], [x11]
	tbz	w10, #3, LBB0_188
LBB0_385:                               ; %cond.load359
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v0 }[3], [x11]
	tbz	w10, #4, LBB0_189
LBB0_386:                               ; %cond.load362
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v1 }[0], [x11]
	tbz	w10, #5, LBB0_190
LBB0_387:                               ; %cond.load365
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v1 }[1], [x11]
	tbz	w10, #6, LBB0_191
LBB0_388:                               ; %cond.load368
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v1 }[2], [x11]
	tbnz	w10, #7, LBB0_192
	b	LBB0_193
LBB0_389:                               ; %cond.load375
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v1 }[0], [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_195
LBB0_390:                               ; %cond.load378
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v1 }[1], [x11]
	tbz	w10, #2, LBB0_196
LBB0_391:                               ; %cond.load381
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v1 }[2], [x11]
	tbz	w10, #3, LBB0_197
LBB0_392:                               ; %cond.load384
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v1 }[3], [x11]
	tbz	w10, #4, LBB0_198
LBB0_393:                               ; %cond.load387
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v0 }[0], [x11]
	tbz	w10, #5, LBB0_199
LBB0_394:                               ; %cond.load390
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v0 }[1], [x11]
	tbz	w10, #6, LBB0_200
LBB0_395:                               ; %cond.load393
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v0 }[2], [x11]
	tbnz	w10, #7, LBB0_201
	b	LBB0_202
LBB0_396:                               ; %cond.load400
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v1 }[0], [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_204
LBB0_397:                               ; %cond.load403
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v1 }[1], [x11]
	tbz	w10, #2, LBB0_205
LBB0_398:                               ; %cond.load406
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v1 }[2], [x11]
	tbz	w10, #3, LBB0_206
LBB0_399:                               ; %cond.load409
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v1 }[3], [x11]
	tbz	w10, #4, LBB0_207
LBB0_400:                               ; %cond.load412
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v0 }[0], [x11]
	tbz	w10, #5, LBB0_208
LBB0_401:                               ; %cond.load415
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v0 }[1], [x11]
	tbz	w10, #6, LBB0_209
LBB0_402:                               ; %cond.load418
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v0 }[2], [x11]
	tbnz	w10, #7, LBB0_210
	b	LBB0_211
LBB0_403:                               ; %cond.load425
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v1 }[0], [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_213
LBB0_404:                               ; %cond.load428
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v1 }[1], [x11]
	tbz	w10, #2, LBB0_214
LBB0_405:                               ; %cond.load431
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v1 }[2], [x11]
	tbz	w10, #3, LBB0_215
LBB0_406:                               ; %cond.load434
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v1 }[3], [x11]
	tbz	w10, #4, LBB0_216
LBB0_407:                               ; %cond.load437
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v0 }[0], [x11]
	tbz	w10, #5, LBB0_217
LBB0_408:                               ; %cond.load440
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v0 }[1], [x11]
	tbz	w10, #6, LBB0_218
LBB0_409:                               ; %cond.load443
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v0 }[2], [x11]
	tbnz	w10, #7, LBB0_219
	b	LBB0_220
LBB0_410:                               ; %cond.load450
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v1 }[0], [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_222
LBB0_411:                               ; %cond.load453
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v1 }[1], [x11]
	tbz	w10, #2, LBB0_223
LBB0_412:                               ; %cond.load456
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v1 }[2], [x11]
	tbz	w10, #3, LBB0_224
LBB0_413:                               ; %cond.load459
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v1 }[3], [x11]
	tbz	w10, #4, LBB0_225
LBB0_414:                               ; %cond.load462
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v0 }[0], [x11]
	tbz	w10, #5, LBB0_226
LBB0_415:                               ; %cond.load465
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v0 }[1], [x11]
	tbz	w10, #6, LBB0_227
LBB0_416:                               ; %cond.load468
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v0 }[2], [x11]
	tbnz	w10, #7, LBB0_228
	b	LBB0_229
LBB0_417:                               ; %cond.load475
                                        ;   in Loop: Header=BB0_4 Depth=1
	ld1.s	{ v0 }[0], [x9]
	tbz	w10, #1, LBB0_231
LBB0_418:                               ; %cond.load478
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v0 }[1], [x11]
	tbz	w10, #2, LBB0_232
LBB0_419:                               ; %cond.load481
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v0 }[2], [x11]
	tbz	w10, #3, LBB0_233
LBB0_420:                               ; %cond.load484
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v0 }[3], [x11]
	tbz	w10, #4, LBB0_234
LBB0_421:                               ; %cond.load487
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v1 }[0], [x11]
	tbz	w10, #5, LBB0_235
LBB0_422:                               ; %cond.load490
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v1 }[1], [x11]
	tbz	w10, #6, LBB0_236
LBB0_423:                               ; %cond.load493
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v1 }[2], [x11]
	tbnz	w10, #7, LBB0_237
	b	LBB0_238
LBB0_424:                               ; %cond.store
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_240
LBB0_425:                               ; %cond.store501
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v0 }[1], [x11]
	tbz	w10, #2, LBB0_241
LBB0_426:                               ; %cond.store503
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v0 }[2], [x11]
	tbz	w10, #3, LBB0_242
LBB0_427:                               ; %cond.store505
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v0 }[3], [x11]
	fmul.4s	v0, v3, v16
	fmul.4s	v1, v17, v18
	fsub.4s	v0, v0, v1
	and.16b	v0, v14, v0
	tbz	w10, #4, LBB0_243
LBB0_428:                               ; %cond.store507
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x9, #16]
	tbz	w10, #5, LBB0_244
LBB0_429:                               ; %cond.store509
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v0 }[1], [x11]
	tbz	w10, #6, LBB0_245
LBB0_430:                               ; %cond.store511
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v0 }[2], [x11]
	stp	q17, q16, [sp, #208]            ; 32-byte Folded Spill
	str	q3, [sp, #240]                  ; 16-byte Spill
	str	d11, [sp, #560]                 ; 8-byte Spill
	tbnz	w10, #7, LBB0_246
	b	LBB0_247
LBB0_431:                               ; %cond.store516
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_249
LBB0_432:                               ; %cond.store518
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v0 }[1], [x11]
	tbz	w10, #2, LBB0_250
LBB0_433:                               ; %cond.store520
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v0 }[2], [x11]
	tbz	w10, #3, LBB0_251
LBB0_434:                               ; %cond.store522
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v0 }[3], [x11]
	fmul.4s	v0, v19, v20
	fmul.4s	v1, v21, v22
	fsub.4s	v0, v0, v1
	and.16b	v0, v14, v0
	tbz	w10, #4, LBB0_252
LBB0_435:                               ; %cond.store524
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x9, #16]
	tbz	w10, #5, LBB0_253
LBB0_436:                               ; %cond.store526
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v0 }[1], [x11]
	tbz	w10, #6, LBB0_254
LBB0_437:                               ; %cond.store528
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v0 }[2], [x11]
	str	q19, [sp, #192]                 ; 16-byte Spill
	str	q18, [sp, #384]                 ; 16-byte Spill
	tbnz	w10, #7, LBB0_255
	b	LBB0_256
LBB0_438:                               ; %cond.store533
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_258
LBB0_439:                               ; %cond.store535
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v0 }[1], [x11]
	tbz	w10, #2, LBB0_259
LBB0_440:                               ; %cond.store537
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v0 }[2], [x11]
	tbz	w10, #3, LBB0_260
LBB0_441:                               ; %cond.store539
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v0 }[3], [x11]
	fmul.4s	v0, v23, v24
	fmul.4s	v18, v25, v28
	fsub.4s	v0, v0, v18
	and.16b	v0, v14, v0
	tbz	w10, #4, LBB0_261
LBB0_442:                               ; %cond.store541
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x9, #16]
	tbz	w10, #5, LBB0_262
LBB0_443:                               ; %cond.store543
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v0 }[1], [x11]
	tbz	w10, #6, LBB0_263
LBB0_444:                               ; %cond.store545
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v0 }[2], [x11]
	str	q25, [sp, #96]                  ; 16-byte Spill
	stp	q24, q23, [sp, #128]            ; 32-byte Folded Spill
	stp	q22, q21, [sp, #160]            ; 32-byte Folded Spill
	str	q20, [sp, #272]                 ; 16-byte Spill
	tbnz	w10, #7, LBB0_264
	b	LBB0_265
LBB0_445:                               ; %cond.store550
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s18, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_267
LBB0_446:                               ; %cond.store552
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v18 }[1], [x11]
	tbz	w10, #2, LBB0_268
LBB0_447:                               ; %cond.store554
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v18 }[2], [x11]
	tbz	w10, #3, LBB0_269
LBB0_448:                               ; %cond.store556
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v18 }[3], [x11]
	fmul.4s	v18, v22, v11
	fmul.4s	v20, v0, v30
	fsub.4s	v18, v18, v20
	and.16b	v18, v14, v18
	tbz	w10, #4, LBB0_270
LBB0_449:                               ; %cond.store558
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s18, [x9, #16]
	tbz	w10, #5, LBB0_271
LBB0_450:                               ; %cond.store560
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v18 }[1], [x11]
	tbz	w10, #6, LBB0_272
LBB0_451:                               ; %cond.store562
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v18 }[2], [x11]
	str	q30, [sp, #16]                  ; 16-byte Spill
	str	q28, [sp, #256]                 ; 16-byte Spill
	mov.16b	v15, v14
	tbnz	w10, #7, LBB0_273
	b	LBB0_274
LBB0_452:                               ; %cond.store567
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s30, [x10]
	tbz	w9, #1, LBB0_276
LBB0_453:                               ; %cond.store569
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #4
	st1.s	{ v30 }[1], [x11]
	tbz	w9, #2, LBB0_277
LBB0_454:                               ; %cond.store571
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #8
	st1.s	{ v30 }[2], [x11]
	tbnz	w9, #3, LBB0_278
	b	LBB0_279
LBB0_455:                               ; %cond.store575
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s30, [x10, #16]
	tbz	w9, #5, LBB0_281
LBB0_456:                               ; %cond.store577
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #20
	st1.s	{ v30 }[1], [x11]
	tbz	w9, #6, LBB0_282
LBB0_457:                               ; %cond.store579
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #24
	st1.s	{ v30 }[2], [x11]
	tbnz	w9, #7, LBB0_283
	b	LBB0_284
LBB0_458:                               ; %cond.store584
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s30, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_286
LBB0_459:                               ; %cond.store586
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v30 }[1], [x11]
	tbz	w10, #2, LBB0_287
LBB0_460:                               ; %cond.store588
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v30 }[2], [x11]
	tbnz	w10, #3, LBB0_288
	b	LBB0_289
LBB0_461:                               ; %cond.store592
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s30, [x9, #16]
	tbz	w10, #5, LBB0_291
LBB0_462:                               ; %cond.store594
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v30 }[1], [x11]
	tbz	w10, #6, LBB0_292
LBB0_463:                               ; %cond.store596
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v30 }[2], [x11]
	tbnz	w10, #7, LBB0_293
	b	LBB0_294
LBB0_464:                               ; %cond.store601
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s2, [x9]
	and	w10, w10, #0xff
	ldr	d17, [sp, #560]                 ; 8-byte Reload
	tbz	w10, #1, LBB0_296
LBB0_465:                               ; %cond.store603
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v2 }[1], [x11]
	tbz	w10, #2, LBB0_297
LBB0_466:                               ; %cond.store605
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v2 }[2], [x11]
	tbnz	w10, #3, LBB0_298
	b	LBB0_299
LBB0_467:                               ; %cond.store609
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s2, [x9, #16]
	mov.16b	v30, v0
	tbz	w10, #5, LBB0_301
LBB0_468:                               ; %cond.store611
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v2 }[1], [x11]
	tbz	w10, #6, LBB0_302
LBB0_469:                               ; %cond.store613
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v2 }[2], [x11]
	tbnz	w10, #7, LBB0_303
	b	LBB0_304
LBB0_470:                               ; %cond.store618
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s1, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_306
LBB0_471:                               ; %cond.store620
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v1 }[1], [x11]
	tbz	w10, #2, LBB0_307
LBB0_472:                               ; %cond.store622
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v1 }[2], [x11]
	tbnz	w10, #3, LBB0_308
	b	LBB0_309
LBB0_473:                               ; %cond.store626
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s1, [x9, #16]
	tbz	w10, #5, LBB0_311
LBB0_474:                               ; %cond.store628
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v1 }[1], [x11]
	tbz	w10, #6, LBB0_312
LBB0_475:                               ; %cond.store630
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v1 }[2], [x11]
	tbnz	w10, #7, LBB0_313
	b	LBB0_314
LBB0_476:                               ; %cond.store635
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s1, [x9]
	and	w10, w10, #0xff
	tbz	w10, #1, LBB0_316
LBB0_477:                               ; %cond.store637
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v1 }[1], [x11]
	tbz	w10, #2, LBB0_317
LBB0_478:                               ; %cond.store639
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v1 }[2], [x11]
	tbz	w10, #3, LBB0_318
LBB0_479:                               ; %cond.store641
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v1 }[3], [x11]
	ldr	q0, [sp, #16]                   ; 16-byte Reload
	fmul.4s	v0, v22, v0
	fmul.4s	v1, v11, v30
	fadd.4s	v0, v1, v0
	and.16b	v0, v15, v0
	tbz	w10, #4, LBB0_319
LBB0_480:                               ; %cond.store643
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x9, #16]
	tbz	w10, #5, LBB0_320
LBB0_481:                               ; %cond.store645
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v0 }[1], [x11]
	tbz	w10, #6, LBB0_321
LBB0_482:                               ; %cond.store647
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v0 }[2], [x11]
	tbnz	w10, #7, LBB0_322
	b	LBB0_323
LBB0_483:                               ; %cond.store652
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x10]
	tbz	w9, #1, LBB0_325
LBB0_484:                               ; %cond.store654
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #4
	st1.s	{ v0 }[1], [x11]
	tbz	w9, #2, LBB0_326
LBB0_485:                               ; %cond.store656
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #8
	st1.s	{ v0 }[2], [x11]
	tbnz	w9, #3, LBB0_327
	b	LBB0_328
LBB0_486:                               ; %cond.store660
                                        ;   in Loop: Header=BB0_4 Depth=1
	str	s0, [x10, #16]
	tbz	w9, #5, LBB0_330
LBB0_487:                               ; %cond.store662
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #20
	st1.s	{ v0 }[1], [x11]
	tbz	w9, #6, LBB0_331
LBB0_488:                               ; %cond.store664
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x11, x10, #24
	st1.s	{ v0 }[2], [x11]
	tbz	w9, #7, LBB0_3
LBB0_489:                               ; %cond.store666
                                        ;   in Loop: Header=BB0_4 Depth=1
	add	x9, x10, #28
	st1.s	{ v0 }[3], [x9]
	b	LBB0_3
LBB0_490:
	add	sp, sp, #1744
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_491:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	sub	sp, sp, #304
	stp	d15, d14, [sp, #224]            ; 16-byte Folded Spill
	stp	d13, d12, [sp, #240]            ; 16-byte Folded Spill
	stp	d11, d10, [sp, #256]            ; 16-byte Folded Spill
	stp	d9, d8, [sp, #272]              ; 16-byte Folded Spill
	stp	x28, x27, [sp, #288]            ; 16-byte Folded Spill
	ldr	x10, [x0]
	ldr	x11, [x0, #16]
	ldr	x9, [x0, #32]
	ldr	x8, [x0, #48]
	ldr	w12, [x1]
	ldr	w13, [x1, #36]
	add	w12, w13, w12, lsl #5
	lsr	w12, w12, #3
	dup.2s	v0, w12
	ushll.2d	v18, v0, #0
	subs	x12, x10, x8
	cset	w13, hs
	lsr	x12, x12, #3
	cmp	x12, #560
	csel	w13, wzr, w13, ls
	subs	x12, x8, x10
	cset	w14, hs
	lsr	x12, x12, #3
	cmp	x12, #560
	csel	w14, wzr, w14, ls
	subs	x12, x11, x8
	cset	w15, hs
	lsr	x12, x12, #3
	cmp	x12, #560
	csel	w15, wzr, w15, ls
	subs	x12, x8, x11
	cset	w16, hs
	cmp	x12, #2243
	csel	w16, wzr, w16, ls
	subs	x12, x9, x8
	cset	w17, hs
	lsr	x12, x12, #3
	cmp	x12, #560
	csel	w12, wzr, w17, ls
	subs	x17, x8, x9
	cset	w0, hs
	cmp	x17, #2243
	csel	w17, wzr, w0, ls
	orr	w17, w12, w17
	fmov	x12, d18
	add	x12, x12, x12, lsl #5
	lsl	x12, x12, #3
	add	x0, x10, x12
	ldp	q20, q1, [x0]
	cmp	w17, #1
	b.ne	LBB0_4
; %bb.1:                                ; %prologue
	orr	w13, w13, w14
	cbz	w13, LBB0_4
; %bb.2:                                ; %prologue
	orr	w13, w15, w16
	tbz	w13, #0, LBB0_4
; %bb.3:                                ; %direct.true
	add	x14, x12, #132
	add	x13, x10, x14
	ldp	q0, q2, [x13]
	fmov	x13, d18
	add	x13, x13, x13, lsl #5
	lsl	x13, x13, #2
	add	x15, x11, x13
	ldp	q3, q5, [x15]
	add	x15, x9, x13
	ldp	q6, q7, [x15]
	fmul.4s	v16, v1, v5
	fmul.4s	v17, v20, v3
	fmul.4s	v18, v2, v7
	fmul.4s	v19, v0, v6
	fsub.4s	v17, v17, v19
	fsub.4s	v16, v16, v18
	add	x15, x8, x12
	stp	q17, q16, [x15]
	fmul.4s	v1, v1, v7
	fmul.4s	v4, v20, v6
	fmul.4s	v2, v2, v5
	fmul.4s	v0, v0, v3
	fadd.4s	v0, v0, v4
	fadd.4s	v1, v2, v1
	add	x14, x8, x14
	stp	q0, q1, [x14]
	add	x14, x12, #32
	add	x15, x10, x14
	ldp	q0, q1, [x15]
	add	x15, x12, #164
	add	x16, x10, x15
	ldp	q2, q3, [x16]
	add	x16, x13, #32
	add	x17, x11, x16
	ldp	q4, q5, [x17]
	add	x16, x9, x16
	ldp	q6, q7, [x16]
	fmul.4s	v16, v1, v5
	fmul.4s	v17, v0, v4
	fmul.4s	v18, v3, v7
	fmul.4s	v19, v2, v6
	fsub.4s	v17, v17, v19
	fsub.4s	v16, v16, v18
	add	x14, x8, x14
	stp	q17, q16, [x14]
	fmul.4s	v1, v1, v7
	fmul.4s	v0, v0, v6
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v2, v0
	fadd.4s	v1, v3, v1
	add	x14, x8, x15
	stp	q0, q1, [x14]
	add	x14, x12, #64
	add	x15, x10, x14
	ldp	q0, q1, [x15]
	add	x15, x12, #196
	add	x16, x10, x15
	ldp	q2, q3, [x16]
	add	x16, x13, #64
	add	x17, x11, x16
	ldp	q4, q5, [x17]
	add	x16, x9, x16
	ldp	q6, q7, [x16]
	fmul.4s	v16, v1, v5
	fmul.4s	v17, v0, v4
	fmul.4s	v18, v3, v7
	fmul.4s	v19, v2, v6
	fsub.4s	v17, v17, v19
	fsub.4s	v16, v16, v18
	add	x14, x8, x14
	stp	q17, q16, [x14]
	fmul.4s	v1, v1, v7
	fmul.4s	v0, v0, v6
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v2, v0
	fadd.4s	v1, v3, v1
	add	x14, x8, x15
	stp	q0, q1, [x14]
	add	x14, x12, #96
	add	x15, x10, x14
	ldp	q1, q0, [x15]
	add	x15, x12, #228
	add	x16, x10, x15
	ldp	q3, q2, [x16]
	add	x16, x13, #96
	add	x17, x11, x16
	ldp	q5, q4, [x17]
	add	x16, x9, x16
	ldp	q7, q6, [x16]
	fmul.4s	v16, v1, v5
	fmul.4s	v17, v0, v4
	fmul.4s	v18, v3, v7
	fmul.4s	v19, v2, v6
	fsub.4s	v17, v17, v19
	fsub.4s	v16, v16, v18
	add	x14, x8, x14
	stp	q16, q17, [x14]
	fmul.4s	v1, v1, v7
	fmul.4s	v0, v0, v6
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v2, v0
	fadd.4s	v1, v3, v1
	add	x14, x8, x15
	stp	q1, q0, [x14]
	add	x14, x12, #128
	ldr	s0, [x10, x14]
	add	x1, x12, #260
	ldr	s1, [x10, x1]
	add	x10, x13, #128
	ldr	s2, [x11, x10]
	ldr	s3, [x9, x10]
	fmul.4s	v4, v0, v2
	fmul.4s	v5, v1, v3
	fsub.4s	v4, v4, v5
	str	s4, [x8, x14]
	fmul.4s	v0, v0, v3
	fmul.4s	v1, v1, v2
	fadd.4s	v0, v1, v0
	b	LBB0_5
LBB0_4:                                 ; %direct.false
	add	x0, x12, #32
	add	x13, x10, x0
	ldp	q6, q16, [x13]
	add	x17, x12, #64
	add	x13, x10, x17
	ldp	q4, q7, [x13]
	stp	q7, q4, [sp, #128]              ; 32-byte Folded Spill
	add	x16, x12, #96
	add	x1, x10, x16
	add	x15, x12, #132
	add	x13, x10, x15
	ldp	q17, q23, [x13]
	add	x14, x12, #164
	add	x13, x10, x14
	ldp	q30, q31, [x13]
	stp	q30, q6, [sp, #64]              ; 32-byte Folded Spill
	stp	q16, q31, [sp, #32]             ; 32-byte Folded Spill
	add	x13, x12, #196
	add	x2, x10, x13
	ldp	q19, q21, [x2]
	stp	q21, q19, [sp, #160]            ; 32-byte Folded Spill
	fmov	x2, d18
	add	x2, x2, x2, lsl #5
	lsl	x3, x2, #2
	add	x2, x11, x3
	ldp	q24, q25, [x2]
	add	x2, x3, #32
	add	x4, x11, x2
	ldp	q18, q12, [x4]
	stp	q12, q18, [sp, #96]             ; 32-byte Folded Spill
	add	x4, x3, #64
	add	x5, x11, x4
	ldp	q8, q9, [x5]
	stp	q9, q8, [sp, #192]              ; 32-byte Folded Spill
	add	x5, x9, x3
	ldp	q10, q11, [x5]
	add	x2, x9, x2
	ldp	q27, q29, [x2]
	add	x2, x9, x4
	fmul.4s	v0, v1, v25
	fmul.4s	v2, v20, v24
	fmul.4s	v3, v23, v11
	ldp	q26, q28, [x2]
	fmul.4s	v5, v17, v10
	fsub.4s	v2, v2, v5
	str	q2, [sp, #16]                   ; 16-byte Spill
	fsub.4s	v22, v0, v3
	fmul.4s	v0, v16, v12
	fmul.4s	v2, v6, v18
	fmul.4s	v3, v31, v29
	fmul.4s	v6, v30, v27
	fsub.4s	v2, v2, v6
	str	q2, [sp]                        ; 16-byte Spill
	fsub.4s	v18, v0, v3
	fmul.4s	v0, v7, v9
	fmul.4s	v2, v4, v8
	fmul.4s	v3, v21, v28
	fmul.4s	v30, v19, v26
	fsub.4s	v16, v2, v30
	fsub.4s	v7, v0, v3
	ldp	q30, q31, [x1]
	add	x2, x12, #228
	add	x1, x10, x2
	add	x4, x3, #96
	add	x5, x11, x4
	add	x4, x9, x4
	ldp	q8, q9, [x5]
	fmul.4s	v2, v30, v8
	ldp	q12, q13, [x1]
	ldp	q0, q3, [x4]
	fmul.4s	v14, v12, v0
	fsub.4s	v6, v2, v14
	fmul.4s	v2, v31, v9
	fmul.4s	v14, v13, v3
	fsub.4s	v5, v2, v14
	add	x4, x12, #128
	add	x1, x12, #260
	add	x3, x3, #128
	ldr	s14, [x10, x4]
	ldr	s15, [x11, x3]
	fmul.4s	v4, v14, v15
	ldr	s2, [x10, x1]
	ldr	s21, [x9, x3]
	fmul.4s	v19, v2, v21
	fsub.4s	v4, v4, v19
	fmul.4s	v1, v1, v11
	fmul.4s	v19, v20, v10
	fmul.4s	v20, v23, v25
	fmul.4s	v24, v17, v24
	add	x9, x8, x12
	ldr	q17, [sp, #16]                  ; 16-byte Reload
	stp	q17, q22, [x9]
	fadd.4s	v17, v24, v19
	fadd.4s	v1, v20, v1
	ldp	q19, q22, [sp, #32]             ; 32-byte Folded Reload
	fmul.4s	v19, v19, v29
	add	x9, x8, x0
	str	q18, [x9, #16]
	ldr	q18, [sp]                       ; 16-byte Reload
	str	q18, [x9]
	ldp	q18, q20, [sp, #80]             ; 32-byte Folded Reload
	fmul.4s	v18, v18, v27
	fmul.4s	v20, v22, v20
	ldr	q22, [sp, #112]                 ; 16-byte Reload
	ldr	q23, [sp, #64]                  ; 16-byte Reload
	fmul.4s	v22, v23, v22
	add	x9, x8, x17
	stp	q16, q7, [x9]
	fadd.4s	v7, v22, v18
	fadd.4s	v16, v20, v19
	ldr	q18, [sp, #128]                 ; 16-byte Reload
	fmul.4s	v18, v18, v28
	add	x9, x8, x16
	stp	q6, q5, [x9]
	ldp	q5, q6, [sp, #144]              ; 32-byte Folded Reload
	fmul.4s	v5, v5, v26
	str	s4, [x8, x4]
	ldp	q19, q4, [sp, #176]             ; 32-byte Folded Reload
	fmul.4s	v4, v6, v4
	ldr	q6, [sp, #208]                  ; 16-byte Reload
	fmul.4s	v6, v19, v6
	fadd.4s	v5, v6, v5
	add	x9, x8, x15
	stp	q17, q1, [x9]
	fadd.4s	v1, v4, v18
	fmul.4s	v3, v31, v3
	fmul.4s	v0, v30, v0
	add	x9, x8, x14
	stp	q7, q16, [x9]
	fmul.4s	v4, v13, v9
	fmul.4s	v6, v12, v8
	fadd.4s	v6, v6, v0
	add	x9, x8, x13
	stp	q5, q1, [x9]
	fadd.4s	v1, v4, v3
	fmul.4s	v0, v14, v21
	fmul.4s	v2, v2, v15
	fadd.4s	v0, v2, v0
	add	x9, x8, x2
	stp	q6, q1, [x9]
LBB0_5:                                 ; %common.ret
	str	s0, [x8, x1]
	ldp	x28, x27, [sp, #288]            ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #272]              ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #256]            ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #240]            ; 16-byte Folded Reload
	ldp	d15, d14, [sp, #224]            ; 16-byte Folded Reload
	add	sp, sp, #304
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_7:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_8:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_10:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_11:
	.quad	14                              ; 0xe
	.quad	15                              ; 0xf
lCPI1_12:
	.quad	10                              ; 0xa
	.quad	11                              ; 0xb
lCPI1_13:
	.quad	12                              ; 0xc
	.quad	13                              ; 0xd
lCPI1_14:
	.quad	8                               ; 0x8
	.quad	9                               ; 0x9
lCPI1_15:
	.quad	32                              ; 0x20
	.quad	0                               ; 0x0
lCPI1_16:
	.quad	22                              ; 0x16
	.quad	23                              ; 0x17
lCPI1_17:
	.quad	18                              ; 0x12
	.quad	19                              ; 0x13
lCPI1_18:
	.quad	20                              ; 0x14
	.quad	21                              ; 0x15
lCPI1_19:
	.quad	16                              ; 0x10
	.quad	17                              ; 0x11
lCPI1_20:
	.quad	64                              ; 0x40
	.quad	0                               ; 0x0
lCPI1_21:
	.quad	30                              ; 0x1e
	.quad	31                              ; 0x1f
lCPI1_22:
	.quad	26                              ; 0x1a
	.quad	27                              ; 0x1b
lCPI1_23:
	.quad	28                              ; 0x1c
	.quad	29                              ; 0x1d
lCPI1_24:
	.quad	24                              ; 0x18
	.quad	25                              ; 0x19
lCPI1_25:
	.quad	96                              ; 0x60
	.quad	0                               ; 0x0
lCPI1_26:
	.quad	152                             ; 0x98
	.quad	156                             ; 0x9c
lCPI1_27:
	.quad	144                             ; 0x90
	.quad	148                             ; 0x94
lCPI1_28:
	.quad	136                             ; 0x88
	.quad	140                             ; 0x8c
lCPI1_29:
	.quad	128                             ; 0x80
	.quad	132                             ; 0x84
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_30:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_970
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2208
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w27, w25, [x2, #44]
	ldp	w28, w24, [x2]
Lloh0:
	adrp	x8, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x8, lCPI1_0@PAGEOFF]
	str	q0, [sp, #656]                  ; 16-byte Spill
Lloh2:
	adrp	x8, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI1_1@PAGEOFF]
	str	q0, [sp, #640]                  ; 16-byte Spill
Lloh4:
	adrp	x8, lCPI1_2@PAGE
Lloh5:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #592]                  ; 16-byte Spill
Lloh6:
	adrp	x8, lCPI1_3@PAGE
Lloh7:
	ldr	q0, [x8, lCPI1_3@PAGEOFF]
	str	q0, [sp, #576]                  ; 16-byte Spill
Lloh8:
	adrp	x8, lCPI1_4@PAGE
Lloh9:
	ldr	q0, [x8, lCPI1_4@PAGEOFF]
	str	q0, [sp, #560]                  ; 16-byte Spill
Lloh10:
	adrp	x8, lCPI1_5@PAGE
Lloh11:
	ldr	q0, [x8, lCPI1_5@PAGEOFF]
	str	q0, [sp, #544]                  ; 16-byte Spill
Lloh12:
	adrp	x8, lCPI1_6@PAGE
Lloh13:
	ldr	q0, [x8, lCPI1_6@PAGEOFF]
	str	q0, [sp, #624]                  ; 16-byte Spill
	movi.2s	v8, #66
	movi.2s	v10, #33
	movi.8b	v11, #1
	ldp	w23, w22, [x2, #8]
	str	w25, [sp, #684]                 ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w28, #1
	cmp	w8, w27
	cset	w8, eq
	csinc	w28, wzr, w28, eq
	cinc	w9, w24, eq
	cmp	w9, w25
	cset	w10, eq
	ands	w8, w8, w10
	csel	w24, wzr, w9, ne
	add	w23, w23, w8
	subs	w19, w19, #1
	b.eq	LBB1_969
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x28, #5, #32
	cmp	x8, x22
	csel	x9, x8, xzr, ls
	subs	x10, x22, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x22, x9
	stp	w28, w24, [x20]
	str	w23, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x22, #2, hi
	csel	x26, x10, xzr, ls
	cmp	x26, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x25, x26, #3
	cbz	x25, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x25, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x25, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x25, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w26, #0x7
	cbz	w8, LBB1_968
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v9, w8
	ldp	q1, q0, [sp, #640]              ; 32-byte Folded Reload
	cmhi.4s	v7, v9, v1
	cmhi.4s	v22, v9, v0
	uzp1.8h	v17, v22, v7
	umaxv.8h	h0, v17
	fmov	w8, s0
	tbz	w8, #0, LBB1_968
; %bb.12:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x11, [x21]
	ldr	x10, [x21, #16]
	ldr	x9, [x21, #32]
	ldr	x8, [x21, #48]
	sshll.2d	v0, v22, #0
	sshll.2d	v1, v7, #0
	sshll2.2d	v23, v22, #0
	sshll2.2d	v24, v7, #0
	ldp	q2, q3, [sp, #576]              ; 32-byte Folded Reload
	and.16b	v31, v24, v3
	and.16b	v12, v23, v2
	ldr	q2, [sp, #560]                  ; 16-byte Reload
	and.16b	v13, v1, v2
	ldr	q1, [sp, #544]                  ; 16-byte Reload
	and.16b	v6, v0, v1
	ubfiz	w12, w28, #2, #27
	orr	w12, w12, w25
	dup.4s	v0, w12
	and.16b	v1, v22, v0
	and.16b	v0, v7, v0
	ushll2.2d	v27, v0, #0
	ushll2.2d	v29, v1, #0
	ushll.2d	v28, v0, #0
	ushll.2d	v2, v1, #0
	subs	x12, x11, x8
	cset	w13, hs
	lsr	x12, x12, #3
	cmp	x12, #560
	csel	w12, wzr, w13, ls
	subs	x13, x8, x11
	cset	w14, hs
	lsr	x13, x13, #3
	cmp	x13, #560
	csel	w13, wzr, w14, ls
	subs	x14, x10, x8
	cset	w15, hs
	lsr	x14, x14, #3
	cmp	x14, #560
	csel	w14, wzr, w15, ls
	subs	x15, x8, x10
	cset	w16, hs
	cmp	x15, #2243
	csel	w15, wzr, w16, ls
	subs	x16, x9, x8
	cset	w17, hs
	lsr	x16, x16, #3
	cmp	x16, #560
	csel	w16, wzr, w17, ls
	subs	x17, x8, x9
	cset	w0, hs
	cmp	x17, #2243
	csel	w17, wzr, w0, ls
	orr	w16, w16, w17
	xtn.2s	v1, v2
	cmp	w16, #1
	b.ne	LBB1_491
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w12, w12, w13
	cbz	w12, LBB1_491
; %bb.14:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w12, w14, w15
	cbz	w12, LBB1_491
; %bb.15:                               ; %direct.true.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q0, [sp, #624]                  ; 16-byte Reload
	and.16b	v0, v17, v0
	addv.8h	h16, v0
	fmov	w14, s16
	mov.16b	v0, v6
	umlal.2d	v0, v1, v8
	fmov	x12, d0
	lsl	x13, x12, #2
	add	x12, x11, x13
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w14, #0, LBB1_23
; %bb.16:                               ; %cond.load
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s2, [x12]
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_24
LBB1_17:                                ; %else2
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #2, LBB1_25
LBB1_18:                                ; %cond.load4
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x12, #8
	ld1.s	{ v2 }[2], [x15]
	tbnz	w14, #3, LBB1_26
LBB1_19:                                ; %else8
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #4, LBB1_27
LBB1_20:                                ; %cond.load10
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x12, #16
	ld1.s	{ v0 }[0], [x15]
	tbnz	w14, #5, LBB1_28
LBB1_21:                                ; %else14
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #6, LBB1_29
LBB1_22:                                ; %cond.load16
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x12, #24
	ld1.s	{ v0 }[2], [x15]
	tbnz	w14, #7, LBB1_30
	b	LBB1_31
LBB1_23:                                ; %else
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_17
LBB1_24:                                ; %cond.load1
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x12, #4
	ld1.s	{ v2 }[1], [x15]
	tbnz	w14, #2, LBB1_18
LBB1_25:                                ; %else5
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #3, LBB1_19
LBB1_26:                                ; %cond.load7
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x12, #12
	ld1.s	{ v2 }[3], [x15]
	tbnz	w14, #4, LBB1_20
LBB1_27:                                ; %else11
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #5, LBB1_21
LBB1_28:                                ; %cond.load13
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x12, #20
	ld1.s	{ v0 }[1], [x15]
	tbnz	w14, #6, LBB1_22
LBB1_29:                                ; %else17
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #7, LBB1_31
LBB1_30:                                ; %cond.load19
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x12, #28
	ld1.s	{ v0 }[3], [x12]
LBB1_31:                                ; %else20
                                        ;   in Loop: Header=BB1_4 Depth=1
	umull.2d	v7, v1, v8
	fmov	w16, s16
	fmov	x12, d7
	lsl	x12, x12, #2
	add	x14, x12, #132
	add	x15, x11, x14
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w16, #0, LBB1_39
; %bb.32:                               ; %cond.load23
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s4, [x15]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_40
LBB1_33:                                ; %else27
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_41
LBB1_34:                                ; %cond.load29
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #8
	ld1.s	{ v4 }[2], [x17]
	tbnz	w16, #3, LBB1_42
LBB1_35:                                ; %else33
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_43
LBB1_36:                                ; %cond.load35
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #16
	ld1.s	{ v3 }[0], [x17]
	tbnz	w16, #5, LBB1_44
LBB1_37:                                ; %else39
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_45
LBB1_38:                                ; %cond.load41
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #24
	ld1.s	{ v3 }[2], [x17]
	tbnz	w16, #7, LBB1_46
	b	LBB1_47
LBB1_39:                                ; %else24
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_33
LBB1_40:                                ; %cond.load26
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #4
	ld1.s	{ v4 }[1], [x17]
	tbnz	w16, #2, LBB1_34
LBB1_41:                                ; %else30
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_35
LBB1_42:                                ; %cond.load32
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #12
	ld1.s	{ v4 }[3], [x17]
	tbnz	w16, #4, LBB1_36
LBB1_43:                                ; %else36
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_37
LBB1_44:                                ; %cond.load38
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #20
	ld1.s	{ v3 }[1], [x17]
	tbnz	w16, #6, LBB1_38
LBB1_45:                                ; %else42
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_47
LBB1_46:                                ; %cond.load44
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x15, #28
	ld1.s	{ v3 }[3], [x15]
LBB1_47:                                ; %else45
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w17, s16
	mov.16b	v5, v6
	umlal.2d	v5, v1, v10
	fmov	x15, d5
	lsl	x15, x15, #2
	add	x16, x10, x15
	movi.2d	v18, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbz	w17, #0, LBB1_79
; %bb.48:                               ; %cond.load48
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s18, [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_80
LBB1_49:                                ; %else52
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #2, LBB1_81
LBB1_50:                                ; %cond.load54
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #8
	ld1.s	{ v18 }[2], [x0]
	tbnz	w17, #3, LBB1_82
LBB1_51:                                ; %else58
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #4, LBB1_83
LBB1_52:                                ; %cond.load60
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #16
	ld1.s	{ v5 }[0], [x0]
	tbnz	w17, #5, LBB1_84
LBB1_53:                                ; %else64
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #6, LBB1_85
LBB1_54:                                ; %cond.load66
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #24
	ld1.s	{ v5 }[2], [x0]
	tbnz	w17, #7, LBB1_86
LBB1_55:                                ; %else70
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w16, s16
	add	x15, x9, x15
	movi.2d	v20, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w16, #0, LBB1_87
LBB1_56:                                ; %cond.load73
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s20, [x15]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_88
LBB1_57:                                ; %else77
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_89
LBB1_58:                                ; %cond.load79
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #8
	ld1.s	{ v20 }[2], [x17]
	tbnz	w16, #3, LBB1_90
LBB1_59:                                ; %else83
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_91
LBB1_60:                                ; %cond.load85
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #16
	ld1.s	{ v19 }[0], [x17]
	tbnz	w16, #5, LBB1_92
LBB1_61:                                ; %else89
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_93
LBB1_62:                                ; %cond.load91
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #24
	ld1.s	{ v19 }[2], [x17]
	tbnz	w16, #7, LBB1_94
LBB1_63:                                ; %else95
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w15, s16
	fmul.4s	v21, v2, v18
	fmul.4s	v22, v4, v20
	fsub.4s	v21, v21, v22
	add	x13, x8, x13
	tbz	w15, #0, LBB1_95
LBB1_64:                                ; %cond.store
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s21, [x13]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_96
LBB1_65:                                ; %else100
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #2, LBB1_97
LBB1_66:                                ; %cond.store101
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #8
	st1.s	{ v21 }[2], [x16]
	tbnz	w15, #3, LBB1_98
LBB1_67:                                ; %else104
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v21, v0, v5
	fmul.4s	v22, v3, v19
	fsub.4s	v21, v21, v22
	tbz	w15, #4, LBB1_99
LBB1_68:                                ; %cond.store105
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s21, [x13, #16]
	tbnz	w15, #5, LBB1_100
LBB1_69:                                ; %else108
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #6, LBB1_101
LBB1_70:                                ; %cond.store109
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #24
	st1.s	{ v21 }[2], [x16]
	tbnz	w15, #7, LBB1_102
LBB1_71:                                ; %else112
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w15, s16
	fmul.4s	v2, v2, v20
	fmul.4s	v4, v4, v18
	fadd.4s	v2, v4, v2
	add	x13, x8, x14
	tbz	w15, #0, LBB1_103
LBB1_72:                                ; %cond.store114
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s2, [x13]
	and	w14, w15, #0xff
	tbnz	w14, #1, LBB1_104
LBB1_73:                                ; %else117
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #2, LBB1_105
LBB1_74:                                ; %cond.store118
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #8
	st1.s	{ v2 }[2], [x15]
	tbnz	w14, #3, LBB1_106
LBB1_75:                                ; %else121
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v0, v0, v19
	fmul.4s	v2, v3, v5
	fadd.4s	v0, v2, v0
	tbz	w14, #4, LBB1_107
LBB1_76:                                ; %cond.store122
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x13, #16]
	tbnz	w14, #5, LBB1_108
LBB1_77:                                ; %else125
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #6, LBB1_109
LBB1_78:                                ; %cond.store126
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #24
	st1.s	{ v0 }[2], [x15]
	tbnz	w14, #7, LBB1_110
	b	LBB1_111
LBB1_79:                                ; %else49
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_49
LBB1_80:                                ; %cond.load51
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #4
	ld1.s	{ v18 }[1], [x0]
	tbnz	w17, #2, LBB1_50
LBB1_81:                                ; %else55
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #3, LBB1_51
LBB1_82:                                ; %cond.load57
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #12
	ld1.s	{ v18 }[3], [x0]
	tbnz	w17, #4, LBB1_52
LBB1_83:                                ; %else61
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #5, LBB1_53
LBB1_84:                                ; %cond.load63
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #20
	ld1.s	{ v5 }[1], [x0]
	tbnz	w17, #6, LBB1_54
LBB1_85:                                ; %else67
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #7, LBB1_55
LBB1_86:                                ; %cond.load69
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x16, #28
	ld1.s	{ v5 }[3], [x16]
	fmov	w16, s16
	add	x15, x9, x15
	movi.2d	v20, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w16, #0, LBB1_56
LBB1_87:                                ; %else74
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_57
LBB1_88:                                ; %cond.load76
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #4
	ld1.s	{ v20 }[1], [x17]
	tbnz	w16, #2, LBB1_58
LBB1_89:                                ; %else80
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_59
LBB1_90:                                ; %cond.load82
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #12
	ld1.s	{ v20 }[3], [x17]
	tbnz	w16, #4, LBB1_60
LBB1_91:                                ; %else86
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_61
LBB1_92:                                ; %cond.load88
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #20
	ld1.s	{ v19 }[1], [x17]
	tbnz	w16, #6, LBB1_62
LBB1_93:                                ; %else92
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_63
LBB1_94:                                ; %cond.load94
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x15, #28
	ld1.s	{ v19 }[3], [x15]
	fmov	w15, s16
	fmul.4s	v21, v2, v18
	fmul.4s	v22, v4, v20
	fsub.4s	v21, v21, v22
	add	x13, x8, x13
	tbnz	w15, #0, LBB1_64
LBB1_95:                                ; %else98
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_65
LBB1_96:                                ; %cond.store99
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #4
	st1.s	{ v21 }[1], [x16]
	tbnz	w15, #2, LBB1_66
LBB1_97:                                ; %else102
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #3, LBB1_67
LBB1_98:                                ; %cond.store103
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #12
	st1.s	{ v21 }[3], [x16]
	fmul.4s	v21, v0, v5
	fmul.4s	v22, v3, v19
	fsub.4s	v21, v21, v22
	tbnz	w15, #4, LBB1_68
LBB1_99:                                ; %else106
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #5, LBB1_69
LBB1_100:                               ; %cond.store107
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #20
	st1.s	{ v21 }[1], [x16]
	tbnz	w15, #6, LBB1_70
LBB1_101:                               ; %else110
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #7, LBB1_71
LBB1_102:                               ; %cond.store111
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x13, #28
	st1.s	{ v21 }[3], [x13]
	fmov	w15, s16
	fmul.4s	v2, v2, v20
	fmul.4s	v4, v4, v18
	fadd.4s	v2, v4, v2
	add	x13, x8, x14
	tbnz	w15, #0, LBB1_72
LBB1_103:                               ; %else115
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w14, w15, #0xff
	tbz	w14, #1, LBB1_73
LBB1_104:                               ; %cond.store116
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #4
	st1.s	{ v2 }[1], [x15]
	tbnz	w14, #2, LBB1_74
LBB1_105:                               ; %else119
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #3, LBB1_75
LBB1_106:                               ; %cond.store120
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #12
	st1.s	{ v2 }[3], [x15]
	fmul.4s	v0, v0, v19
	fmul.4s	v2, v3, v5
	fadd.4s	v0, v2, v0
	tbnz	w14, #4, LBB1_76
LBB1_107:                               ; %else123
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #5, LBB1_77
LBB1_108:                               ; %cond.store124
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #20
	st1.s	{ v0 }[1], [x15]
	tbnz	w14, #6, LBB1_78
LBB1_109:                               ; %else127
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #7, LBB1_111
LBB1_110:                               ; %cond.store128
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x13, #28
	st1.s	{ v0 }[3], [x13]
LBB1_111:                               ; %else129
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w15, s16
	mov	w13, #8                         ; =0x8
	dup.2d	v0, x13
	orr.16b	v5, v6, v0
	add.2d	v0, v7, v5
	fmov	x13, d0
	lsl	x13, x13, #2
	add	x14, x11, x13
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w15, #0, LBB1_127
; %bb.112:                              ; %cond.load131
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s2, [x14]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_128
LBB1_113:                               ; %else135
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #2, LBB1_129
LBB1_114:                               ; %cond.load137
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #8
	ld1.s	{ v2 }[2], [x16]
	tbnz	w15, #3, LBB1_130
LBB1_115:                               ; %else141
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #4, LBB1_131
LBB1_116:                               ; %cond.load143
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #16
	ld1.s	{ v0 }[0], [x16]
	tbnz	w15, #5, LBB1_132
LBB1_117:                               ; %else147
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #6, LBB1_133
LBB1_118:                               ; %cond.load149
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #24
	ld1.s	{ v0 }[2], [x16]
	tbnz	w15, #7, LBB1_134
LBB1_119:                               ; %else153
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w16, s16
	add	x14, x12, #164
	add	x15, x11, x14
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w16, #0, LBB1_135
LBB1_120:                               ; %cond.load156
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s4, [x15]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_136
LBB1_121:                               ; %else160
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_137
LBB1_122:                               ; %cond.load162
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #8
	ld1.s	{ v4 }[2], [x17]
	tbnz	w16, #3, LBB1_138
LBB1_123:                               ; %else166
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_139
LBB1_124:                               ; %cond.load168
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #16
	ld1.s	{ v3 }[0], [x17]
	tbnz	w16, #5, LBB1_140
LBB1_125:                               ; %else172
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_141
LBB1_126:                               ; %cond.load174
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #24
	ld1.s	{ v3 }[2], [x17]
	tbnz	w16, #7, LBB1_142
	b	LBB1_143
LBB1_127:                               ; %else132
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_113
LBB1_128:                               ; %cond.load134
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #4
	ld1.s	{ v2 }[1], [x16]
	tbnz	w15, #2, LBB1_114
LBB1_129:                               ; %else138
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #3, LBB1_115
LBB1_130:                               ; %cond.load140
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #12
	ld1.s	{ v2 }[3], [x16]
	tbnz	w15, #4, LBB1_116
LBB1_131:                               ; %else144
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #5, LBB1_117
LBB1_132:                               ; %cond.load146
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #20
	ld1.s	{ v0 }[1], [x16]
	tbnz	w15, #6, LBB1_118
LBB1_133:                               ; %else150
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #7, LBB1_119
LBB1_134:                               ; %cond.load152
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x14, #28
	ld1.s	{ v0 }[3], [x14]
	fmov	w16, s16
	add	x14, x12, #164
	add	x15, x11, x14
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w16, #0, LBB1_120
LBB1_135:                               ; %else157
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_121
LBB1_136:                               ; %cond.load159
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #4
	ld1.s	{ v4 }[1], [x17]
	tbnz	w16, #2, LBB1_122
LBB1_137:                               ; %else163
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_123
LBB1_138:                               ; %cond.load165
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #12
	ld1.s	{ v4 }[3], [x17]
	tbnz	w16, #4, LBB1_124
LBB1_139:                               ; %else169
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_125
LBB1_140:                               ; %cond.load171
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #20
	ld1.s	{ v3 }[1], [x17]
	tbnz	w16, #6, LBB1_126
LBB1_141:                               ; %else175
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_143
LBB1_142:                               ; %cond.load177
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x15, #28
	ld1.s	{ v3 }[3], [x15]
LBB1_143:                               ; %else178
                                        ;   in Loop: Header=BB1_4 Depth=1
	umull.2d	v18, v1, v10
	fmov	w17, s16
	add.2d	v1, v18, v5
	fmov	x15, d1
	lsl	x15, x15, #2
	add	x16, x10, x15
	movi.2d	v5, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w17, #0, LBB1_175
; %bb.144:                              ; %cond.load181
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s5, [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_176
LBB1_145:                               ; %else185
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #2, LBB1_177
LBB1_146:                               ; %cond.load187
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #8
	ld1.s	{ v5 }[2], [x0]
	tbnz	w17, #3, LBB1_178
LBB1_147:                               ; %else191
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #4, LBB1_179
LBB1_148:                               ; %cond.load193
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #16
	ld1.s	{ v1 }[0], [x0]
	tbnz	w17, #5, LBB1_180
LBB1_149:                               ; %else197
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #6, LBB1_181
LBB1_150:                               ; %cond.load199
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #24
	ld1.s	{ v1 }[2], [x0]
	tbnz	w17, #7, LBB1_182
LBB1_151:                               ; %else203
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w16, s16
	add	x15, x9, x15
	movi.2d	v20, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w16, #0, LBB1_183
LBB1_152:                               ; %cond.load206
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s20, [x15]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_184
LBB1_153:                               ; %else210
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_185
LBB1_154:                               ; %cond.load212
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #8
	ld1.s	{ v20 }[2], [x17]
	tbnz	w16, #3, LBB1_186
LBB1_155:                               ; %else216
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_187
LBB1_156:                               ; %cond.load218
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #16
	ld1.s	{ v19 }[0], [x17]
	tbnz	w16, #5, LBB1_188
LBB1_157:                               ; %else222
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_189
LBB1_158:                               ; %cond.load224
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #24
	ld1.s	{ v19 }[2], [x17]
	tbnz	w16, #7, LBB1_190
LBB1_159:                               ; %else228
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w15, s16
	fmul.4s	v21, v2, v5
	fmul.4s	v22, v4, v20
	fsub.4s	v21, v21, v22
	add	x13, x8, x13
	tbz	w15, #0, LBB1_191
LBB1_160:                               ; %cond.store231
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s21, [x13]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_192
LBB1_161:                               ; %else234
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #2, LBB1_193
LBB1_162:                               ; %cond.store235
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #8
	st1.s	{ v21 }[2], [x16]
	tbnz	w15, #3, LBB1_194
LBB1_163:                               ; %else238
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v21, v0, v1
	fmul.4s	v22, v3, v19
	fsub.4s	v21, v21, v22
	tbz	w15, #4, LBB1_195
LBB1_164:                               ; %cond.store239
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s21, [x13, #16]
	tbnz	w15, #5, LBB1_196
LBB1_165:                               ; %else242
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #6, LBB1_197
LBB1_166:                               ; %cond.store243
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #24
	st1.s	{ v21 }[2], [x16]
	tbnz	w15, #7, LBB1_198
LBB1_167:                               ; %else246
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w15, s16
	fmul.4s	v2, v2, v20
	fmul.4s	v4, v4, v5
	fadd.4s	v2, v4, v2
	add	x13, x8, x14
	tbz	w15, #0, LBB1_199
LBB1_168:                               ; %cond.store248
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s2, [x13]
	and	w14, w15, #0xff
	tbnz	w14, #1, LBB1_200
LBB1_169:                               ; %else251
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #2, LBB1_201
LBB1_170:                               ; %cond.store252
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #8
	st1.s	{ v2 }[2], [x15]
	tbnz	w14, #3, LBB1_202
LBB1_171:                               ; %else255
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v0, v0, v19
	fmul.4s	v1, v3, v1
	fadd.4s	v0, v1, v0
	tbz	w14, #4, LBB1_203
LBB1_172:                               ; %cond.store256
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x13, #16]
	tbnz	w14, #5, LBB1_204
LBB1_173:                               ; %else259
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #6, LBB1_205
LBB1_174:                               ; %cond.store260
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #24
	st1.s	{ v0 }[2], [x15]
	tbnz	w14, #7, LBB1_206
	b	LBB1_207
LBB1_175:                               ; %else182
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_145
LBB1_176:                               ; %cond.load184
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #4
	ld1.s	{ v5 }[1], [x0]
	tbnz	w17, #2, LBB1_146
LBB1_177:                               ; %else188
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #3, LBB1_147
LBB1_178:                               ; %cond.load190
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #12
	ld1.s	{ v5 }[3], [x0]
	tbnz	w17, #4, LBB1_148
LBB1_179:                               ; %else194
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #5, LBB1_149
LBB1_180:                               ; %cond.load196
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #20
	ld1.s	{ v1 }[1], [x0]
	tbnz	w17, #6, LBB1_150
LBB1_181:                               ; %else200
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #7, LBB1_151
LBB1_182:                               ; %cond.load202
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x16, #28
	ld1.s	{ v1 }[3], [x16]
	fmov	w16, s16
	add	x15, x9, x15
	movi.2d	v20, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w16, #0, LBB1_152
LBB1_183:                               ; %else207
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_153
LBB1_184:                               ; %cond.load209
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #4
	ld1.s	{ v20 }[1], [x17]
	tbnz	w16, #2, LBB1_154
LBB1_185:                               ; %else213
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_155
LBB1_186:                               ; %cond.load215
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #12
	ld1.s	{ v20 }[3], [x17]
	tbnz	w16, #4, LBB1_156
LBB1_187:                               ; %else219
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_157
LBB1_188:                               ; %cond.load221
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #20
	ld1.s	{ v19 }[1], [x17]
	tbnz	w16, #6, LBB1_158
LBB1_189:                               ; %else225
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_159
LBB1_190:                               ; %cond.load227
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x15, #28
	ld1.s	{ v19 }[3], [x15]
	fmov	w15, s16
	fmul.4s	v21, v2, v5
	fmul.4s	v22, v4, v20
	fsub.4s	v21, v21, v22
	add	x13, x8, x13
	tbnz	w15, #0, LBB1_160
LBB1_191:                               ; %else232
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_161
LBB1_192:                               ; %cond.store233
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #4
	st1.s	{ v21 }[1], [x16]
	tbnz	w15, #2, LBB1_162
LBB1_193:                               ; %else236
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #3, LBB1_163
LBB1_194:                               ; %cond.store237
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #12
	st1.s	{ v21 }[3], [x16]
	fmul.4s	v21, v0, v1
	fmul.4s	v22, v3, v19
	fsub.4s	v21, v21, v22
	tbnz	w15, #4, LBB1_164
LBB1_195:                               ; %else240
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #5, LBB1_165
LBB1_196:                               ; %cond.store241
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #20
	st1.s	{ v21 }[1], [x16]
	tbnz	w15, #6, LBB1_166
LBB1_197:                               ; %else244
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #7, LBB1_167
LBB1_198:                               ; %cond.store245
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x13, #28
	st1.s	{ v21 }[3], [x13]
	fmov	w15, s16
	fmul.4s	v2, v2, v20
	fmul.4s	v4, v4, v5
	fadd.4s	v2, v4, v2
	add	x13, x8, x14
	tbnz	w15, #0, LBB1_168
LBB1_199:                               ; %else249
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w14, w15, #0xff
	tbz	w14, #1, LBB1_169
LBB1_200:                               ; %cond.store250
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #4
	st1.s	{ v2 }[1], [x15]
	tbnz	w14, #2, LBB1_170
LBB1_201:                               ; %else253
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #3, LBB1_171
LBB1_202:                               ; %cond.store254
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #12
	st1.s	{ v2 }[3], [x15]
	fmul.4s	v0, v0, v19
	fmul.4s	v1, v3, v1
	fadd.4s	v0, v1, v0
	tbnz	w14, #4, LBB1_172
LBB1_203:                               ; %else257
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #5, LBB1_173
LBB1_204:                               ; %cond.store258
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #20
	st1.s	{ v0 }[1], [x15]
	tbnz	w14, #6, LBB1_174
LBB1_205:                               ; %else261
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #7, LBB1_207
LBB1_206:                               ; %cond.store262
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x13, #28
	st1.s	{ v0 }[3], [x13]
LBB1_207:                               ; %else263
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w15, s16
	mov	w13, #16                        ; =0x10
	dup.2d	v0, x13
	orr.16b	v4, v6, v0
	add.2d	v0, v7, v4
	fmov	x13, d0
	lsl	x13, x13, #2
	add	x14, x11, x13
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w15, #0, LBB1_223
; %bb.208:                              ; %cond.load265
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s1, [x14]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_224
LBB1_209:                               ; %else269
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #2, LBB1_225
LBB1_210:                               ; %cond.load271
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #8
	ld1.s	{ v1 }[2], [x16]
	tbnz	w15, #3, LBB1_226
LBB1_211:                               ; %else275
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #4, LBB1_227
LBB1_212:                               ; %cond.load277
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #16
	ld1.s	{ v0 }[0], [x16]
	tbnz	w15, #5, LBB1_228
LBB1_213:                               ; %else281
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #6, LBB1_229
LBB1_214:                               ; %cond.load283
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #24
	ld1.s	{ v0 }[2], [x16]
	tbnz	w15, #7, LBB1_230
LBB1_215:                               ; %else287
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w16, s16
	add	x14, x12, #196
	add	x15, x11, x14
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbz	w16, #0, LBB1_231
LBB1_216:                               ; %cond.load290
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s3, [x15]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_232
LBB1_217:                               ; %else294
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_233
LBB1_218:                               ; %cond.load296
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #8
	ld1.s	{ v3 }[2], [x17]
	tbnz	w16, #3, LBB1_234
LBB1_219:                               ; %else300
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_235
LBB1_220:                               ; %cond.load302
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #16
	ld1.s	{ v2 }[0], [x17]
	tbnz	w16, #5, LBB1_236
LBB1_221:                               ; %else306
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_237
LBB1_222:                               ; %cond.load308
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #24
	ld1.s	{ v2 }[2], [x17]
	tbnz	w16, #7, LBB1_238
	b	LBB1_239
LBB1_223:                               ; %else266
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_209
LBB1_224:                               ; %cond.load268
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #4
	ld1.s	{ v1 }[1], [x16]
	tbnz	w15, #2, LBB1_210
LBB1_225:                               ; %else272
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #3, LBB1_211
LBB1_226:                               ; %cond.load274
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #12
	ld1.s	{ v1 }[3], [x16]
	tbnz	w15, #4, LBB1_212
LBB1_227:                               ; %else278
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #5, LBB1_213
LBB1_228:                               ; %cond.load280
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #20
	ld1.s	{ v0 }[1], [x16]
	tbnz	w15, #6, LBB1_214
LBB1_229:                               ; %else284
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #7, LBB1_215
LBB1_230:                               ; %cond.load286
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x14, #28
	ld1.s	{ v0 }[3], [x14]
	fmov	w16, s16
	add	x14, x12, #196
	add	x15, x11, x14
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w16, #0, LBB1_216
LBB1_231:                               ; %else291
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_217
LBB1_232:                               ; %cond.load293
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #4
	ld1.s	{ v3 }[1], [x17]
	tbnz	w16, #2, LBB1_218
LBB1_233:                               ; %else297
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_219
LBB1_234:                               ; %cond.load299
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #12
	ld1.s	{ v3 }[3], [x17]
	tbnz	w16, #4, LBB1_220
LBB1_235:                               ; %else303
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_221
LBB1_236:                               ; %cond.load305
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #20
	ld1.s	{ v2 }[1], [x17]
	tbnz	w16, #6, LBB1_222
LBB1_237:                               ; %else309
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_239
LBB1_238:                               ; %cond.load311
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x15, #28
	ld1.s	{ v2 }[3], [x15]
LBB1_239:                               ; %else312
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w17, s16
	add.2d	v4, v18, v4
	fmov	x15, d4
	lsl	x15, x15, #2
	add	x16, x10, x15
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w17, #0, LBB1_271
; %bb.240:                              ; %cond.load315
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s5, [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_272
LBB1_241:                               ; %else319
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #2, LBB1_273
LBB1_242:                               ; %cond.load321
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #8
	ld1.s	{ v5 }[2], [x0]
	tbnz	w17, #3, LBB1_274
LBB1_243:                               ; %else325
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #4, LBB1_275
LBB1_244:                               ; %cond.load327
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #16
	ld1.s	{ v4 }[0], [x0]
	tbnz	w17, #5, LBB1_276
LBB1_245:                               ; %else331
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #6, LBB1_277
LBB1_246:                               ; %cond.load333
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #24
	ld1.s	{ v4 }[2], [x0]
	tbnz	w17, #7, LBB1_278
LBB1_247:                               ; %else337
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w16, s16
	add	x15, x9, x15
	movi.2d	v20, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w16, #0, LBB1_279
LBB1_248:                               ; %cond.load340
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s20, [x15]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_280
LBB1_249:                               ; %else344
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_281
LBB1_250:                               ; %cond.load346
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #8
	ld1.s	{ v20 }[2], [x17]
	tbnz	w16, #3, LBB1_282
LBB1_251:                               ; %else350
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_283
LBB1_252:                               ; %cond.load352
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #16
	ld1.s	{ v19 }[0], [x17]
	tbnz	w16, #5, LBB1_284
LBB1_253:                               ; %else356
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_285
LBB1_254:                               ; %cond.load358
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #24
	ld1.s	{ v19 }[2], [x17]
	tbnz	w16, #7, LBB1_286
LBB1_255:                               ; %else362
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w15, s16
	fmul.4s	v21, v1, v5
	fmul.4s	v22, v3, v20
	fsub.4s	v21, v21, v22
	add	x13, x8, x13
	tbz	w15, #0, LBB1_287
LBB1_256:                               ; %cond.store365
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s21, [x13]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_288
LBB1_257:                               ; %else368
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #2, LBB1_289
LBB1_258:                               ; %cond.store369
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #8
	st1.s	{ v21 }[2], [x16]
	tbnz	w15, #3, LBB1_290
LBB1_259:                               ; %else372
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v21, v0, v4
	fmul.4s	v22, v2, v19
	fsub.4s	v21, v21, v22
	tbz	w15, #4, LBB1_291
LBB1_260:                               ; %cond.store373
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s21, [x13, #16]
	tbnz	w15, #5, LBB1_292
LBB1_261:                               ; %else376
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #6, LBB1_293
LBB1_262:                               ; %cond.store377
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #24
	st1.s	{ v21 }[2], [x16]
	tbnz	w15, #7, LBB1_294
LBB1_263:                               ; %else380
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w15, s16
	fmul.4s	v1, v1, v20
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v3, v1
	add	x13, x8, x14
	tbz	w15, #0, LBB1_295
LBB1_264:                               ; %cond.store382
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x13]
	and	w14, w15, #0xff
	tbnz	w14, #1, LBB1_296
LBB1_265:                               ; %else385
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #2, LBB1_297
LBB1_266:                               ; %cond.store386
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #8
	st1.s	{ v1 }[2], [x15]
	tbnz	w14, #3, LBB1_298
LBB1_267:                               ; %else389
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v0, v0, v19
	fmul.4s	v1, v2, v4
	fadd.4s	v0, v1, v0
	tbz	w14, #4, LBB1_299
LBB1_268:                               ; %cond.store390
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x13, #16]
	tbnz	w14, #5, LBB1_300
LBB1_269:                               ; %else393
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #6, LBB1_301
LBB1_270:                               ; %cond.store394
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #24
	st1.s	{ v0 }[2], [x15]
	tbnz	w14, #7, LBB1_302
	b	LBB1_303
LBB1_271:                               ; %else316
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_241
LBB1_272:                               ; %cond.load318
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #4
	ld1.s	{ v5 }[1], [x0]
	tbnz	w17, #2, LBB1_242
LBB1_273:                               ; %else322
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #3, LBB1_243
LBB1_274:                               ; %cond.load324
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #12
	ld1.s	{ v5 }[3], [x0]
	tbnz	w17, #4, LBB1_244
LBB1_275:                               ; %else328
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #5, LBB1_245
LBB1_276:                               ; %cond.load330
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #20
	ld1.s	{ v4 }[1], [x0]
	tbnz	w17, #6, LBB1_246
LBB1_277:                               ; %else334
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #7, LBB1_247
LBB1_278:                               ; %cond.load336
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x16, #28
	ld1.s	{ v4 }[3], [x16]
	fmov	w16, s16
	add	x15, x9, x15
	movi.2d	v20, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w16, #0, LBB1_248
LBB1_279:                               ; %else341
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_249
LBB1_280:                               ; %cond.load343
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #4
	ld1.s	{ v20 }[1], [x17]
	tbnz	w16, #2, LBB1_250
LBB1_281:                               ; %else347
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_251
LBB1_282:                               ; %cond.load349
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #12
	ld1.s	{ v20 }[3], [x17]
	tbnz	w16, #4, LBB1_252
LBB1_283:                               ; %else353
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_253
LBB1_284:                               ; %cond.load355
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #20
	ld1.s	{ v19 }[1], [x17]
	tbnz	w16, #6, LBB1_254
LBB1_285:                               ; %else359
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_255
LBB1_286:                               ; %cond.load361
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x15, #28
	ld1.s	{ v19 }[3], [x15]
	fmov	w15, s16
	fmul.4s	v21, v1, v5
	fmul.4s	v22, v3, v20
	fsub.4s	v21, v21, v22
	add	x13, x8, x13
	tbnz	w15, #0, LBB1_256
LBB1_287:                               ; %else366
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_257
LBB1_288:                               ; %cond.store367
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #4
	st1.s	{ v21 }[1], [x16]
	tbnz	w15, #2, LBB1_258
LBB1_289:                               ; %else370
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #3, LBB1_259
LBB1_290:                               ; %cond.store371
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #12
	st1.s	{ v21 }[3], [x16]
	fmul.4s	v21, v0, v4
	fmul.4s	v22, v2, v19
	fsub.4s	v21, v21, v22
	tbnz	w15, #4, LBB1_260
LBB1_291:                               ; %else374
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #5, LBB1_261
LBB1_292:                               ; %cond.store375
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x13, #20
	st1.s	{ v21 }[1], [x16]
	tbnz	w15, #6, LBB1_262
LBB1_293:                               ; %else378
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #7, LBB1_263
LBB1_294:                               ; %cond.store379
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x13, #28
	st1.s	{ v21 }[3], [x13]
	fmov	w15, s16
	fmul.4s	v1, v1, v20
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v3, v1
	add	x13, x8, x14
	tbnz	w15, #0, LBB1_264
LBB1_295:                               ; %else383
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w14, w15, #0xff
	tbz	w14, #1, LBB1_265
LBB1_296:                               ; %cond.store384
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #4
	st1.s	{ v1 }[1], [x15]
	tbnz	w14, #2, LBB1_266
LBB1_297:                               ; %else387
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #3, LBB1_267
LBB1_298:                               ; %cond.store388
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #12
	st1.s	{ v1 }[3], [x15]
	fmul.4s	v0, v0, v19
	fmul.4s	v1, v2, v4
	fadd.4s	v0, v1, v0
	tbnz	w14, #4, LBB1_268
LBB1_299:                               ; %else391
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #5, LBB1_269
LBB1_300:                               ; %cond.store392
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #20
	st1.s	{ v0 }[1], [x15]
	tbnz	w14, #6, LBB1_270
LBB1_301:                               ; %else395
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #7, LBB1_303
LBB1_302:                               ; %cond.store396
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x13, #28
	st1.s	{ v0 }[3], [x13]
LBB1_303:                               ; %else397
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w15, s16
	mov	w13, #24                        ; =0x18
	dup.2d	v0, x13
	orr.16b	v4, v6, v0
	add.2d	v0, v7, v4
	fmov	x13, d0
	lsl	x13, x13, #2
	add	x14, x11, x13
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w15, #0, LBB1_319
; %bb.304:                              ; %cond.load399
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s1, [x14]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_320
LBB1_305:                               ; %else403
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #2, LBB1_321
LBB1_306:                               ; %cond.load405
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #8
	ld1.s	{ v1 }[2], [x16]
	tbnz	w15, #3, LBB1_322
LBB1_307:                               ; %else409
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #4, LBB1_323
LBB1_308:                               ; %cond.load411
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #16
	ld1.s	{ v0 }[0], [x16]
	tbnz	w15, #5, LBB1_324
LBB1_309:                               ; %else415
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #6, LBB1_325
LBB1_310:                               ; %cond.load417
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #24
	ld1.s	{ v0 }[2], [x16]
	tbnz	w15, #7, LBB1_326
LBB1_311:                               ; %else421
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w15, s16
	add	x12, x12, #228
	add	x14, x11, x12
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbz	w15, #0, LBB1_327
LBB1_312:                               ; %cond.load424
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s3, [x14]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_328
LBB1_313:                               ; %else428
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #2, LBB1_329
LBB1_314:                               ; %cond.load430
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #8
	ld1.s	{ v3 }[2], [x16]
	tbnz	w15, #3, LBB1_330
LBB1_315:                               ; %else434
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #4, LBB1_331
LBB1_316:                               ; %cond.load436
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #16
	ld1.s	{ v2 }[0], [x16]
	tbnz	w15, #5, LBB1_332
LBB1_317:                               ; %else440
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #6, LBB1_333
LBB1_318:                               ; %cond.load442
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #24
	ld1.s	{ v2 }[2], [x16]
	tbnz	w15, #7, LBB1_334
	b	LBB1_335
LBB1_319:                               ; %else400
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_305
LBB1_320:                               ; %cond.load402
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #4
	ld1.s	{ v1 }[1], [x16]
	tbnz	w15, #2, LBB1_306
LBB1_321:                               ; %else406
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #3, LBB1_307
LBB1_322:                               ; %cond.load408
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #12
	ld1.s	{ v1 }[3], [x16]
	tbnz	w15, #4, LBB1_308
LBB1_323:                               ; %else412
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #5, LBB1_309
LBB1_324:                               ; %cond.load414
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #20
	ld1.s	{ v0 }[1], [x16]
	tbnz	w15, #6, LBB1_310
LBB1_325:                               ; %else418
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #7, LBB1_311
LBB1_326:                               ; %cond.load420
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x14, #28
	ld1.s	{ v0 }[3], [x14]
	fmov	w15, s16
	add	x12, x12, #228
	add	x14, x11, x12
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w15, #0, LBB1_312
LBB1_327:                               ; %else425
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_313
LBB1_328:                               ; %cond.load427
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #4
	ld1.s	{ v3 }[1], [x16]
	tbnz	w15, #2, LBB1_314
LBB1_329:                               ; %else431
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #3, LBB1_315
LBB1_330:                               ; %cond.load433
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #12
	ld1.s	{ v3 }[3], [x16]
	tbnz	w15, #4, LBB1_316
LBB1_331:                               ; %else437
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #5, LBB1_317
LBB1_332:                               ; %cond.load439
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #20
	ld1.s	{ v2 }[1], [x16]
	tbnz	w15, #6, LBB1_318
LBB1_333:                               ; %else443
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #7, LBB1_335
LBB1_334:                               ; %cond.load445
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x14, #28
	ld1.s	{ v2 }[3], [x14]
LBB1_335:                               ; %else446
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w16, s16
	add.2d	v4, v18, v4
	fmov	x14, d4
	lsl	x14, x14, #2
	add	x15, x10, x14
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w16, #0, LBB1_367
; %bb.336:                              ; %cond.load449
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s5, [x15]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_368
LBB1_337:                               ; %else453
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_369
LBB1_338:                               ; %cond.load455
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #8
	ld1.s	{ v5 }[2], [x17]
	tbnz	w16, #3, LBB1_370
LBB1_339:                               ; %else459
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_371
LBB1_340:                               ; %cond.load461
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #16
	ld1.s	{ v4 }[0], [x17]
	tbnz	w16, #5, LBB1_372
LBB1_341:                               ; %else465
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_373
LBB1_342:                               ; %cond.load467
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #24
	ld1.s	{ v4 }[2], [x17]
	tbnz	w16, #7, LBB1_374
LBB1_343:                               ; %else471
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w15, s16
	add	x14, x9, x14
	movi.2d	v20, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w15, #0, LBB1_375
LBB1_344:                               ; %cond.load474
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s20, [x14]
	and	w15, w15, #0xff
	tbnz	w15, #1, LBB1_376
LBB1_345:                               ; %else478
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #2, LBB1_377
LBB1_346:                               ; %cond.load480
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #8
	ld1.s	{ v20 }[2], [x16]
	tbnz	w15, #3, LBB1_378
LBB1_347:                               ; %else484
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #4, LBB1_379
LBB1_348:                               ; %cond.load486
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #16
	ld1.s	{ v19 }[0], [x16]
	tbnz	w15, #5, LBB1_380
LBB1_349:                               ; %else490
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #6, LBB1_381
LBB1_350:                               ; %cond.load492
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #24
	ld1.s	{ v19 }[2], [x16]
	tbnz	w15, #7, LBB1_382
LBB1_351:                               ; %else496
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w14, s16
	fmul.4s	v21, v1, v5
	fmul.4s	v22, v3, v20
	fsub.4s	v21, v21, v22
	add	x13, x8, x13
	tbz	w14, #0, LBB1_383
LBB1_352:                               ; %cond.store499
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s21, [x13]
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_384
LBB1_353:                               ; %else502
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #2, LBB1_385
LBB1_354:                               ; %cond.store503
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #8
	st1.s	{ v21 }[2], [x15]
	tbnz	w14, #3, LBB1_386
LBB1_355:                               ; %else506
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v21, v0, v4
	fmul.4s	v22, v2, v19
	fsub.4s	v21, v21, v22
	tbz	w14, #4, LBB1_387
LBB1_356:                               ; %cond.store507
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s21, [x13, #16]
	tbnz	w14, #5, LBB1_388
LBB1_357:                               ; %else510
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #6, LBB1_389
LBB1_358:                               ; %cond.store511
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #24
	st1.s	{ v21 }[2], [x15]
	tbnz	w14, #7, LBB1_390
LBB1_359:                               ; %else514
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w13, s16
	fmul.4s	v1, v1, v20
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v3, v1
	add	x12, x8, x12
	tbz	w13, #0, LBB1_391
LBB1_360:                               ; %cond.store516
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x12]
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_392
LBB1_361:                               ; %else519
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_393
LBB1_362:                               ; %cond.store520
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #8
	st1.s	{ v1 }[2], [x14]
	tbnz	w13, #3, LBB1_394
LBB1_363:                               ; %else523
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v0, v0, v19
	fmul.4s	v1, v2, v4
	fadd.4s	v0, v1, v0
	tbz	w13, #4, LBB1_395
LBB1_364:                               ; %cond.store524
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x12, #16]
	tbnz	w13, #5, LBB1_396
LBB1_365:                               ; %else527
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_397
LBB1_366:                               ; %cond.store528
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #24
	st1.s	{ v0 }[2], [x14]
	tbnz	w13, #7, LBB1_398
	b	LBB1_399
LBB1_367:                               ; %else450
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_337
LBB1_368:                               ; %cond.load452
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #4
	ld1.s	{ v5 }[1], [x17]
	tbnz	w16, #2, LBB1_338
LBB1_369:                               ; %else456
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_339
LBB1_370:                               ; %cond.load458
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #12
	ld1.s	{ v5 }[3], [x17]
	tbnz	w16, #4, LBB1_340
LBB1_371:                               ; %else462
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_341
LBB1_372:                               ; %cond.load464
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x15, #20
	ld1.s	{ v4 }[1], [x17]
	tbnz	w16, #6, LBB1_342
LBB1_373:                               ; %else468
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_343
LBB1_374:                               ; %cond.load470
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x15, #28
	ld1.s	{ v4 }[3], [x15]
	fmov	w15, s16
	add	x14, x9, x14
	movi.2d	v20, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w15, #0, LBB1_344
LBB1_375:                               ; %else475
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w15, w15, #0xff
	tbz	w15, #1, LBB1_345
LBB1_376:                               ; %cond.load477
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #4
	ld1.s	{ v20 }[1], [x16]
	tbnz	w15, #2, LBB1_346
LBB1_377:                               ; %else481
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #3, LBB1_347
LBB1_378:                               ; %cond.load483
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #12
	ld1.s	{ v20 }[3], [x16]
	tbnz	w15, #4, LBB1_348
LBB1_379:                               ; %else487
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #5, LBB1_349
LBB1_380:                               ; %cond.load489
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x14, #20
	ld1.s	{ v19 }[1], [x16]
	tbnz	w15, #6, LBB1_350
LBB1_381:                               ; %else493
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #7, LBB1_351
LBB1_382:                               ; %cond.load495
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x14, #28
	ld1.s	{ v19 }[3], [x14]
	fmov	w14, s16
	fmul.4s	v21, v1, v5
	fmul.4s	v22, v3, v20
	fsub.4s	v21, v21, v22
	add	x13, x8, x13
	tbnz	w14, #0, LBB1_352
LBB1_383:                               ; %else500
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_353
LBB1_384:                               ; %cond.store501
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #4
	st1.s	{ v21 }[1], [x15]
	tbnz	w14, #2, LBB1_354
LBB1_385:                               ; %else504
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #3, LBB1_355
LBB1_386:                               ; %cond.store505
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #12
	st1.s	{ v21 }[3], [x15]
	fmul.4s	v21, v0, v4
	fmul.4s	v22, v2, v19
	fsub.4s	v21, v21, v22
	tbnz	w14, #4, LBB1_356
LBB1_387:                               ; %else508
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #5, LBB1_357
LBB1_388:                               ; %cond.store509
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x13, #20
	st1.s	{ v21 }[1], [x15]
	tbnz	w14, #6, LBB1_358
LBB1_389:                               ; %else512
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #7, LBB1_359
LBB1_390:                               ; %cond.store513
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x13, #28
	st1.s	{ v21 }[3], [x13]
	fmov	w13, s16
	fmul.4s	v1, v1, v20
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v3, v1
	add	x12, x8, x12
	tbnz	w13, #0, LBB1_360
LBB1_391:                               ; %else517
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_361
LBB1_392:                               ; %cond.store518
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #4
	st1.s	{ v1 }[1], [x14]
	tbnz	w13, #2, LBB1_362
LBB1_393:                               ; %else521
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_363
LBB1_394:                               ; %cond.store522
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #12
	st1.s	{ v1 }[3], [x14]
	fmul.4s	v0, v0, v19
	fmul.4s	v1, v2, v4
	fadd.4s	v0, v1, v0
	tbnz	w13, #4, LBB1_364
LBB1_395:                               ; %else525
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #5, LBB1_365
LBB1_396:                               ; %cond.store526
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #20
	st1.s	{ v0 }[1], [x14]
	tbnz	w13, #6, LBB1_366
LBB1_397:                               ; %else529
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_399
LBB1_398:                               ; %cond.store530
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x12, #28
	st1.s	{ v0 }[3], [x12]
LBB1_399:                               ; %else531
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v0, v17
	and.8b	v1, v0, v11
	umov.b	w13, v1[0]
	movi.2d	v22, #0000000000000000
	mov.b	v22[0], v0[0]
	umaxv.8b	b1, v22
	fmov	w15, s1
	rbit	w12, w13
	clz	w12, w12
	tst	w15, #0x1
	csel	w12, w12, wzr, ne
	mov	w14, #32                        ; =0x20
	dup.2d	v24, x14
	orr.16b	v23, v6, v24
	add.2d	v2, v7, v23
	movi.2d	v1, #0000000000000000
	mov.b	v1[0], v0[0]
	ushll.2d	v0, v1, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	and.16b	v0, v0, v2
	movi.2d	v1, #0000000000000000
	stp	q1, q1, [sp, #976]
	stp	q0, q1, [sp, #944]
	and	x14, x12, #0x7
	add	x16, sp, #944
	ldr	x14, [x16, x14, lsl #3]
	sub	x14, x14, x12
	add	x14, x11, x14, lsl #2
	movi.2d	v0, #0000000000000000
	tbz	w15, #0, LBB1_407
; %bb.400:                              ; %cond.load533
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s1, [x14]
	tbnz	w13, #1, LBB1_408
LBB1_401:                               ; %else537
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_409
LBB1_402:                               ; %cond.load539
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #8
	ld1.s	{ v1 }[2], [x15]
	tbnz	w13, #3, LBB1_410
LBB1_403:                               ; %else543
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_411
LBB1_404:                               ; %cond.load545
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #16
	ld1.s	{ v0 }[0], [x15]
	tbnz	w13, #5, LBB1_412
LBB1_405:                               ; %else549
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_413
LBB1_406:                               ; %cond.load551
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #24
	ld1.s	{ v0 }[2], [x15]
	tbnz	w13, #7, LBB1_414
	b	LBB1_415
LBB1_407:                               ; %else534
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #1, LBB1_401
LBB1_408:                               ; %cond.load536
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #4
	ld1.s	{ v1 }[1], [x15]
	tbnz	w13, #2, LBB1_402
LBB1_409:                               ; %else540
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_403
LBB1_410:                               ; %cond.load542
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #12
	ld1.s	{ v1 }[3], [x15]
	tbnz	w13, #4, LBB1_404
LBB1_411:                               ; %else546
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #5, LBB1_405
LBB1_412:                               ; %cond.load548
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #20
	ld1.s	{ v0 }[1], [x15]
	tbnz	w13, #6, LBB1_406
LBB1_413:                               ; %else552
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_415
LBB1_414:                               ; %cond.load554
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x14, #28
	ld1.s	{ v0 }[3], [x13]
LBB1_415:                               ; %else555
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.2s	v25, v29
	umull.2d	v17, v25, v8
	xtn.2s	v26, v28
	umull.2d	v19, v26, v8
	xtn.2s	v27, v27
	umull.2d	v20, v27, v8
	add.2d	v6, v6, v7
	add.2d	v5, v12, v17
	add.2d	v4, v13, v19
	add.2d	v3, v31, v20
	mov	w13, #65                        ; =0x41
	dup.2d	v7, x13
	add.2d	v3, v3, v7
	add.2d	v4, v4, v7
	add.2d	v5, v5, v7
	add.2d	v6, v6, v7
	mov	b7, v22[0]
	mov.b	v7[4], v22[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	mov	b16, v22[2]
	mov.b	v16[4], v22[3]
	and.16b	v7, v7, v6
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	and.16b	v21, v16, v5
	mov	b16, v22[4]
	mov.b	v16[4], v22[5]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	and.16b	v28, v16, v4
	mov	b16, v22[6]
	mov.b	v16[4], v22[7]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	and.16b	v29, v16, v3
Lloh14:
	adrp	x13, lCPI1_30@PAGE
Lloh15:
	ldr	d16, [x13, lCPI1_30@PAGEOFF]
	shl.8b	v30, v22, #7
	cmlt.8b	v30, v30, #0
	and.8b	v16, v30, v16
	addv.8b	b16, v16
	fmov	w13, s16
	stp	q28, q29, [sp, #912]
	stp	q7, q21, [sp, #880]
	and	x14, x12, #0x7
	add	x15, sp, #880
	ldr	x14, [x15, x14, lsl #3]
	sub	x14, x14, x12
	add	x11, x11, x14, lsl #2
	movi.2d	v21, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbz	w13, #0, LBB1_423
; %bb.416:                              ; %cond.load558
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s21, [x11]
	tbnz	w13, #1, LBB1_424
LBB1_417:                               ; %else562
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_425
LBB1_418:                               ; %cond.load564
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #8
	ld1.s	{ v21 }[2], [x14]
	tbnz	w13, #3, LBB1_426
LBB1_419:                               ; %else568
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_427
LBB1_420:                               ; %cond.load570
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #16
	ld1.s	{ v7 }[0], [x14]
	tbnz	w13, #5, LBB1_428
LBB1_421:                               ; %else574
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_429
LBB1_422:                               ; %cond.load576
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #24
	ld1.s	{ v7 }[2], [x14]
	tbnz	w13, #7, LBB1_430
	b	LBB1_431
LBB1_423:                               ; %else559
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #1, LBB1_417
LBB1_424:                               ; %cond.load561
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #4
	ld1.s	{ v21 }[1], [x14]
	tbnz	w13, #2, LBB1_418
LBB1_425:                               ; %else565
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_419
LBB1_426:                               ; %cond.load567
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #12
	ld1.s	{ v21 }[3], [x14]
	tbnz	w13, #4, LBB1_420
LBB1_427:                               ; %else571
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #5, LBB1_421
LBB1_428:                               ; %cond.load573
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #20
	ld1.s	{ v7 }[1], [x14]
	tbnz	w13, #6, LBB1_422
LBB1_429:                               ; %else577
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_431
LBB1_430:                               ; %cond.load579
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x11, #28
	ld1.s	{ v7 }[3], [x11]
LBB1_431:                               ; %else580
                                        ;   in Loop: Header=BB1_4 Depth=1
	umull.2d	v28, v25, v10
	umull.2d	v29, v26, v10
	umull.2d	v27, v27, v10
	orr.16b	v25, v31, v24
	orr.16b	v26, v12, v24
	orr.16b	v24, v13, v24
	add.2d	v27, v27, v25
	add.2d	v29, v29, v24
	add.2d	v28, v28, v26
	add.2d	v18, v18, v23
	mov	b23, v22[0]
	mov.b	v23[4], v22[1]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	and.16b	v18, v23, v18
	mov	b23, v22[2]
	mov.b	v23[4], v22[3]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	and.16b	v23, v23, v28
	mov	b28, v22[4]
	mov.b	v28[4], v22[5]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	mov	b30, v22[6]
	mov.b	v30[4], v22[7]
	and.16b	v22, v28, v29
	ushll.2d	v28, v30, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	and.16b	v27, v28, v27
	stp	q22, q27, [sp, #848]
	stp	q18, q23, [sp, #816]
	and	x11, x12, #0x7
	add	x13, sp, #816
	ldr	x11, [x13, x11, lsl #3]
	fmov	w13, s16
	sub	x11, x11, x12
	lsl	x11, x11, #2
	add	x10, x10, x11
	movi.2d	v22, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbz	w13, #0, LBB1_447
; %bb.432:                              ; %cond.load583
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s22, [x10]
	tbnz	w13, #1, LBB1_448
LBB1_433:                               ; %else587
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_449
LBB1_434:                               ; %cond.load589
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #8
	ld1.s	{ v22 }[2], [x14]
	tbnz	w13, #3, LBB1_450
LBB1_435:                               ; %else593
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_451
LBB1_436:                               ; %cond.load595
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #16
	ld1.s	{ v18 }[0], [x14]
	tbnz	w13, #5, LBB1_452
LBB1_437:                               ; %else599
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_453
LBB1_438:                               ; %cond.load601
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #24
	ld1.s	{ v18 }[2], [x14]
	tbnz	w13, #7, LBB1_454
LBB1_439:                               ; %else605
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, x11
	fmov	w10, s16
	movi.2d	v27, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbz	w10, #0, LBB1_455
LBB1_440:                               ; %cond.load608
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s27, [x9]
	tbnz	w10, #1, LBB1_456
LBB1_441:                               ; %else612
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_457
LBB1_442:                               ; %cond.load614
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v27 }[2], [x11]
	tbnz	w10, #3, LBB1_458
LBB1_443:                               ; %else618
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #4, LBB1_459
LBB1_444:                               ; %cond.load620
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v23 }[0], [x11]
	tbnz	w10, #5, LBB1_460
LBB1_445:                               ; %else624
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_461
LBB1_446:                               ; %cond.load626
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v23 }[2], [x11]
	tbnz	w10, #7, LBB1_462
	b	LBB1_463
LBB1_447:                               ; %else584
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #1, LBB1_433
LBB1_448:                               ; %cond.load586
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #4
	ld1.s	{ v22 }[1], [x14]
	tbnz	w13, #2, LBB1_434
LBB1_449:                               ; %else590
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_435
LBB1_450:                               ; %cond.load592
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #12
	ld1.s	{ v22 }[3], [x14]
	tbnz	w13, #4, LBB1_436
LBB1_451:                               ; %else596
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #5, LBB1_437
LBB1_452:                               ; %cond.load598
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #20
	ld1.s	{ v18 }[1], [x14]
	tbnz	w13, #6, LBB1_438
LBB1_453:                               ; %else602
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_439
LBB1_454:                               ; %cond.load604
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v18 }[3], [x10]
	add	x9, x9, x11
	fmov	w10, s16
	movi.2d	v27, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w10, #0, LBB1_440
LBB1_455:                               ; %else609
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #1, LBB1_441
LBB1_456:                               ; %cond.load611
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v27 }[1], [x11]
	tbnz	w10, #2, LBB1_442
LBB1_457:                               ; %else615
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_443
LBB1_458:                               ; %cond.load617
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v27 }[3], [x11]
	tbnz	w10, #4, LBB1_444
LBB1_459:                               ; %else621
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_445
LBB1_460:                               ; %cond.load623
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v23 }[1], [x11]
	tbnz	w10, #6, LBB1_446
LBB1_461:                               ; %else627
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_463
LBB1_462:                               ; %cond.load629
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v23 }[3], [x9]
LBB1_463:                               ; %else630
                                        ;   in Loop: Header=BB1_4 Depth=1
	add.2d	v19, v19, v24
	add.2d	v24, v17, v26
	add.2d	v20, v20, v25
	fmul.4s	v17, v1, v22
	fmul.4s	v25, v21, v27
	fsub.4s	v17, v17, v25
	stp	q2, q24, [sp, #752]
	stp	q19, q20, [sp, #784]
	and	x9, x12, #0x7
	add	x10, sp, #752
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x12
	add	x9, x8, x9, lsl #2
	fmov	w10, s16
	tbz	w10, #0, LBB1_471
; %bb.464:                              ; %cond.store633
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s17, [x9]
	tbnz	w10, #1, LBB1_472
LBB1_465:                               ; %else636
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_473
LBB1_466:                               ; %cond.store637
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v17 }[2], [x11]
	tbnz	w10, #3, LBB1_474
LBB1_467:                               ; %else640
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v2, v0, v18
	fmul.4s	v17, v7, v23
	fsub.4s	v2, v2, v17
	tbz	w10, #4, LBB1_475
LBB1_468:                               ; %cond.store641
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s2, [x9, #16]
	tbnz	w10, #5, LBB1_476
LBB1_469:                               ; %else644
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_477
LBB1_470:                               ; %cond.store645
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v2 }[2], [x11]
	tbnz	w10, #7, LBB1_478
	b	LBB1_479
LBB1_471:                               ; %else634
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #1, LBB1_465
LBB1_472:                               ; %cond.store635
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v17 }[1], [x11]
	tbnz	w10, #2, LBB1_466
LBB1_473:                               ; %else638
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_467
LBB1_474:                               ; %cond.store639
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v17 }[3], [x11]
	fmul.4s	v2, v0, v18
	fmul.4s	v17, v7, v23
	fsub.4s	v2, v2, v17
	tbnz	w10, #4, LBB1_468
LBB1_475:                               ; %else642
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_469
LBB1_476:                               ; %cond.store643
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v2 }[1], [x11]
	tbnz	w10, #6, LBB1_470
LBB1_477:                               ; %else646
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_479
LBB1_478:                               ; %cond.store647
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v2 }[3], [x9]
LBB1_479:                               ; %else648
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v1, v1, v27
	fmul.4s	v2, v21, v22
	fadd.4s	v1, v2, v1
	stp	q6, q5, [sp, #688]
	stp	q4, q3, [sp, #720]
	and	x9, x12, #0x7
	add	x10, sp, #688
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x12
	add	x8, x8, x9, lsl #2
	fmov	w9, s16
	tbz	w9, #0, LBB1_487
; %bb.480:                              ; %cond.store650
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x8]
	tbnz	w9, #1, LBB1_488
LBB1_481:                               ; %else653
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #2, LBB1_489
LBB1_482:                               ; %cond.store654
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #8
	st1.s	{ v1 }[2], [x10]
	tbnz	w9, #3, LBB1_490
LBB1_483:                               ; %else657
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v0, v0, v23
	fmul.4s	v1, v7, v18
	fadd.4s	v0, v1, v0
	tbz	w9, #4, LBB1_964
LBB1_484:                               ; %cond.store658
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x8, #16]
	tbnz	w9, #5, LBB1_965
LBB1_485:                               ; %else661
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #6, LBB1_966
LBB1_486:                               ; %cond.store662
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB1_967
	b	LBB1_968
LBB1_487:                               ; %else651
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #1, LBB1_481
LBB1_488:                               ; %cond.store652
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #4
	st1.s	{ v1 }[1], [x10]
	tbnz	w9, #2, LBB1_482
LBB1_489:                               ; %else655
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #3, LBB1_483
LBB1_490:                               ; %cond.store656
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #12
	st1.s	{ v1 }[3], [x10]
	fmul.4s	v0, v0, v23
	fmul.4s	v1, v7, v18
	fadd.4s	v0, v1, v0
	tbz	w9, #4, LBB1_964
	b	LBB1_484
LBB1_491:                               ; %direct.false.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q0, [sp, #624]                  ; 16-byte Reload
	and.16b	v0, v17, v0
	addv.8h	h0, v0
	fmov	w13, s0
	umull.2d	v1, v1, v8
	add.2d	v20, v1, v6
	fmov	x12, d20
	add	x12, x11, x12, lsl #2
                                        ; implicit-def: $q3
	tbz	w13, #0, LBB1_497
; %bb.492:                              ; %cond.load667
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s3, [x12]
	and	w13, w13, #0xff
	add	x3, sp, #2048
	add	x4, sp, #1888
	add	x5, sp, #1728
	add	x6, sp, #1568
	tbnz	w13, #1, LBB1_498
LBB1_493:                               ; %else671
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_499
LBB1_494:                               ; %cond.load673
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #8
	ld1.s	{ v3 }[2], [x14]
	tbnz	w13, #3, LBB1_500
LBB1_495:                               ; %else677
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_501
LBB1_496:                               ; %cond.load679
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #16
	ld1.s	{ v4 }[0], [x14]
	tbnz	w13, #5, LBB1_502
	b	LBB1_503
LBB1_497:                               ; %else668
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w13, w13, #0xff
	add	x3, sp, #2048
	add	x4, sp, #1888
	add	x5, sp, #1728
	add	x6, sp, #1568
	tbz	w13, #1, LBB1_493
LBB1_498:                               ; %cond.load670
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #4
	ld1.s	{ v3 }[1], [x14]
	tbnz	w13, #2, LBB1_494
LBB1_499:                               ; %else674
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_495
LBB1_500:                               ; %cond.load676
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #12
	ld1.s	{ v3 }[3], [x14]
	tbnz	w13, #4, LBB1_496
LBB1_501:                               ;   in Loop: Header=BB1_4 Depth=1
                                        ; implicit-def: $q4
	tbz	w13, #5, LBB1_503
LBB1_502:                               ; %cond.load682
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #20
	ld1.s	{ v4 }[1], [x14]
LBB1_503:                               ; %else683
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_505
; %bb.504:                              ; %cond.load685
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #24
	ld1.s	{ v4 }[2], [x14]
	movi.8b	v16, #1
	tbnz	w13, #7, LBB1_506
	b	LBB1_507
LBB1_505:                               ; %else686
                                        ;   in Loop: Header=BB1_4 Depth=1
	movi.8b	v16, #1
	tbz	w13, #7, LBB1_507
LBB1_506:                               ; %cond.load688
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x12, #28
	ld1.s	{ v4 }[3], [x12]
LBB1_507:                               ; %else689
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w13, s0
	str	q3, [sp, #2048]
	str	q4, [sp, #2064]
	mov	w12, #8                         ; =0x8
	dup.2d	v3, x12
	add.2d	v3, v20, v3
	str	q3, [sp, #528]                  ; 16-byte Spill
	fmov	x12, d3
	add	x12, x11, x12, lsl #2
                                        ; implicit-def: $q3
	tbz	w13, #0, LBB1_513
; %bb.508:                              ; %cond.load692
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s3, [x12]
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_514
LBB1_509:                               ; %else696
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_515
LBB1_510:                               ; %cond.load698
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #8
	ld1.s	{ v3 }[2], [x14]
	tbnz	w13, #3, LBB1_516
LBB1_511:                               ; %else702
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_517
LBB1_512:                               ; %cond.load704
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #16
	ld1.s	{ v4 }[0], [x14]
	tbnz	w13, #5, LBB1_518
	b	LBB1_519
LBB1_513:                               ; %else693
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_509
LBB1_514:                               ; %cond.load695
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #4
	ld1.s	{ v3 }[1], [x14]
	tbnz	w13, #2, LBB1_510
LBB1_515:                               ; %else699
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_511
LBB1_516:                               ; %cond.load701
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #12
	ld1.s	{ v3 }[3], [x14]
	tbnz	w13, #4, LBB1_512
LBB1_517:                               ;   in Loop: Header=BB1_4 Depth=1
                                        ; implicit-def: $q4
	tbz	w13, #5, LBB1_519
LBB1_518:                               ; %cond.load707
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #20
	ld1.s	{ v4 }[1], [x14]
LBB1_519:                               ; %else708
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_521
; %bb.520:                              ; %cond.load710
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #24
	ld1.s	{ v4 }[2], [x14]
	tbnz	w13, #7, LBB1_522
	b	LBB1_523
LBB1_521:                               ; %else711
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_523
LBB1_522:                               ; %cond.load713
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x12, #28
	ld1.s	{ v4 }[3], [x12]
LBB1_523:                               ; %else714
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w13, s0
	str	q3, [sp, #2080]
	str	q4, [sp, #2096]
	mov	w12, #16                        ; =0x10
	dup.2d	v3, x12
	add.2d	v3, v20, v3
	str	q3, [sp, #512]                  ; 16-byte Spill
	fmov	x12, d3
	add	x12, x11, x12, lsl #2
                                        ; implicit-def: $q3
	tbz	w13, #0, LBB1_529
; %bb.524:                              ; %cond.load717
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s3, [x12]
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_530
LBB1_525:                               ; %else721
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_531
LBB1_526:                               ; %cond.load723
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #8
	ld1.s	{ v3 }[2], [x14]
	tbnz	w13, #3, LBB1_532
LBB1_527:                               ; %else727
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_533
LBB1_528:                               ; %cond.load729
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #16
	ld1.s	{ v4 }[0], [x14]
	tbnz	w13, #5, LBB1_534
	b	LBB1_535
LBB1_529:                               ; %else718
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_525
LBB1_530:                               ; %cond.load720
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #4
	ld1.s	{ v3 }[1], [x14]
	tbnz	w13, #2, LBB1_526
LBB1_531:                               ; %else724
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_527
LBB1_532:                               ; %cond.load726
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #12
	ld1.s	{ v3 }[3], [x14]
	tbnz	w13, #4, LBB1_528
LBB1_533:                               ;   in Loop: Header=BB1_4 Depth=1
                                        ; implicit-def: $q4
	tbz	w13, #5, LBB1_535
LBB1_534:                               ; %cond.load732
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #20
	ld1.s	{ v4 }[1], [x14]
LBB1_535:                               ; %else733
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_537
; %bb.536:                              ; %cond.load735
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #24
	ld1.s	{ v4 }[2], [x14]
	tbnz	w13, #7, LBB1_538
	b	LBB1_539
LBB1_537:                               ; %else736
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_539
LBB1_538:                               ; %cond.load738
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x12, #28
	ld1.s	{ v4 }[3], [x12]
LBB1_539:                               ; %else739
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w13, s0
	str	q3, [sp, #2112]
	str	q4, [sp, #2128]
	mov	w12, #24                        ; =0x18
	dup.2d	v3, x12
	add.2d	v3, v20, v3
	str	q3, [sp, #496]                  ; 16-byte Spill
	fmov	x12, d3
	add	x12, x11, x12, lsl #2
                                        ; implicit-def: $q3
	tbz	w13, #0, LBB1_545
; %bb.540:                              ; %cond.load742
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s3, [x12]
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_546
LBB1_541:                               ; %else746
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_547
LBB1_542:                               ; %cond.load748
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #8
	ld1.s	{ v3 }[2], [x14]
	tbnz	w13, #3, LBB1_548
LBB1_543:                               ; %else752
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_549
LBB1_544:                               ; %cond.load754
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #16
	ld1.s	{ v4 }[0], [x14]
	tbnz	w13, #5, LBB1_550
	b	LBB1_551
LBB1_545:                               ; %else743
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_541
LBB1_546:                               ; %cond.load745
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #4
	ld1.s	{ v3 }[1], [x14]
	tbnz	w13, #2, LBB1_542
LBB1_547:                               ; %else749
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_543
LBB1_548:                               ; %cond.load751
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #12
	ld1.s	{ v3 }[3], [x14]
	tbnz	w13, #4, LBB1_544
LBB1_549:                               ;   in Loop: Header=BB1_4 Depth=1
                                        ; implicit-def: $q4
	tbz	w13, #5, LBB1_551
LBB1_550:                               ; %cond.load757
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #20
	ld1.s	{ v4 }[1], [x14]
LBB1_551:                               ; %else758
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_553
; %bb.552:                              ; %cond.load760
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x12, #24
	ld1.s	{ v4 }[2], [x14]
	tbnz	w13, #7, LBB1_554
	b	LBB1_555
LBB1_553:                               ; %else761
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_555
LBB1_554:                               ; %cond.load763
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x12, x12, #28
	ld1.s	{ v4 }[3], [x12]
LBB1_555:                               ; %else764
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v5, v17
	str	q3, [sp, #2144]
	str	q4, [sp, #2160]
	and.8b	v3, v5, v16
	umov.b	w13, v3[0]
	movi.2d	v17, #0000000000000000
	mov.b	v17[0], v5[0]
	umaxv.8b	b3, v17
	fmov	w17, s3
	rbit	w12, w13
	clz	w12, w12
	tst	w17, #0x1
	mov	w14, #32                        ; =0x20
	dup.2d	v25, x14
	csel	w12, w12, wzr, ne
	orr.16b	v3, v6, v25
	mov.16b	v11, v3
	add.2d	v3, v1, v3
	movi.2d	v4, #0000000000000000
	mov.b	v4[0], v5[0]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v3, v4, v3
	movi.2d	v4, #0000000000000000
	str	q4, [sp, #1472]
	str	q4, [sp, #1456]
	str	q4, [sp, #1440]
	str	q3, [sp, #1424]
	ubfiz	x14, x12, #3, #3
	add	x15, sp, #1424
	ldr	x15, [x15, x14]
	sub	x15, x15, x12
	add	x16, x11, x15, lsl #2
Lloh16:
	adrp	x15, lCPI1_26@PAGE
Lloh17:
	ldr	q3, [x15, lCPI1_26@PAGEOFF]
Lloh18:
	adrp	x15, lCPI1_27@PAGE
Lloh19:
	ldr	q4, [x15, lCPI1_27@PAGEOFF]
	str	q3, [sp, #1536]
	str	q4, [sp, #1520]
Lloh20:
	adrp	x15, lCPI1_28@PAGE
Lloh21:
	ldr	q3, [x15, lCPI1_28@PAGEOFF]
Lloh22:
	adrp	x15, lCPI1_29@PAGE
Lloh23:
	ldr	q4, [x15, lCPI1_29@PAGEOFF]
	str	q3, [sp, #1504]
	str	q4, [sp, #1488]
	add	x15, sp, #1488
	ldr	x15, [x15, x14]
	ubfiz	x14, x12, #2, #32
	sub	x15, x15, x14
	tst	w13, #0x1
	csel	x15, xzr, x15, eq
	add	x0, x3, x15
	ldp	q3, q4, [x0]
	tbz	w17, #0, LBB1_563
; %bb.556:                              ; %cond.load767
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v3 }[0], [x16]
	tbnz	w13, #1, LBB1_564
LBB1_557:                               ; %else771
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_565
LBB1_558:                               ; %cond.load773
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #8
	ld1.s	{ v3 }[2], [x17]
	tbnz	w13, #3, LBB1_566
LBB1_559:                               ; %else777
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_567
LBB1_560:                               ; %cond.load779
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #16
	ld1.s	{ v4 }[0], [x17]
	tbnz	w13, #5, LBB1_568
LBB1_561:                               ; %else783
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_569
LBB1_562:                               ; %cond.load785
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #24
	ld1.s	{ v4 }[2], [x17]
	tbnz	w13, #7, LBB1_570
	b	LBB1_571
LBB1_563:                               ; %else768
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #1, LBB1_557
LBB1_564:                               ; %cond.load770
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #4
	ld1.s	{ v3 }[1], [x17]
	tbnz	w13, #2, LBB1_558
LBB1_565:                               ; %else774
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_559
LBB1_566:                               ; %cond.load776
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #12
	ld1.s	{ v3 }[3], [x17]
	tbnz	w13, #4, LBB1_560
LBB1_567:                               ; %else780
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #5, LBB1_561
LBB1_568:                               ; %cond.load782
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #20
	ld1.s	{ v4 }[1], [x17]
	tbnz	w13, #6, LBB1_562
LBB1_569:                               ; %else786
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_571
LBB1_570:                               ; %cond.load788
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x16, #28
	ld1.s	{ v4 }[3], [x16]
LBB1_571:                               ; %else789
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v14, v22, #0
	and.16b	v16, v14, v1
	fmov	w17, s0
	add	x16, x3, x15
	stp	q3, q4, [x16]
	add.2d	v5, v6, v16
	mov	w16, #33                        ; =0x21
	dup.2d	v1, x16
	add.2d	v1, v5, v1
	str	q1, [sp, #480]                  ; 16-byte Spill
	fmov	x16, d1
	add	x16, x11, x16, lsl #2
                                        ; implicit-def: $q1
	tbz	w17, #0, LBB1_577
; %bb.572:                              ; %cond.load792
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s1, [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_578
LBB1_573:                               ; %else796
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #2, LBB1_579
LBB1_574:                               ; %cond.load798
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #8
	ld1.s	{ v1 }[2], [x0]
	tbnz	w17, #3, LBB1_580
LBB1_575:                               ; %else802
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #4, LBB1_581
LBB1_576:                               ; %cond.load804
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #16
	ld1.s	{ v3 }[0], [x0]
	tbnz	w17, #5, LBB1_582
	b	LBB1_583
LBB1_577:                               ; %else793
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_573
LBB1_578:                               ; %cond.load795
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #4
	ld1.s	{ v1 }[1], [x0]
	tbnz	w17, #2, LBB1_574
LBB1_579:                               ; %else799
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #3, LBB1_575
LBB1_580:                               ; %cond.load801
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #12
	ld1.s	{ v1 }[3], [x0]
	tbnz	w17, #4, LBB1_576
LBB1_581:                               ;   in Loop: Header=BB1_4 Depth=1
                                        ; implicit-def: $q3
	tbz	w17, #5, LBB1_583
LBB1_582:                               ; %cond.load807
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #20
	ld1.s	{ v3 }[1], [x0]
LBB1_583:                               ; %else808
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #6, LBB1_585
; %bb.584:                              ; %cond.load810
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #24
	ld1.s	{ v3 }[2], [x0]
	tbnz	w17, #7, LBB1_586
	b	LBB1_587
LBB1_585:                               ; %else811
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #7, LBB1_587
LBB1_586:                               ; %cond.load813
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x16, #28
	ld1.s	{ v3 }[3], [x16]
LBB1_587:                               ; %else814
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v15, v22, #0
Lloh24:
	adrp	x16, lCPI1_14@PAGE
Lloh25:
	ldr	q4, [x16, lCPI1_14@PAGEOFF]
	and.16b	v26, v15, v4
	fmov	w17, s0
	str	q1, [sp, #1888]
	str	q3, [sp, #1904]
	mov	w16, #33                        ; =0x21
	dup.2d	v1, x16
	add.2d	v1, v16, v1
	add.2d	v3, v1, v26
	str	q3, [sp, #464]                  ; 16-byte Spill
	fmov	x16, d3
	add	x16, x11, x16, lsl #2
                                        ; implicit-def: $q4
	tbz	w17, #0, LBB1_593
; %bb.588:                              ; %cond.load817
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s4, [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_594
LBB1_589:                               ; %else821
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #2, LBB1_595
LBB1_590:                               ; %cond.load823
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #8
	ld1.s	{ v4 }[2], [x0]
	tbnz	w17, #3, LBB1_596
LBB1_591:                               ; %else827
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q16, [sp, #448]                 ; 16-byte Spill
	tbz	w17, #4, LBB1_597
LBB1_592:                               ; %cond.load829
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #16
	ld1.s	{ v16 }[0], [x0]
	tbnz	w17, #5, LBB1_598
	b	LBB1_599
LBB1_593:                               ; %else818
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_589
LBB1_594:                               ; %cond.load820
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #4
	ld1.s	{ v4 }[1], [x0]
	tbnz	w17, #2, LBB1_590
LBB1_595:                               ; %else824
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #3, LBB1_591
LBB1_596:                               ; %cond.load826
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #12
	ld1.s	{ v4 }[3], [x0]
	str	q16, [sp, #448]                 ; 16-byte Spill
	tbnz	w17, #4, LBB1_592
LBB1_597:                               ;   in Loop: Header=BB1_4 Depth=1
                                        ; implicit-def: $q16
	tbz	w17, #5, LBB1_599
LBB1_598:                               ; %cond.load832
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #20
	ld1.s	{ v16 }[1], [x0]
LBB1_599:                               ; %else833
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #6, LBB1_601
; %bb.600:                              ; %cond.load835
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #24
	ld1.s	{ v16 }[2], [x0]
	tbnz	w17, #7, LBB1_602
	b	LBB1_603
LBB1_601:                               ; %else836
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #7, LBB1_603
LBB1_602:                               ; %cond.load838
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x16, #28
	ld1.s	{ v16 }[3], [x16]
LBB1_603:                               ; %else839
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v8, v22, #0
Lloh26:
	adrp	x16, lCPI1_19@PAGE
Lloh27:
	ldr	q3, [x16, lCPI1_19@PAGEOFF]
	and.16b	v3, v8, v3
	fmov	w17, s0
	str	q4, [sp, #1920]
	str	q16, [sp, #1936]
	add.2d	v4, v1, v3
	str	q4, [sp, #432]                  ; 16-byte Spill
	fmov	x16, d4
	add	x16, x11, x16, lsl #2
                                        ; implicit-def: $q16
	tbz	w17, #0, LBB1_609
; %bb.604:                              ; %cond.load842
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s16, [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_610
LBB1_605:                               ; %else846
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #2, LBB1_611
LBB1_606:                               ; %cond.load848
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #8
	ld1.s	{ v16 }[2], [x0]
	tbnz	w17, #3, LBB1_612
LBB1_607:                               ; %else852
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #4, LBB1_613
LBB1_608:                               ; %cond.load854
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #16
	ld1.s	{ v18 }[0], [x0]
	tbnz	w17, #5, LBB1_614
	b	LBB1_615
LBB1_609:                               ; %else843
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_605
LBB1_610:                               ; %cond.load845
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #4
	ld1.s	{ v16 }[1], [x0]
	tbnz	w17, #2, LBB1_606
LBB1_611:                               ; %else849
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #3, LBB1_607
LBB1_612:                               ; %cond.load851
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #12
	ld1.s	{ v16 }[3], [x0]
	tbnz	w17, #4, LBB1_608
LBB1_613:                               ;   in Loop: Header=BB1_4 Depth=1
                                        ; implicit-def: $q18
	tbz	w17, #5, LBB1_615
LBB1_614:                               ; %cond.load857
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #20
	ld1.s	{ v18 }[1], [x0]
LBB1_615:                               ; %else858
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #6, LBB1_617
; %bb.616:                              ; %cond.load860
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #24
	ld1.s	{ v18 }[2], [x0]
	tbnz	w17, #7, LBB1_618
	b	LBB1_619
LBB1_617:                               ; %else861
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #7, LBB1_619
LBB1_618:                               ; %cond.load863
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x16, #28
	ld1.s	{ v18 }[3], [x16]
LBB1_619:                               ; %else864
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v21, v22, #0
Lloh28:
	adrp	x16, lCPI1_24@PAGE
Lloh29:
	ldr	q4, [x16, lCPI1_24@PAGEOFF]
	and.16b	v4, v21, v4
	fmov	w17, s0
	str	q16, [sp, #1952]
	str	q18, [sp, #1968]
	add.2d	v0, v1, v4
	str	q0, [sp, #416]                  ; 16-byte Spill
	fmov	x16, d0
	add	x16, x11, x16, lsl #2
                                        ; implicit-def: $q0
	tbz	w17, #0, LBB1_625
; %bb.620:                              ; %cond.load867
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s0, [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_626
LBB1_621:                               ; %else871
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #2, LBB1_627
LBB1_622:                               ; %cond.load873
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #8
	ld1.s	{ v0 }[2], [x0]
	tbnz	w17, #3, LBB1_628
LBB1_623:                               ; %else877
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #4, LBB1_629
LBB1_624:                               ; %cond.load879
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #16
	ld1.s	{ v1 }[0], [x0]
	tbnz	w17, #5, LBB1_630
	b	LBB1_631
LBB1_625:                               ; %else868
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_621
LBB1_626:                               ; %cond.load870
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #4
	ld1.s	{ v0 }[1], [x0]
	tbnz	w17, #2, LBB1_622
LBB1_627:                               ; %else874
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #3, LBB1_623
LBB1_628:                               ; %cond.load876
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #12
	ld1.s	{ v0 }[3], [x0]
	tbnz	w17, #4, LBB1_624
LBB1_629:                               ;   in Loop: Header=BB1_4 Depth=1
                                        ; implicit-def: $q1
	tbz	w17, #5, LBB1_631
LBB1_630:                               ; %cond.load882
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #20
	ld1.s	{ v1 }[1], [x0]
LBB1_631:                               ; %else883
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #6, LBB1_633
; %bb.632:                              ; %cond.load885
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x0, x16, #24
	ld1.s	{ v1 }[2], [x0]
	tbnz	w17, #7, LBB1_634
	b	LBB1_635
LBB1_633:                               ; %else886
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w17, #7, LBB1_635
LBB1_634:                               ; %cond.load888
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x16, #28
	ld1.s	{ v1 }[3], [x16]
LBB1_635:                               ; %else889
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v30, v7, #0
	fmov	x16, d27
	add	x16, x16, x16, lsl #5
	lsl	x16, x16, #1
	fmov	d16, x16
	mov.d	x16, v27[1]
	add	x16, x16, x16, lsl #5
	lsl	x17, x16, #1
	mov.d	v16[1], x17
	fmov	x17, d28
	add	x17, x17, x17, lsl #5
	lsl	x17, x17, #1
	fmov	d18, x17
	mov.d	x17, v28[1]
	add	x17, x17, x17, lsl #5
	lsl	x0, x17, #1
	mov.d	v18[1], x0
	fmov	x0, d29
	add	x0, x0, x0, lsl #5
	lsl	x0, x0, #1
	fmov	d19, x0
	mov.d	x0, v29[1]
	add	x0, x0, x0, lsl #5
	lsl	x1, x0, #1
	mov.d	v19[1], x1
	and.16b	v19, v23, v19
	stp	q19, q30, [sp, #320]            ; 32-byte Folded Spill
	and.16b	v18, v30, v18
	and.16b	v16, v24, v16
	str	q0, [sp, #1984]
	str	q1, [sp, #2000]
	add.2d	v0, v12, v19
	stp	q16, q18, [sp, #288]            ; 32-byte Folded Spill
	add.2d	v1, v13, v18
	add.2d	v16, v31, v16
	mov	w1, #65                         ; =0x41
	dup.2d	v18, x1
	add.2d	v19, v16, v18
	add.2d	v16, v1, v18
	add.2d	v30, v0, v18
	add.2d	v1, v5, v18
	mov	b0, v17[0]
	mov.b	v0[4], v17[1]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	stp	q1, q30, [sp, #352]             ; 32-byte Folded Spill
	and.16b	v0, v0, v1
	mov	b1, v17[2]
	mov.b	v1[4], v17[3]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	b5, v17[4]
	mov.b	v5[4], v17[5]
	and.16b	v1, v1, v30
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	stp	q16, q19, [sp, #384]            ; 32-byte Folded Spill
	and.16b	v5, v5, v16
	mov	b16, v17[6]
	mov.b	v16[4], v17[7]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	and.16b	v16, v16, v19
Lloh30:
	adrp	x1, lCPI1_30@PAGE
Lloh31:
	ldr	d18, [x1, lCPI1_30@PAGEOFF]
	shl.8b	v19, v17, #7
	cmlt.8b	v19, v19, #0
	and.8b	v18, v19, v18
	addv.8b	b19, v18
	str	q16, [sp, #1392]
	str	q5, [sp, #1376]
	str	q1, [sp, #1360]
	str	q0, [sp, #1344]
	and	x1, x12, #0x7
	add	x2, sp, #1344
	ldr	x2, [x2, x1, lsl #3]
	fmov	w1, s19
	sub	x2, x2, x12
	add	x11, x11, x2, lsl #2
	add	x2, x4, x15
	ldp	q0, q1, [x2]
	tbz	w1, #0, LBB1_643
; %bb.636:                              ; %cond.load892
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v0 }[0], [x11]
	tbnz	w1, #1, LBB1_644
LBB1_637:                               ; %else896
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #2, LBB1_645
LBB1_638:                               ; %cond.load898
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #8
	ld1.s	{ v0 }[2], [x2]
	tbnz	w1, #3, LBB1_646
LBB1_639:                               ; %else902
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #4, LBB1_647
LBB1_640:                               ; %cond.load904
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #16
	ld1.s	{ v1 }[0], [x2]
	tbnz	w1, #5, LBB1_648
LBB1_641:                               ; %else908
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #6, LBB1_649
LBB1_642:                               ; %cond.load910
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #24
	ld1.s	{ v1 }[2], [x2]
	mov.16b	v18, v29
	tbnz	w1, #7, LBB1_650
	b	LBB1_651
LBB1_643:                               ; %else893
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #1, LBB1_637
LBB1_644:                               ; %cond.load895
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #4
	ld1.s	{ v0 }[1], [x2]
	tbnz	w1, #2, LBB1_638
LBB1_645:                               ; %else899
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #3, LBB1_639
LBB1_646:                               ; %cond.load901
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #12
	ld1.s	{ v0 }[3], [x2]
	tbnz	w1, #4, LBB1_640
LBB1_647:                               ; %else905
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #5, LBB1_641
LBB1_648:                               ; %cond.load907
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #20
	ld1.s	{ v1 }[1], [x2]
	tbnz	w1, #6, LBB1_642
LBB1_649:                               ; %else911
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.16b	v18, v29
	tbz	w1, #7, LBB1_651
LBB1_650:                               ; %cond.load913
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x11, #28
	ld1.s	{ v1 }[3], [x11]
LBB1_651:                               ; %else914
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q5, [sp, #656]                  ; 16-byte Reload
	cmhi.4s	v10, v9, v5
	uzp1.8h	v5, v10, v7
	ldr	q16, [sp, #624]                 ; 16-byte Reload
	and.16b	v5, v5, v16
	addv.8h	h9, v5
	fmov	w1, s9
	sshll.2d	v5, v10, #0
	add	x11, x4, x15
	stp	q0, q1, [x11]
	fmov	x11, d2
	add	x11, x11, x11, lsl #5
	fmov	d0, x11
	mov.d	x11, v2[1]
	add	x11, x11, x11, lsl #5
	mov.d	v0[1], x11
	and.16b	v30, v5, v0
	add.2d	v29, v30, v6
	fmov	x11, d29
	add	x11, x10, x11, lsl #2
	ldr	q0, [sp, #1744]
	ldr	q1, [sp, #1728]
	tbz	w1, #0, LBB1_659
; %bb.652:                              ; %cond.load917
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v1 }[0], [x11]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB1_660
LBB1_653:                               ; %else921
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #2, LBB1_661
LBB1_654:                               ; %cond.load923
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #8
	ld1.s	{ v1 }[2], [x2]
	tbnz	w1, #3, LBB1_662
LBB1_655:                               ; %else927
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #4, LBB1_663
LBB1_656:                               ; %cond.load929
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #16
	ld1.s	{ v0 }[0], [x2]
	tbnz	w1, #5, LBB1_664
LBB1_657:                               ; %else933
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #6, LBB1_665
LBB1_658:                               ; %cond.load935
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #24
	ld1.s	{ v0 }[2], [x2]
	mov.16b	v16, v28
	tbnz	w1, #7, LBB1_666
	b	LBB1_667
LBB1_659:                               ; %else918
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w1, w1, #0xff
	tbz	w1, #1, LBB1_653
LBB1_660:                               ; %cond.load920
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #4
	ld1.s	{ v1 }[1], [x2]
	tbnz	w1, #2, LBB1_654
LBB1_661:                               ; %else924
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #3, LBB1_655
LBB1_662:                               ; %cond.load926
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #12
	ld1.s	{ v1 }[3], [x2]
	tbnz	w1, #4, LBB1_656
LBB1_663:                               ; %else930
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #5, LBB1_657
LBB1_664:                               ; %cond.load932
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #20
	ld1.s	{ v0 }[1], [x2]
	tbnz	w1, #6, LBB1_658
LBB1_665:                               ; %else936
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.16b	v16, v28
	tbz	w1, #7, LBB1_667
LBB1_666:                               ; %cond.load938
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x11, #28
	ld1.s	{ v0 }[3], [x11]
LBB1_667:                               ; %else939
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w1, s9
	str	q1, [sp, #1728]
	str	q0, [sp, #1744]
	add.2d	v28, v30, v26
	fmov	x11, d28
	add	x11, x10, x11, lsl #2
	ldr	q0, [sp, #1776]
	ldr	q1, [sp, #1760]
	tbz	w1, #0, LBB1_675
; %bb.668:                              ; %cond.load942
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v1 }[0], [x11]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB1_676
LBB1_669:                               ; %else946
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #2, LBB1_677
LBB1_670:                               ; %cond.load948
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #8
	ld1.s	{ v1 }[2], [x2]
	tbnz	w1, #3, LBB1_678
LBB1_671:                               ; %else952
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #4, LBB1_679
LBB1_672:                               ; %cond.load954
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #16
	ld1.s	{ v0 }[0], [x2]
	tbnz	w1, #5, LBB1_680
LBB1_673:                               ; %else958
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #6, LBB1_681
LBB1_674:                               ; %cond.load960
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #24
	ld1.s	{ v0 }[2], [x2]
	tbnz	w1, #7, LBB1_682
	b	LBB1_683
LBB1_675:                               ; %else943
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w1, w1, #0xff
	tbz	w1, #1, LBB1_669
LBB1_676:                               ; %cond.load945
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #4
	ld1.s	{ v1 }[1], [x2]
	tbnz	w1, #2, LBB1_670
LBB1_677:                               ; %else949
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #3, LBB1_671
LBB1_678:                               ; %cond.load951
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #12
	ld1.s	{ v1 }[3], [x2]
	tbnz	w1, #4, LBB1_672
LBB1_679:                               ; %else955
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #5, LBB1_673
LBB1_680:                               ; %cond.load957
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #20
	ld1.s	{ v0 }[1], [x2]
	tbnz	w1, #6, LBB1_674
LBB1_681:                               ; %else961
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #7, LBB1_683
LBB1_682:                               ; %cond.load963
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x11, #28
	ld1.s	{ v0 }[3], [x11]
LBB1_683:                               ; %else964
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w1, s9
	str	q1, [sp, #1760]
	str	q0, [sp, #1776]
	add.2d	v26, v30, v3
	fmov	x11, d26
	add	x11, x10, x11, lsl #2
	ldr	q0, [sp, #1808]
	ldr	q1, [sp, #1792]
	tbz	w1, #0, LBB1_691
; %bb.684:                              ; %cond.load967
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v1 }[0], [x11]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB1_692
LBB1_685:                               ; %else971
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #2, LBB1_693
LBB1_686:                               ; %cond.load973
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #8
	ld1.s	{ v1 }[2], [x2]
	tbnz	w1, #3, LBB1_694
LBB1_687:                               ; %else977
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #4, LBB1_695
LBB1_688:                               ; %cond.load979
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #16
	ld1.s	{ v0 }[0], [x2]
	tbnz	w1, #5, LBB1_696
LBB1_689:                               ; %else983
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #6, LBB1_697
LBB1_690:                               ; %cond.load985
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #24
	ld1.s	{ v0 }[2], [x2]
	tbnz	w1, #7, LBB1_698
	b	LBB1_699
LBB1_691:                               ; %else968
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w1, w1, #0xff
	tbz	w1, #1, LBB1_685
LBB1_692:                               ; %cond.load970
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #4
	ld1.s	{ v1 }[1], [x2]
	tbnz	w1, #2, LBB1_686
LBB1_693:                               ; %else974
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #3, LBB1_687
LBB1_694:                               ; %cond.load976
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #12
	ld1.s	{ v1 }[3], [x2]
	tbnz	w1, #4, LBB1_688
LBB1_695:                               ; %else980
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #5, LBB1_689
LBB1_696:                               ; %cond.load982
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #20
	ld1.s	{ v0 }[1], [x2]
	tbnz	w1, #6, LBB1_690
LBB1_697:                               ; %else986
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #7, LBB1_699
LBB1_698:                               ; %cond.load988
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x11, #28
	ld1.s	{ v0 }[3], [x11]
LBB1_699:                               ; %else989
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	w1, s9
	str	q1, [sp, #1792]
	str	q0, [sp, #1808]
	add.2d	v3, v30, v4
	fmov	x11, d3
	add	x11, x10, x11, lsl #2
	ldr	q0, [sp, #1840]
	ldr	q1, [sp, #1824]
	tbz	w1, #0, LBB1_707
; %bb.700:                              ; %cond.load992
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v1 }[0], [x11]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB1_708
LBB1_701:                               ; %else996
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #2, LBB1_709
LBB1_702:                               ; %cond.load998
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #8
	ld1.s	{ v1 }[2], [x2]
	tbnz	w1, #3, LBB1_710
LBB1_703:                               ; %else1002
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #4, LBB1_711
LBB1_704:                               ; %cond.load1004
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #16
	ld1.s	{ v0 }[0], [x2]
	tbnz	w1, #5, LBB1_712
LBB1_705:                               ; %else1008
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #6, LBB1_713
LBB1_706:                               ; %cond.load1010
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #24
	ld1.s	{ v0 }[2], [x2]
	mov.16b	v2, v31
	tbnz	w1, #7, LBB1_714
	b	LBB1_715
LBB1_707:                               ; %else993
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w1, w1, #0xff
	tbz	w1, #1, LBB1_701
LBB1_708:                               ; %cond.load995
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #4
	ld1.s	{ v1 }[1], [x2]
	tbnz	w1, #2, LBB1_702
LBB1_709:                               ; %else999
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #3, LBB1_703
LBB1_710:                               ; %cond.load1001
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #12
	ld1.s	{ v1 }[3], [x2]
	tbnz	w1, #4, LBB1_704
LBB1_711:                               ; %else1005
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w1, #5, LBB1_705
LBB1_712:                               ; %cond.load1007
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x2, x11, #20
	ld1.s	{ v0 }[1], [x2]
	tbnz	w1, #6, LBB1_706
LBB1_713:                               ; %else1011
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.16b	v2, v31
	tbz	w1, #7, LBB1_715
LBB1_714:                               ; %cond.load1013
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x11, #28
	ld1.s	{ v0 }[3], [x11]
LBB1_715:                               ; %else1014
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr.16b	v31, v13, v25
	orr.16b	v13, v12, v25
	orr.16b	v12, v2, v25
	sshll2.2d	v2, v10, #0
	sshll.2d	v4, v7, #0
	fmov	x11, d18
	add	x11, x11, x11, lsl #5
	fmov	d6, x11
	mov.d	v6[1], x0
	fmov	x11, d16
	add	x11, x11, x11, lsl #5
	fmov	d16, x11
	mov.d	v16[1], x17
	fmov	x11, d27
	add	x11, x11, x11, lsl #5
	fmov	d18, x11
	mov.d	v18[1], x16
	and.16b	v18, v24, v18
	and.16b	v4, v4, v16
	and.16b	v2, v2, v6
	str	q1, [sp, #1824]
	str	q0, [sp, #1840]
	add.2d	v0, v18, v12
	str	q31, [sp, #272]                 ; 16-byte Spill
	add.2d	v1, v4, v31
	add.2d	v2, v2, v13
	add.2d	v4, v30, v11
	mov	b6, v17[0]
	mov.b	v6[4], v17[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v4, v6, v4
	mov	b6, v17[2]
	mov.b	v6[4], v17[3]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v2, v6, v2
	mov	b6, v17[4]
	mov.b	v6[4], v17[5]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v1, v6, v1
	mov	b6, v17[6]
	mov.b	v6[4], v17[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v0, v6, v0
	fmov	w16, s19
	str	q0, [sp, #1312]
	str	q1, [sp, #1296]
	str	q2, [sp, #1280]
	str	q4, [sp, #1264]
	and	x11, x12, #0x7
	add	x17, sp, #1264
	ldr	x11, [x17, x11, lsl #3]
	sub	x11, x11, x12
	lsl	x11, x11, #2
	add	x10, x10, x11
	add	x17, x5, x15
	ldp	q0, q1, [x17]
	tbz	w16, #0, LBB1_723
; %bb.716:                              ; %cond.load1017
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v0 }[0], [x10]
	tbnz	w16, #1, LBB1_724
LBB1_717:                               ; %else1021
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_725
LBB1_718:                               ; %cond.load1023
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #8
	ld1.s	{ v0 }[2], [x17]
	tbnz	w16, #3, LBB1_726
LBB1_719:                               ; %else1027
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_727
LBB1_720:                               ; %cond.load1029
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #16
	ld1.s	{ v1 }[0], [x17]
	tbnz	w16, #5, LBB1_728
LBB1_721:                               ; %else1033
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_729
LBB1_722:                               ; %cond.load1035
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #24
	ld1.s	{ v1 }[2], [x17]
	tbnz	w16, #7, LBB1_730
	b	LBB1_731
LBB1_723:                               ; %else1018
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #1, LBB1_717
LBB1_724:                               ; %cond.load1020
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #4
	ld1.s	{ v0 }[1], [x17]
	tbnz	w16, #2, LBB1_718
LBB1_725:                               ; %else1024
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_719
LBB1_726:                               ; %cond.load1026
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #12
	ld1.s	{ v0 }[3], [x17]
	tbnz	w16, #4, LBB1_720
LBB1_727:                               ; %else1030
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_721
LBB1_728:                               ; %cond.load1032
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #20
	ld1.s	{ v1 }[1], [x17]
	tbnz	w16, #6, LBB1_722
LBB1_729:                               ; %else1036
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_731
LBB1_730:                               ; %cond.load1038
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v1 }[3], [x10]
LBB1_731:                               ; %else1039
                                        ;   in Loop: Header=BB1_4 Depth=1
	and.16b	v2, v5, v29
	fmov	w16, s9
	add	x10, x5, x15
	stp	q0, q1, [x10]
	fmov	x10, d2
	add	x10, x9, x10, lsl #2
	ldr	q0, [sp, #1584]
	ldr	q1, [sp, #1568]
	tbz	w16, #0, LBB1_739
; %bb.732:                              ; %cond.load1042
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v1 }[0], [x10]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_740
LBB1_733:                               ; %else1046
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_741
LBB1_734:                               ; %cond.load1048
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #8
	ld1.s	{ v1 }[2], [x17]
	tbnz	w16, #3, LBB1_742
LBB1_735:                               ; %else1052
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_743
LBB1_736:                               ; %cond.load1054
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #16
	ld1.s	{ v0 }[0], [x17]
	tbnz	w16, #5, LBB1_744
LBB1_737:                               ; %else1058
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_745
LBB1_738:                               ; %cond.load1060
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #24
	ld1.s	{ v0 }[2], [x17]
	tbnz	w16, #7, LBB1_746
	b	LBB1_747
LBB1_739:                               ; %else1043
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_733
LBB1_740:                               ; %cond.load1045
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #4
	ld1.s	{ v1 }[1], [x17]
	tbnz	w16, #2, LBB1_734
LBB1_741:                               ; %else1049
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_735
LBB1_742:                               ; %cond.load1051
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #12
	ld1.s	{ v1 }[3], [x17]
	tbnz	w16, #4, LBB1_736
LBB1_743:                               ; %else1055
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_737
LBB1_744:                               ; %cond.load1057
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #20
	ld1.s	{ v0 }[1], [x17]
	tbnz	w16, #6, LBB1_738
LBB1_745:                               ; %else1061
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_747
LBB1_746:                               ; %cond.load1063
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v0 }[3], [x10]
LBB1_747:                               ; %else1064
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v2, v10, #0
	and.16b	v2, v2, v28
	fmov	w16, s9
	str	q1, [sp, #1568]
	str	q0, [sp, #1584]
	fmov	x10, d2
	add	x10, x9, x10, lsl #2
	ldr	q0, [sp, #1616]
	ldr	q1, [sp, #1600]
	tbz	w16, #0, LBB1_755
; %bb.748:                              ; %cond.load1067
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v1 }[0], [x10]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_756
LBB1_749:                               ; %else1071
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_757
LBB1_750:                               ; %cond.load1073
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #8
	ld1.s	{ v1 }[2], [x17]
	tbnz	w16, #3, LBB1_758
LBB1_751:                               ; %else1077
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_759
LBB1_752:                               ; %cond.load1079
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #16
	ld1.s	{ v0 }[0], [x17]
	tbnz	w16, #5, LBB1_760
LBB1_753:                               ; %else1083
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_761
LBB1_754:                               ; %cond.load1085
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #24
	ld1.s	{ v0 }[2], [x17]
	tbnz	w16, #7, LBB1_762
	b	LBB1_763
LBB1_755:                               ; %else1068
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_749
LBB1_756:                               ; %cond.load1070
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #4
	ld1.s	{ v1 }[1], [x17]
	tbnz	w16, #2, LBB1_750
LBB1_757:                               ; %else1074
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_751
LBB1_758:                               ; %cond.load1076
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #12
	ld1.s	{ v1 }[3], [x17]
	tbnz	w16, #4, LBB1_752
LBB1_759:                               ; %else1080
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_753
LBB1_760:                               ; %cond.load1082
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #20
	ld1.s	{ v0 }[1], [x17]
	tbnz	w16, #6, LBB1_754
LBB1_761:                               ; %else1086
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_763
LBB1_762:                               ; %cond.load1088
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v0 }[3], [x10]
LBB1_763:                               ; %else1089
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v2, v10, #0
	and.16b	v2, v2, v26
	fmov	w16, s9
	str	q1, [sp, #1600]
	str	q0, [sp, #1616]
	fmov	x10, d2
	add	x10, x9, x10, lsl #2
	ldr	q0, [sp, #1648]
	ldr	q1, [sp, #1632]
	tbz	w16, #0, LBB1_771
; %bb.764:                              ; %cond.load1092
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v1 }[0], [x10]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_772
LBB1_765:                               ; %else1096
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_773
LBB1_766:                               ; %cond.load1098
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #8
	ld1.s	{ v1 }[2], [x17]
	tbnz	w16, #3, LBB1_774
LBB1_767:                               ; %else1102
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_775
LBB1_768:                               ; %cond.load1104
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #16
	ld1.s	{ v0 }[0], [x17]
	tbnz	w16, #5, LBB1_776
LBB1_769:                               ; %else1108
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_777
LBB1_770:                               ; %cond.load1110
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #24
	ld1.s	{ v0 }[2], [x17]
	tbnz	w16, #7, LBB1_778
	b	LBB1_779
LBB1_771:                               ; %else1093
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_765
LBB1_772:                               ; %cond.load1095
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #4
	ld1.s	{ v1 }[1], [x17]
	tbnz	w16, #2, LBB1_766
LBB1_773:                               ; %else1099
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_767
LBB1_774:                               ; %cond.load1101
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #12
	ld1.s	{ v1 }[3], [x17]
	tbnz	w16, #4, LBB1_768
LBB1_775:                               ; %else1105
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_769
LBB1_776:                               ; %cond.load1107
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #20
	ld1.s	{ v0 }[1], [x17]
	tbnz	w16, #6, LBB1_770
LBB1_777:                               ; %else1111
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_779
LBB1_778:                               ; %cond.load1113
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v0 }[3], [x10]
LBB1_779:                               ; %else1114
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v2, v10, #0
	and.16b	v2, v2, v3
	fmov	w16, s9
	str	q1, [sp, #1632]
	str	q0, [sp, #1648]
	fmov	x10, d2
	add	x10, x9, x10, lsl #2
	ldr	q0, [sp, #1680]
	ldr	q1, [sp, #1664]
	tbz	w16, #0, LBB1_787
; %bb.780:                              ; %cond.load1117
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v1 }[0], [x10]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_788
LBB1_781:                               ; %else1121
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_789
LBB1_782:                               ; %cond.load1123
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #8
	ld1.s	{ v1 }[2], [x17]
	tbnz	w16, #3, LBB1_790
LBB1_783:                               ; %else1127
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_791
LBB1_784:                               ; %cond.load1129
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #16
	ld1.s	{ v0 }[0], [x17]
	tbnz	w16, #5, LBB1_792
LBB1_785:                               ; %else1133
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_793
LBB1_786:                               ; %cond.load1135
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #24
	ld1.s	{ v0 }[2], [x17]
	tbnz	w16, #7, LBB1_794
	b	LBB1_795
LBB1_787:                               ; %else1118
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_781
LBB1_788:                               ; %cond.load1120
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #4
	ld1.s	{ v1 }[1], [x17]
	tbnz	w16, #2, LBB1_782
LBB1_789:                               ; %else1124
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_783
LBB1_790:                               ; %cond.load1126
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #12
	ld1.s	{ v1 }[3], [x17]
	tbnz	w16, #4, LBB1_784
LBB1_791:                               ; %else1130
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_785
LBB1_792:                               ; %cond.load1132
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x10, #20
	ld1.s	{ v0 }[1], [x17]
	tbnz	w16, #6, LBB1_786
LBB1_793:                               ; %else1136
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_795
LBB1_794:                               ; %cond.load1138
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v0 }[3], [x10]
LBB1_795:                               ; %else1139
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q1, [sp, #1664]
	str	q0, [sp, #1680]
	add	x9, x9, x11
	add	x10, x6, x15
	ldp	q0, q1, [x10]
	fmov	w10, s19
	tbz	w10, #0, LBB1_803
; %bb.796:                              ; %cond.load1142
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v0 }[0], [x9]
	tbnz	w10, #1, LBB1_804
LBB1_797:                               ; %else1146
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_805
LBB1_798:                               ; %cond.load1148
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v0 }[2], [x11]
	tbnz	w10, #3, LBB1_806
LBB1_799:                               ; %else1152
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #4, LBB1_807
LBB1_800:                               ; %cond.load1154
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v1 }[0], [x11]
	tbnz	w10, #5, LBB1_808
LBB1_801:                               ; %else1158
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_809
LBB1_802:                               ; %cond.load1160
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v1 }[2], [x11]
	tbnz	w10, #7, LBB1_810
	b	LBB1_811
LBB1_803:                               ; %else1143
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #1, LBB1_797
LBB1_804:                               ; %cond.load1145
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v0 }[1], [x11]
	tbnz	w10, #2, LBB1_798
LBB1_805:                               ; %else1149
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_799
LBB1_806:                               ; %cond.load1151
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v0 }[3], [x11]
	tbnz	w10, #4, LBB1_800
LBB1_807:                               ; %else1155
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_801
LBB1_808:                               ; %cond.load1157
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v1 }[1], [x11]
	tbnz	w10, #6, LBB1_802
LBB1_809:                               ; %else1161
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_811
LBB1_810:                               ; %cond.load1163
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v1 }[3], [x9]
LBB1_811:                               ; %else1164
                                        ;   in Loop: Header=BB1_4 Depth=1
Lloh32:
	adrp	x9, lCPI1_10@PAGE
Lloh33:
	ldr	q2, [x9, lCPI1_10@PAGEOFF]
	and.16b	v3, v14, v2
	and.16b	v2, v14, v20
	fmov	w10, s9
	add	x9, x6, x15
	stp	q0, q1, [x9]
	fmov	x9, d3
	add	x11, x3, x9
	ldp	q0, q4, [x11]
	add	x11, x5, x9
	ldp	q1, q5, [x11]
	str	q0, [sp, #128]                  ; 16-byte Spill
	str	q1, [sp, #96]                   ; 16-byte Spill
	fmul.4s	v0, v0, v1
	add	x11, x4, x9
	ldp	q1, q6, [x11]
	add	x9, x6, x9
	ldp	q18, q16, [x9]
	stp	q18, q1, [sp, #48]              ; 32-byte Folded Spill
	fmul.4s	v1, v1, v18
	fsub.4s	v0, v0, v1
	and.16b	v0, v10, v0
	fmov	x9, d2
	add	x9, x8, x9, lsl #2
	tbz	w10, #0, LBB1_819
; %bb.812:                              ; %cond.store1167
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9]
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_820
LBB1_813:                               ; %else1170
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_821
LBB1_814:                               ; %cond.store1171
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v0 }[2], [x11]
	tbnz	w10, #3, LBB1_822
LBB1_815:                               ; %else1174
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v0, v4, v5
	fmul.4s	v1, v6, v16
	fsub.4s	v0, v0, v1
	and.16b	v0, v7, v0
	tbz	w10, #4, LBB1_823
LBB1_816:                               ; %cond.store1175
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9, #16]
	tbnz	w10, #5, LBB1_824
LBB1_817:                               ; %else1178
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_825
LBB1_818:                               ; %cond.store1179
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v0 }[2], [x11]
	stp	q5, q4, [sp, #240]              ; 32-byte Folded Spill
	str	d19, [sp, #616]                 ; 8-byte Spill
	tbnz	w10, #7, LBB1_826
	b	LBB1_827
LBB1_819:                               ; %else1168
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_813
LBB1_820:                               ; %cond.store1169
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v0 }[1], [x11]
	tbnz	w10, #2, LBB1_814
LBB1_821:                               ; %else1172
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_815
LBB1_822:                               ; %cond.store1173
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v0 }[3], [x11]
	fmul.4s	v0, v4, v5
	fmul.4s	v1, v6, v16
	fsub.4s	v0, v0, v1
	and.16b	v0, v7, v0
	tbnz	w10, #4, LBB1_816
LBB1_823:                               ; %else1176
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_817
LBB1_824:                               ; %cond.store1177
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v0 }[1], [x11]
	tbnz	w10, #6, LBB1_818
LBB1_825:                               ; %else1180
                                        ;   in Loop: Header=BB1_4 Depth=1
	stp	q5, q4, [sp, #240]              ; 32-byte Folded Spill
	str	d19, [sp, #616]                 ; 8-byte Spill
	tbz	w10, #7, LBB1_827
LBB1_826:                               ; %cond.store1181
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v0 }[3], [x9]
LBB1_827:                               ; %else1182
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q0, [sp, #528]                  ; 16-byte Reload
	and.16b	v4, v15, v0
Lloh34:
	adrp	x9, lCPI1_15@PAGE
Lloh35:
	ldr	q0, [x9, lCPI1_15@PAGEOFF]
	and.16b	v0, v15, v0
	fmov	w10, s9
	fmov	x9, d0
	add	x11, x3, x9
	ldp	q1, q0, [x11]
	add	x11, x5, x9
	ldp	q2, q18, [x11]
	stp	q2, q1, [sp, #16]               ; 32-byte Folded Spill
	fmul.4s	v1, v1, v2
	add	x11, x4, x9
	ldp	q19, q20, [x11]
	add	x9, x6, x9
	ldp	q2, q25, [x9]
	fmul.4s	v5, v19, v2
	fsub.4s	v1, v1, v5
	and.16b	v1, v10, v1
	fmov	x9, d4
	add	x9, x8, x9, lsl #2
	tbz	w10, #0, LBB1_835
; %bb.828:                              ; %cond.store1184
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x9]
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_836
LBB1_829:                               ; %else1187
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_837
LBB1_830:                               ; %cond.store1188
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v1 }[2], [x11]
	tbnz	w10, #3, LBB1_838
LBB1_831:                               ; %else1191
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v1, v0, v18
	fmul.4s	v4, v20, v25
	fsub.4s	v1, v1, v4
	and.16b	v1, v7, v1
	tbz	w10, #4, LBB1_839
LBB1_832:                               ; %cond.store1192
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x9, #16]
	tbnz	w10, #5, LBB1_840
LBB1_833:                               ; %else1195
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_841
LBB1_834:                               ; %cond.store1196
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v1 }[2], [x11]
	stp	q25, q18, [sp, #176]            ; 32-byte Folded Spill
	stp	q0, q16, [sp, #208]             ; 32-byte Folded Spill
	str	q6, [sp, #528]                  ; 16-byte Spill
	tbnz	w10, #7, LBB1_842
	b	LBB1_843
LBB1_835:                               ; %else1185
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_829
LBB1_836:                               ; %cond.store1186
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v1 }[1], [x11]
	tbnz	w10, #2, LBB1_830
LBB1_837:                               ; %else1189
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_831
LBB1_838:                               ; %cond.store1190
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v1 }[3], [x11]
	fmul.4s	v1, v0, v18
	fmul.4s	v4, v20, v25
	fsub.4s	v1, v1, v4
	and.16b	v1, v7, v1
	tbnz	w10, #4, LBB1_832
LBB1_839:                               ; %else1193
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_833
LBB1_840:                               ; %cond.store1194
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v1 }[1], [x11]
	tbnz	w10, #6, LBB1_834
LBB1_841:                               ; %else1197
                                        ;   in Loop: Header=BB1_4 Depth=1
	stp	q25, q18, [sp, #176]            ; 32-byte Folded Spill
	stp	q0, q16, [sp, #208]             ; 32-byte Folded Spill
	str	q6, [sp, #528]                  ; 16-byte Spill
	tbz	w10, #7, LBB1_843
LBB1_842:                               ; %cond.store1198
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v1 }[3], [x9]
LBB1_843:                               ; %else1199
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q0, [sp, #512]                  ; 16-byte Reload
	and.16b	v5, v8, v0
Lloh36:
	adrp	x9, lCPI1_20@PAGE
Lloh37:
	ldr	q1, [x9, lCPI1_20@PAGEOFF]
	and.16b	v1, v8, v1
	fmov	w10, s9
	fmov	x9, d1
	add	x11, x3, x9
	ldp	q6, q0, [x11]
	add	x11, x5, x9
	ldp	q25, q26, [x11]
	fmul.4s	v1, v6, v25
	add	x11, x4, x9
	ldp	q16, q28, [x11]
	add	x9, x6, x9
	ldp	q4, q29, [x9]
	fmul.4s	v18, v16, v4
	fsub.4s	v1, v1, v18
	and.16b	v1, v10, v1
	fmov	x9, d5
	add	x9, x8, x9, lsl #2
	tbz	w10, #0, LBB1_851
; %bb.844:                              ; %cond.store1201
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x9]
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_852
LBB1_845:                               ; %else1204
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_853
LBB1_846:                               ; %cond.store1205
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v1 }[2], [x11]
	tbnz	w10, #3, LBB1_854
LBB1_847:                               ; %else1208
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v1, v0, v26
	fmul.4s	v5, v28, v29
	fsub.4s	v1, v1, v5
	and.16b	v1, v7, v1
	tbz	w10, #4, LBB1_855
LBB1_848:                               ; %cond.store1209
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x9, #16]
	tbnz	w10, #5, LBB1_856
LBB1_849:                               ; %else1212
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_857
LBB1_850:                               ; %cond.store1213
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v1 }[2], [x11]
	str	q29, [sp, #80]                  ; 16-byte Spill
	str	q28, [sp, #112]                 ; 16-byte Spill
	stp	q26, q0, [sp, #144]             ; 32-byte Folded Spill
	str	q20, [sp, #512]                 ; 16-byte Spill
	tbnz	w10, #7, LBB1_858
	b	LBB1_859
LBB1_851:                               ; %else1202
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_845
LBB1_852:                               ; %cond.store1203
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v1 }[1], [x11]
	tbnz	w10, #2, LBB1_846
LBB1_853:                               ; %else1206
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_847
LBB1_854:                               ; %cond.store1207
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v1 }[3], [x11]
	fmul.4s	v1, v0, v26
	fmul.4s	v5, v28, v29
	fsub.4s	v1, v1, v5
	and.16b	v1, v7, v1
	tbnz	w10, #4, LBB1_848
LBB1_855:                               ; %else1210
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_849
LBB1_856:                               ; %cond.store1211
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v1 }[1], [x11]
	tbnz	w10, #6, LBB1_850
LBB1_857:                               ; %else1214
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q29, [sp, #80]                  ; 16-byte Spill
	str	q28, [sp, #112]                 ; 16-byte Spill
	stp	q26, q0, [sp, #144]             ; 32-byte Folded Spill
	str	q20, [sp, #512]                 ; 16-byte Spill
	tbz	w10, #7, LBB1_859
LBB1_858:                               ; %cond.store1215
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v1 }[3], [x9]
LBB1_859:                               ; %else1216
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q0, [sp, #496]                  ; 16-byte Reload
	and.16b	v26, v21, v0
Lloh38:
	adrp	x9, lCPI1_25@PAGE
Lloh39:
	ldr	q1, [x9, lCPI1_25@PAGEOFF]
	and.16b	v1, v21, v1
	fmov	w10, s9
	fmov	x9, d1
	add	x11, x3, x9
	ldp	q20, q0, [x11]
	add	x11, x5, x9
	ldp	q28, q1, [x11]
	fmul.4s	v5, v20, v28
	add	x11, x4, x9
	ldp	q29, q27, [x11]
	add	x9, x6, x9
	ldp	q30, q18, [x9]
	fmul.4s	v31, v29, v30
	fsub.4s	v5, v5, v31
	and.16b	v5, v10, v5
	fmov	x9, d26
	add	x9, x8, x9, lsl #2
	tbz	w10, #0, LBB1_867
; %bb.860:                              ; %cond.store1218
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s5, [x9]
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_868
LBB1_861:                               ; %else1221
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_869
LBB1_862:                               ; %cond.store1222
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v5 }[2], [x11]
	tbnz	w10, #3, LBB1_870
LBB1_863:                               ; %else1225
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v5, v0, v1
	fmul.4s	v26, v27, v18
	fsub.4s	v5, v5, v26
	and.16b	v5, v7, v5
	tbz	w10, #4, LBB1_871
LBB1_864:                               ; %cond.store1226
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s5, [x9, #16]
	tbnz	w10, #5, LBB1_872
LBB1_865:                               ; %else1229
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q0, [sp, #496]                  ; 16-byte Spill
	tbz	w10, #6, LBB1_873
LBB1_866:                               ; %cond.store1230
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v5 }[2], [x11]
	mov.16b	v0, v22
	tbnz	w10, #7, LBB1_874
	b	LBB1_875
LBB1_867:                               ; %else1219
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_861
LBB1_868:                               ; %cond.store1220
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v5 }[1], [x11]
	tbnz	w10, #2, LBB1_862
LBB1_869:                               ; %else1223
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_863
LBB1_870:                               ; %cond.store1224
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v5 }[3], [x11]
	fmul.4s	v5, v0, v1
	fmul.4s	v26, v27, v18
	fsub.4s	v5, v5, v26
	and.16b	v5, v7, v5
	tbnz	w10, #4, LBB1_864
LBB1_871:                               ; %else1227
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_865
LBB1_872:                               ; %cond.store1228
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v5 }[1], [x11]
	str	q0, [sp, #496]                  ; 16-byte Spill
	tbnz	w10, #6, LBB1_866
LBB1_873:                               ; %else1231
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.16b	v0, v22
	tbz	w10, #7, LBB1_875
LBB1_874:                               ; %cond.store1232
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v5 }[3], [x9]
LBB1_875:                               ; %else1233
                                        ;   in Loop: Header=BB1_4 Depth=1
Lloh40:
	adrp	x9, lCPI1_7@PAGE
Lloh41:
	ldr	q5, [x9, lCPI1_7@PAGEOFF]
	and.16b	v5, v24, v5
Lloh42:
	adrp	x9, lCPI1_8@PAGE
Lloh43:
	ldr	q26, [x9, lCPI1_8@PAGEOFF]
	and.16b	v26, v23, v26
Lloh44:
	adrp	x9, lCPI1_9@PAGE
Lloh45:
	ldr	q31, [x9, lCPI1_9@PAGEOFF]
	ldr	q21, [sp, #336]                 ; 16-byte Reload
	and.16b	v31, v21, v31
	ldp	q22, q21, [sp, #288]            ; 32-byte Folded Reload
	add.2d	v12, v22, v12
	ldr	q22, [sp, #272]                 ; 16-byte Reload
	add.2d	v24, v21, v22
	ldr	q21, [sp, #320]                 ; 16-byte Reload
	add.2d	v21, v21, v13
	ldr	q22, [sp, #448]                 ; 16-byte Reload
	add.2d	v22, v22, v11
	str	q3, [sp, #1184]
	str	q26, [sp, #1200]
	str	q31, [sp, #1216]
	str	q5, [sp, #1232]
	ubfiz	x10, x12, #3, #3
	add	x9, sp, #1184
	ldr	x9, [x9, x10]
	orr	x9, x9, #0x80
	sub	x9, x9, x14
	tst	w13, #0xff
	csel	x9, xzr, x9, eq
	add	x11, x3, x9
	ldp	q8, q13, [x11]
	add	x11, x5, x9
	ldp	q14, q3, [x11]
	fmul.4s	v11, v8, v14
	add	x11, x4, x9
	ldp	q31, q5, [x11]
	add	x9, x6, x9
	ldp	q15, q26, [x9]
	fmul.4s	v23, v31, v15
	fsub.4s	v23, v11, v23
	zip1.8b	v11, v17, v0
	ushll.4s	v11, v11, #0
	shl.4s	v11, v11, #31
	cmlt.4s	v11, v11, #0
	and.16b	v11, v11, v23
	ldr	d23, [sp, #616]                 ; 8-byte Reload
	fmov	w9, s23
	str	q22, [sp, #1120]
	str	q21, [sp, #1136]
	str	q24, [sp, #1152]
	str	q12, [sp, #1168]
	add	x11, sp, #1120
	ldr	x10, [x11, x10]
	sub	x10, x10, x12
	add	x10, x8, x10, lsl #2
	tbz	w9, #0, LBB1_879
; %bb.876:                              ; %cond.store1235
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s11, [x10]
	mov.16b	v24, v0
	tbnz	w9, #1, LBB1_880
LBB1_877:                               ; %else1238
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #2, LBB1_881
LBB1_878:                               ; %cond.store1239
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x10, #8
	st1.s	{ v11 }[2], [x11]
	tbnz	w9, #3, LBB1_882
	b	LBB1_883
LBB1_879:                               ; %else1236
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.16b	v24, v0
	tbz	w9, #1, LBB1_877
LBB1_880:                               ; %cond.store1237
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x10, #4
	st1.s	{ v11 }[1], [x11]
	tbnz	w9, #2, LBB1_878
LBB1_881:                               ; %else1240
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #3, LBB1_883
LBB1_882:                               ; %cond.store1241
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x10, #12
	st1.s	{ v11 }[3], [x11]
LBB1_883:                               ; %else1242
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v21, v13, v3
	fmul.4s	v22, v5, v26
	fsub.4s	v21, v21, v22
	zip2.8b	v22, v17, v0
	ushll.4s	v22, v22, #0
	shl.4s	v22, v22, #31
	cmlt.4s	v22, v22, #0
	and.16b	v11, v22, v21
	tbz	w9, #4, LBB1_887
; %bb.884:                              ; %cond.store1243
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s11, [x10, #16]
	tbnz	w9, #5, LBB1_888
LBB1_885:                               ; %else1246
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #6, LBB1_889
LBB1_886:                               ; %cond.store1247
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x10, #24
	st1.s	{ v11 }[2], [x11]
	tbnz	w9, #7, LBB1_890
	b	LBB1_891
LBB1_887:                               ; %else1244
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #5, LBB1_885
LBB1_888:                               ; %cond.store1245
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x10, #20
	st1.s	{ v11 }[1], [x11]
	tbnz	w9, #6, LBB1_886
LBB1_889:                               ; %else1248
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #7, LBB1_891
LBB1_890:                               ; %cond.store1249
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x10, #28
	st1.s	{ v11 }[3], [x9]
LBB1_891:                               ; %else1250
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v21, v24, #0
	ldr	q0, [sp, #480]                  ; 16-byte Reload
	and.16b	v21, v21, v0
	fmov	w10, s9
	ldr	q0, [sp, #128]                  ; 16-byte Reload
	ldp	q22, q23, [sp, #48]             ; 32-byte Folded Reload
	fmul.4s	v22, v0, v22
	ldr	q0, [sp, #96]                   ; 16-byte Reload
	fmul.4s	v23, v0, v23
	fadd.4s	v22, v23, v22
	and.16b	v23, v10, v22
	fmov	x9, d21
	add	x9, x8, x9, lsl #2
	tbz	w10, #0, LBB1_895
; %bb.892:                              ; %cond.store1252
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s23, [x9]
	and	w10, w10, #0xff
	movi.8b	v11, #1
	tbnz	w10, #1, LBB1_896
LBB1_893:                               ; %else1255
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_897
LBB1_894:                               ; %cond.store1256
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v23 }[2], [x11]
	tbnz	w10, #3, LBB1_898
	b	LBB1_899
LBB1_895:                               ; %else1253
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w10, w10, #0xff
	movi.8b	v11, #1
	tbz	w10, #1, LBB1_893
LBB1_896:                               ; %cond.store1254
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v23 }[1], [x11]
	tbnz	w10, #2, LBB1_894
LBB1_897:                               ; %else1257
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_899
LBB1_898:                               ; %cond.store1258
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v23 }[3], [x11]
LBB1_899:                               ; %else1259
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q0, [sp, #256]                  ; 16-byte Reload
	ldr	q21, [sp, #224]                 ; 16-byte Reload
	fmul.4s	v21, v0, v21
	ldr	q0, [sp, #240]                  ; 16-byte Reload
	ldr	q22, [sp, #528]                 ; 16-byte Reload
	fmul.4s	v22, v0, v22
	fadd.4s	v21, v22, v21
	and.16b	v23, v7, v21
	tbz	w10, #4, LBB1_903
; %bb.900:                              ; %cond.store1260
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s23, [x9, #16]
	tbnz	w10, #5, LBB1_904
LBB1_901:                               ; %else1263
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_905
LBB1_902:                               ; %cond.store1264
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v23 }[2], [x11]
	tbnz	w10, #7, LBB1_906
	b	LBB1_907
LBB1_903:                               ; %else1261
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_901
LBB1_904:                               ; %cond.store1262
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v23 }[1], [x11]
	tbnz	w10, #6, LBB1_902
LBB1_905:                               ; %else1265
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_907
LBB1_906:                               ; %cond.store1266
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v23 }[3], [x9]
LBB1_907:                               ; %else1267
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v21, v24, #0
	ldr	q0, [sp, #464]                  ; 16-byte Reload
	and.16b	v21, v21, v0
	fmov	w10, s9
	ldr	q0, [sp, #32]                   ; 16-byte Reload
	fmul.4s	v0, v0, v2
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	fmul.4s	v2, v2, v19
	fadd.4s	v0, v2, v0
	and.16b	v0, v10, v0
	fmov	x9, d21
	add	x9, x8, x9, lsl #2
	tbz	w10, #0, LBB1_911
; %bb.908:                              ; %cond.store1269
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9]
	and	w10, w10, #0xff
	ldr	d19, [sp, #616]                 ; 8-byte Reload
	tbnz	w10, #1, LBB1_912
LBB1_909:                               ; %else1272
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_913
LBB1_910:                               ; %cond.store1273
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v0 }[2], [x11]
	tbnz	w10, #3, LBB1_914
	b	LBB1_915
LBB1_911:                               ; %else1270
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w10, w10, #0xff
	ldr	d19, [sp, #616]                 ; 8-byte Reload
	tbz	w10, #1, LBB1_909
LBB1_912:                               ; %cond.store1271
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v0 }[1], [x11]
	tbnz	w10, #2, LBB1_910
LBB1_913:                               ; %else1274
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_915
LBB1_914:                               ; %cond.store1275
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v0 }[3], [x11]
LBB1_915:                               ; %else1276
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q0, [sp, #208]                  ; 16-byte Reload
	ldr	q2, [sp, #176]                  ; 16-byte Reload
	fmul.4s	v0, v0, v2
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	ldr	q21, [sp, #512]                 ; 16-byte Reload
	fmul.4s	v2, v2, v21
	fadd.4s	v0, v2, v0
	and.16b	v0, v7, v0
	tbz	w10, #4, LBB1_919
; %bb.916:                              ; %cond.store1277
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9, #16]
	tbnz	w10, #5, LBB1_920
LBB1_917:                               ; %else1280
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_921
LBB1_918:                               ; %cond.store1281
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v0 }[2], [x11]
	tbnz	w10, #7, LBB1_922
	b	LBB1_923
LBB1_919:                               ; %else1278
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_917
LBB1_920:                               ; %cond.store1279
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v0 }[1], [x11]
	tbnz	w10, #6, LBB1_918
LBB1_921:                               ; %else1282
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_923
LBB1_922:                               ; %cond.store1283
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v0 }[3], [x9]
LBB1_923:                               ; %else1284
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v0, v24, #0
	ldr	q2, [sp, #432]                  ; 16-byte Reload
	and.16b	v2, v0, v2
	fmov	w10, s9
	fmul.4s	v0, v6, v4
	fmul.4s	v4, v25, v16
	fadd.4s	v0, v4, v0
	and.16b	v0, v10, v0
	fmov	x9, d2
	add	x9, x8, x9, lsl #2
	tbz	w10, #0, LBB1_927
; %bb.924:                              ; %cond.store1286
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9]
	and	w10, w10, #0xff
	tbnz	w10, #1, LBB1_928
LBB1_925:                               ; %else1289
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_929
LBB1_926:                               ; %cond.store1290
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v0 }[2], [x11]
	tbnz	w10, #3, LBB1_930
	b	LBB1_931
LBB1_927:                               ; %else1287
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w10, w10, #0xff
	tbz	w10, #1, LBB1_925
LBB1_928:                               ; %cond.store1288
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v0 }[1], [x11]
	tbnz	w10, #2, LBB1_926
LBB1_929:                               ; %else1291
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_931
LBB1_930:                               ; %cond.store1292
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v0 }[3], [x11]
LBB1_931:                               ; %else1293
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q0, [sp, #160]                  ; 16-byte Reload
	ldr	q2, [sp, #80]                   ; 16-byte Reload
	fmul.4s	v0, v0, v2
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	ldr	q4, [sp, #112]                  ; 16-byte Reload
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v2, v0
	and.16b	v0, v7, v0
	tbz	w10, #4, LBB1_935
; %bb.932:                              ; %cond.store1294
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9, #16]
	tbnz	w10, #5, LBB1_936
LBB1_933:                               ; %else1297
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_937
LBB1_934:                               ; %cond.store1298
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v0 }[2], [x11]
	tbnz	w10, #7, LBB1_938
	b	LBB1_939
LBB1_935:                               ; %else1295
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_933
LBB1_936:                               ; %cond.store1296
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v0 }[1], [x11]
	tbnz	w10, #6, LBB1_934
LBB1_937:                               ; %else1299
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_939
LBB1_938:                               ; %cond.store1300
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v0 }[3], [x9]
LBB1_939:                               ; %else1301
                                        ;   in Loop: Header=BB1_4 Depth=1
	sshll.2d	v0, v24, #0
	ldr	q2, [sp, #416]                  ; 16-byte Reload
	and.16b	v2, v0, v2
	fmov	w10, s9
	fmul.4s	v0, v20, v30
	fmul.4s	v4, v28, v29
	fadd.4s	v0, v4, v0
	and.16b	v0, v10, v0
	fmov	x9, d2
	add	x9, x8, x9, lsl #2
	tbz	w10, #0, LBB1_947
; %bb.940:                              ; %cond.store1303
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9]
	and	w10, w10, #0xff
	movi.2s	v10, #33
	tbnz	w10, #1, LBB1_948
LBB1_941:                               ; %else1306
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_949
LBB1_942:                               ; %cond.store1307
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v0 }[2], [x11]
	tbnz	w10, #3, LBB1_950
LBB1_943:                               ; %else1310
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	q0, [sp, #496]                  ; 16-byte Reload
	fmul.4s	v0, v0, v18
	fmul.4s	v1, v1, v27
	fadd.4s	v0, v1, v0
	and.16b	v0, v7, v0
	tbz	w10, #4, LBB1_951
LBB1_944:                               ; %cond.store1311
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x9, #16]
	tbnz	w10, #5, LBB1_952
LBB1_945:                               ; %else1314
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_953
LBB1_946:                               ; %cond.store1315
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v0 }[2], [x11]
	tbnz	w10, #7, LBB1_954
	b	LBB1_955
LBB1_947:                               ; %else1304
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w10, w10, #0xff
	movi.2s	v10, #33
	tbz	w10, #1, LBB1_941
LBB1_948:                               ; %cond.store1305
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v0 }[1], [x11]
	tbnz	w10, #2, LBB1_942
LBB1_949:                               ; %else1308
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_943
LBB1_950:                               ; %cond.store1309
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v0 }[3], [x11]
	ldr	q0, [sp, #496]                  ; 16-byte Reload
	fmul.4s	v0, v0, v18
	fmul.4s	v1, v1, v27
	fadd.4s	v0, v1, v0
	and.16b	v0, v7, v0
	tbnz	w10, #4, LBB1_944
LBB1_951:                               ; %else1312
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_945
LBB1_952:                               ; %cond.store1313
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v0 }[1], [x11]
	tbnz	w10, #6, LBB1_946
LBB1_953:                               ; %else1316
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_955
LBB1_954:                               ; %cond.store1317
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v0 }[3], [x9]
LBB1_955:                               ; %else1318
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v0, v8, v15
	fmul.4s	v1, v14, v31
	fadd.4s	v0, v1, v0
	zip1.8b	v1, v17, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v0, v1, v0
	fmov	w9, s19
	ldp	q2, q1, [sp, #352]              ; 32-byte Folded Reload
	str	q2, [sp, #1040]
	str	q1, [sp, #1056]
	ldp	q2, q1, [sp, #384]              ; 32-byte Folded Reload
	str	q2, [sp, #1072]
	str	q1, [sp, #1088]
	and	x10, x12, #0x7
	add	x11, sp, #1040
	ldr	x10, [x11, x10, lsl #3]
	sub	x10, x10, x12
	add	x8, x8, x10, lsl #2
	tbz	w9, #0, LBB1_959
; %bb.956:                              ; %cond.store1320
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x8]
	movi.2s	v8, #66
	tbnz	w9, #1, LBB1_960
LBB1_957:                               ; %else1323
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #2, LBB1_961
LBB1_958:                               ; %cond.store1324
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #8
	st1.s	{ v0 }[2], [x10]
	tbnz	w9, #3, LBB1_962
	b	LBB1_963
LBB1_959:                               ; %else1321
                                        ;   in Loop: Header=BB1_4 Depth=1
	movi.2s	v8, #66
	tbz	w9, #1, LBB1_957
LBB1_960:                               ; %cond.store1322
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #4
	st1.s	{ v0 }[1], [x10]
	tbnz	w9, #2, LBB1_958
LBB1_961:                               ; %else1325
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #3, LBB1_963
LBB1_962:                               ; %cond.store1326
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #12
	st1.s	{ v0 }[3], [x10]
LBB1_963:                               ; %else1327
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v0, v13, v26
	fmul.4s	v1, v3, v5
	fadd.4s	v0, v1, v0
	zip2.8b	v1, v17, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v0, v1, v0
	tbnz	w9, #4, LBB1_484
LBB1_964:                               ; %else659
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #5, LBB1_485
LBB1_965:                               ; %cond.store660
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbnz	w9, #6, LBB1_486
LBB1_966:                               ; %else663
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #7, LBB1_968
LBB1_967:                               ; %cond.store1334
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB1_968:                               ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w25, [sp, #684]                 ; 4-byte Reload
	b	LBB1_3
LBB1_969:
	add	sp, sp, #2208
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB1_970:                               ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpAdrp	Lloh40, Lloh42
	.loh AdrpLdr	Lloh40, Lloh41
                                        ; -- End function
.subsections_via_symbols

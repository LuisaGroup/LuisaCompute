	.build_version macos, 26, 0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2                               ; -- Begin function llm_rows.full_packet
_llm_rows.full_packet:                  ; @llm_rows.full_packet
; %bb.0:                                ; %prologue
	stp	x28, x27, [sp, #-96]!           ; 16-byte Folded Spill
	stp	x26, x25, [sp, #16]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #32]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #192
	ldr	x23, [x0]
	ldr	x22, [x0, #16]
	ldr	x21, [x0, #32]
	ldr	x20, [x0, #48]
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	lsr	w8, w8, #3
	dup.2s	v0, w8
	ushll.2d	v0, v0, #0
	subs	x8, x23, x20
	cset	w9, hs
	lsr	x8, x8, #13
	cmp	x8, #2048
	csel	w8, wzr, w9, ls
	subs	x9, x20, x23
	cset	w10, hs
	lsr	x9, x9, #13
	cmp	x9, #2048
	csel	w9, wzr, w10, ls
	subs	x10, x22, x20
	cset	w11, hs
	lsr	x10, x10, #13
	cmp	x10, #2048
	csel	w10, wzr, w11, ls
	subs	x11, x20, x22
	cset	w12, hs
	mov	w13, #8191                      ; =0x1fff
	movk	w13, #256, lsl #16
	sub	x13, x13, #2049, lsl #12        ; =8392704
	cmp	x11, x13
	csel	w11, wzr, w12, ls
	subs	x12, x21, x20
	cset	w14, hs
	lsr	x12, x12, #13
	cmp	x12, #2048
	csel	w12, wzr, w14, ls
	subs	x14, x20, x21
	cset	w15, hs
	cmp	x14, x13
	csel	w13, wzr, w15, ls
	orr	w12, w12, w13
	cmp	w12, #1
	b.ne	LBB0_6
; %bb.1:                                ; %prologue
	orr	w8, w8, w9
	cbz	w8, LBB0_6
; %bb.2:                                ; %prologue
	orr	w8, w10, w11
	tbz	w8, #0, LBB0_6
; %bb.3:                                ; %direct.schedule.2.preheader
	mov	x9, #0                          ; =0x0
	mov	w8, #4098                       ; =0x1002
	dup.2s	v1, w8
	xtn.2s	v2, v0
	umull.2d	v1, v2, v1
	fmov	x11, d1
	fmov	x8, d0
	add	x10, x8, x8, lsl #11
	mov	w12, #8196                      ; =0x2004
	add	x12, x12, x11, lsl #2
	add	x11, x23, x12
	add	x12, x20, x12
LBB0_4:                                 ; %direct.true31
                                        ; =>This Inner Loop Header: Depth=1
	fmov	d2, x9
	add.2d	v2, v2, v1
	fmov	x13, d2
	lsl	x13, x13, #2
	add	x14, x23, x13
	ldp	q2, q3, [x14]
	ldp	q4, q5, [x11], #32
	add	x14, x9, x10
	lsl	x14, x14, #2
	add	x15, x22, x14
	ldp	q6, q7, [x15]
	add	x14, x21, x14
	ldp	q16, q17, [x14]
	fmul.4s	v18, v3, v7
	fmul.4s	v19, v2, v6
	fmul.4s	v20, v5, v17
	fmul.4s	v21, v4, v16
	fsub.4s	v19, v19, v21
	fsub.4s	v18, v18, v20
	add	x13, x20, x13
	stp	q19, q18, [x13]
	fmul.4s	v3, v3, v17
	fmul.4s	v2, v2, v16
	fmul.4s	v5, v5, v7
	fmul.4s	v4, v4, v6
	fadd.4s	v2, v4, v2
	fadd.4s	v3, v5, v3
	stp	q2, q3, [x12], #32
	add	x9, x9, #8
	cmp	x9, #2048
	b.ne	LBB0_4
; %bb.5:                                ; %direct.false32
	fmov	x9, d0
	add	x9, x9, x9, lsl #11
	lsl	x9, x9, #3
	add	x10, x9, #2, lsl #12            ; =8192
	ldr	s0, [x23, x10]
	mov	w11, #16388                     ; =0x4004
	add	x19, x9, x11
	ldr	s1, [x23, x19]
	mov	w9, #8196                       ; =0x2004
	umull	x8, w8, w9
	add	x8, x8, #2, lsl #12             ; =8192
	ldr	s2, [x22, x8]
	ldr	s3, [x21, x8]
	fmul.4s	v4, v0, v2
	fmul.4s	v5, v1, v3
	fsub.4s	v4, v4, v5
	str	s4, [x20, x10]
	fmul.4s	v0, v0, v3
	fmul.4s	v1, v1, v2
	b	LBB0_11
LBB0_6:                                 ; %direct.schedule.8.preheader
	fmov	x8, d0
	add	x28, x8, x8, lsl #11
	lsl	x24, x28, #3
	add	x19, x23, x24
	add	x26, sp, #6, lsl #12            ; =24576
	add	x26, x26, #160
	add	x0, sp, #6, lsl #12             ; =24576
	add	x0, x0, #160
	mov	x1, x19
	mov	w2, #8192                       ; =0x2000
	bl	_memcpy
	add	x8, x24, #2, lsl #12            ; =8192
	ldr	s0, [x23, x8]
	str	q0, [sp, #48]                   ; 16-byte Spill
	str	q0, [sp, #32928]
	mov	w8, #8196                       ; =0x2004
	add	x27, sp, #4, lsl #12            ; =16384
	add	x27, x27, #128
	add	x0, sp, #4, lsl #12             ; =16384
	add	x0, x0, #128
	add	x1, x19, x8
	mov	w2, #8192                       ; =0x2000
	bl	_memcpy
	mov	w8, #16388                      ; =0x4004
	add	x19, x24, x8
	ldr	s0, [x23, x19]
	str	q0, [sp, #32]                   ; 16-byte Spill
	str	q0, [sp, #24704]
	lsl	x28, x28, #2
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #96
	add	x0, sp, #2, lsl #12             ; =8192
	add	x0, x0, #96
	add	x1, x22, x28
	mov	w2, #8192                       ; =0x2000
	bl	_memcpy
	add	x25, x28, #2, lsl #12           ; =8192
	ldr	s0, [x22, x25]
	str	q0, [sp, #16]                   ; 16-byte Spill
	str	q0, [sp, #16480]
	add	x22, sp, #64
	add	x0, sp, #64
	add	x1, x21, x28
	mov	w2, #8192                       ; =0x2000
	bl	_memcpy
	mov	x8, #0                          ; =0x0
	ldr	s0, [x21, x25]
	str	q0, [sp, #8256]
	add	x9, x20, x24
LBB0_7:                                 ; %direct.true145
                                        ; =>This Inner Loop Header: Depth=1
	add	x10, x26, x8
	ldp	q1, q2, [x10]
	add	x10, x23, x8
	ldp	q3, q4, [x10]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x10, x27, x8
	ldp	q3, q4, [x10]
	add	x10, x22, x8
	ldp	q5, q6, [x10]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fsub.4s	v1, v1, v3
	fsub.4s	v2, v2, v4
	add	x10, x9, x8
	stp	q1, q2, [x10]
	add	x8, x8, #32
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_7
; %bb.8:                                ; %direct.false146
	mov	x8, #0                          ; =0x0
	ldp	q16, q7, [sp, #32]              ; 32-byte Folded Reload
	ldr	q17, [sp, #16]                  ; 16-byte Reload
	fmul.4s	v1, v7, v17
	fmul.4s	v2, v16, v0
	fsub.4s	v1, v1, v2
	add	x9, x24, #2, lsl #12            ; =8192
	str	s1, [x20, x9]
	mov	w9, #8196                       ; =0x2004
	add	x10, x24, x20
	add	x9, x10, x9
	add	x10, sp, #6, lsl #12            ; =24576
	add	x10, x10, #160
	add	x11, sp, #64
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #128
	add	x13, sp, #2, lsl #12            ; =8192
	add	x13, x13, #96
LBB0_9:                                 ; %direct.true184
                                        ; =>This Inner Loop Header: Depth=1
	add	x14, x10, x8
	ldp	q1, q2, [x14]
	add	x14, x11, x8
	ldp	q3, q4, [x14]
	fmul.4s	v2, v2, v4
	fmul.4s	v1, v1, v3
	add	x14, x12, x8
	ldp	q3, q4, [x14]
	add	x14, x13, x8
	ldp	q5, q6, [x14]
	fmul.4s	v4, v4, v6
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v1, v3
	fadd.4s	v2, v2, v4
	add	x14, x9, x8
	stp	q1, q2, [x14]
	add	x8, x8, #32
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_9
; %bb.10:                               ; %direct.false185
	fmul.4s	v0, v7, v0
	fmul.4s	v1, v16, v17
LBB0_11:                                ; %common.ret
	fadd.4s	v0, v1, v0
	str	s0, [x20, x19]
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #192
	ldp	x29, x30, [sp, #80]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #32]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #16]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp], #96             ; 16-byte Folded Reload
	ret
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI1_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI1_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI1_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI1_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI1_7:
	.quad	8192                            ; 0x2000
	.quad	8196                            ; 0x2004
lCPI1_8:
	.quad	8208                            ; 0x2010
	.quad	8212                            ; 0x2014
lCPI1_9:
	.quad	8200                            ; 0x2008
	.quad	8204                            ; 0x200c
lCPI1_10:
	.quad	8216                            ; 0x2018
	.quad	8220                            ; 0x201c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI1_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #1168
	str	x0, [sp, #232]                  ; 8-byte Spill
	cbz	w3, LBB1_407
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x19, x3
	mov	x20, x2
	mov	w22, #0                         ; =0x0
	mov	w24, #8191                      ; =0x1fff
	movk	w24, #256, lsl #16
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #224]              ; 8-byte Folded Spill
	mov	w8, #4098                       ; =0x1002
	ldp	w25, w12, [x2]
Lloh0:
	adrp	x9, lCPI1_0@PAGE
Lloh1:
	ldr	q0, [x9, lCPI1_0@PAGEOFF]
	str	q0, [sp, #176]                  ; 16-byte Spill
Lloh2:
	adrp	x9, lCPI1_1@PAGE
Lloh3:
	ldr	q0, [x9, lCPI1_1@PAGEOFF]
	str	q0, [sp, #160]                  ; 16-byte Spill
Lloh4:
	adrp	x9, lCPI1_2@PAGE
Lloh5:
	ldr	q0, [x9, lCPI1_2@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Spill
Lloh6:
	adrp	x9, lCPI1_3@PAGE
Lloh7:
	ldr	q0, [x9, lCPI1_3@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Spill
Lloh8:
	adrp	x9, lCPI1_4@PAGE
Lloh9:
	ldr	q0, [x9, lCPI1_4@PAGEOFF]
	str	q0, [sp, #112]                  ; 16-byte Spill
	dup.2s	v9, w8
Lloh10:
	adrp	x8, lCPI1_5@PAGE
Lloh11:
	ldr	q0, [x8, lCPI1_5@PAGEOFF]
	str	q0, [sp, #96]                   ; 16-byte Spill
Lloh12:
	adrp	x8, lCPI1_6@PAGE
Lloh13:
	ldr	q10, [x8, lCPI1_6@PAGEOFF]
	ldp	w27, w8, [x2, #8]
	str	x8, [sp, #216]                  ; 8-byte Spill
	add	x28, sp, #2, lsl #12            ; =8192
	add	x28, x28, #1072
	add	x21, sp, #1040
	str	w3, [sp, #212]                  ; 4-byte Spill
	str	d9, [sp, #8]                    ; 8-byte Spill
	str	q10, [sp, #192]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w19, [sp, #212]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	ldp	w10, w9, [sp, #224]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w26, eq
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w12, wzr, w9, ne
	add	w27, w27, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_407
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_208 Depth 2
                                        ;     Child Loop BB1_242 Depth 2
                                        ;     Child Loop BB1_276 Depth 2
                                        ;     Child Loop BB1_310 Depth 2
                                        ;     Child Loop BB1_344 Depth 2
                                        ;     Child Loop BB1_378 Depth 2
                                        ;     Child Loop BB1_18 Depth 2
	ubfiz	x8, x25, #5, #32
	ldr	x13, [sp, #216]                 ; 8-byte Reload
	cmp	x8, x13
	csel	x9, x8, xzr, ls
	subs	x10, x13, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x13, x9
	stp	w25, w12, [x20]
	mov	x26, x12
	str	w27, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x13, #2, hi
	csel	x23, x10, xzr, ls
	cmp	x23, #32
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x23, [sp, #232]                 ; 8-byte Reload
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x23
	mov	x1, x20
	bl	_llm_rows.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x19, x23, #3
	cbz	x19, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #232]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #232]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #232]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_rows.full_packet
	cmp	x19, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	x24, [sp, #232]                 ; 8-byte Reload
	mov	x0, x24
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x24
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x24
	mov	x1, x20
	bl	_llm_rows.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x24
	mov	w24, #8191                      ; =0x1fff
	movk	w24, #256, lsl #16
	mov	x1, x20
	bl	_llm_rows.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w23, #0x7
	ldr	q10, [sp, #192]                 ; 16-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	dup.4s	v0, w8
	ldp	q2, q1, [sp, #160]              ; 32-byte Folded Reload
	cmhi.4s	v4, v0, v2
	cmhi.4s	v5, v0, v1
	uzp1.8h	v18, v5, v4
	umaxv.8h	h0, v18
	fmov	w8, s0
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [sp, #232]                  ; 8-byte Reload
	ldr	x11, [x8]
	ldr	x10, [x8, #16]
	ldr	x9, [x8, #32]
	ldr	x8, [x8, #48]
	sshll.2d	v0, v5, #0
	sshll.2d	v1, v4, #0
	sshll2.2d	v20, v5, #0
	sshll2.2d	v19, v4, #0
	ldp	q2, q3, [sp, #128]              ; 32-byte Folded Reload
	and.16b	v12, v19, v3
	and.16b	v17, v20, v2
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	and.16b	v15, v1, v2
	ldr	q1, [sp, #96]                   ; 16-byte Reload
	and.16b	v21, v0, v1
	ubfiz	w12, w25, #2, #27
	orr	w12, w12, w19
	dup.4s	v0, w12
	and.16b	v3, v5, v0
	and.16b	v1, v4, v0
	ushll2.2d	v0, v1, #0
	ushll2.2d	v2, v3, #0
	ushll.2d	v1, v1, #0
	ushll.2d	v3, v3, #0
	subs	x12, x11, x8
	cset	w13, hs
	cmp	x12, x24
	csel	w12, wzr, w13, ls
	subs	x13, x8, x11
	cset	w14, hs
	cmp	x13, x24
	csel	w13, wzr, w14, ls
	subs	x14, x10, x8
	cset	w15, hs
	cmp	x14, x24
	csel	w14, wzr, w15, ls
	subs	x15, x8, x10
	cset	w16, hs
	sub	x17, x24, #2049, lsl #12        ; =8392704
	cmp	x15, x17
	csel	w15, wzr, w16, ls
	subs	x16, x9, x8
	cset	w0, hs
	cmp	x16, x24
	csel	w16, wzr, w0, ls
	subs	x0, x8, x9
	cset	w1, hs
	cmp	x0, x17
	csel	w17, wzr, w1, ls
	orr	w16, w16, w17
	xtn.2s	v23, v2
	xtn.2s	v25, v1
	xtn.2s	v22, v0
	xtn.2s	v26, v3
	cmp	w16, #1
	b.ne	LBB1_206
; %bb.14:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w12, w12, w13
	cbz	w12, LBB1_206
; %bb.15:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr	w12, w14, w15
	tbz	w12, #0, LBB1_206
; %bb.16:                               ; %direct.schedule.2.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	umull.2d	v4, v23, v9
	umull.2d	v7, v25, v9
	umull.2d	v5, v22, v9
	umull.2d	v19, v26, v9
	fmov	x13, d19
	add	x13, x13, #2049
	fmov	x14, d3
	add	x14, x14, x14, lsl #11
	and.16b	v6, v18, v10
	addv.8h	h20, v6
	fmov	w15, s20
	b	LBB1_18
LBB1_17:                                ; %else133
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x12, x12, #8
	cmp	x12, #2048
	b.eq	LBB1_114
LBB1_18:                                ; %direct.true31.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v6, x12
	orr.16b	v24, v6, v21
	add.2d	v6, v24, v19
	fmov	x16, d6
	lsl	x16, x16, #2
	add	x17, x11, x16
	movi.2d	v23, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbz	w15, #0, LBB1_26
; %bb.19:                               ; %cond.load
                                        ;   in Loop: Header=BB1_18 Depth=2
	ldr	s23, [x17]
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB1_27
LBB1_20:                                ; %else6
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #2, LBB1_28
LBB1_21:                                ; %cond.load8
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #8
	ld1.s	{ v23 }[2], [x1]
	tbnz	w0, #3, LBB1_29
LBB1_22:                                ; %else12
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #4, LBB1_30
LBB1_23:                                ; %cond.load14
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #16
	ld1.s	{ v22 }[0], [x1]
	tbnz	w0, #5, LBB1_31
LBB1_24:                                ; %else18
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #6, LBB1_32
LBB1_25:                                ; %cond.load20
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #24
	ld1.s	{ v22 }[2], [x1]
	tbnz	w0, #7, LBB1_33
	b	LBB1_34
LBB1_26:                                ; %else
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w0, w15, #0xff
	tbz	w0, #1, LBB1_20
LBB1_27:                                ; %cond.load5
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #4
	ld1.s	{ v23 }[1], [x1]
	tbnz	w0, #2, LBB1_21
LBB1_28:                                ; %else9
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #3, LBB1_22
LBB1_29:                                ; %cond.load11
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #12
	ld1.s	{ v23 }[3], [x1]
	tbnz	w0, #4, LBB1_23
LBB1_30:                                ; %else15
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #5, LBB1_24
LBB1_31:                                ; %cond.load17
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x17, #20
	ld1.s	{ v22 }[1], [x1]
	tbnz	w0, #6, LBB1_25
LBB1_32:                                ; %else21
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #7, LBB1_34
LBB1_33:                                ; %cond.load23
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x17, x17, #28
	ld1.s	{ v22 }[3], [x17]
LBB1_34:                                ; %else24
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmov	w2, s20
	fmov	x0, d24
	add	x17, x13, x0
	lsl	x17, x17, #2
	add	x1, x11, x17
	movi.2d	v25, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbz	w2, #0, LBB1_42
; %bb.35:                               ; %cond.load27
                                        ;   in Loop: Header=BB1_18 Depth=2
	ldr	s25, [x1]
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB1_43
LBB1_36:                                ; %else31
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #2, LBB1_44
LBB1_37:                                ; %cond.load33
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #8
	ld1.s	{ v25 }[2], [x3]
	tbnz	w2, #3, LBB1_45
LBB1_38:                                ; %else37
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #4, LBB1_46
LBB1_39:                                ; %cond.load39
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #16
	ld1.s	{ v24 }[0], [x3]
	tbnz	w2, #5, LBB1_47
LBB1_40:                                ; %else43
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #6, LBB1_48
LBB1_41:                                ; %cond.load45
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #24
	ld1.s	{ v24 }[2], [x3]
	tbnz	w2, #7, LBB1_49
	b	LBB1_50
LBB1_42:                                ; %else28
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w2, w2, #0xff
	tbz	w2, #1, LBB1_36
LBB1_43:                                ; %cond.load30
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #4
	ld1.s	{ v25 }[1], [x3]
	tbnz	w2, #2, LBB1_37
LBB1_44:                                ; %else34
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #3, LBB1_38
LBB1_45:                                ; %cond.load36
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #12
	ld1.s	{ v25 }[3], [x3]
	tbnz	w2, #4, LBB1_39
LBB1_46:                                ; %else40
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #5, LBB1_40
LBB1_47:                                ; %cond.load42
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #20
	ld1.s	{ v24 }[1], [x3]
	tbnz	w2, #6, LBB1_41
LBB1_48:                                ; %else46
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #7, LBB1_50
LBB1_49:                                ; %cond.load48
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x1, #28
	ld1.s	{ v24 }[3], [x1]
LBB1_50:                                ; %else49
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmov	w2, s20
	add	x0, x0, x14
	lsl	x0, x0, #2
	add	x1, x10, x0
	movi.2d	v27, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbz	w2, #0, LBB1_82
; %bb.51:                               ; %cond.load52
                                        ;   in Loop: Header=BB1_18 Depth=2
	ldr	s27, [x1]
	and	w2, w2, #0xff
	tbnz	w2, #1, LBB1_83
LBB1_52:                                ; %else56
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #2, LBB1_84
LBB1_53:                                ; %cond.load58
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #8
	ld1.s	{ v27 }[2], [x3]
	tbnz	w2, #3, LBB1_85
LBB1_54:                                ; %else62
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #4, LBB1_86
LBB1_55:                                ; %cond.load64
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #16
	ld1.s	{ v26 }[0], [x3]
	tbnz	w2, #5, LBB1_87
LBB1_56:                                ; %else68
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #6, LBB1_88
LBB1_57:                                ; %cond.load70
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #24
	ld1.s	{ v26 }[2], [x3]
	tbnz	w2, #7, LBB1_89
LBB1_58:                                ; %else74
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmov	w1, s20
	add	x0, x9, x0
	movi.2d	v29, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbz	w1, #0, LBB1_90
LBB1_59:                                ; %cond.load77
                                        ;   in Loop: Header=BB1_18 Depth=2
	ldr	s29, [x0]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB1_91
LBB1_60:                                ; %else81
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w1, #2, LBB1_92
LBB1_61:                                ; %cond.load83
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #8
	ld1.s	{ v29 }[2], [x2]
	tbnz	w1, #3, LBB1_93
LBB1_62:                                ; %else87
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w1, #4, LBB1_94
LBB1_63:                                ; %cond.load89
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #16
	ld1.s	{ v28 }[0], [x2]
	tbnz	w1, #5, LBB1_95
LBB1_64:                                ; %else93
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w1, #6, LBB1_96
LBB1_65:                                ; %cond.load95
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #24
	ld1.s	{ v28 }[2], [x2]
	tbnz	w1, #7, LBB1_97
LBB1_66:                                ; %else99
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmov	w0, s20
	fmul.4s	v6, v23, v27
	fmul.4s	v30, v25, v29
	fsub.4s	v6, v6, v30
	add	x16, x8, x16
	tbz	w0, #0, LBB1_98
LBB1_67:                                ; %cond.store
                                        ;   in Loop: Header=BB1_18 Depth=2
	str	s6, [x16]
	and	w0, w0, #0xff
	tbnz	w0, #1, LBB1_99
LBB1_68:                                ; %else104
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #2, LBB1_100
LBB1_69:                                ; %cond.store105
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x16, #8
	st1.s	{ v6 }[2], [x1]
	tbnz	w0, #3, LBB1_101
LBB1_70:                                ; %else108
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmul.4s	v6, v22, v26
	fmul.4s	v30, v24, v28
	fsub.4s	v6, v6, v30
	tbz	w0, #4, LBB1_102
LBB1_71:                                ; %cond.store109
                                        ;   in Loop: Header=BB1_18 Depth=2
	str	s6, [x16, #16]
	tbnz	w0, #5, LBB1_103
LBB1_72:                                ; %else112
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #6, LBB1_104
LBB1_73:                                ; %cond.store113
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x16, #24
	st1.s	{ v6 }[2], [x1]
	tbnz	w0, #7, LBB1_105
LBB1_74:                                ; %else116
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmov	w0, s20
	fmul.4s	v6, v23, v29
	fmul.4s	v23, v25, v27
	fadd.4s	v6, v23, v6
	add	x16, x8, x17
	tbz	w0, #0, LBB1_106
LBB1_75:                                ; %cond.store118
                                        ;   in Loop: Header=BB1_18 Depth=2
	str	s6, [x16]
	and	w17, w0, #0xff
	tbnz	w17, #1, LBB1_107
LBB1_76:                                ; %else121
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w17, #2, LBB1_108
LBB1_77:                                ; %cond.store122
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x16, #8
	st1.s	{ v6 }[2], [x0]
	tbnz	w17, #3, LBB1_109
LBB1_78:                                ; %else125
                                        ;   in Loop: Header=BB1_18 Depth=2
	fmul.4s	v6, v22, v28
	fmul.4s	v22, v24, v26
	fadd.4s	v6, v22, v6
	tbz	w17, #4, LBB1_110
LBB1_79:                                ; %cond.store126
                                        ;   in Loop: Header=BB1_18 Depth=2
	str	s6, [x16, #16]
	tbnz	w17, #5, LBB1_111
LBB1_80:                                ; %else129
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w17, #6, LBB1_112
LBB1_81:                                ; %cond.store130
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x16, #24
	st1.s	{ v6 }[2], [x0]
	tbz	w17, #7, LBB1_17
	b	LBB1_113
LBB1_82:                                ; %else53
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w2, w2, #0xff
	tbz	w2, #1, LBB1_52
LBB1_83:                                ; %cond.load55
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #4
	ld1.s	{ v27 }[1], [x3]
	tbnz	w2, #2, LBB1_53
LBB1_84:                                ; %else59
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #3, LBB1_54
LBB1_85:                                ; %cond.load61
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #12
	ld1.s	{ v27 }[3], [x3]
	tbnz	w2, #4, LBB1_55
LBB1_86:                                ; %else65
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #5, LBB1_56
LBB1_87:                                ; %cond.load67
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x3, x1, #20
	ld1.s	{ v26 }[1], [x3]
	tbnz	w2, #6, LBB1_57
LBB1_88:                                ; %else71
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w2, #7, LBB1_58
LBB1_89:                                ; %cond.load73
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x1, #28
	ld1.s	{ v26 }[3], [x1]
	fmov	w1, s20
	add	x0, x9, x0
	movi.2d	v29, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w1, #0, LBB1_59
LBB1_90:                                ; %else78
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w1, w1, #0xff
	tbz	w1, #1, LBB1_60
LBB1_91:                                ; %cond.load80
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #4
	ld1.s	{ v29 }[1], [x2]
	tbnz	w1, #2, LBB1_61
LBB1_92:                                ; %else84
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w1, #3, LBB1_62
LBB1_93:                                ; %cond.load86
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #12
	ld1.s	{ v29 }[3], [x2]
	tbnz	w1, #4, LBB1_63
LBB1_94:                                ; %else90
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w1, #5, LBB1_64
LBB1_95:                                ; %cond.load92
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x2, x0, #20
	ld1.s	{ v28 }[1], [x2]
	tbnz	w1, #6, LBB1_65
LBB1_96:                                ; %else96
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w1, #7, LBB1_66
LBB1_97:                                ; %cond.load98
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x0, #28
	ld1.s	{ v28 }[3], [x0]
	fmov	w0, s20
	fmul.4s	v6, v23, v27
	fmul.4s	v30, v25, v29
	fsub.4s	v6, v6, v30
	add	x16, x8, x16
	tbnz	w0, #0, LBB1_67
LBB1_98:                                ; %else102
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w0, w0, #0xff
	tbz	w0, #1, LBB1_68
LBB1_99:                                ; %cond.store103
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x16, #4
	st1.s	{ v6 }[1], [x1]
	tbnz	w0, #2, LBB1_69
LBB1_100:                               ; %else106
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #3, LBB1_70
LBB1_101:                               ; %cond.store107
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x16, #12
	st1.s	{ v6 }[3], [x1]
	fmul.4s	v6, v22, v26
	fmul.4s	v30, v24, v28
	fsub.4s	v6, v6, v30
	tbnz	w0, #4, LBB1_71
LBB1_102:                               ; %else110
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #5, LBB1_72
LBB1_103:                               ; %cond.store111
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x1, x16, #20
	st1.s	{ v6 }[1], [x1]
	tbnz	w0, #6, LBB1_73
LBB1_104:                               ; %else114
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w0, #7, LBB1_74
LBB1_105:                               ; %cond.store115
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x16, x16, #28
	st1.s	{ v6 }[3], [x16]
	fmov	w0, s20
	fmul.4s	v6, v23, v29
	fmul.4s	v23, v25, v27
	fadd.4s	v6, v23, v6
	add	x16, x8, x17
	tbnz	w0, #0, LBB1_75
LBB1_106:                               ; %else119
                                        ;   in Loop: Header=BB1_18 Depth=2
	and	w17, w0, #0xff
	tbz	w17, #1, LBB1_76
LBB1_107:                               ; %cond.store120
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x16, #4
	st1.s	{ v6 }[1], [x0]
	tbnz	w17, #2, LBB1_77
LBB1_108:                               ; %else123
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w17, #3, LBB1_78
LBB1_109:                               ; %cond.store124
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x16, #12
	st1.s	{ v6 }[3], [x0]
	fmul.4s	v6, v22, v28
	fmul.4s	v22, v24, v26
	fadd.4s	v6, v22, v6
	tbnz	w17, #4, LBB1_79
LBB1_110:                               ; %else127
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w17, #5, LBB1_80
LBB1_111:                               ; %cond.store128
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x0, x16, #20
	st1.s	{ v6 }[1], [x0]
	tbnz	w17, #6, LBB1_81
LBB1_112:                               ; %else131
                                        ;   in Loop: Header=BB1_18 Depth=2
	tbz	w17, #7, LBB1_17
LBB1_113:                               ; %cond.store132
                                        ;   in Loop: Header=BB1_18 Depth=2
	add	x16, x16, #28
	st1.s	{ v6 }[3], [x16]
	b	LBB1_17
LBB1_114:                               ; %direct.false32.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v6, v18
	movi.8b	v18, #1
	and.8b	v18, v6, v18
	umov.b	w13, v18[0]
	movi.2d	v28, #0000000000000000
	mov.b	v28[0], v6[0]
	umaxv.8b	b18, v28
	fmov	w15, s18
	rbit	w12, w13
	clz	w12, w12
	tst	w15, #0x1
	csel	w12, w12, wzr, ne
	mov	w14, #2048                      ; =0x800
	dup.2d	v30, x14
	orr.16b	v29, v21, v30
	add.2d	v22, v19, v29
	movi.2d	v18, #0000000000000000
	mov.b	v18[0], v6[0]
	ushll.2d	v6, v18, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v6, v6, v22
	movi.2d	v18, #0000000000000000
	stp	q18, q18, [sp, #528]
	stp	q6, q18, [sp, #496]
	and	x14, x12, #0x7
	add	x16, sp, #496
	ldr	x14, [x16, x14, lsl #3]
	sub	x14, x14, x12
	add	x14, x11, x14, lsl #2
	movi.2d	v20, #0000000000000000
	tbz	w15, #0, LBB1_122
; %bb.115:                              ; %cond.load135
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s20, [x14]
	tbnz	w13, #1, LBB1_123
LBB1_116:                               ; %else139
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_124
LBB1_117:                               ; %cond.load141
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #8
	ld1.s	{ v20 }[2], [x15]
	tbnz	w13, #3, LBB1_125
LBB1_118:                               ; %else145
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_126
LBB1_119:                               ; %cond.load147
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #16
	ld1.s	{ v18 }[0], [x15]
	tbnz	w13, #5, LBB1_127
LBB1_120:                               ; %else151
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_128
LBB1_121:                               ; %cond.load153
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #24
	ld1.s	{ v18 }[2], [x15]
	tbnz	w13, #7, LBB1_129
	b	LBB1_130
LBB1_122:                               ; %else136
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #1, LBB1_116
LBB1_123:                               ; %cond.load138
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #4
	ld1.s	{ v20 }[1], [x15]
	tbnz	w13, #2, LBB1_117
LBB1_124:                               ; %else142
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_118
LBB1_125:                               ; %cond.load144
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #12
	ld1.s	{ v20 }[3], [x15]
	tbnz	w13, #4, LBB1_119
LBB1_126:                               ; %else148
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #5, LBB1_120
LBB1_127:                               ; %cond.load150
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x15, x14, #20
	ld1.s	{ v18 }[1], [x15]
	tbnz	w13, #6, LBB1_121
LBB1_128:                               ; %else154
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_130
LBB1_129:                               ; %cond.load156
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x14, #28
	ld1.s	{ v18 }[3], [x13]
LBB1_130:                               ; %else157
                                        ;   in Loop: Header=BB1_4 Depth=1
	add.2d	v6, v21, v19
	add.2d	v23, v17, v4
	add.2d	v21, v15, v7
	add.2d	v19, v12, v5
	mov	w13, #4097                      ; =0x1001
	dup.2d	v24, x13
	add.2d	v19, v19, v24
	add.2d	v21, v21, v24
	add.2d	v23, v23, v24
	add.2d	v24, v6, v24
	mov	b6, v28[0]
	mov.b	v6[4], v28[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	mov	b25, v28[2]
	mov.b	v25[4], v28[3]
	and.16b	v6, v6, v24
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	and.16b	v25, v25, v23
	mov	b26, v28[4]
	mov.b	v26[4], v28[5]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
	and.16b	v27, v26, v21
	mov	b26, v28[6]
	mov.b	v26[4], v28[7]
	ushll.2d	v26, v26, #0
	shl.2d	v26, v26, #63
	cmlt.2d	v26, v26, #0
	and.16b	v31, v26, v19
Lloh14:
	adrp	x13, lCPI1_11@PAGE
Lloh15:
	ldr	d26, [x13, lCPI1_11@PAGEOFF]
	shl.8b	v8, v28, #7
	cmlt.8b	v8, v8, #0
	and.8b	v26, v8, v26
	addv.8b	b26, v26
	fmov	w13, s26
	stp	q27, q31, [sp, #464]
	stp	q6, q25, [sp, #432]
	and	x14, x12, #0x7
	add	x15, sp, #432
	ldr	x14, [x15, x14, lsl #3]
	sub	x14, x14, x12
	add	x11, x11, x14, lsl #2
	movi.2d	v27, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbz	w13, #0, LBB1_138
; %bb.131:                              ; %cond.load160
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s27, [x11]
	tbnz	w13, #1, LBB1_139
LBB1_132:                               ; %else164
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_140
LBB1_133:                               ; %cond.load166
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #8
	ld1.s	{ v27 }[2], [x14]
	tbnz	w13, #3, LBB1_141
LBB1_134:                               ; %else170
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_142
LBB1_135:                               ; %cond.load172
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #16
	ld1.s	{ v25 }[0], [x14]
	tbnz	w13, #5, LBB1_143
LBB1_136:                               ; %else176
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_144
LBB1_137:                               ; %cond.load178
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #24
	ld1.s	{ v25 }[2], [x14]
	tbnz	w13, #7, LBB1_145
	b	LBB1_146
LBB1_138:                               ; %else161
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #1, LBB1_132
LBB1_139:                               ; %cond.load163
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #4
	ld1.s	{ v27 }[1], [x14]
	tbnz	w13, #2, LBB1_133
LBB1_140:                               ; %else167
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_134
LBB1_141:                               ; %cond.load169
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #12
	ld1.s	{ v27 }[3], [x14]
	tbnz	w13, #4, LBB1_135
LBB1_142:                               ; %else173
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #5, LBB1_136
LBB1_143:                               ; %cond.load175
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x11, #20
	ld1.s	{ v25 }[1], [x14]
	tbnz	w13, #6, LBB1_137
LBB1_144:                               ; %else179
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_146
LBB1_145:                               ; %cond.load181
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x11, #28
	ld1.s	{ v25 }[3], [x11]
LBB1_146:                               ; %else182
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr.16b	v16, v12, v30
	orr.16b	v17, v17, v30
	fmov	x11, d3
	add	x11, x11, x11, lsl #11
	mov.d	x13, v3[1]
	fmov	d3, x11
	add	x11, x13, x13, lsl #11
	mov.d	v3[1], x11
	fmov	x11, d2
	add	x11, x11, x11, lsl #11
	mov.d	x13, v2[1]
	fmov	d2, x11
	add	x11, x13, x13, lsl #11
	mov.d	v2[1], x11
	fmov	x11, d1
	add	x11, x11, x11, lsl #11
	mov.d	x13, v1[1]
	fmov	d6, x11
	add	x11, x13, x13, lsl #11
	mov.d	v6[1], x11
	orr.16b	v1, v15, v30
	fmov	x11, d0
	add	x11, x11, x11, lsl #11
	fmov	d30, x11
	mov.d	x11, v0[1]
	add	x11, x11, x11, lsl #11
	mov.d	v30[1], x11
	add.2d	v0, v30, v16
	add.2d	v6, v6, v1
	add.2d	v2, v2, v17
	add.2d	v3, v3, v29
	mov	b29, v28[0]
	mov.b	v29[4], v28[1]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v3, v29, v3
	mov	b29, v28[2]
	mov.b	v29[4], v28[3]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v2, v29, v2
	mov	b29, v28[4]
	mov.b	v29[4], v28[5]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	mov	b30, v28[6]
	mov.b	v30[4], v28[7]
	and.16b	v6, v29, v6
	ushll.2d	v28, v30, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	and.16b	v0, v28, v0
	stp	q6, q0, [sp, #400]
	stp	q3, q2, [sp, #368]
	and	x11, x12, #0x7
	add	x13, sp, #368
	ldr	x11, [x13, x11, lsl #3]
	fmov	w13, s26
	sub	x11, x11, x12
	lsl	x11, x11, #2
	add	x10, x10, x11
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w13, #0, LBB1_162
; %bb.147:                              ; %cond.load185
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s2, [x10]
	tbnz	w13, #1, LBB1_163
LBB1_148:                               ; %else189
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #2, LBB1_164
LBB1_149:                               ; %cond.load191
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #8
	ld1.s	{ v2 }[2], [x14]
	tbnz	w13, #3, LBB1_165
LBB1_150:                               ; %else195
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #4, LBB1_166
LBB1_151:                               ; %cond.load197
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #16
	ld1.s	{ v0 }[0], [x14]
	tbnz	w13, #5, LBB1_167
LBB1_152:                               ; %else201
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #6, LBB1_168
LBB1_153:                               ; %cond.load203
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #24
	ld1.s	{ v0 }[2], [x14]
	tbnz	w13, #7, LBB1_169
LBB1_154:                               ; %else207
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, x11
	fmov	w10, s26
	movi.2d	v6, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w10, #0, LBB1_170
LBB1_155:                               ; %cond.load210
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	s6, [x9]
	tbnz	w10, #1, LBB1_171
LBB1_156:                               ; %else214
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_172
LBB1_157:                               ; %cond.load216
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v6 }[2], [x11]
	tbnz	w10, #3, LBB1_173
LBB1_158:                               ; %else220
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #4, LBB1_174
LBB1_159:                               ; %cond.load222
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v3 }[0], [x11]
	tbnz	w10, #5, LBB1_175
LBB1_160:                               ; %else226
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_176
LBB1_161:                               ; %cond.load228
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v3 }[2], [x11]
	tbnz	w10, #7, LBB1_177
	b	LBB1_178
LBB1_162:                               ; %else186
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #1, LBB1_148
LBB1_163:                               ; %cond.load188
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #4
	ld1.s	{ v2 }[1], [x14]
	tbnz	w13, #2, LBB1_149
LBB1_164:                               ; %else192
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #3, LBB1_150
LBB1_165:                               ; %cond.load194
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #12
	ld1.s	{ v2 }[3], [x14]
	tbnz	w13, #4, LBB1_151
LBB1_166:                               ; %else198
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #5, LBB1_152
LBB1_167:                               ; %cond.load200
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x10, #20
	ld1.s	{ v0 }[1], [x14]
	tbnz	w13, #6, LBB1_153
LBB1_168:                               ; %else204
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w13, #7, LBB1_154
LBB1_169:                               ; %cond.load206
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v0 }[3], [x10]
	add	x9, x9, x11
	fmov	w10, s26
	movi.2d	v6, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w10, #0, LBB1_155
LBB1_170:                               ; %else211
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #1, LBB1_156
LBB1_171:                               ; %cond.load213
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v6 }[1], [x11]
	tbnz	w10, #2, LBB1_157
LBB1_172:                               ; %else217
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_158
LBB1_173:                               ; %cond.load219
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v6 }[3], [x11]
	tbnz	w10, #4, LBB1_159
LBB1_174:                               ; %else223
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_160
LBB1_175:                               ; %cond.load225
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v3 }[1], [x11]
	tbnz	w10, #6, LBB1_161
LBB1_176:                               ; %else229
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_178
LBB1_177:                               ; %cond.load231
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v3 }[3], [x9]
LBB1_178:                               ; %else232
                                        ;   in Loop: Header=BB1_4 Depth=1
	add.2d	v7, v7, v1
	add.2d	v4, v4, v17
	add.2d	v5, v5, v16
	fmul.4s	v1, v20, v2
	fmul.4s	v16, v27, v6
	fsub.4s	v1, v1, v16
	stp	q22, q4, [sp, #304]
	stp	q7, q5, [sp, #336]
	and	x9, x12, #0x7
	add	x10, sp, #304
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x12
	add	x9, x8, x9, lsl #2
	fmov	w10, s26
	tbz	w10, #0, LBB1_186
; %bb.179:                              ; %cond.store235
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x9]
	tbnz	w10, #1, LBB1_187
LBB1_180:                               ; %else238
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_188
LBB1_181:                               ; %cond.store239
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	st1.s	{ v1 }[2], [x11]
	tbnz	w10, #3, LBB1_189
LBB1_182:                               ; %else242
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v1, v18, v0
	fmul.4s	v4, v25, v3
	fsub.4s	v1, v1, v4
	tbz	w10, #4, LBB1_190
LBB1_183:                               ; %cond.store243
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x9, #16]
	tbnz	w10, #5, LBB1_191
LBB1_184:                               ; %else246
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_192
LBB1_185:                               ; %cond.store247
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	st1.s	{ v1 }[2], [x11]
	tbnz	w10, #7, LBB1_193
	b	LBB1_194
LBB1_186:                               ; %else236
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #1, LBB1_180
LBB1_187:                               ; %cond.store237
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	st1.s	{ v1 }[1], [x11]
	tbnz	w10, #2, LBB1_181
LBB1_188:                               ; %else240
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_182
LBB1_189:                               ; %cond.store241
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	st1.s	{ v1 }[3], [x11]
	fmul.4s	v1, v18, v0
	fmul.4s	v4, v25, v3
	fsub.4s	v1, v1, v4
	tbnz	w10, #4, LBB1_183
LBB1_190:                               ; %else244
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_184
LBB1_191:                               ; %cond.store245
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	st1.s	{ v1 }[1], [x11]
	tbnz	w10, #6, LBB1_185
LBB1_192:                               ; %else248
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_194
LBB1_193:                               ; %cond.store249
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	st1.s	{ v1 }[3], [x9]
LBB1_194:                               ; %else250
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v1, v20, v6
	fmul.4s	v2, v27, v2
	fadd.4s	v1, v2, v1
	stp	q24, q23, [sp, #240]
	stp	q21, q19, [sp, #272]
	and	x9, x12, #0x7
	add	x10, sp, #240
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x12
	add	x8, x8, x9, lsl #2
	fmov	w9, s26
	tbz	w9, #0, LBB1_202
; %bb.195:                              ; %cond.store252
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x8]
	tbnz	w9, #1, LBB1_203
LBB1_196:                               ; %else255
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #2, LBB1_204
LBB1_197:                               ; %cond.store256
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #8
	st1.s	{ v1 }[2], [x10]
	tbnz	w9, #3, LBB1_205
LBB1_198:                               ; %else259
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v1, v18, v3
	fmul.4s	v0, v25, v0
	fadd.4s	v0, v0, v1
	tbz	w9, #4, LBB1_403
LBB1_199:                               ; %cond.store260
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s0, [x8, #16]
	tbnz	w9, #5, LBB1_404
LBB1_200:                               ; %else531
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #6, LBB1_405
LBB1_201:                               ; %cond.store532
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB1_406
	b	LBB1_2
LBB1_202:                               ; %else253
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #1, LBB1_196
LBB1_203:                               ; %cond.store254
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #4
	st1.s	{ v1 }[1], [x10]
	tbnz	w9, #2, LBB1_197
LBB1_204:                               ; %else257
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #3, LBB1_198
LBB1_205:                               ; %cond.store258
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #12
	st1.s	{ v1 }[3], [x10]
	fmul.4s	v1, v18, v3
	fmul.4s	v0, v25, v0
	fadd.4s	v0, v0, v1
	tbz	w9, #4, LBB1_403
	b	LBB1_199
LBB1_206:                               ; %direct.schedule.8.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x12, #0                         ; =0x0
	fmov	x15, d3
	mov	w13, #16392                     ; =0x4008
	umaddl	x13, w15, w13, x11
	add	x3, sp, #6, lsl #12             ; =24576
	add	x3, x3, #1136
	mov	w5, #8196                       ; =0x2004
	add	x6, sp, #4, lsl #12             ; =16384
	add	x6, x6, #1104
	b	LBB1_208
LBB1_207:                               ; %else291
                                        ;   in Loop: Header=BB1_208 Depth=2
	add	x14, x3, x12
	stp	q24, q6, [x14]
	add	x12, x12, #32
	cmp	x12, #2, lsl #12                ; =8192
	b.eq	LBB1_224
LBB1_208:                               ; %direct.true60.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and.16b	v6, v18, v10
	addv.8h	h7, v6
	fmov	w16, s7
	add	x14, x13, x12
	add	x17, x3, x12
	ldr	q24, [x17]
	tbz	w16, #0, LBB1_216
; %bb.209:                              ; %cond.load269
                                        ;   in Loop: Header=BB1_208 Depth=2
	ld1.s	{ v24 }[0], [x14]
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB1_217
LBB1_210:                               ; %else273
                                        ;   in Loop: Header=BB1_208 Depth=2
	tbz	w16, #2, LBB1_218
LBB1_211:                               ; %cond.load275
                                        ;   in Loop: Header=BB1_208 Depth=2
	add	x0, x14, #8
	ld1.s	{ v24 }[2], [x0]
	tbnz	w16, #3, LBB1_219
LBB1_212:                               ; %else279
                                        ;   in Loop: Header=BB1_208 Depth=2
	ldr	q6, [x17, #16]
	tbz	w16, #4, LBB1_220
LBB1_213:                               ; %cond.load281
                                        ;   in Loop: Header=BB1_208 Depth=2
	add	x17, x14, #16
	ld1.s	{ v6 }[0], [x17]
	tbnz	w16, #5, LBB1_221
LBB1_214:                               ; %else285
                                        ;   in Loop: Header=BB1_208 Depth=2
	tbz	w16, #6, LBB1_222
LBB1_215:                               ; %cond.load287
                                        ;   in Loop: Header=BB1_208 Depth=2
	add	x17, x14, #24
	ld1.s	{ v6 }[2], [x17]
	tbz	w16, #7, LBB1_207
	b	LBB1_223
LBB1_216:                               ; %else270
                                        ;   in Loop: Header=BB1_208 Depth=2
	and	w16, w16, #0xff
	tbz	w16, #1, LBB1_210
LBB1_217:                               ; %cond.load272
                                        ;   in Loop: Header=BB1_208 Depth=2
	add	x0, x14, #4
	ld1.s	{ v24 }[1], [x0]
	tbnz	w16, #2, LBB1_211
LBB1_218:                               ; %else276
                                        ;   in Loop: Header=BB1_208 Depth=2
	tbz	w16, #3, LBB1_212
LBB1_219:                               ; %cond.load278
                                        ;   in Loop: Header=BB1_208 Depth=2
	add	x0, x14, #12
	ld1.s	{ v24 }[3], [x0]
	ldr	q6, [x17, #16]
	tbnz	w16, #4, LBB1_213
LBB1_220:                               ; %else282
                                        ;   in Loop: Header=BB1_208 Depth=2
	tbz	w16, #5, LBB1_214
LBB1_221:                               ; %cond.load284
                                        ;   in Loop: Header=BB1_208 Depth=2
	add	x17, x14, #20
	ld1.s	{ v6 }[1], [x17]
	tbnz	w16, #6, LBB1_215
LBB1_222:                               ; %else288
                                        ;   in Loop: Header=BB1_208 Depth=2
	tbz	w16, #7, LBB1_207
LBB1_223:                               ; %cond.load290
                                        ;   in Loop: Header=BB1_208 Depth=2
	add	x14, x14, #28
	ld1.s	{ v6 }[3], [x14]
	b	LBB1_207
LBB1_224:                               ; %direct.false61.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	xtn.8b	v6, v18
	sshll.2d	v28, v4, #0
	sshll.2d	v29, v5, #0
	movi.8b	v18, #1
	and.8b	v18, v6, v18
	umov.b	w14, v18[0]
	movi.2d	v18, #0000000000000000
	mov.b	v18[0], v6[0]
	umaxv.8b	b24, v18
	fmov	w17, s24
	rbit	w12, w14
	clz	w12, w12
	tst	w17, #0x1
	mov	w13, #2048                      ; =0x800
	dup.2d	v27, x13
	csel	w12, w12, wzr, ne
	orr.16b	v11, v21, v27
	mov.16b	v16, v11
	movi.2d	v30, #0000000000000000
	mov.b	v30[0], v6[0]
	umlal.2d	v16, v26, v9
	ushll.2d	v6, v30, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	str	q16, [sp, #80]                  ; 16-byte Spill
	and.16b	v6, v6, v16
	movi.2d	v30, #0000000000000000
	stp	q30, q30, [sp, #928]
	stp	q6, q30, [sp, #896]
	ubfiz	x13, x12, #3, #3
	add	x16, sp, #896
	ldr	x16, [x16, x13]
	sub	x16, x16, x12
	add	x16, x11, x16, lsl #2
Lloh16:
	adrp	x0, lCPI1_7@PAGE
Lloh17:
	ldr	q6, [x0, lCPI1_7@PAGEOFF]
	mov	w0, #8192                       ; =0x2000
	dup.2d	v30, x0
	bif.16b	v6, v30, v29
Lloh18:
	adrp	x0, lCPI1_8@PAGE
Lloh19:
	ldr	q29, [x0, lCPI1_8@PAGEOFF]
	bsl.16b	v28, v29, v30
Lloh20:
	adrp	x0, lCPI1_9@PAGE
Lloh21:
	ldr	q29, [x0, lCPI1_9@PAGEOFF]
	bsl.16b	v20, v29, v30
Lloh22:
	adrp	x0, lCPI1_10@PAGE
Lloh23:
	ldr	q29, [x0, lCPI1_10@PAGEOFF]
	bsl.16b	v19, v29, v30
	stp	q28, q19, [sp, #992]
	stp	q6, q20, [sp, #960]
	add	x0, sp, #960
	ldr	x13, [x0, x13]
	sub	x13, x13, w12, uxtw #2
	tst	w14, #0x1
	csel	x13, xzr, x13, eq
	add	x0, x3, x13
	ldp	q20, q19, [x0]
	tbz	w17, #0, LBB1_232
; %bb.225:                              ; %cond.load294
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v20 }[0], [x16]
	tbnz	w14, #1, LBB1_233
LBB1_226:                               ; %else298
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #2, LBB1_234
LBB1_227:                               ; %cond.load300
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #8
	ld1.s	{ v20 }[2], [x17]
	tbnz	w14, #3, LBB1_235
LBB1_228:                               ; %else304
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #4, LBB1_236
LBB1_229:                               ; %cond.load306
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #16
	ld1.s	{ v19 }[0], [x17]
	tbnz	w14, #5, LBB1_237
LBB1_230:                               ; %else310
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #6, LBB1_238
LBB1_231:                               ; %cond.load312
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #24
	ld1.s	{ v19 }[2], [x17]
	tbnz	w14, #7, LBB1_239
	b	LBB1_240
LBB1_232:                               ; %else295
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #1, LBB1_226
LBB1_233:                               ; %cond.load297
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #4
	ld1.s	{ v20 }[1], [x17]
	tbnz	w14, #2, LBB1_227
LBB1_234:                               ; %else301
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #3, LBB1_228
LBB1_235:                               ; %cond.load303
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #12
	ld1.s	{ v20 }[3], [x17]
	tbnz	w14, #4, LBB1_229
LBB1_236:                               ; %else307
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #5, LBB1_230
LBB1_237:                               ; %cond.load309
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x16, #20
	ld1.s	{ v19 }[1], [x17]
	tbnz	w14, #6, LBB1_231
LBB1_238:                               ; %else313
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w14, #7, LBB1_240
LBB1_239:                               ; %cond.load315
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x14, x16, #28
	ld1.s	{ v19 }[3], [x14]
LBB1_240:                               ; %else316
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x17, #0                         ; =0x0
	mov.16b	v16, v12
	orr.16b	v13, v12, v27
	orr.16b	v12, v17, v27
	mov.16b	v14, v15
	orr.16b	v24, v15, v27
	umull.2d	v30, v26, v9
	umull.2d	v31, v23, v9
	umull.2d	v10, v25, v9
	umull.2d	v15, v22, v9
	mov.16b	v6, v24
	umlal.2d	v6, v25, v9
	str	q6, [sp, #48]                   ; 16-byte Spill
	mov.16b	v6, v12
	umlal.2d	v6, v23, v9
	str	q6, [sp, #32]                   ; 16-byte Spill
	mov.16b	v6, v13
	umlal.2d	v6, v22, v9
	str	q6, [sp, #16]                   ; 16-byte Spill
	add	x14, x3, x13
	stp	q20, q19, [x14]
	fmov	x14, d30
	ushll2.2d	v6, v4, #0
	mov	w16, #1                         ; =0x1
	dup.2d	v26, x16
	and.16b	v22, v6, v26
	ushll2.2d	v6, v5, #0
	and.16b	v23, v6, v26
	ushll.2d	v6, v4, #0
	and.16b	v25, v6, v26
	ushll.2d	v6, v5, #0
	and.16b	v26, v6, v26
	lsl	x14, x14, #2
	add	x16, x11, x14
	movi.2d	v9, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	b	LBB1_242
LBB1_241:                               ; %else341
                                        ;   in Loop: Header=BB1_242 Depth=2
	add	x17, x6, x17
	stp	q29, q6, [x17]
	add.2d	v8, v8, v23
	add.2d	v27, v27, v25
	add.2d	v28, v28, v22
	add.2d	v9, v9, v26
	fmov	x17, d9
	cmp	x17, #256
	b.ge	LBB1_258
LBB1_242:                               ; %direct.true82.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w1, s7
	lsl	x17, x17, #5
	add	x0, x16, x17
	add	x0, x0, x5
	add	x2, x6, x17
	ldp	q29, q6, [x2]
	tbz	w1, #0, LBB1_250
; %bb.243:                              ; %cond.load319
                                        ;   in Loop: Header=BB1_242 Depth=2
	ld1.s	{ v29 }[0], [x0]
	and	w1, w1, #0xff
	tbnz	w1, #1, LBB1_251
LBB1_244:                               ; %else323
                                        ;   in Loop: Header=BB1_242 Depth=2
	tbz	w1, #2, LBB1_252
LBB1_245:                               ; %cond.load325
                                        ;   in Loop: Header=BB1_242 Depth=2
	add	x2, x0, #8
	ld1.s	{ v29 }[2], [x2]
	tbnz	w1, #3, LBB1_253
LBB1_246:                               ; %else329
                                        ;   in Loop: Header=BB1_242 Depth=2
	tbz	w1, #4, LBB1_254
LBB1_247:                               ; %cond.load331
                                        ;   in Loop: Header=BB1_242 Depth=2
	add	x2, x0, #16
	ld1.s	{ v6 }[0], [x2]
	tbnz	w1, #5, LBB1_255
LBB1_248:                               ; %else335
                                        ;   in Loop: Header=BB1_242 Depth=2
	tbz	w1, #6, LBB1_256
LBB1_249:                               ; %cond.load337
                                        ;   in Loop: Header=BB1_242 Depth=2
	add	x2, x0, #24
	ld1.s	{ v6 }[2], [x2]
	tbz	w1, #7, LBB1_241
	b	LBB1_257
LBB1_250:                               ; %else320
                                        ;   in Loop: Header=BB1_242 Depth=2
	and	w1, w1, #0xff
	tbz	w1, #1, LBB1_244
LBB1_251:                               ; %cond.load322
                                        ;   in Loop: Header=BB1_242 Depth=2
	add	x2, x0, #4
	ld1.s	{ v29 }[1], [x2]
	tbnz	w1, #2, LBB1_245
LBB1_252:                               ; %else326
                                        ;   in Loop: Header=BB1_242 Depth=2
	tbz	w1, #3, LBB1_246
LBB1_253:                               ; %cond.load328
                                        ;   in Loop: Header=BB1_242 Depth=2
	add	x2, x0, #12
	ld1.s	{ v29 }[3], [x2]
	tbnz	w1, #4, LBB1_247
LBB1_254:                               ; %else332
                                        ;   in Loop: Header=BB1_242 Depth=2
	tbz	w1, #5, LBB1_248
LBB1_255:                               ; %cond.load334
                                        ;   in Loop: Header=BB1_242 Depth=2
	add	x2, x0, #20
	ld1.s	{ v6 }[1], [x2]
	tbnz	w1, #6, LBB1_249
LBB1_256:                               ; %else338
                                        ;   in Loop: Header=BB1_242 Depth=2
	tbz	w1, #7, LBB1_241
LBB1_257:                               ; %cond.load340
                                        ;   in Loop: Header=BB1_242 Depth=2
	add	x0, x0, #28
	ld1.s	{ v6 }[3], [x0]
	b	LBB1_241
LBB1_258:                               ; %direct.false83.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add.2d	v21, v21, v30
	add.2d	v17, v17, v31
	add.2d	v27, v14, v10
	add.2d	v6, v16, v15
	mov	w16, #4097                      ; =0x1001
	dup.2d	v28, x16
	add.2d	v16, v6, v28
	add.2d	v6, v27, v28
	add.2d	v17, v17, v28
	add.2d	v21, v21, v28
	mov	b27, v18[0]
	mov.b	v27[4], v18[1]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	and.16b	v27, v27, v21
	mov	b28, v18[2]
	mov.b	v28[4], v18[3]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	mov	b29, v18[4]
	mov.b	v29[4], v18[5]
	and.16b	v28, v28, v17
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	str	q6, [sp, #64]                   ; 16-byte Spill
	and.16b	v29, v29, v6
	mov	b30, v18[6]
	mov.b	v30[4], v18[7]
	ushll.2d	v30, v30, #0
	shl.2d	v30, v30, #63
	cmlt.2d	v30, v30, #0
	and.16b	v30, v30, v16
Lloh24:
	adrp	x16, lCPI1_11@PAGE
Lloh25:
	ldr	d31, [x16, lCPI1_11@PAGEOFF]
	shl.8b	v8, v18, #7
	cmlt.8b	v8, v8, #0
	and.8b	v31, v8, v31
	addv.8b	b31, v31
	stp	q29, q30, [sp, #848]
	stp	q27, q28, [sp, #816]
	and	x16, x12, #0x7
	add	x17, sp, #816
	ldr	x17, [x17, x16, lsl #3]
	fmov	w16, s31
	sub	x17, x17, x12
	add	x11, x11, x17, lsl #2
	add	x17, x6, x13
	ldp	q10, q30, [x17]
	tbz	w16, #0, LBB1_266
; %bb.259:                              ; %cond.load344
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v10 }[0], [x11]
	tbnz	w16, #1, LBB1_267
LBB1_260:                               ; %else348
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #2, LBB1_268
LBB1_261:                               ; %cond.load350
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x11, #8
	ld1.s	{ v10 }[2], [x17]
	tbnz	w16, #3, LBB1_269
LBB1_262:                               ; %else354
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #4, LBB1_270
LBB1_263:                               ; %cond.load356
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x11, #16
	ld1.s	{ v30 }[0], [x17]
	tbnz	w16, #5, LBB1_271
LBB1_264:                               ; %else360
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #6, LBB1_272
LBB1_265:                               ; %cond.load362
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x11, #24
	ld1.s	{ v30 }[2], [x17]
	tbnz	w16, #7, LBB1_273
	b	LBB1_274
LBB1_266:                               ; %else345
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #1, LBB1_260
LBB1_267:                               ; %cond.load347
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x11, #4
	ld1.s	{ v10 }[1], [x17]
	tbnz	w16, #2, LBB1_261
LBB1_268:                               ; %else351
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #3, LBB1_262
LBB1_269:                               ; %cond.load353
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x11, #12
	ld1.s	{ v10 }[3], [x17]
	tbnz	w16, #4, LBB1_263
LBB1_270:                               ; %else357
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #5, LBB1_264
LBB1_271:                               ; %cond.load359
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x17, x11, #20
	ld1.s	{ v30 }[1], [x17]
	tbnz	w16, #6, LBB1_265
LBB1_272:                               ; %else363
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w16, #7, LBB1_274
LBB1_273:                               ; %cond.load365
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x11, #28
	ld1.s	{ v30 }[3], [x11]
LBB1_274:                               ; %else366
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x16, #0                         ; =0x0
	add	x11, x6, x13
	stp	q10, q30, [x11]
	umaddl	x11, w15, w5, x10
	movi.2d	v9, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v8, #0000000000000000
	b	LBB1_276
LBB1_275:                               ; %else391
                                        ;   in Loop: Header=BB1_276 Depth=2
	add	x15, x28, x15
	stp	q29, q15, [x15]
	add.2d	v27, v27, v23
	add.2d	v28, v28, v25
	add.2d	v8, v8, v22
	add.2d	v9, v9, v26
	fmov	x16, d9
	cmp	x16, #256
	b.ge	LBB1_292
LBB1_276:                               ; %direct.true103.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w17, s7
	lsl	x15, x16, #5
	add	x16, x11, x15
	add	x0, x28, x15
	ldp	q29, q15, [x0]
	tbz	w17, #0, LBB1_284
; %bb.277:                              ; %cond.load369
                                        ;   in Loop: Header=BB1_276 Depth=2
	ld1.s	{ v29 }[0], [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_285
LBB1_278:                               ; %else373
                                        ;   in Loop: Header=BB1_276 Depth=2
	tbz	w17, #2, LBB1_286
LBB1_279:                               ; %cond.load375
                                        ;   in Loop: Header=BB1_276 Depth=2
	add	x0, x16, #8
	ld1.s	{ v29 }[2], [x0]
	tbnz	w17, #3, LBB1_287
LBB1_280:                               ; %else379
                                        ;   in Loop: Header=BB1_276 Depth=2
	tbz	w17, #4, LBB1_288
LBB1_281:                               ; %cond.load381
                                        ;   in Loop: Header=BB1_276 Depth=2
	add	x0, x16, #16
	ld1.s	{ v15 }[0], [x0]
	tbnz	w17, #5, LBB1_289
LBB1_282:                               ; %else385
                                        ;   in Loop: Header=BB1_276 Depth=2
	tbz	w17, #6, LBB1_290
LBB1_283:                               ; %cond.load387
                                        ;   in Loop: Header=BB1_276 Depth=2
	add	x0, x16, #24
	ld1.s	{ v15 }[2], [x0]
	tbz	w17, #7, LBB1_275
	b	LBB1_291
LBB1_284:                               ; %else370
                                        ;   in Loop: Header=BB1_276 Depth=2
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_278
LBB1_285:                               ; %cond.load372
                                        ;   in Loop: Header=BB1_276 Depth=2
	add	x0, x16, #4
	ld1.s	{ v29 }[1], [x0]
	tbnz	w17, #2, LBB1_279
LBB1_286:                               ; %else376
                                        ;   in Loop: Header=BB1_276 Depth=2
	tbz	w17, #3, LBB1_280
LBB1_287:                               ; %cond.load378
                                        ;   in Loop: Header=BB1_276 Depth=2
	add	x0, x16, #12
	ld1.s	{ v29 }[3], [x0]
	tbnz	w17, #4, LBB1_281
LBB1_288:                               ; %else382
                                        ;   in Loop: Header=BB1_276 Depth=2
	tbz	w17, #5, LBB1_282
LBB1_289:                               ; %cond.load384
                                        ;   in Loop: Header=BB1_276 Depth=2
	add	x0, x16, #20
	ld1.s	{ v15 }[1], [x0]
	tbnz	w17, #6, LBB1_283
LBB1_290:                               ; %else388
                                        ;   in Loop: Header=BB1_276 Depth=2
	tbz	w17, #7, LBB1_275
LBB1_291:                               ; %cond.load390
                                        ;   in Loop: Header=BB1_276 Depth=2
	add	x16, x16, #28
	ld1.s	{ v15 }[3], [x16]
	b	LBB1_275
LBB1_292:                               ; %direct.false104.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x11, d3
	add	x11, x11, x11, lsl #11
	fmov	d15, x11
	mov.d	x11, v3[1]
	add	x11, x11, x11, lsl #11
	mov.d	v15[1], x11
	fmov	x11, d2
	add	x11, x11, x11, lsl #11
	mov.d	x15, v2[1]
	fmov	d2, x11
	add	x11, x15, x15, lsl #11
	mov.d	v2[1], x11
	fmov	x11, d1
	add	x11, x11, x11, lsl #11
	fmov	d3, x11
	mov.d	x11, v1[1]
	add	x11, x11, x11, lsl #11
	mov.d	v3[1], x11
	fmov	x11, d0
	add	x11, x11, x11, lsl #11
	fmov	d1, x11
	mov.d	x11, v0[1]
	add	x11, x11, x11, lsl #11
	mov.d	v1[1], x11
	add.2d	v0, v1, v13
	add.2d	v1, v3, v24
	add.2d	v2, v2, v12
	add.2d	v3, v15, v11
	mov	b27, v18[0]
	mov.b	v27[4], v18[1]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	and.16b	v3, v27, v3
	mov	b27, v18[2]
	mov.b	v27[4], v18[3]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	and.16b	v2, v27, v2
	mov	b27, v18[4]
	mov.b	v27[4], v18[5]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	and.16b	v1, v27, v1
	mov	b27, v18[6]
	mov.b	v27[4], v18[7]
	ushll.2d	v27, v27, #0
	shl.2d	v27, v27, #63
	cmlt.2d	v27, v27, #0
	and.16b	v0, v27, v0
	fmov	w15, s31
	stp	q1, q0, [sp, #768]
	stp	q3, q2, [sp, #736]
	and	x11, x12, #0x7
	add	x16, sp, #736
	ldr	x11, [x16, x11, lsl #3]
	sub	x11, x11, x12
	lsl	x11, x11, #2
	add	x10, x10, x11
	add	x16, x28, x13
	ldp	q1, q0, [x16]
	tbz	w15, #0, LBB1_300
; %bb.293:                              ; %cond.load394
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v1 }[0], [x10]
	tbnz	w15, #1, LBB1_301
LBB1_294:                               ; %else398
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #2, LBB1_302
LBB1_295:                               ; %cond.load400
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x10, #8
	ld1.s	{ v1 }[2], [x16]
	tbnz	w15, #3, LBB1_303
LBB1_296:                               ; %else404
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #4, LBB1_304
LBB1_297:                               ; %cond.load406
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x10, #16
	ld1.s	{ v0 }[0], [x16]
	tbnz	w15, #5, LBB1_305
LBB1_298:                               ; %else410
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #6, LBB1_306
LBB1_299:                               ; %cond.load412
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x10, #24
	ld1.s	{ v0 }[2], [x16]
	tbnz	w15, #7, LBB1_307
	b	LBB1_308
LBB1_300:                               ; %else395
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #1, LBB1_294
LBB1_301:                               ; %cond.load397
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x10, #4
	ld1.s	{ v1 }[1], [x16]
	tbnz	w15, #2, LBB1_295
LBB1_302:                               ; %else401
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #3, LBB1_296
LBB1_303:                               ; %cond.load403
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x10, #12
	ld1.s	{ v1 }[3], [x16]
	tbnz	w15, #4, LBB1_297
LBB1_304:                               ; %else407
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #5, LBB1_298
LBB1_305:                               ; %cond.load409
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x16, x10, #20
	ld1.s	{ v0 }[1], [x16]
	tbnz	w15, #6, LBB1_299
LBB1_306:                               ; %else413
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w15, #7, LBB1_308
LBB1_307:                               ; %cond.load415
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x10, #28
	ld1.s	{ v0 }[3], [x10]
LBB1_308:                               ; %else416
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x15, #0                         ; =0x0
	add	x10, x28, x13
	stp	q1, q0, [x10]
	fmov	x10, d15
	add	x10, x9, x10, lsl #2
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	b	LBB1_310
LBB1_309:                               ; %else441
                                        ;   in Loop: Header=BB1_310 Depth=2
	add	x15, x21, x15
	stp	q29, q8, [x15]
	add.2d	v3, v3, v23
	add.2d	v27, v27, v25
	add.2d	v28, v28, v22
	add.2d	v2, v2, v26
	fmov	x15, d2
	cmp	x15, #256
	b.ge	LBB1_326
LBB1_310:                               ; %direct.true124.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w17, s7
	lsl	x15, x15, #5
	add	x16, x10, x15
	add	x0, x21, x15
	ldp	q29, q8, [x0]
	tbz	w17, #0, LBB1_318
; %bb.311:                              ; %cond.load419
                                        ;   in Loop: Header=BB1_310 Depth=2
	ld1.s	{ v29 }[0], [x16]
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_319
LBB1_312:                               ; %else423
                                        ;   in Loop: Header=BB1_310 Depth=2
	tbz	w17, #2, LBB1_320
LBB1_313:                               ; %cond.load425
                                        ;   in Loop: Header=BB1_310 Depth=2
	add	x0, x16, #8
	ld1.s	{ v29 }[2], [x0]
	tbnz	w17, #3, LBB1_321
LBB1_314:                               ; %else429
                                        ;   in Loop: Header=BB1_310 Depth=2
	tbz	w17, #4, LBB1_322
LBB1_315:                               ; %cond.load431
                                        ;   in Loop: Header=BB1_310 Depth=2
	add	x0, x16, #16
	ld1.s	{ v8 }[0], [x0]
	tbnz	w17, #5, LBB1_323
LBB1_316:                               ; %else435
                                        ;   in Loop: Header=BB1_310 Depth=2
	tbz	w17, #6, LBB1_324
LBB1_317:                               ; %cond.load437
                                        ;   in Loop: Header=BB1_310 Depth=2
	add	x0, x16, #24
	ld1.s	{ v8 }[2], [x0]
	tbz	w17, #7, LBB1_309
	b	LBB1_325
LBB1_318:                               ; %else420
                                        ;   in Loop: Header=BB1_310 Depth=2
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_312
LBB1_319:                               ; %cond.load422
                                        ;   in Loop: Header=BB1_310 Depth=2
	add	x0, x16, #4
	ld1.s	{ v29 }[1], [x0]
	tbnz	w17, #2, LBB1_313
LBB1_320:                               ; %else426
                                        ;   in Loop: Header=BB1_310 Depth=2
	tbz	w17, #3, LBB1_314
LBB1_321:                               ; %cond.load428
                                        ;   in Loop: Header=BB1_310 Depth=2
	add	x0, x16, #12
	ld1.s	{ v29 }[3], [x0]
	tbnz	w17, #4, LBB1_315
LBB1_322:                               ; %else432
                                        ;   in Loop: Header=BB1_310 Depth=2
	tbz	w17, #5, LBB1_316
LBB1_323:                               ; %cond.load434
                                        ;   in Loop: Header=BB1_310 Depth=2
	add	x0, x16, #20
	ld1.s	{ v8 }[1], [x0]
	tbnz	w17, #6, LBB1_317
LBB1_324:                               ; %else438
                                        ;   in Loop: Header=BB1_310 Depth=2
	tbz	w17, #7, LBB1_309
LBB1_325:                               ; %cond.load440
                                        ;   in Loop: Header=BB1_310 Depth=2
	add	x16, x16, #28
	ld1.s	{ v8 }[3], [x16]
	b	LBB1_309
LBB1_326:                               ; %direct.false125.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, x11
	add	x10, x21, x13
	ldp	q3, q2, [x10]
	fmov	w10, s31
	tbz	w10, #0, LBB1_334
; %bb.327:                              ; %cond.load444
                                        ;   in Loop: Header=BB1_4 Depth=1
	ld1.s	{ v3 }[0], [x9]
	tbnz	w10, #1, LBB1_335
LBB1_328:                               ; %else448
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_336
LBB1_329:                               ; %cond.load450
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #8
	ld1.s	{ v3 }[2], [x11]
	tbnz	w10, #3, LBB1_337
LBB1_330:                               ; %else454
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #4, LBB1_338
LBB1_331:                               ; %cond.load456
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #16
	ld1.s	{ v2 }[0], [x11]
	tbnz	w10, #5, LBB1_339
LBB1_332:                               ; %else460
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_340
LBB1_333:                               ; %cond.load462
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #24
	ld1.s	{ v2 }[2], [x11]
	tbnz	w10, #7, LBB1_341
	b	LBB1_342
LBB1_334:                               ; %else445
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #1, LBB1_328
LBB1_335:                               ; %cond.load447
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #4
	ld1.s	{ v3 }[1], [x11]
	tbnz	w10, #2, LBB1_329
LBB1_336:                               ; %else451
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_330
LBB1_337:                               ; %cond.load453
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #12
	ld1.s	{ v3 }[3], [x11]
	tbnz	w10, #4, LBB1_331
LBB1_338:                               ; %else457
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_332
LBB1_339:                               ; %cond.load459
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x11, x9, #20
	ld1.s	{ v2 }[1], [x11]
	tbnz	w10, #6, LBB1_333
LBB1_340:                               ; %else463
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_342
LBB1_341:                               ; %cond.load465
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x9, x9, #28
	ld1.s	{ v2 }[3], [x9]
LBB1_342:                               ; %else466
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	add	x9, x21, x13
	stp	q3, q2, [x9]
	add	x9, x8, x14
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v8, #0000000000000000
	b	LBB1_344
LBB1_343:                               ; %else484
                                        ;   in Loop: Header=BB1_344 Depth=2
	add.2d	v28, v28, v23
	add.2d	v29, v29, v25
	add.2d	v8, v8, v22
	add.2d	v27, v27, v26
	fmov	x10, d27
	cmp	x10, #256
	b.ge	LBB1_360
LBB1_344:                               ; %direct.true145.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s7
	lsl	x10, x10, #5
	add	x13, x3, x10
	ldp	q12, q9, [x13]
	add	x13, x28, x10
	ldp	q13, q11, [x13]
	fmul.4s	v14, v12, v13
	add	x13, x6, x10
	ldp	q15, q12, [x13]
	add	x13, x21, x10
	ldp	q6, q13, [x13]
	fmul.4s	v6, v15, v6
	fsub.4s	v6, v14, v6
	and.16b	v14, v5, v6
	add	x10, x9, x10
	tbz	w11, #0, LBB1_352
; %bb.345:                              ; %cond.store469
                                        ;   in Loop: Header=BB1_344 Depth=2
	str	s14, [x10]
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_353
LBB1_346:                               ; %else472
                                        ;   in Loop: Header=BB1_344 Depth=2
	tbz	w11, #2, LBB1_354
LBB1_347:                               ; %cond.store473
                                        ;   in Loop: Header=BB1_344 Depth=2
	add	x13, x10, #8
	st1.s	{ v14 }[2], [x13]
	tbnz	w11, #3, LBB1_355
LBB1_348:                               ; %else476
                                        ;   in Loop: Header=BB1_344 Depth=2
	fmul.4s	v6, v9, v11
	fmul.4s	v9, v12, v13
	fsub.4s	v6, v6, v9
	and.16b	v9, v4, v6
	tbz	w11, #4, LBB1_356
LBB1_349:                               ; %cond.store477
                                        ;   in Loop: Header=BB1_344 Depth=2
	str	s9, [x10, #16]
	tbnz	w11, #5, LBB1_357
LBB1_350:                               ; %else480
                                        ;   in Loop: Header=BB1_344 Depth=2
	tbz	w11, #6, LBB1_358
LBB1_351:                               ; %cond.store481
                                        ;   in Loop: Header=BB1_344 Depth=2
	add	x13, x10, #24
	st1.s	{ v9 }[2], [x13]
	tbz	w11, #7, LBB1_343
	b	LBB1_359
LBB1_352:                               ; %else470
                                        ;   in Loop: Header=BB1_344 Depth=2
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_346
LBB1_353:                               ; %cond.store471
                                        ;   in Loop: Header=BB1_344 Depth=2
	add	x13, x10, #4
	st1.s	{ v14 }[1], [x13]
	tbnz	w11, #2, LBB1_347
LBB1_354:                               ; %else474
                                        ;   in Loop: Header=BB1_344 Depth=2
	tbz	w11, #3, LBB1_348
LBB1_355:                               ; %cond.store475
                                        ;   in Loop: Header=BB1_344 Depth=2
	add	x13, x10, #12
	st1.s	{ v14 }[3], [x13]
	fmul.4s	v6, v9, v11
	fmul.4s	v9, v12, v13
	fsub.4s	v6, v6, v9
	and.16b	v9, v4, v6
	tbnz	w11, #4, LBB1_349
LBB1_356:                               ; %else478
                                        ;   in Loop: Header=BB1_344 Depth=2
	tbz	w11, #5, LBB1_350
LBB1_357:                               ; %cond.store479
                                        ;   in Loop: Header=BB1_344 Depth=2
	add	x13, x10, #20
	st1.s	{ v9 }[1], [x13]
	tbnz	w11, #6, LBB1_351
LBB1_358:                               ; %else482
                                        ;   in Loop: Header=BB1_344 Depth=2
	tbz	w11, #7, LBB1_343
LBB1_359:                               ; %cond.store483
                                        ;   in Loop: Header=BB1_344 Depth=2
	add	x10, x10, #28
	st1.s	{ v9 }[3], [x10]
	b	LBB1_343
LBB1_360:                               ; %direct.false146.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v6, v20, v1
	fmul.4s	v27, v10, v3
	fsub.4s	v6, v6, v27
	zip1.8b	v27, v18, v0
	ushll.4s	v27, v27, #0
	shl.4s	v27, v27, #31
	cmlt.4s	v27, v27, #0
	and.16b	v27, v27, v6
	fmov	w10, s31
	ldr	q6, [sp, #80]                   ; 16-byte Reload
	str	q6, [sp, #656]
	ldr	q6, [sp, #32]                   ; 16-byte Reload
	str	q6, [sp, #672]
	ldr	q6, [sp, #48]                   ; 16-byte Reload
	str	q6, [sp, #688]
	ldr	q6, [sp, #16]                   ; 16-byte Reload
	str	q6, [sp, #704]
	and	x11, x12, #0x7
	add	x13, sp, #656
	ldr	x11, [x13, x11, lsl #3]
	sub	x11, x11, x12
	add	x11, x8, x11, lsl #2
	tbz	w10, #0, LBB1_364
; %bb.361:                              ; %cond.store486
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s27, [x11]
	tbnz	w10, #1, LBB1_365
LBB1_362:                               ; %else489
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #2, LBB1_366
LBB1_363:                               ; %cond.store490
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x11, #8
	st1.s	{ v27 }[2], [x13]
	tbnz	w10, #3, LBB1_367
	b	LBB1_368
LBB1_364:                               ; %else487
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #1, LBB1_362
LBB1_365:                               ; %cond.store488
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x11, #4
	st1.s	{ v27 }[1], [x13]
	tbnz	w10, #2, LBB1_363
LBB1_366:                               ; %else491
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #3, LBB1_368
LBB1_367:                               ; %cond.store492
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x11, #12
	st1.s	{ v27 }[3], [x13]
LBB1_368:                               ; %else493
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v6, v19, v0
	fmul.4s	v24, v30, v2
	fsub.4s	v6, v6, v24
	zip2.8b	v24, v18, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	and.16b	v24, v24, v6
	tbz	w10, #4, LBB1_372
; %bb.369:                              ; %cond.store494
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s24, [x11, #16]
	tbnz	w10, #5, LBB1_373
LBB1_370:                               ; %else497
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #6, LBB1_374
LBB1_371:                               ; %cond.store498
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x11, #24
	st1.s	{ v24 }[2], [x13]
	tbnz	w10, #7, LBB1_375
	b	LBB1_376
LBB1_372:                               ; %else495
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #5, LBB1_370
LBB1_373:                               ; %cond.store496
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x13, x11, #20
	st1.s	{ v24 }[1], [x13]
	tbnz	w10, #6, LBB1_371
LBB1_374:                               ; %else499
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w10, #7, LBB1_376
LBB1_375:                               ; %cond.store500
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x11, #28
	st1.s	{ v24 }[3], [x10]
LBB1_376:                               ; %else501
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x10, #0                         ; =0x0
	movi.2d	v24, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	b	LBB1_378
LBB1_377:                               ; %else518
                                        ;   in Loop: Header=BB1_378 Depth=2
	add.2d	v27, v27, v23
	add.2d	v28, v28, v25
	add.2d	v29, v29, v22
	add.2d	v24, v24, v26
	fmov	x10, d24
	cmp	x10, #256
	b.ge	LBB1_394
LBB1_378:                               ; %direct.true184.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w11, s7
	lsl	x10, x10, #5
	add	x13, x3, x10
	ldp	q6, q8, [x13]
	add	x13, x21, x10
	ldp	q11, q9, [x13]
	fmul.4s	v6, v6, v11
	add	x13, x6, x10
	ldp	q13, q11, [x13]
	add	x13, x28, x10
	ldp	q14, q12, [x13]
	fmul.4s	v13, v13, v14
	fadd.4s	v6, v6, v13
	and.16b	v13, v5, v6
	add	x10, x9, x10
	add	x10, x10, x5
	tbz	w11, #0, LBB1_386
; %bb.379:                              ; %cond.store503
                                        ;   in Loop: Header=BB1_378 Depth=2
	str	s13, [x10]
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_387
LBB1_380:                               ; %else506
                                        ;   in Loop: Header=BB1_378 Depth=2
	tbz	w11, #2, LBB1_388
LBB1_381:                               ; %cond.store507
                                        ;   in Loop: Header=BB1_378 Depth=2
	add	x13, x10, #8
	st1.s	{ v13 }[2], [x13]
	tbnz	w11, #3, LBB1_389
LBB1_382:                               ; %else510
                                        ;   in Loop: Header=BB1_378 Depth=2
	fmul.4s	v6, v8, v9
	fmul.4s	v8, v11, v12
	fadd.4s	v6, v6, v8
	and.16b	v8, v4, v6
	tbz	w11, #4, LBB1_390
LBB1_383:                               ; %cond.store511
                                        ;   in Loop: Header=BB1_378 Depth=2
	str	s8, [x10, #16]
	tbnz	w11, #5, LBB1_391
LBB1_384:                               ; %else514
                                        ;   in Loop: Header=BB1_378 Depth=2
	tbz	w11, #6, LBB1_392
LBB1_385:                               ; %cond.store515
                                        ;   in Loop: Header=BB1_378 Depth=2
	add	x13, x10, #24
	st1.s	{ v8 }[2], [x13]
	tbz	w11, #7, LBB1_377
	b	LBB1_393
LBB1_386:                               ; %else504
                                        ;   in Loop: Header=BB1_378 Depth=2
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_380
LBB1_387:                               ; %cond.store505
                                        ;   in Loop: Header=BB1_378 Depth=2
	add	x13, x10, #4
	st1.s	{ v13 }[1], [x13]
	tbnz	w11, #2, LBB1_381
LBB1_388:                               ; %else508
                                        ;   in Loop: Header=BB1_378 Depth=2
	tbz	w11, #3, LBB1_382
LBB1_389:                               ; %cond.store509
                                        ;   in Loop: Header=BB1_378 Depth=2
	add	x13, x10, #12
	st1.s	{ v13 }[3], [x13]
	fmul.4s	v6, v8, v9
	fmul.4s	v8, v11, v12
	fadd.4s	v6, v6, v8
	and.16b	v8, v4, v6
	tbnz	w11, #4, LBB1_383
LBB1_390:                               ; %else512
                                        ;   in Loop: Header=BB1_378 Depth=2
	tbz	w11, #5, LBB1_384
LBB1_391:                               ; %cond.store513
                                        ;   in Loop: Header=BB1_378 Depth=2
	add	x13, x10, #20
	st1.s	{ v8 }[1], [x13]
	tbnz	w11, #6, LBB1_385
LBB1_392:                               ; %else516
                                        ;   in Loop: Header=BB1_378 Depth=2
	tbz	w11, #7, LBB1_377
LBB1_393:                               ; %cond.store517
                                        ;   in Loop: Header=BB1_378 Depth=2
	add	x10, x10, #28
	st1.s	{ v8 }[3], [x10]
	b	LBB1_377
LBB1_394:                               ; %direct.false185.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v3, v20, v3
	fmul.4s	v1, v10, v1
	fadd.4s	v1, v1, v3
	zip1.8b	v3, v18, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v1, v3, v1
	fmov	w9, s31
	stp	q21, q17, [sp, #576]
	ldr	q3, [sp, #64]                   ; 16-byte Reload
	stp	q3, q16, [sp, #608]
	and	x10, x12, #0x7
	add	x11, sp, #576
	ldr	x10, [x11, x10, lsl #3]
	sub	x10, x10, x12
	add	x8, x8, x10, lsl #2
	tbz	w9, #0, LBB1_398
; %bb.395:                              ; %cond.store520
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	s1, [x8]
	ldr	d9, [sp, #8]                    ; 8-byte Reload
	tbnz	w9, #1, LBB1_399
LBB1_396:                               ; %else523
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #2, LBB1_400
LBB1_397:                               ; %cond.store524
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #8
	st1.s	{ v1 }[2], [x10]
	tbnz	w9, #3, LBB1_401
	b	LBB1_402
LBB1_398:                               ; %else521
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	d9, [sp, #8]                    ; 8-byte Reload
	tbz	w9, #1, LBB1_396
LBB1_399:                               ; %cond.store522
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #4
	st1.s	{ v1 }[1], [x10]
	tbnz	w9, #2, LBB1_397
LBB1_400:                               ; %else525
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #3, LBB1_402
LBB1_401:                               ; %cond.store526
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #12
	st1.s	{ v1 }[3], [x10]
LBB1_402:                               ; %else527
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmul.4s	v1, v19, v2
	fmul.4s	v0, v30, v0
	fadd.4s	v0, v0, v1
	zip2.8b	v1, v18, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v0, v1, v0
	tbnz	w9, #4, LBB1_199
LBB1_403:                               ; %else529
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #5, LBB1_200
LBB1_404:                               ; %cond.store262
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbnz	w9, #6, LBB1_201
LBB1_405:                               ; %else533
                                        ;   in Loop: Header=BB1_4 Depth=1
	tbz	w9, #7, LBB1_2
LBB1_406:                               ; %cond.store534
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
	b	LBB1_2
LBB1_407:                               ; %block.batch.exit
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #1168
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdrp	Lloh2, Lloh4
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh24, Lloh25
                                        ; -- End function
.subsections_via_symbols

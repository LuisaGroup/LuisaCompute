import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
SCRIPT = Path('/Users/mike/CLionProjects/luisa/scripts/benchmark/tile_torch/results/m1-max-20260909-simd-root-traversal/archive.py')
SPEC = importlib.util.spec_from_file_location('archive', SCRIPT)
A = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)


def fail(fn, label):
    try:
        fn()
    except (ValueError, OSError, tarfile.TarError):
        print('PASS rejection:', label)
    else:
        raise AssertionError(label)


run = ROOT/'run'
run.mkdir()
(run/'final-source').mkdir()
(run/'final-source'/'source.cpp').write_text('int archive_fixture() { return 1; }\n')
for prefix in A.CASE_PREFIXES:
    for suffix in ('input0.f32', 'input1.f32', 'expected.f64', 'output.f32', 'source.txt', 'log'):
        (run/(prefix+'.'+suffix)).write_bytes((prefix+'/'+suffix+'\n').encode())
# Exercise the real archive's 128 MiB oracle member without a 45 MB raw limit.
with (run/'baseline.expected.f64').open('wb') as stream:
    stream.truncate(128*1024*1024)
out = ROOT/'archive'
A.create(argparse.Namespace(run=run, base_commit='b'*40, output=out))
manifest = json.loads((out/'manifest.json').read_text())
assert len(manifest['bundles']) == 8
assert manifest['logical_file_count'] == 43
assert max(b['size'] for b in manifest['bundles']) < 50_000_000
for bundle in manifest['bundles']:
    with tarfile.open(out/bundle['path'], 'r:gz') as tar:
        for member in bundle['members']:
            with tar.extractfile(member['path']) as stream:
                assert A.hash_stream(stream) == A.hash_file(Path(member['original_path']))
run.rename(ROOT/'run-hidden')
A.verify(out)
print('PASS complete 128 MiB member, exact originals and source-independent verification')
for value in ['', '/', '../x', 'x/../y', '/x', 'a//b', 'a/./b', 'C:/x', 'a\\b', 'a\x00b']:
    fail(lambda: A.safe_name(value), repr(value))
fail(lambda: A.create(argparse.Namespace(run=ROOT/'run-hidden', base_commit='b'*40, output=out)), 'existing output')


def altered(label, fn):
    destination = ROOT/label
    shutil.copytree(out, destination)
    local = json.loads((destination/'manifest.json').read_text())
    fn(destination, local)
    (destination/'manifest.json').write_text(json.dumps(local))
    fail(lambda: A.verify(destination), label)


altered('bad-content', lambda d, m: (d/m['bundles'][0]['path']).write_bytes(b'bad gzip'))
altered('duplicate-members', lambda d, m: m['bundles'][0]['members'].append(m['bundles'][0]['members'][0]))
altered('duplicate-bundles', lambda d, m: m['bundles'].append(m['bundles'][0]))
altered('wrong-member-sha', lambda d, m: m['bundles'][0]['members'][0].update(sha256='0'*64))
altered('wrong-member-size', lambda d, m: m['bundles'][0]['members'][0].update(size=1))
altered('unsafe-member', lambda d, m: m['bundles'][0]['members'][0].update(path='../escape'))


def nonregular(destination, manifest):
    bundle = manifest['bundles'][0]
    with tarfile.open(destination/bundle['path'], 'w:gz') as tar:
        info = tarfile.TarInfo(bundle['members'][0]['path'])
        info.type = tarfile.SYMTYPE
        info.linkname = '/etc/passwd'
        tar.addfile(info)
    size, digest = A.hash_file(destination/bundle['path'])
    bundle.update(size=size, sha256=digest)


altered('symlink-tar', nonregular)
duplicate = ROOT/'duplicate-json'
shutil.copytree(out, duplicate)
(duplicate/'manifest.json').write_text('{"schema": "a", "schema": "b"}')
fail(lambda: A.verify(duplicate), 'duplicate JSON key')
source_symlink = ROOT/'source-symlink'
source_symlink.mkdir()
(source_symlink/'external.cpp').symlink_to(ROOT/'run-hidden'/'final-source'/'source.cpp')
fail(lambda: A.inventory_tree(source_symlink, 'run'), 'source symlink')
poison = ROOT/'run-hidden'/'.poison'
poison.write_text('must not be opened by inventory\n')
fail(lambda: A.inventory_run(ROOT/'run-hidden'), 'unreviewed hidden root file')
print('ALL GEMM ARCHIVE FIXTURES PASSED')

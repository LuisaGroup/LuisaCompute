// node qa-docs.cjs <built-html-root> <new-output-directory> <playwright-module>
const {chromium} = require(process.argv[4]);
const fs = require('node:fs');
const path = require('node:path');
const {pathToFileURL} = require('node:url');
(async () => {
    const output = process.argv[3];
    fs.mkdirSync(output);
    const browser = await chromium.launch({headless: true,
        executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
    try {
        const page = await browser.newPage({reducedMotion: 'reduce'});
        const visits = [], errors = [];
        page.on('pageerror', error => errors.push(error.message));
        for (const width of [1280, 390]) {
            await page.setViewportSize({width, height: 900});
            await page.goto(pathToFileURL(path.join(process.argv[2],
                'source/performance/tile/migration.html')).href + '#simd-gemm-diagnosis-and-root-traversal-checkpoint');
            await page.evaluate(() => document.fonts.ready);
            const section = page.locator('#simd-gemm-diagnosis-and-root-traversal-checkpoint');
            const receipt = await section.evaluate(s => ({pageWidth: document.documentElement.scrollWidth,
                text: s.innerText, rows: s.querySelector('table').rows.length,
                columns: s.querySelector('table').rows[0].cells.length}));
            if (receipt.pageWidth > width + 1 || receipt.rows !== 7 || receipt.columns !== 3 ||
                !receipt.text.includes('not yet fixed') || !receipt.text.includes('September 9 handoff')) {
                throw Error('Missing or overflowed GEMM handoff content');
            }
            await page.screenshot({path: path.join(output, `gemm-${width}.png`)});
            const table = section.locator('table');
            await table.scrollIntoViewIfNeeded();
            const reachable = await table.evaluate(t => {
                const wrapper = t.parentElement;
                wrapper.scrollLeft = wrapper.scrollWidth;
                return t.rows[0].cells[2].getBoundingClientRect().right <= wrapper.getBoundingClientRect().right + 1;
            });
            if (!reachable) throw Error('GEMM timing column not reachable');
            await page.screenshot({path: path.join(output, `gemm-${width}-table.png`)});
            visits.push({width, ...receipt});
        }
        if (errors.length) throw Error(errors.join('\n'));
        fs.writeFileSync(path.join(output, 'receipt.json'), JSON.stringify({passed: true,
            browser: await browser.version(), visits}, null, 2) + '\n');
        console.log('PASS: GEMM diagnostic and handoff render at desktop/mobile widths');
    } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });


/tmp/luisa-xir-bounded.kADecq/code-final/object/tile_xir_w8_50305_1788841795398146_0.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0: 6db63bef     	stp	d15, d14, [sp, #-0xa0]!
       4: 6d0133ed     	stp	d13, d12, [sp, #0x10]
       8: 6d022beb     	stp	d11, d10, [sp, #0x20]
       c: 6d0323e9     	stp	d9, d8, [sp, #0x30]
      10: a9046ffc     	stp	x28, x27, [sp, #0x40]
      14: a90567fa     	stp	x26, x25, [sp, #0x50]
      18: a9065ff8     	stp	x24, x23, [sp, #0x60]
      1c: a90757f6     	stp	x22, x21, [sp, #0x70]
      20: a9084ff4     	stp	x20, x19, [sp, #0x80]
      24: a9097bfd     	stp	x29, x30, [sp, #0x90]
      28: d14013ff     	sub	sp, sp, #0x4, lsl #12   ; =0x4000
      2c: d10803ff     	sub	sp, sp, #0x200
      30: f9004be0     	str	x0, [sp, #0x90]
      34: 34016623     	cbz	w3, 0x2cf8 <ltmp0+0x2cf8>
      38: aa0303f4     	mov	x20, x3
      3c: 52800008     	mov	w8, #0x0                ; =0
      40: 90000009     	adrp	x9, 0x0 <ltmp0>
      44: 3dc00120     	ldr	q0, [x9]
      48: 91400be9     	add	x9, sp, #0x2, lsl #12   ; =0x2000
      4c: 91080129     	add	x9, x9, #0x200
      50: 4e080d21     	dup.2d	v1, x9
      54: 4ee0842e     	add.2d	v14, v1, v0
      58: 90000009     	adrp	x9, 0x0 <ltmp0>
      5c: 3dc00123     	ldr	q3, [x9]
      60: 4ee3842f     	add.2d	v15, v1, v3
      64: 90000009     	adrp	x9, 0x0 <ltmp0>
      68: 3dc00125     	ldr	q5, [x9]
      6c: 4ee5842b     	add.2d	v11, v1, v5
      70: 90000009     	adrp	x9, 0x0 <ltmp0>
      74: 3dc00127     	ldr	q7, [x9]
      78: 4ee7842a     	add.2d	v10, v1, v7
      7c: 90000009     	adrp	x9, 0x0 <ltmp0>
      80: 3dc00122     	ldr	q2, [x9]
      84: 4ee2842c     	add.2d	v12, v1, v2
      88: 90000009     	adrp	x9, 0x0 <ltmp0>
      8c: 3dc00122     	ldr	q2, [x9]
      90: 4ee2842d     	add.2d	v13, v1, v2
      94: 90000009     	adrp	x9, 0x0 <ltmp0>
      98: 3dc00122     	ldr	q2, [x9]
      9c: 4ee28422     	add.2d	v2, v1, v2
      a0: 3d806be2     	str	q2, [sp, #0x1a0]
      a4: 90000009     	adrp	x9, 0x0 <ltmp0>
      a8: 3dc00122     	ldr	q2, [x9]
      ac: 4ee28422     	add.2d	v2, v1, v2
      b0: 3d8067e2     	str	q2, [sp, #0x190]
      b4: 90000009     	adrp	x9, 0x0 <ltmp0>
      b8: 3dc00122     	ldr	q2, [x9]
      bc: 4ee28422     	add.2d	v2, v1, v2
      c0: 3d8063e2     	str	q2, [sp, #0x180]
      c4: 90000009     	adrp	x9, 0x0 <ltmp0>
      c8: 3dc00122     	ldr	q2, [x9]
      cc: 4ee28422     	add.2d	v2, v1, v2
      d0: 3d805fe2     	str	q2, [sp, #0x170]
      d4: 90000009     	adrp	x9, 0x0 <ltmp0>
      d8: 3dc00122     	ldr	q2, [x9]
      dc: 4ee28422     	add.2d	v2, v1, v2
      e0: 3d805be2     	str	q2, [sp, #0x160]
      e4: 90000009     	adrp	x9, 0x0 <ltmp0>
      e8: 3dc00122     	ldr	q2, [x9]
      ec: 4ee28422     	add.2d	v2, v1, v2
      f0: 3d8057e2     	str	q2, [sp, #0x150]
      f4: 90000009     	adrp	x9, 0x0 <ltmp0>
      f8: 3dc00122     	ldr	q2, [x9]
      fc: 4ee28422     	add.2d	v2, v1, v2
     100: 3d8053e2     	str	q2, [sp, #0x140]
     104: 90000009     	adrp	x9, 0x0 <ltmp0>
     108: 3dc00122     	ldr	q2, [x9]
     10c: 4ee28422     	add.2d	v2, v1, v2
     110: 3d804fe2     	str	q2, [sp, #0x130]
     114: 90000009     	adrp	x9, 0x0 <ltmp0>
     118: 3dc00122     	ldr	q2, [x9]
     11c: 4ee28422     	add.2d	v2, v1, v2
     120: 3d804be2     	str	q2, [sp, #0x120]
     124: 90000009     	adrp	x9, 0x0 <ltmp0>
     128: 3dc00122     	ldr	q2, [x9]
     12c: 4ee28422     	add.2d	v2, v1, v2
     130: 3d8047e2     	str	q2, [sp, #0x110]
     134: 910803ec     	add	x12, sp, #0x200
     138: 2945dc55     	ldp	w21, w23, [x2, #0x2c]
     13c: 90000019     	adrp	x25, 0x0 <ltmp0>
     140: 9000001a     	adrp	x26, 0x0 <ltmp0>
     144: 52a7701b     	mov	w27, #0x3b800000        ; =998244352
     148: 29402849     	ldp	w9, w10, [x2]
     14c: 5298b59c     	mov	w28, #0xc5ac            ; =50604
     150: 72a6e4fc     	movk	w28, #0x3727, lsl #16
     154: 2941784b     	ldp	w11, w30, [x2, #0x8]
     158: f90007e2     	str	x2, [sp, #0x8]
     15c: 4e080d9f     	dup.2d	v31, x12
     160: ad062fea     	stp	q10, q11, [sp, #0xc0]
     164: ad0533ed     	stp	q13, q12, [sp, #0xa0]
     168: 29110ff5     	stp	w21, w3, [sp, #0x88]
     16c: ad00bbef     	stp	q15, q14, [sp, #0x10]
     170: b90087f7     	str	w23, [sp, #0x84]
     174: f9003ffe     	str	x30, [sp, #0x78]
     178: 14000013     	b	0x1c4 <ltmp0+0x1c4>
     17c: ad40bbef     	ldp	q15, q14, [sp, #0x10]
     180: ad462fea     	ldp	q10, q11, [sp, #0xc0]
     184: ad4533ed     	ldp	q13, q12, [sp, #0xa0]
     188: aa0f03f6     	mov	x22, x15
     18c: 11000709     	add	w9, w24, #0x1
     190: 6b15013f     	cmp	w9, w21
     194: 1a9f17ea     	cset	w10, eq
     198: 1a9807e9     	csinc	w9, wzr, w24, eq
     19c: b9409fed     	ldr	w13, [sp, #0x9c]
     1a0: 1a8d15ab     	cinc	w11, w13, eq
     1a4: 6b17017f     	cmp	w11, w23
     1a8: 1a9f17ec     	cset	w12, eq
     1ac: 6a0c014c     	ands	w12, w10, w12
     1b0: 1a8b13ea     	csel	w10, wzr, w11, ne
     1b4: 0b0c02cb     	add	w11, w22, w12
     1b8: 11000508     	add	w8, w8, #0x1
     1bc: 6b14011f     	cmp	w8, w20
     1c0: 54015920     	b.eq	0x2ce4 <ltmp0+0x2ce4>
     1c4: aa0b03f6     	mov	x22, x11
     1c8: aa0a03ec     	mov	x12, x10
     1cc: aa0903f8     	mov	x24, x9
     1d0: d37b7d29     	ubfiz	x9, x9, #5, #32
     1d4: eb1e013f     	cmp	x9, x30
     1d8: 9a9f912a     	csel	x10, x9, xzr, ls
     1dc: eb0a03cb     	subs	x11, x30, x10
     1e0: f100817f     	cmp	x11, #0x20
     1e4: 5280040d     	mov	w13, #0x20              ; =32
     1e8: 9a8d316b     	csel	x11, x11, x13, lo
     1ec: eb0a03df     	cmp	x30, x10
     1f0: fa5e8122     	ccmp	x9, x30, #0x2, hi
     1f4: 9a9f9169     	csel	x9, x11, xzr, ls
     1f8: 4e040f64     	dup.4s	v4, w27
     1fc: 4e040f82     	dup.4s	v2, w28
     200: ad0d8be4     	stp	q4, q2, [sp, #0x1b0]
     204: f100813f     	cmp	x9, #0x20
     208: b9009fec     	str	w12, [sp, #0x9c]
     20c: 5400b9a3     	b.lo	0x1940 <ltmp0+0x1940>
     210: b900f3f6     	str	w22, [sp, #0xf0]
     214: d2800009     	mov	x9, #0x0                ; =0
     218: f9404bea     	ldr	x10, [sp, #0x90]
     21c: f940014b     	ldr	x11, [x10]
     220: f9400956     	ldr	x22, [x10, #0x10]
     224: f90073f8     	str	x24, [sp, #0xe0]
     228: 531b6b1c     	lsl	w28, w24, #5
     22c: 4e040f82     	dup.4s	v2, w28
     230: f940194a     	ldr	x10, [x10, #0x30]
     234: 4f2a5442     	shl.4s	v2, v2, #0xa
     238: 3dc0032c     	ldr	q12, [x25]
     23c: 4eac1c44     	orr.16b	v4, v2, v12
     240: 3dc0034d     	ldr	q13, [x26]
     244: 4ead1c42     	orr.16b	v2, v2, v13
     248: 4f042786     	movi.4s	v6, #0x9c, lsl #8
     24c: 4e261c50     	and.16b	v16, v2, v6
     250: 4e261c86     	and.16b	v6, v4, v6
     254: 6f20a4c2     	ushll2.2d	v2, v6, #0x0
     258: 6f20a604     	ushll2.2d	v4, v16, #0x0
     25c: 2f20a4c6     	ushll.2d	v6, v6, #0x0
     260: 2f20a610     	ushll.2d	v16, v16, #0x0
     264: 4e080d31     	dup.2d	v17, x9
     268: 4ef08632     	add.2d	v18, v17, v16
     26c: 4ee48633     	add.2d	v19, v17, v4
     270: 4ee68634     	add.2d	v20, v17, v6
     274: 4e080d6a     	dup.2d	v10, x11
     278: 4ee28635     	add.2d	v21, v17, v2
     27c: 4ef58555     	add.2d	v21, v10, v21
     280: 4ef38553     	add.2d	v19, v10, v19
     284: 4ef28552     	add.2d	v18, v10, v18
     288: 4e183e4c     	mov.d	x12, v18[1]
     28c: 9e66024d     	fmov	x13, d18
     290: bd4001b2     	ldr	s18, [x13]
     294: 4e183e6d     	mov.d	x13, v19[1]
     298: bd400196     	ldr	s22, [x12]
     29c: 4ef48554     	add.2d	v20, v10, v20
     2a0: 9e66026c     	fmov	x12, d19
     2a4: bd400193     	ldr	s19, [x12]
     2a8: 4e183e8c     	mov.d	x12, v20[1]
     2ac: bd4001b7     	ldr	s23, [x13]
     2b0: 9e66028d     	fmov	x13, d20
     2b4: bd4001b4     	ldr	s20, [x13]
     2b8: bd400198     	ldr	s24, [x12]
     2bc: 4e183eac     	mov.d	x12, v21[1]
     2c0: 9e6602ad     	fmov	x13, d21
     2c4: bd4001b5     	ldr	s21, [x13]
     2c8: bd400199     	ldr	s25, [x12]
     2cc: 4ef18431     	add.2d	v17, v1, v17
     2d0: 4ee0863a     	add.2d	v26, v17, v0
     2d4: 4ee3863b     	add.2d	v27, v17, v3
     2d8: 4ee5863c     	add.2d	v28, v17, v5
     2dc: 4ee78631     	add.2d	v17, v17, v7
     2e0: 4e183e2c     	mov.d	x12, v17[1]
     2e4: 9e66022d     	fmov	x13, d17
     2e8: bd0001b2     	str	s18, [x13]
     2ec: bd000196     	str	s22, [x12]
     2f0: 4e183f8c     	mov.d	x12, v28[1]
     2f4: 9e66038d     	fmov	x13, d28
     2f8: bd0001b3     	str	s19, [x13]
     2fc: bd000197     	str	s23, [x12]
     300: 4e183f6c     	mov.d	x12, v27[1]
     304: 9e66036d     	fmov	x13, d27
     308: bd0001b4     	str	s20, [x13]
     30c: 4e183f4d     	mov.d	x13, v26[1]
     310: bd000198     	str	s24, [x12]
     314: 9e66034c     	fmov	x12, d26
     318: bd000195     	str	s21, [x12]
     31c: bd0001b9     	str	s25, [x13]
     320: 91001129     	add	x9, x9, #0x4
     324: f110013f     	cmp	x9, #0x400
     328: 54fff9e1     	b.ne	0x264 <ltmp0+0x264>
     32c: d2800013     	mov	x19, #0x0               ; =0
     330: 3dc033f1     	ldr	q17, [sp, #0xc0]
     334: 4e183e2e     	mov.d	x14, v17[1]
     338: 4e183d6d     	mov.d	x13, v11[1]
     33c: 4e183de6     	mov.d	x6, v15[1]
     340: 9e660229     	fmov	x9, d17
     344: 9e6601eb     	fmov	x11, d15
     348: 4e183dde     	mov.d	x30, v14[1]
     34c: 9e6601cc     	fmov	x12, d14
     350: bd400172     	ldr	s18, [x11]
     354: 0d4090d2     	ld1.s	{ v18 }[1], [x6]
     358: 4d408192     	ld1.s	{ v18 }[2], [x12]
     35c: 4d4093d2     	ld1.s	{ v18 }[3], [x30]
     360: 9e66016b     	fmov	x11, d11
     364: bd400131     	ldr	s17, [x9]
     368: f900ebee     	str	x14, [sp, #0x1d0]
     36c: 0d4091d1     	ld1.s	{ v17 }[1], [x14]
     370: 4d408171     	ld1.s	{ v17 }[2], [x11]
     374: f900f3ed     	str	x13, [sp, #0x1e0]
     378: 4d4091b1     	ld1.s	{ v17 }[3], [x13]
     37c: 6e31de31     	fmul.4s	v17, v17, v17
     380: 3dc067f3     	ldr	q19, [sp, #0x190]
     384: 4e183e7a     	mov.d	x26, v19[1]
     388: 9e660269     	fmov	x9, d19
     38c: 3dc06bf3     	ldr	q19, [sp, #0x1a0]
     390: 9e66026b     	fmov	x11, d19
     394: 4e183e6d     	mov.d	x13, v19[1]
     398: 3dc02bf3     	ldr	q19, [sp, #0xa0]
     39c: 4e183e62     	mov.d	x2, v19[1]
     3a0: 9e66026c     	fmov	x12, d19
     3a4: 3dc02ff3     	ldr	q19, [sp, #0xb0]
     3a8: 4e183e70     	mov.d	x16, v19[1]
     3ac: bd400194     	ldr	s20, [x12]
     3b0: 0d409054     	ld1.s	{ v20 }[1], [x2]
     3b4: 9e66026c     	fmov	x12, d19
     3b8: 4d408194     	ld1.s	{ v20 }[2], [x12]
     3bc: 4d409214     	ld1.s	{ v20 }[3], [x16]
     3c0: bd400135     	ldr	s21, [x9]
     3c4: 0d409355     	ld1.s	{ v21 }[1], [x26]
     3c8: 4d408175     	ld1.s	{ v21 }[2], [x11]
     3cc: f90083ed     	str	x13, [sp, #0x100]
     3d0: 4d4091b5     	ld1.s	{ v21 }[3], [x13]
     3d4: 6e32de53     	fmul.4s	v19, v18, v18
     3d8: 6e35deb2     	fmul.4s	v18, v21, v21
     3dc: ad4adff8     	ldp	q24, q23, [sp, #0x150]
     3e0: 4e183f05     	mov.d	x5, v24[1]
     3e4: 4e183efb     	mov.d	x27, v23[1]
     3e8: 6e34de94     	fmul.4s	v20, v20, v20
     3ec: 3dc05ff5     	ldr	q21, [sp, #0x170]
     3f0: 9e6602a9     	fmov	x9, d21
     3f4: 4e183eaf     	mov.d	x15, v21[1]
     3f8: 3dc063f5     	ldr	q21, [sp, #0x180]
     3fc: 4e183eae     	mov.d	x14, v21[1]
     400: 9e6602ab     	fmov	x11, d21
     404: bd400136     	ldr	s22, [x9]
     408: 0d4091f6     	ld1.s	{ v22 }[1], [x15]
     40c: 4d408176     	ld1.s	{ v22 }[2], [x11]
     410: 9e660309     	fmov	x9, d24
     414: 4d4091d6     	ld1.s	{ v22 }[3], [x14]
     418: bd400135     	ldr	s21, [x9]
     41c: 0d4090b5     	ld1.s	{ v21 }[1], [x5]
     420: 9e6602e9     	fmov	x9, d23
     424: 4d408135     	ld1.s	{ v21 }[2], [x9]
     428: 4d409375     	ld1.s	{ v21 }[3], [x27]
     42c: 6e35deb5     	fmul.4s	v21, v21, v21
     430: 6e36ded6     	fmul.4s	v22, v22, v22
     434: 3dc047f7     	ldr	q23, [sp, #0x110]
     438: 9e6602ec     	fmov	x12, d23
     43c: 4e183eeb     	mov.d	x11, v23[1]
     440: 3dc04bf7     	ldr	q23, [sp, #0x120]
     444: 4e183ee7     	mov.d	x7, v23[1]
     448: 9e6602ed     	fmov	x13, d23
     44c: ad49e7f7     	ldp	q23, q25, [sp, #0x130]
     450: 9e6602e0     	fmov	x0, d23
     454: 4e183ee9     	mov.d	x9, v23[1]
     458: 4e183f31     	mov.d	x17, v25[1]
     45c: bd400018     	ldr	s24, [x0]
     460: 0d409138     	ld1.s	{ v24 }[1], [x9]
     464: bd400197     	ldr	s23, [x12]
     468: 0d409177     	ld1.s	{ v23 }[1], [x11]
     46c: 9e66032c     	fmov	x12, d25
     470: 4d4081b7     	ld1.s	{ v23 }[2], [x13]
     474: 4d4090f7     	ld1.s	{ v23 }[3], [x7]
     478: 6e37def7     	fmul.4s	v23, v23, v23
     47c: 4d408198     	ld1.s	{ v24 }[2], [x12]
     480: 4d409238     	ld1.s	{ v24 }[3], [x17]
     484: 6e38df18     	fmul.4s	v24, v24, v24
     488: 52800383     	mov	w3, #0x1c               ; =28
     48c: d100306c     	sub	x12, x3, #0xc
     490: 4e080d99     	dup.2d	v25, x12
     494: 4ef98439     	add.2d	v25, v1, v25
     498: 4ee0873a     	add.2d	v26, v25, v0
     49c: 4ee3873b     	add.2d	v27, v25, v3
     4a0: 4ee5873c     	add.2d	v28, v25, v5
     4a4: 4ee78739     	add.2d	v25, v25, v7
     4a8: 4e183f2c     	mov.d	x12, v25[1]
     4ac: 9e660320     	fmov	x0, d25
     4b0: 4e183f94     	mov.d	x20, v28[1]
     4b4: 9e660381     	fmov	x1, d28
     4b8: 4e183f75     	mov.d	x21, v27[1]
     4bc: 9e660377     	fmov	x23, d27
     4c0: 4e183f44     	mov.d	x4, v26[1]
     4c4: 9e66034d     	fmov	x13, d26
     4c8: d1002078     	sub	x24, x3, #0x8
     4cc: bd4002f9     	ldr	s25, [x23]
     4d0: 4e080f1a     	dup.2d	v26, x24
     4d4: 4efa843b     	add.2d	v27, v1, v26
     4d8: 4ee0877d     	add.2d	v29, v27, v0
     4dc: 4ee3877c     	add.2d	v28, v27, v3
     4e0: bd40001a     	ldr	s26, [x0]
     4e4: 4ee5877e     	add.2d	v30, v27, v5
     4e8: 4ee7877b     	add.2d	v27, v27, v7
     4ec: 4e183f77     	mov.d	x23, v27[1]
     4f0: 0d4092b9     	ld1.s	{ v25 }[1], [x21]
     4f4: 4e183fc0     	mov.d	x0, v30[1]
     4f8: 4e183f95     	mov.d	x21, v28[1]
     4fc: 0d40919a     	ld1.s	{ v26 }[1], [x12]
     500: 9e660378     	fmov	x24, d27
     504: 9e66038c     	fmov	x12, d28
     508: bd40019b     	ldr	s27, [x12]
     50c: 9e6603d9     	fmov	x25, d30
     510: 0d4092bb     	ld1.s	{ v27 }[1], [x21]
     514: 4e183fac     	mov.d	x12, v29[1]
     518: bd40031c     	ldr	s28, [x24]
     51c: d1001075     	sub	x21, x3, #0x4
     520: 0d4092fc     	ld1.s	{ v28 }[1], [x23]
     524: 4e080ebe     	dup.2d	v30, x21
     528: 9e6603b5     	fmov	x21, d29
     52c: 4efe843d     	add.2d	v29, v1, v30
     530: 4d4081b9     	ld1.s	{ v25 }[2], [x13]
     534: 4ee087be     	add.2d	v30, v29, v0
     538: 4ee387a8     	add.2d	v8, v29, v3
     53c: 4ee587a9     	add.2d	v9, v29, v5
     540: 4ee787bd     	add.2d	v29, v29, v7
     544: 4d40803a     	ld1.s	{ v26 }[2], [x1]
     548: 4e183fad     	mov.d	x13, v29[1]
     54c: 4e183d01     	mov.d	x1, v8[1]
     550: 4d4082bb     	ld1.s	{ v27 }[2], [x21]
     554: 9e660115     	fmov	x21, d8
     558: bd4002a8     	ldr	s8, [x21]
     55c: 4e183fd5     	mov.d	x21, v30[1]
     560: 4d40833c     	ld1.s	{ v28 }[2], [x25]
     564: 9e6603b7     	fmov	x23, d29
     568: 0d409028     	ld1.s	{ v8 }[1], [x1]
     56c: 9e6603c1     	fmov	x1, d30
     570: 4d408028     	ld1.s	{ v8 }[2], [x1]
     574: 4e183d21     	mov.d	x1, v9[1]
     578: bd4002fd     	ldr	s29, [x23]
     57c: 9e660137     	fmov	x23, d9
     580: 4d409099     	ld1.s	{ v25 }[3], [x4]
     584: 0d4091bd     	ld1.s	{ v29 }[1], [x13]
     588: 4e080c7e     	dup.2d	v30, x3
     58c: 4d40929a     	ld1.s	{ v26 }[3], [x20]
     590: 4efe843e     	add.2d	v30, v1, v30
     594: 4ee787c9     	add.2d	v9, v30, v7
     598: 4e183d2d     	mov.d	x13, v9[1]
     59c: 4d40919b     	ld1.s	{ v27 }[3], [x12]
     5a0: 9e66012c     	fmov	x12, d9
     5a4: 4ee587c9     	add.2d	v9, v30, v5
     5a8: 4e183d24     	mov.d	x4, v9[1]
     5ac: 4d40901c     	ld1.s	{ v28 }[3], [x0]
     5b0: 9e660120     	fmov	x0, d9
     5b4: 4ee387c9     	add.2d	v9, v30, v3
     5b8: 4e183d34     	mov.d	x20, v9[1]
     5bc: 4d4092a8     	ld1.s	{ v8 }[3], [x21]
     5c0: 9e660135     	fmov	x21, d9
     5c4: 6e3adf5a     	fmul.4s	v26, v26, v26
     5c8: 6e39df39     	fmul.4s	v25, v25, v25
     5cc: 4d4082fd     	ld1.s	{ v29 }[2], [x23]
     5d0: 4e39d673     	fadd.4s	v19, v19, v25
     5d4: 4d40903d     	ld1.s	{ v29 }[3], [x1]
     5d8: 4ee087d9     	add.2d	v25, v30, v0
     5dc: 4e183f21     	mov.d	x1, v25[1]
     5e0: 4e3ad631     	fadd.4s	v17, v17, v26
     5e4: 9e660337     	fmov	x23, d25
     5e8: 6e3cdf99     	fmul.4s	v25, v28, v28
     5ec: 6e3bdf7a     	fmul.4s	v26, v27, v27
     5f0: 6e3ddfbb     	fmul.4s	v27, v29, v29
     5f4: 6e28dd1c     	fmul.4s	v28, v8, v8
     5f8: 4e3ad694     	fadd.4s	v20, v20, v26
     5fc: bd4002ba     	ldr	s26, [x21]
     600: 0d40929a     	ld1.s	{ v26 }[1], [x20]
     604: 4d4082fa     	ld1.s	{ v26 }[2], [x23]
     608: 4e39d652     	fadd.4s	v18, v18, v25
     60c: 4d40903a     	ld1.s	{ v26 }[3], [x1]
     610: bd400199     	ldr	s25, [x12]
     614: 0d4091b9     	ld1.s	{ v25 }[1], [x13]
     618: 4e3cd6d6     	fadd.4s	v22, v22, v28
     61c: 4d408019     	ld1.s	{ v25 }[2], [x0]
     620: 4d409099     	ld1.s	{ v25 }[3], [x4]
     624: 6e39df39     	fmul.4s	v25, v25, v25
     628: 4e3bd6b5     	fadd.4s	v21, v21, v27
     62c: 6e3adf5a     	fmul.4s	v26, v26, v26
     630: 4e3ad718     	fadd.4s	v24, v24, v26
     634: 4e39d6f7     	fadd.4s	v23, v23, v25
     638: 91001273     	add	x19, x19, #0x4
     63c: 91004063     	add	x3, x3, #0x10
     640: f103f27f     	cmp	x19, #0xfc
     644: 54fff243     	b.lo	0x48c <ltmp0+0x48c>
     648: d280000c     	mov	x12, #0x0               ; =0
     64c: bc6c6ad9     	ldr	s25, [x22, x12]
     650: 4e080d9a     	dup.2d	v26, x12
     654: 4efa87fa     	add.2d	v26, v31, v26
     658: 4ee0875b     	add.2d	v27, v26, v0
     65c: 4ee3875c     	add.2d	v28, v26, v3
     660: 4ee5875d     	add.2d	v29, v26, v5
     664: 4ee7875a     	add.2d	v26, v26, v7
     668: 4e183f4d     	mov.d	x13, v26[1]
     66c: 9e660340     	fmov	x0, d26
     670: bd000019     	str	s25, [x0]
     674: bd0001b9     	str	s25, [x13]
     678: 4e183fad     	mov.d	x13, v29[1]
     67c: 9e6603a0     	fmov	x0, d29
     680: bd000019     	str	s25, [x0]
     684: bd0001b9     	str	s25, [x13]
     688: 4e183f8d     	mov.d	x13, v28[1]
     68c: 9e660380     	fmov	x0, d28
     690: bd000019     	str	s25, [x0]
     694: 4e183f60     	mov.d	x0, v27[1]
     698: bd0001b9     	str	s25, [x13]
     69c: 9e66036d     	fmov	x13, d27
     6a0: bd0001b9     	str	s25, [x13]
     6a4: bd000019     	str	s25, [x0]
     6a8: 9100118c     	add	x12, x12, #0x4
     6ac: f110019f     	cmp	x12, #0x400
     6b0: 54fffce1     	b.ne	0x64c <ltmp0+0x64c>
     6b4: d2800003     	mov	x3, #0x0                ; =0
     6b8: 4e34d673     	fadd.4s	v19, v19, v20
     6bc: 4e32d631     	fadd.4s	v17, v17, v18
     6c0: 4e35d631     	fadd.4s	v17, v17, v21
     6c4: 4e36d672     	fadd.4s	v18, v19, v22
     6c8: 4e38d652     	fadd.4s	v18, v18, v24
     6cc: 4e37d631     	fadd.4s	v17, v17, v23
     6d0: ad4dcff4     	ldp	q20, q19, [sp, #0x1b0]
     6d4: 6e34de31     	fmul.4s	v17, v17, v20
     6d8: 6e34de52     	fmul.4s	v18, v18, v20
     6dc: 4e33d652     	fadd.4s	v18, v18, v19
     6e0: 4e33d631     	fadd.4s	v17, v17, v19
     6e4: 6ea1fa31     	fsqrt.4s	v17, v17
     6e8: 6ea1fa52     	fsqrt.4s	v18, v18
     6ec: 4e080c73     	dup.2d	v19, x3
     6f0: 4ea71e74     	orr.16b	v20, v19, v7
     6f4: 4ea51e75     	orr.16b	v21, v19, v5
     6f8: 4ea31e76     	orr.16b	v22, v19, v3
     6fc: 4ea01e77     	orr.16b	v23, v19, v0
     700: 4ef78438     	add.2d	v24, v1, v23
     704: 4ef68439     	add.2d	v25, v1, v22
     708: 4ef5843a     	add.2d	v26, v1, v21
     70c: 4ef4843b     	add.2d	v27, v1, v20
     710: 4e183f6c     	mov.d	x12, v27[1]
     714: 9e66036d     	fmov	x13, d27
     718: 4e183f40     	mov.d	x0, v26[1]
     71c: 9e660341     	fmov	x1, d26
     720: 4e183f24     	mov.d	x4, v25[1]
     724: 9e660333     	fmov	x19, d25
     728: 4e183f14     	mov.d	x20, v24[1]
     72c: bd400279     	ldr	s25, [x19]
     730: 0d409099     	ld1.s	{ v25 }[1], [x4]
     734: 9e660304     	fmov	x4, d24
     738: 4d408099     	ld1.s	{ v25 }[2], [x4]
     73c: 4d409299     	ld1.s	{ v25 }[3], [x20]
     740: bd4001b8     	ldr	s24, [x13]
     744: 0d409198     	ld1.s	{ v24 }[1], [x12]
     748: 4d408038     	ld1.s	{ v24 }[2], [x1]
     74c: 4d409018     	ld1.s	{ v24 }[3], [x0]
     750: 6e31ff18     	fdiv.4s	v24, v24, v17
     754: 6e32ff39     	fdiv.4s	v25, v25, v18
     758: 4ef787f7     	add.2d	v23, v31, v23
     75c: 4ef687f6     	add.2d	v22, v31, v22
     760: 4ef587f5     	add.2d	v21, v31, v21
     764: 4ef487f4     	add.2d	v20, v31, v20
     768: 4e183e8c     	mov.d	x12, v20[1]
     76c: 9e66028d     	fmov	x13, d20
     770: 4e183ea0     	mov.d	x0, v21[1]
     774: 9e6602a1     	fmov	x1, d21
     778: 4e183ec4     	mov.d	x4, v22[1]
     77c: 9e6602d3     	fmov	x19, d22
     780: 4e183ef4     	mov.d	x20, v23[1]
     784: bd4001b4     	ldr	s20, [x13]
     788: 0d409194     	ld1.s	{ v20 }[1], [x12]
     78c: 4d408034     	ld1.s	{ v20 }[2], [x1]
     790: 4d409014     	ld1.s	{ v20 }[3], [x0]
     794: 9e6602ec     	fmov	x12, d23
     798: bd400275     	ldr	s21, [x19]
     79c: 0d409095     	ld1.s	{ v21 }[1], [x4]
     7a0: 4d408195     	ld1.s	{ v21 }[2], [x12]
     7a4: 4d409295     	ld1.s	{ v21 }[3], [x20]
     7a8: 6e35df35     	fmul.4s	v21, v25, v21
     7ac: 6e34df14     	fmul.4s	v20, v24, v20
     7b0: 4ef08676     	add.2d	v22, v19, v16
     7b4: 4ee48677     	add.2d	v23, v19, v4
     7b8: 4ee68678     	add.2d	v24, v19, v6
     7bc: 4ee28673     	add.2d	v19, v19, v2
     7c0: 4e080d4b     	dup.2d	v11, x10
     7c4: 4ef38573     	add.2d	v19, v11, v19
     7c8: 4ef68576     	add.2d	v22, v11, v22
     7cc: 4e183ecc     	mov.d	x12, v22[1]
     7d0: 9e6602cd     	fmov	x13, d22
     7d4: bd0001b4     	str	s20, [x13]
     7d8: 0d009194     	st1.s	{ v20 }[1], [x12]
     7dc: 4ef78576     	add.2d	v22, v11, v23
     7e0: 4e183ecc     	mov.d	x12, v22[1]
     7e4: 9e6602cd     	fmov	x13, d22
     7e8: 4d0081b4     	st1.s	{ v20 }[2], [x13]
     7ec: 4ef88576     	add.2d	v22, v11, v24
     7f0: 4d009194     	st1.s	{ v20 }[3], [x12]
     7f4: 4e183ecc     	mov.d	x12, v22[1]
     7f8: 9e6602cd     	fmov	x13, d22
     7fc: bd0001b5     	str	s21, [x13]
     800: 0d009195     	st1.s	{ v21 }[1], [x12]
     804: 4e183e6c     	mov.d	x12, v19[1]
     808: 9e66026d     	fmov	x13, d19
     80c: 4d0081b5     	st1.s	{ v21 }[2], [x13]
     810: 4d009195     	st1.s	{ v21 }[3], [x12]
     814: 91001063     	add	x3, x3, #0x4
     818: f110007f     	cmp	x3, #0x400
     81c: 54fff681     	b.ne	0x6ec <ltmp0+0x6ec>
     820: d280000a     	mov	x10, #0x0               ; =0
     824: 321d038c     	orr	w12, w28, #0x8
     828: 4e040d82     	dup.4s	v2, w12
     82c: 4f2a5442     	shl.4s	v2, v2, #0xa
     830: 4eac1c44     	orr.16b	v4, v2, v12
     834: 4ead1c42     	orr.16b	v2, v2, v13
     838: 4f072786     	movi.4s	v6, #0xfc, lsl #8
     83c: 4e261c50     	and.16b	v16, v2, v6
     840: 4e261c86     	and.16b	v6, v4, v6
     844: 6f20a4c2     	ushll2.2d	v2, v6, #0x0
     848: 6f20a604     	ushll2.2d	v4, v16, #0x0
     84c: 2f20a4c6     	ushll.2d	v6, v6, #0x0
     850: 2f20a610     	ushll.2d	v16, v16, #0x0
     854: 4e080d51     	dup.2d	v17, x10
     858: 4ef08632     	add.2d	v18, v17, v16
     85c: 4ee48633     	add.2d	v19, v17, v4
     860: 4ee68634     	add.2d	v20, v17, v6
     864: 4ee28635     	add.2d	v21, v17, v2
     868: 4ef58555     	add.2d	v21, v10, v21
     86c: 4ef38553     	add.2d	v19, v10, v19
     870: 4ef28552     	add.2d	v18, v10, v18
     874: 4e183e4c     	mov.d	x12, v18[1]
     878: 9e66024d     	fmov	x13, d18
     87c: bd4001b2     	ldr	s18, [x13]
     880: 4e183e6d     	mov.d	x13, v19[1]
     884: bd400196     	ldr	s22, [x12]
     888: 4ef48554     	add.2d	v20, v10, v20
     88c: 9e66026c     	fmov	x12, d19
     890: bd400193     	ldr	s19, [x12]
     894: 4e183e8c     	mov.d	x12, v20[1]
     898: bd4001b7     	ldr	s23, [x13]
     89c: 9e66028d     	fmov	x13, d20
     8a0: bd4001b4     	ldr	s20, [x13]
     8a4: bd400198     	ldr	s24, [x12]
     8a8: 4e183eac     	mov.d	x12, v21[1]
     8ac: 9e6602ad     	fmov	x13, d21
     8b0: bd4001b5     	ldr	s21, [x13]
     8b4: bd400199     	ldr	s25, [x12]
     8b8: 4ef18431     	add.2d	v17, v1, v17
     8bc: 4ee0863a     	add.2d	v26, v17, v0
     8c0: 4ee3863b     	add.2d	v27, v17, v3
     8c4: 4ee5863c     	add.2d	v28, v17, v5
     8c8: 4ee78631     	add.2d	v17, v17, v7
     8cc: 4e183e2c     	mov.d	x12, v17[1]
     8d0: 9e66022d     	fmov	x13, d17
     8d4: bd0001b2     	str	s18, [x13]
     8d8: bd000196     	str	s22, [x12]
     8dc: 4e183f8c     	mov.d	x12, v28[1]
     8e0: 9e66038d     	fmov	x13, d28
     8e4: bd0001b3     	str	s19, [x13]
     8e8: bd000197     	str	s23, [x12]
     8ec: 4e183f6c     	mov.d	x12, v27[1]
     8f0: 9e66036d     	fmov	x13, d27
     8f4: bd0001b4     	str	s20, [x13]
     8f8: 4e183f4d     	mov.d	x13, v26[1]
     8fc: bd000198     	str	s24, [x12]
     900: 9e66034c     	fmov	x12, d26
     904: bd000195     	str	s21, [x12]
     908: bd0001b9     	str	s25, [x13]
     90c: 9100114a     	add	x10, x10, #0x4
     910: f110015f     	cmp	x10, #0x400
     914: 54fffa01     	b.ne	0x854 <ltmp0+0x854>
     918: d280000a     	mov	x10, #0x0               ; =0
     91c: 9e6601ec     	fmov	x12, d15
     920: bd400192     	ldr	s18, [x12]
     924: 0d4090d2     	ld1.s	{ v18 }[1], [x6]
     928: 9e6601cc     	fmov	x12, d14
     92c: 4d408192     	ld1.s	{ v18 }[2], [x12]
     930: 3dc033f1     	ldr	q17, [sp, #0xc0]
     934: 9e66022c     	fmov	x12, d17
     938: 4d4093d2     	ld1.s	{ v18 }[3], [x30]
     93c: 3dc037f1     	ldr	q17, [sp, #0xd0]
     940: 9e66022d     	fmov	x13, d17
     944: bd400191     	ldr	s17, [x12]
     948: f940ebec     	ldr	x12, [sp, #0x1d0]
     94c: 0d409191     	ld1.s	{ v17 }[1], [x12]
     950: 4d4081b1     	ld1.s	{ v17 }[2], [x13]
     954: f940f3ec     	ldr	x12, [sp, #0x1e0]
     958: 4d409191     	ld1.s	{ v17 }[3], [x12]
     95c: 6e31de31     	fmul.4s	v17, v17, v17
     960: 6e32de52     	fmul.4s	v18, v18, v18
     964: 3dc02bf3     	ldr	q19, [sp, #0xa0]
     968: 9e66026c     	fmov	x12, d19
     96c: 3dc02ff3     	ldr	q19, [sp, #0xb0]
     970: 9e66026d     	fmov	x13, d19
     974: bd400194     	ldr	s20, [x12]
     978: 0d409054     	ld1.s	{ v20 }[1], [x2]
     97c: 4d4081b4     	ld1.s	{ v20 }[2], [x13]
     980: ad4cd7f3     	ldp	q19, q21, [sp, #0x190]
     984: 9e66026c     	fmov	x12, d19
     988: 4d409214     	ld1.s	{ v20 }[3], [x16]
     98c: bd400193     	ldr	s19, [x12]
     990: 0d409353     	ld1.s	{ v19 }[1], [x26]
     994: 9e6602ac     	fmov	x12, d21
     998: 4d408193     	ld1.s	{ v19 }[2], [x12]
     99c: f94083ec     	ldr	x12, [sp, #0x100]
     9a0: 4d409193     	ld1.s	{ v19 }[3], [x12]
     9a4: 6e33de73     	fmul.4s	v19, v19, v19
     9a8: 3dc057f5     	ldr	q21, [sp, #0x150]
     9ac: 9e6602ac     	fmov	x12, d21
     9b0: 3dc05bf5     	ldr	q21, [sp, #0x160]
     9b4: 9e6602ad     	fmov	x13, d21
     9b8: ad4bdbf5     	ldp	q21, q22, [sp, #0x170]
     9bc: 9e6602a0     	fmov	x0, d21
     9c0: bd400015     	ldr	s21, [x0]
     9c4: 0d4091f5     	ld1.s	{ v21 }[1], [x15]
     9c8: 9e6602c0     	fmov	x0, d22
     9cc: 4d408015     	ld1.s	{ v21 }[2], [x0]
     9d0: 4d4091d5     	ld1.s	{ v21 }[3], [x14]
     9d4: bd400197     	ldr	s23, [x12]
     9d8: 0d4090b7     	ld1.s	{ v23 }[1], [x5]
     9dc: 4d4081b7     	ld1.s	{ v23 }[2], [x13]
     9e0: 4d409377     	ld1.s	{ v23 }[3], [x27]
     9e4: 6e34de96     	fmul.4s	v22, v20, v20
     9e8: 6e37def4     	fmul.4s	v20, v23, v23
     9ec: 6e35deb5     	fmul.4s	v21, v21, v21
     9f0: 3dc047f7     	ldr	q23, [sp, #0x110]
     9f4: 9e6602ec     	fmov	x12, d23
     9f8: 3dc04bf7     	ldr	q23, [sp, #0x120]
     9fc: 9e6602ed     	fmov	x13, d23
     a00: ad49e7f7     	ldp	q23, q25, [sp, #0x130]
     a04: 9e6602e0     	fmov	x0, d23
     a08: bd400018     	ldr	s24, [x0]
     a0c: 0d409138     	ld1.s	{ v24 }[1], [x9]
     a10: bd400197     	ldr	s23, [x12]
     a14: 0d409177     	ld1.s	{ v23 }[1], [x11]
     a18: 9e66032c     	fmov	x12, d25
     a1c: 4d4081b7     	ld1.s	{ v23 }[2], [x13]
     a20: 4d4090f7     	ld1.s	{ v23 }[3], [x7]
     a24: 6e37def7     	fmul.4s	v23, v23, v23
     a28: 4d408198     	ld1.s	{ v24 }[2], [x12]
     a2c: 4d409238     	ld1.s	{ v24 }[3], [x17]
     a30: 6e38df18     	fmul.4s	v24, v24, v24
     a34: 52800383     	mov	w3, #0x1c               ; =28
     a38: 90000019     	adrp	x25, 0x0 <ltmp0>
     a3c: d100306c     	sub	x12, x3, #0xc
     a40: 4e080d99     	dup.2d	v25, x12
     a44: 4ef98439     	add.2d	v25, v1, v25
     a48: 4ee0873a     	add.2d	v26, v25, v0
     a4c: 4ee3873b     	add.2d	v27, v25, v3
     a50: 4ee5873c     	add.2d	v28, v25, v5
     a54: 4ee78739     	add.2d	v25, v25, v7
     a58: 4e183f2c     	mov.d	x12, v25[1]
     a5c: 9e660320     	fmov	x0, d25
     a60: 4e183f93     	mov.d	x19, v28[1]
     a64: 9e660381     	fmov	x1, d28
     a68: 4e183f74     	mov.d	x20, v27[1]
     a6c: 9e660375     	fmov	x21, d27
     a70: 4e183f44     	mov.d	x4, v26[1]
     a74: 9e66034d     	fmov	x13, d26
     a78: d1002077     	sub	x23, x3, #0x8
     a7c: bd4002b9     	ldr	s25, [x21]
     a80: 4e080efa     	dup.2d	v26, x23
     a84: 4efa843b     	add.2d	v27, v1, v26
     a88: 4ee0877d     	add.2d	v29, v27, v0
     a8c: 4ee3877c     	add.2d	v28, v27, v3
     a90: bd40001a     	ldr	s26, [x0]
     a94: 4ee5877e     	add.2d	v30, v27, v5
     a98: 4ee7877b     	add.2d	v27, v27, v7
     a9c: 4e183f75     	mov.d	x21, v27[1]
     aa0: 0d409299     	ld1.s	{ v25 }[1], [x20]
     aa4: 4e183fc0     	mov.d	x0, v30[1]
     aa8: 4e183f94     	mov.d	x20, v28[1]
     aac: 0d40919a     	ld1.s	{ v26 }[1], [x12]
     ab0: 9e660377     	fmov	x23, d27
     ab4: 9e66038c     	fmov	x12, d28
     ab8: bd40019b     	ldr	s27, [x12]
     abc: 9e6603d8     	fmov	x24, d30
     ac0: 0d40929b     	ld1.s	{ v27 }[1], [x20]
     ac4: 4e183fac     	mov.d	x12, v29[1]
     ac8: bd4002fc     	ldr	s28, [x23]
     acc: d1001074     	sub	x20, x3, #0x4
     ad0: 0d4092bc     	ld1.s	{ v28 }[1], [x21]
     ad4: 4e080e9e     	dup.2d	v30, x20
     ad8: 9e6603b4     	fmov	x20, d29
     adc: 4efe843d     	add.2d	v29, v1, v30
     ae0: 4d4081b9     	ld1.s	{ v25 }[2], [x13]
     ae4: 4ee087be     	add.2d	v30, v29, v0
     ae8: 4ee387a8     	add.2d	v8, v29, v3
     aec: 4ee587a9     	add.2d	v9, v29, v5
     af0: 4ee787bd     	add.2d	v29, v29, v7
     af4: 4d40803a     	ld1.s	{ v26 }[2], [x1]
     af8: 4e183fad     	mov.d	x13, v29[1]
     afc: 4e183d01     	mov.d	x1, v8[1]
     b00: 4d40829b     	ld1.s	{ v27 }[2], [x20]
     b04: 9e660114     	fmov	x20, d8
     b08: bd400288     	ldr	s8, [x20]
     b0c: 4e183fd4     	mov.d	x20, v30[1]
     b10: 4d40831c     	ld1.s	{ v28 }[2], [x24]
     b14: 9e6603b5     	fmov	x21, d29
     b18: 0d409028     	ld1.s	{ v8 }[1], [x1]
     b1c: 9e6603c1     	fmov	x1, d30
     b20: 4d408028     	ld1.s	{ v8 }[2], [x1]
     b24: 4e183d21     	mov.d	x1, v9[1]
     b28: bd4002bd     	ldr	s29, [x21]
     b2c: 9e660135     	fmov	x21, d9
     b30: 4d409099     	ld1.s	{ v25 }[3], [x4]
     b34: 0d4091bd     	ld1.s	{ v29 }[1], [x13]
     b38: 4e080c7e     	dup.2d	v30, x3
     b3c: 4d40927a     	ld1.s	{ v26 }[3], [x19]
     b40: 4efe843e     	add.2d	v30, v1, v30
     b44: 4ee787c9     	add.2d	v9, v30, v7
     b48: 4e183d2d     	mov.d	x13, v9[1]
     b4c: 4d40919b     	ld1.s	{ v27 }[3], [x12]
     b50: 9e66012c     	fmov	x12, d9
     b54: 4ee587c9     	add.2d	v9, v30, v5
     b58: 4e183d24     	mov.d	x4, v9[1]
     b5c: 4d40901c     	ld1.s	{ v28 }[3], [x0]
     b60: 9e660120     	fmov	x0, d9
     b64: 4ee387c9     	add.2d	v9, v30, v3
     b68: 4e183d33     	mov.d	x19, v9[1]
     b6c: 4d409288     	ld1.s	{ v8 }[3], [x20]
     b70: 9e660134     	fmov	x20, d9
     b74: 6e3adf5a     	fmul.4s	v26, v26, v26
     b78: 6e39df39     	fmul.4s	v25, v25, v25
     b7c: 4d4082bd     	ld1.s	{ v29 }[2], [x21]
     b80: 4e39d652     	fadd.4s	v18, v18, v25
     b84: 4d40903d     	ld1.s	{ v29 }[3], [x1]
     b88: 4ee087d9     	add.2d	v25, v30, v0
     b8c: 4e183f21     	mov.d	x1, v25[1]
     b90: 4e3ad631     	fadd.4s	v17, v17, v26
     b94: 9e660335     	fmov	x21, d25
     b98: 6e3cdf99     	fmul.4s	v25, v28, v28
     b9c: 6e3bdf7a     	fmul.4s	v26, v27, v27
     ba0: 6e3ddfbb     	fmul.4s	v27, v29, v29
     ba4: 6e28dd1c     	fmul.4s	v28, v8, v8
     ba8: 4e3ad6d6     	fadd.4s	v22, v22, v26
     bac: bd40029a     	ldr	s26, [x20]
     bb0: 0d40927a     	ld1.s	{ v26 }[1], [x19]
     bb4: 4d4082ba     	ld1.s	{ v26 }[2], [x21]
     bb8: 4e39d673     	fadd.4s	v19, v19, v25
     bbc: 4d40903a     	ld1.s	{ v26 }[3], [x1]
     bc0: bd400199     	ldr	s25, [x12]
     bc4: 0d4091b9     	ld1.s	{ v25 }[1], [x13]
     bc8: 4e3cd6b5     	fadd.4s	v21, v21, v28
     bcc: 4d408019     	ld1.s	{ v25 }[2], [x0]
     bd0: 4d409099     	ld1.s	{ v25 }[3], [x4]
     bd4: 6e39df39     	fmul.4s	v25, v25, v25
     bd8: 4e3bd694     	fadd.4s	v20, v20, v27
     bdc: 6e3adf5a     	fmul.4s	v26, v26, v26
     be0: 4e3ad718     	fadd.4s	v24, v24, v26
     be4: 4e39d6f7     	fadd.4s	v23, v23, v25
     be8: 9100114a     	add	x10, x10, #0x4
     bec: 91004063     	add	x3, x3, #0x10
     bf0: f103f15f     	cmp	x10, #0xfc
     bf4: 54fff243     	b.lo	0xa3c <ltmp0+0xa3c>
     bf8: d280000a     	mov	x10, #0x0               ; =0
     bfc: bc6a6ad9     	ldr	s25, [x22, x10]
     c00: 4e080d5a     	dup.2d	v26, x10
     c04: 4efa87fa     	add.2d	v26, v31, v26
     c08: 4ee0875b     	add.2d	v27, v26, v0
     c0c: 4ee3875c     	add.2d	v28, v26, v3
     c10: 4ee5875d     	add.2d	v29, v26, v5
     c14: 4ee7875a     	add.2d	v26, v26, v7
     c18: 4e183f4c     	mov.d	x12, v26[1]
     c1c: 9e66034d     	fmov	x13, d26
     c20: bd0001b9     	str	s25, [x13]
     c24: bd000199     	str	s25, [x12]
     c28: 4e183fac     	mov.d	x12, v29[1]
     c2c: 9e6603ad     	fmov	x13, d29
     c30: bd0001b9     	str	s25, [x13]
     c34: bd000199     	str	s25, [x12]
     c38: 4e183f8c     	mov.d	x12, v28[1]
     c3c: 9e66038d     	fmov	x13, d28
     c40: bd0001b9     	str	s25, [x13]
     c44: 4e183f6d     	mov.d	x13, v27[1]
     c48: bd000199     	str	s25, [x12]
     c4c: 9e66036c     	fmov	x12, d27
     c50: bd000199     	str	s25, [x12]
     c54: bd0001b9     	str	s25, [x13]
     c58: 9100114a     	add	x10, x10, #0x4
     c5c: f110015f     	cmp	x10, #0x400
     c60: 54fffce1     	b.ne	0xbfc <ltmp0+0xbfc>
     c64: d280000a     	mov	x10, #0x0               ; =0
     c68: 4e36d652     	fadd.4s	v18, v18, v22
     c6c: 4e33d631     	fadd.4s	v17, v17, v19
     c70: 4e34d631     	fadd.4s	v17, v17, v20
     c74: 4e35d652     	fadd.4s	v18, v18, v21
     c78: 4e38d652     	fadd.4s	v18, v18, v24
     c7c: 4e37d631     	fadd.4s	v17, v17, v23
     c80: ad4dcff4     	ldp	q20, q19, [sp, #0x1b0]
     c84: 6e34de31     	fmul.4s	v17, v17, v20
     c88: 6e34de52     	fmul.4s	v18, v18, v20
     c8c: 4e33d652     	fadd.4s	v18, v18, v19
     c90: 4e33d631     	fadd.4s	v17, v17, v19
     c94: 6ea1fa31     	fsqrt.4s	v17, v17
     c98: 6ea1fa52     	fsqrt.4s	v18, v18
     c9c: 4e080d53     	dup.2d	v19, x10
     ca0: 4ea71e74     	orr.16b	v20, v19, v7
     ca4: 4ea51e75     	orr.16b	v21, v19, v5
     ca8: 4ea31e76     	orr.16b	v22, v19, v3
     cac: 4ea01e77     	orr.16b	v23, v19, v0
     cb0: 4ef78438     	add.2d	v24, v1, v23
     cb4: 4ef68439     	add.2d	v25, v1, v22
     cb8: 4ef5843a     	add.2d	v26, v1, v21
     cbc: 4ef4843b     	add.2d	v27, v1, v20
     cc0: 4e183f6c     	mov.d	x12, v27[1]
     cc4: 4e183f4d     	mov.d	x13, v26[1]
     cc8: 4e183f20     	mov.d	x0, v25[1]
     ccc: 9e660361     	fmov	x1, d27
     cd0: 9e660323     	fmov	x3, d25
     cd4: 4e183f04     	mov.d	x4, v24[1]
     cd8: 9e660313     	fmov	x19, d24
     cdc: bd400078     	ldr	s24, [x3]
     ce0: 0d409018     	ld1.s	{ v24 }[1], [x0]
     ce4: 4d408278     	ld1.s	{ v24 }[2], [x19]
     ce8: 4d409098     	ld1.s	{ v24 }[3], [x4]
     cec: 9e660340     	fmov	x0, d26
     cf0: bd400039     	ldr	s25, [x1]
     cf4: 0d409199     	ld1.s	{ v25 }[1], [x12]
     cf8: 4d408019     	ld1.s	{ v25 }[2], [x0]
     cfc: 4d4091b9     	ld1.s	{ v25 }[3], [x13]
     d00: 6e31ff39     	fdiv.4s	v25, v25, v17
     d04: 6e32ff18     	fdiv.4s	v24, v24, v18
     d08: 4ef787f7     	add.2d	v23, v31, v23
     d0c: 4ef687f6     	add.2d	v22, v31, v22
     d10: 4ef587f5     	add.2d	v21, v31, v21
     d14: 4ef487f4     	add.2d	v20, v31, v20
     d18: 4e183e8c     	mov.d	x12, v20[1]
     d1c: 4e183ead     	mov.d	x13, v21[1]
     d20: 9e660280     	fmov	x0, d20
     d24: 9e6602a1     	fmov	x1, d21
     d28: 4e183ec3     	mov.d	x3, v22[1]
     d2c: 4e183ee4     	mov.d	x4, v23[1]
     d30: 9e6602d3     	fmov	x19, d22
     d34: bd400014     	ldr	s20, [x0]
     d38: 0d409194     	ld1.s	{ v20 }[1], [x12]
     d3c: 4d408034     	ld1.s	{ v20 }[2], [x1]
     d40: 9e6602ec     	fmov	x12, d23
     d44: 4d4091b4     	ld1.s	{ v20 }[3], [x13]
     d48: bd400275     	ldr	s21, [x19]
     d4c: 0d409075     	ld1.s	{ v21 }[1], [x3]
     d50: 4d408195     	ld1.s	{ v21 }[2], [x12]
     d54: 4d409095     	ld1.s	{ v21 }[3], [x4]
     d58: 6e35df15     	fmul.4s	v21, v24, v21
     d5c: 6e34df34     	fmul.4s	v20, v25, v20
     d60: 4ef08676     	add.2d	v22, v19, v16
     d64: 4ee48677     	add.2d	v23, v19, v4
     d68: 4ee68678     	add.2d	v24, v19, v6
     d6c: 4ee28673     	add.2d	v19, v19, v2
     d70: 4ef38573     	add.2d	v19, v11, v19
     d74: 4ef68576     	add.2d	v22, v11, v22
     d78: 4e183ecc     	mov.d	x12, v22[1]
     d7c: 9e6602cd     	fmov	x13, d22
     d80: bd0001b4     	str	s20, [x13]
     d84: 0d009194     	st1.s	{ v20 }[1], [x12]
     d88: 4ef78576     	add.2d	v22, v11, v23
     d8c: 4e183ecc     	mov.d	x12, v22[1]
     d90: 9e6602cd     	fmov	x13, d22
     d94: 4d0081b4     	st1.s	{ v20 }[2], [x13]
     d98: 4ef88576     	add.2d	v22, v11, v24
     d9c: 4d009194     	st1.s	{ v20 }[3], [x12]
     da0: 4e183ecc     	mov.d	x12, v22[1]
     da4: 9e6602cd     	fmov	x13, d22
     da8: bd0001b5     	str	s21, [x13]
     dac: 0d009195     	st1.s	{ v21 }[1], [x12]
     db0: 4e183e6c     	mov.d	x12, v19[1]
     db4: 9e66026d     	fmov	x13, d19
     db8: 4d0081b5     	st1.s	{ v21 }[2], [x13]
     dbc: 4d009195     	st1.s	{ v21 }[3], [x12]
     dc0: 9100114a     	add	x10, x10, #0x4
     dc4: f110015f     	cmp	x10, #0x400
     dc8: 54fff6a1     	b.ne	0xc9c <ltmp0+0xc9c>
     dcc: d280000a     	mov	x10, #0x0               ; =0
     dd0: 321c038c     	orr	w12, w28, #0x10
     dd4: 4e040d82     	dup.4s	v2, w12
     dd8: 4f2a5442     	shl.4s	v2, v2, #0xa
     ddc: 4eac1c44     	orr.16b	v4, v2, v12
     de0: 4ead1c42     	orr.16b	v2, v2, v13
     de4: 4f072786     	movi.4s	v6, #0xfc, lsl #8
     de8: 4e261c50     	and.16b	v16, v2, v6
     dec: 4e261c86     	and.16b	v6, v4, v6
     df0: 6f20a4c2     	ushll2.2d	v2, v6, #0x0
     df4: 6f20a604     	ushll2.2d	v4, v16, #0x0
     df8: 2f20a4c6     	ushll.2d	v6, v6, #0x0
     dfc: 2f20a610     	ushll.2d	v16, v16, #0x0
     e00: 4e080d51     	dup.2d	v17, x10
     e04: 4ef08632     	add.2d	v18, v17, v16
     e08: 4ee48633     	add.2d	v19, v17, v4
     e0c: 4ee68634     	add.2d	v20, v17, v6
     e10: 4ee28635     	add.2d	v21, v17, v2
     e14: 4ef58555     	add.2d	v21, v10, v21
     e18: 4ef38553     	add.2d	v19, v10, v19
     e1c: 4ef28552     	add.2d	v18, v10, v18
     e20: 4e183e4c     	mov.d	x12, v18[1]
     e24: 9e66024d     	fmov	x13, d18
     e28: bd4001b2     	ldr	s18, [x13]
     e2c: 4e183e6d     	mov.d	x13, v19[1]
     e30: bd400196     	ldr	s22, [x12]
     e34: 4ef48554     	add.2d	v20, v10, v20
     e38: 9e66026c     	fmov	x12, d19
     e3c: bd400193     	ldr	s19, [x12]
     e40: 4e183e8c     	mov.d	x12, v20[1]
     e44: bd4001b7     	ldr	s23, [x13]
     e48: 9e66028d     	fmov	x13, d20
     e4c: bd4001b4     	ldr	s20, [x13]
     e50: bd400198     	ldr	s24, [x12]
     e54: 4e183eac     	mov.d	x12, v21[1]
     e58: 9e6602ad     	fmov	x13, d21
     e5c: bd4001b5     	ldr	s21, [x13]
     e60: bd400199     	ldr	s25, [x12]
     e64: 4ef18431     	add.2d	v17, v1, v17
     e68: 4ee0863a     	add.2d	v26, v17, v0
     e6c: 4ee3863b     	add.2d	v27, v17, v3
     e70: 4ee5863c     	add.2d	v28, v17, v5
     e74: 4ee78631     	add.2d	v17, v17, v7
     e78: 4e183e2c     	mov.d	x12, v17[1]
     e7c: 9e66022d     	fmov	x13, d17
     e80: bd0001b2     	str	s18, [x13]
     e84: bd000196     	str	s22, [x12]
     e88: 4e183f8c     	mov.d	x12, v28[1]
     e8c: 9e66038d     	fmov	x13, d28
     e90: bd0001b3     	str	s19, [x13]
     e94: bd000197     	str	s23, [x12]
     e98: 4e183f6c     	mov.d	x12, v27[1]
     e9c: 9e66036d     	fmov	x13, d27
     ea0: bd0001b4     	str	s20, [x13]
     ea4: 4e183f4d     	mov.d	x13, v26[1]
     ea8: bd000198     	str	s24, [x12]
     eac: 9e66034c     	fmov	x12, d26
     eb0: bd000195     	str	s21, [x12]
     eb4: bd0001b9     	str	s25, [x13]
     eb8: 9100114a     	add	x10, x10, #0x4
     ebc: f110015f     	cmp	x10, #0x400
     ec0: 54fffa01     	b.ne	0xe00 <ltmp0+0xe00>
     ec4: d280000a     	mov	x10, #0x0               ; =0
     ec8: 9e6601ec     	fmov	x12, d15
     ecc: bd400192     	ldr	s18, [x12]
     ed0: 0d4090d2     	ld1.s	{ v18 }[1], [x6]
     ed4: 9e6601cc     	fmov	x12, d14
     ed8: 4d408192     	ld1.s	{ v18 }[2], [x12]
     edc: 3dc033f1     	ldr	q17, [sp, #0xc0]
     ee0: 9e66022c     	fmov	x12, d17
     ee4: 4d4093d2     	ld1.s	{ v18 }[3], [x30]
     ee8: 3dc037f1     	ldr	q17, [sp, #0xd0]
     eec: 9e66022d     	fmov	x13, d17
     ef0: bd400191     	ldr	s17, [x12]
     ef4: f940ebec     	ldr	x12, [sp, #0x1d0]
     ef8: 0d409191     	ld1.s	{ v17 }[1], [x12]
     efc: 4d4081b1     	ld1.s	{ v17 }[2], [x13]
     f00: f940f3ec     	ldr	x12, [sp, #0x1e0]
     f04: 4d409191     	ld1.s	{ v17 }[3], [x12]
     f08: 6e31de31     	fmul.4s	v17, v17, v17
     f0c: 6e32de52     	fmul.4s	v18, v18, v18
     f10: 3dc02bf3     	ldr	q19, [sp, #0xa0]
     f14: 9e66026c     	fmov	x12, d19
     f18: 3dc02ff3     	ldr	q19, [sp, #0xb0]
     f1c: 9e66026d     	fmov	x13, d19
     f20: bd400194     	ldr	s20, [x12]
     f24: 0d409054     	ld1.s	{ v20 }[1], [x2]
     f28: 4d4081b4     	ld1.s	{ v20 }[2], [x13]
     f2c: ad4cd7f3     	ldp	q19, q21, [sp, #0x190]
     f30: 9e66026c     	fmov	x12, d19
     f34: 4d409214     	ld1.s	{ v20 }[3], [x16]
     f38: bd400193     	ldr	s19, [x12]
     f3c: 0d409353     	ld1.s	{ v19 }[1], [x26]
     f40: 9e6602ac     	fmov	x12, d21
     f44: 4d408193     	ld1.s	{ v19 }[2], [x12]
     f48: f94083ec     	ldr	x12, [sp, #0x100]
     f4c: 4d409193     	ld1.s	{ v19 }[3], [x12]
     f50: 6e33de73     	fmul.4s	v19, v19, v19
     f54: 3dc057f5     	ldr	q21, [sp, #0x150]
     f58: 9e6602ac     	fmov	x12, d21
     f5c: 3dc05bf5     	ldr	q21, [sp, #0x160]
     f60: 9e6602ad     	fmov	x13, d21
     f64: ad4bdbf5     	ldp	q21, q22, [sp, #0x170]
     f68: 9e6602a0     	fmov	x0, d21
     f6c: bd400015     	ldr	s21, [x0]
     f70: 0d4091f5     	ld1.s	{ v21 }[1], [x15]
     f74: 9e6602c0     	fmov	x0, d22
     f78: 4d408015     	ld1.s	{ v21 }[2], [x0]
     f7c: 4d4091d5     	ld1.s	{ v21 }[3], [x14]
     f80: bd400197     	ldr	s23, [x12]
     f84: 0d4090b7     	ld1.s	{ v23 }[1], [x5]
     f88: 4d4081b7     	ld1.s	{ v23 }[2], [x13]
     f8c: 4d409377     	ld1.s	{ v23 }[3], [x27]
     f90: 6e34de96     	fmul.4s	v22, v20, v20
     f94: 6e37def4     	fmul.4s	v20, v23, v23
     f98: 6e35deb5     	fmul.4s	v21, v21, v21
     f9c: 3dc047f7     	ldr	q23, [sp, #0x110]
     fa0: 9e6602ec     	fmov	x12, d23
     fa4: 3dc04bf7     	ldr	q23, [sp, #0x120]
     fa8: 9e6602ed     	fmov	x13, d23
     fac: ad49e7f7     	ldp	q23, q25, [sp, #0x130]
     fb0: 9e6602e0     	fmov	x0, d23
     fb4: bd400018     	ldr	s24, [x0]
     fb8: 0d409138     	ld1.s	{ v24 }[1], [x9]
     fbc: bd400197     	ldr	s23, [x12]
     fc0: 0d409177     	ld1.s	{ v23 }[1], [x11]
     fc4: 9e66032c     	fmov	x12, d25
     fc8: 4d4081b7     	ld1.s	{ v23 }[2], [x13]
     fcc: 4d4090f7     	ld1.s	{ v23 }[3], [x7]
     fd0: 6e37def7     	fmul.4s	v23, v23, v23
     fd4: 4d408198     	ld1.s	{ v24 }[2], [x12]
     fd8: 4d409238     	ld1.s	{ v24 }[3], [x17]
     fdc: 6e38df18     	fmul.4s	v24, v24, v24
     fe0: 52800383     	mov	w3, #0x1c               ; =28
     fe4: d100306c     	sub	x12, x3, #0xc
     fe8: 4e080d99     	dup.2d	v25, x12
     fec: 4ef98439     	add.2d	v25, v1, v25
     ff0: 4ee0873a     	add.2d	v26, v25, v0
     ff4: 4ee3873b     	add.2d	v27, v25, v3
     ff8: 4ee5873c     	add.2d	v28, v25, v5
     ffc: 4ee78739     	add.2d	v25, v25, v7
    1000: 4e183f2c     	mov.d	x12, v25[1]
    1004: 9e660320     	fmov	x0, d25
    1008: 4e183f93     	mov.d	x19, v28[1]
    100c: 9e660381     	fmov	x1, d28
    1010: 4e183f74     	mov.d	x20, v27[1]
    1014: 9e660375     	fmov	x21, d27
    1018: 4e183f44     	mov.d	x4, v26[1]
    101c: 9e66034d     	fmov	x13, d26
    1020: d1002077     	sub	x23, x3, #0x8
    1024: bd4002b9     	ldr	s25, [x21]
    1028: 4e080efa     	dup.2d	v26, x23
    102c: 4efa843b     	add.2d	v27, v1, v26
    1030: 4ee0877d     	add.2d	v29, v27, v0
    1034: 4ee3877c     	add.2d	v28, v27, v3
    1038: bd40001a     	ldr	s26, [x0]
    103c: 4ee5877e     	add.2d	v30, v27, v5
    1040: 4ee7877b     	add.2d	v27, v27, v7
    1044: 4e183f75     	mov.d	x21, v27[1]
    1048: 0d409299     	ld1.s	{ v25 }[1], [x20]
    104c: 4e183fc0     	mov.d	x0, v30[1]
    1050: 4e183f94     	mov.d	x20, v28[1]
    1054: 0d40919a     	ld1.s	{ v26 }[1], [x12]
    1058: 9e660377     	fmov	x23, d27
    105c: 9e66038c     	fmov	x12, d28
    1060: bd40019b     	ldr	s27, [x12]
    1064: 9e6603d8     	fmov	x24, d30
    1068: 0d40929b     	ld1.s	{ v27 }[1], [x20]
    106c: 4e183fac     	mov.d	x12, v29[1]
    1070: bd4002fc     	ldr	s28, [x23]
    1074: d1001074     	sub	x20, x3, #0x4
    1078: 0d4092bc     	ld1.s	{ v28 }[1], [x21]
    107c: 4e080e9e     	dup.2d	v30, x20
    1080: 9e6603b4     	fmov	x20, d29
    1084: 4efe843d     	add.2d	v29, v1, v30
    1088: 4d4081b9     	ld1.s	{ v25 }[2], [x13]
    108c: 4ee087be     	add.2d	v30, v29, v0
    1090: 4ee387a8     	add.2d	v8, v29, v3
    1094: 4ee587a9     	add.2d	v9, v29, v5
    1098: 4ee787bd     	add.2d	v29, v29, v7
    109c: 4d40803a     	ld1.s	{ v26 }[2], [x1]
    10a0: 4e183fad     	mov.d	x13, v29[1]
    10a4: 4e183d01     	mov.d	x1, v8[1]
    10a8: 4d40829b     	ld1.s	{ v27 }[2], [x20]
    10ac: 9e660114     	fmov	x20, d8
    10b0: bd400288     	ldr	s8, [x20]
    10b4: 4e183fd4     	mov.d	x20, v30[1]
    10b8: 4d40831c     	ld1.s	{ v28 }[2], [x24]
    10bc: 9e6603b5     	fmov	x21, d29
    10c0: 0d409028     	ld1.s	{ v8 }[1], [x1]
    10c4: 9e6603c1     	fmov	x1, d30
    10c8: 4d408028     	ld1.s	{ v8 }[2], [x1]
    10cc: 4e183d21     	mov.d	x1, v9[1]
    10d0: bd4002bd     	ldr	s29, [x21]
    10d4: 9e660135     	fmov	x21, d9
    10d8: 4d409099     	ld1.s	{ v25 }[3], [x4]
    10dc: 0d4091bd     	ld1.s	{ v29 }[1], [x13]
    10e0: 4e080c7e     	dup.2d	v30, x3
    10e4: 4d40927a     	ld1.s	{ v26 }[3], [x19]
    10e8: 4efe843e     	add.2d	v30, v1, v30
    10ec: 4ee787c9     	add.2d	v9, v30, v7
    10f0: 4e183d2d     	mov.d	x13, v9[1]
    10f4: 4d40919b     	ld1.s	{ v27 }[3], [x12]
    10f8: 9e66012c     	fmov	x12, d9
    10fc: 4ee587c9     	add.2d	v9, v30, v5
    1100: 4e183d24     	mov.d	x4, v9[1]
    1104: 4d40901c     	ld1.s	{ v28 }[3], [x0]
    1108: 9e660120     	fmov	x0, d9
    110c: 4ee387c9     	add.2d	v9, v30, v3
    1110: 4e183d33     	mov.d	x19, v9[1]
    1114: 4d409288     	ld1.s	{ v8 }[3], [x20]
    1118: 9e660134     	fmov	x20, d9
    111c: 6e3adf5a     	fmul.4s	v26, v26, v26
    1120: 6e39df39     	fmul.4s	v25, v25, v25
    1124: 4d4082bd     	ld1.s	{ v29 }[2], [x21]
    1128: 4e39d652     	fadd.4s	v18, v18, v25
    112c: 4d40903d     	ld1.s	{ v29 }[3], [x1]
    1130: 4ee087d9     	add.2d	v25, v30, v0
    1134: 4e183f21     	mov.d	x1, v25[1]
    1138: 4e3ad631     	fadd.4s	v17, v17, v26
    113c: 9e660335     	fmov	x21, d25
    1140: 6e3cdf99     	fmul.4s	v25, v28, v28
    1144: 6e3bdf7a     	fmul.4s	v26, v27, v27
    1148: 6e3ddfbb     	fmul.4s	v27, v29, v29
    114c: 6e28dd1c     	fmul.4s	v28, v8, v8
    1150: 4e3ad6d6     	fadd.4s	v22, v22, v26
    1154: bd40029a     	ldr	s26, [x20]
    1158: 0d40927a     	ld1.s	{ v26 }[1], [x19]
    115c: 4d4082ba     	ld1.s	{ v26 }[2], [x21]
    1160: 4e39d673     	fadd.4s	v19, v19, v25
    1164: 4d40903a     	ld1.s	{ v26 }[3], [x1]
    1168: bd400199     	ldr	s25, [x12]
    116c: 0d4091b9     	ld1.s	{ v25 }[1], [x13]
    1170: 4e3cd6b5     	fadd.4s	v21, v21, v28
    1174: 4d408019     	ld1.s	{ v25 }[2], [x0]
    1178: 4d409099     	ld1.s	{ v25 }[3], [x4]
    117c: 6e39df39     	fmul.4s	v25, v25, v25
    1180: 4e3bd694     	fadd.4s	v20, v20, v27
    1184: 6e3adf5a     	fmul.4s	v26, v26, v26
    1188: 4e3ad718     	fadd.4s	v24, v24, v26
    118c: 4e39d6f7     	fadd.4s	v23, v23, v25
    1190: 9100114a     	add	x10, x10, #0x4
    1194: 91004063     	add	x3, x3, #0x10
    1198: f103f15f     	cmp	x10, #0xfc
    119c: 54fff243     	b.lo	0xfe4 <ltmp0+0xfe4>
    11a0: d280000a     	mov	x10, #0x0               ; =0
    11a4: bc6a6ad9     	ldr	s25, [x22, x10]
    11a8: 4e080d5a     	dup.2d	v26, x10
    11ac: 4efa87fa     	add.2d	v26, v31, v26
    11b0: 4ee0875b     	add.2d	v27, v26, v0
    11b4: 4ee3875c     	add.2d	v28, v26, v3
    11b8: 4ee5875d     	add.2d	v29, v26, v5
    11bc: 4ee7875a     	add.2d	v26, v26, v7
    11c0: 4e183f4c     	mov.d	x12, v26[1]
    11c4: 9e66034d     	fmov	x13, d26
    11c8: bd0001b9     	str	s25, [x13]
    11cc: bd000199     	str	s25, [x12]
    11d0: 4e183fac     	mov.d	x12, v29[1]
    11d4: 9e6603ad     	fmov	x13, d29
    11d8: bd0001b9     	str	s25, [x13]
    11dc: bd000199     	str	s25, [x12]
    11e0: 4e183f8c     	mov.d	x12, v28[1]
    11e4: 9e66038d     	fmov	x13, d28
    11e8: bd0001b9     	str	s25, [x13]
    11ec: 4e183f6d     	mov.d	x13, v27[1]
    11f0: bd000199     	str	s25, [x12]
    11f4: 9e66036c     	fmov	x12, d27
    11f8: bd000199     	str	s25, [x12]
    11fc: bd0001b9     	str	s25, [x13]
    1200: 9100114a     	add	x10, x10, #0x4
    1204: f110015f     	cmp	x10, #0x400
    1208: 54fffce1     	b.ne	0x11a4 <ltmp0+0x11a4>
    120c: d280000a     	mov	x10, #0x0               ; =0
    1210: 4e36d652     	fadd.4s	v18, v18, v22
    1214: 4e33d631     	fadd.4s	v17, v17, v19
    1218: 4e34d631     	fadd.4s	v17, v17, v20
    121c: 4e35d652     	fadd.4s	v18, v18, v21
    1220: 4e38d652     	fadd.4s	v18, v18, v24
    1224: 4e37d631     	fadd.4s	v17, v17, v23
    1228: ad4dcff4     	ldp	q20, q19, [sp, #0x1b0]
    122c: 6e34de31     	fmul.4s	v17, v17, v20
    1230: 6e34de52     	fmul.4s	v18, v18, v20
    1234: 4e33d652     	fadd.4s	v18, v18, v19
    1238: 4e33d631     	fadd.4s	v17, v17, v19
    123c: 6ea1fa31     	fsqrt.4s	v17, v17
    1240: 6ea1fa52     	fsqrt.4s	v18, v18
    1244: 295153f5     	ldp	w21, w20, [sp, #0x88]
    1248: b94087f7     	ldr	w23, [sp, #0x84]
    124c: 4e080d53     	dup.2d	v19, x10
    1250: 4ea71e74     	orr.16b	v20, v19, v7
    1254: 4ea51e75     	orr.16b	v21, v19, v5
    1258: 4ea31e76     	orr.16b	v22, v19, v3
    125c: 4ea01e77     	orr.16b	v23, v19, v0
    1260: 4ef78438     	add.2d	v24, v1, v23
    1264: 4ef68439     	add.2d	v25, v1, v22
    1268: 4ef5843a     	add.2d	v26, v1, v21
    126c: 4ef4843b     	add.2d	v27, v1, v20
    1270: 4e183f6c     	mov.d	x12, v27[1]
    1274: 4e183f4d     	mov.d	x13, v26[1]
    1278: 4e183f20     	mov.d	x0, v25[1]
    127c: 9e660361     	fmov	x1, d27
    1280: 9e660323     	fmov	x3, d25
    1284: 4e183f04     	mov.d	x4, v24[1]
    1288: 9e660313     	fmov	x19, d24
    128c: bd400078     	ldr	s24, [x3]
    1290: 0d409018     	ld1.s	{ v24 }[1], [x0]
    1294: 4d408278     	ld1.s	{ v24 }[2], [x19]
    1298: 4d409098     	ld1.s	{ v24 }[3], [x4]
    129c: 9e660340     	fmov	x0, d26
    12a0: bd400039     	ldr	s25, [x1]
    12a4: 0d409199     	ld1.s	{ v25 }[1], [x12]
    12a8: 4d408019     	ld1.s	{ v25 }[2], [x0]
    12ac: 4d4091b9     	ld1.s	{ v25 }[3], [x13]
    12b0: 6e31ff39     	fdiv.4s	v25, v25, v17
    12b4: 6e32ff18     	fdiv.4s	v24, v24, v18
    12b8: 4ef787f7     	add.2d	v23, v31, v23
    12bc: 4ef687f6     	add.2d	v22, v31, v22
    12c0: 4ef587f5     	add.2d	v21, v31, v21
    12c4: 4ef487f4     	add.2d	v20, v31, v20
    12c8: 4e183e8c     	mov.d	x12, v20[1]
    12cc: 4e183ead     	mov.d	x13, v21[1]
    12d0: 9e660280     	fmov	x0, d20
    12d4: 9e6602a1     	fmov	x1, d21
    12d8: 4e183ec3     	mov.d	x3, v22[1]
    12dc: 4e183ee4     	mov.d	x4, v23[1]
    12e0: 9e6602d3     	fmov	x19, d22
    12e4: bd400014     	ldr	s20, [x0]
    12e8: 0d409194     	ld1.s	{ v20 }[1], [x12]
    12ec: 4d408034     	ld1.s	{ v20 }[2], [x1]
    12f0: 9e6602ec     	fmov	x12, d23
    12f4: 4d4091b4     	ld1.s	{ v20 }[3], [x13]
    12f8: bd400275     	ldr	s21, [x19]
    12fc: 0d409075     	ld1.s	{ v21 }[1], [x3]
    1300: 4d408195     	ld1.s	{ v21 }[2], [x12]
    1304: 4d409095     	ld1.s	{ v21 }[3], [x4]
    1308: 6e35df15     	fmul.4s	v21, v24, v21
    130c: 6e34df34     	fmul.4s	v20, v25, v20
    1310: 4ef08676     	add.2d	v22, v19, v16
    1314: 4ee48677     	add.2d	v23, v19, v4
    1318: 4ee68678     	add.2d	v24, v19, v6
    131c: 4ee28673     	add.2d	v19, v19, v2
    1320: 4ef38573     	add.2d	v19, v11, v19
    1324: 4ef68576     	add.2d	v22, v11, v22
    1328: 4e183ecc     	mov.d	x12, v22[1]
    132c: 9e6602cd     	fmov	x13, d22
    1330: bd0001b4     	str	s20, [x13]
    1334: 0d009194     	st1.s	{ v20 }[1], [x12]
    1338: 4ef78576     	add.2d	v22, v11, v23
    133c: 4e183ecc     	mov.d	x12, v22[1]
    1340: 9e6602cd     	fmov	x13, d22
    1344: 4d0081b4     	st1.s	{ v20 }[2], [x13]
    1348: 4ef88576     	add.2d	v22, v11, v24
    134c: 4d009194     	st1.s	{ v20 }[3], [x12]
    1350: 4e183ecc     	mov.d	x12, v22[1]
    1354: 9e6602cd     	fmov	x13, d22
    1358: bd0001b5     	str	s21, [x13]
    135c: 0d009195     	st1.s	{ v21 }[1], [x12]
    1360: 4e183e6c     	mov.d	x12, v19[1]
    1364: 9e66026d     	fmov	x13, d19
    1368: 4d0081b5     	st1.s	{ v21 }[2], [x13]
    136c: 4d009195     	st1.s	{ v21 }[3], [x12]
    1370: 9100114a     	add	x10, x10, #0x4
    1374: f110015f     	cmp	x10, #0x400
    1378: 54fff6a1     	b.ne	0x124c <ltmp0+0x124c>
    137c: d280000a     	mov	x10, #0x0               ; =0
    1380: 321d078c     	orr	w12, w28, #0x18
    1384: 4e040d82     	dup.4s	v2, w12
    1388: 4f2a5442     	shl.4s	v2, v2, #0xa
    138c: 4eac1c44     	orr.16b	v4, v2, v12
    1390: 4ead1c42     	orr.16b	v2, v2, v13
    1394: 4f072786     	movi.4s	v6, #0xfc, lsl #8
    1398: 4e261c50     	and.16b	v16, v2, v6
    139c: 4e261c86     	and.16b	v6, v4, v6
    13a0: 6f20a4c2     	ushll2.2d	v2, v6, #0x0
    13a4: 6f20a604     	ushll2.2d	v4, v16, #0x0
    13a8: 2f20a4c6     	ushll.2d	v6, v6, #0x0
    13ac: 2f20a610     	ushll.2d	v16, v16, #0x0
    13b0: 4e080d51     	dup.2d	v17, x10
    13b4: 4ef08632     	add.2d	v18, v17, v16
    13b8: 4ee48633     	add.2d	v19, v17, v4
    13bc: 4ee68634     	add.2d	v20, v17, v6
    13c0: 4ee28635     	add.2d	v21, v17, v2
    13c4: 4ef58555     	add.2d	v21, v10, v21
    13c8: 4ef38553     	add.2d	v19, v10, v19
    13cc: 4ef28552     	add.2d	v18, v10, v18
    13d0: 4e183e4c     	mov.d	x12, v18[1]
    13d4: 9e66024d     	fmov	x13, d18
    13d8: bd4001b2     	ldr	s18, [x13]
    13dc: 4e183e6d     	mov.d	x13, v19[1]
    13e0: bd400196     	ldr	s22, [x12]
    13e4: 4ef48554     	add.2d	v20, v10, v20
    13e8: 9e66026c     	fmov	x12, d19
    13ec: bd400193     	ldr	s19, [x12]
    13f0: 4e183e8c     	mov.d	x12, v20[1]
    13f4: bd4001b7     	ldr	s23, [x13]
    13f8: 9e66028d     	fmov	x13, d20
    13fc: bd4001b4     	ldr	s20, [x13]
    1400: bd400198     	ldr	s24, [x12]
    1404: 4e183eac     	mov.d	x12, v21[1]
    1408: 9e6602ad     	fmov	x13, d21
    140c: bd4001b5     	ldr	s21, [x13]
    1410: bd400199     	ldr	s25, [x12]
    1414: 4ef18431     	add.2d	v17, v1, v17
    1418: 4ee0863a     	add.2d	v26, v17, v0
    141c: 4ee3863b     	add.2d	v27, v17, v3
    1420: 4ee5863c     	add.2d	v28, v17, v5
    1424: 4ee78631     	add.2d	v17, v17, v7
    1428: 4e183e2c     	mov.d	x12, v17[1]
    142c: 9e66022d     	fmov	x13, d17
    1430: bd0001b2     	str	s18, [x13]
    1434: bd000196     	str	s22, [x12]
    1438: 4e183f8c     	mov.d	x12, v28[1]
    143c: 9e66038d     	fmov	x13, d28
    1440: bd0001b3     	str	s19, [x13]
    1444: bd000197     	str	s23, [x12]
    1448: 4e183f6c     	mov.d	x12, v27[1]
    144c: 9e66036d     	fmov	x13, d27
    1450: bd0001b4     	str	s20, [x13]
    1454: 4e183f4d     	mov.d	x13, v26[1]
    1458: bd000198     	str	s24, [x12]
    145c: 9e66034c     	fmov	x12, d26
    1460: bd000195     	str	s21, [x12]
    1464: bd0001b9     	str	s25, [x13]
    1468: 9100114a     	add	x10, x10, #0x4
    146c: f110015f     	cmp	x10, #0x400
    1470: 54fffa01     	b.ne	0x13b0 <ltmp0+0x13b0>
    1474: d280000a     	mov	x10, #0x0               ; =0
    1478: 9e6601ec     	fmov	x12, d15
    147c: bd400192     	ldr	s18, [x12]
    1480: 0d4090d2     	ld1.s	{ v18 }[1], [x6]
    1484: 9e6601cc     	fmov	x12, d14
    1488: 4d408192     	ld1.s	{ v18 }[2], [x12]
    148c: ad4647ea     	ldp	q10, q17, [sp, #0xc0]
    1490: 9e66014c     	fmov	x12, d10
    1494: 4d4093d2     	ld1.s	{ v18 }[3], [x30]
    1498: 9e66022d     	fmov	x13, d17
    149c: bd400191     	ldr	s17, [x12]
    14a0: f940ebec     	ldr	x12, [sp, #0x1d0]
    14a4: 0d409191     	ld1.s	{ v17 }[1], [x12]
    14a8: 4d4081b1     	ld1.s	{ v17 }[2], [x13]
    14ac: f940f3ec     	ldr	x12, [sp, #0x1e0]
    14b0: 4d409191     	ld1.s	{ v17 }[3], [x12]
    14b4: 6e31de31     	fmul.4s	v17, v17, v17
    14b8: 6e32de52     	fmul.4s	v18, v18, v18
    14bc: ad4533ed     	ldp	q13, q12, [sp, #0xa0]
    14c0: 9e6601ac     	fmov	x12, d13
    14c4: 9e66018d     	fmov	x13, d12
    14c8: bd400194     	ldr	s20, [x12]
    14cc: 0d409054     	ld1.s	{ v20 }[1], [x2]
    14d0: 4d4081b4     	ld1.s	{ v20 }[2], [x13]
    14d4: ad4cd7f3     	ldp	q19, q21, [sp, #0x190]
    14d8: 9e66026c     	fmov	x12, d19
    14dc: 4d409214     	ld1.s	{ v20 }[3], [x16]
    14e0: bd400193     	ldr	s19, [x12]
    14e4: 0d409353     	ld1.s	{ v19 }[1], [x26]
    14e8: 9e6602ac     	fmov	x12, d21
    14ec: 4d408193     	ld1.s	{ v19 }[2], [x12]
    14f0: f94083ec     	ldr	x12, [sp, #0x100]
    14f4: 4d409193     	ld1.s	{ v19 }[3], [x12]
    14f8: 6e33de73     	fmul.4s	v19, v19, v19
    14fc: 3dc057f5     	ldr	q21, [sp, #0x150]
    1500: 9e6602ac     	fmov	x12, d21
    1504: 3dc05bf5     	ldr	q21, [sp, #0x160]
    1508: 9e6602ad     	fmov	x13, d21
    150c: ad4bdbf5     	ldp	q21, q22, [sp, #0x170]
    1510: 9e6602b0     	fmov	x16, d21
    1514: bd400215     	ldr	s21, [x16]
    1518: 0d4091f5     	ld1.s	{ v21 }[1], [x15]
    151c: 9e6602cf     	fmov	x15, d22
    1520: 4d4081f5     	ld1.s	{ v21 }[2], [x15]
    1524: 4d4091d5     	ld1.s	{ v21 }[3], [x14]
    1528: bd400197     	ldr	s23, [x12]
    152c: 0d4090b7     	ld1.s	{ v23 }[1], [x5]
    1530: 4d4081b7     	ld1.s	{ v23 }[2], [x13]
    1534: 4d409377     	ld1.s	{ v23 }[3], [x27]
    1538: 6e34de96     	fmul.4s	v22, v20, v20
    153c: 6e37def4     	fmul.4s	v20, v23, v23
    1540: 6e35deb5     	fmul.4s	v21, v21, v21
    1544: 3dc047f7     	ldr	q23, [sp, #0x110]
    1548: 9e6602ec     	fmov	x12, d23
    154c: 3dc04bf7     	ldr	q23, [sp, #0x120]
    1550: 9e6602ed     	fmov	x13, d23
    1554: ad49e7f7     	ldp	q23, q25, [sp, #0x130]
    1558: 9e6602ee     	fmov	x14, d23
    155c: bd4001d8     	ldr	s24, [x14]
    1560: 0d409138     	ld1.s	{ v24 }[1], [x9]
    1564: bd400197     	ldr	s23, [x12]
    1568: 0d409177     	ld1.s	{ v23 }[1], [x11]
    156c: 9e660329     	fmov	x9, d25
    1570: 4d4081b7     	ld1.s	{ v23 }[2], [x13]
    1574: 4d4090f7     	ld1.s	{ v23 }[3], [x7]
    1578: 6e37def7     	fmul.4s	v23, v23, v23
    157c: 4d408138     	ld1.s	{ v24 }[2], [x9]
    1580: 4d409238     	ld1.s	{ v24 }[3], [x17]
    1584: 6e38df18     	fmul.4s	v24, v24, v24
    1588: 52800389     	mov	w9, #0x1c               ; =28
    158c: 5298b59c     	mov	w28, #0xc5ac            ; =50604
    1590: 72a6e4fc     	movk	w28, #0x3727, lsl #16
    1594: d100312b     	sub	x11, x9, #0xc
    1598: 4e080d79     	dup.2d	v25, x11
    159c: 4ef98439     	add.2d	v25, v1, v25
    15a0: 4ee0873a     	add.2d	v26, v25, v0
    15a4: 4ee3873b     	add.2d	v27, v25, v3
    15a8: 4ee5873c     	add.2d	v28, v25, v5
    15ac: 4ee78739     	add.2d	v25, v25, v7
    15b0: 4e183f2c     	mov.d	x12, v25[1]
    15b4: 9e66032f     	fmov	x15, d25
    15b8: 4e183f8b     	mov.d	x11, v28[1]
    15bc: 9e660390     	fmov	x16, d28
    15c0: 4e183f71     	mov.d	x17, v27[1]
    15c4: 9e660360     	fmov	x0, d27
    15c8: 4e183f4e     	mov.d	x14, v26[1]
    15cc: 9e66034d     	fmov	x13, d26
    15d0: d1002121     	sub	x1, x9, #0x8
    15d4: bd400019     	ldr	s25, [x0]
    15d8: 4e080c3a     	dup.2d	v26, x1
    15dc: 4efa843b     	add.2d	v27, v1, v26
    15e0: 4ee0877d     	add.2d	v29, v27, v0
    15e4: 4ee3877c     	add.2d	v28, v27, v3
    15e8: bd4001fa     	ldr	s26, [x15]
    15ec: 4ee5877e     	add.2d	v30, v27, v5
    15f0: 4ee7877b     	add.2d	v27, v27, v7
    15f4: 4e183f60     	mov.d	x0, v27[1]
    15f8: 0d409239     	ld1.s	{ v25 }[1], [x17]
    15fc: 4e183fcf     	mov.d	x15, v30[1]
    1600: 4e183f91     	mov.d	x17, v28[1]
    1604: 0d40919a     	ld1.s	{ v26 }[1], [x12]
    1608: 9e660361     	fmov	x1, d27
    160c: 9e66038c     	fmov	x12, d28
    1610: bd40019b     	ldr	s27, [x12]
    1614: 9e6603c2     	fmov	x2, d30
    1618: 0d40923b     	ld1.s	{ v27 }[1], [x17]
    161c: 4e183fac     	mov.d	x12, v29[1]
    1620: bd40003c     	ldr	s28, [x1]
    1624: d1001131     	sub	x17, x9, #0x4
    1628: 0d40901c     	ld1.s	{ v28 }[1], [x0]
    162c: 4e080e3e     	dup.2d	v30, x17
    1630: 9e6603b1     	fmov	x17, d29
    1634: 4efe843d     	add.2d	v29, v1, v30
    1638: 4d4081b9     	ld1.s	{ v25 }[2], [x13]
    163c: 4ee087be     	add.2d	v30, v29, v0
    1640: 4ee387a8     	add.2d	v8, v29, v3
    1644: 4ee587a9     	add.2d	v9, v29, v5
    1648: 4ee787bd     	add.2d	v29, v29, v7
    164c: 4d40821a     	ld1.s	{ v26 }[2], [x16]
    1650: 4e183fad     	mov.d	x13, v29[1]
    1654: 4e183d10     	mov.d	x16, v8[1]
    1658: 4d40823b     	ld1.s	{ v27 }[2], [x17]
    165c: 9e660111     	fmov	x17, d8
    1660: bd400228     	ldr	s8, [x17]
    1664: 4e183fd1     	mov.d	x17, v30[1]
    1668: 4d40805c     	ld1.s	{ v28 }[2], [x2]
    166c: 9e6603a0     	fmov	x0, d29
    1670: 0d409208     	ld1.s	{ v8 }[1], [x16]
    1674: 9e6603d0     	fmov	x16, d30
    1678: 4d408208     	ld1.s	{ v8 }[2], [x16]
    167c: 4e183d30     	mov.d	x16, v9[1]
    1680: bd40001d     	ldr	s29, [x0]
    1684: 9e660120     	fmov	x0, d9
    1688: 4d4091d9     	ld1.s	{ v25 }[3], [x14]
    168c: 0d4091bd     	ld1.s	{ v29 }[1], [x13]
    1690: 4e080d3e     	dup.2d	v30, x9
    1694: 4d40917a     	ld1.s	{ v26 }[3], [x11]
    1698: 4efe843e     	add.2d	v30, v1, v30
    169c: 4ee787c9     	add.2d	v9, v30, v7
    16a0: 4e183d2b     	mov.d	x11, v9[1]
    16a4: 4d40919b     	ld1.s	{ v27 }[3], [x12]
    16a8: 9e66012c     	fmov	x12, d9
    16ac: 4ee587c9     	add.2d	v9, v30, v5
    16b0: 4e183d2d     	mov.d	x13, v9[1]
    16b4: 4d4091fc     	ld1.s	{ v28 }[3], [x15]
    16b8: 9e66012e     	fmov	x14, d9
    16bc: 4ee387c9     	add.2d	v9, v30, v3
    16c0: 4e183d2f     	mov.d	x15, v9[1]
    16c4: 4d409228     	ld1.s	{ v8 }[3], [x17]
    16c8: 9e660131     	fmov	x17, d9
    16cc: 6e3adf5a     	fmul.4s	v26, v26, v26
    16d0: 6e39df39     	fmul.4s	v25, v25, v25
    16d4: 4d40801d     	ld1.s	{ v29 }[2], [x0]
    16d8: 4e39d652     	fadd.4s	v18, v18, v25
    16dc: 4d40921d     	ld1.s	{ v29 }[3], [x16]
    16e0: 4ee087d9     	add.2d	v25, v30, v0
    16e4: 4e183f30     	mov.d	x16, v25[1]
    16e8: 4e3ad631     	fadd.4s	v17, v17, v26
    16ec: 9e660320     	fmov	x0, d25
    16f0: 6e3cdf99     	fmul.4s	v25, v28, v28
    16f4: 6e3bdf7a     	fmul.4s	v26, v27, v27
    16f8: 6e3ddfbb     	fmul.4s	v27, v29, v29
    16fc: 6e28dd1c     	fmul.4s	v28, v8, v8
    1700: 4e3ad6d6     	fadd.4s	v22, v22, v26
    1704: bd40023a     	ldr	s26, [x17]
    1708: 0d4091fa     	ld1.s	{ v26 }[1], [x15]
    170c: 4d40801a     	ld1.s	{ v26 }[2], [x0]
    1710: 4e39d673     	fadd.4s	v19, v19, v25
    1714: 4d40921a     	ld1.s	{ v26 }[3], [x16]
    1718: bd400199     	ldr	s25, [x12]
    171c: 0d409179     	ld1.s	{ v25 }[1], [x11]
    1720: 4e3cd6b5     	fadd.4s	v21, v21, v28
    1724: 4d4081d9     	ld1.s	{ v25 }[2], [x14]
    1728: 4d4091b9     	ld1.s	{ v25 }[3], [x13]
    172c: 6e39df39     	fmul.4s	v25, v25, v25
    1730: 4e3bd694     	fadd.4s	v20, v20, v27
    1734: 6e3adf5a     	fmul.4s	v26, v26, v26
    1738: 4e3ad718     	fadd.4s	v24, v24, v26
    173c: 4e39d6f7     	fadd.4s	v23, v23, v25
    1740: 9100114a     	add	x10, x10, #0x4
    1744: 91004129     	add	x9, x9, #0x10
    1748: f103f15f     	cmp	x10, #0xfc
    174c: 54fff243     	b.lo	0x1594 <ltmp0+0x1594>
    1750: d2800009     	mov	x9, #0x0                ; =0
    1754: 9000001a     	adrp	x26, 0x1000 <ltmp0+0x1000>
    1758: 52a7701b     	mov	w27, #0x3b800000        ; =998244352
    175c: f9403ffe     	ldr	x30, [sp, #0x78]
    1760: bc696ad9     	ldr	s25, [x22, x9]
    1764: 4e080d3a     	dup.2d	v26, x9
    1768: 4efa87fa     	add.2d	v26, v31, v26
    176c: 4ee0875b     	add.2d	v27, v26, v0
    1770: 4ee3875c     	add.2d	v28, v26, v3
    1774: 4ee5875d     	add.2d	v29, v26, v5
    1778: 4ee7875a     	add.2d	v26, v26, v7
    177c: 4e183f4a     	mov.d	x10, v26[1]
    1780: 9e66034b     	fmov	x11, d26
    1784: bd000179     	str	s25, [x11]
    1788: bd000159     	str	s25, [x10]
    178c: 4e183faa     	mov.d	x10, v29[1]
    1790: 9e6603ab     	fmov	x11, d29
    1794: bd000179     	str	s25, [x11]
    1798: bd000159     	str	s25, [x10]
    179c: 4e183f8a     	mov.d	x10, v28[1]
    17a0: 9e66038b     	fmov	x11, d28
    17a4: bd000179     	str	s25, [x11]
    17a8: 4e183f6b     	mov.d	x11, v27[1]
    17ac: bd000159     	str	s25, [x10]
    17b0: 9e66036a     	fmov	x10, d27
    17b4: bd000159     	str	s25, [x10]
    17b8: bd000179     	str	s25, [x11]
    17bc: 91001129     	add	x9, x9, #0x4
    17c0: f110013f     	cmp	x9, #0x400
    17c4: 54fffce1     	b.ne	0x1760 <ltmp0+0x1760>
    17c8: d2800009     	mov	x9, #0x0                ; =0
    17cc: 4e36d652     	fadd.4s	v18, v18, v22
    17d0: 4e33d631     	fadd.4s	v17, v17, v19
    17d4: 4e34d631     	fadd.4s	v17, v17, v20
    17d8: 4e35d652     	fadd.4s	v18, v18, v21
    17dc: 4e38d652     	fadd.4s	v18, v18, v24
    17e0: 4e37d631     	fadd.4s	v17, v17, v23
    17e4: ad4dcff4     	ldp	q20, q19, [sp, #0x1b0]
    17e8: 6e34de31     	fmul.4s	v17, v17, v20
    17ec: 6e34de52     	fmul.4s	v18, v18, v20
    17f0: 4e33d652     	fadd.4s	v18, v18, v19
    17f4: 4e33d631     	fadd.4s	v17, v17, v19
    17f8: 6ea1fa31     	fsqrt.4s	v17, v17
    17fc: 6ea1fa52     	fsqrt.4s	v18, v18
    1800: 4e080d33     	dup.2d	v19, x9
    1804: 4ea71e74     	orr.16b	v20, v19, v7
    1808: 4ea51e75     	orr.16b	v21, v19, v5
    180c: 4ea31e76     	orr.16b	v22, v19, v3
    1810: 4ea01e77     	orr.16b	v23, v19, v0
    1814: 4ef78438     	add.2d	v24, v1, v23
    1818: 4ef68439     	add.2d	v25, v1, v22
    181c: 4ef5843a     	add.2d	v26, v1, v21
    1820: 4ef4843b     	add.2d	v27, v1, v20
    1824: 4e183f6a     	mov.d	x10, v27[1]
    1828: 4e183f4b     	mov.d	x11, v26[1]
    182c: 4e183f2c     	mov.d	x12, v25[1]
    1830: 9e66036d     	fmov	x13, d27
    1834: 9e66032e     	fmov	x14, d25
    1838: 4e183f0f     	mov.d	x15, v24[1]
    183c: 9e660310     	fmov	x16, d24
    1840: bd4001d8     	ldr	s24, [x14]
    1844: 0d409198     	ld1.s	{ v24 }[1], [x12]
    1848: 4d408218     	ld1.s	{ v24 }[2], [x16]
    184c: 4d4091f8     	ld1.s	{ v24 }[3], [x15]
    1850: 9e66034c     	fmov	x12, d26
    1854: bd4001b9     	ldr	s25, [x13]
    1858: 0d409159     	ld1.s	{ v25 }[1], [x10]
    185c: 4d408199     	ld1.s	{ v25 }[2], [x12]
    1860: 4d409179     	ld1.s	{ v25 }[3], [x11]
    1864: 6e31ff39     	fdiv.4s	v25, v25, v17
    1868: 6e32ff18     	fdiv.4s	v24, v24, v18
    186c: 4ef787f7     	add.2d	v23, v31, v23
    1870: 4ef687f6     	add.2d	v22, v31, v22
    1874: 4ef587f5     	add.2d	v21, v31, v21
    1878: 4ef487f4     	add.2d	v20, v31, v20
    187c: 4e183e8a     	mov.d	x10, v20[1]
    1880: 4e183eab     	mov.d	x11, v21[1]
    1884: 9e66028c     	fmov	x12, d20
    1888: 9e6602ad     	fmov	x13, d21
    188c: 4e183ece     	mov.d	x14, v22[1]
    1890: 4e183eef     	mov.d	x15, v23[1]
    1894: 9e6602d0     	fmov	x16, d22
    1898: bd400194     	ldr	s20, [x12]
    189c: 0d409154     	ld1.s	{ v20 }[1], [x10]
    18a0: 4d4081b4     	ld1.s	{ v20 }[2], [x13]
    18a4: 9e6602ea     	fmov	x10, d23
    18a8: 4d409174     	ld1.s	{ v20 }[3], [x11]
    18ac: bd400215     	ldr	s21, [x16]
    18b0: 0d4091d5     	ld1.s	{ v21 }[1], [x14]
    18b4: 4d408155     	ld1.s	{ v21 }[2], [x10]
    18b8: 4d4091f5     	ld1.s	{ v21 }[3], [x15]
    18bc: 6e35df15     	fmul.4s	v21, v24, v21
    18c0: 6e34df34     	fmul.4s	v20, v25, v20
    18c4: 4ef08676     	add.2d	v22, v19, v16
    18c8: 4ee48677     	add.2d	v23, v19, v4
    18cc: 4ee68678     	add.2d	v24, v19, v6
    18d0: 4ee28673     	add.2d	v19, v19, v2
    18d4: 4ef38573     	add.2d	v19, v11, v19
    18d8: 4ef68576     	add.2d	v22, v11, v22
    18dc: 4e183eca     	mov.d	x10, v22[1]
    18e0: 9e6602cb     	fmov	x11, d22
    18e4: bd000174     	str	s20, [x11]
    18e8: 0d009154     	st1.s	{ v20 }[1], [x10]
    18ec: 4ef78576     	add.2d	v22, v11, v23
    18f0: 4e183eca     	mov.d	x10, v22[1]
    18f4: 9e6602cb     	fmov	x11, d22
    18f8: 4d008174     	st1.s	{ v20 }[2], [x11]
    18fc: 4ef88576     	add.2d	v22, v11, v24
    1900: 4d009154     	st1.s	{ v20 }[3], [x10]
    1904: 4e183eca     	mov.d	x10, v22[1]
    1908: 9e6602cb     	fmov	x11, d22
    190c: bd000175     	str	s21, [x11]
    1910: 0d009155     	st1.s	{ v21 }[1], [x10]
    1914: 4e183e6a     	mov.d	x10, v19[1]
    1918: 9e66026b     	fmov	x11, d19
    191c: 4d008175     	st1.s	{ v21 }[2], [x11]
    1920: 4d009155     	st1.s	{ v21 }[3], [x10]
    1924: 91001129     	add	x9, x9, #0x4
    1928: f110013f     	cmp	x9, #0x400
    192c: 54fff6a1     	b.ne	0x1800 <ltmp0+0x1800>
    1930: 3dc037eb     	ldr	q11, [sp, #0xd0]
    1934: b940f3f6     	ldr	w22, [sp, #0xf0]
    1938: f94073f8     	ldr	x24, [sp, #0xe0]
    193c: 17fffa14     	b	0x18c <ltmp0+0x18c>
    1940: d343fd2b     	lsr	x11, x9, #3
    1944: f100213f     	cmp	x9, #0x8
    1948: 54003043     	b.lo	0x1f50 <ltmp0+0x1f50>
    194c: 5280000e     	mov	w14, #0x0               ; =0
    1950: f9404bea     	ldr	x10, [sp, #0x90]
    1954: f940014f     	ldr	x15, [x10]
    1958: f9400950     	ldr	x16, [x10, #0x10]
    195c: 531b6b11     	lsl	w17, w24, #5
    1960: f9401942     	ldr	x2, [x10, #0x30]
    1964: d280000a     	mov	x10, #0x0               ; =0
    1968: 0b0e0e2c     	add	w12, w17, w14, lsl #3
    196c: 4e040d82     	dup.4s	v2, w12
    1970: 4f2a5442     	shl.4s	v2, v2, #0xa
    1974: 3dc00324     	ldr	q4, [x25]
    1978: 4ea41c44     	orr.16b	v4, v2, v4
    197c: 3dc00346     	ldr	q6, [x26]
    1980: 4ea61c42     	orr.16b	v2, v2, v6
    1984: 4f072786     	movi.4s	v6, #0xfc, lsl #8
    1988: 4e261c50     	and.16b	v16, v2, v6
    198c: 4e261c86     	and.16b	v6, v4, v6
    1990: 6f20a4c2     	ushll2.2d	v2, v6, #0x0
    1994: 6f20a604     	ushll2.2d	v4, v16, #0x0
    1998: 2f20a4c6     	ushll.2d	v6, v6, #0x0
    199c: 2f20a610     	ushll.2d	v16, v16, #0x0
    19a0: 4e080d51     	dup.2d	v17, x10
    19a4: 4ef08632     	add.2d	v18, v17, v16
    19a8: 4ee48633     	add.2d	v19, v17, v4
    19ac: 4ee68634     	add.2d	v20, v17, v6
    19b0: 4e080df5     	dup.2d	v21, x15
    19b4: 4ee28636     	add.2d	v22, v17, v2
    19b8: 4ef686b6     	add.2d	v22, v21, v22
    19bc: 4ef386b3     	add.2d	v19, v21, v19
    19c0: 4ef286b2     	add.2d	v18, v21, v18
    19c4: 4e183e4c     	mov.d	x12, v18[1]
    19c8: 9e66024d     	fmov	x13, d18
    19cc: bd4001b2     	ldr	s18, [x13]
    19d0: 4e183e6d     	mov.d	x13, v19[1]
    19d4: bd400197     	ldr	s23, [x12]
    19d8: 4ef486b4     	add.2d	v20, v21, v20
    19dc: 9e66026c     	fmov	x12, d19
    19e0: bd400193     	ldr	s19, [x12]
    19e4: 4e183e8c     	mov.d	x12, v20[1]
    19e8: bd4001b5     	ldr	s21, [x13]
    19ec: 9e66028d     	fmov	x13, d20
    19f0: bd4001b4     	ldr	s20, [x13]
    19f4: bd400198     	ldr	s24, [x12]
    19f8: 4e183ecc     	mov.d	x12, v22[1]
    19fc: 9e6602cd     	fmov	x13, d22
    1a00: bd4001b6     	ldr	s22, [x13]
    1a04: bd400199     	ldr	s25, [x12]
    1a08: 4ef18431     	add.2d	v17, v1, v17
    1a0c: 4ee0863a     	add.2d	v26, v17, v0
    1a10: 4ee3863b     	add.2d	v27, v17, v3
    1a14: 4ee5863c     	add.2d	v28, v17, v5
    1a18: 4ee78631     	add.2d	v17, v17, v7
    1a1c: 4e183e2c     	mov.d	x12, v17[1]
    1a20: 9e66022d     	fmov	x13, d17
    1a24: bd0001b2     	str	s18, [x13]
    1a28: bd000197     	str	s23, [x12]
    1a2c: 4e183f8c     	mov.d	x12, v28[1]
    1a30: 9e66038d     	fmov	x13, d28
    1a34: bd0001b3     	str	s19, [x13]
    1a38: bd000195     	str	s21, [x12]
    1a3c: 4e183f6c     	mov.d	x12, v27[1]
    1a40: 9e66036d     	fmov	x13, d27
    1a44: bd0001b4     	str	s20, [x13]
    1a48: 4e183f4d     	mov.d	x13, v26[1]
    1a4c: bd000198     	str	s24, [x12]
    1a50: 9e66034c     	fmov	x12, d26
    1a54: bd000196     	str	s22, [x12]
    1a58: bd0001b9     	str	s25, [x13]
    1a5c: 9100114a     	add	x10, x10, #0x4
    1a60: f110015f     	cmp	x10, #0x400
    1a64: 54fff9e1     	b.ne	0x19a0 <ltmp0+0x19a0>
    1a68: d280000a     	mov	x10, #0x0               ; =0
    1a6c: 4e183d4c     	mov.d	x12, v10[1]
    1a70: 4e183d6d     	mov.d	x13, v11[1]
    1a74: 4e183de0     	mov.d	x0, v15[1]
    1a78: 9e660141     	fmov	x1, d10
    1a7c: 9e6601e3     	fmov	x3, d15
    1a80: 4e183dc4     	mov.d	x4, v14[1]
    1a84: 9e6601c5     	fmov	x5, d14
    1a88: bd400072     	ldr	s18, [x3]
    1a8c: 0d409012     	ld1.s	{ v18 }[1], [x0]
    1a90: 4d4080b2     	ld1.s	{ v18 }[2], [x5]
    1a94: 4d409092     	ld1.s	{ v18 }[3], [x4]
    1a98: 9e660160     	fmov	x0, d11
    1a9c: bd400031     	ldr	s17, [x1]
    1aa0: 0d409191     	ld1.s	{ v17 }[1], [x12]
    1aa4: 4d408011     	ld1.s	{ v17 }[2], [x0]
    1aa8: 4d4091b1     	ld1.s	{ v17 }[3], [x13]
    1aac: 6e31de31     	fmul.4s	v17, v17, v17
    1ab0: 3dc067f3     	ldr	q19, [sp, #0x190]
    1ab4: 4e183e6c     	mov.d	x12, v19[1]
    1ab8: 9e66026d     	fmov	x13, d19
    1abc: 3dc06bf3     	ldr	q19, [sp, #0x1a0]
    1ac0: 9e660260     	fmov	x0, d19
    1ac4: 4e183e61     	mov.d	x1, v19[1]
    1ac8: 4e183da3     	mov.d	x3, v13[1]
    1acc: 9e6601a4     	fmov	x4, d13
    1ad0: 4e183d85     	mov.d	x5, v12[1]
    1ad4: bd400094     	ldr	s20, [x4]
    1ad8: 0d409074     	ld1.s	{ v20 }[1], [x3]
    1adc: 9e660183     	fmov	x3, d12
    1ae0: 4d408074     	ld1.s	{ v20 }[2], [x3]
    1ae4: 4d4090b4     	ld1.s	{ v20 }[3], [x5]
    1ae8: bd4001b5     	ldr	s21, [x13]
    1aec: 0d409195     	ld1.s	{ v21 }[1], [x12]
    1af0: 4d408015     	ld1.s	{ v21 }[2], [x0]
    1af4: 4d409035     	ld1.s	{ v21 }[3], [x1]
    1af8: 6e32de53     	fmul.4s	v19, v18, v18
    1afc: 6e35deb2     	fmul.4s	v18, v21, v21
    1b00: ad4adff8     	ldp	q24, q23, [sp, #0x150]
    1b04: 4e183f0c     	mov.d	x12, v24[1]
    1b08: 4e183eed     	mov.d	x13, v23[1]
    1b0c: 6e34de94     	fmul.4s	v20, v20, v20
    1b10: 3dc05ff5     	ldr	q21, [sp, #0x170]
    1b14: 9e6602a0     	fmov	x0, d21
    1b18: 4e183ea1     	mov.d	x1, v21[1]
    1b1c: 3dc063f5     	ldr	q21, [sp, #0x180]
    1b20: 4e183ea3     	mov.d	x3, v21[1]
    1b24: 9e6602a4     	fmov	x4, d21
    1b28: bd400016     	ldr	s22, [x0]
    1b2c: 0d409036     	ld1.s	{ v22 }[1], [x1]
    1b30: 4d408096     	ld1.s	{ v22 }[2], [x4]
    1b34: 9e660300     	fmov	x0, d24
    1b38: 4d409076     	ld1.s	{ v22 }[3], [x3]
    1b3c: bd400015     	ldr	s21, [x0]
    1b40: 0d409195     	ld1.s	{ v21 }[1], [x12]
    1b44: 9e6602ec     	fmov	x12, d23
    1b48: 4d408195     	ld1.s	{ v21 }[2], [x12]
    1b4c: 4d4091b5     	ld1.s	{ v21 }[3], [x13]
    1b50: 6e35deb5     	fmul.4s	v21, v21, v21
    1b54: 6e36ded6     	fmul.4s	v22, v22, v22
    1b58: 3dc047f7     	ldr	q23, [sp, #0x110]
    1b5c: 9e6602ec     	fmov	x12, d23
    1b60: 4e183eed     	mov.d	x13, v23[1]
    1b64: 3dc04bf7     	ldr	q23, [sp, #0x120]
    1b68: 4e183ee0     	mov.d	x0, v23[1]
    1b6c: 9e6602e1     	fmov	x1, d23
    1b70: ad49e7f7     	ldp	q23, q25, [sp, #0x130]
    1b74: 9e6602e3     	fmov	x3, d23
    1b78: 4e183ee4     	mov.d	x4, v23[1]
    1b7c: 4e183f25     	mov.d	x5, v25[1]
    1b80: bd400078     	ldr	s24, [x3]
    1b84: 0d409098     	ld1.s	{ v24 }[1], [x4]
    1b88: bd400197     	ldr	s23, [x12]
    1b8c: 0d4091b7     	ld1.s	{ v23 }[1], [x13]
    1b90: 9e66032c     	fmov	x12, d25
    1b94: 4d408037     	ld1.s	{ v23 }[2], [x1]
    1b98: 4d409017     	ld1.s	{ v23 }[3], [x0]
    1b9c: 6e37def7     	fmul.4s	v23, v23, v23
    1ba0: 4d408198     	ld1.s	{ v24 }[2], [x12]
    1ba4: 4d4090b8     	ld1.s	{ v24 }[3], [x5]
    1ba8: 6e38df18     	fmul.4s	v24, v24, v24
    1bac: 52800383     	mov	w3, #0x1c               ; =28
    1bb0: d100306c     	sub	x12, x3, #0xc
    1bb4: 4e080d99     	dup.2d	v25, x12
    1bb8: 4ef98439     	add.2d	v25, v1, v25
    1bbc: 4ee0873a     	add.2d	v26, v25, v0
    1bc0: 4ee3873b     	add.2d	v27, v25, v3
    1bc4: 4ee5873c     	add.2d	v28, v25, v5
    1bc8: 4ee78739     	add.2d	v25, v25, v7
    1bcc: 4e183f2d     	mov.d	x13, v25[1]
    1bd0: 9e660321     	fmov	x1, d25
    1bd4: 4e183f85     	mov.d	x5, v28[1]
    1bd8: 9e660380     	fmov	x0, d28
    1bdc: 4e183f64     	mov.d	x4, v27[1]
    1be0: 9e660367     	fmov	x7, d27
    1be4: 4e183f46     	mov.d	x6, v26[1]
    1be8: 9e66034c     	fmov	x12, d26
    1bec: d1002073     	sub	x19, x3, #0x8
    1bf0: bd4000f9     	ldr	s25, [x7]
    1bf4: 4e080e7a     	dup.2d	v26, x19
    1bf8: 4efa843b     	add.2d	v27, v1, v26
    1bfc: 4ee0877d     	add.2d	v29, v27, v0
    1c00: 4ee3877c     	add.2d	v28, v27, v3
    1c04: bd40003a     	ldr	s26, [x1]
    1c08: 4ee5877e     	add.2d	v30, v27, v5
    1c0c: 4ee7877b     	add.2d	v27, v27, v7
    1c10: 4e183f67     	mov.d	x7, v27[1]
    1c14: 0d409099     	ld1.s	{ v25 }[1], [x4]
    1c18: 4e183fc4     	mov.d	x4, v30[1]
    1c1c: 4e183f81     	mov.d	x1, v28[1]
    1c20: 0d4091ba     	ld1.s	{ v26 }[1], [x13]
    1c24: 9e66036d     	fmov	x13, d27
    1c28: 9e660393     	fmov	x19, d28
    1c2c: bd40027b     	ldr	s27, [x19]
    1c30: 9e6603d3     	fmov	x19, d30
    1c34: 0d40903b     	ld1.s	{ v27 }[1], [x1]
    1c38: 4e183fa1     	mov.d	x1, v29[1]
    1c3c: bd4001bc     	ldr	s28, [x13]
    1c40: d100106d     	sub	x13, x3, #0x4
    1c44: 0d4090fc     	ld1.s	{ v28 }[1], [x7]
    1c48: 4e080dbe     	dup.2d	v30, x13
    1c4c: 9e6603ad     	fmov	x13, d29
    1c50: 4efe843d     	add.2d	v29, v1, v30
    1c54: 4d408199     	ld1.s	{ v25 }[2], [x12]
    1c58: 4ee087be     	add.2d	v30, v29, v0
    1c5c: 4ee387a8     	add.2d	v8, v29, v3
    1c60: 4ee587a9     	add.2d	v9, v29, v5
    1c64: 4ee787bd     	add.2d	v29, v29, v7
    1c68: 4d40801a     	ld1.s	{ v26 }[2], [x0]
    1c6c: 4e183fac     	mov.d	x12, v29[1]
    1c70: 4e183d00     	mov.d	x0, v8[1]
    1c74: 4d4081bb     	ld1.s	{ v27 }[2], [x13]
    1c78: 9e66010d     	fmov	x13, d8
    1c7c: bd4001a8     	ldr	s8, [x13]
    1c80: 4e183fcd     	mov.d	x13, v30[1]
    1c84: 4d40827c     	ld1.s	{ v28 }[2], [x19]
    1c88: 9e6603a7     	fmov	x7, d29
    1c8c: 0d409008     	ld1.s	{ v8 }[1], [x0]
    1c90: 9e6603c0     	fmov	x0, d30
    1c94: 4d408008     	ld1.s	{ v8 }[2], [x0]
    1c98: 4e183d20     	mov.d	x0, v9[1]
    1c9c: bd4000fd     	ldr	s29, [x7]
    1ca0: 9e660127     	fmov	x7, d9
    1ca4: 4d4090d9     	ld1.s	{ v25 }[3], [x6]
    1ca8: 0d40919d     	ld1.s	{ v29 }[1], [x12]
    1cac: 4e080c7e     	dup.2d	v30, x3
    1cb0: 4d4090ba     	ld1.s	{ v26 }[3], [x5]
    1cb4: 4efe843e     	add.2d	v30, v1, v30
    1cb8: 4ee787c9     	add.2d	v9, v30, v7
    1cbc: 4e183d2c     	mov.d	x12, v9[1]
    1cc0: 4d40903b     	ld1.s	{ v27 }[3], [x1]
    1cc4: 9e660121     	fmov	x1, d9
    1cc8: 4ee587c9     	add.2d	v9, v30, v5
    1ccc: 4e183d25     	mov.d	x5, v9[1]
    1cd0: 4d40909c     	ld1.s	{ v28 }[3], [x4]
    1cd4: 9e660124     	fmov	x4, d9
    1cd8: 4ee387c9     	add.2d	v9, v30, v3
    1cdc: 4e183d26     	mov.d	x6, v9[1]
    1ce0: 4d4091a8     	ld1.s	{ v8 }[3], [x13]
    1ce4: 9e66012d     	fmov	x13, d9
    1ce8: 6e3adf5a     	fmul.4s	v26, v26, v26
    1cec: 6e39df39     	fmul.4s	v25, v25, v25
    1cf0: 4d4080fd     	ld1.s	{ v29 }[2], [x7]
    1cf4: 4e39d673     	fadd.4s	v19, v19, v25
    1cf8: 4d40901d     	ld1.s	{ v29 }[3], [x0]
    1cfc: 4ee087d9     	add.2d	v25, v30, v0
    1d00: 4e183f20     	mov.d	x0, v25[1]
    1d04: 4e3ad631     	fadd.4s	v17, v17, v26
    1d08: 9e660327     	fmov	x7, d25
    1d0c: 6e3cdf99     	fmul.4s	v25, v28, v28
    1d10: 6e3bdf7a     	fmul.4s	v26, v27, v27
    1d14: 6e3ddfbb     	fmul.4s	v27, v29, v29
    1d18: 6e28dd1c     	fmul.4s	v28, v8, v8
    1d1c: 4e3ad694     	fadd.4s	v20, v20, v26
    1d20: bd4001ba     	ldr	s26, [x13]
    1d24: 0d4090da     	ld1.s	{ v26 }[1], [x6]
    1d28: 4d4080fa     	ld1.s	{ v26 }[2], [x7]
    1d2c: 4e39d652     	fadd.4s	v18, v18, v25
    1d30: 4d40901a     	ld1.s	{ v26 }[3], [x0]
    1d34: bd400039     	ldr	s25, [x1]
    1d38: 0d409199     	ld1.s	{ v25 }[1], [x12]
    1d3c: 4e3cd6d6     	fadd.4s	v22, v22, v28
    1d40: 4d408099     	ld1.s	{ v25 }[2], [x4]
    1d44: 4d4090b9     	ld1.s	{ v25 }[3], [x5]
    1d48: 6e39df39     	fmul.4s	v25, v25, v25
    1d4c: 4e3bd6b5     	fadd.4s	v21, v21, v27
    1d50: 6e3adf5a     	fmul.4s	v26, v26, v26
    1d54: 4e3ad718     	fadd.4s	v24, v24, v26
    1d58: 4e39d6f7     	fadd.4s	v23, v23, v25
    1d5c: 9100114a     	add	x10, x10, #0x4
    1d60: 91004063     	add	x3, x3, #0x10
    1d64: f103f15f     	cmp	x10, #0xfc
    1d68: 54fff243     	b.lo	0x1bb0 <ltmp0+0x1bb0>
    1d6c: d280000a     	mov	x10, #0x0               ; =0
    1d70: bc6a6a19     	ldr	s25, [x16, x10]
    1d74: 4e080d5a     	dup.2d	v26, x10
    1d78: 4efa87fa     	add.2d	v26, v31, v26
    1d7c: 4ee0875b     	add.2d	v27, v26, v0
    1d80: 4ee3875c     	add.2d	v28, v26, v3
    1d84: 4ee5875d     	add.2d	v29, v26, v5
    1d88: 4ee7875a     	add.2d	v26, v26, v7
    1d8c: 4e183f4c     	mov.d	x12, v26[1]
    1d90: 9e66034d     	fmov	x13, d26
    1d94: bd0001b9     	str	s25, [x13]
    1d98: bd000199     	str	s25, [x12]
    1d9c: 4e183fac     	mov.d	x12, v29[1]
    1da0: 9e6603ad     	fmov	x13, d29
    1da4: bd0001b9     	str	s25, [x13]
    1da8: bd000199     	str	s25, [x12]
    1dac: 4e183f8c     	mov.d	x12, v28[1]
    1db0: 9e66038d     	fmov	x13, d28
    1db4: bd0001b9     	str	s25, [x13]
    1db8: 4e183f6d     	mov.d	x13, v27[1]
    1dbc: bd000199     	str	s25, [x12]
    1dc0: 9e66036c     	fmov	x12, d27
    1dc4: bd000199     	str	s25, [x12]
    1dc8: bd0001b9     	str	s25, [x13]
    1dcc: 9100114a     	add	x10, x10, #0x4
    1dd0: f110015f     	cmp	x10, #0x400
    1dd4: 54fffce1     	b.ne	0x1d70 <ltmp0+0x1d70>
    1dd8: d280000a     	mov	x10, #0x0               ; =0
    1ddc: 4e34d673     	fadd.4s	v19, v19, v20
    1de0: 4e32d631     	fadd.4s	v17, v17, v18
    1de4: 4e35d631     	fadd.4s	v17, v17, v21
    1de8: 4e36d672     	fadd.4s	v18, v19, v22
    1dec: 4e38d652     	fadd.4s	v18, v18, v24
    1df0: 4e37d631     	fadd.4s	v17, v17, v23
    1df4: ad4dcff4     	ldp	q20, q19, [sp, #0x1b0]
    1df8: 6e34de31     	fmul.4s	v17, v17, v20
    1dfc: 6e34de52     	fmul.4s	v18, v18, v20
    1e00: 4e33d652     	fadd.4s	v18, v18, v19
    1e04: 4e33d631     	fadd.4s	v17, v17, v19
    1e08: 6ea1fa31     	fsqrt.4s	v17, v17
    1e0c: 6ea1fa52     	fsqrt.4s	v18, v18
    1e10: 4e080d53     	dup.2d	v19, x10
    1e14: 4ea71e74     	orr.16b	v20, v19, v7
    1e18: 4ea51e75     	orr.16b	v21, v19, v5
    1e1c: 4ea31e76     	orr.16b	v22, v19, v3
    1e20: 4ea01e77     	orr.16b	v23, v19, v0
    1e24: 4ef78438     	add.2d	v24, v1, v23
    1e28: 4ef68439     	add.2d	v25, v1, v22
    1e2c: 4ef5843a     	add.2d	v26, v1, v21
    1e30: 4ef4843b     	add.2d	v27, v1, v20
    1e34: 4e183f6c     	mov.d	x12, v27[1]
    1e38: 9e66036d     	fmov	x13, d27
    1e3c: 4e183f40     	mov.d	x0, v26[1]
    1e40: 9e660341     	fmov	x1, d26
    1e44: 4e183f23     	mov.d	x3, v25[1]
    1e48: 9e660324     	fmov	x4, d25
    1e4c: 4e183f05     	mov.d	x5, v24[1]
    1e50: bd400099     	ldr	s25, [x4]
    1e54: 0d409079     	ld1.s	{ v25 }[1], [x3]
    1e58: 9e660303     	fmov	x3, d24
    1e5c: 4d408079     	ld1.s	{ v25 }[2], [x3]
    1e60: 4d4090b9     	ld1.s	{ v25 }[3], [x5]
    1e64: bd4001b8     	ldr	s24, [x13]
    1e68: 0d409198     	ld1.s	{ v24 }[1], [x12]
    1e6c: 4d408038     	ld1.s	{ v24 }[2], [x1]
    1e70: 4d409018     	ld1.s	{ v24 }[3], [x0]
    1e74: 6e31ff18     	fdiv.4s	v24, v24, v17
    1e78: 6e32ff39     	fdiv.4s	v25, v25, v18
    1e7c: 4ef787f7     	add.2d	v23, v31, v23
    1e80: 4ef687f6     	add.2d	v22, v31, v22
    1e84: 4ef587f5     	add.2d	v21, v31, v21
    1e88: 4ef487f4     	add.2d	v20, v31, v20
    1e8c: 4e183e8c     	mov.d	x12, v20[1]
    1e90: 9e66028d     	fmov	x13, d20
    1e94: 4e183ea0     	mov.d	x0, v21[1]
    1e98: 9e6602a1     	fmov	x1, d21
    1e9c: 4e183ec3     	mov.d	x3, v22[1]
    1ea0: 9e6602c4     	fmov	x4, d22
    1ea4: 4e183ee5     	mov.d	x5, v23[1]
    1ea8: bd4001b4     	ldr	s20, [x13]
    1eac: 0d409194     	ld1.s	{ v20 }[1], [x12]
    1eb0: 4d408034     	ld1.s	{ v20 }[2], [x1]
    1eb4: 4d409014     	ld1.s	{ v20 }[3], [x0]
    1eb8: 9e6602ec     	fmov	x12, d23
    1ebc: bd400095     	ldr	s21, [x4]
    1ec0: 0d409075     	ld1.s	{ v21 }[1], [x3]
    1ec4: 4d408195     	ld1.s	{ v21 }[2], [x12]
    1ec8: 4d4090b5     	ld1.s	{ v21 }[3], [x5]
    1ecc: 6e35df35     	fmul.4s	v21, v25, v21
    1ed0: 6e34df14     	fmul.4s	v20, v24, v20
    1ed4: 4ef08676     	add.2d	v22, v19, v16
    1ed8: 4ee48677     	add.2d	v23, v19, v4
    1edc: 4ee68678     	add.2d	v24, v19, v6
    1ee0: 4ee28673     	add.2d	v19, v19, v2
    1ee4: 4e080c59     	dup.2d	v25, x2
    1ee8: 4ef38733     	add.2d	v19, v25, v19
    1eec: 4ef68736     	add.2d	v22, v25, v22
    1ef0: 4e183ecc     	mov.d	x12, v22[1]
    1ef4: 9e6602cd     	fmov	x13, d22
    1ef8: bd0001b4     	str	s20, [x13]
    1efc: 0d009194     	st1.s	{ v20 }[1], [x12]
    1f00: 4ef78736     	add.2d	v22, v25, v23
    1f04: 4e183ecc     	mov.d	x12, v22[1]
    1f08: 9e6602cd     	fmov	x13, d22
    1f0c: 4d0081b4     	st1.s	{ v20 }[2], [x13]
    1f10: 4ef88736     	add.2d	v22, v25, v24
    1f14: 4d009194     	st1.s	{ v20 }[3], [x12]
    1f18: 4e183ecc     	mov.d	x12, v22[1]
    1f1c: 9e6602cd     	fmov	x13, d22
    1f20: bd0001b5     	str	s21, [x13]
    1f24: 0d009195     	st1.s	{ v21 }[1], [x12]
    1f28: 4e183e6c     	mov.d	x12, v19[1]
    1f2c: 9e66026d     	fmov	x13, d19
    1f30: 4d0081b5     	st1.s	{ v21 }[2], [x13]
    1f34: 4d009195     	st1.s	{ v21 }[3], [x12]
    1f38: 9100114a     	add	x10, x10, #0x4
    1f3c: f110015f     	cmp	x10, #0x400
    1f40: 54fff681     	b.ne	0x1e10 <ltmp0+0x1e10>
    1f44: 110005ce     	add	w14, w14, #0x1
    1f48: 6b0b01df     	cmp	w14, w11
    1f4c: 54ffd0c1     	b.ne	0x1964 <ltmp0+0x1964>
    1f50: 12000929     	and	w9, w9, #0x7
    1f54: 9000000d     	adrp	x13, 0x1000 <ltmp0+0x1000>
    1f58: 34ff11a9     	cbz	w9, 0x18c <ltmp0+0x18c>
    1f5c: aa1603ef     	mov	x15, x22
    1f60: 4e040d22     	dup.4s	v2, w9
    1f64: 90000009     	adrp	x9, 0x1000 <ltmp0+0x1000>
    1f68: 3dc00124     	ldr	q4, [x9]
    1f6c: 90000009     	adrp	x9, 0x1000 <ltmp0+0x1000>
    1f70: 3dc00126     	ldr	q6, [x9]
    1f74: 6ea6345c     	cmhi.4s	v28, v2, v6
    1f78: 6ea43452     	cmhi.4s	v18, v2, v4
    1f7c: 4e5c1a42     	uzp1.8h	v2, v18, v28
    1f80: 6e70a844     	umaxv.8h	h4, v2
    1f84: 1e260089     	fmov	w9, s4
    1f88: 36070fa9     	tbz	w9, #0x0, 0x17c <ltmp0+0x17c>
    1f8c: d280000a     	mov	x10, #0x0               ; =0
    1f90: f9404bec     	ldr	x12, [sp, #0x90]
    1f94: f940018e     	ldr	x14, [x12]
    1f98: f9400989     	ldr	x9, [x12, #0x10]
    1f9c: 531d716b     	lsl	w11, w11, #3
    1fa0: 2a18156b     	orr	w11, w11, w24, lsl #5
    1fa4: 4e040d64     	dup.4s	v4, w11
    1fa8: f9401996     	ldr	x22, [x12, #0x30]
    1fac: 0f20a646     	sshll.2d	v6, v18, #0x0
    1fb0: 0f20a790     	sshll.2d	v16, v28, #0x0
    1fb4: 4f20a651     	sshll2.2d	v17, v18, #0x0
    1fb8: 4f20a793     	sshll2.2d	v19, v28, #0x0
    1fbc: 4f2a5484     	shl.4s	v4, v4, #0xa
    1fc0: 4e211e6a     	and.16b	v10, v19, v1
    1fc4: 4e211e2b     	and.16b	v11, v17, v1
    1fc8: 4e211e0c     	and.16b	v12, v16, v1
    1fcc: 4e211ccd     	and.16b	v13, v6, v1
    1fd0: ad01c7f3     	stp	q19, q17, [sp, #0x30]
    1fd4: 4e201e6e     	and.16b	v14, v19, v0
    1fd8: 4e251e2f     	and.16b	v15, v17, v5
    1fdc: 4e231e1d     	and.16b	v29, v16, v3
    1fe0: 4e271cde     	and.16b	v30, v6, v7
    1fe4: 3dc00346     	ldr	q6, [x26]
    1fe8: 4ea61c86     	orr.16b	v6, v4, v6
    1fec: 3dc00330     	ldr	q16, [x25]
    1ff0: 4eb01c84     	orr.16b	v4, v4, v16
    1ff4: 4f072791     	movi.4s	v17, #0xfc, lsl #8
    1ff8: 3d803ff2     	str	q18, [sp, #0xf0]
    1ffc: 4e311e50     	and.16b	v16, v18, v17
    2000: 4e301cc6     	and.16b	v6, v6, v16
    2004: 4e311f90     	and.16b	v16, v28, v17
    2008: 4e301c84     	and.16b	v4, v4, v16
    200c: 6f20a493     	ushll2.2d	v19, v4, #0x0
    2010: 6f20a4db     	ushll2.2d	v27, v6, #0x0
    2014: 2f20a484     	ushll.2d	v4, v4, #0x0
    2018: 3d807be4     	str	q4, [sp, #0x1e0]
    201c: 2f20a4c4     	ushll.2d	v4, v6, #0x0
    2020: 3d8077e4     	str	q4, [sp, #0x1d0]
    2024: 14000004     	b	0x2034 <ltmp0+0x2034>
    2028: 9100114a     	add	x10, x10, #0x4
    202c: f110015f     	cmp	x10, #0x400
    2030: 54000e20     	b.eq	0x21f4 <ltmp0+0x21f4>
    2034: 3dc001a4     	ldr	q4, [x13]
    2038: 4e241c44     	and.16b	v4, v2, v4
    203c: 4e71b891     	addv.8h	h17, v4
    2040: 1e26022b     	fmov	w11, s17
    2044: 4e080d46     	dup.2d	v6, x10
    2048: 3dc077e4     	ldr	q4, [sp, #0x1d0]
    204c: 4ee484c4     	add.2d	v4, v6, v4
    2050: 4e080dd0     	dup.2d	v16, x14
    2054: 4ee48612     	add.2d	v18, v16, v4
    2058: 6f00e414     	movi.2d	v20, #0000000000000000
    205c: 6f00e404     	movi.2d	v4, #0000000000000000
    2060: 3700046b     	tbnz	w11, #0x0, 0x20ec <ltmp0+0x20ec>
    2064: 12001d6b     	and	w11, w11, #0xff
    2068: 370804ab     	tbnz	w11, #0x1, 0x20fc <ltmp0+0x20fc>
    206c: 4efb84d2     	add.2d	v18, v6, v27
    2070: 4ef28612     	add.2d	v18, v16, v18
    2074: 371004eb     	tbnz	w11, #0x2, 0x2110 <ltmp0+0x2110>
    2078: 3718052b     	tbnz	w11, #0x3, 0x211c <ltmp0+0x211c>
    207c: 3dc07bf2     	ldr	q18, [sp, #0x1e0]
    2080: 4ef284d2     	add.2d	v18, v6, v18
    2084: 4ef28612     	add.2d	v18, v16, v18
    2088: 3720056b     	tbnz	w11, #0x4, 0x2134 <ltmp0+0x2134>
    208c: 372805ab     	tbnz	w11, #0x5, 0x2140 <ltmp0+0x2140>
    2090: 4ef384d2     	add.2d	v18, v6, v19
    2094: 4ef28610     	add.2d	v16, v16, v18
    2098: 373005eb     	tbnz	w11, #0x6, 0x2154 <ltmp0+0x2154>
    209c: 3738062b     	tbnz	w11, #0x7, 0x2160 <ltmp0+0x2160>
    20a0: 1e26022b     	fmov	w11, s17
    20a4: 4ebe1cd0     	orr.16b	v16, v6, v30
    20a8: 4ef085b0     	add.2d	v16, v13, v16
    20ac: 3700066b     	tbnz	w11, #0x0, 0x2178 <ltmp0+0x2178>
    20b0: 12001d6b     	and	w11, w11, #0xff
    20b4: 370806ab     	tbnz	w11, #0x1, 0x2188 <ltmp0+0x2188>
    20b8: 4eaf1cd0     	orr.16b	v16, v6, v15
    20bc: 4ef08570     	add.2d	v16, v11, v16
    20c0: 371006eb     	tbnz	w11, #0x2, 0x219c <ltmp0+0x219c>
    20c4: 3718072b     	tbnz	w11, #0x3, 0x21a8 <ltmp0+0x21a8>
    20c8: 4ebd1cd0     	orr.16b	v16, v6, v29
    20cc: 4ef08590     	add.2d	v16, v12, v16
    20d0: 3720076b     	tbnz	w11, #0x4, 0x21bc <ltmp0+0x21bc>
    20d4: 372807ab     	tbnz	w11, #0x5, 0x21c8 <ltmp0+0x21c8>
    20d8: 4eae1cc6     	orr.16b	v6, v6, v14
    20dc: 4ee68546     	add.2d	v6, v10, v6
    20e0: 373007eb     	tbnz	w11, #0x6, 0x21dc <ltmp0+0x21dc>
    20e4: 363ffa2b     	tbz	w11, #0x7, 0x2028 <ltmp0+0x2028>
    20e8: 14000040     	b	0x21e8 <ltmp0+0x21e8>
    20ec: 9e66024c     	fmov	x12, d18
    20f0: bd400194     	ldr	s20, [x12]
    20f4: 12001d6b     	and	w11, w11, #0xff
    20f8: 360ffbab     	tbz	w11, #0x1, 0x206c <ltmp0+0x206c>
    20fc: 4e183e4c     	mov.d	x12, v18[1]
    2100: 0d409194     	ld1.s	{ v20 }[1], [x12]
    2104: 4efb84d2     	add.2d	v18, v6, v27
    2108: 4ef28612     	add.2d	v18, v16, v18
    210c: 3617fb6b     	tbz	w11, #0x2, 0x2078 <ltmp0+0x2078>
    2110: 9e66024c     	fmov	x12, d18
    2114: 4d408194     	ld1.s	{ v20 }[2], [x12]
    2118: 361ffb2b     	tbz	w11, #0x3, 0x207c <ltmp0+0x207c>
    211c: 4e183e4c     	mov.d	x12, v18[1]
    2120: 4d409194     	ld1.s	{ v20 }[3], [x12]
    2124: 3dc07bf2     	ldr	q18, [sp, #0x1e0]
    2128: 4ef284d2     	add.2d	v18, v6, v18
    212c: 4ef28612     	add.2d	v18, v16, v18
    2130: 3627faeb     	tbz	w11, #0x4, 0x208c <ltmp0+0x208c>
    2134: 9e66024c     	fmov	x12, d18
    2138: 0d408184     	ld1.s	{ v4 }[0], [x12]
    213c: 362ffaab     	tbz	w11, #0x5, 0x2090 <ltmp0+0x2090>
    2140: 4e183e4c     	mov.d	x12, v18[1]
    2144: 0d409184     	ld1.s	{ v4 }[1], [x12]
    2148: 4ef384d2     	add.2d	v18, v6, v19
    214c: 4ef28610     	add.2d	v16, v16, v18
    2150: 3637fa6b     	tbz	w11, #0x6, 0x209c <ltmp0+0x209c>
    2154: 9e66020c     	fmov	x12, d16
    2158: 4d408184     	ld1.s	{ v4 }[2], [x12]
    215c: 363ffa2b     	tbz	w11, #0x7, 0x20a0 <ltmp0+0x20a0>
    2160: 4e183e0b     	mov.d	x11, v16[1]
    2164: 4d409164     	ld1.s	{ v4 }[3], [x11]
    2168: 1e26022b     	fmov	w11, s17
    216c: 4ebe1cd0     	orr.16b	v16, v6, v30
    2170: 4ef085b0     	add.2d	v16, v13, v16
    2174: 3607f9eb     	tbz	w11, #0x0, 0x20b0 <ltmp0+0x20b0>
    2178: 9e66020c     	fmov	x12, d16
    217c: bd000194     	str	s20, [x12]
    2180: 12001d6b     	and	w11, w11, #0xff
    2184: 360ff9ab     	tbz	w11, #0x1, 0x20b8 <ltmp0+0x20b8>
    2188: 4e183e0c     	mov.d	x12, v16[1]
    218c: 0d009194     	st1.s	{ v20 }[1], [x12]
    2190: 4eaf1cd0     	orr.16b	v16, v6, v15
    2194: 4ef08570     	add.2d	v16, v11, v16
    2198: 3617f96b     	tbz	w11, #0x2, 0x20c4 <ltmp0+0x20c4>
    219c: 9e66020c     	fmov	x12, d16
    21a0: 4d008194     	st1.s	{ v20 }[2], [x12]
    21a4: 361ff92b     	tbz	w11, #0x3, 0x20c8 <ltmp0+0x20c8>
    21a8: 4e183e0c     	mov.d	x12, v16[1]
    21ac: 4d009194     	st1.s	{ v20 }[3], [x12]
    21b0: 4ebd1cd0     	orr.16b	v16, v6, v29
    21b4: 4ef08590     	add.2d	v16, v12, v16
    21b8: 3627f8eb     	tbz	w11, #0x4, 0x20d4 <ltmp0+0x20d4>
    21bc: 9e66020c     	fmov	x12, d16
    21c0: bd000184     	str	s4, [x12]
    21c4: 362ff8ab     	tbz	w11, #0x5, 0x20d8 <ltmp0+0x20d8>
    21c8: 4e183e0c     	mov.d	x12, v16[1]
    21cc: 0d009184     	st1.s	{ v4 }[1], [x12]
    21d0: 4eae1cc6     	orr.16b	v6, v6, v14
    21d4: 4ee68546     	add.2d	v6, v10, v6
    21d8: 3637f86b     	tbz	w11, #0x6, 0x20e4 <ltmp0+0x20e4>
    21dc: 9e6600cc     	fmov	x12, d6
    21e0: 4d008184     	st1.s	{ v4 }[2], [x12]
    21e4: 363ff22b     	tbz	w11, #0x7, 0x2028 <ltmp0+0x2028>
    21e8: 4e183ccb     	mov.d	x11, v6[1]
    21ec: 4d009164     	st1.s	{ v4 }[3], [x11]
    21f0: 17ffff8e     	b	0x2028 <ltmp0+0x2028>
    21f4: 1e26022a     	fmov	w10, s17
    21f8: 4efe85a2     	add.2d	v2, v13, v30
    21fc: 6f00e414     	movi.2d	v20, #0000000000000000
    2200: 6f00e415     	movi.2d	v21, #0000000000000000
    2204: 370049ca     	tbnz	w10, #0x0, 0x2b3c <ltmp0+0x2b3c>
    2208: 12001d4a     	and	w10, w10, #0xff
    220c: 37084a0a     	tbnz	w10, #0x1, 0x2b4c <ltmp0+0x2b4c>
    2210: 4eef8576     	add.2d	v22, v11, v15
    2214: 37104a4a     	tbnz	w10, #0x2, 0x2b5c <ltmp0+0x2b5c>
    2218: 37184a8a     	tbnz	w10, #0x3, 0x2b68 <ltmp0+0x2b68>
    221c: 4efd8597     	add.2d	v23, v12, v29
    2220: 37204aca     	tbnz	w10, #0x4, 0x2b78 <ltmp0+0x2b78>
    2224: 37284b0a     	tbnz	w10, #0x5, 0x2b84 <ltmp0+0x2b84>
    2228: 4eee8558     	add.2d	v24, v10, v14
    222c: 37304b4a     	tbnz	w10, #0x6, 0x2b94 <ltmp0+0x2b94>
    2230: 3d801bf3     	str	q19, [sp, #0x60]
    2234: 3638006a     	tbz	w10, #0x7, 0x2240 <ltmp0+0x2240>
    2238: 4e183f0a     	mov.d	x10, v24[1]
    223c: 4d409155     	ld1.s	{ v21 }[3], [x10]
    2240: 1e26022a     	fmov	w10, s17
    2244: 5280008b     	mov	w11, #0x4               ; =4
    2248: 4e080d64     	dup.2d	v4, x11
    224c: 4ee48446     	add.2d	v6, v2, v4
    2250: 6f00e419     	movi.2d	v25, #0000000000000000
    2254: 6f00e41a     	movi.2d	v26, #0000000000000000
    2258: 37004a8a     	tbnz	w10, #0x0, 0x2ba8 <ltmp0+0x2ba8>
    225c: 12001d4a     	and	w10, w10, #0xff
    2260: 37084aca     	tbnz	w10, #0x1, 0x2bb8 <ltmp0+0x2bb8>
    2264: 4ee486c6     	add.2d	v6, v22, v4
    2268: 37104b0a     	tbnz	w10, #0x2, 0x2bc8 <ltmp0+0x2bc8>
    226c: 37184b4a     	tbnz	w10, #0x3, 0x2bd4 <ltmp0+0x2bd4>
    2270: 4ee486e6     	add.2d	v6, v23, v4
    2274: 37204b8a     	tbnz	w10, #0x4, 0x2be4 <ltmp0+0x2be4>
    2278: 37284bca     	tbnz	w10, #0x5, 0x2bf0 <ltmp0+0x2bf0>
    227c: 4ee48704     	add.2d	v4, v24, v4
    2280: 37304c0a     	tbnz	w10, #0x6, 0x2c00 <ltmp0+0x2c00>
    2284: 3638006a     	tbz	w10, #0x7, 0x2290 <ltmp0+0x2290>
    2288: 4e183c8a     	mov.d	x10, v4[1]
    228c: 4d40915a     	ld1.s	{ v26 }[3], [x10]
    2290: 1e26022a     	fmov	w10, s17
    2294: 5280010b     	mov	w11, #0x8               ; =8
    2298: 4e080d70     	dup.2d	v16, x11
    229c: 4ef08452     	add.2d	v18, v2, v16
    22a0: 6f00e404     	movi.2d	v4, #0000000000000000
    22a4: 6f00e406     	movi.2d	v6, #0000000000000000
    22a8: 37004b4a     	tbnz	w10, #0x0, 0x2c10 <ltmp0+0x2c10>
    22ac: 12001d4a     	and	w10, w10, #0xff
    22b0: 37084b8a     	tbnz	w10, #0x1, 0x2c20 <ltmp0+0x2c20>
    22b4: 4ef086d2     	add.2d	v18, v22, v16
    22b8: 37104bca     	tbnz	w10, #0x2, 0x2c30 <ltmp0+0x2c30>
    22bc: 37184c0a     	tbnz	w10, #0x3, 0x2c3c <ltmp0+0x2c3c>
    22c0: 4ef086f2     	add.2d	v18, v23, v16
    22c4: 37204c4a     	tbnz	w10, #0x4, 0x2c4c <ltmp0+0x2c4c>
    22c8: 37284c8a     	tbnz	w10, #0x5, 0x2c58 <ltmp0+0x2c58>
    22cc: 4ef08710     	add.2d	v16, v24, v16
    22d0: 37304cca     	tbnz	w10, #0x6, 0x2c68 <ltmp0+0x2c68>
    22d4: 3638006a     	tbz	w10, #0x7, 0x22e0 <ltmp0+0x22e0>
    22d8: 4e183e0a     	mov.d	x10, v16[1]
    22dc: 4d409146     	ld1.s	{ v6 }[3], [x10]
    22e0: 1e26022a     	fmov	w10, s17
    22e4: 5280018b     	mov	w11, #0xc               ; =12
    22e8: 4e080d72     	dup.2d	v18, x11
    22ec: 4ef28453     	add.2d	v19, v2, v18
    22f0: 6f00e402     	movi.2d	v2, #0000000000000000
    22f4: 6f00e410     	movi.2d	v16, #0000000000000000
    22f8: 37004c0a     	tbnz	w10, #0x0, 0x2c78 <ltmp0+0x2c78>
    22fc: 12001d4a     	and	w10, w10, #0xff
    2300: 37084c4a     	tbnz	w10, #0x1, 0x2c88 <ltmp0+0x2c88>
    2304: 4ef286d3     	add.2d	v19, v22, v18
    2308: 37104c8a     	tbnz	w10, #0x2, 0x2c98 <ltmp0+0x2c98>
    230c: 37184cca     	tbnz	w10, #0x3, 0x2ca4 <ltmp0+0x2ca4>
    2310: 4ef286f3     	add.2d	v19, v23, v18
    2314: 37204d0a     	tbnz	w10, #0x4, 0x2cb4 <ltmp0+0x2cb4>
    2318: 37284d4a     	tbnz	w10, #0x5, 0x2cc0 <ltmp0+0x2cc0>
    231c: 4ef28712     	add.2d	v18, v24, v18
    2320: 37304d8a     	tbnz	w10, #0x6, 0x2cd0 <ltmp0+0x2cd0>
    2324: 3d8017fb     	str	q27, [sp, #0x50]
    2328: 3638006a     	tbz	w10, #0x7, 0x2334 <ltmp0+0x2334>
    232c: 4e183e4a     	mov.d	x10, v18[1]
    2330: 4d409150     	ld1.s	{ v16 }[3], [x10]
    2334: d280000b     	mov	x11, #0x0               ; =0
    2338: 6e34de92     	fmul.4s	v18, v20, v20
    233c: 6e35deb3     	fmul.4s	v19, v21, v21
    2340: 6e39df35     	fmul.4s	v21, v25, v25
    2344: 6e3adf56     	fmul.4s	v22, v26, v26
    2348: 6e24dc84     	fmul.4s	v4, v4, v4
    234c: 6e26dcc6     	fmul.4s	v6, v6, v6
    2350: 6e22dc42     	fmul.4s	v2, v2, v2
    2354: 6e30de10     	fmul.4s	v16, v16, v16
    2358: 4e331f94     	and.16b	v20, v28, v19
    235c: 3dc03ff3     	ldr	q19, [sp, #0xf0]
    2360: 4e321e77     	and.16b	v23, v19, v18
    2364: 4e361f96     	and.16b	v22, v28, v22
    2368: 4e351e7a     	and.16b	v26, v19, v21
    236c: 4e261f99     	and.16b	v25, v28, v6
    2370: 4e241e78     	and.16b	v24, v19, v4
    2374: 4e301f95     	and.16b	v21, v28, v16
    2378: 5280038a     	mov	w10, #0x1c              ; =28
    237c: 4e221e7b     	and.16b	v27, v19, v2
    2380: 3d803bea     	str	q10, [sp, #0xe0]
    2384: 3d8043fc     	str	q28, [sp, #0x100]
    2388: 1400001f     	b	0x2404 <ltmp0+0x2404>
    238c: 6e28dd13     	fmul.4s	v19, v8, v8
    2390: 6e3cdf9c     	fmul.4s	v28, v28, v28
    2394: 4e3cd6fc     	fadd.4s	v28, v23, v28
    2398: 4e33d693     	fadd.4s	v19, v20, v19
    239c: 6e29dd28     	fmul.4s	v8, v9, v9
    23a0: 6e22dc42     	fmul.4s	v2, v2, v2
    23a4: 4e22d742     	fadd.4s	v2, v26, v2
    23a8: 4e28d6c8     	fadd.4s	v8, v22, v8
    23ac: 6e26dcc6     	fmul.4s	v6, v6, v6
    23b0: 6e24dc84     	fmul.4s	v4, v4, v4
    23b4: 4e24d704     	fadd.4s	v4, v24, v4
    23b8: 4e26d726     	fadd.4s	v6, v25, v6
    23bc: 6e30de10     	fmul.4s	v16, v16, v16
    23c0: 6e32de52     	fmul.4s	v18, v18, v18
    23c4: 4e32d6b2     	fadd.4s	v18, v21, v18
    23c8: 4e30d770     	fadd.4s	v16, v27, v16
    23cc: 3dc043e9     	ldr	q9, [sp, #0x100]
    23d0: 6ea91e74     	bit.16b	v20, v19, v9
    23d4: 3dc03ff3     	ldr	q19, [sp, #0xf0]
    23d8: 6eb31f97     	bit.16b	v23, v28, v19
    23dc: 6ea91d16     	bit.16b	v22, v8, v9
    23e0: 6eb31c5a     	bit.16b	v26, v2, v19
    23e4: 6ea91cd9     	bit.16b	v25, v6, v9
    23e8: 6eb31c98     	bit.16b	v24, v4, v19
    23ec: 9100116b     	add	x11, x11, #0x4
    23f0: 6eb31e1b     	bit.16b	v27, v16, v19
    23f4: 9100414a     	add	x10, x10, #0x10
    23f8: 6ea91e55     	bit.16b	v21, v18, v9
    23fc: f103f17f     	cmp	x11, #0xfc
    2400: 54001ae2     	b.hs	0x275c <ltmp0+0x275c>
    2404: 1e26022c     	fmov	w12, s17
    2408: d100314d     	sub	x13, x10, #0xc
    240c: 4e080da2     	dup.2d	v2, x13
    2410: 4ebe1c44     	orr.16b	v4, v2, v30
    2414: 4ee485a4     	add.2d	v4, v13, v4
    2418: 6f00e41c     	movi.2d	v28, #0000000000000000
    241c: 6f00e408     	movi.2d	v8, #0000000000000000
    2420: 37000b0c     	tbnz	w12, #0x0, 0x2580 <ltmp0+0x2580>
    2424: 12001d8e     	and	w14, w12, #0xff
    2428: 37080b4e     	tbnz	w14, #0x1, 0x2590 <ltmp0+0x2590>
    242c: 4eaf1c44     	orr.16b	v4, v2, v15
    2430: 4ee48564     	add.2d	v4, v11, v4
    2434: 37100b8e     	tbnz	w14, #0x2, 0x25a4 <ltmp0+0x25a4>
    2438: 37180bce     	tbnz	w14, #0x3, 0x25b0 <ltmp0+0x25b0>
    243c: 4ebd1c44     	orr.16b	v4, v2, v29
    2440: 4ee48584     	add.2d	v4, v12, v4
    2444: 37200c0e     	tbnz	w14, #0x4, 0x25c4 <ltmp0+0x25c4>
    2448: 37280c4e     	tbnz	w14, #0x5, 0x25d0 <ltmp0+0x25d0>
    244c: 4eae1c42     	orr.16b	v2, v2, v14
    2450: 4ee28542     	add.2d	v2, v10, v2
    2454: 37300c8e     	tbnz	w14, #0x6, 0x25e4 <ltmp0+0x25e4>
    2458: 3638006e     	tbz	w14, #0x7, 0x2464 <ltmp0+0x2464>
    245c: 4e183c4c     	mov.d	x12, v2[1]
    2460: 4d409188     	ld1.s	{ v8 }[3], [x12]
    2464: 1e26022c     	fmov	w12, s17
    2468: d100214d     	sub	x13, x10, #0x8
    246c: 4e080da4     	dup.2d	v4, x13
    2470: 4ebe1c82     	orr.16b	v2, v4, v30
    2474: 4ee285a6     	add.2d	v6, v13, v2
    2478: 6f00e402     	movi.2d	v2, #0000000000000000
    247c: 6f00e409     	movi.2d	v9, #0000000000000000
    2480: 37000bac     	tbnz	w12, #0x0, 0x25f4 <ltmp0+0x25f4>
    2484: 12001d8e     	and	w14, w12, #0xff
    2488: 37080bee     	tbnz	w14, #0x1, 0x2604 <ltmp0+0x2604>
    248c: 4eaf1c86     	orr.16b	v6, v4, v15
    2490: 4ee68566     	add.2d	v6, v11, v6
    2494: 37100c2e     	tbnz	w14, #0x2, 0x2618 <ltmp0+0x2618>
    2498: 37180c6e     	tbnz	w14, #0x3, 0x2624 <ltmp0+0x2624>
    249c: 4ebd1c86     	orr.16b	v6, v4, v29
    24a0: 4ee68586     	add.2d	v6, v12, v6
    24a4: 37200cae     	tbnz	w14, #0x4, 0x2638 <ltmp0+0x2638>
    24a8: 37280cee     	tbnz	w14, #0x5, 0x2644 <ltmp0+0x2644>
    24ac: 4eae1c84     	orr.16b	v4, v4, v14
    24b0: 4ee48544     	add.2d	v4, v10, v4
    24b4: 37300d2e     	tbnz	w14, #0x6, 0x2658 <ltmp0+0x2658>
    24b8: 3638006e     	tbz	w14, #0x7, 0x24c4 <ltmp0+0x24c4>
    24bc: 4e183c8c     	mov.d	x12, v4[1]
    24c0: 4d409189     	ld1.s	{ v9 }[3], [x12]
    24c4: 1e26022c     	fmov	w12, s17
    24c8: d100114d     	sub	x13, x10, #0x4
    24cc: 4e080db0     	dup.2d	v16, x13
    24d0: 4ebe1e04     	orr.16b	v4, v16, v30
    24d4: 4ee485b2     	add.2d	v18, v13, v4
    24d8: 6f00e404     	movi.2d	v4, #0000000000000000
    24dc: 6f00e406     	movi.2d	v6, #0000000000000000
    24e0: 37000c4c     	tbnz	w12, #0x0, 0x2668 <ltmp0+0x2668>
    24e4: 12001d8e     	and	w14, w12, #0xff
    24e8: 37080c8e     	tbnz	w14, #0x1, 0x2678 <ltmp0+0x2678>
    24ec: 4eaf1e12     	orr.16b	v18, v16, v15
    24f0: 4ef28572     	add.2d	v18, v11, v18
    24f4: 37100cce     	tbnz	w14, #0x2, 0x268c <ltmp0+0x268c>
    24f8: 37180d0e     	tbnz	w14, #0x3, 0x2698 <ltmp0+0x2698>
    24fc: 4ebd1e12     	orr.16b	v18, v16, v29
    2500: 4ef28592     	add.2d	v18, v12, v18
    2504: 37200d4e     	tbnz	w14, #0x4, 0x26ac <ltmp0+0x26ac>
    2508: 37280d8e     	tbnz	w14, #0x5, 0x26b8 <ltmp0+0x26b8>
    250c: 4eae1e10     	orr.16b	v16, v16, v14
    2510: 4ef08550     	add.2d	v16, v10, v16
    2514: 37300dce     	tbnz	w14, #0x6, 0x26cc <ltmp0+0x26cc>
    2518: 3638006e     	tbz	w14, #0x7, 0x2524 <ltmp0+0x2524>
    251c: 4e183e0c     	mov.d	x12, v16[1]
    2520: 4d409186     	ld1.s	{ v6 }[3], [x12]
    2524: 1e26022c     	fmov	w12, s17
    2528: 4e080d53     	dup.2d	v19, x10
    252c: 4ebe1e70     	orr.16b	v16, v19, v30
    2530: 4ef085aa     	add.2d	v10, v13, v16
    2534: 6f00e410     	movi.2d	v16, #0000000000000000
    2538: 6f00e412     	movi.2d	v18, #0000000000000000
    253c: 37000d0c     	tbnz	w12, #0x0, 0x26dc <ltmp0+0x26dc>
    2540: 12001d8e     	and	w14, w12, #0xff
    2544: 37080d4e     	tbnz	w14, #0x1, 0x26ec <ltmp0+0x26ec>
    2548: 4eaf1e6a     	orr.16b	v10, v19, v15
    254c: 4eea856a     	add.2d	v10, v11, v10
    2550: 37100d8e     	tbnz	w14, #0x2, 0x2700 <ltmp0+0x2700>
    2554: 37180dce     	tbnz	w14, #0x3, 0x270c <ltmp0+0x270c>
    2558: 4ebd1e6a     	orr.16b	v10, v19, v29
    255c: 4eea858a     	add.2d	v10, v12, v10
    2560: 37200e0e     	tbnz	w14, #0x4, 0x2720 <ltmp0+0x2720>
    2564: 37280e4e     	tbnz	w14, #0x5, 0x272c <ltmp0+0x272c>
    2568: 4eae1e73     	orr.16b	v19, v19, v14
    256c: 3dc03bea     	ldr	q10, [sp, #0xe0]
    2570: 4ef38553     	add.2d	v19, v10, v19
    2574: 37300e8e     	tbnz	w14, #0x6, 0x2744 <ltmp0+0x2744>
    2578: 363ff0ae     	tbz	w14, #0x7, 0x238c <ltmp0+0x238c>
    257c: 14000075     	b	0x2750 <ltmp0+0x2750>
    2580: 9e66008d     	fmov	x13, d4
    2584: bd4001bc     	ldr	s28, [x13]
    2588: 12001d8e     	and	w14, w12, #0xff
    258c: 360ff50e     	tbz	w14, #0x1, 0x242c <ltmp0+0x242c>
    2590: 4e183c8c     	mov.d	x12, v4[1]
    2594: 0d40919c     	ld1.s	{ v28 }[1], [x12]
    2598: 4eaf1c44     	orr.16b	v4, v2, v15
    259c: 4ee48564     	add.2d	v4, v11, v4
    25a0: 3617f4ce     	tbz	w14, #0x2, 0x2438 <ltmp0+0x2438>
    25a4: 9e66008c     	fmov	x12, d4
    25a8: 4d40819c     	ld1.s	{ v28 }[2], [x12]
    25ac: 361ff48e     	tbz	w14, #0x3, 0x243c <ltmp0+0x243c>
    25b0: 4e183c8c     	mov.d	x12, v4[1]
    25b4: 4d40919c     	ld1.s	{ v28 }[3], [x12]
    25b8: 4ebd1c44     	orr.16b	v4, v2, v29
    25bc: 4ee48584     	add.2d	v4, v12, v4
    25c0: 3627f44e     	tbz	w14, #0x4, 0x2448 <ltmp0+0x2448>
    25c4: 9e66008c     	fmov	x12, d4
    25c8: 0d408188     	ld1.s	{ v8 }[0], [x12]
    25cc: 362ff40e     	tbz	w14, #0x5, 0x244c <ltmp0+0x244c>
    25d0: 4e183c8c     	mov.d	x12, v4[1]
    25d4: 0d409188     	ld1.s	{ v8 }[1], [x12]
    25d8: 4eae1c42     	orr.16b	v2, v2, v14
    25dc: 4ee28542     	add.2d	v2, v10, v2
    25e0: 3637f3ce     	tbz	w14, #0x6, 0x2458 <ltmp0+0x2458>
    25e4: 9e66004c     	fmov	x12, d2
    25e8: 4d408188     	ld1.s	{ v8 }[2], [x12]
    25ec: 373ff38e     	tbnz	w14, #0x7, 0x245c <ltmp0+0x245c>
    25f0: 17ffff9d     	b	0x2464 <ltmp0+0x2464>
    25f4: 9e6600cd     	fmov	x13, d6
    25f8: bd4001a2     	ldr	s2, [x13]
    25fc: 12001d8e     	and	w14, w12, #0xff
    2600: 360ff46e     	tbz	w14, #0x1, 0x248c <ltmp0+0x248c>
    2604: 4e183ccc     	mov.d	x12, v6[1]
    2608: 0d409182     	ld1.s	{ v2 }[1], [x12]
    260c: 4eaf1c86     	orr.16b	v6, v4, v15
    2610: 4ee68566     	add.2d	v6, v11, v6
    2614: 3617f42e     	tbz	w14, #0x2, 0x2498 <ltmp0+0x2498>
    2618: 9e6600cc     	fmov	x12, d6
    261c: 4d408182     	ld1.s	{ v2 }[2], [x12]
    2620: 361ff3ee     	tbz	w14, #0x3, 0x249c <ltmp0+0x249c>
    2624: 4e183ccc     	mov.d	x12, v6[1]
    2628: 4d409182     	ld1.s	{ v2 }[3], [x12]
    262c: 4ebd1c86     	orr.16b	v6, v4, v29
    2630: 4ee68586     	add.2d	v6, v12, v6
    2634: 3627f3ae     	tbz	w14, #0x4, 0x24a8 <ltmp0+0x24a8>
    2638: 9e6600cc     	fmov	x12, d6
    263c: 0d408189     	ld1.s	{ v9 }[0], [x12]
    2640: 362ff36e     	tbz	w14, #0x5, 0x24ac <ltmp0+0x24ac>
    2644: 4e183ccc     	mov.d	x12, v6[1]
    2648: 0d409189     	ld1.s	{ v9 }[1], [x12]
    264c: 4eae1c84     	orr.16b	v4, v4, v14
    2650: 4ee48544     	add.2d	v4, v10, v4
    2654: 3637f32e     	tbz	w14, #0x6, 0x24b8 <ltmp0+0x24b8>
    2658: 9e66008c     	fmov	x12, d4
    265c: 4d408189     	ld1.s	{ v9 }[2], [x12]
    2660: 373ff2ee     	tbnz	w14, #0x7, 0x24bc <ltmp0+0x24bc>
    2664: 17ffff98     	b	0x24c4 <ltmp0+0x24c4>
    2668: 9e66024d     	fmov	x13, d18
    266c: bd4001a4     	ldr	s4, [x13]
    2670: 12001d8e     	and	w14, w12, #0xff
    2674: 360ff3ce     	tbz	w14, #0x1, 0x24ec <ltmp0+0x24ec>
    2678: 4e183e4c     	mov.d	x12, v18[1]
    267c: 0d409184     	ld1.s	{ v4 }[1], [x12]
    2680: 4eaf1e12     	orr.16b	v18, v16, v15
    2684: 4ef28572     	add.2d	v18, v11, v18
    2688: 3617f38e     	tbz	w14, #0x2, 0x24f8 <ltmp0+0x24f8>
    268c: 9e66024c     	fmov	x12, d18
    2690: 4d408184     	ld1.s	{ v4 }[2], [x12]
    2694: 361ff34e     	tbz	w14, #0x3, 0x24fc <ltmp0+0x24fc>
    2698: 4e183e4c     	mov.d	x12, v18[1]
    269c: 4d409184     	ld1.s	{ v4 }[3], [x12]
    26a0: 4ebd1e12     	orr.16b	v18, v16, v29
    26a4: 4ef28592     	add.2d	v18, v12, v18
    26a8: 3627f30e     	tbz	w14, #0x4, 0x2508 <ltmp0+0x2508>
    26ac: 9e66024c     	fmov	x12, d18
    26b0: 0d408186     	ld1.s	{ v6 }[0], [x12]
    26b4: 362ff2ce     	tbz	w14, #0x5, 0x250c <ltmp0+0x250c>
    26b8: 4e183e4c     	mov.d	x12, v18[1]
    26bc: 0d409186     	ld1.s	{ v6 }[1], [x12]
    26c0: 4eae1e10     	orr.16b	v16, v16, v14
    26c4: 4ef08550     	add.2d	v16, v10, v16
    26c8: 3637f28e     	tbz	w14, #0x6, 0x2518 <ltmp0+0x2518>
    26cc: 9e66020c     	fmov	x12, d16
    26d0: 4d408186     	ld1.s	{ v6 }[2], [x12]
    26d4: 373ff24e     	tbnz	w14, #0x7, 0x251c <ltmp0+0x251c>
    26d8: 17ffff93     	b	0x2524 <ltmp0+0x2524>
    26dc: 9e66014d     	fmov	x13, d10
    26e0: bd4001b0     	ldr	s16, [x13]
    26e4: 12001d8e     	and	w14, w12, #0xff
    26e8: 360ff30e     	tbz	w14, #0x1, 0x2548 <ltmp0+0x2548>
    26ec: 4e183d4c     	mov.d	x12, v10[1]
    26f0: 0d409190     	ld1.s	{ v16 }[1], [x12]
    26f4: 4eaf1e6a     	orr.16b	v10, v19, v15
    26f8: 4eea856a     	add.2d	v10, v11, v10
    26fc: 3617f2ce     	tbz	w14, #0x2, 0x2554 <ltmp0+0x2554>
    2700: 9e66014c     	fmov	x12, d10
    2704: 4d408190     	ld1.s	{ v16 }[2], [x12]
    2708: 361ff28e     	tbz	w14, #0x3, 0x2558 <ltmp0+0x2558>
    270c: 4e183d4c     	mov.d	x12, v10[1]
    2710: 4d409190     	ld1.s	{ v16 }[3], [x12]
    2714: 4ebd1e6a     	orr.16b	v10, v19, v29
    2718: 4eea858a     	add.2d	v10, v12, v10
    271c: 3627f24e     	tbz	w14, #0x4, 0x2564 <ltmp0+0x2564>
    2720: 9e66014c     	fmov	x12, d10
    2724: 0d408192     	ld1.s	{ v18 }[0], [x12]
    2728: 362ff20e     	tbz	w14, #0x5, 0x2568 <ltmp0+0x2568>
    272c: 4e183d4c     	mov.d	x12, v10[1]
    2730: 0d409192     	ld1.s	{ v18 }[1], [x12]
    2734: 4eae1e73     	orr.16b	v19, v19, v14
    2738: 3dc03bea     	ldr	q10, [sp, #0xe0]
    273c: 4ef38553     	add.2d	v19, v10, v19
    2740: 3637f1ce     	tbz	w14, #0x6, 0x2578 <ltmp0+0x2578>
    2744: 9e66026c     	fmov	x12, d19
    2748: 4d408192     	ld1.s	{ v18 }[2], [x12]
    274c: 363fe20e     	tbz	w14, #0x7, 0x238c <ltmp0+0x238c>
    2750: 4e183e6c     	mov.d	x12, v19[1]
    2754: 4d409192     	ld1.s	{ v18 }[3], [x12]
    2758: 17ffff0d     	b	0x238c <ltmp0+0x238c>
    275c: d280000a     	mov	x10, #0x0               ; =0
    2760: 0f20a662     	sshll.2d	v2, v19, #0x0
    2764: 0f20a524     	sshll.2d	v4, v9, #0x0
    2768: 3dc00fe6     	ldr	q6, [sp, #0x30]
    276c: 4e3f1cdc     	and.16b	v28, v6, v31
    2770: 3dc013e6     	ldr	q6, [sp, #0x40]
    2774: 4e3f1cc8     	and.16b	v8, v6, v31
    2778: 4e3f1c89     	and.16b	v9, v4, v31
    277c: 4e3f1c42     	and.16b	v2, v2, v31
    2780: 14000004     	b	0x2790 <ltmp0+0x2790>
    2784: 9100114a     	add	x10, x10, #0x4
    2788: f110015f     	cmp	x10, #0x400
    278c: 540006c0     	b.eq	0x2864 <ltmp0+0x2864>
    2790: 1e26022b     	fmov	w11, s17
    2794: 8b0a012c     	add	x12, x9, x10
    2798: 4d40c984     	ld1r.4s	{ v4 }, [x12]
    279c: 4e080d46     	dup.2d	v6, x10
    27a0: 4ebe1cd0     	orr.16b	v16, v6, v30
    27a4: 4ef08450     	add.2d	v16, v2, v16
    27a8: 3700020b     	tbnz	w11, #0x0, 0x27e8 <ltmp0+0x27e8>
    27ac: 12001d6b     	and	w11, w11, #0xff
    27b0: 3708024b     	tbnz	w11, #0x1, 0x27f8 <ltmp0+0x27f8>
    27b4: 4eaf1cd0     	orr.16b	v16, v6, v15
    27b8: 4ef08510     	add.2d	v16, v8, v16
    27bc: 3710028b     	tbnz	w11, #0x2, 0x280c <ltmp0+0x280c>
    27c0: 371802cb     	tbnz	w11, #0x3, 0x2818 <ltmp0+0x2818>
    27c4: 4ebd1cd0     	orr.16b	v16, v6, v29
    27c8: 4ef08530     	add.2d	v16, v9, v16
    27cc: 3720030b     	tbnz	w11, #0x4, 0x282c <ltmp0+0x282c>
    27d0: 3728034b     	tbnz	w11, #0x5, 0x2838 <ltmp0+0x2838>
    27d4: 4eae1cc6     	orr.16b	v6, v6, v14
    27d8: 4ee68786     	add.2d	v6, v28, v6
    27dc: 3730038b     	tbnz	w11, #0x6, 0x284c <ltmp0+0x284c>
    27e0: 363ffd2b     	tbz	w11, #0x7, 0x2784 <ltmp0+0x2784>
    27e4: 1400001d     	b	0x2858 <ltmp0+0x2858>
    27e8: 9e66020c     	fmov	x12, d16
    27ec: bd000184     	str	s4, [x12]
    27f0: 12001d6b     	and	w11, w11, #0xff
    27f4: 360ffe0b     	tbz	w11, #0x1, 0x27b4 <ltmp0+0x27b4>
    27f8: 4e183e0c     	mov.d	x12, v16[1]
    27fc: 0d009184     	st1.s	{ v4 }[1], [x12]
    2800: 4eaf1cd0     	orr.16b	v16, v6, v15
    2804: 4ef08510     	add.2d	v16, v8, v16
    2808: 3617fdcb     	tbz	w11, #0x2, 0x27c0 <ltmp0+0x27c0>
    280c: 9e66020c     	fmov	x12, d16
    2810: 4d008184     	st1.s	{ v4 }[2], [x12]
    2814: 361ffd8b     	tbz	w11, #0x3, 0x27c4 <ltmp0+0x27c4>
    2818: 4e183e0c     	mov.d	x12, v16[1]
    281c: 4d009184     	st1.s	{ v4 }[3], [x12]
    2820: 4ebd1cd0     	orr.16b	v16, v6, v29
    2824: 4ef08530     	add.2d	v16, v9, v16
    2828: 3627fd4b     	tbz	w11, #0x4, 0x27d0 <ltmp0+0x27d0>
    282c: 9e66020c     	fmov	x12, d16
    2830: bd000184     	str	s4, [x12]
    2834: 362ffd0b     	tbz	w11, #0x5, 0x27d4 <ltmp0+0x27d4>
    2838: 4e183e0c     	mov.d	x12, v16[1]
    283c: 0d009184     	st1.s	{ v4 }[1], [x12]
    2840: 4eae1cc6     	orr.16b	v6, v6, v14
    2844: 4ee68786     	add.2d	v6, v28, v6
    2848: 3637fccb     	tbz	w11, #0x6, 0x27e0 <ltmp0+0x27e0>
    284c: 9e6600cc     	fmov	x12, d6
    2850: 4d008184     	st1.s	{ v4 }[2], [x12]
    2854: 363ff98b     	tbz	w11, #0x7, 0x2784 <ltmp0+0x2784>
    2858: 4e183ccb     	mov.d	x11, v6[1]
    285c: 4d009164     	st1.s	{ v4 }[3], [x11]
    2860: 17ffffc9     	b	0x2784 <ltmp0+0x2784>
    2864: d2800009     	mov	x9, #0x0                ; =0
    2868: 4e3ad6e4     	fadd.4s	v4, v23, v26
    286c: 4e36d686     	fadd.4s	v6, v20, v22
    2870: 4e39d4c6     	fadd.4s	v6, v6, v25
    2874: 4e38d484     	fadd.4s	v4, v4, v24
    2878: 4e3bd484     	fadd.4s	v4, v4, v27
    287c: 4e35d4c6     	fadd.4s	v6, v6, v21
    2880: ad4dc3f2     	ldp	q18, q16, [sp, #0x1b0]
    2884: 6e32dcc6     	fmul.4s	v6, v6, v18
    2888: 6e32dc84     	fmul.4s	v4, v4, v18
    288c: 4e30d484     	fadd.4s	v4, v4, v16
    2890: 4e30d4c6     	fadd.4s	v6, v6, v16
    2894: 6ea1f8c6     	fsqrt.4s	v6, v6
    2898: 6ea1f884     	fsqrt.4s	v4, v4
    289c: 4e241e73     	and.16b	v19, v19, v4
    28a0: 3dc043e4     	ldr	q4, [sp, #0x100]
    28a4: 4e261c92     	and.16b	v18, v4, v6
    28a8: ad42ebfb     	ldp	q27, q26, [sp, #0x50]
    28ac: 14000004     	b	0x28bc <ltmp0+0x28bc>
    28b0: 91001129     	add	x9, x9, #0x4
    28b4: f110013f     	cmp	x9, #0x400
    28b8: 54fec620     	b.eq	0x17c <ltmp0+0x17c>
    28bc: 1e26022a     	fmov	w10, s17
    28c0: 4e080d34     	dup.2d	v20, x9
    28c4: 4ebe1e86     	orr.16b	v6, v20, v30
    28c8: 4ee685b0     	add.2d	v16, v13, v6
    28cc: 6f00e404     	movi.2d	v4, #0000000000000000
    28d0: 6f00e415     	movi.2d	v21, #0000000000000000
    28d4: 3700076a     	tbnz	w10, #0x0, 0x29c0 <ltmp0+0x29c0>
    28d8: 12001d4a     	and	w10, w10, #0xff
    28dc: 370807aa     	tbnz	w10, #0x1, 0x29d0 <ltmp0+0x29d0>
    28e0: 4eaf1e90     	orr.16b	v16, v20, v15
    28e4: 4ef08576     	add.2d	v22, v11, v16
    28e8: 371007ea     	tbnz	w10, #0x2, 0x29e4 <ltmp0+0x29e4>
    28ec: 3718082a     	tbnz	w10, #0x3, 0x29f0 <ltmp0+0x29f0>
    28f0: 4ebd1e96     	orr.16b	v22, v20, v29
    28f4: 4ef68597     	add.2d	v23, v12, v22
    28f8: 3720086a     	tbnz	w10, #0x4, 0x2a04 <ltmp0+0x2a04>
    28fc: 372808aa     	tbnz	w10, #0x5, 0x2a10 <ltmp0+0x2a10>
    2900: 4eae1e97     	orr.16b	v23, v20, v14
    2904: 4ef78558     	add.2d	v24, v10, v23
    2908: 373008ea     	tbnz	w10, #0x6, 0x2a24 <ltmp0+0x2a24>
    290c: 3738092a     	tbnz	w10, #0x7, 0x2a30 <ltmp0+0x2a30>
    2910: 1e26022a     	fmov	w10, s17
    2914: 4ee68459     	add.2d	v25, v2, v6
    2918: 6f00e418     	movi.2d	v24, #0000000000000000
    291c: 6f00e406     	movi.2d	v6, #0000000000000000
    2920: 3700096a     	tbnz	w10, #0x0, 0x2a4c <ltmp0+0x2a4c>
    2924: 12001d4a     	and	w10, w10, #0xff
    2928: 370809aa     	tbnz	w10, #0x1, 0x2a5c <ltmp0+0x2a5c>
    292c: 4ef08510     	add.2d	v16, v8, v16
    2930: 371009ea     	tbnz	w10, #0x2, 0x2a6c <ltmp0+0x2a6c>
    2934: 37180a2a     	tbnz	w10, #0x3, 0x2a78 <ltmp0+0x2a78>
    2938: 4ef68530     	add.2d	v16, v9, v22
    293c: 37200a6a     	tbnz	w10, #0x4, 0x2a88 <ltmp0+0x2a88>
    2940: 37280aaa     	tbnz	w10, #0x5, 0x2a94 <ltmp0+0x2a94>
    2944: 4ef78790     	add.2d	v16, v28, v23
    2948: 37300aea     	tbnz	w10, #0x6, 0x2aa4 <ltmp0+0x2aa4>
    294c: 3638006a     	tbz	w10, #0x7, 0x2958 <ltmp0+0x2958>
    2950: 4e183e0a     	mov.d	x10, v16[1]
    2954: 4d409146     	ld1.s	{ v6 }[3], [x10]
    2958: 6e33fc84     	fdiv.4s	v4, v4, v19
    295c: 1e26022a     	fmov	w10, s17
    2960: 6e38dc90     	fmul.4s	v16, v4, v24
    2964: 3dc077e4     	ldr	q4, [sp, #0x1d0]
    2968: 4ee48696     	add.2d	v22, v20, v4
    296c: 4e080ec4     	dup.2d	v4, x22
    2970: 4ef68496     	add.2d	v22, v4, v22
    2974: 37000a0a     	tbnz	w10, #0x0, 0x2ab4 <ltmp0+0x2ab4>
    2978: 12001d4a     	and	w10, w10, #0xff
    297c: 37080a4a     	tbnz	w10, #0x1, 0x2ac4 <ltmp0+0x2ac4>
    2980: 4efb8696     	add.2d	v22, v20, v27
    2984: 4ef68496     	add.2d	v22, v4, v22
    2988: 37100a8a     	tbnz	w10, #0x2, 0x2ad8 <ltmp0+0x2ad8>
    298c: 37180aca     	tbnz	w10, #0x3, 0x2ae4 <ltmp0+0x2ae4>
    2990: 6e32feb0     	fdiv.4s	v16, v21, v18
    2994: 6e26de06     	fmul.4s	v6, v16, v6
    2998: 3dc07bf0     	ldr	q16, [sp, #0x1e0]
    299c: 4ef08690     	add.2d	v16, v20, v16
    29a0: 4ef08490     	add.2d	v16, v4, v16
    29a4: 37200b0a     	tbnz	w10, #0x4, 0x2b04 <ltmp0+0x2b04>
    29a8: 37280b4a     	tbnz	w10, #0x5, 0x2b10 <ltmp0+0x2b10>
    29ac: 4efa8690     	add.2d	v16, v20, v26
    29b0: 4ef08484     	add.2d	v4, v4, v16
    29b4: 37300b8a     	tbnz	w10, #0x6, 0x2b24 <ltmp0+0x2b24>
    29b8: 363ff7ca     	tbz	w10, #0x7, 0x28b0 <ltmp0+0x28b0>
    29bc: 1400005d     	b	0x2b30 <ltmp0+0x2b30>
    29c0: 9e66020b     	fmov	x11, d16
    29c4: bd400164     	ldr	s4, [x11]
    29c8: 12001d4a     	and	w10, w10, #0xff
    29cc: 360ff8aa     	tbz	w10, #0x1, 0x28e0 <ltmp0+0x28e0>
    29d0: 4e183e0b     	mov.d	x11, v16[1]
    29d4: 0d409164     	ld1.s	{ v4 }[1], [x11]
    29d8: 4eaf1e90     	orr.16b	v16, v20, v15
    29dc: 4ef08576     	add.2d	v22, v11, v16
    29e0: 3617f86a     	tbz	w10, #0x2, 0x28ec <ltmp0+0x28ec>
    29e4: 9e6602cb     	fmov	x11, d22
    29e8: 4d408164     	ld1.s	{ v4 }[2], [x11]
    29ec: 361ff82a     	tbz	w10, #0x3, 0x28f0 <ltmp0+0x28f0>
    29f0: 4e183ecb     	mov.d	x11, v22[1]
    29f4: 4d409164     	ld1.s	{ v4 }[3], [x11]
    29f8: 4ebd1e96     	orr.16b	v22, v20, v29
    29fc: 4ef68597     	add.2d	v23, v12, v22
    2a00: 3627f7ea     	tbz	w10, #0x4, 0x28fc <ltmp0+0x28fc>
    2a04: 9e6602eb     	fmov	x11, d23
    2a08: 0d408175     	ld1.s	{ v21 }[0], [x11]
    2a0c: 362ff7aa     	tbz	w10, #0x5, 0x2900 <ltmp0+0x2900>
    2a10: 4e183eeb     	mov.d	x11, v23[1]
    2a14: 0d409175     	ld1.s	{ v21 }[1], [x11]
    2a18: 4eae1e97     	orr.16b	v23, v20, v14
    2a1c: 4ef78558     	add.2d	v24, v10, v23
    2a20: 3637f76a     	tbz	w10, #0x6, 0x290c <ltmp0+0x290c>
    2a24: 9e66030b     	fmov	x11, d24
    2a28: 4d408175     	ld1.s	{ v21 }[2], [x11]
    2a2c: 363ff72a     	tbz	w10, #0x7, 0x2910 <ltmp0+0x2910>
    2a30: 4e183f0a     	mov.d	x10, v24[1]
    2a34: 4d409155     	ld1.s	{ v21 }[3], [x10]
    2a38: 1e26022a     	fmov	w10, s17
    2a3c: 4ee68459     	add.2d	v25, v2, v6
    2a40: 6f00e418     	movi.2d	v24, #0000000000000000
    2a44: 6f00e406     	movi.2d	v6, #0000000000000000
    2a48: 3607f6ea     	tbz	w10, #0x0, 0x2924 <ltmp0+0x2924>
    2a4c: 9e66032b     	fmov	x11, d25
    2a50: bd400178     	ldr	s24, [x11]
    2a54: 12001d4a     	and	w10, w10, #0xff
    2a58: 360ff6aa     	tbz	w10, #0x1, 0x292c <ltmp0+0x292c>
    2a5c: 4e183f2b     	mov.d	x11, v25[1]
    2a60: 0d409178     	ld1.s	{ v24 }[1], [x11]
    2a64: 4ef08510     	add.2d	v16, v8, v16
    2a68: 3617f66a     	tbz	w10, #0x2, 0x2934 <ltmp0+0x2934>
    2a6c: 9e66020b     	fmov	x11, d16
    2a70: 4d408178     	ld1.s	{ v24 }[2], [x11]
    2a74: 361ff62a     	tbz	w10, #0x3, 0x2938 <ltmp0+0x2938>
    2a78: 4e183e0b     	mov.d	x11, v16[1]
    2a7c: 4d409178     	ld1.s	{ v24 }[3], [x11]
    2a80: 4ef68530     	add.2d	v16, v9, v22
    2a84: 3627f5ea     	tbz	w10, #0x4, 0x2940 <ltmp0+0x2940>
    2a88: 9e66020b     	fmov	x11, d16
    2a8c: 0d408166     	ld1.s	{ v6 }[0], [x11]
    2a90: 362ff5aa     	tbz	w10, #0x5, 0x2944 <ltmp0+0x2944>
    2a94: 4e183e0b     	mov.d	x11, v16[1]
    2a98: 0d409166     	ld1.s	{ v6 }[1], [x11]
    2a9c: 4ef78790     	add.2d	v16, v28, v23
    2aa0: 3637f56a     	tbz	w10, #0x6, 0x294c <ltmp0+0x294c>
    2aa4: 9e66020b     	fmov	x11, d16
    2aa8: 4d408166     	ld1.s	{ v6 }[2], [x11]
    2aac: 373ff52a     	tbnz	w10, #0x7, 0x2950 <ltmp0+0x2950>
    2ab0: 17ffffaa     	b	0x2958 <ltmp0+0x2958>
    2ab4: 9e6602cb     	fmov	x11, d22
    2ab8: bd000170     	str	s16, [x11]
    2abc: 12001d4a     	and	w10, w10, #0xff
    2ac0: 360ff60a     	tbz	w10, #0x1, 0x2980 <ltmp0+0x2980>
    2ac4: 4e183ecb     	mov.d	x11, v22[1]
    2ac8: 0d009170     	st1.s	{ v16 }[1], [x11]
    2acc: 4efb8696     	add.2d	v22, v20, v27
    2ad0: 4ef68496     	add.2d	v22, v4, v22
    2ad4: 3617f5ca     	tbz	w10, #0x2, 0x298c <ltmp0+0x298c>
    2ad8: 9e6602cb     	fmov	x11, d22
    2adc: 4d008170     	st1.s	{ v16 }[2], [x11]
    2ae0: 361ff58a     	tbz	w10, #0x3, 0x2990 <ltmp0+0x2990>
    2ae4: 4e183ecb     	mov.d	x11, v22[1]
    2ae8: 4d009170     	st1.s	{ v16 }[3], [x11]
    2aec: 6e32feb0     	fdiv.4s	v16, v21, v18
    2af0: 6e26de06     	fmul.4s	v6, v16, v6
    2af4: 3dc07bf0     	ldr	q16, [sp, #0x1e0]
    2af8: 4ef08690     	add.2d	v16, v20, v16
    2afc: 4ef08490     	add.2d	v16, v4, v16
    2b00: 3627f54a     	tbz	w10, #0x4, 0x29a8 <ltmp0+0x29a8>
    2b04: 9e66020b     	fmov	x11, d16
    2b08: bd000166     	str	s6, [x11]
    2b0c: 362ff50a     	tbz	w10, #0x5, 0x29ac <ltmp0+0x29ac>
    2b10: 4e183e0b     	mov.d	x11, v16[1]
    2b14: 0d009166     	st1.s	{ v6 }[1], [x11]
    2b18: 4efa8690     	add.2d	v16, v20, v26
    2b1c: 4ef08484     	add.2d	v4, v4, v16
    2b20: 3637f4ca     	tbz	w10, #0x6, 0x29b8 <ltmp0+0x29b8>
    2b24: 9e66008b     	fmov	x11, d4
    2b28: 4d008166     	st1.s	{ v6 }[2], [x11]
    2b2c: 363fec2a     	tbz	w10, #0x7, 0x28b0 <ltmp0+0x28b0>
    2b30: 4e183c8a     	mov.d	x10, v4[1]
    2b34: 4d009146     	st1.s	{ v6 }[3], [x10]
    2b38: 17ffff5e     	b	0x28b0 <ltmp0+0x28b0>
    2b3c: 9e66004b     	fmov	x11, d2
    2b40: bd400174     	ldr	s20, [x11]
    2b44: 12001d4a     	and	w10, w10, #0xff
    2b48: 360fb64a     	tbz	w10, #0x1, 0x2210 <ltmp0+0x2210>
    2b4c: 4e183c4b     	mov.d	x11, v2[1]
    2b50: 0d409174     	ld1.s	{ v20 }[1], [x11]
    2b54: 4eef8576     	add.2d	v22, v11, v15
    2b58: 3617b60a     	tbz	w10, #0x2, 0x2218 <ltmp0+0x2218>
    2b5c: 9e6602cb     	fmov	x11, d22
    2b60: 4d408174     	ld1.s	{ v20 }[2], [x11]
    2b64: 361fb5ca     	tbz	w10, #0x3, 0x221c <ltmp0+0x221c>
    2b68: 4e183ecb     	mov.d	x11, v22[1]
    2b6c: 4d409174     	ld1.s	{ v20 }[3], [x11]
    2b70: 4efd8597     	add.2d	v23, v12, v29
    2b74: 3627b58a     	tbz	w10, #0x4, 0x2224 <ltmp0+0x2224>
    2b78: 9e6602eb     	fmov	x11, d23
    2b7c: 0d408175     	ld1.s	{ v21 }[0], [x11]
    2b80: 362fb54a     	tbz	w10, #0x5, 0x2228 <ltmp0+0x2228>
    2b84: 4e183eeb     	mov.d	x11, v23[1]
    2b88: 0d409175     	ld1.s	{ v21 }[1], [x11]
    2b8c: 4eee8558     	add.2d	v24, v10, v14
    2b90: 3637b50a     	tbz	w10, #0x6, 0x2230 <ltmp0+0x2230>
    2b94: 9e66030b     	fmov	x11, d24
    2b98: 4d408175     	ld1.s	{ v21 }[2], [x11]
    2b9c: 3d801bf3     	str	q19, [sp, #0x60]
    2ba0: 373fb4ca     	tbnz	w10, #0x7, 0x2238 <ltmp0+0x2238>
    2ba4: 17fffda7     	b	0x2240 <ltmp0+0x2240>
    2ba8: 9e6600cb     	fmov	x11, d6
    2bac: bd400179     	ldr	s25, [x11]
    2bb0: 12001d4a     	and	w10, w10, #0xff
    2bb4: 360fb58a     	tbz	w10, #0x1, 0x2264 <ltmp0+0x2264>
    2bb8: 4e183ccb     	mov.d	x11, v6[1]
    2bbc: 0d409179     	ld1.s	{ v25 }[1], [x11]
    2bc0: 4ee486c6     	add.2d	v6, v22, v4
    2bc4: 3617b54a     	tbz	w10, #0x2, 0x226c <ltmp0+0x226c>
    2bc8: 9e6600cb     	fmov	x11, d6
    2bcc: 4d408179     	ld1.s	{ v25 }[2], [x11]
    2bd0: 361fb50a     	tbz	w10, #0x3, 0x2270 <ltmp0+0x2270>
    2bd4: 4e183ccb     	mov.d	x11, v6[1]
    2bd8: 4d409179     	ld1.s	{ v25 }[3], [x11]
    2bdc: 4ee486e6     	add.2d	v6, v23, v4
    2be0: 3627b4ca     	tbz	w10, #0x4, 0x2278 <ltmp0+0x2278>
    2be4: 9e6600cb     	fmov	x11, d6
    2be8: 0d40817a     	ld1.s	{ v26 }[0], [x11]
    2bec: 362fb48a     	tbz	w10, #0x5, 0x227c <ltmp0+0x227c>
    2bf0: 4e183ccb     	mov.d	x11, v6[1]
    2bf4: 0d40917a     	ld1.s	{ v26 }[1], [x11]
    2bf8: 4ee48704     	add.2d	v4, v24, v4
    2bfc: 3637b44a     	tbz	w10, #0x6, 0x2284 <ltmp0+0x2284>
    2c00: 9e66008b     	fmov	x11, d4
    2c04: 4d40817a     	ld1.s	{ v26 }[2], [x11]
    2c08: 373fb40a     	tbnz	w10, #0x7, 0x2288 <ltmp0+0x2288>
    2c0c: 17fffda1     	b	0x2290 <ltmp0+0x2290>
    2c10: 9e66024b     	fmov	x11, d18
    2c14: bd400164     	ldr	s4, [x11]
    2c18: 12001d4a     	and	w10, w10, #0xff
    2c1c: 360fb4ca     	tbz	w10, #0x1, 0x22b4 <ltmp0+0x22b4>
    2c20: 4e183e4b     	mov.d	x11, v18[1]
    2c24: 0d409164     	ld1.s	{ v4 }[1], [x11]
    2c28: 4ef086d2     	add.2d	v18, v22, v16
    2c2c: 3617b48a     	tbz	w10, #0x2, 0x22bc <ltmp0+0x22bc>
    2c30: 9e66024b     	fmov	x11, d18
    2c34: 4d408164     	ld1.s	{ v4 }[2], [x11]
    2c38: 361fb44a     	tbz	w10, #0x3, 0x22c0 <ltmp0+0x22c0>
    2c3c: 4e183e4b     	mov.d	x11, v18[1]
    2c40: 4d409164     	ld1.s	{ v4 }[3], [x11]
    2c44: 4ef086f2     	add.2d	v18, v23, v16
    2c48: 3627b40a     	tbz	w10, #0x4, 0x22c8 <ltmp0+0x22c8>
    2c4c: 9e66024b     	fmov	x11, d18
    2c50: 0d408166     	ld1.s	{ v6 }[0], [x11]
    2c54: 362fb3ca     	tbz	w10, #0x5, 0x22cc <ltmp0+0x22cc>
    2c58: 4e183e4b     	mov.d	x11, v18[1]
    2c5c: 0d409166     	ld1.s	{ v6 }[1], [x11]
    2c60: 4ef08710     	add.2d	v16, v24, v16
    2c64: 3637b38a     	tbz	w10, #0x6, 0x22d4 <ltmp0+0x22d4>
    2c68: 9e66020b     	fmov	x11, d16
    2c6c: 4d408166     	ld1.s	{ v6 }[2], [x11]
    2c70: 373fb34a     	tbnz	w10, #0x7, 0x22d8 <ltmp0+0x22d8>
    2c74: 17fffd9b     	b	0x22e0 <ltmp0+0x22e0>
    2c78: 9e66026b     	fmov	x11, d19
    2c7c: bd400162     	ldr	s2, [x11]
    2c80: 12001d4a     	and	w10, w10, #0xff
    2c84: 360fb40a     	tbz	w10, #0x1, 0x2304 <ltmp0+0x2304>
    2c88: 4e183e6b     	mov.d	x11, v19[1]
    2c8c: 0d409162     	ld1.s	{ v2 }[1], [x11]
    2c90: 4ef286d3     	add.2d	v19, v22, v18
    2c94: 3617b3ca     	tbz	w10, #0x2, 0x230c <ltmp0+0x230c>
    2c98: 9e66026b     	fmov	x11, d19
    2c9c: 4d408162     	ld1.s	{ v2 }[2], [x11]
    2ca0: 361fb38a     	tbz	w10, #0x3, 0x2310 <ltmp0+0x2310>
    2ca4: 4e183e6b     	mov.d	x11, v19[1]
    2ca8: 4d409162     	ld1.s	{ v2 }[3], [x11]
    2cac: 4ef286f3     	add.2d	v19, v23, v18
    2cb0: 3627b34a     	tbz	w10, #0x4, 0x2318 <ltmp0+0x2318>
    2cb4: 9e66026b     	fmov	x11, d19
    2cb8: 0d408170     	ld1.s	{ v16 }[0], [x11]
    2cbc: 362fb30a     	tbz	w10, #0x5, 0x231c <ltmp0+0x231c>
    2cc0: 4e183e6b     	mov.d	x11, v19[1]
    2cc4: 0d409170     	ld1.s	{ v16 }[1], [x11]
    2cc8: 4ef28712     	add.2d	v18, v24, v18
    2ccc: 3637b2ca     	tbz	w10, #0x6, 0x2324 <ltmp0+0x2324>
    2cd0: 9e66024b     	fmov	x11, d18
    2cd4: 4d408170     	ld1.s	{ v16 }[2], [x11]
    2cd8: 3d8017fb     	str	q27, [sp, #0x50]
    2cdc: 373fb28a     	tbnz	w10, #0x7, 0x232c <ltmp0+0x232c>
    2ce0: 17fffd95     	b	0x2334 <ltmp0+0x2334>
    2ce4: f94007e9     	ldr	x9, [sp, #0x8]
    2ce8: 29003538     	stp	w24, w13, [x9]
    2cec: b9000936     	str	w22, [x9, #0x8]
    2cf0: 52800308     	mov	w8, #0x18               ; =24
    2cf4: b9002528     	str	w8, [x9, #0x24]
    2cf8: 914013ff     	add	sp, sp, #0x4, lsl #12   ; =0x4000
    2cfc: 910803ff     	add	sp, sp, #0x200
    2d00: a9497bfd     	ldp	x29, x30, [sp, #0x90]
    2d04: a9484ff4     	ldp	x20, x19, [sp, #0x80]
    2d08: a94757f6     	ldp	x22, x21, [sp, #0x70]
    2d0c: a9465ff8     	ldp	x24, x23, [sp, #0x60]
    2d10: a94567fa     	ldp	x26, x25, [sp, #0x50]
    2d14: a9446ffc     	ldp	x28, x27, [sp, #0x40]
    2d18: 6d4323e9     	ldp	d9, d8, [sp, #0x30]
    2d1c: 6d422beb     	ldp	d11, d10, [sp, #0x20]
    2d20: 6d4133ed     	ldp	d13, d12, [sp, #0x10]
    2d24: 6cca3bef     	ldp	d15, d14, [sp], #0xa0
    2d28: d65f03c0     	ret

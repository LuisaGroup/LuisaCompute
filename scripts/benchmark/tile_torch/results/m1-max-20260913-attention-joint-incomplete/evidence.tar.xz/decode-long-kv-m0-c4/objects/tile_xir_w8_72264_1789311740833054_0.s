	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.full_packet
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	0                               ; 0x0
	.quad	8192                            ; 0x2000
lCPI0_3:
	.quad	16384                           ; 0x4000
	.quad	24576                           ; 0x6000
lCPI0_4:
	.quad	32768                           ; 0x8000
	.quad	40960                           ; 0xa000
lCPI0_5:
	.quad	49152                           ; 0xc000
	.quad	57344                           ; 0xe000
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	512                             ; 0x200
lCPI0_7:
	.quad	1024                            ; 0x400
	.quad	1536                            ; 0x600
lCPI0_8:
	.quad	2048                            ; 0x800
	.quad	2560                            ; 0xa00
lCPI0_9:
	.quad	3072                            ; 0xc00
	.quad	3584                            ; 0xe00
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention.full_packet:             ; @llm_attention.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2112
	mov	x9, #0                          ; =0x0
	ldr	x21, [x1, #136]
	add	x22, x21, #35, lsl #12          ; =143360
	ldr	x8, [x0]
	ldr	x10, [x0, #16]
	str	x10, [sp, #264]                 ; 8-byte Spill
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
	ldr	x12, [x0, #32]
	ldr	x11, [x0, #48]
	dup.4s	v0, w10
Lloh0:
	adrp	x10, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x10, lCPI0_0@PAGEOFF]
	add.4s	v1, v0, v1
Lloh2:
	adrp	x10, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x10, lCPI0_1@PAGEOFF]
	add.4s	v0, v0, v2
	ushll2.2d	v2, v0, #0
	str	q2, [sp, #2080]                 ; 16-byte Spill
	ushll2.2d	v2, v1, #0
	str	q2, [sp, #2096]                 ; 16-byte Spill
	ushll.2d	v2, v0, #0
	str	q2, [sp, #2048]                 ; 16-byte Spill
	ushll.2d	v2, v1, #0
	str	q2, [sp, #2064]                 ; 16-byte Spill
	ushll2.2d	v2, v0, #7
	ushll2.2d	v3, v1, #7
	ushll.2d	v4, v0, #7
	ushll.2d	v1, v1, #7
	fmov	x10, d1
	add	x10, x8, x10, lsl #2
LBB0_1:                                 ; %copy.chunk.i
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x10, x9]
	str	q0, [x21, x9]
	add	x9, x9, #16
	cmp	x9, #512
	b.ne	LBB0_1
; %bb.2:                                ; %llm_attention.contiguous_copy.exit
	mov.d	x9, v1[1]
	add	x9, x8, x9, lsl #2
	mov	w10, #32                        ; =0x20
LBB0_3:                                 ; %copy.chunk.i339
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x9], #16
	str	q0, [x21, x10, lsl #4]
	add	x10, x10, #1
	cmp	x10, #64
	b.ne	LBB0_3
; %bb.4:                                ; %llm_attention.contiguous_copy.exit342
	fmov	x9, d3
	add	x9, x8, x9, lsl #2
LBB0_5:                                 ; %copy.chunk.i343
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x9], #16
	str	q0, [x21, x10, lsl #4]
	add	x10, x10, #1
	cmp	x10, #96
	b.ne	LBB0_5
; %bb.6:                                ; %llm_attention.contiguous_copy.exit346
	mov.d	x9, v3[1]
	add	x9, x8, x9, lsl #2
LBB0_7:                                 ; %copy.chunk.i347
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x9], #16
	str	q0, [x21, x10, lsl #4]
	add	x10, x10, #1
	cmp	x10, #128
	b.ne	LBB0_7
; %bb.8:                                ; %llm_attention.contiguous_copy.exit350
	fmov	x9, d4
	add	x9, x8, x9, lsl #2
LBB0_9:                                 ; %copy.chunk.i351
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x9], #16
	str	q0, [x21, x10, lsl #4]
	add	x10, x10, #1
	cmp	x10, #160
	b.ne	LBB0_9
; %bb.10:                               ; %llm_attention.contiguous_copy.exit354
	mov.d	x9, v4[1]
	add	x9, x8, x9, lsl #2
LBB0_11:                                ; %copy.chunk.i355
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x9], #16
	str	q0, [x21, x10, lsl #4]
	add	x10, x10, #1
	cmp	x10, #192
	b.ne	LBB0_11
; %bb.12:                               ; %llm_attention.contiguous_copy.exit358
	fmov	x9, d2
	add	x9, x8, x9, lsl #2
LBB0_13:                                ; %copy.chunk.i359
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x9], #16
	str	q0, [x21, x10, lsl #4]
	add	x10, x10, #1
	cmp	x10, #224
	b.ne	LBB0_13
; %bb.14:                               ; %llm_attention.contiguous_copy.exit362
	str	x12, [sp, #256]                 ; 8-byte Spill
	stp	q1, q4, [sp, #16]               ; 32-byte Folded Spill
	stp	q3, q2, [sp, #48]               ; 32-byte Folded Spill
	str	x11, [sp, #88]                  ; 8-byte Spill
	mov.d	x9, v2[1]
	add	x8, x8, x9, lsl #2
	mov	w9, #224                        ; =0xe0
LBB0_15:                                ; %copy.chunk.i363
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q0, [x8], #16
	str	q0, [x21, x9, lsl #4]
	add	x9, x9, #1
	cmp	x9, #256
	b.ne	LBB0_15
; %bb.16:                               ; %direct.true.preheader
	add	x25, x21, #1, lsl #12           ; =4096
	add	x0, x21, #1, lsl #12            ; =4096
	mov	w1, #4096                       ; =0x1000
	bl	_bzero
	mov	x4, #0                          ; =0x0
	add	x11, x21, #3, lsl #12           ; =12288
	add	x0, x21, #19, lsl #12           ; =77824
	add	x20, x22, #512
	add	x8, x21, #35, lsl #12           ; =143360
	add	x19, x8, #1024
	ldr	q0, [sp, #2080]                 ; 16-byte Reload
	shrn.2s	v0, v0, #2
	ldr	q1, [sp, #2048]                 ; 16-byte Reload
	shrn.2s	v1, v1, #2
	ldr	q2, [sp, #2096]                 ; 16-byte Reload
	shrn.2s	v2, v2, #2
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	shrn.2s	v3, v3, #2
	mov	w8, #8193                       ; =0x2001
	dup.2s	v4, w8
	umull.2d	v6, v3, v4
	umull.2d	v5, v2, v4
	stp	q5, q6, [sp, #128]              ; 32-byte Folded Spill
	umull.2d	v5, v1, v4
	umull.2d	v4, v0, v4
	stp	q4, q5, [sp, #96]               ; 32-byte Folded Spill
	add	x12, x21, #5, lsl #12           ; =20480
	add	x13, x21, #7, lsl #12           ; =28672
	add	x14, x21, #9, lsl #12           ; =36864
	add	x15, x21, #11, lsl #12          ; =45056
	add	x16, x21, #13, lsl #12          ; =53248
	add	x1, x21, #15, lsl #12           ; =61440
	add	x2, x21, #17, lsl #12           ; =69632
	add	x3, x21, #21, lsl #12           ; =86016
	mov	w8, #128                        ; =0x80
	movk	w8, #16, lsl #16
	dup.2s	v4, w8
	add	x5, x21, #33, lsl #12           ; =135168
	umull.2d	v7, v3, v4
	umull.2d	v16, v2, v4
	umull.2d	v17, v1, v4
	umull.2d	v18, v0, v4
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v1, w8
	ldr	x17, [sp, #264]                 ; 8-byte Reload
	dup.2d	v19, x17
Lloh4:
	adrp	x8, lCPI0_6@PAGE
Lloh5:
	ldr	q20, [x8, lCPI0_6@PAGEOFF]
Lloh6:
	adrp	x8, lCPI0_7@PAGE
Lloh7:
	ldr	q21, [x8, lCPI0_7@PAGEOFF]
Lloh8:
	adrp	x8, lCPI0_8@PAGE
Lloh9:
	ldr	q11, [x8, lCPI0_8@PAGEOFF]
Lloh10:
	adrp	x8, lCPI0_9@PAGE
Lloh11:
	ldr	q12, [x8, lCPI0_9@PAGEOFF]
Lloh12:
	adrp	x8, lCPI0_2@PAGE
Lloh13:
	ldr	q13, [x8, lCPI0_2@PAGEOFF]
Lloh14:
	adrp	x8, lCPI0_3@PAGE
Lloh15:
	ldr	q14, [x8, lCPI0_3@PAGEOFF]
Lloh16:
	adrp	x8, lCPI0_4@PAGE
Lloh17:
	ldr	q15, [x8, lCPI0_4@PAGEOFF]
Lloh18:
	adrp	x8, lCPI0_5@PAGE
Lloh19:
	ldr	q27, [x8, lCPI0_5@PAGEOFF]
	mov	w6, #2560                       ; =0xa00
	mov	w27, #4608                      ; =0x1200
	mov	w28, #5120                      ; =0x1400
	mov	w26, #5632                      ; =0x1600
	mov	w24, #6656                      ; =0x1a00
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	stp	q0, q19, [sp, #160]             ; 32-byte Folded Spill
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	mov.16b	v0, v1
	mov	w23, #3                         ; =0x3
	stp	q16, q7, [sp, #224]             ; 32-byte Folded Spill
	stp	q18, q17, [sp, #192]            ; 32-byte Folded Spill
	str	q20, [sp, #2032]                ; 16-byte Spill
	str	q21, [sp, #2016]                ; 16-byte Spill
	str	q11, [sp, #2000]                ; 16-byte Spill
	str	q12, [sp, #1984]                ; 16-byte Spill
	str	q13, [sp, #2096]                ; 16-byte Spill
	str	q14, [sp, #2080]                ; 16-byte Spill
	str	q15, [sp, #2064]                ; 16-byte Spill
	str	q27, [sp, #2048]                ; 16-byte Spill
LBB0_17:                                ; %direct.true152
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
                                        ;     Child Loop BB0_37 Depth 2
                                        ;     Child Loop BB0_39 Depth 2
                                        ;     Child Loop BB0_41 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_45 Depth 2
                                        ;     Child Loop BB0_47 Depth 2
                                        ;     Child Loop BB0_49 Depth 2
                                        ;     Child Loop BB0_51 Depth 2
                                        ;     Child Loop BB0_53 Depth 2
                                        ;     Child Loop BB0_20 Depth 2
                                        ;     Child Loop BB0_69 Depth 2
                                        ;     Child Loop BB0_55 Depth 2
                                        ;     Child Loop BB0_57 Depth 2
                                        ;     Child Loop BB0_59 Depth 2
                                        ;     Child Loop BB0_61 Depth 2
                                        ;     Child Loop BB0_63 Depth 2
                                        ;       Child Loop BB0_64 Depth 3
	str	q0, [sp, #1920]                 ; 16-byte Spill
	str	q1, [sp, #1936]                 ; 16-byte Spill
	dup.2d	v1, x11
	dup.2d	v0, x0
	cmp	x4, #512
	b.ne	LBB0_22
; %bb.18:                               ; %direct.true702.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	ldr	x17, [sp, #256]                 ; 8-byte Reload
	b	LBB0_20
LBB0_19:                                ; %direct.schedule.49
                                        ;   in Loop: Header=BB0_20 Depth=2
	dup.2d	v4, x8
	add.2d	v4, v1, v4
	add.2d	v5, v4, v14
	add.2d	v6, v4, v13
	mov.d	x10, v6[1]
	fmov	x11, d6
	str	s3, [x11]
	st1.s	{ v3 }[1], [x10]
	mov.d	x10, v5[1]
	add.2d	v6, v4, v15
	fmov	x11, d5
	st1.s	{ v3 }[2], [x11]
	st1.s	{ v3 }[3], [x10]
	mov.d	x10, v6[1]
	fmov	x11, d6
	str	s2, [x11]
	st1.s	{ v2 }[1], [x10]
	add.2d	v3, v4, v27
	mov.d	x10, v3[1]
	fmov	x11, d3
	st1.s	{ v2 }[2], [x11]
	st1.s	{ v2 }[3], [x10]
	add	x9, x9, #1
	add	x8, x8, #4
	cmp	x9, #2048
	b.eq	LBB0_67
LBB0_20:                                ; %direct.true702
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	cmp	x9, #127
	b.hi	LBB0_19
; %bb.21:                               ; %direct.true715
                                        ;   in Loop: Header=BB0_20 Depth=2
	add	x10, x9, #256, lsl #12          ; =1048576
	dup.2d	v2, x10
	add.2d	v3, v2, v18
	add.2d	v4, v2, v17
	add.2d	v5, v2, v16
	add.2d	v2, v2, v7
	shl.2d	v2, v2, #2
	shl.2d	v5, v5, #2
	shl.2d	v4, v4, #2
	shl.2d	v3, v3, #2
	add.2d	v3, v19, v3
	add.2d	v4, v19, v4
	add.2d	v5, v19, v5
	add.2d	v2, v19, v2
	mov.d	x10, v2[1]
	fmov	x11, d2
	mov.d	x12, v5[1]
	fmov	x13, d5
	mov.d	x14, v4[1]
	fmov	x15, d4
	mov.d	x16, v3[1]
	ldr	s2, [x15]
	ld1.s	{ v2 }[1], [x14]
	fmov	x14, d3
	ld1.s	{ v2 }[2], [x14]
	ld1.s	{ v2 }[3], [x16]
	ldr	s3, [x11]
	ld1.s	{ v3 }[1], [x10]
	ld1.s	{ v3 }[2], [x13]
	ld1.s	{ v3 }[3], [x12]
	b	LBB0_19
LBB0_22:                                ; %direct.true155
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x9, #0                          ; =0x0
	lsl	x8, x4, #4
	dup.2d	v2, x8
	ldr	q3, [sp, #144]                  ; 16-byte Reload
	add.2d	v5, v2, v3
	ldr	q3, [sp, #96]                   ; 16-byte Reload
	add.2d	v6, v2, v3
	ldp	q3, q7, [sp, #112]              ; 32-byte Folded Reload
	add.2d	v4, v2, v7
	add.2d	v2, v2, v3
	shl.2d	v3, v2, #7
	shl.2d	v4, v4, #7
	shl.2d	v2, v6, #7
	shl.2d	v5, v5, #7
	fmov	x8, d5
	add	x10, x17, x8, lsl #2
LBB0_23:                                ; %copy.chunk.i367
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q6, [x10, x9]
	str	q6, [x11, x9]
	add	x9, x9, #16
	cmp	x9, #2, lsl #12                 ; =8192
	b.ne	LBB0_23
; %bb.24:                               ; %llm_attention.contiguous_copy.1.exit
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x10, #0                         ; =0x0
	mov.d	x9, v5[1]
	add	x11, x17, x9, lsl #2
LBB0_25:                                ; %copy.chunk.i370
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q5, [x11, x10]
	str	q5, [x12, x10]
	add	x10, x10, #16
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB0_25
; %bb.26:                               ; %llm_attention.contiguous_copy.1.exit373
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x11, #0                         ; =0x0
	fmov	x10, d4
	add	x12, x17, x10, lsl #2
LBB0_27:                                ; %copy.chunk.i374
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q5, [x12, x11]
	str	q5, [x13, x11]
	add	x11, x11, #16
	cmp	x11, #2, lsl #12                ; =8192
	b.ne	LBB0_27
; %bb.28:                               ; %llm_attention.contiguous_copy.1.exit377
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x12, #0                         ; =0x0
	mov.d	x11, v4[1]
	add	x13, x17, x11, lsl #2
LBB0_29:                                ; %copy.chunk.i378
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x13, x12]
	str	q4, [x14, x12]
	add	x12, x12, #16
	cmp	x12, #2, lsl #12                ; =8192
	b.ne	LBB0_29
; %bb.30:                               ; %llm_attention.contiguous_copy.1.exit381
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x13, #0                         ; =0x0
	fmov	x12, d3
	add	x14, x17, x12, lsl #2
LBB0_31:                                ; %copy.chunk.i382
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q4, [x14, x13]
	str	q4, [x15, x13]
	add	x13, x13, #16
	cmp	x13, #2, lsl #12                ; =8192
	b.ne	LBB0_31
; %bb.32:                               ; %llm_attention.contiguous_copy.1.exit385
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x14, #0                         ; =0x0
	mov.d	x13, v3[1]
	add	x15, x17, x13, lsl #2
LBB0_33:                                ; %copy.chunk.i386
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x15, x14]
	str	q3, [x16, x14]
	add	x14, x14, #16
	cmp	x14, #2, lsl #12                ; =8192
	b.ne	LBB0_33
; %bb.34:                               ; %llm_attention.contiguous_copy.1.exit389
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x15, #0                         ; =0x0
	fmov	x14, d2
	add	x16, x17, x14, lsl #2
LBB0_35:                                ; %copy.chunk.i390
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x16, x15]
	str	q3, [x1, x15]
	add	x15, x15, #16
	cmp	x15, #2, lsl #12                ; =8192
	b.ne	LBB0_35
; %bb.36:                               ; %llm_attention.contiguous_copy.1.exit393
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x16, #0                         ; =0x0
	mov.d	x15, v2[1]
	add	x17, x17, x15, lsl #2
LBB0_37:                                ; %copy.chunk.i394
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x17, x16]
	str	q2, [x2, x16]
	add	x16, x16, #16
	cmp	x16, #2, lsl #12                ; =8192
	b.ne	LBB0_37
; %bb.38:                               ; %direct.true181
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x16, #0                         ; =0x0
	ldr	x17, [sp, #256]                 ; 8-byte Reload
	add	x8, x17, x8, lsl #2
LBB0_39:                                ; %copy.chunk.i398
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x8, x16]
	str	q2, [x0, x16]
	add	x16, x16, #16
	cmp	x16, #2, lsl #12                ; =8192
	b.ne	LBB0_39
; %bb.40:                               ; %llm_attention.contiguous_copy.2.exit
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x17, x9, lsl #2
LBB0_41:                                ; %copy.chunk.i401
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x9, x8]
	str	q2, [x3, x8]
	add	x8, x8, #16
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_41
; %bb.42:                               ; %llm_attention.contiguous_copy.2.exit404
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x17, x10, lsl #2
	add	x10, x21, #23, lsl #12          ; =94208
LBB0_43:                                ; %copy.chunk.i405
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x9, x8]
	str	q2, [x10, x8]
	add	x8, x8, #16
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_43
; %bb.44:                               ; %llm_attention.contiguous_copy.2.exit408
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x17, x11, lsl #2
	add	x10, x21, #25, lsl #12          ; =102400
LBB0_45:                                ; %copy.chunk.i409
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x9, x8]
	str	q2, [x10, x8]
	add	x8, x8, #16
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_45
; %bb.46:                               ; %llm_attention.contiguous_copy.2.exit412
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x17, x12, lsl #2
	add	x10, x21, #27, lsl #12          ; =110592
	add	x11, x21, #31, lsl #12          ; =126976
LBB0_47:                                ; %copy.chunk.i413
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x9, x8]
	str	q2, [x10, x8]
	add	x8, x8, #16
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_47
; %bb.48:                               ; %llm_attention.contiguous_copy.2.exit416
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x17, x13, lsl #2
	add	x10, x21, #29, lsl #12          ; =118784
LBB0_49:                                ; %copy.chunk.i417
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x9, x8]
	str	q2, [x10, x8]
	add	x8, x8, #16
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_49
; %bb.50:                               ; %llm_attention.contiguous_copy.2.exit420
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x17, x14, lsl #2
LBB0_51:                                ; %copy.chunk.i421
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x9, x8]
	str	q2, [x11, x8]
	add	x8, x8, #16
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_51
; %bb.52:                               ; %llm_attention.contiguous_copy.2.exit424
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	add	x9, x17, x15, lsl #2
LBB0_53:                                ; %copy.chunk.i425
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q2, [x9, x8]
	str	q2, [x5, x8]
	add	x8, x8, #16
	cmp	x8, #2, lsl #12                 ; =8192
	b.ne	LBB0_53
LBB0_54:                                ; %direct.true208.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q23, [sp, #1504]                ; 16-byte Spill
	str	q22, [sp, #1520]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	movi.2d	v23, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
LBB0_55:                                ; %direct.true208
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v2, x8
	dup.2d	v31, x21
	add.2d	v3, v31, v2
	add.2d	v4, v3, v12
	add.2d	v5, v3, v11
	add.2d	v6, v3, v21
	add.2d	v3, v3, v20
	mov.d	x14, v3[1]
	fmov	x12, d3
	mov.d	x9, v6[1]
	fmov	x13, d6
	mov.d	x16, v5[1]
	fmov	x10, d5
	mov.d	x11, v4[1]
	add.2d	v2, v1, v2
	add.2d	v6, v2, v27
	add.2d	v5, v2, v15
	fmov	x17, d4
	add.2d	v3, v2, v14
	add.2d	v2, v2, v13
	mov.d	x0, v2[1]
	fmov	x1, d2
	ldr	s2, [x10]
	mov.d	x10, v3[1]
	fmov	x15, d3
	mov.d	x2, v5[1]
	ldr	s3, [x12]
	fmov	x3, d5
	mov.d	x12, v6[1]
	ldr	s4, [x3]
	orr	x3, x8, #0x200
	ldr	s5, [x1]
	dup.2d	v7, x3
	fmov	x1, d6
	add.2d	v6, v1, v7
	ld1.s	{ v2 }[1], [x16]
	add.2d	v16, v6, v27
	add.2d	v7, v6, v15
	add.2d	v17, v6, v14
	add.2d	v18, v6, v13
	ld1.s	{ v3 }[1], [x14]
	mov.d	x3, v18[1]
	mov.d	x16, v7[1]
	ld1.s	{ v4 }[1], [x2]
	fmov	x14, d7
	ldr	s6, [x14]
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[1], [x0]
	ld1.s	{ v6 }[1], [x16]
	mov.d	x16, v16[1]
	ld1.s	{ v2 }[2], [x17]
	fmov	x17, d18
	ldr	s7, [x17]
	ld1.s	{ v7 }[1], [x3]
	ld1.s	{ v3 }[2], [x13]
	fmov	x0, d17
	orr	x13, x8, #0x400
	dup.2d	v17, x13
	ld1.s	{ v4 }[2], [x1]
	fmov	x13, d16
	add.2d	v16, v1, v17
	add.2d	v17, v16, v15
	add.2d	v18, v16, v13
	ld1.s	{ v5 }[2], [x15]
	mov.d	x15, v18[1]
	fmov	x17, d18
	add.2d	v18, v16, v14
	ld1.s	{ v6 }[2], [x13]
	mov.d	x13, v18[1]
	mov.d	x1, v17[1]
	ld1.s	{ v7 }[2], [x0]
	add.2d	v16, v16, v27
	fmov	x0, d17
	ldr	s17, [x0]
	fmov	x0, d18
	ld1.s	{ v2 }[3], [x11]
	mov.d	x11, v16[1]
	ld1.s	{ v17 }[1], [x1]
	ld1.s	{ v3 }[3], [x9]
	fmov	x9, d16
	ld1.s	{ v17 }[2], [x9]
	orr	x9, x8, #0x600
	ld1.s	{ v4 }[3], [x12]
	dup.2d	v16, x9
	add.2d	v16, v1, v16
	add.2d	v18, v16, v13
	ld1.s	{ v5 }[3], [x10]
	mov.d	x9, v18[1]
	fmov	x10, d18
	add.2d	v18, v16, v15
	ld1.s	{ v6 }[3], [x16]
	mov.d	x12, v18[1]
	fmov	x16, d18
	add.2d	v18, v16, v27
	ld1.s	{ v7 }[3], [x14]
	mov.d	x14, v18[1]
	fmov	x1, d18
	ldr	s18, [x17]
	ld1.s	{ v17 }[3], [x11]
	ld1.s	{ v18 }[1], [x15]
	fmul.4s	v5, v3, v5
	fmul.4s	v4, v2, v4
	fmul.4s	v7, v3, v7
	fadd.4s	v23, v23, v4
	fmul.4s	v4, v2, v6
	ld1.s	{ v18 }[2], [x0]
	ld1.s	{ v18 }[3], [x13]
	fadd.4s	v30, v30, v5
	fmul.4s	v5, v3, v18
	fmul.4s	v6, v2, v17
	add.2d	v16, v16, v14
	mov.d	x11, v16[1]
	fadd.4s	v29, v29, v4
	ldr	s4, [x16]
	ld1.s	{ v4 }[1], [x12]
	ld1.s	{ v4 }[2], [x1]
	fadd.4s	v28, v28, v7
	ld1.s	{ v4 }[3], [x14]
	ldr	s7, [x10]
	ld1.s	{ v7 }[1], [x9]
	fadd.4s	v26, v26, v6
	fmov	x9, d16
	ld1.s	{ v7 }[2], [x9]
	ld1.s	{ v7 }[3], [x11]
	fadd.4s	v25, v25, v5
	fmul.4s	v3, v3, v7
	fmul.4s	v2, v2, v4
	fadd.4s	v24, v24, v2
	fadd.4s	v22, v22, v3
	add	x8, x8, #4
	cmp	x8, #512
	b.ne	LBB0_55
; %bb.56:                               ; %direct.true235.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q30, [sp, #1824]                ; 16-byte Spill
	str	q29, [sp, #1840]                ; 16-byte Spill
	str	q28, [sp, #1856]                ; 16-byte Spill
	str	q26, [sp, #1872]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	movi.2d	v30, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v26, #0000000000000000
LBB0_57:                                ; %direct.true235
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v2, x8
	add.2d	v2, v31, v2
	add.2d	v3, v2, v12
	add.2d	v4, v2, v11
	add.2d	v5, v2, v21
	add.2d	v2, v2, v20
	mov.d	x14, v2[1]
	fmov	x10, d2
	mov.d	x9, v5[1]
	fmov	x13, d5
	mov.d	x17, v4[1]
	fmov	x12, d4
	mov.d	x11, v3[1]
	fmov	x15, d3
	ldr	s2, [x12]
	orr	x12, x8, #0x800
	dup.2d	v3, x12
	add.2d	v4, v1, v3
	ldr	s3, [x10]
	add.2d	v6, v4, v27
	add.2d	v5, v4, v15
	add.2d	v7, v4, v14
	add.2d	v4, v4, v13
	mov.d	x0, v4[1]
	fmov	x1, d4
	mov.d	x10, v7[1]
	fmov	x16, d7
	mov.d	x2, v5[1]
	fmov	x3, d5
	mov.d	x12, v6[1]
	ldr	s4, [x3]
	orr	x3, x8, x6
	ldr	s5, [x1]
	dup.2d	v7, x3
	fmov	x1, d6
	add.2d	v6, v1, v7
	ld1.s	{ v2 }[1], [x17]
	add.2d	v16, v6, v27
	add.2d	v7, v6, v15
	add.2d	v17, v6, v14
	add.2d	v18, v6, v13
	ld1.s	{ v3 }[1], [x14]
	mov.d	x3, v18[1]
	mov.d	x17, v7[1]
	ld1.s	{ v4 }[1], [x2]
	fmov	x14, d7
	ldr	s6, [x14]
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[1], [x0]
	ld1.s	{ v6 }[1], [x17]
	mov.d	x17, v16[1]
	ld1.s	{ v2 }[2], [x15]
	fmov	x15, d18
	ldr	s7, [x15]
	ld1.s	{ v7 }[1], [x3]
	ld1.s	{ v3 }[2], [x13]
	fmov	x0, d17
	orr	x13, x8, #0xc00
	dup.2d	v17, x13
	ld1.s	{ v4 }[2], [x1]
	fmov	x13, d16
	add.2d	v16, v1, v17
	add.2d	v17, v16, v15
	add.2d	v18, v16, v13
	ld1.s	{ v5 }[2], [x16]
	mov.d	x15, v18[1]
	fmov	x16, d18
	add.2d	v18, v16, v14
	ld1.s	{ v6 }[2], [x13]
	mov.d	x13, v18[1]
	mov.d	x1, v17[1]
	ld1.s	{ v7 }[2], [x0]
	add.2d	v16, v16, v27
	fmov	x0, d17
	ldr	s17, [x0]
	fmov	x0, d18
	ld1.s	{ v2 }[3], [x11]
	mov.d	x11, v16[1]
	ld1.s	{ v17 }[1], [x1]
	ld1.s	{ v3 }[3], [x9]
	fmov	x9, d16
	ld1.s	{ v17 }[2], [x9]
	orr	x9, x8, #0xe00
	ld1.s	{ v4 }[3], [x12]
	dup.2d	v16, x9
	add.2d	v16, v1, v16
	add.2d	v18, v16, v13
	ld1.s	{ v5 }[3], [x10]
	mov.d	x9, v18[1]
	fmov	x10, d18
	add.2d	v18, v16, v15
	ld1.s	{ v6 }[3], [x17]
	mov.d	x12, v18[1]
	fmov	x17, d18
	add.2d	v18, v16, v27
	ld1.s	{ v7 }[3], [x14]
	mov.d	x14, v18[1]
	fmov	x1, d18
	ldr	s18, [x16]
	ld1.s	{ v17 }[3], [x11]
	ld1.s	{ v18 }[1], [x15]
	fmul.4s	v5, v3, v5
	fmul.4s	v4, v2, v4
	fmul.4s	v7, v3, v7
	fadd.4s	v30, v30, v4
	fmul.4s	v4, v2, v6
	ld1.s	{ v18 }[2], [x0]
	ld1.s	{ v18 }[3], [x13]
	fadd.4s	v26, v26, v5
	fmul.4s	v5, v3, v18
	fmul.4s	v6, v2, v17
	add.2d	v16, v16, v14
	mov.d	x11, v16[1]
	fadd.4s	v19, v19, v4
	ldr	s4, [x17]
	ld1.s	{ v4 }[1], [x12]
	ld1.s	{ v4 }[2], [x1]
	fadd.4s	v10, v10, v7
	ld1.s	{ v4 }[3], [x14]
	ldr	s7, [x10]
	ld1.s	{ v7 }[1], [x9]
	fadd.4s	v9, v9, v6
	fmov	x9, d16
	ld1.s	{ v7 }[2], [x9]
	ld1.s	{ v7 }[3], [x11]
	fadd.4s	v8, v8, v5
	fmul.4s	v3, v3, v7
	fmul.4s	v2, v2, v4
	fadd.4s	v29, v29, v2
	fadd.4s	v28, v28, v3
	add	x8, x8, #4
	cmp	x8, #512
	b.ne	LBB0_57
; %bb.58:                               ; %direct.true263.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	str	q26, [sp, #1680]                ; 16-byte Spill
	str	q19, [sp, #1696]                ; 16-byte Spill
	str	q10, [sp, #1712]                ; 16-byte Spill
	str	q9, [sp, #1728]                 ; 16-byte Spill
	str	q8, [sp, #1760]                 ; 16-byte Spill
	str	q30, [sp, #1776]                ; 16-byte Spill
	str	q29, [sp, #1792]                ; 16-byte Spill
	str	q28, [sp, #1808]                ; 16-byte Spill
	str	q25, [sp, #1888]                ; 16-byte Spill
	str	q24, [sp, #1904]                ; 16-byte Spill
	str	q23, [sp, #1952]                ; 16-byte Spill
	str	q22, [sp, #1968]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	mov.16b	v19, v27
	movi.2d	v29, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v30, #0000000000000000
	mov.16b	v26, v31
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
LBB0_59:                                ; %direct.true263
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v2, x8
	add.2d	v2, v26, v2
	add.2d	v3, v2, v12
	add.2d	v4, v2, v11
	add.2d	v5, v2, v21
	add.2d	v2, v2, v20
	mov.d	x14, v2[1]
	fmov	x10, d2
	mov.d	x9, v5[1]
	fmov	x13, d5
	mov.d	x17, v4[1]
	fmov	x12, d4
	mov.d	x11, v3[1]
	fmov	x15, d3
	ldr	s2, [x12]
	orr	x12, x8, #0x1000
	dup.2d	v3, x12
	add.2d	v4, v1, v3
	ldr	s3, [x10]
	add.2d	v6, v4, v19
	add.2d	v5, v4, v15
	add.2d	v7, v4, v14
	add.2d	v4, v4, v13
	mov.d	x0, v4[1]
	fmov	x1, d4
	mov.d	x10, v7[1]
	fmov	x16, d7
	mov.d	x2, v5[1]
	fmov	x3, d5
	mov.d	x12, v6[1]
	ldr	s4, [x3]
	orr	x3, x8, x27
	ldr	s5, [x1]
	dup.2d	v7, x3
	fmov	x1, d6
	add.2d	v6, v1, v7
	ld1.s	{ v2 }[1], [x17]
	add.2d	v16, v6, v19
	add.2d	v7, v6, v15
	add.2d	v17, v6, v14
	add.2d	v18, v6, v13
	ld1.s	{ v3 }[1], [x14]
	mov.d	x3, v18[1]
	mov.d	x17, v7[1]
	ld1.s	{ v4 }[1], [x2]
	fmov	x14, d7
	ldr	s6, [x14]
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[1], [x0]
	ld1.s	{ v6 }[1], [x17]
	mov.d	x17, v16[1]
	ld1.s	{ v2 }[2], [x15]
	fmov	x15, d18
	ldr	s7, [x15]
	ld1.s	{ v7 }[1], [x3]
	ld1.s	{ v3 }[2], [x13]
	fmov	x0, d17
	orr	x13, x8, x28
	dup.2d	v17, x13
	ld1.s	{ v4 }[2], [x1]
	fmov	x13, d16
	add.2d	v16, v1, v17
	add.2d	v17, v16, v15
	add.2d	v18, v16, v13
	ld1.s	{ v5 }[2], [x16]
	mov.d	x15, v18[1]
	fmov	x16, d18
	add.2d	v18, v16, v14
	ld1.s	{ v6 }[2], [x13]
	mov.d	x13, v18[1]
	mov.d	x1, v17[1]
	ld1.s	{ v7 }[2], [x0]
	add.2d	v16, v16, v19
	fmov	x0, d17
	ldr	s17, [x0]
	fmov	x0, d18
	ld1.s	{ v2 }[3], [x11]
	mov.d	x11, v16[1]
	ld1.s	{ v17 }[1], [x1]
	ld1.s	{ v3 }[3], [x9]
	fmov	x9, d16
	ld1.s	{ v17 }[2], [x9]
	orr	x9, x8, x26
	ld1.s	{ v4 }[3], [x12]
	dup.2d	v16, x9
	add.2d	v16, v1, v16
	add.2d	v18, v16, v13
	ld1.s	{ v5 }[3], [x10]
	mov.d	x9, v18[1]
	fmov	x10, d18
	add.2d	v18, v16, v15
	ld1.s	{ v6 }[3], [x17]
	mov.d	x12, v18[1]
	fmov	x17, d18
	add.2d	v18, v16, v19
	ld1.s	{ v7 }[3], [x14]
	mov.d	x14, v18[1]
	fmov	x1, d18
	ldr	s18, [x16]
	ld1.s	{ v17 }[3], [x11]
	ld1.s	{ v18 }[1], [x15]
	fmul.4s	v5, v3, v5
	fmul.4s	v4, v2, v4
	fmul.4s	v7, v3, v7
	fadd.4s	v29, v29, v4
	fmul.4s	v4, v2, v6
	ld1.s	{ v18 }[2], [x0]
	ld1.s	{ v18 }[3], [x13]
	fadd.4s	v10, v10, v5
	fmul.4s	v5, v3, v18
	fmul.4s	v6, v2, v17
	add.2d	v16, v16, v14
	mov.d	x11, v16[1]
	fadd.4s	v9, v9, v4
	ldr	s4, [x17]
	ld1.s	{ v4 }[1], [x12]
	ld1.s	{ v4 }[2], [x1]
	fadd.4s	v8, v8, v7
	ld1.s	{ v4 }[3], [x14]
	ldr	s7, [x10]
	ld1.s	{ v7 }[1], [x9]
	fadd.4s	v31, v31, v6
	fmov	x9, d16
	ld1.s	{ v7 }[2], [x9]
	ld1.s	{ v7 }[3], [x11]
	fadd.4s	v30, v30, v5
	fmul.4s	v3, v3, v7
	fmul.4s	v2, v2, v4
	fadd.4s	v28, v28, v2
	fadd.4s	v27, v27, v3
	add	x8, x8, #4
	cmp	x8, #512
	b.ne	LBB0_59
; %bb.60:                               ; %direct.true291.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	movi.2d	v13, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v15, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
LBB0_61:                                ; %direct.true291
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v5, x8
	add.2d	v5, v26, v5
	ldr	q6, [sp, #1984]                 ; 16-byte Reload
	add.2d	v6, v5, v6
	ldr	q7, [sp, #2000]                 ; 16-byte Reload
	add.2d	v7, v5, v7
	ldr	q16, [sp, #2016]                ; 16-byte Reload
	add.2d	v16, v5, v16
	ldr	q17, [sp, #2032]                ; 16-byte Reload
	add.2d	v5, v5, v17
	mov.d	x14, v5[1]
	fmov	x10, d5
	mov.d	x9, v16[1]
	fmov	x13, d16
	mov.d	x17, v7[1]
	fmov	x12, d7
	mov.d	x11, v6[1]
	fmov	x15, d6
	ldr	s5, [x12]
	orr	x12, x8, #0x1800
	dup.2d	v6, x12
	add.2d	v7, v1, v6
	ldr	s6, [x10]
	ldr	q25, [sp, #2048]                ; 16-byte Reload
	add.2d	v17, v7, v25
	ldr	q24, [sp, #2064]                ; 16-byte Reload
	add.2d	v16, v7, v24
	ldr	q23, [sp, #2080]                ; 16-byte Reload
	add.2d	v18, v7, v23
	ldr	q22, [sp, #2096]                ; 16-byte Reload
	add.2d	v7, v7, v22
	mov.d	x0, v7[1]
	fmov	x1, d7
	mov.d	x10, v18[1]
	fmov	x16, d18
	mov.d	x2, v16[1]
	fmov	x3, d16
	mov.d	x12, v17[1]
	ldr	s7, [x3]
	orr	x3, x8, x24
	ldr	s16, [x1]
	dup.2d	v18, x3
	fmov	x1, d17
	add.2d	v17, v1, v18
	ld1.s	{ v5 }[1], [x17]
	add.2d	v19, v17, v25
	add.2d	v18, v17, v24
	add.2d	v20, v17, v23
	add.2d	v21, v17, v22
	ld1.s	{ v6 }[1], [x14]
	mov.d	x3, v21[1]
	mov.d	x17, v18[1]
	ld1.s	{ v7 }[1], [x2]
	fmov	x14, d18
	ldr	s17, [x14]
	mov.d	x14, v20[1]
	ld1.s	{ v16 }[1], [x0]
	ld1.s	{ v17 }[1], [x17]
	mov.d	x17, v19[1]
	ld1.s	{ v5 }[2], [x15]
	fmov	x15, d21
	ldr	s18, [x15]
	ld1.s	{ v18 }[1], [x3]
	ld1.s	{ v6 }[2], [x13]
	fmov	x0, d20
	orr	x13, x8, #0x1c00
	dup.2d	v20, x13
	ld1.s	{ v7 }[2], [x1]
	fmov	x13, d19
	add.2d	v19, v1, v20
	add.2d	v20, v19, v24
	add.2d	v21, v19, v22
	ld1.s	{ v16 }[2], [x16]
	mov.d	x15, v21[1]
	fmov	x16, d21
	add.2d	v21, v19, v23
	ld1.s	{ v17 }[2], [x13]
	mov.d	x13, v21[1]
	mov.d	x1, v20[1]
	ld1.s	{ v18 }[2], [x0]
	add.2d	v19, v19, v25
	fmov	x0, d20
	ldr	s20, [x0]
	fmov	x0, d21
	ld1.s	{ v5 }[3], [x11]
	mov.d	x11, v19[1]
	ld1.s	{ v20 }[1], [x1]
	ld1.s	{ v6 }[3], [x9]
	fmov	x9, d19
	ld1.s	{ v20 }[2], [x9]
	orr	x9, x8, #0x1e00
	ld1.s	{ v7 }[3], [x12]
	dup.2d	v19, x9
	add.2d	v19, v1, v19
	add.2d	v21, v19, v22
	ld1.s	{ v16 }[3], [x10]
	mov.d	x9, v21[1]
	fmov	x10, d21
	add.2d	v21, v19, v24
	ld1.s	{ v17 }[3], [x17]
	mov.d	x12, v21[1]
	fmov	x17, d21
	add.2d	v21, v19, v25
	ld1.s	{ v18 }[3], [x14]
	mov.d	x14, v21[1]
	fmov	x1, d21
	ldr	s21, [x16]
	ld1.s	{ v20 }[3], [x11]
	ld1.s	{ v21 }[1], [x15]
	fmul.4s	v16, v6, v16
	fmul.4s	v7, v5, v7
	fmul.4s	v18, v6, v18
	fadd.4s	v13, v13, v7
	fmul.4s	v7, v5, v17
	ld1.s	{ v21 }[2], [x0]
	ld1.s	{ v21 }[3], [x13]
	fadd.4s	v4, v4, v16
	fmul.4s	v16, v6, v21
	fmul.4s	v17, v5, v20
	add.2d	v19, v19, v23
	mov.d	x11, v19[1]
	fadd.4s	v3, v3, v7
	ldr	s7, [x17]
	ld1.s	{ v7 }[1], [x12]
	ld1.s	{ v7 }[2], [x1]
	fadd.4s	v2, v2, v18
	ld1.s	{ v7 }[3], [x14]
	ldr	s18, [x10]
	ld1.s	{ v18 }[1], [x9]
	fadd.4s	v15, v15, v17
	fmov	x9, d19
	ld1.s	{ v18 }[2], [x9]
	ld1.s	{ v18 }[3], [x11]
	fadd.4s	v14, v14, v16
	fmul.4s	v6, v6, v18
	fmul.4s	v5, v5, v7
	fadd.4s	v12, v12, v5
	fadd.4s	v11, v11, v6
	add	x8, x8, #4
	cmp	x8, #512
	b.ne	LBB0_61
; %bb.62:                               ; %direct.false292
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	w9, #1267                       ; =0x4f3
	movk	w9, #15797, lsl #16
	dup.4s	v5, w9
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	fmul.4s	v1, v1, v5
	str	q1, [sp, #1744]                 ; 16-byte Spill
	ldr	q1, [sp, #1952]                 ; 16-byte Reload
	fmul.4s	v1, v1, v5
	str	q1, [sp, #1600]                 ; 16-byte Spill
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	fmul.4s	v6, v1, v5
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	fmul.4s	v7, v1, v5
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	fmul.4s	v16, v1, v5
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	fmul.4s	v17, v1, v5
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v18, v1, v5
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	fmul.4s	v19, v1, v5
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	fmul.4s	v20, v1, v5
	ldr	q1, [sp, #1680]                 ; 16-byte Reload
	fmul.4s	v21, v1, v5
	ldr	q1, [sp, #1696]                 ; 16-byte Reload
	fmul.4s	v25, v1, v5
	ldr	q1, [sp, #1712]                 ; 16-byte Reload
	fmul.4s	v24, v1, v5
	ldr	q1, [sp, #1728]                 ; 16-byte Reload
	fmul.4s	v26, v1, v5
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	fmul.4s	v22, v1, v5
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	fmul.4s	v1, v1, v5
	str	q1, [sp, #1856]                 ; 16-byte Spill
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	fmul.4s	v23, v1, v5
	fmul.4s	v29, v29, v5
	fmul.4s	v10, v10, v5
	fmul.4s	v9, v9, v5
	fmul.4s	v8, v8, v5
	fmul.4s	v31, v31, v5
	fmul.4s	v30, v30, v5
	fmul.4s	v1, v28, v5
	str	q1, [sp, #1728]                 ; 16-byte Spill
	fmul.4s	v27, v27, v5
	fmul.4s	v13, v13, v5
	fmul.4s	v4, v4, v5
	fmul.4s	v3, v3, v5
	fmul.4s	v2, v2, v5
	fmul.4s	v15, v15, v5
	fmul.4s	v14, v14, v5
	fmul.4s	v12, v12, v5
	fmul.4s	v11, v11, v5
	str	x4, [sp, #1544]                 ; 8-byte Spill
	cmp	x4, #512
	cset	w9, lo
	dup.4h	v5, w9
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	str	q5, [sp, #1456]                 ; 16-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v1, w9
	bif.16b	v7, v1, v5
	bif.16b	v6, v1, v5
	str	q6, [sp, #1584]                 ; 16-byte Spill
	mov.16b	v6, v5
	bsl.16b	v6, v17, v1
	str	q6, [sp, #1840]                 ; 16-byte Spill
	bif.16b	v16, v1, v5
	str	q16, [sp, #1568]                ; 16-byte Spill
	mov.16b	v16, v5
	bsl.16b	v16, v19, v1
	str	q16, [sp, #1904]                ; 16-byte Spill
	mov.16b	v17, v5
	bsl.16b	v17, v18, v1
	str	q17, [sp, #1952]                ; 16-byte Spill
	mov.16b	v18, v5
	bsl.16b	v18, v21, v1
	str	q18, [sp, #1824]                ; 16-byte Spill
	mov.16b	v17, v5
	bsl.16b	v17, v20, v1
	str	q17, [sp, #1968]                ; 16-byte Spill
	mov.16b	v20, v5
	bsl.16b	v20, v24, v1
	str	q20, [sp, #1888]                ; 16-byte Spill
	mov.16b	v28, v5
	bsl.16b	v28, v25, v1
	str	q28, [sp, #1616]                ; 16-byte Spill
	bif.16b	v22, v1, v5
	str	q22, [sp, #1808]                ; 16-byte Spill
	mov.16b	v25, v5
	bsl.16b	v25, v26, v1
	str	q25, [sp, #1632]                ; 16-byte Spill
	bif.16b	v23, v1, v5
	str	q23, [sp, #1872]                ; 16-byte Spill
	ldr	q17, [sp, #1856]                ; 16-byte Reload
	mov.16b	v24, v5
	bsl.16b	v24, v17, v1
	str	q24, [sp, #1648]                ; 16-byte Spill
	mov.16b	v26, v5
	bsl.16b	v26, v10, v1
	str	q26, [sp, #1792]                ; 16-byte Spill
	mov.16b	v21, v5
	bsl.16b	v21, v29, v1
	str	q21, [sp, #1664]                ; 16-byte Spill
	mov.16b	v29, v5
	bsl.16b	v29, v8, v1
	str	q29, [sp, #1856]                ; 16-byte Spill
	mov.16b	v8, v5
	bsl.16b	v8, v9, v1
	str	q8, [sp, #1680]                 ; 16-byte Spill
	bif.16b	v30, v1, v5
	str	q30, [sp, #1776]                ; 16-byte Spill
	mov.16b	v19, v5
	bsl.16b	v19, v31, v1
	str	q19, [sp, #1696]                ; 16-byte Spill
	mov.16b	v31, v5
	bsl.16b	v31, v27, v1
	str	q31, [sp, #1760]                ; 16-byte Spill
	ldr	q17, [sp, #1728]                ; 16-byte Reload
	mov.16b	v27, v5
	bsl.16b	v27, v17, v1
	str	q27, [sp, #1712]                ; 16-byte Spill
	bif.16b	v4, v1, v5
	str	q4, [sp, #1552]                 ; 16-byte Spill
	bif.16b	v13, v1, v5
	mov.16b	v9, v5
	bsl.16b	v9, v2, v1
	str	q9, [sp, #1120]                 ; 16-byte Spill
	mov.16b	v17, v5
	bsl.16b	v17, v3, v1
	str	q17, [sp, #1728]                ; 16-byte Spill
	mov.16b	v3, v5
	bsl.16b	v3, v14, v1
	str	q3, [sp, #1200]                 ; 16-byte Spill
	mov.16b	v14, v5
	bsl.16b	v14, v15, v1
	mov.16b	v10, v5
	bsl.16b	v10, v11, v1
	str	q10, [sp, #1296]                ; 16-byte Spill
	mov.16b	v15, v5
	bsl.16b	v15, v12, v1
	str	q15, [sp, #1280]                ; 16-byte Spill
	mvni.4s	v1, #127, msl #16
	ldr	q2, [sp, #1744]                 ; 16-byte Reload
	fmaxnm.4s	v1, v2, v1
	mvni.4s	v11, #127, msl #16
	fmaxnm.4s	v1, v1, v7
	mov.16b	v12, v7
	str	q7, [sp, #1376]                 ; 16-byte Spill
	fmaxnm.4s	v1, v1, v6
	fmaxnm.4s	v1, v1, v16
	fmaxnm.4s	v1, v1, v18
	fmaxnm.4s	v1, v1, v20
	fmaxnm.4s	v1, v1, v22
	fmaxnm.4s	v1, v1, v23
	fmaxnm.4s	v1, v1, v26
	fmaxnm.4s	v1, v1, v29
	fmaxnm.4s	v1, v1, v30
	fmaxnm.4s	v1, v1, v31
	fmaxnm.4s	v1, v1, v4
	fmaxnm.4s	v1, v1, v9
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v1, v1, v10
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	fmaxnm.4s	v10, v3, v1
	fsub.4s	v9, v2, v10
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v2, w9
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v5, w9
	fcmge.4s	v3, v9, v2
	fcmge.4s	v4, v5, v9
	and.16b	v3, v3, v4
	ldr	q6, [sp, #1600]                 ; 16-byte Reload
	fmaxnm.4s	v4, v6, v11
	ldr	q11, [sp, #1584]                ; 16-byte Reload
	fmaxnm.4s	v4, v4, v11
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	fmaxnm.4s	v4, v4, v1
	ldr	q7, [sp, #1952]                 ; 16-byte Reload
	fmaxnm.4s	v4, v4, v7
	ldr	q7, [sp, #1968]                 ; 16-byte Reload
	fmaxnm.4s	v4, v4, v7
	fmaxnm.4s	v4, v4, v28
	fmaxnm.4s	v4, v4, v25
	fmaxnm.4s	v4, v4, v24
	fmaxnm.4s	v4, v4, v21
	fmaxnm.4s	v4, v4, v8
	fmaxnm.4s	v4, v4, v19
	fmaxnm.4s	v4, v4, v27
	fmaxnm.4s	v4, v4, v13
	str	q13, [sp, #608]                 ; 16-byte Spill
	fmaxnm.4s	v4, v4, v17
	fmaxnm.4s	v4, v4, v14
	fmaxnm.4s	v4, v4, v15
	ldr	q7, [sp, #1920]                 ; 16-byte Reload
	fmaxnm.4s	v28, v7, v4
	fsub.4s	v27, v6, v28
	fcmge.4s	v4, v27, v2
	fcmge.4s	v6, v5, v27
	and.16b	v4, v4, v6
	and.16b	v4, v4, v27
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v22, w9
	fmul.4s	v6, v4, v22
	movi.4s	v29, #75, lsl #24
	mvni.4s	v30, #128, lsl #24
	mov.16b	v7, v30
	bsl.16b	v7, v29, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v7, v3, v9
	fmul.4s	v3, v7, v22
	mov.16b	v16, v30
	bsl.16b	v16, v29, v3
	fadd.4s	v3, v3, v16
	fsub.4s	v16, v3, v16
	fcvtzs.4s	v3, v6
	scvtf.4s	v6, v3
	mov	w9, #29184                      ; =0x7200
	movk	w9, #16177, lsl #16
	dup.4s	v21, w9
	fmul.4s	v17, v6, v21
	fsub.4s	v17, v4, v17
	fcvtzs.4s	v4, v16
	scvtf.4s	v16, v4
	fmul.4s	v18, v16, v21
	fsub.4s	v7, v7, v18
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #13759, lsl #16
	dup.4s	v20, w9
	fmul.4s	v16, v16, v20
	fsub.4s	v23, v7, v16
	fmul.4s	v6, v6, v20
	fsub.4s	v6, v17, v6
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v19, w9
	fmul.4s	v7, v6, v19
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v18, w9
	fadd.4s	v7, v7, v18
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v17, w9
	fmul.4s	v7, v6, v7
	fadd.4s	v7, v7, v17
	fmul.4s	v7, v6, v7
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v16, w9
	fadd.4s	v7, v7, v16
	fmul.4s	v24, v6, v7
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v7, w9
	fadd.4s	v24, v24, v7
	fmul.4s	v24, v6, v24
	movi.4s	v31, #63, lsl #24
	fadd.4s	v24, v24, v31
	fmul.4s	v25, v6, v6
	fmul.4s	v24, v25, v24
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v18
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v31
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v6, v6, v24
	fmov.4s	v8, #1.00000000
	fadd.4s	v23, v23, v8
	sshr.4s	v24, v4, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v8
	fmul.4s	v23, v23, v25
	fadd.4s	v6, v6, v8
	sshr.4s	v25, v3, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v8
	fmul.4s	v6, v6, v26
	sub.4s	v4, v4, v24
	sub.4s	v3, v3, v25
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v6, v3
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	str	q9, [sp, #1392]                 ; 16-byte Spill
	fcmgt.4s	v6, v2, v9
	bic.16b	v4, v4, v6
	str	q27, [sp, #1440]                ; 16-byte Spill
	fcmgt.4s	v6, v2, v27
	bic.16b	v3, v3, v6
	fcmgt.4s	v23, v27, v5
	mvni.4s	v6, #127, msl #16
	fneg.4s	v6, v6
	bit.16b	v3, v6, v23
	str	q3, [sp, #1424]                 ; 16-byte Spill
	fcmgt.4s	v3, v9, v5
	bsl.16b	v3, v6, v4
	str	q3, [sp, #1408]                 ; 16-byte Spill
	fsub.4s	v9, v11, v28
	fcmge.4s	v3, v9, v2
	fcmge.4s	v4, v5, v9
	and.16b	v3, v3, v4
	fsub.4s	v11, v12, v10
	fcmge.4s	v4, v11, v2
	fcmge.4s	v23, v5, v11
	and.16b	v4, v4, v23
	and.16b	v4, v4, v11
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v9
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	str	q9, [sp, #1312]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v9
	bic.16b	v4, v4, v23
	str	q11, [sp, #1344]                ; 16-byte Spill
	fcmgt.4s	v23, v2, v11
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v11, v5
	bit.16b	v3, v6, v23
	str	q3, [sp, #1360]                 ; 16-byte Spill
	fcmgt.4s	v3, v9, v5
	bsl.16b	v3, v6, v4
	str	q3, [sp, #1328]                 ; 16-byte Spill
	fsub.4s	v9, v1, v28
	fcmge.4s	v3, v9, v2
	fcmge.4s	v4, v5, v9
	and.16b	v3, v3, v4
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	fsub.4s	v1, v4, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v9
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	str	q9, [sp, #1216]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v9
	bic.16b	v4, v4, v23
	str	q1, [sp, #1248]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1264]                 ; 16-byte Spill
	fcmgt.4s	v3, v9, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #1232]                 ; 16-byte Spill
	ldr	q1, [sp, #1952]                 ; 16-byte Reload
	fsub.4s	v9, v1, v28
	fcmge.4s	v3, v9, v2
	fcmge.4s	v4, v5, v9
	and.16b	v3, v3, v4
	ldr	q4, [sp, #1904]                 ; 16-byte Reload
	fsub.4s	v1, v4, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v9
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	str	q9, [sp, #1136]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v9
	bic.16b	v4, v4, v23
	str	q1, [sp, #1168]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1184]                 ; 16-byte Spill
	fcmgt.4s	v3, v9, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #1152]                 ; 16-byte Spill
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	fsub.4s	v9, v1, v28
	fcmge.4s	v3, v9, v2
	fcmge.4s	v4, v5, v9
	and.16b	v3, v3, v4
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fsub.4s	v1, v4, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v9
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	str	q9, [sp, #1056]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v9
	bic.16b	v4, v4, v23
	str	q1, [sp, #1088]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1104]                 ; 16-byte Spill
	fcmgt.4s	v3, v9, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #1072]                 ; 16-byte Spill
	ldr	q1, [sp, #1616]                 ; 16-byte Reload
	fsub.4s	v9, v1, v28
	fcmge.4s	v3, v9, v2
	fcmge.4s	v4, v5, v9
	and.16b	v3, v3, v4
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fsub.4s	v1, v4, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v9
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v9
	bic.16b	v4, v4, v23
	str	q1, [sp, #1024]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1040]                 ; 16-byte Spill
	fcmgt.4s	v3, v9, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q9, q1, [sp, #992]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	fsub.4s	v9, v1, v28
	fcmge.4s	v3, v9, v2
	fcmge.4s	v4, v5, v9
	and.16b	v3, v3, v4
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	fsub.4s	v1, v4, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v9
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v9
	bic.16b	v4, v4, v23
	str	q1, [sp, #960]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #976]                  ; 16-byte Spill
	fcmgt.4s	v3, v9, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q9, q1, [sp, #928]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1648]                 ; 16-byte Reload
	fsub.4s	v9, v1, v28
	fcmge.4s	v3, v9, v2
	fcmge.4s	v4, v5, v9
	and.16b	v3, v3, v4
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	fsub.4s	v1, v4, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v9
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v9
	bic.16b	v4, v4, v23
	str	q1, [sp, #896]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #912]                  ; 16-byte Spill
	fcmgt.4s	v3, v9, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q9, q1, [sp, #864]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	fsub.4s	v9, v1, v28
	fcmge.4s	v3, v9, v2
	fcmge.4s	v4, v5, v9
	and.16b	v3, v3, v4
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fsub.4s	v1, v4, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v9
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v9
	bic.16b	v4, v4, v23
	str	q1, [sp, #832]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #848]                  ; 16-byte Spill
	fcmgt.4s	v3, v9, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q9, q1, [sp, #800]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1680]                 ; 16-byte Reload
	fsub.4s	v9, v1, v28
	fcmge.4s	v3, v9, v2
	fcmge.4s	v4, v5, v9
	and.16b	v3, v3, v4
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	fsub.4s	v1, v4, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v9
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	str	q9, [sp, #400]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v9
	bic.16b	v4, v4, v23
	str	q1, [sp, #768]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #784]                  ; 16-byte Spill
	fcmgt.4s	v3, v9, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #752]                  ; 16-byte Spill
	ldr	q1, [sp, #1696]                 ; 16-byte Reload
	fsub.4s	v11, v1, v28
	fcmge.4s	v3, v11, v2
	fcmge.4s	v4, v5, v11
	and.16b	v3, v3, v4
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	fsub.4s	v1, v4, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v11
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v11
	bic.16b	v4, v4, v23
	str	q1, [sp, #720]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #736]                  ; 16-byte Spill
	fcmgt.4s	v3, v11, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q11, q1, [sp, #688]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1712]                 ; 16-byte Reload
	fsub.4s	v11, v1, v28
	fcmge.4s	v3, v11, v2
	fcmge.4s	v4, v5, v11
	and.16b	v3, v3, v4
	ldr	q4, [sp, #1760]                 ; 16-byte Reload
	fsub.4s	v1, v4, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v11
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v11
	bic.16b	v4, v4, v23
	str	q1, [sp, #656]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #672]                  ; 16-byte Spill
	fcmgt.4s	v3, v11, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q11, q1, [sp, #624]             ; 32-byte Folded Spill
	fsub.4s	v11, v13, v28
	fcmge.4s	v3, v11, v2
	fcmge.4s	v4, v5, v11
	and.16b	v3, v3, v4
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
	fsub.4s	v1, v1, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v11
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v8
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v11
	bic.16b	v4, v4, v23
	str	q1, [sp, #576]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #592]                  ; 16-byte Spill
	fcmgt.4s	v3, v11, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q11, q1, [sp, #544]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1728]                 ; 16-byte Reload
	fsub.4s	v12, v1, v28
	fcmge.4s	v3, v12, v2
	fcmge.4s	v4, v5, v12
	and.16b	v3, v3, v4
	ldr	q9, [sp, #1120]                 ; 16-byte Reload
	fsub.4s	v1, v9, v10
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v12
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v29, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v11, v26, v21
	fsub.4s	v24, v24, v11
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v31
	fmul.4s	v11, v24, v24
	fmul.4s	v26, v11, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v8
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v8
	sshr.4s	v26, v3, #1
	shl.4s	v11, v26, #23
	add.4s	v11, v11, v8
	fmul.4s	v4, v4, v11
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v12
	bic.16b	v4, v4, v23
	str	q1, [sp, #512]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #528]                  ; 16-byte Spill
	fcmgt.4s	v3, v12, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q12, q1, [sp, #480]             ; 32-byte Folded Spill
	mov.16b	v27, v14
	fsub.4s	v1, v14, v28
	fcmge.4s	v3, v1, v2
	fcmge.4s	v4, v5, v1
	and.16b	v3, v3, v4
	ldr	q26, [sp, #1200]                ; 16-byte Reload
	fsub.4s	v13, v26, v10
	fcmge.4s	v4, v13, v2
	fcmge.4s	v23, v5, v13
	and.16b	v4, v4, v23
	and.16b	v4, v4, v13
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v29, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v1
	fmul.4s	v3, v24, v22
	mov.16b	v11, v30
	bsl.16b	v11, v29, v3
	fadd.4s	v3, v3, v11
	fsub.4s	v11, v3, v11
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v12, v23, v21
	fsub.4s	v4, v4, v12
	fcvtzs.4s	v11, v11
	scvtf.4s	v12, v11
	fmul.4s	v15, v12, v21
	fsub.4s	v24, v24, v15
	fmul.4s	v12, v12, v20
	fsub.4s	v24, v24, v12
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v31
	fmul.4s	v12, v4, v4
	fmul.4s	v23, v12, v23
	fmul.4s	v12, v24, v19
	fadd.4s	v12, v12, v18
	fmul.4s	v12, v24, v12
	fadd.4s	v12, v12, v17
	fmul.4s	v12, v24, v12
	fadd.4s	v12, v12, v16
	fmul.4s	v12, v24, v12
	fadd.4s	v12, v12, v7
	fmul.4s	v12, v24, v12
	fadd.4s	v12, v12, v31
	fmul.4s	v15, v24, v24
	fmul.4s	v12, v15, v12
	fadd.4s	v24, v24, v12
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v8
	sshr.4s	v24, v11, #1
	shl.4s	v12, v24, #23
	add.4s	v12, v12, v8
	fmul.4s	v23, v23, v12
	fadd.4s	v4, v4, v8
	sshr.4s	v12, v3, #1
	shl.4s	v15, v12, #23
	add.4s	v15, v15, v8
	fmul.4s	v4, v4, v15
	sub.4s	v24, v11, v24
	sub.4s	v3, v3, v12
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v23, v4
	str	q1, [sp, #416]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v4, v4, v23
	fcmgt.4s	v23, v2, v13
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v13, v5
	bit.16b	v3, v6, v23
	stp	q13, q3, [sp, #448]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v1, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #432]                  ; 16-byte Spill
	ldr	q25, [sp, #1280]                ; 16-byte Reload
	fsub.4s	v1, v25, v28
	fcmge.4s	v3, v1, v2
	fcmge.4s	v4, v5, v1
	and.16b	v3, v3, v4
	ldr	q24, [sp, #1296]                ; 16-byte Reload
	fsub.4s	v23, v24, v10
	fcmge.4s	v4, v23, v2
	fcmge.4s	v11, v5, v23
	and.16b	v4, v4, v11
	and.16b	v4, v4, v23
	fmul.4s	v11, v4, v22
	mov.16b	v12, v30
	bsl.16b	v12, v29, v11
	fadd.4s	v11, v11, v12
	fsub.4s	v11, v11, v12
	and.16b	v12, v3, v1
	fmul.4s	v3, v12, v22
	mov.16b	v15, v30
	bsl.16b	v15, v29, v3
	fadd.4s	v3, v3, v15
	fsub.4s	v15, v3, v15
	fcvtzs.4s	v3, v11
	scvtf.4s	v11, v3
	fmul.4s	v14, v11, v21
	fsub.4s	v4, v4, v14
	fcvtzs.4s	v14, v15
	scvtf.4s	v15, v14
	fmul.4s	v13, v15, v21
	fsub.4s	v12, v12, v13
	fmul.4s	v13, v15, v20
	fsub.4s	v12, v12, v13
	fmul.4s	v11, v11, v20
	fsub.4s	v4, v4, v11
	fmul.4s	v11, v4, v19
	fadd.4s	v11, v11, v18
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v17
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v16
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v7
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v31
	fmul.4s	v13, v4, v4
	fmul.4s	v11, v13, v11
	fmul.4s	v13, v12, v19
	fadd.4s	v13, v13, v18
	fmul.4s	v13, v12, v13
	fadd.4s	v13, v13, v17
	fmul.4s	v13, v12, v13
	fadd.4s	v13, v13, v16
	fmul.4s	v13, v12, v13
	fadd.4s	v13, v13, v7
	fmul.4s	v13, v12, v13
	fadd.4s	v13, v13, v31
	fmul.4s	v15, v12, v12
	fmul.4s	v13, v15, v13
	fadd.4s	v12, v12, v13
	fadd.4s	v4, v4, v11
	fadd.4s	v11, v12, v8
	sshr.4s	v12, v14, #1
	shl.4s	v13, v12, #23
	add.4s	v13, v13, v8
	fmul.4s	v11, v11, v13
	fadd.4s	v4, v4, v8
	sshr.4s	v13, v3, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v8
	fmul.4s	v4, v4, v15
	sub.4s	v12, v14, v12
	sub.4s	v3, v3, v13
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v8
	fmul.4s	v3, v4, v3
	shl.4s	v4, v12, #23
	add.4s	v4, v4, v8
	fmul.4s	v4, v11, v4
	str	q1, [sp, #336]                  ; 16-byte Spill
	fcmgt.4s	v11, v2, v1
	bic.16b	v4, v4, v11
	fcmgt.4s	v11, v2, v23
	bic.16b	v3, v3, v11
	fcmgt.4s	v11, v23, v5
	bit.16b	v3, v6, v11
	stp	q23, q3, [sp, #368]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v1, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #352]                  ; 16-byte Spill
	str	q28, [sp, #1472]                ; 16-byte Spill
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	fsub.4s	v4, v1, v28
	fcmge.4s	v3, v4, v2
	fcmge.4s	v13, v5, v4
	and.16b	v13, v3, v13
	str	q10, [sp, #1488]                ; 16-byte Spill
	ldr	q1, [sp, #1936]                 ; 16-byte Reload
	fsub.4s	v3, v1, v10
	fcmge.4s	v14, v3, v2
	fcmge.4s	v15, v5, v3
	and.16b	v14, v14, v15
	and.16b	v14, v14, v3
	fmul.4s	v15, v14, v22
	mov.16b	v1, v30
	bsl.16b	v1, v29, v15
	fadd.4s	v15, v15, v1
	fsub.4s	v1, v15, v1
	and.16b	v13, v13, v4
	fmul.4s	v22, v13, v22
	mov.16b	v15, v30
	bsl.16b	v15, v29, v22
	fadd.4s	v22, v22, v15
	fsub.4s	v22, v22, v15
	fcvtzs.4s	v1, v1
	scvtf.4s	v15, v1
	fmul.4s	v12, v15, v21
	fsub.4s	v12, v14, v12
	fcvtzs.4s	v22, v22
	scvtf.4s	v14, v22
	fmul.4s	v21, v14, v21
	fsub.4s	v21, v13, v21
	fmul.4s	v13, v15, v20
	fmul.4s	v20, v14, v20
	fsub.4s	v20, v21, v20
	fsub.4s	v21, v12, v13
	fmul.4s	v12, v21, v19
	fmul.4s	v19, v20, v19
	fadd.4s	v19, v19, v18
	fadd.4s	v18, v12, v18
	fmul.4s	v18, v21, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v19, v19, v17
	fadd.4s	v17, v18, v17
	fmul.4s	v17, v21, v17
	fmul.4s	v18, v20, v19
	fadd.4s	v18, v18, v16
	fadd.4s	v16, v17, v16
	fmul.4s	v16, v21, v16
	fmul.4s	v17, v20, v18
	fadd.4s	v17, v17, v7
	fadd.4s	v7, v16, v7
	fmul.4s	v7, v21, v7
	fadd.4s	v7, v7, v31
	fmul.4s	v16, v21, v21
	fmul.4s	v7, v16, v7
	fmul.4s	v16, v20, v17
	fadd.4s	v16, v16, v31
	fmul.4s	v17, v20, v20
	fmul.4s	v16, v17, v16
	fadd.4s	v16, v20, v16
	fadd.4s	v7, v21, v7
	fadd.4s	v16, v16, v8
	sshr.4s	v17, v22, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v8
	fmul.4s	v16, v16, v18
	fadd.4s	v7, v7, v8
	sshr.4s	v18, v1, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v8
	fmul.4s	v7, v7, v19
	sub.4s	v17, v22, v17
	sub.4s	v1, v1, v18
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v8
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v8
	fmul.4s	v7, v16, v7
	fcmgt.4s	v16, v2, v4
	bic.16b	v7, v7, v16
	fcmgt.4s	v2, v2, v3
	bic.16b	v1, v1, v2
	fcmgt.4s	v2, v3, v5
	bit.16b	v1, v6, v2
	stp	q3, q1, [sp, #304]              ; 32-byte Folded Spill
	fcmgt.4s	v2, v4, v5
	mov.16b	v1, v2
	bsl.16b	v1, v6, v7
	stp	q4, q1, [sp, #272]              ; 32-byte Folded Spill
	ldr	q2, [sp, #1600]                 ; 16-byte Reload
	ldr	q1, [sp, #1744]                 ; 16-byte Reload
	stp	q1, q2, [x22]
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	ldr	q1, [sp, #1376]                 ; 16-byte Reload
	stp	q1, q2, [x22, #32]
	ldr	q2, [sp, #1568]                 ; 16-byte Reload
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	stp	q1, q2, [x22, #64]
	ldr	q2, [sp, #1952]                 ; 16-byte Reload
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	stp	q1, q2, [x22, #96]
	ldr	q2, [sp, #1968]                 ; 16-byte Reload
	ldr	q1, [sp, #1824]                 ; 16-byte Reload
	stp	q1, q2, [x22, #128]
	ldr	q2, [sp, #1616]                 ; 16-byte Reload
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	stp	q1, q2, [x22, #160]
	ldr	q2, [sp, #1632]                 ; 16-byte Reload
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	stp	q1, q2, [x22, #192]
	ldr	q2, [sp, #1648]                 ; 16-byte Reload
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	stp	q1, q2, [x22, #224]
	ldr	q2, [sp, #1664]                 ; 16-byte Reload
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	stp	q1, q2, [x22, #256]
	ldr	q2, [sp, #1680]                 ; 16-byte Reload
	ldr	q1, [sp, #1856]                 ; 16-byte Reload
	stp	q1, q2, [x22, #288]
	ldr	q2, [sp, #1696]                 ; 16-byte Reload
	ldr	q1, [sp, #1776]                 ; 16-byte Reload
	stp	q1, q2, [x22, #320]
	ldr	q2, [sp, #1712]                 ; 16-byte Reload
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	stp	q1, q2, [x22, #352]
	ldr	q2, [sp, #608]                  ; 16-byte Reload
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
	stp	q1, q2, [x22, #384]
	ldr	q1, [sp, #1728]                 ; 16-byte Reload
	stp	q9, q1, [x22, #416]
	stp	q26, q27, [x22, #448]
	stp	q24, q25, [x22, #480]
	ldr	q1, [sp, #1392]                 ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q3, [sp, #160]                  ; 16-byte Reload
	ldr	q1, [sp, #1408]                 ; 16-byte Reload
	bif.16b	v1, v3, v5
	str	q1, [sp, #1968]                 ; 16-byte Spill
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #1424]                 ; 16-byte Reload
	bif.16b	v1, v3, v5
	str	q1, [sp, #1952]                 ; 16-byte Spill
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #1328]                 ; 16-byte Reload
	bif.16b	v1, v3, v5
	str	q1, [sp, #1936]                 ; 16-byte Spill
	ldr	q1, [sp, #1344]                 ; 16-byte Reload
	fcmeq.4s	v6, v1, v1
	ldr	q1, [sp, #1360]                 ; 16-byte Reload
	bif.16b	v1, v3, v6
	str	q1, [sp, #1904]                 ; 16-byte Spill
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	fcmeq.4s	v7, v1, v1
	ldr	q1, [sp, #1232]                 ; 16-byte Reload
	bif.16b	v1, v3, v7
	str	q1, [sp, #1920]                 ; 16-byte Spill
	ldr	q1, [sp, #1248]                 ; 16-byte Reload
	fcmeq.4s	v16, v1, v1
	ldr	q1, [sp, #1264]                 ; 16-byte Reload
	bif.16b	v1, v3, v16
	str	q1, [sp, #1872]                 ; 16-byte Spill
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v17, v1, v1
	ldr	q1, [sp, #1152]                 ; 16-byte Reload
	bif.16b	v1, v3, v17
	str	q1, [sp, #1888]                 ; 16-byte Spill
	ldr	q1, [sp, #1168]                 ; 16-byte Reload
	fcmeq.4s	v18, v1, v1
	ldr	q1, [sp, #1184]                 ; 16-byte Reload
	mov.16b	v16, v18
	bsl.16b	v16, v1, v3
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	fcmeq.4s	v19, v1, v1
	ldr	q1, [sp, #1072]                 ; 16-byte Reload
	bif.16b	v1, v3, v19
	str	q1, [sp, #1856]                 ; 16-byte Spill
	ldr	q1, [sp, #1088]                 ; 16-byte Reload
	fcmeq.4s	v20, v1, v1
	ldr	q1, [sp, #1104]                 ; 16-byte Reload
	mov.16b	v4, v20
	bsl.16b	v4, v1, v3
	ldp	q2, q1, [sp, #992]              ; 32-byte Folded Reload
	fcmeq.4s	v21, v2, v2
	mov.16b	v18, v21
	bsl.16b	v18, v1, v3
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	fcmeq.4s	v22, v1, v1
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	mov.16b	v6, v22
	bsl.16b	v6, v1, v3
	ldp	q5, q1, [sp, #928]              ; 32-byte Folded Reload
	fcmeq.4s	v12, v5, v5
	bsl.16b	v12, v1, v3
	ldp	q7, q1, [sp, #960]              ; 32-byte Folded Reload
	fcmeq.4s	v13, v7, v7
	bsl.16b	v13, v1, v3
	ldr	q1, [sp, #864]                  ; 16-byte Reload
	fcmeq.4s	v14, v1, v1
	ldr	q1, [sp, #880]                  ; 16-byte Reload
	bif.16b	v1, v3, v14
	str	q1, [sp, #1840]                 ; 16-byte Spill
	ldr	q1, [sp, #896]                  ; 16-byte Reload
	fcmeq.4s	v15, v1, v1
	ldr	q1, [sp, #912]                  ; 16-byte Reload
	bsl.16b	v15, v1, v3
	ldr	q1, [sp, #800]                  ; 16-byte Reload
	fcmeq.4s	v11, v1, v1
	ldr	q1, [sp, #816]                  ; 16-byte Reload
	bsl.16b	v11, v1, v3
	ldr	q1, [sp, #832]                  ; 16-byte Reload
	fcmeq.4s	v10, v1, v1
	ldr	q1, [sp, #848]                  ; 16-byte Reload
	bsl.16b	v10, v1, v3
	ldr	q1, [sp, #400]                  ; 16-byte Reload
	fcmeq.4s	v9, v1, v1
	ldr	q1, [sp, #752]                  ; 16-byte Reload
	mov.16b	v14, v9
	bsl.16b	v14, v1, v3
	ldr	q1, [sp, #768]                  ; 16-byte Reload
	fcmeq.4s	v8, v1, v1
	ldr	q1, [sp, #784]                  ; 16-byte Reload
	mov.16b	v19, v8
	bsl.16b	v19, v1, v3
	ldr	q1, [sp, #688]                  ; 16-byte Reload
	fcmeq.4s	v31, v1, v1
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	bsl.16b	v31, v1, v3
	ldr	q1, [sp, #720]                  ; 16-byte Reload
	fcmeq.4s	v30, v1, v1
	ldr	q1, [sp, #736]                  ; 16-byte Reload
	bsl.16b	v30, v1, v3
	ldr	q1, [sp, #624]                  ; 16-byte Reload
	fcmeq.4s	v29, v1, v1
	ldr	q1, [sp, #640]                  ; 16-byte Reload
	bsl.16b	v29, v1, v3
	ldr	q1, [sp, #656]                  ; 16-byte Reload
	fcmeq.4s	v27, v1, v1
	ldr	q1, [sp, #672]                  ; 16-byte Reload
	mov.16b	v20, v27
	bsl.16b	v20, v1, v3
	ldp	q1, q2, [sp, #544]              ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	mov.16b	v28, v1
	bsl.16b	v28, v2, v3
	ldr	q1, [sp, #576]                  ; 16-byte Reload
	fcmeq.4s	v2, v1, v1
	ldr	q1, [sp, #592]                  ; 16-byte Reload
	mov.16b	v22, v2
	bsl.16b	v22, v1, v3
	ldp	q2, q1, [sp, #480]              ; 32-byte Folded Reload
	fcmeq.4s	v26, v2, v2
	bif.16b	v1, v3, v26
	str	q1, [sp, #1824]                 ; 16-byte Spill
	ldr	q1, [sp, #512]                  ; 16-byte Reload
	fcmeq.4s	v25, v1, v1
	ldr	q1, [sp, #528]                  ; 16-byte Reload
	bsl.16b	v25, v1, v3
	ldr	q1, [sp, #416]                  ; 16-byte Reload
	fcmeq.4s	v24, v1, v1
	ldr	q1, [sp, #432]                  ; 16-byte Reload
	bif.16b	v1, v3, v24
	str	q1, [sp, #1808]                 ; 16-byte Spill
	ldr	q1, [sp, #448]                  ; 16-byte Reload
	fcmeq.4s	v23, v1, v1
	ldr	q1, [sp, #464]                  ; 16-byte Reload
	bsl.16b	v23, v1, v3
	ldr	q1, [sp, #336]                  ; 16-byte Reload
	fcmeq.4s	v5, v1, v1
	ldr	q1, [sp, #352]                  ; 16-byte Reload
	mov.16b	v9, v5
	bsl.16b	v9, v1, v3
	ldp	q5, q1, [sp, #368]              ; 32-byte Folded Reload
	fcmeq.4s	v7, v5, v5
	mov.16b	v21, v7
	bsl.16b	v21, v1, v3
	ldr	q1, [sp, #1456]                 ; 16-byte Reload
	ldr	q2, [sp, #1904]                 ; 16-byte Reload
	and.16b	v26, v1, v2
	ldr	q2, [sp, #1936]                 ; 16-byte Reload
	and.16b	v17, v1, v2
	ldr	q2, [sp, #1872]                 ; 16-byte Reload
	and.16b	v24, v1, v2
	ldr	q2, [sp, #1920]                 ; 16-byte Reload
	and.16b	v2, v1, v2
	and.16b	v8, v1, v16
	ldr	q5, [sp, #1888]                 ; 16-byte Reload
	and.16b	v5, v1, v5
	and.16b	v27, v1, v4
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	and.16b	v4, v1, v4
	and.16b	v6, v1, v6
	str	q6, [sp, #1936]                 ; 16-byte Spill
	and.16b	v6, v1, v18
	and.16b	v13, v1, v13
	and.16b	v12, v1, v12
	and.16b	v7, v1, v15
	str	q7, [sp, #1920]                 ; 16-byte Spill
	ldr	q7, [sp, #1840]                 ; 16-byte Reload
	and.16b	v15, v1, v7
	and.16b	v10, v1, v10
	and.16b	v11, v1, v11
	and.16b	v19, v1, v19
	and.16b	v14, v1, v14
	and.16b	v30, v1, v30
	and.16b	v31, v1, v31
	and.16b	v20, v1, v20
	and.16b	v7, v1, v29
	and.16b	v29, v1, v22
	and.16b	v28, v1, v28
	and.16b	v22, v1, v25
	ldr	q16, [sp, #1824]                ; 16-byte Reload
	and.16b	v16, v1, v16
	and.16b	v23, v1, v23
	ldr	q18, [sp, #1808]                ; 16-byte Reload
	and.16b	v25, v1, v18
	and.16b	v21, v1, v21
	and.16b	v9, v1, v9
	ldp	q1, q18, [sp, #272]             ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v18, v3
	str	q1, [sp, #1904]                 ; 16-byte Spill
	ldp	q1, q18, [sp, #304]             ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v18, v3
	ldr	q3, [sp, #1952]                 ; 16-byte Reload
	stp	q3, q26, [x22, #528]
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	str	q3, [x22, #512]
	str	q17, [sp, #1376]                ; 16-byte Spill
	stp	q17, q24, [x22, #560]
	str	q26, [sp, #1888]                ; 16-byte Spill
	str	q2, [sp, #1776]                 ; 16-byte Spill
	stp	q2, q8, [x22, #592]
	str	q24, [sp, #1792]                ; 16-byte Spill
	str	q5, [sp, #1568]                 ; 16-byte Spill
	stp	q5, q27, [x22, #624]
	str	q8, [sp, #1872]                 ; 16-byte Spill
	str	q4, [sp, #1744]                 ; 16-byte Spill
	str	q27, [sp, #1760]                ; 16-byte Spill
	str	q6, [sp, #1552]                 ; 16-byte Spill
	stp	q6, q13, [x22, #688]
	ldr	q2, [sp, #1936]                 ; 16-byte Reload
	stp	q4, q2, [x22, #656]
	str	q12, [sp, #1712]                ; 16-byte Spill
	str	q13, [sp, #1728]                ; 16-byte Spill
	str	q15, [sp, #1456]                ; 16-byte Spill
	stp	q15, q10, [x22, #752]
	ldr	q2, [sp, #1920]                 ; 16-byte Reload
	stp	q12, q2, [x22, #720]
	str	q11, [sp, #1680]                ; 16-byte Spill
	stp	q11, q19, [x22, #784]
	str	q10, [sp, #1696]                ; 16-byte Spill
	str	q14, [sp, #1440]                ; 16-byte Spill
	stp	q14, q30, [x22, #816]
	str	q19, [sp, #1856]                ; 16-byte Spill
	str	q31, [sp, #1648]                ; 16-byte Spill
	stp	q31, q20, [x22, #848]
	mov.16b	v31, v1
	str	q30, [sp, #1664]                ; 16-byte Spill
	ldr	q30, [sp, #1904]                ; 16-byte Reload
	str	q7, [sp, #1424]                 ; 16-byte Spill
	stp	q7, q29, [x22, #880]
	str	q20, [sp, #1840]                ; 16-byte Spill
	str	q28, [sp, #1616]                ; 16-byte Spill
	stp	q28, q22, [x22, #912]
	str	q29, [sp, #1632]                ; 16-byte Spill
	str	q16, [sp, #1408]                ; 16-byte Spill
	stp	q16, q23, [x22, #944]
	str	q22, [sp, #1824]                ; 16-byte Spill
	str	q25, [sp, #1584]                ; 16-byte Spill
	stp	q25, q21, [x22, #976]
	str	q23, [sp, #1600]                ; 16-byte Spill
	str	q9, [sp, #1392]                 ; 16-byte Spill
	str	q9, [x22, #1008]
	str	q21, [sp, #1808]                ; 16-byte Spill
	mov	w9, #12                         ; =0xc
	ldr	q26, [sp, #2096]                ; 16-byte Reload
	ldr	q27, [sp, #2080]                ; 16-byte Reload
	ldr	q28, [sp, #2064]                ; 16-byte Reload
	ldr	q29, [sp, #2048]                ; 16-byte Reload
LBB0_63:                                ; %direct.true557
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_64 Depth 3
	mov	x10, #0                         ; =0x0
	lsl	x11, x8, #7
	add	x12, x25, x11
	ldp	q1, q2, [x12]
	fmul.4s	v2, v30, v2
	fmul.4s	v1, v31, v1
	mov	w12, #1                         ; =0x1
	bfi	x12, x8, #2, #61
	add	x13, x25, x12, lsl #5
	ldp	q3, q4, [x13]
	fmul.4s	v4, v30, v4
	fmul.4s	v3, v31, v3
	mov	w13, #2                         ; =0x2
	bfi	x13, x8, #2, #61
	add	x14, x25, x13, lsl #5
	ldp	q5, q6, [x14]
	fmul.4s	v16, v30, v6
	fmul.4s	v7, v31, v5
	orr	x14, x23, x8, lsl #2
	add	x15, x25, x14, lsl #5
	ldp	q5, q6, [x15]
	fmul.4s	v6, v30, v6
	fmul.4s	v5, v31, v5
	mov	x15, x9
LBB0_64:                                ; %direct.true585
                                        ;   Parent Loop BB0_17 Depth=1
                                        ;     Parent Loop BB0_63 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x16, x20, x10
	ldr	q17, [x16, #16]
	sub	x17, x15, #12
	dup.2d	v18, x17
	add.2d	v18, v0, v18
	add.2d	v19, v18, v29
	add.2d	v20, v18, v28
	add.2d	v21, v18, v27
	add.2d	v18, v18, v26
	mov.d	x3, v18[1]
	fmov	x1, d18
	mov.d	x17, v21[1]
	fmov	x2, d21
	mov.d	x4, v20[1]
	fmov	x5, d20
	mov.d	x0, v19[1]
	sub	x6, x15, #8
	dup.2d	v20, x6
	fmov	x6, d19
	ldr	s18, [x5]
	add.2d	v20, v20, v0
	add.2d	v21, v20, v29
	add.2d	v22, v20, v28
	add.2d	v23, v20, v27
	ldr	s19, [x1]
	add.2d	v20, v20, v26
	mov.d	x5, v20[1]
	fmov	x7, d20
	ld1.s	{ v18 }[1], [x4]
	mov.d	x1, v23[1]
	mov.d	x4, v22[1]
	ld1.s	{ v19 }[1], [x3]
	fmov	x30, d22
	mov.d	x3, v21[1]
	ldr	s20, [x30]
	ld1.s	{ v20 }[1], [x4]
	fmov	x4, d23
	fmov	x30, d21
	ldr	s21, [x7]
	sub	x7, x15, #4
	ld1.s	{ v21 }[1], [x5]
	dup.2d	v22, x7
	add.2d	v22, v22, v0
	add.2d	v23, v22, v28
	ld1.s	{ v18 }[2], [x6]
	add.2d	v24, v22, v27
	add.2d	v25, v22, v26
	mov.d	x5, v25[1]
	ld1.s	{ v19 }[2], [x2]
	mov.d	x2, v24[1]
	mov.d	x6, v23[1]
	ld1.s	{ v20 }[2], [x30]
	add.2d	v22, v22, v29
	fmov	x7, d23
	mov.d	x30, v22[1]
	ld1.s	{ v21 }[2], [x4]
	ldr	s23, [x7]
	fmov	x4, d22
	ld1.s	{ v23 }[1], [x6]
	ld1.s	{ v23 }[2], [x4]
	fmov	x4, d25
	ldr	s22, [x4]
	ld1.s	{ v22 }[1], [x5]
	ld1.s	{ v18 }[3], [x0]
	fmov	x0, d24
	dup.2d	v24, x15
	add.2d	v24, v24, v0
	ld1.s	{ v19 }[3], [x17]
	add.2d	v25, v24, v26
	mov.d	x17, v25[1]
	fmov	x4, d25
	ld1.s	{ v20 }[3], [x3]
	add.2d	v25, v24, v27
	mov.d	x3, v25[1]
	fmov	x5, d25
	ld1.s	{ v21 }[3], [x1]
	add.2d	v25, v24, v28
	mov.d	x1, v25[1]
	fmov	x6, d25
	ld1.s	{ v23 }[3], [x30]
	ldr	q25, [x16]
	fmul.4s	v19, v25, v19
	fmul.4s	v18, v17, v18
	ld1.s	{ v22 }[2], [x0]
	fadd.4s	v2, v2, v18
	ld1.s	{ v22 }[3], [x2]
	add.2d	v18, v24, v29
	mov.d	x16, v18[1]
	fadd.4s	v1, v1, v19
	fmov	x0, d18
	fmul.4s	v18, v25, v21
	fmul.4s	v19, v17, v20
	fmul.4s	v20, v25, v22
	fmul.4s	v21, v17, v23
	fadd.4s	v4, v4, v19
	ldr	s19, [x6]
	ld1.s	{ v19 }[1], [x1]
	ld1.s	{ v19 }[2], [x0]
	fadd.4s	v3, v3, v18
	ld1.s	{ v19 }[3], [x16]
	ldr	s18, [x4]
	ld1.s	{ v18 }[1], [x17]
	fadd.4s	v16, v16, v21
	ld1.s	{ v18 }[2], [x5]
	ld1.s	{ v18 }[3], [x3]
	fmul.4s	v18, v25, v18
	fadd.4s	v7, v7, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v6, v6, v17
	fadd.4s	v5, v5, v18
	add	x10, x10, #32
	add	x15, x15, #512
	cmp	x10, #512
	b.ne	LBB0_64
; %bb.65:                               ; %direct.false586
                                        ;   in Loop: Header=BB0_63 Depth=2
	add	x10, x19, x11
	stp	q1, q2, [x10]
	add	x10, x19, x12, lsl #5
	stp	q3, q4, [x10]
	add	x10, x19, x13, lsl #5
	stp	q7, q16, [x10]
	add	x10, x19, x14, lsl #5
	add	x8, x8, #1
	add	x9, x9, #16
	stp	q5, q6, [x10]
	cmp	x8, #32
	b.ne	LBB0_63
; %bb.66:                               ; %direct.true644.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	add	x0, x21, #2, lsl #12            ; =8192
	mov	x1, x19
	mov	w2, #4096                       ; =0x1000
	str	q31, [sp, #1360]                ; 16-byte Spill
	bl	_memcpy
	add	x0, x21, #1, lsl #12            ; =4096
	mov	x1, x19
	mov	w2, #4096                       ; =0x1000
	bl	_memcpy
	ldr	q27, [sp, #2048]                ; 16-byte Reload
	ldr	q15, [sp, #2064]                ; 16-byte Reload
	ldr	q14, [sp, #2080]                ; 16-byte Reload
	ldr	q13, [sp, #2096]                ; 16-byte Reload
	ldr	q0, [sp, #1504]                 ; 16-byte Reload
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #1520]                 ; 16-byte Reload
	ldr	q2, [sp, #1360]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	movi.2d	v3, #0000000000000000
	ldr	q2, [sp, #1952]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q4, [sp, #1376]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1568]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1760]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1552]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1456]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1920]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1696]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1440]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1648]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1424]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1616]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1408]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1600]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1584]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1392]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v22, v1, v3
	fadd.4s	v23, v0, v2
	ldr	x4, [sp, #1544]                 ; 8-byte Reload
	add	x4, x4, #1
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	ldr	q0, [sp, #1472]                 ; 16-byte Reload
	cmp	x4, #513
	ldr	x17, [sp, #264]                 ; 8-byte Reload
	add	x11, x21, #3, lsl #12           ; =12288
	add	x0, x21, #19, lsl #12           ; =77824
	add	x12, x21, #5, lsl #12           ; =20480
	add	x13, x21, #7, lsl #12           ; =28672
	add	x14, x21, #9, lsl #12           ; =36864
	add	x15, x21, #11, lsl #12          ; =45056
	add	x16, x21, #13, lsl #12          ; =53248
	add	x1, x21, #15, lsl #12           ; =61440
	add	x2, x21, #17, lsl #12           ; =69632
	add	x3, x21, #21, lsl #12           ; =86016
	add	x5, x21, #33, lsl #12           ; =135168
	ldp	q16, q7, [sp, #224]             ; 32-byte Folded Reload
	ldp	q18, q17, [sp, #192]            ; 32-byte Folded Reload
	ldr	q19, [sp, #176]                 ; 16-byte Reload
	ldr	q20, [sp, #2032]                ; 16-byte Reload
	ldr	q21, [sp, #2016]                ; 16-byte Reload
	ldr	q11, [sp, #2000]                ; 16-byte Reload
	ldr	q12, [sp, #1984]                ; 16-byte Reload
	mov	w6, #2560                       ; =0xa00
	b.ne	LBB0_17
	b	LBB0_71
LBB0_67:                                ; %direct.true679.preheader
                                        ;   in Loop: Header=BB0_17 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	b	LBB0_69
LBB0_68:                                ; %direct.schedule.44
                                        ;   in Loop: Header=BB0_69 Depth=2
	dup.2d	v4, x8
	add.2d	v4, v0, v4
	add.2d	v5, v4, v14
	add.2d	v6, v4, v13
	mov.d	x10, v6[1]
	fmov	x11, d6
	str	s3, [x11]
	st1.s	{ v3 }[1], [x10]
	mov.d	x10, v5[1]
	add.2d	v6, v4, v15
	fmov	x11, d5
	st1.s	{ v3 }[2], [x11]
	st1.s	{ v3 }[3], [x10]
	mov.d	x10, v6[1]
	fmov	x11, d6
	str	s2, [x11]
	st1.s	{ v2 }[1], [x10]
	add.2d	v3, v4, v27
	mov.d	x10, v3[1]
	fmov	x11, d3
	st1.s	{ v2 }[2], [x11]
	st1.s	{ v2 }[3], [x10]
	add	x9, x9, #1
	add	x8, x8, #4
	cmp	x9, #2048
	b.eq	LBB0_54
LBB0_69:                                ; %direct.true679
                                        ;   Parent Loop BB0_17 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	cmp	x9, #127
	b.hi	LBB0_68
; %bb.70:                               ; %direct.true692
                                        ;   in Loop: Header=BB0_69 Depth=2
	add	x10, x9, #256, lsl #12          ; =1048576
	dup.2d	v2, x10
	add.2d	v3, v2, v18
	add.2d	v4, v2, v17
	add.2d	v5, v2, v16
	add.2d	v2, v2, v7
	shl.2d	v2, v2, #2
	shl.2d	v5, v5, #2
	shl.2d	v4, v4, #2
	shl.2d	v3, v3, #2
	dup.2d	v6, x17
	add.2d	v3, v6, v3
	add.2d	v4, v6, v4
	add.2d	v5, v6, v5
	add.2d	v2, v6, v2
	mov.d	x10, v2[1]
	fmov	x11, d2
	mov.d	x12, v5[1]
	fmov	x13, d5
	mov.d	x14, v4[1]
	fmov	x15, d4
	mov.d	x16, v3[1]
	ldr	s2, [x15]
	ld1.s	{ v2 }[1], [x14]
	fmov	x14, d3
	ld1.s	{ v2 }[2], [x14]
	ld1.s	{ v2 }[3], [x16]
	ldr	s3, [x11]
	ld1.s	{ v3 }[1], [x10]
	ld1.s	{ v3 }[2], [x13]
	ld1.s	{ v3 }[3], [x12]
	b	LBB0_68
LBB0_71:                                ; %direct.true725.preheader
	mov	x8, #0                          ; =0x0
	ldr	x11, [sp, #88]                  ; 8-byte Reload
	ldp	q16, q7, [sp, #48]              ; 32-byte Folded Reload
	ldp	q18, q17, [sp, #16]             ; 32-byte Folded Reload
LBB0_72:                                ; %direct.true725
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v0, x8
	add.2d	v1, v0, v7
	add.2d	v2, v0, v17
	add.2d	v3, v0, v16
	add.2d	v0, v0, v18
	add	x9, x25, x8, lsl #5
	ldp	q4, q5, [x9]
	fdiv.4s	v5, v5, v23
	fdiv.4s	v4, v4, v22
	shl.2d	v0, v0, #2
	shl.2d	v3, v3, #2
	shl.2d	v2, v2, #2
	shl.2d	v1, v1, #2
	dup.2d	v6, x11
	add.2d	v1, v6, v1
	add.2d	v0, v6, v0
	mov.d	x9, v0[1]
	fmov	x10, d0
	str	s4, [x10]
	st1.s	{ v4 }[1], [x9]
	add.2d	v0, v6, v3
	mov.d	x9, v0[1]
	fmov	x10, d0
	st1.s	{ v4 }[2], [x10]
	add.2d	v0, v6, v2
	st1.s	{ v4 }[3], [x9]
	mov.d	x9, v0[1]
	fmov	x10, d0
	str	s5, [x10]
	st1.s	{ v5 }[1], [x9]
	mov.d	x9, v1[1]
	fmov	x10, d1
	st1.s	{ v5 }[2], [x10]
	st1.s	{ v5 }[3], [x9]
	add	x8, x8, #1
	cmp	x8, #128
	b.ne	LBB0_72
; %bb.73:                               ; %common.ret
	add	sp, sp, #2112
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	3072                            ; 0xc00
	.quad	3584                            ; 0xe00
lCPI1_3:
	.quad	1024                            ; 0x400
	.quad	1536                            ; 0x600
lCPI1_4:
	.quad	2048                            ; 0x800
	.quad	2560                            ; 0xa00
lCPI1_5:
	.quad	0                               ; 0x0
	.quad	512                             ; 0x200
lCPI1_6:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_7:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_9:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_10:
	.quad	49152                           ; 0xc000
	.quad	57344                           ; 0xe000
lCPI1_11:
	.quad	16384                           ; 0x4000
	.quad	24576                           ; 0x6000
lCPI1_12:
	.quad	32768                           ; 0x8000
	.quad	40960                           ; 0xa000
lCPI1_13:
	.quad	0                               ; 0x0
	.quad	8192                            ; 0x2000
lCPI1_14:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3024
	str	x0, [sp, #200]                  ; 8-byte Spill
	cbz	w3, LBB1_580
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x22, x3
	mov	x20, x2
	mov	w27, #0                         ; =0x0
	ldp	w9, w8, [x2, #44]
	stp	w8, w9, [sp, #192]              ; 8-byte Folded Spill
	ldp	w12, w13, [x2]
Lloh20:
	adrp	x8, lCPI1_0@PAGE
Lloh21:
	ldr	q23, [x8, lCPI1_0@PAGEOFF]
Lloh22:
	adrp	x8, lCPI1_1@PAGE
Lloh23:
	ldr	q20, [x8, lCPI1_1@PAGEOFF]
Lloh24:
	adrp	x8, lCPI1_2@PAGE
Lloh25:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #64]                   ; 16-byte Spill
Lloh26:
	adrp	x8, lCPI1_3@PAGE
Lloh27:
	ldr	q0, [x8, lCPI1_3@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Spill
Lloh28:
	adrp	x8, lCPI1_4@PAGE
Lloh29:
	ldr	q0, [x8, lCPI1_4@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Spill
Lloh30:
	adrp	x8, lCPI1_5@PAGE
Lloh31:
	ldr	q0, [x8, lCPI1_5@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
	adrp	x19, lCPI1_14@PAGE
	mov	w25, #2560                      ; =0xa00
	mov	w28, #4608                      ; =0x1200
	mov	w23, #5120                      ; =0x1400
	mov	w24, #5632                      ; =0x1600
	mov	w21, #6656                      ; =0x1a00
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #224]                  ; 16-byte Spill
	ldp	w14, w8, [x2, #8]
	str	x8, [sp, #184]                  ; 8-byte Spill
	str	w3, [sp, #180]                  ; 4-byte Spill
	str	q23, [sp, #320]                 ; 16-byte Spill
	str	q20, [sp, #160]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	ldr	w22, [sp, #180]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x12, [sp, #216]                 ; 8-byte Reload
	add	w8, w12, #1
	ldp	w10, w9, [sp, #192]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w12, wzr, w12, eq
	ldp	w14, w9, [sp, #208]             ; 8-byte Folded Reload
	cinc	w9, w9, eq
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w13, wzr, w9, ne
	add	w14, w14, w8
	add	w27, w27, #1
	cmp	w27, w22
	b.eq	LBB1_580
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_15 Depth 2
                                        ;     Child Loop BB1_18 Depth 2
                                        ;     Child Loop BB1_21 Depth 2
                                        ;     Child Loop BB1_24 Depth 2
                                        ;     Child Loop BB1_27 Depth 2
                                        ;     Child Loop BB1_30 Depth 2
                                        ;     Child Loop BB1_33 Depth 2
                                        ;     Child Loop BB1_36 Depth 2
                                        ;     Child Loop BB1_38 Depth 2
                                        ;     Child Loop BB1_40 Depth 2
                                        ;       Child Loop BB1_78 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_84 Depth 3
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_90 Depth 3
                                        ;       Child Loop BB1_93 Depth 3
                                        ;       Child Loop BB1_96 Depth 3
                                        ;       Child Loop BB1_99 Depth 3
                                        ;       Child Loop BB1_102 Depth 3
                                        ;       Child Loop BB1_105 Depth 3
                                        ;       Child Loop BB1_108 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
                                        ;       Child Loop BB1_114 Depth 3
                                        ;       Child Loop BB1_117 Depth 3
                                        ;       Child Loop BB1_120 Depth 3
                                        ;       Child Loop BB1_123 Depth 3
                                        ;       Child Loop BB1_43 Depth 3
                                        ;       Child Loop BB1_529 Depth 3
                                        ;       Child Loop BB1_126 Depth 3
                                        ;       Child Loop BB1_208 Depth 3
                                        ;       Child Loop BB1_290 Depth 3
                                        ;       Child Loop BB1_372 Depth 3
                                        ;       Child Loop BB1_453 Depth 3
                                        ;       Child Loop BB1_456 Depth 3
                                        ;         Child Loop BB1_458 Depth 4
                                        ;       Child Loop BB1_523 Depth 3
                                        ;       Child Loop BB1_525 Depth 3
                                        ;     Child Loop BB1_564 Depth 2
	ubfiz	x8, x12, #5, #32
	ldr	x15, [sp, #184]                 ; 8-byte Reload
	cmp	x8, x15
	csel	x9, x8, xzr, ls
	subs	x10, x15, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x15, x9
	stp	w12, w13, [x20]
	stp	w14, w13, [sp, #208]            ; 8-byte Folded Spill
	str	w14, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x15, #2, hi
	csel	x26, x10, xzr, ls
	cmp	x26, #32
	str	x12, [sp, #216]                 ; 8-byte Spill
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x26, [sp, #200]                 ; 8-byte Reload
	mov	x0, x26
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x26
	mov	x1, x20
	bl	_llm_attention.full_packet
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x22, x26, #3
	cbz	x22, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	ldr	x0, [sp, #200]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x22, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	ldr	x0, [sp, #200]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x22, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	ldr	x0, [sp, #200]                  ; 8-byte Reload
	mov	x1, x20
	bl	_llm_attention.full_packet
	cmp	x22, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	str	w27, [sp, #2976]                ; 4-byte Spill
	ldr	x27, [sp, #200]                 ; 8-byte Reload
	mov	x0, x27
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x27
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x27
	mov	x1, x20
	bl	_llm_attention.full_packet
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x27
	ldr	w27, [sp, #2976]                ; 4-byte Reload
	mov	x1, x20
	bl	_llm_attention.full_packet
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w9, w26, #0x7
	ldr	q23, [sp, #320]                 ; 16-byte Reload
	ldr	q20, [sp, #160]                 ; 16-byte Reload
	cbz	w9, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w22, #3
	dup.4s	v21, w9
	str	w8, [x20, #36]
	cmhi.4s	v0, v21, v20
	cmhi.4s	v15, v21, v23
	uzp1.8h	v1, v15, v0
	str	q1, [sp, #2144]                 ; 16-byte Spill
	umaxv.8h	h1, v1
	fmov	w9, s1
	tbz	w9, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x9, [x20, #136]
	ldr	x10, [sp, #200]                 ; 8-byte Reload
	ldr	x10, [x10]
	xtn.4h	v1, v15
	ldr	x11, [sp, #216]                 ; 8-byte Reload
	orr	w8, w8, w11, lsl #5
	dup.4s	v2, w8
	uzp1.8b	v3, v1, v0
	orr.16b	v1, v2, v23
	and.16b	v1, v15, v1
	ushll.2d	v4, v1, #7
	umov.b	w8, v3[0]
	tbz	w8, #0, LBB1_16
; %bb.14:                               ; %copy.active.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	fmov	x12, d4
	add	x12, x10, x12, lsl #2
LBB1_15:                                ; %copy.chunk.i.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x12, x11]
	str	q3, [x9, x11]
	add	x11, x11, #16
	cmp	x11, #512
	b.ne	LBB1_15
LBB1_16:                                ; %copy.continue.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.s	w12, v21[1]
	cmp	w12, #1
	cset	w11, hi
	str	w11, [sp, #300]                 ; 4-byte Spill
	cmp	w12, #2
	b.lo	LBB1_19
; %bb.17:                               ; %copy.active133.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	add	x13, x9, #512
	mov.d	x14, v4[1]
	add	x14, x10, x14, lsl #2
LBB1_18:                                ; %copy.chunk.i340.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x14, x11]
	str	q3, [x13, x11]
	add	x11, x11, #16
	cmp	x11, #512
	b.ne	LBB1_18
LBB1_19:                                ; %copy.continue134.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ushll2.2d	v5, v1, #7
	mov.s	w17, v21[2]
	cmp	w17, #2
	cset	w26, hi
	cmp	w17, #3
	b.lo	LBB1_22
; %bb.20:                               ; %copy.active135.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	add	x13, x9, #1024
	fmov	x14, d5
	add	x14, x10, x14, lsl #2
LBB1_21:                                ; %copy.chunk.i344.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x14, x11]
	str	q3, [x13, x11]
	add	x11, x11, #16
	cmp	x11, #512
	b.ne	LBB1_21
LBB1_22:                                ; %copy.continue136.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.s	w15, v21[3]
	cmp	w15, #3
	cset	w11, hi
	str	w11, [sp, #296]                 ; 4-byte Spill
	cmp	w15, #4
	b.lo	LBB1_25
; %bb.23:                               ; %copy.active137.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	add	x13, x9, #1536
	mov.d	x14, v5[1]
	add	x14, x10, x14, lsl #2
LBB1_24:                                ; %copy.chunk.i348.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x14, x11]
	str	q3, [x13, x11]
	add	x11, x11, #16
	cmp	x11, #512
	b.ne	LBB1_24
LBB1_25:                                ; %copy.continue138.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr.16b	v2, v2, v20
	and.16b	v2, v0, v2
	ushll.2d	v6, v2, #7
	fmov	w11, s21
	cmp	w11, #4
	cset	w13, hi
	cmp	w11, #5
	b.lo	LBB1_28
; %bb.26:                               ; %copy.active139.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	add	x14, x9, #2048
	fmov	x16, d6
	add	x16, x10, x16, lsl #2
LBB1_27:                                ; %copy.chunk.i352.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x16, x11]
	str	q3, [x14, x11]
	add	x11, x11, #16
	cmp	x11, #512
	b.ne	LBB1_27
LBB1_28:                                ; %copy.continue140.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	cmp	w12, #5
	cset	w14, hi
	cmp	w12, #6
	b.lo	LBB1_31
; %bb.29:                               ; %copy.active141.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	add	x12, x9, #2560
	mov.d	x16, v6[1]
	add	x16, x10, x16, lsl #2
LBB1_30:                                ; %copy.chunk.i356.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x16, x11]
	str	q3, [x12, x11]
	add	x11, x11, #16
	cmp	x11, #512
	b.ne	LBB1_30
LBB1_31:                                ; %copy.continue142.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ushll2.2d	v7, v2, #7
	cmp	w17, #6
	cset	w16, hi
	cmp	w17, #7
	b.lo	LBB1_34
; %bb.32:                               ; %copy.active143.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	add	x12, x9, #3072
	fmov	x17, d7
	add	x17, x10, x17, lsl #2
LBB1_33:                                ; %copy.chunk.i360.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x17, x11]
	str	q3, [x12, x11]
	add	x11, x11, #16
	cmp	x11, #512
	b.ne	LBB1_33
LBB1_34:                                ; %copy.continue144.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q6, [sp, #96]                   ; 16-byte Spill
	stp	q5, q4, [sp, #128]              ; 32-byte Folded Spill
	ldr	x11, [sp, #200]                 ; 8-byte Reload
	ldr	x17, [x11, #16]
	ldr	x0, [x11, #32]
	ldr	x11, [x11, #48]
	str	x11, [sp, #120]                 ; 8-byte Spill
	cmp	w15, #7
	cset	w1, hi
	cmp	w15, #8
	b.lo	LBB1_37
; %bb.35:                               ; %copy.active145.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x11, #0                         ; =0x0
	add	x15, x9, #3584
	mov.d	x2, v7[1]
	add	x10, x10, x2, lsl #2
LBB1_36:                                ; %copy.chunk.i364.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q3, [x10, x11]
	str	q3, [x15, x11]
	add	x11, x11, #16
	cmp	x11, #512
	b.ne	LBB1_36
LBB1_37:                                ; %direct.true.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q7, [sp, #80]                   ; 16-byte Spill
	mov	x10, #0                         ; =0x0
	add	x11, x9, #3, lsl #12            ; =12288
	dup.2d	v3, x11
	str	q3, [sp, #272]                  ; 16-byte Spill
	add	x11, x9, #19, lsl #12           ; =77824
	dup.2d	v3, x11
	str	q3, [sp, #1472]                 ; 16-byte Spill
	sshll.2d	v5, v15, #0
	sshll.2d	v6, v0, #0
	sshll2.2d	v18, v15, #0
	sshll2.2d	v17, v0, #0
	dup.2d	v7, x9
	add	x2, x9, #35, lsl #12            ; =143360
	ushll.2d	v16, v1, #0
	add	x15, x9, #1, lsl #12            ; =4096
	ushll.2d	v3, v2, #0
	add	x3, x9, #2, lsl #12             ; =8192
	ushll2.2d	v1, v1, #0
	mov	w11, #12800                     ; =0x3200
	movk	w11, #2, lsl #16
	add	x4, x9, x11
	ushll2.2d	v2, v2, #0
	mov	w11, #13312                     ; =0x3400
	movk	w11, #2, lsl #16
	add	x5, x9, x11
	ushr.2d	v4, v2, #2
	ushr.2d	v2, v1, #2
	ushr.2d	v3, v3, #2
	ushr.2d	v1, v16, #2
	and.16b	v16, v17, v7
	str	q16, [sp, #2832]                ; 16-byte Spill
	and.16b	v16, v18, v7
	str	q16, [sp, #2816]                ; 16-byte Spill
	and.16b	v16, v6, v7
	str	q16, [sp, #2800]                ; 16-byte Spill
	and.16b	v7, v5, v7
	str	q7, [sp, #2784]                 ; 16-byte Spill
	ldr	q7, [sp, #64]                   ; 16-byte Reload
	str	q17, [sp, #2032]                ; 16-byte Spill
	and.16b	v7, v17, v7
	str	q7, [sp, #2768]                 ; 16-byte Spill
	ldr	q7, [sp, #48]                   ; 16-byte Reload
	str	q18, [sp, #2016]                ; 16-byte Spill
	and.16b	v7, v18, v7
	str	q7, [sp, #2752]                 ; 16-byte Spill
	ldr	q7, [sp, #32]                   ; 16-byte Reload
	and.16b	v6, v6, v7
	str	q6, [sp, #2736]                 ; 16-byte Spill
	ldr	q6, [sp, #16]                   ; 16-byte Reload
	and.16b	v5, v5, v6
	str	q5, [sp, #2720]                 ; 16-byte Spill
LBB1_38:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x15, x10
	ldp	q5, q6, [x9]
	cmhs.4s	v7, v20, v21
	and.16b	v6, v7, v6
	cmhs.4s	v7, v23, v21
	and.16b	v5, v7, v5
	stp	q5, q6, [x9]
	add	x10, x10, #32
	cmp	x10, #1, lsl #12                ; =4096
	b.ne	LBB1_38
; %bb.39:                               ; %direct.false.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x6, #0                          ; =0x0
	fmov	x9, d4
	add	x9, x9, x9, lsl #13
	fmov	d5, x9
	mov.d	x9, v4[1]
	add	x9, x9, x9, lsl #13
	mov.d	v5[1], x9
	fmov	x9, d3
	add	x9, x9, x9, lsl #13
	mov.d	x10, v3[1]
	fmov	d3, x9
	add	x9, x10, x10, lsl #13
	mov.d	v3[1], x9
	fmov	x9, d2
	add	x9, x9, x9, lsl #13
	fmov	d4, x9
	mov.d	x9, v2[1]
	add	x9, x9, x9, lsl #13
	mov.d	v4[1], x9
	fmov	x9, d1
	add	x9, x9, x9, lsl #13
	fmov	d2, x9
	mov.d	x9, v1[1]
	add	x9, x9, x9, lsl #13
	mov.d	v2[1], x9
	sshll.2d	v1, v15, #0
	sshll.2d	v6, v0, #0
Lloh32:
	adrp	x9, lCPI1_9@PAGE
Lloh33:
	ldr	q7, [x9, lCPI1_9@PAGEOFF]
	str	q7, [sp, #256]                  ; 16-byte Spill
	and.16b	v7, v1, v7
	str	q7, [sp, #1872]                 ; 16-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v7, w9
	and.16b	v16, v0, v7
	str	q16, [sp, #1568]                ; 16-byte Spill
	str	q7, [sp, #240]                  ; 16-byte Spill
	and.16b	v7, v15, v7
	str	q7, [sp, #1552]                 ; 16-byte Spill
	and.16b	v1, v1, v2
	str	q1, [sp, #1792]                 ; 16-byte Spill
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	and.16b	v1, v1, v4
	str	q1, [sp, #1776]                 ; 16-byte Spill
	and.16b	v1, v6, v3
	str	q1, [sp, #1760]                 ; 16-byte Spill
	ldr	q1, [sp, #2032]                 ; 16-byte Reload
	and.16b	v1, v1, v5
	str	q1, [sp, #1744]                 ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #2976]                 ; 16-byte Spill
	movi.2d	v20, #0000000000000000
	movi.2d	v17, #0000000000000000
	str	q1, [sp, #2128]                 ; 16-byte Spill
	str	q1, [sp, #2112]                 ; 16-byte Spill
	str	q1, [sp, #2096]                 ; 16-byte Spill
	str	q1, [sp, #2080]                 ; 16-byte Spill
	str	q1, [sp, #1728]                 ; 16-byte Spill
	str	q1, [sp, #1712]                 ; 16-byte Spill
	str	q1, [sp, #1696]                 ; 16-byte Spill
	str	q1, [sp, #1680]                 ; 16-byte Spill
	str	q1, [sp, #2064]                 ; 16-byte Spill
	str	q1, [sp, #2048]                 ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v6, #0000000000000000
	str	q1, [sp, #2000]                 ; 16-byte Spill
	str	q1, [sp, #1424]                 ; 16-byte Spill
	str	q1, [sp, #1408]                 ; 16-byte Spill
	str	q1, [sp, #1392]                 ; 16-byte Spill
	str	q1, [sp, #1376]                 ; 16-byte Spill
	str	q1, [sp, #1360]                 ; 16-byte Spill
	str	q1, [sp, #2704]                 ; 16-byte Spill
	str	q1, [sp, #2688]                 ; 16-byte Spill
	str	q1, [sp, #2672]                 ; 16-byte Spill
	str	q1, [sp, #2656]                 ; 16-byte Spill
	str	q1, [sp, #2640]                 ; 16-byte Spill
	str	q1, [sp, #2624]                 ; 16-byte Spill
	str	q1, [sp, #2608]                 ; 16-byte Spill
	str	q1, [sp, #2592]                 ; 16-byte Spill
	str	q1, [sp, #2576]                 ; 16-byte Spill
	str	q1, [sp, #2560]                 ; 16-byte Spill
	str	q1, [sp, #2544]                 ; 16-byte Spill
	str	q1, [sp, #2528]                 ; 16-byte Spill
	str	q1, [sp, #1984]                 ; 16-byte Spill
	str	q1, [sp, #2512]                 ; 16-byte Spill
	str	q1, [sp, #2496]                 ; 16-byte Spill
	str	q1, [sp, #2480]                 ; 16-byte Spill
	str	q1, [sp, #2464]                 ; 16-byte Spill
	str	q1, [sp, #2448]                 ; 16-byte Spill
	str	q1, [sp, #2432]                 ; 16-byte Spill
	str	q1, [sp, #2416]                 ; 16-byte Spill
	str	q1, [sp, #2400]                 ; 16-byte Spill
	str	q1, [sp, #2384]                 ; 16-byte Spill
	str	q1, [sp, #2368]                 ; 16-byte Spill
	str	q1, [sp, #2352]                 ; 16-byte Spill
	str	q1, [sp, #2336]                 ; 16-byte Spill
	str	q1, [sp, #2320]                 ; 16-byte Spill
	str	q1, [sp, #2304]                 ; 16-byte Spill
	str	q1, [sp, #2288]                 ; 16-byte Spill
	str	q1, [sp, #2272]                 ; 16-byte Spill
	str	q1, [sp, #2256]                 ; 16-byte Spill
	str	q1, [sp, #2240]                 ; 16-byte Spill
	str	q1, [sp, #2224]                 ; 16-byte Spill
	movi.2d	v23, #0000000000000000
	str	q1, [sp, #2960]                 ; 16-byte Spill
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	str	q1, [sp, #2864]                 ; 16-byte Spill
	str	q1, [sp, #2896]                 ; 16-byte Spill
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	str	q1, [sp, #2928]                 ; 16-byte Spill
	str	q1, [sp, #2912]                 ; 16-byte Spill
	str	q1, [sp, #1456]                 ; 16-byte Spill
	str	q1, [sp, #1440]                 ; 16-byte Spill
	str	q21, [sp, #304]                 ; 16-byte Spill
	str	q15, [sp, #1616]                ; 16-byte Spill
LBB1_40:                                ; %direct.true152.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_78 Depth 3
                                        ;       Child Loop BB1_81 Depth 3
                                        ;       Child Loop BB1_84 Depth 3
                                        ;       Child Loop BB1_87 Depth 3
                                        ;       Child Loop BB1_90 Depth 3
                                        ;       Child Loop BB1_93 Depth 3
                                        ;       Child Loop BB1_96 Depth 3
                                        ;       Child Loop BB1_99 Depth 3
                                        ;       Child Loop BB1_102 Depth 3
                                        ;       Child Loop BB1_105 Depth 3
                                        ;       Child Loop BB1_108 Depth 3
                                        ;       Child Loop BB1_111 Depth 3
                                        ;       Child Loop BB1_114 Depth 3
                                        ;       Child Loop BB1_117 Depth 3
                                        ;       Child Loop BB1_120 Depth 3
                                        ;       Child Loop BB1_123 Depth 3
                                        ;       Child Loop BB1_43 Depth 3
                                        ;       Child Loop BB1_529 Depth 3
                                        ;       Child Loop BB1_126 Depth 3
                                        ;       Child Loop BB1_208 Depth 3
                                        ;       Child Loop BB1_290 Depth 3
                                        ;       Child Loop BB1_372 Depth 3
                                        ;       Child Loop BB1_453 Depth 3
                                        ;       Child Loop BB1_456 Depth 3
                                        ;         Child Loop BB1_458 Depth 4
                                        ;       Child Loop BB1_523 Depth 3
                                        ;       Child Loop BB1_525 Depth 3
	sshll.2d	v2, v15, #0
	sshll.2d	v3, v0, #0
	ldr	q1, [sp, #272]                  ; 16-byte Reload
	ldr	q5, [sp, #2032]                 ; 16-byte Reload
	ldr	q4, [sp, #2896]                 ; 16-byte Reload
	bit.16b	v4, v1, v5
	str	q4, [sp, #2896]                 ; 16-byte Spill
	ldr	q7, [sp, #2016]                 ; 16-byte Reload
	bit.16b	v10, v1, v7
	ldr	q4, [sp, #2864]                 ; 16-byte Reload
	bit.16b	v4, v1, v3
	str	q4, [sp, #2864]                 ; 16-byte Spill
	bit.16b	v9, v1, v2
Lloh34:
	adrp	x9, lCPI1_10@PAGE
Lloh35:
	ldr	q4, [x9, lCPI1_10@PAGEOFF]
	ldr	q1, [sp, #2912]                 ; 16-byte Reload
	bit.16b	v1, v4, v5
	str	q1, [sp, #2912]                 ; 16-byte Spill
Lloh36:
	adrp	x9, lCPI1_11@PAGE
Lloh37:
	ldr	q5, [x9, lCPI1_11@PAGEOFF]
	bit.16b	v30, v5, v7
Lloh38:
	adrp	x9, lCPI1_12@PAGE
Lloh39:
	ldr	q1, [x9, lCPI1_12@PAGEOFF]
	ldr	q7, [sp, #2928]                 ; 16-byte Reload
	bit.16b	v7, v1, v3
	str	q7, [sp, #2928]                 ; 16-byte Spill
Lloh40:
	adrp	x9, lCPI1_13@PAGE
Lloh41:
	ldr	q7, [x9, lCPI1_13@PAGEOFF]
	bit.16b	v29, v7, v2
	cmp	x6, #512
	str	q20, [sp, #1968]                ; 16-byte Spill
	str	q17, [sp, #1952]                ; 16-byte Spill
	str	q29, [sp, #2848]                ; 16-byte Spill
	b.ne	LBB1_76
; %bb.41:                               ; %direct.true702.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	b	LBB1_43
LBB1_42:                                ; %else356
                                        ;   in Loop: Header=BB1_43 Depth=3
	str	q17, [sp, #1952]                ; 16-byte Spill
	str	q20, [sp, #1968]                ; 16-byte Spill
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x10, #2048
	b.eq	LBB1_527
LBB1_43:                                ; %direct.true702.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v2, v15, #0
	sshll.2d	v3, v0, #0
	and	x11, x10, #0x7f
	lsr	x7, x10, #7
	orr	x22, x7, #0x2000
	dup.2d	v16, x22
	ldr	q17, [sp, #1792]                ; 16-byte Reload
	add.2d	v17, v16, v17
	ldr	q20, [sp, #1776]                ; 16-byte Reload
	add.2d	v20, v16, v20
	ldr	q21, [sp, #1760]                ; 16-byte Reload
	add.2d	v21, v16, v21
	ldr	q22, [sp, #1744]                ; 16-byte Reload
	add.2d	v16, v16, v22
	shl.2d	v16, v16, #7
	shl.2d	v21, v21, #7
	shl.2d	v20, v20, #7
	shl.2d	v17, v17, #7
	dup.2d	v22, x11
	orr.16b	v17, v17, v22
	orr.16b	v20, v20, v22
	orr.16b	v21, v21, v22
	orr.16b	v16, v16, v22
	ldr	q22, [sp, #2032]                ; 16-byte Reload
	ldr	q28, [sp, #2080]                ; 16-byte Reload
	bit.16b	v28, v16, v22
	str	q28, [sp, #2080]                ; 16-byte Spill
	ldr	q16, [sp, #2096]                ; 16-byte Reload
	bit.16b	v16, v21, v3
	str	q16, [sp, #2096]                ; 16-byte Spill
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	ldr	q16, [sp, #2112]                ; 16-byte Reload
	bit.16b	v16, v20, v3
	str	q16, [sp, #2112]                ; 16-byte Spill
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	bit.16b	v3, v17, v2
	str	q3, [sp, #2128]                 ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	ldr	q20, [sp, #1968]                ; 16-byte Reload
	cbnz	x7, LBB1_53
; %bb.44:                               ; %direct.true715.i.i
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q2, [x19, lCPI1_14@PAGEOFF]
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	and.16b	v2, v3, v2
	addv.8h	h2, v2
	fmov	w11, s2
	ldr	q2, [sp, #2128]                 ; 16-byte Reload
	shl.2d	v3, v2, #2
	dup.2d	v2, x17
	add.2d	v17, v2, v3
	movi.2d	v3, #0000000000000000
	tbnz	w11, #0, LBB1_69
; %bb.45:                               ; %else1569
                                        ;   in Loop: Header=BB1_43 Depth=3
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_70
LBB1_46:                                ; %else1575
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q17, [sp, #2112]                ; 16-byte Reload
	shl.2d	v17, v17, #2
	add.2d	v17, v2, v17
	tbnz	w11, #2, LBB1_71
LBB1_47:                                ; %else1581
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbnz	w11, #3, LBB1_72
LBB1_48:                                ; %else1587
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q17, [sp, #2096]                ; 16-byte Reload
	shl.2d	v17, v17, #2
	add.2d	v17, v2, v17
	tbnz	w11, #4, LBB1_73
LBB1_49:                                ; %else1593
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbnz	w11, #5, LBB1_74
LBB1_50:                                ; %else1599
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q17, [sp, #2080]                ; 16-byte Reload
	shl.2d	v17, v17, #2
	add.2d	v2, v2, v17
	tbnz	w11, #6, LBB1_75
LBB1_51:                                ; %else1605
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbz	w11, #7, LBB1_53
LBB1_52:                                ; %cond.load1607
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x11, v2[1]
	ld1.s	{ v3 }[3], [x11]
LBB1_53:                                ; %direct.schedule.49.i.i
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q2, [x19, lCPI1_14@PAGEOFF]
	ldr	q17, [sp, #2144]                ; 16-byte Reload
	and.16b	v2, v17, v2
	addv.8h	h2, v2
	fmov	w11, s2
	bit.16b	v20, v16, v15
	dup.2d	v16, x9
	orr.16b	v17, v16, v29
	add.2d	v17, v9, v17
	tbnz	w11, #0, LBB1_62
; %bb.54:                               ; %else328
                                        ;   in Loop: Header=BB1_43 Depth=3
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_63
LBB1_55:                                ; %else332
                                        ;   in Loop: Header=BB1_43 Depth=3
	orr.16b	v17, v16, v30
	add.2d	v17, v10, v17
	tbnz	w11, #2, LBB1_64
LBB1_56:                                ; %else336
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbz	w11, #3, LBB1_58
LBB1_57:                                ; %cond.store337
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x7, v17[1]
	st1.s	{ v20 }[3], [x7]
LBB1_58:                                ; %else340
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q17, [sp, #1952]                ; 16-byte Reload
	bit.16b	v17, v3, v0
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v16, v3
	ldr	q21, [sp, #2864]                ; 16-byte Reload
	add.2d	v3, v21, v3
	tbnz	w11, #4, LBB1_65
; %bb.59:                               ; %else344
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbnz	w11, #5, LBB1_66
LBB1_60:                                ; %else348
                                        ;   in Loop: Header=BB1_43 Depth=3
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v3, v16, v3
	ldr	q16, [sp, #2896]                ; 16-byte Reload
	add.2d	v3, v16, v3
	tbnz	w11, #6, LBB1_67
LBB1_61:                                ; %else352
                                        ;   in Loop: Header=BB1_43 Depth=3
	tbz	w11, #7, LBB1_42
	b	LBB1_68
LBB1_62:                                ; %cond.store325
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x7, d17
	str	s20, [x7]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_55
LBB1_63:                                ; %cond.store329
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x7, v17[1]
	st1.s	{ v20 }[1], [x7]
	orr.16b	v17, v16, v30
	add.2d	v17, v10, v17
	tbz	w11, #2, LBB1_56
LBB1_64:                                ; %cond.store333
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x7, d17
	st1.s	{ v20 }[2], [x7]
	tbnz	w11, #3, LBB1_57
	b	LBB1_58
LBB1_65:                                ; %cond.store341
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x7, d3
	str	s17, [x7]
	tbz	w11, #5, LBB1_60
LBB1_66:                                ; %cond.store345
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x7, v3[1]
	st1.s	{ v17 }[1], [x7]
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v3, v16, v3
	ldr	q16, [sp, #2896]                ; 16-byte Reload
	add.2d	v3, v16, v3
	tbz	w11, #6, LBB1_61
LBB1_67:                                ; %cond.store349
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x7, d3
	st1.s	{ v17 }[2], [x7]
	tbz	w11, #7, LBB1_42
LBB1_68:                                ; %cond.store353
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x11, v3[1]
	st1.s	{ v17 }[3], [x11]
	b	LBB1_42
LBB1_69:                                ; %cond.load1565
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x7, d17
	ldr	s16, [x7]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_46
LBB1_70:                                ; %cond.load1571
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x7, v17[1]
	ld1.s	{ v16 }[1], [x7]
	ldr	q17, [sp, #2112]                ; 16-byte Reload
	shl.2d	v17, v17, #2
	add.2d	v17, v2, v17
	tbz	w11, #2, LBB1_47
LBB1_71:                                ; %cond.load1577
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x7, d17
	ld1.s	{ v16 }[2], [x7]
	tbz	w11, #3, LBB1_48
LBB1_72:                                ; %cond.load1583
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x7, v17[1]
	ld1.s	{ v16 }[3], [x7]
	ldr	q17, [sp, #2096]                ; 16-byte Reload
	shl.2d	v17, v17, #2
	add.2d	v17, v2, v17
	tbz	w11, #4, LBB1_49
LBB1_73:                                ; %cond.load1589
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x7, d17
	ld1.s	{ v3 }[0], [x7]
	tbz	w11, #5, LBB1_50
LBB1_74:                                ; %cond.load1595
                                        ;   in Loop: Header=BB1_43 Depth=3
	mov.d	x7, v17[1]
	ld1.s	{ v3 }[1], [x7]
	ldr	q17, [sp, #2080]                ; 16-byte Reload
	shl.2d	v17, v17, #2
	add.2d	v2, v2, v17
	tbz	w11, #6, LBB1_51
LBB1_75:                                ; %cond.load1601
                                        ;   in Loop: Header=BB1_43 Depth=3
	fmov	x7, d2
	ld1.s	{ v3 }[2], [x7]
	tbnz	w11, #7, LBB1_52
	b	LBB1_53
LBB1_76:                                ; %direct.true155.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	lsl	x9, x6, #4
	dup.2d	v17, x9
	ldr	q2, [sp, #1792]                 ; 16-byte Reload
	add.2d	v2, v17, v2
	shl.2d	v2, v2, #7
	tbz	w8, #0, LBB1_79
; %bb.77:                               ; %copy.active164.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	fmov	x10, d9
	fmov	x11, d29
	add	x10, x10, x11
	fmov	x11, d2
	add	x11, x17, x11, lsl #2
LBB1_78:                                ; %copy.chunk.i368.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x11, x9]
	str	q3, [x10, x9]
	add	x9, x9, #16
	cmp	x9, #2, lsl #12                 ; =8192
	b.ne	LBB1_78
LBB1_79:                                ; %copy.continue165.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov.d	x10, v2[1]
	ldr	w9, [sp, #300]                  ; 4-byte Reload
	cbz	w9, LBB1_82
; %bb.80:                               ; %copy.active166.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	mov.d	x11, v9[1]
	mov.d	x7, v29[1]
	add	x11, x11, x7
	add	x7, x17, x10, lsl #2
LBB1_81:                                ; %copy.chunk.i371.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x7, x9]
	str	q3, [x11, x9]
	add	x9, x9, #16
	cmp	x9, #2, lsl #12                 ; =8192
	b.ne	LBB1_81
LBB1_82:                                ; %copy.continue167.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q3, [sp, #1776]                 ; 16-byte Reload
	add.2d	v3, v17, v3
	shl.2d	v16, v3, #7
	cbz	w26, LBB1_85
; %bb.83:                               ; %copy.active168.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	fmov	x11, d10
	fmov	x7, d30
	add	x11, x11, x7
	fmov	x7, d16
	add	x7, x17, x7, lsl #2
LBB1_84:                                ; %copy.chunk.i375.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x7, x9]
	str	q3, [x11, x9]
	add	x9, x9, #16
	cmp	x9, #2, lsl #12                 ; =8192
	b.ne	LBB1_84
LBB1_85:                                ; %copy.continue169.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov.d	x7, v16[1]
	ldr	w9, [sp, #296]                  ; 4-byte Reload
	cbz	w9, LBB1_88
; %bb.86:                               ; %copy.active170.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	mov.d	x11, v10[1]
	mov.d	x22, v30[1]
	add	x11, x11, x22
	add	x22, x17, x7, lsl #2
LBB1_87:                                ; %copy.chunk.i379.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q3, [x22, x9]
	str	q3, [x11, x9]
	add	x9, x9, #16
	cmp	x9, #2, lsl #12                 ; =8192
	b.ne	LBB1_87
LBB1_88:                                ; %copy.continue171.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x12, x26
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	add.2d	v3, v17, v3
	shl.2d	v3, v3, #7
	cbz	w13, LBB1_91
; %bb.89:                               ; %copy.active172.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q20, [sp, #2864]                ; 16-byte Reload
	fmov	x11, d20
	ldr	q20, [sp, #2928]                ; 16-byte Reload
	fmov	x22, d20
	add	x11, x11, x22
	fmov	x22, d3
	add	x22, x17, x22, lsl #2
LBB1_90:                                ; %copy.chunk.i383.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q20, [x22, x9]
	str	q20, [x11, x9]
	add	x9, x9, #16
	cmp	x9, #2, lsl #12                 ; =8192
	b.ne	LBB1_90
LBB1_91:                                ; %copy.continue173.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov.d	x9, v3[1]
	cbz	w14, LBB1_94
; %bb.92:                               ; %copy.active174.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q20, [sp, #2864]                ; 16-byte Reload
	mov.d	x22, v20[1]
	ldr	q20, [sp, #2928]                ; 16-byte Reload
	mov.d	x26, v20[1]
	add	x22, x22, x26
	add	x26, x17, x9, lsl #2
LBB1_93:                                ; %copy.chunk.i387.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q20, [x26, x11]
	str	q20, [x22, x11]
	add	x11, x11, #16
	cmp	x11, #2, lsl #12                ; =8192
	b.ne	LBB1_93
LBB1_94:                                ; %copy.continue175.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q20, [sp, #1744]                ; 16-byte Reload
	add.2d	v17, v17, v20
	shl.2d	v17, v17, #7
	cbz	w16, LBB1_97
; %bb.95:                               ; %copy.active176.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q20, [sp, #2896]                ; 16-byte Reload
	fmov	x22, d20
	ldr	q20, [sp, #2912]                ; 16-byte Reload
	fmov	x26, d20
	add	x22, x22, x26
	fmov	x26, d17
	add	x26, x17, x26, lsl #2
LBB1_96:                                ; %copy.chunk.i391.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q20, [x26, x11]
	str	q20, [x22, x11]
	add	x11, x11, #16
	cmp	x11, #2, lsl #12                ; =8192
	b.ne	LBB1_96
LBB1_97:                                ; %copy.continue177.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov.d	x30, v17[1]
	cbz	w1, LBB1_100
; %bb.98:                               ; %copy.active178.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q20, [sp, #2896]                ; 16-byte Reload
	mov.d	x22, v20[1]
	ldr	q20, [sp, #2912]                ; 16-byte Reload
	mov.d	x26, v20[1]
	add	x22, x22, x26
	add	x26, x17, x30, lsl #2
LBB1_99:                                ; %copy.chunk.i395.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q20, [x26, x11]
	str	q20, [x22, x11]
	add	x11, x11, #16
	cmp	x11, #2, lsl #12                ; =8192
	b.ne	LBB1_99
LBB1_100:                               ; %direct.schedule.7.thread.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	sshll.2d	v20, v15, #0
	ldr	q21, [sp, #1472]                ; 16-byte Reload
	ldr	q22, [sp, #2976]                ; 16-byte Reload
	bit.16b	v22, v21, v20
	str	q22, [sp, #2976]                ; 16-byte Spill
	bit.16b	v25, v7, v20
	tbz	w8, #0, LBB1_103
; %bb.101:                              ; %copy.active191.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q7, [sp, #2976]                 ; 16-byte Reload
	fmov	x22, d7
	fmov	x26, d25
	add	x22, x22, x26
	fmov	x26, d2
	add	x26, x0, x26, lsl #2
LBB1_102:                               ; %copy.chunk.i399.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x26, x11]
	str	q2, [x22, x11]
	add	x11, x11, #16
	cmp	x11, #2, lsl #12                ; =8192
	b.ne	LBB1_102
LBB1_103:                               ; %copy.continue192.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w11, [sp, #300]                 ; 4-byte Reload
	cbz	w11, LBB1_106
; %bb.104:                              ; %copy.active193.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x11, #0                         ; =0x0
	ldr	q2, [sp, #2976]                 ; 16-byte Reload
	mov.d	x22, v2[1]
	mov.d	x26, v25[1]
	add	x22, x22, x26
	add	x10, x0, x10, lsl #2
LBB1_105:                               ; %copy.chunk.i402.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x10, x11]
	str	q2, [x22, x11]
	add	x11, x11, #16
	cmp	x11, #2, lsl #12                ; =8192
	b.ne	LBB1_105
LBB1_106:                               ; %copy.continue194.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q2, [sp, #1472]                 ; 16-byte Reload
	ldr	q7, [sp, #2016]                 ; 16-byte Reload
	bit.16b	v23, v2, v7
	bit.16b	v26, v5, v7
	mov	x26, x12
	cbz	w12, LBB1_109
; %bb.107:                              ; %copy.active195.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	fmov	x11, d23
	fmov	x22, d26
	add	x11, x11, x22
	fmov	x22, d16
	add	x22, x0, x22, lsl #2
LBB1_108:                               ; %copy.chunk.i406.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x22, x10]
	str	q2, [x11, x10]
	add	x10, x10, #16
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_108
LBB1_109:                               ; %copy.continue196.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	w10, [sp, #296]                 ; 4-byte Reload
	cbz	w10, LBB1_112
; %bb.110:                              ; %copy.active197.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	mov.d	x11, v23[1]
	mov.d	x22, v26[1]
	add	x11, x11, x22
	add	x7, x0, x7, lsl #2
LBB1_111:                               ; %copy.chunk.i410.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x7, x10]
	str	q2, [x11, x10]
	add	x10, x10, #16
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_111
LBB1_112:                               ; %copy.continue198.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	sshll.2d	v2, v0, #0
	ldr	q5, [sp, #1472]                 ; 16-byte Reload
	ldr	q7, [sp, #2960]                 ; 16-byte Reload
	bit.16b	v7, v5, v2
	str	q7, [sp, #2960]                 ; 16-byte Spill
	bit.16b	v27, v1, v2
	cbz	w13, LBB1_115
; %bb.113:                              ; %copy.active199.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	q1, [sp, #2960]                 ; 16-byte Reload
	fmov	x11, d1
	fmov	x7, d27
	add	x11, x11, x7
	fmov	x7, d3
	add	x7, x0, x7, lsl #2
LBB1_114:                               ; %copy.chunk.i414.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q1, [x7, x10]
	str	q1, [x11, x10]
	add	x10, x10, #16
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_114
LBB1_115:                               ; %copy.continue200.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w14, LBB1_118
; %bb.116:                              ; %copy.active201.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x10, #0                         ; =0x0
	ldr	q1, [sp, #2960]                 ; 16-byte Reload
	mov.d	x11, v1[1]
	mov.d	x7, v27[1]
	add	x11, x11, x7
	add	x9, x0, x9, lsl #2
LBB1_117:                               ; %copy.chunk.i418.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q1, [x9, x10]
	str	q1, [x11, x10]
	add	x10, x10, #16
	cmp	x10, #2, lsl #12                ; =8192
	b.ne	LBB1_117
LBB1_118:                               ; %copy.continue202.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	ldr	q2, [sp, #2032]                 ; 16-byte Reload
	bit.16b	v24, v1, v2
	bit.16b	v31, v4, v2
	cbz	w16, LBB1_121
; %bb.119:                              ; %copy.active203.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	fmov	x10, d24
	fmov	x11, d31
	add	x10, x10, x11
	fmov	x11, d17
	add	x11, x0, x11, lsl #2
LBB1_120:                               ; %copy.chunk.i422.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q1, [x11, x9]
	str	q1, [x10, x9]
	add	x9, x9, #16
	cmp	x9, #2, lsl #12                 ; =8192
	b.ne	LBB1_120
LBB1_121:                               ; %copy.continue204.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	cbz	w1, LBB1_124
; %bb.122:                              ; %copy.active205.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	mov.d	x10, v24[1]
	mov.d	x11, v31[1]
	add	x10, x10, x11
	add	x11, x0, x30, lsl #2
LBB1_123:                               ; %copy.chunk.i426.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q1, [x11, x9]
	str	q1, [x10, x9]
	add	x9, x9, #16
	cmp	x9, #2, lsl #12                 ; =8192
	b.ne	LBB1_123
LBB1_124:                               ; %direct.schedule.9.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q23, [sp, #1344]                ; 16-byte Spill
	mov	x7, #0                          ; =0x0
	ldr	q1, [sp, #2224]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2224]                 ; 16-byte Spill
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2240]                 ; 16-byte Spill
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2256]                 ; 16-byte Spill
	ldr	q1, [sp, #2272]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2272]                 ; 16-byte Spill
	ldr	q1, [sp, #2288]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2288]                 ; 16-byte Spill
	ldr	q1, [sp, #2304]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2304]                 ; 16-byte Spill
	ldr	q1, [sp, #2320]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2320]                 ; 16-byte Spill
	ldr	q1, [sp, #2336]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2336]                 ; 16-byte Spill
	str	q24, [sp, #1856]                ; 16-byte Spill
	str	q25, [sp, #1840]                ; 16-byte Spill
	str	q26, [sp, #1824]                ; 16-byte Spill
	str	q27, [sp, #1808]                ; 16-byte Spill
	b	LBB1_126
LBB1_125:                               ; %else582
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmul.4s	v4, v17, v7
	fmul.4s	v1, v16, v1
	ldr	q10, [sp, #2240]                ; 16-byte Reload
	fadd.4s	v1, v10, v1
	ldr	q15, [sp, #2224]                ; 16-byte Reload
	fadd.4s	v4, v15, v4
	fmul.4s	v7, v17, v21
	fmul.4s	v20, v16, v20
	ldr	q30, [sp, #2272]                ; 16-byte Reload
	fadd.4s	v20, v30, v20
	ldr	q9, [sp, #2256]                 ; 16-byte Reload
	fadd.4s	v7, v9, v7
	fmul.4s	v3, v17, v3
	fmul.4s	v2, v16, v2
	ldr	q22, [sp, #2304]                ; 16-byte Reload
	fadd.4s	v2, v22, v2
	ldr	q23, [sp, #2288]                ; 16-byte Reload
	fadd.4s	v3, v23, v3
	fmul.4s	v16, v16, v28
	fmul.4s	v17, v17, v29
	ldr	q21, [sp, #2320]                ; 16-byte Reload
	fadd.4s	v17, v21, v17
	ldr	q5, [sp, #2336]                 ; 16-byte Reload
	fadd.4s	v16, v5, v16
	bit.16b	v15, v4, v0
	str	q15, [sp, #2224]                ; 16-byte Spill
	mov.16b	v15, v27
	bit.16b	v10, v1, v27
	str	q10, [sp, #2240]                ; 16-byte Spill
	bit.16b	v9, v7, v0
	str	q9, [sp, #2256]                 ; 16-byte Spill
	bit.16b	v30, v20, v27
	str	q30, [sp, #2272]                ; 16-byte Spill
	bit.16b	v23, v3, v0
	str	q23, [sp, #2288]                ; 16-byte Spill
	bit.16b	v22, v2, v27
	str	q22, [sp, #2304]                ; 16-byte Spill
	bit.16b	v5, v16, v27
	str	q5, [sp, #2336]                 ; 16-byte Spill
	add	x7, x7, #4
	bit.16b	v21, v17, v0
	str	q21, [sp, #2320]                ; 16-byte Spill
	cmp	x7, #512
	mov.16b	v9, v24
	mov.16b	v10, v25
	ldr	q29, [sp, #2848]                ; 16-byte Reload
	mov.16b	v30, v26
	b.eq	LBB1_206
LBB1_126:                               ; %direct.true208.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q2, [x19, lCPI1_14@PAGEOFF]
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	str	q2, [sp, #2944]                 ; 16-byte Spill
	and.16b	v1, v1, v2
	addv.8h	h4, v1
	fmov	w9, s4
	dup.2d	v2, x7
	ldr	q1, [sp, #2720]                 ; 16-byte Reload
	orr.16b	v1, v2, v1
	ldr	q3, [sp, #2784]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w9, #0, LBB1_169
; %bb.127:                              ; %else359
                                        ;   in Loop: Header=BB1_126 Depth=3
	and	w9, w9, #0xff
	ldr	q5, [sp, #2864]                 ; 16-byte Reload
	ldr	q23, [sp, #2896]                ; 16-byte Reload
	tbnz	w9, #1, LBB1_170
LBB1_128:                               ; %else362
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q1, [sp, #2752]                 ; 16-byte Reload
	orr.16b	v1, v2, v1
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #2, LBB1_171
LBB1_129:                               ; %else366
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbnz	w9, #3, LBB1_172
LBB1_130:                               ; %else370
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q1, [sp, #2736]                 ; 16-byte Reload
	orr.16b	v1, v2, v1
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #4, LBB1_173
LBB1_131:                               ; %else374
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbnz	w9, #5, LBB1_174
LBB1_132:                               ; %else378
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q1, [sp, #2768]                 ; 16-byte Reload
	orr.16b	v1, v2, v1
	ldr	q3, [sp, #2832]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #6, LBB1_175
LBB1_133:                               ; %else382
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbnz	w9, #7, LBB1_176
LBB1_134:                               ; %else386
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	w9, s4
	orr.16b	v1, v2, v29
	add.2d	v3, v9, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w9, #0, LBB1_177
LBB1_135:                               ; %else393
                                        ;   in Loop: Header=BB1_126 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_178
LBB1_136:                               ; %else399
                                        ;   in Loop: Header=BB1_126 Depth=3
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbnz	w9, #2, LBB1_179
LBB1_137:                               ; %else405
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbnz	w9, #3, LBB1_180
LBB1_138:                               ; %else411
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v5, v3
	tbnz	w9, #4, LBB1_181
LBB1_139:                               ; %else417
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbnz	w9, #5, LBB1_182
LBB1_140:                               ; %else423
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v23, v2
	tbnz	w9, #6, LBB1_183
LBB1_141:                               ; %else429
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbz	w9, #7, LBB1_143
LBB1_142:                               ; %cond.load431
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x9, v2[1]
	ld1.s	{ v7 }[3], [x9]
LBB1_143:                               ; %else435
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	w9, s4
	orr	x10, x7, #0x200
	dup.2d	v2, x10
	orr.16b	v3, v2, v29
	add.2d	v3, v9, v3
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w9, #0, LBB1_184
; %bb.144:                              ; %else442
                                        ;   in Loop: Header=BB1_126 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_185
LBB1_145:                               ; %else448
                                        ;   in Loop: Header=BB1_126 Depth=3
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbnz	w9, #2, LBB1_186
LBB1_146:                               ; %else454
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbnz	w9, #3, LBB1_187
LBB1_147:                               ; %else460
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v5, v3
	tbnz	w9, #4, LBB1_188
LBB1_148:                               ; %else466
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbnz	w9, #5, LBB1_189
LBB1_149:                               ; %else472
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v23, v2
	tbnz	w9, #6, LBB1_190
LBB1_150:                               ; %else478
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbz	w9, #7, LBB1_152
LBB1_151:                               ; %cond.load480
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x9, v2[1]
	ld1.s	{ v21 }[3], [x9]
LBB1_152:                               ; %else484
                                        ;   in Loop: Header=BB1_126 Depth=3
	str	q4, [sp, #2880]                 ; 16-byte Spill
	fmov	w9, s4
	orr	x10, x7, #0x400
	dup.2d	v4, x10
	orr.16b	v2, v4, v29
	add.2d	v28, v9, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w9, #0, LBB1_191
; %bb.153:                              ; %else491
                                        ;   in Loop: Header=BB1_126 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_192
LBB1_154:                               ; %else497
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q28, [sp, #2880]                ; 16-byte Reload
	orr.16b	v22, v4, v30
	add.2d	v22, v10, v22
	tbnz	w9, #2, LBB1_193
LBB1_155:                               ; %else503
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbnz	w9, #3, LBB1_194
LBB1_156:                               ; %else509
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v5, v22
	tbnz	w9, #4, LBB1_195
LBB1_157:                               ; %else515
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbnz	w9, #5, LBB1_196
LBB1_158:                               ; %else521
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q22, [sp, #2912]                ; 16-byte Reload
	orr.16b	v4, v4, v22
	add.2d	v4, v23, v4
	tbnz	w9, #6, LBB1_197
LBB1_159:                               ; %else527
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.16b	v26, v30
	tbz	w9, #7, LBB1_161
LBB1_160:                               ; %cond.load529
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[3], [x9]
LBB1_161:                               ; %else533
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	w9, s28
	orr	x10, x7, #0x600
	dup.2d	v4, x10
	orr.16b	v22, v4, v29
	add.2d	v30, v9, v22
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w9, #0, LBB1_198
; %bb.162:                              ; %else540
                                        ;   in Loop: Header=BB1_126 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_199
LBB1_163:                               ; %else546
                                        ;   in Loop: Header=BB1_126 Depth=3
	orr.16b	v22, v4, v26
	add.2d	v22, v10, v22
	tbnz	w9, #2, LBB1_200
LBB1_164:                               ; %else552
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbnz	w9, #3, LBB1_201
LBB1_165:                               ; %else558
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v5, v22
	tbnz	w9, #4, LBB1_202
LBB1_166:                               ; %else564
                                        ;   in Loop: Header=BB1_126 Depth=3
	tbnz	w9, #5, LBB1_203
LBB1_167:                               ; %else570
                                        ;   in Loop: Header=BB1_126 Depth=3
	ldr	q5, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v4, v4, v5
	add.2d	v4, v23, v4
	tbnz	w9, #6, LBB1_204
LBB1_168:                               ; %else576
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.16b	v27, v15
	mov.16b	v25, v10
	mov.16b	v24, v9
	tbz	w9, #7, LBB1_125
	b	LBB1_205
LBB1_169:                               ; %cond.load
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d1
	ldr	s16, [x10]
	and	w9, w9, #0xff
	ldr	q5, [sp, #2864]                 ; 16-byte Reload
	ldr	q23, [sp, #2896]                ; 16-byte Reload
	tbz	w9, #1, LBB1_128
LBB1_170:                               ; %cond.load360
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v1[1]
	ld1.s	{ v16 }[1], [x10]
	ldr	q1, [sp, #2752]                 ; 16-byte Reload
	orr.16b	v1, v2, v1
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #2, LBB1_129
LBB1_171:                               ; %cond.load364
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d1
	ld1.s	{ v16 }[2], [x10]
	tbz	w9, #3, LBB1_130
LBB1_172:                               ; %cond.load368
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v1[1]
	ld1.s	{ v16 }[3], [x10]
	ldr	q1, [sp, #2736]                 ; 16-byte Reload
	orr.16b	v1, v2, v1
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #4, LBB1_131
LBB1_173:                               ; %cond.load372
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d1
	ld1.s	{ v17 }[0], [x10]
	tbz	w9, #5, LBB1_132
LBB1_174:                               ; %cond.load376
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v1[1]
	ld1.s	{ v17 }[1], [x10]
	ldr	q1, [sp, #2768]                 ; 16-byte Reload
	orr.16b	v1, v2, v1
	ldr	q3, [sp, #2832]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB1_133
LBB1_175:                               ; %cond.load380
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d1
	ld1.s	{ v17 }[2], [x10]
	tbz	w9, #7, LBB1_134
LBB1_176:                               ; %cond.load384
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
	fmov	w9, s4
	orr.16b	v1, v2, v29
	add.2d	v3, v9, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbz	w9, #0, LBB1_135
LBB1_177:                               ; %cond.load389
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d3
	ldr	s1, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_136
LBB1_178:                               ; %cond.load395
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v1 }[1], [x10]
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbz	w9, #2, LBB1_137
LBB1_179:                               ; %cond.load401
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d3
	ld1.s	{ v1 }[2], [x10]
	tbz	w9, #3, LBB1_138
LBB1_180:                               ; %cond.load407
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v1 }[3], [x10]
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v5, v3
	tbz	w9, #4, LBB1_139
LBB1_181:                               ; %cond.load413
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d3
	ld1.s	{ v7 }[0], [x10]
	tbz	w9, #5, LBB1_140
LBB1_182:                               ; %cond.load419
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v7 }[1], [x10]
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v23, v2
	tbz	w9, #6, LBB1_141
LBB1_183:                               ; %cond.load425
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d2
	ld1.s	{ v7 }[2], [x10]
	tbnz	w9, #7, LBB1_142
	b	LBB1_143
LBB1_184:                               ; %cond.load438
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d3
	ldr	s20, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_145
LBB1_185:                               ; %cond.load444
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v20 }[1], [x10]
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbz	w9, #2, LBB1_146
LBB1_186:                               ; %cond.load450
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d3
	ld1.s	{ v20 }[2], [x10]
	tbz	w9, #3, LBB1_147
LBB1_187:                               ; %cond.load456
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v20 }[3], [x10]
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v5, v3
	tbz	w9, #4, LBB1_148
LBB1_188:                               ; %cond.load462
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d3
	ld1.s	{ v21 }[0], [x10]
	tbz	w9, #5, LBB1_149
LBB1_189:                               ; %cond.load468
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v21 }[1], [x10]
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v23, v2
	tbz	w9, #6, LBB1_150
LBB1_190:                               ; %cond.load474
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d2
	ld1.s	{ v21 }[2], [x10]
	tbnz	w9, #7, LBB1_151
	b	LBB1_152
LBB1_191:                               ; %cond.load487
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d28
	ldr	s2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_154
LBB1_192:                               ; %cond.load493
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v28[1]
	ld1.s	{ v2 }[1], [x10]
	ldr	q28, [sp, #2880]                ; 16-byte Reload
	orr.16b	v22, v4, v30
	add.2d	v22, v10, v22
	tbz	w9, #2, LBB1_155
LBB1_193:                               ; %cond.load499
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d22
	ld1.s	{ v2 }[2], [x10]
	tbz	w9, #3, LBB1_156
LBB1_194:                               ; %cond.load505
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v2 }[3], [x10]
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v5, v22
	tbz	w9, #4, LBB1_157
LBB1_195:                               ; %cond.load511
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d22
	ld1.s	{ v3 }[0], [x10]
	tbz	w9, #5, LBB1_158
LBB1_196:                               ; %cond.load517
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v3 }[1], [x10]
	ldr	q22, [sp, #2912]                ; 16-byte Reload
	orr.16b	v4, v4, v22
	add.2d	v4, v23, v4
	tbz	w9, #6, LBB1_159
LBB1_197:                               ; %cond.load523
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d4
	ld1.s	{ v3 }[2], [x10]
	mov.16b	v26, v30
	tbnz	w9, #7, LBB1_160
	b	LBB1_161
LBB1_198:                               ; %cond.load536
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d30
	ldr	s28, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_163
LBB1_199:                               ; %cond.load542
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v30[1]
	ld1.s	{ v28 }[1], [x10]
	orr.16b	v22, v4, v26
	add.2d	v22, v10, v22
	tbz	w9, #2, LBB1_164
LBB1_200:                               ; %cond.load548
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d22
	ld1.s	{ v28 }[2], [x10]
	tbz	w9, #3, LBB1_165
LBB1_201:                               ; %cond.load554
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v28 }[3], [x10]
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v5, v22
	tbz	w9, #4, LBB1_166
LBB1_202:                               ; %cond.load560
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d22
	ld1.s	{ v29 }[0], [x10]
	tbz	w9, #5, LBB1_167
LBB1_203:                               ; %cond.load566
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v29 }[1], [x10]
	ldr	q5, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v4, v4, v5
	add.2d	v4, v23, v4
	tbz	w9, #6, LBB1_168
LBB1_204:                               ; %cond.load572
                                        ;   in Loop: Header=BB1_126 Depth=3
	fmov	x10, d4
	ld1.s	{ v29 }[2], [x10]
	mov.16b	v27, v15
	mov.16b	v25, v10
	mov.16b	v24, v9
	tbz	w9, #7, LBB1_125
LBB1_205:                               ; %cond.load578
                                        ;   in Loop: Header=BB1_126 Depth=3
	mov.d	x9, v4[1]
	ld1.s	{ v29 }[3], [x9]
	b	LBB1_125
LBB1_206:                               ; %direct.false209.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x7, #0                          ; =0x0
	ldr	q1, [sp, #2352]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2352]                 ; 16-byte Spill
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2368]                 ; 16-byte Spill
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2384]                 ; 16-byte Spill
	ldr	q1, [sp, #2400]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2400]                 ; 16-byte Spill
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2416]                 ; 16-byte Spill
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2432]                 ; 16-byte Spill
	ldr	q1, [sp, #2448]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2448]                 ; 16-byte Spill
	ldr	q1, [sp, #2464]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2464]                 ; 16-byte Spill
	b	LBB1_208
LBB1_207:                               ; %else827
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmul.4s	v4, v17, v7
	fmul.4s	v1, v16, v1
	ldr	q10, [sp, #2368]                ; 16-byte Reload
	fadd.4s	v1, v10, v1
	ldr	q5, [sp, #2352]                 ; 16-byte Reload
	fadd.4s	v4, v5, v4
	fmul.4s	v7, v17, v21
	fmul.4s	v20, v16, v20
	ldr	q23, [sp, #2400]                ; 16-byte Reload
	fadd.4s	v20, v23, v20
	ldr	q9, [sp, #2384]                 ; 16-byte Reload
	fadd.4s	v7, v9, v7
	fmul.4s	v3, v17, v3
	fmul.4s	v2, v16, v2
	ldr	q30, [sp, #2432]                ; 16-byte Reload
	fadd.4s	v2, v30, v2
	ldr	q15, [sp, #2416]                ; 16-byte Reload
	fadd.4s	v3, v15, v3
	fmul.4s	v16, v16, v28
	fmul.4s	v17, v17, v29
	ldr	q22, [sp, #2448]                ; 16-byte Reload
	fadd.4s	v17, v22, v17
	ldr	q21, [sp, #2464]                ; 16-byte Reload
	fadd.4s	v16, v21, v16
	bit.16b	v5, v4, v0
	str	q5, [sp, #2352]                 ; 16-byte Spill
	bit.16b	v10, v1, v27
	str	q10, [sp, #2368]                ; 16-byte Spill
	bit.16b	v9, v7, v0
	str	q9, [sp, #2384]                 ; 16-byte Spill
	bit.16b	v23, v20, v27
	str	q23, [sp, #2400]                ; 16-byte Spill
	bit.16b	v15, v3, v0
	str	q15, [sp, #2416]                ; 16-byte Spill
	mov.16b	v15, v27
	bit.16b	v30, v2, v27
	str	q30, [sp, #2432]                ; 16-byte Spill
	bit.16b	v21, v16, v27
	str	q21, [sp, #2464]                ; 16-byte Spill
	add	x7, x7, #4
	bit.16b	v22, v17, v0
	str	q22, [sp, #2448]                ; 16-byte Spill
	cmp	x7, #512
	mov.16b	v9, v24
	ldr	q24, [sp, #1856]                ; 16-byte Reload
	mov.16b	v10, v25
	ldr	q25, [sp, #1840]                ; 16-byte Reload
	ldr	q29, [sp, #2848]                ; 16-byte Reload
	mov.16b	v30, v26
	b.eq	LBB1_288
LBB1_208:                               ; %direct.true235.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q4, [sp, #2880]                 ; 16-byte Reload
	fmov	w9, s4
	dup.2d	v1, x7
	ldr	q2, [sp, #2720]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2784]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w9, #0, LBB1_252
; %bb.209:                              ; %else589
                                        ;   in Loop: Header=BB1_208 Depth=3
	and	w9, w9, #0xff
	ldr	q5, [sp, #2864]                 ; 16-byte Reload
	ldr	q23, [sp, #2896]                ; 16-byte Reload
	tbnz	w9, #1, LBB1_253
LBB1_210:                               ; %else595
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q2, [sp, #2752]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #2, LBB1_254
LBB1_211:                               ; %else601
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbnz	w9, #3, LBB1_255
LBB1_212:                               ; %else607
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q2, [sp, #2736]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #4, LBB1_256
LBB1_213:                               ; %else613
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbnz	w9, #5, LBB1_257
LBB1_214:                               ; %else619
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q2, [sp, #2768]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #2832]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB1_258
LBB1_215:                               ; %else625
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbz	w9, #7, LBB1_217
LBB1_216:                               ; %cond.load627
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
LBB1_217:                               ; %else631
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	w9, s4
	orr	x10, x7, #0x800
	dup.2d	v2, x10
	orr.16b	v1, v2, v29
	add.2d	v3, v9, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w9, #0, LBB1_259
; %bb.218:                              ; %else638
                                        ;   in Loop: Header=BB1_208 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_260
LBB1_219:                               ; %else644
                                        ;   in Loop: Header=BB1_208 Depth=3
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbnz	w9, #2, LBB1_261
LBB1_220:                               ; %else650
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbnz	w9, #3, LBB1_262
LBB1_221:                               ; %else656
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v5, v3
	tbnz	w9, #4, LBB1_263
LBB1_222:                               ; %else662
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbnz	w9, #5, LBB1_264
LBB1_223:                               ; %else668
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v23, v2
	tbnz	w9, #6, LBB1_265
LBB1_224:                               ; %else674
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbz	w9, #7, LBB1_226
LBB1_225:                               ; %cond.load676
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x9, v2[1]
	ld1.s	{ v7 }[3], [x9]
LBB1_226:                               ; %else680
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	w9, s4
	orr	x10, x7, x25
	dup.2d	v2, x10
	orr.16b	v3, v2, v29
	add.2d	v3, v9, v3
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w9, #0, LBB1_266
; %bb.227:                              ; %else687
                                        ;   in Loop: Header=BB1_208 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_267
LBB1_228:                               ; %else693
                                        ;   in Loop: Header=BB1_208 Depth=3
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbnz	w9, #2, LBB1_268
LBB1_229:                               ; %else699
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbnz	w9, #3, LBB1_269
LBB1_230:                               ; %else705
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v5, v3
	tbnz	w9, #4, LBB1_270
LBB1_231:                               ; %else711
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbnz	w9, #5, LBB1_271
LBB1_232:                               ; %else717
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v23, v2
	tbnz	w9, #6, LBB1_272
LBB1_233:                               ; %else723
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbz	w9, #7, LBB1_235
LBB1_234:                               ; %cond.load725
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x9, v2[1]
	ld1.s	{ v21 }[3], [x9]
LBB1_235:                               ; %else729
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	w9, s4
	orr	x10, x7, #0xc00
	dup.2d	v4, x10
	orr.16b	v2, v4, v29
	add.2d	v28, v9, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w9, #0, LBB1_273
; %bb.236:                              ; %else736
                                        ;   in Loop: Header=BB1_208 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_274
LBB1_237:                               ; %else742
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q25, [sp, #2880]                ; 16-byte Reload
	orr.16b	v22, v4, v30
	add.2d	v22, v10, v22
	tbnz	w9, #2, LBB1_275
LBB1_238:                               ; %else748
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbnz	w9, #3, LBB1_276
LBB1_239:                               ; %else754
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v5, v22
	tbnz	w9, #4, LBB1_277
LBB1_240:                               ; %else760
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbnz	w9, #5, LBB1_278
LBB1_241:                               ; %else766
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q22, [sp, #2912]                ; 16-byte Reload
	orr.16b	v4, v4, v22
	add.2d	v4, v23, v4
	tbnz	w9, #6, LBB1_279
LBB1_242:                               ; %else772
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.16b	v24, v30
	tbz	w9, #7, LBB1_244
LBB1_243:                               ; %cond.load774
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[3], [x9]
LBB1_244:                               ; %else778
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	w9, s25
	orr	x10, x7, #0xe00
	dup.2d	v4, x10
	orr.16b	v22, v4, v29
	add.2d	v30, v9, v22
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w9, #0, LBB1_280
; %bb.245:                              ; %else785
                                        ;   in Loop: Header=BB1_208 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_281
LBB1_246:                               ; %else791
                                        ;   in Loop: Header=BB1_208 Depth=3
	orr.16b	v22, v4, v24
	add.2d	v22, v10, v22
	tbnz	w9, #2, LBB1_282
LBB1_247:                               ; %else797
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbnz	w9, #3, LBB1_283
LBB1_248:                               ; %else803
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v5, v22
	tbnz	w9, #4, LBB1_284
LBB1_249:                               ; %else809
                                        ;   in Loop: Header=BB1_208 Depth=3
	tbnz	w9, #5, LBB1_285
LBB1_250:                               ; %else815
                                        ;   in Loop: Header=BB1_208 Depth=3
	ldr	q5, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v4, v4, v5
	add.2d	v4, v23, v4
	tbnz	w9, #6, LBB1_286
LBB1_251:                               ; %else821
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.16b	v27, v15
	mov.16b	v26, v24
	mov.16b	v25, v10
	mov.16b	v24, v9
	tbz	w9, #7, LBB1_207
	b	LBB1_287
LBB1_252:                               ; %cond.load585
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d2
	ldr	s16, [x10]
	and	w9, w9, #0xff
	ldr	q5, [sp, #2864]                 ; 16-byte Reload
	ldr	q23, [sp, #2896]                ; 16-byte Reload
	tbz	w9, #1, LBB1_210
LBB1_253:                               ; %cond.load591
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v2[1]
	ld1.s	{ v16 }[1], [x10]
	ldr	q2, [sp, #2752]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #2, LBB1_211
LBB1_254:                               ; %cond.load597
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d2
	ld1.s	{ v16 }[2], [x10]
	tbz	w9, #3, LBB1_212
LBB1_255:                               ; %cond.load603
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v2[1]
	ld1.s	{ v16 }[3], [x10]
	ldr	q2, [sp, #2736]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #4, LBB1_213
LBB1_256:                               ; %cond.load609
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d2
	ld1.s	{ v17 }[0], [x10]
	tbz	w9, #5, LBB1_214
LBB1_257:                               ; %cond.load615
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v2[1]
	ld1.s	{ v17 }[1], [x10]
	ldr	q2, [sp, #2768]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #2832]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB1_215
LBB1_258:                               ; %cond.load621
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d1
	ld1.s	{ v17 }[2], [x10]
	tbnz	w9, #7, LBB1_216
	b	LBB1_217
LBB1_259:                               ; %cond.load634
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d3
	ldr	s1, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_219
LBB1_260:                               ; %cond.load640
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v1 }[1], [x10]
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbz	w9, #2, LBB1_220
LBB1_261:                               ; %cond.load646
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d3
	ld1.s	{ v1 }[2], [x10]
	tbz	w9, #3, LBB1_221
LBB1_262:                               ; %cond.load652
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v1 }[3], [x10]
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v5, v3
	tbz	w9, #4, LBB1_222
LBB1_263:                               ; %cond.load658
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d3
	ld1.s	{ v7 }[0], [x10]
	tbz	w9, #5, LBB1_223
LBB1_264:                               ; %cond.load664
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v7 }[1], [x10]
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v23, v2
	tbz	w9, #6, LBB1_224
LBB1_265:                               ; %cond.load670
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d2
	ld1.s	{ v7 }[2], [x10]
	tbnz	w9, #7, LBB1_225
	b	LBB1_226
LBB1_266:                               ; %cond.load683
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d3
	ldr	s20, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_228
LBB1_267:                               ; %cond.load689
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v20 }[1], [x10]
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbz	w9, #2, LBB1_229
LBB1_268:                               ; %cond.load695
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d3
	ld1.s	{ v20 }[2], [x10]
	tbz	w9, #3, LBB1_230
LBB1_269:                               ; %cond.load701
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v20 }[3], [x10]
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v5, v3
	tbz	w9, #4, LBB1_231
LBB1_270:                               ; %cond.load707
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d3
	ld1.s	{ v21 }[0], [x10]
	tbz	w9, #5, LBB1_232
LBB1_271:                               ; %cond.load713
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v21 }[1], [x10]
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v23, v2
	tbz	w9, #6, LBB1_233
LBB1_272:                               ; %cond.load719
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d2
	ld1.s	{ v21 }[2], [x10]
	tbnz	w9, #7, LBB1_234
	b	LBB1_235
LBB1_273:                               ; %cond.load732
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d28
	ldr	s2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_237
LBB1_274:                               ; %cond.load738
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v28[1]
	ld1.s	{ v2 }[1], [x10]
	ldr	q25, [sp, #2880]                ; 16-byte Reload
	orr.16b	v22, v4, v30
	add.2d	v22, v10, v22
	tbz	w9, #2, LBB1_238
LBB1_275:                               ; %cond.load744
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d22
	ld1.s	{ v2 }[2], [x10]
	tbz	w9, #3, LBB1_239
LBB1_276:                               ; %cond.load750
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v2 }[3], [x10]
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v5, v22
	tbz	w9, #4, LBB1_240
LBB1_277:                               ; %cond.load756
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d22
	ld1.s	{ v3 }[0], [x10]
	tbz	w9, #5, LBB1_241
LBB1_278:                               ; %cond.load762
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v3 }[1], [x10]
	ldr	q22, [sp, #2912]                ; 16-byte Reload
	orr.16b	v4, v4, v22
	add.2d	v4, v23, v4
	tbz	w9, #6, LBB1_242
LBB1_279:                               ; %cond.load768
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d4
	ld1.s	{ v3 }[2], [x10]
	mov.16b	v24, v30
	tbnz	w9, #7, LBB1_243
	b	LBB1_244
LBB1_280:                               ; %cond.load781
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d30
	ldr	s28, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_246
LBB1_281:                               ; %cond.load787
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v30[1]
	ld1.s	{ v28 }[1], [x10]
	orr.16b	v22, v4, v24
	add.2d	v22, v10, v22
	tbz	w9, #2, LBB1_247
LBB1_282:                               ; %cond.load793
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d22
	ld1.s	{ v28 }[2], [x10]
	tbz	w9, #3, LBB1_248
LBB1_283:                               ; %cond.load799
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v28 }[3], [x10]
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v5, v22
	tbz	w9, #4, LBB1_249
LBB1_284:                               ; %cond.load805
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d22
	ld1.s	{ v29 }[0], [x10]
	tbz	w9, #5, LBB1_250
LBB1_285:                               ; %cond.load811
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v29 }[1], [x10]
	ldr	q5, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v4, v4, v5
	add.2d	v4, v23, v4
	tbz	w9, #6, LBB1_251
LBB1_286:                               ; %cond.load817
                                        ;   in Loop: Header=BB1_208 Depth=3
	fmov	x10, d4
	ld1.s	{ v29 }[2], [x10]
	mov.16b	v27, v15
	mov.16b	v26, v24
	mov.16b	v25, v10
	mov.16b	v24, v9
	tbz	w9, #7, LBB1_207
LBB1_287:                               ; %cond.load823
                                        ;   in Loop: Header=BB1_208 Depth=3
	mov.d	x9, v4[1]
	ld1.s	{ v29 }[3], [x9]
	b	LBB1_207
LBB1_288:                               ; %direct.false236.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x7, #0                          ; =0x0
	ldr	q1, [sp, #2480]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2480]                 ; 16-byte Spill
	ldr	q1, [sp, #2496]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2496]                 ; 16-byte Spill
	ldr	q1, [sp, #2512]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2512]                 ; 16-byte Spill
	ldr	q27, [sp, #1984]                ; 16-byte Reload
	bic.16b	v27, v27, v15
	ldr	q1, [sp, #2528]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2528]                 ; 16-byte Spill
	ldr	q1, [sp, #2544]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2544]                 ; 16-byte Spill
	ldr	q1, [sp, #2560]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2560]                 ; 16-byte Spill
	ldr	q1, [sp, #2576]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2576]                 ; 16-byte Spill
	ldr	q23, [sp, #2864]                ; 16-byte Reload
	ldr	q28, [sp, #2880]                ; 16-byte Reload
	b	LBB1_290
LBB1_289:                               ; %else1072
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmul.4s	v4, v17, v7
	fmul.4s	v1, v16, v1
	ldr	q22, [sp, #2496]                ; 16-byte Reload
	fadd.4s	v1, v22, v1
	ldr	q30, [sp, #2480]                ; 16-byte Reload
	fadd.4s	v4, v30, v4
	fmul.4s	v7, v17, v21
	fmul.4s	v20, v16, v20
	fadd.4s	v20, v27, v20
	ldr	q21, [sp, #2512]                ; 16-byte Reload
	fadd.4s	v7, v21, v7
	fmul.4s	v3, v17, v3
	fmul.4s	v2, v16, v2
	ldr	q5, [sp, #2544]                 ; 16-byte Reload
	fadd.4s	v2, v5, v2
	ldr	q23, [sp, #2528]                ; 16-byte Reload
	fadd.4s	v3, v23, v3
	fmul.4s	v16, v16, v28
	fmul.4s	v17, v17, v29
	ldr	q29, [sp, #2560]                ; 16-byte Reload
	fadd.4s	v17, v29, v17
	ldr	q28, [sp, #2576]                ; 16-byte Reload
	fadd.4s	v16, v28, v16
	bit.16b	v30, v4, v0
	str	q30, [sp, #2480]                ; 16-byte Spill
	bit.16b	v22, v1, v15
	str	q22, [sp, #2496]                ; 16-byte Spill
	bit.16b	v21, v7, v0
	str	q21, [sp, #2512]                ; 16-byte Spill
	bit.16b	v27, v20, v15
	bit.16b	v23, v3, v0
	str	q23, [sp, #2528]                ; 16-byte Spill
	bit.16b	v5, v2, v15
	str	q5, [sp, #2544]                 ; 16-byte Spill
	bit.16b	v28, v16, v15
	str	q28, [sp, #2576]                ; 16-byte Spill
	add	x7, x7, #4
	bit.16b	v29, v17, v0
	str	q29, [sp, #2560]                ; 16-byte Spill
	cmp	x7, #512
	ldr	q29, [sp, #2848]                ; 16-byte Reload
	mov.16b	v30, v26
	ldr	q26, [sp, #1824]                ; 16-byte Reload
	ldr	q28, [sp, #2880]                ; 16-byte Reload
	ldr	q23, [sp, #2864]                ; 16-byte Reload
	b.eq	LBB1_370
LBB1_290:                               ; %direct.true263.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w9, s28
	dup.2d	v1, x7
	ldr	q2, [sp, #2720]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2784]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w9, #0, LBB1_334
; %bb.291:                              ; %else834
                                        ;   in Loop: Header=BB1_290 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_335
LBB1_292:                               ; %else840
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q2, [sp, #2752]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #2, LBB1_336
LBB1_293:                               ; %else846
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbnz	w9, #3, LBB1_337
LBB1_294:                               ; %else852
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q2, [sp, #2736]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #4, LBB1_338
LBB1_295:                               ; %else858
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbnz	w9, #5, LBB1_339
LBB1_296:                               ; %else864
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q2, [sp, #2768]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #2832]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB1_340
LBB1_297:                               ; %else870
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbz	w9, #7, LBB1_299
LBB1_298:                               ; %cond.load872
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
LBB1_299:                               ; %else876
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	w9, s28
	orr	x10, x7, #0x1000
	dup.2d	v2, x10
	orr.16b	v1, v2, v29
	add.2d	v3, v9, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w9, #0, LBB1_341
; %bb.300:                              ; %else883
                                        ;   in Loop: Header=BB1_290 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_342
LBB1_301:                               ; %else889
                                        ;   in Loop: Header=BB1_290 Depth=3
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbnz	w9, #2, LBB1_343
LBB1_302:                               ; %else895
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbnz	w9, #3, LBB1_344
LBB1_303:                               ; %else901
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v23, v3
	tbnz	w9, #4, LBB1_345
LBB1_304:                               ; %else907
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbnz	w9, #5, LBB1_346
LBB1_305:                               ; %else913
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #6, LBB1_347
LBB1_306:                               ; %else919
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbz	w9, #7, LBB1_308
LBB1_307:                               ; %cond.load921
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x9, v2[1]
	ld1.s	{ v7 }[3], [x9]
LBB1_308:                               ; %else925
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	w9, s28
	orr	x10, x7, x28
	dup.2d	v2, x10
	orr.16b	v3, v2, v29
	add.2d	v3, v9, v3
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w9, #0, LBB1_348
; %bb.309:                              ; %else932
                                        ;   in Loop: Header=BB1_290 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_349
LBB1_310:                               ; %else938
                                        ;   in Loop: Header=BB1_290 Depth=3
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbnz	w9, #2, LBB1_350
LBB1_311:                               ; %else944
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbnz	w9, #3, LBB1_351
LBB1_312:                               ; %else950
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v23, v3
	tbnz	w9, #4, LBB1_352
LBB1_313:                               ; %else956
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbnz	w9, #5, LBB1_353
LBB1_314:                               ; %else962
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #6, LBB1_354
LBB1_315:                               ; %else968
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbz	w9, #7, LBB1_317
LBB1_316:                               ; %cond.load970
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x9, v2[1]
	ld1.s	{ v21 }[3], [x9]
LBB1_317:                               ; %else974
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	w9, s28
	orr	x10, x7, x23
	dup.2d	v4, x10
	orr.16b	v2, v4, v29
	add.2d	v28, v9, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w9, #0, LBB1_355
; %bb.318:                              ; %else981
                                        ;   in Loop: Header=BB1_290 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_356
LBB1_319:                               ; %else987
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q5, [sp, #2880]                 ; 16-byte Reload
	orr.16b	v22, v4, v30
	add.2d	v22, v10, v22
	tbnz	w9, #2, LBB1_357
LBB1_320:                               ; %else993
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbnz	w9, #3, LBB1_358
LBB1_321:                               ; %else999
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v23, v22
	tbnz	w9, #4, LBB1_359
LBB1_322:                               ; %else1005
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbnz	w9, #5, LBB1_360
LBB1_323:                               ; %else1011
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q22, [sp, #2912]                ; 16-byte Reload
	orr.16b	v4, v4, v22
	ldr	q22, [sp, #2896]                ; 16-byte Reload
	add.2d	v4, v22, v4
	tbnz	w9, #6, LBB1_361
LBB1_324:                               ; %else1017
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.16b	v26, v30
	tbz	w9, #7, LBB1_326
LBB1_325:                               ; %cond.load1019
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[3], [x9]
LBB1_326:                               ; %else1023
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	w9, s5
	orr	x10, x7, x24
	dup.2d	v4, x10
	orr.16b	v22, v4, v29
	add.2d	v30, v9, v22
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w9, #0, LBB1_362
; %bb.327:                              ; %else1030
                                        ;   in Loop: Header=BB1_290 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_363
LBB1_328:                               ; %else1036
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.16b	v30, v26
	orr.16b	v22, v4, v26
	add.2d	v22, v10, v22
	tbnz	w9, #2, LBB1_364
LBB1_329:                               ; %else1042
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbnz	w9, #3, LBB1_365
LBB1_330:                               ; %else1048
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v23, v22
	tbnz	w9, #4, LBB1_366
LBB1_331:                               ; %else1054
                                        ;   in Loop: Header=BB1_290 Depth=3
	tbnz	w9, #5, LBB1_367
LBB1_332:                               ; %else1060
                                        ;   in Loop: Header=BB1_290 Depth=3
	ldr	q22, [sp, #2912]                ; 16-byte Reload
	orr.16b	v4, v4, v22
	ldr	q5, [sp, #2896]                 ; 16-byte Reload
	add.2d	v4, v5, v4
	tbnz	w9, #6, LBB1_368
LBB1_333:                               ; %else1066
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.16b	v26, v30
	tbz	w9, #7, LBB1_289
	b	LBB1_369
LBB1_334:                               ; %cond.load830
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d2
	ldr	s16, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_292
LBB1_335:                               ; %cond.load836
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v2[1]
	ld1.s	{ v16 }[1], [x10]
	ldr	q2, [sp, #2752]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #2, LBB1_293
LBB1_336:                               ; %cond.load842
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d2
	ld1.s	{ v16 }[2], [x10]
	tbz	w9, #3, LBB1_294
LBB1_337:                               ; %cond.load848
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v2[1]
	ld1.s	{ v16 }[3], [x10]
	ldr	q2, [sp, #2736]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #4, LBB1_295
LBB1_338:                               ; %cond.load854
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d2
	ld1.s	{ v17 }[0], [x10]
	tbz	w9, #5, LBB1_296
LBB1_339:                               ; %cond.load860
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v2[1]
	ld1.s	{ v17 }[1], [x10]
	ldr	q2, [sp, #2768]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #2832]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB1_297
LBB1_340:                               ; %cond.load866
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d1
	ld1.s	{ v17 }[2], [x10]
	tbnz	w9, #7, LBB1_298
	b	LBB1_299
LBB1_341:                               ; %cond.load879
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d3
	ldr	s1, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_301
LBB1_342:                               ; %cond.load885
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v1 }[1], [x10]
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbz	w9, #2, LBB1_302
LBB1_343:                               ; %cond.load891
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d3
	ld1.s	{ v1 }[2], [x10]
	tbz	w9, #3, LBB1_303
LBB1_344:                               ; %cond.load897
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v1 }[3], [x10]
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v23, v3
	tbz	w9, #4, LBB1_304
LBB1_345:                               ; %cond.load903
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d3
	ld1.s	{ v7 }[0], [x10]
	tbz	w9, #5, LBB1_305
LBB1_346:                               ; %cond.load909
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v7 }[1], [x10]
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #6, LBB1_306
LBB1_347:                               ; %cond.load915
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d2
	ld1.s	{ v7 }[2], [x10]
	tbnz	w9, #7, LBB1_307
	b	LBB1_308
LBB1_348:                               ; %cond.load928
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d3
	ldr	s20, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_310
LBB1_349:                               ; %cond.load934
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v20 }[1], [x10]
	orr.16b	v3, v2, v30
	add.2d	v3, v10, v3
	tbz	w9, #2, LBB1_311
LBB1_350:                               ; %cond.load940
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d3
	ld1.s	{ v20 }[2], [x10]
	tbz	w9, #3, LBB1_312
LBB1_351:                               ; %cond.load946
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v20 }[3], [x10]
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v23, v3
	tbz	w9, #4, LBB1_313
LBB1_352:                               ; %cond.load952
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d3
	ld1.s	{ v21 }[0], [x10]
	tbz	w9, #5, LBB1_314
LBB1_353:                               ; %cond.load958
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v21 }[1], [x10]
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #6, LBB1_315
LBB1_354:                               ; %cond.load964
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d2
	ld1.s	{ v21 }[2], [x10]
	tbnz	w9, #7, LBB1_316
	b	LBB1_317
LBB1_355:                               ; %cond.load977
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d28
	ldr	s2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_319
LBB1_356:                               ; %cond.load983
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v28[1]
	ld1.s	{ v2 }[1], [x10]
	ldr	q5, [sp, #2880]                 ; 16-byte Reload
	orr.16b	v22, v4, v30
	add.2d	v22, v10, v22
	tbz	w9, #2, LBB1_320
LBB1_357:                               ; %cond.load989
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d22
	ld1.s	{ v2 }[2], [x10]
	tbz	w9, #3, LBB1_321
LBB1_358:                               ; %cond.load995
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v2 }[3], [x10]
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v23, v22
	tbz	w9, #4, LBB1_322
LBB1_359:                               ; %cond.load1001
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d22
	ld1.s	{ v3 }[0], [x10]
	tbz	w9, #5, LBB1_323
LBB1_360:                               ; %cond.load1007
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v3 }[1], [x10]
	ldr	q22, [sp, #2912]                ; 16-byte Reload
	orr.16b	v4, v4, v22
	ldr	q22, [sp, #2896]                ; 16-byte Reload
	add.2d	v4, v22, v4
	tbz	w9, #6, LBB1_324
LBB1_361:                               ; %cond.load1013
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d4
	ld1.s	{ v3 }[2], [x10]
	mov.16b	v26, v30
	tbnz	w9, #7, LBB1_325
	b	LBB1_326
LBB1_362:                               ; %cond.load1026
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d30
	ldr	s28, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_328
LBB1_363:                               ; %cond.load1032
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v30[1]
	ld1.s	{ v28 }[1], [x10]
	mov.16b	v30, v26
	orr.16b	v22, v4, v26
	add.2d	v22, v10, v22
	tbz	w9, #2, LBB1_329
LBB1_364:                               ; %cond.load1038
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d22
	ld1.s	{ v28 }[2], [x10]
	tbz	w9, #3, LBB1_330
LBB1_365:                               ; %cond.load1044
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v28 }[3], [x10]
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v23, v22
	tbz	w9, #4, LBB1_331
LBB1_366:                               ; %cond.load1050
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d22
	ld1.s	{ v29 }[0], [x10]
	tbz	w9, #5, LBB1_332
LBB1_367:                               ; %cond.load1056
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v29 }[1], [x10]
	ldr	q22, [sp, #2912]                ; 16-byte Reload
	orr.16b	v4, v4, v22
	ldr	q5, [sp, #2896]                 ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w9, #6, LBB1_333
LBB1_368:                               ; %cond.load1062
                                        ;   in Loop: Header=BB1_290 Depth=3
	fmov	x10, d4
	ld1.s	{ v29 }[2], [x10]
	mov.16b	v26, v30
	tbz	w9, #7, LBB1_289
LBB1_369:                               ; %cond.load1068
                                        ;   in Loop: Header=BB1_290 Depth=3
	mov.d	x9, v4[1]
	ld1.s	{ v29 }[3], [x9]
	b	LBB1_289
LBB1_370:                               ; %direct.false264.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	str	q30, [sp, #2208]                ; 16-byte Spill
	str	q10, [sp, #1920]                ; 16-byte Spill
	str	q9, [sp, #1936]                 ; 16-byte Spill
	mov	x7, #0                          ; =0x0
	ldr	q1, [sp, #2592]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2592]                 ; 16-byte Spill
	ldr	q1, [sp, #2608]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2608]                 ; 16-byte Spill
	ldr	q1, [sp, #2624]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2624]                 ; 16-byte Spill
	ldr	q1, [sp, #2640]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2640]                 ; 16-byte Spill
	ldr	q1, [sp, #2656]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2656]                 ; 16-byte Spill
	ldr	q1, [sp, #2672]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2672]                 ; 16-byte Spill
	ldr	q1, [sp, #2688]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2688]                 ; 16-byte Spill
	ldr	q1, [sp, #2704]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2704]                 ; 16-byte Spill
	str	q27, [sp, #1984]                ; 16-byte Spill
	b	LBB1_372
LBB1_371:                               ; %else1317
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmul.4s	v4, v17, v7
	fmul.4s	v1, v16, v1
	ldr	q5, [sp, #2608]                 ; 16-byte Reload
	fadd.4s	v1, v5, v1
	ldr	q23, [sp, #2592]                ; 16-byte Reload
	fadd.4s	v4, v23, v4
	fmul.4s	v7, v17, v21
	fmul.4s	v20, v16, v20
	ldr	q10, [sp, #2640]                ; 16-byte Reload
	fadd.4s	v20, v10, v20
	ldr	q9, [sp, #2624]                 ; 16-byte Reload
	fadd.4s	v7, v9, v7
	fmul.4s	v3, v17, v3
	fmul.4s	v2, v16, v2
	ldr	q30, [sp, #2672]                ; 16-byte Reload
	fadd.4s	v2, v30, v2
	ldr	q15, [sp, #2656]                ; 16-byte Reload
	fadd.4s	v3, v15, v3
	fmul.4s	v16, v16, v28
	fmul.4s	v17, v17, v29
	ldr	q22, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v17, v22, v17
	ldr	q21, [sp, #2704]                ; 16-byte Reload
	fadd.4s	v16, v21, v16
	bit.16b	v23, v4, v0
	str	q23, [sp, #2592]                ; 16-byte Spill
	bit.16b	v5, v1, v27
	str	q5, [sp, #2608]                 ; 16-byte Spill
	bit.16b	v9, v7, v0
	str	q9, [sp, #2624]                 ; 16-byte Spill
	bit.16b	v10, v20, v27
	str	q10, [sp, #2640]                ; 16-byte Spill
	bit.16b	v15, v3, v0
	str	q15, [sp, #2656]                ; 16-byte Spill
	mov.16b	v15, v27
	bit.16b	v30, v2, v27
	str	q30, [sp, #2672]                ; 16-byte Spill
	bit.16b	v21, v16, v27
	str	q21, [sp, #2704]                ; 16-byte Spill
	add	x7, x7, #4
	bit.16b	v22, v17, v0
	str	q22, [sp, #2688]                ; 16-byte Spill
	cmp	x7, #512
	ldr	q23, [sp, #1984]                ; 16-byte Reload
	ldr	q27, [sp, #1808]                ; 16-byte Reload
	ldr	q28, [sp, #2880]                ; 16-byte Reload
	b.eq	LBB1_452
LBB1_372:                               ; %direct.true291.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w9, s28
	dup.2d	v1, x7
	ldr	q2, [sp, #2720]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2784]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	ldr	q5, [sp, #1936]                 ; 16-byte Reload
	ldr	q23, [sp, #1920]                ; 16-byte Reload
	ldr	q29, [sp, #2848]                ; 16-byte Reload
	ldr	q22, [sp, #2208]                ; 16-byte Reload
	tbnz	w9, #0, LBB1_416
; %bb.373:                              ; %else1079
                                        ;   in Loop: Header=BB1_372 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_417
LBB1_374:                               ; %else1085
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q2, [sp, #2752]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #2, LBB1_418
LBB1_375:                               ; %else1091
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbnz	w9, #3, LBB1_419
LBB1_376:                               ; %else1097
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q2, [sp, #2736]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #4, LBB1_420
LBB1_377:                               ; %else1103
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbnz	w9, #5, LBB1_421
LBB1_378:                               ; %else1109
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q2, [sp, #2768]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #2832]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB1_422
LBB1_379:                               ; %else1115
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbz	w9, #7, LBB1_381
LBB1_380:                               ; %cond.load1117
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x9, v1[1]
	ld1.s	{ v17 }[3], [x9]
LBB1_381:                               ; %else1121
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	w9, s28
	orr	x10, x7, #0x1800
	dup.2d	v2, x10
	orr.16b	v1, v2, v29
	add.2d	v3, v5, v1
	movi.2d	v1, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w9, #0, LBB1_423
; %bb.382:                              ; %else1128
                                        ;   in Loop: Header=BB1_372 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_424
LBB1_383:                               ; %else1134
                                        ;   in Loop: Header=BB1_372 Depth=3
	orr.16b	v3, v2, v22
	add.2d	v3, v23, v3
	tbnz	w9, #2, LBB1_425
LBB1_384:                               ; %else1140
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbnz	w9, #3, LBB1_426
LBB1_385:                               ; %else1146
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	ldr	q4, [sp, #2864]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbnz	w9, #4, LBB1_427
LBB1_386:                               ; %else1152
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbnz	w9, #5, LBB1_428
LBB1_387:                               ; %else1158
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #6, LBB1_429
LBB1_388:                               ; %else1164
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbz	w9, #7, LBB1_390
LBB1_389:                               ; %cond.load1166
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x9, v2[1]
	ld1.s	{ v7 }[3], [x9]
LBB1_390:                               ; %else1170
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	w9, s28
	orr	x10, x7, x21
	dup.2d	v2, x10
	orr.16b	v3, v2, v29
	add.2d	v3, v5, v3
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w9, #0, LBB1_430
; %bb.391:                              ; %else1177
                                        ;   in Loop: Header=BB1_372 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_431
LBB1_392:                               ; %else1183
                                        ;   in Loop: Header=BB1_372 Depth=3
	orr.16b	v3, v2, v22
	add.2d	v3, v23, v3
	tbnz	w9, #2, LBB1_432
LBB1_393:                               ; %else1189
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbnz	w9, #3, LBB1_433
LBB1_394:                               ; %else1195
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	ldr	q4, [sp, #2864]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbnz	w9, #4, LBB1_434
LBB1_395:                               ; %else1201
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbnz	w9, #5, LBB1_435
LBB1_396:                               ; %else1207
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #6, LBB1_436
LBB1_397:                               ; %else1213
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbz	w9, #7, LBB1_399
LBB1_398:                               ; %cond.load1215
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x9, v2[1]
	ld1.s	{ v21 }[3], [x9]
LBB1_399:                               ; %else1219
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	w9, s28
	orr	x10, x7, #0x1c00
	dup.2d	v4, x10
	orr.16b	v2, v4, v29
	add.2d	v28, v5, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w9, #0, LBB1_437
; %bb.400:                              ; %else1226
                                        ;   in Loop: Header=BB1_372 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_438
LBB1_401:                               ; %else1232
                                        ;   in Loop: Header=BB1_372 Depth=3
	orr.16b	v22, v4, v22
	add.2d	v22, v23, v22
	tbnz	w9, #2, LBB1_439
LBB1_402:                               ; %else1238
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbnz	w9, #3, LBB1_440
LBB1_403:                               ; %else1244
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	ldr	q28, [sp, #2864]                ; 16-byte Reload
	add.2d	v22, v28, v22
	tbnz	w9, #4, LBB1_441
LBB1_404:                               ; %else1250
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q27, [sp, #2880]                ; 16-byte Reload
	tbnz	w9, #5, LBB1_442
LBB1_405:                               ; %else1256
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q22, [sp, #2912]                ; 16-byte Reload
	orr.16b	v4, v4, v22
	ldr	q22, [sp, #2896]                ; 16-byte Reload
	add.2d	v4, v22, v4
	tbnz	w9, #6, LBB1_443
LBB1_406:                               ; %else1262
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbz	w9, #7, LBB1_408
LBB1_407:                               ; %cond.load1264
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[3], [x9]
LBB1_408:                               ; %else1268
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	w9, s27
	orr	x10, x7, #0x1e00
	dup.2d	v4, x10
	orr.16b	v22, v4, v29
	add.2d	v30, v5, v22
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w9, #0, LBB1_444
; %bb.409:                              ; %else1275
                                        ;   in Loop: Header=BB1_372 Depth=3
	and	w9, w9, #0xff
	ldr	q5, [sp, #2864]                 ; 16-byte Reload
	tbnz	w9, #1, LBB1_445
LBB1_410:                               ; %else1281
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q22, [sp, #2208]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v23, v22
	tbnz	w9, #2, LBB1_446
LBB1_411:                               ; %else1287
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q23, [sp, #2896]                ; 16-byte Reload
	tbnz	w9, #3, LBB1_447
LBB1_412:                               ; %else1293
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v5, v22
	tbnz	w9, #4, LBB1_448
LBB1_413:                               ; %else1299
                                        ;   in Loop: Header=BB1_372 Depth=3
	tbnz	w9, #5, LBB1_449
LBB1_414:                               ; %else1305
                                        ;   in Loop: Header=BB1_372 Depth=3
	ldr	q5, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v4, v4, v5
	add.2d	v4, v23, v4
	tbnz	w9, #6, LBB1_450
LBB1_415:                               ; %else1311
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.16b	v27, v15
	tbz	w9, #7, LBB1_371
	b	LBB1_451
LBB1_416:                               ; %cond.load1075
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d2
	ldr	s16, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_374
LBB1_417:                               ; %cond.load1081
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v2[1]
	ld1.s	{ v16 }[1], [x10]
	ldr	q2, [sp, #2752]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2816]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #2, LBB1_375
LBB1_418:                               ; %cond.load1087
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d2
	ld1.s	{ v16 }[2], [x10]
	tbz	w9, #3, LBB1_376
LBB1_419:                               ; %cond.load1093
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v2[1]
	ld1.s	{ v16 }[3], [x10]
	ldr	q2, [sp, #2736]                 ; 16-byte Reload
	orr.16b	v2, v1, v2
	ldr	q3, [sp, #2800]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #4, LBB1_377
LBB1_420:                               ; %cond.load1099
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d2
	ld1.s	{ v17 }[0], [x10]
	tbz	w9, #5, LBB1_378
LBB1_421:                               ; %cond.load1105
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v2[1]
	ld1.s	{ v17 }[1], [x10]
	ldr	q2, [sp, #2768]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #2832]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB1_379
LBB1_422:                               ; %cond.load1111
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d1
	ld1.s	{ v17 }[2], [x10]
	tbnz	w9, #7, LBB1_380
	b	LBB1_381
LBB1_423:                               ; %cond.load1124
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d3
	ldr	s1, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_383
LBB1_424:                               ; %cond.load1130
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v1 }[1], [x10]
	orr.16b	v3, v2, v22
	add.2d	v3, v23, v3
	tbz	w9, #2, LBB1_384
LBB1_425:                               ; %cond.load1136
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d3
	ld1.s	{ v1 }[2], [x10]
	tbz	w9, #3, LBB1_385
LBB1_426:                               ; %cond.load1142
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v1 }[3], [x10]
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	ldr	q4, [sp, #2864]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbz	w9, #4, LBB1_386
LBB1_427:                               ; %cond.load1148
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d3
	ld1.s	{ v7 }[0], [x10]
	tbz	w9, #5, LBB1_387
LBB1_428:                               ; %cond.load1154
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v7 }[1], [x10]
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #6, LBB1_388
LBB1_429:                               ; %cond.load1160
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d2
	ld1.s	{ v7 }[2], [x10]
	tbnz	w9, #7, LBB1_389
	b	LBB1_390
LBB1_430:                               ; %cond.load1173
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d3
	ldr	s20, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_392
LBB1_431:                               ; %cond.load1179
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v20 }[1], [x10]
	orr.16b	v3, v2, v22
	add.2d	v3, v23, v3
	tbz	w9, #2, LBB1_393
LBB1_432:                               ; %cond.load1185
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d3
	ld1.s	{ v20 }[2], [x10]
	tbz	w9, #3, LBB1_394
LBB1_433:                               ; %cond.load1191
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v20 }[3], [x10]
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	ldr	q4, [sp, #2864]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbz	w9, #4, LBB1_395
LBB1_434:                               ; %cond.load1197
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d3
	ld1.s	{ v21 }[0], [x10]
	tbz	w9, #5, LBB1_396
LBB1_435:                               ; %cond.load1203
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v3[1]
	ld1.s	{ v21 }[1], [x10]
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #6, LBB1_397
LBB1_436:                               ; %cond.load1209
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d2
	ld1.s	{ v21 }[2], [x10]
	tbnz	w9, #7, LBB1_398
	b	LBB1_399
LBB1_437:                               ; %cond.load1222
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d28
	ldr	s2, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_401
LBB1_438:                               ; %cond.load1228
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v28[1]
	ld1.s	{ v2 }[1], [x10]
	orr.16b	v22, v4, v22
	add.2d	v22, v23, v22
	tbz	w9, #2, LBB1_402
LBB1_439:                               ; %cond.load1234
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d22
	ld1.s	{ v2 }[2], [x10]
	tbz	w9, #3, LBB1_403
LBB1_440:                               ; %cond.load1240
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v2 }[3], [x10]
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	ldr	q28, [sp, #2864]                ; 16-byte Reload
	add.2d	v22, v28, v22
	tbz	w9, #4, LBB1_404
LBB1_441:                               ; %cond.load1246
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d22
	ld1.s	{ v3 }[0], [x10]
	ldr	q27, [sp, #2880]                ; 16-byte Reload
	tbz	w9, #5, LBB1_405
LBB1_442:                               ; %cond.load1252
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v3 }[1], [x10]
	ldr	q22, [sp, #2912]                ; 16-byte Reload
	orr.16b	v4, v4, v22
	ldr	q22, [sp, #2896]                ; 16-byte Reload
	add.2d	v4, v22, v4
	tbz	w9, #6, LBB1_406
LBB1_443:                               ; %cond.load1258
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d4
	ld1.s	{ v3 }[2], [x10]
	tbnz	w9, #7, LBB1_407
	b	LBB1_408
LBB1_444:                               ; %cond.load1271
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d30
	ldr	s28, [x10]
	and	w9, w9, #0xff
	ldr	q5, [sp, #2864]                 ; 16-byte Reload
	tbz	w9, #1, LBB1_410
LBB1_445:                               ; %cond.load1277
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v30[1]
	ld1.s	{ v28 }[1], [x10]
	ldr	q22, [sp, #2208]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v23, v22
	tbz	w9, #2, LBB1_411
LBB1_446:                               ; %cond.load1283
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d22
	ld1.s	{ v28 }[2], [x10]
	ldr	q23, [sp, #2896]                ; 16-byte Reload
	tbz	w9, #3, LBB1_412
LBB1_447:                               ; %cond.load1289
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v28 }[3], [x10]
	ldr	q22, [sp, #2928]                ; 16-byte Reload
	orr.16b	v22, v4, v22
	add.2d	v22, v5, v22
	tbz	w9, #4, LBB1_413
LBB1_448:                               ; %cond.load1295
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d22
	ld1.s	{ v29 }[0], [x10]
	tbz	w9, #5, LBB1_414
LBB1_449:                               ; %cond.load1301
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x10, v22[1]
	ld1.s	{ v29 }[1], [x10]
	ldr	q5, [sp, #2912]                 ; 16-byte Reload
	orr.16b	v4, v4, v5
	add.2d	v4, v23, v4
	tbz	w9, #6, LBB1_415
LBB1_450:                               ; %cond.load1307
                                        ;   in Loop: Header=BB1_372 Depth=3
	fmov	x10, d4
	ld1.s	{ v29 }[2], [x10]
	mov.16b	v27, v15
	tbz	w9, #7, LBB1_371
LBB1_451:                               ; %cond.load1313
                                        ;   in Loop: Header=BB1_372 Depth=3
	mov.d	x9, v4[1]
	ld1.s	{ v29 }[3], [x9]
	b	LBB1_371
LBB1_452:                               ; %direct.false292.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	mov	w10, #1267                      ; =0x4f3
	movk	w10, #15797, lsl #16
	dup.4s	v16, w10
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	fmul.4s	v5, v1, v16
	ldr	q1, [sp, #2224]                 ; 16-byte Reload
	fmul.4s	v29, v1, v16
	cmp	x6, #512
	cset	w10, lo
	dup.4h	v1, w10
	ldr	q2, [sp, #2256]                 ; 16-byte Reload
	fmul.4s	v3, v2, v16
	ldr	q2, [sp, #2272]                 ; 16-byte Reload
	fmul.4s	v2, v2, v16
	ldr	q4, [sp, #2288]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	ldp	q7, q17, [x2]
	ushll.4s	v1, v1, #0
	bit.16b	v17, v29, v0
	bit.16b	v7, v5, v15
	stp	q7, q17, [x2]
	shl.4s	v1, v1, #31
	cmlt.4s	v17, v1, #0
	ldr	q10, [sp, #240]                 ; 16-byte Reload
	bif.16b	v2, v10, v17
	ldp	q1, q7, [x2, #32]
	bif.16b	v3, v10, v17
	str	q3, [sp, #1232]                 ; 16-byte Spill
	bit.16b	v7, v3, v0
	str	q2, [sp, #1248]                 ; 16-byte Spill
	bit.16b	v1, v2, v15
	stp	q1, q7, [x2, #32]
	ldr	q1, [sp, #2304]                 ; 16-byte Reload
	fmul.4s	v1, v1, v16
	ldr	q7, [sp, #2320]                 ; 16-byte Reload
	fmul.4s	v7, v7, v16
	mov.16b	v21, v17
	bsl.16b	v21, v1, v10
	ldp	q1, q20, [x2, #64]
	bif.16b	v4, v10, v17
	str	q4, [sp, #1136]                 ; 16-byte Spill
	bif.16b	v4, v20, v0
	str	q21, [sp, #1152]                ; 16-byte Spill
	bit.16b	v1, v21, v15
	stp	q1, q4, [x2, #64]
	ldr	q1, [sp, #2336]                 ; 16-byte Reload
	fmul.4s	v1, v1, v16
	ldr	q4, [sp, #2352]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	bif.16b	v1, v10, v17
	ldp	q20, q22, [x2, #96]
	bif.16b	v7, v10, v17
	str	q7, [sp, #1040]                 ; 16-byte Spill
	bit.16b	v22, v7, v0
	str	q1, [sp, #1056]                 ; 16-byte Spill
	bit.16b	v20, v1, v15
	stp	q20, q22, [x2, #96]
	ldr	q20, [sp, #2368]                ; 16-byte Reload
	fmul.4s	v20, v20, v16
	ldr	q22, [sp, #2384]                ; 16-byte Reload
	fmul.4s	v22, v22, v16
	mov.16b	v1, v17
	bsl.16b	v1, v20, v10
	ldp	q30, q9, [x2, #128]
	bif.16b	v4, v10, v17
	str	q4, [sp, #960]                  ; 16-byte Spill
	bif.16b	v4, v9, v0
	ldr	q20, [sp, #1616]                ; 16-byte Reload
	str	q1, [sp, #1536]                 ; 16-byte Spill
	bit.16b	v30, v1, v20
	stp	q30, q4, [x2, #128]
	ldr	q4, [sp, #2400]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	ldr	q20, [sp, #2416]                ; 16-byte Reload
	fmul.4s	v30, v20, v16
	mov.16b	v1, v17
	bsl.16b	v1, v4, v10
	ldp	q4, q9, [x2, #160]
	mov.16b	v7, v17
	bsl.16b	v7, v22, v10
	stp	q7, q1, [sp, #864]              ; 32-byte Folded Spill
	mov.16b	v22, v0
	bsl.16b	v22, v7, v9
	ldr	q20, [sp, #1616]                ; 16-byte Reload
	bit.16b	v4, v1, v20
	stp	q4, q22, [x2, #160]
	ldr	q4, [sp, #2432]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	ldr	q20, [sp, #2448]                ; 16-byte Reload
	fmul.4s	v22, v20, v16
	mov.16b	v1, v17
	bsl.16b	v1, v4, v10
	ldp	q4, q9, [x2, #192]
	mov.16b	v7, v17
	bsl.16b	v7, v30, v10
	str	q7, [sp, #784]                  ; 16-byte Spill
	mov.16b	v30, v0
	bsl.16b	v30, v7, v9
	ldr	q20, [sp, #1616]                ; 16-byte Reload
	str	q1, [sp, #1520]                 ; 16-byte Spill
	bit.16b	v4, v1, v20
	stp	q4, q30, [x2, #192]
	ldr	q4, [sp, #2464]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	ldr	q20, [sp, #2480]                ; 16-byte Reload
	fmul.4s	v30, v20, v16
	mov.16b	v1, v17
	bsl.16b	v1, v4, v10
	ldp	q4, q9, [x2, #224]
	mov.16b	v7, v17
	bsl.16b	v7, v22, v10
	str	q7, [sp, #704]                  ; 16-byte Spill
	mov.16b	v22, v0
	bsl.16b	v22, v7, v9
	ldr	q20, [sp, #1616]                ; 16-byte Reload
	str	q1, [sp, #1504]                 ; 16-byte Spill
	bit.16b	v4, v1, v20
	stp	q4, q22, [x2, #224]
	ldr	q4, [sp, #2496]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	fmul.4s	v22, v23, v16
	mov.16b	v1, v17
	bsl.16b	v1, v4, v10
	ldp	q4, q9, [x2, #256]
	mov.16b	v7, v17
	bsl.16b	v7, v30, v10
	stp	q7, q1, [sp, #624]              ; 32-byte Folded Spill
	mov.16b	v30, v0
	bsl.16b	v30, v7, v9
	ldr	q20, [sp, #1616]                ; 16-byte Reload
	bit.16b	v4, v1, v20
	stp	q4, q30, [x2, #256]
	ldr	q4, [sp, #2512]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	ldr	q20, [sp, #2544]                ; 16-byte Reload
	fmul.4s	v30, v20, v16
	mov.16b	v1, v17
	bsl.16b	v1, v4, v10
	ldp	q9, q4, [x2, #288]
	mov.16b	v7, v17
	bsl.16b	v7, v22, v10
	ldr	q20, [sp, #1616]                ; 16-byte Reload
	str	q7, [sp, #656]                  ; 16-byte Spill
	mov.16b	v22, v20
	bsl.16b	v22, v7, v9
	str	q1, [sp, #1488]                 ; 16-byte Spill
	bit.16b	v4, v1, v0
	stp	q22, q4, [x2, #288]
	ldr	q4, [sp, #2528]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	ldr	q20, [sp, #2576]                ; 16-byte Reload
	fmul.4s	v22, v20, v16
	mov.16b	v1, v17
	bsl.16b	v1, v4, v10
	ldp	q9, q4, [x2, #320]
	mov.16b	v7, v17
	bsl.16b	v7, v30, v10
	ldr	q20, [sp, #1616]                ; 16-byte Reload
	stp	q7, q1, [sp, #720]              ; 32-byte Folded Spill
	mov.16b	v30, v20
	bsl.16b	v30, v7, v9
	bit.16b	v4, v1, v0
	stp	q30, q4, [x2, #320]
	ldr	q4, [sp, #2560]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	ldr	q20, [sp, #2608]                ; 16-byte Reload
	fmul.4s	v30, v20, v16
	mov.16b	v1, v17
	bsl.16b	v1, v4, v10
	ldp	q9, q4, [x2, #352]
	mov.16b	v7, v17
	bsl.16b	v7, v22, v10
	ldr	q20, [sp, #1616]                ; 16-byte Reload
	stp	q7, q1, [sp, #800]              ; 32-byte Folded Spill
	mov.16b	v22, v20
	bsl.16b	v22, v7, v9
	bit.16b	v4, v1, v0
	stp	q22, q4, [x2, #352]
	ldr	q4, [sp, #2592]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	ldr	q20, [sp, #2624]                ; 16-byte Reload
	fmul.4s	v22, v20, v16
	mov.16b	v1, v17
	bsl.16b	v1, v4, v10
	ldp	q9, q4, [x2, #384]
	mov.16b	v7, v17
	bsl.16b	v7, v30, v10
	ldr	q20, [sp, #1616]                ; 16-byte Reload
	stp	q7, q1, [sp, #896]              ; 32-byte Folded Spill
	mov.16b	v30, v20
	bsl.16b	v30, v7, v9
	ldr	q9, [sp, #1616]                 ; 16-byte Reload
	bit.16b	v4, v1, v0
	stp	q30, q4, [x2, #384]
	ldr	q4, [sp, #2640]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	mov.16b	v1, v17
	bsl.16b	v1, v4, v10
	mov.16b	v7, v17
	bsl.16b	v7, v22, v10
	ldp	q4, q22, [x2, #416]
	stp	q7, q1, [sp, #976]              ; 32-byte Folded Spill
	bit.16b	v22, v7, v0
	bit.16b	v4, v1, v9
	stp	q4, q22, [x2, #416]
	ldr	q4, [sp, #2672]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	ldr	q20, [sp, #2656]                ; 16-byte Reload
	fmul.4s	v22, v20, v16
	mov.16b	v1, v17
	bsl.16b	v1, v22, v10
	mov.16b	v7, v17
	bsl.16b	v7, v4, v10
	ldp	q4, q22, [x2, #448]
	str	q7, [sp, #1072]                 ; 16-byte Spill
	bit.16b	v4, v7, v9
	str	q1, [sp, #1088]                 ; 16-byte Spill
	bit.16b	v22, v1, v0
	stp	q4, q22, [x2, #448]
	ldr	q4, [sp, #2704]                 ; 16-byte Reload
	fmul.4s	v4, v4, v16
	ldr	q20, [sp, #2688]                ; 16-byte Reload
	fmul.4s	v16, v20, v16
	mov.16b	v1, v17
	bsl.16b	v1, v16, v10
	mov.16b	v7, v17
	bsl.16b	v7, v4, v10
	ldp	q4, q16, [x2, #480]
	str	q7, [sp, #1168]                 ; 16-byte Spill
	bit.16b	v4, v7, v9
	str	q1, [sp, #1184]                 ; 16-byte Spill
	bit.16b	v16, v1, v0
	stp	q4, q16, [x2, #480]
	mvni.4s	v4, #127, msl #16
	ldr	q30, [sp, #1360]                ; 16-byte Reload
	bit.16b	v30, v4, v0
	ldr	q17, [sp, #1376]                ; 16-byte Reload
	bit.16b	v17, v4, v9
	dup.8b	v4, w10
	str	d4, [sp, #1328]                 ; 8-byte Spill
LBB1_453:                               ; %direct.true416.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x10, x2, x9
	ldp	q4, q16, [x10]
	and.16b	v16, v0, v16
	and.16b	v4, v9, v4
	fmaxnm.4s	v4, v17, v4
	fmaxnm.4s	v16, v30, v16
	bit.16b	v30, v16, v0
	bit.16b	v17, v4, v9
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB1_453
; %bb.454:                              ; %direct.false417.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x7, #0                          ; =0x0
	str	q17, [sp, #1376]                ; 16-byte Spill
	ldr	q4, [sp, #1552]                 ; 16-byte Reload
	fmaxnm.4s	v1, v4, v17
	str	q1, [sp, #1600]                 ; 16-byte Spill
	fsub.4s	v4, v5, v1
	ldp	q16, q5, [sp, #304]             ; 32-byte Folded Reload
	cmhi.4s	v5, v16, v5
	and.16b	v23, v5, v4
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v17, w9
	fcmge.4s	v4, v23, v17
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v16, w9
	fcmge.4s	v22, v16, v23
	and.16b	v4, v4, v22
	str	q30, [sp, #1360]                ; 16-byte Spill
	ldr	q7, [sp, #1568]                 ; 16-byte Reload
	fmaxnm.4s	v1, v7, v30
	str	q1, [sp, #1584]                 ; 16-byte Spill
	fsub.4s	v22, v29, v1
	and.16b	v20, v0, v22
	fcmge.4s	v22, v20, v17
	fcmge.4s	v29, v16, v20
	and.16b	v22, v22, v29
	and.16b	v22, v22, v20
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v1, w9
	str	q1, [sp, #2192]                 ; 16-byte Spill
	fmul.4s	v29, v22, v1
	movi.4s	v9, #75, lsl #24
	mvni.4s	v10, #128, lsl #24
	mov.16b	v30, v10
	bsl.16b	v30, v9, v29
	fadd.4s	v29, v29, v30
	fsub.4s	v29, v29, v30
	and.16b	v30, v4, v23
	fmul.4s	v4, v30, v1
	bif.16b	v9, v4, v10
	fadd.4s	v4, v4, v9
	fsub.4s	v9, v4, v9
	fcvtzs.4s	v7, v29
	scvtf.4s	v10, v7
	mov	w9, #29184                      ; =0x7200
	movk	w9, #16177, lsl #16
	dup.4s	v21, w9
	fmul.4s	v29, v10, v21
	fsub.4s	v22, v22, v29
	fcvtzs.4s	v29, v9
	scvtf.4s	v9, v29
	fmul.4s	v15, v9, v21
	fsub.4s	v30, v30, v15
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #13759, lsl #16
	dup.4s	v3, w9
	str	q3, [sp, #2880]                 ; 16-byte Spill
	fmul.4s	v9, v9, v3
	fsub.4s	v30, v30, v9
	fmul.4s	v9, v10, v3
	fsub.4s	v22, v22, v9
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v15, w9
	fmul.4s	v9, v22, v15
	str	q15, [sp, #1648]                ; 16-byte Spill
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v4, w9
	fadd.4s	v9, v9, v4
	str	q4, [sp, #1664]                 ; 16-byte Spill
	fmul.4s	v9, v22, v9
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v3, w9
	fadd.4s	v9, v9, v3
	str	q3, [sp, #2176]                 ; 16-byte Spill
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v2, w9
	fmul.4s	v9, v22, v9
	fadd.4s	v9, v9, v2
	str	q2, [sp, #1632]                 ; 16-byte Spill
	fmul.4s	v9, v22, v9
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v1, w9
	fadd.4s	v9, v9, v1
	str	q1, [sp, #1888]                 ; 16-byte Spill
	fmul.4s	v9, v22, v9
	movi.4s	v28, #63, lsl #24
	fadd.4s	v9, v9, v28
	fmul.4s	v10, v22, v22
	fmul.4s	v9, v10, v9
	fmul.4s	v10, v30, v15
	fadd.4s	v10, v10, v4
	fmul.4s	v10, v30, v10
	fadd.4s	v10, v10, v3
	fmul.4s	v10, v30, v10
	fadd.4s	v10, v10, v2
	fmul.4s	v10, v30, v10
	fadd.4s	v10, v10, v1
	fmul.4s	v10, v30, v10
	fadd.4s	v10, v10, v28
	fmul.4s	v15, v30, v30
	fmul.4s	v10, v15, v10
	fadd.4s	v30, v30, v10
	fadd.4s	v22, v22, v9
	fmov.4s	v28, #1.00000000
	fadd.4s	v30, v30, v28
	sshr.4s	v9, v29, #1
	shl.4s	v10, v9, #23
	add.4s	v10, v10, v28
	fmul.4s	v30, v30, v10
	fadd.4s	v22, v22, v28
	sshr.4s	v10, v7, #1
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v28
	fmul.4s	v22, v22, v15
	sub.4s	v29, v29, v9
	sub.4s	v4, v7, v10
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v22, v4
	shl.4s	v22, v29, #23
	add.4s	v22, v22, v28
	fmul.4s	v22, v30, v22
	str	q23, [sp, #1264]                ; 16-byte Spill
	fcmgt.4s	v29, v17, v23
	bic.16b	v22, v22, v29
	str	q20, [sp, #1312]                ; 16-byte Spill
	fcmgt.4s	v29, v17, v20
	bic.16b	v4, v4, v29
	fcmgt.4s	v29, v20, v16
	mvni.4s	v20, #127, msl #16
	fneg.4s	v1, v20
	str	q1, [sp, #2160]                 ; 16-byte Spill
	bit.16b	v4, v1, v29
	str	q4, [sp, #1296]                 ; 16-byte Spill
	fcmgt.4s	v4, v23, v16
	bsl.16b	v4, v1, v22
	str	q4, [sp, #1280]                 ; 16-byte Spill
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	ldr	q1, [sp, #1584]                 ; 16-byte Reload
	fsub.4s	v3, v3, v1
	and.16b	v10, v0, v3
	fcmge.4s	v3, v10, v17
	fcmge.4s	v4, v16, v10
	and.16b	v3, v3, v4
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	ldr	q2, [sp, #1248]                 ; 16-byte Reload
	fsub.4s	v2, v2, v1
	and.16b	v15, v5, v2
	fcmge.4s	v2, v15, v17
	fcmge.4s	v4, v16, v15
	and.16b	v2, v2, v4
	and.16b	v4, v2, v15
	ldr	q7, [sp, #2192]                 ; 16-byte Reload
	fmul.4s	v2, v4, v7
	mvni.4s	v20, #128, lsl #24
	movi.4s	v23, #75, lsl #24
	mov.16b	v22, v20
	bsl.16b	v22, v23, v2
	fadd.4s	v2, v2, v22
	fsub.4s	v2, v2, v22
	and.16b	v3, v3, v10
	fmul.4s	v22, v3, v7
	mov.16b	v29, v20
	bsl.16b	v29, v23, v22
	fadd.4s	v22, v22, v29
	fsub.4s	v22, v22, v29
	fcvtzs.4s	v2, v2
	scvtf.4s	v29, v2
	str	q21, [sp, #1904]                ; 16-byte Spill
	fmul.4s	v30, v29, v21
	fsub.4s	v4, v4, v30
	fcvtzs.4s	v22, v22
	scvtf.4s	v30, v22
	fmul.4s	v9, v30, v21
	fsub.4s	v3, v3, v9
	ldr	q7, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v30, v30, v7
	fsub.4s	v3, v3, v30
	fmul.4s	v29, v29, v7
	fsub.4s	v4, v4, v29
	ldr	q20, [sp, #1648]                ; 16-byte Reload
	fmul.4s	v29, v4, v20
	ldr	q21, [sp, #1664]                ; 16-byte Reload
	fadd.4s	v29, v29, v21
	fmul.4s	v29, v4, v29
	ldr	q28, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v29, v29, v28
	fmul.4s	v29, v4, v29
	ldr	q9, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v29, v29, v9
	fmul.4s	v29, v4, v29
	ldr	q23, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v29, v29, v23
	fmul.4s	v29, v4, v29
	movi.4s	v7, #63, lsl #24
	fadd.4s	v29, v29, v7
	fmul.4s	v30, v4, v4
	fmul.4s	v29, v30, v29
	fmul.4s	v30, v3, v20
	fadd.4s	v30, v30, v21
	fmul.4s	v30, v3, v30
	fadd.4s	v30, v30, v28
	fmul.4s	v30, v3, v30
	fadd.4s	v30, v30, v9
	fmul.4s	v30, v3, v30
	fadd.4s	v30, v30, v23
	fmul.4s	v30, v3, v30
	fadd.4s	v30, v30, v7
	fmul.4s	v9, v3, v3
	fmul.4s	v30, v9, v30
	fadd.4s	v3, v3, v30
	fadd.4s	v4, v4, v29
	fmov.4s	v7, #1.00000000
	fadd.4s	v3, v3, v7
	sshr.4s	v29, v22, #1
	shl.4s	v30, v29, #23
	add.4s	v30, v30, v7
	fmul.4s	v3, v3, v30
	fadd.4s	v4, v4, v7
	sshr.4s	v30, v2, #1
	shl.4s	v9, v30, #23
	add.4s	v9, v9, v7
	fmul.4s	v4, v4, v9
	sub.4s	v22, v22, v29
	sub.4s	v2, v2, v30
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v7
	fmul.4s	v2, v4, v2
	shl.4s	v4, v22, #23
	add.4s	v4, v4, v7
	fmul.4s	v3, v3, v4
	str	q10, [sp, #1200]                ; 16-byte Spill
	fcmgt.4s	v4, v17, v10
	bic.16b	v3, v3, v4
	str	q15, [sp, #1216]                ; 16-byte Spill
	fcmgt.4s	v4, v17, v15
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v15, v16
	ldr	q7, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v2, v7, v4
	str	q2, [sp, #1248]                 ; 16-byte Spill
	fcmgt.4s	v2, v10, v16
	bsl.16b	v2, v7, v3
	str	q2, [sp, #1232]                 ; 16-byte Spill
	ldr	q2, [sp, #1136]                 ; 16-byte Reload
	ldr	q9, [sp, #1584]                 ; 16-byte Reload
	fsub.4s	v2, v2, v9
	and.16b	v23, v0, v2
	fcmge.4s	v2, v23, v17
	fcmge.4s	v3, v16, v23
	and.16b	v2, v2, v3
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	fsub.4s	v3, v3, v1
	and.16b	v15, v5, v3
	fcmge.4s	v3, v15, v17
	fcmge.4s	v4, v16, v15
	and.16b	v3, v3, v4
	and.16b	v3, v3, v15
	ldr	q7, [sp, #2192]                 ; 16-byte Reload
	fmul.4s	v4, v3, v7
	movi.4s	v1, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v21, v20
	bsl.16b	v21, v1, v4
	fadd.4s	v4, v4, v21
	fsub.4s	v4, v4, v21
	and.16b	v21, v2, v23
	fmul.4s	v2, v21, v7
	mov.16b	v22, v20
	bsl.16b	v22, v1, v2
	fadd.4s	v2, v2, v22
	fsub.4s	v22, v2, v22
	fcvtzs.4s	v2, v4
	scvtf.4s	v4, v2
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v28, v4, v1
	fsub.4s	v3, v3, v28
	fcvtzs.4s	v22, v22
	scvtf.4s	v28, v22
	fmul.4s	v29, v28, v1
	fsub.4s	v21, v21, v29
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v28, v28, v1
	fsub.4s	v21, v21, v28
	fmul.4s	v4, v4, v1
	fsub.4s	v3, v3, v4
	ldr	q1, [sp, #1648]                 ; 16-byte Reload
	fmul.4s	v4, v3, v1
	ldr	q30, [sp, #1664]                ; 16-byte Reload
	fadd.4s	v4, v4, v30
	fmul.4s	v4, v3, v4
	ldr	q10, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v4, v4, v10
	fmul.4s	v4, v3, v4
	ldr	q29, [sp, #1632]                ; 16-byte Reload
	fadd.4s	v4, v4, v29
	fmul.4s	v4, v3, v4
	ldr	q20, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v3, v4
	movi.4s	v7, #63, lsl #24
	fadd.4s	v4, v4, v7
	fmul.4s	v28, v3, v3
	fmul.4s	v4, v28, v4
	fmul.4s	v28, v21, v1
	fadd.4s	v28, v28, v30
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v10
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v29
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v20
	fmul.4s	v28, v21, v28
	fadd.4s	v28, v28, v7
	fmul.4s	v29, v21, v21
	fmul.4s	v28, v29, v28
	fadd.4s	v21, v21, v28
	fadd.4s	v3, v3, v4
	fmov.4s	v1, #1.00000000
	fadd.4s	v4, v21, v1
	sshr.4s	v21, v22, #1
	shl.4s	v28, v21, #23
	add.4s	v28, v28, v1
	fmul.4s	v4, v4, v28
	fadd.4s	v3, v3, v1
	sshr.4s	v28, v2, #1
	shl.4s	v29, v28, #23
	add.4s	v29, v29, v1
	fmul.4s	v3, v3, v29
	sub.4s	v21, v22, v21
	sub.4s	v2, v2, v28
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v1
	fmul.4s	v2, v3, v2
	shl.4s	v3, v21, #23
	add.4s	v3, v3, v1
	fmul.4s	v3, v4, v3
	str	q23, [sp, #1104]                ; 16-byte Spill
	fcmgt.4s	v4, v17, v23
	bic.16b	v3, v3, v4
	str	q15, [sp, #1136]                ; 16-byte Spill
	fcmgt.4s	v4, v17, v15
	bic.16b	v2, v2, v4
	mov.16b	v30, v16
	fcmgt.4s	v4, v15, v16
	ldr	q20, [sp, #2160]                ; 16-byte Reload
	mov.16b	v1, v4
	bsl.16b	v1, v20, v2
	str	q1, [sp, #1152]                 ; 16-byte Spill
	fcmgt.4s	v2, v23, v16
	mov.16b	v1, v2
	bsl.16b	v1, v20, v3
	str	q1, [sp, #1120]                 ; 16-byte Spill
	mov.16b	v20, v9
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	fsub.4s	v2, v1, v9
	and.16b	v23, v0, v2
	fcmge.4s	v2, v23, v17
	fcmge.4s	v3, v16, v23
	and.16b	v2, v2, v3
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	fsub.4s	v1, v1, v3
	and.16b	v10, v5, v1
	fcmge.4s	v1, v10, v17
	fcmge.4s	v3, v16, v10
	and.16b	v1, v1, v3
	and.16b	v3, v1, v10
	ldr	q16, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v1, v3, v16
	mvni.4s	v7, #128, lsl #24
	movi.4s	v21, #75, lsl #24
	mov.16b	v4, v7
	bsl.16b	v4, v21, v1
	fadd.4s	v1, v1, v4
	fsub.4s	v1, v1, v4
	and.16b	v2, v2, v23
	fmul.4s	v4, v2, v16
	bsl.16b	v7, v21, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	fcvtzs.4s	v1, v1
	scvtf.4s	v7, v1
	ldr	q16, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v21, v7, v16
	fsub.4s	v3, v3, v21
	fcvtzs.4s	v4, v4
	scvtf.4s	v21, v4
	fmul.4s	v22, v21, v16
	fsub.4s	v2, v2, v22
	ldr	q16, [sp, #2880]                ; 16-byte Reload
	fmul.4s	v21, v21, v16
	fsub.4s	v2, v2, v21
	fmul.4s	v7, v7, v16
	fsub.4s	v3, v3, v7
	ldr	q28, [sp, #1648]                ; 16-byte Reload
	fmul.4s	v7, v3, v28
	ldr	q15, [sp, #1664]                ; 16-byte Reload
	fadd.4s	v7, v7, v15
	fmul.4s	v7, v3, v7
	ldr	q9, [sp, #2176]                 ; 16-byte Reload
	fadd.4s	v7, v7, v9
	fmul.4s	v7, v3, v7
	ldr	q16, [sp, #1632]                ; 16-byte Reload
	fadd.4s	v7, v7, v16
	fmul.4s	v7, v3, v7
	ldr	q22, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v7, v7, v22
	fmul.4s	v7, v3, v7
	movi.4s	v29, #63, lsl #24
	fadd.4s	v7, v7, v29
	fmul.4s	v21, v3, v3
	fmul.4s	v7, v21, v7
	fmul.4s	v21, v2, v28
	fadd.4s	v21, v21, v15
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v9
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v16
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v2, v21
	fadd.4s	v21, v21, v29
	fmul.4s	v22, v2, v2
	fmul.4s	v21, v22, v21
	fadd.4s	v2, v2, v21
	fadd.4s	v3, v3, v7
	fmov.4s	v16, #1.00000000
	fadd.4s	v2, v2, v16
	sshr.4s	v7, v4, #1
	shl.4s	v21, v7, #23
	add.4s	v21, v21, v16
	fmul.4s	v2, v2, v21
	fadd.4s	v3, v3, v16
	sshr.4s	v21, v1, #1
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v16
	fmul.4s	v3, v3, v22
	sub.4s	v4, v4, v7
	sub.4s	v1, v1, v21
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v16
	fmul.4s	v1, v3, v1
	shl.4s	v3, v4, #23
	add.4s	v3, v3, v16
	fmov.4s	v22, #1.00000000
	fmul.4s	v2, v2, v3
	mov.16b	v9, v17
	fcmgt.4s	v3, v17, v23
	bic.16b	v2, v2, v3
	str	q10, [sp, #1040]                ; 16-byte Spill
	fcmgt.4s	v3, v17, v10
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v10, v30
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #1056]                 ; 16-byte Spill
	fcmgt.4s	v1, v23, v30
	bsl.16b	v1, v4, v2
	stp	q23, q1, [sp, #1008]            ; 32-byte Folded Spill
	ldr	q1, [sp, #960]                  ; 16-byte Reload
	fsub.4s	v1, v1, v20
	and.16b	v10, v0, v1
	fcmge.4s	v1, v10, v17
	fcmge.4s	v2, v30, v10
	and.16b	v1, v1, v2
	ldr	q23, [sp, #1600]                ; 16-byte Reload
	ldr	q2, [sp, #1536]                 ; 16-byte Reload
	fsub.4s	v2, v2, v23
	and.16b	v4, v5, v2
	str	q4, [sp, #1536]                 ; 16-byte Spill
	fcmge.4s	v2, v4, v17
	fcmge.4s	v3, v30, v4
	and.16b	v2, v2, v3
	and.16b	v2, v2, v4
	ldr	q16, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v3, v2, v16
	movi.4s	v7, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v4, v20
	bsl.16b	v4, v7, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v10
	fmul.4s	v1, v4, v16
	bif.16b	v7, v1, v20
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v16, v3
	scvtf.4s	v3, v16
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v20, v3, v1
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v1
	fsub.4s	v4, v4, v21
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v20, v20, v1
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v1
	fsub.4s	v2, v2, v3
	mov.16b	v1, v28
	fmul.4s	v3, v2, v28
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	ldr	q29, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v3, v3, v29
	fmul.4s	v3, v2, v3
	ldr	q21, [sp, #1632]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	fmul.4s	v3, v2, v3
	ldr	q28, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v3, v3, v28
	fmul.4s	v3, v2, v3
	movi.4s	v17, #63, lsl #24
	fadd.4s	v3, v3, v17
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v1
	fadd.4s	v20, v20, v15
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v29
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v17
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v4, v22
	sshr.4s	v4, v7, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v22
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v22
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v22
	fmul.4s	v2, v2, v21
	sub.4s	v4, v7, v4
	sub.4s	v1, v16, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v22
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v22
	fmul.4s	v2, v3, v2
	fcmgt.4s	v3, v9, v10
	bic.16b	v2, v2, v3
	ldr	q22, [sp, #1536]                ; 16-byte Reload
	fcmgt.4s	v3, v9, v22
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v22, v30
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #960]                  ; 16-byte Spill
	fcmgt.4s	v1, v10, v30
	bsl.16b	v1, v4, v2
	stp	q10, q1, [sp, #928]             ; 32-byte Folded Spill
	ldr	q1, [sp, #864]                  ; 16-byte Reload
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	fsub.4s	v1, v1, v2
	and.16b	v28, v0, v1
	fcmge.4s	v1, v28, v9
	fcmge.4s	v2, v30, v28
	and.16b	v1, v1, v2
	ldr	q2, [sp, #880]                  ; 16-byte Reload
	fsub.4s	v2, v2, v23
	mov.16b	v15, v23
	and.16b	v29, v5, v2
	fcmge.4s	v2, v29, v9
	fcmge.4s	v3, v30, v29
	and.16b	v2, v2, v3
	and.16b	v2, v2, v29
	ldr	q17, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v3, v2, v17
	mvni.4s	v7, #128, lsl #24
	movi.4s	v16, #75, lsl #24
	mov.16b	v4, v7
	bsl.16b	v4, v16, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v28
	fmul.4s	v1, v4, v17
	bsl.16b	v7, v16, v1
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v17, v3
	scvtf.4s	v3, v17
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v20, v3, v1
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v16, v7
	scvtf.4s	v20, v16
	fmul.4s	v21, v20, v1
	fsub.4s	v4, v4, v21
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v20, v20, v1
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v1
	fsub.4s	v2, v2, v3
	ldr	q23, [sp, #1648]                ; 16-byte Reload
	fmul.4s	v3, v2, v23
	ldr	q21, [sp, #1664]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	fmul.4s	v3, v2, v3
	ldr	q7, [sp, #2176]                 ; 16-byte Reload
	fadd.4s	v3, v3, v7
	fmul.4s	v3, v2, v3
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v3, v3, v1
	fmul.4s	v3, v2, v3
	ldr	q22, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v2, v3
	movi.4s	v10, #63, lsl #24
	fadd.4s	v3, v3, v10
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v23
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v7
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v1
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v10
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fmov.4s	v22, #1.00000000
	fadd.4s	v3, v4, v22
	sshr.4s	v4, v16, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v22
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v22
	sshr.4s	v20, v17, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v22
	fmul.4s	v2, v2, v21
	sub.4s	v4, v16, v4
	sub.4s	v1, v17, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v22
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v22
	fmul.4s	v2, v3, v2
	fcmgt.4s	v3, v9, v28
	bic.16b	v2, v2, v3
	fcmgt.4s	v3, v9, v29
	mov.16b	v17, v9
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v29, v30
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	stp	q29, q1, [sp, #864]             ; 32-byte Folded Spill
	fcmgt.4s	v1, v28, v30
	mov.16b	v29, v30
	bsl.16b	v1, v4, v2
	stp	q28, q1, [sp, #832]             ; 32-byte Folded Spill
	ldr	q30, [sp, #1584]                ; 16-byte Reload
	ldr	q1, [sp, #784]                  ; 16-byte Reload
	fsub.4s	v1, v1, v30
	and.16b	v28, v0, v1
	fcmge.4s	v1, v28, v9
	fcmge.4s	v2, v29, v28
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1520]                 ; 16-byte Reload
	fsub.4s	v2, v2, v15
	and.16b	v4, v5, v2
	str	q4, [sp, #1520]                 ; 16-byte Spill
	fcmge.4s	v2, v4, v9
	fcmge.4s	v3, v29, v4
	and.16b	v2, v2, v3
	and.16b	v2, v2, v4
	ldr	q16, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v3, v2, v16
	movi.4s	v7, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v4, v20
	bsl.16b	v4, v7, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v28
	fmul.4s	v1, v4, v16
	bif.16b	v7, v1, v20
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v16, v3
	scvtf.4s	v3, v16
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v20, v3, v1
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v1
	fsub.4s	v4, v4, v21
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v20, v20, v1
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v1
	fsub.4s	v2, v2, v3
	ldr	q1, [sp, #1648]                 ; 16-byte Reload
	fmul.4s	v3, v2, v1
	ldr	q15, [sp, #1664]                ; 16-byte Reload
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	ldr	q21, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	fmul.4s	v3, v2, v3
	ldr	q10, [sp, #1632]                ; 16-byte Reload
	fadd.4s	v3, v3, v10
	fmul.4s	v3, v2, v3
	ldr	q23, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v2, v3
	movi.4s	v9, #63, lsl #24
	fadd.4s	v3, v3, v9
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v1
	fadd.4s	v20, v20, v15
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v23
	mov.16b	v10, v23
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v4, v22
	sshr.4s	v4, v7, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v22
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v22
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v22
	fmul.4s	v2, v2, v21
	sub.4s	v4, v7, v4
	sub.4s	v1, v16, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v22
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v22
	fmul.4s	v2, v3, v2
	mov.16b	v23, v17
	fcmgt.4s	v3, v17, v28
	bic.16b	v2, v2, v3
	ldr	q22, [sp, #1520]                ; 16-byte Reload
	fcmgt.4s	v3, v17, v22
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v22, v29
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #784]                  ; 16-byte Spill
	fcmgt.4s	v1, v28, v29
	mov.16b	v22, v29
	bsl.16b	v1, v4, v2
	stp	q28, q1, [sp, #752]             ; 32-byte Folded Spill
	ldr	q1, [sp, #704]                  ; 16-byte Reload
	fsub.4s	v1, v1, v30
	and.16b	v9, v0, v1
	fcmge.4s	v1, v9, v17
	fcmge.4s	v2, v29, v9
	and.16b	v1, v1, v2
	ldr	q29, [sp, #1600]                ; 16-byte Reload
	ldr	q2, [sp, #1504]                 ; 16-byte Reload
	fsub.4s	v2, v2, v29
	and.16b	v4, v5, v2
	str	q4, [sp, #1504]                 ; 16-byte Spill
	fcmge.4s	v2, v4, v17
	fcmge.4s	v3, v22, v4
	and.16b	v2, v2, v3
	and.16b	v2, v2, v4
	ldr	q7, [sp, #2192]                 ; 16-byte Reload
	fmul.4s	v3, v2, v7
	mvni.4s	v16, #128, lsl #24
	movi.4s	v20, #75, lsl #24
	mov.16b	v4, v16
	bsl.16b	v4, v20, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v9
	fmul.4s	v1, v4, v7
	mov.16b	v7, v16
	bsl.16b	v7, v20, v1
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v16, v3
	scvtf.4s	v3, v16
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v20, v3, v1
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v1
	fsub.4s	v4, v4, v21
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v20, v20, v1
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v1
	fsub.4s	v2, v2, v3
	ldr	q15, [sp, #1648]                ; 16-byte Reload
	fmul.4s	v3, v2, v15
	ldr	q21, [sp, #1664]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	fmul.4s	v3, v2, v3
	ldr	q30, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v3, v3, v30
	fmul.4s	v3, v2, v3
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v3, v3, v1
	fmul.4s	v3, v2, v3
	mov.16b	v28, v10
	fadd.4s	v3, v3, v10
	fmul.4s	v3, v2, v3
	movi.4s	v17, #63, lsl #24
	fadd.4s	v3, v3, v17
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v15
	mov.16b	v10, v15
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v30
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v1
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v17
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fmov.4s	v28, #1.00000000
	fadd.4s	v3, v4, v28
	sshr.4s	v4, v7, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v28
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v28
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v28
	fmul.4s	v2, v2, v21
	sub.4s	v4, v7, v4
	sub.4s	v1, v16, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v28
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v28
	fmul.4s	v2, v3, v2
	mov.16b	v17, v23
	fcmgt.4s	v3, v23, v9
	bic.16b	v2, v2, v3
	ldr	q23, [sp, #1504]                ; 16-byte Reload
	fcmgt.4s	v3, v17, v23
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v23, v22
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #704]                  ; 16-byte Spill
	fcmgt.4s	v1, v9, v22
	mov.16b	v30, v22
	bsl.16b	v1, v4, v2
	stp	q9, q1, [sp, #672]              ; 32-byte Folded Spill
	ldr	q1, [sp, #624]                  ; 16-byte Reload
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	fsub.4s	v1, v1, v2
	and.16b	v15, v0, v1
	fcmge.4s	v1, v15, v17
	fcmge.4s	v2, v22, v15
	and.16b	v1, v1, v2
	ldr	q2, [sp, #640]                  ; 16-byte Reload
	fsub.4s	v2, v2, v29
	and.16b	v23, v5, v2
	fcmge.4s	v2, v23, v17
	fcmge.4s	v3, v22, v23
	and.16b	v2, v2, v3
	and.16b	v2, v2, v23
	ldr	q16, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v3, v2, v16
	mvni.4s	v7, #128, lsl #24
	movi.4s	v20, #75, lsl #24
	mov.16b	v4, v7
	bsl.16b	v4, v20, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v15
	fmul.4s	v1, v4, v16
	bsl.16b	v7, v20, v1
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v16, v3
	scvtf.4s	v3, v16
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v20, v3, v1
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v1
	fsub.4s	v4, v4, v21
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v20, v20, v1
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v1
	fsub.4s	v2, v2, v3
	fmul.4s	v3, v2, v10
	ldr	q9, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v3, v3, v9
	fmul.4s	v3, v2, v3
	ldr	q29, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v3, v3, v29
	fmul.4s	v3, v2, v3
	ldr	q21, [sp, #1632]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	fmul.4s	v3, v2, v3
	ldr	q28, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v3, v3, v28
	fmul.4s	v3, v2, v3
	movi.4s	v22, #63, lsl #24
	fadd.4s	v3, v3, v22
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v10
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v29
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fmov.4s	v22, #1.00000000
	fadd.4s	v3, v4, v22
	sshr.4s	v4, v7, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v22
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v22
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v22
	fmul.4s	v2, v2, v21
	sub.4s	v4, v7, v4
	sub.4s	v1, v16, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v22
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v22
	fmul.4s	v2, v3, v2
	mov.16b	v28, v17
	fcmgt.4s	v3, v17, v15
	bic.16b	v2, v2, v3
	fcmgt.4s	v3, v17, v23
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v23, v30
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	stp	q23, q1, [sp, #624]             ; 32-byte Folded Spill
	fcmgt.4s	v1, v15, v30
	bsl.16b	v1, v4, v2
	stp	q15, q1, [sp, #592]             ; 32-byte Folded Spill
	ldr	q1, [sp, #656]                  ; 16-byte Reload
	ldr	q2, [sp, #1600]                 ; 16-byte Reload
	fsub.4s	v1, v1, v2
	and.16b	v22, v5, v1
	fcmge.4s	v1, v22, v17
	fcmge.4s	v2, v30, v22
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1488]                 ; 16-byte Reload
	ldr	q15, [sp, #1584]                ; 16-byte Reload
	fsub.4s	v2, v2, v15
	and.16b	v4, v0, v2
	str	q4, [sp, #1488]                 ; 16-byte Spill
	fcmge.4s	v2, v4, v17
	fcmge.4s	v3, v30, v4
	and.16b	v2, v2, v3
	and.16b	v2, v2, v4
	ldr	q7, [sp, #2192]                 ; 16-byte Reload
	fmul.4s	v3, v2, v7
	movi.4s	v16, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v4, v20
	bsl.16b	v4, v16, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v22
	fmul.4s	v1, v4, v7
	mov.16b	v7, v20
	bsl.16b	v7, v16, v1
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v16, v3
	scvtf.4s	v3, v16
	ldr	q29, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v20, v3, v29
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v29
	fsub.4s	v4, v4, v21
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v20, v20, v1
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v1
	fsub.4s	v2, v2, v3
	mov.16b	v1, v10
	fmul.4s	v3, v2, v10
	mov.16b	v10, v9
	fadd.4s	v3, v3, v9
	fmul.4s	v3, v2, v3
	ldr	q21, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	fmul.4s	v3, v2, v3
	ldr	q9, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v3, v3, v9
	fmul.4s	v3, v2, v3
	ldr	q23, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v2, v3
	movi.4s	v17, #63, lsl #24
	fadd.4s	v3, v3, v17
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v1
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v9
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v23
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v17
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fmov.4s	v17, #1.00000000
	fadd.4s	v3, v4, v17
	sshr.4s	v4, v7, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v17
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v17
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v17
	fmul.4s	v2, v2, v21
	sub.4s	v4, v7, v4
	sub.4s	v1, v16, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v17
	fmov.4s	v7, #1.00000000
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v7
	fmul.4s	v2, v3, v2
	mov.16b	v17, v28
	fcmgt.4s	v3, v28, v22
	bic.16b	v2, v2, v3
	ldr	q28, [sp, #1488]                ; 16-byte Reload
	fcmgt.4s	v3, v17, v28
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v28, v30
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #656]                  ; 16-byte Spill
	fcmgt.4s	v1, v22, v30
	bsl.16b	v1, v4, v2
	stp	q22, q1, [sp, #560]             ; 32-byte Folded Spill
	ldr	q1, [sp, #720]                  ; 16-byte Reload
	ldr	q2, [sp, #1600]                 ; 16-byte Reload
	fsub.4s	v1, v1, v2
	and.16b	v9, v5, v1
	fcmge.4s	v1, v9, v17
	fcmge.4s	v2, v30, v9
	and.16b	v1, v1, v2
	ldr	q2, [sp, #736]                  ; 16-byte Reload
	fsub.4s	v2, v2, v15
	and.16b	v28, v0, v2
	fcmge.4s	v2, v28, v17
	fcmge.4s	v3, v30, v28
	and.16b	v2, v2, v3
	and.16b	v2, v2, v28
	ldr	q16, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v3, v2, v16
	movi.4s	v7, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v4, v20
	bsl.16b	v4, v7, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v9
	fmul.4s	v1, v4, v16
	bif.16b	v7, v1, v20
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v16, v3
	scvtf.4s	v3, v16
	fmul.4s	v20, v3, v29
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v29
	fsub.4s	v4, v4, v21
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v20, v20, v1
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v1
	fsub.4s	v2, v2, v3
	ldr	q21, [sp, #1648]                ; 16-byte Reload
	fmul.4s	v3, v2, v21
	fadd.4s	v3, v3, v10
	fmul.4s	v3, v2, v3
	ldr	q22, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v2, v3
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v3, v3, v1
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v2, v3
	movi.4s	v29, #63, lsl #24
	fadd.4s	v3, v3, v29
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v21
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v1
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v23
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v29
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fmov.4s	v22, #1.00000000
	fadd.4s	v3, v4, v22
	sshr.4s	v4, v7, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v22
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v22
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v22
	fmul.4s	v2, v2, v21
	sub.4s	v4, v7, v4
	sub.4s	v1, v16, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v22
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v22
	fmul.4s	v2, v3, v2
	mov.16b	v23, v17
	fcmgt.4s	v3, v17, v9
	bic.16b	v2, v2, v3
	fcmgt.4s	v3, v17, v28
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v28, v30
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	stp	q28, q1, [sp, #720]             ; 32-byte Folded Spill
	fcmgt.4s	v1, v9, v30
	bsl.16b	v1, v4, v2
	stp	q9, q1, [sp, #528]              ; 32-byte Folded Spill
	ldr	q1, [sp, #800]                  ; 16-byte Reload
	ldr	q9, [sp, #1600]                 ; 16-byte Reload
	fsub.4s	v1, v1, v9
	and.16b	v22, v5, v1
	fcmge.4s	v1, v22, v17
	fcmge.4s	v2, v30, v22
	and.16b	v1, v1, v2
	ldr	q2, [sp, #816]                  ; 16-byte Reload
	fsub.4s	v2, v2, v15
	and.16b	v10, v0, v2
	fcmge.4s	v2, v10, v17
	fcmge.4s	v3, v30, v10
	and.16b	v2, v2, v3
	and.16b	v2, v2, v10
	ldr	q16, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v3, v2, v16
	mvni.4s	v7, #128, lsl #24
	movi.4s	v20, #75, lsl #24
	mov.16b	v4, v7
	bsl.16b	v4, v20, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v22
	fmul.4s	v1, v4, v16
	bsl.16b	v7, v20, v1
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v16, v3
	scvtf.4s	v3, v16
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v20, v3, v1
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v1
	fsub.4s	v4, v4, v21
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v20, v20, v1
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v1
	fsub.4s	v2, v2, v3
	ldr	q29, [sp, #1648]                ; 16-byte Reload
	fmul.4s	v3, v2, v29
	ldr	q21, [sp, #1664]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	fmul.4s	v3, v2, v3
	ldr	q28, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v3, v3, v28
	fmul.4s	v3, v2, v3
	ldr	q15, [sp, #1632]                ; 16-byte Reload
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v3, v3, v1
	fmul.4s	v3, v2, v3
	movi.4s	v17, #63, lsl #24
	fadd.4s	v3, v3, v17
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v29
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v15
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v1
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v17
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fmov.4s	v17, #1.00000000
	fadd.4s	v3, v4, v17
	sshr.4s	v4, v7, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v17
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v17
	sshr.4s	v20, v16, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v17
	fmul.4s	v2, v2, v21
	sub.4s	v4, v7, v4
	sub.4s	v1, v16, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v17
	fmov.4s	v7, #1.00000000
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v7
	fmul.4s	v2, v3, v2
	mov.16b	v28, v23
	fcmgt.4s	v3, v23, v22
	bic.16b	v2, v2, v3
	fcmgt.4s	v3, v23, v10
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v10, v30
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	stp	q10, q1, [sp, #800]             ; 32-byte Folded Spill
	fcmgt.4s	v1, v22, v30
	bsl.16b	v1, v4, v2
	stp	q22, q1, [sp, #496]             ; 32-byte Folded Spill
	ldr	q1, [sp, #896]                  ; 16-byte Reload
	fsub.4s	v1, v1, v9
	and.16b	v23, v5, v1
	fcmge.4s	v1, v23, v28
	fcmge.4s	v2, v30, v23
	and.16b	v1, v1, v2
	ldr	q2, [sp, #912]                  ; 16-byte Reload
	ldr	q22, [sp, #1584]                ; 16-byte Reload
	fsub.4s	v2, v2, v22
	and.16b	v9, v0, v2
	fcmge.4s	v2, v9, v28
	fcmge.4s	v3, v30, v9
	and.16b	v2, v2, v3
	and.16b	v2, v2, v9
	ldr	q7, [sp, #2192]                 ; 16-byte Reload
	fmul.4s	v3, v2, v7
	movi.4s	v16, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v4, v20
	bsl.16b	v4, v16, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v23
	fmul.4s	v1, v4, v7
	mov.16b	v7, v20
	bsl.16b	v7, v16, v1
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	ldr	q16, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v20, v3, v16
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v16
	fsub.4s	v4, v4, v21
	ldr	q16, [sp, #2880]                ; 16-byte Reload
	fmul.4s	v20, v20, v16
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v16
	fsub.4s	v2, v2, v3
	fmul.4s	v3, v2, v29
	ldr	q10, [sp, #1664]                ; 16-byte Reload
	fadd.4s	v3, v3, v10
	fmul.4s	v3, v2, v3
	ldr	q16, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v3, v3, v16
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	ldr	q21, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	fmul.4s	v3, v2, v3
	movi.4s	v17, #63, lsl #24
	fadd.4s	v3, v3, v17
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v29
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v15
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v21
	mov.16b	v10, v21
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v17
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fmov.4s	v16, #1.00000000
	fadd.4s	v3, v4, v16
	sshr.4s	v4, v7, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v16
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v16
	sshr.4s	v20, v1, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v16
	fmul.4s	v2, v2, v21
	sub.4s	v4, v7, v4
	sub.4s	v1, v1, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v16
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v16
	fmul.4s	v2, v3, v2
	fcmgt.4s	v3, v28, v23
	bic.16b	v2, v2, v3
	fcmgt.4s	v3, v28, v9
	mov.16b	v29, v28
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v9, v30
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	stp	q9, q1, [sp, #896]              ; 32-byte Folded Spill
	fcmgt.4s	v1, v23, v30
	bsl.16b	v1, v4, v2
	stp	q23, q1, [sp, #464]             ; 32-byte Folded Spill
	ldr	q1, [sp, #976]                  ; 16-byte Reload
	fsub.4s	v1, v1, v22
	and.16b	v28, v0, v1
	fcmge.4s	v1, v28, v29
	fcmge.4s	v2, v30, v28
	and.16b	v1, v1, v2
	ldr	q2, [sp, #992]                  ; 16-byte Reload
	ldr	q9, [sp, #1600]                 ; 16-byte Reload
	fsub.4s	v2, v2, v9
	and.16b	v23, v5, v2
	fcmge.4s	v2, v23, v29
	fcmge.4s	v3, v30, v23
	and.16b	v2, v2, v3
	and.16b	v2, v2, v23
	ldr	q16, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v3, v2, v16
	movi.4s	v7, #75, lsl #24
	mvni.4s	v20, #128, lsl #24
	mov.16b	v4, v20
	bsl.16b	v4, v7, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v28
	fmul.4s	v1, v4, v16
	bif.16b	v7, v1, v20
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v17, v3
	scvtf.4s	v3, v17
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v20, v3, v1
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v16, v7
	scvtf.4s	v20, v16
	fmul.4s	v21, v20, v1
	fsub.4s	v4, v4, v21
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v20, v20, v1
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v1
	fsub.4s	v2, v2, v3
	ldr	q7, [sp, #1648]                 ; 16-byte Reload
	fmul.4s	v3, v2, v7
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v3, v3, v1
	fmul.4s	v3, v2, v3
	ldr	q22, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v3, v3, v22
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v10
	fmul.4s	v3, v2, v3
	movi.4s	v21, #63, lsl #24
	fadd.4s	v3, v3, v21
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v7
	fadd.4s	v20, v20, v1
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v22
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v15
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fmov.4s	v7, #1.00000000
	fadd.4s	v3, v4, v7
	sshr.4s	v4, v16, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v7
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v7
	sshr.4s	v20, v17, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v7
	fmul.4s	v2, v2, v21
	sub.4s	v4, v16, v4
	sub.4s	v1, v17, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v7
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v7
	fmul.4s	v2, v3, v2
	fcmgt.4s	v3, v29, v28
	bic.16b	v2, v2, v3
	fcmgt.4s	v3, v29, v23
	mov.16b	v17, v29
	bic.16b	v1, v1, v3
	mov.16b	v22, v30
	fcmgt.4s	v3, v23, v30
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	stp	q23, q1, [sp, #976]             ; 32-byte Folded Spill
	fcmgt.4s	v1, v28, v30
	bsl.16b	v1, v4, v2
	stp	q28, q1, [sp, #432]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1072]                 ; 16-byte Reload
	fsub.4s	v1, v1, v9
	and.16b	v9, v5, v1
	fcmge.4s	v1, v9, v29
	fcmge.4s	v2, v30, v9
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1088]                 ; 16-byte Reload
	ldr	q30, [sp, #1584]                ; 16-byte Reload
	fsub.4s	v2, v2, v30
	and.16b	v10, v0, v2
	fcmge.4s	v2, v10, v29
	fcmge.4s	v3, v22, v10
	and.16b	v2, v2, v3
	and.16b	v2, v2, v10
	ldr	q7, [sp, #2192]                 ; 16-byte Reload
	fmul.4s	v3, v2, v7
	mvni.4s	v20, #128, lsl #24
	movi.4s	v21, #75, lsl #24
	mov.16b	v4, v20
	bsl.16b	v4, v21, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v9
	fmul.4s	v1, v4, v7
	mov.16b	v7, v20
	bsl.16b	v7, v21, v1
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	ldr	q16, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v20, v3, v16
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v7, v7
	scvtf.4s	v20, v7
	fmul.4s	v21, v20, v16
	fsub.4s	v4, v4, v21
	ldr	q16, [sp, #2880]                ; 16-byte Reload
	fmul.4s	v20, v20, v16
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v16
	fsub.4s	v2, v2, v3
	ldr	q28, [sp, #1648]                ; 16-byte Reload
	fmul.4s	v3, v2, v28
	ldr	q29, [sp, #1664]                ; 16-byte Reload
	fadd.4s	v3, v3, v29
	fmul.4s	v3, v2, v3
	ldr	q21, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v3, v3, v21
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	ldr	q23, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v2, v3
	movi.4s	v16, #63, lsl #24
	fadd.4s	v3, v3, v16
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v28
	fadd.4s	v20, v20, v29
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v15
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v23
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v16
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fmov.4s	v23, #1.00000000
	fadd.4s	v3, v4, v23
	sshr.4s	v4, v7, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v23
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v23
	sshr.4s	v20, v1, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v23
	fmul.4s	v2, v2, v21
	sub.4s	v4, v7, v4
	sub.4s	v1, v1, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v23
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v23
	fmul.4s	v2, v3, v2
	mov.16b	v29, v17
	fcmgt.4s	v3, v17, v9
	bic.16b	v2, v2, v3
	str	q10, [sp, #1072]                ; 16-byte Spill
	fcmgt.4s	v3, v17, v10
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v10, v22
	ldr	q7, [sp, #2160]                 ; 16-byte Reload
	bit.16b	v1, v7, v3
	str	q1, [sp, #1088]                 ; 16-byte Spill
	fcmgt.4s	v1, v9, v22
	mov.16b	v23, v22
	bsl.16b	v1, v7, v2
	stp	q9, q1, [sp, #400]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1168]                 ; 16-byte Reload
	ldr	q22, [sp, #1600]                ; 16-byte Reload
	fsub.4s	v1, v1, v22
	and.16b	v9, v5, v1
	fcmge.4s	v1, v9, v17
	fcmge.4s	v2, v23, v9
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1184]                 ; 16-byte Reload
	fsub.4s	v2, v2, v30
	and.16b	v30, v0, v2
	fcmge.4s	v2, v30, v17
	fcmge.4s	v3, v23, v30
	and.16b	v2, v2, v3
	and.16b	v2, v2, v30
	ldr	q16, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v3, v2, v16
	mvni.4s	v7, #128, lsl #24
	movi.4s	v20, #75, lsl #24
	mov.16b	v4, v7
	bsl.16b	v4, v20, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v4, v1, v9
	fmul.4s	v1, v4, v16
	bsl.16b	v7, v20, v1
	fadd.4s	v1, v1, v7
	fsub.4s	v7, v1, v7
	fcvtzs.4s	v17, v3
	scvtf.4s	v3, v17
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v20, v3, v1
	fsub.4s	v2, v2, v20
	fcvtzs.4s	v16, v7
	scvtf.4s	v20, v16
	fmul.4s	v21, v20, v1
	fsub.4s	v4, v4, v21
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v20, v20, v1
	fsub.4s	v4, v4, v20
	fmul.4s	v3, v3, v1
	fsub.4s	v2, v2, v3
	mov.16b	v7, v28
	fmul.4s	v3, v2, v28
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v3, v3, v1
	fmul.4s	v3, v2, v3
	ldr	q10, [sp, #2176]                ; 16-byte Reload
	fadd.4s	v3, v3, v10
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	ldr	q28, [sp, #1888]                ; 16-byte Reload
	fadd.4s	v3, v3, v28
	fmul.4s	v3, v2, v3
	movi.4s	v21, #63, lsl #24
	fadd.4s	v3, v3, v21
	fmul.4s	v20, v2, v2
	fmul.4s	v3, v20, v3
	fmul.4s	v20, v4, v7
	fadd.4s	v20, v20, v1
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v10
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v15
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v4, v20
	fadd.4s	v20, v20, v21
	fmul.4s	v21, v4, v4
	fmul.4s	v20, v21, v20
	fadd.4s	v4, v4, v20
	fadd.4s	v2, v2, v3
	fmov.4s	v28, #1.00000000
	fadd.4s	v3, v4, v28
	sshr.4s	v4, v16, #1
	shl.4s	v20, v4, #23
	add.4s	v20, v20, v28
	fmul.4s	v3, v3, v20
	fadd.4s	v2, v2, v28
	sshr.4s	v20, v17, #1
	shl.4s	v21, v20, #23
	add.4s	v21, v21, v28
	fmul.4s	v2, v2, v21
	sub.4s	v4, v16, v4
	sub.4s	v1, v17, v20
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v28
	fmul.4s	v1, v2, v1
	shl.4s	v2, v4, #23
	add.4s	v2, v2, v28
	fmov.4s	v10, #1.00000000
	fmul.4s	v2, v3, v2
	mov.16b	v16, v29
	fcmgt.4s	v3, v29, v9
	bic.16b	v2, v2, v3
	fcmgt.4s	v3, v29, v30
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v30, v23
	ldr	q20, [sp, #2160]                ; 16-byte Reload
	bit.16b	v1, v20, v3
	stp	q30, q1, [sp, #368]             ; 32-byte Folded Spill
	fcmgt.4s	v1, v9, v23
	bsl.16b	v1, v20, v2
	stp	q9, q1, [sp, #336]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
	fsub.4s	v1, v1, v22
	and.16b	v9, v5, v1
	fcmge.4s	v1, v9, v29
	fcmge.4s	v2, v23, v9
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1568]                 ; 16-byte Reload
	ldr	q3, [sp, #1584]                 ; 16-byte Reload
	fsub.4s	v2, v2, v3
	and.16b	v29, v0, v2
	fcmge.4s	v2, v29, v16
	fcmge.4s	v3, v23, v29
	and.16b	v2, v2, v3
	and.16b	v2, v2, v29
	ldr	q22, [sp, #2192]                ; 16-byte Reload
	fmul.4s	v3, v2, v22
	movi.4s	v7, #75, lsl #24
	mvni.4s	v21, #128, lsl #24
	mov.16b	v4, v21
	bsl.16b	v4, v7, v3
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	and.16b	v1, v1, v9
	fmul.4s	v4, v1, v22
	bsl.16b	v21, v7, v4
	fadd.4s	v4, v4, v21
	fsub.4s	v4, v4, v21
	fcvtzs.4s	v3, v3
	scvtf.4s	v21, v3
	ldr	q7, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v22, v21, v7
	fsub.4s	v2, v2, v22
	fcvtzs.4s	v4, v4
	scvtf.4s	v22, v4
	fmul.4s	v28, v22, v7
	fsub.4s	v1, v1, v28
	ldr	q7, [sp, #2880]                 ; 16-byte Reload
	fmul.4s	v21, v21, v7
	fmul.4s	v22, v22, v7
	fsub.4s	v1, v1, v22
	fsub.4s	v2, v2, v21
	ldr	q7, [sp, #1648]                 ; 16-byte Reload
	fmul.4s	v21, v2, v7
	fmul.4s	v22, v1, v7
	ldr	q7, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v22, v22, v7
	fadd.4s	v21, v21, v7
	fmul.4s	v21, v2, v21
	fmul.4s	v22, v1, v22
	ldr	q7, [sp, #2176]                 ; 16-byte Reload
	fadd.4s	v22, v22, v7
	fadd.4s	v21, v21, v7
	fmul.4s	v21, v2, v21
	fmul.4s	v22, v1, v22
	fadd.4s	v22, v22, v15
	fadd.4s	v21, v21, v15
	fmul.4s	v21, v2, v21
	fmul.4s	v22, v1, v22
	ldr	q7, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v22, v22, v7
	fadd.4s	v21, v21, v7
	fmul.4s	v21, v2, v21
	movi.4s	v7, #63, lsl #24
	fadd.4s	v21, v21, v7
	fmul.4s	v28, v2, v2
	fmul.4s	v21, v28, v21
	fmul.4s	v22, v1, v22
	fadd.4s	v22, v22, v7
	fmul.4s	v28, v1, v1
	fmul.4s	v22, v28, v22
	fadd.4s	v1, v1, v22
	fadd.4s	v2, v2, v21
	fadd.4s	v1, v1, v10
	sshr.4s	v21, v4, #1
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v10
	fmul.4s	v1, v1, v22
	fadd.4s	v2, v2, v10
	sshr.4s	v22, v3, #1
	shl.4s	v28, v22, #23
	add.4s	v28, v28, v10
	fmul.4s	v2, v2, v28
	sub.4s	v4, v4, v21
	sub.4s	v3, v3, v22
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v10
	fmul.4s	v2, v2, v3
	shl.4s	v3, v4, #23
	add.4s	v3, v3, v10
	fmul.4s	v1, v1, v3
	fcmgt.4s	v3, v16, v9
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v16, v29
	bic.16b	v2, v2, v3
	fcmgt.4s	v3, v29, v23
	bit.16b	v2, v20, v3
	str	q2, [sp, #2880]                 ; 16-byte Spill
	fcmgt.4s	v2, v9, v23
	bit.16b	v1, v20, v2
	str	q1, [sp, #2192]                 ; 16-byte Spill
	sshll.2d	v1, v0, #0
Lloh42:
	adrp	x9, lCPI1_8@PAGE
Lloh43:
	ldr	q2, [x9, lCPI1_8@PAGEOFF]
	ldr	q3, [sp, #1408]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #1408]                 ; 16-byte Spill
	ldr	q1, [sp, #1264]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q20, [sp, #224]                 ; 16-byte Reload
	ldr	q2, [sp, #1280]                 ; 16-byte Reload
	mov.16b	v3, v1
	bsl.16b	v3, v2, v20
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1296]                 ; 16-byte Reload
	mov.16b	v15, v1
	bsl.16b	v15, v2, v20
	ldr	q1, [sp, #1200]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1232]                 ; 16-byte Reload
	mov.16b	v17, v1
	bsl.16b	v17, v2, v20
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1248]                 ; 16-byte Reload
	mov.16b	v4, v1
	bsl.16b	v4, v2, v20
	ldr	q1, [sp, #1104]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1120]                 ; 16-byte Reload
	mov.16b	v21, v1
	bsl.16b	v21, v2, v20
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1152]                 ; 16-byte Reload
	mov.16b	v22, v1
	bsl.16b	v22, v2, v20
	ldp	q1, q2, [sp, #1008]             ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	mov.16b	v16, v1
	bsl.16b	v16, v2, v20
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1056]                 ; 16-byte Reload
	bif.16b	v2, v20, v1
	ldp	q1, q7, [sp, #928]              ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	mov.16b	v28, v1
	bsl.16b	v28, v7, v20
	ldr	q1, [sp, #1536]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q7, [sp, #960]                  ; 16-byte Reload
	bif.16b	v7, v20, v1
	ldp	q1, q23, [sp, #832]             ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	mov.16b	v10, v1
	bsl.16b	v10, v23, v20
	ldp	q1, q23, [sp, #864]             ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	mov.16b	v30, v1
	bsl.16b	v30, v23, v20
	ldp	q1, q23, [sp, #752]             ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v23, v20
	str	q1, [sp, #1248]                 ; 16-byte Spill
	ldr	q1, [sp, #1520]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q23, [sp, #784]                 ; 16-byte Reload
	bsl.16b	v1, v23, v20
	str	q1, [sp, #1232]                 ; 16-byte Spill
	ldp	q1, q23, [sp, #672]             ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v23, v20
	str	q1, [sp, #1216]                 ; 16-byte Spill
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q23, [sp, #704]                 ; 16-byte Reload
	bsl.16b	v1, v23, v20
	str	q1, [sp, #1200]                 ; 16-byte Spill
	ldp	q1, q23, [sp, #592]             ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v23, v20
	str	q1, [sp, #1904]                 ; 16-byte Spill
	ldp	q1, q23, [sp, #624]             ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v23, v20
	str	q1, [sp, #1888]                 ; 16-byte Spill
	ldp	q1, q23, [sp, #560]             ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v23, v20
	str	q1, [sp, #2176]                 ; 16-byte Spill
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q23, [sp, #656]                 ; 16-byte Reload
	bsl.16b	v1, v23, v20
	str	q1, [sp, #2160]                 ; 16-byte Spill
	ldr	q1, [x2, #528]
	str	q15, [sp, #1648]                ; 16-byte Spill
	bit.16b	v1, v15, v0
	ldr	q15, [x2, #512]
	str	q3, [sp, #1664]                 ; 16-byte Spill
	bit.16b	v15, v3, v5
	stp	q15, q1, [x2, #512]
	ldr	d23, [sp, #1328]                ; 8-byte Reload
	zip1.8b	v1, v23, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	and.16b	v3, v1, v4
	zip2.8b	v4, v23, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v23, v4, v17
	ldp	q15, q17, [x2, #544]
	str	q23, [sp, #1536]                ; 16-byte Spill
	bit.16b	v17, v23, v0
	str	q3, [sp, #1632]                 ; 16-byte Spill
	bit.16b	v15, v3, v5
	stp	q15, q17, [x2, #544]
	ldr	q3, [sp, #528]                  ; 16-byte Reload
	fcmeq.4s	v17, v3, v3
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	mov.16b	v15, v17
	bsl.16b	v15, v3, v20
	and.16b	v3, v1, v22
	and.16b	v21, v4, v21
	ldr	q17, [x2, #592]
	str	q21, [sp, #1504]                ; 16-byte Spill
	bit.16b	v17, v21, v0
	ldr	q21, [x2, #576]
	str	q3, [sp, #1520]                 ; 16-byte Spill
	bit.16b	v21, v3, v5
	stp	q21, q17, [x2, #576]
	ldr	q3, [sp, #720]                  ; 16-byte Reload
	fcmeq.4s	v17, v3, v3
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	bsl.16b	v17, v3, v20
	and.16b	v21, v1, v2
	and.16b	v3, v4, v16
	ldr	q2, [x2, #624]
	str	q3, [sp, #1328]                 ; 16-byte Spill
	bit.16b	v2, v3, v0
	ldr	q3, [x2, #608]
	str	q21, [sp, #1488]                ; 16-byte Spill
	bit.16b	v3, v21, v5
	stp	q3, q2, [x2, #608]
	ldp	q2, q3, [sp, #496]              ; 32-byte Folded Reload
	fcmeq.4s	v2, v2, v2
	mov.16b	v21, v2
	bsl.16b	v21, v3, v20
	and.16b	v7, v1, v7
	and.16b	v3, v4, v28
	ldr	q2, [x2, #656]
	str	q3, [sp, #1296]                 ; 16-byte Spill
	bit.16b	v2, v3, v0
	ldr	q3, [x2, #640]
	str	q7, [sp, #1312]                 ; 16-byte Spill
	bit.16b	v3, v7, v5
	stp	q3, q2, [x2, #640]
	ldp	q2, q3, [sp, #800]              ; 32-byte Folded Reload
	fcmeq.4s	v2, v2, v2
	bsl.16b	v2, v3, v20
	and.16b	v16, v1, v30
	and.16b	v7, v4, v10
	ldr	q3, [x2, #688]
	str	q7, [sp, #1264]                 ; 16-byte Spill
	bit.16b	v3, v7, v0
	ldr	q7, [x2, #672]
	str	q16, [sp, #1280]                ; 16-byte Spill
	bit.16b	v7, v16, v5
	stp	q7, q3, [x2, #672]
	ldp	q3, q7, [sp, #464]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v7, v20
	ldr	q7, [sp, #1232]                 ; 16-byte Reload
	and.16b	v22, v1, v7
	ldr	q7, [sp, #1248]                 ; 16-byte Reload
	and.16b	v16, v4, v7
	ldr	q7, [x2, #720]
	str	q16, [sp, #1232]                ; 16-byte Spill
	bit.16b	v7, v16, v0
	ldr	q16, [x2, #704]
	str	q22, [sp, #1248]                ; 16-byte Spill
	bit.16b	v16, v22, v5
	stp	q16, q7, [x2, #704]
	ldp	q7, q16, [sp, #896]             ; 32-byte Folded Reload
	fcmeq.4s	v7, v7, v7
	bsl.16b	v7, v16, v20
	ldr	q16, [sp, #1200]                ; 16-byte Reload
	and.16b	v23, v1, v16
	ldr	q16, [sp, #1216]                ; 16-byte Reload
	and.16b	v22, v4, v16
	ldr	q16, [x2, #752]
	str	q22, [sp, #1200]                ; 16-byte Spill
	bit.16b	v16, v22, v0
	ldr	q22, [x2, #736]
	str	q23, [sp, #1216]                ; 16-byte Spill
	bit.16b	v22, v23, v5
	stp	q22, q16, [x2, #736]
	ldp	q16, q22, [sp, #432]            ; 32-byte Folded Reload
	fcmeq.4s	v16, v16, v16
	bsl.16b	v16, v22, v20
	ldr	q22, [sp, #1888]                ; 16-byte Reload
	and.16b	v23, v1, v22
	ldr	q22, [sp, #1904]                ; 16-byte Reload
	and.16b	v28, v4, v22
	ldr	q22, [x2, #784]
	str	q28, [sp, #1168]                ; 16-byte Spill
	bit.16b	v22, v28, v0
	ldr	q28, [x2, #768]
	str	q23, [sp, #1184]                ; 16-byte Spill
	bit.16b	v28, v23, v5
	stp	q28, q22, [x2, #768]
	ldp	q22, q23, [sp, #976]            ; 32-byte Folded Reload
	fcmeq.4s	v22, v22, v22
	bsl.16b	v22, v23, v20
	ldr	q23, [sp, #2160]                ; 16-byte Reload
	and.16b	v23, v4, v23
	ldr	q28, [sp, #2176]                ; 16-byte Reload
	and.16b	v30, v1, v28
	ldr	q28, [x2, #800]
	str	q30, [sp, #1136]                ; 16-byte Spill
	bit.16b	v28, v30, v5
	ldr	q30, [x2, #816]
	str	q23, [sp, #1152]                ; 16-byte Spill
	bit.16b	v30, v23, v0
	stp	q28, q30, [x2, #800]
	ldp	q30, q23, [sp, #400]            ; 32-byte Folded Reload
	fcmeq.4s	v28, v30, v30
	bsl.16b	v28, v23, v20
	and.16b	v10, v4, v17
	and.16b	v23, v1, v15
	ldp	q17, q30, [x2, #832]
	str	q23, [sp, #1120]                ; 16-byte Spill
	bit.16b	v17, v23, v5
	str	q10, [sp, #1104]                ; 16-byte Spill
	bit.16b	v30, v10, v0
	stp	q17, q30, [x2, #832]
	ldr	q17, [sp, #1072]                ; 16-byte Reload
	fcmeq.4s	v17, v17, v17
	ldr	q23, [sp, #1088]                ; 16-byte Reload
	bsl.16b	v17, v23, v20
	and.16b	v23, v4, v2
	and.16b	v21, v1, v21
	ldr	q2, [x2, #864]
	str	q21, [sp, #1072]                ; 16-byte Spill
	bit.16b	v2, v21, v5
	ldr	q21, [x2, #880]
	str	q23, [sp, #1088]                ; 16-byte Spill
	bit.16b	v21, v23, v0
	stp	q2, q21, [x2, #864]
	ldp	q2, q21, [sp, #336]             ; 32-byte Folded Reload
	fcmeq.4s	v2, v2, v2
	bsl.16b	v2, v21, v20
	and.16b	v21, v4, v7
	and.16b	v7, v1, v3
	ldr	q3, [x2, #896]
	str	q7, [sp, #1056]                 ; 16-byte Spill
	bit.16b	v3, v7, v5
	ldr	q7, [x2, #912]
	str	q21, [sp, #1040]                ; 16-byte Spill
	bit.16b	v7, v21, v0
	stp	q3, q7, [x2, #896]
	ldp	q3, q7, [sp, #368]              ; 32-byte Folded Reload
	fcmeq.4s	v3, v3, v3
	bsl.16b	v3, v7, v20
	and.16b	v21, v1, v22
	and.16b	v16, v4, v16
	ldr	q7, [x2, #944]
	stp	q16, q21, [sp, #1008]           ; 32-byte Folded Spill
	bit.16b	v7, v16, v0
	ldr	q16, [x2, #928]
	bit.16b	v16, v21, v5
	stp	q16, q7, [x2, #928]
	and.16b	v7, v4, v17
	and.16b	v3, v4, v3
	and.16b	v4, v1, v28
	and.16b	v16, v1, v2
	ldp	q1, q2, [x2, #960]
	stp	q4, q7, [sp, #960]              ; 32-byte Folded Spill
	bit.16b	v1, v4, v5
	bit.16b	v2, v7, v0
	stp	q1, q2, [x2, #960]
	ldp	q1, q2, [x2, #992]
	str	q16, [sp, #944]                 ; 16-byte Spill
	bit.16b	v1, v16, v5
	str	q3, [sp, #992]                  ; 16-byte Spill
	bit.16b	v2, v3, v0
	stp	q1, q2, [x2, #992]
	fcmeq.4s	v1, v9, v9
	ldr	q2, [sp, #2192]                 ; 16-byte Reload
	bsl.16b	v1, v2, v20
	str	q1, [sp, #1904]                 ; 16-byte Spill
	fcmeq.4s	v1, v29, v29
	ldr	q2, [sp, #2880]                 ; 16-byte Reload
	bsl.16b	v1, v2, v20
	str	q1, [sp, #1888]                 ; 16-byte Spill
	sshll2.2d	v3, v5, #0
Lloh44:
	adrp	x9, lCPI1_7@PAGE
Lloh45:
	ldr	q1, [x9, lCPI1_7@PAGEOFF]
	ldr	q2, [sp, #1424]                 ; 16-byte Reload
	str	q3, [sp, #928]                  ; 16-byte Spill
	bit.16b	v2, v1, v3
	str	q2, [sp, #1424]                 ; 16-byte Spill
Lloh46:
	adrp	x9, lCPI1_6@PAGE
Lloh47:
	ldr	q1, [x9, lCPI1_6@PAGEOFF]
	ldr	q2, [sp, #2032]                 ; 16-byte Reload
	ldr	q3, [sp, #1392]                 ; 16-byte Reload
	bit.16b	v3, v1, v2
	str	q3, [sp, #1392]                 ; 16-byte Spill
	sshll.2d	v1, v5, #0
	ldr	q2, [sp, #256]                  ; 16-byte Reload
	ldr	q21, [sp, #2000]                ; 16-byte Reload
	bit.16b	v21, v2, v1
	mov	w10, #12                        ; =0xc
	ldr	q23, [sp, #1344]                ; 16-byte Reload
	str	q21, [sp, #2000]                ; 16-byte Spill
	b	LBB1_456
LBB1_455:                               ; %direct.false586.i.i
                                        ;   in Loop: Header=BB1_456 Depth=3
	ldr	q21, [sp, #2000]                ; 16-byte Reload
	ldr	q4, [sp, #2880]                 ; 16-byte Reload
	orr.16b	v4, v4, v21
	fmov	x9, d4
	add	x9, x5, x9
	ldp	q4, q20, [x9]
	bit.16b	v20, v30, v0
	bit.16b	v4, v29, v5
	stp	q4, q20, [x9]
	ldr	q4, [sp, #2192]                 ; 16-byte Reload
	orr.16b	v4, v4, v21
	fmov	x9, d4
	add	x9, x5, x9
	ldp	q4, q20, [x9]
	bit.16b	v20, v28, v0
	bit.16b	v4, v17, v5
	stp	q4, q20, [x9]
	ldr	q4, [sp, #2176]                 ; 16-byte Reload
	orr.16b	v4, v4, v21
	fmov	x9, d4
	add	x9, x5, x9
	ldp	q4, q17, [x9]
	bif.16b	v7, v17, v0
	bif.16b	v3, v4, v5
	stp	q3, q7, [x9]
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	orr.16b	v3, v3, v21
	fmov	x9, d3
	add	x9, x5, x9
	ldp	q3, q4, [x9]
	bif.16b	v2, v4, v0
	bif.16b	v1, v3, v5
	stp	q1, q2, [x9]
	add	x7, x7, #1
	add	x10, x10, #16
	cmp	x7, #32
	b.eq	LBB1_522
LBB1_456:                               ; %direct.true557.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_458 Depth 4
	mov	x9, #0                          ; =0x0
	lsl	x11, x7, #7
	dup.2d	v1, x11
	ldr	q17, [sp, #1872]                ; 16-byte Reload
	str	q1, [sp, #2880]                 ; 16-byte Spill
	orr.16b	v1, v1, v17
	fmov	x11, d1
	add	x11, x15, x11
	ldp	q2, q1, [x11]
	ldr	q21, [sp, #1904]                ; 16-byte Reload
	fmul.4s	v2, v21, v2
	ldr	q22, [sp, #1888]                ; 16-byte Reload
	fmul.4s	v1, v22, v1
	mov	w11, #32                        ; =0x20
	bfi	x11, x7, #7, #57
	dup.2d	v3, x11
	str	q3, [sp, #2192]                 ; 16-byte Spill
	orr.16b	v3, v3, v17
	fmov	x11, d3
	add	x11, x15, x11
	ldp	q4, q3, [x11]
	fmul.4s	v4, v21, v4
	fmul.4s	v3, v22, v3
	mov	w11, #64                        ; =0x40
	bfi	x11, x7, #7, #57
	dup.2d	v7, x11
	str	q7, [sp, #2176]                 ; 16-byte Spill
	orr.16b	v7, v7, v17
	fmov	x11, d7
	add	x11, x15, x11
	ldp	q16, q7, [x11]
	fmul.4s	v16, v21, v16
	fmul.4s	v7, v22, v7
	mov	w11, #96                        ; =0x60
	bfi	x11, x7, #7, #57
	dup.2d	v20, x11
	str	q20, [sp, #2160]                ; 16-byte Spill
	orr.16b	v17, v20, v17
	fmov	x11, d17
	add	x11, x15, x11
	ldp	q20, q17, [x11]
	fmul.4s	v20, v21, v20
	fmul.4s	v17, v22, v17
	bit.16b	v6, v1, v0
	bit.16b	v18, v2, v5
	bit.16b	v19, v3, v0
	bit.16b	v14, v4, v5
	bit.16b	v13, v7, v0
	bit.16b	v12, v16, v5
	bit.16b	v11, v17, v0
	bit.16b	v8, v20, v5
	mov	x30, x10
	b	LBB1_458
LBB1_457:                               ; %else1513
                                        ;   in Loop: Header=BB1_458 Depth=4
	and.16b	v1, v0, v29
	and.16b	v22, v5, v28
	fmul.4s	v17, v1, v10
	fmul.4s	v28, v22, v9
	fadd.4s	v29, v18, v28
	fadd.4s	v30, v6, v17
	fmul.4s	v2, v1, v2
	fmul.4s	v3, v22, v3
	fadd.4s	v17, v14, v3
	fadd.4s	v28, v19, v2
	fmul.4s	v2, v1, v20
	fmul.4s	v3, v22, v7
	fadd.4s	v3, v12, v3
	fadd.4s	v7, v13, v2
	fmul.4s	v20, v22, v21
	fmul.4s	v1, v1, v4
	fadd.4s	v2, v11, v1
	fadd.4s	v1, v8, v20
	bit.16b	v6, v30, v0
	bit.16b	v18, v29, v5
	bit.16b	v19, v28, v0
	bit.16b	v14, v17, v5
	bit.16b	v13, v7, v0
	bit.16b	v12, v3, v5
	bit.16b	v8, v1, v5
	bit.16b	v11, v2, v0
	add	x9, x9, #32
	add	x30, x30, #512
	cmp	x9, #512
	b.eq	LBB1_455
LBB1_458:                               ; %direct.true585.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ;       Parent Loop BB1_456 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	uzp1.8h	v1, v5, v0
	ldr	q2, [sp, #2944]                 ; 16-byte Reload
	and.16b	v1, v1, v2
	addv.8h	h16, v1
	fmov	w11, s16
	add	x22, x4, x9
	ldp	q28, q29, [x22]
	sub	x22, x30, #12
	dup.2d	v1, x22
	orr.16b	v2, v1, v25
	ldr	q3, [sp, #2976]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	tbnz	w11, #0, LBB1_492
; %bb.459:                              ; %else1324
                                        ;   in Loop: Header=BB1_458 Depth=4
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_493
LBB1_460:                               ; %else1330
                                        ;   in Loop: Header=BB1_458 Depth=4
	orr.16b	v2, v1, v26
	add.2d	v2, v23, v2
	tbnz	w11, #2, LBB1_494
LBB1_461:                               ; %else1336
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbnz	w11, #3, LBB1_495
LBB1_462:                               ; %else1342
                                        ;   in Loop: Header=BB1_458 Depth=4
	orr.16b	v2, v1, v27
	ldr	q3, [sp, #2960]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w11, #4, LBB1_496
LBB1_463:                               ; %else1348
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbnz	w11, #5, LBB1_497
LBB1_464:                               ; %else1354
                                        ;   in Loop: Header=BB1_458 Depth=4
	orr.16b	v1, v1, v31
	add.2d	v1, v24, v1
	tbnz	w11, #6, LBB1_498
LBB1_465:                               ; %else1360
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbz	w11, #7, LBB1_467
LBB1_466:                               ; %cond.load1362
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x11, v1[1]
	ld1.s	{ v10 }[3], [x11]
LBB1_467:                               ; %else1366
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	w11, s16
	sub	x22, x30, #8
	dup.2d	v4, x22
	ldr	q1, [sp, #2976]                 ; 16-byte Reload
	add.2d	v21, v1, v25
	add.2d	v1, v21, v4
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w11, #0, LBB1_499
; %bb.468:                              ; %else1373
                                        ;   in Loop: Header=BB1_458 Depth=4
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_500
LBB1_469:                               ; %else1379
                                        ;   in Loop: Header=BB1_458 Depth=4
	add.2d	v30, v23, v26
	add.2d	v1, v30, v4
	tbnz	w11, #2, LBB1_501
LBB1_470:                               ; %else1385
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbnz	w11, #3, LBB1_502
LBB1_471:                               ; %else1391
                                        ;   in Loop: Header=BB1_458 Depth=4
	ldr	q1, [sp, #2960]                 ; 16-byte Reload
	add.2d	v1, v1, v27
	add.2d	v7, v1, v4
	tbnz	w11, #4, LBB1_503
LBB1_472:                               ; %else1397
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbnz	w11, #5, LBB1_504
LBB1_473:                               ; %else1403
                                        ;   in Loop: Header=BB1_458 Depth=4
	add.2d	v17, v24, v31
	add.2d	v4, v17, v4
	tbnz	w11, #6, LBB1_505
LBB1_474:                               ; %else1409
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbz	w11, #7, LBB1_476
LBB1_475:                               ; %cond.load1411
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x11, v4[1]
	ld1.s	{ v2 }[3], [x11]
LBB1_476:                               ; %else1415
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	w11, s16
	sub	x22, x30, #4
	dup.2d	v4, x22
	add.2d	v15, v21, v4
	movi.2d	v7, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbnz	w11, #0, LBB1_506
; %bb.477:                              ; %else1422
                                        ;   in Loop: Header=BB1_458 Depth=4
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_507
LBB1_478:                               ; %else1428
                                        ;   in Loop: Header=BB1_458 Depth=4
	add.2d	v22, v30, v4
	tbnz	w11, #2, LBB1_508
LBB1_479:                               ; %else1434
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbnz	w11, #3, LBB1_509
LBB1_480:                               ; %else1440
                                        ;   in Loop: Header=BB1_458 Depth=4
	add.2d	v22, v1, v4
	tbnz	w11, #4, LBB1_510
LBB1_481:                               ; %else1446
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbnz	w11, #5, LBB1_511
LBB1_482:                               ; %else1452
                                        ;   in Loop: Header=BB1_458 Depth=4
	add.2d	v4, v17, v4
	tbnz	w11, #6, LBB1_512
LBB1_483:                               ; %else1458
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbnz	w11, #7, LBB1_513
LBB1_484:                               ; %else1464
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	w11, s16
	dup.2d	v15, x30
	add.2d	v22, v21, v15
	movi.2d	v21, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w11, #0, LBB1_514
LBB1_485:                               ; %else1471
                                        ;   in Loop: Header=BB1_458 Depth=4
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_515
LBB1_486:                               ; %else1477
                                        ;   in Loop: Header=BB1_458 Depth=4
	add.2d	v22, v30, v15
	tbnz	w11, #2, LBB1_516
LBB1_487:                               ; %else1483
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbnz	w11, #3, LBB1_517
LBB1_488:                               ; %else1489
                                        ;   in Loop: Header=BB1_458 Depth=4
	add.2d	v1, v1, v15
	tbnz	w11, #4, LBB1_518
LBB1_489:                               ; %else1495
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbnz	w11, #5, LBB1_519
LBB1_490:                               ; %else1501
                                        ;   in Loop: Header=BB1_458 Depth=4
	add.2d	v1, v17, v15
	tbnz	w11, #6, LBB1_520
LBB1_491:                               ; %else1507
                                        ;   in Loop: Header=BB1_458 Depth=4
	tbz	w11, #7, LBB1_457
	b	LBB1_521
LBB1_492:                               ; %cond.load1320
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d2
	ldr	s9, [x22]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_460
LBB1_493:                               ; %cond.load1326
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v2[1]
	ld1.s	{ v9 }[1], [x22]
	orr.16b	v2, v1, v26
	add.2d	v2, v23, v2
	tbz	w11, #2, LBB1_461
LBB1_494:                               ; %cond.load1332
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d2
	ld1.s	{ v9 }[2], [x22]
	tbz	w11, #3, LBB1_462
LBB1_495:                               ; %cond.load1338
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v2[1]
	ld1.s	{ v9 }[3], [x22]
	orr.16b	v2, v1, v27
	ldr	q3, [sp, #2960]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w11, #4, LBB1_463
LBB1_496:                               ; %cond.load1344
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d2
	ld1.s	{ v10 }[0], [x22]
	tbz	w11, #5, LBB1_464
LBB1_497:                               ; %cond.load1350
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v2[1]
	ld1.s	{ v10 }[1], [x22]
	orr.16b	v1, v1, v31
	add.2d	v1, v24, v1
	tbz	w11, #6, LBB1_465
LBB1_498:                               ; %cond.load1356
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d1
	ld1.s	{ v10 }[2], [x22]
	tbnz	w11, #7, LBB1_466
	b	LBB1_467
LBB1_499:                               ; %cond.load1369
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d1
	ldr	s3, [x22]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_469
LBB1_500:                               ; %cond.load1375
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v1[1]
	ld1.s	{ v3 }[1], [x22]
	add.2d	v30, v23, v26
	add.2d	v1, v30, v4
	tbz	w11, #2, LBB1_470
LBB1_501:                               ; %cond.load1381
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d1
	ld1.s	{ v3 }[2], [x22]
	tbz	w11, #3, LBB1_471
LBB1_502:                               ; %cond.load1387
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v1[1]
	ld1.s	{ v3 }[3], [x22]
	ldr	q1, [sp, #2960]                 ; 16-byte Reload
	add.2d	v1, v1, v27
	add.2d	v7, v1, v4
	tbz	w11, #4, LBB1_472
LBB1_503:                               ; %cond.load1393
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d7
	ld1.s	{ v2 }[0], [x22]
	tbz	w11, #5, LBB1_473
LBB1_504:                               ; %cond.load1399
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v7[1]
	ld1.s	{ v2 }[1], [x22]
	add.2d	v17, v24, v31
	add.2d	v4, v17, v4
	tbz	w11, #6, LBB1_474
LBB1_505:                               ; %cond.load1405
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d4
	ld1.s	{ v2 }[2], [x22]
	tbnz	w11, #7, LBB1_475
	b	LBB1_476
LBB1_506:                               ; %cond.load1418
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d15
	ldr	s7, [x22]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_478
LBB1_507:                               ; %cond.load1424
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v15[1]
	ld1.s	{ v7 }[1], [x22]
	add.2d	v22, v30, v4
	tbz	w11, #2, LBB1_479
LBB1_508:                               ; %cond.load1430
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d22
	ld1.s	{ v7 }[2], [x22]
	tbz	w11, #3, LBB1_480
LBB1_509:                               ; %cond.load1436
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v22[1]
	ld1.s	{ v7 }[3], [x22]
	add.2d	v22, v1, v4
	tbz	w11, #4, LBB1_481
LBB1_510:                               ; %cond.load1442
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d22
	ld1.s	{ v20 }[0], [x22]
	tbz	w11, #5, LBB1_482
LBB1_511:                               ; %cond.load1448
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v22[1]
	ld1.s	{ v20 }[1], [x22]
	add.2d	v4, v17, v4
	tbz	w11, #6, LBB1_483
LBB1_512:                               ; %cond.load1454
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d4
	ld1.s	{ v20 }[2], [x22]
	tbz	w11, #7, LBB1_484
LBB1_513:                               ; %cond.load1460
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x11, v4[1]
	ld1.s	{ v20 }[3], [x11]
	fmov	w11, s16
	dup.2d	v15, x30
	add.2d	v22, v21, v15
	movi.2d	v21, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w11, #0, LBB1_485
LBB1_514:                               ; %cond.load1467
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d22
	ldr	s21, [x22]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_486
LBB1_515:                               ; %cond.load1473
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v22[1]
	ld1.s	{ v21 }[1], [x22]
	add.2d	v22, v30, v15
	tbz	w11, #2, LBB1_487
LBB1_516:                               ; %cond.load1479
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d22
	ld1.s	{ v21 }[2], [x22]
	tbz	w11, #3, LBB1_488
LBB1_517:                               ; %cond.load1485
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v22[1]
	ld1.s	{ v21 }[3], [x22]
	add.2d	v1, v1, v15
	tbz	w11, #4, LBB1_489
LBB1_518:                               ; %cond.load1491
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d1
	ld1.s	{ v4 }[0], [x22]
	tbz	w11, #5, LBB1_490
LBB1_519:                               ; %cond.load1497
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x22, v1[1]
	ld1.s	{ v4 }[1], [x22]
	add.2d	v1, v17, v15
	tbz	w11, #6, LBB1_491
LBB1_520:                               ; %cond.load1503
                                        ;   in Loop: Header=BB1_458 Depth=4
	fmov	x22, d1
	ld1.s	{ v4 }[2], [x22]
	tbz	w11, #7, LBB1_457
LBB1_521:                               ; %cond.load1509
                                        ;   in Loop: Header=BB1_458 Depth=4
	mov.d	x11, v1[1]
	ld1.s	{ v4 }[3], [x11]
	b	LBB1_457
LBB1_522:                               ; %direct.true644.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q7, [sp, #1872]                 ; 16-byte Reload
LBB1_523:                               ; %direct.true644.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d1, x9
	orr.16b	v2, v1, v21
	fmov	x10, d2
	add	x10, x5, x10
	ldp	q2, q3, [x10]
	orr.16b	v1, v1, v7
	fmov	x10, d1
	add	x10, x3, x10
	ldp	q1, q4, [x10]
	bif.16b	v3, v4, v0
	bit.16b	v1, v2, v5
	stp	q1, q3, [x10]
	add	x9, x9, #32
	cmp	x9, #1, lsl #12                 ; =4096
	b.ne	LBB1_523
; %bb.524:                              ; %direct.true660.i.i.preheader
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, x15
	mov	w10, #128                       ; =0x80
	ldr	q15, [sp, #1616]                ; 16-byte Reload
	ldr	q20, [sp, #1968]                ; 16-byte Reload
	ldr	q9, [sp, #1936]                 ; 16-byte Reload
	ldr	q10, [sp, #1920]                ; 16-byte Reload
	ldr	q29, [sp, #2848]                ; 16-byte Reload
	ldr	q30, [sp, #2208]                ; 16-byte Reload
LBB1_525:                               ; %direct.true660.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q1, [x9, #4096]
	ldr	q2, [x9, #4112]
	ldp	q3, q4, [x9]
	bif.16b	v2, v4, v0
	bif.16b	v1, v3, v5
	stp	q1, q2, [x9], #32
	subs	x10, x10, #1
	b.ne	LBB1_525
; %bb.526:                              ; %direct.false661.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	bit.16b	v1, v2, v0
	str	q1, [sp, #1568]                 ; 16-byte Spill
	ldr	q1, [sp, #1552]                 ; 16-byte Reload
	ldr	q2, [sp, #1600]                 ; 16-byte Reload
	bit.16b	v1, v2, v5
	str	q1, [sp, #1552]                 ; 16-byte Spill
	movi.2d	v2, #0000000000000000
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v1, v1, v3
	ldr	q3, [sp, #1648]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1536]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q3, [sp, #1504]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1520]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1488]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1328]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1296]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1312]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1280]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1264]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1248]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1216]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1200]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1168]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1184]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1136]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1152]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1104]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1120]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1072]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1088]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1040]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1056]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldp	q3, q4, [sp, #1008]             ; 32-byte Folded Reload
	fadd.4s	v1, v4, v1
	fadd.4s	v2, v3, v2
	ldp	q3, q4, [sp, #960]              ; 32-byte Folded Reload
	fadd.4s	v2, v4, v2
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #944]                  ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #992]                  ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q7, [sp, #1456]                 ; 16-byte Reload
	ldr	q3, [sp, #1904]                 ; 16-byte Reload
	fmul.4s	v3, v7, v3
	ldr	q17, [sp, #1440]                ; 16-byte Reload
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fmul.4s	v4, v17, v4
	fadd.4s	v2, v4, v2
	fadd.4s	v1, v3, v1
	bit.16b	v7, v1, v5
	str	q7, [sp, #1456]                 ; 16-byte Spill
	bit.16b	v17, v2, v0
	str	q17, [sp, #1440]                ; 16-byte Spill
	add	x6, x6, #1
	cmp	x6, #513
	ldr	q17, [sp, #1952]                ; 16-byte Reload
	b.ne	LBB1_40
	b	LBB1_562
LBB1_527:                               ; %direct.schedule.7.i.i
                                        ;   in Loop: Header=BB1_40 Depth=2
	mov	x9, #0                          ; =0x0
	mov	x10, #0                         ; =0x0
	sshll.2d	v3, v15, #0
	sshll.2d	v16, v0, #0
	ldr	q17, [sp, #1472]                ; 16-byte Reload
	ldr	q20, [sp, #2032]                ; 16-byte Reload
	bit.16b	v24, v17, v20
	ldr	q21, [sp, #2016]                ; 16-byte Reload
	bit.16b	v23, v17, v21
	ldr	q22, [sp, #2960]                ; 16-byte Reload
	bit.16b	v22, v17, v16
	str	q22, [sp, #2960]                ; 16-byte Spill
	ldr	q22, [sp, #2976]                ; 16-byte Reload
	bit.16b	v22, v17, v3
	str	q22, [sp, #2976]                ; 16-byte Spill
	bit.16b	v31, v4, v20
	bit.16b	v26, v5, v21
	bit.16b	v27, v1, v16
	bit.16b	v25, v7, v3
	b	LBB1_529
LBB1_528:                               ; %else323
                                        ;   in Loop: Header=BB1_529 Depth=3
	str	q17, [sp, #1680]                ; 16-byte Spill
	str	q16, [sp, #1696]                ; 16-byte Spill
	str	q4, [sp, #1712]                 ; 16-byte Spill
	str	q7, [sp, #1728]                 ; 16-byte Spill
	add	x10, x10, #1
	add	x9, x9, #4
	cmp	x10, #2048
	b.eq	LBB1_124
LBB1_529:                               ; %direct.true679.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_40 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v1, v15, #0
	sshll.2d	v3, v0, #0
	and	x11, x10, #0x7f
	lsr	x7, x10, #7
	orr	x22, x7, #0x2000
	dup.2d	v4, x22
	ldr	q5, [sp, #1792]                 ; 16-byte Reload
	add.2d	v5, v4, v5
	ldr	q7, [sp, #1776]                 ; 16-byte Reload
	add.2d	v7, v4, v7
	ldr	q16, [sp, #1760]                ; 16-byte Reload
	add.2d	v16, v4, v16
	ldr	q17, [sp, #1744]                ; 16-byte Reload
	add.2d	v4, v4, v17
	shl.2d	v4, v4, #7
	shl.2d	v16, v16, #7
	shl.2d	v7, v7, #7
	shl.2d	v5, v5, #7
	dup.2d	v17, x11
	orr.16b	v5, v5, v17
	orr.16b	v7, v7, v17
	orr.16b	v16, v16, v17
	orr.16b	v4, v4, v17
	ldr	q17, [sp, #2032]                ; 16-byte Reload
	ldr	q20, [sp, #2048]                ; 16-byte Reload
	bit.16b	v20, v4, v17
	str	q20, [sp, #2048]                ; 16-byte Spill
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v4, v16, v3
	str	q4, [sp, #2064]                 ; 16-byte Spill
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	ldr	q17, [sp, #1680]                ; 16-byte Reload
	bit.16b	v17, v7, v3
	ldr	q16, [sp, #1696]                ; 16-byte Reload
	bit.16b	v16, v5, v1
	movi.2d	v3, #0000000000000000
	movi.2d	v1, #0000000000000000
	ldr	q7, [sp, #1728]                 ; 16-byte Reload
	cbnz	x7, LBB1_539
; %bb.530:                              ; %direct.true692.i.i
                                        ;   in Loop: Header=BB1_529 Depth=3
	fmov	w11, s2
	shl.2d	v1, v16, #2
	dup.2d	v4, x0
	add.2d	v5, v4, v1
	movi.2d	v1, #0000000000000000
	tbnz	w11, #0, LBB1_555
; %bb.531:                              ; %else1520
                                        ;   in Loop: Header=BB1_529 Depth=3
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_556
LBB1_532:                               ; %else1526
                                        ;   in Loop: Header=BB1_529 Depth=3
	shl.2d	v5, v17, #2
	add.2d	v5, v4, v5
	tbnz	w11, #2, LBB1_557
LBB1_533:                               ; %else1532
                                        ;   in Loop: Header=BB1_529 Depth=3
	tbnz	w11, #3, LBB1_558
LBB1_534:                               ; %else1538
                                        ;   in Loop: Header=BB1_529 Depth=3
	ldr	q5, [sp, #2064]                 ; 16-byte Reload
	shl.2d	v5, v5, #2
	add.2d	v5, v4, v5
	tbnz	w11, #4, LBB1_559
LBB1_535:                               ; %else1544
                                        ;   in Loop: Header=BB1_529 Depth=3
	tbnz	w11, #5, LBB1_560
LBB1_536:                               ; %else1550
                                        ;   in Loop: Header=BB1_529 Depth=3
	ldr	q5, [sp, #2048]                 ; 16-byte Reload
	shl.2d	v5, v5, #2
	add.2d	v4, v4, v5
	tbnz	w11, #6, LBB1_561
LBB1_537:                               ; %else1556
                                        ;   in Loop: Header=BB1_529 Depth=3
	tbz	w11, #7, LBB1_539
LBB1_538:                               ; %cond.load1558
                                        ;   in Loop: Header=BB1_529 Depth=3
	mov.d	x11, v4[1]
	ld1.s	{ v1 }[3], [x11]
LBB1_539:                               ; %direct.schedule.44.i.i
                                        ;   in Loop: Header=BB1_529 Depth=3
	fmov	w11, s2
	bit.16b	v7, v3, v15
	dup.2d	v3, x9
	orr.16b	v4, v3, v25
	ldr	q5, [sp, #2976]                 ; 16-byte Reload
	add.2d	v4, v5, v4
	tbnz	w11, #0, LBB1_547
; %bb.540:                              ; %else
                                        ;   in Loop: Header=BB1_529 Depth=3
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB1_548
LBB1_541:                               ; %else311
                                        ;   in Loop: Header=BB1_529 Depth=3
	orr.16b	v4, v3, v26
	add.2d	v4, v23, v4
	tbnz	w11, #2, LBB1_549
LBB1_542:                               ; %else313
                                        ;   in Loop: Header=BB1_529 Depth=3
	tbnz	w11, #3, LBB1_550
LBB1_543:                               ; %else315
                                        ;   in Loop: Header=BB1_529 Depth=3
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	bit.16b	v4, v1, v0
	orr.16b	v1, v3, v27
	ldr	q5, [sp, #2960]                 ; 16-byte Reload
	add.2d	v1, v5, v1
	tbnz	w11, #4, LBB1_551
LBB1_544:                               ; %else317
                                        ;   in Loop: Header=BB1_529 Depth=3
	tbnz	w11, #5, LBB1_552
LBB1_545:                               ; %else319
                                        ;   in Loop: Header=BB1_529 Depth=3
	orr.16b	v1, v3, v31
	add.2d	v1, v24, v1
	tbnz	w11, #6, LBB1_553
LBB1_546:                               ; %else321
                                        ;   in Loop: Header=BB1_529 Depth=3
	tbz	w11, #7, LBB1_528
	b	LBB1_554
LBB1_547:                               ; %cond.store
                                        ;   in Loop: Header=BB1_529 Depth=3
	fmov	x7, d4
	str	s7, [x7]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_541
LBB1_548:                               ; %cond.store310
                                        ;   in Loop: Header=BB1_529 Depth=3
	mov.d	x7, v4[1]
	st1.s	{ v7 }[1], [x7]
	orr.16b	v4, v3, v26
	add.2d	v4, v23, v4
	tbz	w11, #2, LBB1_542
LBB1_549:                               ; %cond.store312
                                        ;   in Loop: Header=BB1_529 Depth=3
	fmov	x7, d4
	st1.s	{ v7 }[2], [x7]
	tbz	w11, #3, LBB1_543
LBB1_550:                               ; %cond.store314
                                        ;   in Loop: Header=BB1_529 Depth=3
	mov.d	x7, v4[1]
	st1.s	{ v7 }[3], [x7]
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	bit.16b	v4, v1, v0
	orr.16b	v1, v3, v27
	ldr	q5, [sp, #2960]                 ; 16-byte Reload
	add.2d	v1, v5, v1
	tbz	w11, #4, LBB1_544
LBB1_551:                               ; %cond.store316
                                        ;   in Loop: Header=BB1_529 Depth=3
	fmov	x7, d1
	str	s4, [x7]
	tbz	w11, #5, LBB1_545
LBB1_552:                               ; %cond.store318
                                        ;   in Loop: Header=BB1_529 Depth=3
	mov.d	x7, v1[1]
	st1.s	{ v4 }[1], [x7]
	orr.16b	v1, v3, v31
	add.2d	v1, v24, v1
	tbz	w11, #6, LBB1_546
LBB1_553:                               ; %cond.store320
                                        ;   in Loop: Header=BB1_529 Depth=3
	fmov	x7, d1
	st1.s	{ v4 }[2], [x7]
	tbz	w11, #7, LBB1_528
LBB1_554:                               ; %cond.store322
                                        ;   in Loop: Header=BB1_529 Depth=3
	mov.d	x11, v1[1]
	st1.s	{ v4 }[3], [x11]
	b	LBB1_528
LBB1_555:                               ; %cond.load1516
                                        ;   in Loop: Header=BB1_529 Depth=3
	fmov	x7, d5
	ldr	s3, [x7]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB1_532
LBB1_556:                               ; %cond.load1522
                                        ;   in Loop: Header=BB1_529 Depth=3
	mov.d	x7, v5[1]
	ld1.s	{ v3 }[1], [x7]
	shl.2d	v5, v17, #2
	add.2d	v5, v4, v5
	tbz	w11, #2, LBB1_533
LBB1_557:                               ; %cond.load1528
                                        ;   in Loop: Header=BB1_529 Depth=3
	fmov	x7, d5
	ld1.s	{ v3 }[2], [x7]
	tbz	w11, #3, LBB1_534
LBB1_558:                               ; %cond.load1534
                                        ;   in Loop: Header=BB1_529 Depth=3
	mov.d	x7, v5[1]
	ld1.s	{ v3 }[3], [x7]
	ldr	q5, [sp, #2064]                 ; 16-byte Reload
	shl.2d	v5, v5, #2
	add.2d	v5, v4, v5
	tbz	w11, #4, LBB1_535
LBB1_559:                               ; %cond.load1540
                                        ;   in Loop: Header=BB1_529 Depth=3
	fmov	x7, d5
	ld1.s	{ v1 }[0], [x7]
	tbz	w11, #5, LBB1_536
LBB1_560:                               ; %cond.load1546
                                        ;   in Loop: Header=BB1_529 Depth=3
	mov.d	x7, v5[1]
	ld1.s	{ v1 }[1], [x7]
	ldr	q5, [sp, #2048]                 ; 16-byte Reload
	shl.2d	v5, v5, #2
	add.2d	v4, v4, v5
	tbz	w11, #6, LBB1_537
LBB1_561:                               ; %cond.load1552
                                        ;   in Loop: Header=BB1_529 Depth=3
	fmov	x7, d4
	ld1.s	{ v1 }[2], [x7]
	tbnz	w11, #7, LBB1_538
	b	LBB1_539
LBB1_562:                               ; %direct.schedule.51.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	sshll.2d	v4, v5, #0
	sshll.2d	v3, v0, #0
	ldr	q1, [sp, #128]                  ; 16-byte Reload
	ldr	q2, [sp, #928]                  ; 16-byte Reload
	and.16b	v1, v2, v1
	ldr	q2, [sp, #80]                   ; 16-byte Reload
	ldr	q6, [sp, #2032]                 ; 16-byte Reload
	and.16b	v2, v6, v2
	ldr	q6, [sp, #96]                   ; 16-byte Reload
	and.16b	v3, v3, v6
	ldr	q6, [sp, #144]                  ; 16-byte Reload
	and.16b	v4, v4, v6
	ldr	x11, [sp, #120]                 ; 8-byte Reload
	ldr	q21, [sp, #1456]                ; 16-byte Reload
	ldr	q22, [sp, #1440]                ; 16-byte Reload
	b	LBB1_564
LBB1_563:                               ; %else1645
                                        ;   in Loop: Header=BB1_564 Depth=2
	add	x8, x8, #1
	cmp	x8, #128
	b.eq	LBB1_2
LBB1_564:                               ; %direct.true725.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s16
	dup.2d	v6, x8
	add.2d	v7, v6, v4
	add	x10, x15, x8, lsl #5
	ldp	q18, q17, [x10]
	and.16b	v18, v5, v18
	fdiv.4s	v18, v18, v21
	shl.2d	v19, v7, #2
	dup.2d	v7, x11
	add.2d	v19, v7, v19
	tbnz	w9, #0, LBB1_572
; %bb.565:                              ; %else1617
                                        ;   in Loop: Header=BB1_564 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_573
LBB1_566:                               ; %else1621
                                        ;   in Loop: Header=BB1_564 Depth=2
	add.2d	v19, v6, v1
	shl.2d	v19, v19, #2
	add.2d	v19, v7, v19
	tbnz	w9, #2, LBB1_574
LBB1_567:                               ; %else1625
                                        ;   in Loop: Header=BB1_564 Depth=2
	tbnz	w9, #3, LBB1_575
LBB1_568:                               ; %else1629
                                        ;   in Loop: Header=BB1_564 Depth=2
	add.2d	v18, v6, v3
	and.16b	v17, v0, v17
	fdiv.4s	v17, v17, v22
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbnz	w9, #4, LBB1_576
LBB1_569:                               ; %else1633
                                        ;   in Loop: Header=BB1_564 Depth=2
	tbnz	w9, #5, LBB1_577
LBB1_570:                               ; %else1637
                                        ;   in Loop: Header=BB1_564 Depth=2
	add.2d	v6, v6, v2
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbnz	w9, #6, LBB1_578
LBB1_571:                               ; %else1641
                                        ;   in Loop: Header=BB1_564 Depth=2
	tbz	w9, #7, LBB1_563
	b	LBB1_579
LBB1_572:                               ; %cond.store1614
                                        ;   in Loop: Header=BB1_564 Depth=2
	fmov	x10, d19
	str	s18, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_566
LBB1_573:                               ; %cond.store1618
                                        ;   in Loop: Header=BB1_564 Depth=2
	mov.d	x10, v19[1]
	st1.s	{ v18 }[1], [x10]
	add.2d	v19, v6, v1
	shl.2d	v19, v19, #2
	add.2d	v19, v7, v19
	tbz	w9, #2, LBB1_567
LBB1_574:                               ; %cond.store1622
                                        ;   in Loop: Header=BB1_564 Depth=2
	fmov	x10, d19
	st1.s	{ v18 }[2], [x10]
	tbz	w9, #3, LBB1_568
LBB1_575:                               ; %cond.store1626
                                        ;   in Loop: Header=BB1_564 Depth=2
	mov.d	x10, v19[1]
	st1.s	{ v18 }[3], [x10]
	add.2d	v18, v6, v3
	and.16b	v17, v0, v17
	fdiv.4s	v17, v17, v22
	shl.2d	v18, v18, #2
	add.2d	v18, v7, v18
	tbz	w9, #4, LBB1_569
LBB1_576:                               ; %cond.store1630
                                        ;   in Loop: Header=BB1_564 Depth=2
	fmov	x10, d18
	str	s17, [x10]
	tbz	w9, #5, LBB1_570
LBB1_577:                               ; %cond.store1634
                                        ;   in Loop: Header=BB1_564 Depth=2
	mov.d	x10, v18[1]
	st1.s	{ v17 }[1], [x10]
	add.2d	v6, v6, v2
	shl.2d	v6, v6, #2
	add.2d	v6, v7, v6
	tbz	w9, #6, LBB1_571
LBB1_578:                               ; %cond.store1638
                                        ;   in Loop: Header=BB1_564 Depth=2
	fmov	x10, d6
	st1.s	{ v17 }[2], [x10]
	tbz	w9, #7, LBB1_563
LBB1_579:                               ; %cond.store1642
                                        ;   in Loop: Header=BB1_564 Depth=2
	mov.d	x9, v6[1]
	st1.s	{ v17 }[3], [x9]
	b	LBB1_563
LBB1_580:                               ; %block.batch.exit
	add	sp, sp, #3024
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpAdrp	Lloh38, Lloh40
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
                                        ; -- End function
.subsections_via_symbols

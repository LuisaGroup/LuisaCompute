; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 1024, i64 2048, i64 3072, i64 4096, i64 5120, i64 6144, i64 7168>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 8192
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 20480
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 32768
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 2048, i64 4096, i64 6144, i64 8192, i64 10240, i64 12288, i64 14336>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 49152
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 3072, i64 6144, i64 9216, i64 12288, i64 15360, i64 18432, i64 21504>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 73728
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 77824
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 16, i64 32, i64 48, i64 64, i64 80, i64 96, i64 112>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 77952
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 78976
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 79488
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 128, i64 256, i64 384, i64 512, i64 640, i64 768, i64 896>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 80512
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %33 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace41 = load ptr, ptr %33, align 8
  %tile_snapshot.private42 = getelementptr inbounds i8, ptr %private.workspace41, i64 84608
  %.splatinsert43 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private42, i64 0
  %.splat44 = shufflevector <8 x ptr> %.splatinsert43, <8 x ptr> poison, <8 x i32> zeroinitializer
  %34 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat44, 0
  %35 = insertvalue { <8 x ptr>, <8 x i64> } %34, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %36 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace45 = load ptr, ptr %36, align 8
  %tile_snapshot.private46 = getelementptr inbounds i8, ptr %private.workspace45, i64 84864
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %37 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %38 = insertvalue { <8 x ptr>, <8 x i64> } %37, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %39 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace49 = load ptr, ptr %39, align 8
  %tile_snapshot.private50 = getelementptr inbounds i8, ptr %private.workspace49, i64 85120
  %.splatinsert51 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private50, i64 0
  %.splat52 = shufflevector <8 x ptr> %.splatinsert51, <8 x ptr> poison, <8 x i32> zeroinitializer
  %40 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat52, 0
  %41 = insertvalue { <8 x ptr>, <8 x i64> } %40, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %42 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace53 = load ptr, ptr %42, align 8
  %tile_snapshot.private54 = getelementptr inbounds i8, ptr %private.workspace53, i64 89216
  %.splatinsert55 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private54, i64 0
  %.splat56 = shufflevector <8 x ptr> %.splatinsert55, <8 x ptr> poison, <8 x i32> zeroinitializer
  %43 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat56, 0
  %44 = insertvalue { <8 x ptr>, <8 x i64> } %43, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %45 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace57 = load ptr, ptr %45, align 8
  %tile_snapshot.private58 = getelementptr inbounds i8, ptr %private.workspace57, i64 101504
  %.splatinsert59 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private58, i64 0
  %.splat60 = shufflevector <8 x ptr> %.splatinsert59, <8 x ptr> poison, <8 x i32> zeroinitializer
  %46 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat60, 0
  %47 = insertvalue { <8 x ptr>, <8 x i64> } %46, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill61 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill61, align 64
  %.spill62 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill62, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill63 = alloca i64, align 8
  store i64 0, ptr %.spill63, align 4
  %.spill64 = alloca i64, align 8
  store i64 0, ptr %.spill64, align 4
  %tile_snapshot.spill65 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill65, align 64
  %tile_snapshot.spill66 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill66, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot67 = alloca i64, align 8
  store i64 0, ptr %.slot67, align 4
  %.slot68 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot68, align 32
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot70, align 32
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot72, align 32
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot74, align 32
  %.slot75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot75, align 32
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.slot80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot80, align 32
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.slot83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot83, align 32
  %.spill84 = alloca i64, align 8
  store i64 0, ptr %.spill84, align 4
  %tile_snapshot.spill85 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill85, align 64
  %.spill86 = alloca i1, align 1
  store i1 false, ptr %.spill86, align 1
  %tile_snapshot.spill87 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill87, align 64
  %tile_snapshot.spill88 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill88, align 64
  %.slot89 = alloca i64, align 8
  store i64 0, ptr %.slot89, align 4
  %.spill90 = alloca i64, align 8
  store i64 0, ptr %.spill90, align 4
  %.slot91 = alloca i64, align 8
  store i64 0, ptr %.slot91, align 4
  %tile_snapshot.spill92 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill92, align 64
  %tile_snapshot.spill93 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill93, align 64
  %tile_snapshot.spill94 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill94, align 64
  %tile_snapshot.spill95 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill95, align 64
  %.slot96 = alloca i64, align 8
  store i64 0, ptr %.slot96, align 4
  %tile_snapshot.spill97 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill97, align 64
  %.slot98 = alloca i64, align 8
  store i64 0, ptr %.slot98, align 4
  %.slot99 = alloca i64, align 8
  store i64 0, ptr %.slot99, align 4
  %.slot100 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot100, align 32
  %.slot101 = alloca i64, align 8
  store i64 0, ptr %.slot101, align 4
  %.slot102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot102, align 32
  %.slot103 = alloca i64, align 8
  store i64 0, ptr %.slot103, align 4
  %.slot104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot104, align 32
  %.slot105 = alloca i64, align 8
  store i64 0, ptr %.slot105, align 4
  %.slot106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot106, align 32
  %.slot107 = alloca i64, align 8
  store i64 0, ptr %.slot107, align 4
  %.slot108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot108, align 32
  %.slot109 = alloca i64, align 8
  store i64 0, ptr %.slot109, align 4
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %.slot111 = alloca i64, align 8
  store i64 0, ptr %.slot111, align 4
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.slot113 = alloca i64, align 8
  store i64 0, ptr %.slot113, align 4
  %.slot114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot114, align 32
  %.spill115 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill115, align 32
  %.spill116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill116, align 32
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.spill118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill118, align 32
  %.spill119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill119, align 32
  %.spill120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill120, align 32
  %.spill121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill121, align 32
  %.spill122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill122, align 32
  %tile_snapshot.spill123 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill123, align 64
  %.spill124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill124, align 32
  %.spill125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill125, align 32
  %.spill126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill126, align 32
  %.spill127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill127, align 32
  %.spill128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill128, align 32
  %.spill129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %.spill131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill131, align 32
  %tile_snapshot.spill132 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill132, align 64
  %tile_snapshot.spill133 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill133, align 64
  %.slot134 = alloca i64, align 8
  store i64 0, ptr %.slot134, align 4
  %.spill135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill135, align 32
  %.spill136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill136, align 32
  %.spill137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill137, align 32
  %.spill138 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill138, align 32
  %.spill139 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill139, align 32
  %.spill140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill141, align 32
  %.spill142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill142, align 32
  %.slot143 = alloca i64, align 8
  store i64 0, ptr %.slot143, align 4
  %.slot144 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot144, align 32
  %.slot145 = alloca i64, align 8
  store i64 0, ptr %.slot145, align 4
  %.slot146 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot146, align 32
  %.slot147 = alloca i64, align 8
  store i64 0, ptr %.slot147, align 4
  %.slot148 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot148, align 32
  %.slot149 = alloca i64, align 8
  store i64 0, ptr %.slot149, align 4
  %.slot150 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot150, align 32
  %.slot151 = alloca i64, align 8
  store i64 0, ptr %.slot151, align 4
  %.slot152 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot152, align 32
  %.slot153 = alloca i64, align 8
  store i64 0, ptr %.slot153, align 4
  %.slot154 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot154, align 32
  %.slot155 = alloca i64, align 8
  store i64 0, ptr %.slot155, align 4
  %.slot156 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot156, align 32
  %.slot157 = alloca i64, align 8
  store i64 0, ptr %.slot157, align 4
  %.slot158 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot158, align 32
  %.spill159 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill159, align 32
  %.spill160 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill160, align 32
  %.spill161 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill161, align 32
  %.spill162 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill162, align 32
  %.spill163 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill163, align 32
  %.spill164 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill164, align 32
  %.spill165 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill165, align 32
  %.spill166 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill166, align 32
  %tile_snapshot.spill167 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill167, align 64
  %.slot168 = alloca i64, align 8
  store i64 0, ptr %.slot168, align 4
  %.spill169 = alloca i64, align 8
  store i64 0, ptr %.spill169, align 4
  %.slot170 = alloca i64, align 8
  store i64 0, ptr %.slot170, align 4
  %.slot171 = alloca i64, align 8
  store i64 0, ptr %.slot171, align 4
  %.slot172 = alloca i64, align 8
  store i64 0, ptr %.slot172, align 4
  %.slot173 = alloca i64, align 8
  store i64 0, ptr %.slot173, align 4
  %.spill174 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill174, align 64
  %.slot175 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot175, align 32
  %.slot176 = alloca i64, align 8
  store i64 0, ptr %.slot176, align 4
  %.spill177 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill177, align 64
  %.slot178 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot178, align 32
  %tile_snapshot.spill179 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill179, align 64
  %.slot180 = alloca i64, align 8
  store i64 0, ptr %.slot180, align 4
  %48 = getelementptr i8, ptr %argument_buffer, i64 0
  %49 = load ptr, ptr %48, align 16
  %50 = getelementptr i8, ptr %48, i64 8
  %51 = load i64, ptr %50, align 8
  %52 = insertvalue { ptr, i64 } poison, ptr %49, 0
  %53 = insertvalue { ptr, i64 } %52, i64 %51, 1
  %54 = getelementptr i8, ptr %argument_buffer, i64 16
  %55 = load ptr, ptr %54, align 16
  %56 = getelementptr i8, ptr %54, i64 8
  %57 = load i64, ptr %56, align 8
  %58 = insertvalue { ptr, i64 } poison, ptr %55, 0
  %59 = insertvalue { ptr, i64 } %58, i64 %57, 1
  %60 = getelementptr i8, ptr %argument_buffer, i64 32
  %61 = load ptr, ptr %60, align 16
  %62 = getelementptr i8, ptr %60, i64 8
  %63 = load i64, ptr %62, align 8
  %64 = insertvalue { ptr, i64 } poison, ptr %61, 0
  %65 = insertvalue { ptr, i64 } %64, i64 %63, 1
  %66 = getelementptr i8, ptr %argument_buffer, i64 48
  %67 = load ptr, ptr %66, align 16
  %68 = getelementptr i8, ptr %66, i64 8
  %69 = load i64, ptr %68, align 8
  %70 = insertvalue { ptr, i64 } poison, ptr %67, 0
  %71 = insertvalue { ptr, i64 } %70, i64 %69, 1
  %72 = load i32, ptr %launch_config, align 4
  %73 = getelementptr i8, ptr %launch_config, i64 12
  %74 = load i32, ptr %73, align 4
  %75 = getelementptr i8, ptr %launch_config, i64 4
  %76 = load i32, ptr %75, align 4
  %77 = getelementptr i8, ptr %launch_config, i64 16
  %78 = load i32, ptr %77, align 4
  %79 = getelementptr i8, ptr %launch_config, i64 8
  %80 = load i32, ptr %79, align 4
  %81 = getelementptr i8, ptr %launch_config, i64 20
  %82 = load i32, ptr %81, align 4
  %83 = getelementptr i8, ptr %launch_config, i64 36
  %84 = load i32, ptr %83, align 4
  %.splatinsert181 = insertelement <8 x i32> poison, i32 %84, i64 0
  %.splat182 = shufflevector <8 x i32> %.splatinsert181, <8 x i32> poison, <8 x i32> zeroinitializer
  %85 = add <8 x i32> %.splat182, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %86 = mul i32 %72, 32
  %.splatinsert183 = insertelement <8 x i32> poison, i32 %86, i64 0
  %.splat184 = shufflevector <8 x i32> %.splatinsert183, <8 x i32> poison, <8 x i32> zeroinitializer
  %87 = add <8 x i32> %.splat184, %85
  %88 = mul i32 %76, 1
  %.splatinsert185 = insertelement <8 x i32> poison, i32 %88, i64 0
  %.splat186 = shufflevector <8 x i32> %.splatinsert185, <8 x i32> poison, <8 x i32> zeroinitializer
  %89 = add <8 x i32> %.splat186, zeroinitializer
  %90 = mul i32 %80, 1
  %.splatinsert187 = insertelement <8 x i32> poison, i32 %90, i64 0
  %.splat188 = shufflevector <8 x i32> %.splatinsert187, <8 x i32> poison, <8 x i32> zeroinitializer
  %91 = add <8 x i32> %.splat188, zeroinitializer
  %92 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %87, 0
  %93 = insertvalue [3 x <8 x i32>] %92, <8 x i32> %89, 1
  %94 = insertvalue [3 x <8 x i32>] %93, <8 x i32> %91, 2
  %.splatinsert189 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat190 = shufflevector <8 x i32> %.splatinsert189, <8 x i32> poison, <8 x i32> zeroinitializer
  %95 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat190
  %96 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  br i1 %96, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %97 = extractvalue [3 x <8 x i32>] %94, 0
  %98 = zext <8 x i32> %97 to <8 x i64>
  %99 = select <8 x i1> %95, <8 x i64> %98, <8 x i64> zeroinitializer
  %100 = select <8 x i1> %95, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %101 = sdiv <8 x i64> %99, %100
  %102 = load <8 x i64>, ptr %.spill, align 64
  %103 = select <8 x i1> %95, <8 x i64> %101, <8 x i64> %102
  store <8 x i64> %103, ptr %.spill, align 64
  %104 = select <8 x i1> %95, <8 x i64> %98, <8 x i64> zeroinitializer
  %105 = select <8 x i1> %95, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %106 = sdiv <8 x i64> %104, %105
  %107 = select <8 x i1> %95, <8 x i64> %106, <8 x i64> zeroinitializer
  %108 = select <8 x i1> %95, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %109 = srem <8 x i64> %107, %108
  %110 = mul <8 x i64> %109, splat (i64 8)
  %111 = load <8 x i64>, ptr %.spill61, align 64
  %112 = select <8 x i1> %95, <8 x i64> %110, <8 x i64> %111
  store <8 x i64> %112, ptr %.spill61, align 64
  %113 = select <8 x i1> %95, <8 x i64> %101, <8 x i64> zeroinitializer
  %114 = select <8 x i1> %95, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %115 = sdiv <8 x i64> %113, %114
  %116 = load <8 x i64>, ptr %.spill62, align 64
  %117 = select <8 x i1> %95, <8 x i64> %115, <8 x i64> %116
  store <8 x i64> %117, ptr %.spill62, align 64
  %118 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %119 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %120 = extractvalue { <8 x ptr>, <8 x i64> } %118, 0
  %121 = select <8 x i1> %95, <8 x ptr> %119, <8 x ptr> %120
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %118, 1
  %124 = select <8 x i1> %95, <8 x i64> %122, <8 x i64> %123
  %125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %121, 0
  %126 = insertvalue { <8 x ptr>, <8 x i64> } %125, <8 x i64> %124, 1
  store { <8 x ptr>, <8 x i64> } %126, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.spill63, align 4
  store i64 0, ptr %.spill64, align 4
  %127 = add <8 x i64> zeroinitializer, %101
  %128 = mul <8 x i64> %127, splat (i64 64)
  %129 = add <8 x i64> %128, %110
  %130 = mul <8 x i64> %129, splat (i64 32)
  %131 = add <8 x i64> %130, zeroinitializer
  %132 = extractvalue { ptr, i64 } %53, 0
  %133 = extractelement <8 x i1> %95, i64 0
  br i1 %133, label %copy.active, label %copy.continue

direct.schedule.1:                                ; preds = %direct.schedule.2, %copy.continue204
  %.state = load i64, ptr %.slot, align 4
  %134 = icmp slt i64 %.state, 384
  br i1 %134, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state205 = load i64, ptr %.slot, align 4
  %.splatinsert206 = insertelement <8 x i64> poison, i64 %.state205, i64 0
  %.splat207 = shufflevector <8 x i64> %.splatinsert206, <8 x i64> poison, <8 x i32> zeroinitializer
  %137 = mul <8 x i64> %.splat207, splat (i64 32)
  %138 = add <8 x i64> %136, %137
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %135, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %143 = extractelement <8 x ptr> %141, i32 0
  %144 = extractelement <8 x i64> %142, i32 0
  %145 = sub i64 %144, 0
  %146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %147 = select i1 %146, i64 %145, i64 0
  %private.contiguous.address = getelementptr i8, ptr %143, i64 %147
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %148 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %148, ptr %private.contiguous.address, align 4
  %.state208 = load i64, ptr %.slot, align 4
  %149 = add i64 %.state208, 1
  store i64 %149, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store i64 0, ptr %.slot67, align 4
  %150 = load <8 x float>, ptr %.slot68, align 32
  %151 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %150
  store <8 x float> %151, ptr %.slot68, align 32
  %152 = load <8 x float>, ptr %.slot69, align 32
  %153 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %152
  store <8 x float> %153, ptr %.slot69, align 32
  %154 = load <8 x float>, ptr %.slot70, align 32
  %155 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %154
  store <8 x float> %155, ptr %.slot70, align 32
  %156 = load <8 x float>, ptr %.slot71, align 32
  %157 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %156
  store <8 x float> %157, ptr %.slot71, align 32
  %158 = load <8 x float>, ptr %.slot72, align 32
  %159 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %158
  store <8 x float> %159, ptr %.slot72, align 32
  %160 = load <8 x float>, ptr %.slot73, align 32
  %161 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %160
  store <8 x float> %161, ptr %.slot73, align 32
  %162 = load <8 x float>, ptr %.slot74, align 32
  %163 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %162
  store <8 x float> %163, ptr %.slot74, align 32
  %164 = load <8 x float>, ptr %.slot75, align 32
  %165 = select <8 x i1> %95, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %164
  store <8 x float> %165, ptr %.slot75, align 32
  %166 = load <8 x float>, ptr %.slot76, align 32
  %167 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %166
  store <8 x float> %167, ptr %.slot76, align 32
  %168 = load <8 x float>, ptr %.slot77, align 32
  %169 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %168
  store <8 x float> %169, ptr %.slot77, align 32
  %170 = load <8 x float>, ptr %.slot78, align 32
  %171 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %170
  store <8 x float> %171, ptr %.slot78, align 32
  %172 = load <8 x float>, ptr %.slot79, align 32
  %173 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %172
  store <8 x float> %173, ptr %.slot79, align 32
  %174 = load <8 x float>, ptr %.slot80, align 32
  %175 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %174
  store <8 x float> %175, ptr %.slot80, align 32
  %176 = load <8 x float>, ptr %.slot81, align 32
  %177 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %176
  store <8 x float> %177, ptr %.slot81, align 32
  %178 = load <8 x float>, ptr %.slot82, align 32
  %179 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %178
  store <8 x float> %179, ptr %.slot82, align 32
  %180 = load <8 x float>, ptr %.slot83, align 32
  %181 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %180
  store <8 x float> %181, ptr %.slot83, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.84, %direct.schedule.3
  %.state209 = load i64, ptr %.slot67, align 4
  %182 = icmp slt i64 %.state209, 9
  br i1 %182, label %direct.true210, label %direct.false211

direct.schedule.5:                                ; preds = %direct.true210
  %.state212 = load i64, ptr %.slot67, align 4
  %183 = sdiv i64 %.state212, 1
  %184 = mul i64 %183, 16
  store i64 %184, ptr %.spill84, align 4
  %185 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %185, 0
  %188 = select <8 x i1> %95, <8 x ptr> %186, <8 x ptr> %187
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %185, 1
  %191 = select <8 x i1> %95, <8 x i64> %189, <8 x i64> %190
  %192 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %188, 0
  %193 = insertvalue { <8 x ptr>, <8 x i64> } %192, <8 x i64> %191, 1
  store { <8 x ptr>, <8 x i64> } %193, ptr %tile_snapshot.spill85, align 64
  %194 = icmp sge i64 %184, 0
  %195 = and i1 true, %194
  %196 = icmp sle i64 %184, 113
  %197 = and i1 %195, %196
  store i1 %197, ptr %.spill86, align 1
  br i1 %197, label %direct.true213, label %direct.false214

direct.schedule.6:                                ; preds = %direct.true213
  %.spill.load = load i64, ptr %.spill64, align 4
  %198 = mul i64 %.spill.load, 2
  %.splatinsert215 = insertelement <8 x i64> poison, i64 %198, i64 0
  %.splat216 = shufflevector <8 x i64> %.splatinsert215, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load217 = load <8 x i64>, ptr %.spill62, align 64
  %199 = add <8 x i64> %.splat216, %.spill.load217
  %200 = mul <8 x i64> %199, splat (i64 129)
  %.spill.load218 = load i64, ptr %.spill84, align 4
  %.splatinsert219 = insertelement <8 x i64> poison, i64 %.spill.load218, i64 0
  %.splat220 = shufflevector <8 x i64> %.splatinsert219, <8 x i64> poison, <8 x i32> zeroinitializer
  %201 = add <8 x i64> %200, %.splat220
  %202 = mul <8 x i64> %201, splat (i64 32)
  %203 = add <8 x i64> %202, zeroinitializer
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %204 = extractvalue { ptr, i64 } %59, 0
  %205 = extractelement <8 x i1> %95, i64 0
  br i1 %205, label %copy.active222, label %copy.continue223

direct.schedule.7:                                ; preds = %direct.false1574, %copy.continue237
  %206 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %206, 0
  %209 = select <8 x i1> %95, <8 x ptr> %207, <8 x ptr> %208
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %206, 1
  %212 = select <8 x i1> %95, <8 x i64> %210, <8 x i64> %211
  %213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %209, 0
  %214 = insertvalue { <8 x ptr>, <8 x i64> } %213, <8 x i64> %212, 1
  store { <8 x ptr>, <8 x i64> } %214, ptr %tile_snapshot.spill87, align 64
  %.spill.load238 = load i1, ptr %.spill86, align 1
  br i1 %.spill.load238, label %direct.true239, label %direct.false240

direct.schedule.8:                                ; preds = %direct.true239
  %.spill.load241 = load i64, ptr %.spill64, align 4
  %215 = mul i64 %.spill.load241, 2
  %.splatinsert242 = insertelement <8 x i64> poison, i64 %215, i64 0
  %.splat243 = shufflevector <8 x i64> %.splatinsert242, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load244 = load <8 x i64>, ptr %.spill62, align 64
  %216 = add <8 x i64> %.splat243, %.spill.load244
  %217 = mul <8 x i64> %216, splat (i64 129)
  %.spill.load245 = load i64, ptr %.spill84, align 4
  %.splatinsert246 = insertelement <8 x i64> poison, i64 %.spill.load245, i64 0
  %.splat247 = shufflevector <8 x i64> %.splatinsert246, <8 x i64> poison, <8 x i32> zeroinitializer
  %218 = add <8 x i64> %217, %.splat247
  %219 = mul <8 x i64> %218, splat (i64 48)
  %220 = add <8 x i64> %219, zeroinitializer
  %tile_snapshot.spill.load248 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %221 = extractvalue { ptr, i64 } %65, 0
  %222 = extractelement <8 x i1> %95, i64 0
  br i1 %222, label %copy.active249, label %copy.continue250

direct.schedule.9:                                ; preds = %direct.false1549, %copy.continue264
  %223 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %223, 0
  %226 = select <8 x i1> %95, <8 x ptr> %224, <8 x ptr> %225
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %223, 1
  %229 = select <8 x i1> %95, <8 x i64> %227, <8 x i64> %228
  %230 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %226, 0
  %231 = insertvalue { <8 x ptr>, <8 x i64> } %230, <8 x i64> %229, 1
  store { <8 x ptr>, <8 x i64> } %231, ptr %tile_snapshot.spill88, align 64
  store i64 0, ptr %.slot89, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.14, %direct.schedule.9
  %.state265 = load i64, ptr %.slot89, align 4
  %232 = icmp slt i64 %.state265, 4
  br i1 %232, label %direct.true266, label %direct.false267

direct.schedule.11:                               ; preds = %direct.true266
  %.state268 = load i64, ptr %.slot89, align 4
  %233 = mul i64 %.state268, 2
  store i64 %233, ptr %.spill90, align 4
  store i64 0, ptr %.slot91, align 4
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.13, %direct.schedule.11
  %.state269 = load i64, ptr %.slot91, align 4
  %234 = icmp slt i64 %.state269, 8
  br i1 %234, label %direct.true270, label %direct.false271

direct.schedule.13:                               ; preds = %direct.true270
  %.state272 = load i64, ptr %.slot91, align 4
  %235 = mul i64 %.state272, 2
  %.spill.load273 = load i64, ptr %.spill90, align 4
  %236 = add i64 0, %.spill.load273
  %237 = mul i64 %236, 16
  %238 = add i64 %237, %235
  %239 = add i64 %238, 0
  %240 = srem i64 %239, 16
  %241 = sdiv i64 %239, 16
  %242 = add i64 %238, 1
  %243 = srem i64 %242, 16
  %244 = add i64 %238, 16
  %245 = sdiv i64 %244, 16
  %246 = add i64 %238, 17
  %247 = add i64 0, %241
  %248 = mul i64 %247, 32
  %249 = add i64 %248, 0
  %tile_snapshot.spill.load274 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 0
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 1
  %.splatinsert275 = insertelement <8 x i64> poison, i64 %249, i64 0
  %.splat276 = shufflevector <8 x i64> %.splatinsert275, <8 x i64> poison, <8 x i32> zeroinitializer
  %252 = mul <8 x i64> %.splat276, splat (i64 4)
  %253 = add <8 x i64> %251, %252
  %254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %250, 0
  %255 = insertvalue { <8 x ptr>, <8 x i64> } %254, <8 x i64> %253, 1
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %255, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %255, 1
  %258 = getelementptr i8, <8 x ptr> %256, <8 x i64> %257
  %259 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %258, <8 x i1> %95, <8 x float> zeroinitializer)
  %260 = add i64 0, %245
  %261 = mul i64 %260, 32
  %262 = add i64 %261, 0
  %tile_snapshot.spill.load277 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 0
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 1
  %.splatinsert278 = insertelement <8 x i64> poison, i64 %262, i64 0
  %.splat279 = shufflevector <8 x i64> %.splatinsert278, <8 x i64> poison, <8 x i32> zeroinitializer
  %265 = mul <8 x i64> %.splat279, splat (i64 4)
  %266 = add <8 x i64> %264, %265
  %267 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %263, 0
  %268 = insertvalue { <8 x ptr>, <8 x i64> } %267, <8 x i64> %266, 1
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %268, 0
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %268, 1
  %271 = getelementptr i8, <8 x ptr> %269, <8 x i64> %270
  %272 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %271, <8 x i1> %95, <8 x float> zeroinitializer)
  %273 = add i64 0, %240
  %274 = mul i64 %273, 32
  %275 = add i64 %274, 0
  %tile_snapshot.spill.load280 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %.splatinsert281 = insertelement <8 x i64> poison, i64 %275, i64 0
  %.splat282 = shufflevector <8 x i64> %.splatinsert281, <8 x i64> poison, <8 x i32> zeroinitializer
  %278 = mul <8 x i64> %.splat282, splat (i64 4)
  %279 = add <8 x i64> %277, %278
  %280 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %276, 0
  %281 = insertvalue { <8 x ptr>, <8 x i64> } %280, <8 x i64> %279, 1
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %281, 0
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %281, 1
  %284 = getelementptr i8, <8 x ptr> %282, <8 x i64> %283
  %285 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %284, <8 x i1> %95, <8 x float> zeroinitializer)
  %286 = add i64 0, %243
  %287 = mul i64 %286, 32
  %288 = add i64 %287, 0
  %tile_snapshot.spill.load283 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 1
  %.splatinsert284 = insertelement <8 x i64> poison, i64 %288, i64 0
  %.splat285 = shufflevector <8 x i64> %.splatinsert284, <8 x i64> poison, <8 x i32> zeroinitializer
  %291 = mul <8 x i64> %.splat285, splat (i64 4)
  %292 = add <8 x i64> %290, %291
  %293 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %289, 0
  %294 = insertvalue { <8 x ptr>, <8 x i64> } %293, <8 x i64> %292, 1
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %294, 0
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %294, 1
  %297 = getelementptr i8, <8 x ptr> %295, <8 x i64> %296
  %298 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %297, <8 x i1> %95, <8 x float> zeroinitializer)
  %299 = fmul <8 x float> %259, %285
  %300 = fadd <8 x float> zeroinitializer, %299
  %301 = fmul <8 x float> %259, %298
  %302 = fadd <8 x float> zeroinitializer, %301
  %303 = fmul <8 x float> %272, %285
  %304 = fadd <8 x float> zeroinitializer, %303
  %305 = fmul <8 x float> %272, %298
  %306 = fadd <8 x float> zeroinitializer, %305
  %307 = add i64 %248, 1
  %tile_snapshot.spill.load286 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 1
  %.splatinsert287 = insertelement <8 x i64> poison, i64 %307, i64 0
  %.splat288 = shufflevector <8 x i64> %.splatinsert287, <8 x i64> poison, <8 x i32> zeroinitializer
  %310 = mul <8 x i64> %.splat288, splat (i64 4)
  %311 = add <8 x i64> %309, %310
  %312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %313 = insertvalue { <8 x ptr>, <8 x i64> } %312, <8 x i64> %311, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %313, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %316 = getelementptr i8, <8 x ptr> %314, <8 x i64> %315
  %317 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %316, <8 x i1> %95, <8 x float> zeroinitializer)
  %318 = add i64 %261, 1
  %tile_snapshot.spill.load289 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load289, 0
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load289, 1
  %.splatinsert290 = insertelement <8 x i64> poison, i64 %318, i64 0
  %.splat291 = shufflevector <8 x i64> %.splatinsert290, <8 x i64> poison, <8 x i32> zeroinitializer
  %321 = mul <8 x i64> %.splat291, splat (i64 4)
  %322 = add <8 x i64> %320, %321
  %323 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %319, 0
  %324 = insertvalue { <8 x ptr>, <8 x i64> } %323, <8 x i64> %322, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %324, 0
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %324, 1
  %327 = getelementptr i8, <8 x ptr> %325, <8 x i64> %326
  %328 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %327, <8 x i1> %95, <8 x float> zeroinitializer)
  %329 = add i64 %274, 1
  %tile_snapshot.spill.load292 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load292, 0
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load292, 1
  %.splatinsert293 = insertelement <8 x i64> poison, i64 %329, i64 0
  %.splat294 = shufflevector <8 x i64> %.splatinsert293, <8 x i64> poison, <8 x i32> zeroinitializer
  %332 = mul <8 x i64> %.splat294, splat (i64 4)
  %333 = add <8 x i64> %331, %332
  %334 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %330, 0
  %335 = insertvalue { <8 x ptr>, <8 x i64> } %334, <8 x i64> %333, 1
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %335, 0
  %337 = extractvalue { <8 x ptr>, <8 x i64> } %335, 1
  %338 = getelementptr i8, <8 x ptr> %336, <8 x i64> %337
  %339 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %338, <8 x i1> %95, <8 x float> zeroinitializer)
  %340 = add i64 %287, 1
  %tile_snapshot.spill.load295 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load295, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load295, 1
  %.splatinsert296 = insertelement <8 x i64> poison, i64 %340, i64 0
  %.splat297 = shufflevector <8 x i64> %.splatinsert296, <8 x i64> poison, <8 x i32> zeroinitializer
  %343 = mul <8 x i64> %.splat297, splat (i64 4)
  %344 = add <8 x i64> %342, %343
  %345 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %341, 0
  %346 = insertvalue { <8 x ptr>, <8 x i64> } %345, <8 x i64> %344, 1
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %346, 0
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %346, 1
  %349 = getelementptr i8, <8 x ptr> %347, <8 x i64> %348
  %350 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %349, <8 x i1> %95, <8 x float> zeroinitializer)
  %351 = fmul <8 x float> %317, %339
  %352 = fadd <8 x float> %300, %351
  %353 = fmul <8 x float> %317, %350
  %354 = fadd <8 x float> %302, %353
  %355 = fmul <8 x float> %328, %339
  %356 = fadd <8 x float> %304, %355
  %357 = fmul <8 x float> %328, %350
  %358 = fadd <8 x float> %306, %357
  %359 = add i64 %248, 2
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %.splatinsert299 = insertelement <8 x i64> poison, i64 %359, i64 0
  %.splat300 = shufflevector <8 x i64> %.splatinsert299, <8 x i64> poison, <8 x i32> zeroinitializer
  %362 = mul <8 x i64> %.splat300, splat (i64 4)
  %363 = add <8 x i64> %361, %362
  %364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %360, 0
  %365 = insertvalue { <8 x ptr>, <8 x i64> } %364, <8 x i64> %363, 1
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %365, 0
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %365, 1
  %368 = getelementptr i8, <8 x ptr> %366, <8 x i64> %367
  %369 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %368, <8 x i1> %95, <8 x float> zeroinitializer)
  %370 = add i64 %261, 2
  %tile_snapshot.spill.load301 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load301, 0
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load301, 1
  %.splatinsert302 = insertelement <8 x i64> poison, i64 %370, i64 0
  %.splat303 = shufflevector <8 x i64> %.splatinsert302, <8 x i64> poison, <8 x i32> zeroinitializer
  %373 = mul <8 x i64> %.splat303, splat (i64 4)
  %374 = add <8 x i64> %372, %373
  %375 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %371, 0
  %376 = insertvalue { <8 x ptr>, <8 x i64> } %375, <8 x i64> %374, 1
  %377 = extractvalue { <8 x ptr>, <8 x i64> } %376, 0
  %378 = extractvalue { <8 x ptr>, <8 x i64> } %376, 1
  %379 = getelementptr i8, <8 x ptr> %377, <8 x i64> %378
  %380 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %379, <8 x i1> %95, <8 x float> zeroinitializer)
  %381 = add i64 %274, 2
  %tile_snapshot.spill.load304 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load304, 0
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load304, 1
  %.splatinsert305 = insertelement <8 x i64> poison, i64 %381, i64 0
  %.splat306 = shufflevector <8 x i64> %.splatinsert305, <8 x i64> poison, <8 x i32> zeroinitializer
  %384 = mul <8 x i64> %.splat306, splat (i64 4)
  %385 = add <8 x i64> %383, %384
  %386 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %382, 0
  %387 = insertvalue { <8 x ptr>, <8 x i64> } %386, <8 x i64> %385, 1
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %387, 0
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %387, 1
  %390 = getelementptr i8, <8 x ptr> %388, <8 x i64> %389
  %391 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %390, <8 x i1> %95, <8 x float> zeroinitializer)
  %392 = add i64 %287, 2
  %tile_snapshot.spill.load307 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load307, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load307, 1
  %.splatinsert308 = insertelement <8 x i64> poison, i64 %392, i64 0
  %.splat309 = shufflevector <8 x i64> %.splatinsert308, <8 x i64> poison, <8 x i32> zeroinitializer
  %395 = mul <8 x i64> %.splat309, splat (i64 4)
  %396 = add <8 x i64> %394, %395
  %397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %393, 0
  %398 = insertvalue { <8 x ptr>, <8 x i64> } %397, <8 x i64> %396, 1
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %398, 0
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %398, 1
  %401 = getelementptr i8, <8 x ptr> %399, <8 x i64> %400
  %402 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %401, <8 x i1> %95, <8 x float> zeroinitializer)
  %403 = fmul <8 x float> %369, %391
  %404 = fadd <8 x float> %352, %403
  %405 = fmul <8 x float> %369, %402
  %406 = fadd <8 x float> %354, %405
  %407 = fmul <8 x float> %380, %391
  %408 = fadd <8 x float> %356, %407
  %409 = fmul <8 x float> %380, %402
  %410 = fadd <8 x float> %358, %409
  %411 = add i64 %248, 3
  %tile_snapshot.spill.load310 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load310, 0
  %413 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load310, 1
  %.splatinsert311 = insertelement <8 x i64> poison, i64 %411, i64 0
  %.splat312 = shufflevector <8 x i64> %.splatinsert311, <8 x i64> poison, <8 x i32> zeroinitializer
  %414 = mul <8 x i64> %.splat312, splat (i64 4)
  %415 = add <8 x i64> %413, %414
  %416 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %412, 0
  %417 = insertvalue { <8 x ptr>, <8 x i64> } %416, <8 x i64> %415, 1
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %417, 0
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %417, 1
  %420 = getelementptr i8, <8 x ptr> %418, <8 x i64> %419
  %421 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %420, <8 x i1> %95, <8 x float> zeroinitializer)
  %422 = add i64 %261, 3
  %tile_snapshot.spill.load313 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load313, 0
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load313, 1
  %.splatinsert314 = insertelement <8 x i64> poison, i64 %422, i64 0
  %.splat315 = shufflevector <8 x i64> %.splatinsert314, <8 x i64> poison, <8 x i32> zeroinitializer
  %425 = mul <8 x i64> %.splat315, splat (i64 4)
  %426 = add <8 x i64> %424, %425
  %427 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %423, 0
  %428 = insertvalue { <8 x ptr>, <8 x i64> } %427, <8 x i64> %426, 1
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %428, 0
  %430 = extractvalue { <8 x ptr>, <8 x i64> } %428, 1
  %431 = getelementptr i8, <8 x ptr> %429, <8 x i64> %430
  %432 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %431, <8 x i1> %95, <8 x float> zeroinitializer)
  %433 = add i64 %274, 3
  %tile_snapshot.spill.load316 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load316, 0
  %435 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load316, 1
  %.splatinsert317 = insertelement <8 x i64> poison, i64 %433, i64 0
  %.splat318 = shufflevector <8 x i64> %.splatinsert317, <8 x i64> poison, <8 x i32> zeroinitializer
  %436 = mul <8 x i64> %.splat318, splat (i64 4)
  %437 = add <8 x i64> %435, %436
  %438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %434, 0
  %439 = insertvalue { <8 x ptr>, <8 x i64> } %438, <8 x i64> %437, 1
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %439, 0
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %439, 1
  %442 = getelementptr i8, <8 x ptr> %440, <8 x i64> %441
  %443 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %442, <8 x i1> %95, <8 x float> zeroinitializer)
  %444 = add i64 %287, 3
  %tile_snapshot.spill.load319 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load319, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load319, 1
  %.splatinsert320 = insertelement <8 x i64> poison, i64 %444, i64 0
  %.splat321 = shufflevector <8 x i64> %.splatinsert320, <8 x i64> poison, <8 x i32> zeroinitializer
  %447 = mul <8 x i64> %.splat321, splat (i64 4)
  %448 = add <8 x i64> %446, %447
  %449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %445, 0
  %450 = insertvalue { <8 x ptr>, <8 x i64> } %449, <8 x i64> %448, 1
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %450, 0
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %450, 1
  %453 = getelementptr i8, <8 x ptr> %451, <8 x i64> %452
  %454 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %453, <8 x i1> %95, <8 x float> zeroinitializer)
  %455 = fmul <8 x float> %421, %443
  %456 = fadd <8 x float> %404, %455
  %457 = fmul <8 x float> %421, %454
  %458 = fadd <8 x float> %406, %457
  %459 = fmul <8 x float> %432, %443
  %460 = fadd <8 x float> %408, %459
  %461 = fmul <8 x float> %432, %454
  %462 = fadd <8 x float> %410, %461
  %463 = add i64 %248, 4
  %tile_snapshot.spill.load322 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load322, 0
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load322, 1
  %.splatinsert323 = insertelement <8 x i64> poison, i64 %463, i64 0
  %.splat324 = shufflevector <8 x i64> %.splatinsert323, <8 x i64> poison, <8 x i32> zeroinitializer
  %466 = mul <8 x i64> %.splat324, splat (i64 4)
  %467 = add <8 x i64> %465, %466
  %468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %464, 0
  %469 = insertvalue { <8 x ptr>, <8 x i64> } %468, <8 x i64> %467, 1
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %469, 0
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %469, 1
  %472 = getelementptr i8, <8 x ptr> %470, <8 x i64> %471
  %473 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %472, <8 x i1> %95, <8 x float> zeroinitializer)
  %474 = add i64 %261, 4
  %tile_snapshot.spill.load325 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load325, 0
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load325, 1
  %.splatinsert326 = insertelement <8 x i64> poison, i64 %474, i64 0
  %.splat327 = shufflevector <8 x i64> %.splatinsert326, <8 x i64> poison, <8 x i32> zeroinitializer
  %477 = mul <8 x i64> %.splat327, splat (i64 4)
  %478 = add <8 x i64> %476, %477
  %479 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %475, 0
  %480 = insertvalue { <8 x ptr>, <8 x i64> } %479, <8 x i64> %478, 1
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %480, 0
  %482 = extractvalue { <8 x ptr>, <8 x i64> } %480, 1
  %483 = getelementptr i8, <8 x ptr> %481, <8 x i64> %482
  %484 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %483, <8 x i1> %95, <8 x float> zeroinitializer)
  %485 = add i64 %274, 4
  %tile_snapshot.spill.load328 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load328, 0
  %487 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load328, 1
  %.splatinsert329 = insertelement <8 x i64> poison, i64 %485, i64 0
  %.splat330 = shufflevector <8 x i64> %.splatinsert329, <8 x i64> poison, <8 x i32> zeroinitializer
  %488 = mul <8 x i64> %.splat330, splat (i64 4)
  %489 = add <8 x i64> %487, %488
  %490 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %486, 0
  %491 = insertvalue { <8 x ptr>, <8 x i64> } %490, <8 x i64> %489, 1
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %491, 0
  %493 = extractvalue { <8 x ptr>, <8 x i64> } %491, 1
  %494 = getelementptr i8, <8 x ptr> %492, <8 x i64> %493
  %495 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %494, <8 x i1> %95, <8 x float> zeroinitializer)
  %496 = add i64 %287, 4
  %tile_snapshot.spill.load331 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load331, 0
  %498 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load331, 1
  %.splatinsert332 = insertelement <8 x i64> poison, i64 %496, i64 0
  %.splat333 = shufflevector <8 x i64> %.splatinsert332, <8 x i64> poison, <8 x i32> zeroinitializer
  %499 = mul <8 x i64> %.splat333, splat (i64 4)
  %500 = add <8 x i64> %498, %499
  %501 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %497, 0
  %502 = insertvalue { <8 x ptr>, <8 x i64> } %501, <8 x i64> %500, 1
  %503 = extractvalue { <8 x ptr>, <8 x i64> } %502, 0
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %502, 1
  %505 = getelementptr i8, <8 x ptr> %503, <8 x i64> %504
  %506 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %505, <8 x i1> %95, <8 x float> zeroinitializer)
  %507 = fmul <8 x float> %473, %495
  %508 = fadd <8 x float> %456, %507
  %509 = fmul <8 x float> %473, %506
  %510 = fadd <8 x float> %458, %509
  %511 = fmul <8 x float> %484, %495
  %512 = fadd <8 x float> %460, %511
  %513 = fmul <8 x float> %484, %506
  %514 = fadd <8 x float> %462, %513
  %515 = add i64 %248, 5
  %tile_snapshot.spill.load334 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load334, 0
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load334, 1
  %.splatinsert335 = insertelement <8 x i64> poison, i64 %515, i64 0
  %.splat336 = shufflevector <8 x i64> %.splatinsert335, <8 x i64> poison, <8 x i32> zeroinitializer
  %518 = mul <8 x i64> %.splat336, splat (i64 4)
  %519 = add <8 x i64> %517, %518
  %520 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %516, 0
  %521 = insertvalue { <8 x ptr>, <8 x i64> } %520, <8 x i64> %519, 1
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %521, 0
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %521, 1
  %524 = getelementptr i8, <8 x ptr> %522, <8 x i64> %523
  %525 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %524, <8 x i1> %95, <8 x float> zeroinitializer)
  %526 = add i64 %261, 5
  %tile_snapshot.spill.load337 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load337, 0
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load337, 1
  %.splatinsert338 = insertelement <8 x i64> poison, i64 %526, i64 0
  %.splat339 = shufflevector <8 x i64> %.splatinsert338, <8 x i64> poison, <8 x i32> zeroinitializer
  %529 = mul <8 x i64> %.splat339, splat (i64 4)
  %530 = add <8 x i64> %528, %529
  %531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %527, 0
  %532 = insertvalue { <8 x ptr>, <8 x i64> } %531, <8 x i64> %530, 1
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %532, 0
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %532, 1
  %535 = getelementptr i8, <8 x ptr> %533, <8 x i64> %534
  %536 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %535, <8 x i1> %95, <8 x float> zeroinitializer)
  %537 = add i64 %274, 5
  %tile_snapshot.spill.load340 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load340, 0
  %539 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load340, 1
  %.splatinsert341 = insertelement <8 x i64> poison, i64 %537, i64 0
  %.splat342 = shufflevector <8 x i64> %.splatinsert341, <8 x i64> poison, <8 x i32> zeroinitializer
  %540 = mul <8 x i64> %.splat342, splat (i64 4)
  %541 = add <8 x i64> %539, %540
  %542 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %538, 0
  %543 = insertvalue { <8 x ptr>, <8 x i64> } %542, <8 x i64> %541, 1
  %544 = extractvalue { <8 x ptr>, <8 x i64> } %543, 0
  %545 = extractvalue { <8 x ptr>, <8 x i64> } %543, 1
  %546 = getelementptr i8, <8 x ptr> %544, <8 x i64> %545
  %547 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %546, <8 x i1> %95, <8 x float> zeroinitializer)
  %548 = add i64 %287, 5
  %tile_snapshot.spill.load343 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 0
  %550 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load343, 1
  %.splatinsert344 = insertelement <8 x i64> poison, i64 %548, i64 0
  %.splat345 = shufflevector <8 x i64> %.splatinsert344, <8 x i64> poison, <8 x i32> zeroinitializer
  %551 = mul <8 x i64> %.splat345, splat (i64 4)
  %552 = add <8 x i64> %550, %551
  %553 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %549, 0
  %554 = insertvalue { <8 x ptr>, <8 x i64> } %553, <8 x i64> %552, 1
  %555 = extractvalue { <8 x ptr>, <8 x i64> } %554, 0
  %556 = extractvalue { <8 x ptr>, <8 x i64> } %554, 1
  %557 = getelementptr i8, <8 x ptr> %555, <8 x i64> %556
  %558 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %557, <8 x i1> %95, <8 x float> zeroinitializer)
  %559 = fmul <8 x float> %525, %547
  %560 = fadd <8 x float> %508, %559
  %561 = fmul <8 x float> %525, %558
  %562 = fadd <8 x float> %510, %561
  %563 = fmul <8 x float> %536, %547
  %564 = fadd <8 x float> %512, %563
  %565 = fmul <8 x float> %536, %558
  %566 = fadd <8 x float> %514, %565
  %567 = add i64 %248, 6
  %tile_snapshot.spill.load346 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load346, 0
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load346, 1
  %.splatinsert347 = insertelement <8 x i64> poison, i64 %567, i64 0
  %.splat348 = shufflevector <8 x i64> %.splatinsert347, <8 x i64> poison, <8 x i32> zeroinitializer
  %570 = mul <8 x i64> %.splat348, splat (i64 4)
  %571 = add <8 x i64> %569, %570
  %572 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %568, 0
  %573 = insertvalue { <8 x ptr>, <8 x i64> } %572, <8 x i64> %571, 1
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %573, 0
  %575 = extractvalue { <8 x ptr>, <8 x i64> } %573, 1
  %576 = getelementptr i8, <8 x ptr> %574, <8 x i64> %575
  %577 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %576, <8 x i1> %95, <8 x float> zeroinitializer)
  %578 = add i64 %261, 6
  %tile_snapshot.spill.load349 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %579 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 0
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 1
  %.splatinsert350 = insertelement <8 x i64> poison, i64 %578, i64 0
  %.splat351 = shufflevector <8 x i64> %.splatinsert350, <8 x i64> poison, <8 x i32> zeroinitializer
  %581 = mul <8 x i64> %.splat351, splat (i64 4)
  %582 = add <8 x i64> %580, %581
  %583 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %579, 0
  %584 = insertvalue { <8 x ptr>, <8 x i64> } %583, <8 x i64> %582, 1
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %584, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %584, 1
  %587 = getelementptr i8, <8 x ptr> %585, <8 x i64> %586
  %588 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %587, <8 x i1> %95, <8 x float> zeroinitializer)
  %589 = add i64 %274, 6
  %tile_snapshot.spill.load352 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load352, 0
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load352, 1
  %.splatinsert353 = insertelement <8 x i64> poison, i64 %589, i64 0
  %.splat354 = shufflevector <8 x i64> %.splatinsert353, <8 x i64> poison, <8 x i32> zeroinitializer
  %592 = mul <8 x i64> %.splat354, splat (i64 4)
  %593 = add <8 x i64> %591, %592
  %594 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %590, 0
  %595 = insertvalue { <8 x ptr>, <8 x i64> } %594, <8 x i64> %593, 1
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %595, 0
  %597 = extractvalue { <8 x ptr>, <8 x i64> } %595, 1
  %598 = getelementptr i8, <8 x ptr> %596, <8 x i64> %597
  %599 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %598, <8 x i1> %95, <8 x float> zeroinitializer)
  %600 = add i64 %287, 6
  %tile_snapshot.spill.load355 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load355, 0
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load355, 1
  %.splatinsert356 = insertelement <8 x i64> poison, i64 %600, i64 0
  %.splat357 = shufflevector <8 x i64> %.splatinsert356, <8 x i64> poison, <8 x i32> zeroinitializer
  %603 = mul <8 x i64> %.splat357, splat (i64 4)
  %604 = add <8 x i64> %602, %603
  %605 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %601, 0
  %606 = insertvalue { <8 x ptr>, <8 x i64> } %605, <8 x i64> %604, 1
  %607 = extractvalue { <8 x ptr>, <8 x i64> } %606, 0
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %606, 1
  %609 = getelementptr i8, <8 x ptr> %607, <8 x i64> %608
  %610 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %609, <8 x i1> %95, <8 x float> zeroinitializer)
  %611 = fmul <8 x float> %577, %599
  %612 = fadd <8 x float> %560, %611
  %613 = fmul <8 x float> %577, %610
  %614 = fadd <8 x float> %562, %613
  %615 = fmul <8 x float> %588, %599
  %616 = fadd <8 x float> %564, %615
  %617 = fmul <8 x float> %588, %610
  %618 = fadd <8 x float> %566, %617
  %619 = add i64 %248, 7
  %tile_snapshot.spill.load358 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %620 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load358, 0
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load358, 1
  %.splatinsert359 = insertelement <8 x i64> poison, i64 %619, i64 0
  %.splat360 = shufflevector <8 x i64> %.splatinsert359, <8 x i64> poison, <8 x i32> zeroinitializer
  %622 = mul <8 x i64> %.splat360, splat (i64 4)
  %623 = add <8 x i64> %621, %622
  %624 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %620, 0
  %625 = insertvalue { <8 x ptr>, <8 x i64> } %624, <8 x i64> %623, 1
  %626 = extractvalue { <8 x ptr>, <8 x i64> } %625, 0
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %625, 1
  %628 = getelementptr i8, <8 x ptr> %626, <8 x i64> %627
  %629 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %628, <8 x i1> %95, <8 x float> zeroinitializer)
  %630 = add i64 %261, 7
  %tile_snapshot.spill.load361 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %631 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load361, 0
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load361, 1
  %.splatinsert362 = insertelement <8 x i64> poison, i64 %630, i64 0
  %.splat363 = shufflevector <8 x i64> %.splatinsert362, <8 x i64> poison, <8 x i32> zeroinitializer
  %633 = mul <8 x i64> %.splat363, splat (i64 4)
  %634 = add <8 x i64> %632, %633
  %635 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %631, 0
  %636 = insertvalue { <8 x ptr>, <8 x i64> } %635, <8 x i64> %634, 1
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %636, 0
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %636, 1
  %639 = getelementptr i8, <8 x ptr> %637, <8 x i64> %638
  %640 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %639, <8 x i1> %95, <8 x float> zeroinitializer)
  %641 = add i64 %274, 7
  %tile_snapshot.spill.load364 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load364, 0
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load364, 1
  %.splatinsert365 = insertelement <8 x i64> poison, i64 %641, i64 0
  %.splat366 = shufflevector <8 x i64> %.splatinsert365, <8 x i64> poison, <8 x i32> zeroinitializer
  %644 = mul <8 x i64> %.splat366, splat (i64 4)
  %645 = add <8 x i64> %643, %644
  %646 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %642, 0
  %647 = insertvalue { <8 x ptr>, <8 x i64> } %646, <8 x i64> %645, 1
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %647, 0
  %649 = extractvalue { <8 x ptr>, <8 x i64> } %647, 1
  %650 = getelementptr i8, <8 x ptr> %648, <8 x i64> %649
  %651 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %650, <8 x i1> %95, <8 x float> zeroinitializer)
  %652 = add i64 %287, 7
  %tile_snapshot.spill.load367 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load367, 0
  %654 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load367, 1
  %.splatinsert368 = insertelement <8 x i64> poison, i64 %652, i64 0
  %.splat369 = shufflevector <8 x i64> %.splatinsert368, <8 x i64> poison, <8 x i32> zeroinitializer
  %655 = mul <8 x i64> %.splat369, splat (i64 4)
  %656 = add <8 x i64> %654, %655
  %657 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %653, 0
  %658 = insertvalue { <8 x ptr>, <8 x i64> } %657, <8 x i64> %656, 1
  %659 = extractvalue { <8 x ptr>, <8 x i64> } %658, 0
  %660 = extractvalue { <8 x ptr>, <8 x i64> } %658, 1
  %661 = getelementptr i8, <8 x ptr> %659, <8 x i64> %660
  %662 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %661, <8 x i1> %95, <8 x float> zeroinitializer)
  %663 = fmul <8 x float> %629, %651
  %664 = fadd <8 x float> %612, %663
  %665 = fmul <8 x float> %629, %662
  %666 = fadd <8 x float> %614, %665
  %667 = fmul <8 x float> %640, %651
  %668 = fadd <8 x float> %616, %667
  %669 = fmul <8 x float> %640, %662
  %670 = fadd <8 x float> %618, %669
  %671 = add i64 %248, 8
  %tile_snapshot.spill.load370 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load370, 0
  %673 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load370, 1
  %.splatinsert371 = insertelement <8 x i64> poison, i64 %671, i64 0
  %.splat372 = shufflevector <8 x i64> %.splatinsert371, <8 x i64> poison, <8 x i32> zeroinitializer
  %674 = mul <8 x i64> %.splat372, splat (i64 4)
  %675 = add <8 x i64> %673, %674
  %676 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %672, 0
  %677 = insertvalue { <8 x ptr>, <8 x i64> } %676, <8 x i64> %675, 1
  %678 = extractvalue { <8 x ptr>, <8 x i64> } %677, 0
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %677, 1
  %680 = getelementptr i8, <8 x ptr> %678, <8 x i64> %679
  %681 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %680, <8 x i1> %95, <8 x float> zeroinitializer)
  %682 = add i64 %261, 8
  %tile_snapshot.spill.load373 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %683 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 0
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load373, 1
  %.splatinsert374 = insertelement <8 x i64> poison, i64 %682, i64 0
  %.splat375 = shufflevector <8 x i64> %.splatinsert374, <8 x i64> poison, <8 x i32> zeroinitializer
  %685 = mul <8 x i64> %.splat375, splat (i64 4)
  %686 = add <8 x i64> %684, %685
  %687 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %683, 0
  %688 = insertvalue { <8 x ptr>, <8 x i64> } %687, <8 x i64> %686, 1
  %689 = extractvalue { <8 x ptr>, <8 x i64> } %688, 0
  %690 = extractvalue { <8 x ptr>, <8 x i64> } %688, 1
  %691 = getelementptr i8, <8 x ptr> %689, <8 x i64> %690
  %692 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %691, <8 x i1> %95, <8 x float> zeroinitializer)
  %693 = add i64 %274, 8
  %tile_snapshot.spill.load376 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load376, 0
  %695 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load376, 1
  %.splatinsert377 = insertelement <8 x i64> poison, i64 %693, i64 0
  %.splat378 = shufflevector <8 x i64> %.splatinsert377, <8 x i64> poison, <8 x i32> zeroinitializer
  %696 = mul <8 x i64> %.splat378, splat (i64 4)
  %697 = add <8 x i64> %695, %696
  %698 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %694, 0
  %699 = insertvalue { <8 x ptr>, <8 x i64> } %698, <8 x i64> %697, 1
  %700 = extractvalue { <8 x ptr>, <8 x i64> } %699, 0
  %701 = extractvalue { <8 x ptr>, <8 x i64> } %699, 1
  %702 = getelementptr i8, <8 x ptr> %700, <8 x i64> %701
  %703 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %702, <8 x i1> %95, <8 x float> zeroinitializer)
  %704 = add i64 %287, 8
  %tile_snapshot.spill.load379 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load379, 0
  %706 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load379, 1
  %.splatinsert380 = insertelement <8 x i64> poison, i64 %704, i64 0
  %.splat381 = shufflevector <8 x i64> %.splatinsert380, <8 x i64> poison, <8 x i32> zeroinitializer
  %707 = mul <8 x i64> %.splat381, splat (i64 4)
  %708 = add <8 x i64> %706, %707
  %709 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %705, 0
  %710 = insertvalue { <8 x ptr>, <8 x i64> } %709, <8 x i64> %708, 1
  %711 = extractvalue { <8 x ptr>, <8 x i64> } %710, 0
  %712 = extractvalue { <8 x ptr>, <8 x i64> } %710, 1
  %713 = getelementptr i8, <8 x ptr> %711, <8 x i64> %712
  %714 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %713, <8 x i1> %95, <8 x float> zeroinitializer)
  %715 = fmul <8 x float> %681, %703
  %716 = fadd <8 x float> %664, %715
  %717 = fmul <8 x float> %681, %714
  %718 = fadd <8 x float> %666, %717
  %719 = fmul <8 x float> %692, %703
  %720 = fadd <8 x float> %668, %719
  %721 = fmul <8 x float> %692, %714
  %722 = fadd <8 x float> %670, %721
  %723 = add i64 %248, 9
  %tile_snapshot.spill.load382 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load382, 0
  %725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load382, 1
  %.splatinsert383 = insertelement <8 x i64> poison, i64 %723, i64 0
  %.splat384 = shufflevector <8 x i64> %.splatinsert383, <8 x i64> poison, <8 x i32> zeroinitializer
  %726 = mul <8 x i64> %.splat384, splat (i64 4)
  %727 = add <8 x i64> %725, %726
  %728 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %724, 0
  %729 = insertvalue { <8 x ptr>, <8 x i64> } %728, <8 x i64> %727, 1
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %729, 0
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %729, 1
  %732 = getelementptr i8, <8 x ptr> %730, <8 x i64> %731
  %733 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %732, <8 x i1> %95, <8 x float> zeroinitializer)
  %734 = add i64 %261, 9
  %tile_snapshot.spill.load385 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load385, 0
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load385, 1
  %.splatinsert386 = insertelement <8 x i64> poison, i64 %734, i64 0
  %.splat387 = shufflevector <8 x i64> %.splatinsert386, <8 x i64> poison, <8 x i32> zeroinitializer
  %737 = mul <8 x i64> %.splat387, splat (i64 4)
  %738 = add <8 x i64> %736, %737
  %739 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %735, 0
  %740 = insertvalue { <8 x ptr>, <8 x i64> } %739, <8 x i64> %738, 1
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %740, 0
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %740, 1
  %743 = getelementptr i8, <8 x ptr> %741, <8 x i64> %742
  %744 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %743, <8 x i1> %95, <8 x float> zeroinitializer)
  %745 = add i64 %274, 9
  %tile_snapshot.spill.load388 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load388, 0
  %747 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load388, 1
  %.splatinsert389 = insertelement <8 x i64> poison, i64 %745, i64 0
  %.splat390 = shufflevector <8 x i64> %.splatinsert389, <8 x i64> poison, <8 x i32> zeroinitializer
  %748 = mul <8 x i64> %.splat390, splat (i64 4)
  %749 = add <8 x i64> %747, %748
  %750 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %746, 0
  %751 = insertvalue { <8 x ptr>, <8 x i64> } %750, <8 x i64> %749, 1
  %752 = extractvalue { <8 x ptr>, <8 x i64> } %751, 0
  %753 = extractvalue { <8 x ptr>, <8 x i64> } %751, 1
  %754 = getelementptr i8, <8 x ptr> %752, <8 x i64> %753
  %755 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %754, <8 x i1> %95, <8 x float> zeroinitializer)
  %756 = add i64 %287, 9
  %tile_snapshot.spill.load391 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %757 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load391, 0
  %758 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load391, 1
  %.splatinsert392 = insertelement <8 x i64> poison, i64 %756, i64 0
  %.splat393 = shufflevector <8 x i64> %.splatinsert392, <8 x i64> poison, <8 x i32> zeroinitializer
  %759 = mul <8 x i64> %.splat393, splat (i64 4)
  %760 = add <8 x i64> %758, %759
  %761 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %757, 0
  %762 = insertvalue { <8 x ptr>, <8 x i64> } %761, <8 x i64> %760, 1
  %763 = extractvalue { <8 x ptr>, <8 x i64> } %762, 0
  %764 = extractvalue { <8 x ptr>, <8 x i64> } %762, 1
  %765 = getelementptr i8, <8 x ptr> %763, <8 x i64> %764
  %766 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %765, <8 x i1> %95, <8 x float> zeroinitializer)
  %767 = fmul <8 x float> %733, %755
  %768 = fadd <8 x float> %716, %767
  %769 = fmul <8 x float> %733, %766
  %770 = fadd <8 x float> %718, %769
  %771 = fmul <8 x float> %744, %755
  %772 = fadd <8 x float> %720, %771
  %773 = fmul <8 x float> %744, %766
  %774 = fadd <8 x float> %722, %773
  %775 = add i64 %248, 10
  %tile_snapshot.spill.load394 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load394, 0
  %777 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load394, 1
  %.splatinsert395 = insertelement <8 x i64> poison, i64 %775, i64 0
  %.splat396 = shufflevector <8 x i64> %.splatinsert395, <8 x i64> poison, <8 x i32> zeroinitializer
  %778 = mul <8 x i64> %.splat396, splat (i64 4)
  %779 = add <8 x i64> %777, %778
  %780 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %776, 0
  %781 = insertvalue { <8 x ptr>, <8 x i64> } %780, <8 x i64> %779, 1
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %781, 0
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %781, 1
  %784 = getelementptr i8, <8 x ptr> %782, <8 x i64> %783
  %785 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %784, <8 x i1> %95, <8 x float> zeroinitializer)
  %786 = add i64 %261, 10
  %tile_snapshot.spill.load397 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %787 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load397, 0
  %788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load397, 1
  %.splatinsert398 = insertelement <8 x i64> poison, i64 %786, i64 0
  %.splat399 = shufflevector <8 x i64> %.splatinsert398, <8 x i64> poison, <8 x i32> zeroinitializer
  %789 = mul <8 x i64> %.splat399, splat (i64 4)
  %790 = add <8 x i64> %788, %789
  %791 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %787, 0
  %792 = insertvalue { <8 x ptr>, <8 x i64> } %791, <8 x i64> %790, 1
  %793 = extractvalue { <8 x ptr>, <8 x i64> } %792, 0
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %792, 1
  %795 = getelementptr i8, <8 x ptr> %793, <8 x i64> %794
  %796 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %795, <8 x i1> %95, <8 x float> zeroinitializer)
  %797 = add i64 %274, 10
  %tile_snapshot.spill.load400 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load400, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load400, 1
  %.splatinsert401 = insertelement <8 x i64> poison, i64 %797, i64 0
  %.splat402 = shufflevector <8 x i64> %.splatinsert401, <8 x i64> poison, <8 x i32> zeroinitializer
  %800 = mul <8 x i64> %.splat402, splat (i64 4)
  %801 = add <8 x i64> %799, %800
  %802 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %798, 0
  %803 = insertvalue { <8 x ptr>, <8 x i64> } %802, <8 x i64> %801, 1
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %803, 0
  %805 = extractvalue { <8 x ptr>, <8 x i64> } %803, 1
  %806 = getelementptr i8, <8 x ptr> %804, <8 x i64> %805
  %807 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %806, <8 x i1> %95, <8 x float> zeroinitializer)
  %808 = add i64 %287, 10
  %tile_snapshot.spill.load403 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %809 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load403, 0
  %810 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load403, 1
  %.splatinsert404 = insertelement <8 x i64> poison, i64 %808, i64 0
  %.splat405 = shufflevector <8 x i64> %.splatinsert404, <8 x i64> poison, <8 x i32> zeroinitializer
  %811 = mul <8 x i64> %.splat405, splat (i64 4)
  %812 = add <8 x i64> %810, %811
  %813 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %809, 0
  %814 = insertvalue { <8 x ptr>, <8 x i64> } %813, <8 x i64> %812, 1
  %815 = extractvalue { <8 x ptr>, <8 x i64> } %814, 0
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %814, 1
  %817 = getelementptr i8, <8 x ptr> %815, <8 x i64> %816
  %818 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %817, <8 x i1> %95, <8 x float> zeroinitializer)
  %819 = fmul <8 x float> %785, %807
  %820 = fadd <8 x float> %768, %819
  %821 = fmul <8 x float> %785, %818
  %822 = fadd <8 x float> %770, %821
  %823 = fmul <8 x float> %796, %807
  %824 = fadd <8 x float> %772, %823
  %825 = fmul <8 x float> %796, %818
  %826 = fadd <8 x float> %774, %825
  %827 = add i64 %248, 11
  %tile_snapshot.spill.load406 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load406, 0
  %829 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load406, 1
  %.splatinsert407 = insertelement <8 x i64> poison, i64 %827, i64 0
  %.splat408 = shufflevector <8 x i64> %.splatinsert407, <8 x i64> poison, <8 x i32> zeroinitializer
  %830 = mul <8 x i64> %.splat408, splat (i64 4)
  %831 = add <8 x i64> %829, %830
  %832 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %828, 0
  %833 = insertvalue { <8 x ptr>, <8 x i64> } %832, <8 x i64> %831, 1
  %834 = extractvalue { <8 x ptr>, <8 x i64> } %833, 0
  %835 = extractvalue { <8 x ptr>, <8 x i64> } %833, 1
  %836 = getelementptr i8, <8 x ptr> %834, <8 x i64> %835
  %837 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %836, <8 x i1> %95, <8 x float> zeroinitializer)
  %838 = add i64 %261, 11
  %tile_snapshot.spill.load409 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %.splatinsert410 = insertelement <8 x i64> poison, i64 %838, i64 0
  %.splat411 = shufflevector <8 x i64> %.splatinsert410, <8 x i64> poison, <8 x i32> zeroinitializer
  %841 = mul <8 x i64> %.splat411, splat (i64 4)
  %842 = add <8 x i64> %840, %841
  %843 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %839, 0
  %844 = insertvalue { <8 x ptr>, <8 x i64> } %843, <8 x i64> %842, 1
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %844, 0
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %844, 1
  %847 = getelementptr i8, <8 x ptr> %845, <8 x i64> %846
  %848 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %847, <8 x i1> %95, <8 x float> zeroinitializer)
  %849 = add i64 %274, 11
  %tile_snapshot.spill.load412 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %.splatinsert413 = insertelement <8 x i64> poison, i64 %849, i64 0
  %.splat414 = shufflevector <8 x i64> %.splatinsert413, <8 x i64> poison, <8 x i32> zeroinitializer
  %852 = mul <8 x i64> %.splat414, splat (i64 4)
  %853 = add <8 x i64> %851, %852
  %854 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %850, 0
  %855 = insertvalue { <8 x ptr>, <8 x i64> } %854, <8 x i64> %853, 1
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %855, 0
  %857 = extractvalue { <8 x ptr>, <8 x i64> } %855, 1
  %858 = getelementptr i8, <8 x ptr> %856, <8 x i64> %857
  %859 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %858, <8 x i1> %95, <8 x float> zeroinitializer)
  %860 = add i64 %287, 11
  %tile_snapshot.spill.load415 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %861 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load415, 0
  %862 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load415, 1
  %.splatinsert416 = insertelement <8 x i64> poison, i64 %860, i64 0
  %.splat417 = shufflevector <8 x i64> %.splatinsert416, <8 x i64> poison, <8 x i32> zeroinitializer
  %863 = mul <8 x i64> %.splat417, splat (i64 4)
  %864 = add <8 x i64> %862, %863
  %865 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %861, 0
  %866 = insertvalue { <8 x ptr>, <8 x i64> } %865, <8 x i64> %864, 1
  %867 = extractvalue { <8 x ptr>, <8 x i64> } %866, 0
  %868 = extractvalue { <8 x ptr>, <8 x i64> } %866, 1
  %869 = getelementptr i8, <8 x ptr> %867, <8 x i64> %868
  %870 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %869, <8 x i1> %95, <8 x float> zeroinitializer)
  %871 = fmul <8 x float> %837, %859
  %872 = fadd <8 x float> %820, %871
  %873 = fmul <8 x float> %837, %870
  %874 = fadd <8 x float> %822, %873
  %875 = fmul <8 x float> %848, %859
  %876 = fadd <8 x float> %824, %875
  %877 = fmul <8 x float> %848, %870
  %878 = fadd <8 x float> %826, %877
  %879 = add i64 %248, 12
  %tile_snapshot.spill.load418 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %880 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load418, 0
  %881 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load418, 1
  %.splatinsert419 = insertelement <8 x i64> poison, i64 %879, i64 0
  %.splat420 = shufflevector <8 x i64> %.splatinsert419, <8 x i64> poison, <8 x i32> zeroinitializer
  %882 = mul <8 x i64> %.splat420, splat (i64 4)
  %883 = add <8 x i64> %881, %882
  %884 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %880, 0
  %885 = insertvalue { <8 x ptr>, <8 x i64> } %884, <8 x i64> %883, 1
  %886 = extractvalue { <8 x ptr>, <8 x i64> } %885, 0
  %887 = extractvalue { <8 x ptr>, <8 x i64> } %885, 1
  %888 = getelementptr i8, <8 x ptr> %886, <8 x i64> %887
  %889 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %888, <8 x i1> %95, <8 x float> zeroinitializer)
  %890 = add i64 %261, 12
  %tile_snapshot.spill.load421 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %891 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load421, 0
  %892 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load421, 1
  %.splatinsert422 = insertelement <8 x i64> poison, i64 %890, i64 0
  %.splat423 = shufflevector <8 x i64> %.splatinsert422, <8 x i64> poison, <8 x i32> zeroinitializer
  %893 = mul <8 x i64> %.splat423, splat (i64 4)
  %894 = add <8 x i64> %892, %893
  %895 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %891, 0
  %896 = insertvalue { <8 x ptr>, <8 x i64> } %895, <8 x i64> %894, 1
  %897 = extractvalue { <8 x ptr>, <8 x i64> } %896, 0
  %898 = extractvalue { <8 x ptr>, <8 x i64> } %896, 1
  %899 = getelementptr i8, <8 x ptr> %897, <8 x i64> %898
  %900 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %899, <8 x i1> %95, <8 x float> zeroinitializer)
  %901 = add i64 %274, 12
  %tile_snapshot.spill.load424 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %902 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load424, 0
  %903 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load424, 1
  %.splatinsert425 = insertelement <8 x i64> poison, i64 %901, i64 0
  %.splat426 = shufflevector <8 x i64> %.splatinsert425, <8 x i64> poison, <8 x i32> zeroinitializer
  %904 = mul <8 x i64> %.splat426, splat (i64 4)
  %905 = add <8 x i64> %903, %904
  %906 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %902, 0
  %907 = insertvalue { <8 x ptr>, <8 x i64> } %906, <8 x i64> %905, 1
  %908 = extractvalue { <8 x ptr>, <8 x i64> } %907, 0
  %909 = extractvalue { <8 x ptr>, <8 x i64> } %907, 1
  %910 = getelementptr i8, <8 x ptr> %908, <8 x i64> %909
  %911 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %910, <8 x i1> %95, <8 x float> zeroinitializer)
  %912 = add i64 %287, 12
  %tile_snapshot.spill.load427 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %913 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load427, 0
  %914 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load427, 1
  %.splatinsert428 = insertelement <8 x i64> poison, i64 %912, i64 0
  %.splat429 = shufflevector <8 x i64> %.splatinsert428, <8 x i64> poison, <8 x i32> zeroinitializer
  %915 = mul <8 x i64> %.splat429, splat (i64 4)
  %916 = add <8 x i64> %914, %915
  %917 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %913, 0
  %918 = insertvalue { <8 x ptr>, <8 x i64> } %917, <8 x i64> %916, 1
  %919 = extractvalue { <8 x ptr>, <8 x i64> } %918, 0
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %918, 1
  %921 = getelementptr i8, <8 x ptr> %919, <8 x i64> %920
  %922 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %921, <8 x i1> %95, <8 x float> zeroinitializer)
  %923 = fmul <8 x float> %889, %911
  %924 = fadd <8 x float> %872, %923
  %925 = fmul <8 x float> %889, %922
  %926 = fadd <8 x float> %874, %925
  %927 = fmul <8 x float> %900, %911
  %928 = fadd <8 x float> %876, %927
  %929 = fmul <8 x float> %900, %922
  %930 = fadd <8 x float> %878, %929
  %931 = add i64 %248, 13
  %tile_snapshot.spill.load430 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %932 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load430, 0
  %933 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load430, 1
  %.splatinsert431 = insertelement <8 x i64> poison, i64 %931, i64 0
  %.splat432 = shufflevector <8 x i64> %.splatinsert431, <8 x i64> poison, <8 x i32> zeroinitializer
  %934 = mul <8 x i64> %.splat432, splat (i64 4)
  %935 = add <8 x i64> %933, %934
  %936 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %932, 0
  %937 = insertvalue { <8 x ptr>, <8 x i64> } %936, <8 x i64> %935, 1
  %938 = extractvalue { <8 x ptr>, <8 x i64> } %937, 0
  %939 = extractvalue { <8 x ptr>, <8 x i64> } %937, 1
  %940 = getelementptr i8, <8 x ptr> %938, <8 x i64> %939
  %941 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %940, <8 x i1> %95, <8 x float> zeroinitializer)
  %942 = add i64 %261, 13
  %tile_snapshot.spill.load433 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %943 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load433, 0
  %944 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load433, 1
  %.splatinsert434 = insertelement <8 x i64> poison, i64 %942, i64 0
  %.splat435 = shufflevector <8 x i64> %.splatinsert434, <8 x i64> poison, <8 x i32> zeroinitializer
  %945 = mul <8 x i64> %.splat435, splat (i64 4)
  %946 = add <8 x i64> %944, %945
  %947 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %943, 0
  %948 = insertvalue { <8 x ptr>, <8 x i64> } %947, <8 x i64> %946, 1
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %948, 0
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %948, 1
  %951 = getelementptr i8, <8 x ptr> %949, <8 x i64> %950
  %952 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %951, <8 x i1> %95, <8 x float> zeroinitializer)
  %953 = add i64 %274, 13
  %tile_snapshot.spill.load436 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %954 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load436, 0
  %955 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load436, 1
  %.splatinsert437 = insertelement <8 x i64> poison, i64 %953, i64 0
  %.splat438 = shufflevector <8 x i64> %.splatinsert437, <8 x i64> poison, <8 x i32> zeroinitializer
  %956 = mul <8 x i64> %.splat438, splat (i64 4)
  %957 = add <8 x i64> %955, %956
  %958 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %954, 0
  %959 = insertvalue { <8 x ptr>, <8 x i64> } %958, <8 x i64> %957, 1
  %960 = extractvalue { <8 x ptr>, <8 x i64> } %959, 0
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %959, 1
  %962 = getelementptr i8, <8 x ptr> %960, <8 x i64> %961
  %963 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %962, <8 x i1> %95, <8 x float> zeroinitializer)
  %964 = add i64 %287, 13
  %tile_snapshot.spill.load439 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %965 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load439, 0
  %966 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load439, 1
  %.splatinsert440 = insertelement <8 x i64> poison, i64 %964, i64 0
  %.splat441 = shufflevector <8 x i64> %.splatinsert440, <8 x i64> poison, <8 x i32> zeroinitializer
  %967 = mul <8 x i64> %.splat441, splat (i64 4)
  %968 = add <8 x i64> %966, %967
  %969 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %965, 0
  %970 = insertvalue { <8 x ptr>, <8 x i64> } %969, <8 x i64> %968, 1
  %971 = extractvalue { <8 x ptr>, <8 x i64> } %970, 0
  %972 = extractvalue { <8 x ptr>, <8 x i64> } %970, 1
  %973 = getelementptr i8, <8 x ptr> %971, <8 x i64> %972
  %974 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %973, <8 x i1> %95, <8 x float> zeroinitializer)
  %975 = fmul <8 x float> %941, %963
  %976 = fadd <8 x float> %924, %975
  %977 = fmul <8 x float> %941, %974
  %978 = fadd <8 x float> %926, %977
  %979 = fmul <8 x float> %952, %963
  %980 = fadd <8 x float> %928, %979
  %981 = fmul <8 x float> %952, %974
  %982 = fadd <8 x float> %930, %981
  %983 = add i64 %248, 14
  %tile_snapshot.spill.load442 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %984 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load442, 0
  %985 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load442, 1
  %.splatinsert443 = insertelement <8 x i64> poison, i64 %983, i64 0
  %.splat444 = shufflevector <8 x i64> %.splatinsert443, <8 x i64> poison, <8 x i32> zeroinitializer
  %986 = mul <8 x i64> %.splat444, splat (i64 4)
  %987 = add <8 x i64> %985, %986
  %988 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %984, 0
  %989 = insertvalue { <8 x ptr>, <8 x i64> } %988, <8 x i64> %987, 1
  %990 = extractvalue { <8 x ptr>, <8 x i64> } %989, 0
  %991 = extractvalue { <8 x ptr>, <8 x i64> } %989, 1
  %992 = getelementptr i8, <8 x ptr> %990, <8 x i64> %991
  %993 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %992, <8 x i1> %95, <8 x float> zeroinitializer)
  %994 = add i64 %261, 14
  %tile_snapshot.spill.load445 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %995 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load445, 0
  %996 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load445, 1
  %.splatinsert446 = insertelement <8 x i64> poison, i64 %994, i64 0
  %.splat447 = shufflevector <8 x i64> %.splatinsert446, <8 x i64> poison, <8 x i32> zeroinitializer
  %997 = mul <8 x i64> %.splat447, splat (i64 4)
  %998 = add <8 x i64> %996, %997
  %999 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %995, 0
  %1000 = insertvalue { <8 x ptr>, <8 x i64> } %999, <8 x i64> %998, 1
  %1001 = extractvalue { <8 x ptr>, <8 x i64> } %1000, 0
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %1000, 1
  %1003 = getelementptr i8, <8 x ptr> %1001, <8 x i64> %1002
  %1004 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1003, <8 x i1> %95, <8 x float> zeroinitializer)
  %1005 = add i64 %274, 14
  %tile_snapshot.spill.load448 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load448, 0
  %1007 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load448, 1
  %.splatinsert449 = insertelement <8 x i64> poison, i64 %1005, i64 0
  %.splat450 = shufflevector <8 x i64> %.splatinsert449, <8 x i64> poison, <8 x i32> zeroinitializer
  %1008 = mul <8 x i64> %.splat450, splat (i64 4)
  %1009 = add <8 x i64> %1007, %1008
  %1010 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1006, 0
  %1011 = insertvalue { <8 x ptr>, <8 x i64> } %1010, <8 x i64> %1009, 1
  %1012 = extractvalue { <8 x ptr>, <8 x i64> } %1011, 0
  %1013 = extractvalue { <8 x ptr>, <8 x i64> } %1011, 1
  %1014 = getelementptr i8, <8 x ptr> %1012, <8 x i64> %1013
  %1015 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1014, <8 x i1> %95, <8 x float> zeroinitializer)
  %1016 = add i64 %287, 14
  %tile_snapshot.spill.load451 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1017 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 0
  %1018 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 1
  %.splatinsert452 = insertelement <8 x i64> poison, i64 %1016, i64 0
  %.splat453 = shufflevector <8 x i64> %.splatinsert452, <8 x i64> poison, <8 x i32> zeroinitializer
  %1019 = mul <8 x i64> %.splat453, splat (i64 4)
  %1020 = add <8 x i64> %1018, %1019
  %1021 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1017, 0
  %1022 = insertvalue { <8 x ptr>, <8 x i64> } %1021, <8 x i64> %1020, 1
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %1022, 0
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %1022, 1
  %1025 = getelementptr i8, <8 x ptr> %1023, <8 x i64> %1024
  %1026 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1025, <8 x i1> %95, <8 x float> zeroinitializer)
  %1027 = fmul <8 x float> %993, %1015
  %1028 = fadd <8 x float> %976, %1027
  %1029 = fmul <8 x float> %993, %1026
  %1030 = fadd <8 x float> %978, %1029
  %1031 = fmul <8 x float> %1004, %1015
  %1032 = fadd <8 x float> %980, %1031
  %1033 = fmul <8 x float> %1004, %1026
  %1034 = fadd <8 x float> %982, %1033
  %1035 = add i64 %248, 15
  %tile_snapshot.spill.load454 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load454, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load454, 1
  %.splatinsert455 = insertelement <8 x i64> poison, i64 %1035, i64 0
  %.splat456 = shufflevector <8 x i64> %.splatinsert455, <8 x i64> poison, <8 x i32> zeroinitializer
  %1038 = mul <8 x i64> %.splat456, splat (i64 4)
  %1039 = add <8 x i64> %1037, %1038
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1041 = insertvalue { <8 x ptr>, <8 x i64> } %1040, <8 x i64> %1039, 1
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %1041, 0
  %1043 = extractvalue { <8 x ptr>, <8 x i64> } %1041, 1
  %1044 = getelementptr i8, <8 x ptr> %1042, <8 x i64> %1043
  %1045 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1044, <8 x i1> %95, <8 x float> zeroinitializer)
  %1046 = add i64 %261, 15
  %tile_snapshot.spill.load457 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1047 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load457, 0
  %1048 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load457, 1
  %.splatinsert458 = insertelement <8 x i64> poison, i64 %1046, i64 0
  %.splat459 = shufflevector <8 x i64> %.splatinsert458, <8 x i64> poison, <8 x i32> zeroinitializer
  %1049 = mul <8 x i64> %.splat459, splat (i64 4)
  %1050 = add <8 x i64> %1048, %1049
  %1051 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1047, 0
  %1052 = insertvalue { <8 x ptr>, <8 x i64> } %1051, <8 x i64> %1050, 1
  %1053 = extractvalue { <8 x ptr>, <8 x i64> } %1052, 0
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %1052, 1
  %1055 = getelementptr i8, <8 x ptr> %1053, <8 x i64> %1054
  %1056 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1055, <8 x i1> %95, <8 x float> zeroinitializer)
  %1057 = add i64 %274, 15
  %tile_snapshot.spill.load460 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1058 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load460, 0
  %1059 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load460, 1
  %.splatinsert461 = insertelement <8 x i64> poison, i64 %1057, i64 0
  %.splat462 = shufflevector <8 x i64> %.splatinsert461, <8 x i64> poison, <8 x i32> zeroinitializer
  %1060 = mul <8 x i64> %.splat462, splat (i64 4)
  %1061 = add <8 x i64> %1059, %1060
  %1062 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1058, 0
  %1063 = insertvalue { <8 x ptr>, <8 x i64> } %1062, <8 x i64> %1061, 1
  %1064 = extractvalue { <8 x ptr>, <8 x i64> } %1063, 0
  %1065 = extractvalue { <8 x ptr>, <8 x i64> } %1063, 1
  %1066 = getelementptr i8, <8 x ptr> %1064, <8 x i64> %1065
  %1067 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1066, <8 x i1> %95, <8 x float> zeroinitializer)
  %1068 = add i64 %287, 15
  %tile_snapshot.spill.load463 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1069 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 0
  %1070 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 1
  %.splatinsert464 = insertelement <8 x i64> poison, i64 %1068, i64 0
  %.splat465 = shufflevector <8 x i64> %.splatinsert464, <8 x i64> poison, <8 x i32> zeroinitializer
  %1071 = mul <8 x i64> %.splat465, splat (i64 4)
  %1072 = add <8 x i64> %1070, %1071
  %1073 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1069, 0
  %1074 = insertvalue { <8 x ptr>, <8 x i64> } %1073, <8 x i64> %1072, 1
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %1074, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %1074, 1
  %1077 = getelementptr i8, <8 x ptr> %1075, <8 x i64> %1076
  %1078 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1077, <8 x i1> %95, <8 x float> zeroinitializer)
  %1079 = fmul <8 x float> %1045, %1067
  %1080 = fadd <8 x float> %1028, %1079
  %1081 = fmul <8 x float> %1045, %1078
  %1082 = fadd <8 x float> %1030, %1081
  %1083 = fmul <8 x float> %1056, %1067
  %1084 = fadd <8 x float> %1032, %1083
  %1085 = fmul <8 x float> %1056, %1078
  %1086 = fadd <8 x float> %1034, %1085
  %1087 = add i64 %248, 16
  %tile_snapshot.spill.load466 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load466, 0
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load466, 1
  %.splatinsert467 = insertelement <8 x i64> poison, i64 %1087, i64 0
  %.splat468 = shufflevector <8 x i64> %.splatinsert467, <8 x i64> poison, <8 x i32> zeroinitializer
  %1090 = mul <8 x i64> %.splat468, splat (i64 4)
  %1091 = add <8 x i64> %1089, %1090
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1088, 0
  %1093 = insertvalue { <8 x ptr>, <8 x i64> } %1092, <8 x i64> %1091, 1
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1093, 0
  %1095 = extractvalue { <8 x ptr>, <8 x i64> } %1093, 1
  %1096 = getelementptr i8, <8 x ptr> %1094, <8 x i64> %1095
  %1097 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1096, <8 x i1> %95, <8 x float> zeroinitializer)
  %1098 = add i64 %261, 16
  %tile_snapshot.spill.load469 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1099 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load469, 0
  %1100 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load469, 1
  %.splatinsert470 = insertelement <8 x i64> poison, i64 %1098, i64 0
  %.splat471 = shufflevector <8 x i64> %.splatinsert470, <8 x i64> poison, <8 x i32> zeroinitializer
  %1101 = mul <8 x i64> %.splat471, splat (i64 4)
  %1102 = add <8 x i64> %1100, %1101
  %1103 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1099, 0
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } %1103, <8 x i64> %1102, 1
  %1105 = extractvalue { <8 x ptr>, <8 x i64> } %1104, 0
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %1104, 1
  %1107 = getelementptr i8, <8 x ptr> %1105, <8 x i64> %1106
  %1108 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1107, <8 x i1> %95, <8 x float> zeroinitializer)
  %1109 = add i64 %274, 16
  %tile_snapshot.spill.load472 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 0
  %1111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 1
  %.splatinsert473 = insertelement <8 x i64> poison, i64 %1109, i64 0
  %.splat474 = shufflevector <8 x i64> %.splatinsert473, <8 x i64> poison, <8 x i32> zeroinitializer
  %1112 = mul <8 x i64> %.splat474, splat (i64 4)
  %1113 = add <8 x i64> %1111, %1112
  %1114 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1110, 0
  %1115 = insertvalue { <8 x ptr>, <8 x i64> } %1114, <8 x i64> %1113, 1
  %1116 = extractvalue { <8 x ptr>, <8 x i64> } %1115, 0
  %1117 = extractvalue { <8 x ptr>, <8 x i64> } %1115, 1
  %1118 = getelementptr i8, <8 x ptr> %1116, <8 x i64> %1117
  %1119 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1118, <8 x i1> %95, <8 x float> zeroinitializer)
  %1120 = add i64 %287, 16
  %tile_snapshot.spill.load475 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1121 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load475, 0
  %1122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load475, 1
  %.splatinsert476 = insertelement <8 x i64> poison, i64 %1120, i64 0
  %.splat477 = shufflevector <8 x i64> %.splatinsert476, <8 x i64> poison, <8 x i32> zeroinitializer
  %1123 = mul <8 x i64> %.splat477, splat (i64 4)
  %1124 = add <8 x i64> %1122, %1123
  %1125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1121, 0
  %1126 = insertvalue { <8 x ptr>, <8 x i64> } %1125, <8 x i64> %1124, 1
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %1126, 0
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %1126, 1
  %1129 = getelementptr i8, <8 x ptr> %1127, <8 x i64> %1128
  %1130 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1129, <8 x i1> %95, <8 x float> zeroinitializer)
  %1131 = fmul <8 x float> %1097, %1119
  %1132 = fadd <8 x float> %1080, %1131
  %1133 = fmul <8 x float> %1097, %1130
  %1134 = fadd <8 x float> %1082, %1133
  %1135 = fmul <8 x float> %1108, %1119
  %1136 = fadd <8 x float> %1084, %1135
  %1137 = fmul <8 x float> %1108, %1130
  %1138 = fadd <8 x float> %1086, %1137
  %1139 = add i64 %248, 17
  %tile_snapshot.spill.load478 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 1
  %.splatinsert479 = insertelement <8 x i64> poison, i64 %1139, i64 0
  %.splat480 = shufflevector <8 x i64> %.splatinsert479, <8 x i64> poison, <8 x i32> zeroinitializer
  %1142 = mul <8 x i64> %.splat480, splat (i64 4)
  %1143 = add <8 x i64> %1141, %1142
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1145 = insertvalue { <8 x ptr>, <8 x i64> } %1144, <8 x i64> %1143, 1
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1145, 0
  %1147 = extractvalue { <8 x ptr>, <8 x i64> } %1145, 1
  %1148 = getelementptr i8, <8 x ptr> %1146, <8 x i64> %1147
  %1149 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1148, <8 x i1> %95, <8 x float> zeroinitializer)
  %1150 = add i64 %261, 17
  %tile_snapshot.spill.load481 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load481, 0
  %1152 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load481, 1
  %.splatinsert482 = insertelement <8 x i64> poison, i64 %1150, i64 0
  %.splat483 = shufflevector <8 x i64> %.splatinsert482, <8 x i64> poison, <8 x i32> zeroinitializer
  %1153 = mul <8 x i64> %.splat483, splat (i64 4)
  %1154 = add <8 x i64> %1152, %1153
  %1155 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1151, 0
  %1156 = insertvalue { <8 x ptr>, <8 x i64> } %1155, <8 x i64> %1154, 1
  %1157 = extractvalue { <8 x ptr>, <8 x i64> } %1156, 0
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %1156, 1
  %1159 = getelementptr i8, <8 x ptr> %1157, <8 x i64> %1158
  %1160 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1159, <8 x i1> %95, <8 x float> zeroinitializer)
  %1161 = add i64 %274, 17
  %tile_snapshot.spill.load484 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load484, 0
  %1163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load484, 1
  %.splatinsert485 = insertelement <8 x i64> poison, i64 %1161, i64 0
  %.splat486 = shufflevector <8 x i64> %.splatinsert485, <8 x i64> poison, <8 x i32> zeroinitializer
  %1164 = mul <8 x i64> %.splat486, splat (i64 4)
  %1165 = add <8 x i64> %1163, %1164
  %1166 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1162, 0
  %1167 = insertvalue { <8 x ptr>, <8 x i64> } %1166, <8 x i64> %1165, 1
  %1168 = extractvalue { <8 x ptr>, <8 x i64> } %1167, 0
  %1169 = extractvalue { <8 x ptr>, <8 x i64> } %1167, 1
  %1170 = getelementptr i8, <8 x ptr> %1168, <8 x i64> %1169
  %1171 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1170, <8 x i1> %95, <8 x float> zeroinitializer)
  %1172 = add i64 %287, 17
  %tile_snapshot.spill.load487 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load487, 0
  %1174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load487, 1
  %.splatinsert488 = insertelement <8 x i64> poison, i64 %1172, i64 0
  %.splat489 = shufflevector <8 x i64> %.splatinsert488, <8 x i64> poison, <8 x i32> zeroinitializer
  %1175 = mul <8 x i64> %.splat489, splat (i64 4)
  %1176 = add <8 x i64> %1174, %1175
  %1177 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1173, 0
  %1178 = insertvalue { <8 x ptr>, <8 x i64> } %1177, <8 x i64> %1176, 1
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %1178, 0
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %1178, 1
  %1181 = getelementptr i8, <8 x ptr> %1179, <8 x i64> %1180
  %1182 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1181, <8 x i1> %95, <8 x float> zeroinitializer)
  %1183 = fmul <8 x float> %1149, %1171
  %1184 = fadd <8 x float> %1132, %1183
  %1185 = fmul <8 x float> %1149, %1182
  %1186 = fadd <8 x float> %1134, %1185
  %1187 = fmul <8 x float> %1160, %1171
  %1188 = fadd <8 x float> %1136, %1187
  %1189 = fmul <8 x float> %1160, %1182
  %1190 = fadd <8 x float> %1138, %1189
  %1191 = add i64 %248, 18
  %tile_snapshot.spill.load490 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load490, 0
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load490, 1
  %.splatinsert491 = insertelement <8 x i64> poison, i64 %1191, i64 0
  %.splat492 = shufflevector <8 x i64> %.splatinsert491, <8 x i64> poison, <8 x i32> zeroinitializer
  %1194 = mul <8 x i64> %.splat492, splat (i64 4)
  %1195 = add <8 x i64> %1193, %1194
  %1196 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1192, 0
  %1197 = insertvalue { <8 x ptr>, <8 x i64> } %1196, <8 x i64> %1195, 1
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1197, 0
  %1199 = extractvalue { <8 x ptr>, <8 x i64> } %1197, 1
  %1200 = getelementptr i8, <8 x ptr> %1198, <8 x i64> %1199
  %1201 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1200, <8 x i1> %95, <8 x float> zeroinitializer)
  %1202 = add i64 %261, 18
  %tile_snapshot.spill.load493 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load493, 0
  %1204 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load493, 1
  %.splatinsert494 = insertelement <8 x i64> poison, i64 %1202, i64 0
  %.splat495 = shufflevector <8 x i64> %.splatinsert494, <8 x i64> poison, <8 x i32> zeroinitializer
  %1205 = mul <8 x i64> %.splat495, splat (i64 4)
  %1206 = add <8 x i64> %1204, %1205
  %1207 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1203, 0
  %1208 = insertvalue { <8 x ptr>, <8 x i64> } %1207, <8 x i64> %1206, 1
  %1209 = extractvalue { <8 x ptr>, <8 x i64> } %1208, 0
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %1208, 1
  %1211 = getelementptr i8, <8 x ptr> %1209, <8 x i64> %1210
  %1212 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1211, <8 x i1> %95, <8 x float> zeroinitializer)
  %1213 = add i64 %274, 18
  %tile_snapshot.spill.load496 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load496, 0
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load496, 1
  %.splatinsert497 = insertelement <8 x i64> poison, i64 %1213, i64 0
  %.splat498 = shufflevector <8 x i64> %.splatinsert497, <8 x i64> poison, <8 x i32> zeroinitializer
  %1216 = mul <8 x i64> %.splat498, splat (i64 4)
  %1217 = add <8 x i64> %1215, %1216
  %1218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1214, 0
  %1219 = insertvalue { <8 x ptr>, <8 x i64> } %1218, <8 x i64> %1217, 1
  %1220 = extractvalue { <8 x ptr>, <8 x i64> } %1219, 0
  %1221 = extractvalue { <8 x ptr>, <8 x i64> } %1219, 1
  %1222 = getelementptr i8, <8 x ptr> %1220, <8 x i64> %1221
  %1223 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1222, <8 x i1> %95, <8 x float> zeroinitializer)
  %1224 = add i64 %287, 18
  %tile_snapshot.spill.load499 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load499, 0
  %1226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load499, 1
  %.splatinsert500 = insertelement <8 x i64> poison, i64 %1224, i64 0
  %.splat501 = shufflevector <8 x i64> %.splatinsert500, <8 x i64> poison, <8 x i32> zeroinitializer
  %1227 = mul <8 x i64> %.splat501, splat (i64 4)
  %1228 = add <8 x i64> %1226, %1227
  %1229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1225, 0
  %1230 = insertvalue { <8 x ptr>, <8 x i64> } %1229, <8 x i64> %1228, 1
  %1231 = extractvalue { <8 x ptr>, <8 x i64> } %1230, 0
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %1230, 1
  %1233 = getelementptr i8, <8 x ptr> %1231, <8 x i64> %1232
  %1234 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1233, <8 x i1> %95, <8 x float> zeroinitializer)
  %1235 = fmul <8 x float> %1201, %1223
  %1236 = fadd <8 x float> %1184, %1235
  %1237 = fmul <8 x float> %1201, %1234
  %1238 = fadd <8 x float> %1186, %1237
  %1239 = fmul <8 x float> %1212, %1223
  %1240 = fadd <8 x float> %1188, %1239
  %1241 = fmul <8 x float> %1212, %1234
  %1242 = fadd <8 x float> %1190, %1241
  %1243 = add i64 %248, 19
  %tile_snapshot.spill.load502 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load502, 0
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load502, 1
  %.splatinsert503 = insertelement <8 x i64> poison, i64 %1243, i64 0
  %.splat504 = shufflevector <8 x i64> %.splatinsert503, <8 x i64> poison, <8 x i32> zeroinitializer
  %1246 = mul <8 x i64> %.splat504, splat (i64 4)
  %1247 = add <8 x i64> %1245, %1246
  %1248 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1244, 0
  %1249 = insertvalue { <8 x ptr>, <8 x i64> } %1248, <8 x i64> %1247, 1
  %1250 = extractvalue { <8 x ptr>, <8 x i64> } %1249, 0
  %1251 = extractvalue { <8 x ptr>, <8 x i64> } %1249, 1
  %1252 = getelementptr i8, <8 x ptr> %1250, <8 x i64> %1251
  %1253 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1252, <8 x i1> %95, <8 x float> zeroinitializer)
  %1254 = add i64 %261, 19
  %tile_snapshot.spill.load505 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load505, 0
  %1256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load505, 1
  %.splatinsert506 = insertelement <8 x i64> poison, i64 %1254, i64 0
  %.splat507 = shufflevector <8 x i64> %.splatinsert506, <8 x i64> poison, <8 x i32> zeroinitializer
  %1257 = mul <8 x i64> %.splat507, splat (i64 4)
  %1258 = add <8 x i64> %1256, %1257
  %1259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1255, 0
  %1260 = insertvalue { <8 x ptr>, <8 x i64> } %1259, <8 x i64> %1258, 1
  %1261 = extractvalue { <8 x ptr>, <8 x i64> } %1260, 0
  %1262 = extractvalue { <8 x ptr>, <8 x i64> } %1260, 1
  %1263 = getelementptr i8, <8 x ptr> %1261, <8 x i64> %1262
  %1264 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1263, <8 x i1> %95, <8 x float> zeroinitializer)
  %1265 = add i64 %274, 19
  %tile_snapshot.spill.load508 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load508, 0
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load508, 1
  %.splatinsert509 = insertelement <8 x i64> poison, i64 %1265, i64 0
  %.splat510 = shufflevector <8 x i64> %.splatinsert509, <8 x i64> poison, <8 x i32> zeroinitializer
  %1268 = mul <8 x i64> %.splat510, splat (i64 4)
  %1269 = add <8 x i64> %1267, %1268
  %1270 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1266, 0
  %1271 = insertvalue { <8 x ptr>, <8 x i64> } %1270, <8 x i64> %1269, 1
  %1272 = extractvalue { <8 x ptr>, <8 x i64> } %1271, 0
  %1273 = extractvalue { <8 x ptr>, <8 x i64> } %1271, 1
  %1274 = getelementptr i8, <8 x ptr> %1272, <8 x i64> %1273
  %1275 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1274, <8 x i1> %95, <8 x float> zeroinitializer)
  %1276 = add i64 %287, 19
  %tile_snapshot.spill.load511 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load511, 0
  %1278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load511, 1
  %.splatinsert512 = insertelement <8 x i64> poison, i64 %1276, i64 0
  %.splat513 = shufflevector <8 x i64> %.splatinsert512, <8 x i64> poison, <8 x i32> zeroinitializer
  %1279 = mul <8 x i64> %.splat513, splat (i64 4)
  %1280 = add <8 x i64> %1278, %1279
  %1281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1277, 0
  %1282 = insertvalue { <8 x ptr>, <8 x i64> } %1281, <8 x i64> %1280, 1
  %1283 = extractvalue { <8 x ptr>, <8 x i64> } %1282, 0
  %1284 = extractvalue { <8 x ptr>, <8 x i64> } %1282, 1
  %1285 = getelementptr i8, <8 x ptr> %1283, <8 x i64> %1284
  %1286 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1285, <8 x i1> %95, <8 x float> zeroinitializer)
  %1287 = fmul <8 x float> %1253, %1275
  %1288 = fadd <8 x float> %1236, %1287
  %1289 = fmul <8 x float> %1253, %1286
  %1290 = fadd <8 x float> %1238, %1289
  %1291 = fmul <8 x float> %1264, %1275
  %1292 = fadd <8 x float> %1240, %1291
  %1293 = fmul <8 x float> %1264, %1286
  %1294 = fadd <8 x float> %1242, %1293
  %1295 = add i64 %248, 20
  %tile_snapshot.spill.load514 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1296 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load514, 0
  %1297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load514, 1
  %.splatinsert515 = insertelement <8 x i64> poison, i64 %1295, i64 0
  %.splat516 = shufflevector <8 x i64> %.splatinsert515, <8 x i64> poison, <8 x i32> zeroinitializer
  %1298 = mul <8 x i64> %.splat516, splat (i64 4)
  %1299 = add <8 x i64> %1297, %1298
  %1300 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1296, 0
  %1301 = insertvalue { <8 x ptr>, <8 x i64> } %1300, <8 x i64> %1299, 1
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %1301, 0
  %1303 = extractvalue { <8 x ptr>, <8 x i64> } %1301, 1
  %1304 = getelementptr i8, <8 x ptr> %1302, <8 x i64> %1303
  %1305 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1304, <8 x i1> %95, <8 x float> zeroinitializer)
  %1306 = add i64 %261, 20
  %tile_snapshot.spill.load517 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load517, 0
  %1308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load517, 1
  %.splatinsert518 = insertelement <8 x i64> poison, i64 %1306, i64 0
  %.splat519 = shufflevector <8 x i64> %.splatinsert518, <8 x i64> poison, <8 x i32> zeroinitializer
  %1309 = mul <8 x i64> %.splat519, splat (i64 4)
  %1310 = add <8 x i64> %1308, %1309
  %1311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1307, 0
  %1312 = insertvalue { <8 x ptr>, <8 x i64> } %1311, <8 x i64> %1310, 1
  %1313 = extractvalue { <8 x ptr>, <8 x i64> } %1312, 0
  %1314 = extractvalue { <8 x ptr>, <8 x i64> } %1312, 1
  %1315 = getelementptr i8, <8 x ptr> %1313, <8 x i64> %1314
  %1316 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1315, <8 x i1> %95, <8 x float> zeroinitializer)
  %1317 = add i64 %274, 20
  %tile_snapshot.spill.load520 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 0
  %1319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 1
  %.splatinsert521 = insertelement <8 x i64> poison, i64 %1317, i64 0
  %.splat522 = shufflevector <8 x i64> %.splatinsert521, <8 x i64> poison, <8 x i32> zeroinitializer
  %1320 = mul <8 x i64> %.splat522, splat (i64 4)
  %1321 = add <8 x i64> %1319, %1320
  %1322 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1318, 0
  %1323 = insertvalue { <8 x ptr>, <8 x i64> } %1322, <8 x i64> %1321, 1
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %1323, 0
  %1325 = extractvalue { <8 x ptr>, <8 x i64> } %1323, 1
  %1326 = getelementptr i8, <8 x ptr> %1324, <8 x i64> %1325
  %1327 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1326, <8 x i1> %95, <8 x float> zeroinitializer)
  %1328 = add i64 %287, 20
  %tile_snapshot.spill.load523 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1329 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load523, 0
  %1330 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load523, 1
  %.splatinsert524 = insertelement <8 x i64> poison, i64 %1328, i64 0
  %.splat525 = shufflevector <8 x i64> %.splatinsert524, <8 x i64> poison, <8 x i32> zeroinitializer
  %1331 = mul <8 x i64> %.splat525, splat (i64 4)
  %1332 = add <8 x i64> %1330, %1331
  %1333 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1329, 0
  %1334 = insertvalue { <8 x ptr>, <8 x i64> } %1333, <8 x i64> %1332, 1
  %1335 = extractvalue { <8 x ptr>, <8 x i64> } %1334, 0
  %1336 = extractvalue { <8 x ptr>, <8 x i64> } %1334, 1
  %1337 = getelementptr i8, <8 x ptr> %1335, <8 x i64> %1336
  %1338 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1337, <8 x i1> %95, <8 x float> zeroinitializer)
  %1339 = fmul <8 x float> %1305, %1327
  %1340 = fadd <8 x float> %1288, %1339
  %1341 = fmul <8 x float> %1305, %1338
  %1342 = fadd <8 x float> %1290, %1341
  %1343 = fmul <8 x float> %1316, %1327
  %1344 = fadd <8 x float> %1292, %1343
  %1345 = fmul <8 x float> %1316, %1338
  %1346 = fadd <8 x float> %1294, %1345
  %1347 = add i64 %248, 21
  %tile_snapshot.spill.load526 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1348 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load526, 0
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load526, 1
  %.splatinsert527 = insertelement <8 x i64> poison, i64 %1347, i64 0
  %.splat528 = shufflevector <8 x i64> %.splatinsert527, <8 x i64> poison, <8 x i32> zeroinitializer
  %1350 = mul <8 x i64> %.splat528, splat (i64 4)
  %1351 = add <8 x i64> %1349, %1350
  %1352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1348, 0
  %1353 = insertvalue { <8 x ptr>, <8 x i64> } %1352, <8 x i64> %1351, 1
  %1354 = extractvalue { <8 x ptr>, <8 x i64> } %1353, 0
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %1353, 1
  %1356 = getelementptr i8, <8 x ptr> %1354, <8 x i64> %1355
  %1357 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1356, <8 x i1> %95, <8 x float> zeroinitializer)
  %1358 = add i64 %261, 21
  %tile_snapshot.spill.load529 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1359 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load529, 0
  %1360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load529, 1
  %.splatinsert530 = insertelement <8 x i64> poison, i64 %1358, i64 0
  %.splat531 = shufflevector <8 x i64> %.splatinsert530, <8 x i64> poison, <8 x i32> zeroinitializer
  %1361 = mul <8 x i64> %.splat531, splat (i64 4)
  %1362 = add <8 x i64> %1360, %1361
  %1363 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1359, 0
  %1364 = insertvalue { <8 x ptr>, <8 x i64> } %1363, <8 x i64> %1362, 1
  %1365 = extractvalue { <8 x ptr>, <8 x i64> } %1364, 0
  %1366 = extractvalue { <8 x ptr>, <8 x i64> } %1364, 1
  %1367 = getelementptr i8, <8 x ptr> %1365, <8 x i64> %1366
  %1368 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1367, <8 x i1> %95, <8 x float> zeroinitializer)
  %1369 = add i64 %274, 21
  %tile_snapshot.spill.load532 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load532, 0
  %1371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load532, 1
  %.splatinsert533 = insertelement <8 x i64> poison, i64 %1369, i64 0
  %.splat534 = shufflevector <8 x i64> %.splatinsert533, <8 x i64> poison, <8 x i32> zeroinitializer
  %1372 = mul <8 x i64> %.splat534, splat (i64 4)
  %1373 = add <8 x i64> %1371, %1372
  %1374 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1370, 0
  %1375 = insertvalue { <8 x ptr>, <8 x i64> } %1374, <8 x i64> %1373, 1
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %1375, 0
  %1377 = extractvalue { <8 x ptr>, <8 x i64> } %1375, 1
  %1378 = getelementptr i8, <8 x ptr> %1376, <8 x i64> %1377
  %1379 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1378, <8 x i1> %95, <8 x float> zeroinitializer)
  %1380 = add i64 %287, 21
  %tile_snapshot.spill.load535 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load535, 0
  %1382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load535, 1
  %.splatinsert536 = insertelement <8 x i64> poison, i64 %1380, i64 0
  %.splat537 = shufflevector <8 x i64> %.splatinsert536, <8 x i64> poison, <8 x i32> zeroinitializer
  %1383 = mul <8 x i64> %.splat537, splat (i64 4)
  %1384 = add <8 x i64> %1382, %1383
  %1385 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1381, 0
  %1386 = insertvalue { <8 x ptr>, <8 x i64> } %1385, <8 x i64> %1384, 1
  %1387 = extractvalue { <8 x ptr>, <8 x i64> } %1386, 0
  %1388 = extractvalue { <8 x ptr>, <8 x i64> } %1386, 1
  %1389 = getelementptr i8, <8 x ptr> %1387, <8 x i64> %1388
  %1390 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1389, <8 x i1> %95, <8 x float> zeroinitializer)
  %1391 = fmul <8 x float> %1357, %1379
  %1392 = fadd <8 x float> %1340, %1391
  %1393 = fmul <8 x float> %1357, %1390
  %1394 = fadd <8 x float> %1342, %1393
  %1395 = fmul <8 x float> %1368, %1379
  %1396 = fadd <8 x float> %1344, %1395
  %1397 = fmul <8 x float> %1368, %1390
  %1398 = fadd <8 x float> %1346, %1397
  %1399 = add i64 %248, 22
  %tile_snapshot.spill.load538 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1400 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load538, 0
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load538, 1
  %.splatinsert539 = insertelement <8 x i64> poison, i64 %1399, i64 0
  %.splat540 = shufflevector <8 x i64> %.splatinsert539, <8 x i64> poison, <8 x i32> zeroinitializer
  %1402 = mul <8 x i64> %.splat540, splat (i64 4)
  %1403 = add <8 x i64> %1401, %1402
  %1404 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1400, 0
  %1405 = insertvalue { <8 x ptr>, <8 x i64> } %1404, <8 x i64> %1403, 1
  %1406 = extractvalue { <8 x ptr>, <8 x i64> } %1405, 0
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %1405, 1
  %1408 = getelementptr i8, <8 x ptr> %1406, <8 x i64> %1407
  %1409 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1408, <8 x i1> %95, <8 x float> zeroinitializer)
  %1410 = add i64 %261, 22
  %tile_snapshot.spill.load541 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1411 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load541, 0
  %1412 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load541, 1
  %.splatinsert542 = insertelement <8 x i64> poison, i64 %1410, i64 0
  %.splat543 = shufflevector <8 x i64> %.splatinsert542, <8 x i64> poison, <8 x i32> zeroinitializer
  %1413 = mul <8 x i64> %.splat543, splat (i64 4)
  %1414 = add <8 x i64> %1412, %1413
  %1415 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1411, 0
  %1416 = insertvalue { <8 x ptr>, <8 x i64> } %1415, <8 x i64> %1414, 1
  %1417 = extractvalue { <8 x ptr>, <8 x i64> } %1416, 0
  %1418 = extractvalue { <8 x ptr>, <8 x i64> } %1416, 1
  %1419 = getelementptr i8, <8 x ptr> %1417, <8 x i64> %1418
  %1420 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1419, <8 x i1> %95, <8 x float> zeroinitializer)
  %1421 = add i64 %274, 22
  %tile_snapshot.spill.load544 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load544, 0
  %1423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load544, 1
  %.splatinsert545 = insertelement <8 x i64> poison, i64 %1421, i64 0
  %.splat546 = shufflevector <8 x i64> %.splatinsert545, <8 x i64> poison, <8 x i32> zeroinitializer
  %1424 = mul <8 x i64> %.splat546, splat (i64 4)
  %1425 = add <8 x i64> %1423, %1424
  %1426 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1422, 0
  %1427 = insertvalue { <8 x ptr>, <8 x i64> } %1426, <8 x i64> %1425, 1
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %1427, 0
  %1429 = extractvalue { <8 x ptr>, <8 x i64> } %1427, 1
  %1430 = getelementptr i8, <8 x ptr> %1428, <8 x i64> %1429
  %1431 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1430, <8 x i1> %95, <8 x float> zeroinitializer)
  %1432 = add i64 %287, 22
  %tile_snapshot.spill.load547 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 0
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 1
  %.splatinsert548 = insertelement <8 x i64> poison, i64 %1432, i64 0
  %.splat549 = shufflevector <8 x i64> %.splatinsert548, <8 x i64> poison, <8 x i32> zeroinitializer
  %1435 = mul <8 x i64> %.splat549, splat (i64 4)
  %1436 = add <8 x i64> %1434, %1435
  %1437 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1433, 0
  %1438 = insertvalue { <8 x ptr>, <8 x i64> } %1437, <8 x i64> %1436, 1
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %1438, 0
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %1438, 1
  %1441 = getelementptr i8, <8 x ptr> %1439, <8 x i64> %1440
  %1442 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1441, <8 x i1> %95, <8 x float> zeroinitializer)
  %1443 = fmul <8 x float> %1409, %1431
  %1444 = fadd <8 x float> %1392, %1443
  %1445 = fmul <8 x float> %1409, %1442
  %1446 = fadd <8 x float> %1394, %1445
  %1447 = fmul <8 x float> %1420, %1431
  %1448 = fadd <8 x float> %1396, %1447
  %1449 = fmul <8 x float> %1420, %1442
  %1450 = fadd <8 x float> %1398, %1449
  %1451 = add i64 %248, 23
  %tile_snapshot.spill.load550 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load550, 0
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load550, 1
  %.splatinsert551 = insertelement <8 x i64> poison, i64 %1451, i64 0
  %.splat552 = shufflevector <8 x i64> %.splatinsert551, <8 x i64> poison, <8 x i32> zeroinitializer
  %1454 = mul <8 x i64> %.splat552, splat (i64 4)
  %1455 = add <8 x i64> %1453, %1454
  %1456 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1452, 0
  %1457 = insertvalue { <8 x ptr>, <8 x i64> } %1456, <8 x i64> %1455, 1
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 0
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 1
  %1460 = getelementptr i8, <8 x ptr> %1458, <8 x i64> %1459
  %1461 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1460, <8 x i1> %95, <8 x float> zeroinitializer)
  %1462 = add i64 %261, 23
  %tile_snapshot.spill.load553 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1463 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load553, 0
  %1464 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load553, 1
  %.splatinsert554 = insertelement <8 x i64> poison, i64 %1462, i64 0
  %.splat555 = shufflevector <8 x i64> %.splatinsert554, <8 x i64> poison, <8 x i32> zeroinitializer
  %1465 = mul <8 x i64> %.splat555, splat (i64 4)
  %1466 = add <8 x i64> %1464, %1465
  %1467 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1463, 0
  %1468 = insertvalue { <8 x ptr>, <8 x i64> } %1467, <8 x i64> %1466, 1
  %1469 = extractvalue { <8 x ptr>, <8 x i64> } %1468, 0
  %1470 = extractvalue { <8 x ptr>, <8 x i64> } %1468, 1
  %1471 = getelementptr i8, <8 x ptr> %1469, <8 x i64> %1470
  %1472 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1471, <8 x i1> %95, <8 x float> zeroinitializer)
  %1473 = add i64 %274, 23
  %tile_snapshot.spill.load556 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1474 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load556, 0
  %1475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load556, 1
  %.splatinsert557 = insertelement <8 x i64> poison, i64 %1473, i64 0
  %.splat558 = shufflevector <8 x i64> %.splatinsert557, <8 x i64> poison, <8 x i32> zeroinitializer
  %1476 = mul <8 x i64> %.splat558, splat (i64 4)
  %1477 = add <8 x i64> %1475, %1476
  %1478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1474, 0
  %1479 = insertvalue { <8 x ptr>, <8 x i64> } %1478, <8 x i64> %1477, 1
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %1479, 0
  %1481 = extractvalue { <8 x ptr>, <8 x i64> } %1479, 1
  %1482 = getelementptr i8, <8 x ptr> %1480, <8 x i64> %1481
  %1483 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1482, <8 x i1> %95, <8 x float> zeroinitializer)
  %1484 = add i64 %287, 23
  %tile_snapshot.spill.load559 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load559, 0
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load559, 1
  %.splatinsert560 = insertelement <8 x i64> poison, i64 %1484, i64 0
  %.splat561 = shufflevector <8 x i64> %.splatinsert560, <8 x i64> poison, <8 x i32> zeroinitializer
  %1487 = mul <8 x i64> %.splat561, splat (i64 4)
  %1488 = add <8 x i64> %1486, %1487
  %1489 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1485, 0
  %1490 = insertvalue { <8 x ptr>, <8 x i64> } %1489, <8 x i64> %1488, 1
  %1491 = extractvalue { <8 x ptr>, <8 x i64> } %1490, 0
  %1492 = extractvalue { <8 x ptr>, <8 x i64> } %1490, 1
  %1493 = getelementptr i8, <8 x ptr> %1491, <8 x i64> %1492
  %1494 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1493, <8 x i1> %95, <8 x float> zeroinitializer)
  %1495 = fmul <8 x float> %1461, %1483
  %1496 = fadd <8 x float> %1444, %1495
  %1497 = fmul <8 x float> %1461, %1494
  %1498 = fadd <8 x float> %1446, %1497
  %1499 = fmul <8 x float> %1472, %1483
  %1500 = fadd <8 x float> %1448, %1499
  %1501 = fmul <8 x float> %1472, %1494
  %1502 = fadd <8 x float> %1450, %1501
  %1503 = add i64 %248, 24
  %tile_snapshot.spill.load562 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1504 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load562, 0
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load562, 1
  %.splatinsert563 = insertelement <8 x i64> poison, i64 %1503, i64 0
  %.splat564 = shufflevector <8 x i64> %.splatinsert563, <8 x i64> poison, <8 x i32> zeroinitializer
  %1506 = mul <8 x i64> %.splat564, splat (i64 4)
  %1507 = add <8 x i64> %1505, %1506
  %1508 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1504, 0
  %1509 = insertvalue { <8 x ptr>, <8 x i64> } %1508, <8 x i64> %1507, 1
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %1509, 0
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %1509, 1
  %1512 = getelementptr i8, <8 x ptr> %1510, <8 x i64> %1511
  %1513 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1512, <8 x i1> %95, <8 x float> zeroinitializer)
  %1514 = add i64 %261, 24
  %tile_snapshot.spill.load565 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1515 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load565, 0
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load565, 1
  %.splatinsert566 = insertelement <8 x i64> poison, i64 %1514, i64 0
  %.splat567 = shufflevector <8 x i64> %.splatinsert566, <8 x i64> poison, <8 x i32> zeroinitializer
  %1517 = mul <8 x i64> %.splat567, splat (i64 4)
  %1518 = add <8 x i64> %1516, %1517
  %1519 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1515, 0
  %1520 = insertvalue { <8 x ptr>, <8 x i64> } %1519, <8 x i64> %1518, 1
  %1521 = extractvalue { <8 x ptr>, <8 x i64> } %1520, 0
  %1522 = extractvalue { <8 x ptr>, <8 x i64> } %1520, 1
  %1523 = getelementptr i8, <8 x ptr> %1521, <8 x i64> %1522
  %1524 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1523, <8 x i1> %95, <8 x float> zeroinitializer)
  %1525 = add i64 %274, 24
  %tile_snapshot.spill.load568 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1526 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load568, 0
  %1527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load568, 1
  %.splatinsert569 = insertelement <8 x i64> poison, i64 %1525, i64 0
  %.splat570 = shufflevector <8 x i64> %.splatinsert569, <8 x i64> poison, <8 x i32> zeroinitializer
  %1528 = mul <8 x i64> %.splat570, splat (i64 4)
  %1529 = add <8 x i64> %1527, %1528
  %1530 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1526, 0
  %1531 = insertvalue { <8 x ptr>, <8 x i64> } %1530, <8 x i64> %1529, 1
  %1532 = extractvalue { <8 x ptr>, <8 x i64> } %1531, 0
  %1533 = extractvalue { <8 x ptr>, <8 x i64> } %1531, 1
  %1534 = getelementptr i8, <8 x ptr> %1532, <8 x i64> %1533
  %1535 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1534, <8 x i1> %95, <8 x float> zeroinitializer)
  %1536 = add i64 %287, 24
  %tile_snapshot.spill.load571 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load571, 0
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load571, 1
  %.splatinsert572 = insertelement <8 x i64> poison, i64 %1536, i64 0
  %.splat573 = shufflevector <8 x i64> %.splatinsert572, <8 x i64> poison, <8 x i32> zeroinitializer
  %1539 = mul <8 x i64> %.splat573, splat (i64 4)
  %1540 = add <8 x i64> %1538, %1539
  %1541 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1537, 0
  %1542 = insertvalue { <8 x ptr>, <8 x i64> } %1541, <8 x i64> %1540, 1
  %1543 = extractvalue { <8 x ptr>, <8 x i64> } %1542, 0
  %1544 = extractvalue { <8 x ptr>, <8 x i64> } %1542, 1
  %1545 = getelementptr i8, <8 x ptr> %1543, <8 x i64> %1544
  %1546 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1545, <8 x i1> %95, <8 x float> zeroinitializer)
  %1547 = fmul <8 x float> %1513, %1535
  %1548 = fadd <8 x float> %1496, %1547
  %1549 = fmul <8 x float> %1513, %1546
  %1550 = fadd <8 x float> %1498, %1549
  %1551 = fmul <8 x float> %1524, %1535
  %1552 = fadd <8 x float> %1500, %1551
  %1553 = fmul <8 x float> %1524, %1546
  %1554 = fadd <8 x float> %1502, %1553
  %1555 = add i64 %248, 25
  %tile_snapshot.spill.load574 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load574, 0
  %1557 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load574, 1
  %.splatinsert575 = insertelement <8 x i64> poison, i64 %1555, i64 0
  %.splat576 = shufflevector <8 x i64> %.splatinsert575, <8 x i64> poison, <8 x i32> zeroinitializer
  %1558 = mul <8 x i64> %.splat576, splat (i64 4)
  %1559 = add <8 x i64> %1557, %1558
  %1560 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1556, 0
  %1561 = insertvalue { <8 x ptr>, <8 x i64> } %1560, <8 x i64> %1559, 1
  %1562 = extractvalue { <8 x ptr>, <8 x i64> } %1561, 0
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %1561, 1
  %1564 = getelementptr i8, <8 x ptr> %1562, <8 x i64> %1563
  %1565 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1564, <8 x i1> %95, <8 x float> zeroinitializer)
  %1566 = add i64 %261, 25
  %tile_snapshot.spill.load577 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1567 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load577, 0
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load577, 1
  %.splatinsert578 = insertelement <8 x i64> poison, i64 %1566, i64 0
  %.splat579 = shufflevector <8 x i64> %.splatinsert578, <8 x i64> poison, <8 x i32> zeroinitializer
  %1569 = mul <8 x i64> %.splat579, splat (i64 4)
  %1570 = add <8 x i64> %1568, %1569
  %1571 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1567, 0
  %1572 = insertvalue { <8 x ptr>, <8 x i64> } %1571, <8 x i64> %1570, 1
  %1573 = extractvalue { <8 x ptr>, <8 x i64> } %1572, 0
  %1574 = extractvalue { <8 x ptr>, <8 x i64> } %1572, 1
  %1575 = getelementptr i8, <8 x ptr> %1573, <8 x i64> %1574
  %1576 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1575, <8 x i1> %95, <8 x float> zeroinitializer)
  %1577 = add i64 %274, 25
  %tile_snapshot.spill.load580 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1578 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load580, 0
  %1579 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load580, 1
  %.splatinsert581 = insertelement <8 x i64> poison, i64 %1577, i64 0
  %.splat582 = shufflevector <8 x i64> %.splatinsert581, <8 x i64> poison, <8 x i32> zeroinitializer
  %1580 = mul <8 x i64> %.splat582, splat (i64 4)
  %1581 = add <8 x i64> %1579, %1580
  %1582 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1578, 0
  %1583 = insertvalue { <8 x ptr>, <8 x i64> } %1582, <8 x i64> %1581, 1
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %1583, 0
  %1585 = extractvalue { <8 x ptr>, <8 x i64> } %1583, 1
  %1586 = getelementptr i8, <8 x ptr> %1584, <8 x i64> %1585
  %1587 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1586, <8 x i1> %95, <8 x float> zeroinitializer)
  %1588 = add i64 %287, 25
  %tile_snapshot.spill.load583 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load583, 0
  %1590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load583, 1
  %.splatinsert584 = insertelement <8 x i64> poison, i64 %1588, i64 0
  %.splat585 = shufflevector <8 x i64> %.splatinsert584, <8 x i64> poison, <8 x i32> zeroinitializer
  %1591 = mul <8 x i64> %.splat585, splat (i64 4)
  %1592 = add <8 x i64> %1590, %1591
  %1593 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1589, 0
  %1594 = insertvalue { <8 x ptr>, <8 x i64> } %1593, <8 x i64> %1592, 1
  %1595 = extractvalue { <8 x ptr>, <8 x i64> } %1594, 0
  %1596 = extractvalue { <8 x ptr>, <8 x i64> } %1594, 1
  %1597 = getelementptr i8, <8 x ptr> %1595, <8 x i64> %1596
  %1598 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1597, <8 x i1> %95, <8 x float> zeroinitializer)
  %1599 = fmul <8 x float> %1565, %1587
  %1600 = fadd <8 x float> %1548, %1599
  %1601 = fmul <8 x float> %1565, %1598
  %1602 = fadd <8 x float> %1550, %1601
  %1603 = fmul <8 x float> %1576, %1587
  %1604 = fadd <8 x float> %1552, %1603
  %1605 = fmul <8 x float> %1576, %1598
  %1606 = fadd <8 x float> %1554, %1605
  %1607 = add i64 %248, 26
  %tile_snapshot.spill.load586 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load586, 0
  %1609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load586, 1
  %.splatinsert587 = insertelement <8 x i64> poison, i64 %1607, i64 0
  %.splat588 = shufflevector <8 x i64> %.splatinsert587, <8 x i64> poison, <8 x i32> zeroinitializer
  %1610 = mul <8 x i64> %.splat588, splat (i64 4)
  %1611 = add <8 x i64> %1609, %1610
  %1612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1608, 0
  %1613 = insertvalue { <8 x ptr>, <8 x i64> } %1612, <8 x i64> %1611, 1
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %1613, 0
  %1615 = extractvalue { <8 x ptr>, <8 x i64> } %1613, 1
  %1616 = getelementptr i8, <8 x ptr> %1614, <8 x i64> %1615
  %1617 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1616, <8 x i1> %95, <8 x float> zeroinitializer)
  %1618 = add i64 %261, 26
  %tile_snapshot.spill.load589 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load589, 0
  %1620 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load589, 1
  %.splatinsert590 = insertelement <8 x i64> poison, i64 %1618, i64 0
  %.splat591 = shufflevector <8 x i64> %.splatinsert590, <8 x i64> poison, <8 x i32> zeroinitializer
  %1621 = mul <8 x i64> %.splat591, splat (i64 4)
  %1622 = add <8 x i64> %1620, %1621
  %1623 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1619, 0
  %1624 = insertvalue { <8 x ptr>, <8 x i64> } %1623, <8 x i64> %1622, 1
  %1625 = extractvalue { <8 x ptr>, <8 x i64> } %1624, 0
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %1624, 1
  %1627 = getelementptr i8, <8 x ptr> %1625, <8 x i64> %1626
  %1628 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1627, <8 x i1> %95, <8 x float> zeroinitializer)
  %1629 = add i64 %274, 26
  %tile_snapshot.spill.load592 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load592, 0
  %1631 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load592, 1
  %.splatinsert593 = insertelement <8 x i64> poison, i64 %1629, i64 0
  %.splat594 = shufflevector <8 x i64> %.splatinsert593, <8 x i64> poison, <8 x i32> zeroinitializer
  %1632 = mul <8 x i64> %.splat594, splat (i64 4)
  %1633 = add <8 x i64> %1631, %1632
  %1634 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1630, 0
  %1635 = insertvalue { <8 x ptr>, <8 x i64> } %1634, <8 x i64> %1633, 1
  %1636 = extractvalue { <8 x ptr>, <8 x i64> } %1635, 0
  %1637 = extractvalue { <8 x ptr>, <8 x i64> } %1635, 1
  %1638 = getelementptr i8, <8 x ptr> %1636, <8 x i64> %1637
  %1639 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1638, <8 x i1> %95, <8 x float> zeroinitializer)
  %1640 = add i64 %287, 26
  %tile_snapshot.spill.load595 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load595, 0
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load595, 1
  %.splatinsert596 = insertelement <8 x i64> poison, i64 %1640, i64 0
  %.splat597 = shufflevector <8 x i64> %.splatinsert596, <8 x i64> poison, <8 x i32> zeroinitializer
  %1643 = mul <8 x i64> %.splat597, splat (i64 4)
  %1644 = add <8 x i64> %1642, %1643
  %1645 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1641, 0
  %1646 = insertvalue { <8 x ptr>, <8 x i64> } %1645, <8 x i64> %1644, 1
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %1646, 0
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %1646, 1
  %1649 = getelementptr i8, <8 x ptr> %1647, <8 x i64> %1648
  %1650 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1649, <8 x i1> %95, <8 x float> zeroinitializer)
  %1651 = fmul <8 x float> %1617, %1639
  %1652 = fadd <8 x float> %1600, %1651
  %1653 = fmul <8 x float> %1617, %1650
  %1654 = fadd <8 x float> %1602, %1653
  %1655 = fmul <8 x float> %1628, %1639
  %1656 = fadd <8 x float> %1604, %1655
  %1657 = fmul <8 x float> %1628, %1650
  %1658 = fadd <8 x float> %1606, %1657
  %1659 = add i64 %248, 27
  %tile_snapshot.spill.load598 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1660 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load598, 0
  %1661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load598, 1
  %.splatinsert599 = insertelement <8 x i64> poison, i64 %1659, i64 0
  %.splat600 = shufflevector <8 x i64> %.splatinsert599, <8 x i64> poison, <8 x i32> zeroinitializer
  %1662 = mul <8 x i64> %.splat600, splat (i64 4)
  %1663 = add <8 x i64> %1661, %1662
  %1664 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1660, 0
  %1665 = insertvalue { <8 x ptr>, <8 x i64> } %1664, <8 x i64> %1663, 1
  %1666 = extractvalue { <8 x ptr>, <8 x i64> } %1665, 0
  %1667 = extractvalue { <8 x ptr>, <8 x i64> } %1665, 1
  %1668 = getelementptr i8, <8 x ptr> %1666, <8 x i64> %1667
  %1669 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1668, <8 x i1> %95, <8 x float> zeroinitializer)
  %1670 = add i64 %261, 27
  %tile_snapshot.spill.load601 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1671 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load601, 0
  %1672 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load601, 1
  %.splatinsert602 = insertelement <8 x i64> poison, i64 %1670, i64 0
  %.splat603 = shufflevector <8 x i64> %.splatinsert602, <8 x i64> poison, <8 x i32> zeroinitializer
  %1673 = mul <8 x i64> %.splat603, splat (i64 4)
  %1674 = add <8 x i64> %1672, %1673
  %1675 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1671, 0
  %1676 = insertvalue { <8 x ptr>, <8 x i64> } %1675, <8 x i64> %1674, 1
  %1677 = extractvalue { <8 x ptr>, <8 x i64> } %1676, 0
  %1678 = extractvalue { <8 x ptr>, <8 x i64> } %1676, 1
  %1679 = getelementptr i8, <8 x ptr> %1677, <8 x i64> %1678
  %1680 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1679, <8 x i1> %95, <8 x float> zeroinitializer)
  %1681 = add i64 %274, 27
  %tile_snapshot.spill.load604 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load604, 0
  %1683 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load604, 1
  %.splatinsert605 = insertelement <8 x i64> poison, i64 %1681, i64 0
  %.splat606 = shufflevector <8 x i64> %.splatinsert605, <8 x i64> poison, <8 x i32> zeroinitializer
  %1684 = mul <8 x i64> %.splat606, splat (i64 4)
  %1685 = add <8 x i64> %1683, %1684
  %1686 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1682, 0
  %1687 = insertvalue { <8 x ptr>, <8 x i64> } %1686, <8 x i64> %1685, 1
  %1688 = extractvalue { <8 x ptr>, <8 x i64> } %1687, 0
  %1689 = extractvalue { <8 x ptr>, <8 x i64> } %1687, 1
  %1690 = getelementptr i8, <8 x ptr> %1688, <8 x i64> %1689
  %1691 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1690, <8 x i1> %95, <8 x float> zeroinitializer)
  %1692 = add i64 %287, 27
  %tile_snapshot.spill.load607 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load607, 0
  %1694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load607, 1
  %.splatinsert608 = insertelement <8 x i64> poison, i64 %1692, i64 0
  %.splat609 = shufflevector <8 x i64> %.splatinsert608, <8 x i64> poison, <8 x i32> zeroinitializer
  %1695 = mul <8 x i64> %.splat609, splat (i64 4)
  %1696 = add <8 x i64> %1694, %1695
  %1697 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1693, 0
  %1698 = insertvalue { <8 x ptr>, <8 x i64> } %1697, <8 x i64> %1696, 1
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %1698, 0
  %1700 = extractvalue { <8 x ptr>, <8 x i64> } %1698, 1
  %1701 = getelementptr i8, <8 x ptr> %1699, <8 x i64> %1700
  %1702 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1701, <8 x i1> %95, <8 x float> zeroinitializer)
  %1703 = fmul <8 x float> %1669, %1691
  %1704 = fadd <8 x float> %1652, %1703
  %1705 = fmul <8 x float> %1669, %1702
  %1706 = fadd <8 x float> %1654, %1705
  %1707 = fmul <8 x float> %1680, %1691
  %1708 = fadd <8 x float> %1656, %1707
  %1709 = fmul <8 x float> %1680, %1702
  %1710 = fadd <8 x float> %1658, %1709
  %1711 = add i64 %248, 28
  %tile_snapshot.spill.load610 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1712 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load610, 0
  %1713 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load610, 1
  %.splatinsert611 = insertelement <8 x i64> poison, i64 %1711, i64 0
  %.splat612 = shufflevector <8 x i64> %.splatinsert611, <8 x i64> poison, <8 x i32> zeroinitializer
  %1714 = mul <8 x i64> %.splat612, splat (i64 4)
  %1715 = add <8 x i64> %1713, %1714
  %1716 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1712, 0
  %1717 = insertvalue { <8 x ptr>, <8 x i64> } %1716, <8 x i64> %1715, 1
  %1718 = extractvalue { <8 x ptr>, <8 x i64> } %1717, 0
  %1719 = extractvalue { <8 x ptr>, <8 x i64> } %1717, 1
  %1720 = getelementptr i8, <8 x ptr> %1718, <8 x i64> %1719
  %1721 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1720, <8 x i1> %95, <8 x float> zeroinitializer)
  %1722 = add i64 %261, 28
  %tile_snapshot.spill.load613 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1723 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load613, 0
  %1724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load613, 1
  %.splatinsert614 = insertelement <8 x i64> poison, i64 %1722, i64 0
  %.splat615 = shufflevector <8 x i64> %.splatinsert614, <8 x i64> poison, <8 x i32> zeroinitializer
  %1725 = mul <8 x i64> %.splat615, splat (i64 4)
  %1726 = add <8 x i64> %1724, %1725
  %1727 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1723, 0
  %1728 = insertvalue { <8 x ptr>, <8 x i64> } %1727, <8 x i64> %1726, 1
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %1728, 0
  %1730 = extractvalue { <8 x ptr>, <8 x i64> } %1728, 1
  %1731 = getelementptr i8, <8 x ptr> %1729, <8 x i64> %1730
  %1732 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1731, <8 x i1> %95, <8 x float> zeroinitializer)
  %1733 = add i64 %274, 28
  %tile_snapshot.spill.load616 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1734 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load616, 0
  %1735 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load616, 1
  %.splatinsert617 = insertelement <8 x i64> poison, i64 %1733, i64 0
  %.splat618 = shufflevector <8 x i64> %.splatinsert617, <8 x i64> poison, <8 x i32> zeroinitializer
  %1736 = mul <8 x i64> %.splat618, splat (i64 4)
  %1737 = add <8 x i64> %1735, %1736
  %1738 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1734, 0
  %1739 = insertvalue { <8 x ptr>, <8 x i64> } %1738, <8 x i64> %1737, 1
  %1740 = extractvalue { <8 x ptr>, <8 x i64> } %1739, 0
  %1741 = extractvalue { <8 x ptr>, <8 x i64> } %1739, 1
  %1742 = getelementptr i8, <8 x ptr> %1740, <8 x i64> %1741
  %1743 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1742, <8 x i1> %95, <8 x float> zeroinitializer)
  %1744 = add i64 %287, 28
  %tile_snapshot.spill.load619 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1745 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load619, 0
  %1746 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load619, 1
  %.splatinsert620 = insertelement <8 x i64> poison, i64 %1744, i64 0
  %.splat621 = shufflevector <8 x i64> %.splatinsert620, <8 x i64> poison, <8 x i32> zeroinitializer
  %1747 = mul <8 x i64> %.splat621, splat (i64 4)
  %1748 = add <8 x i64> %1746, %1747
  %1749 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1745, 0
  %1750 = insertvalue { <8 x ptr>, <8 x i64> } %1749, <8 x i64> %1748, 1
  %1751 = extractvalue { <8 x ptr>, <8 x i64> } %1750, 0
  %1752 = extractvalue { <8 x ptr>, <8 x i64> } %1750, 1
  %1753 = getelementptr i8, <8 x ptr> %1751, <8 x i64> %1752
  %1754 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1753, <8 x i1> %95, <8 x float> zeroinitializer)
  %1755 = fmul <8 x float> %1721, %1743
  %1756 = fadd <8 x float> %1704, %1755
  %1757 = fmul <8 x float> %1721, %1754
  %1758 = fadd <8 x float> %1706, %1757
  %1759 = fmul <8 x float> %1732, %1743
  %1760 = fadd <8 x float> %1708, %1759
  %1761 = fmul <8 x float> %1732, %1754
  %1762 = fadd <8 x float> %1710, %1761
  %1763 = add i64 %248, 29
  %tile_snapshot.spill.load622 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1764 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load622, 0
  %1765 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load622, 1
  %.splatinsert623 = insertelement <8 x i64> poison, i64 %1763, i64 0
  %.splat624 = shufflevector <8 x i64> %.splatinsert623, <8 x i64> poison, <8 x i32> zeroinitializer
  %1766 = mul <8 x i64> %.splat624, splat (i64 4)
  %1767 = add <8 x i64> %1765, %1766
  %1768 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1764, 0
  %1769 = insertvalue { <8 x ptr>, <8 x i64> } %1768, <8 x i64> %1767, 1
  %1770 = extractvalue { <8 x ptr>, <8 x i64> } %1769, 0
  %1771 = extractvalue { <8 x ptr>, <8 x i64> } %1769, 1
  %1772 = getelementptr i8, <8 x ptr> %1770, <8 x i64> %1771
  %1773 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1772, <8 x i1> %95, <8 x float> zeroinitializer)
  %1774 = add i64 %261, 29
  %tile_snapshot.spill.load625 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load625, 0
  %1776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load625, 1
  %.splatinsert626 = insertelement <8 x i64> poison, i64 %1774, i64 0
  %.splat627 = shufflevector <8 x i64> %.splatinsert626, <8 x i64> poison, <8 x i32> zeroinitializer
  %1777 = mul <8 x i64> %.splat627, splat (i64 4)
  %1778 = add <8 x i64> %1776, %1777
  %1779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1775, 0
  %1780 = insertvalue { <8 x ptr>, <8 x i64> } %1779, <8 x i64> %1778, 1
  %1781 = extractvalue { <8 x ptr>, <8 x i64> } %1780, 0
  %1782 = extractvalue { <8 x ptr>, <8 x i64> } %1780, 1
  %1783 = getelementptr i8, <8 x ptr> %1781, <8 x i64> %1782
  %1784 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1783, <8 x i1> %95, <8 x float> zeroinitializer)
  %1785 = add i64 %274, 29
  %tile_snapshot.spill.load628 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1786 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 0
  %1787 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 1
  %.splatinsert629 = insertelement <8 x i64> poison, i64 %1785, i64 0
  %.splat630 = shufflevector <8 x i64> %.splatinsert629, <8 x i64> poison, <8 x i32> zeroinitializer
  %1788 = mul <8 x i64> %.splat630, splat (i64 4)
  %1789 = add <8 x i64> %1787, %1788
  %1790 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1786, 0
  %1791 = insertvalue { <8 x ptr>, <8 x i64> } %1790, <8 x i64> %1789, 1
  %1792 = extractvalue { <8 x ptr>, <8 x i64> } %1791, 0
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %1791, 1
  %1794 = getelementptr i8, <8 x ptr> %1792, <8 x i64> %1793
  %1795 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1794, <8 x i1> %95, <8 x float> zeroinitializer)
  %1796 = add i64 %287, 29
  %tile_snapshot.spill.load631 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load631, 0
  %1798 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load631, 1
  %.splatinsert632 = insertelement <8 x i64> poison, i64 %1796, i64 0
  %.splat633 = shufflevector <8 x i64> %.splatinsert632, <8 x i64> poison, <8 x i32> zeroinitializer
  %1799 = mul <8 x i64> %.splat633, splat (i64 4)
  %1800 = add <8 x i64> %1798, %1799
  %1801 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1797, 0
  %1802 = insertvalue { <8 x ptr>, <8 x i64> } %1801, <8 x i64> %1800, 1
  %1803 = extractvalue { <8 x ptr>, <8 x i64> } %1802, 0
  %1804 = extractvalue { <8 x ptr>, <8 x i64> } %1802, 1
  %1805 = getelementptr i8, <8 x ptr> %1803, <8 x i64> %1804
  %1806 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1805, <8 x i1> %95, <8 x float> zeroinitializer)
  %1807 = fmul <8 x float> %1773, %1795
  %1808 = fadd <8 x float> %1756, %1807
  %1809 = fmul <8 x float> %1773, %1806
  %1810 = fadd <8 x float> %1758, %1809
  %1811 = fmul <8 x float> %1784, %1795
  %1812 = fadd <8 x float> %1760, %1811
  %1813 = fmul <8 x float> %1784, %1806
  %1814 = fadd <8 x float> %1762, %1813
  %1815 = add i64 %248, 30
  %tile_snapshot.spill.load634 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1816 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load634, 0
  %1817 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load634, 1
  %.splatinsert635 = insertelement <8 x i64> poison, i64 %1815, i64 0
  %.splat636 = shufflevector <8 x i64> %.splatinsert635, <8 x i64> poison, <8 x i32> zeroinitializer
  %1818 = mul <8 x i64> %.splat636, splat (i64 4)
  %1819 = add <8 x i64> %1817, %1818
  %1820 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1816, 0
  %1821 = insertvalue { <8 x ptr>, <8 x i64> } %1820, <8 x i64> %1819, 1
  %1822 = extractvalue { <8 x ptr>, <8 x i64> } %1821, 0
  %1823 = extractvalue { <8 x ptr>, <8 x i64> } %1821, 1
  %1824 = getelementptr i8, <8 x ptr> %1822, <8 x i64> %1823
  %1825 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1824, <8 x i1> %95, <8 x float> zeroinitializer)
  %1826 = add i64 %261, 30
  %tile_snapshot.spill.load637 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load637, 0
  %1828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load637, 1
  %.splatinsert638 = insertelement <8 x i64> poison, i64 %1826, i64 0
  %.splat639 = shufflevector <8 x i64> %.splatinsert638, <8 x i64> poison, <8 x i32> zeroinitializer
  %1829 = mul <8 x i64> %.splat639, splat (i64 4)
  %1830 = add <8 x i64> %1828, %1829
  %1831 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1827, 0
  %1832 = insertvalue { <8 x ptr>, <8 x i64> } %1831, <8 x i64> %1830, 1
  %1833 = extractvalue { <8 x ptr>, <8 x i64> } %1832, 0
  %1834 = extractvalue { <8 x ptr>, <8 x i64> } %1832, 1
  %1835 = getelementptr i8, <8 x ptr> %1833, <8 x i64> %1834
  %1836 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1835, <8 x i1> %95, <8 x float> zeroinitializer)
  %1837 = add i64 %274, 30
  %tile_snapshot.spill.load640 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1838 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load640, 0
  %1839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load640, 1
  %.splatinsert641 = insertelement <8 x i64> poison, i64 %1837, i64 0
  %.splat642 = shufflevector <8 x i64> %.splatinsert641, <8 x i64> poison, <8 x i32> zeroinitializer
  %1840 = mul <8 x i64> %.splat642, splat (i64 4)
  %1841 = add <8 x i64> %1839, %1840
  %1842 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1838, 0
  %1843 = insertvalue { <8 x ptr>, <8 x i64> } %1842, <8 x i64> %1841, 1
  %1844 = extractvalue { <8 x ptr>, <8 x i64> } %1843, 0
  %1845 = extractvalue { <8 x ptr>, <8 x i64> } %1843, 1
  %1846 = getelementptr i8, <8 x ptr> %1844, <8 x i64> %1845
  %1847 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1846, <8 x i1> %95, <8 x float> zeroinitializer)
  %1848 = add i64 %287, 30
  %tile_snapshot.spill.load643 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1849 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load643, 0
  %1850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load643, 1
  %.splatinsert644 = insertelement <8 x i64> poison, i64 %1848, i64 0
  %.splat645 = shufflevector <8 x i64> %.splatinsert644, <8 x i64> poison, <8 x i32> zeroinitializer
  %1851 = mul <8 x i64> %.splat645, splat (i64 4)
  %1852 = add <8 x i64> %1850, %1851
  %1853 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1849, 0
  %1854 = insertvalue { <8 x ptr>, <8 x i64> } %1853, <8 x i64> %1852, 1
  %1855 = extractvalue { <8 x ptr>, <8 x i64> } %1854, 0
  %1856 = extractvalue { <8 x ptr>, <8 x i64> } %1854, 1
  %1857 = getelementptr i8, <8 x ptr> %1855, <8 x i64> %1856
  %1858 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1857, <8 x i1> %95, <8 x float> zeroinitializer)
  %1859 = fmul <8 x float> %1825, %1847
  %1860 = fadd <8 x float> %1808, %1859
  %1861 = fmul <8 x float> %1825, %1858
  %1862 = fadd <8 x float> %1810, %1861
  %1863 = fmul <8 x float> %1836, %1847
  %1864 = fadd <8 x float> %1812, %1863
  %1865 = fmul <8 x float> %1836, %1858
  %1866 = fadd <8 x float> %1814, %1865
  %1867 = add i64 %248, 31
  %tile_snapshot.spill.load646 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1868 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load646, 0
  %1869 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load646, 1
  %.splatinsert647 = insertelement <8 x i64> poison, i64 %1867, i64 0
  %.splat648 = shufflevector <8 x i64> %.splatinsert647, <8 x i64> poison, <8 x i32> zeroinitializer
  %1870 = mul <8 x i64> %.splat648, splat (i64 4)
  %1871 = add <8 x i64> %1869, %1870
  %1872 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1868, 0
  %1873 = insertvalue { <8 x ptr>, <8 x i64> } %1872, <8 x i64> %1871, 1
  %1874 = extractvalue { <8 x ptr>, <8 x i64> } %1873, 0
  %1875 = extractvalue { <8 x ptr>, <8 x i64> } %1873, 1
  %1876 = getelementptr i8, <8 x ptr> %1874, <8 x i64> %1875
  %1877 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1876, <8 x i1> %95, <8 x float> zeroinitializer)
  %1878 = add i64 %261, 31
  %tile_snapshot.spill.load649 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1879 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load649, 0
  %1880 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load649, 1
  %.splatinsert650 = insertelement <8 x i64> poison, i64 %1878, i64 0
  %.splat651 = shufflevector <8 x i64> %.splatinsert650, <8 x i64> poison, <8 x i32> zeroinitializer
  %1881 = mul <8 x i64> %.splat651, splat (i64 4)
  %1882 = add <8 x i64> %1880, %1881
  %1883 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1879, 0
  %1884 = insertvalue { <8 x ptr>, <8 x i64> } %1883, <8 x i64> %1882, 1
  %1885 = extractvalue { <8 x ptr>, <8 x i64> } %1884, 0
  %1886 = extractvalue { <8 x ptr>, <8 x i64> } %1884, 1
  %1887 = getelementptr i8, <8 x ptr> %1885, <8 x i64> %1886
  %1888 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1887, <8 x i1> %95, <8 x float> zeroinitializer)
  %1889 = add i64 %274, 31
  %tile_snapshot.spill.load652 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1890 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 0
  %1891 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 1
  %.splatinsert653 = insertelement <8 x i64> poison, i64 %1889, i64 0
  %.splat654 = shufflevector <8 x i64> %.splatinsert653, <8 x i64> poison, <8 x i32> zeroinitializer
  %1892 = mul <8 x i64> %.splat654, splat (i64 4)
  %1893 = add <8 x i64> %1891, %1892
  %1894 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1890, 0
  %1895 = insertvalue { <8 x ptr>, <8 x i64> } %1894, <8 x i64> %1893, 1
  %1896 = extractvalue { <8 x ptr>, <8 x i64> } %1895, 0
  %1897 = extractvalue { <8 x ptr>, <8 x i64> } %1895, 1
  %1898 = getelementptr i8, <8 x ptr> %1896, <8 x i64> %1897
  %1899 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1898, <8 x i1> %95, <8 x float> zeroinitializer)
  %1900 = add i64 %287, 31
  %tile_snapshot.spill.load655 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1901 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load655, 0
  %1902 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load655, 1
  %.splatinsert656 = insertelement <8 x i64> poison, i64 %1900, i64 0
  %.splat657 = shufflevector <8 x i64> %.splatinsert656, <8 x i64> poison, <8 x i32> zeroinitializer
  %1903 = mul <8 x i64> %.splat657, splat (i64 4)
  %1904 = add <8 x i64> %1902, %1903
  %1905 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1901, 0
  %1906 = insertvalue { <8 x ptr>, <8 x i64> } %1905, <8 x i64> %1904, 1
  %1907 = extractvalue { <8 x ptr>, <8 x i64> } %1906, 0
  %1908 = extractvalue { <8 x ptr>, <8 x i64> } %1906, 1
  %1909 = getelementptr i8, <8 x ptr> %1907, <8 x i64> %1908
  %1910 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1909, <8 x i1> %95, <8 x float> zeroinitializer)
  %1911 = fmul <8 x float> %1877, %1899
  %1912 = fadd <8 x float> %1860, %1911
  %1913 = fmul <8 x float> %1877, %1910
  %1914 = fadd <8 x float> %1862, %1913
  %1915 = fmul <8 x float> %1888, %1899
  %1916 = fadd <8 x float> %1864, %1915
  %1917 = fmul <8 x float> %1888, %1910
  %1918 = fadd <8 x float> %1866, %1917
  %tile_snapshot.spill.load658 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %1919 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 0
  %1920 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 1
  %.splatinsert659 = insertelement <8 x i64> poison, i64 %239, i64 0
  %.splat660 = shufflevector <8 x i64> %.splatinsert659, <8 x i64> poison, <8 x i32> zeroinitializer
  %1921 = mul <8 x i64> %.splat660, splat (i64 32)
  %1922 = add <8 x i64> %1920, %1921
  %1923 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1919, 0
  %1924 = insertvalue { <8 x ptr>, <8 x i64> } %1923, <8 x i64> %1922, 1
  %1925 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1926 = extractvalue { <8 x ptr>, <8 x i64> } %1924, 1
  %1927 = extractelement <8 x ptr> %1925, i32 0
  %1928 = extractelement <8 x i64> %1926, i32 0
  %1929 = sub i64 %1928, 0
  %1930 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1931 = select i1 %1930, i64 %1929, i64 0
  %private.contiguous.address661 = getelementptr i8, ptr %1927, i64 %1931
  %private.contiguous.preserve662 = load <8 x float>, ptr %private.contiguous.address661, align 4
  %1932 = select <8 x i1> %95, <8 x float> %1912, <8 x float> %private.contiguous.preserve662
  store <8 x float> %1932, ptr %private.contiguous.address661, align 4
  %tile_snapshot.spill.load663 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %1933 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load663, 0
  %1934 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load663, 1
  %.splatinsert664 = insertelement <8 x i64> poison, i64 %242, i64 0
  %.splat665 = shufflevector <8 x i64> %.splatinsert664, <8 x i64> poison, <8 x i32> zeroinitializer
  %1935 = mul <8 x i64> %.splat665, splat (i64 32)
  %1936 = add <8 x i64> %1934, %1935
  %1937 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1933, 0
  %1938 = insertvalue { <8 x ptr>, <8 x i64> } %1937, <8 x i64> %1936, 1
  %1939 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1940 = extractvalue { <8 x ptr>, <8 x i64> } %1938, 1
  %1941 = extractelement <8 x ptr> %1939, i32 0
  %1942 = extractelement <8 x i64> %1940, i32 0
  %1943 = sub i64 %1942, 0
  %1944 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1945 = select i1 %1944, i64 %1943, i64 0
  %private.contiguous.address666 = getelementptr i8, ptr %1941, i64 %1945
  %private.contiguous.preserve667 = load <8 x float>, ptr %private.contiguous.address666, align 4
  %1946 = select <8 x i1> %95, <8 x float> %1914, <8 x float> %private.contiguous.preserve667
  store <8 x float> %1946, ptr %private.contiguous.address666, align 4
  %tile_snapshot.spill.load668 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %1947 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load668, 0
  %1948 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load668, 1
  %.splatinsert669 = insertelement <8 x i64> poison, i64 %244, i64 0
  %.splat670 = shufflevector <8 x i64> %.splatinsert669, <8 x i64> poison, <8 x i32> zeroinitializer
  %1949 = mul <8 x i64> %.splat670, splat (i64 32)
  %1950 = add <8 x i64> %1948, %1949
  %1951 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1947, 0
  %1952 = insertvalue { <8 x ptr>, <8 x i64> } %1951, <8 x i64> %1950, 1
  %1953 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1954 = extractvalue { <8 x ptr>, <8 x i64> } %1952, 1
  %1955 = extractelement <8 x ptr> %1953, i32 0
  %1956 = extractelement <8 x i64> %1954, i32 0
  %1957 = sub i64 %1956, 0
  %1958 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1959 = select i1 %1958, i64 %1957, i64 0
  %private.contiguous.address671 = getelementptr i8, ptr %1955, i64 %1959
  %private.contiguous.preserve672 = load <8 x float>, ptr %private.contiguous.address671, align 4
  %1960 = select <8 x i1> %95, <8 x float> %1916, <8 x float> %private.contiguous.preserve672
  store <8 x float> %1960, ptr %private.contiguous.address671, align 4
  %tile_snapshot.spill.load673 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %1961 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load673, 0
  %1962 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load673, 1
  %.splatinsert674 = insertelement <8 x i64> poison, i64 %246, i64 0
  %.splat675 = shufflevector <8 x i64> %.splatinsert674, <8 x i64> poison, <8 x i32> zeroinitializer
  %1963 = mul <8 x i64> %.splat675, splat (i64 32)
  %1964 = add <8 x i64> %1962, %1963
  %1965 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1961, 0
  %1966 = insertvalue { <8 x ptr>, <8 x i64> } %1965, <8 x i64> %1964, 1
  %1967 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1968 = extractvalue { <8 x ptr>, <8 x i64> } %1966, 1
  %1969 = extractelement <8 x ptr> %1967, i32 0
  %1970 = extractelement <8 x i64> %1968, i32 0
  %1971 = sub i64 %1970, 0
  %1972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %1973 = select i1 %1972, i64 %1971, i64 0
  %private.contiguous.address676 = getelementptr i8, ptr %1969, i64 %1973
  %private.contiguous.preserve677 = load <8 x float>, ptr %private.contiguous.address676, align 4
  %1974 = select <8 x i1> %95, <8 x float> %1918, <8 x float> %private.contiguous.preserve677
  store <8 x float> %1974, ptr %private.contiguous.address676, align 4
  %.state678 = load i64, ptr %.slot91, align 4
  %1975 = add i64 %.state678, 1
  store i64 %1975, ptr %.slot91, align 4
  br label %direct.schedule.12

direct.schedule.14:                               ; preds = %direct.false271
  %.state679 = load i64, ptr %.slot89, align 4
  %1976 = add i64 %.state679, 1
  store i64 %1976, ptr %.slot89, align 4
  br label %direct.schedule.10

direct.schedule.15:                               ; preds = %direct.false267
  %.spill.load680 = load i64, ptr %.spill84, align 4
  %1977 = add i64 0, %.spill.load680
  %.spill.load681 = load i64, ptr %.spill84, align 4
  %1978 = add i64 1, %.spill.load681
  %.spill.load682 = load i64, ptr %.spill84, align 4
  %1979 = add i64 2, %.spill.load682
  %.spill.load683 = load i64, ptr %.spill84, align 4
  %1980 = add i64 3, %.spill.load683
  %.spill.load684 = load i64, ptr %.spill84, align 4
  %1981 = add i64 4, %.spill.load684
  %.spill.load685 = load i64, ptr %.spill84, align 4
  %1982 = add i64 5, %.spill.load685
  %.spill.load686 = load i64, ptr %.spill84, align 4
  %1983 = add i64 6, %.spill.load686
  %.spill.load687 = load i64, ptr %.spill84, align 4
  %1984 = add i64 7, %.spill.load687
  %.spill.load688 = load i64, ptr %.spill84, align 4
  %1985 = add i64 8, %.spill.load688
  %.spill.load689 = load i64, ptr %.spill84, align 4
  %1986 = add i64 9, %.spill.load689
  %.spill.load690 = load i64, ptr %.spill84, align 4
  %1987 = add i64 10, %.spill.load690
  %.spill.load691 = load i64, ptr %.spill84, align 4
  %1988 = add i64 11, %.spill.load691
  %.spill.load692 = load i64, ptr %.spill84, align 4
  %1989 = add i64 12, %.spill.load692
  %.spill.load693 = load i64, ptr %.spill84, align 4
  %1990 = add i64 13, %.spill.load693
  %.spill.load694 = load i64, ptr %.spill84, align 4
  %1991 = add i64 14, %.spill.load694
  %.spill.load695 = load i64, ptr %.spill84, align 4
  %1992 = add i64 15, %.spill.load695
  %1993 = icmp slt i64 %1977, 129
  %1994 = icmp slt i64 %1978, 129
  %1995 = icmp slt i64 %1979, 129
  %1996 = icmp slt i64 %1980, 129
  %1997 = icmp slt i64 %1981, 129
  %1998 = icmp slt i64 %1982, 129
  %1999 = icmp slt i64 %1983, 129
  %2000 = icmp slt i64 %1984, 129
  %2001 = icmp slt i64 %1985, 129
  %2002 = icmp slt i64 %1986, 129
  %2003 = icmp slt i64 %1987, 129
  %2004 = icmp slt i64 %1988, 129
  %2005 = icmp slt i64 %1989, 129
  %2006 = icmp slt i64 %1990, 129
  %2007 = icmp slt i64 %1991, 129
  %2008 = icmp slt i64 %1992, 129
  %2009 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %2010 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2011 = extractvalue { <8 x ptr>, <8 x i64> } %2009, 0
  %2012 = select <8 x i1> %95, <8 x ptr> %2010, <8 x ptr> %2011
  %2013 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2014 = extractvalue { <8 x ptr>, <8 x i64> } %2009, 1
  %2015 = select <8 x i1> %95, <8 x i64> %2013, <8 x i64> %2014
  %2016 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2012, 0
  %2017 = insertvalue { <8 x ptr>, <8 x i64> } %2016, <8 x i64> %2015, 1
  store { <8 x ptr>, <8 x i64> } %2017, ptr %tile_snapshot.spill92, align 64
  %2018 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2019 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2020 = add <8 x i64> %2019, zeroinitializer
  %2021 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2018, 0
  %2022 = insertvalue { <8 x ptr>, <8 x i64> } %2021, <8 x i64> %2020, 1
  %.splatinsert696 = insertelement <8 x i1> poison, i1 %1993, i64 0
  %.splat697 = shufflevector <8 x i1> %.splatinsert696, <8 x i1> poison, <8 x i32> zeroinitializer
  %2023 = extractvalue { <8 x ptr>, <8 x i64> } %2022, 0
  %2024 = extractvalue { <8 x ptr>, <8 x i64> } %2022, 1
  %2025 = getelementptr i8, <8 x ptr> %2023, <8 x i64> %2024
  %2026 = zext <8 x i1> %.splat697 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2026, <8 x ptr> align 1 %2025, <8 x i1> %95)
  %2027 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2028 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2029 = add <8 x i64> %2028, splat (i64 1)
  %2030 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2027, 0
  %2031 = insertvalue { <8 x ptr>, <8 x i64> } %2030, <8 x i64> %2029, 1
  %.splatinsert698 = insertelement <8 x i1> poison, i1 %1994, i64 0
  %.splat699 = shufflevector <8 x i1> %.splatinsert698, <8 x i1> poison, <8 x i32> zeroinitializer
  %2032 = extractvalue { <8 x ptr>, <8 x i64> } %2031, 0
  %2033 = extractvalue { <8 x ptr>, <8 x i64> } %2031, 1
  %2034 = getelementptr i8, <8 x ptr> %2032, <8 x i64> %2033
  %2035 = zext <8 x i1> %.splat699 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2035, <8 x ptr> align 1 %2034, <8 x i1> %95)
  %2036 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2037 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2038 = add <8 x i64> %2037, splat (i64 2)
  %2039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2036, 0
  %2040 = insertvalue { <8 x ptr>, <8 x i64> } %2039, <8 x i64> %2038, 1
  %.splatinsert700 = insertelement <8 x i1> poison, i1 %1995, i64 0
  %.splat701 = shufflevector <8 x i1> %.splatinsert700, <8 x i1> poison, <8 x i32> zeroinitializer
  %2041 = extractvalue { <8 x ptr>, <8 x i64> } %2040, 0
  %2042 = extractvalue { <8 x ptr>, <8 x i64> } %2040, 1
  %2043 = getelementptr i8, <8 x ptr> %2041, <8 x i64> %2042
  %2044 = zext <8 x i1> %.splat701 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2044, <8 x ptr> align 1 %2043, <8 x i1> %95)
  %2045 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2046 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2047 = add <8 x i64> %2046, splat (i64 3)
  %2048 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2045, 0
  %2049 = insertvalue { <8 x ptr>, <8 x i64> } %2048, <8 x i64> %2047, 1
  %.splatinsert702 = insertelement <8 x i1> poison, i1 %1996, i64 0
  %.splat703 = shufflevector <8 x i1> %.splatinsert702, <8 x i1> poison, <8 x i32> zeroinitializer
  %2050 = extractvalue { <8 x ptr>, <8 x i64> } %2049, 0
  %2051 = extractvalue { <8 x ptr>, <8 x i64> } %2049, 1
  %2052 = getelementptr i8, <8 x ptr> %2050, <8 x i64> %2051
  %2053 = zext <8 x i1> %.splat703 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2053, <8 x ptr> align 1 %2052, <8 x i1> %95)
  %2054 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2055 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2056 = add <8 x i64> %2055, splat (i64 4)
  %2057 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2054, 0
  %2058 = insertvalue { <8 x ptr>, <8 x i64> } %2057, <8 x i64> %2056, 1
  %.splatinsert704 = insertelement <8 x i1> poison, i1 %1997, i64 0
  %.splat705 = shufflevector <8 x i1> %.splatinsert704, <8 x i1> poison, <8 x i32> zeroinitializer
  %2059 = extractvalue { <8 x ptr>, <8 x i64> } %2058, 0
  %2060 = extractvalue { <8 x ptr>, <8 x i64> } %2058, 1
  %2061 = getelementptr i8, <8 x ptr> %2059, <8 x i64> %2060
  %2062 = zext <8 x i1> %.splat705 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2062, <8 x ptr> align 1 %2061, <8 x i1> %95)
  %2063 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2064 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2065 = add <8 x i64> %2064, splat (i64 5)
  %2066 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2063, 0
  %2067 = insertvalue { <8 x ptr>, <8 x i64> } %2066, <8 x i64> %2065, 1
  %.splatinsert706 = insertelement <8 x i1> poison, i1 %1998, i64 0
  %.splat707 = shufflevector <8 x i1> %.splatinsert706, <8 x i1> poison, <8 x i32> zeroinitializer
  %2068 = extractvalue { <8 x ptr>, <8 x i64> } %2067, 0
  %2069 = extractvalue { <8 x ptr>, <8 x i64> } %2067, 1
  %2070 = getelementptr i8, <8 x ptr> %2068, <8 x i64> %2069
  %2071 = zext <8 x i1> %.splat707 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2071, <8 x ptr> align 1 %2070, <8 x i1> %95)
  %2072 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2073 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2074 = add <8 x i64> %2073, splat (i64 6)
  %2075 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2072, 0
  %2076 = insertvalue { <8 x ptr>, <8 x i64> } %2075, <8 x i64> %2074, 1
  %.splatinsert708 = insertelement <8 x i1> poison, i1 %1999, i64 0
  %.splat709 = shufflevector <8 x i1> %.splatinsert708, <8 x i1> poison, <8 x i32> zeroinitializer
  %2077 = extractvalue { <8 x ptr>, <8 x i64> } %2076, 0
  %2078 = extractvalue { <8 x ptr>, <8 x i64> } %2076, 1
  %2079 = getelementptr i8, <8 x ptr> %2077, <8 x i64> %2078
  %2080 = zext <8 x i1> %.splat709 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2080, <8 x ptr> align 1 %2079, <8 x i1> %95)
  %2081 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2082 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2083 = add <8 x i64> %2082, splat (i64 7)
  %2084 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2081, 0
  %2085 = insertvalue { <8 x ptr>, <8 x i64> } %2084, <8 x i64> %2083, 1
  %.splatinsert710 = insertelement <8 x i1> poison, i1 %2000, i64 0
  %.splat711 = shufflevector <8 x i1> %.splatinsert710, <8 x i1> poison, <8 x i32> zeroinitializer
  %2086 = extractvalue { <8 x ptr>, <8 x i64> } %2085, 0
  %2087 = extractvalue { <8 x ptr>, <8 x i64> } %2085, 1
  %2088 = getelementptr i8, <8 x ptr> %2086, <8 x i64> %2087
  %2089 = zext <8 x i1> %.splat711 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2089, <8 x ptr> align 1 %2088, <8 x i1> %95)
  %2090 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2091 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2092 = add <8 x i64> %2091, splat (i64 8)
  %2093 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2090, 0
  %2094 = insertvalue { <8 x ptr>, <8 x i64> } %2093, <8 x i64> %2092, 1
  %.splatinsert712 = insertelement <8 x i1> poison, i1 %2001, i64 0
  %.splat713 = shufflevector <8 x i1> %.splatinsert712, <8 x i1> poison, <8 x i32> zeroinitializer
  %2095 = extractvalue { <8 x ptr>, <8 x i64> } %2094, 0
  %2096 = extractvalue { <8 x ptr>, <8 x i64> } %2094, 1
  %2097 = getelementptr i8, <8 x ptr> %2095, <8 x i64> %2096
  %2098 = zext <8 x i1> %.splat713 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2098, <8 x ptr> align 1 %2097, <8 x i1> %95)
  %2099 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2100 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2101 = add <8 x i64> %2100, splat (i64 9)
  %2102 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2099, 0
  %2103 = insertvalue { <8 x ptr>, <8 x i64> } %2102, <8 x i64> %2101, 1
  %.splatinsert714 = insertelement <8 x i1> poison, i1 %2002, i64 0
  %.splat715 = shufflevector <8 x i1> %.splatinsert714, <8 x i1> poison, <8 x i32> zeroinitializer
  %2104 = extractvalue { <8 x ptr>, <8 x i64> } %2103, 0
  %2105 = extractvalue { <8 x ptr>, <8 x i64> } %2103, 1
  %2106 = getelementptr i8, <8 x ptr> %2104, <8 x i64> %2105
  %2107 = zext <8 x i1> %.splat715 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2107, <8 x ptr> align 1 %2106, <8 x i1> %95)
  %2108 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2109 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2110 = add <8 x i64> %2109, splat (i64 10)
  %2111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2108, 0
  %2112 = insertvalue { <8 x ptr>, <8 x i64> } %2111, <8 x i64> %2110, 1
  %.splatinsert716 = insertelement <8 x i1> poison, i1 %2003, i64 0
  %.splat717 = shufflevector <8 x i1> %.splatinsert716, <8 x i1> poison, <8 x i32> zeroinitializer
  %2113 = extractvalue { <8 x ptr>, <8 x i64> } %2112, 0
  %2114 = extractvalue { <8 x ptr>, <8 x i64> } %2112, 1
  %2115 = getelementptr i8, <8 x ptr> %2113, <8 x i64> %2114
  %2116 = zext <8 x i1> %.splat717 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2116, <8 x ptr> align 1 %2115, <8 x i1> %95)
  %2117 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2118 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2119 = add <8 x i64> %2118, splat (i64 11)
  %2120 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2117, 0
  %2121 = insertvalue { <8 x ptr>, <8 x i64> } %2120, <8 x i64> %2119, 1
  %.splatinsert718 = insertelement <8 x i1> poison, i1 %2004, i64 0
  %.splat719 = shufflevector <8 x i1> %.splatinsert718, <8 x i1> poison, <8 x i32> zeroinitializer
  %2122 = extractvalue { <8 x ptr>, <8 x i64> } %2121, 0
  %2123 = extractvalue { <8 x ptr>, <8 x i64> } %2121, 1
  %2124 = getelementptr i8, <8 x ptr> %2122, <8 x i64> %2123
  %2125 = zext <8 x i1> %.splat719 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2125, <8 x ptr> align 1 %2124, <8 x i1> %95)
  %2126 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2127 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2128 = add <8 x i64> %2127, splat (i64 12)
  %2129 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2126, 0
  %2130 = insertvalue { <8 x ptr>, <8 x i64> } %2129, <8 x i64> %2128, 1
  %.splatinsert720 = insertelement <8 x i1> poison, i1 %2005, i64 0
  %.splat721 = shufflevector <8 x i1> %.splatinsert720, <8 x i1> poison, <8 x i32> zeroinitializer
  %2131 = extractvalue { <8 x ptr>, <8 x i64> } %2130, 0
  %2132 = extractvalue { <8 x ptr>, <8 x i64> } %2130, 1
  %2133 = getelementptr i8, <8 x ptr> %2131, <8 x i64> %2132
  %2134 = zext <8 x i1> %.splat721 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2134, <8 x ptr> align 1 %2133, <8 x i1> %95)
  %2135 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2136 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2137 = add <8 x i64> %2136, splat (i64 13)
  %2138 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2135, 0
  %2139 = insertvalue { <8 x ptr>, <8 x i64> } %2138, <8 x i64> %2137, 1
  %.splatinsert722 = insertelement <8 x i1> poison, i1 %2006, i64 0
  %.splat723 = shufflevector <8 x i1> %.splatinsert722, <8 x i1> poison, <8 x i32> zeroinitializer
  %2140 = extractvalue { <8 x ptr>, <8 x i64> } %2139, 0
  %2141 = extractvalue { <8 x ptr>, <8 x i64> } %2139, 1
  %2142 = getelementptr i8, <8 x ptr> %2140, <8 x i64> %2141
  %2143 = zext <8 x i1> %.splat723 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2143, <8 x ptr> align 1 %2142, <8 x i1> %95)
  %2144 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2145 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2146 = add <8 x i64> %2145, splat (i64 14)
  %2147 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2144, 0
  %2148 = insertvalue { <8 x ptr>, <8 x i64> } %2147, <8 x i64> %2146, 1
  %.splatinsert724 = insertelement <8 x i1> poison, i1 %2007, i64 0
  %.splat725 = shufflevector <8 x i1> %.splatinsert724, <8 x i1> poison, <8 x i32> zeroinitializer
  %2149 = extractvalue { <8 x ptr>, <8 x i64> } %2148, 0
  %2150 = extractvalue { <8 x ptr>, <8 x i64> } %2148, 1
  %2151 = getelementptr i8, <8 x ptr> %2149, <8 x i64> %2150
  %2152 = zext <8 x i1> %.splat725 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2152, <8 x ptr> align 1 %2151, <8 x i1> %95)
  %2153 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %2154 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %2155 = add <8 x i64> %2154, splat (i64 15)
  %2156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2153, 0
  %2157 = insertvalue { <8 x ptr>, <8 x i64> } %2156, <8 x i64> %2155, 1
  %.splatinsert726 = insertelement <8 x i1> poison, i1 %2008, i64 0
  %.splat727 = shufflevector <8 x i1> %.splatinsert726, <8 x i1> poison, <8 x i32> zeroinitializer
  %2158 = extractvalue { <8 x ptr>, <8 x i64> } %2157, 0
  %2159 = extractvalue { <8 x ptr>, <8 x i64> } %2157, 1
  %2160 = getelementptr i8, <8 x ptr> %2158, <8 x i64> %2159
  %2161 = zext <8 x i1> %.splat727 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2161, <8 x ptr> align 1 %2160, <8 x i1> %95)
  %2162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %2163 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2164 = extractvalue { <8 x ptr>, <8 x i64> } %2162, 0
  %2165 = select <8 x i1> %95, <8 x ptr> %2163, <8 x ptr> %2164
  %2166 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2167 = extractvalue { <8 x ptr>, <8 x i64> } %2162, 1
  %2168 = select <8 x i1> %95, <8 x i64> %2166, <8 x i64> %2167
  %2169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2165, 0
  %2170 = insertvalue { <8 x ptr>, <8 x i64> } %2169, <8 x i64> %2168, 1
  store { <8 x ptr>, <8 x i64> } %2170, ptr %tile_snapshot.spill93, align 64
  %2171 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2172 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2173 = add <8 x i64> %2172, zeroinitializer
  %2174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2171, 0
  %2175 = insertvalue { <8 x ptr>, <8 x i64> } %2174, <8 x i64> %2173, 1
  %.splatinsert728 = insertelement <8 x i64> poison, i64 %1977, i64 0
  %.splat729 = shufflevector <8 x i64> %.splatinsert728, <8 x i64> poison, <8 x i32> zeroinitializer
  %2176 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2177 = extractvalue { <8 x ptr>, <8 x i64> } %2175, 1
  %2178 = extractelement <8 x ptr> %2176, i32 0
  %2179 = extractelement <8 x i64> %2177, i32 0
  %2180 = sub i64 %2179, 0
  %2181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2182 = select i1 %2181, i64 %2180, i64 0
  %private.contiguous.address730 = getelementptr i8, ptr %2178, i64 %2182
  %private.contiguous.preserve731 = load <8 x i64>, ptr %private.contiguous.address730, align 8
  %2183 = select <8 x i1> %95, <8 x i64> %.splat729, <8 x i64> %private.contiguous.preserve731
  store <8 x i64> %2183, ptr %private.contiguous.address730, align 8
  %2184 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2185 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2186 = add <8 x i64> %2185, splat (i64 64)
  %2187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2184, 0
  %2188 = insertvalue { <8 x ptr>, <8 x i64> } %2187, <8 x i64> %2186, 1
  %.splatinsert732 = insertelement <8 x i64> poison, i64 %1978, i64 0
  %.splat733 = shufflevector <8 x i64> %.splatinsert732, <8 x i64> poison, <8 x i32> zeroinitializer
  %2189 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2190 = extractvalue { <8 x ptr>, <8 x i64> } %2188, 1
  %2191 = extractelement <8 x ptr> %2189, i32 0
  %2192 = extractelement <8 x i64> %2190, i32 0
  %2193 = sub i64 %2192, 0
  %2194 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2195 = select i1 %2194, i64 %2193, i64 0
  %private.contiguous.address734 = getelementptr i8, ptr %2191, i64 %2195
  %private.contiguous.preserve735 = load <8 x i64>, ptr %private.contiguous.address734, align 8
  %2196 = select <8 x i1> %95, <8 x i64> %.splat733, <8 x i64> %private.contiguous.preserve735
  store <8 x i64> %2196, ptr %private.contiguous.address734, align 8
  %2197 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2198 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2199 = add <8 x i64> %2198, splat (i64 128)
  %2200 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2197, 0
  %2201 = insertvalue { <8 x ptr>, <8 x i64> } %2200, <8 x i64> %2199, 1
  %.splatinsert736 = insertelement <8 x i64> poison, i64 %1979, i64 0
  %.splat737 = shufflevector <8 x i64> %.splatinsert736, <8 x i64> poison, <8 x i32> zeroinitializer
  %2202 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2203 = extractvalue { <8 x ptr>, <8 x i64> } %2201, 1
  %2204 = extractelement <8 x ptr> %2202, i32 0
  %2205 = extractelement <8 x i64> %2203, i32 0
  %2206 = sub i64 %2205, 0
  %2207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2208 = select i1 %2207, i64 %2206, i64 0
  %private.contiguous.address738 = getelementptr i8, ptr %2204, i64 %2208
  %private.contiguous.preserve739 = load <8 x i64>, ptr %private.contiguous.address738, align 8
  %2209 = select <8 x i1> %95, <8 x i64> %.splat737, <8 x i64> %private.contiguous.preserve739
  store <8 x i64> %2209, ptr %private.contiguous.address738, align 8
  %2210 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2211 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2212 = add <8 x i64> %2211, splat (i64 192)
  %2213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2210, 0
  %2214 = insertvalue { <8 x ptr>, <8 x i64> } %2213, <8 x i64> %2212, 1
  %.splatinsert740 = insertelement <8 x i64> poison, i64 %1980, i64 0
  %.splat741 = shufflevector <8 x i64> %.splatinsert740, <8 x i64> poison, <8 x i32> zeroinitializer
  %2215 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2216 = extractvalue { <8 x ptr>, <8 x i64> } %2214, 1
  %2217 = extractelement <8 x ptr> %2215, i32 0
  %2218 = extractelement <8 x i64> %2216, i32 0
  %2219 = sub i64 %2218, 0
  %2220 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2221 = select i1 %2220, i64 %2219, i64 0
  %private.contiguous.address742 = getelementptr i8, ptr %2217, i64 %2221
  %private.contiguous.preserve743 = load <8 x i64>, ptr %private.contiguous.address742, align 8
  %2222 = select <8 x i1> %95, <8 x i64> %.splat741, <8 x i64> %private.contiguous.preserve743
  store <8 x i64> %2222, ptr %private.contiguous.address742, align 8
  %2223 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2224 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2225 = add <8 x i64> %2224, splat (i64 256)
  %2226 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2223, 0
  %2227 = insertvalue { <8 x ptr>, <8 x i64> } %2226, <8 x i64> %2225, 1
  %.splatinsert744 = insertelement <8 x i64> poison, i64 %1981, i64 0
  %.splat745 = shufflevector <8 x i64> %.splatinsert744, <8 x i64> poison, <8 x i32> zeroinitializer
  %2228 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2229 = extractvalue { <8 x ptr>, <8 x i64> } %2227, 1
  %2230 = extractelement <8 x ptr> %2228, i32 0
  %2231 = extractelement <8 x i64> %2229, i32 0
  %2232 = sub i64 %2231, 0
  %2233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2234 = select i1 %2233, i64 %2232, i64 0
  %private.contiguous.address746 = getelementptr i8, ptr %2230, i64 %2234
  %private.contiguous.preserve747 = load <8 x i64>, ptr %private.contiguous.address746, align 8
  %2235 = select <8 x i1> %95, <8 x i64> %.splat745, <8 x i64> %private.contiguous.preserve747
  store <8 x i64> %2235, ptr %private.contiguous.address746, align 8
  %2236 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2237 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2238 = add <8 x i64> %2237, splat (i64 320)
  %2239 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2236, 0
  %2240 = insertvalue { <8 x ptr>, <8 x i64> } %2239, <8 x i64> %2238, 1
  %.splatinsert748 = insertelement <8 x i64> poison, i64 %1982, i64 0
  %.splat749 = shufflevector <8 x i64> %.splatinsert748, <8 x i64> poison, <8 x i32> zeroinitializer
  %2241 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2242 = extractvalue { <8 x ptr>, <8 x i64> } %2240, 1
  %2243 = extractelement <8 x ptr> %2241, i32 0
  %2244 = extractelement <8 x i64> %2242, i32 0
  %2245 = sub i64 %2244, 0
  %2246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2247 = select i1 %2246, i64 %2245, i64 0
  %private.contiguous.address750 = getelementptr i8, ptr %2243, i64 %2247
  %private.contiguous.preserve751 = load <8 x i64>, ptr %private.contiguous.address750, align 8
  %2248 = select <8 x i1> %95, <8 x i64> %.splat749, <8 x i64> %private.contiguous.preserve751
  store <8 x i64> %2248, ptr %private.contiguous.address750, align 8
  %2249 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2250 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2251 = add <8 x i64> %2250, splat (i64 384)
  %2252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2249, 0
  %2253 = insertvalue { <8 x ptr>, <8 x i64> } %2252, <8 x i64> %2251, 1
  %.splatinsert752 = insertelement <8 x i64> poison, i64 %1983, i64 0
  %.splat753 = shufflevector <8 x i64> %.splatinsert752, <8 x i64> poison, <8 x i32> zeroinitializer
  %2254 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2255 = extractvalue { <8 x ptr>, <8 x i64> } %2253, 1
  %2256 = extractelement <8 x ptr> %2254, i32 0
  %2257 = extractelement <8 x i64> %2255, i32 0
  %2258 = sub i64 %2257, 0
  %2259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2260 = select i1 %2259, i64 %2258, i64 0
  %private.contiguous.address754 = getelementptr i8, ptr %2256, i64 %2260
  %private.contiguous.preserve755 = load <8 x i64>, ptr %private.contiguous.address754, align 8
  %2261 = select <8 x i1> %95, <8 x i64> %.splat753, <8 x i64> %private.contiguous.preserve755
  store <8 x i64> %2261, ptr %private.contiguous.address754, align 8
  %2262 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2263 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2264 = add <8 x i64> %2263, splat (i64 448)
  %2265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2262, 0
  %2266 = insertvalue { <8 x ptr>, <8 x i64> } %2265, <8 x i64> %2264, 1
  %.splatinsert756 = insertelement <8 x i64> poison, i64 %1984, i64 0
  %.splat757 = shufflevector <8 x i64> %.splatinsert756, <8 x i64> poison, <8 x i32> zeroinitializer
  %2267 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2268 = extractvalue { <8 x ptr>, <8 x i64> } %2266, 1
  %2269 = extractelement <8 x ptr> %2267, i32 0
  %2270 = extractelement <8 x i64> %2268, i32 0
  %2271 = sub i64 %2270, 0
  %2272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2273 = select i1 %2272, i64 %2271, i64 0
  %private.contiguous.address758 = getelementptr i8, ptr %2269, i64 %2273
  %private.contiguous.preserve759 = load <8 x i64>, ptr %private.contiguous.address758, align 8
  %2274 = select <8 x i1> %95, <8 x i64> %.splat757, <8 x i64> %private.contiguous.preserve759
  store <8 x i64> %2274, ptr %private.contiguous.address758, align 8
  %2275 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2276 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2277 = add <8 x i64> %2276, splat (i64 512)
  %2278 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2275, 0
  %2279 = insertvalue { <8 x ptr>, <8 x i64> } %2278, <8 x i64> %2277, 1
  %.splatinsert760 = insertelement <8 x i64> poison, i64 %1985, i64 0
  %.splat761 = shufflevector <8 x i64> %.splatinsert760, <8 x i64> poison, <8 x i32> zeroinitializer
  %2280 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2281 = extractvalue { <8 x ptr>, <8 x i64> } %2279, 1
  %2282 = extractelement <8 x ptr> %2280, i32 0
  %2283 = extractelement <8 x i64> %2281, i32 0
  %2284 = sub i64 %2283, 0
  %2285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2286 = select i1 %2285, i64 %2284, i64 0
  %private.contiguous.address762 = getelementptr i8, ptr %2282, i64 %2286
  %private.contiguous.preserve763 = load <8 x i64>, ptr %private.contiguous.address762, align 8
  %2287 = select <8 x i1> %95, <8 x i64> %.splat761, <8 x i64> %private.contiguous.preserve763
  store <8 x i64> %2287, ptr %private.contiguous.address762, align 8
  %2288 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2289 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2290 = add <8 x i64> %2289, splat (i64 576)
  %2291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2288, 0
  %2292 = insertvalue { <8 x ptr>, <8 x i64> } %2291, <8 x i64> %2290, 1
  %.splatinsert764 = insertelement <8 x i64> poison, i64 %1986, i64 0
  %.splat765 = shufflevector <8 x i64> %.splatinsert764, <8 x i64> poison, <8 x i32> zeroinitializer
  %2293 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2294 = extractvalue { <8 x ptr>, <8 x i64> } %2292, 1
  %2295 = extractelement <8 x ptr> %2293, i32 0
  %2296 = extractelement <8 x i64> %2294, i32 0
  %2297 = sub i64 %2296, 0
  %2298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2299 = select i1 %2298, i64 %2297, i64 0
  %private.contiguous.address766 = getelementptr i8, ptr %2295, i64 %2299
  %private.contiguous.preserve767 = load <8 x i64>, ptr %private.contiguous.address766, align 8
  %2300 = select <8 x i1> %95, <8 x i64> %.splat765, <8 x i64> %private.contiguous.preserve767
  store <8 x i64> %2300, ptr %private.contiguous.address766, align 8
  %2301 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2302 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2303 = add <8 x i64> %2302, splat (i64 640)
  %2304 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2301, 0
  %2305 = insertvalue { <8 x ptr>, <8 x i64> } %2304, <8 x i64> %2303, 1
  %.splatinsert768 = insertelement <8 x i64> poison, i64 %1987, i64 0
  %.splat769 = shufflevector <8 x i64> %.splatinsert768, <8 x i64> poison, <8 x i32> zeroinitializer
  %2306 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2307 = extractvalue { <8 x ptr>, <8 x i64> } %2305, 1
  %2308 = extractelement <8 x ptr> %2306, i32 0
  %2309 = extractelement <8 x i64> %2307, i32 0
  %2310 = sub i64 %2309, 0
  %2311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2312 = select i1 %2311, i64 %2310, i64 0
  %private.contiguous.address770 = getelementptr i8, ptr %2308, i64 %2312
  %private.contiguous.preserve771 = load <8 x i64>, ptr %private.contiguous.address770, align 8
  %2313 = select <8 x i1> %95, <8 x i64> %.splat769, <8 x i64> %private.contiguous.preserve771
  store <8 x i64> %2313, ptr %private.contiguous.address770, align 8
  %2314 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2315 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2316 = add <8 x i64> %2315, splat (i64 704)
  %2317 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2314, 0
  %2318 = insertvalue { <8 x ptr>, <8 x i64> } %2317, <8 x i64> %2316, 1
  %.splatinsert772 = insertelement <8 x i64> poison, i64 %1988, i64 0
  %.splat773 = shufflevector <8 x i64> %.splatinsert772, <8 x i64> poison, <8 x i32> zeroinitializer
  %2319 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2320 = extractvalue { <8 x ptr>, <8 x i64> } %2318, 1
  %2321 = extractelement <8 x ptr> %2319, i32 0
  %2322 = extractelement <8 x i64> %2320, i32 0
  %2323 = sub i64 %2322, 0
  %2324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2325 = select i1 %2324, i64 %2323, i64 0
  %private.contiguous.address774 = getelementptr i8, ptr %2321, i64 %2325
  %private.contiguous.preserve775 = load <8 x i64>, ptr %private.contiguous.address774, align 8
  %2326 = select <8 x i1> %95, <8 x i64> %.splat773, <8 x i64> %private.contiguous.preserve775
  store <8 x i64> %2326, ptr %private.contiguous.address774, align 8
  %2327 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2328 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2329 = add <8 x i64> %2328, splat (i64 768)
  %2330 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2327, 0
  %2331 = insertvalue { <8 x ptr>, <8 x i64> } %2330, <8 x i64> %2329, 1
  %.splatinsert776 = insertelement <8 x i64> poison, i64 %1989, i64 0
  %.splat777 = shufflevector <8 x i64> %.splatinsert776, <8 x i64> poison, <8 x i32> zeroinitializer
  %2332 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2333 = extractvalue { <8 x ptr>, <8 x i64> } %2331, 1
  %2334 = extractelement <8 x ptr> %2332, i32 0
  %2335 = extractelement <8 x i64> %2333, i32 0
  %2336 = sub i64 %2335, 0
  %2337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2338 = select i1 %2337, i64 %2336, i64 0
  %private.contiguous.address778 = getelementptr i8, ptr %2334, i64 %2338
  %private.contiguous.preserve779 = load <8 x i64>, ptr %private.contiguous.address778, align 8
  %2339 = select <8 x i1> %95, <8 x i64> %.splat777, <8 x i64> %private.contiguous.preserve779
  store <8 x i64> %2339, ptr %private.contiguous.address778, align 8
  %2340 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2341 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2342 = add <8 x i64> %2341, splat (i64 832)
  %2343 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2340, 0
  %2344 = insertvalue { <8 x ptr>, <8 x i64> } %2343, <8 x i64> %2342, 1
  %.splatinsert780 = insertelement <8 x i64> poison, i64 %1990, i64 0
  %.splat781 = shufflevector <8 x i64> %.splatinsert780, <8 x i64> poison, <8 x i32> zeroinitializer
  %2345 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2346 = extractvalue { <8 x ptr>, <8 x i64> } %2344, 1
  %2347 = extractelement <8 x ptr> %2345, i32 0
  %2348 = extractelement <8 x i64> %2346, i32 0
  %2349 = sub i64 %2348, 0
  %2350 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2351 = select i1 %2350, i64 %2349, i64 0
  %private.contiguous.address782 = getelementptr i8, ptr %2347, i64 %2351
  %private.contiguous.preserve783 = load <8 x i64>, ptr %private.contiguous.address782, align 8
  %2352 = select <8 x i1> %95, <8 x i64> %.splat781, <8 x i64> %private.contiguous.preserve783
  store <8 x i64> %2352, ptr %private.contiguous.address782, align 8
  %2353 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2354 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2355 = add <8 x i64> %2354, splat (i64 896)
  %2356 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2353, 0
  %2357 = insertvalue { <8 x ptr>, <8 x i64> } %2356, <8 x i64> %2355, 1
  %.splatinsert784 = insertelement <8 x i64> poison, i64 %1991, i64 0
  %.splat785 = shufflevector <8 x i64> %.splatinsert784, <8 x i64> poison, <8 x i32> zeroinitializer
  %2358 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2359 = extractvalue { <8 x ptr>, <8 x i64> } %2357, 1
  %2360 = extractelement <8 x ptr> %2358, i32 0
  %2361 = extractelement <8 x i64> %2359, i32 0
  %2362 = sub i64 %2361, 0
  %2363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2364 = select i1 %2363, i64 %2362, i64 0
  %private.contiguous.address786 = getelementptr i8, ptr %2360, i64 %2364
  %private.contiguous.preserve787 = load <8 x i64>, ptr %private.contiguous.address786, align 8
  %2365 = select <8 x i1> %95, <8 x i64> %.splat785, <8 x i64> %private.contiguous.preserve787
  store <8 x i64> %2365, ptr %private.contiguous.address786, align 8
  %2366 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2367 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %2368 = add <8 x i64> %2367, splat (i64 960)
  %2369 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2366, 0
  %2370 = insertvalue { <8 x ptr>, <8 x i64> } %2369, <8 x i64> %2368, 1
  %.splatinsert788 = insertelement <8 x i64> poison, i64 %1992, i64 0
  %.splat789 = shufflevector <8 x i64> %.splatinsert788, <8 x i64> poison, <8 x i32> zeroinitializer
  %2371 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2372 = extractvalue { <8 x ptr>, <8 x i64> } %2370, 1
  %2373 = extractelement <8 x ptr> %2371, i32 0
  %2374 = extractelement <8 x i64> %2372, i32 0
  %2375 = sub i64 %2374, 0
  %2376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2377 = select i1 %2376, i64 %2375, i64 0
  %private.contiguous.address790 = getelementptr i8, ptr %2373, i64 %2377
  %private.contiguous.preserve791 = load <8 x i64>, ptr %private.contiguous.address790, align 8
  %2378 = select <8 x i1> %95, <8 x i64> %.splat789, <8 x i64> %private.contiguous.preserve791
  store <8 x i64> %2378, ptr %private.contiguous.address790, align 8
  %.spill.load792 = load <8 x i64>, ptr %.spill61, align 64
  %2379 = add <8 x i64> zeroinitializer, %.spill.load792
  %.spill.load793 = load <8 x i64>, ptr %.spill61, align 64
  %2380 = add <8 x i64> splat (i64 1), %.spill.load793
  %.spill.load794 = load <8 x i64>, ptr %.spill61, align 64
  %2381 = add <8 x i64> splat (i64 2), %.spill.load794
  %.spill.load795 = load <8 x i64>, ptr %.spill61, align 64
  %2382 = add <8 x i64> splat (i64 3), %.spill.load795
  %.spill.load796 = load <8 x i64>, ptr %.spill61, align 64
  %2383 = add <8 x i64> splat (i64 4), %.spill.load796
  %.spill.load797 = load <8 x i64>, ptr %.spill61, align 64
  %2384 = add <8 x i64> splat (i64 5), %.spill.load797
  %.spill.load798 = load <8 x i64>, ptr %.spill61, align 64
  %2385 = add <8 x i64> splat (i64 6), %.spill.load798
  %.spill.load799 = load <8 x i64>, ptr %.spill61, align 64
  %2386 = add <8 x i64> splat (i64 7), %.spill.load799
  %2387 = add <8 x i64> %2379, splat (i64 129)
  %2388 = add <8 x i64> %2380, splat (i64 129)
  %2389 = add <8 x i64> %2381, splat (i64 129)
  %2390 = add <8 x i64> %2382, splat (i64 129)
  %2391 = add <8 x i64> %2383, splat (i64 129)
  %2392 = add <8 x i64> %2384, splat (i64 129)
  %2393 = add <8 x i64> %2385, splat (i64 129)
  %2394 = add <8 x i64> %2386, splat (i64 129)
  %2395 = sub <8 x i64> %2387, splat (i64 64)
  %2396 = sub <8 x i64> %2388, splat (i64 64)
  %2397 = sub <8 x i64> %2389, splat (i64 64)
  %2398 = sub <8 x i64> %2390, splat (i64 64)
  %2399 = sub <8 x i64> %2391, splat (i64 64)
  %2400 = sub <8 x i64> %2392, splat (i64 64)
  %2401 = sub <8 x i64> %2393, splat (i64 64)
  %2402 = sub <8 x i64> %2394, splat (i64 64)
  %2403 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %2404 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2405 = extractvalue { <8 x ptr>, <8 x i64> } %2403, 0
  %2406 = select <8 x i1> %95, <8 x ptr> %2404, <8 x ptr> %2405
  %2407 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2408 = extractvalue { <8 x ptr>, <8 x i64> } %2403, 1
  %2409 = select <8 x i1> %95, <8 x i64> %2407, <8 x i64> %2408
  %2410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2406, 0
  %2411 = insertvalue { <8 x ptr>, <8 x i64> } %2410, <8 x i64> %2409, 1
  store { <8 x ptr>, <8 x i64> } %2411, ptr %tile_snapshot.spill94, align 64
  %2412 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2413 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2414 = add <8 x i64> %2413, zeroinitializer
  %2415 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2412, 0
  %2416 = insertvalue { <8 x ptr>, <8 x i64> } %2415, <8 x i64> %2414, 1
  %2417 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2418 = extractvalue { <8 x ptr>, <8 x i64> } %2416, 1
  %2419 = extractelement <8 x ptr> %2417, i32 0
  %2420 = extractelement <8 x i64> %2418, i32 0
  %2421 = sub i64 %2420, 0
  %2422 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2423 = select i1 %2422, i64 %2421, i64 0
  %private.contiguous.address800 = getelementptr i8, ptr %2419, i64 %2423
  %private.contiguous.preserve801 = load <8 x i64>, ptr %private.contiguous.address800, align 8
  %2424 = select <8 x i1> %95, <8 x i64> %2395, <8 x i64> %private.contiguous.preserve801
  store <8 x i64> %2424, ptr %private.contiguous.address800, align 8
  %2425 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2426 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2427 = add <8 x i64> %2426, splat (i64 64)
  %2428 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2425, 0
  %2429 = insertvalue { <8 x ptr>, <8 x i64> } %2428, <8 x i64> %2427, 1
  %2430 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2431 = extractvalue { <8 x ptr>, <8 x i64> } %2429, 1
  %2432 = extractelement <8 x ptr> %2430, i32 0
  %2433 = extractelement <8 x i64> %2431, i32 0
  %2434 = sub i64 %2433, 0
  %2435 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2436 = select i1 %2435, i64 %2434, i64 0
  %private.contiguous.address802 = getelementptr i8, ptr %2432, i64 %2436
  %private.contiguous.preserve803 = load <8 x i64>, ptr %private.contiguous.address802, align 8
  %2437 = select <8 x i1> %95, <8 x i64> %2396, <8 x i64> %private.contiguous.preserve803
  store <8 x i64> %2437, ptr %private.contiguous.address802, align 8
  %2438 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2439 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2440 = add <8 x i64> %2439, splat (i64 128)
  %2441 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2438, 0
  %2442 = insertvalue { <8 x ptr>, <8 x i64> } %2441, <8 x i64> %2440, 1
  %2443 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2444 = extractvalue { <8 x ptr>, <8 x i64> } %2442, 1
  %2445 = extractelement <8 x ptr> %2443, i32 0
  %2446 = extractelement <8 x i64> %2444, i32 0
  %2447 = sub i64 %2446, 0
  %2448 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2449 = select i1 %2448, i64 %2447, i64 0
  %private.contiguous.address804 = getelementptr i8, ptr %2445, i64 %2449
  %private.contiguous.preserve805 = load <8 x i64>, ptr %private.contiguous.address804, align 8
  %2450 = select <8 x i1> %95, <8 x i64> %2397, <8 x i64> %private.contiguous.preserve805
  store <8 x i64> %2450, ptr %private.contiguous.address804, align 8
  %2451 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2452 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2453 = add <8 x i64> %2452, splat (i64 192)
  %2454 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2451, 0
  %2455 = insertvalue { <8 x ptr>, <8 x i64> } %2454, <8 x i64> %2453, 1
  %2456 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2457 = extractvalue { <8 x ptr>, <8 x i64> } %2455, 1
  %2458 = extractelement <8 x ptr> %2456, i32 0
  %2459 = extractelement <8 x i64> %2457, i32 0
  %2460 = sub i64 %2459, 0
  %2461 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2462 = select i1 %2461, i64 %2460, i64 0
  %private.contiguous.address806 = getelementptr i8, ptr %2458, i64 %2462
  %private.contiguous.preserve807 = load <8 x i64>, ptr %private.contiguous.address806, align 8
  %2463 = select <8 x i1> %95, <8 x i64> %2398, <8 x i64> %private.contiguous.preserve807
  store <8 x i64> %2463, ptr %private.contiguous.address806, align 8
  %2464 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2465 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2466 = add <8 x i64> %2465, splat (i64 256)
  %2467 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2464, 0
  %2468 = insertvalue { <8 x ptr>, <8 x i64> } %2467, <8 x i64> %2466, 1
  %2469 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2470 = extractvalue { <8 x ptr>, <8 x i64> } %2468, 1
  %2471 = extractelement <8 x ptr> %2469, i32 0
  %2472 = extractelement <8 x i64> %2470, i32 0
  %2473 = sub i64 %2472, 0
  %2474 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2475 = select i1 %2474, i64 %2473, i64 0
  %private.contiguous.address808 = getelementptr i8, ptr %2471, i64 %2475
  %private.contiguous.preserve809 = load <8 x i64>, ptr %private.contiguous.address808, align 8
  %2476 = select <8 x i1> %95, <8 x i64> %2399, <8 x i64> %private.contiguous.preserve809
  store <8 x i64> %2476, ptr %private.contiguous.address808, align 8
  %2477 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2478 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2479 = add <8 x i64> %2478, splat (i64 320)
  %2480 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2477, 0
  %2481 = insertvalue { <8 x ptr>, <8 x i64> } %2480, <8 x i64> %2479, 1
  %2482 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2483 = extractvalue { <8 x ptr>, <8 x i64> } %2481, 1
  %2484 = extractelement <8 x ptr> %2482, i32 0
  %2485 = extractelement <8 x i64> %2483, i32 0
  %2486 = sub i64 %2485, 0
  %2487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2488 = select i1 %2487, i64 %2486, i64 0
  %private.contiguous.address810 = getelementptr i8, ptr %2484, i64 %2488
  %private.contiguous.preserve811 = load <8 x i64>, ptr %private.contiguous.address810, align 8
  %2489 = select <8 x i1> %95, <8 x i64> %2400, <8 x i64> %private.contiguous.preserve811
  store <8 x i64> %2489, ptr %private.contiguous.address810, align 8
  %2490 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2491 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2492 = add <8 x i64> %2491, splat (i64 384)
  %2493 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2490, 0
  %2494 = insertvalue { <8 x ptr>, <8 x i64> } %2493, <8 x i64> %2492, 1
  %2495 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2496 = extractvalue { <8 x ptr>, <8 x i64> } %2494, 1
  %2497 = extractelement <8 x ptr> %2495, i32 0
  %2498 = extractelement <8 x i64> %2496, i32 0
  %2499 = sub i64 %2498, 0
  %2500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2501 = select i1 %2500, i64 %2499, i64 0
  %private.contiguous.address812 = getelementptr i8, ptr %2497, i64 %2501
  %private.contiguous.preserve813 = load <8 x i64>, ptr %private.contiguous.address812, align 8
  %2502 = select <8 x i1> %95, <8 x i64> %2401, <8 x i64> %private.contiguous.preserve813
  store <8 x i64> %2502, ptr %private.contiguous.address812, align 8
  %2503 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2504 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %2505 = add <8 x i64> %2504, splat (i64 448)
  %2506 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2503, 0
  %2507 = insertvalue { <8 x ptr>, <8 x i64> } %2506, <8 x i64> %2505, 1
  %2508 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2509 = extractvalue { <8 x ptr>, <8 x i64> } %2507, 1
  %2510 = extractelement <8 x ptr> %2508, i32 0
  %2511 = extractelement <8 x i64> %2509, i32 0
  %2512 = sub i64 %2511, 0
  %2513 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2514 = select i1 %2513, i64 %2512, i64 0
  %private.contiguous.address814 = getelementptr i8, ptr %2510, i64 %2514
  %private.contiguous.preserve815 = load <8 x i64>, ptr %private.contiguous.address814, align 8
  %2515 = select <8 x i1> %95, <8 x i64> %2402, <8 x i64> %private.contiguous.preserve815
  store <8 x i64> %2515, ptr %private.contiguous.address814, align 8
  %2516 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %2517 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %2518 = extractvalue { <8 x ptr>, <8 x i64> } %2516, 0
  %2519 = select <8 x i1> %95, <8 x ptr> %2517, <8 x ptr> %2518
  %2520 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %2521 = extractvalue { <8 x ptr>, <8 x i64> } %2516, 1
  %2522 = select <8 x i1> %95, <8 x i64> %2520, <8 x i64> %2521
  %2523 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2519, 0
  %2524 = insertvalue { <8 x ptr>, <8 x i64> } %2523, <8 x i64> %2522, 1
  store { <8 x ptr>, <8 x i64> } %2524, ptr %tile_snapshot.spill95, align 64
  store i64 0, ptr %.slot96, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state816 = load i64, ptr %.slot96, align 4
  %2525 = icmp slt i64 %.state816, 128
  br i1 %2525, label %direct.true817, label %direct.false818

direct.schedule.17:                               ; preds = %direct.true817
  %.state819 = load i64, ptr %.slot96, align 4
  %2526 = srem i64 %.state819, 8
  %.state820 = load i64, ptr %.slot96, align 4
  %2527 = sdiv i64 %.state820, 8
  %2528 = add i64 0, %2527
  %tile_snapshot.spill.load821 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill92, align 64
  %2529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load821, 0
  %2530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load821, 1
  %.splatinsert822 = insertelement <8 x i64> poison, i64 %2528, i64 0
  %.splat823 = shufflevector <8 x i64> %.splatinsert822, <8 x i64> poison, <8 x i32> zeroinitializer
  %2531 = add <8 x i64> %2530, %.splat823
  %2532 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2529, 0
  %2533 = insertvalue { <8 x ptr>, <8 x i64> } %2532, <8 x i64> %2531, 1
  %2534 = extractvalue { <8 x ptr>, <8 x i64> } %2533, 0
  %2535 = extractvalue { <8 x ptr>, <8 x i64> } %2533, 1
  %2536 = getelementptr i8, <8 x ptr> %2534, <8 x i64> %2535
  %2537 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %2536, <8 x i1> %95, <8 x i8> zeroinitializer)
  %2538 = icmp ne <8 x i8> %2537, zeroinitializer
  %2539 = mul i64 %2528, 8
  %2540 = add i64 %2539, %2526
  %2541 = srem i64 %2540, 8
  %2542 = sdiv i64 %2540, 8
  %2543 = add i64 0, %2542
  %tile_snapshot.spill.load824 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %2544 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load824, 0
  %2545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load824, 1
  %.splatinsert825 = insertelement <8 x i64> poison, i64 %2543, i64 0
  %.splat826 = shufflevector <8 x i64> %.splatinsert825, <8 x i64> poison, <8 x i32> zeroinitializer
  %2546 = mul <8 x i64> %.splat826, splat (i64 64)
  %2547 = add <8 x i64> %2545, %2546
  %2548 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2544, 0
  %2549 = insertvalue { <8 x ptr>, <8 x i64> } %2548, <8 x i64> %2547, 1
  %2550 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %2551 = extractvalue { <8 x ptr>, <8 x i64> } %2549, 1
  %2552 = extractelement <8 x ptr> %2550, i32 0
  %2553 = extractelement <8 x i64> %2551, i32 0
  %2554 = sub i64 %2553, 0
  %2555 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2556 = select i1 %2555, i64 %2554, i64 0
  %private.contiguous.address827 = getelementptr i8, ptr %2552, i64 %2556
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address827, align 8
  %2557 = select <8 x i1> %95, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %2558 = add i64 0, %2541
  %tile_snapshot.spill.load828 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill94, align 64
  %2559 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load828, 0
  %2560 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load828, 1
  %.splatinsert829 = insertelement <8 x i64> poison, i64 %2558, i64 0
  %.splat830 = shufflevector <8 x i64> %.splatinsert829, <8 x i64> poison, <8 x i32> zeroinitializer
  %2561 = mul <8 x i64> %.splat830, splat (i64 64)
  %2562 = add <8 x i64> %2560, %2561
  %2563 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2559, 0
  %2564 = insertvalue { <8 x ptr>, <8 x i64> } %2563, <8 x i64> %2562, 1
  %2565 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %2566 = extractvalue { <8 x ptr>, <8 x i64> } %2564, 1
  %2567 = extractelement <8 x ptr> %2565, i32 0
  %2568 = extractelement <8 x i64> %2566, i32 0
  %2569 = sub i64 %2568, 0
  %2570 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2571 = select i1 %2570, i64 %2569, i64 0
  %private.contiguous.address831 = getelementptr i8, ptr %2567, i64 %2571
  %private.contiguous.load832 = load <8 x i64>, ptr %private.contiguous.address831, align 8
  %2572 = select <8 x i1> %95, <8 x i64> %private.contiguous.load832, <8 x i64> zeroinitializer
  %2573 = icmp sle <8 x i64> %2557, %2572
  %2574 = and <8 x i1> %2538, %2573
  %tile_snapshot.spill.load833 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %2575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load833, 0
  %2576 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load833, 1
  %.state834 = load i64, ptr %.slot96, align 4
  %.splatinsert835 = insertelement <8 x i64> poison, i64 %.state834, i64 0
  %.splat836 = shufflevector <8 x i64> %.splatinsert835, <8 x i64> poison, <8 x i32> zeroinitializer
  %2577 = add <8 x i64> %2576, %.splat836
  %2578 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2575, 0
  %2579 = insertvalue { <8 x ptr>, <8 x i64> } %2578, <8 x i64> %2577, 1
  %2580 = extractvalue { <8 x ptr>, <8 x i64> } %2579, 0
  %2581 = extractvalue { <8 x ptr>, <8 x i64> } %2579, 1
  %2582 = getelementptr i8, <8 x ptr> %2580, <8 x i64> %2581
  %2583 = zext <8 x i1> %2574 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2583, <8 x ptr> align 1 %2582, <8 x i1> %95)
  %.state837 = load i64, ptr %.slot96, align 4
  %2584 = add i64 %.state837, 1
  store i64 %2584, ptr %.slot96, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false818
  %2585 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %2586 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2587 = extractvalue { <8 x ptr>, <8 x i64> } %2585, 0
  %2588 = select <8 x i1> %95, <8 x ptr> %2586, <8 x ptr> %2587
  %2589 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %2590 = extractvalue { <8 x ptr>, <8 x i64> } %2585, 1
  %2591 = select <8 x i1> %95, <8 x i64> %2589, <8 x i64> %2590
  %2592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2588, 0
  %2593 = insertvalue { <8 x ptr>, <8 x i64> } %2592, <8 x i64> %2591, 1
  store { <8 x ptr>, <8 x i64> } %2593, ptr %tile_snapshot.spill97, align 64
  store i64 0, ptr %.slot98, align 4
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state838 = load i64, ptr %.slot98, align 4
  %2594 = icmp slt i64 %.state838, 128
  br i1 %2594, label %direct.true839, label %direct.false840

direct.schedule.20:                               ; preds = %direct.true839
  %.state841 = load i64, ptr %.slot98, align 4
  %2595 = srem i64 %.state841, 16
  %.state842 = load i64, ptr %.slot98, align 4
  %2596 = sdiv i64 %.state842, 16
  %2597 = add i64 0, %2595
  %2598 = mul i64 %2597, 8
  %2599 = add i64 %2598, %2596
  %tile_snapshot.spill.load843 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %2600 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load843, 0
  %2601 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load843, 1
  %.splatinsert844 = insertelement <8 x i64> poison, i64 %2599, i64 0
  %.splat845 = shufflevector <8 x i64> %.splatinsert844, <8 x i64> poison, <8 x i32> zeroinitializer
  %2602 = add <8 x i64> %2601, %.splat845
  %2603 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2600, 0
  %2604 = insertvalue { <8 x ptr>, <8 x i64> } %2603, <8 x i64> %2602, 1
  %2605 = extractvalue { <8 x ptr>, <8 x i64> } %2604, 0
  %2606 = extractvalue { <8 x ptr>, <8 x i64> } %2604, 1
  %2607 = getelementptr i8, <8 x ptr> %2605, <8 x i64> %2606
  %2608 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %2607, <8 x i1> %95, <8 x i8> zeroinitializer)
  %2609 = icmp ne <8 x i8> %2608, zeroinitializer
  %2610 = add i64 0, %2596
  %2611 = mul i64 %2610, 16
  %2612 = add i64 %2611, %2595
  %2613 = srem i64 %2612, 16
  %2614 = sdiv i64 %2612, 16
  %2615 = add i64 0, %2614
  %2616 = mul i64 %2615, 16
  %2617 = add i64 %2616, %2613
  %tile_snapshot.spill.load846 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill88, align 64
  %2618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load846, 0
  %2619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load846, 1
  %.splatinsert847 = insertelement <8 x i64> poison, i64 %2617, i64 0
  %.splat848 = shufflevector <8 x i64> %.splatinsert847, <8 x i64> poison, <8 x i32> zeroinitializer
  %2620 = mul <8 x i64> %.splat848, splat (i64 32)
  %2621 = add <8 x i64> %2619, %2620
  %2622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2618, 0
  %2623 = insertvalue { <8 x ptr>, <8 x i64> } %2622, <8 x i64> %2621, 1
  %2624 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %2625 = extractvalue { <8 x ptr>, <8 x i64> } %2623, 1
  %2626 = extractelement <8 x ptr> %2624, i32 0
  %2627 = extractelement <8 x i64> %2625, i32 0
  %2628 = sub i64 %2627, 0
  %2629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2630 = select i1 %2629, i64 %2628, i64 0
  %private.contiguous.address849 = getelementptr i8, ptr %2626, i64 %2630
  %private.contiguous.load850 = load <8 x float>, ptr %private.contiguous.address849, align 4
  %2631 = select <8 x i1> %95, <8 x float> %private.contiguous.load850, <8 x float> zeroinitializer
  %2632 = fmul <8 x float> %2631, splat (float 0x3FC6A09E60000000)
  %2633 = select <8 x i1> %2609, <8 x float> %2632, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load851 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %2634 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load851, 0
  %2635 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load851, 1
  %.state852 = load i64, ptr %.slot98, align 4
  %.splatinsert853 = insertelement <8 x i64> poison, i64 %.state852, i64 0
  %.splat854 = shufflevector <8 x i64> %.splatinsert853, <8 x i64> poison, <8 x i32> zeroinitializer
  %2636 = mul <8 x i64> %.splat854, splat (i64 32)
  %2637 = add <8 x i64> %2635, %2636
  %2638 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2634, 0
  %2639 = insertvalue { <8 x ptr>, <8 x i64> } %2638, <8 x i64> %2637, 1
  %2640 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2641 = extractvalue { <8 x ptr>, <8 x i64> } %2639, 1
  %2642 = extractelement <8 x ptr> %2640, i32 0
  %2643 = extractelement <8 x i64> %2641, i32 0
  %2644 = sub i64 %2643, 0
  %2645 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2646 = select i1 %2645, i64 %2644, i64 0
  %private.contiguous.address855 = getelementptr i8, ptr %2642, i64 %2646
  %private.contiguous.preserve856 = load <8 x float>, ptr %private.contiguous.address855, align 4
  %2647 = select <8 x i1> %95, <8 x float> %2633, <8 x float> %private.contiguous.preserve856
  store <8 x float> %2647, ptr %private.contiguous.address855, align 4
  %.state857 = load i64, ptr %.slot98, align 4
  %2648 = add i64 %.state857, 1
  store i64 %2648, ptr %.slot98, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false840
  store i64 0, ptr %.slot99, align 4
  %2649 = load <8 x float>, ptr %.slot100, align 32
  %2650 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %2649
  store <8 x float> %2650, ptr %.slot100, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state858 = load i64, ptr %.slot99, align 4
  %2651 = icmp slt i64 %.state858, 16
  br i1 %2651, label %direct.true859, label %direct.false860

direct.schedule.23:                               ; preds = %direct.true859
  %.state861 = load i64, ptr %.slot99, align 4
  %2652 = sdiv i64 %.state861, 1
  %.spill.load862 = load i64, ptr %.spill64, align 4
  %2653 = mul i64 %.spill.load862, 1
  %2654 = add i64 %2653, 0
  %2655 = mul i64 %2654, 8
  %2656 = add i64 %2655, 0
  %2657 = mul i64 %2656, 16
  %2658 = add i64 %2657, %2652
  %tile_snapshot.spill.load863 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %2659 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load863, 0
  %2660 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load863, 1
  %.splatinsert864 = insertelement <8 x i64> poison, i64 %2658, i64 0
  %.splat865 = shufflevector <8 x i64> %.splatinsert864, <8 x i64> poison, <8 x i32> zeroinitializer
  %2661 = mul <8 x i64> %.splat865, splat (i64 32)
  %2662 = add <8 x i64> %2660, %2661
  %2663 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2659, 0
  %2664 = insertvalue { <8 x ptr>, <8 x i64> } %2663, <8 x i64> %2662, 1
  %2665 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2666 = extractvalue { <8 x ptr>, <8 x i64> } %2664, 1
  %2667 = extractelement <8 x ptr> %2665, i32 0
  %2668 = extractelement <8 x i64> %2666, i32 0
  %2669 = sub i64 %2668, 0
  %2670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2671 = select i1 %2670, i64 %2669, i64 0
  %private.contiguous.address866 = getelementptr i8, ptr %2667, i64 %2671
  %private.contiguous.load867 = load <8 x float>, ptr %private.contiguous.address866, align 4
  %2672 = select <8 x i1> %95, <8 x float> %private.contiguous.load867, <8 x float> zeroinitializer
  %.state868 = load <8 x float>, ptr %.slot100, align 32
  %2673 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state868, <8 x float> %2672)
  %.state869 = load i64, ptr %.slot99, align 4
  %2674 = add i64 %.state869, 1
  store i64 %2674, ptr %.slot99, align 4
  %2675 = load <8 x float>, ptr %.slot100, align 32
  %2676 = select <8 x i1> %95, <8 x float> %2673, <8 x float> %2675
  store <8 x float> %2676, ptr %.slot100, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false860
  store i64 0, ptr %.slot101, align 4
  %2677 = load <8 x float>, ptr %.slot102, align 32
  %2678 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %2677
  store <8 x float> %2678, ptr %.slot102, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state870 = load i64, ptr %.slot101, align 4
  %2679 = icmp slt i64 %.state870, 16
  br i1 %2679, label %direct.true871, label %direct.false872

direct.schedule.26:                               ; preds = %direct.true871
  %.state873 = load i64, ptr %.slot101, align 4
  %2680 = sdiv i64 %.state873, 1
  %.spill.load874 = load i64, ptr %.spill64, align 4
  %2681 = mul i64 %.spill.load874, 1
  %2682 = add i64 %2681, 0
  %2683 = mul i64 %2682, 8
  %2684 = add i64 %2683, 1
  %2685 = mul i64 %2684, 16
  %2686 = add i64 %2685, %2680
  %tile_snapshot.spill.load875 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %2687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load875, 0
  %2688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load875, 1
  %.splatinsert876 = insertelement <8 x i64> poison, i64 %2686, i64 0
  %.splat877 = shufflevector <8 x i64> %.splatinsert876, <8 x i64> poison, <8 x i32> zeroinitializer
  %2689 = mul <8 x i64> %.splat877, splat (i64 32)
  %2690 = add <8 x i64> %2688, %2689
  %2691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2687, 0
  %2692 = insertvalue { <8 x ptr>, <8 x i64> } %2691, <8 x i64> %2690, 1
  %2693 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2694 = extractvalue { <8 x ptr>, <8 x i64> } %2692, 1
  %2695 = extractelement <8 x ptr> %2693, i32 0
  %2696 = extractelement <8 x i64> %2694, i32 0
  %2697 = sub i64 %2696, 0
  %2698 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2699 = select i1 %2698, i64 %2697, i64 0
  %private.contiguous.address878 = getelementptr i8, ptr %2695, i64 %2699
  %private.contiguous.load879 = load <8 x float>, ptr %private.contiguous.address878, align 4
  %2700 = select <8 x i1> %95, <8 x float> %private.contiguous.load879, <8 x float> zeroinitializer
  %.state880 = load <8 x float>, ptr %.slot102, align 32
  %2701 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state880, <8 x float> %2700)
  %.state881 = load i64, ptr %.slot101, align 4
  %2702 = add i64 %.state881, 1
  store i64 %2702, ptr %.slot101, align 4
  %2703 = load <8 x float>, ptr %.slot102, align 32
  %2704 = select <8 x i1> %95, <8 x float> %2701, <8 x float> %2703
  store <8 x float> %2704, ptr %.slot102, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false872
  store i64 0, ptr %.slot103, align 4
  %2705 = load <8 x float>, ptr %.slot104, align 32
  %2706 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %2705
  store <8 x float> %2706, ptr %.slot104, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.29, %direct.schedule.27
  %.state882 = load i64, ptr %.slot103, align 4
  %2707 = icmp slt i64 %.state882, 16
  br i1 %2707, label %direct.true883, label %direct.false884

direct.schedule.29:                               ; preds = %direct.true883
  %.state885 = load i64, ptr %.slot103, align 4
  %2708 = sdiv i64 %.state885, 1
  %.spill.load886 = load i64, ptr %.spill64, align 4
  %2709 = mul i64 %.spill.load886, 1
  %2710 = add i64 %2709, 0
  %2711 = mul i64 %2710, 8
  %2712 = add i64 %2711, 2
  %2713 = mul i64 %2712, 16
  %2714 = add i64 %2713, %2708
  %tile_snapshot.spill.load887 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %2715 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load887, 0
  %2716 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load887, 1
  %.splatinsert888 = insertelement <8 x i64> poison, i64 %2714, i64 0
  %.splat889 = shufflevector <8 x i64> %.splatinsert888, <8 x i64> poison, <8 x i32> zeroinitializer
  %2717 = mul <8 x i64> %.splat889, splat (i64 32)
  %2718 = add <8 x i64> %2716, %2717
  %2719 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2715, 0
  %2720 = insertvalue { <8 x ptr>, <8 x i64> } %2719, <8 x i64> %2718, 1
  %2721 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2722 = extractvalue { <8 x ptr>, <8 x i64> } %2720, 1
  %2723 = extractelement <8 x ptr> %2721, i32 0
  %2724 = extractelement <8 x i64> %2722, i32 0
  %2725 = sub i64 %2724, 0
  %2726 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2727 = select i1 %2726, i64 %2725, i64 0
  %private.contiguous.address890 = getelementptr i8, ptr %2723, i64 %2727
  %private.contiguous.load891 = load <8 x float>, ptr %private.contiguous.address890, align 4
  %2728 = select <8 x i1> %95, <8 x float> %private.contiguous.load891, <8 x float> zeroinitializer
  %.state892 = load <8 x float>, ptr %.slot104, align 32
  %2729 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state892, <8 x float> %2728)
  %.state893 = load i64, ptr %.slot103, align 4
  %2730 = add i64 %.state893, 1
  store i64 %2730, ptr %.slot103, align 4
  %2731 = load <8 x float>, ptr %.slot104, align 32
  %2732 = select <8 x i1> %95, <8 x float> %2729, <8 x float> %2731
  store <8 x float> %2732, ptr %.slot104, align 32
  br label %direct.schedule.28

direct.schedule.30:                               ; preds = %direct.false884
  store i64 0, ptr %.slot105, align 4
  %2733 = load <8 x float>, ptr %.slot106, align 32
  %2734 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %2733
  store <8 x float> %2734, ptr %.slot106, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state894 = load i64, ptr %.slot105, align 4
  %2735 = icmp slt i64 %.state894, 16
  br i1 %2735, label %direct.true895, label %direct.false896

direct.schedule.32:                               ; preds = %direct.true895
  %.state897 = load i64, ptr %.slot105, align 4
  %2736 = sdiv i64 %.state897, 1
  %.spill.load898 = load i64, ptr %.spill64, align 4
  %2737 = mul i64 %.spill.load898, 1
  %2738 = add i64 %2737, 0
  %2739 = mul i64 %2738, 8
  %2740 = add i64 %2739, 3
  %2741 = mul i64 %2740, 16
  %2742 = add i64 %2741, %2736
  %tile_snapshot.spill.load899 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %2743 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load899, 0
  %2744 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load899, 1
  %.splatinsert900 = insertelement <8 x i64> poison, i64 %2742, i64 0
  %.splat901 = shufflevector <8 x i64> %.splatinsert900, <8 x i64> poison, <8 x i32> zeroinitializer
  %2745 = mul <8 x i64> %.splat901, splat (i64 32)
  %2746 = add <8 x i64> %2744, %2745
  %2747 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2743, 0
  %2748 = insertvalue { <8 x ptr>, <8 x i64> } %2747, <8 x i64> %2746, 1
  %2749 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2750 = extractvalue { <8 x ptr>, <8 x i64> } %2748, 1
  %2751 = extractelement <8 x ptr> %2749, i32 0
  %2752 = extractelement <8 x i64> %2750, i32 0
  %2753 = sub i64 %2752, 0
  %2754 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2755 = select i1 %2754, i64 %2753, i64 0
  %private.contiguous.address902 = getelementptr i8, ptr %2751, i64 %2755
  %private.contiguous.load903 = load <8 x float>, ptr %private.contiguous.address902, align 4
  %2756 = select <8 x i1> %95, <8 x float> %private.contiguous.load903, <8 x float> zeroinitializer
  %.state904 = load <8 x float>, ptr %.slot106, align 32
  %2757 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state904, <8 x float> %2756)
  %.state905 = load i64, ptr %.slot105, align 4
  %2758 = add i64 %.state905, 1
  store i64 %2758, ptr %.slot105, align 4
  %2759 = load <8 x float>, ptr %.slot106, align 32
  %2760 = select <8 x i1> %95, <8 x float> %2757, <8 x float> %2759
  store <8 x float> %2760, ptr %.slot106, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false896
  store i64 0, ptr %.slot107, align 4
  %2761 = load <8 x float>, ptr %.slot108, align 32
  %2762 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %2761
  store <8 x float> %2762, ptr %.slot108, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state906 = load i64, ptr %.slot107, align 4
  %2763 = icmp slt i64 %.state906, 16
  br i1 %2763, label %direct.true907, label %direct.false908

direct.schedule.35:                               ; preds = %direct.true907
  %.state909 = load i64, ptr %.slot107, align 4
  %2764 = sdiv i64 %.state909, 1
  %.spill.load910 = load i64, ptr %.spill64, align 4
  %2765 = mul i64 %.spill.load910, 1
  %2766 = add i64 %2765, 0
  %2767 = mul i64 %2766, 8
  %2768 = add i64 %2767, 4
  %2769 = mul i64 %2768, 16
  %2770 = add i64 %2769, %2764
  %tile_snapshot.spill.load911 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %2771 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load911, 0
  %2772 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load911, 1
  %.splatinsert912 = insertelement <8 x i64> poison, i64 %2770, i64 0
  %.splat913 = shufflevector <8 x i64> %.splatinsert912, <8 x i64> poison, <8 x i32> zeroinitializer
  %2773 = mul <8 x i64> %.splat913, splat (i64 32)
  %2774 = add <8 x i64> %2772, %2773
  %2775 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2771, 0
  %2776 = insertvalue { <8 x ptr>, <8 x i64> } %2775, <8 x i64> %2774, 1
  %2777 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2778 = extractvalue { <8 x ptr>, <8 x i64> } %2776, 1
  %2779 = extractelement <8 x ptr> %2777, i32 0
  %2780 = extractelement <8 x i64> %2778, i32 0
  %2781 = sub i64 %2780, 0
  %2782 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2783 = select i1 %2782, i64 %2781, i64 0
  %private.contiguous.address914 = getelementptr i8, ptr %2779, i64 %2783
  %private.contiguous.load915 = load <8 x float>, ptr %private.contiguous.address914, align 4
  %2784 = select <8 x i1> %95, <8 x float> %private.contiguous.load915, <8 x float> zeroinitializer
  %.state916 = load <8 x float>, ptr %.slot108, align 32
  %2785 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state916, <8 x float> %2784)
  %.state917 = load i64, ptr %.slot107, align 4
  %2786 = add i64 %.state917, 1
  store i64 %2786, ptr %.slot107, align 4
  %2787 = load <8 x float>, ptr %.slot108, align 32
  %2788 = select <8 x i1> %95, <8 x float> %2785, <8 x float> %2787
  store <8 x float> %2788, ptr %.slot108, align 32
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false908
  store i64 0, ptr %.slot109, align 4
  %2789 = load <8 x float>, ptr %.slot110, align 32
  %2790 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %2789
  store <8 x float> %2790, ptr %.slot110, align 32
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state918 = load i64, ptr %.slot109, align 4
  %2791 = icmp slt i64 %.state918, 16
  br i1 %2791, label %direct.true919, label %direct.false920

direct.schedule.38:                               ; preds = %direct.true919
  %.state921 = load i64, ptr %.slot109, align 4
  %2792 = sdiv i64 %.state921, 1
  %.spill.load922 = load i64, ptr %.spill64, align 4
  %2793 = mul i64 %.spill.load922, 1
  %2794 = add i64 %2793, 0
  %2795 = mul i64 %2794, 8
  %2796 = add i64 %2795, 5
  %2797 = mul i64 %2796, 16
  %2798 = add i64 %2797, %2792
  %tile_snapshot.spill.load923 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %2799 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load923, 0
  %2800 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load923, 1
  %.splatinsert924 = insertelement <8 x i64> poison, i64 %2798, i64 0
  %.splat925 = shufflevector <8 x i64> %.splatinsert924, <8 x i64> poison, <8 x i32> zeroinitializer
  %2801 = mul <8 x i64> %.splat925, splat (i64 32)
  %2802 = add <8 x i64> %2800, %2801
  %2803 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2799, 0
  %2804 = insertvalue { <8 x ptr>, <8 x i64> } %2803, <8 x i64> %2802, 1
  %2805 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2806 = extractvalue { <8 x ptr>, <8 x i64> } %2804, 1
  %2807 = extractelement <8 x ptr> %2805, i32 0
  %2808 = extractelement <8 x i64> %2806, i32 0
  %2809 = sub i64 %2808, 0
  %2810 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2811 = select i1 %2810, i64 %2809, i64 0
  %private.contiguous.address926 = getelementptr i8, ptr %2807, i64 %2811
  %private.contiguous.load927 = load <8 x float>, ptr %private.contiguous.address926, align 4
  %2812 = select <8 x i1> %95, <8 x float> %private.contiguous.load927, <8 x float> zeroinitializer
  %.state928 = load <8 x float>, ptr %.slot110, align 32
  %2813 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state928, <8 x float> %2812)
  %.state929 = load i64, ptr %.slot109, align 4
  %2814 = add i64 %.state929, 1
  store i64 %2814, ptr %.slot109, align 4
  %2815 = load <8 x float>, ptr %.slot110, align 32
  %2816 = select <8 x i1> %95, <8 x float> %2813, <8 x float> %2815
  store <8 x float> %2816, ptr %.slot110, align 32
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false920
  store i64 0, ptr %.slot111, align 4
  %2817 = load <8 x float>, ptr %.slot112, align 32
  %2818 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %2817
  store <8 x float> %2818, ptr %.slot112, align 32
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.41, %direct.schedule.39
  %.state930 = load i64, ptr %.slot111, align 4
  %2819 = icmp slt i64 %.state930, 16
  br i1 %2819, label %direct.true931, label %direct.false932

direct.schedule.41:                               ; preds = %direct.true931
  %.state933 = load i64, ptr %.slot111, align 4
  %2820 = sdiv i64 %.state933, 1
  %.spill.load934 = load i64, ptr %.spill64, align 4
  %2821 = mul i64 %.spill.load934, 1
  %2822 = add i64 %2821, 0
  %2823 = mul i64 %2822, 8
  %2824 = add i64 %2823, 6
  %2825 = mul i64 %2824, 16
  %2826 = add i64 %2825, %2820
  %tile_snapshot.spill.load935 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %2827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load935, 0
  %2828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load935, 1
  %.splatinsert936 = insertelement <8 x i64> poison, i64 %2826, i64 0
  %.splat937 = shufflevector <8 x i64> %.splatinsert936, <8 x i64> poison, <8 x i32> zeroinitializer
  %2829 = mul <8 x i64> %.splat937, splat (i64 32)
  %2830 = add <8 x i64> %2828, %2829
  %2831 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2827, 0
  %2832 = insertvalue { <8 x ptr>, <8 x i64> } %2831, <8 x i64> %2830, 1
  %2833 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2834 = extractvalue { <8 x ptr>, <8 x i64> } %2832, 1
  %2835 = extractelement <8 x ptr> %2833, i32 0
  %2836 = extractelement <8 x i64> %2834, i32 0
  %2837 = sub i64 %2836, 0
  %2838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2839 = select i1 %2838, i64 %2837, i64 0
  %private.contiguous.address938 = getelementptr i8, ptr %2835, i64 %2839
  %private.contiguous.load939 = load <8 x float>, ptr %private.contiguous.address938, align 4
  %2840 = select <8 x i1> %95, <8 x float> %private.contiguous.load939, <8 x float> zeroinitializer
  %.state940 = load <8 x float>, ptr %.slot112, align 32
  %2841 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state940, <8 x float> %2840)
  %.state941 = load i64, ptr %.slot111, align 4
  %2842 = add i64 %.state941, 1
  store i64 %2842, ptr %.slot111, align 4
  %2843 = load <8 x float>, ptr %.slot112, align 32
  %2844 = select <8 x i1> %95, <8 x float> %2841, <8 x float> %2843
  store <8 x float> %2844, ptr %.slot112, align 32
  br label %direct.schedule.40

direct.schedule.42:                               ; preds = %direct.false932
  store i64 0, ptr %.slot113, align 4
  %2845 = load <8 x float>, ptr %.slot114, align 32
  %2846 = select <8 x i1> %95, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %2845
  store <8 x float> %2846, ptr %.slot114, align 32
  br label %direct.schedule.43

direct.schedule.43:                               ; preds = %direct.schedule.44, %direct.schedule.42
  %.state942 = load i64, ptr %.slot113, align 4
  %2847 = icmp slt i64 %.state942, 16
  br i1 %2847, label %direct.true943, label %direct.false944

direct.schedule.44:                               ; preds = %direct.true943
  %.state945 = load i64, ptr %.slot113, align 4
  %2848 = sdiv i64 %.state945, 1
  %.spill.load946 = load i64, ptr %.spill64, align 4
  %2849 = mul i64 %.spill.load946, 1
  %2850 = add i64 %2849, 0
  %2851 = mul i64 %2850, 8
  %2852 = add i64 %2851, 7
  %2853 = mul i64 %2852, 16
  %2854 = add i64 %2853, %2848
  %tile_snapshot.spill.load947 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %2855 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load947, 0
  %2856 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load947, 1
  %.splatinsert948 = insertelement <8 x i64> poison, i64 %2854, i64 0
  %.splat949 = shufflevector <8 x i64> %.splatinsert948, <8 x i64> poison, <8 x i32> zeroinitializer
  %2857 = mul <8 x i64> %.splat949, splat (i64 32)
  %2858 = add <8 x i64> %2856, %2857
  %2859 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2855, 0
  %2860 = insertvalue { <8 x ptr>, <8 x i64> } %2859, <8 x i64> %2858, 1
  %2861 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2862 = extractvalue { <8 x ptr>, <8 x i64> } %2860, 1
  %2863 = extractelement <8 x ptr> %2861, i32 0
  %2864 = extractelement <8 x i64> %2862, i32 0
  %2865 = sub i64 %2864, 0
  %2866 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2867 = select i1 %2866, i64 %2865, i64 0
  %private.contiguous.address950 = getelementptr i8, ptr %2863, i64 %2867
  %private.contiguous.load951 = load <8 x float>, ptr %private.contiguous.address950, align 4
  %2868 = select <8 x i1> %95, <8 x float> %private.contiguous.load951, <8 x float> zeroinitializer
  %.state952 = load <8 x float>, ptr %.slot114, align 32
  %2869 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state952, <8 x float> %2868)
  %.state953 = load i64, ptr %.slot113, align 4
  %2870 = add i64 %.state953, 1
  store i64 %2870, ptr %.slot113, align 4
  %2871 = load <8 x float>, ptr %.slot114, align 32
  %2872 = select <8 x i1> %95, <8 x float> %2869, <8 x float> %2871
  store <8 x float> %2872, ptr %.slot114, align 32
  br label %direct.schedule.43

direct.schedule.45:                               ; preds = %direct.false944
  %.state954 = load <8 x float>, ptr %.slot68, align 32
  %.state955 = load <8 x float>, ptr %.slot100, align 32
  %2873 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state954, <8 x float> %.state955)
  %2874 = load <8 x float>, ptr %.spill115, align 32
  %2875 = select <8 x i1> %95, <8 x float> %2873, <8 x float> %2874
  store <8 x float> %2875, ptr %.spill115, align 32
  %.state956 = load <8 x float>, ptr %.slot69, align 32
  %.state957 = load <8 x float>, ptr %.slot102, align 32
  %2876 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state956, <8 x float> %.state957)
  %2877 = load <8 x float>, ptr %.spill116, align 32
  %2878 = select <8 x i1> %95, <8 x float> %2876, <8 x float> %2877
  store <8 x float> %2878, ptr %.spill116, align 32
  %.state958 = load <8 x float>, ptr %.slot70, align 32
  %.state959 = load <8 x float>, ptr %.slot104, align 32
  %2879 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state958, <8 x float> %.state959)
  %2880 = load <8 x float>, ptr %.spill117, align 32
  %2881 = select <8 x i1> %95, <8 x float> %2879, <8 x float> %2880
  store <8 x float> %2881, ptr %.spill117, align 32
  %.state960 = load <8 x float>, ptr %.slot71, align 32
  %.state961 = load <8 x float>, ptr %.slot106, align 32
  %2882 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state960, <8 x float> %.state961)
  %2883 = load <8 x float>, ptr %.spill118, align 32
  %2884 = select <8 x i1> %95, <8 x float> %2882, <8 x float> %2883
  store <8 x float> %2884, ptr %.spill118, align 32
  %.state962 = load <8 x float>, ptr %.slot72, align 32
  %.state963 = load <8 x float>, ptr %.slot108, align 32
  %2885 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state962, <8 x float> %.state963)
  %2886 = load <8 x float>, ptr %.spill119, align 32
  %2887 = select <8 x i1> %95, <8 x float> %2885, <8 x float> %2886
  store <8 x float> %2887, ptr %.spill119, align 32
  %.state964 = load <8 x float>, ptr %.slot73, align 32
  %.state965 = load <8 x float>, ptr %.slot110, align 32
  %2888 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state964, <8 x float> %.state965)
  %2889 = load <8 x float>, ptr %.spill120, align 32
  %2890 = select <8 x i1> %95, <8 x float> %2888, <8 x float> %2889
  store <8 x float> %2890, ptr %.spill120, align 32
  %.state966 = load <8 x float>, ptr %.slot74, align 32
  %.state967 = load <8 x float>, ptr %.slot112, align 32
  %2891 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state966, <8 x float> %.state967)
  %2892 = load <8 x float>, ptr %.spill121, align 32
  %2893 = select <8 x i1> %95, <8 x float> %2891, <8 x float> %2892
  store <8 x float> %2893, ptr %.spill121, align 32
  %.state968 = load <8 x float>, ptr %.slot75, align 32
  %.state969 = load <8 x float>, ptr %.slot114, align 32
  %2894 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state968, <8 x float> %.state969)
  %2895 = load <8 x float>, ptr %.spill122, align 32
  %2896 = select <8 x i1> %95, <8 x float> %2894, <8 x float> %2895
  store <8 x float> %2896, ptr %.spill122, align 32
  %2897 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill123, align 64
  %2898 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2899 = extractvalue { <8 x ptr>, <8 x i64> } %2897, 0
  %2900 = select <8 x i1> %95, <8 x ptr> %2898, <8 x ptr> %2899
  %2901 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %2902 = extractvalue { <8 x ptr>, <8 x i64> } %2897, 1
  %2903 = select <8 x i1> %95, <8 x i64> %2901, <8 x i64> %2902
  %2904 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2900, 0
  %2905 = insertvalue { <8 x ptr>, <8 x i64> } %2904, <8 x i64> %2903, 1
  store { <8 x ptr>, <8 x i64> } %2905, ptr %tile_snapshot.spill123, align 64
  %2906 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2907 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %2908 = add <8 x i64> %2907, zeroinitializer
  %2909 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2906, 0
  %2910 = insertvalue { <8 x ptr>, <8 x i64> } %2909, <8 x i64> %2908, 1
  %2911 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2912 = extractvalue { <8 x ptr>, <8 x i64> } %2910, 1
  %2913 = extractelement <8 x ptr> %2911, i32 0
  %2914 = extractelement <8 x i64> %2912, i32 0
  %2915 = sub i64 %2914, 0
  %2916 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2917 = select i1 %2916, i64 %2915, i64 0
  %private.contiguous.address970 = getelementptr i8, ptr %2913, i64 %2917
  %private.contiguous.preserve971 = load <8 x float>, ptr %private.contiguous.address970, align 4
  %2918 = select <8 x i1> %95, <8 x float> %2873, <8 x float> %private.contiguous.preserve971
  store <8 x float> %2918, ptr %private.contiguous.address970, align 4
  %2919 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2920 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %2921 = add <8 x i64> %2920, splat (i64 32)
  %2922 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2919, 0
  %2923 = insertvalue { <8 x ptr>, <8 x i64> } %2922, <8 x i64> %2921, 1
  %2924 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2925 = extractvalue { <8 x ptr>, <8 x i64> } %2923, 1
  %2926 = extractelement <8 x ptr> %2924, i32 0
  %2927 = extractelement <8 x i64> %2925, i32 0
  %2928 = sub i64 %2927, 0
  %2929 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2930 = select i1 %2929, i64 %2928, i64 0
  %private.contiguous.address972 = getelementptr i8, ptr %2926, i64 %2930
  %private.contiguous.preserve973 = load <8 x float>, ptr %private.contiguous.address972, align 4
  %2931 = select <8 x i1> %95, <8 x float> %2876, <8 x float> %private.contiguous.preserve973
  store <8 x float> %2931, ptr %private.contiguous.address972, align 4
  %2932 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2933 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %2934 = add <8 x i64> %2933, splat (i64 64)
  %2935 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2932, 0
  %2936 = insertvalue { <8 x ptr>, <8 x i64> } %2935, <8 x i64> %2934, 1
  %2937 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2938 = extractvalue { <8 x ptr>, <8 x i64> } %2936, 1
  %2939 = extractelement <8 x ptr> %2937, i32 0
  %2940 = extractelement <8 x i64> %2938, i32 0
  %2941 = sub i64 %2940, 0
  %2942 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2943 = select i1 %2942, i64 %2941, i64 0
  %private.contiguous.address974 = getelementptr i8, ptr %2939, i64 %2943
  %private.contiguous.preserve975 = load <8 x float>, ptr %private.contiguous.address974, align 4
  %2944 = select <8 x i1> %95, <8 x float> %2879, <8 x float> %private.contiguous.preserve975
  store <8 x float> %2944, ptr %private.contiguous.address974, align 4
  %2945 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2946 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %2947 = add <8 x i64> %2946, splat (i64 96)
  %2948 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2945, 0
  %2949 = insertvalue { <8 x ptr>, <8 x i64> } %2948, <8 x i64> %2947, 1
  %2950 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2951 = extractvalue { <8 x ptr>, <8 x i64> } %2949, 1
  %2952 = extractelement <8 x ptr> %2950, i32 0
  %2953 = extractelement <8 x i64> %2951, i32 0
  %2954 = sub i64 %2953, 0
  %2955 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2956 = select i1 %2955, i64 %2954, i64 0
  %private.contiguous.address976 = getelementptr i8, ptr %2952, i64 %2956
  %private.contiguous.preserve977 = load <8 x float>, ptr %private.contiguous.address976, align 4
  %2957 = select <8 x i1> %95, <8 x float> %2882, <8 x float> %private.contiguous.preserve977
  store <8 x float> %2957, ptr %private.contiguous.address976, align 4
  %2958 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2959 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %2960 = add <8 x i64> %2959, splat (i64 128)
  %2961 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2958, 0
  %2962 = insertvalue { <8 x ptr>, <8 x i64> } %2961, <8 x i64> %2960, 1
  %2963 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2964 = extractvalue { <8 x ptr>, <8 x i64> } %2962, 1
  %2965 = extractelement <8 x ptr> %2963, i32 0
  %2966 = extractelement <8 x i64> %2964, i32 0
  %2967 = sub i64 %2966, 0
  %2968 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2969 = select i1 %2968, i64 %2967, i64 0
  %private.contiguous.address978 = getelementptr i8, ptr %2965, i64 %2969
  %private.contiguous.preserve979 = load <8 x float>, ptr %private.contiguous.address978, align 4
  %2970 = select <8 x i1> %95, <8 x float> %2885, <8 x float> %private.contiguous.preserve979
  store <8 x float> %2970, ptr %private.contiguous.address978, align 4
  %2971 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2972 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %2973 = add <8 x i64> %2972, splat (i64 160)
  %2974 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2971, 0
  %2975 = insertvalue { <8 x ptr>, <8 x i64> } %2974, <8 x i64> %2973, 1
  %2976 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2977 = extractvalue { <8 x ptr>, <8 x i64> } %2975, 1
  %2978 = extractelement <8 x ptr> %2976, i32 0
  %2979 = extractelement <8 x i64> %2977, i32 0
  %2980 = sub i64 %2979, 0
  %2981 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2982 = select i1 %2981, i64 %2980, i64 0
  %private.contiguous.address980 = getelementptr i8, ptr %2978, i64 %2982
  %private.contiguous.preserve981 = load <8 x float>, ptr %private.contiguous.address980, align 4
  %2983 = select <8 x i1> %95, <8 x float> %2888, <8 x float> %private.contiguous.preserve981
  store <8 x float> %2983, ptr %private.contiguous.address980, align 4
  %2984 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2985 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %2986 = add <8 x i64> %2985, splat (i64 192)
  %2987 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2984, 0
  %2988 = insertvalue { <8 x ptr>, <8 x i64> } %2987, <8 x i64> %2986, 1
  %2989 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2990 = extractvalue { <8 x ptr>, <8 x i64> } %2988, 1
  %2991 = extractelement <8 x ptr> %2989, i32 0
  %2992 = extractelement <8 x i64> %2990, i32 0
  %2993 = sub i64 %2992, 0
  %2994 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %2995 = select i1 %2994, i64 %2993, i64 0
  %private.contiguous.address982 = getelementptr i8, ptr %2991, i64 %2995
  %private.contiguous.preserve983 = load <8 x float>, ptr %private.contiguous.address982, align 4
  %2996 = select <8 x i1> %95, <8 x float> %2891, <8 x float> %private.contiguous.preserve983
  store <8 x float> %2996, ptr %private.contiguous.address982, align 4
  %2997 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %2998 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %2999 = add <8 x i64> %2998, splat (i64 224)
  %3000 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2997, 0
  %3001 = insertvalue { <8 x ptr>, <8 x i64> } %3000, <8 x i64> %2999, 1
  %3002 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3003 = extractvalue { <8 x ptr>, <8 x i64> } %3001, 1
  %3004 = extractelement <8 x ptr> %3002, i32 0
  %3005 = extractelement <8 x i64> %3003, i32 0
  %3006 = sub i64 %3005, 0
  %3007 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3008 = select i1 %3007, i64 %3006, i64 0
  %private.contiguous.address984 = getelementptr i8, ptr %3004, i64 %3008
  %private.contiguous.preserve985 = load <8 x float>, ptr %private.contiguous.address984, align 4
  %3009 = select <8 x i1> %95, <8 x float> %2894, <8 x float> %private.contiguous.preserve985
  store <8 x float> %3009, ptr %private.contiguous.address984, align 4
  %.state986 = load <8 x float>, ptr %.slot68, align 32
  %3010 = fsub <8 x float> %.state986, %2873
  %.state987 = load <8 x float>, ptr %.slot69, align 32
  %3011 = fsub <8 x float> %.state987, %2876
  %.state988 = load <8 x float>, ptr %.slot70, align 32
  %3012 = fsub <8 x float> %.state988, %2879
  %.state989 = load <8 x float>, ptr %.slot71, align 32
  %3013 = fsub <8 x float> %.state989, %2882
  %.state990 = load <8 x float>, ptr %.slot72, align 32
  %3014 = fsub <8 x float> %.state990, %2885
  %.state991 = load <8 x float>, ptr %.slot73, align 32
  %3015 = fsub <8 x float> %.state991, %2888
  %.state992 = load <8 x float>, ptr %.slot74, align 32
  %3016 = fsub <8 x float> %.state992, %2891
  %.state993 = load <8 x float>, ptr %.slot75, align 32
  %3017 = fsub <8 x float> %.state993, %2894
  %3018 = select <8 x i1> %95, <8 x float> %3010, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3018)
  %3019 = load <8 x float>, ptr %.spill124, align 32
  %3020 = select <8 x i1> %95, <8 x float> %native.exp, <8 x float> %3019
  store <8 x float> %3020, ptr %.spill124, align 32
  %3021 = select <8 x i1> %95, <8 x float> %3011, <8 x float> zeroinitializer
  %native.exp994 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3021)
  %3022 = load <8 x float>, ptr %.spill125, align 32
  %3023 = select <8 x i1> %95, <8 x float> %native.exp994, <8 x float> %3022
  store <8 x float> %3023, ptr %.spill125, align 32
  %3024 = select <8 x i1> %95, <8 x float> %3012, <8 x float> zeroinitializer
  %native.exp995 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3024)
  %3025 = load <8 x float>, ptr %.spill126, align 32
  %3026 = select <8 x i1> %95, <8 x float> %native.exp995, <8 x float> %3025
  store <8 x float> %3026, ptr %.spill126, align 32
  %3027 = select <8 x i1> %95, <8 x float> %3013, <8 x float> zeroinitializer
  %native.exp996 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3027)
  %3028 = load <8 x float>, ptr %.spill127, align 32
  %3029 = select <8 x i1> %95, <8 x float> %native.exp996, <8 x float> %3028
  store <8 x float> %3029, ptr %.spill127, align 32
  %3030 = select <8 x i1> %95, <8 x float> %3014, <8 x float> zeroinitializer
  %native.exp997 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3030)
  %3031 = load <8 x float>, ptr %.spill128, align 32
  %3032 = select <8 x i1> %95, <8 x float> %native.exp997, <8 x float> %3031
  store <8 x float> %3032, ptr %.spill128, align 32
  %3033 = select <8 x i1> %95, <8 x float> %3015, <8 x float> zeroinitializer
  %native.exp998 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3033)
  %3034 = load <8 x float>, ptr %.spill129, align 32
  %3035 = select <8 x i1> %95, <8 x float> %native.exp998, <8 x float> %3034
  store <8 x float> %3035, ptr %.spill129, align 32
  %3036 = select <8 x i1> %95, <8 x float> %3016, <8 x float> zeroinitializer
  %native.exp999 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3036)
  %3037 = load <8 x float>, ptr %.spill130, align 32
  %3038 = select <8 x i1> %95, <8 x float> %native.exp999, <8 x float> %3037
  store <8 x float> %3038, ptr %.spill130, align 32
  %3039 = select <8 x i1> %95, <8 x float> %3017, <8 x float> zeroinitializer
  %native.exp1000 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3039)
  %3040 = load <8 x float>, ptr %.spill131, align 32
  %3041 = select <8 x i1> %95, <8 x float> %native.exp1000, <8 x float> %3040
  store <8 x float> %3041, ptr %.spill131, align 32
  %3042 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %3043 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3044 = extractvalue { <8 x ptr>, <8 x i64> } %3042, 0
  %3045 = select <8 x i1> %95, <8 x ptr> %3043, <8 x ptr> %3044
  %3046 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3047 = extractvalue { <8 x ptr>, <8 x i64> } %3042, 1
  %3048 = select <8 x i1> %95, <8 x i64> %3046, <8 x i64> %3047
  %3049 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3045, 0
  %3050 = insertvalue { <8 x ptr>, <8 x i64> } %3049, <8 x i64> %3048, 1
  store { <8 x ptr>, <8 x i64> } %3050, ptr %tile_snapshot.spill132, align 64
  %3051 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3052 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3053 = add <8 x i64> %3052, zeroinitializer
  %3054 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3051, 0
  %3055 = insertvalue { <8 x ptr>, <8 x i64> } %3054, <8 x i64> %3053, 1
  %3056 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3057 = extractvalue { <8 x ptr>, <8 x i64> } %3055, 1
  %3058 = extractelement <8 x ptr> %3056, i32 0
  %3059 = extractelement <8 x i64> %3057, i32 0
  %3060 = sub i64 %3059, 0
  %3061 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3062 = select i1 %3061, i64 %3060, i64 0
  %private.contiguous.address1001 = getelementptr i8, ptr %3058, i64 %3062
  %private.contiguous.preserve1002 = load <8 x float>, ptr %private.contiguous.address1001, align 4
  %3063 = select <8 x i1> %95, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve1002
  store <8 x float> %3063, ptr %private.contiguous.address1001, align 4
  %3064 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3065 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3066 = add <8 x i64> %3065, splat (i64 32)
  %3067 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3064, 0
  %3068 = insertvalue { <8 x ptr>, <8 x i64> } %3067, <8 x i64> %3066, 1
  %3069 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3070 = extractvalue { <8 x ptr>, <8 x i64> } %3068, 1
  %3071 = extractelement <8 x ptr> %3069, i32 0
  %3072 = extractelement <8 x i64> %3070, i32 0
  %3073 = sub i64 %3072, 0
  %3074 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3075 = select i1 %3074, i64 %3073, i64 0
  %private.contiguous.address1003 = getelementptr i8, ptr %3071, i64 %3075
  %private.contiguous.preserve1004 = load <8 x float>, ptr %private.contiguous.address1003, align 4
  %3076 = select <8 x i1> %95, <8 x float> %native.exp994, <8 x float> %private.contiguous.preserve1004
  store <8 x float> %3076, ptr %private.contiguous.address1003, align 4
  %3077 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3078 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3079 = add <8 x i64> %3078, splat (i64 64)
  %3080 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3077, 0
  %3081 = insertvalue { <8 x ptr>, <8 x i64> } %3080, <8 x i64> %3079, 1
  %3082 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3083 = extractvalue { <8 x ptr>, <8 x i64> } %3081, 1
  %3084 = extractelement <8 x ptr> %3082, i32 0
  %3085 = extractelement <8 x i64> %3083, i32 0
  %3086 = sub i64 %3085, 0
  %3087 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3088 = select i1 %3087, i64 %3086, i64 0
  %private.contiguous.address1005 = getelementptr i8, ptr %3084, i64 %3088
  %private.contiguous.preserve1006 = load <8 x float>, ptr %private.contiguous.address1005, align 4
  %3089 = select <8 x i1> %95, <8 x float> %native.exp995, <8 x float> %private.contiguous.preserve1006
  store <8 x float> %3089, ptr %private.contiguous.address1005, align 4
  %3090 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3091 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3092 = add <8 x i64> %3091, splat (i64 96)
  %3093 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3090, 0
  %3094 = insertvalue { <8 x ptr>, <8 x i64> } %3093, <8 x i64> %3092, 1
  %3095 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3096 = extractvalue { <8 x ptr>, <8 x i64> } %3094, 1
  %3097 = extractelement <8 x ptr> %3095, i32 0
  %3098 = extractelement <8 x i64> %3096, i32 0
  %3099 = sub i64 %3098, 0
  %3100 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3101 = select i1 %3100, i64 %3099, i64 0
  %private.contiguous.address1007 = getelementptr i8, ptr %3097, i64 %3101
  %private.contiguous.preserve1008 = load <8 x float>, ptr %private.contiguous.address1007, align 4
  %3102 = select <8 x i1> %95, <8 x float> %native.exp996, <8 x float> %private.contiguous.preserve1008
  store <8 x float> %3102, ptr %private.contiguous.address1007, align 4
  %3103 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3104 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3105 = add <8 x i64> %3104, splat (i64 128)
  %3106 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3103, 0
  %3107 = insertvalue { <8 x ptr>, <8 x i64> } %3106, <8 x i64> %3105, 1
  %3108 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3109 = extractvalue { <8 x ptr>, <8 x i64> } %3107, 1
  %3110 = extractelement <8 x ptr> %3108, i32 0
  %3111 = extractelement <8 x i64> %3109, i32 0
  %3112 = sub i64 %3111, 0
  %3113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3114 = select i1 %3113, i64 %3112, i64 0
  %private.contiguous.address1009 = getelementptr i8, ptr %3110, i64 %3114
  %private.contiguous.preserve1010 = load <8 x float>, ptr %private.contiguous.address1009, align 4
  %3115 = select <8 x i1> %95, <8 x float> %native.exp997, <8 x float> %private.contiguous.preserve1010
  store <8 x float> %3115, ptr %private.contiguous.address1009, align 4
  %3116 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3117 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3118 = add <8 x i64> %3117, splat (i64 160)
  %3119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3116, 0
  %3120 = insertvalue { <8 x ptr>, <8 x i64> } %3119, <8 x i64> %3118, 1
  %3121 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3122 = extractvalue { <8 x ptr>, <8 x i64> } %3120, 1
  %3123 = extractelement <8 x ptr> %3121, i32 0
  %3124 = extractelement <8 x i64> %3122, i32 0
  %3125 = sub i64 %3124, 0
  %3126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3127 = select i1 %3126, i64 %3125, i64 0
  %private.contiguous.address1011 = getelementptr i8, ptr %3123, i64 %3127
  %private.contiguous.preserve1012 = load <8 x float>, ptr %private.contiguous.address1011, align 4
  %3128 = select <8 x i1> %95, <8 x float> %native.exp998, <8 x float> %private.contiguous.preserve1012
  store <8 x float> %3128, ptr %private.contiguous.address1011, align 4
  %3129 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3130 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3131 = add <8 x i64> %3130, splat (i64 192)
  %3132 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3129, 0
  %3133 = insertvalue { <8 x ptr>, <8 x i64> } %3132, <8 x i64> %3131, 1
  %3134 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3135 = extractvalue { <8 x ptr>, <8 x i64> } %3133, 1
  %3136 = extractelement <8 x ptr> %3134, i32 0
  %3137 = extractelement <8 x i64> %3135, i32 0
  %3138 = sub i64 %3137, 0
  %3139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3140 = select i1 %3139, i64 %3138, i64 0
  %private.contiguous.address1013 = getelementptr i8, ptr %3136, i64 %3140
  %private.contiguous.preserve1014 = load <8 x float>, ptr %private.contiguous.address1013, align 4
  %3141 = select <8 x i1> %95, <8 x float> %native.exp999, <8 x float> %private.contiguous.preserve1014
  store <8 x float> %3141, ptr %private.contiguous.address1013, align 4
  %3142 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3143 = extractvalue { <8 x ptr>, <8 x i64> } %38, 1
  %3144 = add <8 x i64> %3143, splat (i64 224)
  %3145 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3142, 0
  %3146 = insertvalue { <8 x ptr>, <8 x i64> } %3145, <8 x i64> %3144, 1
  %3147 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3148 = extractvalue { <8 x ptr>, <8 x i64> } %3146, 1
  %3149 = extractelement <8 x ptr> %3147, i32 0
  %3150 = extractelement <8 x i64> %3148, i32 0
  %3151 = sub i64 %3150, 0
  %3152 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3153 = select i1 %3152, i64 %3151, i64 0
  %private.contiguous.address1015 = getelementptr i8, ptr %3149, i64 %3153
  %private.contiguous.preserve1016 = load <8 x float>, ptr %private.contiguous.address1015, align 4
  %3154 = select <8 x i1> %95, <8 x float> %native.exp1000, <8 x float> %private.contiguous.preserve1016
  store <8 x float> %3154, ptr %private.contiguous.address1015, align 4
  %3155 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3156 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3157 = extractvalue { <8 x ptr>, <8 x i64> } %3155, 0
  %3158 = select <8 x i1> %95, <8 x ptr> %3156, <8 x ptr> %3157
  %3159 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %3160 = extractvalue { <8 x ptr>, <8 x i64> } %3155, 1
  %3161 = select <8 x i1> %95, <8 x i64> %3159, <8 x i64> %3160
  %3162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3158, 0
  %3163 = insertvalue { <8 x ptr>, <8 x i64> } %3162, <8 x i64> %3161, 1
  store { <8 x ptr>, <8 x i64> } %3163, ptr %tile_snapshot.spill133, align 64
  store i64 0, ptr %.slot134, align 4
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.47, %direct.schedule.45
  %.state1017 = load i64, ptr %.slot134, align 4
  %3164 = icmp slt i64 %.state1017, 128
  br i1 %3164, label %direct.true1018, label %direct.false1019

direct.schedule.47:                               ; preds = %direct.true1018
  %.state1020 = load i64, ptr %.slot134, align 4
  %3165 = srem i64 %.state1020, 16
  %.state1021 = load i64, ptr %.slot134, align 4
  %3166 = sdiv i64 %.state1021, 16
  %3167 = add i64 0, %3165
  %3168 = mul i64 %3167, 8
  %3169 = add i64 %3168, %3166
  %tile_snapshot.spill.load1022 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %3170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1022, 0
  %3171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1022, 1
  %.splatinsert1023 = insertelement <8 x i64> poison, i64 %3169, i64 0
  %.splat1024 = shufflevector <8 x i64> %.splatinsert1023, <8 x i64> poison, <8 x i32> zeroinitializer
  %3172 = add <8 x i64> %3171, %.splat1024
  %3173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3170, 0
  %3174 = insertvalue { <8 x ptr>, <8 x i64> } %3173, <8 x i64> %3172, 1
  %3175 = extractvalue { <8 x ptr>, <8 x i64> } %3174, 0
  %3176 = extractvalue { <8 x ptr>, <8 x i64> } %3174, 1
  %3177 = getelementptr i8, <8 x ptr> %3175, <8 x i64> %3176
  %3178 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %3177, <8 x i1> %95, <8 x i8> zeroinitializer)
  %3179 = icmp ne <8 x i8> %3178, zeroinitializer
  %3180 = add i64 0, %3166
  %3181 = mul i64 %3180, 16
  %3182 = add i64 %3181, %3165
  %3183 = srem i64 %3182, 16
  %3184 = sdiv i64 %3182, 16
  %3185 = add i64 0, %3184
  %3186 = mul i64 %3185, 16
  %3187 = add i64 %3186, %3183
  %3188 = srem i64 %3187, 16
  %3189 = sdiv i64 %3187, 16
  %3190 = add i64 0, %3189
  %3191 = mul i64 %3190, 16
  %3192 = add i64 %3191, %3188
  %tile_snapshot.spill.load1025 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %3193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1025, 0
  %3194 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1025, 1
  %.splatinsert1026 = insertelement <8 x i64> poison, i64 %3192, i64 0
  %.splat1027 = shufflevector <8 x i64> %.splatinsert1026, <8 x i64> poison, <8 x i32> zeroinitializer
  %3195 = mul <8 x i64> %.splat1027, splat (i64 32)
  %3196 = add <8 x i64> %3194, %3195
  %3197 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3193, 0
  %3198 = insertvalue { <8 x ptr>, <8 x i64> } %3197, <8 x i64> %3196, 1
  %3199 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %3200 = extractvalue { <8 x ptr>, <8 x i64> } %3198, 1
  %3201 = extractelement <8 x ptr> %3199, i32 0
  %3202 = extractelement <8 x i64> %3200, i32 0
  %3203 = sub i64 %3202, 0
  %3204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3205 = select i1 %3204, i64 %3203, i64 0
  %private.contiguous.address1028 = getelementptr i8, ptr %3201, i64 %3205
  %private.contiguous.load1029 = load <8 x float>, ptr %private.contiguous.address1028, align 4
  %3206 = select <8 x i1> %95, <8 x float> %private.contiguous.load1029, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1030 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill123, align 64
  %3207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1030, 0
  %3208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1030, 1
  %.splatinsert1031 = insertelement <8 x i64> poison, i64 %3190, i64 0
  %.splat1032 = shufflevector <8 x i64> %.splatinsert1031, <8 x i64> poison, <8 x i32> zeroinitializer
  %3209 = mul <8 x i64> %.splat1032, splat (i64 32)
  %3210 = add <8 x i64> %3208, %3209
  %3211 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3207, 0
  %3212 = insertvalue { <8 x ptr>, <8 x i64> } %3211, <8 x i64> %3210, 1
  %3213 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %3214 = extractvalue { <8 x ptr>, <8 x i64> } %3212, 1
  %3215 = extractelement <8 x ptr> %3213, i32 0
  %3216 = extractelement <8 x i64> %3214, i32 0
  %3217 = sub i64 %3216, 0
  %3218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3219 = select i1 %3218, i64 %3217, i64 0
  %private.contiguous.address1033 = getelementptr i8, ptr %3215, i64 %3219
  %private.contiguous.load1034 = load <8 x float>, ptr %private.contiguous.address1033, align 4
  %3220 = select <8 x i1> %95, <8 x float> %private.contiguous.load1034, <8 x float> zeroinitializer
  %3221 = fsub <8 x float> %3206, %3220
  %3222 = select <8 x i1> %95, <8 x float> %3221, <8 x float> zeroinitializer
  %native.exp1035 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3222)
  %3223 = select <8 x i1> %3179, <8 x float> %native.exp1035, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1036 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3224 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1036, 0
  %3225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1036, 1
  %.state1037 = load i64, ptr %.slot134, align 4
  %.splatinsert1038 = insertelement <8 x i64> poison, i64 %.state1037, i64 0
  %.splat1039 = shufflevector <8 x i64> %.splatinsert1038, <8 x i64> poison, <8 x i32> zeroinitializer
  %3226 = mul <8 x i64> %.splat1039, splat (i64 32)
  %3227 = add <8 x i64> %3225, %3226
  %3228 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3224, 0
  %3229 = insertvalue { <8 x ptr>, <8 x i64> } %3228, <8 x i64> %3227, 1
  %3230 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3231 = extractvalue { <8 x ptr>, <8 x i64> } %3229, 1
  %3232 = extractelement <8 x ptr> %3230, i32 0
  %3233 = extractelement <8 x i64> %3231, i32 0
  %3234 = sub i64 %3233, 0
  %3235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3236 = select i1 %3235, i64 %3234, i64 0
  %private.contiguous.address1040 = getelementptr i8, ptr %3232, i64 %3236
  %private.contiguous.preserve1041 = load <8 x float>, ptr %private.contiguous.address1040, align 4
  %3237 = select <8 x i1> %95, <8 x float> %3223, <8 x float> %private.contiguous.preserve1041
  store <8 x float> %3237, ptr %private.contiguous.address1040, align 4
  %.state1042 = load i64, ptr %.slot134, align 4
  %3238 = add i64 %.state1042, 1
  store i64 %3238, ptr %.slot134, align 4
  br label %direct.schedule.46

direct.schedule.48:                               ; preds = %direct.false1019
  %.state1043 = load <8 x float>, ptr %.slot76, align 32
  %.spill.load1044 = load <8 x float>, ptr %.spill124, align 32
  %3239 = fmul <8 x float> %.state1043, %.spill.load1044
  %3240 = load <8 x float>, ptr %.spill135, align 32
  %3241 = select <8 x i1> %95, <8 x float> %3239, <8 x float> %3240
  store <8 x float> %3241, ptr %.spill135, align 32
  %.state1045 = load <8 x float>, ptr %.slot77, align 32
  %.spill.load1046 = load <8 x float>, ptr %.spill125, align 32
  %3242 = fmul <8 x float> %.state1045, %.spill.load1046
  %3243 = load <8 x float>, ptr %.spill136, align 32
  %3244 = select <8 x i1> %95, <8 x float> %3242, <8 x float> %3243
  store <8 x float> %3244, ptr %.spill136, align 32
  %.state1047 = load <8 x float>, ptr %.slot78, align 32
  %.spill.load1048 = load <8 x float>, ptr %.spill126, align 32
  %3245 = fmul <8 x float> %.state1047, %.spill.load1048
  %3246 = load <8 x float>, ptr %.spill137, align 32
  %3247 = select <8 x i1> %95, <8 x float> %3245, <8 x float> %3246
  store <8 x float> %3247, ptr %.spill137, align 32
  %.state1049 = load <8 x float>, ptr %.slot79, align 32
  %.spill.load1050 = load <8 x float>, ptr %.spill127, align 32
  %3248 = fmul <8 x float> %.state1049, %.spill.load1050
  %3249 = load <8 x float>, ptr %.spill138, align 32
  %3250 = select <8 x i1> %95, <8 x float> %3248, <8 x float> %3249
  store <8 x float> %3250, ptr %.spill138, align 32
  %.state1051 = load <8 x float>, ptr %.slot80, align 32
  %.spill.load1052 = load <8 x float>, ptr %.spill128, align 32
  %3251 = fmul <8 x float> %.state1051, %.spill.load1052
  %3252 = load <8 x float>, ptr %.spill139, align 32
  %3253 = select <8 x i1> %95, <8 x float> %3251, <8 x float> %3252
  store <8 x float> %3253, ptr %.spill139, align 32
  %.state1053 = load <8 x float>, ptr %.slot81, align 32
  %.spill.load1054 = load <8 x float>, ptr %.spill129, align 32
  %3254 = fmul <8 x float> %.state1053, %.spill.load1054
  %3255 = load <8 x float>, ptr %.spill140, align 32
  %3256 = select <8 x i1> %95, <8 x float> %3254, <8 x float> %3255
  store <8 x float> %3256, ptr %.spill140, align 32
  %.state1055 = load <8 x float>, ptr %.slot82, align 32
  %.spill.load1056 = load <8 x float>, ptr %.spill130, align 32
  %3257 = fmul <8 x float> %.state1055, %.spill.load1056
  %3258 = load <8 x float>, ptr %.spill141, align 32
  %3259 = select <8 x i1> %95, <8 x float> %3257, <8 x float> %3258
  store <8 x float> %3259, ptr %.spill141, align 32
  %.state1057 = load <8 x float>, ptr %.slot83, align 32
  %.spill.load1058 = load <8 x float>, ptr %.spill131, align 32
  %3260 = fmul <8 x float> %.state1057, %.spill.load1058
  %3261 = load <8 x float>, ptr %.spill142, align 32
  %3262 = select <8 x i1> %95, <8 x float> %3260, <8 x float> %3261
  store <8 x float> %3262, ptr %.spill142, align 32
  store i64 0, ptr %.slot143, align 4
  %3263 = load <8 x float>, ptr %.slot144, align 32
  %3264 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3263
  store <8 x float> %3264, ptr %.slot144, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.50, %direct.schedule.48
  %.state1059 = load i64, ptr %.slot143, align 4
  %3265 = icmp slt i64 %.state1059, 16
  br i1 %3265, label %direct.true1060, label %direct.false1061

direct.schedule.50:                               ; preds = %direct.true1060
  %.state1062 = load i64, ptr %.slot143, align 4
  %3266 = sdiv i64 %.state1062, 1
  %.spill.load1063 = load i64, ptr %.spill64, align 4
  %3267 = mul i64 %.spill.load1063, 1
  %3268 = add i64 %3267, 0
  %3269 = mul i64 %3268, 8
  %3270 = add i64 %3269, 0
  %3271 = mul i64 %3270, 16
  %3272 = add i64 %3271, %3266
  %tile_snapshot.spill.load1064 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1064, 0
  %3274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1064, 1
  %.splatinsert1065 = insertelement <8 x i64> poison, i64 %3272, i64 0
  %.splat1066 = shufflevector <8 x i64> %.splatinsert1065, <8 x i64> poison, <8 x i32> zeroinitializer
  %3275 = mul <8 x i64> %.splat1066, splat (i64 32)
  %3276 = add <8 x i64> %3274, %3275
  %3277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3273, 0
  %3278 = insertvalue { <8 x ptr>, <8 x i64> } %3277, <8 x i64> %3276, 1
  %3279 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3280 = extractvalue { <8 x ptr>, <8 x i64> } %3278, 1
  %3281 = extractelement <8 x ptr> %3279, i32 0
  %3282 = extractelement <8 x i64> %3280, i32 0
  %3283 = sub i64 %3282, 0
  %3284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3285 = select i1 %3284, i64 %3283, i64 0
  %private.contiguous.address1067 = getelementptr i8, ptr %3281, i64 %3285
  %private.contiguous.load1068 = load <8 x float>, ptr %private.contiguous.address1067, align 4
  %3286 = select <8 x i1> %95, <8 x float> %private.contiguous.load1068, <8 x float> zeroinitializer
  %.state1069 = load <8 x float>, ptr %.slot144, align 32
  %3287 = fadd <8 x float> %.state1069, %3286
  %.state1070 = load i64, ptr %.slot143, align 4
  %3288 = add i64 %.state1070, 1
  store i64 %3288, ptr %.slot143, align 4
  %3289 = load <8 x float>, ptr %.slot144, align 32
  %3290 = select <8 x i1> %95, <8 x float> %3287, <8 x float> %3289
  store <8 x float> %3290, ptr %.slot144, align 32
  br label %direct.schedule.49

direct.schedule.51:                               ; preds = %direct.false1061
  store i64 0, ptr %.slot145, align 4
  %3291 = load <8 x float>, ptr %.slot146, align 32
  %3292 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3291
  store <8 x float> %3292, ptr %.slot146, align 32
  br label %direct.schedule.52

direct.schedule.52:                               ; preds = %direct.schedule.53, %direct.schedule.51
  %.state1071 = load i64, ptr %.slot145, align 4
  %3293 = icmp slt i64 %.state1071, 16
  br i1 %3293, label %direct.true1072, label %direct.false1073

direct.schedule.53:                               ; preds = %direct.true1072
  %.state1074 = load i64, ptr %.slot145, align 4
  %3294 = sdiv i64 %.state1074, 1
  %.spill.load1075 = load i64, ptr %.spill64, align 4
  %3295 = mul i64 %.spill.load1075, 1
  %3296 = add i64 %3295, 0
  %3297 = mul i64 %3296, 8
  %3298 = add i64 %3297, 1
  %3299 = mul i64 %3298, 16
  %3300 = add i64 %3299, %3294
  %tile_snapshot.spill.load1076 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3301 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1076, 0
  %3302 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1076, 1
  %.splatinsert1077 = insertelement <8 x i64> poison, i64 %3300, i64 0
  %.splat1078 = shufflevector <8 x i64> %.splatinsert1077, <8 x i64> poison, <8 x i32> zeroinitializer
  %3303 = mul <8 x i64> %.splat1078, splat (i64 32)
  %3304 = add <8 x i64> %3302, %3303
  %3305 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3301, 0
  %3306 = insertvalue { <8 x ptr>, <8 x i64> } %3305, <8 x i64> %3304, 1
  %3307 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3308 = extractvalue { <8 x ptr>, <8 x i64> } %3306, 1
  %3309 = extractelement <8 x ptr> %3307, i32 0
  %3310 = extractelement <8 x i64> %3308, i32 0
  %3311 = sub i64 %3310, 0
  %3312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3313 = select i1 %3312, i64 %3311, i64 0
  %private.contiguous.address1079 = getelementptr i8, ptr %3309, i64 %3313
  %private.contiguous.load1080 = load <8 x float>, ptr %private.contiguous.address1079, align 4
  %3314 = select <8 x i1> %95, <8 x float> %private.contiguous.load1080, <8 x float> zeroinitializer
  %.state1081 = load <8 x float>, ptr %.slot146, align 32
  %3315 = fadd <8 x float> %.state1081, %3314
  %.state1082 = load i64, ptr %.slot145, align 4
  %3316 = add i64 %.state1082, 1
  store i64 %3316, ptr %.slot145, align 4
  %3317 = load <8 x float>, ptr %.slot146, align 32
  %3318 = select <8 x i1> %95, <8 x float> %3315, <8 x float> %3317
  store <8 x float> %3318, ptr %.slot146, align 32
  br label %direct.schedule.52

direct.schedule.54:                               ; preds = %direct.false1073
  store i64 0, ptr %.slot147, align 4
  %3319 = load <8 x float>, ptr %.slot148, align 32
  %3320 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3319
  store <8 x float> %3320, ptr %.slot148, align 32
  br label %direct.schedule.55

direct.schedule.55:                               ; preds = %direct.schedule.56, %direct.schedule.54
  %.state1083 = load i64, ptr %.slot147, align 4
  %3321 = icmp slt i64 %.state1083, 16
  br i1 %3321, label %direct.true1084, label %direct.false1085

direct.schedule.56:                               ; preds = %direct.true1084
  %.state1086 = load i64, ptr %.slot147, align 4
  %3322 = sdiv i64 %.state1086, 1
  %.spill.load1087 = load i64, ptr %.spill64, align 4
  %3323 = mul i64 %.spill.load1087, 1
  %3324 = add i64 %3323, 0
  %3325 = mul i64 %3324, 8
  %3326 = add i64 %3325, 2
  %3327 = mul i64 %3326, 16
  %3328 = add i64 %3327, %3322
  %tile_snapshot.spill.load1088 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3329 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1088, 0
  %3330 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1088, 1
  %.splatinsert1089 = insertelement <8 x i64> poison, i64 %3328, i64 0
  %.splat1090 = shufflevector <8 x i64> %.splatinsert1089, <8 x i64> poison, <8 x i32> zeroinitializer
  %3331 = mul <8 x i64> %.splat1090, splat (i64 32)
  %3332 = add <8 x i64> %3330, %3331
  %3333 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3329, 0
  %3334 = insertvalue { <8 x ptr>, <8 x i64> } %3333, <8 x i64> %3332, 1
  %3335 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3336 = extractvalue { <8 x ptr>, <8 x i64> } %3334, 1
  %3337 = extractelement <8 x ptr> %3335, i32 0
  %3338 = extractelement <8 x i64> %3336, i32 0
  %3339 = sub i64 %3338, 0
  %3340 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3341 = select i1 %3340, i64 %3339, i64 0
  %private.contiguous.address1091 = getelementptr i8, ptr %3337, i64 %3341
  %private.contiguous.load1092 = load <8 x float>, ptr %private.contiguous.address1091, align 4
  %3342 = select <8 x i1> %95, <8 x float> %private.contiguous.load1092, <8 x float> zeroinitializer
  %.state1093 = load <8 x float>, ptr %.slot148, align 32
  %3343 = fadd <8 x float> %.state1093, %3342
  %.state1094 = load i64, ptr %.slot147, align 4
  %3344 = add i64 %.state1094, 1
  store i64 %3344, ptr %.slot147, align 4
  %3345 = load <8 x float>, ptr %.slot148, align 32
  %3346 = select <8 x i1> %95, <8 x float> %3343, <8 x float> %3345
  store <8 x float> %3346, ptr %.slot148, align 32
  br label %direct.schedule.55

direct.schedule.57:                               ; preds = %direct.false1085
  store i64 0, ptr %.slot149, align 4
  %3347 = load <8 x float>, ptr %.slot150, align 32
  %3348 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3347
  store <8 x float> %3348, ptr %.slot150, align 32
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.59, %direct.schedule.57
  %.state1095 = load i64, ptr %.slot149, align 4
  %3349 = icmp slt i64 %.state1095, 16
  br i1 %3349, label %direct.true1096, label %direct.false1097

direct.schedule.59:                               ; preds = %direct.true1096
  %.state1098 = load i64, ptr %.slot149, align 4
  %3350 = sdiv i64 %.state1098, 1
  %.spill.load1099 = load i64, ptr %.spill64, align 4
  %3351 = mul i64 %.spill.load1099, 1
  %3352 = add i64 %3351, 0
  %3353 = mul i64 %3352, 8
  %3354 = add i64 %3353, 3
  %3355 = mul i64 %3354, 16
  %3356 = add i64 %3355, %3350
  %tile_snapshot.spill.load1100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1100, 0
  %3358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1100, 1
  %.splatinsert1101 = insertelement <8 x i64> poison, i64 %3356, i64 0
  %.splat1102 = shufflevector <8 x i64> %.splatinsert1101, <8 x i64> poison, <8 x i32> zeroinitializer
  %3359 = mul <8 x i64> %.splat1102, splat (i64 32)
  %3360 = add <8 x i64> %3358, %3359
  %3361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3357, 0
  %3362 = insertvalue { <8 x ptr>, <8 x i64> } %3361, <8 x i64> %3360, 1
  %3363 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3364 = extractvalue { <8 x ptr>, <8 x i64> } %3362, 1
  %3365 = extractelement <8 x ptr> %3363, i32 0
  %3366 = extractelement <8 x i64> %3364, i32 0
  %3367 = sub i64 %3366, 0
  %3368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3369 = select i1 %3368, i64 %3367, i64 0
  %private.contiguous.address1103 = getelementptr i8, ptr %3365, i64 %3369
  %private.contiguous.load1104 = load <8 x float>, ptr %private.contiguous.address1103, align 4
  %3370 = select <8 x i1> %95, <8 x float> %private.contiguous.load1104, <8 x float> zeroinitializer
  %.state1105 = load <8 x float>, ptr %.slot150, align 32
  %3371 = fadd <8 x float> %.state1105, %3370
  %.state1106 = load i64, ptr %.slot149, align 4
  %3372 = add i64 %.state1106, 1
  store i64 %3372, ptr %.slot149, align 4
  %3373 = load <8 x float>, ptr %.slot150, align 32
  %3374 = select <8 x i1> %95, <8 x float> %3371, <8 x float> %3373
  store <8 x float> %3374, ptr %.slot150, align 32
  br label %direct.schedule.58

direct.schedule.60:                               ; preds = %direct.false1097
  store i64 0, ptr %.slot151, align 4
  %3375 = load <8 x float>, ptr %.slot152, align 32
  %3376 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3375
  store <8 x float> %3376, ptr %.slot152, align 32
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.62, %direct.schedule.60
  %.state1107 = load i64, ptr %.slot151, align 4
  %3377 = icmp slt i64 %.state1107, 16
  br i1 %3377, label %direct.true1108, label %direct.false1109

direct.schedule.62:                               ; preds = %direct.true1108
  %.state1110 = load i64, ptr %.slot151, align 4
  %3378 = sdiv i64 %.state1110, 1
  %.spill.load1111 = load i64, ptr %.spill64, align 4
  %3379 = mul i64 %.spill.load1111, 1
  %3380 = add i64 %3379, 0
  %3381 = mul i64 %3380, 8
  %3382 = add i64 %3381, 4
  %3383 = mul i64 %3382, 16
  %3384 = add i64 %3383, %3378
  %tile_snapshot.spill.load1112 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3385 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1112, 0
  %3386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1112, 1
  %.splatinsert1113 = insertelement <8 x i64> poison, i64 %3384, i64 0
  %.splat1114 = shufflevector <8 x i64> %.splatinsert1113, <8 x i64> poison, <8 x i32> zeroinitializer
  %3387 = mul <8 x i64> %.splat1114, splat (i64 32)
  %3388 = add <8 x i64> %3386, %3387
  %3389 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3385, 0
  %3390 = insertvalue { <8 x ptr>, <8 x i64> } %3389, <8 x i64> %3388, 1
  %3391 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3392 = extractvalue { <8 x ptr>, <8 x i64> } %3390, 1
  %3393 = extractelement <8 x ptr> %3391, i32 0
  %3394 = extractelement <8 x i64> %3392, i32 0
  %3395 = sub i64 %3394, 0
  %3396 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3397 = select i1 %3396, i64 %3395, i64 0
  %private.contiguous.address1115 = getelementptr i8, ptr %3393, i64 %3397
  %private.contiguous.load1116 = load <8 x float>, ptr %private.contiguous.address1115, align 4
  %3398 = select <8 x i1> %95, <8 x float> %private.contiguous.load1116, <8 x float> zeroinitializer
  %.state1117 = load <8 x float>, ptr %.slot152, align 32
  %3399 = fadd <8 x float> %.state1117, %3398
  %.state1118 = load i64, ptr %.slot151, align 4
  %3400 = add i64 %.state1118, 1
  store i64 %3400, ptr %.slot151, align 4
  %3401 = load <8 x float>, ptr %.slot152, align 32
  %3402 = select <8 x i1> %95, <8 x float> %3399, <8 x float> %3401
  store <8 x float> %3402, ptr %.slot152, align 32
  br label %direct.schedule.61

direct.schedule.63:                               ; preds = %direct.false1109
  store i64 0, ptr %.slot153, align 4
  %3403 = load <8 x float>, ptr %.slot154, align 32
  %3404 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3403
  store <8 x float> %3404, ptr %.slot154, align 32
  br label %direct.schedule.64

direct.schedule.64:                               ; preds = %direct.schedule.65, %direct.schedule.63
  %.state1119 = load i64, ptr %.slot153, align 4
  %3405 = icmp slt i64 %.state1119, 16
  br i1 %3405, label %direct.true1120, label %direct.false1121

direct.schedule.65:                               ; preds = %direct.true1120
  %.state1122 = load i64, ptr %.slot153, align 4
  %3406 = sdiv i64 %.state1122, 1
  %.spill.load1123 = load i64, ptr %.spill64, align 4
  %3407 = mul i64 %.spill.load1123, 1
  %3408 = add i64 %3407, 0
  %3409 = mul i64 %3408, 8
  %3410 = add i64 %3409, 5
  %3411 = mul i64 %3410, 16
  %3412 = add i64 %3411, %3406
  %tile_snapshot.spill.load1124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3413 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1124, 0
  %3414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1124, 1
  %.splatinsert1125 = insertelement <8 x i64> poison, i64 %3412, i64 0
  %.splat1126 = shufflevector <8 x i64> %.splatinsert1125, <8 x i64> poison, <8 x i32> zeroinitializer
  %3415 = mul <8 x i64> %.splat1126, splat (i64 32)
  %3416 = add <8 x i64> %3414, %3415
  %3417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3413, 0
  %3418 = insertvalue { <8 x ptr>, <8 x i64> } %3417, <8 x i64> %3416, 1
  %3419 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3420 = extractvalue { <8 x ptr>, <8 x i64> } %3418, 1
  %3421 = extractelement <8 x ptr> %3419, i32 0
  %3422 = extractelement <8 x i64> %3420, i32 0
  %3423 = sub i64 %3422, 0
  %3424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3425 = select i1 %3424, i64 %3423, i64 0
  %private.contiguous.address1127 = getelementptr i8, ptr %3421, i64 %3425
  %private.contiguous.load1128 = load <8 x float>, ptr %private.contiguous.address1127, align 4
  %3426 = select <8 x i1> %95, <8 x float> %private.contiguous.load1128, <8 x float> zeroinitializer
  %.state1129 = load <8 x float>, ptr %.slot154, align 32
  %3427 = fadd <8 x float> %.state1129, %3426
  %.state1130 = load i64, ptr %.slot153, align 4
  %3428 = add i64 %.state1130, 1
  store i64 %3428, ptr %.slot153, align 4
  %3429 = load <8 x float>, ptr %.slot154, align 32
  %3430 = select <8 x i1> %95, <8 x float> %3427, <8 x float> %3429
  store <8 x float> %3430, ptr %.slot154, align 32
  br label %direct.schedule.64

direct.schedule.66:                               ; preds = %direct.false1121
  store i64 0, ptr %.slot155, align 4
  %3431 = load <8 x float>, ptr %.slot156, align 32
  %3432 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3431
  store <8 x float> %3432, ptr %.slot156, align 32
  br label %direct.schedule.67

direct.schedule.67:                               ; preds = %direct.schedule.68, %direct.schedule.66
  %.state1131 = load i64, ptr %.slot155, align 4
  %3433 = icmp slt i64 %.state1131, 16
  br i1 %3433, label %direct.true1132, label %direct.false1133

direct.schedule.68:                               ; preds = %direct.true1132
  %.state1134 = load i64, ptr %.slot155, align 4
  %3434 = sdiv i64 %.state1134, 1
  %.spill.load1135 = load i64, ptr %.spill64, align 4
  %3435 = mul i64 %.spill.load1135, 1
  %3436 = add i64 %3435, 0
  %3437 = mul i64 %3436, 8
  %3438 = add i64 %3437, 6
  %3439 = mul i64 %3438, 16
  %3440 = add i64 %3439, %3434
  %tile_snapshot.spill.load1136 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1136, 0
  %3442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1136, 1
  %.splatinsert1137 = insertelement <8 x i64> poison, i64 %3440, i64 0
  %.splat1138 = shufflevector <8 x i64> %.splatinsert1137, <8 x i64> poison, <8 x i32> zeroinitializer
  %3443 = mul <8 x i64> %.splat1138, splat (i64 32)
  %3444 = add <8 x i64> %3442, %3443
  %3445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3441, 0
  %3446 = insertvalue { <8 x ptr>, <8 x i64> } %3445, <8 x i64> %3444, 1
  %3447 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3448 = extractvalue { <8 x ptr>, <8 x i64> } %3446, 1
  %3449 = extractelement <8 x ptr> %3447, i32 0
  %3450 = extractelement <8 x i64> %3448, i32 0
  %3451 = sub i64 %3450, 0
  %3452 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3453 = select i1 %3452, i64 %3451, i64 0
  %private.contiguous.address1139 = getelementptr i8, ptr %3449, i64 %3453
  %private.contiguous.load1140 = load <8 x float>, ptr %private.contiguous.address1139, align 4
  %3454 = select <8 x i1> %95, <8 x float> %private.contiguous.load1140, <8 x float> zeroinitializer
  %.state1141 = load <8 x float>, ptr %.slot156, align 32
  %3455 = fadd <8 x float> %.state1141, %3454
  %.state1142 = load i64, ptr %.slot155, align 4
  %3456 = add i64 %.state1142, 1
  store i64 %3456, ptr %.slot155, align 4
  %3457 = load <8 x float>, ptr %.slot156, align 32
  %3458 = select <8 x i1> %95, <8 x float> %3455, <8 x float> %3457
  store <8 x float> %3458, ptr %.slot156, align 32
  br label %direct.schedule.67

direct.schedule.69:                               ; preds = %direct.false1133
  store i64 0, ptr %.slot157, align 4
  %3459 = load <8 x float>, ptr %.slot158, align 32
  %3460 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %3459
  store <8 x float> %3460, ptr %.slot158, align 32
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.71, %direct.schedule.69
  %.state1143 = load i64, ptr %.slot157, align 4
  %3461 = icmp slt i64 %.state1143, 16
  br i1 %3461, label %direct.true1144, label %direct.false1145

direct.schedule.71:                               ; preds = %direct.true1144
  %.state1146 = load i64, ptr %.slot157, align 4
  %3462 = sdiv i64 %.state1146, 1
  %.spill.load1147 = load i64, ptr %.spill64, align 4
  %3463 = mul i64 %.spill.load1147, 1
  %3464 = add i64 %3463, 0
  %3465 = mul i64 %3464, 8
  %3466 = add i64 %3465, 7
  %3467 = mul i64 %3466, 16
  %3468 = add i64 %3467, %3462
  %tile_snapshot.spill.load1148 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3469 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1148, 0
  %3470 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1148, 1
  %.splatinsert1149 = insertelement <8 x i64> poison, i64 %3468, i64 0
  %.splat1150 = shufflevector <8 x i64> %.splatinsert1149, <8 x i64> poison, <8 x i32> zeroinitializer
  %3471 = mul <8 x i64> %.splat1150, splat (i64 32)
  %3472 = add <8 x i64> %3470, %3471
  %3473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3469, 0
  %3474 = insertvalue { <8 x ptr>, <8 x i64> } %3473, <8 x i64> %3472, 1
  %3475 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3476 = extractvalue { <8 x ptr>, <8 x i64> } %3474, 1
  %3477 = extractelement <8 x ptr> %3475, i32 0
  %3478 = extractelement <8 x i64> %3476, i32 0
  %3479 = sub i64 %3478, 0
  %3480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3481 = select i1 %3480, i64 %3479, i64 0
  %private.contiguous.address1151 = getelementptr i8, ptr %3477, i64 %3481
  %private.contiguous.load1152 = load <8 x float>, ptr %private.contiguous.address1151, align 4
  %3482 = select <8 x i1> %95, <8 x float> %private.contiguous.load1152, <8 x float> zeroinitializer
  %.state1153 = load <8 x float>, ptr %.slot158, align 32
  %3483 = fadd <8 x float> %.state1153, %3482
  %.state1154 = load i64, ptr %.slot157, align 4
  %3484 = add i64 %.state1154, 1
  store i64 %3484, ptr %.slot157, align 4
  %3485 = load <8 x float>, ptr %.slot158, align 32
  %3486 = select <8 x i1> %95, <8 x float> %3483, <8 x float> %3485
  store <8 x float> %3486, ptr %.slot158, align 32
  br label %direct.schedule.70

direct.schedule.72:                               ; preds = %direct.false1145
  %.spill.load1155 = load <8 x float>, ptr %.spill135, align 32
  %.state1156 = load <8 x float>, ptr %.slot144, align 32
  %3487 = fadd <8 x float> %.spill.load1155, %.state1156
  %3488 = load <8 x float>, ptr %.spill159, align 32
  %3489 = select <8 x i1> %95, <8 x float> %3487, <8 x float> %3488
  store <8 x float> %3489, ptr %.spill159, align 32
  %.spill.load1157 = load <8 x float>, ptr %.spill136, align 32
  %.state1158 = load <8 x float>, ptr %.slot146, align 32
  %3490 = fadd <8 x float> %.spill.load1157, %.state1158
  %3491 = load <8 x float>, ptr %.spill160, align 32
  %3492 = select <8 x i1> %95, <8 x float> %3490, <8 x float> %3491
  store <8 x float> %3492, ptr %.spill160, align 32
  %.spill.load1159 = load <8 x float>, ptr %.spill137, align 32
  %.state1160 = load <8 x float>, ptr %.slot148, align 32
  %3493 = fadd <8 x float> %.spill.load1159, %.state1160
  %3494 = load <8 x float>, ptr %.spill161, align 32
  %3495 = select <8 x i1> %95, <8 x float> %3493, <8 x float> %3494
  store <8 x float> %3495, ptr %.spill161, align 32
  %.spill.load1161 = load <8 x float>, ptr %.spill138, align 32
  %.state1162 = load <8 x float>, ptr %.slot150, align 32
  %3496 = fadd <8 x float> %.spill.load1161, %.state1162
  %3497 = load <8 x float>, ptr %.spill162, align 32
  %3498 = select <8 x i1> %95, <8 x float> %3496, <8 x float> %3497
  store <8 x float> %3498, ptr %.spill162, align 32
  %.spill.load1163 = load <8 x float>, ptr %.spill139, align 32
  %.state1164 = load <8 x float>, ptr %.slot152, align 32
  %3499 = fadd <8 x float> %.spill.load1163, %.state1164
  %3500 = load <8 x float>, ptr %.spill163, align 32
  %3501 = select <8 x i1> %95, <8 x float> %3499, <8 x float> %3500
  store <8 x float> %3501, ptr %.spill163, align 32
  %.spill.load1165 = load <8 x float>, ptr %.spill140, align 32
  %.state1166 = load <8 x float>, ptr %.slot154, align 32
  %3502 = fadd <8 x float> %.spill.load1165, %.state1166
  %3503 = load <8 x float>, ptr %.spill164, align 32
  %3504 = select <8 x i1> %95, <8 x float> %3502, <8 x float> %3503
  store <8 x float> %3504, ptr %.spill164, align 32
  %.spill.load1167 = load <8 x float>, ptr %.spill141, align 32
  %.state1168 = load <8 x float>, ptr %.slot156, align 32
  %3505 = fadd <8 x float> %.spill.load1167, %.state1168
  %3506 = load <8 x float>, ptr %.spill165, align 32
  %3507 = select <8 x i1> %95, <8 x float> %3505, <8 x float> %3506
  store <8 x float> %3507, ptr %.spill165, align 32
  %.spill.load1169 = load <8 x float>, ptr %.spill142, align 32
  %.state1170 = load <8 x float>, ptr %.slot158, align 32
  %3508 = fadd <8 x float> %.spill.load1169, %.state1170
  %3509 = load <8 x float>, ptr %.spill166, align 32
  %3510 = select <8 x i1> %95, <8 x float> %3508, <8 x float> %3509
  store <8 x float> %3510, ptr %.spill166, align 32
  %3511 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %3512 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %3513 = extractvalue { <8 x ptr>, <8 x i64> } %3511, 0
  %3514 = select <8 x i1> %95, <8 x ptr> %3512, <8 x ptr> %3513
  %3515 = extractvalue { <8 x ptr>, <8 x i64> } %44, 1
  %3516 = extractvalue { <8 x ptr>, <8 x i64> } %3511, 1
  %3517 = select <8 x i1> %95, <8 x i64> %3515, <8 x i64> %3516
  %3518 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3514, 0
  %3519 = insertvalue { <8 x ptr>, <8 x i64> } %3518, <8 x i64> %3517, 1
  store { <8 x ptr>, <8 x i64> } %3519, ptr %tile_snapshot.spill167, align 64
  store i64 0, ptr %.slot168, align 4
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.77, %direct.schedule.72
  %.state1171 = load i64, ptr %.slot168, align 4
  %3520 = icmp slt i64 %.state1171, 4
  br i1 %3520, label %direct.true1172, label %direct.false1173

direct.schedule.74:                               ; preds = %direct.true1172
  %.state1174 = load i64, ptr %.slot168, align 4
  %3521 = mul i64 %.state1174, 2
  store i64 %3521, ptr %.spill169, align 4
  store i64 0, ptr %.slot170, align 4
  br label %direct.schedule.75

direct.schedule.75:                               ; preds = %direct.schedule.76, %direct.schedule.74
  %.state1175 = load i64, ptr %.slot170, align 4
  %3522 = icmp slt i64 %.state1175, 24
  br i1 %3522, label %direct.true1176, label %direct.false1177

direct.schedule.76:                               ; preds = %direct.true1176
  %.state1178 = load i64, ptr %.slot170, align 4
  %3523 = mul i64 %.state1178, 2
  %.spill.load1179 = load i64, ptr %.spill169, align 4
  %3524 = add i64 0, %.spill.load1179
  %3525 = mul i64 %3524, 48
  %3526 = add i64 %3525, %3523
  %3527 = add i64 %3526, 0
  %3528 = srem i64 %3527, 48
  %3529 = sdiv i64 %3527, 48
  %3530 = add i64 0, %3529
  %3531 = mul i64 %3530, 48
  %3532 = add i64 %3531, %3528
  %tile_snapshot.spill.load1180 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %3533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1180, 0
  %3534 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1180, 1
  %.splatinsert1181 = insertelement <8 x i64> poison, i64 %3532, i64 0
  %.splat1182 = shufflevector <8 x i64> %.splatinsert1181, <8 x i64> poison, <8 x i32> zeroinitializer
  %3535 = mul <8 x i64> %.splat1182, splat (i64 32)
  %3536 = add <8 x i64> %3534, %3535
  %3537 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3533, 0
  %3538 = insertvalue { <8 x ptr>, <8 x i64> } %3537, <8 x i64> %3536, 1
  %3539 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %3540 = extractvalue { <8 x ptr>, <8 x i64> } %3538, 1
  %3541 = extractelement <8 x ptr> %3539, i32 0
  %3542 = extractelement <8 x i64> %3540, i32 0
  %3543 = sub i64 %3542, 0
  %3544 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3545 = select i1 %3544, i64 %3543, i64 0
  %private.contiguous.address1183 = getelementptr i8, ptr %3541, i64 %3545
  %private.contiguous.load1184 = load <8 x float>, ptr %private.contiguous.address1183, align 4
  %3546 = select <8 x i1> %95, <8 x float> %private.contiguous.load1184, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1185 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %3547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1185, 0
  %3548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1185, 1
  %.splatinsert1186 = insertelement <8 x i64> poison, i64 %3530, i64 0
  %.splat1187 = shufflevector <8 x i64> %.splatinsert1186, <8 x i64> poison, <8 x i32> zeroinitializer
  %3549 = mul <8 x i64> %.splat1187, splat (i64 32)
  %3550 = add <8 x i64> %3548, %3549
  %3551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3547, 0
  %3552 = insertvalue { <8 x ptr>, <8 x i64> } %3551, <8 x i64> %3550, 1
  %3553 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3554 = extractvalue { <8 x ptr>, <8 x i64> } %3552, 1
  %3555 = extractelement <8 x ptr> %3553, i32 0
  %3556 = extractelement <8 x i64> %3554, i32 0
  %3557 = sub i64 %3556, 0
  %3558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3559 = select i1 %3558, i64 %3557, i64 0
  %private.contiguous.address1188 = getelementptr i8, ptr %3555, i64 %3559
  %private.contiguous.load1189 = load <8 x float>, ptr %private.contiguous.address1188, align 4
  %3560 = select <8 x i1> %95, <8 x float> %private.contiguous.load1189, <8 x float> zeroinitializer
  %3561 = fmul <8 x float> %3546, %3560
  %3562 = add i64 %3526, 1
  %3563 = srem i64 %3562, 48
  %3564 = sdiv i64 %3562, 48
  %3565 = add i64 0, %3564
  %3566 = mul i64 %3565, 48
  %3567 = add i64 %3566, %3563
  %tile_snapshot.spill.load1190 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %3568 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1190, 0
  %3569 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1190, 1
  %.splatinsert1191 = insertelement <8 x i64> poison, i64 %3567, i64 0
  %.splat1192 = shufflevector <8 x i64> %.splatinsert1191, <8 x i64> poison, <8 x i32> zeroinitializer
  %3570 = mul <8 x i64> %.splat1192, splat (i64 32)
  %3571 = add <8 x i64> %3569, %3570
  %3572 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3568, 0
  %3573 = insertvalue { <8 x ptr>, <8 x i64> } %3572, <8 x i64> %3571, 1
  %3574 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %3575 = extractvalue { <8 x ptr>, <8 x i64> } %3573, 1
  %3576 = extractelement <8 x ptr> %3574, i32 0
  %3577 = extractelement <8 x i64> %3575, i32 0
  %3578 = sub i64 %3577, 0
  %3579 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3580 = select i1 %3579, i64 %3578, i64 0
  %private.contiguous.address1193 = getelementptr i8, ptr %3576, i64 %3580
  %private.contiguous.load1194 = load <8 x float>, ptr %private.contiguous.address1193, align 4
  %3581 = select <8 x i1> %95, <8 x float> %private.contiguous.load1194, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1195 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %3582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1195, 0
  %3583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1195, 1
  %.splatinsert1196 = insertelement <8 x i64> poison, i64 %3565, i64 0
  %.splat1197 = shufflevector <8 x i64> %.splatinsert1196, <8 x i64> poison, <8 x i32> zeroinitializer
  %3584 = mul <8 x i64> %.splat1197, splat (i64 32)
  %3585 = add <8 x i64> %3583, %3584
  %3586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3582, 0
  %3587 = insertvalue { <8 x ptr>, <8 x i64> } %3586, <8 x i64> %3585, 1
  %3588 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3589 = extractvalue { <8 x ptr>, <8 x i64> } %3587, 1
  %3590 = extractelement <8 x ptr> %3588, i32 0
  %3591 = extractelement <8 x i64> %3589, i32 0
  %3592 = sub i64 %3591, 0
  %3593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3594 = select i1 %3593, i64 %3592, i64 0
  %private.contiguous.address1198 = getelementptr i8, ptr %3590, i64 %3594
  %private.contiguous.load1199 = load <8 x float>, ptr %private.contiguous.address1198, align 4
  %3595 = select <8 x i1> %95, <8 x float> %private.contiguous.load1199, <8 x float> zeroinitializer
  %3596 = fmul <8 x float> %3581, %3595
  %3597 = add i64 %3526, 48
  %3598 = srem i64 %3597, 48
  %3599 = sdiv i64 %3597, 48
  %3600 = add i64 0, %3599
  %3601 = mul i64 %3600, 48
  %3602 = add i64 %3601, %3598
  %tile_snapshot.spill.load1200 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %3603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1200, 0
  %3604 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1200, 1
  %.splatinsert1201 = insertelement <8 x i64> poison, i64 %3602, i64 0
  %.splat1202 = shufflevector <8 x i64> %.splatinsert1201, <8 x i64> poison, <8 x i32> zeroinitializer
  %3605 = mul <8 x i64> %.splat1202, splat (i64 32)
  %3606 = add <8 x i64> %3604, %3605
  %3607 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3603, 0
  %3608 = insertvalue { <8 x ptr>, <8 x i64> } %3607, <8 x i64> %3606, 1
  %3609 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %3610 = extractvalue { <8 x ptr>, <8 x i64> } %3608, 1
  %3611 = extractelement <8 x ptr> %3609, i32 0
  %3612 = extractelement <8 x i64> %3610, i32 0
  %3613 = sub i64 %3612, 0
  %3614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3615 = select i1 %3614, i64 %3613, i64 0
  %private.contiguous.address1203 = getelementptr i8, ptr %3611, i64 %3615
  %private.contiguous.load1204 = load <8 x float>, ptr %private.contiguous.address1203, align 4
  %3616 = select <8 x i1> %95, <8 x float> %private.contiguous.load1204, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1205 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %3617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1205, 0
  %3618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1205, 1
  %.splatinsert1206 = insertelement <8 x i64> poison, i64 %3600, i64 0
  %.splat1207 = shufflevector <8 x i64> %.splatinsert1206, <8 x i64> poison, <8 x i32> zeroinitializer
  %3619 = mul <8 x i64> %.splat1207, splat (i64 32)
  %3620 = add <8 x i64> %3618, %3619
  %3621 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3617, 0
  %3622 = insertvalue { <8 x ptr>, <8 x i64> } %3621, <8 x i64> %3620, 1
  %3623 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3624 = extractvalue { <8 x ptr>, <8 x i64> } %3622, 1
  %3625 = extractelement <8 x ptr> %3623, i32 0
  %3626 = extractelement <8 x i64> %3624, i32 0
  %3627 = sub i64 %3626, 0
  %3628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3629 = select i1 %3628, i64 %3627, i64 0
  %private.contiguous.address1208 = getelementptr i8, ptr %3625, i64 %3629
  %private.contiguous.load1209 = load <8 x float>, ptr %private.contiguous.address1208, align 4
  %3630 = select <8 x i1> %95, <8 x float> %private.contiguous.load1209, <8 x float> zeroinitializer
  %3631 = fmul <8 x float> %3616, %3630
  %3632 = add i64 %3526, 49
  %3633 = srem i64 %3632, 48
  %3634 = sdiv i64 %3632, 48
  %3635 = add i64 0, %3634
  %3636 = mul i64 %3635, 48
  %3637 = add i64 %3636, %3633
  %tile_snapshot.spill.load1210 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %3638 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1210, 0
  %3639 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1210, 1
  %.splatinsert1211 = insertelement <8 x i64> poison, i64 %3637, i64 0
  %.splat1212 = shufflevector <8 x i64> %.splatinsert1211, <8 x i64> poison, <8 x i32> zeroinitializer
  %3640 = mul <8 x i64> %.splat1212, splat (i64 32)
  %3641 = add <8 x i64> %3639, %3640
  %3642 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3638, 0
  %3643 = insertvalue { <8 x ptr>, <8 x i64> } %3642, <8 x i64> %3641, 1
  %3644 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %3645 = extractvalue { <8 x ptr>, <8 x i64> } %3643, 1
  %3646 = extractelement <8 x ptr> %3644, i32 0
  %3647 = extractelement <8 x i64> %3645, i32 0
  %3648 = sub i64 %3647, 0
  %3649 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3650 = select i1 %3649, i64 %3648, i64 0
  %private.contiguous.address1213 = getelementptr i8, ptr %3646, i64 %3650
  %private.contiguous.load1214 = load <8 x float>, ptr %private.contiguous.address1213, align 4
  %3651 = select <8 x i1> %95, <8 x float> %private.contiguous.load1214, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1215 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill132, align 64
  %3652 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1215, 0
  %3653 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1215, 1
  %.splatinsert1216 = insertelement <8 x i64> poison, i64 %3635, i64 0
  %.splat1217 = shufflevector <8 x i64> %.splatinsert1216, <8 x i64> poison, <8 x i32> zeroinitializer
  %3654 = mul <8 x i64> %.splat1217, splat (i64 32)
  %3655 = add <8 x i64> %3653, %3654
  %3656 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3652, 0
  %3657 = insertvalue { <8 x ptr>, <8 x i64> } %3656, <8 x i64> %3655, 1
  %3658 = extractvalue { <8 x ptr>, <8 x i64> } %38, 0
  %3659 = extractvalue { <8 x ptr>, <8 x i64> } %3657, 1
  %3660 = extractelement <8 x ptr> %3658, i32 0
  %3661 = extractelement <8 x i64> %3659, i32 0
  %3662 = sub i64 %3661, 0
  %3663 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3664 = select i1 %3663, i64 %3662, i64 0
  %private.contiguous.address1218 = getelementptr i8, ptr %3660, i64 %3664
  %private.contiguous.load1219 = load <8 x float>, ptr %private.contiguous.address1218, align 4
  %3665 = select <8 x i1> %95, <8 x float> %private.contiguous.load1219, <8 x float> zeroinitializer
  %3666 = fmul <8 x float> %3651, %3665
  %3667 = mul i64 %3530, 16
  %3668 = add i64 %3667, 0
  %tile_snapshot.spill.load1220 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3669 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1220, 0
  %3670 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1220, 1
  %.splatinsert1221 = insertelement <8 x i64> poison, i64 %3668, i64 0
  %.splat1222 = shufflevector <8 x i64> %.splatinsert1221, <8 x i64> poison, <8 x i32> zeroinitializer
  %3671 = mul <8 x i64> %.splat1222, splat (i64 32)
  %3672 = add <8 x i64> %3670, %3671
  %3673 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3669, 0
  %3674 = insertvalue { <8 x ptr>, <8 x i64> } %3673, <8 x i64> %3672, 1
  %3675 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3676 = extractvalue { <8 x ptr>, <8 x i64> } %3674, 1
  %3677 = extractelement <8 x ptr> %3675, i32 0
  %3678 = extractelement <8 x i64> %3676, i32 0
  %3679 = sub i64 %3678, 0
  %3680 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3681 = select i1 %3680, i64 %3679, i64 0
  %private.contiguous.address1223 = getelementptr i8, ptr %3677, i64 %3681
  %private.contiguous.load1224 = load <8 x float>, ptr %private.contiguous.address1223, align 4
  %3682 = select <8 x i1> %95, <8 x float> %private.contiguous.load1224, <8 x float> zeroinitializer
  %3683 = mul i64 %3600, 16
  %3684 = add i64 %3683, 0
  %tile_snapshot.spill.load1225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1225, 0
  %3686 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1225, 1
  %.splatinsert1226 = insertelement <8 x i64> poison, i64 %3684, i64 0
  %.splat1227 = shufflevector <8 x i64> %.splatinsert1226, <8 x i64> poison, <8 x i32> zeroinitializer
  %3687 = mul <8 x i64> %.splat1227, splat (i64 32)
  %3688 = add <8 x i64> %3686, %3687
  %3689 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3685, 0
  %3690 = insertvalue { <8 x ptr>, <8 x i64> } %3689, <8 x i64> %3688, 1
  %3691 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3692 = extractvalue { <8 x ptr>, <8 x i64> } %3690, 1
  %3693 = extractelement <8 x ptr> %3691, i32 0
  %3694 = extractelement <8 x i64> %3692, i32 0
  %3695 = sub i64 %3694, 0
  %3696 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3697 = select i1 %3696, i64 %3695, i64 0
  %private.contiguous.address1228 = getelementptr i8, ptr %3693, i64 %3697
  %private.contiguous.load1229 = load <8 x float>, ptr %private.contiguous.address1228, align 4
  %3698 = select <8 x i1> %95, <8 x float> %private.contiguous.load1229, <8 x float> zeroinitializer
  %3699 = add i64 0, %3528
  %tile_snapshot.spill.load1230 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %3700 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1230, 0
  %3701 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1230, 1
  %.splatinsert1231 = insertelement <8 x i64> poison, i64 %3699, i64 0
  %.splat1232 = shufflevector <8 x i64> %.splatinsert1231, <8 x i64> poison, <8 x i32> zeroinitializer
  %3702 = mul <8 x i64> %.splat1232, splat (i64 4)
  %3703 = add <8 x i64> %3701, %3702
  %3704 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3700, 0
  %3705 = insertvalue { <8 x ptr>, <8 x i64> } %3704, <8 x i64> %3703, 1
  %3706 = extractvalue { <8 x ptr>, <8 x i64> } %3705, 0
  %3707 = extractvalue { <8 x ptr>, <8 x i64> } %3705, 1
  %3708 = getelementptr i8, <8 x ptr> %3706, <8 x i64> %3707
  %3709 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3708, <8 x i1> %95, <8 x float> zeroinitializer)
  %3710 = add i64 0, %3563
  %tile_snapshot.spill.load1233 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %3711 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1233, 0
  %3712 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1233, 1
  %.splatinsert1234 = insertelement <8 x i64> poison, i64 %3710, i64 0
  %.splat1235 = shufflevector <8 x i64> %.splatinsert1234, <8 x i64> poison, <8 x i32> zeroinitializer
  %3713 = mul <8 x i64> %.splat1235, splat (i64 4)
  %3714 = add <8 x i64> %3712, %3713
  %3715 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3711, 0
  %3716 = insertvalue { <8 x ptr>, <8 x i64> } %3715, <8 x i64> %3714, 1
  %3717 = extractvalue { <8 x ptr>, <8 x i64> } %3716, 0
  %3718 = extractvalue { <8 x ptr>, <8 x i64> } %3716, 1
  %3719 = getelementptr i8, <8 x ptr> %3717, <8 x i64> %3718
  %3720 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3719, <8 x i1> %95, <8 x float> zeroinitializer)
  %3721 = fmul <8 x float> %3682, %3709
  %3722 = fadd <8 x float> %3561, %3721
  %3723 = fmul <8 x float> %3682, %3720
  %3724 = fadd <8 x float> %3596, %3723
  %3725 = fmul <8 x float> %3698, %3709
  %3726 = fadd <8 x float> %3631, %3725
  %3727 = fmul <8 x float> %3698, %3720
  %3728 = fadd <8 x float> %3666, %3727
  %3729 = add i64 %3667, 1
  %tile_snapshot.spill.load1236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3730 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1236, 0
  %3731 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1236, 1
  %.splatinsert1237 = insertelement <8 x i64> poison, i64 %3729, i64 0
  %.splat1238 = shufflevector <8 x i64> %.splatinsert1237, <8 x i64> poison, <8 x i32> zeroinitializer
  %3732 = mul <8 x i64> %.splat1238, splat (i64 32)
  %3733 = add <8 x i64> %3731, %3732
  %3734 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3730, 0
  %3735 = insertvalue { <8 x ptr>, <8 x i64> } %3734, <8 x i64> %3733, 1
  %3736 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3737 = extractvalue { <8 x ptr>, <8 x i64> } %3735, 1
  %3738 = extractelement <8 x ptr> %3736, i32 0
  %3739 = extractelement <8 x i64> %3737, i32 0
  %3740 = sub i64 %3739, 0
  %3741 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3742 = select i1 %3741, i64 %3740, i64 0
  %private.contiguous.address1239 = getelementptr i8, ptr %3738, i64 %3742
  %private.contiguous.load1240 = load <8 x float>, ptr %private.contiguous.address1239, align 4
  %3743 = select <8 x i1> %95, <8 x float> %private.contiguous.load1240, <8 x float> zeroinitializer
  %3744 = add i64 %3683, 1
  %tile_snapshot.spill.load1241 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3745 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1241, 0
  %3746 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1241, 1
  %.splatinsert1242 = insertelement <8 x i64> poison, i64 %3744, i64 0
  %.splat1243 = shufflevector <8 x i64> %.splatinsert1242, <8 x i64> poison, <8 x i32> zeroinitializer
  %3747 = mul <8 x i64> %.splat1243, splat (i64 32)
  %3748 = add <8 x i64> %3746, %3747
  %3749 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3745, 0
  %3750 = insertvalue { <8 x ptr>, <8 x i64> } %3749, <8 x i64> %3748, 1
  %3751 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3752 = extractvalue { <8 x ptr>, <8 x i64> } %3750, 1
  %3753 = extractelement <8 x ptr> %3751, i32 0
  %3754 = extractelement <8 x i64> %3752, i32 0
  %3755 = sub i64 %3754, 0
  %3756 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3757 = select i1 %3756, i64 %3755, i64 0
  %private.contiguous.address1244 = getelementptr i8, ptr %3753, i64 %3757
  %private.contiguous.load1245 = load <8 x float>, ptr %private.contiguous.address1244, align 4
  %3758 = select <8 x i1> %95, <8 x float> %private.contiguous.load1245, <8 x float> zeroinitializer
  %3759 = add i64 48, %3528
  %tile_snapshot.spill.load1246 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %3760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1246, 0
  %3761 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1246, 1
  %.splatinsert1247 = insertelement <8 x i64> poison, i64 %3759, i64 0
  %.splat1248 = shufflevector <8 x i64> %.splatinsert1247, <8 x i64> poison, <8 x i32> zeroinitializer
  %3762 = mul <8 x i64> %.splat1248, splat (i64 4)
  %3763 = add <8 x i64> %3761, %3762
  %3764 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3760, 0
  %3765 = insertvalue { <8 x ptr>, <8 x i64> } %3764, <8 x i64> %3763, 1
  %3766 = extractvalue { <8 x ptr>, <8 x i64> } %3765, 0
  %3767 = extractvalue { <8 x ptr>, <8 x i64> } %3765, 1
  %3768 = getelementptr i8, <8 x ptr> %3766, <8 x i64> %3767
  %3769 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3768, <8 x i1> %95, <8 x float> zeroinitializer)
  %3770 = add i64 48, %3563
  %tile_snapshot.spill.load1249 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %3771 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1249, 0
  %3772 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1249, 1
  %.splatinsert1250 = insertelement <8 x i64> poison, i64 %3770, i64 0
  %.splat1251 = shufflevector <8 x i64> %.splatinsert1250, <8 x i64> poison, <8 x i32> zeroinitializer
  %3773 = mul <8 x i64> %.splat1251, splat (i64 4)
  %3774 = add <8 x i64> %3772, %3773
  %3775 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3771, 0
  %3776 = insertvalue { <8 x ptr>, <8 x i64> } %3775, <8 x i64> %3774, 1
  %3777 = extractvalue { <8 x ptr>, <8 x i64> } %3776, 0
  %3778 = extractvalue { <8 x ptr>, <8 x i64> } %3776, 1
  %3779 = getelementptr i8, <8 x ptr> %3777, <8 x i64> %3778
  %3780 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3779, <8 x i1> %95, <8 x float> zeroinitializer)
  %3781 = fmul <8 x float> %3743, %3769
  %3782 = fadd <8 x float> %3722, %3781
  %3783 = fmul <8 x float> %3743, %3780
  %3784 = fadd <8 x float> %3724, %3783
  %3785 = fmul <8 x float> %3758, %3769
  %3786 = fadd <8 x float> %3726, %3785
  %3787 = fmul <8 x float> %3758, %3780
  %3788 = fadd <8 x float> %3728, %3787
  %3789 = add i64 %3667, 2
  %tile_snapshot.spill.load1252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3790 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1252, 0
  %3791 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1252, 1
  %.splatinsert1253 = insertelement <8 x i64> poison, i64 %3789, i64 0
  %.splat1254 = shufflevector <8 x i64> %.splatinsert1253, <8 x i64> poison, <8 x i32> zeroinitializer
  %3792 = mul <8 x i64> %.splat1254, splat (i64 32)
  %3793 = add <8 x i64> %3791, %3792
  %3794 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3790, 0
  %3795 = insertvalue { <8 x ptr>, <8 x i64> } %3794, <8 x i64> %3793, 1
  %3796 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3797 = extractvalue { <8 x ptr>, <8 x i64> } %3795, 1
  %3798 = extractelement <8 x ptr> %3796, i32 0
  %3799 = extractelement <8 x i64> %3797, i32 0
  %3800 = sub i64 %3799, 0
  %3801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3802 = select i1 %3801, i64 %3800, i64 0
  %private.contiguous.address1255 = getelementptr i8, ptr %3798, i64 %3802
  %private.contiguous.load1256 = load <8 x float>, ptr %private.contiguous.address1255, align 4
  %3803 = select <8 x i1> %95, <8 x float> %private.contiguous.load1256, <8 x float> zeroinitializer
  %3804 = add i64 %3683, 2
  %tile_snapshot.spill.load1257 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3805 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1257, 0
  %3806 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1257, 1
  %.splatinsert1258 = insertelement <8 x i64> poison, i64 %3804, i64 0
  %.splat1259 = shufflevector <8 x i64> %.splatinsert1258, <8 x i64> poison, <8 x i32> zeroinitializer
  %3807 = mul <8 x i64> %.splat1259, splat (i64 32)
  %3808 = add <8 x i64> %3806, %3807
  %3809 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3805, 0
  %3810 = insertvalue { <8 x ptr>, <8 x i64> } %3809, <8 x i64> %3808, 1
  %3811 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3812 = extractvalue { <8 x ptr>, <8 x i64> } %3810, 1
  %3813 = extractelement <8 x ptr> %3811, i32 0
  %3814 = extractelement <8 x i64> %3812, i32 0
  %3815 = sub i64 %3814, 0
  %3816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3817 = select i1 %3816, i64 %3815, i64 0
  %private.contiguous.address1260 = getelementptr i8, ptr %3813, i64 %3817
  %private.contiguous.load1261 = load <8 x float>, ptr %private.contiguous.address1260, align 4
  %3818 = select <8 x i1> %95, <8 x float> %private.contiguous.load1261, <8 x float> zeroinitializer
  %3819 = add i64 96, %3528
  %tile_snapshot.spill.load1262 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %3820 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1262, 0
  %3821 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1262, 1
  %.splatinsert1263 = insertelement <8 x i64> poison, i64 %3819, i64 0
  %.splat1264 = shufflevector <8 x i64> %.splatinsert1263, <8 x i64> poison, <8 x i32> zeroinitializer
  %3822 = mul <8 x i64> %.splat1264, splat (i64 4)
  %3823 = add <8 x i64> %3821, %3822
  %3824 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3820, 0
  %3825 = insertvalue { <8 x ptr>, <8 x i64> } %3824, <8 x i64> %3823, 1
  %3826 = extractvalue { <8 x ptr>, <8 x i64> } %3825, 0
  %3827 = extractvalue { <8 x ptr>, <8 x i64> } %3825, 1
  %3828 = getelementptr i8, <8 x ptr> %3826, <8 x i64> %3827
  %3829 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3828, <8 x i1> %95, <8 x float> zeroinitializer)
  %3830 = add i64 96, %3563
  %tile_snapshot.spill.load1265 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %3831 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1265, 0
  %3832 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1265, 1
  %.splatinsert1266 = insertelement <8 x i64> poison, i64 %3830, i64 0
  %.splat1267 = shufflevector <8 x i64> %.splatinsert1266, <8 x i64> poison, <8 x i32> zeroinitializer
  %3833 = mul <8 x i64> %.splat1267, splat (i64 4)
  %3834 = add <8 x i64> %3832, %3833
  %3835 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3831, 0
  %3836 = insertvalue { <8 x ptr>, <8 x i64> } %3835, <8 x i64> %3834, 1
  %3837 = extractvalue { <8 x ptr>, <8 x i64> } %3836, 0
  %3838 = extractvalue { <8 x ptr>, <8 x i64> } %3836, 1
  %3839 = getelementptr i8, <8 x ptr> %3837, <8 x i64> %3838
  %3840 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3839, <8 x i1> %95, <8 x float> zeroinitializer)
  %3841 = fmul <8 x float> %3803, %3829
  %3842 = fadd <8 x float> %3782, %3841
  %3843 = fmul <8 x float> %3803, %3840
  %3844 = fadd <8 x float> %3784, %3843
  %3845 = fmul <8 x float> %3818, %3829
  %3846 = fadd <8 x float> %3786, %3845
  %3847 = fmul <8 x float> %3818, %3840
  %3848 = fadd <8 x float> %3788, %3847
  %3849 = add i64 %3667, 3
  %tile_snapshot.spill.load1268 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3850 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1268, 0
  %3851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1268, 1
  %.splatinsert1269 = insertelement <8 x i64> poison, i64 %3849, i64 0
  %.splat1270 = shufflevector <8 x i64> %.splatinsert1269, <8 x i64> poison, <8 x i32> zeroinitializer
  %3852 = mul <8 x i64> %.splat1270, splat (i64 32)
  %3853 = add <8 x i64> %3851, %3852
  %3854 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3850, 0
  %3855 = insertvalue { <8 x ptr>, <8 x i64> } %3854, <8 x i64> %3853, 1
  %3856 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3857 = extractvalue { <8 x ptr>, <8 x i64> } %3855, 1
  %3858 = extractelement <8 x ptr> %3856, i32 0
  %3859 = extractelement <8 x i64> %3857, i32 0
  %3860 = sub i64 %3859, 0
  %3861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3862 = select i1 %3861, i64 %3860, i64 0
  %private.contiguous.address1271 = getelementptr i8, ptr %3858, i64 %3862
  %private.contiguous.load1272 = load <8 x float>, ptr %private.contiguous.address1271, align 4
  %3863 = select <8 x i1> %95, <8 x float> %private.contiguous.load1272, <8 x float> zeroinitializer
  %3864 = add i64 %3683, 3
  %tile_snapshot.spill.load1273 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1273, 0
  %3866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1273, 1
  %.splatinsert1274 = insertelement <8 x i64> poison, i64 %3864, i64 0
  %.splat1275 = shufflevector <8 x i64> %.splatinsert1274, <8 x i64> poison, <8 x i32> zeroinitializer
  %3867 = mul <8 x i64> %.splat1275, splat (i64 32)
  %3868 = add <8 x i64> %3866, %3867
  %3869 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3865, 0
  %3870 = insertvalue { <8 x ptr>, <8 x i64> } %3869, <8 x i64> %3868, 1
  %3871 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3872 = extractvalue { <8 x ptr>, <8 x i64> } %3870, 1
  %3873 = extractelement <8 x ptr> %3871, i32 0
  %3874 = extractelement <8 x i64> %3872, i32 0
  %3875 = sub i64 %3874, 0
  %3876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3877 = select i1 %3876, i64 %3875, i64 0
  %private.contiguous.address1276 = getelementptr i8, ptr %3873, i64 %3877
  %private.contiguous.load1277 = load <8 x float>, ptr %private.contiguous.address1276, align 4
  %3878 = select <8 x i1> %95, <8 x float> %private.contiguous.load1277, <8 x float> zeroinitializer
  %3879 = add i64 144, %3528
  %tile_snapshot.spill.load1278 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %3880 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1278, 0
  %3881 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1278, 1
  %.splatinsert1279 = insertelement <8 x i64> poison, i64 %3879, i64 0
  %.splat1280 = shufflevector <8 x i64> %.splatinsert1279, <8 x i64> poison, <8 x i32> zeroinitializer
  %3882 = mul <8 x i64> %.splat1280, splat (i64 4)
  %3883 = add <8 x i64> %3881, %3882
  %3884 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3880, 0
  %3885 = insertvalue { <8 x ptr>, <8 x i64> } %3884, <8 x i64> %3883, 1
  %3886 = extractvalue { <8 x ptr>, <8 x i64> } %3885, 0
  %3887 = extractvalue { <8 x ptr>, <8 x i64> } %3885, 1
  %3888 = getelementptr i8, <8 x ptr> %3886, <8 x i64> %3887
  %3889 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3888, <8 x i1> %95, <8 x float> zeroinitializer)
  %3890 = add i64 144, %3563
  %tile_snapshot.spill.load1281 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %3891 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1281, 0
  %3892 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1281, 1
  %.splatinsert1282 = insertelement <8 x i64> poison, i64 %3890, i64 0
  %.splat1283 = shufflevector <8 x i64> %.splatinsert1282, <8 x i64> poison, <8 x i32> zeroinitializer
  %3893 = mul <8 x i64> %.splat1283, splat (i64 4)
  %3894 = add <8 x i64> %3892, %3893
  %3895 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3891, 0
  %3896 = insertvalue { <8 x ptr>, <8 x i64> } %3895, <8 x i64> %3894, 1
  %3897 = extractvalue { <8 x ptr>, <8 x i64> } %3896, 0
  %3898 = extractvalue { <8 x ptr>, <8 x i64> } %3896, 1
  %3899 = getelementptr i8, <8 x ptr> %3897, <8 x i64> %3898
  %3900 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3899, <8 x i1> %95, <8 x float> zeroinitializer)
  %3901 = fmul <8 x float> %3863, %3889
  %3902 = fadd <8 x float> %3842, %3901
  %3903 = fmul <8 x float> %3863, %3900
  %3904 = fadd <8 x float> %3844, %3903
  %3905 = fmul <8 x float> %3878, %3889
  %3906 = fadd <8 x float> %3846, %3905
  %3907 = fmul <8 x float> %3878, %3900
  %3908 = fadd <8 x float> %3848, %3907
  %3909 = add i64 %3667, 4
  %tile_snapshot.spill.load1284 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3910 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1284, 0
  %3911 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1284, 1
  %.splatinsert1285 = insertelement <8 x i64> poison, i64 %3909, i64 0
  %.splat1286 = shufflevector <8 x i64> %.splatinsert1285, <8 x i64> poison, <8 x i32> zeroinitializer
  %3912 = mul <8 x i64> %.splat1286, splat (i64 32)
  %3913 = add <8 x i64> %3911, %3912
  %3914 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3910, 0
  %3915 = insertvalue { <8 x ptr>, <8 x i64> } %3914, <8 x i64> %3913, 1
  %3916 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3917 = extractvalue { <8 x ptr>, <8 x i64> } %3915, 1
  %3918 = extractelement <8 x ptr> %3916, i32 0
  %3919 = extractelement <8 x i64> %3917, i32 0
  %3920 = sub i64 %3919, 0
  %3921 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3922 = select i1 %3921, i64 %3920, i64 0
  %private.contiguous.address1287 = getelementptr i8, ptr %3918, i64 %3922
  %private.contiguous.load1288 = load <8 x float>, ptr %private.contiguous.address1287, align 4
  %3923 = select <8 x i1> %95, <8 x float> %private.contiguous.load1288, <8 x float> zeroinitializer
  %3924 = add i64 %3683, 4
  %tile_snapshot.spill.load1289 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1289, 0
  %3926 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1289, 1
  %.splatinsert1290 = insertelement <8 x i64> poison, i64 %3924, i64 0
  %.splat1291 = shufflevector <8 x i64> %.splatinsert1290, <8 x i64> poison, <8 x i32> zeroinitializer
  %3927 = mul <8 x i64> %.splat1291, splat (i64 32)
  %3928 = add <8 x i64> %3926, %3927
  %3929 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3925, 0
  %3930 = insertvalue { <8 x ptr>, <8 x i64> } %3929, <8 x i64> %3928, 1
  %3931 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3932 = extractvalue { <8 x ptr>, <8 x i64> } %3930, 1
  %3933 = extractelement <8 x ptr> %3931, i32 0
  %3934 = extractelement <8 x i64> %3932, i32 0
  %3935 = sub i64 %3934, 0
  %3936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3937 = select i1 %3936, i64 %3935, i64 0
  %private.contiguous.address1292 = getelementptr i8, ptr %3933, i64 %3937
  %private.contiguous.load1293 = load <8 x float>, ptr %private.contiguous.address1292, align 4
  %3938 = select <8 x i1> %95, <8 x float> %private.contiguous.load1293, <8 x float> zeroinitializer
  %3939 = add i64 192, %3528
  %tile_snapshot.spill.load1294 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %3940 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1294, 0
  %3941 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1294, 1
  %.splatinsert1295 = insertelement <8 x i64> poison, i64 %3939, i64 0
  %.splat1296 = shufflevector <8 x i64> %.splatinsert1295, <8 x i64> poison, <8 x i32> zeroinitializer
  %3942 = mul <8 x i64> %.splat1296, splat (i64 4)
  %3943 = add <8 x i64> %3941, %3942
  %3944 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3940, 0
  %3945 = insertvalue { <8 x ptr>, <8 x i64> } %3944, <8 x i64> %3943, 1
  %3946 = extractvalue { <8 x ptr>, <8 x i64> } %3945, 0
  %3947 = extractvalue { <8 x ptr>, <8 x i64> } %3945, 1
  %3948 = getelementptr i8, <8 x ptr> %3946, <8 x i64> %3947
  %3949 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3948, <8 x i1> %95, <8 x float> zeroinitializer)
  %3950 = add i64 192, %3563
  %tile_snapshot.spill.load1297 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %3951 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1297, 0
  %3952 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1297, 1
  %.splatinsert1298 = insertelement <8 x i64> poison, i64 %3950, i64 0
  %.splat1299 = shufflevector <8 x i64> %.splatinsert1298, <8 x i64> poison, <8 x i32> zeroinitializer
  %3953 = mul <8 x i64> %.splat1299, splat (i64 4)
  %3954 = add <8 x i64> %3952, %3953
  %3955 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3951, 0
  %3956 = insertvalue { <8 x ptr>, <8 x i64> } %3955, <8 x i64> %3954, 1
  %3957 = extractvalue { <8 x ptr>, <8 x i64> } %3956, 0
  %3958 = extractvalue { <8 x ptr>, <8 x i64> } %3956, 1
  %3959 = getelementptr i8, <8 x ptr> %3957, <8 x i64> %3958
  %3960 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3959, <8 x i1> %95, <8 x float> zeroinitializer)
  %3961 = fmul <8 x float> %3923, %3949
  %3962 = fadd <8 x float> %3902, %3961
  %3963 = fmul <8 x float> %3923, %3960
  %3964 = fadd <8 x float> %3904, %3963
  %3965 = fmul <8 x float> %3938, %3949
  %3966 = fadd <8 x float> %3906, %3965
  %3967 = fmul <8 x float> %3938, %3960
  %3968 = fadd <8 x float> %3908, %3967
  %3969 = add i64 %3667, 5
  %tile_snapshot.spill.load1300 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3970 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1300, 0
  %3971 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1300, 1
  %.splatinsert1301 = insertelement <8 x i64> poison, i64 %3969, i64 0
  %.splat1302 = shufflevector <8 x i64> %.splatinsert1301, <8 x i64> poison, <8 x i32> zeroinitializer
  %3972 = mul <8 x i64> %.splat1302, splat (i64 32)
  %3973 = add <8 x i64> %3971, %3972
  %3974 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3970, 0
  %3975 = insertvalue { <8 x ptr>, <8 x i64> } %3974, <8 x i64> %3973, 1
  %3976 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3977 = extractvalue { <8 x ptr>, <8 x i64> } %3975, 1
  %3978 = extractelement <8 x ptr> %3976, i32 0
  %3979 = extractelement <8 x i64> %3977, i32 0
  %3980 = sub i64 %3979, 0
  %3981 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3982 = select i1 %3981, i64 %3980, i64 0
  %private.contiguous.address1303 = getelementptr i8, ptr %3978, i64 %3982
  %private.contiguous.load1304 = load <8 x float>, ptr %private.contiguous.address1303, align 4
  %3983 = select <8 x i1> %95, <8 x float> %private.contiguous.load1304, <8 x float> zeroinitializer
  %3984 = add i64 %3683, 5
  %tile_snapshot.spill.load1305 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %3985 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1305, 0
  %3986 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1305, 1
  %.splatinsert1306 = insertelement <8 x i64> poison, i64 %3984, i64 0
  %.splat1307 = shufflevector <8 x i64> %.splatinsert1306, <8 x i64> poison, <8 x i32> zeroinitializer
  %3987 = mul <8 x i64> %.splat1307, splat (i64 32)
  %3988 = add <8 x i64> %3986, %3987
  %3989 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3985, 0
  %3990 = insertvalue { <8 x ptr>, <8 x i64> } %3989, <8 x i64> %3988, 1
  %3991 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %3992 = extractvalue { <8 x ptr>, <8 x i64> } %3990, 1
  %3993 = extractelement <8 x ptr> %3991, i32 0
  %3994 = extractelement <8 x i64> %3992, i32 0
  %3995 = sub i64 %3994, 0
  %3996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %3997 = select i1 %3996, i64 %3995, i64 0
  %private.contiguous.address1308 = getelementptr i8, ptr %3993, i64 %3997
  %private.contiguous.load1309 = load <8 x float>, ptr %private.contiguous.address1308, align 4
  %3998 = select <8 x i1> %95, <8 x float> %private.contiguous.load1309, <8 x float> zeroinitializer
  %3999 = add i64 240, %3528
  %tile_snapshot.spill.load1310 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4000 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1310, 0
  %4001 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1310, 1
  %.splatinsert1311 = insertelement <8 x i64> poison, i64 %3999, i64 0
  %.splat1312 = shufflevector <8 x i64> %.splatinsert1311, <8 x i64> poison, <8 x i32> zeroinitializer
  %4002 = mul <8 x i64> %.splat1312, splat (i64 4)
  %4003 = add <8 x i64> %4001, %4002
  %4004 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4000, 0
  %4005 = insertvalue { <8 x ptr>, <8 x i64> } %4004, <8 x i64> %4003, 1
  %4006 = extractvalue { <8 x ptr>, <8 x i64> } %4005, 0
  %4007 = extractvalue { <8 x ptr>, <8 x i64> } %4005, 1
  %4008 = getelementptr i8, <8 x ptr> %4006, <8 x i64> %4007
  %4009 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4008, <8 x i1> %95, <8 x float> zeroinitializer)
  %4010 = add i64 240, %3563
  %tile_snapshot.spill.load1313 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4011 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1313, 0
  %4012 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1313, 1
  %.splatinsert1314 = insertelement <8 x i64> poison, i64 %4010, i64 0
  %.splat1315 = shufflevector <8 x i64> %.splatinsert1314, <8 x i64> poison, <8 x i32> zeroinitializer
  %4013 = mul <8 x i64> %.splat1315, splat (i64 4)
  %4014 = add <8 x i64> %4012, %4013
  %4015 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4011, 0
  %4016 = insertvalue { <8 x ptr>, <8 x i64> } %4015, <8 x i64> %4014, 1
  %4017 = extractvalue { <8 x ptr>, <8 x i64> } %4016, 0
  %4018 = extractvalue { <8 x ptr>, <8 x i64> } %4016, 1
  %4019 = getelementptr i8, <8 x ptr> %4017, <8 x i64> %4018
  %4020 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4019, <8 x i1> %95, <8 x float> zeroinitializer)
  %4021 = fmul <8 x float> %3983, %4009
  %4022 = fadd <8 x float> %3962, %4021
  %4023 = fmul <8 x float> %3983, %4020
  %4024 = fadd <8 x float> %3964, %4023
  %4025 = fmul <8 x float> %3998, %4009
  %4026 = fadd <8 x float> %3966, %4025
  %4027 = fmul <8 x float> %3998, %4020
  %4028 = fadd <8 x float> %3968, %4027
  %4029 = add i64 %3667, 6
  %tile_snapshot.spill.load1316 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4030 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1316, 0
  %4031 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1316, 1
  %.splatinsert1317 = insertelement <8 x i64> poison, i64 %4029, i64 0
  %.splat1318 = shufflevector <8 x i64> %.splatinsert1317, <8 x i64> poison, <8 x i32> zeroinitializer
  %4032 = mul <8 x i64> %.splat1318, splat (i64 32)
  %4033 = add <8 x i64> %4031, %4032
  %4034 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4030, 0
  %4035 = insertvalue { <8 x ptr>, <8 x i64> } %4034, <8 x i64> %4033, 1
  %4036 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4037 = extractvalue { <8 x ptr>, <8 x i64> } %4035, 1
  %4038 = extractelement <8 x ptr> %4036, i32 0
  %4039 = extractelement <8 x i64> %4037, i32 0
  %4040 = sub i64 %4039, 0
  %4041 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4042 = select i1 %4041, i64 %4040, i64 0
  %private.contiguous.address1319 = getelementptr i8, ptr %4038, i64 %4042
  %private.contiguous.load1320 = load <8 x float>, ptr %private.contiguous.address1319, align 4
  %4043 = select <8 x i1> %95, <8 x float> %private.contiguous.load1320, <8 x float> zeroinitializer
  %4044 = add i64 %3683, 6
  %tile_snapshot.spill.load1321 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4045 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1321, 0
  %4046 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1321, 1
  %.splatinsert1322 = insertelement <8 x i64> poison, i64 %4044, i64 0
  %.splat1323 = shufflevector <8 x i64> %.splatinsert1322, <8 x i64> poison, <8 x i32> zeroinitializer
  %4047 = mul <8 x i64> %.splat1323, splat (i64 32)
  %4048 = add <8 x i64> %4046, %4047
  %4049 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4045, 0
  %4050 = insertvalue { <8 x ptr>, <8 x i64> } %4049, <8 x i64> %4048, 1
  %4051 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4052 = extractvalue { <8 x ptr>, <8 x i64> } %4050, 1
  %4053 = extractelement <8 x ptr> %4051, i32 0
  %4054 = extractelement <8 x i64> %4052, i32 0
  %4055 = sub i64 %4054, 0
  %4056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4057 = select i1 %4056, i64 %4055, i64 0
  %private.contiguous.address1324 = getelementptr i8, ptr %4053, i64 %4057
  %private.contiguous.load1325 = load <8 x float>, ptr %private.contiguous.address1324, align 4
  %4058 = select <8 x i1> %95, <8 x float> %private.contiguous.load1325, <8 x float> zeroinitializer
  %4059 = add i64 288, %3528
  %tile_snapshot.spill.load1326 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4060 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1326, 0
  %4061 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1326, 1
  %.splatinsert1327 = insertelement <8 x i64> poison, i64 %4059, i64 0
  %.splat1328 = shufflevector <8 x i64> %.splatinsert1327, <8 x i64> poison, <8 x i32> zeroinitializer
  %4062 = mul <8 x i64> %.splat1328, splat (i64 4)
  %4063 = add <8 x i64> %4061, %4062
  %4064 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4060, 0
  %4065 = insertvalue { <8 x ptr>, <8 x i64> } %4064, <8 x i64> %4063, 1
  %4066 = extractvalue { <8 x ptr>, <8 x i64> } %4065, 0
  %4067 = extractvalue { <8 x ptr>, <8 x i64> } %4065, 1
  %4068 = getelementptr i8, <8 x ptr> %4066, <8 x i64> %4067
  %4069 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4068, <8 x i1> %95, <8 x float> zeroinitializer)
  %4070 = add i64 288, %3563
  %tile_snapshot.spill.load1329 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4071 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1329, 0
  %4072 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1329, 1
  %.splatinsert1330 = insertelement <8 x i64> poison, i64 %4070, i64 0
  %.splat1331 = shufflevector <8 x i64> %.splatinsert1330, <8 x i64> poison, <8 x i32> zeroinitializer
  %4073 = mul <8 x i64> %.splat1331, splat (i64 4)
  %4074 = add <8 x i64> %4072, %4073
  %4075 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4071, 0
  %4076 = insertvalue { <8 x ptr>, <8 x i64> } %4075, <8 x i64> %4074, 1
  %4077 = extractvalue { <8 x ptr>, <8 x i64> } %4076, 0
  %4078 = extractvalue { <8 x ptr>, <8 x i64> } %4076, 1
  %4079 = getelementptr i8, <8 x ptr> %4077, <8 x i64> %4078
  %4080 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4079, <8 x i1> %95, <8 x float> zeroinitializer)
  %4081 = fmul <8 x float> %4043, %4069
  %4082 = fadd <8 x float> %4022, %4081
  %4083 = fmul <8 x float> %4043, %4080
  %4084 = fadd <8 x float> %4024, %4083
  %4085 = fmul <8 x float> %4058, %4069
  %4086 = fadd <8 x float> %4026, %4085
  %4087 = fmul <8 x float> %4058, %4080
  %4088 = fadd <8 x float> %4028, %4087
  %4089 = add i64 %3667, 7
  %tile_snapshot.spill.load1332 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4090 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1332, 0
  %4091 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1332, 1
  %.splatinsert1333 = insertelement <8 x i64> poison, i64 %4089, i64 0
  %.splat1334 = shufflevector <8 x i64> %.splatinsert1333, <8 x i64> poison, <8 x i32> zeroinitializer
  %4092 = mul <8 x i64> %.splat1334, splat (i64 32)
  %4093 = add <8 x i64> %4091, %4092
  %4094 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4090, 0
  %4095 = insertvalue { <8 x ptr>, <8 x i64> } %4094, <8 x i64> %4093, 1
  %4096 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4097 = extractvalue { <8 x ptr>, <8 x i64> } %4095, 1
  %4098 = extractelement <8 x ptr> %4096, i32 0
  %4099 = extractelement <8 x i64> %4097, i32 0
  %4100 = sub i64 %4099, 0
  %4101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4102 = select i1 %4101, i64 %4100, i64 0
  %private.contiguous.address1335 = getelementptr i8, ptr %4098, i64 %4102
  %private.contiguous.load1336 = load <8 x float>, ptr %private.contiguous.address1335, align 4
  %4103 = select <8 x i1> %95, <8 x float> %private.contiguous.load1336, <8 x float> zeroinitializer
  %4104 = add i64 %3683, 7
  %tile_snapshot.spill.load1337 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4105 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1337, 0
  %4106 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1337, 1
  %.splatinsert1338 = insertelement <8 x i64> poison, i64 %4104, i64 0
  %.splat1339 = shufflevector <8 x i64> %.splatinsert1338, <8 x i64> poison, <8 x i32> zeroinitializer
  %4107 = mul <8 x i64> %.splat1339, splat (i64 32)
  %4108 = add <8 x i64> %4106, %4107
  %4109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4105, 0
  %4110 = insertvalue { <8 x ptr>, <8 x i64> } %4109, <8 x i64> %4108, 1
  %4111 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4112 = extractvalue { <8 x ptr>, <8 x i64> } %4110, 1
  %4113 = extractelement <8 x ptr> %4111, i32 0
  %4114 = extractelement <8 x i64> %4112, i32 0
  %4115 = sub i64 %4114, 0
  %4116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4117 = select i1 %4116, i64 %4115, i64 0
  %private.contiguous.address1340 = getelementptr i8, ptr %4113, i64 %4117
  %private.contiguous.load1341 = load <8 x float>, ptr %private.contiguous.address1340, align 4
  %4118 = select <8 x i1> %95, <8 x float> %private.contiguous.load1341, <8 x float> zeroinitializer
  %4119 = add i64 336, %3528
  %tile_snapshot.spill.load1342 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4120 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1342, 0
  %4121 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1342, 1
  %.splatinsert1343 = insertelement <8 x i64> poison, i64 %4119, i64 0
  %.splat1344 = shufflevector <8 x i64> %.splatinsert1343, <8 x i64> poison, <8 x i32> zeroinitializer
  %4122 = mul <8 x i64> %.splat1344, splat (i64 4)
  %4123 = add <8 x i64> %4121, %4122
  %4124 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4120, 0
  %4125 = insertvalue { <8 x ptr>, <8 x i64> } %4124, <8 x i64> %4123, 1
  %4126 = extractvalue { <8 x ptr>, <8 x i64> } %4125, 0
  %4127 = extractvalue { <8 x ptr>, <8 x i64> } %4125, 1
  %4128 = getelementptr i8, <8 x ptr> %4126, <8 x i64> %4127
  %4129 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4128, <8 x i1> %95, <8 x float> zeroinitializer)
  %4130 = add i64 336, %3563
  %tile_snapshot.spill.load1345 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4131 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1345, 0
  %4132 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1345, 1
  %.splatinsert1346 = insertelement <8 x i64> poison, i64 %4130, i64 0
  %.splat1347 = shufflevector <8 x i64> %.splatinsert1346, <8 x i64> poison, <8 x i32> zeroinitializer
  %4133 = mul <8 x i64> %.splat1347, splat (i64 4)
  %4134 = add <8 x i64> %4132, %4133
  %4135 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4131, 0
  %4136 = insertvalue { <8 x ptr>, <8 x i64> } %4135, <8 x i64> %4134, 1
  %4137 = extractvalue { <8 x ptr>, <8 x i64> } %4136, 0
  %4138 = extractvalue { <8 x ptr>, <8 x i64> } %4136, 1
  %4139 = getelementptr i8, <8 x ptr> %4137, <8 x i64> %4138
  %4140 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4139, <8 x i1> %95, <8 x float> zeroinitializer)
  %4141 = fmul <8 x float> %4103, %4129
  %4142 = fadd <8 x float> %4082, %4141
  %4143 = fmul <8 x float> %4103, %4140
  %4144 = fadd <8 x float> %4084, %4143
  %4145 = fmul <8 x float> %4118, %4129
  %4146 = fadd <8 x float> %4086, %4145
  %4147 = fmul <8 x float> %4118, %4140
  %4148 = fadd <8 x float> %4088, %4147
  %4149 = add i64 %3667, 8
  %tile_snapshot.spill.load1348 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1348, 0
  %4151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1348, 1
  %.splatinsert1349 = insertelement <8 x i64> poison, i64 %4149, i64 0
  %.splat1350 = shufflevector <8 x i64> %.splatinsert1349, <8 x i64> poison, <8 x i32> zeroinitializer
  %4152 = mul <8 x i64> %.splat1350, splat (i64 32)
  %4153 = add <8 x i64> %4151, %4152
  %4154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4150, 0
  %4155 = insertvalue { <8 x ptr>, <8 x i64> } %4154, <8 x i64> %4153, 1
  %4156 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4157 = extractvalue { <8 x ptr>, <8 x i64> } %4155, 1
  %4158 = extractelement <8 x ptr> %4156, i32 0
  %4159 = extractelement <8 x i64> %4157, i32 0
  %4160 = sub i64 %4159, 0
  %4161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4162 = select i1 %4161, i64 %4160, i64 0
  %private.contiguous.address1351 = getelementptr i8, ptr %4158, i64 %4162
  %private.contiguous.load1352 = load <8 x float>, ptr %private.contiguous.address1351, align 4
  %4163 = select <8 x i1> %95, <8 x float> %private.contiguous.load1352, <8 x float> zeroinitializer
  %4164 = add i64 %3683, 8
  %tile_snapshot.spill.load1353 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1353, 0
  %4166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1353, 1
  %.splatinsert1354 = insertelement <8 x i64> poison, i64 %4164, i64 0
  %.splat1355 = shufflevector <8 x i64> %.splatinsert1354, <8 x i64> poison, <8 x i32> zeroinitializer
  %4167 = mul <8 x i64> %.splat1355, splat (i64 32)
  %4168 = add <8 x i64> %4166, %4167
  %4169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4165, 0
  %4170 = insertvalue { <8 x ptr>, <8 x i64> } %4169, <8 x i64> %4168, 1
  %4171 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4172 = extractvalue { <8 x ptr>, <8 x i64> } %4170, 1
  %4173 = extractelement <8 x ptr> %4171, i32 0
  %4174 = extractelement <8 x i64> %4172, i32 0
  %4175 = sub i64 %4174, 0
  %4176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4177 = select i1 %4176, i64 %4175, i64 0
  %private.contiguous.address1356 = getelementptr i8, ptr %4173, i64 %4177
  %private.contiguous.load1357 = load <8 x float>, ptr %private.contiguous.address1356, align 4
  %4178 = select <8 x i1> %95, <8 x float> %private.contiguous.load1357, <8 x float> zeroinitializer
  %4179 = add i64 384, %3528
  %tile_snapshot.spill.load1358 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1358, 0
  %4181 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1358, 1
  %.splatinsert1359 = insertelement <8 x i64> poison, i64 %4179, i64 0
  %.splat1360 = shufflevector <8 x i64> %.splatinsert1359, <8 x i64> poison, <8 x i32> zeroinitializer
  %4182 = mul <8 x i64> %.splat1360, splat (i64 4)
  %4183 = add <8 x i64> %4181, %4182
  %4184 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4180, 0
  %4185 = insertvalue { <8 x ptr>, <8 x i64> } %4184, <8 x i64> %4183, 1
  %4186 = extractvalue { <8 x ptr>, <8 x i64> } %4185, 0
  %4187 = extractvalue { <8 x ptr>, <8 x i64> } %4185, 1
  %4188 = getelementptr i8, <8 x ptr> %4186, <8 x i64> %4187
  %4189 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4188, <8 x i1> %95, <8 x float> zeroinitializer)
  %4190 = add i64 384, %3563
  %tile_snapshot.spill.load1361 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1361, 0
  %4192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1361, 1
  %.splatinsert1362 = insertelement <8 x i64> poison, i64 %4190, i64 0
  %.splat1363 = shufflevector <8 x i64> %.splatinsert1362, <8 x i64> poison, <8 x i32> zeroinitializer
  %4193 = mul <8 x i64> %.splat1363, splat (i64 4)
  %4194 = add <8 x i64> %4192, %4193
  %4195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4191, 0
  %4196 = insertvalue { <8 x ptr>, <8 x i64> } %4195, <8 x i64> %4194, 1
  %4197 = extractvalue { <8 x ptr>, <8 x i64> } %4196, 0
  %4198 = extractvalue { <8 x ptr>, <8 x i64> } %4196, 1
  %4199 = getelementptr i8, <8 x ptr> %4197, <8 x i64> %4198
  %4200 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4199, <8 x i1> %95, <8 x float> zeroinitializer)
  %4201 = fmul <8 x float> %4163, %4189
  %4202 = fadd <8 x float> %4142, %4201
  %4203 = fmul <8 x float> %4163, %4200
  %4204 = fadd <8 x float> %4144, %4203
  %4205 = fmul <8 x float> %4178, %4189
  %4206 = fadd <8 x float> %4146, %4205
  %4207 = fmul <8 x float> %4178, %4200
  %4208 = fadd <8 x float> %4148, %4207
  %4209 = add i64 %3667, 9
  %tile_snapshot.spill.load1364 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1364, 0
  %4211 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1364, 1
  %.splatinsert1365 = insertelement <8 x i64> poison, i64 %4209, i64 0
  %.splat1366 = shufflevector <8 x i64> %.splatinsert1365, <8 x i64> poison, <8 x i32> zeroinitializer
  %4212 = mul <8 x i64> %.splat1366, splat (i64 32)
  %4213 = add <8 x i64> %4211, %4212
  %4214 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4210, 0
  %4215 = insertvalue { <8 x ptr>, <8 x i64> } %4214, <8 x i64> %4213, 1
  %4216 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4217 = extractvalue { <8 x ptr>, <8 x i64> } %4215, 1
  %4218 = extractelement <8 x ptr> %4216, i32 0
  %4219 = extractelement <8 x i64> %4217, i32 0
  %4220 = sub i64 %4219, 0
  %4221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4222 = select i1 %4221, i64 %4220, i64 0
  %private.contiguous.address1367 = getelementptr i8, ptr %4218, i64 %4222
  %private.contiguous.load1368 = load <8 x float>, ptr %private.contiguous.address1367, align 4
  %4223 = select <8 x i1> %95, <8 x float> %private.contiguous.load1368, <8 x float> zeroinitializer
  %4224 = add i64 %3683, 9
  %tile_snapshot.spill.load1369 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1369, 0
  %4226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1369, 1
  %.splatinsert1370 = insertelement <8 x i64> poison, i64 %4224, i64 0
  %.splat1371 = shufflevector <8 x i64> %.splatinsert1370, <8 x i64> poison, <8 x i32> zeroinitializer
  %4227 = mul <8 x i64> %.splat1371, splat (i64 32)
  %4228 = add <8 x i64> %4226, %4227
  %4229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4225, 0
  %4230 = insertvalue { <8 x ptr>, <8 x i64> } %4229, <8 x i64> %4228, 1
  %4231 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4232 = extractvalue { <8 x ptr>, <8 x i64> } %4230, 1
  %4233 = extractelement <8 x ptr> %4231, i32 0
  %4234 = extractelement <8 x i64> %4232, i32 0
  %4235 = sub i64 %4234, 0
  %4236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4237 = select i1 %4236, i64 %4235, i64 0
  %private.contiguous.address1372 = getelementptr i8, ptr %4233, i64 %4237
  %private.contiguous.load1373 = load <8 x float>, ptr %private.contiguous.address1372, align 4
  %4238 = select <8 x i1> %95, <8 x float> %private.contiguous.load1373, <8 x float> zeroinitializer
  %4239 = add i64 432, %3528
  %tile_snapshot.spill.load1374 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4240 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1374, 0
  %4241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1374, 1
  %.splatinsert1375 = insertelement <8 x i64> poison, i64 %4239, i64 0
  %.splat1376 = shufflevector <8 x i64> %.splatinsert1375, <8 x i64> poison, <8 x i32> zeroinitializer
  %4242 = mul <8 x i64> %.splat1376, splat (i64 4)
  %4243 = add <8 x i64> %4241, %4242
  %4244 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4240, 0
  %4245 = insertvalue { <8 x ptr>, <8 x i64> } %4244, <8 x i64> %4243, 1
  %4246 = extractvalue { <8 x ptr>, <8 x i64> } %4245, 0
  %4247 = extractvalue { <8 x ptr>, <8 x i64> } %4245, 1
  %4248 = getelementptr i8, <8 x ptr> %4246, <8 x i64> %4247
  %4249 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4248, <8 x i1> %95, <8 x float> zeroinitializer)
  %4250 = add i64 432, %3563
  %tile_snapshot.spill.load1377 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1377, 0
  %4252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1377, 1
  %.splatinsert1378 = insertelement <8 x i64> poison, i64 %4250, i64 0
  %.splat1379 = shufflevector <8 x i64> %.splatinsert1378, <8 x i64> poison, <8 x i32> zeroinitializer
  %4253 = mul <8 x i64> %.splat1379, splat (i64 4)
  %4254 = add <8 x i64> %4252, %4253
  %4255 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4251, 0
  %4256 = insertvalue { <8 x ptr>, <8 x i64> } %4255, <8 x i64> %4254, 1
  %4257 = extractvalue { <8 x ptr>, <8 x i64> } %4256, 0
  %4258 = extractvalue { <8 x ptr>, <8 x i64> } %4256, 1
  %4259 = getelementptr i8, <8 x ptr> %4257, <8 x i64> %4258
  %4260 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4259, <8 x i1> %95, <8 x float> zeroinitializer)
  %4261 = fmul <8 x float> %4223, %4249
  %4262 = fadd <8 x float> %4202, %4261
  %4263 = fmul <8 x float> %4223, %4260
  %4264 = fadd <8 x float> %4204, %4263
  %4265 = fmul <8 x float> %4238, %4249
  %4266 = fadd <8 x float> %4206, %4265
  %4267 = fmul <8 x float> %4238, %4260
  %4268 = fadd <8 x float> %4208, %4267
  %4269 = add i64 %3667, 10
  %tile_snapshot.spill.load1380 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4270 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1380, 0
  %4271 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1380, 1
  %.splatinsert1381 = insertelement <8 x i64> poison, i64 %4269, i64 0
  %.splat1382 = shufflevector <8 x i64> %.splatinsert1381, <8 x i64> poison, <8 x i32> zeroinitializer
  %4272 = mul <8 x i64> %.splat1382, splat (i64 32)
  %4273 = add <8 x i64> %4271, %4272
  %4274 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4270, 0
  %4275 = insertvalue { <8 x ptr>, <8 x i64> } %4274, <8 x i64> %4273, 1
  %4276 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4277 = extractvalue { <8 x ptr>, <8 x i64> } %4275, 1
  %4278 = extractelement <8 x ptr> %4276, i32 0
  %4279 = extractelement <8 x i64> %4277, i32 0
  %4280 = sub i64 %4279, 0
  %4281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4282 = select i1 %4281, i64 %4280, i64 0
  %private.contiguous.address1383 = getelementptr i8, ptr %4278, i64 %4282
  %private.contiguous.load1384 = load <8 x float>, ptr %private.contiguous.address1383, align 4
  %4283 = select <8 x i1> %95, <8 x float> %private.contiguous.load1384, <8 x float> zeroinitializer
  %4284 = add i64 %3683, 10
  %tile_snapshot.spill.load1385 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1385, 0
  %4286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1385, 1
  %.splatinsert1386 = insertelement <8 x i64> poison, i64 %4284, i64 0
  %.splat1387 = shufflevector <8 x i64> %.splatinsert1386, <8 x i64> poison, <8 x i32> zeroinitializer
  %4287 = mul <8 x i64> %.splat1387, splat (i64 32)
  %4288 = add <8 x i64> %4286, %4287
  %4289 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4285, 0
  %4290 = insertvalue { <8 x ptr>, <8 x i64> } %4289, <8 x i64> %4288, 1
  %4291 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4292 = extractvalue { <8 x ptr>, <8 x i64> } %4290, 1
  %4293 = extractelement <8 x ptr> %4291, i32 0
  %4294 = extractelement <8 x i64> %4292, i32 0
  %4295 = sub i64 %4294, 0
  %4296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4297 = select i1 %4296, i64 %4295, i64 0
  %private.contiguous.address1388 = getelementptr i8, ptr %4293, i64 %4297
  %private.contiguous.load1389 = load <8 x float>, ptr %private.contiguous.address1388, align 4
  %4298 = select <8 x i1> %95, <8 x float> %private.contiguous.load1389, <8 x float> zeroinitializer
  %4299 = add i64 480, %3528
  %tile_snapshot.spill.load1390 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4300 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1390, 0
  %4301 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1390, 1
  %.splatinsert1391 = insertelement <8 x i64> poison, i64 %4299, i64 0
  %.splat1392 = shufflevector <8 x i64> %.splatinsert1391, <8 x i64> poison, <8 x i32> zeroinitializer
  %4302 = mul <8 x i64> %.splat1392, splat (i64 4)
  %4303 = add <8 x i64> %4301, %4302
  %4304 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4300, 0
  %4305 = insertvalue { <8 x ptr>, <8 x i64> } %4304, <8 x i64> %4303, 1
  %4306 = extractvalue { <8 x ptr>, <8 x i64> } %4305, 0
  %4307 = extractvalue { <8 x ptr>, <8 x i64> } %4305, 1
  %4308 = getelementptr i8, <8 x ptr> %4306, <8 x i64> %4307
  %4309 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4308, <8 x i1> %95, <8 x float> zeroinitializer)
  %4310 = add i64 480, %3563
  %tile_snapshot.spill.load1393 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1393, 0
  %4312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1393, 1
  %.splatinsert1394 = insertelement <8 x i64> poison, i64 %4310, i64 0
  %.splat1395 = shufflevector <8 x i64> %.splatinsert1394, <8 x i64> poison, <8 x i32> zeroinitializer
  %4313 = mul <8 x i64> %.splat1395, splat (i64 4)
  %4314 = add <8 x i64> %4312, %4313
  %4315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4311, 0
  %4316 = insertvalue { <8 x ptr>, <8 x i64> } %4315, <8 x i64> %4314, 1
  %4317 = extractvalue { <8 x ptr>, <8 x i64> } %4316, 0
  %4318 = extractvalue { <8 x ptr>, <8 x i64> } %4316, 1
  %4319 = getelementptr i8, <8 x ptr> %4317, <8 x i64> %4318
  %4320 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4319, <8 x i1> %95, <8 x float> zeroinitializer)
  %4321 = fmul <8 x float> %4283, %4309
  %4322 = fadd <8 x float> %4262, %4321
  %4323 = fmul <8 x float> %4283, %4320
  %4324 = fadd <8 x float> %4264, %4323
  %4325 = fmul <8 x float> %4298, %4309
  %4326 = fadd <8 x float> %4266, %4325
  %4327 = fmul <8 x float> %4298, %4320
  %4328 = fadd <8 x float> %4268, %4327
  %4329 = add i64 %3667, 11
  %tile_snapshot.spill.load1396 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4330 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1396, 0
  %4331 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1396, 1
  %.splatinsert1397 = insertelement <8 x i64> poison, i64 %4329, i64 0
  %.splat1398 = shufflevector <8 x i64> %.splatinsert1397, <8 x i64> poison, <8 x i32> zeroinitializer
  %4332 = mul <8 x i64> %.splat1398, splat (i64 32)
  %4333 = add <8 x i64> %4331, %4332
  %4334 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4330, 0
  %4335 = insertvalue { <8 x ptr>, <8 x i64> } %4334, <8 x i64> %4333, 1
  %4336 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4337 = extractvalue { <8 x ptr>, <8 x i64> } %4335, 1
  %4338 = extractelement <8 x ptr> %4336, i32 0
  %4339 = extractelement <8 x i64> %4337, i32 0
  %4340 = sub i64 %4339, 0
  %4341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4342 = select i1 %4341, i64 %4340, i64 0
  %private.contiguous.address1399 = getelementptr i8, ptr %4338, i64 %4342
  %private.contiguous.load1400 = load <8 x float>, ptr %private.contiguous.address1399, align 4
  %4343 = select <8 x i1> %95, <8 x float> %private.contiguous.load1400, <8 x float> zeroinitializer
  %4344 = add i64 %3683, 11
  %tile_snapshot.spill.load1401 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1401, 0
  %4346 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1401, 1
  %.splatinsert1402 = insertelement <8 x i64> poison, i64 %4344, i64 0
  %.splat1403 = shufflevector <8 x i64> %.splatinsert1402, <8 x i64> poison, <8 x i32> zeroinitializer
  %4347 = mul <8 x i64> %.splat1403, splat (i64 32)
  %4348 = add <8 x i64> %4346, %4347
  %4349 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4345, 0
  %4350 = insertvalue { <8 x ptr>, <8 x i64> } %4349, <8 x i64> %4348, 1
  %4351 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4352 = extractvalue { <8 x ptr>, <8 x i64> } %4350, 1
  %4353 = extractelement <8 x ptr> %4351, i32 0
  %4354 = extractelement <8 x i64> %4352, i32 0
  %4355 = sub i64 %4354, 0
  %4356 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4357 = select i1 %4356, i64 %4355, i64 0
  %private.contiguous.address1404 = getelementptr i8, ptr %4353, i64 %4357
  %private.contiguous.load1405 = load <8 x float>, ptr %private.contiguous.address1404, align 4
  %4358 = select <8 x i1> %95, <8 x float> %private.contiguous.load1405, <8 x float> zeroinitializer
  %4359 = add i64 528, %3528
  %tile_snapshot.spill.load1406 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1406, 0
  %4361 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1406, 1
  %.splatinsert1407 = insertelement <8 x i64> poison, i64 %4359, i64 0
  %.splat1408 = shufflevector <8 x i64> %.splatinsert1407, <8 x i64> poison, <8 x i32> zeroinitializer
  %4362 = mul <8 x i64> %.splat1408, splat (i64 4)
  %4363 = add <8 x i64> %4361, %4362
  %4364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4360, 0
  %4365 = insertvalue { <8 x ptr>, <8 x i64> } %4364, <8 x i64> %4363, 1
  %4366 = extractvalue { <8 x ptr>, <8 x i64> } %4365, 0
  %4367 = extractvalue { <8 x ptr>, <8 x i64> } %4365, 1
  %4368 = getelementptr i8, <8 x ptr> %4366, <8 x i64> %4367
  %4369 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4368, <8 x i1> %95, <8 x float> zeroinitializer)
  %4370 = add i64 528, %3563
  %tile_snapshot.spill.load1409 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1409, 0
  %4372 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1409, 1
  %.splatinsert1410 = insertelement <8 x i64> poison, i64 %4370, i64 0
  %.splat1411 = shufflevector <8 x i64> %.splatinsert1410, <8 x i64> poison, <8 x i32> zeroinitializer
  %4373 = mul <8 x i64> %.splat1411, splat (i64 4)
  %4374 = add <8 x i64> %4372, %4373
  %4375 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4371, 0
  %4376 = insertvalue { <8 x ptr>, <8 x i64> } %4375, <8 x i64> %4374, 1
  %4377 = extractvalue { <8 x ptr>, <8 x i64> } %4376, 0
  %4378 = extractvalue { <8 x ptr>, <8 x i64> } %4376, 1
  %4379 = getelementptr i8, <8 x ptr> %4377, <8 x i64> %4378
  %4380 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4379, <8 x i1> %95, <8 x float> zeroinitializer)
  %4381 = fmul <8 x float> %4343, %4369
  %4382 = fadd <8 x float> %4322, %4381
  %4383 = fmul <8 x float> %4343, %4380
  %4384 = fadd <8 x float> %4324, %4383
  %4385 = fmul <8 x float> %4358, %4369
  %4386 = fadd <8 x float> %4326, %4385
  %4387 = fmul <8 x float> %4358, %4380
  %4388 = fadd <8 x float> %4328, %4387
  %4389 = add i64 %3667, 12
  %tile_snapshot.spill.load1412 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1412, 0
  %4391 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1412, 1
  %.splatinsert1413 = insertelement <8 x i64> poison, i64 %4389, i64 0
  %.splat1414 = shufflevector <8 x i64> %.splatinsert1413, <8 x i64> poison, <8 x i32> zeroinitializer
  %4392 = mul <8 x i64> %.splat1414, splat (i64 32)
  %4393 = add <8 x i64> %4391, %4392
  %4394 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4390, 0
  %4395 = insertvalue { <8 x ptr>, <8 x i64> } %4394, <8 x i64> %4393, 1
  %4396 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4397 = extractvalue { <8 x ptr>, <8 x i64> } %4395, 1
  %4398 = extractelement <8 x ptr> %4396, i32 0
  %4399 = extractelement <8 x i64> %4397, i32 0
  %4400 = sub i64 %4399, 0
  %4401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4402 = select i1 %4401, i64 %4400, i64 0
  %private.contiguous.address1415 = getelementptr i8, ptr %4398, i64 %4402
  %private.contiguous.load1416 = load <8 x float>, ptr %private.contiguous.address1415, align 4
  %4403 = select <8 x i1> %95, <8 x float> %private.contiguous.load1416, <8 x float> zeroinitializer
  %4404 = add i64 %3683, 12
  %tile_snapshot.spill.load1417 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1417, 0
  %4406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1417, 1
  %.splatinsert1418 = insertelement <8 x i64> poison, i64 %4404, i64 0
  %.splat1419 = shufflevector <8 x i64> %.splatinsert1418, <8 x i64> poison, <8 x i32> zeroinitializer
  %4407 = mul <8 x i64> %.splat1419, splat (i64 32)
  %4408 = add <8 x i64> %4406, %4407
  %4409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4405, 0
  %4410 = insertvalue { <8 x ptr>, <8 x i64> } %4409, <8 x i64> %4408, 1
  %4411 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4412 = extractvalue { <8 x ptr>, <8 x i64> } %4410, 1
  %4413 = extractelement <8 x ptr> %4411, i32 0
  %4414 = extractelement <8 x i64> %4412, i32 0
  %4415 = sub i64 %4414, 0
  %4416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4417 = select i1 %4416, i64 %4415, i64 0
  %private.contiguous.address1420 = getelementptr i8, ptr %4413, i64 %4417
  %private.contiguous.load1421 = load <8 x float>, ptr %private.contiguous.address1420, align 4
  %4418 = select <8 x i1> %95, <8 x float> %private.contiguous.load1421, <8 x float> zeroinitializer
  %4419 = add i64 576, %3528
  %tile_snapshot.spill.load1422 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4420 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1422, 0
  %4421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1422, 1
  %.splatinsert1423 = insertelement <8 x i64> poison, i64 %4419, i64 0
  %.splat1424 = shufflevector <8 x i64> %.splatinsert1423, <8 x i64> poison, <8 x i32> zeroinitializer
  %4422 = mul <8 x i64> %.splat1424, splat (i64 4)
  %4423 = add <8 x i64> %4421, %4422
  %4424 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4420, 0
  %4425 = insertvalue { <8 x ptr>, <8 x i64> } %4424, <8 x i64> %4423, 1
  %4426 = extractvalue { <8 x ptr>, <8 x i64> } %4425, 0
  %4427 = extractvalue { <8 x ptr>, <8 x i64> } %4425, 1
  %4428 = getelementptr i8, <8 x ptr> %4426, <8 x i64> %4427
  %4429 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4428, <8 x i1> %95, <8 x float> zeroinitializer)
  %4430 = add i64 576, %3563
  %tile_snapshot.spill.load1425 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4431 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1425, 0
  %4432 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1425, 1
  %.splatinsert1426 = insertelement <8 x i64> poison, i64 %4430, i64 0
  %.splat1427 = shufflevector <8 x i64> %.splatinsert1426, <8 x i64> poison, <8 x i32> zeroinitializer
  %4433 = mul <8 x i64> %.splat1427, splat (i64 4)
  %4434 = add <8 x i64> %4432, %4433
  %4435 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4431, 0
  %4436 = insertvalue { <8 x ptr>, <8 x i64> } %4435, <8 x i64> %4434, 1
  %4437 = extractvalue { <8 x ptr>, <8 x i64> } %4436, 0
  %4438 = extractvalue { <8 x ptr>, <8 x i64> } %4436, 1
  %4439 = getelementptr i8, <8 x ptr> %4437, <8 x i64> %4438
  %4440 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4439, <8 x i1> %95, <8 x float> zeroinitializer)
  %4441 = fmul <8 x float> %4403, %4429
  %4442 = fadd <8 x float> %4382, %4441
  %4443 = fmul <8 x float> %4403, %4440
  %4444 = fadd <8 x float> %4384, %4443
  %4445 = fmul <8 x float> %4418, %4429
  %4446 = fadd <8 x float> %4386, %4445
  %4447 = fmul <8 x float> %4418, %4440
  %4448 = fadd <8 x float> %4388, %4447
  %4449 = add i64 %3667, 13
  %tile_snapshot.spill.load1428 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4450 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1428, 0
  %4451 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1428, 1
  %.splatinsert1429 = insertelement <8 x i64> poison, i64 %4449, i64 0
  %.splat1430 = shufflevector <8 x i64> %.splatinsert1429, <8 x i64> poison, <8 x i32> zeroinitializer
  %4452 = mul <8 x i64> %.splat1430, splat (i64 32)
  %4453 = add <8 x i64> %4451, %4452
  %4454 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4450, 0
  %4455 = insertvalue { <8 x ptr>, <8 x i64> } %4454, <8 x i64> %4453, 1
  %4456 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4457 = extractvalue { <8 x ptr>, <8 x i64> } %4455, 1
  %4458 = extractelement <8 x ptr> %4456, i32 0
  %4459 = extractelement <8 x i64> %4457, i32 0
  %4460 = sub i64 %4459, 0
  %4461 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4462 = select i1 %4461, i64 %4460, i64 0
  %private.contiguous.address1431 = getelementptr i8, ptr %4458, i64 %4462
  %private.contiguous.load1432 = load <8 x float>, ptr %private.contiguous.address1431, align 4
  %4463 = select <8 x i1> %95, <8 x float> %private.contiguous.load1432, <8 x float> zeroinitializer
  %4464 = add i64 %3683, 13
  %tile_snapshot.spill.load1433 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4465 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1433, 0
  %4466 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1433, 1
  %.splatinsert1434 = insertelement <8 x i64> poison, i64 %4464, i64 0
  %.splat1435 = shufflevector <8 x i64> %.splatinsert1434, <8 x i64> poison, <8 x i32> zeroinitializer
  %4467 = mul <8 x i64> %.splat1435, splat (i64 32)
  %4468 = add <8 x i64> %4466, %4467
  %4469 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4465, 0
  %4470 = insertvalue { <8 x ptr>, <8 x i64> } %4469, <8 x i64> %4468, 1
  %4471 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4472 = extractvalue { <8 x ptr>, <8 x i64> } %4470, 1
  %4473 = extractelement <8 x ptr> %4471, i32 0
  %4474 = extractelement <8 x i64> %4472, i32 0
  %4475 = sub i64 %4474, 0
  %4476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4477 = select i1 %4476, i64 %4475, i64 0
  %private.contiguous.address1436 = getelementptr i8, ptr %4473, i64 %4477
  %private.contiguous.load1437 = load <8 x float>, ptr %private.contiguous.address1436, align 4
  %4478 = select <8 x i1> %95, <8 x float> %private.contiguous.load1437, <8 x float> zeroinitializer
  %4479 = add i64 624, %3528
  %tile_snapshot.spill.load1438 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4480 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1438, 0
  %4481 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1438, 1
  %.splatinsert1439 = insertelement <8 x i64> poison, i64 %4479, i64 0
  %.splat1440 = shufflevector <8 x i64> %.splatinsert1439, <8 x i64> poison, <8 x i32> zeroinitializer
  %4482 = mul <8 x i64> %.splat1440, splat (i64 4)
  %4483 = add <8 x i64> %4481, %4482
  %4484 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4480, 0
  %4485 = insertvalue { <8 x ptr>, <8 x i64> } %4484, <8 x i64> %4483, 1
  %4486 = extractvalue { <8 x ptr>, <8 x i64> } %4485, 0
  %4487 = extractvalue { <8 x ptr>, <8 x i64> } %4485, 1
  %4488 = getelementptr i8, <8 x ptr> %4486, <8 x i64> %4487
  %4489 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4488, <8 x i1> %95, <8 x float> zeroinitializer)
  %4490 = add i64 624, %3563
  %tile_snapshot.spill.load1441 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1441, 0
  %4492 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1441, 1
  %.splatinsert1442 = insertelement <8 x i64> poison, i64 %4490, i64 0
  %.splat1443 = shufflevector <8 x i64> %.splatinsert1442, <8 x i64> poison, <8 x i32> zeroinitializer
  %4493 = mul <8 x i64> %.splat1443, splat (i64 4)
  %4494 = add <8 x i64> %4492, %4493
  %4495 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4491, 0
  %4496 = insertvalue { <8 x ptr>, <8 x i64> } %4495, <8 x i64> %4494, 1
  %4497 = extractvalue { <8 x ptr>, <8 x i64> } %4496, 0
  %4498 = extractvalue { <8 x ptr>, <8 x i64> } %4496, 1
  %4499 = getelementptr i8, <8 x ptr> %4497, <8 x i64> %4498
  %4500 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4499, <8 x i1> %95, <8 x float> zeroinitializer)
  %4501 = fmul <8 x float> %4463, %4489
  %4502 = fadd <8 x float> %4442, %4501
  %4503 = fmul <8 x float> %4463, %4500
  %4504 = fadd <8 x float> %4444, %4503
  %4505 = fmul <8 x float> %4478, %4489
  %4506 = fadd <8 x float> %4446, %4505
  %4507 = fmul <8 x float> %4478, %4500
  %4508 = fadd <8 x float> %4448, %4507
  %4509 = add i64 %3667, 14
  %tile_snapshot.spill.load1444 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1444, 0
  %4511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1444, 1
  %.splatinsert1445 = insertelement <8 x i64> poison, i64 %4509, i64 0
  %.splat1446 = shufflevector <8 x i64> %.splatinsert1445, <8 x i64> poison, <8 x i32> zeroinitializer
  %4512 = mul <8 x i64> %.splat1446, splat (i64 32)
  %4513 = add <8 x i64> %4511, %4512
  %4514 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4510, 0
  %4515 = insertvalue { <8 x ptr>, <8 x i64> } %4514, <8 x i64> %4513, 1
  %4516 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4517 = extractvalue { <8 x ptr>, <8 x i64> } %4515, 1
  %4518 = extractelement <8 x ptr> %4516, i32 0
  %4519 = extractelement <8 x i64> %4517, i32 0
  %4520 = sub i64 %4519, 0
  %4521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4522 = select i1 %4521, i64 %4520, i64 0
  %private.contiguous.address1447 = getelementptr i8, ptr %4518, i64 %4522
  %private.contiguous.load1448 = load <8 x float>, ptr %private.contiguous.address1447, align 4
  %4523 = select <8 x i1> %95, <8 x float> %private.contiguous.load1448, <8 x float> zeroinitializer
  %4524 = add i64 %3683, 14
  %tile_snapshot.spill.load1449 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4525 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1449, 0
  %4526 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1449, 1
  %.splatinsert1450 = insertelement <8 x i64> poison, i64 %4524, i64 0
  %.splat1451 = shufflevector <8 x i64> %.splatinsert1450, <8 x i64> poison, <8 x i32> zeroinitializer
  %4527 = mul <8 x i64> %.splat1451, splat (i64 32)
  %4528 = add <8 x i64> %4526, %4527
  %4529 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4525, 0
  %4530 = insertvalue { <8 x ptr>, <8 x i64> } %4529, <8 x i64> %4528, 1
  %4531 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4532 = extractvalue { <8 x ptr>, <8 x i64> } %4530, 1
  %4533 = extractelement <8 x ptr> %4531, i32 0
  %4534 = extractelement <8 x i64> %4532, i32 0
  %4535 = sub i64 %4534, 0
  %4536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4537 = select i1 %4536, i64 %4535, i64 0
  %private.contiguous.address1452 = getelementptr i8, ptr %4533, i64 %4537
  %private.contiguous.load1453 = load <8 x float>, ptr %private.contiguous.address1452, align 4
  %4538 = select <8 x i1> %95, <8 x float> %private.contiguous.load1453, <8 x float> zeroinitializer
  %4539 = add i64 672, %3528
  %tile_snapshot.spill.load1454 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4540 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1454, 0
  %4541 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1454, 1
  %.splatinsert1455 = insertelement <8 x i64> poison, i64 %4539, i64 0
  %.splat1456 = shufflevector <8 x i64> %.splatinsert1455, <8 x i64> poison, <8 x i32> zeroinitializer
  %4542 = mul <8 x i64> %.splat1456, splat (i64 4)
  %4543 = add <8 x i64> %4541, %4542
  %4544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4540, 0
  %4545 = insertvalue { <8 x ptr>, <8 x i64> } %4544, <8 x i64> %4543, 1
  %4546 = extractvalue { <8 x ptr>, <8 x i64> } %4545, 0
  %4547 = extractvalue { <8 x ptr>, <8 x i64> } %4545, 1
  %4548 = getelementptr i8, <8 x ptr> %4546, <8 x i64> %4547
  %4549 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4548, <8 x i1> %95, <8 x float> zeroinitializer)
  %4550 = add i64 672, %3563
  %tile_snapshot.spill.load1457 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4551 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1457, 0
  %4552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1457, 1
  %.splatinsert1458 = insertelement <8 x i64> poison, i64 %4550, i64 0
  %.splat1459 = shufflevector <8 x i64> %.splatinsert1458, <8 x i64> poison, <8 x i32> zeroinitializer
  %4553 = mul <8 x i64> %.splat1459, splat (i64 4)
  %4554 = add <8 x i64> %4552, %4553
  %4555 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4551, 0
  %4556 = insertvalue { <8 x ptr>, <8 x i64> } %4555, <8 x i64> %4554, 1
  %4557 = extractvalue { <8 x ptr>, <8 x i64> } %4556, 0
  %4558 = extractvalue { <8 x ptr>, <8 x i64> } %4556, 1
  %4559 = getelementptr i8, <8 x ptr> %4557, <8 x i64> %4558
  %4560 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4559, <8 x i1> %95, <8 x float> zeroinitializer)
  %4561 = fmul <8 x float> %4523, %4549
  %4562 = fadd <8 x float> %4502, %4561
  %4563 = fmul <8 x float> %4523, %4560
  %4564 = fadd <8 x float> %4504, %4563
  %4565 = fmul <8 x float> %4538, %4549
  %4566 = fadd <8 x float> %4506, %4565
  %4567 = fmul <8 x float> %4538, %4560
  %4568 = fadd <8 x float> %4508, %4567
  %4569 = add i64 %3667, 15
  %tile_snapshot.spill.load1460 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4570 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1460, 0
  %4571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1460, 1
  %.splatinsert1461 = insertelement <8 x i64> poison, i64 %4569, i64 0
  %.splat1462 = shufflevector <8 x i64> %.splatinsert1461, <8 x i64> poison, <8 x i32> zeroinitializer
  %4572 = mul <8 x i64> %.splat1462, splat (i64 32)
  %4573 = add <8 x i64> %4571, %4572
  %4574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4570, 0
  %4575 = insertvalue { <8 x ptr>, <8 x i64> } %4574, <8 x i64> %4573, 1
  %4576 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4577 = extractvalue { <8 x ptr>, <8 x i64> } %4575, 1
  %4578 = extractelement <8 x ptr> %4576, i32 0
  %4579 = extractelement <8 x i64> %4577, i32 0
  %4580 = sub i64 %4579, 0
  %4581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4582 = select i1 %4581, i64 %4580, i64 0
  %private.contiguous.address1463 = getelementptr i8, ptr %4578, i64 %4582
  %private.contiguous.load1464 = load <8 x float>, ptr %private.contiguous.address1463, align 4
  %4583 = select <8 x i1> %95, <8 x float> %private.contiguous.load1464, <8 x float> zeroinitializer
  %4584 = add i64 %3683, 15
  %tile_snapshot.spill.load1465 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill133, align 64
  %4585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1465, 0
  %4586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1465, 1
  %.splatinsert1466 = insertelement <8 x i64> poison, i64 %4584, i64 0
  %.splat1467 = shufflevector <8 x i64> %.splatinsert1466, <8 x i64> poison, <8 x i32> zeroinitializer
  %4587 = mul <8 x i64> %.splat1467, splat (i64 32)
  %4588 = add <8 x i64> %4586, %4587
  %4589 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4585, 0
  %4590 = insertvalue { <8 x ptr>, <8 x i64> } %4589, <8 x i64> %4588, 1
  %4591 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %4592 = extractvalue { <8 x ptr>, <8 x i64> } %4590, 1
  %4593 = extractelement <8 x ptr> %4591, i32 0
  %4594 = extractelement <8 x i64> %4592, i32 0
  %4595 = sub i64 %4594, 0
  %4596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4597 = select i1 %4596, i64 %4595, i64 0
  %private.contiguous.address1468 = getelementptr i8, ptr %4593, i64 %4597
  %private.contiguous.load1469 = load <8 x float>, ptr %private.contiguous.address1468, align 4
  %4598 = select <8 x i1> %95, <8 x float> %private.contiguous.load1469, <8 x float> zeroinitializer
  %4599 = add i64 720, %3528
  %tile_snapshot.spill.load1470 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4600 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1470, 0
  %4601 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1470, 1
  %.splatinsert1471 = insertelement <8 x i64> poison, i64 %4599, i64 0
  %.splat1472 = shufflevector <8 x i64> %.splatinsert1471, <8 x i64> poison, <8 x i32> zeroinitializer
  %4602 = mul <8 x i64> %.splat1472, splat (i64 4)
  %4603 = add <8 x i64> %4601, %4602
  %4604 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4600, 0
  %4605 = insertvalue { <8 x ptr>, <8 x i64> } %4604, <8 x i64> %4603, 1
  %4606 = extractvalue { <8 x ptr>, <8 x i64> } %4605, 0
  %4607 = extractvalue { <8 x ptr>, <8 x i64> } %4605, 1
  %4608 = getelementptr i8, <8 x ptr> %4606, <8 x i64> %4607
  %4609 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4608, <8 x i1> %95, <8 x float> zeroinitializer)
  %4610 = add i64 720, %3563
  %tile_snapshot.spill.load1473 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1473, 0
  %4612 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1473, 1
  %.splatinsert1474 = insertelement <8 x i64> poison, i64 %4610, i64 0
  %.splat1475 = shufflevector <8 x i64> %.splatinsert1474, <8 x i64> poison, <8 x i32> zeroinitializer
  %4613 = mul <8 x i64> %.splat1475, splat (i64 4)
  %4614 = add <8 x i64> %4612, %4613
  %4615 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4611, 0
  %4616 = insertvalue { <8 x ptr>, <8 x i64> } %4615, <8 x i64> %4614, 1
  %4617 = extractvalue { <8 x ptr>, <8 x i64> } %4616, 0
  %4618 = extractvalue { <8 x ptr>, <8 x i64> } %4616, 1
  %4619 = getelementptr i8, <8 x ptr> %4617, <8 x i64> %4618
  %4620 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4619, <8 x i1> %95, <8 x float> zeroinitializer)
  %4621 = fmul <8 x float> %4583, %4609
  %4622 = fadd <8 x float> %4562, %4621
  %4623 = fmul <8 x float> %4583, %4620
  %4624 = fadd <8 x float> %4564, %4623
  %4625 = fmul <8 x float> %4598, %4609
  %4626 = fadd <8 x float> %4566, %4625
  %4627 = fmul <8 x float> %4598, %4620
  %4628 = fadd <8 x float> %4568, %4627
  %tile_snapshot.spill.load1476 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %4629 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1476, 0
  %4630 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1476, 1
  %.splatinsert1477 = insertelement <8 x i64> poison, i64 %3527, i64 0
  %.splat1478 = shufflevector <8 x i64> %.splatinsert1477, <8 x i64> poison, <8 x i32> zeroinitializer
  %4631 = mul <8 x i64> %.splat1478, splat (i64 32)
  %4632 = add <8 x i64> %4630, %4631
  %4633 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4629, 0
  %4634 = insertvalue { <8 x ptr>, <8 x i64> } %4633, <8 x i64> %4632, 1
  %4635 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %4636 = extractvalue { <8 x ptr>, <8 x i64> } %4634, 1
  %4637 = extractelement <8 x ptr> %4635, i32 0
  %4638 = extractelement <8 x i64> %4636, i32 0
  %4639 = sub i64 %4638, 0
  %4640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4641 = select i1 %4640, i64 %4639, i64 0
  %private.contiguous.address1479 = getelementptr i8, ptr %4637, i64 %4641
  %private.contiguous.preserve1480 = load <8 x float>, ptr %private.contiguous.address1479, align 4
  %4642 = select <8 x i1> %95, <8 x float> %4622, <8 x float> %private.contiguous.preserve1480
  store <8 x float> %4642, ptr %private.contiguous.address1479, align 4
  %tile_snapshot.spill.load1481 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %4643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1481, 0
  %4644 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1481, 1
  %.splatinsert1482 = insertelement <8 x i64> poison, i64 %3562, i64 0
  %.splat1483 = shufflevector <8 x i64> %.splatinsert1482, <8 x i64> poison, <8 x i32> zeroinitializer
  %4645 = mul <8 x i64> %.splat1483, splat (i64 32)
  %4646 = add <8 x i64> %4644, %4645
  %4647 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4643, 0
  %4648 = insertvalue { <8 x ptr>, <8 x i64> } %4647, <8 x i64> %4646, 1
  %4649 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %4650 = extractvalue { <8 x ptr>, <8 x i64> } %4648, 1
  %4651 = extractelement <8 x ptr> %4649, i32 0
  %4652 = extractelement <8 x i64> %4650, i32 0
  %4653 = sub i64 %4652, 0
  %4654 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4655 = select i1 %4654, i64 %4653, i64 0
  %private.contiguous.address1484 = getelementptr i8, ptr %4651, i64 %4655
  %private.contiguous.preserve1485 = load <8 x float>, ptr %private.contiguous.address1484, align 4
  %4656 = select <8 x i1> %95, <8 x float> %4624, <8 x float> %private.contiguous.preserve1485
  store <8 x float> %4656, ptr %private.contiguous.address1484, align 4
  %tile_snapshot.spill.load1486 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %4657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1486, 0
  %4658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1486, 1
  %.splatinsert1487 = insertelement <8 x i64> poison, i64 %3597, i64 0
  %.splat1488 = shufflevector <8 x i64> %.splatinsert1487, <8 x i64> poison, <8 x i32> zeroinitializer
  %4659 = mul <8 x i64> %.splat1488, splat (i64 32)
  %4660 = add <8 x i64> %4658, %4659
  %4661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4657, 0
  %4662 = insertvalue { <8 x ptr>, <8 x i64> } %4661, <8 x i64> %4660, 1
  %4663 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %4664 = extractvalue { <8 x ptr>, <8 x i64> } %4662, 1
  %4665 = extractelement <8 x ptr> %4663, i32 0
  %4666 = extractelement <8 x i64> %4664, i32 0
  %4667 = sub i64 %4666, 0
  %4668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4669 = select i1 %4668, i64 %4667, i64 0
  %private.contiguous.address1489 = getelementptr i8, ptr %4665, i64 %4669
  %private.contiguous.preserve1490 = load <8 x float>, ptr %private.contiguous.address1489, align 4
  %4670 = select <8 x i1> %95, <8 x float> %4626, <8 x float> %private.contiguous.preserve1490
  store <8 x float> %4670, ptr %private.contiguous.address1489, align 4
  %tile_snapshot.spill.load1491 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %4671 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1491, 0
  %4672 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1491, 1
  %.splatinsert1492 = insertelement <8 x i64> poison, i64 %3632, i64 0
  %.splat1493 = shufflevector <8 x i64> %.splatinsert1492, <8 x i64> poison, <8 x i32> zeroinitializer
  %4673 = mul <8 x i64> %.splat1493, splat (i64 32)
  %4674 = add <8 x i64> %4672, %4673
  %4675 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4671, 0
  %4676 = insertvalue { <8 x ptr>, <8 x i64> } %4675, <8 x i64> %4674, 1
  %4677 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %4678 = extractvalue { <8 x ptr>, <8 x i64> } %4676, 1
  %4679 = extractelement <8 x ptr> %4677, i32 0
  %4680 = extractelement <8 x i64> %4678, i32 0
  %4681 = sub i64 %4680, 0
  %4682 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4683 = select i1 %4682, i64 %4681, i64 0
  %private.contiguous.address1494 = getelementptr i8, ptr %4679, i64 %4683
  %private.contiguous.preserve1495 = load <8 x float>, ptr %private.contiguous.address1494, align 4
  %4684 = select <8 x i1> %95, <8 x float> %4628, <8 x float> %private.contiguous.preserve1495
  store <8 x float> %4684, ptr %private.contiguous.address1494, align 4
  %.state1496 = load i64, ptr %.slot170, align 4
  %4685 = add i64 %.state1496, 1
  store i64 %4685, ptr %.slot170, align 4
  br label %direct.schedule.75

direct.schedule.77:                               ; preds = %direct.false1177
  %.state1497 = load i64, ptr %.slot168, align 4
  %4686 = add i64 %.state1497, 1
  store i64 %4686, ptr %.slot168, align 4
  br label %direct.schedule.73

direct.schedule.78:                               ; preds = %direct.false1173
  store i64 0, ptr %.slot171, align 4
  br label %direct.schedule.79

direct.schedule.79:                               ; preds = %direct.schedule.80, %direct.schedule.78
  %.state1498 = load i64, ptr %.slot171, align 4
  %4687 = icmp slt i64 %.state1498, 384
  br i1 %4687, label %direct.true1499, label %direct.false1500

direct.schedule.80:                               ; preds = %direct.true1499
  %tile_snapshot.spill.load1501 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill167, align 64
  %4688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1501, 0
  %4689 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1501, 1
  %.state1502 = load i64, ptr %.slot171, align 4
  %.splatinsert1503 = insertelement <8 x i64> poison, i64 %.state1502, i64 0
  %.splat1504 = shufflevector <8 x i64> %.splatinsert1503, <8 x i64> poison, <8 x i32> zeroinitializer
  %4690 = mul <8 x i64> %.splat1504, splat (i64 32)
  %4691 = add <8 x i64> %4689, %4690
  %4692 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4688, 0
  %4693 = insertvalue { <8 x ptr>, <8 x i64> } %4692, <8 x i64> %4691, 1
  %4694 = extractvalue { <8 x ptr>, <8 x i64> } %44, 0
  %4695 = extractvalue { <8 x ptr>, <8 x i64> } %4693, 1
  %4696 = extractelement <8 x ptr> %4694, i32 0
  %4697 = extractelement <8 x i64> %4695, i32 0
  %4698 = sub i64 %4697, 0
  %4699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4700 = select i1 %4699, i64 %4698, i64 0
  %private.contiguous.address1505 = getelementptr i8, ptr %4696, i64 %4700
  %private.contiguous.load1506 = load <8 x float>, ptr %private.contiguous.address1505, align 4
  %4701 = select <8 x i1> %95, <8 x float> %private.contiguous.load1506, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1507 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %4702 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1507, 0
  %4703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1507, 1
  %.state1508 = load i64, ptr %.slot171, align 4
  %.splatinsert1509 = insertelement <8 x i64> poison, i64 %.state1508, i64 0
  %.splat1510 = shufflevector <8 x i64> %.splatinsert1509, <8 x i64> poison, <8 x i32> zeroinitializer
  %4704 = mul <8 x i64> %.splat1510, splat (i64 32)
  %4705 = add <8 x i64> %4703, %4704
  %4706 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4702, 0
  %4707 = insertvalue { <8 x ptr>, <8 x i64> } %4706, <8 x i64> %4705, 1
  %4708 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %4709 = extractvalue { <8 x ptr>, <8 x i64> } %4707, 1
  %4710 = extractelement <8 x ptr> %4708, i32 0
  %4711 = extractelement <8 x i64> %4709, i32 0
  %4712 = sub i64 %4711, 0
  %4713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4714 = select i1 %4713, i64 %4712, i64 0
  %private.contiguous.address1511 = getelementptr i8, ptr %4710, i64 %4714
  %private.contiguous.preserve1512 = load <8 x float>, ptr %private.contiguous.address1511, align 4
  %4715 = select <8 x i1> %95, <8 x float> %4701, <8 x float> %private.contiguous.preserve1512
  store <8 x float> %4715, ptr %private.contiguous.address1511, align 4
  %.state1513 = load i64, ptr %.slot171, align 4
  %4716 = add i64 %.state1513, 1
  store i64 %4716, ptr %.slot171, align 4
  br label %direct.schedule.79

direct.schedule.81:                               ; preds = %direct.false1500
  store i64 0, ptr %.slot172, align 4
  br label %direct.schedule.82

direct.schedule.82:                               ; preds = %direct.schedule.83, %direct.schedule.81
  %.state1514 = load i64, ptr %.slot172, align 4
  %4717 = icmp slt i64 %.state1514, 384
  br i1 %4717, label %direct.true1515, label %direct.false1516

direct.schedule.83:                               ; preds = %direct.true1515
  %tile_snapshot.spill.load1517 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %4718 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1517, 0
  %4719 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1517, 1
  %.state1518 = load i64, ptr %.slot172, align 4
  %.splatinsert1519 = insertelement <8 x i64> poison, i64 %.state1518, i64 0
  %.splat1520 = shufflevector <8 x i64> %.splatinsert1519, <8 x i64> poison, <8 x i32> zeroinitializer
  %4720 = mul <8 x i64> %.splat1520, splat (i64 32)
  %4721 = add <8 x i64> %4719, %4720
  %4722 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4718, 0
  %4723 = insertvalue { <8 x ptr>, <8 x i64> } %4722, <8 x i64> %4721, 1
  %4724 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %4725 = extractvalue { <8 x ptr>, <8 x i64> } %4723, 1
  %4726 = extractelement <8 x ptr> %4724, i32 0
  %4727 = extractelement <8 x i64> %4725, i32 0
  %4728 = sub i64 %4727, 0
  %4729 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4730 = select i1 %4729, i64 %4728, i64 0
  %private.contiguous.address1521 = getelementptr i8, ptr %4726, i64 %4730
  %private.contiguous.load1522 = load <8 x float>, ptr %private.contiguous.address1521, align 4
  %4731 = select <8 x i1> %95, <8 x float> %private.contiguous.load1522, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1523 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %4732 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1523, 0
  %4733 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1523, 1
  %.state1524 = load i64, ptr %.slot172, align 4
  %.splatinsert1525 = insertelement <8 x i64> poison, i64 %.state1524, i64 0
  %.splat1526 = shufflevector <8 x i64> %.splatinsert1525, <8 x i64> poison, <8 x i32> zeroinitializer
  %4734 = mul <8 x i64> %.splat1526, splat (i64 32)
  %4735 = add <8 x i64> %4733, %4734
  %4736 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4732, 0
  %4737 = insertvalue { <8 x ptr>, <8 x i64> } %4736, <8 x i64> %4735, 1
  %4738 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %4739 = extractvalue { <8 x ptr>, <8 x i64> } %4737, 1
  %4740 = extractelement <8 x ptr> %4738, i32 0
  %4741 = extractelement <8 x i64> %4739, i32 0
  %4742 = sub i64 %4741, 0
  %4743 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4744 = select i1 %4743, i64 %4742, i64 0
  %private.contiguous.address1527 = getelementptr i8, ptr %4740, i64 %4744
  %private.contiguous.preserve1528 = load <8 x float>, ptr %private.contiguous.address1527, align 4
  %4745 = select <8 x i1> %95, <8 x float> %4731, <8 x float> %private.contiguous.preserve1528
  store <8 x float> %4745, ptr %private.contiguous.address1527, align 4
  %.state1529 = load i64, ptr %.slot172, align 4
  %4746 = add i64 %.state1529, 1
  store i64 %4746, ptr %.slot172, align 4
  br label %direct.schedule.82

direct.schedule.84:                               ; preds = %direct.false1516
  %.state1530 = load i64, ptr %.slot67, align 4
  %4747 = add i64 %.state1530, 1
  %.spill.load1531 = load <8 x float>, ptr %.spill115, align 32
  %.spill.load1532 = load <8 x float>, ptr %.spill116, align 32
  %.spill.load1533 = load <8 x float>, ptr %.spill117, align 32
  %.spill.load1534 = load <8 x float>, ptr %.spill118, align 32
  %.spill.load1535 = load <8 x float>, ptr %.spill119, align 32
  %.spill.load1536 = load <8 x float>, ptr %.spill120, align 32
  %.spill.load1537 = load <8 x float>, ptr %.spill121, align 32
  %.spill.load1538 = load <8 x float>, ptr %.spill122, align 32
  %.spill.load1539 = load <8 x float>, ptr %.spill159, align 32
  %.spill.load1540 = load <8 x float>, ptr %.spill160, align 32
  %.spill.load1541 = load <8 x float>, ptr %.spill161, align 32
  %.spill.load1542 = load <8 x float>, ptr %.spill162, align 32
  %.spill.load1543 = load <8 x float>, ptr %.spill163, align 32
  %.spill.load1544 = load <8 x float>, ptr %.spill164, align 32
  %.spill.load1545 = load <8 x float>, ptr %.spill165, align 32
  %.spill.load1546 = load <8 x float>, ptr %.spill166, align 32
  store i64 %4747, ptr %.slot67, align 4
  %4748 = load <8 x float>, ptr %.slot68, align 32
  %4749 = select <8 x i1> %95, <8 x float> %.spill.load1531, <8 x float> %4748
  store <8 x float> %4749, ptr %.slot68, align 32
  %4750 = load <8 x float>, ptr %.slot69, align 32
  %4751 = select <8 x i1> %95, <8 x float> %.spill.load1532, <8 x float> %4750
  store <8 x float> %4751, ptr %.slot69, align 32
  %4752 = load <8 x float>, ptr %.slot70, align 32
  %4753 = select <8 x i1> %95, <8 x float> %.spill.load1533, <8 x float> %4752
  store <8 x float> %4753, ptr %.slot70, align 32
  %4754 = load <8 x float>, ptr %.slot71, align 32
  %4755 = select <8 x i1> %95, <8 x float> %.spill.load1534, <8 x float> %4754
  store <8 x float> %4755, ptr %.slot71, align 32
  %4756 = load <8 x float>, ptr %.slot72, align 32
  %4757 = select <8 x i1> %95, <8 x float> %.spill.load1535, <8 x float> %4756
  store <8 x float> %4757, ptr %.slot72, align 32
  %4758 = load <8 x float>, ptr %.slot73, align 32
  %4759 = select <8 x i1> %95, <8 x float> %.spill.load1536, <8 x float> %4758
  store <8 x float> %4759, ptr %.slot73, align 32
  %4760 = load <8 x float>, ptr %.slot74, align 32
  %4761 = select <8 x i1> %95, <8 x float> %.spill.load1537, <8 x float> %4760
  store <8 x float> %4761, ptr %.slot74, align 32
  %4762 = load <8 x float>, ptr %.slot75, align 32
  %4763 = select <8 x i1> %95, <8 x float> %.spill.load1538, <8 x float> %4762
  store <8 x float> %4763, ptr %.slot75, align 32
  %4764 = load <8 x float>, ptr %.slot76, align 32
  %4765 = select <8 x i1> %95, <8 x float> %.spill.load1539, <8 x float> %4764
  store <8 x float> %4765, ptr %.slot76, align 32
  %4766 = load <8 x float>, ptr %.slot77, align 32
  %4767 = select <8 x i1> %95, <8 x float> %.spill.load1540, <8 x float> %4766
  store <8 x float> %4767, ptr %.slot77, align 32
  %4768 = load <8 x float>, ptr %.slot78, align 32
  %4769 = select <8 x i1> %95, <8 x float> %.spill.load1541, <8 x float> %4768
  store <8 x float> %4769, ptr %.slot78, align 32
  %4770 = load <8 x float>, ptr %.slot79, align 32
  %4771 = select <8 x i1> %95, <8 x float> %.spill.load1542, <8 x float> %4770
  store <8 x float> %4771, ptr %.slot79, align 32
  %4772 = load <8 x float>, ptr %.slot80, align 32
  %4773 = select <8 x i1> %95, <8 x float> %.spill.load1543, <8 x float> %4772
  store <8 x float> %4773, ptr %.slot80, align 32
  %4774 = load <8 x float>, ptr %.slot81, align 32
  %4775 = select <8 x i1> %95, <8 x float> %.spill.load1544, <8 x float> %4774
  store <8 x float> %4775, ptr %.slot81, align 32
  %4776 = load <8 x float>, ptr %.slot82, align 32
  %4777 = select <8 x i1> %95, <8 x float> %.spill.load1545, <8 x float> %4776
  store <8 x float> %4777, ptr %.slot82, align 32
  %4778 = load <8 x float>, ptr %.slot83, align 32
  %4779 = select <8 x i1> %95, <8 x float> %.spill.load1546, <8 x float> %4778
  store <8 x float> %4779, ptr %.slot83, align 32
  br label %direct.schedule.4

direct.schedule.85:                               ; preds = %direct.false240
  store i64 0, ptr %.slot173, align 4
  br label %direct.schedule.86

direct.schedule.86:                               ; preds = %direct.schedule.89, %direct.schedule.85
  %.state1547 = load i64, ptr %.slot173, align 4
  %4780 = icmp slt i64 %.state1547, 768
  br i1 %4780, label %direct.true1548, label %direct.false1549

direct.schedule.87:                               ; preds = %direct.true1548
  %.state1550 = load i64, ptr %.slot173, align 4
  %4781 = srem i64 %.state1550, 48
  %.state1551 = load i64, ptr %.slot173, align 4
  %4782 = sdiv i64 %.state1551, 48
  %.spill.load1552 = load i64, ptr %.spill63, align 4
  %4783 = add i64 %.spill.load1552, 0
  %.spill.load1553 = load <8 x i64>, ptr %.spill62, align 64
  %4784 = add <8 x i64> %.spill.load1553, zeroinitializer
  %4785 = mul i64 %4783, 2
  %.splatinsert1554 = insertelement <8 x i64> poison, i64 %4785, i64 0
  %.splat1555 = shufflevector <8 x i64> %.splatinsert1554, <8 x i64> poison, <8 x i32> zeroinitializer
  %4786 = add <8 x i64> %.splat1555, %4784
  %.spill.load1556 = load i64, ptr %.spill84, align 4
  %4787 = add i64 %.spill.load1556, %4782
  %4788 = mul <8 x i64> %4786, splat (i64 129)
  %.splatinsert1557 = insertelement <8 x i64> poison, i64 %4787, i64 0
  %.splat1558 = shufflevector <8 x i64> %.splatinsert1557, <8 x i64> poison, <8 x i32> zeroinitializer
  %4789 = add <8 x i64> %4788, %.splat1558
  %4790 = icmp sge i64 %4787, 0
  %4791 = and i1 true, %4790
  %4792 = icmp slt i64 %4787, 129
  %4793 = and i1 %4791, %4792
  %4794 = add i64 0, %4781
  %4795 = mul <8 x i64> %4789, splat (i64 48)
  %.splatinsert1559 = insertelement <8 x i64> poison, i64 %4794, i64 0
  %.splat1560 = shufflevector <8 x i64> %.splatinsert1559, <8 x i64> poison, <8 x i32> zeroinitializer
  %4796 = add <8 x i64> %4795, %.splat1560
  %4797 = load <8 x i64>, ptr %.spill174, align 64
  %4798 = select <8 x i1> %95, <8 x i64> %4796, <8 x i64> %4797
  store <8 x i64> %4798, ptr %.spill174, align 64
  br i1 %4793, label %direct.true1561, label %direct.false1562

direct.schedule.88:                               ; preds = %direct.true1561
  %.spill.load1563 = load <8 x i64>, ptr %.spill174, align 64
  %4799 = extractvalue { ptr, i64 } %65, 0
  %4800 = extractelement <8 x i64> %.spill.load1563, i32 0
  %4801 = mul i64 %4800, 4
  %4802 = getelementptr i8, ptr %4799, i64 %4801
  %4803 = load float, ptr %4802, align 4
  %.splatinsert1564 = insertelement <8 x float> poison, float %4803, i64 0
  %.splat1565 = shufflevector <8 x float> %.splatinsert1564, <8 x float> poison, <8 x i32> zeroinitializer
  %4804 = load <8 x float>, ptr %.slot175, align 32
  %4805 = select <8 x i1> %95, <8 x float> %.splat1565, <8 x float> %4804
  store <8 x float> %4805, ptr %.slot175, align 32
  br label %direct.schedule.89

direct.schedule.89:                               ; preds = %direct.schedule.88, %direct.false1562
  %tile_snapshot.spill.load1566 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill87, align 64
  %4806 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1566, 0
  %4807 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1566, 1
  %.state1567 = load i64, ptr %.slot173, align 4
  %.splatinsert1568 = insertelement <8 x i64> poison, i64 %.state1567, i64 0
  %.splat1569 = shufflevector <8 x i64> %.splatinsert1568, <8 x i64> poison, <8 x i32> zeroinitializer
  %4808 = mul <8 x i64> %.splat1569, splat (i64 4)
  %4809 = add <8 x i64> %4807, %4808
  %4810 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4806, 0
  %4811 = insertvalue { <8 x ptr>, <8 x i64> } %4810, <8 x i64> %4809, 1
  %.state1570 = load <8 x float>, ptr %.slot175, align 32
  %4812 = extractvalue { <8 x ptr>, <8 x i64> } %4811, 0
  %4813 = extractvalue { <8 x ptr>, <8 x i64> } %4811, 1
  %4814 = getelementptr i8, <8 x ptr> %4812, <8 x i64> %4813
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1570, <8 x ptr> align 1 %4814, <8 x i1> %95)
  %.state1571 = load i64, ptr %.slot173, align 4
  %4815 = add i64 %.state1571, 1
  store i64 %4815, ptr %.slot173, align 4
  br label %direct.schedule.86

direct.schedule.90:                               ; preds = %direct.false214
  store i64 0, ptr %.slot176, align 4
  br label %direct.schedule.91

direct.schedule.91:                               ; preds = %direct.schedule.94, %direct.schedule.90
  %.state1572 = load i64, ptr %.slot176, align 4
  %4816 = icmp slt i64 %.state1572, 512
  br i1 %4816, label %direct.true1573, label %direct.false1574

direct.schedule.92:                               ; preds = %direct.true1573
  %.state1575 = load i64, ptr %.slot176, align 4
  %4817 = srem i64 %.state1575, 32
  %.state1576 = load i64, ptr %.slot176, align 4
  %4818 = sdiv i64 %.state1576, 32
  %.spill.load1577 = load i64, ptr %.spill63, align 4
  %4819 = add i64 %.spill.load1577, 0
  %.spill.load1578 = load <8 x i64>, ptr %.spill62, align 64
  %4820 = add <8 x i64> %.spill.load1578, zeroinitializer
  %4821 = mul i64 %4819, 2
  %.splatinsert1579 = insertelement <8 x i64> poison, i64 %4821, i64 0
  %.splat1580 = shufflevector <8 x i64> %.splatinsert1579, <8 x i64> poison, <8 x i32> zeroinitializer
  %4822 = add <8 x i64> %.splat1580, %4820
  %.spill.load1581 = load i64, ptr %.spill84, align 4
  %4823 = add i64 %.spill.load1581, %4818
  %4824 = mul <8 x i64> %4822, splat (i64 129)
  %.splatinsert1582 = insertelement <8 x i64> poison, i64 %4823, i64 0
  %.splat1583 = shufflevector <8 x i64> %.splatinsert1582, <8 x i64> poison, <8 x i32> zeroinitializer
  %4825 = add <8 x i64> %4824, %.splat1583
  %4826 = icmp sge i64 %4823, 0
  %4827 = and i1 true, %4826
  %4828 = icmp slt i64 %4823, 129
  %4829 = and i1 %4827, %4828
  %4830 = add i64 0, %4817
  %4831 = mul <8 x i64> %4825, splat (i64 32)
  %.splatinsert1584 = insertelement <8 x i64> poison, i64 %4830, i64 0
  %.splat1585 = shufflevector <8 x i64> %.splatinsert1584, <8 x i64> poison, <8 x i32> zeroinitializer
  %4832 = add <8 x i64> %4831, %.splat1585
  %4833 = load <8 x i64>, ptr %.spill177, align 64
  %4834 = select <8 x i1> %95, <8 x i64> %4832, <8 x i64> %4833
  store <8 x i64> %4834, ptr %.spill177, align 64
  br i1 %4829, label %direct.true1586, label %direct.false1587

direct.schedule.93:                               ; preds = %direct.true1586
  %.spill.load1588 = load <8 x i64>, ptr %.spill177, align 64
  %4835 = extractvalue { ptr, i64 } %59, 0
  %4836 = extractelement <8 x i64> %.spill.load1588, i32 0
  %4837 = mul i64 %4836, 4
  %4838 = getelementptr i8, ptr %4835, i64 %4837
  %4839 = load float, ptr %4838, align 4
  %.splatinsert1589 = insertelement <8 x float> poison, float %4839, i64 0
  %.splat1590 = shufflevector <8 x float> %.splatinsert1589, <8 x float> poison, <8 x i32> zeroinitializer
  %4840 = load <8 x float>, ptr %.slot178, align 32
  %4841 = select <8 x i1> %95, <8 x float> %.splat1590, <8 x float> %4840
  store <8 x float> %4841, ptr %.slot178, align 32
  br label %direct.schedule.94

direct.schedule.94:                               ; preds = %direct.schedule.93, %direct.false1587
  %tile_snapshot.spill.load1591 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %4842 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1591, 0
  %4843 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1591, 1
  %.state1592 = load i64, ptr %.slot176, align 4
  %.splatinsert1593 = insertelement <8 x i64> poison, i64 %.state1592, i64 0
  %.splat1594 = shufflevector <8 x i64> %.splatinsert1593, <8 x i64> poison, <8 x i32> zeroinitializer
  %4844 = mul <8 x i64> %.splat1594, splat (i64 4)
  %4845 = add <8 x i64> %4843, %4844
  %4846 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4842, 0
  %4847 = insertvalue { <8 x ptr>, <8 x i64> } %4846, <8 x i64> %4845, 1
  %.state1595 = load <8 x float>, ptr %.slot178, align 32
  %4848 = extractvalue { <8 x ptr>, <8 x i64> } %4847, 0
  %4849 = extractvalue { <8 x ptr>, <8 x i64> } %4847, 1
  %4850 = getelementptr i8, <8 x ptr> %4848, <8 x i64> %4849
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1595, <8 x ptr> align 1 %4850, <8 x i1> %95)
  %.state1596 = load i64, ptr %.slot176, align 4
  %4851 = add i64 %.state1596, 1
  store i64 %4851, ptr %.slot176, align 4
  br label %direct.schedule.91

direct.schedule.95:                               ; preds = %direct.false211
  %4852 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill179, align 64
  %4853 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4854 = extractvalue { <8 x ptr>, <8 x i64> } %4852, 0
  %4855 = select <8 x i1> %95, <8 x ptr> %4853, <8 x ptr> %4854
  %4856 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %4857 = extractvalue { <8 x ptr>, <8 x i64> } %4852, 1
  %4858 = select <8 x i1> %95, <8 x i64> %4856, <8 x i64> %4857
  %4859 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4855, 0
  %4860 = insertvalue { <8 x ptr>, <8 x i64> } %4859, <8 x i64> %4858, 1
  store { <8 x ptr>, <8 x i64> } %4860, ptr %tile_snapshot.spill179, align 64
  %4861 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4862 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %4863 = add <8 x i64> %4862, zeroinitializer
  %4864 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4861, 0
  %4865 = insertvalue { <8 x ptr>, <8 x i64> } %4864, <8 x i64> %4863, 1
  %.state1597 = load <8 x float>, ptr %.slot76, align 32
  %4866 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4867 = extractvalue { <8 x ptr>, <8 x i64> } %4865, 1
  %4868 = extractelement <8 x ptr> %4866, i32 0
  %4869 = extractelement <8 x i64> %4867, i32 0
  %4870 = sub i64 %4869, 0
  %4871 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4872 = select i1 %4871, i64 %4870, i64 0
  %private.contiguous.address1598 = getelementptr i8, ptr %4868, i64 %4872
  %private.contiguous.preserve1599 = load <8 x float>, ptr %private.contiguous.address1598, align 4
  %4873 = select <8 x i1> %95, <8 x float> %.state1597, <8 x float> %private.contiguous.preserve1599
  store <8 x float> %4873, ptr %private.contiguous.address1598, align 4
  %4874 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4875 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %4876 = add <8 x i64> %4875, splat (i64 32)
  %4877 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4874, 0
  %4878 = insertvalue { <8 x ptr>, <8 x i64> } %4877, <8 x i64> %4876, 1
  %.state1600 = load <8 x float>, ptr %.slot77, align 32
  %4879 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4880 = extractvalue { <8 x ptr>, <8 x i64> } %4878, 1
  %4881 = extractelement <8 x ptr> %4879, i32 0
  %4882 = extractelement <8 x i64> %4880, i32 0
  %4883 = sub i64 %4882, 0
  %4884 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4885 = select i1 %4884, i64 %4883, i64 0
  %private.contiguous.address1601 = getelementptr i8, ptr %4881, i64 %4885
  %private.contiguous.preserve1602 = load <8 x float>, ptr %private.contiguous.address1601, align 4
  %4886 = select <8 x i1> %95, <8 x float> %.state1600, <8 x float> %private.contiguous.preserve1602
  store <8 x float> %4886, ptr %private.contiguous.address1601, align 4
  %4887 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4888 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %4889 = add <8 x i64> %4888, splat (i64 64)
  %4890 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4887, 0
  %4891 = insertvalue { <8 x ptr>, <8 x i64> } %4890, <8 x i64> %4889, 1
  %.state1603 = load <8 x float>, ptr %.slot78, align 32
  %4892 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4893 = extractvalue { <8 x ptr>, <8 x i64> } %4891, 1
  %4894 = extractelement <8 x ptr> %4892, i32 0
  %4895 = extractelement <8 x i64> %4893, i32 0
  %4896 = sub i64 %4895, 0
  %4897 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4898 = select i1 %4897, i64 %4896, i64 0
  %private.contiguous.address1604 = getelementptr i8, ptr %4894, i64 %4898
  %private.contiguous.preserve1605 = load <8 x float>, ptr %private.contiguous.address1604, align 4
  %4899 = select <8 x i1> %95, <8 x float> %.state1603, <8 x float> %private.contiguous.preserve1605
  store <8 x float> %4899, ptr %private.contiguous.address1604, align 4
  %4900 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4901 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %4902 = add <8 x i64> %4901, splat (i64 96)
  %4903 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4900, 0
  %4904 = insertvalue { <8 x ptr>, <8 x i64> } %4903, <8 x i64> %4902, 1
  %.state1606 = load <8 x float>, ptr %.slot79, align 32
  %4905 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4906 = extractvalue { <8 x ptr>, <8 x i64> } %4904, 1
  %4907 = extractelement <8 x ptr> %4905, i32 0
  %4908 = extractelement <8 x i64> %4906, i32 0
  %4909 = sub i64 %4908, 0
  %4910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4911 = select i1 %4910, i64 %4909, i64 0
  %private.contiguous.address1607 = getelementptr i8, ptr %4907, i64 %4911
  %private.contiguous.preserve1608 = load <8 x float>, ptr %private.contiguous.address1607, align 4
  %4912 = select <8 x i1> %95, <8 x float> %.state1606, <8 x float> %private.contiguous.preserve1608
  store <8 x float> %4912, ptr %private.contiguous.address1607, align 4
  %4913 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4914 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %4915 = add <8 x i64> %4914, splat (i64 128)
  %4916 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4913, 0
  %4917 = insertvalue { <8 x ptr>, <8 x i64> } %4916, <8 x i64> %4915, 1
  %.state1609 = load <8 x float>, ptr %.slot80, align 32
  %4918 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4919 = extractvalue { <8 x ptr>, <8 x i64> } %4917, 1
  %4920 = extractelement <8 x ptr> %4918, i32 0
  %4921 = extractelement <8 x i64> %4919, i32 0
  %4922 = sub i64 %4921, 0
  %4923 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4924 = select i1 %4923, i64 %4922, i64 0
  %private.contiguous.address1610 = getelementptr i8, ptr %4920, i64 %4924
  %private.contiguous.preserve1611 = load <8 x float>, ptr %private.contiguous.address1610, align 4
  %4925 = select <8 x i1> %95, <8 x float> %.state1609, <8 x float> %private.contiguous.preserve1611
  store <8 x float> %4925, ptr %private.contiguous.address1610, align 4
  %4926 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4927 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %4928 = add <8 x i64> %4927, splat (i64 160)
  %4929 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4926, 0
  %4930 = insertvalue { <8 x ptr>, <8 x i64> } %4929, <8 x i64> %4928, 1
  %.state1612 = load <8 x float>, ptr %.slot81, align 32
  %4931 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4932 = extractvalue { <8 x ptr>, <8 x i64> } %4930, 1
  %4933 = extractelement <8 x ptr> %4931, i32 0
  %4934 = extractelement <8 x i64> %4932, i32 0
  %4935 = sub i64 %4934, 0
  %4936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4937 = select i1 %4936, i64 %4935, i64 0
  %private.contiguous.address1613 = getelementptr i8, ptr %4933, i64 %4937
  %private.contiguous.preserve1614 = load <8 x float>, ptr %private.contiguous.address1613, align 4
  %4938 = select <8 x i1> %95, <8 x float> %.state1612, <8 x float> %private.contiguous.preserve1614
  store <8 x float> %4938, ptr %private.contiguous.address1613, align 4
  %4939 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4940 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %4941 = add <8 x i64> %4940, splat (i64 192)
  %4942 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4939, 0
  %4943 = insertvalue { <8 x ptr>, <8 x i64> } %4942, <8 x i64> %4941, 1
  %.state1615 = load <8 x float>, ptr %.slot82, align 32
  %4944 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4945 = extractvalue { <8 x ptr>, <8 x i64> } %4943, 1
  %4946 = extractelement <8 x ptr> %4944, i32 0
  %4947 = extractelement <8 x i64> %4945, i32 0
  %4948 = sub i64 %4947, 0
  %4949 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4950 = select i1 %4949, i64 %4948, i64 0
  %private.contiguous.address1616 = getelementptr i8, ptr %4946, i64 %4950
  %private.contiguous.preserve1617 = load <8 x float>, ptr %private.contiguous.address1616, align 4
  %4951 = select <8 x i1> %95, <8 x float> %.state1615, <8 x float> %private.contiguous.preserve1617
  store <8 x float> %4951, ptr %private.contiguous.address1616, align 4
  %4952 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4953 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %4954 = add <8 x i64> %4953, splat (i64 224)
  %4955 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4952, 0
  %4956 = insertvalue { <8 x ptr>, <8 x i64> } %4955, <8 x i64> %4954, 1
  %.state1618 = load <8 x float>, ptr %.slot83, align 32
  %4957 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %4958 = extractvalue { <8 x ptr>, <8 x i64> } %4956, 1
  %4959 = extractelement <8 x ptr> %4957, i32 0
  %4960 = extractelement <8 x i64> %4958, i32 0
  %4961 = sub i64 %4960, 0
  %4962 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4963 = select i1 %4962, i64 %4961, i64 0
  %private.contiguous.address1619 = getelementptr i8, ptr %4959, i64 %4963
  %private.contiguous.preserve1620 = load <8 x float>, ptr %private.contiguous.address1619, align 4
  %4964 = select <8 x i1> %95, <8 x float> %.state1618, <8 x float> %private.contiguous.preserve1620
  store <8 x float> %4964, ptr %private.contiguous.address1619, align 4
  store i64 0, ptr %.slot180, align 4
  br label %direct.schedule.96

direct.schedule.96:                               ; preds = %direct.schedule.97, %direct.schedule.95
  %.state1621 = load i64, ptr %.slot180, align 4
  %4965 = icmp slt i64 %.state1621, 384
  br i1 %4965, label %direct.true1622, label %direct.false1623

direct.schedule.97:                               ; preds = %direct.true1622
  %.state1624 = load i64, ptr %.slot180, align 4
  %4966 = srem i64 %.state1624, 48
  %.state1625 = load i64, ptr %.slot180, align 4
  %4967 = sdiv i64 %.state1625, 48
  %.spill.load1626 = load i64, ptr %.spill63, align 4
  %4968 = add i64 %.spill.load1626, 0
  %.spill.load1627 = load <8 x i64>, ptr %.spill, align 64
  %4969 = add <8 x i64> %.spill.load1627, zeroinitializer
  %4970 = mul i64 %4968, 4
  %.splatinsert1628 = insertelement <8 x i64> poison, i64 %4970, i64 0
  %.splat1629 = shufflevector <8 x i64> %.splatinsert1628, <8 x i64> poison, <8 x i32> zeroinitializer
  %4971 = add <8 x i64> %.splat1629, %4969
  %.spill.load1630 = load <8 x i64>, ptr %.spill61, align 64
  %.splatinsert1631 = insertelement <8 x i64> poison, i64 %4967, i64 0
  %.splat1632 = shufflevector <8 x i64> %.splatinsert1631, <8 x i64> poison, <8 x i32> zeroinitializer
  %4972 = add <8 x i64> %.spill.load1630, %.splat1632
  %4973 = mul <8 x i64> %4971, splat (i64 64)
  %4974 = add <8 x i64> %4973, %4972
  %4975 = add i64 0, %4966
  %4976 = mul <8 x i64> %4974, splat (i64 48)
  %.splatinsert1633 = insertelement <8 x i64> poison, i64 %4975, i64 0
  %.splat1634 = shufflevector <8 x i64> %.splatinsert1633, <8 x i64> poison, <8 x i32> zeroinitializer
  %4977 = add <8 x i64> %4976, %.splat1634
  %4978 = add i64 0, %4967
  %4979 = mul i64 %4978, 48
  %4980 = add i64 %4979, %4966
  %tile_snapshot.spill.load1635 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %4981 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1635, 0
  %4982 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1635, 1
  %.splatinsert1636 = insertelement <8 x i64> poison, i64 %4980, i64 0
  %.splat1637 = shufflevector <8 x i64> %.splatinsert1636, <8 x i64> poison, <8 x i32> zeroinitializer
  %4983 = mul <8 x i64> %.splat1637, splat (i64 32)
  %4984 = add <8 x i64> %4982, %4983
  %4985 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4981, 0
  %4986 = insertvalue { <8 x ptr>, <8 x i64> } %4985, <8 x i64> %4984, 1
  %4987 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %4988 = extractvalue { <8 x ptr>, <8 x i64> } %4986, 1
  %4989 = extractelement <8 x ptr> %4987, i32 0
  %4990 = extractelement <8 x i64> %4988, i32 0
  %4991 = sub i64 %4990, 0
  %4992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %4993 = select i1 %4992, i64 %4991, i64 0
  %private.contiguous.address1638 = getelementptr i8, ptr %4989, i64 %4993
  %private.contiguous.load1639 = load <8 x float>, ptr %private.contiguous.address1638, align 4
  %4994 = select <8 x i1> %95, <8 x float> %private.contiguous.load1639, <8 x float> zeroinitializer
  %tile_snapshot.spill.load1640 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill179, align 64
  %4995 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1640, 0
  %4996 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1640, 1
  %.splatinsert1641 = insertelement <8 x i64> poison, i64 %4978, i64 0
  %.splat1642 = shufflevector <8 x i64> %.splatinsert1641, <8 x i64> poison, <8 x i32> zeroinitializer
  %4997 = mul <8 x i64> %.splat1642, splat (i64 32)
  %4998 = add <8 x i64> %4996, %4997
  %4999 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4995, 0
  %5000 = insertvalue { <8 x ptr>, <8 x i64> } %4999, <8 x i64> %4998, 1
  %5001 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %5002 = extractvalue { <8 x ptr>, <8 x i64> } %5000, 1
  %5003 = extractelement <8 x ptr> %5001, i32 0
  %5004 = extractelement <8 x i64> %5002, i32 0
  %5005 = sub i64 %5004, 0
  %5006 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %95)
  %5007 = select i1 %5006, i64 %5005, i64 0
  %private.contiguous.address1643 = getelementptr i8, ptr %5003, i64 %5007
  %private.contiguous.load1644 = load <8 x float>, ptr %private.contiguous.address1643, align 4
  %5008 = select <8 x i1> %95, <8 x float> %private.contiguous.load1644, <8 x float> zeroinitializer
  %5009 = fdiv <8 x float> %4994, %5008
  %5010 = extractvalue { ptr, i64 } %71, 0
  %5011 = mul <8 x i64> %4977, splat (i64 4)
  %5012 = getelementptr i8, ptr %5010, <8 x i64> %5011
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5009, <8 x ptr> align 1 %5012, <8 x i1> %95)
  %.state1645 = load i64, ptr %.slot180, align 4
  %5013 = add i64 %.state1645, 1
  store i64 %5013, ptr %.slot180, align 4
  br label %direct.schedule.96

direct.schedule.98:                               ; preds = %direct.false1623
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

copy.active:                                      ; preds = %direct.schedule.0
  %5014 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5015 = extractelement <8 x ptr> %5014, i64 0
  %5016 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5017 = extractelement <8 x i64> %5016, i64 0
  %5018 = getelementptr i8, ptr %5015, i64 %5017
  %5019 = extractelement <8 x i64> %131, i64 0
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5019, ptr %5018)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active, %direct.schedule.0
  %5020 = extractelement <8 x i1> %95, i64 1
  br i1 %5020, label %copy.active191, label %copy.continue192

copy.active191:                                   ; preds = %copy.continue
  %5021 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5022 = extractelement <8 x ptr> %5021, i64 1
  %5023 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5024 = extractelement <8 x i64> %5023, i64 1
  %5025 = getelementptr i8, ptr %5022, i64 %5024
  %5026 = extractelement <8 x i64> %131, i64 1
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5026, ptr %5025)
  br label %copy.continue192

copy.continue192:                                 ; preds = %copy.active191, %copy.continue
  %5027 = extractelement <8 x i1> %95, i64 2
  br i1 %5027, label %copy.active193, label %copy.continue194

copy.active193:                                   ; preds = %copy.continue192
  %5028 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5029 = extractelement <8 x ptr> %5028, i64 2
  %5030 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5031 = extractelement <8 x i64> %5030, i64 2
  %5032 = getelementptr i8, ptr %5029, i64 %5031
  %5033 = extractelement <8 x i64> %131, i64 2
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5033, ptr %5032)
  br label %copy.continue194

copy.continue194:                                 ; preds = %copy.active193, %copy.continue192
  %5034 = extractelement <8 x i1> %95, i64 3
  br i1 %5034, label %copy.active195, label %copy.continue196

copy.active195:                                   ; preds = %copy.continue194
  %5035 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5036 = extractelement <8 x ptr> %5035, i64 3
  %5037 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5038 = extractelement <8 x i64> %5037, i64 3
  %5039 = getelementptr i8, ptr %5036, i64 %5038
  %5040 = extractelement <8 x i64> %131, i64 3
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5040, ptr %5039)
  br label %copy.continue196

copy.continue196:                                 ; preds = %copy.active195, %copy.continue194
  %5041 = extractelement <8 x i1> %95, i64 4
  br i1 %5041, label %copy.active197, label %copy.continue198

copy.active197:                                   ; preds = %copy.continue196
  %5042 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5043 = extractelement <8 x ptr> %5042, i64 4
  %5044 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5045 = extractelement <8 x i64> %5044, i64 4
  %5046 = getelementptr i8, ptr %5043, i64 %5045
  %5047 = extractelement <8 x i64> %131, i64 4
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5047, ptr %5046)
  br label %copy.continue198

copy.continue198:                                 ; preds = %copy.active197, %copy.continue196
  %5048 = extractelement <8 x i1> %95, i64 5
  br i1 %5048, label %copy.active199, label %copy.continue200

copy.active199:                                   ; preds = %copy.continue198
  %5049 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5050 = extractelement <8 x ptr> %5049, i64 5
  %5051 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5052 = extractelement <8 x i64> %5051, i64 5
  %5053 = getelementptr i8, ptr %5050, i64 %5052
  %5054 = extractelement <8 x i64> %131, i64 5
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5054, ptr %5053)
  br label %copy.continue200

copy.continue200:                                 ; preds = %copy.active199, %copy.continue198
  %5055 = extractelement <8 x i1> %95, i64 6
  br i1 %5055, label %copy.active201, label %copy.continue202

copy.active201:                                   ; preds = %copy.continue200
  %5056 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5057 = extractelement <8 x ptr> %5056, i64 6
  %5058 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5059 = extractelement <8 x i64> %5058, i64 6
  %5060 = getelementptr i8, ptr %5057, i64 %5059
  %5061 = extractelement <8 x i64> %131, i64 6
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5061, ptr %5060)
  br label %copy.continue202

copy.continue202:                                 ; preds = %copy.active201, %copy.continue200
  %5062 = extractelement <8 x i1> %95, i64 7
  br i1 %5062, label %copy.active203, label %copy.continue204

copy.active203:                                   ; preds = %copy.continue202
  %5063 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %5064 = extractelement <8 x ptr> %5063, i64 7
  %5065 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %5066 = extractelement <8 x i64> %5065, i64 7
  %5067 = getelementptr i8, ptr %5064, i64 %5066
  %5068 = extractelement <8 x i64> %131, i64 7
  call void @llm_attention.contiguous_copy(ptr %132, i64 %5068, ptr %5067)
  br label %copy.continue204

copy.continue204:                                 ; preds = %copy.active203, %copy.continue202
  %5069 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill65, align 64
  %5070 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %5071 = extractvalue { <8 x ptr>, <8 x i64> } %5069, 0
  %5072 = select <8 x i1> %95, <8 x ptr> %5070, <8 x ptr> %5071
  %5073 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %5074 = extractvalue { <8 x ptr>, <8 x i64> } %5069, 1
  %5075 = select <8 x i1> %95, <8 x i64> %5073, <8 x i64> %5074
  %5076 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5072, 0
  %5077 = insertvalue { <8 x ptr>, <8 x i64> } %5076, <8 x i64> %5075, 1
  store { <8 x ptr>, <8 x i64> } %5077, ptr %tile_snapshot.spill65, align 64
  %5078 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill66, align 64
  %5079 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %5080 = extractvalue { <8 x ptr>, <8 x i64> } %5078, 0
  %5081 = select <8 x i1> %95, <8 x ptr> %5079, <8 x ptr> %5080
  %5082 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %5083 = extractvalue { <8 x ptr>, <8 x i64> } %5078, 1
  %5084 = select <8 x i1> %95, <8 x i64> %5082, <8 x i64> %5083
  %5085 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5081, 0
  %5086 = insertvalue { <8 x ptr>, <8 x i64> } %5085, <8 x i64> %5084, 1
  store { <8 x ptr>, <8 x i64> } %5086, ptr %tile_snapshot.spill66, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true210:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false211:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.95

direct.true213:                                   ; preds = %direct.schedule.5
  br label %direct.schedule.6

direct.false214:                                  ; preds = %direct.schedule.5
  br label %direct.schedule.90

copy.active222:                                   ; preds = %direct.schedule.6
  %5087 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5088 = extractelement <8 x ptr> %5087, i64 0
  %5089 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5090 = extractelement <8 x i64> %5089, i64 0
  %5091 = getelementptr i8, ptr %5088, i64 %5090
  %5092 = extractelement <8 x i64> %203, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5092, ptr %5091)
  br label %copy.continue223

copy.continue223:                                 ; preds = %copy.active222, %direct.schedule.6
  %5093 = extractelement <8 x i1> %95, i64 1
  br i1 %5093, label %copy.active224, label %copy.continue225

copy.active224:                                   ; preds = %copy.continue223
  %5094 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5095 = extractelement <8 x ptr> %5094, i64 1
  %5096 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5097 = extractelement <8 x i64> %5096, i64 1
  %5098 = getelementptr i8, ptr %5095, i64 %5097
  %5099 = extractelement <8 x i64> %203, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5099, ptr %5098)
  br label %copy.continue225

copy.continue225:                                 ; preds = %copy.active224, %copy.continue223
  %5100 = extractelement <8 x i1> %95, i64 2
  br i1 %5100, label %copy.active226, label %copy.continue227

copy.active226:                                   ; preds = %copy.continue225
  %5101 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5102 = extractelement <8 x ptr> %5101, i64 2
  %5103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5104 = extractelement <8 x i64> %5103, i64 2
  %5105 = getelementptr i8, ptr %5102, i64 %5104
  %5106 = extractelement <8 x i64> %203, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5106, ptr %5105)
  br label %copy.continue227

copy.continue227:                                 ; preds = %copy.active226, %copy.continue225
  %5107 = extractelement <8 x i1> %95, i64 3
  br i1 %5107, label %copy.active228, label %copy.continue229

copy.active228:                                   ; preds = %copy.continue227
  %5108 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5109 = extractelement <8 x ptr> %5108, i64 3
  %5110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5111 = extractelement <8 x i64> %5110, i64 3
  %5112 = getelementptr i8, ptr %5109, i64 %5111
  %5113 = extractelement <8 x i64> %203, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5113, ptr %5112)
  br label %copy.continue229

copy.continue229:                                 ; preds = %copy.active228, %copy.continue227
  %5114 = extractelement <8 x i1> %95, i64 4
  br i1 %5114, label %copy.active230, label %copy.continue231

copy.active230:                                   ; preds = %copy.continue229
  %5115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5116 = extractelement <8 x ptr> %5115, i64 4
  %5117 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5118 = extractelement <8 x i64> %5117, i64 4
  %5119 = getelementptr i8, ptr %5116, i64 %5118
  %5120 = extractelement <8 x i64> %203, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5120, ptr %5119)
  br label %copy.continue231

copy.continue231:                                 ; preds = %copy.active230, %copy.continue229
  %5121 = extractelement <8 x i1> %95, i64 5
  br i1 %5121, label %copy.active232, label %copy.continue233

copy.active232:                                   ; preds = %copy.continue231
  %5122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5123 = extractelement <8 x ptr> %5122, i64 5
  %5124 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5125 = extractelement <8 x i64> %5124, i64 5
  %5126 = getelementptr i8, ptr %5123, i64 %5125
  %5127 = extractelement <8 x i64> %203, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5127, ptr %5126)
  br label %copy.continue233

copy.continue233:                                 ; preds = %copy.active232, %copy.continue231
  %5128 = extractelement <8 x i1> %95, i64 6
  br i1 %5128, label %copy.active234, label %copy.continue235

copy.active234:                                   ; preds = %copy.continue233
  %5129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5130 = extractelement <8 x ptr> %5129, i64 6
  %5131 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5132 = extractelement <8 x i64> %5131, i64 6
  %5133 = getelementptr i8, ptr %5130, i64 %5132
  %5134 = extractelement <8 x i64> %203, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5134, ptr %5133)
  br label %copy.continue235

copy.continue235:                                 ; preds = %copy.active234, %copy.continue233
  %5135 = extractelement <8 x i1> %95, i64 7
  br i1 %5135, label %copy.active236, label %copy.continue237

copy.active236:                                   ; preds = %copy.continue235
  %5136 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %5137 = extractelement <8 x ptr> %5136, i64 7
  %5138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %5139 = extractelement <8 x i64> %5138, i64 7
  %5140 = getelementptr i8, ptr %5137, i64 %5139
  %5141 = extractelement <8 x i64> %203, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %204, i64 %5141, ptr %5140)
  br label %copy.continue237

copy.continue237:                                 ; preds = %copy.active236, %copy.continue235
  br label %direct.schedule.7

direct.true239:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false240:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.85

copy.active249:                                   ; preds = %direct.schedule.8
  %5142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5143 = extractelement <8 x ptr> %5142, i64 0
  %5144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5145 = extractelement <8 x i64> %5144, i64 0
  %5146 = getelementptr i8, ptr %5143, i64 %5145
  %5147 = extractelement <8 x i64> %220, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5147, ptr %5146)
  br label %copy.continue250

copy.continue250:                                 ; preds = %copy.active249, %direct.schedule.8
  %5148 = extractelement <8 x i1> %95, i64 1
  br i1 %5148, label %copy.active251, label %copy.continue252

copy.active251:                                   ; preds = %copy.continue250
  %5149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5150 = extractelement <8 x ptr> %5149, i64 1
  %5151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5152 = extractelement <8 x i64> %5151, i64 1
  %5153 = getelementptr i8, ptr %5150, i64 %5152
  %5154 = extractelement <8 x i64> %220, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5154, ptr %5153)
  br label %copy.continue252

copy.continue252:                                 ; preds = %copy.active251, %copy.continue250
  %5155 = extractelement <8 x i1> %95, i64 2
  br i1 %5155, label %copy.active253, label %copy.continue254

copy.active253:                                   ; preds = %copy.continue252
  %5156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5157 = extractelement <8 x ptr> %5156, i64 2
  %5158 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5159 = extractelement <8 x i64> %5158, i64 2
  %5160 = getelementptr i8, ptr %5157, i64 %5159
  %5161 = extractelement <8 x i64> %220, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5161, ptr %5160)
  br label %copy.continue254

copy.continue254:                                 ; preds = %copy.active253, %copy.continue252
  %5162 = extractelement <8 x i1> %95, i64 3
  br i1 %5162, label %copy.active255, label %copy.continue256

copy.active255:                                   ; preds = %copy.continue254
  %5163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5164 = extractelement <8 x ptr> %5163, i64 3
  %5165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5166 = extractelement <8 x i64> %5165, i64 3
  %5167 = getelementptr i8, ptr %5164, i64 %5166
  %5168 = extractelement <8 x i64> %220, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5168, ptr %5167)
  br label %copy.continue256

copy.continue256:                                 ; preds = %copy.active255, %copy.continue254
  %5169 = extractelement <8 x i1> %95, i64 4
  br i1 %5169, label %copy.active257, label %copy.continue258

copy.active257:                                   ; preds = %copy.continue256
  %5170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5171 = extractelement <8 x ptr> %5170, i64 4
  %5172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5173 = extractelement <8 x i64> %5172, i64 4
  %5174 = getelementptr i8, ptr %5171, i64 %5173
  %5175 = extractelement <8 x i64> %220, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5175, ptr %5174)
  br label %copy.continue258

copy.continue258:                                 ; preds = %copy.active257, %copy.continue256
  %5176 = extractelement <8 x i1> %95, i64 5
  br i1 %5176, label %copy.active259, label %copy.continue260

copy.active259:                                   ; preds = %copy.continue258
  %5177 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5178 = extractelement <8 x ptr> %5177, i64 5
  %5179 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5180 = extractelement <8 x i64> %5179, i64 5
  %5181 = getelementptr i8, ptr %5178, i64 %5180
  %5182 = extractelement <8 x i64> %220, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5182, ptr %5181)
  br label %copy.continue260

copy.continue260:                                 ; preds = %copy.active259, %copy.continue258
  %5183 = extractelement <8 x i1> %95, i64 6
  br i1 %5183, label %copy.active261, label %copy.continue262

copy.active261:                                   ; preds = %copy.continue260
  %5184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5185 = extractelement <8 x ptr> %5184, i64 6
  %5186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5187 = extractelement <8 x i64> %5186, i64 6
  %5188 = getelementptr i8, ptr %5185, i64 %5187
  %5189 = extractelement <8 x i64> %220, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5189, ptr %5188)
  br label %copy.continue262

copy.continue262:                                 ; preds = %copy.active261, %copy.continue260
  %5190 = extractelement <8 x i1> %95, i64 7
  br i1 %5190, label %copy.active263, label %copy.continue264

copy.active263:                                   ; preds = %copy.continue262
  %5191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %5192 = extractelement <8 x ptr> %5191, i64 7
  %5193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %5194 = extractelement <8 x i64> %5193, i64 7
  %5195 = getelementptr i8, ptr %5192, i64 %5194
  %5196 = extractelement <8 x i64> %220, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %221, i64 %5196, ptr %5195)
  br label %copy.continue264

copy.continue264:                                 ; preds = %copy.active263, %copy.continue262
  br label %direct.schedule.9

direct.true266:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false267:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.15

direct.true270:                                   ; preds = %direct.schedule.12
  br label %direct.schedule.13

direct.false271:                                  ; preds = %direct.schedule.12
  br label %direct.schedule.14

direct.true817:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false818:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true839:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false840:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true859:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false860:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true871:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false872:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true883:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false884:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.30

direct.true895:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false896:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true907:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false908:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true919:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false920:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true931:                                   ; preds = %direct.schedule.40
  br label %direct.schedule.41

direct.false932:                                  ; preds = %direct.schedule.40
  br label %direct.schedule.42

direct.true943:                                   ; preds = %direct.schedule.43
  br label %direct.schedule.44

direct.false944:                                  ; preds = %direct.schedule.43
  br label %direct.schedule.45

direct.true1018:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false1019:                                 ; preds = %direct.schedule.46
  br label %direct.schedule.48

direct.true1060:                                  ; preds = %direct.schedule.49
  br label %direct.schedule.50

direct.false1061:                                 ; preds = %direct.schedule.49
  br label %direct.schedule.51

direct.true1072:                                  ; preds = %direct.schedule.52
  br label %direct.schedule.53

direct.false1073:                                 ; preds = %direct.schedule.52
  br label %direct.schedule.54

direct.true1084:                                  ; preds = %direct.schedule.55
  br label %direct.schedule.56

direct.false1085:                                 ; preds = %direct.schedule.55
  br label %direct.schedule.57

direct.true1096:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false1097:                                 ; preds = %direct.schedule.58
  br label %direct.schedule.60

direct.true1108:                                  ; preds = %direct.schedule.61
  br label %direct.schedule.62

direct.false1109:                                 ; preds = %direct.schedule.61
  br label %direct.schedule.63

direct.true1120:                                  ; preds = %direct.schedule.64
  br label %direct.schedule.65

direct.false1121:                                 ; preds = %direct.schedule.64
  br label %direct.schedule.66

direct.true1132:                                  ; preds = %direct.schedule.67
  br label %direct.schedule.68

direct.false1133:                                 ; preds = %direct.schedule.67
  br label %direct.schedule.69

direct.true1144:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false1145:                                 ; preds = %direct.schedule.70
  br label %direct.schedule.72

direct.true1172:                                  ; preds = %direct.schedule.73
  br label %direct.schedule.74

direct.false1173:                                 ; preds = %direct.schedule.73
  br label %direct.schedule.78

direct.true1176:                                  ; preds = %direct.schedule.75
  br label %direct.schedule.76

direct.false1177:                                 ; preds = %direct.schedule.75
  br label %direct.schedule.77

direct.true1499:                                  ; preds = %direct.schedule.79
  br label %direct.schedule.80

direct.false1500:                                 ; preds = %direct.schedule.79
  br label %direct.schedule.81

direct.true1515:                                  ; preds = %direct.schedule.82
  br label %direct.schedule.83

direct.false1516:                                 ; preds = %direct.schedule.82
  br label %direct.schedule.84

direct.true1548:                                  ; preds = %direct.schedule.86
  br label %direct.schedule.87

direct.false1549:                                 ; preds = %direct.schedule.86
  br label %direct.schedule.9

direct.true1561:                                  ; preds = %direct.schedule.87
  br label %direct.schedule.88

direct.false1562:                                 ; preds = %direct.schedule.87
  %5197 = load <8 x float>, ptr %.slot175, align 32
  %5198 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %5197
  store <8 x float> %5198, ptr %.slot175, align 32
  br label %direct.schedule.89

direct.true1573:                                  ; preds = %direct.schedule.91
  br label %direct.schedule.92

direct.false1574:                                 ; preds = %direct.schedule.91
  br label %direct.schedule.7

direct.true1586:                                  ; preds = %direct.schedule.92
  br label %direct.schedule.93

direct.false1587:                                 ; preds = %direct.schedule.92
  %5199 = load <8 x float>, ptr %.slot178, align 32
  %5200 = select <8 x i1> %95, <8 x float> zeroinitializer, <8 x float> %5199
  store <8 x float> %5200, ptr %.slot178, align 32
  br label %direct.schedule.94

direct.true1622:                                  ; preds = %direct.schedule.96
  br label %direct.schedule.97

direct.false1623:                                 ; preds = %direct.schedule.96
  br label %direct.schedule.98
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 64
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.1(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 128
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.2(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 192
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #3

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nounwind willreturn }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

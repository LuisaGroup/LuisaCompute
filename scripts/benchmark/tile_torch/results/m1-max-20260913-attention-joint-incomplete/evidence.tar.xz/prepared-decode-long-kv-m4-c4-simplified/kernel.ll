; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 4096
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 8192
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 12288
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 77824
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 143360
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 143872
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 144384
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 144896
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 145408
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 149504
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill41 = alloca i64, align 8
  store i64 0, ptr %.spill41, align 4
  %.spill42 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill42, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill43 = alloca i64, align 8
  store i64 0, ptr %.spill43, align 4
  %tile_snapshot.spill44 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill44, align 64
  %tile_snapshot.spill45 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill45, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.spill49 = alloca i64, align 8
  store i64 0, ptr %.spill49, align 4
  %tile_snapshot.spill50 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill50, align 64
  %.spill51 = alloca i1, align 1
  store i1 false, ptr %.spill51, align 1
  %tile_snapshot.spill52 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill52, align 64
  %.spill53 = alloca i1, align 1
  store i1 false, ptr %.spill53, align 1
  %.spill54 = alloca i1, align 1
  store i1 false, ptr %.spill54, align 1
  %.spill55 = alloca i1, align 1
  store i1 false, ptr %.spill55, align 1
  %.spill56 = alloca i1, align 1
  store i1 false, ptr %.spill56, align 1
  %.spill57 = alloca i1, align 1
  store i1 false, ptr %.spill57, align 1
  %.spill58 = alloca i1, align 1
  store i1 false, ptr %.spill58, align 1
  %.spill59 = alloca i1, align 1
  store i1 false, ptr %.spill59, align 1
  %.spill60 = alloca i1, align 1
  store i1 false, ptr %.spill60, align 1
  %.spill61 = alloca i1, align 1
  store i1 false, ptr %.spill61, align 1
  %.spill62 = alloca i1, align 1
  store i1 false, ptr %.spill62, align 1
  %.spill63 = alloca i1, align 1
  store i1 false, ptr %.spill63, align 1
  %.spill64 = alloca i1, align 1
  store i1 false, ptr %.spill64, align 1
  %.spill65 = alloca i1, align 1
  store i1 false, ptr %.spill65, align 1
  %.spill66 = alloca i1, align 1
  store i1 false, ptr %.spill66, align 1
  %.spill67 = alloca i1, align 1
  store i1 false, ptr %.spill67, align 1
  %.spill68 = alloca i1, align 1
  store i1 false, ptr %.spill68, align 1
  %.spill69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill69, align 32
  %.spill70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill70, align 32
  %.spill71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill71, align 32
  %.spill72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill72, align 32
  %.spill73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill73, align 32
  %.spill74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill74, align 32
  %.spill75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill75, align 32
  %.spill76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill76, align 32
  %.spill77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill77, align 32
  %.spill78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill78, align 32
  %.spill79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill79, align 32
  %.spill80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill80, align 32
  %.spill81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill81, align 32
  %.spill82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill82, align 32
  %.spill83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill83, align 32
  %.spill84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill84, align 32
  %tile_snapshot.spill85 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill85, align 64
  %.slot86 = alloca i64, align 8
  store i64 0, ptr %.slot86, align 4
  %.slot87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot87, align 32
  %.spill88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill88, align 32
  %.spill89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill89, align 32
  %tile_snapshot.spill90 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill90, align 64
  %.spill91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill91, align 32
  %.slot92 = alloca i64, align 8
  store i64 0, ptr %.slot92, align 4
  %.slot93 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot93, align 32
  %.spill94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill94, align 32
  %tile_snapshot.spill95 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill95, align 64
  %.slot96 = alloca i64, align 8
  store i64 0, ptr %.slot96, align 4
  %tile_snapshot.spill97 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill97, align 64
  %.slot98 = alloca i64, align 8
  store i64 0, ptr %.slot98, align 4
  %.slot99 = alloca i64, align 8
  store i64 0, ptr %.slot99, align 4
  %.slot100 = alloca i64, align 8
  store i64 0, ptr %.slot100, align 4
  %.spill101 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill101, align 64
  %.slot102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot102, align 32
  %.slot103 = alloca i64, align 8
  store i64 0, ptr %.slot103, align 4
  %.spill104 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill104, align 64
  %.slot105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot105, align 32
  %.slot106 = alloca i64, align 8
  store i64 0, ptr %.slot106, align 4
  %33 = getelementptr i8, ptr %argument_buffer, i64 0
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = getelementptr i8, ptr %argument_buffer, i64 16
  %40 = load ptr, ptr %39, align 16
  %41 = getelementptr i8, ptr %39, i64 8
  %42 = load i64, ptr %41, align 8
  %43 = insertvalue { ptr, i64 } poison, ptr %40, 0
  %44 = insertvalue { ptr, i64 } %43, i64 %42, 1
  %45 = getelementptr i8, ptr %argument_buffer, i64 32
  %46 = load ptr, ptr %45, align 16
  %47 = getelementptr i8, ptr %45, i64 8
  %48 = load i64, ptr %47, align 8
  %49 = insertvalue { ptr, i64 } poison, ptr %46, 0
  %50 = insertvalue { ptr, i64 } %49, i64 %48, 1
  %51 = getelementptr i8, ptr %argument_buffer, i64 48
  %52 = load ptr, ptr %51, align 16
  %53 = getelementptr i8, ptr %51, i64 8
  %54 = load i64, ptr %53, align 8
  %55 = insertvalue { ptr, i64 } poison, ptr %52, 0
  %56 = insertvalue { ptr, i64 } %55, i64 %54, 1
  %57 = load i32, ptr %launch_config, align 4
  %58 = getelementptr i8, ptr %launch_config, i64 12
  %59 = load i32, ptr %58, align 4
  %60 = getelementptr i8, ptr %launch_config, i64 4
  %61 = load i32, ptr %60, align 4
  %62 = getelementptr i8, ptr %launch_config, i64 16
  %63 = load i32, ptr %62, align 4
  %64 = getelementptr i8, ptr %launch_config, i64 8
  %65 = load i32, ptr %64, align 4
  %66 = getelementptr i8, ptr %launch_config, i64 20
  %67 = load i32, ptr %66, align 4
  %68 = getelementptr i8, ptr %launch_config, i64 36
  %69 = load i32, ptr %68, align 4
  %.splatinsert107 = insertelement <8 x i32> poison, i32 %69, i64 0
  %.splat108 = shufflevector <8 x i32> %.splatinsert107, <8 x i32> poison, <8 x i32> zeroinitializer
  %70 = add <8 x i32> %.splat108, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %71 = mul i32 %57, 32
  %.splatinsert109 = insertelement <8 x i32> poison, i32 %71, i64 0
  %.splat110 = shufflevector <8 x i32> %.splatinsert109, <8 x i32> poison, <8 x i32> zeroinitializer
  %72 = add <8 x i32> %.splat110, %70
  %73 = mul i32 %61, 1
  %.splatinsert111 = insertelement <8 x i32> poison, i32 %73, i64 0
  %.splat112 = shufflevector <8 x i32> %.splatinsert111, <8 x i32> poison, <8 x i32> zeroinitializer
  %74 = add <8 x i32> %.splat112, zeroinitializer
  %75 = mul i32 %65, 1
  %.splatinsert113 = insertelement <8 x i32> poison, i32 %75, i64 0
  %.splat114 = shufflevector <8 x i32> %.splatinsert113, <8 x i32> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i32> %.splat114, zeroinitializer
  %77 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %72, 0
  %78 = insertvalue [3 x <8 x i32>] %77, <8 x i32> %74, 1
  %79 = insertvalue [3 x <8 x i32>] %78, <8 x i32> %76, 2
  %.splatinsert115 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat116 = shufflevector <8 x i32> %.splatinsert115, <8 x i32> poison, <8 x i32> zeroinitializer
  %80 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat116
  %81 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  br i1 %81, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %82 = extractvalue [3 x <8 x i32>] %79, 0
  %83 = zext <8 x i32> %82 to <8 x i64>
  %84 = select <8 x i1> %80, <8 x i64> %83, <8 x i64> zeroinitializer
  %85 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %86 = sdiv <8 x i64> %84, %85
  %87 = load <8 x i64>, ptr %.spill, align 64
  %88 = select <8 x i1> %80, <8 x i64> %86, <8 x i64> %87
  store <8 x i64> %88, ptr %.spill, align 64
  store i64 0, ptr %.spill41, align 4
  %89 = select <8 x i1> %80, <8 x i64> %86, <8 x i64> zeroinitializer
  %90 = select <8 x i1> %80, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %91 = sdiv <8 x i64> %89, %90
  %92 = load <8 x i64>, ptr %.spill42, align 64
  %93 = select <8 x i1> %80, <8 x i64> %91, <8 x i64> %92
  store <8 x i64> %93, ptr %.spill42, align 64
  %94 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %94, 0
  %97 = select <8 x i1> %80, <8 x ptr> %95, <8 x ptr> %96
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %94, 1
  %100 = select <8 x i1> %80, <8 x i64> %98, <8 x i64> %99
  %101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %97, 0
  %102 = insertvalue { <8 x ptr>, <8 x i64> } %101, <8 x i64> %100, 1
  store { <8 x ptr>, <8 x i64> } %102, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.spill43, align 4
  %103 = add <8 x i64> zeroinitializer, %86
  %104 = mul <8 x i64> %103, splat (i64 1)
  %105 = add <8 x i64> %104, zeroinitializer
  %106 = mul <8 x i64> %105, splat (i64 128)
  %107 = add <8 x i64> %106, zeroinitializer
  %108 = extractvalue { ptr, i64 } %38, 0
  %109 = extractelement <8 x i1> %80, i64 0
  br i1 %109, label %copy.active, label %copy.continue

direct.schedule.1:                                ; preds = %direct.schedule.2, %copy.continue130
  %.state = load i64, ptr %.slot, align 4
  %110 = icmp slt i64 %.state, 128
  br i1 %110, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %112 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state131 = load i64, ptr %.slot, align 4
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %.state131, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %113 = mul <8 x i64> %.splat133, splat (i64 32)
  %114 = add <8 x i64> %112, %113
  %115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %111, 0
  %116 = insertvalue { <8 x ptr>, <8 x i64> } %115, <8 x i64> %114, 1
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %118 = extractvalue { <8 x ptr>, <8 x i64> } %116, 1
  %119 = extractelement <8 x ptr> %117, i32 0
  %120 = extractelement <8 x i64> %118, i32 0
  %121 = sub i64 %120, 0
  %122 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %123 = select i1 %122, i64 %121, i64 0
  %private.contiguous.address = getelementptr i8, ptr %119, i64 %123
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %124 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %124, ptr %private.contiguous.address, align 4
  %.state134 = load i64, ptr %.slot, align 4
  %125 = add i64 %.state134, 1
  store i64 %125, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store i64 0, ptr %.slot46, align 4
  %126 = load <8 x float>, ptr %.slot47, align 32
  %127 = select <8 x i1> %80, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %126
  store <8 x float> %127, ptr %.slot47, align 32
  %128 = load <8 x float>, ptr %.slot48, align 32
  %129 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %128
  store <8 x float> %129, ptr %.slot48, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.24, %direct.schedule.3
  %.state135 = load i64, ptr %.slot46, align 4
  %130 = icmp slt i64 %.state135, 513
  br i1 %130, label %direct.true136, label %direct.false137

direct.schedule.5:                                ; preds = %direct.true136
  %.state138 = load i64, ptr %.slot46, align 4
  %131 = sdiv i64 %.state138, 1
  %132 = mul i64 %131, 16
  store i64 %132, ptr %.spill49, align 4
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %80, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %80, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %tile_snapshot.spill50, align 64
  %142 = icmp sge i64 %132, 0
  %143 = and i1 true, %142
  %144 = icmp sle i64 %132, 8177
  %145 = and i1 %143, %144
  store i1 %145, ptr %.spill51, align 1
  br i1 %145, label %direct.true139, label %direct.false140

direct.schedule.6:                                ; preds = %direct.true139
  %.spill.load = load i64, ptr %.spill43, align 4
  %146 = mul i64 %.spill.load, 4
  %.splatinsert141 = insertelement <8 x i64> poison, i64 %146, i64 0
  %.splat142 = shufflevector <8 x i64> %.splatinsert141, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load143 = load <8 x i64>, ptr %.spill42, align 64
  %147 = add <8 x i64> %.splat142, %.spill.load143
  %148 = mul <8 x i64> %147, splat (i64 8193)
  %.spill.load144 = load i64, ptr %.spill49, align 4
  %.splatinsert145 = insertelement <8 x i64> poison, i64 %.spill.load144, i64 0
  %.splat146 = shufflevector <8 x i64> %.splatinsert145, <8 x i64> poison, <8 x i32> zeroinitializer
  %149 = add <8 x i64> %148, %.splat146
  %150 = mul <8 x i64> %149, splat (i64 128)
  %151 = add <8 x i64> %150, zeroinitializer
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  %152 = extractvalue { ptr, i64 } %44, 0
  %153 = extractelement <8 x i1> %80, i64 0
  br i1 %153, label %copy.active148, label %copy.continue149

direct.schedule.7:                                ; preds = %direct.false487, %copy.continue163
  %154 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %154, 0
  %157 = select <8 x i1> %80, <8 x ptr> %155, <8 x ptr> %156
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %154, 1
  %160 = select <8 x i1> %80, <8 x i64> %158, <8 x i64> %159
  %161 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %157, 0
  %162 = insertvalue { <8 x ptr>, <8 x i64> } %161, <8 x i64> %160, 1
  store { <8 x ptr>, <8 x i64> } %162, ptr %tile_snapshot.spill52, align 64
  %.spill.load164 = load i1, ptr %.spill51, align 1
  br i1 %.spill.load164, label %direct.true165, label %direct.false166

direct.schedule.8:                                ; preds = %direct.true165
  %.spill.load167 = load i64, ptr %.spill43, align 4
  %163 = mul i64 %.spill.load167, 4
  %.splatinsert168 = insertelement <8 x i64> poison, i64 %163, i64 0
  %.splat169 = shufflevector <8 x i64> %.splatinsert168, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load170 = load <8 x i64>, ptr %.spill42, align 64
  %164 = add <8 x i64> %.splat169, %.spill.load170
  %165 = mul <8 x i64> %164, splat (i64 8193)
  %.spill.load171 = load i64, ptr %.spill49, align 4
  %.splatinsert172 = insertelement <8 x i64> poison, i64 %.spill.load171, i64 0
  %.splat173 = shufflevector <8 x i64> %.splatinsert172, <8 x i64> poison, <8 x i32> zeroinitializer
  %166 = add <8 x i64> %165, %.splat173
  %167 = mul <8 x i64> %166, splat (i64 128)
  %168 = add <8 x i64> %167, zeroinitializer
  %tile_snapshot.spill.load174 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %169 = extractvalue { ptr, i64 } %50, 0
  %170 = extractelement <8 x i1> %80, i64 0
  br i1 %170, label %copy.active175, label %copy.continue176

direct.schedule.9:                                ; preds = %direct.false464, %copy.continue190
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %173 = add <8 x i64> %172, zeroinitializer
  %174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %171, 0
  %175 = insertvalue { <8 x ptr>, <8 x i64> } %174, <8 x i64> %173, 1
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %175, 0
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %175, 1
  %178 = getelementptr i8, <8 x ptr> %176, <8 x i64> %177
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %178, <8 x i1> %80)
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %181 = add <8 x i64> %180, splat (i64 4)
  %182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %179, 0
  %183 = insertvalue { <8 x ptr>, <8 x i64> } %182, <8 x i64> %181, 1
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %183, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %183, 1
  %186 = getelementptr i8, <8 x ptr> %184, <8 x i64> %185
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %186, <8 x i1> %80)
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %189 = add <8 x i64> %188, splat (i64 8)
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %191, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = getelementptr i8, <8 x ptr> %192, <8 x i64> %193
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %194, <8 x i1> %80)
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %197 = add <8 x i64> %196, splat (i64 12)
  %198 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %195, 0
  %199 = insertvalue { <8 x ptr>, <8 x i64> } %198, <8 x i64> %197, 1
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %199, 0
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %199, 1
  %202 = getelementptr i8, <8 x ptr> %200, <8 x i64> %201
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %202, <8 x i1> %80)
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %205 = add <8 x i64> %204, splat (i64 16)
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %203, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %207, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = getelementptr i8, <8 x ptr> %208, <8 x i64> %209
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %210, <8 x i1> %80)
  %211 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %213 = add <8 x i64> %212, splat (i64 20)
  %214 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %211, 0
  %215 = insertvalue { <8 x ptr>, <8 x i64> } %214, <8 x i64> %213, 1
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %215, 0
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %215, 1
  %218 = getelementptr i8, <8 x ptr> %216, <8 x i64> %217
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %218, <8 x i1> %80)
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %221 = add <8 x i64> %220, splat (i64 24)
  %222 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %219, 0
  %223 = insertvalue { <8 x ptr>, <8 x i64> } %222, <8 x i64> %221, 1
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %223, 0
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %223, 1
  %226 = getelementptr i8, <8 x ptr> %224, <8 x i64> %225
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %226, <8 x i1> %80)
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %229 = add <8 x i64> %228, splat (i64 28)
  %230 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %227, 0
  %231 = insertvalue { <8 x ptr>, <8 x i64> } %230, <8 x i64> %229, 1
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %231, 0
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %231, 1
  %234 = getelementptr i8, <8 x ptr> %232, <8 x i64> %233
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %234, <8 x i1> %80)
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %237 = add <8 x i64> %236, splat (i64 32)
  %238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %235, 0
  %239 = insertvalue { <8 x ptr>, <8 x i64> } %238, <8 x i64> %237, 1
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %239, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %242 = getelementptr i8, <8 x ptr> %240, <8 x i64> %241
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %242, <8 x i1> %80)
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %245 = add <8 x i64> %244, splat (i64 36)
  %246 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %243, 0
  %247 = insertvalue { <8 x ptr>, <8 x i64> } %246, <8 x i64> %245, 1
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %247, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %247, 1
  %250 = getelementptr i8, <8 x ptr> %248, <8 x i64> %249
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %250, <8 x i1> %80)
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %253 = add <8 x i64> %252, splat (i64 40)
  %254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %251, 0
  %255 = insertvalue { <8 x ptr>, <8 x i64> } %254, <8 x i64> %253, 1
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %255, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %255, 1
  %258 = getelementptr i8, <8 x ptr> %256, <8 x i64> %257
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %258, <8 x i1> %80)
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %261 = add <8 x i64> %260, splat (i64 44)
  %262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %259, 0
  %263 = insertvalue { <8 x ptr>, <8 x i64> } %262, <8 x i64> %261, 1
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %263, 0
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %263, 1
  %266 = getelementptr i8, <8 x ptr> %264, <8 x i64> %265
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %266, <8 x i1> %80)
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %269 = add <8 x i64> %268, splat (i64 48)
  %270 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %267, 0
  %271 = insertvalue { <8 x ptr>, <8 x i64> } %270, <8 x i64> %269, 1
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %271, 0
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %271, 1
  %274 = getelementptr i8, <8 x ptr> %272, <8 x i64> %273
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %274, <8 x i1> %80)
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %277 = add <8 x i64> %276, splat (i64 52)
  %278 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %275, 0
  %279 = insertvalue { <8 x ptr>, <8 x i64> } %278, <8 x i64> %277, 1
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %279, 0
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %279, 1
  %282 = getelementptr i8, <8 x ptr> %280, <8 x i64> %281
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %282, <8 x i1> %80)
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %285 = add <8 x i64> %284, splat (i64 56)
  %286 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %283, 0
  %287 = insertvalue { <8 x ptr>, <8 x i64> } %286, <8 x i64> %285, 1
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %287, 0
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %287, 1
  %290 = getelementptr i8, <8 x ptr> %288, <8 x i64> %289
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %290, <8 x i1> %80)
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %293 = add <8 x i64> %292, splat (i64 60)
  %294 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %291, 0
  %295 = insertvalue { <8 x ptr>, <8 x i64> } %294, <8 x i64> %293, 1
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %295, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %295, 1
  %298 = getelementptr i8, <8 x ptr> %296, <8 x i64> %297
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %298, <8 x i1> %80)
  %tile_snapshot.spill.load191 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  %299 = extractelement <8 x i1> %80, i64 0
  br i1 %299, label %mma.active, label %mma.continue

direct.schedule.10:                               ; preds = %direct.schedule.11, %mma.continue206
  %.state288 = load i64, ptr %.slot86, align 4
  %300 = icmp slt i64 %.state288, 16
  br i1 %300, label %direct.true289, label %direct.false290

direct.schedule.11:                               ; preds = %direct.true289
  %.state291 = load i64, ptr %.slot86, align 4
  %301 = sdiv i64 %.state291, 1
  %.spill.load292 = load i64, ptr %.spill43, align 4
  %302 = mul i64 %.spill.load292, 1
  %303 = add i64 %302, 0
  %304 = mul i64 %303, 1
  %305 = add i64 %304, 0
  %306 = mul i64 %305, 16
  %307 = add i64 %306, %301
  %tile_snapshot.spill.load293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 1
  %.splatinsert294 = insertelement <8 x i64> poison, i64 %307, i64 0
  %.splat295 = shufflevector <8 x i64> %.splatinsert294, <8 x i64> poison, <8 x i32> zeroinitializer
  %310 = mul <8 x i64> %.splat295, splat (i64 32)
  %311 = add <8 x i64> %309, %310
  %312 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %308, 0
  %313 = insertvalue { <8 x ptr>, <8 x i64> } %312, <8 x i64> %311, 1
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %316 = extractelement <8 x ptr> %314, i32 0
  %317 = extractelement <8 x i64> %315, i32 0
  %318 = sub i64 %317, 0
  %319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %320 = select i1 %319, i64 %318, i64 0
  %private.contiguous.address296 = getelementptr i8, ptr %316, i64 %320
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address296, align 4
  %321 = select <8 x i1> %80, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.state297 = load <8 x float>, ptr %.slot87, align 32
  %322 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state297, <8 x float> %321)
  %.state298 = load i64, ptr %.slot86, align 4
  %323 = add i64 %.state298, 1
  store i64 %323, ptr %.slot86, align 4
  %324 = load <8 x float>, ptr %.slot87, align 32
  %325 = select <8 x i1> %80, <8 x float> %322, <8 x float> %324
  store <8 x float> %325, ptr %.slot87, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false290
  %.state299 = load <8 x float>, ptr %.slot47, align 32
  %.state300 = load <8 x float>, ptr %.slot87, align 32
  %326 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state299, <8 x float> %.state300)
  %327 = load <8 x float>, ptr %.spill88, align 32
  %328 = select <8 x i1> %80, <8 x float> %326, <8 x float> %327
  store <8 x float> %328, ptr %.spill88, align 32
  %.state301 = load <8 x float>, ptr %.slot47, align 32
  %329 = fsub <8 x float> %.state301, %326
  %330 = select <8 x i1> %80, <8 x float> %329, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %330)
  %331 = load <8 x float>, ptr %.spill89, align 32
  %332 = select <8 x i1> %80, <8 x float> %native.exp, <8 x float> %331
  store <8 x float> %332, ptr %.spill89, align 32
  %.spill.load302 = load <8 x float>, ptr %.spill69, align 32
  %333 = fsub <8 x float> %.spill.load302, %326
  %.spill.load303 = load <8 x float>, ptr %.spill70, align 32
  %334 = fsub <8 x float> %.spill.load303, %326
  %.spill.load304 = load <8 x float>, ptr %.spill71, align 32
  %335 = fsub <8 x float> %.spill.load304, %326
  %.spill.load305 = load <8 x float>, ptr %.spill72, align 32
  %336 = fsub <8 x float> %.spill.load305, %326
  %.spill.load306 = load <8 x float>, ptr %.spill73, align 32
  %337 = fsub <8 x float> %.spill.load306, %326
  %.spill.load307 = load <8 x float>, ptr %.spill74, align 32
  %338 = fsub <8 x float> %.spill.load307, %326
  %.spill.load308 = load <8 x float>, ptr %.spill75, align 32
  %339 = fsub <8 x float> %.spill.load308, %326
  %.spill.load309 = load <8 x float>, ptr %.spill76, align 32
  %340 = fsub <8 x float> %.spill.load309, %326
  %.spill.load310 = load <8 x float>, ptr %.spill77, align 32
  %341 = fsub <8 x float> %.spill.load310, %326
  %.spill.load311 = load <8 x float>, ptr %.spill78, align 32
  %342 = fsub <8 x float> %.spill.load311, %326
  %.spill.load312 = load <8 x float>, ptr %.spill79, align 32
  %343 = fsub <8 x float> %.spill.load312, %326
  %.spill.load313 = load <8 x float>, ptr %.spill80, align 32
  %344 = fsub <8 x float> %.spill.load313, %326
  %.spill.load314 = load <8 x float>, ptr %.spill81, align 32
  %345 = fsub <8 x float> %.spill.load314, %326
  %.spill.load315 = load <8 x float>, ptr %.spill82, align 32
  %346 = fsub <8 x float> %.spill.load315, %326
  %.spill.load316 = load <8 x float>, ptr %.spill83, align 32
  %347 = fsub <8 x float> %.spill.load316, %326
  %.spill.load317 = load <8 x float>, ptr %.spill84, align 32
  %348 = fsub <8 x float> %.spill.load317, %326
  %349 = select <8 x i1> %80, <8 x float> %333, <8 x float> zeroinitializer
  %native.exp318 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %349)
  %350 = select <8 x i1> %80, <8 x float> %334, <8 x float> zeroinitializer
  %native.exp319 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %350)
  %351 = select <8 x i1> %80, <8 x float> %335, <8 x float> zeroinitializer
  %native.exp320 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %351)
  %352 = select <8 x i1> %80, <8 x float> %336, <8 x float> zeroinitializer
  %native.exp321 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %352)
  %353 = select <8 x i1> %80, <8 x float> %337, <8 x float> zeroinitializer
  %native.exp322 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %353)
  %354 = select <8 x i1> %80, <8 x float> %338, <8 x float> zeroinitializer
  %native.exp323 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %354)
  %355 = select <8 x i1> %80, <8 x float> %339, <8 x float> zeroinitializer
  %native.exp324 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %355)
  %356 = select <8 x i1> %80, <8 x float> %340, <8 x float> zeroinitializer
  %native.exp325 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %356)
  %357 = select <8 x i1> %80, <8 x float> %341, <8 x float> zeroinitializer
  %native.exp326 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %357)
  %358 = select <8 x i1> %80, <8 x float> %342, <8 x float> zeroinitializer
  %native.exp327 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %358)
  %359 = select <8 x i1> %80, <8 x float> %343, <8 x float> zeroinitializer
  %native.exp328 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %359)
  %360 = select <8 x i1> %80, <8 x float> %344, <8 x float> zeroinitializer
  %native.exp329 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %360)
  %361 = select <8 x i1> %80, <8 x float> %345, <8 x float> zeroinitializer
  %native.exp330 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %361)
  %362 = select <8 x i1> %80, <8 x float> %346, <8 x float> zeroinitializer
  %native.exp331 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %362)
  %363 = select <8 x i1> %80, <8 x float> %347, <8 x float> zeroinitializer
  %native.exp332 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %363)
  %364 = select <8 x i1> %80, <8 x float> %348, <8 x float> zeroinitializer
  %native.exp333 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %364)
  %.spill.load334 = load i1, ptr %.spill53, align 1
  %.splatinsert335 = insertelement <8 x i1> poison, i1 %.spill.load334, i64 0
  %.splat336 = shufflevector <8 x i1> %.splatinsert335, <8 x i1> poison, <8 x i32> zeroinitializer
  %365 = select <8 x i1> %.splat336, <8 x float> %native.exp318, <8 x float> zeroinitializer
  %.spill.load337 = load i1, ptr %.spill54, align 1
  %.splatinsert338 = insertelement <8 x i1> poison, i1 %.spill.load337, i64 0
  %.splat339 = shufflevector <8 x i1> %.splatinsert338, <8 x i1> poison, <8 x i32> zeroinitializer
  %366 = select <8 x i1> %.splat339, <8 x float> %native.exp319, <8 x float> zeroinitializer
  %.spill.load340 = load i1, ptr %.spill55, align 1
  %.splatinsert341 = insertelement <8 x i1> poison, i1 %.spill.load340, i64 0
  %.splat342 = shufflevector <8 x i1> %.splatinsert341, <8 x i1> poison, <8 x i32> zeroinitializer
  %367 = select <8 x i1> %.splat342, <8 x float> %native.exp320, <8 x float> zeroinitializer
  %.spill.load343 = load i1, ptr %.spill56, align 1
  %.splatinsert344 = insertelement <8 x i1> poison, i1 %.spill.load343, i64 0
  %.splat345 = shufflevector <8 x i1> %.splatinsert344, <8 x i1> poison, <8 x i32> zeroinitializer
  %368 = select <8 x i1> %.splat345, <8 x float> %native.exp321, <8 x float> zeroinitializer
  %.spill.load346 = load i1, ptr %.spill57, align 1
  %.splatinsert347 = insertelement <8 x i1> poison, i1 %.spill.load346, i64 0
  %.splat348 = shufflevector <8 x i1> %.splatinsert347, <8 x i1> poison, <8 x i32> zeroinitializer
  %369 = select <8 x i1> %.splat348, <8 x float> %native.exp322, <8 x float> zeroinitializer
  %.spill.load349 = load i1, ptr %.spill58, align 1
  %.splatinsert350 = insertelement <8 x i1> poison, i1 %.spill.load349, i64 0
  %.splat351 = shufflevector <8 x i1> %.splatinsert350, <8 x i1> poison, <8 x i32> zeroinitializer
  %370 = select <8 x i1> %.splat351, <8 x float> %native.exp323, <8 x float> zeroinitializer
  %.spill.load352 = load i1, ptr %.spill59, align 1
  %.splatinsert353 = insertelement <8 x i1> poison, i1 %.spill.load352, i64 0
  %.splat354 = shufflevector <8 x i1> %.splatinsert353, <8 x i1> poison, <8 x i32> zeroinitializer
  %371 = select <8 x i1> %.splat354, <8 x float> %native.exp324, <8 x float> zeroinitializer
  %.spill.load355 = load i1, ptr %.spill60, align 1
  %.splatinsert356 = insertelement <8 x i1> poison, i1 %.spill.load355, i64 0
  %.splat357 = shufflevector <8 x i1> %.splatinsert356, <8 x i1> poison, <8 x i32> zeroinitializer
  %372 = select <8 x i1> %.splat357, <8 x float> %native.exp325, <8 x float> zeroinitializer
  %.spill.load358 = load i1, ptr %.spill61, align 1
  %.splatinsert359 = insertelement <8 x i1> poison, i1 %.spill.load358, i64 0
  %.splat360 = shufflevector <8 x i1> %.splatinsert359, <8 x i1> poison, <8 x i32> zeroinitializer
  %373 = select <8 x i1> %.splat360, <8 x float> %native.exp326, <8 x float> zeroinitializer
  %.spill.load361 = load i1, ptr %.spill62, align 1
  %.splatinsert362 = insertelement <8 x i1> poison, i1 %.spill.load361, i64 0
  %.splat363 = shufflevector <8 x i1> %.splatinsert362, <8 x i1> poison, <8 x i32> zeroinitializer
  %374 = select <8 x i1> %.splat363, <8 x float> %native.exp327, <8 x float> zeroinitializer
  %.spill.load364 = load i1, ptr %.spill63, align 1
  %.splatinsert365 = insertelement <8 x i1> poison, i1 %.spill.load364, i64 0
  %.splat366 = shufflevector <8 x i1> %.splatinsert365, <8 x i1> poison, <8 x i32> zeroinitializer
  %375 = select <8 x i1> %.splat366, <8 x float> %native.exp328, <8 x float> zeroinitializer
  %.spill.load367 = load i1, ptr %.spill64, align 1
  %.splatinsert368 = insertelement <8 x i1> poison, i1 %.spill.load367, i64 0
  %.splat369 = shufflevector <8 x i1> %.splatinsert368, <8 x i1> poison, <8 x i32> zeroinitializer
  %376 = select <8 x i1> %.splat369, <8 x float> %native.exp329, <8 x float> zeroinitializer
  %.spill.load370 = load i1, ptr %.spill65, align 1
  %.splatinsert371 = insertelement <8 x i1> poison, i1 %.spill.load370, i64 0
  %.splat372 = shufflevector <8 x i1> %.splatinsert371, <8 x i1> poison, <8 x i32> zeroinitializer
  %377 = select <8 x i1> %.splat372, <8 x float> %native.exp330, <8 x float> zeroinitializer
  %.spill.load373 = load i1, ptr %.spill66, align 1
  %.splatinsert374 = insertelement <8 x i1> poison, i1 %.spill.load373, i64 0
  %.splat375 = shufflevector <8 x i1> %.splatinsert374, <8 x i1> poison, <8 x i32> zeroinitializer
  %378 = select <8 x i1> %.splat375, <8 x float> %native.exp331, <8 x float> zeroinitializer
  %.spill.load376 = load i1, ptr %.spill67, align 1
  %.splatinsert377 = insertelement <8 x i1> poison, i1 %.spill.load376, i64 0
  %.splat378 = shufflevector <8 x i1> %.splatinsert377, <8 x i1> poison, <8 x i32> zeroinitializer
  %379 = select <8 x i1> %.splat378, <8 x float> %native.exp332, <8 x float> zeroinitializer
  %.spill.load379 = load i1, ptr %.spill68, align 1
  %.splatinsert380 = insertelement <8 x i1> poison, i1 %.spill.load379, i64 0
  %.splat381 = shufflevector <8 x i1> %.splatinsert380, <8 x i1> poison, <8 x i32> zeroinitializer
  %380 = select <8 x i1> %.splat381, <8 x float> %native.exp333, <8 x float> zeroinitializer
  %381 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %381, 0
  %384 = select <8 x i1> %80, <8 x ptr> %382, <8 x ptr> %383
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %381, 1
  %387 = select <8 x i1> %80, <8 x i64> %385, <8 x i64> %386
  %388 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %384, 0
  %389 = insertvalue { <8 x ptr>, <8 x i64> } %388, <8 x i64> %387, 1
  store { <8 x ptr>, <8 x i64> } %389, ptr %tile_snapshot.spill90, align 64
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %392 = add <8 x i64> %391, zeroinitializer
  %393 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %390, 0
  %394 = insertvalue { <8 x ptr>, <8 x i64> } %393, <8 x i64> %392, 1
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %394, 0
  %396 = extractvalue { <8 x ptr>, <8 x i64> } %394, 1
  %397 = getelementptr i8, <8 x ptr> %395, <8 x i64> %396
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %365, <8 x ptr> align 1 %397, <8 x i1> %80)
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %400 = add <8 x i64> %399, splat (i64 4)
  %401 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %398, 0
  %402 = insertvalue { <8 x ptr>, <8 x i64> } %401, <8 x i64> %400, 1
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %402, 0
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %402, 1
  %405 = getelementptr i8, <8 x ptr> %403, <8 x i64> %404
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %366, <8 x ptr> align 1 %405, <8 x i1> %80)
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %407 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %408 = add <8 x i64> %407, splat (i64 8)
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %406, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %410, 0
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %410, 1
  %413 = getelementptr i8, <8 x ptr> %411, <8 x i64> %412
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %367, <8 x ptr> align 1 %413, <8 x i1> %80)
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %416 = add <8 x i64> %415, splat (i64 12)
  %417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %414, 0
  %418 = insertvalue { <8 x ptr>, <8 x i64> } %417, <8 x i64> %416, 1
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %418, 0
  %420 = extractvalue { <8 x ptr>, <8 x i64> } %418, 1
  %421 = getelementptr i8, <8 x ptr> %419, <8 x i64> %420
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %368, <8 x ptr> align 1 %421, <8 x i1> %80)
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %424 = add <8 x i64> %423, splat (i64 16)
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %422, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %426, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %426, 1
  %429 = getelementptr i8, <8 x ptr> %427, <8 x i64> %428
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %369, <8 x ptr> align 1 %429, <8 x i1> %80)
  %430 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %432 = add <8 x i64> %431, splat (i64 20)
  %433 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %430, 0
  %434 = insertvalue { <8 x ptr>, <8 x i64> } %433, <8 x i64> %432, 1
  %435 = extractvalue { <8 x ptr>, <8 x i64> } %434, 0
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %434, 1
  %437 = getelementptr i8, <8 x ptr> %435, <8 x i64> %436
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %370, <8 x ptr> align 1 %437, <8 x i1> %80)
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %440 = add <8 x i64> %439, splat (i64 24)
  %441 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %438, 0
  %442 = insertvalue { <8 x ptr>, <8 x i64> } %441, <8 x i64> %440, 1
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %442, 0
  %444 = extractvalue { <8 x ptr>, <8 x i64> } %442, 1
  %445 = getelementptr i8, <8 x ptr> %443, <8 x i64> %444
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %371, <8 x ptr> align 1 %445, <8 x i1> %80)
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %448 = add <8 x i64> %447, splat (i64 28)
  %449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %446, 0
  %450 = insertvalue { <8 x ptr>, <8 x i64> } %449, <8 x i64> %448, 1
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %450, 0
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %450, 1
  %453 = getelementptr i8, <8 x ptr> %451, <8 x i64> %452
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %372, <8 x ptr> align 1 %453, <8 x i1> %80)
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %455 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %456 = add <8 x i64> %455, splat (i64 32)
  %457 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %454, 0
  %458 = insertvalue { <8 x ptr>, <8 x i64> } %457, <8 x i64> %456, 1
  %459 = extractvalue { <8 x ptr>, <8 x i64> } %458, 0
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %458, 1
  %461 = getelementptr i8, <8 x ptr> %459, <8 x i64> %460
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %373, <8 x ptr> align 1 %461, <8 x i1> %80)
  %462 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %464 = add <8 x i64> %463, splat (i64 36)
  %465 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %462, 0
  %466 = insertvalue { <8 x ptr>, <8 x i64> } %465, <8 x i64> %464, 1
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %466, 0
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %466, 1
  %469 = getelementptr i8, <8 x ptr> %467, <8 x i64> %468
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %374, <8 x ptr> align 1 %469, <8 x i1> %80)
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %472 = add <8 x i64> %471, splat (i64 40)
  %473 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %470, 0
  %474 = insertvalue { <8 x ptr>, <8 x i64> } %473, <8 x i64> %472, 1
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %474, 0
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %474, 1
  %477 = getelementptr i8, <8 x ptr> %475, <8 x i64> %476
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %375, <8 x ptr> align 1 %477, <8 x i1> %80)
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %479 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %480 = add <8 x i64> %479, splat (i64 44)
  %481 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %478, 0
  %482 = insertvalue { <8 x ptr>, <8 x i64> } %481, <8 x i64> %480, 1
  %483 = extractvalue { <8 x ptr>, <8 x i64> } %482, 0
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %482, 1
  %485 = getelementptr i8, <8 x ptr> %483, <8 x i64> %484
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %376, <8 x ptr> align 1 %485, <8 x i1> %80)
  %486 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %487 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %488 = add <8 x i64> %487, splat (i64 48)
  %489 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %486, 0
  %490 = insertvalue { <8 x ptr>, <8 x i64> } %489, <8 x i64> %488, 1
  %491 = extractvalue { <8 x ptr>, <8 x i64> } %490, 0
  %492 = extractvalue { <8 x ptr>, <8 x i64> } %490, 1
  %493 = getelementptr i8, <8 x ptr> %491, <8 x i64> %492
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %377, <8 x ptr> align 1 %493, <8 x i1> %80)
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %496 = add <8 x i64> %495, splat (i64 52)
  %497 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %494, 0
  %498 = insertvalue { <8 x ptr>, <8 x i64> } %497, <8 x i64> %496, 1
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %498, 0
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %498, 1
  %501 = getelementptr i8, <8 x ptr> %499, <8 x i64> %500
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %378, <8 x ptr> align 1 %501, <8 x i1> %80)
  %502 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %503 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %504 = add <8 x i64> %503, splat (i64 56)
  %505 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %502, 0
  %506 = insertvalue { <8 x ptr>, <8 x i64> } %505, <8 x i64> %504, 1
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %506, 0
  %508 = extractvalue { <8 x ptr>, <8 x i64> } %506, 1
  %509 = getelementptr i8, <8 x ptr> %507, <8 x i64> %508
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %379, <8 x ptr> align 1 %509, <8 x i1> %80)
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %511 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %512 = add <8 x i64> %511, splat (i64 60)
  %513 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %510, 0
  %514 = insertvalue { <8 x ptr>, <8 x i64> } %513, <8 x i64> %512, 1
  %515 = extractvalue { <8 x ptr>, <8 x i64> } %514, 0
  %516 = extractvalue { <8 x ptr>, <8 x i64> } %514, 1
  %517 = getelementptr i8, <8 x ptr> %515, <8 x i64> %516
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %380, <8 x ptr> align 1 %517, <8 x i1> %80)
  %.state382 = load <8 x float>, ptr %.slot48, align 32
  %518 = fmul <8 x float> %.state382, %native.exp
  %519 = load <8 x float>, ptr %.spill91, align 32
  %520 = select <8 x i1> %80, <8 x float> %518, <8 x float> %519
  store <8 x float> %520, ptr %.spill91, align 32
  store i64 0, ptr %.slot92, align 4
  %521 = load <8 x float>, ptr %.slot93, align 32
  %522 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %521
  store <8 x float> %522, ptr %.slot93, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state383 = load i64, ptr %.slot92, align 4
  %523 = icmp slt i64 %.state383, 16
  br i1 %523, label %direct.true384, label %direct.false385

direct.schedule.14:                               ; preds = %direct.true384
  %.state386 = load i64, ptr %.slot92, align 4
  %524 = sdiv i64 %.state386, 1
  %.spill.load387 = load i64, ptr %.spill43, align 4
  %525 = mul i64 %.spill.load387, 1
  %526 = add i64 %525, 0
  %527 = mul i64 %526, 1
  %528 = add i64 %527, 0
  %529 = mul i64 %528, 16
  %530 = add i64 %529, %524
  %tile_snapshot.spill.load388 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load388, 0
  %532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load388, 1
  %.splatinsert389 = insertelement <8 x i64> poison, i64 %530, i64 0
  %.splat390 = shufflevector <8 x i64> %.splatinsert389, <8 x i64> poison, <8 x i32> zeroinitializer
  %533 = mul <8 x i64> %.splat390, splat (i64 4)
  %534 = add <8 x i64> %532, %533
  %535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %531, 0
  %536 = insertvalue { <8 x ptr>, <8 x i64> } %535, <8 x i64> %534, 1
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %536, 0
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %536, 1
  %539 = getelementptr i8, <8 x ptr> %537, <8 x i64> %538
  %540 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %539, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state391 = load <8 x float>, ptr %.slot93, align 32
  %541 = fadd <8 x float> %.state391, %540
  %.state392 = load i64, ptr %.slot92, align 4
  %542 = add i64 %.state392, 1
  store i64 %542, ptr %.slot92, align 4
  %543 = load <8 x float>, ptr %.slot93, align 32
  %544 = select <8 x i1> %80, <8 x float> %541, <8 x float> %543
  store <8 x float> %544, ptr %.slot93, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false385
  %.spill.load393 = load <8 x float>, ptr %.spill91, align 32
  %.state394 = load <8 x float>, ptr %.slot93, align 32
  %545 = fadd <8 x float> %.spill.load393, %.state394
  %546 = load <8 x float>, ptr %.spill94, align 32
  %547 = select <8 x i1> %80, <8 x float> %545, <8 x float> %546
  store <8 x float> %547, ptr %.spill94, align 32
  %548 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %549 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %550 = extractvalue { <8 x ptr>, <8 x i64> } %548, 0
  %551 = select <8 x i1> %80, <8 x ptr> %549, <8 x ptr> %550
  %552 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %548, 1
  %554 = select <8 x i1> %80, <8 x i64> %552, <8 x i64> %553
  %555 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %551, 0
  %556 = insertvalue { <8 x ptr>, <8 x i64> } %555, <8 x i64> %554, 1
  store { <8 x ptr>, <8 x i64> } %556, ptr %tile_snapshot.spill95, align 64
  store i64 0, ptr %.slot96, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state395 = load i64, ptr %.slot96, align 4
  %557 = icmp slt i64 %.state395, 128
  br i1 %557, label %direct.true396, label %direct.false397

direct.schedule.17:                               ; preds = %direct.true396
  %.state398 = load i64, ptr %.slot96, align 4
  %558 = add i64 0, %.state398
  %tile_snapshot.spill.load399 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %559 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load399, 0
  %560 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load399, 1
  %.splatinsert400 = insertelement <8 x i64> poison, i64 %558, i64 0
  %.splat401 = shufflevector <8 x i64> %.splatinsert400, <8 x i64> poison, <8 x i32> zeroinitializer
  %561 = mul <8 x i64> %.splat401, splat (i64 32)
  %562 = add <8 x i64> %560, %561
  %563 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %559, 0
  %564 = insertvalue { <8 x ptr>, <8 x i64> } %563, <8 x i64> %562, 1
  %565 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %564, 1
  %567 = extractelement <8 x ptr> %565, i32 0
  %568 = extractelement <8 x i64> %566, i32 0
  %569 = sub i64 %568, 0
  %570 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %571 = select i1 %570, i64 %569, i64 0
  %private.contiguous.address402 = getelementptr i8, ptr %567, i64 %571
  %private.contiguous.load403 = load <8 x float>, ptr %private.contiguous.address402, align 4
  %572 = select <8 x i1> %80, <8 x float> %private.contiguous.load403, <8 x float> zeroinitializer
  %.spill.load404 = load <8 x float>, ptr %.spill89, align 32
  %573 = fmul <8 x float> %572, %.spill.load404
  %tile_snapshot.spill.load405 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load405, 0
  %575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load405, 1
  %.state406 = load i64, ptr %.slot96, align 4
  %.splatinsert407 = insertelement <8 x i64> poison, i64 %.state406, i64 0
  %.splat408 = shufflevector <8 x i64> %.splatinsert407, <8 x i64> poison, <8 x i32> zeroinitializer
  %576 = mul <8 x i64> %.splat408, splat (i64 4)
  %577 = add <8 x i64> %575, %576
  %578 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %574, 0
  %579 = insertvalue { <8 x ptr>, <8 x i64> } %578, <8 x i64> %577, 1
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %579, 0
  %581 = extractvalue { <8 x ptr>, <8 x i64> } %579, 1
  %582 = getelementptr i8, <8 x ptr> %580, <8 x i64> %581
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %573, <8 x ptr> align 1 %582, <8 x i1> %80)
  %.state409 = load i64, ptr %.slot96, align 4
  %583 = add i64 %.state409, 1
  store i64 %583, ptr %.slot96, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false397
  %584 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %584, 0
  %587 = select <8 x i1> %80, <8 x ptr> %585, <8 x ptr> %586
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %584, 1
  %590 = select <8 x i1> %80, <8 x i64> %588, <8 x i64> %589
  %591 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %587, 0
  %592 = insertvalue { <8 x ptr>, <8 x i64> } %591, <8 x i64> %590, 1
  store { <8 x ptr>, <8 x i64> } %592, ptr %tile_snapshot.spill97, align 64
  %tile_snapshot.spill.load410 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %tile_snapshot.spill.load411 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %tile_snapshot.spill.load412 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %593 = extractelement <8 x i1> %80, i64 0
  br i1 %593, label %mma.active413, label %mma.continue414

direct.schedule.19:                               ; preds = %direct.schedule.20, %mma.continue428
  %.state429 = load i64, ptr %.slot98, align 4
  %594 = icmp slt i64 %.state429, 128
  br i1 %594, label %direct.true430, label %direct.false431

direct.schedule.20:                               ; preds = %direct.true430
  %tile_snapshot.spill.load432 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %595 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load432, 0
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load432, 1
  %.state433 = load i64, ptr %.slot98, align 4
  %.splatinsert434 = insertelement <8 x i64> poison, i64 %.state433, i64 0
  %.splat435 = shufflevector <8 x i64> %.splatinsert434, <8 x i64> poison, <8 x i32> zeroinitializer
  %597 = mul <8 x i64> %.splat435, splat (i64 4)
  %598 = add <8 x i64> %596, %597
  %599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %595, 0
  %600 = insertvalue { <8 x ptr>, <8 x i64> } %599, <8 x i64> %598, 1
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %600, 0
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %600, 1
  %603 = getelementptr i8, <8 x ptr> %601, <8 x i64> %602
  %604 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %603, <8 x i1> %80, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load436 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %605 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load436, 0
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load436, 1
  %.state437 = load i64, ptr %.slot98, align 4
  %.splatinsert438 = insertelement <8 x i64> poison, i64 %.state437, i64 0
  %.splat439 = shufflevector <8 x i64> %.splatinsert438, <8 x i64> poison, <8 x i32> zeroinitializer
  %607 = mul <8 x i64> %.splat439, splat (i64 32)
  %608 = add <8 x i64> %606, %607
  %609 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %605, 0
  %610 = insertvalue { <8 x ptr>, <8 x i64> } %609, <8 x i64> %608, 1
  %611 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %612 = extractvalue { <8 x ptr>, <8 x i64> } %610, 1
  %613 = extractelement <8 x ptr> %611, i32 0
  %614 = extractelement <8 x i64> %612, i32 0
  %615 = sub i64 %614, 0
  %616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %617 = select i1 %616, i64 %615, i64 0
  %private.contiguous.address440 = getelementptr i8, ptr %613, i64 %617
  %private.contiguous.preserve441 = load <8 x float>, ptr %private.contiguous.address440, align 4
  %618 = select <8 x i1> %80, <8 x float> %604, <8 x float> %private.contiguous.preserve441
  store <8 x float> %618, ptr %private.contiguous.address440, align 4
  %.state442 = load i64, ptr %.slot98, align 4
  %619 = add i64 %.state442, 1
  store i64 %619, ptr %.slot98, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false431
  store i64 0, ptr %.slot99, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state443 = load i64, ptr %.slot99, align 4
  %620 = icmp slt i64 %.state443, 128
  br i1 %620, label %direct.true444, label %direct.false445

direct.schedule.23:                               ; preds = %direct.true444
  %tile_snapshot.spill.load446 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load446, 0
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load446, 1
  %.state447 = load i64, ptr %.slot99, align 4
  %.splatinsert448 = insertelement <8 x i64> poison, i64 %.state447, i64 0
  %.splat449 = shufflevector <8 x i64> %.splatinsert448, <8 x i64> poison, <8 x i32> zeroinitializer
  %623 = mul <8 x i64> %.splat449, splat (i64 32)
  %624 = add <8 x i64> %622, %623
  %625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %621, 0
  %626 = insertvalue { <8 x ptr>, <8 x i64> } %625, <8 x i64> %624, 1
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %628 = extractvalue { <8 x ptr>, <8 x i64> } %626, 1
  %629 = extractelement <8 x ptr> %627, i32 0
  %630 = extractelement <8 x i64> %628, i32 0
  %631 = sub i64 %630, 0
  %632 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %633 = select i1 %632, i64 %631, i64 0
  %private.contiguous.address450 = getelementptr i8, ptr %629, i64 %633
  %private.contiguous.load451 = load <8 x float>, ptr %private.contiguous.address450, align 4
  %634 = select <8 x i1> %80, <8 x float> %private.contiguous.load451, <8 x float> zeroinitializer
  %tile_snapshot.spill.load452 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %635 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load452, 0
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load452, 1
  %.state453 = load i64, ptr %.slot99, align 4
  %.splatinsert454 = insertelement <8 x i64> poison, i64 %.state453, i64 0
  %.splat455 = shufflevector <8 x i64> %.splatinsert454, <8 x i64> poison, <8 x i32> zeroinitializer
  %637 = mul <8 x i64> %.splat455, splat (i64 32)
  %638 = add <8 x i64> %636, %637
  %639 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %635, 0
  %640 = insertvalue { <8 x ptr>, <8 x i64> } %639, <8 x i64> %638, 1
  %641 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %640, 1
  %643 = extractelement <8 x ptr> %641, i32 0
  %644 = extractelement <8 x i64> %642, i32 0
  %645 = sub i64 %644, 0
  %646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %647 = select i1 %646, i64 %645, i64 0
  %private.contiguous.address456 = getelementptr i8, ptr %643, i64 %647
  %private.contiguous.preserve457 = load <8 x float>, ptr %private.contiguous.address456, align 4
  %648 = select <8 x i1> %80, <8 x float> %634, <8 x float> %private.contiguous.preserve457
  store <8 x float> %648, ptr %private.contiguous.address456, align 4
  %.state458 = load i64, ptr %.slot99, align 4
  %649 = add i64 %.state458, 1
  store i64 %649, ptr %.slot99, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false445
  %.state459 = load i64, ptr %.slot46, align 4
  %650 = add i64 %.state459, 1
  %.spill.load460 = load <8 x float>, ptr %.spill88, align 32
  %.spill.load461 = load <8 x float>, ptr %.spill94, align 32
  store i64 %650, ptr %.slot46, align 4
  %651 = load <8 x float>, ptr %.slot47, align 32
  %652 = select <8 x i1> %80, <8 x float> %.spill.load460, <8 x float> %651
  store <8 x float> %652, ptr %.slot47, align 32
  %653 = load <8 x float>, ptr %.slot48, align 32
  %654 = select <8 x i1> %80, <8 x float> %.spill.load461, <8 x float> %653
  store <8 x float> %654, ptr %.slot48, align 32
  br label %direct.schedule.4

direct.schedule.25:                               ; preds = %direct.false166
  store i64 0, ptr %.slot100, align 4
  br label %direct.schedule.26

direct.schedule.26:                               ; preds = %direct.schedule.29, %direct.schedule.25
  %.state462 = load i64, ptr %.slot100, align 4
  %655 = icmp slt i64 %.state462, 2048
  br i1 %655, label %direct.true463, label %direct.false464

direct.schedule.27:                               ; preds = %direct.true463
  %.state465 = load i64, ptr %.slot100, align 4
  %656 = srem i64 %.state465, 128
  %.state466 = load i64, ptr %.slot100, align 4
  %657 = sdiv i64 %.state466, 128
  %.spill.load467 = load i64, ptr %.spill41, align 4
  %658 = add i64 %.spill.load467, 0
  %.spill.load468 = load <8 x i64>, ptr %.spill42, align 64
  %659 = add <8 x i64> %.spill.load468, zeroinitializer
  %660 = mul i64 %658, 4
  %.splatinsert469 = insertelement <8 x i64> poison, i64 %660, i64 0
  %.splat470 = shufflevector <8 x i64> %.splatinsert469, <8 x i64> poison, <8 x i32> zeroinitializer
  %661 = add <8 x i64> %.splat470, %659
  %.spill.load471 = load i64, ptr %.spill49, align 4
  %662 = add i64 %.spill.load471, %657
  %663 = mul <8 x i64> %661, splat (i64 8193)
  %.splatinsert472 = insertelement <8 x i64> poison, i64 %662, i64 0
  %.splat473 = shufflevector <8 x i64> %.splatinsert472, <8 x i64> poison, <8 x i32> zeroinitializer
  %664 = add <8 x i64> %663, %.splat473
  %665 = icmp sge i64 %662, 0
  %666 = and i1 true, %665
  %667 = icmp slt i64 %662, 8193
  %668 = and i1 %666, %667
  %669 = add i64 0, %656
  %670 = mul <8 x i64> %664, splat (i64 128)
  %.splatinsert474 = insertelement <8 x i64> poison, i64 %669, i64 0
  %.splat475 = shufflevector <8 x i64> %.splatinsert474, <8 x i64> poison, <8 x i32> zeroinitializer
  %671 = add <8 x i64> %670, %.splat475
  %672 = load <8 x i64>, ptr %.spill101, align 64
  %673 = select <8 x i1> %80, <8 x i64> %671, <8 x i64> %672
  store <8 x i64> %673, ptr %.spill101, align 64
  br i1 %668, label %direct.true476, label %direct.false477

direct.schedule.28:                               ; preds = %direct.true476
  %.spill.load478 = load <8 x i64>, ptr %.spill101, align 64
  %674 = extractvalue { ptr, i64 } %50, 0
  %675 = mul <8 x i64> %.spill.load478, splat (i64 4)
  %676 = getelementptr i8, ptr %674, <8 x i64> %675
  %677 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %676, <8 x i1> %80, <8 x float> zeroinitializer)
  %678 = load <8 x float>, ptr %.slot102, align 32
  %679 = select <8 x i1> %80, <8 x float> %677, <8 x float> %678
  store <8 x float> %679, ptr %.slot102, align 32
  br label %direct.schedule.29

direct.schedule.29:                               ; preds = %direct.schedule.28, %direct.false477
  %tile_snapshot.spill.load479 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, 1
  %.state480 = load i64, ptr %.slot100, align 4
  %.splatinsert481 = insertelement <8 x i64> poison, i64 %.state480, i64 0
  %.splat482 = shufflevector <8 x i64> %.splatinsert481, <8 x i64> poison, <8 x i32> zeroinitializer
  %682 = mul <8 x i64> %.splat482, splat (i64 4)
  %683 = add <8 x i64> %681, %682
  %684 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %680, 0
  %685 = insertvalue { <8 x ptr>, <8 x i64> } %684, <8 x i64> %683, 1
  %.state483 = load <8 x float>, ptr %.slot102, align 32
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %685, 0
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %685, 1
  %688 = getelementptr i8, <8 x ptr> %686, <8 x i64> %687
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state483, <8 x ptr> align 1 %688, <8 x i1> %80)
  %.state484 = load i64, ptr %.slot100, align 4
  %689 = add i64 %.state484, 1
  store i64 %689, ptr %.slot100, align 4
  br label %direct.schedule.26

direct.schedule.30:                               ; preds = %direct.false140
  store i64 0, ptr %.slot103, align 4
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.34, %direct.schedule.30
  %.state485 = load i64, ptr %.slot103, align 4
  %690 = icmp slt i64 %.state485, 2048
  br i1 %690, label %direct.true486, label %direct.false487

direct.schedule.32:                               ; preds = %direct.true486
  %.state488 = load i64, ptr %.slot103, align 4
  %691 = srem i64 %.state488, 128
  %.state489 = load i64, ptr %.slot103, align 4
  %692 = sdiv i64 %.state489, 128
  %.spill.load490 = load i64, ptr %.spill41, align 4
  %693 = add i64 %.spill.load490, 0
  %.spill.load491 = load <8 x i64>, ptr %.spill42, align 64
  %694 = add <8 x i64> %.spill.load491, zeroinitializer
  %695 = mul i64 %693, 4
  %.splatinsert492 = insertelement <8 x i64> poison, i64 %695, i64 0
  %.splat493 = shufflevector <8 x i64> %.splatinsert492, <8 x i64> poison, <8 x i32> zeroinitializer
  %696 = add <8 x i64> %.splat493, %694
  %.spill.load494 = load i64, ptr %.spill49, align 4
  %697 = add i64 %.spill.load494, %692
  %698 = mul <8 x i64> %696, splat (i64 8193)
  %.splatinsert495 = insertelement <8 x i64> poison, i64 %697, i64 0
  %.splat496 = shufflevector <8 x i64> %.splatinsert495, <8 x i64> poison, <8 x i32> zeroinitializer
  %699 = add <8 x i64> %698, %.splat496
  %700 = icmp sge i64 %697, 0
  %701 = and i1 true, %700
  %702 = icmp slt i64 %697, 8193
  %703 = and i1 %701, %702
  %704 = add i64 0, %691
  %705 = mul <8 x i64> %699, splat (i64 128)
  %.splatinsert497 = insertelement <8 x i64> poison, i64 %704, i64 0
  %.splat498 = shufflevector <8 x i64> %.splatinsert497, <8 x i64> poison, <8 x i32> zeroinitializer
  %706 = add <8 x i64> %705, %.splat498
  %707 = load <8 x i64>, ptr %.spill104, align 64
  %708 = select <8 x i1> %80, <8 x i64> %706, <8 x i64> %707
  store <8 x i64> %708, ptr %.spill104, align 64
  br i1 %703, label %direct.true499, label %direct.false500

direct.schedule.33:                               ; preds = %direct.true499
  %.spill.load501 = load <8 x i64>, ptr %.spill104, align 64
  %709 = extractvalue { ptr, i64 } %44, 0
  %710 = mul <8 x i64> %.spill.load501, splat (i64 4)
  %711 = getelementptr i8, ptr %709, <8 x i64> %710
  %712 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %711, <8 x i1> %80, <8 x float> zeroinitializer)
  %713 = load <8 x float>, ptr %.slot105, align 32
  %714 = select <8 x i1> %80, <8 x float> %712, <8 x float> %713
  store <8 x float> %714, ptr %.slot105, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.33, %direct.false500
  %tile_snapshot.spill.load502 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load502, 0
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load502, 1
  %.state503 = load i64, ptr %.slot103, align 4
  %.splatinsert504 = insertelement <8 x i64> poison, i64 %.state503, i64 0
  %.splat505 = shufflevector <8 x i64> %.splatinsert504, <8 x i64> poison, <8 x i32> zeroinitializer
  %717 = mul <8 x i64> %.splat505, splat (i64 4)
  %718 = add <8 x i64> %716, %717
  %719 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %715, 0
  %720 = insertvalue { <8 x ptr>, <8 x i64> } %719, <8 x i64> %718, 1
  %.state506 = load <8 x float>, ptr %.slot105, align 32
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %720, 0
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %720, 1
  %723 = getelementptr i8, <8 x ptr> %721, <8 x i64> %722
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state506, <8 x ptr> align 1 %723, <8 x i1> %80)
  %.state507 = load i64, ptr %.slot103, align 4
  %724 = add i64 %.state507, 1
  store i64 %724, ptr %.slot103, align 4
  br label %direct.schedule.31

direct.schedule.35:                               ; preds = %direct.false137
  store i64 0, ptr %.slot106, align 4
  br label %direct.schedule.36

direct.schedule.36:                               ; preds = %direct.schedule.37, %direct.schedule.35
  %.state508 = load i64, ptr %.slot106, align 4
  %725 = icmp slt i64 %.state508, 128
  br i1 %725, label %direct.true509, label %direct.false510

direct.schedule.37:                               ; preds = %direct.true509
  %.spill.load511 = load i64, ptr %.spill41, align 4
  %726 = add i64 %.spill.load511, 0
  %.spill.load512 = load <8 x i64>, ptr %.spill, align 64
  %727 = add <8 x i64> %.spill.load512, zeroinitializer
  %728 = mul i64 %726, 16
  %.splatinsert513 = insertelement <8 x i64> poison, i64 %728, i64 0
  %.splat514 = shufflevector <8 x i64> %.splatinsert513, <8 x i64> poison, <8 x i32> zeroinitializer
  %729 = add <8 x i64> %.splat514, %727
  %730 = mul <8 x i64> %729, splat (i64 1)
  %.spill.load515 = load i64, ptr %.spill43, align 4
  %.splatinsert516 = insertelement <8 x i64> poison, i64 %.spill.load515, i64 0
  %.splat517 = shufflevector <8 x i64> %.splatinsert516, <8 x i64> poison, <8 x i32> zeroinitializer
  %731 = add <8 x i64> %730, %.splat517
  %.state518 = load i64, ptr %.slot106, align 4
  %732 = add i64 0, %.state518
  %733 = mul <8 x i64> %731, splat (i64 128)
  %.splatinsert519 = insertelement <8 x i64> poison, i64 %732, i64 0
  %.splat520 = shufflevector <8 x i64> %.splatinsert519, <8 x i64> poison, <8 x i32> zeroinitializer
  %734 = add <8 x i64> %733, %.splat520
  %.state521 = load i64, ptr %.slot106, align 4
  %735 = add i64 0, %.state521
  %tile_snapshot.spill.load522 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load522, 0
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load522, 1
  %.splatinsert523 = insertelement <8 x i64> poison, i64 %735, i64 0
  %.splat524 = shufflevector <8 x i64> %.splatinsert523, <8 x i64> poison, <8 x i32> zeroinitializer
  %738 = mul <8 x i64> %.splat524, splat (i64 32)
  %739 = add <8 x i64> %737, %738
  %740 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %736, 0
  %741 = insertvalue { <8 x ptr>, <8 x i64> } %740, <8 x i64> %739, 1
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %741, 1
  %744 = extractelement <8 x ptr> %742, i32 0
  %745 = extractelement <8 x i64> %743, i32 0
  %746 = sub i64 %745, 0
  %747 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %748 = select i1 %747, i64 %746, i64 0
  %private.contiguous.address525 = getelementptr i8, ptr %744, i64 %748
  %private.contiguous.load526 = load <8 x float>, ptr %private.contiguous.address525, align 4
  %749 = select <8 x i1> %80, <8 x float> %private.contiguous.load526, <8 x float> zeroinitializer
  %.state527 = load <8 x float>, ptr %.slot48, align 32
  %750 = fdiv <8 x float> %749, %.state527
  %751 = extractvalue { ptr, i64 } %56, 0
  %752 = mul <8 x i64> %734, splat (i64 4)
  %753 = getelementptr i8, ptr %751, <8 x i64> %752
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %750, <8 x ptr> align 1 %753, <8 x i1> %80)
  %.state528 = load i64, ptr %.slot106, align 4
  %754 = add i64 %.state528, 1
  store i64 %754, ptr %.slot106, align 4
  br label %direct.schedule.36

direct.schedule.38:                               ; preds = %direct.false510
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

copy.active:                                      ; preds = %direct.schedule.0
  %755 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %756 = extractelement <8 x ptr> %755, i64 0
  %757 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %758 = extractelement <8 x i64> %757, i64 0
  %759 = getelementptr i8, ptr %756, i64 %758
  %760 = extractelement <8 x i64> %107, i64 0
  call void @llm_attention.contiguous_copy(ptr %108, i64 %760, ptr %759)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active, %direct.schedule.0
  %761 = extractelement <8 x i1> %80, i64 1
  br i1 %761, label %copy.active117, label %copy.continue118

copy.active117:                                   ; preds = %copy.continue
  %762 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %763 = extractelement <8 x ptr> %762, i64 1
  %764 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %765 = extractelement <8 x i64> %764, i64 1
  %766 = getelementptr i8, ptr %763, i64 %765
  %767 = extractelement <8 x i64> %107, i64 1
  call void @llm_attention.contiguous_copy(ptr %108, i64 %767, ptr %766)
  br label %copy.continue118

copy.continue118:                                 ; preds = %copy.active117, %copy.continue
  %768 = extractelement <8 x i1> %80, i64 2
  br i1 %768, label %copy.active119, label %copy.continue120

copy.active119:                                   ; preds = %copy.continue118
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %770 = extractelement <8 x ptr> %769, i64 2
  %771 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %772 = extractelement <8 x i64> %771, i64 2
  %773 = getelementptr i8, ptr %770, i64 %772
  %774 = extractelement <8 x i64> %107, i64 2
  call void @llm_attention.contiguous_copy(ptr %108, i64 %774, ptr %773)
  br label %copy.continue120

copy.continue120:                                 ; preds = %copy.active119, %copy.continue118
  %775 = extractelement <8 x i1> %80, i64 3
  br i1 %775, label %copy.active121, label %copy.continue122

copy.active121:                                   ; preds = %copy.continue120
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %777 = extractelement <8 x ptr> %776, i64 3
  %778 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %779 = extractelement <8 x i64> %778, i64 3
  %780 = getelementptr i8, ptr %777, i64 %779
  %781 = extractelement <8 x i64> %107, i64 3
  call void @llm_attention.contiguous_copy(ptr %108, i64 %781, ptr %780)
  br label %copy.continue122

copy.continue122:                                 ; preds = %copy.active121, %copy.continue120
  %782 = extractelement <8 x i1> %80, i64 4
  br i1 %782, label %copy.active123, label %copy.continue124

copy.active123:                                   ; preds = %copy.continue122
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %784 = extractelement <8 x ptr> %783, i64 4
  %785 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %786 = extractelement <8 x i64> %785, i64 4
  %787 = getelementptr i8, ptr %784, i64 %786
  %788 = extractelement <8 x i64> %107, i64 4
  call void @llm_attention.contiguous_copy(ptr %108, i64 %788, ptr %787)
  br label %copy.continue124

copy.continue124:                                 ; preds = %copy.active123, %copy.continue122
  %789 = extractelement <8 x i1> %80, i64 5
  br i1 %789, label %copy.active125, label %copy.continue126

copy.active125:                                   ; preds = %copy.continue124
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %791 = extractelement <8 x ptr> %790, i64 5
  %792 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %793 = extractelement <8 x i64> %792, i64 5
  %794 = getelementptr i8, ptr %791, i64 %793
  %795 = extractelement <8 x i64> %107, i64 5
  call void @llm_attention.contiguous_copy(ptr %108, i64 %795, ptr %794)
  br label %copy.continue126

copy.continue126:                                 ; preds = %copy.active125, %copy.continue124
  %796 = extractelement <8 x i1> %80, i64 6
  br i1 %796, label %copy.active127, label %copy.continue128

copy.active127:                                   ; preds = %copy.continue126
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %798 = extractelement <8 x ptr> %797, i64 6
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %800 = extractelement <8 x i64> %799, i64 6
  %801 = getelementptr i8, ptr %798, i64 %800
  %802 = extractelement <8 x i64> %107, i64 6
  call void @llm_attention.contiguous_copy(ptr %108, i64 %802, ptr %801)
  br label %copy.continue128

copy.continue128:                                 ; preds = %copy.active127, %copy.continue126
  %803 = extractelement <8 x i1> %80, i64 7
  br i1 %803, label %copy.active129, label %copy.continue130

copy.active129:                                   ; preds = %copy.continue128
  %804 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %805 = extractelement <8 x ptr> %804, i64 7
  %806 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %807 = extractelement <8 x i64> %806, i64 7
  %808 = getelementptr i8, ptr %805, i64 %807
  %809 = extractelement <8 x i64> %107, i64 7
  call void @llm_attention.contiguous_copy(ptr %108, i64 %809, ptr %808)
  br label %copy.continue130

copy.continue130:                                 ; preds = %copy.active129, %copy.continue128
  %810 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %810, 0
  %813 = select <8 x i1> %80, <8 x ptr> %811, <8 x ptr> %812
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %815 = extractvalue { <8 x ptr>, <8 x i64> } %810, 1
  %816 = select <8 x i1> %80, <8 x i64> %814, <8 x i64> %815
  %817 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %813, 0
  %818 = insertvalue { <8 x ptr>, <8 x i64> } %817, <8 x i64> %816, 1
  store { <8 x ptr>, <8 x i64> } %818, ptr %tile_snapshot.spill44, align 64
  %819 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %821 = extractvalue { <8 x ptr>, <8 x i64> } %819, 0
  %822 = select <8 x i1> %80, <8 x ptr> %820, <8 x ptr> %821
  %823 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %819, 1
  %825 = select <8 x i1> %80, <8 x i64> %823, <8 x i64> %824
  %826 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %822, 0
  %827 = insertvalue { <8 x ptr>, <8 x i64> } %826, <8 x i64> %825, 1
  store { <8 x ptr>, <8 x i64> } %827, ptr %tile_snapshot.spill45, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true136:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false137:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.35

direct.true139:                                   ; preds = %direct.schedule.5
  br label %direct.schedule.6

direct.false140:                                  ; preds = %direct.schedule.5
  br label %direct.schedule.30

copy.active148:                                   ; preds = %direct.schedule.6
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %829 = extractelement <8 x ptr> %828, i64 0
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %831 = extractelement <8 x i64> %830, i64 0
  %832 = getelementptr i8, ptr %829, i64 %831
  %833 = extractelement <8 x i64> %151, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %152, i64 %833, ptr %832)
  br label %copy.continue149

copy.continue149:                                 ; preds = %copy.active148, %direct.schedule.6
  %834 = extractelement <8 x i1> %80, i64 1
  br i1 %834, label %copy.active150, label %copy.continue151

copy.active150:                                   ; preds = %copy.continue149
  %835 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %836 = extractelement <8 x ptr> %835, i64 1
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %838 = extractelement <8 x i64> %837, i64 1
  %839 = getelementptr i8, ptr %836, i64 %838
  %840 = extractelement <8 x i64> %151, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %152, i64 %840, ptr %839)
  br label %copy.continue151

copy.continue151:                                 ; preds = %copy.active150, %copy.continue149
  %841 = extractelement <8 x i1> %80, i64 2
  br i1 %841, label %copy.active152, label %copy.continue153

copy.active152:                                   ; preds = %copy.continue151
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %843 = extractelement <8 x ptr> %842, i64 2
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %845 = extractelement <8 x i64> %844, i64 2
  %846 = getelementptr i8, ptr %843, i64 %845
  %847 = extractelement <8 x i64> %151, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %152, i64 %847, ptr %846)
  br label %copy.continue153

copy.continue153:                                 ; preds = %copy.active152, %copy.continue151
  %848 = extractelement <8 x i1> %80, i64 3
  br i1 %848, label %copy.active154, label %copy.continue155

copy.active154:                                   ; preds = %copy.continue153
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %850 = extractelement <8 x ptr> %849, i64 3
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %852 = extractelement <8 x i64> %851, i64 3
  %853 = getelementptr i8, ptr %850, i64 %852
  %854 = extractelement <8 x i64> %151, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %152, i64 %854, ptr %853)
  br label %copy.continue155

copy.continue155:                                 ; preds = %copy.active154, %copy.continue153
  %855 = extractelement <8 x i1> %80, i64 4
  br i1 %855, label %copy.active156, label %copy.continue157

copy.active156:                                   ; preds = %copy.continue155
  %856 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %857 = extractelement <8 x ptr> %856, i64 4
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %859 = extractelement <8 x i64> %858, i64 4
  %860 = getelementptr i8, ptr %857, i64 %859
  %861 = extractelement <8 x i64> %151, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %152, i64 %861, ptr %860)
  br label %copy.continue157

copy.continue157:                                 ; preds = %copy.active156, %copy.continue155
  %862 = extractelement <8 x i1> %80, i64 5
  br i1 %862, label %copy.active158, label %copy.continue159

copy.active158:                                   ; preds = %copy.continue157
  %863 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %864 = extractelement <8 x ptr> %863, i64 5
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %866 = extractelement <8 x i64> %865, i64 5
  %867 = getelementptr i8, ptr %864, i64 %866
  %868 = extractelement <8 x i64> %151, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %152, i64 %868, ptr %867)
  br label %copy.continue159

copy.continue159:                                 ; preds = %copy.active158, %copy.continue157
  %869 = extractelement <8 x i1> %80, i64 6
  br i1 %869, label %copy.active160, label %copy.continue161

copy.active160:                                   ; preds = %copy.continue159
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %871 = extractelement <8 x ptr> %870, i64 6
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %873 = extractelement <8 x i64> %872, i64 6
  %874 = getelementptr i8, ptr %871, i64 %873
  %875 = extractelement <8 x i64> %151, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %152, i64 %875, ptr %874)
  br label %copy.continue161

copy.continue161:                                 ; preds = %copy.active160, %copy.continue159
  %876 = extractelement <8 x i1> %80, i64 7
  br i1 %876, label %copy.active162, label %copy.continue163

copy.active162:                                   ; preds = %copy.continue161
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %878 = extractelement <8 x ptr> %877, i64 7
  %879 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %880 = extractelement <8 x i64> %879, i64 7
  %881 = getelementptr i8, ptr %878, i64 %880
  %882 = extractelement <8 x i64> %151, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %152, i64 %882, ptr %881)
  br label %copy.continue163

copy.continue163:                                 ; preds = %copy.active162, %copy.continue161
  br label %direct.schedule.7

direct.true165:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false166:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.25

copy.active175:                                   ; preds = %direct.schedule.8
  %883 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %884 = extractelement <8 x ptr> %883, i64 0
  %885 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %886 = extractelement <8 x i64> %885, i64 0
  %887 = getelementptr i8, ptr %884, i64 %886
  %888 = extractelement <8 x i64> %168, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %169, i64 %888, ptr %887)
  br label %copy.continue176

copy.continue176:                                 ; preds = %copy.active175, %direct.schedule.8
  %889 = extractelement <8 x i1> %80, i64 1
  br i1 %889, label %copy.active177, label %copy.continue178

copy.active177:                                   ; preds = %copy.continue176
  %890 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %891 = extractelement <8 x ptr> %890, i64 1
  %892 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %893 = extractelement <8 x i64> %892, i64 1
  %894 = getelementptr i8, ptr %891, i64 %893
  %895 = extractelement <8 x i64> %168, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %169, i64 %895, ptr %894)
  br label %copy.continue178

copy.continue178:                                 ; preds = %copy.active177, %copy.continue176
  %896 = extractelement <8 x i1> %80, i64 2
  br i1 %896, label %copy.active179, label %copy.continue180

copy.active179:                                   ; preds = %copy.continue178
  %897 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %898 = extractelement <8 x ptr> %897, i64 2
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %900 = extractelement <8 x i64> %899, i64 2
  %901 = getelementptr i8, ptr %898, i64 %900
  %902 = extractelement <8 x i64> %168, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %169, i64 %902, ptr %901)
  br label %copy.continue180

copy.continue180:                                 ; preds = %copy.active179, %copy.continue178
  %903 = extractelement <8 x i1> %80, i64 3
  br i1 %903, label %copy.active181, label %copy.continue182

copy.active181:                                   ; preds = %copy.continue180
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %905 = extractelement <8 x ptr> %904, i64 3
  %906 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %907 = extractelement <8 x i64> %906, i64 3
  %908 = getelementptr i8, ptr %905, i64 %907
  %909 = extractelement <8 x i64> %168, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %169, i64 %909, ptr %908)
  br label %copy.continue182

copy.continue182:                                 ; preds = %copy.active181, %copy.continue180
  %910 = extractelement <8 x i1> %80, i64 4
  br i1 %910, label %copy.active183, label %copy.continue184

copy.active183:                                   ; preds = %copy.continue182
  %911 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %912 = extractelement <8 x ptr> %911, i64 4
  %913 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %914 = extractelement <8 x i64> %913, i64 4
  %915 = getelementptr i8, ptr %912, i64 %914
  %916 = extractelement <8 x i64> %168, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %169, i64 %916, ptr %915)
  br label %copy.continue184

copy.continue184:                                 ; preds = %copy.active183, %copy.continue182
  %917 = extractelement <8 x i1> %80, i64 5
  br i1 %917, label %copy.active185, label %copy.continue186

copy.active185:                                   ; preds = %copy.continue184
  %918 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %919 = extractelement <8 x ptr> %918, i64 5
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %921 = extractelement <8 x i64> %920, i64 5
  %922 = getelementptr i8, ptr %919, i64 %921
  %923 = extractelement <8 x i64> %168, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %169, i64 %923, ptr %922)
  br label %copy.continue186

copy.continue186:                                 ; preds = %copy.active185, %copy.continue184
  %924 = extractelement <8 x i1> %80, i64 6
  br i1 %924, label %copy.active187, label %copy.continue188

copy.active187:                                   ; preds = %copy.continue186
  %925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %926 = extractelement <8 x ptr> %925, i64 6
  %927 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %928 = extractelement <8 x i64> %927, i64 6
  %929 = getelementptr i8, ptr %926, i64 %928
  %930 = extractelement <8 x i64> %168, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %169, i64 %930, ptr %929)
  br label %copy.continue188

copy.continue188:                                 ; preds = %copy.active187, %copy.continue186
  %931 = extractelement <8 x i1> %80, i64 7
  br i1 %931, label %copy.active189, label %copy.continue190

copy.active189:                                   ; preds = %copy.continue188
  %932 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %933 = extractelement <8 x ptr> %932, i64 7
  %934 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %935 = extractelement <8 x i64> %934, i64 7
  %936 = getelementptr i8, ptr %933, i64 %935
  %937 = extractelement <8 x i64> %168, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %169, i64 %937, ptr %936)
  br label %copy.continue190

copy.continue190:                                 ; preds = %copy.active189, %copy.continue188
  br label %direct.schedule.9

mma.active:                                       ; preds = %direct.schedule.9
  %938 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %939 = extractelement <8 x ptr> %938, i64 0
  %940 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %941 = extractelement <8 x i64> %940, i64 0
  %942 = getelementptr i8, ptr %939, i64 %941
  %943 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %944 = extractelement <8 x ptr> %943, i64 0
  %945 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %946 = extractelement <8 x i64> %945, i64 0
  %947 = getelementptr i8, ptr %944, i64 %946
  %948 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %949 = extractelement <8 x ptr> %948, i64 0
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %951 = extractelement <8 x i64> %950, i64 0
  %952 = getelementptr i8, ptr %949, i64 %951
  %953 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %954 = extractelement <8 x ptr> %953, i64 0
  %955 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %956 = extractelement <8 x i64> %955, i64 0
  %957 = getelementptr i8, ptr %954, i64 %956
  call void @llm_attention.strided_mma(ptr %942, ptr %947, ptr %952, ptr %957)
  br label %mma.continue

mma.continue:                                     ; preds = %mma.active, %direct.schedule.9
  %958 = extractelement <8 x i1> %80, i64 1
  br i1 %958, label %mma.active193, label %mma.continue194

mma.active193:                                    ; preds = %mma.continue
  %959 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %960 = extractelement <8 x ptr> %959, i64 1
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %962 = extractelement <8 x i64> %961, i64 1
  %963 = getelementptr i8, ptr %960, i64 %962
  %964 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %965 = extractelement <8 x ptr> %964, i64 1
  %966 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %967 = extractelement <8 x i64> %966, i64 1
  %968 = getelementptr i8, ptr %965, i64 %967
  %969 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %970 = extractelement <8 x ptr> %969, i64 1
  %971 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %972 = extractelement <8 x i64> %971, i64 1
  %973 = getelementptr i8, ptr %970, i64 %972
  %974 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %975 = extractelement <8 x ptr> %974, i64 1
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %977 = extractelement <8 x i64> %976, i64 1
  %978 = getelementptr i8, ptr %975, i64 %977
  call void @llm_attention.strided_mma(ptr %963, ptr %968, ptr %973, ptr %978)
  br label %mma.continue194

mma.continue194:                                  ; preds = %mma.active193, %mma.continue
  %979 = extractelement <8 x i1> %80, i64 2
  br i1 %979, label %mma.active195, label %mma.continue196

mma.active195:                                    ; preds = %mma.continue194
  %980 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %981 = extractelement <8 x ptr> %980, i64 2
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %983 = extractelement <8 x i64> %982, i64 2
  %984 = getelementptr i8, ptr %981, i64 %983
  %985 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %986 = extractelement <8 x ptr> %985, i64 2
  %987 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %988 = extractelement <8 x i64> %987, i64 2
  %989 = getelementptr i8, ptr %986, i64 %988
  %990 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %991 = extractelement <8 x ptr> %990, i64 2
  %992 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %993 = extractelement <8 x i64> %992, i64 2
  %994 = getelementptr i8, ptr %991, i64 %993
  %995 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %996 = extractelement <8 x ptr> %995, i64 2
  %997 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %998 = extractelement <8 x i64> %997, i64 2
  %999 = getelementptr i8, ptr %996, i64 %998
  call void @llm_attention.strided_mma(ptr %984, ptr %989, ptr %994, ptr %999)
  br label %mma.continue196

mma.continue196:                                  ; preds = %mma.active195, %mma.continue194
  %1000 = extractelement <8 x i1> %80, i64 3
  br i1 %1000, label %mma.active197, label %mma.continue198

mma.active197:                                    ; preds = %mma.continue196
  %1001 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %1002 = extractelement <8 x ptr> %1001, i64 3
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %1004 = extractelement <8 x i64> %1003, i64 3
  %1005 = getelementptr i8, ptr %1002, i64 %1004
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %1007 = extractelement <8 x ptr> %1006, i64 3
  %1008 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %1009 = extractelement <8 x i64> %1008, i64 3
  %1010 = getelementptr i8, ptr %1007, i64 %1009
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1012 = extractelement <8 x ptr> %1011, i64 3
  %1013 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1014 = extractelement <8 x i64> %1013, i64 3
  %1015 = getelementptr i8, ptr %1012, i64 %1014
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1017 = extractelement <8 x ptr> %1016, i64 3
  %1018 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1019 = extractelement <8 x i64> %1018, i64 3
  %1020 = getelementptr i8, ptr %1017, i64 %1019
  call void @llm_attention.strided_mma(ptr %1005, ptr %1010, ptr %1015, ptr %1020)
  br label %mma.continue198

mma.continue198:                                  ; preds = %mma.active197, %mma.continue196
  %1021 = extractelement <8 x i1> %80, i64 4
  br i1 %1021, label %mma.active199, label %mma.continue200

mma.active199:                                    ; preds = %mma.continue198
  %1022 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %1023 = extractelement <8 x ptr> %1022, i64 4
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %1025 = extractelement <8 x i64> %1024, i64 4
  %1026 = getelementptr i8, ptr %1023, i64 %1025
  %1027 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %1028 = extractelement <8 x ptr> %1027, i64 4
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %1030 = extractelement <8 x i64> %1029, i64 4
  %1031 = getelementptr i8, ptr %1028, i64 %1030
  %1032 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1033 = extractelement <8 x ptr> %1032, i64 4
  %1034 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1035 = extractelement <8 x i64> %1034, i64 4
  %1036 = getelementptr i8, ptr %1033, i64 %1035
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1038 = extractelement <8 x ptr> %1037, i64 4
  %1039 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1040 = extractelement <8 x i64> %1039, i64 4
  %1041 = getelementptr i8, ptr %1038, i64 %1040
  call void @llm_attention.strided_mma(ptr %1026, ptr %1031, ptr %1036, ptr %1041)
  br label %mma.continue200

mma.continue200:                                  ; preds = %mma.active199, %mma.continue198
  %1042 = extractelement <8 x i1> %80, i64 5
  br i1 %1042, label %mma.active201, label %mma.continue202

mma.active201:                                    ; preds = %mma.continue200
  %1043 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %1044 = extractelement <8 x ptr> %1043, i64 5
  %1045 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %1046 = extractelement <8 x i64> %1045, i64 5
  %1047 = getelementptr i8, ptr %1044, i64 %1046
  %1048 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %1049 = extractelement <8 x ptr> %1048, i64 5
  %1050 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %1051 = extractelement <8 x i64> %1050, i64 5
  %1052 = getelementptr i8, ptr %1049, i64 %1051
  %1053 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1054 = extractelement <8 x ptr> %1053, i64 5
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1056 = extractelement <8 x i64> %1055, i64 5
  %1057 = getelementptr i8, ptr %1054, i64 %1056
  %1058 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1059 = extractelement <8 x ptr> %1058, i64 5
  %1060 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1061 = extractelement <8 x i64> %1060, i64 5
  %1062 = getelementptr i8, ptr %1059, i64 %1061
  call void @llm_attention.strided_mma(ptr %1047, ptr %1052, ptr %1057, ptr %1062)
  br label %mma.continue202

mma.continue202:                                  ; preds = %mma.active201, %mma.continue200
  %1063 = extractelement <8 x i1> %80, i64 6
  br i1 %1063, label %mma.active203, label %mma.continue204

mma.active203:                                    ; preds = %mma.continue202
  %1064 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %1065 = extractelement <8 x ptr> %1064, i64 6
  %1066 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %1067 = extractelement <8 x i64> %1066, i64 6
  %1068 = getelementptr i8, ptr %1065, i64 %1067
  %1069 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %1070 = extractelement <8 x ptr> %1069, i64 6
  %1071 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %1072 = extractelement <8 x i64> %1071, i64 6
  %1073 = getelementptr i8, ptr %1070, i64 %1072
  %1074 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1075 = extractelement <8 x ptr> %1074, i64 6
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1077 = extractelement <8 x i64> %1076, i64 6
  %1078 = getelementptr i8, ptr %1075, i64 %1077
  %1079 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1080 = extractelement <8 x ptr> %1079, i64 6
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1082 = extractelement <8 x i64> %1081, i64 6
  %1083 = getelementptr i8, ptr %1080, i64 %1082
  call void @llm_attention.strided_mma(ptr %1068, ptr %1073, ptr %1078, ptr %1083)
  br label %mma.continue204

mma.continue204:                                  ; preds = %mma.active203, %mma.continue202
  %1084 = extractelement <8 x i1> %80, i64 7
  br i1 %1084, label %mma.active205, label %mma.continue206

mma.active205:                                    ; preds = %mma.continue204
  %1085 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %1086 = extractelement <8 x ptr> %1085, i64 7
  %1087 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %1088 = extractelement <8 x i64> %1087, i64 7
  %1089 = getelementptr i8, ptr %1086, i64 %1088
  %1090 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %1091 = extractelement <8 x ptr> %1090, i64 7
  %1092 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %1093 = extractelement <8 x i64> %1092, i64 7
  %1094 = getelementptr i8, ptr %1091, i64 %1093
  %1095 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1096 = extractelement <8 x ptr> %1095, i64 7
  %1097 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1098 = extractelement <8 x i64> %1097, i64 7
  %1099 = getelementptr i8, ptr %1096, i64 %1098
  %1100 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1101 = extractelement <8 x ptr> %1100, i64 7
  %1102 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1103 = extractelement <8 x i64> %1102, i64 7
  %1104 = getelementptr i8, ptr %1101, i64 %1103
  call void @llm_attention.strided_mma(ptr %1089, ptr %1094, ptr %1099, ptr %1104)
  br label %mma.continue206

mma.continue206:                                  ; preds = %mma.active205, %mma.continue204
  %1105 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1107 = add <8 x i64> %1106, zeroinitializer
  %1108 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1105, 0
  %1109 = insertvalue { <8 x ptr>, <8 x i64> } %1108, <8 x i64> %1107, 1
  %1110 = extractvalue { <8 x ptr>, <8 x i64> } %1109, 0
  %1111 = extractvalue { <8 x ptr>, <8 x i64> } %1109, 1
  %1112 = getelementptr i8, <8 x ptr> %1110, <8 x i64> %1111
  %1113 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1112, <8 x i1> %80, <8 x float> zeroinitializer)
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1116 = add <8 x i64> %1115, splat (i64 4)
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1114, 0
  %1118 = insertvalue { <8 x ptr>, <8 x i64> } %1117, <8 x i64> %1116, 1
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %1118, 1
  %1121 = getelementptr i8, <8 x ptr> %1119, <8 x i64> %1120
  %1122 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1121, <8 x i1> %80, <8 x float> zeroinitializer)
  %1123 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1125 = add <8 x i64> %1124, splat (i64 8)
  %1126 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1123, 0
  %1127 = insertvalue { <8 x ptr>, <8 x i64> } %1126, <8 x i64> %1125, 1
  %1128 = extractvalue { <8 x ptr>, <8 x i64> } %1127, 0
  %1129 = extractvalue { <8 x ptr>, <8 x i64> } %1127, 1
  %1130 = getelementptr i8, <8 x ptr> %1128, <8 x i64> %1129
  %1131 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1130, <8 x i1> %80, <8 x float> zeroinitializer)
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1134 = add <8 x i64> %1133, splat (i64 12)
  %1135 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1132, 0
  %1136 = insertvalue { <8 x ptr>, <8 x i64> } %1135, <8 x i64> %1134, 1
  %1137 = extractvalue { <8 x ptr>, <8 x i64> } %1136, 0
  %1138 = extractvalue { <8 x ptr>, <8 x i64> } %1136, 1
  %1139 = getelementptr i8, <8 x ptr> %1137, <8 x i64> %1138
  %1140 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1139, <8 x i1> %80, <8 x float> zeroinitializer)
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1142 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1143 = add <8 x i64> %1142, splat (i64 16)
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1141, 0
  %1145 = insertvalue { <8 x ptr>, <8 x i64> } %1144, <8 x i64> %1143, 1
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1145, 0
  %1147 = extractvalue { <8 x ptr>, <8 x i64> } %1145, 1
  %1148 = getelementptr i8, <8 x ptr> %1146, <8 x i64> %1147
  %1149 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1148, <8 x i1> %80, <8 x float> zeroinitializer)
  %1150 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1151 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1152 = add <8 x i64> %1151, splat (i64 20)
  %1153 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1150, 0
  %1154 = insertvalue { <8 x ptr>, <8 x i64> } %1153, <8 x i64> %1152, 1
  %1155 = extractvalue { <8 x ptr>, <8 x i64> } %1154, 0
  %1156 = extractvalue { <8 x ptr>, <8 x i64> } %1154, 1
  %1157 = getelementptr i8, <8 x ptr> %1155, <8 x i64> %1156
  %1158 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1157, <8 x i1> %80, <8 x float> zeroinitializer)
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1160 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1161 = add <8 x i64> %1160, splat (i64 24)
  %1162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1159, 0
  %1163 = insertvalue { <8 x ptr>, <8 x i64> } %1162, <8 x i64> %1161, 1
  %1164 = extractvalue { <8 x ptr>, <8 x i64> } %1163, 0
  %1165 = extractvalue { <8 x ptr>, <8 x i64> } %1163, 1
  %1166 = getelementptr i8, <8 x ptr> %1164, <8 x i64> %1165
  %1167 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1166, <8 x i1> %80, <8 x float> zeroinitializer)
  %1168 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1169 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1170 = add <8 x i64> %1169, splat (i64 28)
  %1171 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1168, 0
  %1172 = insertvalue { <8 x ptr>, <8 x i64> } %1171, <8 x i64> %1170, 1
  %1173 = extractvalue { <8 x ptr>, <8 x i64> } %1172, 0
  %1174 = extractvalue { <8 x ptr>, <8 x i64> } %1172, 1
  %1175 = getelementptr i8, <8 x ptr> %1173, <8 x i64> %1174
  %1176 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1175, <8 x i1> %80, <8 x float> zeroinitializer)
  %1177 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1178 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1179 = add <8 x i64> %1178, splat (i64 32)
  %1180 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1177, 0
  %1181 = insertvalue { <8 x ptr>, <8 x i64> } %1180, <8 x i64> %1179, 1
  %1182 = extractvalue { <8 x ptr>, <8 x i64> } %1181, 0
  %1183 = extractvalue { <8 x ptr>, <8 x i64> } %1181, 1
  %1184 = getelementptr i8, <8 x ptr> %1182, <8 x i64> %1183
  %1185 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1184, <8 x i1> %80, <8 x float> zeroinitializer)
  %1186 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1187 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1188 = add <8 x i64> %1187, splat (i64 36)
  %1189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1186, 0
  %1190 = insertvalue { <8 x ptr>, <8 x i64> } %1189, <8 x i64> %1188, 1
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %1190, 0
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %1190, 1
  %1193 = getelementptr i8, <8 x ptr> %1191, <8 x i64> %1192
  %1194 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1193, <8 x i1> %80, <8 x float> zeroinitializer)
  %1195 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1196 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1197 = add <8 x i64> %1196, splat (i64 40)
  %1198 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1195, 0
  %1199 = insertvalue { <8 x ptr>, <8 x i64> } %1198, <8 x i64> %1197, 1
  %1200 = extractvalue { <8 x ptr>, <8 x i64> } %1199, 0
  %1201 = extractvalue { <8 x ptr>, <8 x i64> } %1199, 1
  %1202 = getelementptr i8, <8 x ptr> %1200, <8 x i64> %1201
  %1203 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1202, <8 x i1> %80, <8 x float> zeroinitializer)
  %1204 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1205 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1206 = add <8 x i64> %1205, splat (i64 44)
  %1207 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1204, 0
  %1208 = insertvalue { <8 x ptr>, <8 x i64> } %1207, <8 x i64> %1206, 1
  %1209 = extractvalue { <8 x ptr>, <8 x i64> } %1208, 0
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %1208, 1
  %1211 = getelementptr i8, <8 x ptr> %1209, <8 x i64> %1210
  %1212 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1211, <8 x i1> %80, <8 x float> zeroinitializer)
  %1213 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1214 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1215 = add <8 x i64> %1214, splat (i64 48)
  %1216 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1213, 0
  %1217 = insertvalue { <8 x ptr>, <8 x i64> } %1216, <8 x i64> %1215, 1
  %1218 = extractvalue { <8 x ptr>, <8 x i64> } %1217, 0
  %1219 = extractvalue { <8 x ptr>, <8 x i64> } %1217, 1
  %1220 = getelementptr i8, <8 x ptr> %1218, <8 x i64> %1219
  %1221 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1220, <8 x i1> %80, <8 x float> zeroinitializer)
  %1222 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1223 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1224 = add <8 x i64> %1223, splat (i64 52)
  %1225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1222, 0
  %1226 = insertvalue { <8 x ptr>, <8 x i64> } %1225, <8 x i64> %1224, 1
  %1227 = extractvalue { <8 x ptr>, <8 x i64> } %1226, 0
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %1226, 1
  %1229 = getelementptr i8, <8 x ptr> %1227, <8 x i64> %1228
  %1230 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1229, <8 x i1> %80, <8 x float> zeroinitializer)
  %1231 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1233 = add <8 x i64> %1232, splat (i64 56)
  %1234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1231, 0
  %1235 = insertvalue { <8 x ptr>, <8 x i64> } %1234, <8 x i64> %1233, 1
  %1236 = extractvalue { <8 x ptr>, <8 x i64> } %1235, 0
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %1235, 1
  %1238 = getelementptr i8, <8 x ptr> %1236, <8 x i64> %1237
  %1239 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1238, <8 x i1> %80, <8 x float> zeroinitializer)
  %1240 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1241 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1242 = add <8 x i64> %1241, splat (i64 60)
  %1243 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1240, 0
  %1244 = insertvalue { <8 x ptr>, <8 x i64> } %1243, <8 x i64> %1242, 1
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %1244, 0
  %1246 = extractvalue { <8 x ptr>, <8 x i64> } %1244, 1
  %1247 = getelementptr i8, <8 x ptr> %1245, <8 x i64> %1246
  %1248 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1247, <8 x i1> %80, <8 x float> zeroinitializer)
  %1249 = fmul <8 x float> %1113, splat (float 0x3FB6A09E60000000)
  %1250 = fmul <8 x float> %1122, splat (float 0x3FB6A09E60000000)
  %1251 = fmul <8 x float> %1131, splat (float 0x3FB6A09E60000000)
  %1252 = fmul <8 x float> %1140, splat (float 0x3FB6A09E60000000)
  %1253 = fmul <8 x float> %1149, splat (float 0x3FB6A09E60000000)
  %1254 = fmul <8 x float> %1158, splat (float 0x3FB6A09E60000000)
  %1255 = fmul <8 x float> %1167, splat (float 0x3FB6A09E60000000)
  %1256 = fmul <8 x float> %1176, splat (float 0x3FB6A09E60000000)
  %1257 = fmul <8 x float> %1185, splat (float 0x3FB6A09E60000000)
  %1258 = fmul <8 x float> %1194, splat (float 0x3FB6A09E60000000)
  %1259 = fmul <8 x float> %1203, splat (float 0x3FB6A09E60000000)
  %1260 = fmul <8 x float> %1212, splat (float 0x3FB6A09E60000000)
  %1261 = fmul <8 x float> %1221, splat (float 0x3FB6A09E60000000)
  %1262 = fmul <8 x float> %1230, splat (float 0x3FB6A09E60000000)
  %1263 = fmul <8 x float> %1239, splat (float 0x3FB6A09E60000000)
  %1264 = fmul <8 x float> %1248, splat (float 0x3FB6A09E60000000)
  %.spill.load207 = load i64, ptr %.spill49, align 4
  %1265 = add i64 0, %.spill.load207
  %.spill.load208 = load i64, ptr %.spill49, align 4
  %1266 = add i64 1, %.spill.load208
  %.spill.load209 = load i64, ptr %.spill49, align 4
  %1267 = add i64 2, %.spill.load209
  %.spill.load210 = load i64, ptr %.spill49, align 4
  %1268 = add i64 3, %.spill.load210
  %.spill.load211 = load i64, ptr %.spill49, align 4
  %1269 = add i64 4, %.spill.load211
  %.spill.load212 = load i64, ptr %.spill49, align 4
  %1270 = add i64 5, %.spill.load212
  %.spill.load213 = load i64, ptr %.spill49, align 4
  %1271 = add i64 6, %.spill.load213
  %.spill.load214 = load i64, ptr %.spill49, align 4
  %1272 = add i64 7, %.spill.load214
  %.spill.load215 = load i64, ptr %.spill49, align 4
  %1273 = add i64 8, %.spill.load215
  %.spill.load216 = load i64, ptr %.spill49, align 4
  %1274 = add i64 9, %.spill.load216
  %.spill.load217 = load i64, ptr %.spill49, align 4
  %1275 = add i64 10, %.spill.load217
  %.spill.load218 = load i64, ptr %.spill49, align 4
  %1276 = add i64 11, %.spill.load218
  %.spill.load219 = load i64, ptr %.spill49, align 4
  %1277 = add i64 12, %.spill.load219
  %.spill.load220 = load i64, ptr %.spill49, align 4
  %1278 = add i64 13, %.spill.load220
  %.spill.load221 = load i64, ptr %.spill49, align 4
  %1279 = add i64 14, %.spill.load221
  %.spill.load222 = load i64, ptr %.spill49, align 4
  %1280 = add i64 15, %.spill.load222
  %1281 = icmp slt i64 %1265, 8193
  %1282 = icmp slt i64 %1266, 8193
  %1283 = icmp slt i64 %1267, 8193
  %1284 = icmp slt i64 %1268, 8193
  %1285 = icmp slt i64 %1269, 8193
  %1286 = icmp slt i64 %1270, 8193
  %1287 = icmp slt i64 %1271, 8193
  %1288 = icmp slt i64 %1272, 8193
  %1289 = icmp slt i64 %1273, 8193
  %1290 = icmp slt i64 %1274, 8193
  %1291 = icmp slt i64 %1275, 8193
  %1292 = icmp slt i64 %1276, 8193
  %1293 = icmp slt i64 %1277, 8193
  %1294 = icmp slt i64 %1278, 8193
  %1295 = icmp slt i64 %1279, 8193
  %1296 = icmp slt i64 %1280, 8193
  %.spill.load223 = load i64, ptr %.spill43, align 4
  %1297 = add i64 %.spill.load223, 8193
  %1298 = sub i64 %1297, 1
  %1299 = icmp sle i64 %1265, %1298
  %1300 = icmp sle i64 %1266, %1298
  %1301 = icmp sle i64 %1267, %1298
  %1302 = icmp sle i64 %1268, %1298
  %1303 = icmp sle i64 %1269, %1298
  %1304 = icmp sle i64 %1270, %1298
  %1305 = icmp sle i64 %1271, %1298
  %1306 = icmp sle i64 %1272, %1298
  %1307 = icmp sle i64 %1273, %1298
  %1308 = icmp sle i64 %1274, %1298
  %1309 = icmp sle i64 %1275, %1298
  %1310 = icmp sle i64 %1276, %1298
  %1311 = icmp sle i64 %1277, %1298
  %1312 = icmp sle i64 %1278, %1298
  %1313 = icmp sle i64 %1279, %1298
  %1314 = icmp sle i64 %1280, %1298
  %1315 = and i1 %1281, %1299
  store i1 %1315, ptr %.spill53, align 1
  %1316 = and i1 %1282, %1300
  store i1 %1316, ptr %.spill54, align 1
  %1317 = and i1 %1283, %1301
  store i1 %1317, ptr %.spill55, align 1
  %1318 = and i1 %1284, %1302
  store i1 %1318, ptr %.spill56, align 1
  %1319 = and i1 %1285, %1303
  store i1 %1319, ptr %.spill57, align 1
  %1320 = and i1 %1286, %1304
  store i1 %1320, ptr %.spill58, align 1
  %1321 = and i1 %1287, %1305
  store i1 %1321, ptr %.spill59, align 1
  %1322 = and i1 %1288, %1306
  store i1 %1322, ptr %.spill60, align 1
  %1323 = and i1 %1289, %1307
  store i1 %1323, ptr %.spill61, align 1
  %1324 = and i1 %1290, %1308
  store i1 %1324, ptr %.spill62, align 1
  %1325 = and i1 %1291, %1309
  store i1 %1325, ptr %.spill63, align 1
  %1326 = and i1 %1292, %1310
  store i1 %1326, ptr %.spill64, align 1
  %1327 = and i1 %1293, %1311
  store i1 %1327, ptr %.spill65, align 1
  %1328 = and i1 %1294, %1312
  store i1 %1328, ptr %.spill66, align 1
  %1329 = and i1 %1295, %1313
  store i1 %1329, ptr %.spill67, align 1
  %1330 = and i1 %1296, %1314
  store i1 %1330, ptr %.spill68, align 1
  %.splatinsert224 = insertelement <8 x i1> poison, i1 %1315, i64 0
  %.splat225 = shufflevector <8 x i1> %.splatinsert224, <8 x i1> poison, <8 x i32> zeroinitializer
  %1331 = select <8 x i1> %.splat225, <8 x float> %1249, <8 x float> splat (float 0xC6293E5940000000)
  %1332 = load <8 x float>, ptr %.spill69, align 32
  %1333 = select <8 x i1> %80, <8 x float> %1331, <8 x float> %1332
  store <8 x float> %1333, ptr %.spill69, align 32
  %.splatinsert226 = insertelement <8 x i1> poison, i1 %1316, i64 0
  %.splat227 = shufflevector <8 x i1> %.splatinsert226, <8 x i1> poison, <8 x i32> zeroinitializer
  %1334 = select <8 x i1> %.splat227, <8 x float> %1250, <8 x float> splat (float 0xC6293E5940000000)
  %1335 = load <8 x float>, ptr %.spill70, align 32
  %1336 = select <8 x i1> %80, <8 x float> %1334, <8 x float> %1335
  store <8 x float> %1336, ptr %.spill70, align 32
  %.splatinsert228 = insertelement <8 x i1> poison, i1 %1317, i64 0
  %.splat229 = shufflevector <8 x i1> %.splatinsert228, <8 x i1> poison, <8 x i32> zeroinitializer
  %1337 = select <8 x i1> %.splat229, <8 x float> %1251, <8 x float> splat (float 0xC6293E5940000000)
  %1338 = load <8 x float>, ptr %.spill71, align 32
  %1339 = select <8 x i1> %80, <8 x float> %1337, <8 x float> %1338
  store <8 x float> %1339, ptr %.spill71, align 32
  %.splatinsert230 = insertelement <8 x i1> poison, i1 %1318, i64 0
  %.splat231 = shufflevector <8 x i1> %.splatinsert230, <8 x i1> poison, <8 x i32> zeroinitializer
  %1340 = select <8 x i1> %.splat231, <8 x float> %1252, <8 x float> splat (float 0xC6293E5940000000)
  %1341 = load <8 x float>, ptr %.spill72, align 32
  %1342 = select <8 x i1> %80, <8 x float> %1340, <8 x float> %1341
  store <8 x float> %1342, ptr %.spill72, align 32
  %.splatinsert232 = insertelement <8 x i1> poison, i1 %1319, i64 0
  %.splat233 = shufflevector <8 x i1> %.splatinsert232, <8 x i1> poison, <8 x i32> zeroinitializer
  %1343 = select <8 x i1> %.splat233, <8 x float> %1253, <8 x float> splat (float 0xC6293E5940000000)
  %1344 = load <8 x float>, ptr %.spill73, align 32
  %1345 = select <8 x i1> %80, <8 x float> %1343, <8 x float> %1344
  store <8 x float> %1345, ptr %.spill73, align 32
  %.splatinsert234 = insertelement <8 x i1> poison, i1 %1320, i64 0
  %.splat235 = shufflevector <8 x i1> %.splatinsert234, <8 x i1> poison, <8 x i32> zeroinitializer
  %1346 = select <8 x i1> %.splat235, <8 x float> %1254, <8 x float> splat (float 0xC6293E5940000000)
  %1347 = load <8 x float>, ptr %.spill74, align 32
  %1348 = select <8 x i1> %80, <8 x float> %1346, <8 x float> %1347
  store <8 x float> %1348, ptr %.spill74, align 32
  %.splatinsert236 = insertelement <8 x i1> poison, i1 %1321, i64 0
  %.splat237 = shufflevector <8 x i1> %.splatinsert236, <8 x i1> poison, <8 x i32> zeroinitializer
  %1349 = select <8 x i1> %.splat237, <8 x float> %1255, <8 x float> splat (float 0xC6293E5940000000)
  %1350 = load <8 x float>, ptr %.spill75, align 32
  %1351 = select <8 x i1> %80, <8 x float> %1349, <8 x float> %1350
  store <8 x float> %1351, ptr %.spill75, align 32
  %.splatinsert238 = insertelement <8 x i1> poison, i1 %1322, i64 0
  %.splat239 = shufflevector <8 x i1> %.splatinsert238, <8 x i1> poison, <8 x i32> zeroinitializer
  %1352 = select <8 x i1> %.splat239, <8 x float> %1256, <8 x float> splat (float 0xC6293E5940000000)
  %1353 = load <8 x float>, ptr %.spill76, align 32
  %1354 = select <8 x i1> %80, <8 x float> %1352, <8 x float> %1353
  store <8 x float> %1354, ptr %.spill76, align 32
  %.splatinsert240 = insertelement <8 x i1> poison, i1 %1323, i64 0
  %.splat241 = shufflevector <8 x i1> %.splatinsert240, <8 x i1> poison, <8 x i32> zeroinitializer
  %1355 = select <8 x i1> %.splat241, <8 x float> %1257, <8 x float> splat (float 0xC6293E5940000000)
  %1356 = load <8 x float>, ptr %.spill77, align 32
  %1357 = select <8 x i1> %80, <8 x float> %1355, <8 x float> %1356
  store <8 x float> %1357, ptr %.spill77, align 32
  %.splatinsert242 = insertelement <8 x i1> poison, i1 %1324, i64 0
  %.splat243 = shufflevector <8 x i1> %.splatinsert242, <8 x i1> poison, <8 x i32> zeroinitializer
  %1358 = select <8 x i1> %.splat243, <8 x float> %1258, <8 x float> splat (float 0xC6293E5940000000)
  %1359 = load <8 x float>, ptr %.spill78, align 32
  %1360 = select <8 x i1> %80, <8 x float> %1358, <8 x float> %1359
  store <8 x float> %1360, ptr %.spill78, align 32
  %.splatinsert244 = insertelement <8 x i1> poison, i1 %1325, i64 0
  %.splat245 = shufflevector <8 x i1> %.splatinsert244, <8 x i1> poison, <8 x i32> zeroinitializer
  %1361 = select <8 x i1> %.splat245, <8 x float> %1259, <8 x float> splat (float 0xC6293E5940000000)
  %1362 = load <8 x float>, ptr %.spill79, align 32
  %1363 = select <8 x i1> %80, <8 x float> %1361, <8 x float> %1362
  store <8 x float> %1363, ptr %.spill79, align 32
  %.splatinsert246 = insertelement <8 x i1> poison, i1 %1326, i64 0
  %.splat247 = shufflevector <8 x i1> %.splatinsert246, <8 x i1> poison, <8 x i32> zeroinitializer
  %1364 = select <8 x i1> %.splat247, <8 x float> %1260, <8 x float> splat (float 0xC6293E5940000000)
  %1365 = load <8 x float>, ptr %.spill80, align 32
  %1366 = select <8 x i1> %80, <8 x float> %1364, <8 x float> %1365
  store <8 x float> %1366, ptr %.spill80, align 32
  %.splatinsert248 = insertelement <8 x i1> poison, i1 %1327, i64 0
  %.splat249 = shufflevector <8 x i1> %.splatinsert248, <8 x i1> poison, <8 x i32> zeroinitializer
  %1367 = select <8 x i1> %.splat249, <8 x float> %1261, <8 x float> splat (float 0xC6293E5940000000)
  %1368 = load <8 x float>, ptr %.spill81, align 32
  %1369 = select <8 x i1> %80, <8 x float> %1367, <8 x float> %1368
  store <8 x float> %1369, ptr %.spill81, align 32
  %.splatinsert250 = insertelement <8 x i1> poison, i1 %1328, i64 0
  %.splat251 = shufflevector <8 x i1> %.splatinsert250, <8 x i1> poison, <8 x i32> zeroinitializer
  %1370 = select <8 x i1> %.splat251, <8 x float> %1262, <8 x float> splat (float 0xC6293E5940000000)
  %1371 = load <8 x float>, ptr %.spill82, align 32
  %1372 = select <8 x i1> %80, <8 x float> %1370, <8 x float> %1371
  store <8 x float> %1372, ptr %.spill82, align 32
  %.splatinsert252 = insertelement <8 x i1> poison, i1 %1329, i64 0
  %.splat253 = shufflevector <8 x i1> %.splatinsert252, <8 x i1> poison, <8 x i32> zeroinitializer
  %1373 = select <8 x i1> %.splat253, <8 x float> %1263, <8 x float> splat (float 0xC6293E5940000000)
  %1374 = load <8 x float>, ptr %.spill83, align 32
  %1375 = select <8 x i1> %80, <8 x float> %1373, <8 x float> %1374
  store <8 x float> %1375, ptr %.spill83, align 32
  %.splatinsert254 = insertelement <8 x i1> poison, i1 %1330, i64 0
  %.splat255 = shufflevector <8 x i1> %.splatinsert254, <8 x i1> poison, <8 x i32> zeroinitializer
  %1376 = select <8 x i1> %.splat255, <8 x float> %1264, <8 x float> splat (float 0xC6293E5940000000)
  %1377 = load <8 x float>, ptr %.spill84, align 32
  %1378 = select <8 x i1> %80, <8 x float> %1376, <8 x float> %1377
  store <8 x float> %1378, ptr %.spill84, align 32
  %1379 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %1379, 0
  %1382 = select <8 x i1> %80, <8 x ptr> %1380, <8 x ptr> %1381
  %1383 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1384 = extractvalue { <8 x ptr>, <8 x i64> } %1379, 1
  %1385 = select <8 x i1> %80, <8 x i64> %1383, <8 x i64> %1384
  %1386 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1382, 0
  %1387 = insertvalue { <8 x ptr>, <8 x i64> } %1386, <8 x i64> %1385, 1
  store { <8 x ptr>, <8 x i64> } %1387, ptr %tile_snapshot.spill85, align 64
  %1388 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1389 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1390 = add <8 x i64> %1389, zeroinitializer
  %1391 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1388, 0
  %1392 = insertvalue { <8 x ptr>, <8 x i64> } %1391, <8 x i64> %1390, 1
  %1393 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1394 = extractvalue { <8 x ptr>, <8 x i64> } %1392, 1
  %1395 = extractelement <8 x ptr> %1393, i32 0
  %1396 = extractelement <8 x i64> %1394, i32 0
  %1397 = sub i64 %1396, 0
  %1398 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1399 = select i1 %1398, i64 %1397, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %1395, i64 %1399
  %private.contiguous.preserve257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %1400 = select <8 x i1> %80, <8 x float> %1331, <8 x float> %private.contiguous.preserve257
  store <8 x float> %1400, ptr %private.contiguous.address256, align 4
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1402 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1403 = add <8 x i64> %1402, splat (i64 32)
  %1404 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1401, 0
  %1405 = insertvalue { <8 x ptr>, <8 x i64> } %1404, <8 x i64> %1403, 1
  %1406 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %1405, 1
  %1408 = extractelement <8 x ptr> %1406, i32 0
  %1409 = extractelement <8 x i64> %1407, i32 0
  %1410 = sub i64 %1409, 0
  %1411 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1412 = select i1 %1411, i64 %1410, i64 0
  %private.contiguous.address258 = getelementptr i8, ptr %1408, i64 %1412
  %private.contiguous.preserve259 = load <8 x float>, ptr %private.contiguous.address258, align 4
  %1413 = select <8 x i1> %80, <8 x float> %1334, <8 x float> %private.contiguous.preserve259
  store <8 x float> %1413, ptr %private.contiguous.address258, align 4
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1416 = add <8 x i64> %1415, splat (i64 64)
  %1417 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1414, 0
  %1418 = insertvalue { <8 x ptr>, <8 x i64> } %1417, <8 x i64> %1416, 1
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %1418, 1
  %1421 = extractelement <8 x ptr> %1419, i32 0
  %1422 = extractelement <8 x i64> %1420, i32 0
  %1423 = sub i64 %1422, 0
  %1424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1425 = select i1 %1424, i64 %1423, i64 0
  %private.contiguous.address260 = getelementptr i8, ptr %1421, i64 %1425
  %private.contiguous.preserve261 = load <8 x float>, ptr %private.contiguous.address260, align 4
  %1426 = select <8 x i1> %80, <8 x float> %1337, <8 x float> %private.contiguous.preserve261
  store <8 x float> %1426, ptr %private.contiguous.address260, align 4
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1429 = add <8 x i64> %1428, splat (i64 96)
  %1430 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1427, 0
  %1431 = insertvalue { <8 x ptr>, <8 x i64> } %1430, <8 x i64> %1429, 1
  %1432 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %1431, 1
  %1434 = extractelement <8 x ptr> %1432, i32 0
  %1435 = extractelement <8 x i64> %1433, i32 0
  %1436 = sub i64 %1435, 0
  %1437 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1438 = select i1 %1437, i64 %1436, i64 0
  %private.contiguous.address262 = getelementptr i8, ptr %1434, i64 %1438
  %private.contiguous.preserve263 = load <8 x float>, ptr %private.contiguous.address262, align 4
  %1439 = select <8 x i1> %80, <8 x float> %1340, <8 x float> %private.contiguous.preserve263
  store <8 x float> %1439, ptr %private.contiguous.address262, align 4
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1442 = add <8 x i64> %1441, splat (i64 128)
  %1443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1440, 0
  %1444 = insertvalue { <8 x ptr>, <8 x i64> } %1443, <8 x i64> %1442, 1
  %1445 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1446 = extractvalue { <8 x ptr>, <8 x i64> } %1444, 1
  %1447 = extractelement <8 x ptr> %1445, i32 0
  %1448 = extractelement <8 x i64> %1446, i32 0
  %1449 = sub i64 %1448, 0
  %1450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1451 = select i1 %1450, i64 %1449, i64 0
  %private.contiguous.address264 = getelementptr i8, ptr %1447, i64 %1451
  %private.contiguous.preserve265 = load <8 x float>, ptr %private.contiguous.address264, align 4
  %1452 = select <8 x i1> %80, <8 x float> %1343, <8 x float> %private.contiguous.preserve265
  store <8 x float> %1452, ptr %private.contiguous.address264, align 4
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1455 = add <8 x i64> %1454, splat (i64 160)
  %1456 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1453, 0
  %1457 = insertvalue { <8 x ptr>, <8 x i64> } %1456, <8 x i64> %1455, 1
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 1
  %1460 = extractelement <8 x ptr> %1458, i32 0
  %1461 = extractelement <8 x i64> %1459, i32 0
  %1462 = sub i64 %1461, 0
  %1463 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1464 = select i1 %1463, i64 %1462, i64 0
  %private.contiguous.address266 = getelementptr i8, ptr %1460, i64 %1464
  %private.contiguous.preserve267 = load <8 x float>, ptr %private.contiguous.address266, align 4
  %1465 = select <8 x i1> %80, <8 x float> %1346, <8 x float> %private.contiguous.preserve267
  store <8 x float> %1465, ptr %private.contiguous.address266, align 4
  %1466 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1467 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1468 = add <8 x i64> %1467, splat (i64 192)
  %1469 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1466, 0
  %1470 = insertvalue { <8 x ptr>, <8 x i64> } %1469, <8 x i64> %1468, 1
  %1471 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %1470, 1
  %1473 = extractelement <8 x ptr> %1471, i32 0
  %1474 = extractelement <8 x i64> %1472, i32 0
  %1475 = sub i64 %1474, 0
  %1476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1477 = select i1 %1476, i64 %1475, i64 0
  %private.contiguous.address268 = getelementptr i8, ptr %1473, i64 %1477
  %private.contiguous.preserve269 = load <8 x float>, ptr %private.contiguous.address268, align 4
  %1478 = select <8 x i1> %80, <8 x float> %1349, <8 x float> %private.contiguous.preserve269
  store <8 x float> %1478, ptr %private.contiguous.address268, align 4
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1481 = add <8 x i64> %1480, splat (i64 224)
  %1482 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1479, 0
  %1483 = insertvalue { <8 x ptr>, <8 x i64> } %1482, <8 x i64> %1481, 1
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %1483, 1
  %1486 = extractelement <8 x ptr> %1484, i32 0
  %1487 = extractelement <8 x i64> %1485, i32 0
  %1488 = sub i64 %1487, 0
  %1489 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1490 = select i1 %1489, i64 %1488, i64 0
  %private.contiguous.address270 = getelementptr i8, ptr %1486, i64 %1490
  %private.contiguous.preserve271 = load <8 x float>, ptr %private.contiguous.address270, align 4
  %1491 = select <8 x i1> %80, <8 x float> %1352, <8 x float> %private.contiguous.preserve271
  store <8 x float> %1491, ptr %private.contiguous.address270, align 4
  %1492 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1493 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1494 = add <8 x i64> %1493, splat (i64 256)
  %1495 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1492, 0
  %1496 = insertvalue { <8 x ptr>, <8 x i64> } %1495, <8 x i64> %1494, 1
  %1497 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1498 = extractvalue { <8 x ptr>, <8 x i64> } %1496, 1
  %1499 = extractelement <8 x ptr> %1497, i32 0
  %1500 = extractelement <8 x i64> %1498, i32 0
  %1501 = sub i64 %1500, 0
  %1502 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1503 = select i1 %1502, i64 %1501, i64 0
  %private.contiguous.address272 = getelementptr i8, ptr %1499, i64 %1503
  %private.contiguous.preserve273 = load <8 x float>, ptr %private.contiguous.address272, align 4
  %1504 = select <8 x i1> %80, <8 x float> %1355, <8 x float> %private.contiguous.preserve273
  store <8 x float> %1504, ptr %private.contiguous.address272, align 4
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1506 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1507 = add <8 x i64> %1506, splat (i64 288)
  %1508 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1505, 0
  %1509 = insertvalue { <8 x ptr>, <8 x i64> } %1508, <8 x i64> %1507, 1
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %1509, 1
  %1512 = extractelement <8 x ptr> %1510, i32 0
  %1513 = extractelement <8 x i64> %1511, i32 0
  %1514 = sub i64 %1513, 0
  %1515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1516 = select i1 %1515, i64 %1514, i64 0
  %private.contiguous.address274 = getelementptr i8, ptr %1512, i64 %1516
  %private.contiguous.preserve275 = load <8 x float>, ptr %private.contiguous.address274, align 4
  %1517 = select <8 x i1> %80, <8 x float> %1358, <8 x float> %private.contiguous.preserve275
  store <8 x float> %1517, ptr %private.contiguous.address274, align 4
  %1518 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1519 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1520 = add <8 x i64> %1519, splat (i64 320)
  %1521 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1518, 0
  %1522 = insertvalue { <8 x ptr>, <8 x i64> } %1521, <8 x i64> %1520, 1
  %1523 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1524 = extractvalue { <8 x ptr>, <8 x i64> } %1522, 1
  %1525 = extractelement <8 x ptr> %1523, i32 0
  %1526 = extractelement <8 x i64> %1524, i32 0
  %1527 = sub i64 %1526, 0
  %1528 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1529 = select i1 %1528, i64 %1527, i64 0
  %private.contiguous.address276 = getelementptr i8, ptr %1525, i64 %1529
  %private.contiguous.preserve277 = load <8 x float>, ptr %private.contiguous.address276, align 4
  %1530 = select <8 x i1> %80, <8 x float> %1361, <8 x float> %private.contiguous.preserve277
  store <8 x float> %1530, ptr %private.contiguous.address276, align 4
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1532 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1533 = add <8 x i64> %1532, splat (i64 352)
  %1534 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1531, 0
  %1535 = insertvalue { <8 x ptr>, <8 x i64> } %1534, <8 x i64> %1533, 1
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %1535, 1
  %1538 = extractelement <8 x ptr> %1536, i32 0
  %1539 = extractelement <8 x i64> %1537, i32 0
  %1540 = sub i64 %1539, 0
  %1541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1542 = select i1 %1541, i64 %1540, i64 0
  %private.contiguous.address278 = getelementptr i8, ptr %1538, i64 %1542
  %private.contiguous.preserve279 = load <8 x float>, ptr %private.contiguous.address278, align 4
  %1543 = select <8 x i1> %80, <8 x float> %1364, <8 x float> %private.contiguous.preserve279
  store <8 x float> %1543, ptr %private.contiguous.address278, align 4
  %1544 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1545 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1546 = add <8 x i64> %1545, splat (i64 384)
  %1547 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1544, 0
  %1548 = insertvalue { <8 x ptr>, <8 x i64> } %1547, <8 x i64> %1546, 1
  %1549 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1550 = extractvalue { <8 x ptr>, <8 x i64> } %1548, 1
  %1551 = extractelement <8 x ptr> %1549, i32 0
  %1552 = extractelement <8 x i64> %1550, i32 0
  %1553 = sub i64 %1552, 0
  %1554 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1555 = select i1 %1554, i64 %1553, i64 0
  %private.contiguous.address280 = getelementptr i8, ptr %1551, i64 %1555
  %private.contiguous.preserve281 = load <8 x float>, ptr %private.contiguous.address280, align 4
  %1556 = select <8 x i1> %80, <8 x float> %1367, <8 x float> %private.contiguous.preserve281
  store <8 x float> %1556, ptr %private.contiguous.address280, align 4
  %1557 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1558 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1559 = add <8 x i64> %1558, splat (i64 416)
  %1560 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1557, 0
  %1561 = insertvalue { <8 x ptr>, <8 x i64> } %1560, <8 x i64> %1559, 1
  %1562 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %1561, 1
  %1564 = extractelement <8 x ptr> %1562, i32 0
  %1565 = extractelement <8 x i64> %1563, i32 0
  %1566 = sub i64 %1565, 0
  %1567 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1568 = select i1 %1567, i64 %1566, i64 0
  %private.contiguous.address282 = getelementptr i8, ptr %1564, i64 %1568
  %private.contiguous.preserve283 = load <8 x float>, ptr %private.contiguous.address282, align 4
  %1569 = select <8 x i1> %80, <8 x float> %1370, <8 x float> %private.contiguous.preserve283
  store <8 x float> %1569, ptr %private.contiguous.address282, align 4
  %1570 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1571 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1572 = add <8 x i64> %1571, splat (i64 448)
  %1573 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1570, 0
  %1574 = insertvalue { <8 x ptr>, <8 x i64> } %1573, <8 x i64> %1572, 1
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1576 = extractvalue { <8 x ptr>, <8 x i64> } %1574, 1
  %1577 = extractelement <8 x ptr> %1575, i32 0
  %1578 = extractelement <8 x i64> %1576, i32 0
  %1579 = sub i64 %1578, 0
  %1580 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1581 = select i1 %1580, i64 %1579, i64 0
  %private.contiguous.address284 = getelementptr i8, ptr %1577, i64 %1581
  %private.contiguous.preserve285 = load <8 x float>, ptr %private.contiguous.address284, align 4
  %1582 = select <8 x i1> %80, <8 x float> %1373, <8 x float> %private.contiguous.preserve285
  store <8 x float> %1582, ptr %private.contiguous.address284, align 4
  %1583 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1585 = add <8 x i64> %1584, splat (i64 480)
  %1586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1583, 0
  %1587 = insertvalue { <8 x ptr>, <8 x i64> } %1586, <8 x i64> %1585, 1
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %1587, 1
  %1590 = extractelement <8 x ptr> %1588, i32 0
  %1591 = extractelement <8 x i64> %1589, i32 0
  %1592 = sub i64 %1591, 0
  %1593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1594 = select i1 %1593, i64 %1592, i64 0
  %private.contiguous.address286 = getelementptr i8, ptr %1590, i64 %1594
  %private.contiguous.preserve287 = load <8 x float>, ptr %private.contiguous.address286, align 4
  %1595 = select <8 x i1> %80, <8 x float> %1376, <8 x float> %private.contiguous.preserve287
  store <8 x float> %1595, ptr %private.contiguous.address286, align 4
  store i64 0, ptr %.slot86, align 4
  %1596 = load <8 x float>, ptr %.slot87, align 32
  %1597 = select <8 x i1> %80, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %1596
  store <8 x float> %1597, ptr %.slot87, align 32
  br label %direct.schedule.10

direct.true289:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false290:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true384:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false385:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true396:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false397:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

mma.active413:                                    ; preds = %direct.schedule.18
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %1599 = extractelement <8 x ptr> %1598, i64 0
  %1600 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %1601 = extractelement <8 x i64> %1600, i64 0
  %1602 = getelementptr i8, ptr %1599, i64 %1601
  %1603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %1604 = extractelement <8 x ptr> %1603, i64 0
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %1606 = extractelement <8 x i64> %1605, i64 0
  %1607 = getelementptr i8, ptr %1604, i64 %1606
  %1608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %1609 = extractelement <8 x ptr> %1608, i64 0
  %1610 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %1611 = extractelement <8 x i64> %1610, i64 0
  %1612 = getelementptr i8, ptr %1609, i64 %1611
  %1613 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1614 = extractelement <8 x ptr> %1613, i64 0
  %1615 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1616 = extractelement <8 x i64> %1615, i64 0
  %1617 = getelementptr i8, ptr %1614, i64 %1616
  call void @llm_attention.strided_mma.3(ptr %1602, ptr %1607, ptr %1612, ptr %1617)
  br label %mma.continue414

mma.continue414:                                  ; preds = %mma.active413, %direct.schedule.18
  %1618 = extractelement <8 x i1> %80, i64 1
  br i1 %1618, label %mma.active415, label %mma.continue416

mma.active415:                                    ; preds = %mma.continue414
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %1620 = extractelement <8 x ptr> %1619, i64 1
  %1621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %1622 = extractelement <8 x i64> %1621, i64 1
  %1623 = getelementptr i8, ptr %1620, i64 %1622
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %1625 = extractelement <8 x ptr> %1624, i64 1
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %1627 = extractelement <8 x i64> %1626, i64 1
  %1628 = getelementptr i8, ptr %1625, i64 %1627
  %1629 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %1630 = extractelement <8 x ptr> %1629, i64 1
  %1631 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %1632 = extractelement <8 x i64> %1631, i64 1
  %1633 = getelementptr i8, ptr %1630, i64 %1632
  %1634 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1635 = extractelement <8 x ptr> %1634, i64 1
  %1636 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1637 = extractelement <8 x i64> %1636, i64 1
  %1638 = getelementptr i8, ptr %1635, i64 %1637
  call void @llm_attention.strided_mma.3(ptr %1623, ptr %1628, ptr %1633, ptr %1638)
  br label %mma.continue416

mma.continue416:                                  ; preds = %mma.active415, %mma.continue414
  %1639 = extractelement <8 x i1> %80, i64 2
  br i1 %1639, label %mma.active417, label %mma.continue418

mma.active417:                                    ; preds = %mma.continue416
  %1640 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %1641 = extractelement <8 x ptr> %1640, i64 2
  %1642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %1643 = extractelement <8 x i64> %1642, i64 2
  %1644 = getelementptr i8, ptr %1641, i64 %1643
  %1645 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %1646 = extractelement <8 x ptr> %1645, i64 2
  %1647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %1648 = extractelement <8 x i64> %1647, i64 2
  %1649 = getelementptr i8, ptr %1646, i64 %1648
  %1650 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %1651 = extractelement <8 x ptr> %1650, i64 2
  %1652 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %1653 = extractelement <8 x i64> %1652, i64 2
  %1654 = getelementptr i8, ptr %1651, i64 %1653
  %1655 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1656 = extractelement <8 x ptr> %1655, i64 2
  %1657 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1658 = extractelement <8 x i64> %1657, i64 2
  %1659 = getelementptr i8, ptr %1656, i64 %1658
  call void @llm_attention.strided_mma.3(ptr %1644, ptr %1649, ptr %1654, ptr %1659)
  br label %mma.continue418

mma.continue418:                                  ; preds = %mma.active417, %mma.continue416
  %1660 = extractelement <8 x i1> %80, i64 3
  br i1 %1660, label %mma.active419, label %mma.continue420

mma.active419:                                    ; preds = %mma.continue418
  %1661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %1662 = extractelement <8 x ptr> %1661, i64 3
  %1663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %1664 = extractelement <8 x i64> %1663, i64 3
  %1665 = getelementptr i8, ptr %1662, i64 %1664
  %1666 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %1667 = extractelement <8 x ptr> %1666, i64 3
  %1668 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %1669 = extractelement <8 x i64> %1668, i64 3
  %1670 = getelementptr i8, ptr %1667, i64 %1669
  %1671 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %1672 = extractelement <8 x ptr> %1671, i64 3
  %1673 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %1674 = extractelement <8 x i64> %1673, i64 3
  %1675 = getelementptr i8, ptr %1672, i64 %1674
  %1676 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1677 = extractelement <8 x ptr> %1676, i64 3
  %1678 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1679 = extractelement <8 x i64> %1678, i64 3
  %1680 = getelementptr i8, ptr %1677, i64 %1679
  call void @llm_attention.strided_mma.3(ptr %1665, ptr %1670, ptr %1675, ptr %1680)
  br label %mma.continue420

mma.continue420:                                  ; preds = %mma.active419, %mma.continue418
  %1681 = extractelement <8 x i1> %80, i64 4
  br i1 %1681, label %mma.active421, label %mma.continue422

mma.active421:                                    ; preds = %mma.continue420
  %1682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %1683 = extractelement <8 x ptr> %1682, i64 4
  %1684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %1685 = extractelement <8 x i64> %1684, i64 4
  %1686 = getelementptr i8, ptr %1683, i64 %1685
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %1688 = extractelement <8 x ptr> %1687, i64 4
  %1689 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %1690 = extractelement <8 x i64> %1689, i64 4
  %1691 = getelementptr i8, ptr %1688, i64 %1690
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %1693 = extractelement <8 x ptr> %1692, i64 4
  %1694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %1695 = extractelement <8 x i64> %1694, i64 4
  %1696 = getelementptr i8, ptr %1693, i64 %1695
  %1697 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1698 = extractelement <8 x ptr> %1697, i64 4
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1700 = extractelement <8 x i64> %1699, i64 4
  %1701 = getelementptr i8, ptr %1698, i64 %1700
  call void @llm_attention.strided_mma.3(ptr %1686, ptr %1691, ptr %1696, ptr %1701)
  br label %mma.continue422

mma.continue422:                                  ; preds = %mma.active421, %mma.continue420
  %1702 = extractelement <8 x i1> %80, i64 5
  br i1 %1702, label %mma.active423, label %mma.continue424

mma.active423:                                    ; preds = %mma.continue422
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %1704 = extractelement <8 x ptr> %1703, i64 5
  %1705 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %1706 = extractelement <8 x i64> %1705, i64 5
  %1707 = getelementptr i8, ptr %1704, i64 %1706
  %1708 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %1709 = extractelement <8 x ptr> %1708, i64 5
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %1711 = extractelement <8 x i64> %1710, i64 5
  %1712 = getelementptr i8, ptr %1709, i64 %1711
  %1713 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %1714 = extractelement <8 x ptr> %1713, i64 5
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %1716 = extractelement <8 x i64> %1715, i64 5
  %1717 = getelementptr i8, ptr %1714, i64 %1716
  %1718 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1719 = extractelement <8 x ptr> %1718, i64 5
  %1720 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1721 = extractelement <8 x i64> %1720, i64 5
  %1722 = getelementptr i8, ptr %1719, i64 %1721
  call void @llm_attention.strided_mma.3(ptr %1707, ptr %1712, ptr %1717, ptr %1722)
  br label %mma.continue424

mma.continue424:                                  ; preds = %mma.active423, %mma.continue422
  %1723 = extractelement <8 x i1> %80, i64 6
  br i1 %1723, label %mma.active425, label %mma.continue426

mma.active425:                                    ; preds = %mma.continue424
  %1724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %1725 = extractelement <8 x ptr> %1724, i64 6
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %1727 = extractelement <8 x i64> %1726, i64 6
  %1728 = getelementptr i8, ptr %1725, i64 %1727
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %1730 = extractelement <8 x ptr> %1729, i64 6
  %1731 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %1732 = extractelement <8 x i64> %1731, i64 6
  %1733 = getelementptr i8, ptr %1730, i64 %1732
  %1734 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %1735 = extractelement <8 x ptr> %1734, i64 6
  %1736 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %1737 = extractelement <8 x i64> %1736, i64 6
  %1738 = getelementptr i8, ptr %1735, i64 %1737
  %1739 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1740 = extractelement <8 x ptr> %1739, i64 6
  %1741 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1742 = extractelement <8 x i64> %1741, i64 6
  %1743 = getelementptr i8, ptr %1740, i64 %1742
  call void @llm_attention.strided_mma.3(ptr %1728, ptr %1733, ptr %1738, ptr %1743)
  br label %mma.continue426

mma.continue426:                                  ; preds = %mma.active425, %mma.continue424
  %1744 = extractelement <8 x i1> %80, i64 7
  br i1 %1744, label %mma.active427, label %mma.continue428

mma.active427:                                    ; preds = %mma.continue426
  %1745 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %1746 = extractelement <8 x ptr> %1745, i64 7
  %1747 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %1748 = extractelement <8 x i64> %1747, i64 7
  %1749 = getelementptr i8, ptr %1746, i64 %1748
  %1750 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %1751 = extractelement <8 x ptr> %1750, i64 7
  %1752 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %1753 = extractelement <8 x i64> %1752, i64 7
  %1754 = getelementptr i8, ptr %1751, i64 %1753
  %1755 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %1756 = extractelement <8 x ptr> %1755, i64 7
  %1757 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %1758 = extractelement <8 x i64> %1757, i64 7
  %1759 = getelementptr i8, ptr %1756, i64 %1758
  %1760 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1761 = extractelement <8 x ptr> %1760, i64 7
  %1762 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1763 = extractelement <8 x i64> %1762, i64 7
  %1764 = getelementptr i8, ptr %1761, i64 %1763
  call void @llm_attention.strided_mma.3(ptr %1749, ptr %1754, ptr %1759, ptr %1764)
  br label %mma.continue428

mma.continue428:                                  ; preds = %mma.active427, %mma.continue426
  store i64 0, ptr %.slot98, align 4
  br label %direct.schedule.19

direct.true430:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false431:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true444:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false445:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true463:                                   ; preds = %direct.schedule.26
  br label %direct.schedule.27

direct.false464:                                  ; preds = %direct.schedule.26
  br label %direct.schedule.9

direct.true476:                                   ; preds = %direct.schedule.27
  br label %direct.schedule.28

direct.false477:                                  ; preds = %direct.schedule.27
  %1765 = load <8 x float>, ptr %.slot102, align 32
  %1766 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %1765
  store <8 x float> %1766, ptr %.slot102, align 32
  br label %direct.schedule.29

direct.true486:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false487:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.7

direct.true499:                                   ; preds = %direct.schedule.32
  br label %direct.schedule.33

direct.false500:                                  ; preds = %direct.schedule.32
  %1767 = load <8 x float>, ptr %.slot105, align 32
  %1768 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %1767
  store <8 x float> %1768, ptr %.slot105, align 32
  br label %direct.schedule.34

direct.true509:                                   ; preds = %direct.schedule.36
  br label %direct.schedule.37

direct.false510:                                  ; preds = %direct.schedule.36
  br label %direct.schedule.38
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 32
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.1(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 512
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.2(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 512
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma(ptr %0, ptr %1, ptr %2, ptr %3) #3 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %39, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 16
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = urem i64 %mma.k, 16
  %6 = udiv i64 %mma.k, 16
  %7 = urem i64 %mma.k, 16
  %8 = mul i64 %7, 128
  %9 = add i64 0, %8
  %10 = udiv i64 %mma.k, 16
  %11 = getelementptr float, ptr %2, i64 %mma.k
  %12 = load float, ptr %11, align 4
  %13 = getelementptr float, ptr %0, i64 0
  %14 = load <4 x float>, ptr %13, align 4
  %15 = getelementptr float, ptr %1, i64 %9
  %16 = load <4 x float>, ptr %15, align 4
  %17 = fmul <4 x float> %14, %16
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.update2, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %29, %mma.update2 ]
  %mma.acc5 = phi <4 x float> [ %17, %mma.update ], [ %28, %mma.update2 ]
  %18 = icmp ult i64 %mma.k4, 31
  br i1 %18, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %19 = add i64 %mma.k4, 1
  %20 = mul i64 %19, 4
  %21 = add i64 0, %20
  %22 = getelementptr float, ptr %0, i64 %21
  %23 = load <4 x float>, ptr %22, align 4
  %24 = add i64 %9, %20
  %25 = getelementptr float, ptr %1, i64 %24
  %26 = load <4 x float>, ptr %25, align 4
  %27 = fmul <4 x float> %23, %26
  %28 = fadd <4 x float> %mma.acc5, %27
  %29 = add i64 %mma.k4, 1
  br label %mma.fold1

mma.fold.done3:                                   ; preds = %mma.fold1
  %30 = extractelement <4 x float> %mma.acc5, i64 0
  %31 = extractelement <4 x float> %mma.acc5, i64 1
  %32 = extractelement <4 x float> %mma.acc5, i64 2
  %33 = extractelement <4 x float> %mma.acc5, i64 3
  %34 = fadd float %30, %31
  %35 = fadd float %32, %33
  %36 = fadd float %34, %35
  %37 = fadd float %12, %36
  %38 = getelementptr float, ptr %3, i64 %mma.k
  store float %37, ptr %38, align 4
  %39 = add i64 %mma.k, 1
  br label %mma.fold
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #4

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #5

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #6 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.strided_mma.3(ptr %0, ptr %1, ptr %2, ptr %3) #3 {
entry:
  br label %mma.fold

mma.fold:                                         ; preds = %mma.fold.done3, %entry
  %mma.k = phi i64 [ 0, %entry ], [ %17, %mma.fold.done3 ]
  %mma.acc = phi i64 [ 0, %entry ], [ %mma.acc, %mma.fold.done3 ]
  %4 = icmp ult i64 %mma.k, 1
  br i1 %4, label %mma.update, label %mma.fold.done

mma.update:                                       ; preds = %mma.fold
  %5 = mul i64 %mma.k, 128
  br label %mma.fold1

mma.fold.done:                                    ; preds = %mma.fold
  ret void

mma.fold1:                                        ; preds = %mma.fold.done8, %mma.update
  %mma.k4 = phi i64 [ 0, %mma.update ], [ %31, %mma.fold.done8 ]
  %mma.acc5 = phi i64 [ 0, %mma.update ], [ %mma.acc5, %mma.fold.done8 ]
  %6 = icmp ult i64 %mma.k4, 32
  br i1 %6, label %mma.update2, label %mma.fold.done3

mma.update2:                                      ; preds = %mma.fold1
  %7 = mul i64 %mma.k4, 4
  %8 = add i64 %5, %7
  %9 = urem i64 %8, 128
  %10 = udiv i64 %8, 128
  %11 = urem i64 %8, 128
  %12 = mul i64 %11, 1
  %13 = add i64 0, %12
  %14 = udiv i64 %8, 128
  %15 = getelementptr float, ptr %2, i64 %8
  %16 = load <4 x float>, ptr %15, align 4
  br label %mma.fold6

mma.fold.done3:                                   ; preds = %mma.fold1
  %17 = add i64 %mma.k, 1
  br label %mma.fold

mma.fold6:                                        ; preds = %mma.update7, %mma.update2
  %mma.k9 = phi i64 [ 0, %mma.update2 ], [ %29, %mma.update7 ]
  %mma.acc10 = phi <4 x float> [ %16, %mma.update2 ], [ %28, %mma.update7 ]
  %18 = icmp ult i64 %mma.k9, 16
  br i1 %18, label %mma.update7, label %mma.fold.done8

mma.update7:                                      ; preds = %mma.fold6
  %19 = mul i64 %mma.k9, 1
  %20 = add i64 0, %19
  %21 = getelementptr float, ptr %0, i64 %20
  %22 = load float, ptr %21, align 4
  %.splatinsert = insertelement <4 x float> poison, float %22, i64 0
  %.splat = shufflevector <4 x float> %.splatinsert, <4 x float> poison, <4 x i32> zeroinitializer
  %23 = mul i64 %mma.k9, 128
  %24 = add i64 %13, %23
  %25 = getelementptr float, ptr %1, i64 %24
  %26 = load <4 x float>, ptr %25, align 4
  %27 = fmul <4 x float> %.splat, %26
  %28 = fadd <4 x float> %mma.acc10, %27
  %29 = add i64 %mma.k9, 1
  br label %mma.fold6

mma.fold.done8:                                   ; preds = %mma.fold6
  %30 = getelementptr float, ptr %3, i64 %8
  store <4 x float> %mma.acc10, ptr %30, align 4
  %31 = add i64 %mma.k4, 1
  br label %mma.fold1
}

define internal void @llm_attention.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %.splatinsert = insertelement <8 x ptr> poison, ptr %private.workspace, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 4096
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 8192
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 12288
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 77824
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 143360
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %16, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 143872
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %17 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %17, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 144384
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %18 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %19 = insertvalue { <8 x ptr>, <8 x i64> } %18, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %20 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %20, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 144896
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %21 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %22 = insertvalue { <8 x ptr>, <8 x i64> } %21, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>, 1
  %23 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %23, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 145408
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %24 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %25 = insertvalue { <8 x ptr>, <8 x i64> } %24, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %26 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %26, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 149504
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %27 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %28 = insertvalue { <8 x ptr>, <8 x i64> } %27, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill41 = alloca i64, align 8
  store i64 0, ptr %.spill41, align 4
  %.spill42 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill42, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill43 = alloca i64, align 8
  store i64 0, ptr %.spill43, align 4
  %tile_snapshot.spill44 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill44, align 64
  %tile_snapshot.spill45 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill45, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.spill49 = alloca i64, align 8
  store i64 0, ptr %.spill49, align 4
  %tile_snapshot.spill50 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill50, align 64
  %.spill51 = alloca i1, align 1
  store i1 false, ptr %.spill51, align 1
  %tile_snapshot.spill52 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill52, align 64
  %.spill53 = alloca i1, align 1
  store i1 false, ptr %.spill53, align 1
  %.spill54 = alloca i1, align 1
  store i1 false, ptr %.spill54, align 1
  %.spill55 = alloca i1, align 1
  store i1 false, ptr %.spill55, align 1
  %.spill56 = alloca i1, align 1
  store i1 false, ptr %.spill56, align 1
  %.spill57 = alloca i1, align 1
  store i1 false, ptr %.spill57, align 1
  %.spill58 = alloca i1, align 1
  store i1 false, ptr %.spill58, align 1
  %.spill59 = alloca i1, align 1
  store i1 false, ptr %.spill59, align 1
  %.spill60 = alloca i1, align 1
  store i1 false, ptr %.spill60, align 1
  %.spill61 = alloca i1, align 1
  store i1 false, ptr %.spill61, align 1
  %.spill62 = alloca i1, align 1
  store i1 false, ptr %.spill62, align 1
  %.spill63 = alloca i1, align 1
  store i1 false, ptr %.spill63, align 1
  %.spill64 = alloca i1, align 1
  store i1 false, ptr %.spill64, align 1
  %.spill65 = alloca i1, align 1
  store i1 false, ptr %.spill65, align 1
  %.spill66 = alloca i1, align 1
  store i1 false, ptr %.spill66, align 1
  %.spill67 = alloca i1, align 1
  store i1 false, ptr %.spill67, align 1
  %.spill68 = alloca i1, align 1
  store i1 false, ptr %.spill68, align 1
  %.spill69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill69, align 32
  %.spill70 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill70, align 32
  %.spill71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill71, align 32
  %.spill72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill72, align 32
  %.spill73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill73, align 32
  %.spill74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill74, align 32
  %.spill75 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill75, align 32
  %.spill76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill76, align 32
  %.spill77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill77, align 32
  %.spill78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill78, align 32
  %.spill79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill79, align 32
  %.spill80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill80, align 32
  %.spill81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill81, align 32
  %.spill82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill82, align 32
  %.spill83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill83, align 32
  %.spill84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill84, align 32
  %tile_snapshot.spill85 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill85, align 64
  %.slot86 = alloca i64, align 8
  store i64 0, ptr %.slot86, align 4
  %.slot87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot87, align 32
  %.spill88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill88, align 32
  %.spill89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill89, align 32
  %tile_snapshot.spill90 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill90, align 64
  %.spill91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill91, align 32
  %.slot92 = alloca i64, align 8
  store i64 0, ptr %.slot92, align 4
  %.slot93 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot93, align 32
  %.spill94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill94, align 32
  %tile_snapshot.spill95 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill95, align 64
  %.slot96 = alloca i64, align 8
  store i64 0, ptr %.slot96, align 4
  %tile_snapshot.spill97 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill97, align 64
  %.slot98 = alloca i64, align 8
  store i64 0, ptr %.slot98, align 4
  %.slot99 = alloca i64, align 8
  store i64 0, ptr %.slot99, align 4
  %.slot100 = alloca i64, align 8
  store i64 0, ptr %.slot100, align 4
  %.spill101 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill101, align 64
  %.slot102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot102, align 32
  %.slot103 = alloca i64, align 8
  store i64 0, ptr %.slot103, align 4
  %.spill104 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill104, align 64
  %.slot105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot105, align 32
  %.slot106 = alloca i64, align 8
  store i64 0, ptr %.slot106, align 4
  %29 = load ptr, ptr %argument_buffer, align 16
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %argument_buffer, i64 32
  %33 = load ptr, ptr %32, align 16
  %34 = getelementptr i8, ptr %argument_buffer, i64 48
  %35 = load ptr, ptr %34, align 16
  %36 = load i32, ptr %launch_config, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 36
  %38 = load i32, ptr %37, align 4
  %.splatinsert107 = insertelement <8 x i32> poison, i32 %38, i64 0
  %.splat108 = shufflevector <8 x i32> %.splatinsert107, <8 x i32> poison, <8 x i32> zeroinitializer
  %39 = add <8 x i32> %.splat108, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %40 = mul i32 %36, 32
  %.splatinsert109 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat110 = shufflevector <8 x i32> %.splatinsert109, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat110, %39
  br label %direct.activate

direct.schedule.0:                                ; preds = %direct.activate
  %42 = zext <8 x i32> %41 to <8 x i64>
  store <8 x i64> %42, ptr %.spill, align 64
  store i64 0, ptr %.spill41, align 4
  %43 = sdiv <8 x i64> %42, splat (i64 4)
  store <8 x i64> %43, ptr %.spill42, align 64
  store { <8 x ptr>, <8 x i64> } %2, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.spill43, align 4
  %44 = mul <8 x i64> %42, splat (i64 128)
  br label %copy.active

direct.schedule.1:                                ; preds = %copy.continue130, %direct.schedule.2
  %.state = load i64, ptr %.slot, align 4
  %45 = icmp slt i64 %.state, 128
  br i1 %45, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %46 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state131 = load i64, ptr %.slot, align 4
  %.splatinsert132 = insertelement <8 x i64> poison, i64 %.state131, i64 0
  %.splat133 = shufflevector <8 x i64> %.splatinsert132, <8 x i64> poison, <8 x i32> zeroinitializer
  %47 = mul <8 x i64> %.splat133, splat (i64 32)
  %48 = add <8 x i64> %46, %47
  %49 = extractelement <8 x i64> %48, i32 0
  %private.contiguous.address = getelementptr i8, ptr %tile_snapshot.private2, i64 %49
  store <8 x float> zeroinitializer, ptr %private.contiguous.address, align 4
  %.state134 = load i64, ptr %.slot, align 4
  %50 = add i64 %.state134, 1
  store i64 %50, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store i64 0, ptr %.slot46, align 4
  store <8 x float> splat (float 0xC6293E5940000000), ptr %.slot47, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.24, %direct.schedule.3
  %.state135 = load i64, ptr %.slot46, align 4
  %51 = icmp slt i64 %.state135, 513
  br i1 %51, label %direct.true136, label %direct.false137

direct.schedule.5:                                ; preds = %direct.true136
  %.state138 = load i64, ptr %.slot46, align 4
  %52 = mul i64 %.state138, 16
  store i64 %52, ptr %.spill49, align 4
  store { <8 x ptr>, <8 x i64> } %11, ptr %tile_snapshot.spill50, align 64
  %53 = icmp sge i64 %52, 0
  %54 = icmp sle i64 %52, 8177
  %55 = and i1 %53, %54
  store i1 %55, ptr %.spill51, align 1
  br i1 %55, label %direct.true139, label %direct.false140

direct.schedule.6:                                ; preds = %direct.true139
  %.spill.load = load i64, ptr %.spill43, align 4
  %56 = mul i64 %.spill.load, 4
  %.splatinsert141 = insertelement <8 x i64> poison, i64 %56, i64 0
  %.splat142 = shufflevector <8 x i64> %.splatinsert141, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load143 = load <8 x i64>, ptr %.spill42, align 64
  %57 = add <8 x i64> %.splat142, %.spill.load143
  %58 = mul <8 x i64> %57, splat (i64 8193)
  %.spill.load144 = load i64, ptr %.spill49, align 4
  %.splatinsert145 = insertelement <8 x i64> poison, i64 %.spill.load144, i64 0
  %.splat146 = shufflevector <8 x i64> %.splatinsert145, <8 x i64> poison, <8 x i32> zeroinitializer
  %59 = add <8 x i64> %58, %.splat146
  %60 = mul <8 x i64> %59, splat (i64 128)
  %tile_snapshot.spill.load147 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  br label %copy.active148

direct.schedule.7:                                ; preds = %direct.false487, %copy.continue163
  store { <8 x ptr>, <8 x i64> } %14, ptr %tile_snapshot.spill52, align 64
  %.spill.load164 = load i1, ptr %.spill51, align 1
  br i1 %.spill.load164, label %direct.true165, label %direct.false166

direct.schedule.8:                                ; preds = %direct.true165
  %.spill.load167 = load i64, ptr %.spill43, align 4
  %61 = mul i64 %.spill.load167, 4
  %.splatinsert168 = insertelement <8 x i64> poison, i64 %61, i64 0
  %.splat169 = shufflevector <8 x i64> %.splatinsert168, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load170 = load <8 x i64>, ptr %.spill42, align 64
  %62 = add <8 x i64> %.splat169, %.spill.load170
  %63 = mul <8 x i64> %62, splat (i64 8193)
  %.spill.load171 = load i64, ptr %.spill49, align 4
  %.splatinsert172 = insertelement <8 x i64> poison, i64 %.spill.load171, i64 0
  %.splat173 = shufflevector <8 x i64> %.splatinsert172, <8 x i64> poison, <8 x i32> zeroinitializer
  %64 = add <8 x i64> %63, %.splat173
  %65 = mul <8 x i64> %64, splat (i64 128)
  %tile_snapshot.spill.load174 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  br label %copy.active175

direct.schedule.9:                                ; preds = %direct.false464, %copy.continue190
  %66 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %66, <8 x i1> splat (i1 true))
  %67 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 4, i64 68, i64 132, i64 196, i64 260, i64 324, i64 388, i64 452>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %67, <8 x i1> splat (i1 true))
  %68 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 8, i64 72, i64 136, i64 200, i64 264, i64 328, i64 392, i64 456>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %68, <8 x i1> splat (i1 true))
  %69 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 12, i64 76, i64 140, i64 204, i64 268, i64 332, i64 396, i64 460>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %69, <8 x i1> splat (i1 true))
  %70 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 16, i64 80, i64 144, i64 208, i64 272, i64 336, i64 400, i64 464>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %70, <8 x i1> splat (i1 true))
  %71 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 20, i64 84, i64 148, i64 212, i64 276, i64 340, i64 404, i64 468>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %71, <8 x i1> splat (i1 true))
  %72 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 24, i64 88, i64 152, i64 216, i64 280, i64 344, i64 408, i64 472>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %72, <8 x i1> splat (i1 true))
  %73 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 28, i64 92, i64 156, i64 220, i64 284, i64 348, i64 412, i64 476>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %73, <8 x i1> splat (i1 true))
  %74 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 32, i64 96, i64 160, i64 224, i64 288, i64 352, i64 416, i64 480>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %74, <8 x i1> splat (i1 true))
  %75 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 36, i64 100, i64 164, i64 228, i64 292, i64 356, i64 420, i64 484>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %75, <8 x i1> splat (i1 true))
  %76 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 40, i64 104, i64 168, i64 232, i64 296, i64 360, i64 424, i64 488>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %76, <8 x i1> splat (i1 true))
  %77 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 44, i64 108, i64 172, i64 236, i64 300, i64 364, i64 428, i64 492>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %77, <8 x i1> splat (i1 true))
  %78 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 48, i64 112, i64 176, i64 240, i64 304, i64 368, i64 432, i64 496>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %78, <8 x i1> splat (i1 true))
  %79 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 52, i64 116, i64 180, i64 244, i64 308, i64 372, i64 436, i64 500>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %79, <8 x i1> splat (i1 true))
  %80 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 56, i64 120, i64 184, i64 248, i64 312, i64 376, i64 440, i64 504>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %80, <8 x i1> splat (i1 true))
  %81 = getelementptr i8, <8 x ptr> %.splat20, <8 x i64> <i64 60, i64 124, i64 188, i64 252, i64 316, i64 380, i64 444, i64 508>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %81, <8 x i1> splat (i1 true))
  %tile_snapshot.spill.load191 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  br label %mma.active

direct.schedule.10:                               ; preds = %mma.continue206, %direct.schedule.11
  %.state288 = load i64, ptr %.slot86, align 4
  %82 = icmp slt i64 %.state288, 16
  br i1 %82, label %direct.true289, label %direct.false290

direct.schedule.11:                               ; preds = %direct.true289
  %.state291 = load i64, ptr %.slot86, align 4
  %.spill.load292 = load i64, ptr %.spill43, align 4
  %83 = mul i64 %.spill.load292, 16
  %84 = add i64 %83, %.state291
  %tile_snapshot.spill.load293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill85, align 64
  %85 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 1
  %.splatinsert294 = insertelement <8 x i64> poison, i64 %84, i64 0
  %.splat295 = shufflevector <8 x i64> %.splatinsert294, <8 x i64> poison, <8 x i32> zeroinitializer
  %86 = mul <8 x i64> %.splat295, splat (i64 32)
  %87 = add <8 x i64> %85, %86
  %88 = extractelement <8 x i64> %87, i32 0
  %private.contiguous.address296 = getelementptr i8, ptr %tile_snapshot.private26, i64 %88
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address296, align 4
  %.state297 = load <8 x float>, ptr %.slot87, align 32
  %89 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state297, <8 x float> %private.contiguous.load)
  %.state298 = load i64, ptr %.slot86, align 4
  %90 = add i64 %.state298, 1
  store i64 %90, ptr %.slot86, align 4
  store <8 x float> %89, ptr %.slot87, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false290
  %.state299 = load <8 x float>, ptr %.slot47, align 32
  %.state300 = load <8 x float>, ptr %.slot87, align 32
  %91 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state299, <8 x float> %.state300)
  store <8 x float> %91, ptr %.spill88, align 32
  %.state301 = load <8 x float>, ptr %.slot47, align 32
  %92 = fsub <8 x float> %.state301, %91
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %92)
  store <8 x float> %native.exp, ptr %.spill89, align 32
  %.spill.load302 = load <8 x float>, ptr %.spill69, align 32
  %93 = fsub <8 x float> %.spill.load302, %91
  %.spill.load303 = load <8 x float>, ptr %.spill70, align 32
  %94 = fsub <8 x float> %.spill.load303, %91
  %.spill.load304 = load <8 x float>, ptr %.spill71, align 32
  %95 = fsub <8 x float> %.spill.load304, %91
  %.spill.load305 = load <8 x float>, ptr %.spill72, align 32
  %96 = fsub <8 x float> %.spill.load305, %91
  %.spill.load306 = load <8 x float>, ptr %.spill73, align 32
  %97 = fsub <8 x float> %.spill.load306, %91
  %.spill.load307 = load <8 x float>, ptr %.spill74, align 32
  %98 = fsub <8 x float> %.spill.load307, %91
  %.spill.load308 = load <8 x float>, ptr %.spill75, align 32
  %99 = fsub <8 x float> %.spill.load308, %91
  %.spill.load309 = load <8 x float>, ptr %.spill76, align 32
  %100 = fsub <8 x float> %.spill.load309, %91
  %.spill.load310 = load <8 x float>, ptr %.spill77, align 32
  %101 = fsub <8 x float> %.spill.load310, %91
  %.spill.load311 = load <8 x float>, ptr %.spill78, align 32
  %102 = fsub <8 x float> %.spill.load311, %91
  %.spill.load312 = load <8 x float>, ptr %.spill79, align 32
  %103 = fsub <8 x float> %.spill.load312, %91
  %.spill.load313 = load <8 x float>, ptr %.spill80, align 32
  %104 = fsub <8 x float> %.spill.load313, %91
  %.spill.load314 = load <8 x float>, ptr %.spill81, align 32
  %105 = fsub <8 x float> %.spill.load314, %91
  %.spill.load315 = load <8 x float>, ptr %.spill82, align 32
  %106 = fsub <8 x float> %.spill.load315, %91
  %.spill.load316 = load <8 x float>, ptr %.spill83, align 32
  %107 = fsub <8 x float> %.spill.load316, %91
  %.spill.load317 = load <8 x float>, ptr %.spill84, align 32
  %108 = fsub <8 x float> %.spill.load317, %91
  %native.exp318 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %93)
  %native.exp319 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %94)
  %native.exp320 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %95)
  %native.exp321 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %96)
  %native.exp322 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %97)
  %native.exp323 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %98)
  %native.exp324 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %99)
  %native.exp325 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %100)
  %native.exp326 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %101)
  %native.exp327 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %102)
  %native.exp328 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %103)
  %native.exp329 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %104)
  %native.exp330 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %105)
  %native.exp331 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %106)
  %native.exp332 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %107)
  %native.exp333 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %108)
  %.spill.load334 = load i1, ptr %.spill53, align 1
  %.splatinsert335 = insertelement <8 x i1> poison, i1 %.spill.load334, i64 0
  %.splat336 = shufflevector <8 x i1> %.splatinsert335, <8 x i1> poison, <8 x i32> zeroinitializer
  %109 = select <8 x i1> %.splat336, <8 x float> %native.exp318, <8 x float> zeroinitializer
  %.spill.load337 = load i1, ptr %.spill54, align 1
  %.splatinsert338 = insertelement <8 x i1> poison, i1 %.spill.load337, i64 0
  %.splat339 = shufflevector <8 x i1> %.splatinsert338, <8 x i1> poison, <8 x i32> zeroinitializer
  %110 = select <8 x i1> %.splat339, <8 x float> %native.exp319, <8 x float> zeroinitializer
  %.spill.load340 = load i1, ptr %.spill55, align 1
  %.splatinsert341 = insertelement <8 x i1> poison, i1 %.spill.load340, i64 0
  %.splat342 = shufflevector <8 x i1> %.splatinsert341, <8 x i1> poison, <8 x i32> zeroinitializer
  %111 = select <8 x i1> %.splat342, <8 x float> %native.exp320, <8 x float> zeroinitializer
  %.spill.load343 = load i1, ptr %.spill56, align 1
  %.splatinsert344 = insertelement <8 x i1> poison, i1 %.spill.load343, i64 0
  %.splat345 = shufflevector <8 x i1> %.splatinsert344, <8 x i1> poison, <8 x i32> zeroinitializer
  %112 = select <8 x i1> %.splat345, <8 x float> %native.exp321, <8 x float> zeroinitializer
  %.spill.load346 = load i1, ptr %.spill57, align 1
  %.splatinsert347 = insertelement <8 x i1> poison, i1 %.spill.load346, i64 0
  %.splat348 = shufflevector <8 x i1> %.splatinsert347, <8 x i1> poison, <8 x i32> zeroinitializer
  %113 = select <8 x i1> %.splat348, <8 x float> %native.exp322, <8 x float> zeroinitializer
  %.spill.load349 = load i1, ptr %.spill58, align 1
  %.splatinsert350 = insertelement <8 x i1> poison, i1 %.spill.load349, i64 0
  %.splat351 = shufflevector <8 x i1> %.splatinsert350, <8 x i1> poison, <8 x i32> zeroinitializer
  %114 = select <8 x i1> %.splat351, <8 x float> %native.exp323, <8 x float> zeroinitializer
  %.spill.load352 = load i1, ptr %.spill59, align 1
  %.splatinsert353 = insertelement <8 x i1> poison, i1 %.spill.load352, i64 0
  %.splat354 = shufflevector <8 x i1> %.splatinsert353, <8 x i1> poison, <8 x i32> zeroinitializer
  %115 = select <8 x i1> %.splat354, <8 x float> %native.exp324, <8 x float> zeroinitializer
  %.spill.load355 = load i1, ptr %.spill60, align 1
  %.splatinsert356 = insertelement <8 x i1> poison, i1 %.spill.load355, i64 0
  %.splat357 = shufflevector <8 x i1> %.splatinsert356, <8 x i1> poison, <8 x i32> zeroinitializer
  %116 = select <8 x i1> %.splat357, <8 x float> %native.exp325, <8 x float> zeroinitializer
  %.spill.load358 = load i1, ptr %.spill61, align 1
  %.splatinsert359 = insertelement <8 x i1> poison, i1 %.spill.load358, i64 0
  %.splat360 = shufflevector <8 x i1> %.splatinsert359, <8 x i1> poison, <8 x i32> zeroinitializer
  %117 = select <8 x i1> %.splat360, <8 x float> %native.exp326, <8 x float> zeroinitializer
  %.spill.load361 = load i1, ptr %.spill62, align 1
  %.splatinsert362 = insertelement <8 x i1> poison, i1 %.spill.load361, i64 0
  %.splat363 = shufflevector <8 x i1> %.splatinsert362, <8 x i1> poison, <8 x i32> zeroinitializer
  %118 = select <8 x i1> %.splat363, <8 x float> %native.exp327, <8 x float> zeroinitializer
  %.spill.load364 = load i1, ptr %.spill63, align 1
  %.splatinsert365 = insertelement <8 x i1> poison, i1 %.spill.load364, i64 0
  %.splat366 = shufflevector <8 x i1> %.splatinsert365, <8 x i1> poison, <8 x i32> zeroinitializer
  %119 = select <8 x i1> %.splat366, <8 x float> %native.exp328, <8 x float> zeroinitializer
  %.spill.load367 = load i1, ptr %.spill64, align 1
  %.splatinsert368 = insertelement <8 x i1> poison, i1 %.spill.load367, i64 0
  %.splat369 = shufflevector <8 x i1> %.splatinsert368, <8 x i1> poison, <8 x i32> zeroinitializer
  %120 = select <8 x i1> %.splat369, <8 x float> %native.exp329, <8 x float> zeroinitializer
  %.spill.load370 = load i1, ptr %.spill65, align 1
  %.splatinsert371 = insertelement <8 x i1> poison, i1 %.spill.load370, i64 0
  %.splat372 = shufflevector <8 x i1> %.splatinsert371, <8 x i1> poison, <8 x i32> zeroinitializer
  %121 = select <8 x i1> %.splat372, <8 x float> %native.exp330, <8 x float> zeroinitializer
  %.spill.load373 = load i1, ptr %.spill66, align 1
  %.splatinsert374 = insertelement <8 x i1> poison, i1 %.spill.load373, i64 0
  %.splat375 = shufflevector <8 x i1> %.splatinsert374, <8 x i1> poison, <8 x i32> zeroinitializer
  %122 = select <8 x i1> %.splat375, <8 x float> %native.exp331, <8 x float> zeroinitializer
  %.spill.load376 = load i1, ptr %.spill67, align 1
  %.splatinsert377 = insertelement <8 x i1> poison, i1 %.spill.load376, i64 0
  %.splat378 = shufflevector <8 x i1> %.splatinsert377, <8 x i1> poison, <8 x i32> zeroinitializer
  %123 = select <8 x i1> %.splat378, <8 x float> %native.exp332, <8 x float> zeroinitializer
  %.spill.load379 = load i1, ptr %.spill68, align 1
  %.splatinsert380 = insertelement <8 x i1> poison, i1 %.spill.load379, i64 0
  %.splat381 = shufflevector <8 x i1> %.splatinsert380, <8 x i1> poison, <8 x i32> zeroinitializer
  %124 = select <8 x i1> %.splat381, <8 x float> %native.exp333, <8 x float> zeroinitializer
  store { <8 x ptr>, <8 x i64> } %22, ptr %tile_snapshot.spill90, align 64
  %125 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %109, <8 x ptr> align 1 %125, <8 x i1> splat (i1 true))
  %126 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 4, i64 68, i64 132, i64 196, i64 260, i64 324, i64 388, i64 452>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %110, <8 x ptr> align 1 %126, <8 x i1> splat (i1 true))
  %127 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 8, i64 72, i64 136, i64 200, i64 264, i64 328, i64 392, i64 456>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %111, <8 x ptr> align 1 %127, <8 x i1> splat (i1 true))
  %128 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 12, i64 76, i64 140, i64 204, i64 268, i64 332, i64 396, i64 460>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %112, <8 x ptr> align 1 %128, <8 x i1> splat (i1 true))
  %129 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 16, i64 80, i64 144, i64 208, i64 272, i64 336, i64 400, i64 464>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %113, <8 x ptr> align 1 %129, <8 x i1> splat (i1 true))
  %130 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 20, i64 84, i64 148, i64 212, i64 276, i64 340, i64 404, i64 468>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %114, <8 x ptr> align 1 %130, <8 x i1> splat (i1 true))
  %131 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 24, i64 88, i64 152, i64 216, i64 280, i64 344, i64 408, i64 472>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %115, <8 x ptr> align 1 %131, <8 x i1> splat (i1 true))
  %132 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 28, i64 92, i64 156, i64 220, i64 284, i64 348, i64 412, i64 476>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %116, <8 x ptr> align 1 %132, <8 x i1> splat (i1 true))
  %133 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 32, i64 96, i64 160, i64 224, i64 288, i64 352, i64 416, i64 480>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %117, <8 x ptr> align 1 %133, <8 x i1> splat (i1 true))
  %134 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 36, i64 100, i64 164, i64 228, i64 292, i64 356, i64 420, i64 484>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %118, <8 x ptr> align 1 %134, <8 x i1> splat (i1 true))
  %135 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 40, i64 104, i64 168, i64 232, i64 296, i64 360, i64 424, i64 488>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %119, <8 x ptr> align 1 %135, <8 x i1> splat (i1 true))
  %136 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 44, i64 108, i64 172, i64 236, i64 300, i64 364, i64 428, i64 492>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %120, <8 x ptr> align 1 %136, <8 x i1> splat (i1 true))
  %137 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 48, i64 112, i64 176, i64 240, i64 304, i64 368, i64 432, i64 496>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %121, <8 x ptr> align 1 %137, <8 x i1> splat (i1 true))
  %138 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 52, i64 116, i64 180, i64 244, i64 308, i64 372, i64 436, i64 500>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %122, <8 x ptr> align 1 %138, <8 x i1> splat (i1 true))
  %139 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 56, i64 120, i64 184, i64 248, i64 312, i64 376, i64 440, i64 504>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %123, <8 x ptr> align 1 %139, <8 x i1> splat (i1 true))
  %140 = getelementptr i8, <8 x ptr> %.splat32, <8 x i64> <i64 60, i64 124, i64 188, i64 252, i64 316, i64 380, i64 444, i64 508>
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %124, <8 x ptr> align 1 %140, <8 x i1> splat (i1 true))
  %.state382 = load <8 x float>, ptr %.slot48, align 32
  %141 = fmul <8 x float> %.state382, %native.exp
  store <8 x float> %141, ptr %.spill91, align 32
  store i64 0, ptr %.slot92, align 4
  store <8 x float> zeroinitializer, ptr %.slot93, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state383 = load i64, ptr %.slot92, align 4
  %142 = icmp slt i64 %.state383, 16
  br i1 %142, label %direct.true384, label %direct.false385

direct.schedule.14:                               ; preds = %direct.true384
  %.state386 = load i64, ptr %.slot92, align 4
  %.spill.load387 = load i64, ptr %.spill43, align 4
  %143 = mul i64 %.spill.load387, 16
  %144 = add i64 %143, %.state386
  %tile_snapshot.spill.load388 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load388, 1
  %.splatinsert389 = insertelement <8 x i64> poison, i64 %144, i64 0
  %.splat390 = shufflevector <8 x i64> %.splatinsert389, <8 x i64> poison, <8 x i32> zeroinitializer
  %146 = mul <8 x i64> %.splat390, splat (i64 4)
  %147 = add <8 x i64> %145, %146
  %148 = insertvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load388, <8 x i64> %147, 1
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %148, 0
  %150 = getelementptr i8, <8 x ptr> %149, <8 x i64> %147
  %151 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %150, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %.state391 = load <8 x float>, ptr %.slot93, align 32
  %152 = fadd <8 x float> %.state391, %151
  %.state392 = load i64, ptr %.slot92, align 4
  %153 = add i64 %.state392, 1
  store i64 %153, ptr %.slot92, align 4
  store <8 x float> %152, ptr %.slot93, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false385
  %.spill.load393 = load <8 x float>, ptr %.spill91, align 32
  %.state394 = load <8 x float>, ptr %.slot93, align 32
  %154 = fadd <8 x float> %.spill.load393, %.state394
  store <8 x float> %154, ptr %.spill94, align 32
  store { <8 x ptr>, <8 x i64> } %25, ptr %tile_snapshot.spill95, align 64
  store i64 0, ptr %.slot96, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state395 = load i64, ptr %.slot96, align 4
  %155 = icmp slt i64 %.state395, 128
  br i1 %155, label %direct.true396, label %direct.false397

direct.schedule.17:                               ; preds = %direct.true396
  %.state398 = load i64, ptr %.slot96, align 4
  %tile_snapshot.spill.load399 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load399, 1
  %.splatinsert400 = insertelement <8 x i64> poison, i64 %.state398, i64 0
  %.splat401 = shufflevector <8 x i64> %.splatinsert400, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = mul <8 x i64> %.splat401, splat (i64 32)
  %158 = add <8 x i64> %156, %157
  %159 = extractelement <8 x i64> %158, i32 0
  %private.contiguous.address402 = getelementptr i8, ptr %tile_snapshot.private2, i64 %159
  %private.contiguous.load403 = load <8 x float>, ptr %private.contiguous.address402, align 4
  %.spill.load404 = load <8 x float>, ptr %.spill89, align 32
  %160 = fmul <8 x float> %private.contiguous.load403, %.spill.load404
  %tile_snapshot.spill.load405 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load405, 1
  %.state406 = load i64, ptr %.slot96, align 4
  %.splatinsert407 = insertelement <8 x i64> poison, i64 %.state406, i64 0
  %.splat408 = shufflevector <8 x i64> %.splatinsert407, <8 x i64> poison, <8 x i32> zeroinitializer
  %162 = mul <8 x i64> %.splat408, splat (i64 4)
  %163 = add <8 x i64> %161, %162
  %164 = insertvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load405, <8 x i64> %163, 1
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %164, 0
  %166 = getelementptr i8, <8 x ptr> %165, <8 x i64> %163
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %160, <8 x ptr> align 1 %166, <8 x i1> splat (i1 true))
  %.state409 = load i64, ptr %.slot96, align 4
  %167 = add i64 %.state409, 1
  store i64 %167, ptr %.slot96, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false397
  store { <8 x ptr>, <8 x i64> } %28, ptr %tile_snapshot.spill97, align 64
  %tile_snapshot.spill.load410 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill90, align 64
  %tile_snapshot.spill.load411 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %tile_snapshot.spill.load412 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill95, align 64
  br label %mma.active413

direct.schedule.19:                               ; preds = %mma.continue428, %direct.schedule.20
  %.state429 = load i64, ptr %.slot98, align 4
  %168 = icmp slt i64 %.state429, 128
  br i1 %168, label %direct.true430, label %direct.false431

direct.schedule.20:                               ; preds = %direct.true430
  %tile_snapshot.spill.load432 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill97, align 64
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load432, 1
  %.state433 = load i64, ptr %.slot98, align 4
  %.splatinsert434 = insertelement <8 x i64> poison, i64 %.state433, i64 0
  %.splat435 = shufflevector <8 x i64> %.splatinsert434, <8 x i64> poison, <8 x i32> zeroinitializer
  %170 = mul <8 x i64> %.splat435, splat (i64 4)
  %171 = add <8 x i64> %169, %170
  %172 = insertvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load432, <8 x i64> %171, 1
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %172, 0
  %174 = getelementptr i8, <8 x ptr> %173, <8 x i64> %171
  %175 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %174, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %tile_snapshot.spill.load436 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load436, 1
  %.state437 = load i64, ptr %.slot98, align 4
  %.splatinsert438 = insertelement <8 x i64> poison, i64 %.state437, i64 0
  %.splat439 = shufflevector <8 x i64> %.splatinsert438, <8 x i64> poison, <8 x i32> zeroinitializer
  %177 = mul <8 x i64> %.splat439, splat (i64 32)
  %178 = add <8 x i64> %176, %177
  %179 = extractelement <8 x i64> %178, i32 0
  %private.contiguous.address440 = getelementptr i8, ptr %tile_snapshot.private6, i64 %179
  store <8 x float> %175, ptr %private.contiguous.address440, align 4
  %.state442 = load i64, ptr %.slot98, align 4
  %180 = add i64 %.state442, 1
  store i64 %180, ptr %.slot98, align 4
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false431
  store i64 0, ptr %.slot99, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state443 = load i64, ptr %.slot99, align 4
  %181 = icmp slt i64 %.state443, 128
  br i1 %181, label %direct.true444, label %direct.false445

direct.schedule.23:                               ; preds = %direct.true444
  %tile_snapshot.spill.load446 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill45, align 64
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load446, 1
  %.state447 = load i64, ptr %.slot99, align 4
  %.splatinsert448 = insertelement <8 x i64> poison, i64 %.state447, i64 0
  %.splat449 = shufflevector <8 x i64> %.splatinsert448, <8 x i64> poison, <8 x i32> zeroinitializer
  %183 = mul <8 x i64> %.splat449, splat (i64 32)
  %184 = add <8 x i64> %182, %183
  %185 = extractelement <8 x i64> %184, i32 0
  %private.contiguous.address450 = getelementptr i8, ptr %tile_snapshot.private6, i64 %185
  %private.contiguous.load451 = load <8 x float>, ptr %private.contiguous.address450, align 4
  %tile_snapshot.spill.load452 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load452, 1
  %.state453 = load i64, ptr %.slot99, align 4
  %.splatinsert454 = insertelement <8 x i64> poison, i64 %.state453, i64 0
  %.splat455 = shufflevector <8 x i64> %.splatinsert454, <8 x i64> poison, <8 x i32> zeroinitializer
  %187 = mul <8 x i64> %.splat455, splat (i64 32)
  %188 = add <8 x i64> %186, %187
  %189 = extractelement <8 x i64> %188, i32 0
  %private.contiguous.address456 = getelementptr i8, ptr %tile_snapshot.private2, i64 %189
  store <8 x float> %private.contiguous.load451, ptr %private.contiguous.address456, align 4
  %.state458 = load i64, ptr %.slot99, align 4
  %190 = add i64 %.state458, 1
  store i64 %190, ptr %.slot99, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false445
  %.state459 = load i64, ptr %.slot46, align 4
  %191 = add i64 %.state459, 1
  %.spill.load460 = load <8 x float>, ptr %.spill88, align 32
  %.spill.load461 = load <8 x float>, ptr %.spill94, align 32
  store i64 %191, ptr %.slot46, align 4
  store <8 x float> %.spill.load460, ptr %.slot47, align 32
  store <8 x float> %.spill.load461, ptr %.slot48, align 32
  br label %direct.schedule.4

direct.schedule.25:                               ; preds = %direct.false166
  store i64 0, ptr %.slot100, align 4
  br label %direct.schedule.26

direct.schedule.26:                               ; preds = %direct.schedule.29, %direct.schedule.25
  %.state462 = load i64, ptr %.slot100, align 4
  %192 = icmp slt i64 %.state462, 2048
  br i1 %192, label %direct.true463, label %direct.false464

direct.schedule.27:                               ; preds = %direct.true463
  %.state465 = load i64, ptr %.slot100, align 4
  %193 = srem i64 %.state465, 128
  %.state466 = load i64, ptr %.slot100, align 4
  %194 = sdiv i64 %.state466, 128
  %.spill.load467 = load i64, ptr %.spill41, align 4
  %.spill.load468 = load <8 x i64>, ptr %.spill42, align 64
  %195 = mul i64 %.spill.load467, 4
  %.splatinsert469 = insertelement <8 x i64> poison, i64 %195, i64 0
  %.splat470 = shufflevector <8 x i64> %.splatinsert469, <8 x i64> poison, <8 x i32> zeroinitializer
  %196 = add <8 x i64> %.splat470, %.spill.load468
  %.spill.load471 = load i64, ptr %.spill49, align 4
  %197 = add i64 %.spill.load471, %194
  %198 = mul <8 x i64> %196, splat (i64 8193)
  %.splatinsert472 = insertelement <8 x i64> poison, i64 %197, i64 0
  %.splat473 = shufflevector <8 x i64> %.splatinsert472, <8 x i64> poison, <8 x i32> zeroinitializer
  %199 = add <8 x i64> %198, %.splat473
  %200 = icmp sge i64 %197, 0
  %201 = icmp slt i64 %197, 8193
  %202 = and i1 %200, %201
  %203 = mul <8 x i64> %199, splat (i64 128)
  %.splatinsert474 = insertelement <8 x i64> poison, i64 %193, i64 0
  %.splat475 = shufflevector <8 x i64> %.splatinsert474, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = add <8 x i64> %203, %.splat475
  store <8 x i64> %204, ptr %.spill101, align 64
  br i1 %202, label %direct.true476, label %direct.false477

direct.schedule.28:                               ; preds = %direct.true476
  %.spill.load478 = load <8 x i64>, ptr %.spill101, align 64
  %205 = mul <8 x i64> %.spill.load478, splat (i64 4)
  %206 = getelementptr i8, ptr %33, <8 x i64> %205
  %207 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %206, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  store <8 x float> %207, ptr %.slot102, align 32
  br label %direct.schedule.29

direct.schedule.29:                               ; preds = %direct.false477, %direct.schedule.28
  %tile_snapshot.spill.load479 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, 1
  %.state480 = load i64, ptr %.slot100, align 4
  %.splatinsert481 = insertelement <8 x i64> poison, i64 %.state480, i64 0
  %.splat482 = shufflevector <8 x i64> %.splatinsert481, <8 x i64> poison, <8 x i32> zeroinitializer
  %209 = mul <8 x i64> %.splat482, splat (i64 4)
  %210 = add <8 x i64> %208, %209
  %211 = insertvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load479, <8 x i64> %210, 1
  %.state483 = load <8 x float>, ptr %.slot102, align 32
  %212 = extractvalue { <8 x ptr>, <8 x i64> } %211, 0
  %213 = getelementptr i8, <8 x ptr> %212, <8 x i64> %210
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state483, <8 x ptr> align 1 %213, <8 x i1> splat (i1 true))
  %.state484 = load i64, ptr %.slot100, align 4
  %214 = add i64 %.state484, 1
  store i64 %214, ptr %.slot100, align 4
  br label %direct.schedule.26

direct.schedule.30:                               ; preds = %direct.false140
  store i64 0, ptr %.slot103, align 4
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.34, %direct.schedule.30
  %.state485 = load i64, ptr %.slot103, align 4
  %215 = icmp slt i64 %.state485, 2048
  br i1 %215, label %direct.true486, label %direct.false487

direct.schedule.32:                               ; preds = %direct.true486
  %.state488 = load i64, ptr %.slot103, align 4
  %216 = srem i64 %.state488, 128
  %.state489 = load i64, ptr %.slot103, align 4
  %217 = sdiv i64 %.state489, 128
  %.spill.load490 = load i64, ptr %.spill41, align 4
  %.spill.load491 = load <8 x i64>, ptr %.spill42, align 64
  %218 = mul i64 %.spill.load490, 4
  %.splatinsert492 = insertelement <8 x i64> poison, i64 %218, i64 0
  %.splat493 = shufflevector <8 x i64> %.splatinsert492, <8 x i64> poison, <8 x i32> zeroinitializer
  %219 = add <8 x i64> %.splat493, %.spill.load491
  %.spill.load494 = load i64, ptr %.spill49, align 4
  %220 = add i64 %.spill.load494, %217
  %221 = mul <8 x i64> %219, splat (i64 8193)
  %.splatinsert495 = insertelement <8 x i64> poison, i64 %220, i64 0
  %.splat496 = shufflevector <8 x i64> %.splatinsert495, <8 x i64> poison, <8 x i32> zeroinitializer
  %222 = add <8 x i64> %221, %.splat496
  %223 = icmp sge i64 %220, 0
  %224 = icmp slt i64 %220, 8193
  %225 = and i1 %223, %224
  %226 = mul <8 x i64> %222, splat (i64 128)
  %.splatinsert497 = insertelement <8 x i64> poison, i64 %216, i64 0
  %.splat498 = shufflevector <8 x i64> %.splatinsert497, <8 x i64> poison, <8 x i32> zeroinitializer
  %227 = add <8 x i64> %226, %.splat498
  store <8 x i64> %227, ptr %.spill104, align 64
  br i1 %225, label %direct.true499, label %direct.false500

direct.schedule.33:                               ; preds = %direct.true499
  %.spill.load501 = load <8 x i64>, ptr %.spill104, align 64
  %228 = mul <8 x i64> %.spill.load501, splat (i64 4)
  %229 = getelementptr i8, ptr %31, <8 x i64> %228
  %230 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %229, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  store <8 x float> %230, ptr %.slot105, align 32
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.false500, %direct.schedule.33
  %tile_snapshot.spill.load502 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill50, align 64
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load502, 1
  %.state503 = load i64, ptr %.slot103, align 4
  %.splatinsert504 = insertelement <8 x i64> poison, i64 %.state503, i64 0
  %.splat505 = shufflevector <8 x i64> %.splatinsert504, <8 x i64> poison, <8 x i32> zeroinitializer
  %232 = mul <8 x i64> %.splat505, splat (i64 4)
  %233 = add <8 x i64> %231, %232
  %234 = insertvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load502, <8 x i64> %233, 1
  %.state506 = load <8 x float>, ptr %.slot105, align 32
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %234, 0
  %236 = getelementptr i8, <8 x ptr> %235, <8 x i64> %233
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state506, <8 x ptr> align 1 %236, <8 x i1> splat (i1 true))
  %.state507 = load i64, ptr %.slot103, align 4
  %237 = add i64 %.state507, 1
  store i64 %237, ptr %.slot103, align 4
  br label %direct.schedule.31

direct.schedule.35:                               ; preds = %direct.false137
  store i64 0, ptr %.slot106, align 4
  br label %direct.schedule.36

direct.schedule.36:                               ; preds = %direct.schedule.37, %direct.schedule.35
  %.state508 = load i64, ptr %.slot106, align 4
  %238 = icmp slt i64 %.state508, 128
  br i1 %238, label %direct.true509, label %direct.false510

direct.schedule.37:                               ; preds = %direct.true509
  %.spill.load511 = load i64, ptr %.spill41, align 4
  %.spill.load512 = load <8 x i64>, ptr %.spill, align 64
  %239 = mul i64 %.spill.load511, 16
  %.splatinsert513 = insertelement <8 x i64> poison, i64 %239, i64 0
  %.splat514 = shufflevector <8 x i64> %.splatinsert513, <8 x i64> poison, <8 x i32> zeroinitializer
  %240 = add <8 x i64> %.splat514, %.spill.load512
  %.spill.load515 = load i64, ptr %.spill43, align 4
  %.splatinsert516 = insertelement <8 x i64> poison, i64 %.spill.load515, i64 0
  %.splat517 = shufflevector <8 x i64> %.splatinsert516, <8 x i64> poison, <8 x i32> zeroinitializer
  %241 = add <8 x i64> %240, %.splat517
  %.state518 = load i64, ptr %.slot106, align 4
  %242 = mul <8 x i64> %241, splat (i64 128)
  %.splatinsert519 = insertelement <8 x i64> poison, i64 %.state518, i64 0
  %.splat520 = shufflevector <8 x i64> %.splatinsert519, <8 x i64> poison, <8 x i32> zeroinitializer
  %243 = add <8 x i64> %242, %.splat520
  %.state521 = load i64, ptr %.slot106, align 4
  %tile_snapshot.spill.load522 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill44, align 64
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load522, 1
  %.splatinsert523 = insertelement <8 x i64> poison, i64 %.state521, i64 0
  %.splat524 = shufflevector <8 x i64> %.splatinsert523, <8 x i64> poison, <8 x i32> zeroinitializer
  %245 = mul <8 x i64> %.splat524, splat (i64 32)
  %246 = add <8 x i64> %244, %245
  %247 = extractelement <8 x i64> %246, i32 0
  %private.contiguous.address525 = getelementptr i8, ptr %tile_snapshot.private2, i64 %247
  %private.contiguous.load526 = load <8 x float>, ptr %private.contiguous.address525, align 4
  %.state527 = load <8 x float>, ptr %.slot48, align 32
  %248 = fdiv <8 x float> %private.contiguous.load526, %.state527
  %249 = mul <8 x i64> %243, splat (i64 4)
  %250 = getelementptr i8, ptr %35, <8 x i64> %249
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %248, <8 x ptr> align 1 %250, <8 x i1> splat (i1 true))
  %.state528 = load i64, ptr %.slot106, align 4
  %251 = add i64 %.state528, 1
  store i64 %251, ptr %.slot106, align 4
  br label %direct.schedule.36

direct.schedule.38:                               ; preds = %direct.false510
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

copy.active:                                      ; preds = %direct.schedule.0
  %252 = extractelement <8 x i64> %44, i64 0
  call void @llm_attention.contiguous_copy(ptr %29, i64 %252, ptr %private.workspace)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active
  br label %copy.active117

copy.active117:                                   ; preds = %copy.continue
  %253 = getelementptr i8, ptr %private.workspace, i64 512
  %254 = extractelement <8 x i64> %44, i64 1
  call void @llm_attention.contiguous_copy(ptr %29, i64 %254, ptr %253)
  br label %copy.continue118

copy.continue118:                                 ; preds = %copy.active117
  br label %copy.active119

copy.active119:                                   ; preds = %copy.continue118
  %255 = getelementptr i8, ptr %private.workspace, i64 1024
  %256 = extractelement <8 x i64> %44, i64 2
  call void @llm_attention.contiguous_copy(ptr %29, i64 %256, ptr %255)
  br label %copy.continue120

copy.continue120:                                 ; preds = %copy.active119
  br label %copy.active121

copy.active121:                                   ; preds = %copy.continue120
  %257 = getelementptr i8, ptr %private.workspace, i64 1536
  %258 = extractelement <8 x i64> %44, i64 3
  call void @llm_attention.contiguous_copy(ptr %29, i64 %258, ptr %257)
  br label %copy.continue122

copy.continue122:                                 ; preds = %copy.active121
  br label %copy.active123

copy.active123:                                   ; preds = %copy.continue122
  %259 = getelementptr i8, ptr %private.workspace, i64 2048
  %260 = extractelement <8 x i64> %44, i64 4
  call void @llm_attention.contiguous_copy(ptr %29, i64 %260, ptr %259)
  br label %copy.continue124

copy.continue124:                                 ; preds = %copy.active123
  br label %copy.active125

copy.active125:                                   ; preds = %copy.continue124
  %261 = getelementptr i8, ptr %private.workspace, i64 2560
  %262 = extractelement <8 x i64> %44, i64 5
  call void @llm_attention.contiguous_copy(ptr %29, i64 %262, ptr %261)
  br label %copy.continue126

copy.continue126:                                 ; preds = %copy.active125
  br label %copy.active127

copy.active127:                                   ; preds = %copy.continue126
  %263 = getelementptr i8, ptr %private.workspace, i64 3072
  %264 = extractelement <8 x i64> %44, i64 6
  call void @llm_attention.contiguous_copy(ptr %29, i64 %264, ptr %263)
  br label %copy.continue128

copy.continue128:                                 ; preds = %copy.active127
  br label %copy.active129

copy.active129:                                   ; preds = %copy.continue128
  %265 = getelementptr i8, ptr %private.workspace, i64 3584
  %266 = extractelement <8 x i64> %44, i64 7
  call void @llm_attention.contiguous_copy(ptr %29, i64 %266, ptr %265)
  br label %copy.continue130

copy.continue130:                                 ; preds = %copy.active129
  store { <8 x ptr>, <8 x i64> } %5, ptr %tile_snapshot.spill44, align 64
  store { <8 x ptr>, <8 x i64> } %8, ptr %tile_snapshot.spill45, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true136:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false137:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.35

direct.true139:                                   ; preds = %direct.schedule.5
  br label %direct.schedule.6

direct.false140:                                  ; preds = %direct.schedule.5
  br label %direct.schedule.30

copy.active148:                                   ; preds = %direct.schedule.6
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %268 = extractelement <8 x ptr> %267, i64 0
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %270 = extractelement <8 x i64> %269, i64 0
  %271 = getelementptr i8, ptr %268, i64 %270
  %272 = extractelement <8 x i64> %60, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %31, i64 %272, ptr %271)
  br label %copy.continue149

copy.continue149:                                 ; preds = %copy.active148
  br label %copy.active150

copy.active150:                                   ; preds = %copy.continue149
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %274 = extractelement <8 x ptr> %273, i64 1
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %276 = extractelement <8 x i64> %275, i64 1
  %277 = getelementptr i8, ptr %274, i64 %276
  %278 = extractelement <8 x i64> %60, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %31, i64 %278, ptr %277)
  br label %copy.continue151

copy.continue151:                                 ; preds = %copy.active150
  br label %copy.active152

copy.active152:                                   ; preds = %copy.continue151
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %280 = extractelement <8 x ptr> %279, i64 2
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %282 = extractelement <8 x i64> %281, i64 2
  %283 = getelementptr i8, ptr %280, i64 %282
  %284 = extractelement <8 x i64> %60, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %31, i64 %284, ptr %283)
  br label %copy.continue153

copy.continue153:                                 ; preds = %copy.active152
  br label %copy.active154

copy.active154:                                   ; preds = %copy.continue153
  %285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %286 = extractelement <8 x ptr> %285, i64 3
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %288 = extractelement <8 x i64> %287, i64 3
  %289 = getelementptr i8, ptr %286, i64 %288
  %290 = extractelement <8 x i64> %60, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %31, i64 %290, ptr %289)
  br label %copy.continue155

copy.continue155:                                 ; preds = %copy.active154
  br label %copy.active156

copy.active156:                                   ; preds = %copy.continue155
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %292 = extractelement <8 x ptr> %291, i64 4
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %294 = extractelement <8 x i64> %293, i64 4
  %295 = getelementptr i8, ptr %292, i64 %294
  %296 = extractelement <8 x i64> %60, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %31, i64 %296, ptr %295)
  br label %copy.continue157

copy.continue157:                                 ; preds = %copy.active156
  br label %copy.active158

copy.active158:                                   ; preds = %copy.continue157
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %298 = extractelement <8 x ptr> %297, i64 5
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %300 = extractelement <8 x i64> %299, i64 5
  %301 = getelementptr i8, ptr %298, i64 %300
  %302 = extractelement <8 x i64> %60, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %31, i64 %302, ptr %301)
  br label %copy.continue159

copy.continue159:                                 ; preds = %copy.active158
  br label %copy.active160

copy.active160:                                   ; preds = %copy.continue159
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %304 = extractelement <8 x ptr> %303, i64 6
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %306 = extractelement <8 x i64> %305, i64 6
  %307 = getelementptr i8, ptr %304, i64 %306
  %308 = extractelement <8 x i64> %60, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %31, i64 %308, ptr %307)
  br label %copy.continue161

copy.continue161:                                 ; preds = %copy.active160
  br label %copy.active162

copy.active162:                                   ; preds = %copy.continue161
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 0
  %310 = extractelement <8 x ptr> %309, i64 7
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load147, 1
  %312 = extractelement <8 x i64> %311, i64 7
  %313 = getelementptr i8, ptr %310, i64 %312
  %314 = extractelement <8 x i64> %60, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %31, i64 %314, ptr %313)
  br label %copy.continue163

copy.continue163:                                 ; preds = %copy.active162
  br label %direct.schedule.7

direct.true165:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false166:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.25

copy.active175:                                   ; preds = %direct.schedule.8
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %316 = extractelement <8 x ptr> %315, i64 0
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %318 = extractelement <8 x i64> %317, i64 0
  %319 = getelementptr i8, ptr %316, i64 %318
  %320 = extractelement <8 x i64> %65, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %33, i64 %320, ptr %319)
  br label %copy.continue176

copy.continue176:                                 ; preds = %copy.active175
  br label %copy.active177

copy.active177:                                   ; preds = %copy.continue176
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %322 = extractelement <8 x ptr> %321, i64 1
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %324 = extractelement <8 x i64> %323, i64 1
  %325 = getelementptr i8, ptr %322, i64 %324
  %326 = extractelement <8 x i64> %65, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %33, i64 %326, ptr %325)
  br label %copy.continue178

copy.continue178:                                 ; preds = %copy.active177
  br label %copy.active179

copy.active179:                                   ; preds = %copy.continue178
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %328 = extractelement <8 x ptr> %327, i64 2
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %330 = extractelement <8 x i64> %329, i64 2
  %331 = getelementptr i8, ptr %328, i64 %330
  %332 = extractelement <8 x i64> %65, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %33, i64 %332, ptr %331)
  br label %copy.continue180

copy.continue180:                                 ; preds = %copy.active179
  br label %copy.active181

copy.active181:                                   ; preds = %copy.continue180
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %334 = extractelement <8 x ptr> %333, i64 3
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %336 = extractelement <8 x i64> %335, i64 3
  %337 = getelementptr i8, ptr %334, i64 %336
  %338 = extractelement <8 x i64> %65, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %33, i64 %338, ptr %337)
  br label %copy.continue182

copy.continue182:                                 ; preds = %copy.active181
  br label %copy.active183

copy.active183:                                   ; preds = %copy.continue182
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %340 = extractelement <8 x ptr> %339, i64 4
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %342 = extractelement <8 x i64> %341, i64 4
  %343 = getelementptr i8, ptr %340, i64 %342
  %344 = extractelement <8 x i64> %65, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %33, i64 %344, ptr %343)
  br label %copy.continue184

copy.continue184:                                 ; preds = %copy.active183
  br label %copy.active185

copy.active185:                                   ; preds = %copy.continue184
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %346 = extractelement <8 x ptr> %345, i64 5
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %348 = extractelement <8 x i64> %347, i64 5
  %349 = getelementptr i8, ptr %346, i64 %348
  %350 = extractelement <8 x i64> %65, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %33, i64 %350, ptr %349)
  br label %copy.continue186

copy.continue186:                                 ; preds = %copy.active185
  br label %copy.active187

copy.active187:                                   ; preds = %copy.continue186
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %352 = extractelement <8 x ptr> %351, i64 6
  %353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %354 = extractelement <8 x i64> %353, i64 6
  %355 = getelementptr i8, ptr %352, i64 %354
  %356 = extractelement <8 x i64> %65, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %33, i64 %356, ptr %355)
  br label %copy.continue188

copy.continue188:                                 ; preds = %copy.active187
  br label %copy.active189

copy.active189:                                   ; preds = %copy.continue188
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 0
  %358 = extractelement <8 x ptr> %357, i64 7
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load174, 1
  %360 = extractelement <8 x i64> %359, i64 7
  %361 = getelementptr i8, ptr %358, i64 %360
  %362 = extractelement <8 x i64> %65, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %33, i64 %362, ptr %361)
  br label %copy.continue190

copy.continue190:                                 ; preds = %copy.active189
  br label %direct.schedule.9

mma.active:                                       ; preds = %direct.schedule.9
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %364 = extractelement <8 x ptr> %363, i64 0
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %366 = extractelement <8 x i64> %365, i64 0
  %367 = getelementptr i8, ptr %364, i64 %366
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %369 = extractelement <8 x ptr> %368, i64 0
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %371 = extractelement <8 x i64> %370, i64 0
  %372 = getelementptr i8, ptr %369, i64 %371
  call void @llm_attention.strided_mma(ptr %367, ptr %372, ptr %tile_snapshot.private18, ptr %tile_snapshot.private22)
  br label %mma.continue

mma.continue:                                     ; preds = %mma.active
  br label %mma.active193

mma.active193:                                    ; preds = %mma.continue
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %374 = extractelement <8 x ptr> %373, i64 1
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %376 = extractelement <8 x i64> %375, i64 1
  %377 = getelementptr i8, ptr %374, i64 %376
  %378 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %379 = extractelement <8 x ptr> %378, i64 1
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %381 = extractelement <8 x i64> %380, i64 1
  %382 = getelementptr i8, ptr %379, i64 %381
  %383 = getelementptr i8, ptr %tile_snapshot.private18, i64 64
  %384 = getelementptr i8, ptr %tile_snapshot.private22, i64 64
  call void @llm_attention.strided_mma(ptr %377, ptr %382, ptr %383, ptr %384)
  br label %mma.continue194

mma.continue194:                                  ; preds = %mma.active193
  br label %mma.active195

mma.active195:                                    ; preds = %mma.continue194
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %386 = extractelement <8 x ptr> %385, i64 2
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %388 = extractelement <8 x i64> %387, i64 2
  %389 = getelementptr i8, ptr %386, i64 %388
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %391 = extractelement <8 x ptr> %390, i64 2
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %393 = extractelement <8 x i64> %392, i64 2
  %394 = getelementptr i8, ptr %391, i64 %393
  %395 = getelementptr i8, ptr %tile_snapshot.private18, i64 128
  %396 = getelementptr i8, ptr %tile_snapshot.private22, i64 128
  call void @llm_attention.strided_mma(ptr %389, ptr %394, ptr %395, ptr %396)
  br label %mma.continue196

mma.continue196:                                  ; preds = %mma.active195
  br label %mma.active197

mma.active197:                                    ; preds = %mma.continue196
  %397 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %398 = extractelement <8 x ptr> %397, i64 3
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %400 = extractelement <8 x i64> %399, i64 3
  %401 = getelementptr i8, ptr %398, i64 %400
  %402 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %403 = extractelement <8 x ptr> %402, i64 3
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %405 = extractelement <8 x i64> %404, i64 3
  %406 = getelementptr i8, ptr %403, i64 %405
  %407 = getelementptr i8, ptr %tile_snapshot.private18, i64 192
  %408 = getelementptr i8, ptr %tile_snapshot.private22, i64 192
  call void @llm_attention.strided_mma(ptr %401, ptr %406, ptr %407, ptr %408)
  br label %mma.continue198

mma.continue198:                                  ; preds = %mma.active197
  br label %mma.active199

mma.active199:                                    ; preds = %mma.continue198
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %410 = extractelement <8 x ptr> %409, i64 4
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %412 = extractelement <8 x i64> %411, i64 4
  %413 = getelementptr i8, ptr %410, i64 %412
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %415 = extractelement <8 x ptr> %414, i64 4
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %417 = extractelement <8 x i64> %416, i64 4
  %418 = getelementptr i8, ptr %415, i64 %417
  %419 = getelementptr i8, ptr %tile_snapshot.private18, i64 256
  %420 = getelementptr i8, ptr %tile_snapshot.private22, i64 256
  call void @llm_attention.strided_mma(ptr %413, ptr %418, ptr %419, ptr %420)
  br label %mma.continue200

mma.continue200:                                  ; preds = %mma.active199
  br label %mma.active201

mma.active201:                                    ; preds = %mma.continue200
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %422 = extractelement <8 x ptr> %421, i64 5
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %424 = extractelement <8 x i64> %423, i64 5
  %425 = getelementptr i8, ptr %422, i64 %424
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %427 = extractelement <8 x ptr> %426, i64 5
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %429 = extractelement <8 x i64> %428, i64 5
  %430 = getelementptr i8, ptr %427, i64 %429
  %431 = getelementptr i8, ptr %tile_snapshot.private18, i64 320
  %432 = getelementptr i8, ptr %tile_snapshot.private22, i64 320
  call void @llm_attention.strided_mma(ptr %425, ptr %430, ptr %431, ptr %432)
  br label %mma.continue202

mma.continue202:                                  ; preds = %mma.active201
  br label %mma.active203

mma.active203:                                    ; preds = %mma.continue202
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %434 = extractelement <8 x ptr> %433, i64 6
  %435 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %436 = extractelement <8 x i64> %435, i64 6
  %437 = getelementptr i8, ptr %434, i64 %436
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %439 = extractelement <8 x ptr> %438, i64 6
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %441 = extractelement <8 x i64> %440, i64 6
  %442 = getelementptr i8, ptr %439, i64 %441
  %443 = getelementptr i8, ptr %tile_snapshot.private18, i64 384
  %444 = getelementptr i8, ptr %tile_snapshot.private22, i64 384
  call void @llm_attention.strided_mma(ptr %437, ptr %442, ptr %443, ptr %444)
  br label %mma.continue204

mma.continue204:                                  ; preds = %mma.active203
  br label %mma.active205

mma.active205:                                    ; preds = %mma.continue204
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 0
  %446 = extractelement <8 x ptr> %445, i64 7
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load191, 1
  %448 = extractelement <8 x i64> %447, i64 7
  %449 = getelementptr i8, ptr %446, i64 %448
  %450 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %451 = extractelement <8 x ptr> %450, i64 7
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %453 = extractelement <8 x i64> %452, i64 7
  %454 = getelementptr i8, ptr %451, i64 %453
  %455 = getelementptr i8, ptr %tile_snapshot.private18, i64 448
  %456 = getelementptr i8, ptr %tile_snapshot.private22, i64 448
  call void @llm_attention.strided_mma(ptr %449, ptr %454, ptr %455, ptr %456)
  br label %mma.continue206

mma.continue206:                                  ; preds = %mma.active205
  %457 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 0, i64 64, i64 128, i64 192, i64 256, i64 320, i64 384, i64 448>
  %458 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %457, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %459 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 4, i64 68, i64 132, i64 196, i64 260, i64 324, i64 388, i64 452>
  %460 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %459, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %461 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 8, i64 72, i64 136, i64 200, i64 264, i64 328, i64 392, i64 456>
  %462 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %461, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %463 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 12, i64 76, i64 140, i64 204, i64 268, i64 332, i64 396, i64 460>
  %464 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %463, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %465 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 16, i64 80, i64 144, i64 208, i64 272, i64 336, i64 400, i64 464>
  %466 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %465, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %467 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 20, i64 84, i64 148, i64 212, i64 276, i64 340, i64 404, i64 468>
  %468 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %467, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %469 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 24, i64 88, i64 152, i64 216, i64 280, i64 344, i64 408, i64 472>
  %470 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %469, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %471 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 28, i64 92, i64 156, i64 220, i64 284, i64 348, i64 412, i64 476>
  %472 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %471, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %473 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 32, i64 96, i64 160, i64 224, i64 288, i64 352, i64 416, i64 480>
  %474 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %473, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %475 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 36, i64 100, i64 164, i64 228, i64 292, i64 356, i64 420, i64 484>
  %476 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %475, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %477 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 40, i64 104, i64 168, i64 232, i64 296, i64 360, i64 424, i64 488>
  %478 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %477, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %479 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 44, i64 108, i64 172, i64 236, i64 300, i64 364, i64 428, i64 492>
  %480 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %479, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %481 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 48, i64 112, i64 176, i64 240, i64 304, i64 368, i64 432, i64 496>
  %482 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %481, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %483 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 52, i64 116, i64 180, i64 244, i64 308, i64 372, i64 436, i64 500>
  %484 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %483, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %485 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 56, i64 120, i64 184, i64 248, i64 312, i64 376, i64 440, i64 504>
  %486 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %485, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %487 = getelementptr i8, <8 x ptr> %.splat24, <8 x i64> <i64 60, i64 124, i64 188, i64 252, i64 316, i64 380, i64 444, i64 508>
  %488 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %487, <8 x i1> splat (i1 true), <8 x float> zeroinitializer)
  %489 = fmul <8 x float> %458, splat (float 0x3FB6A09E60000000)
  %490 = fmul <8 x float> %460, splat (float 0x3FB6A09E60000000)
  %491 = fmul <8 x float> %462, splat (float 0x3FB6A09E60000000)
  %492 = fmul <8 x float> %464, splat (float 0x3FB6A09E60000000)
  %493 = fmul <8 x float> %466, splat (float 0x3FB6A09E60000000)
  %494 = fmul <8 x float> %468, splat (float 0x3FB6A09E60000000)
  %495 = fmul <8 x float> %470, splat (float 0x3FB6A09E60000000)
  %496 = fmul <8 x float> %472, splat (float 0x3FB6A09E60000000)
  %497 = fmul <8 x float> %474, splat (float 0x3FB6A09E60000000)
  %498 = fmul <8 x float> %476, splat (float 0x3FB6A09E60000000)
  %499 = fmul <8 x float> %478, splat (float 0x3FB6A09E60000000)
  %500 = fmul <8 x float> %480, splat (float 0x3FB6A09E60000000)
  %501 = fmul <8 x float> %482, splat (float 0x3FB6A09E60000000)
  %502 = fmul <8 x float> %484, splat (float 0x3FB6A09E60000000)
  %503 = fmul <8 x float> %486, splat (float 0x3FB6A09E60000000)
  %504 = fmul <8 x float> %488, splat (float 0x3FB6A09E60000000)
  %.spill.load207 = load i64, ptr %.spill49, align 4
  %.spill.load208 = load i64, ptr %.spill49, align 4
  %505 = add i64 1, %.spill.load208
  %.spill.load209 = load i64, ptr %.spill49, align 4
  %506 = add i64 2, %.spill.load209
  %.spill.load210 = load i64, ptr %.spill49, align 4
  %507 = add i64 3, %.spill.load210
  %.spill.load211 = load i64, ptr %.spill49, align 4
  %508 = add i64 4, %.spill.load211
  %.spill.load212 = load i64, ptr %.spill49, align 4
  %509 = add i64 5, %.spill.load212
  %.spill.load213 = load i64, ptr %.spill49, align 4
  %510 = add i64 6, %.spill.load213
  %.spill.load214 = load i64, ptr %.spill49, align 4
  %511 = add i64 7, %.spill.load214
  %.spill.load215 = load i64, ptr %.spill49, align 4
  %512 = add i64 8, %.spill.load215
  %.spill.load216 = load i64, ptr %.spill49, align 4
  %513 = add i64 9, %.spill.load216
  %.spill.load217 = load i64, ptr %.spill49, align 4
  %514 = add i64 10, %.spill.load217
  %.spill.load218 = load i64, ptr %.spill49, align 4
  %515 = add i64 11, %.spill.load218
  %.spill.load219 = load i64, ptr %.spill49, align 4
  %516 = add i64 12, %.spill.load219
  %.spill.load220 = load i64, ptr %.spill49, align 4
  %517 = add i64 13, %.spill.load220
  %.spill.load221 = load i64, ptr %.spill49, align 4
  %518 = add i64 14, %.spill.load221
  %.spill.load222 = load i64, ptr %.spill49, align 4
  %519 = add i64 15, %.spill.load222
  %520 = icmp slt i64 %.spill.load207, 8193
  %521 = icmp slt i64 %505, 8193
  %522 = icmp slt i64 %506, 8193
  %523 = icmp slt i64 %507, 8193
  %524 = icmp slt i64 %508, 8193
  %525 = icmp slt i64 %509, 8193
  %526 = icmp slt i64 %510, 8193
  %527 = icmp slt i64 %511, 8193
  %528 = icmp slt i64 %512, 8193
  %529 = icmp slt i64 %513, 8193
  %530 = icmp slt i64 %514, 8193
  %531 = icmp slt i64 %515, 8193
  %532 = icmp slt i64 %516, 8193
  %533 = icmp slt i64 %517, 8193
  %534 = icmp slt i64 %518, 8193
  %535 = icmp slt i64 %519, 8193
  %.spill.load223 = load i64, ptr %.spill43, align 4
  %536 = add i64 %.spill.load223, 8193
  %537 = sub i64 %536, 1
  %538 = icmp sle i64 %.spill.load207, %537
  %539 = icmp sle i64 %505, %537
  %540 = icmp sle i64 %506, %537
  %541 = icmp sle i64 %507, %537
  %542 = icmp sle i64 %508, %537
  %543 = icmp sle i64 %509, %537
  %544 = icmp sle i64 %510, %537
  %545 = icmp sle i64 %511, %537
  %546 = icmp sle i64 %512, %537
  %547 = icmp sle i64 %513, %537
  %548 = icmp sle i64 %514, %537
  %549 = icmp sle i64 %515, %537
  %550 = icmp sle i64 %516, %537
  %551 = icmp sle i64 %517, %537
  %552 = icmp sle i64 %518, %537
  %553 = icmp sle i64 %519, %537
  %554 = and i1 %520, %538
  store i1 %554, ptr %.spill53, align 1
  %555 = and i1 %521, %539
  store i1 %555, ptr %.spill54, align 1
  %556 = and i1 %522, %540
  store i1 %556, ptr %.spill55, align 1
  %557 = and i1 %523, %541
  store i1 %557, ptr %.spill56, align 1
  %558 = and i1 %524, %542
  store i1 %558, ptr %.spill57, align 1
  %559 = and i1 %525, %543
  store i1 %559, ptr %.spill58, align 1
  %560 = and i1 %526, %544
  store i1 %560, ptr %.spill59, align 1
  %561 = and i1 %527, %545
  store i1 %561, ptr %.spill60, align 1
  %562 = and i1 %528, %546
  store i1 %562, ptr %.spill61, align 1
  %563 = and i1 %529, %547
  store i1 %563, ptr %.spill62, align 1
  %564 = and i1 %530, %548
  store i1 %564, ptr %.spill63, align 1
  %565 = and i1 %531, %549
  store i1 %565, ptr %.spill64, align 1
  %566 = and i1 %532, %550
  store i1 %566, ptr %.spill65, align 1
  %567 = and i1 %533, %551
  store i1 %567, ptr %.spill66, align 1
  %568 = and i1 %534, %552
  store i1 %568, ptr %.spill67, align 1
  %569 = and i1 %535, %553
  store i1 %569, ptr %.spill68, align 1
  %.splatinsert224 = insertelement <8 x i1> poison, i1 %554, i64 0
  %.splat225 = shufflevector <8 x i1> %.splatinsert224, <8 x i1> poison, <8 x i32> zeroinitializer
  %570 = select <8 x i1> %.splat225, <8 x float> %489, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %570, ptr %.spill69, align 32
  %.splatinsert226 = insertelement <8 x i1> poison, i1 %555, i64 0
  %.splat227 = shufflevector <8 x i1> %.splatinsert226, <8 x i1> poison, <8 x i32> zeroinitializer
  %571 = select <8 x i1> %.splat227, <8 x float> %490, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %571, ptr %.spill70, align 32
  %.splatinsert228 = insertelement <8 x i1> poison, i1 %556, i64 0
  %.splat229 = shufflevector <8 x i1> %.splatinsert228, <8 x i1> poison, <8 x i32> zeroinitializer
  %572 = select <8 x i1> %.splat229, <8 x float> %491, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %572, ptr %.spill71, align 32
  %.splatinsert230 = insertelement <8 x i1> poison, i1 %557, i64 0
  %.splat231 = shufflevector <8 x i1> %.splatinsert230, <8 x i1> poison, <8 x i32> zeroinitializer
  %573 = select <8 x i1> %.splat231, <8 x float> %492, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %573, ptr %.spill72, align 32
  %.splatinsert232 = insertelement <8 x i1> poison, i1 %558, i64 0
  %.splat233 = shufflevector <8 x i1> %.splatinsert232, <8 x i1> poison, <8 x i32> zeroinitializer
  %574 = select <8 x i1> %.splat233, <8 x float> %493, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %574, ptr %.spill73, align 32
  %.splatinsert234 = insertelement <8 x i1> poison, i1 %559, i64 0
  %.splat235 = shufflevector <8 x i1> %.splatinsert234, <8 x i1> poison, <8 x i32> zeroinitializer
  %575 = select <8 x i1> %.splat235, <8 x float> %494, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %575, ptr %.spill74, align 32
  %.splatinsert236 = insertelement <8 x i1> poison, i1 %560, i64 0
  %.splat237 = shufflevector <8 x i1> %.splatinsert236, <8 x i1> poison, <8 x i32> zeroinitializer
  %576 = select <8 x i1> %.splat237, <8 x float> %495, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %576, ptr %.spill75, align 32
  %.splatinsert238 = insertelement <8 x i1> poison, i1 %561, i64 0
  %.splat239 = shufflevector <8 x i1> %.splatinsert238, <8 x i1> poison, <8 x i32> zeroinitializer
  %577 = select <8 x i1> %.splat239, <8 x float> %496, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %577, ptr %.spill76, align 32
  %.splatinsert240 = insertelement <8 x i1> poison, i1 %562, i64 0
  %.splat241 = shufflevector <8 x i1> %.splatinsert240, <8 x i1> poison, <8 x i32> zeroinitializer
  %578 = select <8 x i1> %.splat241, <8 x float> %497, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %578, ptr %.spill77, align 32
  %.splatinsert242 = insertelement <8 x i1> poison, i1 %563, i64 0
  %.splat243 = shufflevector <8 x i1> %.splatinsert242, <8 x i1> poison, <8 x i32> zeroinitializer
  %579 = select <8 x i1> %.splat243, <8 x float> %498, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %579, ptr %.spill78, align 32
  %.splatinsert244 = insertelement <8 x i1> poison, i1 %564, i64 0
  %.splat245 = shufflevector <8 x i1> %.splatinsert244, <8 x i1> poison, <8 x i32> zeroinitializer
  %580 = select <8 x i1> %.splat245, <8 x float> %499, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %580, ptr %.spill79, align 32
  %.splatinsert246 = insertelement <8 x i1> poison, i1 %565, i64 0
  %.splat247 = shufflevector <8 x i1> %.splatinsert246, <8 x i1> poison, <8 x i32> zeroinitializer
  %581 = select <8 x i1> %.splat247, <8 x float> %500, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %581, ptr %.spill80, align 32
  %.splatinsert248 = insertelement <8 x i1> poison, i1 %566, i64 0
  %.splat249 = shufflevector <8 x i1> %.splatinsert248, <8 x i1> poison, <8 x i32> zeroinitializer
  %582 = select <8 x i1> %.splat249, <8 x float> %501, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %582, ptr %.spill81, align 32
  %.splatinsert250 = insertelement <8 x i1> poison, i1 %567, i64 0
  %.splat251 = shufflevector <8 x i1> %.splatinsert250, <8 x i1> poison, <8 x i32> zeroinitializer
  %583 = select <8 x i1> %.splat251, <8 x float> %502, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %583, ptr %.spill82, align 32
  %.splatinsert252 = insertelement <8 x i1> poison, i1 %568, i64 0
  %.splat253 = shufflevector <8 x i1> %.splatinsert252, <8 x i1> poison, <8 x i32> zeroinitializer
  %584 = select <8 x i1> %.splat253, <8 x float> %503, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %584, ptr %.spill83, align 32
  %.splatinsert254 = insertelement <8 x i1> poison, i1 %569, i64 0
  %.splat255 = shufflevector <8 x i1> %.splatinsert254, <8 x i1> poison, <8 x i32> zeroinitializer
  %585 = select <8 x i1> %.splat255, <8 x float> %504, <8 x float> splat (float 0xC6293E5940000000)
  store <8 x float> %585, ptr %.spill84, align 32
  store { <8 x ptr>, <8 x i64> } %19, ptr %tile_snapshot.spill85, align 64
  store <8 x float> %570, ptr %tile_snapshot.private26, align 4
  %private.contiguous.address258 = getelementptr i8, ptr %tile_snapshot.private26, i64 32
  store <8 x float> %571, ptr %private.contiguous.address258, align 4
  %private.contiguous.address260 = getelementptr i8, ptr %tile_snapshot.private26, i64 64
  store <8 x float> %572, ptr %private.contiguous.address260, align 4
  %private.contiguous.address262 = getelementptr i8, ptr %tile_snapshot.private26, i64 96
  store <8 x float> %573, ptr %private.contiguous.address262, align 4
  %private.contiguous.address264 = getelementptr i8, ptr %tile_snapshot.private26, i64 128
  store <8 x float> %574, ptr %private.contiguous.address264, align 4
  %private.contiguous.address266 = getelementptr i8, ptr %tile_snapshot.private26, i64 160
  store <8 x float> %575, ptr %private.contiguous.address266, align 4
  %private.contiguous.address268 = getelementptr i8, ptr %tile_snapshot.private26, i64 192
  store <8 x float> %576, ptr %private.contiguous.address268, align 4
  %private.contiguous.address270 = getelementptr i8, ptr %tile_snapshot.private26, i64 224
  store <8 x float> %577, ptr %private.contiguous.address270, align 4
  %private.contiguous.address272 = getelementptr i8, ptr %tile_snapshot.private26, i64 256
  store <8 x float> %578, ptr %private.contiguous.address272, align 4
  %private.contiguous.address274 = getelementptr i8, ptr %tile_snapshot.private26, i64 288
  store <8 x float> %579, ptr %private.contiguous.address274, align 4
  %private.contiguous.address276 = getelementptr i8, ptr %tile_snapshot.private26, i64 320
  store <8 x float> %580, ptr %private.contiguous.address276, align 4
  %private.contiguous.address278 = getelementptr i8, ptr %tile_snapshot.private26, i64 352
  store <8 x float> %581, ptr %private.contiguous.address278, align 4
  %private.contiguous.address280 = getelementptr i8, ptr %tile_snapshot.private26, i64 384
  store <8 x float> %582, ptr %private.contiguous.address280, align 4
  %private.contiguous.address282 = getelementptr i8, ptr %tile_snapshot.private26, i64 416
  store <8 x float> %583, ptr %private.contiguous.address282, align 4
  %private.contiguous.address284 = getelementptr i8, ptr %tile_snapshot.private26, i64 448
  store <8 x float> %584, ptr %private.contiguous.address284, align 4
  %private.contiguous.address286 = getelementptr i8, ptr %tile_snapshot.private26, i64 480
  store <8 x float> %585, ptr %private.contiguous.address286, align 4
  store i64 0, ptr %.slot86, align 4
  store <8 x float> splat (float 0xFFF0000000000000), ptr %.slot87, align 32
  br label %direct.schedule.10

direct.true289:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false290:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true384:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false385:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true396:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false397:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

mma.active413:                                    ; preds = %direct.schedule.18
  %586 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %587 = extractelement <8 x ptr> %586, i64 0
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %589 = extractelement <8 x i64> %588, i64 0
  %590 = getelementptr i8, ptr %587, i64 %589
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %592 = extractelement <8 x ptr> %591, i64 0
  %593 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %594 = extractelement <8 x i64> %593, i64 0
  %595 = getelementptr i8, ptr %592, i64 %594
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %597 = extractelement <8 x ptr> %596, i64 0
  %598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %599 = extractelement <8 x i64> %598, i64 0
  %600 = getelementptr i8, ptr %597, i64 %599
  call void @llm_attention.strided_mma.3(ptr %590, ptr %595, ptr %600, ptr %tile_snapshot.private38)
  br label %mma.continue414

mma.continue414:                                  ; preds = %mma.active413
  br label %mma.active415

mma.active415:                                    ; preds = %mma.continue414
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %602 = extractelement <8 x ptr> %601, i64 1
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %604 = extractelement <8 x i64> %603, i64 1
  %605 = getelementptr i8, ptr %602, i64 %604
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %607 = extractelement <8 x ptr> %606, i64 1
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %609 = extractelement <8 x i64> %608, i64 1
  %610 = getelementptr i8, ptr %607, i64 %609
  %611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %612 = extractelement <8 x ptr> %611, i64 1
  %613 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %614 = extractelement <8 x i64> %613, i64 1
  %615 = getelementptr i8, ptr %612, i64 %614
  %616 = getelementptr i8, ptr %tile_snapshot.private38, i64 512
  call void @llm_attention.strided_mma.3(ptr %605, ptr %610, ptr %615, ptr %616)
  br label %mma.continue416

mma.continue416:                                  ; preds = %mma.active415
  br label %mma.active417

mma.active417:                                    ; preds = %mma.continue416
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %618 = extractelement <8 x ptr> %617, i64 2
  %619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %620 = extractelement <8 x i64> %619, i64 2
  %621 = getelementptr i8, ptr %618, i64 %620
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %623 = extractelement <8 x ptr> %622, i64 2
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %625 = extractelement <8 x i64> %624, i64 2
  %626 = getelementptr i8, ptr %623, i64 %625
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %628 = extractelement <8 x ptr> %627, i64 2
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %630 = extractelement <8 x i64> %629, i64 2
  %631 = getelementptr i8, ptr %628, i64 %630
  %632 = getelementptr i8, ptr %tile_snapshot.private38, i64 1024
  call void @llm_attention.strided_mma.3(ptr %621, ptr %626, ptr %631, ptr %632)
  br label %mma.continue418

mma.continue418:                                  ; preds = %mma.active417
  br label %mma.active419

mma.active419:                                    ; preds = %mma.continue418
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %634 = extractelement <8 x ptr> %633, i64 3
  %635 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %636 = extractelement <8 x i64> %635, i64 3
  %637 = getelementptr i8, ptr %634, i64 %636
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %639 = extractelement <8 x ptr> %638, i64 3
  %640 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %641 = extractelement <8 x i64> %640, i64 3
  %642 = getelementptr i8, ptr %639, i64 %641
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %644 = extractelement <8 x ptr> %643, i64 3
  %645 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %646 = extractelement <8 x i64> %645, i64 3
  %647 = getelementptr i8, ptr %644, i64 %646
  %648 = getelementptr i8, ptr %tile_snapshot.private38, i64 1536
  call void @llm_attention.strided_mma.3(ptr %637, ptr %642, ptr %647, ptr %648)
  br label %mma.continue420

mma.continue420:                                  ; preds = %mma.active419
  br label %mma.active421

mma.active421:                                    ; preds = %mma.continue420
  %649 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %650 = extractelement <8 x ptr> %649, i64 4
  %651 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %652 = extractelement <8 x i64> %651, i64 4
  %653 = getelementptr i8, ptr %650, i64 %652
  %654 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %655 = extractelement <8 x ptr> %654, i64 4
  %656 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %657 = extractelement <8 x i64> %656, i64 4
  %658 = getelementptr i8, ptr %655, i64 %657
  %659 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %660 = extractelement <8 x ptr> %659, i64 4
  %661 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %662 = extractelement <8 x i64> %661, i64 4
  %663 = getelementptr i8, ptr %660, i64 %662
  %664 = getelementptr i8, ptr %tile_snapshot.private38, i64 2048
  call void @llm_attention.strided_mma.3(ptr %653, ptr %658, ptr %663, ptr %664)
  br label %mma.continue422

mma.continue422:                                  ; preds = %mma.active421
  br label %mma.active423

mma.active423:                                    ; preds = %mma.continue422
  %665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %666 = extractelement <8 x ptr> %665, i64 5
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %668 = extractelement <8 x i64> %667, i64 5
  %669 = getelementptr i8, ptr %666, i64 %668
  %670 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %671 = extractelement <8 x ptr> %670, i64 5
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %673 = extractelement <8 x i64> %672, i64 5
  %674 = getelementptr i8, ptr %671, i64 %673
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %676 = extractelement <8 x ptr> %675, i64 5
  %677 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %678 = extractelement <8 x i64> %677, i64 5
  %679 = getelementptr i8, ptr %676, i64 %678
  %680 = getelementptr i8, ptr %tile_snapshot.private38, i64 2560
  call void @llm_attention.strided_mma.3(ptr %669, ptr %674, ptr %679, ptr %680)
  br label %mma.continue424

mma.continue424:                                  ; preds = %mma.active423
  br label %mma.active425

mma.active425:                                    ; preds = %mma.continue424
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %682 = extractelement <8 x ptr> %681, i64 6
  %683 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %684 = extractelement <8 x i64> %683, i64 6
  %685 = getelementptr i8, ptr %682, i64 %684
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %687 = extractelement <8 x ptr> %686, i64 6
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %689 = extractelement <8 x i64> %688, i64 6
  %690 = getelementptr i8, ptr %687, i64 %689
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %692 = extractelement <8 x ptr> %691, i64 6
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %694 = extractelement <8 x i64> %693, i64 6
  %695 = getelementptr i8, ptr %692, i64 %694
  %696 = getelementptr i8, ptr %tile_snapshot.private38, i64 3072
  call void @llm_attention.strided_mma.3(ptr %685, ptr %690, ptr %695, ptr %696)
  br label %mma.continue426

mma.continue426:                                  ; preds = %mma.active425
  br label %mma.active427

mma.active427:                                    ; preds = %mma.continue426
  %697 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 0
  %698 = extractelement <8 x ptr> %697, i64 7
  %699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load410, 1
  %700 = extractelement <8 x i64> %699, i64 7
  %701 = getelementptr i8, ptr %698, i64 %700
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 0
  %703 = extractelement <8 x ptr> %702, i64 7
  %704 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load411, 1
  %705 = extractelement <8 x i64> %704, i64 7
  %706 = getelementptr i8, ptr %703, i64 %705
  %707 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 0
  %708 = extractelement <8 x ptr> %707, i64 7
  %709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load412, 1
  %710 = extractelement <8 x i64> %709, i64 7
  %711 = getelementptr i8, ptr %708, i64 %710
  %712 = getelementptr i8, ptr %tile_snapshot.private38, i64 3584
  call void @llm_attention.strided_mma.3(ptr %701, ptr %706, ptr %711, ptr %712)
  br label %mma.continue428

mma.continue428:                                  ; preds = %mma.active427
  store i64 0, ptr %.slot98, align 4
  br label %direct.schedule.19

direct.true430:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false431:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true444:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false445:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true463:                                   ; preds = %direct.schedule.26
  br label %direct.schedule.27

direct.false464:                                  ; preds = %direct.schedule.26
  br label %direct.schedule.9

direct.true476:                                   ; preds = %direct.schedule.27
  br label %direct.schedule.28

direct.false477:                                  ; preds = %direct.schedule.27
  store <8 x float> zeroinitializer, ptr %.slot102, align 32
  br label %direct.schedule.29

direct.true486:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false487:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.7

direct.true499:                                   ; preds = %direct.schedule.32
  br label %direct.schedule.33

direct.false500:                                  ; preds = %direct.schedule.32
  store <8 x float> zeroinitializer, ptr %.slot105, align 32
  br label %direct.schedule.34

direct.true509:                                   ; preds = %direct.schedule.36
  br label %direct.schedule.37

direct.false510:                                  ; preds = %direct.schedule.36
  br label %direct.schedule.38
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nounwind willreturn }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nounwind willreturn "fp-contract"="off" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #5 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

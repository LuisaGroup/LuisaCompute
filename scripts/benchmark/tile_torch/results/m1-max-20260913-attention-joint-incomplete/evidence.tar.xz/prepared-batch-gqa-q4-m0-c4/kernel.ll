; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

@convergence.targets = private unnamed_addr constant [42 x i32] [i32 2, i32 5, i32 109, i32 9, i32 11, i32 14, i32 17, i32 20, i32 23, i32 26, i32 29, i32 32, i32 35, i32 38, i32 41, i32 44, i32 47, i32 50, i32 53, i32 56, i32 59, i32 62, i32 65, i32 68, i32 71, i32 74, i32 77, i32 80, i32 83, i32 92, i32 91, i32 90, i32 95, i32 98, i32 11, i32 103, i32 9, i32 108, i32 114, i32 113, i32 2, i32 119], align 4

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %live.mask = alloca <8 x i1>, align 1
  %runnable.mask = alloca <8 x i1>, align 1
  %ready.count = alloca i32, align 4
  %ready.mask = alloca [8 x <8 x i1>], align 1
  %ready.target = alloca [8 x i32], align 4
  %ready.token = alloca [8 x i32], align 4
  %current.mask = alloca <8 x i1>, align 1
  %current.token = alloca i32, align 4
  %frame.active = alloca i8, align 1
  %frame.static.id = alloca <8 x i32>, align 32
  %frame.parent.token = alloca <8 x i32>, align 32
  %frame.expected = alloca [8 x <8 x i1>], align 1
  %frame.arrived = alloca [8 x <8 x i1>], align 1
  store <8 x i1> zeroinitializer, ptr %live.mask, align 1
  store <8 x i1> zeroinitializer, ptr %runnable.mask, align 1
  store i32 0, ptr %ready.count, align 4
  store [8 x <8 x i1>] zeroinitializer, ptr %ready.mask, align 1
  store [8 x i32] zeroinitializer, ptr %ready.target, align 4
  store [8 x i32] zeroinitializer, ptr %ready.token, align 4
  store <8 x i1> zeroinitializer, ptr %current.mask, align 1
  store i32 0, ptr %current.token, align 4
  store i8 0, ptr %frame.active, align 1
  store <8 x i32> zeroinitializer, ptr %frame.static.id, align 32
  store <8 x i32> zeroinitializer, ptr %frame.parent.token, align 32
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.expected, align 1
  store [8 x <8 x i1>] zeroinitializer, ptr %frame.arrived, align 1
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 640, i64 1280, i64 1920, i64 2560, i64 3200, i64 3840, i64 4480>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 5120
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 11264
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 17408
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 2560, i64 5120, i64 7680, i64 10240, i64 12800, i64 15360, i64 17920>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 37888
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 3072, i64 6144, i64 9216, i64 12288, i64 15360, i64 18432, i64 21504>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 62464
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 64512
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 64640
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 66688
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 72832
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill37 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill37, align 64
  %.spill38 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill38, align 64
  %.spill39 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill39, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %tile_snapshot.spill40 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill40, align 64
  %tile_snapshot.spill41 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill41, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.slot42 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot42, align 64
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.spill51 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill51, align 64
  %tile_snapshot.spill52 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill52, align 64
  %.spill53 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill53, align 1
  %tile_snapshot.spill54 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill54, align 64
  %.slot55 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot55, align 64
  %.slot56 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot56, align 32
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot60, align 64
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.slot63 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot63, align 32
  %.slot64 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot64, align 32
  %.slot65 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot65, align 64
  %.slot66 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot66, align 32
  %.slot67 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot67, align 32
  %.slot68 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot68, align 32
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %.slot70 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot70, align 64
  %.slot71 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot71, align 32
  %.slot72 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot72, align 32
  %.slot73 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot73, align 32
  %.slot74 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot74, align 32
  %.slot75 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot75, align 64
  %.slot76 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot76, align 32
  %.slot77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot77, align 32
  %.slot78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot78, align 32
  %.slot79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot79, align 32
  %.slot80 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot80, align 64
  %.slot81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot81, align 32
  %.slot82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot82, align 32
  %.slot83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot83, align 32
  %.slot84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot84, align 32
  %.slot85 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot85, align 64
  %.slot86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot86, align 32
  %.slot87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot87, align 32
  %.slot88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot88, align 32
  %.slot89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot89, align 32
  %.slot90 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot90, align 64
  %.slot91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot91, align 32
  %.slot92 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot92, align 32
  %.slot93 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot93, align 32
  %.slot94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot94, align 32
  %.slot95 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot95, align 64
  %.slot96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot96, align 32
  %.slot97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot97, align 32
  %.slot98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot98, align 32
  %.slot99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot99, align 32
  %.slot100 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot100, align 64
  %.slot101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot101, align 32
  %.slot102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot102, align 32
  %.slot103 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot103, align 32
  %.slot104 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot104, align 32
  %.slot105 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot105, align 64
  %.slot106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot106, align 32
  %.slot107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot107, align 32
  %.slot108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot108, align 32
  %.slot109 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot109, align 32
  %.slot110 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot110, align 64
  %.slot111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot111, align 32
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.slot114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot114, align 32
  %.slot115 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot115, align 64
  %.slot116 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot116, align 32
  %.slot117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot117, align 32
  %.slot118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot118, align 32
  %.slot119 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot119, align 32
  %.slot120 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot120, align 64
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.slot122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot122, align 32
  %.slot123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot123, align 32
  %.slot124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot124, align 32
  %.slot125 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot125, align 64
  %.slot126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot126, align 32
  %.slot127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot127, align 32
  %.slot128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot128, align 32
  %.slot129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot129, align 32
  %.slot130 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot130, align 64
  %.slot131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot131, align 32
  %.slot132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot132, align 32
  %.slot133 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot133, align 32
  %.slot134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot134, align 32
  %.spill135 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill135, align 1
  %.spill136 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill136, align 1
  %.spill137 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill137, align 1
  %.spill138 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill138, align 1
  %.spill139 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill139, align 1
  %.spill140 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill140, align 1
  %.spill141 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill141, align 1
  %.spill142 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill142, align 1
  %.spill143 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill143, align 1
  %.spill144 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill144, align 1
  %.spill145 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill145, align 1
  %.spill146 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill146, align 1
  %.spill147 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill147, align 1
  %.spill148 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill148, align 1
  %.spill149 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill149, align 1
  %.spill150 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill150, align 1
  %.spill151 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill151, align 1
  %.spill152 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill152, align 1
  %.spill153 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill153, align 1
  %.spill154 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill154, align 1
  %.spill155 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill155, align 1
  %.spill156 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill156, align 1
  %.spill157 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill157, align 1
  %.spill158 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill158, align 1
  %.spill159 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill159, align 1
  %.spill160 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill160, align 1
  %.spill161 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill161, align 1
  %.spill162 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill162, align 1
  %.spill163 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill163, align 1
  %.spill164 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill164, align 1
  %.spill165 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill165, align 1
  %.spill166 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill166, align 1
  %.spill167 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill167, align 1
  %.spill168 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill168, align 1
  %.spill169 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill169, align 1
  %.spill170 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill170, align 1
  %.spill171 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill171, align 1
  %.spill172 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill172, align 1
  %.spill173 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill173, align 1
  %.spill174 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill174, align 1
  %.spill175 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill175, align 1
  %.spill176 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill176, align 1
  %.spill177 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill177, align 1
  %.spill178 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill178, align 1
  %.spill179 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill179, align 1
  %.spill180 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill180, align 1
  %.spill181 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill181, align 1
  %.spill182 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill182, align 1
  %.spill183 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill183, align 1
  %.spill184 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill184, align 1
  %.spill185 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill185, align 1
  %.spill186 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill186, align 1
  %.spill187 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill187, align 1
  %.spill188 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill188, align 1
  %.spill189 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill189, align 1
  %.spill190 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill190, align 1
  %.spill191 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill191, align 1
  %.spill192 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill192, align 1
  %.spill193 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill193, align 1
  %.spill194 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill194, align 1
  %.spill195 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill195, align 1
  %.spill196 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill196, align 1
  %.spill197 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill197, align 1
  %.spill198 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill198, align 1
  %.spill199 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill199, align 32
  %.spill200 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill200, align 32
  %.spill201 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill201, align 32
  %.spill202 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill202, align 32
  %.spill203 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill203, align 32
  %.spill204 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill204, align 32
  %.spill205 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill205, align 32
  %.spill206 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill206, align 32
  %.spill207 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill207, align 32
  %.spill208 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill208, align 32
  %.spill209 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill209, align 32
  %.spill210 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill210, align 32
  %.spill211 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill211, align 32
  %.spill212 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill212, align 32
  %.spill213 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill213, align 32
  %.spill214 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill214, align 32
  %.spill215 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill215, align 32
  %.spill216 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill216, align 32
  %.spill217 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill217, align 32
  %.spill218 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill218, align 32
  %.spill219 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill219, align 32
  %.spill220 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill220, align 32
  %.spill221 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill221, align 32
  %.spill222 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill222, align 32
  %.spill223 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill223, align 32
  %.spill224 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill224, align 32
  %.spill225 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill225, align 32
  %.spill226 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill226, align 32
  %.spill227 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill227, align 32
  %.spill228 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill228, align 32
  %.spill229 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill229, align 32
  %.spill230 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill230, align 32
  %.spill231 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill231, align 32
  %.spill232 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill232, align 32
  %.spill233 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill233, align 32
  %.spill234 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill234, align 32
  %.spill235 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill235, align 32
  %.spill236 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill236, align 32
  %.spill237 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill237, align 32
  %.spill238 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill238, align 32
  %.spill239 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill239, align 32
  %.spill240 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill240, align 32
  %.spill241 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill241, align 32
  %.spill242 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill242, align 32
  %.spill243 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill243, align 32
  %.spill244 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill244, align 32
  %.spill245 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill245, align 32
  %.spill246 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill246, align 32
  %.spill247 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill247, align 32
  %.spill248 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill248, align 32
  %.spill249 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill249, align 32
  %.spill250 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill250, align 32
  %.spill251 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill251, align 32
  %.spill252 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill252, align 32
  %.spill253 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill253, align 32
  %.spill254 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill254, align 32
  %.spill255 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill255, align 32
  %.spill256 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill256, align 32
  %.spill257 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill257, align 32
  %.spill258 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill258, align 32
  %.spill259 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill259, align 32
  %.spill260 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill260, align 32
  %.spill261 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill261, align 32
  %.spill262 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill262, align 32
  %tile_snapshot.spill263 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill263, align 64
  %.slot264 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot264, align 64
  %.slot265 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot265, align 32
  %.slot266 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot266, align 64
  %.slot267 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot267, align 32
  %.slot268 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot268, align 64
  %.slot269 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot269, align 32
  %.slot270 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot270, align 64
  %.slot271 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot271, align 32
  %.spill272 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill272, align 32
  %.spill273 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill273, align 32
  %.spill274 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill274, align 32
  %.spill275 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill275, align 32
  %tile_snapshot.spill276 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill276, align 64
  %tile_snapshot.spill277 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill277, align 64
  %.spill278 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill278, align 32
  %.spill279 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill279, align 32
  %.spill280 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill280, align 32
  %.spill281 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill281, align 32
  %.slot282 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot282, align 64
  %.slot283 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot283, align 32
  %.slot284 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot284, align 64
  %.slot285 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot285, align 32
  %.slot286 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot286, align 64
  %.slot287 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot287, align 32
  %.slot288 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot288, align 64
  %.slot289 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot289, align 32
  %.spill290 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill290, align 32
  %.spill291 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill291, align 32
  %.spill292 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill292, align 32
  %.spill293 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill293, align 32
  %tile_snapshot.spill294 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill294, align 64
  %.slot295 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot295, align 64
  %.spill296 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill296, align 64
  %.slot297 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot297, align 64
  %.spill298 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill298, align 64
  %.spill299 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill299, align 64
  %.spill300 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill300, align 64
  %.spill301 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill301, align 64
  %.spill302 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill302, align 64
  %.spill303 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill303, align 64
  %.spill304 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill304, align 64
  %.spill305 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill305, align 64
  %.slot306 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot306, align 64
  %.slot307 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot307, align 32
  %.slot308 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot308, align 32
  %.slot309 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot309, align 32
  %.slot310 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot310, align 32
  %.slot311 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot311, align 64
  %.slot312 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot312, align 64
  %.slot313 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot313, align 64
  %.spill314 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill314, align 64
  %.slot315 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot315, align 32
  %.slot316 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot316, align 64
  %.spill317 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill317, align 64
  %.slot318 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot318, align 32
  %tile_snapshot.spill319 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill319, align 64
  %.slot320 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot320, align 64
  %.spill321 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill321, align 64
  %.spill322 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill322, align 32
  %.slot323 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot323, align 64
  %.spill324 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill324, align 64
  %.slot325 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot325, align 32
  %30 = getelementptr i8, ptr %argument_buffer, i64 0
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 16
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 32
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = getelementptr i8, ptr %argument_buffer, i64 48
  %49 = load ptr, ptr %48, align 16
  %50 = getelementptr i8, ptr %48, i64 8
  %51 = load i64, ptr %50, align 8
  %52 = insertvalue { ptr, i64 } poison, ptr %49, 0
  %53 = insertvalue { ptr, i64 } %52, i64 %51, 1
  %54 = load i32, ptr %launch_config, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 12
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 4
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 16
  %60 = load i32, ptr %59, align 4
  %61 = getelementptr i8, ptr %launch_config, i64 8
  %62 = load i32, ptr %61, align 4
  %63 = getelementptr i8, ptr %launch_config, i64 20
  %64 = load i32, ptr %63, align 4
  %65 = getelementptr i8, ptr %launch_config, i64 36
  %66 = load i32, ptr %65, align 4
  %.splatinsert326 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat327 = shufflevector <8 x i32> %.splatinsert326, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat327, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %68 = mul i32 %54, 32
  %.splatinsert328 = insertelement <8 x i32> poison, i32 %68, i64 0
  %.splat329 = shufflevector <8 x i32> %.splatinsert328, <8 x i32> poison, <8 x i32> zeroinitializer
  %69 = add <8 x i32> %.splat329, %67
  %70 = mul i32 %58, 1
  %.splatinsert330 = insertelement <8 x i32> poison, i32 %70, i64 0
  %.splat331 = shufflevector <8 x i32> %.splatinsert330, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = add <8 x i32> %.splat331, zeroinitializer
  %72 = mul i32 %62, 1
  %.splatinsert332 = insertelement <8 x i32> poison, i32 %72, i64 0
  %.splat333 = shufflevector <8 x i32> %.splatinsert332, <8 x i32> poison, <8 x i32> zeroinitializer
  %73 = add <8 x i32> %.splat333, zeroinitializer
  %74 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %69, 0
  %75 = insertvalue [3 x <8 x i32>] %74, <8 x i32> %71, 1
  %76 = insertvalue [3 x <8 x i32>] %75, <8 x i32> %73, 2
  %.splatinsert334 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat335 = shufflevector <8 x i32> %.splatinsert334, <8 x i32> poison, <8 x i32> zeroinitializer
  %77 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat335
  store <8 x i1> %77, ptr %live.mask, align 1
  %78 = load i32, ptr %current.token, align 4
  %79 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %77)
  %80 = load i32, ptr %ready.count, align 4
  %81 = icmp uge i32 %80, 8
  %82 = and i1 %79, %81
  br i1 %82, label %ready.overflow.trap, label %ready.overflow.resume

ready.overflow.trap:                              ; preds = %prologue
  call void @llvm.trap()
  unreachable

ready.overflow.resume:                            ; preds = %prologue
  %83 = select i1 %79, i32 %80, i32 0
  %84 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %83
  %85 = load <8 x i1>, ptr %84, align 1
  %86 = select i1 %79, <8 x i1> %77, <8 x i1> %85
  store <8 x i1> %86, ptr %84, align 1
  %87 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %83
  %88 = load i32, ptr %87, align 4
  %89 = select i1 %79, i32 0, i32 %88
  store i32 %89, ptr %87, align 4
  %90 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %83
  %91 = load i32, ptr %90, align 4
  %92 = select i1 %79, i32 %78, i32 %91
  store i32 %92, ptr %90, align 4
  %93 = add i32 %80, 1
  %94 = select i1 %79, i32 %93, i32 %80
  store i32 %94, ptr %ready.count, align 4
  %95 = load <8 x i1>, ptr %runnable.mask, align 1
  %96 = or <8 x i1> %95, %77
  store <8 x i1> %96, ptr %runnable.mask, align 1
  br label %scheduler.loop

scheduler.loop:                                   ; preds = %convergence.target.119.ready, %convergence.cascade.exit2354, %schedule.118, %varying.coherent.false2351, %varying.coherent.true2350, %varying.coherent.false2338, %varying.coherent.true2337, %schedule.115, %return.frame.cleanup.done, %convergence.cascade.exit2266, %convergence.target.113.ready, %convergence.cascade.exit2248, %schedule.112, %varying.coherent.false2244, %varying.coherent.true2243, %varying.coherent.false2229, %varying.coherent.true2228, %convergence.target.109.ready, %convergence.cascade.exit2193, %convergence.target.108.ready, %convergence.cascade.exit2172, %schedule.107, %varying.coherent.false2169, %varying.coherent.true2168, %varying.coherent.false2156, %varying.coherent.true2155, %schedule.104, %convergence.target.103.ready, %convergence.cascade.exit2128, %schedule.102, %varying.coherent.false2125, %varying.coherent.true2124, %varying.coherent.false2112, %varying.coherent.true2111, %schedule.99, %convergence.target.98.ready, %convergence.cascade.exit2079, %schedule.97, %varying.coherent.false2072, %varying.coherent.true2071, %convergence.target.95.ready, %convergence.cascade.exit2048, %schedule.94, %varying.coherent.false2041, %varying.coherent.true2040, %convergence.target.92.ready, %convergence.cascade.exit2017, %convergence.target.91.ready, %convergence.cascade.exit1999, %convergence.target.90.ready, %convergence.cascade.exit1969, %schedule.89, %varying.coherent.false1951, %varying.coherent.true1950, %schedule.87, %varying.coherent.false1932, %varying.coherent.true1931, %schedule.85, %varying.coherent.false1922, %varying.coherent.true1921, %convergence.target.83.ready, %convergence.cascade.exit1890, %schedule.82, %varying.coherent.false1884, %varying.coherent.true1883, %convergence.target.80.ready, %convergence.cascade.exit1860, %schedule.79, %varying.coherent.false1854, %varying.coherent.true1853, %convergence.target.77.ready, %convergence.cascade.exit1830, %schedule.76, %varying.coherent.false1824, %varying.coherent.true1823, %convergence.target.74.ready, %convergence.cascade.exit1800, %schedule.73, %varying.coherent.false1794, %varying.coherent.true1793, %convergence.target.71.ready, %convergence.cascade.exit1423, %schedule.70, %varying.coherent.false1417, %varying.coherent.true1416, %convergence.target.68.ready, %convergence.cascade.exit1393, %schedule.67, %varying.coherent.false1387, %varying.coherent.true1386, %convergence.target.65.ready, %convergence.cascade.exit1363, %schedule.64, %varying.coherent.false1357, %varying.coherent.true1356, %convergence.target.62.ready, %convergence.cascade.exit1333, %schedule.61, %varying.coherent.false1327, %varying.coherent.true1326, %convergence.target.59.ready, %convergence.cascade.exit1093, %schedule.58, %varying.coherent.false1078, %varying.coherent.true1077, %convergence.target.56.ready, %convergence.cascade.exit1054, %schedule.55, %varying.coherent.false1039, %varying.coherent.true1038, %convergence.target.53.ready, %convergence.cascade.exit1015, %schedule.52, %varying.coherent.false1000, %varying.coherent.true999, %convergence.target.50.ready, %convergence.cascade.exit976, %schedule.49, %varying.coherent.false961, %varying.coherent.true960, %convergence.target.47.ready, %convergence.cascade.exit937, %schedule.46, %varying.coherent.false922, %varying.coherent.true921, %convergence.target.44.ready, %convergence.cascade.exit898, %schedule.43, %varying.coherent.false883, %varying.coherent.true882, %convergence.target.41.ready, %convergence.cascade.exit859, %schedule.40, %varying.coherent.false846, %varying.coherent.true845, %convergence.target.38.ready, %convergence.cascade.exit822, %schedule.37, %varying.coherent.false807, %varying.coherent.true806, %convergence.target.35.ready, %convergence.cascade.exit783, %schedule.34, %varying.coherent.false768, %varying.coherent.true767, %convergence.target.32.ready, %convergence.cascade.exit744, %schedule.31, %varying.coherent.false729, %varying.coherent.true728, %convergence.target.29.ready, %convergence.cascade.exit705, %schedule.28, %varying.coherent.false690, %varying.coherent.true689, %convergence.target.26.ready, %convergence.cascade.exit666, %schedule.25, %varying.coherent.false651, %varying.coherent.true650, %convergence.target.23.ready, %convergence.cascade.exit627, %schedule.22, %varying.coherent.false612, %varying.coherent.true611, %convergence.target.20.ready, %convergence.cascade.exit588, %schedule.19, %varying.coherent.false573, %varying.coherent.true572, %convergence.target.17.ready, %convergence.cascade.exit549, %schedule.16, %varying.coherent.false534, %varying.coherent.true533, %convergence.target.14.ready, %convergence.cascade.exit510, %schedule.13, %varying.coherent.false497, %varying.coherent.true496, %convergence.target.11.ready, %convergence.cascade.exit473, %copy.continue471, %varying.coherent.false451, %varying.coherent.true450, %convergence.cascade.exit427, %copy.continue425, %varying.coherent.false405, %varying.coherent.true404, %varying.coherent.false396, %varying.coherent.true395, %convergence.target.5.ready, %convergence.cascade.exit372, %schedule.4, %varying.coherent.false367, %varying.coherent.true366, %convergence.target.2.ready, %convergence.cascade.exit, %copy.continue353, %varying.coherent.false, %varying.coherent.true, %ready.overflow.resume
  %97 = load i32, ptr %ready.count, align 4
  %98 = icmp ne i32 %97, 0
  br i1 %98, label %scheduler.dispatch, label %scheduler.done

scheduler.dispatch:                               ; preds = %scheduler.loop
  %99 = sub i32 %97, 1
  store i32 %99, ptr %ready.count, align 4
  %100 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %99
  %101 = load <8 x i1>, ptr %100, align 1
  store <8 x i1> %101, ptr %current.mask, align 1
  %102 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %99
  %103 = load i32, ptr %102, align 4
  %104 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %99
  %105 = load i32, ptr %104, align 4
  store i32 %105, ptr %current.token, align 4
  %106 = load <8 x i1>, ptr %runnable.mask, align 1
  %107 = xor <8 x i1> %101, splat (i1 true)
  %108 = and <8 x i1> %106, %107
  store <8 x i1> %108, ptr %runnable.mask, align 1
  br label %scheduler.dispatch.route

scheduler.dispatch.route:                         ; preds = %ready.overflow.resume2349, %ready.overflow.resume2336, %ready.overflow.resume2242, %ready.overflow.resume2227, %ready.overflow.resume2167, %ready.overflow.resume2154, %ready.overflow.resume2123, %ready.overflow.resume2110, %ready.overflow.resume2070, %ready.overflow.resume2039, %ready.overflow.resume1949, %ready.overflow.resume1930, %ready.overflow.resume1920, %ready.overflow.resume1882, %ready.overflow.resume1852, %ready.overflow.resume1822, %ready.overflow.resume1792, %ready.overflow.resume1415, %ready.overflow.resume1385, %ready.overflow.resume1355, %ready.overflow.resume1325, %ready.overflow.resume1076, %ready.overflow.resume1037, %ready.overflow.resume998, %ready.overflow.resume959, %ready.overflow.resume920, %ready.overflow.resume881, %ready.overflow.resume844, %ready.overflow.resume805, %ready.overflow.resume766, %ready.overflow.resume727, %ready.overflow.resume688, %ready.overflow.resume649, %ready.overflow.resume610, %ready.overflow.resume571, %ready.overflow.resume532, %ready.overflow.resume495, %ready.overflow.resume449, %ready.overflow.resume403, %ready.overflow.resume394, %ready.overflow.resume365, %ready.overflow.resume337, %scheduler.dispatch
  %scheduler.dispatch.pc = phi i32 [ %103, %scheduler.dispatch ], [ 115, %ready.overflow.resume337 ], [ 5, %ready.overflow.resume365 ], [ 109, %ready.overflow.resume394 ], [ 104, %ready.overflow.resume403 ], [ 99, %ready.overflow.resume449 ], [ 14, %ready.overflow.resume495 ], [ 17, %ready.overflow.resume532 ], [ 20, %ready.overflow.resume571 ], [ 23, %ready.overflow.resume610 ], [ 26, %ready.overflow.resume649 ], [ 29, %ready.overflow.resume688 ], [ 32, %ready.overflow.resume727 ], [ 35, %ready.overflow.resume766 ], [ 38, %ready.overflow.resume805 ], [ 41, %ready.overflow.resume844 ], [ 44, %ready.overflow.resume881 ], [ 47, %ready.overflow.resume920 ], [ 50, %ready.overflow.resume959 ], [ 53, %ready.overflow.resume998 ], [ 56, %ready.overflow.resume1037 ], [ 59, %ready.overflow.resume1076 ], [ 62, %ready.overflow.resume1325 ], [ 65, %ready.overflow.resume1355 ], [ 68, %ready.overflow.resume1385 ], [ 71, %ready.overflow.resume1415 ], [ 74, %ready.overflow.resume1792 ], [ 77, %ready.overflow.resume1822 ], [ 80, %ready.overflow.resume1852 ], [ 83, %ready.overflow.resume1882 ], [ 92, %ready.overflow.resume1920 ], [ 91, %ready.overflow.resume1930 ], [ 90, %ready.overflow.resume1949 ], [ 95, %ready.overflow.resume2039 ], [ 98, %ready.overflow.resume2070 ], [ 11, %ready.overflow.resume2110 ], [ 103, %ready.overflow.resume2123 ], [ 9, %ready.overflow.resume2154 ], [ 108, %ready.overflow.resume2167 ], [ 114, %ready.overflow.resume2227 ], [ 113, %ready.overflow.resume2242 ], [ 2, %ready.overflow.resume2336 ], [ 119, %ready.overflow.resume2349 ]
  switch i32 %scheduler.dispatch.pc, label %scheduler.invalid [
    i32 0, label %schedule.0
    i32 1, label %schedule.1
    i32 2, label %schedule.2
    i32 3, label %schedule.3
    i32 4, label %schedule.4
    i32 5, label %schedule.5
    i32 6, label %schedule.6
    i32 7, label %schedule.7
    i32 8, label %schedule.8
    i32 9, label %schedule.9
    i32 10, label %schedule.10
    i32 11, label %schedule.11
    i32 12, label %schedule.12
    i32 13, label %schedule.13
    i32 14, label %schedule.14
    i32 15, label %schedule.15
    i32 16, label %schedule.16
    i32 17, label %schedule.17
    i32 18, label %schedule.18
    i32 19, label %schedule.19
    i32 20, label %schedule.20
    i32 21, label %schedule.21
    i32 22, label %schedule.22
    i32 23, label %schedule.23
    i32 24, label %schedule.24
    i32 25, label %schedule.25
    i32 26, label %schedule.26
    i32 27, label %schedule.27
    i32 28, label %schedule.28
    i32 29, label %schedule.29
    i32 30, label %schedule.30
    i32 31, label %schedule.31
    i32 32, label %schedule.32
    i32 33, label %schedule.33
    i32 34, label %schedule.34
    i32 35, label %schedule.35
    i32 36, label %schedule.36
    i32 37, label %schedule.37
    i32 38, label %schedule.38
    i32 39, label %schedule.39
    i32 40, label %schedule.40
    i32 41, label %schedule.41
    i32 42, label %schedule.42
    i32 43, label %schedule.43
    i32 44, label %schedule.44
    i32 45, label %schedule.45
    i32 46, label %schedule.46
    i32 47, label %schedule.47
    i32 48, label %schedule.48
    i32 49, label %schedule.49
    i32 50, label %schedule.50
    i32 51, label %schedule.51
    i32 52, label %schedule.52
    i32 53, label %schedule.53
    i32 54, label %schedule.54
    i32 55, label %schedule.55
    i32 56, label %schedule.56
    i32 57, label %schedule.57
    i32 58, label %schedule.58
    i32 59, label %schedule.59
    i32 60, label %schedule.60
    i32 61, label %schedule.61
    i32 62, label %schedule.62
    i32 63, label %schedule.63
    i32 64, label %schedule.64
    i32 65, label %schedule.65
    i32 66, label %schedule.66
    i32 67, label %schedule.67
    i32 68, label %schedule.68
    i32 69, label %schedule.69
    i32 70, label %schedule.70
    i32 71, label %schedule.71
    i32 72, label %schedule.72
    i32 73, label %schedule.73
    i32 74, label %schedule.74
    i32 75, label %schedule.75
    i32 76, label %schedule.76
    i32 77, label %schedule.77
    i32 78, label %schedule.78
    i32 79, label %schedule.79
    i32 80, label %schedule.80
    i32 81, label %schedule.81
    i32 82, label %schedule.82
    i32 83, label %schedule.83
    i32 84, label %schedule.84
    i32 85, label %schedule.85
    i32 86, label %schedule.86
    i32 87, label %schedule.87
    i32 88, label %schedule.88
    i32 89, label %schedule.89
    i32 90, label %schedule.90
    i32 91, label %schedule.91
    i32 92, label %schedule.92
    i32 93, label %schedule.93
    i32 94, label %schedule.94
    i32 95, label %schedule.95
    i32 96, label %schedule.96
    i32 97, label %schedule.97
    i32 98, label %schedule.98
    i32 99, label %schedule.99
    i32 100, label %schedule.100
    i32 101, label %schedule.101
    i32 102, label %schedule.102
    i32 103, label %schedule.103
    i32 104, label %schedule.104
    i32 105, label %schedule.105
    i32 106, label %schedule.106
    i32 107, label %schedule.107
    i32 108, label %schedule.108
    i32 109, label %schedule.109
    i32 110, label %schedule.110
    i32 111, label %schedule.111
    i32 112, label %schedule.112
    i32 113, label %schedule.113
    i32 114, label %schedule.114
    i32 115, label %schedule.115
    i32 116, label %schedule.116
    i32 117, label %schedule.117
    i32 118, label %schedule.118
    i32 119, label %schedule.119
  ]

scheduler.done:                                   ; preds = %scheduler.loop
  %109 = load <8 x i1>, ptr %live.mask, align 1
  %110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %109)
  br i1 %110, label %scheduler.stalled, label %scheduler.exit

scheduler.exit:                                   ; preds = %scheduler.done
  ret void

scheduler.stalled:                                ; preds = %scheduler.done
  call void @llvm.trap()
  unreachable

scheduler.invalid:                                ; preds = %scheduler.dispatch.route
  call void @llvm.trap()
  unreachable

schedule.0:                                       ; preds = %scheduler.dispatch.route
  %111 = load <8 x i1>, ptr %current.mask, align 1
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %113 = bitcast <8 x i1> %111 to i8
  %114 = call i8 @llvm.cttz.i8(i8 %113, i1 false)
  %115 = zext i8 %114 to i32
  %116 = select i1 %112, i32 %115, i32 0
  %117 = extractvalue [3 x <8 x i32>] %76, 0
  %118 = zext <8 x i32> %117 to <8 x i64>
  %119 = select <8 x i1> %111, <8 x i64> %118, <8 x i64> zeroinitializer
  %120 = select <8 x i1> %111, <8 x i64> splat (i64 30), <8 x i64> splat (i64 1)
  %121 = sdiv <8 x i64> %119, %120
  %122 = load <8 x i64>, ptr %.spill, align 64
  %123 = select <8 x i1> %111, <8 x i64> %121, <8 x i64> %122
  store <8 x i64> %123, ptr %.spill, align 64
  %124 = select <8 x i1> %111, <8 x i64> %118, <8 x i64> zeroinitializer
  %125 = select <8 x i1> %111, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %126 = sdiv <8 x i64> %124, %125
  %127 = select <8 x i1> %111, <8 x i64> %126, <8 x i64> zeroinitializer
  %128 = select <8 x i1> %111, <8 x i64> splat (i64 6), <8 x i64> splat (i64 1)
  %129 = srem <8 x i64> %127, %128
  %130 = load <8 x i64>, ptr %.spill37, align 64
  %131 = select <8 x i1> %111, <8 x i64> %129, <8 x i64> %130
  store <8 x i64> %131, ptr %.spill37, align 64
  %132 = select <8 x i1> %111, <8 x i64> %118, <8 x i64> zeroinitializer
  %133 = select <8 x i1> %111, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %134 = sdiv <8 x i64> %132, %133
  %135 = select <8 x i1> %111, <8 x i64> %134, <8 x i64> zeroinitializer
  %136 = select <8 x i1> %111, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %137 = srem <8 x i64> %135, %136
  %138 = mul <8 x i64> %137, splat (i64 4)
  %139 = load <8 x i64>, ptr %.spill38, align 64
  %140 = select <8 x i1> %111, <8 x i64> %138, <8 x i64> %139
  store <8 x i64> %140, ptr %.spill38, align 64
  %141 = select <8 x i1> %111, <8 x i64> %129, <8 x i64> zeroinitializer
  %142 = select <8 x i1> %111, <8 x i64> splat (i64 3), <8 x i64> splat (i64 1)
  %143 = sdiv <8 x i64> %141, %142
  %144 = load <8 x i64>, ptr %.spill39, align 64
  %145 = select <8 x i1> %111, <8 x i64> %143, <8 x i64> %144
  store <8 x i64> %145, ptr %.spill39, align 64
  %146 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %146, 0
  %149 = select <8 x i1> %111, <8 x ptr> %147, <8 x ptr> %148
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %146, 1
  %152 = select <8 x i1> %111, <8 x i64> %150, <8 x i64> %151
  %153 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %149, 0
  %154 = insertvalue { <8 x ptr>, <8 x i64> } %153, <8 x i64> %152, 1
  store { <8 x ptr>, <8 x i64> } %154, ptr %tile_snapshot.spill, align 64
  %155 = icmp sge <8 x i64> %138, zeroinitializer
  %156 = and <8 x i1> splat (i1 true), %155
  %157 = icmp sle <8 x i64> %138, splat (i64 13)
  %158 = and <8 x i1> %156, %157
  %159 = and <8 x i1> %111, %158
  %160 = xor <8 x i1> %158, splat (i1 true)
  %161 = and <8 x i1> %111, %160
  %162 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %159)
  %163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %161)
  %164 = and i1 %162, %163
  br i1 %164, label %varying.divergent, label %varying.coherent

schedule.1:                                       ; preds = %varying.coherent.true, %scheduler.dispatch.route
  %165 = load <8 x i1>, ptr %current.mask, align 1
  %166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %165)
  %167 = bitcast <8 x i1> %165 to i8
  %168 = call i8 @llvm.cttz.i8(i8 %167, i1 false)
  %169 = zext i8 %168 to i32
  %170 = select i1 %166, i32 %169, i32 0
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %171 = add <8 x i64> zeroinitializer, %.spill.load
  %172 = mul <8 x i64> %171, splat (i64 6)
  %.spill.load338 = load <8 x i64>, ptr %.spill37, align 64
  %173 = add <8 x i64> %172, %.spill.load338
  %174 = mul <8 x i64> %173, splat (i64 17)
  %.spill.load339 = load <8 x i64>, ptr %.spill38, align 64
  %175 = add <8 x i64> %174, %.spill.load339
  %176 = mul <8 x i64> %175, splat (i64 40)
  %177 = add <8 x i64> %176, zeroinitializer
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %178 = extractvalue { ptr, i64 } %35, 0
  %179 = extractelement <8 x i1> %165, i64 0
  br i1 %179, label %copy.active, label %copy.continue

schedule.2:                                       ; preds = %varying.coherent.false2338, %copy.continue353, %scheduler.dispatch.route
  %180 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token = load i32, ptr %current.token, align 4
  %convergence.token.present = icmp ne i32 %convergence.current.token, 0
  br i1 %convergence.token.present, label %convergence.cascade, label %convergence.cascade.exit

schedule.3:                                       ; preds = %schedule.4, %convergence.target.2.ready, %scheduler.dispatch.route
  %181 = load <8 x i1>, ptr %current.mask, align 1
  %182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %181)
  %183 = bitcast <8 x i1> %181 to i8
  %184 = call i8 @llvm.cttz.i8(i8 %183, i1 false)
  %185 = zext i8 %184 to i32
  %186 = select i1 %182, i32 %185, i32 0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %187 = icmp slt <8 x i64> %.state, splat (i64 192)
  %188 = and <8 x i1> %181, %187
  %189 = xor <8 x i1> %187, splat (i1 true)
  %190 = and <8 x i1> %181, %189
  %191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %188)
  %192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %190)
  %193 = and i1 %191, %192
  br i1 %193, label %varying.divergent360, label %varying.coherent361

schedule.4:                                       ; preds = %varying.coherent.true366, %scheduler.dispatch.route
  %194 = load <8 x i1>, ptr %current.mask, align 1
  %195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %194)
  %196 = bitcast <8 x i1> %194 to i8
  %197 = call i8 @llvm.cttz.i8(i8 %196, i1 false)
  %198 = zext i8 %197 to i32
  %199 = select i1 %195, i32 %198, i32 0
  %tile_snapshot.spill.load368 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load368, 0
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load368, 1
  %.state369 = load <8 x i64>, ptr %.slot, align 64
  %202 = mul <8 x i64> %.state369, splat (i64 32)
  %203 = add <8 x i64> %201, %202
  %204 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %200, 0
  %205 = insertvalue { <8 x ptr>, <8 x i64> } %204, <8 x i64> %203, 1
  %206 = extractvalue { <8 x ptr>, <8 x i64> } %205, 0
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %205, 1
  %208 = getelementptr i8, <8 x ptr> %206, <8 x i64> %207
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %208, <8 x i1> %194)
  %.state370 = load <8 x i64>, ptr %.slot, align 64
  %209 = add <8 x i64> %.state370, splat (i64 1)
  %210 = load <8 x i64>, ptr %.slot, align 64
  %211 = select <8 x i1> %194, <8 x i64> %209, <8 x i64> %210
  store <8 x i64> %211, ptr %.slot, align 64
  store <8 x i1> %194, ptr %current.mask, align 1
  %212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %194)
  br i1 %212, label %schedule.3, label %scheduler.loop

schedule.5:                                       ; preds = %varying.coherent.false367, %scheduler.dispatch.route
  %213 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token373 = load i32, ptr %current.token, align 4
  %convergence.token.present374 = icmp ne i32 %convergence.current.token373, 0
  br i1 %convergence.token.present374, label %convergence.cascade371, label %convergence.cascade.exit372

schedule.6:                                       ; preds = %convergence.target.98.ready, %convergence.target.5.ready, %scheduler.dispatch.route
  %214 = load <8 x i1>, ptr %current.mask, align 1
  %215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %214)
  %216 = bitcast <8 x i1> %214 to i8
  %217 = call i8 @llvm.cttz.i8(i8 %216, i1 false)
  %218 = zext i8 %217 to i32
  %219 = select i1 %215, i32 %218, i32 0
  %.state388 = load <8 x i64>, ptr %.slot, align 64
  %220 = icmp slt <8 x i64> %.state388, splat (i64 5)
  %221 = and <8 x i1> %214, %220
  %222 = xor <8 x i1> %220, splat (i1 true)
  %223 = and <8 x i1> %214, %222
  %224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  %225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %223)
  %226 = and i1 %224, %225
  br i1 %226, label %varying.divergent389, label %varying.coherent390

schedule.7:                                       ; preds = %varying.coherent.true395, %scheduler.dispatch.route
  %227 = load <8 x i1>, ptr %current.mask, align 1
  %228 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %227)
  %229 = bitcast <8 x i1> %227 to i8
  %230 = call i8 @llvm.cttz.i8(i8 %229, i1 false)
  %231 = zext i8 %230 to i32
  %232 = select i1 %228, i32 %231, i32 0
  %.state397 = load <8 x i64>, ptr %.slot, align 64
  %233 = select <8 x i1> %227, <8 x i64> %.state397, <8 x i64> zeroinitializer
  %234 = select <8 x i1> %227, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %235 = sdiv <8 x i64> %233, %234
  %236 = mul <8 x i64> %235, splat (i64 16)
  %237 = load <8 x i64>, ptr %.spill51, align 64
  %238 = select <8 x i1> %227, <8 x i64> %236, <8 x i64> %237
  store <8 x i64> %238, ptr %.spill51, align 64
  %239 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 0
  %242 = select <8 x i1> %227, <8 x ptr> %240, <8 x ptr> %241
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %245 = select <8 x i1> %227, <8 x i64> %243, <8 x i64> %244
  %246 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %242, 0
  %247 = insertvalue { <8 x ptr>, <8 x i64> } %246, <8 x i64> %245, 1
  store { <8 x ptr>, <8 x i64> } %247, ptr %tile_snapshot.spill52, align 64
  %248 = icmp sge <8 x i64> %236, zeroinitializer
  %249 = and <8 x i1> splat (i1 true), %248
  %250 = icmp sle <8 x i64> %236, splat (i64 51)
  %251 = and <8 x i1> %249, %250
  %252 = load <8 x i1>, ptr %.spill53, align 1
  %253 = select <8 x i1> %227, <8 x i1> %251, <8 x i1> %252
  store <8 x i1> %253, ptr %.spill53, align 1
  %254 = and <8 x i1> %227, %251
  %255 = xor <8 x i1> %251, splat (i1 true)
  %256 = and <8 x i1> %227, %255
  %257 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  %258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %256)
  %259 = and i1 %257, %258
  br i1 %259, label %varying.divergent398, label %varying.coherent399

schedule.8:                                       ; preds = %varying.coherent.true404, %scheduler.dispatch.route
  %260 = load <8 x i1>, ptr %current.mask, align 1
  %261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %260)
  %262 = bitcast <8 x i1> %260 to i8
  %263 = call i8 @llvm.cttz.i8(i8 %262, i1 false)
  %264 = zext i8 %263 to i32
  %265 = select i1 %261, i32 %264, i32 0
  %.spill.load406 = load <8 x i64>, ptr %.spill, align 64
  %266 = add <8 x i64> zeroinitializer, %.spill.load406
  %267 = mul <8 x i64> %266, splat (i64 2)
  %.spill.load407 = load <8 x i64>, ptr %.spill39, align 64
  %268 = add <8 x i64> %267, %.spill.load407
  %269 = mul <8 x i64> %268, splat (i64 67)
  %.spill.load408 = load <8 x i64>, ptr %.spill51, align 64
  %270 = add <8 x i64> %269, %.spill.load408
  %271 = mul <8 x i64> %270, splat (i64 40)
  %272 = add <8 x i64> %271, zeroinitializer
  %tile_snapshot.spill.load409 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %273 = extractvalue { ptr, i64 } %41, 0
  %274 = extractelement <8 x i1> %260, i64 0
  br i1 %274, label %copy.active410, label %copy.continue411

schedule.9:                                       ; preds = %varying.coherent.false2156, %copy.continue425, %scheduler.dispatch.route
  %275 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token428 = load i32, ptr %current.token, align 4
  %convergence.token.present429 = icmp ne i32 %convergence.current.token428, 0
  br i1 %convergence.token.present429, label %convergence.cascade426, label %convergence.cascade.exit427

schedule.10:                                      ; preds = %varying.coherent.true450, %scheduler.dispatch.route
  %276 = load <8 x i1>, ptr %current.mask, align 1
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  %278 = bitcast <8 x i1> %276 to i8
  %279 = call i8 @llvm.cttz.i8(i8 %278, i1 false)
  %280 = zext i8 %279 to i32
  %281 = select i1 %277, i32 %280, i32 0
  %.spill.load452 = load <8 x i64>, ptr %.spill, align 64
  %282 = add <8 x i64> zeroinitializer, %.spill.load452
  %283 = mul <8 x i64> %282, splat (i64 2)
  %.spill.load453 = load <8 x i64>, ptr %.spill39, align 64
  %284 = add <8 x i64> %283, %.spill.load453
  %285 = mul <8 x i64> %284, splat (i64 67)
  %.spill.load454 = load <8 x i64>, ptr %.spill51, align 64
  %286 = add <8 x i64> %285, %.spill.load454
  %287 = mul <8 x i64> %286, splat (i64 48)
  %288 = add <8 x i64> %287, zeroinitializer
  %tile_snapshot.spill.load455 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %289 = extractvalue { ptr, i64 } %47, 0
  %290 = extractelement <8 x i1> %276, i64 0
  br i1 %290, label %copy.active456, label %copy.continue457

schedule.11:                                      ; preds = %varying.coherent.false2112, %copy.continue471, %scheduler.dispatch.route
  %291 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token474 = load i32, ptr %current.token, align 4
  %convergence.token.present475 = icmp ne i32 %convergence.current.token474, 0
  br i1 %convergence.token.present475, label %convergence.cascade472, label %convergence.cascade.exit473

schedule.12:                                      ; preds = %schedule.13, %convergence.target.11.ready, %scheduler.dispatch.route
  %292 = load <8 x i1>, ptr %current.mask, align 1
  %293 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %292)
  %294 = bitcast <8 x i1> %292 to i8
  %295 = call i8 @llvm.cttz.i8(i8 %294, i1 false)
  %296 = zext i8 %295 to i32
  %297 = select i1 %293, i32 %296, i32 0
  %.state489 = load <8 x i64>, ptr %.slot55, align 64
  %298 = icmp slt <8 x i64> %.state489, splat (i64 40)
  %299 = and <8 x i1> %292, %298
  %300 = xor <8 x i1> %298, splat (i1 true)
  %301 = and <8 x i1> %292, %300
  %302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %299)
  %303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %301)
  %304 = and i1 %302, %303
  br i1 %304, label %varying.divergent490, label %varying.coherent491

schedule.13:                                      ; preds = %varying.coherent.true496, %scheduler.dispatch.route
  %305 = load <8 x i1>, ptr %current.mask, align 1
  %306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %305)
  %307 = bitcast <8 x i1> %305 to i8
  %308 = call i8 @llvm.cttz.i8(i8 %307, i1 false)
  %309 = zext i8 %308 to i32
  %310 = select i1 %306, i32 %309, i32 0
  %.state498 = load <8 x i64>, ptr %.slot55, align 64
  %311 = add <8 x i64> zeroinitializer, %.state498
  %tile_snapshot.spill.load499 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load499, 0
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load499, 1
  %314 = mul <8 x i64> %311, splat (i64 4)
  %315 = add <8 x i64> %313, %314
  %316 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %312, 0
  %317 = insertvalue { <8 x ptr>, <8 x i64> } %316, <8 x i64> %315, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %317, 0
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %317, 1
  %320 = getelementptr i8, <8 x ptr> %318, <8 x i64> %319
  %321 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %320, <8 x i1> %305, <8 x float> zeroinitializer)
  %.state500 = load <8 x i64>, ptr %.slot55, align 64
  %322 = add <8 x i64> splat (i64 40), %.state500
  %tile_snapshot.spill.load501 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load501, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load501, 1
  %325 = mul <8 x i64> %322, splat (i64 4)
  %326 = add <8 x i64> %324, %325
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %323, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %328, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %328, 1
  %331 = getelementptr i8, <8 x ptr> %329, <8 x i64> %330
  %332 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %331, <8 x i1> %305, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load502 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load502, 0
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load502, 1
  %335 = mul <8 x i64> %311, splat (i64 4)
  %336 = add <8 x i64> %334, %335
  %337 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %333, 0
  %338 = insertvalue { <8 x ptr>, <8 x i64> } %337, <8 x i64> %336, 1
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %338, 0
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %338, 1
  %341 = getelementptr i8, <8 x ptr> %339, <8 x i64> %340
  %342 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %341, <8 x i1> %305, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load503 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load503, 0
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load503, 1
  %345 = mul <8 x i64> %322, splat (i64 4)
  %346 = add <8 x i64> %344, %345
  %347 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %343, 0
  %348 = insertvalue { <8 x ptr>, <8 x i64> } %347, <8 x i64> %346, 1
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %348, 0
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %348, 1
  %351 = getelementptr i8, <8 x ptr> %349, <8 x i64> %350
  %352 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %351, <8 x i1> %305, <8 x float> zeroinitializer)
  %353 = fmul <8 x float> %321, %342
  %.state504 = load <8 x float>, ptr %.slot56, align 32
  %354 = fadd <8 x float> %.state504, %353
  %355 = fmul <8 x float> %321, %352
  %.state505 = load <8 x float>, ptr %.slot57, align 32
  %356 = fadd <8 x float> %.state505, %355
  %357 = fmul <8 x float> %332, %342
  %.state506 = load <8 x float>, ptr %.slot58, align 32
  %358 = fadd <8 x float> %.state506, %357
  %359 = fmul <8 x float> %332, %352
  %.state507 = load <8 x float>, ptr %.slot59, align 32
  %360 = fadd <8 x float> %.state507, %359
  %.state508 = load <8 x i64>, ptr %.slot55, align 64
  %361 = add <8 x i64> %.state508, splat (i64 1)
  %362 = load <8 x i64>, ptr %.slot55, align 64
  %363 = select <8 x i1> %305, <8 x i64> %361, <8 x i64> %362
  store <8 x i64> %363, ptr %.slot55, align 64
  %364 = load <8 x float>, ptr %.slot56, align 32
  %365 = select <8 x i1> %305, <8 x float> %354, <8 x float> %364
  store <8 x float> %365, ptr %.slot56, align 32
  %366 = load <8 x float>, ptr %.slot57, align 32
  %367 = select <8 x i1> %305, <8 x float> %356, <8 x float> %366
  store <8 x float> %367, ptr %.slot57, align 32
  %368 = load <8 x float>, ptr %.slot58, align 32
  %369 = select <8 x i1> %305, <8 x float> %358, <8 x float> %368
  store <8 x float> %369, ptr %.slot58, align 32
  %370 = load <8 x float>, ptr %.slot59, align 32
  %371 = select <8 x i1> %305, <8 x float> %360, <8 x float> %370
  store <8 x float> %371, ptr %.slot59, align 32
  store <8 x i1> %305, ptr %current.mask, align 1
  %372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %305)
  br i1 %372, label %schedule.12, label %scheduler.loop

schedule.14:                                      ; preds = %varying.coherent.false497, %scheduler.dispatch.route
  %373 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token511 = load i32, ptr %current.token, align 4
  %convergence.token.present512 = icmp ne i32 %convergence.current.token511, 0
  br i1 %convergence.token.present512, label %convergence.cascade509, label %convergence.cascade.exit510

schedule.15:                                      ; preds = %schedule.16, %convergence.target.14.ready, %scheduler.dispatch.route
  %374 = load <8 x i1>, ptr %current.mask, align 1
  %375 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  %376 = bitcast <8 x i1> %374 to i8
  %377 = call i8 @llvm.cttz.i8(i8 %376, i1 false)
  %378 = zext i8 %377 to i32
  %379 = select i1 %375, i32 %378, i32 0
  %.state526 = load <8 x i64>, ptr %.slot55, align 64
  %380 = icmp slt <8 x i64> %.state526, splat (i64 40)
  %381 = and <8 x i1> %374, %380
  %382 = xor <8 x i1> %380, splat (i1 true)
  %383 = and <8 x i1> %374, %382
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %381)
  %385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %383)
  %386 = and i1 %384, %385
  br i1 %386, label %varying.divergent527, label %varying.coherent528

schedule.16:                                      ; preds = %varying.coherent.true533, %scheduler.dispatch.route
  %387 = load <8 x i1>, ptr %current.mask, align 1
  %388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %387)
  %389 = bitcast <8 x i1> %387 to i8
  %390 = call i8 @llvm.cttz.i8(i8 %389, i1 false)
  %391 = zext i8 %390 to i32
  %392 = select i1 %388, i32 %391, i32 0
  %.state535 = load <8 x i64>, ptr %.slot55, align 64
  %393 = add <8 x i64> zeroinitializer, %.state535
  %tile_snapshot.spill.load536 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load536, 0
  %395 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load536, 1
  %396 = mul <8 x i64> %393, splat (i64 4)
  %397 = add <8 x i64> %395, %396
  %398 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %394, 0
  %399 = insertvalue { <8 x ptr>, <8 x i64> } %398, <8 x i64> %397, 1
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %399, 0
  %401 = extractvalue { <8 x ptr>, <8 x i64> } %399, 1
  %402 = getelementptr i8, <8 x ptr> %400, <8 x i64> %401
  %403 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %402, <8 x i1> %387, <8 x float> zeroinitializer)
  %.state537 = load <8 x i64>, ptr %.slot55, align 64
  %404 = add <8 x i64> splat (i64 40), %.state537
  %tile_snapshot.spill.load538 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load538, 0
  %406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load538, 1
  %407 = mul <8 x i64> %404, splat (i64 4)
  %408 = add <8 x i64> %406, %407
  %409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %405, 0
  %410 = insertvalue { <8 x ptr>, <8 x i64> } %409, <8 x i64> %408, 1
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %410, 0
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %410, 1
  %413 = getelementptr i8, <8 x ptr> %411, <8 x i64> %412
  %414 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %413, <8 x i1> %387, <8 x float> zeroinitializer)
  %.state539 = load <8 x i64>, ptr %.slot55, align 64
  %415 = add <8 x i64> splat (i64 80), %.state539
  %tile_snapshot.spill.load540 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load540, 0
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load540, 1
  %418 = mul <8 x i64> %415, splat (i64 4)
  %419 = add <8 x i64> %417, %418
  %420 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %416, 0
  %421 = insertvalue { <8 x ptr>, <8 x i64> } %420, <8 x i64> %419, 1
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %421, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %421, 1
  %424 = getelementptr i8, <8 x ptr> %422, <8 x i64> %423
  %425 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %424, <8 x i1> %387, <8 x float> zeroinitializer)
  %.state541 = load <8 x i64>, ptr %.slot55, align 64
  %426 = add <8 x i64> splat (i64 120), %.state541
  %tile_snapshot.spill.load542 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load542, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load542, 1
  %429 = mul <8 x i64> %426, splat (i64 4)
  %430 = add <8 x i64> %428, %429
  %431 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %427, 0
  %432 = insertvalue { <8 x ptr>, <8 x i64> } %431, <8 x i64> %430, 1
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %432, 0
  %434 = extractvalue { <8 x ptr>, <8 x i64> } %432, 1
  %435 = getelementptr i8, <8 x ptr> %433, <8 x i64> %434
  %436 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %435, <8 x i1> %387, <8 x float> zeroinitializer)
  %437 = fmul <8 x float> %403, %425
  %.state543 = load <8 x float>, ptr %.slot61, align 32
  %438 = fadd <8 x float> %.state543, %437
  %439 = fmul <8 x float> %403, %436
  %.state544 = load <8 x float>, ptr %.slot62, align 32
  %440 = fadd <8 x float> %.state544, %439
  %441 = fmul <8 x float> %414, %425
  %.state545 = load <8 x float>, ptr %.slot63, align 32
  %442 = fadd <8 x float> %.state545, %441
  %443 = fmul <8 x float> %414, %436
  %.state546 = load <8 x float>, ptr %.slot64, align 32
  %444 = fadd <8 x float> %.state546, %443
  %.state547 = load <8 x i64>, ptr %.slot55, align 64
  %445 = add <8 x i64> %.state547, splat (i64 1)
  %446 = load <8 x i64>, ptr %.slot55, align 64
  %447 = select <8 x i1> %387, <8 x i64> %445, <8 x i64> %446
  store <8 x i64> %447, ptr %.slot55, align 64
  %448 = load <8 x float>, ptr %.slot61, align 32
  %449 = select <8 x i1> %387, <8 x float> %438, <8 x float> %448
  store <8 x float> %449, ptr %.slot61, align 32
  %450 = load <8 x float>, ptr %.slot62, align 32
  %451 = select <8 x i1> %387, <8 x float> %440, <8 x float> %450
  store <8 x float> %451, ptr %.slot62, align 32
  %452 = load <8 x float>, ptr %.slot63, align 32
  %453 = select <8 x i1> %387, <8 x float> %442, <8 x float> %452
  store <8 x float> %453, ptr %.slot63, align 32
  %454 = load <8 x float>, ptr %.slot64, align 32
  %455 = select <8 x i1> %387, <8 x float> %444, <8 x float> %454
  store <8 x float> %455, ptr %.slot64, align 32
  store <8 x i1> %387, ptr %current.mask, align 1
  %456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %387)
  br i1 %456, label %schedule.15, label %scheduler.loop

schedule.17:                                      ; preds = %varying.coherent.false534, %scheduler.dispatch.route
  %457 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token550 = load i32, ptr %current.token, align 4
  %convergence.token.present551 = icmp ne i32 %convergence.current.token550, 0
  br i1 %convergence.token.present551, label %convergence.cascade548, label %convergence.cascade.exit549

schedule.18:                                      ; preds = %schedule.19, %convergence.target.17.ready, %scheduler.dispatch.route
  %458 = load <8 x i1>, ptr %current.mask, align 1
  %459 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %458)
  %460 = bitcast <8 x i1> %458 to i8
  %461 = call i8 @llvm.cttz.i8(i8 %460, i1 false)
  %462 = zext i8 %461 to i32
  %463 = select i1 %459, i32 %462, i32 0
  %.state565 = load <8 x i64>, ptr %.slot55, align 64
  %464 = icmp slt <8 x i64> %.state565, splat (i64 40)
  %465 = and <8 x i1> %458, %464
  %466 = xor <8 x i1> %464, splat (i1 true)
  %467 = and <8 x i1> %458, %466
  %468 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %465)
  %469 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %467)
  %470 = and i1 %468, %469
  br i1 %470, label %varying.divergent566, label %varying.coherent567

schedule.19:                                      ; preds = %varying.coherent.true572, %scheduler.dispatch.route
  %471 = load <8 x i1>, ptr %current.mask, align 1
  %472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %471)
  %473 = bitcast <8 x i1> %471 to i8
  %474 = call i8 @llvm.cttz.i8(i8 %473, i1 false)
  %475 = zext i8 %474 to i32
  %476 = select i1 %472, i32 %475, i32 0
  %.state574 = load <8 x i64>, ptr %.slot55, align 64
  %477 = add <8 x i64> zeroinitializer, %.state574
  %tile_snapshot.spill.load575 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load575, 0
  %479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load575, 1
  %480 = mul <8 x i64> %477, splat (i64 4)
  %481 = add <8 x i64> %479, %480
  %482 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %478, 0
  %483 = insertvalue { <8 x ptr>, <8 x i64> } %482, <8 x i64> %481, 1
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %483, 0
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %483, 1
  %486 = getelementptr i8, <8 x ptr> %484, <8 x i64> %485
  %487 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %486, <8 x i1> %471, <8 x float> zeroinitializer)
  %.state576 = load <8 x i64>, ptr %.slot55, align 64
  %488 = add <8 x i64> splat (i64 40), %.state576
  %tile_snapshot.spill.load577 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load577, 0
  %490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load577, 1
  %491 = mul <8 x i64> %488, splat (i64 4)
  %492 = add <8 x i64> %490, %491
  %493 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %489, 0
  %494 = insertvalue { <8 x ptr>, <8 x i64> } %493, <8 x i64> %492, 1
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %494, 0
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %494, 1
  %497 = getelementptr i8, <8 x ptr> %495, <8 x i64> %496
  %498 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %497, <8 x i1> %471, <8 x float> zeroinitializer)
  %.state578 = load <8 x i64>, ptr %.slot55, align 64
  %499 = add <8 x i64> splat (i64 160), %.state578
  %tile_snapshot.spill.load579 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load579, 0
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load579, 1
  %502 = mul <8 x i64> %499, splat (i64 4)
  %503 = add <8 x i64> %501, %502
  %504 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %500, 0
  %505 = insertvalue { <8 x ptr>, <8 x i64> } %504, <8 x i64> %503, 1
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %505, 0
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %505, 1
  %508 = getelementptr i8, <8 x ptr> %506, <8 x i64> %507
  %509 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %508, <8 x i1> %471, <8 x float> zeroinitializer)
  %.state580 = load <8 x i64>, ptr %.slot55, align 64
  %510 = add <8 x i64> splat (i64 200), %.state580
  %tile_snapshot.spill.load581 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load581, 0
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load581, 1
  %513 = mul <8 x i64> %510, splat (i64 4)
  %514 = add <8 x i64> %512, %513
  %515 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %511, 0
  %516 = insertvalue { <8 x ptr>, <8 x i64> } %515, <8 x i64> %514, 1
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %516, 0
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %516, 1
  %519 = getelementptr i8, <8 x ptr> %517, <8 x i64> %518
  %520 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %519, <8 x i1> %471, <8 x float> zeroinitializer)
  %521 = fmul <8 x float> %487, %509
  %.state582 = load <8 x float>, ptr %.slot66, align 32
  %522 = fadd <8 x float> %.state582, %521
  %523 = fmul <8 x float> %487, %520
  %.state583 = load <8 x float>, ptr %.slot67, align 32
  %524 = fadd <8 x float> %.state583, %523
  %525 = fmul <8 x float> %498, %509
  %.state584 = load <8 x float>, ptr %.slot68, align 32
  %526 = fadd <8 x float> %.state584, %525
  %527 = fmul <8 x float> %498, %520
  %.state585 = load <8 x float>, ptr %.slot69, align 32
  %528 = fadd <8 x float> %.state585, %527
  %.state586 = load <8 x i64>, ptr %.slot55, align 64
  %529 = add <8 x i64> %.state586, splat (i64 1)
  %530 = load <8 x i64>, ptr %.slot55, align 64
  %531 = select <8 x i1> %471, <8 x i64> %529, <8 x i64> %530
  store <8 x i64> %531, ptr %.slot55, align 64
  %532 = load <8 x float>, ptr %.slot66, align 32
  %533 = select <8 x i1> %471, <8 x float> %522, <8 x float> %532
  store <8 x float> %533, ptr %.slot66, align 32
  %534 = load <8 x float>, ptr %.slot67, align 32
  %535 = select <8 x i1> %471, <8 x float> %524, <8 x float> %534
  store <8 x float> %535, ptr %.slot67, align 32
  %536 = load <8 x float>, ptr %.slot68, align 32
  %537 = select <8 x i1> %471, <8 x float> %526, <8 x float> %536
  store <8 x float> %537, ptr %.slot68, align 32
  %538 = load <8 x float>, ptr %.slot69, align 32
  %539 = select <8 x i1> %471, <8 x float> %528, <8 x float> %538
  store <8 x float> %539, ptr %.slot69, align 32
  store <8 x i1> %471, ptr %current.mask, align 1
  %540 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %471)
  br i1 %540, label %schedule.18, label %scheduler.loop

schedule.20:                                      ; preds = %varying.coherent.false573, %scheduler.dispatch.route
  %541 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token589 = load i32, ptr %current.token, align 4
  %convergence.token.present590 = icmp ne i32 %convergence.current.token589, 0
  br i1 %convergence.token.present590, label %convergence.cascade587, label %convergence.cascade.exit588

schedule.21:                                      ; preds = %schedule.22, %convergence.target.20.ready, %scheduler.dispatch.route
  %542 = load <8 x i1>, ptr %current.mask, align 1
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %542)
  %544 = bitcast <8 x i1> %542 to i8
  %545 = call i8 @llvm.cttz.i8(i8 %544, i1 false)
  %546 = zext i8 %545 to i32
  %547 = select i1 %543, i32 %546, i32 0
  %.state604 = load <8 x i64>, ptr %.slot55, align 64
  %548 = icmp slt <8 x i64> %.state604, splat (i64 40)
  %549 = and <8 x i1> %542, %548
  %550 = xor <8 x i1> %548, splat (i1 true)
  %551 = and <8 x i1> %542, %550
  %552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %549)
  %553 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %551)
  %554 = and i1 %552, %553
  br i1 %554, label %varying.divergent605, label %varying.coherent606

schedule.22:                                      ; preds = %varying.coherent.true611, %scheduler.dispatch.route
  %555 = load <8 x i1>, ptr %current.mask, align 1
  %556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %555)
  %557 = bitcast <8 x i1> %555 to i8
  %558 = call i8 @llvm.cttz.i8(i8 %557, i1 false)
  %559 = zext i8 %558 to i32
  %560 = select i1 %556, i32 %559, i32 0
  %.state613 = load <8 x i64>, ptr %.slot55, align 64
  %561 = add <8 x i64> zeroinitializer, %.state613
  %tile_snapshot.spill.load614 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 0
  %563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 1
  %564 = mul <8 x i64> %561, splat (i64 4)
  %565 = add <8 x i64> %563, %564
  %566 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %562, 0
  %567 = insertvalue { <8 x ptr>, <8 x i64> } %566, <8 x i64> %565, 1
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %567, 0
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %567, 1
  %570 = getelementptr i8, <8 x ptr> %568, <8 x i64> %569
  %571 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %570, <8 x i1> %555, <8 x float> zeroinitializer)
  %.state615 = load <8 x i64>, ptr %.slot55, align 64
  %572 = add <8 x i64> splat (i64 40), %.state615
  %tile_snapshot.spill.load616 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load616, 0
  %574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load616, 1
  %575 = mul <8 x i64> %572, splat (i64 4)
  %576 = add <8 x i64> %574, %575
  %577 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %573, 0
  %578 = insertvalue { <8 x ptr>, <8 x i64> } %577, <8 x i64> %576, 1
  %579 = extractvalue { <8 x ptr>, <8 x i64> } %578, 0
  %580 = extractvalue { <8 x ptr>, <8 x i64> } %578, 1
  %581 = getelementptr i8, <8 x ptr> %579, <8 x i64> %580
  %582 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %581, <8 x i1> %555, <8 x float> zeroinitializer)
  %.state617 = load <8 x i64>, ptr %.slot55, align 64
  %583 = add <8 x i64> splat (i64 240), %.state617
  %tile_snapshot.spill.load618 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load618, 0
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load618, 1
  %586 = mul <8 x i64> %583, splat (i64 4)
  %587 = add <8 x i64> %585, %586
  %588 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %584, 0
  %589 = insertvalue { <8 x ptr>, <8 x i64> } %588, <8 x i64> %587, 1
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %589, 0
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %589, 1
  %592 = getelementptr i8, <8 x ptr> %590, <8 x i64> %591
  %593 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %592, <8 x i1> %555, <8 x float> zeroinitializer)
  %.state619 = load <8 x i64>, ptr %.slot55, align 64
  %594 = add <8 x i64> splat (i64 280), %.state619
  %tile_snapshot.spill.load620 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %595 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load620, 0
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load620, 1
  %597 = mul <8 x i64> %594, splat (i64 4)
  %598 = add <8 x i64> %596, %597
  %599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %595, 0
  %600 = insertvalue { <8 x ptr>, <8 x i64> } %599, <8 x i64> %598, 1
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %600, 0
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %600, 1
  %603 = getelementptr i8, <8 x ptr> %601, <8 x i64> %602
  %604 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %603, <8 x i1> %555, <8 x float> zeroinitializer)
  %605 = fmul <8 x float> %571, %593
  %.state621 = load <8 x float>, ptr %.slot71, align 32
  %606 = fadd <8 x float> %.state621, %605
  %607 = fmul <8 x float> %571, %604
  %.state622 = load <8 x float>, ptr %.slot72, align 32
  %608 = fadd <8 x float> %.state622, %607
  %609 = fmul <8 x float> %582, %593
  %.state623 = load <8 x float>, ptr %.slot73, align 32
  %610 = fadd <8 x float> %.state623, %609
  %611 = fmul <8 x float> %582, %604
  %.state624 = load <8 x float>, ptr %.slot74, align 32
  %612 = fadd <8 x float> %.state624, %611
  %.state625 = load <8 x i64>, ptr %.slot55, align 64
  %613 = add <8 x i64> %.state625, splat (i64 1)
  %614 = load <8 x i64>, ptr %.slot55, align 64
  %615 = select <8 x i1> %555, <8 x i64> %613, <8 x i64> %614
  store <8 x i64> %615, ptr %.slot55, align 64
  %616 = load <8 x float>, ptr %.slot71, align 32
  %617 = select <8 x i1> %555, <8 x float> %606, <8 x float> %616
  store <8 x float> %617, ptr %.slot71, align 32
  %618 = load <8 x float>, ptr %.slot72, align 32
  %619 = select <8 x i1> %555, <8 x float> %608, <8 x float> %618
  store <8 x float> %619, ptr %.slot72, align 32
  %620 = load <8 x float>, ptr %.slot73, align 32
  %621 = select <8 x i1> %555, <8 x float> %610, <8 x float> %620
  store <8 x float> %621, ptr %.slot73, align 32
  %622 = load <8 x float>, ptr %.slot74, align 32
  %623 = select <8 x i1> %555, <8 x float> %612, <8 x float> %622
  store <8 x float> %623, ptr %.slot74, align 32
  store <8 x i1> %555, ptr %current.mask, align 1
  %624 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %555)
  br i1 %624, label %schedule.21, label %scheduler.loop

schedule.23:                                      ; preds = %varying.coherent.false612, %scheduler.dispatch.route
  %625 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token628 = load i32, ptr %current.token, align 4
  %convergence.token.present629 = icmp ne i32 %convergence.current.token628, 0
  br i1 %convergence.token.present629, label %convergence.cascade626, label %convergence.cascade.exit627

schedule.24:                                      ; preds = %schedule.25, %convergence.target.23.ready, %scheduler.dispatch.route
  %626 = load <8 x i1>, ptr %current.mask, align 1
  %627 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %626)
  %628 = bitcast <8 x i1> %626 to i8
  %629 = call i8 @llvm.cttz.i8(i8 %628, i1 false)
  %630 = zext i8 %629 to i32
  %631 = select i1 %627, i32 %630, i32 0
  %.state643 = load <8 x i64>, ptr %.slot55, align 64
  %632 = icmp slt <8 x i64> %.state643, splat (i64 40)
  %633 = and <8 x i1> %626, %632
  %634 = xor <8 x i1> %632, splat (i1 true)
  %635 = and <8 x i1> %626, %634
  %636 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %635)
  %638 = and i1 %636, %637
  br i1 %638, label %varying.divergent644, label %varying.coherent645

schedule.25:                                      ; preds = %varying.coherent.true650, %scheduler.dispatch.route
  %639 = load <8 x i1>, ptr %current.mask, align 1
  %640 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %639)
  %641 = bitcast <8 x i1> %639 to i8
  %642 = call i8 @llvm.cttz.i8(i8 %641, i1 false)
  %643 = zext i8 %642 to i32
  %644 = select i1 %640, i32 %643, i32 0
  %.state652 = load <8 x i64>, ptr %.slot55, align 64
  %645 = add <8 x i64> zeroinitializer, %.state652
  %tile_snapshot.spill.load653 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load653, 0
  %647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load653, 1
  %648 = mul <8 x i64> %645, splat (i64 4)
  %649 = add <8 x i64> %647, %648
  %650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %646, 0
  %651 = insertvalue { <8 x ptr>, <8 x i64> } %650, <8 x i64> %649, 1
  %652 = extractvalue { <8 x ptr>, <8 x i64> } %651, 0
  %653 = extractvalue { <8 x ptr>, <8 x i64> } %651, 1
  %654 = getelementptr i8, <8 x ptr> %652, <8 x i64> %653
  %655 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %654, <8 x i1> %639, <8 x float> zeroinitializer)
  %.state654 = load <8 x i64>, ptr %.slot55, align 64
  %656 = add <8 x i64> splat (i64 40), %.state654
  %tile_snapshot.spill.load655 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load655, 0
  %658 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load655, 1
  %659 = mul <8 x i64> %656, splat (i64 4)
  %660 = add <8 x i64> %658, %659
  %661 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %657, 0
  %662 = insertvalue { <8 x ptr>, <8 x i64> } %661, <8 x i64> %660, 1
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %662, 0
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %662, 1
  %665 = getelementptr i8, <8 x ptr> %663, <8 x i64> %664
  %666 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %665, <8 x i1> %639, <8 x float> zeroinitializer)
  %.state656 = load <8 x i64>, ptr %.slot55, align 64
  %667 = add <8 x i64> splat (i64 320), %.state656
  %tile_snapshot.spill.load657 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load657, 0
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load657, 1
  %670 = mul <8 x i64> %667, splat (i64 4)
  %671 = add <8 x i64> %669, %670
  %672 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %668, 0
  %673 = insertvalue { <8 x ptr>, <8 x i64> } %672, <8 x i64> %671, 1
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %673, 0
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %673, 1
  %676 = getelementptr i8, <8 x ptr> %674, <8 x i64> %675
  %677 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %676, <8 x i1> %639, <8 x float> zeroinitializer)
  %.state658 = load <8 x i64>, ptr %.slot55, align 64
  %678 = add <8 x i64> splat (i64 360), %.state658
  %tile_snapshot.spill.load659 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %679 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load659, 0
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load659, 1
  %681 = mul <8 x i64> %678, splat (i64 4)
  %682 = add <8 x i64> %680, %681
  %683 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %679, 0
  %684 = insertvalue { <8 x ptr>, <8 x i64> } %683, <8 x i64> %682, 1
  %685 = extractvalue { <8 x ptr>, <8 x i64> } %684, 0
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %684, 1
  %687 = getelementptr i8, <8 x ptr> %685, <8 x i64> %686
  %688 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %687, <8 x i1> %639, <8 x float> zeroinitializer)
  %689 = fmul <8 x float> %655, %677
  %.state660 = load <8 x float>, ptr %.slot76, align 32
  %690 = fadd <8 x float> %.state660, %689
  %691 = fmul <8 x float> %655, %688
  %.state661 = load <8 x float>, ptr %.slot77, align 32
  %692 = fadd <8 x float> %.state661, %691
  %693 = fmul <8 x float> %666, %677
  %.state662 = load <8 x float>, ptr %.slot78, align 32
  %694 = fadd <8 x float> %.state662, %693
  %695 = fmul <8 x float> %666, %688
  %.state663 = load <8 x float>, ptr %.slot79, align 32
  %696 = fadd <8 x float> %.state663, %695
  %.state664 = load <8 x i64>, ptr %.slot55, align 64
  %697 = add <8 x i64> %.state664, splat (i64 1)
  %698 = load <8 x i64>, ptr %.slot55, align 64
  %699 = select <8 x i1> %639, <8 x i64> %697, <8 x i64> %698
  store <8 x i64> %699, ptr %.slot55, align 64
  %700 = load <8 x float>, ptr %.slot76, align 32
  %701 = select <8 x i1> %639, <8 x float> %690, <8 x float> %700
  store <8 x float> %701, ptr %.slot76, align 32
  %702 = load <8 x float>, ptr %.slot77, align 32
  %703 = select <8 x i1> %639, <8 x float> %692, <8 x float> %702
  store <8 x float> %703, ptr %.slot77, align 32
  %704 = load <8 x float>, ptr %.slot78, align 32
  %705 = select <8 x i1> %639, <8 x float> %694, <8 x float> %704
  store <8 x float> %705, ptr %.slot78, align 32
  %706 = load <8 x float>, ptr %.slot79, align 32
  %707 = select <8 x i1> %639, <8 x float> %696, <8 x float> %706
  store <8 x float> %707, ptr %.slot79, align 32
  store <8 x i1> %639, ptr %current.mask, align 1
  %708 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %639)
  br i1 %708, label %schedule.24, label %scheduler.loop

schedule.26:                                      ; preds = %varying.coherent.false651, %scheduler.dispatch.route
  %709 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token667 = load i32, ptr %current.token, align 4
  %convergence.token.present668 = icmp ne i32 %convergence.current.token667, 0
  br i1 %convergence.token.present668, label %convergence.cascade665, label %convergence.cascade.exit666

schedule.27:                                      ; preds = %schedule.28, %convergence.target.26.ready, %scheduler.dispatch.route
  %710 = load <8 x i1>, ptr %current.mask, align 1
  %711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %710)
  %712 = bitcast <8 x i1> %710 to i8
  %713 = call i8 @llvm.cttz.i8(i8 %712, i1 false)
  %714 = zext i8 %713 to i32
  %715 = select i1 %711, i32 %714, i32 0
  %.state682 = load <8 x i64>, ptr %.slot55, align 64
  %716 = icmp slt <8 x i64> %.state682, splat (i64 40)
  %717 = and <8 x i1> %710, %716
  %718 = xor <8 x i1> %716, splat (i1 true)
  %719 = and <8 x i1> %710, %718
  %720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %717)
  %721 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %719)
  %722 = and i1 %720, %721
  br i1 %722, label %varying.divergent683, label %varying.coherent684

schedule.28:                                      ; preds = %varying.coherent.true689, %scheduler.dispatch.route
  %723 = load <8 x i1>, ptr %current.mask, align 1
  %724 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %723)
  %725 = bitcast <8 x i1> %723 to i8
  %726 = call i8 @llvm.cttz.i8(i8 %725, i1 false)
  %727 = zext i8 %726 to i32
  %728 = select i1 %724, i32 %727, i32 0
  %.state691 = load <8 x i64>, ptr %.slot55, align 64
  %729 = add <8 x i64> zeroinitializer, %.state691
  %tile_snapshot.spill.load692 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load692, 0
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load692, 1
  %732 = mul <8 x i64> %729, splat (i64 4)
  %733 = add <8 x i64> %731, %732
  %734 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %730, 0
  %735 = insertvalue { <8 x ptr>, <8 x i64> } %734, <8 x i64> %733, 1
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %735, 0
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %735, 1
  %738 = getelementptr i8, <8 x ptr> %736, <8 x i64> %737
  %739 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %738, <8 x i1> %723, <8 x float> zeroinitializer)
  %.state693 = load <8 x i64>, ptr %.slot55, align 64
  %740 = add <8 x i64> splat (i64 40), %.state693
  %tile_snapshot.spill.load694 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load694, 0
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load694, 1
  %743 = mul <8 x i64> %740, splat (i64 4)
  %744 = add <8 x i64> %742, %743
  %745 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %741, 0
  %746 = insertvalue { <8 x ptr>, <8 x i64> } %745, <8 x i64> %744, 1
  %747 = extractvalue { <8 x ptr>, <8 x i64> } %746, 0
  %748 = extractvalue { <8 x ptr>, <8 x i64> } %746, 1
  %749 = getelementptr i8, <8 x ptr> %747, <8 x i64> %748
  %750 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %749, <8 x i1> %723, <8 x float> zeroinitializer)
  %.state695 = load <8 x i64>, ptr %.slot55, align 64
  %751 = add <8 x i64> splat (i64 400), %.state695
  %tile_snapshot.spill.load696 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %752 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load696, 0
  %753 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load696, 1
  %754 = mul <8 x i64> %751, splat (i64 4)
  %755 = add <8 x i64> %753, %754
  %756 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %752, 0
  %757 = insertvalue { <8 x ptr>, <8 x i64> } %756, <8 x i64> %755, 1
  %758 = extractvalue { <8 x ptr>, <8 x i64> } %757, 0
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %757, 1
  %760 = getelementptr i8, <8 x ptr> %758, <8 x i64> %759
  %761 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %760, <8 x i1> %723, <8 x float> zeroinitializer)
  %.state697 = load <8 x i64>, ptr %.slot55, align 64
  %762 = add <8 x i64> splat (i64 440), %.state697
  %tile_snapshot.spill.load698 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load698, 0
  %764 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load698, 1
  %765 = mul <8 x i64> %762, splat (i64 4)
  %766 = add <8 x i64> %764, %765
  %767 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %763, 0
  %768 = insertvalue { <8 x ptr>, <8 x i64> } %767, <8 x i64> %766, 1
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %768, 0
  %770 = extractvalue { <8 x ptr>, <8 x i64> } %768, 1
  %771 = getelementptr i8, <8 x ptr> %769, <8 x i64> %770
  %772 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %771, <8 x i1> %723, <8 x float> zeroinitializer)
  %773 = fmul <8 x float> %739, %761
  %.state699 = load <8 x float>, ptr %.slot81, align 32
  %774 = fadd <8 x float> %.state699, %773
  %775 = fmul <8 x float> %739, %772
  %.state700 = load <8 x float>, ptr %.slot82, align 32
  %776 = fadd <8 x float> %.state700, %775
  %777 = fmul <8 x float> %750, %761
  %.state701 = load <8 x float>, ptr %.slot83, align 32
  %778 = fadd <8 x float> %.state701, %777
  %779 = fmul <8 x float> %750, %772
  %.state702 = load <8 x float>, ptr %.slot84, align 32
  %780 = fadd <8 x float> %.state702, %779
  %.state703 = load <8 x i64>, ptr %.slot55, align 64
  %781 = add <8 x i64> %.state703, splat (i64 1)
  %782 = load <8 x i64>, ptr %.slot55, align 64
  %783 = select <8 x i1> %723, <8 x i64> %781, <8 x i64> %782
  store <8 x i64> %783, ptr %.slot55, align 64
  %784 = load <8 x float>, ptr %.slot81, align 32
  %785 = select <8 x i1> %723, <8 x float> %774, <8 x float> %784
  store <8 x float> %785, ptr %.slot81, align 32
  %786 = load <8 x float>, ptr %.slot82, align 32
  %787 = select <8 x i1> %723, <8 x float> %776, <8 x float> %786
  store <8 x float> %787, ptr %.slot82, align 32
  %788 = load <8 x float>, ptr %.slot83, align 32
  %789 = select <8 x i1> %723, <8 x float> %778, <8 x float> %788
  store <8 x float> %789, ptr %.slot83, align 32
  %790 = load <8 x float>, ptr %.slot84, align 32
  %791 = select <8 x i1> %723, <8 x float> %780, <8 x float> %790
  store <8 x float> %791, ptr %.slot84, align 32
  store <8 x i1> %723, ptr %current.mask, align 1
  %792 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %723)
  br i1 %792, label %schedule.27, label %scheduler.loop

schedule.29:                                      ; preds = %varying.coherent.false690, %scheduler.dispatch.route
  %793 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token706 = load i32, ptr %current.token, align 4
  %convergence.token.present707 = icmp ne i32 %convergence.current.token706, 0
  br i1 %convergence.token.present707, label %convergence.cascade704, label %convergence.cascade.exit705

schedule.30:                                      ; preds = %schedule.31, %convergence.target.29.ready, %scheduler.dispatch.route
  %794 = load <8 x i1>, ptr %current.mask, align 1
  %795 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %794)
  %796 = bitcast <8 x i1> %794 to i8
  %797 = call i8 @llvm.cttz.i8(i8 %796, i1 false)
  %798 = zext i8 %797 to i32
  %799 = select i1 %795, i32 %798, i32 0
  %.state721 = load <8 x i64>, ptr %.slot55, align 64
  %800 = icmp slt <8 x i64> %.state721, splat (i64 40)
  %801 = and <8 x i1> %794, %800
  %802 = xor <8 x i1> %800, splat (i1 true)
  %803 = and <8 x i1> %794, %802
  %804 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %801)
  %805 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %803)
  %806 = and i1 %804, %805
  br i1 %806, label %varying.divergent722, label %varying.coherent723

schedule.31:                                      ; preds = %varying.coherent.true728, %scheduler.dispatch.route
  %807 = load <8 x i1>, ptr %current.mask, align 1
  %808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %807)
  %809 = bitcast <8 x i1> %807 to i8
  %810 = call i8 @llvm.cttz.i8(i8 %809, i1 false)
  %811 = zext i8 %810 to i32
  %812 = select i1 %808, i32 %811, i32 0
  %.state730 = load <8 x i64>, ptr %.slot55, align 64
  %813 = add <8 x i64> zeroinitializer, %.state730
  %tile_snapshot.spill.load731 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %814 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load731, 0
  %815 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load731, 1
  %816 = mul <8 x i64> %813, splat (i64 4)
  %817 = add <8 x i64> %815, %816
  %818 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %814, 0
  %819 = insertvalue { <8 x ptr>, <8 x i64> } %818, <8 x i64> %817, 1
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %819, 0
  %821 = extractvalue { <8 x ptr>, <8 x i64> } %819, 1
  %822 = getelementptr i8, <8 x ptr> %820, <8 x i64> %821
  %823 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %822, <8 x i1> %807, <8 x float> zeroinitializer)
  %.state732 = load <8 x i64>, ptr %.slot55, align 64
  %824 = add <8 x i64> splat (i64 40), %.state732
  %tile_snapshot.spill.load733 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load733, 0
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load733, 1
  %827 = mul <8 x i64> %824, splat (i64 4)
  %828 = add <8 x i64> %826, %827
  %829 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %825, 0
  %830 = insertvalue { <8 x ptr>, <8 x i64> } %829, <8 x i64> %828, 1
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %830, 0
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %830, 1
  %833 = getelementptr i8, <8 x ptr> %831, <8 x i64> %832
  %834 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %833, <8 x i1> %807, <8 x float> zeroinitializer)
  %.state734 = load <8 x i64>, ptr %.slot55, align 64
  %835 = add <8 x i64> splat (i64 480), %.state734
  %tile_snapshot.spill.load735 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load735, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load735, 1
  %838 = mul <8 x i64> %835, splat (i64 4)
  %839 = add <8 x i64> %837, %838
  %840 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %836, 0
  %841 = insertvalue { <8 x ptr>, <8 x i64> } %840, <8 x i64> %839, 1
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %841, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %841, 1
  %844 = getelementptr i8, <8 x ptr> %842, <8 x i64> %843
  %845 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %844, <8 x i1> %807, <8 x float> zeroinitializer)
  %.state736 = load <8 x i64>, ptr %.slot55, align 64
  %846 = add <8 x i64> splat (i64 520), %.state736
  %tile_snapshot.spill.load737 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %847 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load737, 0
  %848 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load737, 1
  %849 = mul <8 x i64> %846, splat (i64 4)
  %850 = add <8 x i64> %848, %849
  %851 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %847, 0
  %852 = insertvalue { <8 x ptr>, <8 x i64> } %851, <8 x i64> %850, 1
  %853 = extractvalue { <8 x ptr>, <8 x i64> } %852, 0
  %854 = extractvalue { <8 x ptr>, <8 x i64> } %852, 1
  %855 = getelementptr i8, <8 x ptr> %853, <8 x i64> %854
  %856 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %855, <8 x i1> %807, <8 x float> zeroinitializer)
  %857 = fmul <8 x float> %823, %845
  %.state738 = load <8 x float>, ptr %.slot86, align 32
  %858 = fadd <8 x float> %.state738, %857
  %859 = fmul <8 x float> %823, %856
  %.state739 = load <8 x float>, ptr %.slot87, align 32
  %860 = fadd <8 x float> %.state739, %859
  %861 = fmul <8 x float> %834, %845
  %.state740 = load <8 x float>, ptr %.slot88, align 32
  %862 = fadd <8 x float> %.state740, %861
  %863 = fmul <8 x float> %834, %856
  %.state741 = load <8 x float>, ptr %.slot89, align 32
  %864 = fadd <8 x float> %.state741, %863
  %.state742 = load <8 x i64>, ptr %.slot55, align 64
  %865 = add <8 x i64> %.state742, splat (i64 1)
  %866 = load <8 x i64>, ptr %.slot55, align 64
  %867 = select <8 x i1> %807, <8 x i64> %865, <8 x i64> %866
  store <8 x i64> %867, ptr %.slot55, align 64
  %868 = load <8 x float>, ptr %.slot86, align 32
  %869 = select <8 x i1> %807, <8 x float> %858, <8 x float> %868
  store <8 x float> %869, ptr %.slot86, align 32
  %870 = load <8 x float>, ptr %.slot87, align 32
  %871 = select <8 x i1> %807, <8 x float> %860, <8 x float> %870
  store <8 x float> %871, ptr %.slot87, align 32
  %872 = load <8 x float>, ptr %.slot88, align 32
  %873 = select <8 x i1> %807, <8 x float> %862, <8 x float> %872
  store <8 x float> %873, ptr %.slot88, align 32
  %874 = load <8 x float>, ptr %.slot89, align 32
  %875 = select <8 x i1> %807, <8 x float> %864, <8 x float> %874
  store <8 x float> %875, ptr %.slot89, align 32
  store <8 x i1> %807, ptr %current.mask, align 1
  %876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %807)
  br i1 %876, label %schedule.30, label %scheduler.loop

schedule.32:                                      ; preds = %varying.coherent.false729, %scheduler.dispatch.route
  %877 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token745 = load i32, ptr %current.token, align 4
  %convergence.token.present746 = icmp ne i32 %convergence.current.token745, 0
  br i1 %convergence.token.present746, label %convergence.cascade743, label %convergence.cascade.exit744

schedule.33:                                      ; preds = %schedule.34, %convergence.target.32.ready, %scheduler.dispatch.route
  %878 = load <8 x i1>, ptr %current.mask, align 1
  %879 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %878)
  %880 = bitcast <8 x i1> %878 to i8
  %881 = call i8 @llvm.cttz.i8(i8 %880, i1 false)
  %882 = zext i8 %881 to i32
  %883 = select i1 %879, i32 %882, i32 0
  %.state760 = load <8 x i64>, ptr %.slot55, align 64
  %884 = icmp slt <8 x i64> %.state760, splat (i64 40)
  %885 = and <8 x i1> %878, %884
  %886 = xor <8 x i1> %884, splat (i1 true)
  %887 = and <8 x i1> %878, %886
  %888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %885)
  %889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %887)
  %890 = and i1 %888, %889
  br i1 %890, label %varying.divergent761, label %varying.coherent762

schedule.34:                                      ; preds = %varying.coherent.true767, %scheduler.dispatch.route
  %891 = load <8 x i1>, ptr %current.mask, align 1
  %892 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %891)
  %893 = bitcast <8 x i1> %891 to i8
  %894 = call i8 @llvm.cttz.i8(i8 %893, i1 false)
  %895 = zext i8 %894 to i32
  %896 = select i1 %892, i32 %895, i32 0
  %.state769 = load <8 x i64>, ptr %.slot55, align 64
  %897 = add <8 x i64> zeroinitializer, %.state769
  %tile_snapshot.spill.load770 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %898 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load770, 0
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load770, 1
  %900 = mul <8 x i64> %897, splat (i64 4)
  %901 = add <8 x i64> %899, %900
  %902 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %898, 0
  %903 = insertvalue { <8 x ptr>, <8 x i64> } %902, <8 x i64> %901, 1
  %904 = extractvalue { <8 x ptr>, <8 x i64> } %903, 0
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %903, 1
  %906 = getelementptr i8, <8 x ptr> %904, <8 x i64> %905
  %907 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %906, <8 x i1> %891, <8 x float> zeroinitializer)
  %.state771 = load <8 x i64>, ptr %.slot55, align 64
  %908 = add <8 x i64> splat (i64 40), %.state771
  %tile_snapshot.spill.load772 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %909 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load772, 0
  %910 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load772, 1
  %911 = mul <8 x i64> %908, splat (i64 4)
  %912 = add <8 x i64> %910, %911
  %913 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %909, 0
  %914 = insertvalue { <8 x ptr>, <8 x i64> } %913, <8 x i64> %912, 1
  %915 = extractvalue { <8 x ptr>, <8 x i64> } %914, 0
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %914, 1
  %917 = getelementptr i8, <8 x ptr> %915, <8 x i64> %916
  %918 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %917, <8 x i1> %891, <8 x float> zeroinitializer)
  %.state773 = load <8 x i64>, ptr %.slot55, align 64
  %919 = add <8 x i64> splat (i64 560), %.state773
  %tile_snapshot.spill.load774 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load774, 0
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load774, 1
  %922 = mul <8 x i64> %919, splat (i64 4)
  %923 = add <8 x i64> %921, %922
  %924 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %920, 0
  %925 = insertvalue { <8 x ptr>, <8 x i64> } %924, <8 x i64> %923, 1
  %926 = extractvalue { <8 x ptr>, <8 x i64> } %925, 0
  %927 = extractvalue { <8 x ptr>, <8 x i64> } %925, 1
  %928 = getelementptr i8, <8 x ptr> %926, <8 x i64> %927
  %929 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %928, <8 x i1> %891, <8 x float> zeroinitializer)
  %.state775 = load <8 x i64>, ptr %.slot55, align 64
  %930 = add <8 x i64> splat (i64 600), %.state775
  %tile_snapshot.spill.load776 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %931 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 0
  %932 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 1
  %933 = mul <8 x i64> %930, splat (i64 4)
  %934 = add <8 x i64> %932, %933
  %935 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %931, 0
  %936 = insertvalue { <8 x ptr>, <8 x i64> } %935, <8 x i64> %934, 1
  %937 = extractvalue { <8 x ptr>, <8 x i64> } %936, 0
  %938 = extractvalue { <8 x ptr>, <8 x i64> } %936, 1
  %939 = getelementptr i8, <8 x ptr> %937, <8 x i64> %938
  %940 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %939, <8 x i1> %891, <8 x float> zeroinitializer)
  %941 = fmul <8 x float> %907, %929
  %.state777 = load <8 x float>, ptr %.slot91, align 32
  %942 = fadd <8 x float> %.state777, %941
  %943 = fmul <8 x float> %907, %940
  %.state778 = load <8 x float>, ptr %.slot92, align 32
  %944 = fadd <8 x float> %.state778, %943
  %945 = fmul <8 x float> %918, %929
  %.state779 = load <8 x float>, ptr %.slot93, align 32
  %946 = fadd <8 x float> %.state779, %945
  %947 = fmul <8 x float> %918, %940
  %.state780 = load <8 x float>, ptr %.slot94, align 32
  %948 = fadd <8 x float> %.state780, %947
  %.state781 = load <8 x i64>, ptr %.slot55, align 64
  %949 = add <8 x i64> %.state781, splat (i64 1)
  %950 = load <8 x i64>, ptr %.slot55, align 64
  %951 = select <8 x i1> %891, <8 x i64> %949, <8 x i64> %950
  store <8 x i64> %951, ptr %.slot55, align 64
  %952 = load <8 x float>, ptr %.slot91, align 32
  %953 = select <8 x i1> %891, <8 x float> %942, <8 x float> %952
  store <8 x float> %953, ptr %.slot91, align 32
  %954 = load <8 x float>, ptr %.slot92, align 32
  %955 = select <8 x i1> %891, <8 x float> %944, <8 x float> %954
  store <8 x float> %955, ptr %.slot92, align 32
  %956 = load <8 x float>, ptr %.slot93, align 32
  %957 = select <8 x i1> %891, <8 x float> %946, <8 x float> %956
  store <8 x float> %957, ptr %.slot93, align 32
  %958 = load <8 x float>, ptr %.slot94, align 32
  %959 = select <8 x i1> %891, <8 x float> %948, <8 x float> %958
  store <8 x float> %959, ptr %.slot94, align 32
  store <8 x i1> %891, ptr %current.mask, align 1
  %960 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %891)
  br i1 %960, label %schedule.33, label %scheduler.loop

schedule.35:                                      ; preds = %varying.coherent.false768, %scheduler.dispatch.route
  %961 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token784 = load i32, ptr %current.token, align 4
  %convergence.token.present785 = icmp ne i32 %convergence.current.token784, 0
  br i1 %convergence.token.present785, label %convergence.cascade782, label %convergence.cascade.exit783

schedule.36:                                      ; preds = %schedule.37, %convergence.target.35.ready, %scheduler.dispatch.route
  %962 = load <8 x i1>, ptr %current.mask, align 1
  %963 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %962)
  %964 = bitcast <8 x i1> %962 to i8
  %965 = call i8 @llvm.cttz.i8(i8 %964, i1 false)
  %966 = zext i8 %965 to i32
  %967 = select i1 %963, i32 %966, i32 0
  %.state799 = load <8 x i64>, ptr %.slot55, align 64
  %968 = icmp slt <8 x i64> %.state799, splat (i64 40)
  %969 = and <8 x i1> %962, %968
  %970 = xor <8 x i1> %968, splat (i1 true)
  %971 = and <8 x i1> %962, %970
  %972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %969)
  %973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %971)
  %974 = and i1 %972, %973
  br i1 %974, label %varying.divergent800, label %varying.coherent801

schedule.37:                                      ; preds = %varying.coherent.true806, %scheduler.dispatch.route
  %975 = load <8 x i1>, ptr %current.mask, align 1
  %976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %975)
  %977 = bitcast <8 x i1> %975 to i8
  %978 = call i8 @llvm.cttz.i8(i8 %977, i1 false)
  %979 = zext i8 %978 to i32
  %980 = select i1 %976, i32 %979, i32 0
  %.state808 = load <8 x i64>, ptr %.slot55, align 64
  %981 = add <8 x i64> splat (i64 80), %.state808
  %tile_snapshot.spill.load809 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load809, 0
  %983 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load809, 1
  %984 = mul <8 x i64> %981, splat (i64 4)
  %985 = add <8 x i64> %983, %984
  %986 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %982, 0
  %987 = insertvalue { <8 x ptr>, <8 x i64> } %986, <8 x i64> %985, 1
  %988 = extractvalue { <8 x ptr>, <8 x i64> } %987, 0
  %989 = extractvalue { <8 x ptr>, <8 x i64> } %987, 1
  %990 = getelementptr i8, <8 x ptr> %988, <8 x i64> %989
  %991 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %990, <8 x i1> %975, <8 x float> zeroinitializer)
  %.state810 = load <8 x i64>, ptr %.slot55, align 64
  %992 = add <8 x i64> splat (i64 120), %.state810
  %tile_snapshot.spill.load811 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %993 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 0
  %994 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 1
  %995 = mul <8 x i64> %992, splat (i64 4)
  %996 = add <8 x i64> %994, %995
  %997 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %993, 0
  %998 = insertvalue { <8 x ptr>, <8 x i64> } %997, <8 x i64> %996, 1
  %999 = extractvalue { <8 x ptr>, <8 x i64> } %998, 0
  %1000 = extractvalue { <8 x ptr>, <8 x i64> } %998, 1
  %1001 = getelementptr i8, <8 x ptr> %999, <8 x i64> %1000
  %1002 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1001, <8 x i1> %975, <8 x float> zeroinitializer)
  %.state812 = load <8 x i64>, ptr %.slot55, align 64
  %1003 = add <8 x i64> zeroinitializer, %.state812
  %tile_snapshot.spill.load813 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load813, 0
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load813, 1
  %1006 = mul <8 x i64> %1003, splat (i64 4)
  %1007 = add <8 x i64> %1005, %1006
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1004, 0
  %1009 = insertvalue { <8 x ptr>, <8 x i64> } %1008, <8 x i64> %1007, 1
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %1009, 0
  %1011 = extractvalue { <8 x ptr>, <8 x i64> } %1009, 1
  %1012 = getelementptr i8, <8 x ptr> %1010, <8 x i64> %1011
  %1013 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1012, <8 x i1> %975, <8 x float> zeroinitializer)
  %.state814 = load <8 x i64>, ptr %.slot55, align 64
  %1014 = add <8 x i64> splat (i64 40), %.state814
  %tile_snapshot.spill.load815 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load815, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load815, 1
  %1017 = mul <8 x i64> %1014, splat (i64 4)
  %1018 = add <8 x i64> %1016, %1017
  %1019 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1015, 0
  %1020 = insertvalue { <8 x ptr>, <8 x i64> } %1019, <8 x i64> %1018, 1
  %1021 = extractvalue { <8 x ptr>, <8 x i64> } %1020, 0
  %1022 = extractvalue { <8 x ptr>, <8 x i64> } %1020, 1
  %1023 = getelementptr i8, <8 x ptr> %1021, <8 x i64> %1022
  %1024 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1023, <8 x i1> %975, <8 x float> zeroinitializer)
  %1025 = fmul <8 x float> %991, %1013
  %.state816 = load <8 x float>, ptr %.slot96, align 32
  %1026 = fadd <8 x float> %.state816, %1025
  %1027 = fmul <8 x float> %991, %1024
  %.state817 = load <8 x float>, ptr %.slot97, align 32
  %1028 = fadd <8 x float> %.state817, %1027
  %1029 = fmul <8 x float> %1002, %1013
  %.state818 = load <8 x float>, ptr %.slot98, align 32
  %1030 = fadd <8 x float> %.state818, %1029
  %1031 = fmul <8 x float> %1002, %1024
  %.state819 = load <8 x float>, ptr %.slot99, align 32
  %1032 = fadd <8 x float> %.state819, %1031
  %.state820 = load <8 x i64>, ptr %.slot55, align 64
  %1033 = add <8 x i64> %.state820, splat (i64 1)
  %1034 = load <8 x i64>, ptr %.slot55, align 64
  %1035 = select <8 x i1> %975, <8 x i64> %1033, <8 x i64> %1034
  store <8 x i64> %1035, ptr %.slot55, align 64
  %1036 = load <8 x float>, ptr %.slot96, align 32
  %1037 = select <8 x i1> %975, <8 x float> %1026, <8 x float> %1036
  store <8 x float> %1037, ptr %.slot96, align 32
  %1038 = load <8 x float>, ptr %.slot97, align 32
  %1039 = select <8 x i1> %975, <8 x float> %1028, <8 x float> %1038
  store <8 x float> %1039, ptr %.slot97, align 32
  %1040 = load <8 x float>, ptr %.slot98, align 32
  %1041 = select <8 x i1> %975, <8 x float> %1030, <8 x float> %1040
  store <8 x float> %1041, ptr %.slot98, align 32
  %1042 = load <8 x float>, ptr %.slot99, align 32
  %1043 = select <8 x i1> %975, <8 x float> %1032, <8 x float> %1042
  store <8 x float> %1043, ptr %.slot99, align 32
  store <8 x i1> %975, ptr %current.mask, align 1
  %1044 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %975)
  br i1 %1044, label %schedule.36, label %scheduler.loop

schedule.38:                                      ; preds = %varying.coherent.false807, %scheduler.dispatch.route
  %1045 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token823 = load i32, ptr %current.token, align 4
  %convergence.token.present824 = icmp ne i32 %convergence.current.token823, 0
  br i1 %convergence.token.present824, label %convergence.cascade821, label %convergence.cascade.exit822

schedule.39:                                      ; preds = %schedule.40, %convergence.target.38.ready, %scheduler.dispatch.route
  %1046 = load <8 x i1>, ptr %current.mask, align 1
  %1047 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1046)
  %1048 = bitcast <8 x i1> %1046 to i8
  %1049 = call i8 @llvm.cttz.i8(i8 %1048, i1 false)
  %1050 = zext i8 %1049 to i32
  %1051 = select i1 %1047, i32 %1050, i32 0
  %.state838 = load <8 x i64>, ptr %.slot55, align 64
  %1052 = icmp slt <8 x i64> %.state838, splat (i64 40)
  %1053 = and <8 x i1> %1046, %1052
  %1054 = xor <8 x i1> %1052, splat (i1 true)
  %1055 = and <8 x i1> %1046, %1054
  %1056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1053)
  %1057 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1055)
  %1058 = and i1 %1056, %1057
  br i1 %1058, label %varying.divergent839, label %varying.coherent840

schedule.40:                                      ; preds = %varying.coherent.true845, %scheduler.dispatch.route
  %1059 = load <8 x i1>, ptr %current.mask, align 1
  %1060 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1059)
  %1061 = bitcast <8 x i1> %1059 to i8
  %1062 = call i8 @llvm.cttz.i8(i8 %1061, i1 false)
  %1063 = zext i8 %1062 to i32
  %1064 = select i1 %1060, i32 %1063, i32 0
  %.state847 = load <8 x i64>, ptr %.slot55, align 64
  %1065 = add <8 x i64> splat (i64 80), %.state847
  %tile_snapshot.spill.load848 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1066 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load848, 0
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load848, 1
  %1068 = mul <8 x i64> %1065, splat (i64 4)
  %1069 = add <8 x i64> %1067, %1068
  %1070 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1066, 0
  %1071 = insertvalue { <8 x ptr>, <8 x i64> } %1070, <8 x i64> %1069, 1
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %1071, 0
  %1073 = extractvalue { <8 x ptr>, <8 x i64> } %1071, 1
  %1074 = getelementptr i8, <8 x ptr> %1072, <8 x i64> %1073
  %1075 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1074, <8 x i1> %1059, <8 x float> zeroinitializer)
  %.state849 = load <8 x i64>, ptr %.slot55, align 64
  %1076 = add <8 x i64> splat (i64 120), %.state849
  %tile_snapshot.spill.load850 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1077 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load850, 0
  %1078 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load850, 1
  %1079 = mul <8 x i64> %1076, splat (i64 4)
  %1080 = add <8 x i64> %1078, %1079
  %1081 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1077, 0
  %1082 = insertvalue { <8 x ptr>, <8 x i64> } %1081, <8 x i64> %1080, 1
  %1083 = extractvalue { <8 x ptr>, <8 x i64> } %1082, 0
  %1084 = extractvalue { <8 x ptr>, <8 x i64> } %1082, 1
  %1085 = getelementptr i8, <8 x ptr> %1083, <8 x i64> %1084
  %1086 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1085, <8 x i1> %1059, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load851 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1087 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load851, 0
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load851, 1
  %1089 = mul <8 x i64> %1065, splat (i64 4)
  %1090 = add <8 x i64> %1088, %1089
  %1091 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1087, 0
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } %1091, <8 x i64> %1090, 1
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %1092, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1092, 1
  %1095 = getelementptr i8, <8 x ptr> %1093, <8 x i64> %1094
  %1096 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1095, <8 x i1> %1059, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load852 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1097 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load852, 0
  %1098 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load852, 1
  %1099 = mul <8 x i64> %1076, splat (i64 4)
  %1100 = add <8 x i64> %1098, %1099
  %1101 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1097, 0
  %1102 = insertvalue { <8 x ptr>, <8 x i64> } %1101, <8 x i64> %1100, 1
  %1103 = extractvalue { <8 x ptr>, <8 x i64> } %1102, 0
  %1104 = extractvalue { <8 x ptr>, <8 x i64> } %1102, 1
  %1105 = getelementptr i8, <8 x ptr> %1103, <8 x i64> %1104
  %1106 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1105, <8 x i1> %1059, <8 x float> zeroinitializer)
  %1107 = fmul <8 x float> %1075, %1096
  %.state853 = load <8 x float>, ptr %.slot101, align 32
  %1108 = fadd <8 x float> %.state853, %1107
  %1109 = fmul <8 x float> %1075, %1106
  %.state854 = load <8 x float>, ptr %.slot102, align 32
  %1110 = fadd <8 x float> %.state854, %1109
  %1111 = fmul <8 x float> %1086, %1096
  %.state855 = load <8 x float>, ptr %.slot103, align 32
  %1112 = fadd <8 x float> %.state855, %1111
  %1113 = fmul <8 x float> %1086, %1106
  %.state856 = load <8 x float>, ptr %.slot104, align 32
  %1114 = fadd <8 x float> %.state856, %1113
  %.state857 = load <8 x i64>, ptr %.slot55, align 64
  %1115 = add <8 x i64> %.state857, splat (i64 1)
  %1116 = load <8 x i64>, ptr %.slot55, align 64
  %1117 = select <8 x i1> %1059, <8 x i64> %1115, <8 x i64> %1116
  store <8 x i64> %1117, ptr %.slot55, align 64
  %1118 = load <8 x float>, ptr %.slot101, align 32
  %1119 = select <8 x i1> %1059, <8 x float> %1108, <8 x float> %1118
  store <8 x float> %1119, ptr %.slot101, align 32
  %1120 = load <8 x float>, ptr %.slot102, align 32
  %1121 = select <8 x i1> %1059, <8 x float> %1110, <8 x float> %1120
  store <8 x float> %1121, ptr %.slot102, align 32
  %1122 = load <8 x float>, ptr %.slot103, align 32
  %1123 = select <8 x i1> %1059, <8 x float> %1112, <8 x float> %1122
  store <8 x float> %1123, ptr %.slot103, align 32
  %1124 = load <8 x float>, ptr %.slot104, align 32
  %1125 = select <8 x i1> %1059, <8 x float> %1114, <8 x float> %1124
  store <8 x float> %1125, ptr %.slot104, align 32
  store <8 x i1> %1059, ptr %current.mask, align 1
  %1126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1059)
  br i1 %1126, label %schedule.39, label %scheduler.loop

schedule.41:                                      ; preds = %varying.coherent.false846, %scheduler.dispatch.route
  %1127 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token860 = load i32, ptr %current.token, align 4
  %convergence.token.present861 = icmp ne i32 %convergence.current.token860, 0
  br i1 %convergence.token.present861, label %convergence.cascade858, label %convergence.cascade.exit859

schedule.42:                                      ; preds = %schedule.43, %convergence.target.41.ready, %scheduler.dispatch.route
  %1128 = load <8 x i1>, ptr %current.mask, align 1
  %1129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1128)
  %1130 = bitcast <8 x i1> %1128 to i8
  %1131 = call i8 @llvm.cttz.i8(i8 %1130, i1 false)
  %1132 = zext i8 %1131 to i32
  %1133 = select i1 %1129, i32 %1132, i32 0
  %.state875 = load <8 x i64>, ptr %.slot55, align 64
  %1134 = icmp slt <8 x i64> %.state875, splat (i64 40)
  %1135 = and <8 x i1> %1128, %1134
  %1136 = xor <8 x i1> %1134, splat (i1 true)
  %1137 = and <8 x i1> %1128, %1136
  %1138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1135)
  %1139 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1137)
  %1140 = and i1 %1138, %1139
  br i1 %1140, label %varying.divergent876, label %varying.coherent877

schedule.43:                                      ; preds = %varying.coherent.true882, %scheduler.dispatch.route
  %1141 = load <8 x i1>, ptr %current.mask, align 1
  %1142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1141)
  %1143 = bitcast <8 x i1> %1141 to i8
  %1144 = call i8 @llvm.cttz.i8(i8 %1143, i1 false)
  %1145 = zext i8 %1144 to i32
  %1146 = select i1 %1142, i32 %1145, i32 0
  %.state884 = load <8 x i64>, ptr %.slot55, align 64
  %1147 = add <8 x i64> splat (i64 80), %.state884
  %tile_snapshot.spill.load885 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load885, 0
  %1149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load885, 1
  %1150 = mul <8 x i64> %1147, splat (i64 4)
  %1151 = add <8 x i64> %1149, %1150
  %1152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1148, 0
  %1153 = insertvalue { <8 x ptr>, <8 x i64> } %1152, <8 x i64> %1151, 1
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %1153, 0
  %1155 = extractvalue { <8 x ptr>, <8 x i64> } %1153, 1
  %1156 = getelementptr i8, <8 x ptr> %1154, <8 x i64> %1155
  %1157 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1156, <8 x i1> %1141, <8 x float> zeroinitializer)
  %.state886 = load <8 x i64>, ptr %.slot55, align 64
  %1158 = add <8 x i64> splat (i64 120), %.state886
  %tile_snapshot.spill.load887 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load887, 0
  %1160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load887, 1
  %1161 = mul <8 x i64> %1158, splat (i64 4)
  %1162 = add <8 x i64> %1160, %1161
  %1163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1159, 0
  %1164 = insertvalue { <8 x ptr>, <8 x i64> } %1163, <8 x i64> %1162, 1
  %1165 = extractvalue { <8 x ptr>, <8 x i64> } %1164, 0
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %1164, 1
  %1167 = getelementptr i8, <8 x ptr> %1165, <8 x i64> %1166
  %1168 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1167, <8 x i1> %1141, <8 x float> zeroinitializer)
  %.state888 = load <8 x i64>, ptr %.slot55, align 64
  %1169 = add <8 x i64> splat (i64 160), %.state888
  %tile_snapshot.spill.load889 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1170 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load889, 0
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load889, 1
  %1172 = mul <8 x i64> %1169, splat (i64 4)
  %1173 = add <8 x i64> %1171, %1172
  %1174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1170, 0
  %1175 = insertvalue { <8 x ptr>, <8 x i64> } %1174, <8 x i64> %1173, 1
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %1175, 0
  %1177 = extractvalue { <8 x ptr>, <8 x i64> } %1175, 1
  %1178 = getelementptr i8, <8 x ptr> %1176, <8 x i64> %1177
  %1179 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1178, <8 x i1> %1141, <8 x float> zeroinitializer)
  %.state890 = load <8 x i64>, ptr %.slot55, align 64
  %1180 = add <8 x i64> splat (i64 200), %.state890
  %tile_snapshot.spill.load891 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1181 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load891, 0
  %1182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load891, 1
  %1183 = mul <8 x i64> %1180, splat (i64 4)
  %1184 = add <8 x i64> %1182, %1183
  %1185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1181, 0
  %1186 = insertvalue { <8 x ptr>, <8 x i64> } %1185, <8 x i64> %1184, 1
  %1187 = extractvalue { <8 x ptr>, <8 x i64> } %1186, 0
  %1188 = extractvalue { <8 x ptr>, <8 x i64> } %1186, 1
  %1189 = getelementptr i8, <8 x ptr> %1187, <8 x i64> %1188
  %1190 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1189, <8 x i1> %1141, <8 x float> zeroinitializer)
  %1191 = fmul <8 x float> %1157, %1179
  %.state892 = load <8 x float>, ptr %.slot106, align 32
  %1192 = fadd <8 x float> %.state892, %1191
  %1193 = fmul <8 x float> %1157, %1190
  %.state893 = load <8 x float>, ptr %.slot107, align 32
  %1194 = fadd <8 x float> %.state893, %1193
  %1195 = fmul <8 x float> %1168, %1179
  %.state894 = load <8 x float>, ptr %.slot108, align 32
  %1196 = fadd <8 x float> %.state894, %1195
  %1197 = fmul <8 x float> %1168, %1190
  %.state895 = load <8 x float>, ptr %.slot109, align 32
  %1198 = fadd <8 x float> %.state895, %1197
  %.state896 = load <8 x i64>, ptr %.slot55, align 64
  %1199 = add <8 x i64> %.state896, splat (i64 1)
  %1200 = load <8 x i64>, ptr %.slot55, align 64
  %1201 = select <8 x i1> %1141, <8 x i64> %1199, <8 x i64> %1200
  store <8 x i64> %1201, ptr %.slot55, align 64
  %1202 = load <8 x float>, ptr %.slot106, align 32
  %1203 = select <8 x i1> %1141, <8 x float> %1192, <8 x float> %1202
  store <8 x float> %1203, ptr %.slot106, align 32
  %1204 = load <8 x float>, ptr %.slot107, align 32
  %1205 = select <8 x i1> %1141, <8 x float> %1194, <8 x float> %1204
  store <8 x float> %1205, ptr %.slot107, align 32
  %1206 = load <8 x float>, ptr %.slot108, align 32
  %1207 = select <8 x i1> %1141, <8 x float> %1196, <8 x float> %1206
  store <8 x float> %1207, ptr %.slot108, align 32
  %1208 = load <8 x float>, ptr %.slot109, align 32
  %1209 = select <8 x i1> %1141, <8 x float> %1198, <8 x float> %1208
  store <8 x float> %1209, ptr %.slot109, align 32
  store <8 x i1> %1141, ptr %current.mask, align 1
  %1210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1141)
  br i1 %1210, label %schedule.42, label %scheduler.loop

schedule.44:                                      ; preds = %varying.coherent.false883, %scheduler.dispatch.route
  %1211 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token899 = load i32, ptr %current.token, align 4
  %convergence.token.present900 = icmp ne i32 %convergence.current.token899, 0
  br i1 %convergence.token.present900, label %convergence.cascade897, label %convergence.cascade.exit898

schedule.45:                                      ; preds = %schedule.46, %convergence.target.44.ready, %scheduler.dispatch.route
  %1212 = load <8 x i1>, ptr %current.mask, align 1
  %1213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1212)
  %1214 = bitcast <8 x i1> %1212 to i8
  %1215 = call i8 @llvm.cttz.i8(i8 %1214, i1 false)
  %1216 = zext i8 %1215 to i32
  %1217 = select i1 %1213, i32 %1216, i32 0
  %.state914 = load <8 x i64>, ptr %.slot55, align 64
  %1218 = icmp slt <8 x i64> %.state914, splat (i64 40)
  %1219 = and <8 x i1> %1212, %1218
  %1220 = xor <8 x i1> %1218, splat (i1 true)
  %1221 = and <8 x i1> %1212, %1220
  %1222 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1219)
  %1223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1221)
  %1224 = and i1 %1222, %1223
  br i1 %1224, label %varying.divergent915, label %varying.coherent916

schedule.46:                                      ; preds = %varying.coherent.true921, %scheduler.dispatch.route
  %1225 = load <8 x i1>, ptr %current.mask, align 1
  %1226 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1225)
  %1227 = bitcast <8 x i1> %1225 to i8
  %1228 = call i8 @llvm.cttz.i8(i8 %1227, i1 false)
  %1229 = zext i8 %1228 to i32
  %1230 = select i1 %1226, i32 %1229, i32 0
  %.state923 = load <8 x i64>, ptr %.slot55, align 64
  %1231 = add <8 x i64> splat (i64 80), %.state923
  %tile_snapshot.spill.load924 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load924, 0
  %1233 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load924, 1
  %1234 = mul <8 x i64> %1231, splat (i64 4)
  %1235 = add <8 x i64> %1233, %1234
  %1236 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1232, 0
  %1237 = insertvalue { <8 x ptr>, <8 x i64> } %1236, <8 x i64> %1235, 1
  %1238 = extractvalue { <8 x ptr>, <8 x i64> } %1237, 0
  %1239 = extractvalue { <8 x ptr>, <8 x i64> } %1237, 1
  %1240 = getelementptr i8, <8 x ptr> %1238, <8 x i64> %1239
  %1241 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1240, <8 x i1> %1225, <8 x float> zeroinitializer)
  %.state925 = load <8 x i64>, ptr %.slot55, align 64
  %1242 = add <8 x i64> splat (i64 120), %.state925
  %tile_snapshot.spill.load926 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1243 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load926, 0
  %1244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load926, 1
  %1245 = mul <8 x i64> %1242, splat (i64 4)
  %1246 = add <8 x i64> %1244, %1245
  %1247 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1243, 0
  %1248 = insertvalue { <8 x ptr>, <8 x i64> } %1247, <8 x i64> %1246, 1
  %1249 = extractvalue { <8 x ptr>, <8 x i64> } %1248, 0
  %1250 = extractvalue { <8 x ptr>, <8 x i64> } %1248, 1
  %1251 = getelementptr i8, <8 x ptr> %1249, <8 x i64> %1250
  %1252 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1251, <8 x i1> %1225, <8 x float> zeroinitializer)
  %.state927 = load <8 x i64>, ptr %.slot55, align 64
  %1253 = add <8 x i64> splat (i64 240), %.state927
  %tile_snapshot.spill.load928 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1254 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load928, 0
  %1255 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load928, 1
  %1256 = mul <8 x i64> %1253, splat (i64 4)
  %1257 = add <8 x i64> %1255, %1256
  %1258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1254, 0
  %1259 = insertvalue { <8 x ptr>, <8 x i64> } %1258, <8 x i64> %1257, 1
  %1260 = extractvalue { <8 x ptr>, <8 x i64> } %1259, 0
  %1261 = extractvalue { <8 x ptr>, <8 x i64> } %1259, 1
  %1262 = getelementptr i8, <8 x ptr> %1260, <8 x i64> %1261
  %1263 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1262, <8 x i1> %1225, <8 x float> zeroinitializer)
  %.state929 = load <8 x i64>, ptr %.slot55, align 64
  %1264 = add <8 x i64> splat (i64 280), %.state929
  %tile_snapshot.spill.load930 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load930, 0
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load930, 1
  %1267 = mul <8 x i64> %1264, splat (i64 4)
  %1268 = add <8 x i64> %1266, %1267
  %1269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1265, 0
  %1270 = insertvalue { <8 x ptr>, <8 x i64> } %1269, <8 x i64> %1268, 1
  %1271 = extractvalue { <8 x ptr>, <8 x i64> } %1270, 0
  %1272 = extractvalue { <8 x ptr>, <8 x i64> } %1270, 1
  %1273 = getelementptr i8, <8 x ptr> %1271, <8 x i64> %1272
  %1274 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1273, <8 x i1> %1225, <8 x float> zeroinitializer)
  %1275 = fmul <8 x float> %1241, %1263
  %.state931 = load <8 x float>, ptr %.slot111, align 32
  %1276 = fadd <8 x float> %.state931, %1275
  %1277 = fmul <8 x float> %1241, %1274
  %.state932 = load <8 x float>, ptr %.slot112, align 32
  %1278 = fadd <8 x float> %.state932, %1277
  %1279 = fmul <8 x float> %1252, %1263
  %.state933 = load <8 x float>, ptr %.slot113, align 32
  %1280 = fadd <8 x float> %.state933, %1279
  %1281 = fmul <8 x float> %1252, %1274
  %.state934 = load <8 x float>, ptr %.slot114, align 32
  %1282 = fadd <8 x float> %.state934, %1281
  %.state935 = load <8 x i64>, ptr %.slot55, align 64
  %1283 = add <8 x i64> %.state935, splat (i64 1)
  %1284 = load <8 x i64>, ptr %.slot55, align 64
  %1285 = select <8 x i1> %1225, <8 x i64> %1283, <8 x i64> %1284
  store <8 x i64> %1285, ptr %.slot55, align 64
  %1286 = load <8 x float>, ptr %.slot111, align 32
  %1287 = select <8 x i1> %1225, <8 x float> %1276, <8 x float> %1286
  store <8 x float> %1287, ptr %.slot111, align 32
  %1288 = load <8 x float>, ptr %.slot112, align 32
  %1289 = select <8 x i1> %1225, <8 x float> %1278, <8 x float> %1288
  store <8 x float> %1289, ptr %.slot112, align 32
  %1290 = load <8 x float>, ptr %.slot113, align 32
  %1291 = select <8 x i1> %1225, <8 x float> %1280, <8 x float> %1290
  store <8 x float> %1291, ptr %.slot113, align 32
  %1292 = load <8 x float>, ptr %.slot114, align 32
  %1293 = select <8 x i1> %1225, <8 x float> %1282, <8 x float> %1292
  store <8 x float> %1293, ptr %.slot114, align 32
  store <8 x i1> %1225, ptr %current.mask, align 1
  %1294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1225)
  br i1 %1294, label %schedule.45, label %scheduler.loop

schedule.47:                                      ; preds = %varying.coherent.false922, %scheduler.dispatch.route
  %1295 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token938 = load i32, ptr %current.token, align 4
  %convergence.token.present939 = icmp ne i32 %convergence.current.token938, 0
  br i1 %convergence.token.present939, label %convergence.cascade936, label %convergence.cascade.exit937

schedule.48:                                      ; preds = %schedule.49, %convergence.target.47.ready, %scheduler.dispatch.route
  %1296 = load <8 x i1>, ptr %current.mask, align 1
  %1297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1296)
  %1298 = bitcast <8 x i1> %1296 to i8
  %1299 = call i8 @llvm.cttz.i8(i8 %1298, i1 false)
  %1300 = zext i8 %1299 to i32
  %1301 = select i1 %1297, i32 %1300, i32 0
  %.state953 = load <8 x i64>, ptr %.slot55, align 64
  %1302 = icmp slt <8 x i64> %.state953, splat (i64 40)
  %1303 = and <8 x i1> %1296, %1302
  %1304 = xor <8 x i1> %1302, splat (i1 true)
  %1305 = and <8 x i1> %1296, %1304
  %1306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1303)
  %1307 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1305)
  %1308 = and i1 %1306, %1307
  br i1 %1308, label %varying.divergent954, label %varying.coherent955

schedule.49:                                      ; preds = %varying.coherent.true960, %scheduler.dispatch.route
  %1309 = load <8 x i1>, ptr %current.mask, align 1
  %1310 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1309)
  %1311 = bitcast <8 x i1> %1309 to i8
  %1312 = call i8 @llvm.cttz.i8(i8 %1311, i1 false)
  %1313 = zext i8 %1312 to i32
  %1314 = select i1 %1310, i32 %1313, i32 0
  %.state962 = load <8 x i64>, ptr %.slot55, align 64
  %1315 = add <8 x i64> splat (i64 80), %.state962
  %tile_snapshot.spill.load963 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1316 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load963, 0
  %1317 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load963, 1
  %1318 = mul <8 x i64> %1315, splat (i64 4)
  %1319 = add <8 x i64> %1317, %1318
  %1320 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1316, 0
  %1321 = insertvalue { <8 x ptr>, <8 x i64> } %1320, <8 x i64> %1319, 1
  %1322 = extractvalue { <8 x ptr>, <8 x i64> } %1321, 0
  %1323 = extractvalue { <8 x ptr>, <8 x i64> } %1321, 1
  %1324 = getelementptr i8, <8 x ptr> %1322, <8 x i64> %1323
  %1325 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1324, <8 x i1> %1309, <8 x float> zeroinitializer)
  %.state964 = load <8 x i64>, ptr %.slot55, align 64
  %1326 = add <8 x i64> splat (i64 120), %.state964
  %tile_snapshot.spill.load965 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1327 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load965, 0
  %1328 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load965, 1
  %1329 = mul <8 x i64> %1326, splat (i64 4)
  %1330 = add <8 x i64> %1328, %1329
  %1331 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1327, 0
  %1332 = insertvalue { <8 x ptr>, <8 x i64> } %1331, <8 x i64> %1330, 1
  %1333 = extractvalue { <8 x ptr>, <8 x i64> } %1332, 0
  %1334 = extractvalue { <8 x ptr>, <8 x i64> } %1332, 1
  %1335 = getelementptr i8, <8 x ptr> %1333, <8 x i64> %1334
  %1336 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1335, <8 x i1> %1309, <8 x float> zeroinitializer)
  %.state966 = load <8 x i64>, ptr %.slot55, align 64
  %1337 = add <8 x i64> splat (i64 320), %.state966
  %tile_snapshot.spill.load967 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load967, 0
  %1339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load967, 1
  %1340 = mul <8 x i64> %1337, splat (i64 4)
  %1341 = add <8 x i64> %1339, %1340
  %1342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1338, 0
  %1343 = insertvalue { <8 x ptr>, <8 x i64> } %1342, <8 x i64> %1341, 1
  %1344 = extractvalue { <8 x ptr>, <8 x i64> } %1343, 0
  %1345 = extractvalue { <8 x ptr>, <8 x i64> } %1343, 1
  %1346 = getelementptr i8, <8 x ptr> %1344, <8 x i64> %1345
  %1347 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1346, <8 x i1> %1309, <8 x float> zeroinitializer)
  %.state968 = load <8 x i64>, ptr %.slot55, align 64
  %1348 = add <8 x i64> splat (i64 360), %.state968
  %tile_snapshot.spill.load969 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load969, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load969, 1
  %1351 = mul <8 x i64> %1348, splat (i64 4)
  %1352 = add <8 x i64> %1350, %1351
  %1353 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1349, 0
  %1354 = insertvalue { <8 x ptr>, <8 x i64> } %1353, <8 x i64> %1352, 1
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %1354, 0
  %1356 = extractvalue { <8 x ptr>, <8 x i64> } %1354, 1
  %1357 = getelementptr i8, <8 x ptr> %1355, <8 x i64> %1356
  %1358 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1357, <8 x i1> %1309, <8 x float> zeroinitializer)
  %1359 = fmul <8 x float> %1325, %1347
  %.state970 = load <8 x float>, ptr %.slot116, align 32
  %1360 = fadd <8 x float> %.state970, %1359
  %1361 = fmul <8 x float> %1325, %1358
  %.state971 = load <8 x float>, ptr %.slot117, align 32
  %1362 = fadd <8 x float> %.state971, %1361
  %1363 = fmul <8 x float> %1336, %1347
  %.state972 = load <8 x float>, ptr %.slot118, align 32
  %1364 = fadd <8 x float> %.state972, %1363
  %1365 = fmul <8 x float> %1336, %1358
  %.state973 = load <8 x float>, ptr %.slot119, align 32
  %1366 = fadd <8 x float> %.state973, %1365
  %.state974 = load <8 x i64>, ptr %.slot55, align 64
  %1367 = add <8 x i64> %.state974, splat (i64 1)
  %1368 = load <8 x i64>, ptr %.slot55, align 64
  %1369 = select <8 x i1> %1309, <8 x i64> %1367, <8 x i64> %1368
  store <8 x i64> %1369, ptr %.slot55, align 64
  %1370 = load <8 x float>, ptr %.slot116, align 32
  %1371 = select <8 x i1> %1309, <8 x float> %1360, <8 x float> %1370
  store <8 x float> %1371, ptr %.slot116, align 32
  %1372 = load <8 x float>, ptr %.slot117, align 32
  %1373 = select <8 x i1> %1309, <8 x float> %1362, <8 x float> %1372
  store <8 x float> %1373, ptr %.slot117, align 32
  %1374 = load <8 x float>, ptr %.slot118, align 32
  %1375 = select <8 x i1> %1309, <8 x float> %1364, <8 x float> %1374
  store <8 x float> %1375, ptr %.slot118, align 32
  %1376 = load <8 x float>, ptr %.slot119, align 32
  %1377 = select <8 x i1> %1309, <8 x float> %1366, <8 x float> %1376
  store <8 x float> %1377, ptr %.slot119, align 32
  store <8 x i1> %1309, ptr %current.mask, align 1
  %1378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1309)
  br i1 %1378, label %schedule.48, label %scheduler.loop

schedule.50:                                      ; preds = %varying.coherent.false961, %scheduler.dispatch.route
  %1379 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token977 = load i32, ptr %current.token, align 4
  %convergence.token.present978 = icmp ne i32 %convergence.current.token977, 0
  br i1 %convergence.token.present978, label %convergence.cascade975, label %convergence.cascade.exit976

schedule.51:                                      ; preds = %schedule.52, %convergence.target.50.ready, %scheduler.dispatch.route
  %1380 = load <8 x i1>, ptr %current.mask, align 1
  %1381 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1380)
  %1382 = bitcast <8 x i1> %1380 to i8
  %1383 = call i8 @llvm.cttz.i8(i8 %1382, i1 false)
  %1384 = zext i8 %1383 to i32
  %1385 = select i1 %1381, i32 %1384, i32 0
  %.state992 = load <8 x i64>, ptr %.slot55, align 64
  %1386 = icmp slt <8 x i64> %.state992, splat (i64 40)
  %1387 = and <8 x i1> %1380, %1386
  %1388 = xor <8 x i1> %1386, splat (i1 true)
  %1389 = and <8 x i1> %1380, %1388
  %1390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1387)
  %1391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1389)
  %1392 = and i1 %1390, %1391
  br i1 %1392, label %varying.divergent993, label %varying.coherent994

schedule.52:                                      ; preds = %varying.coherent.true999, %scheduler.dispatch.route
  %1393 = load <8 x i1>, ptr %current.mask, align 1
  %1394 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1393)
  %1395 = bitcast <8 x i1> %1393 to i8
  %1396 = call i8 @llvm.cttz.i8(i8 %1395, i1 false)
  %1397 = zext i8 %1396 to i32
  %1398 = select i1 %1394, i32 %1397, i32 0
  %.state1001 = load <8 x i64>, ptr %.slot55, align 64
  %1399 = add <8 x i64> splat (i64 80), %.state1001
  %tile_snapshot.spill.load1002 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1400 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1002, 0
  %1401 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1002, 1
  %1402 = mul <8 x i64> %1399, splat (i64 4)
  %1403 = add <8 x i64> %1401, %1402
  %1404 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1400, 0
  %1405 = insertvalue { <8 x ptr>, <8 x i64> } %1404, <8 x i64> %1403, 1
  %1406 = extractvalue { <8 x ptr>, <8 x i64> } %1405, 0
  %1407 = extractvalue { <8 x ptr>, <8 x i64> } %1405, 1
  %1408 = getelementptr i8, <8 x ptr> %1406, <8 x i64> %1407
  %1409 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1408, <8 x i1> %1393, <8 x float> zeroinitializer)
  %.state1003 = load <8 x i64>, ptr %.slot55, align 64
  %1410 = add <8 x i64> splat (i64 120), %.state1003
  %tile_snapshot.spill.load1004 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1411 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1004, 0
  %1412 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1004, 1
  %1413 = mul <8 x i64> %1410, splat (i64 4)
  %1414 = add <8 x i64> %1412, %1413
  %1415 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1411, 0
  %1416 = insertvalue { <8 x ptr>, <8 x i64> } %1415, <8 x i64> %1414, 1
  %1417 = extractvalue { <8 x ptr>, <8 x i64> } %1416, 0
  %1418 = extractvalue { <8 x ptr>, <8 x i64> } %1416, 1
  %1419 = getelementptr i8, <8 x ptr> %1417, <8 x i64> %1418
  %1420 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1419, <8 x i1> %1393, <8 x float> zeroinitializer)
  %.state1005 = load <8 x i64>, ptr %.slot55, align 64
  %1421 = add <8 x i64> splat (i64 400), %.state1005
  %tile_snapshot.spill.load1006 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 0
  %1423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 1
  %1424 = mul <8 x i64> %1421, splat (i64 4)
  %1425 = add <8 x i64> %1423, %1424
  %1426 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1422, 0
  %1427 = insertvalue { <8 x ptr>, <8 x i64> } %1426, <8 x i64> %1425, 1
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %1427, 0
  %1429 = extractvalue { <8 x ptr>, <8 x i64> } %1427, 1
  %1430 = getelementptr i8, <8 x ptr> %1428, <8 x i64> %1429
  %1431 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1430, <8 x i1> %1393, <8 x float> zeroinitializer)
  %.state1007 = load <8 x i64>, ptr %.slot55, align 64
  %1432 = add <8 x i64> splat (i64 440), %.state1007
  %tile_snapshot.spill.load1008 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1433 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1008, 0
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1008, 1
  %1435 = mul <8 x i64> %1432, splat (i64 4)
  %1436 = add <8 x i64> %1434, %1435
  %1437 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1433, 0
  %1438 = insertvalue { <8 x ptr>, <8 x i64> } %1437, <8 x i64> %1436, 1
  %1439 = extractvalue { <8 x ptr>, <8 x i64> } %1438, 0
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %1438, 1
  %1441 = getelementptr i8, <8 x ptr> %1439, <8 x i64> %1440
  %1442 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1441, <8 x i1> %1393, <8 x float> zeroinitializer)
  %1443 = fmul <8 x float> %1409, %1431
  %.state1009 = load <8 x float>, ptr %.slot121, align 32
  %1444 = fadd <8 x float> %.state1009, %1443
  %1445 = fmul <8 x float> %1409, %1442
  %.state1010 = load <8 x float>, ptr %.slot122, align 32
  %1446 = fadd <8 x float> %.state1010, %1445
  %1447 = fmul <8 x float> %1420, %1431
  %.state1011 = load <8 x float>, ptr %.slot123, align 32
  %1448 = fadd <8 x float> %.state1011, %1447
  %1449 = fmul <8 x float> %1420, %1442
  %.state1012 = load <8 x float>, ptr %.slot124, align 32
  %1450 = fadd <8 x float> %.state1012, %1449
  %.state1013 = load <8 x i64>, ptr %.slot55, align 64
  %1451 = add <8 x i64> %.state1013, splat (i64 1)
  %1452 = load <8 x i64>, ptr %.slot55, align 64
  %1453 = select <8 x i1> %1393, <8 x i64> %1451, <8 x i64> %1452
  store <8 x i64> %1453, ptr %.slot55, align 64
  %1454 = load <8 x float>, ptr %.slot121, align 32
  %1455 = select <8 x i1> %1393, <8 x float> %1444, <8 x float> %1454
  store <8 x float> %1455, ptr %.slot121, align 32
  %1456 = load <8 x float>, ptr %.slot122, align 32
  %1457 = select <8 x i1> %1393, <8 x float> %1446, <8 x float> %1456
  store <8 x float> %1457, ptr %.slot122, align 32
  %1458 = load <8 x float>, ptr %.slot123, align 32
  %1459 = select <8 x i1> %1393, <8 x float> %1448, <8 x float> %1458
  store <8 x float> %1459, ptr %.slot123, align 32
  %1460 = load <8 x float>, ptr %.slot124, align 32
  %1461 = select <8 x i1> %1393, <8 x float> %1450, <8 x float> %1460
  store <8 x float> %1461, ptr %.slot124, align 32
  store <8 x i1> %1393, ptr %current.mask, align 1
  %1462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1393)
  br i1 %1462, label %schedule.51, label %scheduler.loop

schedule.53:                                      ; preds = %varying.coherent.false1000, %scheduler.dispatch.route
  %1463 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1016 = load i32, ptr %current.token, align 4
  %convergence.token.present1017 = icmp ne i32 %convergence.current.token1016, 0
  br i1 %convergence.token.present1017, label %convergence.cascade1014, label %convergence.cascade.exit1015

schedule.54:                                      ; preds = %schedule.55, %convergence.target.53.ready, %scheduler.dispatch.route
  %1464 = load <8 x i1>, ptr %current.mask, align 1
  %1465 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1464)
  %1466 = bitcast <8 x i1> %1464 to i8
  %1467 = call i8 @llvm.cttz.i8(i8 %1466, i1 false)
  %1468 = zext i8 %1467 to i32
  %1469 = select i1 %1465, i32 %1468, i32 0
  %.state1031 = load <8 x i64>, ptr %.slot55, align 64
  %1470 = icmp slt <8 x i64> %.state1031, splat (i64 40)
  %1471 = and <8 x i1> %1464, %1470
  %1472 = xor <8 x i1> %1470, splat (i1 true)
  %1473 = and <8 x i1> %1464, %1472
  %1474 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1471)
  %1475 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1473)
  %1476 = and i1 %1474, %1475
  br i1 %1476, label %varying.divergent1032, label %varying.coherent1033

schedule.55:                                      ; preds = %varying.coherent.true1038, %scheduler.dispatch.route
  %1477 = load <8 x i1>, ptr %current.mask, align 1
  %1478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1477)
  %1479 = bitcast <8 x i1> %1477 to i8
  %1480 = call i8 @llvm.cttz.i8(i8 %1479, i1 false)
  %1481 = zext i8 %1480 to i32
  %1482 = select i1 %1478, i32 %1481, i32 0
  %.state1040 = load <8 x i64>, ptr %.slot55, align 64
  %1483 = add <8 x i64> splat (i64 80), %.state1040
  %tile_snapshot.spill.load1041 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1484 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1041, 0
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1041, 1
  %1486 = mul <8 x i64> %1483, splat (i64 4)
  %1487 = add <8 x i64> %1485, %1486
  %1488 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1484, 0
  %1489 = insertvalue { <8 x ptr>, <8 x i64> } %1488, <8 x i64> %1487, 1
  %1490 = extractvalue { <8 x ptr>, <8 x i64> } %1489, 0
  %1491 = extractvalue { <8 x ptr>, <8 x i64> } %1489, 1
  %1492 = getelementptr i8, <8 x ptr> %1490, <8 x i64> %1491
  %1493 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1492, <8 x i1> %1477, <8 x float> zeroinitializer)
  %.state1042 = load <8 x i64>, ptr %.slot55, align 64
  %1494 = add <8 x i64> splat (i64 120), %.state1042
  %tile_snapshot.spill.load1043 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1043, 0
  %1496 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1043, 1
  %1497 = mul <8 x i64> %1494, splat (i64 4)
  %1498 = add <8 x i64> %1496, %1497
  %1499 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1495, 0
  %1500 = insertvalue { <8 x ptr>, <8 x i64> } %1499, <8 x i64> %1498, 1
  %1501 = extractvalue { <8 x ptr>, <8 x i64> } %1500, 0
  %1502 = extractvalue { <8 x ptr>, <8 x i64> } %1500, 1
  %1503 = getelementptr i8, <8 x ptr> %1501, <8 x i64> %1502
  %1504 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1503, <8 x i1> %1477, <8 x float> zeroinitializer)
  %.state1044 = load <8 x i64>, ptr %.slot55, align 64
  %1505 = add <8 x i64> splat (i64 480), %.state1044
  %tile_snapshot.spill.load1045 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1045, 0
  %1507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1045, 1
  %1508 = mul <8 x i64> %1505, splat (i64 4)
  %1509 = add <8 x i64> %1507, %1508
  %1510 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1506, 0
  %1511 = insertvalue { <8 x ptr>, <8 x i64> } %1510, <8 x i64> %1509, 1
  %1512 = extractvalue { <8 x ptr>, <8 x i64> } %1511, 0
  %1513 = extractvalue { <8 x ptr>, <8 x i64> } %1511, 1
  %1514 = getelementptr i8, <8 x ptr> %1512, <8 x i64> %1513
  %1515 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1514, <8 x i1> %1477, <8 x float> zeroinitializer)
  %.state1046 = load <8 x i64>, ptr %.slot55, align 64
  %1516 = add <8 x i64> splat (i64 520), %.state1046
  %tile_snapshot.spill.load1047 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1047, 0
  %1518 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1047, 1
  %1519 = mul <8 x i64> %1516, splat (i64 4)
  %1520 = add <8 x i64> %1518, %1519
  %1521 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1517, 0
  %1522 = insertvalue { <8 x ptr>, <8 x i64> } %1521, <8 x i64> %1520, 1
  %1523 = extractvalue { <8 x ptr>, <8 x i64> } %1522, 0
  %1524 = extractvalue { <8 x ptr>, <8 x i64> } %1522, 1
  %1525 = getelementptr i8, <8 x ptr> %1523, <8 x i64> %1524
  %1526 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1525, <8 x i1> %1477, <8 x float> zeroinitializer)
  %1527 = fmul <8 x float> %1493, %1515
  %.state1048 = load <8 x float>, ptr %.slot126, align 32
  %1528 = fadd <8 x float> %.state1048, %1527
  %1529 = fmul <8 x float> %1493, %1526
  %.state1049 = load <8 x float>, ptr %.slot127, align 32
  %1530 = fadd <8 x float> %.state1049, %1529
  %1531 = fmul <8 x float> %1504, %1515
  %.state1050 = load <8 x float>, ptr %.slot128, align 32
  %1532 = fadd <8 x float> %.state1050, %1531
  %1533 = fmul <8 x float> %1504, %1526
  %.state1051 = load <8 x float>, ptr %.slot129, align 32
  %1534 = fadd <8 x float> %.state1051, %1533
  %.state1052 = load <8 x i64>, ptr %.slot55, align 64
  %1535 = add <8 x i64> %.state1052, splat (i64 1)
  %1536 = load <8 x i64>, ptr %.slot55, align 64
  %1537 = select <8 x i1> %1477, <8 x i64> %1535, <8 x i64> %1536
  store <8 x i64> %1537, ptr %.slot55, align 64
  %1538 = load <8 x float>, ptr %.slot126, align 32
  %1539 = select <8 x i1> %1477, <8 x float> %1528, <8 x float> %1538
  store <8 x float> %1539, ptr %.slot126, align 32
  %1540 = load <8 x float>, ptr %.slot127, align 32
  %1541 = select <8 x i1> %1477, <8 x float> %1530, <8 x float> %1540
  store <8 x float> %1541, ptr %.slot127, align 32
  %1542 = load <8 x float>, ptr %.slot128, align 32
  %1543 = select <8 x i1> %1477, <8 x float> %1532, <8 x float> %1542
  store <8 x float> %1543, ptr %.slot128, align 32
  %1544 = load <8 x float>, ptr %.slot129, align 32
  %1545 = select <8 x i1> %1477, <8 x float> %1534, <8 x float> %1544
  store <8 x float> %1545, ptr %.slot129, align 32
  store <8 x i1> %1477, ptr %current.mask, align 1
  %1546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1477)
  br i1 %1546, label %schedule.54, label %scheduler.loop

schedule.56:                                      ; preds = %varying.coherent.false1039, %scheduler.dispatch.route
  %1547 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1055 = load i32, ptr %current.token, align 4
  %convergence.token.present1056 = icmp ne i32 %convergence.current.token1055, 0
  br i1 %convergence.token.present1056, label %convergence.cascade1053, label %convergence.cascade.exit1054

schedule.57:                                      ; preds = %schedule.58, %convergence.target.56.ready, %scheduler.dispatch.route
  %1548 = load <8 x i1>, ptr %current.mask, align 1
  %1549 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1548)
  %1550 = bitcast <8 x i1> %1548 to i8
  %1551 = call i8 @llvm.cttz.i8(i8 %1550, i1 false)
  %1552 = zext i8 %1551 to i32
  %1553 = select i1 %1549, i32 %1552, i32 0
  %.state1070 = load <8 x i64>, ptr %.slot55, align 64
  %1554 = icmp slt <8 x i64> %.state1070, splat (i64 40)
  %1555 = and <8 x i1> %1548, %1554
  %1556 = xor <8 x i1> %1554, splat (i1 true)
  %1557 = and <8 x i1> %1548, %1556
  %1558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1555)
  %1559 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1557)
  %1560 = and i1 %1558, %1559
  br i1 %1560, label %varying.divergent1071, label %varying.coherent1072

schedule.58:                                      ; preds = %varying.coherent.true1077, %scheduler.dispatch.route
  %1561 = load <8 x i1>, ptr %current.mask, align 1
  %1562 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1561)
  %1563 = bitcast <8 x i1> %1561 to i8
  %1564 = call i8 @llvm.cttz.i8(i8 %1563, i1 false)
  %1565 = zext i8 %1564 to i32
  %1566 = select i1 %1562, i32 %1565, i32 0
  %.state1079 = load <8 x i64>, ptr %.slot55, align 64
  %1567 = add <8 x i64> splat (i64 80), %.state1079
  %tile_snapshot.spill.load1080 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1080, 0
  %1569 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1080, 1
  %1570 = mul <8 x i64> %1567, splat (i64 4)
  %1571 = add <8 x i64> %1569, %1570
  %1572 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1568, 0
  %1573 = insertvalue { <8 x ptr>, <8 x i64> } %1572, <8 x i64> %1571, 1
  %1574 = extractvalue { <8 x ptr>, <8 x i64> } %1573, 0
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %1573, 1
  %1576 = getelementptr i8, <8 x ptr> %1574, <8 x i64> %1575
  %1577 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1576, <8 x i1> %1561, <8 x float> zeroinitializer)
  %.state1081 = load <8 x i64>, ptr %.slot55, align 64
  %1578 = add <8 x i64> splat (i64 120), %.state1081
  %tile_snapshot.spill.load1082 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1579 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1082, 0
  %1580 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1082, 1
  %1581 = mul <8 x i64> %1578, splat (i64 4)
  %1582 = add <8 x i64> %1580, %1581
  %1583 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1579, 0
  %1584 = insertvalue { <8 x ptr>, <8 x i64> } %1583, <8 x i64> %1582, 1
  %1585 = extractvalue { <8 x ptr>, <8 x i64> } %1584, 0
  %1586 = extractvalue { <8 x ptr>, <8 x i64> } %1584, 1
  %1587 = getelementptr i8, <8 x ptr> %1585, <8 x i64> %1586
  %1588 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1587, <8 x i1> %1561, <8 x float> zeroinitializer)
  %.state1083 = load <8 x i64>, ptr %.slot55, align 64
  %1589 = add <8 x i64> splat (i64 560), %.state1083
  %tile_snapshot.spill.load1084 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1084, 0
  %1591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1084, 1
  %1592 = mul <8 x i64> %1589, splat (i64 4)
  %1593 = add <8 x i64> %1591, %1592
  %1594 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1590, 0
  %1595 = insertvalue { <8 x ptr>, <8 x i64> } %1594, <8 x i64> %1593, 1
  %1596 = extractvalue { <8 x ptr>, <8 x i64> } %1595, 0
  %1597 = extractvalue { <8 x ptr>, <8 x i64> } %1595, 1
  %1598 = getelementptr i8, <8 x ptr> %1596, <8 x i64> %1597
  %1599 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1598, <8 x i1> %1561, <8 x float> zeroinitializer)
  %.state1085 = load <8 x i64>, ptr %.slot55, align 64
  %1600 = add <8 x i64> splat (i64 600), %.state1085
  %tile_snapshot.spill.load1086 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %1601 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1086, 0
  %1602 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1086, 1
  %1603 = mul <8 x i64> %1600, splat (i64 4)
  %1604 = add <8 x i64> %1602, %1603
  %1605 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1601, 0
  %1606 = insertvalue { <8 x ptr>, <8 x i64> } %1605, <8 x i64> %1604, 1
  %1607 = extractvalue { <8 x ptr>, <8 x i64> } %1606, 0
  %1608 = extractvalue { <8 x ptr>, <8 x i64> } %1606, 1
  %1609 = getelementptr i8, <8 x ptr> %1607, <8 x i64> %1608
  %1610 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1609, <8 x i1> %1561, <8 x float> zeroinitializer)
  %1611 = fmul <8 x float> %1577, %1599
  %.state1087 = load <8 x float>, ptr %.slot131, align 32
  %1612 = fadd <8 x float> %.state1087, %1611
  %1613 = fmul <8 x float> %1577, %1610
  %.state1088 = load <8 x float>, ptr %.slot132, align 32
  %1614 = fadd <8 x float> %.state1088, %1613
  %1615 = fmul <8 x float> %1588, %1599
  %.state1089 = load <8 x float>, ptr %.slot133, align 32
  %1616 = fadd <8 x float> %.state1089, %1615
  %1617 = fmul <8 x float> %1588, %1610
  %.state1090 = load <8 x float>, ptr %.slot134, align 32
  %1618 = fadd <8 x float> %.state1090, %1617
  %.state1091 = load <8 x i64>, ptr %.slot55, align 64
  %1619 = add <8 x i64> %.state1091, splat (i64 1)
  %1620 = load <8 x i64>, ptr %.slot55, align 64
  %1621 = select <8 x i1> %1561, <8 x i64> %1619, <8 x i64> %1620
  store <8 x i64> %1621, ptr %.slot55, align 64
  %1622 = load <8 x float>, ptr %.slot131, align 32
  %1623 = select <8 x i1> %1561, <8 x float> %1612, <8 x float> %1622
  store <8 x float> %1623, ptr %.slot131, align 32
  %1624 = load <8 x float>, ptr %.slot132, align 32
  %1625 = select <8 x i1> %1561, <8 x float> %1614, <8 x float> %1624
  store <8 x float> %1625, ptr %.slot132, align 32
  %1626 = load <8 x float>, ptr %.slot133, align 32
  %1627 = select <8 x i1> %1561, <8 x float> %1616, <8 x float> %1626
  store <8 x float> %1627, ptr %.slot133, align 32
  %1628 = load <8 x float>, ptr %.slot134, align 32
  %1629 = select <8 x i1> %1561, <8 x float> %1618, <8 x float> %1628
  store <8 x float> %1629, ptr %.slot134, align 32
  store <8 x i1> %1561, ptr %current.mask, align 1
  %1630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1561)
  br i1 %1630, label %schedule.57, label %scheduler.loop

schedule.59:                                      ; preds = %varying.coherent.false1078, %scheduler.dispatch.route
  %1631 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1094 = load i32, ptr %current.token, align 4
  %convergence.token.present1095 = icmp ne i32 %convergence.current.token1094, 0
  br i1 %convergence.token.present1095, label %convergence.cascade1092, label %convergence.cascade.exit1093

schedule.60:                                      ; preds = %schedule.61, %convergence.target.59.ready, %scheduler.dispatch.route
  %1632 = load <8 x i1>, ptr %current.mask, align 1
  %1633 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1632)
  %1634 = bitcast <8 x i1> %1632 to i8
  %1635 = call i8 @llvm.cttz.i8(i8 %1634, i1 false)
  %1636 = zext i8 %1635 to i32
  %1637 = select i1 %1633, i32 %1636, i32 0
  %.state1319 = load <8 x i64>, ptr %.slot55, align 64
  %1638 = icmp slt <8 x i64> %.state1319, splat (i64 16)
  %1639 = and <8 x i1> %1632, %1638
  %1640 = xor <8 x i1> %1638, splat (i1 true)
  %1641 = and <8 x i1> %1632, %1640
  %1642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1639)
  %1643 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1641)
  %1644 = and i1 %1642, %1643
  br i1 %1644, label %varying.divergent1320, label %varying.coherent1321

schedule.61:                                      ; preds = %varying.coherent.true1326, %scheduler.dispatch.route
  %1645 = load <8 x i1>, ptr %current.mask, align 1
  %1646 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1645)
  %1647 = bitcast <8 x i1> %1645 to i8
  %1648 = call i8 @llvm.cttz.i8(i8 %1647, i1 false)
  %1649 = zext i8 %1648 to i32
  %1650 = select i1 %1646, i32 %1649, i32 0
  %.state1328 = load <8 x i64>, ptr %.slot55, align 64
  %1651 = select <8 x i1> %1645, <8 x i64> %.state1328, <8 x i64> zeroinitializer
  %1652 = select <8 x i1> %1645, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1653 = sdiv <8 x i64> %1651, %1652
  %1654 = add <8 x i64> zeroinitializer, %1653
  %tile_snapshot.spill.load1329 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill263, align 64
  %1655 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1329, 0
  %1656 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1329, 1
  %1657 = mul <8 x i64> %1654, splat (i64 32)
  %1658 = add <8 x i64> %1656, %1657
  %1659 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1655, 0
  %1660 = insertvalue { <8 x ptr>, <8 x i64> } %1659, <8 x i64> %1658, 1
  %1661 = extractvalue { <8 x ptr>, <8 x i64> } %1660, 0
  %1662 = extractvalue { <8 x ptr>, <8 x i64> } %1660, 1
  %1663 = getelementptr i8, <8 x ptr> %1661, <8 x i64> %1662
  %1664 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1663, <8 x i1> %1645, <8 x float> zeroinitializer)
  %.state1330 = load <8 x float>, ptr %.slot56, align 32
  %1665 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1330, <8 x float> %1664)
  %.state1331 = load <8 x i64>, ptr %.slot55, align 64
  %1666 = add <8 x i64> %.state1331, splat (i64 1)
  %1667 = load <8 x i64>, ptr %.slot55, align 64
  %1668 = select <8 x i1> %1645, <8 x i64> %1666, <8 x i64> %1667
  store <8 x i64> %1668, ptr %.slot55, align 64
  %1669 = load <8 x float>, ptr %.slot56, align 32
  %1670 = select <8 x i1> %1645, <8 x float> %1665, <8 x float> %1669
  store <8 x float> %1670, ptr %.slot56, align 32
  store <8 x i1> %1645, ptr %current.mask, align 1
  %1671 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1645)
  br i1 %1671, label %schedule.60, label %scheduler.loop

schedule.62:                                      ; preds = %varying.coherent.false1327, %scheduler.dispatch.route
  %1672 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1334 = load i32, ptr %current.token, align 4
  %convergence.token.present1335 = icmp ne i32 %convergence.current.token1334, 0
  br i1 %convergence.token.present1335, label %convergence.cascade1332, label %convergence.cascade.exit1333

schedule.63:                                      ; preds = %schedule.64, %convergence.target.62.ready, %scheduler.dispatch.route
  %1673 = load <8 x i1>, ptr %current.mask, align 1
  %1674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1673)
  %1675 = bitcast <8 x i1> %1673 to i8
  %1676 = call i8 @llvm.cttz.i8(i8 %1675, i1 false)
  %1677 = zext i8 %1676 to i32
  %1678 = select i1 %1674, i32 %1677, i32 0
  %.state1349 = load <8 x i64>, ptr %.slot55, align 64
  %1679 = icmp slt <8 x i64> %.state1349, splat (i64 16)
  %1680 = and <8 x i1> %1673, %1679
  %1681 = xor <8 x i1> %1679, splat (i1 true)
  %1682 = and <8 x i1> %1673, %1681
  %1683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1680)
  %1684 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1682)
  %1685 = and i1 %1683, %1684
  br i1 %1685, label %varying.divergent1350, label %varying.coherent1351

schedule.64:                                      ; preds = %varying.coherent.true1356, %scheduler.dispatch.route
  %1686 = load <8 x i1>, ptr %current.mask, align 1
  %1687 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1686)
  %1688 = bitcast <8 x i1> %1686 to i8
  %1689 = call i8 @llvm.cttz.i8(i8 %1688, i1 false)
  %1690 = zext i8 %1689 to i32
  %1691 = select i1 %1687, i32 %1690, i32 0
  %.state1358 = load <8 x i64>, ptr %.slot55, align 64
  %1692 = select <8 x i1> %1686, <8 x i64> %.state1358, <8 x i64> zeroinitializer
  %1693 = select <8 x i1> %1686, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1694 = sdiv <8 x i64> %1692, %1693
  %1695 = add <8 x i64> splat (i64 16), %1694
  %tile_snapshot.spill.load1359 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill263, align 64
  %1696 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1359, 0
  %1697 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1359, 1
  %1698 = mul <8 x i64> %1695, splat (i64 32)
  %1699 = add <8 x i64> %1697, %1698
  %1700 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1696, 0
  %1701 = insertvalue { <8 x ptr>, <8 x i64> } %1700, <8 x i64> %1699, 1
  %1702 = extractvalue { <8 x ptr>, <8 x i64> } %1701, 0
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %1701, 1
  %1704 = getelementptr i8, <8 x ptr> %1702, <8 x i64> %1703
  %1705 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1704, <8 x i1> %1686, <8 x float> zeroinitializer)
  %.state1360 = load <8 x float>, ptr %.slot57, align 32
  %1706 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1360, <8 x float> %1705)
  %.state1361 = load <8 x i64>, ptr %.slot55, align 64
  %1707 = add <8 x i64> %.state1361, splat (i64 1)
  %1708 = load <8 x i64>, ptr %.slot55, align 64
  %1709 = select <8 x i1> %1686, <8 x i64> %1707, <8 x i64> %1708
  store <8 x i64> %1709, ptr %.slot55, align 64
  %1710 = load <8 x float>, ptr %.slot57, align 32
  %1711 = select <8 x i1> %1686, <8 x float> %1706, <8 x float> %1710
  store <8 x float> %1711, ptr %.slot57, align 32
  store <8 x i1> %1686, ptr %current.mask, align 1
  %1712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1686)
  br i1 %1712, label %schedule.63, label %scheduler.loop

schedule.65:                                      ; preds = %varying.coherent.false1357, %scheduler.dispatch.route
  %1713 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1364 = load i32, ptr %current.token, align 4
  %convergence.token.present1365 = icmp ne i32 %convergence.current.token1364, 0
  br i1 %convergence.token.present1365, label %convergence.cascade1362, label %convergence.cascade.exit1363

schedule.66:                                      ; preds = %schedule.67, %convergence.target.65.ready, %scheduler.dispatch.route
  %1714 = load <8 x i1>, ptr %current.mask, align 1
  %1715 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1714)
  %1716 = bitcast <8 x i1> %1714 to i8
  %1717 = call i8 @llvm.cttz.i8(i8 %1716, i1 false)
  %1718 = zext i8 %1717 to i32
  %1719 = select i1 %1715, i32 %1718, i32 0
  %.state1379 = load <8 x i64>, ptr %.slot55, align 64
  %1720 = icmp slt <8 x i64> %.state1379, splat (i64 16)
  %1721 = and <8 x i1> %1714, %1720
  %1722 = xor <8 x i1> %1720, splat (i1 true)
  %1723 = and <8 x i1> %1714, %1722
  %1724 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1721)
  %1725 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1723)
  %1726 = and i1 %1724, %1725
  br i1 %1726, label %varying.divergent1380, label %varying.coherent1381

schedule.67:                                      ; preds = %varying.coherent.true1386, %scheduler.dispatch.route
  %1727 = load <8 x i1>, ptr %current.mask, align 1
  %1728 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1727)
  %1729 = bitcast <8 x i1> %1727 to i8
  %1730 = call i8 @llvm.cttz.i8(i8 %1729, i1 false)
  %1731 = zext i8 %1730 to i32
  %1732 = select i1 %1728, i32 %1731, i32 0
  %.state1388 = load <8 x i64>, ptr %.slot55, align 64
  %1733 = select <8 x i1> %1727, <8 x i64> %.state1388, <8 x i64> zeroinitializer
  %1734 = select <8 x i1> %1727, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1735 = sdiv <8 x i64> %1733, %1734
  %1736 = add <8 x i64> splat (i64 32), %1735
  %tile_snapshot.spill.load1389 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill263, align 64
  %1737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1389, 0
  %1738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1389, 1
  %1739 = mul <8 x i64> %1736, splat (i64 32)
  %1740 = add <8 x i64> %1738, %1739
  %1741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1737, 0
  %1742 = insertvalue { <8 x ptr>, <8 x i64> } %1741, <8 x i64> %1740, 1
  %1743 = extractvalue { <8 x ptr>, <8 x i64> } %1742, 0
  %1744 = extractvalue { <8 x ptr>, <8 x i64> } %1742, 1
  %1745 = getelementptr i8, <8 x ptr> %1743, <8 x i64> %1744
  %1746 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1745, <8 x i1> %1727, <8 x float> zeroinitializer)
  %.state1390 = load <8 x float>, ptr %.slot58, align 32
  %1747 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1390, <8 x float> %1746)
  %.state1391 = load <8 x i64>, ptr %.slot55, align 64
  %1748 = add <8 x i64> %.state1391, splat (i64 1)
  %1749 = load <8 x i64>, ptr %.slot55, align 64
  %1750 = select <8 x i1> %1727, <8 x i64> %1748, <8 x i64> %1749
  store <8 x i64> %1750, ptr %.slot55, align 64
  %1751 = load <8 x float>, ptr %.slot58, align 32
  %1752 = select <8 x i1> %1727, <8 x float> %1747, <8 x float> %1751
  store <8 x float> %1752, ptr %.slot58, align 32
  store <8 x i1> %1727, ptr %current.mask, align 1
  %1753 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1727)
  br i1 %1753, label %schedule.66, label %scheduler.loop

schedule.68:                                      ; preds = %varying.coherent.false1387, %scheduler.dispatch.route
  %1754 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1394 = load i32, ptr %current.token, align 4
  %convergence.token.present1395 = icmp ne i32 %convergence.current.token1394, 0
  br i1 %convergence.token.present1395, label %convergence.cascade1392, label %convergence.cascade.exit1393

schedule.69:                                      ; preds = %schedule.70, %convergence.target.68.ready, %scheduler.dispatch.route
  %1755 = load <8 x i1>, ptr %current.mask, align 1
  %1756 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1755)
  %1757 = bitcast <8 x i1> %1755 to i8
  %1758 = call i8 @llvm.cttz.i8(i8 %1757, i1 false)
  %1759 = zext i8 %1758 to i32
  %1760 = select i1 %1756, i32 %1759, i32 0
  %.state1409 = load <8 x i64>, ptr %.slot55, align 64
  %1761 = icmp slt <8 x i64> %.state1409, splat (i64 16)
  %1762 = and <8 x i1> %1755, %1761
  %1763 = xor <8 x i1> %1761, splat (i1 true)
  %1764 = and <8 x i1> %1755, %1763
  %1765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1762)
  %1766 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1764)
  %1767 = and i1 %1765, %1766
  br i1 %1767, label %varying.divergent1410, label %varying.coherent1411

schedule.70:                                      ; preds = %varying.coherent.true1416, %scheduler.dispatch.route
  %1768 = load <8 x i1>, ptr %current.mask, align 1
  %1769 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1768)
  %1770 = bitcast <8 x i1> %1768 to i8
  %1771 = call i8 @llvm.cttz.i8(i8 %1770, i1 false)
  %1772 = zext i8 %1771 to i32
  %1773 = select i1 %1769, i32 %1772, i32 0
  %.state1418 = load <8 x i64>, ptr %.slot55, align 64
  %1774 = select <8 x i1> %1768, <8 x i64> %.state1418, <8 x i64> zeroinitializer
  %1775 = select <8 x i1> %1768, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1776 = sdiv <8 x i64> %1774, %1775
  %1777 = add <8 x i64> splat (i64 48), %1776
  %tile_snapshot.spill.load1419 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill263, align 64
  %1778 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1419, 0
  %1779 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1419, 1
  %1780 = mul <8 x i64> %1777, splat (i64 32)
  %1781 = add <8 x i64> %1779, %1780
  %1782 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1778, 0
  %1783 = insertvalue { <8 x ptr>, <8 x i64> } %1782, <8 x i64> %1781, 1
  %1784 = extractvalue { <8 x ptr>, <8 x i64> } %1783, 0
  %1785 = extractvalue { <8 x ptr>, <8 x i64> } %1783, 1
  %1786 = getelementptr i8, <8 x ptr> %1784, <8 x i64> %1785
  %1787 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1786, <8 x i1> %1768, <8 x float> zeroinitializer)
  %.state1420 = load <8 x float>, ptr %.slot59, align 32
  %1788 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1420, <8 x float> %1787)
  %.state1421 = load <8 x i64>, ptr %.slot55, align 64
  %1789 = add <8 x i64> %.state1421, splat (i64 1)
  %1790 = load <8 x i64>, ptr %.slot55, align 64
  %1791 = select <8 x i1> %1768, <8 x i64> %1789, <8 x i64> %1790
  store <8 x i64> %1791, ptr %.slot55, align 64
  %1792 = load <8 x float>, ptr %.slot59, align 32
  %1793 = select <8 x i1> %1768, <8 x float> %1788, <8 x float> %1792
  store <8 x float> %1793, ptr %.slot59, align 32
  store <8 x i1> %1768, ptr %current.mask, align 1
  %1794 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1768)
  br i1 %1794, label %schedule.69, label %scheduler.loop

schedule.71:                                      ; preds = %varying.coherent.false1417, %scheduler.dispatch.route
  %1795 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1424 = load i32, ptr %current.token, align 4
  %convergence.token.present1425 = icmp ne i32 %convergence.current.token1424, 0
  br i1 %convergence.token.present1425, label %convergence.cascade1422, label %convergence.cascade.exit1423

schedule.72:                                      ; preds = %schedule.73, %convergence.target.71.ready, %scheduler.dispatch.route
  %1796 = load <8 x i1>, ptr %current.mask, align 1
  %1797 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1796)
  %1798 = bitcast <8 x i1> %1796 to i8
  %1799 = call i8 @llvm.cttz.i8(i8 %1798, i1 false)
  %1800 = zext i8 %1799 to i32
  %1801 = select i1 %1797, i32 %1800, i32 0
  %.state1786 = load <8 x i64>, ptr %.slot55, align 64
  %1802 = icmp slt <8 x i64> %.state1786, splat (i64 16)
  %1803 = and <8 x i1> %1796, %1802
  %1804 = xor <8 x i1> %1802, splat (i1 true)
  %1805 = and <8 x i1> %1796, %1804
  %1806 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1803)
  %1807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1805)
  %1808 = and i1 %1806, %1807
  br i1 %1808, label %varying.divergent1787, label %varying.coherent1788

schedule.73:                                      ; preds = %varying.coherent.true1793, %scheduler.dispatch.route
  %1809 = load <8 x i1>, ptr %current.mask, align 1
  %1810 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1809)
  %1811 = bitcast <8 x i1> %1809 to i8
  %1812 = call i8 @llvm.cttz.i8(i8 %1811, i1 false)
  %1813 = zext i8 %1812 to i32
  %1814 = select i1 %1810, i32 %1813, i32 0
  %.state1795 = load <8 x i64>, ptr %.slot55, align 64
  %1815 = select <8 x i1> %1809, <8 x i64> %.state1795, <8 x i64> zeroinitializer
  %1816 = select <8 x i1> %1809, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1817 = sdiv <8 x i64> %1815, %1816
  %1818 = add <8 x i64> zeroinitializer, %1817
  %tile_snapshot.spill.load1796 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill277, align 64
  %1819 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1796, 0
  %1820 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1796, 1
  %1821 = mul <8 x i64> %1818, splat (i64 32)
  %1822 = add <8 x i64> %1820, %1821
  %1823 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1819, 0
  %1824 = insertvalue { <8 x ptr>, <8 x i64> } %1823, <8 x i64> %1822, 1
  %1825 = extractvalue { <8 x ptr>, <8 x i64> } %1824, 0
  %1826 = extractvalue { <8 x ptr>, <8 x i64> } %1824, 1
  %1827 = getelementptr i8, <8 x ptr> %1825, <8 x i64> %1826
  %1828 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1827, <8 x i1> %1809, <8 x float> zeroinitializer)
  %.state1797 = load <8 x float>, ptr %.slot43, align 32
  %1829 = fadd <8 x float> %.state1797, %1828
  %.state1798 = load <8 x i64>, ptr %.slot55, align 64
  %1830 = add <8 x i64> %.state1798, splat (i64 1)
  %1831 = load <8 x i64>, ptr %.slot55, align 64
  %1832 = select <8 x i1> %1809, <8 x i64> %1830, <8 x i64> %1831
  store <8 x i64> %1832, ptr %.slot55, align 64
  %1833 = load <8 x float>, ptr %.slot43, align 32
  %1834 = select <8 x i1> %1809, <8 x float> %1829, <8 x float> %1833
  store <8 x float> %1834, ptr %.slot43, align 32
  store <8 x i1> %1809, ptr %current.mask, align 1
  %1835 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1809)
  br i1 %1835, label %schedule.72, label %scheduler.loop

schedule.74:                                      ; preds = %varying.coherent.false1794, %scheduler.dispatch.route
  %1836 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1801 = load i32, ptr %current.token, align 4
  %convergence.token.present1802 = icmp ne i32 %convergence.current.token1801, 0
  br i1 %convergence.token.present1802, label %convergence.cascade1799, label %convergence.cascade.exit1800

schedule.75:                                      ; preds = %schedule.76, %convergence.target.74.ready, %scheduler.dispatch.route
  %1837 = load <8 x i1>, ptr %current.mask, align 1
  %1838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1837)
  %1839 = bitcast <8 x i1> %1837 to i8
  %1840 = call i8 @llvm.cttz.i8(i8 %1839, i1 false)
  %1841 = zext i8 %1840 to i32
  %1842 = select i1 %1838, i32 %1841, i32 0
  %.state1816 = load <8 x i64>, ptr %.slot55, align 64
  %1843 = icmp slt <8 x i64> %.state1816, splat (i64 16)
  %1844 = and <8 x i1> %1837, %1843
  %1845 = xor <8 x i1> %1843, splat (i1 true)
  %1846 = and <8 x i1> %1837, %1845
  %1847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1844)
  %1848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1846)
  %1849 = and i1 %1847, %1848
  br i1 %1849, label %varying.divergent1817, label %varying.coherent1818

schedule.76:                                      ; preds = %varying.coherent.true1823, %scheduler.dispatch.route
  %1850 = load <8 x i1>, ptr %current.mask, align 1
  %1851 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1850)
  %1852 = bitcast <8 x i1> %1850 to i8
  %1853 = call i8 @llvm.cttz.i8(i8 %1852, i1 false)
  %1854 = zext i8 %1853 to i32
  %1855 = select i1 %1851, i32 %1854, i32 0
  %.state1825 = load <8 x i64>, ptr %.slot55, align 64
  %1856 = select <8 x i1> %1850, <8 x i64> %.state1825, <8 x i64> zeroinitializer
  %1857 = select <8 x i1> %1850, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1858 = sdiv <8 x i64> %1856, %1857
  %1859 = add <8 x i64> splat (i64 16), %1858
  %tile_snapshot.spill.load1826 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill277, align 64
  %1860 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1826, 0
  %1861 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1826, 1
  %1862 = mul <8 x i64> %1859, splat (i64 32)
  %1863 = add <8 x i64> %1861, %1862
  %1864 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1860, 0
  %1865 = insertvalue { <8 x ptr>, <8 x i64> } %1864, <8 x i64> %1863, 1
  %1866 = extractvalue { <8 x ptr>, <8 x i64> } %1865, 0
  %1867 = extractvalue { <8 x ptr>, <8 x i64> } %1865, 1
  %1868 = getelementptr i8, <8 x ptr> %1866, <8 x i64> %1867
  %1869 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1868, <8 x i1> %1850, <8 x float> zeroinitializer)
  %.state1827 = load <8 x float>, ptr %.slot44, align 32
  %1870 = fadd <8 x float> %.state1827, %1869
  %.state1828 = load <8 x i64>, ptr %.slot55, align 64
  %1871 = add <8 x i64> %.state1828, splat (i64 1)
  %1872 = load <8 x i64>, ptr %.slot55, align 64
  %1873 = select <8 x i1> %1850, <8 x i64> %1871, <8 x i64> %1872
  store <8 x i64> %1873, ptr %.slot55, align 64
  %1874 = load <8 x float>, ptr %.slot44, align 32
  %1875 = select <8 x i1> %1850, <8 x float> %1870, <8 x float> %1874
  store <8 x float> %1875, ptr %.slot44, align 32
  store <8 x i1> %1850, ptr %current.mask, align 1
  %1876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1850)
  br i1 %1876, label %schedule.75, label %scheduler.loop

schedule.77:                                      ; preds = %varying.coherent.false1824, %scheduler.dispatch.route
  %1877 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1831 = load i32, ptr %current.token, align 4
  %convergence.token.present1832 = icmp ne i32 %convergence.current.token1831, 0
  br i1 %convergence.token.present1832, label %convergence.cascade1829, label %convergence.cascade.exit1830

schedule.78:                                      ; preds = %schedule.79, %convergence.target.77.ready, %scheduler.dispatch.route
  %1878 = load <8 x i1>, ptr %current.mask, align 1
  %1879 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1878)
  %1880 = bitcast <8 x i1> %1878 to i8
  %1881 = call i8 @llvm.cttz.i8(i8 %1880, i1 false)
  %1882 = zext i8 %1881 to i32
  %1883 = select i1 %1879, i32 %1882, i32 0
  %.state1846 = load <8 x i64>, ptr %.slot55, align 64
  %1884 = icmp slt <8 x i64> %.state1846, splat (i64 16)
  %1885 = and <8 x i1> %1878, %1884
  %1886 = xor <8 x i1> %1884, splat (i1 true)
  %1887 = and <8 x i1> %1878, %1886
  %1888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1885)
  %1889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1887)
  %1890 = and i1 %1888, %1889
  br i1 %1890, label %varying.divergent1847, label %varying.coherent1848

schedule.79:                                      ; preds = %varying.coherent.true1853, %scheduler.dispatch.route
  %1891 = load <8 x i1>, ptr %current.mask, align 1
  %1892 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1891)
  %1893 = bitcast <8 x i1> %1891 to i8
  %1894 = call i8 @llvm.cttz.i8(i8 %1893, i1 false)
  %1895 = zext i8 %1894 to i32
  %1896 = select i1 %1892, i32 %1895, i32 0
  %.state1855 = load <8 x i64>, ptr %.slot55, align 64
  %1897 = select <8 x i1> %1891, <8 x i64> %.state1855, <8 x i64> zeroinitializer
  %1898 = select <8 x i1> %1891, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1899 = sdiv <8 x i64> %1897, %1898
  %1900 = add <8 x i64> splat (i64 32), %1899
  %tile_snapshot.spill.load1856 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill277, align 64
  %1901 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1856, 0
  %1902 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1856, 1
  %1903 = mul <8 x i64> %1900, splat (i64 32)
  %1904 = add <8 x i64> %1902, %1903
  %1905 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1901, 0
  %1906 = insertvalue { <8 x ptr>, <8 x i64> } %1905, <8 x i64> %1904, 1
  %1907 = extractvalue { <8 x ptr>, <8 x i64> } %1906, 0
  %1908 = extractvalue { <8 x ptr>, <8 x i64> } %1906, 1
  %1909 = getelementptr i8, <8 x ptr> %1907, <8 x i64> %1908
  %1910 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1909, <8 x i1> %1891, <8 x float> zeroinitializer)
  %.state1857 = load <8 x float>, ptr %.slot45, align 32
  %1911 = fadd <8 x float> %.state1857, %1910
  %.state1858 = load <8 x i64>, ptr %.slot55, align 64
  %1912 = add <8 x i64> %.state1858, splat (i64 1)
  %1913 = load <8 x i64>, ptr %.slot55, align 64
  %1914 = select <8 x i1> %1891, <8 x i64> %1912, <8 x i64> %1913
  store <8 x i64> %1914, ptr %.slot55, align 64
  %1915 = load <8 x float>, ptr %.slot45, align 32
  %1916 = select <8 x i1> %1891, <8 x float> %1911, <8 x float> %1915
  store <8 x float> %1916, ptr %.slot45, align 32
  store <8 x i1> %1891, ptr %current.mask, align 1
  %1917 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1891)
  br i1 %1917, label %schedule.78, label %scheduler.loop

schedule.80:                                      ; preds = %varying.coherent.false1854, %scheduler.dispatch.route
  %1918 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1861 = load i32, ptr %current.token, align 4
  %convergence.token.present1862 = icmp ne i32 %convergence.current.token1861, 0
  br i1 %convergence.token.present1862, label %convergence.cascade1859, label %convergence.cascade.exit1860

schedule.81:                                      ; preds = %schedule.82, %convergence.target.80.ready, %scheduler.dispatch.route
  %1919 = load <8 x i1>, ptr %current.mask, align 1
  %1920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1919)
  %1921 = bitcast <8 x i1> %1919 to i8
  %1922 = call i8 @llvm.cttz.i8(i8 %1921, i1 false)
  %1923 = zext i8 %1922 to i32
  %1924 = select i1 %1920, i32 %1923, i32 0
  %.state1876 = load <8 x i64>, ptr %.slot55, align 64
  %1925 = icmp slt <8 x i64> %.state1876, splat (i64 16)
  %1926 = and <8 x i1> %1919, %1925
  %1927 = xor <8 x i1> %1925, splat (i1 true)
  %1928 = and <8 x i1> %1919, %1927
  %1929 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1926)
  %1930 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1928)
  %1931 = and i1 %1929, %1930
  br i1 %1931, label %varying.divergent1877, label %varying.coherent1878

schedule.82:                                      ; preds = %varying.coherent.true1883, %scheduler.dispatch.route
  %1932 = load <8 x i1>, ptr %current.mask, align 1
  %1933 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1932)
  %1934 = bitcast <8 x i1> %1932 to i8
  %1935 = call i8 @llvm.cttz.i8(i8 %1934, i1 false)
  %1936 = zext i8 %1935 to i32
  %1937 = select i1 %1933, i32 %1936, i32 0
  %.state1885 = load <8 x i64>, ptr %.slot55, align 64
  %1938 = select <8 x i1> %1932, <8 x i64> %.state1885, <8 x i64> zeroinitializer
  %1939 = select <8 x i1> %1932, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1940 = sdiv <8 x i64> %1938, %1939
  %1941 = add <8 x i64> splat (i64 48), %1940
  %tile_snapshot.spill.load1886 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill277, align 64
  %1942 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1886, 0
  %1943 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1886, 1
  %1944 = mul <8 x i64> %1941, splat (i64 32)
  %1945 = add <8 x i64> %1943, %1944
  %1946 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1942, 0
  %1947 = insertvalue { <8 x ptr>, <8 x i64> } %1946, <8 x i64> %1945, 1
  %1948 = extractvalue { <8 x ptr>, <8 x i64> } %1947, 0
  %1949 = extractvalue { <8 x ptr>, <8 x i64> } %1947, 1
  %1950 = getelementptr i8, <8 x ptr> %1948, <8 x i64> %1949
  %1951 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1950, <8 x i1> %1932, <8 x float> zeroinitializer)
  %.state1887 = load <8 x float>, ptr %.slot46, align 32
  %1952 = fadd <8 x float> %.state1887, %1951
  %.state1888 = load <8 x i64>, ptr %.slot55, align 64
  %1953 = add <8 x i64> %.state1888, splat (i64 1)
  %1954 = load <8 x i64>, ptr %.slot55, align 64
  %1955 = select <8 x i1> %1932, <8 x i64> %1953, <8 x i64> %1954
  store <8 x i64> %1955, ptr %.slot55, align 64
  %1956 = load <8 x float>, ptr %.slot46, align 32
  %1957 = select <8 x i1> %1932, <8 x float> %1952, <8 x float> %1956
  store <8 x float> %1957, ptr %.slot46, align 32
  store <8 x i1> %1932, ptr %current.mask, align 1
  %1958 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1932)
  br i1 %1958, label %schedule.81, label %scheduler.loop

schedule.83:                                      ; preds = %varying.coherent.false1884, %scheduler.dispatch.route
  %1959 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1891 = load i32, ptr %current.token, align 4
  %convergence.token.present1892 = icmp ne i32 %convergence.current.token1891, 0
  br i1 %convergence.token.present1892, label %convergence.cascade1889, label %convergence.cascade.exit1890

schedule.84:                                      ; preds = %convergence.target.91.ready, %convergence.target.83.ready, %scheduler.dispatch.route
  %1960 = load <8 x i1>, ptr %current.mask, align 1
  %1961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1960)
  %1962 = bitcast <8 x i1> %1960 to i8
  %1963 = call i8 @llvm.cttz.i8(i8 %1962, i1 false)
  %1964 = zext i8 %1963 to i32
  %1965 = select i1 %1961, i32 %1964, i32 0
  %.state1914 = load <8 x i64>, ptr %.slot55, align 64
  %1966 = icmp slt <8 x i64> %.state1914, splat (i64 2)
  %1967 = and <8 x i1> %1960, %1966
  %1968 = xor <8 x i1> %1966, splat (i1 true)
  %1969 = and <8 x i1> %1960, %1968
  %1970 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1967)
  %1971 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1969)
  %1972 = and i1 %1970, %1971
  br i1 %1972, label %varying.divergent1915, label %varying.coherent1916

schedule.85:                                      ; preds = %varying.coherent.true1921, %scheduler.dispatch.route
  %1973 = load <8 x i1>, ptr %current.mask, align 1
  %1974 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1973)
  %1975 = bitcast <8 x i1> %1973 to i8
  %1976 = call i8 @llvm.cttz.i8(i8 %1975, i1 false)
  %1977 = zext i8 %1976 to i32
  %1978 = select i1 %1974, i32 %1977, i32 0
  %.state1923 = load <8 x i64>, ptr %.slot55, align 64
  %1979 = mul <8 x i64> %.state1923, splat (i64 2)
  %1980 = load <8 x i64>, ptr %.spill296, align 64
  %1981 = select <8 x i1> %1973, <8 x i64> %1979, <8 x i64> %1980
  store <8 x i64> %1981, ptr %.spill296, align 64
  %1982 = load <8 x i64>, ptr %.slot297, align 64
  %1983 = select <8 x i1> %1973, <8 x i64> zeroinitializer, <8 x i64> %1982
  store <8 x i64> %1983, ptr %.slot297, align 64
  store <8 x i1> %1973, ptr %current.mask, align 1
  %1984 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1973)
  br i1 %1984, label %schedule.86, label %scheduler.loop

schedule.86:                                      ; preds = %convergence.target.90.ready, %schedule.85, %scheduler.dispatch.route
  %1985 = load <8 x i1>, ptr %current.mask, align 1
  %1986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1985)
  %1987 = bitcast <8 x i1> %1985 to i8
  %1988 = call i8 @llvm.cttz.i8(i8 %1987, i1 false)
  %1989 = zext i8 %1988 to i32
  %1990 = select i1 %1986, i32 %1989, i32 0
  %.state1924 = load <8 x i64>, ptr %.slot297, align 64
  %1991 = icmp slt <8 x i64> %.state1924, splat (i64 24)
  %1992 = and <8 x i1> %1985, %1991
  %1993 = xor <8 x i1> %1991, splat (i1 true)
  %1994 = and <8 x i1> %1985, %1993
  %1995 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1992)
  %1996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1994)
  %1997 = and i1 %1995, %1996
  br i1 %1997, label %varying.divergent1925, label %varying.coherent1926

schedule.87:                                      ; preds = %varying.coherent.true1931, %scheduler.dispatch.route
  %1998 = load <8 x i1>, ptr %current.mask, align 1
  %1999 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1998)
  %2000 = bitcast <8 x i1> %1998 to i8
  %2001 = call i8 @llvm.cttz.i8(i8 %2000, i1 false)
  %2002 = zext i8 %2001 to i32
  %2003 = select i1 %1999, i32 %2002, i32 0
  %.state1933 = load <8 x i64>, ptr %.slot297, align 64
  %2004 = mul <8 x i64> %.state1933, splat (i64 2)
  %.spill.load1934 = load <8 x i64>, ptr %.spill296, align 64
  %2005 = add <8 x i64> zeroinitializer, %.spill.load1934
  %2006 = mul <8 x i64> %2005, splat (i64 48)
  %2007 = add <8 x i64> %2006, %2004
  %2008 = add <8 x i64> %2007, zeroinitializer
  %2009 = load <8 x i64>, ptr %.spill298, align 64
  %2010 = select <8 x i1> %1998, <8 x i64> %2008, <8 x i64> %2009
  store <8 x i64> %2010, ptr %.spill298, align 64
  %2011 = select <8 x i1> %1998, <8 x i64> %2008, <8 x i64> zeroinitializer
  %2012 = select <8 x i1> %1998, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2013 = srem <8 x i64> %2011, %2012
  %2014 = load <8 x i64>, ptr %.spill299, align 64
  %2015 = select <8 x i1> %1998, <8 x i64> %2013, <8 x i64> %2014
  store <8 x i64> %2015, ptr %.spill299, align 64
  %2016 = select <8 x i1> %1998, <8 x i64> %2008, <8 x i64> zeroinitializer
  %2017 = select <8 x i1> %1998, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2018 = sdiv <8 x i64> %2016, %2017
  %2019 = add <8 x i64> zeroinitializer, %2018
  %2020 = load <8 x i64>, ptr %.spill300, align 64
  %2021 = select <8 x i1> %1998, <8 x i64> %2019, <8 x i64> %2020
  store <8 x i64> %2021, ptr %.spill300, align 64
  %2022 = mul <8 x i64> %2019, splat (i64 48)
  %2023 = add <8 x i64> %2022, %2013
  %tile_snapshot.spill.load1935 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %2024 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1935, 0
  %2025 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1935, 1
  %2026 = mul <8 x i64> %2023, splat (i64 32)
  %2027 = add <8 x i64> %2025, %2026
  %2028 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2024, 0
  %2029 = insertvalue { <8 x ptr>, <8 x i64> } %2028, <8 x i64> %2027, 1
  %2030 = extractvalue { <8 x ptr>, <8 x i64> } %2029, 0
  %2031 = extractvalue { <8 x ptr>, <8 x i64> } %2029, 1
  %2032 = getelementptr i8, <8 x ptr> %2030, <8 x i64> %2031
  %2033 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2032, <8 x i1> %1998, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1936 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill276, align 64
  %2034 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1936, 0
  %2035 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1936, 1
  %2036 = mul <8 x i64> %2019, splat (i64 32)
  %2037 = add <8 x i64> %2035, %2036
  %2038 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2034, 0
  %2039 = insertvalue { <8 x ptr>, <8 x i64> } %2038, <8 x i64> %2037, 1
  %2040 = extractvalue { <8 x ptr>, <8 x i64> } %2039, 0
  %2041 = extractvalue { <8 x ptr>, <8 x i64> } %2039, 1
  %2042 = getelementptr i8, <8 x ptr> %2040, <8 x i64> %2041
  %2043 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2042, <8 x i1> %1998, <8 x float> zeroinitializer)
  %2044 = fmul <8 x float> %2033, %2043
  %2045 = add <8 x i64> %2007, splat (i64 1)
  %2046 = load <8 x i64>, ptr %.spill301, align 64
  %2047 = select <8 x i1> %1998, <8 x i64> %2045, <8 x i64> %2046
  store <8 x i64> %2047, ptr %.spill301, align 64
  %2048 = select <8 x i1> %1998, <8 x i64> %2045, <8 x i64> zeroinitializer
  %2049 = select <8 x i1> %1998, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2050 = srem <8 x i64> %2048, %2049
  %2051 = load <8 x i64>, ptr %.spill302, align 64
  %2052 = select <8 x i1> %1998, <8 x i64> %2050, <8 x i64> %2051
  store <8 x i64> %2052, ptr %.spill302, align 64
  %2053 = select <8 x i1> %1998, <8 x i64> %2045, <8 x i64> zeroinitializer
  %2054 = select <8 x i1> %1998, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2055 = sdiv <8 x i64> %2053, %2054
  %2056 = add <8 x i64> zeroinitializer, %2055
  %2057 = mul <8 x i64> %2056, splat (i64 48)
  %2058 = add <8 x i64> %2057, %2050
  %tile_snapshot.spill.load1937 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %2059 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1937, 0
  %2060 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1937, 1
  %2061 = mul <8 x i64> %2058, splat (i64 32)
  %2062 = add <8 x i64> %2060, %2061
  %2063 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2059, 0
  %2064 = insertvalue { <8 x ptr>, <8 x i64> } %2063, <8 x i64> %2062, 1
  %2065 = extractvalue { <8 x ptr>, <8 x i64> } %2064, 0
  %2066 = extractvalue { <8 x ptr>, <8 x i64> } %2064, 1
  %2067 = getelementptr i8, <8 x ptr> %2065, <8 x i64> %2066
  %2068 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2067, <8 x i1> %1998, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1938 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill276, align 64
  %2069 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1938, 0
  %2070 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1938, 1
  %2071 = mul <8 x i64> %2056, splat (i64 32)
  %2072 = add <8 x i64> %2070, %2071
  %2073 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2069, 0
  %2074 = insertvalue { <8 x ptr>, <8 x i64> } %2073, <8 x i64> %2072, 1
  %2075 = extractvalue { <8 x ptr>, <8 x i64> } %2074, 0
  %2076 = extractvalue { <8 x ptr>, <8 x i64> } %2074, 1
  %2077 = getelementptr i8, <8 x ptr> %2075, <8 x i64> %2076
  %2078 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2077, <8 x i1> %1998, <8 x float> zeroinitializer)
  %2079 = fmul <8 x float> %2068, %2078
  %2080 = add <8 x i64> %2007, splat (i64 48)
  %2081 = load <8 x i64>, ptr %.spill303, align 64
  %2082 = select <8 x i1> %1998, <8 x i64> %2080, <8 x i64> %2081
  store <8 x i64> %2082, ptr %.spill303, align 64
  %2083 = select <8 x i1> %1998, <8 x i64> %2080, <8 x i64> zeroinitializer
  %2084 = select <8 x i1> %1998, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2085 = srem <8 x i64> %2083, %2084
  %2086 = select <8 x i1> %1998, <8 x i64> %2080, <8 x i64> zeroinitializer
  %2087 = select <8 x i1> %1998, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2088 = sdiv <8 x i64> %2086, %2087
  %2089 = add <8 x i64> zeroinitializer, %2088
  %2090 = load <8 x i64>, ptr %.spill304, align 64
  %2091 = select <8 x i1> %1998, <8 x i64> %2089, <8 x i64> %2090
  store <8 x i64> %2091, ptr %.spill304, align 64
  %2092 = mul <8 x i64> %2089, splat (i64 48)
  %2093 = add <8 x i64> %2092, %2085
  %tile_snapshot.spill.load1939 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %2094 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1939, 0
  %2095 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1939, 1
  %2096 = mul <8 x i64> %2093, splat (i64 32)
  %2097 = add <8 x i64> %2095, %2096
  %2098 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2094, 0
  %2099 = insertvalue { <8 x ptr>, <8 x i64> } %2098, <8 x i64> %2097, 1
  %2100 = extractvalue { <8 x ptr>, <8 x i64> } %2099, 0
  %2101 = extractvalue { <8 x ptr>, <8 x i64> } %2099, 1
  %2102 = getelementptr i8, <8 x ptr> %2100, <8 x i64> %2101
  %2103 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2102, <8 x i1> %1998, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1940 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill276, align 64
  %2104 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1940, 0
  %2105 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1940, 1
  %2106 = mul <8 x i64> %2089, splat (i64 32)
  %2107 = add <8 x i64> %2105, %2106
  %2108 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2104, 0
  %2109 = insertvalue { <8 x ptr>, <8 x i64> } %2108, <8 x i64> %2107, 1
  %2110 = extractvalue { <8 x ptr>, <8 x i64> } %2109, 0
  %2111 = extractvalue { <8 x ptr>, <8 x i64> } %2109, 1
  %2112 = getelementptr i8, <8 x ptr> %2110, <8 x i64> %2111
  %2113 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2112, <8 x i1> %1998, <8 x float> zeroinitializer)
  %2114 = fmul <8 x float> %2103, %2113
  %2115 = add <8 x i64> %2007, splat (i64 49)
  %2116 = load <8 x i64>, ptr %.spill305, align 64
  %2117 = select <8 x i1> %1998, <8 x i64> %2115, <8 x i64> %2116
  store <8 x i64> %2117, ptr %.spill305, align 64
  %2118 = select <8 x i1> %1998, <8 x i64> %2115, <8 x i64> zeroinitializer
  %2119 = select <8 x i1> %1998, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2120 = srem <8 x i64> %2118, %2119
  %2121 = select <8 x i1> %1998, <8 x i64> %2115, <8 x i64> zeroinitializer
  %2122 = select <8 x i1> %1998, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2123 = sdiv <8 x i64> %2121, %2122
  %2124 = add <8 x i64> zeroinitializer, %2123
  %2125 = mul <8 x i64> %2124, splat (i64 48)
  %2126 = add <8 x i64> %2125, %2120
  %tile_snapshot.spill.load1941 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %2127 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1941, 0
  %2128 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1941, 1
  %2129 = mul <8 x i64> %2126, splat (i64 32)
  %2130 = add <8 x i64> %2128, %2129
  %2131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2127, 0
  %2132 = insertvalue { <8 x ptr>, <8 x i64> } %2131, <8 x i64> %2130, 1
  %2133 = extractvalue { <8 x ptr>, <8 x i64> } %2132, 0
  %2134 = extractvalue { <8 x ptr>, <8 x i64> } %2132, 1
  %2135 = getelementptr i8, <8 x ptr> %2133, <8 x i64> %2134
  %2136 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2135, <8 x i1> %1998, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load1942 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill276, align 64
  %2137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1942, 0
  %2138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1942, 1
  %2139 = mul <8 x i64> %2124, splat (i64 32)
  %2140 = add <8 x i64> %2138, %2139
  %2141 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2137, 0
  %2142 = insertvalue { <8 x ptr>, <8 x i64> } %2141, <8 x i64> %2140, 1
  %2143 = extractvalue { <8 x ptr>, <8 x i64> } %2142, 0
  %2144 = extractvalue { <8 x ptr>, <8 x i64> } %2142, 1
  %2145 = getelementptr i8, <8 x ptr> %2143, <8 x i64> %2144
  %2146 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2145, <8 x i1> %1998, <8 x float> zeroinitializer)
  %2147 = fmul <8 x float> %2136, %2146
  %2148 = load <8 x i64>, ptr %.slot306, align 64
  %2149 = select <8 x i1> %1998, <8 x i64> zeroinitializer, <8 x i64> %2148
  store <8 x i64> %2149, ptr %.slot306, align 64
  %2150 = load <8 x float>, ptr %.slot43, align 32
  %2151 = select <8 x i1> %1998, <8 x float> %2044, <8 x float> %2150
  store <8 x float> %2151, ptr %.slot43, align 32
  %2152 = load <8 x float>, ptr %.slot44, align 32
  %2153 = select <8 x i1> %1998, <8 x float> %2079, <8 x float> %2152
  store <8 x float> %2153, ptr %.slot44, align 32
  %2154 = load <8 x float>, ptr %.slot45, align 32
  %2155 = select <8 x i1> %1998, <8 x float> %2114, <8 x float> %2154
  store <8 x float> %2155, ptr %.slot45, align 32
  %2156 = load <8 x float>, ptr %.slot46, align 32
  %2157 = select <8 x i1> %1998, <8 x float> %2147, <8 x float> %2156
  store <8 x float> %2157, ptr %.slot46, align 32
  store <8 x i1> %1998, ptr %current.mask, align 1
  %2158 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1998)
  br i1 %2158, label %schedule.88, label %scheduler.loop

schedule.88:                                      ; preds = %schedule.89, %schedule.87, %scheduler.dispatch.route
  %2159 = load <8 x i1>, ptr %current.mask, align 1
  %2160 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2159)
  %2161 = bitcast <8 x i1> %2159 to i8
  %2162 = call i8 @llvm.cttz.i8(i8 %2161, i1 false)
  %2163 = zext i8 %2162 to i32
  %2164 = select i1 %2160, i32 %2163, i32 0
  %.state1943 = load <8 x i64>, ptr %.slot306, align 64
  %2165 = icmp slt <8 x i64> %.state1943, splat (i64 16)
  %2166 = and <8 x i1> %2159, %2165
  %2167 = xor <8 x i1> %2165, splat (i1 true)
  %2168 = and <8 x i1> %2159, %2167
  %2169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2166)
  %2170 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2168)
  %2171 = and i1 %2169, %2170
  br i1 %2171, label %varying.divergent1944, label %varying.coherent1945

schedule.89:                                      ; preds = %varying.coherent.true1950, %scheduler.dispatch.route
  %2172 = load <8 x i1>, ptr %current.mask, align 1
  %2173 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2172)
  %2174 = bitcast <8 x i1> %2172 to i8
  %2175 = call i8 @llvm.cttz.i8(i8 %2174, i1 false)
  %2176 = zext i8 %2175 to i32
  %2177 = select i1 %2173, i32 %2176, i32 0
  %.spill.load1952 = load <8 x i64>, ptr %.spill300, align 64
  %2178 = mul <8 x i64> %.spill.load1952, splat (i64 16)
  %.state1953 = load <8 x i64>, ptr %.slot306, align 64
  %2179 = add <8 x i64> %2178, %.state1953
  %tile_snapshot.spill.load1954 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill277, align 64
  %2180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1954, 0
  %2181 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1954, 1
  %2182 = mul <8 x i64> %2179, splat (i64 32)
  %2183 = add <8 x i64> %2181, %2182
  %2184 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2180, 0
  %2185 = insertvalue { <8 x ptr>, <8 x i64> } %2184, <8 x i64> %2183, 1
  %2186 = extractvalue { <8 x ptr>, <8 x i64> } %2185, 0
  %2187 = extractvalue { <8 x ptr>, <8 x i64> } %2185, 1
  %2188 = getelementptr i8, <8 x ptr> %2186, <8 x i64> %2187
  %2189 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2188, <8 x i1> %2172, <8 x float> zeroinitializer)
  %.spill.load1955 = load <8 x i64>, ptr %.spill304, align 64
  %2190 = mul <8 x i64> %.spill.load1955, splat (i64 16)
  %.state1956 = load <8 x i64>, ptr %.slot306, align 64
  %2191 = add <8 x i64> %2190, %.state1956
  %tile_snapshot.spill.load1957 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill277, align 64
  %2192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1957, 0
  %2193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1957, 1
  %2194 = mul <8 x i64> %2191, splat (i64 32)
  %2195 = add <8 x i64> %2193, %2194
  %2196 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2192, 0
  %2197 = insertvalue { <8 x ptr>, <8 x i64> } %2196, <8 x i64> %2195, 1
  %2198 = extractvalue { <8 x ptr>, <8 x i64> } %2197, 0
  %2199 = extractvalue { <8 x ptr>, <8 x i64> } %2197, 1
  %2200 = getelementptr i8, <8 x ptr> %2198, <8 x i64> %2199
  %2201 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2200, <8 x i1> %2172, <8 x float> zeroinitializer)
  %.state1958 = load <8 x i64>, ptr %.slot306, align 64
  %2202 = add <8 x i64> zeroinitializer, %.state1958
  %2203 = mul <8 x i64> %2202, splat (i64 48)
  %.spill.load1959 = load <8 x i64>, ptr %.spill299, align 64
  %2204 = add <8 x i64> %2203, %.spill.load1959
  %tile_snapshot.spill.load1960 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %2205 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1960, 0
  %2206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1960, 1
  %2207 = mul <8 x i64> %2204, splat (i64 4)
  %2208 = add <8 x i64> %2206, %2207
  %2209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2205, 0
  %2210 = insertvalue { <8 x ptr>, <8 x i64> } %2209, <8 x i64> %2208, 1
  %2211 = extractvalue { <8 x ptr>, <8 x i64> } %2210, 0
  %2212 = extractvalue { <8 x ptr>, <8 x i64> } %2210, 1
  %2213 = getelementptr i8, <8 x ptr> %2211, <8 x i64> %2212
  %2214 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2213, <8 x i1> %2172, <8 x float> zeroinitializer)
  %.spill.load1961 = load <8 x i64>, ptr %.spill302, align 64
  %2215 = add <8 x i64> %2203, %.spill.load1961
  %tile_snapshot.spill.load1962 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %2216 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1962, 0
  %2217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1962, 1
  %2218 = mul <8 x i64> %2215, splat (i64 4)
  %2219 = add <8 x i64> %2217, %2218
  %2220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2216, 0
  %2221 = insertvalue { <8 x ptr>, <8 x i64> } %2220, <8 x i64> %2219, 1
  %2222 = extractvalue { <8 x ptr>, <8 x i64> } %2221, 0
  %2223 = extractvalue { <8 x ptr>, <8 x i64> } %2221, 1
  %2224 = getelementptr i8, <8 x ptr> %2222, <8 x i64> %2223
  %2225 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2224, <8 x i1> %2172, <8 x float> zeroinitializer)
  %2226 = fmul <8 x float> %2189, %2214
  %.state1963 = load <8 x float>, ptr %.slot43, align 32
  %2227 = fadd <8 x float> %.state1963, %2226
  %2228 = fmul <8 x float> %2189, %2225
  %.state1964 = load <8 x float>, ptr %.slot44, align 32
  %2229 = fadd <8 x float> %.state1964, %2228
  %2230 = fmul <8 x float> %2201, %2214
  %.state1965 = load <8 x float>, ptr %.slot45, align 32
  %2231 = fadd <8 x float> %.state1965, %2230
  %2232 = fmul <8 x float> %2201, %2225
  %.state1966 = load <8 x float>, ptr %.slot46, align 32
  %2233 = fadd <8 x float> %.state1966, %2232
  %.state1967 = load <8 x i64>, ptr %.slot306, align 64
  %2234 = add <8 x i64> %.state1967, splat (i64 1)
  %2235 = load <8 x i64>, ptr %.slot306, align 64
  %2236 = select <8 x i1> %2172, <8 x i64> %2234, <8 x i64> %2235
  store <8 x i64> %2236, ptr %.slot306, align 64
  %2237 = load <8 x float>, ptr %.slot43, align 32
  %2238 = select <8 x i1> %2172, <8 x float> %2227, <8 x float> %2237
  store <8 x float> %2238, ptr %.slot43, align 32
  %2239 = load <8 x float>, ptr %.slot44, align 32
  %2240 = select <8 x i1> %2172, <8 x float> %2229, <8 x float> %2239
  store <8 x float> %2240, ptr %.slot44, align 32
  %2241 = load <8 x float>, ptr %.slot45, align 32
  %2242 = select <8 x i1> %2172, <8 x float> %2231, <8 x float> %2241
  store <8 x float> %2242, ptr %.slot45, align 32
  %2243 = load <8 x float>, ptr %.slot46, align 32
  %2244 = select <8 x i1> %2172, <8 x float> %2233, <8 x float> %2243
  store <8 x float> %2244, ptr %.slot46, align 32
  store <8 x i1> %2172, ptr %current.mask, align 1
  %2245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2172)
  br i1 %2245, label %schedule.88, label %scheduler.loop

schedule.90:                                      ; preds = %varying.coherent.false1951, %scheduler.dispatch.route
  %2246 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token1970 = load i32, ptr %current.token, align 4
  %convergence.token.present1971 = icmp ne i32 %convergence.current.token1970, 0
  br i1 %convergence.token.present1971, label %convergence.cascade1968, label %convergence.cascade.exit1969

schedule.91:                                      ; preds = %varying.coherent.false1932, %scheduler.dispatch.route
  %2247 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2000 = load i32, ptr %current.token, align 4
  %convergence.token.present2001 = icmp ne i32 %convergence.current.token2000, 0
  br i1 %convergence.token.present2001, label %convergence.cascade1998, label %convergence.cascade.exit1999

schedule.92:                                      ; preds = %varying.coherent.false1922, %scheduler.dispatch.route
  %2248 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2018 = load i32, ptr %current.token, align 4
  %convergence.token.present2019 = icmp ne i32 %convergence.current.token2018, 0
  br i1 %convergence.token.present2019, label %convergence.cascade2016, label %convergence.cascade.exit2017

schedule.93:                                      ; preds = %schedule.94, %convergence.target.92.ready, %scheduler.dispatch.route
  %2249 = load <8 x i1>, ptr %current.mask, align 1
  %2250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2249)
  %2251 = bitcast <8 x i1> %2249 to i8
  %2252 = call i8 @llvm.cttz.i8(i8 %2251, i1 false)
  %2253 = zext i8 %2252 to i32
  %2254 = select i1 %2250, i32 %2253, i32 0
  %.state2033 = load <8 x i64>, ptr %.slot55, align 64
  %2255 = icmp slt <8 x i64> %.state2033, splat (i64 192)
  %2256 = and <8 x i1> %2249, %2255
  %2257 = xor <8 x i1> %2255, splat (i1 true)
  %2258 = and <8 x i1> %2249, %2257
  %2259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2256)
  %2260 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2258)
  %2261 = and i1 %2259, %2260
  br i1 %2261, label %varying.divergent2034, label %varying.coherent2035

schedule.94:                                      ; preds = %varying.coherent.true2040, %scheduler.dispatch.route
  %2262 = load <8 x i1>, ptr %current.mask, align 1
  %2263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2262)
  %2264 = bitcast <8 x i1> %2262 to i8
  %2265 = call i8 @llvm.cttz.i8(i8 %2264, i1 false)
  %2266 = zext i8 %2265 to i32
  %2267 = select i1 %2263, i32 %2266, i32 0
  %tile_snapshot.spill.load2042 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill294, align 64
  %2268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2042, 0
  %2269 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2042, 1
  %.state2043 = load <8 x i64>, ptr %.slot55, align 64
  %2270 = mul <8 x i64> %.state2043, splat (i64 32)
  %2271 = add <8 x i64> %2269, %2270
  %2272 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2268, 0
  %2273 = insertvalue { <8 x ptr>, <8 x i64> } %2272, <8 x i64> %2271, 1
  %2274 = extractvalue { <8 x ptr>, <8 x i64> } %2273, 0
  %2275 = extractvalue { <8 x ptr>, <8 x i64> } %2273, 1
  %2276 = getelementptr i8, <8 x ptr> %2274, <8 x i64> %2275
  %2277 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2276, <8 x i1> %2262, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2044 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %2278 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2044, 0
  %2279 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2044, 1
  %.state2045 = load <8 x i64>, ptr %.slot55, align 64
  %2280 = mul <8 x i64> %.state2045, splat (i64 32)
  %2281 = add <8 x i64> %2279, %2280
  %2282 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2278, 0
  %2283 = insertvalue { <8 x ptr>, <8 x i64> } %2282, <8 x i64> %2281, 1
  %2284 = extractvalue { <8 x ptr>, <8 x i64> } %2283, 0
  %2285 = extractvalue { <8 x ptr>, <8 x i64> } %2283, 1
  %2286 = getelementptr i8, <8 x ptr> %2284, <8 x i64> %2285
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2277, <8 x ptr> align 1 %2286, <8 x i1> %2262)
  %.state2046 = load <8 x i64>, ptr %.slot55, align 64
  %2287 = add <8 x i64> %.state2046, splat (i64 1)
  %2288 = load <8 x i64>, ptr %.slot55, align 64
  %2289 = select <8 x i1> %2262, <8 x i64> %2287, <8 x i64> %2288
  store <8 x i64> %2289, ptr %.slot55, align 64
  store <8 x i1> %2262, ptr %current.mask, align 1
  %2290 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2262)
  br i1 %2290, label %schedule.93, label %scheduler.loop

schedule.95:                                      ; preds = %varying.coherent.false2041, %scheduler.dispatch.route
  %2291 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2049 = load i32, ptr %current.token, align 4
  %convergence.token.present2050 = icmp ne i32 %convergence.current.token2049, 0
  br i1 %convergence.token.present2050, label %convergence.cascade2047, label %convergence.cascade.exit2048

schedule.96:                                      ; preds = %schedule.97, %convergence.target.95.ready, %scheduler.dispatch.route
  %2292 = load <8 x i1>, ptr %current.mask, align 1
  %2293 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2292)
  %2294 = bitcast <8 x i1> %2292 to i8
  %2295 = call i8 @llvm.cttz.i8(i8 %2294, i1 false)
  %2296 = zext i8 %2295 to i32
  %2297 = select i1 %2293, i32 %2296, i32 0
  %.state2064 = load <8 x i64>, ptr %.slot55, align 64
  %2298 = icmp slt <8 x i64> %.state2064, splat (i64 192)
  %2299 = and <8 x i1> %2292, %2298
  %2300 = xor <8 x i1> %2298, splat (i1 true)
  %2301 = and <8 x i1> %2292, %2300
  %2302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2299)
  %2303 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2301)
  %2304 = and i1 %2302, %2303
  br i1 %2304, label %varying.divergent2065, label %varying.coherent2066

schedule.97:                                      ; preds = %varying.coherent.true2071, %scheduler.dispatch.route
  %2305 = load <8 x i1>, ptr %current.mask, align 1
  %2306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2305)
  %2307 = bitcast <8 x i1> %2305 to i8
  %2308 = call i8 @llvm.cttz.i8(i8 %2307, i1 false)
  %2309 = zext i8 %2308 to i32
  %2310 = select i1 %2306, i32 %2309, i32 0
  %tile_snapshot.spill.load2073 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %2311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2073, 0
  %2312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2073, 1
  %.state2074 = load <8 x i64>, ptr %.slot55, align 64
  %2313 = mul <8 x i64> %.state2074, splat (i64 32)
  %2314 = add <8 x i64> %2312, %2313
  %2315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2311, 0
  %2316 = insertvalue { <8 x ptr>, <8 x i64> } %2315, <8 x i64> %2314, 1
  %2317 = extractvalue { <8 x ptr>, <8 x i64> } %2316, 0
  %2318 = extractvalue { <8 x ptr>, <8 x i64> } %2316, 1
  %2319 = getelementptr i8, <8 x ptr> %2317, <8 x i64> %2318
  %2320 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2319, <8 x i1> %2305, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2075 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %2321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2075, 0
  %2322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2075, 1
  %.state2076 = load <8 x i64>, ptr %.slot55, align 64
  %2323 = mul <8 x i64> %.state2076, splat (i64 32)
  %2324 = add <8 x i64> %2322, %2323
  %2325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2321, 0
  %2326 = insertvalue { <8 x ptr>, <8 x i64> } %2325, <8 x i64> %2324, 1
  %2327 = extractvalue { <8 x ptr>, <8 x i64> } %2326, 0
  %2328 = extractvalue { <8 x ptr>, <8 x i64> } %2326, 1
  %2329 = getelementptr i8, <8 x ptr> %2327, <8 x i64> %2328
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2320, <8 x ptr> align 1 %2329, <8 x i1> %2305)
  %.state2077 = load <8 x i64>, ptr %.slot55, align 64
  %2330 = add <8 x i64> %.state2077, splat (i64 1)
  %2331 = load <8 x i64>, ptr %.slot55, align 64
  %2332 = select <8 x i1> %2305, <8 x i64> %2330, <8 x i64> %2331
  store <8 x i64> %2332, ptr %.slot55, align 64
  store <8 x i1> %2305, ptr %current.mask, align 1
  %2333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2305)
  br i1 %2333, label %schedule.96, label %scheduler.loop

schedule.98:                                      ; preds = %varying.coherent.false2072, %scheduler.dispatch.route
  %2334 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2080 = load i32, ptr %current.token, align 4
  %convergence.token.present2081 = icmp ne i32 %convergence.current.token2080, 0
  br i1 %convergence.token.present2081, label %convergence.cascade2078, label %convergence.cascade.exit2079

schedule.99:                                      ; preds = %varying.coherent.false451, %scheduler.dispatch.route
  %2335 = load <8 x i1>, ptr %current.mask, align 1
  %2336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2335)
  %2337 = bitcast <8 x i1> %2335 to i8
  %2338 = call i8 @llvm.cttz.i8(i8 %2337, i1 false)
  %2339 = zext i8 %2338 to i32
  %2340 = select i1 %2336, i32 %2339, i32 0
  %2341 = load <8 x i64>, ptr %.slot55, align 64
  %2342 = select <8 x i1> %2335, <8 x i64> zeroinitializer, <8 x i64> %2341
  store <8 x i64> %2342, ptr %.slot55, align 64
  store <8 x i1> %2335, ptr %current.mask, align 1
  %2343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2335)
  br i1 %2343, label %schedule.100, label %scheduler.loop

schedule.100:                                     ; preds = %convergence.target.103.ready, %schedule.99, %scheduler.dispatch.route
  %2344 = load <8 x i1>, ptr %current.mask, align 1
  %2345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2344)
  %2346 = bitcast <8 x i1> %2344 to i8
  %2347 = call i8 @llvm.cttz.i8(i8 %2346, i1 false)
  %2348 = zext i8 %2347 to i32
  %2349 = select i1 %2345, i32 %2348, i32 0
  %.state2104 = load <8 x i64>, ptr %.slot55, align 64
  %2350 = icmp slt <8 x i64> %.state2104, splat (i64 768)
  %2351 = and <8 x i1> %2344, %2350
  %2352 = xor <8 x i1> %2350, splat (i1 true)
  %2353 = and <8 x i1> %2344, %2352
  %2354 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2351)
  %2355 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2353)
  %2356 = and i1 %2354, %2355
  br i1 %2356, label %varying.divergent2105, label %varying.coherent2106

schedule.101:                                     ; preds = %varying.coherent.true2111, %scheduler.dispatch.route
  %2357 = load <8 x i1>, ptr %current.mask, align 1
  %2358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2357)
  %2359 = bitcast <8 x i1> %2357 to i8
  %2360 = call i8 @llvm.cttz.i8(i8 %2359, i1 false)
  %2361 = zext i8 %2360 to i32
  %2362 = select i1 %2358, i32 %2361, i32 0
  %.state2113 = load <8 x i64>, ptr %.slot55, align 64
  %2363 = select <8 x i1> %2357, <8 x i64> %.state2113, <8 x i64> zeroinitializer
  %2364 = select <8 x i1> %2357, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2365 = srem <8 x i64> %2363, %2364
  %.state2114 = load <8 x i64>, ptr %.slot55, align 64
  %2366 = select <8 x i1> %2357, <8 x i64> %.state2114, <8 x i64> zeroinitializer
  %2367 = select <8 x i1> %2357, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2368 = sdiv <8 x i64> %2366, %2367
  %.spill.load2115 = load <8 x i64>, ptr %.spill, align 64
  %2369 = add <8 x i64> %.spill.load2115, zeroinitializer
  %2370 = add <8 x i64> zeroinitializer, %2369
  %.spill.load2116 = load <8 x i64>, ptr %.spill39, align 64
  %2371 = add <8 x i64> %.spill.load2116, zeroinitializer
  %2372 = mul <8 x i64> %2370, splat (i64 2)
  %2373 = add <8 x i64> %2372, %2371
  %.spill.load2117 = load <8 x i64>, ptr %.spill51, align 64
  %2374 = add <8 x i64> %.spill.load2117, %2368
  %2375 = mul <8 x i64> %2373, splat (i64 67)
  %2376 = add <8 x i64> %2375, %2374
  %2377 = icmp sge <8 x i64> %2374, zeroinitializer
  %2378 = and <8 x i1> splat (i1 true), %2377
  %2379 = icmp slt <8 x i64> %2374, splat (i64 67)
  %2380 = and <8 x i1> %2378, %2379
  %2381 = add <8 x i64> zeroinitializer, %2365
  %2382 = mul <8 x i64> %2376, splat (i64 48)
  %2383 = add <8 x i64> %2382, %2381
  %2384 = load <8 x i64>, ptr %.spill314, align 64
  %2385 = select <8 x i1> %2357, <8 x i64> %2383, <8 x i64> %2384
  store <8 x i64> %2385, ptr %.spill314, align 64
  %2386 = and <8 x i1> %2357, %2380
  %2387 = xor <8 x i1> %2380, splat (i1 true)
  %2388 = and <8 x i1> %2357, %2387
  %2389 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2386)
  %2390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2388)
  %2391 = and i1 %2389, %2390
  br i1 %2391, label %varying.divergent2118, label %varying.coherent2119

schedule.102:                                     ; preds = %varying.coherent.true2124, %scheduler.dispatch.route
  %2392 = load <8 x i1>, ptr %current.mask, align 1
  %2393 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2392)
  %2394 = bitcast <8 x i1> %2392 to i8
  %2395 = call i8 @llvm.cttz.i8(i8 %2394, i1 false)
  %2396 = zext i8 %2395 to i32
  %2397 = select i1 %2393, i32 %2396, i32 0
  %.spill.load2126 = load <8 x i64>, ptr %.spill314, align 64
  %2398 = extractvalue { ptr, i64 } %47, 0
  %2399 = mul <8 x i64> %.spill.load2126, splat (i64 4)
  %2400 = getelementptr i8, ptr %2398, <8 x i64> %2399
  %2401 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2400, <8 x i1> %2392, <8 x float> zeroinitializer)
  %2402 = load <8 x float>, ptr %.slot56, align 32
  %2403 = select <8 x i1> %2392, <8 x float> %2401, <8 x float> %2402
  store <8 x float> %2403, ptr %.slot56, align 32
  store <8 x i1> %2392, ptr %current.mask, align 1
  %2404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2392)
  br i1 %2404, label %schedule.103, label %scheduler.loop

schedule.103:                                     ; preds = %schedule.102, %varying.coherent.false2125, %scheduler.dispatch.route
  %2405 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2129 = load i32, ptr %current.token, align 4
  %convergence.token.present2130 = icmp ne i32 %convergence.current.token2129, 0
  br i1 %convergence.token.present2130, label %convergence.cascade2127, label %convergence.cascade.exit2128

schedule.104:                                     ; preds = %varying.coherent.false405, %scheduler.dispatch.route
  %2406 = load <8 x i1>, ptr %current.mask, align 1
  %2407 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2406)
  %2408 = bitcast <8 x i1> %2406 to i8
  %2409 = call i8 @llvm.cttz.i8(i8 %2408, i1 false)
  %2410 = zext i8 %2409 to i32
  %2411 = select i1 %2407, i32 %2410, i32 0
  %2412 = load <8 x i64>, ptr %.slot55, align 64
  %2413 = select <8 x i1> %2406, <8 x i64> zeroinitializer, <8 x i64> %2412
  store <8 x i64> %2413, ptr %.slot55, align 64
  store <8 x i1> %2406, ptr %current.mask, align 1
  %2414 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2406)
  br i1 %2414, label %schedule.105, label %scheduler.loop

schedule.105:                                     ; preds = %convergence.target.108.ready, %schedule.104, %scheduler.dispatch.route
  %2415 = load <8 x i1>, ptr %current.mask, align 1
  %2416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2415)
  %2417 = bitcast <8 x i1> %2415 to i8
  %2418 = call i8 @llvm.cttz.i8(i8 %2417, i1 false)
  %2419 = zext i8 %2418 to i32
  %2420 = select i1 %2416, i32 %2419, i32 0
  %.state2148 = load <8 x i64>, ptr %.slot55, align 64
  %2421 = icmp slt <8 x i64> %.state2148, splat (i64 640)
  %2422 = and <8 x i1> %2415, %2421
  %2423 = xor <8 x i1> %2421, splat (i1 true)
  %2424 = and <8 x i1> %2415, %2423
  %2425 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2422)
  %2426 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2424)
  %2427 = and i1 %2425, %2426
  br i1 %2427, label %varying.divergent2149, label %varying.coherent2150

schedule.106:                                     ; preds = %varying.coherent.true2155, %scheduler.dispatch.route
  %2428 = load <8 x i1>, ptr %current.mask, align 1
  %2429 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2428)
  %2430 = bitcast <8 x i1> %2428 to i8
  %2431 = call i8 @llvm.cttz.i8(i8 %2430, i1 false)
  %2432 = zext i8 %2431 to i32
  %2433 = select i1 %2429, i32 %2432, i32 0
  %.state2157 = load <8 x i64>, ptr %.slot55, align 64
  %2434 = select <8 x i1> %2428, <8 x i64> %.state2157, <8 x i64> zeroinitializer
  %2435 = select <8 x i1> %2428, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %2436 = srem <8 x i64> %2434, %2435
  %.state2158 = load <8 x i64>, ptr %.slot55, align 64
  %2437 = select <8 x i1> %2428, <8 x i64> %.state2158, <8 x i64> zeroinitializer
  %2438 = select <8 x i1> %2428, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %2439 = sdiv <8 x i64> %2437, %2438
  %.spill.load2159 = load <8 x i64>, ptr %.spill, align 64
  %2440 = add <8 x i64> %.spill.load2159, zeroinitializer
  %2441 = add <8 x i64> zeroinitializer, %2440
  %.spill.load2160 = load <8 x i64>, ptr %.spill39, align 64
  %2442 = add <8 x i64> %.spill.load2160, zeroinitializer
  %2443 = mul <8 x i64> %2441, splat (i64 2)
  %2444 = add <8 x i64> %2443, %2442
  %.spill.load2161 = load <8 x i64>, ptr %.spill51, align 64
  %2445 = add <8 x i64> %.spill.load2161, %2439
  %2446 = mul <8 x i64> %2444, splat (i64 67)
  %2447 = add <8 x i64> %2446, %2445
  %2448 = icmp sge <8 x i64> %2445, zeroinitializer
  %2449 = and <8 x i1> splat (i1 true), %2448
  %2450 = icmp slt <8 x i64> %2445, splat (i64 67)
  %2451 = and <8 x i1> %2449, %2450
  %2452 = add <8 x i64> zeroinitializer, %2436
  %2453 = mul <8 x i64> %2447, splat (i64 40)
  %2454 = add <8 x i64> %2453, %2452
  %2455 = load <8 x i64>, ptr %.spill317, align 64
  %2456 = select <8 x i1> %2428, <8 x i64> %2454, <8 x i64> %2455
  store <8 x i64> %2456, ptr %.spill317, align 64
  %2457 = and <8 x i1> %2428, %2451
  %2458 = xor <8 x i1> %2451, splat (i1 true)
  %2459 = and <8 x i1> %2428, %2458
  %2460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2457)
  %2461 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2459)
  %2462 = and i1 %2460, %2461
  br i1 %2462, label %varying.divergent2162, label %varying.coherent2163

schedule.107:                                     ; preds = %varying.coherent.true2168, %scheduler.dispatch.route
  %2463 = load <8 x i1>, ptr %current.mask, align 1
  %2464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2463)
  %2465 = bitcast <8 x i1> %2463 to i8
  %2466 = call i8 @llvm.cttz.i8(i8 %2465, i1 false)
  %2467 = zext i8 %2466 to i32
  %2468 = select i1 %2464, i32 %2467, i32 0
  %.spill.load2170 = load <8 x i64>, ptr %.spill317, align 64
  %2469 = extractvalue { ptr, i64 } %41, 0
  %2470 = mul <8 x i64> %.spill.load2170, splat (i64 4)
  %2471 = getelementptr i8, ptr %2469, <8 x i64> %2470
  %2472 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2471, <8 x i1> %2463, <8 x float> zeroinitializer)
  %2473 = load <8 x float>, ptr %.slot56, align 32
  %2474 = select <8 x i1> %2463, <8 x float> %2472, <8 x float> %2473
  store <8 x float> %2474, ptr %.slot56, align 32
  store <8 x i1> %2463, ptr %current.mask, align 1
  %2475 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2463)
  br i1 %2475, label %schedule.108, label %scheduler.loop

schedule.108:                                     ; preds = %schedule.107, %varying.coherent.false2169, %scheduler.dispatch.route
  %2476 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2173 = load i32, ptr %current.token, align 4
  %convergence.token.present2174 = icmp ne i32 %convergence.current.token2173, 0
  br i1 %convergence.token.present2174, label %convergence.cascade2171, label %convergence.cascade.exit2172

schedule.109:                                     ; preds = %varying.coherent.false396, %scheduler.dispatch.route
  %2477 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2194 = load i32, ptr %current.token, align 4
  %convergence.token.present2195 = icmp ne i32 %convergence.current.token2194, 0
  br i1 %convergence.token.present2195, label %convergence.cascade2192, label %convergence.cascade.exit2193

schedule.110:                                     ; preds = %convergence.target.113.ready, %convergence.target.109.ready, %scheduler.dispatch.route
  %2478 = load <8 x i1>, ptr %current.mask, align 1
  %2479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2478)
  %2480 = bitcast <8 x i1> %2478 to i8
  %2481 = call i8 @llvm.cttz.i8(i8 %2480, i1 false)
  %2482 = zext i8 %2481 to i32
  %2483 = select i1 %2479, i32 %2482, i32 0
  %.state2221 = load <8 x i64>, ptr %.slot, align 64
  %2484 = icmp slt <8 x i64> %.state2221, splat (i64 192)
  %2485 = and <8 x i1> %2478, %2484
  %2486 = xor <8 x i1> %2484, splat (i1 true)
  %2487 = and <8 x i1> %2478, %2486
  %2488 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2485)
  %2489 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2487)
  %2490 = and i1 %2488, %2489
  br i1 %2490, label %varying.divergent2222, label %varying.coherent2223

schedule.111:                                     ; preds = %varying.coherent.true2228, %scheduler.dispatch.route
  %2491 = load <8 x i1>, ptr %current.mask, align 1
  %2492 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2491)
  %2493 = bitcast <8 x i1> %2491 to i8
  %2494 = call i8 @llvm.cttz.i8(i8 %2493, i1 false)
  %2495 = zext i8 %2494 to i32
  %2496 = select i1 %2492, i32 %2495, i32 0
  %.state2230 = load <8 x i64>, ptr %.slot, align 64
  %2497 = select <8 x i1> %2491, <8 x i64> %.state2230, <8 x i64> zeroinitializer
  %2498 = select <8 x i1> %2491, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2499 = srem <8 x i64> %2497, %2498
  %.state2231 = load <8 x i64>, ptr %.slot, align 64
  %2500 = select <8 x i1> %2491, <8 x i64> %.state2231, <8 x i64> zeroinitializer
  %2501 = select <8 x i1> %2491, <8 x i64> splat (i64 48), <8 x i64> splat (i64 1)
  %2502 = sdiv <8 x i64> %2500, %2501
  %.spill.load2232 = load <8 x i64>, ptr %.spill, align 64
  %2503 = add <8 x i64> %.spill.load2232, zeroinitializer
  %2504 = add <8 x i64> zeroinitializer, %2503
  %.spill.load2233 = load <8 x i64>, ptr %.spill37, align 64
  %2505 = add <8 x i64> %.spill.load2233, zeroinitializer
  %2506 = mul <8 x i64> %2504, splat (i64 6)
  %2507 = add <8 x i64> %2506, %2505
  %.spill.load2234 = load <8 x i64>, ptr %.spill38, align 64
  %2508 = add <8 x i64> %.spill.load2234, %2502
  %2509 = mul <8 x i64> %2507, splat (i64 17)
  %2510 = add <8 x i64> %2509, %2508
  %2511 = icmp sge <8 x i64> %2508, zeroinitializer
  %2512 = and <8 x i1> splat (i1 true), %2511
  %2513 = icmp slt <8 x i64> %2508, splat (i64 17)
  %2514 = and <8 x i1> %2512, %2513
  %2515 = add <8 x i64> zeroinitializer, %2499
  %2516 = mul <8 x i64> %2510, splat (i64 48)
  %2517 = add <8 x i64> %2516, %2515
  %2518 = load <8 x i64>, ptr %.spill321, align 64
  %2519 = select <8 x i1> %2491, <8 x i64> %2517, <8 x i64> %2518
  store <8 x i64> %2519, ptr %.spill321, align 64
  %2520 = add <8 x i64> zeroinitializer, %2502
  %2521 = mul <8 x i64> %2520, splat (i64 48)
  %2522 = add <8 x i64> %2521, %2499
  %tile_snapshot.spill.load2235 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %2523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2235, 0
  %2524 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2235, 1
  %2525 = mul <8 x i64> %2522, splat (i64 32)
  %2526 = add <8 x i64> %2524, %2525
  %2527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2523, 0
  %2528 = insertvalue { <8 x ptr>, <8 x i64> } %2527, <8 x i64> %2526, 1
  %2529 = extractvalue { <8 x ptr>, <8 x i64> } %2528, 0
  %2530 = extractvalue { <8 x ptr>, <8 x i64> } %2528, 1
  %2531 = getelementptr i8, <8 x ptr> %2529, <8 x i64> %2530
  %2532 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2531, <8 x i1> %2491, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load2236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill319, align 64
  %2533 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2236, 0
  %2534 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2236, 1
  %2535 = mul <8 x i64> %2520, splat (i64 32)
  %2536 = add <8 x i64> %2534, %2535
  %2537 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2533, 0
  %2538 = insertvalue { <8 x ptr>, <8 x i64> } %2537, <8 x i64> %2536, 1
  %2539 = extractvalue { <8 x ptr>, <8 x i64> } %2538, 0
  %2540 = extractvalue { <8 x ptr>, <8 x i64> } %2538, 1
  %2541 = getelementptr i8, <8 x ptr> %2539, <8 x i64> %2540
  %2542 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2541, <8 x i1> %2491, <8 x float> zeroinitializer)
  %2543 = fdiv <8 x float> %2532, %2542
  %2544 = load <8 x float>, ptr %.spill322, align 32
  %2545 = select <8 x i1> %2491, <8 x float> %2543, <8 x float> %2544
  store <8 x float> %2545, ptr %.spill322, align 32
  %2546 = and <8 x i1> %2491, %2514
  %2547 = xor <8 x i1> %2514, splat (i1 true)
  %2548 = and <8 x i1> %2491, %2547
  %2549 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2546)
  %2550 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2548)
  %2551 = and i1 %2549, %2550
  br i1 %2551, label %varying.divergent2237, label %varying.coherent2238

schedule.112:                                     ; preds = %varying.coherent.true2243, %scheduler.dispatch.route
  %2552 = load <8 x i1>, ptr %current.mask, align 1
  %2553 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2552)
  %2554 = bitcast <8 x i1> %2552 to i8
  %2555 = call i8 @llvm.cttz.i8(i8 %2554, i1 false)
  %2556 = zext i8 %2555 to i32
  %2557 = select i1 %2553, i32 %2556, i32 0
  %.spill.load2245 = load <8 x i64>, ptr %.spill321, align 64
  %.spill.load2246 = load <8 x float>, ptr %.spill322, align 32
  %2558 = extractvalue { ptr, i64 } %53, 0
  %2559 = mul <8 x i64> %.spill.load2245, splat (i64 4)
  %2560 = getelementptr i8, ptr %2558, <8 x i64> %2559
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load2246, <8 x ptr> align 1 %2560, <8 x i1> %2552)
  store <8 x i1> %2552, ptr %current.mask, align 1
  %2561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2552)
  br i1 %2561, label %schedule.113, label %scheduler.loop

schedule.113:                                     ; preds = %schedule.112, %varying.coherent.false2244, %scheduler.dispatch.route
  %2562 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2249 = load i32, ptr %current.token, align 4
  %convergence.token.present2250 = icmp ne i32 %convergence.current.token2249, 0
  br i1 %convergence.token.present2250, label %convergence.cascade2247, label %convergence.cascade.exit2248

schedule.114:                                     ; preds = %varying.coherent.false2229, %scheduler.dispatch.route
  %2563 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2267 = load i32, ptr %current.token, align 4
  %convergence.token.present2268 = icmp ne i32 %convergence.current.token2267, 0
  br i1 %convergence.token.present2268, label %convergence.cascade2265, label %convergence.cascade.exit2266

schedule.115:                                     ; preds = %varying.coherent.false, %scheduler.dispatch.route
  %2564 = load <8 x i1>, ptr %current.mask, align 1
  %2565 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2564)
  %2566 = bitcast <8 x i1> %2564 to i8
  %2567 = call i8 @llvm.cttz.i8(i8 %2566, i1 false)
  %2568 = zext i8 %2567 to i32
  %2569 = select i1 %2565, i32 %2568, i32 0
  %2570 = load <8 x i64>, ptr %.slot, align 64
  %2571 = select <8 x i1> %2564, <8 x i64> zeroinitializer, <8 x i64> %2570
  store <8 x i64> %2571, ptr %.slot, align 64
  store <8 x i1> %2564, ptr %current.mask, align 1
  %2572 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2564)
  br i1 %2572, label %schedule.116, label %scheduler.loop

schedule.116:                                     ; preds = %convergence.target.119.ready, %schedule.115, %scheduler.dispatch.route
  %2573 = load <8 x i1>, ptr %current.mask, align 1
  %2574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2573)
  %2575 = bitcast <8 x i1> %2573 to i8
  %2576 = call i8 @llvm.cttz.i8(i8 %2575, i1 false)
  %2577 = zext i8 %2576 to i32
  %2578 = select i1 %2574, i32 %2577, i32 0
  %.state2330 = load <8 x i64>, ptr %.slot, align 64
  %2579 = icmp slt <8 x i64> %.state2330, splat (i64 160)
  %2580 = and <8 x i1> %2573, %2579
  %2581 = xor <8 x i1> %2579, splat (i1 true)
  %2582 = and <8 x i1> %2573, %2581
  %2583 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2580)
  %2584 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2582)
  %2585 = and i1 %2583, %2584
  br i1 %2585, label %varying.divergent2331, label %varying.coherent2332

schedule.117:                                     ; preds = %varying.coherent.true2337, %scheduler.dispatch.route
  %2586 = load <8 x i1>, ptr %current.mask, align 1
  %2587 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2586)
  %2588 = bitcast <8 x i1> %2586 to i8
  %2589 = call i8 @llvm.cttz.i8(i8 %2588, i1 false)
  %2590 = zext i8 %2589 to i32
  %2591 = select i1 %2587, i32 %2590, i32 0
  %.state2339 = load <8 x i64>, ptr %.slot, align 64
  %2592 = select <8 x i1> %2586, <8 x i64> %.state2339, <8 x i64> zeroinitializer
  %2593 = select <8 x i1> %2586, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %2594 = srem <8 x i64> %2592, %2593
  %.state2340 = load <8 x i64>, ptr %.slot, align 64
  %2595 = select <8 x i1> %2586, <8 x i64> %.state2340, <8 x i64> zeroinitializer
  %2596 = select <8 x i1> %2586, <8 x i64> splat (i64 40), <8 x i64> splat (i64 1)
  %2597 = sdiv <8 x i64> %2595, %2596
  %.spill.load2341 = load <8 x i64>, ptr %.spill, align 64
  %2598 = add <8 x i64> %.spill.load2341, zeroinitializer
  %2599 = add <8 x i64> zeroinitializer, %2598
  %.spill.load2342 = load <8 x i64>, ptr %.spill37, align 64
  %2600 = add <8 x i64> %.spill.load2342, zeroinitializer
  %2601 = mul <8 x i64> %2599, splat (i64 6)
  %2602 = add <8 x i64> %2601, %2600
  %.spill.load2343 = load <8 x i64>, ptr %.spill38, align 64
  %2603 = add <8 x i64> %.spill.load2343, %2597
  %2604 = mul <8 x i64> %2602, splat (i64 17)
  %2605 = add <8 x i64> %2604, %2603
  %2606 = icmp sge <8 x i64> %2603, zeroinitializer
  %2607 = and <8 x i1> splat (i1 true), %2606
  %2608 = icmp slt <8 x i64> %2603, splat (i64 17)
  %2609 = and <8 x i1> %2607, %2608
  %2610 = add <8 x i64> zeroinitializer, %2594
  %2611 = mul <8 x i64> %2605, splat (i64 40)
  %2612 = add <8 x i64> %2611, %2610
  %2613 = load <8 x i64>, ptr %.spill324, align 64
  %2614 = select <8 x i1> %2586, <8 x i64> %2612, <8 x i64> %2613
  store <8 x i64> %2614, ptr %.spill324, align 64
  %2615 = and <8 x i1> %2586, %2609
  %2616 = xor <8 x i1> %2609, splat (i1 true)
  %2617 = and <8 x i1> %2586, %2616
  %2618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2615)
  %2619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2617)
  %2620 = and i1 %2618, %2619
  br i1 %2620, label %varying.divergent2344, label %varying.coherent2345

schedule.118:                                     ; preds = %varying.coherent.true2350, %scheduler.dispatch.route
  %2621 = load <8 x i1>, ptr %current.mask, align 1
  %2622 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2621)
  %2623 = bitcast <8 x i1> %2621 to i8
  %2624 = call i8 @llvm.cttz.i8(i8 %2623, i1 false)
  %2625 = zext i8 %2624 to i32
  %2626 = select i1 %2622, i32 %2625, i32 0
  %.spill.load2352 = load <8 x i64>, ptr %.spill324, align 64
  %2627 = extractvalue { ptr, i64 } %35, 0
  %2628 = mul <8 x i64> %.spill.load2352, splat (i64 4)
  %2629 = getelementptr i8, ptr %2627, <8 x i64> %2628
  %2630 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2629, <8 x i1> %2621, <8 x float> zeroinitializer)
  %2631 = load <8 x float>, ptr %.slot43, align 32
  %2632 = select <8 x i1> %2621, <8 x float> %2630, <8 x float> %2631
  store <8 x float> %2632, ptr %.slot43, align 32
  store <8 x i1> %2621, ptr %current.mask, align 1
  %2633 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2621)
  br i1 %2633, label %schedule.119, label %scheduler.loop

schedule.119:                                     ; preds = %schedule.118, %varying.coherent.false2351, %scheduler.dispatch.route
  %2634 = load <8 x i1>, ptr %current.mask, align 1
  %convergence.current.token2355 = load i32, ptr %current.token, align 4
  %convergence.token.present2356 = icmp ne i32 %convergence.current.token2355, 0
  br i1 %convergence.token.present2356, label %convergence.cascade2353, label %convergence.cascade.exit2354

varying.divergent:                                ; preds = %schedule.0
  %2635 = load i32, ptr %current.token, align 4
  %2636 = icmp ne i32 %2635, 0
  %2637 = sub i32 %2635, 1
  %2638 = select i1 %2636, i32 %2637, i32 0
  %2639 = load i8, ptr %frame.active, align 1
  %2640 = trunc i32 %2638 to i8
  %2641 = shl i8 1, %2640
  %2642 = and i8 %2639, %2641
  %2643 = icmp ne i8 %2642, 0
  %2644 = load <8 x i32>, ptr %frame.static.id, align 32
  %2645 = extractelement <8 x i32> %2644, i32 %2638
  %2646 = icmp eq i32 %2645, 0
  %2647 = and i1 %2643, %2646
  %2648 = and i1 %2636, %2647
  %2649 = xor i1 %2648, true
  %2650 = and i1 true, %2649
  %2651 = xor i8 %2639, -1
  %2652 = icmp ne i8 %2651, 0
  %2653 = xor i1 %2652, true
  %2654 = and i1 %2650, %2653
  br i1 %2654, label %convergence.overflow.trap, label %convergence.overflow.resume

varying.coherent:                                 ; preds = %schedule.0
  br i1 %162, label %varying.coherent.true, label %varying.coherent.false

convergence.overflow.trap:                        ; preds = %varying.divergent
  call void @llvm.trap()
  unreachable

convergence.overflow.resume:                      ; preds = %varying.divergent
  %2655 = call i8 @llvm.cttz.i8(i8 %2651, i1 false)
  %2656 = zext i8 %2655 to i32
  %2657 = select i1 %2652, i32 %2656, i32 0
  %2658 = trunc i32 %2657 to i8
  %2659 = shl i8 1, %2658
  %2660 = or i8 %2639, %2659
  %2661 = select i1 %2650, i8 %2660, i8 %2639
  store i8 %2661, ptr %frame.active, align 1
  %2662 = load <8 x i32>, ptr %frame.static.id, align 32
  %2663 = extractelement <8 x i32> %2662, i32 %2657
  %2664 = select i1 %2650, i32 0, i32 %2663
  %2665 = load <8 x i32>, ptr %frame.static.id, align 32
  %2666 = insertelement <8 x i32> %2665, i32 %2664, i32 %2657
  store <8 x i32> %2666, ptr %frame.static.id, align 32
  %2667 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2668 = extractelement <8 x i32> %2667, i32 %2657
  %2669 = select i1 %2650, i32 %2635, i32 %2668
  %2670 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2671 = insertelement <8 x i32> %2670, i32 %2669, i32 %2657
  store <8 x i32> %2671, ptr %frame.parent.token, align 32
  %2672 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2657
  %2673 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2657
  %2674 = load <8 x i1>, ptr %2672, align 1
  %2675 = load <8 x i1>, ptr %2673, align 1
  %2676 = select i1 %2650, <8 x i1> %111, <8 x i1> %2674
  store <8 x i1> %2676, ptr %2672, align 1
  %2677 = select i1 %2650, <8 x i1> zeroinitializer, <8 x i1> %2675
  store <8 x i1> %2677, ptr %2673, align 1
  %2678 = add i32 %2657, 1
  %2679 = select i1 %2648, i32 %2635, i32 %2678
  %2680 = select i1 true, i32 %2679, i32 %2635
  store i32 %2680, ptr %current.token, align 4
  %2681 = load i32, ptr %current.token, align 4
  %2682 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %159)
  %2683 = load i32, ptr %ready.count, align 4
  %2684 = icmp uge i32 %2683, 8
  %2685 = and i1 %2682, %2684
  br i1 %2685, label %ready.overflow.trap336, label %ready.overflow.resume337

ready.overflow.trap336:                           ; preds = %convergence.overflow.resume
  call void @llvm.trap()
  unreachable

ready.overflow.resume337:                         ; preds = %convergence.overflow.resume
  %2686 = select i1 %2682, i32 %2683, i32 0
  %2687 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2686
  %2688 = load <8 x i1>, ptr %2687, align 1
  %2689 = select i1 %2682, <8 x i1> %159, <8 x i1> %2688
  store <8 x i1> %2689, ptr %2687, align 1
  %2690 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2686
  %2691 = load i32, ptr %2690, align 4
  %2692 = select i1 %2682, i32 1, i32 %2691
  store i32 %2692, ptr %2690, align 4
  %2693 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2686
  %2694 = load i32, ptr %2693, align 4
  %2695 = select i1 %2682, i32 %2681, i32 %2694
  store i32 %2695, ptr %2693, align 4
  %2696 = add i32 %2683, 1
  %2697 = select i1 %2682, i32 %2696, i32 %2683
  store i32 %2697, ptr %ready.count, align 4
  %2698 = load <8 x i1>, ptr %runnable.mask, align 1
  %2699 = or <8 x i1> %2698, %159
  store <8 x i1> %2699, ptr %runnable.mask, align 1
  store <8 x i1> %161, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true:                            ; preds = %varying.coherent
  store <8 x i1> %111, ptr %current.mask, align 1
  %2700 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  br i1 %2700, label %schedule.1, label %scheduler.loop

varying.coherent.false:                           ; preds = %varying.coherent
  store <8 x i1> %111, ptr %current.mask, align 1
  %2701 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  br i1 %2701, label %schedule.115, label %scheduler.loop

copy.active:                                      ; preds = %schedule.1
  %2702 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2703 = extractelement <8 x ptr> %2702, i64 0
  %2704 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %2705 = extractelement <8 x i64> %2704, i64 0
  %2706 = getelementptr i8, ptr %2703, i64 %2705
  %2707 = extractelement <8 x i64> %177, i64 0
  call void @llm_attention.contiguous_copy(ptr %178, i64 %2707, ptr %2706)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active, %schedule.1
  %2708 = extractelement <8 x i1> %165, i64 1
  br i1 %2708, label %copy.active340, label %copy.continue341

copy.active340:                                   ; preds = %copy.continue
  %2709 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2710 = extractelement <8 x ptr> %2709, i64 1
  %2711 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %2712 = extractelement <8 x i64> %2711, i64 1
  %2713 = getelementptr i8, ptr %2710, i64 %2712
  %2714 = extractelement <8 x i64> %177, i64 1
  call void @llm_attention.contiguous_copy(ptr %178, i64 %2714, ptr %2713)
  br label %copy.continue341

copy.continue341:                                 ; preds = %copy.active340, %copy.continue
  %2715 = extractelement <8 x i1> %165, i64 2
  br i1 %2715, label %copy.active342, label %copy.continue343

copy.active342:                                   ; preds = %copy.continue341
  %2716 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2717 = extractelement <8 x ptr> %2716, i64 2
  %2718 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %2719 = extractelement <8 x i64> %2718, i64 2
  %2720 = getelementptr i8, ptr %2717, i64 %2719
  %2721 = extractelement <8 x i64> %177, i64 2
  call void @llm_attention.contiguous_copy(ptr %178, i64 %2721, ptr %2720)
  br label %copy.continue343

copy.continue343:                                 ; preds = %copy.active342, %copy.continue341
  %2722 = extractelement <8 x i1> %165, i64 3
  br i1 %2722, label %copy.active344, label %copy.continue345

copy.active344:                                   ; preds = %copy.continue343
  %2723 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2724 = extractelement <8 x ptr> %2723, i64 3
  %2725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %2726 = extractelement <8 x i64> %2725, i64 3
  %2727 = getelementptr i8, ptr %2724, i64 %2726
  %2728 = extractelement <8 x i64> %177, i64 3
  call void @llm_attention.contiguous_copy(ptr %178, i64 %2728, ptr %2727)
  br label %copy.continue345

copy.continue345:                                 ; preds = %copy.active344, %copy.continue343
  %2729 = extractelement <8 x i1> %165, i64 4
  br i1 %2729, label %copy.active346, label %copy.continue347

copy.active346:                                   ; preds = %copy.continue345
  %2730 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2731 = extractelement <8 x ptr> %2730, i64 4
  %2732 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %2733 = extractelement <8 x i64> %2732, i64 4
  %2734 = getelementptr i8, ptr %2731, i64 %2733
  %2735 = extractelement <8 x i64> %177, i64 4
  call void @llm_attention.contiguous_copy(ptr %178, i64 %2735, ptr %2734)
  br label %copy.continue347

copy.continue347:                                 ; preds = %copy.active346, %copy.continue345
  %2736 = extractelement <8 x i1> %165, i64 5
  br i1 %2736, label %copy.active348, label %copy.continue349

copy.active348:                                   ; preds = %copy.continue347
  %2737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2738 = extractelement <8 x ptr> %2737, i64 5
  %2739 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %2740 = extractelement <8 x i64> %2739, i64 5
  %2741 = getelementptr i8, ptr %2738, i64 %2740
  %2742 = extractelement <8 x i64> %177, i64 5
  call void @llm_attention.contiguous_copy(ptr %178, i64 %2742, ptr %2741)
  br label %copy.continue349

copy.continue349:                                 ; preds = %copy.active348, %copy.continue347
  %2743 = extractelement <8 x i1> %165, i64 6
  br i1 %2743, label %copy.active350, label %copy.continue351

copy.active350:                                   ; preds = %copy.continue349
  %2744 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2745 = extractelement <8 x ptr> %2744, i64 6
  %2746 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %2747 = extractelement <8 x i64> %2746, i64 6
  %2748 = getelementptr i8, ptr %2745, i64 %2747
  %2749 = extractelement <8 x i64> %177, i64 6
  call void @llm_attention.contiguous_copy(ptr %178, i64 %2749, ptr %2748)
  br label %copy.continue351

copy.continue351:                                 ; preds = %copy.active350, %copy.continue349
  %2750 = extractelement <8 x i1> %165, i64 7
  br i1 %2750, label %copy.active352, label %copy.continue353

copy.active352:                                   ; preds = %copy.continue351
  %2751 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %2752 = extractelement <8 x ptr> %2751, i64 7
  %2753 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %2754 = extractelement <8 x i64> %2753, i64 7
  %2755 = getelementptr i8, ptr %2752, i64 %2754
  %2756 = extractelement <8 x i64> %177, i64 7
  call void @llm_attention.contiguous_copy(ptr %178, i64 %2756, ptr %2755)
  br label %copy.continue353

copy.continue353:                                 ; preds = %copy.active352, %copy.continue351
  store <8 x i1> %165, ptr %current.mask, align 1
  %2757 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %165)
  br i1 %2757, label %schedule.2, label %scheduler.loop

convergence.cascade:                              ; preds = %convergence.cascade, %schedule.2
  %convergence.cascade.flow = phi <8 x i1> [ %180, %schedule.2 ], [ %2800, %convergence.cascade ]
  %convergence.cascade.depth = phi i32 [ 0, %schedule.2 ], [ %2801, %convergence.cascade ]
  %2758 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow)
  %2759 = load i32, ptr %current.token, align 4
  %2760 = icmp ne i32 %2759, 0
  %2761 = and i1 %2758, %2760
  %2762 = sub i32 %2759, 1
  %2763 = select i1 %2761, i32 %2762, i32 0
  %2764 = load i8, ptr %frame.active, align 1
  %2765 = trunc i32 %2763 to i8
  %2766 = shl i8 1, %2765
  %2767 = and i8 %2764, %2766
  %2768 = icmp ne i8 %2767, 0
  %2769 = load <8 x i32>, ptr %frame.static.id, align 32
  %2770 = extractelement <8 x i32> %2769, i32 %2763
  %convergence.target.pointer = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %2770
  %convergence.dynamic.target = load i32, ptr %convergence.target.pointer, align 4
  %2771 = icmp eq i32 %convergence.dynamic.target, 2
  %2772 = and i1 %2768, %2771
  %2773 = and i1 %2761, %2772
  %2774 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2763
  %2775 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2763
  %2776 = load <8 x i1>, ptr %2774, align 1
  %2777 = load <8 x i1>, ptr %2775, align 1
  %2778 = or <8 x i1> %2777, %convergence.cascade.flow
  %2779 = load <8 x i1>, ptr %live.mask, align 1
  %2780 = and <8 x i1> %2776, %2779
  %2781 = icmp eq <8 x i1> %2778, %2780
  %2782 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2781)
  %2783 = and i1 %2773, %2782
  %2784 = select i1 %2783, <8 x i1> zeroinitializer, <8 x i1> %2778
  %2785 = select i1 %2773, <8 x i1> %2784, <8 x i1> %2777
  store <8 x i1> %2785, ptr %2775, align 1
  %2786 = select i1 %2783, <8 x i1> zeroinitializer, <8 x i1> %2776
  store <8 x i1> %2786, ptr %2774, align 1
  %2787 = trunc i32 %2763 to i8
  %2788 = shl i8 1, %2787
  %2789 = xor i8 %2788, -1
  %2790 = and i8 %2764, %2789
  %2791 = select i1 %2783, i8 %2790, i8 %2764
  store i8 %2791, ptr %frame.active, align 1
  %.splatinsert354 = insertelement <8 x i1> poison, i1 %2773, i64 0
  %.splat355 = shufflevector <8 x i1> %.splatinsert354, <8 x i1> poison, <8 x i32> zeroinitializer
  %2792 = and <8 x i1> %convergence.cascade.flow, %.splat355
  %2793 = load <8 x i1>, ptr %runnable.mask, align 1
  %2794 = xor <8 x i1> %2792, splat (i1 true)
  %2795 = and <8 x i1> %2793, %2794
  store <8 x i1> %2795, ptr %runnable.mask, align 1
  %.splatinsert356 = insertelement <8 x i1> poison, i1 %2783, i64 0
  %.splat357 = shufflevector <8 x i1> %.splatinsert356, <8 x i1> poison, <8 x i32> zeroinitializer
  %2796 = select <8 x i1> %.splat357, <8 x i1> %2778, <8 x i1> zeroinitializer
  %2797 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2798 = extractelement <8 x i32> %2797, i32 %2763
  %2799 = select i1 %2783, i32 %2798, i32 %2759
  store i32 %2799, ptr %current.token, align 4
  %.splatinsert358 = insertelement <8 x i1> poison, i1 %2773, i64 0
  %.splat359 = shufflevector <8 x i1> %.splatinsert358, <8 x i1> poison, <8 x i32> zeroinitializer
  %2800 = select <8 x i1> %.splat359, <8 x i1> %2796, <8 x i1> %convergence.cascade.flow
  %2801 = add i32 %convergence.cascade.depth, 1
  %2802 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2800)
  %2803 = icmp ult i32 %2801, 8
  %2804 = and i1 %2802, %2803
  %2805 = and i1 %2773, %2804
  %convergence.parent.token = load i32, ptr %current.token, align 4
  %convergence.parent.present = icmp ne i32 %convergence.parent.token, 0
  %2806 = and i1 %2805, %convergence.parent.present
  br i1 %2806, label %convergence.cascade, label %convergence.cascade.exit

convergence.cascade.exit:                         ; preds = %convergence.cascade, %schedule.2
  %convergence.cascade.result = phi <8 x i1> [ %180, %schedule.2 ], [ %2800, %convergence.cascade ]
  %2807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %2807, label %convergence.target.2.ready, label %scheduler.loop

convergence.target.2.ready:                       ; preds = %convergence.cascade.exit
  %2808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  %2809 = bitcast <8 x i1> %convergence.cascade.result to i8
  %2810 = call i8 @llvm.cttz.i8(i8 %2809, i1 false)
  %2811 = zext i8 %2810 to i32
  %2812 = select i1 %2808, i32 %2811, i32 0
  %2813 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %2814 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %2815 = extractvalue { <8 x ptr>, <8 x i64> } %2813, 0
  %2816 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %2814, <8 x ptr> %2815
  %2817 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %2818 = extractvalue { <8 x ptr>, <8 x i64> } %2813, 1
  %2819 = select <8 x i1> %convergence.cascade.result, <8 x i64> %2817, <8 x i64> %2818
  %2820 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2816, 0
  %2821 = insertvalue { <8 x ptr>, <8 x i64> } %2820, <8 x i64> %2819, 1
  store { <8 x ptr>, <8 x i64> } %2821, ptr %tile_snapshot.spill40, align 64
  %2822 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill41, align 64
  %2823 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %2824 = extractvalue { <8 x ptr>, <8 x i64> } %2822, 0
  %2825 = select <8 x i1> %convergence.cascade.result, <8 x ptr> %2823, <8 x ptr> %2824
  %2826 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %2827 = extractvalue { <8 x ptr>, <8 x i64> } %2822, 1
  %2828 = select <8 x i1> %convergence.cascade.result, <8 x i64> %2826, <8 x i64> %2827
  %2829 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2825, 0
  %2830 = insertvalue { <8 x ptr>, <8 x i64> } %2829, <8 x i64> %2828, 1
  store { <8 x ptr>, <8 x i64> } %2830, ptr %tile_snapshot.spill41, align 64
  %2831 = load <8 x i64>, ptr %.slot, align 64
  %2832 = select <8 x i1> %convergence.cascade.result, <8 x i64> zeroinitializer, <8 x i64> %2831
  store <8 x i64> %2832, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result, ptr %current.mask, align 1
  %2833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result)
  br i1 %2833, label %schedule.3, label %scheduler.loop

varying.divergent360:                             ; preds = %schedule.3
  %2834 = load i32, ptr %current.token, align 4
  %2835 = icmp ne i32 %2834, 0
  %2836 = sub i32 %2834, 1
  %2837 = select i1 %2835, i32 %2836, i32 0
  %2838 = load i8, ptr %frame.active, align 1
  %2839 = trunc i32 %2837 to i8
  %2840 = shl i8 1, %2839
  %2841 = and i8 %2838, %2840
  %2842 = icmp ne i8 %2841, 0
  %2843 = load <8 x i32>, ptr %frame.static.id, align 32
  %2844 = extractelement <8 x i32> %2843, i32 %2837
  %2845 = icmp eq i32 %2844, 1
  %2846 = and i1 %2842, %2845
  %2847 = and i1 %2835, %2846
  %2848 = xor i1 %2847, true
  %2849 = and i1 true, %2848
  %2850 = xor i8 %2838, -1
  %2851 = icmp ne i8 %2850, 0
  %2852 = xor i1 %2851, true
  %2853 = and i1 %2849, %2852
  br i1 %2853, label %convergence.overflow.trap362, label %convergence.overflow.resume363

varying.coherent361:                              ; preds = %schedule.3
  br i1 %191, label %varying.coherent.true366, label %varying.coherent.false367

convergence.overflow.trap362:                     ; preds = %varying.divergent360
  call void @llvm.trap()
  unreachable

convergence.overflow.resume363:                   ; preds = %varying.divergent360
  %2854 = call i8 @llvm.cttz.i8(i8 %2850, i1 false)
  %2855 = zext i8 %2854 to i32
  %2856 = select i1 %2851, i32 %2855, i32 0
  %2857 = trunc i32 %2856 to i8
  %2858 = shl i8 1, %2857
  %2859 = or i8 %2838, %2858
  %2860 = select i1 %2849, i8 %2859, i8 %2838
  store i8 %2860, ptr %frame.active, align 1
  %2861 = load <8 x i32>, ptr %frame.static.id, align 32
  %2862 = extractelement <8 x i32> %2861, i32 %2856
  %2863 = select i1 %2849, i32 1, i32 %2862
  %2864 = load <8 x i32>, ptr %frame.static.id, align 32
  %2865 = insertelement <8 x i32> %2864, i32 %2863, i32 %2856
  store <8 x i32> %2865, ptr %frame.static.id, align 32
  %2866 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2867 = extractelement <8 x i32> %2866, i32 %2856
  %2868 = select i1 %2849, i32 %2834, i32 %2867
  %2869 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2870 = insertelement <8 x i32> %2869, i32 %2868, i32 %2856
  store <8 x i32> %2870, ptr %frame.parent.token, align 32
  %2871 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2856
  %2872 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2856
  %2873 = load <8 x i1>, ptr %2871, align 1
  %2874 = load <8 x i1>, ptr %2872, align 1
  %2875 = select i1 %2849, <8 x i1> %181, <8 x i1> %2873
  store <8 x i1> %2875, ptr %2871, align 1
  %2876 = select i1 %2849, <8 x i1> zeroinitializer, <8 x i1> %2874
  store <8 x i1> %2876, ptr %2872, align 1
  %2877 = add i32 %2856, 1
  %2878 = select i1 %2847, i32 %2834, i32 %2877
  %2879 = select i1 true, i32 %2878, i32 %2834
  store i32 %2879, ptr %current.token, align 4
  %2880 = load i32, ptr %current.token, align 4
  %2881 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %188)
  %2882 = load i32, ptr %ready.count, align 4
  %2883 = icmp uge i32 %2882, 8
  %2884 = and i1 %2881, %2883
  br i1 %2884, label %ready.overflow.trap364, label %ready.overflow.resume365

ready.overflow.trap364:                           ; preds = %convergence.overflow.resume363
  call void @llvm.trap()
  unreachable

ready.overflow.resume365:                         ; preds = %convergence.overflow.resume363
  %2885 = select i1 %2881, i32 %2882, i32 0
  %2886 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %2885
  %2887 = load <8 x i1>, ptr %2886, align 1
  %2888 = select i1 %2881, <8 x i1> %188, <8 x i1> %2887
  store <8 x i1> %2888, ptr %2886, align 1
  %2889 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %2885
  %2890 = load i32, ptr %2889, align 4
  %2891 = select i1 %2881, i32 4, i32 %2890
  store i32 %2891, ptr %2889, align 4
  %2892 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %2885
  %2893 = load i32, ptr %2892, align 4
  %2894 = select i1 %2881, i32 %2880, i32 %2893
  store i32 %2894, ptr %2892, align 4
  %2895 = add i32 %2882, 1
  %2896 = select i1 %2881, i32 %2895, i32 %2882
  store i32 %2896, ptr %ready.count, align 4
  %2897 = load <8 x i1>, ptr %runnable.mask, align 1
  %2898 = or <8 x i1> %2897, %188
  store <8 x i1> %2898, ptr %runnable.mask, align 1
  store <8 x i1> %190, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true366:                         ; preds = %varying.coherent361
  store <8 x i1> %181, ptr %current.mask, align 1
  %2899 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %181)
  br i1 %2899, label %schedule.4, label %scheduler.loop

varying.coherent.false367:                        ; preds = %varying.coherent361
  store <8 x i1> %181, ptr %current.mask, align 1
  %2900 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %181)
  br i1 %2900, label %schedule.5, label %scheduler.loop

convergence.cascade371:                           ; preds = %convergence.cascade371, %schedule.5
  %convergence.cascade.flow375 = phi <8 x i1> [ %213, %schedule.5 ], [ %2943, %convergence.cascade371 ]
  %convergence.cascade.depth376 = phi i32 [ 0, %schedule.5 ], [ %2944, %convergence.cascade371 ]
  %2901 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow375)
  %2902 = load i32, ptr %current.token, align 4
  %2903 = icmp ne i32 %2902, 0
  %2904 = and i1 %2901, %2903
  %2905 = sub i32 %2902, 1
  %2906 = select i1 %2904, i32 %2905, i32 0
  %2907 = load i8, ptr %frame.active, align 1
  %2908 = trunc i32 %2906 to i8
  %2909 = shl i8 1, %2908
  %2910 = and i8 %2907, %2909
  %2911 = icmp ne i8 %2910, 0
  %2912 = load <8 x i32>, ptr %frame.static.id, align 32
  %2913 = extractelement <8 x i32> %2912, i32 %2906
  %convergence.target.pointer377 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %2913
  %convergence.dynamic.target378 = load i32, ptr %convergence.target.pointer377, align 4
  %2914 = icmp eq i32 %convergence.dynamic.target378, 5
  %2915 = and i1 %2911, %2914
  %2916 = and i1 %2904, %2915
  %2917 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2906
  %2918 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2906
  %2919 = load <8 x i1>, ptr %2917, align 1
  %2920 = load <8 x i1>, ptr %2918, align 1
  %2921 = or <8 x i1> %2920, %convergence.cascade.flow375
  %2922 = load <8 x i1>, ptr %live.mask, align 1
  %2923 = and <8 x i1> %2919, %2922
  %2924 = icmp eq <8 x i1> %2921, %2923
  %2925 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %2924)
  %2926 = and i1 %2916, %2925
  %2927 = select i1 %2926, <8 x i1> zeroinitializer, <8 x i1> %2921
  %2928 = select i1 %2916, <8 x i1> %2927, <8 x i1> %2920
  store <8 x i1> %2928, ptr %2918, align 1
  %2929 = select i1 %2926, <8 x i1> zeroinitializer, <8 x i1> %2919
  store <8 x i1> %2929, ptr %2917, align 1
  %2930 = trunc i32 %2906 to i8
  %2931 = shl i8 1, %2930
  %2932 = xor i8 %2931, -1
  %2933 = and i8 %2907, %2932
  %2934 = select i1 %2926, i8 %2933, i8 %2907
  store i8 %2934, ptr %frame.active, align 1
  %.splatinsert379 = insertelement <8 x i1> poison, i1 %2916, i64 0
  %.splat380 = shufflevector <8 x i1> %.splatinsert379, <8 x i1> poison, <8 x i32> zeroinitializer
  %2935 = and <8 x i1> %convergence.cascade.flow375, %.splat380
  %2936 = load <8 x i1>, ptr %runnable.mask, align 1
  %2937 = xor <8 x i1> %2935, splat (i1 true)
  %2938 = and <8 x i1> %2936, %2937
  store <8 x i1> %2938, ptr %runnable.mask, align 1
  %.splatinsert381 = insertelement <8 x i1> poison, i1 %2926, i64 0
  %.splat382 = shufflevector <8 x i1> %.splatinsert381, <8 x i1> poison, <8 x i32> zeroinitializer
  %2939 = select <8 x i1> %.splat382, <8 x i1> %2921, <8 x i1> zeroinitializer
  %2940 = load <8 x i32>, ptr %frame.parent.token, align 32
  %2941 = extractelement <8 x i32> %2940, i32 %2906
  %2942 = select i1 %2926, i32 %2941, i32 %2902
  store i32 %2942, ptr %current.token, align 4
  %.splatinsert383 = insertelement <8 x i1> poison, i1 %2916, i64 0
  %.splat384 = shufflevector <8 x i1> %.splatinsert383, <8 x i1> poison, <8 x i32> zeroinitializer
  %2943 = select <8 x i1> %.splat384, <8 x i1> %2939, <8 x i1> %convergence.cascade.flow375
  %2944 = add i32 %convergence.cascade.depth376, 1
  %2945 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2943)
  %2946 = icmp ult i32 %2944, 8
  %2947 = and i1 %2945, %2946
  %2948 = and i1 %2916, %2947
  %convergence.parent.token385 = load i32, ptr %current.token, align 4
  %convergence.parent.present386 = icmp ne i32 %convergence.parent.token385, 0
  %2949 = and i1 %2948, %convergence.parent.present386
  br i1 %2949, label %convergence.cascade371, label %convergence.cascade.exit372

convergence.cascade.exit372:                      ; preds = %convergence.cascade371, %schedule.5
  %convergence.cascade.result387 = phi <8 x i1> [ %213, %schedule.5 ], [ %2943, %convergence.cascade371 ]
  %2950 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result387)
  br i1 %2950, label %convergence.target.5.ready, label %scheduler.loop

convergence.target.5.ready:                       ; preds = %convergence.cascade.exit372
  %2951 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result387)
  %2952 = bitcast <8 x i1> %convergence.cascade.result387 to i8
  %2953 = call i8 @llvm.cttz.i8(i8 %2952, i1 false)
  %2954 = zext i8 %2953 to i32
  %2955 = select i1 %2951, i32 %2954, i32 0
  %2956 = load <8 x i64>, ptr %.slot, align 64
  %2957 = select <8 x i1> %convergence.cascade.result387, <8 x i64> zeroinitializer, <8 x i64> %2956
  store <8 x i64> %2957, ptr %.slot, align 64
  %2958 = load <8 x float>, ptr %.slot43, align 32
  %2959 = select <8 x i1> %convergence.cascade.result387, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2958
  store <8 x float> %2959, ptr %.slot43, align 32
  %2960 = load <8 x float>, ptr %.slot44, align 32
  %2961 = select <8 x i1> %convergence.cascade.result387, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2960
  store <8 x float> %2961, ptr %.slot44, align 32
  %2962 = load <8 x float>, ptr %.slot45, align 32
  %2963 = select <8 x i1> %convergence.cascade.result387, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2962
  store <8 x float> %2963, ptr %.slot45, align 32
  %2964 = load <8 x float>, ptr %.slot46, align 32
  %2965 = select <8 x i1> %convergence.cascade.result387, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %2964
  store <8 x float> %2965, ptr %.slot46, align 32
  %2966 = load <8 x float>, ptr %.slot47, align 32
  %2967 = select <8 x i1> %convergence.cascade.result387, <8 x float> zeroinitializer, <8 x float> %2966
  store <8 x float> %2967, ptr %.slot47, align 32
  %2968 = load <8 x float>, ptr %.slot48, align 32
  %2969 = select <8 x i1> %convergence.cascade.result387, <8 x float> zeroinitializer, <8 x float> %2968
  store <8 x float> %2969, ptr %.slot48, align 32
  %2970 = load <8 x float>, ptr %.slot49, align 32
  %2971 = select <8 x i1> %convergence.cascade.result387, <8 x float> zeroinitializer, <8 x float> %2970
  store <8 x float> %2971, ptr %.slot49, align 32
  %2972 = load <8 x float>, ptr %.slot50, align 32
  %2973 = select <8 x i1> %convergence.cascade.result387, <8 x float> zeroinitializer, <8 x float> %2972
  store <8 x float> %2973, ptr %.slot50, align 32
  store <8 x i1> %convergence.cascade.result387, ptr %current.mask, align 1
  %2974 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result387)
  br i1 %2974, label %schedule.6, label %scheduler.loop

varying.divergent389:                             ; preds = %schedule.6
  %2975 = load i32, ptr %current.token, align 4
  %2976 = icmp ne i32 %2975, 0
  %2977 = sub i32 %2975, 1
  %2978 = select i1 %2976, i32 %2977, i32 0
  %2979 = load i8, ptr %frame.active, align 1
  %2980 = trunc i32 %2978 to i8
  %2981 = shl i8 1, %2980
  %2982 = and i8 %2979, %2981
  %2983 = icmp ne i8 %2982, 0
  %2984 = load <8 x i32>, ptr %frame.static.id, align 32
  %2985 = extractelement <8 x i32> %2984, i32 %2978
  %2986 = icmp eq i32 %2985, 2
  %2987 = and i1 %2983, %2986
  %2988 = and i1 %2976, %2987
  %2989 = xor i1 %2988, true
  %2990 = and i1 true, %2989
  %2991 = xor i8 %2979, -1
  %2992 = icmp ne i8 %2991, 0
  %2993 = xor i1 %2992, true
  %2994 = and i1 %2990, %2993
  br i1 %2994, label %convergence.overflow.trap391, label %convergence.overflow.resume392

varying.coherent390:                              ; preds = %schedule.6
  br i1 %224, label %varying.coherent.true395, label %varying.coherent.false396

convergence.overflow.trap391:                     ; preds = %varying.divergent389
  call void @llvm.trap()
  unreachable

convergence.overflow.resume392:                   ; preds = %varying.divergent389
  %2995 = call i8 @llvm.cttz.i8(i8 %2991, i1 false)
  %2996 = zext i8 %2995 to i32
  %2997 = select i1 %2992, i32 %2996, i32 0
  %2998 = trunc i32 %2997 to i8
  %2999 = shl i8 1, %2998
  %3000 = or i8 %2979, %2999
  %3001 = select i1 %2990, i8 %3000, i8 %2979
  store i8 %3001, ptr %frame.active, align 1
  %3002 = load <8 x i32>, ptr %frame.static.id, align 32
  %3003 = extractelement <8 x i32> %3002, i32 %2997
  %3004 = select i1 %2990, i32 2, i32 %3003
  %3005 = load <8 x i32>, ptr %frame.static.id, align 32
  %3006 = insertelement <8 x i32> %3005, i32 %3004, i32 %2997
  store <8 x i32> %3006, ptr %frame.static.id, align 32
  %3007 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3008 = extractelement <8 x i32> %3007, i32 %2997
  %3009 = select i1 %2990, i32 %2975, i32 %3008
  %3010 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3011 = insertelement <8 x i32> %3010, i32 %3009, i32 %2997
  store <8 x i32> %3011, ptr %frame.parent.token, align 32
  %3012 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %2997
  %3013 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %2997
  %3014 = load <8 x i1>, ptr %3012, align 1
  %3015 = load <8 x i1>, ptr %3013, align 1
  %3016 = select i1 %2990, <8 x i1> %214, <8 x i1> %3014
  store <8 x i1> %3016, ptr %3012, align 1
  %3017 = select i1 %2990, <8 x i1> zeroinitializer, <8 x i1> %3015
  store <8 x i1> %3017, ptr %3013, align 1
  %3018 = add i32 %2997, 1
  %3019 = select i1 %2988, i32 %2975, i32 %3018
  %3020 = select i1 true, i32 %3019, i32 %2975
  store i32 %3020, ptr %current.token, align 4
  %3021 = load i32, ptr %current.token, align 4
  %3022 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %221)
  %3023 = load i32, ptr %ready.count, align 4
  %3024 = icmp uge i32 %3023, 8
  %3025 = and i1 %3022, %3024
  br i1 %3025, label %ready.overflow.trap393, label %ready.overflow.resume394

ready.overflow.trap393:                           ; preds = %convergence.overflow.resume392
  call void @llvm.trap()
  unreachable

ready.overflow.resume394:                         ; preds = %convergence.overflow.resume392
  %3026 = select i1 %3022, i32 %3023, i32 0
  %3027 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3026
  %3028 = load <8 x i1>, ptr %3027, align 1
  %3029 = select i1 %3022, <8 x i1> %221, <8 x i1> %3028
  store <8 x i1> %3029, ptr %3027, align 1
  %3030 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3026
  %3031 = load i32, ptr %3030, align 4
  %3032 = select i1 %3022, i32 7, i32 %3031
  store i32 %3032, ptr %3030, align 4
  %3033 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3026
  %3034 = load i32, ptr %3033, align 4
  %3035 = select i1 %3022, i32 %3021, i32 %3034
  store i32 %3035, ptr %3033, align 4
  %3036 = add i32 %3023, 1
  %3037 = select i1 %3022, i32 %3036, i32 %3023
  store i32 %3037, ptr %ready.count, align 4
  %3038 = load <8 x i1>, ptr %runnable.mask, align 1
  %3039 = or <8 x i1> %3038, %221
  store <8 x i1> %3039, ptr %runnable.mask, align 1
  store <8 x i1> %223, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true395:                         ; preds = %varying.coherent390
  store <8 x i1> %214, ptr %current.mask, align 1
  %3040 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %214)
  br i1 %3040, label %schedule.7, label %scheduler.loop

varying.coherent.false396:                        ; preds = %varying.coherent390
  store <8 x i1> %214, ptr %current.mask, align 1
  %3041 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %214)
  br i1 %3041, label %schedule.109, label %scheduler.loop

varying.divergent398:                             ; preds = %schedule.7
  %3042 = load i32, ptr %current.token, align 4
  %3043 = icmp ne i32 %3042, 0
  %3044 = sub i32 %3042, 1
  %3045 = select i1 %3043, i32 %3044, i32 0
  %3046 = load i8, ptr %frame.active, align 1
  %3047 = trunc i32 %3045 to i8
  %3048 = shl i8 1, %3047
  %3049 = and i8 %3046, %3048
  %3050 = icmp ne i8 %3049, 0
  %3051 = load <8 x i32>, ptr %frame.static.id, align 32
  %3052 = extractelement <8 x i32> %3051, i32 %3045
  %3053 = icmp eq i32 %3052, 3
  %3054 = and i1 %3050, %3053
  %3055 = and i1 %3043, %3054
  %3056 = xor i1 %3055, true
  %3057 = and i1 true, %3056
  %3058 = xor i8 %3046, -1
  %3059 = icmp ne i8 %3058, 0
  %3060 = xor i1 %3059, true
  %3061 = and i1 %3057, %3060
  br i1 %3061, label %convergence.overflow.trap400, label %convergence.overflow.resume401

varying.coherent399:                              ; preds = %schedule.7
  br i1 %257, label %varying.coherent.true404, label %varying.coherent.false405

convergence.overflow.trap400:                     ; preds = %varying.divergent398
  call void @llvm.trap()
  unreachable

convergence.overflow.resume401:                   ; preds = %varying.divergent398
  %3062 = call i8 @llvm.cttz.i8(i8 %3058, i1 false)
  %3063 = zext i8 %3062 to i32
  %3064 = select i1 %3059, i32 %3063, i32 0
  %3065 = trunc i32 %3064 to i8
  %3066 = shl i8 1, %3065
  %3067 = or i8 %3046, %3066
  %3068 = select i1 %3057, i8 %3067, i8 %3046
  store i8 %3068, ptr %frame.active, align 1
  %3069 = load <8 x i32>, ptr %frame.static.id, align 32
  %3070 = extractelement <8 x i32> %3069, i32 %3064
  %3071 = select i1 %3057, i32 3, i32 %3070
  %3072 = load <8 x i32>, ptr %frame.static.id, align 32
  %3073 = insertelement <8 x i32> %3072, i32 %3071, i32 %3064
  store <8 x i32> %3073, ptr %frame.static.id, align 32
  %3074 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3075 = extractelement <8 x i32> %3074, i32 %3064
  %3076 = select i1 %3057, i32 %3042, i32 %3075
  %3077 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3078 = insertelement <8 x i32> %3077, i32 %3076, i32 %3064
  store <8 x i32> %3078, ptr %frame.parent.token, align 32
  %3079 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3064
  %3080 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3064
  %3081 = load <8 x i1>, ptr %3079, align 1
  %3082 = load <8 x i1>, ptr %3080, align 1
  %3083 = select i1 %3057, <8 x i1> %227, <8 x i1> %3081
  store <8 x i1> %3083, ptr %3079, align 1
  %3084 = select i1 %3057, <8 x i1> zeroinitializer, <8 x i1> %3082
  store <8 x i1> %3084, ptr %3080, align 1
  %3085 = add i32 %3064, 1
  %3086 = select i1 %3055, i32 %3042, i32 %3085
  %3087 = select i1 true, i32 %3086, i32 %3042
  store i32 %3087, ptr %current.token, align 4
  %3088 = load i32, ptr %current.token, align 4
  %3089 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %254)
  %3090 = load i32, ptr %ready.count, align 4
  %3091 = icmp uge i32 %3090, 8
  %3092 = and i1 %3089, %3091
  br i1 %3092, label %ready.overflow.trap402, label %ready.overflow.resume403

ready.overflow.trap402:                           ; preds = %convergence.overflow.resume401
  call void @llvm.trap()
  unreachable

ready.overflow.resume403:                         ; preds = %convergence.overflow.resume401
  %3093 = select i1 %3089, i32 %3090, i32 0
  %3094 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3093
  %3095 = load <8 x i1>, ptr %3094, align 1
  %3096 = select i1 %3089, <8 x i1> %254, <8 x i1> %3095
  store <8 x i1> %3096, ptr %3094, align 1
  %3097 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3093
  %3098 = load i32, ptr %3097, align 4
  %3099 = select i1 %3089, i32 8, i32 %3098
  store i32 %3099, ptr %3097, align 4
  %3100 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3093
  %3101 = load i32, ptr %3100, align 4
  %3102 = select i1 %3089, i32 %3088, i32 %3101
  store i32 %3102, ptr %3100, align 4
  %3103 = add i32 %3090, 1
  %3104 = select i1 %3089, i32 %3103, i32 %3090
  store i32 %3104, ptr %ready.count, align 4
  %3105 = load <8 x i1>, ptr %runnable.mask, align 1
  %3106 = or <8 x i1> %3105, %254
  store <8 x i1> %3106, ptr %runnable.mask, align 1
  store <8 x i1> %256, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true404:                         ; preds = %varying.coherent399
  store <8 x i1> %227, ptr %current.mask, align 1
  %3107 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %227)
  br i1 %3107, label %schedule.8, label %scheduler.loop

varying.coherent.false405:                        ; preds = %varying.coherent399
  store <8 x i1> %227, ptr %current.mask, align 1
  %3108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %227)
  br i1 %3108, label %schedule.104, label %scheduler.loop

copy.active410:                                   ; preds = %schedule.8
  %3109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %3110 = extractelement <8 x ptr> %3109, i64 0
  %3111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %3112 = extractelement <8 x i64> %3111, i64 0
  %3113 = getelementptr i8, ptr %3110, i64 %3112
  %3114 = extractelement <8 x i64> %272, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %273, i64 %3114, ptr %3113)
  br label %copy.continue411

copy.continue411:                                 ; preds = %copy.active410, %schedule.8
  %3115 = extractelement <8 x i1> %260, i64 1
  br i1 %3115, label %copy.active412, label %copy.continue413

copy.active412:                                   ; preds = %copy.continue411
  %3116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %3117 = extractelement <8 x ptr> %3116, i64 1
  %3118 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %3119 = extractelement <8 x i64> %3118, i64 1
  %3120 = getelementptr i8, ptr %3117, i64 %3119
  %3121 = extractelement <8 x i64> %272, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %273, i64 %3121, ptr %3120)
  br label %copy.continue413

copy.continue413:                                 ; preds = %copy.active412, %copy.continue411
  %3122 = extractelement <8 x i1> %260, i64 2
  br i1 %3122, label %copy.active414, label %copy.continue415

copy.active414:                                   ; preds = %copy.continue413
  %3123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %3124 = extractelement <8 x ptr> %3123, i64 2
  %3125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %3126 = extractelement <8 x i64> %3125, i64 2
  %3127 = getelementptr i8, ptr %3124, i64 %3126
  %3128 = extractelement <8 x i64> %272, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %273, i64 %3128, ptr %3127)
  br label %copy.continue415

copy.continue415:                                 ; preds = %copy.active414, %copy.continue413
  %3129 = extractelement <8 x i1> %260, i64 3
  br i1 %3129, label %copy.active416, label %copy.continue417

copy.active416:                                   ; preds = %copy.continue415
  %3130 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %3131 = extractelement <8 x ptr> %3130, i64 3
  %3132 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %3133 = extractelement <8 x i64> %3132, i64 3
  %3134 = getelementptr i8, ptr %3131, i64 %3133
  %3135 = extractelement <8 x i64> %272, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %273, i64 %3135, ptr %3134)
  br label %copy.continue417

copy.continue417:                                 ; preds = %copy.active416, %copy.continue415
  %3136 = extractelement <8 x i1> %260, i64 4
  br i1 %3136, label %copy.active418, label %copy.continue419

copy.active418:                                   ; preds = %copy.continue417
  %3137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %3138 = extractelement <8 x ptr> %3137, i64 4
  %3139 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %3140 = extractelement <8 x i64> %3139, i64 4
  %3141 = getelementptr i8, ptr %3138, i64 %3140
  %3142 = extractelement <8 x i64> %272, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %273, i64 %3142, ptr %3141)
  br label %copy.continue419

copy.continue419:                                 ; preds = %copy.active418, %copy.continue417
  %3143 = extractelement <8 x i1> %260, i64 5
  br i1 %3143, label %copy.active420, label %copy.continue421

copy.active420:                                   ; preds = %copy.continue419
  %3144 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %3145 = extractelement <8 x ptr> %3144, i64 5
  %3146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %3147 = extractelement <8 x i64> %3146, i64 5
  %3148 = getelementptr i8, ptr %3145, i64 %3147
  %3149 = extractelement <8 x i64> %272, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %273, i64 %3149, ptr %3148)
  br label %copy.continue421

copy.continue421:                                 ; preds = %copy.active420, %copy.continue419
  %3150 = extractelement <8 x i1> %260, i64 6
  br i1 %3150, label %copy.active422, label %copy.continue423

copy.active422:                                   ; preds = %copy.continue421
  %3151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %3152 = extractelement <8 x ptr> %3151, i64 6
  %3153 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %3154 = extractelement <8 x i64> %3153, i64 6
  %3155 = getelementptr i8, ptr %3152, i64 %3154
  %3156 = extractelement <8 x i64> %272, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %273, i64 %3156, ptr %3155)
  br label %copy.continue423

copy.continue423:                                 ; preds = %copy.active422, %copy.continue421
  %3157 = extractelement <8 x i1> %260, i64 7
  br i1 %3157, label %copy.active424, label %copy.continue425

copy.active424:                                   ; preds = %copy.continue423
  %3158 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 0
  %3159 = extractelement <8 x ptr> %3158, i64 7
  %3160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load409, 1
  %3161 = extractelement <8 x i64> %3160, i64 7
  %3162 = getelementptr i8, ptr %3159, i64 %3161
  %3163 = extractelement <8 x i64> %272, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %273, i64 %3163, ptr %3162)
  br label %copy.continue425

copy.continue425:                                 ; preds = %copy.active424, %copy.continue423
  store <8 x i1> %260, ptr %current.mask, align 1
  %3164 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %260)
  br i1 %3164, label %schedule.9, label %scheduler.loop

convergence.cascade426:                           ; preds = %convergence.cascade426, %schedule.9
  %convergence.cascade.flow430 = phi <8 x i1> [ %275, %schedule.9 ], [ %3207, %convergence.cascade426 ]
  %convergence.cascade.depth431 = phi i32 [ 0, %schedule.9 ], [ %3208, %convergence.cascade426 ]
  %3165 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow430)
  %3166 = load i32, ptr %current.token, align 4
  %3167 = icmp ne i32 %3166, 0
  %3168 = and i1 %3165, %3167
  %3169 = sub i32 %3166, 1
  %3170 = select i1 %3168, i32 %3169, i32 0
  %3171 = load i8, ptr %frame.active, align 1
  %3172 = trunc i32 %3170 to i8
  %3173 = shl i8 1, %3172
  %3174 = and i8 %3171, %3173
  %3175 = icmp ne i8 %3174, 0
  %3176 = load <8 x i32>, ptr %frame.static.id, align 32
  %3177 = extractelement <8 x i32> %3176, i32 %3170
  %convergence.target.pointer432 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %3177
  %convergence.dynamic.target433 = load i32, ptr %convergence.target.pointer432, align 4
  %3178 = icmp eq i32 %convergence.dynamic.target433, 9
  %3179 = and i1 %3175, %3178
  %3180 = and i1 %3168, %3179
  %3181 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3170
  %3182 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3170
  %3183 = load <8 x i1>, ptr %3181, align 1
  %3184 = load <8 x i1>, ptr %3182, align 1
  %3185 = or <8 x i1> %3184, %convergence.cascade.flow430
  %3186 = load <8 x i1>, ptr %live.mask, align 1
  %3187 = and <8 x i1> %3183, %3186
  %3188 = icmp eq <8 x i1> %3185, %3187
  %3189 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3188)
  %3190 = and i1 %3180, %3189
  %3191 = select i1 %3190, <8 x i1> zeroinitializer, <8 x i1> %3185
  %3192 = select i1 %3180, <8 x i1> %3191, <8 x i1> %3184
  store <8 x i1> %3192, ptr %3182, align 1
  %3193 = select i1 %3190, <8 x i1> zeroinitializer, <8 x i1> %3183
  store <8 x i1> %3193, ptr %3181, align 1
  %3194 = trunc i32 %3170 to i8
  %3195 = shl i8 1, %3194
  %3196 = xor i8 %3195, -1
  %3197 = and i8 %3171, %3196
  %3198 = select i1 %3190, i8 %3197, i8 %3171
  store i8 %3198, ptr %frame.active, align 1
  %.splatinsert434 = insertelement <8 x i1> poison, i1 %3180, i64 0
  %.splat435 = shufflevector <8 x i1> %.splatinsert434, <8 x i1> poison, <8 x i32> zeroinitializer
  %3199 = and <8 x i1> %convergence.cascade.flow430, %.splat435
  %3200 = load <8 x i1>, ptr %runnable.mask, align 1
  %3201 = xor <8 x i1> %3199, splat (i1 true)
  %3202 = and <8 x i1> %3200, %3201
  store <8 x i1> %3202, ptr %runnable.mask, align 1
  %.splatinsert436 = insertelement <8 x i1> poison, i1 %3190, i64 0
  %.splat437 = shufflevector <8 x i1> %.splatinsert436, <8 x i1> poison, <8 x i32> zeroinitializer
  %3203 = select <8 x i1> %.splat437, <8 x i1> %3185, <8 x i1> zeroinitializer
  %3204 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3205 = extractelement <8 x i32> %3204, i32 %3170
  %3206 = select i1 %3190, i32 %3205, i32 %3166
  store i32 %3206, ptr %current.token, align 4
  %.splatinsert438 = insertelement <8 x i1> poison, i1 %3180, i64 0
  %.splat439 = shufflevector <8 x i1> %.splatinsert438, <8 x i1> poison, <8 x i32> zeroinitializer
  %3207 = select <8 x i1> %.splat439, <8 x i1> %3203, <8 x i1> %convergence.cascade.flow430
  %3208 = add i32 %convergence.cascade.depth431, 1
  %3209 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3207)
  %3210 = icmp ult i32 %3208, 8
  %3211 = and i1 %3209, %3210
  %3212 = and i1 %3180, %3211
  %convergence.parent.token440 = load i32, ptr %current.token, align 4
  %convergence.parent.present441 = icmp ne i32 %convergence.parent.token440, 0
  %3213 = and i1 %3212, %convergence.parent.present441
  br i1 %3213, label %convergence.cascade426, label %convergence.cascade.exit427

convergence.cascade.exit427:                      ; preds = %convergence.cascade426, %schedule.9
  %convergence.cascade.result442 = phi <8 x i1> [ %275, %schedule.9 ], [ %3207, %convergence.cascade426 ]
  %3214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result442)
  br i1 %3214, label %convergence.target.9.ready, label %scheduler.loop

convergence.target.9.ready:                       ; preds = %convergence.cascade.exit427
  %3215 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result442)
  %3216 = bitcast <8 x i1> %convergence.cascade.result442 to i8
  %3217 = call i8 @llvm.cttz.i8(i8 %3216, i1 false)
  %3218 = zext i8 %3217 to i32
  %3219 = select i1 %3215, i32 %3218, i32 0
  %3220 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %3221 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %3222 = extractvalue { <8 x ptr>, <8 x i64> } %3220, 0
  %3223 = select <8 x i1> %convergence.cascade.result442, <8 x ptr> %3221, <8 x ptr> %3222
  %3224 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %3225 = extractvalue { <8 x ptr>, <8 x i64> } %3220, 1
  %3226 = select <8 x i1> %convergence.cascade.result442, <8 x i64> %3224, <8 x i64> %3225
  %3227 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3223, 0
  %3228 = insertvalue { <8 x ptr>, <8 x i64> } %3227, <8 x i64> %3226, 1
  store { <8 x ptr>, <8 x i64> } %3228, ptr %tile_snapshot.spill54, align 64
  %.spill.load443 = load <8 x i1>, ptr %.spill53, align 1
  %3229 = and <8 x i1> %convergence.cascade.result442, %.spill.load443
  %3230 = xor <8 x i1> %.spill.load443, splat (i1 true)
  %3231 = and <8 x i1> %convergence.cascade.result442, %3230
  %3232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3229)
  %3233 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3231)
  %3234 = and i1 %3232, %3233
  br i1 %3234, label %varying.divergent444, label %varying.coherent445

varying.divergent444:                             ; preds = %convergence.target.9.ready
  %3235 = load i32, ptr %current.token, align 4
  %3236 = icmp ne i32 %3235, 0
  %3237 = sub i32 %3235, 1
  %3238 = select i1 %3236, i32 %3237, i32 0
  %3239 = load i8, ptr %frame.active, align 1
  %3240 = trunc i32 %3238 to i8
  %3241 = shl i8 1, %3240
  %3242 = and i8 %3239, %3241
  %3243 = icmp ne i8 %3242, 0
  %3244 = load <8 x i32>, ptr %frame.static.id, align 32
  %3245 = extractelement <8 x i32> %3244, i32 %3238
  %3246 = icmp eq i32 %3245, 4
  %3247 = and i1 %3243, %3246
  %3248 = and i1 %3236, %3247
  %3249 = xor i1 %3248, true
  %3250 = and i1 true, %3249
  %3251 = xor i8 %3239, -1
  %3252 = icmp ne i8 %3251, 0
  %3253 = xor i1 %3252, true
  %3254 = and i1 %3250, %3253
  br i1 %3254, label %convergence.overflow.trap446, label %convergence.overflow.resume447

varying.coherent445:                              ; preds = %convergence.target.9.ready
  br i1 %3232, label %varying.coherent.true450, label %varying.coherent.false451

convergence.overflow.trap446:                     ; preds = %varying.divergent444
  call void @llvm.trap()
  unreachable

convergence.overflow.resume447:                   ; preds = %varying.divergent444
  %3255 = call i8 @llvm.cttz.i8(i8 %3251, i1 false)
  %3256 = zext i8 %3255 to i32
  %3257 = select i1 %3252, i32 %3256, i32 0
  %3258 = trunc i32 %3257 to i8
  %3259 = shl i8 1, %3258
  %3260 = or i8 %3239, %3259
  %3261 = select i1 %3250, i8 %3260, i8 %3239
  store i8 %3261, ptr %frame.active, align 1
  %3262 = load <8 x i32>, ptr %frame.static.id, align 32
  %3263 = extractelement <8 x i32> %3262, i32 %3257
  %3264 = select i1 %3250, i32 4, i32 %3263
  %3265 = load <8 x i32>, ptr %frame.static.id, align 32
  %3266 = insertelement <8 x i32> %3265, i32 %3264, i32 %3257
  store <8 x i32> %3266, ptr %frame.static.id, align 32
  %3267 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3268 = extractelement <8 x i32> %3267, i32 %3257
  %3269 = select i1 %3250, i32 %3235, i32 %3268
  %3270 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3271 = insertelement <8 x i32> %3270, i32 %3269, i32 %3257
  store <8 x i32> %3271, ptr %frame.parent.token, align 32
  %3272 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3257
  %3273 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3257
  %3274 = load <8 x i1>, ptr %3272, align 1
  %3275 = load <8 x i1>, ptr %3273, align 1
  %3276 = select i1 %3250, <8 x i1> %convergence.cascade.result442, <8 x i1> %3274
  store <8 x i1> %3276, ptr %3272, align 1
  %3277 = select i1 %3250, <8 x i1> zeroinitializer, <8 x i1> %3275
  store <8 x i1> %3277, ptr %3273, align 1
  %3278 = add i32 %3257, 1
  %3279 = select i1 %3248, i32 %3235, i32 %3278
  %3280 = select i1 true, i32 %3279, i32 %3235
  store i32 %3280, ptr %current.token, align 4
  %3281 = load i32, ptr %current.token, align 4
  %3282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3229)
  %3283 = load i32, ptr %ready.count, align 4
  %3284 = icmp uge i32 %3283, 8
  %3285 = and i1 %3282, %3284
  br i1 %3285, label %ready.overflow.trap448, label %ready.overflow.resume449

ready.overflow.trap448:                           ; preds = %convergence.overflow.resume447
  call void @llvm.trap()
  unreachable

ready.overflow.resume449:                         ; preds = %convergence.overflow.resume447
  %3286 = select i1 %3282, i32 %3283, i32 0
  %3287 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3286
  %3288 = load <8 x i1>, ptr %3287, align 1
  %3289 = select i1 %3282, <8 x i1> %3229, <8 x i1> %3288
  store <8 x i1> %3289, ptr %3287, align 1
  %3290 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3286
  %3291 = load i32, ptr %3290, align 4
  %3292 = select i1 %3282, i32 10, i32 %3291
  store i32 %3292, ptr %3290, align 4
  %3293 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3286
  %3294 = load i32, ptr %3293, align 4
  %3295 = select i1 %3282, i32 %3281, i32 %3294
  store i32 %3295, ptr %3293, align 4
  %3296 = add i32 %3283, 1
  %3297 = select i1 %3282, i32 %3296, i32 %3283
  store i32 %3297, ptr %ready.count, align 4
  %3298 = load <8 x i1>, ptr %runnable.mask, align 1
  %3299 = or <8 x i1> %3298, %3229
  store <8 x i1> %3299, ptr %runnable.mask, align 1
  store <8 x i1> %3231, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true450:                         ; preds = %varying.coherent445
  store <8 x i1> %convergence.cascade.result442, ptr %current.mask, align 1
  %3300 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result442)
  br i1 %3300, label %schedule.10, label %scheduler.loop

varying.coherent.false451:                        ; preds = %varying.coherent445
  store <8 x i1> %convergence.cascade.result442, ptr %current.mask, align 1
  %3301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result442)
  br i1 %3301, label %schedule.99, label %scheduler.loop

copy.active456:                                   ; preds = %schedule.10
  %3302 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %3303 = extractelement <8 x ptr> %3302, i64 0
  %3304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %3305 = extractelement <8 x i64> %3304, i64 0
  %3306 = getelementptr i8, ptr %3303, i64 %3305
  %3307 = extractelement <8 x i64> %288, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %289, i64 %3307, ptr %3306)
  br label %copy.continue457

copy.continue457:                                 ; preds = %copy.active456, %schedule.10
  %3308 = extractelement <8 x i1> %276, i64 1
  br i1 %3308, label %copy.active458, label %copy.continue459

copy.active458:                                   ; preds = %copy.continue457
  %3309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %3310 = extractelement <8 x ptr> %3309, i64 1
  %3311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %3312 = extractelement <8 x i64> %3311, i64 1
  %3313 = getelementptr i8, ptr %3310, i64 %3312
  %3314 = extractelement <8 x i64> %288, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %289, i64 %3314, ptr %3313)
  br label %copy.continue459

copy.continue459:                                 ; preds = %copy.active458, %copy.continue457
  %3315 = extractelement <8 x i1> %276, i64 2
  br i1 %3315, label %copy.active460, label %copy.continue461

copy.active460:                                   ; preds = %copy.continue459
  %3316 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %3317 = extractelement <8 x ptr> %3316, i64 2
  %3318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %3319 = extractelement <8 x i64> %3318, i64 2
  %3320 = getelementptr i8, ptr %3317, i64 %3319
  %3321 = extractelement <8 x i64> %288, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %289, i64 %3321, ptr %3320)
  br label %copy.continue461

copy.continue461:                                 ; preds = %copy.active460, %copy.continue459
  %3322 = extractelement <8 x i1> %276, i64 3
  br i1 %3322, label %copy.active462, label %copy.continue463

copy.active462:                                   ; preds = %copy.continue461
  %3323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %3324 = extractelement <8 x ptr> %3323, i64 3
  %3325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %3326 = extractelement <8 x i64> %3325, i64 3
  %3327 = getelementptr i8, ptr %3324, i64 %3326
  %3328 = extractelement <8 x i64> %288, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %289, i64 %3328, ptr %3327)
  br label %copy.continue463

copy.continue463:                                 ; preds = %copy.active462, %copy.continue461
  %3329 = extractelement <8 x i1> %276, i64 4
  br i1 %3329, label %copy.active464, label %copy.continue465

copy.active464:                                   ; preds = %copy.continue463
  %3330 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %3331 = extractelement <8 x ptr> %3330, i64 4
  %3332 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %3333 = extractelement <8 x i64> %3332, i64 4
  %3334 = getelementptr i8, ptr %3331, i64 %3333
  %3335 = extractelement <8 x i64> %288, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %289, i64 %3335, ptr %3334)
  br label %copy.continue465

copy.continue465:                                 ; preds = %copy.active464, %copy.continue463
  %3336 = extractelement <8 x i1> %276, i64 5
  br i1 %3336, label %copy.active466, label %copy.continue467

copy.active466:                                   ; preds = %copy.continue465
  %3337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %3338 = extractelement <8 x ptr> %3337, i64 5
  %3339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %3340 = extractelement <8 x i64> %3339, i64 5
  %3341 = getelementptr i8, ptr %3338, i64 %3340
  %3342 = extractelement <8 x i64> %288, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %289, i64 %3342, ptr %3341)
  br label %copy.continue467

copy.continue467:                                 ; preds = %copy.active466, %copy.continue465
  %3343 = extractelement <8 x i1> %276, i64 6
  br i1 %3343, label %copy.active468, label %copy.continue469

copy.active468:                                   ; preds = %copy.continue467
  %3344 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %3345 = extractelement <8 x ptr> %3344, i64 6
  %3346 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %3347 = extractelement <8 x i64> %3346, i64 6
  %3348 = getelementptr i8, ptr %3345, i64 %3347
  %3349 = extractelement <8 x i64> %288, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %289, i64 %3349, ptr %3348)
  br label %copy.continue469

copy.continue469:                                 ; preds = %copy.active468, %copy.continue467
  %3350 = extractelement <8 x i1> %276, i64 7
  br i1 %3350, label %copy.active470, label %copy.continue471

copy.active470:                                   ; preds = %copy.continue469
  %3351 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %3352 = extractelement <8 x ptr> %3351, i64 7
  %3353 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %3354 = extractelement <8 x i64> %3353, i64 7
  %3355 = getelementptr i8, ptr %3352, i64 %3354
  %3356 = extractelement <8 x i64> %288, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %289, i64 %3356, ptr %3355)
  br label %copy.continue471

copy.continue471:                                 ; preds = %copy.active470, %copy.continue469
  store <8 x i1> %276, ptr %current.mask, align 1
  %3357 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %276)
  br i1 %3357, label %schedule.11, label %scheduler.loop

convergence.cascade472:                           ; preds = %convergence.cascade472, %schedule.11
  %convergence.cascade.flow476 = phi <8 x i1> [ %291, %schedule.11 ], [ %3400, %convergence.cascade472 ]
  %convergence.cascade.depth477 = phi i32 [ 0, %schedule.11 ], [ %3401, %convergence.cascade472 ]
  %3358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow476)
  %3359 = load i32, ptr %current.token, align 4
  %3360 = icmp ne i32 %3359, 0
  %3361 = and i1 %3358, %3360
  %3362 = sub i32 %3359, 1
  %3363 = select i1 %3361, i32 %3362, i32 0
  %3364 = load i8, ptr %frame.active, align 1
  %3365 = trunc i32 %3363 to i8
  %3366 = shl i8 1, %3365
  %3367 = and i8 %3364, %3366
  %3368 = icmp ne i8 %3367, 0
  %3369 = load <8 x i32>, ptr %frame.static.id, align 32
  %3370 = extractelement <8 x i32> %3369, i32 %3363
  %convergence.target.pointer478 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %3370
  %convergence.dynamic.target479 = load i32, ptr %convergence.target.pointer478, align 4
  %3371 = icmp eq i32 %convergence.dynamic.target479, 11
  %3372 = and i1 %3368, %3371
  %3373 = and i1 %3361, %3372
  %3374 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3363
  %3375 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3363
  %3376 = load <8 x i1>, ptr %3374, align 1
  %3377 = load <8 x i1>, ptr %3375, align 1
  %3378 = or <8 x i1> %3377, %convergence.cascade.flow476
  %3379 = load <8 x i1>, ptr %live.mask, align 1
  %3380 = and <8 x i1> %3376, %3379
  %3381 = icmp eq <8 x i1> %3378, %3380
  %3382 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3381)
  %3383 = and i1 %3373, %3382
  %3384 = select i1 %3383, <8 x i1> zeroinitializer, <8 x i1> %3378
  %3385 = select i1 %3373, <8 x i1> %3384, <8 x i1> %3377
  store <8 x i1> %3385, ptr %3375, align 1
  %3386 = select i1 %3383, <8 x i1> zeroinitializer, <8 x i1> %3376
  store <8 x i1> %3386, ptr %3374, align 1
  %3387 = trunc i32 %3363 to i8
  %3388 = shl i8 1, %3387
  %3389 = xor i8 %3388, -1
  %3390 = and i8 %3364, %3389
  %3391 = select i1 %3383, i8 %3390, i8 %3364
  store i8 %3391, ptr %frame.active, align 1
  %.splatinsert480 = insertelement <8 x i1> poison, i1 %3373, i64 0
  %.splat481 = shufflevector <8 x i1> %.splatinsert480, <8 x i1> poison, <8 x i32> zeroinitializer
  %3392 = and <8 x i1> %convergence.cascade.flow476, %.splat481
  %3393 = load <8 x i1>, ptr %runnable.mask, align 1
  %3394 = xor <8 x i1> %3392, splat (i1 true)
  %3395 = and <8 x i1> %3393, %3394
  store <8 x i1> %3395, ptr %runnable.mask, align 1
  %.splatinsert482 = insertelement <8 x i1> poison, i1 %3383, i64 0
  %.splat483 = shufflevector <8 x i1> %.splatinsert482, <8 x i1> poison, <8 x i32> zeroinitializer
  %3396 = select <8 x i1> %.splat483, <8 x i1> %3378, <8 x i1> zeroinitializer
  %3397 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3398 = extractelement <8 x i32> %3397, i32 %3363
  %3399 = select i1 %3383, i32 %3398, i32 %3359
  store i32 %3399, ptr %current.token, align 4
  %.splatinsert484 = insertelement <8 x i1> poison, i1 %3373, i64 0
  %.splat485 = shufflevector <8 x i1> %.splatinsert484, <8 x i1> poison, <8 x i32> zeroinitializer
  %3400 = select <8 x i1> %.splat485, <8 x i1> %3396, <8 x i1> %convergence.cascade.flow476
  %3401 = add i32 %convergence.cascade.depth477, 1
  %3402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3400)
  %3403 = icmp ult i32 %3401, 8
  %3404 = and i1 %3402, %3403
  %3405 = and i1 %3373, %3404
  %convergence.parent.token486 = load i32, ptr %current.token, align 4
  %convergence.parent.present487 = icmp ne i32 %convergence.parent.token486, 0
  %3406 = and i1 %3405, %convergence.parent.present487
  br i1 %3406, label %convergence.cascade472, label %convergence.cascade.exit473

convergence.cascade.exit473:                      ; preds = %convergence.cascade472, %schedule.11
  %convergence.cascade.result488 = phi <8 x i1> [ %291, %schedule.11 ], [ %3400, %convergence.cascade472 ]
  %3407 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result488)
  br i1 %3407, label %convergence.target.11.ready, label %scheduler.loop

convergence.target.11.ready:                      ; preds = %convergence.cascade.exit473
  %3408 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result488)
  %3409 = bitcast <8 x i1> %convergence.cascade.result488 to i8
  %3410 = call i8 @llvm.cttz.i8(i8 %3409, i1 false)
  %3411 = zext i8 %3410 to i32
  %3412 = select i1 %3408, i32 %3411, i32 0
  %3413 = load <8 x i64>, ptr %.slot55, align 64
  %3414 = select <8 x i1> %convergence.cascade.result488, <8 x i64> zeroinitializer, <8 x i64> %3413
  store <8 x i64> %3414, ptr %.slot55, align 64
  %3415 = load <8 x float>, ptr %.slot56, align 32
  %3416 = select <8 x i1> %convergence.cascade.result488, <8 x float> zeroinitializer, <8 x float> %3415
  store <8 x float> %3416, ptr %.slot56, align 32
  %3417 = load <8 x float>, ptr %.slot57, align 32
  %3418 = select <8 x i1> %convergence.cascade.result488, <8 x float> zeroinitializer, <8 x float> %3417
  store <8 x float> %3418, ptr %.slot57, align 32
  %3419 = load <8 x float>, ptr %.slot58, align 32
  %3420 = select <8 x i1> %convergence.cascade.result488, <8 x float> zeroinitializer, <8 x float> %3419
  store <8 x float> %3420, ptr %.slot58, align 32
  %3421 = load <8 x float>, ptr %.slot59, align 32
  %3422 = select <8 x i1> %convergence.cascade.result488, <8 x float> zeroinitializer, <8 x float> %3421
  store <8 x float> %3422, ptr %.slot59, align 32
  store <8 x i1> %convergence.cascade.result488, ptr %current.mask, align 1
  %3423 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result488)
  br i1 %3423, label %schedule.12, label %scheduler.loop

varying.divergent490:                             ; preds = %schedule.12
  %3424 = load i32, ptr %current.token, align 4
  %3425 = icmp ne i32 %3424, 0
  %3426 = sub i32 %3424, 1
  %3427 = select i1 %3425, i32 %3426, i32 0
  %3428 = load i8, ptr %frame.active, align 1
  %3429 = trunc i32 %3427 to i8
  %3430 = shl i8 1, %3429
  %3431 = and i8 %3428, %3430
  %3432 = icmp ne i8 %3431, 0
  %3433 = load <8 x i32>, ptr %frame.static.id, align 32
  %3434 = extractelement <8 x i32> %3433, i32 %3427
  %3435 = icmp eq i32 %3434, 5
  %3436 = and i1 %3432, %3435
  %3437 = and i1 %3425, %3436
  %3438 = xor i1 %3437, true
  %3439 = and i1 true, %3438
  %3440 = xor i8 %3428, -1
  %3441 = icmp ne i8 %3440, 0
  %3442 = xor i1 %3441, true
  %3443 = and i1 %3439, %3442
  br i1 %3443, label %convergence.overflow.trap492, label %convergence.overflow.resume493

varying.coherent491:                              ; preds = %schedule.12
  br i1 %302, label %varying.coherent.true496, label %varying.coherent.false497

convergence.overflow.trap492:                     ; preds = %varying.divergent490
  call void @llvm.trap()
  unreachable

convergence.overflow.resume493:                   ; preds = %varying.divergent490
  %3444 = call i8 @llvm.cttz.i8(i8 %3440, i1 false)
  %3445 = zext i8 %3444 to i32
  %3446 = select i1 %3441, i32 %3445, i32 0
  %3447 = trunc i32 %3446 to i8
  %3448 = shl i8 1, %3447
  %3449 = or i8 %3428, %3448
  %3450 = select i1 %3439, i8 %3449, i8 %3428
  store i8 %3450, ptr %frame.active, align 1
  %3451 = load <8 x i32>, ptr %frame.static.id, align 32
  %3452 = extractelement <8 x i32> %3451, i32 %3446
  %3453 = select i1 %3439, i32 5, i32 %3452
  %3454 = load <8 x i32>, ptr %frame.static.id, align 32
  %3455 = insertelement <8 x i32> %3454, i32 %3453, i32 %3446
  store <8 x i32> %3455, ptr %frame.static.id, align 32
  %3456 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3457 = extractelement <8 x i32> %3456, i32 %3446
  %3458 = select i1 %3439, i32 %3424, i32 %3457
  %3459 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3460 = insertelement <8 x i32> %3459, i32 %3458, i32 %3446
  store <8 x i32> %3460, ptr %frame.parent.token, align 32
  %3461 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3446
  %3462 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3446
  %3463 = load <8 x i1>, ptr %3461, align 1
  %3464 = load <8 x i1>, ptr %3462, align 1
  %3465 = select i1 %3439, <8 x i1> %292, <8 x i1> %3463
  store <8 x i1> %3465, ptr %3461, align 1
  %3466 = select i1 %3439, <8 x i1> zeroinitializer, <8 x i1> %3464
  store <8 x i1> %3466, ptr %3462, align 1
  %3467 = add i32 %3446, 1
  %3468 = select i1 %3437, i32 %3424, i32 %3467
  %3469 = select i1 true, i32 %3468, i32 %3424
  store i32 %3469, ptr %current.token, align 4
  %3470 = load i32, ptr %current.token, align 4
  %3471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %299)
  %3472 = load i32, ptr %ready.count, align 4
  %3473 = icmp uge i32 %3472, 8
  %3474 = and i1 %3471, %3473
  br i1 %3474, label %ready.overflow.trap494, label %ready.overflow.resume495

ready.overflow.trap494:                           ; preds = %convergence.overflow.resume493
  call void @llvm.trap()
  unreachable

ready.overflow.resume495:                         ; preds = %convergence.overflow.resume493
  %3475 = select i1 %3471, i32 %3472, i32 0
  %3476 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3475
  %3477 = load <8 x i1>, ptr %3476, align 1
  %3478 = select i1 %3471, <8 x i1> %299, <8 x i1> %3477
  store <8 x i1> %3478, ptr %3476, align 1
  %3479 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3475
  %3480 = load i32, ptr %3479, align 4
  %3481 = select i1 %3471, i32 13, i32 %3480
  store i32 %3481, ptr %3479, align 4
  %3482 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3475
  %3483 = load i32, ptr %3482, align 4
  %3484 = select i1 %3471, i32 %3470, i32 %3483
  store i32 %3484, ptr %3482, align 4
  %3485 = add i32 %3472, 1
  %3486 = select i1 %3471, i32 %3485, i32 %3472
  store i32 %3486, ptr %ready.count, align 4
  %3487 = load <8 x i1>, ptr %runnable.mask, align 1
  %3488 = or <8 x i1> %3487, %299
  store <8 x i1> %3488, ptr %runnable.mask, align 1
  store <8 x i1> %301, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true496:                         ; preds = %varying.coherent491
  store <8 x i1> %292, ptr %current.mask, align 1
  %3489 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %292)
  br i1 %3489, label %schedule.13, label %scheduler.loop

varying.coherent.false497:                        ; preds = %varying.coherent491
  store <8 x i1> %292, ptr %current.mask, align 1
  %3490 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %292)
  br i1 %3490, label %schedule.14, label %scheduler.loop

convergence.cascade509:                           ; preds = %convergence.cascade509, %schedule.14
  %convergence.cascade.flow513 = phi <8 x i1> [ %373, %schedule.14 ], [ %3533, %convergence.cascade509 ]
  %convergence.cascade.depth514 = phi i32 [ 0, %schedule.14 ], [ %3534, %convergence.cascade509 ]
  %3491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow513)
  %3492 = load i32, ptr %current.token, align 4
  %3493 = icmp ne i32 %3492, 0
  %3494 = and i1 %3491, %3493
  %3495 = sub i32 %3492, 1
  %3496 = select i1 %3494, i32 %3495, i32 0
  %3497 = load i8, ptr %frame.active, align 1
  %3498 = trunc i32 %3496 to i8
  %3499 = shl i8 1, %3498
  %3500 = and i8 %3497, %3499
  %3501 = icmp ne i8 %3500, 0
  %3502 = load <8 x i32>, ptr %frame.static.id, align 32
  %3503 = extractelement <8 x i32> %3502, i32 %3496
  %convergence.target.pointer515 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %3503
  %convergence.dynamic.target516 = load i32, ptr %convergence.target.pointer515, align 4
  %3504 = icmp eq i32 %convergence.dynamic.target516, 14
  %3505 = and i1 %3501, %3504
  %3506 = and i1 %3494, %3505
  %3507 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3496
  %3508 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3496
  %3509 = load <8 x i1>, ptr %3507, align 1
  %3510 = load <8 x i1>, ptr %3508, align 1
  %3511 = or <8 x i1> %3510, %convergence.cascade.flow513
  %3512 = load <8 x i1>, ptr %live.mask, align 1
  %3513 = and <8 x i1> %3509, %3512
  %3514 = icmp eq <8 x i1> %3511, %3513
  %3515 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3514)
  %3516 = and i1 %3506, %3515
  %3517 = select i1 %3516, <8 x i1> zeroinitializer, <8 x i1> %3511
  %3518 = select i1 %3506, <8 x i1> %3517, <8 x i1> %3510
  store <8 x i1> %3518, ptr %3508, align 1
  %3519 = select i1 %3516, <8 x i1> zeroinitializer, <8 x i1> %3509
  store <8 x i1> %3519, ptr %3507, align 1
  %3520 = trunc i32 %3496 to i8
  %3521 = shl i8 1, %3520
  %3522 = xor i8 %3521, -1
  %3523 = and i8 %3497, %3522
  %3524 = select i1 %3516, i8 %3523, i8 %3497
  store i8 %3524, ptr %frame.active, align 1
  %.splatinsert517 = insertelement <8 x i1> poison, i1 %3506, i64 0
  %.splat518 = shufflevector <8 x i1> %.splatinsert517, <8 x i1> poison, <8 x i32> zeroinitializer
  %3525 = and <8 x i1> %convergence.cascade.flow513, %.splat518
  %3526 = load <8 x i1>, ptr %runnable.mask, align 1
  %3527 = xor <8 x i1> %3525, splat (i1 true)
  %3528 = and <8 x i1> %3526, %3527
  store <8 x i1> %3528, ptr %runnable.mask, align 1
  %.splatinsert519 = insertelement <8 x i1> poison, i1 %3516, i64 0
  %.splat520 = shufflevector <8 x i1> %.splatinsert519, <8 x i1> poison, <8 x i32> zeroinitializer
  %3529 = select <8 x i1> %.splat520, <8 x i1> %3511, <8 x i1> zeroinitializer
  %3530 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3531 = extractelement <8 x i32> %3530, i32 %3496
  %3532 = select i1 %3516, i32 %3531, i32 %3492
  store i32 %3532, ptr %current.token, align 4
  %.splatinsert521 = insertelement <8 x i1> poison, i1 %3506, i64 0
  %.splat522 = shufflevector <8 x i1> %.splatinsert521, <8 x i1> poison, <8 x i32> zeroinitializer
  %3533 = select <8 x i1> %.splat522, <8 x i1> %3529, <8 x i1> %convergence.cascade.flow513
  %3534 = add i32 %convergence.cascade.depth514, 1
  %3535 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3533)
  %3536 = icmp ult i32 %3534, 8
  %3537 = and i1 %3535, %3536
  %3538 = and i1 %3506, %3537
  %convergence.parent.token523 = load i32, ptr %current.token, align 4
  %convergence.parent.present524 = icmp ne i32 %convergence.parent.token523, 0
  %3539 = and i1 %3538, %convergence.parent.present524
  br i1 %3539, label %convergence.cascade509, label %convergence.cascade.exit510

convergence.cascade.exit510:                      ; preds = %convergence.cascade509, %schedule.14
  %convergence.cascade.result525 = phi <8 x i1> [ %373, %schedule.14 ], [ %3533, %convergence.cascade509 ]
  %3540 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result525)
  br i1 %3540, label %convergence.target.14.ready, label %scheduler.loop

convergence.target.14.ready:                      ; preds = %convergence.cascade.exit510
  %3541 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result525)
  %3542 = bitcast <8 x i1> %convergence.cascade.result525 to i8
  %3543 = call i8 @llvm.cttz.i8(i8 %3542, i1 false)
  %3544 = zext i8 %3543 to i32
  %3545 = select i1 %3541, i32 %3544, i32 0
  %3546 = load <8 x i64>, ptr %.slot55, align 64
  %3547 = select <8 x i1> %convergence.cascade.result525, <8 x i64> zeroinitializer, <8 x i64> %3546
  store <8 x i64> %3547, ptr %.slot55, align 64
  %3548 = load <8 x float>, ptr %.slot61, align 32
  %3549 = select <8 x i1> %convergence.cascade.result525, <8 x float> zeroinitializer, <8 x float> %3548
  store <8 x float> %3549, ptr %.slot61, align 32
  %3550 = load <8 x float>, ptr %.slot62, align 32
  %3551 = select <8 x i1> %convergence.cascade.result525, <8 x float> zeroinitializer, <8 x float> %3550
  store <8 x float> %3551, ptr %.slot62, align 32
  %3552 = load <8 x float>, ptr %.slot63, align 32
  %3553 = select <8 x i1> %convergence.cascade.result525, <8 x float> zeroinitializer, <8 x float> %3552
  store <8 x float> %3553, ptr %.slot63, align 32
  %3554 = load <8 x float>, ptr %.slot64, align 32
  %3555 = select <8 x i1> %convergence.cascade.result525, <8 x float> zeroinitializer, <8 x float> %3554
  store <8 x float> %3555, ptr %.slot64, align 32
  store <8 x i1> %convergence.cascade.result525, ptr %current.mask, align 1
  %3556 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result525)
  br i1 %3556, label %schedule.15, label %scheduler.loop

varying.divergent527:                             ; preds = %schedule.15
  %3557 = load i32, ptr %current.token, align 4
  %3558 = icmp ne i32 %3557, 0
  %3559 = sub i32 %3557, 1
  %3560 = select i1 %3558, i32 %3559, i32 0
  %3561 = load i8, ptr %frame.active, align 1
  %3562 = trunc i32 %3560 to i8
  %3563 = shl i8 1, %3562
  %3564 = and i8 %3561, %3563
  %3565 = icmp ne i8 %3564, 0
  %3566 = load <8 x i32>, ptr %frame.static.id, align 32
  %3567 = extractelement <8 x i32> %3566, i32 %3560
  %3568 = icmp eq i32 %3567, 6
  %3569 = and i1 %3565, %3568
  %3570 = and i1 %3558, %3569
  %3571 = xor i1 %3570, true
  %3572 = and i1 true, %3571
  %3573 = xor i8 %3561, -1
  %3574 = icmp ne i8 %3573, 0
  %3575 = xor i1 %3574, true
  %3576 = and i1 %3572, %3575
  br i1 %3576, label %convergence.overflow.trap529, label %convergence.overflow.resume530

varying.coherent528:                              ; preds = %schedule.15
  br i1 %384, label %varying.coherent.true533, label %varying.coherent.false534

convergence.overflow.trap529:                     ; preds = %varying.divergent527
  call void @llvm.trap()
  unreachable

convergence.overflow.resume530:                   ; preds = %varying.divergent527
  %3577 = call i8 @llvm.cttz.i8(i8 %3573, i1 false)
  %3578 = zext i8 %3577 to i32
  %3579 = select i1 %3574, i32 %3578, i32 0
  %3580 = trunc i32 %3579 to i8
  %3581 = shl i8 1, %3580
  %3582 = or i8 %3561, %3581
  %3583 = select i1 %3572, i8 %3582, i8 %3561
  store i8 %3583, ptr %frame.active, align 1
  %3584 = load <8 x i32>, ptr %frame.static.id, align 32
  %3585 = extractelement <8 x i32> %3584, i32 %3579
  %3586 = select i1 %3572, i32 6, i32 %3585
  %3587 = load <8 x i32>, ptr %frame.static.id, align 32
  %3588 = insertelement <8 x i32> %3587, i32 %3586, i32 %3579
  store <8 x i32> %3588, ptr %frame.static.id, align 32
  %3589 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3590 = extractelement <8 x i32> %3589, i32 %3579
  %3591 = select i1 %3572, i32 %3557, i32 %3590
  %3592 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3593 = insertelement <8 x i32> %3592, i32 %3591, i32 %3579
  store <8 x i32> %3593, ptr %frame.parent.token, align 32
  %3594 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3579
  %3595 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3579
  %3596 = load <8 x i1>, ptr %3594, align 1
  %3597 = load <8 x i1>, ptr %3595, align 1
  %3598 = select i1 %3572, <8 x i1> %374, <8 x i1> %3596
  store <8 x i1> %3598, ptr %3594, align 1
  %3599 = select i1 %3572, <8 x i1> zeroinitializer, <8 x i1> %3597
  store <8 x i1> %3599, ptr %3595, align 1
  %3600 = add i32 %3579, 1
  %3601 = select i1 %3570, i32 %3557, i32 %3600
  %3602 = select i1 true, i32 %3601, i32 %3557
  store i32 %3602, ptr %current.token, align 4
  %3603 = load i32, ptr %current.token, align 4
  %3604 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %381)
  %3605 = load i32, ptr %ready.count, align 4
  %3606 = icmp uge i32 %3605, 8
  %3607 = and i1 %3604, %3606
  br i1 %3607, label %ready.overflow.trap531, label %ready.overflow.resume532

ready.overflow.trap531:                           ; preds = %convergence.overflow.resume530
  call void @llvm.trap()
  unreachable

ready.overflow.resume532:                         ; preds = %convergence.overflow.resume530
  %3608 = select i1 %3604, i32 %3605, i32 0
  %3609 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3608
  %3610 = load <8 x i1>, ptr %3609, align 1
  %3611 = select i1 %3604, <8 x i1> %381, <8 x i1> %3610
  store <8 x i1> %3611, ptr %3609, align 1
  %3612 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3608
  %3613 = load i32, ptr %3612, align 4
  %3614 = select i1 %3604, i32 16, i32 %3613
  store i32 %3614, ptr %3612, align 4
  %3615 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3608
  %3616 = load i32, ptr %3615, align 4
  %3617 = select i1 %3604, i32 %3603, i32 %3616
  store i32 %3617, ptr %3615, align 4
  %3618 = add i32 %3605, 1
  %3619 = select i1 %3604, i32 %3618, i32 %3605
  store i32 %3619, ptr %ready.count, align 4
  %3620 = load <8 x i1>, ptr %runnable.mask, align 1
  %3621 = or <8 x i1> %3620, %381
  store <8 x i1> %3621, ptr %runnable.mask, align 1
  store <8 x i1> %383, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true533:                         ; preds = %varying.coherent528
  store <8 x i1> %374, ptr %current.mask, align 1
  %3622 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  br i1 %3622, label %schedule.16, label %scheduler.loop

varying.coherent.false534:                        ; preds = %varying.coherent528
  store <8 x i1> %374, ptr %current.mask, align 1
  %3623 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %374)
  br i1 %3623, label %schedule.17, label %scheduler.loop

convergence.cascade548:                           ; preds = %convergence.cascade548, %schedule.17
  %convergence.cascade.flow552 = phi <8 x i1> [ %457, %schedule.17 ], [ %3666, %convergence.cascade548 ]
  %convergence.cascade.depth553 = phi i32 [ 0, %schedule.17 ], [ %3667, %convergence.cascade548 ]
  %3624 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow552)
  %3625 = load i32, ptr %current.token, align 4
  %3626 = icmp ne i32 %3625, 0
  %3627 = and i1 %3624, %3626
  %3628 = sub i32 %3625, 1
  %3629 = select i1 %3627, i32 %3628, i32 0
  %3630 = load i8, ptr %frame.active, align 1
  %3631 = trunc i32 %3629 to i8
  %3632 = shl i8 1, %3631
  %3633 = and i8 %3630, %3632
  %3634 = icmp ne i8 %3633, 0
  %3635 = load <8 x i32>, ptr %frame.static.id, align 32
  %3636 = extractelement <8 x i32> %3635, i32 %3629
  %convergence.target.pointer554 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %3636
  %convergence.dynamic.target555 = load i32, ptr %convergence.target.pointer554, align 4
  %3637 = icmp eq i32 %convergence.dynamic.target555, 17
  %3638 = and i1 %3634, %3637
  %3639 = and i1 %3627, %3638
  %3640 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3629
  %3641 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3629
  %3642 = load <8 x i1>, ptr %3640, align 1
  %3643 = load <8 x i1>, ptr %3641, align 1
  %3644 = or <8 x i1> %3643, %convergence.cascade.flow552
  %3645 = load <8 x i1>, ptr %live.mask, align 1
  %3646 = and <8 x i1> %3642, %3645
  %3647 = icmp eq <8 x i1> %3644, %3646
  %3648 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3647)
  %3649 = and i1 %3639, %3648
  %3650 = select i1 %3649, <8 x i1> zeroinitializer, <8 x i1> %3644
  %3651 = select i1 %3639, <8 x i1> %3650, <8 x i1> %3643
  store <8 x i1> %3651, ptr %3641, align 1
  %3652 = select i1 %3649, <8 x i1> zeroinitializer, <8 x i1> %3642
  store <8 x i1> %3652, ptr %3640, align 1
  %3653 = trunc i32 %3629 to i8
  %3654 = shl i8 1, %3653
  %3655 = xor i8 %3654, -1
  %3656 = and i8 %3630, %3655
  %3657 = select i1 %3649, i8 %3656, i8 %3630
  store i8 %3657, ptr %frame.active, align 1
  %.splatinsert556 = insertelement <8 x i1> poison, i1 %3639, i64 0
  %.splat557 = shufflevector <8 x i1> %.splatinsert556, <8 x i1> poison, <8 x i32> zeroinitializer
  %3658 = and <8 x i1> %convergence.cascade.flow552, %.splat557
  %3659 = load <8 x i1>, ptr %runnable.mask, align 1
  %3660 = xor <8 x i1> %3658, splat (i1 true)
  %3661 = and <8 x i1> %3659, %3660
  store <8 x i1> %3661, ptr %runnable.mask, align 1
  %.splatinsert558 = insertelement <8 x i1> poison, i1 %3649, i64 0
  %.splat559 = shufflevector <8 x i1> %.splatinsert558, <8 x i1> poison, <8 x i32> zeroinitializer
  %3662 = select <8 x i1> %.splat559, <8 x i1> %3644, <8 x i1> zeroinitializer
  %3663 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3664 = extractelement <8 x i32> %3663, i32 %3629
  %3665 = select i1 %3649, i32 %3664, i32 %3625
  store i32 %3665, ptr %current.token, align 4
  %.splatinsert560 = insertelement <8 x i1> poison, i1 %3639, i64 0
  %.splat561 = shufflevector <8 x i1> %.splatinsert560, <8 x i1> poison, <8 x i32> zeroinitializer
  %3666 = select <8 x i1> %.splat561, <8 x i1> %3662, <8 x i1> %convergence.cascade.flow552
  %3667 = add i32 %convergence.cascade.depth553, 1
  %3668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3666)
  %3669 = icmp ult i32 %3667, 8
  %3670 = and i1 %3668, %3669
  %3671 = and i1 %3639, %3670
  %convergence.parent.token562 = load i32, ptr %current.token, align 4
  %convergence.parent.present563 = icmp ne i32 %convergence.parent.token562, 0
  %3672 = and i1 %3671, %convergence.parent.present563
  br i1 %3672, label %convergence.cascade548, label %convergence.cascade.exit549

convergence.cascade.exit549:                      ; preds = %convergence.cascade548, %schedule.17
  %convergence.cascade.result564 = phi <8 x i1> [ %457, %schedule.17 ], [ %3666, %convergence.cascade548 ]
  %3673 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result564)
  br i1 %3673, label %convergence.target.17.ready, label %scheduler.loop

convergence.target.17.ready:                      ; preds = %convergence.cascade.exit549
  %3674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result564)
  %3675 = bitcast <8 x i1> %convergence.cascade.result564 to i8
  %3676 = call i8 @llvm.cttz.i8(i8 %3675, i1 false)
  %3677 = zext i8 %3676 to i32
  %3678 = select i1 %3674, i32 %3677, i32 0
  %3679 = load <8 x i64>, ptr %.slot55, align 64
  %3680 = select <8 x i1> %convergence.cascade.result564, <8 x i64> zeroinitializer, <8 x i64> %3679
  store <8 x i64> %3680, ptr %.slot55, align 64
  %3681 = load <8 x float>, ptr %.slot66, align 32
  %3682 = select <8 x i1> %convergence.cascade.result564, <8 x float> zeroinitializer, <8 x float> %3681
  store <8 x float> %3682, ptr %.slot66, align 32
  %3683 = load <8 x float>, ptr %.slot67, align 32
  %3684 = select <8 x i1> %convergence.cascade.result564, <8 x float> zeroinitializer, <8 x float> %3683
  store <8 x float> %3684, ptr %.slot67, align 32
  %3685 = load <8 x float>, ptr %.slot68, align 32
  %3686 = select <8 x i1> %convergence.cascade.result564, <8 x float> zeroinitializer, <8 x float> %3685
  store <8 x float> %3686, ptr %.slot68, align 32
  %3687 = load <8 x float>, ptr %.slot69, align 32
  %3688 = select <8 x i1> %convergence.cascade.result564, <8 x float> zeroinitializer, <8 x float> %3687
  store <8 x float> %3688, ptr %.slot69, align 32
  store <8 x i1> %convergence.cascade.result564, ptr %current.mask, align 1
  %3689 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result564)
  br i1 %3689, label %schedule.18, label %scheduler.loop

varying.divergent566:                             ; preds = %schedule.18
  %3690 = load i32, ptr %current.token, align 4
  %3691 = icmp ne i32 %3690, 0
  %3692 = sub i32 %3690, 1
  %3693 = select i1 %3691, i32 %3692, i32 0
  %3694 = load i8, ptr %frame.active, align 1
  %3695 = trunc i32 %3693 to i8
  %3696 = shl i8 1, %3695
  %3697 = and i8 %3694, %3696
  %3698 = icmp ne i8 %3697, 0
  %3699 = load <8 x i32>, ptr %frame.static.id, align 32
  %3700 = extractelement <8 x i32> %3699, i32 %3693
  %3701 = icmp eq i32 %3700, 7
  %3702 = and i1 %3698, %3701
  %3703 = and i1 %3691, %3702
  %3704 = xor i1 %3703, true
  %3705 = and i1 true, %3704
  %3706 = xor i8 %3694, -1
  %3707 = icmp ne i8 %3706, 0
  %3708 = xor i1 %3707, true
  %3709 = and i1 %3705, %3708
  br i1 %3709, label %convergence.overflow.trap568, label %convergence.overflow.resume569

varying.coherent567:                              ; preds = %schedule.18
  br i1 %468, label %varying.coherent.true572, label %varying.coherent.false573

convergence.overflow.trap568:                     ; preds = %varying.divergent566
  call void @llvm.trap()
  unreachable

convergence.overflow.resume569:                   ; preds = %varying.divergent566
  %3710 = call i8 @llvm.cttz.i8(i8 %3706, i1 false)
  %3711 = zext i8 %3710 to i32
  %3712 = select i1 %3707, i32 %3711, i32 0
  %3713 = trunc i32 %3712 to i8
  %3714 = shl i8 1, %3713
  %3715 = or i8 %3694, %3714
  %3716 = select i1 %3705, i8 %3715, i8 %3694
  store i8 %3716, ptr %frame.active, align 1
  %3717 = load <8 x i32>, ptr %frame.static.id, align 32
  %3718 = extractelement <8 x i32> %3717, i32 %3712
  %3719 = select i1 %3705, i32 7, i32 %3718
  %3720 = load <8 x i32>, ptr %frame.static.id, align 32
  %3721 = insertelement <8 x i32> %3720, i32 %3719, i32 %3712
  store <8 x i32> %3721, ptr %frame.static.id, align 32
  %3722 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3723 = extractelement <8 x i32> %3722, i32 %3712
  %3724 = select i1 %3705, i32 %3690, i32 %3723
  %3725 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3726 = insertelement <8 x i32> %3725, i32 %3724, i32 %3712
  store <8 x i32> %3726, ptr %frame.parent.token, align 32
  %3727 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3712
  %3728 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3712
  %3729 = load <8 x i1>, ptr %3727, align 1
  %3730 = load <8 x i1>, ptr %3728, align 1
  %3731 = select i1 %3705, <8 x i1> %458, <8 x i1> %3729
  store <8 x i1> %3731, ptr %3727, align 1
  %3732 = select i1 %3705, <8 x i1> zeroinitializer, <8 x i1> %3730
  store <8 x i1> %3732, ptr %3728, align 1
  %3733 = add i32 %3712, 1
  %3734 = select i1 %3703, i32 %3690, i32 %3733
  %3735 = select i1 true, i32 %3734, i32 %3690
  store i32 %3735, ptr %current.token, align 4
  %3736 = load i32, ptr %current.token, align 4
  %3737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %465)
  %3738 = load i32, ptr %ready.count, align 4
  %3739 = icmp uge i32 %3738, 8
  %3740 = and i1 %3737, %3739
  br i1 %3740, label %ready.overflow.trap570, label %ready.overflow.resume571

ready.overflow.trap570:                           ; preds = %convergence.overflow.resume569
  call void @llvm.trap()
  unreachable

ready.overflow.resume571:                         ; preds = %convergence.overflow.resume569
  %3741 = select i1 %3737, i32 %3738, i32 0
  %3742 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3741
  %3743 = load <8 x i1>, ptr %3742, align 1
  %3744 = select i1 %3737, <8 x i1> %465, <8 x i1> %3743
  store <8 x i1> %3744, ptr %3742, align 1
  %3745 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3741
  %3746 = load i32, ptr %3745, align 4
  %3747 = select i1 %3737, i32 19, i32 %3746
  store i32 %3747, ptr %3745, align 4
  %3748 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3741
  %3749 = load i32, ptr %3748, align 4
  %3750 = select i1 %3737, i32 %3736, i32 %3749
  store i32 %3750, ptr %3748, align 4
  %3751 = add i32 %3738, 1
  %3752 = select i1 %3737, i32 %3751, i32 %3738
  store i32 %3752, ptr %ready.count, align 4
  %3753 = load <8 x i1>, ptr %runnable.mask, align 1
  %3754 = or <8 x i1> %3753, %465
  store <8 x i1> %3754, ptr %runnable.mask, align 1
  store <8 x i1> %467, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true572:                         ; preds = %varying.coherent567
  store <8 x i1> %458, ptr %current.mask, align 1
  %3755 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %458)
  br i1 %3755, label %schedule.19, label %scheduler.loop

varying.coherent.false573:                        ; preds = %varying.coherent567
  store <8 x i1> %458, ptr %current.mask, align 1
  %3756 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %458)
  br i1 %3756, label %schedule.20, label %scheduler.loop

convergence.cascade587:                           ; preds = %convergence.cascade587, %schedule.20
  %convergence.cascade.flow591 = phi <8 x i1> [ %541, %schedule.20 ], [ %3799, %convergence.cascade587 ]
  %convergence.cascade.depth592 = phi i32 [ 0, %schedule.20 ], [ %3800, %convergence.cascade587 ]
  %3757 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow591)
  %3758 = load i32, ptr %current.token, align 4
  %3759 = icmp ne i32 %3758, 0
  %3760 = and i1 %3757, %3759
  %3761 = sub i32 %3758, 1
  %3762 = select i1 %3760, i32 %3761, i32 0
  %3763 = load i8, ptr %frame.active, align 1
  %3764 = trunc i32 %3762 to i8
  %3765 = shl i8 1, %3764
  %3766 = and i8 %3763, %3765
  %3767 = icmp ne i8 %3766, 0
  %3768 = load <8 x i32>, ptr %frame.static.id, align 32
  %3769 = extractelement <8 x i32> %3768, i32 %3762
  %convergence.target.pointer593 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %3769
  %convergence.dynamic.target594 = load i32, ptr %convergence.target.pointer593, align 4
  %3770 = icmp eq i32 %convergence.dynamic.target594, 20
  %3771 = and i1 %3767, %3770
  %3772 = and i1 %3760, %3771
  %3773 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3762
  %3774 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3762
  %3775 = load <8 x i1>, ptr %3773, align 1
  %3776 = load <8 x i1>, ptr %3774, align 1
  %3777 = or <8 x i1> %3776, %convergence.cascade.flow591
  %3778 = load <8 x i1>, ptr %live.mask, align 1
  %3779 = and <8 x i1> %3775, %3778
  %3780 = icmp eq <8 x i1> %3777, %3779
  %3781 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3780)
  %3782 = and i1 %3772, %3781
  %3783 = select i1 %3782, <8 x i1> zeroinitializer, <8 x i1> %3777
  %3784 = select i1 %3772, <8 x i1> %3783, <8 x i1> %3776
  store <8 x i1> %3784, ptr %3774, align 1
  %3785 = select i1 %3782, <8 x i1> zeroinitializer, <8 x i1> %3775
  store <8 x i1> %3785, ptr %3773, align 1
  %3786 = trunc i32 %3762 to i8
  %3787 = shl i8 1, %3786
  %3788 = xor i8 %3787, -1
  %3789 = and i8 %3763, %3788
  %3790 = select i1 %3782, i8 %3789, i8 %3763
  store i8 %3790, ptr %frame.active, align 1
  %.splatinsert595 = insertelement <8 x i1> poison, i1 %3772, i64 0
  %.splat596 = shufflevector <8 x i1> %.splatinsert595, <8 x i1> poison, <8 x i32> zeroinitializer
  %3791 = and <8 x i1> %convergence.cascade.flow591, %.splat596
  %3792 = load <8 x i1>, ptr %runnable.mask, align 1
  %3793 = xor <8 x i1> %3791, splat (i1 true)
  %3794 = and <8 x i1> %3792, %3793
  store <8 x i1> %3794, ptr %runnable.mask, align 1
  %.splatinsert597 = insertelement <8 x i1> poison, i1 %3782, i64 0
  %.splat598 = shufflevector <8 x i1> %.splatinsert597, <8 x i1> poison, <8 x i32> zeroinitializer
  %3795 = select <8 x i1> %.splat598, <8 x i1> %3777, <8 x i1> zeroinitializer
  %3796 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3797 = extractelement <8 x i32> %3796, i32 %3762
  %3798 = select i1 %3782, i32 %3797, i32 %3758
  store i32 %3798, ptr %current.token, align 4
  %.splatinsert599 = insertelement <8 x i1> poison, i1 %3772, i64 0
  %.splat600 = shufflevector <8 x i1> %.splatinsert599, <8 x i1> poison, <8 x i32> zeroinitializer
  %3799 = select <8 x i1> %.splat600, <8 x i1> %3795, <8 x i1> %convergence.cascade.flow591
  %3800 = add i32 %convergence.cascade.depth592, 1
  %3801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3799)
  %3802 = icmp ult i32 %3800, 8
  %3803 = and i1 %3801, %3802
  %3804 = and i1 %3772, %3803
  %convergence.parent.token601 = load i32, ptr %current.token, align 4
  %convergence.parent.present602 = icmp ne i32 %convergence.parent.token601, 0
  %3805 = and i1 %3804, %convergence.parent.present602
  br i1 %3805, label %convergence.cascade587, label %convergence.cascade.exit588

convergence.cascade.exit588:                      ; preds = %convergence.cascade587, %schedule.20
  %convergence.cascade.result603 = phi <8 x i1> [ %541, %schedule.20 ], [ %3799, %convergence.cascade587 ]
  %3806 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result603)
  br i1 %3806, label %convergence.target.20.ready, label %scheduler.loop

convergence.target.20.ready:                      ; preds = %convergence.cascade.exit588
  %3807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result603)
  %3808 = bitcast <8 x i1> %convergence.cascade.result603 to i8
  %3809 = call i8 @llvm.cttz.i8(i8 %3808, i1 false)
  %3810 = zext i8 %3809 to i32
  %3811 = select i1 %3807, i32 %3810, i32 0
  %3812 = load <8 x i64>, ptr %.slot55, align 64
  %3813 = select <8 x i1> %convergence.cascade.result603, <8 x i64> zeroinitializer, <8 x i64> %3812
  store <8 x i64> %3813, ptr %.slot55, align 64
  %3814 = load <8 x float>, ptr %.slot71, align 32
  %3815 = select <8 x i1> %convergence.cascade.result603, <8 x float> zeroinitializer, <8 x float> %3814
  store <8 x float> %3815, ptr %.slot71, align 32
  %3816 = load <8 x float>, ptr %.slot72, align 32
  %3817 = select <8 x i1> %convergence.cascade.result603, <8 x float> zeroinitializer, <8 x float> %3816
  store <8 x float> %3817, ptr %.slot72, align 32
  %3818 = load <8 x float>, ptr %.slot73, align 32
  %3819 = select <8 x i1> %convergence.cascade.result603, <8 x float> zeroinitializer, <8 x float> %3818
  store <8 x float> %3819, ptr %.slot73, align 32
  %3820 = load <8 x float>, ptr %.slot74, align 32
  %3821 = select <8 x i1> %convergence.cascade.result603, <8 x float> zeroinitializer, <8 x float> %3820
  store <8 x float> %3821, ptr %.slot74, align 32
  store <8 x i1> %convergence.cascade.result603, ptr %current.mask, align 1
  %3822 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result603)
  br i1 %3822, label %schedule.21, label %scheduler.loop

varying.divergent605:                             ; preds = %schedule.21
  %3823 = load i32, ptr %current.token, align 4
  %3824 = icmp ne i32 %3823, 0
  %3825 = sub i32 %3823, 1
  %3826 = select i1 %3824, i32 %3825, i32 0
  %3827 = load i8, ptr %frame.active, align 1
  %3828 = trunc i32 %3826 to i8
  %3829 = shl i8 1, %3828
  %3830 = and i8 %3827, %3829
  %3831 = icmp ne i8 %3830, 0
  %3832 = load <8 x i32>, ptr %frame.static.id, align 32
  %3833 = extractelement <8 x i32> %3832, i32 %3826
  %3834 = icmp eq i32 %3833, 8
  %3835 = and i1 %3831, %3834
  %3836 = and i1 %3824, %3835
  %3837 = xor i1 %3836, true
  %3838 = and i1 true, %3837
  %3839 = xor i8 %3827, -1
  %3840 = icmp ne i8 %3839, 0
  %3841 = xor i1 %3840, true
  %3842 = and i1 %3838, %3841
  br i1 %3842, label %convergence.overflow.trap607, label %convergence.overflow.resume608

varying.coherent606:                              ; preds = %schedule.21
  br i1 %552, label %varying.coherent.true611, label %varying.coherent.false612

convergence.overflow.trap607:                     ; preds = %varying.divergent605
  call void @llvm.trap()
  unreachable

convergence.overflow.resume608:                   ; preds = %varying.divergent605
  %3843 = call i8 @llvm.cttz.i8(i8 %3839, i1 false)
  %3844 = zext i8 %3843 to i32
  %3845 = select i1 %3840, i32 %3844, i32 0
  %3846 = trunc i32 %3845 to i8
  %3847 = shl i8 1, %3846
  %3848 = or i8 %3827, %3847
  %3849 = select i1 %3838, i8 %3848, i8 %3827
  store i8 %3849, ptr %frame.active, align 1
  %3850 = load <8 x i32>, ptr %frame.static.id, align 32
  %3851 = extractelement <8 x i32> %3850, i32 %3845
  %3852 = select i1 %3838, i32 8, i32 %3851
  %3853 = load <8 x i32>, ptr %frame.static.id, align 32
  %3854 = insertelement <8 x i32> %3853, i32 %3852, i32 %3845
  store <8 x i32> %3854, ptr %frame.static.id, align 32
  %3855 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3856 = extractelement <8 x i32> %3855, i32 %3845
  %3857 = select i1 %3838, i32 %3823, i32 %3856
  %3858 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3859 = insertelement <8 x i32> %3858, i32 %3857, i32 %3845
  store <8 x i32> %3859, ptr %frame.parent.token, align 32
  %3860 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3845
  %3861 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3845
  %3862 = load <8 x i1>, ptr %3860, align 1
  %3863 = load <8 x i1>, ptr %3861, align 1
  %3864 = select i1 %3838, <8 x i1> %542, <8 x i1> %3862
  store <8 x i1> %3864, ptr %3860, align 1
  %3865 = select i1 %3838, <8 x i1> zeroinitializer, <8 x i1> %3863
  store <8 x i1> %3865, ptr %3861, align 1
  %3866 = add i32 %3845, 1
  %3867 = select i1 %3836, i32 %3823, i32 %3866
  %3868 = select i1 true, i32 %3867, i32 %3823
  store i32 %3868, ptr %current.token, align 4
  %3869 = load i32, ptr %current.token, align 4
  %3870 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %549)
  %3871 = load i32, ptr %ready.count, align 4
  %3872 = icmp uge i32 %3871, 8
  %3873 = and i1 %3870, %3872
  br i1 %3873, label %ready.overflow.trap609, label %ready.overflow.resume610

ready.overflow.trap609:                           ; preds = %convergence.overflow.resume608
  call void @llvm.trap()
  unreachable

ready.overflow.resume610:                         ; preds = %convergence.overflow.resume608
  %3874 = select i1 %3870, i32 %3871, i32 0
  %3875 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %3874
  %3876 = load <8 x i1>, ptr %3875, align 1
  %3877 = select i1 %3870, <8 x i1> %549, <8 x i1> %3876
  store <8 x i1> %3877, ptr %3875, align 1
  %3878 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %3874
  %3879 = load i32, ptr %3878, align 4
  %3880 = select i1 %3870, i32 22, i32 %3879
  store i32 %3880, ptr %3878, align 4
  %3881 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %3874
  %3882 = load i32, ptr %3881, align 4
  %3883 = select i1 %3870, i32 %3869, i32 %3882
  store i32 %3883, ptr %3881, align 4
  %3884 = add i32 %3871, 1
  %3885 = select i1 %3870, i32 %3884, i32 %3871
  store i32 %3885, ptr %ready.count, align 4
  %3886 = load <8 x i1>, ptr %runnable.mask, align 1
  %3887 = or <8 x i1> %3886, %549
  store <8 x i1> %3887, ptr %runnable.mask, align 1
  store <8 x i1> %551, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true611:                         ; preds = %varying.coherent606
  store <8 x i1> %542, ptr %current.mask, align 1
  %3888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %542)
  br i1 %3888, label %schedule.22, label %scheduler.loop

varying.coherent.false612:                        ; preds = %varying.coherent606
  store <8 x i1> %542, ptr %current.mask, align 1
  %3889 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %542)
  br i1 %3889, label %schedule.23, label %scheduler.loop

convergence.cascade626:                           ; preds = %convergence.cascade626, %schedule.23
  %convergence.cascade.flow630 = phi <8 x i1> [ %625, %schedule.23 ], [ %3932, %convergence.cascade626 ]
  %convergence.cascade.depth631 = phi i32 [ 0, %schedule.23 ], [ %3933, %convergence.cascade626 ]
  %3890 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow630)
  %3891 = load i32, ptr %current.token, align 4
  %3892 = icmp ne i32 %3891, 0
  %3893 = and i1 %3890, %3892
  %3894 = sub i32 %3891, 1
  %3895 = select i1 %3893, i32 %3894, i32 0
  %3896 = load i8, ptr %frame.active, align 1
  %3897 = trunc i32 %3895 to i8
  %3898 = shl i8 1, %3897
  %3899 = and i8 %3896, %3898
  %3900 = icmp ne i8 %3899, 0
  %3901 = load <8 x i32>, ptr %frame.static.id, align 32
  %3902 = extractelement <8 x i32> %3901, i32 %3895
  %convergence.target.pointer632 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %3902
  %convergence.dynamic.target633 = load i32, ptr %convergence.target.pointer632, align 4
  %3903 = icmp eq i32 %convergence.dynamic.target633, 23
  %3904 = and i1 %3900, %3903
  %3905 = and i1 %3893, %3904
  %3906 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3895
  %3907 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3895
  %3908 = load <8 x i1>, ptr %3906, align 1
  %3909 = load <8 x i1>, ptr %3907, align 1
  %3910 = or <8 x i1> %3909, %convergence.cascade.flow630
  %3911 = load <8 x i1>, ptr %live.mask, align 1
  %3912 = and <8 x i1> %3908, %3911
  %3913 = icmp eq <8 x i1> %3910, %3912
  %3914 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %3913)
  %3915 = and i1 %3905, %3914
  %3916 = select i1 %3915, <8 x i1> zeroinitializer, <8 x i1> %3910
  %3917 = select i1 %3905, <8 x i1> %3916, <8 x i1> %3909
  store <8 x i1> %3917, ptr %3907, align 1
  %3918 = select i1 %3915, <8 x i1> zeroinitializer, <8 x i1> %3908
  store <8 x i1> %3918, ptr %3906, align 1
  %3919 = trunc i32 %3895 to i8
  %3920 = shl i8 1, %3919
  %3921 = xor i8 %3920, -1
  %3922 = and i8 %3896, %3921
  %3923 = select i1 %3915, i8 %3922, i8 %3896
  store i8 %3923, ptr %frame.active, align 1
  %.splatinsert634 = insertelement <8 x i1> poison, i1 %3905, i64 0
  %.splat635 = shufflevector <8 x i1> %.splatinsert634, <8 x i1> poison, <8 x i32> zeroinitializer
  %3924 = and <8 x i1> %convergence.cascade.flow630, %.splat635
  %3925 = load <8 x i1>, ptr %runnable.mask, align 1
  %3926 = xor <8 x i1> %3924, splat (i1 true)
  %3927 = and <8 x i1> %3925, %3926
  store <8 x i1> %3927, ptr %runnable.mask, align 1
  %.splatinsert636 = insertelement <8 x i1> poison, i1 %3915, i64 0
  %.splat637 = shufflevector <8 x i1> %.splatinsert636, <8 x i1> poison, <8 x i32> zeroinitializer
  %3928 = select <8 x i1> %.splat637, <8 x i1> %3910, <8 x i1> zeroinitializer
  %3929 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3930 = extractelement <8 x i32> %3929, i32 %3895
  %3931 = select i1 %3915, i32 %3930, i32 %3891
  store i32 %3931, ptr %current.token, align 4
  %.splatinsert638 = insertelement <8 x i1> poison, i1 %3905, i64 0
  %.splat639 = shufflevector <8 x i1> %.splatinsert638, <8 x i1> poison, <8 x i32> zeroinitializer
  %3932 = select <8 x i1> %.splat639, <8 x i1> %3928, <8 x i1> %convergence.cascade.flow630
  %3933 = add i32 %convergence.cascade.depth631, 1
  %3934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3932)
  %3935 = icmp ult i32 %3933, 8
  %3936 = and i1 %3934, %3935
  %3937 = and i1 %3905, %3936
  %convergence.parent.token640 = load i32, ptr %current.token, align 4
  %convergence.parent.present641 = icmp ne i32 %convergence.parent.token640, 0
  %3938 = and i1 %3937, %convergence.parent.present641
  br i1 %3938, label %convergence.cascade626, label %convergence.cascade.exit627

convergence.cascade.exit627:                      ; preds = %convergence.cascade626, %schedule.23
  %convergence.cascade.result642 = phi <8 x i1> [ %625, %schedule.23 ], [ %3932, %convergence.cascade626 ]
  %3939 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result642)
  br i1 %3939, label %convergence.target.23.ready, label %scheduler.loop

convergence.target.23.ready:                      ; preds = %convergence.cascade.exit627
  %3940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result642)
  %3941 = bitcast <8 x i1> %convergence.cascade.result642 to i8
  %3942 = call i8 @llvm.cttz.i8(i8 %3941, i1 false)
  %3943 = zext i8 %3942 to i32
  %3944 = select i1 %3940, i32 %3943, i32 0
  %3945 = load <8 x i64>, ptr %.slot55, align 64
  %3946 = select <8 x i1> %convergence.cascade.result642, <8 x i64> zeroinitializer, <8 x i64> %3945
  store <8 x i64> %3946, ptr %.slot55, align 64
  %3947 = load <8 x float>, ptr %.slot76, align 32
  %3948 = select <8 x i1> %convergence.cascade.result642, <8 x float> zeroinitializer, <8 x float> %3947
  store <8 x float> %3948, ptr %.slot76, align 32
  %3949 = load <8 x float>, ptr %.slot77, align 32
  %3950 = select <8 x i1> %convergence.cascade.result642, <8 x float> zeroinitializer, <8 x float> %3949
  store <8 x float> %3950, ptr %.slot77, align 32
  %3951 = load <8 x float>, ptr %.slot78, align 32
  %3952 = select <8 x i1> %convergence.cascade.result642, <8 x float> zeroinitializer, <8 x float> %3951
  store <8 x float> %3952, ptr %.slot78, align 32
  %3953 = load <8 x float>, ptr %.slot79, align 32
  %3954 = select <8 x i1> %convergence.cascade.result642, <8 x float> zeroinitializer, <8 x float> %3953
  store <8 x float> %3954, ptr %.slot79, align 32
  store <8 x i1> %convergence.cascade.result642, ptr %current.mask, align 1
  %3955 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result642)
  br i1 %3955, label %schedule.24, label %scheduler.loop

varying.divergent644:                             ; preds = %schedule.24
  %3956 = load i32, ptr %current.token, align 4
  %3957 = icmp ne i32 %3956, 0
  %3958 = sub i32 %3956, 1
  %3959 = select i1 %3957, i32 %3958, i32 0
  %3960 = load i8, ptr %frame.active, align 1
  %3961 = trunc i32 %3959 to i8
  %3962 = shl i8 1, %3961
  %3963 = and i8 %3960, %3962
  %3964 = icmp ne i8 %3963, 0
  %3965 = load <8 x i32>, ptr %frame.static.id, align 32
  %3966 = extractelement <8 x i32> %3965, i32 %3959
  %3967 = icmp eq i32 %3966, 9
  %3968 = and i1 %3964, %3967
  %3969 = and i1 %3957, %3968
  %3970 = xor i1 %3969, true
  %3971 = and i1 true, %3970
  %3972 = xor i8 %3960, -1
  %3973 = icmp ne i8 %3972, 0
  %3974 = xor i1 %3973, true
  %3975 = and i1 %3971, %3974
  br i1 %3975, label %convergence.overflow.trap646, label %convergence.overflow.resume647

varying.coherent645:                              ; preds = %schedule.24
  br i1 %636, label %varying.coherent.true650, label %varying.coherent.false651

convergence.overflow.trap646:                     ; preds = %varying.divergent644
  call void @llvm.trap()
  unreachable

convergence.overflow.resume647:                   ; preds = %varying.divergent644
  %3976 = call i8 @llvm.cttz.i8(i8 %3972, i1 false)
  %3977 = zext i8 %3976 to i32
  %3978 = select i1 %3973, i32 %3977, i32 0
  %3979 = trunc i32 %3978 to i8
  %3980 = shl i8 1, %3979
  %3981 = or i8 %3960, %3980
  %3982 = select i1 %3971, i8 %3981, i8 %3960
  store i8 %3982, ptr %frame.active, align 1
  %3983 = load <8 x i32>, ptr %frame.static.id, align 32
  %3984 = extractelement <8 x i32> %3983, i32 %3978
  %3985 = select i1 %3971, i32 9, i32 %3984
  %3986 = load <8 x i32>, ptr %frame.static.id, align 32
  %3987 = insertelement <8 x i32> %3986, i32 %3985, i32 %3978
  store <8 x i32> %3987, ptr %frame.static.id, align 32
  %3988 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3989 = extractelement <8 x i32> %3988, i32 %3978
  %3990 = select i1 %3971, i32 %3956, i32 %3989
  %3991 = load <8 x i32>, ptr %frame.parent.token, align 32
  %3992 = insertelement <8 x i32> %3991, i32 %3990, i32 %3978
  store <8 x i32> %3992, ptr %frame.parent.token, align 32
  %3993 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %3978
  %3994 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %3978
  %3995 = load <8 x i1>, ptr %3993, align 1
  %3996 = load <8 x i1>, ptr %3994, align 1
  %3997 = select i1 %3971, <8 x i1> %626, <8 x i1> %3995
  store <8 x i1> %3997, ptr %3993, align 1
  %3998 = select i1 %3971, <8 x i1> zeroinitializer, <8 x i1> %3996
  store <8 x i1> %3998, ptr %3994, align 1
  %3999 = add i32 %3978, 1
  %4000 = select i1 %3969, i32 %3956, i32 %3999
  %4001 = select i1 true, i32 %4000, i32 %3956
  store i32 %4001, ptr %current.token, align 4
  %4002 = load i32, ptr %current.token, align 4
  %4003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %633)
  %4004 = load i32, ptr %ready.count, align 4
  %4005 = icmp uge i32 %4004, 8
  %4006 = and i1 %4003, %4005
  br i1 %4006, label %ready.overflow.trap648, label %ready.overflow.resume649

ready.overflow.trap648:                           ; preds = %convergence.overflow.resume647
  call void @llvm.trap()
  unreachable

ready.overflow.resume649:                         ; preds = %convergence.overflow.resume647
  %4007 = select i1 %4003, i32 %4004, i32 0
  %4008 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4007
  %4009 = load <8 x i1>, ptr %4008, align 1
  %4010 = select i1 %4003, <8 x i1> %633, <8 x i1> %4009
  store <8 x i1> %4010, ptr %4008, align 1
  %4011 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4007
  %4012 = load i32, ptr %4011, align 4
  %4013 = select i1 %4003, i32 25, i32 %4012
  store i32 %4013, ptr %4011, align 4
  %4014 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4007
  %4015 = load i32, ptr %4014, align 4
  %4016 = select i1 %4003, i32 %4002, i32 %4015
  store i32 %4016, ptr %4014, align 4
  %4017 = add i32 %4004, 1
  %4018 = select i1 %4003, i32 %4017, i32 %4004
  store i32 %4018, ptr %ready.count, align 4
  %4019 = load <8 x i1>, ptr %runnable.mask, align 1
  %4020 = or <8 x i1> %4019, %633
  store <8 x i1> %4020, ptr %runnable.mask, align 1
  store <8 x i1> %635, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true650:                         ; preds = %varying.coherent645
  store <8 x i1> %626, ptr %current.mask, align 1
  %4021 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %626)
  br i1 %4021, label %schedule.25, label %scheduler.loop

varying.coherent.false651:                        ; preds = %varying.coherent645
  store <8 x i1> %626, ptr %current.mask, align 1
  %4022 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %626)
  br i1 %4022, label %schedule.26, label %scheduler.loop

convergence.cascade665:                           ; preds = %convergence.cascade665, %schedule.26
  %convergence.cascade.flow669 = phi <8 x i1> [ %709, %schedule.26 ], [ %4065, %convergence.cascade665 ]
  %convergence.cascade.depth670 = phi i32 [ 0, %schedule.26 ], [ %4066, %convergence.cascade665 ]
  %4023 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow669)
  %4024 = load i32, ptr %current.token, align 4
  %4025 = icmp ne i32 %4024, 0
  %4026 = and i1 %4023, %4025
  %4027 = sub i32 %4024, 1
  %4028 = select i1 %4026, i32 %4027, i32 0
  %4029 = load i8, ptr %frame.active, align 1
  %4030 = trunc i32 %4028 to i8
  %4031 = shl i8 1, %4030
  %4032 = and i8 %4029, %4031
  %4033 = icmp ne i8 %4032, 0
  %4034 = load <8 x i32>, ptr %frame.static.id, align 32
  %4035 = extractelement <8 x i32> %4034, i32 %4028
  %convergence.target.pointer671 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %4035
  %convergence.dynamic.target672 = load i32, ptr %convergence.target.pointer671, align 4
  %4036 = icmp eq i32 %convergence.dynamic.target672, 26
  %4037 = and i1 %4033, %4036
  %4038 = and i1 %4026, %4037
  %4039 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4028
  %4040 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4028
  %4041 = load <8 x i1>, ptr %4039, align 1
  %4042 = load <8 x i1>, ptr %4040, align 1
  %4043 = or <8 x i1> %4042, %convergence.cascade.flow669
  %4044 = load <8 x i1>, ptr %live.mask, align 1
  %4045 = and <8 x i1> %4041, %4044
  %4046 = icmp eq <8 x i1> %4043, %4045
  %4047 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4046)
  %4048 = and i1 %4038, %4047
  %4049 = select i1 %4048, <8 x i1> zeroinitializer, <8 x i1> %4043
  %4050 = select i1 %4038, <8 x i1> %4049, <8 x i1> %4042
  store <8 x i1> %4050, ptr %4040, align 1
  %4051 = select i1 %4048, <8 x i1> zeroinitializer, <8 x i1> %4041
  store <8 x i1> %4051, ptr %4039, align 1
  %4052 = trunc i32 %4028 to i8
  %4053 = shl i8 1, %4052
  %4054 = xor i8 %4053, -1
  %4055 = and i8 %4029, %4054
  %4056 = select i1 %4048, i8 %4055, i8 %4029
  store i8 %4056, ptr %frame.active, align 1
  %.splatinsert673 = insertelement <8 x i1> poison, i1 %4038, i64 0
  %.splat674 = shufflevector <8 x i1> %.splatinsert673, <8 x i1> poison, <8 x i32> zeroinitializer
  %4057 = and <8 x i1> %convergence.cascade.flow669, %.splat674
  %4058 = load <8 x i1>, ptr %runnable.mask, align 1
  %4059 = xor <8 x i1> %4057, splat (i1 true)
  %4060 = and <8 x i1> %4058, %4059
  store <8 x i1> %4060, ptr %runnable.mask, align 1
  %.splatinsert675 = insertelement <8 x i1> poison, i1 %4048, i64 0
  %.splat676 = shufflevector <8 x i1> %.splatinsert675, <8 x i1> poison, <8 x i32> zeroinitializer
  %4061 = select <8 x i1> %.splat676, <8 x i1> %4043, <8 x i1> zeroinitializer
  %4062 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4063 = extractelement <8 x i32> %4062, i32 %4028
  %4064 = select i1 %4048, i32 %4063, i32 %4024
  store i32 %4064, ptr %current.token, align 4
  %.splatinsert677 = insertelement <8 x i1> poison, i1 %4038, i64 0
  %.splat678 = shufflevector <8 x i1> %.splatinsert677, <8 x i1> poison, <8 x i32> zeroinitializer
  %4065 = select <8 x i1> %.splat678, <8 x i1> %4061, <8 x i1> %convergence.cascade.flow669
  %4066 = add i32 %convergence.cascade.depth670, 1
  %4067 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4065)
  %4068 = icmp ult i32 %4066, 8
  %4069 = and i1 %4067, %4068
  %4070 = and i1 %4038, %4069
  %convergence.parent.token679 = load i32, ptr %current.token, align 4
  %convergence.parent.present680 = icmp ne i32 %convergence.parent.token679, 0
  %4071 = and i1 %4070, %convergence.parent.present680
  br i1 %4071, label %convergence.cascade665, label %convergence.cascade.exit666

convergence.cascade.exit666:                      ; preds = %convergence.cascade665, %schedule.26
  %convergence.cascade.result681 = phi <8 x i1> [ %709, %schedule.26 ], [ %4065, %convergence.cascade665 ]
  %4072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result681)
  br i1 %4072, label %convergence.target.26.ready, label %scheduler.loop

convergence.target.26.ready:                      ; preds = %convergence.cascade.exit666
  %4073 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result681)
  %4074 = bitcast <8 x i1> %convergence.cascade.result681 to i8
  %4075 = call i8 @llvm.cttz.i8(i8 %4074, i1 false)
  %4076 = zext i8 %4075 to i32
  %4077 = select i1 %4073, i32 %4076, i32 0
  %4078 = load <8 x i64>, ptr %.slot55, align 64
  %4079 = select <8 x i1> %convergence.cascade.result681, <8 x i64> zeroinitializer, <8 x i64> %4078
  store <8 x i64> %4079, ptr %.slot55, align 64
  %4080 = load <8 x float>, ptr %.slot81, align 32
  %4081 = select <8 x i1> %convergence.cascade.result681, <8 x float> zeroinitializer, <8 x float> %4080
  store <8 x float> %4081, ptr %.slot81, align 32
  %4082 = load <8 x float>, ptr %.slot82, align 32
  %4083 = select <8 x i1> %convergence.cascade.result681, <8 x float> zeroinitializer, <8 x float> %4082
  store <8 x float> %4083, ptr %.slot82, align 32
  %4084 = load <8 x float>, ptr %.slot83, align 32
  %4085 = select <8 x i1> %convergence.cascade.result681, <8 x float> zeroinitializer, <8 x float> %4084
  store <8 x float> %4085, ptr %.slot83, align 32
  %4086 = load <8 x float>, ptr %.slot84, align 32
  %4087 = select <8 x i1> %convergence.cascade.result681, <8 x float> zeroinitializer, <8 x float> %4086
  store <8 x float> %4087, ptr %.slot84, align 32
  store <8 x i1> %convergence.cascade.result681, ptr %current.mask, align 1
  %4088 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result681)
  br i1 %4088, label %schedule.27, label %scheduler.loop

varying.divergent683:                             ; preds = %schedule.27
  %4089 = load i32, ptr %current.token, align 4
  %4090 = icmp ne i32 %4089, 0
  %4091 = sub i32 %4089, 1
  %4092 = select i1 %4090, i32 %4091, i32 0
  %4093 = load i8, ptr %frame.active, align 1
  %4094 = trunc i32 %4092 to i8
  %4095 = shl i8 1, %4094
  %4096 = and i8 %4093, %4095
  %4097 = icmp ne i8 %4096, 0
  %4098 = load <8 x i32>, ptr %frame.static.id, align 32
  %4099 = extractelement <8 x i32> %4098, i32 %4092
  %4100 = icmp eq i32 %4099, 10
  %4101 = and i1 %4097, %4100
  %4102 = and i1 %4090, %4101
  %4103 = xor i1 %4102, true
  %4104 = and i1 true, %4103
  %4105 = xor i8 %4093, -1
  %4106 = icmp ne i8 %4105, 0
  %4107 = xor i1 %4106, true
  %4108 = and i1 %4104, %4107
  br i1 %4108, label %convergence.overflow.trap685, label %convergence.overflow.resume686

varying.coherent684:                              ; preds = %schedule.27
  br i1 %720, label %varying.coherent.true689, label %varying.coherent.false690

convergence.overflow.trap685:                     ; preds = %varying.divergent683
  call void @llvm.trap()
  unreachable

convergence.overflow.resume686:                   ; preds = %varying.divergent683
  %4109 = call i8 @llvm.cttz.i8(i8 %4105, i1 false)
  %4110 = zext i8 %4109 to i32
  %4111 = select i1 %4106, i32 %4110, i32 0
  %4112 = trunc i32 %4111 to i8
  %4113 = shl i8 1, %4112
  %4114 = or i8 %4093, %4113
  %4115 = select i1 %4104, i8 %4114, i8 %4093
  store i8 %4115, ptr %frame.active, align 1
  %4116 = load <8 x i32>, ptr %frame.static.id, align 32
  %4117 = extractelement <8 x i32> %4116, i32 %4111
  %4118 = select i1 %4104, i32 10, i32 %4117
  %4119 = load <8 x i32>, ptr %frame.static.id, align 32
  %4120 = insertelement <8 x i32> %4119, i32 %4118, i32 %4111
  store <8 x i32> %4120, ptr %frame.static.id, align 32
  %4121 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4122 = extractelement <8 x i32> %4121, i32 %4111
  %4123 = select i1 %4104, i32 %4089, i32 %4122
  %4124 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4125 = insertelement <8 x i32> %4124, i32 %4123, i32 %4111
  store <8 x i32> %4125, ptr %frame.parent.token, align 32
  %4126 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4111
  %4127 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4111
  %4128 = load <8 x i1>, ptr %4126, align 1
  %4129 = load <8 x i1>, ptr %4127, align 1
  %4130 = select i1 %4104, <8 x i1> %710, <8 x i1> %4128
  store <8 x i1> %4130, ptr %4126, align 1
  %4131 = select i1 %4104, <8 x i1> zeroinitializer, <8 x i1> %4129
  store <8 x i1> %4131, ptr %4127, align 1
  %4132 = add i32 %4111, 1
  %4133 = select i1 %4102, i32 %4089, i32 %4132
  %4134 = select i1 true, i32 %4133, i32 %4089
  store i32 %4134, ptr %current.token, align 4
  %4135 = load i32, ptr %current.token, align 4
  %4136 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %717)
  %4137 = load i32, ptr %ready.count, align 4
  %4138 = icmp uge i32 %4137, 8
  %4139 = and i1 %4136, %4138
  br i1 %4139, label %ready.overflow.trap687, label %ready.overflow.resume688

ready.overflow.trap687:                           ; preds = %convergence.overflow.resume686
  call void @llvm.trap()
  unreachable

ready.overflow.resume688:                         ; preds = %convergence.overflow.resume686
  %4140 = select i1 %4136, i32 %4137, i32 0
  %4141 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4140
  %4142 = load <8 x i1>, ptr %4141, align 1
  %4143 = select i1 %4136, <8 x i1> %717, <8 x i1> %4142
  store <8 x i1> %4143, ptr %4141, align 1
  %4144 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4140
  %4145 = load i32, ptr %4144, align 4
  %4146 = select i1 %4136, i32 28, i32 %4145
  store i32 %4146, ptr %4144, align 4
  %4147 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4140
  %4148 = load i32, ptr %4147, align 4
  %4149 = select i1 %4136, i32 %4135, i32 %4148
  store i32 %4149, ptr %4147, align 4
  %4150 = add i32 %4137, 1
  %4151 = select i1 %4136, i32 %4150, i32 %4137
  store i32 %4151, ptr %ready.count, align 4
  %4152 = load <8 x i1>, ptr %runnable.mask, align 1
  %4153 = or <8 x i1> %4152, %717
  store <8 x i1> %4153, ptr %runnable.mask, align 1
  store <8 x i1> %719, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true689:                         ; preds = %varying.coherent684
  store <8 x i1> %710, ptr %current.mask, align 1
  %4154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %710)
  br i1 %4154, label %schedule.28, label %scheduler.loop

varying.coherent.false690:                        ; preds = %varying.coherent684
  store <8 x i1> %710, ptr %current.mask, align 1
  %4155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %710)
  br i1 %4155, label %schedule.29, label %scheduler.loop

convergence.cascade704:                           ; preds = %convergence.cascade704, %schedule.29
  %convergence.cascade.flow708 = phi <8 x i1> [ %793, %schedule.29 ], [ %4198, %convergence.cascade704 ]
  %convergence.cascade.depth709 = phi i32 [ 0, %schedule.29 ], [ %4199, %convergence.cascade704 ]
  %4156 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow708)
  %4157 = load i32, ptr %current.token, align 4
  %4158 = icmp ne i32 %4157, 0
  %4159 = and i1 %4156, %4158
  %4160 = sub i32 %4157, 1
  %4161 = select i1 %4159, i32 %4160, i32 0
  %4162 = load i8, ptr %frame.active, align 1
  %4163 = trunc i32 %4161 to i8
  %4164 = shl i8 1, %4163
  %4165 = and i8 %4162, %4164
  %4166 = icmp ne i8 %4165, 0
  %4167 = load <8 x i32>, ptr %frame.static.id, align 32
  %4168 = extractelement <8 x i32> %4167, i32 %4161
  %convergence.target.pointer710 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %4168
  %convergence.dynamic.target711 = load i32, ptr %convergence.target.pointer710, align 4
  %4169 = icmp eq i32 %convergence.dynamic.target711, 29
  %4170 = and i1 %4166, %4169
  %4171 = and i1 %4159, %4170
  %4172 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4161
  %4173 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4161
  %4174 = load <8 x i1>, ptr %4172, align 1
  %4175 = load <8 x i1>, ptr %4173, align 1
  %4176 = or <8 x i1> %4175, %convergence.cascade.flow708
  %4177 = load <8 x i1>, ptr %live.mask, align 1
  %4178 = and <8 x i1> %4174, %4177
  %4179 = icmp eq <8 x i1> %4176, %4178
  %4180 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4179)
  %4181 = and i1 %4171, %4180
  %4182 = select i1 %4181, <8 x i1> zeroinitializer, <8 x i1> %4176
  %4183 = select i1 %4171, <8 x i1> %4182, <8 x i1> %4175
  store <8 x i1> %4183, ptr %4173, align 1
  %4184 = select i1 %4181, <8 x i1> zeroinitializer, <8 x i1> %4174
  store <8 x i1> %4184, ptr %4172, align 1
  %4185 = trunc i32 %4161 to i8
  %4186 = shl i8 1, %4185
  %4187 = xor i8 %4186, -1
  %4188 = and i8 %4162, %4187
  %4189 = select i1 %4181, i8 %4188, i8 %4162
  store i8 %4189, ptr %frame.active, align 1
  %.splatinsert712 = insertelement <8 x i1> poison, i1 %4171, i64 0
  %.splat713 = shufflevector <8 x i1> %.splatinsert712, <8 x i1> poison, <8 x i32> zeroinitializer
  %4190 = and <8 x i1> %convergence.cascade.flow708, %.splat713
  %4191 = load <8 x i1>, ptr %runnable.mask, align 1
  %4192 = xor <8 x i1> %4190, splat (i1 true)
  %4193 = and <8 x i1> %4191, %4192
  store <8 x i1> %4193, ptr %runnable.mask, align 1
  %.splatinsert714 = insertelement <8 x i1> poison, i1 %4181, i64 0
  %.splat715 = shufflevector <8 x i1> %.splatinsert714, <8 x i1> poison, <8 x i32> zeroinitializer
  %4194 = select <8 x i1> %.splat715, <8 x i1> %4176, <8 x i1> zeroinitializer
  %4195 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4196 = extractelement <8 x i32> %4195, i32 %4161
  %4197 = select i1 %4181, i32 %4196, i32 %4157
  store i32 %4197, ptr %current.token, align 4
  %.splatinsert716 = insertelement <8 x i1> poison, i1 %4171, i64 0
  %.splat717 = shufflevector <8 x i1> %.splatinsert716, <8 x i1> poison, <8 x i32> zeroinitializer
  %4198 = select <8 x i1> %.splat717, <8 x i1> %4194, <8 x i1> %convergence.cascade.flow708
  %4199 = add i32 %convergence.cascade.depth709, 1
  %4200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4198)
  %4201 = icmp ult i32 %4199, 8
  %4202 = and i1 %4200, %4201
  %4203 = and i1 %4171, %4202
  %convergence.parent.token718 = load i32, ptr %current.token, align 4
  %convergence.parent.present719 = icmp ne i32 %convergence.parent.token718, 0
  %4204 = and i1 %4203, %convergence.parent.present719
  br i1 %4204, label %convergence.cascade704, label %convergence.cascade.exit705

convergence.cascade.exit705:                      ; preds = %convergence.cascade704, %schedule.29
  %convergence.cascade.result720 = phi <8 x i1> [ %793, %schedule.29 ], [ %4198, %convergence.cascade704 ]
  %4205 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result720)
  br i1 %4205, label %convergence.target.29.ready, label %scheduler.loop

convergence.target.29.ready:                      ; preds = %convergence.cascade.exit705
  %4206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result720)
  %4207 = bitcast <8 x i1> %convergence.cascade.result720 to i8
  %4208 = call i8 @llvm.cttz.i8(i8 %4207, i1 false)
  %4209 = zext i8 %4208 to i32
  %4210 = select i1 %4206, i32 %4209, i32 0
  %4211 = load <8 x i64>, ptr %.slot55, align 64
  %4212 = select <8 x i1> %convergence.cascade.result720, <8 x i64> zeroinitializer, <8 x i64> %4211
  store <8 x i64> %4212, ptr %.slot55, align 64
  %4213 = load <8 x float>, ptr %.slot86, align 32
  %4214 = select <8 x i1> %convergence.cascade.result720, <8 x float> zeroinitializer, <8 x float> %4213
  store <8 x float> %4214, ptr %.slot86, align 32
  %4215 = load <8 x float>, ptr %.slot87, align 32
  %4216 = select <8 x i1> %convergence.cascade.result720, <8 x float> zeroinitializer, <8 x float> %4215
  store <8 x float> %4216, ptr %.slot87, align 32
  %4217 = load <8 x float>, ptr %.slot88, align 32
  %4218 = select <8 x i1> %convergence.cascade.result720, <8 x float> zeroinitializer, <8 x float> %4217
  store <8 x float> %4218, ptr %.slot88, align 32
  %4219 = load <8 x float>, ptr %.slot89, align 32
  %4220 = select <8 x i1> %convergence.cascade.result720, <8 x float> zeroinitializer, <8 x float> %4219
  store <8 x float> %4220, ptr %.slot89, align 32
  store <8 x i1> %convergence.cascade.result720, ptr %current.mask, align 1
  %4221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result720)
  br i1 %4221, label %schedule.30, label %scheduler.loop

varying.divergent722:                             ; preds = %schedule.30
  %4222 = load i32, ptr %current.token, align 4
  %4223 = icmp ne i32 %4222, 0
  %4224 = sub i32 %4222, 1
  %4225 = select i1 %4223, i32 %4224, i32 0
  %4226 = load i8, ptr %frame.active, align 1
  %4227 = trunc i32 %4225 to i8
  %4228 = shl i8 1, %4227
  %4229 = and i8 %4226, %4228
  %4230 = icmp ne i8 %4229, 0
  %4231 = load <8 x i32>, ptr %frame.static.id, align 32
  %4232 = extractelement <8 x i32> %4231, i32 %4225
  %4233 = icmp eq i32 %4232, 11
  %4234 = and i1 %4230, %4233
  %4235 = and i1 %4223, %4234
  %4236 = xor i1 %4235, true
  %4237 = and i1 true, %4236
  %4238 = xor i8 %4226, -1
  %4239 = icmp ne i8 %4238, 0
  %4240 = xor i1 %4239, true
  %4241 = and i1 %4237, %4240
  br i1 %4241, label %convergence.overflow.trap724, label %convergence.overflow.resume725

varying.coherent723:                              ; preds = %schedule.30
  br i1 %804, label %varying.coherent.true728, label %varying.coherent.false729

convergence.overflow.trap724:                     ; preds = %varying.divergent722
  call void @llvm.trap()
  unreachable

convergence.overflow.resume725:                   ; preds = %varying.divergent722
  %4242 = call i8 @llvm.cttz.i8(i8 %4238, i1 false)
  %4243 = zext i8 %4242 to i32
  %4244 = select i1 %4239, i32 %4243, i32 0
  %4245 = trunc i32 %4244 to i8
  %4246 = shl i8 1, %4245
  %4247 = or i8 %4226, %4246
  %4248 = select i1 %4237, i8 %4247, i8 %4226
  store i8 %4248, ptr %frame.active, align 1
  %4249 = load <8 x i32>, ptr %frame.static.id, align 32
  %4250 = extractelement <8 x i32> %4249, i32 %4244
  %4251 = select i1 %4237, i32 11, i32 %4250
  %4252 = load <8 x i32>, ptr %frame.static.id, align 32
  %4253 = insertelement <8 x i32> %4252, i32 %4251, i32 %4244
  store <8 x i32> %4253, ptr %frame.static.id, align 32
  %4254 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4255 = extractelement <8 x i32> %4254, i32 %4244
  %4256 = select i1 %4237, i32 %4222, i32 %4255
  %4257 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4258 = insertelement <8 x i32> %4257, i32 %4256, i32 %4244
  store <8 x i32> %4258, ptr %frame.parent.token, align 32
  %4259 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4244
  %4260 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4244
  %4261 = load <8 x i1>, ptr %4259, align 1
  %4262 = load <8 x i1>, ptr %4260, align 1
  %4263 = select i1 %4237, <8 x i1> %794, <8 x i1> %4261
  store <8 x i1> %4263, ptr %4259, align 1
  %4264 = select i1 %4237, <8 x i1> zeroinitializer, <8 x i1> %4262
  store <8 x i1> %4264, ptr %4260, align 1
  %4265 = add i32 %4244, 1
  %4266 = select i1 %4235, i32 %4222, i32 %4265
  %4267 = select i1 true, i32 %4266, i32 %4222
  store i32 %4267, ptr %current.token, align 4
  %4268 = load i32, ptr %current.token, align 4
  %4269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %801)
  %4270 = load i32, ptr %ready.count, align 4
  %4271 = icmp uge i32 %4270, 8
  %4272 = and i1 %4269, %4271
  br i1 %4272, label %ready.overflow.trap726, label %ready.overflow.resume727

ready.overflow.trap726:                           ; preds = %convergence.overflow.resume725
  call void @llvm.trap()
  unreachable

ready.overflow.resume727:                         ; preds = %convergence.overflow.resume725
  %4273 = select i1 %4269, i32 %4270, i32 0
  %4274 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4273
  %4275 = load <8 x i1>, ptr %4274, align 1
  %4276 = select i1 %4269, <8 x i1> %801, <8 x i1> %4275
  store <8 x i1> %4276, ptr %4274, align 1
  %4277 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4273
  %4278 = load i32, ptr %4277, align 4
  %4279 = select i1 %4269, i32 31, i32 %4278
  store i32 %4279, ptr %4277, align 4
  %4280 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4273
  %4281 = load i32, ptr %4280, align 4
  %4282 = select i1 %4269, i32 %4268, i32 %4281
  store i32 %4282, ptr %4280, align 4
  %4283 = add i32 %4270, 1
  %4284 = select i1 %4269, i32 %4283, i32 %4270
  store i32 %4284, ptr %ready.count, align 4
  %4285 = load <8 x i1>, ptr %runnable.mask, align 1
  %4286 = or <8 x i1> %4285, %801
  store <8 x i1> %4286, ptr %runnable.mask, align 1
  store <8 x i1> %803, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true728:                         ; preds = %varying.coherent723
  store <8 x i1> %794, ptr %current.mask, align 1
  %4287 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %794)
  br i1 %4287, label %schedule.31, label %scheduler.loop

varying.coherent.false729:                        ; preds = %varying.coherent723
  store <8 x i1> %794, ptr %current.mask, align 1
  %4288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %794)
  br i1 %4288, label %schedule.32, label %scheduler.loop

convergence.cascade743:                           ; preds = %convergence.cascade743, %schedule.32
  %convergence.cascade.flow747 = phi <8 x i1> [ %877, %schedule.32 ], [ %4331, %convergence.cascade743 ]
  %convergence.cascade.depth748 = phi i32 [ 0, %schedule.32 ], [ %4332, %convergence.cascade743 ]
  %4289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow747)
  %4290 = load i32, ptr %current.token, align 4
  %4291 = icmp ne i32 %4290, 0
  %4292 = and i1 %4289, %4291
  %4293 = sub i32 %4290, 1
  %4294 = select i1 %4292, i32 %4293, i32 0
  %4295 = load i8, ptr %frame.active, align 1
  %4296 = trunc i32 %4294 to i8
  %4297 = shl i8 1, %4296
  %4298 = and i8 %4295, %4297
  %4299 = icmp ne i8 %4298, 0
  %4300 = load <8 x i32>, ptr %frame.static.id, align 32
  %4301 = extractelement <8 x i32> %4300, i32 %4294
  %convergence.target.pointer749 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %4301
  %convergence.dynamic.target750 = load i32, ptr %convergence.target.pointer749, align 4
  %4302 = icmp eq i32 %convergence.dynamic.target750, 32
  %4303 = and i1 %4299, %4302
  %4304 = and i1 %4292, %4303
  %4305 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4294
  %4306 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4294
  %4307 = load <8 x i1>, ptr %4305, align 1
  %4308 = load <8 x i1>, ptr %4306, align 1
  %4309 = or <8 x i1> %4308, %convergence.cascade.flow747
  %4310 = load <8 x i1>, ptr %live.mask, align 1
  %4311 = and <8 x i1> %4307, %4310
  %4312 = icmp eq <8 x i1> %4309, %4311
  %4313 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4312)
  %4314 = and i1 %4304, %4313
  %4315 = select i1 %4314, <8 x i1> zeroinitializer, <8 x i1> %4309
  %4316 = select i1 %4304, <8 x i1> %4315, <8 x i1> %4308
  store <8 x i1> %4316, ptr %4306, align 1
  %4317 = select i1 %4314, <8 x i1> zeroinitializer, <8 x i1> %4307
  store <8 x i1> %4317, ptr %4305, align 1
  %4318 = trunc i32 %4294 to i8
  %4319 = shl i8 1, %4318
  %4320 = xor i8 %4319, -1
  %4321 = and i8 %4295, %4320
  %4322 = select i1 %4314, i8 %4321, i8 %4295
  store i8 %4322, ptr %frame.active, align 1
  %.splatinsert751 = insertelement <8 x i1> poison, i1 %4304, i64 0
  %.splat752 = shufflevector <8 x i1> %.splatinsert751, <8 x i1> poison, <8 x i32> zeroinitializer
  %4323 = and <8 x i1> %convergence.cascade.flow747, %.splat752
  %4324 = load <8 x i1>, ptr %runnable.mask, align 1
  %4325 = xor <8 x i1> %4323, splat (i1 true)
  %4326 = and <8 x i1> %4324, %4325
  store <8 x i1> %4326, ptr %runnable.mask, align 1
  %.splatinsert753 = insertelement <8 x i1> poison, i1 %4314, i64 0
  %.splat754 = shufflevector <8 x i1> %.splatinsert753, <8 x i1> poison, <8 x i32> zeroinitializer
  %4327 = select <8 x i1> %.splat754, <8 x i1> %4309, <8 x i1> zeroinitializer
  %4328 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4329 = extractelement <8 x i32> %4328, i32 %4294
  %4330 = select i1 %4314, i32 %4329, i32 %4290
  store i32 %4330, ptr %current.token, align 4
  %.splatinsert755 = insertelement <8 x i1> poison, i1 %4304, i64 0
  %.splat756 = shufflevector <8 x i1> %.splatinsert755, <8 x i1> poison, <8 x i32> zeroinitializer
  %4331 = select <8 x i1> %.splat756, <8 x i1> %4327, <8 x i1> %convergence.cascade.flow747
  %4332 = add i32 %convergence.cascade.depth748, 1
  %4333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4331)
  %4334 = icmp ult i32 %4332, 8
  %4335 = and i1 %4333, %4334
  %4336 = and i1 %4304, %4335
  %convergence.parent.token757 = load i32, ptr %current.token, align 4
  %convergence.parent.present758 = icmp ne i32 %convergence.parent.token757, 0
  %4337 = and i1 %4336, %convergence.parent.present758
  br i1 %4337, label %convergence.cascade743, label %convergence.cascade.exit744

convergence.cascade.exit744:                      ; preds = %convergence.cascade743, %schedule.32
  %convergence.cascade.result759 = phi <8 x i1> [ %877, %schedule.32 ], [ %4331, %convergence.cascade743 ]
  %4338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result759)
  br i1 %4338, label %convergence.target.32.ready, label %scheduler.loop

convergence.target.32.ready:                      ; preds = %convergence.cascade.exit744
  %4339 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result759)
  %4340 = bitcast <8 x i1> %convergence.cascade.result759 to i8
  %4341 = call i8 @llvm.cttz.i8(i8 %4340, i1 false)
  %4342 = zext i8 %4341 to i32
  %4343 = select i1 %4339, i32 %4342, i32 0
  %4344 = load <8 x i64>, ptr %.slot55, align 64
  %4345 = select <8 x i1> %convergence.cascade.result759, <8 x i64> zeroinitializer, <8 x i64> %4344
  store <8 x i64> %4345, ptr %.slot55, align 64
  %4346 = load <8 x float>, ptr %.slot91, align 32
  %4347 = select <8 x i1> %convergence.cascade.result759, <8 x float> zeroinitializer, <8 x float> %4346
  store <8 x float> %4347, ptr %.slot91, align 32
  %4348 = load <8 x float>, ptr %.slot92, align 32
  %4349 = select <8 x i1> %convergence.cascade.result759, <8 x float> zeroinitializer, <8 x float> %4348
  store <8 x float> %4349, ptr %.slot92, align 32
  %4350 = load <8 x float>, ptr %.slot93, align 32
  %4351 = select <8 x i1> %convergence.cascade.result759, <8 x float> zeroinitializer, <8 x float> %4350
  store <8 x float> %4351, ptr %.slot93, align 32
  %4352 = load <8 x float>, ptr %.slot94, align 32
  %4353 = select <8 x i1> %convergence.cascade.result759, <8 x float> zeroinitializer, <8 x float> %4352
  store <8 x float> %4353, ptr %.slot94, align 32
  store <8 x i1> %convergence.cascade.result759, ptr %current.mask, align 1
  %4354 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result759)
  br i1 %4354, label %schedule.33, label %scheduler.loop

varying.divergent761:                             ; preds = %schedule.33
  %4355 = load i32, ptr %current.token, align 4
  %4356 = icmp ne i32 %4355, 0
  %4357 = sub i32 %4355, 1
  %4358 = select i1 %4356, i32 %4357, i32 0
  %4359 = load i8, ptr %frame.active, align 1
  %4360 = trunc i32 %4358 to i8
  %4361 = shl i8 1, %4360
  %4362 = and i8 %4359, %4361
  %4363 = icmp ne i8 %4362, 0
  %4364 = load <8 x i32>, ptr %frame.static.id, align 32
  %4365 = extractelement <8 x i32> %4364, i32 %4358
  %4366 = icmp eq i32 %4365, 12
  %4367 = and i1 %4363, %4366
  %4368 = and i1 %4356, %4367
  %4369 = xor i1 %4368, true
  %4370 = and i1 true, %4369
  %4371 = xor i8 %4359, -1
  %4372 = icmp ne i8 %4371, 0
  %4373 = xor i1 %4372, true
  %4374 = and i1 %4370, %4373
  br i1 %4374, label %convergence.overflow.trap763, label %convergence.overflow.resume764

varying.coherent762:                              ; preds = %schedule.33
  br i1 %888, label %varying.coherent.true767, label %varying.coherent.false768

convergence.overflow.trap763:                     ; preds = %varying.divergent761
  call void @llvm.trap()
  unreachable

convergence.overflow.resume764:                   ; preds = %varying.divergent761
  %4375 = call i8 @llvm.cttz.i8(i8 %4371, i1 false)
  %4376 = zext i8 %4375 to i32
  %4377 = select i1 %4372, i32 %4376, i32 0
  %4378 = trunc i32 %4377 to i8
  %4379 = shl i8 1, %4378
  %4380 = or i8 %4359, %4379
  %4381 = select i1 %4370, i8 %4380, i8 %4359
  store i8 %4381, ptr %frame.active, align 1
  %4382 = load <8 x i32>, ptr %frame.static.id, align 32
  %4383 = extractelement <8 x i32> %4382, i32 %4377
  %4384 = select i1 %4370, i32 12, i32 %4383
  %4385 = load <8 x i32>, ptr %frame.static.id, align 32
  %4386 = insertelement <8 x i32> %4385, i32 %4384, i32 %4377
  store <8 x i32> %4386, ptr %frame.static.id, align 32
  %4387 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4388 = extractelement <8 x i32> %4387, i32 %4377
  %4389 = select i1 %4370, i32 %4355, i32 %4388
  %4390 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4391 = insertelement <8 x i32> %4390, i32 %4389, i32 %4377
  store <8 x i32> %4391, ptr %frame.parent.token, align 32
  %4392 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4377
  %4393 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4377
  %4394 = load <8 x i1>, ptr %4392, align 1
  %4395 = load <8 x i1>, ptr %4393, align 1
  %4396 = select i1 %4370, <8 x i1> %878, <8 x i1> %4394
  store <8 x i1> %4396, ptr %4392, align 1
  %4397 = select i1 %4370, <8 x i1> zeroinitializer, <8 x i1> %4395
  store <8 x i1> %4397, ptr %4393, align 1
  %4398 = add i32 %4377, 1
  %4399 = select i1 %4368, i32 %4355, i32 %4398
  %4400 = select i1 true, i32 %4399, i32 %4355
  store i32 %4400, ptr %current.token, align 4
  %4401 = load i32, ptr %current.token, align 4
  %4402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %885)
  %4403 = load i32, ptr %ready.count, align 4
  %4404 = icmp uge i32 %4403, 8
  %4405 = and i1 %4402, %4404
  br i1 %4405, label %ready.overflow.trap765, label %ready.overflow.resume766

ready.overflow.trap765:                           ; preds = %convergence.overflow.resume764
  call void @llvm.trap()
  unreachable

ready.overflow.resume766:                         ; preds = %convergence.overflow.resume764
  %4406 = select i1 %4402, i32 %4403, i32 0
  %4407 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4406
  %4408 = load <8 x i1>, ptr %4407, align 1
  %4409 = select i1 %4402, <8 x i1> %885, <8 x i1> %4408
  store <8 x i1> %4409, ptr %4407, align 1
  %4410 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4406
  %4411 = load i32, ptr %4410, align 4
  %4412 = select i1 %4402, i32 34, i32 %4411
  store i32 %4412, ptr %4410, align 4
  %4413 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4406
  %4414 = load i32, ptr %4413, align 4
  %4415 = select i1 %4402, i32 %4401, i32 %4414
  store i32 %4415, ptr %4413, align 4
  %4416 = add i32 %4403, 1
  %4417 = select i1 %4402, i32 %4416, i32 %4403
  store i32 %4417, ptr %ready.count, align 4
  %4418 = load <8 x i1>, ptr %runnable.mask, align 1
  %4419 = or <8 x i1> %4418, %885
  store <8 x i1> %4419, ptr %runnable.mask, align 1
  store <8 x i1> %887, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true767:                         ; preds = %varying.coherent762
  store <8 x i1> %878, ptr %current.mask, align 1
  %4420 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %878)
  br i1 %4420, label %schedule.34, label %scheduler.loop

varying.coherent.false768:                        ; preds = %varying.coherent762
  store <8 x i1> %878, ptr %current.mask, align 1
  %4421 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %878)
  br i1 %4421, label %schedule.35, label %scheduler.loop

convergence.cascade782:                           ; preds = %convergence.cascade782, %schedule.35
  %convergence.cascade.flow786 = phi <8 x i1> [ %961, %schedule.35 ], [ %4464, %convergence.cascade782 ]
  %convergence.cascade.depth787 = phi i32 [ 0, %schedule.35 ], [ %4465, %convergence.cascade782 ]
  %4422 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow786)
  %4423 = load i32, ptr %current.token, align 4
  %4424 = icmp ne i32 %4423, 0
  %4425 = and i1 %4422, %4424
  %4426 = sub i32 %4423, 1
  %4427 = select i1 %4425, i32 %4426, i32 0
  %4428 = load i8, ptr %frame.active, align 1
  %4429 = trunc i32 %4427 to i8
  %4430 = shl i8 1, %4429
  %4431 = and i8 %4428, %4430
  %4432 = icmp ne i8 %4431, 0
  %4433 = load <8 x i32>, ptr %frame.static.id, align 32
  %4434 = extractelement <8 x i32> %4433, i32 %4427
  %convergence.target.pointer788 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %4434
  %convergence.dynamic.target789 = load i32, ptr %convergence.target.pointer788, align 4
  %4435 = icmp eq i32 %convergence.dynamic.target789, 35
  %4436 = and i1 %4432, %4435
  %4437 = and i1 %4425, %4436
  %4438 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4427
  %4439 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4427
  %4440 = load <8 x i1>, ptr %4438, align 1
  %4441 = load <8 x i1>, ptr %4439, align 1
  %4442 = or <8 x i1> %4441, %convergence.cascade.flow786
  %4443 = load <8 x i1>, ptr %live.mask, align 1
  %4444 = and <8 x i1> %4440, %4443
  %4445 = icmp eq <8 x i1> %4442, %4444
  %4446 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4445)
  %4447 = and i1 %4437, %4446
  %4448 = select i1 %4447, <8 x i1> zeroinitializer, <8 x i1> %4442
  %4449 = select i1 %4437, <8 x i1> %4448, <8 x i1> %4441
  store <8 x i1> %4449, ptr %4439, align 1
  %4450 = select i1 %4447, <8 x i1> zeroinitializer, <8 x i1> %4440
  store <8 x i1> %4450, ptr %4438, align 1
  %4451 = trunc i32 %4427 to i8
  %4452 = shl i8 1, %4451
  %4453 = xor i8 %4452, -1
  %4454 = and i8 %4428, %4453
  %4455 = select i1 %4447, i8 %4454, i8 %4428
  store i8 %4455, ptr %frame.active, align 1
  %.splatinsert790 = insertelement <8 x i1> poison, i1 %4437, i64 0
  %.splat791 = shufflevector <8 x i1> %.splatinsert790, <8 x i1> poison, <8 x i32> zeroinitializer
  %4456 = and <8 x i1> %convergence.cascade.flow786, %.splat791
  %4457 = load <8 x i1>, ptr %runnable.mask, align 1
  %4458 = xor <8 x i1> %4456, splat (i1 true)
  %4459 = and <8 x i1> %4457, %4458
  store <8 x i1> %4459, ptr %runnable.mask, align 1
  %.splatinsert792 = insertelement <8 x i1> poison, i1 %4447, i64 0
  %.splat793 = shufflevector <8 x i1> %.splatinsert792, <8 x i1> poison, <8 x i32> zeroinitializer
  %4460 = select <8 x i1> %.splat793, <8 x i1> %4442, <8 x i1> zeroinitializer
  %4461 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4462 = extractelement <8 x i32> %4461, i32 %4427
  %4463 = select i1 %4447, i32 %4462, i32 %4423
  store i32 %4463, ptr %current.token, align 4
  %.splatinsert794 = insertelement <8 x i1> poison, i1 %4437, i64 0
  %.splat795 = shufflevector <8 x i1> %.splatinsert794, <8 x i1> poison, <8 x i32> zeroinitializer
  %4464 = select <8 x i1> %.splat795, <8 x i1> %4460, <8 x i1> %convergence.cascade.flow786
  %4465 = add i32 %convergence.cascade.depth787, 1
  %4466 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4464)
  %4467 = icmp ult i32 %4465, 8
  %4468 = and i1 %4466, %4467
  %4469 = and i1 %4437, %4468
  %convergence.parent.token796 = load i32, ptr %current.token, align 4
  %convergence.parent.present797 = icmp ne i32 %convergence.parent.token796, 0
  %4470 = and i1 %4469, %convergence.parent.present797
  br i1 %4470, label %convergence.cascade782, label %convergence.cascade.exit783

convergence.cascade.exit783:                      ; preds = %convergence.cascade782, %schedule.35
  %convergence.cascade.result798 = phi <8 x i1> [ %961, %schedule.35 ], [ %4464, %convergence.cascade782 ]
  %4471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result798)
  br i1 %4471, label %convergence.target.35.ready, label %scheduler.loop

convergence.target.35.ready:                      ; preds = %convergence.cascade.exit783
  %4472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result798)
  %4473 = bitcast <8 x i1> %convergence.cascade.result798 to i8
  %4474 = call i8 @llvm.cttz.i8(i8 %4473, i1 false)
  %4475 = zext i8 %4474 to i32
  %4476 = select i1 %4472, i32 %4475, i32 0
  %4477 = load <8 x i64>, ptr %.slot55, align 64
  %4478 = select <8 x i1> %convergence.cascade.result798, <8 x i64> zeroinitializer, <8 x i64> %4477
  store <8 x i64> %4478, ptr %.slot55, align 64
  %4479 = load <8 x float>, ptr %.slot96, align 32
  %4480 = select <8 x i1> %convergence.cascade.result798, <8 x float> zeroinitializer, <8 x float> %4479
  store <8 x float> %4480, ptr %.slot96, align 32
  %4481 = load <8 x float>, ptr %.slot97, align 32
  %4482 = select <8 x i1> %convergence.cascade.result798, <8 x float> zeroinitializer, <8 x float> %4481
  store <8 x float> %4482, ptr %.slot97, align 32
  %4483 = load <8 x float>, ptr %.slot98, align 32
  %4484 = select <8 x i1> %convergence.cascade.result798, <8 x float> zeroinitializer, <8 x float> %4483
  store <8 x float> %4484, ptr %.slot98, align 32
  %4485 = load <8 x float>, ptr %.slot99, align 32
  %4486 = select <8 x i1> %convergence.cascade.result798, <8 x float> zeroinitializer, <8 x float> %4485
  store <8 x float> %4486, ptr %.slot99, align 32
  store <8 x i1> %convergence.cascade.result798, ptr %current.mask, align 1
  %4487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result798)
  br i1 %4487, label %schedule.36, label %scheduler.loop

varying.divergent800:                             ; preds = %schedule.36
  %4488 = load i32, ptr %current.token, align 4
  %4489 = icmp ne i32 %4488, 0
  %4490 = sub i32 %4488, 1
  %4491 = select i1 %4489, i32 %4490, i32 0
  %4492 = load i8, ptr %frame.active, align 1
  %4493 = trunc i32 %4491 to i8
  %4494 = shl i8 1, %4493
  %4495 = and i8 %4492, %4494
  %4496 = icmp ne i8 %4495, 0
  %4497 = load <8 x i32>, ptr %frame.static.id, align 32
  %4498 = extractelement <8 x i32> %4497, i32 %4491
  %4499 = icmp eq i32 %4498, 13
  %4500 = and i1 %4496, %4499
  %4501 = and i1 %4489, %4500
  %4502 = xor i1 %4501, true
  %4503 = and i1 true, %4502
  %4504 = xor i8 %4492, -1
  %4505 = icmp ne i8 %4504, 0
  %4506 = xor i1 %4505, true
  %4507 = and i1 %4503, %4506
  br i1 %4507, label %convergence.overflow.trap802, label %convergence.overflow.resume803

varying.coherent801:                              ; preds = %schedule.36
  br i1 %972, label %varying.coherent.true806, label %varying.coherent.false807

convergence.overflow.trap802:                     ; preds = %varying.divergent800
  call void @llvm.trap()
  unreachable

convergence.overflow.resume803:                   ; preds = %varying.divergent800
  %4508 = call i8 @llvm.cttz.i8(i8 %4504, i1 false)
  %4509 = zext i8 %4508 to i32
  %4510 = select i1 %4505, i32 %4509, i32 0
  %4511 = trunc i32 %4510 to i8
  %4512 = shl i8 1, %4511
  %4513 = or i8 %4492, %4512
  %4514 = select i1 %4503, i8 %4513, i8 %4492
  store i8 %4514, ptr %frame.active, align 1
  %4515 = load <8 x i32>, ptr %frame.static.id, align 32
  %4516 = extractelement <8 x i32> %4515, i32 %4510
  %4517 = select i1 %4503, i32 13, i32 %4516
  %4518 = load <8 x i32>, ptr %frame.static.id, align 32
  %4519 = insertelement <8 x i32> %4518, i32 %4517, i32 %4510
  store <8 x i32> %4519, ptr %frame.static.id, align 32
  %4520 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4521 = extractelement <8 x i32> %4520, i32 %4510
  %4522 = select i1 %4503, i32 %4488, i32 %4521
  %4523 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4524 = insertelement <8 x i32> %4523, i32 %4522, i32 %4510
  store <8 x i32> %4524, ptr %frame.parent.token, align 32
  %4525 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4510
  %4526 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4510
  %4527 = load <8 x i1>, ptr %4525, align 1
  %4528 = load <8 x i1>, ptr %4526, align 1
  %4529 = select i1 %4503, <8 x i1> %962, <8 x i1> %4527
  store <8 x i1> %4529, ptr %4525, align 1
  %4530 = select i1 %4503, <8 x i1> zeroinitializer, <8 x i1> %4528
  store <8 x i1> %4530, ptr %4526, align 1
  %4531 = add i32 %4510, 1
  %4532 = select i1 %4501, i32 %4488, i32 %4531
  %4533 = select i1 true, i32 %4532, i32 %4488
  store i32 %4533, ptr %current.token, align 4
  %4534 = load i32, ptr %current.token, align 4
  %4535 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %969)
  %4536 = load i32, ptr %ready.count, align 4
  %4537 = icmp uge i32 %4536, 8
  %4538 = and i1 %4535, %4537
  br i1 %4538, label %ready.overflow.trap804, label %ready.overflow.resume805

ready.overflow.trap804:                           ; preds = %convergence.overflow.resume803
  call void @llvm.trap()
  unreachable

ready.overflow.resume805:                         ; preds = %convergence.overflow.resume803
  %4539 = select i1 %4535, i32 %4536, i32 0
  %4540 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4539
  %4541 = load <8 x i1>, ptr %4540, align 1
  %4542 = select i1 %4535, <8 x i1> %969, <8 x i1> %4541
  store <8 x i1> %4542, ptr %4540, align 1
  %4543 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4539
  %4544 = load i32, ptr %4543, align 4
  %4545 = select i1 %4535, i32 37, i32 %4544
  store i32 %4545, ptr %4543, align 4
  %4546 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4539
  %4547 = load i32, ptr %4546, align 4
  %4548 = select i1 %4535, i32 %4534, i32 %4547
  store i32 %4548, ptr %4546, align 4
  %4549 = add i32 %4536, 1
  %4550 = select i1 %4535, i32 %4549, i32 %4536
  store i32 %4550, ptr %ready.count, align 4
  %4551 = load <8 x i1>, ptr %runnable.mask, align 1
  %4552 = or <8 x i1> %4551, %969
  store <8 x i1> %4552, ptr %runnable.mask, align 1
  store <8 x i1> %971, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true806:                         ; preds = %varying.coherent801
  store <8 x i1> %962, ptr %current.mask, align 1
  %4553 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %962)
  br i1 %4553, label %schedule.37, label %scheduler.loop

varying.coherent.false807:                        ; preds = %varying.coherent801
  store <8 x i1> %962, ptr %current.mask, align 1
  %4554 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %962)
  br i1 %4554, label %schedule.38, label %scheduler.loop

convergence.cascade821:                           ; preds = %convergence.cascade821, %schedule.38
  %convergence.cascade.flow825 = phi <8 x i1> [ %1045, %schedule.38 ], [ %4597, %convergence.cascade821 ]
  %convergence.cascade.depth826 = phi i32 [ 0, %schedule.38 ], [ %4598, %convergence.cascade821 ]
  %4555 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow825)
  %4556 = load i32, ptr %current.token, align 4
  %4557 = icmp ne i32 %4556, 0
  %4558 = and i1 %4555, %4557
  %4559 = sub i32 %4556, 1
  %4560 = select i1 %4558, i32 %4559, i32 0
  %4561 = load i8, ptr %frame.active, align 1
  %4562 = trunc i32 %4560 to i8
  %4563 = shl i8 1, %4562
  %4564 = and i8 %4561, %4563
  %4565 = icmp ne i8 %4564, 0
  %4566 = load <8 x i32>, ptr %frame.static.id, align 32
  %4567 = extractelement <8 x i32> %4566, i32 %4560
  %convergence.target.pointer827 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %4567
  %convergence.dynamic.target828 = load i32, ptr %convergence.target.pointer827, align 4
  %4568 = icmp eq i32 %convergence.dynamic.target828, 38
  %4569 = and i1 %4565, %4568
  %4570 = and i1 %4558, %4569
  %4571 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4560
  %4572 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4560
  %4573 = load <8 x i1>, ptr %4571, align 1
  %4574 = load <8 x i1>, ptr %4572, align 1
  %4575 = or <8 x i1> %4574, %convergence.cascade.flow825
  %4576 = load <8 x i1>, ptr %live.mask, align 1
  %4577 = and <8 x i1> %4573, %4576
  %4578 = icmp eq <8 x i1> %4575, %4577
  %4579 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4578)
  %4580 = and i1 %4570, %4579
  %4581 = select i1 %4580, <8 x i1> zeroinitializer, <8 x i1> %4575
  %4582 = select i1 %4570, <8 x i1> %4581, <8 x i1> %4574
  store <8 x i1> %4582, ptr %4572, align 1
  %4583 = select i1 %4580, <8 x i1> zeroinitializer, <8 x i1> %4573
  store <8 x i1> %4583, ptr %4571, align 1
  %4584 = trunc i32 %4560 to i8
  %4585 = shl i8 1, %4584
  %4586 = xor i8 %4585, -1
  %4587 = and i8 %4561, %4586
  %4588 = select i1 %4580, i8 %4587, i8 %4561
  store i8 %4588, ptr %frame.active, align 1
  %.splatinsert829 = insertelement <8 x i1> poison, i1 %4570, i64 0
  %.splat830 = shufflevector <8 x i1> %.splatinsert829, <8 x i1> poison, <8 x i32> zeroinitializer
  %4589 = and <8 x i1> %convergence.cascade.flow825, %.splat830
  %4590 = load <8 x i1>, ptr %runnable.mask, align 1
  %4591 = xor <8 x i1> %4589, splat (i1 true)
  %4592 = and <8 x i1> %4590, %4591
  store <8 x i1> %4592, ptr %runnable.mask, align 1
  %.splatinsert831 = insertelement <8 x i1> poison, i1 %4580, i64 0
  %.splat832 = shufflevector <8 x i1> %.splatinsert831, <8 x i1> poison, <8 x i32> zeroinitializer
  %4593 = select <8 x i1> %.splat832, <8 x i1> %4575, <8 x i1> zeroinitializer
  %4594 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4595 = extractelement <8 x i32> %4594, i32 %4560
  %4596 = select i1 %4580, i32 %4595, i32 %4556
  store i32 %4596, ptr %current.token, align 4
  %.splatinsert833 = insertelement <8 x i1> poison, i1 %4570, i64 0
  %.splat834 = shufflevector <8 x i1> %.splatinsert833, <8 x i1> poison, <8 x i32> zeroinitializer
  %4597 = select <8 x i1> %.splat834, <8 x i1> %4593, <8 x i1> %convergence.cascade.flow825
  %4598 = add i32 %convergence.cascade.depth826, 1
  %4599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4597)
  %4600 = icmp ult i32 %4598, 8
  %4601 = and i1 %4599, %4600
  %4602 = and i1 %4570, %4601
  %convergence.parent.token835 = load i32, ptr %current.token, align 4
  %convergence.parent.present836 = icmp ne i32 %convergence.parent.token835, 0
  %4603 = and i1 %4602, %convergence.parent.present836
  br i1 %4603, label %convergence.cascade821, label %convergence.cascade.exit822

convergence.cascade.exit822:                      ; preds = %convergence.cascade821, %schedule.38
  %convergence.cascade.result837 = phi <8 x i1> [ %1045, %schedule.38 ], [ %4597, %convergence.cascade821 ]
  %4604 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result837)
  br i1 %4604, label %convergence.target.38.ready, label %scheduler.loop

convergence.target.38.ready:                      ; preds = %convergence.cascade.exit822
  %4605 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result837)
  %4606 = bitcast <8 x i1> %convergence.cascade.result837 to i8
  %4607 = call i8 @llvm.cttz.i8(i8 %4606, i1 false)
  %4608 = zext i8 %4607 to i32
  %4609 = select i1 %4605, i32 %4608, i32 0
  %4610 = load <8 x i64>, ptr %.slot55, align 64
  %4611 = select <8 x i1> %convergence.cascade.result837, <8 x i64> zeroinitializer, <8 x i64> %4610
  store <8 x i64> %4611, ptr %.slot55, align 64
  %4612 = load <8 x float>, ptr %.slot101, align 32
  %4613 = select <8 x i1> %convergence.cascade.result837, <8 x float> zeroinitializer, <8 x float> %4612
  store <8 x float> %4613, ptr %.slot101, align 32
  %4614 = load <8 x float>, ptr %.slot102, align 32
  %4615 = select <8 x i1> %convergence.cascade.result837, <8 x float> zeroinitializer, <8 x float> %4614
  store <8 x float> %4615, ptr %.slot102, align 32
  %4616 = load <8 x float>, ptr %.slot103, align 32
  %4617 = select <8 x i1> %convergence.cascade.result837, <8 x float> zeroinitializer, <8 x float> %4616
  store <8 x float> %4617, ptr %.slot103, align 32
  %4618 = load <8 x float>, ptr %.slot104, align 32
  %4619 = select <8 x i1> %convergence.cascade.result837, <8 x float> zeroinitializer, <8 x float> %4618
  store <8 x float> %4619, ptr %.slot104, align 32
  store <8 x i1> %convergence.cascade.result837, ptr %current.mask, align 1
  %4620 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result837)
  br i1 %4620, label %schedule.39, label %scheduler.loop

varying.divergent839:                             ; preds = %schedule.39
  %4621 = load i32, ptr %current.token, align 4
  %4622 = icmp ne i32 %4621, 0
  %4623 = sub i32 %4621, 1
  %4624 = select i1 %4622, i32 %4623, i32 0
  %4625 = load i8, ptr %frame.active, align 1
  %4626 = trunc i32 %4624 to i8
  %4627 = shl i8 1, %4626
  %4628 = and i8 %4625, %4627
  %4629 = icmp ne i8 %4628, 0
  %4630 = load <8 x i32>, ptr %frame.static.id, align 32
  %4631 = extractelement <8 x i32> %4630, i32 %4624
  %4632 = icmp eq i32 %4631, 14
  %4633 = and i1 %4629, %4632
  %4634 = and i1 %4622, %4633
  %4635 = xor i1 %4634, true
  %4636 = and i1 true, %4635
  %4637 = xor i8 %4625, -1
  %4638 = icmp ne i8 %4637, 0
  %4639 = xor i1 %4638, true
  %4640 = and i1 %4636, %4639
  br i1 %4640, label %convergence.overflow.trap841, label %convergence.overflow.resume842

varying.coherent840:                              ; preds = %schedule.39
  br i1 %1056, label %varying.coherent.true845, label %varying.coherent.false846

convergence.overflow.trap841:                     ; preds = %varying.divergent839
  call void @llvm.trap()
  unreachable

convergence.overflow.resume842:                   ; preds = %varying.divergent839
  %4641 = call i8 @llvm.cttz.i8(i8 %4637, i1 false)
  %4642 = zext i8 %4641 to i32
  %4643 = select i1 %4638, i32 %4642, i32 0
  %4644 = trunc i32 %4643 to i8
  %4645 = shl i8 1, %4644
  %4646 = or i8 %4625, %4645
  %4647 = select i1 %4636, i8 %4646, i8 %4625
  store i8 %4647, ptr %frame.active, align 1
  %4648 = load <8 x i32>, ptr %frame.static.id, align 32
  %4649 = extractelement <8 x i32> %4648, i32 %4643
  %4650 = select i1 %4636, i32 14, i32 %4649
  %4651 = load <8 x i32>, ptr %frame.static.id, align 32
  %4652 = insertelement <8 x i32> %4651, i32 %4650, i32 %4643
  store <8 x i32> %4652, ptr %frame.static.id, align 32
  %4653 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4654 = extractelement <8 x i32> %4653, i32 %4643
  %4655 = select i1 %4636, i32 %4621, i32 %4654
  %4656 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4657 = insertelement <8 x i32> %4656, i32 %4655, i32 %4643
  store <8 x i32> %4657, ptr %frame.parent.token, align 32
  %4658 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4643
  %4659 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4643
  %4660 = load <8 x i1>, ptr %4658, align 1
  %4661 = load <8 x i1>, ptr %4659, align 1
  %4662 = select i1 %4636, <8 x i1> %1046, <8 x i1> %4660
  store <8 x i1> %4662, ptr %4658, align 1
  %4663 = select i1 %4636, <8 x i1> zeroinitializer, <8 x i1> %4661
  store <8 x i1> %4663, ptr %4659, align 1
  %4664 = add i32 %4643, 1
  %4665 = select i1 %4634, i32 %4621, i32 %4664
  %4666 = select i1 true, i32 %4665, i32 %4621
  store i32 %4666, ptr %current.token, align 4
  %4667 = load i32, ptr %current.token, align 4
  %4668 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1053)
  %4669 = load i32, ptr %ready.count, align 4
  %4670 = icmp uge i32 %4669, 8
  %4671 = and i1 %4668, %4670
  br i1 %4671, label %ready.overflow.trap843, label %ready.overflow.resume844

ready.overflow.trap843:                           ; preds = %convergence.overflow.resume842
  call void @llvm.trap()
  unreachable

ready.overflow.resume844:                         ; preds = %convergence.overflow.resume842
  %4672 = select i1 %4668, i32 %4669, i32 0
  %4673 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4672
  %4674 = load <8 x i1>, ptr %4673, align 1
  %4675 = select i1 %4668, <8 x i1> %1053, <8 x i1> %4674
  store <8 x i1> %4675, ptr %4673, align 1
  %4676 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4672
  %4677 = load i32, ptr %4676, align 4
  %4678 = select i1 %4668, i32 40, i32 %4677
  store i32 %4678, ptr %4676, align 4
  %4679 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4672
  %4680 = load i32, ptr %4679, align 4
  %4681 = select i1 %4668, i32 %4667, i32 %4680
  store i32 %4681, ptr %4679, align 4
  %4682 = add i32 %4669, 1
  %4683 = select i1 %4668, i32 %4682, i32 %4669
  store i32 %4683, ptr %ready.count, align 4
  %4684 = load <8 x i1>, ptr %runnable.mask, align 1
  %4685 = or <8 x i1> %4684, %1053
  store <8 x i1> %4685, ptr %runnable.mask, align 1
  store <8 x i1> %1055, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true845:                         ; preds = %varying.coherent840
  store <8 x i1> %1046, ptr %current.mask, align 1
  %4686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1046)
  br i1 %4686, label %schedule.40, label %scheduler.loop

varying.coherent.false846:                        ; preds = %varying.coherent840
  store <8 x i1> %1046, ptr %current.mask, align 1
  %4687 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1046)
  br i1 %4687, label %schedule.41, label %scheduler.loop

convergence.cascade858:                           ; preds = %convergence.cascade858, %schedule.41
  %convergence.cascade.flow862 = phi <8 x i1> [ %1127, %schedule.41 ], [ %4730, %convergence.cascade858 ]
  %convergence.cascade.depth863 = phi i32 [ 0, %schedule.41 ], [ %4731, %convergence.cascade858 ]
  %4688 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow862)
  %4689 = load i32, ptr %current.token, align 4
  %4690 = icmp ne i32 %4689, 0
  %4691 = and i1 %4688, %4690
  %4692 = sub i32 %4689, 1
  %4693 = select i1 %4691, i32 %4692, i32 0
  %4694 = load i8, ptr %frame.active, align 1
  %4695 = trunc i32 %4693 to i8
  %4696 = shl i8 1, %4695
  %4697 = and i8 %4694, %4696
  %4698 = icmp ne i8 %4697, 0
  %4699 = load <8 x i32>, ptr %frame.static.id, align 32
  %4700 = extractelement <8 x i32> %4699, i32 %4693
  %convergence.target.pointer864 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %4700
  %convergence.dynamic.target865 = load i32, ptr %convergence.target.pointer864, align 4
  %4701 = icmp eq i32 %convergence.dynamic.target865, 41
  %4702 = and i1 %4698, %4701
  %4703 = and i1 %4691, %4702
  %4704 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4693
  %4705 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4693
  %4706 = load <8 x i1>, ptr %4704, align 1
  %4707 = load <8 x i1>, ptr %4705, align 1
  %4708 = or <8 x i1> %4707, %convergence.cascade.flow862
  %4709 = load <8 x i1>, ptr %live.mask, align 1
  %4710 = and <8 x i1> %4706, %4709
  %4711 = icmp eq <8 x i1> %4708, %4710
  %4712 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4711)
  %4713 = and i1 %4703, %4712
  %4714 = select i1 %4713, <8 x i1> zeroinitializer, <8 x i1> %4708
  %4715 = select i1 %4703, <8 x i1> %4714, <8 x i1> %4707
  store <8 x i1> %4715, ptr %4705, align 1
  %4716 = select i1 %4713, <8 x i1> zeroinitializer, <8 x i1> %4706
  store <8 x i1> %4716, ptr %4704, align 1
  %4717 = trunc i32 %4693 to i8
  %4718 = shl i8 1, %4717
  %4719 = xor i8 %4718, -1
  %4720 = and i8 %4694, %4719
  %4721 = select i1 %4713, i8 %4720, i8 %4694
  store i8 %4721, ptr %frame.active, align 1
  %.splatinsert866 = insertelement <8 x i1> poison, i1 %4703, i64 0
  %.splat867 = shufflevector <8 x i1> %.splatinsert866, <8 x i1> poison, <8 x i32> zeroinitializer
  %4722 = and <8 x i1> %convergence.cascade.flow862, %.splat867
  %4723 = load <8 x i1>, ptr %runnable.mask, align 1
  %4724 = xor <8 x i1> %4722, splat (i1 true)
  %4725 = and <8 x i1> %4723, %4724
  store <8 x i1> %4725, ptr %runnable.mask, align 1
  %.splatinsert868 = insertelement <8 x i1> poison, i1 %4713, i64 0
  %.splat869 = shufflevector <8 x i1> %.splatinsert868, <8 x i1> poison, <8 x i32> zeroinitializer
  %4726 = select <8 x i1> %.splat869, <8 x i1> %4708, <8 x i1> zeroinitializer
  %4727 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4728 = extractelement <8 x i32> %4727, i32 %4693
  %4729 = select i1 %4713, i32 %4728, i32 %4689
  store i32 %4729, ptr %current.token, align 4
  %.splatinsert870 = insertelement <8 x i1> poison, i1 %4703, i64 0
  %.splat871 = shufflevector <8 x i1> %.splatinsert870, <8 x i1> poison, <8 x i32> zeroinitializer
  %4730 = select <8 x i1> %.splat871, <8 x i1> %4726, <8 x i1> %convergence.cascade.flow862
  %4731 = add i32 %convergence.cascade.depth863, 1
  %4732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4730)
  %4733 = icmp ult i32 %4731, 8
  %4734 = and i1 %4732, %4733
  %4735 = and i1 %4703, %4734
  %convergence.parent.token872 = load i32, ptr %current.token, align 4
  %convergence.parent.present873 = icmp ne i32 %convergence.parent.token872, 0
  %4736 = and i1 %4735, %convergence.parent.present873
  br i1 %4736, label %convergence.cascade858, label %convergence.cascade.exit859

convergence.cascade.exit859:                      ; preds = %convergence.cascade858, %schedule.41
  %convergence.cascade.result874 = phi <8 x i1> [ %1127, %schedule.41 ], [ %4730, %convergence.cascade858 ]
  %4737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result874)
  br i1 %4737, label %convergence.target.41.ready, label %scheduler.loop

convergence.target.41.ready:                      ; preds = %convergence.cascade.exit859
  %4738 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result874)
  %4739 = bitcast <8 x i1> %convergence.cascade.result874 to i8
  %4740 = call i8 @llvm.cttz.i8(i8 %4739, i1 false)
  %4741 = zext i8 %4740 to i32
  %4742 = select i1 %4738, i32 %4741, i32 0
  %4743 = load <8 x i64>, ptr %.slot55, align 64
  %4744 = select <8 x i1> %convergence.cascade.result874, <8 x i64> zeroinitializer, <8 x i64> %4743
  store <8 x i64> %4744, ptr %.slot55, align 64
  %4745 = load <8 x float>, ptr %.slot106, align 32
  %4746 = select <8 x i1> %convergence.cascade.result874, <8 x float> zeroinitializer, <8 x float> %4745
  store <8 x float> %4746, ptr %.slot106, align 32
  %4747 = load <8 x float>, ptr %.slot107, align 32
  %4748 = select <8 x i1> %convergence.cascade.result874, <8 x float> zeroinitializer, <8 x float> %4747
  store <8 x float> %4748, ptr %.slot107, align 32
  %4749 = load <8 x float>, ptr %.slot108, align 32
  %4750 = select <8 x i1> %convergence.cascade.result874, <8 x float> zeroinitializer, <8 x float> %4749
  store <8 x float> %4750, ptr %.slot108, align 32
  %4751 = load <8 x float>, ptr %.slot109, align 32
  %4752 = select <8 x i1> %convergence.cascade.result874, <8 x float> zeroinitializer, <8 x float> %4751
  store <8 x float> %4752, ptr %.slot109, align 32
  store <8 x i1> %convergence.cascade.result874, ptr %current.mask, align 1
  %4753 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result874)
  br i1 %4753, label %schedule.42, label %scheduler.loop

varying.divergent876:                             ; preds = %schedule.42
  %4754 = load i32, ptr %current.token, align 4
  %4755 = icmp ne i32 %4754, 0
  %4756 = sub i32 %4754, 1
  %4757 = select i1 %4755, i32 %4756, i32 0
  %4758 = load i8, ptr %frame.active, align 1
  %4759 = trunc i32 %4757 to i8
  %4760 = shl i8 1, %4759
  %4761 = and i8 %4758, %4760
  %4762 = icmp ne i8 %4761, 0
  %4763 = load <8 x i32>, ptr %frame.static.id, align 32
  %4764 = extractelement <8 x i32> %4763, i32 %4757
  %4765 = icmp eq i32 %4764, 15
  %4766 = and i1 %4762, %4765
  %4767 = and i1 %4755, %4766
  %4768 = xor i1 %4767, true
  %4769 = and i1 true, %4768
  %4770 = xor i8 %4758, -1
  %4771 = icmp ne i8 %4770, 0
  %4772 = xor i1 %4771, true
  %4773 = and i1 %4769, %4772
  br i1 %4773, label %convergence.overflow.trap878, label %convergence.overflow.resume879

varying.coherent877:                              ; preds = %schedule.42
  br i1 %1138, label %varying.coherent.true882, label %varying.coherent.false883

convergence.overflow.trap878:                     ; preds = %varying.divergent876
  call void @llvm.trap()
  unreachable

convergence.overflow.resume879:                   ; preds = %varying.divergent876
  %4774 = call i8 @llvm.cttz.i8(i8 %4770, i1 false)
  %4775 = zext i8 %4774 to i32
  %4776 = select i1 %4771, i32 %4775, i32 0
  %4777 = trunc i32 %4776 to i8
  %4778 = shl i8 1, %4777
  %4779 = or i8 %4758, %4778
  %4780 = select i1 %4769, i8 %4779, i8 %4758
  store i8 %4780, ptr %frame.active, align 1
  %4781 = load <8 x i32>, ptr %frame.static.id, align 32
  %4782 = extractelement <8 x i32> %4781, i32 %4776
  %4783 = select i1 %4769, i32 15, i32 %4782
  %4784 = load <8 x i32>, ptr %frame.static.id, align 32
  %4785 = insertelement <8 x i32> %4784, i32 %4783, i32 %4776
  store <8 x i32> %4785, ptr %frame.static.id, align 32
  %4786 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4787 = extractelement <8 x i32> %4786, i32 %4776
  %4788 = select i1 %4769, i32 %4754, i32 %4787
  %4789 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4790 = insertelement <8 x i32> %4789, i32 %4788, i32 %4776
  store <8 x i32> %4790, ptr %frame.parent.token, align 32
  %4791 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4776
  %4792 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4776
  %4793 = load <8 x i1>, ptr %4791, align 1
  %4794 = load <8 x i1>, ptr %4792, align 1
  %4795 = select i1 %4769, <8 x i1> %1128, <8 x i1> %4793
  store <8 x i1> %4795, ptr %4791, align 1
  %4796 = select i1 %4769, <8 x i1> zeroinitializer, <8 x i1> %4794
  store <8 x i1> %4796, ptr %4792, align 1
  %4797 = add i32 %4776, 1
  %4798 = select i1 %4767, i32 %4754, i32 %4797
  %4799 = select i1 true, i32 %4798, i32 %4754
  store i32 %4799, ptr %current.token, align 4
  %4800 = load i32, ptr %current.token, align 4
  %4801 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1135)
  %4802 = load i32, ptr %ready.count, align 4
  %4803 = icmp uge i32 %4802, 8
  %4804 = and i1 %4801, %4803
  br i1 %4804, label %ready.overflow.trap880, label %ready.overflow.resume881

ready.overflow.trap880:                           ; preds = %convergence.overflow.resume879
  call void @llvm.trap()
  unreachable

ready.overflow.resume881:                         ; preds = %convergence.overflow.resume879
  %4805 = select i1 %4801, i32 %4802, i32 0
  %4806 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4805
  %4807 = load <8 x i1>, ptr %4806, align 1
  %4808 = select i1 %4801, <8 x i1> %1135, <8 x i1> %4807
  store <8 x i1> %4808, ptr %4806, align 1
  %4809 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4805
  %4810 = load i32, ptr %4809, align 4
  %4811 = select i1 %4801, i32 43, i32 %4810
  store i32 %4811, ptr %4809, align 4
  %4812 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4805
  %4813 = load i32, ptr %4812, align 4
  %4814 = select i1 %4801, i32 %4800, i32 %4813
  store i32 %4814, ptr %4812, align 4
  %4815 = add i32 %4802, 1
  %4816 = select i1 %4801, i32 %4815, i32 %4802
  store i32 %4816, ptr %ready.count, align 4
  %4817 = load <8 x i1>, ptr %runnable.mask, align 1
  %4818 = or <8 x i1> %4817, %1135
  store <8 x i1> %4818, ptr %runnable.mask, align 1
  store <8 x i1> %1137, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true882:                         ; preds = %varying.coherent877
  store <8 x i1> %1128, ptr %current.mask, align 1
  %4819 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1128)
  br i1 %4819, label %schedule.43, label %scheduler.loop

varying.coherent.false883:                        ; preds = %varying.coherent877
  store <8 x i1> %1128, ptr %current.mask, align 1
  %4820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1128)
  br i1 %4820, label %schedule.44, label %scheduler.loop

convergence.cascade897:                           ; preds = %convergence.cascade897, %schedule.44
  %convergence.cascade.flow901 = phi <8 x i1> [ %1211, %schedule.44 ], [ %4863, %convergence.cascade897 ]
  %convergence.cascade.depth902 = phi i32 [ 0, %schedule.44 ], [ %4864, %convergence.cascade897 ]
  %4821 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow901)
  %4822 = load i32, ptr %current.token, align 4
  %4823 = icmp ne i32 %4822, 0
  %4824 = and i1 %4821, %4823
  %4825 = sub i32 %4822, 1
  %4826 = select i1 %4824, i32 %4825, i32 0
  %4827 = load i8, ptr %frame.active, align 1
  %4828 = trunc i32 %4826 to i8
  %4829 = shl i8 1, %4828
  %4830 = and i8 %4827, %4829
  %4831 = icmp ne i8 %4830, 0
  %4832 = load <8 x i32>, ptr %frame.static.id, align 32
  %4833 = extractelement <8 x i32> %4832, i32 %4826
  %convergence.target.pointer903 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %4833
  %convergence.dynamic.target904 = load i32, ptr %convergence.target.pointer903, align 4
  %4834 = icmp eq i32 %convergence.dynamic.target904, 44
  %4835 = and i1 %4831, %4834
  %4836 = and i1 %4824, %4835
  %4837 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4826
  %4838 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4826
  %4839 = load <8 x i1>, ptr %4837, align 1
  %4840 = load <8 x i1>, ptr %4838, align 1
  %4841 = or <8 x i1> %4840, %convergence.cascade.flow901
  %4842 = load <8 x i1>, ptr %live.mask, align 1
  %4843 = and <8 x i1> %4839, %4842
  %4844 = icmp eq <8 x i1> %4841, %4843
  %4845 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4844)
  %4846 = and i1 %4836, %4845
  %4847 = select i1 %4846, <8 x i1> zeroinitializer, <8 x i1> %4841
  %4848 = select i1 %4836, <8 x i1> %4847, <8 x i1> %4840
  store <8 x i1> %4848, ptr %4838, align 1
  %4849 = select i1 %4846, <8 x i1> zeroinitializer, <8 x i1> %4839
  store <8 x i1> %4849, ptr %4837, align 1
  %4850 = trunc i32 %4826 to i8
  %4851 = shl i8 1, %4850
  %4852 = xor i8 %4851, -1
  %4853 = and i8 %4827, %4852
  %4854 = select i1 %4846, i8 %4853, i8 %4827
  store i8 %4854, ptr %frame.active, align 1
  %.splatinsert905 = insertelement <8 x i1> poison, i1 %4836, i64 0
  %.splat906 = shufflevector <8 x i1> %.splatinsert905, <8 x i1> poison, <8 x i32> zeroinitializer
  %4855 = and <8 x i1> %convergence.cascade.flow901, %.splat906
  %4856 = load <8 x i1>, ptr %runnable.mask, align 1
  %4857 = xor <8 x i1> %4855, splat (i1 true)
  %4858 = and <8 x i1> %4856, %4857
  store <8 x i1> %4858, ptr %runnable.mask, align 1
  %.splatinsert907 = insertelement <8 x i1> poison, i1 %4846, i64 0
  %.splat908 = shufflevector <8 x i1> %.splatinsert907, <8 x i1> poison, <8 x i32> zeroinitializer
  %4859 = select <8 x i1> %.splat908, <8 x i1> %4841, <8 x i1> zeroinitializer
  %4860 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4861 = extractelement <8 x i32> %4860, i32 %4826
  %4862 = select i1 %4846, i32 %4861, i32 %4822
  store i32 %4862, ptr %current.token, align 4
  %.splatinsert909 = insertelement <8 x i1> poison, i1 %4836, i64 0
  %.splat910 = shufflevector <8 x i1> %.splatinsert909, <8 x i1> poison, <8 x i32> zeroinitializer
  %4863 = select <8 x i1> %.splat910, <8 x i1> %4859, <8 x i1> %convergence.cascade.flow901
  %4864 = add i32 %convergence.cascade.depth902, 1
  %4865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4863)
  %4866 = icmp ult i32 %4864, 8
  %4867 = and i1 %4865, %4866
  %4868 = and i1 %4836, %4867
  %convergence.parent.token911 = load i32, ptr %current.token, align 4
  %convergence.parent.present912 = icmp ne i32 %convergence.parent.token911, 0
  %4869 = and i1 %4868, %convergence.parent.present912
  br i1 %4869, label %convergence.cascade897, label %convergence.cascade.exit898

convergence.cascade.exit898:                      ; preds = %convergence.cascade897, %schedule.44
  %convergence.cascade.result913 = phi <8 x i1> [ %1211, %schedule.44 ], [ %4863, %convergence.cascade897 ]
  %4870 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  br i1 %4870, label %convergence.target.44.ready, label %scheduler.loop

convergence.target.44.ready:                      ; preds = %convergence.cascade.exit898
  %4871 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  %4872 = bitcast <8 x i1> %convergence.cascade.result913 to i8
  %4873 = call i8 @llvm.cttz.i8(i8 %4872, i1 false)
  %4874 = zext i8 %4873 to i32
  %4875 = select i1 %4871, i32 %4874, i32 0
  %4876 = load <8 x i64>, ptr %.slot55, align 64
  %4877 = select <8 x i1> %convergence.cascade.result913, <8 x i64> zeroinitializer, <8 x i64> %4876
  store <8 x i64> %4877, ptr %.slot55, align 64
  %4878 = load <8 x float>, ptr %.slot111, align 32
  %4879 = select <8 x i1> %convergence.cascade.result913, <8 x float> zeroinitializer, <8 x float> %4878
  store <8 x float> %4879, ptr %.slot111, align 32
  %4880 = load <8 x float>, ptr %.slot112, align 32
  %4881 = select <8 x i1> %convergence.cascade.result913, <8 x float> zeroinitializer, <8 x float> %4880
  store <8 x float> %4881, ptr %.slot112, align 32
  %4882 = load <8 x float>, ptr %.slot113, align 32
  %4883 = select <8 x i1> %convergence.cascade.result913, <8 x float> zeroinitializer, <8 x float> %4882
  store <8 x float> %4883, ptr %.slot113, align 32
  %4884 = load <8 x float>, ptr %.slot114, align 32
  %4885 = select <8 x i1> %convergence.cascade.result913, <8 x float> zeroinitializer, <8 x float> %4884
  store <8 x float> %4885, ptr %.slot114, align 32
  store <8 x i1> %convergence.cascade.result913, ptr %current.mask, align 1
  %4886 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result913)
  br i1 %4886, label %schedule.45, label %scheduler.loop

varying.divergent915:                             ; preds = %schedule.45
  %4887 = load i32, ptr %current.token, align 4
  %4888 = icmp ne i32 %4887, 0
  %4889 = sub i32 %4887, 1
  %4890 = select i1 %4888, i32 %4889, i32 0
  %4891 = load i8, ptr %frame.active, align 1
  %4892 = trunc i32 %4890 to i8
  %4893 = shl i8 1, %4892
  %4894 = and i8 %4891, %4893
  %4895 = icmp ne i8 %4894, 0
  %4896 = load <8 x i32>, ptr %frame.static.id, align 32
  %4897 = extractelement <8 x i32> %4896, i32 %4890
  %4898 = icmp eq i32 %4897, 16
  %4899 = and i1 %4895, %4898
  %4900 = and i1 %4888, %4899
  %4901 = xor i1 %4900, true
  %4902 = and i1 true, %4901
  %4903 = xor i8 %4891, -1
  %4904 = icmp ne i8 %4903, 0
  %4905 = xor i1 %4904, true
  %4906 = and i1 %4902, %4905
  br i1 %4906, label %convergence.overflow.trap917, label %convergence.overflow.resume918

varying.coherent916:                              ; preds = %schedule.45
  br i1 %1222, label %varying.coherent.true921, label %varying.coherent.false922

convergence.overflow.trap917:                     ; preds = %varying.divergent915
  call void @llvm.trap()
  unreachable

convergence.overflow.resume918:                   ; preds = %varying.divergent915
  %4907 = call i8 @llvm.cttz.i8(i8 %4903, i1 false)
  %4908 = zext i8 %4907 to i32
  %4909 = select i1 %4904, i32 %4908, i32 0
  %4910 = trunc i32 %4909 to i8
  %4911 = shl i8 1, %4910
  %4912 = or i8 %4891, %4911
  %4913 = select i1 %4902, i8 %4912, i8 %4891
  store i8 %4913, ptr %frame.active, align 1
  %4914 = load <8 x i32>, ptr %frame.static.id, align 32
  %4915 = extractelement <8 x i32> %4914, i32 %4909
  %4916 = select i1 %4902, i32 16, i32 %4915
  %4917 = load <8 x i32>, ptr %frame.static.id, align 32
  %4918 = insertelement <8 x i32> %4917, i32 %4916, i32 %4909
  store <8 x i32> %4918, ptr %frame.static.id, align 32
  %4919 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4920 = extractelement <8 x i32> %4919, i32 %4909
  %4921 = select i1 %4902, i32 %4887, i32 %4920
  %4922 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4923 = insertelement <8 x i32> %4922, i32 %4921, i32 %4909
  store <8 x i32> %4923, ptr %frame.parent.token, align 32
  %4924 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4909
  %4925 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4909
  %4926 = load <8 x i1>, ptr %4924, align 1
  %4927 = load <8 x i1>, ptr %4925, align 1
  %4928 = select i1 %4902, <8 x i1> %1212, <8 x i1> %4926
  store <8 x i1> %4928, ptr %4924, align 1
  %4929 = select i1 %4902, <8 x i1> zeroinitializer, <8 x i1> %4927
  store <8 x i1> %4929, ptr %4925, align 1
  %4930 = add i32 %4909, 1
  %4931 = select i1 %4900, i32 %4887, i32 %4930
  %4932 = select i1 true, i32 %4931, i32 %4887
  store i32 %4932, ptr %current.token, align 4
  %4933 = load i32, ptr %current.token, align 4
  %4934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1219)
  %4935 = load i32, ptr %ready.count, align 4
  %4936 = icmp uge i32 %4935, 8
  %4937 = and i1 %4934, %4936
  br i1 %4937, label %ready.overflow.trap919, label %ready.overflow.resume920

ready.overflow.trap919:                           ; preds = %convergence.overflow.resume918
  call void @llvm.trap()
  unreachable

ready.overflow.resume920:                         ; preds = %convergence.overflow.resume918
  %4938 = select i1 %4934, i32 %4935, i32 0
  %4939 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %4938
  %4940 = load <8 x i1>, ptr %4939, align 1
  %4941 = select i1 %4934, <8 x i1> %1219, <8 x i1> %4940
  store <8 x i1> %4941, ptr %4939, align 1
  %4942 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %4938
  %4943 = load i32, ptr %4942, align 4
  %4944 = select i1 %4934, i32 46, i32 %4943
  store i32 %4944, ptr %4942, align 4
  %4945 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %4938
  %4946 = load i32, ptr %4945, align 4
  %4947 = select i1 %4934, i32 %4933, i32 %4946
  store i32 %4947, ptr %4945, align 4
  %4948 = add i32 %4935, 1
  %4949 = select i1 %4934, i32 %4948, i32 %4935
  store i32 %4949, ptr %ready.count, align 4
  %4950 = load <8 x i1>, ptr %runnable.mask, align 1
  %4951 = or <8 x i1> %4950, %1219
  store <8 x i1> %4951, ptr %runnable.mask, align 1
  store <8 x i1> %1221, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true921:                         ; preds = %varying.coherent916
  store <8 x i1> %1212, ptr %current.mask, align 1
  %4952 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1212)
  br i1 %4952, label %schedule.46, label %scheduler.loop

varying.coherent.false922:                        ; preds = %varying.coherent916
  store <8 x i1> %1212, ptr %current.mask, align 1
  %4953 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1212)
  br i1 %4953, label %schedule.47, label %scheduler.loop

convergence.cascade936:                           ; preds = %convergence.cascade936, %schedule.47
  %convergence.cascade.flow940 = phi <8 x i1> [ %1295, %schedule.47 ], [ %4996, %convergence.cascade936 ]
  %convergence.cascade.depth941 = phi i32 [ 0, %schedule.47 ], [ %4997, %convergence.cascade936 ]
  %4954 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow940)
  %4955 = load i32, ptr %current.token, align 4
  %4956 = icmp ne i32 %4955, 0
  %4957 = and i1 %4954, %4956
  %4958 = sub i32 %4955, 1
  %4959 = select i1 %4957, i32 %4958, i32 0
  %4960 = load i8, ptr %frame.active, align 1
  %4961 = trunc i32 %4959 to i8
  %4962 = shl i8 1, %4961
  %4963 = and i8 %4960, %4962
  %4964 = icmp ne i8 %4963, 0
  %4965 = load <8 x i32>, ptr %frame.static.id, align 32
  %4966 = extractelement <8 x i32> %4965, i32 %4959
  %convergence.target.pointer942 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %4966
  %convergence.dynamic.target943 = load i32, ptr %convergence.target.pointer942, align 4
  %4967 = icmp eq i32 %convergence.dynamic.target943, 47
  %4968 = and i1 %4964, %4967
  %4969 = and i1 %4957, %4968
  %4970 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %4959
  %4971 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %4959
  %4972 = load <8 x i1>, ptr %4970, align 1
  %4973 = load <8 x i1>, ptr %4971, align 1
  %4974 = or <8 x i1> %4973, %convergence.cascade.flow940
  %4975 = load <8 x i1>, ptr %live.mask, align 1
  %4976 = and <8 x i1> %4972, %4975
  %4977 = icmp eq <8 x i1> %4974, %4976
  %4978 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %4977)
  %4979 = and i1 %4969, %4978
  %4980 = select i1 %4979, <8 x i1> zeroinitializer, <8 x i1> %4974
  %4981 = select i1 %4969, <8 x i1> %4980, <8 x i1> %4973
  store <8 x i1> %4981, ptr %4971, align 1
  %4982 = select i1 %4979, <8 x i1> zeroinitializer, <8 x i1> %4972
  store <8 x i1> %4982, ptr %4970, align 1
  %4983 = trunc i32 %4959 to i8
  %4984 = shl i8 1, %4983
  %4985 = xor i8 %4984, -1
  %4986 = and i8 %4960, %4985
  %4987 = select i1 %4979, i8 %4986, i8 %4960
  store i8 %4987, ptr %frame.active, align 1
  %.splatinsert944 = insertelement <8 x i1> poison, i1 %4969, i64 0
  %.splat945 = shufflevector <8 x i1> %.splatinsert944, <8 x i1> poison, <8 x i32> zeroinitializer
  %4988 = and <8 x i1> %convergence.cascade.flow940, %.splat945
  %4989 = load <8 x i1>, ptr %runnable.mask, align 1
  %4990 = xor <8 x i1> %4988, splat (i1 true)
  %4991 = and <8 x i1> %4989, %4990
  store <8 x i1> %4991, ptr %runnable.mask, align 1
  %.splatinsert946 = insertelement <8 x i1> poison, i1 %4979, i64 0
  %.splat947 = shufflevector <8 x i1> %.splatinsert946, <8 x i1> poison, <8 x i32> zeroinitializer
  %4992 = select <8 x i1> %.splat947, <8 x i1> %4974, <8 x i1> zeroinitializer
  %4993 = load <8 x i32>, ptr %frame.parent.token, align 32
  %4994 = extractelement <8 x i32> %4993, i32 %4959
  %4995 = select i1 %4979, i32 %4994, i32 %4955
  store i32 %4995, ptr %current.token, align 4
  %.splatinsert948 = insertelement <8 x i1> poison, i1 %4969, i64 0
  %.splat949 = shufflevector <8 x i1> %.splatinsert948, <8 x i1> poison, <8 x i32> zeroinitializer
  %4996 = select <8 x i1> %.splat949, <8 x i1> %4992, <8 x i1> %convergence.cascade.flow940
  %4997 = add i32 %convergence.cascade.depth941, 1
  %4998 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4996)
  %4999 = icmp ult i32 %4997, 8
  %5000 = and i1 %4998, %4999
  %5001 = and i1 %4969, %5000
  %convergence.parent.token950 = load i32, ptr %current.token, align 4
  %convergence.parent.present951 = icmp ne i32 %convergence.parent.token950, 0
  %5002 = and i1 %5001, %convergence.parent.present951
  br i1 %5002, label %convergence.cascade936, label %convergence.cascade.exit937

convergence.cascade.exit937:                      ; preds = %convergence.cascade936, %schedule.47
  %convergence.cascade.result952 = phi <8 x i1> [ %1295, %schedule.47 ], [ %4996, %convergence.cascade936 ]
  %5003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result952)
  br i1 %5003, label %convergence.target.47.ready, label %scheduler.loop

convergence.target.47.ready:                      ; preds = %convergence.cascade.exit937
  %5004 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result952)
  %5005 = bitcast <8 x i1> %convergence.cascade.result952 to i8
  %5006 = call i8 @llvm.cttz.i8(i8 %5005, i1 false)
  %5007 = zext i8 %5006 to i32
  %5008 = select i1 %5004, i32 %5007, i32 0
  %5009 = load <8 x i64>, ptr %.slot55, align 64
  %5010 = select <8 x i1> %convergence.cascade.result952, <8 x i64> zeroinitializer, <8 x i64> %5009
  store <8 x i64> %5010, ptr %.slot55, align 64
  %5011 = load <8 x float>, ptr %.slot116, align 32
  %5012 = select <8 x i1> %convergence.cascade.result952, <8 x float> zeroinitializer, <8 x float> %5011
  store <8 x float> %5012, ptr %.slot116, align 32
  %5013 = load <8 x float>, ptr %.slot117, align 32
  %5014 = select <8 x i1> %convergence.cascade.result952, <8 x float> zeroinitializer, <8 x float> %5013
  store <8 x float> %5014, ptr %.slot117, align 32
  %5015 = load <8 x float>, ptr %.slot118, align 32
  %5016 = select <8 x i1> %convergence.cascade.result952, <8 x float> zeroinitializer, <8 x float> %5015
  store <8 x float> %5016, ptr %.slot118, align 32
  %5017 = load <8 x float>, ptr %.slot119, align 32
  %5018 = select <8 x i1> %convergence.cascade.result952, <8 x float> zeroinitializer, <8 x float> %5017
  store <8 x float> %5018, ptr %.slot119, align 32
  store <8 x i1> %convergence.cascade.result952, ptr %current.mask, align 1
  %5019 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result952)
  br i1 %5019, label %schedule.48, label %scheduler.loop

varying.divergent954:                             ; preds = %schedule.48
  %5020 = load i32, ptr %current.token, align 4
  %5021 = icmp ne i32 %5020, 0
  %5022 = sub i32 %5020, 1
  %5023 = select i1 %5021, i32 %5022, i32 0
  %5024 = load i8, ptr %frame.active, align 1
  %5025 = trunc i32 %5023 to i8
  %5026 = shl i8 1, %5025
  %5027 = and i8 %5024, %5026
  %5028 = icmp ne i8 %5027, 0
  %5029 = load <8 x i32>, ptr %frame.static.id, align 32
  %5030 = extractelement <8 x i32> %5029, i32 %5023
  %5031 = icmp eq i32 %5030, 17
  %5032 = and i1 %5028, %5031
  %5033 = and i1 %5021, %5032
  %5034 = xor i1 %5033, true
  %5035 = and i1 true, %5034
  %5036 = xor i8 %5024, -1
  %5037 = icmp ne i8 %5036, 0
  %5038 = xor i1 %5037, true
  %5039 = and i1 %5035, %5038
  br i1 %5039, label %convergence.overflow.trap956, label %convergence.overflow.resume957

varying.coherent955:                              ; preds = %schedule.48
  br i1 %1306, label %varying.coherent.true960, label %varying.coherent.false961

convergence.overflow.trap956:                     ; preds = %varying.divergent954
  call void @llvm.trap()
  unreachable

convergence.overflow.resume957:                   ; preds = %varying.divergent954
  %5040 = call i8 @llvm.cttz.i8(i8 %5036, i1 false)
  %5041 = zext i8 %5040 to i32
  %5042 = select i1 %5037, i32 %5041, i32 0
  %5043 = trunc i32 %5042 to i8
  %5044 = shl i8 1, %5043
  %5045 = or i8 %5024, %5044
  %5046 = select i1 %5035, i8 %5045, i8 %5024
  store i8 %5046, ptr %frame.active, align 1
  %5047 = load <8 x i32>, ptr %frame.static.id, align 32
  %5048 = extractelement <8 x i32> %5047, i32 %5042
  %5049 = select i1 %5035, i32 17, i32 %5048
  %5050 = load <8 x i32>, ptr %frame.static.id, align 32
  %5051 = insertelement <8 x i32> %5050, i32 %5049, i32 %5042
  store <8 x i32> %5051, ptr %frame.static.id, align 32
  %5052 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5053 = extractelement <8 x i32> %5052, i32 %5042
  %5054 = select i1 %5035, i32 %5020, i32 %5053
  %5055 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5056 = insertelement <8 x i32> %5055, i32 %5054, i32 %5042
  store <8 x i32> %5056, ptr %frame.parent.token, align 32
  %5057 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5042
  %5058 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5042
  %5059 = load <8 x i1>, ptr %5057, align 1
  %5060 = load <8 x i1>, ptr %5058, align 1
  %5061 = select i1 %5035, <8 x i1> %1296, <8 x i1> %5059
  store <8 x i1> %5061, ptr %5057, align 1
  %5062 = select i1 %5035, <8 x i1> zeroinitializer, <8 x i1> %5060
  store <8 x i1> %5062, ptr %5058, align 1
  %5063 = add i32 %5042, 1
  %5064 = select i1 %5033, i32 %5020, i32 %5063
  %5065 = select i1 true, i32 %5064, i32 %5020
  store i32 %5065, ptr %current.token, align 4
  %5066 = load i32, ptr %current.token, align 4
  %5067 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1303)
  %5068 = load i32, ptr %ready.count, align 4
  %5069 = icmp uge i32 %5068, 8
  %5070 = and i1 %5067, %5069
  br i1 %5070, label %ready.overflow.trap958, label %ready.overflow.resume959

ready.overflow.trap958:                           ; preds = %convergence.overflow.resume957
  call void @llvm.trap()
  unreachable

ready.overflow.resume959:                         ; preds = %convergence.overflow.resume957
  %5071 = select i1 %5067, i32 %5068, i32 0
  %5072 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5071
  %5073 = load <8 x i1>, ptr %5072, align 1
  %5074 = select i1 %5067, <8 x i1> %1303, <8 x i1> %5073
  store <8 x i1> %5074, ptr %5072, align 1
  %5075 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5071
  %5076 = load i32, ptr %5075, align 4
  %5077 = select i1 %5067, i32 49, i32 %5076
  store i32 %5077, ptr %5075, align 4
  %5078 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5071
  %5079 = load i32, ptr %5078, align 4
  %5080 = select i1 %5067, i32 %5066, i32 %5079
  store i32 %5080, ptr %5078, align 4
  %5081 = add i32 %5068, 1
  %5082 = select i1 %5067, i32 %5081, i32 %5068
  store i32 %5082, ptr %ready.count, align 4
  %5083 = load <8 x i1>, ptr %runnable.mask, align 1
  %5084 = or <8 x i1> %5083, %1303
  store <8 x i1> %5084, ptr %runnable.mask, align 1
  store <8 x i1> %1305, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true960:                         ; preds = %varying.coherent955
  store <8 x i1> %1296, ptr %current.mask, align 1
  %5085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1296)
  br i1 %5085, label %schedule.49, label %scheduler.loop

varying.coherent.false961:                        ; preds = %varying.coherent955
  store <8 x i1> %1296, ptr %current.mask, align 1
  %5086 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1296)
  br i1 %5086, label %schedule.50, label %scheduler.loop

convergence.cascade975:                           ; preds = %convergence.cascade975, %schedule.50
  %convergence.cascade.flow979 = phi <8 x i1> [ %1379, %schedule.50 ], [ %5129, %convergence.cascade975 ]
  %convergence.cascade.depth980 = phi i32 [ 0, %schedule.50 ], [ %5130, %convergence.cascade975 ]
  %5087 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow979)
  %5088 = load i32, ptr %current.token, align 4
  %5089 = icmp ne i32 %5088, 0
  %5090 = and i1 %5087, %5089
  %5091 = sub i32 %5088, 1
  %5092 = select i1 %5090, i32 %5091, i32 0
  %5093 = load i8, ptr %frame.active, align 1
  %5094 = trunc i32 %5092 to i8
  %5095 = shl i8 1, %5094
  %5096 = and i8 %5093, %5095
  %5097 = icmp ne i8 %5096, 0
  %5098 = load <8 x i32>, ptr %frame.static.id, align 32
  %5099 = extractelement <8 x i32> %5098, i32 %5092
  %convergence.target.pointer981 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %5099
  %convergence.dynamic.target982 = load i32, ptr %convergence.target.pointer981, align 4
  %5100 = icmp eq i32 %convergence.dynamic.target982, 50
  %5101 = and i1 %5097, %5100
  %5102 = and i1 %5090, %5101
  %5103 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5092
  %5104 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5092
  %5105 = load <8 x i1>, ptr %5103, align 1
  %5106 = load <8 x i1>, ptr %5104, align 1
  %5107 = or <8 x i1> %5106, %convergence.cascade.flow979
  %5108 = load <8 x i1>, ptr %live.mask, align 1
  %5109 = and <8 x i1> %5105, %5108
  %5110 = icmp eq <8 x i1> %5107, %5109
  %5111 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5110)
  %5112 = and i1 %5102, %5111
  %5113 = select i1 %5112, <8 x i1> zeroinitializer, <8 x i1> %5107
  %5114 = select i1 %5102, <8 x i1> %5113, <8 x i1> %5106
  store <8 x i1> %5114, ptr %5104, align 1
  %5115 = select i1 %5112, <8 x i1> zeroinitializer, <8 x i1> %5105
  store <8 x i1> %5115, ptr %5103, align 1
  %5116 = trunc i32 %5092 to i8
  %5117 = shl i8 1, %5116
  %5118 = xor i8 %5117, -1
  %5119 = and i8 %5093, %5118
  %5120 = select i1 %5112, i8 %5119, i8 %5093
  store i8 %5120, ptr %frame.active, align 1
  %.splatinsert983 = insertelement <8 x i1> poison, i1 %5102, i64 0
  %.splat984 = shufflevector <8 x i1> %.splatinsert983, <8 x i1> poison, <8 x i32> zeroinitializer
  %5121 = and <8 x i1> %convergence.cascade.flow979, %.splat984
  %5122 = load <8 x i1>, ptr %runnable.mask, align 1
  %5123 = xor <8 x i1> %5121, splat (i1 true)
  %5124 = and <8 x i1> %5122, %5123
  store <8 x i1> %5124, ptr %runnable.mask, align 1
  %.splatinsert985 = insertelement <8 x i1> poison, i1 %5112, i64 0
  %.splat986 = shufflevector <8 x i1> %.splatinsert985, <8 x i1> poison, <8 x i32> zeroinitializer
  %5125 = select <8 x i1> %.splat986, <8 x i1> %5107, <8 x i1> zeroinitializer
  %5126 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5127 = extractelement <8 x i32> %5126, i32 %5092
  %5128 = select i1 %5112, i32 %5127, i32 %5088
  store i32 %5128, ptr %current.token, align 4
  %.splatinsert987 = insertelement <8 x i1> poison, i1 %5102, i64 0
  %.splat988 = shufflevector <8 x i1> %.splatinsert987, <8 x i1> poison, <8 x i32> zeroinitializer
  %5129 = select <8 x i1> %.splat988, <8 x i1> %5125, <8 x i1> %convergence.cascade.flow979
  %5130 = add i32 %convergence.cascade.depth980, 1
  %5131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5129)
  %5132 = icmp ult i32 %5130, 8
  %5133 = and i1 %5131, %5132
  %5134 = and i1 %5102, %5133
  %convergence.parent.token989 = load i32, ptr %current.token, align 4
  %convergence.parent.present990 = icmp ne i32 %convergence.parent.token989, 0
  %5135 = and i1 %5134, %convergence.parent.present990
  br i1 %5135, label %convergence.cascade975, label %convergence.cascade.exit976

convergence.cascade.exit976:                      ; preds = %convergence.cascade975, %schedule.50
  %convergence.cascade.result991 = phi <8 x i1> [ %1379, %schedule.50 ], [ %5129, %convergence.cascade975 ]
  %5136 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result991)
  br i1 %5136, label %convergence.target.50.ready, label %scheduler.loop

convergence.target.50.ready:                      ; preds = %convergence.cascade.exit976
  %5137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result991)
  %5138 = bitcast <8 x i1> %convergence.cascade.result991 to i8
  %5139 = call i8 @llvm.cttz.i8(i8 %5138, i1 false)
  %5140 = zext i8 %5139 to i32
  %5141 = select i1 %5137, i32 %5140, i32 0
  %5142 = load <8 x i64>, ptr %.slot55, align 64
  %5143 = select <8 x i1> %convergence.cascade.result991, <8 x i64> zeroinitializer, <8 x i64> %5142
  store <8 x i64> %5143, ptr %.slot55, align 64
  %5144 = load <8 x float>, ptr %.slot121, align 32
  %5145 = select <8 x i1> %convergence.cascade.result991, <8 x float> zeroinitializer, <8 x float> %5144
  store <8 x float> %5145, ptr %.slot121, align 32
  %5146 = load <8 x float>, ptr %.slot122, align 32
  %5147 = select <8 x i1> %convergence.cascade.result991, <8 x float> zeroinitializer, <8 x float> %5146
  store <8 x float> %5147, ptr %.slot122, align 32
  %5148 = load <8 x float>, ptr %.slot123, align 32
  %5149 = select <8 x i1> %convergence.cascade.result991, <8 x float> zeroinitializer, <8 x float> %5148
  store <8 x float> %5149, ptr %.slot123, align 32
  %5150 = load <8 x float>, ptr %.slot124, align 32
  %5151 = select <8 x i1> %convergence.cascade.result991, <8 x float> zeroinitializer, <8 x float> %5150
  store <8 x float> %5151, ptr %.slot124, align 32
  store <8 x i1> %convergence.cascade.result991, ptr %current.mask, align 1
  %5152 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result991)
  br i1 %5152, label %schedule.51, label %scheduler.loop

varying.divergent993:                             ; preds = %schedule.51
  %5153 = load i32, ptr %current.token, align 4
  %5154 = icmp ne i32 %5153, 0
  %5155 = sub i32 %5153, 1
  %5156 = select i1 %5154, i32 %5155, i32 0
  %5157 = load i8, ptr %frame.active, align 1
  %5158 = trunc i32 %5156 to i8
  %5159 = shl i8 1, %5158
  %5160 = and i8 %5157, %5159
  %5161 = icmp ne i8 %5160, 0
  %5162 = load <8 x i32>, ptr %frame.static.id, align 32
  %5163 = extractelement <8 x i32> %5162, i32 %5156
  %5164 = icmp eq i32 %5163, 18
  %5165 = and i1 %5161, %5164
  %5166 = and i1 %5154, %5165
  %5167 = xor i1 %5166, true
  %5168 = and i1 true, %5167
  %5169 = xor i8 %5157, -1
  %5170 = icmp ne i8 %5169, 0
  %5171 = xor i1 %5170, true
  %5172 = and i1 %5168, %5171
  br i1 %5172, label %convergence.overflow.trap995, label %convergence.overflow.resume996

varying.coherent994:                              ; preds = %schedule.51
  br i1 %1390, label %varying.coherent.true999, label %varying.coherent.false1000

convergence.overflow.trap995:                     ; preds = %varying.divergent993
  call void @llvm.trap()
  unreachable

convergence.overflow.resume996:                   ; preds = %varying.divergent993
  %5173 = call i8 @llvm.cttz.i8(i8 %5169, i1 false)
  %5174 = zext i8 %5173 to i32
  %5175 = select i1 %5170, i32 %5174, i32 0
  %5176 = trunc i32 %5175 to i8
  %5177 = shl i8 1, %5176
  %5178 = or i8 %5157, %5177
  %5179 = select i1 %5168, i8 %5178, i8 %5157
  store i8 %5179, ptr %frame.active, align 1
  %5180 = load <8 x i32>, ptr %frame.static.id, align 32
  %5181 = extractelement <8 x i32> %5180, i32 %5175
  %5182 = select i1 %5168, i32 18, i32 %5181
  %5183 = load <8 x i32>, ptr %frame.static.id, align 32
  %5184 = insertelement <8 x i32> %5183, i32 %5182, i32 %5175
  store <8 x i32> %5184, ptr %frame.static.id, align 32
  %5185 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5186 = extractelement <8 x i32> %5185, i32 %5175
  %5187 = select i1 %5168, i32 %5153, i32 %5186
  %5188 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5189 = insertelement <8 x i32> %5188, i32 %5187, i32 %5175
  store <8 x i32> %5189, ptr %frame.parent.token, align 32
  %5190 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5175
  %5191 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5175
  %5192 = load <8 x i1>, ptr %5190, align 1
  %5193 = load <8 x i1>, ptr %5191, align 1
  %5194 = select i1 %5168, <8 x i1> %1380, <8 x i1> %5192
  store <8 x i1> %5194, ptr %5190, align 1
  %5195 = select i1 %5168, <8 x i1> zeroinitializer, <8 x i1> %5193
  store <8 x i1> %5195, ptr %5191, align 1
  %5196 = add i32 %5175, 1
  %5197 = select i1 %5166, i32 %5153, i32 %5196
  %5198 = select i1 true, i32 %5197, i32 %5153
  store i32 %5198, ptr %current.token, align 4
  %5199 = load i32, ptr %current.token, align 4
  %5200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1387)
  %5201 = load i32, ptr %ready.count, align 4
  %5202 = icmp uge i32 %5201, 8
  %5203 = and i1 %5200, %5202
  br i1 %5203, label %ready.overflow.trap997, label %ready.overflow.resume998

ready.overflow.trap997:                           ; preds = %convergence.overflow.resume996
  call void @llvm.trap()
  unreachable

ready.overflow.resume998:                         ; preds = %convergence.overflow.resume996
  %5204 = select i1 %5200, i32 %5201, i32 0
  %5205 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5204
  %5206 = load <8 x i1>, ptr %5205, align 1
  %5207 = select i1 %5200, <8 x i1> %1387, <8 x i1> %5206
  store <8 x i1> %5207, ptr %5205, align 1
  %5208 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5204
  %5209 = load i32, ptr %5208, align 4
  %5210 = select i1 %5200, i32 52, i32 %5209
  store i32 %5210, ptr %5208, align 4
  %5211 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5204
  %5212 = load i32, ptr %5211, align 4
  %5213 = select i1 %5200, i32 %5199, i32 %5212
  store i32 %5213, ptr %5211, align 4
  %5214 = add i32 %5201, 1
  %5215 = select i1 %5200, i32 %5214, i32 %5201
  store i32 %5215, ptr %ready.count, align 4
  %5216 = load <8 x i1>, ptr %runnable.mask, align 1
  %5217 = or <8 x i1> %5216, %1387
  store <8 x i1> %5217, ptr %runnable.mask, align 1
  store <8 x i1> %1389, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true999:                         ; preds = %varying.coherent994
  store <8 x i1> %1380, ptr %current.mask, align 1
  %5218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1380)
  br i1 %5218, label %schedule.52, label %scheduler.loop

varying.coherent.false1000:                       ; preds = %varying.coherent994
  store <8 x i1> %1380, ptr %current.mask, align 1
  %5219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1380)
  br i1 %5219, label %schedule.53, label %scheduler.loop

convergence.cascade1014:                          ; preds = %convergence.cascade1014, %schedule.53
  %convergence.cascade.flow1018 = phi <8 x i1> [ %1463, %schedule.53 ], [ %5262, %convergence.cascade1014 ]
  %convergence.cascade.depth1019 = phi i32 [ 0, %schedule.53 ], [ %5263, %convergence.cascade1014 ]
  %5220 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1018)
  %5221 = load i32, ptr %current.token, align 4
  %5222 = icmp ne i32 %5221, 0
  %5223 = and i1 %5220, %5222
  %5224 = sub i32 %5221, 1
  %5225 = select i1 %5223, i32 %5224, i32 0
  %5226 = load i8, ptr %frame.active, align 1
  %5227 = trunc i32 %5225 to i8
  %5228 = shl i8 1, %5227
  %5229 = and i8 %5226, %5228
  %5230 = icmp ne i8 %5229, 0
  %5231 = load <8 x i32>, ptr %frame.static.id, align 32
  %5232 = extractelement <8 x i32> %5231, i32 %5225
  %convergence.target.pointer1020 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %5232
  %convergence.dynamic.target1021 = load i32, ptr %convergence.target.pointer1020, align 4
  %5233 = icmp eq i32 %convergence.dynamic.target1021, 53
  %5234 = and i1 %5230, %5233
  %5235 = and i1 %5223, %5234
  %5236 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5225
  %5237 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5225
  %5238 = load <8 x i1>, ptr %5236, align 1
  %5239 = load <8 x i1>, ptr %5237, align 1
  %5240 = or <8 x i1> %5239, %convergence.cascade.flow1018
  %5241 = load <8 x i1>, ptr %live.mask, align 1
  %5242 = and <8 x i1> %5238, %5241
  %5243 = icmp eq <8 x i1> %5240, %5242
  %5244 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5243)
  %5245 = and i1 %5235, %5244
  %5246 = select i1 %5245, <8 x i1> zeroinitializer, <8 x i1> %5240
  %5247 = select i1 %5235, <8 x i1> %5246, <8 x i1> %5239
  store <8 x i1> %5247, ptr %5237, align 1
  %5248 = select i1 %5245, <8 x i1> zeroinitializer, <8 x i1> %5238
  store <8 x i1> %5248, ptr %5236, align 1
  %5249 = trunc i32 %5225 to i8
  %5250 = shl i8 1, %5249
  %5251 = xor i8 %5250, -1
  %5252 = and i8 %5226, %5251
  %5253 = select i1 %5245, i8 %5252, i8 %5226
  store i8 %5253, ptr %frame.active, align 1
  %.splatinsert1022 = insertelement <8 x i1> poison, i1 %5235, i64 0
  %.splat1023 = shufflevector <8 x i1> %.splatinsert1022, <8 x i1> poison, <8 x i32> zeroinitializer
  %5254 = and <8 x i1> %convergence.cascade.flow1018, %.splat1023
  %5255 = load <8 x i1>, ptr %runnable.mask, align 1
  %5256 = xor <8 x i1> %5254, splat (i1 true)
  %5257 = and <8 x i1> %5255, %5256
  store <8 x i1> %5257, ptr %runnable.mask, align 1
  %.splatinsert1024 = insertelement <8 x i1> poison, i1 %5245, i64 0
  %.splat1025 = shufflevector <8 x i1> %.splatinsert1024, <8 x i1> poison, <8 x i32> zeroinitializer
  %5258 = select <8 x i1> %.splat1025, <8 x i1> %5240, <8 x i1> zeroinitializer
  %5259 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5260 = extractelement <8 x i32> %5259, i32 %5225
  %5261 = select i1 %5245, i32 %5260, i32 %5221
  store i32 %5261, ptr %current.token, align 4
  %.splatinsert1026 = insertelement <8 x i1> poison, i1 %5235, i64 0
  %.splat1027 = shufflevector <8 x i1> %.splatinsert1026, <8 x i1> poison, <8 x i32> zeroinitializer
  %5262 = select <8 x i1> %.splat1027, <8 x i1> %5258, <8 x i1> %convergence.cascade.flow1018
  %5263 = add i32 %convergence.cascade.depth1019, 1
  %5264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5262)
  %5265 = icmp ult i32 %5263, 8
  %5266 = and i1 %5264, %5265
  %5267 = and i1 %5235, %5266
  %convergence.parent.token1028 = load i32, ptr %current.token, align 4
  %convergence.parent.present1029 = icmp ne i32 %convergence.parent.token1028, 0
  %5268 = and i1 %5267, %convergence.parent.present1029
  br i1 %5268, label %convergence.cascade1014, label %convergence.cascade.exit1015

convergence.cascade.exit1015:                     ; preds = %convergence.cascade1014, %schedule.53
  %convergence.cascade.result1030 = phi <8 x i1> [ %1463, %schedule.53 ], [ %5262, %convergence.cascade1014 ]
  %5269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1030)
  br i1 %5269, label %convergence.target.53.ready, label %scheduler.loop

convergence.target.53.ready:                      ; preds = %convergence.cascade.exit1015
  %5270 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1030)
  %5271 = bitcast <8 x i1> %convergence.cascade.result1030 to i8
  %5272 = call i8 @llvm.cttz.i8(i8 %5271, i1 false)
  %5273 = zext i8 %5272 to i32
  %5274 = select i1 %5270, i32 %5273, i32 0
  %5275 = load <8 x i64>, ptr %.slot55, align 64
  %5276 = select <8 x i1> %convergence.cascade.result1030, <8 x i64> zeroinitializer, <8 x i64> %5275
  store <8 x i64> %5276, ptr %.slot55, align 64
  %5277 = load <8 x float>, ptr %.slot126, align 32
  %5278 = select <8 x i1> %convergence.cascade.result1030, <8 x float> zeroinitializer, <8 x float> %5277
  store <8 x float> %5278, ptr %.slot126, align 32
  %5279 = load <8 x float>, ptr %.slot127, align 32
  %5280 = select <8 x i1> %convergence.cascade.result1030, <8 x float> zeroinitializer, <8 x float> %5279
  store <8 x float> %5280, ptr %.slot127, align 32
  %5281 = load <8 x float>, ptr %.slot128, align 32
  %5282 = select <8 x i1> %convergence.cascade.result1030, <8 x float> zeroinitializer, <8 x float> %5281
  store <8 x float> %5282, ptr %.slot128, align 32
  %5283 = load <8 x float>, ptr %.slot129, align 32
  %5284 = select <8 x i1> %convergence.cascade.result1030, <8 x float> zeroinitializer, <8 x float> %5283
  store <8 x float> %5284, ptr %.slot129, align 32
  store <8 x i1> %convergence.cascade.result1030, ptr %current.mask, align 1
  %5285 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1030)
  br i1 %5285, label %schedule.54, label %scheduler.loop

varying.divergent1032:                            ; preds = %schedule.54
  %5286 = load i32, ptr %current.token, align 4
  %5287 = icmp ne i32 %5286, 0
  %5288 = sub i32 %5286, 1
  %5289 = select i1 %5287, i32 %5288, i32 0
  %5290 = load i8, ptr %frame.active, align 1
  %5291 = trunc i32 %5289 to i8
  %5292 = shl i8 1, %5291
  %5293 = and i8 %5290, %5292
  %5294 = icmp ne i8 %5293, 0
  %5295 = load <8 x i32>, ptr %frame.static.id, align 32
  %5296 = extractelement <8 x i32> %5295, i32 %5289
  %5297 = icmp eq i32 %5296, 19
  %5298 = and i1 %5294, %5297
  %5299 = and i1 %5287, %5298
  %5300 = xor i1 %5299, true
  %5301 = and i1 true, %5300
  %5302 = xor i8 %5290, -1
  %5303 = icmp ne i8 %5302, 0
  %5304 = xor i1 %5303, true
  %5305 = and i1 %5301, %5304
  br i1 %5305, label %convergence.overflow.trap1034, label %convergence.overflow.resume1035

varying.coherent1033:                             ; preds = %schedule.54
  br i1 %1474, label %varying.coherent.true1038, label %varying.coherent.false1039

convergence.overflow.trap1034:                    ; preds = %varying.divergent1032
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1035:                  ; preds = %varying.divergent1032
  %5306 = call i8 @llvm.cttz.i8(i8 %5302, i1 false)
  %5307 = zext i8 %5306 to i32
  %5308 = select i1 %5303, i32 %5307, i32 0
  %5309 = trunc i32 %5308 to i8
  %5310 = shl i8 1, %5309
  %5311 = or i8 %5290, %5310
  %5312 = select i1 %5301, i8 %5311, i8 %5290
  store i8 %5312, ptr %frame.active, align 1
  %5313 = load <8 x i32>, ptr %frame.static.id, align 32
  %5314 = extractelement <8 x i32> %5313, i32 %5308
  %5315 = select i1 %5301, i32 19, i32 %5314
  %5316 = load <8 x i32>, ptr %frame.static.id, align 32
  %5317 = insertelement <8 x i32> %5316, i32 %5315, i32 %5308
  store <8 x i32> %5317, ptr %frame.static.id, align 32
  %5318 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5319 = extractelement <8 x i32> %5318, i32 %5308
  %5320 = select i1 %5301, i32 %5286, i32 %5319
  %5321 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5322 = insertelement <8 x i32> %5321, i32 %5320, i32 %5308
  store <8 x i32> %5322, ptr %frame.parent.token, align 32
  %5323 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5308
  %5324 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5308
  %5325 = load <8 x i1>, ptr %5323, align 1
  %5326 = load <8 x i1>, ptr %5324, align 1
  %5327 = select i1 %5301, <8 x i1> %1464, <8 x i1> %5325
  store <8 x i1> %5327, ptr %5323, align 1
  %5328 = select i1 %5301, <8 x i1> zeroinitializer, <8 x i1> %5326
  store <8 x i1> %5328, ptr %5324, align 1
  %5329 = add i32 %5308, 1
  %5330 = select i1 %5299, i32 %5286, i32 %5329
  %5331 = select i1 true, i32 %5330, i32 %5286
  store i32 %5331, ptr %current.token, align 4
  %5332 = load i32, ptr %current.token, align 4
  %5333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1471)
  %5334 = load i32, ptr %ready.count, align 4
  %5335 = icmp uge i32 %5334, 8
  %5336 = and i1 %5333, %5335
  br i1 %5336, label %ready.overflow.trap1036, label %ready.overflow.resume1037

ready.overflow.trap1036:                          ; preds = %convergence.overflow.resume1035
  call void @llvm.trap()
  unreachable

ready.overflow.resume1037:                        ; preds = %convergence.overflow.resume1035
  %5337 = select i1 %5333, i32 %5334, i32 0
  %5338 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5337
  %5339 = load <8 x i1>, ptr %5338, align 1
  %5340 = select i1 %5333, <8 x i1> %1471, <8 x i1> %5339
  store <8 x i1> %5340, ptr %5338, align 1
  %5341 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5337
  %5342 = load i32, ptr %5341, align 4
  %5343 = select i1 %5333, i32 55, i32 %5342
  store i32 %5343, ptr %5341, align 4
  %5344 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5337
  %5345 = load i32, ptr %5344, align 4
  %5346 = select i1 %5333, i32 %5332, i32 %5345
  store i32 %5346, ptr %5344, align 4
  %5347 = add i32 %5334, 1
  %5348 = select i1 %5333, i32 %5347, i32 %5334
  store i32 %5348, ptr %ready.count, align 4
  %5349 = load <8 x i1>, ptr %runnable.mask, align 1
  %5350 = or <8 x i1> %5349, %1471
  store <8 x i1> %5350, ptr %runnable.mask, align 1
  store <8 x i1> %1473, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1038:                        ; preds = %varying.coherent1033
  store <8 x i1> %1464, ptr %current.mask, align 1
  %5351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1464)
  br i1 %5351, label %schedule.55, label %scheduler.loop

varying.coherent.false1039:                       ; preds = %varying.coherent1033
  store <8 x i1> %1464, ptr %current.mask, align 1
  %5352 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1464)
  br i1 %5352, label %schedule.56, label %scheduler.loop

convergence.cascade1053:                          ; preds = %convergence.cascade1053, %schedule.56
  %convergence.cascade.flow1057 = phi <8 x i1> [ %1547, %schedule.56 ], [ %5395, %convergence.cascade1053 ]
  %convergence.cascade.depth1058 = phi i32 [ 0, %schedule.56 ], [ %5396, %convergence.cascade1053 ]
  %5353 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1057)
  %5354 = load i32, ptr %current.token, align 4
  %5355 = icmp ne i32 %5354, 0
  %5356 = and i1 %5353, %5355
  %5357 = sub i32 %5354, 1
  %5358 = select i1 %5356, i32 %5357, i32 0
  %5359 = load i8, ptr %frame.active, align 1
  %5360 = trunc i32 %5358 to i8
  %5361 = shl i8 1, %5360
  %5362 = and i8 %5359, %5361
  %5363 = icmp ne i8 %5362, 0
  %5364 = load <8 x i32>, ptr %frame.static.id, align 32
  %5365 = extractelement <8 x i32> %5364, i32 %5358
  %convergence.target.pointer1059 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %5365
  %convergence.dynamic.target1060 = load i32, ptr %convergence.target.pointer1059, align 4
  %5366 = icmp eq i32 %convergence.dynamic.target1060, 56
  %5367 = and i1 %5363, %5366
  %5368 = and i1 %5356, %5367
  %5369 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5358
  %5370 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5358
  %5371 = load <8 x i1>, ptr %5369, align 1
  %5372 = load <8 x i1>, ptr %5370, align 1
  %5373 = or <8 x i1> %5372, %convergence.cascade.flow1057
  %5374 = load <8 x i1>, ptr %live.mask, align 1
  %5375 = and <8 x i1> %5371, %5374
  %5376 = icmp eq <8 x i1> %5373, %5375
  %5377 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5376)
  %5378 = and i1 %5368, %5377
  %5379 = select i1 %5378, <8 x i1> zeroinitializer, <8 x i1> %5373
  %5380 = select i1 %5368, <8 x i1> %5379, <8 x i1> %5372
  store <8 x i1> %5380, ptr %5370, align 1
  %5381 = select i1 %5378, <8 x i1> zeroinitializer, <8 x i1> %5371
  store <8 x i1> %5381, ptr %5369, align 1
  %5382 = trunc i32 %5358 to i8
  %5383 = shl i8 1, %5382
  %5384 = xor i8 %5383, -1
  %5385 = and i8 %5359, %5384
  %5386 = select i1 %5378, i8 %5385, i8 %5359
  store i8 %5386, ptr %frame.active, align 1
  %.splatinsert1061 = insertelement <8 x i1> poison, i1 %5368, i64 0
  %.splat1062 = shufflevector <8 x i1> %.splatinsert1061, <8 x i1> poison, <8 x i32> zeroinitializer
  %5387 = and <8 x i1> %convergence.cascade.flow1057, %.splat1062
  %5388 = load <8 x i1>, ptr %runnable.mask, align 1
  %5389 = xor <8 x i1> %5387, splat (i1 true)
  %5390 = and <8 x i1> %5388, %5389
  store <8 x i1> %5390, ptr %runnable.mask, align 1
  %.splatinsert1063 = insertelement <8 x i1> poison, i1 %5378, i64 0
  %.splat1064 = shufflevector <8 x i1> %.splatinsert1063, <8 x i1> poison, <8 x i32> zeroinitializer
  %5391 = select <8 x i1> %.splat1064, <8 x i1> %5373, <8 x i1> zeroinitializer
  %5392 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5393 = extractelement <8 x i32> %5392, i32 %5358
  %5394 = select i1 %5378, i32 %5393, i32 %5354
  store i32 %5394, ptr %current.token, align 4
  %.splatinsert1065 = insertelement <8 x i1> poison, i1 %5368, i64 0
  %.splat1066 = shufflevector <8 x i1> %.splatinsert1065, <8 x i1> poison, <8 x i32> zeroinitializer
  %5395 = select <8 x i1> %.splat1066, <8 x i1> %5391, <8 x i1> %convergence.cascade.flow1057
  %5396 = add i32 %convergence.cascade.depth1058, 1
  %5397 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5395)
  %5398 = icmp ult i32 %5396, 8
  %5399 = and i1 %5397, %5398
  %5400 = and i1 %5368, %5399
  %convergence.parent.token1067 = load i32, ptr %current.token, align 4
  %convergence.parent.present1068 = icmp ne i32 %convergence.parent.token1067, 0
  %5401 = and i1 %5400, %convergence.parent.present1068
  br i1 %5401, label %convergence.cascade1053, label %convergence.cascade.exit1054

convergence.cascade.exit1054:                     ; preds = %convergence.cascade1053, %schedule.56
  %convergence.cascade.result1069 = phi <8 x i1> [ %1547, %schedule.56 ], [ %5395, %convergence.cascade1053 ]
  %5402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1069)
  br i1 %5402, label %convergence.target.56.ready, label %scheduler.loop

convergence.target.56.ready:                      ; preds = %convergence.cascade.exit1054
  %5403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1069)
  %5404 = bitcast <8 x i1> %convergence.cascade.result1069 to i8
  %5405 = call i8 @llvm.cttz.i8(i8 %5404, i1 false)
  %5406 = zext i8 %5405 to i32
  %5407 = select i1 %5403, i32 %5406, i32 0
  %5408 = load <8 x i64>, ptr %.slot55, align 64
  %5409 = select <8 x i1> %convergence.cascade.result1069, <8 x i64> zeroinitializer, <8 x i64> %5408
  store <8 x i64> %5409, ptr %.slot55, align 64
  %5410 = load <8 x float>, ptr %.slot131, align 32
  %5411 = select <8 x i1> %convergence.cascade.result1069, <8 x float> zeroinitializer, <8 x float> %5410
  store <8 x float> %5411, ptr %.slot131, align 32
  %5412 = load <8 x float>, ptr %.slot132, align 32
  %5413 = select <8 x i1> %convergence.cascade.result1069, <8 x float> zeroinitializer, <8 x float> %5412
  store <8 x float> %5413, ptr %.slot132, align 32
  %5414 = load <8 x float>, ptr %.slot133, align 32
  %5415 = select <8 x i1> %convergence.cascade.result1069, <8 x float> zeroinitializer, <8 x float> %5414
  store <8 x float> %5415, ptr %.slot133, align 32
  %5416 = load <8 x float>, ptr %.slot134, align 32
  %5417 = select <8 x i1> %convergence.cascade.result1069, <8 x float> zeroinitializer, <8 x float> %5416
  store <8 x float> %5417, ptr %.slot134, align 32
  store <8 x i1> %convergence.cascade.result1069, ptr %current.mask, align 1
  %5418 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1069)
  br i1 %5418, label %schedule.57, label %scheduler.loop

varying.divergent1071:                            ; preds = %schedule.57
  %5419 = load i32, ptr %current.token, align 4
  %5420 = icmp ne i32 %5419, 0
  %5421 = sub i32 %5419, 1
  %5422 = select i1 %5420, i32 %5421, i32 0
  %5423 = load i8, ptr %frame.active, align 1
  %5424 = trunc i32 %5422 to i8
  %5425 = shl i8 1, %5424
  %5426 = and i8 %5423, %5425
  %5427 = icmp ne i8 %5426, 0
  %5428 = load <8 x i32>, ptr %frame.static.id, align 32
  %5429 = extractelement <8 x i32> %5428, i32 %5422
  %5430 = icmp eq i32 %5429, 20
  %5431 = and i1 %5427, %5430
  %5432 = and i1 %5420, %5431
  %5433 = xor i1 %5432, true
  %5434 = and i1 true, %5433
  %5435 = xor i8 %5423, -1
  %5436 = icmp ne i8 %5435, 0
  %5437 = xor i1 %5436, true
  %5438 = and i1 %5434, %5437
  br i1 %5438, label %convergence.overflow.trap1073, label %convergence.overflow.resume1074

varying.coherent1072:                             ; preds = %schedule.57
  br i1 %1558, label %varying.coherent.true1077, label %varying.coherent.false1078

convergence.overflow.trap1073:                    ; preds = %varying.divergent1071
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1074:                  ; preds = %varying.divergent1071
  %5439 = call i8 @llvm.cttz.i8(i8 %5435, i1 false)
  %5440 = zext i8 %5439 to i32
  %5441 = select i1 %5436, i32 %5440, i32 0
  %5442 = trunc i32 %5441 to i8
  %5443 = shl i8 1, %5442
  %5444 = or i8 %5423, %5443
  %5445 = select i1 %5434, i8 %5444, i8 %5423
  store i8 %5445, ptr %frame.active, align 1
  %5446 = load <8 x i32>, ptr %frame.static.id, align 32
  %5447 = extractelement <8 x i32> %5446, i32 %5441
  %5448 = select i1 %5434, i32 20, i32 %5447
  %5449 = load <8 x i32>, ptr %frame.static.id, align 32
  %5450 = insertelement <8 x i32> %5449, i32 %5448, i32 %5441
  store <8 x i32> %5450, ptr %frame.static.id, align 32
  %5451 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5452 = extractelement <8 x i32> %5451, i32 %5441
  %5453 = select i1 %5434, i32 %5419, i32 %5452
  %5454 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5455 = insertelement <8 x i32> %5454, i32 %5453, i32 %5441
  store <8 x i32> %5455, ptr %frame.parent.token, align 32
  %5456 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5441
  %5457 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5441
  %5458 = load <8 x i1>, ptr %5456, align 1
  %5459 = load <8 x i1>, ptr %5457, align 1
  %5460 = select i1 %5434, <8 x i1> %1548, <8 x i1> %5458
  store <8 x i1> %5460, ptr %5456, align 1
  %5461 = select i1 %5434, <8 x i1> zeroinitializer, <8 x i1> %5459
  store <8 x i1> %5461, ptr %5457, align 1
  %5462 = add i32 %5441, 1
  %5463 = select i1 %5432, i32 %5419, i32 %5462
  %5464 = select i1 true, i32 %5463, i32 %5419
  store i32 %5464, ptr %current.token, align 4
  %5465 = load i32, ptr %current.token, align 4
  %5466 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1555)
  %5467 = load i32, ptr %ready.count, align 4
  %5468 = icmp uge i32 %5467, 8
  %5469 = and i1 %5466, %5468
  br i1 %5469, label %ready.overflow.trap1075, label %ready.overflow.resume1076

ready.overflow.trap1075:                          ; preds = %convergence.overflow.resume1074
  call void @llvm.trap()
  unreachable

ready.overflow.resume1076:                        ; preds = %convergence.overflow.resume1074
  %5470 = select i1 %5466, i32 %5467, i32 0
  %5471 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %5470
  %5472 = load <8 x i1>, ptr %5471, align 1
  %5473 = select i1 %5466, <8 x i1> %1555, <8 x i1> %5472
  store <8 x i1> %5473, ptr %5471, align 1
  %5474 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %5470
  %5475 = load i32, ptr %5474, align 4
  %5476 = select i1 %5466, i32 58, i32 %5475
  store i32 %5476, ptr %5474, align 4
  %5477 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %5470
  %5478 = load i32, ptr %5477, align 4
  %5479 = select i1 %5466, i32 %5465, i32 %5478
  store i32 %5479, ptr %5477, align 4
  %5480 = add i32 %5467, 1
  %5481 = select i1 %5466, i32 %5480, i32 %5467
  store i32 %5481, ptr %ready.count, align 4
  %5482 = load <8 x i1>, ptr %runnable.mask, align 1
  %5483 = or <8 x i1> %5482, %1555
  store <8 x i1> %5483, ptr %runnable.mask, align 1
  store <8 x i1> %1557, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1077:                        ; preds = %varying.coherent1072
  store <8 x i1> %1548, ptr %current.mask, align 1
  %5484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1548)
  br i1 %5484, label %schedule.58, label %scheduler.loop

varying.coherent.false1078:                       ; preds = %varying.coherent1072
  store <8 x i1> %1548, ptr %current.mask, align 1
  %5485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1548)
  br i1 %5485, label %schedule.59, label %scheduler.loop

convergence.cascade1092:                          ; preds = %convergence.cascade1092, %schedule.59
  %convergence.cascade.flow1096 = phi <8 x i1> [ %1631, %schedule.59 ], [ %5528, %convergence.cascade1092 ]
  %convergence.cascade.depth1097 = phi i32 [ 0, %schedule.59 ], [ %5529, %convergence.cascade1092 ]
  %5486 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1096)
  %5487 = load i32, ptr %current.token, align 4
  %5488 = icmp ne i32 %5487, 0
  %5489 = and i1 %5486, %5488
  %5490 = sub i32 %5487, 1
  %5491 = select i1 %5489, i32 %5490, i32 0
  %5492 = load i8, ptr %frame.active, align 1
  %5493 = trunc i32 %5491 to i8
  %5494 = shl i8 1, %5493
  %5495 = and i8 %5492, %5494
  %5496 = icmp ne i8 %5495, 0
  %5497 = load <8 x i32>, ptr %frame.static.id, align 32
  %5498 = extractelement <8 x i32> %5497, i32 %5491
  %convergence.target.pointer1098 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %5498
  %convergence.dynamic.target1099 = load i32, ptr %convergence.target.pointer1098, align 4
  %5499 = icmp eq i32 %convergence.dynamic.target1099, 59
  %5500 = and i1 %5496, %5499
  %5501 = and i1 %5489, %5500
  %5502 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %5491
  %5503 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %5491
  %5504 = load <8 x i1>, ptr %5502, align 1
  %5505 = load <8 x i1>, ptr %5503, align 1
  %5506 = or <8 x i1> %5505, %convergence.cascade.flow1096
  %5507 = load <8 x i1>, ptr %live.mask, align 1
  %5508 = and <8 x i1> %5504, %5507
  %5509 = icmp eq <8 x i1> %5506, %5508
  %5510 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %5509)
  %5511 = and i1 %5501, %5510
  %5512 = select i1 %5511, <8 x i1> zeroinitializer, <8 x i1> %5506
  %5513 = select i1 %5501, <8 x i1> %5512, <8 x i1> %5505
  store <8 x i1> %5513, ptr %5503, align 1
  %5514 = select i1 %5511, <8 x i1> zeroinitializer, <8 x i1> %5504
  store <8 x i1> %5514, ptr %5502, align 1
  %5515 = trunc i32 %5491 to i8
  %5516 = shl i8 1, %5515
  %5517 = xor i8 %5516, -1
  %5518 = and i8 %5492, %5517
  %5519 = select i1 %5511, i8 %5518, i8 %5492
  store i8 %5519, ptr %frame.active, align 1
  %.splatinsert1100 = insertelement <8 x i1> poison, i1 %5501, i64 0
  %.splat1101 = shufflevector <8 x i1> %.splatinsert1100, <8 x i1> poison, <8 x i32> zeroinitializer
  %5520 = and <8 x i1> %convergence.cascade.flow1096, %.splat1101
  %5521 = load <8 x i1>, ptr %runnable.mask, align 1
  %5522 = xor <8 x i1> %5520, splat (i1 true)
  %5523 = and <8 x i1> %5521, %5522
  store <8 x i1> %5523, ptr %runnable.mask, align 1
  %.splatinsert1102 = insertelement <8 x i1> poison, i1 %5511, i64 0
  %.splat1103 = shufflevector <8 x i1> %.splatinsert1102, <8 x i1> poison, <8 x i32> zeroinitializer
  %5524 = select <8 x i1> %.splat1103, <8 x i1> %5506, <8 x i1> zeroinitializer
  %5525 = load <8 x i32>, ptr %frame.parent.token, align 32
  %5526 = extractelement <8 x i32> %5525, i32 %5491
  %5527 = select i1 %5511, i32 %5526, i32 %5487
  store i32 %5527, ptr %current.token, align 4
  %.splatinsert1104 = insertelement <8 x i1> poison, i1 %5501, i64 0
  %.splat1105 = shufflevector <8 x i1> %.splatinsert1104, <8 x i1> poison, <8 x i32> zeroinitializer
  %5528 = select <8 x i1> %.splat1105, <8 x i1> %5524, <8 x i1> %convergence.cascade.flow1096
  %5529 = add i32 %convergence.cascade.depth1097, 1
  %5530 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5528)
  %5531 = icmp ult i32 %5529, 8
  %5532 = and i1 %5530, %5531
  %5533 = and i1 %5501, %5532
  %convergence.parent.token1106 = load i32, ptr %current.token, align 4
  %convergence.parent.present1107 = icmp ne i32 %convergence.parent.token1106, 0
  %5534 = and i1 %5533, %convergence.parent.present1107
  br i1 %5534, label %convergence.cascade1092, label %convergence.cascade.exit1093

convergence.cascade.exit1093:                     ; preds = %convergence.cascade1092, %schedule.59
  %convergence.cascade.result1108 = phi <8 x i1> [ %1631, %schedule.59 ], [ %5528, %convergence.cascade1092 ]
  %5535 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  br i1 %5535, label %convergence.target.59.ready, label %scheduler.loop

convergence.target.59.ready:                      ; preds = %convergence.cascade.exit1093
  %5536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %5537 = bitcast <8 x i1> %convergence.cascade.result1108 to i8
  %5538 = call i8 @llvm.cttz.i8(i8 %5537, i1 false)
  %5539 = zext i8 %5538 to i32
  %5540 = select i1 %5536, i32 %5539, i32 0
  %.state1109 = load <8 x float>, ptr %.slot56, align 32
  %5541 = fmul <8 x float> %.state1109, splat (float 0x3FC43D1360000000)
  %.state1110 = load <8 x float>, ptr %.slot57, align 32
  %5542 = fmul <8 x float> %.state1110, splat (float 0x3FC43D1360000000)
  %.state1111 = load <8 x float>, ptr %.slot61, align 32
  %5543 = fmul <8 x float> %.state1111, splat (float 0x3FC43D1360000000)
  %.state1112 = load <8 x float>, ptr %.slot62, align 32
  %5544 = fmul <8 x float> %.state1112, splat (float 0x3FC43D1360000000)
  %.state1113 = load <8 x float>, ptr %.slot66, align 32
  %5545 = fmul <8 x float> %.state1113, splat (float 0x3FC43D1360000000)
  %.state1114 = load <8 x float>, ptr %.slot67, align 32
  %5546 = fmul <8 x float> %.state1114, splat (float 0x3FC43D1360000000)
  %.state1115 = load <8 x float>, ptr %.slot71, align 32
  %5547 = fmul <8 x float> %.state1115, splat (float 0x3FC43D1360000000)
  %.state1116 = load <8 x float>, ptr %.slot72, align 32
  %5548 = fmul <8 x float> %.state1116, splat (float 0x3FC43D1360000000)
  %.state1117 = load <8 x float>, ptr %.slot76, align 32
  %5549 = fmul <8 x float> %.state1117, splat (float 0x3FC43D1360000000)
  %.state1118 = load <8 x float>, ptr %.slot77, align 32
  %5550 = fmul <8 x float> %.state1118, splat (float 0x3FC43D1360000000)
  %.state1119 = load <8 x float>, ptr %.slot81, align 32
  %5551 = fmul <8 x float> %.state1119, splat (float 0x3FC43D1360000000)
  %.state1120 = load <8 x float>, ptr %.slot82, align 32
  %5552 = fmul <8 x float> %.state1120, splat (float 0x3FC43D1360000000)
  %.state1121 = load <8 x float>, ptr %.slot86, align 32
  %5553 = fmul <8 x float> %.state1121, splat (float 0x3FC43D1360000000)
  %.state1122 = load <8 x float>, ptr %.slot87, align 32
  %5554 = fmul <8 x float> %.state1122, splat (float 0x3FC43D1360000000)
  %.state1123 = load <8 x float>, ptr %.slot91, align 32
  %5555 = fmul <8 x float> %.state1123, splat (float 0x3FC43D1360000000)
  %.state1124 = load <8 x float>, ptr %.slot92, align 32
  %5556 = fmul <8 x float> %.state1124, splat (float 0x3FC43D1360000000)
  %.state1125 = load <8 x float>, ptr %.slot58, align 32
  %5557 = fmul <8 x float> %.state1125, splat (float 0x3FC43D1360000000)
  %.state1126 = load <8 x float>, ptr %.slot59, align 32
  %5558 = fmul <8 x float> %.state1126, splat (float 0x3FC43D1360000000)
  %.state1127 = load <8 x float>, ptr %.slot63, align 32
  %5559 = fmul <8 x float> %.state1127, splat (float 0x3FC43D1360000000)
  %.state1128 = load <8 x float>, ptr %.slot64, align 32
  %5560 = fmul <8 x float> %.state1128, splat (float 0x3FC43D1360000000)
  %.state1129 = load <8 x float>, ptr %.slot68, align 32
  %5561 = fmul <8 x float> %.state1129, splat (float 0x3FC43D1360000000)
  %.state1130 = load <8 x float>, ptr %.slot69, align 32
  %5562 = fmul <8 x float> %.state1130, splat (float 0x3FC43D1360000000)
  %.state1131 = load <8 x float>, ptr %.slot73, align 32
  %5563 = fmul <8 x float> %.state1131, splat (float 0x3FC43D1360000000)
  %.state1132 = load <8 x float>, ptr %.slot74, align 32
  %5564 = fmul <8 x float> %.state1132, splat (float 0x3FC43D1360000000)
  %.state1133 = load <8 x float>, ptr %.slot78, align 32
  %5565 = fmul <8 x float> %.state1133, splat (float 0x3FC43D1360000000)
  %.state1134 = load <8 x float>, ptr %.slot79, align 32
  %5566 = fmul <8 x float> %.state1134, splat (float 0x3FC43D1360000000)
  %.state1135 = load <8 x float>, ptr %.slot83, align 32
  %5567 = fmul <8 x float> %.state1135, splat (float 0x3FC43D1360000000)
  %.state1136 = load <8 x float>, ptr %.slot84, align 32
  %5568 = fmul <8 x float> %.state1136, splat (float 0x3FC43D1360000000)
  %.state1137 = load <8 x float>, ptr %.slot88, align 32
  %5569 = fmul <8 x float> %.state1137, splat (float 0x3FC43D1360000000)
  %.state1138 = load <8 x float>, ptr %.slot89, align 32
  %5570 = fmul <8 x float> %.state1138, splat (float 0x3FC43D1360000000)
  %.state1139 = load <8 x float>, ptr %.slot93, align 32
  %5571 = fmul <8 x float> %.state1139, splat (float 0x3FC43D1360000000)
  %.state1140 = load <8 x float>, ptr %.slot94, align 32
  %5572 = fmul <8 x float> %.state1140, splat (float 0x3FC43D1360000000)
  %.state1141 = load <8 x float>, ptr %.slot96, align 32
  %5573 = fmul <8 x float> %.state1141, splat (float 0x3FC43D1360000000)
  %.state1142 = load <8 x float>, ptr %.slot97, align 32
  %5574 = fmul <8 x float> %.state1142, splat (float 0x3FC43D1360000000)
  %.state1143 = load <8 x float>, ptr %.slot101, align 32
  %5575 = fmul <8 x float> %.state1143, splat (float 0x3FC43D1360000000)
  %.state1144 = load <8 x float>, ptr %.slot102, align 32
  %5576 = fmul <8 x float> %.state1144, splat (float 0x3FC43D1360000000)
  %.state1145 = load <8 x float>, ptr %.slot106, align 32
  %5577 = fmul <8 x float> %.state1145, splat (float 0x3FC43D1360000000)
  %.state1146 = load <8 x float>, ptr %.slot107, align 32
  %5578 = fmul <8 x float> %.state1146, splat (float 0x3FC43D1360000000)
  %.state1147 = load <8 x float>, ptr %.slot111, align 32
  %5579 = fmul <8 x float> %.state1147, splat (float 0x3FC43D1360000000)
  %.state1148 = load <8 x float>, ptr %.slot112, align 32
  %5580 = fmul <8 x float> %.state1148, splat (float 0x3FC43D1360000000)
  %.state1149 = load <8 x float>, ptr %.slot116, align 32
  %5581 = fmul <8 x float> %.state1149, splat (float 0x3FC43D1360000000)
  %.state1150 = load <8 x float>, ptr %.slot117, align 32
  %5582 = fmul <8 x float> %.state1150, splat (float 0x3FC43D1360000000)
  %.state1151 = load <8 x float>, ptr %.slot121, align 32
  %5583 = fmul <8 x float> %.state1151, splat (float 0x3FC43D1360000000)
  %.state1152 = load <8 x float>, ptr %.slot122, align 32
  %5584 = fmul <8 x float> %.state1152, splat (float 0x3FC43D1360000000)
  %.state1153 = load <8 x float>, ptr %.slot126, align 32
  %5585 = fmul <8 x float> %.state1153, splat (float 0x3FC43D1360000000)
  %.state1154 = load <8 x float>, ptr %.slot127, align 32
  %5586 = fmul <8 x float> %.state1154, splat (float 0x3FC43D1360000000)
  %.state1155 = load <8 x float>, ptr %.slot131, align 32
  %5587 = fmul <8 x float> %.state1155, splat (float 0x3FC43D1360000000)
  %.state1156 = load <8 x float>, ptr %.slot132, align 32
  %5588 = fmul <8 x float> %.state1156, splat (float 0x3FC43D1360000000)
  %.state1157 = load <8 x float>, ptr %.slot98, align 32
  %5589 = fmul <8 x float> %.state1157, splat (float 0x3FC43D1360000000)
  %.state1158 = load <8 x float>, ptr %.slot99, align 32
  %5590 = fmul <8 x float> %.state1158, splat (float 0x3FC43D1360000000)
  %.state1159 = load <8 x float>, ptr %.slot103, align 32
  %5591 = fmul <8 x float> %.state1159, splat (float 0x3FC43D1360000000)
  %.state1160 = load <8 x float>, ptr %.slot104, align 32
  %5592 = fmul <8 x float> %.state1160, splat (float 0x3FC43D1360000000)
  %.state1161 = load <8 x float>, ptr %.slot108, align 32
  %5593 = fmul <8 x float> %.state1161, splat (float 0x3FC43D1360000000)
  %.state1162 = load <8 x float>, ptr %.slot109, align 32
  %5594 = fmul <8 x float> %.state1162, splat (float 0x3FC43D1360000000)
  %.state1163 = load <8 x float>, ptr %.slot113, align 32
  %5595 = fmul <8 x float> %.state1163, splat (float 0x3FC43D1360000000)
  %.state1164 = load <8 x float>, ptr %.slot114, align 32
  %5596 = fmul <8 x float> %.state1164, splat (float 0x3FC43D1360000000)
  %.state1165 = load <8 x float>, ptr %.slot118, align 32
  %5597 = fmul <8 x float> %.state1165, splat (float 0x3FC43D1360000000)
  %.state1166 = load <8 x float>, ptr %.slot119, align 32
  %5598 = fmul <8 x float> %.state1166, splat (float 0x3FC43D1360000000)
  %.state1167 = load <8 x float>, ptr %.slot123, align 32
  %5599 = fmul <8 x float> %.state1167, splat (float 0x3FC43D1360000000)
  %.state1168 = load <8 x float>, ptr %.slot124, align 32
  %5600 = fmul <8 x float> %.state1168, splat (float 0x3FC43D1360000000)
  %.state1169 = load <8 x float>, ptr %.slot128, align 32
  %5601 = fmul <8 x float> %.state1169, splat (float 0x3FC43D1360000000)
  %.state1170 = load <8 x float>, ptr %.slot129, align 32
  %5602 = fmul <8 x float> %.state1170, splat (float 0x3FC43D1360000000)
  %.state1171 = load <8 x float>, ptr %.slot133, align 32
  %5603 = fmul <8 x float> %.state1171, splat (float 0x3FC43D1360000000)
  %.state1172 = load <8 x float>, ptr %.slot134, align 32
  %5604 = fmul <8 x float> %.state1172, splat (float 0x3FC43D1360000000)
  %.spill.load1173 = load <8 x i64>, ptr %.spill51, align 64
  %5605 = add <8 x i64> zeroinitializer, %.spill.load1173
  %.spill.load1174 = load <8 x i64>, ptr %.spill51, align 64
  %5606 = add <8 x i64> splat (i64 1), %.spill.load1174
  %.spill.load1175 = load <8 x i64>, ptr %.spill51, align 64
  %5607 = add <8 x i64> splat (i64 2), %.spill.load1175
  %.spill.load1176 = load <8 x i64>, ptr %.spill51, align 64
  %5608 = add <8 x i64> splat (i64 3), %.spill.load1176
  %.spill.load1177 = load <8 x i64>, ptr %.spill51, align 64
  %5609 = add <8 x i64> splat (i64 4), %.spill.load1177
  %.spill.load1178 = load <8 x i64>, ptr %.spill51, align 64
  %5610 = add <8 x i64> splat (i64 5), %.spill.load1178
  %.spill.load1179 = load <8 x i64>, ptr %.spill51, align 64
  %5611 = add <8 x i64> splat (i64 6), %.spill.load1179
  %.spill.load1180 = load <8 x i64>, ptr %.spill51, align 64
  %5612 = add <8 x i64> splat (i64 7), %.spill.load1180
  %.spill.load1181 = load <8 x i64>, ptr %.spill51, align 64
  %5613 = add <8 x i64> splat (i64 8), %.spill.load1181
  %.spill.load1182 = load <8 x i64>, ptr %.spill51, align 64
  %5614 = add <8 x i64> splat (i64 9), %.spill.load1182
  %.spill.load1183 = load <8 x i64>, ptr %.spill51, align 64
  %5615 = add <8 x i64> splat (i64 10), %.spill.load1183
  %.spill.load1184 = load <8 x i64>, ptr %.spill51, align 64
  %5616 = add <8 x i64> splat (i64 11), %.spill.load1184
  %.spill.load1185 = load <8 x i64>, ptr %.spill51, align 64
  %5617 = add <8 x i64> splat (i64 12), %.spill.load1185
  %.spill.load1186 = load <8 x i64>, ptr %.spill51, align 64
  %5618 = add <8 x i64> splat (i64 13), %.spill.load1186
  %.spill.load1187 = load <8 x i64>, ptr %.spill51, align 64
  %5619 = add <8 x i64> splat (i64 14), %.spill.load1187
  %.spill.load1188 = load <8 x i64>, ptr %.spill51, align 64
  %5620 = add <8 x i64> splat (i64 15), %.spill.load1188
  %5621 = icmp slt <8 x i64> %5605, splat (i64 67)
  %5622 = icmp slt <8 x i64> %5606, splat (i64 67)
  %5623 = icmp slt <8 x i64> %5607, splat (i64 67)
  %5624 = icmp slt <8 x i64> %5608, splat (i64 67)
  %5625 = icmp slt <8 x i64> %5609, splat (i64 67)
  %5626 = icmp slt <8 x i64> %5610, splat (i64 67)
  %5627 = icmp slt <8 x i64> %5611, splat (i64 67)
  %5628 = icmp slt <8 x i64> %5612, splat (i64 67)
  %5629 = icmp slt <8 x i64> %5613, splat (i64 67)
  %5630 = icmp slt <8 x i64> %5614, splat (i64 67)
  %5631 = icmp slt <8 x i64> %5615, splat (i64 67)
  %5632 = icmp slt <8 x i64> %5616, splat (i64 67)
  %5633 = icmp slt <8 x i64> %5617, splat (i64 67)
  %5634 = icmp slt <8 x i64> %5618, splat (i64 67)
  %5635 = icmp slt <8 x i64> %5619, splat (i64 67)
  %5636 = icmp slt <8 x i64> %5620, splat (i64 67)
  %.spill.load1189 = load <8 x i64>, ptr %.spill38, align 64
  %5637 = add <8 x i64> zeroinitializer, %.spill.load1189
  %.spill.load1190 = load <8 x i64>, ptr %.spill38, align 64
  %5638 = add <8 x i64> splat (i64 1), %.spill.load1190
  %.spill.load1191 = load <8 x i64>, ptr %.spill38, align 64
  %5639 = add <8 x i64> splat (i64 2), %.spill.load1191
  %.spill.load1192 = load <8 x i64>, ptr %.spill38, align 64
  %5640 = add <8 x i64> splat (i64 3), %.spill.load1192
  %5641 = add <8 x i64> %5637, splat (i64 67)
  %5642 = add <8 x i64> %5638, splat (i64 67)
  %5643 = add <8 x i64> %5639, splat (i64 67)
  %5644 = add <8 x i64> %5640, splat (i64 67)
  %5645 = sub <8 x i64> %5641, splat (i64 17)
  %5646 = sub <8 x i64> %5642, splat (i64 17)
  %5647 = sub <8 x i64> %5643, splat (i64 17)
  %5648 = sub <8 x i64> %5644, splat (i64 17)
  %5649 = icmp sle <8 x i64> %5605, %5645
  %5650 = icmp sle <8 x i64> %5605, %5646
  %5651 = icmp sle <8 x i64> %5605, %5647
  %5652 = icmp sle <8 x i64> %5605, %5648
  %5653 = icmp sle <8 x i64> %5606, %5645
  %5654 = icmp sle <8 x i64> %5606, %5646
  %5655 = icmp sle <8 x i64> %5606, %5647
  %5656 = icmp sle <8 x i64> %5606, %5648
  %5657 = icmp sle <8 x i64> %5607, %5645
  %5658 = icmp sle <8 x i64> %5607, %5646
  %5659 = icmp sle <8 x i64> %5607, %5647
  %5660 = icmp sle <8 x i64> %5607, %5648
  %5661 = icmp sle <8 x i64> %5608, %5645
  %5662 = icmp sle <8 x i64> %5608, %5646
  %5663 = icmp sle <8 x i64> %5608, %5647
  %5664 = icmp sle <8 x i64> %5608, %5648
  %5665 = icmp sle <8 x i64> %5609, %5645
  %5666 = icmp sle <8 x i64> %5609, %5646
  %5667 = icmp sle <8 x i64> %5609, %5647
  %5668 = icmp sle <8 x i64> %5609, %5648
  %5669 = icmp sle <8 x i64> %5610, %5645
  %5670 = icmp sle <8 x i64> %5610, %5646
  %5671 = icmp sle <8 x i64> %5610, %5647
  %5672 = icmp sle <8 x i64> %5610, %5648
  %5673 = icmp sle <8 x i64> %5611, %5645
  %5674 = icmp sle <8 x i64> %5611, %5646
  %5675 = icmp sle <8 x i64> %5611, %5647
  %5676 = icmp sle <8 x i64> %5611, %5648
  %5677 = icmp sle <8 x i64> %5612, %5645
  %5678 = icmp sle <8 x i64> %5612, %5646
  %5679 = icmp sle <8 x i64> %5612, %5647
  %5680 = icmp sle <8 x i64> %5612, %5648
  %5681 = icmp sle <8 x i64> %5613, %5645
  %5682 = icmp sle <8 x i64> %5613, %5646
  %5683 = icmp sle <8 x i64> %5613, %5647
  %5684 = icmp sle <8 x i64> %5613, %5648
  %5685 = icmp sle <8 x i64> %5614, %5645
  %5686 = icmp sle <8 x i64> %5614, %5646
  %5687 = icmp sle <8 x i64> %5614, %5647
  %5688 = icmp sle <8 x i64> %5614, %5648
  %5689 = icmp sle <8 x i64> %5615, %5645
  %5690 = icmp sle <8 x i64> %5615, %5646
  %5691 = icmp sle <8 x i64> %5615, %5647
  %5692 = icmp sle <8 x i64> %5615, %5648
  %5693 = icmp sle <8 x i64> %5616, %5645
  %5694 = icmp sle <8 x i64> %5616, %5646
  %5695 = icmp sle <8 x i64> %5616, %5647
  %5696 = icmp sle <8 x i64> %5616, %5648
  %5697 = icmp sle <8 x i64> %5617, %5645
  %5698 = icmp sle <8 x i64> %5617, %5646
  %5699 = icmp sle <8 x i64> %5617, %5647
  %5700 = icmp sle <8 x i64> %5617, %5648
  %5701 = icmp sle <8 x i64> %5618, %5645
  %5702 = icmp sle <8 x i64> %5618, %5646
  %5703 = icmp sle <8 x i64> %5618, %5647
  %5704 = icmp sle <8 x i64> %5618, %5648
  %5705 = icmp sle <8 x i64> %5619, %5645
  %5706 = icmp sle <8 x i64> %5619, %5646
  %5707 = icmp sle <8 x i64> %5619, %5647
  %5708 = icmp sle <8 x i64> %5619, %5648
  %5709 = icmp sle <8 x i64> %5620, %5645
  %5710 = icmp sle <8 x i64> %5620, %5646
  %5711 = icmp sle <8 x i64> %5620, %5647
  %5712 = icmp sle <8 x i64> %5620, %5648
  %5713 = and <8 x i1> %5621, %5649
  %5714 = load <8 x i1>, ptr %.spill135, align 1
  %5715 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5713, <8 x i1> %5714
  store <8 x i1> %5715, ptr %.spill135, align 1
  %5716 = and <8 x i1> %5621, %5650
  %5717 = load <8 x i1>, ptr %.spill136, align 1
  %5718 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5716, <8 x i1> %5717
  store <8 x i1> %5718, ptr %.spill136, align 1
  %5719 = and <8 x i1> %5621, %5651
  %5720 = load <8 x i1>, ptr %.spill137, align 1
  %5721 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5719, <8 x i1> %5720
  store <8 x i1> %5721, ptr %.spill137, align 1
  %5722 = and <8 x i1> %5621, %5652
  %5723 = load <8 x i1>, ptr %.spill138, align 1
  %5724 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5722, <8 x i1> %5723
  store <8 x i1> %5724, ptr %.spill138, align 1
  %5725 = and <8 x i1> %5622, %5653
  %5726 = load <8 x i1>, ptr %.spill139, align 1
  %5727 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5725, <8 x i1> %5726
  store <8 x i1> %5727, ptr %.spill139, align 1
  %5728 = and <8 x i1> %5622, %5654
  %5729 = load <8 x i1>, ptr %.spill140, align 1
  %5730 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5728, <8 x i1> %5729
  store <8 x i1> %5730, ptr %.spill140, align 1
  %5731 = and <8 x i1> %5622, %5655
  %5732 = load <8 x i1>, ptr %.spill141, align 1
  %5733 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5731, <8 x i1> %5732
  store <8 x i1> %5733, ptr %.spill141, align 1
  %5734 = and <8 x i1> %5622, %5656
  %5735 = load <8 x i1>, ptr %.spill142, align 1
  %5736 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5734, <8 x i1> %5735
  store <8 x i1> %5736, ptr %.spill142, align 1
  %5737 = and <8 x i1> %5623, %5657
  %5738 = load <8 x i1>, ptr %.spill143, align 1
  %5739 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5737, <8 x i1> %5738
  store <8 x i1> %5739, ptr %.spill143, align 1
  %5740 = and <8 x i1> %5623, %5658
  %5741 = load <8 x i1>, ptr %.spill144, align 1
  %5742 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5740, <8 x i1> %5741
  store <8 x i1> %5742, ptr %.spill144, align 1
  %5743 = and <8 x i1> %5623, %5659
  %5744 = load <8 x i1>, ptr %.spill145, align 1
  %5745 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5743, <8 x i1> %5744
  store <8 x i1> %5745, ptr %.spill145, align 1
  %5746 = and <8 x i1> %5623, %5660
  %5747 = load <8 x i1>, ptr %.spill146, align 1
  %5748 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5746, <8 x i1> %5747
  store <8 x i1> %5748, ptr %.spill146, align 1
  %5749 = and <8 x i1> %5624, %5661
  %5750 = load <8 x i1>, ptr %.spill147, align 1
  %5751 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5749, <8 x i1> %5750
  store <8 x i1> %5751, ptr %.spill147, align 1
  %5752 = and <8 x i1> %5624, %5662
  %5753 = load <8 x i1>, ptr %.spill148, align 1
  %5754 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5752, <8 x i1> %5753
  store <8 x i1> %5754, ptr %.spill148, align 1
  %5755 = and <8 x i1> %5624, %5663
  %5756 = load <8 x i1>, ptr %.spill149, align 1
  %5757 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5755, <8 x i1> %5756
  store <8 x i1> %5757, ptr %.spill149, align 1
  %5758 = and <8 x i1> %5624, %5664
  %5759 = load <8 x i1>, ptr %.spill150, align 1
  %5760 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5758, <8 x i1> %5759
  store <8 x i1> %5760, ptr %.spill150, align 1
  %5761 = and <8 x i1> %5625, %5665
  %5762 = load <8 x i1>, ptr %.spill151, align 1
  %5763 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5761, <8 x i1> %5762
  store <8 x i1> %5763, ptr %.spill151, align 1
  %5764 = and <8 x i1> %5625, %5666
  %5765 = load <8 x i1>, ptr %.spill152, align 1
  %5766 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5764, <8 x i1> %5765
  store <8 x i1> %5766, ptr %.spill152, align 1
  %5767 = and <8 x i1> %5625, %5667
  %5768 = load <8 x i1>, ptr %.spill153, align 1
  %5769 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5767, <8 x i1> %5768
  store <8 x i1> %5769, ptr %.spill153, align 1
  %5770 = and <8 x i1> %5625, %5668
  %5771 = load <8 x i1>, ptr %.spill154, align 1
  %5772 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5770, <8 x i1> %5771
  store <8 x i1> %5772, ptr %.spill154, align 1
  %5773 = and <8 x i1> %5626, %5669
  %5774 = load <8 x i1>, ptr %.spill155, align 1
  %5775 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5773, <8 x i1> %5774
  store <8 x i1> %5775, ptr %.spill155, align 1
  %5776 = and <8 x i1> %5626, %5670
  %5777 = load <8 x i1>, ptr %.spill156, align 1
  %5778 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5776, <8 x i1> %5777
  store <8 x i1> %5778, ptr %.spill156, align 1
  %5779 = and <8 x i1> %5626, %5671
  %5780 = load <8 x i1>, ptr %.spill157, align 1
  %5781 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5779, <8 x i1> %5780
  store <8 x i1> %5781, ptr %.spill157, align 1
  %5782 = and <8 x i1> %5626, %5672
  %5783 = load <8 x i1>, ptr %.spill158, align 1
  %5784 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5782, <8 x i1> %5783
  store <8 x i1> %5784, ptr %.spill158, align 1
  %5785 = and <8 x i1> %5627, %5673
  %5786 = load <8 x i1>, ptr %.spill159, align 1
  %5787 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5785, <8 x i1> %5786
  store <8 x i1> %5787, ptr %.spill159, align 1
  %5788 = and <8 x i1> %5627, %5674
  %5789 = load <8 x i1>, ptr %.spill160, align 1
  %5790 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5788, <8 x i1> %5789
  store <8 x i1> %5790, ptr %.spill160, align 1
  %5791 = and <8 x i1> %5627, %5675
  %5792 = load <8 x i1>, ptr %.spill161, align 1
  %5793 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5791, <8 x i1> %5792
  store <8 x i1> %5793, ptr %.spill161, align 1
  %5794 = and <8 x i1> %5627, %5676
  %5795 = load <8 x i1>, ptr %.spill162, align 1
  %5796 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5794, <8 x i1> %5795
  store <8 x i1> %5796, ptr %.spill162, align 1
  %5797 = and <8 x i1> %5628, %5677
  %5798 = load <8 x i1>, ptr %.spill163, align 1
  %5799 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5797, <8 x i1> %5798
  store <8 x i1> %5799, ptr %.spill163, align 1
  %5800 = and <8 x i1> %5628, %5678
  %5801 = load <8 x i1>, ptr %.spill164, align 1
  %5802 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5800, <8 x i1> %5801
  store <8 x i1> %5802, ptr %.spill164, align 1
  %5803 = and <8 x i1> %5628, %5679
  %5804 = load <8 x i1>, ptr %.spill165, align 1
  %5805 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5803, <8 x i1> %5804
  store <8 x i1> %5805, ptr %.spill165, align 1
  %5806 = and <8 x i1> %5628, %5680
  %5807 = load <8 x i1>, ptr %.spill166, align 1
  %5808 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5806, <8 x i1> %5807
  store <8 x i1> %5808, ptr %.spill166, align 1
  %5809 = and <8 x i1> %5629, %5681
  %5810 = load <8 x i1>, ptr %.spill167, align 1
  %5811 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5809, <8 x i1> %5810
  store <8 x i1> %5811, ptr %.spill167, align 1
  %5812 = and <8 x i1> %5629, %5682
  %5813 = load <8 x i1>, ptr %.spill168, align 1
  %5814 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5812, <8 x i1> %5813
  store <8 x i1> %5814, ptr %.spill168, align 1
  %5815 = and <8 x i1> %5629, %5683
  %5816 = load <8 x i1>, ptr %.spill169, align 1
  %5817 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5815, <8 x i1> %5816
  store <8 x i1> %5817, ptr %.spill169, align 1
  %5818 = and <8 x i1> %5629, %5684
  %5819 = load <8 x i1>, ptr %.spill170, align 1
  %5820 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5818, <8 x i1> %5819
  store <8 x i1> %5820, ptr %.spill170, align 1
  %5821 = and <8 x i1> %5630, %5685
  %5822 = load <8 x i1>, ptr %.spill171, align 1
  %5823 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5821, <8 x i1> %5822
  store <8 x i1> %5823, ptr %.spill171, align 1
  %5824 = and <8 x i1> %5630, %5686
  %5825 = load <8 x i1>, ptr %.spill172, align 1
  %5826 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5824, <8 x i1> %5825
  store <8 x i1> %5826, ptr %.spill172, align 1
  %5827 = and <8 x i1> %5630, %5687
  %5828 = load <8 x i1>, ptr %.spill173, align 1
  %5829 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5827, <8 x i1> %5828
  store <8 x i1> %5829, ptr %.spill173, align 1
  %5830 = and <8 x i1> %5630, %5688
  %5831 = load <8 x i1>, ptr %.spill174, align 1
  %5832 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5830, <8 x i1> %5831
  store <8 x i1> %5832, ptr %.spill174, align 1
  %5833 = and <8 x i1> %5631, %5689
  %5834 = load <8 x i1>, ptr %.spill175, align 1
  %5835 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5833, <8 x i1> %5834
  store <8 x i1> %5835, ptr %.spill175, align 1
  %5836 = and <8 x i1> %5631, %5690
  %5837 = load <8 x i1>, ptr %.spill176, align 1
  %5838 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5836, <8 x i1> %5837
  store <8 x i1> %5838, ptr %.spill176, align 1
  %5839 = and <8 x i1> %5631, %5691
  %5840 = load <8 x i1>, ptr %.spill177, align 1
  %5841 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5839, <8 x i1> %5840
  store <8 x i1> %5841, ptr %.spill177, align 1
  %5842 = and <8 x i1> %5631, %5692
  %5843 = load <8 x i1>, ptr %.spill178, align 1
  %5844 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5842, <8 x i1> %5843
  store <8 x i1> %5844, ptr %.spill178, align 1
  %5845 = and <8 x i1> %5632, %5693
  %5846 = load <8 x i1>, ptr %.spill179, align 1
  %5847 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5845, <8 x i1> %5846
  store <8 x i1> %5847, ptr %.spill179, align 1
  %5848 = and <8 x i1> %5632, %5694
  %5849 = load <8 x i1>, ptr %.spill180, align 1
  %5850 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5848, <8 x i1> %5849
  store <8 x i1> %5850, ptr %.spill180, align 1
  %5851 = and <8 x i1> %5632, %5695
  %5852 = load <8 x i1>, ptr %.spill181, align 1
  %5853 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5851, <8 x i1> %5852
  store <8 x i1> %5853, ptr %.spill181, align 1
  %5854 = and <8 x i1> %5632, %5696
  %5855 = load <8 x i1>, ptr %.spill182, align 1
  %5856 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5854, <8 x i1> %5855
  store <8 x i1> %5856, ptr %.spill182, align 1
  %5857 = and <8 x i1> %5633, %5697
  %5858 = load <8 x i1>, ptr %.spill183, align 1
  %5859 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5857, <8 x i1> %5858
  store <8 x i1> %5859, ptr %.spill183, align 1
  %5860 = and <8 x i1> %5633, %5698
  %5861 = load <8 x i1>, ptr %.spill184, align 1
  %5862 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5860, <8 x i1> %5861
  store <8 x i1> %5862, ptr %.spill184, align 1
  %5863 = and <8 x i1> %5633, %5699
  %5864 = load <8 x i1>, ptr %.spill185, align 1
  %5865 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5863, <8 x i1> %5864
  store <8 x i1> %5865, ptr %.spill185, align 1
  %5866 = and <8 x i1> %5633, %5700
  %5867 = load <8 x i1>, ptr %.spill186, align 1
  %5868 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5866, <8 x i1> %5867
  store <8 x i1> %5868, ptr %.spill186, align 1
  %5869 = and <8 x i1> %5634, %5701
  %5870 = load <8 x i1>, ptr %.spill187, align 1
  %5871 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5869, <8 x i1> %5870
  store <8 x i1> %5871, ptr %.spill187, align 1
  %5872 = and <8 x i1> %5634, %5702
  %5873 = load <8 x i1>, ptr %.spill188, align 1
  %5874 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5872, <8 x i1> %5873
  store <8 x i1> %5874, ptr %.spill188, align 1
  %5875 = and <8 x i1> %5634, %5703
  %5876 = load <8 x i1>, ptr %.spill189, align 1
  %5877 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5875, <8 x i1> %5876
  store <8 x i1> %5877, ptr %.spill189, align 1
  %5878 = and <8 x i1> %5634, %5704
  %5879 = load <8 x i1>, ptr %.spill190, align 1
  %5880 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5878, <8 x i1> %5879
  store <8 x i1> %5880, ptr %.spill190, align 1
  %5881 = and <8 x i1> %5635, %5705
  %5882 = load <8 x i1>, ptr %.spill191, align 1
  %5883 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5881, <8 x i1> %5882
  store <8 x i1> %5883, ptr %.spill191, align 1
  %5884 = and <8 x i1> %5635, %5706
  %5885 = load <8 x i1>, ptr %.spill192, align 1
  %5886 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5884, <8 x i1> %5885
  store <8 x i1> %5886, ptr %.spill192, align 1
  %5887 = and <8 x i1> %5635, %5707
  %5888 = load <8 x i1>, ptr %.spill193, align 1
  %5889 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5887, <8 x i1> %5888
  store <8 x i1> %5889, ptr %.spill193, align 1
  %5890 = and <8 x i1> %5635, %5708
  %5891 = load <8 x i1>, ptr %.spill194, align 1
  %5892 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5890, <8 x i1> %5891
  store <8 x i1> %5892, ptr %.spill194, align 1
  %5893 = and <8 x i1> %5636, %5709
  %5894 = load <8 x i1>, ptr %.spill195, align 1
  %5895 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5893, <8 x i1> %5894
  store <8 x i1> %5895, ptr %.spill195, align 1
  %5896 = and <8 x i1> %5636, %5710
  %5897 = load <8 x i1>, ptr %.spill196, align 1
  %5898 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5896, <8 x i1> %5897
  store <8 x i1> %5898, ptr %.spill196, align 1
  %5899 = and <8 x i1> %5636, %5711
  %5900 = load <8 x i1>, ptr %.spill197, align 1
  %5901 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5899, <8 x i1> %5900
  store <8 x i1> %5901, ptr %.spill197, align 1
  %5902 = and <8 x i1> %5636, %5712
  %5903 = load <8 x i1>, ptr %.spill198, align 1
  %5904 = select <8 x i1> %convergence.cascade.result1108, <8 x i1> %5902, <8 x i1> %5903
  store <8 x i1> %5904, ptr %.spill198, align 1
  %5905 = select <8 x i1> %5713, <8 x float> %5541, <8 x float> splat (float 0xC6293E5940000000)
  %5906 = load <8 x float>, ptr %.spill199, align 32
  %5907 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5905, <8 x float> %5906
  store <8 x float> %5907, ptr %.spill199, align 32
  %5908 = select <8 x i1> %5725, <8 x float> %5542, <8 x float> splat (float 0xC6293E5940000000)
  %5909 = load <8 x float>, ptr %.spill200, align 32
  %5910 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5908, <8 x float> %5909
  store <8 x float> %5910, ptr %.spill200, align 32
  %5911 = select <8 x i1> %5737, <8 x float> %5543, <8 x float> splat (float 0xC6293E5940000000)
  %5912 = load <8 x float>, ptr %.spill201, align 32
  %5913 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5911, <8 x float> %5912
  store <8 x float> %5913, ptr %.spill201, align 32
  %5914 = select <8 x i1> %5749, <8 x float> %5544, <8 x float> splat (float 0xC6293E5940000000)
  %5915 = load <8 x float>, ptr %.spill202, align 32
  %5916 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5914, <8 x float> %5915
  store <8 x float> %5916, ptr %.spill202, align 32
  %5917 = select <8 x i1> %5761, <8 x float> %5545, <8 x float> splat (float 0xC6293E5940000000)
  %5918 = load <8 x float>, ptr %.spill203, align 32
  %5919 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5917, <8 x float> %5918
  store <8 x float> %5919, ptr %.spill203, align 32
  %5920 = select <8 x i1> %5773, <8 x float> %5546, <8 x float> splat (float 0xC6293E5940000000)
  %5921 = load <8 x float>, ptr %.spill204, align 32
  %5922 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5920, <8 x float> %5921
  store <8 x float> %5922, ptr %.spill204, align 32
  %5923 = select <8 x i1> %5785, <8 x float> %5547, <8 x float> splat (float 0xC6293E5940000000)
  %5924 = load <8 x float>, ptr %.spill205, align 32
  %5925 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5923, <8 x float> %5924
  store <8 x float> %5925, ptr %.spill205, align 32
  %5926 = select <8 x i1> %5797, <8 x float> %5548, <8 x float> splat (float 0xC6293E5940000000)
  %5927 = load <8 x float>, ptr %.spill206, align 32
  %5928 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5926, <8 x float> %5927
  store <8 x float> %5928, ptr %.spill206, align 32
  %5929 = select <8 x i1> %5809, <8 x float> %5549, <8 x float> splat (float 0xC6293E5940000000)
  %5930 = load <8 x float>, ptr %.spill207, align 32
  %5931 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5929, <8 x float> %5930
  store <8 x float> %5931, ptr %.spill207, align 32
  %5932 = select <8 x i1> %5821, <8 x float> %5550, <8 x float> splat (float 0xC6293E5940000000)
  %5933 = load <8 x float>, ptr %.spill208, align 32
  %5934 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5932, <8 x float> %5933
  store <8 x float> %5934, ptr %.spill208, align 32
  %5935 = select <8 x i1> %5833, <8 x float> %5551, <8 x float> splat (float 0xC6293E5940000000)
  %5936 = load <8 x float>, ptr %.spill209, align 32
  %5937 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5935, <8 x float> %5936
  store <8 x float> %5937, ptr %.spill209, align 32
  %5938 = select <8 x i1> %5845, <8 x float> %5552, <8 x float> splat (float 0xC6293E5940000000)
  %5939 = load <8 x float>, ptr %.spill210, align 32
  %5940 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5938, <8 x float> %5939
  store <8 x float> %5940, ptr %.spill210, align 32
  %5941 = select <8 x i1> %5857, <8 x float> %5553, <8 x float> splat (float 0xC6293E5940000000)
  %5942 = load <8 x float>, ptr %.spill211, align 32
  %5943 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5941, <8 x float> %5942
  store <8 x float> %5943, ptr %.spill211, align 32
  %5944 = select <8 x i1> %5869, <8 x float> %5554, <8 x float> splat (float 0xC6293E5940000000)
  %5945 = load <8 x float>, ptr %.spill212, align 32
  %5946 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5944, <8 x float> %5945
  store <8 x float> %5946, ptr %.spill212, align 32
  %5947 = select <8 x i1> %5881, <8 x float> %5555, <8 x float> splat (float 0xC6293E5940000000)
  %5948 = load <8 x float>, ptr %.spill213, align 32
  %5949 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5947, <8 x float> %5948
  store <8 x float> %5949, ptr %.spill213, align 32
  %5950 = select <8 x i1> %5893, <8 x float> %5556, <8 x float> splat (float 0xC6293E5940000000)
  %5951 = load <8 x float>, ptr %.spill214, align 32
  %5952 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5950, <8 x float> %5951
  store <8 x float> %5952, ptr %.spill214, align 32
  %5953 = select <8 x i1> %5716, <8 x float> %5557, <8 x float> splat (float 0xC6293E5940000000)
  %5954 = load <8 x float>, ptr %.spill215, align 32
  %5955 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5953, <8 x float> %5954
  store <8 x float> %5955, ptr %.spill215, align 32
  %5956 = select <8 x i1> %5728, <8 x float> %5558, <8 x float> splat (float 0xC6293E5940000000)
  %5957 = load <8 x float>, ptr %.spill216, align 32
  %5958 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5956, <8 x float> %5957
  store <8 x float> %5958, ptr %.spill216, align 32
  %5959 = select <8 x i1> %5740, <8 x float> %5559, <8 x float> splat (float 0xC6293E5940000000)
  %5960 = load <8 x float>, ptr %.spill217, align 32
  %5961 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5959, <8 x float> %5960
  store <8 x float> %5961, ptr %.spill217, align 32
  %5962 = select <8 x i1> %5752, <8 x float> %5560, <8 x float> splat (float 0xC6293E5940000000)
  %5963 = load <8 x float>, ptr %.spill218, align 32
  %5964 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5962, <8 x float> %5963
  store <8 x float> %5964, ptr %.spill218, align 32
  %5965 = select <8 x i1> %5764, <8 x float> %5561, <8 x float> splat (float 0xC6293E5940000000)
  %5966 = load <8 x float>, ptr %.spill219, align 32
  %5967 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5965, <8 x float> %5966
  store <8 x float> %5967, ptr %.spill219, align 32
  %5968 = select <8 x i1> %5776, <8 x float> %5562, <8 x float> splat (float 0xC6293E5940000000)
  %5969 = load <8 x float>, ptr %.spill220, align 32
  %5970 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5968, <8 x float> %5969
  store <8 x float> %5970, ptr %.spill220, align 32
  %5971 = select <8 x i1> %5788, <8 x float> %5563, <8 x float> splat (float 0xC6293E5940000000)
  %5972 = load <8 x float>, ptr %.spill221, align 32
  %5973 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5971, <8 x float> %5972
  store <8 x float> %5973, ptr %.spill221, align 32
  %5974 = select <8 x i1> %5800, <8 x float> %5564, <8 x float> splat (float 0xC6293E5940000000)
  %5975 = load <8 x float>, ptr %.spill222, align 32
  %5976 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5974, <8 x float> %5975
  store <8 x float> %5976, ptr %.spill222, align 32
  %5977 = select <8 x i1> %5812, <8 x float> %5565, <8 x float> splat (float 0xC6293E5940000000)
  %5978 = load <8 x float>, ptr %.spill223, align 32
  %5979 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5977, <8 x float> %5978
  store <8 x float> %5979, ptr %.spill223, align 32
  %5980 = select <8 x i1> %5824, <8 x float> %5566, <8 x float> splat (float 0xC6293E5940000000)
  %5981 = load <8 x float>, ptr %.spill224, align 32
  %5982 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5980, <8 x float> %5981
  store <8 x float> %5982, ptr %.spill224, align 32
  %5983 = select <8 x i1> %5836, <8 x float> %5567, <8 x float> splat (float 0xC6293E5940000000)
  %5984 = load <8 x float>, ptr %.spill225, align 32
  %5985 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5983, <8 x float> %5984
  store <8 x float> %5985, ptr %.spill225, align 32
  %5986 = select <8 x i1> %5848, <8 x float> %5568, <8 x float> splat (float 0xC6293E5940000000)
  %5987 = load <8 x float>, ptr %.spill226, align 32
  %5988 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5986, <8 x float> %5987
  store <8 x float> %5988, ptr %.spill226, align 32
  %5989 = select <8 x i1> %5860, <8 x float> %5569, <8 x float> splat (float 0xC6293E5940000000)
  %5990 = load <8 x float>, ptr %.spill227, align 32
  %5991 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5989, <8 x float> %5990
  store <8 x float> %5991, ptr %.spill227, align 32
  %5992 = select <8 x i1> %5872, <8 x float> %5570, <8 x float> splat (float 0xC6293E5940000000)
  %5993 = load <8 x float>, ptr %.spill228, align 32
  %5994 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5992, <8 x float> %5993
  store <8 x float> %5994, ptr %.spill228, align 32
  %5995 = select <8 x i1> %5884, <8 x float> %5571, <8 x float> splat (float 0xC6293E5940000000)
  %5996 = load <8 x float>, ptr %.spill229, align 32
  %5997 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5995, <8 x float> %5996
  store <8 x float> %5997, ptr %.spill229, align 32
  %5998 = select <8 x i1> %5896, <8 x float> %5572, <8 x float> splat (float 0xC6293E5940000000)
  %5999 = load <8 x float>, ptr %.spill230, align 32
  %6000 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5998, <8 x float> %5999
  store <8 x float> %6000, ptr %.spill230, align 32
  %6001 = select <8 x i1> %5719, <8 x float> %5573, <8 x float> splat (float 0xC6293E5940000000)
  %6002 = load <8 x float>, ptr %.spill231, align 32
  %6003 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6001, <8 x float> %6002
  store <8 x float> %6003, ptr %.spill231, align 32
  %6004 = select <8 x i1> %5731, <8 x float> %5574, <8 x float> splat (float 0xC6293E5940000000)
  %6005 = load <8 x float>, ptr %.spill232, align 32
  %6006 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6004, <8 x float> %6005
  store <8 x float> %6006, ptr %.spill232, align 32
  %6007 = select <8 x i1> %5743, <8 x float> %5575, <8 x float> splat (float 0xC6293E5940000000)
  %6008 = load <8 x float>, ptr %.spill233, align 32
  %6009 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6007, <8 x float> %6008
  store <8 x float> %6009, ptr %.spill233, align 32
  %6010 = select <8 x i1> %5755, <8 x float> %5576, <8 x float> splat (float 0xC6293E5940000000)
  %6011 = load <8 x float>, ptr %.spill234, align 32
  %6012 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6010, <8 x float> %6011
  store <8 x float> %6012, ptr %.spill234, align 32
  %6013 = select <8 x i1> %5767, <8 x float> %5577, <8 x float> splat (float 0xC6293E5940000000)
  %6014 = load <8 x float>, ptr %.spill235, align 32
  %6015 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6013, <8 x float> %6014
  store <8 x float> %6015, ptr %.spill235, align 32
  %6016 = select <8 x i1> %5779, <8 x float> %5578, <8 x float> splat (float 0xC6293E5940000000)
  %6017 = load <8 x float>, ptr %.spill236, align 32
  %6018 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6016, <8 x float> %6017
  store <8 x float> %6018, ptr %.spill236, align 32
  %6019 = select <8 x i1> %5791, <8 x float> %5579, <8 x float> splat (float 0xC6293E5940000000)
  %6020 = load <8 x float>, ptr %.spill237, align 32
  %6021 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6019, <8 x float> %6020
  store <8 x float> %6021, ptr %.spill237, align 32
  %6022 = select <8 x i1> %5803, <8 x float> %5580, <8 x float> splat (float 0xC6293E5940000000)
  %6023 = load <8 x float>, ptr %.spill238, align 32
  %6024 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6022, <8 x float> %6023
  store <8 x float> %6024, ptr %.spill238, align 32
  %6025 = select <8 x i1> %5815, <8 x float> %5581, <8 x float> splat (float 0xC6293E5940000000)
  %6026 = load <8 x float>, ptr %.spill239, align 32
  %6027 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6025, <8 x float> %6026
  store <8 x float> %6027, ptr %.spill239, align 32
  %6028 = select <8 x i1> %5827, <8 x float> %5582, <8 x float> splat (float 0xC6293E5940000000)
  %6029 = load <8 x float>, ptr %.spill240, align 32
  %6030 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6028, <8 x float> %6029
  store <8 x float> %6030, ptr %.spill240, align 32
  %6031 = select <8 x i1> %5839, <8 x float> %5583, <8 x float> splat (float 0xC6293E5940000000)
  %6032 = load <8 x float>, ptr %.spill241, align 32
  %6033 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6031, <8 x float> %6032
  store <8 x float> %6033, ptr %.spill241, align 32
  %6034 = select <8 x i1> %5851, <8 x float> %5584, <8 x float> splat (float 0xC6293E5940000000)
  %6035 = load <8 x float>, ptr %.spill242, align 32
  %6036 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6034, <8 x float> %6035
  store <8 x float> %6036, ptr %.spill242, align 32
  %6037 = select <8 x i1> %5863, <8 x float> %5585, <8 x float> splat (float 0xC6293E5940000000)
  %6038 = load <8 x float>, ptr %.spill243, align 32
  %6039 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6037, <8 x float> %6038
  store <8 x float> %6039, ptr %.spill243, align 32
  %6040 = select <8 x i1> %5875, <8 x float> %5586, <8 x float> splat (float 0xC6293E5940000000)
  %6041 = load <8 x float>, ptr %.spill244, align 32
  %6042 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6040, <8 x float> %6041
  store <8 x float> %6042, ptr %.spill244, align 32
  %6043 = select <8 x i1> %5887, <8 x float> %5587, <8 x float> splat (float 0xC6293E5940000000)
  %6044 = load <8 x float>, ptr %.spill245, align 32
  %6045 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6043, <8 x float> %6044
  store <8 x float> %6045, ptr %.spill245, align 32
  %6046 = select <8 x i1> %5899, <8 x float> %5588, <8 x float> splat (float 0xC6293E5940000000)
  %6047 = load <8 x float>, ptr %.spill246, align 32
  %6048 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6046, <8 x float> %6047
  store <8 x float> %6048, ptr %.spill246, align 32
  %6049 = select <8 x i1> %5722, <8 x float> %5589, <8 x float> splat (float 0xC6293E5940000000)
  %6050 = load <8 x float>, ptr %.spill247, align 32
  %6051 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6049, <8 x float> %6050
  store <8 x float> %6051, ptr %.spill247, align 32
  %6052 = select <8 x i1> %5734, <8 x float> %5590, <8 x float> splat (float 0xC6293E5940000000)
  %6053 = load <8 x float>, ptr %.spill248, align 32
  %6054 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6052, <8 x float> %6053
  store <8 x float> %6054, ptr %.spill248, align 32
  %6055 = select <8 x i1> %5746, <8 x float> %5591, <8 x float> splat (float 0xC6293E5940000000)
  %6056 = load <8 x float>, ptr %.spill249, align 32
  %6057 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6055, <8 x float> %6056
  store <8 x float> %6057, ptr %.spill249, align 32
  %6058 = select <8 x i1> %5758, <8 x float> %5592, <8 x float> splat (float 0xC6293E5940000000)
  %6059 = load <8 x float>, ptr %.spill250, align 32
  %6060 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6058, <8 x float> %6059
  store <8 x float> %6060, ptr %.spill250, align 32
  %6061 = select <8 x i1> %5770, <8 x float> %5593, <8 x float> splat (float 0xC6293E5940000000)
  %6062 = load <8 x float>, ptr %.spill251, align 32
  %6063 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6061, <8 x float> %6062
  store <8 x float> %6063, ptr %.spill251, align 32
  %6064 = select <8 x i1> %5782, <8 x float> %5594, <8 x float> splat (float 0xC6293E5940000000)
  %6065 = load <8 x float>, ptr %.spill252, align 32
  %6066 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6064, <8 x float> %6065
  store <8 x float> %6066, ptr %.spill252, align 32
  %6067 = select <8 x i1> %5794, <8 x float> %5595, <8 x float> splat (float 0xC6293E5940000000)
  %6068 = load <8 x float>, ptr %.spill253, align 32
  %6069 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6067, <8 x float> %6068
  store <8 x float> %6069, ptr %.spill253, align 32
  %6070 = select <8 x i1> %5806, <8 x float> %5596, <8 x float> splat (float 0xC6293E5940000000)
  %6071 = load <8 x float>, ptr %.spill254, align 32
  %6072 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6070, <8 x float> %6071
  store <8 x float> %6072, ptr %.spill254, align 32
  %6073 = select <8 x i1> %5818, <8 x float> %5597, <8 x float> splat (float 0xC6293E5940000000)
  %6074 = load <8 x float>, ptr %.spill255, align 32
  %6075 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6073, <8 x float> %6074
  store <8 x float> %6075, ptr %.spill255, align 32
  %6076 = select <8 x i1> %5830, <8 x float> %5598, <8 x float> splat (float 0xC6293E5940000000)
  %6077 = load <8 x float>, ptr %.spill256, align 32
  %6078 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6076, <8 x float> %6077
  store <8 x float> %6078, ptr %.spill256, align 32
  %6079 = select <8 x i1> %5842, <8 x float> %5599, <8 x float> splat (float 0xC6293E5940000000)
  %6080 = load <8 x float>, ptr %.spill257, align 32
  %6081 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6079, <8 x float> %6080
  store <8 x float> %6081, ptr %.spill257, align 32
  %6082 = select <8 x i1> %5854, <8 x float> %5600, <8 x float> splat (float 0xC6293E5940000000)
  %6083 = load <8 x float>, ptr %.spill258, align 32
  %6084 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6082, <8 x float> %6083
  store <8 x float> %6084, ptr %.spill258, align 32
  %6085 = select <8 x i1> %5866, <8 x float> %5601, <8 x float> splat (float 0xC6293E5940000000)
  %6086 = load <8 x float>, ptr %.spill259, align 32
  %6087 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6085, <8 x float> %6086
  store <8 x float> %6087, ptr %.spill259, align 32
  %6088 = select <8 x i1> %5878, <8 x float> %5602, <8 x float> splat (float 0xC6293E5940000000)
  %6089 = load <8 x float>, ptr %.spill260, align 32
  %6090 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6088, <8 x float> %6089
  store <8 x float> %6090, ptr %.spill260, align 32
  %6091 = select <8 x i1> %5890, <8 x float> %5603, <8 x float> splat (float 0xC6293E5940000000)
  %6092 = load <8 x float>, ptr %.spill261, align 32
  %6093 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6091, <8 x float> %6092
  store <8 x float> %6093, ptr %.spill261, align 32
  %6094 = select <8 x i1> %5902, <8 x float> %5604, <8 x float> splat (float 0xC6293E5940000000)
  %6095 = load <8 x float>, ptr %.spill262, align 32
  %6096 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6094, <8 x float> %6095
  store <8 x float> %6096, ptr %.spill262, align 32
  %6097 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill263, align 64
  %6098 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6099 = extractvalue { <8 x ptr>, <8 x i64> } %6097, 0
  %6100 = select <8 x i1> %convergence.cascade.result1108, <8 x ptr> %6098, <8 x ptr> %6099
  %6101 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6102 = extractvalue { <8 x ptr>, <8 x i64> } %6097, 1
  %6103 = select <8 x i1> %convergence.cascade.result1108, <8 x i64> %6101, <8 x i64> %6102
  %6104 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6100, 0
  %6105 = insertvalue { <8 x ptr>, <8 x i64> } %6104, <8 x i64> %6103, 1
  store { <8 x ptr>, <8 x i64> } %6105, ptr %tile_snapshot.spill263, align 64
  %6106 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6107 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6108 = add <8 x i64> %6107, zeroinitializer
  %6109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6106, 0
  %6110 = insertvalue { <8 x ptr>, <8 x i64> } %6109, <8 x i64> %6108, 1
  %6111 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6112 = extractvalue { <8 x ptr>, <8 x i64> } %6110, 1
  %6113 = extractelement <8 x ptr> %6111, i32 0
  %6114 = extractelement <8 x i64> %6112, i32 %5540
  %6115 = zext i32 %5540 to i64
  %6116 = mul i64 %6115, 4
  %6117 = sub i64 %6114, %6116
  %6118 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6119 = select i1 %6118, i64 %6117, i64 0
  %private.contiguous.address = getelementptr i8, ptr %6113, i64 %6119
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %6120 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5905, <8 x float> %private.contiguous.preserve
  store <8 x float> %6120, ptr %private.contiguous.address, align 4
  %6121 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6122 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6123 = add <8 x i64> %6122, splat (i64 32)
  %6124 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6121, 0
  %6125 = insertvalue { <8 x ptr>, <8 x i64> } %6124, <8 x i64> %6123, 1
  %6126 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6127 = extractvalue { <8 x ptr>, <8 x i64> } %6125, 1
  %6128 = extractelement <8 x ptr> %6126, i32 0
  %6129 = extractelement <8 x i64> %6127, i32 %5540
  %6130 = zext i32 %5540 to i64
  %6131 = mul i64 %6130, 4
  %6132 = sub i64 %6129, %6131
  %6133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6134 = select i1 %6133, i64 %6132, i64 0
  %private.contiguous.address1193 = getelementptr i8, ptr %6128, i64 %6134
  %private.contiguous.preserve1194 = load <8 x float>, ptr %private.contiguous.address1193, align 4
  %6135 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5908, <8 x float> %private.contiguous.preserve1194
  store <8 x float> %6135, ptr %private.contiguous.address1193, align 4
  %6136 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6137 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6138 = add <8 x i64> %6137, splat (i64 64)
  %6139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6136, 0
  %6140 = insertvalue { <8 x ptr>, <8 x i64> } %6139, <8 x i64> %6138, 1
  %6141 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6142 = extractvalue { <8 x ptr>, <8 x i64> } %6140, 1
  %6143 = extractelement <8 x ptr> %6141, i32 0
  %6144 = extractelement <8 x i64> %6142, i32 %5540
  %6145 = zext i32 %5540 to i64
  %6146 = mul i64 %6145, 4
  %6147 = sub i64 %6144, %6146
  %6148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6149 = select i1 %6148, i64 %6147, i64 0
  %private.contiguous.address1195 = getelementptr i8, ptr %6143, i64 %6149
  %private.contiguous.preserve1196 = load <8 x float>, ptr %private.contiguous.address1195, align 4
  %6150 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5911, <8 x float> %private.contiguous.preserve1196
  store <8 x float> %6150, ptr %private.contiguous.address1195, align 4
  %6151 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6152 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6153 = add <8 x i64> %6152, splat (i64 96)
  %6154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6151, 0
  %6155 = insertvalue { <8 x ptr>, <8 x i64> } %6154, <8 x i64> %6153, 1
  %6156 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6157 = extractvalue { <8 x ptr>, <8 x i64> } %6155, 1
  %6158 = extractelement <8 x ptr> %6156, i32 0
  %6159 = extractelement <8 x i64> %6157, i32 %5540
  %6160 = zext i32 %5540 to i64
  %6161 = mul i64 %6160, 4
  %6162 = sub i64 %6159, %6161
  %6163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6164 = select i1 %6163, i64 %6162, i64 0
  %private.contiguous.address1197 = getelementptr i8, ptr %6158, i64 %6164
  %private.contiguous.preserve1198 = load <8 x float>, ptr %private.contiguous.address1197, align 4
  %6165 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5914, <8 x float> %private.contiguous.preserve1198
  store <8 x float> %6165, ptr %private.contiguous.address1197, align 4
  %6166 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6167 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6168 = add <8 x i64> %6167, splat (i64 128)
  %6169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6166, 0
  %6170 = insertvalue { <8 x ptr>, <8 x i64> } %6169, <8 x i64> %6168, 1
  %6171 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6172 = extractvalue { <8 x ptr>, <8 x i64> } %6170, 1
  %6173 = extractelement <8 x ptr> %6171, i32 0
  %6174 = extractelement <8 x i64> %6172, i32 %5540
  %6175 = zext i32 %5540 to i64
  %6176 = mul i64 %6175, 4
  %6177 = sub i64 %6174, %6176
  %6178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6179 = select i1 %6178, i64 %6177, i64 0
  %private.contiguous.address1199 = getelementptr i8, ptr %6173, i64 %6179
  %private.contiguous.preserve1200 = load <8 x float>, ptr %private.contiguous.address1199, align 4
  %6180 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5917, <8 x float> %private.contiguous.preserve1200
  store <8 x float> %6180, ptr %private.contiguous.address1199, align 4
  %6181 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6182 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6183 = add <8 x i64> %6182, splat (i64 160)
  %6184 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6181, 0
  %6185 = insertvalue { <8 x ptr>, <8 x i64> } %6184, <8 x i64> %6183, 1
  %6186 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6187 = extractvalue { <8 x ptr>, <8 x i64> } %6185, 1
  %6188 = extractelement <8 x ptr> %6186, i32 0
  %6189 = extractelement <8 x i64> %6187, i32 %5540
  %6190 = zext i32 %5540 to i64
  %6191 = mul i64 %6190, 4
  %6192 = sub i64 %6189, %6191
  %6193 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6194 = select i1 %6193, i64 %6192, i64 0
  %private.contiguous.address1201 = getelementptr i8, ptr %6188, i64 %6194
  %private.contiguous.preserve1202 = load <8 x float>, ptr %private.contiguous.address1201, align 4
  %6195 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5920, <8 x float> %private.contiguous.preserve1202
  store <8 x float> %6195, ptr %private.contiguous.address1201, align 4
  %6196 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6197 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6198 = add <8 x i64> %6197, splat (i64 192)
  %6199 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6196, 0
  %6200 = insertvalue { <8 x ptr>, <8 x i64> } %6199, <8 x i64> %6198, 1
  %6201 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6202 = extractvalue { <8 x ptr>, <8 x i64> } %6200, 1
  %6203 = extractelement <8 x ptr> %6201, i32 0
  %6204 = extractelement <8 x i64> %6202, i32 %5540
  %6205 = zext i32 %5540 to i64
  %6206 = mul i64 %6205, 4
  %6207 = sub i64 %6204, %6206
  %6208 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6209 = select i1 %6208, i64 %6207, i64 0
  %private.contiguous.address1203 = getelementptr i8, ptr %6203, i64 %6209
  %private.contiguous.preserve1204 = load <8 x float>, ptr %private.contiguous.address1203, align 4
  %6210 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5923, <8 x float> %private.contiguous.preserve1204
  store <8 x float> %6210, ptr %private.contiguous.address1203, align 4
  %6211 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6212 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6213 = add <8 x i64> %6212, splat (i64 224)
  %6214 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6211, 0
  %6215 = insertvalue { <8 x ptr>, <8 x i64> } %6214, <8 x i64> %6213, 1
  %6216 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6217 = extractvalue { <8 x ptr>, <8 x i64> } %6215, 1
  %6218 = extractelement <8 x ptr> %6216, i32 0
  %6219 = extractelement <8 x i64> %6217, i32 %5540
  %6220 = zext i32 %5540 to i64
  %6221 = mul i64 %6220, 4
  %6222 = sub i64 %6219, %6221
  %6223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6224 = select i1 %6223, i64 %6222, i64 0
  %private.contiguous.address1205 = getelementptr i8, ptr %6218, i64 %6224
  %private.contiguous.preserve1206 = load <8 x float>, ptr %private.contiguous.address1205, align 4
  %6225 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5926, <8 x float> %private.contiguous.preserve1206
  store <8 x float> %6225, ptr %private.contiguous.address1205, align 4
  %6226 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6227 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6228 = add <8 x i64> %6227, splat (i64 256)
  %6229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6226, 0
  %6230 = insertvalue { <8 x ptr>, <8 x i64> } %6229, <8 x i64> %6228, 1
  %6231 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6232 = extractvalue { <8 x ptr>, <8 x i64> } %6230, 1
  %6233 = extractelement <8 x ptr> %6231, i32 0
  %6234 = extractelement <8 x i64> %6232, i32 %5540
  %6235 = zext i32 %5540 to i64
  %6236 = mul i64 %6235, 4
  %6237 = sub i64 %6234, %6236
  %6238 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6239 = select i1 %6238, i64 %6237, i64 0
  %private.contiguous.address1207 = getelementptr i8, ptr %6233, i64 %6239
  %private.contiguous.preserve1208 = load <8 x float>, ptr %private.contiguous.address1207, align 4
  %6240 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5929, <8 x float> %private.contiguous.preserve1208
  store <8 x float> %6240, ptr %private.contiguous.address1207, align 4
  %6241 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6242 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6243 = add <8 x i64> %6242, splat (i64 288)
  %6244 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6241, 0
  %6245 = insertvalue { <8 x ptr>, <8 x i64> } %6244, <8 x i64> %6243, 1
  %6246 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6247 = extractvalue { <8 x ptr>, <8 x i64> } %6245, 1
  %6248 = extractelement <8 x ptr> %6246, i32 0
  %6249 = extractelement <8 x i64> %6247, i32 %5540
  %6250 = zext i32 %5540 to i64
  %6251 = mul i64 %6250, 4
  %6252 = sub i64 %6249, %6251
  %6253 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6254 = select i1 %6253, i64 %6252, i64 0
  %private.contiguous.address1209 = getelementptr i8, ptr %6248, i64 %6254
  %private.contiguous.preserve1210 = load <8 x float>, ptr %private.contiguous.address1209, align 4
  %6255 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5932, <8 x float> %private.contiguous.preserve1210
  store <8 x float> %6255, ptr %private.contiguous.address1209, align 4
  %6256 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6257 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6258 = add <8 x i64> %6257, splat (i64 320)
  %6259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6256, 0
  %6260 = insertvalue { <8 x ptr>, <8 x i64> } %6259, <8 x i64> %6258, 1
  %6261 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6262 = extractvalue { <8 x ptr>, <8 x i64> } %6260, 1
  %6263 = extractelement <8 x ptr> %6261, i32 0
  %6264 = extractelement <8 x i64> %6262, i32 %5540
  %6265 = zext i32 %5540 to i64
  %6266 = mul i64 %6265, 4
  %6267 = sub i64 %6264, %6266
  %6268 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6269 = select i1 %6268, i64 %6267, i64 0
  %private.contiguous.address1211 = getelementptr i8, ptr %6263, i64 %6269
  %private.contiguous.preserve1212 = load <8 x float>, ptr %private.contiguous.address1211, align 4
  %6270 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5935, <8 x float> %private.contiguous.preserve1212
  store <8 x float> %6270, ptr %private.contiguous.address1211, align 4
  %6271 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6272 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6273 = add <8 x i64> %6272, splat (i64 352)
  %6274 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6271, 0
  %6275 = insertvalue { <8 x ptr>, <8 x i64> } %6274, <8 x i64> %6273, 1
  %6276 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6277 = extractvalue { <8 x ptr>, <8 x i64> } %6275, 1
  %6278 = extractelement <8 x ptr> %6276, i32 0
  %6279 = extractelement <8 x i64> %6277, i32 %5540
  %6280 = zext i32 %5540 to i64
  %6281 = mul i64 %6280, 4
  %6282 = sub i64 %6279, %6281
  %6283 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6284 = select i1 %6283, i64 %6282, i64 0
  %private.contiguous.address1213 = getelementptr i8, ptr %6278, i64 %6284
  %private.contiguous.preserve1214 = load <8 x float>, ptr %private.contiguous.address1213, align 4
  %6285 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5938, <8 x float> %private.contiguous.preserve1214
  store <8 x float> %6285, ptr %private.contiguous.address1213, align 4
  %6286 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6287 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6288 = add <8 x i64> %6287, splat (i64 384)
  %6289 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6286, 0
  %6290 = insertvalue { <8 x ptr>, <8 x i64> } %6289, <8 x i64> %6288, 1
  %6291 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6292 = extractvalue { <8 x ptr>, <8 x i64> } %6290, 1
  %6293 = extractelement <8 x ptr> %6291, i32 0
  %6294 = extractelement <8 x i64> %6292, i32 %5540
  %6295 = zext i32 %5540 to i64
  %6296 = mul i64 %6295, 4
  %6297 = sub i64 %6294, %6296
  %6298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6299 = select i1 %6298, i64 %6297, i64 0
  %private.contiguous.address1215 = getelementptr i8, ptr %6293, i64 %6299
  %private.contiguous.preserve1216 = load <8 x float>, ptr %private.contiguous.address1215, align 4
  %6300 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5941, <8 x float> %private.contiguous.preserve1216
  store <8 x float> %6300, ptr %private.contiguous.address1215, align 4
  %6301 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6302 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6303 = add <8 x i64> %6302, splat (i64 416)
  %6304 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6301, 0
  %6305 = insertvalue { <8 x ptr>, <8 x i64> } %6304, <8 x i64> %6303, 1
  %6306 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6307 = extractvalue { <8 x ptr>, <8 x i64> } %6305, 1
  %6308 = extractelement <8 x ptr> %6306, i32 0
  %6309 = extractelement <8 x i64> %6307, i32 %5540
  %6310 = zext i32 %5540 to i64
  %6311 = mul i64 %6310, 4
  %6312 = sub i64 %6309, %6311
  %6313 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6314 = select i1 %6313, i64 %6312, i64 0
  %private.contiguous.address1217 = getelementptr i8, ptr %6308, i64 %6314
  %private.contiguous.preserve1218 = load <8 x float>, ptr %private.contiguous.address1217, align 4
  %6315 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5944, <8 x float> %private.contiguous.preserve1218
  store <8 x float> %6315, ptr %private.contiguous.address1217, align 4
  %6316 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6317 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6318 = add <8 x i64> %6317, splat (i64 448)
  %6319 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6316, 0
  %6320 = insertvalue { <8 x ptr>, <8 x i64> } %6319, <8 x i64> %6318, 1
  %6321 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6322 = extractvalue { <8 x ptr>, <8 x i64> } %6320, 1
  %6323 = extractelement <8 x ptr> %6321, i32 0
  %6324 = extractelement <8 x i64> %6322, i32 %5540
  %6325 = zext i32 %5540 to i64
  %6326 = mul i64 %6325, 4
  %6327 = sub i64 %6324, %6326
  %6328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6329 = select i1 %6328, i64 %6327, i64 0
  %private.contiguous.address1219 = getelementptr i8, ptr %6323, i64 %6329
  %private.contiguous.preserve1220 = load <8 x float>, ptr %private.contiguous.address1219, align 4
  %6330 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5947, <8 x float> %private.contiguous.preserve1220
  store <8 x float> %6330, ptr %private.contiguous.address1219, align 4
  %6331 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6332 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6333 = add <8 x i64> %6332, splat (i64 480)
  %6334 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6331, 0
  %6335 = insertvalue { <8 x ptr>, <8 x i64> } %6334, <8 x i64> %6333, 1
  %6336 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6337 = extractvalue { <8 x ptr>, <8 x i64> } %6335, 1
  %6338 = extractelement <8 x ptr> %6336, i32 0
  %6339 = extractelement <8 x i64> %6337, i32 %5540
  %6340 = zext i32 %5540 to i64
  %6341 = mul i64 %6340, 4
  %6342 = sub i64 %6339, %6341
  %6343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6344 = select i1 %6343, i64 %6342, i64 0
  %private.contiguous.address1221 = getelementptr i8, ptr %6338, i64 %6344
  %private.contiguous.preserve1222 = load <8 x float>, ptr %private.contiguous.address1221, align 4
  %6345 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5950, <8 x float> %private.contiguous.preserve1222
  store <8 x float> %6345, ptr %private.contiguous.address1221, align 4
  %6346 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6347 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6348 = add <8 x i64> %6347, splat (i64 512)
  %6349 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6346, 0
  %6350 = insertvalue { <8 x ptr>, <8 x i64> } %6349, <8 x i64> %6348, 1
  %6351 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6352 = extractvalue { <8 x ptr>, <8 x i64> } %6350, 1
  %6353 = extractelement <8 x ptr> %6351, i32 0
  %6354 = extractelement <8 x i64> %6352, i32 %5540
  %6355 = zext i32 %5540 to i64
  %6356 = mul i64 %6355, 4
  %6357 = sub i64 %6354, %6356
  %6358 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6359 = select i1 %6358, i64 %6357, i64 0
  %private.contiguous.address1223 = getelementptr i8, ptr %6353, i64 %6359
  %private.contiguous.preserve1224 = load <8 x float>, ptr %private.contiguous.address1223, align 4
  %6360 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5953, <8 x float> %private.contiguous.preserve1224
  store <8 x float> %6360, ptr %private.contiguous.address1223, align 4
  %6361 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6362 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6363 = add <8 x i64> %6362, splat (i64 544)
  %6364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6361, 0
  %6365 = insertvalue { <8 x ptr>, <8 x i64> } %6364, <8 x i64> %6363, 1
  %6366 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6367 = extractvalue { <8 x ptr>, <8 x i64> } %6365, 1
  %6368 = extractelement <8 x ptr> %6366, i32 0
  %6369 = extractelement <8 x i64> %6367, i32 %5540
  %6370 = zext i32 %5540 to i64
  %6371 = mul i64 %6370, 4
  %6372 = sub i64 %6369, %6371
  %6373 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6374 = select i1 %6373, i64 %6372, i64 0
  %private.contiguous.address1225 = getelementptr i8, ptr %6368, i64 %6374
  %private.contiguous.preserve1226 = load <8 x float>, ptr %private.contiguous.address1225, align 4
  %6375 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5956, <8 x float> %private.contiguous.preserve1226
  store <8 x float> %6375, ptr %private.contiguous.address1225, align 4
  %6376 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6377 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6378 = add <8 x i64> %6377, splat (i64 576)
  %6379 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6376, 0
  %6380 = insertvalue { <8 x ptr>, <8 x i64> } %6379, <8 x i64> %6378, 1
  %6381 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6382 = extractvalue { <8 x ptr>, <8 x i64> } %6380, 1
  %6383 = extractelement <8 x ptr> %6381, i32 0
  %6384 = extractelement <8 x i64> %6382, i32 %5540
  %6385 = zext i32 %5540 to i64
  %6386 = mul i64 %6385, 4
  %6387 = sub i64 %6384, %6386
  %6388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6389 = select i1 %6388, i64 %6387, i64 0
  %private.contiguous.address1227 = getelementptr i8, ptr %6383, i64 %6389
  %private.contiguous.preserve1228 = load <8 x float>, ptr %private.contiguous.address1227, align 4
  %6390 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5959, <8 x float> %private.contiguous.preserve1228
  store <8 x float> %6390, ptr %private.contiguous.address1227, align 4
  %6391 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6392 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6393 = add <8 x i64> %6392, splat (i64 608)
  %6394 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6391, 0
  %6395 = insertvalue { <8 x ptr>, <8 x i64> } %6394, <8 x i64> %6393, 1
  %6396 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6397 = extractvalue { <8 x ptr>, <8 x i64> } %6395, 1
  %6398 = extractelement <8 x ptr> %6396, i32 0
  %6399 = extractelement <8 x i64> %6397, i32 %5540
  %6400 = zext i32 %5540 to i64
  %6401 = mul i64 %6400, 4
  %6402 = sub i64 %6399, %6401
  %6403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6404 = select i1 %6403, i64 %6402, i64 0
  %private.contiguous.address1229 = getelementptr i8, ptr %6398, i64 %6404
  %private.contiguous.preserve1230 = load <8 x float>, ptr %private.contiguous.address1229, align 4
  %6405 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5962, <8 x float> %private.contiguous.preserve1230
  store <8 x float> %6405, ptr %private.contiguous.address1229, align 4
  %6406 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6407 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6408 = add <8 x i64> %6407, splat (i64 640)
  %6409 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6406, 0
  %6410 = insertvalue { <8 x ptr>, <8 x i64> } %6409, <8 x i64> %6408, 1
  %6411 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6412 = extractvalue { <8 x ptr>, <8 x i64> } %6410, 1
  %6413 = extractelement <8 x ptr> %6411, i32 0
  %6414 = extractelement <8 x i64> %6412, i32 %5540
  %6415 = zext i32 %5540 to i64
  %6416 = mul i64 %6415, 4
  %6417 = sub i64 %6414, %6416
  %6418 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6419 = select i1 %6418, i64 %6417, i64 0
  %private.contiguous.address1231 = getelementptr i8, ptr %6413, i64 %6419
  %private.contiguous.preserve1232 = load <8 x float>, ptr %private.contiguous.address1231, align 4
  %6420 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5965, <8 x float> %private.contiguous.preserve1232
  store <8 x float> %6420, ptr %private.contiguous.address1231, align 4
  %6421 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6422 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6423 = add <8 x i64> %6422, splat (i64 672)
  %6424 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6421, 0
  %6425 = insertvalue { <8 x ptr>, <8 x i64> } %6424, <8 x i64> %6423, 1
  %6426 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6427 = extractvalue { <8 x ptr>, <8 x i64> } %6425, 1
  %6428 = extractelement <8 x ptr> %6426, i32 0
  %6429 = extractelement <8 x i64> %6427, i32 %5540
  %6430 = zext i32 %5540 to i64
  %6431 = mul i64 %6430, 4
  %6432 = sub i64 %6429, %6431
  %6433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6434 = select i1 %6433, i64 %6432, i64 0
  %private.contiguous.address1233 = getelementptr i8, ptr %6428, i64 %6434
  %private.contiguous.preserve1234 = load <8 x float>, ptr %private.contiguous.address1233, align 4
  %6435 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5968, <8 x float> %private.contiguous.preserve1234
  store <8 x float> %6435, ptr %private.contiguous.address1233, align 4
  %6436 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6437 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6438 = add <8 x i64> %6437, splat (i64 704)
  %6439 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6436, 0
  %6440 = insertvalue { <8 x ptr>, <8 x i64> } %6439, <8 x i64> %6438, 1
  %6441 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6442 = extractvalue { <8 x ptr>, <8 x i64> } %6440, 1
  %6443 = extractelement <8 x ptr> %6441, i32 0
  %6444 = extractelement <8 x i64> %6442, i32 %5540
  %6445 = zext i32 %5540 to i64
  %6446 = mul i64 %6445, 4
  %6447 = sub i64 %6444, %6446
  %6448 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6449 = select i1 %6448, i64 %6447, i64 0
  %private.contiguous.address1235 = getelementptr i8, ptr %6443, i64 %6449
  %private.contiguous.preserve1236 = load <8 x float>, ptr %private.contiguous.address1235, align 4
  %6450 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5971, <8 x float> %private.contiguous.preserve1236
  store <8 x float> %6450, ptr %private.contiguous.address1235, align 4
  %6451 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6452 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6453 = add <8 x i64> %6452, splat (i64 736)
  %6454 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6451, 0
  %6455 = insertvalue { <8 x ptr>, <8 x i64> } %6454, <8 x i64> %6453, 1
  %6456 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6457 = extractvalue { <8 x ptr>, <8 x i64> } %6455, 1
  %6458 = extractelement <8 x ptr> %6456, i32 0
  %6459 = extractelement <8 x i64> %6457, i32 %5540
  %6460 = zext i32 %5540 to i64
  %6461 = mul i64 %6460, 4
  %6462 = sub i64 %6459, %6461
  %6463 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6464 = select i1 %6463, i64 %6462, i64 0
  %private.contiguous.address1237 = getelementptr i8, ptr %6458, i64 %6464
  %private.contiguous.preserve1238 = load <8 x float>, ptr %private.contiguous.address1237, align 4
  %6465 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5974, <8 x float> %private.contiguous.preserve1238
  store <8 x float> %6465, ptr %private.contiguous.address1237, align 4
  %6466 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6467 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6468 = add <8 x i64> %6467, splat (i64 768)
  %6469 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6466, 0
  %6470 = insertvalue { <8 x ptr>, <8 x i64> } %6469, <8 x i64> %6468, 1
  %6471 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6472 = extractvalue { <8 x ptr>, <8 x i64> } %6470, 1
  %6473 = extractelement <8 x ptr> %6471, i32 0
  %6474 = extractelement <8 x i64> %6472, i32 %5540
  %6475 = zext i32 %5540 to i64
  %6476 = mul i64 %6475, 4
  %6477 = sub i64 %6474, %6476
  %6478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6479 = select i1 %6478, i64 %6477, i64 0
  %private.contiguous.address1239 = getelementptr i8, ptr %6473, i64 %6479
  %private.contiguous.preserve1240 = load <8 x float>, ptr %private.contiguous.address1239, align 4
  %6480 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5977, <8 x float> %private.contiguous.preserve1240
  store <8 x float> %6480, ptr %private.contiguous.address1239, align 4
  %6481 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6482 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6483 = add <8 x i64> %6482, splat (i64 800)
  %6484 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6481, 0
  %6485 = insertvalue { <8 x ptr>, <8 x i64> } %6484, <8 x i64> %6483, 1
  %6486 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6487 = extractvalue { <8 x ptr>, <8 x i64> } %6485, 1
  %6488 = extractelement <8 x ptr> %6486, i32 0
  %6489 = extractelement <8 x i64> %6487, i32 %5540
  %6490 = zext i32 %5540 to i64
  %6491 = mul i64 %6490, 4
  %6492 = sub i64 %6489, %6491
  %6493 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6494 = select i1 %6493, i64 %6492, i64 0
  %private.contiguous.address1241 = getelementptr i8, ptr %6488, i64 %6494
  %private.contiguous.preserve1242 = load <8 x float>, ptr %private.contiguous.address1241, align 4
  %6495 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5980, <8 x float> %private.contiguous.preserve1242
  store <8 x float> %6495, ptr %private.contiguous.address1241, align 4
  %6496 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6497 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6498 = add <8 x i64> %6497, splat (i64 832)
  %6499 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6496, 0
  %6500 = insertvalue { <8 x ptr>, <8 x i64> } %6499, <8 x i64> %6498, 1
  %6501 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6502 = extractvalue { <8 x ptr>, <8 x i64> } %6500, 1
  %6503 = extractelement <8 x ptr> %6501, i32 0
  %6504 = extractelement <8 x i64> %6502, i32 %5540
  %6505 = zext i32 %5540 to i64
  %6506 = mul i64 %6505, 4
  %6507 = sub i64 %6504, %6506
  %6508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6509 = select i1 %6508, i64 %6507, i64 0
  %private.contiguous.address1243 = getelementptr i8, ptr %6503, i64 %6509
  %private.contiguous.preserve1244 = load <8 x float>, ptr %private.contiguous.address1243, align 4
  %6510 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5983, <8 x float> %private.contiguous.preserve1244
  store <8 x float> %6510, ptr %private.contiguous.address1243, align 4
  %6511 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6512 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6513 = add <8 x i64> %6512, splat (i64 864)
  %6514 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6511, 0
  %6515 = insertvalue { <8 x ptr>, <8 x i64> } %6514, <8 x i64> %6513, 1
  %6516 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6517 = extractvalue { <8 x ptr>, <8 x i64> } %6515, 1
  %6518 = extractelement <8 x ptr> %6516, i32 0
  %6519 = extractelement <8 x i64> %6517, i32 %5540
  %6520 = zext i32 %5540 to i64
  %6521 = mul i64 %6520, 4
  %6522 = sub i64 %6519, %6521
  %6523 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6524 = select i1 %6523, i64 %6522, i64 0
  %private.contiguous.address1245 = getelementptr i8, ptr %6518, i64 %6524
  %private.contiguous.preserve1246 = load <8 x float>, ptr %private.contiguous.address1245, align 4
  %6525 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5986, <8 x float> %private.contiguous.preserve1246
  store <8 x float> %6525, ptr %private.contiguous.address1245, align 4
  %6526 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6527 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6528 = add <8 x i64> %6527, splat (i64 896)
  %6529 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6526, 0
  %6530 = insertvalue { <8 x ptr>, <8 x i64> } %6529, <8 x i64> %6528, 1
  %6531 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6532 = extractvalue { <8 x ptr>, <8 x i64> } %6530, 1
  %6533 = extractelement <8 x ptr> %6531, i32 0
  %6534 = extractelement <8 x i64> %6532, i32 %5540
  %6535 = zext i32 %5540 to i64
  %6536 = mul i64 %6535, 4
  %6537 = sub i64 %6534, %6536
  %6538 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6539 = select i1 %6538, i64 %6537, i64 0
  %private.contiguous.address1247 = getelementptr i8, ptr %6533, i64 %6539
  %private.contiguous.preserve1248 = load <8 x float>, ptr %private.contiguous.address1247, align 4
  %6540 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5989, <8 x float> %private.contiguous.preserve1248
  store <8 x float> %6540, ptr %private.contiguous.address1247, align 4
  %6541 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6542 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6543 = add <8 x i64> %6542, splat (i64 928)
  %6544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6541, 0
  %6545 = insertvalue { <8 x ptr>, <8 x i64> } %6544, <8 x i64> %6543, 1
  %6546 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6547 = extractvalue { <8 x ptr>, <8 x i64> } %6545, 1
  %6548 = extractelement <8 x ptr> %6546, i32 0
  %6549 = extractelement <8 x i64> %6547, i32 %5540
  %6550 = zext i32 %5540 to i64
  %6551 = mul i64 %6550, 4
  %6552 = sub i64 %6549, %6551
  %6553 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6554 = select i1 %6553, i64 %6552, i64 0
  %private.contiguous.address1249 = getelementptr i8, ptr %6548, i64 %6554
  %private.contiguous.preserve1250 = load <8 x float>, ptr %private.contiguous.address1249, align 4
  %6555 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5992, <8 x float> %private.contiguous.preserve1250
  store <8 x float> %6555, ptr %private.contiguous.address1249, align 4
  %6556 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6557 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6558 = add <8 x i64> %6557, splat (i64 960)
  %6559 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6556, 0
  %6560 = insertvalue { <8 x ptr>, <8 x i64> } %6559, <8 x i64> %6558, 1
  %6561 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6562 = extractvalue { <8 x ptr>, <8 x i64> } %6560, 1
  %6563 = extractelement <8 x ptr> %6561, i32 0
  %6564 = extractelement <8 x i64> %6562, i32 %5540
  %6565 = zext i32 %5540 to i64
  %6566 = mul i64 %6565, 4
  %6567 = sub i64 %6564, %6566
  %6568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6569 = select i1 %6568, i64 %6567, i64 0
  %private.contiguous.address1251 = getelementptr i8, ptr %6563, i64 %6569
  %private.contiguous.preserve1252 = load <8 x float>, ptr %private.contiguous.address1251, align 4
  %6570 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5995, <8 x float> %private.contiguous.preserve1252
  store <8 x float> %6570, ptr %private.contiguous.address1251, align 4
  %6571 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6572 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6573 = add <8 x i64> %6572, splat (i64 992)
  %6574 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6571, 0
  %6575 = insertvalue { <8 x ptr>, <8 x i64> } %6574, <8 x i64> %6573, 1
  %6576 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6577 = extractvalue { <8 x ptr>, <8 x i64> } %6575, 1
  %6578 = extractelement <8 x ptr> %6576, i32 0
  %6579 = extractelement <8 x i64> %6577, i32 %5540
  %6580 = zext i32 %5540 to i64
  %6581 = mul i64 %6580, 4
  %6582 = sub i64 %6579, %6581
  %6583 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6584 = select i1 %6583, i64 %6582, i64 0
  %private.contiguous.address1253 = getelementptr i8, ptr %6578, i64 %6584
  %private.contiguous.preserve1254 = load <8 x float>, ptr %private.contiguous.address1253, align 4
  %6585 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %5998, <8 x float> %private.contiguous.preserve1254
  store <8 x float> %6585, ptr %private.contiguous.address1253, align 4
  %6586 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6587 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6588 = add <8 x i64> %6587, splat (i64 1024)
  %6589 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6586, 0
  %6590 = insertvalue { <8 x ptr>, <8 x i64> } %6589, <8 x i64> %6588, 1
  %6591 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6592 = extractvalue { <8 x ptr>, <8 x i64> } %6590, 1
  %6593 = extractelement <8 x ptr> %6591, i32 0
  %6594 = extractelement <8 x i64> %6592, i32 %5540
  %6595 = zext i32 %5540 to i64
  %6596 = mul i64 %6595, 4
  %6597 = sub i64 %6594, %6596
  %6598 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6599 = select i1 %6598, i64 %6597, i64 0
  %private.contiguous.address1255 = getelementptr i8, ptr %6593, i64 %6599
  %private.contiguous.preserve1256 = load <8 x float>, ptr %private.contiguous.address1255, align 4
  %6600 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6001, <8 x float> %private.contiguous.preserve1256
  store <8 x float> %6600, ptr %private.contiguous.address1255, align 4
  %6601 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6602 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6603 = add <8 x i64> %6602, splat (i64 1056)
  %6604 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6601, 0
  %6605 = insertvalue { <8 x ptr>, <8 x i64> } %6604, <8 x i64> %6603, 1
  %6606 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6607 = extractvalue { <8 x ptr>, <8 x i64> } %6605, 1
  %6608 = extractelement <8 x ptr> %6606, i32 0
  %6609 = extractelement <8 x i64> %6607, i32 %5540
  %6610 = zext i32 %5540 to i64
  %6611 = mul i64 %6610, 4
  %6612 = sub i64 %6609, %6611
  %6613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6614 = select i1 %6613, i64 %6612, i64 0
  %private.contiguous.address1257 = getelementptr i8, ptr %6608, i64 %6614
  %private.contiguous.preserve1258 = load <8 x float>, ptr %private.contiguous.address1257, align 4
  %6615 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6004, <8 x float> %private.contiguous.preserve1258
  store <8 x float> %6615, ptr %private.contiguous.address1257, align 4
  %6616 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6617 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6618 = add <8 x i64> %6617, splat (i64 1088)
  %6619 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6616, 0
  %6620 = insertvalue { <8 x ptr>, <8 x i64> } %6619, <8 x i64> %6618, 1
  %6621 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6622 = extractvalue { <8 x ptr>, <8 x i64> } %6620, 1
  %6623 = extractelement <8 x ptr> %6621, i32 0
  %6624 = extractelement <8 x i64> %6622, i32 %5540
  %6625 = zext i32 %5540 to i64
  %6626 = mul i64 %6625, 4
  %6627 = sub i64 %6624, %6626
  %6628 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6629 = select i1 %6628, i64 %6627, i64 0
  %private.contiguous.address1259 = getelementptr i8, ptr %6623, i64 %6629
  %private.contiguous.preserve1260 = load <8 x float>, ptr %private.contiguous.address1259, align 4
  %6630 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6007, <8 x float> %private.contiguous.preserve1260
  store <8 x float> %6630, ptr %private.contiguous.address1259, align 4
  %6631 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6632 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6633 = add <8 x i64> %6632, splat (i64 1120)
  %6634 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6631, 0
  %6635 = insertvalue { <8 x ptr>, <8 x i64> } %6634, <8 x i64> %6633, 1
  %6636 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6637 = extractvalue { <8 x ptr>, <8 x i64> } %6635, 1
  %6638 = extractelement <8 x ptr> %6636, i32 0
  %6639 = extractelement <8 x i64> %6637, i32 %5540
  %6640 = zext i32 %5540 to i64
  %6641 = mul i64 %6640, 4
  %6642 = sub i64 %6639, %6641
  %6643 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6644 = select i1 %6643, i64 %6642, i64 0
  %private.contiguous.address1261 = getelementptr i8, ptr %6638, i64 %6644
  %private.contiguous.preserve1262 = load <8 x float>, ptr %private.contiguous.address1261, align 4
  %6645 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6010, <8 x float> %private.contiguous.preserve1262
  store <8 x float> %6645, ptr %private.contiguous.address1261, align 4
  %6646 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6647 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6648 = add <8 x i64> %6647, splat (i64 1152)
  %6649 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6646, 0
  %6650 = insertvalue { <8 x ptr>, <8 x i64> } %6649, <8 x i64> %6648, 1
  %6651 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6652 = extractvalue { <8 x ptr>, <8 x i64> } %6650, 1
  %6653 = extractelement <8 x ptr> %6651, i32 0
  %6654 = extractelement <8 x i64> %6652, i32 %5540
  %6655 = zext i32 %5540 to i64
  %6656 = mul i64 %6655, 4
  %6657 = sub i64 %6654, %6656
  %6658 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6659 = select i1 %6658, i64 %6657, i64 0
  %private.contiguous.address1263 = getelementptr i8, ptr %6653, i64 %6659
  %private.contiguous.preserve1264 = load <8 x float>, ptr %private.contiguous.address1263, align 4
  %6660 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6013, <8 x float> %private.contiguous.preserve1264
  store <8 x float> %6660, ptr %private.contiguous.address1263, align 4
  %6661 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6662 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6663 = add <8 x i64> %6662, splat (i64 1184)
  %6664 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6661, 0
  %6665 = insertvalue { <8 x ptr>, <8 x i64> } %6664, <8 x i64> %6663, 1
  %6666 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6667 = extractvalue { <8 x ptr>, <8 x i64> } %6665, 1
  %6668 = extractelement <8 x ptr> %6666, i32 0
  %6669 = extractelement <8 x i64> %6667, i32 %5540
  %6670 = zext i32 %5540 to i64
  %6671 = mul i64 %6670, 4
  %6672 = sub i64 %6669, %6671
  %6673 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6674 = select i1 %6673, i64 %6672, i64 0
  %private.contiguous.address1265 = getelementptr i8, ptr %6668, i64 %6674
  %private.contiguous.preserve1266 = load <8 x float>, ptr %private.contiguous.address1265, align 4
  %6675 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6016, <8 x float> %private.contiguous.preserve1266
  store <8 x float> %6675, ptr %private.contiguous.address1265, align 4
  %6676 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6677 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6678 = add <8 x i64> %6677, splat (i64 1216)
  %6679 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6676, 0
  %6680 = insertvalue { <8 x ptr>, <8 x i64> } %6679, <8 x i64> %6678, 1
  %6681 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6682 = extractvalue { <8 x ptr>, <8 x i64> } %6680, 1
  %6683 = extractelement <8 x ptr> %6681, i32 0
  %6684 = extractelement <8 x i64> %6682, i32 %5540
  %6685 = zext i32 %5540 to i64
  %6686 = mul i64 %6685, 4
  %6687 = sub i64 %6684, %6686
  %6688 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6689 = select i1 %6688, i64 %6687, i64 0
  %private.contiguous.address1267 = getelementptr i8, ptr %6683, i64 %6689
  %private.contiguous.preserve1268 = load <8 x float>, ptr %private.contiguous.address1267, align 4
  %6690 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6019, <8 x float> %private.contiguous.preserve1268
  store <8 x float> %6690, ptr %private.contiguous.address1267, align 4
  %6691 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6692 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6693 = add <8 x i64> %6692, splat (i64 1248)
  %6694 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6691, 0
  %6695 = insertvalue { <8 x ptr>, <8 x i64> } %6694, <8 x i64> %6693, 1
  %6696 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6697 = extractvalue { <8 x ptr>, <8 x i64> } %6695, 1
  %6698 = extractelement <8 x ptr> %6696, i32 0
  %6699 = extractelement <8 x i64> %6697, i32 %5540
  %6700 = zext i32 %5540 to i64
  %6701 = mul i64 %6700, 4
  %6702 = sub i64 %6699, %6701
  %6703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6704 = select i1 %6703, i64 %6702, i64 0
  %private.contiguous.address1269 = getelementptr i8, ptr %6698, i64 %6704
  %private.contiguous.preserve1270 = load <8 x float>, ptr %private.contiguous.address1269, align 4
  %6705 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6022, <8 x float> %private.contiguous.preserve1270
  store <8 x float> %6705, ptr %private.contiguous.address1269, align 4
  %6706 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6707 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6708 = add <8 x i64> %6707, splat (i64 1280)
  %6709 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6706, 0
  %6710 = insertvalue { <8 x ptr>, <8 x i64> } %6709, <8 x i64> %6708, 1
  %6711 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6712 = extractvalue { <8 x ptr>, <8 x i64> } %6710, 1
  %6713 = extractelement <8 x ptr> %6711, i32 0
  %6714 = extractelement <8 x i64> %6712, i32 %5540
  %6715 = zext i32 %5540 to i64
  %6716 = mul i64 %6715, 4
  %6717 = sub i64 %6714, %6716
  %6718 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6719 = select i1 %6718, i64 %6717, i64 0
  %private.contiguous.address1271 = getelementptr i8, ptr %6713, i64 %6719
  %private.contiguous.preserve1272 = load <8 x float>, ptr %private.contiguous.address1271, align 4
  %6720 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6025, <8 x float> %private.contiguous.preserve1272
  store <8 x float> %6720, ptr %private.contiguous.address1271, align 4
  %6721 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6722 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6723 = add <8 x i64> %6722, splat (i64 1312)
  %6724 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6721, 0
  %6725 = insertvalue { <8 x ptr>, <8 x i64> } %6724, <8 x i64> %6723, 1
  %6726 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6727 = extractvalue { <8 x ptr>, <8 x i64> } %6725, 1
  %6728 = extractelement <8 x ptr> %6726, i32 0
  %6729 = extractelement <8 x i64> %6727, i32 %5540
  %6730 = zext i32 %5540 to i64
  %6731 = mul i64 %6730, 4
  %6732 = sub i64 %6729, %6731
  %6733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6734 = select i1 %6733, i64 %6732, i64 0
  %private.contiguous.address1273 = getelementptr i8, ptr %6728, i64 %6734
  %private.contiguous.preserve1274 = load <8 x float>, ptr %private.contiguous.address1273, align 4
  %6735 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6028, <8 x float> %private.contiguous.preserve1274
  store <8 x float> %6735, ptr %private.contiguous.address1273, align 4
  %6736 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6737 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6738 = add <8 x i64> %6737, splat (i64 1344)
  %6739 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6736, 0
  %6740 = insertvalue { <8 x ptr>, <8 x i64> } %6739, <8 x i64> %6738, 1
  %6741 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6742 = extractvalue { <8 x ptr>, <8 x i64> } %6740, 1
  %6743 = extractelement <8 x ptr> %6741, i32 0
  %6744 = extractelement <8 x i64> %6742, i32 %5540
  %6745 = zext i32 %5540 to i64
  %6746 = mul i64 %6745, 4
  %6747 = sub i64 %6744, %6746
  %6748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6749 = select i1 %6748, i64 %6747, i64 0
  %private.contiguous.address1275 = getelementptr i8, ptr %6743, i64 %6749
  %private.contiguous.preserve1276 = load <8 x float>, ptr %private.contiguous.address1275, align 4
  %6750 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6031, <8 x float> %private.contiguous.preserve1276
  store <8 x float> %6750, ptr %private.contiguous.address1275, align 4
  %6751 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6752 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6753 = add <8 x i64> %6752, splat (i64 1376)
  %6754 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6751, 0
  %6755 = insertvalue { <8 x ptr>, <8 x i64> } %6754, <8 x i64> %6753, 1
  %6756 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6757 = extractvalue { <8 x ptr>, <8 x i64> } %6755, 1
  %6758 = extractelement <8 x ptr> %6756, i32 0
  %6759 = extractelement <8 x i64> %6757, i32 %5540
  %6760 = zext i32 %5540 to i64
  %6761 = mul i64 %6760, 4
  %6762 = sub i64 %6759, %6761
  %6763 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6764 = select i1 %6763, i64 %6762, i64 0
  %private.contiguous.address1277 = getelementptr i8, ptr %6758, i64 %6764
  %private.contiguous.preserve1278 = load <8 x float>, ptr %private.contiguous.address1277, align 4
  %6765 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6034, <8 x float> %private.contiguous.preserve1278
  store <8 x float> %6765, ptr %private.contiguous.address1277, align 4
  %6766 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6767 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6768 = add <8 x i64> %6767, splat (i64 1408)
  %6769 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6766, 0
  %6770 = insertvalue { <8 x ptr>, <8 x i64> } %6769, <8 x i64> %6768, 1
  %6771 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6772 = extractvalue { <8 x ptr>, <8 x i64> } %6770, 1
  %6773 = extractelement <8 x ptr> %6771, i32 0
  %6774 = extractelement <8 x i64> %6772, i32 %5540
  %6775 = zext i32 %5540 to i64
  %6776 = mul i64 %6775, 4
  %6777 = sub i64 %6774, %6776
  %6778 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6779 = select i1 %6778, i64 %6777, i64 0
  %private.contiguous.address1279 = getelementptr i8, ptr %6773, i64 %6779
  %private.contiguous.preserve1280 = load <8 x float>, ptr %private.contiguous.address1279, align 4
  %6780 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6037, <8 x float> %private.contiguous.preserve1280
  store <8 x float> %6780, ptr %private.contiguous.address1279, align 4
  %6781 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6782 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6783 = add <8 x i64> %6782, splat (i64 1440)
  %6784 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6781, 0
  %6785 = insertvalue { <8 x ptr>, <8 x i64> } %6784, <8 x i64> %6783, 1
  %6786 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6787 = extractvalue { <8 x ptr>, <8 x i64> } %6785, 1
  %6788 = extractelement <8 x ptr> %6786, i32 0
  %6789 = extractelement <8 x i64> %6787, i32 %5540
  %6790 = zext i32 %5540 to i64
  %6791 = mul i64 %6790, 4
  %6792 = sub i64 %6789, %6791
  %6793 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6794 = select i1 %6793, i64 %6792, i64 0
  %private.contiguous.address1281 = getelementptr i8, ptr %6788, i64 %6794
  %private.contiguous.preserve1282 = load <8 x float>, ptr %private.contiguous.address1281, align 4
  %6795 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6040, <8 x float> %private.contiguous.preserve1282
  store <8 x float> %6795, ptr %private.contiguous.address1281, align 4
  %6796 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6797 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6798 = add <8 x i64> %6797, splat (i64 1472)
  %6799 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6796, 0
  %6800 = insertvalue { <8 x ptr>, <8 x i64> } %6799, <8 x i64> %6798, 1
  %6801 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6802 = extractvalue { <8 x ptr>, <8 x i64> } %6800, 1
  %6803 = extractelement <8 x ptr> %6801, i32 0
  %6804 = extractelement <8 x i64> %6802, i32 %5540
  %6805 = zext i32 %5540 to i64
  %6806 = mul i64 %6805, 4
  %6807 = sub i64 %6804, %6806
  %6808 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6809 = select i1 %6808, i64 %6807, i64 0
  %private.contiguous.address1283 = getelementptr i8, ptr %6803, i64 %6809
  %private.contiguous.preserve1284 = load <8 x float>, ptr %private.contiguous.address1283, align 4
  %6810 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6043, <8 x float> %private.contiguous.preserve1284
  store <8 x float> %6810, ptr %private.contiguous.address1283, align 4
  %6811 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6812 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6813 = add <8 x i64> %6812, splat (i64 1504)
  %6814 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6811, 0
  %6815 = insertvalue { <8 x ptr>, <8 x i64> } %6814, <8 x i64> %6813, 1
  %6816 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6817 = extractvalue { <8 x ptr>, <8 x i64> } %6815, 1
  %6818 = extractelement <8 x ptr> %6816, i32 0
  %6819 = extractelement <8 x i64> %6817, i32 %5540
  %6820 = zext i32 %5540 to i64
  %6821 = mul i64 %6820, 4
  %6822 = sub i64 %6819, %6821
  %6823 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6824 = select i1 %6823, i64 %6822, i64 0
  %private.contiguous.address1285 = getelementptr i8, ptr %6818, i64 %6824
  %private.contiguous.preserve1286 = load <8 x float>, ptr %private.contiguous.address1285, align 4
  %6825 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6046, <8 x float> %private.contiguous.preserve1286
  store <8 x float> %6825, ptr %private.contiguous.address1285, align 4
  %6826 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6827 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6828 = add <8 x i64> %6827, splat (i64 1536)
  %6829 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6826, 0
  %6830 = insertvalue { <8 x ptr>, <8 x i64> } %6829, <8 x i64> %6828, 1
  %6831 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6832 = extractvalue { <8 x ptr>, <8 x i64> } %6830, 1
  %6833 = extractelement <8 x ptr> %6831, i32 0
  %6834 = extractelement <8 x i64> %6832, i32 %5540
  %6835 = zext i32 %5540 to i64
  %6836 = mul i64 %6835, 4
  %6837 = sub i64 %6834, %6836
  %6838 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6839 = select i1 %6838, i64 %6837, i64 0
  %private.contiguous.address1287 = getelementptr i8, ptr %6833, i64 %6839
  %private.contiguous.preserve1288 = load <8 x float>, ptr %private.contiguous.address1287, align 4
  %6840 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6049, <8 x float> %private.contiguous.preserve1288
  store <8 x float> %6840, ptr %private.contiguous.address1287, align 4
  %6841 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6842 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6843 = add <8 x i64> %6842, splat (i64 1568)
  %6844 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6841, 0
  %6845 = insertvalue { <8 x ptr>, <8 x i64> } %6844, <8 x i64> %6843, 1
  %6846 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6847 = extractvalue { <8 x ptr>, <8 x i64> } %6845, 1
  %6848 = extractelement <8 x ptr> %6846, i32 0
  %6849 = extractelement <8 x i64> %6847, i32 %5540
  %6850 = zext i32 %5540 to i64
  %6851 = mul i64 %6850, 4
  %6852 = sub i64 %6849, %6851
  %6853 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6854 = select i1 %6853, i64 %6852, i64 0
  %private.contiguous.address1289 = getelementptr i8, ptr %6848, i64 %6854
  %private.contiguous.preserve1290 = load <8 x float>, ptr %private.contiguous.address1289, align 4
  %6855 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6052, <8 x float> %private.contiguous.preserve1290
  store <8 x float> %6855, ptr %private.contiguous.address1289, align 4
  %6856 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6857 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6858 = add <8 x i64> %6857, splat (i64 1600)
  %6859 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6856, 0
  %6860 = insertvalue { <8 x ptr>, <8 x i64> } %6859, <8 x i64> %6858, 1
  %6861 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6862 = extractvalue { <8 x ptr>, <8 x i64> } %6860, 1
  %6863 = extractelement <8 x ptr> %6861, i32 0
  %6864 = extractelement <8 x i64> %6862, i32 %5540
  %6865 = zext i32 %5540 to i64
  %6866 = mul i64 %6865, 4
  %6867 = sub i64 %6864, %6866
  %6868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6869 = select i1 %6868, i64 %6867, i64 0
  %private.contiguous.address1291 = getelementptr i8, ptr %6863, i64 %6869
  %private.contiguous.preserve1292 = load <8 x float>, ptr %private.contiguous.address1291, align 4
  %6870 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6055, <8 x float> %private.contiguous.preserve1292
  store <8 x float> %6870, ptr %private.contiguous.address1291, align 4
  %6871 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6872 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6873 = add <8 x i64> %6872, splat (i64 1632)
  %6874 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6871, 0
  %6875 = insertvalue { <8 x ptr>, <8 x i64> } %6874, <8 x i64> %6873, 1
  %6876 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6877 = extractvalue { <8 x ptr>, <8 x i64> } %6875, 1
  %6878 = extractelement <8 x ptr> %6876, i32 0
  %6879 = extractelement <8 x i64> %6877, i32 %5540
  %6880 = zext i32 %5540 to i64
  %6881 = mul i64 %6880, 4
  %6882 = sub i64 %6879, %6881
  %6883 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6884 = select i1 %6883, i64 %6882, i64 0
  %private.contiguous.address1293 = getelementptr i8, ptr %6878, i64 %6884
  %private.contiguous.preserve1294 = load <8 x float>, ptr %private.contiguous.address1293, align 4
  %6885 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6058, <8 x float> %private.contiguous.preserve1294
  store <8 x float> %6885, ptr %private.contiguous.address1293, align 4
  %6886 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6887 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6888 = add <8 x i64> %6887, splat (i64 1664)
  %6889 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6886, 0
  %6890 = insertvalue { <8 x ptr>, <8 x i64> } %6889, <8 x i64> %6888, 1
  %6891 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6892 = extractvalue { <8 x ptr>, <8 x i64> } %6890, 1
  %6893 = extractelement <8 x ptr> %6891, i32 0
  %6894 = extractelement <8 x i64> %6892, i32 %5540
  %6895 = zext i32 %5540 to i64
  %6896 = mul i64 %6895, 4
  %6897 = sub i64 %6894, %6896
  %6898 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6899 = select i1 %6898, i64 %6897, i64 0
  %private.contiguous.address1295 = getelementptr i8, ptr %6893, i64 %6899
  %private.contiguous.preserve1296 = load <8 x float>, ptr %private.contiguous.address1295, align 4
  %6900 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6061, <8 x float> %private.contiguous.preserve1296
  store <8 x float> %6900, ptr %private.contiguous.address1295, align 4
  %6901 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6902 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6903 = add <8 x i64> %6902, splat (i64 1696)
  %6904 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6901, 0
  %6905 = insertvalue { <8 x ptr>, <8 x i64> } %6904, <8 x i64> %6903, 1
  %6906 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6907 = extractvalue { <8 x ptr>, <8 x i64> } %6905, 1
  %6908 = extractelement <8 x ptr> %6906, i32 0
  %6909 = extractelement <8 x i64> %6907, i32 %5540
  %6910 = zext i32 %5540 to i64
  %6911 = mul i64 %6910, 4
  %6912 = sub i64 %6909, %6911
  %6913 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6914 = select i1 %6913, i64 %6912, i64 0
  %private.contiguous.address1297 = getelementptr i8, ptr %6908, i64 %6914
  %private.contiguous.preserve1298 = load <8 x float>, ptr %private.contiguous.address1297, align 4
  %6915 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6064, <8 x float> %private.contiguous.preserve1298
  store <8 x float> %6915, ptr %private.contiguous.address1297, align 4
  %6916 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6917 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6918 = add <8 x i64> %6917, splat (i64 1728)
  %6919 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6916, 0
  %6920 = insertvalue { <8 x ptr>, <8 x i64> } %6919, <8 x i64> %6918, 1
  %6921 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6922 = extractvalue { <8 x ptr>, <8 x i64> } %6920, 1
  %6923 = extractelement <8 x ptr> %6921, i32 0
  %6924 = extractelement <8 x i64> %6922, i32 %5540
  %6925 = zext i32 %5540 to i64
  %6926 = mul i64 %6925, 4
  %6927 = sub i64 %6924, %6926
  %6928 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6929 = select i1 %6928, i64 %6927, i64 0
  %private.contiguous.address1299 = getelementptr i8, ptr %6923, i64 %6929
  %private.contiguous.preserve1300 = load <8 x float>, ptr %private.contiguous.address1299, align 4
  %6930 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6067, <8 x float> %private.contiguous.preserve1300
  store <8 x float> %6930, ptr %private.contiguous.address1299, align 4
  %6931 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6932 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6933 = add <8 x i64> %6932, splat (i64 1760)
  %6934 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6931, 0
  %6935 = insertvalue { <8 x ptr>, <8 x i64> } %6934, <8 x i64> %6933, 1
  %6936 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6937 = extractvalue { <8 x ptr>, <8 x i64> } %6935, 1
  %6938 = extractelement <8 x ptr> %6936, i32 0
  %6939 = extractelement <8 x i64> %6937, i32 %5540
  %6940 = zext i32 %5540 to i64
  %6941 = mul i64 %6940, 4
  %6942 = sub i64 %6939, %6941
  %6943 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6944 = select i1 %6943, i64 %6942, i64 0
  %private.contiguous.address1301 = getelementptr i8, ptr %6938, i64 %6944
  %private.contiguous.preserve1302 = load <8 x float>, ptr %private.contiguous.address1301, align 4
  %6945 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6070, <8 x float> %private.contiguous.preserve1302
  store <8 x float> %6945, ptr %private.contiguous.address1301, align 4
  %6946 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6947 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6948 = add <8 x i64> %6947, splat (i64 1792)
  %6949 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6946, 0
  %6950 = insertvalue { <8 x ptr>, <8 x i64> } %6949, <8 x i64> %6948, 1
  %6951 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6952 = extractvalue { <8 x ptr>, <8 x i64> } %6950, 1
  %6953 = extractelement <8 x ptr> %6951, i32 0
  %6954 = extractelement <8 x i64> %6952, i32 %5540
  %6955 = zext i32 %5540 to i64
  %6956 = mul i64 %6955, 4
  %6957 = sub i64 %6954, %6956
  %6958 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6959 = select i1 %6958, i64 %6957, i64 0
  %private.contiguous.address1303 = getelementptr i8, ptr %6953, i64 %6959
  %private.contiguous.preserve1304 = load <8 x float>, ptr %private.contiguous.address1303, align 4
  %6960 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6073, <8 x float> %private.contiguous.preserve1304
  store <8 x float> %6960, ptr %private.contiguous.address1303, align 4
  %6961 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6962 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6963 = add <8 x i64> %6962, splat (i64 1824)
  %6964 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6961, 0
  %6965 = insertvalue { <8 x ptr>, <8 x i64> } %6964, <8 x i64> %6963, 1
  %6966 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6967 = extractvalue { <8 x ptr>, <8 x i64> } %6965, 1
  %6968 = extractelement <8 x ptr> %6966, i32 0
  %6969 = extractelement <8 x i64> %6967, i32 %5540
  %6970 = zext i32 %5540 to i64
  %6971 = mul i64 %6970, 4
  %6972 = sub i64 %6969, %6971
  %6973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6974 = select i1 %6973, i64 %6972, i64 0
  %private.contiguous.address1305 = getelementptr i8, ptr %6968, i64 %6974
  %private.contiguous.preserve1306 = load <8 x float>, ptr %private.contiguous.address1305, align 4
  %6975 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6076, <8 x float> %private.contiguous.preserve1306
  store <8 x float> %6975, ptr %private.contiguous.address1305, align 4
  %6976 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6977 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6978 = add <8 x i64> %6977, splat (i64 1856)
  %6979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6976, 0
  %6980 = insertvalue { <8 x ptr>, <8 x i64> } %6979, <8 x i64> %6978, 1
  %6981 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6982 = extractvalue { <8 x ptr>, <8 x i64> } %6980, 1
  %6983 = extractelement <8 x ptr> %6981, i32 0
  %6984 = extractelement <8 x i64> %6982, i32 %5540
  %6985 = zext i32 %5540 to i64
  %6986 = mul i64 %6985, 4
  %6987 = sub i64 %6984, %6986
  %6988 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %6989 = select i1 %6988, i64 %6987, i64 0
  %private.contiguous.address1307 = getelementptr i8, ptr %6983, i64 %6989
  %private.contiguous.preserve1308 = load <8 x float>, ptr %private.contiguous.address1307, align 4
  %6990 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6079, <8 x float> %private.contiguous.preserve1308
  store <8 x float> %6990, ptr %private.contiguous.address1307, align 4
  %6991 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6992 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %6993 = add <8 x i64> %6992, splat (i64 1888)
  %6994 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6991, 0
  %6995 = insertvalue { <8 x ptr>, <8 x i64> } %6994, <8 x i64> %6993, 1
  %6996 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %6997 = extractvalue { <8 x ptr>, <8 x i64> } %6995, 1
  %6998 = extractelement <8 x ptr> %6996, i32 0
  %6999 = extractelement <8 x i64> %6997, i32 %5540
  %7000 = zext i32 %5540 to i64
  %7001 = mul i64 %7000, 4
  %7002 = sub i64 %6999, %7001
  %7003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %7004 = select i1 %7003, i64 %7002, i64 0
  %private.contiguous.address1309 = getelementptr i8, ptr %6998, i64 %7004
  %private.contiguous.preserve1310 = load <8 x float>, ptr %private.contiguous.address1309, align 4
  %7005 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6082, <8 x float> %private.contiguous.preserve1310
  store <8 x float> %7005, ptr %private.contiguous.address1309, align 4
  %7006 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7007 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7008 = add <8 x i64> %7007, splat (i64 1920)
  %7009 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7006, 0
  %7010 = insertvalue { <8 x ptr>, <8 x i64> } %7009, <8 x i64> %7008, 1
  %7011 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7012 = extractvalue { <8 x ptr>, <8 x i64> } %7010, 1
  %7013 = extractelement <8 x ptr> %7011, i32 0
  %7014 = extractelement <8 x i64> %7012, i32 %5540
  %7015 = zext i32 %5540 to i64
  %7016 = mul i64 %7015, 4
  %7017 = sub i64 %7014, %7016
  %7018 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %7019 = select i1 %7018, i64 %7017, i64 0
  %private.contiguous.address1311 = getelementptr i8, ptr %7013, i64 %7019
  %private.contiguous.preserve1312 = load <8 x float>, ptr %private.contiguous.address1311, align 4
  %7020 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6085, <8 x float> %private.contiguous.preserve1312
  store <8 x float> %7020, ptr %private.contiguous.address1311, align 4
  %7021 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7022 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7023 = add <8 x i64> %7022, splat (i64 1952)
  %7024 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7021, 0
  %7025 = insertvalue { <8 x ptr>, <8 x i64> } %7024, <8 x i64> %7023, 1
  %7026 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7027 = extractvalue { <8 x ptr>, <8 x i64> } %7025, 1
  %7028 = extractelement <8 x ptr> %7026, i32 0
  %7029 = extractelement <8 x i64> %7027, i32 %5540
  %7030 = zext i32 %5540 to i64
  %7031 = mul i64 %7030, 4
  %7032 = sub i64 %7029, %7031
  %7033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %7034 = select i1 %7033, i64 %7032, i64 0
  %private.contiguous.address1313 = getelementptr i8, ptr %7028, i64 %7034
  %private.contiguous.preserve1314 = load <8 x float>, ptr %private.contiguous.address1313, align 4
  %7035 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6088, <8 x float> %private.contiguous.preserve1314
  store <8 x float> %7035, ptr %private.contiguous.address1313, align 4
  %7036 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7037 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7038 = add <8 x i64> %7037, splat (i64 1984)
  %7039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7036, 0
  %7040 = insertvalue { <8 x ptr>, <8 x i64> } %7039, <8 x i64> %7038, 1
  %7041 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7042 = extractvalue { <8 x ptr>, <8 x i64> } %7040, 1
  %7043 = extractelement <8 x ptr> %7041, i32 0
  %7044 = extractelement <8 x i64> %7042, i32 %5540
  %7045 = zext i32 %5540 to i64
  %7046 = mul i64 %7045, 4
  %7047 = sub i64 %7044, %7046
  %7048 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %7049 = select i1 %7048, i64 %7047, i64 0
  %private.contiguous.address1315 = getelementptr i8, ptr %7043, i64 %7049
  %private.contiguous.preserve1316 = load <8 x float>, ptr %private.contiguous.address1315, align 4
  %7050 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6091, <8 x float> %private.contiguous.preserve1316
  store <8 x float> %7050, ptr %private.contiguous.address1315, align 4
  %7051 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7052 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %7053 = add <8 x i64> %7052, splat (i64 2016)
  %7054 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7051, 0
  %7055 = insertvalue { <8 x ptr>, <8 x i64> } %7054, <8 x i64> %7053, 1
  %7056 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %7057 = extractvalue { <8 x ptr>, <8 x i64> } %7055, 1
  %7058 = extractelement <8 x ptr> %7056, i32 0
  %7059 = extractelement <8 x i64> %7057, i32 %5540
  %7060 = zext i32 %5540 to i64
  %7061 = mul i64 %7060, 4
  %7062 = sub i64 %7059, %7061
  %7063 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  %7064 = select i1 %7063, i64 %7062, i64 0
  %private.contiguous.address1317 = getelementptr i8, ptr %7058, i64 %7064
  %private.contiguous.preserve1318 = load <8 x float>, ptr %private.contiguous.address1317, align 4
  %7065 = select <8 x i1> %convergence.cascade.result1108, <8 x float> %6094, <8 x float> %private.contiguous.preserve1318
  store <8 x float> %7065, ptr %private.contiguous.address1317, align 4
  %7066 = load <8 x i64>, ptr %.slot55, align 64
  %7067 = select <8 x i1> %convergence.cascade.result1108, <8 x i64> zeroinitializer, <8 x i64> %7066
  store <8 x i64> %7067, ptr %.slot55, align 64
  %7068 = load <8 x float>, ptr %.slot56, align 32
  %7069 = select <8 x i1> %convergence.cascade.result1108, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7068
  store <8 x float> %7069, ptr %.slot56, align 32
  store <8 x i1> %convergence.cascade.result1108, ptr %current.mask, align 1
  %7070 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1108)
  br i1 %7070, label %schedule.60, label %scheduler.loop

varying.divergent1320:                            ; preds = %schedule.60
  %7071 = load i32, ptr %current.token, align 4
  %7072 = icmp ne i32 %7071, 0
  %7073 = sub i32 %7071, 1
  %7074 = select i1 %7072, i32 %7073, i32 0
  %7075 = load i8, ptr %frame.active, align 1
  %7076 = trunc i32 %7074 to i8
  %7077 = shl i8 1, %7076
  %7078 = and i8 %7075, %7077
  %7079 = icmp ne i8 %7078, 0
  %7080 = load <8 x i32>, ptr %frame.static.id, align 32
  %7081 = extractelement <8 x i32> %7080, i32 %7074
  %7082 = icmp eq i32 %7081, 21
  %7083 = and i1 %7079, %7082
  %7084 = and i1 %7072, %7083
  %7085 = xor i1 %7084, true
  %7086 = and i1 true, %7085
  %7087 = xor i8 %7075, -1
  %7088 = icmp ne i8 %7087, 0
  %7089 = xor i1 %7088, true
  %7090 = and i1 %7086, %7089
  br i1 %7090, label %convergence.overflow.trap1322, label %convergence.overflow.resume1323

varying.coherent1321:                             ; preds = %schedule.60
  br i1 %1642, label %varying.coherent.true1326, label %varying.coherent.false1327

convergence.overflow.trap1322:                    ; preds = %varying.divergent1320
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1323:                  ; preds = %varying.divergent1320
  %7091 = call i8 @llvm.cttz.i8(i8 %7087, i1 false)
  %7092 = zext i8 %7091 to i32
  %7093 = select i1 %7088, i32 %7092, i32 0
  %7094 = trunc i32 %7093 to i8
  %7095 = shl i8 1, %7094
  %7096 = or i8 %7075, %7095
  %7097 = select i1 %7086, i8 %7096, i8 %7075
  store i8 %7097, ptr %frame.active, align 1
  %7098 = load <8 x i32>, ptr %frame.static.id, align 32
  %7099 = extractelement <8 x i32> %7098, i32 %7093
  %7100 = select i1 %7086, i32 21, i32 %7099
  %7101 = load <8 x i32>, ptr %frame.static.id, align 32
  %7102 = insertelement <8 x i32> %7101, i32 %7100, i32 %7093
  store <8 x i32> %7102, ptr %frame.static.id, align 32
  %7103 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7104 = extractelement <8 x i32> %7103, i32 %7093
  %7105 = select i1 %7086, i32 %7071, i32 %7104
  %7106 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7107 = insertelement <8 x i32> %7106, i32 %7105, i32 %7093
  store <8 x i32> %7107, ptr %frame.parent.token, align 32
  %7108 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7093
  %7109 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7093
  %7110 = load <8 x i1>, ptr %7108, align 1
  %7111 = load <8 x i1>, ptr %7109, align 1
  %7112 = select i1 %7086, <8 x i1> %1632, <8 x i1> %7110
  store <8 x i1> %7112, ptr %7108, align 1
  %7113 = select i1 %7086, <8 x i1> zeroinitializer, <8 x i1> %7111
  store <8 x i1> %7113, ptr %7109, align 1
  %7114 = add i32 %7093, 1
  %7115 = select i1 %7084, i32 %7071, i32 %7114
  %7116 = select i1 true, i32 %7115, i32 %7071
  store i32 %7116, ptr %current.token, align 4
  %7117 = load i32, ptr %current.token, align 4
  %7118 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1639)
  %7119 = load i32, ptr %ready.count, align 4
  %7120 = icmp uge i32 %7119, 8
  %7121 = and i1 %7118, %7120
  br i1 %7121, label %ready.overflow.trap1324, label %ready.overflow.resume1325

ready.overflow.trap1324:                          ; preds = %convergence.overflow.resume1323
  call void @llvm.trap()
  unreachable

ready.overflow.resume1325:                        ; preds = %convergence.overflow.resume1323
  %7122 = select i1 %7118, i32 %7119, i32 0
  %7123 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7122
  %7124 = load <8 x i1>, ptr %7123, align 1
  %7125 = select i1 %7118, <8 x i1> %1639, <8 x i1> %7124
  store <8 x i1> %7125, ptr %7123, align 1
  %7126 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7122
  %7127 = load i32, ptr %7126, align 4
  %7128 = select i1 %7118, i32 61, i32 %7127
  store i32 %7128, ptr %7126, align 4
  %7129 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7122
  %7130 = load i32, ptr %7129, align 4
  %7131 = select i1 %7118, i32 %7117, i32 %7130
  store i32 %7131, ptr %7129, align 4
  %7132 = add i32 %7119, 1
  %7133 = select i1 %7118, i32 %7132, i32 %7119
  store i32 %7133, ptr %ready.count, align 4
  %7134 = load <8 x i1>, ptr %runnable.mask, align 1
  %7135 = or <8 x i1> %7134, %1639
  store <8 x i1> %7135, ptr %runnable.mask, align 1
  store <8 x i1> %1641, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1326:                        ; preds = %varying.coherent1321
  store <8 x i1> %1632, ptr %current.mask, align 1
  %7136 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1632)
  br i1 %7136, label %schedule.61, label %scheduler.loop

varying.coherent.false1327:                       ; preds = %varying.coherent1321
  store <8 x i1> %1632, ptr %current.mask, align 1
  %7137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1632)
  br i1 %7137, label %schedule.62, label %scheduler.loop

convergence.cascade1332:                          ; preds = %convergence.cascade1332, %schedule.62
  %convergence.cascade.flow1336 = phi <8 x i1> [ %1672, %schedule.62 ], [ %7180, %convergence.cascade1332 ]
  %convergence.cascade.depth1337 = phi i32 [ 0, %schedule.62 ], [ %7181, %convergence.cascade1332 ]
  %7138 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1336)
  %7139 = load i32, ptr %current.token, align 4
  %7140 = icmp ne i32 %7139, 0
  %7141 = and i1 %7138, %7140
  %7142 = sub i32 %7139, 1
  %7143 = select i1 %7141, i32 %7142, i32 0
  %7144 = load i8, ptr %frame.active, align 1
  %7145 = trunc i32 %7143 to i8
  %7146 = shl i8 1, %7145
  %7147 = and i8 %7144, %7146
  %7148 = icmp ne i8 %7147, 0
  %7149 = load <8 x i32>, ptr %frame.static.id, align 32
  %7150 = extractelement <8 x i32> %7149, i32 %7143
  %convergence.target.pointer1338 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %7150
  %convergence.dynamic.target1339 = load i32, ptr %convergence.target.pointer1338, align 4
  %7151 = icmp eq i32 %convergence.dynamic.target1339, 62
  %7152 = and i1 %7148, %7151
  %7153 = and i1 %7141, %7152
  %7154 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7143
  %7155 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7143
  %7156 = load <8 x i1>, ptr %7154, align 1
  %7157 = load <8 x i1>, ptr %7155, align 1
  %7158 = or <8 x i1> %7157, %convergence.cascade.flow1336
  %7159 = load <8 x i1>, ptr %live.mask, align 1
  %7160 = and <8 x i1> %7156, %7159
  %7161 = icmp eq <8 x i1> %7158, %7160
  %7162 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7161)
  %7163 = and i1 %7153, %7162
  %7164 = select i1 %7163, <8 x i1> zeroinitializer, <8 x i1> %7158
  %7165 = select i1 %7153, <8 x i1> %7164, <8 x i1> %7157
  store <8 x i1> %7165, ptr %7155, align 1
  %7166 = select i1 %7163, <8 x i1> zeroinitializer, <8 x i1> %7156
  store <8 x i1> %7166, ptr %7154, align 1
  %7167 = trunc i32 %7143 to i8
  %7168 = shl i8 1, %7167
  %7169 = xor i8 %7168, -1
  %7170 = and i8 %7144, %7169
  %7171 = select i1 %7163, i8 %7170, i8 %7144
  store i8 %7171, ptr %frame.active, align 1
  %.splatinsert1340 = insertelement <8 x i1> poison, i1 %7153, i64 0
  %.splat1341 = shufflevector <8 x i1> %.splatinsert1340, <8 x i1> poison, <8 x i32> zeroinitializer
  %7172 = and <8 x i1> %convergence.cascade.flow1336, %.splat1341
  %7173 = load <8 x i1>, ptr %runnable.mask, align 1
  %7174 = xor <8 x i1> %7172, splat (i1 true)
  %7175 = and <8 x i1> %7173, %7174
  store <8 x i1> %7175, ptr %runnable.mask, align 1
  %.splatinsert1342 = insertelement <8 x i1> poison, i1 %7163, i64 0
  %.splat1343 = shufflevector <8 x i1> %.splatinsert1342, <8 x i1> poison, <8 x i32> zeroinitializer
  %7176 = select <8 x i1> %.splat1343, <8 x i1> %7158, <8 x i1> zeroinitializer
  %7177 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7178 = extractelement <8 x i32> %7177, i32 %7143
  %7179 = select i1 %7163, i32 %7178, i32 %7139
  store i32 %7179, ptr %current.token, align 4
  %.splatinsert1344 = insertelement <8 x i1> poison, i1 %7153, i64 0
  %.splat1345 = shufflevector <8 x i1> %.splatinsert1344, <8 x i1> poison, <8 x i32> zeroinitializer
  %7180 = select <8 x i1> %.splat1345, <8 x i1> %7176, <8 x i1> %convergence.cascade.flow1336
  %7181 = add i32 %convergence.cascade.depth1337, 1
  %7182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7180)
  %7183 = icmp ult i32 %7181, 8
  %7184 = and i1 %7182, %7183
  %7185 = and i1 %7153, %7184
  %convergence.parent.token1346 = load i32, ptr %current.token, align 4
  %convergence.parent.present1347 = icmp ne i32 %convergence.parent.token1346, 0
  %7186 = and i1 %7185, %convergence.parent.present1347
  br i1 %7186, label %convergence.cascade1332, label %convergence.cascade.exit1333

convergence.cascade.exit1333:                     ; preds = %convergence.cascade1332, %schedule.62
  %convergence.cascade.result1348 = phi <8 x i1> [ %1672, %schedule.62 ], [ %7180, %convergence.cascade1332 ]
  %7187 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1348)
  br i1 %7187, label %convergence.target.62.ready, label %scheduler.loop

convergence.target.62.ready:                      ; preds = %convergence.cascade.exit1333
  %7188 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1348)
  %7189 = bitcast <8 x i1> %convergence.cascade.result1348 to i8
  %7190 = call i8 @llvm.cttz.i8(i8 %7189, i1 false)
  %7191 = zext i8 %7190 to i32
  %7192 = select i1 %7188, i32 %7191, i32 0
  %7193 = load <8 x i64>, ptr %.slot55, align 64
  %7194 = select <8 x i1> %convergence.cascade.result1348, <8 x i64> zeroinitializer, <8 x i64> %7193
  store <8 x i64> %7194, ptr %.slot55, align 64
  %7195 = load <8 x float>, ptr %.slot57, align 32
  %7196 = select <8 x i1> %convergence.cascade.result1348, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7195
  store <8 x float> %7196, ptr %.slot57, align 32
  store <8 x i1> %convergence.cascade.result1348, ptr %current.mask, align 1
  %7197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1348)
  br i1 %7197, label %schedule.63, label %scheduler.loop

varying.divergent1350:                            ; preds = %schedule.63
  %7198 = load i32, ptr %current.token, align 4
  %7199 = icmp ne i32 %7198, 0
  %7200 = sub i32 %7198, 1
  %7201 = select i1 %7199, i32 %7200, i32 0
  %7202 = load i8, ptr %frame.active, align 1
  %7203 = trunc i32 %7201 to i8
  %7204 = shl i8 1, %7203
  %7205 = and i8 %7202, %7204
  %7206 = icmp ne i8 %7205, 0
  %7207 = load <8 x i32>, ptr %frame.static.id, align 32
  %7208 = extractelement <8 x i32> %7207, i32 %7201
  %7209 = icmp eq i32 %7208, 22
  %7210 = and i1 %7206, %7209
  %7211 = and i1 %7199, %7210
  %7212 = xor i1 %7211, true
  %7213 = and i1 true, %7212
  %7214 = xor i8 %7202, -1
  %7215 = icmp ne i8 %7214, 0
  %7216 = xor i1 %7215, true
  %7217 = and i1 %7213, %7216
  br i1 %7217, label %convergence.overflow.trap1352, label %convergence.overflow.resume1353

varying.coherent1351:                             ; preds = %schedule.63
  br i1 %1683, label %varying.coherent.true1356, label %varying.coherent.false1357

convergence.overflow.trap1352:                    ; preds = %varying.divergent1350
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1353:                  ; preds = %varying.divergent1350
  %7218 = call i8 @llvm.cttz.i8(i8 %7214, i1 false)
  %7219 = zext i8 %7218 to i32
  %7220 = select i1 %7215, i32 %7219, i32 0
  %7221 = trunc i32 %7220 to i8
  %7222 = shl i8 1, %7221
  %7223 = or i8 %7202, %7222
  %7224 = select i1 %7213, i8 %7223, i8 %7202
  store i8 %7224, ptr %frame.active, align 1
  %7225 = load <8 x i32>, ptr %frame.static.id, align 32
  %7226 = extractelement <8 x i32> %7225, i32 %7220
  %7227 = select i1 %7213, i32 22, i32 %7226
  %7228 = load <8 x i32>, ptr %frame.static.id, align 32
  %7229 = insertelement <8 x i32> %7228, i32 %7227, i32 %7220
  store <8 x i32> %7229, ptr %frame.static.id, align 32
  %7230 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7231 = extractelement <8 x i32> %7230, i32 %7220
  %7232 = select i1 %7213, i32 %7198, i32 %7231
  %7233 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7234 = insertelement <8 x i32> %7233, i32 %7232, i32 %7220
  store <8 x i32> %7234, ptr %frame.parent.token, align 32
  %7235 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7220
  %7236 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7220
  %7237 = load <8 x i1>, ptr %7235, align 1
  %7238 = load <8 x i1>, ptr %7236, align 1
  %7239 = select i1 %7213, <8 x i1> %1673, <8 x i1> %7237
  store <8 x i1> %7239, ptr %7235, align 1
  %7240 = select i1 %7213, <8 x i1> zeroinitializer, <8 x i1> %7238
  store <8 x i1> %7240, ptr %7236, align 1
  %7241 = add i32 %7220, 1
  %7242 = select i1 %7211, i32 %7198, i32 %7241
  %7243 = select i1 true, i32 %7242, i32 %7198
  store i32 %7243, ptr %current.token, align 4
  %7244 = load i32, ptr %current.token, align 4
  %7245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1680)
  %7246 = load i32, ptr %ready.count, align 4
  %7247 = icmp uge i32 %7246, 8
  %7248 = and i1 %7245, %7247
  br i1 %7248, label %ready.overflow.trap1354, label %ready.overflow.resume1355

ready.overflow.trap1354:                          ; preds = %convergence.overflow.resume1353
  call void @llvm.trap()
  unreachable

ready.overflow.resume1355:                        ; preds = %convergence.overflow.resume1353
  %7249 = select i1 %7245, i32 %7246, i32 0
  %7250 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7249
  %7251 = load <8 x i1>, ptr %7250, align 1
  %7252 = select i1 %7245, <8 x i1> %1680, <8 x i1> %7251
  store <8 x i1> %7252, ptr %7250, align 1
  %7253 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7249
  %7254 = load i32, ptr %7253, align 4
  %7255 = select i1 %7245, i32 64, i32 %7254
  store i32 %7255, ptr %7253, align 4
  %7256 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7249
  %7257 = load i32, ptr %7256, align 4
  %7258 = select i1 %7245, i32 %7244, i32 %7257
  store i32 %7258, ptr %7256, align 4
  %7259 = add i32 %7246, 1
  %7260 = select i1 %7245, i32 %7259, i32 %7246
  store i32 %7260, ptr %ready.count, align 4
  %7261 = load <8 x i1>, ptr %runnable.mask, align 1
  %7262 = or <8 x i1> %7261, %1680
  store <8 x i1> %7262, ptr %runnable.mask, align 1
  store <8 x i1> %1682, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1356:                        ; preds = %varying.coherent1351
  store <8 x i1> %1673, ptr %current.mask, align 1
  %7263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1673)
  br i1 %7263, label %schedule.64, label %scheduler.loop

varying.coherent.false1357:                       ; preds = %varying.coherent1351
  store <8 x i1> %1673, ptr %current.mask, align 1
  %7264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1673)
  br i1 %7264, label %schedule.65, label %scheduler.loop

convergence.cascade1362:                          ; preds = %convergence.cascade1362, %schedule.65
  %convergence.cascade.flow1366 = phi <8 x i1> [ %1713, %schedule.65 ], [ %7307, %convergence.cascade1362 ]
  %convergence.cascade.depth1367 = phi i32 [ 0, %schedule.65 ], [ %7308, %convergence.cascade1362 ]
  %7265 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1366)
  %7266 = load i32, ptr %current.token, align 4
  %7267 = icmp ne i32 %7266, 0
  %7268 = and i1 %7265, %7267
  %7269 = sub i32 %7266, 1
  %7270 = select i1 %7268, i32 %7269, i32 0
  %7271 = load i8, ptr %frame.active, align 1
  %7272 = trunc i32 %7270 to i8
  %7273 = shl i8 1, %7272
  %7274 = and i8 %7271, %7273
  %7275 = icmp ne i8 %7274, 0
  %7276 = load <8 x i32>, ptr %frame.static.id, align 32
  %7277 = extractelement <8 x i32> %7276, i32 %7270
  %convergence.target.pointer1368 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %7277
  %convergence.dynamic.target1369 = load i32, ptr %convergence.target.pointer1368, align 4
  %7278 = icmp eq i32 %convergence.dynamic.target1369, 65
  %7279 = and i1 %7275, %7278
  %7280 = and i1 %7268, %7279
  %7281 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7270
  %7282 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7270
  %7283 = load <8 x i1>, ptr %7281, align 1
  %7284 = load <8 x i1>, ptr %7282, align 1
  %7285 = or <8 x i1> %7284, %convergence.cascade.flow1366
  %7286 = load <8 x i1>, ptr %live.mask, align 1
  %7287 = and <8 x i1> %7283, %7286
  %7288 = icmp eq <8 x i1> %7285, %7287
  %7289 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7288)
  %7290 = and i1 %7280, %7289
  %7291 = select i1 %7290, <8 x i1> zeroinitializer, <8 x i1> %7285
  %7292 = select i1 %7280, <8 x i1> %7291, <8 x i1> %7284
  store <8 x i1> %7292, ptr %7282, align 1
  %7293 = select i1 %7290, <8 x i1> zeroinitializer, <8 x i1> %7283
  store <8 x i1> %7293, ptr %7281, align 1
  %7294 = trunc i32 %7270 to i8
  %7295 = shl i8 1, %7294
  %7296 = xor i8 %7295, -1
  %7297 = and i8 %7271, %7296
  %7298 = select i1 %7290, i8 %7297, i8 %7271
  store i8 %7298, ptr %frame.active, align 1
  %.splatinsert1370 = insertelement <8 x i1> poison, i1 %7280, i64 0
  %.splat1371 = shufflevector <8 x i1> %.splatinsert1370, <8 x i1> poison, <8 x i32> zeroinitializer
  %7299 = and <8 x i1> %convergence.cascade.flow1366, %.splat1371
  %7300 = load <8 x i1>, ptr %runnable.mask, align 1
  %7301 = xor <8 x i1> %7299, splat (i1 true)
  %7302 = and <8 x i1> %7300, %7301
  store <8 x i1> %7302, ptr %runnable.mask, align 1
  %.splatinsert1372 = insertelement <8 x i1> poison, i1 %7290, i64 0
  %.splat1373 = shufflevector <8 x i1> %.splatinsert1372, <8 x i1> poison, <8 x i32> zeroinitializer
  %7303 = select <8 x i1> %.splat1373, <8 x i1> %7285, <8 x i1> zeroinitializer
  %7304 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7305 = extractelement <8 x i32> %7304, i32 %7270
  %7306 = select i1 %7290, i32 %7305, i32 %7266
  store i32 %7306, ptr %current.token, align 4
  %.splatinsert1374 = insertelement <8 x i1> poison, i1 %7280, i64 0
  %.splat1375 = shufflevector <8 x i1> %.splatinsert1374, <8 x i1> poison, <8 x i32> zeroinitializer
  %7307 = select <8 x i1> %.splat1375, <8 x i1> %7303, <8 x i1> %convergence.cascade.flow1366
  %7308 = add i32 %convergence.cascade.depth1367, 1
  %7309 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7307)
  %7310 = icmp ult i32 %7308, 8
  %7311 = and i1 %7309, %7310
  %7312 = and i1 %7280, %7311
  %convergence.parent.token1376 = load i32, ptr %current.token, align 4
  %convergence.parent.present1377 = icmp ne i32 %convergence.parent.token1376, 0
  %7313 = and i1 %7312, %convergence.parent.present1377
  br i1 %7313, label %convergence.cascade1362, label %convergence.cascade.exit1363

convergence.cascade.exit1363:                     ; preds = %convergence.cascade1362, %schedule.65
  %convergence.cascade.result1378 = phi <8 x i1> [ %1713, %schedule.65 ], [ %7307, %convergence.cascade1362 ]
  %7314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1378)
  br i1 %7314, label %convergence.target.65.ready, label %scheduler.loop

convergence.target.65.ready:                      ; preds = %convergence.cascade.exit1363
  %7315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1378)
  %7316 = bitcast <8 x i1> %convergence.cascade.result1378 to i8
  %7317 = call i8 @llvm.cttz.i8(i8 %7316, i1 false)
  %7318 = zext i8 %7317 to i32
  %7319 = select i1 %7315, i32 %7318, i32 0
  %7320 = load <8 x i64>, ptr %.slot55, align 64
  %7321 = select <8 x i1> %convergence.cascade.result1378, <8 x i64> zeroinitializer, <8 x i64> %7320
  store <8 x i64> %7321, ptr %.slot55, align 64
  %7322 = load <8 x float>, ptr %.slot58, align 32
  %7323 = select <8 x i1> %convergence.cascade.result1378, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7322
  store <8 x float> %7323, ptr %.slot58, align 32
  store <8 x i1> %convergence.cascade.result1378, ptr %current.mask, align 1
  %7324 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1378)
  br i1 %7324, label %schedule.66, label %scheduler.loop

varying.divergent1380:                            ; preds = %schedule.66
  %7325 = load i32, ptr %current.token, align 4
  %7326 = icmp ne i32 %7325, 0
  %7327 = sub i32 %7325, 1
  %7328 = select i1 %7326, i32 %7327, i32 0
  %7329 = load i8, ptr %frame.active, align 1
  %7330 = trunc i32 %7328 to i8
  %7331 = shl i8 1, %7330
  %7332 = and i8 %7329, %7331
  %7333 = icmp ne i8 %7332, 0
  %7334 = load <8 x i32>, ptr %frame.static.id, align 32
  %7335 = extractelement <8 x i32> %7334, i32 %7328
  %7336 = icmp eq i32 %7335, 23
  %7337 = and i1 %7333, %7336
  %7338 = and i1 %7326, %7337
  %7339 = xor i1 %7338, true
  %7340 = and i1 true, %7339
  %7341 = xor i8 %7329, -1
  %7342 = icmp ne i8 %7341, 0
  %7343 = xor i1 %7342, true
  %7344 = and i1 %7340, %7343
  br i1 %7344, label %convergence.overflow.trap1382, label %convergence.overflow.resume1383

varying.coherent1381:                             ; preds = %schedule.66
  br i1 %1724, label %varying.coherent.true1386, label %varying.coherent.false1387

convergence.overflow.trap1382:                    ; preds = %varying.divergent1380
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1383:                  ; preds = %varying.divergent1380
  %7345 = call i8 @llvm.cttz.i8(i8 %7341, i1 false)
  %7346 = zext i8 %7345 to i32
  %7347 = select i1 %7342, i32 %7346, i32 0
  %7348 = trunc i32 %7347 to i8
  %7349 = shl i8 1, %7348
  %7350 = or i8 %7329, %7349
  %7351 = select i1 %7340, i8 %7350, i8 %7329
  store i8 %7351, ptr %frame.active, align 1
  %7352 = load <8 x i32>, ptr %frame.static.id, align 32
  %7353 = extractelement <8 x i32> %7352, i32 %7347
  %7354 = select i1 %7340, i32 23, i32 %7353
  %7355 = load <8 x i32>, ptr %frame.static.id, align 32
  %7356 = insertelement <8 x i32> %7355, i32 %7354, i32 %7347
  store <8 x i32> %7356, ptr %frame.static.id, align 32
  %7357 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7358 = extractelement <8 x i32> %7357, i32 %7347
  %7359 = select i1 %7340, i32 %7325, i32 %7358
  %7360 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7361 = insertelement <8 x i32> %7360, i32 %7359, i32 %7347
  store <8 x i32> %7361, ptr %frame.parent.token, align 32
  %7362 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7347
  %7363 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7347
  %7364 = load <8 x i1>, ptr %7362, align 1
  %7365 = load <8 x i1>, ptr %7363, align 1
  %7366 = select i1 %7340, <8 x i1> %1714, <8 x i1> %7364
  store <8 x i1> %7366, ptr %7362, align 1
  %7367 = select i1 %7340, <8 x i1> zeroinitializer, <8 x i1> %7365
  store <8 x i1> %7367, ptr %7363, align 1
  %7368 = add i32 %7347, 1
  %7369 = select i1 %7338, i32 %7325, i32 %7368
  %7370 = select i1 true, i32 %7369, i32 %7325
  store i32 %7370, ptr %current.token, align 4
  %7371 = load i32, ptr %current.token, align 4
  %7372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1721)
  %7373 = load i32, ptr %ready.count, align 4
  %7374 = icmp uge i32 %7373, 8
  %7375 = and i1 %7372, %7374
  br i1 %7375, label %ready.overflow.trap1384, label %ready.overflow.resume1385

ready.overflow.trap1384:                          ; preds = %convergence.overflow.resume1383
  call void @llvm.trap()
  unreachable

ready.overflow.resume1385:                        ; preds = %convergence.overflow.resume1383
  %7376 = select i1 %7372, i32 %7373, i32 0
  %7377 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7376
  %7378 = load <8 x i1>, ptr %7377, align 1
  %7379 = select i1 %7372, <8 x i1> %1721, <8 x i1> %7378
  store <8 x i1> %7379, ptr %7377, align 1
  %7380 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7376
  %7381 = load i32, ptr %7380, align 4
  %7382 = select i1 %7372, i32 67, i32 %7381
  store i32 %7382, ptr %7380, align 4
  %7383 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7376
  %7384 = load i32, ptr %7383, align 4
  %7385 = select i1 %7372, i32 %7371, i32 %7384
  store i32 %7385, ptr %7383, align 4
  %7386 = add i32 %7373, 1
  %7387 = select i1 %7372, i32 %7386, i32 %7373
  store i32 %7387, ptr %ready.count, align 4
  %7388 = load <8 x i1>, ptr %runnable.mask, align 1
  %7389 = or <8 x i1> %7388, %1721
  store <8 x i1> %7389, ptr %runnable.mask, align 1
  store <8 x i1> %1723, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1386:                        ; preds = %varying.coherent1381
  store <8 x i1> %1714, ptr %current.mask, align 1
  %7390 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1714)
  br i1 %7390, label %schedule.67, label %scheduler.loop

varying.coherent.false1387:                       ; preds = %varying.coherent1381
  store <8 x i1> %1714, ptr %current.mask, align 1
  %7391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1714)
  br i1 %7391, label %schedule.68, label %scheduler.loop

convergence.cascade1392:                          ; preds = %convergence.cascade1392, %schedule.68
  %convergence.cascade.flow1396 = phi <8 x i1> [ %1754, %schedule.68 ], [ %7434, %convergence.cascade1392 ]
  %convergence.cascade.depth1397 = phi i32 [ 0, %schedule.68 ], [ %7435, %convergence.cascade1392 ]
  %7392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1396)
  %7393 = load i32, ptr %current.token, align 4
  %7394 = icmp ne i32 %7393, 0
  %7395 = and i1 %7392, %7394
  %7396 = sub i32 %7393, 1
  %7397 = select i1 %7395, i32 %7396, i32 0
  %7398 = load i8, ptr %frame.active, align 1
  %7399 = trunc i32 %7397 to i8
  %7400 = shl i8 1, %7399
  %7401 = and i8 %7398, %7400
  %7402 = icmp ne i8 %7401, 0
  %7403 = load <8 x i32>, ptr %frame.static.id, align 32
  %7404 = extractelement <8 x i32> %7403, i32 %7397
  %convergence.target.pointer1398 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %7404
  %convergence.dynamic.target1399 = load i32, ptr %convergence.target.pointer1398, align 4
  %7405 = icmp eq i32 %convergence.dynamic.target1399, 68
  %7406 = and i1 %7402, %7405
  %7407 = and i1 %7395, %7406
  %7408 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7397
  %7409 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7397
  %7410 = load <8 x i1>, ptr %7408, align 1
  %7411 = load <8 x i1>, ptr %7409, align 1
  %7412 = or <8 x i1> %7411, %convergence.cascade.flow1396
  %7413 = load <8 x i1>, ptr %live.mask, align 1
  %7414 = and <8 x i1> %7410, %7413
  %7415 = icmp eq <8 x i1> %7412, %7414
  %7416 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7415)
  %7417 = and i1 %7407, %7416
  %7418 = select i1 %7417, <8 x i1> zeroinitializer, <8 x i1> %7412
  %7419 = select i1 %7407, <8 x i1> %7418, <8 x i1> %7411
  store <8 x i1> %7419, ptr %7409, align 1
  %7420 = select i1 %7417, <8 x i1> zeroinitializer, <8 x i1> %7410
  store <8 x i1> %7420, ptr %7408, align 1
  %7421 = trunc i32 %7397 to i8
  %7422 = shl i8 1, %7421
  %7423 = xor i8 %7422, -1
  %7424 = and i8 %7398, %7423
  %7425 = select i1 %7417, i8 %7424, i8 %7398
  store i8 %7425, ptr %frame.active, align 1
  %.splatinsert1400 = insertelement <8 x i1> poison, i1 %7407, i64 0
  %.splat1401 = shufflevector <8 x i1> %.splatinsert1400, <8 x i1> poison, <8 x i32> zeroinitializer
  %7426 = and <8 x i1> %convergence.cascade.flow1396, %.splat1401
  %7427 = load <8 x i1>, ptr %runnable.mask, align 1
  %7428 = xor <8 x i1> %7426, splat (i1 true)
  %7429 = and <8 x i1> %7427, %7428
  store <8 x i1> %7429, ptr %runnable.mask, align 1
  %.splatinsert1402 = insertelement <8 x i1> poison, i1 %7417, i64 0
  %.splat1403 = shufflevector <8 x i1> %.splatinsert1402, <8 x i1> poison, <8 x i32> zeroinitializer
  %7430 = select <8 x i1> %.splat1403, <8 x i1> %7412, <8 x i1> zeroinitializer
  %7431 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7432 = extractelement <8 x i32> %7431, i32 %7397
  %7433 = select i1 %7417, i32 %7432, i32 %7393
  store i32 %7433, ptr %current.token, align 4
  %.splatinsert1404 = insertelement <8 x i1> poison, i1 %7407, i64 0
  %.splat1405 = shufflevector <8 x i1> %.splatinsert1404, <8 x i1> poison, <8 x i32> zeroinitializer
  %7434 = select <8 x i1> %.splat1405, <8 x i1> %7430, <8 x i1> %convergence.cascade.flow1396
  %7435 = add i32 %convergence.cascade.depth1397, 1
  %7436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7434)
  %7437 = icmp ult i32 %7435, 8
  %7438 = and i1 %7436, %7437
  %7439 = and i1 %7407, %7438
  %convergence.parent.token1406 = load i32, ptr %current.token, align 4
  %convergence.parent.present1407 = icmp ne i32 %convergence.parent.token1406, 0
  %7440 = and i1 %7439, %convergence.parent.present1407
  br i1 %7440, label %convergence.cascade1392, label %convergence.cascade.exit1393

convergence.cascade.exit1393:                     ; preds = %convergence.cascade1392, %schedule.68
  %convergence.cascade.result1408 = phi <8 x i1> [ %1754, %schedule.68 ], [ %7434, %convergence.cascade1392 ]
  %7441 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1408)
  br i1 %7441, label %convergence.target.68.ready, label %scheduler.loop

convergence.target.68.ready:                      ; preds = %convergence.cascade.exit1393
  %7442 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1408)
  %7443 = bitcast <8 x i1> %convergence.cascade.result1408 to i8
  %7444 = call i8 @llvm.cttz.i8(i8 %7443, i1 false)
  %7445 = zext i8 %7444 to i32
  %7446 = select i1 %7442, i32 %7445, i32 0
  %7447 = load <8 x i64>, ptr %.slot55, align 64
  %7448 = select <8 x i1> %convergence.cascade.result1408, <8 x i64> zeroinitializer, <8 x i64> %7447
  store <8 x i64> %7448, ptr %.slot55, align 64
  %7449 = load <8 x float>, ptr %.slot59, align 32
  %7450 = select <8 x i1> %convergence.cascade.result1408, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %7449
  store <8 x float> %7450, ptr %.slot59, align 32
  store <8 x i1> %convergence.cascade.result1408, ptr %current.mask, align 1
  %7451 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1408)
  br i1 %7451, label %schedule.69, label %scheduler.loop

varying.divergent1410:                            ; preds = %schedule.69
  %7452 = load i32, ptr %current.token, align 4
  %7453 = icmp ne i32 %7452, 0
  %7454 = sub i32 %7452, 1
  %7455 = select i1 %7453, i32 %7454, i32 0
  %7456 = load i8, ptr %frame.active, align 1
  %7457 = trunc i32 %7455 to i8
  %7458 = shl i8 1, %7457
  %7459 = and i8 %7456, %7458
  %7460 = icmp ne i8 %7459, 0
  %7461 = load <8 x i32>, ptr %frame.static.id, align 32
  %7462 = extractelement <8 x i32> %7461, i32 %7455
  %7463 = icmp eq i32 %7462, 24
  %7464 = and i1 %7460, %7463
  %7465 = and i1 %7453, %7464
  %7466 = xor i1 %7465, true
  %7467 = and i1 true, %7466
  %7468 = xor i8 %7456, -1
  %7469 = icmp ne i8 %7468, 0
  %7470 = xor i1 %7469, true
  %7471 = and i1 %7467, %7470
  br i1 %7471, label %convergence.overflow.trap1412, label %convergence.overflow.resume1413

varying.coherent1411:                             ; preds = %schedule.69
  br i1 %1765, label %varying.coherent.true1416, label %varying.coherent.false1417

convergence.overflow.trap1412:                    ; preds = %varying.divergent1410
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1413:                  ; preds = %varying.divergent1410
  %7472 = call i8 @llvm.cttz.i8(i8 %7468, i1 false)
  %7473 = zext i8 %7472 to i32
  %7474 = select i1 %7469, i32 %7473, i32 0
  %7475 = trunc i32 %7474 to i8
  %7476 = shl i8 1, %7475
  %7477 = or i8 %7456, %7476
  %7478 = select i1 %7467, i8 %7477, i8 %7456
  store i8 %7478, ptr %frame.active, align 1
  %7479 = load <8 x i32>, ptr %frame.static.id, align 32
  %7480 = extractelement <8 x i32> %7479, i32 %7474
  %7481 = select i1 %7467, i32 24, i32 %7480
  %7482 = load <8 x i32>, ptr %frame.static.id, align 32
  %7483 = insertelement <8 x i32> %7482, i32 %7481, i32 %7474
  store <8 x i32> %7483, ptr %frame.static.id, align 32
  %7484 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7485 = extractelement <8 x i32> %7484, i32 %7474
  %7486 = select i1 %7467, i32 %7452, i32 %7485
  %7487 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7488 = insertelement <8 x i32> %7487, i32 %7486, i32 %7474
  store <8 x i32> %7488, ptr %frame.parent.token, align 32
  %7489 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7474
  %7490 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7474
  %7491 = load <8 x i1>, ptr %7489, align 1
  %7492 = load <8 x i1>, ptr %7490, align 1
  %7493 = select i1 %7467, <8 x i1> %1755, <8 x i1> %7491
  store <8 x i1> %7493, ptr %7489, align 1
  %7494 = select i1 %7467, <8 x i1> zeroinitializer, <8 x i1> %7492
  store <8 x i1> %7494, ptr %7490, align 1
  %7495 = add i32 %7474, 1
  %7496 = select i1 %7465, i32 %7452, i32 %7495
  %7497 = select i1 true, i32 %7496, i32 %7452
  store i32 %7497, ptr %current.token, align 4
  %7498 = load i32, ptr %current.token, align 4
  %7499 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1762)
  %7500 = load i32, ptr %ready.count, align 4
  %7501 = icmp uge i32 %7500, 8
  %7502 = and i1 %7499, %7501
  br i1 %7502, label %ready.overflow.trap1414, label %ready.overflow.resume1415

ready.overflow.trap1414:                          ; preds = %convergence.overflow.resume1413
  call void @llvm.trap()
  unreachable

ready.overflow.resume1415:                        ; preds = %convergence.overflow.resume1413
  %7503 = select i1 %7499, i32 %7500, i32 0
  %7504 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %7503
  %7505 = load <8 x i1>, ptr %7504, align 1
  %7506 = select i1 %7499, <8 x i1> %1762, <8 x i1> %7505
  store <8 x i1> %7506, ptr %7504, align 1
  %7507 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %7503
  %7508 = load i32, ptr %7507, align 4
  %7509 = select i1 %7499, i32 70, i32 %7508
  store i32 %7509, ptr %7507, align 4
  %7510 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %7503
  %7511 = load i32, ptr %7510, align 4
  %7512 = select i1 %7499, i32 %7498, i32 %7511
  store i32 %7512, ptr %7510, align 4
  %7513 = add i32 %7500, 1
  %7514 = select i1 %7499, i32 %7513, i32 %7500
  store i32 %7514, ptr %ready.count, align 4
  %7515 = load <8 x i1>, ptr %runnable.mask, align 1
  %7516 = or <8 x i1> %7515, %1762
  store <8 x i1> %7516, ptr %runnable.mask, align 1
  store <8 x i1> %1764, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1416:                        ; preds = %varying.coherent1411
  store <8 x i1> %1755, ptr %current.mask, align 1
  %7517 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1755)
  br i1 %7517, label %schedule.70, label %scheduler.loop

varying.coherent.false1417:                       ; preds = %varying.coherent1411
  store <8 x i1> %1755, ptr %current.mask, align 1
  %7518 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1755)
  br i1 %7518, label %schedule.71, label %scheduler.loop

convergence.cascade1422:                          ; preds = %convergence.cascade1422, %schedule.71
  %convergence.cascade.flow1426 = phi <8 x i1> [ %1795, %schedule.71 ], [ %7561, %convergence.cascade1422 ]
  %convergence.cascade.depth1427 = phi i32 [ 0, %schedule.71 ], [ %7562, %convergence.cascade1422 ]
  %7519 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1426)
  %7520 = load i32, ptr %current.token, align 4
  %7521 = icmp ne i32 %7520, 0
  %7522 = and i1 %7519, %7521
  %7523 = sub i32 %7520, 1
  %7524 = select i1 %7522, i32 %7523, i32 0
  %7525 = load i8, ptr %frame.active, align 1
  %7526 = trunc i32 %7524 to i8
  %7527 = shl i8 1, %7526
  %7528 = and i8 %7525, %7527
  %7529 = icmp ne i8 %7528, 0
  %7530 = load <8 x i32>, ptr %frame.static.id, align 32
  %7531 = extractelement <8 x i32> %7530, i32 %7524
  %convergence.target.pointer1428 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %7531
  %convergence.dynamic.target1429 = load i32, ptr %convergence.target.pointer1428, align 4
  %7532 = icmp eq i32 %convergence.dynamic.target1429, 71
  %7533 = and i1 %7529, %7532
  %7534 = and i1 %7522, %7533
  %7535 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %7524
  %7536 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %7524
  %7537 = load <8 x i1>, ptr %7535, align 1
  %7538 = load <8 x i1>, ptr %7536, align 1
  %7539 = or <8 x i1> %7538, %convergence.cascade.flow1426
  %7540 = load <8 x i1>, ptr %live.mask, align 1
  %7541 = and <8 x i1> %7537, %7540
  %7542 = icmp eq <8 x i1> %7539, %7541
  %7543 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %7542)
  %7544 = and i1 %7534, %7543
  %7545 = select i1 %7544, <8 x i1> zeroinitializer, <8 x i1> %7539
  %7546 = select i1 %7534, <8 x i1> %7545, <8 x i1> %7538
  store <8 x i1> %7546, ptr %7536, align 1
  %7547 = select i1 %7544, <8 x i1> zeroinitializer, <8 x i1> %7537
  store <8 x i1> %7547, ptr %7535, align 1
  %7548 = trunc i32 %7524 to i8
  %7549 = shl i8 1, %7548
  %7550 = xor i8 %7549, -1
  %7551 = and i8 %7525, %7550
  %7552 = select i1 %7544, i8 %7551, i8 %7525
  store i8 %7552, ptr %frame.active, align 1
  %.splatinsert1430 = insertelement <8 x i1> poison, i1 %7534, i64 0
  %.splat1431 = shufflevector <8 x i1> %.splatinsert1430, <8 x i1> poison, <8 x i32> zeroinitializer
  %7553 = and <8 x i1> %convergence.cascade.flow1426, %.splat1431
  %7554 = load <8 x i1>, ptr %runnable.mask, align 1
  %7555 = xor <8 x i1> %7553, splat (i1 true)
  %7556 = and <8 x i1> %7554, %7555
  store <8 x i1> %7556, ptr %runnable.mask, align 1
  %.splatinsert1432 = insertelement <8 x i1> poison, i1 %7544, i64 0
  %.splat1433 = shufflevector <8 x i1> %.splatinsert1432, <8 x i1> poison, <8 x i32> zeroinitializer
  %7557 = select <8 x i1> %.splat1433, <8 x i1> %7539, <8 x i1> zeroinitializer
  %7558 = load <8 x i32>, ptr %frame.parent.token, align 32
  %7559 = extractelement <8 x i32> %7558, i32 %7524
  %7560 = select i1 %7544, i32 %7559, i32 %7520
  store i32 %7560, ptr %current.token, align 4
  %.splatinsert1434 = insertelement <8 x i1> poison, i1 %7534, i64 0
  %.splat1435 = shufflevector <8 x i1> %.splatinsert1434, <8 x i1> poison, <8 x i32> zeroinitializer
  %7561 = select <8 x i1> %.splat1435, <8 x i1> %7557, <8 x i1> %convergence.cascade.flow1426
  %7562 = add i32 %convergence.cascade.depth1427, 1
  %7563 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %7561)
  %7564 = icmp ult i32 %7562, 8
  %7565 = and i1 %7563, %7564
  %7566 = and i1 %7534, %7565
  %convergence.parent.token1436 = load i32, ptr %current.token, align 4
  %convergence.parent.present1437 = icmp ne i32 %convergence.parent.token1436, 0
  %7567 = and i1 %7566, %convergence.parent.present1437
  br i1 %7567, label %convergence.cascade1422, label %convergence.cascade.exit1423

convergence.cascade.exit1423:                     ; preds = %convergence.cascade1422, %schedule.71
  %convergence.cascade.result1438 = phi <8 x i1> [ %1795, %schedule.71 ], [ %7561, %convergence.cascade1422 ]
  %7568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  br i1 %7568, label %convergence.target.71.ready, label %scheduler.loop

convergence.target.71.ready:                      ; preds = %convergence.cascade.exit1423
  %7569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7570 = bitcast <8 x i1> %convergence.cascade.result1438 to i8
  %7571 = call i8 @llvm.cttz.i8(i8 %7570, i1 false)
  %7572 = zext i8 %7571 to i32
  %7573 = select i1 %7569, i32 %7572, i32 0
  %.state1439 = load <8 x float>, ptr %.slot43, align 32
  %.state1440 = load <8 x float>, ptr %.slot56, align 32
  %7574 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1439, <8 x float> %.state1440)
  %7575 = load <8 x float>, ptr %.spill272, align 32
  %7576 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7574, <8 x float> %7575
  store <8 x float> %7576, ptr %.spill272, align 32
  %.state1441 = load <8 x float>, ptr %.slot44, align 32
  %.state1442 = load <8 x float>, ptr %.slot57, align 32
  %7577 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1441, <8 x float> %.state1442)
  %7578 = load <8 x float>, ptr %.spill273, align 32
  %7579 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7577, <8 x float> %7578
  store <8 x float> %7579, ptr %.spill273, align 32
  %.state1443 = load <8 x float>, ptr %.slot45, align 32
  %.state1444 = load <8 x float>, ptr %.slot58, align 32
  %7580 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1443, <8 x float> %.state1444)
  %7581 = load <8 x float>, ptr %.spill274, align 32
  %7582 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7580, <8 x float> %7581
  store <8 x float> %7582, ptr %.spill274, align 32
  %.state1445 = load <8 x float>, ptr %.slot46, align 32
  %.state1446 = load <8 x float>, ptr %.slot59, align 32
  %7583 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state1445, <8 x float> %.state1446)
  %7584 = load <8 x float>, ptr %.spill275, align 32
  %7585 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7583, <8 x float> %7584
  store <8 x float> %7585, ptr %.spill275, align 32
  %.state1447 = load <8 x float>, ptr %.slot43, align 32
  %7586 = fsub <8 x float> %.state1447, %7574
  %.state1448 = load <8 x float>, ptr %.slot44, align 32
  %7587 = fsub <8 x float> %.state1448, %7577
  %.state1449 = load <8 x float>, ptr %.slot45, align 32
  %7588 = fsub <8 x float> %.state1449, %7580
  %.state1450 = load <8 x float>, ptr %.slot46, align 32
  %7589 = fsub <8 x float> %.state1450, %7583
  %7590 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7586, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7590)
  %7591 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7587, <8 x float> zeroinitializer
  %native.exp1451 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7591)
  %7592 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7588, <8 x float> zeroinitializer
  %native.exp1452 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7592)
  %7593 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7589, <8 x float> zeroinitializer
  %native.exp1453 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7593)
  %7594 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill276, align 64
  %7595 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7596 = extractvalue { <8 x ptr>, <8 x i64> } %7594, 0
  %7597 = select <8 x i1> %convergence.cascade.result1438, <8 x ptr> %7595, <8 x ptr> %7596
  %7598 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7599 = extractvalue { <8 x ptr>, <8 x i64> } %7594, 1
  %7600 = select <8 x i1> %convergence.cascade.result1438, <8 x i64> %7598, <8 x i64> %7599
  %7601 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7597, 0
  %7602 = insertvalue { <8 x ptr>, <8 x i64> } %7601, <8 x i64> %7600, 1
  store { <8 x ptr>, <8 x i64> } %7602, ptr %tile_snapshot.spill276, align 64
  %7603 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7604 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7605 = add <8 x i64> %7604, zeroinitializer
  %7606 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7603, 0
  %7607 = insertvalue { <8 x ptr>, <8 x i64> } %7606, <8 x i64> %7605, 1
  %7608 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7609 = extractvalue { <8 x ptr>, <8 x i64> } %7607, 1
  %7610 = extractelement <8 x ptr> %7608, i32 0
  %7611 = extractelement <8 x i64> %7609, i32 %7573
  %7612 = zext i32 %7573 to i64
  %7613 = mul i64 %7612, 4
  %7614 = sub i64 %7611, %7613
  %7615 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7616 = select i1 %7615, i64 %7614, i64 0
  %private.contiguous.address1454 = getelementptr i8, ptr %7610, i64 %7616
  %private.contiguous.preserve1455 = load <8 x float>, ptr %private.contiguous.address1454, align 4
  %7617 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve1455
  store <8 x float> %7617, ptr %private.contiguous.address1454, align 4
  %7618 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7619 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7620 = add <8 x i64> %7619, splat (i64 32)
  %7621 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7618, 0
  %7622 = insertvalue { <8 x ptr>, <8 x i64> } %7621, <8 x i64> %7620, 1
  %7623 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7624 = extractvalue { <8 x ptr>, <8 x i64> } %7622, 1
  %7625 = extractelement <8 x ptr> %7623, i32 0
  %7626 = extractelement <8 x i64> %7624, i32 %7573
  %7627 = zext i32 %7573 to i64
  %7628 = mul i64 %7627, 4
  %7629 = sub i64 %7626, %7628
  %7630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7631 = select i1 %7630, i64 %7629, i64 0
  %private.contiguous.address1456 = getelementptr i8, ptr %7625, i64 %7631
  %private.contiguous.preserve1457 = load <8 x float>, ptr %private.contiguous.address1456, align 4
  %7632 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %native.exp1451, <8 x float> %private.contiguous.preserve1457
  store <8 x float> %7632, ptr %private.contiguous.address1456, align 4
  %7633 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7634 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7635 = add <8 x i64> %7634, splat (i64 64)
  %7636 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7633, 0
  %7637 = insertvalue { <8 x ptr>, <8 x i64> } %7636, <8 x i64> %7635, 1
  %7638 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7639 = extractvalue { <8 x ptr>, <8 x i64> } %7637, 1
  %7640 = extractelement <8 x ptr> %7638, i32 0
  %7641 = extractelement <8 x i64> %7639, i32 %7573
  %7642 = zext i32 %7573 to i64
  %7643 = mul i64 %7642, 4
  %7644 = sub i64 %7641, %7643
  %7645 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7646 = select i1 %7645, i64 %7644, i64 0
  %private.contiguous.address1458 = getelementptr i8, ptr %7640, i64 %7646
  %private.contiguous.preserve1459 = load <8 x float>, ptr %private.contiguous.address1458, align 4
  %7647 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %native.exp1452, <8 x float> %private.contiguous.preserve1459
  store <8 x float> %7647, ptr %private.contiguous.address1458, align 4
  %7648 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7649 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %7650 = add <8 x i64> %7649, splat (i64 96)
  %7651 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7648, 0
  %7652 = insertvalue { <8 x ptr>, <8 x i64> } %7651, <8 x i64> %7650, 1
  %7653 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %7654 = extractvalue { <8 x ptr>, <8 x i64> } %7652, 1
  %7655 = extractelement <8 x ptr> %7653, i32 0
  %7656 = extractelement <8 x i64> %7654, i32 %7573
  %7657 = zext i32 %7573 to i64
  %7658 = mul i64 %7657, 4
  %7659 = sub i64 %7656, %7658
  %7660 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7661 = select i1 %7660, i64 %7659, i64 0
  %private.contiguous.address1460 = getelementptr i8, ptr %7655, i64 %7661
  %private.contiguous.preserve1461 = load <8 x float>, ptr %private.contiguous.address1460, align 4
  %7662 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %native.exp1453, <8 x float> %private.contiguous.preserve1461
  store <8 x float> %7662, ptr %private.contiguous.address1460, align 4
  %.spill.load1462 = load <8 x float>, ptr %.spill199, align 32
  %7663 = fsub <8 x float> %.spill.load1462, %7574
  %.spill.load1463 = load <8 x float>, ptr %.spill200, align 32
  %7664 = fsub <8 x float> %.spill.load1463, %7574
  %.spill.load1464 = load <8 x float>, ptr %.spill201, align 32
  %7665 = fsub <8 x float> %.spill.load1464, %7574
  %.spill.load1465 = load <8 x float>, ptr %.spill202, align 32
  %7666 = fsub <8 x float> %.spill.load1465, %7574
  %.spill.load1466 = load <8 x float>, ptr %.spill203, align 32
  %7667 = fsub <8 x float> %.spill.load1466, %7574
  %.spill.load1467 = load <8 x float>, ptr %.spill204, align 32
  %7668 = fsub <8 x float> %.spill.load1467, %7574
  %.spill.load1468 = load <8 x float>, ptr %.spill205, align 32
  %7669 = fsub <8 x float> %.spill.load1468, %7574
  %.spill.load1469 = load <8 x float>, ptr %.spill206, align 32
  %7670 = fsub <8 x float> %.spill.load1469, %7574
  %.spill.load1470 = load <8 x float>, ptr %.spill207, align 32
  %7671 = fsub <8 x float> %.spill.load1470, %7574
  %.spill.load1471 = load <8 x float>, ptr %.spill208, align 32
  %7672 = fsub <8 x float> %.spill.load1471, %7574
  %.spill.load1472 = load <8 x float>, ptr %.spill209, align 32
  %7673 = fsub <8 x float> %.spill.load1472, %7574
  %.spill.load1473 = load <8 x float>, ptr %.spill210, align 32
  %7674 = fsub <8 x float> %.spill.load1473, %7574
  %.spill.load1474 = load <8 x float>, ptr %.spill211, align 32
  %7675 = fsub <8 x float> %.spill.load1474, %7574
  %.spill.load1475 = load <8 x float>, ptr %.spill212, align 32
  %7676 = fsub <8 x float> %.spill.load1475, %7574
  %.spill.load1476 = load <8 x float>, ptr %.spill213, align 32
  %7677 = fsub <8 x float> %.spill.load1476, %7574
  %.spill.load1477 = load <8 x float>, ptr %.spill214, align 32
  %7678 = fsub <8 x float> %.spill.load1477, %7574
  %.spill.load1478 = load <8 x float>, ptr %.spill215, align 32
  %7679 = fsub <8 x float> %.spill.load1478, %7577
  %.spill.load1479 = load <8 x float>, ptr %.spill216, align 32
  %7680 = fsub <8 x float> %.spill.load1479, %7577
  %.spill.load1480 = load <8 x float>, ptr %.spill217, align 32
  %7681 = fsub <8 x float> %.spill.load1480, %7577
  %.spill.load1481 = load <8 x float>, ptr %.spill218, align 32
  %7682 = fsub <8 x float> %.spill.load1481, %7577
  %.spill.load1482 = load <8 x float>, ptr %.spill219, align 32
  %7683 = fsub <8 x float> %.spill.load1482, %7577
  %.spill.load1483 = load <8 x float>, ptr %.spill220, align 32
  %7684 = fsub <8 x float> %.spill.load1483, %7577
  %.spill.load1484 = load <8 x float>, ptr %.spill221, align 32
  %7685 = fsub <8 x float> %.spill.load1484, %7577
  %.spill.load1485 = load <8 x float>, ptr %.spill222, align 32
  %7686 = fsub <8 x float> %.spill.load1485, %7577
  %.spill.load1486 = load <8 x float>, ptr %.spill223, align 32
  %7687 = fsub <8 x float> %.spill.load1486, %7577
  %.spill.load1487 = load <8 x float>, ptr %.spill224, align 32
  %7688 = fsub <8 x float> %.spill.load1487, %7577
  %.spill.load1488 = load <8 x float>, ptr %.spill225, align 32
  %7689 = fsub <8 x float> %.spill.load1488, %7577
  %.spill.load1489 = load <8 x float>, ptr %.spill226, align 32
  %7690 = fsub <8 x float> %.spill.load1489, %7577
  %.spill.load1490 = load <8 x float>, ptr %.spill227, align 32
  %7691 = fsub <8 x float> %.spill.load1490, %7577
  %.spill.load1491 = load <8 x float>, ptr %.spill228, align 32
  %7692 = fsub <8 x float> %.spill.load1491, %7577
  %.spill.load1492 = load <8 x float>, ptr %.spill229, align 32
  %7693 = fsub <8 x float> %.spill.load1492, %7577
  %.spill.load1493 = load <8 x float>, ptr %.spill230, align 32
  %7694 = fsub <8 x float> %.spill.load1493, %7577
  %.spill.load1494 = load <8 x float>, ptr %.spill231, align 32
  %7695 = fsub <8 x float> %.spill.load1494, %7580
  %.spill.load1495 = load <8 x float>, ptr %.spill232, align 32
  %7696 = fsub <8 x float> %.spill.load1495, %7580
  %.spill.load1496 = load <8 x float>, ptr %.spill233, align 32
  %7697 = fsub <8 x float> %.spill.load1496, %7580
  %.spill.load1497 = load <8 x float>, ptr %.spill234, align 32
  %7698 = fsub <8 x float> %.spill.load1497, %7580
  %.spill.load1498 = load <8 x float>, ptr %.spill235, align 32
  %7699 = fsub <8 x float> %.spill.load1498, %7580
  %.spill.load1499 = load <8 x float>, ptr %.spill236, align 32
  %7700 = fsub <8 x float> %.spill.load1499, %7580
  %.spill.load1500 = load <8 x float>, ptr %.spill237, align 32
  %7701 = fsub <8 x float> %.spill.load1500, %7580
  %.spill.load1501 = load <8 x float>, ptr %.spill238, align 32
  %7702 = fsub <8 x float> %.spill.load1501, %7580
  %.spill.load1502 = load <8 x float>, ptr %.spill239, align 32
  %7703 = fsub <8 x float> %.spill.load1502, %7580
  %.spill.load1503 = load <8 x float>, ptr %.spill240, align 32
  %7704 = fsub <8 x float> %.spill.load1503, %7580
  %.spill.load1504 = load <8 x float>, ptr %.spill241, align 32
  %7705 = fsub <8 x float> %.spill.load1504, %7580
  %.spill.load1505 = load <8 x float>, ptr %.spill242, align 32
  %7706 = fsub <8 x float> %.spill.load1505, %7580
  %.spill.load1506 = load <8 x float>, ptr %.spill243, align 32
  %7707 = fsub <8 x float> %.spill.load1506, %7580
  %.spill.load1507 = load <8 x float>, ptr %.spill244, align 32
  %7708 = fsub <8 x float> %.spill.load1507, %7580
  %.spill.load1508 = load <8 x float>, ptr %.spill245, align 32
  %7709 = fsub <8 x float> %.spill.load1508, %7580
  %.spill.load1509 = load <8 x float>, ptr %.spill246, align 32
  %7710 = fsub <8 x float> %.spill.load1509, %7580
  %.spill.load1510 = load <8 x float>, ptr %.spill247, align 32
  %7711 = fsub <8 x float> %.spill.load1510, %7583
  %.spill.load1511 = load <8 x float>, ptr %.spill248, align 32
  %7712 = fsub <8 x float> %.spill.load1511, %7583
  %.spill.load1512 = load <8 x float>, ptr %.spill249, align 32
  %7713 = fsub <8 x float> %.spill.load1512, %7583
  %.spill.load1513 = load <8 x float>, ptr %.spill250, align 32
  %7714 = fsub <8 x float> %.spill.load1513, %7583
  %.spill.load1514 = load <8 x float>, ptr %.spill251, align 32
  %7715 = fsub <8 x float> %.spill.load1514, %7583
  %.spill.load1515 = load <8 x float>, ptr %.spill252, align 32
  %7716 = fsub <8 x float> %.spill.load1515, %7583
  %.spill.load1516 = load <8 x float>, ptr %.spill253, align 32
  %7717 = fsub <8 x float> %.spill.load1516, %7583
  %.spill.load1517 = load <8 x float>, ptr %.spill254, align 32
  %7718 = fsub <8 x float> %.spill.load1517, %7583
  %.spill.load1518 = load <8 x float>, ptr %.spill255, align 32
  %7719 = fsub <8 x float> %.spill.load1518, %7583
  %.spill.load1519 = load <8 x float>, ptr %.spill256, align 32
  %7720 = fsub <8 x float> %.spill.load1519, %7583
  %.spill.load1520 = load <8 x float>, ptr %.spill257, align 32
  %7721 = fsub <8 x float> %.spill.load1520, %7583
  %.spill.load1521 = load <8 x float>, ptr %.spill258, align 32
  %7722 = fsub <8 x float> %.spill.load1521, %7583
  %.spill.load1522 = load <8 x float>, ptr %.spill259, align 32
  %7723 = fsub <8 x float> %.spill.load1522, %7583
  %.spill.load1523 = load <8 x float>, ptr %.spill260, align 32
  %7724 = fsub <8 x float> %.spill.load1523, %7583
  %.spill.load1524 = load <8 x float>, ptr %.spill261, align 32
  %7725 = fsub <8 x float> %.spill.load1524, %7583
  %.spill.load1525 = load <8 x float>, ptr %.spill262, align 32
  %7726 = fsub <8 x float> %.spill.load1525, %7583
  %7727 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7663, <8 x float> zeroinitializer
  %native.exp1526 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7727)
  %7728 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7664, <8 x float> zeroinitializer
  %native.exp1527 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7728)
  %7729 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7665, <8 x float> zeroinitializer
  %native.exp1528 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7729)
  %7730 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7666, <8 x float> zeroinitializer
  %native.exp1529 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7730)
  %7731 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7667, <8 x float> zeroinitializer
  %native.exp1530 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7731)
  %7732 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7668, <8 x float> zeroinitializer
  %native.exp1531 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7732)
  %7733 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7669, <8 x float> zeroinitializer
  %native.exp1532 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7733)
  %7734 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7670, <8 x float> zeroinitializer
  %native.exp1533 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7734)
  %7735 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7671, <8 x float> zeroinitializer
  %native.exp1534 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7735)
  %7736 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7672, <8 x float> zeroinitializer
  %native.exp1535 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7736)
  %7737 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7673, <8 x float> zeroinitializer
  %native.exp1536 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7737)
  %7738 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7674, <8 x float> zeroinitializer
  %native.exp1537 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7738)
  %7739 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7675, <8 x float> zeroinitializer
  %native.exp1538 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7739)
  %7740 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7676, <8 x float> zeroinitializer
  %native.exp1539 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7740)
  %7741 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7677, <8 x float> zeroinitializer
  %native.exp1540 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7741)
  %7742 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7678, <8 x float> zeroinitializer
  %native.exp1541 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7742)
  %7743 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7679, <8 x float> zeroinitializer
  %native.exp1542 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7743)
  %7744 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7680, <8 x float> zeroinitializer
  %native.exp1543 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7744)
  %7745 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7681, <8 x float> zeroinitializer
  %native.exp1544 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7745)
  %7746 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7682, <8 x float> zeroinitializer
  %native.exp1545 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7746)
  %7747 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7683, <8 x float> zeroinitializer
  %native.exp1546 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7747)
  %7748 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7684, <8 x float> zeroinitializer
  %native.exp1547 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7748)
  %7749 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7685, <8 x float> zeroinitializer
  %native.exp1548 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7749)
  %7750 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7686, <8 x float> zeroinitializer
  %native.exp1549 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7750)
  %7751 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7687, <8 x float> zeroinitializer
  %native.exp1550 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7751)
  %7752 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7688, <8 x float> zeroinitializer
  %native.exp1551 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7752)
  %7753 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7689, <8 x float> zeroinitializer
  %native.exp1552 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7753)
  %7754 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7690, <8 x float> zeroinitializer
  %native.exp1553 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7754)
  %7755 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7691, <8 x float> zeroinitializer
  %native.exp1554 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7755)
  %7756 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7692, <8 x float> zeroinitializer
  %native.exp1555 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7756)
  %7757 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7693, <8 x float> zeroinitializer
  %native.exp1556 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7757)
  %7758 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7694, <8 x float> zeroinitializer
  %native.exp1557 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7758)
  %7759 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7695, <8 x float> zeroinitializer
  %native.exp1558 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7759)
  %7760 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7696, <8 x float> zeroinitializer
  %native.exp1559 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7760)
  %7761 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7697, <8 x float> zeroinitializer
  %native.exp1560 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7761)
  %7762 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7698, <8 x float> zeroinitializer
  %native.exp1561 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7762)
  %7763 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7699, <8 x float> zeroinitializer
  %native.exp1562 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7763)
  %7764 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7700, <8 x float> zeroinitializer
  %native.exp1563 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7764)
  %7765 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7701, <8 x float> zeroinitializer
  %native.exp1564 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7765)
  %7766 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7702, <8 x float> zeroinitializer
  %native.exp1565 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7766)
  %7767 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7703, <8 x float> zeroinitializer
  %native.exp1566 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7767)
  %7768 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7704, <8 x float> zeroinitializer
  %native.exp1567 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7768)
  %7769 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7705, <8 x float> zeroinitializer
  %native.exp1568 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7769)
  %7770 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7706, <8 x float> zeroinitializer
  %native.exp1569 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7770)
  %7771 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7707, <8 x float> zeroinitializer
  %native.exp1570 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7771)
  %7772 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7708, <8 x float> zeroinitializer
  %native.exp1571 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7772)
  %7773 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7709, <8 x float> zeroinitializer
  %native.exp1572 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7773)
  %7774 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7710, <8 x float> zeroinitializer
  %native.exp1573 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7774)
  %7775 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7711, <8 x float> zeroinitializer
  %native.exp1574 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7775)
  %7776 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7712, <8 x float> zeroinitializer
  %native.exp1575 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7776)
  %7777 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7713, <8 x float> zeroinitializer
  %native.exp1576 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7777)
  %7778 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7714, <8 x float> zeroinitializer
  %native.exp1577 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7778)
  %7779 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7715, <8 x float> zeroinitializer
  %native.exp1578 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7779)
  %7780 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7716, <8 x float> zeroinitializer
  %native.exp1579 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7780)
  %7781 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7717, <8 x float> zeroinitializer
  %native.exp1580 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7781)
  %7782 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7718, <8 x float> zeroinitializer
  %native.exp1581 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7782)
  %7783 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7719, <8 x float> zeroinitializer
  %native.exp1582 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7783)
  %7784 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7720, <8 x float> zeroinitializer
  %native.exp1583 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7784)
  %7785 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7721, <8 x float> zeroinitializer
  %native.exp1584 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7785)
  %7786 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7722, <8 x float> zeroinitializer
  %native.exp1585 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7786)
  %7787 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7723, <8 x float> zeroinitializer
  %native.exp1586 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7787)
  %7788 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7724, <8 x float> zeroinitializer
  %native.exp1587 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7788)
  %7789 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7725, <8 x float> zeroinitializer
  %native.exp1588 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7789)
  %7790 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7726, <8 x float> zeroinitializer
  %native.exp1589 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %7790)
  %.spill.load1590 = load <8 x i1>, ptr %.spill135, align 1
  %7791 = select <8 x i1> %.spill.load1590, <8 x float> %native.exp1526, <8 x float> zeroinitializer
  %.spill.load1591 = load <8 x i1>, ptr %.spill139, align 1
  %7792 = select <8 x i1> %.spill.load1591, <8 x float> %native.exp1527, <8 x float> zeroinitializer
  %.spill.load1592 = load <8 x i1>, ptr %.spill143, align 1
  %7793 = select <8 x i1> %.spill.load1592, <8 x float> %native.exp1528, <8 x float> zeroinitializer
  %.spill.load1593 = load <8 x i1>, ptr %.spill147, align 1
  %7794 = select <8 x i1> %.spill.load1593, <8 x float> %native.exp1529, <8 x float> zeroinitializer
  %.spill.load1594 = load <8 x i1>, ptr %.spill151, align 1
  %7795 = select <8 x i1> %.spill.load1594, <8 x float> %native.exp1530, <8 x float> zeroinitializer
  %.spill.load1595 = load <8 x i1>, ptr %.spill155, align 1
  %7796 = select <8 x i1> %.spill.load1595, <8 x float> %native.exp1531, <8 x float> zeroinitializer
  %.spill.load1596 = load <8 x i1>, ptr %.spill159, align 1
  %7797 = select <8 x i1> %.spill.load1596, <8 x float> %native.exp1532, <8 x float> zeroinitializer
  %.spill.load1597 = load <8 x i1>, ptr %.spill163, align 1
  %7798 = select <8 x i1> %.spill.load1597, <8 x float> %native.exp1533, <8 x float> zeroinitializer
  %.spill.load1598 = load <8 x i1>, ptr %.spill167, align 1
  %7799 = select <8 x i1> %.spill.load1598, <8 x float> %native.exp1534, <8 x float> zeroinitializer
  %.spill.load1599 = load <8 x i1>, ptr %.spill171, align 1
  %7800 = select <8 x i1> %.spill.load1599, <8 x float> %native.exp1535, <8 x float> zeroinitializer
  %.spill.load1600 = load <8 x i1>, ptr %.spill175, align 1
  %7801 = select <8 x i1> %.spill.load1600, <8 x float> %native.exp1536, <8 x float> zeroinitializer
  %.spill.load1601 = load <8 x i1>, ptr %.spill179, align 1
  %7802 = select <8 x i1> %.spill.load1601, <8 x float> %native.exp1537, <8 x float> zeroinitializer
  %.spill.load1602 = load <8 x i1>, ptr %.spill183, align 1
  %7803 = select <8 x i1> %.spill.load1602, <8 x float> %native.exp1538, <8 x float> zeroinitializer
  %.spill.load1603 = load <8 x i1>, ptr %.spill187, align 1
  %7804 = select <8 x i1> %.spill.load1603, <8 x float> %native.exp1539, <8 x float> zeroinitializer
  %.spill.load1604 = load <8 x i1>, ptr %.spill191, align 1
  %7805 = select <8 x i1> %.spill.load1604, <8 x float> %native.exp1540, <8 x float> zeroinitializer
  %.spill.load1605 = load <8 x i1>, ptr %.spill195, align 1
  %7806 = select <8 x i1> %.spill.load1605, <8 x float> %native.exp1541, <8 x float> zeroinitializer
  %.spill.load1606 = load <8 x i1>, ptr %.spill136, align 1
  %7807 = select <8 x i1> %.spill.load1606, <8 x float> %native.exp1542, <8 x float> zeroinitializer
  %.spill.load1607 = load <8 x i1>, ptr %.spill140, align 1
  %7808 = select <8 x i1> %.spill.load1607, <8 x float> %native.exp1543, <8 x float> zeroinitializer
  %.spill.load1608 = load <8 x i1>, ptr %.spill144, align 1
  %7809 = select <8 x i1> %.spill.load1608, <8 x float> %native.exp1544, <8 x float> zeroinitializer
  %.spill.load1609 = load <8 x i1>, ptr %.spill148, align 1
  %7810 = select <8 x i1> %.spill.load1609, <8 x float> %native.exp1545, <8 x float> zeroinitializer
  %.spill.load1610 = load <8 x i1>, ptr %.spill152, align 1
  %7811 = select <8 x i1> %.spill.load1610, <8 x float> %native.exp1546, <8 x float> zeroinitializer
  %.spill.load1611 = load <8 x i1>, ptr %.spill156, align 1
  %7812 = select <8 x i1> %.spill.load1611, <8 x float> %native.exp1547, <8 x float> zeroinitializer
  %.spill.load1612 = load <8 x i1>, ptr %.spill160, align 1
  %7813 = select <8 x i1> %.spill.load1612, <8 x float> %native.exp1548, <8 x float> zeroinitializer
  %.spill.load1613 = load <8 x i1>, ptr %.spill164, align 1
  %7814 = select <8 x i1> %.spill.load1613, <8 x float> %native.exp1549, <8 x float> zeroinitializer
  %.spill.load1614 = load <8 x i1>, ptr %.spill168, align 1
  %7815 = select <8 x i1> %.spill.load1614, <8 x float> %native.exp1550, <8 x float> zeroinitializer
  %.spill.load1615 = load <8 x i1>, ptr %.spill172, align 1
  %7816 = select <8 x i1> %.spill.load1615, <8 x float> %native.exp1551, <8 x float> zeroinitializer
  %.spill.load1616 = load <8 x i1>, ptr %.spill176, align 1
  %7817 = select <8 x i1> %.spill.load1616, <8 x float> %native.exp1552, <8 x float> zeroinitializer
  %.spill.load1617 = load <8 x i1>, ptr %.spill180, align 1
  %7818 = select <8 x i1> %.spill.load1617, <8 x float> %native.exp1553, <8 x float> zeroinitializer
  %.spill.load1618 = load <8 x i1>, ptr %.spill184, align 1
  %7819 = select <8 x i1> %.spill.load1618, <8 x float> %native.exp1554, <8 x float> zeroinitializer
  %.spill.load1619 = load <8 x i1>, ptr %.spill188, align 1
  %7820 = select <8 x i1> %.spill.load1619, <8 x float> %native.exp1555, <8 x float> zeroinitializer
  %.spill.load1620 = load <8 x i1>, ptr %.spill192, align 1
  %7821 = select <8 x i1> %.spill.load1620, <8 x float> %native.exp1556, <8 x float> zeroinitializer
  %.spill.load1621 = load <8 x i1>, ptr %.spill196, align 1
  %7822 = select <8 x i1> %.spill.load1621, <8 x float> %native.exp1557, <8 x float> zeroinitializer
  %.spill.load1622 = load <8 x i1>, ptr %.spill137, align 1
  %7823 = select <8 x i1> %.spill.load1622, <8 x float> %native.exp1558, <8 x float> zeroinitializer
  %.spill.load1623 = load <8 x i1>, ptr %.spill141, align 1
  %7824 = select <8 x i1> %.spill.load1623, <8 x float> %native.exp1559, <8 x float> zeroinitializer
  %.spill.load1624 = load <8 x i1>, ptr %.spill145, align 1
  %7825 = select <8 x i1> %.spill.load1624, <8 x float> %native.exp1560, <8 x float> zeroinitializer
  %.spill.load1625 = load <8 x i1>, ptr %.spill149, align 1
  %7826 = select <8 x i1> %.spill.load1625, <8 x float> %native.exp1561, <8 x float> zeroinitializer
  %.spill.load1626 = load <8 x i1>, ptr %.spill153, align 1
  %7827 = select <8 x i1> %.spill.load1626, <8 x float> %native.exp1562, <8 x float> zeroinitializer
  %.spill.load1627 = load <8 x i1>, ptr %.spill157, align 1
  %7828 = select <8 x i1> %.spill.load1627, <8 x float> %native.exp1563, <8 x float> zeroinitializer
  %.spill.load1628 = load <8 x i1>, ptr %.spill161, align 1
  %7829 = select <8 x i1> %.spill.load1628, <8 x float> %native.exp1564, <8 x float> zeroinitializer
  %.spill.load1629 = load <8 x i1>, ptr %.spill165, align 1
  %7830 = select <8 x i1> %.spill.load1629, <8 x float> %native.exp1565, <8 x float> zeroinitializer
  %.spill.load1630 = load <8 x i1>, ptr %.spill169, align 1
  %7831 = select <8 x i1> %.spill.load1630, <8 x float> %native.exp1566, <8 x float> zeroinitializer
  %.spill.load1631 = load <8 x i1>, ptr %.spill173, align 1
  %7832 = select <8 x i1> %.spill.load1631, <8 x float> %native.exp1567, <8 x float> zeroinitializer
  %.spill.load1632 = load <8 x i1>, ptr %.spill177, align 1
  %7833 = select <8 x i1> %.spill.load1632, <8 x float> %native.exp1568, <8 x float> zeroinitializer
  %.spill.load1633 = load <8 x i1>, ptr %.spill181, align 1
  %7834 = select <8 x i1> %.spill.load1633, <8 x float> %native.exp1569, <8 x float> zeroinitializer
  %.spill.load1634 = load <8 x i1>, ptr %.spill185, align 1
  %7835 = select <8 x i1> %.spill.load1634, <8 x float> %native.exp1570, <8 x float> zeroinitializer
  %.spill.load1635 = load <8 x i1>, ptr %.spill189, align 1
  %7836 = select <8 x i1> %.spill.load1635, <8 x float> %native.exp1571, <8 x float> zeroinitializer
  %.spill.load1636 = load <8 x i1>, ptr %.spill193, align 1
  %7837 = select <8 x i1> %.spill.load1636, <8 x float> %native.exp1572, <8 x float> zeroinitializer
  %.spill.load1637 = load <8 x i1>, ptr %.spill197, align 1
  %7838 = select <8 x i1> %.spill.load1637, <8 x float> %native.exp1573, <8 x float> zeroinitializer
  %.spill.load1638 = load <8 x i1>, ptr %.spill138, align 1
  %7839 = select <8 x i1> %.spill.load1638, <8 x float> %native.exp1574, <8 x float> zeroinitializer
  %.spill.load1639 = load <8 x i1>, ptr %.spill142, align 1
  %7840 = select <8 x i1> %.spill.load1639, <8 x float> %native.exp1575, <8 x float> zeroinitializer
  %.spill.load1640 = load <8 x i1>, ptr %.spill146, align 1
  %7841 = select <8 x i1> %.spill.load1640, <8 x float> %native.exp1576, <8 x float> zeroinitializer
  %.spill.load1641 = load <8 x i1>, ptr %.spill150, align 1
  %7842 = select <8 x i1> %.spill.load1641, <8 x float> %native.exp1577, <8 x float> zeroinitializer
  %.spill.load1642 = load <8 x i1>, ptr %.spill154, align 1
  %7843 = select <8 x i1> %.spill.load1642, <8 x float> %native.exp1578, <8 x float> zeroinitializer
  %.spill.load1643 = load <8 x i1>, ptr %.spill158, align 1
  %7844 = select <8 x i1> %.spill.load1643, <8 x float> %native.exp1579, <8 x float> zeroinitializer
  %.spill.load1644 = load <8 x i1>, ptr %.spill162, align 1
  %7845 = select <8 x i1> %.spill.load1644, <8 x float> %native.exp1580, <8 x float> zeroinitializer
  %.spill.load1645 = load <8 x i1>, ptr %.spill166, align 1
  %7846 = select <8 x i1> %.spill.load1645, <8 x float> %native.exp1581, <8 x float> zeroinitializer
  %.spill.load1646 = load <8 x i1>, ptr %.spill170, align 1
  %7847 = select <8 x i1> %.spill.load1646, <8 x float> %native.exp1582, <8 x float> zeroinitializer
  %.spill.load1647 = load <8 x i1>, ptr %.spill174, align 1
  %7848 = select <8 x i1> %.spill.load1647, <8 x float> %native.exp1583, <8 x float> zeroinitializer
  %.spill.load1648 = load <8 x i1>, ptr %.spill178, align 1
  %7849 = select <8 x i1> %.spill.load1648, <8 x float> %native.exp1584, <8 x float> zeroinitializer
  %.spill.load1649 = load <8 x i1>, ptr %.spill182, align 1
  %7850 = select <8 x i1> %.spill.load1649, <8 x float> %native.exp1585, <8 x float> zeroinitializer
  %.spill.load1650 = load <8 x i1>, ptr %.spill186, align 1
  %7851 = select <8 x i1> %.spill.load1650, <8 x float> %native.exp1586, <8 x float> zeroinitializer
  %.spill.load1651 = load <8 x i1>, ptr %.spill190, align 1
  %7852 = select <8 x i1> %.spill.load1651, <8 x float> %native.exp1587, <8 x float> zeroinitializer
  %.spill.load1652 = load <8 x i1>, ptr %.spill194, align 1
  %7853 = select <8 x i1> %.spill.load1652, <8 x float> %native.exp1588, <8 x float> zeroinitializer
  %.spill.load1653 = load <8 x i1>, ptr %.spill198, align 1
  %7854 = select <8 x i1> %.spill.load1653, <8 x float> %native.exp1589, <8 x float> zeroinitializer
  %7855 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill277, align 64
  %7856 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7857 = extractvalue { <8 x ptr>, <8 x i64> } %7855, 0
  %7858 = select <8 x i1> %convergence.cascade.result1438, <8 x ptr> %7856, <8 x ptr> %7857
  %7859 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %7860 = extractvalue { <8 x ptr>, <8 x i64> } %7855, 1
  %7861 = select <8 x i1> %convergence.cascade.result1438, <8 x i64> %7859, <8 x i64> %7860
  %7862 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7858, 0
  %7863 = insertvalue { <8 x ptr>, <8 x i64> } %7862, <8 x i64> %7861, 1
  store { <8 x ptr>, <8 x i64> } %7863, ptr %tile_snapshot.spill277, align 64
  %7864 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7865 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %7866 = add <8 x i64> %7865, zeroinitializer
  %7867 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7864, 0
  %7868 = insertvalue { <8 x ptr>, <8 x i64> } %7867, <8 x i64> %7866, 1
  %7869 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7870 = extractvalue { <8 x ptr>, <8 x i64> } %7868, 1
  %7871 = extractelement <8 x ptr> %7869, i32 0
  %7872 = extractelement <8 x i64> %7870, i32 %7573
  %7873 = zext i32 %7573 to i64
  %7874 = mul i64 %7873, 4
  %7875 = sub i64 %7872, %7874
  %7876 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7877 = select i1 %7876, i64 %7875, i64 0
  %private.contiguous.address1654 = getelementptr i8, ptr %7871, i64 %7877
  %private.contiguous.preserve1655 = load <8 x float>, ptr %private.contiguous.address1654, align 4
  %7878 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7791, <8 x float> %private.contiguous.preserve1655
  store <8 x float> %7878, ptr %private.contiguous.address1654, align 4
  %7879 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7880 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %7881 = add <8 x i64> %7880, splat (i64 32)
  %7882 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7879, 0
  %7883 = insertvalue { <8 x ptr>, <8 x i64> } %7882, <8 x i64> %7881, 1
  %7884 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7885 = extractvalue { <8 x ptr>, <8 x i64> } %7883, 1
  %7886 = extractelement <8 x ptr> %7884, i32 0
  %7887 = extractelement <8 x i64> %7885, i32 %7573
  %7888 = zext i32 %7573 to i64
  %7889 = mul i64 %7888, 4
  %7890 = sub i64 %7887, %7889
  %7891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7892 = select i1 %7891, i64 %7890, i64 0
  %private.contiguous.address1656 = getelementptr i8, ptr %7886, i64 %7892
  %private.contiguous.preserve1657 = load <8 x float>, ptr %private.contiguous.address1656, align 4
  %7893 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7792, <8 x float> %private.contiguous.preserve1657
  store <8 x float> %7893, ptr %private.contiguous.address1656, align 4
  %7894 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7895 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %7896 = add <8 x i64> %7895, splat (i64 64)
  %7897 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7894, 0
  %7898 = insertvalue { <8 x ptr>, <8 x i64> } %7897, <8 x i64> %7896, 1
  %7899 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7900 = extractvalue { <8 x ptr>, <8 x i64> } %7898, 1
  %7901 = extractelement <8 x ptr> %7899, i32 0
  %7902 = extractelement <8 x i64> %7900, i32 %7573
  %7903 = zext i32 %7573 to i64
  %7904 = mul i64 %7903, 4
  %7905 = sub i64 %7902, %7904
  %7906 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7907 = select i1 %7906, i64 %7905, i64 0
  %private.contiguous.address1658 = getelementptr i8, ptr %7901, i64 %7907
  %private.contiguous.preserve1659 = load <8 x float>, ptr %private.contiguous.address1658, align 4
  %7908 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7793, <8 x float> %private.contiguous.preserve1659
  store <8 x float> %7908, ptr %private.contiguous.address1658, align 4
  %7909 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7910 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %7911 = add <8 x i64> %7910, splat (i64 96)
  %7912 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7909, 0
  %7913 = insertvalue { <8 x ptr>, <8 x i64> } %7912, <8 x i64> %7911, 1
  %7914 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7915 = extractvalue { <8 x ptr>, <8 x i64> } %7913, 1
  %7916 = extractelement <8 x ptr> %7914, i32 0
  %7917 = extractelement <8 x i64> %7915, i32 %7573
  %7918 = zext i32 %7573 to i64
  %7919 = mul i64 %7918, 4
  %7920 = sub i64 %7917, %7919
  %7921 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7922 = select i1 %7921, i64 %7920, i64 0
  %private.contiguous.address1660 = getelementptr i8, ptr %7916, i64 %7922
  %private.contiguous.preserve1661 = load <8 x float>, ptr %private.contiguous.address1660, align 4
  %7923 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7794, <8 x float> %private.contiguous.preserve1661
  store <8 x float> %7923, ptr %private.contiguous.address1660, align 4
  %7924 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7925 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %7926 = add <8 x i64> %7925, splat (i64 128)
  %7927 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7924, 0
  %7928 = insertvalue { <8 x ptr>, <8 x i64> } %7927, <8 x i64> %7926, 1
  %7929 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7930 = extractvalue { <8 x ptr>, <8 x i64> } %7928, 1
  %7931 = extractelement <8 x ptr> %7929, i32 0
  %7932 = extractelement <8 x i64> %7930, i32 %7573
  %7933 = zext i32 %7573 to i64
  %7934 = mul i64 %7933, 4
  %7935 = sub i64 %7932, %7934
  %7936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7937 = select i1 %7936, i64 %7935, i64 0
  %private.contiguous.address1662 = getelementptr i8, ptr %7931, i64 %7937
  %private.contiguous.preserve1663 = load <8 x float>, ptr %private.contiguous.address1662, align 4
  %7938 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7795, <8 x float> %private.contiguous.preserve1663
  store <8 x float> %7938, ptr %private.contiguous.address1662, align 4
  %7939 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7940 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %7941 = add <8 x i64> %7940, splat (i64 160)
  %7942 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7939, 0
  %7943 = insertvalue { <8 x ptr>, <8 x i64> } %7942, <8 x i64> %7941, 1
  %7944 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7945 = extractvalue { <8 x ptr>, <8 x i64> } %7943, 1
  %7946 = extractelement <8 x ptr> %7944, i32 0
  %7947 = extractelement <8 x i64> %7945, i32 %7573
  %7948 = zext i32 %7573 to i64
  %7949 = mul i64 %7948, 4
  %7950 = sub i64 %7947, %7949
  %7951 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7952 = select i1 %7951, i64 %7950, i64 0
  %private.contiguous.address1664 = getelementptr i8, ptr %7946, i64 %7952
  %private.contiguous.preserve1665 = load <8 x float>, ptr %private.contiguous.address1664, align 4
  %7953 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7796, <8 x float> %private.contiguous.preserve1665
  store <8 x float> %7953, ptr %private.contiguous.address1664, align 4
  %7954 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7955 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %7956 = add <8 x i64> %7955, splat (i64 192)
  %7957 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7954, 0
  %7958 = insertvalue { <8 x ptr>, <8 x i64> } %7957, <8 x i64> %7956, 1
  %7959 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7960 = extractvalue { <8 x ptr>, <8 x i64> } %7958, 1
  %7961 = extractelement <8 x ptr> %7959, i32 0
  %7962 = extractelement <8 x i64> %7960, i32 %7573
  %7963 = zext i32 %7573 to i64
  %7964 = mul i64 %7963, 4
  %7965 = sub i64 %7962, %7964
  %7966 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7967 = select i1 %7966, i64 %7965, i64 0
  %private.contiguous.address1666 = getelementptr i8, ptr %7961, i64 %7967
  %private.contiguous.preserve1667 = load <8 x float>, ptr %private.contiguous.address1666, align 4
  %7968 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7797, <8 x float> %private.contiguous.preserve1667
  store <8 x float> %7968, ptr %private.contiguous.address1666, align 4
  %7969 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7970 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %7971 = add <8 x i64> %7970, splat (i64 224)
  %7972 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7969, 0
  %7973 = insertvalue { <8 x ptr>, <8 x i64> } %7972, <8 x i64> %7971, 1
  %7974 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7975 = extractvalue { <8 x ptr>, <8 x i64> } %7973, 1
  %7976 = extractelement <8 x ptr> %7974, i32 0
  %7977 = extractelement <8 x i64> %7975, i32 %7573
  %7978 = zext i32 %7573 to i64
  %7979 = mul i64 %7978, 4
  %7980 = sub i64 %7977, %7979
  %7981 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7982 = select i1 %7981, i64 %7980, i64 0
  %private.contiguous.address1668 = getelementptr i8, ptr %7976, i64 %7982
  %private.contiguous.preserve1669 = load <8 x float>, ptr %private.contiguous.address1668, align 4
  %7983 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7798, <8 x float> %private.contiguous.preserve1669
  store <8 x float> %7983, ptr %private.contiguous.address1668, align 4
  %7984 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7985 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %7986 = add <8 x i64> %7985, splat (i64 256)
  %7987 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7984, 0
  %7988 = insertvalue { <8 x ptr>, <8 x i64> } %7987, <8 x i64> %7986, 1
  %7989 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %7990 = extractvalue { <8 x ptr>, <8 x i64> } %7988, 1
  %7991 = extractelement <8 x ptr> %7989, i32 0
  %7992 = extractelement <8 x i64> %7990, i32 %7573
  %7993 = zext i32 %7573 to i64
  %7994 = mul i64 %7993, 4
  %7995 = sub i64 %7992, %7994
  %7996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %7997 = select i1 %7996, i64 %7995, i64 0
  %private.contiguous.address1670 = getelementptr i8, ptr %7991, i64 %7997
  %private.contiguous.preserve1671 = load <8 x float>, ptr %private.contiguous.address1670, align 4
  %7998 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7799, <8 x float> %private.contiguous.preserve1671
  store <8 x float> %7998, ptr %private.contiguous.address1670, align 4
  %7999 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8000 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8001 = add <8 x i64> %8000, splat (i64 288)
  %8002 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %7999, 0
  %8003 = insertvalue { <8 x ptr>, <8 x i64> } %8002, <8 x i64> %8001, 1
  %8004 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8005 = extractvalue { <8 x ptr>, <8 x i64> } %8003, 1
  %8006 = extractelement <8 x ptr> %8004, i32 0
  %8007 = extractelement <8 x i64> %8005, i32 %7573
  %8008 = zext i32 %7573 to i64
  %8009 = mul i64 %8008, 4
  %8010 = sub i64 %8007, %8009
  %8011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8012 = select i1 %8011, i64 %8010, i64 0
  %private.contiguous.address1672 = getelementptr i8, ptr %8006, i64 %8012
  %private.contiguous.preserve1673 = load <8 x float>, ptr %private.contiguous.address1672, align 4
  %8013 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7800, <8 x float> %private.contiguous.preserve1673
  store <8 x float> %8013, ptr %private.contiguous.address1672, align 4
  %8014 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8015 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8016 = add <8 x i64> %8015, splat (i64 320)
  %8017 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8014, 0
  %8018 = insertvalue { <8 x ptr>, <8 x i64> } %8017, <8 x i64> %8016, 1
  %8019 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8020 = extractvalue { <8 x ptr>, <8 x i64> } %8018, 1
  %8021 = extractelement <8 x ptr> %8019, i32 0
  %8022 = extractelement <8 x i64> %8020, i32 %7573
  %8023 = zext i32 %7573 to i64
  %8024 = mul i64 %8023, 4
  %8025 = sub i64 %8022, %8024
  %8026 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8027 = select i1 %8026, i64 %8025, i64 0
  %private.contiguous.address1674 = getelementptr i8, ptr %8021, i64 %8027
  %private.contiguous.preserve1675 = load <8 x float>, ptr %private.contiguous.address1674, align 4
  %8028 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7801, <8 x float> %private.contiguous.preserve1675
  store <8 x float> %8028, ptr %private.contiguous.address1674, align 4
  %8029 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8030 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8031 = add <8 x i64> %8030, splat (i64 352)
  %8032 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8029, 0
  %8033 = insertvalue { <8 x ptr>, <8 x i64> } %8032, <8 x i64> %8031, 1
  %8034 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8035 = extractvalue { <8 x ptr>, <8 x i64> } %8033, 1
  %8036 = extractelement <8 x ptr> %8034, i32 0
  %8037 = extractelement <8 x i64> %8035, i32 %7573
  %8038 = zext i32 %7573 to i64
  %8039 = mul i64 %8038, 4
  %8040 = sub i64 %8037, %8039
  %8041 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8042 = select i1 %8041, i64 %8040, i64 0
  %private.contiguous.address1676 = getelementptr i8, ptr %8036, i64 %8042
  %private.contiguous.preserve1677 = load <8 x float>, ptr %private.contiguous.address1676, align 4
  %8043 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7802, <8 x float> %private.contiguous.preserve1677
  store <8 x float> %8043, ptr %private.contiguous.address1676, align 4
  %8044 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8045 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8046 = add <8 x i64> %8045, splat (i64 384)
  %8047 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8044, 0
  %8048 = insertvalue { <8 x ptr>, <8 x i64> } %8047, <8 x i64> %8046, 1
  %8049 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8050 = extractvalue { <8 x ptr>, <8 x i64> } %8048, 1
  %8051 = extractelement <8 x ptr> %8049, i32 0
  %8052 = extractelement <8 x i64> %8050, i32 %7573
  %8053 = zext i32 %7573 to i64
  %8054 = mul i64 %8053, 4
  %8055 = sub i64 %8052, %8054
  %8056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8057 = select i1 %8056, i64 %8055, i64 0
  %private.contiguous.address1678 = getelementptr i8, ptr %8051, i64 %8057
  %private.contiguous.preserve1679 = load <8 x float>, ptr %private.contiguous.address1678, align 4
  %8058 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7803, <8 x float> %private.contiguous.preserve1679
  store <8 x float> %8058, ptr %private.contiguous.address1678, align 4
  %8059 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8060 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8061 = add <8 x i64> %8060, splat (i64 416)
  %8062 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8059, 0
  %8063 = insertvalue { <8 x ptr>, <8 x i64> } %8062, <8 x i64> %8061, 1
  %8064 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8065 = extractvalue { <8 x ptr>, <8 x i64> } %8063, 1
  %8066 = extractelement <8 x ptr> %8064, i32 0
  %8067 = extractelement <8 x i64> %8065, i32 %7573
  %8068 = zext i32 %7573 to i64
  %8069 = mul i64 %8068, 4
  %8070 = sub i64 %8067, %8069
  %8071 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8072 = select i1 %8071, i64 %8070, i64 0
  %private.contiguous.address1680 = getelementptr i8, ptr %8066, i64 %8072
  %private.contiguous.preserve1681 = load <8 x float>, ptr %private.contiguous.address1680, align 4
  %8073 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7804, <8 x float> %private.contiguous.preserve1681
  store <8 x float> %8073, ptr %private.contiguous.address1680, align 4
  %8074 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8075 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8076 = add <8 x i64> %8075, splat (i64 448)
  %8077 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8074, 0
  %8078 = insertvalue { <8 x ptr>, <8 x i64> } %8077, <8 x i64> %8076, 1
  %8079 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8080 = extractvalue { <8 x ptr>, <8 x i64> } %8078, 1
  %8081 = extractelement <8 x ptr> %8079, i32 0
  %8082 = extractelement <8 x i64> %8080, i32 %7573
  %8083 = zext i32 %7573 to i64
  %8084 = mul i64 %8083, 4
  %8085 = sub i64 %8082, %8084
  %8086 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8087 = select i1 %8086, i64 %8085, i64 0
  %private.contiguous.address1682 = getelementptr i8, ptr %8081, i64 %8087
  %private.contiguous.preserve1683 = load <8 x float>, ptr %private.contiguous.address1682, align 4
  %8088 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7805, <8 x float> %private.contiguous.preserve1683
  store <8 x float> %8088, ptr %private.contiguous.address1682, align 4
  %8089 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8090 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8091 = add <8 x i64> %8090, splat (i64 480)
  %8092 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8089, 0
  %8093 = insertvalue { <8 x ptr>, <8 x i64> } %8092, <8 x i64> %8091, 1
  %8094 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8095 = extractvalue { <8 x ptr>, <8 x i64> } %8093, 1
  %8096 = extractelement <8 x ptr> %8094, i32 0
  %8097 = extractelement <8 x i64> %8095, i32 %7573
  %8098 = zext i32 %7573 to i64
  %8099 = mul i64 %8098, 4
  %8100 = sub i64 %8097, %8099
  %8101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8102 = select i1 %8101, i64 %8100, i64 0
  %private.contiguous.address1684 = getelementptr i8, ptr %8096, i64 %8102
  %private.contiguous.preserve1685 = load <8 x float>, ptr %private.contiguous.address1684, align 4
  %8103 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7806, <8 x float> %private.contiguous.preserve1685
  store <8 x float> %8103, ptr %private.contiguous.address1684, align 4
  %8104 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8105 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8106 = add <8 x i64> %8105, splat (i64 512)
  %8107 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8104, 0
  %8108 = insertvalue { <8 x ptr>, <8 x i64> } %8107, <8 x i64> %8106, 1
  %8109 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8110 = extractvalue { <8 x ptr>, <8 x i64> } %8108, 1
  %8111 = extractelement <8 x ptr> %8109, i32 0
  %8112 = extractelement <8 x i64> %8110, i32 %7573
  %8113 = zext i32 %7573 to i64
  %8114 = mul i64 %8113, 4
  %8115 = sub i64 %8112, %8114
  %8116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8117 = select i1 %8116, i64 %8115, i64 0
  %private.contiguous.address1686 = getelementptr i8, ptr %8111, i64 %8117
  %private.contiguous.preserve1687 = load <8 x float>, ptr %private.contiguous.address1686, align 4
  %8118 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7807, <8 x float> %private.contiguous.preserve1687
  store <8 x float> %8118, ptr %private.contiguous.address1686, align 4
  %8119 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8120 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8121 = add <8 x i64> %8120, splat (i64 544)
  %8122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8119, 0
  %8123 = insertvalue { <8 x ptr>, <8 x i64> } %8122, <8 x i64> %8121, 1
  %8124 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8125 = extractvalue { <8 x ptr>, <8 x i64> } %8123, 1
  %8126 = extractelement <8 x ptr> %8124, i32 0
  %8127 = extractelement <8 x i64> %8125, i32 %7573
  %8128 = zext i32 %7573 to i64
  %8129 = mul i64 %8128, 4
  %8130 = sub i64 %8127, %8129
  %8131 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8132 = select i1 %8131, i64 %8130, i64 0
  %private.contiguous.address1688 = getelementptr i8, ptr %8126, i64 %8132
  %private.contiguous.preserve1689 = load <8 x float>, ptr %private.contiguous.address1688, align 4
  %8133 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7808, <8 x float> %private.contiguous.preserve1689
  store <8 x float> %8133, ptr %private.contiguous.address1688, align 4
  %8134 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8135 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8136 = add <8 x i64> %8135, splat (i64 576)
  %8137 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8134, 0
  %8138 = insertvalue { <8 x ptr>, <8 x i64> } %8137, <8 x i64> %8136, 1
  %8139 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8140 = extractvalue { <8 x ptr>, <8 x i64> } %8138, 1
  %8141 = extractelement <8 x ptr> %8139, i32 0
  %8142 = extractelement <8 x i64> %8140, i32 %7573
  %8143 = zext i32 %7573 to i64
  %8144 = mul i64 %8143, 4
  %8145 = sub i64 %8142, %8144
  %8146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8147 = select i1 %8146, i64 %8145, i64 0
  %private.contiguous.address1690 = getelementptr i8, ptr %8141, i64 %8147
  %private.contiguous.preserve1691 = load <8 x float>, ptr %private.contiguous.address1690, align 4
  %8148 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7809, <8 x float> %private.contiguous.preserve1691
  store <8 x float> %8148, ptr %private.contiguous.address1690, align 4
  %8149 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8150 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8151 = add <8 x i64> %8150, splat (i64 608)
  %8152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8149, 0
  %8153 = insertvalue { <8 x ptr>, <8 x i64> } %8152, <8 x i64> %8151, 1
  %8154 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8155 = extractvalue { <8 x ptr>, <8 x i64> } %8153, 1
  %8156 = extractelement <8 x ptr> %8154, i32 0
  %8157 = extractelement <8 x i64> %8155, i32 %7573
  %8158 = zext i32 %7573 to i64
  %8159 = mul i64 %8158, 4
  %8160 = sub i64 %8157, %8159
  %8161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8162 = select i1 %8161, i64 %8160, i64 0
  %private.contiguous.address1692 = getelementptr i8, ptr %8156, i64 %8162
  %private.contiguous.preserve1693 = load <8 x float>, ptr %private.contiguous.address1692, align 4
  %8163 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7810, <8 x float> %private.contiguous.preserve1693
  store <8 x float> %8163, ptr %private.contiguous.address1692, align 4
  %8164 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8165 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8166 = add <8 x i64> %8165, splat (i64 640)
  %8167 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8164, 0
  %8168 = insertvalue { <8 x ptr>, <8 x i64> } %8167, <8 x i64> %8166, 1
  %8169 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8170 = extractvalue { <8 x ptr>, <8 x i64> } %8168, 1
  %8171 = extractelement <8 x ptr> %8169, i32 0
  %8172 = extractelement <8 x i64> %8170, i32 %7573
  %8173 = zext i32 %7573 to i64
  %8174 = mul i64 %8173, 4
  %8175 = sub i64 %8172, %8174
  %8176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8177 = select i1 %8176, i64 %8175, i64 0
  %private.contiguous.address1694 = getelementptr i8, ptr %8171, i64 %8177
  %private.contiguous.preserve1695 = load <8 x float>, ptr %private.contiguous.address1694, align 4
  %8178 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7811, <8 x float> %private.contiguous.preserve1695
  store <8 x float> %8178, ptr %private.contiguous.address1694, align 4
  %8179 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8180 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8181 = add <8 x i64> %8180, splat (i64 672)
  %8182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8179, 0
  %8183 = insertvalue { <8 x ptr>, <8 x i64> } %8182, <8 x i64> %8181, 1
  %8184 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8185 = extractvalue { <8 x ptr>, <8 x i64> } %8183, 1
  %8186 = extractelement <8 x ptr> %8184, i32 0
  %8187 = extractelement <8 x i64> %8185, i32 %7573
  %8188 = zext i32 %7573 to i64
  %8189 = mul i64 %8188, 4
  %8190 = sub i64 %8187, %8189
  %8191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8192 = select i1 %8191, i64 %8190, i64 0
  %private.contiguous.address1696 = getelementptr i8, ptr %8186, i64 %8192
  %private.contiguous.preserve1697 = load <8 x float>, ptr %private.contiguous.address1696, align 4
  %8193 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7812, <8 x float> %private.contiguous.preserve1697
  store <8 x float> %8193, ptr %private.contiguous.address1696, align 4
  %8194 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8195 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8196 = add <8 x i64> %8195, splat (i64 704)
  %8197 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8194, 0
  %8198 = insertvalue { <8 x ptr>, <8 x i64> } %8197, <8 x i64> %8196, 1
  %8199 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8200 = extractvalue { <8 x ptr>, <8 x i64> } %8198, 1
  %8201 = extractelement <8 x ptr> %8199, i32 0
  %8202 = extractelement <8 x i64> %8200, i32 %7573
  %8203 = zext i32 %7573 to i64
  %8204 = mul i64 %8203, 4
  %8205 = sub i64 %8202, %8204
  %8206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8207 = select i1 %8206, i64 %8205, i64 0
  %private.contiguous.address1698 = getelementptr i8, ptr %8201, i64 %8207
  %private.contiguous.preserve1699 = load <8 x float>, ptr %private.contiguous.address1698, align 4
  %8208 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7813, <8 x float> %private.contiguous.preserve1699
  store <8 x float> %8208, ptr %private.contiguous.address1698, align 4
  %8209 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8210 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8211 = add <8 x i64> %8210, splat (i64 736)
  %8212 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8209, 0
  %8213 = insertvalue { <8 x ptr>, <8 x i64> } %8212, <8 x i64> %8211, 1
  %8214 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8215 = extractvalue { <8 x ptr>, <8 x i64> } %8213, 1
  %8216 = extractelement <8 x ptr> %8214, i32 0
  %8217 = extractelement <8 x i64> %8215, i32 %7573
  %8218 = zext i32 %7573 to i64
  %8219 = mul i64 %8218, 4
  %8220 = sub i64 %8217, %8219
  %8221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8222 = select i1 %8221, i64 %8220, i64 0
  %private.contiguous.address1700 = getelementptr i8, ptr %8216, i64 %8222
  %private.contiguous.preserve1701 = load <8 x float>, ptr %private.contiguous.address1700, align 4
  %8223 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7814, <8 x float> %private.contiguous.preserve1701
  store <8 x float> %8223, ptr %private.contiguous.address1700, align 4
  %8224 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8225 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8226 = add <8 x i64> %8225, splat (i64 768)
  %8227 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8224, 0
  %8228 = insertvalue { <8 x ptr>, <8 x i64> } %8227, <8 x i64> %8226, 1
  %8229 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8230 = extractvalue { <8 x ptr>, <8 x i64> } %8228, 1
  %8231 = extractelement <8 x ptr> %8229, i32 0
  %8232 = extractelement <8 x i64> %8230, i32 %7573
  %8233 = zext i32 %7573 to i64
  %8234 = mul i64 %8233, 4
  %8235 = sub i64 %8232, %8234
  %8236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8237 = select i1 %8236, i64 %8235, i64 0
  %private.contiguous.address1702 = getelementptr i8, ptr %8231, i64 %8237
  %private.contiguous.preserve1703 = load <8 x float>, ptr %private.contiguous.address1702, align 4
  %8238 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7815, <8 x float> %private.contiguous.preserve1703
  store <8 x float> %8238, ptr %private.contiguous.address1702, align 4
  %8239 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8240 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8241 = add <8 x i64> %8240, splat (i64 800)
  %8242 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8239, 0
  %8243 = insertvalue { <8 x ptr>, <8 x i64> } %8242, <8 x i64> %8241, 1
  %8244 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8245 = extractvalue { <8 x ptr>, <8 x i64> } %8243, 1
  %8246 = extractelement <8 x ptr> %8244, i32 0
  %8247 = extractelement <8 x i64> %8245, i32 %7573
  %8248 = zext i32 %7573 to i64
  %8249 = mul i64 %8248, 4
  %8250 = sub i64 %8247, %8249
  %8251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8252 = select i1 %8251, i64 %8250, i64 0
  %private.contiguous.address1704 = getelementptr i8, ptr %8246, i64 %8252
  %private.contiguous.preserve1705 = load <8 x float>, ptr %private.contiguous.address1704, align 4
  %8253 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7816, <8 x float> %private.contiguous.preserve1705
  store <8 x float> %8253, ptr %private.contiguous.address1704, align 4
  %8254 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8255 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8256 = add <8 x i64> %8255, splat (i64 832)
  %8257 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8254, 0
  %8258 = insertvalue { <8 x ptr>, <8 x i64> } %8257, <8 x i64> %8256, 1
  %8259 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8260 = extractvalue { <8 x ptr>, <8 x i64> } %8258, 1
  %8261 = extractelement <8 x ptr> %8259, i32 0
  %8262 = extractelement <8 x i64> %8260, i32 %7573
  %8263 = zext i32 %7573 to i64
  %8264 = mul i64 %8263, 4
  %8265 = sub i64 %8262, %8264
  %8266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8267 = select i1 %8266, i64 %8265, i64 0
  %private.contiguous.address1706 = getelementptr i8, ptr %8261, i64 %8267
  %private.contiguous.preserve1707 = load <8 x float>, ptr %private.contiguous.address1706, align 4
  %8268 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7817, <8 x float> %private.contiguous.preserve1707
  store <8 x float> %8268, ptr %private.contiguous.address1706, align 4
  %8269 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8270 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8271 = add <8 x i64> %8270, splat (i64 864)
  %8272 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8269, 0
  %8273 = insertvalue { <8 x ptr>, <8 x i64> } %8272, <8 x i64> %8271, 1
  %8274 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8275 = extractvalue { <8 x ptr>, <8 x i64> } %8273, 1
  %8276 = extractelement <8 x ptr> %8274, i32 0
  %8277 = extractelement <8 x i64> %8275, i32 %7573
  %8278 = zext i32 %7573 to i64
  %8279 = mul i64 %8278, 4
  %8280 = sub i64 %8277, %8279
  %8281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8282 = select i1 %8281, i64 %8280, i64 0
  %private.contiguous.address1708 = getelementptr i8, ptr %8276, i64 %8282
  %private.contiguous.preserve1709 = load <8 x float>, ptr %private.contiguous.address1708, align 4
  %8283 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7818, <8 x float> %private.contiguous.preserve1709
  store <8 x float> %8283, ptr %private.contiguous.address1708, align 4
  %8284 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8285 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8286 = add <8 x i64> %8285, splat (i64 896)
  %8287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8284, 0
  %8288 = insertvalue { <8 x ptr>, <8 x i64> } %8287, <8 x i64> %8286, 1
  %8289 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8290 = extractvalue { <8 x ptr>, <8 x i64> } %8288, 1
  %8291 = extractelement <8 x ptr> %8289, i32 0
  %8292 = extractelement <8 x i64> %8290, i32 %7573
  %8293 = zext i32 %7573 to i64
  %8294 = mul i64 %8293, 4
  %8295 = sub i64 %8292, %8294
  %8296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8297 = select i1 %8296, i64 %8295, i64 0
  %private.contiguous.address1710 = getelementptr i8, ptr %8291, i64 %8297
  %private.contiguous.preserve1711 = load <8 x float>, ptr %private.contiguous.address1710, align 4
  %8298 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7819, <8 x float> %private.contiguous.preserve1711
  store <8 x float> %8298, ptr %private.contiguous.address1710, align 4
  %8299 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8300 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8301 = add <8 x i64> %8300, splat (i64 928)
  %8302 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8299, 0
  %8303 = insertvalue { <8 x ptr>, <8 x i64> } %8302, <8 x i64> %8301, 1
  %8304 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8305 = extractvalue { <8 x ptr>, <8 x i64> } %8303, 1
  %8306 = extractelement <8 x ptr> %8304, i32 0
  %8307 = extractelement <8 x i64> %8305, i32 %7573
  %8308 = zext i32 %7573 to i64
  %8309 = mul i64 %8308, 4
  %8310 = sub i64 %8307, %8309
  %8311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8312 = select i1 %8311, i64 %8310, i64 0
  %private.contiguous.address1712 = getelementptr i8, ptr %8306, i64 %8312
  %private.contiguous.preserve1713 = load <8 x float>, ptr %private.contiguous.address1712, align 4
  %8313 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7820, <8 x float> %private.contiguous.preserve1713
  store <8 x float> %8313, ptr %private.contiguous.address1712, align 4
  %8314 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8315 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8316 = add <8 x i64> %8315, splat (i64 960)
  %8317 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8314, 0
  %8318 = insertvalue { <8 x ptr>, <8 x i64> } %8317, <8 x i64> %8316, 1
  %8319 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8320 = extractvalue { <8 x ptr>, <8 x i64> } %8318, 1
  %8321 = extractelement <8 x ptr> %8319, i32 0
  %8322 = extractelement <8 x i64> %8320, i32 %7573
  %8323 = zext i32 %7573 to i64
  %8324 = mul i64 %8323, 4
  %8325 = sub i64 %8322, %8324
  %8326 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8327 = select i1 %8326, i64 %8325, i64 0
  %private.contiguous.address1714 = getelementptr i8, ptr %8321, i64 %8327
  %private.contiguous.preserve1715 = load <8 x float>, ptr %private.contiguous.address1714, align 4
  %8328 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7821, <8 x float> %private.contiguous.preserve1715
  store <8 x float> %8328, ptr %private.contiguous.address1714, align 4
  %8329 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8330 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8331 = add <8 x i64> %8330, splat (i64 992)
  %8332 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8329, 0
  %8333 = insertvalue { <8 x ptr>, <8 x i64> } %8332, <8 x i64> %8331, 1
  %8334 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8335 = extractvalue { <8 x ptr>, <8 x i64> } %8333, 1
  %8336 = extractelement <8 x ptr> %8334, i32 0
  %8337 = extractelement <8 x i64> %8335, i32 %7573
  %8338 = zext i32 %7573 to i64
  %8339 = mul i64 %8338, 4
  %8340 = sub i64 %8337, %8339
  %8341 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8342 = select i1 %8341, i64 %8340, i64 0
  %private.contiguous.address1716 = getelementptr i8, ptr %8336, i64 %8342
  %private.contiguous.preserve1717 = load <8 x float>, ptr %private.contiguous.address1716, align 4
  %8343 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7822, <8 x float> %private.contiguous.preserve1717
  store <8 x float> %8343, ptr %private.contiguous.address1716, align 4
  %8344 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8345 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8346 = add <8 x i64> %8345, splat (i64 1024)
  %8347 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8344, 0
  %8348 = insertvalue { <8 x ptr>, <8 x i64> } %8347, <8 x i64> %8346, 1
  %8349 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8350 = extractvalue { <8 x ptr>, <8 x i64> } %8348, 1
  %8351 = extractelement <8 x ptr> %8349, i32 0
  %8352 = extractelement <8 x i64> %8350, i32 %7573
  %8353 = zext i32 %7573 to i64
  %8354 = mul i64 %8353, 4
  %8355 = sub i64 %8352, %8354
  %8356 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8357 = select i1 %8356, i64 %8355, i64 0
  %private.contiguous.address1718 = getelementptr i8, ptr %8351, i64 %8357
  %private.contiguous.preserve1719 = load <8 x float>, ptr %private.contiguous.address1718, align 4
  %8358 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7823, <8 x float> %private.contiguous.preserve1719
  store <8 x float> %8358, ptr %private.contiguous.address1718, align 4
  %8359 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8360 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8361 = add <8 x i64> %8360, splat (i64 1056)
  %8362 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8359, 0
  %8363 = insertvalue { <8 x ptr>, <8 x i64> } %8362, <8 x i64> %8361, 1
  %8364 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8365 = extractvalue { <8 x ptr>, <8 x i64> } %8363, 1
  %8366 = extractelement <8 x ptr> %8364, i32 0
  %8367 = extractelement <8 x i64> %8365, i32 %7573
  %8368 = zext i32 %7573 to i64
  %8369 = mul i64 %8368, 4
  %8370 = sub i64 %8367, %8369
  %8371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8372 = select i1 %8371, i64 %8370, i64 0
  %private.contiguous.address1720 = getelementptr i8, ptr %8366, i64 %8372
  %private.contiguous.preserve1721 = load <8 x float>, ptr %private.contiguous.address1720, align 4
  %8373 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7824, <8 x float> %private.contiguous.preserve1721
  store <8 x float> %8373, ptr %private.contiguous.address1720, align 4
  %8374 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8375 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8376 = add <8 x i64> %8375, splat (i64 1088)
  %8377 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8374, 0
  %8378 = insertvalue { <8 x ptr>, <8 x i64> } %8377, <8 x i64> %8376, 1
  %8379 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8380 = extractvalue { <8 x ptr>, <8 x i64> } %8378, 1
  %8381 = extractelement <8 x ptr> %8379, i32 0
  %8382 = extractelement <8 x i64> %8380, i32 %7573
  %8383 = zext i32 %7573 to i64
  %8384 = mul i64 %8383, 4
  %8385 = sub i64 %8382, %8384
  %8386 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8387 = select i1 %8386, i64 %8385, i64 0
  %private.contiguous.address1722 = getelementptr i8, ptr %8381, i64 %8387
  %private.contiguous.preserve1723 = load <8 x float>, ptr %private.contiguous.address1722, align 4
  %8388 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7825, <8 x float> %private.contiguous.preserve1723
  store <8 x float> %8388, ptr %private.contiguous.address1722, align 4
  %8389 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8390 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8391 = add <8 x i64> %8390, splat (i64 1120)
  %8392 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8389, 0
  %8393 = insertvalue { <8 x ptr>, <8 x i64> } %8392, <8 x i64> %8391, 1
  %8394 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8395 = extractvalue { <8 x ptr>, <8 x i64> } %8393, 1
  %8396 = extractelement <8 x ptr> %8394, i32 0
  %8397 = extractelement <8 x i64> %8395, i32 %7573
  %8398 = zext i32 %7573 to i64
  %8399 = mul i64 %8398, 4
  %8400 = sub i64 %8397, %8399
  %8401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8402 = select i1 %8401, i64 %8400, i64 0
  %private.contiguous.address1724 = getelementptr i8, ptr %8396, i64 %8402
  %private.contiguous.preserve1725 = load <8 x float>, ptr %private.contiguous.address1724, align 4
  %8403 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7826, <8 x float> %private.contiguous.preserve1725
  store <8 x float> %8403, ptr %private.contiguous.address1724, align 4
  %8404 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8405 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8406 = add <8 x i64> %8405, splat (i64 1152)
  %8407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8404, 0
  %8408 = insertvalue { <8 x ptr>, <8 x i64> } %8407, <8 x i64> %8406, 1
  %8409 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8410 = extractvalue { <8 x ptr>, <8 x i64> } %8408, 1
  %8411 = extractelement <8 x ptr> %8409, i32 0
  %8412 = extractelement <8 x i64> %8410, i32 %7573
  %8413 = zext i32 %7573 to i64
  %8414 = mul i64 %8413, 4
  %8415 = sub i64 %8412, %8414
  %8416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8417 = select i1 %8416, i64 %8415, i64 0
  %private.contiguous.address1726 = getelementptr i8, ptr %8411, i64 %8417
  %private.contiguous.preserve1727 = load <8 x float>, ptr %private.contiguous.address1726, align 4
  %8418 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7827, <8 x float> %private.contiguous.preserve1727
  store <8 x float> %8418, ptr %private.contiguous.address1726, align 4
  %8419 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8420 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8421 = add <8 x i64> %8420, splat (i64 1184)
  %8422 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8419, 0
  %8423 = insertvalue { <8 x ptr>, <8 x i64> } %8422, <8 x i64> %8421, 1
  %8424 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8425 = extractvalue { <8 x ptr>, <8 x i64> } %8423, 1
  %8426 = extractelement <8 x ptr> %8424, i32 0
  %8427 = extractelement <8 x i64> %8425, i32 %7573
  %8428 = zext i32 %7573 to i64
  %8429 = mul i64 %8428, 4
  %8430 = sub i64 %8427, %8429
  %8431 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8432 = select i1 %8431, i64 %8430, i64 0
  %private.contiguous.address1728 = getelementptr i8, ptr %8426, i64 %8432
  %private.contiguous.preserve1729 = load <8 x float>, ptr %private.contiguous.address1728, align 4
  %8433 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7828, <8 x float> %private.contiguous.preserve1729
  store <8 x float> %8433, ptr %private.contiguous.address1728, align 4
  %8434 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8435 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8436 = add <8 x i64> %8435, splat (i64 1216)
  %8437 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8434, 0
  %8438 = insertvalue { <8 x ptr>, <8 x i64> } %8437, <8 x i64> %8436, 1
  %8439 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8440 = extractvalue { <8 x ptr>, <8 x i64> } %8438, 1
  %8441 = extractelement <8 x ptr> %8439, i32 0
  %8442 = extractelement <8 x i64> %8440, i32 %7573
  %8443 = zext i32 %7573 to i64
  %8444 = mul i64 %8443, 4
  %8445 = sub i64 %8442, %8444
  %8446 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8447 = select i1 %8446, i64 %8445, i64 0
  %private.contiguous.address1730 = getelementptr i8, ptr %8441, i64 %8447
  %private.contiguous.preserve1731 = load <8 x float>, ptr %private.contiguous.address1730, align 4
  %8448 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7829, <8 x float> %private.contiguous.preserve1731
  store <8 x float> %8448, ptr %private.contiguous.address1730, align 4
  %8449 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8450 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8451 = add <8 x i64> %8450, splat (i64 1248)
  %8452 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8449, 0
  %8453 = insertvalue { <8 x ptr>, <8 x i64> } %8452, <8 x i64> %8451, 1
  %8454 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8455 = extractvalue { <8 x ptr>, <8 x i64> } %8453, 1
  %8456 = extractelement <8 x ptr> %8454, i32 0
  %8457 = extractelement <8 x i64> %8455, i32 %7573
  %8458 = zext i32 %7573 to i64
  %8459 = mul i64 %8458, 4
  %8460 = sub i64 %8457, %8459
  %8461 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8462 = select i1 %8461, i64 %8460, i64 0
  %private.contiguous.address1732 = getelementptr i8, ptr %8456, i64 %8462
  %private.contiguous.preserve1733 = load <8 x float>, ptr %private.contiguous.address1732, align 4
  %8463 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7830, <8 x float> %private.contiguous.preserve1733
  store <8 x float> %8463, ptr %private.contiguous.address1732, align 4
  %8464 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8465 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8466 = add <8 x i64> %8465, splat (i64 1280)
  %8467 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8464, 0
  %8468 = insertvalue { <8 x ptr>, <8 x i64> } %8467, <8 x i64> %8466, 1
  %8469 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8470 = extractvalue { <8 x ptr>, <8 x i64> } %8468, 1
  %8471 = extractelement <8 x ptr> %8469, i32 0
  %8472 = extractelement <8 x i64> %8470, i32 %7573
  %8473 = zext i32 %7573 to i64
  %8474 = mul i64 %8473, 4
  %8475 = sub i64 %8472, %8474
  %8476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8477 = select i1 %8476, i64 %8475, i64 0
  %private.contiguous.address1734 = getelementptr i8, ptr %8471, i64 %8477
  %private.contiguous.preserve1735 = load <8 x float>, ptr %private.contiguous.address1734, align 4
  %8478 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7831, <8 x float> %private.contiguous.preserve1735
  store <8 x float> %8478, ptr %private.contiguous.address1734, align 4
  %8479 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8480 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8481 = add <8 x i64> %8480, splat (i64 1312)
  %8482 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8479, 0
  %8483 = insertvalue { <8 x ptr>, <8 x i64> } %8482, <8 x i64> %8481, 1
  %8484 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8485 = extractvalue { <8 x ptr>, <8 x i64> } %8483, 1
  %8486 = extractelement <8 x ptr> %8484, i32 0
  %8487 = extractelement <8 x i64> %8485, i32 %7573
  %8488 = zext i32 %7573 to i64
  %8489 = mul i64 %8488, 4
  %8490 = sub i64 %8487, %8489
  %8491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8492 = select i1 %8491, i64 %8490, i64 0
  %private.contiguous.address1736 = getelementptr i8, ptr %8486, i64 %8492
  %private.contiguous.preserve1737 = load <8 x float>, ptr %private.contiguous.address1736, align 4
  %8493 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7832, <8 x float> %private.contiguous.preserve1737
  store <8 x float> %8493, ptr %private.contiguous.address1736, align 4
  %8494 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8495 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8496 = add <8 x i64> %8495, splat (i64 1344)
  %8497 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8494, 0
  %8498 = insertvalue { <8 x ptr>, <8 x i64> } %8497, <8 x i64> %8496, 1
  %8499 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8500 = extractvalue { <8 x ptr>, <8 x i64> } %8498, 1
  %8501 = extractelement <8 x ptr> %8499, i32 0
  %8502 = extractelement <8 x i64> %8500, i32 %7573
  %8503 = zext i32 %7573 to i64
  %8504 = mul i64 %8503, 4
  %8505 = sub i64 %8502, %8504
  %8506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8507 = select i1 %8506, i64 %8505, i64 0
  %private.contiguous.address1738 = getelementptr i8, ptr %8501, i64 %8507
  %private.contiguous.preserve1739 = load <8 x float>, ptr %private.contiguous.address1738, align 4
  %8508 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7833, <8 x float> %private.contiguous.preserve1739
  store <8 x float> %8508, ptr %private.contiguous.address1738, align 4
  %8509 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8510 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8511 = add <8 x i64> %8510, splat (i64 1376)
  %8512 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8509, 0
  %8513 = insertvalue { <8 x ptr>, <8 x i64> } %8512, <8 x i64> %8511, 1
  %8514 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8515 = extractvalue { <8 x ptr>, <8 x i64> } %8513, 1
  %8516 = extractelement <8 x ptr> %8514, i32 0
  %8517 = extractelement <8 x i64> %8515, i32 %7573
  %8518 = zext i32 %7573 to i64
  %8519 = mul i64 %8518, 4
  %8520 = sub i64 %8517, %8519
  %8521 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8522 = select i1 %8521, i64 %8520, i64 0
  %private.contiguous.address1740 = getelementptr i8, ptr %8516, i64 %8522
  %private.contiguous.preserve1741 = load <8 x float>, ptr %private.contiguous.address1740, align 4
  %8523 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7834, <8 x float> %private.contiguous.preserve1741
  store <8 x float> %8523, ptr %private.contiguous.address1740, align 4
  %8524 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8525 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8526 = add <8 x i64> %8525, splat (i64 1408)
  %8527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8524, 0
  %8528 = insertvalue { <8 x ptr>, <8 x i64> } %8527, <8 x i64> %8526, 1
  %8529 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8530 = extractvalue { <8 x ptr>, <8 x i64> } %8528, 1
  %8531 = extractelement <8 x ptr> %8529, i32 0
  %8532 = extractelement <8 x i64> %8530, i32 %7573
  %8533 = zext i32 %7573 to i64
  %8534 = mul i64 %8533, 4
  %8535 = sub i64 %8532, %8534
  %8536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8537 = select i1 %8536, i64 %8535, i64 0
  %private.contiguous.address1742 = getelementptr i8, ptr %8531, i64 %8537
  %private.contiguous.preserve1743 = load <8 x float>, ptr %private.contiguous.address1742, align 4
  %8538 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7835, <8 x float> %private.contiguous.preserve1743
  store <8 x float> %8538, ptr %private.contiguous.address1742, align 4
  %8539 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8540 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8541 = add <8 x i64> %8540, splat (i64 1440)
  %8542 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8539, 0
  %8543 = insertvalue { <8 x ptr>, <8 x i64> } %8542, <8 x i64> %8541, 1
  %8544 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8545 = extractvalue { <8 x ptr>, <8 x i64> } %8543, 1
  %8546 = extractelement <8 x ptr> %8544, i32 0
  %8547 = extractelement <8 x i64> %8545, i32 %7573
  %8548 = zext i32 %7573 to i64
  %8549 = mul i64 %8548, 4
  %8550 = sub i64 %8547, %8549
  %8551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8552 = select i1 %8551, i64 %8550, i64 0
  %private.contiguous.address1744 = getelementptr i8, ptr %8546, i64 %8552
  %private.contiguous.preserve1745 = load <8 x float>, ptr %private.contiguous.address1744, align 4
  %8553 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7836, <8 x float> %private.contiguous.preserve1745
  store <8 x float> %8553, ptr %private.contiguous.address1744, align 4
  %8554 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8555 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8556 = add <8 x i64> %8555, splat (i64 1472)
  %8557 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8554, 0
  %8558 = insertvalue { <8 x ptr>, <8 x i64> } %8557, <8 x i64> %8556, 1
  %8559 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8560 = extractvalue { <8 x ptr>, <8 x i64> } %8558, 1
  %8561 = extractelement <8 x ptr> %8559, i32 0
  %8562 = extractelement <8 x i64> %8560, i32 %7573
  %8563 = zext i32 %7573 to i64
  %8564 = mul i64 %8563, 4
  %8565 = sub i64 %8562, %8564
  %8566 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8567 = select i1 %8566, i64 %8565, i64 0
  %private.contiguous.address1746 = getelementptr i8, ptr %8561, i64 %8567
  %private.contiguous.preserve1747 = load <8 x float>, ptr %private.contiguous.address1746, align 4
  %8568 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7837, <8 x float> %private.contiguous.preserve1747
  store <8 x float> %8568, ptr %private.contiguous.address1746, align 4
  %8569 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8570 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8571 = add <8 x i64> %8570, splat (i64 1504)
  %8572 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8569, 0
  %8573 = insertvalue { <8 x ptr>, <8 x i64> } %8572, <8 x i64> %8571, 1
  %8574 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8575 = extractvalue { <8 x ptr>, <8 x i64> } %8573, 1
  %8576 = extractelement <8 x ptr> %8574, i32 0
  %8577 = extractelement <8 x i64> %8575, i32 %7573
  %8578 = zext i32 %7573 to i64
  %8579 = mul i64 %8578, 4
  %8580 = sub i64 %8577, %8579
  %8581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8582 = select i1 %8581, i64 %8580, i64 0
  %private.contiguous.address1748 = getelementptr i8, ptr %8576, i64 %8582
  %private.contiguous.preserve1749 = load <8 x float>, ptr %private.contiguous.address1748, align 4
  %8583 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7838, <8 x float> %private.contiguous.preserve1749
  store <8 x float> %8583, ptr %private.contiguous.address1748, align 4
  %8584 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8585 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8586 = add <8 x i64> %8585, splat (i64 1536)
  %8587 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8584, 0
  %8588 = insertvalue { <8 x ptr>, <8 x i64> } %8587, <8 x i64> %8586, 1
  %8589 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8590 = extractvalue { <8 x ptr>, <8 x i64> } %8588, 1
  %8591 = extractelement <8 x ptr> %8589, i32 0
  %8592 = extractelement <8 x i64> %8590, i32 %7573
  %8593 = zext i32 %7573 to i64
  %8594 = mul i64 %8593, 4
  %8595 = sub i64 %8592, %8594
  %8596 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8597 = select i1 %8596, i64 %8595, i64 0
  %private.contiguous.address1750 = getelementptr i8, ptr %8591, i64 %8597
  %private.contiguous.preserve1751 = load <8 x float>, ptr %private.contiguous.address1750, align 4
  %8598 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7839, <8 x float> %private.contiguous.preserve1751
  store <8 x float> %8598, ptr %private.contiguous.address1750, align 4
  %8599 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8600 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8601 = add <8 x i64> %8600, splat (i64 1568)
  %8602 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8599, 0
  %8603 = insertvalue { <8 x ptr>, <8 x i64> } %8602, <8 x i64> %8601, 1
  %8604 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8605 = extractvalue { <8 x ptr>, <8 x i64> } %8603, 1
  %8606 = extractelement <8 x ptr> %8604, i32 0
  %8607 = extractelement <8 x i64> %8605, i32 %7573
  %8608 = zext i32 %7573 to i64
  %8609 = mul i64 %8608, 4
  %8610 = sub i64 %8607, %8609
  %8611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8612 = select i1 %8611, i64 %8610, i64 0
  %private.contiguous.address1752 = getelementptr i8, ptr %8606, i64 %8612
  %private.contiguous.preserve1753 = load <8 x float>, ptr %private.contiguous.address1752, align 4
  %8613 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7840, <8 x float> %private.contiguous.preserve1753
  store <8 x float> %8613, ptr %private.contiguous.address1752, align 4
  %8614 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8615 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8616 = add <8 x i64> %8615, splat (i64 1600)
  %8617 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8614, 0
  %8618 = insertvalue { <8 x ptr>, <8 x i64> } %8617, <8 x i64> %8616, 1
  %8619 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8620 = extractvalue { <8 x ptr>, <8 x i64> } %8618, 1
  %8621 = extractelement <8 x ptr> %8619, i32 0
  %8622 = extractelement <8 x i64> %8620, i32 %7573
  %8623 = zext i32 %7573 to i64
  %8624 = mul i64 %8623, 4
  %8625 = sub i64 %8622, %8624
  %8626 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8627 = select i1 %8626, i64 %8625, i64 0
  %private.contiguous.address1754 = getelementptr i8, ptr %8621, i64 %8627
  %private.contiguous.preserve1755 = load <8 x float>, ptr %private.contiguous.address1754, align 4
  %8628 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7841, <8 x float> %private.contiguous.preserve1755
  store <8 x float> %8628, ptr %private.contiguous.address1754, align 4
  %8629 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8630 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8631 = add <8 x i64> %8630, splat (i64 1632)
  %8632 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8629, 0
  %8633 = insertvalue { <8 x ptr>, <8 x i64> } %8632, <8 x i64> %8631, 1
  %8634 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8635 = extractvalue { <8 x ptr>, <8 x i64> } %8633, 1
  %8636 = extractelement <8 x ptr> %8634, i32 0
  %8637 = extractelement <8 x i64> %8635, i32 %7573
  %8638 = zext i32 %7573 to i64
  %8639 = mul i64 %8638, 4
  %8640 = sub i64 %8637, %8639
  %8641 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8642 = select i1 %8641, i64 %8640, i64 0
  %private.contiguous.address1756 = getelementptr i8, ptr %8636, i64 %8642
  %private.contiguous.preserve1757 = load <8 x float>, ptr %private.contiguous.address1756, align 4
  %8643 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7842, <8 x float> %private.contiguous.preserve1757
  store <8 x float> %8643, ptr %private.contiguous.address1756, align 4
  %8644 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8645 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8646 = add <8 x i64> %8645, splat (i64 1664)
  %8647 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8644, 0
  %8648 = insertvalue { <8 x ptr>, <8 x i64> } %8647, <8 x i64> %8646, 1
  %8649 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8650 = extractvalue { <8 x ptr>, <8 x i64> } %8648, 1
  %8651 = extractelement <8 x ptr> %8649, i32 0
  %8652 = extractelement <8 x i64> %8650, i32 %7573
  %8653 = zext i32 %7573 to i64
  %8654 = mul i64 %8653, 4
  %8655 = sub i64 %8652, %8654
  %8656 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8657 = select i1 %8656, i64 %8655, i64 0
  %private.contiguous.address1758 = getelementptr i8, ptr %8651, i64 %8657
  %private.contiguous.preserve1759 = load <8 x float>, ptr %private.contiguous.address1758, align 4
  %8658 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7843, <8 x float> %private.contiguous.preserve1759
  store <8 x float> %8658, ptr %private.contiguous.address1758, align 4
  %8659 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8660 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8661 = add <8 x i64> %8660, splat (i64 1696)
  %8662 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8659, 0
  %8663 = insertvalue { <8 x ptr>, <8 x i64> } %8662, <8 x i64> %8661, 1
  %8664 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8665 = extractvalue { <8 x ptr>, <8 x i64> } %8663, 1
  %8666 = extractelement <8 x ptr> %8664, i32 0
  %8667 = extractelement <8 x i64> %8665, i32 %7573
  %8668 = zext i32 %7573 to i64
  %8669 = mul i64 %8668, 4
  %8670 = sub i64 %8667, %8669
  %8671 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8672 = select i1 %8671, i64 %8670, i64 0
  %private.contiguous.address1760 = getelementptr i8, ptr %8666, i64 %8672
  %private.contiguous.preserve1761 = load <8 x float>, ptr %private.contiguous.address1760, align 4
  %8673 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7844, <8 x float> %private.contiguous.preserve1761
  store <8 x float> %8673, ptr %private.contiguous.address1760, align 4
  %8674 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8675 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8676 = add <8 x i64> %8675, splat (i64 1728)
  %8677 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8674, 0
  %8678 = insertvalue { <8 x ptr>, <8 x i64> } %8677, <8 x i64> %8676, 1
  %8679 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8680 = extractvalue { <8 x ptr>, <8 x i64> } %8678, 1
  %8681 = extractelement <8 x ptr> %8679, i32 0
  %8682 = extractelement <8 x i64> %8680, i32 %7573
  %8683 = zext i32 %7573 to i64
  %8684 = mul i64 %8683, 4
  %8685 = sub i64 %8682, %8684
  %8686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8687 = select i1 %8686, i64 %8685, i64 0
  %private.contiguous.address1762 = getelementptr i8, ptr %8681, i64 %8687
  %private.contiguous.preserve1763 = load <8 x float>, ptr %private.contiguous.address1762, align 4
  %8688 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7845, <8 x float> %private.contiguous.preserve1763
  store <8 x float> %8688, ptr %private.contiguous.address1762, align 4
  %8689 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8690 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8691 = add <8 x i64> %8690, splat (i64 1760)
  %8692 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8689, 0
  %8693 = insertvalue { <8 x ptr>, <8 x i64> } %8692, <8 x i64> %8691, 1
  %8694 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8695 = extractvalue { <8 x ptr>, <8 x i64> } %8693, 1
  %8696 = extractelement <8 x ptr> %8694, i32 0
  %8697 = extractelement <8 x i64> %8695, i32 %7573
  %8698 = zext i32 %7573 to i64
  %8699 = mul i64 %8698, 4
  %8700 = sub i64 %8697, %8699
  %8701 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8702 = select i1 %8701, i64 %8700, i64 0
  %private.contiguous.address1764 = getelementptr i8, ptr %8696, i64 %8702
  %private.contiguous.preserve1765 = load <8 x float>, ptr %private.contiguous.address1764, align 4
  %8703 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7846, <8 x float> %private.contiguous.preserve1765
  store <8 x float> %8703, ptr %private.contiguous.address1764, align 4
  %8704 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8705 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8706 = add <8 x i64> %8705, splat (i64 1792)
  %8707 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8704, 0
  %8708 = insertvalue { <8 x ptr>, <8 x i64> } %8707, <8 x i64> %8706, 1
  %8709 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8710 = extractvalue { <8 x ptr>, <8 x i64> } %8708, 1
  %8711 = extractelement <8 x ptr> %8709, i32 0
  %8712 = extractelement <8 x i64> %8710, i32 %7573
  %8713 = zext i32 %7573 to i64
  %8714 = mul i64 %8713, 4
  %8715 = sub i64 %8712, %8714
  %8716 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8717 = select i1 %8716, i64 %8715, i64 0
  %private.contiguous.address1766 = getelementptr i8, ptr %8711, i64 %8717
  %private.contiguous.preserve1767 = load <8 x float>, ptr %private.contiguous.address1766, align 4
  %8718 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7847, <8 x float> %private.contiguous.preserve1767
  store <8 x float> %8718, ptr %private.contiguous.address1766, align 4
  %8719 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8720 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8721 = add <8 x i64> %8720, splat (i64 1824)
  %8722 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8719, 0
  %8723 = insertvalue { <8 x ptr>, <8 x i64> } %8722, <8 x i64> %8721, 1
  %8724 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8725 = extractvalue { <8 x ptr>, <8 x i64> } %8723, 1
  %8726 = extractelement <8 x ptr> %8724, i32 0
  %8727 = extractelement <8 x i64> %8725, i32 %7573
  %8728 = zext i32 %7573 to i64
  %8729 = mul i64 %8728, 4
  %8730 = sub i64 %8727, %8729
  %8731 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8732 = select i1 %8731, i64 %8730, i64 0
  %private.contiguous.address1768 = getelementptr i8, ptr %8726, i64 %8732
  %private.contiguous.preserve1769 = load <8 x float>, ptr %private.contiguous.address1768, align 4
  %8733 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7848, <8 x float> %private.contiguous.preserve1769
  store <8 x float> %8733, ptr %private.contiguous.address1768, align 4
  %8734 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8735 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8736 = add <8 x i64> %8735, splat (i64 1856)
  %8737 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8734, 0
  %8738 = insertvalue { <8 x ptr>, <8 x i64> } %8737, <8 x i64> %8736, 1
  %8739 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8740 = extractvalue { <8 x ptr>, <8 x i64> } %8738, 1
  %8741 = extractelement <8 x ptr> %8739, i32 0
  %8742 = extractelement <8 x i64> %8740, i32 %7573
  %8743 = zext i32 %7573 to i64
  %8744 = mul i64 %8743, 4
  %8745 = sub i64 %8742, %8744
  %8746 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8747 = select i1 %8746, i64 %8745, i64 0
  %private.contiguous.address1770 = getelementptr i8, ptr %8741, i64 %8747
  %private.contiguous.preserve1771 = load <8 x float>, ptr %private.contiguous.address1770, align 4
  %8748 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7849, <8 x float> %private.contiguous.preserve1771
  store <8 x float> %8748, ptr %private.contiguous.address1770, align 4
  %8749 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8750 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8751 = add <8 x i64> %8750, splat (i64 1888)
  %8752 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8749, 0
  %8753 = insertvalue { <8 x ptr>, <8 x i64> } %8752, <8 x i64> %8751, 1
  %8754 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8755 = extractvalue { <8 x ptr>, <8 x i64> } %8753, 1
  %8756 = extractelement <8 x ptr> %8754, i32 0
  %8757 = extractelement <8 x i64> %8755, i32 %7573
  %8758 = zext i32 %7573 to i64
  %8759 = mul i64 %8758, 4
  %8760 = sub i64 %8757, %8759
  %8761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8762 = select i1 %8761, i64 %8760, i64 0
  %private.contiguous.address1772 = getelementptr i8, ptr %8756, i64 %8762
  %private.contiguous.preserve1773 = load <8 x float>, ptr %private.contiguous.address1772, align 4
  %8763 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7850, <8 x float> %private.contiguous.preserve1773
  store <8 x float> %8763, ptr %private.contiguous.address1772, align 4
  %8764 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8765 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8766 = add <8 x i64> %8765, splat (i64 1920)
  %8767 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8764, 0
  %8768 = insertvalue { <8 x ptr>, <8 x i64> } %8767, <8 x i64> %8766, 1
  %8769 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8770 = extractvalue { <8 x ptr>, <8 x i64> } %8768, 1
  %8771 = extractelement <8 x ptr> %8769, i32 0
  %8772 = extractelement <8 x i64> %8770, i32 %7573
  %8773 = zext i32 %7573 to i64
  %8774 = mul i64 %8773, 4
  %8775 = sub i64 %8772, %8774
  %8776 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8777 = select i1 %8776, i64 %8775, i64 0
  %private.contiguous.address1774 = getelementptr i8, ptr %8771, i64 %8777
  %private.contiguous.preserve1775 = load <8 x float>, ptr %private.contiguous.address1774, align 4
  %8778 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7851, <8 x float> %private.contiguous.preserve1775
  store <8 x float> %8778, ptr %private.contiguous.address1774, align 4
  %8779 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8780 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8781 = add <8 x i64> %8780, splat (i64 1952)
  %8782 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8779, 0
  %8783 = insertvalue { <8 x ptr>, <8 x i64> } %8782, <8 x i64> %8781, 1
  %8784 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8785 = extractvalue { <8 x ptr>, <8 x i64> } %8783, 1
  %8786 = extractelement <8 x ptr> %8784, i32 0
  %8787 = extractelement <8 x i64> %8785, i32 %7573
  %8788 = zext i32 %7573 to i64
  %8789 = mul i64 %8788, 4
  %8790 = sub i64 %8787, %8789
  %8791 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8792 = select i1 %8791, i64 %8790, i64 0
  %private.contiguous.address1776 = getelementptr i8, ptr %8786, i64 %8792
  %private.contiguous.preserve1777 = load <8 x float>, ptr %private.contiguous.address1776, align 4
  %8793 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7852, <8 x float> %private.contiguous.preserve1777
  store <8 x float> %8793, ptr %private.contiguous.address1776, align 4
  %8794 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8795 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8796 = add <8 x i64> %8795, splat (i64 1984)
  %8797 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8794, 0
  %8798 = insertvalue { <8 x ptr>, <8 x i64> } %8797, <8 x i64> %8796, 1
  %8799 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8800 = extractvalue { <8 x ptr>, <8 x i64> } %8798, 1
  %8801 = extractelement <8 x ptr> %8799, i32 0
  %8802 = extractelement <8 x i64> %8800, i32 %7573
  %8803 = zext i32 %7573 to i64
  %8804 = mul i64 %8803, 4
  %8805 = sub i64 %8802, %8804
  %8806 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8807 = select i1 %8806, i64 %8805, i64 0
  %private.contiguous.address1778 = getelementptr i8, ptr %8801, i64 %8807
  %private.contiguous.preserve1779 = load <8 x float>, ptr %private.contiguous.address1778, align 4
  %8808 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7853, <8 x float> %private.contiguous.preserve1779
  store <8 x float> %8808, ptr %private.contiguous.address1778, align 4
  %8809 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8810 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %8811 = add <8 x i64> %8810, splat (i64 2016)
  %8812 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %8809, 0
  %8813 = insertvalue { <8 x ptr>, <8 x i64> } %8812, <8 x i64> %8811, 1
  %8814 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %8815 = extractvalue { <8 x ptr>, <8 x i64> } %8813, 1
  %8816 = extractelement <8 x ptr> %8814, i32 0
  %8817 = extractelement <8 x i64> %8815, i32 %7573
  %8818 = zext i32 %7573 to i64
  %8819 = mul i64 %8818, 4
  %8820 = sub i64 %8817, %8819
  %8821 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  %8822 = select i1 %8821, i64 %8820, i64 0
  %private.contiguous.address1780 = getelementptr i8, ptr %8816, i64 %8822
  %private.contiguous.preserve1781 = load <8 x float>, ptr %private.contiguous.address1780, align 4
  %8823 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %7854, <8 x float> %private.contiguous.preserve1781
  store <8 x float> %8823, ptr %private.contiguous.address1780, align 4
  %.state1782 = load <8 x float>, ptr %.slot47, align 32
  %8824 = fmul <8 x float> %.state1782, %native.exp
  %8825 = load <8 x float>, ptr %.spill278, align 32
  %8826 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %8824, <8 x float> %8825
  store <8 x float> %8826, ptr %.spill278, align 32
  %.state1783 = load <8 x float>, ptr %.slot48, align 32
  %8827 = fmul <8 x float> %.state1783, %native.exp1451
  %8828 = load <8 x float>, ptr %.spill279, align 32
  %8829 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %8827, <8 x float> %8828
  store <8 x float> %8829, ptr %.spill279, align 32
  %.state1784 = load <8 x float>, ptr %.slot49, align 32
  %8830 = fmul <8 x float> %.state1784, %native.exp1452
  %8831 = load <8 x float>, ptr %.spill280, align 32
  %8832 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %8830, <8 x float> %8831
  store <8 x float> %8832, ptr %.spill280, align 32
  %.state1785 = load <8 x float>, ptr %.slot50, align 32
  %8833 = fmul <8 x float> %.state1785, %native.exp1453
  %8834 = load <8 x float>, ptr %.spill281, align 32
  %8835 = select <8 x i1> %convergence.cascade.result1438, <8 x float> %8833, <8 x float> %8834
  store <8 x float> %8835, ptr %.spill281, align 32
  %8836 = load <8 x i64>, ptr %.slot55, align 64
  %8837 = select <8 x i1> %convergence.cascade.result1438, <8 x i64> zeroinitializer, <8 x i64> %8836
  store <8 x i64> %8837, ptr %.slot55, align 64
  %8838 = load <8 x float>, ptr %.slot43, align 32
  %8839 = select <8 x i1> %convergence.cascade.result1438, <8 x float> zeroinitializer, <8 x float> %8838
  store <8 x float> %8839, ptr %.slot43, align 32
  store <8 x i1> %convergence.cascade.result1438, ptr %current.mask, align 1
  %8840 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1438)
  br i1 %8840, label %schedule.72, label %scheduler.loop

varying.divergent1787:                            ; preds = %schedule.72
  %8841 = load i32, ptr %current.token, align 4
  %8842 = icmp ne i32 %8841, 0
  %8843 = sub i32 %8841, 1
  %8844 = select i1 %8842, i32 %8843, i32 0
  %8845 = load i8, ptr %frame.active, align 1
  %8846 = trunc i32 %8844 to i8
  %8847 = shl i8 1, %8846
  %8848 = and i8 %8845, %8847
  %8849 = icmp ne i8 %8848, 0
  %8850 = load <8 x i32>, ptr %frame.static.id, align 32
  %8851 = extractelement <8 x i32> %8850, i32 %8844
  %8852 = icmp eq i32 %8851, 25
  %8853 = and i1 %8849, %8852
  %8854 = and i1 %8842, %8853
  %8855 = xor i1 %8854, true
  %8856 = and i1 true, %8855
  %8857 = xor i8 %8845, -1
  %8858 = icmp ne i8 %8857, 0
  %8859 = xor i1 %8858, true
  %8860 = and i1 %8856, %8859
  br i1 %8860, label %convergence.overflow.trap1789, label %convergence.overflow.resume1790

varying.coherent1788:                             ; preds = %schedule.72
  br i1 %1806, label %varying.coherent.true1793, label %varying.coherent.false1794

convergence.overflow.trap1789:                    ; preds = %varying.divergent1787
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1790:                  ; preds = %varying.divergent1787
  %8861 = call i8 @llvm.cttz.i8(i8 %8857, i1 false)
  %8862 = zext i8 %8861 to i32
  %8863 = select i1 %8858, i32 %8862, i32 0
  %8864 = trunc i32 %8863 to i8
  %8865 = shl i8 1, %8864
  %8866 = or i8 %8845, %8865
  %8867 = select i1 %8856, i8 %8866, i8 %8845
  store i8 %8867, ptr %frame.active, align 1
  %8868 = load <8 x i32>, ptr %frame.static.id, align 32
  %8869 = extractelement <8 x i32> %8868, i32 %8863
  %8870 = select i1 %8856, i32 25, i32 %8869
  %8871 = load <8 x i32>, ptr %frame.static.id, align 32
  %8872 = insertelement <8 x i32> %8871, i32 %8870, i32 %8863
  store <8 x i32> %8872, ptr %frame.static.id, align 32
  %8873 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8874 = extractelement <8 x i32> %8873, i32 %8863
  %8875 = select i1 %8856, i32 %8841, i32 %8874
  %8876 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8877 = insertelement <8 x i32> %8876, i32 %8875, i32 %8863
  store <8 x i32> %8877, ptr %frame.parent.token, align 32
  %8878 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8863
  %8879 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8863
  %8880 = load <8 x i1>, ptr %8878, align 1
  %8881 = load <8 x i1>, ptr %8879, align 1
  %8882 = select i1 %8856, <8 x i1> %1796, <8 x i1> %8880
  store <8 x i1> %8882, ptr %8878, align 1
  %8883 = select i1 %8856, <8 x i1> zeroinitializer, <8 x i1> %8881
  store <8 x i1> %8883, ptr %8879, align 1
  %8884 = add i32 %8863, 1
  %8885 = select i1 %8854, i32 %8841, i32 %8884
  %8886 = select i1 true, i32 %8885, i32 %8841
  store i32 %8886, ptr %current.token, align 4
  %8887 = load i32, ptr %current.token, align 4
  %8888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1803)
  %8889 = load i32, ptr %ready.count, align 4
  %8890 = icmp uge i32 %8889, 8
  %8891 = and i1 %8888, %8890
  br i1 %8891, label %ready.overflow.trap1791, label %ready.overflow.resume1792

ready.overflow.trap1791:                          ; preds = %convergence.overflow.resume1790
  call void @llvm.trap()
  unreachable

ready.overflow.resume1792:                        ; preds = %convergence.overflow.resume1790
  %8892 = select i1 %8888, i32 %8889, i32 0
  %8893 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %8892
  %8894 = load <8 x i1>, ptr %8893, align 1
  %8895 = select i1 %8888, <8 x i1> %1803, <8 x i1> %8894
  store <8 x i1> %8895, ptr %8893, align 1
  %8896 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %8892
  %8897 = load i32, ptr %8896, align 4
  %8898 = select i1 %8888, i32 73, i32 %8897
  store i32 %8898, ptr %8896, align 4
  %8899 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %8892
  %8900 = load i32, ptr %8899, align 4
  %8901 = select i1 %8888, i32 %8887, i32 %8900
  store i32 %8901, ptr %8899, align 4
  %8902 = add i32 %8889, 1
  %8903 = select i1 %8888, i32 %8902, i32 %8889
  store i32 %8903, ptr %ready.count, align 4
  %8904 = load <8 x i1>, ptr %runnable.mask, align 1
  %8905 = or <8 x i1> %8904, %1803
  store <8 x i1> %8905, ptr %runnable.mask, align 1
  store <8 x i1> %1805, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1793:                        ; preds = %varying.coherent1788
  store <8 x i1> %1796, ptr %current.mask, align 1
  %8906 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1796)
  br i1 %8906, label %schedule.73, label %scheduler.loop

varying.coherent.false1794:                       ; preds = %varying.coherent1788
  store <8 x i1> %1796, ptr %current.mask, align 1
  %8907 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1796)
  br i1 %8907, label %schedule.74, label %scheduler.loop

convergence.cascade1799:                          ; preds = %convergence.cascade1799, %schedule.74
  %convergence.cascade.flow1803 = phi <8 x i1> [ %1836, %schedule.74 ], [ %8950, %convergence.cascade1799 ]
  %convergence.cascade.depth1804 = phi i32 [ 0, %schedule.74 ], [ %8951, %convergence.cascade1799 ]
  %8908 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1803)
  %8909 = load i32, ptr %current.token, align 4
  %8910 = icmp ne i32 %8909, 0
  %8911 = and i1 %8908, %8910
  %8912 = sub i32 %8909, 1
  %8913 = select i1 %8911, i32 %8912, i32 0
  %8914 = load i8, ptr %frame.active, align 1
  %8915 = trunc i32 %8913 to i8
  %8916 = shl i8 1, %8915
  %8917 = and i8 %8914, %8916
  %8918 = icmp ne i8 %8917, 0
  %8919 = load <8 x i32>, ptr %frame.static.id, align 32
  %8920 = extractelement <8 x i32> %8919, i32 %8913
  %convergence.target.pointer1805 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %8920
  %convergence.dynamic.target1806 = load i32, ptr %convergence.target.pointer1805, align 4
  %8921 = icmp eq i32 %convergence.dynamic.target1806, 74
  %8922 = and i1 %8918, %8921
  %8923 = and i1 %8911, %8922
  %8924 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8913
  %8925 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8913
  %8926 = load <8 x i1>, ptr %8924, align 1
  %8927 = load <8 x i1>, ptr %8925, align 1
  %8928 = or <8 x i1> %8927, %convergence.cascade.flow1803
  %8929 = load <8 x i1>, ptr %live.mask, align 1
  %8930 = and <8 x i1> %8926, %8929
  %8931 = icmp eq <8 x i1> %8928, %8930
  %8932 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %8931)
  %8933 = and i1 %8923, %8932
  %8934 = select i1 %8933, <8 x i1> zeroinitializer, <8 x i1> %8928
  %8935 = select i1 %8923, <8 x i1> %8934, <8 x i1> %8927
  store <8 x i1> %8935, ptr %8925, align 1
  %8936 = select i1 %8933, <8 x i1> zeroinitializer, <8 x i1> %8926
  store <8 x i1> %8936, ptr %8924, align 1
  %8937 = trunc i32 %8913 to i8
  %8938 = shl i8 1, %8937
  %8939 = xor i8 %8938, -1
  %8940 = and i8 %8914, %8939
  %8941 = select i1 %8933, i8 %8940, i8 %8914
  store i8 %8941, ptr %frame.active, align 1
  %.splatinsert1807 = insertelement <8 x i1> poison, i1 %8923, i64 0
  %.splat1808 = shufflevector <8 x i1> %.splatinsert1807, <8 x i1> poison, <8 x i32> zeroinitializer
  %8942 = and <8 x i1> %convergence.cascade.flow1803, %.splat1808
  %8943 = load <8 x i1>, ptr %runnable.mask, align 1
  %8944 = xor <8 x i1> %8942, splat (i1 true)
  %8945 = and <8 x i1> %8943, %8944
  store <8 x i1> %8945, ptr %runnable.mask, align 1
  %.splatinsert1809 = insertelement <8 x i1> poison, i1 %8933, i64 0
  %.splat1810 = shufflevector <8 x i1> %.splatinsert1809, <8 x i1> poison, <8 x i32> zeroinitializer
  %8946 = select <8 x i1> %.splat1810, <8 x i1> %8928, <8 x i1> zeroinitializer
  %8947 = load <8 x i32>, ptr %frame.parent.token, align 32
  %8948 = extractelement <8 x i32> %8947, i32 %8913
  %8949 = select i1 %8933, i32 %8948, i32 %8909
  store i32 %8949, ptr %current.token, align 4
  %.splatinsert1811 = insertelement <8 x i1> poison, i1 %8923, i64 0
  %.splat1812 = shufflevector <8 x i1> %.splatinsert1811, <8 x i1> poison, <8 x i32> zeroinitializer
  %8950 = select <8 x i1> %.splat1812, <8 x i1> %8946, <8 x i1> %convergence.cascade.flow1803
  %8951 = add i32 %convergence.cascade.depth1804, 1
  %8952 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %8950)
  %8953 = icmp ult i32 %8951, 8
  %8954 = and i1 %8952, %8953
  %8955 = and i1 %8923, %8954
  %convergence.parent.token1813 = load i32, ptr %current.token, align 4
  %convergence.parent.present1814 = icmp ne i32 %convergence.parent.token1813, 0
  %8956 = and i1 %8955, %convergence.parent.present1814
  br i1 %8956, label %convergence.cascade1799, label %convergence.cascade.exit1800

convergence.cascade.exit1800:                     ; preds = %convergence.cascade1799, %schedule.74
  %convergence.cascade.result1815 = phi <8 x i1> [ %1836, %schedule.74 ], [ %8950, %convergence.cascade1799 ]
  %8957 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1815)
  br i1 %8957, label %convergence.target.74.ready, label %scheduler.loop

convergence.target.74.ready:                      ; preds = %convergence.cascade.exit1800
  %8958 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1815)
  %8959 = bitcast <8 x i1> %convergence.cascade.result1815 to i8
  %8960 = call i8 @llvm.cttz.i8(i8 %8959, i1 false)
  %8961 = zext i8 %8960 to i32
  %8962 = select i1 %8958, i32 %8961, i32 0
  %8963 = load <8 x i64>, ptr %.slot55, align 64
  %8964 = select <8 x i1> %convergence.cascade.result1815, <8 x i64> zeroinitializer, <8 x i64> %8963
  store <8 x i64> %8964, ptr %.slot55, align 64
  %8965 = load <8 x float>, ptr %.slot44, align 32
  %8966 = select <8 x i1> %convergence.cascade.result1815, <8 x float> zeroinitializer, <8 x float> %8965
  store <8 x float> %8966, ptr %.slot44, align 32
  store <8 x i1> %convergence.cascade.result1815, ptr %current.mask, align 1
  %8967 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1815)
  br i1 %8967, label %schedule.75, label %scheduler.loop

varying.divergent1817:                            ; preds = %schedule.75
  %8968 = load i32, ptr %current.token, align 4
  %8969 = icmp ne i32 %8968, 0
  %8970 = sub i32 %8968, 1
  %8971 = select i1 %8969, i32 %8970, i32 0
  %8972 = load i8, ptr %frame.active, align 1
  %8973 = trunc i32 %8971 to i8
  %8974 = shl i8 1, %8973
  %8975 = and i8 %8972, %8974
  %8976 = icmp ne i8 %8975, 0
  %8977 = load <8 x i32>, ptr %frame.static.id, align 32
  %8978 = extractelement <8 x i32> %8977, i32 %8971
  %8979 = icmp eq i32 %8978, 26
  %8980 = and i1 %8976, %8979
  %8981 = and i1 %8969, %8980
  %8982 = xor i1 %8981, true
  %8983 = and i1 true, %8982
  %8984 = xor i8 %8972, -1
  %8985 = icmp ne i8 %8984, 0
  %8986 = xor i1 %8985, true
  %8987 = and i1 %8983, %8986
  br i1 %8987, label %convergence.overflow.trap1819, label %convergence.overflow.resume1820

varying.coherent1818:                             ; preds = %schedule.75
  br i1 %1847, label %varying.coherent.true1823, label %varying.coherent.false1824

convergence.overflow.trap1819:                    ; preds = %varying.divergent1817
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1820:                  ; preds = %varying.divergent1817
  %8988 = call i8 @llvm.cttz.i8(i8 %8984, i1 false)
  %8989 = zext i8 %8988 to i32
  %8990 = select i1 %8985, i32 %8989, i32 0
  %8991 = trunc i32 %8990 to i8
  %8992 = shl i8 1, %8991
  %8993 = or i8 %8972, %8992
  %8994 = select i1 %8983, i8 %8993, i8 %8972
  store i8 %8994, ptr %frame.active, align 1
  %8995 = load <8 x i32>, ptr %frame.static.id, align 32
  %8996 = extractelement <8 x i32> %8995, i32 %8990
  %8997 = select i1 %8983, i32 26, i32 %8996
  %8998 = load <8 x i32>, ptr %frame.static.id, align 32
  %8999 = insertelement <8 x i32> %8998, i32 %8997, i32 %8990
  store <8 x i32> %8999, ptr %frame.static.id, align 32
  %9000 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9001 = extractelement <8 x i32> %9000, i32 %8990
  %9002 = select i1 %8983, i32 %8968, i32 %9001
  %9003 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9004 = insertelement <8 x i32> %9003, i32 %9002, i32 %8990
  store <8 x i32> %9004, ptr %frame.parent.token, align 32
  %9005 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %8990
  %9006 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %8990
  %9007 = load <8 x i1>, ptr %9005, align 1
  %9008 = load <8 x i1>, ptr %9006, align 1
  %9009 = select i1 %8983, <8 x i1> %1837, <8 x i1> %9007
  store <8 x i1> %9009, ptr %9005, align 1
  %9010 = select i1 %8983, <8 x i1> zeroinitializer, <8 x i1> %9008
  store <8 x i1> %9010, ptr %9006, align 1
  %9011 = add i32 %8990, 1
  %9012 = select i1 %8981, i32 %8968, i32 %9011
  %9013 = select i1 true, i32 %9012, i32 %8968
  store i32 %9013, ptr %current.token, align 4
  %9014 = load i32, ptr %current.token, align 4
  %9015 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1844)
  %9016 = load i32, ptr %ready.count, align 4
  %9017 = icmp uge i32 %9016, 8
  %9018 = and i1 %9015, %9017
  br i1 %9018, label %ready.overflow.trap1821, label %ready.overflow.resume1822

ready.overflow.trap1821:                          ; preds = %convergence.overflow.resume1820
  call void @llvm.trap()
  unreachable

ready.overflow.resume1822:                        ; preds = %convergence.overflow.resume1820
  %9019 = select i1 %9015, i32 %9016, i32 0
  %9020 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9019
  %9021 = load <8 x i1>, ptr %9020, align 1
  %9022 = select i1 %9015, <8 x i1> %1844, <8 x i1> %9021
  store <8 x i1> %9022, ptr %9020, align 1
  %9023 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9019
  %9024 = load i32, ptr %9023, align 4
  %9025 = select i1 %9015, i32 76, i32 %9024
  store i32 %9025, ptr %9023, align 4
  %9026 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9019
  %9027 = load i32, ptr %9026, align 4
  %9028 = select i1 %9015, i32 %9014, i32 %9027
  store i32 %9028, ptr %9026, align 4
  %9029 = add i32 %9016, 1
  %9030 = select i1 %9015, i32 %9029, i32 %9016
  store i32 %9030, ptr %ready.count, align 4
  %9031 = load <8 x i1>, ptr %runnable.mask, align 1
  %9032 = or <8 x i1> %9031, %1844
  store <8 x i1> %9032, ptr %runnable.mask, align 1
  store <8 x i1> %1846, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1823:                        ; preds = %varying.coherent1818
  store <8 x i1> %1837, ptr %current.mask, align 1
  %9033 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1837)
  br i1 %9033, label %schedule.76, label %scheduler.loop

varying.coherent.false1824:                       ; preds = %varying.coherent1818
  store <8 x i1> %1837, ptr %current.mask, align 1
  %9034 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1837)
  br i1 %9034, label %schedule.77, label %scheduler.loop

convergence.cascade1829:                          ; preds = %convergence.cascade1829, %schedule.77
  %convergence.cascade.flow1833 = phi <8 x i1> [ %1877, %schedule.77 ], [ %9077, %convergence.cascade1829 ]
  %convergence.cascade.depth1834 = phi i32 [ 0, %schedule.77 ], [ %9078, %convergence.cascade1829 ]
  %9035 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1833)
  %9036 = load i32, ptr %current.token, align 4
  %9037 = icmp ne i32 %9036, 0
  %9038 = and i1 %9035, %9037
  %9039 = sub i32 %9036, 1
  %9040 = select i1 %9038, i32 %9039, i32 0
  %9041 = load i8, ptr %frame.active, align 1
  %9042 = trunc i32 %9040 to i8
  %9043 = shl i8 1, %9042
  %9044 = and i8 %9041, %9043
  %9045 = icmp ne i8 %9044, 0
  %9046 = load <8 x i32>, ptr %frame.static.id, align 32
  %9047 = extractelement <8 x i32> %9046, i32 %9040
  %convergence.target.pointer1835 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %9047
  %convergence.dynamic.target1836 = load i32, ptr %convergence.target.pointer1835, align 4
  %9048 = icmp eq i32 %convergence.dynamic.target1836, 77
  %9049 = and i1 %9045, %9048
  %9050 = and i1 %9038, %9049
  %9051 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9040
  %9052 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9040
  %9053 = load <8 x i1>, ptr %9051, align 1
  %9054 = load <8 x i1>, ptr %9052, align 1
  %9055 = or <8 x i1> %9054, %convergence.cascade.flow1833
  %9056 = load <8 x i1>, ptr %live.mask, align 1
  %9057 = and <8 x i1> %9053, %9056
  %9058 = icmp eq <8 x i1> %9055, %9057
  %9059 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9058)
  %9060 = and i1 %9050, %9059
  %9061 = select i1 %9060, <8 x i1> zeroinitializer, <8 x i1> %9055
  %9062 = select i1 %9050, <8 x i1> %9061, <8 x i1> %9054
  store <8 x i1> %9062, ptr %9052, align 1
  %9063 = select i1 %9060, <8 x i1> zeroinitializer, <8 x i1> %9053
  store <8 x i1> %9063, ptr %9051, align 1
  %9064 = trunc i32 %9040 to i8
  %9065 = shl i8 1, %9064
  %9066 = xor i8 %9065, -1
  %9067 = and i8 %9041, %9066
  %9068 = select i1 %9060, i8 %9067, i8 %9041
  store i8 %9068, ptr %frame.active, align 1
  %.splatinsert1837 = insertelement <8 x i1> poison, i1 %9050, i64 0
  %.splat1838 = shufflevector <8 x i1> %.splatinsert1837, <8 x i1> poison, <8 x i32> zeroinitializer
  %9069 = and <8 x i1> %convergence.cascade.flow1833, %.splat1838
  %9070 = load <8 x i1>, ptr %runnable.mask, align 1
  %9071 = xor <8 x i1> %9069, splat (i1 true)
  %9072 = and <8 x i1> %9070, %9071
  store <8 x i1> %9072, ptr %runnable.mask, align 1
  %.splatinsert1839 = insertelement <8 x i1> poison, i1 %9060, i64 0
  %.splat1840 = shufflevector <8 x i1> %.splatinsert1839, <8 x i1> poison, <8 x i32> zeroinitializer
  %9073 = select <8 x i1> %.splat1840, <8 x i1> %9055, <8 x i1> zeroinitializer
  %9074 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9075 = extractelement <8 x i32> %9074, i32 %9040
  %9076 = select i1 %9060, i32 %9075, i32 %9036
  store i32 %9076, ptr %current.token, align 4
  %.splatinsert1841 = insertelement <8 x i1> poison, i1 %9050, i64 0
  %.splat1842 = shufflevector <8 x i1> %.splatinsert1841, <8 x i1> poison, <8 x i32> zeroinitializer
  %9077 = select <8 x i1> %.splat1842, <8 x i1> %9073, <8 x i1> %convergence.cascade.flow1833
  %9078 = add i32 %convergence.cascade.depth1834, 1
  %9079 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9077)
  %9080 = icmp ult i32 %9078, 8
  %9081 = and i1 %9079, %9080
  %9082 = and i1 %9050, %9081
  %convergence.parent.token1843 = load i32, ptr %current.token, align 4
  %convergence.parent.present1844 = icmp ne i32 %convergence.parent.token1843, 0
  %9083 = and i1 %9082, %convergence.parent.present1844
  br i1 %9083, label %convergence.cascade1829, label %convergence.cascade.exit1830

convergence.cascade.exit1830:                     ; preds = %convergence.cascade1829, %schedule.77
  %convergence.cascade.result1845 = phi <8 x i1> [ %1877, %schedule.77 ], [ %9077, %convergence.cascade1829 ]
  %9084 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1845)
  br i1 %9084, label %convergence.target.77.ready, label %scheduler.loop

convergence.target.77.ready:                      ; preds = %convergence.cascade.exit1830
  %9085 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1845)
  %9086 = bitcast <8 x i1> %convergence.cascade.result1845 to i8
  %9087 = call i8 @llvm.cttz.i8(i8 %9086, i1 false)
  %9088 = zext i8 %9087 to i32
  %9089 = select i1 %9085, i32 %9088, i32 0
  %9090 = load <8 x i64>, ptr %.slot55, align 64
  %9091 = select <8 x i1> %convergence.cascade.result1845, <8 x i64> zeroinitializer, <8 x i64> %9090
  store <8 x i64> %9091, ptr %.slot55, align 64
  %9092 = load <8 x float>, ptr %.slot45, align 32
  %9093 = select <8 x i1> %convergence.cascade.result1845, <8 x float> zeroinitializer, <8 x float> %9092
  store <8 x float> %9093, ptr %.slot45, align 32
  store <8 x i1> %convergence.cascade.result1845, ptr %current.mask, align 1
  %9094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1845)
  br i1 %9094, label %schedule.78, label %scheduler.loop

varying.divergent1847:                            ; preds = %schedule.78
  %9095 = load i32, ptr %current.token, align 4
  %9096 = icmp ne i32 %9095, 0
  %9097 = sub i32 %9095, 1
  %9098 = select i1 %9096, i32 %9097, i32 0
  %9099 = load i8, ptr %frame.active, align 1
  %9100 = trunc i32 %9098 to i8
  %9101 = shl i8 1, %9100
  %9102 = and i8 %9099, %9101
  %9103 = icmp ne i8 %9102, 0
  %9104 = load <8 x i32>, ptr %frame.static.id, align 32
  %9105 = extractelement <8 x i32> %9104, i32 %9098
  %9106 = icmp eq i32 %9105, 27
  %9107 = and i1 %9103, %9106
  %9108 = and i1 %9096, %9107
  %9109 = xor i1 %9108, true
  %9110 = and i1 true, %9109
  %9111 = xor i8 %9099, -1
  %9112 = icmp ne i8 %9111, 0
  %9113 = xor i1 %9112, true
  %9114 = and i1 %9110, %9113
  br i1 %9114, label %convergence.overflow.trap1849, label %convergence.overflow.resume1850

varying.coherent1848:                             ; preds = %schedule.78
  br i1 %1888, label %varying.coherent.true1853, label %varying.coherent.false1854

convergence.overflow.trap1849:                    ; preds = %varying.divergent1847
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1850:                  ; preds = %varying.divergent1847
  %9115 = call i8 @llvm.cttz.i8(i8 %9111, i1 false)
  %9116 = zext i8 %9115 to i32
  %9117 = select i1 %9112, i32 %9116, i32 0
  %9118 = trunc i32 %9117 to i8
  %9119 = shl i8 1, %9118
  %9120 = or i8 %9099, %9119
  %9121 = select i1 %9110, i8 %9120, i8 %9099
  store i8 %9121, ptr %frame.active, align 1
  %9122 = load <8 x i32>, ptr %frame.static.id, align 32
  %9123 = extractelement <8 x i32> %9122, i32 %9117
  %9124 = select i1 %9110, i32 27, i32 %9123
  %9125 = load <8 x i32>, ptr %frame.static.id, align 32
  %9126 = insertelement <8 x i32> %9125, i32 %9124, i32 %9117
  store <8 x i32> %9126, ptr %frame.static.id, align 32
  %9127 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9128 = extractelement <8 x i32> %9127, i32 %9117
  %9129 = select i1 %9110, i32 %9095, i32 %9128
  %9130 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9131 = insertelement <8 x i32> %9130, i32 %9129, i32 %9117
  store <8 x i32> %9131, ptr %frame.parent.token, align 32
  %9132 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9117
  %9133 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9117
  %9134 = load <8 x i1>, ptr %9132, align 1
  %9135 = load <8 x i1>, ptr %9133, align 1
  %9136 = select i1 %9110, <8 x i1> %1878, <8 x i1> %9134
  store <8 x i1> %9136, ptr %9132, align 1
  %9137 = select i1 %9110, <8 x i1> zeroinitializer, <8 x i1> %9135
  store <8 x i1> %9137, ptr %9133, align 1
  %9138 = add i32 %9117, 1
  %9139 = select i1 %9108, i32 %9095, i32 %9138
  %9140 = select i1 true, i32 %9139, i32 %9095
  store i32 %9140, ptr %current.token, align 4
  %9141 = load i32, ptr %current.token, align 4
  %9142 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1885)
  %9143 = load i32, ptr %ready.count, align 4
  %9144 = icmp uge i32 %9143, 8
  %9145 = and i1 %9142, %9144
  br i1 %9145, label %ready.overflow.trap1851, label %ready.overflow.resume1852

ready.overflow.trap1851:                          ; preds = %convergence.overflow.resume1850
  call void @llvm.trap()
  unreachable

ready.overflow.resume1852:                        ; preds = %convergence.overflow.resume1850
  %9146 = select i1 %9142, i32 %9143, i32 0
  %9147 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9146
  %9148 = load <8 x i1>, ptr %9147, align 1
  %9149 = select i1 %9142, <8 x i1> %1885, <8 x i1> %9148
  store <8 x i1> %9149, ptr %9147, align 1
  %9150 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9146
  %9151 = load i32, ptr %9150, align 4
  %9152 = select i1 %9142, i32 79, i32 %9151
  store i32 %9152, ptr %9150, align 4
  %9153 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9146
  %9154 = load i32, ptr %9153, align 4
  %9155 = select i1 %9142, i32 %9141, i32 %9154
  store i32 %9155, ptr %9153, align 4
  %9156 = add i32 %9143, 1
  %9157 = select i1 %9142, i32 %9156, i32 %9143
  store i32 %9157, ptr %ready.count, align 4
  %9158 = load <8 x i1>, ptr %runnable.mask, align 1
  %9159 = or <8 x i1> %9158, %1885
  store <8 x i1> %9159, ptr %runnable.mask, align 1
  store <8 x i1> %1887, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1853:                        ; preds = %varying.coherent1848
  store <8 x i1> %1878, ptr %current.mask, align 1
  %9160 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1878)
  br i1 %9160, label %schedule.79, label %scheduler.loop

varying.coherent.false1854:                       ; preds = %varying.coherent1848
  store <8 x i1> %1878, ptr %current.mask, align 1
  %9161 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1878)
  br i1 %9161, label %schedule.80, label %scheduler.loop

convergence.cascade1859:                          ; preds = %convergence.cascade1859, %schedule.80
  %convergence.cascade.flow1863 = phi <8 x i1> [ %1918, %schedule.80 ], [ %9204, %convergence.cascade1859 ]
  %convergence.cascade.depth1864 = phi i32 [ 0, %schedule.80 ], [ %9205, %convergence.cascade1859 ]
  %9162 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1863)
  %9163 = load i32, ptr %current.token, align 4
  %9164 = icmp ne i32 %9163, 0
  %9165 = and i1 %9162, %9164
  %9166 = sub i32 %9163, 1
  %9167 = select i1 %9165, i32 %9166, i32 0
  %9168 = load i8, ptr %frame.active, align 1
  %9169 = trunc i32 %9167 to i8
  %9170 = shl i8 1, %9169
  %9171 = and i8 %9168, %9170
  %9172 = icmp ne i8 %9171, 0
  %9173 = load <8 x i32>, ptr %frame.static.id, align 32
  %9174 = extractelement <8 x i32> %9173, i32 %9167
  %convergence.target.pointer1865 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %9174
  %convergence.dynamic.target1866 = load i32, ptr %convergence.target.pointer1865, align 4
  %9175 = icmp eq i32 %convergence.dynamic.target1866, 80
  %9176 = and i1 %9172, %9175
  %9177 = and i1 %9165, %9176
  %9178 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9167
  %9179 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9167
  %9180 = load <8 x i1>, ptr %9178, align 1
  %9181 = load <8 x i1>, ptr %9179, align 1
  %9182 = or <8 x i1> %9181, %convergence.cascade.flow1863
  %9183 = load <8 x i1>, ptr %live.mask, align 1
  %9184 = and <8 x i1> %9180, %9183
  %9185 = icmp eq <8 x i1> %9182, %9184
  %9186 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9185)
  %9187 = and i1 %9177, %9186
  %9188 = select i1 %9187, <8 x i1> zeroinitializer, <8 x i1> %9182
  %9189 = select i1 %9177, <8 x i1> %9188, <8 x i1> %9181
  store <8 x i1> %9189, ptr %9179, align 1
  %9190 = select i1 %9187, <8 x i1> zeroinitializer, <8 x i1> %9180
  store <8 x i1> %9190, ptr %9178, align 1
  %9191 = trunc i32 %9167 to i8
  %9192 = shl i8 1, %9191
  %9193 = xor i8 %9192, -1
  %9194 = and i8 %9168, %9193
  %9195 = select i1 %9187, i8 %9194, i8 %9168
  store i8 %9195, ptr %frame.active, align 1
  %.splatinsert1867 = insertelement <8 x i1> poison, i1 %9177, i64 0
  %.splat1868 = shufflevector <8 x i1> %.splatinsert1867, <8 x i1> poison, <8 x i32> zeroinitializer
  %9196 = and <8 x i1> %convergence.cascade.flow1863, %.splat1868
  %9197 = load <8 x i1>, ptr %runnable.mask, align 1
  %9198 = xor <8 x i1> %9196, splat (i1 true)
  %9199 = and <8 x i1> %9197, %9198
  store <8 x i1> %9199, ptr %runnable.mask, align 1
  %.splatinsert1869 = insertelement <8 x i1> poison, i1 %9187, i64 0
  %.splat1870 = shufflevector <8 x i1> %.splatinsert1869, <8 x i1> poison, <8 x i32> zeroinitializer
  %9200 = select <8 x i1> %.splat1870, <8 x i1> %9182, <8 x i1> zeroinitializer
  %9201 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9202 = extractelement <8 x i32> %9201, i32 %9167
  %9203 = select i1 %9187, i32 %9202, i32 %9163
  store i32 %9203, ptr %current.token, align 4
  %.splatinsert1871 = insertelement <8 x i1> poison, i1 %9177, i64 0
  %.splat1872 = shufflevector <8 x i1> %.splatinsert1871, <8 x i1> poison, <8 x i32> zeroinitializer
  %9204 = select <8 x i1> %.splat1872, <8 x i1> %9200, <8 x i1> %convergence.cascade.flow1863
  %9205 = add i32 %convergence.cascade.depth1864, 1
  %9206 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9204)
  %9207 = icmp ult i32 %9205, 8
  %9208 = and i1 %9206, %9207
  %9209 = and i1 %9177, %9208
  %convergence.parent.token1873 = load i32, ptr %current.token, align 4
  %convergence.parent.present1874 = icmp ne i32 %convergence.parent.token1873, 0
  %9210 = and i1 %9209, %convergence.parent.present1874
  br i1 %9210, label %convergence.cascade1859, label %convergence.cascade.exit1860

convergence.cascade.exit1860:                     ; preds = %convergence.cascade1859, %schedule.80
  %convergence.cascade.result1875 = phi <8 x i1> [ %1918, %schedule.80 ], [ %9204, %convergence.cascade1859 ]
  %9211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1875)
  br i1 %9211, label %convergence.target.80.ready, label %scheduler.loop

convergence.target.80.ready:                      ; preds = %convergence.cascade.exit1860
  %9212 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1875)
  %9213 = bitcast <8 x i1> %convergence.cascade.result1875 to i8
  %9214 = call i8 @llvm.cttz.i8(i8 %9213, i1 false)
  %9215 = zext i8 %9214 to i32
  %9216 = select i1 %9212, i32 %9215, i32 0
  %9217 = load <8 x i64>, ptr %.slot55, align 64
  %9218 = select <8 x i1> %convergence.cascade.result1875, <8 x i64> zeroinitializer, <8 x i64> %9217
  store <8 x i64> %9218, ptr %.slot55, align 64
  %9219 = load <8 x float>, ptr %.slot46, align 32
  %9220 = select <8 x i1> %convergence.cascade.result1875, <8 x float> zeroinitializer, <8 x float> %9219
  store <8 x float> %9220, ptr %.slot46, align 32
  store <8 x i1> %convergence.cascade.result1875, ptr %current.mask, align 1
  %9221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1875)
  br i1 %9221, label %schedule.81, label %scheduler.loop

varying.divergent1877:                            ; preds = %schedule.81
  %9222 = load i32, ptr %current.token, align 4
  %9223 = icmp ne i32 %9222, 0
  %9224 = sub i32 %9222, 1
  %9225 = select i1 %9223, i32 %9224, i32 0
  %9226 = load i8, ptr %frame.active, align 1
  %9227 = trunc i32 %9225 to i8
  %9228 = shl i8 1, %9227
  %9229 = and i8 %9226, %9228
  %9230 = icmp ne i8 %9229, 0
  %9231 = load <8 x i32>, ptr %frame.static.id, align 32
  %9232 = extractelement <8 x i32> %9231, i32 %9225
  %9233 = icmp eq i32 %9232, 28
  %9234 = and i1 %9230, %9233
  %9235 = and i1 %9223, %9234
  %9236 = xor i1 %9235, true
  %9237 = and i1 true, %9236
  %9238 = xor i8 %9226, -1
  %9239 = icmp ne i8 %9238, 0
  %9240 = xor i1 %9239, true
  %9241 = and i1 %9237, %9240
  br i1 %9241, label %convergence.overflow.trap1879, label %convergence.overflow.resume1880

varying.coherent1878:                             ; preds = %schedule.81
  br i1 %1929, label %varying.coherent.true1883, label %varying.coherent.false1884

convergence.overflow.trap1879:                    ; preds = %varying.divergent1877
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1880:                  ; preds = %varying.divergent1877
  %9242 = call i8 @llvm.cttz.i8(i8 %9238, i1 false)
  %9243 = zext i8 %9242 to i32
  %9244 = select i1 %9239, i32 %9243, i32 0
  %9245 = trunc i32 %9244 to i8
  %9246 = shl i8 1, %9245
  %9247 = or i8 %9226, %9246
  %9248 = select i1 %9237, i8 %9247, i8 %9226
  store i8 %9248, ptr %frame.active, align 1
  %9249 = load <8 x i32>, ptr %frame.static.id, align 32
  %9250 = extractelement <8 x i32> %9249, i32 %9244
  %9251 = select i1 %9237, i32 28, i32 %9250
  %9252 = load <8 x i32>, ptr %frame.static.id, align 32
  %9253 = insertelement <8 x i32> %9252, i32 %9251, i32 %9244
  store <8 x i32> %9253, ptr %frame.static.id, align 32
  %9254 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9255 = extractelement <8 x i32> %9254, i32 %9244
  %9256 = select i1 %9237, i32 %9222, i32 %9255
  %9257 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9258 = insertelement <8 x i32> %9257, i32 %9256, i32 %9244
  store <8 x i32> %9258, ptr %frame.parent.token, align 32
  %9259 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9244
  %9260 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9244
  %9261 = load <8 x i1>, ptr %9259, align 1
  %9262 = load <8 x i1>, ptr %9260, align 1
  %9263 = select i1 %9237, <8 x i1> %1919, <8 x i1> %9261
  store <8 x i1> %9263, ptr %9259, align 1
  %9264 = select i1 %9237, <8 x i1> zeroinitializer, <8 x i1> %9262
  store <8 x i1> %9264, ptr %9260, align 1
  %9265 = add i32 %9244, 1
  %9266 = select i1 %9235, i32 %9222, i32 %9265
  %9267 = select i1 true, i32 %9266, i32 %9222
  store i32 %9267, ptr %current.token, align 4
  %9268 = load i32, ptr %current.token, align 4
  %9269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1926)
  %9270 = load i32, ptr %ready.count, align 4
  %9271 = icmp uge i32 %9270, 8
  %9272 = and i1 %9269, %9271
  br i1 %9272, label %ready.overflow.trap1881, label %ready.overflow.resume1882

ready.overflow.trap1881:                          ; preds = %convergence.overflow.resume1880
  call void @llvm.trap()
  unreachable

ready.overflow.resume1882:                        ; preds = %convergence.overflow.resume1880
  %9273 = select i1 %9269, i32 %9270, i32 0
  %9274 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9273
  %9275 = load <8 x i1>, ptr %9274, align 1
  %9276 = select i1 %9269, <8 x i1> %1926, <8 x i1> %9275
  store <8 x i1> %9276, ptr %9274, align 1
  %9277 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9273
  %9278 = load i32, ptr %9277, align 4
  %9279 = select i1 %9269, i32 82, i32 %9278
  store i32 %9279, ptr %9277, align 4
  %9280 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9273
  %9281 = load i32, ptr %9280, align 4
  %9282 = select i1 %9269, i32 %9268, i32 %9281
  store i32 %9282, ptr %9280, align 4
  %9283 = add i32 %9270, 1
  %9284 = select i1 %9269, i32 %9283, i32 %9270
  store i32 %9284, ptr %ready.count, align 4
  %9285 = load <8 x i1>, ptr %runnable.mask, align 1
  %9286 = or <8 x i1> %9285, %1926
  store <8 x i1> %9286, ptr %runnable.mask, align 1
  store <8 x i1> %1928, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1883:                        ; preds = %varying.coherent1878
  store <8 x i1> %1919, ptr %current.mask, align 1
  %9287 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1919)
  br i1 %9287, label %schedule.82, label %scheduler.loop

varying.coherent.false1884:                       ; preds = %varying.coherent1878
  store <8 x i1> %1919, ptr %current.mask, align 1
  %9288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1919)
  br i1 %9288, label %schedule.83, label %scheduler.loop

convergence.cascade1889:                          ; preds = %convergence.cascade1889, %schedule.83
  %convergence.cascade.flow1893 = phi <8 x i1> [ %1959, %schedule.83 ], [ %9331, %convergence.cascade1889 ]
  %convergence.cascade.depth1894 = phi i32 [ 0, %schedule.83 ], [ %9332, %convergence.cascade1889 ]
  %9289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1893)
  %9290 = load i32, ptr %current.token, align 4
  %9291 = icmp ne i32 %9290, 0
  %9292 = and i1 %9289, %9291
  %9293 = sub i32 %9290, 1
  %9294 = select i1 %9292, i32 %9293, i32 0
  %9295 = load i8, ptr %frame.active, align 1
  %9296 = trunc i32 %9294 to i8
  %9297 = shl i8 1, %9296
  %9298 = and i8 %9295, %9297
  %9299 = icmp ne i8 %9298, 0
  %9300 = load <8 x i32>, ptr %frame.static.id, align 32
  %9301 = extractelement <8 x i32> %9300, i32 %9294
  %convergence.target.pointer1895 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %9301
  %convergence.dynamic.target1896 = load i32, ptr %convergence.target.pointer1895, align 4
  %9302 = icmp eq i32 %convergence.dynamic.target1896, 83
  %9303 = and i1 %9299, %9302
  %9304 = and i1 %9292, %9303
  %9305 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9294
  %9306 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9294
  %9307 = load <8 x i1>, ptr %9305, align 1
  %9308 = load <8 x i1>, ptr %9306, align 1
  %9309 = or <8 x i1> %9308, %convergence.cascade.flow1893
  %9310 = load <8 x i1>, ptr %live.mask, align 1
  %9311 = and <8 x i1> %9307, %9310
  %9312 = icmp eq <8 x i1> %9309, %9311
  %9313 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9312)
  %9314 = and i1 %9304, %9313
  %9315 = select i1 %9314, <8 x i1> zeroinitializer, <8 x i1> %9309
  %9316 = select i1 %9304, <8 x i1> %9315, <8 x i1> %9308
  store <8 x i1> %9316, ptr %9306, align 1
  %9317 = select i1 %9314, <8 x i1> zeroinitializer, <8 x i1> %9307
  store <8 x i1> %9317, ptr %9305, align 1
  %9318 = trunc i32 %9294 to i8
  %9319 = shl i8 1, %9318
  %9320 = xor i8 %9319, -1
  %9321 = and i8 %9295, %9320
  %9322 = select i1 %9314, i8 %9321, i8 %9295
  store i8 %9322, ptr %frame.active, align 1
  %.splatinsert1897 = insertelement <8 x i1> poison, i1 %9304, i64 0
  %.splat1898 = shufflevector <8 x i1> %.splatinsert1897, <8 x i1> poison, <8 x i32> zeroinitializer
  %9323 = and <8 x i1> %convergence.cascade.flow1893, %.splat1898
  %9324 = load <8 x i1>, ptr %runnable.mask, align 1
  %9325 = xor <8 x i1> %9323, splat (i1 true)
  %9326 = and <8 x i1> %9324, %9325
  store <8 x i1> %9326, ptr %runnable.mask, align 1
  %.splatinsert1899 = insertelement <8 x i1> poison, i1 %9314, i64 0
  %.splat1900 = shufflevector <8 x i1> %.splatinsert1899, <8 x i1> poison, <8 x i32> zeroinitializer
  %9327 = select <8 x i1> %.splat1900, <8 x i1> %9309, <8 x i1> zeroinitializer
  %9328 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9329 = extractelement <8 x i32> %9328, i32 %9294
  %9330 = select i1 %9314, i32 %9329, i32 %9290
  store i32 %9330, ptr %current.token, align 4
  %.splatinsert1901 = insertelement <8 x i1> poison, i1 %9304, i64 0
  %.splat1902 = shufflevector <8 x i1> %.splatinsert1901, <8 x i1> poison, <8 x i32> zeroinitializer
  %9331 = select <8 x i1> %.splat1902, <8 x i1> %9327, <8 x i1> %convergence.cascade.flow1893
  %9332 = add i32 %convergence.cascade.depth1894, 1
  %9333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9331)
  %9334 = icmp ult i32 %9332, 8
  %9335 = and i1 %9333, %9334
  %9336 = and i1 %9304, %9335
  %convergence.parent.token1903 = load i32, ptr %current.token, align 4
  %convergence.parent.present1904 = icmp ne i32 %convergence.parent.token1903, 0
  %9337 = and i1 %9336, %convergence.parent.present1904
  br i1 %9337, label %convergence.cascade1889, label %convergence.cascade.exit1890

convergence.cascade.exit1890:                     ; preds = %convergence.cascade1889, %schedule.83
  %convergence.cascade.result1905 = phi <8 x i1> [ %1959, %schedule.83 ], [ %9331, %convergence.cascade1889 ]
  %9338 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1905)
  br i1 %9338, label %convergence.target.83.ready, label %scheduler.loop

convergence.target.83.ready:                      ; preds = %convergence.cascade.exit1890
  %9339 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1905)
  %9340 = bitcast <8 x i1> %convergence.cascade.result1905 to i8
  %9341 = call i8 @llvm.cttz.i8(i8 %9340, i1 false)
  %9342 = zext i8 %9341 to i32
  %9343 = select i1 %9339, i32 %9342, i32 0
  %.spill.load1906 = load <8 x float>, ptr %.spill278, align 32
  %.state1907 = load <8 x float>, ptr %.slot43, align 32
  %9344 = fadd <8 x float> %.spill.load1906, %.state1907
  %9345 = load <8 x float>, ptr %.spill290, align 32
  %9346 = select <8 x i1> %convergence.cascade.result1905, <8 x float> %9344, <8 x float> %9345
  store <8 x float> %9346, ptr %.spill290, align 32
  %.spill.load1908 = load <8 x float>, ptr %.spill279, align 32
  %.state1909 = load <8 x float>, ptr %.slot44, align 32
  %9347 = fadd <8 x float> %.spill.load1908, %.state1909
  %9348 = load <8 x float>, ptr %.spill291, align 32
  %9349 = select <8 x i1> %convergence.cascade.result1905, <8 x float> %9347, <8 x float> %9348
  store <8 x float> %9349, ptr %.spill291, align 32
  %.spill.load1910 = load <8 x float>, ptr %.spill280, align 32
  %.state1911 = load <8 x float>, ptr %.slot45, align 32
  %9350 = fadd <8 x float> %.spill.load1910, %.state1911
  %9351 = load <8 x float>, ptr %.spill292, align 32
  %9352 = select <8 x i1> %convergence.cascade.result1905, <8 x float> %9350, <8 x float> %9351
  store <8 x float> %9352, ptr %.spill292, align 32
  %.spill.load1912 = load <8 x float>, ptr %.spill281, align 32
  %.state1913 = load <8 x float>, ptr %.slot46, align 32
  %9353 = fadd <8 x float> %.spill.load1912, %.state1913
  %9354 = load <8 x float>, ptr %.spill293, align 32
  %9355 = select <8 x i1> %convergence.cascade.result1905, <8 x float> %9353, <8 x float> %9354
  store <8 x float> %9355, ptr %.spill293, align 32
  %9356 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill294, align 64
  %9357 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %9358 = extractvalue { <8 x ptr>, <8 x i64> } %9356, 0
  %9359 = select <8 x i1> %convergence.cascade.result1905, <8 x ptr> %9357, <8 x ptr> %9358
  %9360 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %9361 = extractvalue { <8 x ptr>, <8 x i64> } %9356, 1
  %9362 = select <8 x i1> %convergence.cascade.result1905, <8 x i64> %9360, <8 x i64> %9361
  %9363 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9359, 0
  %9364 = insertvalue { <8 x ptr>, <8 x i64> } %9363, <8 x i64> %9362, 1
  store { <8 x ptr>, <8 x i64> } %9364, ptr %tile_snapshot.spill294, align 64
  %9365 = load <8 x i64>, ptr %.slot55, align 64
  %9366 = select <8 x i1> %convergence.cascade.result1905, <8 x i64> zeroinitializer, <8 x i64> %9365
  store <8 x i64> %9366, ptr %.slot55, align 64
  store <8 x i1> %convergence.cascade.result1905, ptr %current.mask, align 1
  %9367 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1905)
  br i1 %9367, label %schedule.84, label %scheduler.loop

varying.divergent1915:                            ; preds = %schedule.84
  %9368 = load i32, ptr %current.token, align 4
  %9369 = icmp ne i32 %9368, 0
  %9370 = sub i32 %9368, 1
  %9371 = select i1 %9369, i32 %9370, i32 0
  %9372 = load i8, ptr %frame.active, align 1
  %9373 = trunc i32 %9371 to i8
  %9374 = shl i8 1, %9373
  %9375 = and i8 %9372, %9374
  %9376 = icmp ne i8 %9375, 0
  %9377 = load <8 x i32>, ptr %frame.static.id, align 32
  %9378 = extractelement <8 x i32> %9377, i32 %9371
  %9379 = icmp eq i32 %9378, 29
  %9380 = and i1 %9376, %9379
  %9381 = and i1 %9369, %9380
  %9382 = xor i1 %9381, true
  %9383 = and i1 true, %9382
  %9384 = xor i8 %9372, -1
  %9385 = icmp ne i8 %9384, 0
  %9386 = xor i1 %9385, true
  %9387 = and i1 %9383, %9386
  br i1 %9387, label %convergence.overflow.trap1917, label %convergence.overflow.resume1918

varying.coherent1916:                             ; preds = %schedule.84
  br i1 %1970, label %varying.coherent.true1921, label %varying.coherent.false1922

convergence.overflow.trap1917:                    ; preds = %varying.divergent1915
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1918:                  ; preds = %varying.divergent1915
  %9388 = call i8 @llvm.cttz.i8(i8 %9384, i1 false)
  %9389 = zext i8 %9388 to i32
  %9390 = select i1 %9385, i32 %9389, i32 0
  %9391 = trunc i32 %9390 to i8
  %9392 = shl i8 1, %9391
  %9393 = or i8 %9372, %9392
  %9394 = select i1 %9383, i8 %9393, i8 %9372
  store i8 %9394, ptr %frame.active, align 1
  %9395 = load <8 x i32>, ptr %frame.static.id, align 32
  %9396 = extractelement <8 x i32> %9395, i32 %9390
  %9397 = select i1 %9383, i32 29, i32 %9396
  %9398 = load <8 x i32>, ptr %frame.static.id, align 32
  %9399 = insertelement <8 x i32> %9398, i32 %9397, i32 %9390
  store <8 x i32> %9399, ptr %frame.static.id, align 32
  %9400 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9401 = extractelement <8 x i32> %9400, i32 %9390
  %9402 = select i1 %9383, i32 %9368, i32 %9401
  %9403 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9404 = insertelement <8 x i32> %9403, i32 %9402, i32 %9390
  store <8 x i32> %9404, ptr %frame.parent.token, align 32
  %9405 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9390
  %9406 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9390
  %9407 = load <8 x i1>, ptr %9405, align 1
  %9408 = load <8 x i1>, ptr %9406, align 1
  %9409 = select i1 %9383, <8 x i1> %1960, <8 x i1> %9407
  store <8 x i1> %9409, ptr %9405, align 1
  %9410 = select i1 %9383, <8 x i1> zeroinitializer, <8 x i1> %9408
  store <8 x i1> %9410, ptr %9406, align 1
  %9411 = add i32 %9390, 1
  %9412 = select i1 %9381, i32 %9368, i32 %9411
  %9413 = select i1 true, i32 %9412, i32 %9368
  store i32 %9413, ptr %current.token, align 4
  %9414 = load i32, ptr %current.token, align 4
  %9415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1967)
  %9416 = load i32, ptr %ready.count, align 4
  %9417 = icmp uge i32 %9416, 8
  %9418 = and i1 %9415, %9417
  br i1 %9418, label %ready.overflow.trap1919, label %ready.overflow.resume1920

ready.overflow.trap1919:                          ; preds = %convergence.overflow.resume1918
  call void @llvm.trap()
  unreachable

ready.overflow.resume1920:                        ; preds = %convergence.overflow.resume1918
  %9419 = select i1 %9415, i32 %9416, i32 0
  %9420 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9419
  %9421 = load <8 x i1>, ptr %9420, align 1
  %9422 = select i1 %9415, <8 x i1> %1967, <8 x i1> %9421
  store <8 x i1> %9422, ptr %9420, align 1
  %9423 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9419
  %9424 = load i32, ptr %9423, align 4
  %9425 = select i1 %9415, i32 85, i32 %9424
  store i32 %9425, ptr %9423, align 4
  %9426 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9419
  %9427 = load i32, ptr %9426, align 4
  %9428 = select i1 %9415, i32 %9414, i32 %9427
  store i32 %9428, ptr %9426, align 4
  %9429 = add i32 %9416, 1
  %9430 = select i1 %9415, i32 %9429, i32 %9416
  store i32 %9430, ptr %ready.count, align 4
  %9431 = load <8 x i1>, ptr %runnable.mask, align 1
  %9432 = or <8 x i1> %9431, %1967
  store <8 x i1> %9432, ptr %runnable.mask, align 1
  store <8 x i1> %1969, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1921:                        ; preds = %varying.coherent1916
  store <8 x i1> %1960, ptr %current.mask, align 1
  %9433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1960)
  br i1 %9433, label %schedule.85, label %scheduler.loop

varying.coherent.false1922:                       ; preds = %varying.coherent1916
  store <8 x i1> %1960, ptr %current.mask, align 1
  %9434 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1960)
  br i1 %9434, label %schedule.92, label %scheduler.loop

varying.divergent1925:                            ; preds = %schedule.86
  %9435 = load i32, ptr %current.token, align 4
  %9436 = icmp ne i32 %9435, 0
  %9437 = sub i32 %9435, 1
  %9438 = select i1 %9436, i32 %9437, i32 0
  %9439 = load i8, ptr %frame.active, align 1
  %9440 = trunc i32 %9438 to i8
  %9441 = shl i8 1, %9440
  %9442 = and i8 %9439, %9441
  %9443 = icmp ne i8 %9442, 0
  %9444 = load <8 x i32>, ptr %frame.static.id, align 32
  %9445 = extractelement <8 x i32> %9444, i32 %9438
  %9446 = icmp eq i32 %9445, 30
  %9447 = and i1 %9443, %9446
  %9448 = and i1 %9436, %9447
  %9449 = xor i1 %9448, true
  %9450 = and i1 true, %9449
  %9451 = xor i8 %9439, -1
  %9452 = icmp ne i8 %9451, 0
  %9453 = xor i1 %9452, true
  %9454 = and i1 %9450, %9453
  br i1 %9454, label %convergence.overflow.trap1927, label %convergence.overflow.resume1928

varying.coherent1926:                             ; preds = %schedule.86
  br i1 %1995, label %varying.coherent.true1931, label %varying.coherent.false1932

convergence.overflow.trap1927:                    ; preds = %varying.divergent1925
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1928:                  ; preds = %varying.divergent1925
  %9455 = call i8 @llvm.cttz.i8(i8 %9451, i1 false)
  %9456 = zext i8 %9455 to i32
  %9457 = select i1 %9452, i32 %9456, i32 0
  %9458 = trunc i32 %9457 to i8
  %9459 = shl i8 1, %9458
  %9460 = or i8 %9439, %9459
  %9461 = select i1 %9450, i8 %9460, i8 %9439
  store i8 %9461, ptr %frame.active, align 1
  %9462 = load <8 x i32>, ptr %frame.static.id, align 32
  %9463 = extractelement <8 x i32> %9462, i32 %9457
  %9464 = select i1 %9450, i32 30, i32 %9463
  %9465 = load <8 x i32>, ptr %frame.static.id, align 32
  %9466 = insertelement <8 x i32> %9465, i32 %9464, i32 %9457
  store <8 x i32> %9466, ptr %frame.static.id, align 32
  %9467 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9468 = extractelement <8 x i32> %9467, i32 %9457
  %9469 = select i1 %9450, i32 %9435, i32 %9468
  %9470 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9471 = insertelement <8 x i32> %9470, i32 %9469, i32 %9457
  store <8 x i32> %9471, ptr %frame.parent.token, align 32
  %9472 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9457
  %9473 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9457
  %9474 = load <8 x i1>, ptr %9472, align 1
  %9475 = load <8 x i1>, ptr %9473, align 1
  %9476 = select i1 %9450, <8 x i1> %1985, <8 x i1> %9474
  store <8 x i1> %9476, ptr %9472, align 1
  %9477 = select i1 %9450, <8 x i1> zeroinitializer, <8 x i1> %9475
  store <8 x i1> %9477, ptr %9473, align 1
  %9478 = add i32 %9457, 1
  %9479 = select i1 %9448, i32 %9435, i32 %9478
  %9480 = select i1 true, i32 %9479, i32 %9435
  store i32 %9480, ptr %current.token, align 4
  %9481 = load i32, ptr %current.token, align 4
  %9482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1992)
  %9483 = load i32, ptr %ready.count, align 4
  %9484 = icmp uge i32 %9483, 8
  %9485 = and i1 %9482, %9484
  br i1 %9485, label %ready.overflow.trap1929, label %ready.overflow.resume1930

ready.overflow.trap1929:                          ; preds = %convergence.overflow.resume1928
  call void @llvm.trap()
  unreachable

ready.overflow.resume1930:                        ; preds = %convergence.overflow.resume1928
  %9486 = select i1 %9482, i32 %9483, i32 0
  %9487 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9486
  %9488 = load <8 x i1>, ptr %9487, align 1
  %9489 = select i1 %9482, <8 x i1> %1992, <8 x i1> %9488
  store <8 x i1> %9489, ptr %9487, align 1
  %9490 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9486
  %9491 = load i32, ptr %9490, align 4
  %9492 = select i1 %9482, i32 87, i32 %9491
  store i32 %9492, ptr %9490, align 4
  %9493 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9486
  %9494 = load i32, ptr %9493, align 4
  %9495 = select i1 %9482, i32 %9481, i32 %9494
  store i32 %9495, ptr %9493, align 4
  %9496 = add i32 %9483, 1
  %9497 = select i1 %9482, i32 %9496, i32 %9483
  store i32 %9497, ptr %ready.count, align 4
  %9498 = load <8 x i1>, ptr %runnable.mask, align 1
  %9499 = or <8 x i1> %9498, %1992
  store <8 x i1> %9499, ptr %runnable.mask, align 1
  store <8 x i1> %1994, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1931:                        ; preds = %varying.coherent1926
  store <8 x i1> %1985, ptr %current.mask, align 1
  %9500 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1985)
  br i1 %9500, label %schedule.87, label %scheduler.loop

varying.coherent.false1932:                       ; preds = %varying.coherent1926
  store <8 x i1> %1985, ptr %current.mask, align 1
  %9501 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1985)
  br i1 %9501, label %schedule.91, label %scheduler.loop

varying.divergent1944:                            ; preds = %schedule.88
  %9502 = load i32, ptr %current.token, align 4
  %9503 = icmp ne i32 %9502, 0
  %9504 = sub i32 %9502, 1
  %9505 = select i1 %9503, i32 %9504, i32 0
  %9506 = load i8, ptr %frame.active, align 1
  %9507 = trunc i32 %9505 to i8
  %9508 = shl i8 1, %9507
  %9509 = and i8 %9506, %9508
  %9510 = icmp ne i8 %9509, 0
  %9511 = load <8 x i32>, ptr %frame.static.id, align 32
  %9512 = extractelement <8 x i32> %9511, i32 %9505
  %9513 = icmp eq i32 %9512, 31
  %9514 = and i1 %9510, %9513
  %9515 = and i1 %9503, %9514
  %9516 = xor i1 %9515, true
  %9517 = and i1 true, %9516
  %9518 = xor i8 %9506, -1
  %9519 = icmp ne i8 %9518, 0
  %9520 = xor i1 %9519, true
  %9521 = and i1 %9517, %9520
  br i1 %9521, label %convergence.overflow.trap1946, label %convergence.overflow.resume1947

varying.coherent1945:                             ; preds = %schedule.88
  br i1 %2169, label %varying.coherent.true1950, label %varying.coherent.false1951

convergence.overflow.trap1946:                    ; preds = %varying.divergent1944
  call void @llvm.trap()
  unreachable

convergence.overflow.resume1947:                  ; preds = %varying.divergent1944
  %9522 = call i8 @llvm.cttz.i8(i8 %9518, i1 false)
  %9523 = zext i8 %9522 to i32
  %9524 = select i1 %9519, i32 %9523, i32 0
  %9525 = trunc i32 %9524 to i8
  %9526 = shl i8 1, %9525
  %9527 = or i8 %9506, %9526
  %9528 = select i1 %9517, i8 %9527, i8 %9506
  store i8 %9528, ptr %frame.active, align 1
  %9529 = load <8 x i32>, ptr %frame.static.id, align 32
  %9530 = extractelement <8 x i32> %9529, i32 %9524
  %9531 = select i1 %9517, i32 31, i32 %9530
  %9532 = load <8 x i32>, ptr %frame.static.id, align 32
  %9533 = insertelement <8 x i32> %9532, i32 %9531, i32 %9524
  store <8 x i32> %9533, ptr %frame.static.id, align 32
  %9534 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9535 = extractelement <8 x i32> %9534, i32 %9524
  %9536 = select i1 %9517, i32 %9502, i32 %9535
  %9537 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9538 = insertelement <8 x i32> %9537, i32 %9536, i32 %9524
  store <8 x i32> %9538, ptr %frame.parent.token, align 32
  %9539 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9524
  %9540 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9524
  %9541 = load <8 x i1>, ptr %9539, align 1
  %9542 = load <8 x i1>, ptr %9540, align 1
  %9543 = select i1 %9517, <8 x i1> %2159, <8 x i1> %9541
  store <8 x i1> %9543, ptr %9539, align 1
  %9544 = select i1 %9517, <8 x i1> zeroinitializer, <8 x i1> %9542
  store <8 x i1> %9544, ptr %9540, align 1
  %9545 = add i32 %9524, 1
  %9546 = select i1 %9515, i32 %9502, i32 %9545
  %9547 = select i1 true, i32 %9546, i32 %9502
  store i32 %9547, ptr %current.token, align 4
  %9548 = load i32, ptr %current.token, align 4
  %9549 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2166)
  %9550 = load i32, ptr %ready.count, align 4
  %9551 = icmp uge i32 %9550, 8
  %9552 = and i1 %9549, %9551
  br i1 %9552, label %ready.overflow.trap1948, label %ready.overflow.resume1949

ready.overflow.trap1948:                          ; preds = %convergence.overflow.resume1947
  call void @llvm.trap()
  unreachable

ready.overflow.resume1949:                        ; preds = %convergence.overflow.resume1947
  %9553 = select i1 %9549, i32 %9550, i32 0
  %9554 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9553
  %9555 = load <8 x i1>, ptr %9554, align 1
  %9556 = select i1 %9549, <8 x i1> %2166, <8 x i1> %9555
  store <8 x i1> %9556, ptr %9554, align 1
  %9557 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9553
  %9558 = load i32, ptr %9557, align 4
  %9559 = select i1 %9549, i32 89, i32 %9558
  store i32 %9559, ptr %9557, align 4
  %9560 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9553
  %9561 = load i32, ptr %9560, align 4
  %9562 = select i1 %9549, i32 %9548, i32 %9561
  store i32 %9562, ptr %9560, align 4
  %9563 = add i32 %9550, 1
  %9564 = select i1 %9549, i32 %9563, i32 %9550
  store i32 %9564, ptr %ready.count, align 4
  %9565 = load <8 x i1>, ptr %runnable.mask, align 1
  %9566 = or <8 x i1> %9565, %2166
  store <8 x i1> %9566, ptr %runnable.mask, align 1
  store <8 x i1> %2168, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true1950:                        ; preds = %varying.coherent1945
  store <8 x i1> %2159, ptr %current.mask, align 1
  %9567 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2159)
  br i1 %9567, label %schedule.89, label %scheduler.loop

varying.coherent.false1951:                       ; preds = %varying.coherent1945
  store <8 x i1> %2159, ptr %current.mask, align 1
  %9568 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2159)
  br i1 %9568, label %schedule.90, label %scheduler.loop

convergence.cascade1968:                          ; preds = %convergence.cascade1968, %schedule.90
  %convergence.cascade.flow1972 = phi <8 x i1> [ %2246, %schedule.90 ], [ %9611, %convergence.cascade1968 ]
  %convergence.cascade.depth1973 = phi i32 [ 0, %schedule.90 ], [ %9612, %convergence.cascade1968 ]
  %9569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow1972)
  %9570 = load i32, ptr %current.token, align 4
  %9571 = icmp ne i32 %9570, 0
  %9572 = and i1 %9569, %9571
  %9573 = sub i32 %9570, 1
  %9574 = select i1 %9572, i32 %9573, i32 0
  %9575 = load i8, ptr %frame.active, align 1
  %9576 = trunc i32 %9574 to i8
  %9577 = shl i8 1, %9576
  %9578 = and i8 %9575, %9577
  %9579 = icmp ne i8 %9578, 0
  %9580 = load <8 x i32>, ptr %frame.static.id, align 32
  %9581 = extractelement <8 x i32> %9580, i32 %9574
  %convergence.target.pointer1974 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %9581
  %convergence.dynamic.target1975 = load i32, ptr %convergence.target.pointer1974, align 4
  %9582 = icmp eq i32 %convergence.dynamic.target1975, 90
  %9583 = and i1 %9579, %9582
  %9584 = and i1 %9572, %9583
  %9585 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9574
  %9586 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9574
  %9587 = load <8 x i1>, ptr %9585, align 1
  %9588 = load <8 x i1>, ptr %9586, align 1
  %9589 = or <8 x i1> %9588, %convergence.cascade.flow1972
  %9590 = load <8 x i1>, ptr %live.mask, align 1
  %9591 = and <8 x i1> %9587, %9590
  %9592 = icmp eq <8 x i1> %9589, %9591
  %9593 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9592)
  %9594 = and i1 %9584, %9593
  %9595 = select i1 %9594, <8 x i1> zeroinitializer, <8 x i1> %9589
  %9596 = select i1 %9584, <8 x i1> %9595, <8 x i1> %9588
  store <8 x i1> %9596, ptr %9586, align 1
  %9597 = select i1 %9594, <8 x i1> zeroinitializer, <8 x i1> %9587
  store <8 x i1> %9597, ptr %9585, align 1
  %9598 = trunc i32 %9574 to i8
  %9599 = shl i8 1, %9598
  %9600 = xor i8 %9599, -1
  %9601 = and i8 %9575, %9600
  %9602 = select i1 %9594, i8 %9601, i8 %9575
  store i8 %9602, ptr %frame.active, align 1
  %.splatinsert1976 = insertelement <8 x i1> poison, i1 %9584, i64 0
  %.splat1977 = shufflevector <8 x i1> %.splatinsert1976, <8 x i1> poison, <8 x i32> zeroinitializer
  %9603 = and <8 x i1> %convergence.cascade.flow1972, %.splat1977
  %9604 = load <8 x i1>, ptr %runnable.mask, align 1
  %9605 = xor <8 x i1> %9603, splat (i1 true)
  %9606 = and <8 x i1> %9604, %9605
  store <8 x i1> %9606, ptr %runnable.mask, align 1
  %.splatinsert1978 = insertelement <8 x i1> poison, i1 %9594, i64 0
  %.splat1979 = shufflevector <8 x i1> %.splatinsert1978, <8 x i1> poison, <8 x i32> zeroinitializer
  %9607 = select <8 x i1> %.splat1979, <8 x i1> %9589, <8 x i1> zeroinitializer
  %9608 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9609 = extractelement <8 x i32> %9608, i32 %9574
  %9610 = select i1 %9594, i32 %9609, i32 %9570
  store i32 %9610, ptr %current.token, align 4
  %.splatinsert1980 = insertelement <8 x i1> poison, i1 %9584, i64 0
  %.splat1981 = shufflevector <8 x i1> %.splatinsert1980, <8 x i1> poison, <8 x i32> zeroinitializer
  %9611 = select <8 x i1> %.splat1981, <8 x i1> %9607, <8 x i1> %convergence.cascade.flow1972
  %9612 = add i32 %convergence.cascade.depth1973, 1
  %9613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9611)
  %9614 = icmp ult i32 %9612, 8
  %9615 = and i1 %9613, %9614
  %9616 = and i1 %9584, %9615
  %convergence.parent.token1982 = load i32, ptr %current.token, align 4
  %convergence.parent.present1983 = icmp ne i32 %convergence.parent.token1982, 0
  %9617 = and i1 %9616, %convergence.parent.present1983
  br i1 %9617, label %convergence.cascade1968, label %convergence.cascade.exit1969

convergence.cascade.exit1969:                     ; preds = %convergence.cascade1968, %schedule.90
  %convergence.cascade.result1984 = phi <8 x i1> [ %2246, %schedule.90 ], [ %9611, %convergence.cascade1968 ]
  %9618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1984)
  br i1 %9618, label %convergence.target.90.ready, label %scheduler.loop

convergence.target.90.ready:                      ; preds = %convergence.cascade.exit1969
  %9619 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1984)
  %9620 = bitcast <8 x i1> %convergence.cascade.result1984 to i8
  %9621 = call i8 @llvm.cttz.i8(i8 %9620, i1 false)
  %9622 = zext i8 %9621 to i32
  %9623 = select i1 %9619, i32 %9622, i32 0
  %tile_snapshot.spill.load1985 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill294, align 64
  %9624 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1985, 0
  %9625 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1985, 1
  %.spill.load1986 = load <8 x i64>, ptr %.spill298, align 64
  %9626 = mul <8 x i64> %.spill.load1986, splat (i64 32)
  %9627 = add <8 x i64> %9625, %9626
  %9628 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9624, 0
  %9629 = insertvalue { <8 x ptr>, <8 x i64> } %9628, <8 x i64> %9627, 1
  %.state1987 = load <8 x float>, ptr %.slot43, align 32
  %9630 = extractvalue { <8 x ptr>, <8 x i64> } %9629, 0
  %9631 = extractvalue { <8 x ptr>, <8 x i64> } %9629, 1
  %9632 = getelementptr i8, <8 x ptr> %9630, <8 x i64> %9631
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1987, <8 x ptr> align 1 %9632, <8 x i1> %convergence.cascade.result1984)
  %tile_snapshot.spill.load1988 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill294, align 64
  %9633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1988, 0
  %9634 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1988, 1
  %.spill.load1989 = load <8 x i64>, ptr %.spill301, align 64
  %9635 = mul <8 x i64> %.spill.load1989, splat (i64 32)
  %9636 = add <8 x i64> %9634, %9635
  %9637 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9633, 0
  %9638 = insertvalue { <8 x ptr>, <8 x i64> } %9637, <8 x i64> %9636, 1
  %.state1990 = load <8 x float>, ptr %.slot44, align 32
  %9639 = extractvalue { <8 x ptr>, <8 x i64> } %9638, 0
  %9640 = extractvalue { <8 x ptr>, <8 x i64> } %9638, 1
  %9641 = getelementptr i8, <8 x ptr> %9639, <8 x i64> %9640
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1990, <8 x ptr> align 1 %9641, <8 x i1> %convergence.cascade.result1984)
  %tile_snapshot.spill.load1991 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill294, align 64
  %9642 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1991, 0
  %9643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1991, 1
  %.spill.load1992 = load <8 x i64>, ptr %.spill303, align 64
  %9644 = mul <8 x i64> %.spill.load1992, splat (i64 32)
  %9645 = add <8 x i64> %9643, %9644
  %9646 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9642, 0
  %9647 = insertvalue { <8 x ptr>, <8 x i64> } %9646, <8 x i64> %9645, 1
  %.state1993 = load <8 x float>, ptr %.slot45, align 32
  %9648 = extractvalue { <8 x ptr>, <8 x i64> } %9647, 0
  %9649 = extractvalue { <8 x ptr>, <8 x i64> } %9647, 1
  %9650 = getelementptr i8, <8 x ptr> %9648, <8 x i64> %9649
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1993, <8 x ptr> align 1 %9650, <8 x i1> %convergence.cascade.result1984)
  %tile_snapshot.spill.load1994 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill294, align 64
  %9651 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1994, 0
  %9652 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1994, 1
  %.spill.load1995 = load <8 x i64>, ptr %.spill305, align 64
  %9653 = mul <8 x i64> %.spill.load1995, splat (i64 32)
  %9654 = add <8 x i64> %9652, %9653
  %9655 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %9651, 0
  %9656 = insertvalue { <8 x ptr>, <8 x i64> } %9655, <8 x i64> %9654, 1
  %.state1996 = load <8 x float>, ptr %.slot46, align 32
  %9657 = extractvalue { <8 x ptr>, <8 x i64> } %9656, 0
  %9658 = extractvalue { <8 x ptr>, <8 x i64> } %9656, 1
  %9659 = getelementptr i8, <8 x ptr> %9657, <8 x i64> %9658
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1996, <8 x ptr> align 1 %9659, <8 x i1> %convergence.cascade.result1984)
  %.state1997 = load <8 x i64>, ptr %.slot297, align 64
  %9660 = add <8 x i64> %.state1997, splat (i64 1)
  %9661 = load <8 x i64>, ptr %.slot297, align 64
  %9662 = select <8 x i1> %convergence.cascade.result1984, <8 x i64> %9660, <8 x i64> %9661
  store <8 x i64> %9662, ptr %.slot297, align 64
  store <8 x i1> %convergence.cascade.result1984, ptr %current.mask, align 1
  %9663 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result1984)
  br i1 %9663, label %schedule.86, label %scheduler.loop

convergence.cascade1998:                          ; preds = %convergence.cascade1998, %schedule.91
  %convergence.cascade.flow2002 = phi <8 x i1> [ %2247, %schedule.91 ], [ %9706, %convergence.cascade1998 ]
  %convergence.cascade.depth2003 = phi i32 [ 0, %schedule.91 ], [ %9707, %convergence.cascade1998 ]
  %9664 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2002)
  %9665 = load i32, ptr %current.token, align 4
  %9666 = icmp ne i32 %9665, 0
  %9667 = and i1 %9664, %9666
  %9668 = sub i32 %9665, 1
  %9669 = select i1 %9667, i32 %9668, i32 0
  %9670 = load i8, ptr %frame.active, align 1
  %9671 = trunc i32 %9669 to i8
  %9672 = shl i8 1, %9671
  %9673 = and i8 %9670, %9672
  %9674 = icmp ne i8 %9673, 0
  %9675 = load <8 x i32>, ptr %frame.static.id, align 32
  %9676 = extractelement <8 x i32> %9675, i32 %9669
  %convergence.target.pointer2004 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %9676
  %convergence.dynamic.target2005 = load i32, ptr %convergence.target.pointer2004, align 4
  %9677 = icmp eq i32 %convergence.dynamic.target2005, 91
  %9678 = and i1 %9674, %9677
  %9679 = and i1 %9667, %9678
  %9680 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9669
  %9681 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9669
  %9682 = load <8 x i1>, ptr %9680, align 1
  %9683 = load <8 x i1>, ptr %9681, align 1
  %9684 = or <8 x i1> %9683, %convergence.cascade.flow2002
  %9685 = load <8 x i1>, ptr %live.mask, align 1
  %9686 = and <8 x i1> %9682, %9685
  %9687 = icmp eq <8 x i1> %9684, %9686
  %9688 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9687)
  %9689 = and i1 %9679, %9688
  %9690 = select i1 %9689, <8 x i1> zeroinitializer, <8 x i1> %9684
  %9691 = select i1 %9679, <8 x i1> %9690, <8 x i1> %9683
  store <8 x i1> %9691, ptr %9681, align 1
  %9692 = select i1 %9689, <8 x i1> zeroinitializer, <8 x i1> %9682
  store <8 x i1> %9692, ptr %9680, align 1
  %9693 = trunc i32 %9669 to i8
  %9694 = shl i8 1, %9693
  %9695 = xor i8 %9694, -1
  %9696 = and i8 %9670, %9695
  %9697 = select i1 %9689, i8 %9696, i8 %9670
  store i8 %9697, ptr %frame.active, align 1
  %.splatinsert2006 = insertelement <8 x i1> poison, i1 %9679, i64 0
  %.splat2007 = shufflevector <8 x i1> %.splatinsert2006, <8 x i1> poison, <8 x i32> zeroinitializer
  %9698 = and <8 x i1> %convergence.cascade.flow2002, %.splat2007
  %9699 = load <8 x i1>, ptr %runnable.mask, align 1
  %9700 = xor <8 x i1> %9698, splat (i1 true)
  %9701 = and <8 x i1> %9699, %9700
  store <8 x i1> %9701, ptr %runnable.mask, align 1
  %.splatinsert2008 = insertelement <8 x i1> poison, i1 %9689, i64 0
  %.splat2009 = shufflevector <8 x i1> %.splatinsert2008, <8 x i1> poison, <8 x i32> zeroinitializer
  %9702 = select <8 x i1> %.splat2009, <8 x i1> %9684, <8 x i1> zeroinitializer
  %9703 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9704 = extractelement <8 x i32> %9703, i32 %9669
  %9705 = select i1 %9689, i32 %9704, i32 %9665
  store i32 %9705, ptr %current.token, align 4
  %.splatinsert2010 = insertelement <8 x i1> poison, i1 %9679, i64 0
  %.splat2011 = shufflevector <8 x i1> %.splatinsert2010, <8 x i1> poison, <8 x i32> zeroinitializer
  %9706 = select <8 x i1> %.splat2011, <8 x i1> %9702, <8 x i1> %convergence.cascade.flow2002
  %9707 = add i32 %convergence.cascade.depth2003, 1
  %9708 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9706)
  %9709 = icmp ult i32 %9707, 8
  %9710 = and i1 %9708, %9709
  %9711 = and i1 %9679, %9710
  %convergence.parent.token2012 = load i32, ptr %current.token, align 4
  %convergence.parent.present2013 = icmp ne i32 %convergence.parent.token2012, 0
  %9712 = and i1 %9711, %convergence.parent.present2013
  br i1 %9712, label %convergence.cascade1998, label %convergence.cascade.exit1999

convergence.cascade.exit1999:                     ; preds = %convergence.cascade1998, %schedule.91
  %convergence.cascade.result2014 = phi <8 x i1> [ %2247, %schedule.91 ], [ %9706, %convergence.cascade1998 ]
  %9713 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2014)
  br i1 %9713, label %convergence.target.91.ready, label %scheduler.loop

convergence.target.91.ready:                      ; preds = %convergence.cascade.exit1999
  %9714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2014)
  %9715 = bitcast <8 x i1> %convergence.cascade.result2014 to i8
  %9716 = call i8 @llvm.cttz.i8(i8 %9715, i1 false)
  %9717 = zext i8 %9716 to i32
  %9718 = select i1 %9714, i32 %9717, i32 0
  %.state2015 = load <8 x i64>, ptr %.slot55, align 64
  %9719 = add <8 x i64> %.state2015, splat (i64 1)
  %9720 = load <8 x i64>, ptr %.slot55, align 64
  %9721 = select <8 x i1> %convergence.cascade.result2014, <8 x i64> %9719, <8 x i64> %9720
  store <8 x i64> %9721, ptr %.slot55, align 64
  store <8 x i1> %convergence.cascade.result2014, ptr %current.mask, align 1
  %9722 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2014)
  br i1 %9722, label %schedule.84, label %scheduler.loop

convergence.cascade2016:                          ; preds = %convergence.cascade2016, %schedule.92
  %convergence.cascade.flow2020 = phi <8 x i1> [ %2248, %schedule.92 ], [ %9765, %convergence.cascade2016 ]
  %convergence.cascade.depth2021 = phi i32 [ 0, %schedule.92 ], [ %9766, %convergence.cascade2016 ]
  %9723 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2020)
  %9724 = load i32, ptr %current.token, align 4
  %9725 = icmp ne i32 %9724, 0
  %9726 = and i1 %9723, %9725
  %9727 = sub i32 %9724, 1
  %9728 = select i1 %9726, i32 %9727, i32 0
  %9729 = load i8, ptr %frame.active, align 1
  %9730 = trunc i32 %9728 to i8
  %9731 = shl i8 1, %9730
  %9732 = and i8 %9729, %9731
  %9733 = icmp ne i8 %9732, 0
  %9734 = load <8 x i32>, ptr %frame.static.id, align 32
  %9735 = extractelement <8 x i32> %9734, i32 %9728
  %convergence.target.pointer2022 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %9735
  %convergence.dynamic.target2023 = load i32, ptr %convergence.target.pointer2022, align 4
  %9736 = icmp eq i32 %convergence.dynamic.target2023, 92
  %9737 = and i1 %9733, %9736
  %9738 = and i1 %9726, %9737
  %9739 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9728
  %9740 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9728
  %9741 = load <8 x i1>, ptr %9739, align 1
  %9742 = load <8 x i1>, ptr %9740, align 1
  %9743 = or <8 x i1> %9742, %convergence.cascade.flow2020
  %9744 = load <8 x i1>, ptr %live.mask, align 1
  %9745 = and <8 x i1> %9741, %9744
  %9746 = icmp eq <8 x i1> %9743, %9745
  %9747 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9746)
  %9748 = and i1 %9738, %9747
  %9749 = select i1 %9748, <8 x i1> zeroinitializer, <8 x i1> %9743
  %9750 = select i1 %9738, <8 x i1> %9749, <8 x i1> %9742
  store <8 x i1> %9750, ptr %9740, align 1
  %9751 = select i1 %9748, <8 x i1> zeroinitializer, <8 x i1> %9741
  store <8 x i1> %9751, ptr %9739, align 1
  %9752 = trunc i32 %9728 to i8
  %9753 = shl i8 1, %9752
  %9754 = xor i8 %9753, -1
  %9755 = and i8 %9729, %9754
  %9756 = select i1 %9748, i8 %9755, i8 %9729
  store i8 %9756, ptr %frame.active, align 1
  %.splatinsert2024 = insertelement <8 x i1> poison, i1 %9738, i64 0
  %.splat2025 = shufflevector <8 x i1> %.splatinsert2024, <8 x i1> poison, <8 x i32> zeroinitializer
  %9757 = and <8 x i1> %convergence.cascade.flow2020, %.splat2025
  %9758 = load <8 x i1>, ptr %runnable.mask, align 1
  %9759 = xor <8 x i1> %9757, splat (i1 true)
  %9760 = and <8 x i1> %9758, %9759
  store <8 x i1> %9760, ptr %runnable.mask, align 1
  %.splatinsert2026 = insertelement <8 x i1> poison, i1 %9748, i64 0
  %.splat2027 = shufflevector <8 x i1> %.splatinsert2026, <8 x i1> poison, <8 x i32> zeroinitializer
  %9761 = select <8 x i1> %.splat2027, <8 x i1> %9743, <8 x i1> zeroinitializer
  %9762 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9763 = extractelement <8 x i32> %9762, i32 %9728
  %9764 = select i1 %9748, i32 %9763, i32 %9724
  store i32 %9764, ptr %current.token, align 4
  %.splatinsert2028 = insertelement <8 x i1> poison, i1 %9738, i64 0
  %.splat2029 = shufflevector <8 x i1> %.splatinsert2028, <8 x i1> poison, <8 x i32> zeroinitializer
  %9765 = select <8 x i1> %.splat2029, <8 x i1> %9761, <8 x i1> %convergence.cascade.flow2020
  %9766 = add i32 %convergence.cascade.depth2021, 1
  %9767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9765)
  %9768 = icmp ult i32 %9766, 8
  %9769 = and i1 %9767, %9768
  %9770 = and i1 %9738, %9769
  %convergence.parent.token2030 = load i32, ptr %current.token, align 4
  %convergence.parent.present2031 = icmp ne i32 %convergence.parent.token2030, 0
  %9771 = and i1 %9770, %convergence.parent.present2031
  br i1 %9771, label %convergence.cascade2016, label %convergence.cascade.exit2017

convergence.cascade.exit2017:                     ; preds = %convergence.cascade2016, %schedule.92
  %convergence.cascade.result2032 = phi <8 x i1> [ %2248, %schedule.92 ], [ %9765, %convergence.cascade2016 ]
  %9772 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2032)
  br i1 %9772, label %convergence.target.92.ready, label %scheduler.loop

convergence.target.92.ready:                      ; preds = %convergence.cascade.exit2017
  %9773 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2032)
  %9774 = bitcast <8 x i1> %convergence.cascade.result2032 to i8
  %9775 = call i8 @llvm.cttz.i8(i8 %9774, i1 false)
  %9776 = zext i8 %9775 to i32
  %9777 = select i1 %9773, i32 %9776, i32 0
  %9778 = load <8 x i64>, ptr %.slot55, align 64
  %9779 = select <8 x i1> %convergence.cascade.result2032, <8 x i64> zeroinitializer, <8 x i64> %9778
  store <8 x i64> %9779, ptr %.slot55, align 64
  store <8 x i1> %convergence.cascade.result2032, ptr %current.mask, align 1
  %9780 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2032)
  br i1 %9780, label %schedule.93, label %scheduler.loop

varying.divergent2034:                            ; preds = %schedule.93
  %9781 = load i32, ptr %current.token, align 4
  %9782 = icmp ne i32 %9781, 0
  %9783 = sub i32 %9781, 1
  %9784 = select i1 %9782, i32 %9783, i32 0
  %9785 = load i8, ptr %frame.active, align 1
  %9786 = trunc i32 %9784 to i8
  %9787 = shl i8 1, %9786
  %9788 = and i8 %9785, %9787
  %9789 = icmp ne i8 %9788, 0
  %9790 = load <8 x i32>, ptr %frame.static.id, align 32
  %9791 = extractelement <8 x i32> %9790, i32 %9784
  %9792 = icmp eq i32 %9791, 32
  %9793 = and i1 %9789, %9792
  %9794 = and i1 %9782, %9793
  %9795 = xor i1 %9794, true
  %9796 = and i1 true, %9795
  %9797 = xor i8 %9785, -1
  %9798 = icmp ne i8 %9797, 0
  %9799 = xor i1 %9798, true
  %9800 = and i1 %9796, %9799
  br i1 %9800, label %convergence.overflow.trap2036, label %convergence.overflow.resume2037

varying.coherent2035:                             ; preds = %schedule.93
  br i1 %2259, label %varying.coherent.true2040, label %varying.coherent.false2041

convergence.overflow.trap2036:                    ; preds = %varying.divergent2034
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2037:                  ; preds = %varying.divergent2034
  %9801 = call i8 @llvm.cttz.i8(i8 %9797, i1 false)
  %9802 = zext i8 %9801 to i32
  %9803 = select i1 %9798, i32 %9802, i32 0
  %9804 = trunc i32 %9803 to i8
  %9805 = shl i8 1, %9804
  %9806 = or i8 %9785, %9805
  %9807 = select i1 %9796, i8 %9806, i8 %9785
  store i8 %9807, ptr %frame.active, align 1
  %9808 = load <8 x i32>, ptr %frame.static.id, align 32
  %9809 = extractelement <8 x i32> %9808, i32 %9803
  %9810 = select i1 %9796, i32 32, i32 %9809
  %9811 = load <8 x i32>, ptr %frame.static.id, align 32
  %9812 = insertelement <8 x i32> %9811, i32 %9810, i32 %9803
  store <8 x i32> %9812, ptr %frame.static.id, align 32
  %9813 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9814 = extractelement <8 x i32> %9813, i32 %9803
  %9815 = select i1 %9796, i32 %9781, i32 %9814
  %9816 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9817 = insertelement <8 x i32> %9816, i32 %9815, i32 %9803
  store <8 x i32> %9817, ptr %frame.parent.token, align 32
  %9818 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9803
  %9819 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9803
  %9820 = load <8 x i1>, ptr %9818, align 1
  %9821 = load <8 x i1>, ptr %9819, align 1
  %9822 = select i1 %9796, <8 x i1> %2249, <8 x i1> %9820
  store <8 x i1> %9822, ptr %9818, align 1
  %9823 = select i1 %9796, <8 x i1> zeroinitializer, <8 x i1> %9821
  store <8 x i1> %9823, ptr %9819, align 1
  %9824 = add i32 %9803, 1
  %9825 = select i1 %9794, i32 %9781, i32 %9824
  %9826 = select i1 true, i32 %9825, i32 %9781
  store i32 %9826, ptr %current.token, align 4
  %9827 = load i32, ptr %current.token, align 4
  %9828 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2256)
  %9829 = load i32, ptr %ready.count, align 4
  %9830 = icmp uge i32 %9829, 8
  %9831 = and i1 %9828, %9830
  br i1 %9831, label %ready.overflow.trap2038, label %ready.overflow.resume2039

ready.overflow.trap2038:                          ; preds = %convergence.overflow.resume2037
  call void @llvm.trap()
  unreachable

ready.overflow.resume2039:                        ; preds = %convergence.overflow.resume2037
  %9832 = select i1 %9828, i32 %9829, i32 0
  %9833 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9832
  %9834 = load <8 x i1>, ptr %9833, align 1
  %9835 = select i1 %9828, <8 x i1> %2256, <8 x i1> %9834
  store <8 x i1> %9835, ptr %9833, align 1
  %9836 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9832
  %9837 = load i32, ptr %9836, align 4
  %9838 = select i1 %9828, i32 94, i32 %9837
  store i32 %9838, ptr %9836, align 4
  %9839 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9832
  %9840 = load i32, ptr %9839, align 4
  %9841 = select i1 %9828, i32 %9827, i32 %9840
  store i32 %9841, ptr %9839, align 4
  %9842 = add i32 %9829, 1
  %9843 = select i1 %9828, i32 %9842, i32 %9829
  store i32 %9843, ptr %ready.count, align 4
  %9844 = load <8 x i1>, ptr %runnable.mask, align 1
  %9845 = or <8 x i1> %9844, %2256
  store <8 x i1> %9845, ptr %runnable.mask, align 1
  store <8 x i1> %2258, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2040:                        ; preds = %varying.coherent2035
  store <8 x i1> %2249, ptr %current.mask, align 1
  %9846 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2249)
  br i1 %9846, label %schedule.94, label %scheduler.loop

varying.coherent.false2041:                       ; preds = %varying.coherent2035
  store <8 x i1> %2249, ptr %current.mask, align 1
  %9847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2249)
  br i1 %9847, label %schedule.95, label %scheduler.loop

convergence.cascade2047:                          ; preds = %convergence.cascade2047, %schedule.95
  %convergence.cascade.flow2051 = phi <8 x i1> [ %2291, %schedule.95 ], [ %9890, %convergence.cascade2047 ]
  %convergence.cascade.depth2052 = phi i32 [ 0, %schedule.95 ], [ %9891, %convergence.cascade2047 ]
  %9848 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2051)
  %9849 = load i32, ptr %current.token, align 4
  %9850 = icmp ne i32 %9849, 0
  %9851 = and i1 %9848, %9850
  %9852 = sub i32 %9849, 1
  %9853 = select i1 %9851, i32 %9852, i32 0
  %9854 = load i8, ptr %frame.active, align 1
  %9855 = trunc i32 %9853 to i8
  %9856 = shl i8 1, %9855
  %9857 = and i8 %9854, %9856
  %9858 = icmp ne i8 %9857, 0
  %9859 = load <8 x i32>, ptr %frame.static.id, align 32
  %9860 = extractelement <8 x i32> %9859, i32 %9853
  %convergence.target.pointer2053 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %9860
  %convergence.dynamic.target2054 = load i32, ptr %convergence.target.pointer2053, align 4
  %9861 = icmp eq i32 %convergence.dynamic.target2054, 95
  %9862 = and i1 %9858, %9861
  %9863 = and i1 %9851, %9862
  %9864 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9853
  %9865 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9853
  %9866 = load <8 x i1>, ptr %9864, align 1
  %9867 = load <8 x i1>, ptr %9865, align 1
  %9868 = or <8 x i1> %9867, %convergence.cascade.flow2051
  %9869 = load <8 x i1>, ptr %live.mask, align 1
  %9870 = and <8 x i1> %9866, %9869
  %9871 = icmp eq <8 x i1> %9868, %9870
  %9872 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9871)
  %9873 = and i1 %9863, %9872
  %9874 = select i1 %9873, <8 x i1> zeroinitializer, <8 x i1> %9868
  %9875 = select i1 %9863, <8 x i1> %9874, <8 x i1> %9867
  store <8 x i1> %9875, ptr %9865, align 1
  %9876 = select i1 %9873, <8 x i1> zeroinitializer, <8 x i1> %9866
  store <8 x i1> %9876, ptr %9864, align 1
  %9877 = trunc i32 %9853 to i8
  %9878 = shl i8 1, %9877
  %9879 = xor i8 %9878, -1
  %9880 = and i8 %9854, %9879
  %9881 = select i1 %9873, i8 %9880, i8 %9854
  store i8 %9881, ptr %frame.active, align 1
  %.splatinsert2055 = insertelement <8 x i1> poison, i1 %9863, i64 0
  %.splat2056 = shufflevector <8 x i1> %.splatinsert2055, <8 x i1> poison, <8 x i32> zeroinitializer
  %9882 = and <8 x i1> %convergence.cascade.flow2051, %.splat2056
  %9883 = load <8 x i1>, ptr %runnable.mask, align 1
  %9884 = xor <8 x i1> %9882, splat (i1 true)
  %9885 = and <8 x i1> %9883, %9884
  store <8 x i1> %9885, ptr %runnable.mask, align 1
  %.splatinsert2057 = insertelement <8 x i1> poison, i1 %9873, i64 0
  %.splat2058 = shufflevector <8 x i1> %.splatinsert2057, <8 x i1> poison, <8 x i32> zeroinitializer
  %9886 = select <8 x i1> %.splat2058, <8 x i1> %9868, <8 x i1> zeroinitializer
  %9887 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9888 = extractelement <8 x i32> %9887, i32 %9853
  %9889 = select i1 %9873, i32 %9888, i32 %9849
  store i32 %9889, ptr %current.token, align 4
  %.splatinsert2059 = insertelement <8 x i1> poison, i1 %9863, i64 0
  %.splat2060 = shufflevector <8 x i1> %.splatinsert2059, <8 x i1> poison, <8 x i32> zeroinitializer
  %9890 = select <8 x i1> %.splat2060, <8 x i1> %9886, <8 x i1> %convergence.cascade.flow2051
  %9891 = add i32 %convergence.cascade.depth2052, 1
  %9892 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %9890)
  %9893 = icmp ult i32 %9891, 8
  %9894 = and i1 %9892, %9893
  %9895 = and i1 %9863, %9894
  %convergence.parent.token2061 = load i32, ptr %current.token, align 4
  %convergence.parent.present2062 = icmp ne i32 %convergence.parent.token2061, 0
  %9896 = and i1 %9895, %convergence.parent.present2062
  br i1 %9896, label %convergence.cascade2047, label %convergence.cascade.exit2048

convergence.cascade.exit2048:                     ; preds = %convergence.cascade2047, %schedule.95
  %convergence.cascade.result2063 = phi <8 x i1> [ %2291, %schedule.95 ], [ %9890, %convergence.cascade2047 ]
  %9897 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2063)
  br i1 %9897, label %convergence.target.95.ready, label %scheduler.loop

convergence.target.95.ready:                      ; preds = %convergence.cascade.exit2048
  %9898 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2063)
  %9899 = bitcast <8 x i1> %convergence.cascade.result2063 to i8
  %9900 = call i8 @llvm.cttz.i8(i8 %9899, i1 false)
  %9901 = zext i8 %9900 to i32
  %9902 = select i1 %9898, i32 %9901, i32 0
  %9903 = load <8 x i64>, ptr %.slot55, align 64
  %9904 = select <8 x i1> %convergence.cascade.result2063, <8 x i64> zeroinitializer, <8 x i64> %9903
  store <8 x i64> %9904, ptr %.slot55, align 64
  store <8 x i1> %convergence.cascade.result2063, ptr %current.mask, align 1
  %9905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2063)
  br i1 %9905, label %schedule.96, label %scheduler.loop

varying.divergent2065:                            ; preds = %schedule.96
  %9906 = load i32, ptr %current.token, align 4
  %9907 = icmp ne i32 %9906, 0
  %9908 = sub i32 %9906, 1
  %9909 = select i1 %9907, i32 %9908, i32 0
  %9910 = load i8, ptr %frame.active, align 1
  %9911 = trunc i32 %9909 to i8
  %9912 = shl i8 1, %9911
  %9913 = and i8 %9910, %9912
  %9914 = icmp ne i8 %9913, 0
  %9915 = load <8 x i32>, ptr %frame.static.id, align 32
  %9916 = extractelement <8 x i32> %9915, i32 %9909
  %9917 = icmp eq i32 %9916, 33
  %9918 = and i1 %9914, %9917
  %9919 = and i1 %9907, %9918
  %9920 = xor i1 %9919, true
  %9921 = and i1 true, %9920
  %9922 = xor i8 %9910, -1
  %9923 = icmp ne i8 %9922, 0
  %9924 = xor i1 %9923, true
  %9925 = and i1 %9921, %9924
  br i1 %9925, label %convergence.overflow.trap2067, label %convergence.overflow.resume2068

varying.coherent2066:                             ; preds = %schedule.96
  br i1 %2302, label %varying.coherent.true2071, label %varying.coherent.false2072

convergence.overflow.trap2067:                    ; preds = %varying.divergent2065
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2068:                  ; preds = %varying.divergent2065
  %9926 = call i8 @llvm.cttz.i8(i8 %9922, i1 false)
  %9927 = zext i8 %9926 to i32
  %9928 = select i1 %9923, i32 %9927, i32 0
  %9929 = trunc i32 %9928 to i8
  %9930 = shl i8 1, %9929
  %9931 = or i8 %9910, %9930
  %9932 = select i1 %9921, i8 %9931, i8 %9910
  store i8 %9932, ptr %frame.active, align 1
  %9933 = load <8 x i32>, ptr %frame.static.id, align 32
  %9934 = extractelement <8 x i32> %9933, i32 %9928
  %9935 = select i1 %9921, i32 33, i32 %9934
  %9936 = load <8 x i32>, ptr %frame.static.id, align 32
  %9937 = insertelement <8 x i32> %9936, i32 %9935, i32 %9928
  store <8 x i32> %9937, ptr %frame.static.id, align 32
  %9938 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9939 = extractelement <8 x i32> %9938, i32 %9928
  %9940 = select i1 %9921, i32 %9906, i32 %9939
  %9941 = load <8 x i32>, ptr %frame.parent.token, align 32
  %9942 = insertelement <8 x i32> %9941, i32 %9940, i32 %9928
  store <8 x i32> %9942, ptr %frame.parent.token, align 32
  %9943 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9928
  %9944 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9928
  %9945 = load <8 x i1>, ptr %9943, align 1
  %9946 = load <8 x i1>, ptr %9944, align 1
  %9947 = select i1 %9921, <8 x i1> %2292, <8 x i1> %9945
  store <8 x i1> %9947, ptr %9943, align 1
  %9948 = select i1 %9921, <8 x i1> zeroinitializer, <8 x i1> %9946
  store <8 x i1> %9948, ptr %9944, align 1
  %9949 = add i32 %9928, 1
  %9950 = select i1 %9919, i32 %9906, i32 %9949
  %9951 = select i1 true, i32 %9950, i32 %9906
  store i32 %9951, ptr %current.token, align 4
  %9952 = load i32, ptr %current.token, align 4
  %9953 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2299)
  %9954 = load i32, ptr %ready.count, align 4
  %9955 = icmp uge i32 %9954, 8
  %9956 = and i1 %9953, %9955
  br i1 %9956, label %ready.overflow.trap2069, label %ready.overflow.resume2070

ready.overflow.trap2069:                          ; preds = %convergence.overflow.resume2068
  call void @llvm.trap()
  unreachable

ready.overflow.resume2070:                        ; preds = %convergence.overflow.resume2068
  %9957 = select i1 %9953, i32 %9954, i32 0
  %9958 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %9957
  %9959 = load <8 x i1>, ptr %9958, align 1
  %9960 = select i1 %9953, <8 x i1> %2299, <8 x i1> %9959
  store <8 x i1> %9960, ptr %9958, align 1
  %9961 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %9957
  %9962 = load i32, ptr %9961, align 4
  %9963 = select i1 %9953, i32 97, i32 %9962
  store i32 %9963, ptr %9961, align 4
  %9964 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %9957
  %9965 = load i32, ptr %9964, align 4
  %9966 = select i1 %9953, i32 %9952, i32 %9965
  store i32 %9966, ptr %9964, align 4
  %9967 = add i32 %9954, 1
  %9968 = select i1 %9953, i32 %9967, i32 %9954
  store i32 %9968, ptr %ready.count, align 4
  %9969 = load <8 x i1>, ptr %runnable.mask, align 1
  %9970 = or <8 x i1> %9969, %2299
  store <8 x i1> %9970, ptr %runnable.mask, align 1
  store <8 x i1> %2301, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2071:                        ; preds = %varying.coherent2066
  store <8 x i1> %2292, ptr %current.mask, align 1
  %9971 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2292)
  br i1 %9971, label %schedule.97, label %scheduler.loop

varying.coherent.false2072:                       ; preds = %varying.coherent2066
  store <8 x i1> %2292, ptr %current.mask, align 1
  %9972 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2292)
  br i1 %9972, label %schedule.98, label %scheduler.loop

convergence.cascade2078:                          ; preds = %convergence.cascade2078, %schedule.98
  %convergence.cascade.flow2082 = phi <8 x i1> [ %2334, %schedule.98 ], [ %10015, %convergence.cascade2078 ]
  %convergence.cascade.depth2083 = phi i32 [ 0, %schedule.98 ], [ %10016, %convergence.cascade2078 ]
  %9973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2082)
  %9974 = load i32, ptr %current.token, align 4
  %9975 = icmp ne i32 %9974, 0
  %9976 = and i1 %9973, %9975
  %9977 = sub i32 %9974, 1
  %9978 = select i1 %9976, i32 %9977, i32 0
  %9979 = load i8, ptr %frame.active, align 1
  %9980 = trunc i32 %9978 to i8
  %9981 = shl i8 1, %9980
  %9982 = and i8 %9979, %9981
  %9983 = icmp ne i8 %9982, 0
  %9984 = load <8 x i32>, ptr %frame.static.id, align 32
  %9985 = extractelement <8 x i32> %9984, i32 %9978
  %convergence.target.pointer2084 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %9985
  %convergence.dynamic.target2085 = load i32, ptr %convergence.target.pointer2084, align 4
  %9986 = icmp eq i32 %convergence.dynamic.target2085, 98
  %9987 = and i1 %9983, %9986
  %9988 = and i1 %9976, %9987
  %9989 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %9978
  %9990 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %9978
  %9991 = load <8 x i1>, ptr %9989, align 1
  %9992 = load <8 x i1>, ptr %9990, align 1
  %9993 = or <8 x i1> %9992, %convergence.cascade.flow2082
  %9994 = load <8 x i1>, ptr %live.mask, align 1
  %9995 = and <8 x i1> %9991, %9994
  %9996 = icmp eq <8 x i1> %9993, %9995
  %9997 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %9996)
  %9998 = and i1 %9988, %9997
  %9999 = select i1 %9998, <8 x i1> zeroinitializer, <8 x i1> %9993
  %10000 = select i1 %9988, <8 x i1> %9999, <8 x i1> %9992
  store <8 x i1> %10000, ptr %9990, align 1
  %10001 = select i1 %9998, <8 x i1> zeroinitializer, <8 x i1> %9991
  store <8 x i1> %10001, ptr %9989, align 1
  %10002 = trunc i32 %9978 to i8
  %10003 = shl i8 1, %10002
  %10004 = xor i8 %10003, -1
  %10005 = and i8 %9979, %10004
  %10006 = select i1 %9998, i8 %10005, i8 %9979
  store i8 %10006, ptr %frame.active, align 1
  %.splatinsert2086 = insertelement <8 x i1> poison, i1 %9988, i64 0
  %.splat2087 = shufflevector <8 x i1> %.splatinsert2086, <8 x i1> poison, <8 x i32> zeroinitializer
  %10007 = and <8 x i1> %convergence.cascade.flow2082, %.splat2087
  %10008 = load <8 x i1>, ptr %runnable.mask, align 1
  %10009 = xor <8 x i1> %10007, splat (i1 true)
  %10010 = and <8 x i1> %10008, %10009
  store <8 x i1> %10010, ptr %runnable.mask, align 1
  %.splatinsert2088 = insertelement <8 x i1> poison, i1 %9998, i64 0
  %.splat2089 = shufflevector <8 x i1> %.splatinsert2088, <8 x i1> poison, <8 x i32> zeroinitializer
  %10011 = select <8 x i1> %.splat2089, <8 x i1> %9993, <8 x i1> zeroinitializer
  %10012 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10013 = extractelement <8 x i32> %10012, i32 %9978
  %10014 = select i1 %9998, i32 %10013, i32 %9974
  store i32 %10014, ptr %current.token, align 4
  %.splatinsert2090 = insertelement <8 x i1> poison, i1 %9988, i64 0
  %.splat2091 = shufflevector <8 x i1> %.splatinsert2090, <8 x i1> poison, <8 x i32> zeroinitializer
  %10015 = select <8 x i1> %.splat2091, <8 x i1> %10011, <8 x i1> %convergence.cascade.flow2082
  %10016 = add i32 %convergence.cascade.depth2083, 1
  %10017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10015)
  %10018 = icmp ult i32 %10016, 8
  %10019 = and i1 %10017, %10018
  %10020 = and i1 %9988, %10019
  %convergence.parent.token2092 = load i32, ptr %current.token, align 4
  %convergence.parent.present2093 = icmp ne i32 %convergence.parent.token2092, 0
  %10021 = and i1 %10020, %convergence.parent.present2093
  br i1 %10021, label %convergence.cascade2078, label %convergence.cascade.exit2079

convergence.cascade.exit2079:                     ; preds = %convergence.cascade2078, %schedule.98
  %convergence.cascade.result2094 = phi <8 x i1> [ %2334, %schedule.98 ], [ %10015, %convergence.cascade2078 ]
  %10022 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2094)
  br i1 %10022, label %convergence.target.98.ready, label %scheduler.loop

convergence.target.98.ready:                      ; preds = %convergence.cascade.exit2079
  %10023 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2094)
  %10024 = bitcast <8 x i1> %convergence.cascade.result2094 to i8
  %10025 = call i8 @llvm.cttz.i8(i8 %10024, i1 false)
  %10026 = zext i8 %10025 to i32
  %10027 = select i1 %10023, i32 %10026, i32 0
  %.state2095 = load <8 x i64>, ptr %.slot, align 64
  %10028 = add <8 x i64> %.state2095, splat (i64 1)
  %.spill.load2096 = load <8 x float>, ptr %.spill272, align 32
  %.spill.load2097 = load <8 x float>, ptr %.spill273, align 32
  %.spill.load2098 = load <8 x float>, ptr %.spill274, align 32
  %.spill.load2099 = load <8 x float>, ptr %.spill275, align 32
  %.spill.load2100 = load <8 x float>, ptr %.spill290, align 32
  %.spill.load2101 = load <8 x float>, ptr %.spill291, align 32
  %.spill.load2102 = load <8 x float>, ptr %.spill292, align 32
  %.spill.load2103 = load <8 x float>, ptr %.spill293, align 32
  %10029 = load <8 x i64>, ptr %.slot, align 64
  %10030 = select <8 x i1> %convergence.cascade.result2094, <8 x i64> %10028, <8 x i64> %10029
  store <8 x i64> %10030, ptr %.slot, align 64
  %10031 = load <8 x float>, ptr %.slot43, align 32
  %10032 = select <8 x i1> %convergence.cascade.result2094, <8 x float> %.spill.load2096, <8 x float> %10031
  store <8 x float> %10032, ptr %.slot43, align 32
  %10033 = load <8 x float>, ptr %.slot44, align 32
  %10034 = select <8 x i1> %convergence.cascade.result2094, <8 x float> %.spill.load2097, <8 x float> %10033
  store <8 x float> %10034, ptr %.slot44, align 32
  %10035 = load <8 x float>, ptr %.slot45, align 32
  %10036 = select <8 x i1> %convergence.cascade.result2094, <8 x float> %.spill.load2098, <8 x float> %10035
  store <8 x float> %10036, ptr %.slot45, align 32
  %10037 = load <8 x float>, ptr %.slot46, align 32
  %10038 = select <8 x i1> %convergence.cascade.result2094, <8 x float> %.spill.load2099, <8 x float> %10037
  store <8 x float> %10038, ptr %.slot46, align 32
  %10039 = load <8 x float>, ptr %.slot47, align 32
  %10040 = select <8 x i1> %convergence.cascade.result2094, <8 x float> %.spill.load2100, <8 x float> %10039
  store <8 x float> %10040, ptr %.slot47, align 32
  %10041 = load <8 x float>, ptr %.slot48, align 32
  %10042 = select <8 x i1> %convergence.cascade.result2094, <8 x float> %.spill.load2101, <8 x float> %10041
  store <8 x float> %10042, ptr %.slot48, align 32
  %10043 = load <8 x float>, ptr %.slot49, align 32
  %10044 = select <8 x i1> %convergence.cascade.result2094, <8 x float> %.spill.load2102, <8 x float> %10043
  store <8 x float> %10044, ptr %.slot49, align 32
  %10045 = load <8 x float>, ptr %.slot50, align 32
  %10046 = select <8 x i1> %convergence.cascade.result2094, <8 x float> %.spill.load2103, <8 x float> %10045
  store <8 x float> %10046, ptr %.slot50, align 32
  store <8 x i1> %convergence.cascade.result2094, ptr %current.mask, align 1
  %10047 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2094)
  br i1 %10047, label %schedule.6, label %scheduler.loop

varying.divergent2105:                            ; preds = %schedule.100
  %10048 = load i32, ptr %current.token, align 4
  %10049 = icmp ne i32 %10048, 0
  %10050 = sub i32 %10048, 1
  %10051 = select i1 %10049, i32 %10050, i32 0
  %10052 = load i8, ptr %frame.active, align 1
  %10053 = trunc i32 %10051 to i8
  %10054 = shl i8 1, %10053
  %10055 = and i8 %10052, %10054
  %10056 = icmp ne i8 %10055, 0
  %10057 = load <8 x i32>, ptr %frame.static.id, align 32
  %10058 = extractelement <8 x i32> %10057, i32 %10051
  %10059 = icmp eq i32 %10058, 34
  %10060 = and i1 %10056, %10059
  %10061 = and i1 %10049, %10060
  %10062 = xor i1 %10061, true
  %10063 = and i1 true, %10062
  %10064 = xor i8 %10052, -1
  %10065 = icmp ne i8 %10064, 0
  %10066 = xor i1 %10065, true
  %10067 = and i1 %10063, %10066
  br i1 %10067, label %convergence.overflow.trap2107, label %convergence.overflow.resume2108

varying.coherent2106:                             ; preds = %schedule.100
  br i1 %2354, label %varying.coherent.true2111, label %varying.coherent.false2112

convergence.overflow.trap2107:                    ; preds = %varying.divergent2105
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2108:                  ; preds = %varying.divergent2105
  %10068 = call i8 @llvm.cttz.i8(i8 %10064, i1 false)
  %10069 = zext i8 %10068 to i32
  %10070 = select i1 %10065, i32 %10069, i32 0
  %10071 = trunc i32 %10070 to i8
  %10072 = shl i8 1, %10071
  %10073 = or i8 %10052, %10072
  %10074 = select i1 %10063, i8 %10073, i8 %10052
  store i8 %10074, ptr %frame.active, align 1
  %10075 = load <8 x i32>, ptr %frame.static.id, align 32
  %10076 = extractelement <8 x i32> %10075, i32 %10070
  %10077 = select i1 %10063, i32 34, i32 %10076
  %10078 = load <8 x i32>, ptr %frame.static.id, align 32
  %10079 = insertelement <8 x i32> %10078, i32 %10077, i32 %10070
  store <8 x i32> %10079, ptr %frame.static.id, align 32
  %10080 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10081 = extractelement <8 x i32> %10080, i32 %10070
  %10082 = select i1 %10063, i32 %10048, i32 %10081
  %10083 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10084 = insertelement <8 x i32> %10083, i32 %10082, i32 %10070
  store <8 x i32> %10084, ptr %frame.parent.token, align 32
  %10085 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10070
  %10086 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10070
  %10087 = load <8 x i1>, ptr %10085, align 1
  %10088 = load <8 x i1>, ptr %10086, align 1
  %10089 = select i1 %10063, <8 x i1> %2344, <8 x i1> %10087
  store <8 x i1> %10089, ptr %10085, align 1
  %10090 = select i1 %10063, <8 x i1> zeroinitializer, <8 x i1> %10088
  store <8 x i1> %10090, ptr %10086, align 1
  %10091 = add i32 %10070, 1
  %10092 = select i1 %10061, i32 %10048, i32 %10091
  %10093 = select i1 true, i32 %10092, i32 %10048
  store i32 %10093, ptr %current.token, align 4
  %10094 = load i32, ptr %current.token, align 4
  %10095 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2351)
  %10096 = load i32, ptr %ready.count, align 4
  %10097 = icmp uge i32 %10096, 8
  %10098 = and i1 %10095, %10097
  br i1 %10098, label %ready.overflow.trap2109, label %ready.overflow.resume2110

ready.overflow.trap2109:                          ; preds = %convergence.overflow.resume2108
  call void @llvm.trap()
  unreachable

ready.overflow.resume2110:                        ; preds = %convergence.overflow.resume2108
  %10099 = select i1 %10095, i32 %10096, i32 0
  %10100 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10099
  %10101 = load <8 x i1>, ptr %10100, align 1
  %10102 = select i1 %10095, <8 x i1> %2351, <8 x i1> %10101
  store <8 x i1> %10102, ptr %10100, align 1
  %10103 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10099
  %10104 = load i32, ptr %10103, align 4
  %10105 = select i1 %10095, i32 101, i32 %10104
  store i32 %10105, ptr %10103, align 4
  %10106 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10099
  %10107 = load i32, ptr %10106, align 4
  %10108 = select i1 %10095, i32 %10094, i32 %10107
  store i32 %10108, ptr %10106, align 4
  %10109 = add i32 %10096, 1
  %10110 = select i1 %10095, i32 %10109, i32 %10096
  store i32 %10110, ptr %ready.count, align 4
  %10111 = load <8 x i1>, ptr %runnable.mask, align 1
  %10112 = or <8 x i1> %10111, %2351
  store <8 x i1> %10112, ptr %runnable.mask, align 1
  store <8 x i1> %2353, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2111:                        ; preds = %varying.coherent2106
  store <8 x i1> %2344, ptr %current.mask, align 1
  %10113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2344)
  br i1 %10113, label %schedule.101, label %scheduler.loop

varying.coherent.false2112:                       ; preds = %varying.coherent2106
  store <8 x i1> %2344, ptr %current.mask, align 1
  %10114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2344)
  br i1 %10114, label %schedule.11, label %scheduler.loop

varying.divergent2118:                            ; preds = %schedule.101
  %10115 = load i32, ptr %current.token, align 4
  %10116 = icmp ne i32 %10115, 0
  %10117 = sub i32 %10115, 1
  %10118 = select i1 %10116, i32 %10117, i32 0
  %10119 = load i8, ptr %frame.active, align 1
  %10120 = trunc i32 %10118 to i8
  %10121 = shl i8 1, %10120
  %10122 = and i8 %10119, %10121
  %10123 = icmp ne i8 %10122, 0
  %10124 = load <8 x i32>, ptr %frame.static.id, align 32
  %10125 = extractelement <8 x i32> %10124, i32 %10118
  %10126 = icmp eq i32 %10125, 35
  %10127 = and i1 %10123, %10126
  %10128 = and i1 %10116, %10127
  %10129 = xor i1 %10128, true
  %10130 = and i1 true, %10129
  %10131 = xor i8 %10119, -1
  %10132 = icmp ne i8 %10131, 0
  %10133 = xor i1 %10132, true
  %10134 = and i1 %10130, %10133
  br i1 %10134, label %convergence.overflow.trap2120, label %convergence.overflow.resume2121

varying.coherent2119:                             ; preds = %schedule.101
  br i1 %2389, label %varying.coherent.true2124, label %varying.coherent.false2125

convergence.overflow.trap2120:                    ; preds = %varying.divergent2118
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2121:                  ; preds = %varying.divergent2118
  %10135 = call i8 @llvm.cttz.i8(i8 %10131, i1 false)
  %10136 = zext i8 %10135 to i32
  %10137 = select i1 %10132, i32 %10136, i32 0
  %10138 = trunc i32 %10137 to i8
  %10139 = shl i8 1, %10138
  %10140 = or i8 %10119, %10139
  %10141 = select i1 %10130, i8 %10140, i8 %10119
  store i8 %10141, ptr %frame.active, align 1
  %10142 = load <8 x i32>, ptr %frame.static.id, align 32
  %10143 = extractelement <8 x i32> %10142, i32 %10137
  %10144 = select i1 %10130, i32 35, i32 %10143
  %10145 = load <8 x i32>, ptr %frame.static.id, align 32
  %10146 = insertelement <8 x i32> %10145, i32 %10144, i32 %10137
  store <8 x i32> %10146, ptr %frame.static.id, align 32
  %10147 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10148 = extractelement <8 x i32> %10147, i32 %10137
  %10149 = select i1 %10130, i32 %10115, i32 %10148
  %10150 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10151 = insertelement <8 x i32> %10150, i32 %10149, i32 %10137
  store <8 x i32> %10151, ptr %frame.parent.token, align 32
  %10152 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10137
  %10153 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10137
  %10154 = load <8 x i1>, ptr %10152, align 1
  %10155 = load <8 x i1>, ptr %10153, align 1
  %10156 = select i1 %10130, <8 x i1> %2357, <8 x i1> %10154
  store <8 x i1> %10156, ptr %10152, align 1
  %10157 = select i1 %10130, <8 x i1> zeroinitializer, <8 x i1> %10155
  store <8 x i1> %10157, ptr %10153, align 1
  %10158 = add i32 %10137, 1
  %10159 = select i1 %10128, i32 %10115, i32 %10158
  %10160 = select i1 true, i32 %10159, i32 %10115
  store i32 %10160, ptr %current.token, align 4
  %10161 = load <8 x float>, ptr %.slot56, align 32
  %10162 = select <8 x i1> %2388, <8 x float> zeroinitializer, <8 x float> %10161
  store <8 x float> %10162, ptr %.slot56, align 32
  %10163 = load i32, ptr %current.token, align 4
  %10164 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2386)
  %10165 = load i32, ptr %ready.count, align 4
  %10166 = icmp uge i32 %10165, 8
  %10167 = and i1 %10164, %10166
  br i1 %10167, label %ready.overflow.trap2122, label %ready.overflow.resume2123

ready.overflow.trap2122:                          ; preds = %convergence.overflow.resume2121
  call void @llvm.trap()
  unreachable

ready.overflow.resume2123:                        ; preds = %convergence.overflow.resume2121
  %10168 = select i1 %10164, i32 %10165, i32 0
  %10169 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10168
  %10170 = load <8 x i1>, ptr %10169, align 1
  %10171 = select i1 %10164, <8 x i1> %2386, <8 x i1> %10170
  store <8 x i1> %10171, ptr %10169, align 1
  %10172 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10168
  %10173 = load i32, ptr %10172, align 4
  %10174 = select i1 %10164, i32 102, i32 %10173
  store i32 %10174, ptr %10172, align 4
  %10175 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10168
  %10176 = load i32, ptr %10175, align 4
  %10177 = select i1 %10164, i32 %10163, i32 %10176
  store i32 %10177, ptr %10175, align 4
  %10178 = add i32 %10165, 1
  %10179 = select i1 %10164, i32 %10178, i32 %10165
  store i32 %10179, ptr %ready.count, align 4
  %10180 = load <8 x i1>, ptr %runnable.mask, align 1
  %10181 = or <8 x i1> %10180, %2386
  store <8 x i1> %10181, ptr %runnable.mask, align 1
  store <8 x i1> %2388, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2124:                        ; preds = %varying.coherent2119
  store <8 x i1> %2357, ptr %current.mask, align 1
  %10182 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2357)
  br i1 %10182, label %schedule.102, label %scheduler.loop

varying.coherent.false2125:                       ; preds = %varying.coherent2119
  %10183 = load <8 x float>, ptr %.slot56, align 32
  %10184 = select <8 x i1> %2357, <8 x float> zeroinitializer, <8 x float> %10183
  store <8 x float> %10184, ptr %.slot56, align 32
  store <8 x i1> %2357, ptr %current.mask, align 1
  %10185 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2357)
  br i1 %10185, label %schedule.103, label %scheduler.loop

convergence.cascade2127:                          ; preds = %convergence.cascade2127, %schedule.103
  %convergence.cascade.flow2131 = phi <8 x i1> [ %2405, %schedule.103 ], [ %10228, %convergence.cascade2127 ]
  %convergence.cascade.depth2132 = phi i32 [ 0, %schedule.103 ], [ %10229, %convergence.cascade2127 ]
  %10186 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2131)
  %10187 = load i32, ptr %current.token, align 4
  %10188 = icmp ne i32 %10187, 0
  %10189 = and i1 %10186, %10188
  %10190 = sub i32 %10187, 1
  %10191 = select i1 %10189, i32 %10190, i32 0
  %10192 = load i8, ptr %frame.active, align 1
  %10193 = trunc i32 %10191 to i8
  %10194 = shl i8 1, %10193
  %10195 = and i8 %10192, %10194
  %10196 = icmp ne i8 %10195, 0
  %10197 = load <8 x i32>, ptr %frame.static.id, align 32
  %10198 = extractelement <8 x i32> %10197, i32 %10191
  %convergence.target.pointer2133 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %10198
  %convergence.dynamic.target2134 = load i32, ptr %convergence.target.pointer2133, align 4
  %10199 = icmp eq i32 %convergence.dynamic.target2134, 103
  %10200 = and i1 %10196, %10199
  %10201 = and i1 %10189, %10200
  %10202 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10191
  %10203 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10191
  %10204 = load <8 x i1>, ptr %10202, align 1
  %10205 = load <8 x i1>, ptr %10203, align 1
  %10206 = or <8 x i1> %10205, %convergence.cascade.flow2131
  %10207 = load <8 x i1>, ptr %live.mask, align 1
  %10208 = and <8 x i1> %10204, %10207
  %10209 = icmp eq <8 x i1> %10206, %10208
  %10210 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10209)
  %10211 = and i1 %10201, %10210
  %10212 = select i1 %10211, <8 x i1> zeroinitializer, <8 x i1> %10206
  %10213 = select i1 %10201, <8 x i1> %10212, <8 x i1> %10205
  store <8 x i1> %10213, ptr %10203, align 1
  %10214 = select i1 %10211, <8 x i1> zeroinitializer, <8 x i1> %10204
  store <8 x i1> %10214, ptr %10202, align 1
  %10215 = trunc i32 %10191 to i8
  %10216 = shl i8 1, %10215
  %10217 = xor i8 %10216, -1
  %10218 = and i8 %10192, %10217
  %10219 = select i1 %10211, i8 %10218, i8 %10192
  store i8 %10219, ptr %frame.active, align 1
  %.splatinsert2135 = insertelement <8 x i1> poison, i1 %10201, i64 0
  %.splat2136 = shufflevector <8 x i1> %.splatinsert2135, <8 x i1> poison, <8 x i32> zeroinitializer
  %10220 = and <8 x i1> %convergence.cascade.flow2131, %.splat2136
  %10221 = load <8 x i1>, ptr %runnable.mask, align 1
  %10222 = xor <8 x i1> %10220, splat (i1 true)
  %10223 = and <8 x i1> %10221, %10222
  store <8 x i1> %10223, ptr %runnable.mask, align 1
  %.splatinsert2137 = insertelement <8 x i1> poison, i1 %10211, i64 0
  %.splat2138 = shufflevector <8 x i1> %.splatinsert2137, <8 x i1> poison, <8 x i32> zeroinitializer
  %10224 = select <8 x i1> %.splat2138, <8 x i1> %10206, <8 x i1> zeroinitializer
  %10225 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10226 = extractelement <8 x i32> %10225, i32 %10191
  %10227 = select i1 %10211, i32 %10226, i32 %10187
  store i32 %10227, ptr %current.token, align 4
  %.splatinsert2139 = insertelement <8 x i1> poison, i1 %10201, i64 0
  %.splat2140 = shufflevector <8 x i1> %.splatinsert2139, <8 x i1> poison, <8 x i32> zeroinitializer
  %10228 = select <8 x i1> %.splat2140, <8 x i1> %10224, <8 x i1> %convergence.cascade.flow2131
  %10229 = add i32 %convergence.cascade.depth2132, 1
  %10230 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10228)
  %10231 = icmp ult i32 %10229, 8
  %10232 = and i1 %10230, %10231
  %10233 = and i1 %10201, %10232
  %convergence.parent.token2141 = load i32, ptr %current.token, align 4
  %convergence.parent.present2142 = icmp ne i32 %convergence.parent.token2141, 0
  %10234 = and i1 %10233, %convergence.parent.present2142
  br i1 %10234, label %convergence.cascade2127, label %convergence.cascade.exit2128

convergence.cascade.exit2128:                     ; preds = %convergence.cascade2127, %schedule.103
  %convergence.cascade.result2143 = phi <8 x i1> [ %2405, %schedule.103 ], [ %10228, %convergence.cascade2127 ]
  %10235 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2143)
  br i1 %10235, label %convergence.target.103.ready, label %scheduler.loop

convergence.target.103.ready:                     ; preds = %convergence.cascade.exit2128
  %10236 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2143)
  %10237 = bitcast <8 x i1> %convergence.cascade.result2143 to i8
  %10238 = call i8 @llvm.cttz.i8(i8 %10237, i1 false)
  %10239 = zext i8 %10238 to i32
  %10240 = select i1 %10236, i32 %10239, i32 0
  %tile_snapshot.spill.load2144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill54, align 64
  %10241 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2144, 0
  %10242 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2144, 1
  %.state2145 = load <8 x i64>, ptr %.slot55, align 64
  %10243 = mul <8 x i64> %.state2145, splat (i64 4)
  %10244 = add <8 x i64> %10242, %10243
  %10245 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10241, 0
  %10246 = insertvalue { <8 x ptr>, <8 x i64> } %10245, <8 x i64> %10244, 1
  %.state2146 = load <8 x float>, ptr %.slot56, align 32
  %10247 = extractvalue { <8 x ptr>, <8 x i64> } %10246, 0
  %10248 = extractvalue { <8 x ptr>, <8 x i64> } %10246, 1
  %10249 = getelementptr i8, <8 x ptr> %10247, <8 x i64> %10248
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state2146, <8 x ptr> align 1 %10249, <8 x i1> %convergence.cascade.result2143)
  %.state2147 = load <8 x i64>, ptr %.slot55, align 64
  %10250 = add <8 x i64> %.state2147, splat (i64 1)
  %10251 = load <8 x i64>, ptr %.slot55, align 64
  %10252 = select <8 x i1> %convergence.cascade.result2143, <8 x i64> %10250, <8 x i64> %10251
  store <8 x i64> %10252, ptr %.slot55, align 64
  store <8 x i1> %convergence.cascade.result2143, ptr %current.mask, align 1
  %10253 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2143)
  br i1 %10253, label %schedule.100, label %scheduler.loop

varying.divergent2149:                            ; preds = %schedule.105
  %10254 = load i32, ptr %current.token, align 4
  %10255 = icmp ne i32 %10254, 0
  %10256 = sub i32 %10254, 1
  %10257 = select i1 %10255, i32 %10256, i32 0
  %10258 = load i8, ptr %frame.active, align 1
  %10259 = trunc i32 %10257 to i8
  %10260 = shl i8 1, %10259
  %10261 = and i8 %10258, %10260
  %10262 = icmp ne i8 %10261, 0
  %10263 = load <8 x i32>, ptr %frame.static.id, align 32
  %10264 = extractelement <8 x i32> %10263, i32 %10257
  %10265 = icmp eq i32 %10264, 36
  %10266 = and i1 %10262, %10265
  %10267 = and i1 %10255, %10266
  %10268 = xor i1 %10267, true
  %10269 = and i1 true, %10268
  %10270 = xor i8 %10258, -1
  %10271 = icmp ne i8 %10270, 0
  %10272 = xor i1 %10271, true
  %10273 = and i1 %10269, %10272
  br i1 %10273, label %convergence.overflow.trap2151, label %convergence.overflow.resume2152

varying.coherent2150:                             ; preds = %schedule.105
  br i1 %2425, label %varying.coherent.true2155, label %varying.coherent.false2156

convergence.overflow.trap2151:                    ; preds = %varying.divergent2149
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2152:                  ; preds = %varying.divergent2149
  %10274 = call i8 @llvm.cttz.i8(i8 %10270, i1 false)
  %10275 = zext i8 %10274 to i32
  %10276 = select i1 %10271, i32 %10275, i32 0
  %10277 = trunc i32 %10276 to i8
  %10278 = shl i8 1, %10277
  %10279 = or i8 %10258, %10278
  %10280 = select i1 %10269, i8 %10279, i8 %10258
  store i8 %10280, ptr %frame.active, align 1
  %10281 = load <8 x i32>, ptr %frame.static.id, align 32
  %10282 = extractelement <8 x i32> %10281, i32 %10276
  %10283 = select i1 %10269, i32 36, i32 %10282
  %10284 = load <8 x i32>, ptr %frame.static.id, align 32
  %10285 = insertelement <8 x i32> %10284, i32 %10283, i32 %10276
  store <8 x i32> %10285, ptr %frame.static.id, align 32
  %10286 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10287 = extractelement <8 x i32> %10286, i32 %10276
  %10288 = select i1 %10269, i32 %10254, i32 %10287
  %10289 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10290 = insertelement <8 x i32> %10289, i32 %10288, i32 %10276
  store <8 x i32> %10290, ptr %frame.parent.token, align 32
  %10291 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10276
  %10292 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10276
  %10293 = load <8 x i1>, ptr %10291, align 1
  %10294 = load <8 x i1>, ptr %10292, align 1
  %10295 = select i1 %10269, <8 x i1> %2415, <8 x i1> %10293
  store <8 x i1> %10295, ptr %10291, align 1
  %10296 = select i1 %10269, <8 x i1> zeroinitializer, <8 x i1> %10294
  store <8 x i1> %10296, ptr %10292, align 1
  %10297 = add i32 %10276, 1
  %10298 = select i1 %10267, i32 %10254, i32 %10297
  %10299 = select i1 true, i32 %10298, i32 %10254
  store i32 %10299, ptr %current.token, align 4
  %10300 = load i32, ptr %current.token, align 4
  %10301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2422)
  %10302 = load i32, ptr %ready.count, align 4
  %10303 = icmp uge i32 %10302, 8
  %10304 = and i1 %10301, %10303
  br i1 %10304, label %ready.overflow.trap2153, label %ready.overflow.resume2154

ready.overflow.trap2153:                          ; preds = %convergence.overflow.resume2152
  call void @llvm.trap()
  unreachable

ready.overflow.resume2154:                        ; preds = %convergence.overflow.resume2152
  %10305 = select i1 %10301, i32 %10302, i32 0
  %10306 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10305
  %10307 = load <8 x i1>, ptr %10306, align 1
  %10308 = select i1 %10301, <8 x i1> %2422, <8 x i1> %10307
  store <8 x i1> %10308, ptr %10306, align 1
  %10309 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10305
  %10310 = load i32, ptr %10309, align 4
  %10311 = select i1 %10301, i32 106, i32 %10310
  store i32 %10311, ptr %10309, align 4
  %10312 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10305
  %10313 = load i32, ptr %10312, align 4
  %10314 = select i1 %10301, i32 %10300, i32 %10313
  store i32 %10314, ptr %10312, align 4
  %10315 = add i32 %10302, 1
  %10316 = select i1 %10301, i32 %10315, i32 %10302
  store i32 %10316, ptr %ready.count, align 4
  %10317 = load <8 x i1>, ptr %runnable.mask, align 1
  %10318 = or <8 x i1> %10317, %2422
  store <8 x i1> %10318, ptr %runnable.mask, align 1
  store <8 x i1> %2424, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2155:                        ; preds = %varying.coherent2150
  store <8 x i1> %2415, ptr %current.mask, align 1
  %10319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2415)
  br i1 %10319, label %schedule.106, label %scheduler.loop

varying.coherent.false2156:                       ; preds = %varying.coherent2150
  store <8 x i1> %2415, ptr %current.mask, align 1
  %10320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2415)
  br i1 %10320, label %schedule.9, label %scheduler.loop

varying.divergent2162:                            ; preds = %schedule.106
  %10321 = load i32, ptr %current.token, align 4
  %10322 = icmp ne i32 %10321, 0
  %10323 = sub i32 %10321, 1
  %10324 = select i1 %10322, i32 %10323, i32 0
  %10325 = load i8, ptr %frame.active, align 1
  %10326 = trunc i32 %10324 to i8
  %10327 = shl i8 1, %10326
  %10328 = and i8 %10325, %10327
  %10329 = icmp ne i8 %10328, 0
  %10330 = load <8 x i32>, ptr %frame.static.id, align 32
  %10331 = extractelement <8 x i32> %10330, i32 %10324
  %10332 = icmp eq i32 %10331, 37
  %10333 = and i1 %10329, %10332
  %10334 = and i1 %10322, %10333
  %10335 = xor i1 %10334, true
  %10336 = and i1 true, %10335
  %10337 = xor i8 %10325, -1
  %10338 = icmp ne i8 %10337, 0
  %10339 = xor i1 %10338, true
  %10340 = and i1 %10336, %10339
  br i1 %10340, label %convergence.overflow.trap2164, label %convergence.overflow.resume2165

varying.coherent2163:                             ; preds = %schedule.106
  br i1 %2460, label %varying.coherent.true2168, label %varying.coherent.false2169

convergence.overflow.trap2164:                    ; preds = %varying.divergent2162
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2165:                  ; preds = %varying.divergent2162
  %10341 = call i8 @llvm.cttz.i8(i8 %10337, i1 false)
  %10342 = zext i8 %10341 to i32
  %10343 = select i1 %10338, i32 %10342, i32 0
  %10344 = trunc i32 %10343 to i8
  %10345 = shl i8 1, %10344
  %10346 = or i8 %10325, %10345
  %10347 = select i1 %10336, i8 %10346, i8 %10325
  store i8 %10347, ptr %frame.active, align 1
  %10348 = load <8 x i32>, ptr %frame.static.id, align 32
  %10349 = extractelement <8 x i32> %10348, i32 %10343
  %10350 = select i1 %10336, i32 37, i32 %10349
  %10351 = load <8 x i32>, ptr %frame.static.id, align 32
  %10352 = insertelement <8 x i32> %10351, i32 %10350, i32 %10343
  store <8 x i32> %10352, ptr %frame.static.id, align 32
  %10353 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10354 = extractelement <8 x i32> %10353, i32 %10343
  %10355 = select i1 %10336, i32 %10321, i32 %10354
  %10356 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10357 = insertelement <8 x i32> %10356, i32 %10355, i32 %10343
  store <8 x i32> %10357, ptr %frame.parent.token, align 32
  %10358 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10343
  %10359 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10343
  %10360 = load <8 x i1>, ptr %10358, align 1
  %10361 = load <8 x i1>, ptr %10359, align 1
  %10362 = select i1 %10336, <8 x i1> %2428, <8 x i1> %10360
  store <8 x i1> %10362, ptr %10358, align 1
  %10363 = select i1 %10336, <8 x i1> zeroinitializer, <8 x i1> %10361
  store <8 x i1> %10363, ptr %10359, align 1
  %10364 = add i32 %10343, 1
  %10365 = select i1 %10334, i32 %10321, i32 %10364
  %10366 = select i1 true, i32 %10365, i32 %10321
  store i32 %10366, ptr %current.token, align 4
  %10367 = load <8 x float>, ptr %.slot56, align 32
  %10368 = select <8 x i1> %2459, <8 x float> zeroinitializer, <8 x float> %10367
  store <8 x float> %10368, ptr %.slot56, align 32
  %10369 = load i32, ptr %current.token, align 4
  %10370 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2457)
  %10371 = load i32, ptr %ready.count, align 4
  %10372 = icmp uge i32 %10371, 8
  %10373 = and i1 %10370, %10372
  br i1 %10373, label %ready.overflow.trap2166, label %ready.overflow.resume2167

ready.overflow.trap2166:                          ; preds = %convergence.overflow.resume2165
  call void @llvm.trap()
  unreachable

ready.overflow.resume2167:                        ; preds = %convergence.overflow.resume2165
  %10374 = select i1 %10370, i32 %10371, i32 0
  %10375 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10374
  %10376 = load <8 x i1>, ptr %10375, align 1
  %10377 = select i1 %10370, <8 x i1> %2457, <8 x i1> %10376
  store <8 x i1> %10377, ptr %10375, align 1
  %10378 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10374
  %10379 = load i32, ptr %10378, align 4
  %10380 = select i1 %10370, i32 107, i32 %10379
  store i32 %10380, ptr %10378, align 4
  %10381 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10374
  %10382 = load i32, ptr %10381, align 4
  %10383 = select i1 %10370, i32 %10369, i32 %10382
  store i32 %10383, ptr %10381, align 4
  %10384 = add i32 %10371, 1
  %10385 = select i1 %10370, i32 %10384, i32 %10371
  store i32 %10385, ptr %ready.count, align 4
  %10386 = load <8 x i1>, ptr %runnable.mask, align 1
  %10387 = or <8 x i1> %10386, %2457
  store <8 x i1> %10387, ptr %runnable.mask, align 1
  store <8 x i1> %2459, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2168:                        ; preds = %varying.coherent2163
  store <8 x i1> %2428, ptr %current.mask, align 1
  %10388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2428)
  br i1 %10388, label %schedule.107, label %scheduler.loop

varying.coherent.false2169:                       ; preds = %varying.coherent2163
  %10389 = load <8 x float>, ptr %.slot56, align 32
  %10390 = select <8 x i1> %2428, <8 x float> zeroinitializer, <8 x float> %10389
  store <8 x float> %10390, ptr %.slot56, align 32
  store <8 x i1> %2428, ptr %current.mask, align 1
  %10391 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2428)
  br i1 %10391, label %schedule.108, label %scheduler.loop

convergence.cascade2171:                          ; preds = %convergence.cascade2171, %schedule.108
  %convergence.cascade.flow2175 = phi <8 x i1> [ %2476, %schedule.108 ], [ %10434, %convergence.cascade2171 ]
  %convergence.cascade.depth2176 = phi i32 [ 0, %schedule.108 ], [ %10435, %convergence.cascade2171 ]
  %10392 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2175)
  %10393 = load i32, ptr %current.token, align 4
  %10394 = icmp ne i32 %10393, 0
  %10395 = and i1 %10392, %10394
  %10396 = sub i32 %10393, 1
  %10397 = select i1 %10395, i32 %10396, i32 0
  %10398 = load i8, ptr %frame.active, align 1
  %10399 = trunc i32 %10397 to i8
  %10400 = shl i8 1, %10399
  %10401 = and i8 %10398, %10400
  %10402 = icmp ne i8 %10401, 0
  %10403 = load <8 x i32>, ptr %frame.static.id, align 32
  %10404 = extractelement <8 x i32> %10403, i32 %10397
  %convergence.target.pointer2177 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %10404
  %convergence.dynamic.target2178 = load i32, ptr %convergence.target.pointer2177, align 4
  %10405 = icmp eq i32 %convergence.dynamic.target2178, 108
  %10406 = and i1 %10402, %10405
  %10407 = and i1 %10395, %10406
  %10408 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10397
  %10409 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10397
  %10410 = load <8 x i1>, ptr %10408, align 1
  %10411 = load <8 x i1>, ptr %10409, align 1
  %10412 = or <8 x i1> %10411, %convergence.cascade.flow2175
  %10413 = load <8 x i1>, ptr %live.mask, align 1
  %10414 = and <8 x i1> %10410, %10413
  %10415 = icmp eq <8 x i1> %10412, %10414
  %10416 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10415)
  %10417 = and i1 %10407, %10416
  %10418 = select i1 %10417, <8 x i1> zeroinitializer, <8 x i1> %10412
  %10419 = select i1 %10407, <8 x i1> %10418, <8 x i1> %10411
  store <8 x i1> %10419, ptr %10409, align 1
  %10420 = select i1 %10417, <8 x i1> zeroinitializer, <8 x i1> %10410
  store <8 x i1> %10420, ptr %10408, align 1
  %10421 = trunc i32 %10397 to i8
  %10422 = shl i8 1, %10421
  %10423 = xor i8 %10422, -1
  %10424 = and i8 %10398, %10423
  %10425 = select i1 %10417, i8 %10424, i8 %10398
  store i8 %10425, ptr %frame.active, align 1
  %.splatinsert2179 = insertelement <8 x i1> poison, i1 %10407, i64 0
  %.splat2180 = shufflevector <8 x i1> %.splatinsert2179, <8 x i1> poison, <8 x i32> zeroinitializer
  %10426 = and <8 x i1> %convergence.cascade.flow2175, %.splat2180
  %10427 = load <8 x i1>, ptr %runnable.mask, align 1
  %10428 = xor <8 x i1> %10426, splat (i1 true)
  %10429 = and <8 x i1> %10427, %10428
  store <8 x i1> %10429, ptr %runnable.mask, align 1
  %.splatinsert2181 = insertelement <8 x i1> poison, i1 %10417, i64 0
  %.splat2182 = shufflevector <8 x i1> %.splatinsert2181, <8 x i1> poison, <8 x i32> zeroinitializer
  %10430 = select <8 x i1> %.splat2182, <8 x i1> %10412, <8 x i1> zeroinitializer
  %10431 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10432 = extractelement <8 x i32> %10431, i32 %10397
  %10433 = select i1 %10417, i32 %10432, i32 %10393
  store i32 %10433, ptr %current.token, align 4
  %.splatinsert2183 = insertelement <8 x i1> poison, i1 %10407, i64 0
  %.splat2184 = shufflevector <8 x i1> %.splatinsert2183, <8 x i1> poison, <8 x i32> zeroinitializer
  %10434 = select <8 x i1> %.splat2184, <8 x i1> %10430, <8 x i1> %convergence.cascade.flow2175
  %10435 = add i32 %convergence.cascade.depth2176, 1
  %10436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10434)
  %10437 = icmp ult i32 %10435, 8
  %10438 = and i1 %10436, %10437
  %10439 = and i1 %10407, %10438
  %convergence.parent.token2185 = load i32, ptr %current.token, align 4
  %convergence.parent.present2186 = icmp ne i32 %convergence.parent.token2185, 0
  %10440 = and i1 %10439, %convergence.parent.present2186
  br i1 %10440, label %convergence.cascade2171, label %convergence.cascade.exit2172

convergence.cascade.exit2172:                     ; preds = %convergence.cascade2171, %schedule.108
  %convergence.cascade.result2187 = phi <8 x i1> [ %2476, %schedule.108 ], [ %10434, %convergence.cascade2171 ]
  %10441 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2187)
  br i1 %10441, label %convergence.target.108.ready, label %scheduler.loop

convergence.target.108.ready:                     ; preds = %convergence.cascade.exit2172
  %10442 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2187)
  %10443 = bitcast <8 x i1> %convergence.cascade.result2187 to i8
  %10444 = call i8 @llvm.cttz.i8(i8 %10443, i1 false)
  %10445 = zext i8 %10444 to i32
  %10446 = select i1 %10442, i32 %10445, i32 0
  %tile_snapshot.spill.load2188 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill52, align 64
  %10447 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2188, 0
  %10448 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2188, 1
  %.state2189 = load <8 x i64>, ptr %.slot55, align 64
  %10449 = mul <8 x i64> %.state2189, splat (i64 4)
  %10450 = add <8 x i64> %10448, %10449
  %10451 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10447, 0
  %10452 = insertvalue { <8 x ptr>, <8 x i64> } %10451, <8 x i64> %10450, 1
  %.state2190 = load <8 x float>, ptr %.slot56, align 32
  %10453 = extractvalue { <8 x ptr>, <8 x i64> } %10452, 0
  %10454 = extractvalue { <8 x ptr>, <8 x i64> } %10452, 1
  %10455 = getelementptr i8, <8 x ptr> %10453, <8 x i64> %10454
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state2190, <8 x ptr> align 1 %10455, <8 x i1> %convergence.cascade.result2187)
  %.state2191 = load <8 x i64>, ptr %.slot55, align 64
  %10456 = add <8 x i64> %.state2191, splat (i64 1)
  %10457 = load <8 x i64>, ptr %.slot55, align 64
  %10458 = select <8 x i1> %convergence.cascade.result2187, <8 x i64> %10456, <8 x i64> %10457
  store <8 x i64> %10458, ptr %.slot55, align 64
  store <8 x i1> %convergence.cascade.result2187, ptr %current.mask, align 1
  %10459 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2187)
  br i1 %10459, label %schedule.105, label %scheduler.loop

convergence.cascade2192:                          ; preds = %convergence.cascade2192, %schedule.109
  %convergence.cascade.flow2196 = phi <8 x i1> [ %2477, %schedule.109 ], [ %10502, %convergence.cascade2192 ]
  %convergence.cascade.depth2197 = phi i32 [ 0, %schedule.109 ], [ %10503, %convergence.cascade2192 ]
  %10460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2196)
  %10461 = load i32, ptr %current.token, align 4
  %10462 = icmp ne i32 %10461, 0
  %10463 = and i1 %10460, %10462
  %10464 = sub i32 %10461, 1
  %10465 = select i1 %10463, i32 %10464, i32 0
  %10466 = load i8, ptr %frame.active, align 1
  %10467 = trunc i32 %10465 to i8
  %10468 = shl i8 1, %10467
  %10469 = and i8 %10466, %10468
  %10470 = icmp ne i8 %10469, 0
  %10471 = load <8 x i32>, ptr %frame.static.id, align 32
  %10472 = extractelement <8 x i32> %10471, i32 %10465
  %convergence.target.pointer2198 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %10472
  %convergence.dynamic.target2199 = load i32, ptr %convergence.target.pointer2198, align 4
  %10473 = icmp eq i32 %convergence.dynamic.target2199, 109
  %10474 = and i1 %10470, %10473
  %10475 = and i1 %10463, %10474
  %10476 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10465
  %10477 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10465
  %10478 = load <8 x i1>, ptr %10476, align 1
  %10479 = load <8 x i1>, ptr %10477, align 1
  %10480 = or <8 x i1> %10479, %convergence.cascade.flow2196
  %10481 = load <8 x i1>, ptr %live.mask, align 1
  %10482 = and <8 x i1> %10478, %10481
  %10483 = icmp eq <8 x i1> %10480, %10482
  %10484 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10483)
  %10485 = and i1 %10475, %10484
  %10486 = select i1 %10485, <8 x i1> zeroinitializer, <8 x i1> %10480
  %10487 = select i1 %10475, <8 x i1> %10486, <8 x i1> %10479
  store <8 x i1> %10487, ptr %10477, align 1
  %10488 = select i1 %10485, <8 x i1> zeroinitializer, <8 x i1> %10478
  store <8 x i1> %10488, ptr %10476, align 1
  %10489 = trunc i32 %10465 to i8
  %10490 = shl i8 1, %10489
  %10491 = xor i8 %10490, -1
  %10492 = and i8 %10466, %10491
  %10493 = select i1 %10485, i8 %10492, i8 %10466
  store i8 %10493, ptr %frame.active, align 1
  %.splatinsert2200 = insertelement <8 x i1> poison, i1 %10475, i64 0
  %.splat2201 = shufflevector <8 x i1> %.splatinsert2200, <8 x i1> poison, <8 x i32> zeroinitializer
  %10494 = and <8 x i1> %convergence.cascade.flow2196, %.splat2201
  %10495 = load <8 x i1>, ptr %runnable.mask, align 1
  %10496 = xor <8 x i1> %10494, splat (i1 true)
  %10497 = and <8 x i1> %10495, %10496
  store <8 x i1> %10497, ptr %runnable.mask, align 1
  %.splatinsert2202 = insertelement <8 x i1> poison, i1 %10485, i64 0
  %.splat2203 = shufflevector <8 x i1> %.splatinsert2202, <8 x i1> poison, <8 x i32> zeroinitializer
  %10498 = select <8 x i1> %.splat2203, <8 x i1> %10480, <8 x i1> zeroinitializer
  %10499 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10500 = extractelement <8 x i32> %10499, i32 %10465
  %10501 = select i1 %10485, i32 %10500, i32 %10461
  store i32 %10501, ptr %current.token, align 4
  %.splatinsert2204 = insertelement <8 x i1> poison, i1 %10475, i64 0
  %.splat2205 = shufflevector <8 x i1> %.splatinsert2204, <8 x i1> poison, <8 x i32> zeroinitializer
  %10502 = select <8 x i1> %.splat2205, <8 x i1> %10498, <8 x i1> %convergence.cascade.flow2196
  %10503 = add i32 %convergence.cascade.depth2197, 1
  %10504 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10502)
  %10505 = icmp ult i32 %10503, 8
  %10506 = and i1 %10504, %10505
  %10507 = and i1 %10475, %10506
  %convergence.parent.token2206 = load i32, ptr %current.token, align 4
  %convergence.parent.present2207 = icmp ne i32 %convergence.parent.token2206, 0
  %10508 = and i1 %10507, %convergence.parent.present2207
  br i1 %10508, label %convergence.cascade2192, label %convergence.cascade.exit2193

convergence.cascade.exit2193:                     ; preds = %convergence.cascade2192, %schedule.109
  %convergence.cascade.result2208 = phi <8 x i1> [ %2477, %schedule.109 ], [ %10502, %convergence.cascade2192 ]
  %10509 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2208)
  br i1 %10509, label %convergence.target.109.ready, label %scheduler.loop

convergence.target.109.ready:                     ; preds = %convergence.cascade.exit2193
  %10510 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2208)
  %10511 = bitcast <8 x i1> %convergence.cascade.result2208 to i8
  %10512 = call i8 @llvm.cttz.i8(i8 %10511, i1 false)
  %10513 = zext i8 %10512 to i32
  %10514 = select i1 %10510, i32 %10513, i32 0
  %10515 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill319, align 64
  %10516 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10517 = extractvalue { <8 x ptr>, <8 x i64> } %10515, 0
  %10518 = select <8 x i1> %convergence.cascade.result2208, <8 x ptr> %10516, <8 x ptr> %10517
  %10519 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10520 = extractvalue { <8 x ptr>, <8 x i64> } %10515, 1
  %10521 = select <8 x i1> %convergence.cascade.result2208, <8 x i64> %10519, <8 x i64> %10520
  %10522 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10518, 0
  %10523 = insertvalue { <8 x ptr>, <8 x i64> } %10522, <8 x i64> %10521, 1
  store { <8 x ptr>, <8 x i64> } %10523, ptr %tile_snapshot.spill319, align 64
  %10524 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10525 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10526 = add <8 x i64> %10525, zeroinitializer
  %10527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10524, 0
  %10528 = insertvalue { <8 x ptr>, <8 x i64> } %10527, <8 x i64> %10526, 1
  %.state2209 = load <8 x float>, ptr %.slot47, align 32
  %10529 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10530 = extractvalue { <8 x ptr>, <8 x i64> } %10528, 1
  %10531 = extractelement <8 x ptr> %10529, i32 0
  %10532 = extractelement <8 x i64> %10530, i32 %10514
  %10533 = zext i32 %10514 to i64
  %10534 = mul i64 %10533, 4
  %10535 = sub i64 %10532, %10534
  %10536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2208)
  %10537 = select i1 %10536, i64 %10535, i64 0
  %private.contiguous.address2210 = getelementptr i8, ptr %10531, i64 %10537
  %private.contiguous.preserve2211 = load <8 x float>, ptr %private.contiguous.address2210, align 4
  %10538 = select <8 x i1> %convergence.cascade.result2208, <8 x float> %.state2209, <8 x float> %private.contiguous.preserve2211
  store <8 x float> %10538, ptr %private.contiguous.address2210, align 4
  %10539 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10540 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10541 = add <8 x i64> %10540, splat (i64 32)
  %10542 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10539, 0
  %10543 = insertvalue { <8 x ptr>, <8 x i64> } %10542, <8 x i64> %10541, 1
  %.state2212 = load <8 x float>, ptr %.slot48, align 32
  %10544 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10545 = extractvalue { <8 x ptr>, <8 x i64> } %10543, 1
  %10546 = extractelement <8 x ptr> %10544, i32 0
  %10547 = extractelement <8 x i64> %10545, i32 %10514
  %10548 = zext i32 %10514 to i64
  %10549 = mul i64 %10548, 4
  %10550 = sub i64 %10547, %10549
  %10551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2208)
  %10552 = select i1 %10551, i64 %10550, i64 0
  %private.contiguous.address2213 = getelementptr i8, ptr %10546, i64 %10552
  %private.contiguous.preserve2214 = load <8 x float>, ptr %private.contiguous.address2213, align 4
  %10553 = select <8 x i1> %convergence.cascade.result2208, <8 x float> %.state2212, <8 x float> %private.contiguous.preserve2214
  store <8 x float> %10553, ptr %private.contiguous.address2213, align 4
  %10554 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10555 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10556 = add <8 x i64> %10555, splat (i64 64)
  %10557 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10554, 0
  %10558 = insertvalue { <8 x ptr>, <8 x i64> } %10557, <8 x i64> %10556, 1
  %.state2215 = load <8 x float>, ptr %.slot49, align 32
  %10559 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10560 = extractvalue { <8 x ptr>, <8 x i64> } %10558, 1
  %10561 = extractelement <8 x ptr> %10559, i32 0
  %10562 = extractelement <8 x i64> %10560, i32 %10514
  %10563 = zext i32 %10514 to i64
  %10564 = mul i64 %10563, 4
  %10565 = sub i64 %10562, %10564
  %10566 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2208)
  %10567 = select i1 %10566, i64 %10565, i64 0
  %private.contiguous.address2216 = getelementptr i8, ptr %10561, i64 %10567
  %private.contiguous.preserve2217 = load <8 x float>, ptr %private.contiguous.address2216, align 4
  %10568 = select <8 x i1> %convergence.cascade.result2208, <8 x float> %.state2215, <8 x float> %private.contiguous.preserve2217
  store <8 x float> %10568, ptr %private.contiguous.address2216, align 4
  %10569 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10570 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %10571 = add <8 x i64> %10570, splat (i64 96)
  %10572 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %10569, 0
  %10573 = insertvalue { <8 x ptr>, <8 x i64> } %10572, <8 x i64> %10571, 1
  %.state2218 = load <8 x float>, ptr %.slot50, align 32
  %10574 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %10575 = extractvalue { <8 x ptr>, <8 x i64> } %10573, 1
  %10576 = extractelement <8 x ptr> %10574, i32 0
  %10577 = extractelement <8 x i64> %10575, i32 %10514
  %10578 = zext i32 %10514 to i64
  %10579 = mul i64 %10578, 4
  %10580 = sub i64 %10577, %10579
  %10581 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2208)
  %10582 = select i1 %10581, i64 %10580, i64 0
  %private.contiguous.address2219 = getelementptr i8, ptr %10576, i64 %10582
  %private.contiguous.preserve2220 = load <8 x float>, ptr %private.contiguous.address2219, align 4
  %10583 = select <8 x i1> %convergence.cascade.result2208, <8 x float> %.state2218, <8 x float> %private.contiguous.preserve2220
  store <8 x float> %10583, ptr %private.contiguous.address2219, align 4
  %10584 = load <8 x i64>, ptr %.slot, align 64
  %10585 = select <8 x i1> %convergence.cascade.result2208, <8 x i64> zeroinitializer, <8 x i64> %10584
  store <8 x i64> %10585, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result2208, ptr %current.mask, align 1
  %10586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2208)
  br i1 %10586, label %schedule.110, label %scheduler.loop

varying.divergent2222:                            ; preds = %schedule.110
  %10587 = load i32, ptr %current.token, align 4
  %10588 = icmp ne i32 %10587, 0
  %10589 = sub i32 %10587, 1
  %10590 = select i1 %10588, i32 %10589, i32 0
  %10591 = load i8, ptr %frame.active, align 1
  %10592 = trunc i32 %10590 to i8
  %10593 = shl i8 1, %10592
  %10594 = and i8 %10591, %10593
  %10595 = icmp ne i8 %10594, 0
  %10596 = load <8 x i32>, ptr %frame.static.id, align 32
  %10597 = extractelement <8 x i32> %10596, i32 %10590
  %10598 = icmp eq i32 %10597, 38
  %10599 = and i1 %10595, %10598
  %10600 = and i1 %10588, %10599
  %10601 = xor i1 %10600, true
  %10602 = and i1 true, %10601
  %10603 = xor i8 %10591, -1
  %10604 = icmp ne i8 %10603, 0
  %10605 = xor i1 %10604, true
  %10606 = and i1 %10602, %10605
  br i1 %10606, label %convergence.overflow.trap2224, label %convergence.overflow.resume2225

varying.coherent2223:                             ; preds = %schedule.110
  br i1 %2488, label %varying.coherent.true2228, label %varying.coherent.false2229

convergence.overflow.trap2224:                    ; preds = %varying.divergent2222
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2225:                  ; preds = %varying.divergent2222
  %10607 = call i8 @llvm.cttz.i8(i8 %10603, i1 false)
  %10608 = zext i8 %10607 to i32
  %10609 = select i1 %10604, i32 %10608, i32 0
  %10610 = trunc i32 %10609 to i8
  %10611 = shl i8 1, %10610
  %10612 = or i8 %10591, %10611
  %10613 = select i1 %10602, i8 %10612, i8 %10591
  store i8 %10613, ptr %frame.active, align 1
  %10614 = load <8 x i32>, ptr %frame.static.id, align 32
  %10615 = extractelement <8 x i32> %10614, i32 %10609
  %10616 = select i1 %10602, i32 38, i32 %10615
  %10617 = load <8 x i32>, ptr %frame.static.id, align 32
  %10618 = insertelement <8 x i32> %10617, i32 %10616, i32 %10609
  store <8 x i32> %10618, ptr %frame.static.id, align 32
  %10619 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10620 = extractelement <8 x i32> %10619, i32 %10609
  %10621 = select i1 %10602, i32 %10587, i32 %10620
  %10622 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10623 = insertelement <8 x i32> %10622, i32 %10621, i32 %10609
  store <8 x i32> %10623, ptr %frame.parent.token, align 32
  %10624 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10609
  %10625 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10609
  %10626 = load <8 x i1>, ptr %10624, align 1
  %10627 = load <8 x i1>, ptr %10625, align 1
  %10628 = select i1 %10602, <8 x i1> %2478, <8 x i1> %10626
  store <8 x i1> %10628, ptr %10624, align 1
  %10629 = select i1 %10602, <8 x i1> zeroinitializer, <8 x i1> %10627
  store <8 x i1> %10629, ptr %10625, align 1
  %10630 = add i32 %10609, 1
  %10631 = select i1 %10600, i32 %10587, i32 %10630
  %10632 = select i1 true, i32 %10631, i32 %10587
  store i32 %10632, ptr %current.token, align 4
  %10633 = load i32, ptr %current.token, align 4
  %10634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2485)
  %10635 = load i32, ptr %ready.count, align 4
  %10636 = icmp uge i32 %10635, 8
  %10637 = and i1 %10634, %10636
  br i1 %10637, label %ready.overflow.trap2226, label %ready.overflow.resume2227

ready.overflow.trap2226:                          ; preds = %convergence.overflow.resume2225
  call void @llvm.trap()
  unreachable

ready.overflow.resume2227:                        ; preds = %convergence.overflow.resume2225
  %10638 = select i1 %10634, i32 %10635, i32 0
  %10639 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10638
  %10640 = load <8 x i1>, ptr %10639, align 1
  %10641 = select i1 %10634, <8 x i1> %2485, <8 x i1> %10640
  store <8 x i1> %10641, ptr %10639, align 1
  %10642 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10638
  %10643 = load i32, ptr %10642, align 4
  %10644 = select i1 %10634, i32 111, i32 %10643
  store i32 %10644, ptr %10642, align 4
  %10645 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10638
  %10646 = load i32, ptr %10645, align 4
  %10647 = select i1 %10634, i32 %10633, i32 %10646
  store i32 %10647, ptr %10645, align 4
  %10648 = add i32 %10635, 1
  %10649 = select i1 %10634, i32 %10648, i32 %10635
  store i32 %10649, ptr %ready.count, align 4
  %10650 = load <8 x i1>, ptr %runnable.mask, align 1
  %10651 = or <8 x i1> %10650, %2485
  store <8 x i1> %10651, ptr %runnable.mask, align 1
  store <8 x i1> %2487, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2228:                        ; preds = %varying.coherent2223
  store <8 x i1> %2478, ptr %current.mask, align 1
  %10652 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2478)
  br i1 %10652, label %schedule.111, label %scheduler.loop

varying.coherent.false2229:                       ; preds = %varying.coherent2223
  store <8 x i1> %2478, ptr %current.mask, align 1
  %10653 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2478)
  br i1 %10653, label %schedule.114, label %scheduler.loop

varying.divergent2237:                            ; preds = %schedule.111
  %10654 = load i32, ptr %current.token, align 4
  %10655 = icmp ne i32 %10654, 0
  %10656 = sub i32 %10654, 1
  %10657 = select i1 %10655, i32 %10656, i32 0
  %10658 = load i8, ptr %frame.active, align 1
  %10659 = trunc i32 %10657 to i8
  %10660 = shl i8 1, %10659
  %10661 = and i8 %10658, %10660
  %10662 = icmp ne i8 %10661, 0
  %10663 = load <8 x i32>, ptr %frame.static.id, align 32
  %10664 = extractelement <8 x i32> %10663, i32 %10657
  %10665 = icmp eq i32 %10664, 39
  %10666 = and i1 %10662, %10665
  %10667 = and i1 %10655, %10666
  %10668 = xor i1 %10667, true
  %10669 = and i1 true, %10668
  %10670 = xor i8 %10658, -1
  %10671 = icmp ne i8 %10670, 0
  %10672 = xor i1 %10671, true
  %10673 = and i1 %10669, %10672
  br i1 %10673, label %convergence.overflow.trap2239, label %convergence.overflow.resume2240

varying.coherent2238:                             ; preds = %schedule.111
  br i1 %2549, label %varying.coherent.true2243, label %varying.coherent.false2244

convergence.overflow.trap2239:                    ; preds = %varying.divergent2237
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2240:                  ; preds = %varying.divergent2237
  %10674 = call i8 @llvm.cttz.i8(i8 %10670, i1 false)
  %10675 = zext i8 %10674 to i32
  %10676 = select i1 %10671, i32 %10675, i32 0
  %10677 = trunc i32 %10676 to i8
  %10678 = shl i8 1, %10677
  %10679 = or i8 %10658, %10678
  %10680 = select i1 %10669, i8 %10679, i8 %10658
  store i8 %10680, ptr %frame.active, align 1
  %10681 = load <8 x i32>, ptr %frame.static.id, align 32
  %10682 = extractelement <8 x i32> %10681, i32 %10676
  %10683 = select i1 %10669, i32 39, i32 %10682
  %10684 = load <8 x i32>, ptr %frame.static.id, align 32
  %10685 = insertelement <8 x i32> %10684, i32 %10683, i32 %10676
  store <8 x i32> %10685, ptr %frame.static.id, align 32
  %10686 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10687 = extractelement <8 x i32> %10686, i32 %10676
  %10688 = select i1 %10669, i32 %10654, i32 %10687
  %10689 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10690 = insertelement <8 x i32> %10689, i32 %10688, i32 %10676
  store <8 x i32> %10690, ptr %frame.parent.token, align 32
  %10691 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10676
  %10692 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10676
  %10693 = load <8 x i1>, ptr %10691, align 1
  %10694 = load <8 x i1>, ptr %10692, align 1
  %10695 = select i1 %10669, <8 x i1> %2491, <8 x i1> %10693
  store <8 x i1> %10695, ptr %10691, align 1
  %10696 = select i1 %10669, <8 x i1> zeroinitializer, <8 x i1> %10694
  store <8 x i1> %10696, ptr %10692, align 1
  %10697 = add i32 %10676, 1
  %10698 = select i1 %10667, i32 %10654, i32 %10697
  %10699 = select i1 true, i32 %10698, i32 %10654
  store i32 %10699, ptr %current.token, align 4
  %10700 = load i32, ptr %current.token, align 4
  %10701 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2546)
  %10702 = load i32, ptr %ready.count, align 4
  %10703 = icmp uge i32 %10702, 8
  %10704 = and i1 %10701, %10703
  br i1 %10704, label %ready.overflow.trap2241, label %ready.overflow.resume2242

ready.overflow.trap2241:                          ; preds = %convergence.overflow.resume2240
  call void @llvm.trap()
  unreachable

ready.overflow.resume2242:                        ; preds = %convergence.overflow.resume2240
  %10705 = select i1 %10701, i32 %10702, i32 0
  %10706 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10705
  %10707 = load <8 x i1>, ptr %10706, align 1
  %10708 = select i1 %10701, <8 x i1> %2546, <8 x i1> %10707
  store <8 x i1> %10708, ptr %10706, align 1
  %10709 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10705
  %10710 = load i32, ptr %10709, align 4
  %10711 = select i1 %10701, i32 112, i32 %10710
  store i32 %10711, ptr %10709, align 4
  %10712 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10705
  %10713 = load i32, ptr %10712, align 4
  %10714 = select i1 %10701, i32 %10700, i32 %10713
  store i32 %10714, ptr %10712, align 4
  %10715 = add i32 %10702, 1
  %10716 = select i1 %10701, i32 %10715, i32 %10702
  store i32 %10716, ptr %ready.count, align 4
  %10717 = load <8 x i1>, ptr %runnable.mask, align 1
  %10718 = or <8 x i1> %10717, %2546
  store <8 x i1> %10718, ptr %runnable.mask, align 1
  store <8 x i1> %2548, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2243:                        ; preds = %varying.coherent2238
  store <8 x i1> %2491, ptr %current.mask, align 1
  %10719 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2491)
  br i1 %10719, label %schedule.112, label %scheduler.loop

varying.coherent.false2244:                       ; preds = %varying.coherent2238
  store <8 x i1> %2491, ptr %current.mask, align 1
  %10720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2491)
  br i1 %10720, label %schedule.113, label %scheduler.loop

convergence.cascade2247:                          ; preds = %convergence.cascade2247, %schedule.113
  %convergence.cascade.flow2251 = phi <8 x i1> [ %2562, %schedule.113 ], [ %10763, %convergence.cascade2247 ]
  %convergence.cascade.depth2252 = phi i32 [ 0, %schedule.113 ], [ %10764, %convergence.cascade2247 ]
  %10721 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2251)
  %10722 = load i32, ptr %current.token, align 4
  %10723 = icmp ne i32 %10722, 0
  %10724 = and i1 %10721, %10723
  %10725 = sub i32 %10722, 1
  %10726 = select i1 %10724, i32 %10725, i32 0
  %10727 = load i8, ptr %frame.active, align 1
  %10728 = trunc i32 %10726 to i8
  %10729 = shl i8 1, %10728
  %10730 = and i8 %10727, %10729
  %10731 = icmp ne i8 %10730, 0
  %10732 = load <8 x i32>, ptr %frame.static.id, align 32
  %10733 = extractelement <8 x i32> %10732, i32 %10726
  %convergence.target.pointer2253 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %10733
  %convergence.dynamic.target2254 = load i32, ptr %convergence.target.pointer2253, align 4
  %10734 = icmp eq i32 %convergence.dynamic.target2254, 113
  %10735 = and i1 %10731, %10734
  %10736 = and i1 %10724, %10735
  %10737 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10726
  %10738 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10726
  %10739 = load <8 x i1>, ptr %10737, align 1
  %10740 = load <8 x i1>, ptr %10738, align 1
  %10741 = or <8 x i1> %10740, %convergence.cascade.flow2251
  %10742 = load <8 x i1>, ptr %live.mask, align 1
  %10743 = and <8 x i1> %10739, %10742
  %10744 = icmp eq <8 x i1> %10741, %10743
  %10745 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10744)
  %10746 = and i1 %10736, %10745
  %10747 = select i1 %10746, <8 x i1> zeroinitializer, <8 x i1> %10741
  %10748 = select i1 %10736, <8 x i1> %10747, <8 x i1> %10740
  store <8 x i1> %10748, ptr %10738, align 1
  %10749 = select i1 %10746, <8 x i1> zeroinitializer, <8 x i1> %10739
  store <8 x i1> %10749, ptr %10737, align 1
  %10750 = trunc i32 %10726 to i8
  %10751 = shl i8 1, %10750
  %10752 = xor i8 %10751, -1
  %10753 = and i8 %10727, %10752
  %10754 = select i1 %10746, i8 %10753, i8 %10727
  store i8 %10754, ptr %frame.active, align 1
  %.splatinsert2255 = insertelement <8 x i1> poison, i1 %10736, i64 0
  %.splat2256 = shufflevector <8 x i1> %.splatinsert2255, <8 x i1> poison, <8 x i32> zeroinitializer
  %10755 = and <8 x i1> %convergence.cascade.flow2251, %.splat2256
  %10756 = load <8 x i1>, ptr %runnable.mask, align 1
  %10757 = xor <8 x i1> %10755, splat (i1 true)
  %10758 = and <8 x i1> %10756, %10757
  store <8 x i1> %10758, ptr %runnable.mask, align 1
  %.splatinsert2257 = insertelement <8 x i1> poison, i1 %10746, i64 0
  %.splat2258 = shufflevector <8 x i1> %.splatinsert2257, <8 x i1> poison, <8 x i32> zeroinitializer
  %10759 = select <8 x i1> %.splat2258, <8 x i1> %10741, <8 x i1> zeroinitializer
  %10760 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10761 = extractelement <8 x i32> %10760, i32 %10726
  %10762 = select i1 %10746, i32 %10761, i32 %10722
  store i32 %10762, ptr %current.token, align 4
  %.splatinsert2259 = insertelement <8 x i1> poison, i1 %10736, i64 0
  %.splat2260 = shufflevector <8 x i1> %.splatinsert2259, <8 x i1> poison, <8 x i32> zeroinitializer
  %10763 = select <8 x i1> %.splat2260, <8 x i1> %10759, <8 x i1> %convergence.cascade.flow2251
  %10764 = add i32 %convergence.cascade.depth2252, 1
  %10765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10763)
  %10766 = icmp ult i32 %10764, 8
  %10767 = and i1 %10765, %10766
  %10768 = and i1 %10736, %10767
  %convergence.parent.token2261 = load i32, ptr %current.token, align 4
  %convergence.parent.present2262 = icmp ne i32 %convergence.parent.token2261, 0
  %10769 = and i1 %10768, %convergence.parent.present2262
  br i1 %10769, label %convergence.cascade2247, label %convergence.cascade.exit2248

convergence.cascade.exit2248:                     ; preds = %convergence.cascade2247, %schedule.113
  %convergence.cascade.result2263 = phi <8 x i1> [ %2562, %schedule.113 ], [ %10763, %convergence.cascade2247 ]
  %10770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2263)
  br i1 %10770, label %convergence.target.113.ready, label %scheduler.loop

convergence.target.113.ready:                     ; preds = %convergence.cascade.exit2248
  %10771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2263)
  %10772 = bitcast <8 x i1> %convergence.cascade.result2263 to i8
  %10773 = call i8 @llvm.cttz.i8(i8 %10772, i1 false)
  %10774 = zext i8 %10773 to i32
  %10775 = select i1 %10771, i32 %10774, i32 0
  %.state2264 = load <8 x i64>, ptr %.slot, align 64
  %10776 = add <8 x i64> %.state2264, splat (i64 1)
  %10777 = load <8 x i64>, ptr %.slot, align 64
  %10778 = select <8 x i1> %convergence.cascade.result2263, <8 x i64> %10776, <8 x i64> %10777
  store <8 x i64> %10778, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result2263, ptr %current.mask, align 1
  %10779 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2263)
  br i1 %10779, label %schedule.110, label %scheduler.loop

convergence.cascade2265:                          ; preds = %convergence.cascade2265, %schedule.114
  %convergence.cascade.flow2269 = phi <8 x i1> [ %2563, %schedule.114 ], [ %10822, %convergence.cascade2265 ]
  %convergence.cascade.depth2270 = phi i32 [ 0, %schedule.114 ], [ %10823, %convergence.cascade2265 ]
  %10780 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2269)
  %10781 = load i32, ptr %current.token, align 4
  %10782 = icmp ne i32 %10781, 0
  %10783 = and i1 %10780, %10782
  %10784 = sub i32 %10781, 1
  %10785 = select i1 %10783, i32 %10784, i32 0
  %10786 = load i8, ptr %frame.active, align 1
  %10787 = trunc i32 %10785 to i8
  %10788 = shl i8 1, %10787
  %10789 = and i8 %10786, %10788
  %10790 = icmp ne i8 %10789, 0
  %10791 = load <8 x i32>, ptr %frame.static.id, align 32
  %10792 = extractelement <8 x i32> %10791, i32 %10785
  %convergence.target.pointer2271 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %10792
  %convergence.dynamic.target2272 = load i32, ptr %convergence.target.pointer2271, align 4
  %10793 = icmp eq i32 %convergence.dynamic.target2272, 114
  %10794 = and i1 %10790, %10793
  %10795 = and i1 %10783, %10794
  %10796 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %10785
  %10797 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %10785
  %10798 = load <8 x i1>, ptr %10796, align 1
  %10799 = load <8 x i1>, ptr %10797, align 1
  %10800 = or <8 x i1> %10799, %convergence.cascade.flow2269
  %10801 = load <8 x i1>, ptr %live.mask, align 1
  %10802 = and <8 x i1> %10798, %10801
  %10803 = icmp eq <8 x i1> %10800, %10802
  %10804 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10803)
  %10805 = and i1 %10795, %10804
  %10806 = select i1 %10805, <8 x i1> zeroinitializer, <8 x i1> %10800
  %10807 = select i1 %10795, <8 x i1> %10806, <8 x i1> %10799
  store <8 x i1> %10807, ptr %10797, align 1
  %10808 = select i1 %10805, <8 x i1> zeroinitializer, <8 x i1> %10798
  store <8 x i1> %10808, ptr %10796, align 1
  %10809 = trunc i32 %10785 to i8
  %10810 = shl i8 1, %10809
  %10811 = xor i8 %10810, -1
  %10812 = and i8 %10786, %10811
  %10813 = select i1 %10805, i8 %10812, i8 %10786
  store i8 %10813, ptr %frame.active, align 1
  %.splatinsert2273 = insertelement <8 x i1> poison, i1 %10795, i64 0
  %.splat2274 = shufflevector <8 x i1> %.splatinsert2273, <8 x i1> poison, <8 x i32> zeroinitializer
  %10814 = and <8 x i1> %convergence.cascade.flow2269, %.splat2274
  %10815 = load <8 x i1>, ptr %runnable.mask, align 1
  %10816 = xor <8 x i1> %10814, splat (i1 true)
  %10817 = and <8 x i1> %10815, %10816
  store <8 x i1> %10817, ptr %runnable.mask, align 1
  %.splatinsert2275 = insertelement <8 x i1> poison, i1 %10805, i64 0
  %.splat2276 = shufflevector <8 x i1> %.splatinsert2275, <8 x i1> poison, <8 x i32> zeroinitializer
  %10818 = select <8 x i1> %.splat2276, <8 x i1> %10800, <8 x i1> zeroinitializer
  %10819 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10820 = extractelement <8 x i32> %10819, i32 %10785
  %10821 = select i1 %10805, i32 %10820, i32 %10781
  store i32 %10821, ptr %current.token, align 4
  %.splatinsert2277 = insertelement <8 x i1> poison, i1 %10795, i64 0
  %.splat2278 = shufflevector <8 x i1> %.splatinsert2277, <8 x i1> poison, <8 x i32> zeroinitializer
  %10822 = select <8 x i1> %.splat2278, <8 x i1> %10818, <8 x i1> %convergence.cascade.flow2269
  %10823 = add i32 %convergence.cascade.depth2270, 1
  %10824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10822)
  %10825 = icmp ult i32 %10823, 8
  %10826 = and i1 %10824, %10825
  %10827 = and i1 %10795, %10826
  %convergence.parent.token2279 = load i32, ptr %current.token, align 4
  %convergence.parent.present2280 = icmp ne i32 %convergence.parent.token2279, 0
  %10828 = and i1 %10827, %convergence.parent.present2280
  br i1 %10828, label %convergence.cascade2265, label %convergence.cascade.exit2266

convergence.cascade.exit2266:                     ; preds = %convergence.cascade2265, %schedule.114
  %convergence.cascade.result2281 = phi <8 x i1> [ %2563, %schedule.114 ], [ %10822, %convergence.cascade2265 ]
  %10829 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2281)
  br i1 %10829, label %convergence.target.114.ready, label %scheduler.loop

convergence.target.114.ready:                     ; preds = %convergence.cascade.exit2266
  %10830 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2281)
  %10831 = bitcast <8 x i1> %convergence.cascade.result2281 to i8
  %10832 = call i8 @llvm.cttz.i8(i8 %10831, i1 false)
  %10833 = zext i8 %10832 to i32
  %10834 = select i1 %10830, i32 %10833, i32 0
  %10835 = load <8 x i1>, ptr %live.mask, align 1
  %10836 = xor <8 x i1> %convergence.cascade.result2281, splat (i1 true)
  %10837 = and <8 x i1> %10835, %10836
  store <8 x i1> %10837, ptr %live.mask, align 1
  %10838 = load <8 x i1>, ptr %runnable.mask, align 1
  %10839 = xor <8 x i1> %convergence.cascade.result2281, splat (i1 true)
  %10840 = and <8 x i1> %10838, %10839
  store <8 x i1> %10840, ptr %runnable.mask, align 1
  %return.active.frames = load i8, ptr %frame.active, align 1
  %return.frames.present = icmp ne i8 %return.active.frames, 0
  br i1 %return.frames.present, label %return.frame.cleanup, label %return.frame.cleanup.done

return.frame.cleanup:                             ; preds = %convergence.target.114.ready
  %10841 = load i8, ptr %frame.active, align 1
  %10842 = and i8 %10841, 1
  %10843 = icmp ne i8 %10842, 0
  %10844 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 0
  %10845 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 0
  %10846 = load <8 x i1>, ptr %10844, align 1
  %10847 = load <8 x i1>, ptr %10845, align 1
  %10848 = and <8 x i1> %10846, %10837
  %10849 = icmp eq <8 x i1> %10847, %10848
  %10850 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10849)
  %10851 = and i1 %10843, %10850
  %.splatinsert2282 = insertelement <8 x i1> poison, i1 %10851, i64 0
  %.splat2283 = shufflevector <8 x i1> %.splatinsert2282, <8 x i1> poison, <8 x i32> zeroinitializer
  %10852 = select <8 x i1> %.splat2283, <8 x i1> %10847, <8 x i1> zeroinitializer
  %10853 = select i1 %10851, <8 x i1> zeroinitializer, <8 x i1> %10848
  store <8 x i1> %10853, ptr %10844, align 1
  %10854 = select i1 %10851, <8 x i1> zeroinitializer, <8 x i1> %10847
  store <8 x i1> %10854, ptr %10845, align 1
  %10855 = and i8 %10841, -2
  %10856 = select i1 %10851, i8 %10855, i8 %10841
  store i8 %10856, ptr %frame.active, align 1
  %10857 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10858 = extractelement <8 x i32> %10857, i32 0
  %10859 = load <8 x i32>, ptr %frame.static.id, align 32
  %10860 = extractelement <8 x i32> %10859, i32 0
  %convergence.target.pointer2284 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %10860
  %convergence.dynamic.target2285 = load i32, ptr %convergence.target.pointer2284, align 4
  %10861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10852)
  %10862 = load i32, ptr %ready.count, align 4
  %10863 = icmp uge i32 %10862, 8
  %10864 = and i1 %10861, %10863
  br i1 %10864, label %ready.overflow.trap2286, label %ready.overflow.resume2287

return.frame.cleanup.done:                        ; preds = %ready.overflow.resume2329, %convergence.target.114.ready
  br label %scheduler.loop

ready.overflow.trap2286:                          ; preds = %return.frame.cleanup
  call void @llvm.trap()
  unreachable

ready.overflow.resume2287:                        ; preds = %return.frame.cleanup
  %10865 = select i1 %10861, i32 %10862, i32 0
  %10866 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10865
  %10867 = load <8 x i1>, ptr %10866, align 1
  %10868 = select i1 %10861, <8 x i1> %10852, <8 x i1> %10867
  store <8 x i1> %10868, ptr %10866, align 1
  %10869 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10865
  %10870 = load i32, ptr %10869, align 4
  %10871 = select i1 %10861, i32 %convergence.dynamic.target2285, i32 %10870
  store i32 %10871, ptr %10869, align 4
  %10872 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10865
  %10873 = load i32, ptr %10872, align 4
  %10874 = select i1 %10861, i32 %10858, i32 %10873
  store i32 %10874, ptr %10872, align 4
  %10875 = add i32 %10862, 1
  %10876 = select i1 %10861, i32 %10875, i32 %10862
  store i32 %10876, ptr %ready.count, align 4
  %10877 = load <8 x i1>, ptr %runnable.mask, align 1
  %10878 = or <8 x i1> %10877, %10852
  store <8 x i1> %10878, ptr %runnable.mask, align 1
  %10879 = load i8, ptr %frame.active, align 1
  %10880 = and i8 %10879, 2
  %10881 = icmp ne i8 %10880, 0
  %10882 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 1
  %10883 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 1
  %10884 = load <8 x i1>, ptr %10882, align 1
  %10885 = load <8 x i1>, ptr %10883, align 1
  %10886 = and <8 x i1> %10884, %10837
  %10887 = icmp eq <8 x i1> %10885, %10886
  %10888 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10887)
  %10889 = and i1 %10881, %10888
  %.splatinsert2288 = insertelement <8 x i1> poison, i1 %10889, i64 0
  %.splat2289 = shufflevector <8 x i1> %.splatinsert2288, <8 x i1> poison, <8 x i32> zeroinitializer
  %10890 = select <8 x i1> %.splat2289, <8 x i1> %10885, <8 x i1> zeroinitializer
  %10891 = select i1 %10889, <8 x i1> zeroinitializer, <8 x i1> %10886
  store <8 x i1> %10891, ptr %10882, align 1
  %10892 = select i1 %10889, <8 x i1> zeroinitializer, <8 x i1> %10885
  store <8 x i1> %10892, ptr %10883, align 1
  %10893 = and i8 %10879, -3
  %10894 = select i1 %10889, i8 %10893, i8 %10879
  store i8 %10894, ptr %frame.active, align 1
  %10895 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10896 = extractelement <8 x i32> %10895, i32 1
  %10897 = load <8 x i32>, ptr %frame.static.id, align 32
  %10898 = extractelement <8 x i32> %10897, i32 1
  %convergence.target.pointer2290 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %10898
  %convergence.dynamic.target2291 = load i32, ptr %convergence.target.pointer2290, align 4
  %10899 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10890)
  %10900 = load i32, ptr %ready.count, align 4
  %10901 = icmp uge i32 %10900, 8
  %10902 = and i1 %10899, %10901
  br i1 %10902, label %ready.overflow.trap2292, label %ready.overflow.resume2293

ready.overflow.trap2292:                          ; preds = %ready.overflow.resume2287
  call void @llvm.trap()
  unreachable

ready.overflow.resume2293:                        ; preds = %ready.overflow.resume2287
  %10903 = select i1 %10899, i32 %10900, i32 0
  %10904 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10903
  %10905 = load <8 x i1>, ptr %10904, align 1
  %10906 = select i1 %10899, <8 x i1> %10890, <8 x i1> %10905
  store <8 x i1> %10906, ptr %10904, align 1
  %10907 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10903
  %10908 = load i32, ptr %10907, align 4
  %10909 = select i1 %10899, i32 %convergence.dynamic.target2291, i32 %10908
  store i32 %10909, ptr %10907, align 4
  %10910 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10903
  %10911 = load i32, ptr %10910, align 4
  %10912 = select i1 %10899, i32 %10896, i32 %10911
  store i32 %10912, ptr %10910, align 4
  %10913 = add i32 %10900, 1
  %10914 = select i1 %10899, i32 %10913, i32 %10900
  store i32 %10914, ptr %ready.count, align 4
  %10915 = load <8 x i1>, ptr %runnable.mask, align 1
  %10916 = or <8 x i1> %10915, %10890
  store <8 x i1> %10916, ptr %runnable.mask, align 1
  %10917 = load i8, ptr %frame.active, align 1
  %10918 = and i8 %10917, 4
  %10919 = icmp ne i8 %10918, 0
  %10920 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 2
  %10921 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 2
  %10922 = load <8 x i1>, ptr %10920, align 1
  %10923 = load <8 x i1>, ptr %10921, align 1
  %10924 = and <8 x i1> %10922, %10837
  %10925 = icmp eq <8 x i1> %10923, %10924
  %10926 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10925)
  %10927 = and i1 %10919, %10926
  %.splatinsert2294 = insertelement <8 x i1> poison, i1 %10927, i64 0
  %.splat2295 = shufflevector <8 x i1> %.splatinsert2294, <8 x i1> poison, <8 x i32> zeroinitializer
  %10928 = select <8 x i1> %.splat2295, <8 x i1> %10923, <8 x i1> zeroinitializer
  %10929 = select i1 %10927, <8 x i1> zeroinitializer, <8 x i1> %10924
  store <8 x i1> %10929, ptr %10920, align 1
  %10930 = select i1 %10927, <8 x i1> zeroinitializer, <8 x i1> %10923
  store <8 x i1> %10930, ptr %10921, align 1
  %10931 = and i8 %10917, -5
  %10932 = select i1 %10927, i8 %10931, i8 %10917
  store i8 %10932, ptr %frame.active, align 1
  %10933 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10934 = extractelement <8 x i32> %10933, i32 2
  %10935 = load <8 x i32>, ptr %frame.static.id, align 32
  %10936 = extractelement <8 x i32> %10935, i32 2
  %convergence.target.pointer2296 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %10936
  %convergence.dynamic.target2297 = load i32, ptr %convergence.target.pointer2296, align 4
  %10937 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10928)
  %10938 = load i32, ptr %ready.count, align 4
  %10939 = icmp uge i32 %10938, 8
  %10940 = and i1 %10937, %10939
  br i1 %10940, label %ready.overflow.trap2298, label %ready.overflow.resume2299

ready.overflow.trap2298:                          ; preds = %ready.overflow.resume2293
  call void @llvm.trap()
  unreachable

ready.overflow.resume2299:                        ; preds = %ready.overflow.resume2293
  %10941 = select i1 %10937, i32 %10938, i32 0
  %10942 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10941
  %10943 = load <8 x i1>, ptr %10942, align 1
  %10944 = select i1 %10937, <8 x i1> %10928, <8 x i1> %10943
  store <8 x i1> %10944, ptr %10942, align 1
  %10945 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10941
  %10946 = load i32, ptr %10945, align 4
  %10947 = select i1 %10937, i32 %convergence.dynamic.target2297, i32 %10946
  store i32 %10947, ptr %10945, align 4
  %10948 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10941
  %10949 = load i32, ptr %10948, align 4
  %10950 = select i1 %10937, i32 %10934, i32 %10949
  store i32 %10950, ptr %10948, align 4
  %10951 = add i32 %10938, 1
  %10952 = select i1 %10937, i32 %10951, i32 %10938
  store i32 %10952, ptr %ready.count, align 4
  %10953 = load <8 x i1>, ptr %runnable.mask, align 1
  %10954 = or <8 x i1> %10953, %10928
  store <8 x i1> %10954, ptr %runnable.mask, align 1
  %10955 = load i8, ptr %frame.active, align 1
  %10956 = and i8 %10955, 8
  %10957 = icmp ne i8 %10956, 0
  %10958 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 3
  %10959 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 3
  %10960 = load <8 x i1>, ptr %10958, align 1
  %10961 = load <8 x i1>, ptr %10959, align 1
  %10962 = and <8 x i1> %10960, %10837
  %10963 = icmp eq <8 x i1> %10961, %10962
  %10964 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %10963)
  %10965 = and i1 %10957, %10964
  %.splatinsert2300 = insertelement <8 x i1> poison, i1 %10965, i64 0
  %.splat2301 = shufflevector <8 x i1> %.splatinsert2300, <8 x i1> poison, <8 x i32> zeroinitializer
  %10966 = select <8 x i1> %.splat2301, <8 x i1> %10961, <8 x i1> zeroinitializer
  %10967 = select i1 %10965, <8 x i1> zeroinitializer, <8 x i1> %10962
  store <8 x i1> %10967, ptr %10958, align 1
  %10968 = select i1 %10965, <8 x i1> zeroinitializer, <8 x i1> %10961
  store <8 x i1> %10968, ptr %10959, align 1
  %10969 = and i8 %10955, -9
  %10970 = select i1 %10965, i8 %10969, i8 %10955
  store i8 %10970, ptr %frame.active, align 1
  %10971 = load <8 x i32>, ptr %frame.parent.token, align 32
  %10972 = extractelement <8 x i32> %10971, i32 3
  %10973 = load <8 x i32>, ptr %frame.static.id, align 32
  %10974 = extractelement <8 x i32> %10973, i32 3
  %convergence.target.pointer2302 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %10974
  %convergence.dynamic.target2303 = load i32, ptr %convergence.target.pointer2302, align 4
  %10975 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %10966)
  %10976 = load i32, ptr %ready.count, align 4
  %10977 = icmp uge i32 %10976, 8
  %10978 = and i1 %10975, %10977
  br i1 %10978, label %ready.overflow.trap2304, label %ready.overflow.resume2305

ready.overflow.trap2304:                          ; preds = %ready.overflow.resume2299
  call void @llvm.trap()
  unreachable

ready.overflow.resume2305:                        ; preds = %ready.overflow.resume2299
  %10979 = select i1 %10975, i32 %10976, i32 0
  %10980 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %10979
  %10981 = load <8 x i1>, ptr %10980, align 1
  %10982 = select i1 %10975, <8 x i1> %10966, <8 x i1> %10981
  store <8 x i1> %10982, ptr %10980, align 1
  %10983 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %10979
  %10984 = load i32, ptr %10983, align 4
  %10985 = select i1 %10975, i32 %convergence.dynamic.target2303, i32 %10984
  store i32 %10985, ptr %10983, align 4
  %10986 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %10979
  %10987 = load i32, ptr %10986, align 4
  %10988 = select i1 %10975, i32 %10972, i32 %10987
  store i32 %10988, ptr %10986, align 4
  %10989 = add i32 %10976, 1
  %10990 = select i1 %10975, i32 %10989, i32 %10976
  store i32 %10990, ptr %ready.count, align 4
  %10991 = load <8 x i1>, ptr %runnable.mask, align 1
  %10992 = or <8 x i1> %10991, %10966
  store <8 x i1> %10992, ptr %runnable.mask, align 1
  %10993 = load i8, ptr %frame.active, align 1
  %10994 = and i8 %10993, 16
  %10995 = icmp ne i8 %10994, 0
  %10996 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 4
  %10997 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 4
  %10998 = load <8 x i1>, ptr %10996, align 1
  %10999 = load <8 x i1>, ptr %10997, align 1
  %11000 = and <8 x i1> %10998, %10837
  %11001 = icmp eq <8 x i1> %10999, %11000
  %11002 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %11001)
  %11003 = and i1 %10995, %11002
  %.splatinsert2306 = insertelement <8 x i1> poison, i1 %11003, i64 0
  %.splat2307 = shufflevector <8 x i1> %.splatinsert2306, <8 x i1> poison, <8 x i32> zeroinitializer
  %11004 = select <8 x i1> %.splat2307, <8 x i1> %10999, <8 x i1> zeroinitializer
  %11005 = select i1 %11003, <8 x i1> zeroinitializer, <8 x i1> %11000
  store <8 x i1> %11005, ptr %10996, align 1
  %11006 = select i1 %11003, <8 x i1> zeroinitializer, <8 x i1> %10999
  store <8 x i1> %11006, ptr %10997, align 1
  %11007 = and i8 %10993, -17
  %11008 = select i1 %11003, i8 %11007, i8 %10993
  store i8 %11008, ptr %frame.active, align 1
  %11009 = load <8 x i32>, ptr %frame.parent.token, align 32
  %11010 = extractelement <8 x i32> %11009, i32 4
  %11011 = load <8 x i32>, ptr %frame.static.id, align 32
  %11012 = extractelement <8 x i32> %11011, i32 4
  %convergence.target.pointer2308 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %11012
  %convergence.dynamic.target2309 = load i32, ptr %convergence.target.pointer2308, align 4
  %11013 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %11004)
  %11014 = load i32, ptr %ready.count, align 4
  %11015 = icmp uge i32 %11014, 8
  %11016 = and i1 %11013, %11015
  br i1 %11016, label %ready.overflow.trap2310, label %ready.overflow.resume2311

ready.overflow.trap2310:                          ; preds = %ready.overflow.resume2305
  call void @llvm.trap()
  unreachable

ready.overflow.resume2311:                        ; preds = %ready.overflow.resume2305
  %11017 = select i1 %11013, i32 %11014, i32 0
  %11018 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %11017
  %11019 = load <8 x i1>, ptr %11018, align 1
  %11020 = select i1 %11013, <8 x i1> %11004, <8 x i1> %11019
  store <8 x i1> %11020, ptr %11018, align 1
  %11021 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %11017
  %11022 = load i32, ptr %11021, align 4
  %11023 = select i1 %11013, i32 %convergence.dynamic.target2309, i32 %11022
  store i32 %11023, ptr %11021, align 4
  %11024 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %11017
  %11025 = load i32, ptr %11024, align 4
  %11026 = select i1 %11013, i32 %11010, i32 %11025
  store i32 %11026, ptr %11024, align 4
  %11027 = add i32 %11014, 1
  %11028 = select i1 %11013, i32 %11027, i32 %11014
  store i32 %11028, ptr %ready.count, align 4
  %11029 = load <8 x i1>, ptr %runnable.mask, align 1
  %11030 = or <8 x i1> %11029, %11004
  store <8 x i1> %11030, ptr %runnable.mask, align 1
  %11031 = load i8, ptr %frame.active, align 1
  %11032 = and i8 %11031, 32
  %11033 = icmp ne i8 %11032, 0
  %11034 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 5
  %11035 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 5
  %11036 = load <8 x i1>, ptr %11034, align 1
  %11037 = load <8 x i1>, ptr %11035, align 1
  %11038 = and <8 x i1> %11036, %10837
  %11039 = icmp eq <8 x i1> %11037, %11038
  %11040 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %11039)
  %11041 = and i1 %11033, %11040
  %.splatinsert2312 = insertelement <8 x i1> poison, i1 %11041, i64 0
  %.splat2313 = shufflevector <8 x i1> %.splatinsert2312, <8 x i1> poison, <8 x i32> zeroinitializer
  %11042 = select <8 x i1> %.splat2313, <8 x i1> %11037, <8 x i1> zeroinitializer
  %11043 = select i1 %11041, <8 x i1> zeroinitializer, <8 x i1> %11038
  store <8 x i1> %11043, ptr %11034, align 1
  %11044 = select i1 %11041, <8 x i1> zeroinitializer, <8 x i1> %11037
  store <8 x i1> %11044, ptr %11035, align 1
  %11045 = and i8 %11031, -33
  %11046 = select i1 %11041, i8 %11045, i8 %11031
  store i8 %11046, ptr %frame.active, align 1
  %11047 = load <8 x i32>, ptr %frame.parent.token, align 32
  %11048 = extractelement <8 x i32> %11047, i32 5
  %11049 = load <8 x i32>, ptr %frame.static.id, align 32
  %11050 = extractelement <8 x i32> %11049, i32 5
  %convergence.target.pointer2314 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %11050
  %convergence.dynamic.target2315 = load i32, ptr %convergence.target.pointer2314, align 4
  %11051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %11042)
  %11052 = load i32, ptr %ready.count, align 4
  %11053 = icmp uge i32 %11052, 8
  %11054 = and i1 %11051, %11053
  br i1 %11054, label %ready.overflow.trap2316, label %ready.overflow.resume2317

ready.overflow.trap2316:                          ; preds = %ready.overflow.resume2311
  call void @llvm.trap()
  unreachable

ready.overflow.resume2317:                        ; preds = %ready.overflow.resume2311
  %11055 = select i1 %11051, i32 %11052, i32 0
  %11056 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %11055
  %11057 = load <8 x i1>, ptr %11056, align 1
  %11058 = select i1 %11051, <8 x i1> %11042, <8 x i1> %11057
  store <8 x i1> %11058, ptr %11056, align 1
  %11059 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %11055
  %11060 = load i32, ptr %11059, align 4
  %11061 = select i1 %11051, i32 %convergence.dynamic.target2315, i32 %11060
  store i32 %11061, ptr %11059, align 4
  %11062 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %11055
  %11063 = load i32, ptr %11062, align 4
  %11064 = select i1 %11051, i32 %11048, i32 %11063
  store i32 %11064, ptr %11062, align 4
  %11065 = add i32 %11052, 1
  %11066 = select i1 %11051, i32 %11065, i32 %11052
  store i32 %11066, ptr %ready.count, align 4
  %11067 = load <8 x i1>, ptr %runnable.mask, align 1
  %11068 = or <8 x i1> %11067, %11042
  store <8 x i1> %11068, ptr %runnable.mask, align 1
  %11069 = load i8, ptr %frame.active, align 1
  %11070 = and i8 %11069, 64
  %11071 = icmp ne i8 %11070, 0
  %11072 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 6
  %11073 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 6
  %11074 = load <8 x i1>, ptr %11072, align 1
  %11075 = load <8 x i1>, ptr %11073, align 1
  %11076 = and <8 x i1> %11074, %10837
  %11077 = icmp eq <8 x i1> %11075, %11076
  %11078 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %11077)
  %11079 = and i1 %11071, %11078
  %.splatinsert2318 = insertelement <8 x i1> poison, i1 %11079, i64 0
  %.splat2319 = shufflevector <8 x i1> %.splatinsert2318, <8 x i1> poison, <8 x i32> zeroinitializer
  %11080 = select <8 x i1> %.splat2319, <8 x i1> %11075, <8 x i1> zeroinitializer
  %11081 = select i1 %11079, <8 x i1> zeroinitializer, <8 x i1> %11076
  store <8 x i1> %11081, ptr %11072, align 1
  %11082 = select i1 %11079, <8 x i1> zeroinitializer, <8 x i1> %11075
  store <8 x i1> %11082, ptr %11073, align 1
  %11083 = and i8 %11069, -65
  %11084 = select i1 %11079, i8 %11083, i8 %11069
  store i8 %11084, ptr %frame.active, align 1
  %11085 = load <8 x i32>, ptr %frame.parent.token, align 32
  %11086 = extractelement <8 x i32> %11085, i32 6
  %11087 = load <8 x i32>, ptr %frame.static.id, align 32
  %11088 = extractelement <8 x i32> %11087, i32 6
  %convergence.target.pointer2320 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %11088
  %convergence.dynamic.target2321 = load i32, ptr %convergence.target.pointer2320, align 4
  %11089 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %11080)
  %11090 = load i32, ptr %ready.count, align 4
  %11091 = icmp uge i32 %11090, 8
  %11092 = and i1 %11089, %11091
  br i1 %11092, label %ready.overflow.trap2322, label %ready.overflow.resume2323

ready.overflow.trap2322:                          ; preds = %ready.overflow.resume2317
  call void @llvm.trap()
  unreachable

ready.overflow.resume2323:                        ; preds = %ready.overflow.resume2317
  %11093 = select i1 %11089, i32 %11090, i32 0
  %11094 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %11093
  %11095 = load <8 x i1>, ptr %11094, align 1
  %11096 = select i1 %11089, <8 x i1> %11080, <8 x i1> %11095
  store <8 x i1> %11096, ptr %11094, align 1
  %11097 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %11093
  %11098 = load i32, ptr %11097, align 4
  %11099 = select i1 %11089, i32 %convergence.dynamic.target2321, i32 %11098
  store i32 %11099, ptr %11097, align 4
  %11100 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %11093
  %11101 = load i32, ptr %11100, align 4
  %11102 = select i1 %11089, i32 %11086, i32 %11101
  store i32 %11102, ptr %11100, align 4
  %11103 = add i32 %11090, 1
  %11104 = select i1 %11089, i32 %11103, i32 %11090
  store i32 %11104, ptr %ready.count, align 4
  %11105 = load <8 x i1>, ptr %runnable.mask, align 1
  %11106 = or <8 x i1> %11105, %11080
  store <8 x i1> %11106, ptr %runnable.mask, align 1
  %11107 = load i8, ptr %frame.active, align 1
  %11108 = and i8 %11107, -128
  %11109 = icmp ne i8 %11108, 0
  %11110 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 7
  %11111 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 7
  %11112 = load <8 x i1>, ptr %11110, align 1
  %11113 = load <8 x i1>, ptr %11111, align 1
  %11114 = and <8 x i1> %11112, %10837
  %11115 = icmp eq <8 x i1> %11113, %11114
  %11116 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %11115)
  %11117 = and i1 %11109, %11116
  %.splatinsert2324 = insertelement <8 x i1> poison, i1 %11117, i64 0
  %.splat2325 = shufflevector <8 x i1> %.splatinsert2324, <8 x i1> poison, <8 x i32> zeroinitializer
  %11118 = select <8 x i1> %.splat2325, <8 x i1> %11113, <8 x i1> zeroinitializer
  %11119 = select i1 %11117, <8 x i1> zeroinitializer, <8 x i1> %11114
  store <8 x i1> %11119, ptr %11110, align 1
  %11120 = select i1 %11117, <8 x i1> zeroinitializer, <8 x i1> %11113
  store <8 x i1> %11120, ptr %11111, align 1
  %11121 = and i8 %11107, 127
  %11122 = select i1 %11117, i8 %11121, i8 %11107
  store i8 %11122, ptr %frame.active, align 1
  %11123 = load <8 x i32>, ptr %frame.parent.token, align 32
  %11124 = extractelement <8 x i32> %11123, i32 7
  %11125 = load <8 x i32>, ptr %frame.static.id, align 32
  %11126 = extractelement <8 x i32> %11125, i32 7
  %convergence.target.pointer2326 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %11126
  %convergence.dynamic.target2327 = load i32, ptr %convergence.target.pointer2326, align 4
  %11127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %11118)
  %11128 = load i32, ptr %ready.count, align 4
  %11129 = icmp uge i32 %11128, 8
  %11130 = and i1 %11127, %11129
  br i1 %11130, label %ready.overflow.trap2328, label %ready.overflow.resume2329

ready.overflow.trap2328:                          ; preds = %ready.overflow.resume2323
  call void @llvm.trap()
  unreachable

ready.overflow.resume2329:                        ; preds = %ready.overflow.resume2323
  %11131 = select i1 %11127, i32 %11128, i32 0
  %11132 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %11131
  %11133 = load <8 x i1>, ptr %11132, align 1
  %11134 = select i1 %11127, <8 x i1> %11118, <8 x i1> %11133
  store <8 x i1> %11134, ptr %11132, align 1
  %11135 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %11131
  %11136 = load i32, ptr %11135, align 4
  %11137 = select i1 %11127, i32 %convergence.dynamic.target2327, i32 %11136
  store i32 %11137, ptr %11135, align 4
  %11138 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %11131
  %11139 = load i32, ptr %11138, align 4
  %11140 = select i1 %11127, i32 %11124, i32 %11139
  store i32 %11140, ptr %11138, align 4
  %11141 = add i32 %11128, 1
  %11142 = select i1 %11127, i32 %11141, i32 %11128
  store i32 %11142, ptr %ready.count, align 4
  %11143 = load <8 x i1>, ptr %runnable.mask, align 1
  %11144 = or <8 x i1> %11143, %11118
  store <8 x i1> %11144, ptr %runnable.mask, align 1
  br label %return.frame.cleanup.done

varying.divergent2331:                            ; preds = %schedule.116
  %11145 = load i32, ptr %current.token, align 4
  %11146 = icmp ne i32 %11145, 0
  %11147 = sub i32 %11145, 1
  %11148 = select i1 %11146, i32 %11147, i32 0
  %11149 = load i8, ptr %frame.active, align 1
  %11150 = trunc i32 %11148 to i8
  %11151 = shl i8 1, %11150
  %11152 = and i8 %11149, %11151
  %11153 = icmp ne i8 %11152, 0
  %11154 = load <8 x i32>, ptr %frame.static.id, align 32
  %11155 = extractelement <8 x i32> %11154, i32 %11148
  %11156 = icmp eq i32 %11155, 40
  %11157 = and i1 %11153, %11156
  %11158 = and i1 %11146, %11157
  %11159 = xor i1 %11158, true
  %11160 = and i1 true, %11159
  %11161 = xor i8 %11149, -1
  %11162 = icmp ne i8 %11161, 0
  %11163 = xor i1 %11162, true
  %11164 = and i1 %11160, %11163
  br i1 %11164, label %convergence.overflow.trap2333, label %convergence.overflow.resume2334

varying.coherent2332:                             ; preds = %schedule.116
  br i1 %2583, label %varying.coherent.true2337, label %varying.coherent.false2338

convergence.overflow.trap2333:                    ; preds = %varying.divergent2331
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2334:                  ; preds = %varying.divergent2331
  %11165 = call i8 @llvm.cttz.i8(i8 %11161, i1 false)
  %11166 = zext i8 %11165 to i32
  %11167 = select i1 %11162, i32 %11166, i32 0
  %11168 = trunc i32 %11167 to i8
  %11169 = shl i8 1, %11168
  %11170 = or i8 %11149, %11169
  %11171 = select i1 %11160, i8 %11170, i8 %11149
  store i8 %11171, ptr %frame.active, align 1
  %11172 = load <8 x i32>, ptr %frame.static.id, align 32
  %11173 = extractelement <8 x i32> %11172, i32 %11167
  %11174 = select i1 %11160, i32 40, i32 %11173
  %11175 = load <8 x i32>, ptr %frame.static.id, align 32
  %11176 = insertelement <8 x i32> %11175, i32 %11174, i32 %11167
  store <8 x i32> %11176, ptr %frame.static.id, align 32
  %11177 = load <8 x i32>, ptr %frame.parent.token, align 32
  %11178 = extractelement <8 x i32> %11177, i32 %11167
  %11179 = select i1 %11160, i32 %11145, i32 %11178
  %11180 = load <8 x i32>, ptr %frame.parent.token, align 32
  %11181 = insertelement <8 x i32> %11180, i32 %11179, i32 %11167
  store <8 x i32> %11181, ptr %frame.parent.token, align 32
  %11182 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %11167
  %11183 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %11167
  %11184 = load <8 x i1>, ptr %11182, align 1
  %11185 = load <8 x i1>, ptr %11183, align 1
  %11186 = select i1 %11160, <8 x i1> %2573, <8 x i1> %11184
  store <8 x i1> %11186, ptr %11182, align 1
  %11187 = select i1 %11160, <8 x i1> zeroinitializer, <8 x i1> %11185
  store <8 x i1> %11187, ptr %11183, align 1
  %11188 = add i32 %11167, 1
  %11189 = select i1 %11158, i32 %11145, i32 %11188
  %11190 = select i1 true, i32 %11189, i32 %11145
  store i32 %11190, ptr %current.token, align 4
  %11191 = load i32, ptr %current.token, align 4
  %11192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2580)
  %11193 = load i32, ptr %ready.count, align 4
  %11194 = icmp uge i32 %11193, 8
  %11195 = and i1 %11192, %11194
  br i1 %11195, label %ready.overflow.trap2335, label %ready.overflow.resume2336

ready.overflow.trap2335:                          ; preds = %convergence.overflow.resume2334
  call void @llvm.trap()
  unreachable

ready.overflow.resume2336:                        ; preds = %convergence.overflow.resume2334
  %11196 = select i1 %11192, i32 %11193, i32 0
  %11197 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %11196
  %11198 = load <8 x i1>, ptr %11197, align 1
  %11199 = select i1 %11192, <8 x i1> %2580, <8 x i1> %11198
  store <8 x i1> %11199, ptr %11197, align 1
  %11200 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %11196
  %11201 = load i32, ptr %11200, align 4
  %11202 = select i1 %11192, i32 117, i32 %11201
  store i32 %11202, ptr %11200, align 4
  %11203 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %11196
  %11204 = load i32, ptr %11203, align 4
  %11205 = select i1 %11192, i32 %11191, i32 %11204
  store i32 %11205, ptr %11203, align 4
  %11206 = add i32 %11193, 1
  %11207 = select i1 %11192, i32 %11206, i32 %11193
  store i32 %11207, ptr %ready.count, align 4
  %11208 = load <8 x i1>, ptr %runnable.mask, align 1
  %11209 = or <8 x i1> %11208, %2580
  store <8 x i1> %11209, ptr %runnable.mask, align 1
  store <8 x i1> %2582, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2337:                        ; preds = %varying.coherent2332
  store <8 x i1> %2573, ptr %current.mask, align 1
  %11210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2573)
  br i1 %11210, label %schedule.117, label %scheduler.loop

varying.coherent.false2338:                       ; preds = %varying.coherent2332
  store <8 x i1> %2573, ptr %current.mask, align 1
  %11211 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2573)
  br i1 %11211, label %schedule.2, label %scheduler.loop

varying.divergent2344:                            ; preds = %schedule.117
  %11212 = load i32, ptr %current.token, align 4
  %11213 = icmp ne i32 %11212, 0
  %11214 = sub i32 %11212, 1
  %11215 = select i1 %11213, i32 %11214, i32 0
  %11216 = load i8, ptr %frame.active, align 1
  %11217 = trunc i32 %11215 to i8
  %11218 = shl i8 1, %11217
  %11219 = and i8 %11216, %11218
  %11220 = icmp ne i8 %11219, 0
  %11221 = load <8 x i32>, ptr %frame.static.id, align 32
  %11222 = extractelement <8 x i32> %11221, i32 %11215
  %11223 = icmp eq i32 %11222, 41
  %11224 = and i1 %11220, %11223
  %11225 = and i1 %11213, %11224
  %11226 = xor i1 %11225, true
  %11227 = and i1 true, %11226
  %11228 = xor i8 %11216, -1
  %11229 = icmp ne i8 %11228, 0
  %11230 = xor i1 %11229, true
  %11231 = and i1 %11227, %11230
  br i1 %11231, label %convergence.overflow.trap2346, label %convergence.overflow.resume2347

varying.coherent2345:                             ; preds = %schedule.117
  br i1 %2618, label %varying.coherent.true2350, label %varying.coherent.false2351

convergence.overflow.trap2346:                    ; preds = %varying.divergent2344
  call void @llvm.trap()
  unreachable

convergence.overflow.resume2347:                  ; preds = %varying.divergent2344
  %11232 = call i8 @llvm.cttz.i8(i8 %11228, i1 false)
  %11233 = zext i8 %11232 to i32
  %11234 = select i1 %11229, i32 %11233, i32 0
  %11235 = trunc i32 %11234 to i8
  %11236 = shl i8 1, %11235
  %11237 = or i8 %11216, %11236
  %11238 = select i1 %11227, i8 %11237, i8 %11216
  store i8 %11238, ptr %frame.active, align 1
  %11239 = load <8 x i32>, ptr %frame.static.id, align 32
  %11240 = extractelement <8 x i32> %11239, i32 %11234
  %11241 = select i1 %11227, i32 41, i32 %11240
  %11242 = load <8 x i32>, ptr %frame.static.id, align 32
  %11243 = insertelement <8 x i32> %11242, i32 %11241, i32 %11234
  store <8 x i32> %11243, ptr %frame.static.id, align 32
  %11244 = load <8 x i32>, ptr %frame.parent.token, align 32
  %11245 = extractelement <8 x i32> %11244, i32 %11234
  %11246 = select i1 %11227, i32 %11212, i32 %11245
  %11247 = load <8 x i32>, ptr %frame.parent.token, align 32
  %11248 = insertelement <8 x i32> %11247, i32 %11246, i32 %11234
  store <8 x i32> %11248, ptr %frame.parent.token, align 32
  %11249 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %11234
  %11250 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %11234
  %11251 = load <8 x i1>, ptr %11249, align 1
  %11252 = load <8 x i1>, ptr %11250, align 1
  %11253 = select i1 %11227, <8 x i1> %2586, <8 x i1> %11251
  store <8 x i1> %11253, ptr %11249, align 1
  %11254 = select i1 %11227, <8 x i1> zeroinitializer, <8 x i1> %11252
  store <8 x i1> %11254, ptr %11250, align 1
  %11255 = add i32 %11234, 1
  %11256 = select i1 %11225, i32 %11212, i32 %11255
  %11257 = select i1 true, i32 %11256, i32 %11212
  store i32 %11257, ptr %current.token, align 4
  %11258 = load <8 x float>, ptr %.slot43, align 32
  %11259 = select <8 x i1> %2617, <8 x float> zeroinitializer, <8 x float> %11258
  store <8 x float> %11259, ptr %.slot43, align 32
  %11260 = load i32, ptr %current.token, align 4
  %11261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2615)
  %11262 = load i32, ptr %ready.count, align 4
  %11263 = icmp uge i32 %11262, 8
  %11264 = and i1 %11261, %11263
  br i1 %11264, label %ready.overflow.trap2348, label %ready.overflow.resume2349

ready.overflow.trap2348:                          ; preds = %convergence.overflow.resume2347
  call void @llvm.trap()
  unreachable

ready.overflow.resume2349:                        ; preds = %convergence.overflow.resume2347
  %11265 = select i1 %11261, i32 %11262, i32 0
  %11266 = getelementptr inbounds [8 x <8 x i1>], ptr %ready.mask, i32 0, i32 %11265
  %11267 = load <8 x i1>, ptr %11266, align 1
  %11268 = select i1 %11261, <8 x i1> %2615, <8 x i1> %11267
  store <8 x i1> %11268, ptr %11266, align 1
  %11269 = getelementptr inbounds [8 x i32], ptr %ready.target, i32 0, i32 %11265
  %11270 = load i32, ptr %11269, align 4
  %11271 = select i1 %11261, i32 118, i32 %11270
  store i32 %11271, ptr %11269, align 4
  %11272 = getelementptr inbounds [8 x i32], ptr %ready.token, i32 0, i32 %11265
  %11273 = load i32, ptr %11272, align 4
  %11274 = select i1 %11261, i32 %11260, i32 %11273
  store i32 %11274, ptr %11272, align 4
  %11275 = add i32 %11262, 1
  %11276 = select i1 %11261, i32 %11275, i32 %11262
  store i32 %11276, ptr %ready.count, align 4
  %11277 = load <8 x i1>, ptr %runnable.mask, align 1
  %11278 = or <8 x i1> %11277, %2615
  store <8 x i1> %11278, ptr %runnable.mask, align 1
  store <8 x i1> %2617, ptr %current.mask, align 1
  br label %scheduler.dispatch.route

varying.coherent.true2350:                        ; preds = %varying.coherent2345
  store <8 x i1> %2586, ptr %current.mask, align 1
  %11279 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2586)
  br i1 %11279, label %schedule.118, label %scheduler.loop

varying.coherent.false2351:                       ; preds = %varying.coherent2345
  %11280 = load <8 x float>, ptr %.slot43, align 32
  %11281 = select <8 x i1> %2586, <8 x float> zeroinitializer, <8 x float> %11280
  store <8 x float> %11281, ptr %.slot43, align 32
  store <8 x i1> %2586, ptr %current.mask, align 1
  %11282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2586)
  br i1 %11282, label %schedule.119, label %scheduler.loop

convergence.cascade2353:                          ; preds = %convergence.cascade2353, %schedule.119
  %convergence.cascade.flow2357 = phi <8 x i1> [ %2634, %schedule.119 ], [ %11325, %convergence.cascade2353 ]
  %convergence.cascade.depth2358 = phi i32 [ 0, %schedule.119 ], [ %11326, %convergence.cascade2353 ]
  %11283 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.flow2357)
  %11284 = load i32, ptr %current.token, align 4
  %11285 = icmp ne i32 %11284, 0
  %11286 = and i1 %11283, %11285
  %11287 = sub i32 %11284, 1
  %11288 = select i1 %11286, i32 %11287, i32 0
  %11289 = load i8, ptr %frame.active, align 1
  %11290 = trunc i32 %11288 to i8
  %11291 = shl i8 1, %11290
  %11292 = and i8 %11289, %11291
  %11293 = icmp ne i8 %11292, 0
  %11294 = load <8 x i32>, ptr %frame.static.id, align 32
  %11295 = extractelement <8 x i32> %11294, i32 %11288
  %convergence.target.pointer2359 = getelementptr inbounds [42 x i32], ptr @convergence.targets, i32 0, i32 %11295
  %convergence.dynamic.target2360 = load i32, ptr %convergence.target.pointer2359, align 4
  %11296 = icmp eq i32 %convergence.dynamic.target2360, 119
  %11297 = and i1 %11293, %11296
  %11298 = and i1 %11286, %11297
  %11299 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.expected, i32 0, i32 %11288
  %11300 = getelementptr inbounds [8 x <8 x i1>], ptr %frame.arrived, i32 0, i32 %11288
  %11301 = load <8 x i1>, ptr %11299, align 1
  %11302 = load <8 x i1>, ptr %11300, align 1
  %11303 = or <8 x i1> %11302, %convergence.cascade.flow2357
  %11304 = load <8 x i1>, ptr %live.mask, align 1
  %11305 = and <8 x i1> %11301, %11304
  %11306 = icmp eq <8 x i1> %11303, %11305
  %11307 = call i1 @llvm.vector.reduce.and.v8i1(<8 x i1> %11306)
  %11308 = and i1 %11298, %11307
  %11309 = select i1 %11308, <8 x i1> zeroinitializer, <8 x i1> %11303
  %11310 = select i1 %11298, <8 x i1> %11309, <8 x i1> %11302
  store <8 x i1> %11310, ptr %11300, align 1
  %11311 = select i1 %11308, <8 x i1> zeroinitializer, <8 x i1> %11301
  store <8 x i1> %11311, ptr %11299, align 1
  %11312 = trunc i32 %11288 to i8
  %11313 = shl i8 1, %11312
  %11314 = xor i8 %11313, -1
  %11315 = and i8 %11289, %11314
  %11316 = select i1 %11308, i8 %11315, i8 %11289
  store i8 %11316, ptr %frame.active, align 1
  %.splatinsert2361 = insertelement <8 x i1> poison, i1 %11298, i64 0
  %.splat2362 = shufflevector <8 x i1> %.splatinsert2361, <8 x i1> poison, <8 x i32> zeroinitializer
  %11317 = and <8 x i1> %convergence.cascade.flow2357, %.splat2362
  %11318 = load <8 x i1>, ptr %runnable.mask, align 1
  %11319 = xor <8 x i1> %11317, splat (i1 true)
  %11320 = and <8 x i1> %11318, %11319
  store <8 x i1> %11320, ptr %runnable.mask, align 1
  %.splatinsert2363 = insertelement <8 x i1> poison, i1 %11308, i64 0
  %.splat2364 = shufflevector <8 x i1> %.splatinsert2363, <8 x i1> poison, <8 x i32> zeroinitializer
  %11321 = select <8 x i1> %.splat2364, <8 x i1> %11303, <8 x i1> zeroinitializer
  %11322 = load <8 x i32>, ptr %frame.parent.token, align 32
  %11323 = extractelement <8 x i32> %11322, i32 %11288
  %11324 = select i1 %11308, i32 %11323, i32 %11284
  store i32 %11324, ptr %current.token, align 4
  %.splatinsert2365 = insertelement <8 x i1> poison, i1 %11298, i64 0
  %.splat2366 = shufflevector <8 x i1> %.splatinsert2365, <8 x i1> poison, <8 x i32> zeroinitializer
  %11325 = select <8 x i1> %.splat2366, <8 x i1> %11321, <8 x i1> %convergence.cascade.flow2357
  %11326 = add i32 %convergence.cascade.depth2358, 1
  %11327 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %11325)
  %11328 = icmp ult i32 %11326, 8
  %11329 = and i1 %11327, %11328
  %11330 = and i1 %11298, %11329
  %convergence.parent.token2367 = load i32, ptr %current.token, align 4
  %convergence.parent.present2368 = icmp ne i32 %convergence.parent.token2367, 0
  %11331 = and i1 %11330, %convergence.parent.present2368
  br i1 %11331, label %convergence.cascade2353, label %convergence.cascade.exit2354

convergence.cascade.exit2354:                     ; preds = %convergence.cascade2353, %schedule.119
  %convergence.cascade.result2369 = phi <8 x i1> [ %2634, %schedule.119 ], [ %11325, %convergence.cascade2353 ]
  %11332 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2369)
  br i1 %11332, label %convergence.target.119.ready, label %scheduler.loop

convergence.target.119.ready:                     ; preds = %convergence.cascade.exit2354
  %11333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2369)
  %11334 = bitcast <8 x i1> %convergence.cascade.result2369 to i8
  %11335 = call i8 @llvm.cttz.i8(i8 %11334, i1 false)
  %11336 = zext i8 %11335 to i32
  %11337 = select i1 %11333, i32 %11336, i32 0
  %tile_snapshot.spill.load2370 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %11338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2370, 0
  %11339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load2370, 1
  %.state2371 = load <8 x i64>, ptr %.slot, align 64
  %11340 = mul <8 x i64> %.state2371, splat (i64 4)
  %11341 = add <8 x i64> %11339, %11340
  %11342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %11338, 0
  %11343 = insertvalue { <8 x ptr>, <8 x i64> } %11342, <8 x i64> %11341, 1
  %.state2372 = load <8 x float>, ptr %.slot43, align 32
  %11344 = extractvalue { <8 x ptr>, <8 x i64> } %11343, 0
  %11345 = extractvalue { <8 x ptr>, <8 x i64> } %11343, 1
  %11346 = getelementptr i8, <8 x ptr> %11344, <8 x i64> %11345
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state2372, <8 x ptr> align 1 %11346, <8 x i1> %convergence.cascade.result2369)
  %.state2373 = load <8 x i64>, ptr %.slot, align 64
  %11347 = add <8 x i64> %.state2373, splat (i64 1)
  %11348 = load <8 x i64>, ptr %.slot, align 64
  %11349 = select <8 x i1> %convergence.cascade.result2369, <8 x i64> %11347, <8 x i64> %11348
  store <8 x i64> %11349, ptr %.slot, align 64
  store <8 x i1> %convergence.cascade.result2369, ptr %current.mask, align 1
  %11350 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %convergence.cascade.result2369)
  br i1 %11350, label %schedule.116, label %scheduler.loop
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy(ptr %0, i64 %1, ptr %2) #2 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 40
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.and.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #3

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.1(ptr %0, i64 %1, ptr %2) #2 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 160
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.2(ptr %0, i64 %1, ptr %2) #2 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 192
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #4

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #5

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #6 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

define dso_local void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #2 = { nounwind willreturn }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #5 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

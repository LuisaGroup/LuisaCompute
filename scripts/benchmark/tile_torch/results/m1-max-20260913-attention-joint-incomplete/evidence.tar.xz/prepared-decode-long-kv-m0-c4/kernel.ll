; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 4096
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 8192
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 12288
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 77824
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 143360
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 143872
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 144384
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill31 = alloca i64, align 8
  store i64 0, ptr %.spill31, align 4
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %tile_snapshot.spill33 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill33, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.spill39 = alloca i1, align 1
  store i1 false, ptr %.spill39, align 1
  %tile_snapshot.spill40 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill40, align 64
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca i64, align 8
  store i64 0, ptr %.slot51, align 4
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot54, align 32
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.spill61 = alloca i1, align 1
  store i1 false, ptr %.spill61, align 1
  %.spill62 = alloca i1, align 1
  store i1 false, ptr %.spill62, align 1
  %.spill63 = alloca i1, align 1
  store i1 false, ptr %.spill63, align 1
  %.spill64 = alloca i1, align 1
  store i1 false, ptr %.spill64, align 1
  %.spill65 = alloca i1, align 1
  store i1 false, ptr %.spill65, align 1
  %.spill66 = alloca i1, align 1
  store i1 false, ptr %.spill66, align 1
  %.spill67 = alloca i1, align 1
  store i1 false, ptr %.spill67, align 1
  %.spill68 = alloca i1, align 1
  store i1 false, ptr %.spill68, align 1
  %.spill69 = alloca i1, align 1
  store i1 false, ptr %.spill69, align 1
  %.spill70 = alloca i1, align 1
  store i1 false, ptr %.spill70, align 1
  %.spill71 = alloca i1, align 1
  store i1 false, ptr %.spill71, align 1
  %.spill72 = alloca i1, align 1
  store i1 false, ptr %.spill72, align 1
  %.spill73 = alloca i1, align 1
  store i1 false, ptr %.spill73, align 1
  %.spill74 = alloca i1, align 1
  store i1 false, ptr %.spill74, align 1
  %.spill75 = alloca i1, align 1
  store i1 false, ptr %.spill75, align 1
  %.spill76 = alloca i1, align 1
  store i1 false, ptr %.spill76, align 1
  %.spill77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill77, align 32
  %.spill78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill78, align 32
  %.spill79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill79, align 32
  %.spill80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill80, align 32
  %.spill81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill81, align 32
  %.spill82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill82, align 32
  %.spill83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill83, align 32
  %.spill84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill84, align 32
  %.spill85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill85, align 32
  %.spill86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill86, align 32
  %.spill87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill87, align 32
  %.spill88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill88, align 32
  %.spill89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill89, align 32
  %.spill90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill90, align 32
  %.spill91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill91, align 32
  %.spill92 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill92, align 32
  %tile_snapshot.spill93 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill93, align 64
  %.slot94 = alloca i64, align 8
  store i64 0, ptr %.slot94, align 4
  %.slot95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %tile_snapshot.spill98 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill98, align 64
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.slot100 = alloca i64, align 8
  store i64 0, ptr %.slot100, align 4
  %.slot101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %tile_snapshot.spill103 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill103, align 64
  %.slot104 = alloca i64, align 8
  store i64 0, ptr %.slot104, align 4
  %.spill105 = alloca i64, align 8
  store i64 0, ptr %.spill105, align 4
  %.spill106 = alloca i64, align 8
  store i64 0, ptr %.spill106, align 4
  %.spill107 = alloca i64, align 8
  store i64 0, ptr %.spill107, align 4
  %.spill108 = alloca i64, align 8
  store i64 0, ptr %.spill108, align 4
  %.slot109 = alloca i64, align 8
  store i64 0, ptr %.slot109, align 4
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %.slot111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot111, align 32
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.slot114 = alloca i64, align 8
  store i64 0, ptr %.slot114, align 4
  %.slot115 = alloca i64, align 8
  store i64 0, ptr %.slot115, align 4
  %.slot116 = alloca i64, align 8
  store i64 0, ptr %.slot116, align 4
  %.spill117 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill117, align 64
  %.slot118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot118, align 32
  %.slot119 = alloca i64, align 8
  store i64 0, ptr %.slot119, align 4
  %.spill120 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill120, align 64
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert123 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat124 = shufflevector <8 x i32> %.splatinsert123, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat124, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert125 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat126 = shufflevector <8 x i32> %.splatinsert125, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat126, %61
  %64 = mul i32 %52, 1
  %.splatinsert127 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat128 = shufflevector <8 x i32> %.splatinsert127, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat128, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert129 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat130 = shufflevector <8 x i32> %.splatinsert129, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat130, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert131 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat132 = shufflevector <8 x i32> %.splatinsert131, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat132
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.spill31, align 4
  %94 = add <8 x i64> zeroinitializer, %77
  %95 = mul <8 x i64> %94, splat (i64 1)
  %96 = add <8 x i64> %95, zeroinitializer
  %97 = mul <8 x i64> %96, splat (i64 128)
  %98 = add <8 x i64> %97, zeroinitializer
  %99 = extractvalue { ptr, i64 } %29, 0
  %100 = extractelement <8 x i1> %71, i64 0
  br i1 %100, label %copy.active, label %copy.continue

direct.schedule.1:                                ; preds = %direct.schedule.2, %copy.continue146
  %.state = load i64, ptr %.slot, align 4
  %101 = icmp slt i64 %.state, 128
  br i1 %101, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state147 = load i64, ptr %.slot, align 4
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %.state147, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = mul <8 x i64> %.splat149, splat (i64 32)
  %105 = add <8 x i64> %103, %104
  %106 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %107 = insertvalue { <8 x ptr>, <8 x i64> } %106, <8 x i64> %105, 1
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %107, 1
  %110 = extractelement <8 x ptr> %108, i32 0
  %111 = extractelement <8 x i64> %109, i32 0
  %112 = sub i64 %111, 0
  %113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %114 = select i1 %113, i64 %112, i64 0
  %private.contiguous.address = getelementptr i8, ptr %110, i64 %114
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %115 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %115, ptr %private.contiguous.address, align 4
  %.state150 = load i64, ptr %.slot, align 4
  %116 = add i64 %.state150, 1
  store i64 %116, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store i64 0, ptr %.slot34, align 4
  %117 = load <8 x float>, ptr %.slot35, align 32
  %118 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %117
  store <8 x float> %118, ptr %.slot35, align 32
  %119 = load <8 x float>, ptr %.slot36, align 32
  %120 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %119
  store <8 x float> %120, ptr %.slot36, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.39, %direct.schedule.3
  %.state151 = load i64, ptr %.slot34, align 4
  %121 = icmp slt i64 %.state151, 513
  br i1 %121, label %direct.true152, label %direct.false153

direct.schedule.5:                                ; preds = %direct.true152
  %.state154 = load i64, ptr %.slot34, align 4
  %122 = sdiv i64 %.state154, 1
  %123 = mul i64 %122, 16
  store i64 %123, ptr %.spill37, align 4
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill38, align 64
  %133 = icmp sge i64 %123, 0
  %134 = and i1 true, %133
  %135 = icmp sle i64 %123, 8177
  %136 = and i1 %134, %135
  store i1 %136, ptr %.spill39, align 1
  br i1 %136, label %direct.true155, label %direct.false156

direct.schedule.6:                                ; preds = %direct.true155
  %.spill.load = load i64, ptr %.spill31, align 4
  %137 = mul i64 %.spill.load, 4
  %.splatinsert157 = insertelement <8 x i64> poison, i64 %137, i64 0
  %.splat158 = shufflevector <8 x i64> %.splatinsert157, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load159 = load <8 x i64>, ptr %.spill30, align 64
  %138 = add <8 x i64> %.splat158, %.spill.load159
  %139 = mul <8 x i64> %138, splat (i64 8193)
  %.spill.load160 = load i64, ptr %.spill37, align 4
  %.splatinsert161 = insertelement <8 x i64> poison, i64 %.spill.load160, i64 0
  %.splat162 = shufflevector <8 x i64> %.splatinsert161, <8 x i64> poison, <8 x i32> zeroinitializer
  %140 = add <8 x i64> %139, %.splat162
  %141 = mul <8 x i64> %140, splat (i64 128)
  %142 = add <8 x i64> %141, zeroinitializer
  %tile_snapshot.spill.load163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %143 = extractvalue { ptr, i64 } %35, 0
  %144 = extractelement <8 x i1> %71, i64 0
  br i1 %144, label %copy.active164, label %copy.continue165

direct.schedule.7:                                ; preds = %direct.false703, %copy.continue179
  %145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 0
  %148 = select <8 x i1> %71, <8 x ptr> %146, <8 x ptr> %147
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %151 = select <8 x i1> %71, <8 x i64> %149, <8 x i64> %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  store { <8 x ptr>, <8 x i64> } %153, ptr %tile_snapshot.spill40, align 64
  %.spill.load180 = load i1, ptr %.spill39, align 1
  br i1 %.spill.load180, label %direct.true181, label %direct.false182

direct.schedule.8:                                ; preds = %direct.true181
  %.spill.load183 = load i64, ptr %.spill31, align 4
  %154 = mul i64 %.spill.load183, 4
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %154, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load186 = load <8 x i64>, ptr %.spill30, align 64
  %155 = add <8 x i64> %.splat185, %.spill.load186
  %156 = mul <8 x i64> %155, splat (i64 8193)
  %.spill.load187 = load i64, ptr %.spill37, align 4
  %.splatinsert188 = insertelement <8 x i64> poison, i64 %.spill.load187, i64 0
  %.splat189 = shufflevector <8 x i64> %.splatinsert188, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = add <8 x i64> %156, %.splat189
  %158 = mul <8 x i64> %157, splat (i64 128)
  %159 = add <8 x i64> %158, zeroinitializer
  %tile_snapshot.spill.load190 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %160 = extractvalue { ptr, i64 } %41, 0
  %161 = extractelement <8 x i1> %71, i64 0
  br i1 %161, label %copy.active191, label %copy.continue192

direct.schedule.9:                                ; preds = %direct.false680, %copy.continue206
  store i64 0, ptr %.slot41, align 4
  %162 = load <8 x float>, ptr %.slot42, align 32
  %163 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %162
  store <8 x float> %163, ptr %.slot42, align 32
  %164 = load <8 x float>, ptr %.slot43, align 32
  %165 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %164
  store <8 x float> %165, ptr %.slot43, align 32
  %166 = load <8 x float>, ptr %.slot44, align 32
  %167 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %166
  store <8 x float> %167, ptr %.slot44, align 32
  %168 = load <8 x float>, ptr %.slot45, align 32
  %169 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %168
  store <8 x float> %169, ptr %.slot45, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state207 = load i64, ptr %.slot41, align 4
  %170 = icmp slt i64 %.state207, 128
  br i1 %170, label %direct.true208, label %direct.false209

direct.schedule.11:                               ; preds = %direct.true208
  %.state210 = load i64, ptr %.slot41, align 4
  %171 = add i64 0, %.state210
  %tile_snapshot.spill.load211 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 1
  %.splatinsert212 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat213 = shufflevector <8 x i64> %.splatinsert212, <8 x i64> poison, <8 x i32> zeroinitializer
  %174 = mul <8 x i64> %.splat213, splat (i64 4)
  %175 = add <8 x i64> %173, %174
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %172, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %177, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = getelementptr i8, <8 x ptr> %178, <8 x i64> %179
  %181 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %180, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 1
  %.splatinsert215 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat216 = shufflevector <8 x i64> %.splatinsert215, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = mul <8 x i64> %.splat216, splat (i64 4)
  %185 = add <8 x i64> %183, %184
  %186 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %182, 0
  %187 = insertvalue { <8 x ptr>, <8 x i64> } %186, <8 x i64> %185, 1
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %187, 0
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %187, 1
  %190 = getelementptr i8, <8 x ptr> %188, <8 x i64> %189
  %191 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %190, <8 x i1> %71, <8 x float> zeroinitializer)
  %192 = fmul <8 x float> %181, %191
  %.state217 = load <8 x float>, ptr %.slot42, align 32
  %193 = fadd <8 x float> %.state217, %192
  %.state218 = load i64, ptr %.slot41, align 4
  %194 = add i64 128, %.state218
  %tile_snapshot.spill.load219 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 1
  %.splatinsert220 = insertelement <8 x i64> poison, i64 %194, i64 0
  %.splat221 = shufflevector <8 x i64> %.splatinsert220, <8 x i64> poison, <8 x i32> zeroinitializer
  %197 = mul <8 x i64> %.splat221, splat (i64 4)
  %198 = add <8 x i64> %196, %197
  %199 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %195, 0
  %200 = insertvalue { <8 x ptr>, <8 x i64> } %199, <8 x i64> %198, 1
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %200, 0
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %200, 1
  %203 = getelementptr i8, <8 x ptr> %201, <8 x i64> %202
  %204 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %203, <8 x i1> %71, <8 x float> zeroinitializer)
  %205 = fmul <8 x float> %181, %204
  %.state222 = load <8 x float>, ptr %.slot43, align 32
  %206 = fadd <8 x float> %.state222, %205
  %.state223 = load i64, ptr %.slot41, align 4
  %207 = add i64 256, %.state223
  %tile_snapshot.spill.load224 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 1
  %.splatinsert225 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat226 = shufflevector <8 x i64> %.splatinsert225, <8 x i64> poison, <8 x i32> zeroinitializer
  %210 = mul <8 x i64> %.splat226, splat (i64 4)
  %211 = add <8 x i64> %209, %210
  %212 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %208, 0
  %213 = insertvalue { <8 x ptr>, <8 x i64> } %212, <8 x i64> %211, 1
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %213, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %213, 1
  %216 = getelementptr i8, <8 x ptr> %214, <8 x i64> %215
  %217 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %216, <8 x i1> %71, <8 x float> zeroinitializer)
  %218 = fmul <8 x float> %181, %217
  %.state227 = load <8 x float>, ptr %.slot44, align 32
  %219 = fadd <8 x float> %.state227, %218
  %.state228 = load i64, ptr %.slot41, align 4
  %220 = add i64 384, %.state228
  %tile_snapshot.spill.load229 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 0
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 1
  %.splatinsert230 = insertelement <8 x i64> poison, i64 %220, i64 0
  %.splat231 = shufflevector <8 x i64> %.splatinsert230, <8 x i64> poison, <8 x i32> zeroinitializer
  %223 = mul <8 x i64> %.splat231, splat (i64 4)
  %224 = add <8 x i64> %222, %223
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %221, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %226, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = getelementptr i8, <8 x ptr> %227, <8 x i64> %228
  %230 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %229, <8 x i1> %71, <8 x float> zeroinitializer)
  %231 = fmul <8 x float> %181, %230
  %.state232 = load <8 x float>, ptr %.slot45, align 32
  %232 = fadd <8 x float> %.state232, %231
  %.state233 = load i64, ptr %.slot41, align 4
  %233 = add i64 %.state233, 1
  store i64 %233, ptr %.slot41, align 4
  %234 = load <8 x float>, ptr %.slot42, align 32
  %235 = select <8 x i1> %71, <8 x float> %193, <8 x float> %234
  store <8 x float> %235, ptr %.slot42, align 32
  %236 = load <8 x float>, ptr %.slot43, align 32
  %237 = select <8 x i1> %71, <8 x float> %206, <8 x float> %236
  store <8 x float> %237, ptr %.slot43, align 32
  %238 = load <8 x float>, ptr %.slot44, align 32
  %239 = select <8 x i1> %71, <8 x float> %219, <8 x float> %238
  store <8 x float> %239, ptr %.slot44, align 32
  %240 = load <8 x float>, ptr %.slot45, align 32
  %241 = select <8 x i1> %71, <8 x float> %232, <8 x float> %240
  store <8 x float> %241, ptr %.slot45, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false209
  store i64 0, ptr %.slot46, align 4
  %242 = load <8 x float>, ptr %.slot47, align 32
  %243 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %242
  store <8 x float> %243, ptr %.slot47, align 32
  %244 = load <8 x float>, ptr %.slot48, align 32
  %245 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %244
  store <8 x float> %245, ptr %.slot48, align 32
  %246 = load <8 x float>, ptr %.slot49, align 32
  %247 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %246
  store <8 x float> %247, ptr %.slot49, align 32
  %248 = load <8 x float>, ptr %.slot50, align 32
  %249 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %248
  store <8 x float> %249, ptr %.slot50, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state234 = load i64, ptr %.slot46, align 4
  %250 = icmp slt i64 %.state234, 128
  br i1 %250, label %direct.true235, label %direct.false236

direct.schedule.14:                               ; preds = %direct.true235
  %.state237 = load i64, ptr %.slot46, align 4
  %251 = add i64 0, %.state237
  %tile_snapshot.spill.load238 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load238, 0
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load238, 1
  %.splatinsert239 = insertelement <8 x i64> poison, i64 %251, i64 0
  %.splat240 = shufflevector <8 x i64> %.splatinsert239, <8 x i64> poison, <8 x i32> zeroinitializer
  %254 = mul <8 x i64> %.splat240, splat (i64 4)
  %255 = add <8 x i64> %253, %254
  %256 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %252, 0
  %257 = insertvalue { <8 x ptr>, <8 x i64> } %256, <8 x i64> %255, 1
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %257, 0
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %257, 1
  %260 = getelementptr i8, <8 x ptr> %258, <8 x i64> %259
  %261 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %260, <8 x i1> %71, <8 x float> zeroinitializer)
  %.state241 = load i64, ptr %.slot46, align 4
  %262 = add i64 512, %.state241
  %tile_snapshot.spill.load242 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 0
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 1
  %.splatinsert243 = insertelement <8 x i64> poison, i64 %262, i64 0
  %.splat244 = shufflevector <8 x i64> %.splatinsert243, <8 x i64> poison, <8 x i32> zeroinitializer
  %265 = mul <8 x i64> %.splat244, splat (i64 4)
  %266 = add <8 x i64> %264, %265
  %267 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %263, 0
  %268 = insertvalue { <8 x ptr>, <8 x i64> } %267, <8 x i64> %266, 1
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %268, 0
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %268, 1
  %271 = getelementptr i8, <8 x ptr> %269, <8 x i64> %270
  %272 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %271, <8 x i1> %71, <8 x float> zeroinitializer)
  %273 = fmul <8 x float> %261, %272
  %.state245 = load <8 x float>, ptr %.slot47, align 32
  %274 = fadd <8 x float> %.state245, %273
  %.state246 = load i64, ptr %.slot46, align 4
  %275 = add i64 640, %.state246
  %tile_snapshot.spill.load247 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 1
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %275, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %278 = mul <8 x i64> %.splat249, splat (i64 4)
  %279 = add <8 x i64> %277, %278
  %280 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %276, 0
  %281 = insertvalue { <8 x ptr>, <8 x i64> } %280, <8 x i64> %279, 1
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %281, 0
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %281, 1
  %284 = getelementptr i8, <8 x ptr> %282, <8 x i64> %283
  %285 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %284, <8 x i1> %71, <8 x float> zeroinitializer)
  %286 = fmul <8 x float> %261, %285
  %.state250 = load <8 x float>, ptr %.slot48, align 32
  %287 = fadd <8 x float> %.state250, %286
  %.state251 = load i64, ptr %.slot46, align 4
  %288 = add i64 768, %.state251
  %tile_snapshot.spill.load252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 1
  %.splatinsert253 = insertelement <8 x i64> poison, i64 %288, i64 0
  %.splat254 = shufflevector <8 x i64> %.splatinsert253, <8 x i64> poison, <8 x i32> zeroinitializer
  %291 = mul <8 x i64> %.splat254, splat (i64 4)
  %292 = add <8 x i64> %290, %291
  %293 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %289, 0
  %294 = insertvalue { <8 x ptr>, <8 x i64> } %293, <8 x i64> %292, 1
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %294, 0
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %294, 1
  %297 = getelementptr i8, <8 x ptr> %295, <8 x i64> %296
  %298 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %297, <8 x i1> %71, <8 x float> zeroinitializer)
  %299 = fmul <8 x float> %261, %298
  %.state255 = load <8 x float>, ptr %.slot49, align 32
  %300 = fadd <8 x float> %.state255, %299
  %.state256 = load i64, ptr %.slot46, align 4
  %301 = add i64 896, %.state256
  %tile_snapshot.spill.load257 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 0
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 1
  %.splatinsert258 = insertelement <8 x i64> poison, i64 %301, i64 0
  %.splat259 = shufflevector <8 x i64> %.splatinsert258, <8 x i64> poison, <8 x i32> zeroinitializer
  %304 = mul <8 x i64> %.splat259, splat (i64 4)
  %305 = add <8 x i64> %303, %304
  %306 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %302, 0
  %307 = insertvalue { <8 x ptr>, <8 x i64> } %306, <8 x i64> %305, 1
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %307, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %307, 1
  %310 = getelementptr i8, <8 x ptr> %308, <8 x i64> %309
  %311 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %310, <8 x i1> %71, <8 x float> zeroinitializer)
  %312 = fmul <8 x float> %261, %311
  %.state260 = load <8 x float>, ptr %.slot50, align 32
  %313 = fadd <8 x float> %.state260, %312
  %.state261 = load i64, ptr %.slot46, align 4
  %314 = add i64 %.state261, 1
  store i64 %314, ptr %.slot46, align 4
  %315 = load <8 x float>, ptr %.slot47, align 32
  %316 = select <8 x i1> %71, <8 x float> %274, <8 x float> %315
  store <8 x float> %316, ptr %.slot47, align 32
  %317 = load <8 x float>, ptr %.slot48, align 32
  %318 = select <8 x i1> %71, <8 x float> %287, <8 x float> %317
  store <8 x float> %318, ptr %.slot48, align 32
  %319 = load <8 x float>, ptr %.slot49, align 32
  %320 = select <8 x i1> %71, <8 x float> %300, <8 x float> %319
  store <8 x float> %320, ptr %.slot49, align 32
  %321 = load <8 x float>, ptr %.slot50, align 32
  %322 = select <8 x i1> %71, <8 x float> %313, <8 x float> %321
  store <8 x float> %322, ptr %.slot50, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false236
  store i64 0, ptr %.slot51, align 4
  %323 = load <8 x float>, ptr %.slot52, align 32
  %324 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %323
  store <8 x float> %324, ptr %.slot52, align 32
  %325 = load <8 x float>, ptr %.slot53, align 32
  %326 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %325
  store <8 x float> %326, ptr %.slot53, align 32
  %327 = load <8 x float>, ptr %.slot54, align 32
  %328 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %327
  store <8 x float> %328, ptr %.slot54, align 32
  %329 = load <8 x float>, ptr %.slot55, align 32
  %330 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %329
  store <8 x float> %330, ptr %.slot55, align 32
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state262 = load i64, ptr %.slot51, align 4
  %331 = icmp slt i64 %.state262, 128
  br i1 %331, label %direct.true263, label %direct.false264

direct.schedule.17:                               ; preds = %direct.true263
  %.state265 = load i64, ptr %.slot51, align 4
  %332 = add i64 0, %.state265
  %tile_snapshot.spill.load266 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 0
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 1
  %.splatinsert267 = insertelement <8 x i64> poison, i64 %332, i64 0
  %.splat268 = shufflevector <8 x i64> %.splatinsert267, <8 x i64> poison, <8 x i32> zeroinitializer
  %335 = mul <8 x i64> %.splat268, splat (i64 4)
  %336 = add <8 x i64> %334, %335
  %337 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %333, 0
  %338 = insertvalue { <8 x ptr>, <8 x i64> } %337, <8 x i64> %336, 1
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %338, 0
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %338, 1
  %341 = getelementptr i8, <8 x ptr> %339, <8 x i64> %340
  %342 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %341, <8 x i1> %71, <8 x float> zeroinitializer)
  %.state269 = load i64, ptr %.slot51, align 4
  %343 = add i64 1024, %.state269
  %tile_snapshot.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %.splatinsert271 = insertelement <8 x i64> poison, i64 %343, i64 0
  %.splat272 = shufflevector <8 x i64> %.splatinsert271, <8 x i64> poison, <8 x i32> zeroinitializer
  %346 = mul <8 x i64> %.splat272, splat (i64 4)
  %347 = add <8 x i64> %345, %346
  %348 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %344, 0
  %349 = insertvalue { <8 x ptr>, <8 x i64> } %348, <8 x i64> %347, 1
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %349, 0
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %349, 1
  %352 = getelementptr i8, <8 x ptr> %350, <8 x i64> %351
  %353 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %352, <8 x i1> %71, <8 x float> zeroinitializer)
  %354 = fmul <8 x float> %342, %353
  %.state273 = load <8 x float>, ptr %.slot52, align 32
  %355 = fadd <8 x float> %.state273, %354
  %.state274 = load i64, ptr %.slot51, align 4
  %356 = add i64 1152, %.state274
  %tile_snapshot.spill.load275 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load275, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load275, 1
  %.splatinsert276 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat277 = shufflevector <8 x i64> %.splatinsert276, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat277, splat (i64 4)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %362, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = getelementptr i8, <8 x ptr> %363, <8 x i64> %364
  %366 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %365, <8 x i1> %71, <8 x float> zeroinitializer)
  %367 = fmul <8 x float> %342, %366
  %.state278 = load <8 x float>, ptr %.slot53, align 32
  %368 = fadd <8 x float> %.state278, %367
  %.state279 = load i64, ptr %.slot51, align 4
  %369 = add i64 1280, %.state279
  %tile_snapshot.spill.load280 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %.splatinsert281 = insertelement <8 x i64> poison, i64 %369, i64 0
  %.splat282 = shufflevector <8 x i64> %.splatinsert281, <8 x i64> poison, <8 x i32> zeroinitializer
  %372 = mul <8 x i64> %.splat282, splat (i64 4)
  %373 = add <8 x i64> %371, %372
  %374 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %370, 0
  %375 = insertvalue { <8 x ptr>, <8 x i64> } %374, <8 x i64> %373, 1
  %376 = extractvalue { <8 x ptr>, <8 x i64> } %375, 0
  %377 = extractvalue { <8 x ptr>, <8 x i64> } %375, 1
  %378 = getelementptr i8, <8 x ptr> %376, <8 x i64> %377
  %379 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %378, <8 x i1> %71, <8 x float> zeroinitializer)
  %380 = fmul <8 x float> %342, %379
  %.state283 = load <8 x float>, ptr %.slot54, align 32
  %381 = fadd <8 x float> %.state283, %380
  %.state284 = load i64, ptr %.slot51, align 4
  %382 = add i64 1408, %.state284
  %tile_snapshot.spill.load285 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 0
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 1
  %.splatinsert286 = insertelement <8 x i64> poison, i64 %382, i64 0
  %.splat287 = shufflevector <8 x i64> %.splatinsert286, <8 x i64> poison, <8 x i32> zeroinitializer
  %385 = mul <8 x i64> %.splat287, splat (i64 4)
  %386 = add <8 x i64> %384, %385
  %387 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %383, 0
  %388 = insertvalue { <8 x ptr>, <8 x i64> } %387, <8 x i64> %386, 1
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %388, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %388, 1
  %391 = getelementptr i8, <8 x ptr> %389, <8 x i64> %390
  %392 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %391, <8 x i1> %71, <8 x float> zeroinitializer)
  %393 = fmul <8 x float> %342, %392
  %.state288 = load <8 x float>, ptr %.slot55, align 32
  %394 = fadd <8 x float> %.state288, %393
  %.state289 = load i64, ptr %.slot51, align 4
  %395 = add i64 %.state289, 1
  store i64 %395, ptr %.slot51, align 4
  %396 = load <8 x float>, ptr %.slot52, align 32
  %397 = select <8 x i1> %71, <8 x float> %355, <8 x float> %396
  store <8 x float> %397, ptr %.slot52, align 32
  %398 = load <8 x float>, ptr %.slot53, align 32
  %399 = select <8 x i1> %71, <8 x float> %368, <8 x float> %398
  store <8 x float> %399, ptr %.slot53, align 32
  %400 = load <8 x float>, ptr %.slot54, align 32
  %401 = select <8 x i1> %71, <8 x float> %381, <8 x float> %400
  store <8 x float> %401, ptr %.slot54, align 32
  %402 = load <8 x float>, ptr %.slot55, align 32
  %403 = select <8 x i1> %71, <8 x float> %394, <8 x float> %402
  store <8 x float> %403, ptr %.slot55, align 32
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false264
  store i64 0, ptr %.slot56, align 4
  %404 = load <8 x float>, ptr %.slot57, align 32
  %405 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %404
  store <8 x float> %405, ptr %.slot57, align 32
  %406 = load <8 x float>, ptr %.slot58, align 32
  %407 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %406
  store <8 x float> %407, ptr %.slot58, align 32
  %408 = load <8 x float>, ptr %.slot59, align 32
  %409 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %408
  store <8 x float> %409, ptr %.slot59, align 32
  %410 = load <8 x float>, ptr %.slot60, align 32
  %411 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %410
  store <8 x float> %411, ptr %.slot60, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state290 = load i64, ptr %.slot56, align 4
  %412 = icmp slt i64 %.state290, 128
  br i1 %412, label %direct.true291, label %direct.false292

direct.schedule.20:                               ; preds = %direct.true291
  %.state293 = load i64, ptr %.slot56, align 4
  %413 = add i64 0, %.state293
  %tile_snapshot.spill.load294 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 0
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 1
  %.splatinsert295 = insertelement <8 x i64> poison, i64 %413, i64 0
  %.splat296 = shufflevector <8 x i64> %.splatinsert295, <8 x i64> poison, <8 x i32> zeroinitializer
  %416 = mul <8 x i64> %.splat296, splat (i64 4)
  %417 = add <8 x i64> %415, %416
  %418 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %414, 0
  %419 = insertvalue { <8 x ptr>, <8 x i64> } %418, <8 x i64> %417, 1
  %420 = extractvalue { <8 x ptr>, <8 x i64> } %419, 0
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %419, 1
  %422 = getelementptr i8, <8 x ptr> %420, <8 x i64> %421
  %423 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %422, <8 x i1> %71, <8 x float> zeroinitializer)
  %.state297 = load i64, ptr %.slot56, align 4
  %424 = add i64 1536, %.state297
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %.splatinsert299 = insertelement <8 x i64> poison, i64 %424, i64 0
  %.splat300 = shufflevector <8 x i64> %.splatinsert299, <8 x i64> poison, <8 x i32> zeroinitializer
  %427 = mul <8 x i64> %.splat300, splat (i64 4)
  %428 = add <8 x i64> %426, %427
  %429 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %425, 0
  %430 = insertvalue { <8 x ptr>, <8 x i64> } %429, <8 x i64> %428, 1
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %430, 0
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %430, 1
  %433 = getelementptr i8, <8 x ptr> %431, <8 x i64> %432
  %434 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %433, <8 x i1> %71, <8 x float> zeroinitializer)
  %435 = fmul <8 x float> %423, %434
  %.state301 = load <8 x float>, ptr %.slot57, align 32
  %436 = fadd <8 x float> %.state301, %435
  %.state302 = load i64, ptr %.slot56, align 4
  %437 = add i64 1664, %.state302
  %tile_snapshot.spill.load303 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load303, 0
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load303, 1
  %.splatinsert304 = insertelement <8 x i64> poison, i64 %437, i64 0
  %.splat305 = shufflevector <8 x i64> %.splatinsert304, <8 x i64> poison, <8 x i32> zeroinitializer
  %440 = mul <8 x i64> %.splat305, splat (i64 4)
  %441 = add <8 x i64> %439, %440
  %442 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %438, 0
  %443 = insertvalue { <8 x ptr>, <8 x i64> } %442, <8 x i64> %441, 1
  %444 = extractvalue { <8 x ptr>, <8 x i64> } %443, 0
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %443, 1
  %446 = getelementptr i8, <8 x ptr> %444, <8 x i64> %445
  %447 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %446, <8 x i1> %71, <8 x float> zeroinitializer)
  %448 = fmul <8 x float> %423, %447
  %.state306 = load <8 x float>, ptr %.slot58, align 32
  %449 = fadd <8 x float> %.state306, %448
  %.state307 = load i64, ptr %.slot56, align 4
  %450 = add i64 1792, %.state307
  %tile_snapshot.spill.load308 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 0
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 1
  %.splatinsert309 = insertelement <8 x i64> poison, i64 %450, i64 0
  %.splat310 = shufflevector <8 x i64> %.splatinsert309, <8 x i64> poison, <8 x i32> zeroinitializer
  %453 = mul <8 x i64> %.splat310, splat (i64 4)
  %454 = add <8 x i64> %452, %453
  %455 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %451, 0
  %456 = insertvalue { <8 x ptr>, <8 x i64> } %455, <8 x i64> %454, 1
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %456, 0
  %458 = extractvalue { <8 x ptr>, <8 x i64> } %456, 1
  %459 = getelementptr i8, <8 x ptr> %457, <8 x i64> %458
  %460 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %459, <8 x i1> %71, <8 x float> zeroinitializer)
  %461 = fmul <8 x float> %423, %460
  %.state311 = load <8 x float>, ptr %.slot59, align 32
  %462 = fadd <8 x float> %.state311, %461
  %.state312 = load i64, ptr %.slot56, align 4
  %463 = add i64 1920, %.state312
  %tile_snapshot.spill.load313 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load313, 0
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load313, 1
  %.splatinsert314 = insertelement <8 x i64> poison, i64 %463, i64 0
  %.splat315 = shufflevector <8 x i64> %.splatinsert314, <8 x i64> poison, <8 x i32> zeroinitializer
  %466 = mul <8 x i64> %.splat315, splat (i64 4)
  %467 = add <8 x i64> %465, %466
  %468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %464, 0
  %469 = insertvalue { <8 x ptr>, <8 x i64> } %468, <8 x i64> %467, 1
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %469, 0
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %469, 1
  %472 = getelementptr i8, <8 x ptr> %470, <8 x i64> %471
  %473 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %472, <8 x i1> %71, <8 x float> zeroinitializer)
  %474 = fmul <8 x float> %423, %473
  %.state316 = load <8 x float>, ptr %.slot60, align 32
  %475 = fadd <8 x float> %.state316, %474
  %.state317 = load i64, ptr %.slot56, align 4
  %476 = add i64 %.state317, 1
  store i64 %476, ptr %.slot56, align 4
  %477 = load <8 x float>, ptr %.slot57, align 32
  %478 = select <8 x i1> %71, <8 x float> %436, <8 x float> %477
  store <8 x float> %478, ptr %.slot57, align 32
  %479 = load <8 x float>, ptr %.slot58, align 32
  %480 = select <8 x i1> %71, <8 x float> %449, <8 x float> %479
  store <8 x float> %480, ptr %.slot58, align 32
  %481 = load <8 x float>, ptr %.slot59, align 32
  %482 = select <8 x i1> %71, <8 x float> %462, <8 x float> %481
  store <8 x float> %482, ptr %.slot59, align 32
  %483 = load <8 x float>, ptr %.slot60, align 32
  %484 = select <8 x i1> %71, <8 x float> %475, <8 x float> %483
  store <8 x float> %484, ptr %.slot60, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false292
  %.state318 = load <8 x float>, ptr %.slot42, align 32
  %485 = fmul <8 x float> %.state318, splat (float 0x3FB6A09E60000000)
  %.state319 = load <8 x float>, ptr %.slot43, align 32
  %486 = fmul <8 x float> %.state319, splat (float 0x3FB6A09E60000000)
  %.state320 = load <8 x float>, ptr %.slot44, align 32
  %487 = fmul <8 x float> %.state320, splat (float 0x3FB6A09E60000000)
  %.state321 = load <8 x float>, ptr %.slot45, align 32
  %488 = fmul <8 x float> %.state321, splat (float 0x3FB6A09E60000000)
  %.state322 = load <8 x float>, ptr %.slot47, align 32
  %489 = fmul <8 x float> %.state322, splat (float 0x3FB6A09E60000000)
  %.state323 = load <8 x float>, ptr %.slot48, align 32
  %490 = fmul <8 x float> %.state323, splat (float 0x3FB6A09E60000000)
  %.state324 = load <8 x float>, ptr %.slot49, align 32
  %491 = fmul <8 x float> %.state324, splat (float 0x3FB6A09E60000000)
  %.state325 = load <8 x float>, ptr %.slot50, align 32
  %492 = fmul <8 x float> %.state325, splat (float 0x3FB6A09E60000000)
  %.state326 = load <8 x float>, ptr %.slot52, align 32
  %493 = fmul <8 x float> %.state326, splat (float 0x3FB6A09E60000000)
  %.state327 = load <8 x float>, ptr %.slot53, align 32
  %494 = fmul <8 x float> %.state327, splat (float 0x3FB6A09E60000000)
  %.state328 = load <8 x float>, ptr %.slot54, align 32
  %495 = fmul <8 x float> %.state328, splat (float 0x3FB6A09E60000000)
  %.state329 = load <8 x float>, ptr %.slot55, align 32
  %496 = fmul <8 x float> %.state329, splat (float 0x3FB6A09E60000000)
  %.state330 = load <8 x float>, ptr %.slot57, align 32
  %497 = fmul <8 x float> %.state330, splat (float 0x3FB6A09E60000000)
  %.state331 = load <8 x float>, ptr %.slot58, align 32
  %498 = fmul <8 x float> %.state331, splat (float 0x3FB6A09E60000000)
  %.state332 = load <8 x float>, ptr %.slot59, align 32
  %499 = fmul <8 x float> %.state332, splat (float 0x3FB6A09E60000000)
  %.state333 = load <8 x float>, ptr %.slot60, align 32
  %500 = fmul <8 x float> %.state333, splat (float 0x3FB6A09E60000000)
  %.spill.load334 = load i64, ptr %.spill37, align 4
  %501 = add i64 0, %.spill.load334
  %.spill.load335 = load i64, ptr %.spill37, align 4
  %502 = add i64 1, %.spill.load335
  %.spill.load336 = load i64, ptr %.spill37, align 4
  %503 = add i64 2, %.spill.load336
  %.spill.load337 = load i64, ptr %.spill37, align 4
  %504 = add i64 3, %.spill.load337
  %.spill.load338 = load i64, ptr %.spill37, align 4
  %505 = add i64 4, %.spill.load338
  %.spill.load339 = load i64, ptr %.spill37, align 4
  %506 = add i64 5, %.spill.load339
  %.spill.load340 = load i64, ptr %.spill37, align 4
  %507 = add i64 6, %.spill.load340
  %.spill.load341 = load i64, ptr %.spill37, align 4
  %508 = add i64 7, %.spill.load341
  %.spill.load342 = load i64, ptr %.spill37, align 4
  %509 = add i64 8, %.spill.load342
  %.spill.load343 = load i64, ptr %.spill37, align 4
  %510 = add i64 9, %.spill.load343
  %.spill.load344 = load i64, ptr %.spill37, align 4
  %511 = add i64 10, %.spill.load344
  %.spill.load345 = load i64, ptr %.spill37, align 4
  %512 = add i64 11, %.spill.load345
  %.spill.load346 = load i64, ptr %.spill37, align 4
  %513 = add i64 12, %.spill.load346
  %.spill.load347 = load i64, ptr %.spill37, align 4
  %514 = add i64 13, %.spill.load347
  %.spill.load348 = load i64, ptr %.spill37, align 4
  %515 = add i64 14, %.spill.load348
  %.spill.load349 = load i64, ptr %.spill37, align 4
  %516 = add i64 15, %.spill.load349
  %517 = icmp slt i64 %501, 8193
  %518 = icmp slt i64 %502, 8193
  %519 = icmp slt i64 %503, 8193
  %520 = icmp slt i64 %504, 8193
  %521 = icmp slt i64 %505, 8193
  %522 = icmp slt i64 %506, 8193
  %523 = icmp slt i64 %507, 8193
  %524 = icmp slt i64 %508, 8193
  %525 = icmp slt i64 %509, 8193
  %526 = icmp slt i64 %510, 8193
  %527 = icmp slt i64 %511, 8193
  %528 = icmp slt i64 %512, 8193
  %529 = icmp slt i64 %513, 8193
  %530 = icmp slt i64 %514, 8193
  %531 = icmp slt i64 %515, 8193
  %532 = icmp slt i64 %516, 8193
  %.spill.load350 = load i64, ptr %.spill31, align 4
  %533 = add i64 %.spill.load350, 8193
  %534 = sub i64 %533, 1
  %535 = icmp sle i64 %501, %534
  %536 = icmp sle i64 %502, %534
  %537 = icmp sle i64 %503, %534
  %538 = icmp sle i64 %504, %534
  %539 = icmp sle i64 %505, %534
  %540 = icmp sle i64 %506, %534
  %541 = icmp sle i64 %507, %534
  %542 = icmp sle i64 %508, %534
  %543 = icmp sle i64 %509, %534
  %544 = icmp sle i64 %510, %534
  %545 = icmp sle i64 %511, %534
  %546 = icmp sle i64 %512, %534
  %547 = icmp sle i64 %513, %534
  %548 = icmp sle i64 %514, %534
  %549 = icmp sle i64 %515, %534
  %550 = icmp sle i64 %516, %534
  %551 = and i1 %517, %535
  store i1 %551, ptr %.spill61, align 1
  %552 = and i1 %518, %536
  store i1 %552, ptr %.spill62, align 1
  %553 = and i1 %519, %537
  store i1 %553, ptr %.spill63, align 1
  %554 = and i1 %520, %538
  store i1 %554, ptr %.spill64, align 1
  %555 = and i1 %521, %539
  store i1 %555, ptr %.spill65, align 1
  %556 = and i1 %522, %540
  store i1 %556, ptr %.spill66, align 1
  %557 = and i1 %523, %541
  store i1 %557, ptr %.spill67, align 1
  %558 = and i1 %524, %542
  store i1 %558, ptr %.spill68, align 1
  %559 = and i1 %525, %543
  store i1 %559, ptr %.spill69, align 1
  %560 = and i1 %526, %544
  store i1 %560, ptr %.spill70, align 1
  %561 = and i1 %527, %545
  store i1 %561, ptr %.spill71, align 1
  %562 = and i1 %528, %546
  store i1 %562, ptr %.spill72, align 1
  %563 = and i1 %529, %547
  store i1 %563, ptr %.spill73, align 1
  %564 = and i1 %530, %548
  store i1 %564, ptr %.spill74, align 1
  %565 = and i1 %531, %549
  store i1 %565, ptr %.spill75, align 1
  %566 = and i1 %532, %550
  store i1 %566, ptr %.spill76, align 1
  %.splatinsert351 = insertelement <8 x i1> poison, i1 %551, i64 0
  %.splat352 = shufflevector <8 x i1> %.splatinsert351, <8 x i1> poison, <8 x i32> zeroinitializer
  %567 = select <8 x i1> %.splat352, <8 x float> %485, <8 x float> splat (float 0xC6293E5940000000)
  %568 = load <8 x float>, ptr %.spill77, align 32
  %569 = select <8 x i1> %71, <8 x float> %567, <8 x float> %568
  store <8 x float> %569, ptr %.spill77, align 32
  %.splatinsert353 = insertelement <8 x i1> poison, i1 %552, i64 0
  %.splat354 = shufflevector <8 x i1> %.splatinsert353, <8 x i1> poison, <8 x i32> zeroinitializer
  %570 = select <8 x i1> %.splat354, <8 x float> %486, <8 x float> splat (float 0xC6293E5940000000)
  %571 = load <8 x float>, ptr %.spill78, align 32
  %572 = select <8 x i1> %71, <8 x float> %570, <8 x float> %571
  store <8 x float> %572, ptr %.spill78, align 32
  %.splatinsert355 = insertelement <8 x i1> poison, i1 %553, i64 0
  %.splat356 = shufflevector <8 x i1> %.splatinsert355, <8 x i1> poison, <8 x i32> zeroinitializer
  %573 = select <8 x i1> %.splat356, <8 x float> %487, <8 x float> splat (float 0xC6293E5940000000)
  %574 = load <8 x float>, ptr %.spill79, align 32
  %575 = select <8 x i1> %71, <8 x float> %573, <8 x float> %574
  store <8 x float> %575, ptr %.spill79, align 32
  %.splatinsert357 = insertelement <8 x i1> poison, i1 %554, i64 0
  %.splat358 = shufflevector <8 x i1> %.splatinsert357, <8 x i1> poison, <8 x i32> zeroinitializer
  %576 = select <8 x i1> %.splat358, <8 x float> %488, <8 x float> splat (float 0xC6293E5940000000)
  %577 = load <8 x float>, ptr %.spill80, align 32
  %578 = select <8 x i1> %71, <8 x float> %576, <8 x float> %577
  store <8 x float> %578, ptr %.spill80, align 32
  %.splatinsert359 = insertelement <8 x i1> poison, i1 %555, i64 0
  %.splat360 = shufflevector <8 x i1> %.splatinsert359, <8 x i1> poison, <8 x i32> zeroinitializer
  %579 = select <8 x i1> %.splat360, <8 x float> %489, <8 x float> splat (float 0xC6293E5940000000)
  %580 = load <8 x float>, ptr %.spill81, align 32
  %581 = select <8 x i1> %71, <8 x float> %579, <8 x float> %580
  store <8 x float> %581, ptr %.spill81, align 32
  %.splatinsert361 = insertelement <8 x i1> poison, i1 %556, i64 0
  %.splat362 = shufflevector <8 x i1> %.splatinsert361, <8 x i1> poison, <8 x i32> zeroinitializer
  %582 = select <8 x i1> %.splat362, <8 x float> %490, <8 x float> splat (float 0xC6293E5940000000)
  %583 = load <8 x float>, ptr %.spill82, align 32
  %584 = select <8 x i1> %71, <8 x float> %582, <8 x float> %583
  store <8 x float> %584, ptr %.spill82, align 32
  %.splatinsert363 = insertelement <8 x i1> poison, i1 %557, i64 0
  %.splat364 = shufflevector <8 x i1> %.splatinsert363, <8 x i1> poison, <8 x i32> zeroinitializer
  %585 = select <8 x i1> %.splat364, <8 x float> %491, <8 x float> splat (float 0xC6293E5940000000)
  %586 = load <8 x float>, ptr %.spill83, align 32
  %587 = select <8 x i1> %71, <8 x float> %585, <8 x float> %586
  store <8 x float> %587, ptr %.spill83, align 32
  %.splatinsert365 = insertelement <8 x i1> poison, i1 %558, i64 0
  %.splat366 = shufflevector <8 x i1> %.splatinsert365, <8 x i1> poison, <8 x i32> zeroinitializer
  %588 = select <8 x i1> %.splat366, <8 x float> %492, <8 x float> splat (float 0xC6293E5940000000)
  %589 = load <8 x float>, ptr %.spill84, align 32
  %590 = select <8 x i1> %71, <8 x float> %588, <8 x float> %589
  store <8 x float> %590, ptr %.spill84, align 32
  %.splatinsert367 = insertelement <8 x i1> poison, i1 %559, i64 0
  %.splat368 = shufflevector <8 x i1> %.splatinsert367, <8 x i1> poison, <8 x i32> zeroinitializer
  %591 = select <8 x i1> %.splat368, <8 x float> %493, <8 x float> splat (float 0xC6293E5940000000)
  %592 = load <8 x float>, ptr %.spill85, align 32
  %593 = select <8 x i1> %71, <8 x float> %591, <8 x float> %592
  store <8 x float> %593, ptr %.spill85, align 32
  %.splatinsert369 = insertelement <8 x i1> poison, i1 %560, i64 0
  %.splat370 = shufflevector <8 x i1> %.splatinsert369, <8 x i1> poison, <8 x i32> zeroinitializer
  %594 = select <8 x i1> %.splat370, <8 x float> %494, <8 x float> splat (float 0xC6293E5940000000)
  %595 = load <8 x float>, ptr %.spill86, align 32
  %596 = select <8 x i1> %71, <8 x float> %594, <8 x float> %595
  store <8 x float> %596, ptr %.spill86, align 32
  %.splatinsert371 = insertelement <8 x i1> poison, i1 %561, i64 0
  %.splat372 = shufflevector <8 x i1> %.splatinsert371, <8 x i1> poison, <8 x i32> zeroinitializer
  %597 = select <8 x i1> %.splat372, <8 x float> %495, <8 x float> splat (float 0xC6293E5940000000)
  %598 = load <8 x float>, ptr %.spill87, align 32
  %599 = select <8 x i1> %71, <8 x float> %597, <8 x float> %598
  store <8 x float> %599, ptr %.spill87, align 32
  %.splatinsert373 = insertelement <8 x i1> poison, i1 %562, i64 0
  %.splat374 = shufflevector <8 x i1> %.splatinsert373, <8 x i1> poison, <8 x i32> zeroinitializer
  %600 = select <8 x i1> %.splat374, <8 x float> %496, <8 x float> splat (float 0xC6293E5940000000)
  %601 = load <8 x float>, ptr %.spill88, align 32
  %602 = select <8 x i1> %71, <8 x float> %600, <8 x float> %601
  store <8 x float> %602, ptr %.spill88, align 32
  %.splatinsert375 = insertelement <8 x i1> poison, i1 %563, i64 0
  %.splat376 = shufflevector <8 x i1> %.splatinsert375, <8 x i1> poison, <8 x i32> zeroinitializer
  %603 = select <8 x i1> %.splat376, <8 x float> %497, <8 x float> splat (float 0xC6293E5940000000)
  %604 = load <8 x float>, ptr %.spill89, align 32
  %605 = select <8 x i1> %71, <8 x float> %603, <8 x float> %604
  store <8 x float> %605, ptr %.spill89, align 32
  %.splatinsert377 = insertelement <8 x i1> poison, i1 %564, i64 0
  %.splat378 = shufflevector <8 x i1> %.splatinsert377, <8 x i1> poison, <8 x i32> zeroinitializer
  %606 = select <8 x i1> %.splat378, <8 x float> %498, <8 x float> splat (float 0xC6293E5940000000)
  %607 = load <8 x float>, ptr %.spill90, align 32
  %608 = select <8 x i1> %71, <8 x float> %606, <8 x float> %607
  store <8 x float> %608, ptr %.spill90, align 32
  %.splatinsert379 = insertelement <8 x i1> poison, i1 %565, i64 0
  %.splat380 = shufflevector <8 x i1> %.splatinsert379, <8 x i1> poison, <8 x i32> zeroinitializer
  %609 = select <8 x i1> %.splat380, <8 x float> %499, <8 x float> splat (float 0xC6293E5940000000)
  %610 = load <8 x float>, ptr %.spill91, align 32
  %611 = select <8 x i1> %71, <8 x float> %609, <8 x float> %610
  store <8 x float> %611, ptr %.spill91, align 32
  %.splatinsert381 = insertelement <8 x i1> poison, i1 %566, i64 0
  %.splat382 = shufflevector <8 x i1> %.splatinsert381, <8 x i1> poison, <8 x i32> zeroinitializer
  %612 = select <8 x i1> %.splat382, <8 x float> %500, <8 x float> splat (float 0xC6293E5940000000)
  %613 = load <8 x float>, ptr %.spill92, align 32
  %614 = select <8 x i1> %71, <8 x float> %612, <8 x float> %613
  store <8 x float> %614, ptr %.spill92, align 32
  %615 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %615, 0
  %618 = select <8 x i1> %71, <8 x ptr> %616, <8 x ptr> %617
  %619 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %620 = extractvalue { <8 x ptr>, <8 x i64> } %615, 1
  %621 = select <8 x i1> %71, <8 x i64> %619, <8 x i64> %620
  %622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %618, 0
  %623 = insertvalue { <8 x ptr>, <8 x i64> } %622, <8 x i64> %621, 1
  store { <8 x ptr>, <8 x i64> } %623, ptr %tile_snapshot.spill93, align 64
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %625 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %626 = add <8 x i64> %625, zeroinitializer
  %627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %624, 0
  %628 = insertvalue { <8 x ptr>, <8 x i64> } %627, <8 x i64> %626, 1
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %628, 1
  %631 = extractelement <8 x ptr> %629, i32 0
  %632 = extractelement <8 x i64> %630, i32 0
  %633 = sub i64 %632, 0
  %634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %635 = select i1 %634, i64 %633, i64 0
  %private.contiguous.address383 = getelementptr i8, ptr %631, i64 %635
  %private.contiguous.preserve384 = load <8 x float>, ptr %private.contiguous.address383, align 4
  %636 = select <8 x i1> %71, <8 x float> %567, <8 x float> %private.contiguous.preserve384
  store <8 x float> %636, ptr %private.contiguous.address383, align 4
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %639 = add <8 x i64> %638, splat (i64 32)
  %640 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %637, 0
  %641 = insertvalue { <8 x ptr>, <8 x i64> } %640, <8 x i64> %639, 1
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %641, 1
  %644 = extractelement <8 x ptr> %642, i32 0
  %645 = extractelement <8 x i64> %643, i32 0
  %646 = sub i64 %645, 0
  %647 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %648 = select i1 %647, i64 %646, i64 0
  %private.contiguous.address385 = getelementptr i8, ptr %644, i64 %648
  %private.contiguous.preserve386 = load <8 x float>, ptr %private.contiguous.address385, align 4
  %649 = select <8 x i1> %71, <8 x float> %570, <8 x float> %private.contiguous.preserve386
  store <8 x float> %649, ptr %private.contiguous.address385, align 4
  %650 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %651 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %652 = add <8 x i64> %651, splat (i64 64)
  %653 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %650, 0
  %654 = insertvalue { <8 x ptr>, <8 x i64> } %653, <8 x i64> %652, 1
  %655 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %656 = extractvalue { <8 x ptr>, <8 x i64> } %654, 1
  %657 = extractelement <8 x ptr> %655, i32 0
  %658 = extractelement <8 x i64> %656, i32 0
  %659 = sub i64 %658, 0
  %660 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %661 = select i1 %660, i64 %659, i64 0
  %private.contiguous.address387 = getelementptr i8, ptr %657, i64 %661
  %private.contiguous.preserve388 = load <8 x float>, ptr %private.contiguous.address387, align 4
  %662 = select <8 x i1> %71, <8 x float> %573, <8 x float> %private.contiguous.preserve388
  store <8 x float> %662, ptr %private.contiguous.address387, align 4
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %665 = add <8 x i64> %664, splat (i64 96)
  %666 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %663, 0
  %667 = insertvalue { <8 x ptr>, <8 x i64> } %666, <8 x i64> %665, 1
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %667, 1
  %670 = extractelement <8 x ptr> %668, i32 0
  %671 = extractelement <8 x i64> %669, i32 0
  %672 = sub i64 %671, 0
  %673 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %674 = select i1 %673, i64 %672, i64 0
  %private.contiguous.address389 = getelementptr i8, ptr %670, i64 %674
  %private.contiguous.preserve390 = load <8 x float>, ptr %private.contiguous.address389, align 4
  %675 = select <8 x i1> %71, <8 x float> %576, <8 x float> %private.contiguous.preserve390
  store <8 x float> %675, ptr %private.contiguous.address389, align 4
  %676 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %677 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %678 = add <8 x i64> %677, splat (i64 128)
  %679 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %676, 0
  %680 = insertvalue { <8 x ptr>, <8 x i64> } %679, <8 x i64> %678, 1
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %682 = extractvalue { <8 x ptr>, <8 x i64> } %680, 1
  %683 = extractelement <8 x ptr> %681, i32 0
  %684 = extractelement <8 x i64> %682, i32 0
  %685 = sub i64 %684, 0
  %686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %687 = select i1 %686, i64 %685, i64 0
  %private.contiguous.address391 = getelementptr i8, ptr %683, i64 %687
  %private.contiguous.preserve392 = load <8 x float>, ptr %private.contiguous.address391, align 4
  %688 = select <8 x i1> %71, <8 x float> %579, <8 x float> %private.contiguous.preserve392
  store <8 x float> %688, ptr %private.contiguous.address391, align 4
  %689 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %690 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %691 = add <8 x i64> %690, splat (i64 160)
  %692 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %689, 0
  %693 = insertvalue { <8 x ptr>, <8 x i64> } %692, <8 x i64> %691, 1
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %695 = extractvalue { <8 x ptr>, <8 x i64> } %693, 1
  %696 = extractelement <8 x ptr> %694, i32 0
  %697 = extractelement <8 x i64> %695, i32 0
  %698 = sub i64 %697, 0
  %699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %700 = select i1 %699, i64 %698, i64 0
  %private.contiguous.address393 = getelementptr i8, ptr %696, i64 %700
  %private.contiguous.preserve394 = load <8 x float>, ptr %private.contiguous.address393, align 4
  %701 = select <8 x i1> %71, <8 x float> %582, <8 x float> %private.contiguous.preserve394
  store <8 x float> %701, ptr %private.contiguous.address393, align 4
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %703 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %704 = add <8 x i64> %703, splat (i64 192)
  %705 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %702, 0
  %706 = insertvalue { <8 x ptr>, <8 x i64> } %705, <8 x i64> %704, 1
  %707 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %708 = extractvalue { <8 x ptr>, <8 x i64> } %706, 1
  %709 = extractelement <8 x ptr> %707, i32 0
  %710 = extractelement <8 x i64> %708, i32 0
  %711 = sub i64 %710, 0
  %712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %713 = select i1 %712, i64 %711, i64 0
  %private.contiguous.address395 = getelementptr i8, ptr %709, i64 %713
  %private.contiguous.preserve396 = load <8 x float>, ptr %private.contiguous.address395, align 4
  %714 = select <8 x i1> %71, <8 x float> %585, <8 x float> %private.contiguous.preserve396
  store <8 x float> %714, ptr %private.contiguous.address395, align 4
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %717 = add <8 x i64> %716, splat (i64 224)
  %718 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %715, 0
  %719 = insertvalue { <8 x ptr>, <8 x i64> } %718, <8 x i64> %717, 1
  %720 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %719, 1
  %722 = extractelement <8 x ptr> %720, i32 0
  %723 = extractelement <8 x i64> %721, i32 0
  %724 = sub i64 %723, 0
  %725 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %726 = select i1 %725, i64 %724, i64 0
  %private.contiguous.address397 = getelementptr i8, ptr %722, i64 %726
  %private.contiguous.preserve398 = load <8 x float>, ptr %private.contiguous.address397, align 4
  %727 = select <8 x i1> %71, <8 x float> %588, <8 x float> %private.contiguous.preserve398
  store <8 x float> %727, ptr %private.contiguous.address397, align 4
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %730 = add <8 x i64> %729, splat (i64 256)
  %731 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %728, 0
  %732 = insertvalue { <8 x ptr>, <8 x i64> } %731, <8 x i64> %730, 1
  %733 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %734 = extractvalue { <8 x ptr>, <8 x i64> } %732, 1
  %735 = extractelement <8 x ptr> %733, i32 0
  %736 = extractelement <8 x i64> %734, i32 0
  %737 = sub i64 %736, 0
  %738 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %739 = select i1 %738, i64 %737, i64 0
  %private.contiguous.address399 = getelementptr i8, ptr %735, i64 %739
  %private.contiguous.preserve400 = load <8 x float>, ptr %private.contiguous.address399, align 4
  %740 = select <8 x i1> %71, <8 x float> %591, <8 x float> %private.contiguous.preserve400
  store <8 x float> %740, ptr %private.contiguous.address399, align 4
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %743 = add <8 x i64> %742, splat (i64 288)
  %744 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %741, 0
  %745 = insertvalue { <8 x ptr>, <8 x i64> } %744, <8 x i64> %743, 1
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %747 = extractvalue { <8 x ptr>, <8 x i64> } %745, 1
  %748 = extractelement <8 x ptr> %746, i32 0
  %749 = extractelement <8 x i64> %747, i32 0
  %750 = sub i64 %749, 0
  %751 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %752 = select i1 %751, i64 %750, i64 0
  %private.contiguous.address401 = getelementptr i8, ptr %748, i64 %752
  %private.contiguous.preserve402 = load <8 x float>, ptr %private.contiguous.address401, align 4
  %753 = select <8 x i1> %71, <8 x float> %594, <8 x float> %private.contiguous.preserve402
  store <8 x float> %753, ptr %private.contiguous.address401, align 4
  %754 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %755 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %756 = add <8 x i64> %755, splat (i64 320)
  %757 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %754, 0
  %758 = insertvalue { <8 x ptr>, <8 x i64> } %757, <8 x i64> %756, 1
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %758, 1
  %761 = extractelement <8 x ptr> %759, i32 0
  %762 = extractelement <8 x i64> %760, i32 0
  %763 = sub i64 %762, 0
  %764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %765 = select i1 %764, i64 %763, i64 0
  %private.contiguous.address403 = getelementptr i8, ptr %761, i64 %765
  %private.contiguous.preserve404 = load <8 x float>, ptr %private.contiguous.address403, align 4
  %766 = select <8 x i1> %71, <8 x float> %597, <8 x float> %private.contiguous.preserve404
  store <8 x float> %766, ptr %private.contiguous.address403, align 4
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %768 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %769 = add <8 x i64> %768, splat (i64 352)
  %770 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %767, 0
  %771 = insertvalue { <8 x ptr>, <8 x i64> } %770, <8 x i64> %769, 1
  %772 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %773 = extractvalue { <8 x ptr>, <8 x i64> } %771, 1
  %774 = extractelement <8 x ptr> %772, i32 0
  %775 = extractelement <8 x i64> %773, i32 0
  %776 = sub i64 %775, 0
  %777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %778 = select i1 %777, i64 %776, i64 0
  %private.contiguous.address405 = getelementptr i8, ptr %774, i64 %778
  %private.contiguous.preserve406 = load <8 x float>, ptr %private.contiguous.address405, align 4
  %779 = select <8 x i1> %71, <8 x float> %600, <8 x float> %private.contiguous.preserve406
  store <8 x float> %779, ptr %private.contiguous.address405, align 4
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %782 = add <8 x i64> %781, splat (i64 384)
  %783 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %780, 0
  %784 = insertvalue { <8 x ptr>, <8 x i64> } %783, <8 x i64> %782, 1
  %785 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %786 = extractvalue { <8 x ptr>, <8 x i64> } %784, 1
  %787 = extractelement <8 x ptr> %785, i32 0
  %788 = extractelement <8 x i64> %786, i32 0
  %789 = sub i64 %788, 0
  %790 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %791 = select i1 %790, i64 %789, i64 0
  %private.contiguous.address407 = getelementptr i8, ptr %787, i64 %791
  %private.contiguous.preserve408 = load <8 x float>, ptr %private.contiguous.address407, align 4
  %792 = select <8 x i1> %71, <8 x float> %603, <8 x float> %private.contiguous.preserve408
  store <8 x float> %792, ptr %private.contiguous.address407, align 4
  %793 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %795 = add <8 x i64> %794, splat (i64 416)
  %796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %793, 0
  %797 = insertvalue { <8 x ptr>, <8 x i64> } %796, <8 x i64> %795, 1
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %797, 1
  %800 = extractelement <8 x ptr> %798, i32 0
  %801 = extractelement <8 x i64> %799, i32 0
  %802 = sub i64 %801, 0
  %803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %804 = select i1 %803, i64 %802, i64 0
  %private.contiguous.address409 = getelementptr i8, ptr %800, i64 %804
  %private.contiguous.preserve410 = load <8 x float>, ptr %private.contiguous.address409, align 4
  %805 = select <8 x i1> %71, <8 x float> %606, <8 x float> %private.contiguous.preserve410
  store <8 x float> %805, ptr %private.contiguous.address409, align 4
  %806 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %808 = add <8 x i64> %807, splat (i64 448)
  %809 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %806, 0
  %810 = insertvalue { <8 x ptr>, <8 x i64> } %809, <8 x i64> %808, 1
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %810, 1
  %813 = extractelement <8 x ptr> %811, i32 0
  %814 = extractelement <8 x i64> %812, i32 0
  %815 = sub i64 %814, 0
  %816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %817 = select i1 %816, i64 %815, i64 0
  %private.contiguous.address411 = getelementptr i8, ptr %813, i64 %817
  %private.contiguous.preserve412 = load <8 x float>, ptr %private.contiguous.address411, align 4
  %818 = select <8 x i1> %71, <8 x float> %609, <8 x float> %private.contiguous.preserve412
  store <8 x float> %818, ptr %private.contiguous.address411, align 4
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %821 = add <8 x i64> %820, splat (i64 480)
  %822 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %819, 0
  %823 = insertvalue { <8 x ptr>, <8 x i64> } %822, <8 x i64> %821, 1
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %823, 1
  %826 = extractelement <8 x ptr> %824, i32 0
  %827 = extractelement <8 x i64> %825, i32 0
  %828 = sub i64 %827, 0
  %829 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %830 = select i1 %829, i64 %828, i64 0
  %private.contiguous.address413 = getelementptr i8, ptr %826, i64 %830
  %private.contiguous.preserve414 = load <8 x float>, ptr %private.contiguous.address413, align 4
  %831 = select <8 x i1> %71, <8 x float> %612, <8 x float> %private.contiguous.preserve414
  store <8 x float> %831, ptr %private.contiguous.address413, align 4
  store i64 0, ptr %.slot94, align 4
  %832 = load <8 x float>, ptr %.slot95, align 32
  %833 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %832
  store <8 x float> %833, ptr %.slot95, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state415 = load i64, ptr %.slot94, align 4
  %834 = icmp slt i64 %.state415, 16
  br i1 %834, label %direct.true416, label %direct.false417

direct.schedule.23:                               ; preds = %direct.true416
  %.state418 = load i64, ptr %.slot94, align 4
  %835 = sdiv i64 %.state418, 1
  %.spill.load419 = load i64, ptr %.spill31, align 4
  %836 = mul i64 %.spill.load419, 1
  %837 = add i64 %836, 0
  %838 = mul i64 %837, 1
  %839 = add i64 %838, 0
  %840 = mul i64 %839, 16
  %841 = add i64 %840, %835
  %tile_snapshot.spill.load420 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load420, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load420, 1
  %.splatinsert421 = insertelement <8 x i64> poison, i64 %841, i64 0
  %.splat422 = shufflevector <8 x i64> %.splatinsert421, <8 x i64> poison, <8 x i32> zeroinitializer
  %844 = mul <8 x i64> %.splat422, splat (i64 32)
  %845 = add <8 x i64> %843, %844
  %846 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %842, 0
  %847 = insertvalue { <8 x ptr>, <8 x i64> } %846, <8 x i64> %845, 1
  %848 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %847, 1
  %850 = extractelement <8 x ptr> %848, i32 0
  %851 = extractelement <8 x i64> %849, i32 0
  %852 = sub i64 %851, 0
  %853 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %854 = select i1 %853, i64 %852, i64 0
  %private.contiguous.address423 = getelementptr i8, ptr %850, i64 %854
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address423, align 4
  %855 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.state424 = load <8 x float>, ptr %.slot95, align 32
  %856 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state424, <8 x float> %855)
  %.state425 = load i64, ptr %.slot94, align 4
  %857 = add i64 %.state425, 1
  store i64 %857, ptr %.slot94, align 4
  %858 = load <8 x float>, ptr %.slot95, align 32
  %859 = select <8 x i1> %71, <8 x float> %856, <8 x float> %858
  store <8 x float> %859, ptr %.slot95, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false417
  %.state426 = load <8 x float>, ptr %.slot35, align 32
  %.state427 = load <8 x float>, ptr %.slot95, align 32
  %860 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state426, <8 x float> %.state427)
  %861 = load <8 x float>, ptr %.spill96, align 32
  %862 = select <8 x i1> %71, <8 x float> %860, <8 x float> %861
  store <8 x float> %862, ptr %.spill96, align 32
  %.state428 = load <8 x float>, ptr %.slot35, align 32
  %863 = fsub <8 x float> %.state428, %860
  %864 = select <8 x i1> %71, <8 x float> %863, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %864)
  %865 = load <8 x float>, ptr %.spill97, align 32
  %866 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %865
  store <8 x float> %866, ptr %.spill97, align 32
  %.spill.load429 = load <8 x float>, ptr %.spill77, align 32
  %867 = fsub <8 x float> %.spill.load429, %860
  %.spill.load430 = load <8 x float>, ptr %.spill78, align 32
  %868 = fsub <8 x float> %.spill.load430, %860
  %.spill.load431 = load <8 x float>, ptr %.spill79, align 32
  %869 = fsub <8 x float> %.spill.load431, %860
  %.spill.load432 = load <8 x float>, ptr %.spill80, align 32
  %870 = fsub <8 x float> %.spill.load432, %860
  %.spill.load433 = load <8 x float>, ptr %.spill81, align 32
  %871 = fsub <8 x float> %.spill.load433, %860
  %.spill.load434 = load <8 x float>, ptr %.spill82, align 32
  %872 = fsub <8 x float> %.spill.load434, %860
  %.spill.load435 = load <8 x float>, ptr %.spill83, align 32
  %873 = fsub <8 x float> %.spill.load435, %860
  %.spill.load436 = load <8 x float>, ptr %.spill84, align 32
  %874 = fsub <8 x float> %.spill.load436, %860
  %.spill.load437 = load <8 x float>, ptr %.spill85, align 32
  %875 = fsub <8 x float> %.spill.load437, %860
  %.spill.load438 = load <8 x float>, ptr %.spill86, align 32
  %876 = fsub <8 x float> %.spill.load438, %860
  %.spill.load439 = load <8 x float>, ptr %.spill87, align 32
  %877 = fsub <8 x float> %.spill.load439, %860
  %.spill.load440 = load <8 x float>, ptr %.spill88, align 32
  %878 = fsub <8 x float> %.spill.load440, %860
  %.spill.load441 = load <8 x float>, ptr %.spill89, align 32
  %879 = fsub <8 x float> %.spill.load441, %860
  %.spill.load442 = load <8 x float>, ptr %.spill90, align 32
  %880 = fsub <8 x float> %.spill.load442, %860
  %.spill.load443 = load <8 x float>, ptr %.spill91, align 32
  %881 = fsub <8 x float> %.spill.load443, %860
  %.spill.load444 = load <8 x float>, ptr %.spill92, align 32
  %882 = fsub <8 x float> %.spill.load444, %860
  %883 = select <8 x i1> %71, <8 x float> %867, <8 x float> zeroinitializer
  %native.exp445 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %883)
  %884 = select <8 x i1> %71, <8 x float> %868, <8 x float> zeroinitializer
  %native.exp446 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %884)
  %885 = select <8 x i1> %71, <8 x float> %869, <8 x float> zeroinitializer
  %native.exp447 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %885)
  %886 = select <8 x i1> %71, <8 x float> %870, <8 x float> zeroinitializer
  %native.exp448 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %886)
  %887 = select <8 x i1> %71, <8 x float> %871, <8 x float> zeroinitializer
  %native.exp449 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %887)
  %888 = select <8 x i1> %71, <8 x float> %872, <8 x float> zeroinitializer
  %native.exp450 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %888)
  %889 = select <8 x i1> %71, <8 x float> %873, <8 x float> zeroinitializer
  %native.exp451 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %889)
  %890 = select <8 x i1> %71, <8 x float> %874, <8 x float> zeroinitializer
  %native.exp452 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %890)
  %891 = select <8 x i1> %71, <8 x float> %875, <8 x float> zeroinitializer
  %native.exp453 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %891)
  %892 = select <8 x i1> %71, <8 x float> %876, <8 x float> zeroinitializer
  %native.exp454 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %892)
  %893 = select <8 x i1> %71, <8 x float> %877, <8 x float> zeroinitializer
  %native.exp455 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %893)
  %894 = select <8 x i1> %71, <8 x float> %878, <8 x float> zeroinitializer
  %native.exp456 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %894)
  %895 = select <8 x i1> %71, <8 x float> %879, <8 x float> zeroinitializer
  %native.exp457 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %895)
  %896 = select <8 x i1> %71, <8 x float> %880, <8 x float> zeroinitializer
  %native.exp458 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %896)
  %897 = select <8 x i1> %71, <8 x float> %881, <8 x float> zeroinitializer
  %native.exp459 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %897)
  %898 = select <8 x i1> %71, <8 x float> %882, <8 x float> zeroinitializer
  %native.exp460 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %898)
  %.spill.load461 = load i1, ptr %.spill61, align 1
  %.splatinsert462 = insertelement <8 x i1> poison, i1 %.spill.load461, i64 0
  %.splat463 = shufflevector <8 x i1> %.splatinsert462, <8 x i1> poison, <8 x i32> zeroinitializer
  %899 = select <8 x i1> %.splat463, <8 x float> %native.exp445, <8 x float> zeroinitializer
  %.spill.load464 = load i1, ptr %.spill62, align 1
  %.splatinsert465 = insertelement <8 x i1> poison, i1 %.spill.load464, i64 0
  %.splat466 = shufflevector <8 x i1> %.splatinsert465, <8 x i1> poison, <8 x i32> zeroinitializer
  %900 = select <8 x i1> %.splat466, <8 x float> %native.exp446, <8 x float> zeroinitializer
  %.spill.load467 = load i1, ptr %.spill63, align 1
  %.splatinsert468 = insertelement <8 x i1> poison, i1 %.spill.load467, i64 0
  %.splat469 = shufflevector <8 x i1> %.splatinsert468, <8 x i1> poison, <8 x i32> zeroinitializer
  %901 = select <8 x i1> %.splat469, <8 x float> %native.exp447, <8 x float> zeroinitializer
  %.spill.load470 = load i1, ptr %.spill64, align 1
  %.splatinsert471 = insertelement <8 x i1> poison, i1 %.spill.load470, i64 0
  %.splat472 = shufflevector <8 x i1> %.splatinsert471, <8 x i1> poison, <8 x i32> zeroinitializer
  %902 = select <8 x i1> %.splat472, <8 x float> %native.exp448, <8 x float> zeroinitializer
  %.spill.load473 = load i1, ptr %.spill65, align 1
  %.splatinsert474 = insertelement <8 x i1> poison, i1 %.spill.load473, i64 0
  %.splat475 = shufflevector <8 x i1> %.splatinsert474, <8 x i1> poison, <8 x i32> zeroinitializer
  %903 = select <8 x i1> %.splat475, <8 x float> %native.exp449, <8 x float> zeroinitializer
  %.spill.load476 = load i1, ptr %.spill66, align 1
  %.splatinsert477 = insertelement <8 x i1> poison, i1 %.spill.load476, i64 0
  %.splat478 = shufflevector <8 x i1> %.splatinsert477, <8 x i1> poison, <8 x i32> zeroinitializer
  %904 = select <8 x i1> %.splat478, <8 x float> %native.exp450, <8 x float> zeroinitializer
  %.spill.load479 = load i1, ptr %.spill67, align 1
  %.splatinsert480 = insertelement <8 x i1> poison, i1 %.spill.load479, i64 0
  %.splat481 = shufflevector <8 x i1> %.splatinsert480, <8 x i1> poison, <8 x i32> zeroinitializer
  %905 = select <8 x i1> %.splat481, <8 x float> %native.exp451, <8 x float> zeroinitializer
  %.spill.load482 = load i1, ptr %.spill68, align 1
  %.splatinsert483 = insertelement <8 x i1> poison, i1 %.spill.load482, i64 0
  %.splat484 = shufflevector <8 x i1> %.splatinsert483, <8 x i1> poison, <8 x i32> zeroinitializer
  %906 = select <8 x i1> %.splat484, <8 x float> %native.exp452, <8 x float> zeroinitializer
  %.spill.load485 = load i1, ptr %.spill69, align 1
  %.splatinsert486 = insertelement <8 x i1> poison, i1 %.spill.load485, i64 0
  %.splat487 = shufflevector <8 x i1> %.splatinsert486, <8 x i1> poison, <8 x i32> zeroinitializer
  %907 = select <8 x i1> %.splat487, <8 x float> %native.exp453, <8 x float> zeroinitializer
  %.spill.load488 = load i1, ptr %.spill70, align 1
  %.splatinsert489 = insertelement <8 x i1> poison, i1 %.spill.load488, i64 0
  %.splat490 = shufflevector <8 x i1> %.splatinsert489, <8 x i1> poison, <8 x i32> zeroinitializer
  %908 = select <8 x i1> %.splat490, <8 x float> %native.exp454, <8 x float> zeroinitializer
  %.spill.load491 = load i1, ptr %.spill71, align 1
  %.splatinsert492 = insertelement <8 x i1> poison, i1 %.spill.load491, i64 0
  %.splat493 = shufflevector <8 x i1> %.splatinsert492, <8 x i1> poison, <8 x i32> zeroinitializer
  %909 = select <8 x i1> %.splat493, <8 x float> %native.exp455, <8 x float> zeroinitializer
  %.spill.load494 = load i1, ptr %.spill72, align 1
  %.splatinsert495 = insertelement <8 x i1> poison, i1 %.spill.load494, i64 0
  %.splat496 = shufflevector <8 x i1> %.splatinsert495, <8 x i1> poison, <8 x i32> zeroinitializer
  %910 = select <8 x i1> %.splat496, <8 x float> %native.exp456, <8 x float> zeroinitializer
  %.spill.load497 = load i1, ptr %.spill73, align 1
  %.splatinsert498 = insertelement <8 x i1> poison, i1 %.spill.load497, i64 0
  %.splat499 = shufflevector <8 x i1> %.splatinsert498, <8 x i1> poison, <8 x i32> zeroinitializer
  %911 = select <8 x i1> %.splat499, <8 x float> %native.exp457, <8 x float> zeroinitializer
  %.spill.load500 = load i1, ptr %.spill74, align 1
  %.splatinsert501 = insertelement <8 x i1> poison, i1 %.spill.load500, i64 0
  %.splat502 = shufflevector <8 x i1> %.splatinsert501, <8 x i1> poison, <8 x i32> zeroinitializer
  %912 = select <8 x i1> %.splat502, <8 x float> %native.exp458, <8 x float> zeroinitializer
  %.spill.load503 = load i1, ptr %.spill75, align 1
  %.splatinsert504 = insertelement <8 x i1> poison, i1 %.spill.load503, i64 0
  %.splat505 = shufflevector <8 x i1> %.splatinsert504, <8 x i1> poison, <8 x i32> zeroinitializer
  %913 = select <8 x i1> %.splat505, <8 x float> %native.exp459, <8 x float> zeroinitializer
  %.spill.load506 = load i1, ptr %.spill76, align 1
  %.splatinsert507 = insertelement <8 x i1> poison, i1 %.spill.load506, i64 0
  %.splat508 = shufflevector <8 x i1> %.splatinsert507, <8 x i1> poison, <8 x i32> zeroinitializer
  %914 = select <8 x i1> %.splat508, <8 x float> %native.exp460, <8 x float> zeroinitializer
  %915 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %917 = extractvalue { <8 x ptr>, <8 x i64> } %915, 0
  %918 = select <8 x i1> %71, <8 x ptr> %916, <8 x ptr> %917
  %919 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %915, 1
  %921 = select <8 x i1> %71, <8 x i64> %919, <8 x i64> %920
  %922 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %918, 0
  %923 = insertvalue { <8 x ptr>, <8 x i64> } %922, <8 x i64> %921, 1
  store { <8 x ptr>, <8 x i64> } %923, ptr %tile_snapshot.spill98, align 64
  %924 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %925 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %926 = add <8 x i64> %925, zeroinitializer
  %927 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %924, 0
  %928 = insertvalue { <8 x ptr>, <8 x i64> } %927, <8 x i64> %926, 1
  %929 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %930 = extractvalue { <8 x ptr>, <8 x i64> } %928, 1
  %931 = extractelement <8 x ptr> %929, i32 0
  %932 = extractelement <8 x i64> %930, i32 0
  %933 = sub i64 %932, 0
  %934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %935 = select i1 %934, i64 %933, i64 0
  %private.contiguous.address509 = getelementptr i8, ptr %931, i64 %935
  %private.contiguous.preserve510 = load <8 x float>, ptr %private.contiguous.address509, align 4
  %936 = select <8 x i1> %71, <8 x float> %899, <8 x float> %private.contiguous.preserve510
  store <8 x float> %936, ptr %private.contiguous.address509, align 4
  %937 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %938 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %939 = add <8 x i64> %938, splat (i64 32)
  %940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %937, 0
  %941 = insertvalue { <8 x ptr>, <8 x i64> } %940, <8 x i64> %939, 1
  %942 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %943 = extractvalue { <8 x ptr>, <8 x i64> } %941, 1
  %944 = extractelement <8 x ptr> %942, i32 0
  %945 = extractelement <8 x i64> %943, i32 0
  %946 = sub i64 %945, 0
  %947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %948 = select i1 %947, i64 %946, i64 0
  %private.contiguous.address511 = getelementptr i8, ptr %944, i64 %948
  %private.contiguous.preserve512 = load <8 x float>, ptr %private.contiguous.address511, align 4
  %949 = select <8 x i1> %71, <8 x float> %900, <8 x float> %private.contiguous.preserve512
  store <8 x float> %949, ptr %private.contiguous.address511, align 4
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %951 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %952 = add <8 x i64> %951, splat (i64 64)
  %953 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %950, 0
  %954 = insertvalue { <8 x ptr>, <8 x i64> } %953, <8 x i64> %952, 1
  %955 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %956 = extractvalue { <8 x ptr>, <8 x i64> } %954, 1
  %957 = extractelement <8 x ptr> %955, i32 0
  %958 = extractelement <8 x i64> %956, i32 0
  %959 = sub i64 %958, 0
  %960 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %961 = select i1 %960, i64 %959, i64 0
  %private.contiguous.address513 = getelementptr i8, ptr %957, i64 %961
  %private.contiguous.preserve514 = load <8 x float>, ptr %private.contiguous.address513, align 4
  %962 = select <8 x i1> %71, <8 x float> %901, <8 x float> %private.contiguous.preserve514
  store <8 x float> %962, ptr %private.contiguous.address513, align 4
  %963 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %964 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %965 = add <8 x i64> %964, splat (i64 96)
  %966 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %963, 0
  %967 = insertvalue { <8 x ptr>, <8 x i64> } %966, <8 x i64> %965, 1
  %968 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %969 = extractvalue { <8 x ptr>, <8 x i64> } %967, 1
  %970 = extractelement <8 x ptr> %968, i32 0
  %971 = extractelement <8 x i64> %969, i32 0
  %972 = sub i64 %971, 0
  %973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %974 = select i1 %973, i64 %972, i64 0
  %private.contiguous.address515 = getelementptr i8, ptr %970, i64 %974
  %private.contiguous.preserve516 = load <8 x float>, ptr %private.contiguous.address515, align 4
  %975 = select <8 x i1> %71, <8 x float> %902, <8 x float> %private.contiguous.preserve516
  store <8 x float> %975, ptr %private.contiguous.address515, align 4
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %977 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %978 = add <8 x i64> %977, splat (i64 128)
  %979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %976, 0
  %980 = insertvalue { <8 x ptr>, <8 x i64> } %979, <8 x i64> %978, 1
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %980, 1
  %983 = extractelement <8 x ptr> %981, i32 0
  %984 = extractelement <8 x i64> %982, i32 0
  %985 = sub i64 %984, 0
  %986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %987 = select i1 %986, i64 %985, i64 0
  %private.contiguous.address517 = getelementptr i8, ptr %983, i64 %987
  %private.contiguous.preserve518 = load <8 x float>, ptr %private.contiguous.address517, align 4
  %988 = select <8 x i1> %71, <8 x float> %903, <8 x float> %private.contiguous.preserve518
  store <8 x float> %988, ptr %private.contiguous.address517, align 4
  %989 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %990 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %991 = add <8 x i64> %990, splat (i64 160)
  %992 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %989, 0
  %993 = insertvalue { <8 x ptr>, <8 x i64> } %992, <8 x i64> %991, 1
  %994 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %995 = extractvalue { <8 x ptr>, <8 x i64> } %993, 1
  %996 = extractelement <8 x ptr> %994, i32 0
  %997 = extractelement <8 x i64> %995, i32 0
  %998 = sub i64 %997, 0
  %999 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1000 = select i1 %999, i64 %998, i64 0
  %private.contiguous.address519 = getelementptr i8, ptr %996, i64 %1000
  %private.contiguous.preserve520 = load <8 x float>, ptr %private.contiguous.address519, align 4
  %1001 = select <8 x i1> %71, <8 x float> %904, <8 x float> %private.contiguous.preserve520
  store <8 x float> %1001, ptr %private.contiguous.address519, align 4
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1004 = add <8 x i64> %1003, splat (i64 192)
  %1005 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1002, 0
  %1006 = insertvalue { <8 x ptr>, <8 x i64> } %1005, <8 x i64> %1004, 1
  %1007 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1008 = extractvalue { <8 x ptr>, <8 x i64> } %1006, 1
  %1009 = extractelement <8 x ptr> %1007, i32 0
  %1010 = extractelement <8 x i64> %1008, i32 0
  %1011 = sub i64 %1010, 0
  %1012 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1013 = select i1 %1012, i64 %1011, i64 0
  %private.contiguous.address521 = getelementptr i8, ptr %1009, i64 %1013
  %private.contiguous.preserve522 = load <8 x float>, ptr %private.contiguous.address521, align 4
  %1014 = select <8 x i1> %71, <8 x float> %905, <8 x float> %private.contiguous.preserve522
  store <8 x float> %1014, ptr %private.contiguous.address521, align 4
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1017 = add <8 x i64> %1016, splat (i64 224)
  %1018 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1015, 0
  %1019 = insertvalue { <8 x ptr>, <8 x i64> } %1018, <8 x i64> %1017, 1
  %1020 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1021 = extractvalue { <8 x ptr>, <8 x i64> } %1019, 1
  %1022 = extractelement <8 x ptr> %1020, i32 0
  %1023 = extractelement <8 x i64> %1021, i32 0
  %1024 = sub i64 %1023, 0
  %1025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1026 = select i1 %1025, i64 %1024, i64 0
  %private.contiguous.address523 = getelementptr i8, ptr %1022, i64 %1026
  %private.contiguous.preserve524 = load <8 x float>, ptr %private.contiguous.address523, align 4
  %1027 = select <8 x i1> %71, <8 x float> %906, <8 x float> %private.contiguous.preserve524
  store <8 x float> %1027, ptr %private.contiguous.address523, align 4
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1030 = add <8 x i64> %1029, splat (i64 256)
  %1031 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1028, 0
  %1032 = insertvalue { <8 x ptr>, <8 x i64> } %1031, <8 x i64> %1030, 1
  %1033 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1034 = extractvalue { <8 x ptr>, <8 x i64> } %1032, 1
  %1035 = extractelement <8 x ptr> %1033, i32 0
  %1036 = extractelement <8 x i64> %1034, i32 0
  %1037 = sub i64 %1036, 0
  %1038 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1039 = select i1 %1038, i64 %1037, i64 0
  %private.contiguous.address525 = getelementptr i8, ptr %1035, i64 %1039
  %private.contiguous.preserve526 = load <8 x float>, ptr %private.contiguous.address525, align 4
  %1040 = select <8 x i1> %71, <8 x float> %907, <8 x float> %private.contiguous.preserve526
  store <8 x float> %1040, ptr %private.contiguous.address525, align 4
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1043 = add <8 x i64> %1042, splat (i64 288)
  %1044 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1041, 0
  %1045 = insertvalue { <8 x ptr>, <8 x i64> } %1044, <8 x i64> %1043, 1
  %1046 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1047 = extractvalue { <8 x ptr>, <8 x i64> } %1045, 1
  %1048 = extractelement <8 x ptr> %1046, i32 0
  %1049 = extractelement <8 x i64> %1047, i32 0
  %1050 = sub i64 %1049, 0
  %1051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1052 = select i1 %1051, i64 %1050, i64 0
  %private.contiguous.address527 = getelementptr i8, ptr %1048, i64 %1052
  %private.contiguous.preserve528 = load <8 x float>, ptr %private.contiguous.address527, align 4
  %1053 = select <8 x i1> %71, <8 x float> %908, <8 x float> %private.contiguous.preserve528
  store <8 x float> %1053, ptr %private.contiguous.address527, align 4
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1056 = add <8 x i64> %1055, splat (i64 320)
  %1057 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1054, 0
  %1058 = insertvalue { <8 x ptr>, <8 x i64> } %1057, <8 x i64> %1056, 1
  %1059 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1060 = extractvalue { <8 x ptr>, <8 x i64> } %1058, 1
  %1061 = extractelement <8 x ptr> %1059, i32 0
  %1062 = extractelement <8 x i64> %1060, i32 0
  %1063 = sub i64 %1062, 0
  %1064 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1065 = select i1 %1064, i64 %1063, i64 0
  %private.contiguous.address529 = getelementptr i8, ptr %1061, i64 %1065
  %private.contiguous.preserve530 = load <8 x float>, ptr %private.contiguous.address529, align 4
  %1066 = select <8 x i1> %71, <8 x float> %909, <8 x float> %private.contiguous.preserve530
  store <8 x float> %1066, ptr %private.contiguous.address529, align 4
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1069 = add <8 x i64> %1068, splat (i64 352)
  %1070 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1067, 0
  %1071 = insertvalue { <8 x ptr>, <8 x i64> } %1070, <8 x i64> %1069, 1
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1073 = extractvalue { <8 x ptr>, <8 x i64> } %1071, 1
  %1074 = extractelement <8 x ptr> %1072, i32 0
  %1075 = extractelement <8 x i64> %1073, i32 0
  %1076 = sub i64 %1075, 0
  %1077 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1078 = select i1 %1077, i64 %1076, i64 0
  %private.contiguous.address531 = getelementptr i8, ptr %1074, i64 %1078
  %private.contiguous.preserve532 = load <8 x float>, ptr %private.contiguous.address531, align 4
  %1079 = select <8 x i1> %71, <8 x float> %910, <8 x float> %private.contiguous.preserve532
  store <8 x float> %1079, ptr %private.contiguous.address531, align 4
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1082 = add <8 x i64> %1081, splat (i64 384)
  %1083 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1080, 0
  %1084 = insertvalue { <8 x ptr>, <8 x i64> } %1083, <8 x i64> %1082, 1
  %1085 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1086 = extractvalue { <8 x ptr>, <8 x i64> } %1084, 1
  %1087 = extractelement <8 x ptr> %1085, i32 0
  %1088 = extractelement <8 x i64> %1086, i32 0
  %1089 = sub i64 %1088, 0
  %1090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1091 = select i1 %1090, i64 %1089, i64 0
  %private.contiguous.address533 = getelementptr i8, ptr %1087, i64 %1091
  %private.contiguous.preserve534 = load <8 x float>, ptr %private.contiguous.address533, align 4
  %1092 = select <8 x i1> %71, <8 x float> %911, <8 x float> %private.contiguous.preserve534
  store <8 x float> %1092, ptr %private.contiguous.address533, align 4
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1095 = add <8 x i64> %1094, splat (i64 416)
  %1096 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1093, 0
  %1097 = insertvalue { <8 x ptr>, <8 x i64> } %1096, <8 x i64> %1095, 1
  %1098 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1099 = extractvalue { <8 x ptr>, <8 x i64> } %1097, 1
  %1100 = extractelement <8 x ptr> %1098, i32 0
  %1101 = extractelement <8 x i64> %1099, i32 0
  %1102 = sub i64 %1101, 0
  %1103 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1104 = select i1 %1103, i64 %1102, i64 0
  %private.contiguous.address535 = getelementptr i8, ptr %1100, i64 %1104
  %private.contiguous.preserve536 = load <8 x float>, ptr %private.contiguous.address535, align 4
  %1105 = select <8 x i1> %71, <8 x float> %912, <8 x float> %private.contiguous.preserve536
  store <8 x float> %1105, ptr %private.contiguous.address535, align 4
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1108 = add <8 x i64> %1107, splat (i64 448)
  %1109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1106, 0
  %1110 = insertvalue { <8 x ptr>, <8 x i64> } %1109, <8 x i64> %1108, 1
  %1111 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1112 = extractvalue { <8 x ptr>, <8 x i64> } %1110, 1
  %1113 = extractelement <8 x ptr> %1111, i32 0
  %1114 = extractelement <8 x i64> %1112, i32 0
  %1115 = sub i64 %1114, 0
  %1116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1117 = select i1 %1116, i64 %1115, i64 0
  %private.contiguous.address537 = getelementptr i8, ptr %1113, i64 %1117
  %private.contiguous.preserve538 = load <8 x float>, ptr %private.contiguous.address537, align 4
  %1118 = select <8 x i1> %71, <8 x float> %913, <8 x float> %private.contiguous.preserve538
  store <8 x float> %1118, ptr %private.contiguous.address537, align 4
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1121 = add <8 x i64> %1120, splat (i64 480)
  %1122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1119, 0
  %1123 = insertvalue { <8 x ptr>, <8 x i64> } %1122, <8 x i64> %1121, 1
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1125 = extractvalue { <8 x ptr>, <8 x i64> } %1123, 1
  %1126 = extractelement <8 x ptr> %1124, i32 0
  %1127 = extractelement <8 x i64> %1125, i32 0
  %1128 = sub i64 %1127, 0
  %1129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1130 = select i1 %1129, i64 %1128, i64 0
  %private.contiguous.address539 = getelementptr i8, ptr %1126, i64 %1130
  %private.contiguous.preserve540 = load <8 x float>, ptr %private.contiguous.address539, align 4
  %1131 = select <8 x i1> %71, <8 x float> %914, <8 x float> %private.contiguous.preserve540
  store <8 x float> %1131, ptr %private.contiguous.address539, align 4
  %.state541 = load <8 x float>, ptr %.slot36, align 32
  %1132 = fmul <8 x float> %.state541, %native.exp
  %1133 = load <8 x float>, ptr %.spill99, align 32
  %1134 = select <8 x i1> %71, <8 x float> %1132, <8 x float> %1133
  store <8 x float> %1134, ptr %.spill99, align 32
  store i64 0, ptr %.slot100, align 4
  %1135 = load <8 x float>, ptr %.slot101, align 32
  %1136 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1135
  store <8 x float> %1136, ptr %.slot101, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state542 = load i64, ptr %.slot100, align 4
  %1137 = icmp slt i64 %.state542, 16
  br i1 %1137, label %direct.true543, label %direct.false544

direct.schedule.26:                               ; preds = %direct.true543
  %.state545 = load i64, ptr %.slot100, align 4
  %1138 = sdiv i64 %.state545, 1
  %.spill.load546 = load i64, ptr %.spill31, align 4
  %1139 = mul i64 %.spill.load546, 1
  %1140 = add i64 %1139, 0
  %1141 = mul i64 %1140, 1
  %1142 = add i64 %1141, 0
  %1143 = mul i64 %1142, 16
  %1144 = add i64 %1143, %1138
  %tile_snapshot.spill.load547 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 1
  %.splatinsert548 = insertelement <8 x i64> poison, i64 %1144, i64 0
  %.splat549 = shufflevector <8 x i64> %.splatinsert548, <8 x i64> poison, <8 x i32> zeroinitializer
  %1147 = mul <8 x i64> %.splat549, splat (i64 32)
  %1148 = add <8 x i64> %1146, %1147
  %1149 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1145, 0
  %1150 = insertvalue { <8 x ptr>, <8 x i64> } %1149, <8 x i64> %1148, 1
  %1151 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1152 = extractvalue { <8 x ptr>, <8 x i64> } %1150, 1
  %1153 = extractelement <8 x ptr> %1151, i32 0
  %1154 = extractelement <8 x i64> %1152, i32 0
  %1155 = sub i64 %1154, 0
  %1156 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1157 = select i1 %1156, i64 %1155, i64 0
  %private.contiguous.address550 = getelementptr i8, ptr %1153, i64 %1157
  %private.contiguous.load551 = load <8 x float>, ptr %private.contiguous.address550, align 4
  %1158 = select <8 x i1> %71, <8 x float> %private.contiguous.load551, <8 x float> zeroinitializer
  %.state552 = load <8 x float>, ptr %.slot101, align 32
  %1159 = fadd <8 x float> %.state552, %1158
  %.state553 = load i64, ptr %.slot100, align 4
  %1160 = add i64 %.state553, 1
  store i64 %1160, ptr %.slot100, align 4
  %1161 = load <8 x float>, ptr %.slot101, align 32
  %1162 = select <8 x i1> %71, <8 x float> %1159, <8 x float> %1161
  store <8 x float> %1162, ptr %.slot101, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false544
  %.spill.load554 = load <8 x float>, ptr %.spill99, align 32
  %.state555 = load <8 x float>, ptr %.slot101, align 32
  %1163 = fadd <8 x float> %.spill.load554, %.state555
  %1164 = load <8 x float>, ptr %.spill102, align 32
  %1165 = select <8 x i1> %71, <8 x float> %1163, <8 x float> %1164
  store <8 x float> %1165, ptr %.spill102, align 32
  %1166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1168 = extractvalue { <8 x ptr>, <8 x i64> } %1166, 0
  %1169 = select <8 x i1> %71, <8 x ptr> %1167, <8 x ptr> %1168
  %1170 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %1166, 1
  %1172 = select <8 x i1> %71, <8 x i64> %1170, <8 x i64> %1171
  %1173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1169, 0
  %1174 = insertvalue { <8 x ptr>, <8 x i64> } %1173, <8 x i64> %1172, 1
  store { <8 x ptr>, <8 x i64> } %1174, ptr %tile_snapshot.spill103, align 64
  store i64 0, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.32, %direct.schedule.27
  %.state556 = load i64, ptr %.slot104, align 4
  %1175 = icmp slt i64 %.state556, 32
  br i1 %1175, label %direct.true557, label %direct.false558

direct.schedule.29:                               ; preds = %direct.true557
  %.state559 = load i64, ptr %.slot104, align 4
  %1176 = mul i64 %.state559, 4
  %1177 = add i64 0, %1176
  %1178 = add i64 %1177, 0
  store i64 %1178, ptr %.spill105, align 4
  %1179 = add i64 0, %1178
  %tile_snapshot.spill.load560 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load560, 0
  %1181 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load560, 1
  %.splatinsert561 = insertelement <8 x i64> poison, i64 %1179, i64 0
  %.splat562 = shufflevector <8 x i64> %.splatinsert561, <8 x i64> poison, <8 x i32> zeroinitializer
  %1182 = mul <8 x i64> %.splat562, splat (i64 32)
  %1183 = add <8 x i64> %1181, %1182
  %1184 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1180, 0
  %1185 = insertvalue { <8 x ptr>, <8 x i64> } %1184, <8 x i64> %1183, 1
  %1186 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1187 = extractvalue { <8 x ptr>, <8 x i64> } %1185, 1
  %1188 = extractelement <8 x ptr> %1186, i32 0
  %1189 = extractelement <8 x i64> %1187, i32 0
  %1190 = sub i64 %1189, 0
  %1191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1192 = select i1 %1191, i64 %1190, i64 0
  %private.contiguous.address563 = getelementptr i8, ptr %1188, i64 %1192
  %private.contiguous.load564 = load <8 x float>, ptr %private.contiguous.address563, align 4
  %1193 = select <8 x i1> %71, <8 x float> %private.contiguous.load564, <8 x float> zeroinitializer
  %.spill.load565 = load <8 x float>, ptr %.spill97, align 32
  %1194 = fmul <8 x float> %1193, %.spill.load565
  %1195 = add i64 %1177, 1
  store i64 %1195, ptr %.spill106, align 4
  %1196 = add i64 0, %1195
  %tile_snapshot.spill.load566 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load566, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load566, 1
  %.splatinsert567 = insertelement <8 x i64> poison, i64 %1196, i64 0
  %.splat568 = shufflevector <8 x i64> %.splatinsert567, <8 x i64> poison, <8 x i32> zeroinitializer
  %1199 = mul <8 x i64> %.splat568, splat (i64 32)
  %1200 = add <8 x i64> %1198, %1199
  %1201 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1197, 0
  %1202 = insertvalue { <8 x ptr>, <8 x i64> } %1201, <8 x i64> %1200, 1
  %1203 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1204 = extractvalue { <8 x ptr>, <8 x i64> } %1202, 1
  %1205 = extractelement <8 x ptr> %1203, i32 0
  %1206 = extractelement <8 x i64> %1204, i32 0
  %1207 = sub i64 %1206, 0
  %1208 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1209 = select i1 %1208, i64 %1207, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %1205, i64 %1209
  %private.contiguous.load570 = load <8 x float>, ptr %private.contiguous.address569, align 4
  %1210 = select <8 x i1> %71, <8 x float> %private.contiguous.load570, <8 x float> zeroinitializer
  %.spill.load571 = load <8 x float>, ptr %.spill97, align 32
  %1211 = fmul <8 x float> %1210, %.spill.load571
  %1212 = add i64 %1177, 2
  store i64 %1212, ptr %.spill107, align 4
  %1213 = add i64 0, %1212
  %tile_snapshot.spill.load572 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load572, 0
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load572, 1
  %.splatinsert573 = insertelement <8 x i64> poison, i64 %1213, i64 0
  %.splat574 = shufflevector <8 x i64> %.splatinsert573, <8 x i64> poison, <8 x i32> zeroinitializer
  %1216 = mul <8 x i64> %.splat574, splat (i64 32)
  %1217 = add <8 x i64> %1215, %1216
  %1218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1214, 0
  %1219 = insertvalue { <8 x ptr>, <8 x i64> } %1218, <8 x i64> %1217, 1
  %1220 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1221 = extractvalue { <8 x ptr>, <8 x i64> } %1219, 1
  %1222 = extractelement <8 x ptr> %1220, i32 0
  %1223 = extractelement <8 x i64> %1221, i32 0
  %1224 = sub i64 %1223, 0
  %1225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1226 = select i1 %1225, i64 %1224, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %1222, i64 %1226
  %private.contiguous.load576 = load <8 x float>, ptr %private.contiguous.address575, align 4
  %1227 = select <8 x i1> %71, <8 x float> %private.contiguous.load576, <8 x float> zeroinitializer
  %.spill.load577 = load <8 x float>, ptr %.spill97, align 32
  %1228 = fmul <8 x float> %1227, %.spill.load577
  %1229 = add i64 %1177, 3
  store i64 %1229, ptr %.spill108, align 4
  %1230 = add i64 0, %1229
  %tile_snapshot.spill.load578 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load578, 0
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load578, 1
  %.splatinsert579 = insertelement <8 x i64> poison, i64 %1230, i64 0
  %.splat580 = shufflevector <8 x i64> %.splatinsert579, <8 x i64> poison, <8 x i32> zeroinitializer
  %1233 = mul <8 x i64> %.splat580, splat (i64 32)
  %1234 = add <8 x i64> %1232, %1233
  %1235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1231, 0
  %1236 = insertvalue { <8 x ptr>, <8 x i64> } %1235, <8 x i64> %1234, 1
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1238 = extractvalue { <8 x ptr>, <8 x i64> } %1236, 1
  %1239 = extractelement <8 x ptr> %1237, i32 0
  %1240 = extractelement <8 x i64> %1238, i32 0
  %1241 = sub i64 %1240, 0
  %1242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1243 = select i1 %1242, i64 %1241, i64 0
  %private.contiguous.address581 = getelementptr i8, ptr %1239, i64 %1243
  %private.contiguous.load582 = load <8 x float>, ptr %private.contiguous.address581, align 4
  %1244 = select <8 x i1> %71, <8 x float> %private.contiguous.load582, <8 x float> zeroinitializer
  %.spill.load583 = load <8 x float>, ptr %.spill97, align 32
  %1245 = fmul <8 x float> %1244, %.spill.load583
  store i64 0, ptr %.slot109, align 4
  %1246 = load <8 x float>, ptr %.slot110, align 32
  %1247 = select <8 x i1> %71, <8 x float> %1194, <8 x float> %1246
  store <8 x float> %1247, ptr %.slot110, align 32
  %1248 = load <8 x float>, ptr %.slot111, align 32
  %1249 = select <8 x i1> %71, <8 x float> %1211, <8 x float> %1248
  store <8 x float> %1249, ptr %.slot111, align 32
  %1250 = load <8 x float>, ptr %.slot112, align 32
  %1251 = select <8 x i1> %71, <8 x float> %1228, <8 x float> %1250
  store <8 x float> %1251, ptr %.slot112, align 32
  %1252 = load <8 x float>, ptr %.slot113, align 32
  %1253 = select <8 x i1> %71, <8 x float> %1245, <8 x float> %1252
  store <8 x float> %1253, ptr %.slot113, align 32
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.31, %direct.schedule.29
  %.state584 = load i64, ptr %.slot109, align 4
  %1254 = icmp slt i64 %.state584, 16
  br i1 %1254, label %direct.true585, label %direct.false586

direct.schedule.31:                               ; preds = %direct.true585
  %.state587 = load i64, ptr %.slot109, align 4
  %1255 = add i64 0, %.state587
  %tile_snapshot.spill.load588 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %1256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load588, 0
  %1257 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load588, 1
  %.splatinsert589 = insertelement <8 x i64> poison, i64 %1255, i64 0
  %.splat590 = shufflevector <8 x i64> %.splatinsert589, <8 x i64> poison, <8 x i32> zeroinitializer
  %1258 = mul <8 x i64> %.splat590, splat (i64 32)
  %1259 = add <8 x i64> %1257, %1258
  %1260 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1256, 0
  %1261 = insertvalue { <8 x ptr>, <8 x i64> } %1260, <8 x i64> %1259, 1
  %1262 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %1261, 1
  %1264 = extractelement <8 x ptr> %1262, i32 0
  %1265 = extractelement <8 x i64> %1263, i32 0
  %1266 = sub i64 %1265, 0
  %1267 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1268 = select i1 %1267, i64 %1266, i64 0
  %private.contiguous.address591 = getelementptr i8, ptr %1264, i64 %1268
  %private.contiguous.load592 = load <8 x float>, ptr %private.contiguous.address591, align 4
  %1269 = select <8 x i1> %71, <8 x float> %private.contiguous.load592, <8 x float> zeroinitializer
  %1270 = mul i64 %1255, 128
  %.spill.load593 = load i64, ptr %.spill105, align 4
  %1271 = add i64 %1270, %.spill.load593
  %tile_snapshot.spill.load594 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1272 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load594, 0
  %1273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load594, 1
  %.splatinsert595 = insertelement <8 x i64> poison, i64 %1271, i64 0
  %.splat596 = shufflevector <8 x i64> %.splatinsert595, <8 x i64> poison, <8 x i32> zeroinitializer
  %1274 = mul <8 x i64> %.splat596, splat (i64 4)
  %1275 = add <8 x i64> %1273, %1274
  %1276 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1272, 0
  %1277 = insertvalue { <8 x ptr>, <8 x i64> } %1276, <8 x i64> %1275, 1
  %1278 = extractvalue { <8 x ptr>, <8 x i64> } %1277, 0
  %1279 = extractvalue { <8 x ptr>, <8 x i64> } %1277, 1
  %1280 = getelementptr i8, <8 x ptr> %1278, <8 x i64> %1279
  %1281 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1280, <8 x i1> %71, <8 x float> zeroinitializer)
  %1282 = fmul <8 x float> %1269, %1281
  %.state597 = load <8 x float>, ptr %.slot110, align 32
  %1283 = fadd <8 x float> %.state597, %1282
  %.spill.load598 = load i64, ptr %.spill106, align 4
  %1284 = add i64 %1270, %.spill.load598
  %tile_snapshot.spill.load599 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load599, 0
  %1286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load599, 1
  %.splatinsert600 = insertelement <8 x i64> poison, i64 %1284, i64 0
  %.splat601 = shufflevector <8 x i64> %.splatinsert600, <8 x i64> poison, <8 x i32> zeroinitializer
  %1287 = mul <8 x i64> %.splat601, splat (i64 4)
  %1288 = add <8 x i64> %1286, %1287
  %1289 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1285, 0
  %1290 = insertvalue { <8 x ptr>, <8 x i64> } %1289, <8 x i64> %1288, 1
  %1291 = extractvalue { <8 x ptr>, <8 x i64> } %1290, 0
  %1292 = extractvalue { <8 x ptr>, <8 x i64> } %1290, 1
  %1293 = getelementptr i8, <8 x ptr> %1291, <8 x i64> %1292
  %1294 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1293, <8 x i1> %71, <8 x float> zeroinitializer)
  %1295 = fmul <8 x float> %1269, %1294
  %.state602 = load <8 x float>, ptr %.slot111, align 32
  %1296 = fadd <8 x float> %.state602, %1295
  %.spill.load603 = load i64, ptr %.spill107, align 4
  %1297 = add i64 %1270, %.spill.load603
  %tile_snapshot.spill.load604 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1298 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load604, 0
  %1299 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load604, 1
  %.splatinsert605 = insertelement <8 x i64> poison, i64 %1297, i64 0
  %.splat606 = shufflevector <8 x i64> %.splatinsert605, <8 x i64> poison, <8 x i32> zeroinitializer
  %1300 = mul <8 x i64> %.splat606, splat (i64 4)
  %1301 = add <8 x i64> %1299, %1300
  %1302 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1298, 0
  %1303 = insertvalue { <8 x ptr>, <8 x i64> } %1302, <8 x i64> %1301, 1
  %1304 = extractvalue { <8 x ptr>, <8 x i64> } %1303, 0
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %1303, 1
  %1306 = getelementptr i8, <8 x ptr> %1304, <8 x i64> %1305
  %1307 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1306, <8 x i1> %71, <8 x float> zeroinitializer)
  %1308 = fmul <8 x float> %1269, %1307
  %.state607 = load <8 x float>, ptr %.slot112, align 32
  %1309 = fadd <8 x float> %.state607, %1308
  %.spill.load608 = load i64, ptr %.spill108, align 4
  %1310 = add i64 %1270, %.spill.load608
  %tile_snapshot.spill.load609 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load609, 0
  %1312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load609, 1
  %.splatinsert610 = insertelement <8 x i64> poison, i64 %1310, i64 0
  %.splat611 = shufflevector <8 x i64> %.splatinsert610, <8 x i64> poison, <8 x i32> zeroinitializer
  %1313 = mul <8 x i64> %.splat611, splat (i64 4)
  %1314 = add <8 x i64> %1312, %1313
  %1315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1311, 0
  %1316 = insertvalue { <8 x ptr>, <8 x i64> } %1315, <8 x i64> %1314, 1
  %1317 = extractvalue { <8 x ptr>, <8 x i64> } %1316, 0
  %1318 = extractvalue { <8 x ptr>, <8 x i64> } %1316, 1
  %1319 = getelementptr i8, <8 x ptr> %1317, <8 x i64> %1318
  %1320 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1319, <8 x i1> %71, <8 x float> zeroinitializer)
  %1321 = fmul <8 x float> %1269, %1320
  %.state612 = load <8 x float>, ptr %.slot113, align 32
  %1322 = fadd <8 x float> %.state612, %1321
  %.state613 = load i64, ptr %.slot109, align 4
  %1323 = add i64 %.state613, 1
  store i64 %1323, ptr %.slot109, align 4
  %1324 = load <8 x float>, ptr %.slot110, align 32
  %1325 = select <8 x i1> %71, <8 x float> %1283, <8 x float> %1324
  store <8 x float> %1325, ptr %.slot110, align 32
  %1326 = load <8 x float>, ptr %.slot111, align 32
  %1327 = select <8 x i1> %71, <8 x float> %1296, <8 x float> %1326
  store <8 x float> %1327, ptr %.slot111, align 32
  %1328 = load <8 x float>, ptr %.slot112, align 32
  %1329 = select <8 x i1> %71, <8 x float> %1309, <8 x float> %1328
  store <8 x float> %1329, ptr %.slot112, align 32
  %1330 = load <8 x float>, ptr %.slot113, align 32
  %1331 = select <8 x i1> %71, <8 x float> %1322, <8 x float> %1330
  store <8 x float> %1331, ptr %.slot113, align 32
  br label %direct.schedule.30

direct.schedule.32:                               ; preds = %direct.false586
  %tile_snapshot.spill.load614 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1332 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 0
  %1333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 1
  %.spill.load615 = load i64, ptr %.spill105, align 4
  %.splatinsert616 = insertelement <8 x i64> poison, i64 %.spill.load615, i64 0
  %.splat617 = shufflevector <8 x i64> %.splatinsert616, <8 x i64> poison, <8 x i32> zeroinitializer
  %1334 = mul <8 x i64> %.splat617, splat (i64 32)
  %1335 = add <8 x i64> %1333, %1334
  %1336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1332, 0
  %1337 = insertvalue { <8 x ptr>, <8 x i64> } %1336, <8 x i64> %1335, 1
  %.state618 = load <8 x float>, ptr %.slot110, align 32
  %1338 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1339 = extractvalue { <8 x ptr>, <8 x i64> } %1337, 1
  %1340 = extractelement <8 x ptr> %1338, i32 0
  %1341 = extractelement <8 x i64> %1339, i32 0
  %1342 = sub i64 %1341, 0
  %1343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1344 = select i1 %1343, i64 %1342, i64 0
  %private.contiguous.address619 = getelementptr i8, ptr %1340, i64 %1344
  %private.contiguous.preserve620 = load <8 x float>, ptr %private.contiguous.address619, align 4
  %1345 = select <8 x i1> %71, <8 x float> %.state618, <8 x float> %private.contiguous.preserve620
  store <8 x float> %1345, ptr %private.contiguous.address619, align 4
  %tile_snapshot.spill.load621 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1346 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load621, 0
  %1347 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load621, 1
  %.spill.load622 = load i64, ptr %.spill106, align 4
  %.splatinsert623 = insertelement <8 x i64> poison, i64 %.spill.load622, i64 0
  %.splat624 = shufflevector <8 x i64> %.splatinsert623, <8 x i64> poison, <8 x i32> zeroinitializer
  %1348 = mul <8 x i64> %.splat624, splat (i64 32)
  %1349 = add <8 x i64> %1347, %1348
  %1350 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1346, 0
  %1351 = insertvalue { <8 x ptr>, <8 x i64> } %1350, <8 x i64> %1349, 1
  %.state625 = load <8 x float>, ptr %.slot111, align 32
  %1352 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1353 = extractvalue { <8 x ptr>, <8 x i64> } %1351, 1
  %1354 = extractelement <8 x ptr> %1352, i32 0
  %1355 = extractelement <8 x i64> %1353, i32 0
  %1356 = sub i64 %1355, 0
  %1357 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1358 = select i1 %1357, i64 %1356, i64 0
  %private.contiguous.address626 = getelementptr i8, ptr %1354, i64 %1358
  %private.contiguous.preserve627 = load <8 x float>, ptr %private.contiguous.address626, align 4
  %1359 = select <8 x i1> %71, <8 x float> %.state625, <8 x float> %private.contiguous.preserve627
  store <8 x float> %1359, ptr %private.contiguous.address626, align 4
  %tile_snapshot.spill.load628 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 0
  %1361 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 1
  %.spill.load629 = load i64, ptr %.spill107, align 4
  %.splatinsert630 = insertelement <8 x i64> poison, i64 %.spill.load629, i64 0
  %.splat631 = shufflevector <8 x i64> %.splatinsert630, <8 x i64> poison, <8 x i32> zeroinitializer
  %1362 = mul <8 x i64> %.splat631, splat (i64 32)
  %1363 = add <8 x i64> %1361, %1362
  %1364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1360, 0
  %1365 = insertvalue { <8 x ptr>, <8 x i64> } %1364, <8 x i64> %1363, 1
  %.state632 = load <8 x float>, ptr %.slot112, align 32
  %1366 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1367 = extractvalue { <8 x ptr>, <8 x i64> } %1365, 1
  %1368 = extractelement <8 x ptr> %1366, i32 0
  %1369 = extractelement <8 x i64> %1367, i32 0
  %1370 = sub i64 %1369, 0
  %1371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1372 = select i1 %1371, i64 %1370, i64 0
  %private.contiguous.address633 = getelementptr i8, ptr %1368, i64 %1372
  %private.contiguous.preserve634 = load <8 x float>, ptr %private.contiguous.address633, align 4
  %1373 = select <8 x i1> %71, <8 x float> %.state632, <8 x float> %private.contiguous.preserve634
  store <8 x float> %1373, ptr %private.contiguous.address633, align 4
  %tile_snapshot.spill.load635 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load635, 0
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load635, 1
  %.spill.load636 = load i64, ptr %.spill108, align 4
  %.splatinsert637 = insertelement <8 x i64> poison, i64 %.spill.load636, i64 0
  %.splat638 = shufflevector <8 x i64> %.splatinsert637, <8 x i64> poison, <8 x i32> zeroinitializer
  %1376 = mul <8 x i64> %.splat638, splat (i64 32)
  %1377 = add <8 x i64> %1375, %1376
  %1378 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1374, 0
  %1379 = insertvalue { <8 x ptr>, <8 x i64> } %1378, <8 x i64> %1377, 1
  %.state639 = load <8 x float>, ptr %.slot113, align 32
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %1379, 1
  %1382 = extractelement <8 x ptr> %1380, i32 0
  %1383 = extractelement <8 x i64> %1381, i32 0
  %1384 = sub i64 %1383, 0
  %1385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1386 = select i1 %1385, i64 %1384, i64 0
  %private.contiguous.address640 = getelementptr i8, ptr %1382, i64 %1386
  %private.contiguous.preserve641 = load <8 x float>, ptr %private.contiguous.address640, align 4
  %1387 = select <8 x i1> %71, <8 x float> %.state639, <8 x float> %private.contiguous.preserve641
  store <8 x float> %1387, ptr %private.contiguous.address640, align 4
  %.state642 = load i64, ptr %.slot104, align 4
  %1388 = add i64 %.state642, 1
  store i64 %1388, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.schedule.33:                               ; preds = %direct.false558
  store i64 0, ptr %.slot114, align 4
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state643 = load i64, ptr %.slot114, align 4
  %1389 = icmp slt i64 %.state643, 128
  br i1 %1389, label %direct.true644, label %direct.false645

direct.schedule.35:                               ; preds = %direct.true644
  %tile_snapshot.spill.load646 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load646, 0
  %1391 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load646, 1
  %.state647 = load i64, ptr %.slot114, align 4
  %.splatinsert648 = insertelement <8 x i64> poison, i64 %.state647, i64 0
  %.splat649 = shufflevector <8 x i64> %.splatinsert648, <8 x i64> poison, <8 x i32> zeroinitializer
  %1392 = mul <8 x i64> %.splat649, splat (i64 32)
  %1393 = add <8 x i64> %1391, %1392
  %1394 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1390, 0
  %1395 = insertvalue { <8 x ptr>, <8 x i64> } %1394, <8 x i64> %1393, 1
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1397 = extractvalue { <8 x ptr>, <8 x i64> } %1395, 1
  %1398 = extractelement <8 x ptr> %1396, i32 0
  %1399 = extractelement <8 x i64> %1397, i32 0
  %1400 = sub i64 %1399, 0
  %1401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1402 = select i1 %1401, i64 %1400, i64 0
  %private.contiguous.address650 = getelementptr i8, ptr %1398, i64 %1402
  %private.contiguous.load651 = load <8 x float>, ptr %private.contiguous.address650, align 4
  %1403 = select <8 x i1> %71, <8 x float> %private.contiguous.load651, <8 x float> zeroinitializer
  %tile_snapshot.spill.load652 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 0
  %1405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 1
  %.state653 = load i64, ptr %.slot114, align 4
  %.splatinsert654 = insertelement <8 x i64> poison, i64 %.state653, i64 0
  %.splat655 = shufflevector <8 x i64> %.splatinsert654, <8 x i64> poison, <8 x i32> zeroinitializer
  %1406 = mul <8 x i64> %.splat655, splat (i64 32)
  %1407 = add <8 x i64> %1405, %1406
  %1408 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1404, 0
  %1409 = insertvalue { <8 x ptr>, <8 x i64> } %1408, <8 x i64> %1407, 1
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1411 = extractvalue { <8 x ptr>, <8 x i64> } %1409, 1
  %1412 = extractelement <8 x ptr> %1410, i32 0
  %1413 = extractelement <8 x i64> %1411, i32 0
  %1414 = sub i64 %1413, 0
  %1415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1416 = select i1 %1415, i64 %1414, i64 0
  %private.contiguous.address656 = getelementptr i8, ptr %1412, i64 %1416
  %private.contiguous.preserve657 = load <8 x float>, ptr %private.contiguous.address656, align 4
  %1417 = select <8 x i1> %71, <8 x float> %1403, <8 x float> %private.contiguous.preserve657
  store <8 x float> %1417, ptr %private.contiguous.address656, align 4
  %.state658 = load i64, ptr %.slot114, align 4
  %1418 = add i64 %.state658, 1
  store i64 %1418, ptr %.slot114, align 4
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false645
  store i64 0, ptr %.slot115, align 4
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state659 = load i64, ptr %.slot115, align 4
  %1419 = icmp slt i64 %.state659, 128
  br i1 %1419, label %direct.true660, label %direct.false661

direct.schedule.38:                               ; preds = %direct.true660
  %tile_snapshot.spill.load662 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load662, 0
  %1421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load662, 1
  %.state663 = load i64, ptr %.slot115, align 4
  %.splatinsert664 = insertelement <8 x i64> poison, i64 %.state663, i64 0
  %.splat665 = shufflevector <8 x i64> %.splatinsert664, <8 x i64> poison, <8 x i32> zeroinitializer
  %1422 = mul <8 x i64> %.splat665, splat (i64 32)
  %1423 = add <8 x i64> %1421, %1422
  %1424 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1420, 0
  %1425 = insertvalue { <8 x ptr>, <8 x i64> } %1424, <8 x i64> %1423, 1
  %1426 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %1425, 1
  %1428 = extractelement <8 x ptr> %1426, i32 0
  %1429 = extractelement <8 x i64> %1427, i32 0
  %1430 = sub i64 %1429, 0
  %1431 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1432 = select i1 %1431, i64 %1430, i64 0
  %private.contiguous.address666 = getelementptr i8, ptr %1428, i64 %1432
  %private.contiguous.load667 = load <8 x float>, ptr %private.contiguous.address666, align 4
  %1433 = select <8 x i1> %71, <8 x float> %private.contiguous.load667, <8 x float> zeroinitializer
  %tile_snapshot.spill.load668 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load668, 0
  %1435 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load668, 1
  %.state669 = load i64, ptr %.slot115, align 4
  %.splatinsert670 = insertelement <8 x i64> poison, i64 %.state669, i64 0
  %.splat671 = shufflevector <8 x i64> %.splatinsert670, <8 x i64> poison, <8 x i32> zeroinitializer
  %1436 = mul <8 x i64> %.splat671, splat (i64 32)
  %1437 = add <8 x i64> %1435, %1436
  %1438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1434, 0
  %1439 = insertvalue { <8 x ptr>, <8 x i64> } %1438, <8 x i64> %1437, 1
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %1439, 1
  %1442 = extractelement <8 x ptr> %1440, i32 0
  %1443 = extractelement <8 x i64> %1441, i32 0
  %1444 = sub i64 %1443, 0
  %1445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1446 = select i1 %1445, i64 %1444, i64 0
  %private.contiguous.address672 = getelementptr i8, ptr %1442, i64 %1446
  %private.contiguous.preserve673 = load <8 x float>, ptr %private.contiguous.address672, align 4
  %1447 = select <8 x i1> %71, <8 x float> %1433, <8 x float> %private.contiguous.preserve673
  store <8 x float> %1447, ptr %private.contiguous.address672, align 4
  %.state674 = load i64, ptr %.slot115, align 4
  %1448 = add i64 %.state674, 1
  store i64 %1448, ptr %.slot115, align 4
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false661
  %.state675 = load i64, ptr %.slot34, align 4
  %1449 = add i64 %.state675, 1
  %.spill.load676 = load <8 x float>, ptr %.spill96, align 32
  %.spill.load677 = load <8 x float>, ptr %.spill102, align 32
  store i64 %1449, ptr %.slot34, align 4
  %1450 = load <8 x float>, ptr %.slot35, align 32
  %1451 = select <8 x i1> %71, <8 x float> %.spill.load676, <8 x float> %1450
  store <8 x float> %1451, ptr %.slot35, align 32
  %1452 = load <8 x float>, ptr %.slot36, align 32
  %1453 = select <8 x i1> %71, <8 x float> %.spill.load677, <8 x float> %1452
  store <8 x float> %1453, ptr %.slot36, align 32
  br label %direct.schedule.4

direct.schedule.40:                               ; preds = %direct.false182
  store i64 0, ptr %.slot116, align 4
  br label %direct.schedule.41

direct.schedule.41:                               ; preds = %direct.schedule.44, %direct.schedule.40
  %.state678 = load i64, ptr %.slot116, align 4
  %1454 = icmp slt i64 %.state678, 2048
  br i1 %1454, label %direct.true679, label %direct.false680

direct.schedule.42:                               ; preds = %direct.true679
  %.state681 = load i64, ptr %.slot116, align 4
  %1455 = srem i64 %.state681, 128
  %.state682 = load i64, ptr %.slot116, align 4
  %1456 = sdiv i64 %.state682, 128
  %.spill.load683 = load i64, ptr %.spill29, align 4
  %1457 = add i64 %.spill.load683, 0
  %.spill.load684 = load <8 x i64>, ptr %.spill30, align 64
  %1458 = add <8 x i64> %.spill.load684, zeroinitializer
  %1459 = mul i64 %1457, 4
  %.splatinsert685 = insertelement <8 x i64> poison, i64 %1459, i64 0
  %.splat686 = shufflevector <8 x i64> %.splatinsert685, <8 x i64> poison, <8 x i32> zeroinitializer
  %1460 = add <8 x i64> %.splat686, %1458
  %.spill.load687 = load i64, ptr %.spill37, align 4
  %1461 = add i64 %.spill.load687, %1456
  %1462 = mul <8 x i64> %1460, splat (i64 8193)
  %.splatinsert688 = insertelement <8 x i64> poison, i64 %1461, i64 0
  %.splat689 = shufflevector <8 x i64> %.splatinsert688, <8 x i64> poison, <8 x i32> zeroinitializer
  %1463 = add <8 x i64> %1462, %.splat689
  %1464 = icmp sge i64 %1461, 0
  %1465 = and i1 true, %1464
  %1466 = icmp slt i64 %1461, 8193
  %1467 = and i1 %1465, %1466
  %1468 = add i64 0, %1455
  %1469 = mul <8 x i64> %1463, splat (i64 128)
  %.splatinsert690 = insertelement <8 x i64> poison, i64 %1468, i64 0
  %.splat691 = shufflevector <8 x i64> %.splatinsert690, <8 x i64> poison, <8 x i32> zeroinitializer
  %1470 = add <8 x i64> %1469, %.splat691
  %1471 = load <8 x i64>, ptr %.spill117, align 64
  %1472 = select <8 x i1> %71, <8 x i64> %1470, <8 x i64> %1471
  store <8 x i64> %1472, ptr %.spill117, align 64
  br i1 %1467, label %direct.true692, label %direct.false693

direct.schedule.43:                               ; preds = %direct.true692
  %.spill.load694 = load <8 x i64>, ptr %.spill117, align 64
  %1473 = extractvalue { ptr, i64 } %41, 0
  %1474 = mul <8 x i64> %.spill.load694, splat (i64 4)
  %1475 = getelementptr i8, ptr %1473, <8 x i64> %1474
  %1476 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1475, <8 x i1> %71, <8 x float> zeroinitializer)
  %1477 = load <8 x float>, ptr %.slot118, align 32
  %1478 = select <8 x i1> %71, <8 x float> %1476, <8 x float> %1477
  store <8 x float> %1478, ptr %.slot118, align 32
  br label %direct.schedule.44

direct.schedule.44:                               ; preds = %direct.schedule.43, %direct.false693
  %tile_snapshot.spill.load695 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load695, 0
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load695, 1
  %.state696 = load i64, ptr %.slot116, align 4
  %.splatinsert697 = insertelement <8 x i64> poison, i64 %.state696, i64 0
  %.splat698 = shufflevector <8 x i64> %.splatinsert697, <8 x i64> poison, <8 x i32> zeroinitializer
  %1481 = mul <8 x i64> %.splat698, splat (i64 4)
  %1482 = add <8 x i64> %1480, %1481
  %1483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1479, 0
  %1484 = insertvalue { <8 x ptr>, <8 x i64> } %1483, <8 x i64> %1482, 1
  %.state699 = load <8 x float>, ptr %.slot118, align 32
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %1484, 0
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %1484, 1
  %1487 = getelementptr i8, <8 x ptr> %1485, <8 x i64> %1486
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state699, <8 x ptr> align 1 %1487, <8 x i1> %71)
  %.state700 = load i64, ptr %.slot116, align 4
  %1488 = add i64 %.state700, 1
  store i64 %1488, ptr %.slot116, align 4
  br label %direct.schedule.41

direct.schedule.45:                               ; preds = %direct.false156
  store i64 0, ptr %.slot119, align 4
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.49, %direct.schedule.45
  %.state701 = load i64, ptr %.slot119, align 4
  %1489 = icmp slt i64 %.state701, 2048
  br i1 %1489, label %direct.true702, label %direct.false703

direct.schedule.47:                               ; preds = %direct.true702
  %.state704 = load i64, ptr %.slot119, align 4
  %1490 = srem i64 %.state704, 128
  %.state705 = load i64, ptr %.slot119, align 4
  %1491 = sdiv i64 %.state705, 128
  %.spill.load706 = load i64, ptr %.spill29, align 4
  %1492 = add i64 %.spill.load706, 0
  %.spill.load707 = load <8 x i64>, ptr %.spill30, align 64
  %1493 = add <8 x i64> %.spill.load707, zeroinitializer
  %1494 = mul i64 %1492, 4
  %.splatinsert708 = insertelement <8 x i64> poison, i64 %1494, i64 0
  %.splat709 = shufflevector <8 x i64> %.splatinsert708, <8 x i64> poison, <8 x i32> zeroinitializer
  %1495 = add <8 x i64> %.splat709, %1493
  %.spill.load710 = load i64, ptr %.spill37, align 4
  %1496 = add i64 %.spill.load710, %1491
  %1497 = mul <8 x i64> %1495, splat (i64 8193)
  %.splatinsert711 = insertelement <8 x i64> poison, i64 %1496, i64 0
  %.splat712 = shufflevector <8 x i64> %.splatinsert711, <8 x i64> poison, <8 x i32> zeroinitializer
  %1498 = add <8 x i64> %1497, %.splat712
  %1499 = icmp sge i64 %1496, 0
  %1500 = and i1 true, %1499
  %1501 = icmp slt i64 %1496, 8193
  %1502 = and i1 %1500, %1501
  %1503 = add i64 0, %1490
  %1504 = mul <8 x i64> %1498, splat (i64 128)
  %.splatinsert713 = insertelement <8 x i64> poison, i64 %1503, i64 0
  %.splat714 = shufflevector <8 x i64> %.splatinsert713, <8 x i64> poison, <8 x i32> zeroinitializer
  %1505 = add <8 x i64> %1504, %.splat714
  %1506 = load <8 x i64>, ptr %.spill120, align 64
  %1507 = select <8 x i1> %71, <8 x i64> %1505, <8 x i64> %1506
  store <8 x i64> %1507, ptr %.spill120, align 64
  br i1 %1502, label %direct.true715, label %direct.false716

direct.schedule.48:                               ; preds = %direct.true715
  %.spill.load717 = load <8 x i64>, ptr %.spill120, align 64
  %1508 = extractvalue { ptr, i64 } %35, 0
  %1509 = mul <8 x i64> %.spill.load717, splat (i64 4)
  %1510 = getelementptr i8, ptr %1508, <8 x i64> %1509
  %1511 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1510, <8 x i1> %71, <8 x float> zeroinitializer)
  %1512 = load <8 x float>, ptr %.slot121, align 32
  %1513 = select <8 x i1> %71, <8 x float> %1511, <8 x float> %1512
  store <8 x float> %1513, ptr %.slot121, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.48, %direct.false716
  %tile_snapshot.spill.load718 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %1514 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load718, 0
  %1515 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load718, 1
  %.state719 = load i64, ptr %.slot119, align 4
  %.splatinsert720 = insertelement <8 x i64> poison, i64 %.state719, i64 0
  %.splat721 = shufflevector <8 x i64> %.splatinsert720, <8 x i64> poison, <8 x i32> zeroinitializer
  %1516 = mul <8 x i64> %.splat721, splat (i64 4)
  %1517 = add <8 x i64> %1515, %1516
  %1518 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1514, 0
  %1519 = insertvalue { <8 x ptr>, <8 x i64> } %1518, <8 x i64> %1517, 1
  %.state722 = load <8 x float>, ptr %.slot121, align 32
  %1520 = extractvalue { <8 x ptr>, <8 x i64> } %1519, 0
  %1521 = extractvalue { <8 x ptr>, <8 x i64> } %1519, 1
  %1522 = getelementptr i8, <8 x ptr> %1520, <8 x i64> %1521
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state722, <8 x ptr> align 1 %1522, <8 x i1> %71)
  %.state723 = load i64, ptr %.slot119, align 4
  %1523 = add i64 %.state723, 1
  store i64 %1523, ptr %.slot119, align 4
  br label %direct.schedule.46

direct.schedule.50:                               ; preds = %direct.false153
  store i64 0, ptr %.slot122, align 4
  br label %direct.schedule.51

direct.schedule.51:                               ; preds = %direct.schedule.52, %direct.schedule.50
  %.state724 = load i64, ptr %.slot122, align 4
  %1524 = icmp slt i64 %.state724, 128
  br i1 %1524, label %direct.true725, label %direct.false726

direct.schedule.52:                               ; preds = %direct.true725
  %.spill.load727 = load i64, ptr %.spill29, align 4
  %1525 = add i64 %.spill.load727, 0
  %.spill.load728 = load <8 x i64>, ptr %.spill, align 64
  %1526 = add <8 x i64> %.spill.load728, zeroinitializer
  %1527 = mul i64 %1525, 16
  %.splatinsert729 = insertelement <8 x i64> poison, i64 %1527, i64 0
  %.splat730 = shufflevector <8 x i64> %.splatinsert729, <8 x i64> poison, <8 x i32> zeroinitializer
  %1528 = add <8 x i64> %.splat730, %1526
  %1529 = mul <8 x i64> %1528, splat (i64 1)
  %.spill.load731 = load i64, ptr %.spill31, align 4
  %.splatinsert732 = insertelement <8 x i64> poison, i64 %.spill.load731, i64 0
  %.splat733 = shufflevector <8 x i64> %.splatinsert732, <8 x i64> poison, <8 x i32> zeroinitializer
  %1530 = add <8 x i64> %1529, %.splat733
  %.state734 = load i64, ptr %.slot122, align 4
  %1531 = add i64 0, %.state734
  %1532 = mul <8 x i64> %1530, splat (i64 128)
  %.splatinsert735 = insertelement <8 x i64> poison, i64 %1531, i64 0
  %.splat736 = shufflevector <8 x i64> %.splatinsert735, <8 x i64> poison, <8 x i32> zeroinitializer
  %1533 = add <8 x i64> %1532, %.splat736
  %.state737 = load i64, ptr %.slot122, align 4
  %1534 = add i64 0, %.state737
  %tile_snapshot.spill.load738 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1535 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load738, 0
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load738, 1
  %.splatinsert739 = insertelement <8 x i64> poison, i64 %1534, i64 0
  %.splat740 = shufflevector <8 x i64> %.splatinsert739, <8 x i64> poison, <8 x i32> zeroinitializer
  %1537 = mul <8 x i64> %.splat740, splat (i64 32)
  %1538 = add <8 x i64> %1536, %1537
  %1539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1535, 0
  %1540 = insertvalue { <8 x ptr>, <8 x i64> } %1539, <8 x i64> %1538, 1
  %1541 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %1540, 1
  %1543 = extractelement <8 x ptr> %1541, i32 0
  %1544 = extractelement <8 x i64> %1542, i32 0
  %1545 = sub i64 %1544, 0
  %1546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1547 = select i1 %1546, i64 %1545, i64 0
  %private.contiguous.address741 = getelementptr i8, ptr %1543, i64 %1547
  %private.contiguous.load742 = load <8 x float>, ptr %private.contiguous.address741, align 4
  %1548 = select <8 x i1> %71, <8 x float> %private.contiguous.load742, <8 x float> zeroinitializer
  %.state743 = load <8 x float>, ptr %.slot36, align 32
  %1549 = fdiv <8 x float> %1548, %.state743
  %1550 = extractvalue { ptr, i64 } %47, 0
  %1551 = mul <8 x i64> %1533, splat (i64 4)
  %1552 = getelementptr i8, ptr %1550, <8 x i64> %1551
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1549, <8 x ptr> align 1 %1552, <8 x i1> %71)
  %.state744 = load i64, ptr %.slot122, align 4
  %1553 = add i64 %.state744, 1
  store i64 %1553, ptr %.slot122, align 4
  br label %direct.schedule.51

direct.schedule.53:                               ; preds = %direct.false726
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

copy.active:                                      ; preds = %direct.schedule.0
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1555 = extractelement <8 x ptr> %1554, i64 0
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1557 = extractelement <8 x i64> %1556, i64 0
  %1558 = getelementptr i8, ptr %1555, i64 %1557
  %1559 = extractelement <8 x i64> %98, i64 0
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1559, ptr %1558)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active, %direct.schedule.0
  %1560 = extractelement <8 x i1> %71, i64 1
  br i1 %1560, label %copy.active133, label %copy.continue134

copy.active133:                                   ; preds = %copy.continue
  %1561 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1562 = extractelement <8 x ptr> %1561, i64 1
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1564 = extractelement <8 x i64> %1563, i64 1
  %1565 = getelementptr i8, ptr %1562, i64 %1564
  %1566 = extractelement <8 x i64> %98, i64 1
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1566, ptr %1565)
  br label %copy.continue134

copy.continue134:                                 ; preds = %copy.active133, %copy.continue
  %1567 = extractelement <8 x i1> %71, i64 2
  br i1 %1567, label %copy.active135, label %copy.continue136

copy.active135:                                   ; preds = %copy.continue134
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1569 = extractelement <8 x ptr> %1568, i64 2
  %1570 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1571 = extractelement <8 x i64> %1570, i64 2
  %1572 = getelementptr i8, ptr %1569, i64 %1571
  %1573 = extractelement <8 x i64> %98, i64 2
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1573, ptr %1572)
  br label %copy.continue136

copy.continue136:                                 ; preds = %copy.active135, %copy.continue134
  %1574 = extractelement <8 x i1> %71, i64 3
  br i1 %1574, label %copy.active137, label %copy.continue138

copy.active137:                                   ; preds = %copy.continue136
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1576 = extractelement <8 x ptr> %1575, i64 3
  %1577 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1578 = extractelement <8 x i64> %1577, i64 3
  %1579 = getelementptr i8, ptr %1576, i64 %1578
  %1580 = extractelement <8 x i64> %98, i64 3
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1580, ptr %1579)
  br label %copy.continue138

copy.continue138:                                 ; preds = %copy.active137, %copy.continue136
  %1581 = extractelement <8 x i1> %71, i64 4
  br i1 %1581, label %copy.active139, label %copy.continue140

copy.active139:                                   ; preds = %copy.continue138
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1583 = extractelement <8 x ptr> %1582, i64 4
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1585 = extractelement <8 x i64> %1584, i64 4
  %1586 = getelementptr i8, ptr %1583, i64 %1585
  %1587 = extractelement <8 x i64> %98, i64 4
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1587, ptr %1586)
  br label %copy.continue140

copy.continue140:                                 ; preds = %copy.active139, %copy.continue138
  %1588 = extractelement <8 x i1> %71, i64 5
  br i1 %1588, label %copy.active141, label %copy.continue142

copy.active141:                                   ; preds = %copy.continue140
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1590 = extractelement <8 x ptr> %1589, i64 5
  %1591 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1592 = extractelement <8 x i64> %1591, i64 5
  %1593 = getelementptr i8, ptr %1590, i64 %1592
  %1594 = extractelement <8 x i64> %98, i64 5
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1594, ptr %1593)
  br label %copy.continue142

copy.continue142:                                 ; preds = %copy.active141, %copy.continue140
  %1595 = extractelement <8 x i1> %71, i64 6
  br i1 %1595, label %copy.active143, label %copy.continue144

copy.active143:                                   ; preds = %copy.continue142
  %1596 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1597 = extractelement <8 x ptr> %1596, i64 6
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1599 = extractelement <8 x i64> %1598, i64 6
  %1600 = getelementptr i8, ptr %1597, i64 %1599
  %1601 = extractelement <8 x i64> %98, i64 6
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1601, ptr %1600)
  br label %copy.continue144

copy.continue144:                                 ; preds = %copy.active143, %copy.continue142
  %1602 = extractelement <8 x i1> %71, i64 7
  br i1 %1602, label %copy.active145, label %copy.continue146

copy.active145:                                   ; preds = %copy.continue144
  %1603 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1604 = extractelement <8 x ptr> %1603, i64 7
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1606 = extractelement <8 x i64> %1605, i64 7
  %1607 = getelementptr i8, ptr %1604, i64 %1606
  %1608 = extractelement <8 x i64> %98, i64 7
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1608, ptr %1607)
  br label %copy.continue146

copy.continue146:                                 ; preds = %copy.active145, %copy.continue144
  %1609 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1610 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1611 = extractvalue { <8 x ptr>, <8 x i64> } %1609, 0
  %1612 = select <8 x i1> %71, <8 x ptr> %1610, <8 x ptr> %1611
  %1613 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %1609, 1
  %1615 = select <8 x i1> %71, <8 x i64> %1613, <8 x i64> %1614
  %1616 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1612, 0
  %1617 = insertvalue { <8 x ptr>, <8 x i64> } %1616, <8 x i64> %1615, 1
  store { <8 x ptr>, <8 x i64> } %1617, ptr %tile_snapshot.spill32, align 64
  %1618 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1620 = extractvalue { <8 x ptr>, <8 x i64> } %1618, 0
  %1621 = select <8 x i1> %71, <8 x ptr> %1619, <8 x ptr> %1620
  %1622 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %1618, 1
  %1624 = select <8 x i1> %71, <8 x i64> %1622, <8 x i64> %1623
  %1625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1621, 0
  %1626 = insertvalue { <8 x ptr>, <8 x i64> } %1625, <8 x i64> %1624, 1
  store { <8 x ptr>, <8 x i64> } %1626, ptr %tile_snapshot.spill33, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true152:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false153:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.50

direct.true155:                                   ; preds = %direct.schedule.5
  br label %direct.schedule.6

direct.false156:                                  ; preds = %direct.schedule.5
  br label %direct.schedule.45

copy.active164:                                   ; preds = %direct.schedule.6
  %1627 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1628 = extractelement <8 x ptr> %1627, i64 0
  %1629 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1630 = extractelement <8 x i64> %1629, i64 0
  %1631 = getelementptr i8, ptr %1628, i64 %1630
  %1632 = extractelement <8 x i64> %142, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1632, ptr %1631)
  br label %copy.continue165

copy.continue165:                                 ; preds = %copy.active164, %direct.schedule.6
  %1633 = extractelement <8 x i1> %71, i64 1
  br i1 %1633, label %copy.active166, label %copy.continue167

copy.active166:                                   ; preds = %copy.continue165
  %1634 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1635 = extractelement <8 x ptr> %1634, i64 1
  %1636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1637 = extractelement <8 x i64> %1636, i64 1
  %1638 = getelementptr i8, ptr %1635, i64 %1637
  %1639 = extractelement <8 x i64> %142, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1639, ptr %1638)
  br label %copy.continue167

copy.continue167:                                 ; preds = %copy.active166, %copy.continue165
  %1640 = extractelement <8 x i1> %71, i64 2
  br i1 %1640, label %copy.active168, label %copy.continue169

copy.active168:                                   ; preds = %copy.continue167
  %1641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1642 = extractelement <8 x ptr> %1641, i64 2
  %1643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1644 = extractelement <8 x i64> %1643, i64 2
  %1645 = getelementptr i8, ptr %1642, i64 %1644
  %1646 = extractelement <8 x i64> %142, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1646, ptr %1645)
  br label %copy.continue169

copy.continue169:                                 ; preds = %copy.active168, %copy.continue167
  %1647 = extractelement <8 x i1> %71, i64 3
  br i1 %1647, label %copy.active170, label %copy.continue171

copy.active170:                                   ; preds = %copy.continue169
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1649 = extractelement <8 x ptr> %1648, i64 3
  %1650 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1651 = extractelement <8 x i64> %1650, i64 3
  %1652 = getelementptr i8, ptr %1649, i64 %1651
  %1653 = extractelement <8 x i64> %142, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1653, ptr %1652)
  br label %copy.continue171

copy.continue171:                                 ; preds = %copy.active170, %copy.continue169
  %1654 = extractelement <8 x i1> %71, i64 4
  br i1 %1654, label %copy.active172, label %copy.continue173

copy.active172:                                   ; preds = %copy.continue171
  %1655 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1656 = extractelement <8 x ptr> %1655, i64 4
  %1657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1658 = extractelement <8 x i64> %1657, i64 4
  %1659 = getelementptr i8, ptr %1656, i64 %1658
  %1660 = extractelement <8 x i64> %142, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1660, ptr %1659)
  br label %copy.continue173

copy.continue173:                                 ; preds = %copy.active172, %copy.continue171
  %1661 = extractelement <8 x i1> %71, i64 5
  br i1 %1661, label %copy.active174, label %copy.continue175

copy.active174:                                   ; preds = %copy.continue173
  %1662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1663 = extractelement <8 x ptr> %1662, i64 5
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1665 = extractelement <8 x i64> %1664, i64 5
  %1666 = getelementptr i8, ptr %1663, i64 %1665
  %1667 = extractelement <8 x i64> %142, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1667, ptr %1666)
  br label %copy.continue175

copy.continue175:                                 ; preds = %copy.active174, %copy.continue173
  %1668 = extractelement <8 x i1> %71, i64 6
  br i1 %1668, label %copy.active176, label %copy.continue177

copy.active176:                                   ; preds = %copy.continue175
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1670 = extractelement <8 x ptr> %1669, i64 6
  %1671 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1672 = extractelement <8 x i64> %1671, i64 6
  %1673 = getelementptr i8, ptr %1670, i64 %1672
  %1674 = extractelement <8 x i64> %142, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1674, ptr %1673)
  br label %copy.continue177

copy.continue177:                                 ; preds = %copy.active176, %copy.continue175
  %1675 = extractelement <8 x i1> %71, i64 7
  br i1 %1675, label %copy.active178, label %copy.continue179

copy.active178:                                   ; preds = %copy.continue177
  %1676 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1677 = extractelement <8 x ptr> %1676, i64 7
  %1678 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1679 = extractelement <8 x i64> %1678, i64 7
  %1680 = getelementptr i8, ptr %1677, i64 %1679
  %1681 = extractelement <8 x i64> %142, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1681, ptr %1680)
  br label %copy.continue179

copy.continue179:                                 ; preds = %copy.active178, %copy.continue177
  br label %direct.schedule.7

direct.true181:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false182:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.40

copy.active191:                                   ; preds = %direct.schedule.8
  %1682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1683 = extractelement <8 x ptr> %1682, i64 0
  %1684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1685 = extractelement <8 x i64> %1684, i64 0
  %1686 = getelementptr i8, ptr %1683, i64 %1685
  %1687 = extractelement <8 x i64> %159, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1687, ptr %1686)
  br label %copy.continue192

copy.continue192:                                 ; preds = %copy.active191, %direct.schedule.8
  %1688 = extractelement <8 x i1> %71, i64 1
  br i1 %1688, label %copy.active193, label %copy.continue194

copy.active193:                                   ; preds = %copy.continue192
  %1689 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1690 = extractelement <8 x ptr> %1689, i64 1
  %1691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1692 = extractelement <8 x i64> %1691, i64 1
  %1693 = getelementptr i8, ptr %1690, i64 %1692
  %1694 = extractelement <8 x i64> %159, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1694, ptr %1693)
  br label %copy.continue194

copy.continue194:                                 ; preds = %copy.active193, %copy.continue192
  %1695 = extractelement <8 x i1> %71, i64 2
  br i1 %1695, label %copy.active195, label %copy.continue196

copy.active195:                                   ; preds = %copy.continue194
  %1696 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1697 = extractelement <8 x ptr> %1696, i64 2
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1699 = extractelement <8 x i64> %1698, i64 2
  %1700 = getelementptr i8, ptr %1697, i64 %1699
  %1701 = extractelement <8 x i64> %159, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1701, ptr %1700)
  br label %copy.continue196

copy.continue196:                                 ; preds = %copy.active195, %copy.continue194
  %1702 = extractelement <8 x i1> %71, i64 3
  br i1 %1702, label %copy.active197, label %copy.continue198

copy.active197:                                   ; preds = %copy.continue196
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1704 = extractelement <8 x ptr> %1703, i64 3
  %1705 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1706 = extractelement <8 x i64> %1705, i64 3
  %1707 = getelementptr i8, ptr %1704, i64 %1706
  %1708 = extractelement <8 x i64> %159, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1708, ptr %1707)
  br label %copy.continue198

copy.continue198:                                 ; preds = %copy.active197, %copy.continue196
  %1709 = extractelement <8 x i1> %71, i64 4
  br i1 %1709, label %copy.active199, label %copy.continue200

copy.active199:                                   ; preds = %copy.continue198
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1711 = extractelement <8 x ptr> %1710, i64 4
  %1712 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1713 = extractelement <8 x i64> %1712, i64 4
  %1714 = getelementptr i8, ptr %1711, i64 %1713
  %1715 = extractelement <8 x i64> %159, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1715, ptr %1714)
  br label %copy.continue200

copy.continue200:                                 ; preds = %copy.active199, %copy.continue198
  %1716 = extractelement <8 x i1> %71, i64 5
  br i1 %1716, label %copy.active201, label %copy.continue202

copy.active201:                                   ; preds = %copy.continue200
  %1717 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1718 = extractelement <8 x ptr> %1717, i64 5
  %1719 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1720 = extractelement <8 x i64> %1719, i64 5
  %1721 = getelementptr i8, ptr %1718, i64 %1720
  %1722 = extractelement <8 x i64> %159, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1722, ptr %1721)
  br label %copy.continue202

copy.continue202:                                 ; preds = %copy.active201, %copy.continue200
  %1723 = extractelement <8 x i1> %71, i64 6
  br i1 %1723, label %copy.active203, label %copy.continue204

copy.active203:                                   ; preds = %copy.continue202
  %1724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1725 = extractelement <8 x ptr> %1724, i64 6
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1727 = extractelement <8 x i64> %1726, i64 6
  %1728 = getelementptr i8, ptr %1725, i64 %1727
  %1729 = extractelement <8 x i64> %159, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1729, ptr %1728)
  br label %copy.continue204

copy.continue204:                                 ; preds = %copy.active203, %copy.continue202
  %1730 = extractelement <8 x i1> %71, i64 7
  br i1 %1730, label %copy.active205, label %copy.continue206

copy.active205:                                   ; preds = %copy.continue204
  %1731 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1732 = extractelement <8 x ptr> %1731, i64 7
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1734 = extractelement <8 x i64> %1733, i64 7
  %1735 = getelementptr i8, ptr %1732, i64 %1734
  %1736 = extractelement <8 x i64> %159, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1736, ptr %1735)
  br label %copy.continue206

copy.continue206:                                 ; preds = %copy.active205, %copy.continue204
  br label %direct.schedule.9

direct.true208:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false209:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true235:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false236:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true263:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false264:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true291:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false292:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true416:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false417:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true543:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false544:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true557:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false558:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.33

direct.true585:                                   ; preds = %direct.schedule.30
  br label %direct.schedule.31

direct.false586:                                  ; preds = %direct.schedule.30
  br label %direct.schedule.32

direct.true644:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false645:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true660:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false661:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true679:                                   ; preds = %direct.schedule.41
  br label %direct.schedule.42

direct.false680:                                  ; preds = %direct.schedule.41
  br label %direct.schedule.9

direct.true692:                                   ; preds = %direct.schedule.42
  br label %direct.schedule.43

direct.false693:                                  ; preds = %direct.schedule.42
  %1737 = load <8 x float>, ptr %.slot118, align 32
  %1738 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1737
  store <8 x float> %1738, ptr %.slot118, align 32
  br label %direct.schedule.44

direct.true702:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false703:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.7

direct.true715:                                   ; preds = %direct.schedule.47
  br label %direct.schedule.48

direct.false716:                                  ; preds = %direct.schedule.47
  %1739 = load <8 x float>, ptr %.slot121, align 32
  %1740 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1739
  store <8 x float> %1740, ptr %.slot121, align 32
  br label %direct.schedule.49

direct.true725:                                   ; preds = %direct.schedule.51
  br label %direct.schedule.52

direct.false726:                                  ; preds = %direct.schedule.51
  br label %direct.schedule.53
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 32
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.1(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 512
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nounwind willreturn
define private void @llm_attention.contiguous_copy.2(ptr %0, i64 %1, ptr %2) #1 {
entry:
  %3 = getelementptr i32, ptr %0, i64 %1
  br label %copy.loop

copy.loop:                                        ; preds = %copy.chunk, %entry
  %copy.index = phi i64 [ 0, %entry ], [ %10, %copy.chunk ]
  %4 = icmp ult i64 %copy.index, 512
  br i1 %4, label %copy.chunk, label %copy.next

copy.chunk:                                       ; preds = %copy.loop
  %5 = mul i64 %copy.index, 4
  %6 = add i64 0, %5
  %7 = getelementptr i32, ptr %3, i64 %6
  %8 = getelementptr i32, ptr %2, i64 %6
  %9 = load <4 x i32>, ptr %7, align 4
  store <4 x i32> %9, ptr %8, align 4
  %10 = add i64 %copy.index, 1
  br label %copy.loop

copy.next:                                        ; preds = %copy.loop
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #3

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #4 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #5

define internal void @llm_attention.full_packet(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 4096
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 8192
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 12288
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 77824
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 8192, i64 16384, i64 24576, i64 32768, i64 40960, i64 49152, i64 57344>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 143360
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 143872
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 144384
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill29 = alloca i64, align 8
  store i64 0, ptr %.spill29, align 4
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill31 = alloca i64, align 8
  store i64 0, ptr %.spill31, align 4
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %tile_snapshot.spill33 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill33, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.spill37 = alloca i64, align 8
  store i64 0, ptr %.spill37, align 4
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.spill39 = alloca i1, align 1
  store i1 false, ptr %.spill39, align 1
  %tile_snapshot.spill40 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill40, align 64
  %.slot41 = alloca i64, align 8
  store i64 0, ptr %.slot41, align 4
  %.slot42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot42, align 32
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot44, align 32
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca i64, align 8
  store i64 0, ptr %.slot46, align 4
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca i64, align 8
  store i64 0, ptr %.slot51, align 4
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot54, align 32
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca i64, align 8
  store i64 0, ptr %.slot56, align 4
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.spill61 = alloca i1, align 1
  store i1 false, ptr %.spill61, align 1
  %.spill62 = alloca i1, align 1
  store i1 false, ptr %.spill62, align 1
  %.spill63 = alloca i1, align 1
  store i1 false, ptr %.spill63, align 1
  %.spill64 = alloca i1, align 1
  store i1 false, ptr %.spill64, align 1
  %.spill65 = alloca i1, align 1
  store i1 false, ptr %.spill65, align 1
  %.spill66 = alloca i1, align 1
  store i1 false, ptr %.spill66, align 1
  %.spill67 = alloca i1, align 1
  store i1 false, ptr %.spill67, align 1
  %.spill68 = alloca i1, align 1
  store i1 false, ptr %.spill68, align 1
  %.spill69 = alloca i1, align 1
  store i1 false, ptr %.spill69, align 1
  %.spill70 = alloca i1, align 1
  store i1 false, ptr %.spill70, align 1
  %.spill71 = alloca i1, align 1
  store i1 false, ptr %.spill71, align 1
  %.spill72 = alloca i1, align 1
  store i1 false, ptr %.spill72, align 1
  %.spill73 = alloca i1, align 1
  store i1 false, ptr %.spill73, align 1
  %.spill74 = alloca i1, align 1
  store i1 false, ptr %.spill74, align 1
  %.spill75 = alloca i1, align 1
  store i1 false, ptr %.spill75, align 1
  %.spill76 = alloca i1, align 1
  store i1 false, ptr %.spill76, align 1
  %.spill77 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill77, align 32
  %.spill78 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill78, align 32
  %.spill79 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill79, align 32
  %.spill80 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill80, align 32
  %.spill81 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill81, align 32
  %.spill82 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill82, align 32
  %.spill83 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill83, align 32
  %.spill84 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill84, align 32
  %.spill85 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill85, align 32
  %.spill86 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill86, align 32
  %.spill87 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill87, align 32
  %.spill88 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill88, align 32
  %.spill89 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill89, align 32
  %.spill90 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill90, align 32
  %.spill91 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill91, align 32
  %.spill92 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill92, align 32
  %tile_snapshot.spill93 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill93, align 64
  %.slot94 = alloca i64, align 8
  store i64 0, ptr %.slot94, align 4
  %.slot95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot95, align 32
  %.spill96 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill96, align 32
  %.spill97 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill97, align 32
  %tile_snapshot.spill98 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill98, align 64
  %.spill99 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill99, align 32
  %.slot100 = alloca i64, align 8
  store i64 0, ptr %.slot100, align 4
  %.slot101 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot101, align 32
  %.spill102 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill102, align 32
  %tile_snapshot.spill103 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill103, align 64
  %.slot104 = alloca i64, align 8
  store i64 0, ptr %.slot104, align 4
  %.spill105 = alloca i64, align 8
  store i64 0, ptr %.spill105, align 4
  %.spill106 = alloca i64, align 8
  store i64 0, ptr %.spill106, align 4
  %.spill107 = alloca i64, align 8
  store i64 0, ptr %.spill107, align 4
  %.spill108 = alloca i64, align 8
  store i64 0, ptr %.spill108, align 4
  %.slot109 = alloca i64, align 8
  store i64 0, ptr %.slot109, align 4
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %.slot111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot111, align 32
  %.slot112 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot112, align 32
  %.slot113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot113, align 32
  %.slot114 = alloca i64, align 8
  store i64 0, ptr %.slot114, align 4
  %.slot115 = alloca i64, align 8
  store i64 0, ptr %.slot115, align 4
  %.slot116 = alloca i64, align 8
  store i64 0, ptr %.slot116, align 4
  %.spill117 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill117, align 64
  %.slot118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot118, align 32
  %.slot119 = alloca i64, align 8
  store i64 0, ptr %.slot119, align 4
  %.spill120 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill120, align 64
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.slot122 = alloca i64, align 8
  store i64 0, ptr %.slot122, align 4
  %24 = getelementptr i8, ptr %argument_buffer, i64 0
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 16
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = getelementptr i8, ptr %argument_buffer, i64 32
  %37 = load ptr, ptr %36, align 16
  %38 = getelementptr i8, ptr %36, i64 8
  %39 = load i64, ptr %38, align 8
  %40 = insertvalue { ptr, i64 } poison, ptr %37, 0
  %41 = insertvalue { ptr, i64 } %40, i64 %39, 1
  %42 = getelementptr i8, ptr %argument_buffer, i64 48
  %43 = load ptr, ptr %42, align 16
  %44 = getelementptr i8, ptr %42, i64 8
  %45 = load i64, ptr %44, align 8
  %46 = insertvalue { ptr, i64 } poison, ptr %43, 0
  %47 = insertvalue { ptr, i64 } %46, i64 %45, 1
  %48 = load i32, ptr %launch_config, align 4
  %49 = getelementptr i8, ptr %launch_config, i64 12
  %50 = load i32, ptr %49, align 4
  %51 = getelementptr i8, ptr %launch_config, i64 4
  %52 = load i32, ptr %51, align 4
  %53 = getelementptr i8, ptr %launch_config, i64 16
  %54 = load i32, ptr %53, align 4
  %55 = getelementptr i8, ptr %launch_config, i64 8
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr i8, ptr %launch_config, i64 20
  %58 = load i32, ptr %57, align 4
  %59 = getelementptr i8, ptr %launch_config, i64 36
  %60 = load i32, ptr %59, align 4
  %.splatinsert123 = insertelement <8 x i32> poison, i32 %60, i64 0
  %.splat124 = shufflevector <8 x i32> %.splatinsert123, <8 x i32> poison, <8 x i32> zeroinitializer
  %61 = add <8 x i32> %.splat124, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %62 = mul i32 %48, 32
  %.splatinsert125 = insertelement <8 x i32> poison, i32 %62, i64 0
  %.splat126 = shufflevector <8 x i32> %.splatinsert125, <8 x i32> poison, <8 x i32> zeroinitializer
  %63 = add <8 x i32> %.splat126, %61
  %64 = mul i32 %52, 1
  %.splatinsert127 = insertelement <8 x i32> poison, i32 %64, i64 0
  %.splat128 = shufflevector <8 x i32> %.splatinsert127, <8 x i32> poison, <8 x i32> zeroinitializer
  %65 = add <8 x i32> %.splat128, zeroinitializer
  %66 = mul i32 %56, 1
  %.splatinsert129 = insertelement <8 x i32> poison, i32 %66, i64 0
  %.splat130 = shufflevector <8 x i32> %.splatinsert129, <8 x i32> poison, <8 x i32> zeroinitializer
  %67 = add <8 x i32> %.splat130, zeroinitializer
  %68 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %63, 0
  %69 = insertvalue [3 x <8 x i32>] %68, <8 x i32> %65, 1
  %70 = insertvalue [3 x <8 x i32>] %69, <8 x i32> %67, 2
  %.splatinsert131 = insertelement <8 x i32> poison, i32 8, i64 0
  %.splat132 = shufflevector <8 x i32> %.splatinsert131, <8 x i32> poison, <8 x i32> zeroinitializer
  %71 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat132
  %72 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  br i1 %72, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %73 = extractvalue [3 x <8 x i32>] %70, 0
  %74 = zext <8 x i32> %73 to <8 x i64>
  %75 = select <8 x i1> %71, <8 x i64> %74, <8 x i64> zeroinitializer
  %76 = select <8 x i1> %71, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %77 = sdiv <8 x i64> %75, %76
  %78 = load <8 x i64>, ptr %.spill, align 64
  %79 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> %78
  store <8 x i64> %79, ptr %.spill, align 64
  store i64 0, ptr %.spill29, align 4
  %80 = select <8 x i1> %71, <8 x i64> %77, <8 x i64> zeroinitializer
  %81 = select <8 x i1> %71, <8 x i64> splat (i64 4), <8 x i64> splat (i64 1)
  %82 = sdiv <8 x i64> %80, %81
  %83 = load <8 x i64>, ptr %.spill30, align 64
  %84 = select <8 x i1> %71, <8 x i64> %82, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill30, align 64
  %85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %85, 0
  %88 = select <8 x i1> %71, <8 x ptr> %86, <8 x ptr> %87
  %89 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %85, 1
  %91 = select <8 x i1> %71, <8 x i64> %89, <8 x i64> %90
  %92 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %88, 0
  %93 = insertvalue { <8 x ptr>, <8 x i64> } %92, <8 x i64> %91, 1
  store { <8 x ptr>, <8 x i64> } %93, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.spill31, align 4
  %94 = add <8 x i64> zeroinitializer, %77
  %95 = mul <8 x i64> %94, splat (i64 1)
  %96 = add <8 x i64> %95, zeroinitializer
  %97 = mul <8 x i64> %96, splat (i64 128)
  %98 = add <8 x i64> %97, zeroinitializer
  %99 = extractvalue { ptr, i64 } %29, 0
  %100 = extractelement <8 x i1> %71, i64 0
  br i1 %100, label %copy.active, label %copy.continue

direct.schedule.1:                                ; preds = %copy.continue146, %direct.schedule.2
  %.state = load i64, ptr %.slot, align 4
  %101 = icmp slt i64 %.state, 128
  br i1 %101, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state147 = load i64, ptr %.slot, align 4
  %.splatinsert148 = insertelement <8 x i64> poison, i64 %.state147, i64 0
  %.splat149 = shufflevector <8 x i64> %.splatinsert148, <8 x i64> poison, <8 x i32> zeroinitializer
  %104 = mul <8 x i64> %.splat149, splat (i64 32)
  %105 = add <8 x i64> %103, %104
  %106 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %102, 0
  %107 = insertvalue { <8 x ptr>, <8 x i64> } %106, <8 x i64> %105, 1
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %107, 1
  %110 = extractelement <8 x ptr> %108, i32 0
  %111 = extractelement <8 x i64> %109, i32 0
  %112 = sub i64 %111, 0
  %113 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %114 = select i1 %113, i64 %112, i64 0
  %private.contiguous.address = getelementptr i8, ptr %110, i64 %114
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %115 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve
  store <8 x float> %115, ptr %private.contiguous.address, align 4
  %.state150 = load i64, ptr %.slot, align 4
  %116 = add i64 %.state150, 1
  store i64 %116, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store i64 0, ptr %.slot34, align 4
  %117 = load <8 x float>, ptr %.slot35, align 32
  %118 = select <8 x i1> %71, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %117
  store <8 x float> %118, ptr %.slot35, align 32
  %119 = load <8 x float>, ptr %.slot36, align 32
  %120 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %119
  store <8 x float> %120, ptr %.slot36, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.39, %direct.schedule.3
  %.state151 = load i64, ptr %.slot34, align 4
  %121 = icmp slt i64 %.state151, 513
  br i1 %121, label %direct.true152, label %direct.false153

direct.schedule.5:                                ; preds = %direct.true152
  %.state154 = load i64, ptr %.slot34, align 4
  %122 = sdiv i64 %.state154, 1
  %123 = mul i64 %122, 16
  store i64 %123, ptr %.spill37, align 4
  %124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %124, 0
  %127 = select <8 x i1> %71, <8 x ptr> %125, <8 x ptr> %126
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %124, 1
  %130 = select <8 x i1> %71, <8 x i64> %128, <8 x i64> %129
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %127, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  store { <8 x ptr>, <8 x i64> } %132, ptr %tile_snapshot.spill38, align 64
  %133 = icmp sge i64 %123, 0
  %134 = and i1 true, %133
  %135 = icmp sle i64 %123, 8177
  %136 = and i1 %134, %135
  store i1 %136, ptr %.spill39, align 1
  br i1 %136, label %direct.true155, label %direct.false156

direct.schedule.6:                                ; preds = %direct.true155
  %.spill.load = load i64, ptr %.spill31, align 4
  %137 = mul i64 %.spill.load, 4
  %.splatinsert157 = insertelement <8 x i64> poison, i64 %137, i64 0
  %.splat158 = shufflevector <8 x i64> %.splatinsert157, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load159 = load <8 x i64>, ptr %.spill30, align 64
  %138 = add <8 x i64> %.splat158, %.spill.load159
  %139 = mul <8 x i64> %138, splat (i64 8193)
  %.spill.load160 = load i64, ptr %.spill37, align 4
  %.splatinsert161 = insertelement <8 x i64> poison, i64 %.spill.load160, i64 0
  %.splat162 = shufflevector <8 x i64> %.splatinsert161, <8 x i64> poison, <8 x i32> zeroinitializer
  %140 = add <8 x i64> %139, %.splat162
  %141 = mul <8 x i64> %140, splat (i64 128)
  %142 = add <8 x i64> %141, zeroinitializer
  %tile_snapshot.spill.load163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %143 = extractvalue { ptr, i64 } %35, 0
  %144 = extractelement <8 x i1> %71, i64 0
  br i1 %144, label %copy.active164, label %copy.continue165

direct.schedule.7:                                ; preds = %direct.false703, %copy.continue179
  %145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %145, 0
  %148 = select <8 x i1> %71, <8 x ptr> %146, <8 x ptr> %147
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %145, 1
  %151 = select <8 x i1> %71, <8 x i64> %149, <8 x i64> %150
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %148, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  store { <8 x ptr>, <8 x i64> } %153, ptr %tile_snapshot.spill40, align 64
  %.spill.load180 = load i1, ptr %.spill39, align 1
  br i1 %.spill.load180, label %direct.true181, label %direct.false182

direct.schedule.8:                                ; preds = %direct.true181
  %.spill.load183 = load i64, ptr %.spill31, align 4
  %154 = mul i64 %.spill.load183, 4
  %.splatinsert184 = insertelement <8 x i64> poison, i64 %154, i64 0
  %.splat185 = shufflevector <8 x i64> %.splatinsert184, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load186 = load <8 x i64>, ptr %.spill30, align 64
  %155 = add <8 x i64> %.splat185, %.spill.load186
  %156 = mul <8 x i64> %155, splat (i64 8193)
  %.spill.load187 = load i64, ptr %.spill37, align 4
  %.splatinsert188 = insertelement <8 x i64> poison, i64 %.spill.load187, i64 0
  %.splat189 = shufflevector <8 x i64> %.splatinsert188, <8 x i64> poison, <8 x i32> zeroinitializer
  %157 = add <8 x i64> %156, %.splat189
  %158 = mul <8 x i64> %157, splat (i64 128)
  %159 = add <8 x i64> %158, zeroinitializer
  %tile_snapshot.spill.load190 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %160 = extractvalue { ptr, i64 } %41, 0
  %161 = extractelement <8 x i1> %71, i64 0
  br i1 %161, label %copy.active191, label %copy.continue192

direct.schedule.9:                                ; preds = %direct.false680, %copy.continue206
  store i64 0, ptr %.slot41, align 4
  %162 = load <8 x float>, ptr %.slot42, align 32
  %163 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %162
  store <8 x float> %163, ptr %.slot42, align 32
  %164 = load <8 x float>, ptr %.slot43, align 32
  %165 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %164
  store <8 x float> %165, ptr %.slot43, align 32
  %166 = load <8 x float>, ptr %.slot44, align 32
  %167 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %166
  store <8 x float> %167, ptr %.slot44, align 32
  %168 = load <8 x float>, ptr %.slot45, align 32
  %169 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %168
  store <8 x float> %169, ptr %.slot45, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state207 = load i64, ptr %.slot41, align 4
  %170 = icmp slt i64 %.state207, 128
  br i1 %170, label %direct.true208, label %direct.false209

direct.schedule.11:                               ; preds = %direct.true208
  %.state210 = load i64, ptr %.slot41, align 4
  %171 = add i64 0, %.state210
  %tile_snapshot.spill.load211 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load211, 1
  %.splatinsert212 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat213 = shufflevector <8 x i64> %.splatinsert212, <8 x i64> poison, <8 x i32> zeroinitializer
  %174 = mul <8 x i64> %.splat213, splat (i64 4)
  %175 = add <8 x i64> %173, %174
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %172, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %177, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = getelementptr i8, <8 x ptr> %178, <8 x i64> %179
  %181 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %180, <8 x i1> %71, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 1
  %.splatinsert215 = insertelement <8 x i64> poison, i64 %171, i64 0
  %.splat216 = shufflevector <8 x i64> %.splatinsert215, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = mul <8 x i64> %.splat216, splat (i64 4)
  %185 = add <8 x i64> %183, %184
  %186 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %182, 0
  %187 = insertvalue { <8 x ptr>, <8 x i64> } %186, <8 x i64> %185, 1
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %187, 0
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %187, 1
  %190 = getelementptr i8, <8 x ptr> %188, <8 x i64> %189
  %191 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %190, <8 x i1> %71, <8 x float> zeroinitializer)
  %192 = fmul <8 x float> %181, %191
  %.state217 = load <8 x float>, ptr %.slot42, align 32
  %193 = fadd <8 x float> %.state217, %192
  %.state218 = load i64, ptr %.slot41, align 4
  %194 = add i64 128, %.state218
  %tile_snapshot.spill.load219 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 0
  %196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load219, 1
  %.splatinsert220 = insertelement <8 x i64> poison, i64 %194, i64 0
  %.splat221 = shufflevector <8 x i64> %.splatinsert220, <8 x i64> poison, <8 x i32> zeroinitializer
  %197 = mul <8 x i64> %.splat221, splat (i64 4)
  %198 = add <8 x i64> %196, %197
  %199 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %195, 0
  %200 = insertvalue { <8 x ptr>, <8 x i64> } %199, <8 x i64> %198, 1
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %200, 0
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %200, 1
  %203 = getelementptr i8, <8 x ptr> %201, <8 x i64> %202
  %204 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %203, <8 x i1> %71, <8 x float> zeroinitializer)
  %205 = fmul <8 x float> %181, %204
  %.state222 = load <8 x float>, ptr %.slot43, align 32
  %206 = fadd <8 x float> %.state222, %205
  %.state223 = load i64, ptr %.slot41, align 4
  %207 = add i64 256, %.state223
  %tile_snapshot.spill.load224 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load224, 1
  %.splatinsert225 = insertelement <8 x i64> poison, i64 %207, i64 0
  %.splat226 = shufflevector <8 x i64> %.splatinsert225, <8 x i64> poison, <8 x i32> zeroinitializer
  %210 = mul <8 x i64> %.splat226, splat (i64 4)
  %211 = add <8 x i64> %209, %210
  %212 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %208, 0
  %213 = insertvalue { <8 x ptr>, <8 x i64> } %212, <8 x i64> %211, 1
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %213, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %213, 1
  %216 = getelementptr i8, <8 x ptr> %214, <8 x i64> %215
  %217 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %216, <8 x i1> %71, <8 x float> zeroinitializer)
  %218 = fmul <8 x float> %181, %217
  %.state227 = load <8 x float>, ptr %.slot44, align 32
  %219 = fadd <8 x float> %.state227, %218
  %.state228 = load i64, ptr %.slot41, align 4
  %220 = add i64 384, %.state228
  %tile_snapshot.spill.load229 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 0
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 1
  %.splatinsert230 = insertelement <8 x i64> poison, i64 %220, i64 0
  %.splat231 = shufflevector <8 x i64> %.splatinsert230, <8 x i64> poison, <8 x i32> zeroinitializer
  %223 = mul <8 x i64> %.splat231, splat (i64 4)
  %224 = add <8 x i64> %222, %223
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %221, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %226, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = getelementptr i8, <8 x ptr> %227, <8 x i64> %228
  %230 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %229, <8 x i1> %71, <8 x float> zeroinitializer)
  %231 = fmul <8 x float> %181, %230
  %.state232 = load <8 x float>, ptr %.slot45, align 32
  %232 = fadd <8 x float> %.state232, %231
  %.state233 = load i64, ptr %.slot41, align 4
  %233 = add i64 %.state233, 1
  store i64 %233, ptr %.slot41, align 4
  %234 = load <8 x float>, ptr %.slot42, align 32
  %235 = select <8 x i1> %71, <8 x float> %193, <8 x float> %234
  store <8 x float> %235, ptr %.slot42, align 32
  %236 = load <8 x float>, ptr %.slot43, align 32
  %237 = select <8 x i1> %71, <8 x float> %206, <8 x float> %236
  store <8 x float> %237, ptr %.slot43, align 32
  %238 = load <8 x float>, ptr %.slot44, align 32
  %239 = select <8 x i1> %71, <8 x float> %219, <8 x float> %238
  store <8 x float> %239, ptr %.slot44, align 32
  %240 = load <8 x float>, ptr %.slot45, align 32
  %241 = select <8 x i1> %71, <8 x float> %232, <8 x float> %240
  store <8 x float> %241, ptr %.slot45, align 32
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false209
  store i64 0, ptr %.slot46, align 4
  %242 = load <8 x float>, ptr %.slot47, align 32
  %243 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %242
  store <8 x float> %243, ptr %.slot47, align 32
  %244 = load <8 x float>, ptr %.slot48, align 32
  %245 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %244
  store <8 x float> %245, ptr %.slot48, align 32
  %246 = load <8 x float>, ptr %.slot49, align 32
  %247 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %246
  store <8 x float> %247, ptr %.slot49, align 32
  %248 = load <8 x float>, ptr %.slot50, align 32
  %249 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %248
  store <8 x float> %249, ptr %.slot50, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state234 = load i64, ptr %.slot46, align 4
  %250 = icmp slt i64 %.state234, 128
  br i1 %250, label %direct.true235, label %direct.false236

direct.schedule.14:                               ; preds = %direct.true235
  %.state237 = load i64, ptr %.slot46, align 4
  %251 = add i64 0, %.state237
  %tile_snapshot.spill.load238 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load238, 0
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load238, 1
  %.splatinsert239 = insertelement <8 x i64> poison, i64 %251, i64 0
  %.splat240 = shufflevector <8 x i64> %.splatinsert239, <8 x i64> poison, <8 x i32> zeroinitializer
  %254 = mul <8 x i64> %.splat240, splat (i64 4)
  %255 = add <8 x i64> %253, %254
  %256 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %252, 0
  %257 = insertvalue { <8 x ptr>, <8 x i64> } %256, <8 x i64> %255, 1
  %258 = extractvalue { <8 x ptr>, <8 x i64> } %257, 0
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %257, 1
  %260 = getelementptr i8, <8 x ptr> %258, <8 x i64> %259
  %261 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %260, <8 x i1> %71, <8 x float> zeroinitializer)
  %.state241 = load i64, ptr %.slot46, align 4
  %262 = add i64 512, %.state241
  %tile_snapshot.spill.load242 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 0
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 1
  %.splatinsert243 = insertelement <8 x i64> poison, i64 %262, i64 0
  %.splat244 = shufflevector <8 x i64> %.splatinsert243, <8 x i64> poison, <8 x i32> zeroinitializer
  %265 = mul <8 x i64> %.splat244, splat (i64 4)
  %266 = add <8 x i64> %264, %265
  %267 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %263, 0
  %268 = insertvalue { <8 x ptr>, <8 x i64> } %267, <8 x i64> %266, 1
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %268, 0
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %268, 1
  %271 = getelementptr i8, <8 x ptr> %269, <8 x i64> %270
  %272 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %271, <8 x i1> %71, <8 x float> zeroinitializer)
  %273 = fmul <8 x float> %261, %272
  %.state245 = load <8 x float>, ptr %.slot47, align 32
  %274 = fadd <8 x float> %.state245, %273
  %.state246 = load i64, ptr %.slot46, align 4
  %275 = add i64 640, %.state246
  %tile_snapshot.spill.load247 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 0
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 1
  %.splatinsert248 = insertelement <8 x i64> poison, i64 %275, i64 0
  %.splat249 = shufflevector <8 x i64> %.splatinsert248, <8 x i64> poison, <8 x i32> zeroinitializer
  %278 = mul <8 x i64> %.splat249, splat (i64 4)
  %279 = add <8 x i64> %277, %278
  %280 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %276, 0
  %281 = insertvalue { <8 x ptr>, <8 x i64> } %280, <8 x i64> %279, 1
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %281, 0
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %281, 1
  %284 = getelementptr i8, <8 x ptr> %282, <8 x i64> %283
  %285 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %284, <8 x i1> %71, <8 x float> zeroinitializer)
  %286 = fmul <8 x float> %261, %285
  %.state250 = load <8 x float>, ptr %.slot48, align 32
  %287 = fadd <8 x float> %.state250, %286
  %.state251 = load i64, ptr %.slot46, align 4
  %288 = add i64 768, %.state251
  %tile_snapshot.spill.load252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %289 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 0
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 1
  %.splatinsert253 = insertelement <8 x i64> poison, i64 %288, i64 0
  %.splat254 = shufflevector <8 x i64> %.splatinsert253, <8 x i64> poison, <8 x i32> zeroinitializer
  %291 = mul <8 x i64> %.splat254, splat (i64 4)
  %292 = add <8 x i64> %290, %291
  %293 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %289, 0
  %294 = insertvalue { <8 x ptr>, <8 x i64> } %293, <8 x i64> %292, 1
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %294, 0
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %294, 1
  %297 = getelementptr i8, <8 x ptr> %295, <8 x i64> %296
  %298 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %297, <8 x i1> %71, <8 x float> zeroinitializer)
  %299 = fmul <8 x float> %261, %298
  %.state255 = load <8 x float>, ptr %.slot49, align 32
  %300 = fadd <8 x float> %.state255, %299
  %.state256 = load i64, ptr %.slot46, align 4
  %301 = add i64 896, %.state256
  %tile_snapshot.spill.load257 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 0
  %303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 1
  %.splatinsert258 = insertelement <8 x i64> poison, i64 %301, i64 0
  %.splat259 = shufflevector <8 x i64> %.splatinsert258, <8 x i64> poison, <8 x i32> zeroinitializer
  %304 = mul <8 x i64> %.splat259, splat (i64 4)
  %305 = add <8 x i64> %303, %304
  %306 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %302, 0
  %307 = insertvalue { <8 x ptr>, <8 x i64> } %306, <8 x i64> %305, 1
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %307, 0
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %307, 1
  %310 = getelementptr i8, <8 x ptr> %308, <8 x i64> %309
  %311 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %310, <8 x i1> %71, <8 x float> zeroinitializer)
  %312 = fmul <8 x float> %261, %311
  %.state260 = load <8 x float>, ptr %.slot50, align 32
  %313 = fadd <8 x float> %.state260, %312
  %.state261 = load i64, ptr %.slot46, align 4
  %314 = add i64 %.state261, 1
  store i64 %314, ptr %.slot46, align 4
  %315 = load <8 x float>, ptr %.slot47, align 32
  %316 = select <8 x i1> %71, <8 x float> %274, <8 x float> %315
  store <8 x float> %316, ptr %.slot47, align 32
  %317 = load <8 x float>, ptr %.slot48, align 32
  %318 = select <8 x i1> %71, <8 x float> %287, <8 x float> %317
  store <8 x float> %318, ptr %.slot48, align 32
  %319 = load <8 x float>, ptr %.slot49, align 32
  %320 = select <8 x i1> %71, <8 x float> %300, <8 x float> %319
  store <8 x float> %320, ptr %.slot49, align 32
  %321 = load <8 x float>, ptr %.slot50, align 32
  %322 = select <8 x i1> %71, <8 x float> %313, <8 x float> %321
  store <8 x float> %322, ptr %.slot50, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false236
  store i64 0, ptr %.slot51, align 4
  %323 = load <8 x float>, ptr %.slot52, align 32
  %324 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %323
  store <8 x float> %324, ptr %.slot52, align 32
  %325 = load <8 x float>, ptr %.slot53, align 32
  %326 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %325
  store <8 x float> %326, ptr %.slot53, align 32
  %327 = load <8 x float>, ptr %.slot54, align 32
  %328 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %327
  store <8 x float> %328, ptr %.slot54, align 32
  %329 = load <8 x float>, ptr %.slot55, align 32
  %330 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %329
  store <8 x float> %330, ptr %.slot55, align 32
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state262 = load i64, ptr %.slot51, align 4
  %331 = icmp slt i64 %.state262, 128
  br i1 %331, label %direct.true263, label %direct.false264

direct.schedule.17:                               ; preds = %direct.true263
  %.state265 = load i64, ptr %.slot51, align 4
  %332 = add i64 0, %.state265
  %tile_snapshot.spill.load266 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 0
  %334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 1
  %.splatinsert267 = insertelement <8 x i64> poison, i64 %332, i64 0
  %.splat268 = shufflevector <8 x i64> %.splatinsert267, <8 x i64> poison, <8 x i32> zeroinitializer
  %335 = mul <8 x i64> %.splat268, splat (i64 4)
  %336 = add <8 x i64> %334, %335
  %337 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %333, 0
  %338 = insertvalue { <8 x ptr>, <8 x i64> } %337, <8 x i64> %336, 1
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %338, 0
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %338, 1
  %341 = getelementptr i8, <8 x ptr> %339, <8 x i64> %340
  %342 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %341, <8 x i1> %71, <8 x float> zeroinitializer)
  %.state269 = load i64, ptr %.slot51, align 4
  %343 = add i64 1024, %.state269
  %tile_snapshot.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %.splatinsert271 = insertelement <8 x i64> poison, i64 %343, i64 0
  %.splat272 = shufflevector <8 x i64> %.splatinsert271, <8 x i64> poison, <8 x i32> zeroinitializer
  %346 = mul <8 x i64> %.splat272, splat (i64 4)
  %347 = add <8 x i64> %345, %346
  %348 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %344, 0
  %349 = insertvalue { <8 x ptr>, <8 x i64> } %348, <8 x i64> %347, 1
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %349, 0
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %349, 1
  %352 = getelementptr i8, <8 x ptr> %350, <8 x i64> %351
  %353 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %352, <8 x i1> %71, <8 x float> zeroinitializer)
  %354 = fmul <8 x float> %342, %353
  %.state273 = load <8 x float>, ptr %.slot52, align 32
  %355 = fadd <8 x float> %.state273, %354
  %.state274 = load i64, ptr %.slot51, align 4
  %356 = add i64 1152, %.state274
  %tile_snapshot.spill.load275 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %357 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load275, 0
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load275, 1
  %.splatinsert276 = insertelement <8 x i64> poison, i64 %356, i64 0
  %.splat277 = shufflevector <8 x i64> %.splatinsert276, <8 x i64> poison, <8 x i32> zeroinitializer
  %359 = mul <8 x i64> %.splat277, splat (i64 4)
  %360 = add <8 x i64> %358, %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %362, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %362, 1
  %365 = getelementptr i8, <8 x ptr> %363, <8 x i64> %364
  %366 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %365, <8 x i1> %71, <8 x float> zeroinitializer)
  %367 = fmul <8 x float> %342, %366
  %.state278 = load <8 x float>, ptr %.slot53, align 32
  %368 = fadd <8 x float> %.state278, %367
  %.state279 = load i64, ptr %.slot51, align 4
  %369 = add i64 1280, %.state279
  %tile_snapshot.spill.load280 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %.splatinsert281 = insertelement <8 x i64> poison, i64 %369, i64 0
  %.splat282 = shufflevector <8 x i64> %.splatinsert281, <8 x i64> poison, <8 x i32> zeroinitializer
  %372 = mul <8 x i64> %.splat282, splat (i64 4)
  %373 = add <8 x i64> %371, %372
  %374 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %370, 0
  %375 = insertvalue { <8 x ptr>, <8 x i64> } %374, <8 x i64> %373, 1
  %376 = extractvalue { <8 x ptr>, <8 x i64> } %375, 0
  %377 = extractvalue { <8 x ptr>, <8 x i64> } %375, 1
  %378 = getelementptr i8, <8 x ptr> %376, <8 x i64> %377
  %379 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %378, <8 x i1> %71, <8 x float> zeroinitializer)
  %380 = fmul <8 x float> %342, %379
  %.state283 = load <8 x float>, ptr %.slot54, align 32
  %381 = fadd <8 x float> %.state283, %380
  %.state284 = load i64, ptr %.slot51, align 4
  %382 = add i64 1408, %.state284
  %tile_snapshot.spill.load285 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 0
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 1
  %.splatinsert286 = insertelement <8 x i64> poison, i64 %382, i64 0
  %.splat287 = shufflevector <8 x i64> %.splatinsert286, <8 x i64> poison, <8 x i32> zeroinitializer
  %385 = mul <8 x i64> %.splat287, splat (i64 4)
  %386 = add <8 x i64> %384, %385
  %387 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %383, 0
  %388 = insertvalue { <8 x ptr>, <8 x i64> } %387, <8 x i64> %386, 1
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %388, 0
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %388, 1
  %391 = getelementptr i8, <8 x ptr> %389, <8 x i64> %390
  %392 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %391, <8 x i1> %71, <8 x float> zeroinitializer)
  %393 = fmul <8 x float> %342, %392
  %.state288 = load <8 x float>, ptr %.slot55, align 32
  %394 = fadd <8 x float> %.state288, %393
  %.state289 = load i64, ptr %.slot51, align 4
  %395 = add i64 %.state289, 1
  store i64 %395, ptr %.slot51, align 4
  %396 = load <8 x float>, ptr %.slot52, align 32
  %397 = select <8 x i1> %71, <8 x float> %355, <8 x float> %396
  store <8 x float> %397, ptr %.slot52, align 32
  %398 = load <8 x float>, ptr %.slot53, align 32
  %399 = select <8 x i1> %71, <8 x float> %368, <8 x float> %398
  store <8 x float> %399, ptr %.slot53, align 32
  %400 = load <8 x float>, ptr %.slot54, align 32
  %401 = select <8 x i1> %71, <8 x float> %381, <8 x float> %400
  store <8 x float> %401, ptr %.slot54, align 32
  %402 = load <8 x float>, ptr %.slot55, align 32
  %403 = select <8 x i1> %71, <8 x float> %394, <8 x float> %402
  store <8 x float> %403, ptr %.slot55, align 32
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false264
  store i64 0, ptr %.slot56, align 4
  %404 = load <8 x float>, ptr %.slot57, align 32
  %405 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %404
  store <8 x float> %405, ptr %.slot57, align 32
  %406 = load <8 x float>, ptr %.slot58, align 32
  %407 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %406
  store <8 x float> %407, ptr %.slot58, align 32
  %408 = load <8 x float>, ptr %.slot59, align 32
  %409 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %408
  store <8 x float> %409, ptr %.slot59, align 32
  %410 = load <8 x float>, ptr %.slot60, align 32
  %411 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %410
  store <8 x float> %411, ptr %.slot60, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state290 = load i64, ptr %.slot56, align 4
  %412 = icmp slt i64 %.state290, 128
  br i1 %412, label %direct.true291, label %direct.false292

direct.schedule.20:                               ; preds = %direct.true291
  %.state293 = load i64, ptr %.slot56, align 4
  %413 = add i64 0, %.state293
  %tile_snapshot.spill.load294 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 0
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 1
  %.splatinsert295 = insertelement <8 x i64> poison, i64 %413, i64 0
  %.splat296 = shufflevector <8 x i64> %.splatinsert295, <8 x i64> poison, <8 x i32> zeroinitializer
  %416 = mul <8 x i64> %.splat296, splat (i64 4)
  %417 = add <8 x i64> %415, %416
  %418 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %414, 0
  %419 = insertvalue { <8 x ptr>, <8 x i64> } %418, <8 x i64> %417, 1
  %420 = extractvalue { <8 x ptr>, <8 x i64> } %419, 0
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %419, 1
  %422 = getelementptr i8, <8 x ptr> %420, <8 x i64> %421
  %423 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %422, <8 x i1> %71, <8 x float> zeroinitializer)
  %.state297 = load i64, ptr %.slot56, align 4
  %424 = add i64 1536, %.state297
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %.splatinsert299 = insertelement <8 x i64> poison, i64 %424, i64 0
  %.splat300 = shufflevector <8 x i64> %.splatinsert299, <8 x i64> poison, <8 x i32> zeroinitializer
  %427 = mul <8 x i64> %.splat300, splat (i64 4)
  %428 = add <8 x i64> %426, %427
  %429 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %425, 0
  %430 = insertvalue { <8 x ptr>, <8 x i64> } %429, <8 x i64> %428, 1
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %430, 0
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %430, 1
  %433 = getelementptr i8, <8 x ptr> %431, <8 x i64> %432
  %434 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %433, <8 x i1> %71, <8 x float> zeroinitializer)
  %435 = fmul <8 x float> %423, %434
  %.state301 = load <8 x float>, ptr %.slot57, align 32
  %436 = fadd <8 x float> %.state301, %435
  %.state302 = load i64, ptr %.slot56, align 4
  %437 = add i64 1664, %.state302
  %tile_snapshot.spill.load303 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load303, 0
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load303, 1
  %.splatinsert304 = insertelement <8 x i64> poison, i64 %437, i64 0
  %.splat305 = shufflevector <8 x i64> %.splatinsert304, <8 x i64> poison, <8 x i32> zeroinitializer
  %440 = mul <8 x i64> %.splat305, splat (i64 4)
  %441 = add <8 x i64> %439, %440
  %442 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %438, 0
  %443 = insertvalue { <8 x ptr>, <8 x i64> } %442, <8 x i64> %441, 1
  %444 = extractvalue { <8 x ptr>, <8 x i64> } %443, 0
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %443, 1
  %446 = getelementptr i8, <8 x ptr> %444, <8 x i64> %445
  %447 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %446, <8 x i1> %71, <8 x float> zeroinitializer)
  %448 = fmul <8 x float> %423, %447
  %.state306 = load <8 x float>, ptr %.slot58, align 32
  %449 = fadd <8 x float> %.state306, %448
  %.state307 = load i64, ptr %.slot56, align 4
  %450 = add i64 1792, %.state307
  %tile_snapshot.spill.load308 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 0
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load308, 1
  %.splatinsert309 = insertelement <8 x i64> poison, i64 %450, i64 0
  %.splat310 = shufflevector <8 x i64> %.splatinsert309, <8 x i64> poison, <8 x i32> zeroinitializer
  %453 = mul <8 x i64> %.splat310, splat (i64 4)
  %454 = add <8 x i64> %452, %453
  %455 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %451, 0
  %456 = insertvalue { <8 x ptr>, <8 x i64> } %455, <8 x i64> %454, 1
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %456, 0
  %458 = extractvalue { <8 x ptr>, <8 x i64> } %456, 1
  %459 = getelementptr i8, <8 x ptr> %457, <8 x i64> %458
  %460 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %459, <8 x i1> %71, <8 x float> zeroinitializer)
  %461 = fmul <8 x float> %423, %460
  %.state311 = load <8 x float>, ptr %.slot59, align 32
  %462 = fadd <8 x float> %.state311, %461
  %.state312 = load i64, ptr %.slot56, align 4
  %463 = add i64 1920, %.state312
  %tile_snapshot.spill.load313 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load313, 0
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load313, 1
  %.splatinsert314 = insertelement <8 x i64> poison, i64 %463, i64 0
  %.splat315 = shufflevector <8 x i64> %.splatinsert314, <8 x i64> poison, <8 x i32> zeroinitializer
  %466 = mul <8 x i64> %.splat315, splat (i64 4)
  %467 = add <8 x i64> %465, %466
  %468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %464, 0
  %469 = insertvalue { <8 x ptr>, <8 x i64> } %468, <8 x i64> %467, 1
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %469, 0
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %469, 1
  %472 = getelementptr i8, <8 x ptr> %470, <8 x i64> %471
  %473 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %472, <8 x i1> %71, <8 x float> zeroinitializer)
  %474 = fmul <8 x float> %423, %473
  %.state316 = load <8 x float>, ptr %.slot60, align 32
  %475 = fadd <8 x float> %.state316, %474
  %.state317 = load i64, ptr %.slot56, align 4
  %476 = add i64 %.state317, 1
  store i64 %476, ptr %.slot56, align 4
  %477 = load <8 x float>, ptr %.slot57, align 32
  %478 = select <8 x i1> %71, <8 x float> %436, <8 x float> %477
  store <8 x float> %478, ptr %.slot57, align 32
  %479 = load <8 x float>, ptr %.slot58, align 32
  %480 = select <8 x i1> %71, <8 x float> %449, <8 x float> %479
  store <8 x float> %480, ptr %.slot58, align 32
  %481 = load <8 x float>, ptr %.slot59, align 32
  %482 = select <8 x i1> %71, <8 x float> %462, <8 x float> %481
  store <8 x float> %482, ptr %.slot59, align 32
  %483 = load <8 x float>, ptr %.slot60, align 32
  %484 = select <8 x i1> %71, <8 x float> %475, <8 x float> %483
  store <8 x float> %484, ptr %.slot60, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false292
  %.state318 = load <8 x float>, ptr %.slot42, align 32
  %485 = fmul <8 x float> %.state318, splat (float 0x3FB6A09E60000000)
  %.state319 = load <8 x float>, ptr %.slot43, align 32
  %486 = fmul <8 x float> %.state319, splat (float 0x3FB6A09E60000000)
  %.state320 = load <8 x float>, ptr %.slot44, align 32
  %487 = fmul <8 x float> %.state320, splat (float 0x3FB6A09E60000000)
  %.state321 = load <8 x float>, ptr %.slot45, align 32
  %488 = fmul <8 x float> %.state321, splat (float 0x3FB6A09E60000000)
  %.state322 = load <8 x float>, ptr %.slot47, align 32
  %489 = fmul <8 x float> %.state322, splat (float 0x3FB6A09E60000000)
  %.state323 = load <8 x float>, ptr %.slot48, align 32
  %490 = fmul <8 x float> %.state323, splat (float 0x3FB6A09E60000000)
  %.state324 = load <8 x float>, ptr %.slot49, align 32
  %491 = fmul <8 x float> %.state324, splat (float 0x3FB6A09E60000000)
  %.state325 = load <8 x float>, ptr %.slot50, align 32
  %492 = fmul <8 x float> %.state325, splat (float 0x3FB6A09E60000000)
  %.state326 = load <8 x float>, ptr %.slot52, align 32
  %493 = fmul <8 x float> %.state326, splat (float 0x3FB6A09E60000000)
  %.state327 = load <8 x float>, ptr %.slot53, align 32
  %494 = fmul <8 x float> %.state327, splat (float 0x3FB6A09E60000000)
  %.state328 = load <8 x float>, ptr %.slot54, align 32
  %495 = fmul <8 x float> %.state328, splat (float 0x3FB6A09E60000000)
  %.state329 = load <8 x float>, ptr %.slot55, align 32
  %496 = fmul <8 x float> %.state329, splat (float 0x3FB6A09E60000000)
  %.state330 = load <8 x float>, ptr %.slot57, align 32
  %497 = fmul <8 x float> %.state330, splat (float 0x3FB6A09E60000000)
  %.state331 = load <8 x float>, ptr %.slot58, align 32
  %498 = fmul <8 x float> %.state331, splat (float 0x3FB6A09E60000000)
  %.state332 = load <8 x float>, ptr %.slot59, align 32
  %499 = fmul <8 x float> %.state332, splat (float 0x3FB6A09E60000000)
  %.state333 = load <8 x float>, ptr %.slot60, align 32
  %500 = fmul <8 x float> %.state333, splat (float 0x3FB6A09E60000000)
  %.spill.load334 = load i64, ptr %.spill37, align 4
  %501 = add i64 0, %.spill.load334
  %.spill.load335 = load i64, ptr %.spill37, align 4
  %502 = add i64 1, %.spill.load335
  %.spill.load336 = load i64, ptr %.spill37, align 4
  %503 = add i64 2, %.spill.load336
  %.spill.load337 = load i64, ptr %.spill37, align 4
  %504 = add i64 3, %.spill.load337
  %.spill.load338 = load i64, ptr %.spill37, align 4
  %505 = add i64 4, %.spill.load338
  %.spill.load339 = load i64, ptr %.spill37, align 4
  %506 = add i64 5, %.spill.load339
  %.spill.load340 = load i64, ptr %.spill37, align 4
  %507 = add i64 6, %.spill.load340
  %.spill.load341 = load i64, ptr %.spill37, align 4
  %508 = add i64 7, %.spill.load341
  %.spill.load342 = load i64, ptr %.spill37, align 4
  %509 = add i64 8, %.spill.load342
  %.spill.load343 = load i64, ptr %.spill37, align 4
  %510 = add i64 9, %.spill.load343
  %.spill.load344 = load i64, ptr %.spill37, align 4
  %511 = add i64 10, %.spill.load344
  %.spill.load345 = load i64, ptr %.spill37, align 4
  %512 = add i64 11, %.spill.load345
  %.spill.load346 = load i64, ptr %.spill37, align 4
  %513 = add i64 12, %.spill.load346
  %.spill.load347 = load i64, ptr %.spill37, align 4
  %514 = add i64 13, %.spill.load347
  %.spill.load348 = load i64, ptr %.spill37, align 4
  %515 = add i64 14, %.spill.load348
  %.spill.load349 = load i64, ptr %.spill37, align 4
  %516 = add i64 15, %.spill.load349
  %517 = icmp slt i64 %501, 8193
  %518 = icmp slt i64 %502, 8193
  %519 = icmp slt i64 %503, 8193
  %520 = icmp slt i64 %504, 8193
  %521 = icmp slt i64 %505, 8193
  %522 = icmp slt i64 %506, 8193
  %523 = icmp slt i64 %507, 8193
  %524 = icmp slt i64 %508, 8193
  %525 = icmp slt i64 %509, 8193
  %526 = icmp slt i64 %510, 8193
  %527 = icmp slt i64 %511, 8193
  %528 = icmp slt i64 %512, 8193
  %529 = icmp slt i64 %513, 8193
  %530 = icmp slt i64 %514, 8193
  %531 = icmp slt i64 %515, 8193
  %532 = icmp slt i64 %516, 8193
  %.spill.load350 = load i64, ptr %.spill31, align 4
  %533 = add i64 %.spill.load350, 8193
  %534 = sub i64 %533, 1
  %535 = icmp sle i64 %501, %534
  %536 = icmp sle i64 %502, %534
  %537 = icmp sle i64 %503, %534
  %538 = icmp sle i64 %504, %534
  %539 = icmp sle i64 %505, %534
  %540 = icmp sle i64 %506, %534
  %541 = icmp sle i64 %507, %534
  %542 = icmp sle i64 %508, %534
  %543 = icmp sle i64 %509, %534
  %544 = icmp sle i64 %510, %534
  %545 = icmp sle i64 %511, %534
  %546 = icmp sle i64 %512, %534
  %547 = icmp sle i64 %513, %534
  %548 = icmp sle i64 %514, %534
  %549 = icmp sle i64 %515, %534
  %550 = icmp sle i64 %516, %534
  %551 = and i1 %517, %535
  store i1 %551, ptr %.spill61, align 1
  %552 = and i1 %518, %536
  store i1 %552, ptr %.spill62, align 1
  %553 = and i1 %519, %537
  store i1 %553, ptr %.spill63, align 1
  %554 = and i1 %520, %538
  store i1 %554, ptr %.spill64, align 1
  %555 = and i1 %521, %539
  store i1 %555, ptr %.spill65, align 1
  %556 = and i1 %522, %540
  store i1 %556, ptr %.spill66, align 1
  %557 = and i1 %523, %541
  store i1 %557, ptr %.spill67, align 1
  %558 = and i1 %524, %542
  store i1 %558, ptr %.spill68, align 1
  %559 = and i1 %525, %543
  store i1 %559, ptr %.spill69, align 1
  %560 = and i1 %526, %544
  store i1 %560, ptr %.spill70, align 1
  %561 = and i1 %527, %545
  store i1 %561, ptr %.spill71, align 1
  %562 = and i1 %528, %546
  store i1 %562, ptr %.spill72, align 1
  %563 = and i1 %529, %547
  store i1 %563, ptr %.spill73, align 1
  %564 = and i1 %530, %548
  store i1 %564, ptr %.spill74, align 1
  %565 = and i1 %531, %549
  store i1 %565, ptr %.spill75, align 1
  %566 = and i1 %532, %550
  store i1 %566, ptr %.spill76, align 1
  %.splatinsert351 = insertelement <8 x i1> poison, i1 %551, i64 0
  %.splat352 = shufflevector <8 x i1> %.splatinsert351, <8 x i1> poison, <8 x i32> zeroinitializer
  %567 = select <8 x i1> %.splat352, <8 x float> %485, <8 x float> splat (float 0xC6293E5940000000)
  %568 = load <8 x float>, ptr %.spill77, align 32
  %569 = select <8 x i1> %71, <8 x float> %567, <8 x float> %568
  store <8 x float> %569, ptr %.spill77, align 32
  %.splatinsert353 = insertelement <8 x i1> poison, i1 %552, i64 0
  %.splat354 = shufflevector <8 x i1> %.splatinsert353, <8 x i1> poison, <8 x i32> zeroinitializer
  %570 = select <8 x i1> %.splat354, <8 x float> %486, <8 x float> splat (float 0xC6293E5940000000)
  %571 = load <8 x float>, ptr %.spill78, align 32
  %572 = select <8 x i1> %71, <8 x float> %570, <8 x float> %571
  store <8 x float> %572, ptr %.spill78, align 32
  %.splatinsert355 = insertelement <8 x i1> poison, i1 %553, i64 0
  %.splat356 = shufflevector <8 x i1> %.splatinsert355, <8 x i1> poison, <8 x i32> zeroinitializer
  %573 = select <8 x i1> %.splat356, <8 x float> %487, <8 x float> splat (float 0xC6293E5940000000)
  %574 = load <8 x float>, ptr %.spill79, align 32
  %575 = select <8 x i1> %71, <8 x float> %573, <8 x float> %574
  store <8 x float> %575, ptr %.spill79, align 32
  %.splatinsert357 = insertelement <8 x i1> poison, i1 %554, i64 0
  %.splat358 = shufflevector <8 x i1> %.splatinsert357, <8 x i1> poison, <8 x i32> zeroinitializer
  %576 = select <8 x i1> %.splat358, <8 x float> %488, <8 x float> splat (float 0xC6293E5940000000)
  %577 = load <8 x float>, ptr %.spill80, align 32
  %578 = select <8 x i1> %71, <8 x float> %576, <8 x float> %577
  store <8 x float> %578, ptr %.spill80, align 32
  %.splatinsert359 = insertelement <8 x i1> poison, i1 %555, i64 0
  %.splat360 = shufflevector <8 x i1> %.splatinsert359, <8 x i1> poison, <8 x i32> zeroinitializer
  %579 = select <8 x i1> %.splat360, <8 x float> %489, <8 x float> splat (float 0xC6293E5940000000)
  %580 = load <8 x float>, ptr %.spill81, align 32
  %581 = select <8 x i1> %71, <8 x float> %579, <8 x float> %580
  store <8 x float> %581, ptr %.spill81, align 32
  %.splatinsert361 = insertelement <8 x i1> poison, i1 %556, i64 0
  %.splat362 = shufflevector <8 x i1> %.splatinsert361, <8 x i1> poison, <8 x i32> zeroinitializer
  %582 = select <8 x i1> %.splat362, <8 x float> %490, <8 x float> splat (float 0xC6293E5940000000)
  %583 = load <8 x float>, ptr %.spill82, align 32
  %584 = select <8 x i1> %71, <8 x float> %582, <8 x float> %583
  store <8 x float> %584, ptr %.spill82, align 32
  %.splatinsert363 = insertelement <8 x i1> poison, i1 %557, i64 0
  %.splat364 = shufflevector <8 x i1> %.splatinsert363, <8 x i1> poison, <8 x i32> zeroinitializer
  %585 = select <8 x i1> %.splat364, <8 x float> %491, <8 x float> splat (float 0xC6293E5940000000)
  %586 = load <8 x float>, ptr %.spill83, align 32
  %587 = select <8 x i1> %71, <8 x float> %585, <8 x float> %586
  store <8 x float> %587, ptr %.spill83, align 32
  %.splatinsert365 = insertelement <8 x i1> poison, i1 %558, i64 0
  %.splat366 = shufflevector <8 x i1> %.splatinsert365, <8 x i1> poison, <8 x i32> zeroinitializer
  %588 = select <8 x i1> %.splat366, <8 x float> %492, <8 x float> splat (float 0xC6293E5940000000)
  %589 = load <8 x float>, ptr %.spill84, align 32
  %590 = select <8 x i1> %71, <8 x float> %588, <8 x float> %589
  store <8 x float> %590, ptr %.spill84, align 32
  %.splatinsert367 = insertelement <8 x i1> poison, i1 %559, i64 0
  %.splat368 = shufflevector <8 x i1> %.splatinsert367, <8 x i1> poison, <8 x i32> zeroinitializer
  %591 = select <8 x i1> %.splat368, <8 x float> %493, <8 x float> splat (float 0xC6293E5940000000)
  %592 = load <8 x float>, ptr %.spill85, align 32
  %593 = select <8 x i1> %71, <8 x float> %591, <8 x float> %592
  store <8 x float> %593, ptr %.spill85, align 32
  %.splatinsert369 = insertelement <8 x i1> poison, i1 %560, i64 0
  %.splat370 = shufflevector <8 x i1> %.splatinsert369, <8 x i1> poison, <8 x i32> zeroinitializer
  %594 = select <8 x i1> %.splat370, <8 x float> %494, <8 x float> splat (float 0xC6293E5940000000)
  %595 = load <8 x float>, ptr %.spill86, align 32
  %596 = select <8 x i1> %71, <8 x float> %594, <8 x float> %595
  store <8 x float> %596, ptr %.spill86, align 32
  %.splatinsert371 = insertelement <8 x i1> poison, i1 %561, i64 0
  %.splat372 = shufflevector <8 x i1> %.splatinsert371, <8 x i1> poison, <8 x i32> zeroinitializer
  %597 = select <8 x i1> %.splat372, <8 x float> %495, <8 x float> splat (float 0xC6293E5940000000)
  %598 = load <8 x float>, ptr %.spill87, align 32
  %599 = select <8 x i1> %71, <8 x float> %597, <8 x float> %598
  store <8 x float> %599, ptr %.spill87, align 32
  %.splatinsert373 = insertelement <8 x i1> poison, i1 %562, i64 0
  %.splat374 = shufflevector <8 x i1> %.splatinsert373, <8 x i1> poison, <8 x i32> zeroinitializer
  %600 = select <8 x i1> %.splat374, <8 x float> %496, <8 x float> splat (float 0xC6293E5940000000)
  %601 = load <8 x float>, ptr %.spill88, align 32
  %602 = select <8 x i1> %71, <8 x float> %600, <8 x float> %601
  store <8 x float> %602, ptr %.spill88, align 32
  %.splatinsert375 = insertelement <8 x i1> poison, i1 %563, i64 0
  %.splat376 = shufflevector <8 x i1> %.splatinsert375, <8 x i1> poison, <8 x i32> zeroinitializer
  %603 = select <8 x i1> %.splat376, <8 x float> %497, <8 x float> splat (float 0xC6293E5940000000)
  %604 = load <8 x float>, ptr %.spill89, align 32
  %605 = select <8 x i1> %71, <8 x float> %603, <8 x float> %604
  store <8 x float> %605, ptr %.spill89, align 32
  %.splatinsert377 = insertelement <8 x i1> poison, i1 %564, i64 0
  %.splat378 = shufflevector <8 x i1> %.splatinsert377, <8 x i1> poison, <8 x i32> zeroinitializer
  %606 = select <8 x i1> %.splat378, <8 x float> %498, <8 x float> splat (float 0xC6293E5940000000)
  %607 = load <8 x float>, ptr %.spill90, align 32
  %608 = select <8 x i1> %71, <8 x float> %606, <8 x float> %607
  store <8 x float> %608, ptr %.spill90, align 32
  %.splatinsert379 = insertelement <8 x i1> poison, i1 %565, i64 0
  %.splat380 = shufflevector <8 x i1> %.splatinsert379, <8 x i1> poison, <8 x i32> zeroinitializer
  %609 = select <8 x i1> %.splat380, <8 x float> %499, <8 x float> splat (float 0xC6293E5940000000)
  %610 = load <8 x float>, ptr %.spill91, align 32
  %611 = select <8 x i1> %71, <8 x float> %609, <8 x float> %610
  store <8 x float> %611, ptr %.spill91, align 32
  %.splatinsert381 = insertelement <8 x i1> poison, i1 %566, i64 0
  %.splat382 = shufflevector <8 x i1> %.splatinsert381, <8 x i1> poison, <8 x i32> zeroinitializer
  %612 = select <8 x i1> %.splat382, <8 x float> %500, <8 x float> splat (float 0xC6293E5940000000)
  %613 = load <8 x float>, ptr %.spill92, align 32
  %614 = select <8 x i1> %71, <8 x float> %612, <8 x float> %613
  store <8 x float> %614, ptr %.spill92, align 32
  %615 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %615, 0
  %618 = select <8 x i1> %71, <8 x ptr> %616, <8 x ptr> %617
  %619 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %620 = extractvalue { <8 x ptr>, <8 x i64> } %615, 1
  %621 = select <8 x i1> %71, <8 x i64> %619, <8 x i64> %620
  %622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %618, 0
  %623 = insertvalue { <8 x ptr>, <8 x i64> } %622, <8 x i64> %621, 1
  store { <8 x ptr>, <8 x i64> } %623, ptr %tile_snapshot.spill93, align 64
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %625 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %626 = add <8 x i64> %625, zeroinitializer
  %627 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %624, 0
  %628 = insertvalue { <8 x ptr>, <8 x i64> } %627, <8 x i64> %626, 1
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %628, 1
  %631 = extractelement <8 x ptr> %629, i32 0
  %632 = extractelement <8 x i64> %630, i32 0
  %633 = sub i64 %632, 0
  %634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %635 = select i1 %634, i64 %633, i64 0
  %private.contiguous.address383 = getelementptr i8, ptr %631, i64 %635
  %private.contiguous.preserve384 = load <8 x float>, ptr %private.contiguous.address383, align 4
  %636 = select <8 x i1> %71, <8 x float> %567, <8 x float> %private.contiguous.preserve384
  store <8 x float> %636, ptr %private.contiguous.address383, align 4
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %639 = add <8 x i64> %638, splat (i64 32)
  %640 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %637, 0
  %641 = insertvalue { <8 x ptr>, <8 x i64> } %640, <8 x i64> %639, 1
  %642 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %641, 1
  %644 = extractelement <8 x ptr> %642, i32 0
  %645 = extractelement <8 x i64> %643, i32 0
  %646 = sub i64 %645, 0
  %647 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %648 = select i1 %647, i64 %646, i64 0
  %private.contiguous.address385 = getelementptr i8, ptr %644, i64 %648
  %private.contiguous.preserve386 = load <8 x float>, ptr %private.contiguous.address385, align 4
  %649 = select <8 x i1> %71, <8 x float> %570, <8 x float> %private.contiguous.preserve386
  store <8 x float> %649, ptr %private.contiguous.address385, align 4
  %650 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %651 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %652 = add <8 x i64> %651, splat (i64 64)
  %653 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %650, 0
  %654 = insertvalue { <8 x ptr>, <8 x i64> } %653, <8 x i64> %652, 1
  %655 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %656 = extractvalue { <8 x ptr>, <8 x i64> } %654, 1
  %657 = extractelement <8 x ptr> %655, i32 0
  %658 = extractelement <8 x i64> %656, i32 0
  %659 = sub i64 %658, 0
  %660 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %661 = select i1 %660, i64 %659, i64 0
  %private.contiguous.address387 = getelementptr i8, ptr %657, i64 %661
  %private.contiguous.preserve388 = load <8 x float>, ptr %private.contiguous.address387, align 4
  %662 = select <8 x i1> %71, <8 x float> %573, <8 x float> %private.contiguous.preserve388
  store <8 x float> %662, ptr %private.contiguous.address387, align 4
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %664 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %665 = add <8 x i64> %664, splat (i64 96)
  %666 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %663, 0
  %667 = insertvalue { <8 x ptr>, <8 x i64> } %666, <8 x i64> %665, 1
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %667, 1
  %670 = extractelement <8 x ptr> %668, i32 0
  %671 = extractelement <8 x i64> %669, i32 0
  %672 = sub i64 %671, 0
  %673 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %674 = select i1 %673, i64 %672, i64 0
  %private.contiguous.address389 = getelementptr i8, ptr %670, i64 %674
  %private.contiguous.preserve390 = load <8 x float>, ptr %private.contiguous.address389, align 4
  %675 = select <8 x i1> %71, <8 x float> %576, <8 x float> %private.contiguous.preserve390
  store <8 x float> %675, ptr %private.contiguous.address389, align 4
  %676 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %677 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %678 = add <8 x i64> %677, splat (i64 128)
  %679 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %676, 0
  %680 = insertvalue { <8 x ptr>, <8 x i64> } %679, <8 x i64> %678, 1
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %682 = extractvalue { <8 x ptr>, <8 x i64> } %680, 1
  %683 = extractelement <8 x ptr> %681, i32 0
  %684 = extractelement <8 x i64> %682, i32 0
  %685 = sub i64 %684, 0
  %686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %687 = select i1 %686, i64 %685, i64 0
  %private.contiguous.address391 = getelementptr i8, ptr %683, i64 %687
  %private.contiguous.preserve392 = load <8 x float>, ptr %private.contiguous.address391, align 4
  %688 = select <8 x i1> %71, <8 x float> %579, <8 x float> %private.contiguous.preserve392
  store <8 x float> %688, ptr %private.contiguous.address391, align 4
  %689 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %690 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %691 = add <8 x i64> %690, splat (i64 160)
  %692 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %689, 0
  %693 = insertvalue { <8 x ptr>, <8 x i64> } %692, <8 x i64> %691, 1
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %695 = extractvalue { <8 x ptr>, <8 x i64> } %693, 1
  %696 = extractelement <8 x ptr> %694, i32 0
  %697 = extractelement <8 x i64> %695, i32 0
  %698 = sub i64 %697, 0
  %699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %700 = select i1 %699, i64 %698, i64 0
  %private.contiguous.address393 = getelementptr i8, ptr %696, i64 %700
  %private.contiguous.preserve394 = load <8 x float>, ptr %private.contiguous.address393, align 4
  %701 = select <8 x i1> %71, <8 x float> %582, <8 x float> %private.contiguous.preserve394
  store <8 x float> %701, ptr %private.contiguous.address393, align 4
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %703 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %704 = add <8 x i64> %703, splat (i64 192)
  %705 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %702, 0
  %706 = insertvalue { <8 x ptr>, <8 x i64> } %705, <8 x i64> %704, 1
  %707 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %708 = extractvalue { <8 x ptr>, <8 x i64> } %706, 1
  %709 = extractelement <8 x ptr> %707, i32 0
  %710 = extractelement <8 x i64> %708, i32 0
  %711 = sub i64 %710, 0
  %712 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %713 = select i1 %712, i64 %711, i64 0
  %private.contiguous.address395 = getelementptr i8, ptr %709, i64 %713
  %private.contiguous.preserve396 = load <8 x float>, ptr %private.contiguous.address395, align 4
  %714 = select <8 x i1> %71, <8 x float> %585, <8 x float> %private.contiguous.preserve396
  store <8 x float> %714, ptr %private.contiguous.address395, align 4
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %717 = add <8 x i64> %716, splat (i64 224)
  %718 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %715, 0
  %719 = insertvalue { <8 x ptr>, <8 x i64> } %718, <8 x i64> %717, 1
  %720 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %719, 1
  %722 = extractelement <8 x ptr> %720, i32 0
  %723 = extractelement <8 x i64> %721, i32 0
  %724 = sub i64 %723, 0
  %725 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %726 = select i1 %725, i64 %724, i64 0
  %private.contiguous.address397 = getelementptr i8, ptr %722, i64 %726
  %private.contiguous.preserve398 = load <8 x float>, ptr %private.contiguous.address397, align 4
  %727 = select <8 x i1> %71, <8 x float> %588, <8 x float> %private.contiguous.preserve398
  store <8 x float> %727, ptr %private.contiguous.address397, align 4
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %730 = add <8 x i64> %729, splat (i64 256)
  %731 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %728, 0
  %732 = insertvalue { <8 x ptr>, <8 x i64> } %731, <8 x i64> %730, 1
  %733 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %734 = extractvalue { <8 x ptr>, <8 x i64> } %732, 1
  %735 = extractelement <8 x ptr> %733, i32 0
  %736 = extractelement <8 x i64> %734, i32 0
  %737 = sub i64 %736, 0
  %738 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %739 = select i1 %738, i64 %737, i64 0
  %private.contiguous.address399 = getelementptr i8, ptr %735, i64 %739
  %private.contiguous.preserve400 = load <8 x float>, ptr %private.contiguous.address399, align 4
  %740 = select <8 x i1> %71, <8 x float> %591, <8 x float> %private.contiguous.preserve400
  store <8 x float> %740, ptr %private.contiguous.address399, align 4
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %743 = add <8 x i64> %742, splat (i64 288)
  %744 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %741, 0
  %745 = insertvalue { <8 x ptr>, <8 x i64> } %744, <8 x i64> %743, 1
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %747 = extractvalue { <8 x ptr>, <8 x i64> } %745, 1
  %748 = extractelement <8 x ptr> %746, i32 0
  %749 = extractelement <8 x i64> %747, i32 0
  %750 = sub i64 %749, 0
  %751 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %752 = select i1 %751, i64 %750, i64 0
  %private.contiguous.address401 = getelementptr i8, ptr %748, i64 %752
  %private.contiguous.preserve402 = load <8 x float>, ptr %private.contiguous.address401, align 4
  %753 = select <8 x i1> %71, <8 x float> %594, <8 x float> %private.contiguous.preserve402
  store <8 x float> %753, ptr %private.contiguous.address401, align 4
  %754 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %755 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %756 = add <8 x i64> %755, splat (i64 320)
  %757 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %754, 0
  %758 = insertvalue { <8 x ptr>, <8 x i64> } %757, <8 x i64> %756, 1
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %758, 1
  %761 = extractelement <8 x ptr> %759, i32 0
  %762 = extractelement <8 x i64> %760, i32 0
  %763 = sub i64 %762, 0
  %764 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %765 = select i1 %764, i64 %763, i64 0
  %private.contiguous.address403 = getelementptr i8, ptr %761, i64 %765
  %private.contiguous.preserve404 = load <8 x float>, ptr %private.contiguous.address403, align 4
  %766 = select <8 x i1> %71, <8 x float> %597, <8 x float> %private.contiguous.preserve404
  store <8 x float> %766, ptr %private.contiguous.address403, align 4
  %767 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %768 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %769 = add <8 x i64> %768, splat (i64 352)
  %770 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %767, 0
  %771 = insertvalue { <8 x ptr>, <8 x i64> } %770, <8 x i64> %769, 1
  %772 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %773 = extractvalue { <8 x ptr>, <8 x i64> } %771, 1
  %774 = extractelement <8 x ptr> %772, i32 0
  %775 = extractelement <8 x i64> %773, i32 0
  %776 = sub i64 %775, 0
  %777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %778 = select i1 %777, i64 %776, i64 0
  %private.contiguous.address405 = getelementptr i8, ptr %774, i64 %778
  %private.contiguous.preserve406 = load <8 x float>, ptr %private.contiguous.address405, align 4
  %779 = select <8 x i1> %71, <8 x float> %600, <8 x float> %private.contiguous.preserve406
  store <8 x float> %779, ptr %private.contiguous.address405, align 4
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %782 = add <8 x i64> %781, splat (i64 384)
  %783 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %780, 0
  %784 = insertvalue { <8 x ptr>, <8 x i64> } %783, <8 x i64> %782, 1
  %785 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %786 = extractvalue { <8 x ptr>, <8 x i64> } %784, 1
  %787 = extractelement <8 x ptr> %785, i32 0
  %788 = extractelement <8 x i64> %786, i32 0
  %789 = sub i64 %788, 0
  %790 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %791 = select i1 %790, i64 %789, i64 0
  %private.contiguous.address407 = getelementptr i8, ptr %787, i64 %791
  %private.contiguous.preserve408 = load <8 x float>, ptr %private.contiguous.address407, align 4
  %792 = select <8 x i1> %71, <8 x float> %603, <8 x float> %private.contiguous.preserve408
  store <8 x float> %792, ptr %private.contiguous.address407, align 4
  %793 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %795 = add <8 x i64> %794, splat (i64 416)
  %796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %793, 0
  %797 = insertvalue { <8 x ptr>, <8 x i64> } %796, <8 x i64> %795, 1
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %797, 1
  %800 = extractelement <8 x ptr> %798, i32 0
  %801 = extractelement <8 x i64> %799, i32 0
  %802 = sub i64 %801, 0
  %803 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %804 = select i1 %803, i64 %802, i64 0
  %private.contiguous.address409 = getelementptr i8, ptr %800, i64 %804
  %private.contiguous.preserve410 = load <8 x float>, ptr %private.contiguous.address409, align 4
  %805 = select <8 x i1> %71, <8 x float> %606, <8 x float> %private.contiguous.preserve410
  store <8 x float> %805, ptr %private.contiguous.address409, align 4
  %806 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %808 = add <8 x i64> %807, splat (i64 448)
  %809 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %806, 0
  %810 = insertvalue { <8 x ptr>, <8 x i64> } %809, <8 x i64> %808, 1
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %810, 1
  %813 = extractelement <8 x ptr> %811, i32 0
  %814 = extractelement <8 x i64> %812, i32 0
  %815 = sub i64 %814, 0
  %816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %817 = select i1 %816, i64 %815, i64 0
  %private.contiguous.address411 = getelementptr i8, ptr %813, i64 %817
  %private.contiguous.preserve412 = load <8 x float>, ptr %private.contiguous.address411, align 4
  %818 = select <8 x i1> %71, <8 x float> %609, <8 x float> %private.contiguous.preserve412
  store <8 x float> %818, ptr %private.contiguous.address411, align 4
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %821 = add <8 x i64> %820, splat (i64 480)
  %822 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %819, 0
  %823 = insertvalue { <8 x ptr>, <8 x i64> } %822, <8 x i64> %821, 1
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %823, 1
  %826 = extractelement <8 x ptr> %824, i32 0
  %827 = extractelement <8 x i64> %825, i32 0
  %828 = sub i64 %827, 0
  %829 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %830 = select i1 %829, i64 %828, i64 0
  %private.contiguous.address413 = getelementptr i8, ptr %826, i64 %830
  %private.contiguous.preserve414 = load <8 x float>, ptr %private.contiguous.address413, align 4
  %831 = select <8 x i1> %71, <8 x float> %612, <8 x float> %private.contiguous.preserve414
  store <8 x float> %831, ptr %private.contiguous.address413, align 4
  store i64 0, ptr %.slot94, align 4
  %832 = load <8 x float>, ptr %.slot95, align 32
  %833 = select <8 x i1> %71, <8 x float> splat (float 0xFFF0000000000000), <8 x float> %832
  store <8 x float> %833, ptr %.slot95, align 32
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state415 = load i64, ptr %.slot94, align 4
  %834 = icmp slt i64 %.state415, 16
  br i1 %834, label %direct.true416, label %direct.false417

direct.schedule.23:                               ; preds = %direct.true416
  %.state418 = load i64, ptr %.slot94, align 4
  %835 = sdiv i64 %.state418, 1
  %.spill.load419 = load i64, ptr %.spill31, align 4
  %836 = mul i64 %.spill.load419, 1
  %837 = add i64 %836, 0
  %838 = mul i64 %837, 1
  %839 = add i64 %838, 0
  %840 = mul i64 %839, 16
  %841 = add i64 %840, %835
  %tile_snapshot.spill.load420 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill93, align 64
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load420, 0
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load420, 1
  %.splatinsert421 = insertelement <8 x i64> poison, i64 %841, i64 0
  %.splat422 = shufflevector <8 x i64> %.splatinsert421, <8 x i64> poison, <8 x i32> zeroinitializer
  %844 = mul <8 x i64> %.splat422, splat (i64 32)
  %845 = add <8 x i64> %843, %844
  %846 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %842, 0
  %847 = insertvalue { <8 x ptr>, <8 x i64> } %846, <8 x i64> %845, 1
  %848 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %847, 1
  %850 = extractelement <8 x ptr> %848, i32 0
  %851 = extractelement <8 x i64> %849, i32 0
  %852 = sub i64 %851, 0
  %853 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %854 = select i1 %853, i64 %852, i64 0
  %private.contiguous.address423 = getelementptr i8, ptr %850, i64 %854
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address423, align 4
  %855 = select <8 x i1> %71, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.state424 = load <8 x float>, ptr %.slot95, align 32
  %856 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state424, <8 x float> %855)
  %.state425 = load i64, ptr %.slot94, align 4
  %857 = add i64 %.state425, 1
  store i64 %857, ptr %.slot94, align 4
  %858 = load <8 x float>, ptr %.slot95, align 32
  %859 = select <8 x i1> %71, <8 x float> %856, <8 x float> %858
  store <8 x float> %859, ptr %.slot95, align 32
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false417
  %.state426 = load <8 x float>, ptr %.slot35, align 32
  %.state427 = load <8 x float>, ptr %.slot95, align 32
  %860 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state426, <8 x float> %.state427)
  %861 = load <8 x float>, ptr %.spill96, align 32
  %862 = select <8 x i1> %71, <8 x float> %860, <8 x float> %861
  store <8 x float> %862, ptr %.spill96, align 32
  %.state428 = load <8 x float>, ptr %.slot35, align 32
  %863 = fsub <8 x float> %.state428, %860
  %864 = select <8 x i1> %71, <8 x float> %863, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %864)
  %865 = load <8 x float>, ptr %.spill97, align 32
  %866 = select <8 x i1> %71, <8 x float> %native.exp, <8 x float> %865
  store <8 x float> %866, ptr %.spill97, align 32
  %.spill.load429 = load <8 x float>, ptr %.spill77, align 32
  %867 = fsub <8 x float> %.spill.load429, %860
  %.spill.load430 = load <8 x float>, ptr %.spill78, align 32
  %868 = fsub <8 x float> %.spill.load430, %860
  %.spill.load431 = load <8 x float>, ptr %.spill79, align 32
  %869 = fsub <8 x float> %.spill.load431, %860
  %.spill.load432 = load <8 x float>, ptr %.spill80, align 32
  %870 = fsub <8 x float> %.spill.load432, %860
  %.spill.load433 = load <8 x float>, ptr %.spill81, align 32
  %871 = fsub <8 x float> %.spill.load433, %860
  %.spill.load434 = load <8 x float>, ptr %.spill82, align 32
  %872 = fsub <8 x float> %.spill.load434, %860
  %.spill.load435 = load <8 x float>, ptr %.spill83, align 32
  %873 = fsub <8 x float> %.spill.load435, %860
  %.spill.load436 = load <8 x float>, ptr %.spill84, align 32
  %874 = fsub <8 x float> %.spill.load436, %860
  %.spill.load437 = load <8 x float>, ptr %.spill85, align 32
  %875 = fsub <8 x float> %.spill.load437, %860
  %.spill.load438 = load <8 x float>, ptr %.spill86, align 32
  %876 = fsub <8 x float> %.spill.load438, %860
  %.spill.load439 = load <8 x float>, ptr %.spill87, align 32
  %877 = fsub <8 x float> %.spill.load439, %860
  %.spill.load440 = load <8 x float>, ptr %.spill88, align 32
  %878 = fsub <8 x float> %.spill.load440, %860
  %.spill.load441 = load <8 x float>, ptr %.spill89, align 32
  %879 = fsub <8 x float> %.spill.load441, %860
  %.spill.load442 = load <8 x float>, ptr %.spill90, align 32
  %880 = fsub <8 x float> %.spill.load442, %860
  %.spill.load443 = load <8 x float>, ptr %.spill91, align 32
  %881 = fsub <8 x float> %.spill.load443, %860
  %.spill.load444 = load <8 x float>, ptr %.spill92, align 32
  %882 = fsub <8 x float> %.spill.load444, %860
  %883 = select <8 x i1> %71, <8 x float> %867, <8 x float> zeroinitializer
  %native.exp445 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %883)
  %884 = select <8 x i1> %71, <8 x float> %868, <8 x float> zeroinitializer
  %native.exp446 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %884)
  %885 = select <8 x i1> %71, <8 x float> %869, <8 x float> zeroinitializer
  %native.exp447 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %885)
  %886 = select <8 x i1> %71, <8 x float> %870, <8 x float> zeroinitializer
  %native.exp448 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %886)
  %887 = select <8 x i1> %71, <8 x float> %871, <8 x float> zeroinitializer
  %native.exp449 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %887)
  %888 = select <8 x i1> %71, <8 x float> %872, <8 x float> zeroinitializer
  %native.exp450 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %888)
  %889 = select <8 x i1> %71, <8 x float> %873, <8 x float> zeroinitializer
  %native.exp451 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %889)
  %890 = select <8 x i1> %71, <8 x float> %874, <8 x float> zeroinitializer
  %native.exp452 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %890)
  %891 = select <8 x i1> %71, <8 x float> %875, <8 x float> zeroinitializer
  %native.exp453 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %891)
  %892 = select <8 x i1> %71, <8 x float> %876, <8 x float> zeroinitializer
  %native.exp454 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %892)
  %893 = select <8 x i1> %71, <8 x float> %877, <8 x float> zeroinitializer
  %native.exp455 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %893)
  %894 = select <8 x i1> %71, <8 x float> %878, <8 x float> zeroinitializer
  %native.exp456 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %894)
  %895 = select <8 x i1> %71, <8 x float> %879, <8 x float> zeroinitializer
  %native.exp457 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %895)
  %896 = select <8 x i1> %71, <8 x float> %880, <8 x float> zeroinitializer
  %native.exp458 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %896)
  %897 = select <8 x i1> %71, <8 x float> %881, <8 x float> zeroinitializer
  %native.exp459 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %897)
  %898 = select <8 x i1> %71, <8 x float> %882, <8 x float> zeroinitializer
  %native.exp460 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %898)
  %.spill.load461 = load i1, ptr %.spill61, align 1
  %.splatinsert462 = insertelement <8 x i1> poison, i1 %.spill.load461, i64 0
  %.splat463 = shufflevector <8 x i1> %.splatinsert462, <8 x i1> poison, <8 x i32> zeroinitializer
  %899 = select <8 x i1> %.splat463, <8 x float> %native.exp445, <8 x float> zeroinitializer
  %.spill.load464 = load i1, ptr %.spill62, align 1
  %.splatinsert465 = insertelement <8 x i1> poison, i1 %.spill.load464, i64 0
  %.splat466 = shufflevector <8 x i1> %.splatinsert465, <8 x i1> poison, <8 x i32> zeroinitializer
  %900 = select <8 x i1> %.splat466, <8 x float> %native.exp446, <8 x float> zeroinitializer
  %.spill.load467 = load i1, ptr %.spill63, align 1
  %.splatinsert468 = insertelement <8 x i1> poison, i1 %.spill.load467, i64 0
  %.splat469 = shufflevector <8 x i1> %.splatinsert468, <8 x i1> poison, <8 x i32> zeroinitializer
  %901 = select <8 x i1> %.splat469, <8 x float> %native.exp447, <8 x float> zeroinitializer
  %.spill.load470 = load i1, ptr %.spill64, align 1
  %.splatinsert471 = insertelement <8 x i1> poison, i1 %.spill.load470, i64 0
  %.splat472 = shufflevector <8 x i1> %.splatinsert471, <8 x i1> poison, <8 x i32> zeroinitializer
  %902 = select <8 x i1> %.splat472, <8 x float> %native.exp448, <8 x float> zeroinitializer
  %.spill.load473 = load i1, ptr %.spill65, align 1
  %.splatinsert474 = insertelement <8 x i1> poison, i1 %.spill.load473, i64 0
  %.splat475 = shufflevector <8 x i1> %.splatinsert474, <8 x i1> poison, <8 x i32> zeroinitializer
  %903 = select <8 x i1> %.splat475, <8 x float> %native.exp449, <8 x float> zeroinitializer
  %.spill.load476 = load i1, ptr %.spill66, align 1
  %.splatinsert477 = insertelement <8 x i1> poison, i1 %.spill.load476, i64 0
  %.splat478 = shufflevector <8 x i1> %.splatinsert477, <8 x i1> poison, <8 x i32> zeroinitializer
  %904 = select <8 x i1> %.splat478, <8 x float> %native.exp450, <8 x float> zeroinitializer
  %.spill.load479 = load i1, ptr %.spill67, align 1
  %.splatinsert480 = insertelement <8 x i1> poison, i1 %.spill.load479, i64 0
  %.splat481 = shufflevector <8 x i1> %.splatinsert480, <8 x i1> poison, <8 x i32> zeroinitializer
  %905 = select <8 x i1> %.splat481, <8 x float> %native.exp451, <8 x float> zeroinitializer
  %.spill.load482 = load i1, ptr %.spill68, align 1
  %.splatinsert483 = insertelement <8 x i1> poison, i1 %.spill.load482, i64 0
  %.splat484 = shufflevector <8 x i1> %.splatinsert483, <8 x i1> poison, <8 x i32> zeroinitializer
  %906 = select <8 x i1> %.splat484, <8 x float> %native.exp452, <8 x float> zeroinitializer
  %.spill.load485 = load i1, ptr %.spill69, align 1
  %.splatinsert486 = insertelement <8 x i1> poison, i1 %.spill.load485, i64 0
  %.splat487 = shufflevector <8 x i1> %.splatinsert486, <8 x i1> poison, <8 x i32> zeroinitializer
  %907 = select <8 x i1> %.splat487, <8 x float> %native.exp453, <8 x float> zeroinitializer
  %.spill.load488 = load i1, ptr %.spill70, align 1
  %.splatinsert489 = insertelement <8 x i1> poison, i1 %.spill.load488, i64 0
  %.splat490 = shufflevector <8 x i1> %.splatinsert489, <8 x i1> poison, <8 x i32> zeroinitializer
  %908 = select <8 x i1> %.splat490, <8 x float> %native.exp454, <8 x float> zeroinitializer
  %.spill.load491 = load i1, ptr %.spill71, align 1
  %.splatinsert492 = insertelement <8 x i1> poison, i1 %.spill.load491, i64 0
  %.splat493 = shufflevector <8 x i1> %.splatinsert492, <8 x i1> poison, <8 x i32> zeroinitializer
  %909 = select <8 x i1> %.splat493, <8 x float> %native.exp455, <8 x float> zeroinitializer
  %.spill.load494 = load i1, ptr %.spill72, align 1
  %.splatinsert495 = insertelement <8 x i1> poison, i1 %.spill.load494, i64 0
  %.splat496 = shufflevector <8 x i1> %.splatinsert495, <8 x i1> poison, <8 x i32> zeroinitializer
  %910 = select <8 x i1> %.splat496, <8 x float> %native.exp456, <8 x float> zeroinitializer
  %.spill.load497 = load i1, ptr %.spill73, align 1
  %.splatinsert498 = insertelement <8 x i1> poison, i1 %.spill.load497, i64 0
  %.splat499 = shufflevector <8 x i1> %.splatinsert498, <8 x i1> poison, <8 x i32> zeroinitializer
  %911 = select <8 x i1> %.splat499, <8 x float> %native.exp457, <8 x float> zeroinitializer
  %.spill.load500 = load i1, ptr %.spill74, align 1
  %.splatinsert501 = insertelement <8 x i1> poison, i1 %.spill.load500, i64 0
  %.splat502 = shufflevector <8 x i1> %.splatinsert501, <8 x i1> poison, <8 x i32> zeroinitializer
  %912 = select <8 x i1> %.splat502, <8 x float> %native.exp458, <8 x float> zeroinitializer
  %.spill.load503 = load i1, ptr %.spill75, align 1
  %.splatinsert504 = insertelement <8 x i1> poison, i1 %.spill.load503, i64 0
  %.splat505 = shufflevector <8 x i1> %.splatinsert504, <8 x i1> poison, <8 x i32> zeroinitializer
  %913 = select <8 x i1> %.splat505, <8 x float> %native.exp459, <8 x float> zeroinitializer
  %.spill.load506 = load i1, ptr %.spill76, align 1
  %.splatinsert507 = insertelement <8 x i1> poison, i1 %.spill.load506, i64 0
  %.splat508 = shufflevector <8 x i1> %.splatinsert507, <8 x i1> poison, <8 x i32> zeroinitializer
  %914 = select <8 x i1> %.splat508, <8 x float> %native.exp460, <8 x float> zeroinitializer
  %915 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %917 = extractvalue { <8 x ptr>, <8 x i64> } %915, 0
  %918 = select <8 x i1> %71, <8 x ptr> %916, <8 x ptr> %917
  %919 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %915, 1
  %921 = select <8 x i1> %71, <8 x i64> %919, <8 x i64> %920
  %922 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %918, 0
  %923 = insertvalue { <8 x ptr>, <8 x i64> } %922, <8 x i64> %921, 1
  store { <8 x ptr>, <8 x i64> } %923, ptr %tile_snapshot.spill98, align 64
  %924 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %925 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %926 = add <8 x i64> %925, zeroinitializer
  %927 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %924, 0
  %928 = insertvalue { <8 x ptr>, <8 x i64> } %927, <8 x i64> %926, 1
  %929 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %930 = extractvalue { <8 x ptr>, <8 x i64> } %928, 1
  %931 = extractelement <8 x ptr> %929, i32 0
  %932 = extractelement <8 x i64> %930, i32 0
  %933 = sub i64 %932, 0
  %934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %935 = select i1 %934, i64 %933, i64 0
  %private.contiguous.address509 = getelementptr i8, ptr %931, i64 %935
  %private.contiguous.preserve510 = load <8 x float>, ptr %private.contiguous.address509, align 4
  %936 = select <8 x i1> %71, <8 x float> %899, <8 x float> %private.contiguous.preserve510
  store <8 x float> %936, ptr %private.contiguous.address509, align 4
  %937 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %938 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %939 = add <8 x i64> %938, splat (i64 32)
  %940 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %937, 0
  %941 = insertvalue { <8 x ptr>, <8 x i64> } %940, <8 x i64> %939, 1
  %942 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %943 = extractvalue { <8 x ptr>, <8 x i64> } %941, 1
  %944 = extractelement <8 x ptr> %942, i32 0
  %945 = extractelement <8 x i64> %943, i32 0
  %946 = sub i64 %945, 0
  %947 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %948 = select i1 %947, i64 %946, i64 0
  %private.contiguous.address511 = getelementptr i8, ptr %944, i64 %948
  %private.contiguous.preserve512 = load <8 x float>, ptr %private.contiguous.address511, align 4
  %949 = select <8 x i1> %71, <8 x float> %900, <8 x float> %private.contiguous.preserve512
  store <8 x float> %949, ptr %private.contiguous.address511, align 4
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %951 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %952 = add <8 x i64> %951, splat (i64 64)
  %953 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %950, 0
  %954 = insertvalue { <8 x ptr>, <8 x i64> } %953, <8 x i64> %952, 1
  %955 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %956 = extractvalue { <8 x ptr>, <8 x i64> } %954, 1
  %957 = extractelement <8 x ptr> %955, i32 0
  %958 = extractelement <8 x i64> %956, i32 0
  %959 = sub i64 %958, 0
  %960 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %961 = select i1 %960, i64 %959, i64 0
  %private.contiguous.address513 = getelementptr i8, ptr %957, i64 %961
  %private.contiguous.preserve514 = load <8 x float>, ptr %private.contiguous.address513, align 4
  %962 = select <8 x i1> %71, <8 x float> %901, <8 x float> %private.contiguous.preserve514
  store <8 x float> %962, ptr %private.contiguous.address513, align 4
  %963 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %964 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %965 = add <8 x i64> %964, splat (i64 96)
  %966 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %963, 0
  %967 = insertvalue { <8 x ptr>, <8 x i64> } %966, <8 x i64> %965, 1
  %968 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %969 = extractvalue { <8 x ptr>, <8 x i64> } %967, 1
  %970 = extractelement <8 x ptr> %968, i32 0
  %971 = extractelement <8 x i64> %969, i32 0
  %972 = sub i64 %971, 0
  %973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %974 = select i1 %973, i64 %972, i64 0
  %private.contiguous.address515 = getelementptr i8, ptr %970, i64 %974
  %private.contiguous.preserve516 = load <8 x float>, ptr %private.contiguous.address515, align 4
  %975 = select <8 x i1> %71, <8 x float> %902, <8 x float> %private.contiguous.preserve516
  store <8 x float> %975, ptr %private.contiguous.address515, align 4
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %977 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %978 = add <8 x i64> %977, splat (i64 128)
  %979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %976, 0
  %980 = insertvalue { <8 x ptr>, <8 x i64> } %979, <8 x i64> %978, 1
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %980, 1
  %983 = extractelement <8 x ptr> %981, i32 0
  %984 = extractelement <8 x i64> %982, i32 0
  %985 = sub i64 %984, 0
  %986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %987 = select i1 %986, i64 %985, i64 0
  %private.contiguous.address517 = getelementptr i8, ptr %983, i64 %987
  %private.contiguous.preserve518 = load <8 x float>, ptr %private.contiguous.address517, align 4
  %988 = select <8 x i1> %71, <8 x float> %903, <8 x float> %private.contiguous.preserve518
  store <8 x float> %988, ptr %private.contiguous.address517, align 4
  %989 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %990 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %991 = add <8 x i64> %990, splat (i64 160)
  %992 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %989, 0
  %993 = insertvalue { <8 x ptr>, <8 x i64> } %992, <8 x i64> %991, 1
  %994 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %995 = extractvalue { <8 x ptr>, <8 x i64> } %993, 1
  %996 = extractelement <8 x ptr> %994, i32 0
  %997 = extractelement <8 x i64> %995, i32 0
  %998 = sub i64 %997, 0
  %999 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1000 = select i1 %999, i64 %998, i64 0
  %private.contiguous.address519 = getelementptr i8, ptr %996, i64 %1000
  %private.contiguous.preserve520 = load <8 x float>, ptr %private.contiguous.address519, align 4
  %1001 = select <8 x i1> %71, <8 x float> %904, <8 x float> %private.contiguous.preserve520
  store <8 x float> %1001, ptr %private.contiguous.address519, align 4
  %1002 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1004 = add <8 x i64> %1003, splat (i64 192)
  %1005 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1002, 0
  %1006 = insertvalue { <8 x ptr>, <8 x i64> } %1005, <8 x i64> %1004, 1
  %1007 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1008 = extractvalue { <8 x ptr>, <8 x i64> } %1006, 1
  %1009 = extractelement <8 x ptr> %1007, i32 0
  %1010 = extractelement <8 x i64> %1008, i32 0
  %1011 = sub i64 %1010, 0
  %1012 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1013 = select i1 %1012, i64 %1011, i64 0
  %private.contiguous.address521 = getelementptr i8, ptr %1009, i64 %1013
  %private.contiguous.preserve522 = load <8 x float>, ptr %private.contiguous.address521, align 4
  %1014 = select <8 x i1> %71, <8 x float> %905, <8 x float> %private.contiguous.preserve522
  store <8 x float> %1014, ptr %private.contiguous.address521, align 4
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1017 = add <8 x i64> %1016, splat (i64 224)
  %1018 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1015, 0
  %1019 = insertvalue { <8 x ptr>, <8 x i64> } %1018, <8 x i64> %1017, 1
  %1020 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1021 = extractvalue { <8 x ptr>, <8 x i64> } %1019, 1
  %1022 = extractelement <8 x ptr> %1020, i32 0
  %1023 = extractelement <8 x i64> %1021, i32 0
  %1024 = sub i64 %1023, 0
  %1025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1026 = select i1 %1025, i64 %1024, i64 0
  %private.contiguous.address523 = getelementptr i8, ptr %1022, i64 %1026
  %private.contiguous.preserve524 = load <8 x float>, ptr %private.contiguous.address523, align 4
  %1027 = select <8 x i1> %71, <8 x float> %906, <8 x float> %private.contiguous.preserve524
  store <8 x float> %1027, ptr %private.contiguous.address523, align 4
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1030 = add <8 x i64> %1029, splat (i64 256)
  %1031 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1028, 0
  %1032 = insertvalue { <8 x ptr>, <8 x i64> } %1031, <8 x i64> %1030, 1
  %1033 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1034 = extractvalue { <8 x ptr>, <8 x i64> } %1032, 1
  %1035 = extractelement <8 x ptr> %1033, i32 0
  %1036 = extractelement <8 x i64> %1034, i32 0
  %1037 = sub i64 %1036, 0
  %1038 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1039 = select i1 %1038, i64 %1037, i64 0
  %private.contiguous.address525 = getelementptr i8, ptr %1035, i64 %1039
  %private.contiguous.preserve526 = load <8 x float>, ptr %private.contiguous.address525, align 4
  %1040 = select <8 x i1> %71, <8 x float> %907, <8 x float> %private.contiguous.preserve526
  store <8 x float> %1040, ptr %private.contiguous.address525, align 4
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1043 = add <8 x i64> %1042, splat (i64 288)
  %1044 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1041, 0
  %1045 = insertvalue { <8 x ptr>, <8 x i64> } %1044, <8 x i64> %1043, 1
  %1046 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1047 = extractvalue { <8 x ptr>, <8 x i64> } %1045, 1
  %1048 = extractelement <8 x ptr> %1046, i32 0
  %1049 = extractelement <8 x i64> %1047, i32 0
  %1050 = sub i64 %1049, 0
  %1051 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1052 = select i1 %1051, i64 %1050, i64 0
  %private.contiguous.address527 = getelementptr i8, ptr %1048, i64 %1052
  %private.contiguous.preserve528 = load <8 x float>, ptr %private.contiguous.address527, align 4
  %1053 = select <8 x i1> %71, <8 x float> %908, <8 x float> %private.contiguous.preserve528
  store <8 x float> %1053, ptr %private.contiguous.address527, align 4
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1055 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1056 = add <8 x i64> %1055, splat (i64 320)
  %1057 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1054, 0
  %1058 = insertvalue { <8 x ptr>, <8 x i64> } %1057, <8 x i64> %1056, 1
  %1059 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1060 = extractvalue { <8 x ptr>, <8 x i64> } %1058, 1
  %1061 = extractelement <8 x ptr> %1059, i32 0
  %1062 = extractelement <8 x i64> %1060, i32 0
  %1063 = sub i64 %1062, 0
  %1064 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1065 = select i1 %1064, i64 %1063, i64 0
  %private.contiguous.address529 = getelementptr i8, ptr %1061, i64 %1065
  %private.contiguous.preserve530 = load <8 x float>, ptr %private.contiguous.address529, align 4
  %1066 = select <8 x i1> %71, <8 x float> %909, <8 x float> %private.contiguous.preserve530
  store <8 x float> %1066, ptr %private.contiguous.address529, align 4
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1069 = add <8 x i64> %1068, splat (i64 352)
  %1070 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1067, 0
  %1071 = insertvalue { <8 x ptr>, <8 x i64> } %1070, <8 x i64> %1069, 1
  %1072 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1073 = extractvalue { <8 x ptr>, <8 x i64> } %1071, 1
  %1074 = extractelement <8 x ptr> %1072, i32 0
  %1075 = extractelement <8 x i64> %1073, i32 0
  %1076 = sub i64 %1075, 0
  %1077 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1078 = select i1 %1077, i64 %1076, i64 0
  %private.contiguous.address531 = getelementptr i8, ptr %1074, i64 %1078
  %private.contiguous.preserve532 = load <8 x float>, ptr %private.contiguous.address531, align 4
  %1079 = select <8 x i1> %71, <8 x float> %910, <8 x float> %private.contiguous.preserve532
  store <8 x float> %1079, ptr %private.contiguous.address531, align 4
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1082 = add <8 x i64> %1081, splat (i64 384)
  %1083 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1080, 0
  %1084 = insertvalue { <8 x ptr>, <8 x i64> } %1083, <8 x i64> %1082, 1
  %1085 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1086 = extractvalue { <8 x ptr>, <8 x i64> } %1084, 1
  %1087 = extractelement <8 x ptr> %1085, i32 0
  %1088 = extractelement <8 x i64> %1086, i32 0
  %1089 = sub i64 %1088, 0
  %1090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1091 = select i1 %1090, i64 %1089, i64 0
  %private.contiguous.address533 = getelementptr i8, ptr %1087, i64 %1091
  %private.contiguous.preserve534 = load <8 x float>, ptr %private.contiguous.address533, align 4
  %1092 = select <8 x i1> %71, <8 x float> %911, <8 x float> %private.contiguous.preserve534
  store <8 x float> %1092, ptr %private.contiguous.address533, align 4
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1095 = add <8 x i64> %1094, splat (i64 416)
  %1096 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1093, 0
  %1097 = insertvalue { <8 x ptr>, <8 x i64> } %1096, <8 x i64> %1095, 1
  %1098 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1099 = extractvalue { <8 x ptr>, <8 x i64> } %1097, 1
  %1100 = extractelement <8 x ptr> %1098, i32 0
  %1101 = extractelement <8 x i64> %1099, i32 0
  %1102 = sub i64 %1101, 0
  %1103 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1104 = select i1 %1103, i64 %1102, i64 0
  %private.contiguous.address535 = getelementptr i8, ptr %1100, i64 %1104
  %private.contiguous.preserve536 = load <8 x float>, ptr %private.contiguous.address535, align 4
  %1105 = select <8 x i1> %71, <8 x float> %912, <8 x float> %private.contiguous.preserve536
  store <8 x float> %1105, ptr %private.contiguous.address535, align 4
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1108 = add <8 x i64> %1107, splat (i64 448)
  %1109 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1106, 0
  %1110 = insertvalue { <8 x ptr>, <8 x i64> } %1109, <8 x i64> %1108, 1
  %1111 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1112 = extractvalue { <8 x ptr>, <8 x i64> } %1110, 1
  %1113 = extractelement <8 x ptr> %1111, i32 0
  %1114 = extractelement <8 x i64> %1112, i32 0
  %1115 = sub i64 %1114, 0
  %1116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1117 = select i1 %1116, i64 %1115, i64 0
  %private.contiguous.address537 = getelementptr i8, ptr %1113, i64 %1117
  %private.contiguous.preserve538 = load <8 x float>, ptr %private.contiguous.address537, align 4
  %1118 = select <8 x i1> %71, <8 x float> %913, <8 x float> %private.contiguous.preserve538
  store <8 x float> %1118, ptr %private.contiguous.address537, align 4
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1120 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1121 = add <8 x i64> %1120, splat (i64 480)
  %1122 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1119, 0
  %1123 = insertvalue { <8 x ptr>, <8 x i64> } %1122, <8 x i64> %1121, 1
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1125 = extractvalue { <8 x ptr>, <8 x i64> } %1123, 1
  %1126 = extractelement <8 x ptr> %1124, i32 0
  %1127 = extractelement <8 x i64> %1125, i32 0
  %1128 = sub i64 %1127, 0
  %1129 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1130 = select i1 %1129, i64 %1128, i64 0
  %private.contiguous.address539 = getelementptr i8, ptr %1126, i64 %1130
  %private.contiguous.preserve540 = load <8 x float>, ptr %private.contiguous.address539, align 4
  %1131 = select <8 x i1> %71, <8 x float> %914, <8 x float> %private.contiguous.preserve540
  store <8 x float> %1131, ptr %private.contiguous.address539, align 4
  %.state541 = load <8 x float>, ptr %.slot36, align 32
  %1132 = fmul <8 x float> %.state541, %native.exp
  %1133 = load <8 x float>, ptr %.spill99, align 32
  %1134 = select <8 x i1> %71, <8 x float> %1132, <8 x float> %1133
  store <8 x float> %1134, ptr %.spill99, align 32
  store i64 0, ptr %.slot100, align 4
  %1135 = load <8 x float>, ptr %.slot101, align 32
  %1136 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1135
  store <8 x float> %1136, ptr %.slot101, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.26, %direct.schedule.24
  %.state542 = load i64, ptr %.slot100, align 4
  %1137 = icmp slt i64 %.state542, 16
  br i1 %1137, label %direct.true543, label %direct.false544

direct.schedule.26:                               ; preds = %direct.true543
  %.state545 = load i64, ptr %.slot100, align 4
  %1138 = sdiv i64 %.state545, 1
  %.spill.load546 = load i64, ptr %.spill31, align 4
  %1139 = mul i64 %.spill.load546, 1
  %1140 = add i64 %1139, 0
  %1141 = mul i64 %1140, 1
  %1142 = add i64 %1141, 0
  %1143 = mul i64 %1142, 16
  %1144 = add i64 %1143, %1138
  %tile_snapshot.spill.load547 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load547, 1
  %.splatinsert548 = insertelement <8 x i64> poison, i64 %1144, i64 0
  %.splat549 = shufflevector <8 x i64> %.splatinsert548, <8 x i64> poison, <8 x i32> zeroinitializer
  %1147 = mul <8 x i64> %.splat549, splat (i64 32)
  %1148 = add <8 x i64> %1146, %1147
  %1149 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1145, 0
  %1150 = insertvalue { <8 x ptr>, <8 x i64> } %1149, <8 x i64> %1148, 1
  %1151 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1152 = extractvalue { <8 x ptr>, <8 x i64> } %1150, 1
  %1153 = extractelement <8 x ptr> %1151, i32 0
  %1154 = extractelement <8 x i64> %1152, i32 0
  %1155 = sub i64 %1154, 0
  %1156 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1157 = select i1 %1156, i64 %1155, i64 0
  %private.contiguous.address550 = getelementptr i8, ptr %1153, i64 %1157
  %private.contiguous.load551 = load <8 x float>, ptr %private.contiguous.address550, align 4
  %1158 = select <8 x i1> %71, <8 x float> %private.contiguous.load551, <8 x float> zeroinitializer
  %.state552 = load <8 x float>, ptr %.slot101, align 32
  %1159 = fadd <8 x float> %.state552, %1158
  %.state553 = load i64, ptr %.slot100, align 4
  %1160 = add i64 %.state553, 1
  store i64 %1160, ptr %.slot100, align 4
  %1161 = load <8 x float>, ptr %.slot101, align 32
  %1162 = select <8 x i1> %71, <8 x float> %1159, <8 x float> %1161
  store <8 x float> %1162, ptr %.slot101, align 32
  br label %direct.schedule.25

direct.schedule.27:                               ; preds = %direct.false544
  %.spill.load554 = load <8 x float>, ptr %.spill99, align 32
  %.state555 = load <8 x float>, ptr %.slot101, align 32
  %1163 = fadd <8 x float> %.spill.load554, %.state555
  %1164 = load <8 x float>, ptr %.spill102, align 32
  %1165 = select <8 x i1> %71, <8 x float> %1163, <8 x float> %1164
  store <8 x float> %1165, ptr %.spill102, align 32
  %1166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1167 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1168 = extractvalue { <8 x ptr>, <8 x i64> } %1166, 0
  %1169 = select <8 x i1> %71, <8 x ptr> %1167, <8 x ptr> %1168
  %1170 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %1166, 1
  %1172 = select <8 x i1> %71, <8 x i64> %1170, <8 x i64> %1171
  %1173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1169, 0
  %1174 = insertvalue { <8 x ptr>, <8 x i64> } %1173, <8 x i64> %1172, 1
  store { <8 x ptr>, <8 x i64> } %1174, ptr %tile_snapshot.spill103, align 64
  store i64 0, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.32, %direct.schedule.27
  %.state556 = load i64, ptr %.slot104, align 4
  %1175 = icmp slt i64 %.state556, 32
  br i1 %1175, label %direct.true557, label %direct.false558

direct.schedule.29:                               ; preds = %direct.true557
  %.state559 = load i64, ptr %.slot104, align 4
  %1176 = mul i64 %.state559, 4
  %1177 = add i64 0, %1176
  %1178 = add i64 %1177, 0
  store i64 %1178, ptr %.spill105, align 4
  %1179 = add i64 0, %1178
  %tile_snapshot.spill.load560 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load560, 0
  %1181 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load560, 1
  %.splatinsert561 = insertelement <8 x i64> poison, i64 %1179, i64 0
  %.splat562 = shufflevector <8 x i64> %.splatinsert561, <8 x i64> poison, <8 x i32> zeroinitializer
  %1182 = mul <8 x i64> %.splat562, splat (i64 32)
  %1183 = add <8 x i64> %1181, %1182
  %1184 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1180, 0
  %1185 = insertvalue { <8 x ptr>, <8 x i64> } %1184, <8 x i64> %1183, 1
  %1186 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1187 = extractvalue { <8 x ptr>, <8 x i64> } %1185, 1
  %1188 = extractelement <8 x ptr> %1186, i32 0
  %1189 = extractelement <8 x i64> %1187, i32 0
  %1190 = sub i64 %1189, 0
  %1191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1192 = select i1 %1191, i64 %1190, i64 0
  %private.contiguous.address563 = getelementptr i8, ptr %1188, i64 %1192
  %private.contiguous.load564 = load <8 x float>, ptr %private.contiguous.address563, align 4
  %1193 = select <8 x i1> %71, <8 x float> %private.contiguous.load564, <8 x float> zeroinitializer
  %.spill.load565 = load <8 x float>, ptr %.spill97, align 32
  %1194 = fmul <8 x float> %1193, %.spill.load565
  %1195 = add i64 %1177, 1
  store i64 %1195, ptr %.spill106, align 4
  %1196 = add i64 0, %1195
  %tile_snapshot.spill.load566 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load566, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load566, 1
  %.splatinsert567 = insertelement <8 x i64> poison, i64 %1196, i64 0
  %.splat568 = shufflevector <8 x i64> %.splatinsert567, <8 x i64> poison, <8 x i32> zeroinitializer
  %1199 = mul <8 x i64> %.splat568, splat (i64 32)
  %1200 = add <8 x i64> %1198, %1199
  %1201 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1197, 0
  %1202 = insertvalue { <8 x ptr>, <8 x i64> } %1201, <8 x i64> %1200, 1
  %1203 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1204 = extractvalue { <8 x ptr>, <8 x i64> } %1202, 1
  %1205 = extractelement <8 x ptr> %1203, i32 0
  %1206 = extractelement <8 x i64> %1204, i32 0
  %1207 = sub i64 %1206, 0
  %1208 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1209 = select i1 %1208, i64 %1207, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %1205, i64 %1209
  %private.contiguous.load570 = load <8 x float>, ptr %private.contiguous.address569, align 4
  %1210 = select <8 x i1> %71, <8 x float> %private.contiguous.load570, <8 x float> zeroinitializer
  %.spill.load571 = load <8 x float>, ptr %.spill97, align 32
  %1211 = fmul <8 x float> %1210, %.spill.load571
  %1212 = add i64 %1177, 2
  store i64 %1212, ptr %.spill107, align 4
  %1213 = add i64 0, %1212
  %tile_snapshot.spill.load572 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load572, 0
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load572, 1
  %.splatinsert573 = insertelement <8 x i64> poison, i64 %1213, i64 0
  %.splat574 = shufflevector <8 x i64> %.splatinsert573, <8 x i64> poison, <8 x i32> zeroinitializer
  %1216 = mul <8 x i64> %.splat574, splat (i64 32)
  %1217 = add <8 x i64> %1215, %1216
  %1218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1214, 0
  %1219 = insertvalue { <8 x ptr>, <8 x i64> } %1218, <8 x i64> %1217, 1
  %1220 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1221 = extractvalue { <8 x ptr>, <8 x i64> } %1219, 1
  %1222 = extractelement <8 x ptr> %1220, i32 0
  %1223 = extractelement <8 x i64> %1221, i32 0
  %1224 = sub i64 %1223, 0
  %1225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1226 = select i1 %1225, i64 %1224, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %1222, i64 %1226
  %private.contiguous.load576 = load <8 x float>, ptr %private.contiguous.address575, align 4
  %1227 = select <8 x i1> %71, <8 x float> %private.contiguous.load576, <8 x float> zeroinitializer
  %.spill.load577 = load <8 x float>, ptr %.spill97, align 32
  %1228 = fmul <8 x float> %1227, %.spill.load577
  %1229 = add i64 %1177, 3
  store i64 %1229, ptr %.spill108, align 4
  %1230 = add i64 0, %1229
  %tile_snapshot.spill.load578 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load578, 0
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load578, 1
  %.splatinsert579 = insertelement <8 x i64> poison, i64 %1230, i64 0
  %.splat580 = shufflevector <8 x i64> %.splatinsert579, <8 x i64> poison, <8 x i32> zeroinitializer
  %1233 = mul <8 x i64> %.splat580, splat (i64 32)
  %1234 = add <8 x i64> %1232, %1233
  %1235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1231, 0
  %1236 = insertvalue { <8 x ptr>, <8 x i64> } %1235, <8 x i64> %1234, 1
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1238 = extractvalue { <8 x ptr>, <8 x i64> } %1236, 1
  %1239 = extractelement <8 x ptr> %1237, i32 0
  %1240 = extractelement <8 x i64> %1238, i32 0
  %1241 = sub i64 %1240, 0
  %1242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1243 = select i1 %1242, i64 %1241, i64 0
  %private.contiguous.address581 = getelementptr i8, ptr %1239, i64 %1243
  %private.contiguous.load582 = load <8 x float>, ptr %private.contiguous.address581, align 4
  %1244 = select <8 x i1> %71, <8 x float> %private.contiguous.load582, <8 x float> zeroinitializer
  %.spill.load583 = load <8 x float>, ptr %.spill97, align 32
  %1245 = fmul <8 x float> %1244, %.spill.load583
  store i64 0, ptr %.slot109, align 4
  %1246 = load <8 x float>, ptr %.slot110, align 32
  %1247 = select <8 x i1> %71, <8 x float> %1194, <8 x float> %1246
  store <8 x float> %1247, ptr %.slot110, align 32
  %1248 = load <8 x float>, ptr %.slot111, align 32
  %1249 = select <8 x i1> %71, <8 x float> %1211, <8 x float> %1248
  store <8 x float> %1249, ptr %.slot111, align 32
  %1250 = load <8 x float>, ptr %.slot112, align 32
  %1251 = select <8 x i1> %71, <8 x float> %1228, <8 x float> %1250
  store <8 x float> %1251, ptr %.slot112, align 32
  %1252 = load <8 x float>, ptr %.slot113, align 32
  %1253 = select <8 x i1> %71, <8 x float> %1245, <8 x float> %1252
  store <8 x float> %1253, ptr %.slot113, align 32
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.31, %direct.schedule.29
  %.state584 = load i64, ptr %.slot109, align 4
  %1254 = icmp slt i64 %.state584, 16
  br i1 %1254, label %direct.true585, label %direct.false586

direct.schedule.31:                               ; preds = %direct.true585
  %.state587 = load i64, ptr %.slot109, align 4
  %1255 = add i64 0, %.state587
  %tile_snapshot.spill.load588 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill98, align 64
  %1256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load588, 0
  %1257 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load588, 1
  %.splatinsert589 = insertelement <8 x i64> poison, i64 %1255, i64 0
  %.splat590 = shufflevector <8 x i64> %.splatinsert589, <8 x i64> poison, <8 x i32> zeroinitializer
  %1258 = mul <8 x i64> %.splat590, splat (i64 32)
  %1259 = add <8 x i64> %1257, %1258
  %1260 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1256, 0
  %1261 = insertvalue { <8 x ptr>, <8 x i64> } %1260, <8 x i64> %1259, 1
  %1262 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %1261, 1
  %1264 = extractelement <8 x ptr> %1262, i32 0
  %1265 = extractelement <8 x i64> %1263, i32 0
  %1266 = sub i64 %1265, 0
  %1267 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1268 = select i1 %1267, i64 %1266, i64 0
  %private.contiguous.address591 = getelementptr i8, ptr %1264, i64 %1268
  %private.contiguous.load592 = load <8 x float>, ptr %private.contiguous.address591, align 4
  %1269 = select <8 x i1> %71, <8 x float> %private.contiguous.load592, <8 x float> zeroinitializer
  %1270 = mul i64 %1255, 128
  %.spill.load593 = load i64, ptr %.spill105, align 4
  %1271 = add i64 %1270, %.spill.load593
  %tile_snapshot.spill.load594 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1272 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load594, 0
  %1273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load594, 1
  %.splatinsert595 = insertelement <8 x i64> poison, i64 %1271, i64 0
  %.splat596 = shufflevector <8 x i64> %.splatinsert595, <8 x i64> poison, <8 x i32> zeroinitializer
  %1274 = mul <8 x i64> %.splat596, splat (i64 4)
  %1275 = add <8 x i64> %1273, %1274
  %1276 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1272, 0
  %1277 = insertvalue { <8 x ptr>, <8 x i64> } %1276, <8 x i64> %1275, 1
  %1278 = extractvalue { <8 x ptr>, <8 x i64> } %1277, 0
  %1279 = extractvalue { <8 x ptr>, <8 x i64> } %1277, 1
  %1280 = getelementptr i8, <8 x ptr> %1278, <8 x i64> %1279
  %1281 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1280, <8 x i1> %71, <8 x float> zeroinitializer)
  %1282 = fmul <8 x float> %1269, %1281
  %.state597 = load <8 x float>, ptr %.slot110, align 32
  %1283 = fadd <8 x float> %.state597, %1282
  %.spill.load598 = load i64, ptr %.spill106, align 4
  %1284 = add i64 %1270, %.spill.load598
  %tile_snapshot.spill.load599 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load599, 0
  %1286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load599, 1
  %.splatinsert600 = insertelement <8 x i64> poison, i64 %1284, i64 0
  %.splat601 = shufflevector <8 x i64> %.splatinsert600, <8 x i64> poison, <8 x i32> zeroinitializer
  %1287 = mul <8 x i64> %.splat601, splat (i64 4)
  %1288 = add <8 x i64> %1286, %1287
  %1289 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1285, 0
  %1290 = insertvalue { <8 x ptr>, <8 x i64> } %1289, <8 x i64> %1288, 1
  %1291 = extractvalue { <8 x ptr>, <8 x i64> } %1290, 0
  %1292 = extractvalue { <8 x ptr>, <8 x i64> } %1290, 1
  %1293 = getelementptr i8, <8 x ptr> %1291, <8 x i64> %1292
  %1294 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1293, <8 x i1> %71, <8 x float> zeroinitializer)
  %1295 = fmul <8 x float> %1269, %1294
  %.state602 = load <8 x float>, ptr %.slot111, align 32
  %1296 = fadd <8 x float> %.state602, %1295
  %.spill.load603 = load i64, ptr %.spill107, align 4
  %1297 = add i64 %1270, %.spill.load603
  %tile_snapshot.spill.load604 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1298 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load604, 0
  %1299 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load604, 1
  %.splatinsert605 = insertelement <8 x i64> poison, i64 %1297, i64 0
  %.splat606 = shufflevector <8 x i64> %.splatinsert605, <8 x i64> poison, <8 x i32> zeroinitializer
  %1300 = mul <8 x i64> %.splat606, splat (i64 4)
  %1301 = add <8 x i64> %1299, %1300
  %1302 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1298, 0
  %1303 = insertvalue { <8 x ptr>, <8 x i64> } %1302, <8 x i64> %1301, 1
  %1304 = extractvalue { <8 x ptr>, <8 x i64> } %1303, 0
  %1305 = extractvalue { <8 x ptr>, <8 x i64> } %1303, 1
  %1306 = getelementptr i8, <8 x ptr> %1304, <8 x i64> %1305
  %1307 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1306, <8 x i1> %71, <8 x float> zeroinitializer)
  %1308 = fmul <8 x float> %1269, %1307
  %.state607 = load <8 x float>, ptr %.slot112, align 32
  %1309 = fadd <8 x float> %.state607, %1308
  %.spill.load608 = load i64, ptr %.spill108, align 4
  %1310 = add i64 %1270, %.spill.load608
  %tile_snapshot.spill.load609 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load609, 0
  %1312 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load609, 1
  %.splatinsert610 = insertelement <8 x i64> poison, i64 %1310, i64 0
  %.splat611 = shufflevector <8 x i64> %.splatinsert610, <8 x i64> poison, <8 x i32> zeroinitializer
  %1313 = mul <8 x i64> %.splat611, splat (i64 4)
  %1314 = add <8 x i64> %1312, %1313
  %1315 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1311, 0
  %1316 = insertvalue { <8 x ptr>, <8 x i64> } %1315, <8 x i64> %1314, 1
  %1317 = extractvalue { <8 x ptr>, <8 x i64> } %1316, 0
  %1318 = extractvalue { <8 x ptr>, <8 x i64> } %1316, 1
  %1319 = getelementptr i8, <8 x ptr> %1317, <8 x i64> %1318
  %1320 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1319, <8 x i1> %71, <8 x float> zeroinitializer)
  %1321 = fmul <8 x float> %1269, %1320
  %.state612 = load <8 x float>, ptr %.slot113, align 32
  %1322 = fadd <8 x float> %.state612, %1321
  %.state613 = load i64, ptr %.slot109, align 4
  %1323 = add i64 %.state613, 1
  store i64 %1323, ptr %.slot109, align 4
  %1324 = load <8 x float>, ptr %.slot110, align 32
  %1325 = select <8 x i1> %71, <8 x float> %1283, <8 x float> %1324
  store <8 x float> %1325, ptr %.slot110, align 32
  %1326 = load <8 x float>, ptr %.slot111, align 32
  %1327 = select <8 x i1> %71, <8 x float> %1296, <8 x float> %1326
  store <8 x float> %1327, ptr %.slot111, align 32
  %1328 = load <8 x float>, ptr %.slot112, align 32
  %1329 = select <8 x i1> %71, <8 x float> %1309, <8 x float> %1328
  store <8 x float> %1329, ptr %.slot112, align 32
  %1330 = load <8 x float>, ptr %.slot113, align 32
  %1331 = select <8 x i1> %71, <8 x float> %1322, <8 x float> %1330
  store <8 x float> %1331, ptr %.slot113, align 32
  br label %direct.schedule.30

direct.schedule.32:                               ; preds = %direct.false586
  %tile_snapshot.spill.load614 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1332 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 0
  %1333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 1
  %.spill.load615 = load i64, ptr %.spill105, align 4
  %.splatinsert616 = insertelement <8 x i64> poison, i64 %.spill.load615, i64 0
  %.splat617 = shufflevector <8 x i64> %.splatinsert616, <8 x i64> poison, <8 x i32> zeroinitializer
  %1334 = mul <8 x i64> %.splat617, splat (i64 32)
  %1335 = add <8 x i64> %1333, %1334
  %1336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1332, 0
  %1337 = insertvalue { <8 x ptr>, <8 x i64> } %1336, <8 x i64> %1335, 1
  %.state618 = load <8 x float>, ptr %.slot110, align 32
  %1338 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1339 = extractvalue { <8 x ptr>, <8 x i64> } %1337, 1
  %1340 = extractelement <8 x ptr> %1338, i32 0
  %1341 = extractelement <8 x i64> %1339, i32 0
  %1342 = sub i64 %1341, 0
  %1343 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1344 = select i1 %1343, i64 %1342, i64 0
  %private.contiguous.address619 = getelementptr i8, ptr %1340, i64 %1344
  %private.contiguous.preserve620 = load <8 x float>, ptr %private.contiguous.address619, align 4
  %1345 = select <8 x i1> %71, <8 x float> %.state618, <8 x float> %private.contiguous.preserve620
  store <8 x float> %1345, ptr %private.contiguous.address619, align 4
  %tile_snapshot.spill.load621 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1346 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load621, 0
  %1347 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load621, 1
  %.spill.load622 = load i64, ptr %.spill106, align 4
  %.splatinsert623 = insertelement <8 x i64> poison, i64 %.spill.load622, i64 0
  %.splat624 = shufflevector <8 x i64> %.splatinsert623, <8 x i64> poison, <8 x i32> zeroinitializer
  %1348 = mul <8 x i64> %.splat624, splat (i64 32)
  %1349 = add <8 x i64> %1347, %1348
  %1350 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1346, 0
  %1351 = insertvalue { <8 x ptr>, <8 x i64> } %1350, <8 x i64> %1349, 1
  %.state625 = load <8 x float>, ptr %.slot111, align 32
  %1352 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1353 = extractvalue { <8 x ptr>, <8 x i64> } %1351, 1
  %1354 = extractelement <8 x ptr> %1352, i32 0
  %1355 = extractelement <8 x i64> %1353, i32 0
  %1356 = sub i64 %1355, 0
  %1357 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1358 = select i1 %1357, i64 %1356, i64 0
  %private.contiguous.address626 = getelementptr i8, ptr %1354, i64 %1358
  %private.contiguous.preserve627 = load <8 x float>, ptr %private.contiguous.address626, align 4
  %1359 = select <8 x i1> %71, <8 x float> %.state625, <8 x float> %private.contiguous.preserve627
  store <8 x float> %1359, ptr %private.contiguous.address626, align 4
  %tile_snapshot.spill.load628 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 0
  %1361 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load628, 1
  %.spill.load629 = load i64, ptr %.spill107, align 4
  %.splatinsert630 = insertelement <8 x i64> poison, i64 %.spill.load629, i64 0
  %.splat631 = shufflevector <8 x i64> %.splatinsert630, <8 x i64> poison, <8 x i32> zeroinitializer
  %1362 = mul <8 x i64> %.splat631, splat (i64 32)
  %1363 = add <8 x i64> %1361, %1362
  %1364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1360, 0
  %1365 = insertvalue { <8 x ptr>, <8 x i64> } %1364, <8 x i64> %1363, 1
  %.state632 = load <8 x float>, ptr %.slot112, align 32
  %1366 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1367 = extractvalue { <8 x ptr>, <8 x i64> } %1365, 1
  %1368 = extractelement <8 x ptr> %1366, i32 0
  %1369 = extractelement <8 x i64> %1367, i32 0
  %1370 = sub i64 %1369, 0
  %1371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1372 = select i1 %1371, i64 %1370, i64 0
  %private.contiguous.address633 = getelementptr i8, ptr %1368, i64 %1372
  %private.contiguous.preserve634 = load <8 x float>, ptr %private.contiguous.address633, align 4
  %1373 = select <8 x i1> %71, <8 x float> %.state632, <8 x float> %private.contiguous.preserve634
  store <8 x float> %1373, ptr %private.contiguous.address633, align 4
  %tile_snapshot.spill.load635 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1374 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load635, 0
  %1375 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load635, 1
  %.spill.load636 = load i64, ptr %.spill108, align 4
  %.splatinsert637 = insertelement <8 x i64> poison, i64 %.spill.load636, i64 0
  %.splat638 = shufflevector <8 x i64> %.splatinsert637, <8 x i64> poison, <8 x i32> zeroinitializer
  %1376 = mul <8 x i64> %.splat638, splat (i64 32)
  %1377 = add <8 x i64> %1375, %1376
  %1378 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1374, 0
  %1379 = insertvalue { <8 x ptr>, <8 x i64> } %1378, <8 x i64> %1377, 1
  %.state639 = load <8 x float>, ptr %.slot113, align 32
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1381 = extractvalue { <8 x ptr>, <8 x i64> } %1379, 1
  %1382 = extractelement <8 x ptr> %1380, i32 0
  %1383 = extractelement <8 x i64> %1381, i32 0
  %1384 = sub i64 %1383, 0
  %1385 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1386 = select i1 %1385, i64 %1384, i64 0
  %private.contiguous.address640 = getelementptr i8, ptr %1382, i64 %1386
  %private.contiguous.preserve641 = load <8 x float>, ptr %private.contiguous.address640, align 4
  %1387 = select <8 x i1> %71, <8 x float> %.state639, <8 x float> %private.contiguous.preserve641
  store <8 x float> %1387, ptr %private.contiguous.address640, align 4
  %.state642 = load i64, ptr %.slot104, align 4
  %1388 = add i64 %.state642, 1
  store i64 %1388, ptr %.slot104, align 4
  br label %direct.schedule.28

direct.schedule.33:                               ; preds = %direct.false558
  store i64 0, ptr %.slot114, align 4
  br label %direct.schedule.34

direct.schedule.34:                               ; preds = %direct.schedule.35, %direct.schedule.33
  %.state643 = load i64, ptr %.slot114, align 4
  %1389 = icmp slt i64 %.state643, 128
  br i1 %1389, label %direct.true644, label %direct.false645

direct.schedule.35:                               ; preds = %direct.true644
  %tile_snapshot.spill.load646 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill103, align 64
  %1390 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load646, 0
  %1391 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load646, 1
  %.state647 = load i64, ptr %.slot114, align 4
  %.splatinsert648 = insertelement <8 x i64> poison, i64 %.state647, i64 0
  %.splat649 = shufflevector <8 x i64> %.splatinsert648, <8 x i64> poison, <8 x i32> zeroinitializer
  %1392 = mul <8 x i64> %.splat649, splat (i64 32)
  %1393 = add <8 x i64> %1391, %1392
  %1394 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1390, 0
  %1395 = insertvalue { <8 x ptr>, <8 x i64> } %1394, <8 x i64> %1393, 1
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1397 = extractvalue { <8 x ptr>, <8 x i64> } %1395, 1
  %1398 = extractelement <8 x ptr> %1396, i32 0
  %1399 = extractelement <8 x i64> %1397, i32 0
  %1400 = sub i64 %1399, 0
  %1401 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1402 = select i1 %1401, i64 %1400, i64 0
  %private.contiguous.address650 = getelementptr i8, ptr %1398, i64 %1402
  %private.contiguous.load651 = load <8 x float>, ptr %private.contiguous.address650, align 4
  %1403 = select <8 x i1> %71, <8 x float> %private.contiguous.load651, <8 x float> zeroinitializer
  %tile_snapshot.spill.load652 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 0
  %1405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 1
  %.state653 = load i64, ptr %.slot114, align 4
  %.splatinsert654 = insertelement <8 x i64> poison, i64 %.state653, i64 0
  %.splat655 = shufflevector <8 x i64> %.splatinsert654, <8 x i64> poison, <8 x i32> zeroinitializer
  %1406 = mul <8 x i64> %.splat655, splat (i64 32)
  %1407 = add <8 x i64> %1405, %1406
  %1408 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1404, 0
  %1409 = insertvalue { <8 x ptr>, <8 x i64> } %1408, <8 x i64> %1407, 1
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1411 = extractvalue { <8 x ptr>, <8 x i64> } %1409, 1
  %1412 = extractelement <8 x ptr> %1410, i32 0
  %1413 = extractelement <8 x i64> %1411, i32 0
  %1414 = sub i64 %1413, 0
  %1415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1416 = select i1 %1415, i64 %1414, i64 0
  %private.contiguous.address656 = getelementptr i8, ptr %1412, i64 %1416
  %private.contiguous.preserve657 = load <8 x float>, ptr %private.contiguous.address656, align 4
  %1417 = select <8 x i1> %71, <8 x float> %1403, <8 x float> %private.contiguous.preserve657
  store <8 x float> %1417, ptr %private.contiguous.address656, align 4
  %.state658 = load i64, ptr %.slot114, align 4
  %1418 = add i64 %.state658, 1
  store i64 %1418, ptr %.slot114, align 4
  br label %direct.schedule.34

direct.schedule.36:                               ; preds = %direct.false645
  store i64 0, ptr %.slot115, align 4
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.38, %direct.schedule.36
  %.state659 = load i64, ptr %.slot115, align 4
  %1419 = icmp slt i64 %.state659, 128
  br i1 %1419, label %direct.true660, label %direct.false661

direct.schedule.38:                               ; preds = %direct.true660
  %tile_snapshot.spill.load662 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load662, 0
  %1421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load662, 1
  %.state663 = load i64, ptr %.slot115, align 4
  %.splatinsert664 = insertelement <8 x i64> poison, i64 %.state663, i64 0
  %.splat665 = shufflevector <8 x i64> %.splatinsert664, <8 x i64> poison, <8 x i32> zeroinitializer
  %1422 = mul <8 x i64> %.splat665, splat (i64 32)
  %1423 = add <8 x i64> %1421, %1422
  %1424 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1420, 0
  %1425 = insertvalue { <8 x ptr>, <8 x i64> } %1424, <8 x i64> %1423, 1
  %1426 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1427 = extractvalue { <8 x ptr>, <8 x i64> } %1425, 1
  %1428 = extractelement <8 x ptr> %1426, i32 0
  %1429 = extractelement <8 x i64> %1427, i32 0
  %1430 = sub i64 %1429, 0
  %1431 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1432 = select i1 %1431, i64 %1430, i64 0
  %private.contiguous.address666 = getelementptr i8, ptr %1428, i64 %1432
  %private.contiguous.load667 = load <8 x float>, ptr %private.contiguous.address666, align 4
  %1433 = select <8 x i1> %71, <8 x float> %private.contiguous.load667, <8 x float> zeroinitializer
  %tile_snapshot.spill.load668 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1434 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load668, 0
  %1435 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load668, 1
  %.state669 = load i64, ptr %.slot115, align 4
  %.splatinsert670 = insertelement <8 x i64> poison, i64 %.state669, i64 0
  %.splat671 = shufflevector <8 x i64> %.splatinsert670, <8 x i64> poison, <8 x i32> zeroinitializer
  %1436 = mul <8 x i64> %.splat671, splat (i64 32)
  %1437 = add <8 x i64> %1435, %1436
  %1438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1434, 0
  %1439 = insertvalue { <8 x ptr>, <8 x i64> } %1438, <8 x i64> %1437, 1
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %1439, 1
  %1442 = extractelement <8 x ptr> %1440, i32 0
  %1443 = extractelement <8 x i64> %1441, i32 0
  %1444 = sub i64 %1443, 0
  %1445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1446 = select i1 %1445, i64 %1444, i64 0
  %private.contiguous.address672 = getelementptr i8, ptr %1442, i64 %1446
  %private.contiguous.preserve673 = load <8 x float>, ptr %private.contiguous.address672, align 4
  %1447 = select <8 x i1> %71, <8 x float> %1433, <8 x float> %private.contiguous.preserve673
  store <8 x float> %1447, ptr %private.contiguous.address672, align 4
  %.state674 = load i64, ptr %.slot115, align 4
  %1448 = add i64 %.state674, 1
  store i64 %1448, ptr %.slot115, align 4
  br label %direct.schedule.37

direct.schedule.39:                               ; preds = %direct.false661
  %.state675 = load i64, ptr %.slot34, align 4
  %1449 = add i64 %.state675, 1
  %.spill.load676 = load <8 x float>, ptr %.spill96, align 32
  %.spill.load677 = load <8 x float>, ptr %.spill102, align 32
  store i64 %1449, ptr %.slot34, align 4
  %1450 = load <8 x float>, ptr %.slot35, align 32
  %1451 = select <8 x i1> %71, <8 x float> %.spill.load676, <8 x float> %1450
  store <8 x float> %1451, ptr %.slot35, align 32
  %1452 = load <8 x float>, ptr %.slot36, align 32
  %1453 = select <8 x i1> %71, <8 x float> %.spill.load677, <8 x float> %1452
  store <8 x float> %1453, ptr %.slot36, align 32
  br label %direct.schedule.4

direct.schedule.40:                               ; preds = %direct.false182
  store i64 0, ptr %.slot116, align 4
  br label %direct.schedule.41

direct.schedule.41:                               ; preds = %direct.schedule.44, %direct.schedule.40
  %.state678 = load i64, ptr %.slot116, align 4
  %1454 = icmp slt i64 %.state678, 2048
  br i1 %1454, label %direct.true679, label %direct.false680

direct.schedule.42:                               ; preds = %direct.true679
  %.state681 = load i64, ptr %.slot116, align 4
  %1455 = srem i64 %.state681, 128
  %.state682 = load i64, ptr %.slot116, align 4
  %1456 = sdiv i64 %.state682, 128
  %.spill.load683 = load i64, ptr %.spill29, align 4
  %1457 = add i64 %.spill.load683, 0
  %.spill.load684 = load <8 x i64>, ptr %.spill30, align 64
  %1458 = add <8 x i64> %.spill.load684, zeroinitializer
  %1459 = mul i64 %1457, 4
  %.splatinsert685 = insertelement <8 x i64> poison, i64 %1459, i64 0
  %.splat686 = shufflevector <8 x i64> %.splatinsert685, <8 x i64> poison, <8 x i32> zeroinitializer
  %1460 = add <8 x i64> %.splat686, %1458
  %.spill.load687 = load i64, ptr %.spill37, align 4
  %1461 = add i64 %.spill.load687, %1456
  %1462 = mul <8 x i64> %1460, splat (i64 8193)
  %.splatinsert688 = insertelement <8 x i64> poison, i64 %1461, i64 0
  %.splat689 = shufflevector <8 x i64> %.splatinsert688, <8 x i64> poison, <8 x i32> zeroinitializer
  %1463 = add <8 x i64> %1462, %.splat689
  %1464 = icmp sge i64 %1461, 0
  %1465 = and i1 true, %1464
  %1466 = icmp slt i64 %1461, 8193
  %1467 = and i1 %1465, %1466
  %1468 = add i64 0, %1455
  %1469 = mul <8 x i64> %1463, splat (i64 128)
  %.splatinsert690 = insertelement <8 x i64> poison, i64 %1468, i64 0
  %.splat691 = shufflevector <8 x i64> %.splatinsert690, <8 x i64> poison, <8 x i32> zeroinitializer
  %1470 = add <8 x i64> %1469, %.splat691
  %1471 = load <8 x i64>, ptr %.spill117, align 64
  %1472 = select <8 x i1> %71, <8 x i64> %1470, <8 x i64> %1471
  store <8 x i64> %1472, ptr %.spill117, align 64
  br i1 %1467, label %direct.true692, label %direct.false693

direct.schedule.43:                               ; preds = %direct.true692
  %.spill.load694 = load <8 x i64>, ptr %.spill117, align 64
  %1473 = extractvalue { ptr, i64 } %41, 0
  %1474 = mul <8 x i64> %.spill.load694, splat (i64 4)
  %1475 = getelementptr i8, ptr %1473, <8 x i64> %1474
  %1476 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1475, <8 x i1> %71, <8 x float> zeroinitializer)
  %1477 = load <8 x float>, ptr %.slot118, align 32
  %1478 = select <8 x i1> %71, <8 x float> %1476, <8 x float> %1477
  store <8 x float> %1478, ptr %.slot118, align 32
  br label %direct.schedule.44

direct.schedule.44:                               ; preds = %direct.false693, %direct.schedule.43
  %tile_snapshot.spill.load695 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill40, align 64
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load695, 0
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load695, 1
  %.state696 = load i64, ptr %.slot116, align 4
  %.splatinsert697 = insertelement <8 x i64> poison, i64 %.state696, i64 0
  %.splat698 = shufflevector <8 x i64> %.splatinsert697, <8 x i64> poison, <8 x i32> zeroinitializer
  %1481 = mul <8 x i64> %.splat698, splat (i64 4)
  %1482 = add <8 x i64> %1480, %1481
  %1483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1479, 0
  %1484 = insertvalue { <8 x ptr>, <8 x i64> } %1483, <8 x i64> %1482, 1
  %.state699 = load <8 x float>, ptr %.slot118, align 32
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %1484, 0
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %1484, 1
  %1487 = getelementptr i8, <8 x ptr> %1485, <8 x i64> %1486
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state699, <8 x ptr> align 1 %1487, <8 x i1> %71)
  %.state700 = load i64, ptr %.slot116, align 4
  %1488 = add i64 %.state700, 1
  store i64 %1488, ptr %.slot116, align 4
  br label %direct.schedule.41

direct.schedule.45:                               ; preds = %direct.false156
  store i64 0, ptr %.slot119, align 4
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.49, %direct.schedule.45
  %.state701 = load i64, ptr %.slot119, align 4
  %1489 = icmp slt i64 %.state701, 2048
  br i1 %1489, label %direct.true702, label %direct.false703

direct.schedule.47:                               ; preds = %direct.true702
  %.state704 = load i64, ptr %.slot119, align 4
  %1490 = srem i64 %.state704, 128
  %.state705 = load i64, ptr %.slot119, align 4
  %1491 = sdiv i64 %.state705, 128
  %.spill.load706 = load i64, ptr %.spill29, align 4
  %1492 = add i64 %.spill.load706, 0
  %.spill.load707 = load <8 x i64>, ptr %.spill30, align 64
  %1493 = add <8 x i64> %.spill.load707, zeroinitializer
  %1494 = mul i64 %1492, 4
  %.splatinsert708 = insertelement <8 x i64> poison, i64 %1494, i64 0
  %.splat709 = shufflevector <8 x i64> %.splatinsert708, <8 x i64> poison, <8 x i32> zeroinitializer
  %1495 = add <8 x i64> %.splat709, %1493
  %.spill.load710 = load i64, ptr %.spill37, align 4
  %1496 = add i64 %.spill.load710, %1491
  %1497 = mul <8 x i64> %1495, splat (i64 8193)
  %.splatinsert711 = insertelement <8 x i64> poison, i64 %1496, i64 0
  %.splat712 = shufflevector <8 x i64> %.splatinsert711, <8 x i64> poison, <8 x i32> zeroinitializer
  %1498 = add <8 x i64> %1497, %.splat712
  %1499 = icmp sge i64 %1496, 0
  %1500 = and i1 true, %1499
  %1501 = icmp slt i64 %1496, 8193
  %1502 = and i1 %1500, %1501
  %1503 = add i64 0, %1490
  %1504 = mul <8 x i64> %1498, splat (i64 128)
  %.splatinsert713 = insertelement <8 x i64> poison, i64 %1503, i64 0
  %.splat714 = shufflevector <8 x i64> %.splatinsert713, <8 x i64> poison, <8 x i32> zeroinitializer
  %1505 = add <8 x i64> %1504, %.splat714
  %1506 = load <8 x i64>, ptr %.spill120, align 64
  %1507 = select <8 x i1> %71, <8 x i64> %1505, <8 x i64> %1506
  store <8 x i64> %1507, ptr %.spill120, align 64
  br i1 %1502, label %direct.true715, label %direct.false716

direct.schedule.48:                               ; preds = %direct.true715
  %.spill.load717 = load <8 x i64>, ptr %.spill120, align 64
  %1508 = extractvalue { ptr, i64 } %35, 0
  %1509 = mul <8 x i64> %.spill.load717, splat (i64 4)
  %1510 = getelementptr i8, ptr %1508, <8 x i64> %1509
  %1511 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1510, <8 x i1> %71, <8 x float> zeroinitializer)
  %1512 = load <8 x float>, ptr %.slot121, align 32
  %1513 = select <8 x i1> %71, <8 x float> %1511, <8 x float> %1512
  store <8 x float> %1513, ptr %.slot121, align 32
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.false716, %direct.schedule.48
  %tile_snapshot.spill.load718 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %1514 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load718, 0
  %1515 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load718, 1
  %.state719 = load i64, ptr %.slot119, align 4
  %.splatinsert720 = insertelement <8 x i64> poison, i64 %.state719, i64 0
  %.splat721 = shufflevector <8 x i64> %.splatinsert720, <8 x i64> poison, <8 x i32> zeroinitializer
  %1516 = mul <8 x i64> %.splat721, splat (i64 4)
  %1517 = add <8 x i64> %1515, %1516
  %1518 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1514, 0
  %1519 = insertvalue { <8 x ptr>, <8 x i64> } %1518, <8 x i64> %1517, 1
  %.state722 = load <8 x float>, ptr %.slot121, align 32
  %1520 = extractvalue { <8 x ptr>, <8 x i64> } %1519, 0
  %1521 = extractvalue { <8 x ptr>, <8 x i64> } %1519, 1
  %1522 = getelementptr i8, <8 x ptr> %1520, <8 x i64> %1521
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state722, <8 x ptr> align 1 %1522, <8 x i1> %71)
  %.state723 = load i64, ptr %.slot119, align 4
  %1523 = add i64 %.state723, 1
  store i64 %1523, ptr %.slot119, align 4
  br label %direct.schedule.46

direct.schedule.50:                               ; preds = %direct.false153
  store i64 0, ptr %.slot122, align 4
  br label %direct.schedule.51

direct.schedule.51:                               ; preds = %direct.schedule.52, %direct.schedule.50
  %.state724 = load i64, ptr %.slot122, align 4
  %1524 = icmp slt i64 %.state724, 128
  br i1 %1524, label %direct.true725, label %direct.false726

direct.schedule.52:                               ; preds = %direct.true725
  %.spill.load727 = load i64, ptr %.spill29, align 4
  %1525 = add i64 %.spill.load727, 0
  %.spill.load728 = load <8 x i64>, ptr %.spill, align 64
  %1526 = add <8 x i64> %.spill.load728, zeroinitializer
  %1527 = mul i64 %1525, 16
  %.splatinsert729 = insertelement <8 x i64> poison, i64 %1527, i64 0
  %.splat730 = shufflevector <8 x i64> %.splatinsert729, <8 x i64> poison, <8 x i32> zeroinitializer
  %1528 = add <8 x i64> %.splat730, %1526
  %1529 = mul <8 x i64> %1528, splat (i64 1)
  %.spill.load731 = load i64, ptr %.spill31, align 4
  %.splatinsert732 = insertelement <8 x i64> poison, i64 %.spill.load731, i64 0
  %.splat733 = shufflevector <8 x i64> %.splatinsert732, <8 x i64> poison, <8 x i32> zeroinitializer
  %1530 = add <8 x i64> %1529, %.splat733
  %.state734 = load i64, ptr %.slot122, align 4
  %1531 = add i64 0, %.state734
  %1532 = mul <8 x i64> %1530, splat (i64 128)
  %.splatinsert735 = insertelement <8 x i64> poison, i64 %1531, i64 0
  %.splat736 = shufflevector <8 x i64> %.splatinsert735, <8 x i64> poison, <8 x i32> zeroinitializer
  %1533 = add <8 x i64> %1532, %.splat736
  %.state737 = load i64, ptr %.slot122, align 4
  %1534 = add i64 0, %.state737
  %tile_snapshot.spill.load738 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1535 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load738, 0
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load738, 1
  %.splatinsert739 = insertelement <8 x i64> poison, i64 %1534, i64 0
  %.splat740 = shufflevector <8 x i64> %.splatinsert739, <8 x i64> poison, <8 x i32> zeroinitializer
  %1537 = mul <8 x i64> %.splat740, splat (i64 32)
  %1538 = add <8 x i64> %1536, %1537
  %1539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1535, 0
  %1540 = insertvalue { <8 x ptr>, <8 x i64> } %1539, <8 x i64> %1538, 1
  %1541 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %1540, 1
  %1543 = extractelement <8 x ptr> %1541, i32 0
  %1544 = extractelement <8 x i64> %1542, i32 0
  %1545 = sub i64 %1544, 0
  %1546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %71)
  %1547 = select i1 %1546, i64 %1545, i64 0
  %private.contiguous.address741 = getelementptr i8, ptr %1543, i64 %1547
  %private.contiguous.load742 = load <8 x float>, ptr %private.contiguous.address741, align 4
  %1548 = select <8 x i1> %71, <8 x float> %private.contiguous.load742, <8 x float> zeroinitializer
  %.state743 = load <8 x float>, ptr %.slot36, align 32
  %1549 = fdiv <8 x float> %1548, %.state743
  %1550 = extractvalue { ptr, i64 } %47, 0
  %1551 = mul <8 x i64> %1533, splat (i64 4)
  %1552 = getelementptr i8, ptr %1550, <8 x i64> %1551
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1549, <8 x ptr> align 1 %1552, <8 x i1> %71)
  %.state744 = load i64, ptr %.slot122, align 4
  %1553 = add i64 %.state744, 1
  store i64 %1553, ptr %.slot122, align 4
  br label %direct.schedule.51

direct.schedule.53:                               ; preds = %direct.false726
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

copy.active:                                      ; preds = %direct.schedule.0
  %1554 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1555 = extractelement <8 x ptr> %1554, i64 0
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1557 = extractelement <8 x i64> %1556, i64 0
  %1558 = getelementptr i8, ptr %1555, i64 %1557
  %1559 = extractelement <8 x i64> %98, i64 0
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1559, ptr %1558)
  br label %copy.continue

copy.continue:                                    ; preds = %copy.active, %direct.schedule.0
  %1560 = extractelement <8 x i1> %71, i64 1
  br i1 %1560, label %copy.active133, label %copy.continue134

copy.active133:                                   ; preds = %copy.continue
  %1561 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1562 = extractelement <8 x ptr> %1561, i64 1
  %1563 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1564 = extractelement <8 x i64> %1563, i64 1
  %1565 = getelementptr i8, ptr %1562, i64 %1564
  %1566 = extractelement <8 x i64> %98, i64 1
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1566, ptr %1565)
  br label %copy.continue134

copy.continue134:                                 ; preds = %copy.active133, %copy.continue
  %1567 = extractelement <8 x i1> %71, i64 2
  br i1 %1567, label %copy.active135, label %copy.continue136

copy.active135:                                   ; preds = %copy.continue134
  %1568 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1569 = extractelement <8 x ptr> %1568, i64 2
  %1570 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1571 = extractelement <8 x i64> %1570, i64 2
  %1572 = getelementptr i8, ptr %1569, i64 %1571
  %1573 = extractelement <8 x i64> %98, i64 2
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1573, ptr %1572)
  br label %copy.continue136

copy.continue136:                                 ; preds = %copy.active135, %copy.continue134
  %1574 = extractelement <8 x i1> %71, i64 3
  br i1 %1574, label %copy.active137, label %copy.continue138

copy.active137:                                   ; preds = %copy.continue136
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1576 = extractelement <8 x ptr> %1575, i64 3
  %1577 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1578 = extractelement <8 x i64> %1577, i64 3
  %1579 = getelementptr i8, ptr %1576, i64 %1578
  %1580 = extractelement <8 x i64> %98, i64 3
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1580, ptr %1579)
  br label %copy.continue138

copy.continue138:                                 ; preds = %copy.active137, %copy.continue136
  %1581 = extractelement <8 x i1> %71, i64 4
  br i1 %1581, label %copy.active139, label %copy.continue140

copy.active139:                                   ; preds = %copy.continue138
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1583 = extractelement <8 x ptr> %1582, i64 4
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1585 = extractelement <8 x i64> %1584, i64 4
  %1586 = getelementptr i8, ptr %1583, i64 %1585
  %1587 = extractelement <8 x i64> %98, i64 4
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1587, ptr %1586)
  br label %copy.continue140

copy.continue140:                                 ; preds = %copy.active139, %copy.continue138
  %1588 = extractelement <8 x i1> %71, i64 5
  br i1 %1588, label %copy.active141, label %copy.continue142

copy.active141:                                   ; preds = %copy.continue140
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1590 = extractelement <8 x ptr> %1589, i64 5
  %1591 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1592 = extractelement <8 x i64> %1591, i64 5
  %1593 = getelementptr i8, ptr %1590, i64 %1592
  %1594 = extractelement <8 x i64> %98, i64 5
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1594, ptr %1593)
  br label %copy.continue142

copy.continue142:                                 ; preds = %copy.active141, %copy.continue140
  %1595 = extractelement <8 x i1> %71, i64 6
  br i1 %1595, label %copy.active143, label %copy.continue144

copy.active143:                                   ; preds = %copy.continue142
  %1596 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1597 = extractelement <8 x ptr> %1596, i64 6
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1599 = extractelement <8 x i64> %1598, i64 6
  %1600 = getelementptr i8, ptr %1597, i64 %1599
  %1601 = extractelement <8 x i64> %98, i64 6
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1601, ptr %1600)
  br label %copy.continue144

copy.continue144:                                 ; preds = %copy.active143, %copy.continue142
  %1602 = extractelement <8 x i1> %71, i64 7
  br i1 %1602, label %copy.active145, label %copy.continue146

copy.active145:                                   ; preds = %copy.continue144
  %1603 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %1604 = extractelement <8 x ptr> %1603, i64 7
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %1606 = extractelement <8 x i64> %1605, i64 7
  %1607 = getelementptr i8, ptr %1604, i64 %1606
  %1608 = extractelement <8 x i64> %98, i64 7
  call void @llm_attention.contiguous_copy(ptr %99, i64 %1608, ptr %1607)
  br label %copy.continue146

copy.continue146:                                 ; preds = %copy.active145, %copy.continue144
  %1609 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1610 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1611 = extractvalue { <8 x ptr>, <8 x i64> } %1609, 0
  %1612 = select <8 x i1> %71, <8 x ptr> %1610, <8 x ptr> %1611
  %1613 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1614 = extractvalue { <8 x ptr>, <8 x i64> } %1609, 1
  %1615 = select <8 x i1> %71, <8 x i64> %1613, <8 x i64> %1614
  %1616 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1612, 0
  %1617 = insertvalue { <8 x ptr>, <8 x i64> } %1616, <8 x i64> %1615, 1
  store { <8 x ptr>, <8 x i64> } %1617, ptr %tile_snapshot.spill32, align 64
  %1618 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill33, align 64
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1620 = extractvalue { <8 x ptr>, <8 x i64> } %1618, 0
  %1621 = select <8 x i1> %71, <8 x ptr> %1619, <8 x ptr> %1620
  %1622 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %1618, 1
  %1624 = select <8 x i1> %71, <8 x i64> %1622, <8 x i64> %1623
  %1625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1621, 0
  %1626 = insertvalue { <8 x ptr>, <8 x i64> } %1625, <8 x i64> %1624, 1
  store { <8 x ptr>, <8 x i64> } %1626, ptr %tile_snapshot.spill33, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true152:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false153:                                  ; preds = %direct.schedule.4
  br label %direct.schedule.50

direct.true155:                                   ; preds = %direct.schedule.5
  br label %direct.schedule.6

direct.false156:                                  ; preds = %direct.schedule.5
  br label %direct.schedule.45

copy.active164:                                   ; preds = %direct.schedule.6
  %1627 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1628 = extractelement <8 x ptr> %1627, i64 0
  %1629 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1630 = extractelement <8 x i64> %1629, i64 0
  %1631 = getelementptr i8, ptr %1628, i64 %1630
  %1632 = extractelement <8 x i64> %142, i64 0
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1632, ptr %1631)
  br label %copy.continue165

copy.continue165:                                 ; preds = %copy.active164, %direct.schedule.6
  %1633 = extractelement <8 x i1> %71, i64 1
  br i1 %1633, label %copy.active166, label %copy.continue167

copy.active166:                                   ; preds = %copy.continue165
  %1634 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1635 = extractelement <8 x ptr> %1634, i64 1
  %1636 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1637 = extractelement <8 x i64> %1636, i64 1
  %1638 = getelementptr i8, ptr %1635, i64 %1637
  %1639 = extractelement <8 x i64> %142, i64 1
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1639, ptr %1638)
  br label %copy.continue167

copy.continue167:                                 ; preds = %copy.active166, %copy.continue165
  %1640 = extractelement <8 x i1> %71, i64 2
  br i1 %1640, label %copy.active168, label %copy.continue169

copy.active168:                                   ; preds = %copy.continue167
  %1641 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1642 = extractelement <8 x ptr> %1641, i64 2
  %1643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1644 = extractelement <8 x i64> %1643, i64 2
  %1645 = getelementptr i8, ptr %1642, i64 %1644
  %1646 = extractelement <8 x i64> %142, i64 2
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1646, ptr %1645)
  br label %copy.continue169

copy.continue169:                                 ; preds = %copy.active168, %copy.continue167
  %1647 = extractelement <8 x i1> %71, i64 3
  br i1 %1647, label %copy.active170, label %copy.continue171

copy.active170:                                   ; preds = %copy.continue169
  %1648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1649 = extractelement <8 x ptr> %1648, i64 3
  %1650 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1651 = extractelement <8 x i64> %1650, i64 3
  %1652 = getelementptr i8, ptr %1649, i64 %1651
  %1653 = extractelement <8 x i64> %142, i64 3
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1653, ptr %1652)
  br label %copy.continue171

copy.continue171:                                 ; preds = %copy.active170, %copy.continue169
  %1654 = extractelement <8 x i1> %71, i64 4
  br i1 %1654, label %copy.active172, label %copy.continue173

copy.active172:                                   ; preds = %copy.continue171
  %1655 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1656 = extractelement <8 x ptr> %1655, i64 4
  %1657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1658 = extractelement <8 x i64> %1657, i64 4
  %1659 = getelementptr i8, ptr %1656, i64 %1658
  %1660 = extractelement <8 x i64> %142, i64 4
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1660, ptr %1659)
  br label %copy.continue173

copy.continue173:                                 ; preds = %copy.active172, %copy.continue171
  %1661 = extractelement <8 x i1> %71, i64 5
  br i1 %1661, label %copy.active174, label %copy.continue175

copy.active174:                                   ; preds = %copy.continue173
  %1662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1663 = extractelement <8 x ptr> %1662, i64 5
  %1664 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1665 = extractelement <8 x i64> %1664, i64 5
  %1666 = getelementptr i8, ptr %1663, i64 %1665
  %1667 = extractelement <8 x i64> %142, i64 5
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1667, ptr %1666)
  br label %copy.continue175

copy.continue175:                                 ; preds = %copy.active174, %copy.continue173
  %1668 = extractelement <8 x i1> %71, i64 6
  br i1 %1668, label %copy.active176, label %copy.continue177

copy.active176:                                   ; preds = %copy.continue175
  %1669 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1670 = extractelement <8 x ptr> %1669, i64 6
  %1671 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1672 = extractelement <8 x i64> %1671, i64 6
  %1673 = getelementptr i8, ptr %1670, i64 %1672
  %1674 = extractelement <8 x i64> %142, i64 6
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1674, ptr %1673)
  br label %copy.continue177

copy.continue177:                                 ; preds = %copy.active176, %copy.continue175
  %1675 = extractelement <8 x i1> %71, i64 7
  br i1 %1675, label %copy.active178, label %copy.continue179

copy.active178:                                   ; preds = %copy.continue177
  %1676 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %1677 = extractelement <8 x ptr> %1676, i64 7
  %1678 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %1679 = extractelement <8 x i64> %1678, i64 7
  %1680 = getelementptr i8, ptr %1677, i64 %1679
  %1681 = extractelement <8 x i64> %142, i64 7
  call void @llm_attention.contiguous_copy.1(ptr %143, i64 %1681, ptr %1680)
  br label %copy.continue179

copy.continue179:                                 ; preds = %copy.active178, %copy.continue177
  br label %direct.schedule.7

direct.true181:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false182:                                  ; preds = %direct.schedule.7
  br label %direct.schedule.40

copy.active191:                                   ; preds = %direct.schedule.8
  %1682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1683 = extractelement <8 x ptr> %1682, i64 0
  %1684 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1685 = extractelement <8 x i64> %1684, i64 0
  %1686 = getelementptr i8, ptr %1683, i64 %1685
  %1687 = extractelement <8 x i64> %159, i64 0
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1687, ptr %1686)
  br label %copy.continue192

copy.continue192:                                 ; preds = %copy.active191, %direct.schedule.8
  %1688 = extractelement <8 x i1> %71, i64 1
  br i1 %1688, label %copy.active193, label %copy.continue194

copy.active193:                                   ; preds = %copy.continue192
  %1689 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1690 = extractelement <8 x ptr> %1689, i64 1
  %1691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1692 = extractelement <8 x i64> %1691, i64 1
  %1693 = getelementptr i8, ptr %1690, i64 %1692
  %1694 = extractelement <8 x i64> %159, i64 1
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1694, ptr %1693)
  br label %copy.continue194

copy.continue194:                                 ; preds = %copy.active193, %copy.continue192
  %1695 = extractelement <8 x i1> %71, i64 2
  br i1 %1695, label %copy.active195, label %copy.continue196

copy.active195:                                   ; preds = %copy.continue194
  %1696 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1697 = extractelement <8 x ptr> %1696, i64 2
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1699 = extractelement <8 x i64> %1698, i64 2
  %1700 = getelementptr i8, ptr %1697, i64 %1699
  %1701 = extractelement <8 x i64> %159, i64 2
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1701, ptr %1700)
  br label %copy.continue196

copy.continue196:                                 ; preds = %copy.active195, %copy.continue194
  %1702 = extractelement <8 x i1> %71, i64 3
  br i1 %1702, label %copy.active197, label %copy.continue198

copy.active197:                                   ; preds = %copy.continue196
  %1703 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1704 = extractelement <8 x ptr> %1703, i64 3
  %1705 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1706 = extractelement <8 x i64> %1705, i64 3
  %1707 = getelementptr i8, ptr %1704, i64 %1706
  %1708 = extractelement <8 x i64> %159, i64 3
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1708, ptr %1707)
  br label %copy.continue198

copy.continue198:                                 ; preds = %copy.active197, %copy.continue196
  %1709 = extractelement <8 x i1> %71, i64 4
  br i1 %1709, label %copy.active199, label %copy.continue200

copy.active199:                                   ; preds = %copy.continue198
  %1710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1711 = extractelement <8 x ptr> %1710, i64 4
  %1712 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1713 = extractelement <8 x i64> %1712, i64 4
  %1714 = getelementptr i8, ptr %1711, i64 %1713
  %1715 = extractelement <8 x i64> %159, i64 4
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1715, ptr %1714)
  br label %copy.continue200

copy.continue200:                                 ; preds = %copy.active199, %copy.continue198
  %1716 = extractelement <8 x i1> %71, i64 5
  br i1 %1716, label %copy.active201, label %copy.continue202

copy.active201:                                   ; preds = %copy.continue200
  %1717 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1718 = extractelement <8 x ptr> %1717, i64 5
  %1719 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1720 = extractelement <8 x i64> %1719, i64 5
  %1721 = getelementptr i8, ptr %1718, i64 %1720
  %1722 = extractelement <8 x i64> %159, i64 5
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1722, ptr %1721)
  br label %copy.continue202

copy.continue202:                                 ; preds = %copy.active201, %copy.continue200
  %1723 = extractelement <8 x i1> %71, i64 6
  br i1 %1723, label %copy.active203, label %copy.continue204

copy.active203:                                   ; preds = %copy.continue202
  %1724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1725 = extractelement <8 x ptr> %1724, i64 6
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1727 = extractelement <8 x i64> %1726, i64 6
  %1728 = getelementptr i8, ptr %1725, i64 %1727
  %1729 = extractelement <8 x i64> %159, i64 6
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1729, ptr %1728)
  br label %copy.continue204

copy.continue204:                                 ; preds = %copy.active203, %copy.continue202
  %1730 = extractelement <8 x i1> %71, i64 7
  br i1 %1730, label %copy.active205, label %copy.continue206

copy.active205:                                   ; preds = %copy.continue204
  %1731 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 0
  %1732 = extractelement <8 x ptr> %1731, i64 7
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load190, 1
  %1734 = extractelement <8 x i64> %1733, i64 7
  %1735 = getelementptr i8, ptr %1732, i64 %1734
  %1736 = extractelement <8 x i64> %159, i64 7
  call void @llm_attention.contiguous_copy.2(ptr %160, i64 %1736, ptr %1735)
  br label %copy.continue206

copy.continue206:                                 ; preds = %copy.active205, %copy.continue204
  br label %direct.schedule.9

direct.true208:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false209:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true235:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false236:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true263:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false264:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true291:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false292:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true416:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false417:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24

direct.true543:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false544:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.27

direct.true557:                                   ; preds = %direct.schedule.28
  br label %direct.schedule.29

direct.false558:                                  ; preds = %direct.schedule.28
  br label %direct.schedule.33

direct.true585:                                   ; preds = %direct.schedule.30
  br label %direct.schedule.31

direct.false586:                                  ; preds = %direct.schedule.30
  br label %direct.schedule.32

direct.true644:                                   ; preds = %direct.schedule.34
  br label %direct.schedule.35

direct.false645:                                  ; preds = %direct.schedule.34
  br label %direct.schedule.36

direct.true660:                                   ; preds = %direct.schedule.37
  br label %direct.schedule.38

direct.false661:                                  ; preds = %direct.schedule.37
  br label %direct.schedule.39

direct.true679:                                   ; preds = %direct.schedule.41
  br label %direct.schedule.42

direct.false680:                                  ; preds = %direct.schedule.41
  br label %direct.schedule.9

direct.true692:                                   ; preds = %direct.schedule.42
  br label %direct.schedule.43

direct.false693:                                  ; preds = %direct.schedule.42
  %1737 = load <8 x float>, ptr %.slot118, align 32
  %1738 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1737
  store <8 x float> %1738, ptr %.slot118, align 32
  br label %direct.schedule.44

direct.true702:                                   ; preds = %direct.schedule.46
  br label %direct.schedule.47

direct.false703:                                  ; preds = %direct.schedule.46
  br label %direct.schedule.7

direct.true715:                                   ; preds = %direct.schedule.47
  br label %direct.schedule.48

direct.false716:                                  ; preds = %direct.schedule.47
  %1739 = load <8 x float>, ptr %.slot121, align 32
  %1740 = select <8 x i1> %71, <8 x float> zeroinitializer, <8 x float> %1739
  store <8 x float> %1740, ptr %.slot121, align 32
  br label %direct.schedule.49

direct.true725:                                   ; preds = %direct.schedule.51
  br label %direct.schedule.52

direct.false726:                                  ; preds = %direct.schedule.51
  br label %direct.schedule.53
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention.full_packet(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nounwind willreturn }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(write) }

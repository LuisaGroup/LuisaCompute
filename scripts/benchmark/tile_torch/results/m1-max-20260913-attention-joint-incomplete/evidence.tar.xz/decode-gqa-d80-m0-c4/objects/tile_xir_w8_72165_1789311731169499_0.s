	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.full_packet
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	0                               ; 0x0
	.quad	5120                            ; 0x1400
lCPI0_3:
	.quad	10240                           ; 0x2800
	.quad	15360                           ; 0x3c00
lCPI0_4:
	.quad	20480                           ; 0x5000
	.quad	25600                           ; 0x6400
lCPI0_5:
	.quad	30720                           ; 0x7800
	.quad	35840                           ; 0x8c00
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	6144                            ; 0x1800
lCPI0_7:
	.quad	12288                           ; 0x3000
	.quad	18432                           ; 0x4800
lCPI0_8:
	.quad	24576                           ; 0x6000
	.quad	30720                           ; 0x7800
lCPI0_9:
	.quad	36864                           ; 0x9000
	.quad	43008                           ; 0xa800
lCPI0_10:
	.quad	0                               ; 0x0
	.quad	320                             ; 0x140
lCPI0_11:
	.quad	640                             ; 0x280
	.quad	960                             ; 0x3c0
lCPI0_12:
	.quad	1280                            ; 0x500
	.quad	1600                            ; 0x640
lCPI0_13:
	.quad	1920                            ; 0x780
	.quad	2240                            ; 0x8c0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention.full_packet:             ; @llm_attention.full_packet
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2336
	ldr	x22, [x1, #136]
	add	x20, x22, #2560
	ldr	x8, [x0]
	ldr	x19, [x0, #16]
	ldr	x9, [x0, #32]
	str	x9, [sp, #592]                  ; 8-byte Spill
	ldr	x9, [x0, #48]
	str	x9, [sp, #8]                    ; 8-byte Spill
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	add	w9, w10, w9, lsl #5
	dup.4s	v0, w9
Lloh0:
	adrp	x9, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x9, lCPI0_0@PAGEOFF]
	add.4s	v3, v0, v1
Lloh2:
	adrp	x9, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x9, lCPI0_1@PAGEOFF]
	add.4s	v1, v0, v1
	ushll2.2d	v2, v1, #0
	ushll2.2d	v0, v3, #0
	stp	q0, q2, [sp, #48]               ; 32-byte Folded Spill
	ushll.2d	v2, v1, #0
	ushll.2d	v0, v3, #0
	stp	q0, q2, [sp, #16]               ; 32-byte Folded Spill
	movi.4s	v2, #80
	umull2.2d	v0, v1, v2
	movi.2s	v4, #80
	umull.2d	v1, v1, v4
	umull2.2d	v2, v3, v2
	umull.2d	v3, v3, v4
	mov.d	x9, v3[1]
	fmov	x10, d3
	add	x10, x8, x10, lsl #2
	ldr	q3, [x10]
	str	q3, [x22]
	ldr	q3, [x10, #16]
	str	q3, [x22, #16]
	ldr	q3, [x10, #32]
	str	q3, [x22, #32]
	ldr	q3, [x10, #48]
	str	q3, [x22, #48]
	ldr	q3, [x10, #64]
	str	q3, [x22, #64]
	ldr	q3, [x10, #80]
	str	q3, [x22, #80]
	ldr	q3, [x10, #96]
	str	q3, [x22, #96]
	ldr	q3, [x10, #112]
	str	q3, [x22, #112]
	ldr	q3, [x10, #128]
	str	q3, [x22, #128]
	ldr	q3, [x10, #144]
	str	q3, [x22, #144]
	ldr	q3, [x10, #160]
	str	q3, [x22, #160]
	ldr	q3, [x10, #176]
	str	q3, [x22, #176]
	ldr	q3, [x10, #192]
	str	q3, [x22, #192]
	ldr	q3, [x10, #208]
	str	q3, [x22, #208]
	ldr	q3, [x10, #224]
	str	q3, [x22, #224]
	ldr	q3, [x10, #240]
	str	q3, [x22, #240]
	ldr	q3, [x10, #256]
	str	q3, [x22, #256]
	ldr	q3, [x10, #272]
	str	q3, [x22, #272]
	ldr	q3, [x10, #288]
	str	q3, [x22, #288]
	ldr	q3, [x10, #304]
	str	q3, [x22, #304]
	add	x9, x8, x9, lsl #2
	ldr	q3, [x9]
	str	q3, [x22, #320]
	ldr	q3, [x9, #16]
	str	q3, [x22, #336]
	ldr	q3, [x9, #32]
	str	q3, [x22, #352]
	ldr	q3, [x9, #48]
	str	q3, [x22, #368]
	ldr	q3, [x9, #64]
	str	q3, [x22, #384]
	ldr	q3, [x9, #80]
	str	q3, [x22, #400]
	ldr	q3, [x9, #96]
	str	q3, [x22, #416]
	ldr	q3, [x9, #112]
	str	q3, [x22, #432]
	ldr	q3, [x9, #128]
	str	q3, [x22, #448]
	ldr	q3, [x9, #144]
	str	q3, [x22, #464]
	ldr	q3, [x9, #160]
	str	q3, [x22, #480]
	ldr	q3, [x9, #176]
	str	q3, [x22, #496]
	ldr	q3, [x9, #192]
	str	q3, [x22, #512]
	ldr	q3, [x9, #208]
	str	q3, [x22, #528]
	ldr	q3, [x9, #224]
	str	q3, [x22, #544]
	ldr	q3, [x9, #240]
	str	q3, [x22, #560]
	ldr	q3, [x9, #256]
	str	q3, [x22, #576]
	ldr	q3, [x9, #272]
	str	q3, [x22, #592]
	ldr	q3, [x9, #288]
	str	q3, [x22, #608]
	ldr	q3, [x9, #304]
	str	q3, [x22, #624]
	mov.d	x9, v2[1]
	fmov	x10, d2
	add	x10, x8, x10, lsl #2
	ldr	q2, [x10]
	str	q2, [x22, #640]
	ldr	q2, [x10, #16]
	str	q2, [x22, #656]
	ldr	q2, [x10, #32]
	str	q2, [x22, #672]
	ldr	q2, [x10, #48]
	str	q2, [x22, #688]
	ldr	q2, [x10, #64]
	str	q2, [x22, #704]
	ldr	q2, [x10, #80]
	str	q2, [x22, #720]
	ldr	q2, [x10, #96]
	str	q2, [x22, #736]
	ldr	q2, [x10, #112]
	str	q2, [x22, #752]
	ldr	q2, [x10, #128]
	str	q2, [x22, #768]
	ldr	q2, [x10, #144]
	str	q2, [x22, #784]
	ldr	q2, [x10, #160]
	str	q2, [x22, #800]
	ldr	q2, [x10, #176]
	str	q2, [x22, #816]
	ldr	q2, [x10, #192]
	str	q2, [x22, #832]
	ldr	q2, [x10, #208]
	str	q2, [x22, #848]
	ldr	q2, [x10, #224]
	str	q2, [x22, #864]
	ldr	q2, [x10, #240]
	str	q2, [x22, #880]
	ldr	q2, [x10, #256]
	str	q2, [x22, #896]
	ldr	q2, [x10, #272]
	str	q2, [x22, #912]
	ldr	q2, [x10, #288]
	str	q2, [x22, #928]
	ldr	q2, [x10, #304]
	str	q2, [x22, #944]
	add	x9, x8, x9, lsl #2
	ldr	q2, [x9]
	str	q2, [x22, #960]
	ldr	q2, [x9, #16]
	str	q2, [x22, #976]
	ldr	q2, [x9, #32]
	str	q2, [x22, #992]
	ldr	q2, [x9, #48]
	str	q2, [x22, #1008]
	ldr	q2, [x9, #64]
	str	q2, [x22, #1024]
	ldr	q2, [x9, #80]
	str	q2, [x22, #1040]
	ldr	q2, [x9, #96]
	str	q2, [x22, #1056]
	ldr	q2, [x9, #112]
	str	q2, [x22, #1072]
	ldr	q2, [x9, #128]
	str	q2, [x22, #1088]
	ldr	q2, [x9, #144]
	str	q2, [x22, #1104]
	ldr	q2, [x9, #160]
	str	q2, [x22, #1120]
	ldr	q2, [x9, #176]
	str	q2, [x22, #1136]
	ldr	q2, [x9, #192]
	str	q2, [x22, #1152]
	ldr	q2, [x9, #208]
	str	q2, [x22, #1168]
	ldr	q2, [x9, #224]
	str	q2, [x22, #1184]
	ldr	q2, [x9, #240]
	str	q2, [x22, #1200]
	ldr	q2, [x9, #256]
	str	q2, [x22, #1216]
	ldr	q2, [x9, #272]
	str	q2, [x22, #1232]
	ldr	q2, [x9, #288]
	str	q2, [x22, #1248]
	ldr	q2, [x9, #304]
	str	q2, [x22, #1264]
	mov.d	x9, v1[1]
	fmov	x10, d1
	add	x10, x8, x10, lsl #2
	ldr	q1, [x10]
	str	q1, [x22, #1280]
	ldr	q1, [x10, #16]
	str	q1, [x22, #1296]
	ldr	q1, [x10, #32]
	str	q1, [x22, #1312]
	ldr	q1, [x10, #48]
	str	q1, [x22, #1328]
	ldr	q1, [x10, #64]
	str	q1, [x22, #1344]
	ldr	q1, [x10, #80]
	str	q1, [x22, #1360]
	ldr	q1, [x10, #96]
	str	q1, [x22, #1376]
	ldr	q1, [x10, #112]
	str	q1, [x22, #1392]
	ldr	q1, [x10, #128]
	str	q1, [x22, #1408]
	ldr	q1, [x10, #144]
	str	q1, [x22, #1424]
	ldr	q1, [x10, #160]
	str	q1, [x22, #1440]
	ldr	q1, [x10, #176]
	str	q1, [x22, #1456]
	ldr	q1, [x10, #192]
	str	q1, [x22, #1472]
	ldr	q1, [x10, #208]
	str	q1, [x22, #1488]
	ldr	q1, [x10, #224]
	str	q1, [x22, #1504]
	ldr	q1, [x10, #240]
	str	q1, [x22, #1520]
	ldr	q1, [x10, #256]
	str	q1, [x22, #1536]
	ldr	q1, [x10, #272]
	str	q1, [x22, #1552]
	ldr	q1, [x10, #288]
	str	q1, [x22, #1568]
	ldr	q1, [x10, #304]
	str	q1, [x22, #1584]
	add	x9, x8, x9, lsl #2
	ldr	q1, [x9]
	str	q1, [x22, #1600]
	ldr	q1, [x9, #16]
	str	q1, [x22, #1616]
	ldr	q1, [x9, #32]
	str	q1, [x22, #1632]
	ldr	q1, [x9, #48]
	str	q1, [x22, #1648]
	ldr	q1, [x9, #64]
	str	q1, [x22, #1664]
	ldr	q1, [x9, #80]
	str	q1, [x22, #1680]
	ldr	q1, [x9, #96]
	str	q1, [x22, #1696]
	ldr	q1, [x9, #112]
	str	q1, [x22, #1712]
	ldr	q1, [x9, #128]
	str	q1, [x22, #1728]
	ldr	q1, [x9, #144]
	str	q1, [x22, #1744]
	ldr	q1, [x9, #160]
	str	q1, [x22, #1760]
	ldr	q1, [x9, #176]
	str	q1, [x22, #1776]
	ldr	q1, [x9, #192]
	str	q1, [x22, #1792]
	ldr	q1, [x9, #208]
	str	q1, [x22, #1808]
	ldr	q1, [x9, #224]
	str	q1, [x22, #1824]
	ldr	q1, [x9, #240]
	str	q1, [x22, #1840]
	ldr	q1, [x9, #256]
	str	q1, [x22, #1856]
	ldr	q1, [x9, #272]
	str	q1, [x22, #1872]
	ldr	q1, [x9, #288]
	str	q1, [x22, #1888]
	ldr	q1, [x9, #304]
	mov.d	x9, v0[1]
	str	q1, [x22, #1904]
	fmov	x10, d0
	add	x10, x8, x10, lsl #2
	ldr	q0, [x10]
	str	q0, [x22, #1920]
	ldr	q0, [x10, #16]
	str	q0, [x22, #1936]
	ldr	q0, [x10, #32]
	str	q0, [x22, #1952]
	ldr	q0, [x10, #48]
	str	q0, [x22, #1968]
	ldr	q0, [x10, #64]
	str	q0, [x22, #1984]
	ldr	q0, [x10, #80]
	str	q0, [x22, #2000]
	ldr	q0, [x10, #96]
	str	q0, [x22, #2016]
	ldr	q0, [x10, #112]
	str	q0, [x22, #2032]
	ldr	q0, [x10, #128]
	str	q0, [x22, #2048]
	ldr	q0, [x10, #144]
	str	q0, [x22, #2064]
	ldr	q0, [x10, #160]
	str	q0, [x22, #2080]
	ldr	q0, [x10, #176]
	str	q0, [x22, #2096]
	ldr	q0, [x10, #192]
	str	q0, [x22, #2112]
	ldr	q0, [x10, #208]
	str	q0, [x22, #2128]
	ldr	q0, [x10, #224]
	str	q0, [x22, #2144]
	ldr	q0, [x10, #240]
	str	q0, [x22, #2160]
	ldr	q0, [x10, #256]
	str	q0, [x22, #2176]
	ldr	q0, [x10, #272]
	str	q0, [x22, #2192]
	ldr	q0, [x10, #288]
	str	q0, [x22, #2208]
	ldr	q0, [x10, #304]
	str	q0, [x22, #2224]
	add	x8, x8, x9, lsl #2
	ldr	q0, [x8]
	str	q0, [x22, #2240]
	ldr	q0, [x8, #16]
	str	q0, [x22, #2256]
	ldr	q0, [x8, #32]
	str	q0, [x22, #2272]
	ldr	q0, [x8, #48]
	str	q0, [x22, #2288]
	ldr	q0, [x8, #64]
	str	q0, [x22, #2304]
	ldr	q0, [x8, #80]
	str	q0, [x22, #2320]
	ldr	q0, [x8, #96]
	str	q0, [x22, #2336]
	ldr	q0, [x8, #112]
	str	q0, [x22, #2352]
	ldr	q0, [x8, #128]
	str	q0, [x22, #2368]
	ldr	q0, [x8, #144]
	str	q0, [x22, #2384]
	ldr	q0, [x8, #160]
	str	q0, [x22, #2400]
	ldr	q0, [x8, #176]
	str	q0, [x22, #2416]
	ldr	q0, [x8, #192]
	str	q0, [x22, #2432]
	ldr	q0, [x8, #208]
	str	q0, [x22, #2448]
	ldr	q0, [x8, #224]
	str	q0, [x22, #2464]
	ldr	q0, [x8, #240]
	str	q0, [x22, #2480]
	ldr	q0, [x8, #256]
	str	q0, [x22, #2496]
	ldr	q0, [x8, #272]
	str	q0, [x22, #2512]
	ldr	q0, [x8, #288]
	str	q0, [x22, #2528]
	ldr	q0, [x8, #304]
	str	q0, [x22, #2544]
	add	x0, x22, #2560
	mov	w1, #3072                       ; =0xc00
	bl	_bzero
	mov	x17, x19
	mov	x4, #0                          ; =0x0
	mov	w8, #8704                       ; =0x2200
	add	x26, x22, x8
	mov	w8, #49664                      ; =0xc200
	add	x27, x22, x8
	add	x8, x22, #24, lsl #12           ; =98304
	add	x19, x8, #1536
	ldp	q0, q1, [sp, #16]               ; 32-byte Folded Reload
	shrn.2s	v0, v0, #2
	shrn.2s	v1, v1, #2
	ldp	q2, q3, [sp, #48]               ; 32-byte Folded Reload
	shrn.2s	v2, v2, #2
	mov	w8, #2053                       ; =0x805
	shrn.2s	v3, v3, #2
	mov	w9, #13824                      ; =0x3600
	add	x16, x22, x9
	mov	w9, #18944                      ; =0x4a00
	add	x0, x22, x9
	dup.2s	v4, w8
	mov	w8, #24064                      ; =0x5e00
	add	x8, x22, x8
	str	x8, [sp, #160]                  ; 8-byte Spill
	umull.2d	v8, v3, v4
	mov	w8, #29184                      ; =0x7200
	add	x8, x22, x8
	str	x8, [sp, #152]                  ; 8-byte Spill
	umull.2d	v20, v2, v4
	mov	w8, #34304                      ; =0x8600
	add	x8, x22, x8
	str	x8, [sp, #144]                  ; 8-byte Spill
	umull.2d	v21, v1, v4
	mov	w8, #39424                      ; =0x9a00
	add	x8, x22, x8
	str	x8, [sp, #136]                  ; 8-byte Spill
	umull.2d	v22, v0, v4
	mov	w8, #44544                      ; =0xae00
	add	x8, x22, x8
	str	x8, [sp, #128]                  ; 8-byte Spill
	mov	w8, #55808                      ; =0xda00
	add	x8, x22, x8
	str	x8, [sp, #120]                  ; 8-byte Spill
	mov	w8, #61952                      ; =0xf200
	add	x8, x22, x8
	str	x8, [sp, #112]                  ; 8-byte Spill
	add	x8, x22, #16, lsl #12           ; =65536
	add	x9, x8, #2560
	add	x8, x22, #18, lsl #12           ; =73728
	add	x8, x8, #512
	stp	x8, x9, [sp, #96]               ; 16-byte Folded Spill
	add	x8, x22, #19, lsl #12           ; =77824
	add	x8, x8, #2560
	str	x8, [sp, #88]                   ; 8-byte Spill
	add	x8, x22, #21, lsl #12           ; =86016
	add	x23, x8, #512
	add	x8, x22, #22, lsl #12           ; =90112
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v1, w9
	add	x25, x8, #2560
	dup.2d	v23, x17
Lloh4:
	adrp	x8, lCPI0_10@PAGE
Lloh5:
	ldr	q11, [x8, lCPI0_10@PAGEOFF]
Lloh6:
	adrp	x8, lCPI0_11@PAGE
Lloh7:
	ldr	q12, [x8, lCPI0_11@PAGEOFF]
Lloh8:
	adrp	x8, lCPI0_12@PAGE
Lloh9:
	ldr	q13, [x8, lCPI0_12@PAGEOFF]
Lloh10:
	adrp	x8, lCPI0_13@PAGE
Lloh11:
	ldr	q14, [x8, lCPI0_13@PAGEOFF]
Lloh12:
	adrp	x8, lCPI0_2@PAGE
Lloh13:
	ldr	q15, [x8, lCPI0_2@PAGEOFF]
Lloh14:
	adrp	x8, lCPI0_3@PAGE
Lloh15:
	ldr	q24, [x8, lCPI0_3@PAGEOFF]
Lloh16:
	adrp	x8, lCPI0_4@PAGE
Lloh17:
	ldr	q25, [x8, lCPI0_4@PAGEOFF]
	add	x8, x22, #24, lsl #12           ; =98304
Lloh18:
	adrp	x9, lCPI0_5@PAGE
Lloh19:
	ldr	q26, [x9, lCPI0_5@PAGEOFF]
	add	x9, x8, #512
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #544
	stp	x8, x9, [sp, #416]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #576
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #608
	stp	x8, x9, [sp, #400]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #640
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #672
	stp	x8, x9, [sp, #384]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #704
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #736
	stp	x8, x9, [sp, #368]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #768
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #800
	stp	x8, x9, [sp, #352]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #832
	str	x8, [sp, #344]                  ; 8-byte Spill
Lloh20:
	adrp	x8, lCPI0_6@PAGE
Lloh21:
	ldr	q27, [x8, lCPI0_6@PAGEOFF]
Lloh22:
	adrp	x8, lCPI0_7@PAGE
Lloh23:
	ldr	q28, [x8, lCPI0_7@PAGEOFF]
Lloh24:
	adrp	x8, lCPI0_8@PAGE
Lloh25:
	ldr	q29, [x8, lCPI0_8@PAGEOFF]
Lloh26:
	adrp	x8, lCPI0_9@PAGE
Lloh27:
	ldr	q30, [x8, lCPI0_9@PAGEOFF]
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #864
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #896
	stp	x8, x9, [sp, #328]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #928
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #960
	stp	x8, x9, [sp, #312]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #992
	str	x8, [sp, #304]                  ; 8-byte Spill
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #288]                  ; 16-byte Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #1056
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #1088
	stp	x8, x9, [sp, #272]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #1120
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #1152
	stp	x8, x9, [sp, #256]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #1184
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #1216
	stp	x8, x9, [sp, #240]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #1248
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #1280
	stp	x8, x9, [sp, #224]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #1312
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #1344
	stp	x8, x9, [sp, #208]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #1376
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #1408
	stp	x8, x9, [sp, #192]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x9, x8, #1440
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #1472
	stp	x8, x9, [sp, #176]              ; 16-byte Folded Spill
	add	x8, x22, #24, lsl #12           ; =98304
	add	x8, x8, #1504
	str	x8, [sp, #168]                  ; 8-byte Spill
	movi.2d	v31, #0000000000000000
	movi.2d	v19, #0000000000000000
	mov.16b	v0, v1
	mov	w8, #33792                      ; =0x8400
	movk	w8, #1, lsl #16
	add	x24, x22, x8
	mov	w1, #52429                      ; =0xcccd
	mov	w2, #80                         ; =0x50
	mov	w3, #43691                      ; =0xaaab
	mov	w5, #96                         ; =0x60
	mov	w28, #2560                      ; =0xa00
	mov	w21, #3                         ; =0x3
	str	x16, [sp, #584]                 ; 8-byte Spill
	str	x0, [sp, #576]                  ; 8-byte Spill
	str	x17, [sp, #600]                 ; 8-byte Spill
	stp	q20, q8, [sp, #544]             ; 32-byte Folded Spill
	stp	q22, q21, [sp, #512]            ; 32-byte Folded Spill
	stp	q15, q23, [sp, #480]            ; 32-byte Folded Spill
	str	q11, [sp, #2320]                ; 16-byte Spill
	str	q12, [sp, #2304]                ; 16-byte Spill
	str	q13, [sp, #2288]                ; 16-byte Spill
	str	q14, [sp, #2272]                ; 16-byte Spill
	stp	q25, q24, [sp, #448]            ; 32-byte Folded Spill
	str	q26, [sp, #432]                 ; 16-byte Spill
	str	q27, [sp, #1744]                ; 16-byte Spill
	str	q28, [sp, #1728]                ; 16-byte Spill
	str	q29, [sp, #1712]                ; 16-byte Spill
	str	q30, [sp, #1696]                ; 16-byte Spill
LBB0_1:                                 ; %direct.true152
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
                                        ;     Child Loop BB0_21 Depth 2
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
                                        ;     Child Loop BB0_37 Depth 2
                                        ;     Child Loop BB0_4 Depth 2
                                        ;     Child Loop BB0_53 Depth 2
                                        ;     Child Loop BB0_39 Depth 2
                                        ;     Child Loop BB0_41 Depth 2
                                        ;     Child Loop BB0_43 Depth 2
                                        ;     Child Loop BB0_45 Depth 2
                                        ;     Child Loop BB0_47 Depth 2
                                        ;       Child Loop BB0_48 Depth 3
	str	q0, [sp, #2208]                 ; 16-byte Spill
	dup.2d	v9, x26
	dup.2d	v0, x27
	cmp	x4, #128
	b.ne	LBB0_6
; %bb.2:                                ; %direct.true702.preheader
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	ldr	x0, [sp, #592]                  ; 8-byte Reload
	b	LBB0_4
LBB0_3:                                 ; %direct.schedule.49
                                        ;   in Loop: Header=BB0_4 Depth=2
	dup.2d	v4, x8
	add.2d	v4, v4, v9
	add.2d	v5, v4, v24
	add.2d	v6, v4, v15
	mov.d	x10, v6[1]
	fmov	x11, d6
	str	s3, [x11]
	st1.s	{ v3 }[1], [x10]
	mov.d	x10, v5[1]
	add.2d	v6, v4, v25
	fmov	x11, d5
	st1.s	{ v3 }[2], [x11]
	st1.s	{ v3 }[3], [x10]
	mov.d	x10, v6[1]
	fmov	x11, d6
	str	s2, [x11]
	st1.s	{ v2 }[1], [x10]
	add.2d	v3, v4, v26
	mov.d	x10, v3[1]
	fmov	x11, d3
	st1.s	{ v2 }[2], [x11]
	st1.s	{ v2 }[3], [x10]
	add	x9, x9, #1
	add	x8, x8, #4
	cmp	x9, #1280
	b.eq	LBB0_51
LBB0_4:                                 ; %direct.true702
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w10, w9, #0xffff
	mul	w10, w10, w1
	mov	w11, #2048                      ; =0x800
	bfxil	w11, w10, #22, #10
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	cmp	w11, #2052
	b.hi	LBB0_3
; %bb.5:                                ; %direct.true715
                                        ;   in Loop: Header=BB0_4 Depth=2
	lsr	w10, w10, #22
	dup.2d	v2, x11
	add.2d	v3, v2, v8
	add.2d	v4, v2, v21
	add.2d	v5, v2, v20
	add.2d	v2, v2, v22
	mov.d	x11, v2[1]
	fmov	x12, d2
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d2, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v2[1], x11
	mov.d	x11, v5[1]
	fmov	x12, d5
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d5, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v5[1], x11
	mov.d	x11, v4[1]
	fmov	x12, d4
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d4, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v4[1], x11
	mov.d	x11, v3[1]
	fmov	x12, d3
	add	x12, x12, x12, lsl #2
	lsl	x12, x12, #4
	fmov	d3, x12
	add	x11, x11, x11, lsl #2
	lsl	x11, x11, #4
	mov.d	v3[1], x11
	msub	w10, w10, w2, w9
	and	x10, x10, #0xffff
	dup.2d	v6, x10
	add.2d	v3, v3, v6
	add.2d	v4, v4, v6
	add.2d	v5, v5, v6
	add.2d	v2, v2, v6
	shl.2d	v2, v2, #2
	shl.2d	v5, v5, #2
	shl.2d	v4, v4, #2
	shl.2d	v3, v3, #2
	add.2d	v3, v23, v3
	add.2d	v4, v23, v4
	add.2d	v5, v23, v5
	add.2d	v2, v23, v2
	mov.d	x10, v2[1]
	fmov	x11, d2
	mov.d	x12, v5[1]
	fmov	x13, d5
	mov.d	x14, v4[1]
	fmov	x15, d4
	mov.d	x16, v3[1]
	ldr	s2, [x15]
	ld1.s	{ v2 }[1], [x14]
	fmov	x14, d3
	ld1.s	{ v2 }[2], [x14]
	ld1.s	{ v2 }[3], [x16]
	ldr	s3, [x11]
	ld1.s	{ v3 }[1], [x10]
	ld1.s	{ v3 }[2], [x13]
	ld1.s	{ v3 }[3], [x12]
	b	LBB0_3
LBB0_6:                                 ; %direct.true155
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x12, #0                         ; =0x0
	lsl	x8, x4, #4
	dup.2d	v5, x8
	add.2d	v4, v5, v22
	add.2d	v3, v5, v20
	add.2d	v2, v5, v21
	fmov	x8, d2
	add	x8, x8, x8, lsl #2
	lsl	x8, x8, #4
	fmov	d7, x8
	mov.d	x8, v2[1]
	add	x9, x8, x8, lsl #2
	lsl	x9, x9, #4
	mov.d	v7[1], x9
	fmov	x9, d3
	add	x9, x9, x9, lsl #2
	lsl	x9, x9, #4
	fmov	d16, x9
	mov.d	x9, v3[1]
	add	x10, x9, x9, lsl #2
	lsl	x10, x10, #4
	mov.d	v16[1], x10
	fmov	x10, d4
	add	x13, x10, x10, lsl #2
	lsl	x10, x13, #4
	fmov	d17, x10
	mov.d	x11, v4[1]
	add	x10, x11, x11, lsl #2
	lsl	x10, x10, #4
	mov.d	v17[1], x10
	add.2d	v5, v5, v8
	fmov	x10, d5
	add	x10, x10, x10, lsl #2
	lsl	x14, x10, #4
	mov.d	x10, v5[1]
	fmov	d6, x14
	add	x14, x10, x10, lsl #2
	lsl	x14, x14, #4
	mov.d	v6[1], x14
	add	x13, x17, x13, lsl #6
	ldr	x15, [sp, #592]                 ; 8-byte Reload
LBB0_7:                                 ; %copy.chunk.i
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x14, x12, #4
	ldr	q18, [x13, x14]
	str	q18, [x26, x14]
	add	x12, x12, #1
	cmp	x12, #320
	b.ne	LBB0_7
; %bb.8:                                ; %llm_attention.contiguous_copy.1.exit
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x12, #0                         ; =0x0
	mov.d	x13, v17[1]
	add	x13, x17, x13, lsl #2
LBB0_9:                                 ; %copy.chunk.i339
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x14, x12, #4
	ldr	q17, [x13, x14]
	str	q17, [x16, x14]
	add	x12, x12, #1
	cmp	x12, #320
	b.ne	LBB0_9
; %bb.10:                               ; %llm_attention.contiguous_copy.1.exit342
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x12, #0                         ; =0x0
	fmov	x13, d16
	add	x13, x17, x13, lsl #2
LBB0_11:                                ; %copy.chunk.i343
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x14, x12, #4
	ldr	q17, [x13, x14]
	str	q17, [x0, x14]
	add	x12, x12, #1
	cmp	x12, #320
	b.ne	LBB0_11
; %bb.12:                               ; %llm_attention.contiguous_copy.1.exit346
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x12, #0                         ; =0x0
	mov.d	x13, v16[1]
	add	x13, x17, x13, lsl #2
	ldr	x16, [sp, #160]                 ; 8-byte Reload
LBB0_13:                                ; %copy.chunk.i347
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x14, x12, #4
	ldr	q16, [x13, x14]
	str	q16, [x16, x14]
	add	x12, x12, #1
	cmp	x12, #320
	b.ne	LBB0_13
; %bb.14:                               ; %llm_attention.contiguous_copy.1.exit350
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x12, #0                         ; =0x0
	fmov	x13, d7
	add	x13, x17, x13, lsl #2
	ldp	x0, x16, [sp, #144]             ; 16-byte Folded Reload
LBB0_15:                                ; %copy.chunk.i351
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x14, x12, #4
	ldr	q16, [x13, x14]
	str	q16, [x16, x14]
	add	x12, x12, #1
	cmp	x12, #320
	b.ne	LBB0_15
; %bb.16:                               ; %llm_attention.contiguous_copy.1.exit354
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x12, #0                         ; =0x0
	mov.d	x13, v7[1]
	add	x13, x17, x13, lsl #2
LBB0_17:                                ; %copy.chunk.i355
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x14, x12, #4
	ldr	q7, [x13, x14]
	str	q7, [x0, x14]
	add	x12, x12, #1
	cmp	x12, #320
	b.ne	LBB0_17
; %bb.18:                               ; %llm_attention.contiguous_copy.1.exit358
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x12, #0                         ; =0x0
	fmov	x13, d6
	add	x13, x17, x13, lsl #2
	ldr	x16, [sp, #136]                 ; 8-byte Reload
LBB0_19:                                ; %copy.chunk.i359
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x14, x12, #4
	ldr	q7, [x13, x14]
	str	q7, [x16, x14]
	add	x12, x12, #1
	cmp	x12, #320
	b.ne	LBB0_19
; %bb.20:                               ; %llm_attention.contiguous_copy.1.exit362
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x12, #0                         ; =0x0
	mov.d	x13, v6[1]
	add	x13, x17, x13, lsl #2
	ldr	x16, [sp, #128]                 ; 8-byte Reload
LBB0_21:                                ; %copy.chunk.i363
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x14, x12, #4
	ldr	q6, [x13, x14]
	str	q6, [x16, x14]
	add	x12, x12, #1
	cmp	x12, #320
	b.ne	LBB0_21
; %bb.22:                               ; %direct.true181
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x12, #0                         ; =0x0
	fmov	x13, d4
	add	x13, x13, x13, lsl #1
	lsl	x14, x13, #5
	fmov	d6, x14
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v6[1], x11
	fmov	x11, d3
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	fmov	d4, x11
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v4[1], x9
	fmov	x9, d2
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d3, x9
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #5
	mov.d	v3[1], x8
	fmov	x8, d5
	add	x8, x8, x8, lsl #1
	lsl	x8, x8, #5
	fmov	d2, x8
	add	x8, x10, x10, lsl #1
	lsl	x8, x8, #5
	mov.d	v2[1], x8
	add	x8, x15, x13, lsl #7
LBB0_23:                                ; %copy.chunk.i367
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x9, x12, #4
	ldr	q5, [x8, x9]
	str	q5, [x27, x9]
	add	x12, x12, #1
	cmp	x12, #384
	b.ne	LBB0_23
; %bb.24:                               ; %llm_attention.contiguous_copy.2.exit
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x8, #0                          ; =0x0
	mov.d	x9, v6[1]
	add	x9, x15, x9, lsl #2
	ldr	x11, [sp, #120]                 ; 8-byte Reload
LBB0_25:                                ; %copy.chunk.i370
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #4
	ldr	q5, [x9, x10]
	str	q5, [x11, x10]
	add	x8, x8, #1
	cmp	x8, #384
	b.ne	LBB0_25
; %bb.26:                               ; %llm_attention.contiguous_copy.2.exit373
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x8, #0                          ; =0x0
	fmov	x9, d4
	add	x9, x15, x9, lsl #2
	ldr	x11, [sp, #112]                 ; 8-byte Reload
LBB0_27:                                ; %copy.chunk.i374
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #4
	ldr	q5, [x9, x10]
	str	q5, [x11, x10]
	add	x8, x8, #1
	cmp	x8, #384
	b.ne	LBB0_27
; %bb.28:                               ; %llm_attention.contiguous_copy.2.exit377
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x8, #0                          ; =0x0
	mov.d	x9, v4[1]
	add	x9, x15, x9, lsl #2
	ldr	x11, [sp, #104]                 ; 8-byte Reload
LBB0_29:                                ; %copy.chunk.i378
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #4
	ldr	q4, [x9, x10]
	str	q4, [x11, x10]
	add	x8, x8, #1
	cmp	x8, #384
	b.ne	LBB0_29
; %bb.30:                               ; %llm_attention.contiguous_copy.2.exit381
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x8, #0                          ; =0x0
	fmov	x9, d3
	add	x9, x15, x9, lsl #2
	ldr	x11, [sp, #96]                  ; 8-byte Reload
LBB0_31:                                ; %copy.chunk.i382
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #4
	ldr	q4, [x9, x10]
	str	q4, [x11, x10]
	add	x8, x8, #1
	cmp	x8, #384
	b.ne	LBB0_31
; %bb.32:                               ; %llm_attention.contiguous_copy.2.exit385
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x8, #0                          ; =0x0
	mov.d	x9, v3[1]
	add	x9, x15, x9, lsl #2
	ldr	x11, [sp, #88]                  ; 8-byte Reload
LBB0_33:                                ; %copy.chunk.i386
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #4
	ldr	q3, [x9, x10]
	str	q3, [x11, x10]
	add	x8, x8, #1
	cmp	x8, #384
	b.ne	LBB0_33
; %bb.34:                               ; %llm_attention.contiguous_copy.2.exit389
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x8, #0                          ; =0x0
	fmov	x9, d2
	add	x9, x15, x9, lsl #2
LBB0_35:                                ; %copy.chunk.i390
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #4
	ldr	q3, [x9, x10]
	str	q3, [x23, x10]
	add	x8, x8, #1
	cmp	x8, #384
	b.ne	LBB0_35
; %bb.36:                               ; %llm_attention.contiguous_copy.2.exit393
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x8, #0                          ; =0x0
	mov.d	x9, v2[1]
	add	x9, x15, x9, lsl #2
LBB0_37:                                ; %copy.chunk.i394
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	lsl	x10, x8, #4
	ldr	q2, [x9, x10]
	str	q2, [x25, x10]
	add	x8, x8, #1
	cmp	x8, #384
	b.ne	LBB0_37
LBB0_38:                                ; %direct.true208.preheader
                                        ;   in Loop: Header=BB0_1 Depth=1
	str	q19, [sp, #1648]                ; 16-byte Spill
	str	q31, [sp, #1664]                ; 16-byte Spill
	str	q1, [sp, #2224]                 ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	movi.2d	v31, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
LBB0_39:                                ; %direct.true208
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v2, x8
	dup.2d	v27, x22
	add.2d	v3, v2, v27
	add.2d	v4, v3, v14
	add.2d	v5, v3, v13
	add.2d	v6, v3, v12
	add.2d	v3, v3, v11
	mov.d	x14, v3[1]
	fmov	x12, d3
	mov.d	x9, v6[1]
	fmov	x13, d6
	mov.d	x16, v5[1]
	fmov	x10, d5
	mov.d	x11, v4[1]
	add.2d	v2, v9, v2
	add.2d	v6, v2, v26
	add.2d	v5, v2, v25
	fmov	x17, d4
	add.2d	v3, v2, v24
	add.2d	v2, v2, v15
	mov.d	x0, v2[1]
	fmov	x1, d2
	ldr	s2, [x10]
	mov.d	x10, v3[1]
	fmov	x15, d3
	mov.d	x2, v5[1]
	ldr	s3, [x12]
	fmov	x3, d5
	mov.d	x12, v6[1]
	ldr	s4, [x3]
	add	x3, x8, #320
	ldr	s5, [x1]
	dup.2d	v7, x3
	fmov	x1, d6
	add.2d	v6, v9, v7
	ld1.s	{ v2 }[1], [x16]
	add.2d	v16, v6, v26
	add.2d	v7, v6, v25
	add.2d	v17, v6, v24
	add.2d	v18, v6, v15
	ld1.s	{ v3 }[1], [x14]
	mov.d	x3, v18[1]
	mov.d	x16, v7[1]
	ld1.s	{ v4 }[1], [x2]
	fmov	x14, d7
	ldr	s6, [x14]
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[1], [x0]
	ld1.s	{ v6 }[1], [x16]
	mov.d	x16, v16[1]
	ld1.s	{ v2 }[2], [x17]
	fmov	x17, d18
	ldr	s7, [x17]
	ld1.s	{ v7 }[1], [x3]
	ld1.s	{ v3 }[2], [x13]
	fmov	x0, d17
	add	x13, x8, #640
	dup.2d	v17, x13
	ld1.s	{ v4 }[2], [x1]
	fmov	x13, d16
	add.2d	v16, v17, v9
	add.2d	v17, v16, v25
	add.2d	v18, v16, v15
	ld1.s	{ v5 }[2], [x15]
	mov.d	x15, v18[1]
	fmov	x17, d18
	add.2d	v18, v16, v24
	ld1.s	{ v6 }[2], [x13]
	mov.d	x13, v18[1]
	mov.d	x1, v17[1]
	ld1.s	{ v7 }[2], [x0]
	add.2d	v16, v16, v26
	fmov	x0, d17
	ldr	s17, [x0]
	fmov	x0, d18
	ld1.s	{ v2 }[3], [x11]
	mov.d	x11, v16[1]
	ld1.s	{ v17 }[1], [x1]
	ld1.s	{ v3 }[3], [x9]
	fmov	x9, d16
	ld1.s	{ v17 }[2], [x9]
	add	x9, x8, #960
	ld1.s	{ v4 }[3], [x12]
	dup.2d	v16, x9
	add.2d	v16, v16, v9
	add.2d	v18, v16, v15
	ld1.s	{ v5 }[3], [x10]
	mov.d	x9, v18[1]
	fmov	x10, d18
	add.2d	v18, v16, v25
	ld1.s	{ v6 }[3], [x16]
	mov.d	x12, v18[1]
	fmov	x16, d18
	add.2d	v18, v16, v26
	ld1.s	{ v7 }[3], [x14]
	mov.d	x14, v18[1]
	fmov	x1, d18
	ldr	s18, [x17]
	ld1.s	{ v17 }[3], [x11]
	ld1.s	{ v18 }[1], [x15]
	fmul.4s	v5, v3, v5
	fmul.4s	v4, v2, v4
	fmul.4s	v7, v3, v7
	fadd.4s	v31, v31, v4
	fmul.4s	v4, v2, v6
	ld1.s	{ v18 }[2], [x0]
	ld1.s	{ v18 }[3], [x13]
	fadd.4s	v22, v22, v5
	fmul.4s	v5, v3, v18
	fmul.4s	v6, v2, v17
	add.2d	v16, v16, v24
	mov.d	x11, v16[1]
	fadd.4s	v21, v21, v4
	ldr	s4, [x16]
	ld1.s	{ v4 }[1], [x12]
	ld1.s	{ v4 }[2], [x1]
	fadd.4s	v20, v20, v7
	ld1.s	{ v4 }[3], [x14]
	ldr	s7, [x10]
	ld1.s	{ v7 }[1], [x9]
	fadd.4s	v8, v8, v6
	fmov	x9, d16
	ld1.s	{ v7 }[2], [x9]
	ld1.s	{ v7 }[3], [x11]
	fadd.4s	v19, v19, v5
	fmul.4s	v3, v3, v7
	fmul.4s	v2, v2, v4
	fadd.4s	v1, v1, v2
	fadd.4s	v10, v10, v3
	add	x8, x8, #4
	cmp	x8, #320
	b.ne	LBB0_39
; %bb.40:                               ; %direct.true235.preheader
                                        ;   in Loop: Header=BB0_1 Depth=1
	str	q22, [sp, #2112]                ; 16-byte Spill
	str	q21, [sp, #2128]                ; 16-byte Spill
	str	q20, [sp, #2144]                ; 16-byte Spill
	str	q8, [sp, #2160]                 ; 16-byte Spill
	str	q19, [sp, #2176]                ; 16-byte Spill
	str	q31, [sp, #2192]                ; 16-byte Spill
	str	q1, [sp, #2240]                 ; 16-byte Spill
	str	q10, [sp, #2256]                ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	movi.2d	v20, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	mov.16b	v19, v27
LBB0_41:                                ; %direct.true235
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v2, x8
	add.2d	v2, v2, v19
	add.2d	v3, v2, v14
	add.2d	v4, v2, v13
	add.2d	v5, v2, v12
	add.2d	v2, v2, v11
	mov.d	x14, v2[1]
	fmov	x10, d2
	mov.d	x9, v5[1]
	fmov	x13, d5
	mov.d	x17, v4[1]
	fmov	x12, d4
	mov.d	x11, v3[1]
	fmov	x15, d3
	ldr	s2, [x12]
	add	x12, x8, #1280
	dup.2d	v3, x12
	add.2d	v4, v3, v9
	ldr	s3, [x10]
	add.2d	v6, v4, v26
	add.2d	v5, v4, v25
	add.2d	v7, v4, v24
	add.2d	v4, v4, v15
	mov.d	x0, v4[1]
	fmov	x1, d4
	mov.d	x10, v7[1]
	fmov	x16, d7
	mov.d	x2, v5[1]
	fmov	x3, d5
	mov.d	x12, v6[1]
	ldr	s4, [x3]
	add	x3, x8, #1600
	ldr	s5, [x1]
	dup.2d	v7, x3
	fmov	x1, d6
	add.2d	v6, v7, v9
	ld1.s	{ v2 }[1], [x17]
	add.2d	v16, v6, v26
	add.2d	v7, v6, v25
	add.2d	v17, v6, v24
	add.2d	v18, v6, v15
	ld1.s	{ v3 }[1], [x14]
	mov.d	x3, v18[1]
	mov.d	x17, v7[1]
	ld1.s	{ v4 }[1], [x2]
	fmov	x14, d7
	ldr	s6, [x14]
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[1], [x0]
	ld1.s	{ v6 }[1], [x17]
	mov.d	x17, v16[1]
	ld1.s	{ v2 }[2], [x15]
	fmov	x15, d18
	ldr	s7, [x15]
	ld1.s	{ v7 }[1], [x3]
	ld1.s	{ v3 }[2], [x13]
	fmov	x0, d17
	add	x13, x8, #1920
	dup.2d	v17, x13
	ld1.s	{ v4 }[2], [x1]
	fmov	x13, d16
	add.2d	v16, v17, v9
	add.2d	v17, v16, v25
	add.2d	v18, v16, v15
	ld1.s	{ v5 }[2], [x16]
	mov.d	x15, v18[1]
	fmov	x16, d18
	add.2d	v18, v16, v24
	ld1.s	{ v6 }[2], [x13]
	mov.d	x13, v18[1]
	mov.d	x1, v17[1]
	ld1.s	{ v7 }[2], [x0]
	add.2d	v16, v16, v26
	fmov	x0, d17
	ldr	s17, [x0]
	fmov	x0, d18
	ld1.s	{ v2 }[3], [x11]
	mov.d	x11, v16[1]
	ld1.s	{ v17 }[1], [x1]
	ld1.s	{ v3 }[3], [x9]
	fmov	x9, d16
	ld1.s	{ v17 }[2], [x9]
	add	x9, x8, #2240
	ld1.s	{ v4 }[3], [x12]
	dup.2d	v16, x9
	add.2d	v16, v16, v9
	add.2d	v18, v16, v15
	ld1.s	{ v5 }[3], [x10]
	mov.d	x9, v18[1]
	fmov	x10, d18
	add.2d	v18, v16, v25
	ld1.s	{ v6 }[3], [x17]
	mov.d	x12, v18[1]
	fmov	x17, d18
	add.2d	v18, v16, v26
	ld1.s	{ v7 }[3], [x14]
	mov.d	x14, v18[1]
	fmov	x1, d18
	ldr	s18, [x16]
	ld1.s	{ v17 }[3], [x11]
	ld1.s	{ v18 }[1], [x15]
	fmul.4s	v5, v3, v5
	fmul.4s	v4, v2, v4
	fmul.4s	v7, v3, v7
	fadd.4s	v20, v20, v4
	fmul.4s	v4, v2, v6
	ld1.s	{ v18 }[2], [x0]
	ld1.s	{ v18 }[3], [x13]
	fadd.4s	v31, v31, v5
	fmul.4s	v5, v3, v18
	fmul.4s	v6, v2, v17
	add.2d	v16, v16, v24
	mov.d	x11, v16[1]
	fadd.4s	v30, v30, v4
	ldr	s4, [x17]
	ld1.s	{ v4 }[1], [x12]
	ld1.s	{ v4 }[2], [x1]
	fadd.4s	v29, v29, v7
	ld1.s	{ v4 }[3], [x14]
	ldr	s7, [x10]
	ld1.s	{ v7 }[1], [x9]
	fadd.4s	v28, v28, v6
	fmov	x9, d16
	ld1.s	{ v7 }[2], [x9]
	ld1.s	{ v7 }[3], [x11]
	fadd.4s	v22, v22, v5
	fmul.4s	v3, v3, v7
	fmul.4s	v2, v2, v4
	fadd.4s	v21, v21, v2
	fadd.4s	v1, v1, v3
	add	x8, x8, #4
	cmp	x8, #320
	b.ne	LBB0_41
; %bb.42:                               ; %direct.true263.preheader
                                        ;   in Loop: Header=BB0_1 Depth=1
	str	q31, [sp, #1968]                ; 16-byte Spill
	str	q30, [sp, #1984]                ; 16-byte Spill
	str	q29, [sp, #2000]                ; 16-byte Spill
	str	q28, [sp, #2016]                ; 16-byte Spill
	str	q22, [sp, #2048]                ; 16-byte Spill
	str	q21, [sp, #2064]                ; 16-byte Spill
	str	q20, [sp, #2080]                ; 16-byte Spill
	str	q1, [sp, #2096]                 ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	movi.2d	v29, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v10, #0000000000000000
LBB0_43:                                ; %direct.true263
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v2, x8
	add.2d	v2, v2, v19
	add.2d	v3, v2, v14
	add.2d	v4, v2, v13
	add.2d	v5, v2, v12
	add.2d	v2, v2, v11
	mov.d	x14, v2[1]
	fmov	x10, d2
	mov.d	x9, v5[1]
	fmov	x13, d5
	mov.d	x17, v4[1]
	fmov	x12, d4
	mov.d	x11, v3[1]
	fmov	x15, d3
	ldr	s2, [x12]
	orr	x12, x8, x28
	dup.2d	v3, x12
	add.2d	v4, v3, v9
	ldr	s3, [x10]
	add.2d	v6, v4, v26
	add.2d	v5, v4, v25
	add.2d	v7, v4, v24
	add.2d	v4, v4, v15
	mov.d	x0, v4[1]
	fmov	x1, d4
	mov.d	x10, v7[1]
	fmov	x16, d7
	mov.d	x2, v5[1]
	fmov	x3, d5
	mov.d	x12, v6[1]
	ldr	s4, [x3]
	add	x3, x8, #2880
	ldr	s5, [x1]
	dup.2d	v7, x3
	fmov	x1, d6
	add.2d	v6, v7, v9
	ld1.s	{ v2 }[1], [x17]
	add.2d	v16, v6, v26
	add.2d	v7, v6, v25
	add.2d	v17, v6, v24
	add.2d	v18, v6, v15
	ld1.s	{ v3 }[1], [x14]
	mov.d	x3, v18[1]
	mov.d	x17, v7[1]
	ld1.s	{ v4 }[1], [x2]
	fmov	x14, d7
	ldr	s6, [x14]
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[1], [x0]
	ld1.s	{ v6 }[1], [x17]
	mov.d	x17, v16[1]
	ld1.s	{ v2 }[2], [x15]
	fmov	x15, d18
	ldr	s7, [x15]
	ld1.s	{ v7 }[1], [x3]
	ld1.s	{ v3 }[2], [x13]
	fmov	x0, d17
	add	x13, x8, #3200
	dup.2d	v17, x13
	ld1.s	{ v4 }[2], [x1]
	fmov	x13, d16
	add.2d	v16, v17, v9
	add.2d	v17, v16, v25
	add.2d	v18, v16, v15
	ld1.s	{ v5 }[2], [x16]
	mov.d	x15, v18[1]
	fmov	x16, d18
	add.2d	v18, v16, v24
	ld1.s	{ v6 }[2], [x13]
	mov.d	x13, v18[1]
	mov.d	x1, v17[1]
	ld1.s	{ v7 }[2], [x0]
	add.2d	v16, v16, v26
	fmov	x0, d17
	ldr	s17, [x0]
	fmov	x0, d18
	ld1.s	{ v2 }[3], [x11]
	mov.d	x11, v16[1]
	ld1.s	{ v17 }[1], [x1]
	ld1.s	{ v3 }[3], [x9]
	fmov	x9, d16
	ld1.s	{ v17 }[2], [x9]
	add	x9, x8, #3520
	ld1.s	{ v4 }[3], [x12]
	dup.2d	v16, x9
	add.2d	v16, v16, v9
	add.2d	v18, v16, v15
	ld1.s	{ v5 }[3], [x10]
	mov.d	x9, v18[1]
	fmov	x10, d18
	add.2d	v18, v16, v25
	ld1.s	{ v6 }[3], [x17]
	mov.d	x12, v18[1]
	fmov	x17, d18
	add.2d	v18, v16, v26
	ld1.s	{ v7 }[3], [x14]
	mov.d	x14, v18[1]
	fmov	x1, d18
	ldr	s18, [x16]
	ld1.s	{ v17 }[3], [x11]
	ld1.s	{ v18 }[1], [x15]
	fmul.4s	v5, v3, v5
	fmul.4s	v4, v2, v4
	fmul.4s	v7, v3, v7
	fadd.4s	v29, v29, v4
	fmul.4s	v4, v2, v6
	ld1.s	{ v18 }[2], [x0]
	ld1.s	{ v18 }[3], [x13]
	fadd.4s	v10, v10, v5
	fmul.4s	v5, v3, v18
	fmul.4s	v6, v2, v17
	add.2d	v16, v16, v24
	mov.d	x11, v16[1]
	fadd.4s	v27, v27, v4
	ldr	s4, [x17]
	ld1.s	{ v4 }[1], [x12]
	ld1.s	{ v4 }[2], [x1]
	fadd.4s	v8, v8, v7
	ld1.s	{ v4 }[3], [x14]
	ldr	s7, [x10]
	ld1.s	{ v7 }[1], [x9]
	fadd.4s	v31, v31, v6
	fmov	x9, d16
	ld1.s	{ v7 }[2], [x9]
	ld1.s	{ v7 }[3], [x11]
	fadd.4s	v30, v30, v5
	fmul.4s	v3, v3, v7
	fmul.4s	v2, v2, v4
	fadd.4s	v20, v20, v2
	fadd.4s	v1, v1, v3
	add	x8, x8, #4
	cmp	x8, #320
	b.ne	LBB0_43
; %bb.44:                               ; %direct.true291.preheader
                                        ;   in Loop: Header=BB0_1 Depth=1
	str	q20, [sp, #1936]                ; 16-byte Spill
	str	q1, [sp, #1952]                 ; 16-byte Spill
	mov	x8, #0                          ; =0x0
	movi.2d	v12, #0000000000000000
	movi.2d	v11, #0000000000000000
	mov	w9, #4800                       ; =0x12c0
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	mov.16b	v1, v26
	mov.16b	v26, v25
	mov.16b	v25, v24
	mov.16b	v24, v15
	movi.2d	v15, #0000000000000000
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
LBB0_45:                                ; %direct.true291
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v5, x8
	add.2d	v5, v5, v19
	ldr	q6, [sp, #2272]                 ; 16-byte Reload
	add.2d	v6, v5, v6
	ldr	q7, [sp, #2288]                 ; 16-byte Reload
	add.2d	v7, v5, v7
	ldr	q16, [sp, #2304]                ; 16-byte Reload
	add.2d	v16, v5, v16
	ldr	q17, [sp, #2320]                ; 16-byte Reload
	add.2d	v5, v5, v17
	mov.d	x16, v5[1]
	fmov	x12, d5
	mov.d	x10, v16[1]
	fmov	x13, d16
	mov.d	x15, v7[1]
	fmov	x17, d7
	mov.d	x11, v6[1]
	fmov	x14, d6
	ldr	s5, [x17]
	sub	x17, x9, #960
	dup.2d	v6, x17
	add.2d	v7, v6, v9
	ldr	s6, [x12]
	add.2d	v17, v7, v1
	add.2d	v16, v7, v26
	add.2d	v18, v7, v25
	add.2d	v7, v7, v24
	mov.d	x0, v7[1]
	fmov	x1, d7
	mov.d	x12, v18[1]
	mov.d	x2, v16[1]
	fmov	x17, d16
	ldr	s7, [x17]
	fmov	x17, d18
	ldr	s16, [x1]
	sub	x1, x9, #640
	ld1.s	{ v5 }[1], [x15]
	dup.2d	v18, x1
	mov.d	x15, v17[1]
	ld1.s	{ v6 }[1], [x16]
	fmov	x1, d17
	add.2d	v17, v18, v9
	mov.16b	v28, v19
	add.2d	v19, v17, v1
	add.2d	v18, v17, v26
	ld1.s	{ v7 }[1], [x2]
	add.2d	v20, v17, v25
	add.2d	v21, v17, v24
	mov.d	x16, v18[1]
	ld1.s	{ v16 }[1], [x0]
	fmov	x0, d18
	ldr	s17, [x0]
	mov.d	x0, v21[1]
	ld1.s	{ v17 }[1], [x16]
	fmov	x16, d21
	ldr	s18, [x16]
	mov.d	x16, v20[1]
	ld1.s	{ v5 }[2], [x14]
	fmov	x14, d20
	ld1.s	{ v18 }[1], [x0]
	sub	x0, x9, #320
	ld1.s	{ v6 }[2], [x13]
	dup.2d	v20, x0
	mov.d	x13, v19[1]
	ld1.s	{ v7 }[2], [x1]
	fmov	x0, d19
	add.2d	v19, v20, v9
	add.2d	v20, v19, v1
	add.2d	v21, v19, v26
	ld1.s	{ v16 }[2], [x17]
	add.2d	v22, v19, v25
	add.2d	v23, v19, v24
	mov.d	x17, v21[1]
	ld1.s	{ v17 }[2], [x0]
	fmov	x0, d21
	ldr	s19, [x0]
	mov.d	x0, v23[1]
	ld1.s	{ v18 }[2], [x14]
	ld1.s	{ v19 }[1], [x17]
	mov.d	x14, v20[1]
	ld1.s	{ v5 }[3], [x11]
	fmov	x11, d20
	ld1.s	{ v19 }[2], [x11]
	fmov	x11, d23
	ld1.s	{ v6 }[3], [x10]
	mov.d	x10, v22[1]
	ldr	s20, [x11]
	fmov	x11, d22
	ld1.s	{ v7 }[3], [x15]
	ld1.s	{ v20 }[1], [x0]
	dup.2d	v21, x9
	ld1.s	{ v16 }[3], [x12]
	add.2d	v21, v21, v9
	add.2d	v22, v21, v24
	mov.d	x12, v22[1]
	ld1.s	{ v17 }[3], [x13]
	fmov	x13, d22
	add.2d	v22, v21, v25
	mov.d	x15, v22[1]
	ld1.s	{ v18 }[3], [x16]
	fmov	x16, d22
	add.2d	v22, v21, v26
	mov.d	x17, v22[1]
	ld1.s	{ v19 }[3], [x14]
	fmov	x14, d22
	fmul.4s	v16, v6, v16
	fmul.4s	v7, v5, v7
	fmul.4s	v18, v6, v18
	fmul.4s	v17, v5, v17
	fadd.4s	v12, v12, v7
	ld1.s	{ v20 }[2], [x11]
	ld1.s	{ v20 }[3], [x10]
	fmul.4s	v7, v6, v20
	fadd.4s	v4, v4, v16
	add.2d	v16, v21, v1
	mov.d	x10, v16[1]
	fmov	x11, d16
	ldr	s16, [x14]
	fadd.4s	v3, v3, v17
	ld1.s	{ v16 }[1], [x17]
	ldr	s17, [x13]
	ld1.s	{ v17 }[1], [x12]
	fadd.4s	v2, v2, v18
	fmul.4s	v18, v5, v19
	mov.16b	v19, v28
	ld1.s	{ v17 }[2], [x16]
	ld1.s	{ v17 }[3], [x15]
	fadd.4s	v15, v15, v18
	fmul.4s	v6, v6, v17
	ld1.s	{ v16 }[2], [x11]
	ld1.s	{ v16 }[3], [x10]
	fadd.4s	v14, v14, v7
	fmul.4s	v5, v5, v16
	fadd.4s	v13, v13, v5
	fadd.4s	v11, v11, v6
	add	x9, x9, #4
	add	x8, x8, #4
	cmp	x8, #320
	b.ne	LBB0_45
; %bb.46:                               ; %direct.false292
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x8, #0                          ; =0x0
	mov	w9, #63790                      ; =0xf92e
	movk	w9, #15844, lsl #16
	dup.4s	v1, w9
	ldr	q5, [sp, #2112]                 ; 16-byte Reload
	fmul.4s	v5, v5, v1
	str	q5, [sp, #2032]                 ; 16-byte Spill
	ldr	q5, [sp, #2192]                 ; 16-byte Reload
	fmul.4s	v5, v5, v1
	str	q5, [sp, #1872]                 ; 16-byte Spill
	ldr	q5, [sp, #2144]                 ; 16-byte Reload
	fmul.4s	v5, v5, v1
	str	q5, [sp, #1856]                 ; 16-byte Spill
	ldr	q5, [sp, #2128]                 ; 16-byte Reload
	fmul.4s	v5, v5, v1
	str	q5, [sp, #1840]                 ; 16-byte Spill
	ldr	q5, [sp, #2176]                 ; 16-byte Reload
	fmul.4s	v5, v5, v1
	str	q5, [sp, #1824]                 ; 16-byte Spill
	ldr	q5, [sp, #2160]                 ; 16-byte Reload
	fmul.4s	v5, v5, v1
	str	q5, [sp, #1808]                 ; 16-byte Spill
	ldr	q5, [sp, #2256]                 ; 16-byte Reload
	fmul.4s	v5, v5, v1
	str	q5, [sp, #1776]                 ; 16-byte Spill
	ldr	q5, [sp, #2240]                 ; 16-byte Reload
	fmul.4s	v5, v5, v1
	str	q5, [sp, #1760]                 ; 16-byte Spill
	ldr	q5, [sp, #1968]                 ; 16-byte Reload
	fmul.4s	v5, v5, v1
	str	q5, [sp, #2256]                 ; 16-byte Spill
	ldr	q5, [sp, #2080]                 ; 16-byte Reload
	fmul.4s	v5, v5, v1
	str	q5, [sp, #2240]                 ; 16-byte Spill
	ldr	q5, [sp, #1984]                 ; 16-byte Reload
	fmul.4s	v6, v5, v1
	ldr	q5, [sp, #2000]                 ; 16-byte Reload
	fmul.4s	v7, v5, v1
	ldr	q5, [sp, #2016]                 ; 16-byte Reload
	fmul.4s	v16, v5, v1
	ldr	q5, [sp, #2048]                 ; 16-byte Reload
	fmul.4s	v17, v5, v1
	ldr	q5, [sp, #2064]                 ; 16-byte Reload
	fmul.4s	v18, v5, v1
	ldr	q5, [sp, #2096]                 ; 16-byte Reload
	fmul.4s	v19, v5, v1
	fmul.4s	v20, v29, v1
	fmul.4s	v21, v10, v1
	fmul.4s	v22, v27, v1
	fmul.4s	v23, v8, v1
	fmul.4s	v24, v31, v1
	fmul.4s	v25, v30, v1
	ldr	q5, [sp, #1936]                 ; 16-byte Reload
	fmul.4s	v26, v5, v1
	ldr	q5, [sp, #1952]                 ; 16-byte Reload
	fmul.4s	v27, v5, v1
	fmul.4s	v28, v12, v1
	fmul.4s	v4, v4, v1
	fmul.4s	v3, v3, v1
	fmul.4s	v2, v2, v1
	fmul.4s	v29, v15, v1
	fmul.4s	v30, v14, v1
	fmul.4s	v31, v13, v1
	fmul.4s	v1, v11, v1
	str	x4, [sp, #1688]                 ; 8-byte Spill
	cmp	x4, #128
	cset	w9, lo
	dup.4h	v5, w9
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v9, v5, #0
	str	q9, [sp, #704]                  ; 16-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v8, w9
	mov.16b	v5, v9
	bsl.16b	v5, v7, v8
	str	q5, [sp, #2192]                 ; 16-byte Spill
	mov.16b	v12, v9
	bsl.16b	v12, v6, v8
	mov.16b	v6, v9
	bsl.16b	v6, v17, v8
	str	q6, [sp, #2112]                 ; 16-byte Spill
	mov.16b	v11, v9
	bsl.16b	v11, v16, v8
	str	q11, [sp, #1888]                ; 16-byte Spill
	mov.16b	v16, v9
	bsl.16b	v16, v19, v8
	str	q16, [sp, #2176]                ; 16-byte Spill
	mov.16b	v19, v9
	bsl.16b	v19, v18, v8
	str	q19, [sp, #1904]                ; 16-byte Spill
	mov.16b	v18, v9
	bsl.16b	v18, v21, v8
	str	q18, [sp, #2096]                ; 16-byte Spill
	mov.16b	v21, v9
	bsl.16b	v21, v20, v8
	str	q21, [sp, #1920]                ; 16-byte Spill
	mov.16b	v20, v9
	bsl.16b	v20, v23, v8
	str	q20, [sp, #2160]                ; 16-byte Spill
	mov.16b	v23, v9
	bsl.16b	v23, v22, v8
	str	q23, [sp, #1936]                ; 16-byte Spill
	mov.16b	v22, v9
	bsl.16b	v22, v25, v8
	str	q22, [sp, #2080]                ; 16-byte Spill
	mov.16b	v25, v9
	bsl.16b	v25, v24, v8
	str	q25, [sp, #1952]                ; 16-byte Spill
	mov.16b	v24, v9
	bsl.16b	v24, v27, v8
	str	q24, [sp, #2144]                ; 16-byte Spill
	bif.16b	v26, v8, v9
	str	q26, [sp, #1968]                ; 16-byte Spill
	bif.16b	v4, v8, v9
	str	q4, [sp, #2064]                 ; 16-byte Spill
	mov.16b	v10, v9
	bsl.16b	v10, v28, v8
	str	q10, [sp, #1984]                ; 16-byte Spill
	mov.16b	v28, v9
	bsl.16b	v28, v2, v8
	str	q28, [sp, #2128]                ; 16-byte Spill
	mov.16b	v17, v9
	bsl.16b	v17, v3, v8
	str	q17, [sp, #2000]                ; 16-byte Spill
	mov.16b	v3, v9
	bsl.16b	v3, v30, v8
	str	q3, [sp, #2048]                 ; 16-byte Spill
	mov.16b	v7, v9
	bsl.16b	v7, v29, v8
	str	q7, [sp, #2016]                 ; 16-byte Spill
	mov.16b	v13, v9
	bsl.16b	v13, v1, v8
	str	q13, [sp, #1472]                ; 16-byte Spill
	bif.16b	v31, v8, v9
	str	q31, [sp, #1792]                ; 16-byte Spill
	mvni.4s	v27, #127, msl #16
	ldr	q2, [sp, #2032]                 ; 16-byte Reload
	fmaxnm.4s	v1, v2, v27
	ldr	q29, [sp, #1856]                ; 16-byte Reload
	fmaxnm.4s	v1, v1, v29
	ldr	q30, [sp, #1824]                ; 16-byte Reload
	fmaxnm.4s	v1, v1, v30
	ldr	q9, [sp, #1776]                 ; 16-byte Reload
	fmaxnm.4s	v1, v1, v9
	ldr	q8, [sp, #2256]                 ; 16-byte Reload
	fmaxnm.4s	v1, v1, v8
	fmaxnm.4s	v1, v1, v5
	fmaxnm.4s	v1, v1, v6
	fmaxnm.4s	v1, v1, v16
	fmaxnm.4s	v1, v1, v18
	fmaxnm.4s	v1, v1, v20
	fmaxnm.4s	v1, v1, v22
	fmaxnm.4s	v1, v1, v24
	fmaxnm.4s	v1, v1, v4
	fmaxnm.4s	v1, v1, v28
	fmaxnm.4s	v1, v1, v3
	fmaxnm.4s	v1, v1, v13
	ldr	q3, [sp, #2224]                 ; 16-byte Reload
	fmaxnm.4s	v13, v3, v1
	fsub.4s	v1, v2, v13
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v2, w9
	fcmge.4s	v3, v1, v2
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v5, w9
	fcmge.4s	v4, v5, v1
	and.16b	v3, v3, v4
	ldr	q6, [sp, #1872]                 ; 16-byte Reload
	fmaxnm.4s	v4, v6, v27
	ldr	q14, [sp, #1840]                ; 16-byte Reload
	fmaxnm.4s	v4, v4, v14
	ldr	q15, [sp, #1808]                ; 16-byte Reload
	fmaxnm.4s	v4, v4, v15
	ldr	q8, [sp, #1760]                 ; 16-byte Reload
	fmaxnm.4s	v4, v4, v8
	ldr	q16, [sp, #2240]                ; 16-byte Reload
	fmaxnm.4s	v4, v4, v16
	fmaxnm.4s	v4, v4, v12
	str	q12, [sp, #1264]                ; 16-byte Spill
	fmaxnm.4s	v4, v4, v11
	fmaxnm.4s	v4, v4, v19
	fmaxnm.4s	v4, v4, v21
	fmaxnm.4s	v4, v4, v23
	fmaxnm.4s	v4, v4, v25
	fmaxnm.4s	v4, v4, v26
	fmaxnm.4s	v4, v4, v10
	fmaxnm.4s	v4, v4, v17
	fmaxnm.4s	v4, v4, v7
	fmaxnm.4s	v4, v4, v31
	ldr	q7, [sp, #2208]                 ; 16-byte Reload
	fmaxnm.4s	v31, v7, v4
	fsub.4s	v11, v6, v31
	fcmge.4s	v4, v11, v2
	fcmge.4s	v6, v5, v11
	and.16b	v4, v4, v6
	and.16b	v4, v4, v11
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v22, w9
	fmul.4s	v6, v4, v22
	movi.4s	v16, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v16, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	and.16b	v7, v3, v1
	fmul.4s	v3, v7, v22
	bif.16b	v16, v3, v17
	fadd.4s	v3, v3, v16
	fsub.4s	v16, v3, v16
	fcvtzs.4s	v3, v6
	scvtf.4s	v6, v3
	mov	w9, #29184                      ; =0x7200
	movk	w9, #16177, lsl #16
	dup.4s	v21, w9
	fmul.4s	v17, v6, v21
	fsub.4s	v17, v4, v17
	fcvtzs.4s	v4, v16
	scvtf.4s	v16, v4
	fmul.4s	v18, v16, v21
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #13759, lsl #16
	dup.4s	v20, w9
	fsub.4s	v7, v7, v18
	fmul.4s	v16, v16, v20
	fsub.4s	v23, v7, v16
	fmul.4s	v6, v6, v20
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v19, w9
	fsub.4s	v6, v17, v6
	fmul.4s	v7, v6, v19
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v18, w9
	fadd.4s	v7, v7, v18
	fmul.4s	v7, v6, v7
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v17, w9
	fadd.4s	v7, v7, v17
	fmul.4s	v7, v6, v7
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v16, w9
	fadd.4s	v7, v7, v16
	fmul.4s	v24, v6, v7
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v7, w9
	fadd.4s	v24, v24, v7
	fmul.4s	v24, v6, v24
	movi.4s	v10, #63, lsl #24
	fadd.4s	v24, v24, v10
	fmul.4s	v25, v6, v6
	fmul.4s	v24, v25, v24
	fmul.4s	v25, v23, v19
	fadd.4s	v25, v25, v18
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v17
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v16
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v7
	fmul.4s	v25, v23, v25
	fadd.4s	v25, v25, v10
	fmul.4s	v26, v23, v23
	fmul.4s	v25, v26, v25
	fadd.4s	v23, v23, v25
	fadd.4s	v6, v6, v24
	fmov.4s	v28, #1.00000000
	fadd.4s	v23, v23, v28
	sshr.4s	v24, v4, #1
	shl.4s	v25, v24, #23
	add.4s	v25, v25, v28
	fmul.4s	v23, v23, v25
	fadd.4s	v6, v6, v28
	sshr.4s	v25, v3, #1
	shl.4s	v26, v25, #23
	add.4s	v26, v26, v28
	fmul.4s	v6, v6, v26
	sub.4s	v4, v4, v24
	sub.4s	v3, v3, v25
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v6, v3
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	str	q1, [sp, #1552]                 ; 16-byte Spill
	fcmgt.4s	v6, v2, v1
	bic.16b	v4, v4, v6
	str	q11, [sp, #1600]                ; 16-byte Spill
	fcmgt.4s	v6, v2, v11
	bic.16b	v3, v3, v6
	fcmgt.4s	v23, v11, v5
	fneg.4s	v6, v27
	bit.16b	v3, v6, v23
	str	q3, [sp, #1584]                 ; 16-byte Spill
	fcmgt.4s	v3, v1, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #1568]                 ; 16-byte Spill
	fsub.4s	v29, v29, v13
	fcmge.4s	v3, v29, v2
	fcmge.4s	v4, v5, v29
	and.16b	v3, v3, v4
	fsub.4s	v11, v14, v31
	fcmge.4s	v4, v11, v2
	fcmge.4s	v23, v5, v11
	and.16b	v4, v4, v23
	and.16b	v4, v4, v11
	fmul.4s	v23, v4, v22
	movi.4s	v1, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v24, v25
	bsl.16b	v24, v1, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v29
	fmul.4s	v3, v24, v22
	bsl.16b	v25, v1, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	str	q29, [sp, #1488]                ; 16-byte Spill
	fcmgt.4s	v23, v2, v29
	bic.16b	v4, v4, v23
	str	q11, [sp, #1520]                ; 16-byte Spill
	fcmgt.4s	v23, v2, v11
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v11, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1536]                 ; 16-byte Spill
	fcmgt.4s	v3, v29, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #1504]                 ; 16-byte Spill
	fsub.4s	v29, v30, v13
	fcmge.4s	v3, v29, v2
	fcmge.4s	v4, v5, v29
	and.16b	v3, v3, v4
	fsub.4s	v1, v15, v31
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mvni.4s	v25, #128, lsl #24
	movi.4s	v26, #75, lsl #24
	mov.16b	v24, v25
	bsl.16b	v24, v26, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v29
	fmul.4s	v3, v24, v22
	bsl.16b	v25, v26, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	str	q29, [sp, #1408]                ; 16-byte Spill
	fcmgt.4s	v23, v2, v29
	bic.16b	v4, v4, v23
	str	q1, [sp, #1440]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1456]                 ; 16-byte Spill
	fcmgt.4s	v3, v29, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #1424]                 ; 16-byte Spill
	fsub.4s	v29, v9, v13
	fcmge.4s	v3, v29, v2
	fcmge.4s	v4, v5, v29
	and.16b	v3, v3, v4
	fsub.4s	v1, v8, v31
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	movi.4s	v25, #75, lsl #24
	mvni.4s	v26, #128, lsl #24
	mov.16b	v24, v26
	bsl.16b	v24, v25, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v29
	fmul.4s	v3, v24, v22
	bif.16b	v25, v3, v26
	mvni.4s	v30, #128, lsl #24
	movi.4s	v8, #75, lsl #24
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	str	q29, [sp, #1344]                ; 16-byte Spill
	fcmgt.4s	v23, v2, v29
	bic.16b	v4, v4, v23
	str	q1, [sp, #1376]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1392]                 ; 16-byte Spill
	fcmgt.4s	v3, v29, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #1360]                 ; 16-byte Spill
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	fsub.4s	v29, v1, v13
	fcmge.4s	v3, v29, v2
	fcmge.4s	v4, v5, v29
	and.16b	v3, v3, v4
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	fsub.4s	v1, v1, v31
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v8, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v29
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v8, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	str	q29, [sp, #1280]                ; 16-byte Spill
	fcmgt.4s	v23, v2, v29
	bic.16b	v4, v4, v23
	str	q1, [sp, #1312]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1328]                 ; 16-byte Spill
	fcmgt.4s	v3, v29, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #1296]                 ; 16-byte Spill
	fsub.4s	v29, v12, v31
	fcmge.4s	v3, v29, v2
	fcmge.4s	v4, v5, v29
	and.16b	v3, v3, v4
	ldr	q1, [sp, #2192]                 ; 16-byte Reload
	fsub.4s	v30, v1, v13
	fcmge.4s	v4, v30, v2
	fcmge.4s	v23, v5, v30
	and.16b	v4, v4, v23
	and.16b	v4, v4, v30
	fmul.4s	v23, v4, v22
	mvni.4s	v1, #128, lsl #24
	movi.4s	v25, #75, lsl #24
	mov.16b	v24, v1
	bsl.16b	v24, v25, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v29
	fmul.4s	v3, v24, v22
	bif.16b	v25, v3, v1
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	str	q29, [sp, #1200]                ; 16-byte Spill
	fcmgt.4s	v23, v2, v29
	bic.16b	v4, v4, v23
	str	q30, [sp, #1232]                ; 16-byte Spill
	fcmgt.4s	v23, v2, v30
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v30, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1248]                 ; 16-byte Spill
	fcmgt.4s	v3, v29, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #1216]                 ; 16-byte Spill
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	fsub.4s	v29, v1, v31
	fcmge.4s	v3, v29, v2
	fcmge.4s	v4, v5, v29
	and.16b	v3, v3, v4
	ldr	q1, [sp, #2112]                 ; 16-byte Reload
	fsub.4s	v1, v1, v13
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	movi.4s	v25, #75, lsl #24
	mvni.4s	v26, #128, lsl #24
	mov.16b	v24, v26
	bsl.16b	v24, v25, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v29
	fmul.4s	v3, v24, v22
	bif.16b	v25, v3, v26
	mvni.4s	v30, #128, lsl #24
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	str	q29, [sp, #1136]                ; 16-byte Spill
	fcmgt.4s	v23, v2, v29
	bic.16b	v4, v4, v23
	str	q1, [sp, #1168]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1184]                 ; 16-byte Spill
	fcmgt.4s	v3, v29, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #1152]                 ; 16-byte Spill
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	fsub.4s	v29, v1, v31
	fcmge.4s	v3, v29, v2
	fcmge.4s	v4, v5, v29
	and.16b	v3, v3, v4
	ldr	q1, [sp, #2176]                 ; 16-byte Reload
	fsub.4s	v1, v1, v13
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v8, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v29
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v8, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	str	q29, [sp, #1072]                ; 16-byte Spill
	fcmgt.4s	v23, v2, v29
	bic.16b	v4, v4, v23
	str	q1, [sp, #1104]                 ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1120]                 ; 16-byte Spill
	fcmgt.4s	v3, v29, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #1088]                 ; 16-byte Spill
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	fsub.4s	v29, v1, v31
	fcmge.4s	v3, v29, v2
	fcmge.4s	v4, v5, v29
	and.16b	v3, v3, v4
	ldr	q1, [sp, #2096]                 ; 16-byte Reload
	mov.16b	v8, v13
	fsub.4s	v30, v1, v13
	fcmge.4s	v4, v30, v2
	fcmge.4s	v23, v5, v30
	and.16b	v4, v4, v23
	and.16b	v4, v4, v30
	fmul.4s	v23, v4, v22
	mvni.4s	v1, #128, lsl #24
	movi.4s	v25, #75, lsl #24
	mov.16b	v24, v1
	bsl.16b	v24, v25, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v29
	fmul.4s	v3, v24, v22
	bif.16b	v25, v3, v1
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v29
	bic.16b	v4, v4, v23
	str	q30, [sp, #1040]                ; 16-byte Spill
	fcmgt.4s	v23, v2, v30
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v30, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #1056]                 ; 16-byte Spill
	fcmgt.4s	v3, v29, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q29, q1, [sp, #1008]            ; 32-byte Folded Spill
	ldr	q1, [sp, #1936]                 ; 16-byte Reload
	fsub.4s	v29, v1, v31
	fcmge.4s	v3, v29, v2
	fcmge.4s	v4, v5, v29
	and.16b	v3, v3, v4
	ldr	q1, [sp, #2160]                 ; 16-byte Reload
	fsub.4s	v1, v1, v13
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	movi.4s	v25, #75, lsl #24
	mvni.4s	v26, #128, lsl #24
	mov.16b	v24, v26
	bsl.16b	v24, v25, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v29
	fmul.4s	v3, v24, v22
	bif.16b	v25, v3, v26
	mvni.4s	v30, #128, lsl #24
	movi.4s	v11, #75, lsl #24
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v29
	bic.16b	v4, v4, v23
	str	q1, [sp, #976]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #992]                  ; 16-byte Spill
	fcmgt.4s	v3, v29, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q29, q1, [sp, #944]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1952]                 ; 16-byte Reload
	fsub.4s	v29, v1, v31
	fcmge.4s	v3, v29, v2
	fcmge.4s	v4, v5, v29
	and.16b	v3, v3, v4
	ldr	q1, [sp, #2080]                 ; 16-byte Reload
	fsub.4s	v1, v1, v13
	fcmge.4s	v4, v1, v2
	fcmge.4s	v23, v5, v1
	and.16b	v4, v4, v23
	and.16b	v4, v4, v1
	fmul.4s	v23, v4, v22
	mov.16b	v24, v30
	bsl.16b	v24, v11, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v29
	fmul.4s	v3, v24, v22
	mov.16b	v25, v30
	bsl.16b	v25, v11, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v29
	bic.16b	v4, v4, v23
	str	q1, [sp, #912]                  ; 16-byte Spill
	fcmgt.4s	v23, v2, v1
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v1, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #928]                  ; 16-byte Spill
	fcmgt.4s	v3, v29, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q29, q1, [sp, #880]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	fsub.4s	v29, v1, v31
	fcmge.4s	v3, v29, v2
	fcmge.4s	v4, v5, v29
	and.16b	v3, v3, v4
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	fsub.4s	v30, v1, v13
	fcmge.4s	v4, v30, v2
	fcmge.4s	v23, v5, v30
	and.16b	v4, v4, v23
	and.16b	v4, v4, v30
	fmul.4s	v23, v4, v22
	mvni.4s	v1, #128, lsl #24
	movi.4s	v25, #75, lsl #24
	mov.16b	v24, v1
	bsl.16b	v24, v25, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v29
	fmul.4s	v3, v24, v22
	bif.16b	v25, v3, v1
	mvni.4s	v12, #128, lsl #24
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v29
	bic.16b	v4, v4, v23
	fcmgt.4s	v23, v2, v30
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v30, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	stp	q30, q1, [sp, #848]             ; 32-byte Folded Spill
	fcmgt.4s	v3, v29, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q29, q1, [sp, #816]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	fsub.4s	v30, v1, v31
	fcmge.4s	v3, v30, v2
	fcmge.4s	v4, v5, v30
	and.16b	v3, v3, v4
	ldr	q1, [sp, #2064]                 ; 16-byte Reload
	fsub.4s	v29, v1, v13
	fcmge.4s	v4, v29, v2
	fcmge.4s	v23, v5, v29
	and.16b	v4, v4, v23
	and.16b	v4, v4, v29
	fmul.4s	v23, v4, v22
	mov.16b	v24, v12
	bsl.16b	v24, v11, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v30
	fmul.4s	v3, v24, v22
	mov.16b	v25, v12
	bsl.16b	v25, v11, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v27, v26, v21
	fsub.4s	v24, v24, v27
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v27, v24, v24
	fmul.4s	v26, v27, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v27, v26, #23
	add.4s	v27, v27, v28
	fmul.4s	v4, v4, v27
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v30
	bic.16b	v4, v4, v23
	fcmgt.4s	v23, v2, v29
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v29, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #800]                  ; 16-byte Spill
	fcmgt.4s	v3, v30, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q30, q1, [sp, #768]             ; 32-byte Folded Spill
	ldr	q1, [sp, #2000]                 ; 16-byte Reload
	fsub.4s	v30, v1, v31
	fcmge.4s	v3, v30, v2
	fcmge.4s	v4, v5, v30
	and.16b	v3, v3, v4
	ldr	q1, [sp, #2128]                 ; 16-byte Reload
	fsub.4s	v27, v1, v13
	fcmge.4s	v4, v27, v2
	fcmge.4s	v23, v5, v27
	and.16b	v4, v4, v23
	and.16b	v4, v4, v27
	fmul.4s	v23, v4, v22
	movi.4s	v1, #75, lsl #24
	mvni.4s	v25, #128, lsl #24
	mov.16b	v24, v25
	bsl.16b	v24, v1, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v30
	fmul.4s	v3, v24, v22
	bsl.16b	v25, v1, v3
	fadd.4s	v3, v3, v25
	fsub.4s	v25, v3, v25
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v26, v23, v21
	fsub.4s	v4, v4, v26
	fcvtzs.4s	v25, v25
	scvtf.4s	v26, v25
	fmul.4s	v11, v26, v21
	fsub.4s	v24, v24, v11
	fmul.4s	v26, v26, v20
	fsub.4s	v24, v24, v26
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v26, v4, v4
	fmul.4s	v23, v26, v23
	fmul.4s	v26, v24, v19
	fadd.4s	v26, v26, v18
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v17
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v16
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v7
	fmul.4s	v26, v24, v26
	fadd.4s	v26, v26, v10
	fmul.4s	v11, v24, v24
	fmul.4s	v26, v11, v26
	fadd.4s	v24, v24, v26
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v25, #1
	shl.4s	v26, v24, #23
	add.4s	v26, v26, v28
	fmul.4s	v23, v23, v26
	fadd.4s	v4, v4, v28
	sshr.4s	v26, v3, #1
	shl.4s	v11, v26, #23
	add.4s	v11, v11, v28
	fmul.4s	v4, v4, v11
	sub.4s	v24, v25, v24
	sub.4s	v3, v3, v26
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v30
	bic.16b	v4, v4, v23
	fcmgt.4s	v23, v2, v27
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v27, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #752]                  ; 16-byte Spill
	fcmgt.4s	v3, v30, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	stp	q30, q1, [sp, #720]             ; 32-byte Folded Spill
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	fsub.4s	v26, v1, v31
	fcmge.4s	v3, v26, v2
	fcmge.4s	v4, v5, v26
	and.16b	v3, v3, v4
	ldr	q1, [sp, #2048]                 ; 16-byte Reload
	fsub.4s	v25, v1, v13
	fcmge.4s	v4, v25, v2
	fcmge.4s	v23, v5, v25
	and.16b	v4, v4, v23
	and.16b	v4, v4, v25
	fmul.4s	v23, v4, v22
	movi.4s	v1, #75, lsl #24
	mvni.4s	v30, #128, lsl #24
	mov.16b	v24, v30
	bsl.16b	v24, v1, v23
	fadd.4s	v23, v23, v24
	fsub.4s	v23, v23, v24
	and.16b	v24, v3, v26
	fmul.4s	v3, v24, v22
	mov.16b	v11, v30
	bsl.16b	v11, v1, v3
	fadd.4s	v3, v3, v11
	fsub.4s	v11, v3, v11
	fcvtzs.4s	v3, v23
	scvtf.4s	v23, v3
	fmul.4s	v12, v23, v21
	fsub.4s	v4, v4, v12
	fcvtzs.4s	v11, v11
	scvtf.4s	v12, v11
	fmul.4s	v15, v12, v21
	fsub.4s	v24, v24, v15
	fmul.4s	v12, v12, v20
	fsub.4s	v24, v24, v12
	fmul.4s	v23, v23, v20
	fsub.4s	v4, v4, v23
	fmul.4s	v23, v4, v19
	fadd.4s	v23, v23, v18
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v17
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v16
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v7
	fmul.4s	v23, v4, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v12, v4, v4
	fmul.4s	v23, v12, v23
	fmul.4s	v12, v24, v19
	fadd.4s	v12, v12, v18
	fmul.4s	v12, v24, v12
	fadd.4s	v12, v12, v17
	fmul.4s	v12, v24, v12
	fadd.4s	v12, v12, v16
	fmul.4s	v12, v24, v12
	fadd.4s	v12, v12, v7
	fmul.4s	v12, v24, v12
	fadd.4s	v12, v12, v10
	fmul.4s	v15, v24, v24
	fmul.4s	v12, v15, v12
	fadd.4s	v24, v24, v12
	fadd.4s	v4, v4, v23
	fadd.4s	v23, v24, v28
	sshr.4s	v24, v11, #1
	shl.4s	v12, v24, #23
	add.4s	v12, v12, v28
	fmul.4s	v23, v23, v12
	fadd.4s	v4, v4, v28
	sshr.4s	v12, v3, #1
	shl.4s	v15, v12, #23
	add.4s	v15, v15, v28
	fmul.4s	v4, v4, v15
	sub.4s	v24, v11, v24
	sub.4s	v3, v3, v12
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v24, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v23, v4
	fcmgt.4s	v23, v2, v26
	bic.16b	v4, v4, v23
	fcmgt.4s	v23, v2, v25
	bic.16b	v3, v3, v23
	fcmgt.4s	v23, v25, v5
	mov.16b	v1, v23
	bsl.16b	v1, v6, v3
	str	q1, [sp, #688]                  ; 16-byte Spill
	fcmgt.4s	v3, v26, v5
	mov.16b	v1, v3
	bsl.16b	v1, v6, v4
	str	q1, [sp, #672]                  ; 16-byte Spill
	ldr	q1, [sp, #1792]                 ; 16-byte Reload
	fsub.4s	v24, v1, v31
	fcmge.4s	v3, v24, v2
	fcmge.4s	v4, v5, v24
	and.16b	v3, v3, v4
	ldr	q30, [sp, #1472]                ; 16-byte Reload
	fsub.4s	v23, v30, v13
	fcmge.4s	v4, v23, v2
	fcmge.4s	v11, v5, v23
	and.16b	v4, v4, v11
	and.16b	v4, v4, v23
	fmul.4s	v11, v4, v22
	mvni.4s	v1, #128, lsl #24
	movi.4s	v9, #75, lsl #24
	mov.16b	v12, v1
	bsl.16b	v12, v9, v11
	fadd.4s	v11, v11, v12
	fsub.4s	v11, v11, v12
	and.16b	v12, v3, v24
	fmul.4s	v3, v12, v22
	mov.16b	v15, v1
	bsl.16b	v15, v9, v3
	fadd.4s	v3, v3, v15
	fsub.4s	v15, v3, v15
	fcvtzs.4s	v3, v11
	scvtf.4s	v11, v3
	fmul.4s	v14, v11, v21
	fsub.4s	v4, v4, v14
	fcvtzs.4s	v14, v15
	scvtf.4s	v15, v14
	fmul.4s	v13, v15, v21
	fsub.4s	v12, v12, v13
	fmul.4s	v13, v15, v20
	fsub.4s	v12, v12, v13
	fmul.4s	v11, v11, v20
	fsub.4s	v4, v4, v11
	fmul.4s	v11, v4, v19
	fadd.4s	v11, v11, v18
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v17
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v16
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v7
	fmul.4s	v11, v4, v11
	fadd.4s	v11, v11, v10
	fmul.4s	v13, v4, v4
	fmul.4s	v11, v13, v11
	fmul.4s	v13, v12, v19
	fadd.4s	v13, v13, v18
	fmul.4s	v13, v12, v13
	fadd.4s	v13, v13, v17
	fmul.4s	v13, v12, v13
	fadd.4s	v13, v13, v16
	fmul.4s	v13, v12, v13
	fadd.4s	v13, v13, v7
	fmul.4s	v13, v12, v13
	fadd.4s	v13, v13, v10
	fmul.4s	v15, v12, v12
	fmul.4s	v13, v15, v13
	fadd.4s	v12, v12, v13
	fadd.4s	v4, v4, v11
	fadd.4s	v11, v12, v28
	sshr.4s	v12, v14, #1
	shl.4s	v13, v12, #23
	add.4s	v13, v13, v28
	fmul.4s	v11, v11, v13
	fadd.4s	v4, v4, v28
	sshr.4s	v13, v3, #1
	shl.4s	v15, v13, #23
	add.4s	v15, v15, v28
	fmul.4s	v4, v4, v15
	sub.4s	v12, v14, v12
	sub.4s	v3, v3, v13
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v28
	fmul.4s	v3, v4, v3
	shl.4s	v4, v12, #23
	add.4s	v4, v4, v28
	fmul.4s	v4, v11, v4
	fcmgt.4s	v11, v2, v24
	bic.16b	v4, v4, v11
	fcmgt.4s	v11, v2, v23
	bic.16b	v3, v3, v11
	fcmgt.4s	v11, v23, v5
	mov.16b	v1, v11
	bsl.16b	v1, v6, v3
	str	q1, [sp, #656]                  ; 16-byte Spill
	fcmgt.4s	v3, v24, v5
	bit.16b	v4, v6, v3
	str	q31, [sp, #1616]                ; 16-byte Spill
	ldr	q1, [sp, #2208]                 ; 16-byte Reload
	fsub.4s	v31, v1, v31
	fcmge.4s	v3, v31, v2
	fcmge.4s	v13, v5, v31
	and.16b	v13, v3, v13
	str	q8, [sp, #1632]                 ; 16-byte Spill
	ldr	q3, [sp, #2224]                 ; 16-byte Reload
	fsub.4s	v9, v3, v8
	fcmge.4s	v14, v9, v2
	fcmge.4s	v15, v5, v9
	and.16b	v14, v14, v15
	and.16b	v14, v14, v9
	fmul.4s	v15, v14, v22
	movi.4s	v3, #75, lsl #24
	mvni.4s	v8, #128, lsl #24
	mov.16b	v1, v8
	bsl.16b	v1, v3, v15
	fadd.4s	v15, v15, v1
	fsub.4s	v1, v15, v1
	and.16b	v13, v13, v31
	fmul.4s	v22, v13, v22
	mov.16b	v15, v8
	bsl.16b	v15, v3, v22
	fadd.4s	v22, v22, v15
	fsub.4s	v22, v22, v15
	fcvtzs.4s	v1, v1
	scvtf.4s	v15, v1
	fmul.4s	v12, v15, v21
	fsub.4s	v12, v14, v12
	fcvtzs.4s	v22, v22
	scvtf.4s	v14, v22
	fmul.4s	v21, v14, v21
	fsub.4s	v21, v13, v21
	fmul.4s	v13, v15, v20
	fmul.4s	v20, v14, v20
	fsub.4s	v20, v21, v20
	fsub.4s	v21, v12, v13
	fmul.4s	v12, v21, v19
	fmul.4s	v19, v20, v19
	fadd.4s	v19, v19, v18
	fadd.4s	v18, v12, v18
	fmul.4s	v18, v21, v18
	fmul.4s	v19, v20, v19
	fadd.4s	v19, v19, v17
	fadd.4s	v17, v18, v17
	fmul.4s	v17, v21, v17
	fmul.4s	v18, v20, v19
	fadd.4s	v18, v18, v16
	fadd.4s	v16, v17, v16
	fmul.4s	v16, v21, v16
	fmul.4s	v17, v20, v18
	fadd.4s	v17, v17, v7
	fadd.4s	v7, v16, v7
	fmul.4s	v7, v21, v7
	fadd.4s	v7, v7, v10
	fmul.4s	v16, v21, v21
	fmul.4s	v7, v16, v7
	fmul.4s	v16, v20, v17
	fadd.4s	v16, v16, v10
	fmul.4s	v17, v20, v20
	fmul.4s	v16, v17, v16
	fadd.4s	v16, v20, v16
	fadd.4s	v7, v21, v7
	fadd.4s	v16, v16, v28
	sshr.4s	v17, v22, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v28
	fmul.4s	v16, v16, v18
	fadd.4s	v7, v7, v28
	sshr.4s	v18, v1, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v28
	fmul.4s	v7, v7, v19
	sub.4s	v17, v22, v17
	sub.4s	v1, v1, v18
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v28
	fmul.4s	v1, v7, v1
	shl.4s	v7, v17, #23
	add.4s	v7, v7, v28
	fmul.4s	v7, v16, v7
	fcmgt.4s	v16, v2, v31
	bic.16b	v7, v7, v16
	fcmgt.4s	v2, v2, v9
	bic.16b	v1, v1, v2
	fcmgt.4s	v2, v9, v5
	bit.16b	v1, v6, v2
	str	q1, [sp, #640]                  ; 16-byte Spill
	fcmgt.4s	v2, v31, v5
	mov.16b	v1, v2
	bsl.16b	v1, v6, v7
	stp	q31, q1, [sp, #608]             ; 32-byte Folded Spill
	ldp	x9, x10, [sp, #416]             ; 16-byte Folded Reload
	ldr	q1, [sp, #1872]                 ; 16-byte Reload
	ldr	q5, [sp, #2032]                 ; 16-byte Reload
	stp	q5, q1, [x10]
	ldr	q1, [sp, #1840]                 ; 16-byte Reload
	ldr	q5, [sp, #1856]                 ; 16-byte Reload
	stp	q5, q1, [x9]
	ldp	x9, x10, [sp, #400]             ; 16-byte Folded Reload
	ldr	q1, [sp, #1808]                 ; 16-byte Reload
	ldr	q5, [sp, #1824]                 ; 16-byte Reload
	stp	q5, q1, [x10]
	ldr	q1, [sp, #1760]                 ; 16-byte Reload
	ldr	q5, [sp, #1776]                 ; 16-byte Reload
	stp	q5, q1, [x9]
	ldp	x9, x10, [sp, #384]             ; 16-byte Folded Reload
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	ldr	q5, [sp, #2256]                 ; 16-byte Reload
	stp	q5, q1, [x10]
	ldr	q1, [sp, #1264]                 ; 16-byte Reload
	ldr	q5, [sp, #2192]                 ; 16-byte Reload
	stp	q5, q1, [x9]
	ldp	x9, x10, [sp, #368]             ; 16-byte Folded Reload
	ldr	q1, [sp, #1888]                 ; 16-byte Reload
	ldr	q5, [sp, #2112]                 ; 16-byte Reload
	stp	q5, q1, [x10]
	ldr	q1, [sp, #1904]                 ; 16-byte Reload
	ldr	q5, [sp, #2176]                 ; 16-byte Reload
	stp	q5, q1, [x9]
	ldp	x9, x10, [sp, #352]             ; 16-byte Folded Reload
	ldr	q1, [sp, #1920]                 ; 16-byte Reload
	ldr	q5, [sp, #2096]                 ; 16-byte Reload
	stp	q5, q1, [x10]
	ldr	q1, [sp, #1936]                 ; 16-byte Reload
	ldr	q5, [sp, #2160]                 ; 16-byte Reload
	stp	q5, q1, [x9]
	ldp	x9, x10, [sp, #336]             ; 16-byte Folded Reload
	ldr	q1, [sp, #1952]                 ; 16-byte Reload
	ldr	q5, [sp, #2080]                 ; 16-byte Reload
	stp	q5, q1, [x10]
	ldr	q1, [sp, #1968]                 ; 16-byte Reload
	ldr	q5, [sp, #2144]                 ; 16-byte Reload
	stp	q5, q1, [x9]
	ldp	x9, x10, [sp, #320]             ; 16-byte Folded Reload
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	ldr	q5, [sp, #2064]                 ; 16-byte Reload
	stp	q5, q1, [x10]
	ldr	q1, [sp, #2000]                 ; 16-byte Reload
	ldr	q5, [sp, #2128]                 ; 16-byte Reload
	stp	q5, q1, [x9]
	ldp	x9, x10, [sp, #304]             ; 16-byte Folded Reload
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	ldr	q5, [sp, #2048]                 ; 16-byte Reload
	stp	q5, q1, [x10]
	ldr	q5, [sp, #1792]                 ; 16-byte Reload
	stp	q30, q5, [x9]
	ldr	q5, [sp, #1552]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q13, [sp, #288]                 ; 16-byte Reload
	ldr	q6, [sp, #1568]                 ; 16-byte Reload
	mov.16b	v1, v5
	bsl.16b	v1, v6, v13
	str	q1, [sp, #2256]                 ; 16-byte Spill
	ldr	q5, [sp, #1600]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1584]                 ; 16-byte Reload
	mov.16b	v1, v5
	bsl.16b	v1, v6, v13
	str	q1, [sp, #2224]                 ; 16-byte Spill
	ldr	q5, [sp, #1488]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1504]                 ; 16-byte Reload
	mov.16b	v1, v5
	bsl.16b	v1, v6, v13
	str	q1, [sp, #2240]                 ; 16-byte Spill
	ldr	q5, [sp, #1520]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1536]                 ; 16-byte Reload
	mov.16b	v1, v5
	bsl.16b	v1, v6, v13
	str	q1, [sp, #2192]                 ; 16-byte Spill
	ldr	q5, [sp, #1408]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1424]                 ; 16-byte Reload
	mov.16b	v1, v5
	bsl.16b	v1, v6, v13
	str	q1, [sp, #2208]                 ; 16-byte Spill
	ldr	q5, [sp, #1440]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1456]                 ; 16-byte Reload
	mov.16b	v1, v5
	bsl.16b	v1, v6, v13
	str	q1, [sp, #2176]                 ; 16-byte Spill
	ldr	q5, [sp, #1344]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1360]                 ; 16-byte Reload
	mov.16b	v1, v5
	bsl.16b	v1, v6, v13
	str	q1, [sp, #2160]                 ; 16-byte Spill
	ldr	q5, [sp, #1376]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1392]                 ; 16-byte Reload
	mov.16b	v15, v5
	bsl.16b	v15, v6, v13
	ldr	q5, [sp, #1280]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1296]                 ; 16-byte Reload
	mov.16b	v1, v5
	bsl.16b	v1, v6, v13
	str	q1, [sp, #2144]                 ; 16-byte Spill
	ldr	q5, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1328]                 ; 16-byte Reload
	mov.16b	v11, v5
	bsl.16b	v11, v6, v13
	ldr	q5, [sp, #1200]                 ; 16-byte Reload
	fcmeq.4s	v5, v5, v5
	ldr	q6, [sp, #1216]                 ; 16-byte Reload
	mov.16b	v1, v5
	bsl.16b	v1, v6, v13
	ldr	q6, [sp, #1232]                 ; 16-byte Reload
	fcmeq.4s	v6, v6, v6
	ldr	q7, [sp, #1248]                 ; 16-byte Reload
	bsl.16b	v6, v7, v13
	ldr	q7, [sp, #1136]                 ; 16-byte Reload
	fcmeq.4s	v7, v7, v7
	ldr	q16, [sp, #1152]                ; 16-byte Reload
	bsl.16b	v7, v16, v13
	ldr	q16, [sp, #1168]                ; 16-byte Reload
	fcmeq.4s	v16, v16, v16
	ldr	q17, [sp, #1184]                ; 16-byte Reload
	bsl.16b	v16, v17, v13
	ldr	q17, [sp, #1072]                ; 16-byte Reload
	fcmeq.4s	v17, v17, v17
	ldr	q18, [sp, #1088]                ; 16-byte Reload
	mov.16b	v5, v17
	bsl.16b	v5, v18, v13
	ldr	q18, [sp, #1104]                ; 16-byte Reload
	fcmeq.4s	v18, v18, v18
	ldr	q19, [sp, #1120]                ; 16-byte Reload
	bsl.16b	v18, v19, v13
	ldp	q19, q20, [sp, #1008]           ; 32-byte Folded Reload
	fcmeq.4s	v19, v19, v19
	bsl.16b	v19, v20, v13
	ldr	q20, [sp, #1040]                ; 16-byte Reload
	fcmeq.4s	v20, v20, v20
	ldr	q21, [sp, #1056]                ; 16-byte Reload
	bsl.16b	v20, v21, v13
	ldp	q21, q22, [sp, #944]            ; 32-byte Folded Reload
	fcmeq.4s	v21, v21, v21
	bsl.16b	v21, v22, v13
	ldp	q22, q28, [sp, #976]            ; 32-byte Folded Reload
	fcmeq.4s	v22, v22, v22
	bsl.16b	v22, v28, v13
	ldp	q2, q28, [sp, #880]             ; 32-byte Folded Reload
	fcmeq.4s	v12, v2, v2
	bsl.16b	v12, v28, v13
	ldp	q3, q28, [sp, #912]             ; 32-byte Folded Reload
	fcmeq.4s	v10, v3, v3
	bsl.16b	v10, v28, v13
	ldp	q17, q28, [sp, #816]            ; 32-byte Folded Reload
	fcmeq.4s	v8, v17, v17
	bsl.16b	v8, v28, v13
	ldp	q30, q28, [sp, #848]            ; 32-byte Folded Reload
	fcmeq.4s	v31, v30, v30
	bsl.16b	v31, v28, v13
	ldr	q28, [sp, #768]                 ; 16-byte Reload
	fcmeq.4s	v30, v28, v28
	ldr	q28, [sp, #784]                 ; 16-byte Reload
	bsl.16b	v30, v28, v13
	fcmeq.4s	v29, v29, v29
	ldr	q28, [sp, #800]                 ; 16-byte Reload
	bsl.16b	v29, v28, v13
	ldp	q28, q14, [sp, #720]            ; 32-byte Folded Reload
	fcmeq.4s	v28, v28, v28
	bsl.16b	v28, v14, v13
	fcmeq.4s	v27, v27, v27
	ldr	q14, [sp, #752]                 ; 16-byte Reload
	mov.16b	v17, v27
	bsl.16b	v17, v14, v13
	fcmeq.4s	v26, v26, v26
	ldr	q2, [sp, #672]                  ; 16-byte Reload
	bsl.16b	v26, v2, v13
	fcmeq.4s	v25, v25, v25
	ldp	q2, q14, [sp, #688]             ; 32-byte Folded Reload
	bsl.16b	v25, v2, v13
	fcmeq.4s	v24, v24, v24
	bif.16b	v4, v13, v24
	fcmeq.4s	v23, v23, v23
	ldr	q2, [sp, #656]                  ; 16-byte Reload
	bif.16b	v2, v13, v23
	and.16b	v27, v14, v6
	and.16b	v3, v14, v1
	and.16b	v23, v14, v16
	and.16b	v1, v14, v7
	and.16b	v24, v14, v18
	and.16b	v5, v14, v5
	and.16b	v20, v14, v20
	and.16b	v19, v14, v19
	and.16b	v7, v14, v22
	and.16b	v6, v14, v21
	and.16b	v21, v14, v10
	and.16b	v22, v14, v12
	and.16b	v16, v14, v31
	and.16b	v31, v14, v8
	and.16b	v29, v14, v29
	and.16b	v30, v14, v30
	and.16b	v17, v14, v17
	and.16b	v28, v14, v28
	and.16b	v25, v14, v25
	and.16b	v26, v14, v26
	and.16b	v18, v14, v2
	and.16b	v8, v14, v4
	ldr	q2, [sp, #608]                  ; 16-byte Reload
	fcmeq.4s	v4, v2, v2
	ldr	q2, [sp, #624]                  ; 16-byte Reload
	mov.16b	v10, v4
	bsl.16b	v10, v2, v13
	fcmeq.4s	v2, v9, v9
	ldr	q4, [sp, #640]                  ; 16-byte Reload
	mov.16b	v9, v2
	bsl.16b	v9, v4, v13
	mov	w9, #33792                      ; =0x8400
	movk	w9, #1, lsl #16
	add	x9, x22, x9
	ldr	q4, [sp, #2224]                 ; 16-byte Reload
	ldr	q2, [sp, #2256]                 ; 16-byte Reload
	stp	q2, q4, [x9]
	ldp	x9, x10, [sp, #272]             ; 16-byte Folded Reload
	ldr	q4, [sp, #2192]                 ; 16-byte Reload
	ldr	q2, [sp, #2240]                 ; 16-byte Reload
	stp	q2, q4, [x10]
	ldr	q4, [sp, #2176]                 ; 16-byte Reload
	ldr	q2, [sp, #2208]                 ; 16-byte Reload
	stp	q2, q4, [x9]
	ldp	x9, x10, [sp, #256]             ; 16-byte Folded Reload
	str	q15, [sp, #2128]                ; 16-byte Spill
	ldr	q2, [sp, #2160]                 ; 16-byte Reload
	stp	q2, q15, [x10]
	str	q11, [sp, #2112]                ; 16-byte Spill
	ldr	q2, [sp, #2144]                 ; 16-byte Reload
	stp	q2, q11, [x9]
	ldp	x9, x10, [sp, #240]             ; 16-byte Folded Reload
	str	q3, [sp, #1840]                 ; 16-byte Spill
	stp	q27, q3, [x10]
	str	q27, [sp, #2096]                ; 16-byte Spill
	str	q1, [sp, #1984]                 ; 16-byte Spill
	stp	q23, q1, [x9]
	str	q23, [sp, #2000]                ; 16-byte Spill
	ldp	x9, x11, [sp, #224]             ; 16-byte Folded Reload
	str	q5, [sp, #1824]                 ; 16-byte Spill
	stp	q24, q5, [x11]
	str	q24, [sp, #2080]                ; 16-byte Spill
	str	q19, [sp, #1952]                ; 16-byte Spill
	stp	q20, q19, [x9]
	str	q20, [sp, #1968]                ; 16-byte Spill
	ldr	x9, [sp, #216]                  ; 8-byte Reload
	str	q6, [sp, #1808]                 ; 16-byte Spill
	stp	q7, q6, [x9]
	str	q7, [sp, #2064]                 ; 16-byte Spill
	ldr	x9, [sp, #208]                  ; 8-byte Reload
	str	q22, [sp, #1920]                ; 16-byte Spill
	stp	q21, q22, [x9]
	str	q21, [sp, #1936]                ; 16-byte Spill
	ldr	x9, [sp, #200]                  ; 8-byte Reload
	str	q31, [sp, #1792]                ; 16-byte Spill
	stp	q16, q31, [x9]
	str	q16, [sp, #2048]                ; 16-byte Spill
	ldr	x9, [sp, #192]                  ; 8-byte Reload
	str	q30, [sp, #1888]                ; 16-byte Spill
	stp	q29, q30, [x9]
	str	q29, [sp, #1904]                ; 16-byte Spill
	ldr	x9, [sp, #184]                  ; 8-byte Reload
	str	q28, [sp, #1776]                ; 16-byte Spill
	stp	q17, q28, [x9]
	str	q17, [sp, #2032]                ; 16-byte Spill
	ldr	x9, [sp, #176]                  ; 8-byte Reload
	str	q26, [sp, #1856]                ; 16-byte Spill
	stp	q25, q26, [x9]
	str	q25, [sp, #1872]                ; 16-byte Spill
	ldr	x9, [sp, #168]                  ; 8-byte Reload
	str	q8, [sp, #1760]                 ; 16-byte Spill
	stp	q18, q8, [x9]
	str	q18, [sp, #2016]                ; 16-byte Spill
	mov	w9, #12                         ; =0xc
	ldr	q26, [sp, #1744]                ; 16-byte Reload
	ldr	q27, [sp, #1728]                ; 16-byte Reload
	ldr	q28, [sp, #1712]                ; 16-byte Reload
	ldr	q29, [sp, #1696]                ; 16-byte Reload
LBB0_47:                                ; %direct.true557
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_48 Depth 3
	mov	x10, #0                         ; =0x0
	lsl	x11, x8, #7
	add	x12, x20, x11
	ldp	q1, q2, [x12]
	fmul.4s	v2, v10, v2
	fmul.4s	v1, v9, v1
	mov	w12, #1                         ; =0x1
	bfi	x12, x8, #2, #61
	add	x13, x20, x12, lsl #5
	ldp	q3, q4, [x13]
	fmul.4s	v4, v10, v4
	fmul.4s	v3, v9, v3
	mov	w13, #2                         ; =0x2
	bfi	x13, x8, #2, #61
	add	x14, x20, x13, lsl #5
	ldp	q5, q6, [x14]
	fmul.4s	v16, v10, v6
	fmul.4s	v7, v9, v5
	orr	x14, x21, x8, lsl #2
	add	x15, x20, x14, lsl #5
	ldp	q5, q6, [x15]
	fmul.4s	v6, v10, v6
	fmul.4s	v5, v9, v5
	mov	x15, x9
LBB0_48:                                ; %direct.true585
                                        ;   Parent Loop BB0_1 Depth=1
                                        ;     Parent Loop BB0_47 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x16, x24, x10
	ldr	q17, [x16, #16]
	sub	x17, x15, #12
	dup.2d	v18, x17
	add.2d	v18, v18, v0
	add.2d	v19, v18, v29
	add.2d	v20, v18, v28
	add.2d	v21, v18, v27
	add.2d	v18, v18, v26
	mov.d	x3, v18[1]
	fmov	x1, d18
	mov.d	x17, v21[1]
	fmov	x2, d21
	mov.d	x4, v20[1]
	fmov	x5, d20
	mov.d	x0, v19[1]
	sub	x6, x15, #8
	dup.2d	v20, x6
	fmov	x6, d19
	ldr	s18, [x5]
	add.2d	v20, v20, v0
	add.2d	v21, v20, v29
	add.2d	v22, v20, v28
	add.2d	v23, v20, v27
	ldr	s19, [x1]
	add.2d	v20, v20, v26
	mov.d	x5, v20[1]
	fmov	x7, d20
	ld1.s	{ v18 }[1], [x4]
	mov.d	x1, v23[1]
	mov.d	x4, v22[1]
	ld1.s	{ v19 }[1], [x3]
	fmov	x30, d22
	mov.d	x3, v21[1]
	ldr	s20, [x30]
	ld1.s	{ v20 }[1], [x4]
	fmov	x4, d23
	fmov	x30, d21
	ldr	s21, [x7]
	sub	x7, x15, #4
	ld1.s	{ v21 }[1], [x5]
	dup.2d	v22, x7
	add.2d	v22, v22, v0
	add.2d	v23, v22, v28
	ld1.s	{ v18 }[2], [x6]
	add.2d	v24, v22, v27
	add.2d	v25, v22, v26
	mov.d	x5, v25[1]
	ld1.s	{ v19 }[2], [x2]
	mov.d	x2, v24[1]
	mov.d	x6, v23[1]
	ld1.s	{ v20 }[2], [x30]
	add.2d	v22, v22, v29
	fmov	x7, d23
	mov.d	x30, v22[1]
	ld1.s	{ v21 }[2], [x4]
	ldr	s23, [x7]
	fmov	x4, d22
	ld1.s	{ v23 }[1], [x6]
	ld1.s	{ v23 }[2], [x4]
	fmov	x4, d25
	ldr	s22, [x4]
	ld1.s	{ v22 }[1], [x5]
	ld1.s	{ v18 }[3], [x0]
	fmov	x0, d24
	dup.2d	v24, x15
	add.2d	v24, v24, v0
	ld1.s	{ v19 }[3], [x17]
	add.2d	v25, v24, v26
	mov.d	x17, v25[1]
	fmov	x4, d25
	ld1.s	{ v20 }[3], [x3]
	add.2d	v25, v24, v27
	mov.d	x3, v25[1]
	fmov	x5, d25
	ld1.s	{ v21 }[3], [x1]
	add.2d	v25, v24, v28
	mov.d	x1, v25[1]
	fmov	x6, d25
	ld1.s	{ v23 }[3], [x30]
	ldr	q25, [x16]
	fmul.4s	v19, v25, v19
	fmul.4s	v18, v17, v18
	ld1.s	{ v22 }[2], [x0]
	fadd.4s	v2, v2, v18
	ld1.s	{ v22 }[3], [x2]
	add.2d	v18, v24, v29
	mov.d	x16, v18[1]
	fadd.4s	v1, v1, v19
	fmov	x0, d18
	fmul.4s	v18, v25, v21
	fmul.4s	v19, v17, v20
	fmul.4s	v20, v25, v22
	fmul.4s	v21, v17, v23
	fadd.4s	v4, v4, v19
	ldr	s19, [x6]
	ld1.s	{ v19 }[1], [x1]
	ld1.s	{ v19 }[2], [x0]
	fadd.4s	v3, v3, v18
	ld1.s	{ v19 }[3], [x16]
	ldr	s18, [x4]
	ld1.s	{ v18 }[1], [x17]
	fadd.4s	v16, v16, v21
	ld1.s	{ v18 }[2], [x5]
	ld1.s	{ v18 }[3], [x3]
	fmul.4s	v18, v25, v18
	fadd.4s	v7, v7, v20
	fmul.4s	v17, v17, v19
	fadd.4s	v6, v6, v17
	fadd.4s	v5, v5, v18
	add	x10, x10, #32
	add	x15, x15, #384
	cmp	x10, #512
	b.ne	LBB0_48
; %bb.49:                               ; %direct.false586
                                        ;   in Loop: Header=BB0_47 Depth=2
	add	x10, x19, x11
	stp	q1, q2, [x10]
	add	x10, x19, x12, lsl #5
	stp	q3, q4, [x10]
	add	x10, x19, x13, lsl #5
	stp	q7, q16, [x10]
	add	x10, x19, x14, lsl #5
	add	x8, x8, #1
	add	x9, x9, #16
	stp	q5, q6, [x10]
	cmp	x8, #24
	b.ne	LBB0_47
; %bb.50:                               ; %direct.true644.preheader
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	w8, #5632                       ; =0x1600
	add	x0, x22, x8
	mov	x1, x19
	mov	w2, #3072                       ; =0xc00
	str	q10, [sp, #1600]                ; 16-byte Spill
	str	q9, [sp, #1584]                 ; 16-byte Spill
	bl	_memcpy
	add	x0, x22, #2560
	mov	x1, x19
	mov	w2, #3072                       ; =0xc00
	bl	_memcpy
	ldr	q30, [sp, #1696]                ; 16-byte Reload
	ldr	q29, [sp, #1712]                ; 16-byte Reload
	ldr	q28, [sp, #1728]                ; 16-byte Reload
	ldr	q27, [sp, #1744]                ; 16-byte Reload
	ldr	q0, [sp, #1648]                 ; 16-byte Reload
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	fmul.4s	v0, v0, v1
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	fmul.4s	v1, v1, v2
	movi.2d	v3, #0000000000000000
	ldr	q2, [sp, #2224]                 ; 16-byte Reload
	fadd.4s	v2, v2, v3
	ldr	q4, [sp, #2192]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2256]                 ; 16-byte Reload
	fadd.4s	v3, v4, v3
	ldr	q4, [sp, #2240]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2208]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2176]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2160]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2112]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1840]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2096]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #2000]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1984]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1824]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2080]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1952]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1808]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1920]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2048]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1904]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1888]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2032]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1872]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #1760]                 ; 16-byte Reload
	fadd.4s	v2, v2, v4
	ldr	q4, [sp, #2016]                 ; 16-byte Reload
	fadd.4s	v3, v3, v4
	fadd.4s	v31, v1, v3
	fadd.4s	v19, v0, v2
	ldr	x4, [sp, #1688]                 ; 8-byte Reload
	add	x4, x4, #1
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	ldr	q0, [sp, #1616]                 ; 16-byte Reload
	cmp	x4, #129
	ldr	x17, [sp, #600]                 ; 8-byte Reload
	ldr	x16, [sp, #584]                 ; 8-byte Reload
	ldr	x0, [sp, #576]                  ; 8-byte Reload
	ldp	q20, q8, [sp, #544]             ; 32-byte Folded Reload
	ldp	q22, q21, [sp, #512]            ; 32-byte Folded Reload
	ldp	q15, q23, [sp, #480]            ; 32-byte Folded Reload
	ldr	q11, [sp, #2320]                ; 16-byte Reload
	ldr	q12, [sp, #2304]                ; 16-byte Reload
	ldr	q13, [sp, #2288]                ; 16-byte Reload
	ldr	q14, [sp, #2272]                ; 16-byte Reload
	ldp	q25, q24, [sp, #448]            ; 32-byte Folded Reload
	ldr	q26, [sp, #432]                 ; 16-byte Reload
	mov	w1, #52429                      ; =0xcccd
	mov	w2, #80                         ; =0x50
	mov	w3, #43691                      ; =0xaaab
	mov	w5, #96                         ; =0x60
	b.ne	LBB0_1
	b	LBB0_55
LBB0_51:                                ; %direct.true679.preheader
                                        ;   in Loop: Header=BB0_1 Depth=1
	mov	x8, #0                          ; =0x0
	mov	x9, #0                          ; =0x0
	b	LBB0_53
LBB0_52:                                ; %direct.schedule.44
                                        ;   in Loop: Header=BB0_53 Depth=2
	dup.2d	v4, x8
	add.2d	v4, v4, v0
	add.2d	v5, v4, v28
	add.2d	v6, v4, v27
	mov.d	x10, v6[1]
	fmov	x11, d6
	str	s3, [x11]
	st1.s	{ v3 }[1], [x10]
	mov.d	x10, v5[1]
	add.2d	v6, v4, v29
	fmov	x11, d5
	st1.s	{ v3 }[2], [x11]
	st1.s	{ v3 }[3], [x10]
	mov.d	x10, v6[1]
	fmov	x11, d6
	str	s2, [x11]
	st1.s	{ v2 }[1], [x10]
	add.2d	v3, v4, v30
	mov.d	x10, v3[1]
	fmov	x11, d3
	st1.s	{ v2 }[2], [x11]
	st1.s	{ v2 }[3], [x10]
	add	x9, x9, #1
	add	x8, x8, #4
	cmp	x9, #1536
	b.eq	LBB0_38
LBB0_53:                                ; %direct.true679
                                        ;   Parent Loop BB0_1 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	and	w10, w9, #0xffff
	mul	w10, w10, w3
	mov	w11, #2048                      ; =0x800
	bfxil	w11, w10, #22, #10
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	cmp	w11, #2052
	b.hi	LBB0_52
; %bb.54:                               ; %direct.true692
                                        ;   in Loop: Header=BB0_53 Depth=2
	lsr	w10, w10, #22
	dup.2d	v2, x11
	add.2d	v3, v2, v8
	add.2d	v4, v2, v21
	add.2d	v5, v2, v20
	add.2d	v2, v2, v22
	mov.d	x11, v2[1]
	fmov	x12, d2
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d2, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v2[1], x11
	mov.d	x11, v5[1]
	fmov	x12, d5
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d5, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v5[1], x11
	mov.d	x11, v4[1]
	fmov	x12, d4
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d4, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v4[1], x11
	mov.d	x11, v3[1]
	fmov	x12, d3
	add	x12, x12, x12, lsl #1
	lsl	x12, x12, #5
	fmov	d3, x12
	add	x11, x11, x11, lsl #1
	lsl	x11, x11, #5
	mov.d	v3[1], x11
	msub	w10, w10, w5, w9
	and	x10, x10, #0xffff
	dup.2d	v6, x10
	add.2d	v3, v3, v6
	add.2d	v4, v4, v6
	add.2d	v5, v5, v6
	add.2d	v2, v2, v6
	shl.2d	v2, v2, #2
	shl.2d	v5, v5, #2
	shl.2d	v4, v4, #2
	shl.2d	v3, v3, #2
	dup.2d	v6, x0
	add.2d	v3, v6, v3
	add.2d	v4, v6, v4
	add.2d	v5, v6, v5
	add.2d	v2, v6, v2
	mov.d	x10, v2[1]
	fmov	x11, d2
	mov.d	x12, v5[1]
	fmov	x13, d5
	mov.d	x14, v4[1]
	fmov	x15, d4
	mov.d	x16, v3[1]
	ldr	s2, [x15]
	ld1.s	{ v2 }[1], [x14]
	fmov	x14, d3
	ld1.s	{ v2 }[2], [x14]
	ld1.s	{ v2 }[3], [x16]
	ldr	s3, [x11]
	ld1.s	{ v3 }[1], [x10]
	ld1.s	{ v3 }[2], [x13]
	ld1.s	{ v3 }[3], [x12]
	b	LBB0_52
LBB0_55:                                ; %direct.schedule.51.preheader
	mov	x8, #0                          ; =0x0
	ldp	q0, q2, [sp, #16]               ; 32-byte Folded Reload
	xtn.2s	v0, v0
	movi.2s	v3, #96
	umull.2d	v0, v0, v3
	ldp	q1, q4, [sp, #48]               ; 32-byte Folded Reload
	xtn.2s	v1, v1
	umull.2d	v1, v1, v3
	xtn.2s	v2, v2
	umull.2d	v2, v2, v3
	xtn.2s	v4, v4
	umull.2d	v3, v4, v3
	ldr	x11, [sp, #8]                   ; 8-byte Reload
LBB0_56:                                ; %direct.true725
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v4, x8
	add.2d	v5, v4, v3
	add.2d	v6, v4, v2
	add.2d	v7, v4, v1
	add.2d	v4, v4, v0
	add	x9, x20, x8, lsl #5
	ldp	q16, q17, [x9]
	fdiv.4s	v17, v17, v19
	fdiv.4s	v16, v16, v31
	shl.2d	v4, v4, #2
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	shl.2d	v5, v5, #2
	dup.2d	v18, x11
	add.2d	v5, v18, v5
	add.2d	v4, v18, v4
	mov.d	x9, v4[1]
	fmov	x10, d4
	str	s16, [x10]
	st1.s	{ v16 }[1], [x9]
	add.2d	v4, v18, v7
	mov.d	x9, v4[1]
	fmov	x10, d4
	st1.s	{ v16 }[2], [x10]
	add.2d	v4, v18, v6
	st1.s	{ v16 }[3], [x9]
	mov.d	x9, v4[1]
	fmov	x10, d4
	str	s17, [x10]
	st1.s	{ v17 }[1], [x9]
	mov.d	x9, v5[1]
	fmov	x10, d5
	st1.s	{ v17 }[2], [x10]
	st1.s	{ v17 }[3], [x9]
	add	x8, x8, #1
	cmp	x8, #96
	b.ne	LBB0_56
; %bb.57:                               ; %common.ret
	add	sp, sp, #2336
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention.packet_batch.blocks
lCPI1_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI1_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI1_2:
	.quad	1920                            ; 0x780
	.quad	2240                            ; 0x8c0
lCPI1_3:
	.quad	640                             ; 0x280
	.quad	960                             ; 0x3c0
lCPI1_4:
	.quad	1280                            ; 0x500
	.quad	1600                            ; 0x640
lCPI1_5:
	.quad	0                               ; 0x0
	.quad	320                             ; 0x140
lCPI1_6:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI1_7:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI1_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI1_9:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI1_10:
	.quad	30720                           ; 0x7800
	.quad	35840                           ; 0x8c00
lCPI1_11:
	.quad	10240                           ; 0x2800
	.quad	15360                           ; 0x3c00
lCPI1_12:
	.quad	20480                           ; 0x5000
	.quad	25600                           ; 0x6400
lCPI1_13:
	.quad	0                               ; 0x0
	.quad	5120                            ; 0x1400
lCPI1_14:
	.quad	36864                           ; 0x9000
	.quad	43008                           ; 0xa800
lCPI1_15:
	.quad	12288                           ; 0x3000
	.quad	18432                           ; 0x4800
lCPI1_16:
	.quad	24576                           ; 0x6000
	.quad	30720                           ; 0x7800
lCPI1_17:
	.quad	0                               ; 0x0
	.quad	6144                            ; 0x1800
lCPI1_18:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #3248
	str	x0, [sp, #200]                  ; 8-byte Spill
	cbz	w3, LBB1_575
; %bb.1:                                ; %block.batch.loop.preheader
	mov	x20, x3
	mov	w9, #0                          ; =0x0
	mov	w22, #33280                     ; =0x8200
	movk	w22, #1, lsl #16
Lloh28:
	adrp	x8, lCPI1_0@PAGE
Lloh29:
	ldr	q19, [x8, lCPI1_0@PAGEOFF]
Lloh30:
	adrp	x8, lCPI1_1@PAGE
Lloh31:
	ldr	q20, [x8, lCPI1_1@PAGEOFF]
Lloh32:
	adrp	x8, lCPI1_2@PAGE
Lloh33:
	ldr	q0, [x8, lCPI1_2@PAGEOFF]
	str	q0, [sp, #64]                   ; 16-byte Spill
Lloh34:
	adrp	x8, lCPI1_3@PAGE
Lloh35:
	ldr	q0, [x8, lCPI1_3@PAGEOFF]
	str	q0, [sp, #48]                   ; 16-byte Spill
Lloh36:
	adrp	x8, lCPI1_4@PAGE
Lloh37:
	ldr	q0, [x8, lCPI1_4@PAGEOFF]
	str	q0, [sp, #32]                   ; 16-byte Spill
Lloh38:
	adrp	x8, lCPI1_5@PAGE
Lloh39:
	ldr	q0, [x8, lCPI1_5@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
	mov	w19, #52429                     ; =0xcccd
	mov	w24, #80                        ; =0x50
	adrp	x23, lCPI1_18@PAGE
	mov	w26, #43691                     ; =0xaaab
	mov	w25, #96                        ; =0x60
	mov	w28, #2560                      ; =0xa00
	mov	w27, #4160                      ; =0x1040
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #240]                  ; 16-byte Spill
	ldp	w10, w8, [x2, #44]
	stp	w8, w10, [sp, #192]             ; 8-byte Folded Spill
	ldp	w15, w13, [x2, #4]
	ldr	w14, [x2]
	str	x2, [sp, #232]                  ; 8-byte Spill
	str	w3, [sp, #188]                  ; 4-byte Spill
	str	q19, [sp, #672]                 ; 16-byte Spill
	str	q20, [sp, #160]                 ; 16-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x2, #36]
	ldr	w20, [sp, #188]                 ; 4-byte Reload
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldp	w13, w11, [sp, #216]            ; 8-byte Folded Reload
	ldr	x14, [sp, #224]                 ; 8-byte Reload
	add	w8, w14, #1
	ldp	w10, w9, [sp, #192]             ; 8-byte Folded Reload
	cmp	w8, w9
	cset	w8, eq
	csinc	w14, wzr, w14, eq
	ldr	w9, [sp, #212]                  ; 4-byte Reload
	cinc	w9, w9, eq
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w15, wzr, w9, ne
	add	w13, w13, w8
	add	w9, w11, #1
	cmp	w9, w20
	b.eq	LBB1_575
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_30 Depth 2
                                        ;     Child Loop BB1_32 Depth 2
                                        ;       Child Loop BB1_70 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_76 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_82 Depth 3
                                        ;       Child Loop BB1_85 Depth 3
                                        ;       Child Loop BB1_88 Depth 3
                                        ;       Child Loop BB1_91 Depth 3
                                        ;       Child Loop BB1_94 Depth 3
                                        ;       Child Loop BB1_97 Depth 3
                                        ;       Child Loop BB1_100 Depth 3
                                        ;       Child Loop BB1_103 Depth 3
                                        ;       Child Loop BB1_106 Depth 3
                                        ;       Child Loop BB1_109 Depth 3
                                        ;       Child Loop BB1_112 Depth 3
                                        ;       Child Loop BB1_115 Depth 3
                                        ;       Child Loop BB1_35 Depth 3
                                        ;       Child Loop BB1_118 Depth 3
                                        ;       Child Loop BB1_156 Depth 3
                                        ;       Child Loop BB1_238 Depth 3
                                        ;       Child Loop BB1_320 Depth 3
                                        ;       Child Loop BB1_402 Depth 3
                                        ;       Child Loop BB1_483 Depth 3
                                        ;       Child Loop BB1_486 Depth 3
                                        ;         Child Loop BB1_488 Depth 4
                                        ;       Child Loop BB1_553 Depth 3
                                        ;       Child Loop BB1_555 Depth 3
                                        ;     Child Loop BB1_559 Depth 2
	stp	w13, w9, [sp, #216]             ; 8-byte Folded Spill
	ldr	w8, [x2, #12]
	ubfiz	x9, x14, #5, #32
	cmp	x9, x8
	csel	x10, x9, xzr, ls
	subs	x11, x8, x10
	cmp	x11, #32
	mov	w12, #32                        ; =0x20
	csel	x11, x11, x12, lo
	cmp	x8, x10
	stp	w14, w15, [x2]
	str	w15, [sp, #212]                 ; 4-byte Spill
	str	w13, [x2, #8]
	str	wzr, [x2, #36]
	ccmp	x9, x8, #2, hi
	csel	x21, x11, xzr, ls
	cmp	x21, #32
	str	x14, [sp, #224]                 ; 8-byte Spill
	b.lo	LBB1_6
; %bb.5:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x21, [sp, #200]                 ; 8-byte Reload
	mov	x0, x21
	ldr	x1, [sp, #232]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #232]                  ; 8-byte Reload
	mov	w9, #8                          ; =0x8
	str	w9, [x8, #36]
	mov	x0, x21
	ldr	x1, [sp, #232]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #232]                  ; 8-byte Reload
	mov	w9, #16                         ; =0x10
	str	w9, [x8, #36]
	mov	x0, x21
	ldr	x1, [sp, #232]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #232]                  ; 8-byte Reload
	mov	w9, #24                         ; =0x18
	str	w9, [x8, #36]
	mov	x0, x21
	ldr	x1, [sp, #232]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #232]                  ; 8-byte Reload
	b	LBB1_3
LBB1_6:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x20, x21, #3
	cbz	x20, LBB1_11
; %bb.7:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x2, #36]
	ldr	x0, [sp, #200]                  ; 8-byte Reload
	ldr	x1, [sp, #232]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #232]                  ; 8-byte Reload
	cmp	x20, #1
	b.eq	LBB1_11
; %bb.8:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x2, #36]
	ldr	x0, [sp, #200]                  ; 8-byte Reload
	ldr	x1, [sp, #232]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #232]                  ; 8-byte Reload
	cmp	x20, #2
	b.eq	LBB1_11
; %bb.9:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x2, #36]
	ldr	x0, [sp, #200]                  ; 8-byte Reload
	ldr	x1, [sp, #232]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #232]                  ; 8-byte Reload
	cmp	x20, #3
	b.eq	LBB1_11
; %bb.10:                               ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x2, #36]
	ldr	x22, [sp, #200]                 ; 8-byte Reload
	mov	x0, x22
	ldr	x1, [sp, #232]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #232]                  ; 8-byte Reload
	mov	w9, #32                         ; =0x20
	str	w9, [x8, #36]
	mov	x0, x22
	ldr	x1, [sp, #232]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #232]                  ; 8-byte Reload
	mov	w9, #40                         ; =0x28
	str	w9, [x8, #36]
	mov	x0, x22
	ldr	x1, [sp, #232]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x8, [sp, #232]                  ; 8-byte Reload
	mov	w9, #48                         ; =0x30
	str	w9, [x8, #36]
	mov	x0, x22
	mov	w22, #33280                     ; =0x8200
	movk	w22, #1, lsl #16
	ldr	x1, [sp, #232]                  ; 8-byte Reload
	bl	_llm_attention.full_packet
	ldr	x2, [sp, #232]                  ; 8-byte Reload
LBB1_11:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w8, w21, #0x7
	ldr	q19, [sp, #672]                 ; 16-byte Reload
	ldr	q20, [sp, #160]                 ; 16-byte Reload
	cbz	w8, LBB1_2
; %bb.12:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w10, w20, #3
	dup.4s	v16, w8
	str	w10, [x2, #36]
	cmhi.4s	v0, v16, v20
	cmhi.4s	v15, v16, v19
	uzp1.8h	v1, v15, v0
	str	q1, [sp, #2416]                 ; 16-byte Spill
	umaxv.8h	h1, v1
	fmov	w8, s1
	tbz	w8, #0, LBB1_2
; %bb.13:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	ldr	x8, [x2, #136]
	ldr	x9, [sp, #200]                  ; 8-byte Reload
	ldr	x9, [x9]
	xtn.4h	v1, v15
	ldr	x11, [sp, #224]                 ; 8-byte Reload
	orr	w10, w10, w11, lsl #5
	dup.4s	v2, w10
	uzp1.8b	v4, v1, v0
	orr.16b	v1, v2, v19
	and.16b	v1, v15, v1
	movi.2s	v3, #80
	umull.2d	v3, v1, v3
	umov.b	w10, v4[0]
	str	w10, [sp, #652]                 ; 4-byte Spill
	tbz	w10, #0, LBB1_15
; %bb.14:                               ; %copy.active.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x10, d3
	add	x10, x9, x10, lsl #2
	ldr	q4, [x10]
	str	q4, [x8]
	ldr	q4, [x10, #16]
	str	q4, [x8, #16]
	ldr	q4, [x10, #32]
	str	q4, [x8, #32]
	ldr	q4, [x10, #48]
	str	q4, [x8, #48]
	ldr	q4, [x10, #64]
	str	q4, [x8, #64]
	ldr	q4, [x10, #80]
	str	q4, [x8, #80]
	ldr	q4, [x10, #96]
	str	q4, [x8, #96]
	ldr	q4, [x10, #112]
	str	q4, [x8, #112]
	ldr	q4, [x10, #128]
	str	q4, [x8, #128]
	ldr	q4, [x10, #144]
	str	q4, [x8, #144]
	ldr	q4, [x10, #160]
	str	q4, [x8, #160]
	ldr	q4, [x10, #176]
	str	q4, [x8, #176]
	ldr	q4, [x10, #192]
	str	q4, [x8, #192]
	ldr	q4, [x10, #208]
	str	q4, [x8, #208]
	ldr	q4, [x10, #224]
	str	q4, [x8, #224]
	ldr	q4, [x10, #240]
	str	q4, [x8, #240]
	ldr	q4, [x10, #256]
	str	q4, [x8, #256]
	ldr	q4, [x10, #272]
	str	q4, [x8, #272]
	ldr	q4, [x10, #288]
	str	q4, [x8, #288]
	ldr	q4, [x10, #304]
	str	q4, [x8, #304]
LBB1_15:                                ; %copy.continue.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.s	w10, v16[1]
	cmp	w10, #1
	cset	w11, hi
	str	w11, [sp, #648]                 ; 4-byte Spill
	cmp	w10, #2
	b.lo	LBB1_17
; %bb.16:                               ; %copy.active133.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x11, v3[1]
	add	x11, x9, x11, lsl #2
	ldr	q3, [x11]
	str	q3, [x8, #320]
	ldr	q3, [x11, #16]
	str	q3, [x8, #336]
	ldr	q3, [x11, #32]
	str	q3, [x8, #352]
	ldr	q3, [x11, #48]
	str	q3, [x8, #368]
	ldr	q3, [x11, #64]
	str	q3, [x8, #384]
	ldr	q3, [x11, #80]
	str	q3, [x8, #400]
	ldr	q3, [x11, #96]
	str	q3, [x8, #416]
	ldr	q3, [x11, #112]
	str	q3, [x8, #432]
	ldr	q3, [x11, #128]
	str	q3, [x8, #448]
	ldr	q3, [x11, #144]
	str	q3, [x8, #464]
	ldr	q3, [x11, #160]
	str	q3, [x8, #480]
	ldr	q3, [x11, #176]
	str	q3, [x8, #496]
	ldr	q3, [x11, #192]
	str	q3, [x8, #512]
	ldr	q3, [x11, #208]
	str	q3, [x8, #528]
	ldr	q3, [x11, #224]
	str	q3, [x8, #544]
	ldr	q3, [x11, #240]
	str	q3, [x8, #560]
	ldr	q3, [x11, #256]
	str	q3, [x8, #576]
	ldr	q3, [x11, #272]
	str	q3, [x8, #592]
	ldr	q3, [x11, #288]
	str	q3, [x8, #608]
	ldr	q3, [x11, #304]
	str	q3, [x8, #624]
LBB1_17:                                ; %copy.continue134.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	movi.4s	v3, #80
	umull2.2d	v3, v1, v3
	mov.s	w11, v16[2]
	cmp	w11, #2
	cset	w21, hi
	cmp	w11, #3
	b.lo	LBB1_19
; %bb.18:                               ; %copy.active135.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x12, d3
	add	x12, x9, x12, lsl #2
	ldr	q4, [x12]
	str	q4, [x8, #640]
	ldr	q4, [x12, #16]
	str	q4, [x8, #656]
	ldr	q4, [x12, #32]
	str	q4, [x8, #672]
	ldr	q4, [x12, #48]
	str	q4, [x8, #688]
	ldr	q4, [x12, #64]
	str	q4, [x8, #704]
	ldr	q4, [x12, #80]
	str	q4, [x8, #720]
	ldr	q4, [x12, #96]
	str	q4, [x8, #736]
	ldr	q4, [x12, #112]
	str	q4, [x8, #752]
	ldr	q4, [x12, #128]
	str	q4, [x8, #768]
	ldr	q4, [x12, #144]
	str	q4, [x8, #784]
	ldr	q4, [x12, #160]
	str	q4, [x8, #800]
	ldr	q4, [x12, #176]
	str	q4, [x8, #816]
	ldr	q4, [x12, #192]
	str	q4, [x8, #832]
	ldr	q4, [x12, #208]
	str	q4, [x8, #848]
	ldr	q4, [x12, #224]
	str	q4, [x8, #864]
	ldr	q4, [x12, #240]
	str	q4, [x8, #880]
	ldr	q4, [x12, #256]
	str	q4, [x8, #896]
	ldr	q4, [x12, #272]
	str	q4, [x8, #912]
	ldr	q4, [x12, #288]
	str	q4, [x8, #928]
	ldr	q4, [x12, #304]
	str	q4, [x8, #944]
LBB1_19:                                ; %copy.continue136.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.s	w12, v16[3]
	cmp	w12, #3
	cset	w13, hi
	str	w13, [sp, #644]                 ; 4-byte Spill
	cmp	w12, #4
	b.lo	LBB1_21
; %bb.20:                               ; %copy.active137.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x13, v3[1]
	add	x13, x9, x13, lsl #2
	ldr	q3, [x13]
	str	q3, [x8, #960]
	ldr	q3, [x13, #16]
	str	q3, [x8, #976]
	ldr	q3, [x13, #32]
	str	q3, [x8, #992]
	ldr	q3, [x13, #48]
	str	q3, [x8, #1008]
	ldr	q3, [x13, #64]
	str	q3, [x8, #1024]
	ldr	q3, [x13, #80]
	str	q3, [x8, #1040]
	ldr	q3, [x13, #96]
	str	q3, [x8, #1056]
	ldr	q3, [x13, #112]
	str	q3, [x8, #1072]
	ldr	q3, [x13, #128]
	str	q3, [x8, #1088]
	ldr	q3, [x13, #144]
	str	q3, [x8, #1104]
	ldr	q3, [x13, #160]
	str	q3, [x8, #1120]
	ldr	q3, [x13, #176]
	str	q3, [x8, #1136]
	ldr	q3, [x13, #192]
	str	q3, [x8, #1152]
	ldr	q3, [x13, #208]
	str	q3, [x8, #1168]
	ldr	q3, [x13, #224]
	str	q3, [x8, #1184]
	ldr	q3, [x13, #240]
	str	q3, [x8, #1200]
	ldr	q3, [x13, #256]
	str	q3, [x8, #1216]
	ldr	q3, [x13, #272]
	str	q3, [x8, #1232]
	ldr	q3, [x13, #288]
	str	q3, [x8, #1248]
	ldr	q3, [x13, #304]
	str	q3, [x8, #1264]
LBB1_21:                                ; %copy.continue138.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	orr.16b	v2, v2, v20
	and.16b	v2, v0, v2
	movi.2s	v3, #80
	umull.2d	v3, v2, v3
	fmov	w13, s16
	cmp	w13, #4
	cset	w14, hi
	str	w14, [sp, #640]                 ; 4-byte Spill
	cmp	w13, #5
	b.lo	LBB1_23
; %bb.22:                               ; %copy.active139.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x13, d3
	add	x13, x9, x13, lsl #2
	ldr	q4, [x13]
	str	q4, [x8, #1280]
	ldr	q4, [x13, #16]
	str	q4, [x8, #1296]
	ldr	q4, [x13, #32]
	str	q4, [x8, #1312]
	ldr	q4, [x13, #48]
	str	q4, [x8, #1328]
	ldr	q4, [x13, #64]
	str	q4, [x8, #1344]
	ldr	q4, [x13, #80]
	str	q4, [x8, #1360]
	ldr	q4, [x13, #96]
	str	q4, [x8, #1376]
	ldr	q4, [x13, #112]
	str	q4, [x8, #1392]
	ldr	q4, [x13, #128]
	str	q4, [x8, #1408]
	ldr	q4, [x13, #144]
	str	q4, [x8, #1424]
	ldr	q4, [x13, #160]
	str	q4, [x8, #1440]
	ldr	q4, [x13, #176]
	str	q4, [x8, #1456]
	ldr	q4, [x13, #192]
	str	q4, [x8, #1472]
	ldr	q4, [x13, #208]
	str	q4, [x8, #1488]
	ldr	q4, [x13, #224]
	str	q4, [x8, #1504]
	ldr	q4, [x13, #240]
	str	q4, [x8, #1520]
	ldr	q4, [x13, #256]
	str	q4, [x8, #1536]
	ldr	q4, [x13, #272]
	str	q4, [x8, #1552]
	ldr	q4, [x13, #288]
	str	q4, [x8, #1568]
	ldr	q4, [x13, #304]
	str	q4, [x8, #1584]
LBB1_23:                                ; %copy.continue140.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	cmp	w10, #5
	cset	w13, hi
	str	w13, [sp, #636]                 ; 4-byte Spill
	cmp	w10, #6
	b.lo	LBB1_25
; %bb.24:                               ; %copy.active141.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x10, v3[1]
	add	x10, x9, x10, lsl #2
	ldr	q3, [x10]
	str	q3, [x8, #1600]
	ldr	q3, [x10, #16]
	str	q3, [x8, #1616]
	ldr	q3, [x10, #32]
	str	q3, [x8, #1632]
	ldr	q3, [x10, #48]
	str	q3, [x8, #1648]
	ldr	q3, [x10, #64]
	str	q3, [x8, #1664]
	ldr	q3, [x10, #80]
	str	q3, [x8, #1680]
	ldr	q3, [x10, #96]
	str	q3, [x8, #1696]
	ldr	q3, [x10, #112]
	str	q3, [x8, #1712]
	ldr	q3, [x10, #128]
	str	q3, [x8, #1728]
	ldr	q3, [x10, #144]
	str	q3, [x8, #1744]
	ldr	q3, [x10, #160]
	str	q3, [x8, #1760]
	ldr	q3, [x10, #176]
	str	q3, [x8, #1776]
	ldr	q3, [x10, #192]
	str	q3, [x8, #1792]
	ldr	q3, [x10, #208]
	str	q3, [x8, #1808]
	ldr	q3, [x10, #224]
	str	q3, [x8, #1824]
	ldr	q3, [x10, #240]
	str	q3, [x8, #1840]
	ldr	q3, [x10, #256]
	str	q3, [x8, #1856]
	ldr	q3, [x10, #272]
	str	q3, [x8, #1872]
	ldr	q3, [x10, #288]
	str	q3, [x8, #1888]
	ldr	q3, [x10, #304]
	str	q3, [x8, #1904]
LBB1_25:                                ; %copy.continue142.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	movi.4s	v3, #80
	umull2.2d	v3, v2, v3
	cmp	w11, #6
	cset	w10, hi
	str	w10, [sp, #632]                 ; 4-byte Spill
	cmp	w11, #7
	b.lo	LBB1_27
; %bb.26:                               ; %copy.active143.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	fmov	x10, d3
	add	x10, x9, x10, lsl #2
	ldr	q4, [x10]
	str	q4, [x8, #1920]
	ldr	q4, [x10, #16]
	str	q4, [x8, #1936]
	ldr	q4, [x10, #32]
	str	q4, [x8, #1952]
	ldr	q4, [x10, #48]
	str	q4, [x8, #1968]
	ldr	q4, [x10, #64]
	str	q4, [x8, #1984]
	ldr	q4, [x10, #80]
	str	q4, [x8, #2000]
	ldr	q4, [x10, #96]
	str	q4, [x8, #2016]
	ldr	q4, [x10, #112]
	str	q4, [x8, #2032]
	ldr	q4, [x10, #128]
	str	q4, [x8, #2048]
	ldr	q4, [x10, #144]
	str	q4, [x8, #2064]
	ldr	q4, [x10, #160]
	str	q4, [x8, #2080]
	ldr	q4, [x10, #176]
	str	q4, [x8, #2096]
	ldr	q4, [x10, #192]
	str	q4, [x8, #2112]
	ldr	q4, [x10, #208]
	str	q4, [x8, #2128]
	ldr	q4, [x10, #224]
	str	q4, [x8, #2144]
	ldr	q4, [x10, #240]
	str	q4, [x8, #2160]
	ldr	q4, [x10, #256]
	str	q4, [x8, #2176]
	ldr	q4, [x10, #272]
	str	q4, [x8, #2192]
	ldr	q4, [x10, #288]
	str	q4, [x8, #2208]
	ldr	q4, [x10, #304]
	str	q4, [x8, #2224]
LBB1_27:                                ; %copy.continue144.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	cmp	w12, #7
	cset	w10, hi
	str	w10, [sp, #628]                 ; 4-byte Spill
	cmp	w12, #8
	b.lo	LBB1_29
; %bb.28:                               ; %copy.active145.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov.d	x10, v3[1]
	add	x9, x9, x10, lsl #2
	ldr	q3, [x9]
	str	q3, [x8, #2240]
	ldr	q3, [x9, #16]
	str	q3, [x8, #2256]
	ldr	q3, [x9, #32]
	str	q3, [x8, #2272]
	ldr	q3, [x9, #48]
	str	q3, [x8, #2288]
	ldr	q3, [x9, #64]
	str	q3, [x8, #2304]
	ldr	q3, [x9, #80]
	str	q3, [x8, #2320]
	ldr	q3, [x9, #96]
	str	q3, [x8, #2336]
	ldr	q3, [x9, #112]
	str	q3, [x8, #2352]
	ldr	q3, [x9, #128]
	str	q3, [x8, #2368]
	ldr	q3, [x9, #144]
	str	q3, [x8, #2384]
	ldr	q3, [x9, #160]
	str	q3, [x8, #2400]
	ldr	q3, [x9, #176]
	str	q3, [x8, #2416]
	ldr	q3, [x9, #192]
	str	q3, [x8, #2432]
	ldr	q3, [x9, #208]
	str	q3, [x8, #2448]
	ldr	q3, [x9, #224]
	str	q3, [x8, #2464]
	ldr	q3, [x9, #240]
	str	q3, [x8, #2480]
	ldr	q3, [x9, #256]
	str	q3, [x8, #2496]
	ldr	q3, [x9, #272]
	str	q3, [x8, #2512]
	ldr	q3, [x9, #288]
	str	q3, [x8, #2528]
	ldr	q3, [x9, #304]
	str	q3, [x8, #2544]
LBB1_29:                                ; %direct.true.i.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x9, #0                          ; =0x0
	mov	w10, #8704                      ; =0x2200
	add	x10, x8, x10
	dup.2d	v3, x10
	str	q3, [sp, #608]                  ; 16-byte Spill
	mov	w10, #49664                     ; =0xc200
	add	x10, x8, x10
	dup.2d	v27, x10
	sshll.2d	v5, v15, #0
	sshll.2d	v6, v0, #0
	sshll2.2d	v28, v15, #0
	sshll2.2d	v17, v0, #0
	dup.2d	v7, x8
	add	x15, x8, #2560
	ushll.2d	v18, v1, #0
	mov	w10, #5632                      ; =0x1600
	add	x1, x8, x10
	ushll.2d	v3, v2, #0
	add	x2, x8, x22
	ushll2.2d	v1, v1, #0
	mov	w10, #33792                     ; =0x8400
	movk	w10, #1, lsl #16
	add	x3, x8, x10
	ushll2.2d	v2, v2, #0
	mov	w10, #34304                     ; =0x8600
	movk	w10, #1, lsl #16
	add	x4, x8, x10
	ldr	x10, [sp, #200]                 ; 8-byte Reload
	ldr	x5, [x10, #16]
	ldr	x6, [x10, #32]
	stp	q2, q3, [sp, #80]               ; 32-byte Folded Spill
	ushr.2d	v4, v2, #2
	stp	q1, q18, [sp, #112]             ; 32-byte Folded Spill
	ushr.2d	v2, v1, #2
	ushr.2d	v3, v3, #2
	ldr	x10, [x10, #48]
	str	x10, [sp, #152]                 ; 8-byte Spill
	ushr.2d	v1, v18, #2
	and.16b	v18, v17, v7
	str	q18, [sp, #2192]                ; 16-byte Spill
	and.16b	v18, v28, v7
	str	q18, [sp, #2176]                ; 16-byte Spill
	and.16b	v18, v6, v7
	str	q18, [sp, #2160]                ; 16-byte Spill
	and.16b	v7, v5, v7
	str	q7, [sp, #2144]                 ; 16-byte Spill
	ldr	q7, [sp, #64]                   ; 16-byte Reload
	and.16b	v7, v17, v7
	str	q7, [sp, #2128]                 ; 16-byte Spill
	ldr	q7, [sp, #48]                   ; 16-byte Reload
	and.16b	v7, v28, v7
	str	q7, [sp, #2112]                 ; 16-byte Spill
	ldr	q7, [sp, #32]                   ; 16-byte Reload
	and.16b	v6, v6, v7
	str	q6, [sp, #2096]                 ; 16-byte Spill
	ldr	q6, [sp, #16]                   ; 16-byte Reload
	and.16b	v5, v5, v6
	str	q5, [sp, #2080]                 ; 16-byte Spill
LBB1_30:                                ; %direct.true.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x10, x15, x9
	ldp	q5, q6, [x10]
	cmhs.4s	v7, v20, v16
	and.16b	v6, v7, v6
	cmhs.4s	v7, v19, v16
	and.16b	v5, v7, v5
	stp	q5, q6, [x10]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB1_30
; %bb.31:                               ; %direct.false.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	q16, [sp, #656]                 ; 16-byte Spill
	mov	x7, #0                          ; =0x0
	sshll.2d	v5, v15, #0
	sshll.2d	v6, v0, #0
Lloh40:
	adrp	x9, lCPI1_9@PAGE
Lloh41:
	ldr	q7, [x9, lCPI1_9@PAGEOFF]
	str	q7, [sp, #560]                  ; 16-byte Spill
	and.16b	v7, v5, v7
	str	q7, [sp, #2208]                 ; 16-byte Spill
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	dup.4s	v7, w9
	and.16b	v16, v0, v7
	str	q16, [sp, #2000]                ; 16-byte Spill
	str	q7, [sp, #544]                  ; 16-byte Spill
	and.16b	v7, v15, v7
	str	q7, [sp, #1984]                 ; 16-byte Spill
	mov.d	x9, v4[1]
	mov	w11, #2053                      ; =0x805
	mul	x9, x9, x11
	fmov	x10, d4
	mul	x10, x10, x11
	fmov	d4, x10
	mov.d	v4[1], x9
	mov.d	x9, v3[1]
	mul	x9, x9, x11
	fmov	x10, d3
	mul	x10, x10, x11
	fmov	d3, x10
	mov.d	v3[1], x9
	mov.d	x9, v2[1]
	mul	x9, x9, x11
	fmov	x10, d2
	mul	x10, x10, x11
	fmov	d2, x10
	mov.d	v2[1], x9
	mov.d	x9, v1[1]
	mul	x9, x9, x11
	fmov	x10, d1
	mul	x10, x10, x11
	fmov	d1, x10
	mov.d	v1[1], x9
	and.16b	v19, v5, v1
	and.16b	v29, v28, v2
	and.16b	v31, v6, v3
	and.16b	v2, v17, v4
	movi.2d	v1, #0000000000000000
	str	q1, [sp, #3200]                 ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	movi.2d	v4, #0000000000000000
	str	q1, [sp, #2400]                 ; 16-byte Spill
	str	q1, [sp, #2384]                 ; 16-byte Spill
	str	q1, [sp, #2368]                 ; 16-byte Spill
	str	q1, [sp, #2352]                 ; 16-byte Spill
	stp	q1, q2, [sp, #464]              ; 32-byte Folded Spill
	str	q1, [sp, #2064]                 ; 16-byte Spill
	str	q1, [sp, #2048]                 ; 16-byte Spill
	str	q1, [sp, #2032]                 ; 16-byte Spill
	str	q1, [sp, #2336]                 ; 16-byte Spill
	str	q1, [sp, #2320]                 ; 16-byte Spill
	movi.2d	v30, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	mov	w9, #33312                      ; =0x8220
	movk	w9, #1, lsl #16
	add	x20, x8, x9
	movi.2d	v24, #0000000000000000
	mov	w9, #33344                      ; =0x8240
	movk	w9, #1, lsl #16
	add	x30, x8, x9
	movi.2d	v25, #0000000000000000
	mov	w9, #33376                      ; =0x8260
	movk	w9, #1, lsl #16
	add	x10, x8, x9
	movi.2d	v26, #0000000000000000
	mov	w9, #33408                      ; =0x8280
	movk	w9, #1, lsl #16
	add	x11, x8, x9
	movi.2d	v13, #0000000000000000
	mov	w9, #33440                      ; =0x82a0
	movk	w9, #1, lsl #16
	add	x12, x8, x9
	str	q1, [sp, #1904]                 ; 16-byte Spill
	mov	w9, #33472                      ; =0x82c0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #456]                  ; 8-byte Spill
	mov	w9, #33504                      ; =0x82e0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #448]                  ; 8-byte Spill
	mov	w9, #33536                      ; =0x8300
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #440]                  ; 8-byte Spill
	mov	w9, #33568                      ; =0x8320
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #432]                  ; 8-byte Spill
	mov	w9, #33600                      ; =0x8340
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #424]                  ; 8-byte Spill
	mov	w9, #33632                      ; =0x8360
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #416]                  ; 8-byte Spill
	mov	w9, #33664                      ; =0x8380
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #408]                  ; 8-byte Spill
	mov	w9, #33696                      ; =0x83a0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #400]                  ; 8-byte Spill
	mov	w9, #33728                      ; =0x83c0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #392]                  ; 8-byte Spill
	mov	w9, #33760                      ; =0x83e0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #384]                  ; 8-byte Spill
	mov	w9, #33824                      ; =0x8420
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #376]                  ; 8-byte Spill
	mov	w9, #33856                      ; =0x8440
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #368]                  ; 8-byte Spill
	mov	w9, #33888                      ; =0x8460
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #360]                  ; 8-byte Spill
	mov	w9, #33920                      ; =0x8480
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #352]                  ; 8-byte Spill
	mov	w9, #33952                      ; =0x84a0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #344]                  ; 8-byte Spill
	mov	w9, #33984                      ; =0x84c0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #336]                  ; 8-byte Spill
	mov	w9, #34016                      ; =0x84e0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #328]                  ; 8-byte Spill
	mov	w9, #34048                      ; =0x8500
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #320]                  ; 8-byte Spill
	mov	w9, #34080                      ; =0x8520
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #312]                  ; 8-byte Spill
	mov	w9, #34112                      ; =0x8540
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #304]                  ; 8-byte Spill
	mov	w9, #34144                      ; =0x8560
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #296]                  ; 8-byte Spill
	mov	w9, #34176                      ; =0x8580
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #288]                  ; 8-byte Spill
	mov	w9, #34208                      ; =0x85a0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #280]                  ; 8-byte Spill
	mov	w9, #34240                      ; =0x85c0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #272]                  ; 8-byte Spill
	mov	w9, #34272                      ; =0x85e0
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	str	x9, [sp, #264]                  ; 8-byte Spill
	str	q1, [sp, #1888]                 ; 16-byte Spill
	str	q1, [sp, #1872]                 ; 16-byte Spill
	str	q1, [sp, #1856]                 ; 16-byte Spill
	str	q1, [sp, #1840]                 ; 16-byte Spill
	str	q1, [sp, #2944]                 ; 16-byte Spill
	str	q1, [sp, #2928]                 ; 16-byte Spill
	str	q1, [sp, #2912]                 ; 16-byte Spill
	str	q1, [sp, #2896]                 ; 16-byte Spill
	str	q1, [sp, #2880]                 ; 16-byte Spill
	str	q1, [sp, #2864]                 ; 16-byte Spill
	str	q1, [sp, #2848]                 ; 16-byte Spill
	str	q1, [sp, #2832]                 ; 16-byte Spill
	str	q1, [sp, #2960]                 ; 16-byte Spill
	str	q1, [sp, #2016]                 ; 16-byte Spill
	str	q1, [sp, #2816]                 ; 16-byte Spill
	str	q1, [sp, #2800]                 ; 16-byte Spill
	str	q1, [sp, #2784]                 ; 16-byte Spill
	str	q1, [sp, #2768]                 ; 16-byte Spill
	str	q1, [sp, #2752]                 ; 16-byte Spill
	str	q1, [sp, #2736]                 ; 16-byte Spill
	str	q1, [sp, #2720]                 ; 16-byte Spill
	str	q1, [sp, #2704]                 ; 16-byte Spill
	str	q1, [sp, #2688]                 ; 16-byte Spill
	str	q1, [sp, #2672]                 ; 16-byte Spill
	str	q1, [sp, #2656]                 ; 16-byte Spill
	str	q1, [sp, #2640]                 ; 16-byte Spill
	str	q1, [sp, #2624]                 ; 16-byte Spill
	str	q1, [sp, #2608]                 ; 16-byte Spill
	str	q1, [sp, #1952]                 ; 16-byte Spill
	str	q1, [sp, #2592]                 ; 16-byte Spill
	str	q1, [sp, #2576]                 ; 16-byte Spill
	str	q1, [sp, #2560]                 ; 16-byte Spill
	str	q1, [sp, #2544]                 ; 16-byte Spill
	str	q1, [sp, #2528]                 ; 16-byte Spill
	str	q1, [sp, #2512]                 ; 16-byte Spill
	str	q1, [sp, #2496]                 ; 16-byte Spill
	str	q1, [sp, #3184]                 ; 16-byte Spill
	str	q1, [sp, #3168]                 ; 16-byte Spill
	str	q1, [sp, #3152]                 ; 16-byte Spill
	str	q1, [sp, #3136]                 ; 16-byte Spill
	str	q1, [sp, #3120]                 ; 16-byte Spill
	str	q1, [sp, #3104]                 ; 16-byte Spill
	str	q1, [sp, #3088]                 ; 16-byte Spill
	movi.2d	v5, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	str	q1, [sp, #2480]                 ; 16-byte Spill
	movi.2d	v7, #0000000000000000
	str	q1, [sp, #2464]                 ; 16-byte Spill
	str	q1, [sp, #2448]                 ; 16-byte Spill
	str	q1, [sp, #2432]                 ; 16-byte Spill
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	str	q17, [sp, #1920]                ; 16-byte Spill
	stp	q28, q27, [sp, #576]            ; 32-byte Folded Spill
	stp	q29, q19, [sp, #512]            ; 32-byte Folded Spill
	str	q31, [sp, #496]                 ; 16-byte Spill
	str	q15, [sp, #1968]                ; 16-byte Spill
LBB1_32:                                ; %direct.true152.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB1_70 Depth 3
                                        ;       Child Loop BB1_73 Depth 3
                                        ;       Child Loop BB1_76 Depth 3
                                        ;       Child Loop BB1_79 Depth 3
                                        ;       Child Loop BB1_82 Depth 3
                                        ;       Child Loop BB1_85 Depth 3
                                        ;       Child Loop BB1_88 Depth 3
                                        ;       Child Loop BB1_91 Depth 3
                                        ;       Child Loop BB1_94 Depth 3
                                        ;       Child Loop BB1_97 Depth 3
                                        ;       Child Loop BB1_100 Depth 3
                                        ;       Child Loop BB1_103 Depth 3
                                        ;       Child Loop BB1_106 Depth 3
                                        ;       Child Loop BB1_109 Depth 3
                                        ;       Child Loop BB1_112 Depth 3
                                        ;       Child Loop BB1_115 Depth 3
                                        ;       Child Loop BB1_35 Depth 3
                                        ;       Child Loop BB1_118 Depth 3
                                        ;       Child Loop BB1_156 Depth 3
                                        ;       Child Loop BB1_238 Depth 3
                                        ;       Child Loop BB1_320 Depth 3
                                        ;       Child Loop BB1_402 Depth 3
                                        ;       Child Loop BB1_483 Depth 3
                                        ;       Child Loop BB1_486 Depth 3
                                        ;         Child Loop BB1_488 Depth 4
                                        ;       Child Loop BB1_553 Depth 3
                                        ;       Child Loop BB1_555 Depth 3
	str	q13, [sp, #2304]                ; 16-byte Spill
	str	q9, [sp, #1808]                 ; 16-byte Spill
	str	q8, [sp, #1824]                 ; 16-byte Spill
	sshll.2d	v1, v15, #0
	sshll.2d	v2, v0, #0
	ldr	q3, [sp, #608]                  ; 16-byte Reload
	ldr	q6, [sp, #2480]                 ; 16-byte Reload
	bit.16b	v6, v3, v17
	bit.16b	v11, v3, v28
	bit.16b	v12, v3, v2
	bit.16b	v5, v3, v1
Lloh42:
	adrp	x9, lCPI1_10@PAGE
Lloh43:
	ldr	q3, [x9, lCPI1_10@PAGEOFF]
	ldr	q9, [sp, #2432]                 ; 16-byte Reload
	bit.16b	v9, v3, v17
Lloh44:
	adrp	x9, lCPI1_11@PAGE
Lloh45:
	ldr	q3, [x9, lCPI1_11@PAGEOFF]
	ldr	q18, [sp, #2464]                ; 16-byte Reload
	bit.16b	v18, v3, v28
Lloh46:
	adrp	x9, lCPI1_12@PAGE
Lloh47:
	ldr	q3, [x9, lCPI1_12@PAGEOFF]
	ldr	q8, [sp, #2448]                 ; 16-byte Reload
	bit.16b	v8, v3, v2
Lloh48:
	adrp	x9, lCPI1_13@PAGE
Lloh49:
	ldr	q2, [x9, lCPI1_13@PAGEOFF]
	bit.16b	v7, v2, v1
	str	q18, [sp, #2464]                ; 16-byte Spill
	add.2d	v1, v11, v18
	str	q1, [sp, #2976]                 ; 16-byte Spill
	add.2d	v1, v5, v7
	str	q1, [sp, #3008]                 ; 16-byte Spill
	str	q8, [sp, #2448]                 ; 16-byte Spill
	add.2d	v1, v12, v8
	str	q1, [sp, #2992]                 ; 16-byte Spill
	str	q6, [sp, #2480]                 ; 16-byte Spill
	str	q9, [sp, #2432]                 ; 16-byte Spill
	add.2d	v13, v6, v9
	cmp	x7, #128
	str	q5, [sp, #2272]                 ; 16-byte Spill
	str	q7, [sp, #2240]                 ; 16-byte Spill
	str	q4, [sp, #2288]                 ; 16-byte Spill
	str	q12, [sp, #2256]                ; 16-byte Spill
	b.ne	LBB1_68
; %bb.33:                               ; %direct.true702.i.i.preheader
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	mov	x13, #0                         ; =0x0
	ldr	q18, [sp, #480]                 ; 16-byte Reload
	b	LBB1_35
LBB1_34:                                ; %else294
                                        ;   in Loop: Header=BB1_35 Depth=3
	str	q4, [sp, #2288]                 ; 16-byte Spill
	add	x13, x13, #1
	add	x9, x9, #4
	cmp	x13, #1280
	b.eq	LBB1_116
LBB1_35:                                ; %direct.true702.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w14, w13, #0xffff
	mul	w16, w14, w19
	mov	w14, #2048                      ; =0x800
	bfxil	w14, w16, #22, #10
	dup.2d	v1, x14
	add.2d	v2, v1, v19
	add.2d	v3, v1, v29
	add.2d	v4, v1, v31
	add.2d	v1, v1, v18
	mov.d	x17, v1[1]
	fmov	x0, d1
	add	x0, x0, x0, lsl #2
	lsl	x0, x0, #4
	fmov	d1, x0
	add	x17, x17, x17, lsl #2
	lsl	x17, x17, #4
	mov.d	v1[1], x17
	mov.d	x17, v4[1]
	fmov	x0, d4
	add	x0, x0, x0, lsl #2
	lsl	x0, x0, #4
	fmov	d4, x0
	add	x17, x17, x17, lsl #2
	lsl	x17, x17, #4
	mov.d	v4[1], x17
	mov.d	x17, v3[1]
	fmov	x0, d3
	add	x0, x0, x0, lsl #2
	lsl	x0, x0, #4
	fmov	d3, x0
	add	x17, x17, x17, lsl #2
	lsl	x17, x17, #4
	mov.d	v3[1], x17
	mov.d	x17, v2[1]
	fmov	x0, d2
	add	x0, x0, x0, lsl #2
	lsl	x0, x0, #4
	fmov	d2, x0
	sshll.2d	v5, v15, #0
	lsr	w16, w16, #22
	msub	w16, w16, w24, w13
	and	x16, x16, #0xffff
	add	x17, x17, x17, lsl #2
	lsl	x17, x17, #4
	mov.d	v2[1], x17
	dup.2d	v6, x16
	sshll.2d	v7, v0, #0
	add.2d	v2, v2, v6
	add.2d	v3, v3, v6
	add.2d	v4, v4, v6
	add.2d	v1, v1, v6
	ldr	q6, [sp, #2352]                 ; 16-byte Reload
	bit.16b	v6, v1, v17
	str	q6, [sp, #2352]                 ; 16-byte Spill
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	bit.16b	v1, v4, v7
	str	q1, [sp, #2368]                 ; 16-byte Spill
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	bit.16b	v1, v3, v28
	str	q1, [sp, #2384]                 ; 16-byte Spill
	ldr	q1, [sp, #2400]                 ; 16-byte Reload
	bit.16b	v1, v2, v5
	str	q1, [sp, #2400]                 ; 16-byte Spill
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	cmp	w14, #2052
	b.hi	LBB1_45
; %bb.36:                               ; %direct.true715.i.i
                                        ;   in Loop: Header=BB1_35 Depth=3
	ldr	q1, [x23, lCPI1_18@PAGEOFF]
	ldr	q2, [sp, #2416]                 ; 16-byte Reload
	and.16b	v1, v2, v1
	addv.8h	h1, v1
	fmov	w14, s1
	ldr	q1, [sp, #2400]                 ; 16-byte Reload
	shl.2d	v2, v1, #2
	dup.2d	v1, x5
	add.2d	v4, v1, v2
	movi.2d	v2, #0000000000000000
	tbnz	w14, #0, LBB1_61
; %bb.37:                               ; %else1507
                                        ;   in Loop: Header=BB1_35 Depth=3
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_62
LBB1_38:                                ; %else1513
                                        ;   in Loop: Header=BB1_35 Depth=3
	ldr	q4, [sp, #2384]                 ; 16-byte Reload
	shl.2d	v4, v4, #2
	add.2d	v4, v1, v4
	tbnz	w14, #2, LBB1_63
LBB1_39:                                ; %else1519
                                        ;   in Loop: Header=BB1_35 Depth=3
	tbnz	w14, #3, LBB1_64
LBB1_40:                                ; %else1525
                                        ;   in Loop: Header=BB1_35 Depth=3
	ldr	q4, [sp, #2368]                 ; 16-byte Reload
	shl.2d	v4, v4, #2
	add.2d	v4, v1, v4
	tbnz	w14, #4, LBB1_65
LBB1_41:                                ; %else1531
                                        ;   in Loop: Header=BB1_35 Depth=3
	tbnz	w14, #5, LBB1_66
LBB1_42:                                ; %else1537
                                        ;   in Loop: Header=BB1_35 Depth=3
	ldr	q4, [sp, #2352]                 ; 16-byte Reload
	shl.2d	v4, v4, #2
	add.2d	v1, v1, v4
	tbnz	w14, #6, LBB1_67
LBB1_43:                                ; %else1543
                                        ;   in Loop: Header=BB1_35 Depth=3
	tbz	w14, #7, LBB1_45
LBB1_44:                                ; %cond.load1545
                                        ;   in Loop: Header=BB1_35 Depth=3
	mov.d	x14, v1[1]
	ld1.s	{ v2 }[3], [x14]
LBB1_45:                                ; %direct.schedule.49.i.i
                                        ;   in Loop: Header=BB1_35 Depth=3
	ldr	q1, [x23, lCPI1_18@PAGEOFF]
	ldr	q4, [sp, #2416]                 ; 16-byte Reload
	and.16b	v1, v4, v1
	addv.8h	h1, v1
	fmov	w14, s1
	bit.16b	v16, v3, v15
	dup.2d	v3, x9
	ldr	q4, [sp, #3008]                 ; 16-byte Reload
	add.2d	v4, v4, v3
	tbnz	w14, #0, LBB1_53
; %bb.46:                               ; %else266
                                        ;   in Loop: Header=BB1_35 Depth=3
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_54
LBB1_47:                                ; %else270
                                        ;   in Loop: Header=BB1_35 Depth=3
	ldr	q4, [sp, #2976]                 ; 16-byte Reload
	add.2d	v4, v4, v3
	tbnz	w14, #2, LBB1_55
LBB1_48:                                ; %else274
                                        ;   in Loop: Header=BB1_35 Depth=3
	tbnz	w14, #3, LBB1_56
LBB1_49:                                ; %else278
                                        ;   in Loop: Header=BB1_35 Depth=3
	ldr	q4, [sp, #2288]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	ldr	q2, [sp, #2992]                 ; 16-byte Reload
	add.2d	v2, v2, v3
	tbnz	w14, #4, LBB1_57
LBB1_50:                                ; %else282
                                        ;   in Loop: Header=BB1_35 Depth=3
	tbnz	w14, #5, LBB1_58
LBB1_51:                                ; %else286
                                        ;   in Loop: Header=BB1_35 Depth=3
	add.2d	v2, v13, v3
	tbnz	w14, #6, LBB1_59
LBB1_52:                                ; %else290
                                        ;   in Loop: Header=BB1_35 Depth=3
	tbz	w14, #7, LBB1_34
	b	LBB1_60
LBB1_53:                                ; %cond.store263
                                        ;   in Loop: Header=BB1_35 Depth=3
	fmov	x16, d4
	str	s16, [x16]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_47
LBB1_54:                                ; %cond.store267
                                        ;   in Loop: Header=BB1_35 Depth=3
	mov.d	x16, v4[1]
	st1.s	{ v16 }[1], [x16]
	ldr	q4, [sp, #2976]                 ; 16-byte Reload
	add.2d	v4, v4, v3
	tbz	w14, #2, LBB1_48
LBB1_55:                                ; %cond.store271
                                        ;   in Loop: Header=BB1_35 Depth=3
	fmov	x16, d4
	st1.s	{ v16 }[2], [x16]
	tbz	w14, #3, LBB1_49
LBB1_56:                                ; %cond.store275
                                        ;   in Loop: Header=BB1_35 Depth=3
	mov.d	x16, v4[1]
	st1.s	{ v16 }[3], [x16]
	ldr	q4, [sp, #2288]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	ldr	q2, [sp, #2992]                 ; 16-byte Reload
	add.2d	v2, v2, v3
	tbz	w14, #4, LBB1_50
LBB1_57:                                ; %cond.store279
                                        ;   in Loop: Header=BB1_35 Depth=3
	fmov	x16, d2
	str	s4, [x16]
	tbz	w14, #5, LBB1_51
LBB1_58:                                ; %cond.store283
                                        ;   in Loop: Header=BB1_35 Depth=3
	mov.d	x16, v2[1]
	st1.s	{ v4 }[1], [x16]
	add.2d	v2, v13, v3
	tbz	w14, #6, LBB1_52
LBB1_59:                                ; %cond.store287
                                        ;   in Loop: Header=BB1_35 Depth=3
	fmov	x16, d2
	st1.s	{ v4 }[2], [x16]
	tbz	w14, #7, LBB1_34
LBB1_60:                                ; %cond.store291
                                        ;   in Loop: Header=BB1_35 Depth=3
	mov.d	x14, v2[1]
	st1.s	{ v4 }[3], [x14]
	b	LBB1_34
LBB1_61:                                ; %cond.load1503
                                        ;   in Loop: Header=BB1_35 Depth=3
	fmov	x16, d4
	ldr	s3, [x16]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_38
LBB1_62:                                ; %cond.load1509
                                        ;   in Loop: Header=BB1_35 Depth=3
	mov.d	x16, v4[1]
	ld1.s	{ v3 }[1], [x16]
	ldr	q4, [sp, #2384]                 ; 16-byte Reload
	shl.2d	v4, v4, #2
	add.2d	v4, v1, v4
	tbz	w14, #2, LBB1_39
LBB1_63:                                ; %cond.load1515
                                        ;   in Loop: Header=BB1_35 Depth=3
	fmov	x16, d4
	ld1.s	{ v3 }[2], [x16]
	tbz	w14, #3, LBB1_40
LBB1_64:                                ; %cond.load1521
                                        ;   in Loop: Header=BB1_35 Depth=3
	mov.d	x16, v4[1]
	ld1.s	{ v3 }[3], [x16]
	ldr	q4, [sp, #2368]                 ; 16-byte Reload
	shl.2d	v4, v4, #2
	add.2d	v4, v1, v4
	tbz	w14, #4, LBB1_41
LBB1_65:                                ; %cond.load1527
                                        ;   in Loop: Header=BB1_35 Depth=3
	fmov	x16, d4
	ld1.s	{ v2 }[0], [x16]
	tbz	w14, #5, LBB1_42
LBB1_66:                                ; %cond.load1533
                                        ;   in Loop: Header=BB1_35 Depth=3
	mov.d	x16, v4[1]
	ld1.s	{ v2 }[1], [x16]
	ldr	q4, [sp, #2352]                 ; 16-byte Reload
	shl.2d	v4, v4, #2
	add.2d	v1, v1, v4
	tbz	w14, #6, LBB1_43
LBB1_67:                                ; %cond.load1539
                                        ;   in Loop: Header=BB1_35 Depth=3
	fmov	x16, d1
	ld1.s	{ v2 }[2], [x16]
	tbnz	w14, #7, LBB1_44
	b	LBB1_45
LBB1_68:                                ; %direct.true155.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x19, x8
	mov	x8, x12
	mov	x12, x11
	mov	x11, x10
	lsl	x9, x7, #4
	dup.2d	v1, x9
	add.2d	v4, v1, v19
	fmov	x9, d4
	add	x9, x9, x9, lsl #2
	lsl	x9, x9, #4
	fmov	d2, x9
	mov.d	x16, v4[1]
	add	x9, x16, x16, lsl #2
	lsl	x9, x9, #4
	mov.d	v2[1], x9
	ldr	w9, [sp, #652]                  ; 4-byte Reload
	tbz	w9, #0, LBB1_71
; %bb.69:                               ; %copy.active164.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	fmov	x13, d5
	fmov	x14, d7
	add	x13, x13, x14
	fmov	x14, d2
	add	x14, x5, x14, lsl #2
LBB1_70:                                ; %copy.chunk.i.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x17, x9, #4
	ldr	q3, [x14, x17]
	str	q3, [x13, x17]
	add	x9, x9, #1
	cmp	x9, #320
	b.ne	LBB1_70
LBB1_71:                                ; %copy.continue165.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x10, x30
	ldr	w9, [sp, #648]                  ; 4-byte Reload
	cbz	w9, LBB1_74
; %bb.72:                               ; %copy.active166.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	mov.d	x13, v5[1]
	mov.d	x14, v7[1]
	add	x13, x13, x14
	mov.d	x14, v2[1]
	add	x14, x5, x14, lsl #2
LBB1_73:                                ; %copy.chunk.i340.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x17, x9, #4
	ldr	q2, [x14, x17]
	str	q2, [x13, x17]
	add	x9, x9, #1
	cmp	x9, #320
	b.ne	LBB1_73
LBB1_74:                                ; %copy.continue167.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x30, x20
	add.2d	v3, v1, v29
	fmov	x9, d3
	add	x9, x9, x9, lsl #2
	lsl	x9, x9, #4
	fmov	d2, x9
	mov.d	x14, v3[1]
	add	x9, x14, x14, lsl #2
	lsl	x9, x9, #4
	mov.d	v2[1], x9
	ldr	q7, [sp, #480]                  ; 16-byte Reload
	ldr	q18, [sp, #2016]                ; 16-byte Reload
	ldr	q10, [sp, #1952]                ; 16-byte Reload
	cbz	w21, LBB1_77
; %bb.75:                               ; %copy.active168.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	fmov	x13, d11
	ldr	q5, [sp, #2464]                 ; 16-byte Reload
	fmov	x17, d5
	add	x13, x13, x17
	fmov	x17, d2
	add	x17, x5, x17, lsl #2
LBB1_76:                                ; %copy.chunk.i344.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x0, x9, #4
	ldr	q5, [x17, x0]
	str	q5, [x13, x0]
	add	x9, x9, #1
	cmp	x9, #320
	b.ne	LBB1_76
LBB1_77:                                ; %copy.continue169.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x20, x21
	ldr	w9, [sp, #644]                  ; 4-byte Reload
	cbz	w9, LBB1_80
; %bb.78:                               ; %copy.active170.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	mov.d	x13, v11[1]
	ldr	q5, [sp, #2464]                 ; 16-byte Reload
	mov.d	x17, v5[1]
	add	x13, x13, x17
	mov.d	x17, v2[1]
	add	x17, x5, x17, lsl #2
LBB1_79:                                ; %copy.chunk.i348.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x0, x9, #4
	ldr	q2, [x17, x0]
	str	q2, [x13, x0]
	add	x9, x9, #1
	cmp	x9, #320
	b.ne	LBB1_79
LBB1_80:                                ; %copy.continue171.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	add.2d	v2, v1, v31
	fmov	x9, d2
	add	x9, x9, x9, lsl #2
	lsl	x9, x9, #4
	fmov	d5, x9
	mov.d	x13, v2[1]
	add	x9, x13, x13, lsl #2
	lsl	x9, x9, #4
	mov.d	v5[1], x9
	ldr	w9, [sp, #640]                  ; 4-byte Reload
	cbz	w9, LBB1_83
; %bb.81:                               ; %copy.active172.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	fmov	x17, d12
	ldr	q6, [sp, #2448]                 ; 16-byte Reload
	fmov	x0, d6
	add	x17, x17, x0
	fmov	x0, d5
	add	x0, x5, x0, lsl #2
LBB1_82:                                ; %copy.chunk.i352.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x21, x9, #4
	ldr	q6, [x0, x21]
	str	q6, [x17, x21]
	add	x9, x9, #1
	cmp	x9, #320
	b.ne	LBB1_82
LBB1_83:                                ; %copy.continue173.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	ldr	w9, [sp, #636]                  ; 4-byte Reload
	cbz	w9, LBB1_86
; %bb.84:                               ; %copy.active174.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	mov.d	x17, v12[1]
	ldr	q6, [sp, #2448]                 ; 16-byte Reload
	mov.d	x0, v6[1]
	add	x17, x17, x0
	mov.d	x0, v5[1]
	add	x0, x5, x0, lsl #2
LBB1_85:                                ; %copy.chunk.i356.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x21, x9, #4
	ldr	q5, [x0, x21]
	str	q5, [x17, x21]
	add	x9, x9, #1
	cmp	x9, #320
	b.ne	LBB1_85
LBB1_86:                                ; %copy.continue175.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	add.2d	v1, v1, v7
	fmov	x9, d1
	add	x9, x9, x9, lsl #2
	lsl	x9, x9, #4
	fmov	d5, x9
	mov.d	x9, v1[1]
	add	x17, x9, x9, lsl #2
	lsl	x17, x17, #4
	mov.d	v5[1], x17
	ldr	w17, [sp, #632]                 ; 4-byte Reload
	cbz	w17, LBB1_89
; %bb.87:                               ; %copy.active176.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x17, #0                         ; =0x0
	ldr	q6, [sp, #2480]                 ; 16-byte Reload
	fmov	x0, d6
	ldr	q6, [sp, #2432]                 ; 16-byte Reload
	fmov	x21, d6
	add	x0, x0, x21
	fmov	x21, d5
	add	x21, x5, x21, lsl #2
LBB1_88:                                ; %copy.chunk.i360.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x22, x17, #4
	ldr	q6, [x21, x22]
	str	q6, [x0, x22]
	add	x17, x17, #1
	cmp	x17, #320
	b.ne	LBB1_88
LBB1_89:                                ; %copy.continue177.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	ldr	w17, [sp, #628]                 ; 4-byte Reload
	cbz	w17, LBB1_92
; %bb.90:                               ; %copy.active178.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x17, #0                         ; =0x0
	ldr	q6, [sp, #2480]                 ; 16-byte Reload
	mov.d	x0, v6[1]
	ldr	q6, [sp, #2432]                 ; 16-byte Reload
	mov.d	x21, v6[1]
	add	x0, x0, x21
	mov.d	x21, v5[1]
	add	x21, x5, x21, lsl #2
LBB1_91:                                ; %copy.chunk.i364.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x22, x17, #4
	ldr	q5, [x21, x22]
	str	q5, [x0, x22]
	add	x17, x17, #1
	cmp	x17, #320
	b.ne	LBB1_91
LBB1_92:                                ; %direct.schedule.7.thread.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	sshll.2d	v5, v15, #0
	ldr	q6, [sp, #3200]                 ; 16-byte Reload
	bit.16b	v6, v27, v5
	str	q6, [sp, #3200]                 ; 16-byte Spill
Lloh50:
	adrp	x17, lCPI1_17@PAGE
Lloh51:
	ldr	q6, [x17, lCPI1_17@PAGEOFF]
	ldr	q7, [sp, #3136]                 ; 16-byte Reload
	bit.16b	v7, v6, v5
	str	q7, [sp, #3136]                 ; 16-byte Spill
	fmov	x17, d4
	add	x17, x17, x17, lsl #1
	lsl	x17, x17, #5
	fmov	d4, x17
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #5
	mov.d	v4[1], x16
	ldr	w16, [sp, #652]                 ; 4-byte Reload
	tbz	w16, #0, LBB1_95
; %bb.93:                               ; %copy.active191.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x16, #0                         ; =0x0
	ldr	q5, [sp, #3200]                 ; 16-byte Reload
	fmov	x17, d5
	ldr	q5, [sp, #3136]                 ; 16-byte Reload
	fmov	x0, d5
	add	x17, x17, x0
	fmov	x0, d4
	add	x0, x6, x0, lsl #2
LBB1_94:                                ; %copy.chunk.i368.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x21, x16, #4
	ldr	q5, [x0, x21]
	str	q5, [x17, x21]
	add	x16, x16, #1
	cmp	x16, #384
	b.ne	LBB1_94
LBB1_95:                                ; %copy.continue192.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	ldr	w16, [sp, #648]                 ; 4-byte Reload
	cbz	w16, LBB1_98
; %bb.96:                               ; %copy.active193.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x16, #0                         ; =0x0
	ldr	q5, [sp, #3200]                 ; 16-byte Reload
	mov.d	x17, v5[1]
	ldr	q5, [sp, #3136]                 ; 16-byte Reload
	mov.d	x0, v5[1]
	add	x17, x17, x0
	mov.d	x0, v4[1]
	add	x0, x6, x0, lsl #2
LBB1_97:                                ; %copy.chunk.i371.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x21, x16, #4
	ldr	q4, [x0, x21]
	str	q4, [x17, x21]
	add	x16, x16, #1
	cmp	x16, #384
	b.ne	LBB1_97
LBB1_98:                                ; %copy.continue194.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	ldr	q4, [sp, #3184]                 ; 16-byte Reload
	bit.16b	v4, v27, v28
	str	q4, [sp, #3184]                 ; 16-byte Spill
Lloh52:
	adrp	x16, lCPI1_15@PAGE
Lloh53:
	ldr	q4, [x16, lCPI1_15@PAGEOFF]
	ldr	q5, [sp, #3120]                 ; 16-byte Reload
	bit.16b	v5, v4, v28
	str	q5, [sp, #3120]                 ; 16-byte Spill
	fmov	x16, d3
	add	x16, x16, x16, lsl #1
	lsl	x16, x16, #5
	fmov	d3, x16
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #5
	mov.d	v3[1], x14
	mov	w22, #33280                     ; =0x8200
	movk	w22, #1, lsl #16
	mov	x21, x20
	cbz	w20, LBB1_101
; %bb.99:                               ; %copy.active195.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x14, #0                         ; =0x0
	ldr	q4, [sp, #3184]                 ; 16-byte Reload
	fmov	x16, d4
	ldr	q4, [sp, #3120]                 ; 16-byte Reload
	fmov	x17, d4
	add	x16, x16, x17
	fmov	x17, d3
	add	x17, x6, x17, lsl #2
LBB1_100:                               ; %copy.chunk.i375.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x0, x14, #4
	ldr	q4, [x17, x0]
	str	q4, [x16, x0]
	add	x14, x14, #1
	cmp	x14, #384
	b.ne	LBB1_100
LBB1_101:                               ; %copy.continue196.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	ldr	w14, [sp, #644]                 ; 4-byte Reload
	mov	x20, x30
	cbz	w14, LBB1_104
; %bb.102:                              ; %copy.active197.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x14, #0                         ; =0x0
	ldr	q4, [sp, #3184]                 ; 16-byte Reload
	mov.d	x16, v4[1]
	ldr	q4, [sp, #3120]                 ; 16-byte Reload
	mov.d	x17, v4[1]
	add	x16, x16, x17
	mov.d	x17, v3[1]
	add	x17, x6, x17, lsl #2
LBB1_103:                               ; %copy.chunk.i379.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x0, x14, #4
	ldr	q3, [x17, x0]
	str	q3, [x16, x0]
	add	x14, x14, #1
	cmp	x14, #384
	b.ne	LBB1_103
LBB1_104:                               ; %copy.continue198.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	sshll.2d	v3, v0, #0
	ldr	q4, [sp, #3168]                 ; 16-byte Reload
	bit.16b	v4, v27, v3
	str	q4, [sp, #3168]                 ; 16-byte Spill
Lloh54:
	adrp	x14, lCPI1_16@PAGE
Lloh55:
	ldr	q4, [x14, lCPI1_16@PAGEOFF]
	ldr	q5, [sp, #3104]                 ; 16-byte Reload
	bit.16b	v5, v4, v3
	str	q5, [sp, #3104]                 ; 16-byte Spill
	fmov	x14, d2
	add	x14, x14, x14, lsl #1
	lsl	x14, x14, #5
	fmov	d2, x14
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #5
	mov.d	v2[1], x13
	ldr	w13, [sp, #640]                 ; 4-byte Reload
	mov	x30, x10
	cbz	w13, LBB1_107
; %bb.105:                              ; %copy.active199.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #3168]                 ; 16-byte Reload
	fmov	x14, d3
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	fmov	x16, d3
	add	x14, x14, x16
	fmov	x16, d2
	add	x16, x6, x16, lsl #2
LBB1_106:                               ; %copy.chunk.i383.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x17, x13, #4
	ldr	q3, [x16, x17]
	str	q3, [x14, x17]
	add	x13, x13, #1
	cmp	x13, #384
	b.ne	LBB1_106
LBB1_107:                               ; %copy.continue200.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	ldr	w13, [sp, #636]                 ; 4-byte Reload
	mov	x10, x11
	ldr	q4, [sp, #2960]                 ; 16-byte Reload
	cbz	w13, LBB1_110
; %bb.108:                              ; %copy.active201.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x13, #0                         ; =0x0
	ldr	q3, [sp, #3168]                 ; 16-byte Reload
	mov.d	x14, v3[1]
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	mov.d	x16, v3[1]
	add	x14, x14, x16
	mov.d	x16, v2[1]
	add	x16, x6, x16, lsl #2
LBB1_109:                               ; %copy.chunk.i387.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x17, x13, #4
	ldr	q2, [x16, x17]
	str	q2, [x14, x17]
	add	x13, x13, #1
	cmp	x13, #384
	b.ne	LBB1_109
LBB1_110:                               ; %copy.continue202.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	ldr	q2, [sp, #3152]                 ; 16-byte Reload
	bit.16b	v2, v27, v17
	str	q2, [sp, #3152]                 ; 16-byte Spill
Lloh56:
	adrp	x13, lCPI1_14@PAGE
Lloh57:
	ldr	q2, [x13, lCPI1_14@PAGEOFF]
	ldr	q3, [sp, #3088]                 ; 16-byte Reload
	bit.16b	v3, v2, v17
	str	q3, [sp, #3088]                 ; 16-byte Spill
	fmov	x13, d1
	add	x13, x13, x13, lsl #1
	lsl	x13, x13, #5
	fmov	d1, x13
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v1[1], x9
	ldr	w9, [sp, #632]                  ; 4-byte Reload
	mov	x11, x12
	cbz	w9, LBB1_113
; %bb.111:                              ; %copy.active203.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q2, [sp, #3152]                 ; 16-byte Reload
	fmov	x13, d2
	ldr	q2, [sp, #3088]                 ; 16-byte Reload
	fmov	x14, d2
	add	x13, x13, x14
	fmov	x14, d1
	add	x14, x6, x14, lsl #2
LBB1_112:                               ; %copy.chunk.i391.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x16, x9, #4
	ldr	q2, [x14, x16]
	str	q2, [x13, x16]
	add	x9, x9, #1
	cmp	x9, #384
	b.ne	LBB1_112
LBB1_113:                               ; %copy.continue204.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	ldr	w9, [sp, #628]                  ; 4-byte Reload
	mov	x12, x8
	str	q16, [sp, #1792]                ; 16-byte Spill
	cbz	w9, LBB1_152
; %bb.114:                              ; %copy.active205.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q2, [sp, #3152]                 ; 16-byte Reload
	mov.d	x13, v2[1]
	ldr	q2, [sp, #3088]                 ; 16-byte Reload
	mov.d	x14, v2[1]
	add	x13, x13, x14
	mov.d	x14, v1[1]
	add	x14, x6, x14, lsl #2
	mov	x8, x19
LBB1_115:                               ; %copy.chunk.i395.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	lsl	x16, x9, #4
	ldr	q1, [x14, x16]
	str	q1, [x13, x16]
	add	x9, x9, #1
	cmp	x9, #384
	b.ne	LBB1_115
	b	LBB1_153
LBB1_116:                               ; %direct.schedule.7.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	str	q16, [sp, #1792]                ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	mov	x13, #0                         ; =0x0
	sshll.2d	v2, v15, #0
	sshll.2d	v3, v0, #0
	ldr	q4, [sp, #3152]                 ; 16-byte Reload
	bit.16b	v4, v27, v17
	str	q4, [sp, #3152]                 ; 16-byte Spill
	ldr	q4, [sp, #3184]                 ; 16-byte Reload
	bit.16b	v4, v27, v28
	str	q4, [sp, #3184]                 ; 16-byte Spill
	ldr	q4, [sp, #3168]                 ; 16-byte Reload
	bit.16b	v4, v27, v3
	str	q4, [sp, #3168]                 ; 16-byte Spill
	ldr	q4, [sp, #3200]                 ; 16-byte Reload
	bit.16b	v4, v27, v2
	str	q4, [sp, #3200]                 ; 16-byte Spill
Lloh58:
	adrp	x14, lCPI1_14@PAGE
Lloh59:
	ldr	q4, [x14, lCPI1_14@PAGEOFF]
	ldr	q5, [sp, #3088]                 ; 16-byte Reload
	bit.16b	v5, v4, v17
	str	q5, [sp, #3088]                 ; 16-byte Spill
Lloh60:
	adrp	x14, lCPI1_15@PAGE
Lloh61:
	ldr	q4, [x14, lCPI1_15@PAGEOFF]
	ldr	q5, [sp, #3120]                 ; 16-byte Reload
	bit.16b	v5, v4, v28
	str	q5, [sp, #3120]                 ; 16-byte Spill
Lloh62:
	adrp	x14, lCPI1_16@PAGE
Lloh63:
	ldr	q4, [x14, lCPI1_16@PAGEOFF]
	ldr	q5, [sp, #3104]                 ; 16-byte Reload
	bit.16b	v5, v4, v3
	str	q5, [sp, #3104]                 ; 16-byte Spill
Lloh64:
	adrp	x14, lCPI1_17@PAGE
Lloh65:
	ldr	q3, [x14, lCPI1_17@PAGEOFF]
	ldr	q4, [sp, #3136]                 ; 16-byte Reload
	bit.16b	v4, v3, v2
	str	q4, [sp, #3136]                 ; 16-byte Spill
	ldr	q27, [sp, #464]                 ; 16-byte Reload
	ldr	q10, [sp, #1952]                ; 16-byte Reload
	b	LBB1_118
LBB1_117:                               ; %else261
                                        ;   in Loop: Header=BB1_118 Depth=3
	str	q16, [sp, #2032]                ; 16-byte Spill
	str	q7, [sp, #2048]                 ; 16-byte Spill
	str	q4, [sp, #2064]                 ; 16-byte Spill
	add	x13, x13, #1
	add	x9, x9, #4
	cmp	x13, #1536
	b.eq	LBB1_151
LBB1_118:                               ; %direct.true679.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	and	w14, w13, #0xffff
	mul	w16, w14, w26
	mov	w14, #2048                      ; =0x800
	bfxil	w14, w16, #22, #10
	dup.2d	v2, x14
	add.2d	v3, v2, v19
	add.2d	v4, v2, v29
	add.2d	v5, v2, v31
	add.2d	v2, v2, v18
	mov.d	x17, v2[1]
	fmov	x0, d2
	add	x0, x0, x0, lsl #1
	lsl	x0, x0, #5
	fmov	d2, x0
	add	x17, x17, x17, lsl #1
	lsl	x17, x17, #5
	mov.d	v2[1], x17
	mov.d	x17, v5[1]
	fmov	x0, d5
	add	x0, x0, x0, lsl #1
	lsl	x0, x0, #5
	fmov	d5, x0
	add	x17, x17, x17, lsl #1
	lsl	x17, x17, #5
	mov.d	v5[1], x17
	mov.d	x17, v4[1]
	fmov	x0, d4
	add	x0, x0, x0, lsl #1
	lsl	x0, x0, #5
	fmov	d4, x0
	add	x17, x17, x17, lsl #1
	lsl	x17, x17, #5
	mov.d	v4[1], x17
	mov.d	x17, v3[1]
	fmov	x0, d3
	add	x0, x0, x0, lsl #1
	lsl	x0, x0, #5
	fmov	d3, x0
	sshll.2d	v6, v15, #0
	lsr	w16, w16, #22
	msub	w16, w16, w25, w13
	and	x16, x16, #0xffff
	add	x17, x17, x17, lsl #1
	lsl	x17, x17, #5
	mov.d	v3[1], x17
	dup.2d	v7, x16
	sshll.2d	v16, v0, #0
	add.2d	v3, v3, v7
	add.2d	v4, v4, v7
	add.2d	v5, v5, v7
	add.2d	v2, v2, v7
	ldr	q7, [sp, #2320]                 ; 16-byte Reload
	bit.16b	v7, v2, v17
	str	q7, [sp, #2320]                 ; 16-byte Spill
	ldr	q2, [sp, #2336]                 ; 16-byte Reload
	bit.16b	v2, v5, v16
	str	q2, [sp, #2336]                 ; 16-byte Spill
	ldr	q16, [sp, #2032]                ; 16-byte Reload
	bit.16b	v16, v4, v28
	ldr	q7, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v7, v3, v6
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	cmp	w14, #2052
	b.hi	LBB1_128
; %bb.119:                              ; %direct.true692.i.i
                                        ;   in Loop: Header=BB1_118 Depth=3
	fmov	w14, s1
	shl.2d	v2, v7, #2
	dup.2d	v4, x6
	add.2d	v5, v4, v2
	movi.2d	v2, #0000000000000000
	tbnz	w14, #0, LBB1_144
; %bb.120:                              ; %else1458
                                        ;   in Loop: Header=BB1_118 Depth=3
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_145
LBB1_121:                               ; %else1464
                                        ;   in Loop: Header=BB1_118 Depth=3
	shl.2d	v5, v16, #2
	add.2d	v5, v4, v5
	tbnz	w14, #2, LBB1_146
LBB1_122:                               ; %else1470
                                        ;   in Loop: Header=BB1_118 Depth=3
	tbnz	w14, #3, LBB1_147
LBB1_123:                               ; %else1476
                                        ;   in Loop: Header=BB1_118 Depth=3
	ldr	q5, [sp, #2336]                 ; 16-byte Reload
	shl.2d	v5, v5, #2
	add.2d	v5, v4, v5
	tbnz	w14, #4, LBB1_148
LBB1_124:                               ; %else1482
                                        ;   in Loop: Header=BB1_118 Depth=3
	tbnz	w14, #5, LBB1_149
LBB1_125:                               ; %else1488
                                        ;   in Loop: Header=BB1_118 Depth=3
	ldr	q5, [sp, #2320]                 ; 16-byte Reload
	shl.2d	v5, v5, #2
	add.2d	v4, v4, v5
	tbnz	w14, #6, LBB1_150
LBB1_126:                               ; %else1494
                                        ;   in Loop: Header=BB1_118 Depth=3
	tbz	w14, #7, LBB1_128
LBB1_127:                               ; %cond.load1496
                                        ;   in Loop: Header=BB1_118 Depth=3
	mov.d	x14, v4[1]
	ld1.s	{ v2 }[3], [x14]
LBB1_128:                               ; %direct.schedule.44.i.i
                                        ;   in Loop: Header=BB1_118 Depth=3
	fmov	w14, s1
	bit.16b	v27, v3, v15
	dup.2d	v3, x9
	ldr	q4, [sp, #3200]                 ; 16-byte Reload
	ldr	q5, [sp, #3136]                 ; 16-byte Reload
	add.2d	v4, v4, v5
	add.2d	v4, v4, v3
	tbnz	w14, #0, LBB1_137
; %bb.129:                              ; %else
                                        ;   in Loop: Header=BB1_118 Depth=3
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB1_138
LBB1_130:                               ; %else249
                                        ;   in Loop: Header=BB1_118 Depth=3
	ldr	q4, [sp, #3184]                 ; 16-byte Reload
	ldr	q5, [sp, #3120]                 ; 16-byte Reload
	add.2d	v4, v4, v5
	add.2d	v4, v4, v3
	tbnz	w14, #2, LBB1_139
LBB1_131:                               ; %else251
                                        ;   in Loop: Header=BB1_118 Depth=3
	tbz	w14, #3, LBB1_133
LBB1_132:                               ; %cond.store252
                                        ;   in Loop: Header=BB1_118 Depth=3
	mov.d	x16, v4[1]
	st1.s	{ v27 }[3], [x16]
LBB1_133:                               ; %else253
                                        ;   in Loop: Header=BB1_118 Depth=3
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	ldr	q2, [sp, #3168]                 ; 16-byte Reload
	ldr	q5, [sp, #3104]                 ; 16-byte Reload
	add.2d	v2, v2, v5
	add.2d	v2, v2, v3
	tbnz	w14, #4, LBB1_140
; %bb.134:                              ; %else255
                                        ;   in Loop: Header=BB1_118 Depth=3
	tbnz	w14, #5, LBB1_141
LBB1_135:                               ; %else257
                                        ;   in Loop: Header=BB1_118 Depth=3
	ldr	q2, [sp, #3152]                 ; 16-byte Reload
	ldr	q5, [sp, #3088]                 ; 16-byte Reload
	add.2d	v2, v2, v5
	add.2d	v2, v2, v3
	tbnz	w14, #6, LBB1_142
LBB1_136:                               ; %else259
                                        ;   in Loop: Header=BB1_118 Depth=3
	tbz	w14, #7, LBB1_117
	b	LBB1_143
LBB1_137:                               ; %cond.store
                                        ;   in Loop: Header=BB1_118 Depth=3
	fmov	x16, d4
	str	s27, [x16]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_130
LBB1_138:                               ; %cond.store248
                                        ;   in Loop: Header=BB1_118 Depth=3
	mov.d	x16, v4[1]
	st1.s	{ v27 }[1], [x16]
	ldr	q4, [sp, #3184]                 ; 16-byte Reload
	ldr	q5, [sp, #3120]                 ; 16-byte Reload
	add.2d	v4, v4, v5
	add.2d	v4, v4, v3
	tbz	w14, #2, LBB1_131
LBB1_139:                               ; %cond.store250
                                        ;   in Loop: Header=BB1_118 Depth=3
	fmov	x16, d4
	st1.s	{ v27 }[2], [x16]
	tbnz	w14, #3, LBB1_132
	b	LBB1_133
LBB1_140:                               ; %cond.store254
                                        ;   in Loop: Header=BB1_118 Depth=3
	fmov	x16, d2
	str	s4, [x16]
	tbz	w14, #5, LBB1_135
LBB1_141:                               ; %cond.store256
                                        ;   in Loop: Header=BB1_118 Depth=3
	mov.d	x16, v2[1]
	st1.s	{ v4 }[1], [x16]
	ldr	q2, [sp, #3152]                 ; 16-byte Reload
	ldr	q5, [sp, #3088]                 ; 16-byte Reload
	add.2d	v2, v2, v5
	add.2d	v2, v2, v3
	tbz	w14, #6, LBB1_136
LBB1_142:                               ; %cond.store258
                                        ;   in Loop: Header=BB1_118 Depth=3
	fmov	x16, d2
	st1.s	{ v4 }[2], [x16]
	tbz	w14, #7, LBB1_117
LBB1_143:                               ; %cond.store260
                                        ;   in Loop: Header=BB1_118 Depth=3
	mov.d	x14, v2[1]
	st1.s	{ v4 }[3], [x14]
	b	LBB1_117
LBB1_144:                               ; %cond.load1454
                                        ;   in Loop: Header=BB1_118 Depth=3
	fmov	x16, d5
	ldr	s3, [x16]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB1_121
LBB1_145:                               ; %cond.load1460
                                        ;   in Loop: Header=BB1_118 Depth=3
	mov.d	x16, v5[1]
	ld1.s	{ v3 }[1], [x16]
	shl.2d	v5, v16, #2
	add.2d	v5, v4, v5
	tbz	w14, #2, LBB1_122
LBB1_146:                               ; %cond.load1466
                                        ;   in Loop: Header=BB1_118 Depth=3
	fmov	x16, d5
	ld1.s	{ v3 }[2], [x16]
	tbz	w14, #3, LBB1_123
LBB1_147:                               ; %cond.load1472
                                        ;   in Loop: Header=BB1_118 Depth=3
	mov.d	x16, v5[1]
	ld1.s	{ v3 }[3], [x16]
	ldr	q5, [sp, #2336]                 ; 16-byte Reload
	shl.2d	v5, v5, #2
	add.2d	v5, v4, v5
	tbz	w14, #4, LBB1_124
LBB1_148:                               ; %cond.load1478
                                        ;   in Loop: Header=BB1_118 Depth=3
	fmov	x16, d5
	ld1.s	{ v2 }[0], [x16]
	tbz	w14, #5, LBB1_125
LBB1_149:                               ; %cond.load1484
                                        ;   in Loop: Header=BB1_118 Depth=3
	mov.d	x16, v5[1]
	ld1.s	{ v2 }[1], [x16]
	ldr	q5, [sp, #2320]                 ; 16-byte Reload
	shl.2d	v5, v5, #2
	add.2d	v4, v4, v5
	tbz	w14, #6, LBB1_126
LBB1_150:                               ; %cond.load1490
                                        ;   in Loop: Header=BB1_118 Depth=3
	fmov	x16, d4
	ld1.s	{ v2 }[2], [x16]
	tbnz	w14, #7, LBB1_127
	b	LBB1_128
LBB1_151:                               ;   in Loop: Header=BB1_32 Depth=2
	str	q27, [sp, #464]                 ; 16-byte Spill
	ldr	q4, [sp, #2960]                 ; 16-byte Reload
	ldr	q18, [sp, #2016]                ; 16-byte Reload
	b	LBB1_154
LBB1_152:                               ;   in Loop: Header=BB1_32 Depth=2
	mov	x8, x19
LBB1_153:                               ; %direct.schedule.9.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	w19, #52429                     ; =0xcccd
LBB1_154:                               ; %direct.schedule.9.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	str	q4, [sp, #2960]                 ; 16-byte Spill
	str	q18, [sp, #2016]                ; 16-byte Spill
	mov	x13, #0                         ; =0x0
	ldr	q1, [sp, #2496]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2496]                 ; 16-byte Spill
	ldr	q1, [sp, #2512]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2512]                 ; 16-byte Spill
	ldr	q1, [sp, #2528]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2528]                 ; 16-byte Spill
	ldr	q1, [sp, #2544]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2544]                 ; 16-byte Spill
	ldr	q1, [sp, #2560]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2560]                 ; 16-byte Spill
	ldr	q1, [sp, #2576]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2576]                 ; 16-byte Spill
	ldr	q1, [sp, #2592]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2592]                 ; 16-byte Spill
	bic.16b	v10, v10, v15
	b	LBB1_156
LBB1_155:                               ; %else520
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmul.4s	v29, v31, v14
	fmul.4s	v8, v1, v9
	ldr	q14, [sp, #2512]                ; 16-byte Reload
	fadd.4s	v8, v14, v8
	ldr	q11, [sp, #2496]                ; 16-byte Reload
	fadd.4s	v29, v11, v29
	fmul.4s	v3, v31, v3
	fmul.4s	v2, v1, v2
	ldr	q28, [sp, #2544]                ; 16-byte Reload
	fadd.4s	v2, v28, v2
	ldr	q9, [sp, #2528]                 ; 16-byte Reload
	fadd.4s	v3, v9, v3
	fmul.4s	v6, v31, v6
	fmul.4s	v5, v1, v5
	ldr	q7, [sp, #2576]                 ; 16-byte Reload
	fadd.4s	v5, v7, v5
	ldr	q18, [sp, #2560]                ; 16-byte Reload
	fadd.4s	v6, v18, v6
	fmul.4s	v1, v1, v16
	fmul.4s	v16, v31, v17
	ldr	q4, [sp, #2592]                 ; 16-byte Reload
	fadd.4s	v16, v4, v16
	fadd.4s	v1, v10, v1
	bit.16b	v11, v29, v0
	str	q11, [sp, #2496]                ; 16-byte Spill
	bit.16b	v14, v8, v15
	str	q14, [sp, #2512]                ; 16-byte Spill
	bit.16b	v9, v3, v0
	str	q9, [sp, #2528]                 ; 16-byte Spill
	bit.16b	v28, v2, v15
	str	q28, [sp, #2544]                ; 16-byte Spill
	bit.16b	v18, v6, v0
	str	q18, [sp, #2560]                ; 16-byte Spill
	bit.16b	v7, v5, v15
	str	q7, [sp, #2576]                 ; 16-byte Spill
	bit.16b	v10, v1, v15
	add	x13, x13, #4
	bit.16b	v4, v16, v0
	str	q4, [sp, #2592]                 ; 16-byte Spill
	cmp	x13, #320
	mov.16b	v11, v12
	ldr	q12, [sp, #2256]                ; 16-byte Reload
	b.eq	LBB1_236
LBB1_156:                               ; %direct.true208.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q27, [x23, lCPI1_18@PAGEOFF]
	ldr	q1, [sp, #2416]                 ; 16-byte Reload
	and.16b	v1, v1, v27
	addv.8h	h19, v1
	fmov	w9, s19
	dup.2d	v2, x13
	ldr	q1, [sp, #2144]                 ; 16-byte Reload
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	add.2d	v1, v1, v3
	str	q1, [sp, #3072]                 ; 16-byte Spill
	add.2d	v3, v1, v2
	movi.2d	v1, #0000000000000000
	movi.2d	v31, #0000000000000000
	tbnz	w9, #0, LBB1_199
; %bb.157:                              ; %else297
                                        ;   in Loop: Header=BB1_156 Depth=3
	and	w9, w9, #0xff
	ldr	q4, [sp, #2272]                 ; 16-byte Reload
	ldr	q6, [sp, #2240]                 ; 16-byte Reload
	ldr	q7, [sp, #3008]                 ; 16-byte Reload
	ldr	q18, [sp, #2992]                ; 16-byte Reload
	tbnz	w9, #1, LBB1_200
LBB1_158:                               ; %else300
                                        ;   in Loop: Header=BB1_156 Depth=3
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	ldr	q5, [sp, #2112]                 ; 16-byte Reload
	add.2d	v3, v3, v5
	str	q3, [sp, #3056]                 ; 16-byte Spill
	add.2d	v3, v3, v2
	tbnz	w9, #2, LBB1_201
LBB1_159:                               ; %else304
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbnz	w9, #3, LBB1_202
LBB1_160:                               ; %else308
                                        ;   in Loop: Header=BB1_156 Depth=3
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	ldr	q5, [sp, #2096]                 ; 16-byte Reload
	add.2d	v3, v3, v5
	str	q3, [sp, #3040]                 ; 16-byte Spill
	add.2d	v3, v3, v2
	tbnz	w9, #4, LBB1_203
LBB1_161:                               ; %else312
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbnz	w9, #5, LBB1_204
LBB1_162:                               ; %else316
                                        ;   in Loop: Header=BB1_156 Depth=3
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	ldr	q5, [sp, #2128]                 ; 16-byte Reload
	add.2d	v3, v3, v5
	str	q3, [sp, #3024]                 ; 16-byte Spill
	add.2d	v3, v3, v2
	tbnz	w9, #6, LBB1_205
LBB1_163:                               ; %else320
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbnz	w9, #7, LBB1_206
LBB1_164:                               ; %else324
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	w9, s19
	orr.16b	v3, v2, v6
	add.2d	v3, v4, v3
	movi.2d	v9, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbnz	w9, #0, LBB1_207
LBB1_165:                               ; %else331
                                        ;   in Loop: Header=BB1_156 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_208
LBB1_166:                               ; %else337
                                        ;   in Loop: Header=BB1_156 Depth=3
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v11, v3
	tbnz	w9, #2, LBB1_209
LBB1_167:                               ; %else343
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbnz	w9, #3, LBB1_210
LBB1_168:                               ; %else349
                                        ;   in Loop: Header=BB1_156 Depth=3
	ldr	q3, [sp, #2448]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v12, v3
	tbnz	w9, #4, LBB1_211
LBB1_169:                               ; %else355
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbnz	w9, #5, LBB1_212
LBB1_170:                               ; %else361
                                        ;   in Loop: Header=BB1_156 Depth=3
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #2480]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #6, LBB1_213
LBB1_171:                               ; %else367
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbz	w9, #7, LBB1_173
LBB1_172:                               ; %cond.load369
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x9, v2[1]
	ld1.s	{ v14 }[3], [x9]
LBB1_173:                               ; %else373
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	w9, s19
	add	x14, x13, #320
	dup.2d	v5, x14
	orr.16b	v2, v5, v6
	add.2d	v6, v4, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w9, #0, LBB1_214
; %bb.174:                              ; %else380
                                        ;   in Loop: Header=BB1_156 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_215
LBB1_175:                               ; %else386
                                        ;   in Loop: Header=BB1_156 Depth=3
	ldr	q4, [sp, #2464]                 ; 16-byte Reload
	orr.16b	v6, v5, v4
	add.2d	v6, v11, v6
	tbnz	w9, #2, LBB1_216
LBB1_176:                               ; %else392
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbnz	w9, #3, LBB1_217
LBB1_177:                               ; %else398
                                        ;   in Loop: Header=BB1_156 Depth=3
	ldr	q4, [sp, #2448]                 ; 16-byte Reload
	orr.16b	v6, v5, v4
	add.2d	v6, v12, v6
	tbnz	w9, #4, LBB1_218
LBB1_178:                               ; %else404
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbnz	w9, #5, LBB1_219
LBB1_179:                               ; %else410
                                        ;   in Loop: Header=BB1_156 Depth=3
	ldr	q4, [sp, #2432]                 ; 16-byte Reload
	orr.16b	v5, v5, v4
	ldr	q4, [sp, #2480]                 ; 16-byte Reload
	add.2d	v5, v4, v5
	tbnz	w9, #6, LBB1_220
LBB1_180:                               ; %else416
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbz	w9, #7, LBB1_182
LBB1_181:                               ; %cond.load418
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[3], [x9]
LBB1_182:                               ; %else422
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	w9, s19
	add	x14, x13, #640
	dup.2d	v16, x14
	add.2d	v17, v7, v16
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #0, LBB1_221
; %bb.183:                              ; %else429
                                        ;   in Loop: Header=BB1_156 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_222
LBB1_184:                               ; %else435
                                        ;   in Loop: Header=BB1_156 Depth=3
	ldr	q4, [sp, #2976]                 ; 16-byte Reload
	add.2d	v17, v4, v16
	tbnz	w9, #2, LBB1_223
LBB1_185:                               ; %else441
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbnz	w9, #3, LBB1_224
LBB1_186:                               ; %else447
                                        ;   in Loop: Header=BB1_156 Depth=3
	add.2d	v17, v18, v16
	tbnz	w9, #4, LBB1_225
LBB1_187:                               ; %else453
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbnz	w9, #5, LBB1_226
LBB1_188:                               ; %else459
                                        ;   in Loop: Header=BB1_156 Depth=3
	add.2d	v16, v13, v16
	tbnz	w9, #6, LBB1_227
LBB1_189:                               ; %else465
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbz	w9, #7, LBB1_191
LBB1_190:                               ; %cond.load467
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x9, v16[1]
	ld1.s	{ v6 }[3], [x9]
LBB1_191:                               ; %else471
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	w9, s19
	add	x14, x13, #960
	dup.2d	v8, x14
	add.2d	v29, v7, v8
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w9, #0, LBB1_228
; %bb.192:                              ; %else478
                                        ;   in Loop: Header=BB1_156 Depth=3
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_229
LBB1_193:                               ; %else484
                                        ;   in Loop: Header=BB1_156 Depth=3
	ldr	q4, [sp, #2976]                 ; 16-byte Reload
	add.2d	v29, v4, v8
	tbnz	w9, #2, LBB1_230
LBB1_194:                               ; %else490
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbnz	w9, #3, LBB1_231
LBB1_195:                               ; %else496
                                        ;   in Loop: Header=BB1_156 Depth=3
	add.2d	v29, v18, v8
	tbnz	w9, #4, LBB1_232
LBB1_196:                               ; %else502
                                        ;   in Loop: Header=BB1_156 Depth=3
	tbnz	w9, #5, LBB1_233
LBB1_197:                               ; %else508
                                        ;   in Loop: Header=BB1_156 Depth=3
	add.2d	v29, v13, v8
	tbnz	w9, #6, LBB1_234
LBB1_198:                               ; %else514
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.16b	v12, v11
	tbz	w9, #7, LBB1_155
	b	LBB1_235
LBB1_199:                               ; %cond.load
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d3
	ldr	s1, [x14]
	and	w9, w9, #0xff
	ldr	q4, [sp, #2272]                 ; 16-byte Reload
	ldr	q6, [sp, #2240]                 ; 16-byte Reload
	ldr	q7, [sp, #3008]                 ; 16-byte Reload
	ldr	q18, [sp, #2992]                ; 16-byte Reload
	tbz	w9, #1, LBB1_158
LBB1_200:                               ; %cond.load298
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v1 }[1], [x14]
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	ldr	q5, [sp, #2112]                 ; 16-byte Reload
	add.2d	v3, v3, v5
	str	q3, [sp, #3056]                 ; 16-byte Spill
	add.2d	v3, v3, v2
	tbz	w9, #2, LBB1_159
LBB1_201:                               ; %cond.load302
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d3
	ld1.s	{ v1 }[2], [x14]
	tbz	w9, #3, LBB1_160
LBB1_202:                               ; %cond.load306
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v1 }[3], [x14]
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	ldr	q5, [sp, #2096]                 ; 16-byte Reload
	add.2d	v3, v3, v5
	str	q3, [sp, #3040]                 ; 16-byte Spill
	add.2d	v3, v3, v2
	tbz	w9, #4, LBB1_161
LBB1_203:                               ; %cond.load310
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d3
	ld1.s	{ v31 }[0], [x14]
	tbz	w9, #5, LBB1_162
LBB1_204:                               ; %cond.load314
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v31 }[1], [x14]
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	ldr	q5, [sp, #2128]                 ; 16-byte Reload
	add.2d	v3, v3, v5
	str	q3, [sp, #3024]                 ; 16-byte Spill
	add.2d	v3, v3, v2
	tbz	w9, #6, LBB1_163
LBB1_205:                               ; %cond.load318
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d3
	ld1.s	{ v31 }[2], [x14]
	tbz	w9, #7, LBB1_164
LBB1_206:                               ; %cond.load322
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x9, v3[1]
	ld1.s	{ v31 }[3], [x9]
	fmov	w9, s19
	orr.16b	v3, v2, v6
	add.2d	v3, v4, v3
	movi.2d	v9, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbz	w9, #0, LBB1_165
LBB1_207:                               ; %cond.load327
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d3
	ldr	s9, [x14]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_166
LBB1_208:                               ; %cond.load333
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v9 }[1], [x14]
	ldr	q3, [sp, #2464]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v11, v3
	tbz	w9, #2, LBB1_167
LBB1_209:                               ; %cond.load339
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d3
	ld1.s	{ v9 }[2], [x14]
	tbz	w9, #3, LBB1_168
LBB1_210:                               ; %cond.load345
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v9 }[3], [x14]
	ldr	q3, [sp, #2448]                 ; 16-byte Reload
	orr.16b	v3, v2, v3
	add.2d	v3, v12, v3
	tbz	w9, #4, LBB1_169
LBB1_211:                               ; %cond.load351
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d3
	ld1.s	{ v14 }[0], [x14]
	tbz	w9, #5, LBB1_170
LBB1_212:                               ; %cond.load357
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v14 }[1], [x14]
	ldr	q3, [sp, #2432]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #2480]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #6, LBB1_171
LBB1_213:                               ; %cond.load363
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d2
	ld1.s	{ v14 }[2], [x14]
	tbnz	w9, #7, LBB1_172
	b	LBB1_173
LBB1_214:                               ; %cond.load376
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d6
	ldr	s2, [x14]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_175
LBB1_215:                               ; %cond.load382
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v2 }[1], [x14]
	ldr	q4, [sp, #2464]                 ; 16-byte Reload
	orr.16b	v6, v5, v4
	add.2d	v6, v11, v6
	tbz	w9, #2, LBB1_176
LBB1_216:                               ; %cond.load388
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d6
	ld1.s	{ v2 }[2], [x14]
	tbz	w9, #3, LBB1_177
LBB1_217:                               ; %cond.load394
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v2 }[3], [x14]
	ldr	q4, [sp, #2448]                 ; 16-byte Reload
	orr.16b	v6, v5, v4
	add.2d	v6, v12, v6
	tbz	w9, #4, LBB1_178
LBB1_218:                               ; %cond.load400
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d6
	ld1.s	{ v3 }[0], [x14]
	tbz	w9, #5, LBB1_179
LBB1_219:                               ; %cond.load406
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v3 }[1], [x14]
	ldr	q4, [sp, #2432]                 ; 16-byte Reload
	orr.16b	v5, v5, v4
	ldr	q4, [sp, #2480]                 ; 16-byte Reload
	add.2d	v5, v4, v5
	tbz	w9, #6, LBB1_180
LBB1_220:                               ; %cond.load412
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d5
	ld1.s	{ v3 }[2], [x14]
	tbnz	w9, #7, LBB1_181
	b	LBB1_182
LBB1_221:                               ; %cond.load425
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d17
	ldr	s5, [x14]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_184
LBB1_222:                               ; %cond.load431
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[1], [x14]
	ldr	q4, [sp, #2976]                 ; 16-byte Reload
	add.2d	v17, v4, v16
	tbz	w9, #2, LBB1_185
LBB1_223:                               ; %cond.load437
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d17
	ld1.s	{ v5 }[2], [x14]
	tbz	w9, #3, LBB1_186
LBB1_224:                               ; %cond.load443
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[3], [x14]
	add.2d	v17, v18, v16
	tbz	w9, #4, LBB1_187
LBB1_225:                               ; %cond.load449
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d17
	ld1.s	{ v6 }[0], [x14]
	tbz	w9, #5, LBB1_188
LBB1_226:                               ; %cond.load455
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v6 }[1], [x14]
	add.2d	v16, v13, v16
	tbz	w9, #6, LBB1_189
LBB1_227:                               ; %cond.load461
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d16
	ld1.s	{ v6 }[2], [x14]
	tbnz	w9, #7, LBB1_190
	b	LBB1_191
LBB1_228:                               ; %cond.load474
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d29
	ldr	s16, [x14]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_193
LBB1_229:                               ; %cond.load480
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v16 }[1], [x14]
	ldr	q4, [sp, #2976]                 ; 16-byte Reload
	add.2d	v29, v4, v8
	tbz	w9, #2, LBB1_194
LBB1_230:                               ; %cond.load486
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d29
	ld1.s	{ v16 }[2], [x14]
	tbz	w9, #3, LBB1_195
LBB1_231:                               ; %cond.load492
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v16 }[3], [x14]
	add.2d	v29, v18, v8
	tbz	w9, #4, LBB1_196
LBB1_232:                               ; %cond.load498
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d29
	ld1.s	{ v17 }[0], [x14]
	tbz	w9, #5, LBB1_197
LBB1_233:                               ; %cond.load504
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v17 }[1], [x14]
	add.2d	v29, v13, v8
	tbz	w9, #6, LBB1_198
LBB1_234:                               ; %cond.load510
                                        ;   in Loop: Header=BB1_156 Depth=3
	fmov	x14, d29
	ld1.s	{ v17 }[2], [x14]
	mov.16b	v12, v11
	tbz	w9, #7, LBB1_155
LBB1_235:                               ; %cond.load516
                                        ;   in Loop: Header=BB1_156 Depth=3
	mov.d	x9, v29[1]
	ld1.s	{ v17 }[3], [x9]
	b	LBB1_155
LBB1_236:                               ; %direct.false209.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q1, [sp, #2608]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2608]                 ; 16-byte Spill
	ldr	q1, [sp, #2624]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2624]                 ; 16-byte Spill
	ldr	q1, [sp, #2640]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2640]                 ; 16-byte Spill
	ldr	q1, [sp, #2656]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2656]                 ; 16-byte Spill
	ldr	q1, [sp, #2672]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2672]                 ; 16-byte Spill
	ldr	q1, [sp, #2688]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2688]                 ; 16-byte Spill
	ldr	q1, [sp, #2704]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2704]                 ; 16-byte Spill
	ldr	q1, [sp, #2720]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2720]                 ; 16-byte Spill
	str	q10, [sp, #1952]                ; 16-byte Spill
	ldr	q12, [sp, #2976]                ; 16-byte Reload
	b	LBB1_238
LBB1_237:                               ; %else765
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmul.4s	v29, v31, v14
	fmul.4s	v8, v1, v9
	ldr	q4, [sp, #2624]                 ; 16-byte Reload
	fadd.4s	v8, v4, v8
	ldr	q10, [sp, #2608]                ; 16-byte Reload
	fadd.4s	v29, v10, v29
	fmul.4s	v3, v31, v3
	fmul.4s	v2, v1, v2
	ldr	q14, [sp, #2656]                ; 16-byte Reload
	fadd.4s	v2, v14, v2
	ldr	q28, [sp, #2640]                ; 16-byte Reload
	fadd.4s	v3, v28, v3
	fmul.4s	v6, v31, v6
	fmul.4s	v5, v1, v5
	ldr	q18, [sp, #2688]                ; 16-byte Reload
	fadd.4s	v5, v18, v5
	ldr	q9, [sp, #2672]                 ; 16-byte Reload
	fadd.4s	v6, v9, v6
	fmul.4s	v1, v1, v16
	fmul.4s	v16, v31, v17
	ldr	q17, [sp, #2704]                ; 16-byte Reload
	fadd.4s	v16, v17, v16
	ldr	q7, [sp, #2720]                 ; 16-byte Reload
	fadd.4s	v1, v7, v1
	bit.16b	v10, v29, v0
	str	q10, [sp, #2608]                ; 16-byte Spill
	bit.16b	v4, v8, v15
	str	q4, [sp, #2624]                 ; 16-byte Spill
	bit.16b	v28, v3, v0
	str	q28, [sp, #2640]                ; 16-byte Spill
	bit.16b	v14, v2, v15
	str	q14, [sp, #2656]                ; 16-byte Spill
	bit.16b	v9, v6, v0
	str	q9, [sp, #2672]                 ; 16-byte Spill
	bit.16b	v18, v5, v15
	str	q18, [sp, #2688]                ; 16-byte Spill
	bit.16b	v7, v1, v15
	str	q7, [sp, #2720]                 ; 16-byte Spill
	add	x9, x9, #4
	bit.16b	v17, v16, v0
	str	q17, [sp, #2704]                ; 16-byte Spill
	cmp	x9, #320
	b.eq	LBB1_318
LBB1_238:                               ; %direct.true235.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w13, s19
	dup.2d	v2, x9
	ldr	q1, [sp, #3072]                 ; 16-byte Reload
	add.2d	v3, v1, v2
	movi.2d	v1, #0000000000000000
	movi.2d	v31, #0000000000000000
	ldr	q4, [sp, #3008]                 ; 16-byte Reload
	tbnz	w13, #0, LBB1_282
; %bb.239:                              ; %else527
                                        ;   in Loop: Header=BB1_238 Depth=3
	and	w13, w13, #0xff
	ldr	q7, [sp, #2992]                 ; 16-byte Reload
	tbnz	w13, #1, LBB1_283
LBB1_240:                               ; %else533
                                        ;   in Loop: Header=BB1_238 Depth=3
	ldr	q3, [sp, #3056]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbnz	w13, #2, LBB1_284
LBB1_241:                               ; %else539
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbnz	w13, #3, LBB1_285
LBB1_242:                               ; %else545
                                        ;   in Loop: Header=BB1_238 Depth=3
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbnz	w13, #4, LBB1_286
LBB1_243:                               ; %else551
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbnz	w13, #5, LBB1_287
LBB1_244:                               ; %else557
                                        ;   in Loop: Header=BB1_238 Depth=3
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w13, #6, LBB1_288
LBB1_245:                               ; %else563
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbz	w13, #7, LBB1_247
LBB1_246:                               ; %cond.load565
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x13, v2[1]
	ld1.s	{ v31 }[3], [x13]
LBB1_247:                               ; %else569
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	w13, s19
	add	x14, x9, #1280
	dup.2d	v2, x14
	add.2d	v3, v4, v2
	movi.2d	v9, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbnz	w13, #0, LBB1_289
; %bb.248:                              ; %else576
                                        ;   in Loop: Header=BB1_238 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_290
LBB1_249:                               ; %else582
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v3, v12, v2
	tbnz	w13, #2, LBB1_291
LBB1_250:                               ; %else588
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbnz	w13, #3, LBB1_292
LBB1_251:                               ; %else594
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v3, v7, v2
	tbnz	w13, #4, LBB1_293
LBB1_252:                               ; %else600
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbnz	w13, #5, LBB1_294
LBB1_253:                               ; %else606
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v2, v13, v2
	tbnz	w13, #6, LBB1_295
LBB1_254:                               ; %else612
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbz	w13, #7, LBB1_256
LBB1_255:                               ; %cond.load614
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x13, v2[1]
	ld1.s	{ v14 }[3], [x13]
LBB1_256:                               ; %else618
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	w13, s19
	add	x14, x9, #1600
	dup.2d	v5, x14
	add.2d	v6, v4, v5
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w13, #0, LBB1_296
; %bb.257:                              ; %else625
                                        ;   in Loop: Header=BB1_238 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_297
LBB1_258:                               ; %else631
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v6, v12, v5
	tbnz	w13, #2, LBB1_298
LBB1_259:                               ; %else637
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbnz	w13, #3, LBB1_299
LBB1_260:                               ; %else643
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v6, v7, v5
	tbnz	w13, #4, LBB1_300
LBB1_261:                               ; %else649
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbnz	w13, #5, LBB1_301
LBB1_262:                               ; %else655
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v5, v13, v5
	tbnz	w13, #6, LBB1_302
LBB1_263:                               ; %else661
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbz	w13, #7, LBB1_265
LBB1_264:                               ; %cond.load663
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x13, v5[1]
	ld1.s	{ v3 }[3], [x13]
LBB1_265:                               ; %else667
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	w13, s19
	add	x14, x9, #1920
	dup.2d	v16, x14
	add.2d	v17, v4, v16
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w13, #0, LBB1_303
; %bb.266:                              ; %else674
                                        ;   in Loop: Header=BB1_238 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_304
LBB1_267:                               ; %else680
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v17, v12, v16
	tbnz	w13, #2, LBB1_305
LBB1_268:                               ; %else686
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbnz	w13, #3, LBB1_306
LBB1_269:                               ; %else692
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v17, v7, v16
	tbnz	w13, #4, LBB1_307
LBB1_270:                               ; %else698
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbnz	w13, #5, LBB1_308
LBB1_271:                               ; %else704
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v16, v13, v16
	tbnz	w13, #6, LBB1_309
LBB1_272:                               ; %else710
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbz	w13, #7, LBB1_274
LBB1_273:                               ; %cond.load712
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x13, v16[1]
	ld1.s	{ v6 }[3], [x13]
LBB1_274:                               ; %else716
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	w13, s19
	add	x14, x9, #2240
	dup.2d	v8, x14
	add.2d	v29, v4, v8
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w13, #0, LBB1_310
; %bb.275:                              ; %else723
                                        ;   in Loop: Header=BB1_238 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_311
LBB1_276:                               ; %else729
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v29, v12, v8
	tbnz	w13, #2, LBB1_312
LBB1_277:                               ; %else735
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbnz	w13, #3, LBB1_313
LBB1_278:                               ; %else741
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v29, v7, v8
	tbnz	w13, #4, LBB1_314
LBB1_279:                               ; %else747
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbnz	w13, #5, LBB1_315
LBB1_280:                               ; %else753
                                        ;   in Loop: Header=BB1_238 Depth=3
	add.2d	v29, v13, v8
	tbnz	w13, #6, LBB1_316
LBB1_281:                               ; %else759
                                        ;   in Loop: Header=BB1_238 Depth=3
	tbz	w13, #7, LBB1_237
	b	LBB1_317
LBB1_282:                               ; %cond.load523
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d3
	ldr	s1, [x14]
	and	w13, w13, #0xff
	ldr	q7, [sp, #2992]                 ; 16-byte Reload
	tbz	w13, #1, LBB1_240
LBB1_283:                               ; %cond.load529
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v1 }[1], [x14]
	ldr	q3, [sp, #3056]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbz	w13, #2, LBB1_241
LBB1_284:                               ; %cond.load535
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d3
	ld1.s	{ v1 }[2], [x14]
	tbz	w13, #3, LBB1_242
LBB1_285:                               ; %cond.load541
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v1 }[3], [x14]
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbz	w13, #4, LBB1_243
LBB1_286:                               ; %cond.load547
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d3
	ld1.s	{ v31 }[0], [x14]
	tbz	w13, #5, LBB1_244
LBB1_287:                               ; %cond.load553
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v31 }[1], [x14]
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w13, #6, LBB1_245
LBB1_288:                               ; %cond.load559
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d2
	ld1.s	{ v31 }[2], [x14]
	tbnz	w13, #7, LBB1_246
	b	LBB1_247
LBB1_289:                               ; %cond.load572
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d3
	ldr	s9, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_249
LBB1_290:                               ; %cond.load578
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v9 }[1], [x14]
	add.2d	v3, v12, v2
	tbz	w13, #2, LBB1_250
LBB1_291:                               ; %cond.load584
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d3
	ld1.s	{ v9 }[2], [x14]
	tbz	w13, #3, LBB1_251
LBB1_292:                               ; %cond.load590
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v9 }[3], [x14]
	add.2d	v3, v7, v2
	tbz	w13, #4, LBB1_252
LBB1_293:                               ; %cond.load596
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d3
	ld1.s	{ v14 }[0], [x14]
	tbz	w13, #5, LBB1_253
LBB1_294:                               ; %cond.load602
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v14 }[1], [x14]
	add.2d	v2, v13, v2
	tbz	w13, #6, LBB1_254
LBB1_295:                               ; %cond.load608
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d2
	ld1.s	{ v14 }[2], [x14]
	tbnz	w13, #7, LBB1_255
	b	LBB1_256
LBB1_296:                               ; %cond.load621
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d6
	ldr	s2, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_258
LBB1_297:                               ; %cond.load627
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v2 }[1], [x14]
	add.2d	v6, v12, v5
	tbz	w13, #2, LBB1_259
LBB1_298:                               ; %cond.load633
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d6
	ld1.s	{ v2 }[2], [x14]
	tbz	w13, #3, LBB1_260
LBB1_299:                               ; %cond.load639
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v2 }[3], [x14]
	add.2d	v6, v7, v5
	tbz	w13, #4, LBB1_261
LBB1_300:                               ; %cond.load645
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d6
	ld1.s	{ v3 }[0], [x14]
	tbz	w13, #5, LBB1_262
LBB1_301:                               ; %cond.load651
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v3 }[1], [x14]
	add.2d	v5, v13, v5
	tbz	w13, #6, LBB1_263
LBB1_302:                               ; %cond.load657
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d5
	ld1.s	{ v3 }[2], [x14]
	tbnz	w13, #7, LBB1_264
	b	LBB1_265
LBB1_303:                               ; %cond.load670
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d17
	ldr	s5, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_267
LBB1_304:                               ; %cond.load676
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[1], [x14]
	add.2d	v17, v12, v16
	tbz	w13, #2, LBB1_268
LBB1_305:                               ; %cond.load682
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d17
	ld1.s	{ v5 }[2], [x14]
	tbz	w13, #3, LBB1_269
LBB1_306:                               ; %cond.load688
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[3], [x14]
	add.2d	v17, v7, v16
	tbz	w13, #4, LBB1_270
LBB1_307:                               ; %cond.load694
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d17
	ld1.s	{ v6 }[0], [x14]
	tbz	w13, #5, LBB1_271
LBB1_308:                               ; %cond.load700
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v6 }[1], [x14]
	add.2d	v16, v13, v16
	tbz	w13, #6, LBB1_272
LBB1_309:                               ; %cond.load706
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d16
	ld1.s	{ v6 }[2], [x14]
	tbnz	w13, #7, LBB1_273
	b	LBB1_274
LBB1_310:                               ; %cond.load719
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d29
	ldr	s16, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_276
LBB1_311:                               ; %cond.load725
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v16 }[1], [x14]
	add.2d	v29, v12, v8
	tbz	w13, #2, LBB1_277
LBB1_312:                               ; %cond.load731
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d29
	ld1.s	{ v16 }[2], [x14]
	tbz	w13, #3, LBB1_278
LBB1_313:                               ; %cond.load737
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v16 }[3], [x14]
	add.2d	v29, v7, v8
	tbz	w13, #4, LBB1_279
LBB1_314:                               ; %cond.load743
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d29
	ld1.s	{ v17 }[0], [x14]
	tbz	w13, #5, LBB1_280
LBB1_315:                               ; %cond.load749
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v17 }[1], [x14]
	add.2d	v29, v13, v8
	tbz	w13, #6, LBB1_281
LBB1_316:                               ; %cond.load755
                                        ;   in Loop: Header=BB1_238 Depth=3
	fmov	x14, d29
	ld1.s	{ v17 }[2], [x14]
	tbz	w13, #7, LBB1_237
LBB1_317:                               ; %cond.load761
                                        ;   in Loop: Header=BB1_238 Depth=3
	mov.d	x13, v29[1]
	ld1.s	{ v17 }[3], [x13]
	b	LBB1_237
LBB1_318:                               ; %direct.false236.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	str	q13, [sp, #2224]                ; 16-byte Spill
	str	q11, [sp, #1776]                ; 16-byte Spill
	mov	x9, #0                          ; =0x0
	ldr	q1, [sp, #2736]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2736]                 ; 16-byte Spill
	ldr	q1, [sp, #2752]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2752]                 ; 16-byte Spill
	ldr	q1, [sp, #2768]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2768]                 ; 16-byte Spill
	ldr	q1, [sp, #2784]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2784]                 ; 16-byte Spill
	ldr	q1, [sp, #2800]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2800]                 ; 16-byte Spill
	ldr	q1, [sp, #2816]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2816]                 ; 16-byte Spill
	ldr	q11, [sp, #2016]                ; 16-byte Reload
	bic.16b	v11, v11, v0
	ldr	q17, [sp, #2960]                ; 16-byte Reload
	bic.16b	v17, v17, v15
	ldr	q4, [sp, #3008]                 ; 16-byte Reload
	ldr	q28, [sp, #2992]                ; 16-byte Reload
	b	LBB1_320
LBB1_319:                               ; %else1010
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmul.4s	v29, v31, v14
	fmul.4s	v8, v1, v9
	ldr	q18, [sp, #2752]                ; 16-byte Reload
	fadd.4s	v8, v18, v8
	ldr	q7, [sp, #2736]                 ; 16-byte Reload
	fadd.4s	v29, v7, v29
	fmul.4s	v3, v31, v3
	fmul.4s	v2, v1, v2
	ldr	q9, [sp, #2784]                 ; 16-byte Reload
	fadd.4s	v2, v9, v2
	ldr	q14, [sp, #2768]                ; 16-byte Reload
	fadd.4s	v3, v14, v3
	fmul.4s	v6, v31, v6
	fmul.4s	v5, v1, v5
	ldr	q10, [sp, #2816]                ; 16-byte Reload
	fadd.4s	v5, v10, v5
	ldr	q13, [sp, #2800]                ; 16-byte Reload
	fadd.4s	v6, v13, v6
	fmul.4s	v1, v1, v16
	fmul.4s	v16, v31, v17
	fadd.4s	v16, v11, v16
	ldr	q17, [sp, #2960]                ; 16-byte Reload
	fadd.4s	v1, v17, v1
	bit.16b	v7, v29, v0
	str	q7, [sp, #2736]                 ; 16-byte Spill
	bit.16b	v18, v8, v15
	str	q18, [sp, #2752]                ; 16-byte Spill
	bit.16b	v14, v3, v0
	str	q14, [sp, #2768]                ; 16-byte Spill
	bit.16b	v9, v2, v15
	str	q9, [sp, #2784]                 ; 16-byte Spill
	bit.16b	v13, v6, v0
	str	q13, [sp, #2800]                ; 16-byte Spill
	bit.16b	v10, v5, v15
	str	q10, [sp, #2816]                ; 16-byte Spill
	bit.16b	v17, v1, v15
	add	x9, x9, #4
	bit.16b	v11, v16, v0
	cmp	x9, #320
	b.eq	LBB1_400
LBB1_320:                               ; %direct.true263.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	str	q17, [sp, #2960]                ; 16-byte Spill
	fmov	w13, s19
	dup.2d	v2, x9
	ldr	q1, [sp, #3072]                 ; 16-byte Reload
	add.2d	v3, v1, v2
	movi.2d	v1, #0000000000000000
	movi.2d	v31, #0000000000000000
	tbnz	w13, #0, LBB1_364
; %bb.321:                              ; %else772
                                        ;   in Loop: Header=BB1_320 Depth=3
	and	w13, w13, #0xff
	ldr	q7, [sp, #2224]                 ; 16-byte Reload
	tbnz	w13, #1, LBB1_365
LBB1_322:                               ; %else778
                                        ;   in Loop: Header=BB1_320 Depth=3
	ldr	q3, [sp, #3056]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbnz	w13, #2, LBB1_366
LBB1_323:                               ; %else784
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbnz	w13, #3, LBB1_367
LBB1_324:                               ; %else790
                                        ;   in Loop: Header=BB1_320 Depth=3
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbnz	w13, #4, LBB1_368
LBB1_325:                               ; %else796
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbnz	w13, #5, LBB1_369
LBB1_326:                               ; %else802
                                        ;   in Loop: Header=BB1_320 Depth=3
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w13, #6, LBB1_370
LBB1_327:                               ; %else808
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbz	w13, #7, LBB1_329
LBB1_328:                               ; %cond.load810
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x13, v2[1]
	ld1.s	{ v31 }[3], [x13]
LBB1_329:                               ; %else814
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	w13, s19
	orr	x14, x9, x28
	dup.2d	v2, x14
	add.2d	v3, v4, v2
	movi.2d	v9, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbnz	w13, #0, LBB1_371
; %bb.330:                              ; %else821
                                        ;   in Loop: Header=BB1_320 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_372
LBB1_331:                               ; %else827
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v3, v12, v2
	tbnz	w13, #2, LBB1_373
LBB1_332:                               ; %else833
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbnz	w13, #3, LBB1_374
LBB1_333:                               ; %else839
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v3, v28, v2
	tbnz	w13, #4, LBB1_375
LBB1_334:                               ; %else845
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbnz	w13, #5, LBB1_376
LBB1_335:                               ; %else851
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v2, v7, v2
	tbnz	w13, #6, LBB1_377
LBB1_336:                               ; %else857
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbz	w13, #7, LBB1_338
LBB1_337:                               ; %cond.load859
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x13, v2[1]
	ld1.s	{ v14 }[3], [x13]
LBB1_338:                               ; %else863
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	w13, s19
	add	x14, x9, #2880
	dup.2d	v5, x14
	add.2d	v6, v4, v5
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w13, #0, LBB1_378
; %bb.339:                              ; %else870
                                        ;   in Loop: Header=BB1_320 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_379
LBB1_340:                               ; %else876
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v6, v12, v5
	tbnz	w13, #2, LBB1_380
LBB1_341:                               ; %else882
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbnz	w13, #3, LBB1_381
LBB1_342:                               ; %else888
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v6, v28, v5
	tbnz	w13, #4, LBB1_382
LBB1_343:                               ; %else894
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbnz	w13, #5, LBB1_383
LBB1_344:                               ; %else900
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v5, v7, v5
	tbnz	w13, #6, LBB1_384
LBB1_345:                               ; %else906
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbz	w13, #7, LBB1_347
LBB1_346:                               ; %cond.load908
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x13, v5[1]
	ld1.s	{ v3 }[3], [x13]
LBB1_347:                               ; %else912
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	w13, s19
	add	x14, x9, #3200
	dup.2d	v16, x14
	add.2d	v17, v4, v16
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w13, #0, LBB1_385
; %bb.348:                              ; %else919
                                        ;   in Loop: Header=BB1_320 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_386
LBB1_349:                               ; %else925
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v17, v12, v16
	tbnz	w13, #2, LBB1_387
LBB1_350:                               ; %else931
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbnz	w13, #3, LBB1_388
LBB1_351:                               ; %else937
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v17, v28, v16
	tbnz	w13, #4, LBB1_389
LBB1_352:                               ; %else943
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbnz	w13, #5, LBB1_390
LBB1_353:                               ; %else949
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v16, v7, v16
	tbnz	w13, #6, LBB1_391
LBB1_354:                               ; %else955
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbz	w13, #7, LBB1_356
LBB1_355:                               ; %cond.load957
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x13, v16[1]
	ld1.s	{ v6 }[3], [x13]
LBB1_356:                               ; %else961
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	w13, s19
	add	x14, x9, #3520
	dup.2d	v8, x14
	add.2d	v29, v4, v8
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w13, #0, LBB1_392
; %bb.357:                              ; %else968
                                        ;   in Loop: Header=BB1_320 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_393
LBB1_358:                               ; %else974
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v29, v12, v8
	tbnz	w13, #2, LBB1_394
LBB1_359:                               ; %else980
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbnz	w13, #3, LBB1_395
LBB1_360:                               ; %else986
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v29, v28, v8
	tbnz	w13, #4, LBB1_396
LBB1_361:                               ; %else992
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbnz	w13, #5, LBB1_397
LBB1_362:                               ; %else998
                                        ;   in Loop: Header=BB1_320 Depth=3
	add.2d	v29, v7, v8
	tbnz	w13, #6, LBB1_398
LBB1_363:                               ; %else1004
                                        ;   in Loop: Header=BB1_320 Depth=3
	tbz	w13, #7, LBB1_319
	b	LBB1_399
LBB1_364:                               ; %cond.load768
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d3
	ldr	s1, [x14]
	and	w13, w13, #0xff
	ldr	q7, [sp, #2224]                 ; 16-byte Reload
	tbz	w13, #1, LBB1_322
LBB1_365:                               ; %cond.load774
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v1 }[1], [x14]
	ldr	q3, [sp, #3056]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbz	w13, #2, LBB1_323
LBB1_366:                               ; %cond.load780
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d3
	ld1.s	{ v1 }[2], [x14]
	tbz	w13, #3, LBB1_324
LBB1_367:                               ; %cond.load786
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v1 }[3], [x14]
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbz	w13, #4, LBB1_325
LBB1_368:                               ; %cond.load792
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d3
	ld1.s	{ v31 }[0], [x14]
	tbz	w13, #5, LBB1_326
LBB1_369:                               ; %cond.load798
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v31 }[1], [x14]
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w13, #6, LBB1_327
LBB1_370:                               ; %cond.load804
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d2
	ld1.s	{ v31 }[2], [x14]
	tbnz	w13, #7, LBB1_328
	b	LBB1_329
LBB1_371:                               ; %cond.load817
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d3
	ldr	s9, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_331
LBB1_372:                               ; %cond.load823
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v9 }[1], [x14]
	add.2d	v3, v12, v2
	tbz	w13, #2, LBB1_332
LBB1_373:                               ; %cond.load829
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d3
	ld1.s	{ v9 }[2], [x14]
	tbz	w13, #3, LBB1_333
LBB1_374:                               ; %cond.load835
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v9 }[3], [x14]
	add.2d	v3, v28, v2
	tbz	w13, #4, LBB1_334
LBB1_375:                               ; %cond.load841
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d3
	ld1.s	{ v14 }[0], [x14]
	tbz	w13, #5, LBB1_335
LBB1_376:                               ; %cond.load847
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v14 }[1], [x14]
	add.2d	v2, v7, v2
	tbz	w13, #6, LBB1_336
LBB1_377:                               ; %cond.load853
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d2
	ld1.s	{ v14 }[2], [x14]
	tbnz	w13, #7, LBB1_337
	b	LBB1_338
LBB1_378:                               ; %cond.load866
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d6
	ldr	s2, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_340
LBB1_379:                               ; %cond.load872
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v2 }[1], [x14]
	add.2d	v6, v12, v5
	tbz	w13, #2, LBB1_341
LBB1_380:                               ; %cond.load878
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d6
	ld1.s	{ v2 }[2], [x14]
	tbz	w13, #3, LBB1_342
LBB1_381:                               ; %cond.load884
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v2 }[3], [x14]
	add.2d	v6, v28, v5
	tbz	w13, #4, LBB1_343
LBB1_382:                               ; %cond.load890
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d6
	ld1.s	{ v3 }[0], [x14]
	tbz	w13, #5, LBB1_344
LBB1_383:                               ; %cond.load896
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v3 }[1], [x14]
	add.2d	v5, v7, v5
	tbz	w13, #6, LBB1_345
LBB1_384:                               ; %cond.load902
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d5
	ld1.s	{ v3 }[2], [x14]
	tbnz	w13, #7, LBB1_346
	b	LBB1_347
LBB1_385:                               ; %cond.load915
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d17
	ldr	s5, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_349
LBB1_386:                               ; %cond.load921
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[1], [x14]
	add.2d	v17, v12, v16
	tbz	w13, #2, LBB1_350
LBB1_387:                               ; %cond.load927
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d17
	ld1.s	{ v5 }[2], [x14]
	tbz	w13, #3, LBB1_351
LBB1_388:                               ; %cond.load933
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[3], [x14]
	add.2d	v17, v28, v16
	tbz	w13, #4, LBB1_352
LBB1_389:                               ; %cond.load939
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d17
	ld1.s	{ v6 }[0], [x14]
	tbz	w13, #5, LBB1_353
LBB1_390:                               ; %cond.load945
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v6 }[1], [x14]
	add.2d	v16, v7, v16
	tbz	w13, #6, LBB1_354
LBB1_391:                               ; %cond.load951
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d16
	ld1.s	{ v6 }[2], [x14]
	tbnz	w13, #7, LBB1_355
	b	LBB1_356
LBB1_392:                               ; %cond.load964
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d29
	ldr	s16, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_358
LBB1_393:                               ; %cond.load970
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v16 }[1], [x14]
	add.2d	v29, v12, v8
	tbz	w13, #2, LBB1_359
LBB1_394:                               ; %cond.load976
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d29
	ld1.s	{ v16 }[2], [x14]
	tbz	w13, #3, LBB1_360
LBB1_395:                               ; %cond.load982
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v16 }[3], [x14]
	add.2d	v29, v28, v8
	tbz	w13, #4, LBB1_361
LBB1_396:                               ; %cond.load988
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d29
	ld1.s	{ v17 }[0], [x14]
	tbz	w13, #5, LBB1_362
LBB1_397:                               ; %cond.load994
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v17 }[1], [x14]
	add.2d	v29, v7, v8
	tbz	w13, #6, LBB1_363
LBB1_398:                               ; %cond.load1000
                                        ;   in Loop: Header=BB1_320 Depth=3
	fmov	x14, d29
	ld1.s	{ v17 }[2], [x14]
	tbz	w13, #7, LBB1_319
LBB1_399:                               ; %cond.load1006
                                        ;   in Loop: Header=BB1_320 Depth=3
	mov.d	x13, v29[1]
	ld1.s	{ v17 }[3], [x13]
	b	LBB1_319
LBB1_400:                               ; %direct.false264.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	str	q11, [sp, #2016]                ; 16-byte Spill
	str	q17, [sp, #2960]                ; 16-byte Spill
	ldr	q1, [sp, #2832]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2832]                 ; 16-byte Spill
	ldr	q1, [sp, #2848]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2848]                 ; 16-byte Spill
	ldr	q1, [sp, #2864]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2864]                 ; 16-byte Spill
	ldr	q1, [sp, #2880]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2880]                 ; 16-byte Spill
	ldr	q1, [sp, #2896]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2896]                 ; 16-byte Spill
	ldr	q1, [sp, #2912]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2912]                 ; 16-byte Spill
	ldr	q1, [sp, #2928]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #2928]                 ; 16-byte Spill
	mov	w9, #3840                       ; =0xf00
	ldr	q1, [sp, #2944]                 ; 16-byte Reload
	bic.16b	v1, v1, v15
	str	q1, [sp, #2944]                 ; 16-byte Spill
	ldr	q10, [sp, #2224]                ; 16-byte Reload
	b	LBB1_402
LBB1_401:                               ; %else1255
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmul.4s	v29, v31, v14
	fmul.4s	v8, v1, v9
	ldr	q18, [sp, #2848]                ; 16-byte Reload
	fadd.4s	v8, v18, v8
	ldr	q28, [sp, #2832]                ; 16-byte Reload
	fadd.4s	v29, v28, v29
	fmul.4s	v3, v31, v3
	fmul.4s	v2, v1, v2
	ldr	q4, [sp, #2880]                 ; 16-byte Reload
	fadd.4s	v2, v4, v2
	ldr	q7, [sp, #2864]                 ; 16-byte Reload
	fadd.4s	v3, v7, v3
	fmul.4s	v6, v31, v6
	fmul.4s	v5, v1, v5
	ldr	q9, [sp, #2912]                 ; 16-byte Reload
	fadd.4s	v5, v9, v5
	ldr	q14, [sp, #2896]                ; 16-byte Reload
	fadd.4s	v6, v14, v6
	fmul.4s	v1, v1, v16
	fmul.4s	v16, v31, v17
	ldr	q31, [sp, #2928]                ; 16-byte Reload
	fadd.4s	v16, v31, v16
	ldr	q17, [sp, #2944]                ; 16-byte Reload
	fadd.4s	v1, v17, v1
	bit.16b	v28, v29, v0
	str	q28, [sp, #2832]                ; 16-byte Spill
	bit.16b	v18, v8, v15
	str	q18, [sp, #2848]                ; 16-byte Spill
	bit.16b	v7, v3, v0
	str	q7, [sp, #2864]                 ; 16-byte Spill
	bit.16b	v4, v2, v15
	str	q4, [sp, #2880]                 ; 16-byte Spill
	bit.16b	v14, v6, v0
	str	q14, [sp, #2896]                ; 16-byte Spill
	bit.16b	v9, v5, v15
	str	q9, [sp, #2912]                 ; 16-byte Spill
	bit.16b	v17, v1, v15
	str	q17, [sp, #2944]                ; 16-byte Spill
	add	x9, x9, #4
	bit.16b	v31, v16, v0
	str	q31, [sp, #2928]                ; 16-byte Spill
	cmp	x9, x27
	ldr	q4, [sp, #3008]                 ; 16-byte Reload
	b.eq	LBB1_482
LBB1_402:                               ; %direct.true291.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	w13, s19
	sub	x14, x9, #3840
	dup.2d	v2, x14
	ldr	q1, [sp, #3072]                 ; 16-byte Reload
	add.2d	v3, v1, v2
	movi.2d	v1, #0000000000000000
	movi.2d	v31, #0000000000000000
	tbnz	w13, #0, LBB1_445
; %bb.403:                              ; %else1017
                                        ;   in Loop: Header=BB1_402 Depth=3
	and	w13, w13, #0xff
	ldr	q7, [sp, #2992]                 ; 16-byte Reload
	tbnz	w13, #1, LBB1_446
LBB1_404:                               ; %else1023
                                        ;   in Loop: Header=BB1_402 Depth=3
	ldr	q3, [sp, #3056]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbnz	w13, #2, LBB1_447
LBB1_405:                               ; %else1029
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbnz	w13, #3, LBB1_448
LBB1_406:                               ; %else1035
                                        ;   in Loop: Header=BB1_402 Depth=3
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbnz	w13, #4, LBB1_449
LBB1_407:                               ; %else1041
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbnz	w13, #5, LBB1_450
LBB1_408:                               ; %else1047
                                        ;   in Loop: Header=BB1_402 Depth=3
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w13, #6, LBB1_451
LBB1_409:                               ; %else1053
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbnz	w13, #7, LBB1_452
LBB1_410:                               ; %else1059
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	w13, s19
	dup.2d	v2, x9
	add.2d	v3, v4, v2
	movi.2d	v9, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbnz	w13, #0, LBB1_453
LBB1_411:                               ; %else1066
                                        ;   in Loop: Header=BB1_402 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_454
LBB1_412:                               ; %else1072
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v3, v12, v2
	tbnz	w13, #2, LBB1_455
LBB1_413:                               ; %else1078
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbnz	w13, #3, LBB1_456
LBB1_414:                               ; %else1084
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v3, v7, v2
	tbnz	w13, #4, LBB1_457
LBB1_415:                               ; %else1090
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbnz	w13, #5, LBB1_458
LBB1_416:                               ; %else1096
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v2, v10, v2
	tbnz	w13, #6, LBB1_459
LBB1_417:                               ; %else1102
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbz	w13, #7, LBB1_419
LBB1_418:                               ; %cond.load1104
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x13, v2[1]
	ld1.s	{ v14 }[3], [x13]
LBB1_419:                               ; %else1108
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	w13, s19
	add	x14, x9, #320
	dup.2d	v5, x14
	add.2d	v6, v4, v5
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w13, #0, LBB1_460
; %bb.420:                              ; %else1115
                                        ;   in Loop: Header=BB1_402 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_461
LBB1_421:                               ; %else1121
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v6, v12, v5
	tbnz	w13, #2, LBB1_462
LBB1_422:                               ; %else1127
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbnz	w13, #3, LBB1_463
LBB1_423:                               ; %else1133
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v6, v7, v5
	tbnz	w13, #4, LBB1_464
LBB1_424:                               ; %else1139
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbnz	w13, #5, LBB1_465
LBB1_425:                               ; %else1145
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v5, v10, v5
	tbnz	w13, #6, LBB1_466
LBB1_426:                               ; %else1151
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbz	w13, #7, LBB1_428
LBB1_427:                               ; %cond.load1153
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x13, v5[1]
	ld1.s	{ v3 }[3], [x13]
LBB1_428:                               ; %else1157
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	w13, s19
	add	x14, x9, #640
	dup.2d	v16, x14
	add.2d	v17, v4, v16
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w13, #0, LBB1_467
; %bb.429:                              ; %else1164
                                        ;   in Loop: Header=BB1_402 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_468
LBB1_430:                               ; %else1170
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v17, v12, v16
	tbnz	w13, #2, LBB1_469
LBB1_431:                               ; %else1176
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbnz	w13, #3, LBB1_470
LBB1_432:                               ; %else1182
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v17, v7, v16
	tbnz	w13, #4, LBB1_471
LBB1_433:                               ; %else1188
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbnz	w13, #5, LBB1_472
LBB1_434:                               ; %else1194
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v16, v10, v16
	tbnz	w13, #6, LBB1_473
LBB1_435:                               ; %else1200
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbz	w13, #7, LBB1_437
LBB1_436:                               ; %cond.load1202
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x13, v16[1]
	ld1.s	{ v6 }[3], [x13]
LBB1_437:                               ; %else1206
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	w13, s19
	add	x14, x9, #960
	dup.2d	v8, x14
	add.2d	v29, v4, v8
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w13, #0, LBB1_474
; %bb.438:                              ; %else1213
                                        ;   in Loop: Header=BB1_402 Depth=3
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB1_475
LBB1_439:                               ; %else1219
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v29, v12, v8
	tbnz	w13, #2, LBB1_476
LBB1_440:                               ; %else1225
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbnz	w13, #3, LBB1_477
LBB1_441:                               ; %else1231
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v29, v7, v8
	tbnz	w13, #4, LBB1_478
LBB1_442:                               ; %else1237
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbnz	w13, #5, LBB1_479
LBB1_443:                               ; %else1243
                                        ;   in Loop: Header=BB1_402 Depth=3
	add.2d	v29, v10, v8
	tbnz	w13, #6, LBB1_480
LBB1_444:                               ; %else1249
                                        ;   in Loop: Header=BB1_402 Depth=3
	tbz	w13, #7, LBB1_401
	b	LBB1_481
LBB1_445:                               ; %cond.load1013
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d3
	ldr	s1, [x14]
	and	w13, w13, #0xff
	ldr	q7, [sp, #2992]                 ; 16-byte Reload
	tbz	w13, #1, LBB1_404
LBB1_446:                               ; %cond.load1019
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v1 }[1], [x14]
	ldr	q3, [sp, #3056]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbz	w13, #2, LBB1_405
LBB1_447:                               ; %cond.load1025
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d3
	ld1.s	{ v1 }[2], [x14]
	tbz	w13, #3, LBB1_406
LBB1_448:                               ; %cond.load1031
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v1 }[3], [x14]
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	add.2d	v3, v3, v2
	tbz	w13, #4, LBB1_407
LBB1_449:                               ; %cond.load1037
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d3
	ld1.s	{ v31 }[0], [x14]
	tbz	w13, #5, LBB1_408
LBB1_450:                               ; %cond.load1043
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v31 }[1], [x14]
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w13, #6, LBB1_409
LBB1_451:                               ; %cond.load1049
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d2
	ld1.s	{ v31 }[2], [x14]
	tbz	w13, #7, LBB1_410
LBB1_452:                               ; %cond.load1055
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x13, v2[1]
	ld1.s	{ v31 }[3], [x13]
	fmov	w13, s19
	dup.2d	v2, x9
	add.2d	v3, v4, v2
	movi.2d	v9, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbz	w13, #0, LBB1_411
LBB1_453:                               ; %cond.load1062
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d3
	ldr	s9, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_412
LBB1_454:                               ; %cond.load1068
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v9 }[1], [x14]
	add.2d	v3, v12, v2
	tbz	w13, #2, LBB1_413
LBB1_455:                               ; %cond.load1074
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d3
	ld1.s	{ v9 }[2], [x14]
	tbz	w13, #3, LBB1_414
LBB1_456:                               ; %cond.load1080
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v9 }[3], [x14]
	add.2d	v3, v7, v2
	tbz	w13, #4, LBB1_415
LBB1_457:                               ; %cond.load1086
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d3
	ld1.s	{ v14 }[0], [x14]
	tbz	w13, #5, LBB1_416
LBB1_458:                               ; %cond.load1092
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v3[1]
	ld1.s	{ v14 }[1], [x14]
	add.2d	v2, v10, v2
	tbz	w13, #6, LBB1_417
LBB1_459:                               ; %cond.load1098
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d2
	ld1.s	{ v14 }[2], [x14]
	tbnz	w13, #7, LBB1_418
	b	LBB1_419
LBB1_460:                               ; %cond.load1111
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d6
	ldr	s2, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_421
LBB1_461:                               ; %cond.load1117
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v2 }[1], [x14]
	add.2d	v6, v12, v5
	tbz	w13, #2, LBB1_422
LBB1_462:                               ; %cond.load1123
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d6
	ld1.s	{ v2 }[2], [x14]
	tbz	w13, #3, LBB1_423
LBB1_463:                               ; %cond.load1129
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v2 }[3], [x14]
	add.2d	v6, v7, v5
	tbz	w13, #4, LBB1_424
LBB1_464:                               ; %cond.load1135
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d6
	ld1.s	{ v3 }[0], [x14]
	tbz	w13, #5, LBB1_425
LBB1_465:                               ; %cond.load1141
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v6[1]
	ld1.s	{ v3 }[1], [x14]
	add.2d	v5, v10, v5
	tbz	w13, #6, LBB1_426
LBB1_466:                               ; %cond.load1147
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d5
	ld1.s	{ v3 }[2], [x14]
	tbnz	w13, #7, LBB1_427
	b	LBB1_428
LBB1_467:                               ; %cond.load1160
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d17
	ldr	s5, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_430
LBB1_468:                               ; %cond.load1166
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[1], [x14]
	add.2d	v17, v12, v16
	tbz	w13, #2, LBB1_431
LBB1_469:                               ; %cond.load1172
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d17
	ld1.s	{ v5 }[2], [x14]
	tbz	w13, #3, LBB1_432
LBB1_470:                               ; %cond.load1178
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v5 }[3], [x14]
	add.2d	v17, v7, v16
	tbz	w13, #4, LBB1_433
LBB1_471:                               ; %cond.load1184
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d17
	ld1.s	{ v6 }[0], [x14]
	tbz	w13, #5, LBB1_434
LBB1_472:                               ; %cond.load1190
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v17[1]
	ld1.s	{ v6 }[1], [x14]
	add.2d	v16, v10, v16
	tbz	w13, #6, LBB1_435
LBB1_473:                               ; %cond.load1196
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d16
	ld1.s	{ v6 }[2], [x14]
	tbnz	w13, #7, LBB1_436
	b	LBB1_437
LBB1_474:                               ; %cond.load1209
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d29
	ldr	s16, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB1_439
LBB1_475:                               ; %cond.load1215
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v16 }[1], [x14]
	add.2d	v29, v12, v8
	tbz	w13, #2, LBB1_440
LBB1_476:                               ; %cond.load1221
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d29
	ld1.s	{ v16 }[2], [x14]
	tbz	w13, #3, LBB1_441
LBB1_477:                               ; %cond.load1227
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v16 }[3], [x14]
	add.2d	v29, v7, v8
	tbz	w13, #4, LBB1_442
LBB1_478:                               ; %cond.load1233
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d29
	ld1.s	{ v17 }[0], [x14]
	tbz	w13, #5, LBB1_443
LBB1_479:                               ; %cond.load1239
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x14, v29[1]
	ld1.s	{ v17 }[1], [x14]
	add.2d	v29, v10, v8
	tbz	w13, #6, LBB1_444
LBB1_480:                               ; %cond.load1245
                                        ;   in Loop: Header=BB1_402 Depth=3
	fmov	x14, d29
	ld1.s	{ v17 }[2], [x14]
	tbz	w13, #7, LBB1_401
LBB1_481:                               ; %cond.load1251
                                        ;   in Loop: Header=BB1_402 Depth=3
	mov.d	x13, v29[1]
	ld1.s	{ v17 }[3], [x13]
	b	LBB1_401
LBB1_482:                               ; %direct.false292.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	mov	w13, #63790                     ; =0xf92e
	movk	w13, #15844, lsl #16
	dup.4s	v6, w13
	ldr	q1, [sp, #2512]                 ; 16-byte Reload
	fmul.4s	v5, v1, v6
	ldr	q1, [sp, #2496]                 ; 16-byte Reload
	fmul.4s	v4, v1, v6
	add	x13, x8, x22
	ldp	q1, q2, [x13]
	ldr	q3, [sp, #2544]                 ; 16-byte Reload
	fmul.4s	v3, v3, v6
	cmp	x7, #128
	bit.16b	v2, v4, v0
	bit.16b	v1, v5, v15
	stp	q1, q2, [x13]
	cset	w13, lo
	dup.4h	v7, w13
	ldr	q1, [sp, #2528]                 ; 16-byte Reload
	fmul.4s	v2, v1, v6
	ldr	q1, [sp, #2576]                 ; 16-byte Reload
	fmul.4s	v31, v1, v6
	ldr	q1, [sp, #2560]                 ; 16-byte Reload
	fmul.4s	v29, v1, v6
	ldr	q1, [sp, #1952]                 ; 16-byte Reload
	fmul.4s	v13, v1, v6
	ldp	q16, q17, [x20]
	ldr	q18, [sp, #2592]                ; 16-byte Reload
	fmul.4s	v12, v18, v6
	ldr	q18, [sp, #2624]                ; 16-byte Reload
	fmul.4s	v9, v18, v6
	str	q2, [sp, #1680]                 ; 16-byte Spill
	bit.16b	v17, v2, v0
	bit.16b	v16, v3, v15
	stp	q16, q17, [x20]
	ldr	q16, [sp, #2608]                ; 16-byte Reload
	fmul.4s	v1, v16, v6
	ldr	q16, [sp, #2640]                ; 16-byte Reload
	fmul.4s	v16, v16, v6
	ldr	q17, [sp, #2656]                ; 16-byte Reload
	fmul.4s	v17, v17, v6
	ldp	q18, q19, [x30]
	ldr	q28, [sp, #2672]                ; 16-byte Reload
	fmul.4s	v28, v28, v6
	str	q29, [sp, #1584]                ; 16-byte Spill
	bit.16b	v19, v29, v0
	str	q31, [sp, #1568]                ; 16-byte Spill
	bit.16b	v18, v31, v15
	stp	q18, q19, [x30]
	ldr	q18, [sp, #2688]                ; 16-byte Reload
	fmul.4s	v18, v18, v6
	ldr	q19, [sp, #2704]                ; 16-byte Reload
	fmul.4s	v19, v19, v6
	ldr	q29, [sp, #2720]                ; 16-byte Reload
	fmul.4s	v29, v29, v6
	ldp	q8, q10, [x10]
	ldr	q31, [sp, #2736]                ; 16-byte Reload
	fmul.4s	v11, v31, v6
	str	q12, [sp, #1488]                ; 16-byte Spill
	bit.16b	v10, v12, v0
	str	q13, [sp, #1472]                ; 16-byte Spill
	bit.16b	v8, v13, v15
	stp	q8, q10, [x10]
	ldr	q31, [sp, #2752]                ; 16-byte Reload
	fmul.4s	v8, v31, v6
	ldr	q31, [sp, #2784]                ; 16-byte Reload
	fmul.4s	v10, v31, v6
	ldr	q31, [sp, #2768]                ; 16-byte Reload
	fmul.4s	v12, v31, v6
	ldp	q13, q15, [x11]
	ushll.4s	v7, v7, #0
	str	q1, [sp, #1392]                 ; 16-byte Spill
	bit.16b	v15, v1, v0
	ldr	q31, [sp, #1968]                ; 16-byte Reload
	str	q9, [sp, #1376]                 ; 16-byte Spill
	bit.16b	v13, v9, v31
	stp	q13, q15, [x11]
	ldr	q31, [sp, #1968]                ; 16-byte Reload
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	ldr	q15, [sp, #544]                 ; 16-byte Reload
	mov.16b	v1, v7
	bsl.16b	v1, v17, v15
	ldp	q17, q13, [x12]
	bif.16b	v16, v15, v7
	str	q16, [sp, #1280]                ; 16-byte Spill
	bif.16b	v16, v13, v0
	str	q1, [sp, #1296]                 ; 16-byte Spill
	bit.16b	v17, v1, v31
	stp	q17, q16, [x12]
	ldr	q16, [sp, #2816]                ; 16-byte Reload
	fmul.4s	v16, v16, v6
	ldr	q17, [sp, #2800]                ; 16-byte Reload
	fmul.4s	v17, v17, v6
	mov.16b	v1, v7
	bsl.16b	v1, v18, v15
	ldr	x14, [sp, #456]                 ; 8-byte Reload
	ldp	q18, q13, [x14]
	bif.16b	v28, v15, v7
	str	q28, [sp, #1184]                ; 16-byte Spill
	bif.16b	v28, v13, v0
	str	q1, [sp, #1200]                 ; 16-byte Spill
	bit.16b	v18, v1, v31
	stp	q18, q28, [x14]
	ldr	q18, [sp, #2960]                ; 16-byte Reload
	fmul.4s	v18, v18, v6
	ldr	q28, [sp, #2016]                ; 16-byte Reload
	fmul.4s	v28, v28, v6
	mov.16b	v1, v7
	bsl.16b	v1, v29, v15
	ldr	x14, [sp, #448]                 ; 8-byte Reload
	ldp	q29, q13, [x14]
	bif.16b	v19, v15, v7
	str	q19, [sp, #1088]                ; 16-byte Spill
	bif.16b	v19, v13, v0
	str	q1, [sp, #1104]                 ; 16-byte Spill
	bit.16b	v29, v1, v31
	stp	q29, q19, [x14]
	ldr	q19, [sp, #2848]                ; 16-byte Reload
	fmul.4s	v19, v19, v6
	ldr	q29, [sp, #2832]                ; 16-byte Reload
	fmul.4s	v29, v29, v6
	mov.16b	v1, v7
	bsl.16b	v1, v8, v15
	ldr	x14, [sp, #440]                 ; 8-byte Reload
	ldp	q8, q13, [x14]
	mov.16b	v9, v7
	bsl.16b	v9, v11, v15
	stp	q9, q1, [sp, #992]              ; 32-byte Folded Spill
	mov.16b	v11, v0
	bsl.16b	v11, v9, v13
	bit.16b	v8, v1, v31
	stp	q8, q11, [x14]
	ldr	q8, [sp, #2864]                 ; 16-byte Reload
	fmul.4s	v8, v8, v6
	ldr	q11, [sp, #2880]                ; 16-byte Reload
	fmul.4s	v11, v11, v6
	mov.16b	v1, v7
	bsl.16b	v1, v12, v15
	ldr	x14, [sp, #432]                 ; 8-byte Reload
	ldp	q13, q12, [x14]
	mov.16b	v9, v7
	bsl.16b	v9, v10, v15
	str	q9, [sp, #1024]                 ; 16-byte Spill
	mov.16b	v10, v31
	bsl.16b	v10, v9, v13
	str	q1, [sp, #1040]                 ; 16-byte Spill
	bit.16b	v12, v1, v0
	stp	q10, q12, [x14]
	mov.16b	v1, v7
	bsl.16b	v1, v17, v15
	mov.16b	v10, v7
	bsl.16b	v10, v16, v15
	bif.16b	v28, v15, v7
	ldr	x14, [sp, #424]                 ; 8-byte Reload
	ldp	q17, q16, [x14]
	mov.16b	v9, v7
	bsl.16b	v9, v18, v15
	str	q10, [sp, #1120]                ; 16-byte Spill
	bit.16b	v17, v10, v31
	str	q1, [sp, #1136]                 ; 16-byte Spill
	bit.16b	v16, v1, v0
	stp	q17, q16, [x14]
	mov.16b	v1, v7
	bsl.16b	v1, v29, v15
	mov.16b	v18, v7
	bsl.16b	v18, v19, v15
	ldr	x14, [sp, #416]                 ; 8-byte Reload
	ldp	q17, q16, [x14]
	str	q9, [sp, #1216]                 ; 16-byte Spill
	bit.16b	v17, v9, v31
	str	q28, [sp, #1232]                ; 16-byte Spill
	bit.16b	v16, v28, v0
	stp	q17, q16, [x14]
	ldr	x14, [sp, #408]                 ; 8-byte Reload
	ldp	q17, q16, [x14]
	str	q18, [sp, #1312]                ; 16-byte Spill
	bit.16b	v17, v18, v31
	str	q1, [sp, #1328]                 ; 16-byte Spill
	bit.16b	v16, v1, v0
	stp	q17, q16, [x14]
	ldr	q16, [sp, #2912]                ; 16-byte Reload
	fmul.4s	v16, v16, v6
	ldr	q17, [sp, #2896]                ; 16-byte Reload
	fmul.4s	v17, v17, v6
	ldr	q18, [sp, #2944]                ; 16-byte Reload
	fmul.4s	v18, v18, v6
	ldr	q19, [sp, #2928]                ; 16-byte Reload
	fmul.4s	v6, v19, v6
	mov.16b	v28, v7
	bsl.16b	v28, v11, v15
	mov.16b	v29, v7
	bsl.16b	v29, v8, v15
	bif.16b	v17, v15, v7
	mov.16b	v19, v7
	bsl.16b	v19, v16, v15
	mov.16b	v1, v7
	bsl.16b	v1, v6, v15
	mov.16b	v16, v7
	bsl.16b	v16, v18, v15
	ldr	x14, [sp, #400]                 ; 8-byte Reload
	ldp	q7, q6, [x14]
	str	q29, [sp, #1408]                ; 16-byte Spill
	bit.16b	v6, v29, v0
	str	q28, [sp, #1424]                ; 16-byte Spill
	bit.16b	v7, v28, v31
	stp	q7, q6, [x14]
	ldr	x14, [sp, #392]                 ; 8-byte Reload
	ldp	q6, q7, [x14]
	str	q19, [sp, #1504]                ; 16-byte Spill
	bit.16b	v6, v19, v31
	str	q17, [sp, #1520]                ; 16-byte Spill
	bit.16b	v7, v17, v0
	stp	q6, q7, [x14]
	ldr	x14, [sp, #384]                 ; 8-byte Reload
	ldp	q6, q7, [x14]
	str	q16, [sp, #1600]                ; 16-byte Spill
	bit.16b	v6, v16, v31
	str	q1, [sp, #1616]                 ; 16-byte Spill
	bit.16b	v7, v1, v0
	stp	q6, q7, [x14]
	mvni.4s	v6, #127, msl #16
	ldr	q17, [sp, #1840]                ; 16-byte Reload
	bit.16b	v17, v6, v0
	ldr	q16, [sp, #1856]                ; 16-byte Reload
	bit.16b	v16, v6, v31
	dup.8b	v6, w13
	str	d6, [sp, #1760]                 ; 8-byte Spill
LBB1_483:                               ; %direct.true416.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x13, x2, x9
	ldp	q6, q7, [x13]
	and.16b	v7, v0, v7
	and.16b	v6, v31, v6
	fmaxnm.4s	v6, v16, v6
	fmaxnm.4s	v7, v17, v7
	bit.16b	v17, v7, v0
	bit.16b	v16, v6, v31
	add	x9, x9, #32
	cmp	x9, #512
	b.ne	LBB1_483
; %bb.484:                              ; %direct.false417.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x13, #0                         ; =0x0
	str	q16, [sp, #1856]                ; 16-byte Spill
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	fmaxnm.4s	v14, v1, v16
	fsub.4s	v5, v5, v14
	ldp	q7, q6, [sp, #656]              ; 32-byte Folded Reload
	cmhi.4s	v10, v7, v6
	and.16b	v1, v10, v5
	mov	w9, #-1026555904                ; =0xc2d00000
	dup.4s	v28, w9
	mov	w9, #1120403456                 ; =0x42c80000
	dup.4s	v19, w9
	fcmge.4s	v5, v1, v28
	fcmge.4s	v6, v19, v1
	and.16b	v5, v5, v6
	str	q17, [sp, #1840]                ; 16-byte Spill
	ldr	q6, [sp, #2000]                 ; 16-byte Reload
	fmaxnm.4s	v6, v6, v17
	str	q6, [sp, #3024]                 ; 16-byte Spill
	fsub.4s	v4, v4, v6
	and.16b	v9, v0, v4
	fcmge.4s	v4, v9, v28
	fcmge.4s	v6, v19, v9
	and.16b	v4, v4, v6
	and.16b	v6, v4, v9
	mov	w9, #43579                      ; =0xaa3b
	movk	w9, #16312, lsl #16
	dup.4s	v31, w9
	fmul.4s	v4, v6, v31
	movi.4s	v16, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v7, v17
	bsl.16b	v7, v16, v4
	fadd.4s	v4, v4, v7
	fsub.4s	v4, v4, v7
	and.16b	v7, v5, v1
	fmul.4s	v5, v7, v31
	bif.16b	v16, v5, v17
	fadd.4s	v5, v5, v16
	fsub.4s	v5, v5, v16
	fcvtzs.4s	v4, v4
	mov	w9, #29184                      ; =0x7200
	movk	w9, #16177, lsl #16
	dup.4s	v11, w9
	scvtf.4s	v16, v4
	fmul.4s	v17, v16, v11
	fsub.4s	v6, v6, v17
	fcvtzs.4s	v5, v5
	scvtf.4s	v17, v5
	fmul.4s	v18, v17, v11
	fsub.4s	v7, v7, v18
	mov	w9, #48782                      ; =0xbe8e
	movk	w9, #13759, lsl #16
	dup.4s	v18, w9
	fmul.4s	v17, v17, v18
	fsub.4s	v17, v7, v17
	fmul.4s	v7, v16, v18
	fsub.4s	v6, v6, v7
	mov	w9, #11226                      ; =0x2bda
	movk	w9, #14672, lsl #16
	dup.4s	v13, w9
	fmul.4s	v7, v6, v13
	mov	w9, #38601                      ; =0x96c9
	movk	w9, #15030, lsl #16
	dup.4s	v15, w9
	fadd.4s	v7, v7, v15
	fmul.4s	v7, v6, v7
	mov	w9, #34982                      ; =0x88a6
	movk	w9, #15368, lsl #16
	dup.4s	v12, w9
	fadd.4s	v7, v7, v12
	str	q12, [sp, #2976]                ; 16-byte Spill
	fmul.4s	v7, v6, v7
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v2, w9
	fadd.4s	v7, v7, v2
	str	q2, [sp, #1936]                 ; 16-byte Spill
	fmul.4s	v16, v6, v7
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v7, w9
	fadd.4s	v16, v16, v7
	str	q7, [sp, #2224]                 ; 16-byte Spill
	fmul.4s	v16, v6, v16
	movi.4s	v29, #63, lsl #24
	fadd.4s	v16, v16, v29
	movi.4s	v8, #63, lsl #24
	fmul.4s	v29, v6, v6
	fmul.4s	v16, v29, v16
	fmul.4s	v29, v17, v13
	fadd.4s	v29, v29, v15
	fmul.4s	v29, v17, v29
	fadd.4s	v29, v29, v12
	fmul.4s	v29, v17, v29
	fadd.4s	v29, v29, v2
	fmul.4s	v29, v17, v29
	fadd.4s	v29, v29, v7
	fmul.4s	v29, v17, v29
	fadd.4s	v29, v29, v8
	fmul.4s	v8, v17, v17
	fmul.4s	v29, v8, v29
	fadd.4s	v17, v17, v29
	fadd.4s	v6, v6, v16
	fmov.4s	v12, #1.00000000
	fadd.4s	v16, v17, v12
	sshr.4s	v17, v5, #1
	shl.4s	v29, v17, #23
	add.4s	v29, v29, v12
	fmul.4s	v16, v16, v29
	fadd.4s	v6, v6, v12
	sshr.4s	v29, v4, #1
	shl.4s	v8, v29, #23
	add.4s	v8, v8, v12
	fmul.4s	v6, v6, v8
	sub.4s	v5, v5, v17
	sub.4s	v4, v4, v29
	shl.4s	v4, v4, #23
	add.4s	v4, v4, v12
	fmul.4s	v4, v6, v4
	shl.4s	v5, v5, #23
	add.4s	v5, v5, v12
	fmul.4s	v5, v16, v5
	str	q1, [sp, #1696]                 ; 16-byte Spill
	fcmgt.4s	v6, v28, v1
	bic.16b	v5, v5, v6
	str	q9, [sp, #1744]                 ; 16-byte Spill
	fcmgt.4s	v6, v28, v9
	bic.16b	v6, v4, v6
	fcmgt.4s	v16, v9, v19
	mvni.4s	v4, #127, msl #16
	fneg.4s	v7, v4
	bit.16b	v6, v7, v16
	str	q6, [sp, #1728]                 ; 16-byte Spill
	fcmgt.4s	v6, v1, v19
	mov.16b	v1, v6
	bsl.16b	v1, v7, v5
	str	q1, [sp, #1712]                 ; 16-byte Spill
	str	q14, [sp, #3040]                ; 16-byte Spill
	fsub.4s	v3, v3, v14
	and.16b	v4, v10, v3
	fcmge.4s	v3, v4, v28
	fcmge.4s	v5, v19, v4
	and.16b	v3, v3, v5
	ldr	q1, [sp, #3024]                 ; 16-byte Reload
	ldr	q2, [sp, #1680]                 ; 16-byte Reload
	fsub.4s	v2, v2, v1
	and.16b	v8, v0, v2
	fcmge.4s	v2, v8, v28
	fcmge.4s	v5, v19, v8
	and.16b	v2, v2, v5
	and.16b	v5, v2, v8
	str	q31, [sp, #2992]                ; 16-byte Spill
	fmul.4s	v2, v5, v31
	mvni.4s	v1, #128, lsl #24
	movi.4s	v16, #75, lsl #24
	mov.16b	v6, v1
	bsl.16b	v6, v16, v2
	fadd.4s	v2, v2, v6
	fsub.4s	v2, v2, v6
	and.16b	v3, v3, v4
	fmul.4s	v6, v3, v31
	bif.16b	v16, v6, v1
	fadd.4s	v6, v6, v16
	fsub.4s	v6, v6, v16
	fcvtzs.4s	v2, v2
	scvtf.4s	v16, v2
	str	q11, [sp, #3008]                ; 16-byte Spill
	fmul.4s	v17, v16, v11
	fsub.4s	v5, v5, v17
	fcvtzs.4s	v6, v6
	scvtf.4s	v17, v6
	fmul.4s	v29, v17, v11
	fsub.4s	v3, v3, v29
	fmul.4s	v17, v17, v18
	fsub.4s	v3, v3, v17
	fmul.4s	v16, v16, v18
	mov.16b	v31, v18
	fsub.4s	v5, v5, v16
	fmul.4s	v16, v5, v13
	mov.16b	v18, v15
	fadd.4s	v16, v16, v15
	fmul.4s	v16, v5, v16
	ldr	q29, [sp, #2976]                ; 16-byte Reload
	fadd.4s	v16, v16, v29
	fmul.4s	v16, v5, v16
	ldr	q9, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v16, v16, v9
	fmul.4s	v16, v5, v16
	ldr	q15, [sp, #2224]                ; 16-byte Reload
	fadd.4s	v16, v16, v15
	fmul.4s	v16, v5, v16
	movi.4s	v1, #63, lsl #24
	fadd.4s	v16, v16, v1
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fmul.4s	v17, v3, v13
	fadd.4s	v17, v17, v18
	fmul.4s	v17, v3, v17
	fadd.4s	v17, v17, v29
	fmul.4s	v17, v3, v17
	fadd.4s	v17, v17, v9
	fmul.4s	v17, v3, v17
	fadd.4s	v17, v17, v15
	fmul.4s	v17, v3, v17
	fadd.4s	v17, v17, v1
	fmul.4s	v29, v3, v3
	fmul.4s	v17, v29, v17
	fadd.4s	v3, v3, v17
	fadd.4s	v5, v5, v16
	fadd.4s	v3, v3, v12
	sshr.4s	v16, v6, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v3, v3, v17
	fadd.4s	v5, v5, v12
	sshr.4s	v17, v2, #1
	shl.4s	v29, v17, #23
	add.4s	v29, v29, v12
	fmul.4s	v5, v5, v29
	sub.4s	v6, v6, v16
	sub.4s	v2, v2, v17
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v5, v2
	shl.4s	v5, v6, #23
	add.4s	v5, v5, v12
	fmul.4s	v3, v3, v5
	str	q4, [sp, #1632]                 ; 16-byte Spill
	fcmgt.4s	v5, v28, v4
	bic.16b	v3, v3, v5
	str	q8, [sp, #1664]                 ; 16-byte Spill
	fcmgt.4s	v5, v28, v8
	bic.16b	v2, v2, v5
	fcmgt.4s	v5, v8, v19
	mov.16b	v1, v5
	bsl.16b	v1, v7, v2
	str	q1, [sp, #1680]                 ; 16-byte Spill
	fcmgt.4s	v2, v4, v19
	mov.16b	v1, v2
	bsl.16b	v1, v7, v3
	str	q1, [sp, #1648]                 ; 16-byte Spill
	mov.16b	v4, v7
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	fsub.4s	v2, v1, v14
	and.16b	v7, v10, v2
	fcmge.4s	v2, v7, v28
	fcmge.4s	v3, v19, v7
	and.16b	v2, v2, v3
	ldr	q11, [sp, #3024]                ; 16-byte Reload
	ldr	q1, [sp, #1584]                 ; 16-byte Reload
	fsub.4s	v3, v1, v11
	and.16b	v14, v0, v3
	fcmge.4s	v3, v14, v28
	fcmge.4s	v5, v19, v14
	and.16b	v3, v3, v5
	and.16b	v3, v3, v14
	ldr	q8, [sp, #2992]                 ; 16-byte Reload
	fmul.4s	v5, v3, v8
	mvni.4s	v1, #128, lsl #24
	movi.4s	v16, #75, lsl #24
	mov.16b	v6, v1
	bsl.16b	v6, v16, v5
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	and.16b	v6, v2, v7
	fmul.4s	v2, v6, v8
	bif.16b	v16, v2, v1
	fadd.4s	v2, v2, v16
	fsub.4s	v16, v2, v16
	fcvtzs.4s	v2, v5
	scvtf.4s	v5, v2
	ldr	q1, [sp, #3008]                 ; 16-byte Reload
	fmul.4s	v17, v5, v1
	fsub.4s	v3, v3, v17
	fcvtzs.4s	v16, v16
	scvtf.4s	v17, v16
	fmul.4s	v29, v17, v1
	fsub.4s	v6, v6, v29
	str	q31, [sp, #3072]                ; 16-byte Spill
	fmul.4s	v17, v17, v31
	fsub.4s	v6, v6, v17
	fmul.4s	v5, v5, v31
	fsub.4s	v3, v3, v5
	fmul.4s	v5, v3, v13
	fadd.4s	v5, v5, v18
	fmul.4s	v5, v3, v5
	ldr	q1, [sp, #2976]                 ; 16-byte Reload
	fadd.4s	v5, v5, v1
	fmul.4s	v5, v3, v5
	fadd.4s	v5, v5, v9
	fmul.4s	v5, v3, v5
	fadd.4s	v5, v5, v15
	fmul.4s	v5, v3, v5
	movi.4s	v29, #63, lsl #24
	fadd.4s	v5, v5, v29
	fmul.4s	v17, v3, v3
	fmul.4s	v5, v17, v5
	fmul.4s	v17, v6, v13
	fadd.4s	v17, v17, v18
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v1
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v9
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v15
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v29
	fmul.4s	v29, v6, v6
	fmul.4s	v17, v29, v17
	fadd.4s	v6, v6, v17
	fadd.4s	v3, v3, v5
	fadd.4s	v5, v6, v12
	sshr.4s	v6, v16, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v12
	fmul.4s	v5, v5, v17
	fadd.4s	v3, v3, v12
	sshr.4s	v17, v2, #1
	shl.4s	v29, v17, #23
	add.4s	v29, v29, v12
	fmul.4s	v3, v3, v29
	sub.4s	v6, v16, v6
	sub.4s	v2, v2, v17
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	shl.4s	v3, v6, #23
	add.4s	v3, v3, v12
	fmul.4s	v3, v5, v3
	str	q7, [sp, #1536]                 ; 16-byte Spill
	fcmgt.4s	v5, v28, v7
	bic.16b	v3, v3, v5
	str	q14, [sp, #1568]                ; 16-byte Spill
	fcmgt.4s	v5, v28, v14
	bic.16b	v2, v2, v5
	fcmgt.4s	v5, v14, v19
	str	q4, [sp, #3056]                 ; 16-byte Spill
	mov.16b	v1, v5
	bsl.16b	v1, v4, v2
	str	q1, [sp, #1584]                 ; 16-byte Spill
	fcmgt.4s	v2, v7, v19
	mov.16b	v1, v2
	bsl.16b	v1, v4, v3
	str	q1, [sp, #1552]                 ; 16-byte Spill
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	ldr	q31, [sp, #3040]                ; 16-byte Reload
	fsub.4s	v2, v1, v31
	and.16b	v29, v10, v2
	fcmge.4s	v2, v29, v28
	fcmge.4s	v3, v19, v29
	and.16b	v2, v2, v3
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v4, v0, v1
	fcmge.4s	v1, v4, v28
	fcmge.4s	v3, v19, v4
	and.16b	v1, v1, v3
	and.16b	v3, v1, v4
	fmul.4s	v1, v3, v8
	movi.4s	v6, #75, lsl #24
	mvni.4s	v7, #128, lsl #24
	mov.16b	v5, v7
	bsl.16b	v5, v6, v1
	fadd.4s	v1, v1, v5
	fsub.4s	v1, v1, v5
	and.16b	v2, v2, v29
	fmul.4s	v5, v2, v8
	bif.16b	v6, v5, v7
	fadd.4s	v5, v5, v6
	fsub.4s	v5, v5, v6
	fcvtzs.4s	v1, v1
	scvtf.4s	v6, v1
	ldr	q7, [sp, #3008]                 ; 16-byte Reload
	fmul.4s	v16, v6, v7
	fsub.4s	v3, v3, v16
	fcvtzs.4s	v5, v5
	scvtf.4s	v16, v5
	fmul.4s	v17, v16, v7
	fsub.4s	v2, v2, v17
	ldr	q7, [sp, #3072]                 ; 16-byte Reload
	fmul.4s	v16, v16, v7
	fsub.4s	v2, v2, v16
	fmul.4s	v6, v6, v7
	fsub.4s	v3, v3, v6
	fmul.4s	v6, v3, v13
	mov.16b	v17, v18
	str	q18, [sp, #688]                 ; 16-byte Spill
	fadd.4s	v6, v6, v18
	fmul.4s	v6, v3, v6
	ldr	q14, [sp, #2976]                ; 16-byte Reload
	fadd.4s	v6, v6, v14
	fmul.4s	v6, v3, v6
	fadd.4s	v6, v6, v9
	fmul.4s	v6, v3, v6
	mov.16b	v18, v15
	fadd.4s	v6, v6, v15
	fmul.4s	v6, v3, v6
	movi.4s	v7, #63, lsl #24
	fadd.4s	v6, v6, v7
	fmul.4s	v16, v3, v3
	fmul.4s	v6, v16, v6
	fmul.4s	v16, v2, v13
	fadd.4s	v16, v16, v17
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v14
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v9
	mov.16b	v15, v9
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v18
	mov.16b	v8, v18
	fmul.4s	v16, v2, v16
	fadd.4s	v16, v16, v7
	fmul.4s	v17, v2, v2
	fmul.4s	v16, v17, v16
	fadd.4s	v2, v2, v16
	fadd.4s	v3, v3, v6
	fadd.4s	v2, v2, v12
	sshr.4s	v6, v5, #1
	shl.4s	v16, v6, #23
	add.4s	v16, v16, v12
	fmul.4s	v2, v2, v16
	fadd.4s	v3, v3, v12
	sshr.4s	v16, v1, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v3, v3, v17
	sub.4s	v5, v5, v6
	sub.4s	v1, v1, v16
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v3, v1
	shl.4s	v3, v5, #23
	add.4s	v3, v3, v12
	fmul.4s	v2, v2, v3
	str	q29, [sp, #1440]                ; 16-byte Spill
	fcmgt.4s	v3, v28, v29
	bic.16b	v2, v2, v3
	str	q4, [sp, #1472]                 ; 16-byte Spill
	fcmgt.4s	v3, v28, v4
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v4, v19
	ldr	q4, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #1488]                 ; 16-byte Spill
	fcmgt.4s	v1, v29, v19
	bsl.16b	v1, v4, v2
	str	q1, [sp, #1456]                 ; 16-byte Spill
	ldr	q1, [sp, #1376]                 ; 16-byte Reload
	fsub.4s	v1, v1, v31
	and.16b	v4, v10, v1
	fcmge.4s	v1, v4, v28
	fcmge.4s	v2, v19, v4
	and.16b	v1, v1, v2
	ldr	q9, [sp, #3024]                 ; 16-byte Reload
	ldr	q2, [sp, #1392]                 ; 16-byte Reload
	fsub.4s	v2, v2, v9
	and.16b	v29, v0, v2
	fcmge.4s	v2, v29, v28
	fcmge.4s	v3, v19, v29
	and.16b	v2, v2, v3
	and.16b	v2, v2, v29
	ldr	q18, [sp, #2992]                ; 16-byte Reload
	fmul.4s	v3, v2, v18
	mvni.4s	v7, #128, lsl #24
	movi.4s	v16, #75, lsl #24
	mov.16b	v5, v7
	bsl.16b	v5, v16, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v5, v1, v4
	fmul.4s	v1, v5, v18
	mov.16b	v6, v7
	bsl.16b	v6, v16, v1
	fadd.4s	v1, v1, v6
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	ldr	q7, [sp, #3008]                 ; 16-byte Reload
	fmul.4s	v16, v3, v7
	fsub.4s	v2, v2, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v7
	fsub.4s	v5, v5, v17
	ldr	q7, [sp, #3072]                 ; 16-byte Reload
	fmul.4s	v16, v16, v7
	fsub.4s	v5, v5, v16
	fmul.4s	v3, v3, v7
	fsub.4s	v2, v2, v3
	fmul.4s	v3, v2, v13
	ldr	q11, [sp, #688]                 ; 16-byte Reload
	fadd.4s	v3, v3, v11
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v8
	fmul.4s	v3, v2, v3
	movi.4s	v7, #63, lsl #24
	fadd.4s	v3, v3, v7
	fmul.4s	v16, v2, v2
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v5, v13
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v14
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v15
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v7
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v5, v12
	sshr.4s	v5, v6, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v12
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v12
	sshr.4s	v16, v1, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v2, v2, v17
	sub.4s	v5, v6, v5
	sub.4s	v1, v1, v16
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v5, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	mov.16b	v5, v4
	str	q4, [sp, #1344]                 ; 16-byte Spill
	fcmgt.4s	v3, v28, v4
	bic.16b	v2, v2, v3
	str	q29, [sp, #1376]                ; 16-byte Spill
	fcmgt.4s	v3, v28, v29
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v29, v19
	ldr	q4, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #1392]                 ; 16-byte Spill
	fcmgt.4s	v1, v5, v19
	bsl.16b	v1, v4, v2
	str	q1, [sp, #1360]                 ; 16-byte Spill
	ldr	q1, [sp, #1280]                 ; 16-byte Reload
	fsub.4s	v1, v1, v9
	and.16b	v29, v0, v1
	fcmge.4s	v1, v29, v28
	fcmge.4s	v2, v19, v29
	and.16b	v1, v1, v2
	ldr	q31, [sp, #3040]                ; 16-byte Reload
	ldr	q2, [sp, #1296]                 ; 16-byte Reload
	fsub.4s	v2, v2, v31
	and.16b	v9, v10, v2
	fcmge.4s	v2, v9, v28
	fcmge.4s	v3, v19, v9
	and.16b	v2, v2, v3
	and.16b	v2, v2, v9
	fmul.4s	v3, v2, v18
	mvni.4s	v6, #128, lsl #24
	movi.4s	v16, #75, lsl #24
	mov.16b	v5, v6
	bsl.16b	v5, v16, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v5, v1, v29
	fmul.4s	v1, v5, v18
	bsl.16b	v6, v16, v1
	fadd.4s	v1, v1, v6
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	ldr	q4, [sp, #3008]                 ; 16-byte Reload
	fmul.4s	v16, v3, v4
	fsub.4s	v2, v2, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v4
	fsub.4s	v5, v5, v17
	ldr	q7, [sp, #3072]                 ; 16-byte Reload
	fmul.4s	v16, v16, v7
	fsub.4s	v5, v5, v16
	fmul.4s	v3, v3, v7
	fsub.4s	v2, v2, v3
	fmul.4s	v3, v2, v13
	fadd.4s	v3, v3, v11
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v8
	fmul.4s	v3, v2, v3
	movi.4s	v7, #63, lsl #24
	fadd.4s	v3, v3, v7
	fmul.4s	v16, v2, v2
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v5, v13
	fadd.4s	v16, v16, v11
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v14
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v15
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v7
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v5, v12
	sshr.4s	v5, v6, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v12
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v12
	sshr.4s	v16, v1, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v2, v2, v17
	sub.4s	v5, v6, v5
	sub.4s	v1, v1, v16
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v5, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	str	q29, [sp, #1248]                ; 16-byte Spill
	fcmgt.4s	v3, v28, v29
	bic.16b	v2, v2, v3
	str	q9, [sp, #1280]                 ; 16-byte Spill
	fcmgt.4s	v3, v28, v9
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v9, v19
	ldr	q5, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v5, v3
	str	q1, [sp, #1296]                 ; 16-byte Spill
	fcmgt.4s	v1, v29, v19
	bsl.16b	v1, v5, v2
	str	q1, [sp, #1264]                 ; 16-byte Spill
	ldr	q1, [sp, #1184]                 ; 16-byte Reload
	ldr	q7, [sp, #3024]                 ; 16-byte Reload
	fsub.4s	v1, v1, v7
	and.16b	v29, v0, v1
	fcmge.4s	v1, v29, v28
	fcmge.4s	v2, v19, v29
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1200]                 ; 16-byte Reload
	fsub.4s	v2, v2, v31
	and.16b	v31, v10, v2
	fcmge.4s	v2, v31, v28
	fcmge.4s	v3, v19, v31
	and.16b	v2, v2, v3
	and.16b	v2, v2, v31
	fmul.4s	v3, v2, v18
	movi.4s	v6, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v5, v16
	bsl.16b	v5, v6, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v5, v1, v29
	fmul.4s	v1, v5, v18
	bif.16b	v6, v1, v16
	fadd.4s	v1, v1, v6
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	fmul.4s	v16, v3, v4
	fsub.4s	v2, v2, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v4
	mov.16b	v18, v4
	fsub.4s	v5, v5, v17
	ldr	q4, [sp, #3072]                 ; 16-byte Reload
	fmul.4s	v16, v16, v4
	fsub.4s	v5, v5, v16
	fmul.4s	v3, v3, v4
	fsub.4s	v2, v2, v3
	fmul.4s	v3, v2, v13
	fadd.4s	v3, v3, v11
	fmul.4s	v3, v2, v3
	mov.16b	v17, v14
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v8
	fmul.4s	v3, v2, v3
	movi.4s	v4, #63, lsl #24
	fadd.4s	v3, v3, v4
	fmul.4s	v16, v2, v2
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v5, v13
	fadd.4s	v16, v16, v11
	mov.16b	v14, v11
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v17
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v15
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v4
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v5, v12
	sshr.4s	v5, v6, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v12
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v12
	sshr.4s	v16, v1, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v2, v2, v17
	sub.4s	v5, v6, v5
	sub.4s	v1, v1, v16
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v5, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	str	q29, [sp, #1152]                ; 16-byte Spill
	fcmgt.4s	v3, v28, v29
	bic.16b	v2, v2, v3
	str	q31, [sp, #1184]                ; 16-byte Spill
	fcmgt.4s	v3, v28, v31
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v31, v19
	ldr	q4, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #1200]                 ; 16-byte Spill
	fcmgt.4s	v1, v29, v19
	bsl.16b	v1, v4, v2
	str	q1, [sp, #1168]                 ; 16-byte Spill
	mov.16b	v29, v7
	ldr	q1, [sp, #1088]                 ; 16-byte Reload
	fsub.4s	v1, v1, v7
	and.16b	v11, v0, v1
	fcmge.4s	v1, v11, v28
	fcmge.4s	v2, v19, v11
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1104]                 ; 16-byte Reload
	ldr	q7, [sp, #3040]                 ; 16-byte Reload
	fsub.4s	v2, v2, v7
	and.16b	v8, v10, v2
	fcmge.4s	v2, v8, v28
	fcmge.4s	v3, v19, v8
	and.16b	v2, v2, v3
	and.16b	v2, v2, v8
	ldr	q9, [sp, #2992]                 ; 16-byte Reload
	fmul.4s	v3, v2, v9
	movi.4s	v6, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v5, v16
	bsl.16b	v5, v6, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v5, v1, v11
	fmul.4s	v1, v5, v9
	bif.16b	v6, v1, v16
	fadd.4s	v1, v1, v6
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	fmul.4s	v16, v3, v18
	fsub.4s	v2, v2, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v18
	fsub.4s	v5, v5, v17
	ldr	q4, [sp, #3072]                 ; 16-byte Reload
	fmul.4s	v16, v16, v4
	fsub.4s	v5, v5, v16
	fmul.4s	v3, v3, v4
	fsub.4s	v2, v2, v3
	mov.16b	v31, v13
	fmul.4s	v3, v2, v13
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	ldr	q18, [sp, #2976]                ; 16-byte Reload
	fadd.4s	v3, v3, v18
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	ldr	q17, [sp, #2224]                ; 16-byte Reload
	fadd.4s	v3, v3, v17
	fmul.4s	v3, v2, v3
	movi.4s	v4, #63, lsl #24
	fadd.4s	v3, v3, v4
	fmul.4s	v16, v2, v2
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v5, v13
	fadd.4s	v16, v16, v14
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v18
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v15
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v17
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v4
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v5, v12
	sshr.4s	v5, v6, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v12
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v12
	sshr.4s	v16, v1, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v2, v2, v17
	sub.4s	v5, v6, v5
	sub.4s	v1, v1, v16
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v5, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	str	q11, [sp, #1056]                ; 16-byte Spill
	fcmgt.4s	v3, v28, v11
	bic.16b	v2, v2, v3
	str	q8, [sp, #1088]                 ; 16-byte Spill
	fcmgt.4s	v3, v28, v8
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v8, v19
	ldr	q4, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #1104]                 ; 16-byte Spill
	fcmgt.4s	v1, v11, v19
	bsl.16b	v1, v4, v2
	str	q1, [sp, #1072]                 ; 16-byte Spill
	mov.16b	v11, v4
	ldr	q1, [sp, #992]                  ; 16-byte Reload
	fsub.4s	v1, v1, v29
	and.16b	v29, v0, v1
	fcmge.4s	v1, v29, v28
	fcmge.4s	v2, v19, v29
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1008]                 ; 16-byte Reload
	fsub.4s	v2, v2, v7
	and.16b	v4, v10, v2
	fcmge.4s	v2, v4, v28
	fcmge.4s	v3, v19, v4
	and.16b	v2, v2, v3
	and.16b	v2, v2, v4
	fmul.4s	v3, v2, v9
	mvni.4s	v6, #128, lsl #24
	movi.4s	v16, #75, lsl #24
	mov.16b	v5, v6
	bsl.16b	v5, v16, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v5, v1, v29
	fmul.4s	v1, v5, v9
	mov.16b	v7, v9
	bsl.16b	v6, v16, v1
	fadd.4s	v1, v1, v6
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	ldr	q13, [sp, #3008]                ; 16-byte Reload
	fmul.4s	v16, v3, v13
	fsub.4s	v2, v2, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v13
	fsub.4s	v5, v5, v17
	ldr	q17, [sp, #3072]                ; 16-byte Reload
	fmul.4s	v16, v16, v17
	fsub.4s	v5, v5, v16
	fmul.4s	v3, v3, v17
	fsub.4s	v2, v2, v3
	fmul.4s	v3, v2, v31
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v18
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	ldr	q9, [sp, #2224]                 ; 16-byte Reload
	fadd.4s	v3, v3, v9
	fmul.4s	v3, v2, v3
	movi.4s	v17, #63, lsl #24
	fadd.4s	v3, v3, v17
	fmul.4s	v16, v2, v2
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v5, v31
	fadd.4s	v16, v16, v14
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v18
	mov.16b	v8, v18
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v15
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v9
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v17
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v5, v12
	sshr.4s	v5, v6, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v12
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v12
	sshr.4s	v16, v1, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v2, v2, v17
	sub.4s	v5, v6, v5
	sub.4s	v1, v1, v16
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v5, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	fcmgt.4s	v3, v28, v29
	bic.16b	v2, v2, v3
	fcmgt.4s	v3, v28, v4
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v4, v19
	bit.16b	v1, v11, v3
	stp	q4, q1, [sp, #992]              ; 32-byte Folded Spill
	fcmgt.4s	v1, v29, v19
	bsl.16b	v1, v11, v2
	stp	q29, q1, [sp, #960]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	ldr	q4, [sp, #3040]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v11, v10, v1
	fcmge.4s	v1, v11, v28
	fcmge.4s	v2, v19, v11
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1040]                 ; 16-byte Reload
	ldr	q18, [sp, #3024]                ; 16-byte Reload
	fsub.4s	v2, v2, v18
	and.16b	v29, v0, v2
	fcmge.4s	v2, v29, v28
	fcmge.4s	v3, v19, v29
	and.16b	v2, v2, v3
	and.16b	v2, v2, v29
	fmul.4s	v3, v2, v7
	movi.4s	v6, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v5, v16
	bsl.16b	v5, v6, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v5, v1, v11
	fmul.4s	v1, v5, v7
	bif.16b	v6, v1, v16
	fadd.4s	v1, v1, v6
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	fmul.4s	v16, v3, v13
	fsub.4s	v2, v2, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v13
	fsub.4s	v5, v5, v17
	ldr	q7, [sp, #3072]                 ; 16-byte Reload
	fmul.4s	v16, v16, v7
	fsub.4s	v5, v5, v16
	fmul.4s	v3, v3, v7
	fsub.4s	v2, v2, v3
	fmul.4s	v3, v2, v31
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v8
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v9
	fmul.4s	v3, v2, v3
	movi.4s	v17, #63, lsl #24
	fadd.4s	v3, v3, v17
	fmul.4s	v16, v2, v2
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v5, v31
	fadd.4s	v16, v16, v14
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v15
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v9
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v17
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v5, v12
	sshr.4s	v5, v6, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v12
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v12
	sshr.4s	v16, v1, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v2, v2, v17
	sub.4s	v5, v6, v5
	sub.4s	v1, v1, v16
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v5, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	fcmgt.4s	v3, v28, v11
	bic.16b	v2, v2, v3
	str	q29, [sp, #1024]                ; 16-byte Spill
	fcmgt.4s	v3, v28, v29
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v29, v19
	ldr	q5, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v5, v3
	str	q1, [sp, #1040]                 ; 16-byte Spill
	fcmgt.4s	v1, v11, v19
	bsl.16b	v1, v5, v2
	stp	q11, q1, [sp, #928]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v7, v10, v1
	fcmge.4s	v1, v7, v28
	fcmge.4s	v2, v19, v7
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1136]                 ; 16-byte Reload
	mov.16b	v29, v18
	fsub.4s	v2, v2, v18
	and.16b	v11, v0, v2
	fcmge.4s	v2, v11, v28
	fcmge.4s	v3, v19, v11
	and.16b	v2, v2, v3
	and.16b	v2, v2, v11
	ldr	q4, [sp, #2992]                 ; 16-byte Reload
	fmul.4s	v3, v2, v4
	movi.4s	v6, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v5, v16
	bsl.16b	v5, v6, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v5, v1, v7
	fmul.4s	v1, v5, v4
	bif.16b	v6, v1, v16
	fadd.4s	v1, v1, v6
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	mov.16b	v18, v13
	fmul.4s	v16, v3, v13
	fsub.4s	v2, v2, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v13
	fsub.4s	v5, v5, v17
	ldr	q17, [sp, #3072]                ; 16-byte Reload
	fmul.4s	v16, v16, v17
	fsub.4s	v5, v5, v16
	fmul.4s	v3, v3, v17
	fsub.4s	v2, v2, v3
	fmul.4s	v3, v2, v31
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v8
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	mov.16b	v13, v9
	fadd.4s	v3, v3, v9
	fmul.4s	v3, v2, v3
	movi.4s	v17, #63, lsl #24
	fadd.4s	v3, v3, v17
	fmul.4s	v16, v2, v2
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v5, v31
	mov.16b	v9, v31
	fadd.4s	v16, v16, v14
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v15
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v13
	mov.16b	v31, v13
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v17
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v5, v12
	sshr.4s	v5, v6, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v12
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v12
	sshr.4s	v16, v1, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v2, v2, v17
	sub.4s	v5, v6, v5
	sub.4s	v1, v1, v16
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v5, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	fcmgt.4s	v3, v28, v7
	bic.16b	v2, v2, v3
	str	q11, [sp, #1120]                ; 16-byte Spill
	fcmgt.4s	v3, v28, v11
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v11, v19
	ldr	q5, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v5, v3
	str	q1, [sp, #1136]                 ; 16-byte Spill
	fcmgt.4s	v1, v7, v19
	bsl.16b	v1, v5, v2
	stp	q7, q1, [sp, #896]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	ldr	q11, [sp, #3040]                ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v7, v10, v1
	fcmge.4s	v1, v7, v28
	fcmge.4s	v2, v19, v7
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1232]                 ; 16-byte Reload
	fsub.4s	v2, v2, v29
	and.16b	v29, v0, v2
	fcmge.4s	v2, v29, v28
	fcmge.4s	v3, v19, v29
	and.16b	v2, v2, v3
	and.16b	v2, v2, v29
	fmul.4s	v3, v2, v4
	mvni.4s	v6, #128, lsl #24
	movi.4s	v16, #75, lsl #24
	mov.16b	v5, v6
	bsl.16b	v5, v16, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v5, v1, v7
	fmul.4s	v1, v5, v4
	bsl.16b	v6, v16, v1
	fadd.4s	v1, v1, v6
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	fmul.4s	v16, v3, v18
	fsub.4s	v2, v2, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v18
	fsub.4s	v5, v5, v17
	ldr	q4, [sp, #3072]                 ; 16-byte Reload
	fmul.4s	v16, v16, v4
	fsub.4s	v5, v5, v16
	fmul.4s	v3, v3, v4
	fsub.4s	v2, v2, v3
	fmul.4s	v3, v2, v9
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v8
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v15
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v13
	fmul.4s	v3, v2, v3
	movi.4s	v4, #63, lsl #24
	fadd.4s	v3, v3, v4
	fmul.4s	v16, v2, v2
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v5, v9
	fadd.4s	v16, v16, v14
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v15
	mov.16b	v18, v15
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v13
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v4
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v5, v12
	sshr.4s	v5, v6, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v12
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v12
	sshr.4s	v16, v1, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v2, v2, v17
	sub.4s	v5, v6, v5
	sub.4s	v1, v1, v16
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v5, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	fcmgt.4s	v3, v28, v7
	bic.16b	v2, v2, v3
	str	q29, [sp, #1216]                ; 16-byte Spill
	fcmgt.4s	v3, v28, v29
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v29, v19
	ldr	q4, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #1232]                 ; 16-byte Spill
	fcmgt.4s	v1, v7, v19
	bsl.16b	v1, v4, v2
	stp	q7, q1, [sp, #864]              ; 32-byte Folded Spill
	ldr	q1, [sp, #1312]                 ; 16-byte Reload
	fsub.4s	v1, v1, v11
	and.16b	v11, v10, v1
	fcmge.4s	v1, v11, v28
	fcmge.4s	v2, v19, v11
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1328]                 ; 16-byte Reload
	ldr	q15, [sp, #3024]                ; 16-byte Reload
	fsub.4s	v2, v2, v15
	and.16b	v29, v0, v2
	fcmge.4s	v2, v29, v28
	fcmge.4s	v3, v19, v29
	and.16b	v2, v2, v3
	and.16b	v2, v2, v29
	ldr	q4, [sp, #2992]                 ; 16-byte Reload
	fmul.4s	v3, v2, v4
	mvni.4s	v6, #128, lsl #24
	movi.4s	v7, #75, lsl #24
	mov.16b	v5, v6
	bsl.16b	v5, v7, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v5, v1, v11
	fmul.4s	v1, v5, v4
	bsl.16b	v6, v7, v1
	fadd.4s	v1, v1, v6
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	ldr	q4, [sp, #3008]                 ; 16-byte Reload
	fmul.4s	v16, v3, v4
	fsub.4s	v2, v2, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v4
	fsub.4s	v5, v5, v17
	ldr	q13, [sp, #3072]                ; 16-byte Reload
	fmul.4s	v16, v16, v13
	fsub.4s	v5, v5, v16
	fmul.4s	v3, v3, v13
	fsub.4s	v2, v2, v3
	mov.16b	v4, v9
	fmul.4s	v3, v2, v9
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v8
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v18
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v3, v2, v3
	movi.4s	v7, #63, lsl #24
	fadd.4s	v3, v3, v7
	fmul.4s	v16, v2, v2
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v5, v9
	fadd.4s	v16, v16, v14
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v18
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v7
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v5, v12
	sshr.4s	v5, v6, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v12
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v12
	sshr.4s	v16, v1, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v2, v2, v17
	sub.4s	v5, v6, v5
	sub.4s	v1, v1, v16
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v5, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	fcmgt.4s	v3, v28, v11
	bic.16b	v2, v2, v3
	str	q29, [sp, #1312]                ; 16-byte Spill
	fcmgt.4s	v3, v28, v29
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v29, v19
	ldr	q5, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v5, v3
	str	q1, [sp, #1328]                 ; 16-byte Spill
	fcmgt.4s	v1, v11, v19
	bsl.16b	v1, v5, v2
	stp	q11, q1, [sp, #832]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1408]                 ; 16-byte Reload
	fsub.4s	v1, v1, v15
	and.16b	v29, v0, v1
	fcmge.4s	v1, v29, v28
	fcmge.4s	v2, v19, v29
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1424]                 ; 16-byte Reload
	ldr	q9, [sp, #3040]                 ; 16-byte Reload
	fsub.4s	v2, v2, v9
	and.16b	v7, v10, v2
	fcmge.4s	v2, v7, v28
	fcmge.4s	v3, v19, v7
	and.16b	v2, v2, v3
	and.16b	v2, v2, v7
	ldr	q17, [sp, #2992]                ; 16-byte Reload
	fmul.4s	v3, v2, v17
	movi.4s	v6, #75, lsl #24
	mvni.4s	v16, #128, lsl #24
	mov.16b	v5, v16
	bsl.16b	v5, v6, v3
	fadd.4s	v3, v3, v5
	fsub.4s	v3, v3, v5
	and.16b	v5, v1, v29
	fmul.4s	v1, v5, v17
	bif.16b	v6, v1, v16
	fadd.4s	v1, v1, v6
	fsub.4s	v6, v1, v6
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	ldr	q11, [sp, #3008]                ; 16-byte Reload
	fmul.4s	v16, v3, v11
	fsub.4s	v2, v2, v16
	fcvtzs.4s	v6, v6
	scvtf.4s	v16, v6
	fmul.4s	v17, v16, v11
	fsub.4s	v5, v5, v17
	fmul.4s	v16, v16, v13
	fsub.4s	v5, v5, v16
	fmul.4s	v3, v3, v13
	fsub.4s	v2, v2, v3
	mov.16b	v13, v4
	fmul.4s	v3, v2, v4
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v8
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v18
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v3, v2, v3
	movi.4s	v17, #63, lsl #24
	fadd.4s	v3, v3, v17
	fmul.4s	v16, v2, v2
	fmul.4s	v3, v16, v3
	fmul.4s	v16, v5, v4
	fadd.4s	v16, v16, v14
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v8
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v18
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v31
	fmul.4s	v16, v5, v16
	fadd.4s	v16, v16, v17
	fmul.4s	v17, v5, v5
	fmul.4s	v16, v17, v16
	fadd.4s	v5, v5, v16
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v5, v12
	sshr.4s	v5, v6, #1
	shl.4s	v16, v5, #23
	add.4s	v16, v16, v12
	fmul.4s	v3, v3, v16
	fadd.4s	v2, v2, v12
	sshr.4s	v16, v1, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v12
	fmul.4s	v2, v2, v17
	sub.4s	v5, v6, v5
	sub.4s	v1, v1, v16
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v5, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	fcmgt.4s	v3, v28, v29
	bic.16b	v2, v2, v3
	str	q7, [sp, #1408]                 ; 16-byte Spill
	fcmgt.4s	v3, v28, v7
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v7, v19
	ldr	q4, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #1424]                 ; 16-byte Spill
	fcmgt.4s	v1, v29, v19
	bsl.16b	v1, v4, v2
	stp	q29, q1, [sp, #800]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	fsub.4s	v1, v1, v9
	mov.16b	v4, v9
	and.16b	v7, v10, v1
	fcmge.4s	v1, v7, v28
	fcmge.4s	v2, v19, v7
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1520]                 ; 16-byte Reload
	fsub.4s	v2, v2, v15
	and.16b	v5, v0, v2
	fcmge.4s	v2, v5, v28
	fcmge.4s	v3, v19, v5
	and.16b	v2, v2, v3
	and.16b	v2, v2, v5
	ldr	q16, [sp, #2992]                ; 16-byte Reload
	fmul.4s	v3, v2, v16
	mvni.4s	v17, #128, lsl #24
	movi.4s	v29, #75, lsl #24
	mov.16b	v6, v17
	bsl.16b	v6, v29, v3
	fadd.4s	v3, v3, v6
	fsub.4s	v3, v3, v6
	and.16b	v6, v1, v7
	fmul.4s	v1, v6, v16
	mov.16b	v16, v17
	bsl.16b	v16, v29, v1
	fadd.4s	v1, v1, v16
	fsub.4s	v16, v1, v16
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	fmul.4s	v17, v3, v11
	fsub.4s	v2, v2, v17
	fcvtzs.4s	v16, v16
	scvtf.4s	v17, v16
	fmul.4s	v29, v17, v11
	fsub.4s	v6, v6, v29
	ldr	q29, [sp, #3072]                ; 16-byte Reload
	fmul.4s	v17, v17, v29
	fsub.4s	v6, v6, v17
	fmul.4s	v3, v3, v29
	fsub.4s	v2, v2, v3
	fmul.4s	v3, v2, v13
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v8
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v18
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v31
	fmul.4s	v3, v2, v3
	movi.4s	v29, #63, lsl #24
	fadd.4s	v3, v3, v29
	fmul.4s	v17, v2, v2
	fmul.4s	v3, v17, v3
	fmul.4s	v17, v6, v13
	fadd.4s	v17, v17, v14
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v8
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v18
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v31
	mov.16b	v9, v31
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v29
	fmul.4s	v29, v6, v6
	fmul.4s	v17, v29, v17
	fadd.4s	v6, v6, v17
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v6, v12
	sshr.4s	v6, v16, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v12
	fmul.4s	v3, v3, v17
	fadd.4s	v2, v2, v12
	sshr.4s	v17, v1, #1
	shl.4s	v29, v17, #23
	add.4s	v29, v29, v12
	fmul.4s	v2, v2, v29
	sub.4s	v6, v16, v6
	sub.4s	v1, v1, v17
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v6, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	stp	q7, q5, [sp, #768]              ; 32-byte Folded Spill
	fcmgt.4s	v3, v28, v7
	bic.16b	v2, v2, v3
	fcmgt.4s	v3, v28, v5
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v5, v19
	ldr	q5, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v5, v3
	str	q1, [sp, #1504]                 ; 16-byte Spill
	fcmgt.4s	v1, v7, v19
	bsl.16b	v1, v5, v2
	str	q1, [sp, #1520]                 ; 16-byte Spill
	ldr	q1, [sp, #1600]                 ; 16-byte Reload
	fsub.4s	v1, v1, v4
	and.16b	v31, v10, v1
	fcmge.4s	v1, v31, v28
	fcmge.4s	v2, v19, v31
	and.16b	v1, v1, v2
	ldr	q2, [sp, #1616]                 ; 16-byte Reload
	fsub.4s	v2, v2, v15
	and.16b	v4, v0, v2
	fcmge.4s	v2, v4, v28
	fcmge.4s	v3, v19, v4
	and.16b	v2, v2, v3
	and.16b	v2, v2, v4
	ldr	q15, [sp, #2992]                ; 16-byte Reload
	fmul.4s	v3, v2, v15
	mvni.4s	v5, #128, lsl #24
	movi.4s	v7, #75, lsl #24
	mov.16b	v6, v5
	bsl.16b	v6, v7, v3
	fadd.4s	v3, v3, v6
	fsub.4s	v3, v3, v6
	and.16b	v6, v1, v31
	fmul.4s	v1, v6, v15
	mov.16b	v16, v5
	bsl.16b	v16, v7, v1
	fadd.4s	v1, v1, v16
	fsub.4s	v16, v1, v16
	fcvtzs.4s	v1, v3
	scvtf.4s	v3, v1
	fmul.4s	v17, v3, v11
	fsub.4s	v2, v2, v17
	fcvtzs.4s	v16, v16
	scvtf.4s	v17, v16
	fmul.4s	v29, v17, v11
	fsub.4s	v6, v6, v29
	ldr	q5, [sp, #3072]                 ; 16-byte Reload
	fmul.4s	v17, v17, v5
	fsub.4s	v6, v6, v17
	fmul.4s	v3, v3, v5
	fsub.4s	v2, v2, v3
	fmul.4s	v3, v2, v13
	mov.16b	v7, v14
	fadd.4s	v3, v3, v14
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v8
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v18
	fmul.4s	v3, v2, v3
	fadd.4s	v3, v3, v9
	fmul.4s	v3, v2, v3
	movi.4s	v5, #63, lsl #24
	fadd.4s	v3, v3, v5
	fmul.4s	v17, v2, v2
	fmul.4s	v3, v17, v3
	fmul.4s	v17, v6, v13
	mov.16b	v14, v13
	fadd.4s	v17, v17, v7
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v8
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v18
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v9
	mov.16b	v13, v9
	fmul.4s	v17, v6, v17
	fadd.4s	v17, v17, v5
	fmul.4s	v29, v6, v6
	fmul.4s	v17, v29, v17
	fadd.4s	v6, v6, v17
	fadd.4s	v2, v2, v3
	fadd.4s	v3, v6, v12
	sshr.4s	v6, v16, #1
	shl.4s	v17, v6, #23
	add.4s	v17, v17, v12
	fmul.4s	v3, v3, v17
	fadd.4s	v2, v2, v12
	sshr.4s	v17, v1, #1
	shl.4s	v29, v17, #23
	add.4s	v29, v29, v12
	fmul.4s	v2, v2, v29
	sub.4s	v6, v16, v6
	sub.4s	v1, v1, v17
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v2, v1
	shl.4s	v2, v6, #23
	add.4s	v2, v2, v12
	fmul.4s	v2, v3, v2
	fcmgt.4s	v3, v28, v31
	bic.16b	v2, v2, v3
	str	q4, [sp, #736]                  ; 16-byte Spill
	fcmgt.4s	v3, v28, v4
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v4, v19
	ldr	q4, [sp, #3056]                 ; 16-byte Reload
	bit.16b	v1, v4, v3
	str	q1, [sp, #752]                  ; 16-byte Spill
	fcmgt.4s	v1, v31, v19
	bsl.16b	v1, v4, v2
	stp	q31, q1, [sp, #704]             ; 32-byte Folded Spill
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	ldr	q2, [sp, #3040]                 ; 16-byte Reload
	fsub.4s	v1, v1, v2
	and.16b	v11, v10, v1
	fcmge.4s	v1, v11, v28
	fcmge.4s	v3, v19, v11
	and.16b	v1, v1, v3
	ldr	q2, [sp, #2000]                 ; 16-byte Reload
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	fsub.4s	v3, v2, v3
	and.16b	v9, v0, v3
	fcmge.4s	v6, v9, v28
	fcmge.4s	v16, v19, v9
	and.16b	v6, v6, v16
	and.16b	v6, v6, v9
	fmul.4s	v16, v6, v15
	movi.4s	v2, #75, lsl #24
	mvni.4s	v3, #128, lsl #24
	mov.16b	v17, v3
	bsl.16b	v17, v2, v16
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	and.16b	v1, v1, v11
	fmul.4s	v17, v1, v15
	mov.16b	v29, v3
	bsl.16b	v29, v2, v17
	fadd.4s	v17, v17, v29
	fsub.4s	v17, v17, v29
	fcvtzs.4s	v16, v16
	scvtf.4s	v29, v16
	ldr	q2, [sp, #3008]                 ; 16-byte Reload
	fmul.4s	v8, v29, v2
	fsub.4s	v6, v6, v8
	fcvtzs.4s	v17, v17
	scvtf.4s	v8, v17
	fmul.4s	v15, v8, v2
	fsub.4s	v1, v1, v15
	ldr	q2, [sp, #3072]                 ; 16-byte Reload
	fmul.4s	v29, v29, v2
	fmul.4s	v8, v8, v2
	fsub.4s	v1, v1, v8
	fsub.4s	v6, v6, v29
	fmul.4s	v29, v6, v14
	fmul.4s	v8, v1, v14
	fadd.4s	v8, v8, v7
	fadd.4s	v29, v29, v7
	fmul.4s	v29, v6, v29
	fmul.4s	v8, v1, v8
	ldr	q2, [sp, #2976]                 ; 16-byte Reload
	fadd.4s	v8, v8, v2
	fadd.4s	v29, v29, v2
	fmul.4s	v29, v6, v29
	fmul.4s	v8, v1, v8
	ldr	q2, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v8, v8, v2
	fadd.4s	v18, v29, v2
	fmul.4s	v18, v6, v18
	fmul.4s	v29, v1, v8
	fadd.4s	v29, v29, v13
	fadd.4s	v7, v18, v13
	fmul.4s	v7, v6, v7
	fadd.4s	v7, v7, v5
	fmul.4s	v18, v6, v6
	fmul.4s	v7, v18, v7
	fmul.4s	v18, v1, v29
	fadd.4s	v18, v18, v5
	fmul.4s	v29, v1, v1
	fmul.4s	v18, v29, v18
	fadd.4s	v1, v1, v18
	fadd.4s	v6, v6, v7
	fadd.4s	v1, v1, v12
	sshr.4s	v7, v17, #1
	shl.4s	v18, v7, #23
	add.4s	v18, v18, v12
	fmul.4s	v1, v1, v18
	fadd.4s	v6, v6, v12
	sshr.4s	v18, v16, #1
	shl.4s	v29, v18, #23
	add.4s	v29, v29, v12
	fmul.4s	v6, v6, v29
	sub.4s	v7, v17, v7
	sub.4s	v16, v16, v18
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v12
	fmul.4s	v6, v6, v16
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v12
	fmul.4s	v1, v1, v7
	fcmgt.4s	v7, v28, v11
	bic.16b	v1, v1, v7
	fcmgt.4s	v7, v28, v9
	bic.16b	v6, v6, v7
	fcmgt.4s	v7, v9, v19
	mov.16b	v2, v7
	bsl.16b	v2, v4, v6
	str	q2, [sp, #3072]                 ; 16-byte Spill
	fcmgt.4s	v6, v11, v19
	bit.16b	v1, v4, v6
	str	q1, [sp, #688]                  ; 16-byte Spill
	sshll.2d	v1, v0, #0
Lloh66:
	adrp	x9, lCPI1_8@PAGE
Lloh67:
	ldr	q4, [x9, lCPI1_8@PAGEOFF]
	ldr	q5, [sp, #1888]                 ; 16-byte Reload
	bit.16b	v5, v4, v1
	str	q5, [sp, #1888]                 ; 16-byte Spill
	ldr	q1, [sp, #1696]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q31, [sp, #240]                 ; 16-byte Reload
	ldr	q2, [sp, #1712]                 ; 16-byte Reload
	mov.16b	v5, v1
	bsl.16b	v5, v2, v31
	ldr	q1, [sp, #1744]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1728]                 ; 16-byte Reload
	mov.16b	v16, v1
	bsl.16b	v16, v2, v31
	ldr	q1, [sp, #1632]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1648]                 ; 16-byte Reload
	mov.16b	v19, v1
	bsl.16b	v19, v2, v31
	ldr	q1, [sp, #1664]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1680]                 ; 16-byte Reload
	mov.16b	v17, v1
	bsl.16b	v17, v2, v31
	ldr	q1, [sp, #1536]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1552]                 ; 16-byte Reload
	mov.16b	v14, v1
	bsl.16b	v14, v2, v31
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	mov.16b	v3, v1
	bsl.16b	v3, v2, v31
	ldr	q1, [sp, #1440]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1456]                 ; 16-byte Reload
	mov.16b	v28, v1
	bsl.16b	v28, v2, v31
	ldr	q1, [sp, #1472]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1488]                 ; 16-byte Reload
	mov.16b	v7, v1
	bsl.16b	v7, v2, v31
	ldr	q1, [sp, #1344]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1360]                 ; 16-byte Reload
	mov.16b	v29, v1
	bsl.16b	v29, v2, v31
	ldr	q1, [sp, #1376]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1392]                 ; 16-byte Reload
	mov.16b	v18, v1
	bsl.16b	v18, v2, v31
	ldr	q1, [sp, #1248]                 ; 16-byte Reload
	fcmeq.4s	v1, v1, v1
	ldr	q2, [sp, #1264]                 ; 16-byte Reload
	mov.16b	v8, v1
	bsl.16b	v8, v2, v31
	ldr	q1, [sp, #1280]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1296]                 ; 16-byte Reload
	mov.16b	v2, v4
	bsl.16b	v2, v1, v31
	ldr	q1, [sp, #1152]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1168]                 ; 16-byte Reload
	mov.16b	v15, v4
	bsl.16b	v15, v1, v31
	ldr	q1, [sp, #1184]                 ; 16-byte Reload
	fcmeq.4s	v4, v1, v1
	ldr	q1, [sp, #1200]                 ; 16-byte Reload
	bsl.16b	v4, v1, v31
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	fcmeq.4s	v6, v1, v1
	ldr	q1, [sp, #1072]                 ; 16-byte Reload
	mov.16b	v12, v6
	bsl.16b	v12, v1, v31
	ldr	q1, [sp, #1088]                 ; 16-byte Reload
	fcmeq.4s	v6, v1, v1
	ldr	q1, [sp, #1104]                 ; 16-byte Reload
	mov.16b	v13, v6
	bsl.16b	v13, v1, v31
	ldr	q1, [sp, #960]                  ; 16-byte Reload
	fcmeq.4s	v6, v1, v1
	ldr	q1, [sp, #976]                  ; 16-byte Reload
	bif.16b	v1, v31, v6
	str	q1, [sp, #1600]                 ; 16-byte Spill
	ldr	q1, [sp, #992]                  ; 16-byte Reload
	fcmeq.4s	v6, v1, v1
	ldr	q1, [sp, #1008]                 ; 16-byte Reload
	bif.16b	v1, v31, v6
	str	q1, [sp, #1584]                 ; 16-byte Spill
	ldr	q1, [sp, #928]                  ; 16-byte Reload
	fcmeq.4s	v6, v1, v1
	ldr	q1, [sp, #944]                  ; 16-byte Reload
	bif.16b	v1, v31, v6
	str	q1, [sp, #1568]                 ; 16-byte Spill
	mov	w9, #33792                      ; =0x8400
	movk	w9, #1, lsl #16
	add	x9, x8, x9
	ldr	q6, [x9, #16]
	str	q16, [sp, #3008]                ; 16-byte Spill
	bit.16b	v6, v16, v0
	ldr	q16, [x9]
	str	q5, [sp, #3056]                 ; 16-byte Spill
	bit.16b	v16, v5, v10
	stp	q16, q6, [x9]
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	fcmeq.4s	v6, v1, v1
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	bif.16b	v1, v31, v6
	str	q1, [sp, #1552]                 ; 16-byte Spill
	ldp	q5, q1, [sp, #896]              ; 32-byte Folded Reload
	fcmeq.4s	v6, v5, v5
	bif.16b	v1, v31, v6
	str	q1, [sp, #1536]                 ; 16-byte Spill
	ldr	x9, [sp, #376]                  ; 8-byte Reload
	ldr	q6, [x9, #16]
	str	q17, [sp, #2976]                ; 16-byte Spill
	bit.16b	v6, v17, v0
	ldr	q17, [x9]
	str	q19, [sp, #2992]                ; 16-byte Spill
	bit.16b	v17, v19, v10
	stp	q17, q6, [x9]
	ldr	q1, [sp, #1120]                 ; 16-byte Reload
	fcmeq.4s	v6, v1, v1
	ldr	q1, [sp, #1136]                 ; 16-byte Reload
	mov.16b	v16, v6
	bsl.16b	v16, v1, v31
	ldr	q1, [sp, #864]                  ; 16-byte Reload
	fcmeq.4s	v6, v1, v1
	ldr	q1, [sp, #880]                  ; 16-byte Reload
	mov.16b	v17, v6
	bsl.16b	v17, v1, v31
	ldr	q1, [sp, #1216]                 ; 16-byte Reload
	fcmeq.4s	v6, v1, v1
	ldr	q1, [sp, #1232]                 ; 16-byte Reload
	mov.16b	v19, v6
	bsl.16b	v19, v1, v31
	ldr	x9, [sp, #368]                  ; 8-byte Reload
	ldp	q5, q6, [x9]
	str	q3, [sp, #1936]                 ; 16-byte Spill
	bit.16b	v6, v3, v0
	str	q14, [sp, #2224]                ; 16-byte Spill
	bit.16b	v5, v14, v10
	stp	q5, q6, [x9]
	ldr	x9, [sp, #360]                  ; 8-byte Reload
	ldp	q6, q5, [x9]
	str	q7, [sp, #1728]                 ; 16-byte Spill
	bit.16b	v5, v7, v0
	str	q28, [sp, #1744]                ; 16-byte Spill
	bit.16b	v6, v28, v10
	stp	q6, q5, [x9]
	ldr	x9, [sp, #352]                  ; 8-byte Reload
	ldp	q6, q5, [x9]
	str	q18, [sp, #1696]                ; 16-byte Spill
	bit.16b	v5, v18, v0
	str	q29, [sp, #1712]                ; 16-byte Spill
	bit.16b	v6, v29, v10
	stp	q6, q5, [x9]
	ldr	d1, [sp, #1760]                 ; 8-byte Reload
	zip1.8b	v5, v1, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v6, v5, #0
	and.16b	v2, v6, v2
	zip2.8b	v5, v1, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v18, v5, #0
	and.16b	v3, v18, v8
	ldr	x9, [sp, #344]                  ; 8-byte Reload
	ldp	q5, q1, [x9]
	str	q3, [sp, #1680]                 ; 16-byte Spill
	bit.16b	v1, v3, v0
	str	q2, [sp, #1760]                 ; 16-byte Spill
	bit.16b	v5, v2, v10
	stp	q5, q1, [x9]
	ldp	q1, q2, [sp, #832]              ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v2, v31
	and.16b	v2, v6, v4
	and.16b	v3, v18, v15
	ldr	x9, [sp, #336]                  ; 8-byte Reload
	ldp	q5, q4, [x9]
	str	q3, [sp, #1648]                 ; 16-byte Spill
	bit.16b	v4, v3, v0
	str	q2, [sp, #1664]                 ; 16-byte Spill
	bit.16b	v5, v2, v10
	stp	q5, q4, [x9]
	ldr	q2, [sp, #1312]                 ; 16-byte Reload
	fcmeq.4s	v4, v2, v2
	ldr	q2, [sp, #1328]                 ; 16-byte Reload
	bsl.16b	v4, v2, v31
	and.16b	v2, v6, v13
	and.16b	v3, v18, v12
	ldr	x9, [sp, #328]                  ; 8-byte Reload
	ldp	q12, q5, [x9]
	str	q3, [sp, #1616]                 ; 16-byte Spill
	bit.16b	v5, v3, v0
	str	q2, [sp, #1632]                 ; 16-byte Spill
	bit.16b	v12, v2, v10
	stp	q12, q5, [x9]
	ldp	q3, q2, [sp, #800]              ; 32-byte Folded Reload
	fcmeq.4s	v5, v3, v3
	bsl.16b	v5, v2, v31
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	and.16b	v2, v6, v2
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	and.16b	v3, v18, v3
	ldr	x9, [sp, #320]                  ; 8-byte Reload
	ldp	q29, q28, [x9]
	str	q3, [sp, #1584]                 ; 16-byte Spill
	bit.16b	v28, v3, v0
	str	q2, [sp, #1600]                 ; 16-byte Spill
	bit.16b	v29, v2, v10
	stp	q29, q28, [x9]
	ldr	q2, [sp, #1408]                 ; 16-byte Reload
	fcmeq.4s	v28, v2, v2
	ldr	q2, [sp, #1424]                 ; 16-byte Reload
	bsl.16b	v28, v2, v31
	ldr	q2, [sp, #1552]                 ; 16-byte Reload
	and.16b	v2, v18, v2
	ldr	q3, [sp, #1568]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	ldr	x9, [sp, #312]                  ; 8-byte Reload
	ldp	q7, q29, [x9]
	str	q3, [sp, #1552]                 ; 16-byte Spill
	bit.16b	v7, v3, v10
	str	q2, [sp, #1568]                 ; 16-byte Spill
	bit.16b	v29, v2, v0
	stp	q7, q29, [x9]
	ldr	q2, [sp, #768]                  ; 16-byte Reload
	fcmeq.4s	v7, v2, v2
	ldr	q2, [sp, #1520]                 ; 16-byte Reload
	bsl.16b	v7, v2, v31
	and.16b	v3, v18, v16
	ldr	q2, [sp, #1536]                 ; 16-byte Reload
	and.16b	v2, v6, v2
	ldr	x9, [sp, #304]                  ; 8-byte Reload
	ldp	q16, q29, [x9]
	str	q2, [sp, #1536]                 ; 16-byte Spill
	bit.16b	v16, v2, v10
	str	q3, [sp, #1520]                 ; 16-byte Spill
	bit.16b	v29, v3, v0
	stp	q16, q29, [x9]
	ldr	q2, [sp, #784]                  ; 16-byte Reload
	fcmeq.4s	v16, v2, v2
	ldr	q2, [sp, #1504]                 ; 16-byte Reload
	bsl.16b	v16, v2, v31
	and.16b	v2, v18, v19
	and.16b	v3, v6, v17
	ldr	x9, [sp, #296]                  ; 8-byte Reload
	ldp	q17, q19, [x9]
	str	q3, [sp, #1488]                 ; 16-byte Spill
	bit.16b	v17, v3, v10
	str	q2, [sp, #1504]                 ; 16-byte Spill
	bit.16b	v19, v2, v0
	stp	q17, q19, [x9]
	ldp	q3, q2, [sp, #704]              ; 32-byte Folded Reload
	fcmeq.4s	v17, v3, v3
	bsl.16b	v17, v2, v31
	and.16b	v3, v18, v4
	and.16b	v2, v6, v1
	ldr	x9, [sp, #288]                  ; 8-byte Reload
	ldp	q1, q4, [x9]
	str	q2, [sp, #1472]                 ; 16-byte Spill
	bit.16b	v1, v2, v10
	str	q3, [sp, #1456]                 ; 16-byte Spill
	bit.16b	v4, v3, v0
	stp	q1, q4, [x9]
	ldp	q1, q2, [sp, #736]              ; 32-byte Folded Reload
	fcmeq.4s	v1, v1, v1
	bsl.16b	v1, v2, v31
	and.16b	v2, v6, v28
	and.16b	v3, v18, v5
	ldr	x9, [sp, #280]                  ; 8-byte Reload
	ldp	q5, q4, [x9]
	str	q3, [sp, #1424]                 ; 16-byte Spill
	bit.16b	v4, v3, v0
	str	q2, [sp, #1440]                 ; 16-byte Spill
	bit.16b	v5, v2, v10
	stp	q5, q4, [x9]
	and.16b	v3, v18, v16
	and.16b	v2, v18, v1
	and.16b	v4, v6, v7
	and.16b	v5, v6, v17
	ldr	x9, [sp, #272]                  ; 8-byte Reload
	ldr	q1, [x9]
	str	q4, [sp, #1376]                 ; 16-byte Spill
	bit.16b	v1, v4, v10
	ldr	q4, [x9, #16]
	str	q3, [sp, #1392]                 ; 16-byte Spill
	bit.16b	v4, v3, v0
	stp	q1, q4, [x9]
	ldr	x9, [sp, #264]                  ; 8-byte Reload
	ldp	q1, q4, [x9]
	str	q5, [sp, #1360]                 ; 16-byte Spill
	bit.16b	v1, v5, v10
	str	q2, [sp, #1408]                 ; 16-byte Spill
	bit.16b	v4, v2, v0
	stp	q1, q4, [x9]
	fcmeq.4s	v1, v11, v11
	ldr	q2, [sp, #688]                  ; 16-byte Reload
	mov.16b	v28, v1
	bsl.16b	v28, v2, v31
	fcmeq.4s	v1, v9, v9
	ldr	q2, [sp, #3072]                 ; 16-byte Reload
	mov.16b	v4, v1
	bsl.16b	v4, v2, v31
	sshll2.2d	v3, v10, #0
Lloh68:
	adrp	x9, lCPI1_7@PAGE
Lloh69:
	ldr	q1, [x9, lCPI1_7@PAGEOFF]
	ldr	q2, [sp, #1904]                 ; 16-byte Reload
	str	q3, [sp, #1344]                 ; 16-byte Spill
	bit.16b	v2, v1, v3
	str	q2, [sp, #1904]                 ; 16-byte Spill
Lloh70:
	adrp	x9, lCPI1_6@PAGE
Lloh71:
	ldr	q1, [x9, lCPI1_6@PAGEOFF]
	ldr	q2, [sp, #1920]                 ; 16-byte Reload
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	bit.16b	v3, v1, v2
	str	q3, [sp, #1872]                 ; 16-byte Spill
	sshll.2d	v1, v10, #0
	ldr	q2, [sp, #560]                  ; 16-byte Reload
	ldr	q13, [sp, #2304]                ; 16-byte Reload
	bit.16b	v13, v2, v1
	mov	w16, #12                        ; =0xc
	str	q13, [sp, #2304]                ; 16-byte Spill
	b	LBB1_486
LBB1_485:                               ; %direct.false586.i.i
                                        ;   in Loop: Header=BB1_486 Depth=3
	ldr	q13, [sp, #2304]                ; 16-byte Reload
	ldr	q1, [sp, #3072]                 ; 16-byte Reload
	orr.16b	v1, v1, v13
	fmov	x9, d1
	add	x9, x4, x9
	ldp	q1, q16, [x9]
	bit.16b	v16, v9, v0
	bit.16b	v1, v8, v10
	stp	q1, q16, [x9]
	orr.16b	v1, v31, v13
	fmov	x9, d1
	add	x9, x4, x9
	ldp	q1, q16, [x9]
	bit.16b	v16, v29, v0
	bit.16b	v1, v7, v10
	stp	q1, q16, [x9]
	orr.16b	v1, v11, v13
	fmov	x9, d1
	add	x9, x4, x9
	ldp	q1, q7, [x9]
	bif.16b	v6, v7, v0
	bit.16b	v1, v5, v10
	stp	q1, q6, [x9]
	orr.16b	v1, v12, v13
	fmov	x9, d1
	add	x9, x4, x9
	ldp	q1, q5, [x9]
	bif.16b	v3, v5, v0
	bit.16b	v1, v2, v10
	stp	q1, q3, [x9]
	add	x13, x13, #1
	add	x16, x16, #16
	cmp	x13, #24
	b.eq	LBB1_552
LBB1_486:                               ; %direct.true557.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Loop Header: Depth=3
                                        ;         Child Loop BB1_488 Depth 4
	mov	x14, #0                         ; =0x0
	lsl	x9, x13, #7
	dup.2d	v1, x9
	ldr	q16, [sp, #2208]                ; 16-byte Reload
	str	q1, [sp, #3072]                 ; 16-byte Spill
	orr.16b	v1, v1, v16
	fmov	x9, d1
	add	x9, x15, x9
	ldp	q2, q1, [x9]
	fmul.4s	v2, v28, v2
	fmul.4s	v1, v4, v1
	mov	w9, #32                         ; =0x20
	bfi	x9, x13, #7, #57
	dup.2d	v31, x9
	orr.16b	v3, v31, v16
	fmov	x9, d3
	add	x9, x15, x9
	ldp	q5, q3, [x9]
	fmul.4s	v5, v28, v5
	fmul.4s	v3, v4, v3
	mov	w9, #64                         ; =0x40
	bfi	x9, x13, #7, #57
	dup.2d	v11, x9
	orr.16b	v6, v11, v16
	fmov	x9, d6
	add	x9, x15, x9
	ldp	q7, q6, [x9]
	fmul.4s	v7, v28, v7
	fmul.4s	v6, v4, v6
	mov	w9, #96                         ; =0x60
	bfi	x9, x13, #7, #57
	dup.2d	v12, x9
	orr.16b	v16, v12, v16
	fmov	x9, d16
	add	x9, x15, x9
	ldp	q17, q16, [x9]
	fmul.4s	v17, v28, v17
	fmul.4s	v16, v4, v16
	bit.16b	v26, v1, v0
	bit.16b	v25, v2, v10
	bit.16b	v24, v3, v0
	bit.16b	v23, v5, v10
	bit.16b	v22, v6, v0
	bit.16b	v21, v7, v10
	bit.16b	v20, v16, v0
	bit.16b	v30, v17, v10
	mov	x9, x16
	b	LBB1_488
LBB1_487:                               ; %else1451
                                        ;   in Loop: Header=BB1_488 Depth=4
	and.16b	v1, v0, v7
	and.16b	v2, v10, v13
	fmul.4s	v7, v1, v14
	fmul.4s	v29, v2, v9
	fadd.4s	v8, v25, v29
	fadd.4s	v9, v26, v7
	fmul.4s	v5, v1, v5
	fmul.4s	v3, v2, v3
	fadd.4s	v7, v23, v3
	fadd.4s	v29, v24, v5
	fmul.4s	v3, v1, v16
	fmul.4s	v5, v2, v6
	fadd.4s	v5, v21, v5
	fadd.4s	v6, v22, v3
	fmul.4s	v2, v2, v19
	fmul.4s	v1, v1, v17
	fadd.4s	v3, v20, v1
	fadd.4s	v2, v30, v2
	bit.16b	v26, v9, v0
	bit.16b	v25, v8, v10
	bit.16b	v24, v29, v0
	bit.16b	v23, v7, v10
	bit.16b	v22, v6, v0
	bit.16b	v21, v5, v10
	bit.16b	v30, v2, v10
	bit.16b	v20, v3, v0
	add	x14, x14, #32
	add	x9, x9, #384
	cmp	x14, #512
	b.eq	LBB1_485
LBB1_488:                               ; %direct.true585.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ;       Parent Loop BB1_486 Depth=3
                                        ; =>      This Inner Loop Header: Depth=4
	uzp1.8h	v1, v10, v0
	and.16b	v1, v1, v27
	addv.8h	h18, v1
	fmov	w17, s18
	add	x0, x3, x14
	ldp	q13, q7, [x0]
	sub	x0, x9, #12
	dup.2d	v3, x0
	ldr	q1, [sp, #3200]                 ; 16-byte Reload
	ldr	q2, [sp, #3136]                 ; 16-byte Reload
	add.2d	v19, v1, v2
	add.2d	v2, v19, v3
	movi.2d	v9, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbnz	w17, #0, LBB1_522
; %bb.489:                              ; %else1262
                                        ;   in Loop: Header=BB1_488 Depth=4
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_523
LBB1_490:                               ; %else1268
                                        ;   in Loop: Header=BB1_488 Depth=4
	ldr	q1, [sp, #3184]                 ; 16-byte Reload
	ldr	q2, [sp, #3120]                 ; 16-byte Reload
	add.2d	v2, v1, v2
	add.2d	v1, v2, v3
	tbnz	w17, #2, LBB1_524
LBB1_491:                               ; %else1274
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbnz	w17, #3, LBB1_525
LBB1_492:                               ; %else1280
                                        ;   in Loop: Header=BB1_488 Depth=4
	ldr	q1, [sp, #3168]                 ; 16-byte Reload
	ldr	q5, [sp, #3104]                 ; 16-byte Reload
	add.2d	v15, v1, v5
	add.2d	v1, v15, v3
	tbnz	w17, #4, LBB1_526
LBB1_493:                               ; %else1286
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbnz	w17, #5, LBB1_527
LBB1_494:                               ; %else1292
                                        ;   in Loop: Header=BB1_488 Depth=4
	ldr	q1, [sp, #3152]                 ; 16-byte Reload
	ldr	q5, [sp, #3088]                 ; 16-byte Reload
	add.2d	v8, v1, v5
	add.2d	v1, v8, v3
	tbnz	w17, #6, LBB1_528
LBB1_495:                               ; %else1298
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbz	w17, #7, LBB1_497
LBB1_496:                               ; %cond.load1300
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x17, v1[1]
	ld1.s	{ v14 }[3], [x17]
LBB1_497:                               ; %else1304
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	w17, s18
	sub	x0, x9, #8
	dup.2d	v6, x0
	add.2d	v16, v19, v6
	movi.2d	v3, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w17, #0, LBB1_529
; %bb.498:                              ; %else1311
                                        ;   in Loop: Header=BB1_488 Depth=4
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_530
LBB1_499:                               ; %else1317
                                        ;   in Loop: Header=BB1_488 Depth=4
	add.2d	v1, v2, v6
	tbnz	w17, #2, LBB1_531
LBB1_500:                               ; %else1323
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbnz	w17, #3, LBB1_532
LBB1_501:                               ; %else1329
                                        ;   in Loop: Header=BB1_488 Depth=4
	add.2d	v1, v15, v6
	tbnz	w17, #4, LBB1_533
LBB1_502:                               ; %else1335
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbnz	w17, #5, LBB1_534
LBB1_503:                               ; %else1341
                                        ;   in Loop: Header=BB1_488 Depth=4
	add.2d	v1, v8, v6
	tbnz	w17, #6, LBB1_535
LBB1_504:                               ; %else1347
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbz	w17, #7, LBB1_506
LBB1_505:                               ; %cond.load1349
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x17, v1[1]
	ld1.s	{ v5 }[3], [x17]
LBB1_506:                               ; %else1353
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	w17, s18
	sub	x0, x9, #4
	dup.2d	v17, x0
	add.2d	v29, v19, v17
	movi.2d	v6, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w17, #0, LBB1_536
; %bb.507:                              ; %else1360
                                        ;   in Loop: Header=BB1_488 Depth=4
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_537
LBB1_508:                               ; %else1366
                                        ;   in Loop: Header=BB1_488 Depth=4
	add.2d	v1, v2, v17
	tbnz	w17, #2, LBB1_538
LBB1_509:                               ; %else1372
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbnz	w17, #3, LBB1_539
LBB1_510:                               ; %else1378
                                        ;   in Loop: Header=BB1_488 Depth=4
	add.2d	v1, v15, v17
	tbnz	w17, #4, LBB1_540
LBB1_511:                               ; %else1384
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbnz	w17, #5, LBB1_541
LBB1_512:                               ; %else1390
                                        ;   in Loop: Header=BB1_488 Depth=4
	add.2d	v1, v8, v17
	tbnz	w17, #6, LBB1_542
LBB1_513:                               ; %else1396
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbnz	w17, #7, LBB1_543
LBB1_514:                               ; %else1402
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	w17, s18
	dup.2d	v29, x9
	add.2d	v1, v19, v29
	movi.2d	v19, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbnz	w17, #0, LBB1_544
LBB1_515:                               ; %else1409
                                        ;   in Loop: Header=BB1_488 Depth=4
	and	w17, w17, #0xff
	tbnz	w17, #1, LBB1_545
LBB1_516:                               ; %else1415
                                        ;   in Loop: Header=BB1_488 Depth=4
	add.2d	v1, v2, v29
	tbnz	w17, #2, LBB1_546
LBB1_517:                               ; %else1421
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbnz	w17, #3, LBB1_547
LBB1_518:                               ; %else1427
                                        ;   in Loop: Header=BB1_488 Depth=4
	add.2d	v1, v15, v29
	tbnz	w17, #4, LBB1_548
LBB1_519:                               ; %else1433
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbnz	w17, #5, LBB1_549
LBB1_520:                               ; %else1439
                                        ;   in Loop: Header=BB1_488 Depth=4
	add.2d	v1, v8, v29
	tbnz	w17, #6, LBB1_550
LBB1_521:                               ; %else1445
                                        ;   in Loop: Header=BB1_488 Depth=4
	tbz	w17, #7, LBB1_487
	b	LBB1_551
LBB1_522:                               ; %cond.load1258
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d2
	ldr	s9, [x0]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_490
LBB1_523:                               ; %cond.load1264
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v2[1]
	ld1.s	{ v9 }[1], [x0]
	ldr	q1, [sp, #3184]                 ; 16-byte Reload
	ldr	q2, [sp, #3120]                 ; 16-byte Reload
	add.2d	v2, v1, v2
	add.2d	v1, v2, v3
	tbz	w17, #2, LBB1_491
LBB1_524:                               ; %cond.load1270
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v9 }[2], [x0]
	tbz	w17, #3, LBB1_492
LBB1_525:                               ; %cond.load1276
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v1[1]
	ld1.s	{ v9 }[3], [x0]
	ldr	q1, [sp, #3168]                 ; 16-byte Reload
	ldr	q5, [sp, #3104]                 ; 16-byte Reload
	add.2d	v15, v1, v5
	add.2d	v1, v15, v3
	tbz	w17, #4, LBB1_493
LBB1_526:                               ; %cond.load1282
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v14 }[0], [x0]
	tbz	w17, #5, LBB1_494
LBB1_527:                               ; %cond.load1288
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v1[1]
	ld1.s	{ v14 }[1], [x0]
	ldr	q1, [sp, #3152]                 ; 16-byte Reload
	ldr	q5, [sp, #3088]                 ; 16-byte Reload
	add.2d	v8, v1, v5
	add.2d	v1, v8, v3
	tbz	w17, #6, LBB1_495
LBB1_528:                               ; %cond.load1294
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v14 }[2], [x0]
	tbnz	w17, #7, LBB1_496
	b	LBB1_497
LBB1_529:                               ; %cond.load1307
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d16
	ldr	s3, [x0]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_499
LBB1_530:                               ; %cond.load1313
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v16[1]
	ld1.s	{ v3 }[1], [x0]
	add.2d	v1, v2, v6
	tbz	w17, #2, LBB1_500
LBB1_531:                               ; %cond.load1319
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v3 }[2], [x0]
	tbz	w17, #3, LBB1_501
LBB1_532:                               ; %cond.load1325
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v1[1]
	ld1.s	{ v3 }[3], [x0]
	add.2d	v1, v15, v6
	tbz	w17, #4, LBB1_502
LBB1_533:                               ; %cond.load1331
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v5 }[0], [x0]
	tbz	w17, #5, LBB1_503
LBB1_534:                               ; %cond.load1337
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v1[1]
	ld1.s	{ v5 }[1], [x0]
	add.2d	v1, v8, v6
	tbz	w17, #6, LBB1_504
LBB1_535:                               ; %cond.load1343
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v5 }[2], [x0]
	tbnz	w17, #7, LBB1_505
	b	LBB1_506
LBB1_536:                               ; %cond.load1356
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d29
	ldr	s6, [x0]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_508
LBB1_537:                               ; %cond.load1362
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v29[1]
	ld1.s	{ v6 }[1], [x0]
	add.2d	v1, v2, v17
	tbz	w17, #2, LBB1_509
LBB1_538:                               ; %cond.load1368
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v6 }[2], [x0]
	tbz	w17, #3, LBB1_510
LBB1_539:                               ; %cond.load1374
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v1[1]
	ld1.s	{ v6 }[3], [x0]
	add.2d	v1, v15, v17
	tbz	w17, #4, LBB1_511
LBB1_540:                               ; %cond.load1380
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v16 }[0], [x0]
	tbz	w17, #5, LBB1_512
LBB1_541:                               ; %cond.load1386
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v1[1]
	ld1.s	{ v16 }[1], [x0]
	add.2d	v1, v8, v17
	tbz	w17, #6, LBB1_513
LBB1_542:                               ; %cond.load1392
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v16 }[2], [x0]
	tbz	w17, #7, LBB1_514
LBB1_543:                               ; %cond.load1398
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x17, v1[1]
	ld1.s	{ v16 }[3], [x17]
	fmov	w17, s18
	dup.2d	v29, x9
	add.2d	v1, v19, v29
	movi.2d	v19, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w17, #0, LBB1_515
LBB1_544:                               ; %cond.load1405
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ldr	s19, [x0]
	and	w17, w17, #0xff
	tbz	w17, #1, LBB1_516
LBB1_545:                               ; %cond.load1411
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v1[1]
	ld1.s	{ v19 }[1], [x0]
	add.2d	v1, v2, v29
	tbz	w17, #2, LBB1_517
LBB1_546:                               ; %cond.load1417
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v19 }[2], [x0]
	tbz	w17, #3, LBB1_518
LBB1_547:                               ; %cond.load1423
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v1[1]
	ld1.s	{ v19 }[3], [x0]
	add.2d	v1, v15, v29
	tbz	w17, #4, LBB1_519
LBB1_548:                               ; %cond.load1429
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v17 }[0], [x0]
	tbz	w17, #5, LBB1_520
LBB1_549:                               ; %cond.load1435
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x0, v1[1]
	ld1.s	{ v17 }[1], [x0]
	add.2d	v1, v8, v29
	tbz	w17, #6, LBB1_521
LBB1_550:                               ; %cond.load1441
                                        ;   in Loop: Header=BB1_488 Depth=4
	fmov	x0, d1
	ld1.s	{ v17 }[2], [x0]
	tbz	w17, #7, LBB1_487
LBB1_551:                               ; %cond.load1447
                                        ;   in Loop: Header=BB1_488 Depth=4
	mov.d	x17, v1[1]
	ld1.s	{ v17 }[3], [x17]
	b	LBB1_487
LBB1_552:                               ; %direct.true644.i.i.preheader
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, #0                          ; =0x0
	ldr	q6, [sp, #2208]                 ; 16-byte Reload
LBB1_553:                               ; %direct.true644.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	fmov	d1, x9
	orr.16b	v2, v1, v13
	fmov	x13, d2
	add	x13, x4, x13
	ldp	q2, q3, [x13]
	orr.16b	v1, v1, v6
	fmov	x13, d1
	add	x13, x1, x13
	ldp	q1, q5, [x13]
	bif.16b	v3, v5, v0
	bit.16b	v1, v2, v10
	stp	q1, q3, [x13]
	add	x9, x9, #32
	cmp	x9, #3072
	b.ne	LBB1_553
; %bb.554:                              ; %direct.true660.i.i.preheader
                                        ;   in Loop: Header=BB1_32 Depth=2
	mov	x9, x8
	mov	w13, #96                        ; =0x60
	ldr	q15, [sp, #1968]                ; 16-byte Reload
	ldr	q17, [sp, #1920]                ; 16-byte Reload
	ldr	q27, [sp, #592]                 ; 16-byte Reload
	ldp	q29, q19, [sp, #512]            ; 32-byte Folded Reload
	ldr	q31, [sp, #496]                 ; 16-byte Reload
	ldr	q8, [sp, #1824]                 ; 16-byte Reload
	ldr	q9, [sp, #1808]                 ; 16-byte Reload
	ldr	q16, [sp, #1792]                ; 16-byte Reload
	ldr	q11, [sp, #1776]                ; 16-byte Reload
	ldr	q12, [sp, #2256]                ; 16-byte Reload
	ldr	q7, [sp, #2240]                 ; 16-byte Reload
LBB1_555:                               ; %direct.true660.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ;     Parent Loop BB1_32 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q1, [x9, #5632]
	ldr	q2, [x9, #5648]
	ldr	q3, [x9, #2560]
	ldr	q5, [x9, #2576]
	bif.16b	v2, v5, v0
	bif.16b	v1, v3, v10
	str	q1, [x9, #2560]
	str	q2, [x9, #2576]
	add	x9, x9, #32
	subs	x13, x13, #1
	b.ne	LBB1_555
; %bb.556:                              ; %direct.false661.i.i
                                        ;   in Loop: Header=BB1_32 Depth=2
	ldr	q1, [sp, #2000]                 ; 16-byte Reload
	ldr	q2, [sp, #3024]                 ; 16-byte Reload
	bit.16b	v1, v2, v0
	str	q1, [sp, #2000]                 ; 16-byte Spill
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	ldr	q2, [sp, #3040]                 ; 16-byte Reload
	bit.16b	v1, v2, v10
	str	q1, [sp, #1984]                 ; 16-byte Spill
	movi.2d	v2, #0000000000000000
	ldr	q1, [sp, #3056]                 ; 16-byte Reload
	fadd.4s	v1, v1, v2
	ldr	q3, [sp, #2992]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #3008]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #2976]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1936]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #2224]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1744]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1728]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1712]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1760]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1680]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1648]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1616]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1584]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1568]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1520]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1536]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1488]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1504]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1456]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1472]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1440]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1424]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1392]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	ldr	q3, [sp, #1376]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1360]                 ; 16-byte Reload
	fadd.4s	v1, v3, v1
	ldr	q3, [sp, #1408]                 ; 16-byte Reload
	fadd.4s	v2, v3, v2
	fmul.4s	v3, v8, v28
	fmul.4s	v4, v9, v4
	fadd.4s	v2, v4, v2
	fadd.4s	v1, v3, v1
	bit.16b	v8, v1, v10
	bit.16b	v9, v2, v0
	add	x7, x7, #1
	cmp	x7, #129
	ldr	q28, [sp, #576]                 ; 16-byte Reload
	ldr	q4, [sp, #2288]                 ; 16-byte Reload
	ldr	q5, [sp, #2272]                 ; 16-byte Reload
	b.ne	LBB1_32
; %bb.557:                              ; %direct.schedule.51.preheader.i.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x8, #0                          ; =0x0
	ldr	q1, [sp, #80]                   ; 16-byte Reload
	fmov	x9, d1
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d4, x9
	mov.d	x9, v1[1]
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v4[1], x9
	ldr	q1, [sp, #96]                   ; 16-byte Reload
	fmov	x9, d1
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d3, x9
	mov.d	x9, v1[1]
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v3[1], x9
	ldp	q1, q5, [sp, #112]              ; 32-byte Folded Reload
	fmov	x9, d1
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d2, x9
	mov.d	x9, v1[1]
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v2[1], x9
	fmov	x9, d5
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	fmov	d1, x9
	mov.d	x9, v5[1]
	add	x9, x9, x9, lsl #1
	lsl	x9, x9, #5
	mov.d	v1[1], x9
	sshll.2d	v5, v0, #0
	sshll.2d	v6, v10, #0
	and.16b	v1, v6, v1
	ldr	q6, [sp, #1344]                 ; 16-byte Reload
	and.16b	v2, v6, v2
	and.16b	v3, v5, v3
	and.16b	v4, v17, v4
	ldr	x2, [sp, #232]                  ; 8-byte Reload
	ldr	x11, [sp, #152]                 ; 8-byte Reload
	b	LBB1_559
LBB1_558:                               ; %else1583
                                        ;   in Loop: Header=BB1_559 Depth=2
	add	x8, x8, #1
	cmp	x8, #96
	b.eq	LBB1_2
LBB1_559:                               ; %direct.true725.i.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s18
	dup.2d	v5, x8
	add.2d	v6, v5, v1
	add	x10, x15, x8, lsl #5
	ldp	q16, q7, [x10]
	and.16b	v16, v10, v16
	fdiv.4s	v16, v16, v8
	shl.2d	v17, v6, #2
	dup.2d	v6, x11
	add.2d	v17, v6, v17
	tbnz	w9, #0, LBB1_567
; %bb.560:                              ; %else1555
                                        ;   in Loop: Header=BB1_559 Depth=2
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB1_568
LBB1_561:                               ; %else1559
                                        ;   in Loop: Header=BB1_559 Depth=2
	add.2d	v17, v5, v2
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbnz	w9, #2, LBB1_569
LBB1_562:                               ; %else1563
                                        ;   in Loop: Header=BB1_559 Depth=2
	tbnz	w9, #3, LBB1_570
LBB1_563:                               ; %else1567
                                        ;   in Loop: Header=BB1_559 Depth=2
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v9
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbnz	w9, #4, LBB1_571
LBB1_564:                               ; %else1571
                                        ;   in Loop: Header=BB1_559 Depth=2
	tbnz	w9, #5, LBB1_572
LBB1_565:                               ; %else1575
                                        ;   in Loop: Header=BB1_559 Depth=2
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbnz	w9, #6, LBB1_573
LBB1_566:                               ; %else1579
                                        ;   in Loop: Header=BB1_559 Depth=2
	tbz	w9, #7, LBB1_558
	b	LBB1_574
LBB1_567:                               ; %cond.store1552
                                        ;   in Loop: Header=BB1_559 Depth=2
	fmov	x10, d17
	str	s16, [x10]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB1_561
LBB1_568:                               ; %cond.store1556
                                        ;   in Loop: Header=BB1_559 Depth=2
	mov.d	x10, v17[1]
	st1.s	{ v16 }[1], [x10]
	add.2d	v17, v5, v2
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbz	w9, #2, LBB1_562
LBB1_569:                               ; %cond.store1560
                                        ;   in Loop: Header=BB1_559 Depth=2
	fmov	x10, d17
	st1.s	{ v16 }[2], [x10]
	tbz	w9, #3, LBB1_563
LBB1_570:                               ; %cond.store1564
                                        ;   in Loop: Header=BB1_559 Depth=2
	mov.d	x10, v17[1]
	st1.s	{ v16 }[3], [x10]
	add.2d	v16, v5, v3
	and.16b	v7, v0, v7
	fdiv.4s	v7, v7, v9
	shl.2d	v16, v16, #2
	add.2d	v16, v6, v16
	tbz	w9, #4, LBB1_564
LBB1_571:                               ; %cond.store1568
                                        ;   in Loop: Header=BB1_559 Depth=2
	fmov	x10, d16
	str	s7, [x10]
	tbz	w9, #5, LBB1_565
LBB1_572:                               ; %cond.store1572
                                        ;   in Loop: Header=BB1_559 Depth=2
	mov.d	x10, v16[1]
	st1.s	{ v7 }[1], [x10]
	add.2d	v5, v5, v4
	shl.2d	v5, v5, #2
	add.2d	v5, v6, v5
	tbz	w9, #6, LBB1_566
LBB1_573:                               ; %cond.store1576
                                        ;   in Loop: Header=BB1_559 Depth=2
	fmov	x10, d5
	st1.s	{ v7 }[2], [x10]
	tbz	w9, #7, LBB1_558
LBB1_574:                               ; %cond.store1580
                                        ;   in Loop: Header=BB1_559 Depth=2
	mov.d	x9, v5[1]
	st1.s	{ v7 }[3], [x9]
	b	LBB1_558
LBB1_575:                               ; %block.batch.exit
	add	sp, sp, #3248
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh38, Lloh39
	.loh AdrpAdrp	Lloh36, Lloh38
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpAdrp	Lloh34, Lloh36
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpAdrp	Lloh32, Lloh34
	.loh AdrpLdr	Lloh32, Lloh33
	.loh AdrpAdrp	Lloh30, Lloh32
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpLdr	Lloh40, Lloh41
	.loh AdrpLdr	Lloh48, Lloh49
	.loh AdrpAdrp	Lloh46, Lloh48
	.loh AdrpLdr	Lloh46, Lloh47
	.loh AdrpAdrp	Lloh44, Lloh46
	.loh AdrpLdr	Lloh44, Lloh45
	.loh AdrpAdrp	Lloh42, Lloh44
	.loh AdrpLdr	Lloh42, Lloh43
	.loh AdrpLdr	Lloh50, Lloh51
	.loh AdrpLdr	Lloh52, Lloh53
	.loh AdrpLdr	Lloh54, Lloh55
	.loh AdrpLdr	Lloh56, Lloh57
	.loh AdrpLdr	Lloh64, Lloh65
	.loh AdrpAdrp	Lloh62, Lloh64
	.loh AdrpLdr	Lloh62, Lloh63
	.loh AdrpAdrp	Lloh60, Lloh62
	.loh AdrpLdr	Lloh60, Lloh61
	.loh AdrpAdrp	Lloh58, Lloh60
	.loh AdrpLdr	Lloh58, Lloh59
	.loh AdrpLdr	Lloh70, Lloh71
	.loh AdrpAdrp	Lloh68, Lloh70
	.loh AdrpLdr	Lloh68, Lloh69
	.loh AdrpLdr	Lloh66, Lloh67
                                        ; -- End function
.subsections_via_symbols

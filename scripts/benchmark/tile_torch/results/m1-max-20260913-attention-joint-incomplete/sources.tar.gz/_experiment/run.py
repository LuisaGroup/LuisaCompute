"""Predeclared fresh joint native copy / MMA / full-packet experiment.

No build or test command is executed here. Freeze only after the selected full
build and eleven-test gate. Capture and prepare all 30 candidates before replay.
Each edge is measured independently with the unchanged two-arm ABBA runner.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/mike/CLionProjects/luisa')
OUT = Path(__file__).resolve().parent
SOURCE = Path('/tmp/luisa-next-integration.roZbN8/source')
BUILD = Path('/tmp/luisa-next-integration.roZbN8/build')
PRODUCER = BUILD / 'bin/benchmark_tile_xir'
RUNNER = ROOT / 'scripts/benchmark/tile_torch/native_tile.py'
LLVM = Path('/opt/homebrew/opt/llvm/bin')
CASES = [
    ('decode-mha-d64', (1, 8, 8, 1, 2048, 64, 64), (1, 16), 0, False),
    ('decode-gqa-d80', (1, 8, 2, 1, 2053, 80, 96), (1, 16), 8, False),
    ('decode-long-kv', (1, 16, 4, 1, 8193, 128, 128), (1, 16), 8, False),
    ('prefill-q4', (1, 4, 2, 32, 65, 32, 32), (4, 16), 0, True),
    ('prefill-q8', (1, 4, 2, 64, 129, 32, 48), (8, 16), 0, True),
    ('batch-gqa-q4', (2, 6, 2, 17, 67, 40, 48), (4, 16), 8, True),
]
# name, native MMA width, native copy width, simplified specialization request.
VARIANTS = (('m0-c0', 0, 0, False), ('m0-c4', 0, 4, False),
            ('m4-c0', 4, 0, False), ('m4-c4', 4, 4, False),
            ('m4-c4-simplified', 4, 4, True))
EDGES = (('copy-m0', 'm0-c0', 'm0-c4', 'copy'),
         ('copy-m4', 'm4-c0', 'm4-c4', 'copy'),
         ('mma-c0', 'm0-c0', 'm4-c0', 'mma'),
         ('mma-c4', 'm0-c4', 'm4-c4', 'mma'),
         ('simplified-m4-c4', 'm4-c4', 'm4-c4-simplified', 'specialization'))
# Must be finalized with the producer metadata before freeze.
SIMPLIFIED_REQUEST_FIELD = 'full_packet_simplification_requested'
TESTS = ('test_simd_schedule_ir', 'test_simd_llvm_schedule_codegen', 'test_simd_xir_to_schedule',
         'test_simd_warp_uniformity', 'test_tile_dsl', 'test_tile_xir_target_info',
         'test_tile_xir_runtime', 'test_tile_xir_llm', 'test_xir_verifier',
         'test_xir_interchange', 'test_xir_passes')
ATOL = RTOL = 5e-5


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value, progress=False):
    # Only aggregate progress records may be updated; raw attempts are unique.
    with Path(path).open('w' if progress else 'x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def local_file(root, relative):
    relative = Path(relative)
    require(not relative.is_absolute() and '..' not in relative.parts, 'unsafe artifact path')
    path = root / relative
    require(path.is_file() and not path.is_symlink(), 'missing/nonregular artifact: ' + str(path))
    require(path.resolve().is_relative_to(root.resolve()), 'artifact escaped root')
    return path


def controls():
    return dict(cases=[dict(case=n, dimensions=list(d), block=list(b), cap=c, two_dimensional=t)
                       for n, d, b, c, t in CASES],
                variants=[dict(name=n, native_mma_vector_width=m, native_copy_vector_width=c,
                               simplified_full_packet_specialization=p) for n, m, c, p in VARIANTS],
                edges=[dict(name=n, baseline=a, candidate=b, kind=k) for n, a, b, k in EDGES],
                requested_mma_output_block=4, packet_width=8, workers_per_block=32,
                local_lanes=1, max_unrolled_tile_elements=64, max_unrolled_region_work=4096,
                full_packet_specialization=True, attention_qk='mma', attention_pv='mma',
                precision='fp32', fast_math=False, native_cycles=3, native_samples=7,
                native_warmup_ms=30, native_target_ms=15, capture_samples=3,
                capture_sample_ms=1, capture_warmup_ms=1, capture_timeout_s=180,
                replay_timeout_s=120, require_same_mma_copy_root_order_equal=True,
                require_same_mma_copy_blocks_per_task_equal=True,
                require_same_mma_copy_equal_snapshot_capacity=True,
                require_same_mma_bitwise_output=True, require_own_capture_bitwise_replay=True,
                metric='single_thread_native_entry_host_wall_us',
                oracle='Independent dense FP64 NumPy einsum(optimize=False), FP32 scale, bottom-right causal GQA',
                atol=ATOL, rtol=RTOL, captures=30, pair_replays=30, visits=360, samples=2520,
                count_order=['native_mmas', 'native_contraction_mmas', 'native_output_mmas'],
                expected_native_counts={'m0': [0, 0, 0], 'm4': [2, 1, 1]},
                expected_native_copies_rule='copy0:0; copy4:one to three preexisting Q/K/V snapshots. Record realized sites; offline audit cross-checks private LLVM copy helper definitions. Q64 in MMA0 is below snapshot threshold and has no dynamic/indexable MMA consumer, so Q is not required to materialize.',
                simplified_request_field=SIMPLIFIED_REQUEST_FIELD,
                order_policy='Five predeclared edges per case; each independently uses three ABBA cycles, no cross-edge visit division',
                interaction_policy='Compare direct matched conditional edges; no cross-edge arithmetic as a causal interaction estimate or best-arm selection proof',
                boundary='Copy/specialization preserve same-MMA bits and snapshot capacity; interleaving, helper code, workspace and clone admission may change. MMA changes may alter snapshots, entry ABI and FP32 order; all candidates need full FP64 checks. No Torch/MPS/BLAS or default-policy claim.')

def frozen_identities(build_gate, test_gate):
    names = (OUT / 'owned.txt').read_text().splitlines()
    require(names and len(names) == len(set(names)), 'invalid owned source inventory')
    main = {n: sha(local_file(ROOT, n)) for n in names}
    selected = {n: sha(local_file(SOURCE, n)) for n in names}
    require(main == selected, 'main/selected source mismatch')
    gate_records = []
    for label, expected_command in (
            (build_gate, ['cmake', '--build', str(BUILD), '-j', '6']),
            (test_gate, ['ctest', '--test-dir', str(BUILD), '--output-on-failure', '-R', '^(' + '|'.join(TESTS) + ')$'])):
        path = local_file(OUT, label)
        gate = load(path)
        log = local_file(OUT, path.stem + '.log')
        require(gate.get('returncode') == 0 and gate.get('source_unchanged') is True, 'gate not successful: ' + label)
        require(gate.get('command') == expected_command, 'gate command is not the full selected build/test set')
        require(gate.get('source_sha256') == main and gate.get('selected_source') == str(SOURCE)
                and gate.get('build') == str(BUILD), 'gate source identity differs')
        require(gate.get('log_sha256') == sha(log), 'gate log changed')
        require(gate['finished'] >= gate['started'], 'invalid gate chronology')
        gate_records.append((gate, path, log))
    require(gate_records[1][0]['started'] >= gate_records[0][0]['finished'], 'tests preceded the complete build')
    require(re.search(r'100% tests passed(?:, 0 tests failed)? out of 11\b', gate_records[1][2].read_text()),
            'test log does not acknowledge all eleven tests passing')
    abi = 'src/backends/simd/llvm/llvm_schedule_codegen.h'
    require(sha(ROOT / abi) == sha(SOURCE / abi), 'actual producer/helper ABI header differs')
    paths = [Path(__file__).resolve(), OUT / 'audit.py', OUT / 'predeclared.json', OUT / 'gate.py', OUT / 'owned.txt', Path(sys.executable), RUNNER,
             RUNNER.parent / 'native_tile_replay.cpp', ROOT / abi, SOURCE / abi, PRODUCER,
             *[BUILD / 'bin' / name for name in ('libluisa-backend-simd.so', 'libluisa-tile-bridge-xir.dylib',
                                                'libluisa-tile.dylib', 'libluisa-xir.dylib')],
             LLVM / 'clang++', LLVM / 'llvm-nm',
             *[path for _, gate, log in gate_records for path in (gate, log)]]
    return dict(owned_source_sha256=main, selected_source_sha256=selected,
                files_sha256={str(p): sha(p) for p in paths})


def freeze(create=False, build_gate=None, test_gate=None):
    path = OUT / 'plan.json'
    if not create:
        plan = load(path)
        build_gate, test_gate = plan['build_gate'], plan['test_gate']
    require(build_gate and test_gate, 'freeze requires --build-gate and --test-gate filenames')
    require(load(OUT / 'predeclared.json') == controls(), 'predeclared controls differ from driver')
    expected = dict(controls=controls(), build_gate=build_gate, test_gate=test_gate,
                    identities=frozen_identities(build_gate, test_gate),
                    python=str(Path(sys.executable).resolve()), python_launcher=str(Path(sys.executable).absolute()), llvm=str(LLVM))
    if create:
        save(path, dict(**expected, frozen_unix=time.time(),
                       identity_boundary='Exact selected source and binary/tool fingerprints; not a full HEAD archive or loader-closure attestation.'))
    else:
        require(all(plan.get(k) == v for k, v in expected.items()), 'frozen source/producer/runner/gate/control changed')
    return sha(path)


def clean_env():
    env = {k: v for k, v in os.environ.items() if not k.startswith(('LUISA_', 'MTL_'))}
    env.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1')
    return env


def run(command, folder, stem, env=None, timeout=180):
    paths = [folder / (stem + suffix) for suffix in ('.command.json', '.result.json', '.stdout', '.stderr')]
    require(not any(p.exists() for p in paths), 'attempt already exists: ' + stem)
    record = dict(command=command, started=time.time(), timeout_s=timeout, process_group_isolated=True,
                  environment={k: v for k, v in (env or {}).items()
                               if k.startswith('LUISA_') or k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')})
    save(paths[0], record)
    process = None
    stdout = stderr = b''
    try:
        process = subprocess.Popen(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = process.communicate()
            record['error'] = 'timeout; entire isolated process group terminated'
        record['returncode'] = process.returncode
        require(process.returncode == 0 and 'error' not in record, stem + ': failed; inspect retained logs')
        require(not stderr, stem + ': stderr requires review before acceptance')
        return stdout
    except BaseException as error:
        if process is not None and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = process.communicate()
            record['returncode'] = process.returncode
        record['error'] = str(error)
        raise
    finally:
        for path, data in zip(paths[2:], (stdout, stderr)):
            with path.open('xb') as stream:
                stream.write(data)
        record['finished'] = time.time()
        save(paths[1], record)


def field(text, name, boolean=False):
    values = re.findall(r'\b' + re.escape(name) + '=' + ('(true|false)' if boolean else r'(\d+)') + r'\b', text)
    require(len(values) == 1, 'missing/duplicate realization acknowledgement: ' + name)
    return values[0] == 'true' if boolean else int(values[0])


def execution_controls(metadata, cap, two_d, mma_width, copy_width, simplified, prepared=None):
    text = metadata['realization']
    require(re.findall(r'\bW(\d+), (\d+) workers/block\b', text) == [('8', '32')], 'W8/block32 drift')
    for key, value in dict(local_lanes=1, max_unrolled_tile_elements=64, max_unrolled_region_work=4096,
                           requested_mma_output_block=4, requested_max_unrolled_mma_terms=cap,
                           native_mma_vector_width=mma_width, native_copy_vector_width=copy_width).items():
        require(field(text, key) == value, key + ' drift')
    require(field(text, 'requested_mma_2d_blocking', True) is two_d, '2D request drift')
    require(field(text, SIMPLIFIED_REQUEST_FIELD, True) is simplified, 'simplified request drift')
    decisions = re.findall(r'\bfull_packet_specialization_decision=([a-z_]+)\b', text)
    require(len(decisions) == 1 and decisions[0] in (
        'ineligible', 'source_budget_exceeded', 'candidate_budget_exceeded',
        'legacy_selected', 'simplified_selected'), 'missing/unexpected specialization decision')
    source_work = field(text, 'full_packet_source_instructions')
    candidate_work = field(text, 'full_packet_candidate_instructions')
    rounds = field(text, 'full_packet_simplification_rounds')
    require(rounds <= 4 and (simplified or rounds == 0), 'simplification round drift')
    require(decisions[0] != ('legacy_selected' if simplified else 'simplified_selected'), 'wrong specialization algorithm selected')
    if decisions[0] == 'simplified_selected':
        require(source_work <= 8192 and candidate_work <= 4096, 'simplified specialization budget drift')
    if decisions[0] == 'legacy_selected':
        require(source_work <= 4096, 'legacy specialization budget drift')
    counts = [field(text, key) for key in controls()['count_order']]
    require(counts == ([2, 1, 1] if mma_width else [0, 0, 0]), 'native MMA admission drift: ' + str(counts))
    copies = field(text, 'native_copies')
    require((copies == 0) if not copy_width else (1 <= copies <= 3), 'native copy snapshot admission drift')
    orders = re.findall(r'\broot order \[([0-9]+(?:\s*,\s*[0-9]+)*)\]', text)
    require(len(orders) == 1, 'missing/duplicate root order')
    order = [int(x.strip()) for x in orders[0].split(',')]
    require(sorted(order) == list(range(len(order))), 'root order is not a permutation')
    if prepared is not None:
        require(prepared['packet_width'] == 8 and prepared['block'] == [32, 1, 1], 'prepared launch drift')
        require(prepared['metadata'] == metadata, 'prepared metadata differs')
    return dict(root_order=order, blocks_per_task=field(text, 'blocks_per_task'))

def capture_one(name, dims, block, cap, two_d, variant, mma_width, copy_width, simplified):
    label = name + '-' + variant
    folder = OUT / label
    folder.mkdir()
    prefix = folder / 'output.f32'
    env = clean_env()
    env.update(LUISA_TILE_BENCH_XIR_BACKEND='simd', LUISA_TILE_BENCH_ATTENTION_QK='mma',
               LUISA_TILE_BENCH_ATTENTION_PV='mma', LUISA_TILE_BENCH_XIR_MMA_OUTPUT_BLOCK='4',
               LUISA_TILE_BENCH_XIR_MMA_UNROLL_TERMS=str(cap),
               LUISA_TILE_BENCH_XIR_MMA_2D_BLOCKING='1' if two_d else '0',
               LUISA_TILE_BENCH_XIR_BLOCK_SIZE='32', LUISA_TILE_BENCH_XIR_LOCAL_LANES='1',
               LUISA_TILE_BENCH_XIR_REGION_WORK='4096', LUISA_SIMD_NATIVE_MMA_VECTOR_WIDTH=str(mma_width),
               LUISA_SIMD_NATIVE_COPY_VECTOR_WIDTH=str(copy_width),
               LUISA_SIMD_ENABLE_SIMPLIFIED_FULL_PACKET_SPECIALIZATION='1' if simplified else '0',
               LUISA_TILE_BENCH_DUMP_SOURCE=str(prefix) + '.source.txt',
               LUISA_SIMD_DUMP_ASSEMBLY_DIR=str(folder / 'objects'), LUISA_SIMD_ENABLE_FULL_PACKET_SPECIALIZATION='1')
    metadata = json.loads(run([str(PRODUCER), 'llm', 'attention', ','.join(map(str, dims)),
                               *map(str, block), '3', '1', '1', str(prefix)], folder, 'capture', env))
    require(metadata['dimensions'] == list(dims) and metadata['attention_block'] == list(block), 'shape drift')
    require(metadata['attention_qk'] == metadata['attention_pv'] == 'mma', 'decomposition drift')
    require(metadata['fast_math'] is False and metadata['precision'] == 'fp32', 'precision drift')
    execution_controls(metadata, cap, two_d, mma_width, copy_width, simplified)
    run([sys.executable, str(RUNNER), 'prepare', '--capture-kind', 'llm', '--llvm', str(LLVM),
         '--prefix', str(prefix), '--log', str(folder / 'capture.stdout'), '--objects', str(folder / 'objects'),
         '--output', str(OUT / ('prepared-' + label)), '--name', variant], folder, 'prepare', clean_env())
    manifest = OUT / ('prepared-' + label) / 'prepared.json'
    prepared = load(manifest)
    execution = execution_controls(metadata, cap, two_d, mma_width, copy_width, simplified, prepared)
    return dict(label=label, prepared_manifest_sha256=sha(manifest), execution_controls=execution,
                realization=metadata['realization'])


def case_oracle(name, dims, block, cap, two_d):
    # Loaded only outside native timing subprocesses.
    import numpy as np

    directories = {variant: OUT / f'prepared-{name}-{variant}' for variant, *_ in VARIANTS}
    manifests = {variant: load(path / 'prepared.json') for variant, path in directories.items()}
    execution = {}
    for variant, mma_width, copy_width, simplified in VARIANTS:
        directory, manifest = directories[variant], manifests[variant]
        require(manifest.get('status') == 'prepared' and manifest.get('capture_kind') == 'llm', 'incomplete LLM preparation')
        for relative, digest in manifest['files'].items():
            require(sha(local_file(directory, relative)) == digest, 'prepared hash drift: ' + relative)
        execution[variant] = execution_controls(manifest['metadata'], cap, two_d, mma_width, copy_width, simplified, manifest)
    base = manifests['m0-c0']
    for variant, manifest in manifests.items():
        for key in ('dimensions', 'attention_block', 'attention_qk', 'attention_pv', 'precision', 'fast_math',
                    'relaxed_precision', 'source_reduction_policy', 'dispatch', 'input_shapes', 'output_shape'):
            require(base['metadata'][key] == manifest['metadata'][key], 'candidate math/config drift: ' + key)
        for key in ('packet_width', 'block', 'dispatch', 'tool_sha256', 'atol', 'rtol'):
            require(base[key] == manifest[key], 'candidate entry/helper contract drift: ' + key)
        for relative in ('input0.f32', 'input1.f32', 'input2.f32', 'expected.f64', 'native_tile.py',
                         'native_tile_replay.cpp', 'backends/simd/llvm/llvm_schedule_codegen.h'):
            require(base['files'][relative] == manifest['files'][relative], 'candidate input/oracle/helper drift: ' + relative)
    require(base['metadata']['dimensions'] == list(dims) and base['metadata']['attention_block'] == list(block), 'declared shape mismatch')
    require(base['atol'] == ATOL and base['rtol'] == RTOL, 'capture tolerance drift')
    b, h, kh, q, keys, d, dv = dims
    shapes = ((b, h, q, d), (b, kh, keys, d), (b, kh, keys, dv))

    def array(path, shape, dtype):
        require(path.stat().st_size == math.prod(shape) * np.dtype(dtype).itemsize, 'tensor extent mismatch')
        result = np.fromfile(path, dtype=dtype).reshape(shape)
        require(np.isfinite(result).all(), 'nonfinite tensor')
        return result

    query, key, value = [array(directories['m0-c0'] / f'input{i}.f32', shape, '<f4').astype(np.float64)
                         for i, shape in enumerate(shapes)]
    key, value = np.repeat(key, h // kh, axis=1), np.repeat(value, h // kh, axis=1)
    scale = float(np.float32(1) / np.sqrt(np.float32(d)))
    score = np.einsum('bhqd,bhkd->bhqk', query, key, optimize=False) * scale
    mask = np.arange(keys)[None, :] <= np.arange(q)[:, None] + keys - q
    score = np.where(mask, score, -1e30)
    weights = np.where(mask, np.exp(score - score.max(axis=-1, keepdims=True)), 0)
    expected = np.einsum('bhqk,bhkv->bhqv', weights / weights.sum(axis=-1, keepdims=True), value, optimize=False)
    require(np.allclose(array(directories['m0-c0'] / 'expected.f64', expected.shape, '<f8'), expected,
                        atol=1e-12, rtol=1e-12), 'independent FP64 einsum oracle differs from captured oracle')
    checks = {}
    for variant, manifest in manifests.items():
        directory = directories[variant]
        output = array(directory / 'captured.f32', expected.shape, '<f4').astype(np.float64)
        error = np.abs(output - expected)
        require(np.all(error <= ATOL + RTOL * np.abs(expected)), variant + ': complete captured output mismatch')
        require(manifest['output_elements'] == math.prod(expected.shape), 'output metadata extent drift')
        text = manifest['metadata']['realization']
        checks[variant] = dict(captured_output_sha256=manifest['files']['captured.f32'],
                               max_abs_error=float(error.max()), workspace_bytes=manifest['workspace_bytes'],
                               abi=manifest['abi'], symbol=manifest['symbol'], execution=execution[variant],
                               physical={key: field(text, key) for key in (
                                   'static_snapshot_bytes_per_worker', 'static_snapshot_allocations',
                                   'interleaved_private_arrays', 'full_packet_specializations',
                                   'full_packet_cloned_instructions', 'native_mmas',
                                   'native_contraction_mmas', 'native_output_mmas', 'native_copies',
                                   'full_packet_source_instructions', 'full_packet_candidate_instructions',
                                   'full_packet_simplification_rounds')},
                               specialization_decision=re.findall(r'\bfull_packet_specialization_decision=([a-z_]+)\b', text)[0])
    edge_checks = {}
    for edge, left, right, kind in EDGES:
        a, b = checks[left], checks[right]
        bitwise = a['captured_output_sha256'] == b['captured_output_sha256']
        if kind != 'mma':
            require(execution[left] == execution[right], edge + ': root-order/task-grain drift')
            require(a['abi'] == b['abi'] and a['symbol'] == b['symbol'], edge + ': entry ABI/symbol drift')
            require(bitwise, edge + ': exact FP32 bits changed')
            for key in ('static_snapshot_bytes_per_worker', 'static_snapshot_allocations'):
                require(a['physical'][key] == b['physical'][key], edge + ': snapshot allocation drift: ' + key)
        edge_checks[edge] = dict(kind=kind, bitwise_equal=bitwise, bitwise_required=kind != 'mma')
    return dict(independent_fp64=True, elements=math.prod(expected.shape), atol=ATOL, rtol=RTOL,
                edge_checks=edge_checks, variants=checks)

def capture(selected):
    plan_hash = freeze()
    path = OUT / 'captures.json'
    record = load(path) if path.exists() else dict(started=time.time(), plan_sha256=plan_hash,
                                                  cases=[dict(case=n, status='NotRun') for n, *_ in CASES])
    require(record['plan_sha256'] == plan_hash, 'capture plan drift')
    require([r['case'] for r in record['cases']] == [n for n, *_ in CASES], 'capture case inventory drift')
    for row, case in zip(record['cases'], CASES):
        name, dims, block, cap, two_d = case
        if name not in selected:
            continue
        require(row['status'] == 'NotRun', 'case already attempted: ' + name)
        row.update(status='Capturing', variants=[])
        save(path, record, progress=True)
        try:
            for variant, mma_width, copy_width, simplified in VARIANTS:
                require(freeze() == plan_hash, 'identity changed before capture')
                row['variants'].append(capture_one(*case, variant, mma_width, copy_width, simplified))
                save(path, record, progress=True)
            row.update(status='OK', correctness=case_oracle(*case))
        except Exception as error:
            row.update(status='Error', error=str(error))
        save(path, record, progress=True)
        print(name, row['status'], row.get('error', ''), flush=True)
    require(freeze() == plan_hash, 'identity changed during capture')
    record.update(status='complete' if all(r['status'] == 'OK' for r in record['cases']) else 'incomplete', updated=time.time())
    save(path, record, progress=True)
    require(all(r['status'] == 'OK' for r in record['cases'] if r['case'] in selected), 'selected capture errors retained')


def replay(selected, selected_edges):
    plan_hash = freeze()
    captures = load(OUT / 'captures.json')
    require(captures.get('status') == 'complete' and captures['plan_sha256'] == plan_hash, 'all thirty captures must pass before replay')
    require([r['case'] for r in captures['cases']] == [n for n, *_ in CASES], 'capture case inventory drift')
    for row in captures['cases']:
        require(row['status'] == 'OK' and [v['label'] for v in row['variants']] ==
                [row['case'] + '-' + variant for variant, *_ in VARIANTS], 'capture variants incomplete')
        for variant in row['variants']:
            require(sha(OUT / ('prepared-' + variant['label']) / 'prepared.json') == variant['prepared_manifest_sha256'],
                    'prepared manifest changed after capture admission')
    inventory = [(case, edge) for case, *_ in CASES for edge, *_ in EDGES]
    path = OUT / 'replays.json'
    record = load(path) if path.exists() else dict(started=time.time(), load_before=os.getloadavg(), plan_sha256=plan_hash,
                    experiments=[dict(case=case, edge=edge, status='NotRun') for case, edge in inventory])
    require(record['plan_sha256'] == plan_hash, 'replay plan drift')
    require([(r['case'], r['edge']) for r in record['experiments']] == inventory, 'replay edge inventory drift')
    case_map = {case[0]: case for case in CASES}
    edge_map = {edge[0]: edge for edge in EDGES}
    for row in record['experiments']:
        name, edge = row['case'], row['edge']
        if name not in selected or edge not in selected_edges:
            continue
        require(row['status'] == 'NotRun', 'replay already attempted: ' + name + '/' + edge)
        row.update(status='Replaying')
        save(path, record, progress=True)
        try:
            require(freeze() == plan_hash, 'identity changed before edge replay')
            check = case_oracle(*case_map[name])
            _, baseline, candidate, kind = edge_map[edge]
            directory = OUT / ('replay-' + name + '-' + edge)
            run([sys.executable, str(RUNNER), 'replay',
                 '--prepared', str(OUT / f'prepared-{name}-{baseline}/prepared.json'),
                 '--prepared', str(OUT / f'prepared-{name}-{candidate}/prepared.json'), '--output', str(directory),
                 '--cycles', '3', '--samples', '7', '--warmup-ms', '30', '--target-ms', '15'], OUT,
                'replay-' + name + '-' + edge, clean_env(), timeout=120)
            result = load(directory / 'results.json')
            require(result.get('status') == 'passed' and len(result['visits']) == 12, 'incomplete ABBA cohort')
            for i, visit in enumerate(result['visits']):
                variant = (baseline, candidate, candidate, baseline)[i % 4]
                require(visit['cycle'] == i // 4 and visit['position'] == i % 4 and visit['variant'] == variant, 'ABBA order drift')
                require(visit.get('valid') is True and len(visit['samples_us']) == 7 and visit['repetitions'] > 0, 'invalid timing visit')
                require(all(math.isfinite(x) and x > 0 for x in visit['samples_us']), 'invalid native time')
                require(visit.get('all_guards_passed') is True and visit.get('inputs_unchanged') is True, 'validation-checkpoint guards failed')
                require(sha(local_file(directory, visit['output'])) == visit['output_sha256'] ==
                        check['variants'][variant]['captured_output_sha256'], 'replay differs from its own FP64-checked capture')
            row.update(status='OK', kind=kind, correctness=check, results_sha256=sha(directory / 'results.json'))
        except Exception as error:
            row.update(status='Error', error=str(error))
        save(path, record, progress=True)
        print(name, edge, row['status'], row.get('error', ''), flush=True)
    require(freeze() == plan_hash, 'identity changed during replay')
    record.update(status='complete' if all(r['status'] == 'OK' for r in record['experiments']) else 'incomplete',
                  updated=time.time(), load_after=os.getloadavg())
    save(path, record, progress=True)
    require(all(r['status'] == 'OK' for r in record['experiments'] if r['case'] in selected and r['edge'] in selected_edges), 'selected replay errors retained')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('freeze', 'capture', 'replay'))
    parser.add_argument('--build-gate', help='successful gate.py build JSON filename, relative to this experiment')
    parser.add_argument('--test-gate', help='successful gate.py tests JSON filename, relative to this experiment')
    parser.add_argument('--case', action='append', choices=[n for n, *_ in CASES], help='predeclared case subset; default all six')
    parser.add_argument('--edge', action='append', choices=[e for e, *_ in EDGES], help='replay-only predeclared edge subset')
    args = parser.parse_args()
    if args.phase == 'freeze':
        require(args.case is None and args.edge is None, 'freeze always declares the complete six-case, five-variant matrix')
        print(freeze(True, args.build_gate, args.test_gate))
    else:
        require(args.build_gate is None and args.test_gate is None, 'gate choices are frozen in plan.json')
        selected = set(args.case or [n for n, *_ in CASES])
        if args.phase == 'capture':
            require(args.edge is None, '--edge is replay-only')
            capture(selected)
        else:
            replay(selected, set(args.edge or [e for e, *_ in EDGES]))

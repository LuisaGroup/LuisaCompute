	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_7:
	.quad	256                             ; 0x100
	.quad	260                             ; 0x104
lCPI0_8:
	.quad	272                             ; 0x110
	.quad	276                             ; 0x114
lCPI0_9:
	.quad	264                             ; 0x108
	.quad	268                             ; 0x10c
lCPI0_10:
	.quad	280                             ; 0x118
	.quad	284                             ; 0x11c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v17, v1, v0
	umaxv.8h	h2, v17
	fmov	w8, s2
	tbz	w8, #0, LBB0_191
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-112]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	sub	sp, sp, #1104
	ldr	x12, [x0]
	ldr	x9, [x0, #16]
	ldr	x8, [x0, #48]
	sshll.2d	v5, v1, #0
	sshll.2d	v4, v0, #0
	sshll2.2d	v21, v1, #0
	sshll2.2d	v20, v0, #0
	ldr	w10, [x1]
	ldr	w11, [x1, #36]
	add	w10, w11, w10, lsl #5
Lloh4:
	adrp	x11, lCPI0_2@PAGE
Lloh5:
	ldr	q2, [x11, lCPI0_2@PAGEOFF]
	and.16b	v24, v20, v2
Lloh6:
	adrp	x11, lCPI0_3@PAGE
Lloh7:
	ldr	q3, [x11, lCPI0_3@PAGEOFF]
	and.16b	v3, v21, v3
Lloh8:
	adrp	x11, lCPI0_4@PAGE
Lloh9:
	ldr	q6, [x11, lCPI0_4@PAGEOFF]
	and.16b	v4, v4, v6
Lloh10:
	adrp	x11, lCPI0_5@PAGE
Lloh11:
	ldr	q6, [x11, lCPI0_5@PAGEOFF]
	and.16b	v2, v5, v6
	str	q2, [sp, #112]                  ; 16-byte Spill
	lsr	w10, w10, #3
	dup.4s	v5, w10
	and.16b	v6, v1, v5
	and.16b	v5, v0, v5
	ushll2.2d	v7, v5, #0
	ushll2.2d	v19, v6, #0
	ushll.2d	v22, v5, #0
	ushll.2d	v18, v6, #0
	subs	x10, x12, x8
	cset	w11, hs
	lsr	x10, x10, #2
	cmp	x10, #1104
	csel	w10, wzr, w11, ls
	subs	x11, x8, x12
	cset	w13, hs
	lsr	x11, x11, #2
	cmp	x11, #1104
	csel	w11, wzr, w13, ls
	orr	w14, w10, w11
	subs	x10, x9, x8
	cset	w11, hs
	lsr	x10, x10, #2
	cmp	x10, #1104
	csel	w11, wzr, w11, ls
	subs	x10, x8, x9
	cset	w13, hs
	lsr	x10, x10, #2
	cmp	x10, #1104
	csel	w13, wzr, w13, ls
	fmov	x10, d18
	add	x10, x10, x10, lsl #6
	lsl	x15, x10, #2
	adrp	x16, lCPI0_6@PAGE
	xtn.2s	v25, v7
	xtn.2s	v26, v22
	xtn.2s	v2, v19
	str	d2, [sp, #128]                  ; 8-byte Spill
	adrp	x10, lCPI0_11@PAGE
	cmp	w14, #1
	b.ne	LBB0_53
; %bb.2:                                ; %direct.activate
	orr	w11, w11, w13
	cbz	w11, LBB0_53
; %bb.3:                                ; %direct.true20.preheader
	str	d26, [sp, #80]                  ; 8-byte Spill
	str	d25, [sp, #96]                  ; 8-byte Spill
	str	q24, [sp, #144]                 ; 16-byte Spill
	mov	x11, #0                         ; =0x0
	add	x13, x8, x15
	add	x14, x9, x15
	add	x15, x12, x15
	ldr	q19, [x16, lCPI0_6@PAGEOFF]
	and.16b	v19, v17, v19
	addv.8h	h19, v19
	fmov	w16, s19
	mov	w17, #-1026555904               ; =0xc2d00000
	mov	w0, #1120403456                 ; =0x42c80000
	mov	w1, #43579                      ; =0xaa3b
	movk	w1, #16312, lsl #16
	movi.4s	v20, #75, lsl #24
	mvni.4s	v21, #128, lsl #24
	mov	w2, #29184                      ; =0x7200
	movk	w2, #48945, lsl #16
	mov	w3, #48782                      ; =0xbe8e
	movk	w3, #46527, lsl #16
	mov	w4, #11226                      ; =0x2bda
	movk	w4, #14672, lsl #16
	mov	w5, #38601                      ; =0x96c9
	movk	w5, #15030, lsl #16
	mov	w6, #34982                      ; =0x88a6
	movk	w6, #15368, lsl #16
	mov	w7, #43642                      ; =0xaa7a
	movk	w7, #15658, lsl #16
	mov	w19, #43691                     ; =0xaaab
	movk	w19, #15914, lsl #16
	movi.4s	v22, #63, lsl #24
	fmov.4s	v23, #1.00000000
	mvni.4s	v24, #127, msl #16
	fneg.4s	v24, v24
	mvni.4s	v25, #63, msl #16
	fneg.4s	v25, v25
	b	LBB0_5
LBB0_4:                                 ; %else71
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x11, x11, #32
	cmp	x11, #256
	b.eq	LBB0_151
LBB0_5:                                 ; %direct.true20
                                        ; =>This Inner Loop Header: Depth=1
	add	x20, x15, x11
	movi.2d	v27, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbz	w16, #0, LBB0_21
; %bb.6:                                ; %cond.load
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s27, [x20]
	and	w21, w16, #0xff
	tbnz	w21, #1, LBB0_22
LBB0_7:                                 ; %else11
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #2, LBB0_23
LBB0_8:                                 ; %cond.load13
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #8
	ld1.s	{ v27 }[2], [x22]
	tbnz	w21, #3, LBB0_24
LBB0_9:                                 ; %else17
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #4, LBB0_25
LBB0_10:                                ; %cond.load19
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #16
	ld1.s	{ v26 }[0], [x22]
	tbnz	w21, #5, LBB0_26
LBB0_11:                                ; %else23
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #6, LBB0_27
LBB0_12:                                ; %cond.load25
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #24
	ld1.s	{ v26 }[2], [x22]
	tbnz	w21, #7, LBB0_28
LBB0_13:                                ; %else29
                                        ;   in Loop: Header=BB0_5 Depth=1
	fmov	w21, s19
	add	x20, x14, x11
	movi.2d	v29, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbz	w21, #0, LBB0_29
LBB0_14:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_5 Depth=1
	ldr	s29, [x20]
	and	w21, w21, #0xff
	tbnz	w21, #1, LBB0_30
LBB0_15:                                ; %else36
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #2, LBB0_31
LBB0_16:                                ; %cond.load38
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #8
	ld1.s	{ v29 }[2], [x22]
	tbnz	w21, #3, LBB0_32
LBB0_17:                                ; %else42
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #4, LBB0_33
LBB0_18:                                ; %cond.load44
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #16
	ld1.s	{ v28 }[0], [x22]
	tbnz	w21, #5, LBB0_34
LBB0_19:                                ; %else48
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #6, LBB0_35
LBB0_20:                                ; %cond.load50
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #24
	ld1.s	{ v28 }[2], [x22]
	tbnz	w21, #7, LBB0_36
	b	LBB0_37
LBB0_21:                                ; %else
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w21, w16, #0xff
	tbz	w21, #1, LBB0_7
LBB0_22:                                ; %cond.load10
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #4
	ld1.s	{ v27 }[1], [x22]
	tbnz	w21, #2, LBB0_8
LBB0_23:                                ; %else14
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #3, LBB0_9
LBB0_24:                                ; %cond.load16
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #12
	ld1.s	{ v27 }[3], [x22]
	tbnz	w21, #4, LBB0_10
LBB0_25:                                ; %else20
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #5, LBB0_11
LBB0_26:                                ; %cond.load22
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #20
	ld1.s	{ v26 }[1], [x22]
	tbnz	w21, #6, LBB0_12
LBB0_27:                                ; %else26
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #7, LBB0_13
LBB0_28:                                ; %cond.load28
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x20, x20, #28
	ld1.s	{ v26 }[3], [x20]
	fmov	w21, s19
	add	x20, x14, x11
	movi.2d	v29, #0000000000000000
	movi.2d	v28, #0000000000000000
	tbnz	w21, #0, LBB0_14
LBB0_29:                                ; %else33
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w21, w21, #0xff
	tbz	w21, #1, LBB0_15
LBB0_30:                                ; %cond.load35
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #4
	ld1.s	{ v29 }[1], [x22]
	tbnz	w21, #2, LBB0_16
LBB0_31:                                ; %else39
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #3, LBB0_17
LBB0_32:                                ; %cond.load41
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #12
	ld1.s	{ v29 }[3], [x22]
	tbnz	w21, #4, LBB0_18
LBB0_33:                                ; %else45
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #5, LBB0_19
LBB0_34:                                ; %cond.load47
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #20
	ld1.s	{ v28 }[1], [x22]
	tbnz	w21, #6, LBB0_20
LBB0_35:                                ; %else51
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #7, LBB0_37
LBB0_36:                                ; %cond.load53
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x20, x20, #28
	ld1.s	{ v28 }[3], [x20]
LBB0_37:                                ; %else54
                                        ;   in Loop: Header=BB0_5 Depth=1
	fneg.4s	v31, v27
	dup.4s	v30, w17
	and.16b	v5, v1, v31
	fcmge.4s	v8, v5, v30
	dup.4s	v31, w0
	fcmge.4s	v9, v31, v5
	and.16b	v8, v8, v9
	and.16b	v10, v8, v5
	dup.4s	v8, w1
	fmul.4s	v9, v10, v8
	mov.16b	v11, v21
	bsl.16b	v11, v20, v9
	fadd.4s	v9, v9, v11
	fsub.4s	v9, v9, v11
	fcvtzs.4s	v6, v9
	scvtf.4s	v11, v6
	dup.4s	v9, w2
	fmul.4s	v12, v11, v9
	fadd.4s	v12, v10, v12
	dup.4s	v10, w3
	fmul.4s	v13, v11, v10
	dup.4s	v11, w4
	fadd.4s	v7, v12, v13
	fmul.4s	v13, v7, v11
	dup.4s	v12, w5
	fadd.4s	v13, v13, v12
	fmul.4s	v14, v7, v13
	dup.4s	v13, w6
	fadd.4s	v14, v14, v13
	fmul.4s	v15, v7, v14
	dup.4s	v14, w7
	fadd.4s	v15, v15, v14
	fmul.4s	v16, v7, v15
	dup.4s	v15, w19
	fadd.4s	v16, v16, v15
	fmul.4s	v16, v7, v16
	fadd.4s	v16, v16, v22
	fmul.4s	v2, v7, v7
	fmul.4s	v2, v2, v16
	fadd.4s	v2, v7, v2
	fadd.4s	v2, v2, v23
	sshr.4s	v7, v6, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v23
	fmul.4s	v2, v2, v16
	sub.4s	v6, v6, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v23
	fmul.4s	v2, v2, v6
	fcmgt.4s	v6, v30, v5
	fcmgt.4s	v7, v5, v31
	fcmeq.4s	v5, v5, v5
	fadd.4s	v2, v2, v23
	bit.16b	v2, v23, v6
	bit.16b	v2, v24, v7
	bif.16b	v2, v25, v5
	fdiv.4s	v2, v27, v2
	fmov	w21, s19
	fmul.4s	v27, v29, v2
	add	x20, x13, x11
	tbz	w21, #0, LBB0_41
; %bb.38:                               ; %cond.store
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s27, [x20]
	and	w21, w21, #0xff
	tbnz	w21, #1, LBB0_42
LBB0_39:                                ; %else59
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #2, LBB0_43
LBB0_40:                                ; %cond.store60
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #8
	st1.s	{ v27 }[2], [x22]
	tbnz	w21, #3, LBB0_44
	b	LBB0_45
LBB0_41:                                ; %else57
                                        ;   in Loop: Header=BB0_5 Depth=1
	and	w21, w21, #0xff
	tbz	w21, #1, LBB0_39
LBB0_42:                                ; %cond.store58
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #4
	st1.s	{ v27 }[1], [x22]
	tbnz	w21, #2, LBB0_40
LBB0_43:                                ; %else61
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #3, LBB0_45
LBB0_44:                                ; %cond.store62
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #12
	st1.s	{ v27 }[3], [x22]
LBB0_45:                                ; %else63
                                        ;   in Loop: Header=BB0_5 Depth=1
	fneg.4s	v2, v26
	and.16b	v2, v0, v2
	fcmge.4s	v5, v2, v30
	fcmge.4s	v6, v31, v2
	and.16b	v5, v5, v6
	and.16b	v5, v5, v2
	fmul.4s	v6, v5, v8
	mov.16b	v7, v21
	bsl.16b	v7, v20, v6
	fadd.4s	v6, v6, v7
	fsub.4s	v6, v6, v7
	fcvtzs.4s	v6, v6
	scvtf.4s	v7, v6
	fmul.4s	v16, v7, v9
	fadd.4s	v5, v5, v16
	fmul.4s	v7, v7, v10
	fadd.4s	v5, v5, v7
	fmul.4s	v7, v5, v11
	fadd.4s	v7, v7, v12
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v13
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v14
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v15
	fmul.4s	v7, v5, v7
	fadd.4s	v7, v7, v22
	fmul.4s	v16, v5, v5
	fmul.4s	v7, v16, v7
	fadd.4s	v5, v5, v7
	fadd.4s	v5, v5, v23
	sshr.4s	v7, v6, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v23
	fmul.4s	v5, v5, v16
	sub.4s	v6, v6, v7
	shl.4s	v6, v6, #23
	add.4s	v6, v6, v23
	fmul.4s	v5, v5, v6
	fcmgt.4s	v6, v30, v2
	fcmgt.4s	v7, v2, v31
	fcmeq.4s	v2, v2, v2
	fadd.4s	v5, v5, v23
	bit.16b	v5, v23, v6
	bit.16b	v5, v24, v7
	bsl.16b	v2, v5, v25
	fdiv.4s	v2, v26, v2
	fmul.4s	v26, v28, v2
	tbz	w21, #4, LBB0_49
; %bb.46:                               ; %cond.store64
                                        ;   in Loop: Header=BB0_5 Depth=1
	str	s26, [x20, #16]
	tbnz	w21, #5, LBB0_50
LBB0_47:                                ; %else67
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #6, LBB0_51
LBB0_48:                                ; %cond.store68
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #24
	st1.s	{ v26 }[2], [x22]
	tbz	w21, #7, LBB0_4
	b	LBB0_52
LBB0_49:                                ; %else65
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #5, LBB0_47
LBB0_50:                                ; %cond.store66
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x22, x20, #20
	st1.s	{ v26 }[1], [x22]
	tbnz	w21, #6, LBB0_48
LBB0_51:                                ; %else69
                                        ;   in Loop: Header=BB0_5 Depth=1
	tbz	w21, #7, LBB0_4
LBB0_52:                                ; %cond.store70
                                        ;   in Loop: Header=BB0_5 Depth=1
	add	x20, x20, #28
	st1.s	{ v26 }[3], [x20]
	b	LBB0_4
LBB0_53:                                ; %direct.schedule.8.preheader
	mov	x11, #0                         ; =0x0
	add	x13, x12, x15
	ldr	q19, [x16, lCPI0_6@PAGEOFF]
	and.16b	v19, v17, v19
	addv.8h	h19, v19
	fmov	w14, s19
	add	x15, sp, #816
	b	LBB0_55
LBB0_54:                                ; %else162
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x16, x15, x11
	stp	q22, q23, [x16]
	add	x11, x11, #32
	cmp	x11, #256
	b.eq	LBB0_71
LBB0_55:                                ; %direct.true40
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x11
	add	x0, x15, x11
	ldr	q22, [x0]
	tbz	w14, #0, LBB0_63
; %bb.56:                               ; %cond.load140
                                        ;   in Loop: Header=BB0_55 Depth=1
	ld1.s	{ v22 }[0], [x16]
	and	w17, w14, #0xff
	tbnz	w17, #1, LBB0_64
LBB0_57:                                ; %else144
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w17, #2, LBB0_65
LBB0_58:                                ; %cond.load146
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x1, x16, #8
	ld1.s	{ v22 }[2], [x1]
	tbnz	w17, #3, LBB0_66
LBB0_59:                                ; %else150
                                        ;   in Loop: Header=BB0_55 Depth=1
	ldr	q23, [x0, #16]
	tbz	w17, #4, LBB0_67
LBB0_60:                                ; %cond.load152
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x0, x16, #16
	ld1.s	{ v23 }[0], [x0]
	tbnz	w17, #5, LBB0_68
LBB0_61:                                ; %else156
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w17, #6, LBB0_69
LBB0_62:                                ; %cond.load158
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x0, x16, #24
	ld1.s	{ v23 }[2], [x0]
	tbz	w17, #7, LBB0_54
	b	LBB0_70
LBB0_63:                                ; %else141
                                        ;   in Loop: Header=BB0_55 Depth=1
	and	w17, w14, #0xff
	tbz	w17, #1, LBB0_57
LBB0_64:                                ; %cond.load143
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x1, x16, #4
	ld1.s	{ v22 }[1], [x1]
	tbnz	w17, #2, LBB0_58
LBB0_65:                                ; %else147
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w17, #3, LBB0_59
LBB0_66:                                ; %cond.load149
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x1, x16, #12
	ld1.s	{ v22 }[3], [x1]
	ldr	q23, [x0, #16]
	tbnz	w17, #4, LBB0_60
LBB0_67:                                ; %else153
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w17, #5, LBB0_61
LBB0_68:                                ; %cond.load155
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x0, x16, #20
	ld1.s	{ v23 }[1], [x0]
	tbnz	w17, #6, LBB0_62
LBB0_69:                                ; %else159
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w17, #7, LBB0_54
LBB0_70:                                ; %cond.load161
                                        ;   in Loop: Header=BB0_55 Depth=1
	add	x16, x16, #28
	ld1.s	{ v23 }[3], [x16]
	b	LBB0_54
LBB0_71:                                ; %direct.false41
	xtn.8b	v2, v17
	sshll.2d	v5, v0, #0
	sshll.2d	v6, v1, #0
	movi.8b	v7, #1
	and.8b	v7, v2, v7
	umov.b	w14, v7[0]
	movi.2d	v27, #0000000000000000
	mov.b	v27[0], v2[0]
	movi.2d	v7, #0000000000000000
	umaxv.8b	b16, v27
	fmov	w16, s16
	rbit	w11, w14
	clz	w11, w11
	tst	w16, #0x1
	csel	w11, w11, wzr, ne
	mov	w13, #64                        ; =0x40
	dup.2d	v23, x13
	fmov	x13, d18
	add	x13, x13, x13, lsl #6
	fmov	d22, x13
	mov.d	x13, v18[1]
	add	x13, x13, x13, lsl #6
	mov.d	v22[1], x13
	ldr	q16, [sp, #112]                 ; 16-byte Reload
	add.2d	v16, v22, v16
	add.2d	v17, v16, v23
	movi.2d	v16, #0000000000000000
	mov.b	v16[0], v2[0]
	ushll.2d	v2, v16, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	str	q17, [sp, #144]                 ; 16-byte Spill
	and.16b	v2, v2, v17
	stp	q7, q7, [sp, #416]
	stp	q2, q7, [sp, #384]
	ubfiz	x17, x11, #3, #3
	add	x13, sp, #384
	ldr	x13, [x13, x17]
	sub	x13, x13, x11
	lsl	x13, x13, #2
	add	x15, x12, x13
	mov	w12, #256                       ; =0x100
	dup.2d	v2, x12
Lloh12:
	adrp	x12, lCPI0_7@PAGE
Lloh13:
	ldr	q7, [x12, lCPI0_7@PAGEOFF]
	bsl.16b	v6, v7, v2
Lloh14:
	adrp	x12, lCPI0_8@PAGE
Lloh15:
	ldr	q7, [x12, lCPI0_8@PAGEOFF]
	bsl.16b	v5, v7, v2
Lloh16:
	adrp	x12, lCPI0_9@PAGE
Lloh17:
	ldr	q7, [x12, lCPI0_9@PAGEOFF]
	bif.16b	v7, v2, v21
Lloh18:
	adrp	x12, lCPI0_10@PAGE
Lloh19:
	ldr	q16, [x12, lCPI0_10@PAGEOFF]
	bit.16b	v2, v16, v20
	stp	q5, q2, [sp, #480]
	stp	q6, q7, [sp, #448]
	add	x12, sp, #448
	ldr	x12, [x12, x17]
	sub	x12, x12, w11, uxtw #2
	tst	w14, #0x1
	csel	x12, xzr, x12, eq
	add	x17, sp, #816
	add	x17, x17, x12
	ldr	q5, [x17]
	tbz	w16, #0, LBB0_79
; %bb.72:                               ; %cond.load165
	ld1.s	{ v5 }[0], [x15]
	tbnz	w14, #1, LBB0_80
LBB0_73:                                ; %else169
	tbz	w14, #2, LBB0_81
LBB0_74:                                ; %cond.load171
	add	x16, x15, #8
	ld1.s	{ v5 }[2], [x16]
	tbnz	w14, #3, LBB0_82
LBB0_75:                                ; %else175
	ldr	q6, [x17, #16]
	tbz	w14, #4, LBB0_83
LBB0_76:                                ; %cond.load177
	add	x16, x15, #16
	ld1.s	{ v6 }[0], [x16]
	tbnz	w14, #5, LBB0_84
LBB0_77:                                ; %else181
	movi.2s	v16, #65
	tbz	w14, #6, LBB0_85
LBB0_78:                                ; %cond.load183
	add	x16, x15, #24
	ld1.s	{ v6 }[2], [x16]
	ldr	d2, [sp, #128]                  ; 8-byte Reload
	umlal.2d	v3, v2, v16
	umlal.2d	v4, v26, v16
	umlal.2d	v24, v25, v16
	tbnz	w14, #7, LBB0_86
	b	LBB0_87
LBB0_79:                                ; %else166
	tbz	w14, #1, LBB0_73
LBB0_80:                                ; %cond.load168
	add	x16, x15, #4
	ld1.s	{ v5 }[1], [x16]
	tbnz	w14, #2, LBB0_74
LBB0_81:                                ; %else172
	tbz	w14, #3, LBB0_75
LBB0_82:                                ; %cond.load174
	add	x16, x15, #12
	ld1.s	{ v5 }[3], [x16]
	ldr	q6, [x17, #16]
	tbnz	w14, #4, LBB0_76
LBB0_83:                                ; %else178
	tbz	w14, #5, LBB0_77
LBB0_84:                                ; %cond.load180
	add	x16, x15, #20
	ld1.s	{ v6 }[1], [x16]
	movi.2s	v16, #65
	tbnz	w14, #6, LBB0_78
LBB0_85:                                ; %else184
	ldr	d2, [sp, #128]                  ; 8-byte Reload
	umlal.2d	v3, v2, v16
	umlal.2d	v4, v26, v16
	umlal.2d	v24, v25, v16
	tbz	w14, #7, LBB0_87
LBB0_86:                                ; %cond.load186
	add	x14, x15, #28
	ld1.s	{ v6 }[3], [x14]
LBB0_87:                                ; %else187
	mov	x0, #0                          ; =0x0
	add.2d	v7, v3, v23
	add.2d	v2, v4, v23
	stp	q2, q7, [sp, #112]              ; 32-byte Folded Spill
	add.2d	v2, v24, v23
	stp	q5, q2, [sp, #64]               ; 32-byte Folded Spill
	add	x14, sp, #816
	add	x14, x14, x12
	str	q6, [sp, #48]                   ; 16-byte Spill
	stp	q5, q6, [x14]
	fmov	x14, d22
	lsl	x14, x14, #2
	add	x15, x9, x14
	ushll2.2d	v2, v0, #0
	mov	w16, #1                         ; =0x1
	dup.2d	v3, x16
	and.16b	v5, v2, v3
	ushll2.2d	v2, v1, #0
	and.16b	v6, v2, v3
	ushll.2d	v2, v0, #0
	and.16b	v7, v2, v3
	ushll.2d	v2, v1, #0
	and.16b	v21, v2, v3
	movi.2d	v2, #0000000000000000
	fmov	w16, s19
	add	x17, sp, #528
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v16, #0000000000000000
	b	LBB0_89
LBB0_88:                                ; %else212
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x0, x17, x0
	stp	q22, q23, [x0]
	add.2d	v3, v3, v6
	add.2d	v4, v4, v7
	add.2d	v16, v16, v5
	add.2d	v2, v2, v21
	fmov	x0, d2
	cmp	x0, #8
	b.ge	LBB0_105
LBB0_89:                                ; %direct.true62
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x0, x0, #5
	add	x1, x15, x0
	add	x3, x17, x0
	ldr	q22, [x3]
	tbz	w16, #0, LBB0_97
; %bb.90:                               ; %cond.load190
                                        ;   in Loop: Header=BB0_89 Depth=1
	ld1.s	{ v22 }[0], [x1]
	and	w2, w16, #0xff
	tbnz	w2, #1, LBB0_98
LBB0_91:                                ; %else194
                                        ;   in Loop: Header=BB0_89 Depth=1
	tbz	w2, #2, LBB0_99
LBB0_92:                                ; %cond.load196
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x4, x1, #8
	ld1.s	{ v22 }[2], [x4]
	tbnz	w2, #3, LBB0_100
LBB0_93:                                ; %else200
                                        ;   in Loop: Header=BB0_89 Depth=1
	ldr	q23, [x3, #16]
	tbz	w2, #4, LBB0_101
LBB0_94:                                ; %cond.load202
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x3, x1, #16
	ld1.s	{ v23 }[0], [x3]
	tbnz	w2, #5, LBB0_102
LBB0_95:                                ; %else206
                                        ;   in Loop: Header=BB0_89 Depth=1
	tbz	w2, #6, LBB0_103
LBB0_96:                                ; %cond.load208
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x3, x1, #24
	ld1.s	{ v23 }[2], [x3]
	tbz	w2, #7, LBB0_88
	b	LBB0_104
LBB0_97:                                ; %else191
                                        ;   in Loop: Header=BB0_89 Depth=1
	and	w2, w16, #0xff
	tbz	w2, #1, LBB0_91
LBB0_98:                                ; %cond.load193
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x4, x1, #4
	ld1.s	{ v22 }[1], [x4]
	tbnz	w2, #2, LBB0_92
LBB0_99:                                ; %else197
                                        ;   in Loop: Header=BB0_89 Depth=1
	tbz	w2, #3, LBB0_93
LBB0_100:                               ; %cond.load199
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x4, x1, #12
	ld1.s	{ v22 }[3], [x4]
	ldr	q23, [x3, #16]
	tbnz	w2, #4, LBB0_94
LBB0_101:                               ; %else203
                                        ;   in Loop: Header=BB0_89 Depth=1
	tbz	w2, #5, LBB0_95
LBB0_102:                               ; %cond.load205
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x3, x1, #20
	ld1.s	{ v23 }[1], [x3]
	tbnz	w2, #6, LBB0_96
LBB0_103:                               ; %else209
                                        ;   in Loop: Header=BB0_89 Depth=1
	tbz	w2, #7, LBB0_88
LBB0_104:                               ; %cond.load211
                                        ;   in Loop: Header=BB0_89 Depth=1
	add	x1, x1, #28
	ld1.s	{ v23 }[3], [x1]
	b	LBB0_88
LBB0_105:                               ; %direct.false63
	add	x9, x9, x13
	add	x13, sp, #528
	add	x13, x13, x12
	ldr	q4, [x13]
	ldr	d2, [x10, lCPI0_11@PAGEOFF]
	shl.8b	v3, v27, #7
	cmlt.8b	v3, v3, #0
	and.8b	v2, v3, v2
	addv.8b	b2, v2
	str	d2, [sp, #8]                    ; 8-byte Spill
	fmov	w10, s2
	tbz	w10, #0, LBB0_113
; %bb.106:                              ; %cond.load215
	ld1.s	{ v4 }[0], [x9]
	tbnz	w10, #1, LBB0_114
LBB0_107:                               ; %else219
	tbz	w10, #2, LBB0_115
LBB0_108:                               ; %cond.load221
	add	x15, x9, #8
	ld1.s	{ v4 }[2], [x15]
	tbnz	w10, #3, LBB0_116
LBB0_109:                               ; %else225
	ldr	q2, [x13, #16]
	tbz	w10, #4, LBB0_117
LBB0_110:                               ; %cond.load227
	add	x13, x9, #16
	ld1.s	{ v2 }[0], [x13]
	tbnz	w10, #5, LBB0_118
LBB0_111:                               ; %else231
	tbz	w10, #6, LBB0_119
LBB0_112:                               ; %cond.load233
	add	x13, x9, #24
	ld1.s	{ v2 }[2], [x13]
	str	q27, [sp, #96]                  ; 16-byte Spill
	tbnz	w10, #7, LBB0_120
	b	LBB0_121
LBB0_113:                               ; %else216
	tbz	w10, #1, LBB0_107
LBB0_114:                               ; %cond.load218
	add	x15, x9, #4
	ld1.s	{ v4 }[1], [x15]
	tbnz	w10, #2, LBB0_108
LBB0_115:                               ; %else222
	tbz	w10, #3, LBB0_109
LBB0_116:                               ; %cond.load224
	add	x15, x9, #12
	ld1.s	{ v4 }[3], [x15]
	ldr	q2, [x13, #16]
	tbnz	w10, #4, LBB0_110
LBB0_117:                               ; %else228
	tbz	w10, #5, LBB0_111
LBB0_118:                               ; %cond.load230
	add	x13, x9, #20
	ld1.s	{ v2 }[1], [x13]
	tbnz	w10, #6, LBB0_112
LBB0_119:                               ; %else234
	str	q27, [sp, #96]                  ; 16-byte Spill
	tbz	w10, #7, LBB0_121
LBB0_120:                               ; %cond.load236
	add	x9, x9, #28
	ld1.s	{ v2 }[3], [x9]
LBB0_121:                               ; %else237
	mov	x15, #0                         ; =0x0
	add	x9, sp, #528
	add	x10, x9, x12
	stp	q2, q4, [sp, #16]               ; 32-byte Folded Spill
	stp	q4, q2, [x10]
	add	x10, x8, x14
	movi.2d	v25, #0000000000000000
	fmov	w12, s19
	mov	w13, #-1026555904               ; =0xc2d00000
	dup.4s	v19, w13
	mov	w13, #1120403456                ; =0x42c80000
	dup.4s	v26, w13
	mov	w13, #43579                     ; =0xaa3b
	movk	w13, #16312, lsl #16
	dup.4s	v27, w13
	mov	w13, #29184                     ; =0x7200
	movk	w13, #48945, lsl #16
	dup.4s	v28, w13
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #46527, lsl #16
	dup.4s	v29, w13
	mov	w13, #11226                     ; =0x2bda
	movk	w13, #14672, lsl #16
	dup.4s	v30, w13
	mov	w13, #38601                     ; =0x96c9
	movk	w13, #15030, lsl #16
	dup.4s	v31, w13
	mov	w13, #34982                     ; =0x88a6
	movk	w13, #15368, lsl #16
	dup.4s	v8, w13
	mov	w13, #43642                     ; =0xaa7a
	movk	w13, #15658, lsl #16
	dup.4s	v9, w13
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15914, lsl #16
	dup.4s	v10, w13
	add	x13, sp, #816
	movi.4s	v11, #75, lsl #24
	mvni.4s	v12, #128, lsl #24
	movi.4s	v13, #63, lsl #24
	fmov.4s	v14, #1.00000000
	mvni.4s	v2, #127, msl #16
	fneg.4s	v15, v2
	mvni.4s	v2, #63, msl #16
	fneg.4s	v2, v2
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v16, #0000000000000000
	b	LBB0_123
LBB0_122:                               ; %else255
                                        ;   in Loop: Header=BB0_123 Depth=1
	add.2d	v3, v3, v6
	add.2d	v4, v4, v7
	add.2d	v16, v16, v5
	add.2d	v25, v25, v21
	fmov	x15, d25
	cmp	x15, #8
	b.ge	LBB0_139
LBB0_123:                               ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x14, x15, #5
	add	x16, x13, x14
	ldr	q24, [x16]
	and.16b	v24, v1, v24
	fneg.4s	v17, v24
	and.16b	v17, v1, v17
	fcmge.4s	v18, v17, v19
	fcmge.4s	v20, v26, v17
	and.16b	v18, v18, v20
	and.16b	v18, v18, v17
	fmul.4s	v20, v18, v27
	mov.16b	v22, v12
	bsl.16b	v22, v11, v20
	fadd.4s	v20, v20, v22
	fsub.4s	v20, v20, v22
	fcvtzs.4s	v20, v20
	scvtf.4s	v22, v20
	fmul.4s	v23, v22, v28
	fadd.4s	v18, v18, v23
	fmul.4s	v22, v22, v29
	fadd.4s	v18, v18, v22
	fmul.4s	v22, v18, v30
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v18, v22
	fadd.4s	v22, v22, v8
	fmul.4s	v22, v18, v22
	fadd.4s	v22, v22, v9
	fmul.4s	v22, v18, v22
	fadd.4s	v22, v22, v10
	fmul.4s	v22, v18, v22
	fadd.4s	v22, v22, v13
	fmul.4s	v23, v18, v18
	fmul.4s	v22, v23, v22
	fadd.4s	v18, v18, v22
	fadd.4s	v18, v18, v14
	sshr.4s	v22, v20, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v14
	fmul.4s	v18, v18, v23
	sub.4s	v20, v20, v22
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v14
	fmul.4s	v18, v18, v20
	fcmgt.4s	v20, v19, v17
	fcmgt.4s	v22, v17, v26
	fcmeq.4s	v17, v17, v17
	fadd.4s	v18, v18, v14
	bit.16b	v18, v14, v20
	bit.16b	v18, v15, v22
	bsl.16b	v17, v18, v2
	fdiv.4s	v17, v24, v17
	add	x17, x9, x14
	ldr	q18, [x17]
	and.16b	v18, v1, v18
	fmul.4s	v24, v18, v17
	add	x14, x10, x14
	tbz	w12, #0, LBB0_127
; %bb.124:                              ; %cond.store240
                                        ;   in Loop: Header=BB0_123 Depth=1
	str	s24, [x14]
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_128
LBB0_125:                               ; %else243
                                        ;   in Loop: Header=BB0_123 Depth=1
	tbz	w15, #2, LBB0_129
LBB0_126:                               ; %cond.store244
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x0, x14, #8
	st1.s	{ v24 }[2], [x0]
	tbnz	w15, #3, LBB0_130
	b	LBB0_131
LBB0_127:                               ; %else241
                                        ;   in Loop: Header=BB0_123 Depth=1
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_125
LBB0_128:                               ; %cond.store242
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x0, x14, #4
	st1.s	{ v24 }[1], [x0]
	tbnz	w15, #2, LBB0_126
LBB0_129:                               ; %else245
                                        ;   in Loop: Header=BB0_123 Depth=1
	tbz	w15, #3, LBB0_131
LBB0_130:                               ; %cond.store246
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x0, x14, #12
	st1.s	{ v24 }[3], [x0]
LBB0_131:                               ; %else247
                                        ;   in Loop: Header=BB0_123 Depth=1
	ldr	q17, [x16, #16]
	and.16b	v17, v0, v17
	fneg.4s	v18, v17
	and.16b	v18, v0, v18
	fcmge.4s	v20, v18, v19
	fcmge.4s	v22, v26, v18
	and.16b	v20, v20, v22
	and.16b	v20, v20, v18
	fmul.4s	v22, v20, v27
	mov.16b	v23, v12
	bsl.16b	v23, v11, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v22, v22
	scvtf.4s	v23, v22
	fmul.4s	v24, v23, v28
	fadd.4s	v20, v20, v24
	fmul.4s	v23, v23, v29
	fadd.4s	v20, v20, v23
	fmul.4s	v23, v20, v30
	fadd.4s	v23, v23, v31
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v8
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v9
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v20, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v24, v20, v20
	fmul.4s	v23, v24, v23
	fadd.4s	v20, v20, v23
	fadd.4s	v20, v20, v14
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v14
	fmul.4s	v20, v20, v24
	sub.4s	v22, v22, v23
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v14
	fmul.4s	v20, v20, v22
	fcmgt.4s	v22, v19, v18
	fcmgt.4s	v23, v18, v26
	fcmeq.4s	v18, v18, v18
	fadd.4s	v20, v20, v14
	bit.16b	v20, v14, v22
	bit.16b	v20, v15, v23
	bsl.16b	v18, v20, v2
	fdiv.4s	v17, v17, v18
	ldr	q18, [x17, #16]
	and.16b	v18, v0, v18
	fmul.4s	v24, v18, v17
	tbz	w15, #4, LBB0_135
; %bb.132:                              ; %cond.store248
                                        ;   in Loop: Header=BB0_123 Depth=1
	str	s24, [x14, #16]
	tbnz	w15, #5, LBB0_136
LBB0_133:                               ; %else251
                                        ;   in Loop: Header=BB0_123 Depth=1
	tbz	w15, #6, LBB0_137
LBB0_134:                               ; %cond.store252
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x16, x14, #24
	st1.s	{ v24 }[2], [x16]
	tbz	w15, #7, LBB0_122
	b	LBB0_138
LBB0_135:                               ; %else249
                                        ;   in Loop: Header=BB0_123 Depth=1
	tbz	w15, #5, LBB0_133
LBB0_136:                               ; %cond.store250
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x16, x14, #20
	st1.s	{ v24 }[1], [x16]
	tbnz	w15, #6, LBB0_134
LBB0_137:                               ; %else253
                                        ;   in Loop: Header=BB0_123 Depth=1
	tbz	w15, #7, LBB0_122
LBB0_138:                               ; %cond.store254
                                        ;   in Loop: Header=BB0_123 Depth=1
	add	x14, x14, #28
	st1.s	{ v24 }[3], [x14]
	b	LBB0_122
LBB0_139:                               ; %direct.false84
	ldr	d0, [sp, #8]                    ; 8-byte Reload
	fmov	w9, s0
	ldr	q1, [sp, #96]                   ; 16-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v3, v0, #0
	ldr	q0, [sp, #64]                   ; 16-byte Reload
	and.16b	v4, v3, v0
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q1, [sp, #48]                   ; 16-byte Reload
	and.16b	v1, v0, v1
	fneg.4s	v2, v1
	fneg.4s	v5, v4
	and.16b	v5, v3, v5
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v6, w10
	and.16b	v2, v0, v2
	fcmge.4s	v16, v2, v6
	fcmge.4s	v17, v5, v6
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v7, w10
	fcmge.4s	v18, v7, v2
	fcmge.4s	v19, v7, v5
	and.16b	v17, v17, v19
	and.16b	v16, v16, v18
	and.16b	v16, v16, v2
	and.16b	v17, v17, v5
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v18, w10
	fmul.4s	v19, v17, v18
	fmul.4s	v18, v16, v18
	movi.4s	v20, #75, lsl #24
	mvni.4s	v21, #128, lsl #24
	mov.16b	v22, v21
	bsl.16b	v22, v20, v18
	bif.16b	v20, v19, v21
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v19, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v20, v18
	scvtf.4s	v21, v19
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v22, w10
	fmul.4s	v23, v21, v22
	fmul.4s	v22, v20, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v17, v17, v23
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v22, w10
	fmul.4s	v20, v20, v22
	fmul.4s	v21, v21, v22
	fadd.4s	v17, v17, v21
	fadd.4s	v16, v16, v20
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v20, w10
	fmul.4s	v21, v16, v20
	fmul.4s	v20, v17, v20
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v22, w10
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v22, w10
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v22, w10
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v22, w10
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	movi.4s	v22, #63, lsl #24
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v22, v17, v17
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v21
	fmov.4s	v20, #1.00000000
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v20
	sshr.4s	v21, v18, #1
	sshr.4s	v22, v19, #1
	shl.4s	v23, v22, #23
	shl.4s	v24, v21, #23
	add.4s	v24, v24, v20
	add.4s	v23, v23, v20
	fmul.4s	v17, v17, v23
	fmul.4s	v16, v16, v24
	sub.4s	v19, v19, v22
	sub.4s	v18, v18, v21
	shl.4s	v18, v18, #23
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v20
	add.4s	v18, v18, v20
	fmul.4s	v16, v16, v18
	fmul.4s	v17, v17, v19
	fcmgt.4s	v18, v6, v5
	fcmgt.4s	v19, v6, v2
	fcmgt.4s	v6, v2, v7
	fcmgt.4s	v21, v5, v7
	fcmeq.4s	v22, v5, v5
	fadd.4s	v5, v17, v20
	fadd.4s	v7, v16, v20
	bit.16b	v7, v20, v19
	bit.16b	v5, v20, v18
	mvni.4s	v16, #127, msl #16
	fneg.4s	v16, v16
	mov.16b	v17, v21
	bsl.16b	v17, v16, v5
	mvni.4s	v5, #63, msl #16
	fneg.4s	v5, v5
	bif.16b	v17, v5, v22
	fdiv.4s	v4, v4, v17
	ldr	q17, [sp, #32]                  ; 16-byte Reload
	and.16b	v3, v3, v17
	fmul.4s	v3, v4, v3
	ldr	q4, [sp, #144]                  ; 16-byte Reload
	str	q4, [sp, #304]
	ldr	q4, [sp, #128]                  ; 16-byte Reload
	str	q4, [sp, #320]
	ldr	q4, [sp, #112]                  ; 16-byte Reload
	str	q4, [sp, #336]
	ldr	q4, [sp, #80]                   ; 16-byte Reload
	str	q4, [sp, #352]
	and	x10, x11, #0x7
	add	x12, sp, #304
	ldr	x10, [x12, x10, lsl #3]
	sub	x10, x10, x11
	add	x8, x8, x10, lsl #2
	tbz	w9, #0, LBB0_147
; %bb.140:                              ; %cond.store257
	str	s3, [x8]
	fcmeq.4s	v2, v2, v2
	mov.16b	v4, v6
	bsl.16b	v4, v16, v7
	tbnz	w9, #1, LBB0_148
LBB0_141:                               ; %else260
	bsl.16b	v2, v4, v5
	tbz	w9, #2, LBB0_149
LBB0_142:                               ; %cond.store261
	add	x10, x8, #8
	st1.s	{ v3 }[2], [x10]
	fdiv.4s	v1, v1, v2
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v0, v0, v2
	tbnz	w9, #3, LBB0_150
LBB0_143:                               ; %else264
	fmul.4s	v0, v1, v0
	tbz	w9, #4, LBB0_186
LBB0_144:                               ; %cond.store265
	str	s0, [x8, #16]
	tbnz	w9, #5, LBB0_187
LBB0_145:                               ; %else268
	tbz	w9, #6, LBB0_188
LBB0_146:                               ; %cond.store135
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB0_189
	b	LBB0_190
LBB0_147:                               ; %else258
	fcmeq.4s	v2, v2, v2
	mov.16b	v4, v6
	bsl.16b	v4, v16, v7
	tbz	w9, #1, LBB0_141
LBB0_148:                               ; %cond.store259
	add	x10, x8, #4
	st1.s	{ v3 }[1], [x10]
	bsl.16b	v2, v4, v5
	tbnz	w9, #2, LBB0_142
LBB0_149:                               ; %else262
	fdiv.4s	v1, v1, v2
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v0, v0, v2
	tbz	w9, #3, LBB0_143
LBB0_150:                               ; %cond.store263
	add	x10, x8, #12
	st1.s	{ v3 }[3], [x10]
	fmul.4s	v0, v1, v0
	tbz	w9, #4, LBB0_186
	b	LBB0_144
LBB0_151:                               ; %direct.false21
	xtn.8b	v0, v17
	movi.8b	v1, #1
	and.8b	v1, v0, v1
	umov.b	w14, v1[0]
	movi.2d	v1, #0000000000000000
	movi.2d	v20, #0000000000000000
	mov.b	v20[0], v0[0]
	umaxv.8b	b2, v20
	fmov	w15, s2
	rbit	w11, w14
	clz	w11, w11
	tst	w15, #0x1
	mov	w13, #64                        ; =0x40
	dup.2d	v17, x13
	csel	w11, w11, wzr, ne
	fmov	x13, d18
	add	x13, x13, x13, lsl #6
	fmov	d2, x13
	mov.d	x13, v18[1]
	add	x13, x13, x13, lsl #6
	mov.d	v2[1], x13
	ldr	q5, [sp, #112]                  ; 16-byte Reload
	add.2d	v2, v2, v5
	add.2d	v16, v2, v17
	movi.2d	v2, #0000000000000000
	mov.b	v2[0], v0[0]
	ushll.2d	v0, v2, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	and.16b	v0, v0, v16
	stp	q1, q1, [sp, #256]
	stp	q0, q1, [sp, #224]
	and	x13, x11, #0x7
	add	x16, sp, #224
	ldr	x13, [x16, x13, lsl #3]
	sub	x13, x13, x11
	lsl	x13, x13, #2
	add	x12, x12, x13
	movi.2d	v0, #0000000000000000
	tbz	w15, #0, LBB0_159
; %bb.152:                              ; %cond.load73
	ldr	s1, [x12]
	tbnz	w14, #1, LBB0_160
LBB0_153:                               ; %else77
	tbz	w14, #2, LBB0_161
LBB0_154:                               ; %cond.load79
	add	x15, x12, #8
	ld1.s	{ v1 }[2], [x15]
	tbnz	w14, #3, LBB0_162
LBB0_155:                               ; %else83
	tbz	w14, #4, LBB0_163
LBB0_156:                               ; %cond.load85
	add	x15, x12, #16
	ld1.s	{ v0 }[0], [x15]
	tbnz	w14, #5, LBB0_164
LBB0_157:                               ; %else89
	tbz	w14, #6, LBB0_165
LBB0_158:                               ; %cond.load91
	add	x15, x12, #24
	ld1.s	{ v0 }[2], [x15]
	tbnz	w14, #7, LBB0_166
	b	LBB0_167
LBB0_159:                               ; %else74
	tbz	w14, #1, LBB0_153
LBB0_160:                               ; %cond.load76
	add	x15, x12, #4
	ld1.s	{ v1 }[1], [x15]
	tbnz	w14, #2, LBB0_154
LBB0_161:                               ; %else80
	tbz	w14, #3, LBB0_155
LBB0_162:                               ; %cond.load82
	add	x15, x12, #12
	ld1.s	{ v1 }[3], [x15]
	tbnz	w14, #4, LBB0_156
LBB0_163:                               ; %else86
	tbz	w14, #5, LBB0_157
LBB0_164:                               ; %cond.load88
	add	x15, x12, #20
	ld1.s	{ v0 }[1], [x15]
	tbnz	w14, #6, LBB0_158
LBB0_165:                               ; %else92
	tbz	w14, #7, LBB0_167
LBB0_166:                               ; %cond.load94
	add	x12, x12, #28
	ld1.s	{ v0 }[3], [x12]
LBB0_167:                               ; %else95
	fneg.4s	v2, v1
	fneg.4s	v5, v0
	ldr	d6, [x10, lCPI0_11@PAGEOFF]
	shl.8b	v7, v20, #7
	cmlt.8b	v7, v7, #0
	and.8b	v6, v7, v6
	addv.8b	b19, v6
	fmov	w10, s19
	zip2.8b	v6, v20, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v18, v6, v5
	zip1.8b	v5, v20, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v23, v5, v2
	mov	w12, #-1026555904               ; =0xc2d00000
	dup.4s	v21, w12
	fcmge.4s	v2, v23, v21
	fcmge.4s	v5, v18, v21
	mov	w12, #1120403456                ; =0x42c80000
	dup.4s	v20, w12
	fcmge.4s	v6, v20, v23
	fcmge.4s	v7, v20, v18
	and.16b	v5, v5, v7
	and.16b	v2, v2, v6
	and.16b	v2, v2, v23
	and.16b	v5, v5, v18
	mov	w12, #43579                     ; =0xaa3b
	movk	w12, #16312, lsl #16
	dup.4s	v6, w12
	fmul.4s	v7, v5, v6
	fmul.4s	v6, v2, v6
	movi.4s	v22, #75, lsl #24
	mvni.4s	v24, #128, lsl #24
	mov.16b	v25, v24
	bsl.16b	v25, v22, v6
	bif.16b	v22, v7, v24
	fadd.4s	v7, v7, v22
	fadd.4s	v6, v6, v25
	fsub.4s	v6, v6, v25
	fsub.4s	v7, v7, v22
	fcvtzs.4s	v26, v7
	fcvtzs.4s	v6, v6
	scvtf.4s	v7, v6
	mov	w12, #29184                     ; =0x7200
	movk	w12, #48945, lsl #16
	dup.4s	v22, w12
	scvtf.4s	v24, v26
	fmul.4s	v25, v24, v22
	fmul.4s	v22, v7, v22
	fadd.4s	v2, v2, v22
	fadd.4s	v5, v5, v25
	mov	w12, #48782                     ; =0xbe8e
	movk	w12, #46527, lsl #16
	dup.4s	v22, w12
	fmul.4s	v7, v7, v22
	fmul.4s	v22, v24, v22
	fadd.4s	v27, v5, v22
	fadd.4s	v2, v2, v7
	mov	w12, #11226                     ; =0x2bda
	movk	w12, #14672, lsl #16
	dup.4s	v5, w12
	fmul.4s	v7, v2, v5
	fmul.4s	v5, v27, v5
	mov	w12, #38601                     ; =0x96c9
	movk	w12, #15030, lsl #16
	dup.4s	v22, w12
	fadd.4s	v5, v5, v22
	fadd.4s	v7, v7, v22
	fmul.4s	v7, v2, v7
	fmul.4s	v5, v27, v5
	mov	w12, #34982                     ; =0x88a6
	movk	w12, #15368, lsl #16
	dup.4s	v22, w12
	fadd.4s	v5, v5, v22
	fadd.4s	v7, v7, v22
	fmul.4s	v7, v2, v7
	fmul.4s	v5, v27, v5
	mov	w12, #43642                     ; =0xaa7a
	movk	w12, #15658, lsl #16
	dup.4s	v22, w12
	fadd.4s	v5, v5, v22
	fadd.4s	v7, v7, v22
	fmul.4s	v7, v2, v7
	fmul.4s	v5, v27, v5
	mov	w12, #43691                     ; =0xaaab
	movk	w12, #15914, lsl #16
	dup.4s	v22, w12
	fadd.4s	v5, v5, v22
	fadd.4s	v7, v7, v22
	fmul.4s	v7, v2, v7
	fmul.4s	v28, v27, v5
	movi.4s	v29, #63, lsl #24
	fadd.4s	v5, v7, v29
	fmul.4s	v7, v2, v2
	fmul.4s	v5, v7, v5
	fadd.4s	v2, v2, v5
	fmov.4s	v24, #1.00000000
	fadd.4s	v30, v2, v24
	sshr.4s	v2, v6, #1
	shl.4s	v5, v2, #23
	add.4s	v31, v5, v24
	sub.4s	v2, v6, v2
	shl.4s	v8, v2, #23
	add	x9, x9, x13
	movi.2d	v25, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbz	w10, #0, LBB0_192
; %bb.168:                              ; %cond.load98
	ldr	s25, [x9]
	fadd.4s	v28, v28, v29
	fmul.4s	v29, v27, v27
	fmul.4s	v30, v30, v31
	add.4s	v31, v8, v24
	tbnz	w10, #1, LBB0_193
LBB0_169:                               ; %else102
	fmul.4s	v28, v29, v28
	sshr.4s	v29, v26, #1
	fmul.4s	v30, v30, v31
	tbz	w10, #2, LBB0_171
LBB0_170:                               ; %cond.load104
	add	x12, x9, #8
	ld1.s	{ v25 }[2], [x12]
LBB0_171:                               ; %else105
	fadd.4s	v27, v27, v28
	shl.4s	v28, v29, #23
	sub.4s	v29, v26, v29
	fcmgt.4s	v26, v21, v23
	fadd.4s	v30, v30, v24
	mvni.4s	v31, #127, msl #16
	tbz	w10, #3, LBB0_173
; %bb.172:                              ; %cond.load107
	add	x12, x9, #12
	ld1.s	{ v25 }[3], [x12]
LBB0_173:                               ; %else108
	fadd.4s	v27, v27, v24
	add.4s	v28, v28, v24
	shl.4s	v8, v29, #23
	fcmgt.4s	v29, v23, v20
	bit.16b	v30, v24, v26
	fneg.4s	v26, v31
	mvni.4s	v9, #63, msl #16
	tbz	w10, #4, LBB0_175
; %bb.174:                              ; %cond.load110
	add	x12, x9, #16
	ld1.s	{ v22 }[0], [x12]
LBB0_175:                               ; %else111
	fmul.4s	v31, v27, v28
	add.4s	v8, v8, v24
	movi.2s	v27, #65
	fcmeq.4s	v28, v23, v23
	bit.16b	v30, v26, v29
	fneg.4s	v23, v9
	tbz	w10, #5, LBB0_177
; %bb.176:                              ; %cond.load113
	add	x12, x9, #20
	ld1.s	{ v22 }[1], [x12]
LBB0_177:                               ; %else114
	fmul.4s	v29, v31, v8
	ldr	d2, [sp, #128]                  ; 8-byte Reload
	umlal.2d	v3, v2, v27
	ldr	d2, [sp, #80]                   ; 8-byte Reload
	umlal.2d	v4, v2, v27
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	ldr	d5, [sp, #96]                   ; 8-byte Reload
	umlal.2d	v2, v5, v27
	str	q2, [sp, #144]                  ; 16-byte Spill
	mov.16b	v5, v28
	bsl.16b	v5, v30, v23
	tbz	w10, #6, LBB0_179
; %bb.178:                              ; %cond.load116
	add	x12, x9, #24
	ld1.s	{ v22 }[2], [x12]
LBB0_179:                               ; %else117
	fcmgt.4s	v6, v21, v18
	fadd.4s	v7, v29, v24
	add.2d	v3, v3, v17
	add.2d	v4, v4, v17
	ldr	q2, [sp, #144]                  ; 16-byte Reload
	add.2d	v2, v2, v17
	fdiv.4s	v1, v1, v5
	tbz	w10, #7, LBB0_181
; %bb.180:                              ; %cond.load119
	add	x9, x9, #28
	ld1.s	{ v22 }[3], [x9]
LBB0_181:                               ; %else120
	fcmgt.4s	v5, v18, v20
	bsl.16b	v6, v24, v7
	fmul.4s	v1, v25, v1
	stp	q16, q3, [sp, #160]
	stp	q4, q2, [sp, #192]
	and	x9, x11, #0x7
	add	x10, sp, #160
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x11
	add	x8, x8, x9, lsl #2
	fmov	w9, s19
	tbz	w9, #0, LBB0_194
; %bb.182:                              ; %cond.store123
	str	s1, [x8]
	fcmeq.4s	v2, v18, v18
	mov.16b	v3, v5
	bsl.16b	v3, v26, v6
	tbnz	w9, #1, LBB0_195
LBB0_183:                               ; %else126
	bsl.16b	v2, v3, v23
	tbz	w9, #2, LBB0_196
LBB0_184:                               ; %cond.store127
	add	x10, x8, #8
	st1.s	{ v1 }[2], [x10]
	fdiv.4s	v0, v0, v2
	tbnz	w9, #3, LBB0_197
LBB0_185:                               ; %else130
	fmul.4s	v0, v22, v0
	tbnz	w9, #4, LBB0_144
LBB0_186:                               ; %else266
	tbz	w9, #5, LBB0_145
LBB0_187:                               ; %cond.store267
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbnz	w9, #6, LBB0_146
LBB0_188:                               ; %else270
	tbz	w9, #7, LBB0_190
LBB0_189:                               ; %cond.store271
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_190:
	add	sp, sp, #1104
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #112            ; 16-byte Folded Reload
LBB0_191:                               ; %common.ret
	ret
LBB0_192:                               ; %else99
	fadd.4s	v28, v28, v29
	fmul.4s	v29, v27, v27
	fmul.4s	v30, v30, v31
	add.4s	v31, v8, v24
	tbz	w10, #1, LBB0_169
LBB0_193:                               ; %cond.load101
	add	x12, x9, #4
	ld1.s	{ v25 }[1], [x12]
	fmul.4s	v28, v29, v28
	sshr.4s	v29, v26, #1
	fmul.4s	v30, v30, v31
	tbnz	w10, #2, LBB0_170
	b	LBB0_171
LBB0_194:                               ; %else124
	fcmeq.4s	v2, v18, v18
	mov.16b	v3, v5
	bsl.16b	v3, v26, v6
	tbz	w9, #1, LBB0_183
LBB0_195:                               ; %cond.store125
	add	x10, x8, #4
	st1.s	{ v1 }[1], [x10]
	bsl.16b	v2, v3, v23
	tbnz	w9, #2, LBB0_184
LBB0_196:                               ; %else128
	fdiv.4s	v0, v0, v2
	tbz	w9, #3, LBB0_185
LBB0_197:                               ; %cond.store129
	add	x10, x8, #12
	st1.s	{ v1 }[3], [x10]
	fmul.4s	v0, v22, v0
	tbz	w9, #4, LBB0_186
	b	LBB0_144
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

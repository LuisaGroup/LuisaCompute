	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_11:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI0_12:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI0_13:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI0_14:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
lCPI0_15:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_16:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v4, v1, v0
	umaxv.8h	h2, v4
	fmov	w8, s2
	tbz	w8, #0, LBB0_82
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1616
	mov	x11, #0                         ; =0x0
	ldr	x16, [x1, #136]
	mov	w8, #16416                      ; =0x4020
	add	x10, x16, x8
	mov	w8, #32832                      ; =0x8040
	add	x9, x16, x8
	mov	w8, #49248                      ; =0xc060
	add	x13, x16, x8
	ldr	x12, [x0]
	ldr	x15, [x0, #16]
	ldr	x14, [x0, #32]
	ldr	x8, [x0, #48]
Lloh4:
	adrp	x17, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x17, lCPI0_0@PAGEOFF]
	and.16b	v2, v4, v2
	addv.8h	h26, v2
	fmov	w17, s26
	and	w0, w17, #0xff
	ldr	w17, [x1]
	ldr	w1, [x1, #36]
	add	w17, w1, w17, lsl #5
	lsr	w17, w17, #3
	dup.4s	v2, w17
	and.16b	v16, v1, v2
	and.16b	v2, v0, v2
	ushll2.2d	v5, v2, #0
	ushll2.2d	v6, v16, #0
	ushll.2d	v7, v2, #0
	ushll.2d	v2, v16, #0
	fmov	x17, d2
	mov	w1, #16388                      ; =0x4004
	umaddl	x17, w17, w1, x12
	fmov	w1, s26
	b	LBB0_3
LBB0_2:                                 ; %else64
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x16, x11
	stp	q16, q17, [x2]
	add	x11, x11, #32
	cmp	x11, #4, lsl #12                ; =16384
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x2, x17, x11
	add	x4, x16, x11
	ldr	q16, [x4]
	tbnz	w1, #0, LBB0_11
; %bb.4:                                ; %else44
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w3, w1, #0xff
	tbnz	w3, #1, LBB0_12
LBB0_5:                                 ; %else46
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #2, LBB0_13
LBB0_6:                                 ; %else49
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #3, LBB0_14
LBB0_7:                                 ; %else52
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q17, [x4, #16]
	tbnz	w3, #4, LBB0_15
LBB0_8:                                 ; %else55
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #5, LBB0_16
LBB0_9:                                 ; %else58
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w3, #6, LBB0_17
LBB0_10:                                ; %else61
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w3, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v16 }[0], [x2]
	and	w3, w1, #0xff
	tbz	w3, #1, LBB0_5
LBB0_12:                                ; %cond.load45
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x5, x2, #4
	ld1.s	{ v16 }[1], [x5]
	tbz	w3, #2, LBB0_6
LBB0_13:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x5, x2, #8
	ld1.s	{ v16 }[2], [x5]
	tbz	w3, #3, LBB0_7
LBB0_14:                                ; %cond.load51
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x5, x2, #12
	ld1.s	{ v16 }[3], [x5]
	ldr	q17, [x4, #16]
	tbz	w3, #4, LBB0_8
LBB0_15:                                ; %cond.load54
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #16
	ld1.s	{ v17 }[0], [x4]
	tbz	w3, #5, LBB0_9
LBB0_16:                                ; %cond.load57
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #20
	ld1.s	{ v17 }[1], [x4]
	tbz	w3, #6, LBB0_10
LBB0_17:                                ; %cond.load60
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x4, x2, #24
	ld1.s	{ v17 }[2], [x4]
	tbz	w3, #7, LBB0_2
LBB0_18:                                ; %cond.load63
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x2, #28
	ld1.s	{ v17 }[3], [x2]
	b	LBB0_2
LBB0_19:                                ; %direct.true80.preheader
	xtn.8b	v30, v4
	sshll.2d	v4, v1, #0
	sshll.2d	v20, v0, #0
	sshll2.2d	v27, v1, #0
	sshll2.2d	v28, v0, #0
Lloh6:
	adrp	x11, lCPI0_6@PAGE
Lloh7:
	ldr	q16, [x11, lCPI0_6@PAGEOFF]
	and.16b	v29, v4, v16
	movi.2d	v17, #0000000000000000
Lloh8:
	adrp	x11, lCPI0_7@PAGE
Lloh9:
	ldr	q18, [x11, lCPI0_7@PAGEOFF]
	and.16b	v18, v4, v18
Lloh10:
	adrp	x11, lCPI0_8@PAGE
Lloh11:
	ldr	q4, [x11, lCPI0_8@PAGEOFF]
	and.16b	v4, v20, v4
Lloh12:
	adrp	x11, lCPI0_9@PAGE
Lloh13:
	ldr	q19, [x11, lCPI0_9@PAGEOFF]
	and.16b	v19, v27, v19
Lloh14:
	adrp	x11, lCPI0_10@PAGE
Lloh15:
	ldr	q21, [x11, lCPI0_10@PAGEOFF]
	and.16b	v21, v28, v21
	movi.8b	v22, #1
	and.8b	v22, v30, v22
	umov.b	w17, v22[0]
	movi.2d	v25, #0000000000000000
	movi.2d	v16, #0000000000000000
	mov.b	v16[0], v30[0]
	umaxv.8b	b22, v16
	fmov	w11, s22
	rbit	w1, w17
	clz	w1, w1
	tst	w11, #0x1
	csel	w3, w1, wzr, ne
	mov	w1, #4096                       ; =0x1000
	dup.2d	v24, x1
	orr.16b	v3, v29, v24
	mov	w1, #4097                       ; =0x1001
	dup.2s	v22, w1
	xtn.2s	v23, v2
	str	q3, [sp, #208]                  ; 16-byte Spill
	umlal.2d	v3, v23, v22
	str	q30, [sp, #336]                 ; 16-byte Spill
	mov.b	v25[0], v30[0]
	ushll.2d	v2, v25, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	str	q3, [sp, #304]                  ; 16-byte Spill
	and.16b	v2, v2, v3
	str	q17, [sp, #1520]
	str	q17, [sp, #1504]
	str	q17, [sp, #1488]
	str	q2, [sp, #1472]
	ubfiz	x2, x3, #3, #3
	add	x1, sp, #1472
	ldr	x1, [x1, x2]
	sub	x1, x1, x3
	add	x1, x12, x1, lsl #2
	str	q21, [sp, #1584]
	str	q4, [sp, #1568]
	str	q19, [sp, #1552]
	str	q18, [sp, #1536]
	add	x12, sp, #1536
	ldr	x12, [x12, x2]
	orr	x12, x12, #0x4000
	sub	x12, x12, w3, uxtw #2
	tst	w17, #0x1
	csel	x12, xzr, x12, eq
	add	x2, x16, x12
	ldr	q21, [x2]
	tbnz	w11, #0, LBB0_127
; %bb.20:                               ; %else68
	tbnz	w17, #1, LBB0_128
LBB0_21:                                ; %else71
	tbnz	w17, #2, LBB0_129
LBB0_22:                                ; %else74
	str	x3, [sp, #328]                  ; 8-byte Spill
	tbnz	w17, #3, LBB0_130
LBB0_23:                                ; %else77
	adrp	x11, lCPI0_3@PAGE
	adrp	x3, lCPI0_4@PAGE
	adrp	x4, lCPI0_5@PAGE
	ldr	q30, [x2, #16]
	tbnz	w17, #4, LBB0_131
LBB0_24:                                ; %else80
	ldr	q4, [x11, lCPI0_3@PAGEOFF]
	ldr	q19, [x3, lCPI0_4@PAGEOFF]
	ldr	q25, [x4, lCPI0_5@PAGEOFF]
	tbnz	w17, #5, LBB0_132
LBB0_25:                                ; %else83
	and.16b	v2, v28, v4
	and.16b	v3, v27, v19
	and.16b	v4, v20, v25
	tbz	w17, #6, LBB0_27
LBB0_26:                                ; %cond.load85
	add	x11, x1, #24
	ld1.s	{ v30 }[2], [x11]
LBB0_27:                                ; %else86
	stp	q4, q3, [sp, #96]               ; 32-byte Folded Spill
	orr.16b	v17, v4, v24
	orr.16b	v19, v3, v24
	orr.16b	v3, v2, v24
	xtn.2s	v6, v6
	xtn.2s	v4, v7
	xtn.2s	v5, v5
	stp	q29, q16, [sp, #352]            ; 32-byte Folded Spill
	str	q26, [sp, #288]                 ; 16-byte Spill
	str	q2, [sp, #128]                  ; 16-byte Spill
	tbz	w17, #7, LBB0_29
; %bb.28:                               ; %cond.load88
	add	x11, x1, #28
	ld1.s	{ v30 }[3], [x11]
LBB0_29:                                ; %else89
	umull.2d	v7, v23, v22
	stp	q17, q3, [sp, #176]             ; 32-byte Folded Spill
	mov.16b	v2, v3
	umlal.2d	v2, v5, v22
	str	q2, [sp, #272]                  ; 16-byte Spill
	stp	q21, q19, [sp, #144]            ; 32-byte Folded Spill
	mov.16b	v2, v19
	umlal.2d	v2, v6, v22
	str	q2, [sp, #256]                  ; 16-byte Spill
	mov.16b	v2, v17
	umlal.2d	v2, v4, v22
	stp	q7, q2, [sp, #224]              ; 32-byte Folded Spill
	sshll.2d	v24, v1, #0
	sshll.2d	v25, v0, #0
	add	x11, x16, x12
	str	q30, [sp, #80]                  ; 16-byte Spill
	stp	q21, q30, [x11]
	fmov	x28, d18
	mov	w17, #4                         ; =0x4
	dup.2d	v5, x17
	and.16b	v4, v28, v5
	and.16b	v30, v27, v5
	and.16b	v31, v25, v5
	and.16b	v8, v24, v5
	fmov	x27, d8
	ldp	q6, q5, [x16, #96]
	and.16b	v5, v0, v5
	and.16b	v6, v1, v6
	ldp	q7, q18, [x16, #64]
	and.16b	v18, v0, v18
	and.16b	v7, v1, v7
	ldp	q23, q22, [x16, #32]
	and.16b	v22, v0, v22
	and.16b	v23, v1, v23
	add	x11, x16, x28
	ldp	q29, q9, [x11]
	and.16b	v10, v0, v9
	mov	x11, x27
	and.16b	v11, v1, v29
	mov.16b	v13, v8
	mov.16b	v14, v30
	mov.16b	v15, v31
	mov.16b	v29, v4
LBB0_30:                                ; %direct.true80
                                        ; =>This Inner Loop Header: Depth=1
	add	x11, x16, x11, lsl #5
	ldp	q9, q12, [x11]
	fadd.4s	v9, v11, v9
	fadd.4s	v12, v10, v12
	ldp	q16, q3, [x11, #32]
	fadd.4s	v16, v23, v16
	fadd.4s	v3, v22, v3
	ldp	q19, q17, [x11, #64]
	fadd.4s	v19, v7, v19
	fadd.4s	v17, v18, v17
	ldp	q26, q20, [x11, #96]
	fadd.4s	v26, v6, v26
	fadd.4s	v20, v5, v20
	dup.2d	v2, x17
	and.16b	v21, v28, v2
	add.2d	v29, v29, v21
	and.16b	v21, v27, v2
	add.2d	v14, v14, v21
	and.16b	v21, v25, v2
	add.2d	v15, v15, v21
	and.16b	v2, v24, v2
	add.2d	v13, v13, v2
	bit.16b	v10, v12, v0
	bit.16b	v11, v9, v1
	bit.16b	v22, v3, v0
	bit.16b	v23, v16, v1
	bit.16b	v18, v17, v0
	bit.16b	v7, v19, v1
	bit.16b	v5, v20, v0
	bit.16b	v6, v26, v1
	fmov	x11, d13
	cmp	x11, #512
	b.lt	LBB0_30
; %bb.31:                               ; %direct.false81
	mov	x30, #0                         ; =0x0
	ldr	q2, [sp, #80]                   ; 16-byte Reload
	fadd.4s	v2, v2, v10
	ldr	q3, [sp, #144]                  ; 16-byte Reload
	fadd.4s	v3, v3, v11
	ldr	q24, [sp, #368]                 ; 16-byte Reload
	zip1.8b	v16, v24, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v3, v16, v3
	zip2.8b	v16, v24, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v2, v16, v2
	ldr	q25, [sp, #336]                 ; 16-byte Reload
	zip2.8b	v16, v25, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	movi.2d	v17, #0000000000000000
	mov.b	v17[2], v25[1]
	mov.b	v17[4], v25[2]
	mov.b	v17[6], v25[3]
	bit.16b	v2, v12, v16
	ushll.4s	v16, v17, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bit.16b	v3, v9, v16
	fadd.4s	v3, v23, v3
	fadd.4s	v2, v22, v2
	fadd.4s	v2, v18, v2
	fadd.4s	v3, v7, v3
	fadd.4s	v6, v6, v3
	fadd.4s	v7, v5, v2
	ldr	q2, [sp, #352]                  ; 16-byte Reload
	ldr	q3, [sp, #112]                  ; 16-byte Reload
	uzp1.4s	v5, v2, v3
	ldr	q2, [sp, #128]                  ; 16-byte Reload
	ldr	q3, [sp, #96]                   ; 16-byte Reload
	uzp1.4s	v17, v3, v2
	movi.4s	v2, #1
	eor.16b	v19, v17, v2
	eor.16b	v2, v5, v2
	mov.s	w11, v2[1]
	mov.s	w1, v2[2]
	mov.s	w2, v2[3]
	fmov	w17, s2
	add	x3, sp, #1112
	bfxil	x3, x17, #0, #3
	str	d25, [sp, #1112]
	ldrb	w3, [x3]
	and	x4, x17, #0x7
	umov.b	w17, v25[0]
	str	q7, [sp, #1328]
	str	q6, [sp, #1312]
	add	x5, sp, #1312
	ldr	s3, [x5, x4, lsl #2]
	ands	w7, w17, #0x1
	tst	w7, w3
	movi.2d	v2, #0000000000000000
	fcsel	s18, s3, s2, ne
	and	x4, x11, #0x7
	add	x3, sp, #1112
	bfxil	x3, x11, #0, #3
	ldrb	w11, [x3]
	umov.b	w3, v25[1]
	and	w11, w3, w11
	str	q7, [sp, #1296]
	str	q6, [sp, #1280]
	add	x5, sp, #1280
	ldr	s3, [x5, x4, lsl #2]
	tst	w11, #0x1
	fcsel	s20, s3, s2, ne
	and	x11, x1, #0x7
	add	x4, sp, #1112
	bfxil	x4, x1, #0, #3
	ldrb	w4, [x4]
	umov.b	w1, v25[2]
	and	w4, w1, w4
	str	q7, [sp, #1264]
	str	q6, [sp, #1248]
	add	x5, sp, #1248
	ldr	s3, [x5, x11, lsl #2]
	tst	w4, #0x1
	fcsel	s21, s3, s2, ne
	and	x11, x2, #0x7
	add	x4, sp, #1112
	bfxil	x4, x2, #0, #3
	umov.b	w2, v25[3]
	ldrb	w4, [x4]
	str	q7, [sp, #1232]
	str	q6, [sp, #1216]
	add	x5, sp, #1216
	ldr	s3, [x5, x11, lsl #2]
	and	w11, w2, w4
	tst	w11, #0x1
	mov.s	w11, v19[1]
	mov.s	w4, v19[2]
	fcsel	s22, s3, s2, ne
	mov.s	w5, v19[3]
	fmov	w6, s19
	and	x20, x6, #0x7
	add	x19, sp, #1112
	bfxil	x19, x6, #0, #3
	ldrb	w6, [x19]
	umov.b	w19, v25[4]
	and	w6, w19, w6
	str	q7, [sp, #1456]
	str	q6, [sp, #1440]
	add	x21, sp, #1440
	ldr	s3, [x21, x20, lsl #2]
	tst	w6, #0x1
	fcsel	s3, s3, s2, ne
	and	x20, x11, #0x7
	add	x6, sp, #1112
	bfxil	x6, x11, #0, #3
	ldrb	w11, [x6]
	umov.b	w6, v25[5]
	and	w11, w6, w11
	str	q7, [sp, #1424]
	str	q6, [sp, #1408]
	add	x21, sp, #1408
	ldr	s16, [x21, x20, lsl #2]
	tst	w11, #0x1
	fcsel	s16, s16, s2, ne
	and	x11, x4, #0x7
	add	x20, sp, #1112
	bfxil	x20, x4, #0, #3
	ldrb	w20, [x20]
	umov.b	w4, v25[6]
	and	w20, w4, w20
	str	q7, [sp, #1392]
	str	q6, [sp, #1376]
	add	x21, sp, #1376
	ldr	s19, [x21, x11, lsl #2]
	tst	w20, #0x1
	fcsel	s19, s19, s2, ne
	and	x11, x5, #0x7
	add	x20, sp, #1112
	bfxil	x20, x5, #0, #3
	ldrb	w20, [x20]
	umov.b	w5, v25[7]
	and	w20, w5, w20
	str	q7, [sp, #1360]
	str	q6, [sp, #1344]
	add	x21, sp, #1344
	ldr	s23, [x21, x11, lsl #2]
	tst	w20, #0x1
	fcsel	s23, s23, s2, ne
	mov.s	v3[1], v16[0]
	mov.s	v3[2], v19[0]
	mov.s	v3[3], v23[0]
	mov.s	v18[1], v20[0]
	mov.s	v18[2], v21[0]
	mov.s	v18[3], v22[0]
	add	x11, sp, #1112
	fadd.4s	v6, v6, v18
	fadd.4s	v3, v7, v3
	movi.4s	v7, #2
	eor.16b	v16, v17, v7
	eor.16b	v5, v5, v7
	fmov	w20, s5
	add	x21, sp, #1112
	bfxil	x21, x20, #0, #3
	ldrb	w21, [x21]
	and	x20, x20, #0x7
	str	q3, [sp, #1200]
	str	q6, [sp, #1184]
	add	x22, sp, #1184
	ldr	s5, [x22, x20, lsl #2]
	tst	w7, w21
	fcsel	s5, s5, s2, ne
	fmov	w7, s16
	and	x20, x7, #0x7
	bfxil	x11, x7, #0, #3
	ldrb	w11, [x11]
	and	w11, w19, w11
	str	q3, [sp, #1168]
	str	q6, [sp, #1152]
	add	x7, sp, #1152
	ldr	s7, [x7, x20, lsl #2]
	tst	w11, #0x1
	fcsel	s7, s7, s2, ne
	fadd.4s	v3, v3, v7
	and	w7, w17, w19
	tst	w7, #0x1
	fcsel	s3, s3, s2, ne
	ands	w25, w17, #0x1
	fadd.4s	v5, v6, v5
	fadd	s3, s5, s3
	fcsel	s5, s3, s2, ne
	tst	w7, #0x1
	and	w20, w3, w17
	fcsel	s6, s3, s2, ne
	and	w11, w3, w17
	str	w11, [sp, #144]                 ; 4-byte Spill
	tst	w20, #0x1
	and	w21, w1, w17
	fcsel	s7, s3, s2, ne
	tst	w21, #0x1
	and	w22, w2, w17
	fcsel	s16, s3, s2, ne
	tst	w22, #0x1
	fcsel	s17, s3, s2, ne
	and	w23, w6, w17
	tst	w23, #0x1
	fcsel	s18, s3, s2, ne
	and	w24, w4, w17
	tst	w24, #0x1
	fcsel	s19, s3, s2, ne
	and	w26, w5, w17
	tst	w26, #0x1
	fcsel	s3, s3, s2, ne
	mov.s	v5[1], v7[0]
	mov.s	v5[2], v16[0]
	mov.s	v5[3], v17[0]
	mov.s	v6[1], v18[0]
	mov.s	v6[2], v19[0]
	mov.s	v6[3], v3[0]
	rbit	w11, w0
	clz	w0, w11
	str	q6, [sp, #1136]
	str	q5, [sp, #1120]
	and	x11, x0, #0x7
	add	x20, sp, #1120
	ldr	s3, [x20, x11, lsl #2]
	movi.2d	v5, #0000000000000000
	mov.b	v25[0], wzr
	str	q25, [sp, #64]                  ; 16-byte Spill
	fadd	s2, s3, s2
	mov	w11, #2048                      ; =0x800
	movk	w11, #17792, lsl #16
	fmov	s3, w11
	fdiv	s2, s2, s3
	dup.4s	v2, v2[0]
	ushll2.2d	v3, v0, #0
	mov	w11, #1                         ; =0x1
	dup.2d	v6, x11
	and.16b	v18, v3, v6
	ushll2.2d	v3, v1, #0
	and.16b	v19, v3, v6
	ushll.2d	v3, v0, #0
	and.16b	v20, v3, v6
	ushll.2d	v3, v1, #0
	and.16b	v21, v3, v6
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v17, #0000000000000000
LBB0_32:                                ; %direct.true115
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x11, x30, #5
	add	x20, x16, x11
	ldp	q16, q3, [x20]
	fsub.4s	v16, v16, v2
	fsub.4s	v3, v3, v2
	add	x11, x10, x11
	ldp	q22, q23, [x11]
	bif.16b	v3, v23, v0
	bif.16b	v16, v22, v1
	stp	q16, q3, [x11]
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v17, v17, v18
	add.2d	v5, v5, v21
	fmov	x30, d5
	cmp	x30, #512
	b.lt	LBB0_32
; %bb.33:                               ; %direct.true152.preheader
Lloh16:
	adrp	x11, lCPI0_11@PAGE
Lloh17:
	ldr	q3, [x11, lCPI0_11@PAGEOFF]
	and.16b	v3, v0, v3
	str	q3, [sp, #80]                   ; 16-byte Spill
Lloh18:
	adrp	x11, lCPI0_12@PAGE
Lloh19:
	ldr	q3, [x11, lCPI0_12@PAGEOFF]
	and.16b	v3, v1, v3
	str	q3, [sp, #48]                   ; 16-byte Spill
Lloh20:
	adrp	x11, lCPI0_13@PAGE
Lloh21:
	ldr	q3, [x11, lCPI0_13@PAGEOFF]
	and.16b	v3, v0, v3
	str	q3, [sp, #112]                  ; 16-byte Spill
Lloh22:
	adrp	x11, lCPI0_14@PAGE
Lloh23:
	ldr	q3, [x11, lCPI0_14@PAGEOFF]
	and.16b	v3, v1, v3
	str	q3, [sp, #96]                   ; 16-byte Spill
Lloh24:
	adrp	x11, lCPI0_15@PAGE
Lloh25:
	ldr	q3, [x11, lCPI0_15@PAGEOFF]
	and.16b	v3, v1, v3
	str	q3, [sp, #128]                  ; 16-byte Spill
	add	x11, x16, x12
	ldp	q5, q3, [x11]
	fsub.4s	v6, v5, v2
	fsub.4s	v7, v3, v2
	add	x11, x10, x12
	ldp	q2, q3, [x11]
	zip2.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	stp	q7, q6, [sp, #16]               ; 32-byte Folded Spill
	bit.16b	v3, v7, v5
	zip1.8b	v5, v24, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bit.16b	v2, v6, v5
	stp	q2, q3, [x11]
	ldr	q2, [x16, #16528]
	ldr	q3, [x16, #16512]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v15, v0, v2
	and.16b	v5, v1, v3
	ldr	q2, [x16, #16496]
	ldr	q3, [x16, #16480]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v2, v0, v2
	and.16b	v7, v1, v3
	ldr	q3, [x16, #16464]
	ldr	q16, [x16, #16448]
	fmul.4s	v16, v16, v16
	fmul.4s	v3, v3, v3
	and.16b	v22, v0, v3
	and.16b	v23, v1, v16
	add	x11, x10, x28
	ldp	q16, q3, [x11]
	fmul.4s	v16, v16, v16
	fmul.4s	v3, v3, v3
	and.16b	v25, v0, v3
	and.16b	v24, v1, v16
	mov	w16, #4                         ; =0x4
LBB0_34:                                ; %direct.true152
                                        ; =>This Inner Loop Header: Depth=1
	sshll.2d	v3, v1, #0
	sshll.2d	v16, v0, #0
	add	x11, x10, x27, lsl #5
	ldp	q29, q26, [x11]
	and.16b	v29, v1, v29
	and.16b	v26, v0, v26
	fmul.4s	v26, v26, v26
	fmul.4s	v29, v29, v29
	fadd.4s	v9, v24, v29
	fadd.4s	v10, v25, v26
	ldp	q29, q26, [x11, #32]
	and.16b	v29, v1, v29
	and.16b	v26, v0, v26
	fmul.4s	v26, v26, v26
	fmul.4s	v29, v29, v29
	fadd.4s	v29, v23, v29
	fadd.4s	v26, v22, v26
	ldp	q6, q17, [x11, #64]
	and.16b	v6, v1, v6
	and.16b	v17, v0, v17
	fmul.4s	v17, v17, v17
	fmul.4s	v6, v6, v6
	fadd.4s	v6, v7, v6
	fadd.4s	v17, v2, v17
	ldp	q12, q11, [x11, #96]
	and.16b	v12, v1, v12
	and.16b	v11, v0, v11
	fmul.4s	v11, v11, v11
	fmul.4s	v12, v12, v12
	fadd.4s	v12, v5, v12
	fadd.4s	v11, v15, v11
	dup.2d	v13, x16
	and.16b	v14, v28, v13
	add.2d	v4, v4, v14
	and.16b	v14, v27, v13
	add.2d	v30, v30, v14
	and.16b	v16, v16, v13
	add.2d	v31, v31, v16
	and.16b	v3, v3, v13
	add.2d	v8, v8, v3
	bit.16b	v25, v10, v0
	bit.16b	v24, v9, v1
	bit.16b	v22, v26, v0
	bit.16b	v23, v29, v1
	bit.16b	v2, v17, v0
	bit.16b	v7, v6, v1
	bit.16b	v15, v11, v0
	bit.16b	v5, v12, v1
	fmov	x27, d8
	cmp	x27, #512
	b.lt	LBB0_34
; %bb.35:                               ; %direct.true189.preheader
	mov	x11, #0                         ; =0x0
	movi.2d	v27, #0000000000000000
	ldr	q8, [sp, #288]                  ; 16-byte Reload
	fmov	w16, s8
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	b	LBB0_37
LBB0_36:                                ; %else114
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x11, x9, x27
	stp	q31, q4, [x11]
	add.2d	v28, v28, v19
	add.2d	v29, v29, v20
	add.2d	v30, v30, v18
	add.2d	v27, v27, v21
	fmov	x11, d27
	cmp	x11, #512
	b.ge	LBB0_53
LBB0_37:                                ; %direct.true189
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x27, x11, #5
	add	x28, x15, x27
	add	x11, x9, x27
	ldr	q31, [x11]
	tbnz	w16, #0, LBB0_45
; %bb.38:                               ; %else93
                                        ;   in Loop: Header=BB0_37 Depth=1
	and	w30, w16, #0xff
	tbnz	w30, #1, LBB0_46
LBB0_39:                                ; %else96
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w30, #2, LBB0_47
LBB0_40:                                ; %else99
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w30, #3, LBB0_48
LBB0_41:                                ; %else102
                                        ;   in Loop: Header=BB0_37 Depth=1
	ldr	q4, [x11, #16]
	tbnz	w30, #4, LBB0_49
LBB0_42:                                ; %else105
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w30, #5, LBB0_50
LBB0_43:                                ; %else108
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w30, #6, LBB0_51
LBB0_44:                                ; %else111
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbz	w30, #7, LBB0_36
	b	LBB0_52
LBB0_45:                                ; %cond.load92
                                        ;   in Loop: Header=BB0_37 Depth=1
	ld1.s	{ v31 }[0], [x28]
	and	w30, w16, #0xff
	tbz	w30, #1, LBB0_39
LBB0_46:                                ; %cond.load95
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x20, x28, #4
	ld1.s	{ v31 }[1], [x20]
	tbz	w30, #2, LBB0_40
LBB0_47:                                ; %cond.load98
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x20, x28, #8
	ld1.s	{ v31 }[2], [x20]
	tbz	w30, #3, LBB0_41
LBB0_48:                                ; %cond.load101
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x20, x28, #12
	ld1.s	{ v31 }[3], [x20]
	ldr	q4, [x11, #16]
	tbz	w30, #4, LBB0_42
LBB0_49:                                ; %cond.load104
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x11, x28, #16
	ld1.s	{ v4 }[0], [x11]
	tbz	w30, #5, LBB0_43
LBB0_50:                                ; %cond.load107
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x11, x28, #20
	ld1.s	{ v4 }[1], [x11]
	tbz	w30, #6, LBB0_44
LBB0_51:                                ; %cond.load110
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x11, x28, #24
	ld1.s	{ v4 }[2], [x11]
	tbz	w30, #7, LBB0_36
LBB0_52:                                ; %cond.load113
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x11, x28, #28
	ld1.s	{ v4 }[3], [x11]
	b	LBB0_36
LBB0_53:                                ; %direct.false190
	ldr	q28, [sp, #368]                 ; 16-byte Reload
	zip2.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldp	q4, q16, [sp, #16]              ; 32-byte Folded Reload
	and.16b	v4, v3, v4
	zip1.8b	v6, v28, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	and.16b	v16, v6, v16
	fmul.4s	v16, v16, v16
	fmul.4s	v4, v4, v4
	fadd.4s	v4, v4, v25
	fadd.4s	v16, v16, v24
	and.16b	v6, v6, v16
	and.16b	v3, v3, v4
	ldr	q16, [sp, #64]                  ; 16-byte Reload
	zip2.8b	v4, v16, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v3, v10, v4
	zip1.8b	v4, v16, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bsl.16b	v4, v9, v6
	fadd.4s	v4, v23, v4
	fadd.4s	v3, v22, v3
	fadd.4s	v3, v2, v3
	fadd.4s	v2, v7, v4
	fadd.4s	v2, v5, v2
	fadd.4s	v5, v15, v3
	ldr	q4, [sp, #48]                   ; 16-byte Reload
	fmov	w11, s4
	add	x16, sp, #456
	bfxil	x16, x11, #0, #3
	ldr	q3, [sp, #336]                  ; 16-byte Reload
	str	d3, [sp, #456]
	ldrb	w16, [x16]
	and	x11, x11, #0x7
	stp	q2, q5, [sp, #944]
	add	x20, sp, #944
	ldr	s3, [x20, x11, lsl #2]
	tst	w25, w16
	movi.2d	v27, #0000000000000000
	fcsel	s6, s3, s27, ne
	mov.s	w11, v4[1]
	and	x16, x11, #0x7
	add	x20, sp, #456
	bfxil	x20, x11, #0, #3
	ldrb	w11, [x20]
	stp	q2, q5, [sp, #912]
	add	x20, sp, #912
	ldr	s3, [x20, x16, lsl #2]
	and	w11, w3, w11
	tst	w11, #0x1
	fcsel	s7, s3, s27, ne
	mov.s	w11, v4[2]
	and	x16, x11, #0x7
	add	x20, sp, #456
	bfxil	x20, x11, #0, #3
	ldrb	w11, [x20]
	and	w11, w1, w11
	stp	q2, q5, [sp, #880]
	add	x20, sp, #880
	ldr	s3, [x20, x16, lsl #2]
	tst	w11, #0x1
	mov.s	w11, v4[3]
	fcsel	s17, s3, s27, ne
	and	x16, x11, #0x7
	add	x20, sp, #456
	bfxil	x20, x11, #0, #3
	ldrb	w11, [x20]
	and	w11, w2, w11
	stp	q2, q5, [sp, #848]
	add	x20, sp, #848
	ldr	s3, [x20, x16, lsl #2]
	tst	w11, #0x1
	fcsel	s22, s3, s27, ne
	ldr	q23, [sp, #80]                  ; 16-byte Reload
	fmov	w11, s23
	and	x16, x11, #0x7
	add	x20, sp, #456
	bfxil	x20, x11, #0, #3
	ldrb	w11, [x20]
	and	w11, w19, w11
	str	q5, [sp, #1088]
	str	q2, [sp, #1072]
	add	x20, sp, #1072
	ldr	s3, [x20, x16, lsl #2]
	tst	w11, #0x1
	fcsel	s3, s3, s27, ne
	mov.s	w11, v23[1]
	and	x16, x11, #0x7
	add	x20, sp, #456
	bfxil	x20, x11, #0, #3
	ldrb	w11, [x20]
	and	w11, w6, w11
	str	q5, [sp, #1056]
	str	q2, [sp, #1040]
	add	x20, sp, #1040
	ldr	s4, [x20, x16, lsl #2]
	tst	w11, #0x1
	fcsel	s4, s4, s27, ne
	mov.s	w11, v23[2]
	and	x16, x11, #0x7
	add	x20, sp, #456
	bfxil	x20, x11, #0, #3
	ldrb	w11, [x20]
	and	w11, w4, w11
	stp	q2, q5, [sp, #1008]
	add	x20, sp, #1008
	ldr	s16, [x20, x16, lsl #2]
	tst	w11, #0x1
	fcsel	s16, s16, s27, ne
	mov.s	w11, v23[3]
	and	x16, x11, #0x7
	add	x20, sp, #456
	bfxil	x20, x11, #0, #3
	ldrb	w11, [x20]
	and	w11, w5, w11
	stp	q2, q5, [sp, #976]
	add	x20, sp, #976
	ldr	s23, [x20, x16, lsl #2]
	tst	w11, #0x1
	fcsel	s23, s23, s27, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v16[0]
	mov.s	v3[3], v23[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v17[0]
	add	x16, sp, #456
	mov.s	v6[3], v22[0]
	fadd.4s	v2, v2, v6
	fadd.4s	v5, v5, v3
	ldr	q4, [sp, #96]                   ; 16-byte Reload
	fmov	w11, s4
	add	x20, sp, #456
	bfxil	x20, x11, #0, #3
	ldrb	w20, [x20]
	and	x11, x11, #0x7
	stp	q2, q5, [sp, #688]
	add	x27, sp, #688
	ldr	s3, [x27, x11, lsl #2]
	tst	w25, w20
	mov.s	w11, v4[1]
	fcsel	s6, s3, s27, ne
	and	x20, x11, #0x7
	add	x27, sp, #456
	bfxil	x27, x11, #0, #3
	ldrb	w11, [x27]
	and	w11, w3, w11
	stp	q2, q5, [sp, #656]
	add	x3, sp, #656
	ldr	s3, [x3, x20, lsl #2]
	tst	w11, #0x1
	fcsel	s7, s3, s27, ne
	mov.s	w11, v4[2]
	and	x3, x11, #0x7
	add	x20, sp, #456
	bfxil	x20, x11, #0, #3
	ldrb	w11, [x20]
	stp	q2, q5, [sp, #624]
	add	x20, sp, #624
	ldr	s3, [x20, x3, lsl #2]
	and	w11, w1, w11
	tst	w11, #0x1
	fcsel	s17, s3, s27, ne
	mov.s	w11, v4[3]
	and	x1, x11, #0x7
	add	x3, sp, #456
	bfxil	x3, x11, #0, #3
	ldrb	w11, [x3]
	and	w11, w2, w11
	stp	q2, q5, [sp, #592]
	add	x2, sp, #592
	ldr	s3, [x2, x1, lsl #2]
	tst	w11, #0x1
	fcsel	s22, s3, s27, ne
	ldr	q23, [sp, #112]                 ; 16-byte Reload
	fmov	w11, s23
	and	x1, x11, #0x7
	add	x2, sp, #456
	bfxil	x2, x11, #0, #3
	ldrb	w11, [x2]
	and	w11, w19, w11
	stp	q2, q5, [sp, #816]
	add	x2, sp, #816
	ldr	s3, [x2, x1, lsl #2]
	tst	w11, #0x1
	fcsel	s3, s3, s27, ne
	mov.s	w11, v23[1]
	and	x1, x11, #0x7
	add	x2, sp, #456
	bfxil	x2, x11, #0, #3
	ldrb	w11, [x2]
	and	w11, w6, w11
	stp	q2, q5, [sp, #784]
	add	x2, sp, #784
	ldr	s4, [x2, x1, lsl #2]
	tst	w11, #0x1
	fcsel	s4, s4, s27, ne
	mov.s	w11, v23[2]
	and	x1, x11, #0x7
	add	x2, sp, #456
	bfxil	x2, x11, #0, #3
	ldrb	w11, [x2]
	and	w11, w4, w11
	stp	q2, q5, [sp, #752]
	add	x2, sp, #752
	ldr	s16, [x2, x1, lsl #2]
	tst	w11, #0x1
	fcsel	s16, s16, s27, ne
	mov.s	w11, v23[3]
	and	x1, x11, #0x7
	add	x2, sp, #456
	bfxil	x2, x11, #0, #3
	ldrb	w11, [x2]
	and	w11, w5, w11
	stp	q2, q5, [sp, #720]
	add	x2, sp, #720
	ldr	s23, [x2, x1, lsl #2]
	tst	w11, #0x1
	fcsel	s23, s23, s27, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v16[0]
	mov.s	v3[3], v23[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v22[0]
	fadd.4s	v2, v2, v6
	fadd.4s	v3, v5, v3
	ldr	q4, [sp, #128]                  ; 16-byte Reload
	fmov	w11, s4
	bfxil	x16, x11, #0, #3
	ldrb	w16, [x16]
	and	x11, x11, #0x7
	stp	q2, q3, [sp, #560]
	add	x1, sp, #560
	ldr	s3, [x1, x11, lsl #2]
	tst	w25, w16
	fcsel	s3, s3, s27, ne
	tst	w17, #0x1
Lloh26:
	adrp	x11, lCPI0_16@PAGE
Lloh27:
	ldr	d4, [x11, lCPI0_16@PAGEOFF]
	shl.8b	v5, v28, #7
	cmlt.8b	v5, v5, #0
	and.8b	v4, v5, v4
	addv.8b	b26, v4
	fadd	s2, s2, s3
	fcsel	s3, s2, s27, ne
	ldr	w11, [sp, #144]                 ; 4-byte Reload
	tst	w11, #0x1
	fcsel	s4, s2, s27, ne
	tst	w21, #0x1
	fcsel	s5, s2, s27, ne
	tst	w22, #0x1
	fcsel	s6, s2, s27, ne
	tst	w7, #0x1
	fcsel	s7, s2, s27, ne
	tst	w23, #0x1
	fcsel	s16, s2, s27, ne
	tst	w24, #0x1
	fcsel	s17, s2, s27, ne
	tst	w26, #0x1
	fcsel	s2, s2, s27, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v5[0]
	mov.s	v3[3], v6[0]
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	mov.s	v7[3], v2[0]
	stp	q3, q7, [sp, #528]
	and	x11, x0, #0x7
	add	x16, sp, #528
	ldr	s2, [x16, x11, lsl #2]
	mov	b3, v28[0]
	mov.b	v3[4], v28[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldp	q7, q4, [sp, #192]              ; 32-byte Folded Reload
	and.16b	v3, v3, v4
	mov	b4, v28[2]
	mov.b	v4[4], v28[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldp	q5, q6, [sp, #160]              ; 32-byte Folded Reload
	and.16b	v4, v4, v5
	mov	b5, v28[4]
	mov.b	v5[4], v28[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v5, v5, v6
	mov	b6, v28[6]
	mov.b	v6[4], v28[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v6, v6, v7
	stp	q5, q6, [sp, #496]
	stp	q3, q4, [sp, #464]
	ldr	x3, [sp, #328]                  ; 8-byte Reload
	and	x11, x3, #0x7
	add	x16, sp, #464
	ldr	x11, [x16, x11, lsl #3]
	fmov	w17, s26
	sub	x11, x11, x3
	lsl	x16, x11, #2
	add	x15, x15, x16
	add	x11, x9, x12
	ldr	q5, [x11]
	tbnz	w17, #0, LBB0_133
; %bb.54:                               ; %else118
	ldr	q29, [sp, #352]                 ; 16-byte Reload
	tbnz	w17, #1, LBB0_134
LBB0_55:                                ; %else121
	tbnz	w17, #2, LBB0_135
LBB0_56:                                ; %else124
	tbnz	w17, #3, LBB0_136
LBB0_57:                                ; %else127
	ldr	q4, [x11, #16]
	tbnz	w17, #4, LBB0_137
LBB0_58:                                ; %else130
	mov	w11, #2048                      ; =0x800
	movk	w11, #17792, lsl #16
	tbnz	w17, #5, LBB0_138
LBB0_59:                                ; %else133
	fadd	s2, s2, s27
	fmov	s6, w11
	tbnz	w17, #6, LBB0_139
LBB0_60:                                ; %else136
	fdiv	s2, s2, s6
	tbz	w17, #7, LBB0_62
LBB0_61:                                ; %cond.load138
	add	x11, x15, #28
	ld1.s	{ v4 }[3], [x11]
LBB0_62:                                ; %else139
	add	x11, x9, x12
	stp	q5, q4, [x11]
	mov	w11, #50604                     ; =0xc5ac
	movk	w11, #14119, lsl #16
	fmov	s3, w11
	fadd	s2, s2, s3
	subs	x11, x8, x14
	cset	w15, hs
	mov	w17, #16387                     ; =0x4003
	cmp	x11, x17
	csel	w11, wzr, w15, ls
	subs	x15, x14, x8
	mov	w17, #4095                      ; =0xfff
	movk	w17, #256, lsl #16
	ccmp	x15, x17, #0, hs
	fsqrt	s2, s2
	b.hi	LBB0_83
; %bb.63:                               ; %else139
	tbnz	w11, #0, LBB0_83
; %bb.64:                               ; %direct.true259.preheader
	mov	x11, #0                         ; =0x0
	movi.2d	v5, #0000000000000000
	fmov	w15, s8
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	b	LBB0_66
LBB0_65:                                ; %else231
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x11, x13, x17
	stp	q17, q4, [x11]
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v16, v16, v18
	add.2d	v5, v5, v21
	fmov	x11, d5
	cmp	x11, #512
	b.ge	LBB0_140
LBB0_66:                                ; %direct.true259
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x17, x11, #5
	add	x0, x14, x17
	add	x11, x13, x17
	ldr	q17, [x11]
	tbnz	w15, #0, LBB0_74
; %bb.67:                               ; %else210
                                        ;   in Loop: Header=BB0_66 Depth=1
	and	w1, w15, #0xff
	tbnz	w1, #1, LBB0_75
LBB0_68:                                ; %else213
                                        ;   in Loop: Header=BB0_66 Depth=1
	tbnz	w1, #2, LBB0_76
LBB0_69:                                ; %else216
                                        ;   in Loop: Header=BB0_66 Depth=1
	tbnz	w1, #3, LBB0_77
LBB0_70:                                ; %else219
                                        ;   in Loop: Header=BB0_66 Depth=1
	ldr	q4, [x11, #16]
	tbnz	w1, #4, LBB0_78
LBB0_71:                                ; %else222
                                        ;   in Loop: Header=BB0_66 Depth=1
	tbnz	w1, #5, LBB0_79
LBB0_72:                                ; %else225
                                        ;   in Loop: Header=BB0_66 Depth=1
	tbnz	w1, #6, LBB0_80
LBB0_73:                                ; %else228
                                        ;   in Loop: Header=BB0_66 Depth=1
	tbz	w1, #7, LBB0_65
	b	LBB0_81
LBB0_74:                                ; %cond.load209
                                        ;   in Loop: Header=BB0_66 Depth=1
	ld1.s	{ v17 }[0], [x0]
	and	w1, w15, #0xff
	tbz	w1, #1, LBB0_68
LBB0_75:                                ; %cond.load212
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x2, x0, #4
	ld1.s	{ v17 }[1], [x2]
	tbz	w1, #2, LBB0_69
LBB0_76:                                ; %cond.load215
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x2, x0, #8
	ld1.s	{ v17 }[2], [x2]
	tbz	w1, #3, LBB0_70
LBB0_77:                                ; %cond.load218
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x2, x0, #12
	ld1.s	{ v17 }[3], [x2]
	ldr	q4, [x11, #16]
	tbz	w1, #4, LBB0_71
LBB0_78:                                ; %cond.load221
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x11, x0, #16
	ld1.s	{ v4 }[0], [x11]
	tbz	w1, #5, LBB0_72
LBB0_79:                                ; %cond.load224
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x11, x0, #20
	ld1.s	{ v4 }[1], [x11]
	tbz	w1, #6, LBB0_73
LBB0_80:                                ; %cond.load227
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x11, x0, #24
	ld1.s	{ v4 }[2], [x11]
	tbz	w1, #7, LBB0_65
LBB0_81:                                ; %cond.load230
                                        ;   in Loop: Header=BB0_66 Depth=1
	add	x11, x0, #28
	ld1.s	{ v4 }[3], [x11]
	b	LBB0_65
LBB0_82:                                ; %common.ret
	ret
LBB0_83:                                ; %direct.schedule.27.preheader
	mov	x15, #0                         ; =0x0
	dup.4s	v22, v2[0]
	ldr	q2, [sp, #224]                  ; 16-byte Reload
	add.2d	v2, v29, v2
	movi.2d	v5, #0000000000000000
	fmov	w13, s8
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v17, #0000000000000000
	b	LBB0_85
LBB0_84:                                ; %else182
                                        ;   in Loop: Header=BB0_85 Depth=1
	add.2d	v6, v6, v19
	add.2d	v7, v7, v20
	add.2d	v17, v17, v18
	add.2d	v5, v5, v21
	fmov	x15, d5
	cmp	x15, #512
	b.ge	LBB0_117
LBB0_85:                                ; %direct.true217
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v24, v5, #3
	orr.16b	v3, v24, v29
	fmov	x11, d3
	add	x17, x14, x11, lsl #2
	movi.2d	v25, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w13, #0, LBB0_102
; %bb.86:                               ; %else143
                                        ;   in Loop: Header=BB0_85 Depth=1
	and	w0, w13, #0xff
	tbnz	w0, #1, LBB0_103
LBB0_87:                                ; %else146
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w0, #2, LBB0_104
LBB0_88:                                ; %else149
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w0, #3, LBB0_105
LBB0_89:                                ; %else152
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w0, #4, LBB0_106
LBB0_90:                                ; %else155
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w0, #5, LBB0_107
LBB0_91:                                ; %else158
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w0, #6, LBB0_108
LBB0_92:                                ; %else161
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbz	w0, #7, LBB0_94
LBB0_93:                                ; %cond.load163
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x11, x17, #28
	ld1.s	{ v23 }[3], [x11]
LBB0_94:                                ; %else164
                                        ;   in Loop: Header=BB0_85 Depth=1
	lsl	x11, x15, #5
	add	x15, x10, x11
	ldp	q3, q4, [x15]
	and.16b	v3, v1, v3
	fdiv.4s	v3, v3, v22
	add	x11, x9, x11
	ldp	q16, q27, [x11]
	and.16b	v16, v1, v16
	fmul.4s	v3, v3, v16
	fmov	w11, s8
	fadd.4s	v25, v25, v3
	add.2d	v3, v24, v2
	fmov	x15, d3
	add	x15, x8, x15, lsl #2
	tbnz	w11, #0, LBB0_109
; %bb.95:                               ; %else168
                                        ;   in Loop: Header=BB0_85 Depth=1
	and	w11, w11, #0xff
	tbnz	w11, #1, LBB0_110
LBB0_96:                                ; %else170
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w11, #2, LBB0_111
LBB0_97:                                ; %else172
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w11, #3, LBB0_112
LBB0_98:                                ; %else174
                                        ;   in Loop: Header=BB0_85 Depth=1
	and.16b	v3, v0, v4
	fdiv.4s	v3, v3, v22
	and.16b	v4, v0, v27
	fmul.4s	v3, v3, v4
	fadd.4s	v4, v23, v3
	tbnz	w11, #4, LBB0_113
LBB0_99:                                ; %else176
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w11, #5, LBB0_114
LBB0_100:                               ; %else178
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w11, #6, LBB0_115
LBB0_101:                               ; %else180
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbz	w11, #7, LBB0_84
	b	LBB0_116
LBB0_102:                               ; %cond.load142
                                        ;   in Loop: Header=BB0_85 Depth=1
	ldr	s25, [x17]
	and	w0, w13, #0xff
	tbz	w0, #1, LBB0_87
LBB0_103:                               ; %cond.load145
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x11, x17, #4
	ld1.s	{ v25 }[1], [x11]
	tbz	w0, #2, LBB0_88
LBB0_104:                               ; %cond.load148
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x11, x17, #8
	ld1.s	{ v25 }[2], [x11]
	tbz	w0, #3, LBB0_89
LBB0_105:                               ; %cond.load151
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x11, x17, #12
	ld1.s	{ v25 }[3], [x11]
	tbz	w0, #4, LBB0_90
LBB0_106:                               ; %cond.load154
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x11, x17, #16
	ld1.s	{ v23 }[0], [x11]
	tbz	w0, #5, LBB0_91
LBB0_107:                               ; %cond.load157
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x11, x17, #20
	ld1.s	{ v23 }[1], [x11]
	tbz	w0, #6, LBB0_92
LBB0_108:                               ; %cond.load160
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x11, x17, #24
	ld1.s	{ v23 }[2], [x11]
	tbnz	w0, #7, LBB0_93
	b	LBB0_94
LBB0_109:                               ; %cond.store167
                                        ;   in Loop: Header=BB0_85 Depth=1
	str	s25, [x15]
	and	w11, w11, #0xff
	tbz	w11, #1, LBB0_96
LBB0_110:                               ; %cond.store169
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x17, x15, #4
	st1.s	{ v25 }[1], [x17]
	tbz	w11, #2, LBB0_97
LBB0_111:                               ; %cond.store171
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x17, x15, #8
	st1.s	{ v25 }[2], [x17]
	tbz	w11, #3, LBB0_98
LBB0_112:                               ; %cond.store173
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x17, x15, #12
	st1.s	{ v25 }[3], [x17]
	and.16b	v3, v0, v4
	fdiv.4s	v3, v3, v22
	and.16b	v4, v0, v27
	fmul.4s	v3, v3, v4
	fadd.4s	v4, v23, v3
	tbz	w11, #4, LBB0_99
LBB0_113:                               ; %cond.store175
                                        ;   in Loop: Header=BB0_85 Depth=1
	str	s4, [x15, #16]
	tbz	w11, #5, LBB0_100
LBB0_114:                               ; %cond.store177
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x17, x15, #20
	st1.s	{ v4 }[1], [x17]
	tbz	w11, #6, LBB0_101
LBB0_115:                               ; %cond.store179
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x17, x15, #24
	st1.s	{ v4 }[2], [x17]
	tbz	w11, #7, LBB0_84
LBB0_116:                               ; %cond.store181
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x11, x15, #28
	st1.s	{ v4 }[3], [x11]
	b	LBB0_84
LBB0_117:                               ; %direct.false218
	fmov	w15, s26
	add	x13, x14, x16
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w15, #0, LBB0_185
; %bb.118:                              ; %else185
	zip2.8b	v2, v28, v0
	zip1.8b	v3, v28, v0
	tbnz	w15, #1, LBB0_186
LBB0_119:                               ; %else188
	ushll.4s	v2, v2, #0
	ushll.4s	v3, v3, #0
	tbnz	w15, #2, LBB0_187
LBB0_120:                               ; %else191
	add	x10, x10, x12
	shl.4s	v2, v2, #31
	shl.4s	v3, v3, #31
	tbnz	w15, #3, LBB0_188
LBB0_121:                               ; %else194
	ldp	q4, q5, [x10]
	cmlt.4s	v2, v2, #0
	cmlt.4s	v3, v3, #0
	add	x9, x9, x12
	tbnz	w15, #4, LBB0_189
LBB0_122:                               ; %else197
	and.16b	v5, v2, v5
	and.16b	v4, v3, v4
	ldp	q7, q6, [x9]
	tbnz	w15, #5, LBB0_190
LBB0_123:                               ; %else200
	fdiv.4s	v4, v4, v22
	fdiv.4s	v5, v5, v22
	and.16b	v7, v3, v7
	and.16b	v2, v2, v6
	tbnz	w15, #6, LBB0_191
LBB0_124:                               ; %else203
	fmul.4s	v3, v5, v2
	fmul.4s	v2, v4, v7
	tbz	w15, #7, LBB0_126
LBB0_125:                               ; %cond.load205
	add	x9, x13, #28
	ld1.s	{ v1 }[3], [x9]
LBB0_126:                               ; %else206
	fadd.4s	v2, v0, v2
	fadd.4s	v0, v1, v3
	b	LBB0_168
LBB0_127:                               ; %cond.load67
	ld1.s	{ v21 }[0], [x1]
	tbz	w17, #1, LBB0_21
LBB0_128:                               ; %cond.load70
	add	x11, x1, #4
	ld1.s	{ v21 }[1], [x11]
	tbz	w17, #2, LBB0_22
LBB0_129:                               ; %cond.load73
	add	x11, x1, #8
	ld1.s	{ v21 }[2], [x11]
	str	x3, [sp, #328]                  ; 8-byte Spill
	tbz	w17, #3, LBB0_23
LBB0_130:                               ; %cond.load76
	add	x11, x1, #12
	ld1.s	{ v21 }[3], [x11]
	adrp	x11, lCPI0_3@PAGE
	adrp	x3, lCPI0_4@PAGE
	adrp	x4, lCPI0_5@PAGE
	ldr	q30, [x2, #16]
	tbz	w17, #4, LBB0_24
LBB0_131:                               ; %cond.load79
	add	x2, x1, #16
	ld1.s	{ v30 }[0], [x2]
	ldr	q4, [x11, lCPI0_3@PAGEOFF]
	ldr	q19, [x3, lCPI0_4@PAGEOFF]
	ldr	q25, [x4, lCPI0_5@PAGEOFF]
	tbz	w17, #5, LBB0_25
LBB0_132:                               ; %cond.load82
	add	x11, x1, #20
	ld1.s	{ v30 }[1], [x11]
	and.16b	v2, v28, v4
	and.16b	v3, v27, v19
	and.16b	v4, v20, v25
	tbnz	w17, #6, LBB0_26
	b	LBB0_27
LBB0_133:                               ; %cond.load117
	ld1.s	{ v5 }[0], [x15]
	ldr	q29, [sp, #352]                 ; 16-byte Reload
	tbz	w17, #1, LBB0_55
LBB0_134:                               ; %cond.load120
	add	x0, x15, #4
	ld1.s	{ v5 }[1], [x0]
	tbz	w17, #2, LBB0_56
LBB0_135:                               ; %cond.load123
	add	x0, x15, #8
	ld1.s	{ v5 }[2], [x0]
	tbz	w17, #3, LBB0_57
LBB0_136:                               ; %cond.load126
	add	x0, x15, #12
	ld1.s	{ v5 }[3], [x0]
	ldr	q4, [x11, #16]
	tbz	w17, #4, LBB0_58
LBB0_137:                               ; %cond.load129
	add	x11, x15, #16
	ld1.s	{ v4 }[0], [x11]
	mov	w11, #2048                      ; =0x800
	movk	w11, #17792, lsl #16
	tbz	w17, #5, LBB0_59
LBB0_138:                               ; %cond.load132
	add	x0, x15, #20
	ld1.s	{ v4 }[1], [x0]
	fadd	s2, s2, s27
	fmov	s6, w11
	tbz	w17, #6, LBB0_60
LBB0_139:                               ; %cond.load135
	add	x11, x15, #24
	ld1.s	{ v4 }[2], [x11]
	fdiv	s2, s2, s6
	tbnz	w17, #7, LBB0_61
	b	LBB0_62
LBB0_140:                               ; %direct.false260
	add	x14, x14, x16
	add	x11, x13, x12
	ldr	q5, [x11]
	fmov	w15, s26
	tbnz	w15, #0, LBB0_192
; %bb.141:                              ; %else235
	tbnz	w15, #1, LBB0_193
LBB0_142:                               ; %else238
	tbnz	w15, #2, LBB0_194
LBB0_143:                               ; %else241
	tbnz	w15, #3, LBB0_195
LBB0_144:                               ; %else244
	ldr	q4, [x11, #16]
	tbnz	w15, #4, LBB0_196
LBB0_145:                               ; %else247
	tbnz	w15, #5, LBB0_197
LBB0_146:                               ; %else250
	tbnz	w15, #6, LBB0_198
LBB0_147:                               ; %else253
	tbz	w15, #7, LBB0_149
LBB0_148:                               ; %cond.load255
	add	x11, x14, #28
	ld1.s	{ v4 }[3], [x11]
LBB0_149:                               ; %else256
	mov	x11, #0                         ; =0x0
	add	x14, x13, x12
	stp	q5, q4, [x14]
	dup.4s	v2, v2[0]
	ldr	q3, [sp, #224]                  ; 16-byte Reload
	fmov	x14, d3
	add	x14, x8, x14, lsl #2
	movi.2d	v5, #0000000000000000
	fmov	w15, s8
	movi.2d	v3, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	b	LBB0_151
LBB0_150:                               ; %else274
                                        ;   in Loop: Header=BB0_151 Depth=1
	add.2d	v3, v3, v19
	add.2d	v6, v6, v20
	add.2d	v7, v7, v18
	add.2d	v5, v5, v21
	fmov	x11, d5
	cmp	x11, #512
	b.ge	LBB0_167
LBB0_151:                               ; %direct.true284
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x11, x11, #5
	add	x16, x10, x11
	ldp	q16, q4, [x16]
	and.16b	v16, v1, v16
	fdiv.4s	v17, v16, v2
	add	x16, x9, x11
	ldp	q22, q16, [x16]
	and.16b	v22, v1, v22
	fmul.4s	v22, v17, v22
	add	x16, x13, x11
	ldp	q23, q17, [x16]
	and.16b	v23, v1, v23
	fadd.4s	v22, v22, v23
	add	x16, x14, x11
	tbnz	w15, #0, LBB0_160
; %bb.152:                              ; %else260
                                        ;   in Loop: Header=BB0_151 Depth=1
	and	w11, w15, #0xff
	tbnz	w11, #1, LBB0_161
LBB0_153:                               ; %else262
                                        ;   in Loop: Header=BB0_151 Depth=1
	tbnz	w11, #2, LBB0_162
LBB0_154:                               ; %else264
                                        ;   in Loop: Header=BB0_151 Depth=1
	tbz	w11, #3, LBB0_156
LBB0_155:                               ; %cond.store265
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x17, x16, #12
	st1.s	{ v22 }[3], [x17]
LBB0_156:                               ; %else266
                                        ;   in Loop: Header=BB0_151 Depth=1
	and.16b	v4, v0, v4
	fdiv.4s	v4, v4, v2
	and.16b	v16, v0, v16
	fmul.4s	v4, v4, v16
	and.16b	v16, v0, v17
	fadd.4s	v4, v4, v16
	tbnz	w11, #4, LBB0_163
; %bb.157:                              ; %else268
                                        ;   in Loop: Header=BB0_151 Depth=1
	tbnz	w11, #5, LBB0_164
LBB0_158:                               ; %else270
                                        ;   in Loop: Header=BB0_151 Depth=1
	tbnz	w11, #6, LBB0_165
LBB0_159:                               ; %else272
                                        ;   in Loop: Header=BB0_151 Depth=1
	tbz	w11, #7, LBB0_150
	b	LBB0_166
LBB0_160:                               ; %cond.store259
                                        ;   in Loop: Header=BB0_151 Depth=1
	str	s22, [x16]
	and	w11, w15, #0xff
	tbz	w11, #1, LBB0_153
LBB0_161:                               ; %cond.store261
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x17, x16, #4
	st1.s	{ v22 }[1], [x17]
	tbz	w11, #2, LBB0_154
LBB0_162:                               ; %cond.store263
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x17, x16, #8
	st1.s	{ v22 }[2], [x17]
	tbnz	w11, #3, LBB0_155
	b	LBB0_156
LBB0_163:                               ; %cond.store267
                                        ;   in Loop: Header=BB0_151 Depth=1
	str	s4, [x16, #16]
	tbz	w11, #5, LBB0_158
LBB0_164:                               ; %cond.store269
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x17, x16, #20
	st1.s	{ v4 }[1], [x17]
	tbz	w11, #6, LBB0_159
LBB0_165:                               ; %cond.store271
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x17, x16, #24
	st1.s	{ v4 }[2], [x17]
	tbz	w11, #7, LBB0_150
LBB0_166:                               ; %cond.store273
                                        ;   in Loop: Header=BB0_151 Depth=1
	add	x11, x16, #28
	st1.s	{ v4 }[3], [x11]
	b	LBB0_150
LBB0_167:                               ; %direct.false285
	add	x10, x10, x12
	ldp	q1, q0, [x10]
	zip1.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v1, v3, v1
	zip2.8b	v4, v28, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v0, v4, v0
	fdiv.4s	v0, v0, v2
	fdiv.4s	v1, v1, v2
	add	x9, x9, x12
	ldp	q2, q5, [x9]
	and.16b	v5, v4, v5
	and.16b	v2, v3, v2
	fmul.4s	v1, v1, v2
	fmul.4s	v0, v0, v5
	add	x9, x13, x12
	ldp	q5, q2, [x9]
	and.16b	v3, v3, v5
	and.16b	v2, v4, v2
	fadd.4s	v0, v0, v2
	fadd.4s	v2, v1, v3
LBB0_168:                               ; %common.ret.sink.split
	ldr	q3, [sp, #304]                  ; 16-byte Reload
	ldp	q5, q4, [sp, #240]              ; 32-byte Folded Reload
	stp	q3, q4, [sp, #384]
	ldr	q1, [sp, #272]                  ; 16-byte Reload
	stp	q5, q1, [sp, #416]
	and	x9, x3, #0x7
	add	x10, sp, #384
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x3
	add	x8, x8, x9, lsl #2
	fmov	w9, s26
	tbnz	w9, #0, LBB0_178
; %bb.169:                              ; %else
	tbnz	w9, #1, LBB0_179
LBB0_170:                               ; %else30
	tbnz	w9, #2, LBB0_180
LBB0_171:                               ; %else32
	tbnz	w9, #3, LBB0_181
LBB0_172:                               ; %else34
	tbnz	w9, #4, LBB0_182
LBB0_173:                               ; %else36
	tbnz	w9, #5, LBB0_183
LBB0_174:                               ; %else38
	tbnz	w9, #6, LBB0_184
LBB0_175:                               ; %else40
	tbz	w9, #7, LBB0_177
LBB0_176:                               ; %cond.store41
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_177:
	add	sp, sp, #1616
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_178:                               ; %cond.store
	str	s2, [x8]
	tbz	w9, #1, LBB0_170
LBB0_179:                               ; %cond.store29
	add	x10, x8, #4
	st1.s	{ v2 }[1], [x10]
	tbz	w9, #2, LBB0_171
LBB0_180:                               ; %cond.store31
	add	x10, x8, #8
	st1.s	{ v2 }[2], [x10]
	tbz	w9, #3, LBB0_172
LBB0_181:                               ; %cond.store33
	add	x10, x8, #12
	st1.s	{ v2 }[3], [x10]
	tbz	w9, #4, LBB0_173
LBB0_182:                               ; %cond.store35
	str	s0, [x8, #16]
	tbz	w9, #5, LBB0_174
LBB0_183:                               ; %cond.store37
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w9, #6, LBB0_175
LBB0_184:                               ; %cond.store39
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB0_176
	b	LBB0_177
LBB0_185:                               ; %cond.load184
	ldr	s0, [x13]
	zip2.8b	v2, v28, v0
	zip1.8b	v3, v28, v0
	tbz	w15, #1, LBB0_119
LBB0_186:                               ; %cond.load187
	add	x11, x13, #4
	ld1.s	{ v0 }[1], [x11]
	ushll.4s	v2, v2, #0
	ushll.4s	v3, v3, #0
	tbz	w15, #2, LBB0_120
LBB0_187:                               ; %cond.load190
	add	x11, x13, #8
	ld1.s	{ v0 }[2], [x11]
	add	x10, x10, x12
	shl.4s	v2, v2, #31
	shl.4s	v3, v3, #31
	tbz	w15, #3, LBB0_121
LBB0_188:                               ; %cond.load193
	add	x11, x13, #12
	ld1.s	{ v0 }[3], [x11]
	ldp	q4, q5, [x10]
	cmlt.4s	v2, v2, #0
	cmlt.4s	v3, v3, #0
	add	x9, x9, x12
	tbz	w15, #4, LBB0_122
LBB0_189:                               ; %cond.load196
	add	x10, x13, #16
	ld1.s	{ v1 }[0], [x10]
	and.16b	v5, v2, v5
	and.16b	v4, v3, v4
	ldp	q7, q6, [x9]
	tbz	w15, #5, LBB0_123
LBB0_190:                               ; %cond.load199
	add	x9, x13, #20
	ld1.s	{ v1 }[1], [x9]
	fdiv.4s	v4, v4, v22
	fdiv.4s	v5, v5, v22
	and.16b	v7, v3, v7
	and.16b	v2, v2, v6
	tbz	w15, #6, LBB0_124
LBB0_191:                               ; %cond.load202
	add	x9, x13, #24
	ld1.s	{ v1 }[2], [x9]
	fmul.4s	v3, v5, v2
	fmul.4s	v2, v4, v7
	tbnz	w15, #7, LBB0_125
	b	LBB0_126
LBB0_192:                               ; %cond.load234
	ld1.s	{ v5 }[0], [x14]
	tbz	w15, #1, LBB0_142
LBB0_193:                               ; %cond.load237
	add	x16, x14, #4
	ld1.s	{ v5 }[1], [x16]
	tbz	w15, #2, LBB0_143
LBB0_194:                               ; %cond.load240
	add	x16, x14, #8
	ld1.s	{ v5 }[2], [x16]
	tbz	w15, #3, LBB0_144
LBB0_195:                               ; %cond.load243
	add	x16, x14, #12
	ld1.s	{ v5 }[3], [x16]
	ldr	q4, [x11, #16]
	tbz	w15, #4, LBB0_145
LBB0_196:                               ; %cond.load246
	add	x11, x14, #16
	ld1.s	{ v4 }[0], [x11]
	tbz	w15, #5, LBB0_146
LBB0_197:                               ; %cond.load249
	add	x11, x14, #20
	ld1.s	{ v4 }[1], [x11]
	tbz	w15, #6, LBB0_147
LBB0_198:                               ; %cond.load252
	add	x11, x14, #24
	ld1.s	{ v4 }[2], [x11]
	tbnz	w15, #7, LBB0_148
	b	LBB0_149
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh26, Lloh27
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

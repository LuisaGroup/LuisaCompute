	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_11:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI0_12:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI0_13:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI0_14:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
lCPI0_15:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_16:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v2, v1, v0
	umaxv.8h	h3, v2
	fmov	w8, s3
	tbz	w8, #0, LBB0_117
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1616
	mov	x12, #0                         ; =0x0
	ldr	x26, [x1, #136]
	mov	w8, #16416                      ; =0x4020
	add	x11, x26, x8
	mov	w8, #32832                      ; =0x8040
	add	x10, x26, x8
	mov	w8, #49248                      ; =0xc060
	add	x9, x26, x8
	ldr	x13, [x0]
	ldr	x15, [x0, #16]
	ldr	x14, [x0, #32]
	ldr	x8, [x0, #48]
	str	x8, [sp, #328]                  ; 8-byte Spill
Lloh4:
	adrp	x8, lCPI0_0@PAGE
Lloh5:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
	and.16b	v3, v2, v3
	addv.8h	h17, v3
	fmov	w8, s17
	and	w6, w8, #0xff
	ldr	w8, [x1]
	ldr	w16, [x1, #36]
	add	w8, w16, w8, lsl #5
	lsr	w8, w8, #3
	dup.4s	v3, w8
	and.16b	v7, v1, v3
	and.16b	v3, v0, v3
	ushll2.2d	v4, v3, #0
	ushll2.2d	v5, v7, #0
	ushll.2d	v6, v3, #0
	ushll.2d	v7, v7, #0
	fmov	x8, d7
	mov	w16, #16388                     ; =0x4004
	umaddl	x16, w8, w16, x13
	fmov	w17, s17
	b	LBB0_3
LBB0_2:                                 ; %else48
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x26, x12
	stp	q3, q16, [x8]
	add	x12, x12, #32
	cmp	x12, #4, lsl #12                ; =16384
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x0, x16, x12
	add	x2, x26, x12
	ldr	q3, [x2]
	tbnz	w17, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w1, w17, #0xff
	tbnz	w1, #1, LBB0_12
LBB0_5:                                 ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w1, #2, LBB0_13
LBB0_6:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w1, #3, LBB0_14
LBB0_7:                                 ; %else36
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q16, [x2, #16]
	tbnz	w1, #4, LBB0_15
LBB0_8:                                 ; %else39
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w1, #5, LBB0_16
LBB0_9:                                 ; %else42
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w1, #6, LBB0_17
LBB0_10:                                ; %else45
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w1, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v3 }[0], [x0]
	and	w1, w17, #0xff
	tbz	w1, #1, LBB0_5
LBB0_12:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x0, #4
	ld1.s	{ v3 }[1], [x8]
	tbz	w1, #2, LBB0_6
LBB0_13:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x0, #8
	ld1.s	{ v3 }[2], [x8]
	tbz	w1, #3, LBB0_7
LBB0_14:                                ; %cond.load35
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x0, #12
	ld1.s	{ v3 }[3], [x8]
	ldr	q16, [x2, #16]
	tbz	w1, #4, LBB0_8
LBB0_15:                                ; %cond.load38
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x0, #16
	ld1.s	{ v16 }[0], [x8]
	tbz	w1, #5, LBB0_9
LBB0_16:                                ; %cond.load41
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x0, #20
	ld1.s	{ v16 }[1], [x8]
	tbz	w1, #6, LBB0_10
LBB0_17:                                ; %cond.load44
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x0, #24
	ld1.s	{ v16 }[2], [x8]
	tbz	w1, #7, LBB0_2
LBB0_18:                                ; %cond.load47
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x8, x0, #28
	ld1.s	{ v16 }[3], [x8]
	b	LBB0_2
LBB0_19:                                ; %direct.true79.preheader
	xtn.8b	v29, v2
	sshll.2d	v3, v1, #0
	sshll.2d	v20, v0, #0
	sshll2.2d	v26, v1, #0
	sshll2.2d	v27, v0, #0
Lloh6:
	adrp	x8, lCPI0_6@PAGE
Lloh7:
	ldr	q2, [x8, lCPI0_6@PAGEOFF]
	and.16b	v24, v3, v2
	movi.2d	v16, #0000000000000000
Lloh8:
	adrp	x8, lCPI0_7@PAGE
Lloh9:
	ldr	q18, [x8, lCPI0_7@PAGEOFF]
	and.16b	v18, v3, v18
Lloh10:
	adrp	x8, lCPI0_8@PAGE
Lloh11:
	ldr	q3, [x8, lCPI0_8@PAGEOFF]
	and.16b	v19, v20, v3
Lloh12:
	adrp	x8, lCPI0_9@PAGE
Lloh13:
	ldr	q3, [x8, lCPI0_9@PAGEOFF]
	and.16b	v21, v26, v3
Lloh14:
	adrp	x8, lCPI0_10@PAGE
Lloh15:
	ldr	q3, [x8, lCPI0_10@PAGEOFF]
	and.16b	v22, v27, v3
	movi.8b	v3, #1
	and.8b	v3, v29, v3
	umov.b	w16, v3[0]
	movi.2d	v28, #0000000000000000
	movi.2d	v2, #0000000000000000
	mov.b	v2[0], v29[0]
	umaxv.8b	b23, v2
	fmov	w8, s23
	rbit	w12, w16
	clz	w12, w12
	tst	w8, #0x1
	csel	w12, w12, wzr, ne
	mov	w17, #4096                      ; =0x1000
	dup.2d	v25, x17
	str	q24, [sp, #208]                 ; 16-byte Spill
	orr.16b	v3, v24, v25
	mov	w17, #4097                      ; =0x1001
	dup.2s	v23, w17
	xtn.2s	v24, v7
	str	q3, [sp, #192]                  ; 16-byte Spill
	umlal.2d	v3, v24, v23
	str	q29, [sp, #336]                 ; 16-byte Spill
	mov.b	v28[0], v29[0]
	ushll.2d	v7, v28, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	str	q3, [sp, #288]                  ; 16-byte Spill
	and.16b	v7, v7, v3
	str	q16, [sp, #1520]
	str	q16, [sp, #1504]
	str	q16, [sp, #1488]
	str	q7, [sp, #1472]
	ubfiz	x0, x12, #3, #3
	add	x17, sp, #1472
	ldr	x17, [x17, x0]
	sub	x17, x17, x12
	add	x17, x13, x17, lsl #2
	str	q22, [sp, #1584]
	str	q19, [sp, #1568]
	str	q21, [sp, #1552]
	str	q18, [sp, #1536]
	add	x13, sp, #1536
	ldr	x13, [x13, x0]
	orr	x13, x13, #0x4000
	sub	x13, x13, w12, uxtw #2
	tst	w16, #0x1
	csel	x13, xzr, x13, eq
	add	x0, x26, x13
	ldr	q21, [x0]
	tbnz	w8, #0, LBB0_118
; %bb.20:                               ; %else52
	tbnz	w16, #1, LBB0_119
LBB0_21:                                ; %else55
	tbnz	w16, #2, LBB0_120
LBB0_22:                                ; %else58
	tbnz	w16, #3, LBB0_121
LBB0_23:                                ; %else61
	adrp	x8, lCPI0_3@PAGE
	adrp	x1, lCPI0_4@PAGE
	adrp	x2, lCPI0_5@PAGE
	ldr	q29, [x0, #16]
	tbnz	w16, #4, LBB0_122
LBB0_24:                                ; %else64
	ldr	q16, [x8, lCPI0_3@PAGEOFF]
	ldr	q19, [x1, lCPI0_4@PAGEOFF]
	ldr	q22, [x2, lCPI0_5@PAGEOFF]
	tbnz	w16, #5, LBB0_123
LBB0_25:                                ; %else67
	and.16b	v3, v27, v16
	and.16b	v16, v26, v19
	and.16b	v7, v20, v22
	tbz	w16, #6, LBB0_27
LBB0_26:                                ; %cond.load69
	add	x8, x17, #24
	ld1.s	{ v29 }[2], [x8]
LBB0_27:                                ; %else70
	stp	q7, q16, [sp, #80]              ; 32-byte Folded Spill
	orr.16b	v7, v7, v25
	orr.16b	v16, v16, v25
	str	q3, [sp, #112]                  ; 16-byte Spill
	orr.16b	v3, v3, v25
	xtn.2s	v22, v5
	xtn.2s	v5, v6
	xtn.2s	v4, v4
	str	q2, [sp, #352]                  ; 16-byte Spill
	str	q17, [sp, #304]                 ; 16-byte Spill
	tbz	w16, #7, LBB0_29
; %bb.28:                               ; %cond.load72
	add	x8, x17, #28
	ld1.s	{ v29 }[3], [x8]
LBB0_29:                                ; %else73
	umull.2d	v6, v24, v23
	stp	q7, q3, [sp, #160]              ; 32-byte Folded Spill
	mov.16b	v2, v3
	umlal.2d	v2, v4, v23
	str	q2, [sp, #272]                  ; 16-byte Spill
	stp	q16, q21, [sp, #128]            ; 32-byte Folded Spill
	mov.16b	v2, v16
	umlal.2d	v2, v22, v23
	str	q2, [sp, #256]                  ; 16-byte Spill
	mov.16b	v2, v7
	umlal.2d	v2, v5, v23
	stp	q6, q2, [sp, #224]              ; 32-byte Folded Spill
	sshll.2d	v25, v1, #0
	sshll.2d	v28, v0, #0
	add	x8, x26, x13
	str	q29, [sp, #64]                  ; 16-byte Spill
	stp	q21, q29, [x8]
	fmov	x28, d18
	mov	w16, #4                         ; =0x4
	dup.2d	v4, x16
	and.16b	v22, v27, v4
	and.16b	v11, v26, v4
	and.16b	v12, v28, v4
	and.16b	v13, v25, v4
	fmov	x27, d13
	ldp	q5, q4, [x26, #96]
	and.16b	v4, v0, v4
	and.16b	v5, v1, v5
	ldp	q6, q18, [x26, #64]
	and.16b	v18, v0, v18
	and.16b	v6, v1, v6
	ldp	q24, q23, [x26, #32]
	and.16b	v23, v0, v23
	and.16b	v24, v1, v24
	add	x8, x26, x28
	ldp	q29, q30, [x8]
	and.16b	v30, v0, v30
	mov	x8, x27
	and.16b	v31, v1, v29
	mov.16b	v9, v13
	mov.16b	v14, v11
	mov.16b	v15, v12
	mov.16b	v10, v22
LBB0_30:                                ; %direct.true79
                                        ; =>This Inner Loop Header: Depth=1
	add	x8, x26, x8, lsl #5
	ldp	q29, q8, [x8]
	fadd.4s	v29, v31, v29
	fadd.4s	v8, v30, v8
	ldp	q3, q2, [x8, #32]
	fadd.4s	v3, v24, v3
	fadd.4s	v2, v23, v2
	ldp	q19, q16, [x8, #64]
	fadd.4s	v19, v6, v19
	fadd.4s	v16, v18, v16
	ldp	q17, q20, [x8, #96]
	fadd.4s	v17, v5, v17
	fadd.4s	v20, v4, v20
	dup.2d	v7, x16
	and.16b	v21, v27, v7
	add.2d	v10, v10, v21
	and.16b	v21, v26, v7
	add.2d	v14, v14, v21
	and.16b	v21, v28, v7
	add.2d	v15, v15, v21
	and.16b	v7, v25, v7
	add.2d	v9, v9, v7
	bit.16b	v30, v8, v0
	bit.16b	v31, v29, v1
	bit.16b	v23, v2, v0
	bit.16b	v24, v3, v1
	bit.16b	v18, v16, v0
	bit.16b	v6, v19, v1
	bit.16b	v4, v20, v0
	bit.16b	v5, v17, v1
	fmov	x8, d9
	cmp	x8, #512
	b.lt	LBB0_30
; %bb.31:                               ; %direct.false80
	mov	x30, #0                         ; =0x0
	ldr	q2, [sp, #64]                   ; 16-byte Reload
	fadd.4s	v2, v2, v30
	ldr	q3, [sp, #144]                  ; 16-byte Reload
	fadd.4s	v3, v3, v31
	ldp	q28, q25, [sp, #336]            ; 32-byte Folded Reload
	zip1.8b	v7, v25, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v3, v7, v3
	zip2.8b	v7, v25, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v2, v7, v2
	zip2.8b	v7, v28, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	movi.2d	v16, #0000000000000000
	mov.b	v16[2], v28[1]
	mov.b	v16[4], v28[2]
	mov.b	v16[6], v28[3]
	bit.16b	v2, v8, v7
	ushll.4s	v7, v16, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v3, v29, v7
	fadd.4s	v3, v24, v3
	fadd.4s	v2, v23, v2
	fadd.4s	v2, v18, v2
	fadd.4s	v3, v6, v3
	fadd.4s	v5, v5, v3
	fadd.4s	v6, v4, v2
	ldr	q2, [sp, #208]                  ; 16-byte Reload
	ldp	q3, q7, [sp, #80]               ; 32-byte Folded Reload
	uzp1.4s	v4, v2, v7
	ldr	q2, [sp, #112]                  ; 16-byte Reload
	uzp1.4s	v7, v3, v2
	movi.4s	v2, #1
	eor.16b	v18, v7, v2
	eor.16b	v2, v4, v2
	mov.s	w8, v2[1]
	mov.s	w17, v2[2]
	mov.s	w0, v2[3]
	fmov	w16, s2
	add	x1, sp, #1112
	bfxil	x1, x16, #0, #3
	str	d28, [sp, #1112]
	ldrb	w1, [x1]
	and	x2, x16, #0x7
	umov.b	w16, v28[0]
	str	q6, [sp, #1328]
	str	q5, [sp, #1312]
	add	x3, sp, #1312
	ldr	s3, [x3, x2, lsl #2]
	ands	w7, w16, #0x1
	tst	w7, w1
	movi.2d	v2, #0000000000000000
	fcsel	s16, s3, s2, ne
	and	x2, x8, #0x7
	add	x1, sp, #1112
	bfxil	x1, x8, #0, #3
	ldrb	w8, [x1]
	umov.b	w1, v28[1]
	and	w8, w1, w8
	str	q6, [sp, #1296]
	str	q5, [sp, #1280]
	add	x3, sp, #1280
	ldr	s3, [x3, x2, lsl #2]
	tst	w8, #0x1
	fcsel	s19, s3, s2, ne
	and	x8, x17, #0x7
	add	x2, sp, #1112
	bfxil	x2, x17, #0, #3
	ldrb	w2, [x2]
	umov.b	w17, v28[2]
	and	w2, w17, w2
	str	q6, [sp, #1264]
	str	q5, [sp, #1248]
	add	x3, sp, #1248
	ldr	s3, [x3, x8, lsl #2]
	tst	w2, #0x1
	fcsel	s20, s3, s2, ne
	and	x8, x0, #0x7
	add	x2, sp, #1112
	bfxil	x2, x0, #0, #3
	umov.b	w0, v28[3]
	ldrb	w2, [x2]
	str	q6, [sp, #1232]
	str	q5, [sp, #1216]
	add	x3, sp, #1216
	ldr	s3, [x3, x8, lsl #2]
	and	w8, w0, w2
	tst	w8, #0x1
	mov.s	w8, v18[1]
	mov.s	w2, v18[2]
	fcsel	s21, s3, s2, ne
	mov.s	w3, v18[3]
	fmov	w4, s18
	and	x19, x4, #0x7
	add	x5, sp, #1112
	bfxil	x5, x4, #0, #3
	ldrb	w4, [x5]
	umov.b	w5, v28[4]
	and	w4, w5, w4
	str	q6, [sp, #1456]
	str	q5, [sp, #1440]
	add	x20, sp, #1440
	ldr	s3, [x20, x19, lsl #2]
	tst	w4, #0x1
	fcsel	s3, s3, s2, ne
	and	x19, x8, #0x7
	add	x4, sp, #1112
	bfxil	x4, x8, #0, #3
	ldrb	w8, [x4]
	umov.b	w4, v28[5]
	and	w8, w4, w8
	str	q6, [sp, #1424]
	str	q5, [sp, #1408]
	add	x20, sp, #1408
	ldr	s17, [x20, x19, lsl #2]
	tst	w8, #0x1
	fcsel	s17, s17, s2, ne
	and	x8, x2, #0x7
	add	x19, sp, #1112
	bfxil	x19, x2, #0, #3
	ldrb	w19, [x19]
	umov.b	w2, v28[6]
	and	w19, w2, w19
	str	q6, [sp, #1392]
	str	q5, [sp, #1376]
	add	x20, sp, #1376
	ldr	s18, [x20, x8, lsl #2]
	tst	w19, #0x1
	fcsel	s18, s18, s2, ne
	and	x8, x3, #0x7
	add	x19, sp, #1112
	bfxil	x19, x3, #0, #3
	ldrb	w19, [x19]
	umov.b	w3, v28[7]
	and	w19, w3, w19
	str	q6, [sp, #1360]
	str	q5, [sp, #1344]
	add	x20, sp, #1344
	ldr	s23, [x20, x8, lsl #2]
	tst	w19, #0x1
	fcsel	s23, s23, s2, ne
	mov.s	v3[1], v17[0]
	mov.s	v3[2], v18[0]
	mov.s	v3[3], v23[0]
	mov.s	v16[1], v19[0]
	mov.s	v16[2], v20[0]
	mov.s	v16[3], v21[0]
	add	x8, sp, #1112
	fadd.4s	v5, v5, v16
	fadd.4s	v3, v6, v3
	movi.4s	v6, #2
	eor.16b	v7, v7, v6
	eor.16b	v4, v4, v6
	fmov	w19, s4
	add	x20, sp, #1112
	bfxil	x20, x19, #0, #3
	ldrb	w20, [x20]
	and	x19, x19, #0x7
	str	q3, [sp, #1200]
	str	q5, [sp, #1184]
	add	x21, sp, #1184
	ldr	s4, [x21, x19, lsl #2]
	tst	w7, w20
	fcsel	s4, s4, s2, ne
	fmov	w7, s7
	and	x19, x7, #0x7
	bfxil	x8, x7, #0, #3
	ldrb	w8, [x8]
	and	w8, w5, w8
	str	q3, [sp, #1168]
	str	q5, [sp, #1152]
	add	x7, sp, #1152
	ldr	s6, [x7, x19, lsl #2]
	tst	w8, #0x1
	fcsel	s6, s6, s2, ne
	fadd.4s	v3, v3, v6
	and	w7, w16, w5
	tst	w7, #0x1
	fcsel	s3, s3, s2, ne
	ands	w19, w16, #0x1
	fadd.4s	v4, v5, v4
	fadd	s3, s4, s3
	fcsel	s4, s3, s2, ne
	tst	w7, #0x1
	and	w20, w1, w16
	fcsel	s5, s3, s2, ne
	tst	w20, #0x1
	and	w21, w17, w16
	fcsel	s6, s3, s2, ne
	tst	w21, #0x1
	and	w22, w0, w16
	fcsel	s7, s3, s2, ne
	tst	w22, #0x1
	fcsel	s16, s3, s2, ne
	and	w23, w4, w16
	tst	w23, #0x1
	fcsel	s17, s3, s2, ne
	and	w24, w2, w16
	tst	w24, #0x1
	fcsel	s18, s3, s2, ne
	and	w25, w3, w16
	tst	w25, #0x1
	fcsel	s3, s3, s2, ne
	mov.s	v4[1], v6[0]
	mov.s	v4[2], v7[0]
	mov.s	v4[3], v16[0]
	mov.s	v5[1], v17[0]
	mov.s	v5[2], v18[0]
	mov.s	v5[3], v3[0]
	rbit	w8, w6
	clz	w8, w8
	str	q5, [sp, #1136]
	str	q4, [sp, #1120]
	str	x8, [sp, #208]                  ; 8-byte Spill
	and	x8, x8, #0x7
	add	x6, sp, #1120
	ldr	s3, [x6, x8, lsl #2]
	movi.2d	v4, #0000000000000000
	mov.b	v28[0], wzr
	str	q28, [sp, #64]                  ; 16-byte Spill
	fadd	s2, s3, s2
	mov	w8, #2048                       ; =0x800
	movk	w8, #17792, lsl #16
	fmov	s3, w8
	fdiv	s2, s2, s3
	dup.4s	v2, v2[0]
	ushll2.2d	v3, v0, #0
	mov	w8, #1                          ; =0x1
	dup.2d	v5, x8
	and.16b	v18, v3, v5
	ushll2.2d	v3, v1, #0
	and.16b	v19, v3, v5
	ushll.2d	v3, v0, #0
	and.16b	v20, v3, v5
	ushll.2d	v3, v1, #0
	and.16b	v21, v3, v5
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
LBB0_32:                                ; %direct.true114
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x8, x30, #5
	add	x6, x26, x8
	ldp	q16, q3, [x6]
	fsub.4s	v16, v16, v2
	fsub.4s	v3, v3, v2
	add	x8, x11, x8
	ldp	q17, q23, [x8]
	bif.16b	v3, v23, v0
	bif.16b	v16, v17, v1
	stp	q16, q3, [x8]
	add.2d	v5, v5, v19
	add.2d	v6, v6, v20
	add.2d	v7, v7, v18
	add.2d	v4, v4, v21
	fmov	x30, d4
	cmp	x30, #512
	b.lt	LBB0_32
; %bb.33:                               ; %direct.true151.preheader
Lloh16:
	adrp	x8, lCPI0_11@PAGE
Lloh17:
	ldr	q3, [x8, lCPI0_11@PAGEOFF]
	and.16b	v3, v0, v3
	str	q3, [sp, #80]                   ; 16-byte Spill
Lloh18:
	adrp	x8, lCPI0_12@PAGE
Lloh19:
	ldr	q3, [x8, lCPI0_12@PAGEOFF]
	and.16b	v3, v1, v3
	str	q3, [sp, #48]                   ; 16-byte Spill
Lloh20:
	adrp	x8, lCPI0_13@PAGE
Lloh21:
	ldr	q3, [x8, lCPI0_13@PAGEOFF]
	and.16b	v3, v0, v3
	str	q3, [sp, #112]                  ; 16-byte Spill
Lloh22:
	adrp	x8, lCPI0_14@PAGE
Lloh23:
	ldr	q3, [x8, lCPI0_14@PAGEOFF]
	and.16b	v3, v1, v3
	str	q3, [sp, #96]                   ; 16-byte Spill
Lloh24:
	adrp	x8, lCPI0_15@PAGE
Lloh25:
	ldr	q3, [x8, lCPI0_15@PAGEOFF]
	and.16b	v3, v1, v3
	str	q3, [sp, #144]                  ; 16-byte Spill
	add	x8, x26, x13
	ldp	q4, q3, [x8]
	fsub.4s	v5, v4, v2
	fsub.4s	v6, v3, v2
	add	x8, x11, x13
	ldp	q2, q3, [x8]
	zip2.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	stp	q6, q5, [sp, #16]               ; 32-byte Folded Spill
	bit.16b	v3, v6, v4
	zip1.8b	v4, v25, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v2, v5, v4
	stp	q2, q3, [x8]
	ldr	q2, [x26, #16528]
	ldr	q3, [x26, #16512]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v14, v0, v2
	and.16b	v16, v1, v3
	ldr	q2, [x26, #16496]
	ldr	q3, [x26, #16480]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v6, v0, v2
	and.16b	v5, v1, v3
	ldr	q2, [x26, #16464]
	ldr	q3, [x26, #16448]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v7, v0, v2
	and.16b	v4, v1, v3
	add	x8, x11, x28
	ldp	q3, q2, [x8]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v23, v0, v2
	and.16b	v2, v1, v3
	mov	w26, #4                         ; =0x4
LBB0_34:                                ; %direct.true151
                                        ; =>This Inner Loop Header: Depth=1
	sshll.2d	v3, v1, #0
	sshll.2d	v17, v0, #0
	add	x8, x11, x27, lsl #5
	ldp	q28, q24, [x8]
	and.16b	v28, v1, v28
	and.16b	v24, v0, v24
	fmul.4s	v10, v24, v24
	fmul.4s	v24, v28, v28
	fadd.4s	v24, v2, v24
	fadd.4s	v28, v23, v10
	ldp	q15, q10, [x8, #32]
	and.16b	v15, v1, v15
	and.16b	v10, v0, v10
	fmul.4s	v10, v10, v10
	fmul.4s	v15, v15, v15
	fadd.4s	v15, v4, v15
	fadd.4s	v10, v7, v10
	ldp	q29, q25, [x8, #64]
	and.16b	v29, v1, v29
	and.16b	v25, v0, v25
	fmul.4s	v25, v25, v25
	fmul.4s	v29, v29, v29
	fadd.4s	v29, v5, v29
	fadd.4s	v25, v6, v25
	ldp	q31, q30, [x8, #96]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	fmul.4s	v30, v30, v30
	fmul.4s	v31, v31, v31
	fadd.4s	v31, v16, v31
	fadd.4s	v30, v14, v30
	dup.2d	v8, x26
	and.16b	v9, v27, v8
	add.2d	v22, v22, v9
	and.16b	v9, v26, v8
	add.2d	v11, v11, v9
	and.16b	v17, v17, v8
	add.2d	v12, v12, v17
	and.16b	v3, v3, v8
	add.2d	v13, v13, v3
	bit.16b	v23, v28, v0
	bit.16b	v2, v24, v1
	bit.16b	v7, v10, v0
	bit.16b	v4, v15, v1
	bit.16b	v6, v25, v0
	bit.16b	v5, v29, v1
	bit.16b	v14, v30, v0
	bit.16b	v16, v31, v1
	fmov	x27, d13
	cmp	x27, #512
	b.lt	LBB0_34
; %bb.35:                               ; %direct.true188.preheader
	mov	x8, #0                          ; =0x0
	movi.2d	v26, #0000000000000000
	ldr	q29, [sp, #304]                 ; 16-byte Reload
	fmov	w26, s29
	movi.2d	v27, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	ldr	q30, [sp, #352]                 ; 16-byte Reload
	b	LBB0_37
LBB0_36:                                ; %else98
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x8, x10, x27
	stp	q12, q22, [x8]
	add.2d	v27, v27, v19
	add.2d	v10, v10, v20
	add.2d	v11, v11, v18
	add.2d	v26, v26, v21
	fmov	x8, d26
	cmp	x8, #512
	b.ge	LBB0_53
LBB0_37:                                ; %direct.true188
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x27, x8, #5
	add	x28, x15, x27
	add	x8, x10, x27
	ldr	q12, [x8]
	tbnz	w26, #0, LBB0_45
; %bb.38:                               ; %else77
                                        ;   in Loop: Header=BB0_37 Depth=1
	and	w30, w26, #0xff
	tbnz	w30, #1, LBB0_46
LBB0_39:                                ; %else80
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w30, #2, LBB0_47
LBB0_40:                                ; %else83
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w30, #3, LBB0_48
LBB0_41:                                ; %else86
                                        ;   in Loop: Header=BB0_37 Depth=1
	ldr	q22, [x8, #16]
	tbnz	w30, #4, LBB0_49
LBB0_42:                                ; %else89
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w30, #5, LBB0_50
LBB0_43:                                ; %else92
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w30, #6, LBB0_51
LBB0_44:                                ; %else95
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbz	w30, #7, LBB0_36
	b	LBB0_52
LBB0_45:                                ; %cond.load76
                                        ;   in Loop: Header=BB0_37 Depth=1
	ld1.s	{ v12 }[0], [x28]
	and	w30, w26, #0xff
	tbz	w30, #1, LBB0_39
LBB0_46:                                ; %cond.load79
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x6, x28, #4
	ld1.s	{ v12 }[1], [x6]
	tbz	w30, #2, LBB0_40
LBB0_47:                                ; %cond.load82
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x6, x28, #8
	ld1.s	{ v12 }[2], [x6]
	tbz	w30, #3, LBB0_41
LBB0_48:                                ; %cond.load85
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x6, x28, #12
	ld1.s	{ v12 }[3], [x6]
	ldr	q22, [x8, #16]
	tbz	w30, #4, LBB0_42
LBB0_49:                                ; %cond.load88
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x8, x28, #16
	ld1.s	{ v22 }[0], [x8]
	tbz	w30, #5, LBB0_43
LBB0_50:                                ; %cond.load91
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x8, x28, #20
	ld1.s	{ v22 }[1], [x8]
	tbz	w30, #6, LBB0_44
LBB0_51:                                ; %cond.load94
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x8, x28, #24
	ld1.s	{ v22 }[2], [x8]
	tbz	w30, #7, LBB0_36
LBB0_52:                                ; %cond.load97
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x8, x28, #28
	ld1.s	{ v22 }[3], [x8]
	b	LBB0_36
LBB0_53:                                ; %direct.false189
	mov	b3, v30[0]
	mov.b	v3[4], v30[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q17, [sp, #192]                 ; 16-byte Reload
	and.16b	v3, v3, v17
	mov	b17, v30[2]
	mov.b	v17[4], v30[3]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldr	q22, [sp, #128]                 ; 16-byte Reload
	and.16b	v17, v17, v22
	mov	b22, v30[4]
	mov.b	v22[4], v30[5]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	ldp	q25, q26, [sp, #160]            ; 32-byte Folded Reload
	and.16b	v25, v22, v25
	mov	b22, v30[6]
	mov.b	v22[4], v30[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v26, v22, v26
Lloh26:
	adrp	x8, lCPI0_16@PAGE
Lloh27:
	ldr	d22, [x8, lCPI0_16@PAGEOFF]
	shl.8b	v27, v30, #7
	cmlt.8b	v27, v27, #0
	and.8b	v22, v27, v22
	addv.8b	b22, v22
	str	q26, [sp, #1088]
	str	q25, [sp, #1072]
	str	q17, [sp, #1056]
	str	q3, [sp, #1040]
	and	x8, x12, #0x7
	add	x6, sp, #1040
	ldr	x8, [x6, x8, lsl #3]
	fmov	w27, s22
	sub	x8, x8, x12
	lsl	x26, x8, #2
	add	x15, x15, x26
	add	x8, x10, x13
	ldr	q26, [x8]
	tbnz	w27, #0, LBB0_124
; %bb.54:                               ; %else102
	tbnz	w27, #1, LBB0_125
LBB0_55:                                ; %else105
	tbnz	w27, #2, LBB0_126
LBB0_56:                                ; %else108
	tbnz	w27, #3, LBB0_127
LBB0_57:                                ; %else111
	ldr	q27, [x8, #16]
	tbnz	w27, #4, LBB0_128
LBB0_58:                                ; %else114
	tbnz	w27, #5, LBB0_129
LBB0_59:                                ; %else117
	tbnz	w27, #6, LBB0_130
LBB0_60:                                ; %else120
	tbz	w27, #7, LBB0_62
LBB0_61:                                ; %cond.load122
	add	x8, x15, #28
	ld1.s	{ v27 }[3], [x8]
LBB0_62:                                ; %else123
	mov	x8, #0                          ; =0x0
	add	x15, x10, x13
	stp	q26, q27, [x15]
	movi.2d	v26, #0000000000000000
	fmov	w15, s29
	movi.2d	v27, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	b	LBB0_64
LBB0_63:                                ; %else148
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x8, x9, x27
	stp	q12, q13, [x8]
	add.2d	v27, v27, v19
	add.2d	v10, v10, v20
	add.2d	v11, v11, v18
	add.2d	v26, v26, v21
	fmov	x8, d26
	cmp	x8, #512
	b.ge	LBB0_80
LBB0_64:                                ; %direct.true214
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x27, x8, #5
	add	x28, x14, x27
	add	x8, x9, x27
	ldr	q12, [x8]
	tbnz	w15, #0, LBB0_72
; %bb.65:                               ; %else127
                                        ;   in Loop: Header=BB0_64 Depth=1
	and	w30, w15, #0xff
	tbnz	w30, #1, LBB0_73
LBB0_66:                                ; %else130
                                        ;   in Loop: Header=BB0_64 Depth=1
	tbnz	w30, #2, LBB0_74
LBB0_67:                                ; %else133
                                        ;   in Loop: Header=BB0_64 Depth=1
	tbnz	w30, #3, LBB0_75
LBB0_68:                                ; %else136
                                        ;   in Loop: Header=BB0_64 Depth=1
	ldr	q13, [x8, #16]
	tbnz	w30, #4, LBB0_76
LBB0_69:                                ; %else139
                                        ;   in Loop: Header=BB0_64 Depth=1
	tbnz	w30, #5, LBB0_77
LBB0_70:                                ; %else142
                                        ;   in Loop: Header=BB0_64 Depth=1
	tbnz	w30, #6, LBB0_78
LBB0_71:                                ; %else145
                                        ;   in Loop: Header=BB0_64 Depth=1
	tbz	w30, #7, LBB0_63
	b	LBB0_79
LBB0_72:                                ; %cond.load126
                                        ;   in Loop: Header=BB0_64 Depth=1
	ld1.s	{ v12 }[0], [x28]
	and	w30, w15, #0xff
	tbz	w30, #1, LBB0_66
LBB0_73:                                ; %cond.load129
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x6, x28, #4
	ld1.s	{ v12 }[1], [x6]
	tbz	w30, #2, LBB0_67
LBB0_74:                                ; %cond.load132
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x6, x28, #8
	ld1.s	{ v12 }[2], [x6]
	tbz	w30, #3, LBB0_68
LBB0_75:                                ; %cond.load135
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x6, x28, #12
	ld1.s	{ v12 }[3], [x6]
	ldr	q13, [x8, #16]
	tbz	w30, #4, LBB0_69
LBB0_76:                                ; %cond.load138
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x8, x28, #16
	ld1.s	{ v13 }[0], [x8]
	tbz	w30, #5, LBB0_70
LBB0_77:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x8, x28, #20
	ld1.s	{ v13 }[1], [x8]
	tbz	w30, #6, LBB0_71
LBB0_78:                                ; %cond.load144
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x8, x28, #24
	ld1.s	{ v13 }[2], [x8]
	tbz	w30, #7, LBB0_63
LBB0_79:                                ; %cond.load147
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x8, x28, #28
	ld1.s	{ v13 }[3], [x8]
	b	LBB0_63
LBB0_80:                                ; %direct.false215
	zip2.8b	v3, v30, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldp	q17, q26, [sp, #16]             ; 32-byte Folded Reload
	and.16b	v17, v3, v17
	zip1.8b	v25, v30, v0
	ushll.4s	v25, v25, #0
	shl.4s	v25, v25, #31
	cmlt.4s	v25, v25, #0
	and.16b	v26, v25, v26
	fmul.4s	v26, v26, v26
	fmul.4s	v17, v17, v17
	fadd.4s	v17, v17, v23
	fadd.4s	v2, v26, v2
	and.16b	v2, v25, v2
	and.16b	v3, v3, v17
	ldr	q23, [sp, #64]                  ; 16-byte Reload
	zip2.8b	v17, v23, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v3, v28, v17
	zip1.8b	v17, v23, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v2, v24, v17
	fadd.4s	v2, v4, v2
	fadd.4s	v3, v7, v3
	fadd.4s	v3, v6, v3
	fadd.4s	v2, v5, v2
	fadd.4s	v4, v16, v2
	fadd.4s	v5, v14, v3
	ldr	q16, [sp, #48]                  ; 16-byte Reload
	fmov	w8, s16
	add	x15, sp, #440
	bfxil	x15, x8, #0, #3
	ldr	q2, [sp, #336]                  ; 16-byte Reload
	str	d2, [sp, #440]
	ldrb	w15, [x15]
	and	x8, x8, #0x7
	stp	q4, q5, [sp, #864]
	add	x6, sp, #864
	ldr	s3, [x6, x8, lsl #2]
	tst	w19, w15
	movi.2d	v2, #0000000000000000
	fcsel	s6, s3, s2, ne
	mov.s	w8, v16[1]
	and	x15, x8, #0x7
	add	x6, sp, #440
	bfxil	x6, x8, #0, #3
	ldrb	w8, [x6]
	stp	q4, q5, [sp, #832]
	add	x6, sp, #832
	ldr	s3, [x6, x15, lsl #2]
	and	w8, w1, w8
	tst	w8, #0x1
	fcsel	s7, s3, s2, ne
	mov.s	w8, v16[2]
	and	x15, x8, #0x7
	add	x6, sp, #440
	bfxil	x6, x8, #0, #3
	ldrb	w8, [x6]
	and	w8, w17, w8
	stp	q4, q5, [sp, #800]
	add	x6, sp, #800
	ldr	s3, [x6, x15, lsl #2]
	tst	w8, #0x1
	mov.s	w8, v16[3]
	fcsel	s16, s3, s2, ne
	and	x15, x8, #0x7
	add	x6, sp, #440
	bfxil	x6, x8, #0, #3
	ldrb	w8, [x6]
	and	w8, w0, w8
	stp	q4, q5, [sp, #768]
	add	x6, sp, #768
	ldr	s3, [x6, x15, lsl #2]
	tst	w8, #0x1
	fcsel	s17, s3, s2, ne
	ldr	q25, [sp, #80]                  ; 16-byte Reload
	fmov	w8, s25
	and	x15, x8, #0x7
	add	x6, sp, #440
	bfxil	x6, x8, #0, #3
	ldrb	w8, [x6]
	and	w8, w5, w8
	stp	q4, q5, [sp, #992]
	add	x6, sp, #992
	ldr	s3, [x6, x15, lsl #2]
	tst	w8, #0x1
	fcsel	s3, s3, s2, ne
	mov.s	w8, v25[1]
	and	x15, x8, #0x7
	add	x6, sp, #440
	bfxil	x6, x8, #0, #3
	ldrb	w8, [x6]
	and	w8, w4, w8
	stp	q4, q5, [sp, #960]
	add	x6, sp, #960
	ldr	s23, [x6, x15, lsl #2]
	tst	w8, #0x1
	fcsel	s23, s23, s2, ne
	mov.s	w8, v25[2]
	and	x15, x8, #0x7
	add	x6, sp, #440
	bfxil	x6, x8, #0, #3
	ldrb	w8, [x6]
	and	w8, w2, w8
	stp	q4, q5, [sp, #928]
	add	x6, sp, #928
	ldr	s24, [x6, x15, lsl #2]
	tst	w8, #0x1
	fcsel	s24, s24, s2, ne
	mov.s	w8, v25[3]
	and	x15, x8, #0x7
	add	x6, sp, #440
	bfxil	x6, x8, #0, #3
	ldrb	w8, [x6]
	and	w8, w3, w8
	stp	q4, q5, [sp, #896]
	add	x6, sp, #896
	ldr	s25, [x6, x15, lsl #2]
	tst	w8, #0x1
	fcsel	s25, s25, s2, ne
	mov.s	v3[1], v23[0]
	mov.s	v3[2], v24[0]
	mov.s	v3[3], v25[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	add	x15, sp, #440
	mov.s	v6[3], v17[0]
	fadd.4s	v4, v4, v6
	fadd.4s	v5, v5, v3
	ldr	q17, [sp, #96]                  ; 16-byte Reload
	fmov	w8, s17
	add	x6, sp, #440
	bfxil	x6, x8, #0, #3
	ldrb	w6, [x6]
	and	x8, x8, #0x7
	stp	q4, q5, [sp, #608]
	add	x27, sp, #608
	ldr	s3, [x27, x8, lsl #2]
	tst	w19, w6
	mov.s	w8, v17[1]
	fcsel	s6, s3, s2, ne
	and	x6, x8, #0x7
	add	x27, sp, #440
	bfxil	x27, x8, #0, #3
	ldrb	w8, [x27]
	and	w8, w1, w8
	stp	q4, q5, [sp, #576]
	add	x1, sp, #576
	ldr	s3, [x1, x6, lsl #2]
	tst	w8, #0x1
	fcsel	s7, s3, s2, ne
	mov.s	w8, v17[2]
	and	x1, x8, #0x7
	add	x6, sp, #440
	bfxil	x6, x8, #0, #3
	ldrb	w8, [x6]
	stp	q4, q5, [sp, #544]
	add	x6, sp, #544
	ldr	s3, [x6, x1, lsl #2]
	and	w8, w17, w8
	tst	w8, #0x1
	fcsel	s16, s3, s2, ne
	mov.s	w8, v17[3]
	and	x17, x8, #0x7
	add	x1, sp, #440
	bfxil	x1, x8, #0, #3
	ldrb	w8, [x1]
	and	w8, w0, w8
	stp	q4, q5, [sp, #512]
	add	x0, sp, #512
	ldr	s3, [x0, x17, lsl #2]
	tst	w8, #0x1
	fcsel	s17, s3, s2, ne
	ldr	q25, [sp, #112]                 ; 16-byte Reload
	fmov	w8, s25
	and	x17, x8, #0x7
	add	x0, sp, #440
	bfxil	x0, x8, #0, #3
	ldrb	w8, [x0]
	and	w8, w5, w8
	stp	q4, q5, [sp, #736]
	add	x0, sp, #736
	ldr	s3, [x0, x17, lsl #2]
	tst	w8, #0x1
	fcsel	s3, s3, s2, ne
	mov.s	w8, v25[1]
	and	x17, x8, #0x7
	add	x0, sp, #440
	bfxil	x0, x8, #0, #3
	ldrb	w8, [x0]
	and	w8, w4, w8
	stp	q4, q5, [sp, #704]
	add	x0, sp, #704
	ldr	s23, [x0, x17, lsl #2]
	tst	w8, #0x1
	fcsel	s23, s23, s2, ne
	mov.s	w8, v25[2]
	and	x17, x8, #0x7
	add	x0, sp, #440
	bfxil	x0, x8, #0, #3
	ldrb	w8, [x0]
	and	w8, w2, w8
	stp	q4, q5, [sp, #672]
	add	x0, sp, #672
	ldr	s24, [x0, x17, lsl #2]
	tst	w8, #0x1
	fcsel	s24, s24, s2, ne
	mov.s	w8, v25[3]
	and	x17, x8, #0x7
	add	x0, sp, #440
	bfxil	x0, x8, #0, #3
	ldrb	w8, [x0]
	and	w8, w3, w8
	stp	q4, q5, [sp, #640]
	add	x0, sp, #640
	ldr	s25, [x0, x17, lsl #2]
	tst	w8, #0x1
	fcsel	s25, s25, s2, ne
	mov.s	v3[1], v23[0]
	mov.s	v3[2], v24[0]
	mov.s	v3[3], v25[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v17[0]
	fadd.4s	v4, v4, v6
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #144]                  ; 16-byte Reload
	fmov	w8, s5
	bfxil	x15, x8, #0, #3
	ldrb	w15, [x15]
	and	x8, x8, #0x7
	stp	q4, q3, [sp, #480]
	add	x17, sp, #480
	ldr	s3, [x17, x8, lsl #2]
	tst	w19, w15
	fcsel	s3, s3, s2, ne
	tst	w16, #0x1
	fadd	s3, s4, s3
	fcsel	s4, s3, s2, ne
	tst	w20, #0x1
	fcsel	s5, s3, s2, ne
	tst	w21, #0x1
	fcsel	s6, s3, s2, ne
	tst	w22, #0x1
	fcsel	s7, s3, s2, ne
	tst	w7, #0x1
	fcsel	s16, s3, s2, ne
	tst	w23, #0x1
	fcsel	s17, s3, s2, ne
	tst	w24, #0x1
	fcsel	s23, s3, s2, ne
	tst	w25, #0x1
	fcsel	s3, s3, s2, ne
	mov.s	v4[1], v5[0]
	mov.s	v4[2], v6[0]
	mov.s	v4[3], v7[0]
	mov.s	v16[1], v17[0]
	mov.s	v16[2], v23[0]
	mov.s	v16[3], v3[0]
	fmov	w15, s22
	stp	q4, q16, [sp, #448]
	add	x14, x14, x26
	add	x16, x9, x13
	ldr	q4, [x16]
	tbnz	w15, #0, LBB0_131
; %bb.81:                               ; %else152
	tbnz	w15, #1, LBB0_132
LBB0_82:                                ; %else155
	ldr	x8, [sp, #208]                  ; 8-byte Reload
	and	x8, x8, #0x7
	add	x17, sp, #448
	tbnz	w15, #2, LBB0_133
LBB0_83:                                ; %else158
	ldr	x0, [sp, #328]                  ; 8-byte Reload
	ldr	s5, [x17, x8, lsl #2]
	mov	w8, #2048                       ; =0x800
	movk	w8, #17792, lsl #16
	tbnz	w15, #3, LBB0_134
LBB0_84:                                ; %else161
	fadd	s5, s5, s2
	fmov	s6, w8
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	ldr	q2, [x16, #16]
	tbnz	w15, #4, LBB0_135
LBB0_85:                                ; %else164
	fmov	s7, w8
	fdiv	s5, s5, s6
	tbnz	w15, #5, LBB0_136
LBB0_86:                                ; %else167
	fadd	s5, s5, s7
	tbnz	w15, #6, LBB0_137
LBB0_87:                                ; %else170
	fsqrt	s5, s5
	tbz	w15, #7, LBB0_89
LBB0_88:                                ; %cond.load172
	add	x8, x14, #28
	ld1.s	{ v2 }[3], [x8]
LBB0_89:                                ; %else173
	mov	x8, #0                          ; =0x0
	add	x14, x9, x13
	stp	q4, q2, [x14]
	dup.4s	v2, v5[0]
	ldr	q3, [sp, #224]                  ; 16-byte Reload
	fmov	x14, d3
	add	x14, x0, x14, lsl #2
	movi.2d	v4, #0000000000000000
	fmov	w15, s29
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	b	LBB0_91
LBB0_90:                                ; %else190
                                        ;   in Loop: Header=BB0_91 Depth=1
	add.2d	v5, v5, v19
	add.2d	v6, v6, v20
	add.2d	v7, v7, v18
	add.2d	v4, v4, v21
	fmov	x8, d4
	cmp	x8, #512
	b.ge	LBB0_107
LBB0_91:                                ; %direct.true239
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x8, x8, #5
	add	x16, x11, x8
	ldp	q3, q16, [x16]
	and.16b	v3, v1, v3
	fdiv.4s	v3, v3, v2
	add	x16, x10, x8
	ldp	q23, q17, [x16]
	and.16b	v23, v1, v23
	fmul.4s	v3, v3, v23
	add	x16, x9, x8
	ldp	q24, q23, [x16]
	and.16b	v24, v1, v24
	fadd.4s	v24, v3, v24
	add	x16, x14, x8
	tbnz	w15, #0, LBB0_100
; %bb.92:                               ; %else176
                                        ;   in Loop: Header=BB0_91 Depth=1
	and	w8, w15, #0xff
	tbnz	w8, #1, LBB0_101
LBB0_93:                                ; %else178
                                        ;   in Loop: Header=BB0_91 Depth=1
	tbnz	w8, #2, LBB0_102
LBB0_94:                                ; %else180
                                        ;   in Loop: Header=BB0_91 Depth=1
	tbz	w8, #3, LBB0_96
LBB0_95:                                ; %cond.store181
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x17, x16, #12
	st1.s	{ v24 }[3], [x17]
LBB0_96:                                ; %else182
                                        ;   in Loop: Header=BB0_91 Depth=1
	and.16b	v3, v0, v16
	fdiv.4s	v3, v3, v2
	and.16b	v16, v0, v17
	fmul.4s	v3, v3, v16
	and.16b	v16, v0, v23
	fadd.4s	v16, v3, v16
	tbnz	w8, #4, LBB0_103
; %bb.97:                               ; %else184
                                        ;   in Loop: Header=BB0_91 Depth=1
	tbnz	w8, #5, LBB0_104
LBB0_98:                                ; %else186
                                        ;   in Loop: Header=BB0_91 Depth=1
	tbnz	w8, #6, LBB0_105
LBB0_99:                                ; %else188
                                        ;   in Loop: Header=BB0_91 Depth=1
	tbz	w8, #7, LBB0_90
	b	LBB0_106
LBB0_100:                               ; %cond.store
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	s24, [x16]
	and	w8, w15, #0xff
	tbz	w8, #1, LBB0_93
LBB0_101:                               ; %cond.store177
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x17, x16, #4
	st1.s	{ v24 }[1], [x17]
	tbz	w8, #2, LBB0_94
LBB0_102:                               ; %cond.store179
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x17, x16, #8
	st1.s	{ v24 }[2], [x17]
	tbnz	w8, #3, LBB0_95
	b	LBB0_96
LBB0_103:                               ; %cond.store183
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	s16, [x16, #16]
	tbz	w8, #5, LBB0_98
LBB0_104:                               ; %cond.store185
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x17, x16, #20
	st1.s	{ v16 }[1], [x17]
	tbz	w8, #6, LBB0_99
LBB0_105:                               ; %cond.store187
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x17, x16, #24
	st1.s	{ v16 }[2], [x17]
	tbz	w8, #7, LBB0_90
LBB0_106:                               ; %cond.store189
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x8, x16, #28
	st1.s	{ v16 }[3], [x8]
	b	LBB0_90
LBB0_107:                               ; %direct.false240
	add	x8, x11, x13
	ldp	q0, q1, [x8]
	zip1.8b	v3, v30, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v4, v3, v0
	zip2.8b	v0, v30, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	fmov	w11, s22
	fdiv.4s	v4, v4, v2
	add	x8, x10, x13
	ldp	q6, q5, [x8]
	and.16b	v6, v3, v6
	fmul.4s	v6, v4, v6
	add	x8, x9, x13
	ldp	q7, q4, [x8]
	and.16b	v3, v3, v7
	fadd.4s	v3, v6, v3
	ldr	q7, [sp, #288]                  ; 16-byte Reload
	ldr	q6, [sp, #256]                  ; 16-byte Reload
	stp	q7, q6, [sp, #368]
	ldr	q7, [sp, #240]                  ; 16-byte Reload
	ldr	q6, [sp, #272]                  ; 16-byte Reload
	stp	q7, q6, [sp, #400]
	and	x8, x12, #0x7
	add	x9, sp, #368
	ldr	x8, [x9, x8, lsl #3]
	sub	x8, x8, x12
	add	x8, x0, x8, lsl #2
	tbnz	w11, #0, LBB0_138
; %bb.108:                              ; %else193
	and.16b	v1, v0, v1
	tbnz	w11, #1, LBB0_139
LBB0_109:                               ; %else195
	fdiv.4s	v1, v1, v2
	and.16b	v2, v0, v5
	tbnz	w11, #2, LBB0_140
LBB0_110:                               ; %else197
	fmul.4s	v1, v1, v2
	and.16b	v0, v0, v4
	tbnz	w11, #3, LBB0_141
LBB0_111:                               ; %else199
	fadd.4s	v0, v1, v0
	tbnz	w11, #4, LBB0_142
LBB0_112:                               ; %else201
	tbnz	w11, #5, LBB0_143
LBB0_113:                               ; %else203
	tbnz	w11, #6, LBB0_144
LBB0_114:                               ; %else205
	tbz	w11, #7, LBB0_116
LBB0_115:                               ; %cond.store206
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_116:
	add	sp, sp, #1616
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_117:                               ; %common.ret
	ret
LBB0_118:                               ; %cond.load51
	ld1.s	{ v21 }[0], [x17]
	tbz	w16, #1, LBB0_21
LBB0_119:                               ; %cond.load54
	add	x8, x17, #4
	ld1.s	{ v21 }[1], [x8]
	tbz	w16, #2, LBB0_22
LBB0_120:                               ; %cond.load57
	add	x8, x17, #8
	ld1.s	{ v21 }[2], [x8]
	tbz	w16, #3, LBB0_23
LBB0_121:                               ; %cond.load60
	add	x8, x17, #12
	ld1.s	{ v21 }[3], [x8]
	adrp	x8, lCPI0_3@PAGE
	adrp	x1, lCPI0_4@PAGE
	adrp	x2, lCPI0_5@PAGE
	ldr	q29, [x0, #16]
	tbz	w16, #4, LBB0_24
LBB0_122:                               ; %cond.load63
	add	x0, x17, #16
	ld1.s	{ v29 }[0], [x0]
	ldr	q16, [x8, lCPI0_3@PAGEOFF]
	ldr	q19, [x1, lCPI0_4@PAGEOFF]
	ldr	q22, [x2, lCPI0_5@PAGEOFF]
	tbz	w16, #5, LBB0_25
LBB0_123:                               ; %cond.load66
	add	x8, x17, #20
	ld1.s	{ v29 }[1], [x8]
	and.16b	v3, v27, v16
	and.16b	v16, v26, v19
	and.16b	v7, v20, v22
	tbnz	w16, #6, LBB0_26
	b	LBB0_27
LBB0_124:                               ; %cond.load101
	ld1.s	{ v26 }[0], [x15]
	tbz	w27, #1, LBB0_55
LBB0_125:                               ; %cond.load104
	add	x6, x15, #4
	ld1.s	{ v26 }[1], [x6]
	tbz	w27, #2, LBB0_56
LBB0_126:                               ; %cond.load107
	add	x6, x15, #8
	ld1.s	{ v26 }[2], [x6]
	tbz	w27, #3, LBB0_57
LBB0_127:                               ; %cond.load110
	add	x6, x15, #12
	ld1.s	{ v26 }[3], [x6]
	ldr	q27, [x8, #16]
	tbz	w27, #4, LBB0_58
LBB0_128:                               ; %cond.load113
	add	x8, x15, #16
	ld1.s	{ v27 }[0], [x8]
	tbz	w27, #5, LBB0_59
LBB0_129:                               ; %cond.load116
	add	x8, x15, #20
	ld1.s	{ v27 }[1], [x8]
	tbz	w27, #6, LBB0_60
LBB0_130:                               ; %cond.load119
	add	x8, x15, #24
	ld1.s	{ v27 }[2], [x8]
	tbnz	w27, #7, LBB0_61
	b	LBB0_62
LBB0_131:                               ; %cond.load151
	ld1.s	{ v4 }[0], [x14]
	tbz	w15, #1, LBB0_82
LBB0_132:                               ; %cond.load154
	add	x8, x14, #4
	ld1.s	{ v4 }[1], [x8]
	ldr	x8, [sp, #208]                  ; 8-byte Reload
	and	x8, x8, #0x7
	add	x17, sp, #448
	tbz	w15, #2, LBB0_83
LBB0_133:                               ; %cond.load157
	add	x0, x14, #8
	ld1.s	{ v4 }[2], [x0]
	ldr	x0, [sp, #328]                  ; 8-byte Reload
	ldr	s5, [x17, x8, lsl #2]
	mov	w8, #2048                       ; =0x800
	movk	w8, #17792, lsl #16
	tbz	w15, #3, LBB0_84
LBB0_134:                               ; %cond.load160
	add	x17, x14, #12
	ld1.s	{ v4 }[3], [x17]
	fadd	s5, s5, s2
	fmov	s6, w8
	mov	w8, #50604                      ; =0xc5ac
	movk	w8, #14119, lsl #16
	ldr	q2, [x16, #16]
	tbz	w15, #4, LBB0_85
LBB0_135:                               ; %cond.load163
	add	x16, x14, #16
	ld1.s	{ v2 }[0], [x16]
	fmov	s7, w8
	fdiv	s5, s5, s6
	tbz	w15, #5, LBB0_86
LBB0_136:                               ; %cond.load166
	add	x8, x14, #20
	ld1.s	{ v2 }[1], [x8]
	fadd	s5, s5, s7
	tbz	w15, #6, LBB0_87
LBB0_137:                               ; %cond.load169
	add	x8, x14, #24
	ld1.s	{ v2 }[2], [x8]
	fsqrt	s5, s5
	tbnz	w15, #7, LBB0_88
	b	LBB0_89
LBB0_138:                               ; %cond.store192
	str	s3, [x8]
	and.16b	v1, v0, v1
	tbz	w11, #1, LBB0_109
LBB0_139:                               ; %cond.store194
	add	x9, x8, #4
	st1.s	{ v3 }[1], [x9]
	fdiv.4s	v1, v1, v2
	and.16b	v2, v0, v5
	tbz	w11, #2, LBB0_110
LBB0_140:                               ; %cond.store196
	add	x9, x8, #8
	st1.s	{ v3 }[2], [x9]
	fmul.4s	v1, v1, v2
	and.16b	v0, v0, v4
	tbz	w11, #3, LBB0_111
LBB0_141:                               ; %cond.store198
	add	x9, x8, #12
	st1.s	{ v3 }[3], [x9]
	fadd.4s	v0, v1, v0
	tbz	w11, #4, LBB0_112
LBB0_142:                               ; %cond.store200
	str	s0, [x8, #16]
	tbz	w11, #5, LBB0_113
LBB0_143:                               ; %cond.store202
	add	x9, x8, #20
	st1.s	{ v0 }[1], [x9]
	tbz	w11, #6, LBB0_114
LBB0_144:                               ; %cond.store204
	add	x9, x8, #24
	st1.s	{ v0 }[2], [x9]
	tbnz	w11, #7, LBB0_115
	b	LBB0_116
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh26, Lloh27
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 16416
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 32832
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 49248
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill13, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill14 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill14, align 1
  %.spill15 = alloca i64, align 8
  store i64 0, ptr %.spill15, align 4
  %.slot16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot16, align 64
  %.slot17 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot17, align 32
  %.slot18 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot18, align 32
  %.slot19 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot19, align 32
  %.slot20 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot20, align 32
  %.slot21 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot21, align 32
  %.spill22 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill22, align 32
  %.spill23 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill23, align 32
  %.spill24 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill24, align 32
  %.spill25 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill25, align 4
  %tile_snapshot.spill26 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill26, align 64
  %.slot27 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot27, align 64
  %.slot28 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot28, align 64
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.slot31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot31, align 32
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.spill34 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill34, align 4
  %tile_snapshot.spill35 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill35, align 64
  %.slot36 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot36, align 64
  %.spill37 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill37, align 4
  %.slot38 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot38, align 64
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.slot40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot40, align 64
  %.slot41 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot41, align 64
  %12 = getelementptr i8, ptr %argument_buffer, i64 0
  %13 = load ptr, ptr %12, align 16
  %14 = getelementptr i8, ptr %12, i64 8
  %15 = load i64, ptr %14, align 8
  %16 = insertvalue { ptr, i64 } poison, ptr %13, 0
  %17 = insertvalue { ptr, i64 } %16, i64 %15, 1
  %18 = getelementptr i8, ptr %argument_buffer, i64 16
  %19 = load ptr, ptr %18, align 16
  %20 = getelementptr i8, ptr %18, i64 8
  %21 = load i64, ptr %20, align 8
  %22 = insertvalue { ptr, i64 } poison, ptr %19, 0
  %23 = insertvalue { ptr, i64 } %22, i64 %21, 1
  %24 = getelementptr i8, ptr %argument_buffer, i64 32
  %25 = load ptr, ptr %24, align 16
  %26 = getelementptr i8, ptr %24, i64 8
  %27 = load i64, ptr %26, align 8
  %28 = insertvalue { ptr, i64 } poison, ptr %25, 0
  %29 = insertvalue { ptr, i64 } %28, i64 %27, 1
  %30 = getelementptr i8, ptr %argument_buffer, i64 48
  %31 = load ptr, ptr %30, align 16
  %32 = getelementptr i8, ptr %30, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = insertvalue { ptr, i64 } poison, ptr %31, 0
  %35 = insertvalue { ptr, i64 } %34, i64 %33, 1
  %36 = load i32, ptr %launch_config, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 12
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 4
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 16
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 8
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 20
  %46 = load i32, ptr %45, align 4
  %47 = getelementptr i8, ptr %launch_config, i64 36
  %48 = load i32, ptr %47, align 4
  %.splatinsert42 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat43 = shufflevector <8 x i32> %.splatinsert42, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat43, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %50 = mul i32 %36, 32
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat45, %49
  %52 = mul i32 %40, 1
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat47, zeroinitializer
  %54 = mul i32 %44, 1
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %54, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = add <8 x i32> %.splat49, zeroinitializer
  %56 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %51, 0
  %57 = insertvalue [3 x <8 x i32>] %56, <8 x i32> %53, 1
  %58 = insertvalue [3 x <8 x i32>] %57, <8 x i32> %55, 2
  %.splatinsert50 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %59 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat51
  %60 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  br i1 %60, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %61 = extractvalue [3 x <8 x i32>] %58, 0
  %62 = load <8 x i64>, ptr %.spill, align 64
  %63 = select <8 x i1> %59, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %62
  store <8 x i64> %63, ptr %.spill, align 64
  %64 = sub <8 x i32> %61, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %65 = select <8 x i1> %59, <8 x i32> %64, <8 x i32> zeroinitializer
  %66 = select <8 x i1> %59, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %67 = lshr <8 x i32> %65, %66
  %68 = zext <8 x i32> %67 to <8 x i64>
  %69 = select <8 x i1> %59, <8 x i64> %68, <8 x i64> zeroinitializer
  %70 = select <8 x i1> %59, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %71 = sdiv <8 x i64> %69, %70
  %72 = load <8 x i64>, ptr %.spill13, align 64
  %73 = select <8 x i1> %59, <8 x i64> %71, <8 x i64> %72
  store <8 x i64> %73, ptr %.spill13, align 64
  %74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %74, 0
  %77 = select <8 x i1> %59, <8 x ptr> %75, <8 x ptr> %76
  %78 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %74, 1
  %80 = select <8 x i1> %59, <8 x i64> %78, <8 x i64> %79
  %81 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %77, 0
  %82 = insertvalue { <8 x ptr>, <8 x i64> } %81, <8 x i64> %80, 1
  store { <8 x ptr>, <8 x i64> } %82, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %83 = icmp slt i64 %.state, 512
  br i1 %83, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state52 = load i64, ptr %.slot, align 4
  %84 = mul i64 %.state52, 8
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %84, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %85 = add <8 x i64> %.splat54, %.spill.load
  %.spill.load55 = load <8 x i64>, ptr %.spill13, align 64
  %86 = add <8 x i64> %.spill.load55, zeroinitializer
  %87 = add <8 x i64> zeroinitializer, %86
  %88 = add <8 x i64> zeroinitializer, %85
  %89 = mul <8 x i64> %87, splat (i64 4097)
  %90 = add <8 x i64> %89, %88
  %91 = extractvalue { ptr, i64 } %17, 0
  %92 = extractelement <8 x i64> %90, i32 0
  %93 = sub i64 %92, 0
  %94 = mul i64 %93, 4
  %buffer.contiguous.address = getelementptr i8, ptr %91, i64 %94
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state56 = load i64, ptr %.slot, align 4
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %.state56, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %97 = mul <8 x i64> %.splat58, splat (i64 32)
  %98 = add <8 x i64> %96, %97
  %99 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %95, 0
  %100 = insertvalue { <8 x ptr>, <8 x i64> } %99, <8 x i64> %98, 1
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %100, 1
  %103 = extractelement <8 x ptr> %101, i32 0
  %104 = extractelement <8 x i64> %102, i32 0
  %105 = sub i64 %104, 0
  %106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %107 = select i1 %106, i64 %105, i64 0
  %private.contiguous.address = getelementptr i8, ptr %103, i64 %107
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %108 = select <8 x i1> %59, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %108, ptr %private.contiguous.address, align 4
  %.state59 = load i64, ptr %.slot, align 4
  %109 = add i64 %.state59, 1
  store i64 %109, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %110 = icmp slt <8 x i64> %.spill.load60, splat (i64 1)
  %111 = load <8 x i1>, ptr %.spill14, align 1
  %112 = select <8 x i1> %59, <8 x i1> %110, <8 x i1> %111
  store <8 x i1> %112, ptr %.spill14, align 1
  %113 = and <8 x i1> %59, %110
  %114 = xor <8 x i1> %110, splat (i1 true)
  %115 = and <8 x i1> %59, %114
  %116 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %113)
  %117 = bitcast <8 x i1> %113 to i8
  %118 = call i8 @llvm.cttz.i8(i8 %117, i1 false)
  %119 = zext i8 %118 to i32
  %120 = select i1 %116, i32 %119, i32 0
  %.spill.load61 = load <8 x i64>, ptr %.spill, align 64
  %121 = add <8 x i64> splat (i64 4096), %.spill.load61
  %.spill.load62 = load <8 x i64>, ptr %.spill13, align 64
  %122 = add <8 x i64> %.spill.load62, zeroinitializer
  %123 = add <8 x i64> zeroinitializer, %122
  %124 = add <8 x i64> zeroinitializer, %121
  %125 = mul <8 x i64> %123, splat (i64 4097)
  %126 = add <8 x i64> %125, %124
  %127 = extractvalue { ptr, i64 } %17, 0
  %128 = select <8 x i1> %113, <8 x i64> %126, <8 x i64> zeroinitializer
  %129 = extractelement <8 x i64> %128, i32 %120
  %130 = zext i32 %120 to i64
  %131 = sub i64 %129, %130
  %132 = mul i64 %131, 4
  %buffer.contiguous.address63 = getelementptr i8, ptr %127, i64 %132
  %buffer.contiguous.load64 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address63, <8 x i1> %113, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %133 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %135 = add <8 x i64> %134, splat (i64 16384)
  %136 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %133, 0
  %137 = insertvalue { <8 x ptr>, <8 x i64> } %136, <8 x i64> %135, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %137, 1
  %140 = extractelement <8 x ptr> %138, i32 0
  %141 = extractelement <8 x i64> %139, i32 %120
  %142 = zext i32 %120 to i64
  %143 = mul i64 %142, 4
  %144 = sub i64 %141, %143
  %145 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %113)
  %146 = select i1 %145, i64 %144, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %140, i64 %146
  %private.contiguous.preserve67 = load <8 x float>, ptr %private.contiguous.address66, align 4
  %147 = select <8 x i1> %113, <8 x float> %buffer.contiguous.load64, <8 x float> %private.contiguous.preserve67
  store <8 x float> %147, ptr %private.contiguous.address66, align 4
  %148 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %115)
  %149 = bitcast <8 x i1> %115 to i8
  %150 = call i8 @llvm.cttz.i8(i8 %149, i1 false)
  %151 = zext i8 %150 to i32
  %152 = select i1 %148, i32 %151, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  store i64 0, ptr %.spill15, align 4
  %tile_snapshot.spill.load68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 0
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load68, 1
  %155 = add <8 x i64> %154, zeroinitializer
  %156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %153, 0
  %157 = insertvalue { <8 x ptr>, <8 x i64> } %156, <8 x i64> %155, 1
  %158 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %157, 1
  %160 = extractelement <8 x ptr> %158, i32 0
  %161 = extractelement <8 x i64> %159, i32 0
  %162 = sub i64 %161, 0
  %163 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %164 = select i1 %163, i64 %162, i64 0
  %private.contiguous.address69 = getelementptr i8, ptr %160, i64 %164
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address69, align 4
  %165 = select <8 x i1> %59, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 1
  %168 = add <8 x i64> %167, splat (i64 32)
  %169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %170 = insertvalue { <8 x ptr>, <8 x i64> } %169, <8 x i64> %168, 1
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %170, 1
  %173 = extractelement <8 x ptr> %171, i32 0
  %174 = extractelement <8 x i64> %172, i32 0
  %175 = sub i64 %174, 0
  %176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %177 = select i1 %176, i64 %175, i64 0
  %private.contiguous.address71 = getelementptr i8, ptr %173, i64 %177
  %private.contiguous.load72 = load <8 x float>, ptr %private.contiguous.address71, align 4
  %178 = select <8 x i1> %59, <8 x float> %private.contiguous.load72, <8 x float> zeroinitializer
  %tile_snapshot.spill.load73 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 0
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 1
  %181 = add <8 x i64> %180, splat (i64 64)
  %182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %179, 0
  %183 = insertvalue { <8 x ptr>, <8 x i64> } %182, <8 x i64> %181, 1
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %185 = extractvalue { <8 x ptr>, <8 x i64> } %183, 1
  %186 = extractelement <8 x ptr> %184, i32 0
  %187 = extractelement <8 x i64> %185, i32 0
  %188 = sub i64 %187, 0
  %189 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %190 = select i1 %189, i64 %188, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %186, i64 %190
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %191 = select <8 x i1> %59, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %tile_snapshot.spill.load76 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %194 = add <8 x i64> %193, splat (i64 96)
  %195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %192, 0
  %196 = insertvalue { <8 x ptr>, <8 x i64> } %195, <8 x i64> %194, 1
  %197 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %196, 1
  %199 = extractelement <8 x ptr> %197, i32 0
  %200 = extractelement <8 x i64> %198, i32 0
  %201 = sub i64 %200, 0
  %202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %203 = select i1 %202, i64 %201, i64 0
  %private.contiguous.address77 = getelementptr i8, ptr %199, i64 %203
  %private.contiguous.load78 = load <8 x float>, ptr %private.contiguous.address77, align 4
  %204 = select <8 x i1> %59, <8 x float> %private.contiguous.load78, <8 x float> zeroinitializer
  %205 = load <8 x i64>, ptr %.slot16, align 64
  %206 = select <8 x i1> %59, <8 x i64> splat (i64 4), <8 x i64> %205
  store <8 x i64> %206, ptr %.slot16, align 64
  %207 = load <8 x float>, ptr %.slot17, align 32
  %208 = select <8 x i1> %59, <8 x float> %165, <8 x float> %207
  store <8 x float> %208, ptr %.slot17, align 32
  %209 = load <8 x float>, ptr %.slot18, align 32
  %210 = select <8 x i1> %59, <8 x float> %178, <8 x float> %209
  store <8 x float> %210, ptr %.slot18, align 32
  %211 = load <8 x float>, ptr %.slot19, align 32
  %212 = select <8 x i1> %59, <8 x float> %191, <8 x float> %211
  store <8 x float> %212, ptr %.slot19, align 32
  %213 = load <8 x float>, ptr %.slot20, align 32
  %214 = select <8 x i1> %59, <8 x float> %204, <8 x float> %213
  store <8 x float> %214, ptr %.slot20, align 32
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state79 = load <8 x i64>, ptr %.slot16, align 64
  %215 = icmp slt <8 x i64> %.state79, splat (i64 512)
  %216 = extractelement <8 x i1> %215, i32 0
  br i1 %216, label %direct.true80, label %direct.false81

direct.schedule.7:                                ; preds = %direct.true80
  %.state82 = load <8 x i64>, ptr %.slot16, align 64
  %217 = add <8 x i64> %.state82, zeroinitializer
  %tile_snapshot.spill.load83 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 0
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load83, 1
  %220 = mul <8 x i64> %217, splat (i64 32)
  %221 = add <8 x i64> %219, %220
  %222 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %218, 0
  %223 = insertvalue { <8 x ptr>, <8 x i64> } %222, <8 x i64> %221, 1
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %223, 1
  %226 = extractelement <8 x ptr> %224, i32 0
  %227 = extractelement <8 x i64> %225, i32 0
  %228 = sub i64 %227, 0
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %230 = select i1 %229, i64 %228, i64 0
  %private.contiguous.address84 = getelementptr i8, ptr %226, i64 %230
  %private.contiguous.load85 = load <8 x float>, ptr %private.contiguous.address84, align 4
  %231 = select <8 x i1> %59, <8 x float> %private.contiguous.load85, <8 x float> zeroinitializer
  %.state86 = load <8 x float>, ptr %.slot17, align 32
  %232 = fadd <8 x float> %.state86, %231
  %.state87 = load <8 x i64>, ptr %.slot16, align 64
  %233 = add <8 x i64> %.state87, splat (i64 1)
  %tile_snapshot.spill.load88 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 0
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 1
  %236 = mul <8 x i64> %233, splat (i64 32)
  %237 = add <8 x i64> %235, %236
  %238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %234, 0
  %239 = insertvalue { <8 x ptr>, <8 x i64> } %238, <8 x i64> %237, 1
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %242 = extractelement <8 x ptr> %240, i32 0
  %243 = extractelement <8 x i64> %241, i32 0
  %244 = sub i64 %243, 0
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %246 = select i1 %245, i64 %244, i64 0
  %private.contiguous.address89 = getelementptr i8, ptr %242, i64 %246
  %private.contiguous.load90 = load <8 x float>, ptr %private.contiguous.address89, align 4
  %247 = select <8 x i1> %59, <8 x float> %private.contiguous.load90, <8 x float> zeroinitializer
  %.state91 = load <8 x float>, ptr %.slot18, align 32
  %248 = fadd <8 x float> %.state91, %247
  %.state92 = load <8 x i64>, ptr %.slot16, align 64
  %249 = add <8 x i64> %.state92, splat (i64 2)
  %tile_snapshot.spill.load93 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 0
  %251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 1
  %252 = mul <8 x i64> %249, splat (i64 32)
  %253 = add <8 x i64> %251, %252
  %254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %250, 0
  %255 = insertvalue { <8 x ptr>, <8 x i64> } %254, <8 x i64> %253, 1
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %255, 1
  %258 = extractelement <8 x ptr> %256, i32 0
  %259 = extractelement <8 x i64> %257, i32 0
  %260 = sub i64 %259, 0
  %261 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %262 = select i1 %261, i64 %260, i64 0
  %private.contiguous.address94 = getelementptr i8, ptr %258, i64 %262
  %private.contiguous.load95 = load <8 x float>, ptr %private.contiguous.address94, align 4
  %263 = select <8 x i1> %59, <8 x float> %private.contiguous.load95, <8 x float> zeroinitializer
  %.state96 = load <8 x float>, ptr %.slot19, align 32
  %264 = fadd <8 x float> %.state96, %263
  %.state97 = load <8 x i64>, ptr %.slot16, align 64
  %265 = add <8 x i64> %.state97, splat (i64 3)
  %tile_snapshot.spill.load98 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 1
  %268 = mul <8 x i64> %265, splat (i64 32)
  %269 = add <8 x i64> %267, %268
  %270 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %266, 0
  %271 = insertvalue { <8 x ptr>, <8 x i64> } %270, <8 x i64> %269, 1
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %271, 1
  %274 = extractelement <8 x ptr> %272, i32 0
  %275 = extractelement <8 x i64> %273, i32 0
  %276 = sub i64 %275, 0
  %277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %278 = select i1 %277, i64 %276, i64 0
  %private.contiguous.address99 = getelementptr i8, ptr %274, i64 %278
  %private.contiguous.load100 = load <8 x float>, ptr %private.contiguous.address99, align 4
  %279 = select <8 x i1> %59, <8 x float> %private.contiguous.load100, <8 x float> zeroinitializer
  %.state101 = load <8 x float>, ptr %.slot20, align 32
  %280 = fadd <8 x float> %.state101, %279
  %.state102 = load <8 x i64>, ptr %.slot16, align 64
  %281 = add <8 x i64> %.state102, splat (i64 4)
  %282 = load <8 x i64>, ptr %.slot16, align 64
  %283 = select <8 x i1> %59, <8 x i64> %281, <8 x i64> %282
  store <8 x i64> %283, ptr %.slot16, align 64
  %284 = load <8 x float>, ptr %.slot17, align 32
  %285 = select <8 x i1> %59, <8 x float> %232, <8 x float> %284
  store <8 x float> %285, ptr %.slot17, align 32
  %286 = load <8 x float>, ptr %.slot18, align 32
  %287 = select <8 x i1> %59, <8 x float> %248, <8 x float> %286
  store <8 x float> %287, ptr %.slot18, align 32
  %288 = load <8 x float>, ptr %.slot19, align 32
  %289 = select <8 x i1> %59, <8 x float> %264, <8 x float> %288
  store <8 x float> %289, ptr %.slot19, align 32
  %290 = load <8 x float>, ptr %.slot20, align 32
  %291 = select <8 x i1> %59, <8 x float> %280, <8 x float> %290
  store <8 x float> %291, ptr %.slot20, align 32
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false81
  %.spill.load103 = load <8 x i1>, ptr %.spill14, align 1
  %292 = and <8 x i1> %59, %.spill.load103
  %293 = xor <8 x i1> %.spill.load103, splat (i1 true)
  %294 = and <8 x i1> %59, %293
  %295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %292)
  %296 = bitcast <8 x i1> %292 to i8
  %297 = call i8 @llvm.cttz.i8(i8 %296, i1 false)
  %298 = zext i8 %297 to i32
  %299 = select i1 %295, i32 %298, i32 0
  %tile_snapshot.spill.load104 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load104, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load104, 1
  %302 = add <8 x i64> %301, splat (i64 16384)
  %303 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %300, 0
  %304 = insertvalue { <8 x ptr>, <8 x i64> } %303, <8 x i64> %302, 1
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %304, 1
  %307 = extractelement <8 x ptr> %305, i32 0
  %308 = extractelement <8 x i64> %306, i32 %299
  %309 = zext i32 %299 to i64
  %310 = mul i64 %309, 4
  %311 = sub i64 %308, %310
  %312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %292)
  %313 = select i1 %312, i64 %311, i64 0
  %private.contiguous.address105 = getelementptr i8, ptr %307, i64 %313
  %private.contiguous.load106 = load <8 x float>, ptr %private.contiguous.address105, align 4
  %314 = select <8 x i1> %292, <8 x float> %private.contiguous.load106, <8 x float> zeroinitializer
  %.state107 = load <8 x float>, ptr %.slot17, align 32
  %315 = fadd <8 x float> %.state107, %314
  %316 = load <8 x float>, ptr %.slot21, align 32
  %317 = select <8 x i1> %292, <8 x float> %315, <8 x float> %316
  store <8 x float> %317, ptr %.slot21, align 32
  %318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %294)
  %319 = bitcast <8 x i1> %294 to i8
  %320 = call i8 @llvm.cttz.i8(i8 %319, i1 false)
  %321 = zext i8 %320 to i32
  %322 = select i1 %318, i32 %321, i32 0
  %.state108 = load <8 x float>, ptr %.slot17, align 32
  %323 = load <8 x float>, ptr %.slot21, align 32
  %324 = select <8 x i1> %294, <8 x float> %.state108, <8 x float> %323
  store <8 x float> %324, ptr %.slot21, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.state109 = load <8 x float>, ptr %.slot21, align 32
  %.state110 = load <8 x float>, ptr %.slot18, align 32
  %325 = fadd <8 x float> %.state109, %.state110
  %.state111 = load <8 x float>, ptr %.slot19, align 32
  %326 = fadd <8 x float> %325, %.state111
  %.state112 = load <8 x float>, ptr %.slot20, align 32
  %327 = fadd <8 x float> %326, %.state112
  %.spill.load113 = load <8 x i64>, ptr %.spill, align 64
  %328 = trunc <8 x i64> %.spill.load113 to <8 x i32>
  %329 = xor <8 x i32> %328, splat (i32 1)
  %330 = load <8 x i32>, ptr %.spill22, align 32
  %331 = select <8 x i1> %59, <8 x i32> %329, <8 x i32> %330
  store <8 x i32> %331, ptr %.spill22, align 32
  %332 = extractelement <8 x i32> %329, i64 0
  %333 = icmp ult i32 %332, 8
  %334 = select i1 %333, i32 %332, i32 0
  %335 = extractelement <8 x i1> %59, i32 %334
  %336 = extractelement <8 x i1> %59, i64 0
  %337 = and i1 %333, %335
  %338 = and i1 %336, %337
  %339 = extractelement <8 x float> %327, i32 %334
  %340 = select i1 %338, float %339, float 0.000000e+00
  %341 = insertelement <8 x float> poison, float %340, i64 0
  %342 = xor i1 %338, true
  %343 = and i1 %336, %342
  %344 = insertelement <8 x i1> poison, i1 %343, i64 0
  %345 = extractelement <8 x i32> %329, i64 1
  %346 = icmp ult i32 %345, 8
  %347 = select i1 %346, i32 %345, i32 0
  %348 = extractelement <8 x i1> %59, i32 %347
  %349 = extractelement <8 x i1> %59, i64 1
  %350 = and i1 %346, %348
  %351 = and i1 %349, %350
  %352 = extractelement <8 x float> %327, i32 %347
  %353 = select i1 %351, float %352, float 0.000000e+00
  %354 = insertelement <8 x float> %341, float %353, i64 1
  %355 = xor i1 %351, true
  %356 = and i1 %349, %355
  %357 = insertelement <8 x i1> %344, i1 %356, i64 1
  %358 = extractelement <8 x i32> %329, i64 2
  %359 = icmp ult i32 %358, 8
  %360 = select i1 %359, i32 %358, i32 0
  %361 = extractelement <8 x i1> %59, i32 %360
  %362 = extractelement <8 x i1> %59, i64 2
  %363 = and i1 %359, %361
  %364 = and i1 %362, %363
  %365 = extractelement <8 x float> %327, i32 %360
  %366 = select i1 %364, float %365, float 0.000000e+00
  %367 = insertelement <8 x float> %354, float %366, i64 2
  %368 = xor i1 %364, true
  %369 = and i1 %362, %368
  %370 = insertelement <8 x i1> %357, i1 %369, i64 2
  %371 = extractelement <8 x i32> %329, i64 3
  %372 = icmp ult i32 %371, 8
  %373 = select i1 %372, i32 %371, i32 0
  %374 = extractelement <8 x i1> %59, i32 %373
  %375 = extractelement <8 x i1> %59, i64 3
  %376 = and i1 %372, %374
  %377 = and i1 %375, %376
  %378 = extractelement <8 x float> %327, i32 %373
  %379 = select i1 %377, float %378, float 0.000000e+00
  %380 = insertelement <8 x float> %367, float %379, i64 3
  %381 = xor i1 %377, true
  %382 = and i1 %375, %381
  %383 = insertelement <8 x i1> %370, i1 %382, i64 3
  %384 = extractelement <8 x i32> %329, i64 4
  %385 = icmp ult i32 %384, 8
  %386 = select i1 %385, i32 %384, i32 0
  %387 = extractelement <8 x i1> %59, i32 %386
  %388 = extractelement <8 x i1> %59, i64 4
  %389 = and i1 %385, %387
  %390 = and i1 %388, %389
  %391 = extractelement <8 x float> %327, i32 %386
  %392 = select i1 %390, float %391, float 0.000000e+00
  %393 = insertelement <8 x float> %380, float %392, i64 4
  %394 = xor i1 %390, true
  %395 = and i1 %388, %394
  %396 = insertelement <8 x i1> %383, i1 %395, i64 4
  %397 = extractelement <8 x i32> %329, i64 5
  %398 = icmp ult i32 %397, 8
  %399 = select i1 %398, i32 %397, i32 0
  %400 = extractelement <8 x i1> %59, i32 %399
  %401 = extractelement <8 x i1> %59, i64 5
  %402 = and i1 %398, %400
  %403 = and i1 %401, %402
  %404 = extractelement <8 x float> %327, i32 %399
  %405 = select i1 %403, float %404, float 0.000000e+00
  %406 = insertelement <8 x float> %393, float %405, i64 5
  %407 = xor i1 %403, true
  %408 = and i1 %401, %407
  %409 = insertelement <8 x i1> %396, i1 %408, i64 5
  %410 = extractelement <8 x i32> %329, i64 6
  %411 = icmp ult i32 %410, 8
  %412 = select i1 %411, i32 %410, i32 0
  %413 = extractelement <8 x i1> %59, i32 %412
  %414 = extractelement <8 x i1> %59, i64 6
  %415 = and i1 %411, %413
  %416 = and i1 %414, %415
  %417 = extractelement <8 x float> %327, i32 %412
  %418 = select i1 %416, float %417, float 0.000000e+00
  %419 = insertelement <8 x float> %406, float %418, i64 6
  %420 = xor i1 %416, true
  %421 = and i1 %414, %420
  %422 = insertelement <8 x i1> %409, i1 %421, i64 6
  %423 = extractelement <8 x i32> %329, i64 7
  %424 = icmp ult i32 %423, 8
  %425 = select i1 %424, i32 %423, i32 0
  %426 = extractelement <8 x i1> %59, i32 %425
  %427 = extractelement <8 x i1> %59, i64 7
  %428 = and i1 %424, %426
  %429 = and i1 %427, %428
  %430 = extractelement <8 x float> %327, i32 %425
  %431 = select i1 %429, float %430, float 0.000000e+00
  %432 = insertelement <8 x float> %419, float %431, i64 7
  %433 = xor i1 %429, true
  %434 = and i1 %427, %433
  %435 = insertelement <8 x i1> %422, i1 %434, i64 7
  %436 = fadd <8 x float> %327, %432
  %437 = xor <8 x i32> %328, splat (i32 2)
  %438 = load <8 x i32>, ptr %.spill23, align 32
  %439 = select <8 x i1> %59, <8 x i32> %437, <8 x i32> %438
  store <8 x i32> %439, ptr %.spill23, align 32
  %440 = extractelement <8 x i32> %437, i64 0
  %441 = icmp ult i32 %440, 8
  %442 = select i1 %441, i32 %440, i32 0
  %443 = extractelement <8 x i1> %59, i32 %442
  %444 = extractelement <8 x i1> %59, i64 0
  %445 = and i1 %441, %443
  %446 = and i1 %444, %445
  %447 = extractelement <8 x float> %436, i32 %442
  %448 = select i1 %446, float %447, float 0.000000e+00
  %449 = insertelement <8 x float> poison, float %448, i64 0
  %450 = xor i1 %446, true
  %451 = and i1 %444, %450
  %452 = insertelement <8 x i1> poison, i1 %451, i64 0
  %453 = extractelement <8 x i32> %437, i64 1
  %454 = icmp ult i32 %453, 8
  %455 = select i1 %454, i32 %453, i32 0
  %456 = extractelement <8 x i1> %59, i32 %455
  %457 = extractelement <8 x i1> %59, i64 1
  %458 = and i1 %454, %456
  %459 = and i1 %457, %458
  %460 = extractelement <8 x float> %436, i32 %455
  %461 = select i1 %459, float %460, float 0.000000e+00
  %462 = insertelement <8 x float> %449, float %461, i64 1
  %463 = xor i1 %459, true
  %464 = and i1 %457, %463
  %465 = insertelement <8 x i1> %452, i1 %464, i64 1
  %466 = extractelement <8 x i32> %437, i64 2
  %467 = icmp ult i32 %466, 8
  %468 = select i1 %467, i32 %466, i32 0
  %469 = extractelement <8 x i1> %59, i32 %468
  %470 = extractelement <8 x i1> %59, i64 2
  %471 = and i1 %467, %469
  %472 = and i1 %470, %471
  %473 = extractelement <8 x float> %436, i32 %468
  %474 = select i1 %472, float %473, float 0.000000e+00
  %475 = insertelement <8 x float> %462, float %474, i64 2
  %476 = xor i1 %472, true
  %477 = and i1 %470, %476
  %478 = insertelement <8 x i1> %465, i1 %477, i64 2
  %479 = extractelement <8 x i32> %437, i64 3
  %480 = icmp ult i32 %479, 8
  %481 = select i1 %480, i32 %479, i32 0
  %482 = extractelement <8 x i1> %59, i32 %481
  %483 = extractelement <8 x i1> %59, i64 3
  %484 = and i1 %480, %482
  %485 = and i1 %483, %484
  %486 = extractelement <8 x float> %436, i32 %481
  %487 = select i1 %485, float %486, float 0.000000e+00
  %488 = insertelement <8 x float> %475, float %487, i64 3
  %489 = xor i1 %485, true
  %490 = and i1 %483, %489
  %491 = insertelement <8 x i1> %478, i1 %490, i64 3
  %492 = extractelement <8 x i32> %437, i64 4
  %493 = icmp ult i32 %492, 8
  %494 = select i1 %493, i32 %492, i32 0
  %495 = extractelement <8 x i1> %59, i32 %494
  %496 = extractelement <8 x i1> %59, i64 4
  %497 = and i1 %493, %495
  %498 = and i1 %496, %497
  %499 = extractelement <8 x float> %436, i32 %494
  %500 = select i1 %498, float %499, float 0.000000e+00
  %501 = insertelement <8 x float> %488, float %500, i64 4
  %502 = xor i1 %498, true
  %503 = and i1 %496, %502
  %504 = insertelement <8 x i1> %491, i1 %503, i64 4
  %505 = extractelement <8 x i32> %437, i64 5
  %506 = icmp ult i32 %505, 8
  %507 = select i1 %506, i32 %505, i32 0
  %508 = extractelement <8 x i1> %59, i32 %507
  %509 = extractelement <8 x i1> %59, i64 5
  %510 = and i1 %506, %508
  %511 = and i1 %509, %510
  %512 = extractelement <8 x float> %436, i32 %507
  %513 = select i1 %511, float %512, float 0.000000e+00
  %514 = insertelement <8 x float> %501, float %513, i64 5
  %515 = xor i1 %511, true
  %516 = and i1 %509, %515
  %517 = insertelement <8 x i1> %504, i1 %516, i64 5
  %518 = extractelement <8 x i32> %437, i64 6
  %519 = icmp ult i32 %518, 8
  %520 = select i1 %519, i32 %518, i32 0
  %521 = extractelement <8 x i1> %59, i32 %520
  %522 = extractelement <8 x i1> %59, i64 6
  %523 = and i1 %519, %521
  %524 = and i1 %522, %523
  %525 = extractelement <8 x float> %436, i32 %520
  %526 = select i1 %524, float %525, float 0.000000e+00
  %527 = insertelement <8 x float> %514, float %526, i64 6
  %528 = xor i1 %524, true
  %529 = and i1 %522, %528
  %530 = insertelement <8 x i1> %517, i1 %529, i64 6
  %531 = extractelement <8 x i32> %437, i64 7
  %532 = icmp ult i32 %531, 8
  %533 = select i1 %532, i32 %531, i32 0
  %534 = extractelement <8 x i1> %59, i32 %533
  %535 = extractelement <8 x i1> %59, i64 7
  %536 = and i1 %532, %534
  %537 = and i1 %535, %536
  %538 = extractelement <8 x float> %436, i32 %533
  %539 = select i1 %537, float %538, float 0.000000e+00
  %540 = insertelement <8 x float> %527, float %539, i64 7
  %541 = xor i1 %537, true
  %542 = and i1 %535, %541
  %543 = insertelement <8 x i1> %530, i1 %542, i64 7
  %544 = fadd <8 x float> %436, %540
  %545 = xor <8 x i32> %328, splat (i32 4)
  %546 = load <8 x i32>, ptr %.spill24, align 32
  %547 = select <8 x i1> %59, <8 x i32> %545, <8 x i32> %546
  store <8 x i32> %547, ptr %.spill24, align 32
  %548 = extractelement <8 x i32> %545, i64 0
  %549 = icmp ult i32 %548, 8
  %550 = select i1 %549, i32 %548, i32 0
  %551 = extractelement <8 x i1> %59, i32 %550
  %552 = extractelement <8 x i1> %59, i64 0
  %553 = and i1 %549, %551
  %554 = and i1 %552, %553
  %555 = extractelement <8 x float> %544, i32 %550
  %556 = select i1 %554, float %555, float 0.000000e+00
  %557 = insertelement <8 x float> poison, float %556, i64 0
  %558 = xor i1 %554, true
  %559 = and i1 %552, %558
  %560 = insertelement <8 x i1> poison, i1 %559, i64 0
  %561 = extractelement <8 x i32> %545, i64 1
  %562 = icmp ult i32 %561, 8
  %563 = select i1 %562, i32 %561, i32 0
  %564 = extractelement <8 x i1> %59, i32 %563
  %565 = extractelement <8 x i1> %59, i64 1
  %566 = and i1 %562, %564
  %567 = and i1 %565, %566
  %568 = extractelement <8 x float> %544, i32 %563
  %569 = select i1 %567, float %568, float 0.000000e+00
  %570 = insertelement <8 x float> %557, float %569, i64 1
  %571 = xor i1 %567, true
  %572 = and i1 %565, %571
  %573 = insertelement <8 x i1> %560, i1 %572, i64 1
  %574 = extractelement <8 x i32> %545, i64 2
  %575 = icmp ult i32 %574, 8
  %576 = select i1 %575, i32 %574, i32 0
  %577 = extractelement <8 x i1> %59, i32 %576
  %578 = extractelement <8 x i1> %59, i64 2
  %579 = and i1 %575, %577
  %580 = and i1 %578, %579
  %581 = extractelement <8 x float> %544, i32 %576
  %582 = select i1 %580, float %581, float 0.000000e+00
  %583 = insertelement <8 x float> %570, float %582, i64 2
  %584 = xor i1 %580, true
  %585 = and i1 %578, %584
  %586 = insertelement <8 x i1> %573, i1 %585, i64 2
  %587 = extractelement <8 x i32> %545, i64 3
  %588 = icmp ult i32 %587, 8
  %589 = select i1 %588, i32 %587, i32 0
  %590 = extractelement <8 x i1> %59, i32 %589
  %591 = extractelement <8 x i1> %59, i64 3
  %592 = and i1 %588, %590
  %593 = and i1 %591, %592
  %594 = extractelement <8 x float> %544, i32 %589
  %595 = select i1 %593, float %594, float 0.000000e+00
  %596 = insertelement <8 x float> %583, float %595, i64 3
  %597 = xor i1 %593, true
  %598 = and i1 %591, %597
  %599 = insertelement <8 x i1> %586, i1 %598, i64 3
  %600 = extractelement <8 x i32> %545, i64 4
  %601 = icmp ult i32 %600, 8
  %602 = select i1 %601, i32 %600, i32 0
  %603 = extractelement <8 x i1> %59, i32 %602
  %604 = extractelement <8 x i1> %59, i64 4
  %605 = and i1 %601, %603
  %606 = and i1 %604, %605
  %607 = extractelement <8 x float> %544, i32 %602
  %608 = select i1 %606, float %607, float 0.000000e+00
  %609 = insertelement <8 x float> %596, float %608, i64 4
  %610 = xor i1 %606, true
  %611 = and i1 %604, %610
  %612 = insertelement <8 x i1> %599, i1 %611, i64 4
  %613 = extractelement <8 x i32> %545, i64 5
  %614 = icmp ult i32 %613, 8
  %615 = select i1 %614, i32 %613, i32 0
  %616 = extractelement <8 x i1> %59, i32 %615
  %617 = extractelement <8 x i1> %59, i64 5
  %618 = and i1 %614, %616
  %619 = and i1 %617, %618
  %620 = extractelement <8 x float> %544, i32 %615
  %621 = select i1 %619, float %620, float 0.000000e+00
  %622 = insertelement <8 x float> %609, float %621, i64 5
  %623 = xor i1 %619, true
  %624 = and i1 %617, %623
  %625 = insertelement <8 x i1> %612, i1 %624, i64 5
  %626 = extractelement <8 x i32> %545, i64 6
  %627 = icmp ult i32 %626, 8
  %628 = select i1 %627, i32 %626, i32 0
  %629 = extractelement <8 x i1> %59, i32 %628
  %630 = extractelement <8 x i1> %59, i64 6
  %631 = and i1 %627, %629
  %632 = and i1 %630, %631
  %633 = extractelement <8 x float> %544, i32 %628
  %634 = select i1 %632, float %633, float 0.000000e+00
  %635 = insertelement <8 x float> %622, float %634, i64 6
  %636 = xor i1 %632, true
  %637 = and i1 %630, %636
  %638 = insertelement <8 x i1> %625, i1 %637, i64 6
  %639 = extractelement <8 x i32> %545, i64 7
  %640 = icmp ult i32 %639, 8
  %641 = select i1 %640, i32 %639, i32 0
  %642 = extractelement <8 x i1> %59, i32 %641
  %643 = extractelement <8 x i1> %59, i64 7
  %644 = and i1 %640, %642
  %645 = and i1 %643, %644
  %646 = extractelement <8 x float> %544, i32 %641
  %647 = select i1 %645, float %646, float 0.000000e+00
  %648 = insertelement <8 x float> %635, float %647, i64 7
  %649 = xor i1 %645, true
  %650 = and i1 %643, %649
  %651 = insertelement <8 x i1> %638, i1 %650, i64 7
  %652 = fadd <8 x float> %544, %648
  %653 = extractelement <8 x i1> %59, i32 0
  %654 = extractelement <8 x i1> %59, i64 0
  %655 = and i1 true, %653
  %656 = and i1 %654, %655
  %657 = extractelement <8 x float> %652, i32 0
  %658 = select i1 %656, float %657, float 0.000000e+00
  %659 = insertelement <8 x float> poison, float %658, i64 0
  %660 = xor i1 %656, true
  %661 = and i1 %654, %660
  %662 = insertelement <8 x i1> poison, i1 %661, i64 0
  %663 = extractelement <8 x i1> %59, i32 0
  %664 = extractelement <8 x i1> %59, i64 1
  %665 = and i1 true, %663
  %666 = and i1 %664, %665
  %667 = extractelement <8 x float> %652, i32 0
  %668 = select i1 %666, float %667, float 0.000000e+00
  %669 = insertelement <8 x float> %659, float %668, i64 1
  %670 = xor i1 %666, true
  %671 = and i1 %664, %670
  %672 = insertelement <8 x i1> %662, i1 %671, i64 1
  %673 = extractelement <8 x i1> %59, i32 0
  %674 = extractelement <8 x i1> %59, i64 2
  %675 = and i1 true, %673
  %676 = and i1 %674, %675
  %677 = extractelement <8 x float> %652, i32 0
  %678 = select i1 %676, float %677, float 0.000000e+00
  %679 = insertelement <8 x float> %669, float %678, i64 2
  %680 = xor i1 %676, true
  %681 = and i1 %674, %680
  %682 = insertelement <8 x i1> %672, i1 %681, i64 2
  %683 = extractelement <8 x i1> %59, i32 0
  %684 = extractelement <8 x i1> %59, i64 3
  %685 = and i1 true, %683
  %686 = and i1 %684, %685
  %687 = extractelement <8 x float> %652, i32 0
  %688 = select i1 %686, float %687, float 0.000000e+00
  %689 = insertelement <8 x float> %679, float %688, i64 3
  %690 = xor i1 %686, true
  %691 = and i1 %684, %690
  %692 = insertelement <8 x i1> %682, i1 %691, i64 3
  %693 = extractelement <8 x i1> %59, i32 0
  %694 = extractelement <8 x i1> %59, i64 4
  %695 = and i1 true, %693
  %696 = and i1 %694, %695
  %697 = extractelement <8 x float> %652, i32 0
  %698 = select i1 %696, float %697, float 0.000000e+00
  %699 = insertelement <8 x float> %689, float %698, i64 4
  %700 = xor i1 %696, true
  %701 = and i1 %694, %700
  %702 = insertelement <8 x i1> %692, i1 %701, i64 4
  %703 = extractelement <8 x i1> %59, i32 0
  %704 = extractelement <8 x i1> %59, i64 5
  %705 = and i1 true, %703
  %706 = and i1 %704, %705
  %707 = extractelement <8 x float> %652, i32 0
  %708 = select i1 %706, float %707, float 0.000000e+00
  %709 = insertelement <8 x float> %699, float %708, i64 5
  %710 = xor i1 %706, true
  %711 = and i1 %704, %710
  %712 = insertelement <8 x i1> %702, i1 %711, i64 5
  %713 = extractelement <8 x i1> %59, i32 0
  %714 = extractelement <8 x i1> %59, i64 6
  %715 = and i1 true, %713
  %716 = and i1 %714, %715
  %717 = extractelement <8 x float> %652, i32 0
  %718 = select i1 %716, float %717, float 0.000000e+00
  %719 = insertelement <8 x float> %709, float %718, i64 6
  %720 = xor i1 %716, true
  %721 = and i1 %714, %720
  %722 = insertelement <8 x i1> %712, i1 %721, i64 6
  %723 = extractelement <8 x i1> %59, i32 0
  %724 = extractelement <8 x i1> %59, i64 7
  %725 = and i1 true, %723
  %726 = and i1 %724, %725
  %727 = extractelement <8 x float> %652, i32 0
  %728 = select i1 %726, float %727, float 0.000000e+00
  %729 = insertelement <8 x float> %719, float %728, i64 7
  %730 = xor i1 %726, true
  %731 = and i1 %724, %730
  %732 = insertelement <8 x i1> %722, i1 %731, i64 7
  %733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %734 = bitcast <8 x i1> %59 to i8
  %735 = call i8 @llvm.cttz.i8(i8 %734, i1 false)
  %736 = zext i8 %735 to i32
  %737 = select i1 %733, i32 %736, i32 0
  %738 = extractelement <8 x float> %729, i32 %737
  %739 = fadd float 0.000000e+00, %738
  %740 = fdiv float %739, 4.097000e+03
  store float %740, ptr %.spill25, align 4
  %741 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %743 = extractvalue { <8 x ptr>, <8 x i64> } %741, 0
  %744 = select <8 x i1> %59, <8 x ptr> %742, <8 x ptr> %743
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %741, 1
  %747 = select <8 x i1> %59, <8 x i64> %745, <8 x i64> %746
  %748 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %744, 0
  %749 = insertvalue { <8 x ptr>, <8 x i64> } %748, <8 x i64> %747, 1
  store { <8 x ptr>, <8 x i64> } %749, ptr %tile_snapshot.spill26, align 64
  %750 = load <8 x i64>, ptr %.slot27, align 64
  %751 = select <8 x i1> %59, <8 x i64> zeroinitializer, <8 x i64> %750
  store <8 x i64> %751, ptr %.slot27, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state114 = load <8 x i64>, ptr %.slot27, align 64
  %752 = icmp slt <8 x i64> %.state114, splat (i64 512)
  %753 = extractelement <8 x i1> %752, i32 0
  br i1 %753, label %direct.true115, label %direct.false116

direct.schedule.12:                               ; preds = %direct.true115
  %tile_snapshot.spill.load117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %754 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 0
  %755 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 1
  %.state118 = load <8 x i64>, ptr %.slot27, align 64
  %756 = mul <8 x i64> %.state118, splat (i64 32)
  %757 = add <8 x i64> %755, %756
  %758 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %754, 0
  %759 = insertvalue { <8 x ptr>, <8 x i64> } %758, <8 x i64> %757, 1
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %761 = extractvalue { <8 x ptr>, <8 x i64> } %759, 1
  %762 = extractelement <8 x ptr> %760, i32 0
  %763 = extractelement <8 x i64> %761, i32 0
  %764 = sub i64 %763, 0
  %765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %766 = select i1 %765, i64 %764, i64 0
  %private.contiguous.address119 = getelementptr i8, ptr %762, i64 %766
  %private.contiguous.load120 = load <8 x float>, ptr %private.contiguous.address119, align 4
  %767 = select <8 x i1> %59, <8 x float> %private.contiguous.load120, <8 x float> zeroinitializer
  %.spill.load121 = load float, ptr %.spill25, align 4
  %.splatinsert122 = insertelement <8 x float> poison, float %.spill.load121, i64 0
  %.splat123 = shufflevector <8 x float> %.splatinsert122, <8 x float> poison, <8 x i32> zeroinitializer
  %768 = fsub <8 x float> %767, %.splat123
  %tile_snapshot.spill.load124 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 0
  %770 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load124, 1
  %.state125 = load <8 x i64>, ptr %.slot27, align 64
  %771 = mul <8 x i64> %.state125, splat (i64 32)
  %772 = add <8 x i64> %770, %771
  %773 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %769, 0
  %774 = insertvalue { <8 x ptr>, <8 x i64> } %773, <8 x i64> %772, 1
  %775 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %774, 1
  %777 = extractelement <8 x ptr> %775, i32 0
  %778 = extractelement <8 x i64> %776, i32 0
  %779 = sub i64 %778, 0
  %780 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %781 = select i1 %780, i64 %779, i64 0
  %private.contiguous.address126 = getelementptr i8, ptr %777, i64 %781
  %private.contiguous.preserve127 = load <8 x float>, ptr %private.contiguous.address126, align 4
  %782 = select <8 x i1> %59, <8 x float> %768, <8 x float> %private.contiguous.preserve127
  store <8 x float> %782, ptr %private.contiguous.address126, align 4
  %.state128 = load <8 x i64>, ptr %.slot27, align 64
  %783 = add <8 x i64> %.state128, splat (i64 1)
  %784 = load <8 x i64>, ptr %.slot27, align 64
  %785 = select <8 x i1> %59, <8 x i64> %783, <8 x i64> %784
  store <8 x i64> %785, ptr %.slot27, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false116
  %.spill.load129 = load <8 x i1>, ptr %.spill14, align 1
  %786 = and <8 x i1> %59, %.spill.load129
  %787 = xor <8 x i1> %.spill.load129, splat (i1 true)
  %788 = and <8 x i1> %59, %787
  %789 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %786)
  %790 = bitcast <8 x i1> %786 to i8
  %791 = call i8 @llvm.cttz.i8(i8 %790, i1 false)
  %792 = zext i8 %791 to i32
  %793 = select i1 %789, i32 %792, i32 0
  %tile_snapshot.spill.load130 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 0
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 1
  %796 = add <8 x i64> %795, splat (i64 16384)
  %797 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %794, 0
  %798 = insertvalue { <8 x ptr>, <8 x i64> } %797, <8 x i64> %796, 1
  %799 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %798, 1
  %801 = extractelement <8 x ptr> %799, i32 0
  %802 = extractelement <8 x i64> %800, i32 %793
  %803 = zext i32 %793 to i64
  %804 = mul i64 %803, 4
  %805 = sub i64 %802, %804
  %806 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %786)
  %807 = select i1 %806, i64 %805, i64 0
  %private.contiguous.address131 = getelementptr i8, ptr %801, i64 %807
  %private.contiguous.load132 = load <8 x float>, ptr %private.contiguous.address131, align 4
  %808 = select <8 x i1> %786, <8 x float> %private.contiguous.load132, <8 x float> zeroinitializer
  %.spill.load133 = load float, ptr %.spill25, align 4
  %.splatinsert134 = insertelement <8 x float> poison, float %.spill.load133, i64 0
  %.splat135 = shufflevector <8 x float> %.splatinsert134, <8 x float> poison, <8 x i32> zeroinitializer
  %809 = fsub <8 x float> %808, %.splat135
  %tile_snapshot.spill.load136 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %810 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 0
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 1
  %812 = add <8 x i64> %811, splat (i64 16384)
  %813 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %810, 0
  %814 = insertvalue { <8 x ptr>, <8 x i64> } %813, <8 x i64> %812, 1
  %815 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %816 = extractvalue { <8 x ptr>, <8 x i64> } %814, 1
  %817 = extractelement <8 x ptr> %815, i32 0
  %818 = extractelement <8 x i64> %816, i32 %793
  %819 = zext i32 %793 to i64
  %820 = mul i64 %819, 4
  %821 = sub i64 %818, %820
  %822 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %786)
  %823 = select i1 %822, i64 %821, i64 0
  %private.contiguous.address137 = getelementptr i8, ptr %817, i64 %823
  %private.contiguous.preserve138 = load <8 x float>, ptr %private.contiguous.address137, align 4
  %824 = select <8 x i1> %786, <8 x float> %809, <8 x float> %private.contiguous.preserve138
  store <8 x float> %824, ptr %private.contiguous.address137, align 4
  %825 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %788)
  %826 = bitcast <8 x i1> %788 to i8
  %827 = call i8 @llvm.cttz.i8(i8 %826, i1 false)
  %828 = zext i8 %827 to i32
  %829 = select i1 %825, i32 %828, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %tile_snapshot.spill.load139 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 0
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 1
  %832 = add <8 x i64> %831, zeroinitializer
  %833 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %830, 0
  %834 = insertvalue { <8 x ptr>, <8 x i64> } %833, <8 x i64> %832, 1
  %835 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %834, 1
  %837 = extractelement <8 x ptr> %835, i32 0
  %838 = extractelement <8 x i64> %836, i32 0
  %839 = sub i64 %838, 0
  %840 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %841 = select i1 %840, i64 %839, i64 0
  %private.contiguous.address140 = getelementptr i8, ptr %837, i64 %841
  %private.contiguous.load141 = load <8 x float>, ptr %private.contiguous.address140, align 4
  %842 = select <8 x i1> %59, <8 x float> %private.contiguous.load141, <8 x float> zeroinitializer
  %843 = fmul <8 x float> %842, %842
  %tile_snapshot.spill.load142 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load142, 0
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load142, 1
  %846 = add <8 x i64> %845, splat (i64 32)
  %847 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %844, 0
  %848 = insertvalue { <8 x ptr>, <8 x i64> } %847, <8 x i64> %846, 1
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %848, 1
  %851 = extractelement <8 x ptr> %849, i32 0
  %852 = extractelement <8 x i64> %850, i32 0
  %853 = sub i64 %852, 0
  %854 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %855 = select i1 %854, i64 %853, i64 0
  %private.contiguous.address143 = getelementptr i8, ptr %851, i64 %855
  %private.contiguous.load144 = load <8 x float>, ptr %private.contiguous.address143, align 4
  %856 = select <8 x i1> %59, <8 x float> %private.contiguous.load144, <8 x float> zeroinitializer
  %857 = fmul <8 x float> %856, %856
  %tile_snapshot.spill.load145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load145, 0
  %859 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load145, 1
  %860 = add <8 x i64> %859, splat (i64 64)
  %861 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %858, 0
  %862 = insertvalue { <8 x ptr>, <8 x i64> } %861, <8 x i64> %860, 1
  %863 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %864 = extractvalue { <8 x ptr>, <8 x i64> } %862, 1
  %865 = extractelement <8 x ptr> %863, i32 0
  %866 = extractelement <8 x i64> %864, i32 0
  %867 = sub i64 %866, 0
  %868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %869 = select i1 %868, i64 %867, i64 0
  %private.contiguous.address146 = getelementptr i8, ptr %865, i64 %869
  %private.contiguous.load147 = load <8 x float>, ptr %private.contiguous.address146, align 4
  %870 = select <8 x i1> %59, <8 x float> %private.contiguous.load147, <8 x float> zeroinitializer
  %871 = fmul <8 x float> %870, %870
  %tile_snapshot.spill.load148 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load148, 0
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load148, 1
  %874 = add <8 x i64> %873, splat (i64 96)
  %875 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %872, 0
  %876 = insertvalue { <8 x ptr>, <8 x i64> } %875, <8 x i64> %874, 1
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %876, 1
  %879 = extractelement <8 x ptr> %877, i32 0
  %880 = extractelement <8 x i64> %878, i32 0
  %881 = sub i64 %880, 0
  %882 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %883 = select i1 %882, i64 %881, i64 0
  %private.contiguous.address149 = getelementptr i8, ptr %879, i64 %883
  %private.contiguous.load150 = load <8 x float>, ptr %private.contiguous.address149, align 4
  %884 = select <8 x i1> %59, <8 x float> %private.contiguous.load150, <8 x float> zeroinitializer
  %885 = fmul <8 x float> %884, %884
  %886 = load <8 x i64>, ptr %.slot28, align 64
  %887 = select <8 x i1> %59, <8 x i64> splat (i64 4), <8 x i64> %886
  store <8 x i64> %887, ptr %.slot28, align 64
  %888 = load <8 x float>, ptr %.slot29, align 32
  %889 = select <8 x i1> %59, <8 x float> %843, <8 x float> %888
  store <8 x float> %889, ptr %.slot29, align 32
  %890 = load <8 x float>, ptr %.slot30, align 32
  %891 = select <8 x i1> %59, <8 x float> %857, <8 x float> %890
  store <8 x float> %891, ptr %.slot30, align 32
  %892 = load <8 x float>, ptr %.slot31, align 32
  %893 = select <8 x i1> %59, <8 x float> %871, <8 x float> %892
  store <8 x float> %893, ptr %.slot31, align 32
  %894 = load <8 x float>, ptr %.slot32, align 32
  %895 = select <8 x i1> %59, <8 x float> %885, <8 x float> %894
  store <8 x float> %895, ptr %.slot32, align 32
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state151 = load <8 x i64>, ptr %.slot28, align 64
  %896 = icmp slt <8 x i64> %.state151, splat (i64 512)
  %897 = extractelement <8 x i1> %896, i32 0
  br i1 %897, label %direct.true152, label %direct.false153

direct.schedule.17:                               ; preds = %direct.true152
  %.state154 = load <8 x i64>, ptr %.slot28, align 64
  %898 = add <8 x i64> %.state154, zeroinitializer
  %tile_snapshot.spill.load155 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %899 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load155, 0
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load155, 1
  %901 = mul <8 x i64> %898, splat (i64 32)
  %902 = add <8 x i64> %900, %901
  %903 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %899, 0
  %904 = insertvalue { <8 x ptr>, <8 x i64> } %903, <8 x i64> %902, 1
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %906 = extractvalue { <8 x ptr>, <8 x i64> } %904, 1
  %907 = extractelement <8 x ptr> %905, i32 0
  %908 = extractelement <8 x i64> %906, i32 0
  %909 = sub i64 %908, 0
  %910 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %911 = select i1 %910, i64 %909, i64 0
  %private.contiguous.address156 = getelementptr i8, ptr %907, i64 %911
  %private.contiguous.load157 = load <8 x float>, ptr %private.contiguous.address156, align 4
  %912 = select <8 x i1> %59, <8 x float> %private.contiguous.load157, <8 x float> zeroinitializer
  %913 = fmul <8 x float> %912, %912
  %.state158 = load <8 x float>, ptr %.slot29, align 32
  %914 = fadd <8 x float> %.state158, %913
  %.state159 = load <8 x i64>, ptr %.slot28, align 64
  %915 = add <8 x i64> %.state159, splat (i64 1)
  %tile_snapshot.spill.load160 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load160, 0
  %917 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load160, 1
  %918 = mul <8 x i64> %915, splat (i64 32)
  %919 = add <8 x i64> %917, %918
  %920 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %916, 0
  %921 = insertvalue { <8 x ptr>, <8 x i64> } %920, <8 x i64> %919, 1
  %922 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %923 = extractvalue { <8 x ptr>, <8 x i64> } %921, 1
  %924 = extractelement <8 x ptr> %922, i32 0
  %925 = extractelement <8 x i64> %923, i32 0
  %926 = sub i64 %925, 0
  %927 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %928 = select i1 %927, i64 %926, i64 0
  %private.contiguous.address161 = getelementptr i8, ptr %924, i64 %928
  %private.contiguous.load162 = load <8 x float>, ptr %private.contiguous.address161, align 4
  %929 = select <8 x i1> %59, <8 x float> %private.contiguous.load162, <8 x float> zeroinitializer
  %930 = fmul <8 x float> %929, %929
  %.state163 = load <8 x float>, ptr %.slot30, align 32
  %931 = fadd <8 x float> %.state163, %930
  %.state164 = load <8 x i64>, ptr %.slot28, align 64
  %932 = add <8 x i64> %.state164, splat (i64 2)
  %tile_snapshot.spill.load165 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %933 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load165, 0
  %934 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load165, 1
  %935 = mul <8 x i64> %932, splat (i64 32)
  %936 = add <8 x i64> %934, %935
  %937 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %933, 0
  %938 = insertvalue { <8 x ptr>, <8 x i64> } %937, <8 x i64> %936, 1
  %939 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %940 = extractvalue { <8 x ptr>, <8 x i64> } %938, 1
  %941 = extractelement <8 x ptr> %939, i32 0
  %942 = extractelement <8 x i64> %940, i32 0
  %943 = sub i64 %942, 0
  %944 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %945 = select i1 %944, i64 %943, i64 0
  %private.contiguous.address166 = getelementptr i8, ptr %941, i64 %945
  %private.contiguous.load167 = load <8 x float>, ptr %private.contiguous.address166, align 4
  %946 = select <8 x i1> %59, <8 x float> %private.contiguous.load167, <8 x float> zeroinitializer
  %947 = fmul <8 x float> %946, %946
  %.state168 = load <8 x float>, ptr %.slot31, align 32
  %948 = fadd <8 x float> %.state168, %947
  %.state169 = load <8 x i64>, ptr %.slot28, align 64
  %949 = add <8 x i64> %.state169, splat (i64 3)
  %tile_snapshot.spill.load170 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load170, 0
  %951 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load170, 1
  %952 = mul <8 x i64> %949, splat (i64 32)
  %953 = add <8 x i64> %951, %952
  %954 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %950, 0
  %955 = insertvalue { <8 x ptr>, <8 x i64> } %954, <8 x i64> %953, 1
  %956 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %957 = extractvalue { <8 x ptr>, <8 x i64> } %955, 1
  %958 = extractelement <8 x ptr> %956, i32 0
  %959 = extractelement <8 x i64> %957, i32 0
  %960 = sub i64 %959, 0
  %961 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %962 = select i1 %961, i64 %960, i64 0
  %private.contiguous.address171 = getelementptr i8, ptr %958, i64 %962
  %private.contiguous.load172 = load <8 x float>, ptr %private.contiguous.address171, align 4
  %963 = select <8 x i1> %59, <8 x float> %private.contiguous.load172, <8 x float> zeroinitializer
  %964 = fmul <8 x float> %963, %963
  %.state173 = load <8 x float>, ptr %.slot32, align 32
  %965 = fadd <8 x float> %.state173, %964
  %.state174 = load <8 x i64>, ptr %.slot28, align 64
  %966 = add <8 x i64> %.state174, splat (i64 4)
  %967 = load <8 x i64>, ptr %.slot28, align 64
  %968 = select <8 x i1> %59, <8 x i64> %966, <8 x i64> %967
  store <8 x i64> %968, ptr %.slot28, align 64
  %969 = load <8 x float>, ptr %.slot29, align 32
  %970 = select <8 x i1> %59, <8 x float> %914, <8 x float> %969
  store <8 x float> %970, ptr %.slot29, align 32
  %971 = load <8 x float>, ptr %.slot30, align 32
  %972 = select <8 x i1> %59, <8 x float> %931, <8 x float> %971
  store <8 x float> %972, ptr %.slot30, align 32
  %973 = load <8 x float>, ptr %.slot31, align 32
  %974 = select <8 x i1> %59, <8 x float> %948, <8 x float> %973
  store <8 x float> %974, ptr %.slot31, align 32
  %975 = load <8 x float>, ptr %.slot32, align 32
  %976 = select <8 x i1> %59, <8 x float> %965, <8 x float> %975
  store <8 x float> %976, ptr %.slot32, align 32
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false153
  %.spill.load175 = load <8 x i1>, ptr %.spill14, align 1
  %977 = and <8 x i1> %59, %.spill.load175
  %978 = xor <8 x i1> %.spill.load175, splat (i1 true)
  %979 = and <8 x i1> %59, %978
  %980 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %977)
  %981 = bitcast <8 x i1> %977 to i8
  %982 = call i8 @llvm.cttz.i8(i8 %981, i1 false)
  %983 = zext i8 %982 to i32
  %984 = select i1 %980, i32 %983, i32 0
  %tile_snapshot.spill.load176 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %985 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 0
  %986 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 1
  %987 = add <8 x i64> %986, splat (i64 16384)
  %988 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %985, 0
  %989 = insertvalue { <8 x ptr>, <8 x i64> } %988, <8 x i64> %987, 1
  %990 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %991 = extractvalue { <8 x ptr>, <8 x i64> } %989, 1
  %992 = extractelement <8 x ptr> %990, i32 0
  %993 = extractelement <8 x i64> %991, i32 %984
  %994 = zext i32 %984 to i64
  %995 = mul i64 %994, 4
  %996 = sub i64 %993, %995
  %997 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %977)
  %998 = select i1 %997, i64 %996, i64 0
  %private.contiguous.address177 = getelementptr i8, ptr %992, i64 %998
  %private.contiguous.load178 = load <8 x float>, ptr %private.contiguous.address177, align 4
  %999 = select <8 x i1> %977, <8 x float> %private.contiguous.load178, <8 x float> zeroinitializer
  %1000 = fmul <8 x float> %999, %999
  %.state179 = load <8 x float>, ptr %.slot29, align 32
  %1001 = fadd <8 x float> %.state179, %1000
  %1002 = load <8 x float>, ptr %.slot33, align 32
  %1003 = select <8 x i1> %977, <8 x float> %1001, <8 x float> %1002
  store <8 x float> %1003, ptr %.slot33, align 32
  %1004 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %979)
  %1005 = bitcast <8 x i1> %979 to i8
  %1006 = call i8 @llvm.cttz.i8(i8 %1005, i1 false)
  %1007 = zext i8 %1006 to i32
  %1008 = select i1 %1004, i32 %1007, i32 0
  %.state180 = load <8 x float>, ptr %.slot29, align 32
  %1009 = load <8 x float>, ptr %.slot33, align 32
  %1010 = select <8 x i1> %979, <8 x float> %.state180, <8 x float> %1009
  store <8 x float> %1010, ptr %.slot33, align 32
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  %.state181 = load <8 x float>, ptr %.slot33, align 32
  %.state182 = load <8 x float>, ptr %.slot30, align 32
  %1011 = fadd <8 x float> %.state181, %.state182
  %.state183 = load <8 x float>, ptr %.slot31, align 32
  %1012 = fadd <8 x float> %1011, %.state183
  %.state184 = load <8 x float>, ptr %.slot32, align 32
  %1013 = fadd <8 x float> %1012, %.state184
  %.spill.load185 = load <8 x i32>, ptr %.spill22, align 32
  %1014 = extractelement <8 x i32> %.spill.load185, i64 0
  %1015 = icmp ult i32 %1014, 8
  %1016 = select i1 %1015, i32 %1014, i32 0
  %1017 = extractelement <8 x i1> %59, i32 %1016
  %1018 = extractelement <8 x i1> %59, i64 0
  %1019 = and i1 %1015, %1017
  %1020 = and i1 %1018, %1019
  %1021 = extractelement <8 x float> %1013, i32 %1016
  %1022 = select i1 %1020, float %1021, float 0.000000e+00
  %1023 = insertelement <8 x float> poison, float %1022, i64 0
  %1024 = xor i1 %1020, true
  %1025 = and i1 %1018, %1024
  %1026 = insertelement <8 x i1> poison, i1 %1025, i64 0
  %1027 = extractelement <8 x i32> %.spill.load185, i64 1
  %1028 = icmp ult i32 %1027, 8
  %1029 = select i1 %1028, i32 %1027, i32 0
  %1030 = extractelement <8 x i1> %59, i32 %1029
  %1031 = extractelement <8 x i1> %59, i64 1
  %1032 = and i1 %1028, %1030
  %1033 = and i1 %1031, %1032
  %1034 = extractelement <8 x float> %1013, i32 %1029
  %1035 = select i1 %1033, float %1034, float 0.000000e+00
  %1036 = insertelement <8 x float> %1023, float %1035, i64 1
  %1037 = xor i1 %1033, true
  %1038 = and i1 %1031, %1037
  %1039 = insertelement <8 x i1> %1026, i1 %1038, i64 1
  %1040 = extractelement <8 x i32> %.spill.load185, i64 2
  %1041 = icmp ult i32 %1040, 8
  %1042 = select i1 %1041, i32 %1040, i32 0
  %1043 = extractelement <8 x i1> %59, i32 %1042
  %1044 = extractelement <8 x i1> %59, i64 2
  %1045 = and i1 %1041, %1043
  %1046 = and i1 %1044, %1045
  %1047 = extractelement <8 x float> %1013, i32 %1042
  %1048 = select i1 %1046, float %1047, float 0.000000e+00
  %1049 = insertelement <8 x float> %1036, float %1048, i64 2
  %1050 = xor i1 %1046, true
  %1051 = and i1 %1044, %1050
  %1052 = insertelement <8 x i1> %1039, i1 %1051, i64 2
  %1053 = extractelement <8 x i32> %.spill.load185, i64 3
  %1054 = icmp ult i32 %1053, 8
  %1055 = select i1 %1054, i32 %1053, i32 0
  %1056 = extractelement <8 x i1> %59, i32 %1055
  %1057 = extractelement <8 x i1> %59, i64 3
  %1058 = and i1 %1054, %1056
  %1059 = and i1 %1057, %1058
  %1060 = extractelement <8 x float> %1013, i32 %1055
  %1061 = select i1 %1059, float %1060, float 0.000000e+00
  %1062 = insertelement <8 x float> %1049, float %1061, i64 3
  %1063 = xor i1 %1059, true
  %1064 = and i1 %1057, %1063
  %1065 = insertelement <8 x i1> %1052, i1 %1064, i64 3
  %1066 = extractelement <8 x i32> %.spill.load185, i64 4
  %1067 = icmp ult i32 %1066, 8
  %1068 = select i1 %1067, i32 %1066, i32 0
  %1069 = extractelement <8 x i1> %59, i32 %1068
  %1070 = extractelement <8 x i1> %59, i64 4
  %1071 = and i1 %1067, %1069
  %1072 = and i1 %1070, %1071
  %1073 = extractelement <8 x float> %1013, i32 %1068
  %1074 = select i1 %1072, float %1073, float 0.000000e+00
  %1075 = insertelement <8 x float> %1062, float %1074, i64 4
  %1076 = xor i1 %1072, true
  %1077 = and i1 %1070, %1076
  %1078 = insertelement <8 x i1> %1065, i1 %1077, i64 4
  %1079 = extractelement <8 x i32> %.spill.load185, i64 5
  %1080 = icmp ult i32 %1079, 8
  %1081 = select i1 %1080, i32 %1079, i32 0
  %1082 = extractelement <8 x i1> %59, i32 %1081
  %1083 = extractelement <8 x i1> %59, i64 5
  %1084 = and i1 %1080, %1082
  %1085 = and i1 %1083, %1084
  %1086 = extractelement <8 x float> %1013, i32 %1081
  %1087 = select i1 %1085, float %1086, float 0.000000e+00
  %1088 = insertelement <8 x float> %1075, float %1087, i64 5
  %1089 = xor i1 %1085, true
  %1090 = and i1 %1083, %1089
  %1091 = insertelement <8 x i1> %1078, i1 %1090, i64 5
  %1092 = extractelement <8 x i32> %.spill.load185, i64 6
  %1093 = icmp ult i32 %1092, 8
  %1094 = select i1 %1093, i32 %1092, i32 0
  %1095 = extractelement <8 x i1> %59, i32 %1094
  %1096 = extractelement <8 x i1> %59, i64 6
  %1097 = and i1 %1093, %1095
  %1098 = and i1 %1096, %1097
  %1099 = extractelement <8 x float> %1013, i32 %1094
  %1100 = select i1 %1098, float %1099, float 0.000000e+00
  %1101 = insertelement <8 x float> %1088, float %1100, i64 6
  %1102 = xor i1 %1098, true
  %1103 = and i1 %1096, %1102
  %1104 = insertelement <8 x i1> %1091, i1 %1103, i64 6
  %1105 = extractelement <8 x i32> %.spill.load185, i64 7
  %1106 = icmp ult i32 %1105, 8
  %1107 = select i1 %1106, i32 %1105, i32 0
  %1108 = extractelement <8 x i1> %59, i32 %1107
  %1109 = extractelement <8 x i1> %59, i64 7
  %1110 = and i1 %1106, %1108
  %1111 = and i1 %1109, %1110
  %1112 = extractelement <8 x float> %1013, i32 %1107
  %1113 = select i1 %1111, float %1112, float 0.000000e+00
  %1114 = insertelement <8 x float> %1101, float %1113, i64 7
  %1115 = xor i1 %1111, true
  %1116 = and i1 %1109, %1115
  %1117 = insertelement <8 x i1> %1104, i1 %1116, i64 7
  %1118 = fadd <8 x float> %1013, %1114
  %.spill.load186 = load <8 x i32>, ptr %.spill23, align 32
  %1119 = extractelement <8 x i32> %.spill.load186, i64 0
  %1120 = icmp ult i32 %1119, 8
  %1121 = select i1 %1120, i32 %1119, i32 0
  %1122 = extractelement <8 x i1> %59, i32 %1121
  %1123 = extractelement <8 x i1> %59, i64 0
  %1124 = and i1 %1120, %1122
  %1125 = and i1 %1123, %1124
  %1126 = extractelement <8 x float> %1118, i32 %1121
  %1127 = select i1 %1125, float %1126, float 0.000000e+00
  %1128 = insertelement <8 x float> poison, float %1127, i64 0
  %1129 = xor i1 %1125, true
  %1130 = and i1 %1123, %1129
  %1131 = insertelement <8 x i1> poison, i1 %1130, i64 0
  %1132 = extractelement <8 x i32> %.spill.load186, i64 1
  %1133 = icmp ult i32 %1132, 8
  %1134 = select i1 %1133, i32 %1132, i32 0
  %1135 = extractelement <8 x i1> %59, i32 %1134
  %1136 = extractelement <8 x i1> %59, i64 1
  %1137 = and i1 %1133, %1135
  %1138 = and i1 %1136, %1137
  %1139 = extractelement <8 x float> %1118, i32 %1134
  %1140 = select i1 %1138, float %1139, float 0.000000e+00
  %1141 = insertelement <8 x float> %1128, float %1140, i64 1
  %1142 = xor i1 %1138, true
  %1143 = and i1 %1136, %1142
  %1144 = insertelement <8 x i1> %1131, i1 %1143, i64 1
  %1145 = extractelement <8 x i32> %.spill.load186, i64 2
  %1146 = icmp ult i32 %1145, 8
  %1147 = select i1 %1146, i32 %1145, i32 0
  %1148 = extractelement <8 x i1> %59, i32 %1147
  %1149 = extractelement <8 x i1> %59, i64 2
  %1150 = and i1 %1146, %1148
  %1151 = and i1 %1149, %1150
  %1152 = extractelement <8 x float> %1118, i32 %1147
  %1153 = select i1 %1151, float %1152, float 0.000000e+00
  %1154 = insertelement <8 x float> %1141, float %1153, i64 2
  %1155 = xor i1 %1151, true
  %1156 = and i1 %1149, %1155
  %1157 = insertelement <8 x i1> %1144, i1 %1156, i64 2
  %1158 = extractelement <8 x i32> %.spill.load186, i64 3
  %1159 = icmp ult i32 %1158, 8
  %1160 = select i1 %1159, i32 %1158, i32 0
  %1161 = extractelement <8 x i1> %59, i32 %1160
  %1162 = extractelement <8 x i1> %59, i64 3
  %1163 = and i1 %1159, %1161
  %1164 = and i1 %1162, %1163
  %1165 = extractelement <8 x float> %1118, i32 %1160
  %1166 = select i1 %1164, float %1165, float 0.000000e+00
  %1167 = insertelement <8 x float> %1154, float %1166, i64 3
  %1168 = xor i1 %1164, true
  %1169 = and i1 %1162, %1168
  %1170 = insertelement <8 x i1> %1157, i1 %1169, i64 3
  %1171 = extractelement <8 x i32> %.spill.load186, i64 4
  %1172 = icmp ult i32 %1171, 8
  %1173 = select i1 %1172, i32 %1171, i32 0
  %1174 = extractelement <8 x i1> %59, i32 %1173
  %1175 = extractelement <8 x i1> %59, i64 4
  %1176 = and i1 %1172, %1174
  %1177 = and i1 %1175, %1176
  %1178 = extractelement <8 x float> %1118, i32 %1173
  %1179 = select i1 %1177, float %1178, float 0.000000e+00
  %1180 = insertelement <8 x float> %1167, float %1179, i64 4
  %1181 = xor i1 %1177, true
  %1182 = and i1 %1175, %1181
  %1183 = insertelement <8 x i1> %1170, i1 %1182, i64 4
  %1184 = extractelement <8 x i32> %.spill.load186, i64 5
  %1185 = icmp ult i32 %1184, 8
  %1186 = select i1 %1185, i32 %1184, i32 0
  %1187 = extractelement <8 x i1> %59, i32 %1186
  %1188 = extractelement <8 x i1> %59, i64 5
  %1189 = and i1 %1185, %1187
  %1190 = and i1 %1188, %1189
  %1191 = extractelement <8 x float> %1118, i32 %1186
  %1192 = select i1 %1190, float %1191, float 0.000000e+00
  %1193 = insertelement <8 x float> %1180, float %1192, i64 5
  %1194 = xor i1 %1190, true
  %1195 = and i1 %1188, %1194
  %1196 = insertelement <8 x i1> %1183, i1 %1195, i64 5
  %1197 = extractelement <8 x i32> %.spill.load186, i64 6
  %1198 = icmp ult i32 %1197, 8
  %1199 = select i1 %1198, i32 %1197, i32 0
  %1200 = extractelement <8 x i1> %59, i32 %1199
  %1201 = extractelement <8 x i1> %59, i64 6
  %1202 = and i1 %1198, %1200
  %1203 = and i1 %1201, %1202
  %1204 = extractelement <8 x float> %1118, i32 %1199
  %1205 = select i1 %1203, float %1204, float 0.000000e+00
  %1206 = insertelement <8 x float> %1193, float %1205, i64 6
  %1207 = xor i1 %1203, true
  %1208 = and i1 %1201, %1207
  %1209 = insertelement <8 x i1> %1196, i1 %1208, i64 6
  %1210 = extractelement <8 x i32> %.spill.load186, i64 7
  %1211 = icmp ult i32 %1210, 8
  %1212 = select i1 %1211, i32 %1210, i32 0
  %1213 = extractelement <8 x i1> %59, i32 %1212
  %1214 = extractelement <8 x i1> %59, i64 7
  %1215 = and i1 %1211, %1213
  %1216 = and i1 %1214, %1215
  %1217 = extractelement <8 x float> %1118, i32 %1212
  %1218 = select i1 %1216, float %1217, float 0.000000e+00
  %1219 = insertelement <8 x float> %1206, float %1218, i64 7
  %1220 = xor i1 %1216, true
  %1221 = and i1 %1214, %1220
  %1222 = insertelement <8 x i1> %1209, i1 %1221, i64 7
  %1223 = fadd <8 x float> %1118, %1219
  %.spill.load187 = load <8 x i32>, ptr %.spill24, align 32
  %1224 = extractelement <8 x i32> %.spill.load187, i64 0
  %1225 = icmp ult i32 %1224, 8
  %1226 = select i1 %1225, i32 %1224, i32 0
  %1227 = extractelement <8 x i1> %59, i32 %1226
  %1228 = extractelement <8 x i1> %59, i64 0
  %1229 = and i1 %1225, %1227
  %1230 = and i1 %1228, %1229
  %1231 = extractelement <8 x float> %1223, i32 %1226
  %1232 = select i1 %1230, float %1231, float 0.000000e+00
  %1233 = insertelement <8 x float> poison, float %1232, i64 0
  %1234 = xor i1 %1230, true
  %1235 = and i1 %1228, %1234
  %1236 = insertelement <8 x i1> poison, i1 %1235, i64 0
  %1237 = extractelement <8 x i32> %.spill.load187, i64 1
  %1238 = icmp ult i32 %1237, 8
  %1239 = select i1 %1238, i32 %1237, i32 0
  %1240 = extractelement <8 x i1> %59, i32 %1239
  %1241 = extractelement <8 x i1> %59, i64 1
  %1242 = and i1 %1238, %1240
  %1243 = and i1 %1241, %1242
  %1244 = extractelement <8 x float> %1223, i32 %1239
  %1245 = select i1 %1243, float %1244, float 0.000000e+00
  %1246 = insertelement <8 x float> %1233, float %1245, i64 1
  %1247 = xor i1 %1243, true
  %1248 = and i1 %1241, %1247
  %1249 = insertelement <8 x i1> %1236, i1 %1248, i64 1
  %1250 = extractelement <8 x i32> %.spill.load187, i64 2
  %1251 = icmp ult i32 %1250, 8
  %1252 = select i1 %1251, i32 %1250, i32 0
  %1253 = extractelement <8 x i1> %59, i32 %1252
  %1254 = extractelement <8 x i1> %59, i64 2
  %1255 = and i1 %1251, %1253
  %1256 = and i1 %1254, %1255
  %1257 = extractelement <8 x float> %1223, i32 %1252
  %1258 = select i1 %1256, float %1257, float 0.000000e+00
  %1259 = insertelement <8 x float> %1246, float %1258, i64 2
  %1260 = xor i1 %1256, true
  %1261 = and i1 %1254, %1260
  %1262 = insertelement <8 x i1> %1249, i1 %1261, i64 2
  %1263 = extractelement <8 x i32> %.spill.load187, i64 3
  %1264 = icmp ult i32 %1263, 8
  %1265 = select i1 %1264, i32 %1263, i32 0
  %1266 = extractelement <8 x i1> %59, i32 %1265
  %1267 = extractelement <8 x i1> %59, i64 3
  %1268 = and i1 %1264, %1266
  %1269 = and i1 %1267, %1268
  %1270 = extractelement <8 x float> %1223, i32 %1265
  %1271 = select i1 %1269, float %1270, float 0.000000e+00
  %1272 = insertelement <8 x float> %1259, float %1271, i64 3
  %1273 = xor i1 %1269, true
  %1274 = and i1 %1267, %1273
  %1275 = insertelement <8 x i1> %1262, i1 %1274, i64 3
  %1276 = extractelement <8 x i32> %.spill.load187, i64 4
  %1277 = icmp ult i32 %1276, 8
  %1278 = select i1 %1277, i32 %1276, i32 0
  %1279 = extractelement <8 x i1> %59, i32 %1278
  %1280 = extractelement <8 x i1> %59, i64 4
  %1281 = and i1 %1277, %1279
  %1282 = and i1 %1280, %1281
  %1283 = extractelement <8 x float> %1223, i32 %1278
  %1284 = select i1 %1282, float %1283, float 0.000000e+00
  %1285 = insertelement <8 x float> %1272, float %1284, i64 4
  %1286 = xor i1 %1282, true
  %1287 = and i1 %1280, %1286
  %1288 = insertelement <8 x i1> %1275, i1 %1287, i64 4
  %1289 = extractelement <8 x i32> %.spill.load187, i64 5
  %1290 = icmp ult i32 %1289, 8
  %1291 = select i1 %1290, i32 %1289, i32 0
  %1292 = extractelement <8 x i1> %59, i32 %1291
  %1293 = extractelement <8 x i1> %59, i64 5
  %1294 = and i1 %1290, %1292
  %1295 = and i1 %1293, %1294
  %1296 = extractelement <8 x float> %1223, i32 %1291
  %1297 = select i1 %1295, float %1296, float 0.000000e+00
  %1298 = insertelement <8 x float> %1285, float %1297, i64 5
  %1299 = xor i1 %1295, true
  %1300 = and i1 %1293, %1299
  %1301 = insertelement <8 x i1> %1288, i1 %1300, i64 5
  %1302 = extractelement <8 x i32> %.spill.load187, i64 6
  %1303 = icmp ult i32 %1302, 8
  %1304 = select i1 %1303, i32 %1302, i32 0
  %1305 = extractelement <8 x i1> %59, i32 %1304
  %1306 = extractelement <8 x i1> %59, i64 6
  %1307 = and i1 %1303, %1305
  %1308 = and i1 %1306, %1307
  %1309 = extractelement <8 x float> %1223, i32 %1304
  %1310 = select i1 %1308, float %1309, float 0.000000e+00
  %1311 = insertelement <8 x float> %1298, float %1310, i64 6
  %1312 = xor i1 %1308, true
  %1313 = and i1 %1306, %1312
  %1314 = insertelement <8 x i1> %1301, i1 %1313, i64 6
  %1315 = extractelement <8 x i32> %.spill.load187, i64 7
  %1316 = icmp ult i32 %1315, 8
  %1317 = select i1 %1316, i32 %1315, i32 0
  %1318 = extractelement <8 x i1> %59, i32 %1317
  %1319 = extractelement <8 x i1> %59, i64 7
  %1320 = and i1 %1316, %1318
  %1321 = and i1 %1319, %1320
  %1322 = extractelement <8 x float> %1223, i32 %1317
  %1323 = select i1 %1321, float %1322, float 0.000000e+00
  %1324 = insertelement <8 x float> %1311, float %1323, i64 7
  %1325 = xor i1 %1321, true
  %1326 = and i1 %1319, %1325
  %1327 = insertelement <8 x i1> %1314, i1 %1326, i64 7
  %1328 = fadd <8 x float> %1223, %1324
  %1329 = extractelement <8 x i1> %59, i32 0
  %1330 = extractelement <8 x i1> %59, i64 0
  %1331 = and i1 true, %1329
  %1332 = and i1 %1330, %1331
  %1333 = extractelement <8 x float> %1328, i32 0
  %1334 = select i1 %1332, float %1333, float 0.000000e+00
  %1335 = insertelement <8 x float> poison, float %1334, i64 0
  %1336 = xor i1 %1332, true
  %1337 = and i1 %1330, %1336
  %1338 = insertelement <8 x i1> poison, i1 %1337, i64 0
  %1339 = extractelement <8 x i1> %59, i32 0
  %1340 = extractelement <8 x i1> %59, i64 1
  %1341 = and i1 true, %1339
  %1342 = and i1 %1340, %1341
  %1343 = extractelement <8 x float> %1328, i32 0
  %1344 = select i1 %1342, float %1343, float 0.000000e+00
  %1345 = insertelement <8 x float> %1335, float %1344, i64 1
  %1346 = xor i1 %1342, true
  %1347 = and i1 %1340, %1346
  %1348 = insertelement <8 x i1> %1338, i1 %1347, i64 1
  %1349 = extractelement <8 x i1> %59, i32 0
  %1350 = extractelement <8 x i1> %59, i64 2
  %1351 = and i1 true, %1349
  %1352 = and i1 %1350, %1351
  %1353 = extractelement <8 x float> %1328, i32 0
  %1354 = select i1 %1352, float %1353, float 0.000000e+00
  %1355 = insertelement <8 x float> %1345, float %1354, i64 2
  %1356 = xor i1 %1352, true
  %1357 = and i1 %1350, %1356
  %1358 = insertelement <8 x i1> %1348, i1 %1357, i64 2
  %1359 = extractelement <8 x i1> %59, i32 0
  %1360 = extractelement <8 x i1> %59, i64 3
  %1361 = and i1 true, %1359
  %1362 = and i1 %1360, %1361
  %1363 = extractelement <8 x float> %1328, i32 0
  %1364 = select i1 %1362, float %1363, float 0.000000e+00
  %1365 = insertelement <8 x float> %1355, float %1364, i64 3
  %1366 = xor i1 %1362, true
  %1367 = and i1 %1360, %1366
  %1368 = insertelement <8 x i1> %1358, i1 %1367, i64 3
  %1369 = extractelement <8 x i1> %59, i32 0
  %1370 = extractelement <8 x i1> %59, i64 4
  %1371 = and i1 true, %1369
  %1372 = and i1 %1370, %1371
  %1373 = extractelement <8 x float> %1328, i32 0
  %1374 = select i1 %1372, float %1373, float 0.000000e+00
  %1375 = insertelement <8 x float> %1365, float %1374, i64 4
  %1376 = xor i1 %1372, true
  %1377 = and i1 %1370, %1376
  %1378 = insertelement <8 x i1> %1368, i1 %1377, i64 4
  %1379 = extractelement <8 x i1> %59, i32 0
  %1380 = extractelement <8 x i1> %59, i64 5
  %1381 = and i1 true, %1379
  %1382 = and i1 %1380, %1381
  %1383 = extractelement <8 x float> %1328, i32 0
  %1384 = select i1 %1382, float %1383, float 0.000000e+00
  %1385 = insertelement <8 x float> %1375, float %1384, i64 5
  %1386 = xor i1 %1382, true
  %1387 = and i1 %1380, %1386
  %1388 = insertelement <8 x i1> %1378, i1 %1387, i64 5
  %1389 = extractelement <8 x i1> %59, i32 0
  %1390 = extractelement <8 x i1> %59, i64 6
  %1391 = and i1 true, %1389
  %1392 = and i1 %1390, %1391
  %1393 = extractelement <8 x float> %1328, i32 0
  %1394 = select i1 %1392, float %1393, float 0.000000e+00
  %1395 = insertelement <8 x float> %1385, float %1394, i64 6
  %1396 = xor i1 %1392, true
  %1397 = and i1 %1390, %1396
  %1398 = insertelement <8 x i1> %1388, i1 %1397, i64 6
  %1399 = extractelement <8 x i1> %59, i32 0
  %1400 = extractelement <8 x i1> %59, i64 7
  %1401 = and i1 true, %1399
  %1402 = and i1 %1400, %1401
  %1403 = extractelement <8 x float> %1328, i32 0
  %1404 = select i1 %1402, float %1403, float 0.000000e+00
  %1405 = insertelement <8 x float> %1395, float %1404, i64 7
  %1406 = xor i1 %1402, true
  %1407 = and i1 %1400, %1406
  %1408 = insertelement <8 x i1> %1398, i1 %1407, i64 7
  %1409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %1410 = bitcast <8 x i1> %59 to i8
  %1411 = call i8 @llvm.cttz.i8(i8 %1410, i1 false)
  %1412 = zext i8 %1411 to i32
  %1413 = select i1 %1409, i32 %1412, i32 0
  %1414 = extractelement <8 x float> %1405, i32 %1413
  %1415 = fadd float 0.000000e+00, %1414
  %1416 = fdiv float %1415, 4.097000e+03
  store float %1416, ptr %.spill34, align 4
  %1417 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1418 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %1417, 0
  %1420 = select <8 x i1> %59, <8 x ptr> %1418, <8 x ptr> %1419
  %1421 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %1422 = extractvalue { <8 x ptr>, <8 x i64> } %1417, 1
  %1423 = select <8 x i1> %59, <8 x i64> %1421, <8 x i64> %1422
  %1424 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1420, 0
  %1425 = insertvalue { <8 x ptr>, <8 x i64> } %1424, <8 x i64> %1423, 1
  store { <8 x ptr>, <8 x i64> } %1425, ptr %tile_snapshot.spill35, align 64
  %1426 = load <8 x i64>, ptr %.slot36, align 64
  %1427 = select <8 x i1> %59, <8 x i64> zeroinitializer, <8 x i64> %1426
  store <8 x i64> %1427, ptr %.slot36, align 64
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state188 = load <8 x i64>, ptr %.slot36, align 64
  %1428 = icmp slt <8 x i64> %.state188, splat (i64 512)
  %1429 = extractelement <8 x i1> %1428, i32 0
  br i1 %1429, label %direct.true189, label %direct.false190

direct.schedule.22:                               ; preds = %direct.true189
  %.state191 = load <8 x i64>, ptr %.slot36, align 64
  %1430 = mul <8 x i64> %.state191, splat (i64 8)
  %.spill.load192 = load <8 x i64>, ptr %.spill, align 64
  %1431 = add <8 x i64> %1430, %.spill.load192
  %.spill.load193 = load i64, ptr %.spill15, align 4
  %1432 = add i64 %.spill.load193, 0
  %1433 = add <8 x i64> zeroinitializer, %1431
  %1434 = mul i64 %1432, 4097
  %.splatinsert194 = insertelement <8 x i64> poison, i64 %1434, i64 0
  %.splat195 = shufflevector <8 x i64> %.splatinsert194, <8 x i64> poison, <8 x i32> zeroinitializer
  %1435 = add <8 x i64> %.splat195, %1433
  %1436 = extractvalue { ptr, i64 } %23, 0
  %1437 = extractelement <8 x i64> %1435, i32 0
  %1438 = sub i64 %1437, 0
  %1439 = mul i64 %1438, 4
  %buffer.contiguous.address196 = getelementptr i8, ptr %1436, i64 %1439
  %buffer.contiguous.load197 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address196, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load198 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 1
  %.state199 = load <8 x i64>, ptr %.slot36, align 64
  %1442 = mul <8 x i64> %.state199, splat (i64 32)
  %1443 = add <8 x i64> %1441, %1442
  %1444 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1440, 0
  %1445 = insertvalue { <8 x ptr>, <8 x i64> } %1444, <8 x i64> %1443, 1
  %1446 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1447 = extractvalue { <8 x ptr>, <8 x i64> } %1445, 1
  %1448 = extractelement <8 x ptr> %1446, i32 0
  %1449 = extractelement <8 x i64> %1447, i32 0
  %1450 = sub i64 %1449, 0
  %1451 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %1452 = select i1 %1451, i64 %1450, i64 0
  %private.contiguous.address200 = getelementptr i8, ptr %1448, i64 %1452
  %private.contiguous.preserve201 = load <8 x float>, ptr %private.contiguous.address200, align 4
  %1453 = select <8 x i1> %59, <8 x float> %buffer.contiguous.load197, <8 x float> %private.contiguous.preserve201
  store <8 x float> %1453, ptr %private.contiguous.address200, align 4
  %.state202 = load <8 x i64>, ptr %.slot36, align 64
  %1454 = add <8 x i64> %.state202, splat (i64 1)
  %1455 = load <8 x i64>, ptr %.slot36, align 64
  %1456 = select <8 x i1> %59, <8 x i64> %1454, <8 x i64> %1455
  store <8 x i64> %1456, ptr %.slot36, align 64
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false190
  %.spill.load203 = load <8 x i1>, ptr %.spill14, align 1
  %1457 = and <8 x i1> %59, %.spill.load203
  %1458 = xor <8 x i1> %.spill.load203, splat (i1 true)
  %1459 = and <8 x i1> %59, %1458
  %1460 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1457)
  %1461 = bitcast <8 x i1> %1457 to i8
  %1462 = call i8 @llvm.cttz.i8(i8 %1461, i1 false)
  %1463 = zext i8 %1462 to i32
  %1464 = select i1 %1460, i32 %1463, i32 0
  %.spill.load204 = load <8 x i64>, ptr %.spill, align 64
  %1465 = add <8 x i64> splat (i64 4096), %.spill.load204
  %.spill.load205 = load i64, ptr %.spill15, align 4
  %1466 = add i64 %.spill.load205, 0
  %1467 = add <8 x i64> zeroinitializer, %1465
  %1468 = mul i64 %1466, 4097
  %.splatinsert206 = insertelement <8 x i64> poison, i64 %1468, i64 0
  %.splat207 = shufflevector <8 x i64> %.splatinsert206, <8 x i64> poison, <8 x i32> zeroinitializer
  %1469 = add <8 x i64> %.splat207, %1467
  %1470 = extractvalue { ptr, i64 } %23, 0
  %1471 = select <8 x i1> %1457, <8 x i64> %1469, <8 x i64> zeroinitializer
  %1472 = extractelement <8 x i64> %1471, i32 %1464
  %1473 = zext i32 %1464 to i64
  %1474 = sub i64 %1472, %1473
  %1475 = mul i64 %1474, 4
  %buffer.contiguous.address208 = getelementptr i8, ptr %1470, i64 %1475
  %buffer.contiguous.load209 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address208, <8 x i1> %1457, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load210 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1476 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 0
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load210, 1
  %1478 = add <8 x i64> %1477, splat (i64 16384)
  %1479 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1476, 0
  %1480 = insertvalue { <8 x ptr>, <8 x i64> } %1479, <8 x i64> %1478, 1
  %1481 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1482 = extractvalue { <8 x ptr>, <8 x i64> } %1480, 1
  %1483 = extractelement <8 x ptr> %1481, i32 0
  %1484 = extractelement <8 x i64> %1482, i32 %1464
  %1485 = zext i32 %1464 to i64
  %1486 = mul i64 %1485, 4
  %1487 = sub i64 %1484, %1486
  %1488 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1457)
  %1489 = select i1 %1488, i64 %1487, i64 0
  %private.contiguous.address211 = getelementptr i8, ptr %1483, i64 %1489
  %private.contiguous.preserve212 = load <8 x float>, ptr %private.contiguous.address211, align 4
  %1490 = select <8 x i1> %1457, <8 x float> %buffer.contiguous.load209, <8 x float> %private.contiguous.preserve212
  store <8 x float> %1490, ptr %private.contiguous.address211, align 4
  %1491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1459)
  %1492 = bitcast <8 x i1> %1459 to i8
  %1493 = call i8 @llvm.cttz.i8(i8 %1492, i1 false)
  %1494 = zext i8 %1493 to i32
  %1495 = select i1 %1491, i32 %1494, i32 0
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.23
  %.spill.load213 = load float, ptr %.spill34, align 4
  %1496 = fadd float %.spill.load213, 0x3EE4F8B580000000
  %1497 = call float @llvm.sqrt.f32(float %1496)
  store float %1497, ptr %.spill37, align 4
  %1498 = extractvalue { ptr, i64 } %29, 1
  %1499 = extractvalue { ptr, i64 } %29, 0
  %1500 = ptrtoint ptr %1499 to i64
  %1501 = extractvalue { ptr, i64 } %35, 1
  %1502 = extractvalue { ptr, i64 } %35, 0
  %1503 = ptrtoint ptr %1502 to i64
  %1504 = icmp uge i64 %1500, %1503
  %1505 = sub i64 %1500, %1503
  %1506 = icmp uge i64 %1505, 16781312
  %1507 = and i1 %1504, %1506
  %1508 = icmp uge i64 %1503, %1500
  %1509 = sub i64 %1503, %1500
  %1510 = icmp uge i64 %1509, 16388
  %1511 = and i1 %1508, %1510
  %1512 = or i1 %1507, %1511
  %1513 = and i1 true, %1512
  br i1 %1513, label %direct.true214, label %direct.false215

direct.schedule.26:                               ; preds = %direct.true214
  %1514 = load <8 x i64>, ptr %.slot38, align 64
  %1515 = select <8 x i1> %59, <8 x i64> zeroinitializer, <8 x i64> %1514
  store <8 x i64> %1515, ptr %.slot38, align 64
  br label %direct.schedule.27

direct.schedule.27:                               ; preds = %direct.schedule.28, %direct.schedule.26
  %.state216 = load <8 x i64>, ptr %.slot38, align 64
  %1516 = icmp slt <8 x i64> %.state216, splat (i64 512)
  %1517 = extractelement <8 x i1> %1516, i32 0
  br i1 %1517, label %direct.true217, label %direct.false218

direct.schedule.28:                               ; preds = %direct.true217
  %.state219 = load <8 x i64>, ptr %.slot38, align 64
  %1518 = mul <8 x i64> %.state219, splat (i64 8)
  %.spill.load220 = load <8 x i64>, ptr %.spill, align 64
  %1519 = add <8 x i64> %1518, %.spill.load220
  %tile_snapshot.spill.load221 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %1520 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 0
  %1521 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load221, 1
  %.state222 = load <8 x i64>, ptr %.slot38, align 64
  %1522 = mul <8 x i64> %.state222, splat (i64 32)
  %1523 = add <8 x i64> %1521, %1522
  %1524 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1520, 0
  %1525 = insertvalue { <8 x ptr>, <8 x i64> } %1524, <8 x i64> %1523, 1
  %1526 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1527 = extractvalue { <8 x ptr>, <8 x i64> } %1525, 1
  %1528 = extractelement <8 x ptr> %1526, i32 0
  %1529 = extractelement <8 x i64> %1527, i32 0
  %1530 = sub i64 %1529, 0
  %1531 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %1532 = select i1 %1531, i64 %1530, i64 0
  %private.contiguous.address223 = getelementptr i8, ptr %1528, i64 %1532
  %private.contiguous.load224 = load <8 x float>, ptr %private.contiguous.address223, align 4
  %1533 = select <8 x i1> %59, <8 x float> %private.contiguous.load224, <8 x float> zeroinitializer
  %.spill.load225 = load float, ptr %.spill37, align 4
  %.splatinsert226 = insertelement <8 x float> poison, float %.spill.load225, i64 0
  %.splat227 = shufflevector <8 x float> %.splatinsert226, <8 x float> poison, <8 x i32> zeroinitializer
  %1534 = fdiv <8 x float> %1533, %.splat227
  %tile_snapshot.spill.load228 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1535 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load228, 0
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load228, 1
  %.state229 = load <8 x i64>, ptr %.slot38, align 64
  %1537 = mul <8 x i64> %.state229, splat (i64 32)
  %1538 = add <8 x i64> %1536, %1537
  %1539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1535, 0
  %1540 = insertvalue { <8 x ptr>, <8 x i64> } %1539, <8 x i64> %1538, 1
  %1541 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1542 = extractvalue { <8 x ptr>, <8 x i64> } %1540, 1
  %1543 = extractelement <8 x ptr> %1541, i32 0
  %1544 = extractelement <8 x i64> %1542, i32 0
  %1545 = sub i64 %1544, 0
  %1546 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %1547 = select i1 %1546, i64 %1545, i64 0
  %private.contiguous.address230 = getelementptr i8, ptr %1543, i64 %1547
  %private.contiguous.load231 = load <8 x float>, ptr %private.contiguous.address230, align 4
  %1548 = select <8 x i1> %59, <8 x float> %private.contiguous.load231, <8 x float> zeroinitializer
  %1549 = fmul <8 x float> %1534, %1548
  %.spill.load232 = load i64, ptr %.spill15, align 4
  %1550 = add i64 %.spill.load232, 0
  %1551 = add <8 x i64> zeroinitializer, %1519
  %1552 = mul i64 %1550, 4097
  %.splatinsert233 = insertelement <8 x i64> poison, i64 %1552, i64 0
  %.splat234 = shufflevector <8 x i64> %.splatinsert233, <8 x i64> poison, <8 x i32> zeroinitializer
  %1553 = add <8 x i64> %.splat234, %1551
  %1554 = extractvalue { ptr, i64 } %29, 0
  %1555 = extractelement <8 x i64> %1553, i32 0
  %1556 = sub i64 %1555, 0
  %1557 = mul i64 %1556, 4
  %buffer.contiguous.address235 = getelementptr i8, ptr %1554, i64 %1557
  %buffer.contiguous.load236 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address235, <8 x i1> %59, <8 x float> zeroinitializer)
  %1558 = fadd <8 x float> %1549, %buffer.contiguous.load236
  %.spill.load237 = load <8 x i64>, ptr %.spill13, align 64
  %1559 = add <8 x i64> %.spill.load237, zeroinitializer
  %1560 = add <8 x i64> zeroinitializer, %1559
  %1561 = mul <8 x i64> %1560, splat (i64 4097)
  %1562 = add <8 x i64> %1561, %1551
  %1563 = extractvalue { ptr, i64 } %35, 0
  %1564 = extractelement <8 x i64> %1562, i32 0
  %1565 = sub i64 %1564, 0
  %1566 = mul i64 %1565, 4
  %buffer.contiguous.address238 = getelementptr i8, ptr %1563, i64 %1566
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1558, ptr align 1 %buffer.contiguous.address238, <8 x i1> %59)
  %.state239 = load <8 x i64>, ptr %.slot38, align 64
  %1567 = add <8 x i64> %.state239, splat (i64 1)
  %1568 = load <8 x i64>, ptr %.slot38, align 64
  %1569 = select <8 x i1> %59, <8 x i64> %1567, <8 x i64> %1568
  store <8 x i64> %1569, ptr %.slot38, align 64
  br label %direct.schedule.27

direct.schedule.29:                               ; preds = %direct.false218
  %.spill.load240 = load <8 x i1>, ptr %.spill14, align 1
  %1570 = and <8 x i1> %59, %.spill.load240
  %1571 = xor <8 x i1> %.spill.load240, splat (i1 true)
  %1572 = and <8 x i1> %59, %1571
  %1573 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1570)
  %1574 = bitcast <8 x i1> %1570 to i8
  %1575 = call i8 @llvm.cttz.i8(i8 %1574, i1 false)
  %1576 = zext i8 %1575 to i32
  %1577 = select i1 %1573, i32 %1576, i32 0
  %.spill.load241 = load <8 x i64>, ptr %.spill, align 64
  %1578 = add <8 x i64> splat (i64 4096), %.spill.load241
  %tile_snapshot.spill.load242 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %1579 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 0
  %1580 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 1
  %1581 = add <8 x i64> %1580, splat (i64 16384)
  %1582 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1579, 0
  %1583 = insertvalue { <8 x ptr>, <8 x i64> } %1582, <8 x i64> %1581, 1
  %1584 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1585 = extractvalue { <8 x ptr>, <8 x i64> } %1583, 1
  %1586 = extractelement <8 x ptr> %1584, i32 0
  %1587 = extractelement <8 x i64> %1585, i32 %1577
  %1588 = zext i32 %1577 to i64
  %1589 = mul i64 %1588, 4
  %1590 = sub i64 %1587, %1589
  %1591 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1570)
  %1592 = select i1 %1591, i64 %1590, i64 0
  %private.contiguous.address243 = getelementptr i8, ptr %1586, i64 %1592
  %private.contiguous.load244 = load <8 x float>, ptr %private.contiguous.address243, align 4
  %1593 = select <8 x i1> %1570, <8 x float> %private.contiguous.load244, <8 x float> zeroinitializer
  %.spill.load245 = load float, ptr %.spill37, align 4
  %.splatinsert246 = insertelement <8 x float> poison, float %.spill.load245, i64 0
  %.splat247 = shufflevector <8 x float> %.splatinsert246, <8 x float> poison, <8 x i32> zeroinitializer
  %1594 = fdiv <8 x float> %1593, %.splat247
  %tile_snapshot.spill.load248 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1595 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %1596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %1597 = add <8 x i64> %1596, splat (i64 16384)
  %1598 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1595, 0
  %1599 = insertvalue { <8 x ptr>, <8 x i64> } %1598, <8 x i64> %1597, 1
  %1600 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1601 = extractvalue { <8 x ptr>, <8 x i64> } %1599, 1
  %1602 = extractelement <8 x ptr> %1600, i32 0
  %1603 = extractelement <8 x i64> %1601, i32 %1577
  %1604 = zext i32 %1577 to i64
  %1605 = mul i64 %1604, 4
  %1606 = sub i64 %1603, %1605
  %1607 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1570)
  %1608 = select i1 %1607, i64 %1606, i64 0
  %private.contiguous.address249 = getelementptr i8, ptr %1602, i64 %1608
  %private.contiguous.load250 = load <8 x float>, ptr %private.contiguous.address249, align 4
  %1609 = select <8 x i1> %1570, <8 x float> %private.contiguous.load250, <8 x float> zeroinitializer
  %1610 = fmul <8 x float> %1594, %1609
  %.spill.load251 = load i64, ptr %.spill15, align 4
  %1611 = add i64 %.spill.load251, 0
  %1612 = add <8 x i64> zeroinitializer, %1578
  %1613 = mul i64 %1611, 4097
  %.splatinsert252 = insertelement <8 x i64> poison, i64 %1613, i64 0
  %.splat253 = shufflevector <8 x i64> %.splatinsert252, <8 x i64> poison, <8 x i32> zeroinitializer
  %1614 = add <8 x i64> %.splat253, %1612
  %1615 = extractvalue { ptr, i64 } %29, 0
  %1616 = select <8 x i1> %1570, <8 x i64> %1614, <8 x i64> zeroinitializer
  %1617 = extractelement <8 x i64> %1616, i32 %1577
  %1618 = zext i32 %1577 to i64
  %1619 = sub i64 %1617, %1618
  %1620 = mul i64 %1619, 4
  %buffer.contiguous.address254 = getelementptr i8, ptr %1615, i64 %1620
  %buffer.contiguous.load255 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address254, <8 x i1> %1570, <8 x float> zeroinitializer)
  %1621 = fadd <8 x float> %1610, %buffer.contiguous.load255
  %.spill.load256 = load <8 x i64>, ptr %.spill13, align 64
  %1622 = add <8 x i64> %.spill.load256, zeroinitializer
  %1623 = add <8 x i64> zeroinitializer, %1622
  %1624 = mul <8 x i64> %1623, splat (i64 4097)
  %1625 = add <8 x i64> %1624, %1612
  %1626 = extractvalue { ptr, i64 } %35, 0
  %1627 = extractelement <8 x i64> %1625, i32 %1577
  %1628 = zext i32 %1577 to i64
  %1629 = sub i64 %1627, %1628
  %1630 = mul i64 %1629, 4
  %buffer.contiguous.address257 = getelementptr i8, ptr %1626, i64 %1630
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1621, ptr align 1 %buffer.contiguous.address257, <8 x i1> %1570)
  %1631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1572)
  %1632 = bitcast <8 x i1> %1572 to i8
  %1633 = call i8 @llvm.cttz.i8(i8 %1632, i1 false)
  %1634 = zext i8 %1633 to i32
  %1635 = select i1 %1631, i32 %1634, i32 0
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.40, %direct.schedule.29
  ret void

direct.schedule.32:                               ; preds = %direct.false215
  %1636 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1637 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1638 = extractvalue { <8 x ptr>, <8 x i64> } %1636, 0
  %1639 = select <8 x i1> %59, <8 x ptr> %1637, <8 x ptr> %1638
  %1640 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %1641 = extractvalue { <8 x ptr>, <8 x i64> } %1636, 1
  %1642 = select <8 x i1> %59, <8 x i64> %1640, <8 x i64> %1641
  %1643 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1639, 0
  %1644 = insertvalue { <8 x ptr>, <8 x i64> } %1643, <8 x i64> %1642, 1
  store { <8 x ptr>, <8 x i64> } %1644, ptr %tile_snapshot.spill39, align 64
  %1645 = load <8 x i64>, ptr %.slot40, align 64
  %1646 = select <8 x i1> %59, <8 x i64> zeroinitializer, <8 x i64> %1645
  store <8 x i64> %1646, ptr %.slot40, align 64
  br label %direct.schedule.33

direct.schedule.33:                               ; preds = %direct.schedule.34, %direct.schedule.32
  %.state258 = load <8 x i64>, ptr %.slot40, align 64
  %1647 = icmp slt <8 x i64> %.state258, splat (i64 512)
  %1648 = extractelement <8 x i1> %1647, i32 0
  br i1 %1648, label %direct.true259, label %direct.false260

direct.schedule.34:                               ; preds = %direct.true259
  %.state261 = load <8 x i64>, ptr %.slot40, align 64
  %1649 = mul <8 x i64> %.state261, splat (i64 8)
  %.spill.load262 = load <8 x i64>, ptr %.spill, align 64
  %1650 = add <8 x i64> %1649, %.spill.load262
  %.spill.load263 = load i64, ptr %.spill15, align 4
  %1651 = add i64 %.spill.load263, 0
  %1652 = add <8 x i64> zeroinitializer, %1650
  %1653 = mul i64 %1651, 4097
  %.splatinsert264 = insertelement <8 x i64> poison, i64 %1653, i64 0
  %.splat265 = shufflevector <8 x i64> %.splatinsert264, <8 x i64> poison, <8 x i32> zeroinitializer
  %1654 = add <8 x i64> %.splat265, %1652
  %1655 = extractvalue { ptr, i64 } %29, 0
  %1656 = extractelement <8 x i64> %1654, i32 0
  %1657 = sub i64 %1656, 0
  %1658 = mul i64 %1657, 4
  %buffer.contiguous.address266 = getelementptr i8, ptr %1655, i64 %1658
  %buffer.contiguous.load267 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address266, <8 x i1> %59, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load268 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1659 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 0
  %1660 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 1
  %.state269 = load <8 x i64>, ptr %.slot40, align 64
  %1661 = mul <8 x i64> %.state269, splat (i64 32)
  %1662 = add <8 x i64> %1660, %1661
  %1663 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1659, 0
  %1664 = insertvalue { <8 x ptr>, <8 x i64> } %1663, <8 x i64> %1662, 1
  %1665 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1666 = extractvalue { <8 x ptr>, <8 x i64> } %1664, 1
  %1667 = extractelement <8 x ptr> %1665, i32 0
  %1668 = extractelement <8 x i64> %1666, i32 0
  %1669 = sub i64 %1668, 0
  %1670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %1671 = select i1 %1670, i64 %1669, i64 0
  %private.contiguous.address270 = getelementptr i8, ptr %1667, i64 %1671
  %private.contiguous.preserve271 = load <8 x float>, ptr %private.contiguous.address270, align 4
  %1672 = select <8 x i1> %59, <8 x float> %buffer.contiguous.load267, <8 x float> %private.contiguous.preserve271
  store <8 x float> %1672, ptr %private.contiguous.address270, align 4
  %.state272 = load <8 x i64>, ptr %.slot40, align 64
  %1673 = add <8 x i64> %.state272, splat (i64 1)
  %1674 = load <8 x i64>, ptr %.slot40, align 64
  %1675 = select <8 x i1> %59, <8 x i64> %1673, <8 x i64> %1674
  store <8 x i64> %1675, ptr %.slot40, align 64
  br label %direct.schedule.33

direct.schedule.35:                               ; preds = %direct.false260
  %.spill.load273 = load <8 x i1>, ptr %.spill14, align 1
  %1676 = and <8 x i1> %59, %.spill.load273
  %1677 = xor <8 x i1> %.spill.load273, splat (i1 true)
  %1678 = and <8 x i1> %59, %1677
  %1679 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1676)
  %1680 = bitcast <8 x i1> %1676 to i8
  %1681 = call i8 @llvm.cttz.i8(i8 %1680, i1 false)
  %1682 = zext i8 %1681 to i32
  %1683 = select i1 %1679, i32 %1682, i32 0
  %.spill.load274 = load <8 x i64>, ptr %.spill, align 64
  %1684 = add <8 x i64> splat (i64 4096), %.spill.load274
  %.spill.load275 = load i64, ptr %.spill15, align 4
  %1685 = add i64 %.spill.load275, 0
  %1686 = add <8 x i64> zeroinitializer, %1684
  %1687 = mul i64 %1685, 4097
  %.splatinsert276 = insertelement <8 x i64> poison, i64 %1687, i64 0
  %.splat277 = shufflevector <8 x i64> %.splatinsert276, <8 x i64> poison, <8 x i32> zeroinitializer
  %1688 = add <8 x i64> %.splat277, %1686
  %1689 = extractvalue { ptr, i64 } %29, 0
  %1690 = select <8 x i1> %1676, <8 x i64> %1688, <8 x i64> zeroinitializer
  %1691 = extractelement <8 x i64> %1690, i32 %1683
  %1692 = zext i32 %1683 to i64
  %1693 = sub i64 %1691, %1692
  %1694 = mul i64 %1693, 4
  %buffer.contiguous.address278 = getelementptr i8, ptr %1689, i64 %1694
  %buffer.contiguous.load279 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address278, <8 x i1> %1676, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load280 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1695 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %1696 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %1697 = add <8 x i64> %1696, splat (i64 16384)
  %1698 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1695, 0
  %1699 = insertvalue { <8 x ptr>, <8 x i64> } %1698, <8 x i64> %1697, 1
  %1700 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1701 = extractvalue { <8 x ptr>, <8 x i64> } %1699, 1
  %1702 = extractelement <8 x ptr> %1700, i32 0
  %1703 = extractelement <8 x i64> %1701, i32 %1683
  %1704 = zext i32 %1683 to i64
  %1705 = mul i64 %1704, 4
  %1706 = sub i64 %1703, %1705
  %1707 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1676)
  %1708 = select i1 %1707, i64 %1706, i64 0
  %private.contiguous.address281 = getelementptr i8, ptr %1702, i64 %1708
  %private.contiguous.preserve282 = load <8 x float>, ptr %private.contiguous.address281, align 4
  %1709 = select <8 x i1> %1676, <8 x float> %buffer.contiguous.load279, <8 x float> %private.contiguous.preserve282
  store <8 x float> %1709, ptr %private.contiguous.address281, align 4
  %1710 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1678)
  %1711 = bitcast <8 x i1> %1678 to i8
  %1712 = call i8 @llvm.cttz.i8(i8 %1711, i1 false)
  %1713 = zext i8 %1712 to i32
  %1714 = select i1 %1710, i32 %1713, i32 0
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.35
  %1715 = load <8 x i64>, ptr %.slot41, align 64
  %1716 = select <8 x i1> %59, <8 x i64> zeroinitializer, <8 x i64> %1715
  store <8 x i64> %1716, ptr %.slot41, align 64
  br label %direct.schedule.38

direct.schedule.38:                               ; preds = %direct.schedule.39, %direct.schedule.37
  %.state283 = load <8 x i64>, ptr %.slot41, align 64
  %1717 = icmp slt <8 x i64> %.state283, splat (i64 512)
  %1718 = extractelement <8 x i1> %1717, i32 0
  br i1 %1718, label %direct.true284, label %direct.false285

direct.schedule.39:                               ; preds = %direct.true284
  %.state286 = load <8 x i64>, ptr %.slot41, align 64
  %1719 = mul <8 x i64> %.state286, splat (i64 8)
  %.spill.load287 = load <8 x i64>, ptr %.spill, align 64
  %1720 = add <8 x i64> %1719, %.spill.load287
  %.spill.load288 = load <8 x i64>, ptr %.spill13, align 64
  %1721 = add <8 x i64> %.spill.load288, zeroinitializer
  %1722 = add <8 x i64> zeroinitializer, %1721
  %1723 = add <8 x i64> zeroinitializer, %1720
  %1724 = mul <8 x i64> %1722, splat (i64 4097)
  %1725 = add <8 x i64> %1724, %1723
  %tile_snapshot.spill.load289 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %1726 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load289, 0
  %1727 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load289, 1
  %.state290 = load <8 x i64>, ptr %.slot41, align 64
  %1728 = mul <8 x i64> %.state290, splat (i64 32)
  %1729 = add <8 x i64> %1727, %1728
  %1730 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1726, 0
  %1731 = insertvalue { <8 x ptr>, <8 x i64> } %1730, <8 x i64> %1729, 1
  %1732 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1733 = extractvalue { <8 x ptr>, <8 x i64> } %1731, 1
  %1734 = extractelement <8 x ptr> %1732, i32 0
  %1735 = extractelement <8 x i64> %1733, i32 0
  %1736 = sub i64 %1735, 0
  %1737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %1738 = select i1 %1737, i64 %1736, i64 0
  %private.contiguous.address291 = getelementptr i8, ptr %1734, i64 %1738
  %private.contiguous.load292 = load <8 x float>, ptr %private.contiguous.address291, align 4
  %1739 = select <8 x i1> %59, <8 x float> %private.contiguous.load292, <8 x float> zeroinitializer
  %.spill.load293 = load float, ptr %.spill37, align 4
  %.splatinsert294 = insertelement <8 x float> poison, float %.spill.load293, i64 0
  %.splat295 = shufflevector <8 x float> %.splatinsert294, <8 x float> poison, <8 x i32> zeroinitializer
  %1740 = fdiv <8 x float> %1739, %.splat295
  %tile_snapshot.spill.load296 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1741 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load296, 0
  %1742 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load296, 1
  %.state297 = load <8 x i64>, ptr %.slot41, align 64
  %1743 = mul <8 x i64> %.state297, splat (i64 32)
  %1744 = add <8 x i64> %1742, %1743
  %1745 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1741, 0
  %1746 = insertvalue { <8 x ptr>, <8 x i64> } %1745, <8 x i64> %1744, 1
  %1747 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %1746, 1
  %1749 = extractelement <8 x ptr> %1747, i32 0
  %1750 = extractelement <8 x i64> %1748, i32 0
  %1751 = sub i64 %1750, 0
  %1752 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %1753 = select i1 %1752, i64 %1751, i64 0
  %private.contiguous.address298 = getelementptr i8, ptr %1749, i64 %1753
  %private.contiguous.load299 = load <8 x float>, ptr %private.contiguous.address298, align 4
  %1754 = select <8 x i1> %59, <8 x float> %private.contiguous.load299, <8 x float> zeroinitializer
  %1755 = fmul <8 x float> %1740, %1754
  %tile_snapshot.spill.load300 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1756 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load300, 0
  %1757 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load300, 1
  %.state301 = load <8 x i64>, ptr %.slot41, align 64
  %1758 = mul <8 x i64> %.state301, splat (i64 32)
  %1759 = add <8 x i64> %1757, %1758
  %1760 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1756, 0
  %1761 = insertvalue { <8 x ptr>, <8 x i64> } %1760, <8 x i64> %1759, 1
  %1762 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1763 = extractvalue { <8 x ptr>, <8 x i64> } %1761, 1
  %1764 = extractelement <8 x ptr> %1762, i32 0
  %1765 = extractelement <8 x i64> %1763, i32 0
  %1766 = sub i64 %1765, 0
  %1767 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %59)
  %1768 = select i1 %1767, i64 %1766, i64 0
  %private.contiguous.address302 = getelementptr i8, ptr %1764, i64 %1768
  %private.contiguous.load303 = load <8 x float>, ptr %private.contiguous.address302, align 4
  %1769 = select <8 x i1> %59, <8 x float> %private.contiguous.load303, <8 x float> zeroinitializer
  %1770 = fadd <8 x float> %1755, %1769
  %1771 = extractvalue { ptr, i64 } %35, 0
  %1772 = extractelement <8 x i64> %1725, i32 0
  %1773 = sub i64 %1772, 0
  %1774 = mul i64 %1773, 4
  %buffer.contiguous.address304 = getelementptr i8, ptr %1771, i64 %1774
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1770, ptr align 1 %buffer.contiguous.address304, <8 x i1> %59)
  %.state305 = load <8 x i64>, ptr %.slot41, align 64
  %1775 = add <8 x i64> %.state305, splat (i64 1)
  %1776 = load <8 x i64>, ptr %.slot41, align 64
  %1777 = select <8 x i1> %59, <8 x i64> %1775, <8 x i64> %1776
  store <8 x i64> %1777, ptr %.slot41, align 64
  br label %direct.schedule.38

direct.schedule.40:                               ; preds = %direct.false285
  %.spill.load306 = load <8 x i1>, ptr %.spill14, align 1
  %1778 = and <8 x i1> %59, %.spill.load306
  %1779 = xor <8 x i1> %.spill.load306, splat (i1 true)
  %1780 = and <8 x i1> %59, %1779
  %1781 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1778)
  %1782 = bitcast <8 x i1> %1778 to i8
  %1783 = call i8 @llvm.cttz.i8(i8 %1782, i1 false)
  %1784 = zext i8 %1783 to i32
  %1785 = select i1 %1781, i32 %1784, i32 0
  %.spill.load307 = load <8 x i64>, ptr %.spill, align 64
  %1786 = add <8 x i64> splat (i64 4096), %.spill.load307
  %.spill.load308 = load <8 x i64>, ptr %.spill13, align 64
  %1787 = add <8 x i64> %.spill.load308, zeroinitializer
  %1788 = add <8 x i64> zeroinitializer, %1787
  %1789 = add <8 x i64> zeroinitializer, %1786
  %1790 = mul <8 x i64> %1788, splat (i64 4097)
  %1791 = add <8 x i64> %1790, %1789
  %tile_snapshot.spill.load309 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill26, align 64
  %1792 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load309, 0
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load309, 1
  %1794 = add <8 x i64> %1793, splat (i64 16384)
  %1795 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1792, 0
  %1796 = insertvalue { <8 x ptr>, <8 x i64> } %1795, <8 x i64> %1794, 1
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1798 = extractvalue { <8 x ptr>, <8 x i64> } %1796, 1
  %1799 = extractelement <8 x ptr> %1797, i32 0
  %1800 = extractelement <8 x i64> %1798, i32 %1785
  %1801 = zext i32 %1785 to i64
  %1802 = mul i64 %1801, 4
  %1803 = sub i64 %1800, %1802
  %1804 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1778)
  %1805 = select i1 %1804, i64 %1803, i64 0
  %private.contiguous.address310 = getelementptr i8, ptr %1799, i64 %1805
  %private.contiguous.load311 = load <8 x float>, ptr %private.contiguous.address310, align 4
  %1806 = select <8 x i1> %1778, <8 x float> %private.contiguous.load311, <8 x float> zeroinitializer
  %.spill.load312 = load float, ptr %.spill37, align 4
  %.splatinsert313 = insertelement <8 x float> poison, float %.spill.load312, i64 0
  %.splat314 = shufflevector <8 x float> %.splatinsert313, <8 x float> poison, <8 x i32> zeroinitializer
  %1807 = fdiv <8 x float> %1806, %.splat314
  %tile_snapshot.spill.load315 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %1808 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 0
  %1809 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 1
  %1810 = add <8 x i64> %1809, splat (i64 16384)
  %1811 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1808, 0
  %1812 = insertvalue { <8 x ptr>, <8 x i64> } %1811, <8 x i64> %1810, 1
  %1813 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %1814 = extractvalue { <8 x ptr>, <8 x i64> } %1812, 1
  %1815 = extractelement <8 x ptr> %1813, i32 0
  %1816 = extractelement <8 x i64> %1814, i32 %1785
  %1817 = zext i32 %1785 to i64
  %1818 = mul i64 %1817, 4
  %1819 = sub i64 %1816, %1818
  %1820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1778)
  %1821 = select i1 %1820, i64 %1819, i64 0
  %private.contiguous.address316 = getelementptr i8, ptr %1815, i64 %1821
  %private.contiguous.load317 = load <8 x float>, ptr %private.contiguous.address316, align 4
  %1822 = select <8 x i1> %1778, <8 x float> %private.contiguous.load317, <8 x float> zeroinitializer
  %1823 = fmul <8 x float> %1807, %1822
  %tile_snapshot.spill.load318 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1824 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load318, 0
  %1825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load318, 1
  %1826 = add <8 x i64> %1825, splat (i64 16384)
  %1827 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1824, 0
  %1828 = insertvalue { <8 x ptr>, <8 x i64> } %1827, <8 x i64> %1826, 1
  %1829 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %1830 = extractvalue { <8 x ptr>, <8 x i64> } %1828, 1
  %1831 = extractelement <8 x ptr> %1829, i32 0
  %1832 = extractelement <8 x i64> %1830, i32 %1785
  %1833 = zext i32 %1785 to i64
  %1834 = mul i64 %1833, 4
  %1835 = sub i64 %1832, %1834
  %1836 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1778)
  %1837 = select i1 %1836, i64 %1835, i64 0
  %private.contiguous.address319 = getelementptr i8, ptr %1831, i64 %1837
  %private.contiguous.load320 = load <8 x float>, ptr %private.contiguous.address319, align 4
  %1838 = select <8 x i1> %1778, <8 x float> %private.contiguous.load320, <8 x float> zeroinitializer
  %1839 = fadd <8 x float> %1823, %1838
  %1840 = extractvalue { ptr, i64 } %35, 0
  %1841 = extractelement <8 x i64> %1791, i32 %1785
  %1842 = zext i32 %1785 to i64
  %1843 = sub i64 %1841, %1842
  %1844 = mul i64 %1843, 4
  %buffer.contiguous.address321 = getelementptr i8, ptr %1840, i64 %1844
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1839, ptr align 1 %buffer.contiguous.address321, <8 x i1> %1778)
  %1845 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1780)
  %1846 = bitcast <8 x i1> %1780 to i8
  %1847 = call i8 @llvm.cttz.i8(i8 %1846, i1 false)
  %1848 = zext i8 %1847 to i32
  %1849 = select i1 %1845, i32 %1848, i32 0
  br label %direct.schedule.31

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true80:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false81:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true115:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false116:                                  ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true152:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false153:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true189:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false190:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true214:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false215:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.32

direct.true217:                                   ; preds = %direct.schedule.27
  br label %direct.schedule.28

direct.false218:                                  ; preds = %direct.schedule.27
  br label %direct.schedule.29

direct.true259:                                   ; preds = %direct.schedule.33
  br label %direct.schedule.34

direct.false260:                                  ; preds = %direct.schedule.33
  br label %direct.schedule.35

direct.true284:                                   ; preds = %direct.schedule.38
  br label %direct.schedule.39

direct.false285:                                  ; preds = %direct.schedule.38
  br label %direct.schedule.40
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #3

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	8192                            ; 0x2000
	.quad	8196                            ; 0x2004
lCPI0_8:
	.quad	8208                            ; 0x2010
	.quad	8212                            ; 0x2014
lCPI0_9:
	.quad	8200                            ; 0x2008
	.quad	8204                            ; 0x200c
lCPI0_10:
	.quad	8216                            ; 0x2018
	.quad	8220                            ; 0x201c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB0_165
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #656
	mov	x9, #0                          ; =0x0
	ldr	x15, [x0]
	ldr	x13, [x0, #16]
	ldr	x10, [x0, #32]
	ldr	x8, [x0, #48]
	ldr	w11, [x1]
	ldr	w12, [x1, #36]
	add	w11, w12, w11, lsl #5
	lsr	w11, w11, #3
	dup.4s	v2, w11
	and.16b	v4, v1, v2
	and.16b	v2, v0, v2
	ushll2.2d	v29, v2, #0
	ushll2.2d	v31, v4, #0
	ushll.2d	v30, v2, #0
	ushll.2d	v8, v4, #0
	fmov	x14, d8
	mov	w11, #16392                     ; =0x4008
	umaddl	x11, w14, w11, x15
Lloh4:
	adrp	x12, lCPI0_2@PAGE
Lloh5:
	ldr	q2, [x12, lCPI0_2@PAGEOFF]
	and.16b	v2, v3, v2
	addv.8h	h2, v2
	fmov	w12, s2
	add	x16, sp, #6, lsl #12            ; =24576
	add	x16, x16, #624
	b	LBB0_3
LBB0_2:                                 ; %else21
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x16, x9
	stp	q4, q5, [x17]
	add	x9, x9, #32
	cmp	x9, #2, lsl #12                 ; =8192
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x11, x9
	add	x1, x16, x9
	ldr	q4, [x1]
	tbnz	w12, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w0, w12, #0xff
	tbnz	w0, #1, LBB0_12
LBB0_5:                                 ; %else3
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #2, LBB0_13
LBB0_6:                                 ; %else6
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #3, LBB0_14
LBB0_7:                                 ; %else9
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q5, [x1, #16]
	tbnz	w0, #4, LBB0_15
LBB0_8:                                 ; %else12
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #5, LBB0_16
LBB0_9:                                 ; %else15
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #6, LBB0_17
LBB0_10:                                ; %else18
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w0, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v4 }[0], [x17]
	and	w0, w12, #0xff
	tbz	w0, #1, LBB0_5
LBB0_12:                                ; %cond.load2
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #4
	ld1.s	{ v4 }[1], [x2]
	tbz	w0, #2, LBB0_6
LBB0_13:                                ; %cond.load5
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #8
	ld1.s	{ v4 }[2], [x2]
	tbz	w0, #3, LBB0_7
LBB0_14:                                ; %cond.load8
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x2, x17, #12
	ld1.s	{ v4 }[3], [x2]
	ldr	q5, [x1, #16]
	tbz	w0, #4, LBB0_8
LBB0_15:                                ; %cond.load11
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #16
	ld1.s	{ v5 }[0], [x1]
	tbz	w0, #5, LBB0_9
LBB0_16:                                ; %cond.load14
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #20
	ld1.s	{ v5 }[1], [x1]
	tbz	w0, #6, LBB0_10
LBB0_17:                                ; %cond.load17
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #24
	ld1.s	{ v5 }[2], [x1]
	tbz	w0, #7, LBB0_2
LBB0_18:                                ; %cond.load20
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x17, #28
	ld1.s	{ v5 }[3], [x17]
	b	LBB0_2
LBB0_19:                                ; %direct.false
	xtn.8b	v4, v3
	sshll.2d	v5, v1, #0
	sshll.2d	v16, v0, #0
	sshll2.2d	v17, v1, #0
	sshll2.2d	v18, v0, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q3, [x9, lCPI0_6@PAGEOFF]
	and.16b	v19, v5, v3
	movi.2d	v6, #0000000000000000
	movi.8b	v3, #1
	and.8b	v3, v4, v3
	umov.b	w11, v3[0]
	movi.2d	v20, #0000000000000000
	movi.2d	v3, #0000000000000000
	mov.b	v3[0], v4[0]
	umaxv.8b	b7, v3
	fmov	w17, s7
	rbit	w9, w11
	clz	w9, w9
	tst	w17, #0x1
	csel	w9, w9, wzr, ne
	mov	w12, #2048                      ; =0x800
	dup.2d	v23, x12
	mov	w12, #4098                      ; =0x1002
	dup.2s	v7, w12
	orr.16b	v9, v19, v23
	xtn.2s	v24, v8
	mov.16b	v21, v9
	umlal.2d	v21, v24, v7
	mov.b	v20[0], v4[0]
	ushll.2d	v4, v20, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	str	q21, [sp, #48]                  ; 16-byte Spill
	and.16b	v4, v4, v21
	stp	q6, q6, [sp, #416]
	stp	q4, q6, [sp, #384]
	ubfiz	x12, x9, #3, #3
	add	x16, sp, #384
	ldr	x16, [x16, x12]
	sub	x16, x16, x9
	add	x16, x15, x16, lsl #2
	mov	w0, #8192                       ; =0x2000
	dup.2d	v4, x0
Lloh8:
	adrp	x0, lCPI0_7@PAGE
Lloh9:
	ldr	q6, [x0, lCPI0_7@PAGEOFF]
	bsl.16b	v5, v6, v4
Lloh10:
	adrp	x0, lCPI0_8@PAGE
Lloh11:
	ldr	q6, [x0, lCPI0_8@PAGEOFF]
	bif.16b	v6, v4, v16
Lloh12:
	adrp	x0, lCPI0_9@PAGE
Lloh13:
	ldr	q20, [x0, lCPI0_9@PAGEOFF]
	bif.16b	v20, v4, v17
Lloh14:
	adrp	x0, lCPI0_10@PAGE
Lloh15:
	ldr	q21, [x0, lCPI0_10@PAGEOFF]
	bit.16b	v4, v21, v18
	stp	q6, q4, [sp, #480]
	stp	q5, q20, [sp, #448]
	add	x0, sp, #448
	ldr	x12, [x0, x12]
	sub	x12, x12, w9, uxtw #2
	tst	w11, #0x1
	csel	x12, xzr, x12, eq
	add	x0, sp, #6, lsl #12             ; =24576
	add	x0, x0, #624
	add	x0, x0, x12
	ldr	q4, [x0]
	tbnz	w17, #0, LBB0_166
; %bb.20:                               ; %else25
	tbnz	w11, #1, LBB0_167
LBB0_21:                                ; %else28
	tbnz	w11, #2, LBB0_168
LBB0_22:                                ; %else31
	tbnz	w11, #3, LBB0_169
LBB0_23:                                ; %else34
	adrp	x17, lCPI0_3@PAGE
	adrp	x1, lCPI0_4@PAGE
	adrp	x2, lCPI0_5@PAGE
	ldr	q5, [x0, #16]
	tbnz	w11, #4, LBB0_170
LBB0_24:                                ; %else37
	ldr	q6, [x17, lCPI0_3@PAGEOFF]
	ldr	q21, [x1, lCPI0_4@PAGEOFF]
	ldr	q22, [x2, lCPI0_5@PAGEOFF]
	tbnz	w11, #5, LBB0_171
LBB0_25:                                ; %else40
	and.16b	v20, v18, v6
	and.16b	v21, v17, v21
	and.16b	v22, v16, v22
	tbz	w11, #6, LBB0_27
LBB0_26:                                ; %cond.load42
	add	x17, x16, #24
	ld1.s	{ v5 }[2], [x17]
LBB0_27:                                ; %else43
	orr.16b	v11, v22, v23
	orr.16b	v10, v21, v23
	orr.16b	v12, v20, v23
	xtn.2s	v16, v31
	xtn.2s	v6, v30
	xtn.2s	v17, v29
	umull.2d	v26, v24, v7
	tbz	w11, #7, LBB0_29
; %bb.28:                               ; %cond.load45
	add	x11, x16, #28
	ld1.s	{ v5 }[3], [x11]
LBB0_29:                                ; %else46
	mov	x2, #0                          ; =0x0
	umull.2d	v27, v16, v7
	umull.2d	v28, v6, v7
	umull.2d	v13, v17, v7
	mov.16b	v18, v12
	umlal.2d	v18, v17, v7
	mov.16b	v17, v10
	umlal.2d	v17, v16, v7
	stp	q17, q18, [sp, #16]             ; 32-byte Folded Spill
	mov.16b	v16, v11
	umlal.2d	v16, v6, v7
	str	q16, [sp]                       ; 16-byte Spill
	add	x11, sp, #6, lsl #12            ; =24576
	add	x11, x11, #624
	add	x11, x11, x12
	stp	q4, q5, [x11]
	fmov	x11, d26
	ushll2.2d	v6, v0, #0
	mov	w16, #1                         ; =0x1
	dup.2d	v18, x16
	and.16b	v7, v6, v18
	ushll2.2d	v6, v1, #0
	and.16b	v16, v6, v18
	ushll.2d	v6, v0, #0
	and.16b	v17, v6, v18
	ushll.2d	v6, v1, #0
	and.16b	v18, v6, v18
	lsl	x11, x11, #2
	add	x16, x15, x11
	movi.2d	v14, #0000000000000000
	fmov	w17, s2
	mov	w0, #8196                       ; =0x2004
	add	x1, sp, #4, lsl #12             ; =16384
	add	x1, x1, #592
	movi.2d	v15, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	b	LBB0_31
LBB0_30:                                ; %else71
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x2, x1, x2
	stp	q25, q6, [x2]
	add.2d	v15, v15, v16
	add.2d	v23, v23, v17
	add.2d	v24, v24, v7
	add.2d	v14, v14, v18
	fmov	x2, d14
	cmp	x2, #256
	b.ge	LBB0_47
LBB0_31:                                ; %direct.true47
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x2, x2, #5
	add	x3, x16, x2
	add	x3, x3, x0
	add	x5, x1, x2
	ldr	q25, [x5]
	tbnz	w17, #0, LBB0_39
; %bb.32:                               ; %else50
                                        ;   in Loop: Header=BB0_31 Depth=1
	and	w4, w17, #0xff
	tbnz	w4, #1, LBB0_40
LBB0_33:                                ; %else53
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w4, #2, LBB0_41
LBB0_34:                                ; %else56
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w4, #3, LBB0_42
LBB0_35:                                ; %else59
                                        ;   in Loop: Header=BB0_31 Depth=1
	ldr	q6, [x5, #16]
	tbnz	w4, #4, LBB0_43
LBB0_36:                                ; %else62
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w4, #5, LBB0_44
LBB0_37:                                ; %else65
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w4, #6, LBB0_45
LBB0_38:                                ; %else68
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbz	w4, #7, LBB0_30
	b	LBB0_46
LBB0_39:                                ; %cond.load49
                                        ;   in Loop: Header=BB0_31 Depth=1
	ld1.s	{ v25 }[0], [x3]
	and	w4, w17, #0xff
	tbz	w4, #1, LBB0_33
LBB0_40:                                ; %cond.load52
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x6, x3, #4
	ld1.s	{ v25 }[1], [x6]
	tbz	w4, #2, LBB0_34
LBB0_41:                                ; %cond.load55
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x6, x3, #8
	ld1.s	{ v25 }[2], [x6]
	tbz	w4, #3, LBB0_35
LBB0_42:                                ; %cond.load58
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x6, x3, #12
	ld1.s	{ v25 }[3], [x6]
	ldr	q6, [x5, #16]
	tbz	w4, #4, LBB0_36
LBB0_43:                                ; %cond.load61
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x5, x3, #16
	ld1.s	{ v6 }[0], [x5]
	tbz	w4, #5, LBB0_37
LBB0_44:                                ; %cond.load64
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x5, x3, #20
	ld1.s	{ v6 }[1], [x5]
	tbz	w4, #6, LBB0_38
LBB0_45:                                ; %cond.load67
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x5, x3, #24
	ld1.s	{ v6 }[2], [x5]
	tbz	w4, #7, LBB0_30
LBB0_46:                                ; %cond.load70
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x3, x3, #28
	ld1.s	{ v6 }[3], [x3]
	b	LBB0_30
LBB0_47:                                ; %direct.false48
	add.2d	v6, v19, v26
	add.2d	v21, v21, v27
	add.2d	v22, v22, v28
	add.2d	v19, v20, v13
	mov	w16, #4097                      ; =0x1001
	dup.2d	v23, x16
	add.2d	v19, v19, v23
	add.2d	v20, v22, v23
	add.2d	v21, v21, v23
	add.2d	v22, v6, v23
	mov	b6, v3[0]
	mov.b	v6[4], v3[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v6, v6, v22
	mov	b23, v3[2]
	mov.b	v23[4], v3[3]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	and.16b	v23, v23, v21
	mov	b24, v3[4]
	mov.b	v24[4], v3[5]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	and.16b	v24, v24, v20
	mov	b25, v3[6]
	mov.b	v25[4], v3[7]
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	and.16b	v25, v25, v19
Lloh16:
	adrp	x16, lCPI0_11@PAGE
Lloh17:
	ldr	d26, [x16, lCPI0_11@PAGEOFF]
	shl.8b	v27, v3, #7
	cmlt.8b	v27, v27, #0
	and.8b	v26, v27, v26
	addv.8b	b26, v26
	stp	q24, q25, [sp, #336]
	stp	q6, q23, [sp, #304]
	and	x16, x9, #0x7
	add	x17, sp, #304
	ldr	x17, [x17, x16, lsl #3]
	fmov	w16, s26
	sub	x17, x17, x9
	add	x15, x15, x17, lsl #2
	add	x17, sp, #4, lsl #12            ; =16384
	add	x17, x17, #592
	add	x17, x17, x12
	ldr	q27, [x17]
	tbnz	w16, #0, LBB0_172
; %bb.48:                               ; %else75
	tbnz	w16, #1, LBB0_173
LBB0_49:                                ; %else78
	tbnz	w16, #2, LBB0_174
LBB0_50:                                ; %else81
	tbnz	w16, #3, LBB0_175
LBB0_51:                                ; %else84
	ldr	q28, [x17, #16]
	tbnz	w16, #4, LBB0_176
LBB0_52:                                ; %else87
	tbnz	w16, #5, LBB0_177
LBB0_53:                                ; %else90
	tbnz	w16, #6, LBB0_178
LBB0_54:                                ; %else93
	tbz	w16, #7, LBB0_56
LBB0_55:                                ; %cond.load95
	add	x15, x15, #28
	ld1.s	{ v28 }[3], [x15]
LBB0_56:                                ; %else96
	mov	x17, #0                         ; =0x0
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #592
	add	x15, x15, x12
	stp	q27, q28, [x15]
	mov	w15, #8196                      ; =0x2004
	umaddl	x14, w14, w15, x13
	movi.2d	v13, #0000000000000000
	fmov	w15, s2
	add	x16, sp, #2, lsl #12            ; =8192
	add	x16, x16, #560
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v14, #0000000000000000
	b	LBB0_58
LBB0_57:                                ; %else121
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x17, x16, x17
	stp	q25, q6, [x17]
	add.2d	v23, v23, v16
	add.2d	v24, v24, v17
	add.2d	v14, v14, v7
	add.2d	v13, v13, v18
	fmov	x17, d13
	cmp	x17, #256
	b.ge	LBB0_74
LBB0_58:                                ; %direct.true68
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x17, x17, #5
	add	x0, x14, x17
	add	x2, x16, x17
	ldr	q25, [x2]
	tbnz	w15, #0, LBB0_66
; %bb.59:                               ; %else100
                                        ;   in Loop: Header=BB0_58 Depth=1
	and	w1, w15, #0xff
	tbnz	w1, #1, LBB0_67
LBB0_60:                                ; %else103
                                        ;   in Loop: Header=BB0_58 Depth=1
	tbnz	w1, #2, LBB0_68
LBB0_61:                                ; %else106
                                        ;   in Loop: Header=BB0_58 Depth=1
	tbnz	w1, #3, LBB0_69
LBB0_62:                                ; %else109
                                        ;   in Loop: Header=BB0_58 Depth=1
	ldr	q6, [x2, #16]
	tbnz	w1, #4, LBB0_70
LBB0_63:                                ; %else112
                                        ;   in Loop: Header=BB0_58 Depth=1
	tbnz	w1, #5, LBB0_71
LBB0_64:                                ; %else115
                                        ;   in Loop: Header=BB0_58 Depth=1
	tbnz	w1, #6, LBB0_72
LBB0_65:                                ; %else118
                                        ;   in Loop: Header=BB0_58 Depth=1
	tbz	w1, #7, LBB0_57
	b	LBB0_73
LBB0_66:                                ; %cond.load99
                                        ;   in Loop: Header=BB0_58 Depth=1
	ld1.s	{ v25 }[0], [x0]
	and	w1, w15, #0xff
	tbz	w1, #1, LBB0_60
LBB0_67:                                ; %cond.load102
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x3, x0, #4
	ld1.s	{ v25 }[1], [x3]
	tbz	w1, #2, LBB0_61
LBB0_68:                                ; %cond.load105
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x3, x0, #8
	ld1.s	{ v25 }[2], [x3]
	tbz	w1, #3, LBB0_62
LBB0_69:                                ; %cond.load108
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x3, x0, #12
	ld1.s	{ v25 }[3], [x3]
	ldr	q6, [x2, #16]
	tbz	w1, #4, LBB0_63
LBB0_70:                                ; %cond.load111
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x2, x0, #16
	ld1.s	{ v6 }[0], [x2]
	tbz	w1, #5, LBB0_64
LBB0_71:                                ; %cond.load114
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x2, x0, #20
	ld1.s	{ v6 }[1], [x2]
	tbz	w1, #6, LBB0_65
LBB0_72:                                ; %cond.load117
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x2, x0, #24
	ld1.s	{ v6 }[2], [x2]
	tbz	w1, #7, LBB0_57
LBB0_73:                                ; %cond.load120
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x0, x0, #28
	ld1.s	{ v6 }[3], [x0]
	b	LBB0_57
LBB0_74:                                ; %direct.false69
	fmov	x14, d8
	add	x14, x14, x14, lsl #11
	fmov	d13, x14
	mov.d	x14, v8[1]
	add	x14, x14, x14, lsl #11
	mov.d	v13[1], x14
	fmov	x14, d31
	add	x14, x14, x14, lsl #11
	fmov	d6, x14
	mov.d	x14, v31[1]
	add	x14, x14, x14, lsl #11
	mov.d	v6[1], x14
	fmov	x14, d30
	add	x14, x14, x14, lsl #11
	mov.d	x15, v30[1]
	fmov	d23, x14
	add	x14, x15, x15, lsl #11
	mov.d	v23[1], x14
	fmov	x14, d29
	add	x14, x14, x14, lsl #11
	fmov	d24, x14
	mov.d	x14, v29[1]
	add	x14, x14, x14, lsl #11
	mov.d	v24[1], x14
	add.2d	v24, v24, v12
	add.2d	v23, v23, v11
	add.2d	v6, v6, v10
	add.2d	v25, v13, v9
	mov	b29, v3[0]
	mov.b	v29[4], v3[1]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v25, v29, v25
	mov	b29, v3[2]
	mov.b	v29[4], v3[3]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v6, v29, v6
	mov	b29, v3[4]
	mov.b	v29[4], v3[5]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v23, v29, v23
	mov	b29, v3[6]
	mov.b	v29[4], v3[7]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	and.16b	v24, v29, v24
	fmov	w15, s26
	stp	q23, q24, [sp, #256]
	stp	q25, q6, [sp, #224]
	and	x14, x9, #0x7
	add	x16, sp, #224
	ldr	x14, [x16, x14, lsl #3]
	sub	x14, x14, x9
	lsl	x14, x14, #2
	add	x13, x13, x14
	add	x16, sp, #2, lsl #12            ; =8192
	add	x16, x16, #560
	add	x16, x16, x12
	ldr	q29, [x16]
	tbnz	w15, #0, LBB0_179
; %bb.75:                               ; %else125
	tbnz	w15, #1, LBB0_180
LBB0_76:                                ; %else128
	tbnz	w15, #2, LBB0_181
LBB0_77:                                ; %else131
	tbnz	w15, #3, LBB0_182
LBB0_78:                                ; %else134
	ldr	q30, [x16, #16]
	tbnz	w15, #4, LBB0_183
LBB0_79:                                ; %else137
	tbnz	w15, #5, LBB0_184
LBB0_80:                                ; %else140
	tbnz	w15, #6, LBB0_185
LBB0_81:                                ; %else143
	tbz	w15, #7, LBB0_83
LBB0_82:                                ; %cond.load145
	add	x13, x13, #28
	ld1.s	{ v30 }[3], [x13]
LBB0_83:                                ; %else146
	mov	x17, #0                         ; =0x0
	add	x13, sp, #2, lsl #12            ; =8192
	add	x13, x13, #560
	add	x13, x13, x12
	stp	q29, q30, [x13]
	fmov	x13, d13
	add	x13, x10, x13, lsl #2
	movi.2d	v31, #0000000000000000
	fmov	w15, s2
	add	x16, sp, #528
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v8, #0000000000000000
	b	LBB0_85
LBB0_84:                                ; %else171
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x17, x16, x17
	stp	q25, q6, [x17]
	add.2d	v23, v23, v16
	add.2d	v24, v24, v17
	add.2d	v8, v8, v7
	add.2d	v31, v31, v18
	fmov	x17, d31
	cmp	x17, #256
	b.ge	LBB0_101
LBB0_85:                                ; %direct.true89
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x17, x17, #5
	add	x0, x13, x17
	add	x2, x16, x17
	ldr	q25, [x2]
	tbnz	w15, #0, LBB0_93
; %bb.86:                               ; %else150
                                        ;   in Loop: Header=BB0_85 Depth=1
	and	w1, w15, #0xff
	tbnz	w1, #1, LBB0_94
LBB0_87:                                ; %else153
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w1, #2, LBB0_95
LBB0_88:                                ; %else156
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w1, #3, LBB0_96
LBB0_89:                                ; %else159
                                        ;   in Loop: Header=BB0_85 Depth=1
	ldr	q6, [x2, #16]
	tbnz	w1, #4, LBB0_97
LBB0_90:                                ; %else162
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w1, #5, LBB0_98
LBB0_91:                                ; %else165
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbnz	w1, #6, LBB0_99
LBB0_92:                                ; %else168
                                        ;   in Loop: Header=BB0_85 Depth=1
	tbz	w1, #7, LBB0_84
	b	LBB0_100
LBB0_93:                                ; %cond.load149
                                        ;   in Loop: Header=BB0_85 Depth=1
	ld1.s	{ v25 }[0], [x0]
	and	w1, w15, #0xff
	tbz	w1, #1, LBB0_87
LBB0_94:                                ; %cond.load152
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x3, x0, #4
	ld1.s	{ v25 }[1], [x3]
	tbz	w1, #2, LBB0_88
LBB0_95:                                ; %cond.load155
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x3, x0, #8
	ld1.s	{ v25 }[2], [x3]
	tbz	w1, #3, LBB0_89
LBB0_96:                                ; %cond.load158
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x3, x0, #12
	ld1.s	{ v25 }[3], [x3]
	ldr	q6, [x2, #16]
	tbz	w1, #4, LBB0_90
LBB0_97:                                ; %cond.load161
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x2, x0, #16
	ld1.s	{ v6 }[0], [x2]
	tbz	w1, #5, LBB0_91
LBB0_98:                                ; %cond.load164
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x2, x0, #20
	ld1.s	{ v6 }[1], [x2]
	tbz	w1, #6, LBB0_92
LBB0_99:                                ; %cond.load167
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x2, x0, #24
	ld1.s	{ v6 }[2], [x2]
	tbz	w1, #7, LBB0_84
LBB0_100:                               ; %cond.load170
                                        ;   in Loop: Header=BB0_85 Depth=1
	add	x0, x0, #28
	ld1.s	{ v6 }[3], [x0]
	b	LBB0_84
LBB0_101:                               ; %direct.false90
	add	x10, x10, x14
	add	x13, sp, #528
	add	x14, x13, x12
	ldr	q31, [x14]
	fmov	w13, s26
	tbnz	w13, #0, LBB0_186
; %bb.102:                              ; %else175
	tbnz	w13, #1, LBB0_187
LBB0_103:                               ; %else178
	tbnz	w13, #2, LBB0_188
LBB0_104:                               ; %else181
	tbnz	w13, #3, LBB0_189
LBB0_105:                               ; %else184
	ldr	q8, [x14, #16]
	tbnz	w13, #4, LBB0_190
LBB0_106:                               ; %else187
	tbnz	w13, #5, LBB0_191
LBB0_107:                               ; %else190
	tbnz	w13, #6, LBB0_192
LBB0_108:                               ; %else193
	tbz	w13, #7, LBB0_110
LBB0_109:                               ; %cond.load195
	add	x10, x10, #28
	ld1.s	{ v8 }[3], [x10]
LBB0_110:                               ; %else196
	mov	x17, #0                         ; =0x0
	add	x10, sp, #528
	add	x12, x10, x12
	stp	q31, q8, [x12]
	add	x12, x8, x11
	movi.2d	v23, #0000000000000000
	fmov	w13, s2
	add	x14, sp, #6, lsl #12            ; =24576
	add	x14, x14, #624
	add	x15, sp, #2, lsl #12            ; =8192
	add	x15, x15, #560
	add	x16, sp, #4, lsl #12            ; =16384
	add	x16, x16, #592
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v9, #0000000000000000
	b	LBB0_112
LBB0_111:                               ; %else213
                                        ;   in Loop: Header=BB0_112 Depth=1
	add.2d	v24, v24, v16
	add.2d	v25, v25, v17
	add.2d	v9, v9, v7
	add.2d	v23, v23, v18
	fmov	x17, d23
	cmp	x17, #256
	b.ge	LBB0_128
LBB0_112:                               ; %direct.true110
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x17, x17, #5
	add	x1, x14, x17
	ldr	q6, [x1]
	add	x2, x15, x17
	ldr	q10, [x2]
	fmul.4s	v6, v6, v10
	add	x3, x16, x17
	ldr	q10, [x3]
	add	x4, x10, x17
	ldr	q11, [x4]
	fmul.4s	v10, v10, v11
	fsub.4s	v6, v6, v10
	and.16b	v6, v1, v6
	add	x17, x12, x17
	tbnz	w13, #0, LBB0_121
; %bb.113:                              ; %else199
                                        ;   in Loop: Header=BB0_112 Depth=1
	and	w0, w13, #0xff
	tbnz	w0, #1, LBB0_122
LBB0_114:                               ; %else201
                                        ;   in Loop: Header=BB0_112 Depth=1
	tbnz	w0, #2, LBB0_123
LBB0_115:                               ; %else203
                                        ;   in Loop: Header=BB0_112 Depth=1
	tbz	w0, #3, LBB0_117
LBB0_116:                               ; %cond.store204
                                        ;   in Loop: Header=BB0_112 Depth=1
	add	x5, x17, #12
	st1.s	{ v6 }[3], [x5]
LBB0_117:                               ; %else205
                                        ;   in Loop: Header=BB0_112 Depth=1
	ldr	q6, [x1, #16]
	ldr	q10, [x2, #16]
	fmul.4s	v6, v6, v10
	ldr	q10, [x3, #16]
	ldr	q11, [x4, #16]
	fmul.4s	v10, v10, v11
	fsub.4s	v6, v6, v10
	and.16b	v6, v0, v6
	tbnz	w0, #4, LBB0_124
; %bb.118:                              ; %else207
                                        ;   in Loop: Header=BB0_112 Depth=1
	tbnz	w0, #5, LBB0_125
LBB0_119:                               ; %else209
                                        ;   in Loop: Header=BB0_112 Depth=1
	tbnz	w0, #6, LBB0_126
LBB0_120:                               ; %else211
                                        ;   in Loop: Header=BB0_112 Depth=1
	tbz	w0, #7, LBB0_111
	b	LBB0_127
LBB0_121:                               ; %cond.store
                                        ;   in Loop: Header=BB0_112 Depth=1
	str	s6, [x17]
	and	w0, w13, #0xff
	tbz	w0, #1, LBB0_114
LBB0_122:                               ; %cond.store200
                                        ;   in Loop: Header=BB0_112 Depth=1
	add	x5, x17, #4
	st1.s	{ v6 }[1], [x5]
	tbz	w0, #2, LBB0_115
LBB0_123:                               ; %cond.store202
                                        ;   in Loop: Header=BB0_112 Depth=1
	add	x5, x17, #8
	st1.s	{ v6 }[2], [x5]
	tbnz	w0, #3, LBB0_116
	b	LBB0_117
LBB0_124:                               ; %cond.store206
                                        ;   in Loop: Header=BB0_112 Depth=1
	str	s6, [x17, #16]
	tbz	w0, #5, LBB0_119
LBB0_125:                               ; %cond.store208
                                        ;   in Loop: Header=BB0_112 Depth=1
	add	x1, x17, #20
	st1.s	{ v6 }[1], [x1]
	tbz	w0, #6, LBB0_120
LBB0_126:                               ; %cond.store210
                                        ;   in Loop: Header=BB0_112 Depth=1
	add	x1, x17, #24
	st1.s	{ v6 }[2], [x1]
	tbz	w0, #7, LBB0_111
LBB0_127:                               ; %cond.store212
                                        ;   in Loop: Header=BB0_112 Depth=1
	add	x17, x17, #28
	st1.s	{ v6 }[3], [x17]
	b	LBB0_111
LBB0_128:                               ; %direct.false111
	fmul.4s	v6, v4, v29
	fmul.4s	v23, v27, v31
	fsub.4s	v6, v6, v23
	zip2.8b	v23, v3, v0
	zip1.8b	v24, v3, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	and.16b	v6, v24, v6
	fmov	w10, s26
	ldr	q25, [sp, #48]                  ; 16-byte Reload
	ldr	q24, [sp, #16]                  ; 16-byte Reload
	stp	q25, q24, [sp, #144]
	ldr	q25, [sp]                       ; 16-byte Reload
	ldr	q24, [sp, #32]                  ; 16-byte Reload
	stp	q25, q24, [sp, #176]
	and	x12, x9, #0x7
	add	x13, sp, #144
	ldr	x12, [x13, x12, lsl #3]
	sub	x12, x12, x9
	add	x12, x8, x12, lsl #2
	tbnz	w10, #0, LBB0_193
; %bb.129:                              ; %else216
	ushll.4s	v24, v23, #0
	tbnz	w10, #1, LBB0_194
LBB0_130:                               ; %else218
	fmul.4s	v23, v5, v30
	fmul.4s	v25, v28, v8
	shl.4s	v24, v24, #31
	tbnz	w10, #2, LBB0_195
LBB0_131:                               ; %else220
	fsub.4s	v23, v23, v25
	cmlt.4s	v24, v24, #0
	tbnz	w10, #3, LBB0_196
LBB0_132:                               ; %else222
	and.16b	v6, v24, v23
	tbnz	w10, #4, LBB0_197
LBB0_133:                               ; %else224
	tbnz	w10, #5, LBB0_198
LBB0_134:                               ; %else226
	tbnz	w10, #6, LBB0_199
LBB0_135:                               ; %else228
	tbz	w10, #7, LBB0_137
LBB0_136:                               ; %cond.store229
	add	x10, x12, #28
	st1.s	{ v6 }[3], [x10]
LBB0_137:                               ; %else230
	mov	x17, #0                         ; =0x0
	add	x10, x8, x11
	movi.2d	v6, #0000000000000000
	fmov	w11, s2
	add	x12, sp, #6, lsl #12            ; =24576
	add	x12, x12, #624
	add	x13, sp, #528
	movi.2d	v2, #0000000000000000
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #592
	movi.2d	v23, #0000000000000000
	add	x15, sp, #2, lsl #12            ; =8192
	add	x15, x15, #560
	mov	w16, #8196                      ; =0x2004
	movi.2d	v24, #0000000000000000
	b	LBB0_139
LBB0_138:                               ; %else247
                                        ;   in Loop: Header=BB0_139 Depth=1
	add.2d	v2, v2, v16
	add.2d	v23, v23, v17
	add.2d	v24, v24, v7
	add.2d	v6, v6, v18
	fmov	x17, d6
	cmp	x17, #256
	b.ge	LBB0_155
LBB0_139:                               ; %direct.true149
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x17, x17, #5
	add	x1, x12, x17
	ldr	q25, [x1]
	add	x2, x13, x17
	ldr	q9, [x2]
	fmul.4s	v25, v25, v9
	add	x3, x14, x17
	ldr	q9, [x3]
	add	x4, x15, x17
	ldr	q10, [x4]
	fmul.4s	v9, v9, v10
	fadd.4s	v25, v25, v9
	and.16b	v25, v1, v25
	add	x17, x10, x17
	add	x17, x17, x16
	tbnz	w11, #0, LBB0_148
; %bb.140:                              ; %else233
                                        ;   in Loop: Header=BB0_139 Depth=1
	and	w0, w11, #0xff
	tbnz	w0, #1, LBB0_149
LBB0_141:                               ; %else235
                                        ;   in Loop: Header=BB0_139 Depth=1
	tbnz	w0, #2, LBB0_150
LBB0_142:                               ; %else237
                                        ;   in Loop: Header=BB0_139 Depth=1
	tbz	w0, #3, LBB0_144
LBB0_143:                               ; %cond.store238
                                        ;   in Loop: Header=BB0_139 Depth=1
	add	x5, x17, #12
	st1.s	{ v25 }[3], [x5]
LBB0_144:                               ; %else239
                                        ;   in Loop: Header=BB0_139 Depth=1
	ldr	q25, [x1, #16]
	ldr	q9, [x2, #16]
	fmul.4s	v25, v25, v9
	ldr	q9, [x3, #16]
	ldr	q10, [x4, #16]
	fmul.4s	v9, v9, v10
	fadd.4s	v25, v25, v9
	and.16b	v25, v0, v25
	tbnz	w0, #4, LBB0_151
; %bb.145:                              ; %else241
                                        ;   in Loop: Header=BB0_139 Depth=1
	tbnz	w0, #5, LBB0_152
LBB0_146:                               ; %else243
                                        ;   in Loop: Header=BB0_139 Depth=1
	tbnz	w0, #6, LBB0_153
LBB0_147:                               ; %else245
                                        ;   in Loop: Header=BB0_139 Depth=1
	tbz	w0, #7, LBB0_138
	b	LBB0_154
LBB0_148:                               ; %cond.store232
                                        ;   in Loop: Header=BB0_139 Depth=1
	str	s25, [x17]
	and	w0, w11, #0xff
	tbz	w0, #1, LBB0_141
LBB0_149:                               ; %cond.store234
                                        ;   in Loop: Header=BB0_139 Depth=1
	add	x5, x17, #4
	st1.s	{ v25 }[1], [x5]
	tbz	w0, #2, LBB0_142
LBB0_150:                               ; %cond.store236
                                        ;   in Loop: Header=BB0_139 Depth=1
	add	x5, x17, #8
	st1.s	{ v25 }[2], [x5]
	tbnz	w0, #3, LBB0_143
	b	LBB0_144
LBB0_151:                               ; %cond.store240
                                        ;   in Loop: Header=BB0_139 Depth=1
	str	s25, [x17, #16]
	tbz	w0, #5, LBB0_146
LBB0_152:                               ; %cond.store242
                                        ;   in Loop: Header=BB0_139 Depth=1
	add	x1, x17, #20
	st1.s	{ v25 }[1], [x1]
	tbz	w0, #6, LBB0_147
LBB0_153:                               ; %cond.store244
                                        ;   in Loop: Header=BB0_139 Depth=1
	add	x1, x17, #24
	st1.s	{ v25 }[2], [x1]
	tbz	w0, #7, LBB0_138
LBB0_154:                               ; %cond.store246
                                        ;   in Loop: Header=BB0_139 Depth=1
	add	x17, x17, #28
	st1.s	{ v25 }[3], [x17]
	b	LBB0_138
LBB0_155:                               ; %direct.false150
	fmul.4s	v0, v4, v31
	fmul.4s	v1, v27, v29
	fadd.4s	v0, v1, v0
	zip2.8b	v1, v3, v0
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v0, v2, v0
	fmov	w10, s26
	stp	q22, q21, [sp, #64]
	stp	q20, q19, [sp, #96]
	and	x11, x9, #0x7
	add	x12, sp, #64
	ldr	x11, [x12, x11, lsl #3]
	sub	x9, x11, x9
	add	x8, x8, x9, lsl #2
	tbnz	w10, #0, LBB0_200
; %bb.156:                              ; %else250
	ushll.4s	v2, v1, #0
	tbnz	w10, #1, LBB0_201
LBB0_157:                               ; %else252
	fmul.4s	v1, v5, v8
	fmul.4s	v3, v28, v30
	shl.4s	v2, v2, #31
	tbnz	w10, #2, LBB0_202
LBB0_158:                               ; %else254
	fadd.4s	v1, v3, v1
	cmlt.4s	v2, v2, #0
	tbnz	w10, #3, LBB0_203
LBB0_159:                               ; %else256
	and.16b	v0, v2, v1
	tbnz	w10, #4, LBB0_204
LBB0_160:                               ; %else258
	tbnz	w10, #5, LBB0_205
LBB0_161:                               ; %else260
	tbnz	w10, #6, LBB0_206
LBB0_162:                               ; %else262
	tbz	w10, #7, LBB0_164
LBB0_163:                               ; %cond.store263
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_164:
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #656
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
LBB0_165:                               ; %common.ret
	ret
LBB0_166:                               ; %cond.load24
	ld1.s	{ v4 }[0], [x16]
	tbz	w11, #1, LBB0_21
LBB0_167:                               ; %cond.load27
	add	x17, x16, #4
	ld1.s	{ v4 }[1], [x17]
	tbz	w11, #2, LBB0_22
LBB0_168:                               ; %cond.load30
	add	x17, x16, #8
	ld1.s	{ v4 }[2], [x17]
	tbz	w11, #3, LBB0_23
LBB0_169:                               ; %cond.load33
	add	x17, x16, #12
	ld1.s	{ v4 }[3], [x17]
	adrp	x17, lCPI0_3@PAGE
	adrp	x1, lCPI0_4@PAGE
	adrp	x2, lCPI0_5@PAGE
	ldr	q5, [x0, #16]
	tbz	w11, #4, LBB0_24
LBB0_170:                               ; %cond.load36
	add	x0, x16, #16
	ld1.s	{ v5 }[0], [x0]
	ldr	q6, [x17, lCPI0_3@PAGEOFF]
	ldr	q21, [x1, lCPI0_4@PAGEOFF]
	ldr	q22, [x2, lCPI0_5@PAGEOFF]
	tbz	w11, #5, LBB0_25
LBB0_171:                               ; %cond.load39
	add	x17, x16, #20
	ld1.s	{ v5 }[1], [x17]
	and.16b	v20, v18, v6
	and.16b	v21, v17, v21
	and.16b	v22, v16, v22
	tbnz	w11, #6, LBB0_26
	b	LBB0_27
LBB0_172:                               ; %cond.load74
	ld1.s	{ v27 }[0], [x15]
	tbz	w16, #1, LBB0_49
LBB0_173:                               ; %cond.load77
	add	x0, x15, #4
	ld1.s	{ v27 }[1], [x0]
	tbz	w16, #2, LBB0_50
LBB0_174:                               ; %cond.load80
	add	x0, x15, #8
	ld1.s	{ v27 }[2], [x0]
	tbz	w16, #3, LBB0_51
LBB0_175:                               ; %cond.load83
	add	x0, x15, #12
	ld1.s	{ v27 }[3], [x0]
	ldr	q28, [x17, #16]
	tbz	w16, #4, LBB0_52
LBB0_176:                               ; %cond.load86
	add	x17, x15, #16
	ld1.s	{ v28 }[0], [x17]
	tbz	w16, #5, LBB0_53
LBB0_177:                               ; %cond.load89
	add	x17, x15, #20
	ld1.s	{ v28 }[1], [x17]
	tbz	w16, #6, LBB0_54
LBB0_178:                               ; %cond.load92
	add	x17, x15, #24
	ld1.s	{ v28 }[2], [x17]
	tbnz	w16, #7, LBB0_55
	b	LBB0_56
LBB0_179:                               ; %cond.load124
	ld1.s	{ v29 }[0], [x13]
	tbz	w15, #1, LBB0_76
LBB0_180:                               ; %cond.load127
	add	x17, x13, #4
	ld1.s	{ v29 }[1], [x17]
	tbz	w15, #2, LBB0_77
LBB0_181:                               ; %cond.load130
	add	x17, x13, #8
	ld1.s	{ v29 }[2], [x17]
	tbz	w15, #3, LBB0_78
LBB0_182:                               ; %cond.load133
	add	x17, x13, #12
	ld1.s	{ v29 }[3], [x17]
	ldr	q30, [x16, #16]
	tbz	w15, #4, LBB0_79
LBB0_183:                               ; %cond.load136
	add	x16, x13, #16
	ld1.s	{ v30 }[0], [x16]
	tbz	w15, #5, LBB0_80
LBB0_184:                               ; %cond.load139
	add	x16, x13, #20
	ld1.s	{ v30 }[1], [x16]
	tbz	w15, #6, LBB0_81
LBB0_185:                               ; %cond.load142
	add	x16, x13, #24
	ld1.s	{ v30 }[2], [x16]
	tbnz	w15, #7, LBB0_82
	b	LBB0_83
LBB0_186:                               ; %cond.load174
	ld1.s	{ v31 }[0], [x10]
	tbz	w13, #1, LBB0_103
LBB0_187:                               ; %cond.load177
	add	x15, x10, #4
	ld1.s	{ v31 }[1], [x15]
	tbz	w13, #2, LBB0_104
LBB0_188:                               ; %cond.load180
	add	x15, x10, #8
	ld1.s	{ v31 }[2], [x15]
	tbz	w13, #3, LBB0_105
LBB0_189:                               ; %cond.load183
	add	x15, x10, #12
	ld1.s	{ v31 }[3], [x15]
	ldr	q8, [x14, #16]
	tbz	w13, #4, LBB0_106
LBB0_190:                               ; %cond.load186
	add	x14, x10, #16
	ld1.s	{ v8 }[0], [x14]
	tbz	w13, #5, LBB0_107
LBB0_191:                               ; %cond.load189
	add	x14, x10, #20
	ld1.s	{ v8 }[1], [x14]
	tbz	w13, #6, LBB0_108
LBB0_192:                               ; %cond.load192
	add	x14, x10, #24
	ld1.s	{ v8 }[2], [x14]
	tbnz	w13, #7, LBB0_109
	b	LBB0_110
LBB0_193:                               ; %cond.store215
	str	s6, [x12]
	ushll.4s	v24, v23, #0
	tbz	w10, #1, LBB0_130
LBB0_194:                               ; %cond.store217
	add	x13, x12, #4
	st1.s	{ v6 }[1], [x13]
	fmul.4s	v23, v5, v30
	fmul.4s	v25, v28, v8
	shl.4s	v24, v24, #31
	tbz	w10, #2, LBB0_131
LBB0_195:                               ; %cond.store219
	add	x13, x12, #8
	st1.s	{ v6 }[2], [x13]
	fsub.4s	v23, v23, v25
	cmlt.4s	v24, v24, #0
	tbz	w10, #3, LBB0_132
LBB0_196:                               ; %cond.store221
	add	x13, x12, #12
	st1.s	{ v6 }[3], [x13]
	and.16b	v6, v24, v23
	tbz	w10, #4, LBB0_133
LBB0_197:                               ; %cond.store223
	str	s6, [x12, #16]
	tbz	w10, #5, LBB0_134
LBB0_198:                               ; %cond.store225
	add	x13, x12, #20
	st1.s	{ v6 }[1], [x13]
	tbz	w10, #6, LBB0_135
LBB0_199:                               ; %cond.store227
	add	x13, x12, #24
	st1.s	{ v6 }[2], [x13]
	tbnz	w10, #7, LBB0_136
	b	LBB0_137
LBB0_200:                               ; %cond.store249
	str	s0, [x8]
	ushll.4s	v2, v1, #0
	tbz	w10, #1, LBB0_157
LBB0_201:                               ; %cond.store251
	add	x9, x8, #4
	st1.s	{ v0 }[1], [x9]
	fmul.4s	v1, v5, v8
	fmul.4s	v3, v28, v30
	shl.4s	v2, v2, #31
	tbz	w10, #2, LBB0_158
LBB0_202:                               ; %cond.store253
	add	x9, x8, #8
	st1.s	{ v0 }[2], [x9]
	fadd.4s	v1, v3, v1
	cmlt.4s	v2, v2, #0
	tbz	w10, #3, LBB0_159
LBB0_203:                               ; %cond.store255
	add	x9, x8, #12
	st1.s	{ v0 }[3], [x9]
	and.16b	v0, v2, v1
	tbz	w10, #4, LBB0_160
LBB0_204:                               ; %cond.store257
	str	s0, [x8, #16]
	tbz	w10, #5, LBB0_161
LBB0_205:                               ; %cond.store259
	add	x9, x8, #20
	st1.s	{ v0 }[1], [x9]
	tbz	w10, #6, LBB0_162
LBB0_206:                               ; %cond.store261
	add	x9, x8, #24
	st1.s	{ v0 }[2], [x9]
	tbnz	w10, #7, LBB0_163
	b	LBB0_164
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh16, Lloh17
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

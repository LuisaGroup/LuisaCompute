; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [288 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [288 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill11 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill11, align 1
  %.spill12 = alloca i64, align 8
  store i64 0, ptr %.spill12, align 4
  %.slot13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot13, align 64
  %.slot14 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot14, align 32
  %.slot15 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot15, align 32
  %.slot16 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot16, align 32
  %.slot17 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot17, align 32
  %.slot18 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot18, align 32
  %.spill19 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill19, align 32
  %.spill20 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill20, align 32
  %.spill21 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill21, align 32
  %.spill22 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill22, align 4
  %tile_snapshot.spill23 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill23, align 64
  %.slot24 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot24, align 64
  %.slot25 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot25, align 64
  %.slot26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot26, align 32
  %.slot27 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot27, align 32
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.spill31 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill31, align 4
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot33, align 64
  %.spill34 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill34, align 4
  %.slot35 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot35, align 64
  %tile_snapshot.spill36 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill36, align 64
  %.slot37 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot37, align 64
  %.slot38 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot38, align 64
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert39 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat40 = shufflevector <8 x i32> %.splatinsert39, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat40, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert41 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat42 = shufflevector <8 x i32> %.splatinsert41, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat42, %45
  %48 = mul i32 %36, 1
  %.splatinsert43 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat44 = shufflevector <8 x i32> %.splatinsert43, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat44, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert45 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat46 = shufflevector <8 x i32> %.splatinsert45, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat46, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert47 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat48 = shufflevector <8 x i32> %.splatinsert47, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat48
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %70, 0
  %73 = select <8 x i1> %55, <8 x ptr> %71, <8 x ptr> %72
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %70, 1
  %76 = select <8 x i1> %55, <8 x i64> %74, <8 x i64> %75
  %77 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %73, 0
  %78 = insertvalue { <8 x ptr>, <8 x i64> } %77, <8 x i64> %76, 1
  store { <8 x ptr>, <8 x i64> } %78, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %79 = icmp slt i64 %.state, 8
  br i1 %79, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state49 = load i64, ptr %.slot, align 4
  %80 = mul i64 %.state49, 8
  %.splatinsert50 = insertelement <8 x i64> poison, i64 %80, i64 0
  %.splat51 = shufflevector <8 x i64> %.splatinsert50, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.splat51, %.spill.load
  %.spill.load52 = load <8 x i64>, ptr %.spill10, align 64
  %82 = add <8 x i64> %.spill.load52, zeroinitializer
  %83 = add <8 x i64> zeroinitializer, %82
  %84 = add <8 x i64> zeroinitializer, %81
  %85 = mul <8 x i64> %83, splat (i64 65)
  %86 = add <8 x i64> %85, %84
  %87 = extractvalue { ptr, i64 } %13, 0
  %88 = extractelement <8 x i64> %86, i32 0
  %89 = sub i64 %88, 0
  %90 = mul i64 %89, 4
  %buffer.contiguous.address = getelementptr i8, ptr %87, i64 %90
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %92 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state53 = load i64, ptr %.slot, align 4
  %.splatinsert54 = insertelement <8 x i64> poison, i64 %.state53, i64 0
  %.splat55 = shufflevector <8 x i64> %.splatinsert54, <8 x i64> poison, <8 x i32> zeroinitializer
  %93 = mul <8 x i64> %.splat55, splat (i64 32)
  %94 = add <8 x i64> %92, %93
  %95 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %91, 0
  %96 = insertvalue { <8 x ptr>, <8 x i64> } %95, <8 x i64> %94, 1
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %98 = extractvalue { <8 x ptr>, <8 x i64> } %96, 1
  %99 = extractelement <8 x ptr> %97, i32 0
  %100 = extractelement <8 x i64> %98, i32 0
  %101 = sub i64 %100, 0
  %102 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %103 = select i1 %102, i64 %101, i64 0
  %private.contiguous.address = getelementptr i8, ptr %99, i64 %103
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %104 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %104, ptr %private.contiguous.address, align 4
  %.state56 = load i64, ptr %.slot, align 4
  %105 = add i64 %.state56, 1
  store i64 %105, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load57 = load <8 x i64>, ptr %.spill, align 64
  %106 = icmp slt <8 x i64> %.spill.load57, splat (i64 1)
  %107 = load <8 x i1>, ptr %.spill11, align 1
  %108 = select <8 x i1> %55, <8 x i1> %106, <8 x i1> %107
  store <8 x i1> %108, ptr %.spill11, align 1
  %109 = and <8 x i1> %55, %106
  %110 = xor <8 x i1> %106, splat (i1 true)
  %111 = and <8 x i1> %55, %110
  %112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %109)
  %113 = bitcast <8 x i1> %109 to i8
  %114 = call i8 @llvm.cttz.i8(i8 %113, i1 false)
  %115 = zext i8 %114 to i32
  %116 = select i1 %112, i32 %115, i32 0
  %.spill.load58 = load <8 x i64>, ptr %.spill, align 64
  %117 = add <8 x i64> splat (i64 64), %.spill.load58
  %.spill.load59 = load <8 x i64>, ptr %.spill10, align 64
  %118 = add <8 x i64> %.spill.load59, zeroinitializer
  %119 = add <8 x i64> zeroinitializer, %118
  %120 = add <8 x i64> zeroinitializer, %117
  %121 = mul <8 x i64> %119, splat (i64 65)
  %122 = add <8 x i64> %121, %120
  %123 = extractvalue { ptr, i64 } %13, 0
  %124 = select <8 x i1> %109, <8 x i64> %122, <8 x i64> zeroinitializer
  %125 = extractelement <8 x i64> %124, i32 %116
  %126 = zext i32 %116 to i64
  %127 = sub i64 %125, %126
  %128 = mul i64 %127, 4
  %buffer.contiguous.address60 = getelementptr i8, ptr %123, i64 %128
  %buffer.contiguous.load61 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address60, <8 x i1> %109, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load62 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 0
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load62, 1
  %131 = add <8 x i64> %130, splat (i64 256)
  %132 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %129, 0
  %133 = insertvalue { <8 x ptr>, <8 x i64> } %132, <8 x i64> %131, 1
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %136 = extractelement <8 x ptr> %134, i32 0
  %137 = extractelement <8 x i64> %135, i32 %116
  %138 = zext i32 %116 to i64
  %139 = mul i64 %138, 4
  %140 = sub i64 %137, %139
  %141 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %109)
  %142 = select i1 %141, i64 %140, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %136, i64 %142
  %private.contiguous.preserve64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %143 = select <8 x i1> %109, <8 x float> %buffer.contiguous.load61, <8 x float> %private.contiguous.preserve64
  store <8 x float> %143, ptr %private.contiguous.address63, align 4
  %144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %145 = bitcast <8 x i1> %111 to i8
  %146 = call i8 @llvm.cttz.i8(i8 %145, i1 false)
  %147 = zext i8 %146 to i32
  %148 = select i1 %144, i32 %147, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  store i64 0, ptr %.spill12, align 4
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %151 = add <8 x i64> %150, zeroinitializer
  %152 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %149, 0
  %153 = insertvalue { <8 x ptr>, <8 x i64> } %152, <8 x i64> %151, 1
  %154 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %153, 1
  %156 = extractelement <8 x ptr> %154, i32 0
  %157 = extractelement <8 x i64> %155, i32 0
  %158 = sub i64 %157, 0
  %159 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %160 = select i1 %159, i64 %158, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %156, i64 %160
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address66, align 4
  %161 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %tile_snapshot.spill.load67 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 0
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load67, 1
  %164 = add <8 x i64> %163, splat (i64 32)
  %165 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %162, 0
  %166 = insertvalue { <8 x ptr>, <8 x i64> } %165, <8 x i64> %164, 1
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %166, 1
  %169 = extractelement <8 x ptr> %167, i32 0
  %170 = extractelement <8 x i64> %168, i32 0
  %171 = sub i64 %170, 0
  %172 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %173 = select i1 %172, i64 %171, i64 0
  %private.contiguous.address68 = getelementptr i8, ptr %169, i64 %173
  %private.contiguous.load69 = load <8 x float>, ptr %private.contiguous.address68, align 4
  %174 = select <8 x i1> %55, <8 x float> %private.contiguous.load69, <8 x float> zeroinitializer
  %tile_snapshot.spill.load70 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load70, 1
  %177 = add <8 x i64> %176, splat (i64 64)
  %178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %175, 0
  %179 = insertvalue { <8 x ptr>, <8 x i64> } %178, <8 x i64> %177, 1
  %180 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %181 = extractvalue { <8 x ptr>, <8 x i64> } %179, 1
  %182 = extractelement <8 x ptr> %180, i32 0
  %183 = extractelement <8 x i64> %181, i32 0
  %184 = sub i64 %183, 0
  %185 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %186 = select i1 %185, i64 %184, i64 0
  %private.contiguous.address71 = getelementptr i8, ptr %182, i64 %186
  %private.contiguous.load72 = load <8 x float>, ptr %private.contiguous.address71, align 4
  %187 = select <8 x i1> %55, <8 x float> %private.contiguous.load72, <8 x float> zeroinitializer
  %tile_snapshot.spill.load73 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 0
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 1
  %190 = add <8 x i64> %189, splat (i64 96)
  %191 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %188, 0
  %192 = insertvalue { <8 x ptr>, <8 x i64> } %191, <8 x i64> %190, 1
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %194 = extractvalue { <8 x ptr>, <8 x i64> } %192, 1
  %195 = extractelement <8 x ptr> %193, i32 0
  %196 = extractelement <8 x i64> %194, i32 0
  %197 = sub i64 %196, 0
  %198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %199 = select i1 %198, i64 %197, i64 0
  %private.contiguous.address74 = getelementptr i8, ptr %195, i64 %199
  %private.contiguous.load75 = load <8 x float>, ptr %private.contiguous.address74, align 4
  %200 = select <8 x i1> %55, <8 x float> %private.contiguous.load75, <8 x float> zeroinitializer
  %201 = load <8 x i64>, ptr %.slot13, align 64
  %202 = select <8 x i1> %55, <8 x i64> splat (i64 4), <8 x i64> %201
  store <8 x i64> %202, ptr %.slot13, align 64
  %203 = load <8 x float>, ptr %.slot14, align 32
  %204 = select <8 x i1> %55, <8 x float> %161, <8 x float> %203
  store <8 x float> %204, ptr %.slot14, align 32
  %205 = load <8 x float>, ptr %.slot15, align 32
  %206 = select <8 x i1> %55, <8 x float> %174, <8 x float> %205
  store <8 x float> %206, ptr %.slot15, align 32
  %207 = load <8 x float>, ptr %.slot16, align 32
  %208 = select <8 x i1> %55, <8 x float> %187, <8 x float> %207
  store <8 x float> %208, ptr %.slot16, align 32
  %209 = load <8 x float>, ptr %.slot17, align 32
  %210 = select <8 x i1> %55, <8 x float> %200, <8 x float> %209
  store <8 x float> %210, ptr %.slot17, align 32
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state76 = load <8 x i64>, ptr %.slot13, align 64
  %211 = icmp slt <8 x i64> %.state76, splat (i64 8)
  %212 = extractelement <8 x i1> %211, i32 0
  br i1 %212, label %direct.true77, label %direct.false78

direct.schedule.7:                                ; preds = %direct.true77
  %.state79 = load <8 x i64>, ptr %.slot13, align 64
  %213 = add <8 x i64> %.state79, zeroinitializer
  %tile_snapshot.spill.load80 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 1
  %216 = mul <8 x i64> %213, splat (i64 32)
  %217 = add <8 x i64> %215, %216
  %218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %214, 0
  %219 = insertvalue { <8 x ptr>, <8 x i64> } %218, <8 x i64> %217, 1
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %222 = extractelement <8 x ptr> %220, i32 0
  %223 = extractelement <8 x i64> %221, i32 0
  %224 = sub i64 %223, 0
  %225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %226 = select i1 %225, i64 %224, i64 0
  %private.contiguous.address81 = getelementptr i8, ptr %222, i64 %226
  %private.contiguous.load82 = load <8 x float>, ptr %private.contiguous.address81, align 4
  %227 = select <8 x i1> %55, <8 x float> %private.contiguous.load82, <8 x float> zeroinitializer
  %.state83 = load <8 x float>, ptr %.slot14, align 32
  %228 = fadd <8 x float> %.state83, %227
  %.state84 = load <8 x i64>, ptr %.slot13, align 64
  %229 = add <8 x i64> %.state84, splat (i64 1)
  %tile_snapshot.spill.load85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 1
  %232 = mul <8 x i64> %229, splat (i64 32)
  %233 = add <8 x i64> %231, %232
  %234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %230, 0
  %235 = insertvalue { <8 x ptr>, <8 x i64> } %234, <8 x i64> %233, 1
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %235, 1
  %238 = extractelement <8 x ptr> %236, i32 0
  %239 = extractelement <8 x i64> %237, i32 0
  %240 = sub i64 %239, 0
  %241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %242 = select i1 %241, i64 %240, i64 0
  %private.contiguous.address86 = getelementptr i8, ptr %238, i64 %242
  %private.contiguous.load87 = load <8 x float>, ptr %private.contiguous.address86, align 4
  %243 = select <8 x i1> %55, <8 x float> %private.contiguous.load87, <8 x float> zeroinitializer
  %.state88 = load <8 x float>, ptr %.slot15, align 32
  %244 = fadd <8 x float> %.state88, %243
  %.state89 = load <8 x i64>, ptr %.slot13, align 64
  %245 = add <8 x i64> %.state89, splat (i64 2)
  %tile_snapshot.spill.load90 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %246 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 0
  %247 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 1
  %248 = mul <8 x i64> %245, splat (i64 32)
  %249 = add <8 x i64> %247, %248
  %250 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %246, 0
  %251 = insertvalue { <8 x ptr>, <8 x i64> } %250, <8 x i64> %249, 1
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %251, 1
  %254 = extractelement <8 x ptr> %252, i32 0
  %255 = extractelement <8 x i64> %253, i32 0
  %256 = sub i64 %255, 0
  %257 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %258 = select i1 %257, i64 %256, i64 0
  %private.contiguous.address91 = getelementptr i8, ptr %254, i64 %258
  %private.contiguous.load92 = load <8 x float>, ptr %private.contiguous.address91, align 4
  %259 = select <8 x i1> %55, <8 x float> %private.contiguous.load92, <8 x float> zeroinitializer
  %.state93 = load <8 x float>, ptr %.slot16, align 32
  %260 = fadd <8 x float> %.state93, %259
  %.state94 = load <8 x i64>, ptr %.slot13, align 64
  %261 = add <8 x i64> %.state94, splat (i64 3)
  %tile_snapshot.spill.load95 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 0
  %263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 1
  %264 = mul <8 x i64> %261, splat (i64 32)
  %265 = add <8 x i64> %263, %264
  %266 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %262, 0
  %267 = insertvalue { <8 x ptr>, <8 x i64> } %266, <8 x i64> %265, 1
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %267, 1
  %270 = extractelement <8 x ptr> %268, i32 0
  %271 = extractelement <8 x i64> %269, i32 0
  %272 = sub i64 %271, 0
  %273 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %274 = select i1 %273, i64 %272, i64 0
  %private.contiguous.address96 = getelementptr i8, ptr %270, i64 %274
  %private.contiguous.load97 = load <8 x float>, ptr %private.contiguous.address96, align 4
  %275 = select <8 x i1> %55, <8 x float> %private.contiguous.load97, <8 x float> zeroinitializer
  %.state98 = load <8 x float>, ptr %.slot17, align 32
  %276 = fadd <8 x float> %.state98, %275
  %.state99 = load <8 x i64>, ptr %.slot13, align 64
  %277 = add <8 x i64> %.state99, splat (i64 4)
  %278 = load <8 x i64>, ptr %.slot13, align 64
  %279 = select <8 x i1> %55, <8 x i64> %277, <8 x i64> %278
  store <8 x i64> %279, ptr %.slot13, align 64
  %280 = load <8 x float>, ptr %.slot14, align 32
  %281 = select <8 x i1> %55, <8 x float> %228, <8 x float> %280
  store <8 x float> %281, ptr %.slot14, align 32
  %282 = load <8 x float>, ptr %.slot15, align 32
  %283 = select <8 x i1> %55, <8 x float> %244, <8 x float> %282
  store <8 x float> %283, ptr %.slot15, align 32
  %284 = load <8 x float>, ptr %.slot16, align 32
  %285 = select <8 x i1> %55, <8 x float> %260, <8 x float> %284
  store <8 x float> %285, ptr %.slot16, align 32
  %286 = load <8 x float>, ptr %.slot17, align 32
  %287 = select <8 x i1> %55, <8 x float> %276, <8 x float> %286
  store <8 x float> %287, ptr %.slot17, align 32
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false78
  %.spill.load100 = load <8 x i1>, ptr %.spill11, align 1
  %288 = and <8 x i1> %55, %.spill.load100
  %289 = xor <8 x i1> %.spill.load100, splat (i1 true)
  %290 = and <8 x i1> %55, %289
  %291 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %288)
  %292 = bitcast <8 x i1> %288 to i8
  %293 = call i8 @llvm.cttz.i8(i8 %292, i1 false)
  %294 = zext i8 %293 to i32
  %295 = select i1 %291, i32 %294, i32 0
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %296 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %297 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %298 = add <8 x i64> %297, splat (i64 256)
  %299 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %296, 0
  %300 = insertvalue { <8 x ptr>, <8 x i64> } %299, <8 x i64> %298, 1
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %302 = extractvalue { <8 x ptr>, <8 x i64> } %300, 1
  %303 = extractelement <8 x ptr> %301, i32 0
  %304 = extractelement <8 x i64> %302, i32 %295
  %305 = zext i32 %295 to i64
  %306 = mul i64 %305, 4
  %307 = sub i64 %304, %306
  %308 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %288)
  %309 = select i1 %308, i64 %307, i64 0
  %private.contiguous.address102 = getelementptr i8, ptr %303, i64 %309
  %private.contiguous.load103 = load <8 x float>, ptr %private.contiguous.address102, align 4
  %310 = select <8 x i1> %288, <8 x float> %private.contiguous.load103, <8 x float> zeroinitializer
  %.state104 = load <8 x float>, ptr %.slot14, align 32
  %311 = fadd <8 x float> %.state104, %310
  %312 = load <8 x float>, ptr %.slot18, align 32
  %313 = select <8 x i1> %288, <8 x float> %311, <8 x float> %312
  store <8 x float> %313, ptr %.slot18, align 32
  %314 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %290)
  %315 = bitcast <8 x i1> %290 to i8
  %316 = call i8 @llvm.cttz.i8(i8 %315, i1 false)
  %317 = zext i8 %316 to i32
  %318 = select i1 %314, i32 %317, i32 0
  %.state105 = load <8 x float>, ptr %.slot14, align 32
  %319 = load <8 x float>, ptr %.slot18, align 32
  %320 = select <8 x i1> %290, <8 x float> %.state105, <8 x float> %319
  store <8 x float> %320, ptr %.slot18, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.state106 = load <8 x float>, ptr %.slot18, align 32
  %.state107 = load <8 x float>, ptr %.slot15, align 32
  %321 = fadd <8 x float> %.state106, %.state107
  %.state108 = load <8 x float>, ptr %.slot16, align 32
  %322 = fadd <8 x float> %321, %.state108
  %.state109 = load <8 x float>, ptr %.slot17, align 32
  %323 = fadd <8 x float> %322, %.state109
  %.spill.load110 = load <8 x i64>, ptr %.spill, align 64
  %324 = trunc <8 x i64> %.spill.load110 to <8 x i32>
  %325 = xor <8 x i32> %324, splat (i32 1)
  %326 = load <8 x i32>, ptr %.spill19, align 32
  %327 = select <8 x i1> %55, <8 x i32> %325, <8 x i32> %326
  store <8 x i32> %327, ptr %.spill19, align 32
  %328 = extractelement <8 x i32> %325, i64 0
  %329 = icmp ult i32 %328, 8
  %330 = select i1 %329, i32 %328, i32 0
  %331 = extractelement <8 x i1> %55, i32 %330
  %332 = extractelement <8 x i1> %55, i64 0
  %333 = and i1 %329, %331
  %334 = and i1 %332, %333
  %335 = extractelement <8 x float> %323, i32 %330
  %336 = select i1 %334, float %335, float 0.000000e+00
  %337 = insertelement <8 x float> poison, float %336, i64 0
  %338 = xor i1 %334, true
  %339 = and i1 %332, %338
  %340 = insertelement <8 x i1> poison, i1 %339, i64 0
  %341 = extractelement <8 x i32> %325, i64 1
  %342 = icmp ult i32 %341, 8
  %343 = select i1 %342, i32 %341, i32 0
  %344 = extractelement <8 x i1> %55, i32 %343
  %345 = extractelement <8 x i1> %55, i64 1
  %346 = and i1 %342, %344
  %347 = and i1 %345, %346
  %348 = extractelement <8 x float> %323, i32 %343
  %349 = select i1 %347, float %348, float 0.000000e+00
  %350 = insertelement <8 x float> %337, float %349, i64 1
  %351 = xor i1 %347, true
  %352 = and i1 %345, %351
  %353 = insertelement <8 x i1> %340, i1 %352, i64 1
  %354 = extractelement <8 x i32> %325, i64 2
  %355 = icmp ult i32 %354, 8
  %356 = select i1 %355, i32 %354, i32 0
  %357 = extractelement <8 x i1> %55, i32 %356
  %358 = extractelement <8 x i1> %55, i64 2
  %359 = and i1 %355, %357
  %360 = and i1 %358, %359
  %361 = extractelement <8 x float> %323, i32 %356
  %362 = select i1 %360, float %361, float 0.000000e+00
  %363 = insertelement <8 x float> %350, float %362, i64 2
  %364 = xor i1 %360, true
  %365 = and i1 %358, %364
  %366 = insertelement <8 x i1> %353, i1 %365, i64 2
  %367 = extractelement <8 x i32> %325, i64 3
  %368 = icmp ult i32 %367, 8
  %369 = select i1 %368, i32 %367, i32 0
  %370 = extractelement <8 x i1> %55, i32 %369
  %371 = extractelement <8 x i1> %55, i64 3
  %372 = and i1 %368, %370
  %373 = and i1 %371, %372
  %374 = extractelement <8 x float> %323, i32 %369
  %375 = select i1 %373, float %374, float 0.000000e+00
  %376 = insertelement <8 x float> %363, float %375, i64 3
  %377 = xor i1 %373, true
  %378 = and i1 %371, %377
  %379 = insertelement <8 x i1> %366, i1 %378, i64 3
  %380 = extractelement <8 x i32> %325, i64 4
  %381 = icmp ult i32 %380, 8
  %382 = select i1 %381, i32 %380, i32 0
  %383 = extractelement <8 x i1> %55, i32 %382
  %384 = extractelement <8 x i1> %55, i64 4
  %385 = and i1 %381, %383
  %386 = and i1 %384, %385
  %387 = extractelement <8 x float> %323, i32 %382
  %388 = select i1 %386, float %387, float 0.000000e+00
  %389 = insertelement <8 x float> %376, float %388, i64 4
  %390 = xor i1 %386, true
  %391 = and i1 %384, %390
  %392 = insertelement <8 x i1> %379, i1 %391, i64 4
  %393 = extractelement <8 x i32> %325, i64 5
  %394 = icmp ult i32 %393, 8
  %395 = select i1 %394, i32 %393, i32 0
  %396 = extractelement <8 x i1> %55, i32 %395
  %397 = extractelement <8 x i1> %55, i64 5
  %398 = and i1 %394, %396
  %399 = and i1 %397, %398
  %400 = extractelement <8 x float> %323, i32 %395
  %401 = select i1 %399, float %400, float 0.000000e+00
  %402 = insertelement <8 x float> %389, float %401, i64 5
  %403 = xor i1 %399, true
  %404 = and i1 %397, %403
  %405 = insertelement <8 x i1> %392, i1 %404, i64 5
  %406 = extractelement <8 x i32> %325, i64 6
  %407 = icmp ult i32 %406, 8
  %408 = select i1 %407, i32 %406, i32 0
  %409 = extractelement <8 x i1> %55, i32 %408
  %410 = extractelement <8 x i1> %55, i64 6
  %411 = and i1 %407, %409
  %412 = and i1 %410, %411
  %413 = extractelement <8 x float> %323, i32 %408
  %414 = select i1 %412, float %413, float 0.000000e+00
  %415 = insertelement <8 x float> %402, float %414, i64 6
  %416 = xor i1 %412, true
  %417 = and i1 %410, %416
  %418 = insertelement <8 x i1> %405, i1 %417, i64 6
  %419 = extractelement <8 x i32> %325, i64 7
  %420 = icmp ult i32 %419, 8
  %421 = select i1 %420, i32 %419, i32 0
  %422 = extractelement <8 x i1> %55, i32 %421
  %423 = extractelement <8 x i1> %55, i64 7
  %424 = and i1 %420, %422
  %425 = and i1 %423, %424
  %426 = extractelement <8 x float> %323, i32 %421
  %427 = select i1 %425, float %426, float 0.000000e+00
  %428 = insertelement <8 x float> %415, float %427, i64 7
  %429 = xor i1 %425, true
  %430 = and i1 %423, %429
  %431 = insertelement <8 x i1> %418, i1 %430, i64 7
  %432 = fadd <8 x float> %323, %428
  %433 = xor <8 x i32> %324, splat (i32 2)
  %434 = load <8 x i32>, ptr %.spill20, align 32
  %435 = select <8 x i1> %55, <8 x i32> %433, <8 x i32> %434
  store <8 x i32> %435, ptr %.spill20, align 32
  %436 = extractelement <8 x i32> %433, i64 0
  %437 = icmp ult i32 %436, 8
  %438 = select i1 %437, i32 %436, i32 0
  %439 = extractelement <8 x i1> %55, i32 %438
  %440 = extractelement <8 x i1> %55, i64 0
  %441 = and i1 %437, %439
  %442 = and i1 %440, %441
  %443 = extractelement <8 x float> %432, i32 %438
  %444 = select i1 %442, float %443, float 0.000000e+00
  %445 = insertelement <8 x float> poison, float %444, i64 0
  %446 = xor i1 %442, true
  %447 = and i1 %440, %446
  %448 = insertelement <8 x i1> poison, i1 %447, i64 0
  %449 = extractelement <8 x i32> %433, i64 1
  %450 = icmp ult i32 %449, 8
  %451 = select i1 %450, i32 %449, i32 0
  %452 = extractelement <8 x i1> %55, i32 %451
  %453 = extractelement <8 x i1> %55, i64 1
  %454 = and i1 %450, %452
  %455 = and i1 %453, %454
  %456 = extractelement <8 x float> %432, i32 %451
  %457 = select i1 %455, float %456, float 0.000000e+00
  %458 = insertelement <8 x float> %445, float %457, i64 1
  %459 = xor i1 %455, true
  %460 = and i1 %453, %459
  %461 = insertelement <8 x i1> %448, i1 %460, i64 1
  %462 = extractelement <8 x i32> %433, i64 2
  %463 = icmp ult i32 %462, 8
  %464 = select i1 %463, i32 %462, i32 0
  %465 = extractelement <8 x i1> %55, i32 %464
  %466 = extractelement <8 x i1> %55, i64 2
  %467 = and i1 %463, %465
  %468 = and i1 %466, %467
  %469 = extractelement <8 x float> %432, i32 %464
  %470 = select i1 %468, float %469, float 0.000000e+00
  %471 = insertelement <8 x float> %458, float %470, i64 2
  %472 = xor i1 %468, true
  %473 = and i1 %466, %472
  %474 = insertelement <8 x i1> %461, i1 %473, i64 2
  %475 = extractelement <8 x i32> %433, i64 3
  %476 = icmp ult i32 %475, 8
  %477 = select i1 %476, i32 %475, i32 0
  %478 = extractelement <8 x i1> %55, i32 %477
  %479 = extractelement <8 x i1> %55, i64 3
  %480 = and i1 %476, %478
  %481 = and i1 %479, %480
  %482 = extractelement <8 x float> %432, i32 %477
  %483 = select i1 %481, float %482, float 0.000000e+00
  %484 = insertelement <8 x float> %471, float %483, i64 3
  %485 = xor i1 %481, true
  %486 = and i1 %479, %485
  %487 = insertelement <8 x i1> %474, i1 %486, i64 3
  %488 = extractelement <8 x i32> %433, i64 4
  %489 = icmp ult i32 %488, 8
  %490 = select i1 %489, i32 %488, i32 0
  %491 = extractelement <8 x i1> %55, i32 %490
  %492 = extractelement <8 x i1> %55, i64 4
  %493 = and i1 %489, %491
  %494 = and i1 %492, %493
  %495 = extractelement <8 x float> %432, i32 %490
  %496 = select i1 %494, float %495, float 0.000000e+00
  %497 = insertelement <8 x float> %484, float %496, i64 4
  %498 = xor i1 %494, true
  %499 = and i1 %492, %498
  %500 = insertelement <8 x i1> %487, i1 %499, i64 4
  %501 = extractelement <8 x i32> %433, i64 5
  %502 = icmp ult i32 %501, 8
  %503 = select i1 %502, i32 %501, i32 0
  %504 = extractelement <8 x i1> %55, i32 %503
  %505 = extractelement <8 x i1> %55, i64 5
  %506 = and i1 %502, %504
  %507 = and i1 %505, %506
  %508 = extractelement <8 x float> %432, i32 %503
  %509 = select i1 %507, float %508, float 0.000000e+00
  %510 = insertelement <8 x float> %497, float %509, i64 5
  %511 = xor i1 %507, true
  %512 = and i1 %505, %511
  %513 = insertelement <8 x i1> %500, i1 %512, i64 5
  %514 = extractelement <8 x i32> %433, i64 6
  %515 = icmp ult i32 %514, 8
  %516 = select i1 %515, i32 %514, i32 0
  %517 = extractelement <8 x i1> %55, i32 %516
  %518 = extractelement <8 x i1> %55, i64 6
  %519 = and i1 %515, %517
  %520 = and i1 %518, %519
  %521 = extractelement <8 x float> %432, i32 %516
  %522 = select i1 %520, float %521, float 0.000000e+00
  %523 = insertelement <8 x float> %510, float %522, i64 6
  %524 = xor i1 %520, true
  %525 = and i1 %518, %524
  %526 = insertelement <8 x i1> %513, i1 %525, i64 6
  %527 = extractelement <8 x i32> %433, i64 7
  %528 = icmp ult i32 %527, 8
  %529 = select i1 %528, i32 %527, i32 0
  %530 = extractelement <8 x i1> %55, i32 %529
  %531 = extractelement <8 x i1> %55, i64 7
  %532 = and i1 %528, %530
  %533 = and i1 %531, %532
  %534 = extractelement <8 x float> %432, i32 %529
  %535 = select i1 %533, float %534, float 0.000000e+00
  %536 = insertelement <8 x float> %523, float %535, i64 7
  %537 = xor i1 %533, true
  %538 = and i1 %531, %537
  %539 = insertelement <8 x i1> %526, i1 %538, i64 7
  %540 = fadd <8 x float> %432, %536
  %541 = xor <8 x i32> %324, splat (i32 4)
  %542 = load <8 x i32>, ptr %.spill21, align 32
  %543 = select <8 x i1> %55, <8 x i32> %541, <8 x i32> %542
  store <8 x i32> %543, ptr %.spill21, align 32
  %544 = extractelement <8 x i32> %541, i64 0
  %545 = icmp ult i32 %544, 8
  %546 = select i1 %545, i32 %544, i32 0
  %547 = extractelement <8 x i1> %55, i32 %546
  %548 = extractelement <8 x i1> %55, i64 0
  %549 = and i1 %545, %547
  %550 = and i1 %548, %549
  %551 = extractelement <8 x float> %540, i32 %546
  %552 = select i1 %550, float %551, float 0.000000e+00
  %553 = insertelement <8 x float> poison, float %552, i64 0
  %554 = xor i1 %550, true
  %555 = and i1 %548, %554
  %556 = insertelement <8 x i1> poison, i1 %555, i64 0
  %557 = extractelement <8 x i32> %541, i64 1
  %558 = icmp ult i32 %557, 8
  %559 = select i1 %558, i32 %557, i32 0
  %560 = extractelement <8 x i1> %55, i32 %559
  %561 = extractelement <8 x i1> %55, i64 1
  %562 = and i1 %558, %560
  %563 = and i1 %561, %562
  %564 = extractelement <8 x float> %540, i32 %559
  %565 = select i1 %563, float %564, float 0.000000e+00
  %566 = insertelement <8 x float> %553, float %565, i64 1
  %567 = xor i1 %563, true
  %568 = and i1 %561, %567
  %569 = insertelement <8 x i1> %556, i1 %568, i64 1
  %570 = extractelement <8 x i32> %541, i64 2
  %571 = icmp ult i32 %570, 8
  %572 = select i1 %571, i32 %570, i32 0
  %573 = extractelement <8 x i1> %55, i32 %572
  %574 = extractelement <8 x i1> %55, i64 2
  %575 = and i1 %571, %573
  %576 = and i1 %574, %575
  %577 = extractelement <8 x float> %540, i32 %572
  %578 = select i1 %576, float %577, float 0.000000e+00
  %579 = insertelement <8 x float> %566, float %578, i64 2
  %580 = xor i1 %576, true
  %581 = and i1 %574, %580
  %582 = insertelement <8 x i1> %569, i1 %581, i64 2
  %583 = extractelement <8 x i32> %541, i64 3
  %584 = icmp ult i32 %583, 8
  %585 = select i1 %584, i32 %583, i32 0
  %586 = extractelement <8 x i1> %55, i32 %585
  %587 = extractelement <8 x i1> %55, i64 3
  %588 = and i1 %584, %586
  %589 = and i1 %587, %588
  %590 = extractelement <8 x float> %540, i32 %585
  %591 = select i1 %589, float %590, float 0.000000e+00
  %592 = insertelement <8 x float> %579, float %591, i64 3
  %593 = xor i1 %589, true
  %594 = and i1 %587, %593
  %595 = insertelement <8 x i1> %582, i1 %594, i64 3
  %596 = extractelement <8 x i32> %541, i64 4
  %597 = icmp ult i32 %596, 8
  %598 = select i1 %597, i32 %596, i32 0
  %599 = extractelement <8 x i1> %55, i32 %598
  %600 = extractelement <8 x i1> %55, i64 4
  %601 = and i1 %597, %599
  %602 = and i1 %600, %601
  %603 = extractelement <8 x float> %540, i32 %598
  %604 = select i1 %602, float %603, float 0.000000e+00
  %605 = insertelement <8 x float> %592, float %604, i64 4
  %606 = xor i1 %602, true
  %607 = and i1 %600, %606
  %608 = insertelement <8 x i1> %595, i1 %607, i64 4
  %609 = extractelement <8 x i32> %541, i64 5
  %610 = icmp ult i32 %609, 8
  %611 = select i1 %610, i32 %609, i32 0
  %612 = extractelement <8 x i1> %55, i32 %611
  %613 = extractelement <8 x i1> %55, i64 5
  %614 = and i1 %610, %612
  %615 = and i1 %613, %614
  %616 = extractelement <8 x float> %540, i32 %611
  %617 = select i1 %615, float %616, float 0.000000e+00
  %618 = insertelement <8 x float> %605, float %617, i64 5
  %619 = xor i1 %615, true
  %620 = and i1 %613, %619
  %621 = insertelement <8 x i1> %608, i1 %620, i64 5
  %622 = extractelement <8 x i32> %541, i64 6
  %623 = icmp ult i32 %622, 8
  %624 = select i1 %623, i32 %622, i32 0
  %625 = extractelement <8 x i1> %55, i32 %624
  %626 = extractelement <8 x i1> %55, i64 6
  %627 = and i1 %623, %625
  %628 = and i1 %626, %627
  %629 = extractelement <8 x float> %540, i32 %624
  %630 = select i1 %628, float %629, float 0.000000e+00
  %631 = insertelement <8 x float> %618, float %630, i64 6
  %632 = xor i1 %628, true
  %633 = and i1 %626, %632
  %634 = insertelement <8 x i1> %621, i1 %633, i64 6
  %635 = extractelement <8 x i32> %541, i64 7
  %636 = icmp ult i32 %635, 8
  %637 = select i1 %636, i32 %635, i32 0
  %638 = extractelement <8 x i1> %55, i32 %637
  %639 = extractelement <8 x i1> %55, i64 7
  %640 = and i1 %636, %638
  %641 = and i1 %639, %640
  %642 = extractelement <8 x float> %540, i32 %637
  %643 = select i1 %641, float %642, float 0.000000e+00
  %644 = insertelement <8 x float> %631, float %643, i64 7
  %645 = xor i1 %641, true
  %646 = and i1 %639, %645
  %647 = insertelement <8 x i1> %634, i1 %646, i64 7
  %648 = fadd <8 x float> %540, %644
  %649 = extractelement <8 x i1> %55, i32 0
  %650 = extractelement <8 x i1> %55, i64 0
  %651 = and i1 true, %649
  %652 = and i1 %650, %651
  %653 = extractelement <8 x float> %648, i32 0
  %654 = select i1 %652, float %653, float 0.000000e+00
  %655 = insertelement <8 x float> poison, float %654, i64 0
  %656 = xor i1 %652, true
  %657 = and i1 %650, %656
  %658 = insertelement <8 x i1> poison, i1 %657, i64 0
  %659 = extractelement <8 x i1> %55, i32 0
  %660 = extractelement <8 x i1> %55, i64 1
  %661 = and i1 true, %659
  %662 = and i1 %660, %661
  %663 = extractelement <8 x float> %648, i32 0
  %664 = select i1 %662, float %663, float 0.000000e+00
  %665 = insertelement <8 x float> %655, float %664, i64 1
  %666 = xor i1 %662, true
  %667 = and i1 %660, %666
  %668 = insertelement <8 x i1> %658, i1 %667, i64 1
  %669 = extractelement <8 x i1> %55, i32 0
  %670 = extractelement <8 x i1> %55, i64 2
  %671 = and i1 true, %669
  %672 = and i1 %670, %671
  %673 = extractelement <8 x float> %648, i32 0
  %674 = select i1 %672, float %673, float 0.000000e+00
  %675 = insertelement <8 x float> %665, float %674, i64 2
  %676 = xor i1 %672, true
  %677 = and i1 %670, %676
  %678 = insertelement <8 x i1> %668, i1 %677, i64 2
  %679 = extractelement <8 x i1> %55, i32 0
  %680 = extractelement <8 x i1> %55, i64 3
  %681 = and i1 true, %679
  %682 = and i1 %680, %681
  %683 = extractelement <8 x float> %648, i32 0
  %684 = select i1 %682, float %683, float 0.000000e+00
  %685 = insertelement <8 x float> %675, float %684, i64 3
  %686 = xor i1 %682, true
  %687 = and i1 %680, %686
  %688 = insertelement <8 x i1> %678, i1 %687, i64 3
  %689 = extractelement <8 x i1> %55, i32 0
  %690 = extractelement <8 x i1> %55, i64 4
  %691 = and i1 true, %689
  %692 = and i1 %690, %691
  %693 = extractelement <8 x float> %648, i32 0
  %694 = select i1 %692, float %693, float 0.000000e+00
  %695 = insertelement <8 x float> %685, float %694, i64 4
  %696 = xor i1 %692, true
  %697 = and i1 %690, %696
  %698 = insertelement <8 x i1> %688, i1 %697, i64 4
  %699 = extractelement <8 x i1> %55, i32 0
  %700 = extractelement <8 x i1> %55, i64 5
  %701 = and i1 true, %699
  %702 = and i1 %700, %701
  %703 = extractelement <8 x float> %648, i32 0
  %704 = select i1 %702, float %703, float 0.000000e+00
  %705 = insertelement <8 x float> %695, float %704, i64 5
  %706 = xor i1 %702, true
  %707 = and i1 %700, %706
  %708 = insertelement <8 x i1> %698, i1 %707, i64 5
  %709 = extractelement <8 x i1> %55, i32 0
  %710 = extractelement <8 x i1> %55, i64 6
  %711 = and i1 true, %709
  %712 = and i1 %710, %711
  %713 = extractelement <8 x float> %648, i32 0
  %714 = select i1 %712, float %713, float 0.000000e+00
  %715 = insertelement <8 x float> %705, float %714, i64 6
  %716 = xor i1 %712, true
  %717 = and i1 %710, %716
  %718 = insertelement <8 x i1> %708, i1 %717, i64 6
  %719 = extractelement <8 x i1> %55, i32 0
  %720 = extractelement <8 x i1> %55, i64 7
  %721 = and i1 true, %719
  %722 = and i1 %720, %721
  %723 = extractelement <8 x float> %648, i32 0
  %724 = select i1 %722, float %723, float 0.000000e+00
  %725 = insertelement <8 x float> %715, float %724, i64 7
  %726 = xor i1 %722, true
  %727 = and i1 %720, %726
  %728 = insertelement <8 x i1> %718, i1 %727, i64 7
  %729 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %730 = bitcast <8 x i1> %55 to i8
  %731 = call i8 @llvm.cttz.i8(i8 %730, i1 false)
  %732 = zext i8 %731 to i32
  %733 = select i1 %729, i32 %732, i32 0
  %734 = extractelement <8 x float> %725, i32 %733
  %735 = fadd float 0.000000e+00, %734
  %736 = fdiv float %735, 6.500000e+01
  store float %736, ptr %.spill22, align 4
  %737 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %739 = extractvalue { <8 x ptr>, <8 x i64> } %737, 0
  %740 = select <8 x i1> %55, <8 x ptr> %738, <8 x ptr> %739
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %737, 1
  %743 = select <8 x i1> %55, <8 x i64> %741, <8 x i64> %742
  %744 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %740, 0
  %745 = insertvalue { <8 x ptr>, <8 x i64> } %744, <8 x i64> %743, 1
  store { <8 x ptr>, <8 x i64> } %745, ptr %tile_snapshot.spill23, align 64
  %746 = load <8 x i64>, ptr %.slot24, align 64
  %747 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %746
  store <8 x i64> %747, ptr %.slot24, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state111 = load <8 x i64>, ptr %.slot24, align 64
  %748 = icmp slt <8 x i64> %.state111, splat (i64 8)
  %749 = extractelement <8 x i1> %748, i32 0
  br i1 %749, label %direct.true112, label %direct.false113

direct.schedule.12:                               ; preds = %direct.true112
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %750 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %751 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %.state115 = load <8 x i64>, ptr %.slot24, align 64
  %752 = mul <8 x i64> %.state115, splat (i64 32)
  %753 = add <8 x i64> %751, %752
  %754 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %750, 0
  %755 = insertvalue { <8 x ptr>, <8 x i64> } %754, <8 x i64> %753, 1
  %756 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %757 = extractvalue { <8 x ptr>, <8 x i64> } %755, 1
  %758 = extractelement <8 x ptr> %756, i32 0
  %759 = extractelement <8 x i64> %757, i32 0
  %760 = sub i64 %759, 0
  %761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %762 = select i1 %761, i64 %760, i64 0
  %private.contiguous.address116 = getelementptr i8, ptr %758, i64 %762
  %private.contiguous.load117 = load <8 x float>, ptr %private.contiguous.address116, align 4
  %763 = select <8 x i1> %55, <8 x float> %private.contiguous.load117, <8 x float> zeroinitializer
  %.spill.load118 = load float, ptr %.spill22, align 4
  %.splatinsert119 = insertelement <8 x float> poison, float %.spill.load118, i64 0
  %.splat120 = shufflevector <8 x float> %.splatinsert119, <8 x float> poison, <8 x i32> zeroinitializer
  %764 = fsub <8 x float> %763, %.splat120
  %tile_snapshot.spill.load121 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %765 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 0
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load121, 1
  %.state122 = load <8 x i64>, ptr %.slot24, align 64
  %767 = mul <8 x i64> %.state122, splat (i64 32)
  %768 = add <8 x i64> %766, %767
  %769 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %765, 0
  %770 = insertvalue { <8 x ptr>, <8 x i64> } %769, <8 x i64> %768, 1
  %771 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %772 = extractvalue { <8 x ptr>, <8 x i64> } %770, 1
  %773 = extractelement <8 x ptr> %771, i32 0
  %774 = extractelement <8 x i64> %772, i32 0
  %775 = sub i64 %774, 0
  %776 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %777 = select i1 %776, i64 %775, i64 0
  %private.contiguous.address123 = getelementptr i8, ptr %773, i64 %777
  %private.contiguous.preserve124 = load <8 x float>, ptr %private.contiguous.address123, align 4
  %778 = select <8 x i1> %55, <8 x float> %764, <8 x float> %private.contiguous.preserve124
  store <8 x float> %778, ptr %private.contiguous.address123, align 4
  %.state125 = load <8 x i64>, ptr %.slot24, align 64
  %779 = add <8 x i64> %.state125, splat (i64 1)
  %780 = load <8 x i64>, ptr %.slot24, align 64
  %781 = select <8 x i1> %55, <8 x i64> %779, <8 x i64> %780
  store <8 x i64> %781, ptr %.slot24, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false113
  %.spill.load126 = load <8 x i1>, ptr %.spill11, align 1
  %782 = and <8 x i1> %55, %.spill.load126
  %783 = xor <8 x i1> %.spill.load126, splat (i1 true)
  %784 = and <8 x i1> %55, %783
  %785 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %786 = bitcast <8 x i1> %782 to i8
  %787 = call i8 @llvm.cttz.i8(i8 %786, i1 false)
  %788 = zext i8 %787 to i32
  %789 = select i1 %785, i32 %788, i32 0
  %tile_snapshot.spill.load127 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load127, 0
  %791 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load127, 1
  %792 = add <8 x i64> %791, splat (i64 256)
  %793 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %790, 0
  %794 = insertvalue { <8 x ptr>, <8 x i64> } %793, <8 x i64> %792, 1
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %796 = extractvalue { <8 x ptr>, <8 x i64> } %794, 1
  %797 = extractelement <8 x ptr> %795, i32 0
  %798 = extractelement <8 x i64> %796, i32 %789
  %799 = zext i32 %789 to i64
  %800 = mul i64 %799, 4
  %801 = sub i64 %798, %800
  %802 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %803 = select i1 %802, i64 %801, i64 0
  %private.contiguous.address128 = getelementptr i8, ptr %797, i64 %803
  %private.contiguous.load129 = load <8 x float>, ptr %private.contiguous.address128, align 4
  %804 = select <8 x i1> %782, <8 x float> %private.contiguous.load129, <8 x float> zeroinitializer
  %.spill.load130 = load float, ptr %.spill22, align 4
  %.splatinsert131 = insertelement <8 x float> poison, float %.spill.load130, i64 0
  %.splat132 = shufflevector <8 x float> %.splatinsert131, <8 x float> poison, <8 x i32> zeroinitializer
  %805 = fsub <8 x float> %804, %.splat132
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %806 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %808 = add <8 x i64> %807, splat (i64 256)
  %809 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %806, 0
  %810 = insertvalue { <8 x ptr>, <8 x i64> } %809, <8 x i64> %808, 1
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %810, 1
  %813 = extractelement <8 x ptr> %811, i32 0
  %814 = extractelement <8 x i64> %812, i32 %789
  %815 = zext i32 %789 to i64
  %816 = mul i64 %815, 4
  %817 = sub i64 %814, %816
  %818 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %782)
  %819 = select i1 %818, i64 %817, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %813, i64 %819
  %private.contiguous.preserve135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %820 = select <8 x i1> %782, <8 x float> %805, <8 x float> %private.contiguous.preserve135
  store <8 x float> %820, ptr %private.contiguous.address134, align 4
  %821 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %784)
  %822 = bitcast <8 x i1> %784 to i8
  %823 = call i8 @llvm.cttz.i8(i8 %822, i1 false)
  %824 = zext i8 %823 to i32
  %825 = select i1 %821, i32 %824, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %tile_snapshot.spill.load136 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 0
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 1
  %828 = add <8 x i64> %827, zeroinitializer
  %829 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %826, 0
  %830 = insertvalue { <8 x ptr>, <8 x i64> } %829, <8 x i64> %828, 1
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %830, 1
  %833 = extractelement <8 x ptr> %831, i32 0
  %834 = extractelement <8 x i64> %832, i32 0
  %835 = sub i64 %834, 0
  %836 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %837 = select i1 %836, i64 %835, i64 0
  %private.contiguous.address137 = getelementptr i8, ptr %833, i64 %837
  %private.contiguous.load138 = load <8 x float>, ptr %private.contiguous.address137, align 4
  %838 = select <8 x i1> %55, <8 x float> %private.contiguous.load138, <8 x float> zeroinitializer
  %839 = fmul <8 x float> %838, %838
  %tile_snapshot.spill.load139 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %840 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 0
  %841 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 1
  %842 = add <8 x i64> %841, splat (i64 32)
  %843 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %840, 0
  %844 = insertvalue { <8 x ptr>, <8 x i64> } %843, <8 x i64> %842, 1
  %845 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %846 = extractvalue { <8 x ptr>, <8 x i64> } %844, 1
  %847 = extractelement <8 x ptr> %845, i32 0
  %848 = extractelement <8 x i64> %846, i32 0
  %849 = sub i64 %848, 0
  %850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %851 = select i1 %850, i64 %849, i64 0
  %private.contiguous.address140 = getelementptr i8, ptr %847, i64 %851
  %private.contiguous.load141 = load <8 x float>, ptr %private.contiguous.address140, align 4
  %852 = select <8 x i1> %55, <8 x float> %private.contiguous.load141, <8 x float> zeroinitializer
  %853 = fmul <8 x float> %852, %852
  %tile_snapshot.spill.load142 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %854 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load142, 0
  %855 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load142, 1
  %856 = add <8 x i64> %855, splat (i64 64)
  %857 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %854, 0
  %858 = insertvalue { <8 x ptr>, <8 x i64> } %857, <8 x i64> %856, 1
  %859 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %860 = extractvalue { <8 x ptr>, <8 x i64> } %858, 1
  %861 = extractelement <8 x ptr> %859, i32 0
  %862 = extractelement <8 x i64> %860, i32 0
  %863 = sub i64 %862, 0
  %864 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %865 = select i1 %864, i64 %863, i64 0
  %private.contiguous.address143 = getelementptr i8, ptr %861, i64 %865
  %private.contiguous.load144 = load <8 x float>, ptr %private.contiguous.address143, align 4
  %866 = select <8 x i1> %55, <8 x float> %private.contiguous.load144, <8 x float> zeroinitializer
  %867 = fmul <8 x float> %866, %866
  %tile_snapshot.spill.load145 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %868 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load145, 0
  %869 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load145, 1
  %870 = add <8 x i64> %869, splat (i64 96)
  %871 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %868, 0
  %872 = insertvalue { <8 x ptr>, <8 x i64> } %871, <8 x i64> %870, 1
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %874 = extractvalue { <8 x ptr>, <8 x i64> } %872, 1
  %875 = extractelement <8 x ptr> %873, i32 0
  %876 = extractelement <8 x i64> %874, i32 0
  %877 = sub i64 %876, 0
  %878 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %879 = select i1 %878, i64 %877, i64 0
  %private.contiguous.address146 = getelementptr i8, ptr %875, i64 %879
  %private.contiguous.load147 = load <8 x float>, ptr %private.contiguous.address146, align 4
  %880 = select <8 x i1> %55, <8 x float> %private.contiguous.load147, <8 x float> zeroinitializer
  %881 = fmul <8 x float> %880, %880
  %882 = load <8 x i64>, ptr %.slot25, align 64
  %883 = select <8 x i1> %55, <8 x i64> splat (i64 4), <8 x i64> %882
  store <8 x i64> %883, ptr %.slot25, align 64
  %884 = load <8 x float>, ptr %.slot26, align 32
  %885 = select <8 x i1> %55, <8 x float> %839, <8 x float> %884
  store <8 x float> %885, ptr %.slot26, align 32
  %886 = load <8 x float>, ptr %.slot27, align 32
  %887 = select <8 x i1> %55, <8 x float> %853, <8 x float> %886
  store <8 x float> %887, ptr %.slot27, align 32
  %888 = load <8 x float>, ptr %.slot28, align 32
  %889 = select <8 x i1> %55, <8 x float> %867, <8 x float> %888
  store <8 x float> %889, ptr %.slot28, align 32
  %890 = load <8 x float>, ptr %.slot29, align 32
  %891 = select <8 x i1> %55, <8 x float> %881, <8 x float> %890
  store <8 x float> %891, ptr %.slot29, align 32
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state148 = load <8 x i64>, ptr %.slot25, align 64
  %892 = icmp slt <8 x i64> %.state148, splat (i64 8)
  %893 = extractelement <8 x i1> %892, i32 0
  br i1 %893, label %direct.true149, label %direct.false150

direct.schedule.17:                               ; preds = %direct.true149
  %.state151 = load <8 x i64>, ptr %.slot25, align 64
  %894 = add <8 x i64> %.state151, zeroinitializer
  %tile_snapshot.spill.load152 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %895 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 0
  %896 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load152, 1
  %897 = mul <8 x i64> %894, splat (i64 32)
  %898 = add <8 x i64> %896, %897
  %899 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %895, 0
  %900 = insertvalue { <8 x ptr>, <8 x i64> } %899, <8 x i64> %898, 1
  %901 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %902 = extractvalue { <8 x ptr>, <8 x i64> } %900, 1
  %903 = extractelement <8 x ptr> %901, i32 0
  %904 = extractelement <8 x i64> %902, i32 0
  %905 = sub i64 %904, 0
  %906 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %907 = select i1 %906, i64 %905, i64 0
  %private.contiguous.address153 = getelementptr i8, ptr %903, i64 %907
  %private.contiguous.load154 = load <8 x float>, ptr %private.contiguous.address153, align 4
  %908 = select <8 x i1> %55, <8 x float> %private.contiguous.load154, <8 x float> zeroinitializer
  %909 = fmul <8 x float> %908, %908
  %.state155 = load <8 x float>, ptr %.slot26, align 32
  %910 = fadd <8 x float> %.state155, %909
  %.state156 = load <8 x i64>, ptr %.slot25, align 64
  %911 = add <8 x i64> %.state156, splat (i64 1)
  %tile_snapshot.spill.load157 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %912 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 0
  %913 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load157, 1
  %914 = mul <8 x i64> %911, splat (i64 32)
  %915 = add <8 x i64> %913, %914
  %916 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %912, 0
  %917 = insertvalue { <8 x ptr>, <8 x i64> } %916, <8 x i64> %915, 1
  %918 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %919 = extractvalue { <8 x ptr>, <8 x i64> } %917, 1
  %920 = extractelement <8 x ptr> %918, i32 0
  %921 = extractelement <8 x i64> %919, i32 0
  %922 = sub i64 %921, 0
  %923 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %924 = select i1 %923, i64 %922, i64 0
  %private.contiguous.address158 = getelementptr i8, ptr %920, i64 %924
  %private.contiguous.load159 = load <8 x float>, ptr %private.contiguous.address158, align 4
  %925 = select <8 x i1> %55, <8 x float> %private.contiguous.load159, <8 x float> zeroinitializer
  %926 = fmul <8 x float> %925, %925
  %.state160 = load <8 x float>, ptr %.slot27, align 32
  %927 = fadd <8 x float> %.state160, %926
  %.state161 = load <8 x i64>, ptr %.slot25, align 64
  %928 = add <8 x i64> %.state161, splat (i64 2)
  %tile_snapshot.spill.load162 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %929 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 0
  %930 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load162, 1
  %931 = mul <8 x i64> %928, splat (i64 32)
  %932 = add <8 x i64> %930, %931
  %933 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %929, 0
  %934 = insertvalue { <8 x ptr>, <8 x i64> } %933, <8 x i64> %932, 1
  %935 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %936 = extractvalue { <8 x ptr>, <8 x i64> } %934, 1
  %937 = extractelement <8 x ptr> %935, i32 0
  %938 = extractelement <8 x i64> %936, i32 0
  %939 = sub i64 %938, 0
  %940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %941 = select i1 %940, i64 %939, i64 0
  %private.contiguous.address163 = getelementptr i8, ptr %937, i64 %941
  %private.contiguous.load164 = load <8 x float>, ptr %private.contiguous.address163, align 4
  %942 = select <8 x i1> %55, <8 x float> %private.contiguous.load164, <8 x float> zeroinitializer
  %943 = fmul <8 x float> %942, %942
  %.state165 = load <8 x float>, ptr %.slot28, align 32
  %944 = fadd <8 x float> %.state165, %943
  %.state166 = load <8 x i64>, ptr %.slot25, align 64
  %945 = add <8 x i64> %.state166, splat (i64 3)
  %tile_snapshot.spill.load167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %946 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 0
  %947 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 1
  %948 = mul <8 x i64> %945, splat (i64 32)
  %949 = add <8 x i64> %947, %948
  %950 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %946, 0
  %951 = insertvalue { <8 x ptr>, <8 x i64> } %950, <8 x i64> %949, 1
  %952 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %953 = extractvalue { <8 x ptr>, <8 x i64> } %951, 1
  %954 = extractelement <8 x ptr> %952, i32 0
  %955 = extractelement <8 x i64> %953, i32 0
  %956 = sub i64 %955, 0
  %957 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %958 = select i1 %957, i64 %956, i64 0
  %private.contiguous.address168 = getelementptr i8, ptr %954, i64 %958
  %private.contiguous.load169 = load <8 x float>, ptr %private.contiguous.address168, align 4
  %959 = select <8 x i1> %55, <8 x float> %private.contiguous.load169, <8 x float> zeroinitializer
  %960 = fmul <8 x float> %959, %959
  %.state170 = load <8 x float>, ptr %.slot29, align 32
  %961 = fadd <8 x float> %.state170, %960
  %.state171 = load <8 x i64>, ptr %.slot25, align 64
  %962 = add <8 x i64> %.state171, splat (i64 4)
  %963 = load <8 x i64>, ptr %.slot25, align 64
  %964 = select <8 x i1> %55, <8 x i64> %962, <8 x i64> %963
  store <8 x i64> %964, ptr %.slot25, align 64
  %965 = load <8 x float>, ptr %.slot26, align 32
  %966 = select <8 x i1> %55, <8 x float> %910, <8 x float> %965
  store <8 x float> %966, ptr %.slot26, align 32
  %967 = load <8 x float>, ptr %.slot27, align 32
  %968 = select <8 x i1> %55, <8 x float> %927, <8 x float> %967
  store <8 x float> %968, ptr %.slot27, align 32
  %969 = load <8 x float>, ptr %.slot28, align 32
  %970 = select <8 x i1> %55, <8 x float> %944, <8 x float> %969
  store <8 x float> %970, ptr %.slot28, align 32
  %971 = load <8 x float>, ptr %.slot29, align 32
  %972 = select <8 x i1> %55, <8 x float> %961, <8 x float> %971
  store <8 x float> %972, ptr %.slot29, align 32
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false150
  %.spill.load172 = load <8 x i1>, ptr %.spill11, align 1
  %973 = and <8 x i1> %55, %.spill.load172
  %974 = xor <8 x i1> %.spill.load172, splat (i1 true)
  %975 = and <8 x i1> %55, %974
  %976 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %973)
  %977 = bitcast <8 x i1> %973 to i8
  %978 = call i8 @llvm.cttz.i8(i8 %977, i1 false)
  %979 = zext i8 %978 to i32
  %980 = select i1 %976, i32 %979, i32 0
  %tile_snapshot.spill.load173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 0
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 1
  %983 = add <8 x i64> %982, splat (i64 256)
  %984 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %981, 0
  %985 = insertvalue { <8 x ptr>, <8 x i64> } %984, <8 x i64> %983, 1
  %986 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %987 = extractvalue { <8 x ptr>, <8 x i64> } %985, 1
  %988 = extractelement <8 x ptr> %986, i32 0
  %989 = extractelement <8 x i64> %987, i32 %980
  %990 = zext i32 %980 to i64
  %991 = mul i64 %990, 4
  %992 = sub i64 %989, %991
  %993 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %973)
  %994 = select i1 %993, i64 %992, i64 0
  %private.contiguous.address174 = getelementptr i8, ptr %988, i64 %994
  %private.contiguous.load175 = load <8 x float>, ptr %private.contiguous.address174, align 4
  %995 = select <8 x i1> %973, <8 x float> %private.contiguous.load175, <8 x float> zeroinitializer
  %996 = fmul <8 x float> %995, %995
  %.state176 = load <8 x float>, ptr %.slot26, align 32
  %997 = fadd <8 x float> %.state176, %996
  %998 = load <8 x float>, ptr %.slot30, align 32
  %999 = select <8 x i1> %973, <8 x float> %997, <8 x float> %998
  store <8 x float> %999, ptr %.slot30, align 32
  %1000 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %975)
  %1001 = bitcast <8 x i1> %975 to i8
  %1002 = call i8 @llvm.cttz.i8(i8 %1001, i1 false)
  %1003 = zext i8 %1002 to i32
  %1004 = select i1 %1000, i32 %1003, i32 0
  %.state177 = load <8 x float>, ptr %.slot26, align 32
  %1005 = load <8 x float>, ptr %.slot30, align 32
  %1006 = select <8 x i1> %975, <8 x float> %.state177, <8 x float> %1005
  store <8 x float> %1006, ptr %.slot30, align 32
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  %.state178 = load <8 x float>, ptr %.slot30, align 32
  %.state179 = load <8 x float>, ptr %.slot27, align 32
  %1007 = fadd <8 x float> %.state178, %.state179
  %.state180 = load <8 x float>, ptr %.slot28, align 32
  %1008 = fadd <8 x float> %1007, %.state180
  %.state181 = load <8 x float>, ptr %.slot29, align 32
  %1009 = fadd <8 x float> %1008, %.state181
  %.spill.load182 = load <8 x i32>, ptr %.spill19, align 32
  %1010 = extractelement <8 x i32> %.spill.load182, i64 0
  %1011 = icmp ult i32 %1010, 8
  %1012 = select i1 %1011, i32 %1010, i32 0
  %1013 = extractelement <8 x i1> %55, i32 %1012
  %1014 = extractelement <8 x i1> %55, i64 0
  %1015 = and i1 %1011, %1013
  %1016 = and i1 %1014, %1015
  %1017 = extractelement <8 x float> %1009, i32 %1012
  %1018 = select i1 %1016, float %1017, float 0.000000e+00
  %1019 = insertelement <8 x float> poison, float %1018, i64 0
  %1020 = xor i1 %1016, true
  %1021 = and i1 %1014, %1020
  %1022 = insertelement <8 x i1> poison, i1 %1021, i64 0
  %1023 = extractelement <8 x i32> %.spill.load182, i64 1
  %1024 = icmp ult i32 %1023, 8
  %1025 = select i1 %1024, i32 %1023, i32 0
  %1026 = extractelement <8 x i1> %55, i32 %1025
  %1027 = extractelement <8 x i1> %55, i64 1
  %1028 = and i1 %1024, %1026
  %1029 = and i1 %1027, %1028
  %1030 = extractelement <8 x float> %1009, i32 %1025
  %1031 = select i1 %1029, float %1030, float 0.000000e+00
  %1032 = insertelement <8 x float> %1019, float %1031, i64 1
  %1033 = xor i1 %1029, true
  %1034 = and i1 %1027, %1033
  %1035 = insertelement <8 x i1> %1022, i1 %1034, i64 1
  %1036 = extractelement <8 x i32> %.spill.load182, i64 2
  %1037 = icmp ult i32 %1036, 8
  %1038 = select i1 %1037, i32 %1036, i32 0
  %1039 = extractelement <8 x i1> %55, i32 %1038
  %1040 = extractelement <8 x i1> %55, i64 2
  %1041 = and i1 %1037, %1039
  %1042 = and i1 %1040, %1041
  %1043 = extractelement <8 x float> %1009, i32 %1038
  %1044 = select i1 %1042, float %1043, float 0.000000e+00
  %1045 = insertelement <8 x float> %1032, float %1044, i64 2
  %1046 = xor i1 %1042, true
  %1047 = and i1 %1040, %1046
  %1048 = insertelement <8 x i1> %1035, i1 %1047, i64 2
  %1049 = extractelement <8 x i32> %.spill.load182, i64 3
  %1050 = icmp ult i32 %1049, 8
  %1051 = select i1 %1050, i32 %1049, i32 0
  %1052 = extractelement <8 x i1> %55, i32 %1051
  %1053 = extractelement <8 x i1> %55, i64 3
  %1054 = and i1 %1050, %1052
  %1055 = and i1 %1053, %1054
  %1056 = extractelement <8 x float> %1009, i32 %1051
  %1057 = select i1 %1055, float %1056, float 0.000000e+00
  %1058 = insertelement <8 x float> %1045, float %1057, i64 3
  %1059 = xor i1 %1055, true
  %1060 = and i1 %1053, %1059
  %1061 = insertelement <8 x i1> %1048, i1 %1060, i64 3
  %1062 = extractelement <8 x i32> %.spill.load182, i64 4
  %1063 = icmp ult i32 %1062, 8
  %1064 = select i1 %1063, i32 %1062, i32 0
  %1065 = extractelement <8 x i1> %55, i32 %1064
  %1066 = extractelement <8 x i1> %55, i64 4
  %1067 = and i1 %1063, %1065
  %1068 = and i1 %1066, %1067
  %1069 = extractelement <8 x float> %1009, i32 %1064
  %1070 = select i1 %1068, float %1069, float 0.000000e+00
  %1071 = insertelement <8 x float> %1058, float %1070, i64 4
  %1072 = xor i1 %1068, true
  %1073 = and i1 %1066, %1072
  %1074 = insertelement <8 x i1> %1061, i1 %1073, i64 4
  %1075 = extractelement <8 x i32> %.spill.load182, i64 5
  %1076 = icmp ult i32 %1075, 8
  %1077 = select i1 %1076, i32 %1075, i32 0
  %1078 = extractelement <8 x i1> %55, i32 %1077
  %1079 = extractelement <8 x i1> %55, i64 5
  %1080 = and i1 %1076, %1078
  %1081 = and i1 %1079, %1080
  %1082 = extractelement <8 x float> %1009, i32 %1077
  %1083 = select i1 %1081, float %1082, float 0.000000e+00
  %1084 = insertelement <8 x float> %1071, float %1083, i64 5
  %1085 = xor i1 %1081, true
  %1086 = and i1 %1079, %1085
  %1087 = insertelement <8 x i1> %1074, i1 %1086, i64 5
  %1088 = extractelement <8 x i32> %.spill.load182, i64 6
  %1089 = icmp ult i32 %1088, 8
  %1090 = select i1 %1089, i32 %1088, i32 0
  %1091 = extractelement <8 x i1> %55, i32 %1090
  %1092 = extractelement <8 x i1> %55, i64 6
  %1093 = and i1 %1089, %1091
  %1094 = and i1 %1092, %1093
  %1095 = extractelement <8 x float> %1009, i32 %1090
  %1096 = select i1 %1094, float %1095, float 0.000000e+00
  %1097 = insertelement <8 x float> %1084, float %1096, i64 6
  %1098 = xor i1 %1094, true
  %1099 = and i1 %1092, %1098
  %1100 = insertelement <8 x i1> %1087, i1 %1099, i64 6
  %1101 = extractelement <8 x i32> %.spill.load182, i64 7
  %1102 = icmp ult i32 %1101, 8
  %1103 = select i1 %1102, i32 %1101, i32 0
  %1104 = extractelement <8 x i1> %55, i32 %1103
  %1105 = extractelement <8 x i1> %55, i64 7
  %1106 = and i1 %1102, %1104
  %1107 = and i1 %1105, %1106
  %1108 = extractelement <8 x float> %1009, i32 %1103
  %1109 = select i1 %1107, float %1108, float 0.000000e+00
  %1110 = insertelement <8 x float> %1097, float %1109, i64 7
  %1111 = xor i1 %1107, true
  %1112 = and i1 %1105, %1111
  %1113 = insertelement <8 x i1> %1100, i1 %1112, i64 7
  %1114 = fadd <8 x float> %1009, %1110
  %.spill.load183 = load <8 x i32>, ptr %.spill20, align 32
  %1115 = extractelement <8 x i32> %.spill.load183, i64 0
  %1116 = icmp ult i32 %1115, 8
  %1117 = select i1 %1116, i32 %1115, i32 0
  %1118 = extractelement <8 x i1> %55, i32 %1117
  %1119 = extractelement <8 x i1> %55, i64 0
  %1120 = and i1 %1116, %1118
  %1121 = and i1 %1119, %1120
  %1122 = extractelement <8 x float> %1114, i32 %1117
  %1123 = select i1 %1121, float %1122, float 0.000000e+00
  %1124 = insertelement <8 x float> poison, float %1123, i64 0
  %1125 = xor i1 %1121, true
  %1126 = and i1 %1119, %1125
  %1127 = insertelement <8 x i1> poison, i1 %1126, i64 0
  %1128 = extractelement <8 x i32> %.spill.load183, i64 1
  %1129 = icmp ult i32 %1128, 8
  %1130 = select i1 %1129, i32 %1128, i32 0
  %1131 = extractelement <8 x i1> %55, i32 %1130
  %1132 = extractelement <8 x i1> %55, i64 1
  %1133 = and i1 %1129, %1131
  %1134 = and i1 %1132, %1133
  %1135 = extractelement <8 x float> %1114, i32 %1130
  %1136 = select i1 %1134, float %1135, float 0.000000e+00
  %1137 = insertelement <8 x float> %1124, float %1136, i64 1
  %1138 = xor i1 %1134, true
  %1139 = and i1 %1132, %1138
  %1140 = insertelement <8 x i1> %1127, i1 %1139, i64 1
  %1141 = extractelement <8 x i32> %.spill.load183, i64 2
  %1142 = icmp ult i32 %1141, 8
  %1143 = select i1 %1142, i32 %1141, i32 0
  %1144 = extractelement <8 x i1> %55, i32 %1143
  %1145 = extractelement <8 x i1> %55, i64 2
  %1146 = and i1 %1142, %1144
  %1147 = and i1 %1145, %1146
  %1148 = extractelement <8 x float> %1114, i32 %1143
  %1149 = select i1 %1147, float %1148, float 0.000000e+00
  %1150 = insertelement <8 x float> %1137, float %1149, i64 2
  %1151 = xor i1 %1147, true
  %1152 = and i1 %1145, %1151
  %1153 = insertelement <8 x i1> %1140, i1 %1152, i64 2
  %1154 = extractelement <8 x i32> %.spill.load183, i64 3
  %1155 = icmp ult i32 %1154, 8
  %1156 = select i1 %1155, i32 %1154, i32 0
  %1157 = extractelement <8 x i1> %55, i32 %1156
  %1158 = extractelement <8 x i1> %55, i64 3
  %1159 = and i1 %1155, %1157
  %1160 = and i1 %1158, %1159
  %1161 = extractelement <8 x float> %1114, i32 %1156
  %1162 = select i1 %1160, float %1161, float 0.000000e+00
  %1163 = insertelement <8 x float> %1150, float %1162, i64 3
  %1164 = xor i1 %1160, true
  %1165 = and i1 %1158, %1164
  %1166 = insertelement <8 x i1> %1153, i1 %1165, i64 3
  %1167 = extractelement <8 x i32> %.spill.load183, i64 4
  %1168 = icmp ult i32 %1167, 8
  %1169 = select i1 %1168, i32 %1167, i32 0
  %1170 = extractelement <8 x i1> %55, i32 %1169
  %1171 = extractelement <8 x i1> %55, i64 4
  %1172 = and i1 %1168, %1170
  %1173 = and i1 %1171, %1172
  %1174 = extractelement <8 x float> %1114, i32 %1169
  %1175 = select i1 %1173, float %1174, float 0.000000e+00
  %1176 = insertelement <8 x float> %1163, float %1175, i64 4
  %1177 = xor i1 %1173, true
  %1178 = and i1 %1171, %1177
  %1179 = insertelement <8 x i1> %1166, i1 %1178, i64 4
  %1180 = extractelement <8 x i32> %.spill.load183, i64 5
  %1181 = icmp ult i32 %1180, 8
  %1182 = select i1 %1181, i32 %1180, i32 0
  %1183 = extractelement <8 x i1> %55, i32 %1182
  %1184 = extractelement <8 x i1> %55, i64 5
  %1185 = and i1 %1181, %1183
  %1186 = and i1 %1184, %1185
  %1187 = extractelement <8 x float> %1114, i32 %1182
  %1188 = select i1 %1186, float %1187, float 0.000000e+00
  %1189 = insertelement <8 x float> %1176, float %1188, i64 5
  %1190 = xor i1 %1186, true
  %1191 = and i1 %1184, %1190
  %1192 = insertelement <8 x i1> %1179, i1 %1191, i64 5
  %1193 = extractelement <8 x i32> %.spill.load183, i64 6
  %1194 = icmp ult i32 %1193, 8
  %1195 = select i1 %1194, i32 %1193, i32 0
  %1196 = extractelement <8 x i1> %55, i32 %1195
  %1197 = extractelement <8 x i1> %55, i64 6
  %1198 = and i1 %1194, %1196
  %1199 = and i1 %1197, %1198
  %1200 = extractelement <8 x float> %1114, i32 %1195
  %1201 = select i1 %1199, float %1200, float 0.000000e+00
  %1202 = insertelement <8 x float> %1189, float %1201, i64 6
  %1203 = xor i1 %1199, true
  %1204 = and i1 %1197, %1203
  %1205 = insertelement <8 x i1> %1192, i1 %1204, i64 6
  %1206 = extractelement <8 x i32> %.spill.load183, i64 7
  %1207 = icmp ult i32 %1206, 8
  %1208 = select i1 %1207, i32 %1206, i32 0
  %1209 = extractelement <8 x i1> %55, i32 %1208
  %1210 = extractelement <8 x i1> %55, i64 7
  %1211 = and i1 %1207, %1209
  %1212 = and i1 %1210, %1211
  %1213 = extractelement <8 x float> %1114, i32 %1208
  %1214 = select i1 %1212, float %1213, float 0.000000e+00
  %1215 = insertelement <8 x float> %1202, float %1214, i64 7
  %1216 = xor i1 %1212, true
  %1217 = and i1 %1210, %1216
  %1218 = insertelement <8 x i1> %1205, i1 %1217, i64 7
  %1219 = fadd <8 x float> %1114, %1215
  %.spill.load184 = load <8 x i32>, ptr %.spill21, align 32
  %1220 = extractelement <8 x i32> %.spill.load184, i64 0
  %1221 = icmp ult i32 %1220, 8
  %1222 = select i1 %1221, i32 %1220, i32 0
  %1223 = extractelement <8 x i1> %55, i32 %1222
  %1224 = extractelement <8 x i1> %55, i64 0
  %1225 = and i1 %1221, %1223
  %1226 = and i1 %1224, %1225
  %1227 = extractelement <8 x float> %1219, i32 %1222
  %1228 = select i1 %1226, float %1227, float 0.000000e+00
  %1229 = insertelement <8 x float> poison, float %1228, i64 0
  %1230 = xor i1 %1226, true
  %1231 = and i1 %1224, %1230
  %1232 = insertelement <8 x i1> poison, i1 %1231, i64 0
  %1233 = extractelement <8 x i32> %.spill.load184, i64 1
  %1234 = icmp ult i32 %1233, 8
  %1235 = select i1 %1234, i32 %1233, i32 0
  %1236 = extractelement <8 x i1> %55, i32 %1235
  %1237 = extractelement <8 x i1> %55, i64 1
  %1238 = and i1 %1234, %1236
  %1239 = and i1 %1237, %1238
  %1240 = extractelement <8 x float> %1219, i32 %1235
  %1241 = select i1 %1239, float %1240, float 0.000000e+00
  %1242 = insertelement <8 x float> %1229, float %1241, i64 1
  %1243 = xor i1 %1239, true
  %1244 = and i1 %1237, %1243
  %1245 = insertelement <8 x i1> %1232, i1 %1244, i64 1
  %1246 = extractelement <8 x i32> %.spill.load184, i64 2
  %1247 = icmp ult i32 %1246, 8
  %1248 = select i1 %1247, i32 %1246, i32 0
  %1249 = extractelement <8 x i1> %55, i32 %1248
  %1250 = extractelement <8 x i1> %55, i64 2
  %1251 = and i1 %1247, %1249
  %1252 = and i1 %1250, %1251
  %1253 = extractelement <8 x float> %1219, i32 %1248
  %1254 = select i1 %1252, float %1253, float 0.000000e+00
  %1255 = insertelement <8 x float> %1242, float %1254, i64 2
  %1256 = xor i1 %1252, true
  %1257 = and i1 %1250, %1256
  %1258 = insertelement <8 x i1> %1245, i1 %1257, i64 2
  %1259 = extractelement <8 x i32> %.spill.load184, i64 3
  %1260 = icmp ult i32 %1259, 8
  %1261 = select i1 %1260, i32 %1259, i32 0
  %1262 = extractelement <8 x i1> %55, i32 %1261
  %1263 = extractelement <8 x i1> %55, i64 3
  %1264 = and i1 %1260, %1262
  %1265 = and i1 %1263, %1264
  %1266 = extractelement <8 x float> %1219, i32 %1261
  %1267 = select i1 %1265, float %1266, float 0.000000e+00
  %1268 = insertelement <8 x float> %1255, float %1267, i64 3
  %1269 = xor i1 %1265, true
  %1270 = and i1 %1263, %1269
  %1271 = insertelement <8 x i1> %1258, i1 %1270, i64 3
  %1272 = extractelement <8 x i32> %.spill.load184, i64 4
  %1273 = icmp ult i32 %1272, 8
  %1274 = select i1 %1273, i32 %1272, i32 0
  %1275 = extractelement <8 x i1> %55, i32 %1274
  %1276 = extractelement <8 x i1> %55, i64 4
  %1277 = and i1 %1273, %1275
  %1278 = and i1 %1276, %1277
  %1279 = extractelement <8 x float> %1219, i32 %1274
  %1280 = select i1 %1278, float %1279, float 0.000000e+00
  %1281 = insertelement <8 x float> %1268, float %1280, i64 4
  %1282 = xor i1 %1278, true
  %1283 = and i1 %1276, %1282
  %1284 = insertelement <8 x i1> %1271, i1 %1283, i64 4
  %1285 = extractelement <8 x i32> %.spill.load184, i64 5
  %1286 = icmp ult i32 %1285, 8
  %1287 = select i1 %1286, i32 %1285, i32 0
  %1288 = extractelement <8 x i1> %55, i32 %1287
  %1289 = extractelement <8 x i1> %55, i64 5
  %1290 = and i1 %1286, %1288
  %1291 = and i1 %1289, %1290
  %1292 = extractelement <8 x float> %1219, i32 %1287
  %1293 = select i1 %1291, float %1292, float 0.000000e+00
  %1294 = insertelement <8 x float> %1281, float %1293, i64 5
  %1295 = xor i1 %1291, true
  %1296 = and i1 %1289, %1295
  %1297 = insertelement <8 x i1> %1284, i1 %1296, i64 5
  %1298 = extractelement <8 x i32> %.spill.load184, i64 6
  %1299 = icmp ult i32 %1298, 8
  %1300 = select i1 %1299, i32 %1298, i32 0
  %1301 = extractelement <8 x i1> %55, i32 %1300
  %1302 = extractelement <8 x i1> %55, i64 6
  %1303 = and i1 %1299, %1301
  %1304 = and i1 %1302, %1303
  %1305 = extractelement <8 x float> %1219, i32 %1300
  %1306 = select i1 %1304, float %1305, float 0.000000e+00
  %1307 = insertelement <8 x float> %1294, float %1306, i64 6
  %1308 = xor i1 %1304, true
  %1309 = and i1 %1302, %1308
  %1310 = insertelement <8 x i1> %1297, i1 %1309, i64 6
  %1311 = extractelement <8 x i32> %.spill.load184, i64 7
  %1312 = icmp ult i32 %1311, 8
  %1313 = select i1 %1312, i32 %1311, i32 0
  %1314 = extractelement <8 x i1> %55, i32 %1313
  %1315 = extractelement <8 x i1> %55, i64 7
  %1316 = and i1 %1312, %1314
  %1317 = and i1 %1315, %1316
  %1318 = extractelement <8 x float> %1219, i32 %1313
  %1319 = select i1 %1317, float %1318, float 0.000000e+00
  %1320 = insertelement <8 x float> %1307, float %1319, i64 7
  %1321 = xor i1 %1317, true
  %1322 = and i1 %1315, %1321
  %1323 = insertelement <8 x i1> %1310, i1 %1322, i64 7
  %1324 = fadd <8 x float> %1219, %1320
  %1325 = extractelement <8 x i1> %55, i32 0
  %1326 = extractelement <8 x i1> %55, i64 0
  %1327 = and i1 true, %1325
  %1328 = and i1 %1326, %1327
  %1329 = extractelement <8 x float> %1324, i32 0
  %1330 = select i1 %1328, float %1329, float 0.000000e+00
  %1331 = insertelement <8 x float> poison, float %1330, i64 0
  %1332 = xor i1 %1328, true
  %1333 = and i1 %1326, %1332
  %1334 = insertelement <8 x i1> poison, i1 %1333, i64 0
  %1335 = extractelement <8 x i1> %55, i32 0
  %1336 = extractelement <8 x i1> %55, i64 1
  %1337 = and i1 true, %1335
  %1338 = and i1 %1336, %1337
  %1339 = extractelement <8 x float> %1324, i32 0
  %1340 = select i1 %1338, float %1339, float 0.000000e+00
  %1341 = insertelement <8 x float> %1331, float %1340, i64 1
  %1342 = xor i1 %1338, true
  %1343 = and i1 %1336, %1342
  %1344 = insertelement <8 x i1> %1334, i1 %1343, i64 1
  %1345 = extractelement <8 x i1> %55, i32 0
  %1346 = extractelement <8 x i1> %55, i64 2
  %1347 = and i1 true, %1345
  %1348 = and i1 %1346, %1347
  %1349 = extractelement <8 x float> %1324, i32 0
  %1350 = select i1 %1348, float %1349, float 0.000000e+00
  %1351 = insertelement <8 x float> %1341, float %1350, i64 2
  %1352 = xor i1 %1348, true
  %1353 = and i1 %1346, %1352
  %1354 = insertelement <8 x i1> %1344, i1 %1353, i64 2
  %1355 = extractelement <8 x i1> %55, i32 0
  %1356 = extractelement <8 x i1> %55, i64 3
  %1357 = and i1 true, %1355
  %1358 = and i1 %1356, %1357
  %1359 = extractelement <8 x float> %1324, i32 0
  %1360 = select i1 %1358, float %1359, float 0.000000e+00
  %1361 = insertelement <8 x float> %1351, float %1360, i64 3
  %1362 = xor i1 %1358, true
  %1363 = and i1 %1356, %1362
  %1364 = insertelement <8 x i1> %1354, i1 %1363, i64 3
  %1365 = extractelement <8 x i1> %55, i32 0
  %1366 = extractelement <8 x i1> %55, i64 4
  %1367 = and i1 true, %1365
  %1368 = and i1 %1366, %1367
  %1369 = extractelement <8 x float> %1324, i32 0
  %1370 = select i1 %1368, float %1369, float 0.000000e+00
  %1371 = insertelement <8 x float> %1361, float %1370, i64 4
  %1372 = xor i1 %1368, true
  %1373 = and i1 %1366, %1372
  %1374 = insertelement <8 x i1> %1364, i1 %1373, i64 4
  %1375 = extractelement <8 x i1> %55, i32 0
  %1376 = extractelement <8 x i1> %55, i64 5
  %1377 = and i1 true, %1375
  %1378 = and i1 %1376, %1377
  %1379 = extractelement <8 x float> %1324, i32 0
  %1380 = select i1 %1378, float %1379, float 0.000000e+00
  %1381 = insertelement <8 x float> %1371, float %1380, i64 5
  %1382 = xor i1 %1378, true
  %1383 = and i1 %1376, %1382
  %1384 = insertelement <8 x i1> %1374, i1 %1383, i64 5
  %1385 = extractelement <8 x i1> %55, i32 0
  %1386 = extractelement <8 x i1> %55, i64 6
  %1387 = and i1 true, %1385
  %1388 = and i1 %1386, %1387
  %1389 = extractelement <8 x float> %1324, i32 0
  %1390 = select i1 %1388, float %1389, float 0.000000e+00
  %1391 = insertelement <8 x float> %1381, float %1390, i64 6
  %1392 = xor i1 %1388, true
  %1393 = and i1 %1386, %1392
  %1394 = insertelement <8 x i1> %1384, i1 %1393, i64 6
  %1395 = extractelement <8 x i1> %55, i32 0
  %1396 = extractelement <8 x i1> %55, i64 7
  %1397 = and i1 true, %1395
  %1398 = and i1 %1396, %1397
  %1399 = extractelement <8 x float> %1324, i32 0
  %1400 = select i1 %1398, float %1399, float 0.000000e+00
  %1401 = insertelement <8 x float> %1391, float %1400, i64 7
  %1402 = xor i1 %1398, true
  %1403 = and i1 %1396, %1402
  %1404 = insertelement <8 x i1> %1394, i1 %1403, i64 7
  %1405 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1406 = bitcast <8 x i1> %55 to i8
  %1407 = call i8 @llvm.cttz.i8(i8 %1406, i1 false)
  %1408 = zext i8 %1407 to i32
  %1409 = select i1 %1405, i32 %1408, i32 0
  %1410 = extractelement <8 x float> %1401, i32 %1409
  %1411 = fadd float 0.000000e+00, %1410
  %1412 = fdiv float %1411, 6.500000e+01
  store float %1412, ptr %.spill31, align 4
  %1413 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1414 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %1413, 0
  %1416 = select <8 x i1> %55, <8 x ptr> %1414, <8 x ptr> %1415
  %1417 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %1418 = extractvalue { <8 x ptr>, <8 x i64> } %1413, 1
  %1419 = select <8 x i1> %55, <8 x i64> %1417, <8 x i64> %1418
  %1420 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1416, 0
  %1421 = insertvalue { <8 x ptr>, <8 x i64> } %1420, <8 x i64> %1419, 1
  store { <8 x ptr>, <8 x i64> } %1421, ptr %tile_snapshot.spill32, align 64
  %1422 = load <8 x i64>, ptr %.slot33, align 64
  %1423 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %1422
  store <8 x i64> %1423, ptr %.slot33, align 64
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state185 = load <8 x i64>, ptr %.slot33, align 64
  %1424 = icmp slt <8 x i64> %.state185, splat (i64 8)
  %1425 = extractelement <8 x i1> %1424, i32 0
  br i1 %1425, label %direct.true186, label %direct.false187

direct.schedule.22:                               ; preds = %direct.true186
  %.state188 = load <8 x i64>, ptr %.slot33, align 64
  %1426 = mul <8 x i64> %.state188, splat (i64 8)
  %.spill.load189 = load <8 x i64>, ptr %.spill, align 64
  %1427 = add <8 x i64> %1426, %.spill.load189
  %.spill.load190 = load i64, ptr %.spill12, align 4
  %1428 = add i64 %.spill.load190, 0
  %1429 = add <8 x i64> zeroinitializer, %1427
  %1430 = mul i64 %1428, 65
  %.splatinsert191 = insertelement <8 x i64> poison, i64 %1430, i64 0
  %.splat192 = shufflevector <8 x i64> %.splatinsert191, <8 x i64> poison, <8 x i32> zeroinitializer
  %1431 = add <8 x i64> %.splat192, %1429
  %1432 = extractvalue { ptr, i64 } %19, 0
  %1433 = extractelement <8 x i64> %1431, i32 0
  %1434 = sub i64 %1433, 0
  %1435 = mul i64 %1434, 4
  %buffer.contiguous.address193 = getelementptr i8, ptr %1432, i64 %1435
  %buffer.contiguous.load194 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address193, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load195 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 0
  %1437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 1
  %.state196 = load <8 x i64>, ptr %.slot33, align 64
  %1438 = mul <8 x i64> %.state196, splat (i64 32)
  %1439 = add <8 x i64> %1437, %1438
  %1440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1436, 0
  %1441 = insertvalue { <8 x ptr>, <8 x i64> } %1440, <8 x i64> %1439, 1
  %1442 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1443 = extractvalue { <8 x ptr>, <8 x i64> } %1441, 1
  %1444 = extractelement <8 x ptr> %1442, i32 0
  %1445 = extractelement <8 x i64> %1443, i32 0
  %1446 = sub i64 %1445, 0
  %1447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1448 = select i1 %1447, i64 %1446, i64 0
  %private.contiguous.address197 = getelementptr i8, ptr %1444, i64 %1448
  %private.contiguous.preserve198 = load <8 x float>, ptr %private.contiguous.address197, align 4
  %1449 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load194, <8 x float> %private.contiguous.preserve198
  store <8 x float> %1449, ptr %private.contiguous.address197, align 4
  %.state199 = load <8 x i64>, ptr %.slot33, align 64
  %1450 = add <8 x i64> %.state199, splat (i64 1)
  %1451 = load <8 x i64>, ptr %.slot33, align 64
  %1452 = select <8 x i1> %55, <8 x i64> %1450, <8 x i64> %1451
  store <8 x i64> %1452, ptr %.slot33, align 64
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false187
  %.spill.load200 = load <8 x i1>, ptr %.spill11, align 1
  %1453 = and <8 x i1> %55, %.spill.load200
  %1454 = xor <8 x i1> %.spill.load200, splat (i1 true)
  %1455 = and <8 x i1> %55, %1454
  %1456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1453)
  %1457 = bitcast <8 x i1> %1453 to i8
  %1458 = call i8 @llvm.cttz.i8(i8 %1457, i1 false)
  %1459 = zext i8 %1458 to i32
  %1460 = select i1 %1456, i32 %1459, i32 0
  %.spill.load201 = load <8 x i64>, ptr %.spill, align 64
  %1461 = add <8 x i64> splat (i64 64), %.spill.load201
  %.spill.load202 = load i64, ptr %.spill12, align 4
  %1462 = add i64 %.spill.load202, 0
  %1463 = add <8 x i64> zeroinitializer, %1461
  %1464 = mul i64 %1462, 65
  %.splatinsert203 = insertelement <8 x i64> poison, i64 %1464, i64 0
  %.splat204 = shufflevector <8 x i64> %.splatinsert203, <8 x i64> poison, <8 x i32> zeroinitializer
  %1465 = add <8 x i64> %.splat204, %1463
  %1466 = extractvalue { ptr, i64 } %19, 0
  %1467 = select <8 x i1> %1453, <8 x i64> %1465, <8 x i64> zeroinitializer
  %1468 = extractelement <8 x i64> %1467, i32 %1460
  %1469 = zext i32 %1460 to i64
  %1470 = sub i64 %1468, %1469
  %1471 = mul i64 %1470, 4
  %buffer.contiguous.address205 = getelementptr i8, ptr %1466, i64 %1471
  %buffer.contiguous.load206 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address205, <8 x i1> %1453, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load207 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1472 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load207, 0
  %1473 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load207, 1
  %1474 = add <8 x i64> %1473, splat (i64 256)
  %1475 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1472, 0
  %1476 = insertvalue { <8 x ptr>, <8 x i64> } %1475, <8 x i64> %1474, 1
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1478 = extractvalue { <8 x ptr>, <8 x i64> } %1476, 1
  %1479 = extractelement <8 x ptr> %1477, i32 0
  %1480 = extractelement <8 x i64> %1478, i32 %1460
  %1481 = zext i32 %1460 to i64
  %1482 = mul i64 %1481, 4
  %1483 = sub i64 %1480, %1482
  %1484 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1453)
  %1485 = select i1 %1484, i64 %1483, i64 0
  %private.contiguous.address208 = getelementptr i8, ptr %1479, i64 %1485
  %private.contiguous.preserve209 = load <8 x float>, ptr %private.contiguous.address208, align 4
  %1486 = select <8 x i1> %1453, <8 x float> %buffer.contiguous.load206, <8 x float> %private.contiguous.preserve209
  store <8 x float> %1486, ptr %private.contiguous.address208, align 4
  %1487 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1455)
  %1488 = bitcast <8 x i1> %1455 to i8
  %1489 = call i8 @llvm.cttz.i8(i8 %1488, i1 false)
  %1490 = zext i8 %1489 to i32
  %1491 = select i1 %1487, i32 %1490, i32 0
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.23
  %.spill.load210 = load float, ptr %.spill31, align 4
  %1492 = fadd float %.spill.load210, 0x3EE4F8B580000000
  %1493 = call float @llvm.sqrt.f32(float %1492)
  store float %1493, ptr %.spill34, align 4
  %1494 = extractvalue { ptr, i64 } %25, 1
  %1495 = extractvalue { ptr, i64 } %25, 0
  %1496 = ptrtoint ptr %1495 to i64
  %1497 = extractvalue { ptr, i64 } %31, 1
  %1498 = extractvalue { ptr, i64 } %31, 0
  %1499 = ptrtoint ptr %1498 to i64
  %1500 = icmp uge i64 %1496, %1499
  %1501 = sub i64 %1496, %1499
  %1502 = icmp uge i64 %1501, 4420
  %1503 = and i1 %1500, %1502
  %1504 = icmp uge i64 %1499, %1496
  %1505 = sub i64 %1499, %1496
  %1506 = icmp uge i64 %1505, 260
  %1507 = and i1 %1504, %1506
  %1508 = or i1 %1503, %1507
  %1509 = and i1 true, %1508
  br i1 %1509, label %direct.true211, label %direct.false212

direct.schedule.26:                               ; preds = %direct.true211
  %1510 = load <8 x i64>, ptr %.slot35, align 64
  %1511 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %1510
  store <8 x i64> %1511, ptr %.slot35, align 64
  br label %direct.schedule.27

direct.schedule.27:                               ; preds = %direct.schedule.28, %direct.schedule.26
  %.state213 = load <8 x i64>, ptr %.slot35, align 64
  %1512 = icmp slt <8 x i64> %.state213, splat (i64 8)
  %1513 = extractelement <8 x i1> %1512, i32 0
  br i1 %1513, label %direct.true214, label %direct.false215

direct.schedule.28:                               ; preds = %direct.true214
  %.state216 = load <8 x i64>, ptr %.slot35, align 64
  %1514 = mul <8 x i64> %.state216, splat (i64 8)
  %.spill.load217 = load <8 x i64>, ptr %.spill, align 64
  %1515 = add <8 x i64> %1514, %.spill.load217
  %tile_snapshot.spill.load218 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 0
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load218, 1
  %.state219 = load <8 x i64>, ptr %.slot35, align 64
  %1518 = mul <8 x i64> %.state219, splat (i64 32)
  %1519 = add <8 x i64> %1517, %1518
  %1520 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1516, 0
  %1521 = insertvalue { <8 x ptr>, <8 x i64> } %1520, <8 x i64> %1519, 1
  %1522 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1523 = extractvalue { <8 x ptr>, <8 x i64> } %1521, 1
  %1524 = extractelement <8 x ptr> %1522, i32 0
  %1525 = extractelement <8 x i64> %1523, i32 0
  %1526 = sub i64 %1525, 0
  %1527 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1528 = select i1 %1527, i64 %1526, i64 0
  %private.contiguous.address220 = getelementptr i8, ptr %1524, i64 %1528
  %private.contiguous.load221 = load <8 x float>, ptr %private.contiguous.address220, align 4
  %1529 = select <8 x i1> %55, <8 x float> %private.contiguous.load221, <8 x float> zeroinitializer
  %.spill.load222 = load float, ptr %.spill34, align 4
  %.splatinsert223 = insertelement <8 x float> poison, float %.spill.load222, i64 0
  %.splat224 = shufflevector <8 x float> %.splatinsert223, <8 x float> poison, <8 x i32> zeroinitializer
  %1530 = fdiv <8 x float> %1529, %.splat224
  %tile_snapshot.spill.load225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1531 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 0
  %1532 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 1
  %.state226 = load <8 x i64>, ptr %.slot35, align 64
  %1533 = mul <8 x i64> %.state226, splat (i64 32)
  %1534 = add <8 x i64> %1532, %1533
  %1535 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1531, 0
  %1536 = insertvalue { <8 x ptr>, <8 x i64> } %1535, <8 x i64> %1534, 1
  %1537 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %1536, 1
  %1539 = extractelement <8 x ptr> %1537, i32 0
  %1540 = extractelement <8 x i64> %1538, i32 0
  %1541 = sub i64 %1540, 0
  %1542 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1543 = select i1 %1542, i64 %1541, i64 0
  %private.contiguous.address227 = getelementptr i8, ptr %1539, i64 %1543
  %private.contiguous.load228 = load <8 x float>, ptr %private.contiguous.address227, align 4
  %1544 = select <8 x i1> %55, <8 x float> %private.contiguous.load228, <8 x float> zeroinitializer
  %1545 = fmul <8 x float> %1530, %1544
  %.spill.load229 = load i64, ptr %.spill12, align 4
  %1546 = add i64 %.spill.load229, 0
  %1547 = add <8 x i64> zeroinitializer, %1515
  %1548 = mul i64 %1546, 65
  %.splatinsert230 = insertelement <8 x i64> poison, i64 %1548, i64 0
  %.splat231 = shufflevector <8 x i64> %.splatinsert230, <8 x i64> poison, <8 x i32> zeroinitializer
  %1549 = add <8 x i64> %.splat231, %1547
  %1550 = extractvalue { ptr, i64 } %25, 0
  %1551 = extractelement <8 x i64> %1549, i32 0
  %1552 = sub i64 %1551, 0
  %1553 = mul i64 %1552, 4
  %buffer.contiguous.address232 = getelementptr i8, ptr %1550, i64 %1553
  %buffer.contiguous.load233 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address232, <8 x i1> %55, <8 x float> zeroinitializer)
  %1554 = fadd <8 x float> %1545, %buffer.contiguous.load233
  %.spill.load234 = load <8 x i64>, ptr %.spill10, align 64
  %1555 = add <8 x i64> %.spill.load234, zeroinitializer
  %1556 = add <8 x i64> zeroinitializer, %1555
  %1557 = mul <8 x i64> %1556, splat (i64 65)
  %1558 = add <8 x i64> %1557, %1547
  %1559 = extractvalue { ptr, i64 } %31, 0
  %1560 = extractelement <8 x i64> %1558, i32 0
  %1561 = sub i64 %1560, 0
  %1562 = mul i64 %1561, 4
  %buffer.contiguous.address235 = getelementptr i8, ptr %1559, i64 %1562
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1554, ptr align 1 %buffer.contiguous.address235, <8 x i1> %55)
  %.state236 = load <8 x i64>, ptr %.slot35, align 64
  %1563 = add <8 x i64> %.state236, splat (i64 1)
  %1564 = load <8 x i64>, ptr %.slot35, align 64
  %1565 = select <8 x i1> %55, <8 x i64> %1563, <8 x i64> %1564
  store <8 x i64> %1565, ptr %.slot35, align 64
  br label %direct.schedule.27

direct.schedule.29:                               ; preds = %direct.false215
  %.spill.load237 = load <8 x i1>, ptr %.spill11, align 1
  %1566 = and <8 x i1> %55, %.spill.load237
  %1567 = xor <8 x i1> %.spill.load237, splat (i1 true)
  %1568 = and <8 x i1> %55, %1567
  %1569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1566)
  %1570 = bitcast <8 x i1> %1566 to i8
  %1571 = call i8 @llvm.cttz.i8(i8 %1570, i1 false)
  %1572 = zext i8 %1571 to i32
  %1573 = select i1 %1569, i32 %1572, i32 0
  %.spill.load238 = load <8 x i64>, ptr %.spill, align 64
  %1574 = add <8 x i64> splat (i64 64), %.spill.load238
  %tile_snapshot.spill.load239 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 0
  %1576 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 1
  %1577 = add <8 x i64> %1576, splat (i64 256)
  %1578 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1575, 0
  %1579 = insertvalue { <8 x ptr>, <8 x i64> } %1578, <8 x i64> %1577, 1
  %1580 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1581 = extractvalue { <8 x ptr>, <8 x i64> } %1579, 1
  %1582 = extractelement <8 x ptr> %1580, i32 0
  %1583 = extractelement <8 x i64> %1581, i32 %1573
  %1584 = zext i32 %1573 to i64
  %1585 = mul i64 %1584, 4
  %1586 = sub i64 %1583, %1585
  %1587 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1566)
  %1588 = select i1 %1587, i64 %1586, i64 0
  %private.contiguous.address240 = getelementptr i8, ptr %1582, i64 %1588
  %private.contiguous.load241 = load <8 x float>, ptr %private.contiguous.address240, align 4
  %1589 = select <8 x i1> %1566, <8 x float> %private.contiguous.load241, <8 x float> zeroinitializer
  %.spill.load242 = load float, ptr %.spill34, align 4
  %.splatinsert243 = insertelement <8 x float> poison, float %.spill.load242, i64 0
  %.splat244 = shufflevector <8 x float> %.splatinsert243, <8 x float> poison, <8 x i32> zeroinitializer
  %1590 = fdiv <8 x float> %1589, %.splat244
  %tile_snapshot.spill.load245 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 0
  %1592 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 1
  %1593 = add <8 x i64> %1592, splat (i64 256)
  %1594 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1591, 0
  %1595 = insertvalue { <8 x ptr>, <8 x i64> } %1594, <8 x i64> %1593, 1
  %1596 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1597 = extractvalue { <8 x ptr>, <8 x i64> } %1595, 1
  %1598 = extractelement <8 x ptr> %1596, i32 0
  %1599 = extractelement <8 x i64> %1597, i32 %1573
  %1600 = zext i32 %1573 to i64
  %1601 = mul i64 %1600, 4
  %1602 = sub i64 %1599, %1601
  %1603 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1566)
  %1604 = select i1 %1603, i64 %1602, i64 0
  %private.contiguous.address246 = getelementptr i8, ptr %1598, i64 %1604
  %private.contiguous.load247 = load <8 x float>, ptr %private.contiguous.address246, align 4
  %1605 = select <8 x i1> %1566, <8 x float> %private.contiguous.load247, <8 x float> zeroinitializer
  %1606 = fmul <8 x float> %1590, %1605
  %.spill.load248 = load i64, ptr %.spill12, align 4
  %1607 = add i64 %.spill.load248, 0
  %1608 = add <8 x i64> zeroinitializer, %1574
  %1609 = mul i64 %1607, 65
  %.splatinsert249 = insertelement <8 x i64> poison, i64 %1609, i64 0
  %.splat250 = shufflevector <8 x i64> %.splatinsert249, <8 x i64> poison, <8 x i32> zeroinitializer
  %1610 = add <8 x i64> %.splat250, %1608
  %1611 = extractvalue { ptr, i64 } %25, 0
  %1612 = select <8 x i1> %1566, <8 x i64> %1610, <8 x i64> zeroinitializer
  %1613 = extractelement <8 x i64> %1612, i32 %1573
  %1614 = zext i32 %1573 to i64
  %1615 = sub i64 %1613, %1614
  %1616 = mul i64 %1615, 4
  %buffer.contiguous.address251 = getelementptr i8, ptr %1611, i64 %1616
  %buffer.contiguous.load252 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address251, <8 x i1> %1566, <8 x float> zeroinitializer)
  %1617 = fadd <8 x float> %1606, %buffer.contiguous.load252
  %.spill.load253 = load <8 x i64>, ptr %.spill10, align 64
  %1618 = add <8 x i64> %.spill.load253, zeroinitializer
  %1619 = add <8 x i64> zeroinitializer, %1618
  %1620 = mul <8 x i64> %1619, splat (i64 65)
  %1621 = add <8 x i64> %1620, %1608
  %1622 = extractvalue { ptr, i64 } %31, 0
  %1623 = extractelement <8 x i64> %1621, i32 %1573
  %1624 = zext i32 %1573 to i64
  %1625 = sub i64 %1623, %1624
  %1626 = mul i64 %1625, 4
  %buffer.contiguous.address254 = getelementptr i8, ptr %1622, i64 %1626
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1617, ptr align 1 %buffer.contiguous.address254, <8 x i1> %1566)
  %1627 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1568)
  %1628 = bitcast <8 x i1> %1568 to i8
  %1629 = call i8 @llvm.cttz.i8(i8 %1628, i1 false)
  %1630 = zext i8 %1629 to i32
  %1631 = select i1 %1627, i32 %1630, i32 0
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.40, %direct.schedule.29
  ret void

direct.schedule.32:                               ; preds = %direct.false212
  %1632 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill36, align 64
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1634 = extractvalue { <8 x ptr>, <8 x i64> } %1632, 0
  %1635 = select <8 x i1> %55, <8 x ptr> %1633, <8 x ptr> %1634
  %1636 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %1637 = extractvalue { <8 x ptr>, <8 x i64> } %1632, 1
  %1638 = select <8 x i1> %55, <8 x i64> %1636, <8 x i64> %1637
  %1639 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1635, 0
  %1640 = insertvalue { <8 x ptr>, <8 x i64> } %1639, <8 x i64> %1638, 1
  store { <8 x ptr>, <8 x i64> } %1640, ptr %tile_snapshot.spill36, align 64
  %1641 = load <8 x i64>, ptr %.slot37, align 64
  %1642 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %1641
  store <8 x i64> %1642, ptr %.slot37, align 64
  br label %direct.schedule.33

direct.schedule.33:                               ; preds = %direct.schedule.34, %direct.schedule.32
  %.state255 = load <8 x i64>, ptr %.slot37, align 64
  %1643 = icmp slt <8 x i64> %.state255, splat (i64 8)
  %1644 = extractelement <8 x i1> %1643, i32 0
  br i1 %1644, label %direct.true256, label %direct.false257

direct.schedule.34:                               ; preds = %direct.true256
  %.state258 = load <8 x i64>, ptr %.slot37, align 64
  %1645 = mul <8 x i64> %.state258, splat (i64 8)
  %.spill.load259 = load <8 x i64>, ptr %.spill, align 64
  %1646 = add <8 x i64> %1645, %.spill.load259
  %.spill.load260 = load i64, ptr %.spill12, align 4
  %1647 = add i64 %.spill.load260, 0
  %1648 = add <8 x i64> zeroinitializer, %1646
  %1649 = mul i64 %1647, 65
  %.splatinsert261 = insertelement <8 x i64> poison, i64 %1649, i64 0
  %.splat262 = shufflevector <8 x i64> %.splatinsert261, <8 x i64> poison, <8 x i32> zeroinitializer
  %1650 = add <8 x i64> %.splat262, %1648
  %1651 = extractvalue { ptr, i64 } %25, 0
  %1652 = extractelement <8 x i64> %1650, i32 0
  %1653 = sub i64 %1652, 0
  %1654 = mul i64 %1653, 4
  %buffer.contiguous.address263 = getelementptr i8, ptr %1651, i64 %1654
  %buffer.contiguous.load264 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address263, <8 x i1> %55, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load265 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill36, align 64
  %1655 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 0
  %1656 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 1
  %.state266 = load <8 x i64>, ptr %.slot37, align 64
  %1657 = mul <8 x i64> %.state266, splat (i64 32)
  %1658 = add <8 x i64> %1656, %1657
  %1659 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1655, 0
  %1660 = insertvalue { <8 x ptr>, <8 x i64> } %1659, <8 x i64> %1658, 1
  %1661 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1662 = extractvalue { <8 x ptr>, <8 x i64> } %1660, 1
  %1663 = extractelement <8 x ptr> %1661, i32 0
  %1664 = extractelement <8 x i64> %1662, i32 0
  %1665 = sub i64 %1664, 0
  %1666 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1667 = select i1 %1666, i64 %1665, i64 0
  %private.contiguous.address267 = getelementptr i8, ptr %1663, i64 %1667
  %private.contiguous.preserve268 = load <8 x float>, ptr %private.contiguous.address267, align 4
  %1668 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load264, <8 x float> %private.contiguous.preserve268
  store <8 x float> %1668, ptr %private.contiguous.address267, align 4
  %.state269 = load <8 x i64>, ptr %.slot37, align 64
  %1669 = add <8 x i64> %.state269, splat (i64 1)
  %1670 = load <8 x i64>, ptr %.slot37, align 64
  %1671 = select <8 x i1> %55, <8 x i64> %1669, <8 x i64> %1670
  store <8 x i64> %1671, ptr %.slot37, align 64
  br label %direct.schedule.33

direct.schedule.35:                               ; preds = %direct.false257
  %.spill.load270 = load <8 x i1>, ptr %.spill11, align 1
  %1672 = and <8 x i1> %55, %.spill.load270
  %1673 = xor <8 x i1> %.spill.load270, splat (i1 true)
  %1674 = and <8 x i1> %55, %1673
  %1675 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1672)
  %1676 = bitcast <8 x i1> %1672 to i8
  %1677 = call i8 @llvm.cttz.i8(i8 %1676, i1 false)
  %1678 = zext i8 %1677 to i32
  %1679 = select i1 %1675, i32 %1678, i32 0
  %.spill.load271 = load <8 x i64>, ptr %.spill, align 64
  %1680 = add <8 x i64> splat (i64 64), %.spill.load271
  %.spill.load272 = load i64, ptr %.spill12, align 4
  %1681 = add i64 %.spill.load272, 0
  %1682 = add <8 x i64> zeroinitializer, %1680
  %1683 = mul i64 %1681, 65
  %.splatinsert273 = insertelement <8 x i64> poison, i64 %1683, i64 0
  %.splat274 = shufflevector <8 x i64> %.splatinsert273, <8 x i64> poison, <8 x i32> zeroinitializer
  %1684 = add <8 x i64> %.splat274, %1682
  %1685 = extractvalue { ptr, i64 } %25, 0
  %1686 = select <8 x i1> %1672, <8 x i64> %1684, <8 x i64> zeroinitializer
  %1687 = extractelement <8 x i64> %1686, i32 %1679
  %1688 = zext i32 %1679 to i64
  %1689 = sub i64 %1687, %1688
  %1690 = mul i64 %1689, 4
  %buffer.contiguous.address275 = getelementptr i8, ptr %1685, i64 %1690
  %buffer.contiguous.load276 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address275, <8 x i1> %1672, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load277 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill36, align 64
  %1691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 0
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 1
  %1693 = add <8 x i64> %1692, splat (i64 256)
  %1694 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1691, 0
  %1695 = insertvalue { <8 x ptr>, <8 x i64> } %1694, <8 x i64> %1693, 1
  %1696 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1697 = extractvalue { <8 x ptr>, <8 x i64> } %1695, 1
  %1698 = extractelement <8 x ptr> %1696, i32 0
  %1699 = extractelement <8 x i64> %1697, i32 %1679
  %1700 = zext i32 %1679 to i64
  %1701 = mul i64 %1700, 4
  %1702 = sub i64 %1699, %1701
  %1703 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1672)
  %1704 = select i1 %1703, i64 %1702, i64 0
  %private.contiguous.address278 = getelementptr i8, ptr %1698, i64 %1704
  %private.contiguous.preserve279 = load <8 x float>, ptr %private.contiguous.address278, align 4
  %1705 = select <8 x i1> %1672, <8 x float> %buffer.contiguous.load276, <8 x float> %private.contiguous.preserve279
  store <8 x float> %1705, ptr %private.contiguous.address278, align 4
  %1706 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1674)
  %1707 = bitcast <8 x i1> %1674 to i8
  %1708 = call i8 @llvm.cttz.i8(i8 %1707, i1 false)
  %1709 = zext i8 %1708 to i32
  %1710 = select i1 %1706, i32 %1709, i32 0
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.35
  %1711 = load <8 x i64>, ptr %.slot38, align 64
  %1712 = select <8 x i1> %55, <8 x i64> zeroinitializer, <8 x i64> %1711
  store <8 x i64> %1712, ptr %.slot38, align 64
  br label %direct.schedule.38

direct.schedule.38:                               ; preds = %direct.schedule.39, %direct.schedule.37
  %.state280 = load <8 x i64>, ptr %.slot38, align 64
  %1713 = icmp slt <8 x i64> %.state280, splat (i64 8)
  %1714 = extractelement <8 x i1> %1713, i32 0
  br i1 %1714, label %direct.true281, label %direct.false282

direct.schedule.39:                               ; preds = %direct.true281
  %.state283 = load <8 x i64>, ptr %.slot38, align 64
  %1715 = mul <8 x i64> %.state283, splat (i64 8)
  %.spill.load284 = load <8 x i64>, ptr %.spill, align 64
  %1716 = add <8 x i64> %1715, %.spill.load284
  %.spill.load285 = load <8 x i64>, ptr %.spill10, align 64
  %1717 = add <8 x i64> %.spill.load285, zeroinitializer
  %1718 = add <8 x i64> zeroinitializer, %1717
  %1719 = add <8 x i64> zeroinitializer, %1716
  %1720 = mul <8 x i64> %1718, splat (i64 65)
  %1721 = add <8 x i64> %1720, %1719
  %tile_snapshot.spill.load286 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %1722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 0
  %1723 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 1
  %.state287 = load <8 x i64>, ptr %.slot38, align 64
  %1724 = mul <8 x i64> %.state287, splat (i64 32)
  %1725 = add <8 x i64> %1723, %1724
  %1726 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1722, 0
  %1727 = insertvalue { <8 x ptr>, <8 x i64> } %1726, <8 x i64> %1725, 1
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1729 = extractvalue { <8 x ptr>, <8 x i64> } %1727, 1
  %1730 = extractelement <8 x ptr> %1728, i32 0
  %1731 = extractelement <8 x i64> %1729, i32 0
  %1732 = sub i64 %1731, 0
  %1733 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1734 = select i1 %1733, i64 %1732, i64 0
  %private.contiguous.address288 = getelementptr i8, ptr %1730, i64 %1734
  %private.contiguous.load289 = load <8 x float>, ptr %private.contiguous.address288, align 4
  %1735 = select <8 x i1> %55, <8 x float> %private.contiguous.load289, <8 x float> zeroinitializer
  %.spill.load290 = load float, ptr %.spill34, align 4
  %.splatinsert291 = insertelement <8 x float> poison, float %.spill.load290, i64 0
  %.splat292 = shufflevector <8 x float> %.splatinsert291, <8 x float> poison, <8 x i32> zeroinitializer
  %1736 = fdiv <8 x float> %1735, %.splat292
  %tile_snapshot.spill.load293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 0
  %1738 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 1
  %.state294 = load <8 x i64>, ptr %.slot38, align 64
  %1739 = mul <8 x i64> %.state294, splat (i64 32)
  %1740 = add <8 x i64> %1738, %1739
  %1741 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1737, 0
  %1742 = insertvalue { <8 x ptr>, <8 x i64> } %1741, <8 x i64> %1740, 1
  %1743 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1744 = extractvalue { <8 x ptr>, <8 x i64> } %1742, 1
  %1745 = extractelement <8 x ptr> %1743, i32 0
  %1746 = extractelement <8 x i64> %1744, i32 0
  %1747 = sub i64 %1746, 0
  %1748 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1749 = select i1 %1748, i64 %1747, i64 0
  %private.contiguous.address295 = getelementptr i8, ptr %1745, i64 %1749
  %private.contiguous.load296 = load <8 x float>, ptr %private.contiguous.address295, align 4
  %1750 = select <8 x i1> %55, <8 x float> %private.contiguous.load296, <8 x float> zeroinitializer
  %1751 = fmul <8 x float> %1736, %1750
  %tile_snapshot.spill.load297 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill36, align 64
  %1752 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load297, 0
  %1753 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load297, 1
  %.state298 = load <8 x i64>, ptr %.slot38, align 64
  %1754 = mul <8 x i64> %.state298, splat (i64 32)
  %1755 = add <8 x i64> %1753, %1754
  %1756 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1752, 0
  %1757 = insertvalue { <8 x ptr>, <8 x i64> } %1756, <8 x i64> %1755, 1
  %1758 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1759 = extractvalue { <8 x ptr>, <8 x i64> } %1757, 1
  %1760 = extractelement <8 x ptr> %1758, i32 0
  %1761 = extractelement <8 x i64> %1759, i32 0
  %1762 = sub i64 %1761, 0
  %1763 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1764 = select i1 %1763, i64 %1762, i64 0
  %private.contiguous.address299 = getelementptr i8, ptr %1760, i64 %1764
  %private.contiguous.load300 = load <8 x float>, ptr %private.contiguous.address299, align 4
  %1765 = select <8 x i1> %55, <8 x float> %private.contiguous.load300, <8 x float> zeroinitializer
  %1766 = fadd <8 x float> %1751, %1765
  %1767 = extractvalue { ptr, i64 } %31, 0
  %1768 = extractelement <8 x i64> %1721, i32 0
  %1769 = sub i64 %1768, 0
  %1770 = mul i64 %1769, 4
  %buffer.contiguous.address301 = getelementptr i8, ptr %1767, i64 %1770
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1766, ptr align 1 %buffer.contiguous.address301, <8 x i1> %55)
  %.state302 = load <8 x i64>, ptr %.slot38, align 64
  %1771 = add <8 x i64> %.state302, splat (i64 1)
  %1772 = load <8 x i64>, ptr %.slot38, align 64
  %1773 = select <8 x i1> %55, <8 x i64> %1771, <8 x i64> %1772
  store <8 x i64> %1773, ptr %.slot38, align 64
  br label %direct.schedule.38

direct.schedule.40:                               ; preds = %direct.false282
  %.spill.load303 = load <8 x i1>, ptr %.spill11, align 1
  %1774 = and <8 x i1> %55, %.spill.load303
  %1775 = xor <8 x i1> %.spill.load303, splat (i1 true)
  %1776 = and <8 x i1> %55, %1775
  %1777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1774)
  %1778 = bitcast <8 x i1> %1774 to i8
  %1779 = call i8 @llvm.cttz.i8(i8 %1778, i1 false)
  %1780 = zext i8 %1779 to i32
  %1781 = select i1 %1777, i32 %1780, i32 0
  %.spill.load304 = load <8 x i64>, ptr %.spill, align 64
  %1782 = add <8 x i64> splat (i64 64), %.spill.load304
  %.spill.load305 = load <8 x i64>, ptr %.spill10, align 64
  %1783 = add <8 x i64> %.spill.load305, zeroinitializer
  %1784 = add <8 x i64> zeroinitializer, %1783
  %1785 = add <8 x i64> zeroinitializer, %1782
  %1786 = mul <8 x i64> %1784, splat (i64 65)
  %1787 = add <8 x i64> %1786, %1785
  %tile_snapshot.spill.load306 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill23, align 64
  %1788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load306, 0
  %1789 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load306, 1
  %1790 = add <8 x i64> %1789, splat (i64 256)
  %1791 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1788, 0
  %1792 = insertvalue { <8 x ptr>, <8 x i64> } %1791, <8 x i64> %1790, 1
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1794 = extractvalue { <8 x ptr>, <8 x i64> } %1792, 1
  %1795 = extractelement <8 x ptr> %1793, i32 0
  %1796 = extractelement <8 x i64> %1794, i32 %1781
  %1797 = zext i32 %1781 to i64
  %1798 = mul i64 %1797, 4
  %1799 = sub i64 %1796, %1798
  %1800 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1774)
  %1801 = select i1 %1800, i64 %1799, i64 0
  %private.contiguous.address307 = getelementptr i8, ptr %1795, i64 %1801
  %private.contiguous.load308 = load <8 x float>, ptr %private.contiguous.address307, align 4
  %1802 = select <8 x i1> %1774, <8 x float> %private.contiguous.load308, <8 x float> zeroinitializer
  %.spill.load309 = load float, ptr %.spill34, align 4
  %.splatinsert310 = insertelement <8 x float> poison, float %.spill.load309, i64 0
  %.splat311 = shufflevector <8 x float> %.splatinsert310, <8 x float> poison, <8 x i32> zeroinitializer
  %1803 = fdiv <8 x float> %1802, %.splat311
  %tile_snapshot.spill.load312 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1804 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load312, 0
  %1805 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load312, 1
  %1806 = add <8 x i64> %1805, splat (i64 256)
  %1807 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1804, 0
  %1808 = insertvalue { <8 x ptr>, <8 x i64> } %1807, <8 x i64> %1806, 1
  %1809 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1810 = extractvalue { <8 x ptr>, <8 x i64> } %1808, 1
  %1811 = extractelement <8 x ptr> %1809, i32 0
  %1812 = extractelement <8 x i64> %1810, i32 %1781
  %1813 = zext i32 %1781 to i64
  %1814 = mul i64 %1813, 4
  %1815 = sub i64 %1812, %1814
  %1816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1774)
  %1817 = select i1 %1816, i64 %1815, i64 0
  %private.contiguous.address313 = getelementptr i8, ptr %1811, i64 %1817
  %private.contiguous.load314 = load <8 x float>, ptr %private.contiguous.address313, align 4
  %1818 = select <8 x i1> %1774, <8 x float> %private.contiguous.load314, <8 x float> zeroinitializer
  %1819 = fmul <8 x float> %1803, %1818
  %tile_snapshot.spill.load315 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill36, align 64
  %1820 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 0
  %1821 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load315, 1
  %1822 = add <8 x i64> %1821, splat (i64 256)
  %1823 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1820, 0
  %1824 = insertvalue { <8 x ptr>, <8 x i64> } %1823, <8 x i64> %1822, 1
  %1825 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1826 = extractvalue { <8 x ptr>, <8 x i64> } %1824, 1
  %1827 = extractelement <8 x ptr> %1825, i32 0
  %1828 = extractelement <8 x i64> %1826, i32 %1781
  %1829 = zext i32 %1781 to i64
  %1830 = mul i64 %1829, 4
  %1831 = sub i64 %1828, %1830
  %1832 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1774)
  %1833 = select i1 %1832, i64 %1831, i64 0
  %private.contiguous.address316 = getelementptr i8, ptr %1827, i64 %1833
  %private.contiguous.load317 = load <8 x float>, ptr %private.contiguous.address316, align 4
  %1834 = select <8 x i1> %1774, <8 x float> %private.contiguous.load317, <8 x float> zeroinitializer
  %1835 = fadd <8 x float> %1819, %1834
  %1836 = extractvalue { ptr, i64 } %31, 0
  %1837 = extractelement <8 x i64> %1787, i32 %1781
  %1838 = zext i32 %1781 to i64
  %1839 = sub i64 %1837, %1838
  %1840 = mul i64 %1839, 4
  %buffer.contiguous.address318 = getelementptr i8, ptr %1836, i64 %1840
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1835, ptr align 1 %buffer.contiguous.address318, <8 x i1> %1774)
  %1841 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1776)
  %1842 = bitcast <8 x i1> %1776 to i8
  %1843 = call i8 @llvm.cttz.i8(i8 %1842, i1 false)
  %1844 = zext i8 %1843 to i32
  %1845 = select i1 %1841, i32 %1844, i32 0
  br label %direct.schedule.31

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true77:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false78:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true112:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false113:                                  ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true149:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false150:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true186:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false187:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true211:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false212:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.32

direct.true214:                                   ; preds = %direct.schedule.27
  br label %direct.schedule.28

direct.false215:                                  ; preds = %direct.schedule.27
  br label %direct.schedule.29

direct.true256:                                   ; preds = %direct.schedule.33
  br label %direct.schedule.34

direct.false257:                                  ; preds = %direct.schedule.33
  br label %direct.schedule.35

direct.true281:                                   ; preds = %direct.schedule.38
  br label %direct.schedule.39

direct.false282:                                  ; preds = %direct.schedule.38
  br label %direct.schedule.40
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #3

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

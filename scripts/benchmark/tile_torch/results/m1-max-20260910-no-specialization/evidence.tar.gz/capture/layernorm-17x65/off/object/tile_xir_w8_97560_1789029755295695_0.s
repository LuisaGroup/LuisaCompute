	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_11:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI0_12:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI0_13:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI0_14:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
lCPI0_15:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_16:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB0_117
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #2736
	mov	x9, #0                          ; =0x0
	ldr	x11, [x0]
	ldr	x12, [x0, #16]
	ldr	x10, [x0, #32]
	ldr	x8, [x0, #48]
Lloh4:
	adrp	x13, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x13, lCPI0_0@PAGEOFF]
	and.16b	v2, v3, v2
	addv.8h	h17, v2
	fmov	w13, s17
	ldr	w14, [x1]
	ldr	w15, [x1, #36]
	add	w14, w15, w14, lsl #5
	lsr	w14, w14, #3
	dup.4s	v2, w14
	and	w3, w13, #0xff
	and.16b	v4, v1, v2
	and.16b	v6, v0, v2
	ushll2.2d	v2, v6, #0
	ushll2.2d	v5, v4, #0
	ushll.2d	v6, v6, #0
	ushll.2d	v16, v4, #0
	fmov	x13, d16
	mov	w14, #260                       ; =0x104
	umaddl	x13, w13, w14, x11
	fmov	w14, s17
	add	x15, sp, #2448
	b	LBB0_3
LBB0_2:                                 ; %else48
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x15, x9
	stp	q4, q7, [x16]
	add	x9, x9, #32
	cmp	x9, #256
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x9
	add	x0, x15, x9
	ldr	q4, [x0]
	tbnz	w14, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w17, w14, #0xff
	tbnz	w17, #1, LBB0_12
LBB0_5:                                 ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #2, LBB0_13
LBB0_6:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #3, LBB0_14
LBB0_7:                                 ; %else36
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q7, [x0, #16]
	tbnz	w17, #4, LBB0_15
LBB0_8:                                 ; %else39
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #5, LBB0_16
LBB0_9:                                 ; %else42
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #6, LBB0_17
LBB0_10:                                ; %else45
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w17, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v4 }[0], [x16]
	and	w17, w14, #0xff
	tbz	w17, #1, LBB0_5
LBB0_12:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x16, #4
	ld1.s	{ v4 }[1], [x1]
	tbz	w17, #2, LBB0_6
LBB0_13:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x16, #8
	ld1.s	{ v4 }[2], [x1]
	tbz	w17, #3, LBB0_7
LBB0_14:                                ; %cond.load35
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x16, #12
	ld1.s	{ v4 }[3], [x1]
	ldr	q7, [x0, #16]
	tbz	w17, #4, LBB0_8
LBB0_15:                                ; %cond.load38
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #16
	ld1.s	{ v7 }[0], [x0]
	tbz	w17, #5, LBB0_9
LBB0_16:                                ; %cond.load41
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #20
	ld1.s	{ v7 }[1], [x0]
	tbz	w17, #6, LBB0_10
LBB0_17:                                ; %cond.load44
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #24
	ld1.s	{ v7 }[2], [x0]
	tbz	w17, #7, LBB0_2
LBB0_18:                                ; %cond.load47
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x16, #28
	ld1.s	{ v7 }[3], [x16]
	b	LBB0_2
LBB0_19:                                ; %direct.true76.preheader
	xtn.8b	v29, v3
	sshll.2d	v3, v1, #0
	sshll.2d	v19, v0, #0
	sshll2.2d	v26, v1, #0
	sshll2.2d	v27, v0, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q4, [x9, lCPI0_6@PAGEOFF]
	and.16b	v4, v3, v4
	movi.2d	v18, #0000000000000000
Lloh8:
	adrp	x9, lCPI0_7@PAGE
Lloh9:
	ldr	q7, [x9, lCPI0_7@PAGEOFF]
	and.16b	v7, v3, v7
Lloh10:
	adrp	x9, lCPI0_8@PAGE
Lloh11:
	ldr	q3, [x9, lCPI0_8@PAGEOFF]
	and.16b	v23, v19, v3
Lloh12:
	adrp	x9, lCPI0_9@PAGE
Lloh13:
	ldr	q3, [x9, lCPI0_9@PAGEOFF]
	and.16b	v24, v26, v3
Lloh14:
	adrp	x9, lCPI0_10@PAGE
Lloh15:
	ldr	q3, [x9, lCPI0_10@PAGEOFF]
	and.16b	v25, v27, v3
	movi.8b	v3, #1
	and.8b	v3, v29, v3
	umov.b	w13, v3[0]
	movi.2d	v28, #0000000000000000
	movi.2d	v3, #0000000000000000
	mov.b	v3[0], v29[0]
	umaxv.8b	b20, v3
	fmov	w16, s20
	rbit	w9, w13
	clz	w9, w9
	tst	w16, #0x1
	mov	w14, #64                        ; =0x40
	dup.2d	v22, x14
	csel	w9, w9, wzr, ne
	str	q4, [sp, #160]                  ; 16-byte Spill
	orr.16b	v4, v4, v22
	xtn.2s	v21, v16
	movi.2s	v20, #65
	str	q4, [sp, #192]                  ; 16-byte Spill
	umlal.2d	v4, v21, v20
	str	q29, [sp, #304]                 ; 16-byte Spill
	mov.b	v28[0], v29[0]
	ushll.2d	v16, v28, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	str	q4, [sp, #272]                  ; 16-byte Spill
	and.16b	v16, v16, v4
	str	q18, [sp, #1488]
	str	q18, [sp, #1472]
	str	q18, [sp, #1456]
	str	q16, [sp, #1440]
	ubfiz	x15, x9, #3, #3
	add	x14, sp, #1440
	ldr	x14, [x14, x15]
	sub	x14, x14, x9
	add	x14, x11, x14, lsl #2
	str	q25, [sp, #1552]
	str	q23, [sp, #1536]
	str	q24, [sp, #1520]
	str	q7, [sp, #1504]
	add	x11, sp, #1504
	ldr	x11, [x11, x15]
	orr	x11, x11, #0x100
	sub	x11, x11, w9, uxtw #2
	tst	w13, #0x1
	csel	x11, xzr, x11, eq
	add	x15, sp, #2448
	add	x15, x15, x11
	ldr	q25, [x15]
	tbnz	w16, #0, LBB0_118
; %bb.20:                               ; %else52
	tbnz	w13, #1, LBB0_119
LBB0_21:                                ; %else55
	tbnz	w13, #2, LBB0_120
LBB0_22:                                ; %else58
	tbnz	w13, #3, LBB0_121
LBB0_23:                                ; %else61
	adrp	x16, lCPI0_3@PAGE
	adrp	x17, lCPI0_4@PAGE
	adrp	x0, lCPI0_5@PAGE
	ldr	q28, [x15, #16]
	tbnz	w13, #4, LBB0_122
LBB0_24:                                ; %else64
	ldr	q16, [x16, lCPI0_3@PAGEOFF]
	ldr	q18, [x17, lCPI0_4@PAGEOFF]
	ldr	q23, [x0, lCPI0_5@PAGEOFF]
	tbnz	w13, #5, LBB0_123
LBB0_25:                                ; %else67
	and.16b	v4, v27, v16
	and.16b	v18, v26, v18
	and.16b	v16, v19, v23
	tbz	w13, #6, LBB0_27
LBB0_26:                                ; %cond.load69
	add	x15, x14, #24
	ld1.s	{ v28 }[2], [x15]
LBB0_27:                                ; %else70
	stp	q16, q18, [sp, #80]             ; 32-byte Folded Spill
	orr.16b	v16, v16, v22
	orr.16b	v18, v18, v22
	str	q4, [sp, #112]                  ; 16-byte Spill
	orr.16b	v4, v4, v22
	xtn.2s	v22, v5
	xtn.2s	v5, v6
	xtn.2s	v2, v2
	str	q3, [sp, #320]                  ; 16-byte Spill
	str	q17, [sp, #288]                 ; 16-byte Spill
	tbz	w13, #7, LBB0_29
; %bb.28:                               ; %cond.load72
	add	x13, x14, #28
	ld1.s	{ v28 }[3], [x13]
LBB0_29:                                ; %else73
	umull.2d	v6, v21, v20
	str	q4, [sp, #176]                  ; 16-byte Spill
	mov.16b	v3, v4
	umlal.2d	v3, v2, v20
	stp	q18, q16, [sp, #128]            ; 32-byte Folded Spill
	mov.16b	v2, v18
	umlal.2d	v2, v22, v20
	stp	q2, q3, [sp, #240]              ; 32-byte Folded Spill
	mov.16b	v2, v16
	umlal.2d	v2, v5, v20
	stp	q6, q2, [sp, #208]              ; 32-byte Folded Spill
	sshll.2d	v2, v1, #0
	sshll.2d	v24, v0, #0
	add	x13, sp, #2448
	add	x14, x13, x11
	stp	q28, q25, [sp, #16]             ; 32-byte Folded Spill
	stp	q25, q28, [x14]
	fmov	x24, d7
	mov	w14, #4                         ; =0x4
	dup.2d	v5, x14
	and.16b	v23, v27, v5
	and.16b	v12, v26, v5
	and.16b	v13, v24, v5
	and.16b	v14, v2, v5
	fmov	x23, d14
	ldr	q6, [sp, #2544]
	ldr	q5, [sp, #2560]
	and.16b	v5, v0, v5
	and.16b	v6, v1, v6
	ldr	q7, [sp, #2512]
	ldr	q20, [sp, #2528]
	and.16b	v20, v0, v20
	and.16b	v7, v1, v7
	ldr	q22, [sp, #2480]
	ldr	q21, [sp, #2496]
	and.16b	v21, v0, v21
	and.16b	v22, v1, v22
	add	x15, x13, x24
	ldp	q25, q28, [x15]
	and.16b	v29, v0, v28
	mov	x15, x23
	and.16b	v30, v1, v25
	mov.16b	v31, v14
	mov.16b	v8, v12
	mov.16b	v9, v13
	mov.16b	v10, v23
LBB0_30:                                ; %direct.true76
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x13, x15, lsl #5
	ldp	q28, q25, [x15]
	fadd.4s	v28, v30, v28
	fadd.4s	v25, v29, v25
	ldp	q3, q4, [x15, #32]
	fadd.4s	v3, v22, v3
	fadd.4s	v4, v21, v4
	ldp	q15, q11, [x15, #64]
	fadd.4s	v15, v7, v15
	fadd.4s	v11, v20, v11
	ldp	q18, q16, [x15, #96]
	fadd.4s	v18, v6, v18
	fadd.4s	v16, v5, v16
	dup.2d	v19, x14
	and.16b	v17, v27, v19
	add.2d	v10, v10, v17
	and.16b	v17, v26, v19
	add.2d	v8, v8, v17
	and.16b	v17, v24, v19
	add.2d	v9, v9, v17
	and.16b	v17, v2, v19
	add.2d	v31, v31, v17
	bit.16b	v29, v25, v0
	bit.16b	v30, v28, v1
	bit.16b	v21, v4, v0
	bit.16b	v22, v3, v1
	bit.16b	v20, v11, v0
	bit.16b	v7, v15, v1
	bit.16b	v5, v16, v0
	bit.16b	v6, v18, v1
	fmov	x15, d31
	cmp	x15, #8
	b.lt	LBB0_30
; %bb.31:                               ; %direct.false77
	mov	x25, #0                         ; =0x0
	ldp	q8, q31, [sp, #16]              ; 32-byte Folded Reload
	fadd.4s	v2, v8, v29
	fadd.4s	v3, v31, v30
	ldp	q30, q29, [sp, #304]            ; 32-byte Folded Reload
	zip1.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v3, v4, v3
	zip2.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	and.16b	v2, v4, v2
	zip2.8b	v4, v30, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bsl.16b	v4, v25, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v16, #0000000000000000
	mov.b	v16[2], v30[1]
	mov.b	v16[4], v30[2]
	mov.b	v16[6], v30[3]
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bit.16b	v3, v28, v16
	fadd.4s	v3, v22, v3
	fadd.4s	v4, v21, v4
	fadd.4s	v4, v20, v4
	fadd.4s	v3, v7, v3
	fadd.4s	v6, v6, v3
	fadd.4s	v7, v5, v4
	ldr	q3, [sp, #160]                  ; 16-byte Reload
	ldr	q4, [sp, #96]                   ; 16-byte Reload
	uzp1.4s	v5, v3, v4
	ldr	q3, [sp, #112]                  ; 16-byte Reload
	ldr	q4, [sp, #80]                   ; 16-byte Reload
	uzp1.4s	v16, v4, v3
	movi.4s	v3, #1
	eor.16b	v4, v5, v3
	mov.s	w14, v4[1]
	mov.s	w15, v4[2]
	eor.16b	v21, v16, v3
	mov.s	w17, v4[3]
	fmov	w13, s4
	add	x4, sp, #1080
	add	x16, sp, #1080
	bfxil	x16, x13, #0, #3
	str	d30, [sp, #1080]
	ldrb	w16, [x16]
	and	x0, x13, #0x7
	umov.b	w13, v30[0]
	str	q7, [sp, #1296]
	str	q6, [sp, #1280]
	add	x1, sp, #1280
	ldr	s3, [x1, x0, lsl #2]
	ands	w5, w13, #0x1
	tst	w5, w16
	movi.2d	v4, #0000000000000000
	fcsel	s18, s3, s4, ne
	and	x0, x14, #0x7
	add	x16, sp, #1080
	bfxil	x16, x14, #0, #3
	ldrb	w14, [x16]
	umov.b	w16, v30[1]
	and	w14, w16, w14
	str	q7, [sp, #1264]
	str	q6, [sp, #1248]
	add	x1, sp, #1248
	ldr	s3, [x1, x0, lsl #2]
	tst	w14, #0x1
	fcsel	s19, s3, s4, ne
	and	x14, x15, #0x7
	add	x0, sp, #1080
	bfxil	x0, x15, #0, #3
	ldrb	w0, [x0]
	umov.b	w15, v30[2]
	and	w0, w15, w0
	str	q7, [sp, #1232]
	str	q6, [sp, #1216]
	add	x1, sp, #1216
	ldr	s3, [x1, x14, lsl #2]
	tst	w0, #0x1
	fcsel	s20, s3, s4, ne
	and	x0, x17, #0x7
	add	x1, sp, #1080
	bfxil	x1, x17, #0, #3
	umov.b	w14, v30[3]
	ldrb	w17, [x1]
	str	q7, [sp, #1200]
	str	q6, [sp, #1184]
	add	x1, sp, #1184
	ldr	s3, [x1, x0, lsl #2]
	and	w17, w14, w17
	tst	w17, #0x1
	mov.s	w17, v21[1]
	mov.s	w0, v21[2]
	fcsel	s22, s3, s4, ne
	mov.s	w6, v21[3]
	fmov	w1, s21
	and	x7, x1, #0x7
	add	x2, sp, #1080
	bfxil	x2, x1, #0, #3
	ldrb	w1, [x2]
	umov.b	w2, v30[4]
	and	w1, w2, w1
	str	q7, [sp, #1424]
	str	q6, [sp, #1408]
	add	x19, sp, #1408
	ldr	s3, [x19, x7, lsl #2]
	tst	w1, #0x1
	fcsel	s3, s3, s4, ne
	and	x7, x17, #0x7
	add	x1, sp, #1080
	bfxil	x1, x17, #0, #3
	ldrb	w17, [x1]
	umov.b	w1, v30[5]
	and	w17, w1, w17
	str	q7, [sp, #1392]
	str	q6, [sp, #1376]
	add	x19, sp, #1376
	ldr	s17, [x19, x7, lsl #2]
	tst	w17, #0x1
	fcsel	s17, s17, s4, ne
	and	x7, x0, #0x7
	add	x17, sp, #1080
	bfxil	x17, x0, #0, #3
	ldrb	w0, [x17]
	umov.b	w17, v30[6]
	and	w0, w17, w0
	str	q7, [sp, #1360]
	str	q6, [sp, #1344]
	add	x19, sp, #1344
	ldr	s21, [x19, x7, lsl #2]
	tst	w0, #0x1
	fcsel	s21, s21, s4, ne
	and	x7, x6, #0x7
	add	x0, sp, #1080
	bfxil	x0, x6, #0, #3
	ldrb	w6, [x0]
	umov.b	w0, v30[7]
	and	w6, w0, w6
	str	q7, [sp, #1328]
	str	q6, [sp, #1312]
	add	x19, sp, #1312
	ldr	s24, [x19, x7, lsl #2]
	tst	w6, #0x1
	fcsel	s24, s24, s4, ne
	mov.s	v3[1], v17[0]
	mov.s	v3[2], v21[0]
	mov.s	v3[3], v24[0]
	mov.s	v18[1], v19[0]
	mov.s	v18[2], v20[0]
	mov.s	v18[3], v22[0]
	fadd.4s	v6, v6, v18
	fadd.4s	v3, v7, v3
	movi.4s	v7, #2
	eor.16b	v16, v16, v7
	eor.16b	v5, v5, v7
	fmov	w6, s5
	add	x7, sp, #1080
	bfxil	x7, x6, #0, #3
	ldrb	w7, [x7]
	and	x6, x6, #0x7
	str	q3, [sp, #1168]
	str	q6, [sp, #1152]
	add	x19, sp, #1152
	ldr	s5, [x19, x6, lsl #2]
	tst	w5, w7
	fcsel	s5, s5, s4, ne
	fmov	w5, s16
	and	x6, x5, #0x7
	bfxil	x4, x5, #0, #3
	ldrb	w4, [x4]
	and	w4, w2, w4
	str	q3, [sp, #1136]
	str	q6, [sp, #1120]
	add	x5, sp, #1120
	ldr	s7, [x5, x6, lsl #2]
	tst	w4, #0x1
	fcsel	s7, s7, s4, ne
	fadd.4s	v3, v3, v7
	and	w4, w13, w2
	tst	w4, #0x1
	fcsel	s3, s3, s4, ne
	ands	w5, w13, #0x1
	fadd.4s	v5, v6, v5
	fadd	s3, s5, s3
	fcsel	s5, s3, s4, ne
	tst	w4, #0x1
	mov.b	v30[0], wzr
	str	q30, [sp, #80]                  ; 16-byte Spill
	and	w6, w16, w13
	fcsel	s6, s3, s4, ne
	tst	w6, #0x1
	and	w7, w15, w13
	fcsel	s7, s3, s4, ne
	tst	w7, #0x1
	and	w19, w14, w13
	fcsel	s16, s3, s4, ne
	tst	w19, #0x1
	fcsel	s17, s3, s4, ne
	and	w20, w1, w13
	tst	w20, #0x1
	fcsel	s18, s3, s4, ne
	and	w21, w17, w13
	tst	w21, #0x1
	fcsel	s19, s3, s4, ne
	and	w22, w0, w13
	tst	w22, #0x1
	fcsel	s3, s3, s4, ne
	mov.s	v5[1], v7[0]
	mov.s	v5[2], v16[0]
	mov.s	v5[3], v17[0]
	mov.s	v6[1], v18[0]
	mov.s	v6[2], v19[0]
	mov.s	v6[3], v3[0]
	rbit	w3, w3
	clz	w3, w3
	str	q6, [sp, #1104]
	str	q5, [sp, #1088]
	and	x26, x3, #0x7
	add	x27, sp, #1088
	ldr	s3, [x27, x26, lsl #2]
	fadd	s3, s3, s4
	mov	w26, #1115815936                ; =0x42820000
	fmov	s4, w26
	fdiv	s3, s3, s4
	dup.4s	v4, v3[0]
	ushll2.2d	v3, v0, #0
	mov	w26, #1                         ; =0x1
	dup.2d	v5, x26
	and.16b	v18, v3, v5
	ushll2.2d	v3, v1, #0
	and.16b	v19, v3, v5
	ushll.2d	v3, v0, #0
	and.16b	v20, v3, v5
	ushll.2d	v3, v1, #0
	and.16b	v21, v3, v5
	add	x26, sp, #2448
	add	x27, sp, #2160
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
LBB0_32:                                ; %direct.true111
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x25, x25, #5
	add	x28, x26, x25
	ldp	q16, q3, [x28]
	fsub.4s	v16, v16, v4
	fsub.4s	v3, v3, v4
	add	x25, x27, x25
	ldp	q17, q22, [x25]
	bif.16b	v3, v22, v0
	bif.16b	v16, v17, v1
	stp	q16, q3, [x25]
	add.2d	v5, v5, v19
	add.2d	v6, v6, v20
	add.2d	v7, v7, v18
	add.2d	v2, v2, v21
	fmov	x25, d2
	cmp	x25, #8
	b.lt	LBB0_32
; %bb.33:                               ; %direct.true148.preheader
Lloh16:
	adrp	x25, lCPI0_11@PAGE
Lloh17:
	ldr	q2, [x25, lCPI0_11@PAGEOFF]
	and.16b	v2, v0, v2
	str	q2, [sp, #64]                   ; 16-byte Spill
Lloh18:
	adrp	x25, lCPI0_12@PAGE
Lloh19:
	ldr	q2, [x25, lCPI0_12@PAGEOFF]
	and.16b	v2, v1, v2
	str	q2, [sp, #48]                   ; 16-byte Spill
Lloh20:
	adrp	x25, lCPI0_13@PAGE
Lloh21:
	ldr	q2, [x25, lCPI0_13@PAGEOFF]
	and.16b	v2, v0, v2
	str	q2, [sp, #112]                  ; 16-byte Spill
Lloh22:
	adrp	x25, lCPI0_14@PAGE
Lloh23:
	ldr	q2, [x25, lCPI0_14@PAGEOFF]
	and.16b	v2, v1, v2
	str	q2, [sp, #96]                   ; 16-byte Spill
Lloh24:
	adrp	x25, lCPI0_15@PAGE
Lloh25:
	ldr	q2, [x25, lCPI0_15@PAGEOFF]
	and.16b	v2, v1, v2
	str	q2, [sp, #160]                  ; 16-byte Spill
	fsub.4s	v5, v31, v4
	fsub.4s	v6, v8, v4
	add	x25, sp, #2160
	add	x26, x25, x11
	ldp	q2, q3, [x26]
	zip2.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	stp	q6, q5, [sp, #16]               ; 32-byte Folded Spill
	bit.16b	v3, v6, v4
	zip1.8b	v4, v29, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v2, v5, v4
	stp	q2, q3, [x26]
	ldr	q2, [sp, #2272]
	ldr	q3, [sp, #2256]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v15, v0, v2
	and.16b	v16, v1, v3
	ldr	q2, [sp, #2240]
	ldr	q3, [sp, #2224]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v6, v0, v2
	and.16b	v5, v1, v3
	ldr	q2, [sp, #2208]
	ldr	q3, [sp, #2192]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v7, v0, v2
	and.16b	v4, v1, v3
	add	x24, x25, x24
	ldp	q3, q2, [x24]
	fmul.4s	v3, v3, v3
	fmul.4s	v2, v2, v2
	and.16b	v28, v0, v2
	and.16b	v2, v1, v3
	mov	w24, #4                         ; =0x4
LBB0_34:                                ; %direct.true148
                                        ; =>This Inner Loop Header: Depth=1
	sshll.2d	v3, v1, #0
	sshll.2d	v17, v0, #0
	add	x23, x25, x23, lsl #5
	ldp	q25, q22, [x23]
	and.16b	v25, v1, v25
	and.16b	v22, v0, v22
	fmul.4s	v10, v22, v22
	fmul.4s	v22, v25, v25
	fadd.4s	v22, v2, v22
	fadd.4s	v11, v28, v10
	ldp	q10, q25, [x23, #32]
	and.16b	v10, v1, v10
	and.16b	v25, v0, v25
	fmul.4s	v25, v25, v25
	fmul.4s	v10, v10, v10
	fadd.4s	v10, v4, v10
	fadd.4s	v25, v7, v25
	ldp	q29, q24, [x23, #64]
	and.16b	v29, v1, v29
	and.16b	v24, v0, v24
	fmul.4s	v24, v24, v24
	fmul.4s	v29, v29, v29
	fadd.4s	v29, v5, v29
	fadd.4s	v24, v6, v24
	ldp	q31, q30, [x23, #96]
	and.16b	v31, v1, v31
	and.16b	v30, v0, v30
	fmul.4s	v30, v30, v30
	fmul.4s	v31, v31, v31
	fadd.4s	v31, v16, v31
	fadd.4s	v30, v15, v30
	dup.2d	v8, x24
	and.16b	v9, v27, v8
	add.2d	v23, v23, v9
	and.16b	v9, v26, v8
	add.2d	v12, v12, v9
	and.16b	v17, v17, v8
	add.2d	v13, v13, v17
	and.16b	v3, v3, v8
	add.2d	v14, v14, v3
	bit.16b	v28, v11, v0
	bit.16b	v2, v22, v1
	bit.16b	v7, v25, v0
	bit.16b	v4, v10, v1
	bit.16b	v6, v24, v0
	bit.16b	v5, v29, v1
	bit.16b	v15, v30, v0
	bit.16b	v16, v31, v1
	fmov	x23, d14
	cmp	x23, #8
	b.lt	LBB0_34
; %bb.35:                               ; %direct.true185.preheader
	mov	x25, #0                         ; =0x0
	movi.2d	v26, #0000000000000000
	ldr	q30, [sp, #288]                 ; 16-byte Reload
	fmov	w23, s30
	add	x24, sp, #1872
	movi.2d	v27, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v12, #0000000000000000
	ldr	q31, [sp, #320]                 ; 16-byte Reload
	b	LBB0_37
LBB0_36:                                ; %else98
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x25, x24, x25
	stp	q13, q23, [x25]
	add.2d	v27, v27, v19
	add.2d	v10, v10, v20
	add.2d	v12, v12, v18
	add.2d	v26, v26, v21
	fmov	x25, d26
	cmp	x25, #8
	b.ge	LBB0_53
LBB0_37:                                ; %direct.true185
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x25, x25, #5
	add	x26, x12, x25
	add	x28, x24, x25
	ldr	q13, [x28]
	tbnz	w23, #0, LBB0_45
; %bb.38:                               ; %else77
                                        ;   in Loop: Header=BB0_37 Depth=1
	and	w27, w23, #0xff
	tbnz	w27, #1, LBB0_46
LBB0_39:                                ; %else80
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w27, #2, LBB0_47
LBB0_40:                                ; %else83
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w27, #3, LBB0_48
LBB0_41:                                ; %else86
                                        ;   in Loop: Header=BB0_37 Depth=1
	ldr	q23, [x28, #16]
	tbnz	w27, #4, LBB0_49
LBB0_42:                                ; %else89
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w27, #5, LBB0_50
LBB0_43:                                ; %else92
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w27, #6, LBB0_51
LBB0_44:                                ; %else95
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbz	w27, #7, LBB0_36
	b	LBB0_52
LBB0_45:                                ; %cond.load76
                                        ;   in Loop: Header=BB0_37 Depth=1
	ld1.s	{ v13 }[0], [x26]
	and	w27, w23, #0xff
	tbz	w27, #1, LBB0_39
LBB0_46:                                ; %cond.load79
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x30, x26, #4
	ld1.s	{ v13 }[1], [x30]
	tbz	w27, #2, LBB0_40
LBB0_47:                                ; %cond.load82
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x30, x26, #8
	ld1.s	{ v13 }[2], [x30]
	tbz	w27, #3, LBB0_41
LBB0_48:                                ; %cond.load85
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x30, x26, #12
	ld1.s	{ v13 }[3], [x30]
	ldr	q23, [x28, #16]
	tbz	w27, #4, LBB0_42
LBB0_49:                                ; %cond.load88
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x28, x26, #16
	ld1.s	{ v23 }[0], [x28]
	tbz	w27, #5, LBB0_43
LBB0_50:                                ; %cond.load91
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x28, x26, #20
	ld1.s	{ v23 }[1], [x28]
	tbz	w27, #6, LBB0_44
LBB0_51:                                ; %cond.load94
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x28, x26, #24
	ld1.s	{ v23 }[2], [x28]
	tbz	w27, #7, LBB0_36
LBB0_52:                                ; %cond.load97
                                        ;   in Loop: Header=BB0_37 Depth=1
	add	x26, x26, #28
	ld1.s	{ v23 }[3], [x26]
	b	LBB0_36
LBB0_53:                                ; %direct.false186
	mov	b3, v31[0]
	mov.b	v3[4], v31[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldp	q25, q17, [sp, #176]            ; 32-byte Folded Reload
	and.16b	v3, v3, v17
	mov	b17, v31[2]
	mov.b	v17[4], v31[3]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldp	q23, q24, [sp, #128]            ; 32-byte Folded Reload
	and.16b	v17, v17, v23
	mov	b23, v31[4]
	mov.b	v23[4], v31[5]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	and.16b	v23, v23, v24
	mov	b24, v31[6]
	mov.b	v24[4], v31[7]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	and.16b	v24, v24, v25
Lloh26:
	adrp	x23, lCPI0_16@PAGE
Lloh27:
	ldr	d25, [x23, lCPI0_16@PAGEOFF]
	shl.8b	v26, v31, #7
	cmlt.8b	v26, v26, #0
	and.8b	v25, v26, v25
	addv.8b	b8, v25
	fmov	w24, s8
	str	q24, [sp, #1056]
	str	q23, [sp, #1040]
	stp	q3, q17, [sp, #1008]
	and	x23, x9, #0x7
	add	x25, sp, #1008
	ldr	x23, [x25, x23, lsl #3]
	sub	x23, x23, x9
	lsl	x23, x23, #2
	add	x12, x12, x23
	add	x25, sp, #1872
	add	x25, x25, x11
	ldr	q23, [x25]
	tbnz	w24, #0, LBB0_124
; %bb.54:                               ; %else102
	tbnz	w24, #1, LBB0_125
LBB0_55:                                ; %else105
	tbnz	w24, #2, LBB0_126
LBB0_56:                                ; %else108
	tbnz	w24, #3, LBB0_127
LBB0_57:                                ; %else111
	ldr	q25, [x25, #16]
	tbnz	w24, #4, LBB0_128
LBB0_58:                                ; %else114
	tbnz	w24, #5, LBB0_129
LBB0_59:                                ; %else117
	tbnz	w24, #6, LBB0_130
LBB0_60:                                ; %else120
	tbz	w24, #7, LBB0_62
LBB0_61:                                ; %cond.load122
	add	x12, x12, #28
	ld1.s	{ v25 }[3], [x12]
LBB0_62:                                ; %else123
	mov	x25, #0                         ; =0x0
	add	x12, sp, #1872
	add	x12, x12, x11
	stp	q23, q25, [x12]
	movi.2d	v26, #0000000000000000
	fmov	w12, s30
	add	x24, sp, #1584
	movi.2d	v10, #0000000000000000
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	b	LBB0_64
LBB0_63:                                ; %else148
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x25, x24, x25
	stp	q14, q27, [x25]
	add.2d	v10, v10, v19
	add.2d	v12, v12, v20
	add.2d	v13, v13, v18
	add.2d	v26, v26, v21
	fmov	x25, d26
	cmp	x25, #8
	b.ge	LBB0_80
LBB0_64:                                ; %direct.true211
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x25, x25, #5
	add	x26, x10, x25
	add	x28, x24, x25
	ldr	q14, [x28]
	tbnz	w12, #0, LBB0_72
; %bb.65:                               ; %else127
                                        ;   in Loop: Header=BB0_64 Depth=1
	and	w27, w12, #0xff
	tbnz	w27, #1, LBB0_73
LBB0_66:                                ; %else130
                                        ;   in Loop: Header=BB0_64 Depth=1
	tbnz	w27, #2, LBB0_74
LBB0_67:                                ; %else133
                                        ;   in Loop: Header=BB0_64 Depth=1
	tbnz	w27, #3, LBB0_75
LBB0_68:                                ; %else136
                                        ;   in Loop: Header=BB0_64 Depth=1
	ldr	q27, [x28, #16]
	tbnz	w27, #4, LBB0_76
LBB0_69:                                ; %else139
                                        ;   in Loop: Header=BB0_64 Depth=1
	tbnz	w27, #5, LBB0_77
LBB0_70:                                ; %else142
                                        ;   in Loop: Header=BB0_64 Depth=1
	tbnz	w27, #6, LBB0_78
LBB0_71:                                ; %else145
                                        ;   in Loop: Header=BB0_64 Depth=1
	tbz	w27, #7, LBB0_63
	b	LBB0_79
LBB0_72:                                ; %cond.load126
                                        ;   in Loop: Header=BB0_64 Depth=1
	ld1.s	{ v14 }[0], [x26]
	and	w27, w12, #0xff
	tbz	w27, #1, LBB0_66
LBB0_73:                                ; %cond.load129
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x30, x26, #4
	ld1.s	{ v14 }[1], [x30]
	tbz	w27, #2, LBB0_67
LBB0_74:                                ; %cond.load132
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x30, x26, #8
	ld1.s	{ v14 }[2], [x30]
	tbz	w27, #3, LBB0_68
LBB0_75:                                ; %cond.load135
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x30, x26, #12
	ld1.s	{ v14 }[3], [x30]
	ldr	q27, [x28, #16]
	tbz	w27, #4, LBB0_69
LBB0_76:                                ; %cond.load138
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x28, x26, #16
	ld1.s	{ v27 }[0], [x28]
	tbz	w27, #5, LBB0_70
LBB0_77:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x28, x26, #20
	ld1.s	{ v27 }[1], [x28]
	tbz	w27, #6, LBB0_71
LBB0_78:                                ; %cond.load144
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x28, x26, #24
	ld1.s	{ v27 }[2], [x28]
	tbz	w27, #7, LBB0_63
LBB0_79:                                ; %cond.load147
                                        ;   in Loop: Header=BB0_64 Depth=1
	add	x26, x26, #28
	ld1.s	{ v27 }[3], [x26]
	b	LBB0_63
LBB0_80:                                ; %direct.false212
	zip2.8b	v3, v31, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldp	q17, q26, [sp, #16]             ; 32-byte Folded Reload
	and.16b	v24, v3, v17
	zip1.8b	v17, v31, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	and.16b	v26, v17, v26
	fmul.4s	v27, v26, v26
	fmul.4s	v29, v24, v24
	fadd.4s	v28, v29, v28
	fadd.4s	v2, v27, v2
	and.16b	v2, v17, v2
	and.16b	v3, v3, v28
	ldr	q27, [sp, #80]                  ; 16-byte Reload
	zip2.8b	v17, v27, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v3, v11, v17
	zip1.8b	v17, v27, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bit.16b	v2, v22, v17
	fadd.4s	v2, v4, v2
	fadd.4s	v3, v7, v3
	fadd.4s	v3, v6, v3
	fadd.4s	v2, v5, v2
	fadd.4s	v4, v16, v2
	fadd.4s	v5, v15, v3
	ldr	q17, [sp, #48]                  ; 16-byte Reload
	fmov	w12, s17
	add	x24, sp, #408
	bfxil	x24, x12, #0, #3
	ldr	q2, [sp, #304]                  ; 16-byte Reload
	str	d2, [sp, #408]
	ldrb	w24, [x24]
	and	x12, x12, #0x7
	stp	q4, q5, [sp, #832]
	add	x25, sp, #832
	ldr	s3, [x25, x12, lsl #2]
	tst	w5, w24
	movi.2d	v2, #0000000000000000
	mov.s	w12, v17[1]
	fcsel	s6, s3, s2, ne
	and	x24, x12, #0x7
	add	x25, sp, #408
	bfxil	x25, x12, #0, #3
	ldrb	w12, [x25]
	and	w12, w16, w12
	stp	q4, q5, [sp, #800]
	add	x25, sp, #800
	ldr	s3, [x25, x24, lsl #2]
	tst	w12, #0x1
	fcsel	s7, s3, s2, ne
	mov.s	w12, v17[2]
	and	x24, x12, #0x7
	add	x25, sp, #408
	bfxil	x25, x12, #0, #3
	ldrb	w12, [x25]
	stp	q4, q5, [sp, #768]
	add	x25, sp, #768
	ldr	s3, [x25, x24, lsl #2]
	and	w12, w15, w12
	tst	w12, #0x1
	fcsel	s16, s3, s2, ne
	mov.s	w12, v17[3]
	and	x24, x12, #0x7
	add	x25, sp, #408
	bfxil	x25, x12, #0, #3
	ldrb	w12, [x25]
	and	w12, w14, w12
	stp	q4, q5, [sp, #736]
	add	x25, sp, #736
	ldr	s3, [x25, x24, lsl #2]
	tst	w12, #0x1
	fcsel	s17, s3, s2, ne
	ldr	q28, [sp, #64]                  ; 16-byte Reload
	fmov	w12, s28
	and	x24, x12, #0x7
	add	x25, sp, #408
	bfxil	x25, x12, #0, #3
	ldrb	w12, [x25]
	and	w12, w2, w12
	stp	q4, q5, [sp, #960]
	add	x25, sp, #960
	ldr	s3, [x25, x24, lsl #2]
	tst	w12, #0x1
	fcsel	s3, s3, s2, ne
	mov.s	w12, v28[1]
	and	x24, x12, #0x7
	add	x25, sp, #408
	bfxil	x25, x12, #0, #3
	ldrb	w12, [x25]
	and	w12, w1, w12
	stp	q4, q5, [sp, #928]
	add	x25, sp, #928
	ldr	s22, [x25, x24, lsl #2]
	tst	w12, #0x1
	fcsel	s22, s22, s2, ne
	mov.s	w12, v28[2]
	and	x24, x12, #0x7
	add	x25, sp, #408
	bfxil	x25, x12, #0, #3
	ldrb	w12, [x25]
	and	w12, w17, w12
	stp	q4, q5, [sp, #896]
	add	x25, sp, #896
	ldr	s27, [x25, x24, lsl #2]
	tst	w12, #0x1
	fcsel	s27, s27, s2, ne
	mov.s	w12, v28[3]
	and	x24, x12, #0x7
	add	x25, sp, #408
	bfxil	x25, x12, #0, #3
	ldrb	w12, [x25]
	and	w12, w0, w12
	stp	q4, q5, [sp, #864]
	add	x25, sp, #864
	ldr	s28, [x25, x24, lsl #2]
	tst	w12, #0x1
	fcsel	s28, s28, s2, ne
	mov.s	v3[1], v22[0]
	mov.s	v3[2], v27[0]
	mov.s	v3[3], v28[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v17[0]
	fadd.4s	v4, v4, v6
	fadd.4s	v5, v5, v3
	ldr	q17, [sp, #96]                  ; 16-byte Reload
	fmov	w12, s17
	add	x24, sp, #408
	bfxil	x24, x12, #0, #3
	ldrb	w24, [x24]
	and	x12, x12, #0x7
	stp	q4, q5, [sp, #576]
	add	x25, sp, #576
	ldr	s3, [x25, x12, lsl #2]
	tst	w5, w24
	fcsel	s6, s3, s2, ne
	mov.s	w12, v17[1]
	and	x24, x12, #0x7
	add	x25, sp, #408
	bfxil	x25, x12, #0, #3
	ldrb	w12, [x25]
	and	w12, w16, w12
	stp	q4, q5, [sp, #544]
	add	x16, sp, #544
	ldr	s3, [x16, x24, lsl #2]
	tst	w12, #0x1
	mov.s	w12, v17[2]
	fcsel	s7, s3, s2, ne
	and	x16, x12, #0x7
	add	x24, sp, #408
	bfxil	x24, x12, #0, #3
	ldrb	w12, [x24]
	and	w12, w15, w12
	stp	q4, q5, [sp, #512]
	add	x15, sp, #512
	ldr	s3, [x15, x16, lsl #2]
	tst	w12, #0x1
	fcsel	s16, s3, s2, ne
	mov.s	w12, v17[3]
	and	x15, x12, #0x7
	add	x16, sp, #408
	bfxil	x16, x12, #0, #3
	ldrb	w12, [x16]
	stp	q4, q5, [sp, #480]
	add	x16, sp, #480
	ldr	s3, [x16, x15, lsl #2]
	and	w12, w14, w12
	tst	w12, #0x1
	fcsel	s17, s3, s2, ne
	ldr	q28, [sp, #112]                 ; 16-byte Reload
	fmov	w12, s28
	and	x14, x12, #0x7
	add	x15, sp, #408
	bfxil	x15, x12, #0, #3
	ldrb	w12, [x15]
	and	w12, w2, w12
	stp	q4, q5, [sp, #704]
	add	x15, sp, #704
	ldr	s3, [x15, x14, lsl #2]
	tst	w12, #0x1
	fcsel	s3, s3, s2, ne
	mov.s	w12, v28[1]
	and	x14, x12, #0x7
	add	x15, sp, #408
	bfxil	x15, x12, #0, #3
	ldrb	w12, [x15]
	and	w12, w1, w12
	stp	q4, q5, [sp, #672]
	add	x15, sp, #672
	ldr	s22, [x15, x14, lsl #2]
	tst	w12, #0x1
	fcsel	s22, s22, s2, ne
	mov.s	w12, v28[2]
	and	x14, x12, #0x7
	add	x15, sp, #408
	bfxil	x15, x12, #0, #3
	ldrb	w12, [x15]
	and	w12, w17, w12
	stp	q4, q5, [sp, #640]
	add	x15, sp, #640
	ldr	s27, [x15, x14, lsl #2]
	tst	w12, #0x1
	fcsel	s27, s27, s2, ne
	mov.s	w12, v28[3]
	and	x14, x12, #0x7
	add	x15, sp, #408
	bfxil	x15, x12, #0, #3
	ldrb	w12, [x15]
	and	w12, w0, w12
	stp	q4, q5, [sp, #608]
	add	x15, sp, #608
	ldr	s28, [x15, x14, lsl #2]
	tst	w12, #0x1
	fcsel	s28, s28, s2, ne
	mov.s	v3[1], v22[0]
	mov.s	v3[2], v27[0]
	mov.s	v3[3], v28[0]
	mov.s	v6[1], v7[0]
	add	x12, sp, #408
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v17[0]
	fadd.4s	v4, v4, v6
	fadd.4s	v3, v5, v3
	ldr	q5, [sp, #160]                  ; 16-byte Reload
	fmov	w14, s5
	bfxil	x12, x14, #0, #3
	ldrb	w12, [x12]
	and	x14, x14, #0x7
	stp	q4, q3, [sp, #448]
	add	x15, sp, #448
	ldr	s3, [x15, x14, lsl #2]
	tst	w5, w12
	fcsel	s3, s3, s2, ne
	tst	w13, #0x1
	fmov	w12, s8
	fadd	s3, s4, s3
	fcsel	s4, s3, s2, ne
	tst	w6, #0x1
	fcsel	s5, s3, s2, ne
	tst	w7, #0x1
	fcsel	s6, s3, s2, ne
	tst	w19, #0x1
	fcsel	s7, s3, s2, ne
	tst	w4, #0x1
	fcsel	s16, s3, s2, ne
	tst	w20, #0x1
	fcsel	s17, s3, s2, ne
	tst	w21, #0x1
	fcsel	s22, s3, s2, ne
	tst	w22, #0x1
	fcsel	s3, s3, s2, ne
	mov.s	v4[1], v5[0]
	mov.s	v4[2], v6[0]
	mov.s	v4[3], v7[0]
	mov.s	v16[1], v17[0]
	mov.s	v16[2], v22[0]
	mov.s	v16[3], v3[0]
	stp	q4, q16, [sp, #416]
	add	x10, x10, x23
	add	x13, sp, #1584
	add	x13, x13, x11
	ldr	q4, [x13]
	tbnz	w12, #0, LBB0_131
; %bb.81:                               ; %else152
	tbnz	w12, #1, LBB0_132
LBB0_82:                                ; %else155
	and	x14, x3, #0x7
	add	x15, sp, #416
	tbnz	w12, #2, LBB0_133
LBB0_83:                                ; %else158
	ldr	s5, [x15, x14, lsl #2]
	mov	w14, #1115815936                ; =0x42820000
	tbnz	w12, #3, LBB0_134
LBB0_84:                                ; %else161
	fadd	s5, s5, s2
	fmov	s6, w14
	mov	w14, #50604                     ; =0xc5ac
	movk	w14, #14119, lsl #16
	ldr	q2, [x13, #16]
	tbnz	w12, #4, LBB0_135
LBB0_85:                                ; %else164
	fmov	s7, w14
	fdiv	s5, s5, s6
	tbnz	w12, #5, LBB0_136
LBB0_86:                                ; %else167
	fadd	s5, s5, s7
	tbnz	w12, #6, LBB0_137
LBB0_87:                                ; %else170
	fsqrt	s5, s5
	tbz	w12, #7, LBB0_89
LBB0_88:                                ; %cond.load172
	add	x10, x10, #28
	ld1.s	{ v2 }[3], [x10]
LBB0_89:                                ; %else173
	mov	x15, #0                         ; =0x0
	add	x10, sp, #1584
	add	x11, x10, x11
	stp	q4, q2, [x11]
	dup.4s	v5, v5[0]
	ldr	q3, [sp, #208]                  ; 16-byte Reload
	fmov	x11, d3
	add	x11, x8, x11, lsl #2
	movi.2d	v6, #0000000000000000
	fmov	w12, s30
	add	x13, sp, #2160
	add	x14, sp, #1872
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	b	LBB0_91
LBB0_90:                                ; %else190
                                        ;   in Loop: Header=BB0_91 Depth=1
	add.2d	v7, v7, v19
	add.2d	v16, v16, v20
	add.2d	v17, v17, v18
	add.2d	v6, v6, v21
	fmov	x15, d6
	cmp	x15, #8
	b.ge	LBB0_107
LBB0_91:                                ; %direct.true236
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x15, x15, #5
	add	x17, x13, x15
	ldr	q3, [x17]
	and.16b	v3, v1, v3
	fdiv.4s	v3, v3, v5
	add	x0, x14, x15
	ldr	q22, [x0]
	and.16b	v22, v1, v22
	fmul.4s	v3, v3, v22
	add	x1, x10, x15
	ldr	q22, [x1]
	and.16b	v22, v1, v22
	fadd.4s	v22, v3, v22
	add	x15, x11, x15
	tbnz	w12, #0, LBB0_100
; %bb.92:                               ; %else176
                                        ;   in Loop: Header=BB0_91 Depth=1
	and	w16, w12, #0xff
	tbnz	w16, #1, LBB0_101
LBB0_93:                                ; %else178
                                        ;   in Loop: Header=BB0_91 Depth=1
	tbnz	w16, #2, LBB0_102
LBB0_94:                                ; %else180
                                        ;   in Loop: Header=BB0_91 Depth=1
	tbz	w16, #3, LBB0_96
LBB0_95:                                ; %cond.store181
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x2, x15, #12
	st1.s	{ v22 }[3], [x2]
LBB0_96:                                ; %else182
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q3, [x17, #16]
	and.16b	v3, v0, v3
	fdiv.4s	v3, v3, v5
	ldr	q22, [x0, #16]
	and.16b	v22, v0, v22
	fmul.4s	v3, v3, v22
	ldr	q22, [x1, #16]
	and.16b	v22, v0, v22
	fadd.4s	v22, v3, v22
	tbnz	w16, #4, LBB0_103
; %bb.97:                               ; %else184
                                        ;   in Loop: Header=BB0_91 Depth=1
	tbnz	w16, #5, LBB0_104
LBB0_98:                                ; %else186
                                        ;   in Loop: Header=BB0_91 Depth=1
	tbnz	w16, #6, LBB0_105
LBB0_99:                                ; %else188
                                        ;   in Loop: Header=BB0_91 Depth=1
	tbz	w16, #7, LBB0_90
	b	LBB0_106
LBB0_100:                               ; %cond.store
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	s22, [x15]
	and	w16, w12, #0xff
	tbz	w16, #1, LBB0_93
LBB0_101:                               ; %cond.store177
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x2, x15, #4
	st1.s	{ v22 }[1], [x2]
	tbz	w16, #2, LBB0_94
LBB0_102:                               ; %cond.store179
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x2, x15, #8
	st1.s	{ v22 }[2], [x2]
	tbnz	w16, #3, LBB0_95
	b	LBB0_96
LBB0_103:                               ; %cond.store183
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	s22, [x15, #16]
	tbz	w16, #5, LBB0_98
LBB0_104:                               ; %cond.store185
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x17, x15, #20
	st1.s	{ v22 }[1], [x17]
	tbz	w16, #6, LBB0_99
LBB0_105:                               ; %cond.store187
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x17, x15, #24
	st1.s	{ v22 }[2], [x17]
	tbz	w16, #7, LBB0_90
LBB0_106:                               ; %cond.store189
                                        ;   in Loop: Header=BB0_91 Depth=1
	add	x15, x15, #28
	st1.s	{ v22 }[3], [x15]
	b	LBB0_90
LBB0_107:                               ; %direct.false237
	fdiv.4s	v0, v26, v5
	fmov	w10, s8
	zip2.8b	v1, v31, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	zip1.8b	v3, v31, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v6, v3, v23
	fmul.4s	v0, v0, v6
	and.16b	v3, v3, v4
	fadd.4s	v0, v0, v3
	ldp	q3, q4, [sp, #256]              ; 32-byte Folded Reload
	ldp	q7, q6, [sp, #224]              ; 32-byte Folded Reload
	stp	q4, q6, [sp, #336]
	stp	q7, q3, [sp, #368]
	and	x11, x9, #0x7
	add	x12, sp, #336
	ldr	x11, [x12, x11, lsl #3]
	sub	x9, x11, x9
	add	x8, x8, x9, lsl #2
	tbnz	w10, #0, LBB0_138
; %bb.108:                              ; %else193
	cmlt.4s	v1, v1, #0
	tbnz	w10, #1, LBB0_139
LBB0_109:                               ; %else195
	fdiv.4s	v3, v24, v5
	and.16b	v4, v1, v25
	tbnz	w10, #2, LBB0_140
LBB0_110:                               ; %else197
	fmul.4s	v3, v3, v4
	and.16b	v1, v1, v2
	tbnz	w10, #3, LBB0_141
LBB0_111:                               ; %else199
	fadd.4s	v0, v3, v1
	tbnz	w10, #4, LBB0_142
LBB0_112:                               ; %else201
	tbnz	w10, #5, LBB0_143
LBB0_113:                               ; %else203
	tbnz	w10, #6, LBB0_144
LBB0_114:                               ; %else205
	tbz	w10, #7, LBB0_116
LBB0_115:                               ; %cond.store206
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_116:
	add	sp, sp, #2736
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_117:                               ; %common.ret
	ret
LBB0_118:                               ; %cond.load51
	ld1.s	{ v25 }[0], [x14]
	tbz	w13, #1, LBB0_21
LBB0_119:                               ; %cond.load54
	add	x16, x14, #4
	ld1.s	{ v25 }[1], [x16]
	tbz	w13, #2, LBB0_22
LBB0_120:                               ; %cond.load57
	add	x16, x14, #8
	ld1.s	{ v25 }[2], [x16]
	tbz	w13, #3, LBB0_23
LBB0_121:                               ; %cond.load60
	add	x16, x14, #12
	ld1.s	{ v25 }[3], [x16]
	adrp	x16, lCPI0_3@PAGE
	adrp	x17, lCPI0_4@PAGE
	adrp	x0, lCPI0_5@PAGE
	ldr	q28, [x15, #16]
	tbz	w13, #4, LBB0_24
LBB0_122:                               ; %cond.load63
	add	x15, x14, #16
	ld1.s	{ v28 }[0], [x15]
	ldr	q16, [x16, lCPI0_3@PAGEOFF]
	ldr	q18, [x17, lCPI0_4@PAGEOFF]
	ldr	q23, [x0, lCPI0_5@PAGEOFF]
	tbz	w13, #5, LBB0_25
LBB0_123:                               ; %cond.load66
	add	x15, x14, #20
	ld1.s	{ v28 }[1], [x15]
	and.16b	v4, v27, v16
	and.16b	v18, v26, v18
	and.16b	v16, v19, v23
	tbnz	w13, #6, LBB0_26
	b	LBB0_27
LBB0_124:                               ; %cond.load101
	ld1.s	{ v23 }[0], [x12]
	tbz	w24, #1, LBB0_55
LBB0_125:                               ; %cond.load104
	add	x26, x12, #4
	ld1.s	{ v23 }[1], [x26]
	tbz	w24, #2, LBB0_56
LBB0_126:                               ; %cond.load107
	add	x26, x12, #8
	ld1.s	{ v23 }[2], [x26]
	tbz	w24, #3, LBB0_57
LBB0_127:                               ; %cond.load110
	add	x26, x12, #12
	ld1.s	{ v23 }[3], [x26]
	ldr	q25, [x25, #16]
	tbz	w24, #4, LBB0_58
LBB0_128:                               ; %cond.load113
	add	x25, x12, #16
	ld1.s	{ v25 }[0], [x25]
	tbz	w24, #5, LBB0_59
LBB0_129:                               ; %cond.load116
	add	x25, x12, #20
	ld1.s	{ v25 }[1], [x25]
	tbz	w24, #6, LBB0_60
LBB0_130:                               ; %cond.load119
	add	x25, x12, #24
	ld1.s	{ v25 }[2], [x25]
	tbnz	w24, #7, LBB0_61
	b	LBB0_62
LBB0_131:                               ; %cond.load151
	ld1.s	{ v4 }[0], [x10]
	tbz	w12, #1, LBB0_82
LBB0_132:                               ; %cond.load154
	add	x14, x10, #4
	ld1.s	{ v4 }[1], [x14]
	and	x14, x3, #0x7
	add	x15, sp, #416
	tbz	w12, #2, LBB0_83
LBB0_133:                               ; %cond.load157
	add	x16, x10, #8
	ld1.s	{ v4 }[2], [x16]
	ldr	s5, [x15, x14, lsl #2]
	mov	w14, #1115815936                ; =0x42820000
	tbz	w12, #3, LBB0_84
LBB0_134:                               ; %cond.load160
	add	x15, x10, #12
	ld1.s	{ v4 }[3], [x15]
	fadd	s5, s5, s2
	fmov	s6, w14
	mov	w14, #50604                     ; =0xc5ac
	movk	w14, #14119, lsl #16
	ldr	q2, [x13, #16]
	tbz	w12, #4, LBB0_85
LBB0_135:                               ; %cond.load163
	add	x13, x10, #16
	ld1.s	{ v2 }[0], [x13]
	fmov	s7, w14
	fdiv	s5, s5, s6
	tbz	w12, #5, LBB0_86
LBB0_136:                               ; %cond.load166
	add	x13, x10, #20
	ld1.s	{ v2 }[1], [x13]
	fadd	s5, s5, s7
	tbz	w12, #6, LBB0_87
LBB0_137:                               ; %cond.load169
	add	x13, x10, #24
	ld1.s	{ v2 }[2], [x13]
	fsqrt	s5, s5
	tbnz	w12, #7, LBB0_88
	b	LBB0_89
LBB0_138:                               ; %cond.store192
	str	s0, [x8]
	cmlt.4s	v1, v1, #0
	tbz	w10, #1, LBB0_109
LBB0_139:                               ; %cond.store194
	add	x9, x8, #4
	st1.s	{ v0 }[1], [x9]
	fdiv.4s	v3, v24, v5
	and.16b	v4, v1, v25
	tbz	w10, #2, LBB0_110
LBB0_140:                               ; %cond.store196
	add	x9, x8, #8
	st1.s	{ v0 }[2], [x9]
	fmul.4s	v3, v3, v4
	and.16b	v1, v1, v2
	tbz	w10, #3, LBB0_111
LBB0_141:                               ; %cond.store198
	add	x9, x8, #12
	st1.s	{ v0 }[3], [x9]
	fadd.4s	v0, v3, v1
	tbz	w10, #4, LBB0_112
LBB0_142:                               ; %cond.store200
	str	s0, [x8, #16]
	tbz	w10, #5, LBB0_113
LBB0_143:                               ; %cond.store202
	add	x9, x8, #20
	st1.s	{ v0 }[1], [x9]
	tbz	w10, #6, LBB0_114
LBB0_144:                               ; %cond.store204
	add	x9, x8, #24
	st1.s	{ v0 }[2], [x9]
	tbnz	w10, #7, LBB0_115
	b	LBB0_116
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpAdrp	Lloh22, Lloh24
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh26, Lloh27
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

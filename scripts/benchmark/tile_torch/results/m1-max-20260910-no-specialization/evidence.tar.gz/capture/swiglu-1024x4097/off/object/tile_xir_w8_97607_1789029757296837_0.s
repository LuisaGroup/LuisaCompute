	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	4096                            ; 0x1000
	.quad	4097                            ; 0x1001
lCPI0_4:
	.quad	4100                            ; 0x1004
	.quad	4101                            ; 0x1005
lCPI0_5:
	.quad	4098                            ; 0x1002
	.quad	4099                            ; 0x1003
lCPI0_6:
	.quad	4102                            ; 0x1006
	.quad	4103                            ; 0x1007
lCPI0_7:
	.quad	16384                           ; 0x4000
	.quad	16388                           ; 0x4004
lCPI0_8:
	.quad	16400                           ; 0x4010
	.quad	16404                           ; 0x4014
lCPI0_9:
	.quad	16392                           ; 0x4008
	.quad	16396                           ; 0x400c
lCPI0_10:
	.quad	16408                           ; 0x4018
	.quad	16412                           ; 0x401c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB0_84
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #448
	mov	x9, #0                          ; =0x0
	ldr	x11, [x0]
	ldr	x10, [x0, #16]
	ldr	x8, [x0, #48]
	ldr	w12, [x1]
	ldr	w13, [x1, #36]
	add	w12, w13, w12, lsl #5
	lsr	w12, w12, #3
	dup.4s	v2, w12
	and.16b	v4, v1, v2
	and.16b	v2, v0, v2
	ushll2.2d	v18, v2, #0
	ushll2.2d	v19, v4, #0
	ushll.2d	v20, v2, #0
	ushll.2d	v2, v4, #0
	fmov	x12, d2
	mov	w13, #16388                     ; =0x4004
	umaddl	x12, w12, w13, x11
Lloh4:
	adrp	x13, lCPI0_2@PAGE
Lloh5:
	ldr	q4, [x13, lCPI0_2@PAGEOFF]
	and.16b	v4, v3, v4
	addv.8h	h16, v4
	fmov	w13, s16
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #416
	b	LBB0_3
LBB0_2:                                 ; %else21
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x14, x9
	stp	q4, q5, [x15]
	add	x9, x9, #32
	cmp	x9, #4, lsl #12                 ; =16384
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x12, x9
	add	x17, x14, x9
	ldr	q4, [x17]
	tbnz	w13, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w16, w13, #0xff
	tbnz	w16, #1, LBB0_12
LBB0_5:                                 ; %else3
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #2, LBB0_13
LBB0_6:                                 ; %else6
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #3, LBB0_14
LBB0_7:                                 ; %else9
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q5, [x17, #16]
	tbnz	w16, #4, LBB0_15
LBB0_8:                                 ; %else12
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #5, LBB0_16
LBB0_9:                                 ; %else15
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #6, LBB0_17
LBB0_10:                                ; %else18
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w16, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v4 }[0], [x15]
	and	w16, w13, #0xff
	tbz	w16, #1, LBB0_5
LBB0_12:                                ; %cond.load2
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x15, #4
	ld1.s	{ v4 }[1], [x0]
	tbz	w16, #2, LBB0_6
LBB0_13:                                ; %cond.load5
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x15, #8
	ld1.s	{ v4 }[2], [x0]
	tbz	w16, #3, LBB0_7
LBB0_14:                                ; %cond.load8
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x15, #12
	ld1.s	{ v4 }[3], [x0]
	ldr	q5, [x17, #16]
	tbz	w16, #4, LBB0_8
LBB0_15:                                ; %cond.load11
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #16
	ld1.s	{ v5 }[0], [x17]
	tbz	w16, #5, LBB0_9
LBB0_16:                                ; %cond.load14
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #20
	ld1.s	{ v5 }[1], [x17]
	tbz	w16, #6, LBB0_10
LBB0_17:                                ; %cond.load17
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #24
	ld1.s	{ v5 }[2], [x17]
	tbz	w16, #7, LBB0_2
LBB0_18:                                ; %cond.load20
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x15, #28
	ld1.s	{ v5 }[3], [x15]
	b	LBB0_2
LBB0_19:                                ; %direct.false
	xtn.8b	v7, v3
	sshll2.2d	v5, v0, #0
	sshll2.2d	v6, v1, #0
	sshll.2d	v4, v0, #0
	sshll.2d	v17, v1, #0
	movi.8b	v3, #1
	and.8b	v3, v7, v3
	umov.b	w13, v3[0]
	movi.2d	v23, #0000000000000000
	movi.2d	v26, #0000000000000000
	mov.b	v26[0], v7[0]
	umaxv.8b	b21, v26
	fmov	w15, s21
	rbit	w9, w13
	clz	w9, w9
	tst	w15, #0x1
	csel	w9, w9, wzr, ne
Lloh6:
	adrp	x12, lCPI0_3@PAGE
Lloh7:
	ldr	q21, [x12, lCPI0_3@PAGEOFF]
	mov	w12, #4096                      ; =0x1000
	dup.2d	v22, x12
	mov.16b	v3, v17
	bsl.16b	v3, v21, v22
	mov	w12, #4097                      ; =0x1001
	dup.2s	v21, w12
	xtn.2s	v2, v2
	umlal.2d	v3, v2, v21
	movi.2d	v24, #0000000000000000
	mov.b	v24[0], v7[0]
	ushll.2d	v7, v24, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	str	q3, [sp, #144]                  ; 16-byte Spill
	and.16b	v7, v7, v3
	stp	q23, q23, [sp, #272]
	stp	q7, q23, [sp, #240]
	ubfiz	x16, x9, #3, #3
	add	x12, sp, #240
	ldr	x12, [x12, x16]
	sub	x12, x12, x9
	lsl	x12, x12, #2
	add	x14, x11, x12
	mov	w11, #16384                     ; =0x4000
	dup.2d	v7, x11
Lloh8:
	adrp	x11, lCPI0_7@PAGE
Lloh9:
	ldr	q23, [x11, lCPI0_7@PAGEOFF]
	bsl.16b	v17, v23, v7
Lloh10:
	adrp	x11, lCPI0_8@PAGE
Lloh11:
	ldr	q23, [x11, lCPI0_8@PAGEOFF]
	bif.16b	v23, v7, v4
Lloh12:
	adrp	x11, lCPI0_9@PAGE
Lloh13:
	ldr	q24, [x11, lCPI0_9@PAGEOFF]
	bif.16b	v24, v7, v6
Lloh14:
	adrp	x11, lCPI0_10@PAGE
Lloh15:
	ldr	q25, [x11, lCPI0_10@PAGEOFF]
	bit.16b	v7, v25, v5
	stp	q23, q7, [sp, #336]
	stp	q17, q24, [sp, #304]
	add	x11, sp, #304
	ldr	x11, [x11, x16]
	sub	x11, x11, w9, uxtw #2
	tst	w13, #0x1
	csel	x11, xzr, x11, eq
	add	x16, sp, #4, lsl #12            ; =16384
	add	x16, x16, #416
	add	x16, x16, x11
	ldr	q27, [x16]
	tbnz	w15, #0, LBB0_85
; %bb.20:                               ; %else25
	tbnz	w13, #1, LBB0_86
LBB0_21:                                ; %else28
	tbnz	w13, #2, LBB0_87
LBB0_22:                                ; %else31
	tbnz	w13, #3, LBB0_88
LBB0_23:                                ; %else34
	ldr	q28, [x16, #16]
	tbnz	w13, #4, LBB0_89
LBB0_24:                                ; %else37
	adrp	x15, lCPI0_4@PAGE
	adrp	x16, lCPI0_5@PAGE
	adrp	x17, lCPI0_6@PAGE
	tbnz	w13, #5, LBB0_90
LBB0_25:                                ; %else40
	ldr	q23, [x15, lCPI0_4@PAGEOFF]
	ldr	q24, [x16, lCPI0_5@PAGEOFF]
	ldr	q25, [x17, lCPI0_6@PAGEOFF]
	tbz	w13, #6, LBB0_27
LBB0_26:                                ; %cond.load42
	add	x15, x14, #24
	ld1.s	{ v28 }[2], [x15]
LBB0_27:                                ; %else43
	mov.16b	v3, v4
	bsl.16b	v3, v23, v22
	mov.16b	v17, v6
	bsl.16b	v17, v24, v22
	mov.16b	v7, v5
	bsl.16b	v7, v25, v22
	xtn.2s	v5, v19
	xtn.2s	v4, v20
	xtn.2s	v6, v18
	umull.2d	v2, v2, v21
	tbz	w13, #7, LBB0_29
; %bb.28:                               ; %cond.load45
	add	x13, x14, #28
	ld1.s	{ v28 }[3], [x13]
LBB0_29:                                ; %else46
	mov	x17, #0                         ; =0x0
	umlal.2d	v7, v6, v21
	umlal.2d	v17, v5, v21
	umlal.2d	v3, v4, v21
	add	x13, sp, #4, lsl #12            ; =16384
	add	x13, x13, #416
	add	x13, x13, x11
	stp	q27, q28, [x13]
	fmov	x13, d2
	lsl	x13, x13, #2
	add	x14, x10, x13
	ushll2.2d	v2, v0, #0
	mov	w15, #1                         ; =0x1
	dup.2d	v4, x15
	and.16b	v18, v2, v4
	ushll2.2d	v2, v1, #0
	and.16b	v19, v2, v4
	ushll.2d	v2, v0, #0
	and.16b	v20, v2, v4
	ushll.2d	v2, v1, #0
	and.16b	v21, v2, v4
	movi.2d	v2, #0000000000000000
	fmov	w15, s16
	add	x16, sp, #384
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	b	LBB0_31
LBB0_30:                                ; %else71
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x17, x16, x17
	stp	q22, q23, [x17]
	add.2d	v4, v4, v19
	add.2d	v5, v5, v20
	add.2d	v6, v6, v18
	add.2d	v2, v2, v21
	fmov	x17, d2
	cmp	x17, #512
	b.ge	LBB0_47
LBB0_31:                                ; %direct.true36
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x17, x17, #5
	add	x0, x14, x17
	add	x2, x16, x17
	ldr	q22, [x2]
	tbnz	w15, #0, LBB0_39
; %bb.32:                               ; %else50
                                        ;   in Loop: Header=BB0_31 Depth=1
	and	w1, w15, #0xff
	tbnz	w1, #1, LBB0_40
LBB0_33:                                ; %else53
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w1, #2, LBB0_41
LBB0_34:                                ; %else56
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w1, #3, LBB0_42
LBB0_35:                                ; %else59
                                        ;   in Loop: Header=BB0_31 Depth=1
	ldr	q23, [x2, #16]
	tbnz	w1, #4, LBB0_43
LBB0_36:                                ; %else62
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w1, #5, LBB0_44
LBB0_37:                                ; %else65
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w1, #6, LBB0_45
LBB0_38:                                ; %else68
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbz	w1, #7, LBB0_30
	b	LBB0_46
LBB0_39:                                ; %cond.load49
                                        ;   in Loop: Header=BB0_31 Depth=1
	ld1.s	{ v22 }[0], [x0]
	and	w1, w15, #0xff
	tbz	w1, #1, LBB0_33
LBB0_40:                                ; %cond.load52
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x3, x0, #4
	ld1.s	{ v22 }[1], [x3]
	tbz	w1, #2, LBB0_34
LBB0_41:                                ; %cond.load55
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x3, x0, #8
	ld1.s	{ v22 }[2], [x3]
	tbz	w1, #3, LBB0_35
LBB0_42:                                ; %cond.load58
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x3, x0, #12
	ld1.s	{ v22 }[3], [x3]
	ldr	q23, [x2, #16]
	tbz	w1, #4, LBB0_36
LBB0_43:                                ; %cond.load61
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x2, x0, #16
	ld1.s	{ v23 }[0], [x2]
	tbz	w1, #5, LBB0_37
LBB0_44:                                ; %cond.load64
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x2, x0, #20
	ld1.s	{ v23 }[1], [x2]
	tbz	w1, #6, LBB0_38
LBB0_45:                                ; %cond.load67
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x2, x0, #24
	ld1.s	{ v23 }[2], [x2]
	tbz	w1, #7, LBB0_30
LBB0_46:                                ; %cond.load70
                                        ;   in Loop: Header=BB0_31 Depth=1
	add	x0, x0, #28
	ld1.s	{ v23 }[3], [x0]
	b	LBB0_30
LBB0_47:                                ; %direct.false37
	add	x10, x10, x12
	add	x12, sp, #384
	add	x14, x12, x11
	ldr	q5, [x14]
Lloh16:
	adrp	x12, lCPI0_11@PAGE
Lloh17:
	ldr	d2, [x12, lCPI0_11@PAGEOFF]
	shl.8b	v4, v26, #7
	cmlt.8b	v4, v4, #0
	and.8b	v2, v4, v2
	addv.8b	b2, v2
	str	d2, [sp, #8]                    ; 8-byte Spill
	fmov	w12, s2
	tbnz	w12, #0, LBB0_91
; %bb.48:                               ; %else75
	tbnz	w12, #1, LBB0_92
LBB0_49:                                ; %else78
	tbnz	w12, #2, LBB0_93
LBB0_50:                                ; %else81
	tbnz	w12, #3, LBB0_94
LBB0_51:                                ; %else84
	ldr	q2, [x14, #16]
	tbnz	w12, #4, LBB0_95
LBB0_52:                                ; %else87
	tbnz	w12, #5, LBB0_96
LBB0_53:                                ; %else90
	tbnz	w12, #6, LBB0_97
LBB0_54:                                ; %else93
	str	q26, [sp, #128]                 ; 16-byte Spill
	stp	q28, q27, [sp, #48]             ; 32-byte Folded Spill
	tbz	w12, #7, LBB0_56
LBB0_55:                                ; %cond.load95
	add	x10, x10, #28
	ld1.s	{ v2 }[3], [x10]
LBB0_56:                                ; %else96
	stp	q17, q7, [sp, #80]              ; 32-byte Folded Spill
	str	q3, [sp, #112]                  ; 16-byte Spill
	mov	x14, #0                         ; =0x0
	add	x10, sp, #384
	add	x11, x10, x11
	stp	q2, q5, [sp, #16]               ; 32-byte Folded Spill
	stp	q5, q2, [x11]
	add	x11, x8, x13
	movi.2d	v25, #0000000000000000
	fmov	w12, s16
	mov	w13, #-1026555904               ; =0xc2d00000
	dup.4s	v16, w13
	mov	w13, #1120403456                ; =0x42c80000
	dup.4s	v26, w13
	mov	w13, #43579                     ; =0xaa3b
	movk	w13, #16312, lsl #16
	dup.4s	v27, w13
	mov	w13, #29184                     ; =0x7200
	movk	w13, #48945, lsl #16
	dup.4s	v28, w13
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #46527, lsl #16
	dup.4s	v29, w13
	mov	w13, #11226                     ; =0x2bda
	movk	w13, #14672, lsl #16
	dup.4s	v30, w13
	mov	w13, #38601                     ; =0x96c9
	movk	w13, #15030, lsl #16
	dup.4s	v31, w13
	mov	w13, #34982                     ; =0x88a6
	movk	w13, #15368, lsl #16
	dup.4s	v8, w13
	mov	w13, #43642                     ; =0xaa7a
	movk	w13, #15658, lsl #16
	dup.4s	v9, w13
	mov	w13, #43691                     ; =0xaaab
	movk	w13, #15914, lsl #16
	dup.4s	v10, w13
	add	x13, sp, #4, lsl #12            ; =16384
	add	x13, x13, #416
	movi.4s	v11, #75, lsl #24
	mvni.4s	v12, #128, lsl #24
	movi.4s	v13, #63, lsl #24
	fmov.4s	v14, #1.00000000
	mvni.4s	v2, #127, msl #16
	fneg.4s	v15, v2
	mvni.4s	v2, #63, msl #16
	fneg.4s	v4, v2
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v2, #0000000000000000
	b	LBB0_58
LBB0_57:                                ; %else113
                                        ;   in Loop: Header=BB0_58 Depth=1
	add.2d	v5, v5, v19
	add.2d	v6, v6, v20
	add.2d	v2, v2, v18
	add.2d	v25, v25, v21
	fmov	x14, d25
	cmp	x14, #512
	b.ge	LBB0_74
LBB0_58:                                ; %direct.true57
                                        ; =>This Inner Loop Header: Depth=1
	lsl	x14, x14, #5
	add	x16, x13, x14
	ldr	q24, [x16]
	and.16b	v24, v1, v24
	fneg.4s	v3, v24
	and.16b	v3, v1, v3
	fcmge.4s	v7, v3, v16
	fcmge.4s	v17, v26, v3
	and.16b	v7, v7, v17
	and.16b	v7, v7, v3
	fmul.4s	v17, v7, v27
	mov.16b	v22, v12
	bsl.16b	v22, v11, v17
	fadd.4s	v17, v17, v22
	fsub.4s	v17, v17, v22
	fcvtzs.4s	v17, v17
	scvtf.4s	v22, v17
	fmul.4s	v23, v22, v28
	fadd.4s	v7, v7, v23
	fmul.4s	v22, v22, v29
	fadd.4s	v7, v7, v22
	fmul.4s	v22, v7, v30
	fadd.4s	v22, v22, v31
	fmul.4s	v22, v7, v22
	fadd.4s	v22, v22, v8
	fmul.4s	v22, v7, v22
	fadd.4s	v22, v22, v9
	fmul.4s	v22, v7, v22
	fadd.4s	v22, v22, v10
	fmul.4s	v22, v7, v22
	fadd.4s	v22, v22, v13
	fmul.4s	v23, v7, v7
	fmul.4s	v22, v23, v22
	fadd.4s	v7, v7, v22
	fadd.4s	v7, v7, v14
	sshr.4s	v22, v17, #1
	shl.4s	v23, v22, #23
	add.4s	v23, v23, v14
	fmul.4s	v7, v7, v23
	sub.4s	v17, v17, v22
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v14
	fmul.4s	v7, v7, v17
	fcmgt.4s	v17, v16, v3
	fcmgt.4s	v22, v3, v26
	fcmeq.4s	v3, v3, v3
	fadd.4s	v7, v7, v14
	bit.16b	v7, v14, v17
	bit.16b	v7, v15, v22
	bsl.16b	v3, v7, v4
	fdiv.4s	v3, v24, v3
	add	x17, x10, x14
	ldr	q7, [x17]
	and.16b	v7, v1, v7
	fmul.4s	v24, v7, v3
	add	x14, x11, x14
	tbnz	w12, #0, LBB0_67
; %bb.59:                               ; %else99
                                        ;   in Loop: Header=BB0_58 Depth=1
	and	w15, w12, #0xff
	tbnz	w15, #1, LBB0_68
LBB0_60:                                ; %else101
                                        ;   in Loop: Header=BB0_58 Depth=1
	tbnz	w15, #2, LBB0_69
LBB0_61:                                ; %else103
                                        ;   in Loop: Header=BB0_58 Depth=1
	tbz	w15, #3, LBB0_63
LBB0_62:                                ; %cond.store104
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x0, x14, #12
	st1.s	{ v24 }[3], [x0]
LBB0_63:                                ; %else105
                                        ;   in Loop: Header=BB0_58 Depth=1
	ldr	q3, [x16, #16]
	and.16b	v3, v0, v3
	fneg.4s	v7, v3
	and.16b	v7, v0, v7
	fcmge.4s	v17, v7, v16
	fcmge.4s	v22, v26, v7
	and.16b	v17, v17, v22
	and.16b	v17, v17, v7
	fmul.4s	v22, v17, v27
	mov.16b	v23, v12
	bsl.16b	v23, v11, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v22, v22
	scvtf.4s	v23, v22
	fmul.4s	v24, v23, v28
	fadd.4s	v17, v17, v24
	fmul.4s	v23, v23, v29
	fadd.4s	v17, v17, v23
	fmul.4s	v23, v17, v30
	fadd.4s	v23, v23, v31
	fmul.4s	v23, v17, v23
	fadd.4s	v23, v23, v8
	fmul.4s	v23, v17, v23
	fadd.4s	v23, v23, v9
	fmul.4s	v23, v17, v23
	fadd.4s	v23, v23, v10
	fmul.4s	v23, v17, v23
	fadd.4s	v23, v23, v13
	fmul.4s	v24, v17, v17
	fmul.4s	v23, v24, v23
	fadd.4s	v17, v17, v23
	fadd.4s	v17, v17, v14
	sshr.4s	v23, v22, #1
	shl.4s	v24, v23, #23
	add.4s	v24, v24, v14
	fmul.4s	v17, v17, v24
	sub.4s	v22, v22, v23
	shl.4s	v22, v22, #23
	add.4s	v22, v22, v14
	fmul.4s	v17, v17, v22
	fcmgt.4s	v22, v16, v7
	fcmgt.4s	v23, v7, v26
	fcmeq.4s	v7, v7, v7
	fadd.4s	v17, v17, v14
	bit.16b	v17, v14, v22
	bit.16b	v17, v15, v23
	bsl.16b	v7, v17, v4
	fdiv.4s	v3, v3, v7
	ldr	q7, [x17, #16]
	and.16b	v7, v0, v7
	fmul.4s	v24, v7, v3
	tbnz	w15, #4, LBB0_70
; %bb.64:                               ; %else107
                                        ;   in Loop: Header=BB0_58 Depth=1
	tbnz	w15, #5, LBB0_71
LBB0_65:                                ; %else109
                                        ;   in Loop: Header=BB0_58 Depth=1
	tbnz	w15, #6, LBB0_72
LBB0_66:                                ; %else111
                                        ;   in Loop: Header=BB0_58 Depth=1
	tbz	w15, #7, LBB0_57
	b	LBB0_73
LBB0_67:                                ; %cond.store
                                        ;   in Loop: Header=BB0_58 Depth=1
	str	s24, [x14]
	and	w15, w12, #0xff
	tbz	w15, #1, LBB0_60
LBB0_68:                                ; %cond.store100
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x0, x14, #4
	st1.s	{ v24 }[1], [x0]
	tbz	w15, #2, LBB0_61
LBB0_69:                                ; %cond.store102
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x0, x14, #8
	st1.s	{ v24 }[2], [x0]
	tbnz	w15, #3, LBB0_62
	b	LBB0_63
LBB0_70:                                ; %cond.store106
                                        ;   in Loop: Header=BB0_58 Depth=1
	str	s24, [x14, #16]
	tbz	w15, #5, LBB0_65
LBB0_71:                                ; %cond.store108
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x16, x14, #20
	st1.s	{ v24 }[1], [x16]
	tbz	w15, #6, LBB0_66
LBB0_72:                                ; %cond.store110
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x16, x14, #24
	st1.s	{ v24 }[2], [x16]
	tbz	w15, #7, LBB0_57
LBB0_73:                                ; %cond.store112
                                        ;   in Loop: Header=BB0_58 Depth=1
	add	x14, x14, #28
	st1.s	{ v24 }[3], [x14]
	b	LBB0_57
LBB0_74:                                ; %direct.false58
	ldr	d0, [sp, #8]                    ; 8-byte Reload
	fmov	w10, s0
	ldr	q1, [sp, #128]                  ; 16-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v4, v0, #0
	ldr	q0, [sp, #64]                   ; 16-byte Reload
	and.16b	v5, v4, v0
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q1, [sp, #48]                   ; 16-byte Reload
	and.16b	v1, v0, v1
	fneg.4s	v2, v1
	fneg.4s	v3, v5
	and.16b	v3, v4, v3
	mov	w11, #-1026555904               ; =0xc2d00000
	dup.4s	v6, w11
	and.16b	v2, v0, v2
	fcmge.4s	v16, v2, v6
	fcmge.4s	v17, v3, v6
	mov	w11, #1120403456                ; =0x42c80000
	dup.4s	v7, w11
	fcmge.4s	v18, v7, v2
	fcmge.4s	v19, v7, v3
	and.16b	v17, v17, v19
	and.16b	v16, v16, v18
	and.16b	v16, v16, v2
	and.16b	v17, v17, v3
	mov	w11, #43579                     ; =0xaa3b
	movk	w11, #16312, lsl #16
	dup.4s	v18, w11
	fmul.4s	v19, v17, v18
	fmul.4s	v18, v16, v18
	movi.4s	v20, #75, lsl #24
	mvni.4s	v21, #128, lsl #24
	mov.16b	v22, v21
	bsl.16b	v22, v20, v18
	bif.16b	v20, v19, v21
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v22
	fsub.4s	v18, v18, v22
	fsub.4s	v19, v19, v20
	fcvtzs.4s	v19, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v20, v18
	scvtf.4s	v21, v19
	mov	w11, #29184                     ; =0x7200
	movk	w11, #48945, lsl #16
	dup.4s	v22, w11
	fmul.4s	v23, v21, v22
	fmul.4s	v22, v20, v22
	fadd.4s	v16, v16, v22
	fadd.4s	v17, v17, v23
	mov	w11, #48782                     ; =0xbe8e
	movk	w11, #46527, lsl #16
	dup.4s	v22, w11
	fmul.4s	v20, v20, v22
	fmul.4s	v21, v21, v22
	fadd.4s	v17, v17, v21
	fadd.4s	v16, v16, v20
	mov	w11, #11226                     ; =0x2bda
	movk	w11, #14672, lsl #16
	dup.4s	v20, w11
	fmul.4s	v21, v16, v20
	fmul.4s	v20, v17, v20
	mov	w11, #38601                     ; =0x96c9
	movk	w11, #15030, lsl #16
	dup.4s	v22, w11
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	mov	w11, #34982                     ; =0x88a6
	movk	w11, #15368, lsl #16
	dup.4s	v22, w11
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	mov	w11, #43642                     ; =0xaa7a
	movk	w11, #15658, lsl #16
	dup.4s	v22, w11
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	mov	w11, #43691                     ; =0xaaab
	movk	w11, #15914, lsl #16
	dup.4s	v22, w11
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v21, v16, v21
	fmul.4s	v20, v17, v20
	movi.4s	v22, #63, lsl #24
	fadd.4s	v20, v20, v22
	fadd.4s	v21, v21, v22
	fmul.4s	v22, v17, v17
	fmul.4s	v23, v16, v16
	fmul.4s	v21, v23, v21
	fmul.4s	v20, v22, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v21
	fmov.4s	v20, #1.00000000
	fadd.4s	v16, v16, v20
	fadd.4s	v17, v17, v20
	sshr.4s	v21, v18, #1
	sshr.4s	v22, v19, #1
	shl.4s	v23, v22, #23
	shl.4s	v24, v21, #23
	add.4s	v24, v24, v20
	add.4s	v23, v23, v20
	fmul.4s	v17, v17, v23
	fmul.4s	v16, v16, v24
	sub.4s	v19, v19, v22
	sub.4s	v18, v18, v21
	shl.4s	v18, v18, #23
	shl.4s	v19, v19, #23
	add.4s	v19, v19, v20
	add.4s	v18, v18, v20
	fmul.4s	v16, v16, v18
	fmul.4s	v17, v17, v19
	fcmgt.4s	v18, v6, v3
	fcmgt.4s	v19, v6, v2
	fcmgt.4s	v6, v2, v7
	fcmgt.4s	v7, v3, v7
	fcmeq.4s	v3, v3, v3
	fadd.4s	v17, v17, v20
	fadd.4s	v16, v16, v20
	bit.16b	v16, v20, v19
	bsl.16b	v18, v20, v17
	mvni.4s	v17, #127, msl #16
	fneg.4s	v17, v17
	bit.16b	v18, v17, v7
	mvni.4s	v7, #63, msl #16
	fneg.4s	v7, v7
	bsl.16b	v3, v18, v7
	fdiv.4s	v3, v5, v3
	ldr	q5, [sp, #32]                   ; 16-byte Reload
	and.16b	v4, v4, v5
	fmul.4s	v3, v3, v4
	ldr	q5, [sp, #144]                  ; 16-byte Reload
	ldr	q4, [sp, #80]                   ; 16-byte Reload
	stp	q5, q4, [sp, #160]
	ldp	q4, q5, [sp, #96]               ; 32-byte Folded Reload
	stp	q5, q4, [sp, #192]
	and	x11, x9, #0x7
	add	x12, sp, #160
	ldr	x11, [x12, x11, lsl #3]
	sub	x9, x11, x9
	add	x8, x8, x9, lsl #2
	tbnz	w10, #0, LBB0_98
; %bb.75:                               ; %else116
	fcmeq.4s	v2, v2, v2
	mov.16b	v4, v6
	bsl.16b	v4, v17, v16
	tbnz	w10, #1, LBB0_99
LBB0_76:                                ; %else118
	bsl.16b	v2, v4, v7
	tbnz	w10, #2, LBB0_100
LBB0_77:                                ; %else120
	fdiv.4s	v1, v1, v2
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v0, v0, v2
	tbnz	w10, #3, LBB0_101
LBB0_78:                                ; %else122
	fmul.4s	v0, v1, v0
	tbnz	w10, #4, LBB0_102
LBB0_79:                                ; %else124
	tbnz	w10, #5, LBB0_103
LBB0_80:                                ; %else126
	tbnz	w10, #6, LBB0_104
LBB0_81:                                ; %else128
	tbz	w10, #7, LBB0_83
LBB0_82:                                ; %cond.store129
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_83:
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #448
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
LBB0_84:                                ; %common.ret
	ret
LBB0_85:                                ; %cond.load24
	ld1.s	{ v27 }[0], [x14]
	tbz	w13, #1, LBB0_21
LBB0_86:                                ; %cond.load27
	add	x15, x14, #4
	ld1.s	{ v27 }[1], [x15]
	tbz	w13, #2, LBB0_22
LBB0_87:                                ; %cond.load30
	add	x15, x14, #8
	ld1.s	{ v27 }[2], [x15]
	tbz	w13, #3, LBB0_23
LBB0_88:                                ; %cond.load33
	add	x15, x14, #12
	ld1.s	{ v27 }[3], [x15]
	ldr	q28, [x16, #16]
	tbz	w13, #4, LBB0_24
LBB0_89:                                ; %cond.load36
	add	x15, x14, #16
	ld1.s	{ v28 }[0], [x15]
	adrp	x15, lCPI0_4@PAGE
	adrp	x16, lCPI0_5@PAGE
	adrp	x17, lCPI0_6@PAGE
	tbz	w13, #5, LBB0_25
LBB0_90:                                ; %cond.load39
	add	x0, x14, #20
	ld1.s	{ v28 }[1], [x0]
	ldr	q23, [x15, lCPI0_4@PAGEOFF]
	ldr	q24, [x16, lCPI0_5@PAGEOFF]
	ldr	q25, [x17, lCPI0_6@PAGEOFF]
	tbnz	w13, #6, LBB0_26
	b	LBB0_27
LBB0_91:                                ; %cond.load74
	ld1.s	{ v5 }[0], [x10]
	tbz	w12, #1, LBB0_49
LBB0_92:                                ; %cond.load77
	add	x15, x10, #4
	ld1.s	{ v5 }[1], [x15]
	tbz	w12, #2, LBB0_50
LBB0_93:                                ; %cond.load80
	add	x15, x10, #8
	ld1.s	{ v5 }[2], [x15]
	tbz	w12, #3, LBB0_51
LBB0_94:                                ; %cond.load83
	add	x15, x10, #12
	ld1.s	{ v5 }[3], [x15]
	ldr	q2, [x14, #16]
	tbz	w12, #4, LBB0_52
LBB0_95:                                ; %cond.load86
	add	x14, x10, #16
	ld1.s	{ v2 }[0], [x14]
	tbz	w12, #5, LBB0_53
LBB0_96:                                ; %cond.load89
	add	x14, x10, #20
	ld1.s	{ v2 }[1], [x14]
	tbz	w12, #6, LBB0_54
LBB0_97:                                ; %cond.load92
	add	x14, x10, #24
	ld1.s	{ v2 }[2], [x14]
	str	q26, [sp, #128]                 ; 16-byte Spill
	stp	q28, q27, [sp, #48]             ; 32-byte Folded Spill
	tbnz	w12, #7, LBB0_55
	b	LBB0_56
LBB0_98:                                ; %cond.store115
	str	s3, [x8]
	fcmeq.4s	v2, v2, v2
	mov.16b	v4, v6
	bsl.16b	v4, v17, v16
	tbz	w10, #1, LBB0_76
LBB0_99:                                ; %cond.store117
	add	x9, x8, #4
	st1.s	{ v3 }[1], [x9]
	bsl.16b	v2, v4, v7
	tbz	w10, #2, LBB0_77
LBB0_100:                               ; %cond.store119
	add	x9, x8, #8
	st1.s	{ v3 }[2], [x9]
	fdiv.4s	v1, v1, v2
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v0, v0, v2
	tbz	w10, #3, LBB0_78
LBB0_101:                               ; %cond.store121
	add	x9, x8, #12
	st1.s	{ v3 }[3], [x9]
	fmul.4s	v0, v1, v0
	tbz	w10, #4, LBB0_79
LBB0_102:                               ; %cond.store123
	str	s0, [x8, #16]
	tbz	w10, #5, LBB0_80
LBB0_103:                               ; %cond.store125
	add	x9, x8, #20
	st1.s	{ v0 }[1], [x9]
	tbz	w10, #6, LBB0_81
LBB0_104:                               ; %cond.store127
	add	x9, x8, #24
	st1.s	{ v0 }[2], [x9]
	tbnz	w10, #7, LBB0_82
	b	LBB0_83
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh16, Lloh17
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

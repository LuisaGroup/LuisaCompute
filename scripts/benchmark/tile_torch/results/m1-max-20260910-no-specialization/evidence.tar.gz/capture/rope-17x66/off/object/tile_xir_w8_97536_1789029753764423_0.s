	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_8:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_10:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_11:
	.quad	14                              ; 0xe
	.quad	15                              ; 0xf
lCPI0_12:
	.quad	10                              ; 0xa
	.quad	11                              ; 0xb
lCPI0_13:
	.quad	12                              ; 0xc
	.quad	13                              ; 0xd
lCPI0_14:
	.quad	8                               ; 0x8
	.quad	9                               ; 0x9
lCPI0_15:
	.quad	32                              ; 0x20
	.quad	0                               ; 0x0
lCPI0_16:
	.quad	22                              ; 0x16
	.quad	23                              ; 0x17
lCPI0_17:
	.quad	18                              ; 0x12
	.quad	19                              ; 0x13
lCPI0_18:
	.quad	20                              ; 0x14
	.quad	21                              ; 0x15
lCPI0_19:
	.quad	16                              ; 0x10
	.quad	17                              ; 0x11
lCPI0_20:
	.quad	64                              ; 0x40
	.quad	0                               ; 0x0
lCPI0_21:
	.quad	30                              ; 0x1e
	.quad	31                              ; 0x1f
lCPI0_22:
	.quad	26                              ; 0x1a
	.quad	27                              ; 0x1b
lCPI0_23:
	.quad	28                              ; 0x1c
	.quad	29                              ; 0x1d
lCPI0_24:
	.quad	24                              ; 0x18
	.quad	25                              ; 0x19
lCPI0_25:
	.quad	96                              ; 0x60
	.quad	0                               ; 0x0
lCPI0_26:
	.quad	32                              ; 0x20
	.quad	33                              ; 0x21
lCPI0_27:
	.quad	152                             ; 0x98
	.quad	156                             ; 0x9c
lCPI0_28:
	.quad	144                             ; 0x90
	.quad	148                             ; 0x94
lCPI0_29:
	.quad	136                             ; 0x88
	.quad	140                             ; 0x8c
lCPI0_30:
	.quad	128                             ; 0x80
	.quad	132                             ; 0x84
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_31:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #1696
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v10, v0, v2
	cmhi.4s	v1, v0, v1
	uzp1.8h	v3, v1, v10
	umaxv.8h	h0, v3
	fmov	w8, s0
	tbz	w8, #0, LBB0_325
; %bb.1:                                ; %direct.activate
Lloh4:
	adrp	x8, lCPI0_2@PAGE
Lloh5:
	ldr	q0, [x8, lCPI0_2@PAGEOFF]
	and.16b	v0, v3, v0
	addv.8h	h2, v0
	fmov	w10, s2
	and	w8, w10, #0xff
	ldr	w9, [x1]
	ldr	w11, [x1, #36]
	add	w9, w11, w9, lsl #5
	lsr	w9, w9, #3
	dup.4s	v21, w9
	ldr	x15, [x0]
	and.16b	v13, v1, v21
	movi.2s	v5, #66
	umull.2d	v4, v13, v5
	fmov	x9, d4
	add	x9, x15, x9, lsl #2
	tbz	w10, #0, LBB0_3
; %bb.2:                                ; %cond.load
	ldr	s0, [x9]
	tbnz	w8, #1, LBB0_4
	b	LBB0_5
LBB0_3:
                                        ; implicit-def: $q0
	tbz	w8, #1, LBB0_5
LBB0_4:                                 ; %cond.load1
	add	x10, x9, #4
	ld1.s	{ v0 }[1], [x10]
LBB0_5:                                 ; %else2
	tbnz	w8, #2, LBB0_9
; %bb.6:                                ; %else5
	tbnz	w8, #3, LBB0_10
LBB0_7:                                 ; %else8
	tbz	w8, #4, LBB0_11
LBB0_8:                                 ; %cond.load10
	add	x10, x9, #16
	ld1.s	{ v6 }[0], [x10]
	tbnz	w8, #5, LBB0_12
	b	LBB0_13
LBB0_9:                                 ; %cond.load4
	add	x10, x9, #8
	ld1.s	{ v0 }[2], [x10]
	tbz	w8, #3, LBB0_7
LBB0_10:                                ; %cond.load7
	add	x10, x9, #12
	ld1.s	{ v0 }[3], [x10]
	tbnz	w8, #4, LBB0_8
LBB0_11:
                                        ; implicit-def: $q6
	tbz	w8, #5, LBB0_13
LBB0_12:                                ; %cond.load13
	add	x10, x9, #20
	ld1.s	{ v6 }[1], [x10]
LBB0_13:                                ; %else14
	tbnz	w8, #6, LBB0_18
; %bb.14:                               ; %else17
	tbz	w8, #7, LBB0_16
LBB0_15:                                ; %cond.load19
	add	x8, x9, #28
	ld1.s	{ v6 }[3], [x8]
LBB0_16:                                ; %else20
	ldr	x8, [x0, #48]
	ldr	x12, [x0, #32]
	ldr	x14, [x0, #16]
	fmov	w11, s2
	and	w9, w11, #0xff
	str	q0, [sp, #1536]
	str	q6, [sp, #1552]
Lloh6:
	adrp	x10, lCPI0_14@PAGE
Lloh7:
	ldr	q16, [x10, lCPI0_14@PAGEOFF]
	add.2d	v0, v4, v16
	str	q0, [sp, #352]                  ; 16-byte Spill
	fmov	x10, d0
	add	x10, x15, x10, lsl #2
	tbz	w11, #0, LBB0_19
; %bb.17:                               ; %cond.load23
	ldr	s0, [x10]
	tbnz	w9, #1, LBB0_20
	b	LBB0_21
LBB0_18:                                ; %cond.load16
	add	x10, x9, #24
	ld1.s	{ v6 }[2], [x10]
	tbnz	w8, #7, LBB0_15
	b	LBB0_16
LBB0_19:
                                        ; implicit-def: $q0
	tbz	w9, #1, LBB0_21
LBB0_20:                                ; %cond.load26
	add	x11, x10, #4
	ld1.s	{ v0 }[1], [x11]
LBB0_21:                                ; %else27
	tbnz	w9, #2, LBB0_25
; %bb.22:                               ; %else30
	tbnz	w9, #3, LBB0_26
LBB0_23:                                ; %else33
	tbz	w9, #4, LBB0_27
LBB0_24:                                ; %cond.load35
	add	x11, x10, #16
	ld1.s	{ v6 }[0], [x11]
	tbnz	w9, #5, LBB0_28
	b	LBB0_29
LBB0_25:                                ; %cond.load29
	add	x11, x10, #8
	ld1.s	{ v0 }[2], [x11]
	tbz	w9, #3, LBB0_23
LBB0_26:                                ; %cond.load32
	add	x11, x10, #12
	ld1.s	{ v0 }[3], [x11]
	tbnz	w9, #4, LBB0_24
LBB0_27:
                                        ; implicit-def: $q6
	tbz	w9, #5, LBB0_29
LBB0_28:                                ; %cond.load38
	add	x11, x10, #20
	ld1.s	{ v6 }[1], [x11]
LBB0_29:                                ; %else39
	tbnz	w9, #6, LBB0_34
; %bb.30:                               ; %else42
	tbz	w9, #7, LBB0_32
LBB0_31:                                ; %cond.load44
	add	x9, x10, #28
	ld1.s	{ v6 }[3], [x9]
LBB0_32:                                ; %else45
	fmov	w11, s2
	and	w9, w11, #0xff
	str	q0, [sp, #1568]
	str	q6, [sp, #1584]
Lloh8:
	adrp	x10, lCPI0_19@PAGE
Lloh9:
	ldr	q6, [x10, lCPI0_19@PAGEOFF]
	add.2d	v0, v4, v6
	str	q0, [sp, #336]                  ; 16-byte Spill
	fmov	x10, d0
	add	x10, x15, x10, lsl #2
	tbz	w11, #0, LBB0_35
; %bb.33:                               ; %cond.load48
	ldr	s0, [x10]
	tbnz	w9, #1, LBB0_36
	b	LBB0_37
LBB0_34:                                ; %cond.load41
	add	x11, x10, #24
	ld1.s	{ v6 }[2], [x11]
	tbnz	w9, #7, LBB0_31
	b	LBB0_32
LBB0_35:
                                        ; implicit-def: $q0
	tbz	w9, #1, LBB0_37
LBB0_36:                                ; %cond.load51
	add	x11, x10, #4
	ld1.s	{ v0 }[1], [x11]
LBB0_37:                                ; %else52
	tbnz	w9, #2, LBB0_41
; %bb.38:                               ; %else55
	tbnz	w9, #3, LBB0_42
LBB0_39:                                ; %else58
	tbz	w9, #4, LBB0_43
LBB0_40:                                ; %cond.load60
	add	x11, x10, #16
	ld1.s	{ v7 }[0], [x11]
	tbnz	w9, #5, LBB0_44
	b	LBB0_45
LBB0_41:                                ; %cond.load54
	add	x11, x10, #8
	ld1.s	{ v0 }[2], [x11]
	tbz	w9, #3, LBB0_39
LBB0_42:                                ; %cond.load57
	add	x11, x10, #12
	ld1.s	{ v0 }[3], [x11]
	tbnz	w9, #4, LBB0_40
LBB0_43:
                                        ; implicit-def: $q7
	tbz	w9, #5, LBB0_45
LBB0_44:                                ; %cond.load63
	add	x11, x10, #20
	ld1.s	{ v7 }[1], [x11]
LBB0_45:                                ; %else64
	tbnz	w9, #6, LBB0_50
; %bb.46:                               ; %else67
	tbz	w9, #7, LBB0_48
LBB0_47:                                ; %cond.load69
	add	x9, x10, #28
	ld1.s	{ v7 }[3], [x9]
LBB0_48:                                ; %else70
	fmov	w11, s2
	and	w9, w11, #0xff
	str	q0, [sp, #1600]
	str	q7, [sp, #1616]
Lloh10:
	adrp	x10, lCPI0_24@PAGE
Lloh11:
	ldr	q7, [x10, lCPI0_24@PAGEOFF]
	add.2d	v0, v4, v7
	str	q0, [sp, #320]                  ; 16-byte Spill
	fmov	x10, d0
	add	x10, x15, x10, lsl #2
	tbz	w11, #0, LBB0_51
; %bb.49:                               ; %cond.load73
	ldr	s0, [x10]
	tbnz	w9, #1, LBB0_52
	b	LBB0_53
LBB0_50:                                ; %cond.load66
	add	x11, x10, #24
	ld1.s	{ v7 }[2], [x11]
	tbnz	w9, #7, LBB0_47
	b	LBB0_48
LBB0_51:
                                        ; implicit-def: $q0
	tbz	w9, #1, LBB0_53
LBB0_52:                                ; %cond.load76
	add	x11, x10, #4
	ld1.s	{ v0 }[1], [x11]
LBB0_53:                                ; %else77
	tbnz	w9, #2, LBB0_57
; %bb.54:                               ; %else80
	tbnz	w9, #3, LBB0_58
LBB0_55:                                ; %else83
	tbz	w9, #4, LBB0_59
LBB0_56:                                ; %cond.load85
	add	x11, x10, #16
	ld1.s	{ v17 }[0], [x11]
	tbnz	w9, #5, LBB0_60
	b	LBB0_61
LBB0_57:                                ; %cond.load79
	add	x11, x10, #8
	ld1.s	{ v0 }[2], [x11]
	tbz	w9, #3, LBB0_55
LBB0_58:                                ; %cond.load82
	add	x11, x10, #12
	ld1.s	{ v0 }[3], [x11]
	tbnz	w9, #4, LBB0_56
LBB0_59:
                                        ; implicit-def: $q17
	tbz	w9, #5, LBB0_61
LBB0_60:                                ; %cond.load88
	add	x11, x10, #20
	ld1.s	{ v17 }[1], [x11]
LBB0_61:                                ; %else89
	tbnz	w9, #6, LBB0_75
; %bb.62:                               ; %else92
	tbz	w9, #7, LBB0_64
LBB0_63:                                ; %cond.load94
	add	x9, x10, #28
	ld1.s	{ v17 }[3], [x9]
LBB0_64:                                ; %else95
	xtn.8b	v18, v3
	str	q0, [sp, #1632]
	str	q17, [sp, #1648]
	movi.8b	v0, #1
	and.8b	v0, v18, v0
	umov.b	w10, v0[0]
	movi.2d	v0, #0000000000000000
	movi.2d	v3, #0000000000000000
	mov.b	v3[0], v18[0]
	umaxv.8b	b17, v3
	fmov	w0, s17
	rbit	w9, w10
	clz	w9, w9
	tst	w0, #0x1
	csel	w9, w9, wzr, ne
Lloh12:
	adrp	x11, lCPI0_26@PAGE
Lloh13:
	ldr	q17, [x11, lCPI0_26@PAGEOFF]
	add.2d	v17, v4, v17
	movi.2d	v19, #0000000000000000
	mov.b	v19[0], v18[0]
	ushll.2d	v18, v19, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	and.16b	v17, v18, v17
	stp	q0, q0, [sp, #944]
	stp	q17, q0, [sp, #912]
	ubfiz	x11, x9, #3, #3
	add	x13, sp, #912
	ldr	x13, [x13, x11]
	sub	x13, x13, x9
	add	x16, x15, x13, lsl #2
Lloh14:
	adrp	x13, lCPI0_27@PAGE
Lloh15:
	ldr	q0, [x13, lCPI0_27@PAGEOFF]
Lloh16:
	adrp	x13, lCPI0_28@PAGE
Lloh17:
	ldr	q17, [x13, lCPI0_28@PAGEOFF]
	stp	q17, q0, [sp, #1008]
Lloh18:
	adrp	x13, lCPI0_29@PAGE
Lloh19:
	ldr	q0, [x13, lCPI0_29@PAGEOFF]
Lloh20:
	adrp	x13, lCPI0_30@PAGE
Lloh21:
	ldr	q17, [x13, lCPI0_30@PAGEOFF]
	stp	q17, q0, [sp, #976]
	add	x13, sp, #976
	ldr	x13, [x13, x11]
	ubfiz	x11, x9, #2, #32
	sub	x13, x13, x11
	tst	w10, #0x1
	csel	x13, xzr, x13, eq
	add	x17, sp, #1536
	add	x17, x17, x13
	ldr	q0, [x17]
	tbnz	w0, #0, LBB0_76
; %bb.65:                               ; %else99
	tbnz	w10, #1, LBB0_77
LBB0_66:                                ; %else102
	tbnz	w10, #2, LBB0_78
LBB0_67:                                ; %else105
	tbnz	w10, #3, LBB0_79
LBB0_68:                                ; %else108
	ldr	q17, [x17, #16]
	tbnz	w10, #4, LBB0_80
LBB0_69:                                ; %else111
	adrp	x17, lCPI0_6@PAGE
	tbnz	w10, #5, LBB0_81
LBB0_70:                                ; %else114
	ldr	q12, [x17, lCPI0_6@PAGEOFF]
	sshll.2d	v26, v1, #0
	tbnz	w10, #6, LBB0_82
LBB0_71:                                ; %else117
	and.16b	v14, v26, v12
	and.16b	v30, v26, v4
	tbz	w10, #7, LBB0_73
LBB0_72:                                ; %cond.load119
	add	x16, x16, #28
	ld1.s	{ v17 }[3], [x16]
LBB0_73:                                ; %else120
	fmov	w0, s2
	and	w16, w0, #0xff
	add	x17, sp, #1536
	add	x17, x17, x13
	stp	q0, q17, [x17]
	mov	w17, #33                        ; =0x21
	dup.2d	v0, x17
	add.2d	v0, v30, v0
	add.2d	v17, v0, v14
	str	q17, [sp, #480]                 ; 16-byte Spill
	fmov	x17, d17
	add	x17, x15, x17, lsl #2
	tbz	w0, #0, LBB0_83
; %bb.74:                               ; %cond.load123
	ldr	s17, [x17]
	tbnz	w16, #1, LBB0_84
	b	LBB0_85
LBB0_75:                                ; %cond.load91
	add	x11, x10, #24
	ld1.s	{ v17 }[2], [x11]
	tbnz	w9, #7, LBB0_63
	b	LBB0_64
LBB0_76:                                ; %cond.load98
	ld1.s	{ v0 }[0], [x16]
	tbz	w10, #1, LBB0_66
LBB0_77:                                ; %cond.load101
	add	x0, x16, #4
	ld1.s	{ v0 }[1], [x0]
	tbz	w10, #2, LBB0_67
LBB0_78:                                ; %cond.load104
	add	x0, x16, #8
	ld1.s	{ v0 }[2], [x0]
	tbz	w10, #3, LBB0_68
LBB0_79:                                ; %cond.load107
	add	x0, x16, #12
	ld1.s	{ v0 }[3], [x0]
	ldr	q17, [x17, #16]
	tbz	w10, #4, LBB0_69
LBB0_80:                                ; %cond.load110
	add	x17, x16, #16
	ld1.s	{ v17 }[0], [x17]
	adrp	x17, lCPI0_6@PAGE
	tbz	w10, #5, LBB0_70
LBB0_81:                                ; %cond.load113
	add	x0, x16, #20
	ld1.s	{ v17 }[1], [x0]
	ldr	q12, [x17, lCPI0_6@PAGEOFF]
	sshll.2d	v26, v1, #0
	tbz	w10, #6, LBB0_71
LBB0_82:                                ; %cond.load116
	add	x17, x16, #24
	ld1.s	{ v17 }[2], [x17]
	and.16b	v14, v26, v12
	and.16b	v30, v26, v4
	tbnz	w10, #7, LBB0_72
	b	LBB0_73
LBB0_83:
                                        ; implicit-def: $q17
	tbz	w16, #1, LBB0_85
LBB0_84:                                ; %cond.load126
	add	x0, x17, #4
	ld1.s	{ v17 }[1], [x0]
LBB0_85:                                ; %else127
	tbnz	w16, #2, LBB0_89
; %bb.86:                               ; %else130
	tbnz	w16, #3, LBB0_90
LBB0_87:                                ; %else133
	tbz	w16, #4, LBB0_91
LBB0_88:                                ; %cond.load135
	add	x0, x17, #16
	ld1.s	{ v18 }[0], [x0]
	tbnz	w16, #5, LBB0_92
	b	LBB0_93
LBB0_89:                                ; %cond.load129
	add	x0, x17, #8
	ld1.s	{ v17 }[2], [x0]
	tbz	w16, #3, LBB0_87
LBB0_90:                                ; %cond.load132
	add	x0, x17, #12
	ld1.s	{ v17 }[3], [x0]
	tbnz	w16, #4, LBB0_88
LBB0_91:
                                        ; implicit-def: $q18
	tbz	w16, #5, LBB0_93
LBB0_92:                                ; %cond.load138
	add	x0, x17, #20
	ld1.s	{ v18 }[1], [x0]
LBB0_93:                                ; %else139
	sshll.2d	v29, v1, #0
	tbnz	w16, #6, LBB0_98
; %bb.94:                               ; %else142
	and.16b	v15, v29, v16
	tbz	w16, #7, LBB0_96
LBB0_95:                                ; %cond.load144
	add	x16, x17, #28
	ld1.s	{ v18 }[3], [x16]
LBB0_96:                                ; %else145
	fmov	w0, s2
	and	w16, w0, #0xff
	str	q17, [sp, #1376]
	str	q18, [sp, #1392]
	add.2d	v16, v0, v15
	str	q16, [sp, #464]                 ; 16-byte Spill
	fmov	x17, d16
	add	x17, x15, x17, lsl #2
	tbz	w0, #0, LBB0_99
; %bb.97:                               ; %cond.load148
	ldr	s16, [x17]
	tbnz	w16, #1, LBB0_100
	b	LBB0_101
LBB0_98:                                ; %cond.load141
	add	x0, x17, #24
	ld1.s	{ v18 }[2], [x0]
	and.16b	v15, v29, v16
	tbnz	w16, #7, LBB0_95
	b	LBB0_96
LBB0_99:
                                        ; implicit-def: $q16
	tbz	w16, #1, LBB0_101
LBB0_100:                               ; %cond.load151
	add	x0, x17, #4
	ld1.s	{ v16 }[1], [x0]
LBB0_101:                               ; %else152
	tbnz	w16, #2, LBB0_105
; %bb.102:                              ; %else155
	tbnz	w16, #3, LBB0_106
LBB0_103:                               ; %else158
	tbz	w16, #4, LBB0_107
LBB0_104:                               ; %cond.load160
	add	x0, x17, #16
	ld1.s	{ v17 }[0], [x0]
	tbnz	w16, #5, LBB0_108
	b	LBB0_109
LBB0_105:                               ; %cond.load154
	add	x0, x17, #8
	ld1.s	{ v16 }[2], [x0]
	tbz	w16, #3, LBB0_103
LBB0_106:                               ; %cond.load157
	add	x0, x17, #12
	ld1.s	{ v16 }[3], [x0]
	tbnz	w16, #4, LBB0_104
LBB0_107:
                                        ; implicit-def: $q17
	tbz	w16, #5, LBB0_109
LBB0_108:                               ; %cond.load163
	add	x0, x17, #20
	ld1.s	{ v17 }[1], [x0]
LBB0_109:                               ; %else164
	sshll.2d	v8, v1, #0
	tbnz	w16, #6, LBB0_326
; %bb.110:                              ; %else167
	and.16b	v6, v8, v6
	tbz	w16, #7, LBB0_112
LBB0_111:                               ; %cond.load169
	add	x16, x17, #28
	ld1.s	{ v17 }[3], [x16]
LBB0_112:                               ; %else170
	fmov	w0, s2
	and	w16, w0, #0xff
	str	q16, [sp, #1408]
	str	q17, [sp, #1424]
	add.2d	v16, v0, v6
	str	q16, [sp, #448]                 ; 16-byte Spill
	fmov	x17, d16
	add	x17, x15, x17, lsl #2
	ldr	q17, [sp, #1440]
	tbnz	w0, #0, LBB0_327
; %bb.113:                              ; %else174
	tbnz	w16, #1, LBB0_328
LBB0_114:                               ; %else177
	tbnz	w16, #2, LBB0_329
LBB0_115:                               ; %else180
	tbnz	w16, #3, LBB0_330
LBB0_116:                               ; %else183
	ldr	q18, [sp, #1456]
	tbnz	w16, #4, LBB0_331
LBB0_117:                               ; %else186
	tbnz	w16, #5, LBB0_332
LBB0_118:                               ; %else189
	sshll.2d	v16, v1, #0
	tbnz	w16, #6, LBB0_333
LBB0_119:                               ; %else192
	str	q16, [sp, #272]                 ; 16-byte Spill
	and.16b	v16, v16, v7
	tbz	w16, #7, LBB0_121
LBB0_120:                               ; %cond.load194
	add	x16, x17, #28
	ld1.s	{ v18 }[3], [x16]
LBB0_121:                               ; %else195
	fmov	w0, s2
	and	w16, w0, #0xff
	str	q17, [sp, #1440]
	str	q18, [sp, #1456]
	add.2d	v0, v0, v16
	str	q0, [sp, #432]                  ; 16-byte Spill
	fmov	x17, d0
	add	x17, x15, x17, lsl #2
	ldr	q0, [sp, #1472]
	tbnz	w0, #0, LBB0_334
; %bb.122:                              ; %else199
	tbnz	w16, #1, LBB0_335
LBB0_123:                               ; %else202
	tbnz	w16, #2, LBB0_336
LBB0_124:                               ; %else205
	tbnz	w16, #3, LBB0_337
LBB0_125:                               ; %else208
	and.16b	v22, v10, v21
	ldr	q18, [sp, #1488]
	tbnz	w16, #4, LBB0_338
LBB0_126:                               ; %else211
	adrp	x1, lCPI0_3@PAGE
	adrp	x2, lCPI0_4@PAGE
	adrp	x0, lCPI0_5@PAGE
	movi.4s	v7, #66
	tbz	w16, #5, LBB0_128
LBB0_127:                               ; %cond.load213
	add	x3, x17, #20
	ld1.s	{ v18 }[1], [x3]
LBB0_128:                               ; %else214
	sshll.2d	v9, v10, #0
	sshll2.2d	v11, v1, #0
	sshll2.2d	v27, v10, #0
	ldr	q17, [x1, lCPI0_3@PAGEOFF]
	ldr	q20, [x2, lCPI0_4@PAGEOFF]
	umull.2d	v19, v22, v5
	ldr	q5, [x0, lCPI0_5@PAGEOFF]
	umull2.2d	v21, v13, v7
	umull2.2d	v23, v22, v7
	tbz	w16, #6, LBB0_130
; %bb.129:                              ; %cond.load216
	add	x0, x17, #24
	ld1.s	{ v18 }[2], [x0]
LBB0_130:                               ; %else217
	and.16b	v7, v27, v17
	and.16b	v17, v11, v20
	and.16b	v5, v9, v5
	and.16b	v23, v27, v23
	and.16b	v20, v11, v21
	and.16b	v19, v9, v19
	tbz	w16, #7, LBB0_132
; %bb.131:                              ; %cond.load219
	add	x16, x17, #28
	ld1.s	{ v18 }[3], [x16]
LBB0_132:                               ; %else220
	str	q0, [sp, #1472]
	str	q18, [sp, #1488]
	add.2d	v0, v30, v14
	str	q20, [sp, #288]                 ; 16-byte Spill
	add.2d	v18, v20, v17
	str	q19, [sp, #256]                 ; 16-byte Spill
	add.2d	v19, v19, v5
	mov.16b	v28, v23
	add.2d	v20, v23, v7
	mov	w16, #65                        ; =0x41
	dup.2d	v21, x16
	add.2d	v23, v20, v21
	add.2d	v20, v19, v21
	add.2d	v19, v18, v21
	add.2d	v18, v0, v21
	mov	b0, v3[0]
	mov.b	v0[4], v3[1]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	stp	q18, q19, [sp, #368]            ; 32-byte Folded Spill
	and.16b	v0, v0, v18
	mov	b18, v3[2]
	mov.b	v18[4], v3[3]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	and.16b	v18, v18, v19
	mov	b19, v3[4]
	mov.b	v19[4], v3[5]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	stp	q20, q23, [sp, #400]            ; 32-byte Folded Spill
	and.16b	v19, v19, v20
	mov	b20, v3[6]
	mov.b	v20[4], v3[7]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	and.16b	v20, v20, v23
Lloh22:
	adrp	x16, lCPI0_31@PAGE
Lloh23:
	ldr	d21, [x16, lCPI0_31@PAGEOFF]
	shl.8b	v23, v3, #7
	cmlt.8b	v23, v23, #0
	and.8b	v21, v23, v21
	addv.8b	b21, v21
	stp	q19, q20, [sp, #864]
	stp	q0, q18, [sp, #832]
	and	x16, x9, #0x7
	add	x17, sp, #832
	ldr	x17, [x17, x16, lsl #3]
	str	d21, [sp, #520]                 ; 8-byte Spill
	fmov	w16, s21
	sub	x17, x17, x9
	add	x15, x15, x17, lsl #2
	add	x17, sp, #1376
	add	x17, x17, x13
	ldr	q0, [x17]
	tbnz	w16, #0, LBB0_339
; %bb.133:                              ; %else224
	tbnz	w16, #1, LBB0_340
LBB0_134:                               ; %else227
	tbnz	w16, #2, LBB0_341
LBB0_135:                               ; %else230
	tbnz	w16, #3, LBB0_342
LBB0_136:                               ; %else233
	ldr	q18, [x17, #16]
	tbnz	w16, #4, LBB0_343
LBB0_137:                               ; %else236
	tbnz	w16, #5, LBB0_344
LBB0_138:                               ; %else239
	tbnz	w16, #6, LBB0_345
LBB0_139:                               ; %else242
	ushll.2d	v19, v13, #0
	tbz	w16, #7, LBB0_141
LBB0_140:                               ; %cond.load244
	add	x15, x15, #28
	ld1.s	{ v18 }[3], [x15]
LBB0_141:                               ; %else245
	fmov	w17, s2
	and	w15, w17, #0xff
	fmov	x16, d19
	add	x16, x16, x16, lsl #5
	fmov	d20, x16
	mov.d	x16, v19[1]
	sshll.2d	v19, v1, #0
	add	x16, x16, x16, lsl #5
	mov.d	v20[1], x16
	add	x16, sp, #1376
	add	x16, x16, x13
	stp	q0, q18, [x16]
	and.16b	v24, v19, v20
	add.2d	v23, v24, v14
	fmov	x16, d23
	add	x16, x14, x16, lsl #2
	ldr	q0, [sp, #1216]
	tbnz	w17, #0, LBB0_346
; %bb.142:                              ; %else249
	tbnz	w15, #1, LBB0_347
LBB0_143:                               ; %else252
	tbnz	w15, #2, LBB0_348
LBB0_144:                               ; %else255
	tbnz	w15, #3, LBB0_349
LBB0_145:                               ; %else258
	ldr	q18, [sp, #1232]
	tbnz	w15, #4, LBB0_350
LBB0_146:                               ; %else261
	tbnz	w15, #5, LBB0_351
LBB0_147:                               ; %else264
	tbnz	w15, #6, LBB0_352
LBB0_148:                               ; %else267
	tbz	w15, #7, LBB0_150
LBB0_149:                               ; %cond.load269
	add	x15, x16, #28
	ld1.s	{ v18 }[3], [x15]
LBB0_150:                               ; %else270
	fmov	w17, s2
	and	w15, w17, #0xff
	str	q0, [sp, #1216]
	str	q18, [sp, #1232]
	add.2d	v21, v24, v15
	fmov	x16, d21
	add	x16, x14, x16, lsl #2
	ldr	q0, [sp, #1248]
	tbnz	w17, #0, LBB0_353
; %bb.151:                              ; %else274
	tbnz	w15, #1, LBB0_354
LBB0_152:                               ; %else277
	tbnz	w15, #2, LBB0_355
LBB0_153:                               ; %else280
	tbnz	w15, #3, LBB0_356
LBB0_154:                               ; %else283
	ldr	q18, [sp, #1264]
	tbnz	w15, #4, LBB0_357
LBB0_155:                               ; %else286
	tbnz	w15, #5, LBB0_358
LBB0_156:                               ; %else289
	tbnz	w15, #6, LBB0_359
LBB0_157:                               ; %else292
	tbz	w15, #7, LBB0_159
LBB0_158:                               ; %cond.load294
	add	x15, x16, #28
	ld1.s	{ v18 }[3], [x15]
LBB0_159:                               ; %else295
	fmov	w17, s2
	and	w15, w17, #0xff
	str	q0, [sp, #1248]
	str	q18, [sp, #1264]
	add.2d	v20, v24, v6
	fmov	x16, d20
	add	x16, x14, x16, lsl #2
	ldr	q0, [sp, #1280]
	tbnz	w17, #0, LBB0_360
; %bb.160:                              ; %else299
	tbnz	w15, #1, LBB0_361
LBB0_161:                               ; %else302
	tbnz	w15, #2, LBB0_362
LBB0_162:                               ; %else305
	tbnz	w15, #3, LBB0_363
LBB0_163:                               ; %else308
	ldr	q6, [sp, #1296]
	tbnz	w15, #4, LBB0_364
LBB0_164:                               ; %else311
	tbnz	w15, #5, LBB0_365
LBB0_165:                               ; %else314
	tbnz	w15, #6, LBB0_366
LBB0_166:                               ; %else317
	tbz	w15, #7, LBB0_168
LBB0_167:                               ; %cond.load319
	add	x15, x16, #28
	ld1.s	{ v6 }[3], [x15]
LBB0_168:                               ; %else320
	fmov	w17, s2
	and	w15, w17, #0xff
	str	q0, [sp, #1280]
	str	q6, [sp, #1296]
	add.2d	v6, v24, v16
	fmov	x16, d6
	add	x16, x14, x16, lsl #2
	ldr	q0, [sp, #1312]
	tbnz	w17, #0, LBB0_367
; %bb.169:                              ; %else324
	ushll2.2d	v16, v22, #0
	ushll2.2d	v25, v13, #0
	ushll.2d	v18, v22, #0
	tbnz	w15, #1, LBB0_368
LBB0_170:                               ; %else327
	tbnz	w15, #2, LBB0_369
LBB0_171:                               ; %else330
	fmov	x5, d25
	fmov	x3, d18
	fmov	x4, d16
	tbz	w15, #3, LBB0_173
LBB0_172:                               ; %cond.load332
	add	x17, x16, #12
	ld1.s	{ v0 }[3], [x17]
LBB0_173:                               ; %else333
	mov	w17, #32                        ; =0x20
	mov.d	x0, v25[1]
	mov.d	x1, v18[1]
	mov.d	x2, v16[1]
	add	x5, x5, x5, lsl #5
	ldr	q16, [sp, #1328]
	add	x6, x3, x3, lsl #5
	add	x3, x4, x4, lsl #5
	tbz	w15, #4, LBB0_175
; %bb.174:                              ; %cond.load335
	add	x4, x16, #16
	ld1.s	{ v16 }[0], [x4]
LBB0_175:                               ; %else336
	fmov	d18, x5
	add	x0, x0, x0, lsl #5
	fmov	d22, x6
	add	x1, x1, x1, lsl #5
	fmov	d25, x3
	add	x2, x2, x2, lsl #5
	str	q30, [sp, #304]                 ; 16-byte Spill
	tbz	w15, #5, LBB0_177
; %bb.176:                              ; %cond.load338
	add	x3, x16, #20
	ld1.s	{ v16 }[1], [x3]
LBB0_177:                               ; %else339
	dup.2d	v31, x17
	sshll.2d	v30, v10, #0
	mov.d	v18[1], x0
	mov.d	v22[1], x1
	mov.d	v25[1], x2
	tbz	w15, #6, LBB0_179
; %bb.178:                              ; %cond.load341
	add	x17, x16, #24
	ld1.s	{ v16 }[2], [x17]
LBB0_179:                               ; %else342
	orr.16b	v5, v5, v31
	str	q5, [sp, #496]                  ; 16-byte Spill
	orr.16b	v15, v17, v31
	orr.16b	v13, v14, v31
	orr.16b	v31, v7, v31
	and.16b	v17, v27, v25
	and.16b	v7, v30, v22
	and.16b	v5, v11, v18
	tbz	w15, #7, LBB0_181
; %bb.180:                              ; %cond.load344
	add	x15, x16, #28
	ld1.s	{ v16 }[3], [x15]
LBB0_181:                               ; %else345
	mov.16b	v18, v8
	str	q0, [sp, #1312]
	str	q16, [sp, #1328]
	add.2d	v0, v17, v31
	ldr	q16, [sp, #496]                 ; 16-byte Reload
	add.2d	v7, v7, v16
	add.2d	v5, v5, v15
	add.2d	v16, v24, v13
	mov.16b	v24, v13
	mov	b17, v3[0]
	mov.b	v17[4], v3[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	and.16b	v16, v17, v16
	mov	b17, v3[2]
	mov.b	v17[4], v3[3]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	and.16b	v5, v17, v5
	mov	b17, v3[4]
	mov.b	v17[4], v3[5]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	and.16b	v7, v17, v7
	mov	b17, v3[6]
	mov.b	v17[4], v3[7]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	and.16b	v0, v17, v0
	ldr	d17, [sp, #520]                 ; 8-byte Reload
	fmov	w16, s17
	stp	q7, q0, [sp, #784]
	stp	q16, q5, [sp, #752]
	and	x15, x9, #0x7
	add	x17, sp, #752
	ldr	x15, [x17, x15, lsl #3]
	sub	x15, x15, x9
	lsl	x15, x15, #2
	add	x14, x14, x15
	add	x17, sp, #1216
	add	x17, x17, x13
	ldr	q0, [x17]
	tbnz	w16, #0, LBB0_370
; %bb.182:                              ; %else349
	ldr	q8, [sp, #272]                  ; 16-byte Reload
	mov.16b	v22, v9
	tbnz	w16, #1, LBB0_371
LBB0_183:                               ; %else352
	tbnz	w16, #2, LBB0_372
LBB0_184:                               ; %else355
	tbnz	w16, #3, LBB0_373
LBB0_185:                               ; %else358
	ldr	q5, [x17, #16]
	tbnz	w16, #4, LBB0_374
LBB0_186:                               ; %else361
	tbnz	w16, #5, LBB0_375
LBB0_187:                               ; %else364
	tbnz	w16, #6, LBB0_376
LBB0_188:                               ; %else367
	and.16b	v7, v19, v23
	tbz	w16, #7, LBB0_190
LBB0_189:                               ; %cond.load369
	add	x14, x14, #28
	ld1.s	{ v5 }[3], [x14]
LBB0_190:                               ; %else370
	mov.16b	v23, v28
	fmov	w17, s2
	and	w14, w17, #0xff
	add	x16, sp, #1216
	add	x16, x16, x13
	stp	q0, q5, [x16]
	fmov	x16, d7
	add	x16, x12, x16, lsl #2
	ldr	q0, [sp, #1056]
	tbnz	w17, #0, LBB0_377
; %bb.191:                              ; %else374
	tbnz	w14, #1, LBB0_378
LBB0_192:                               ; %else377
	tbnz	w14, #2, LBB0_379
LBB0_193:                               ; %else380
	tbnz	w14, #3, LBB0_380
LBB0_194:                               ; %else383
	ldr	q5, [sp, #1072]
	tbnz	w14, #4, LBB0_381
LBB0_195:                               ; %else386
	tbnz	w14, #5, LBB0_382
LBB0_196:                               ; %else389
	sshll.2d	v7, v1, #0
	tbnz	w14, #6, LBB0_383
LBB0_197:                               ; %else392
	and.16b	v7, v7, v21
	tbz	w14, #7, LBB0_199
LBB0_198:                               ; %cond.load394
	add	x14, x16, #28
	ld1.s	{ v5 }[3], [x14]
LBB0_199:                               ; %else395
	fmov	w17, s2
	and	w14, w17, #0xff
	str	q0, [sp, #1056]
	str	q5, [sp, #1072]
	fmov	x16, d7
	add	x16, x12, x16, lsl #2
	ldr	q0, [sp, #1088]
	tbnz	w17, #0, LBB0_384
; %bb.200:                              ; %else399
	tbnz	w14, #1, LBB0_385
LBB0_201:                               ; %else402
	tbnz	w14, #2, LBB0_386
LBB0_202:                               ; %else405
	tbnz	w14, #3, LBB0_387
LBB0_203:                               ; %else408
	ldr	q5, [sp, #1104]
	tbnz	w14, #4, LBB0_388
LBB0_204:                               ; %else411
	tbnz	w14, #5, LBB0_389
LBB0_205:                               ; %else414
	sshll.2d	v7, v1, #0
	tbnz	w14, #6, LBB0_390
LBB0_206:                               ; %else417
	and.16b	v7, v7, v20
	tbz	w14, #7, LBB0_208
LBB0_207:                               ; %cond.load419
	add	x14, x16, #28
	ld1.s	{ v5 }[3], [x14]
LBB0_208:                               ; %else420
	fmov	w17, s2
	and	w14, w17, #0xff
	str	q0, [sp, #1088]
	str	q5, [sp, #1104]
	fmov	x16, d7
	add	x16, x12, x16, lsl #2
	ldr	q0, [sp, #1120]
	tbnz	w17, #0, LBB0_391
; %bb.209:                              ; %else424
	tbnz	w14, #1, LBB0_392
LBB0_210:                               ; %else427
	tbnz	w14, #2, LBB0_393
LBB0_211:                               ; %else430
	tbnz	w14, #3, LBB0_394
LBB0_212:                               ; %else433
	ldr	q5, [sp, #1136]
	tbnz	w14, #4, LBB0_395
LBB0_213:                               ; %else436
	tbnz	w14, #5, LBB0_396
LBB0_214:                               ; %else439
	sshll.2d	v7, v1, #0
	tbnz	w14, #6, LBB0_397
LBB0_215:                               ; %else442
	and.16b	v6, v7, v6
	tbz	w14, #7, LBB0_217
LBB0_216:                               ; %cond.load444
	add	x14, x16, #28
	ld1.s	{ v5 }[3], [x14]
LBB0_217:                               ; %else445
	fmov	w17, s2
	and	w14, w17, #0xff
	str	q0, [sp, #1120]
	str	q5, [sp, #1136]
	fmov	x16, d6
	add	x16, x12, x16, lsl #2
	ldr	q0, [sp, #1152]
	tbnz	w17, #0, LBB0_398
; %bb.218:                              ; %else449
	tbnz	w14, #1, LBB0_399
LBB0_219:                               ; %else452
	tbnz	w14, #2, LBB0_400
LBB0_220:                               ; %else455
	tbnz	w14, #3, LBB0_401
LBB0_221:                               ; %else458
	ldr	q5, [sp, #1168]
	tbnz	w14, #4, LBB0_402
LBB0_222:                               ; %else461
	tbnz	w14, #5, LBB0_403
LBB0_223:                               ; %else464
	tbnz	w14, #6, LBB0_404
LBB0_224:                               ; %else467
	tbz	w14, #7, LBB0_226
LBB0_225:                               ; %cond.load469
	add	x14, x16, #28
	ld1.s	{ v5 }[3], [x14]
LBB0_226:                               ; %else470
	str	q0, [sp, #1152]
	str	q5, [sp, #1168]
	add	x12, x12, x15
	add	x14, sp, #1056
	add	x15, x14, x13
	ldr	q0, [x15]
	ldr	d5, [sp, #520]                  ; 8-byte Reload
	fmov	w14, s5
	tbnz	w14, #0, LBB0_405
; %bb.227:                              ; %else474
	tbnz	w14, #1, LBB0_406
LBB0_228:                               ; %else477
	tbnz	w14, #2, LBB0_407
LBB0_229:                               ; %else480
	tbnz	w14, #3, LBB0_408
LBB0_230:                               ; %else483
	ldr	q5, [x15, #16]
	tbnz	w14, #4, LBB0_409
LBB0_231:                               ; %else486
	adrp	x15, lCPI0_10@PAGE
	tbnz	w14, #5, LBB0_410
LBB0_232:                               ; %else489
	ldr	q6, [x15, lCPI0_10@PAGEOFF]
	orr.16b	v4, v4, v12
	tbnz	w14, #6, LBB0_411
LBB0_233:                               ; %else492
	and.16b	v7, v26, v6
	and.16b	v4, v26, v4
	tbz	w14, #7, LBB0_235
LBB0_234:                               ; %cond.load494
	add	x12, x12, #28
	ld1.s	{ v5 }[3], [x12]
LBB0_235:                               ; %else495
	fmov	w0, s2
	and	w12, w0, #0xff
	add	x17, sp, #1056
	add	x13, x17, x13
	stp	q0, q5, [x13]
	fmov	x13, d7
	add	x14, sp, #1536
	add	x14, x14, x13
	ldr	q0, [x14]
	add	x15, sp, #1216
	add	x15, x15, x13
	ldr	q5, [x15]
	str	q0, [sp, #272]                  ; 16-byte Spill
	str	q5, [sp, #240]                  ; 16-byte Spill
	fmul.4s	v0, v0, v5
	add	x16, sp, #1376
	add	x16, x16, x13
	ldr	q5, [x16]
	add	x17, x17, x13
	ldr	q6, [x17]
	stp	q6, q5, [sp, #176]              ; 32-byte Folded Spill
	fmul.4s	v5, v5, v6
	fsub.4s	v0, v0, v5
	and.16b	v0, v1, v0
	fmov	x13, d4
	add	x13, x8, x13, lsl #2
	tbnz	w0, #0, LBB0_412
; %bb.236:                              ; %else498
	ldr	q4, [x14, #16]
	ldr	q5, [x15, #16]
	ldr	q6, [x16, #16]
	ldr	q30, [x17, #16]
	tbnz	w12, #1, LBB0_413
LBB0_237:                               ; %else500
	stp	q5, q4, [sp, #208]              ; 32-byte Folded Spill
	fmul.4s	v4, v4, v5
	fmul.4s	v5, v6, v30
	tbnz	w12, #2, LBB0_414
LBB0_238:                               ; %else502
	fsub.4s	v4, v4, v5
	tbnz	w12, #3, LBB0_415
LBB0_239:                               ; %else504
	and.16b	v0, v10, v4
	tbnz	w12, #4, LBB0_416
LBB0_240:                               ; %else506
	adrp	x14, lCPI0_15@PAGE
	tbnz	w12, #5, LBB0_417
LBB0_241:                               ; %else508
	ldr	q5, [x14, lCPI0_15@PAGEOFF]
	tbnz	w12, #6, LBB0_418
LBB0_242:                               ; %else510
	ldr	q4, [sp, #352]                  ; 16-byte Reload
	and.16b	v4, v29, v4
	and.16b	v5, v29, v5
	tbz	w12, #7, LBB0_244
LBB0_243:                               ; %cond.store511
	add	x12, x13, #28
	st1.s	{ v0 }[3], [x12]
LBB0_244:                               ; %else512
	fmov	w0, s2
	and	w12, w0, #0xff
	fmov	x13, d5
	add	x14, sp, #1536
	add	x14, x14, x13
	ldr	q0, [x14]
	add	x15, sp, #1216
	add	x15, x15, x13
	ldr	q5, [x15]
	stp	q5, q0, [sp, #144]              ; 32-byte Folded Spill
	fmul.4s	v0, v0, v5
	add	x16, sp, #1376
	add	x16, x16, x13
	ldr	q5, [x16]
	add	x17, sp, #1056
	add	x17, x17, x13
	ldr	q16, [x17]
	str	q5, [sp, #96]                   ; 16-byte Spill
	str	q16, [sp, #64]                  ; 16-byte Spill
	fmul.4s	v5, v5, v16
	fsub.4s	v0, v0, v5
	and.16b	v0, v1, v0
	fmov	x13, d4
	add	x13, x8, x13, lsl #2
	tbnz	w0, #0, LBB0_419
; %bb.245:                              ; %else515
	ldr	q4, [x14, #16]
	ldr	q5, [x15, #16]
	ldr	q16, [x16, #16]
	ldr	q17, [x17, #16]
	tbnz	w12, #1, LBB0_420
LBB0_246:                               ; %else517
	stp	q5, q4, [sp, #112]              ; 32-byte Folded Spill
	fmul.4s	v4, v4, v5
	fmul.4s	v5, v16, v17
	tbnz	w12, #2, LBB0_421
LBB0_247:                               ; %else519
	fsub.4s	v4, v4, v5
	tbnz	w12, #3, LBB0_422
LBB0_248:                               ; %else521
	and.16b	v0, v10, v4
	tbnz	w12, #4, LBB0_423
LBB0_249:                               ; %else523
	adrp	x14, lCPI0_20@PAGE
	tbnz	w12, #5, LBB0_424
LBB0_250:                               ; %else525
	ldr	q5, [x14, lCPI0_20@PAGEOFF]
	tbnz	w12, #6, LBB0_425
LBB0_251:                               ; %else527
	str	q6, [sp, #352]                  ; 16-byte Spill
	mov.16b	v26, v15
	ldr	q4, [sp, #336]                  ; 16-byte Reload
	and.16b	v4, v18, v4
	and.16b	v5, v18, v5
	tbz	w12, #7, LBB0_253
LBB0_252:                               ; %cond.store528
	add	x12, x13, #28
	st1.s	{ v0 }[3], [x12]
LBB0_253:                               ; %else529
	mov.16b	v28, v31
	fmov	w0, s2
	and	w12, w0, #0xff
	fmov	x13, d5
	add	x14, sp, #1536
	add	x14, x14, x13
	ldr	q0, [x14]
	add	x15, sp, #1216
	add	x15, x15, x13
	ldr	q5, [x15]
	stp	q5, q0, [sp, #32]               ; 32-byte Folded Spill
	fmul.4s	v0, v0, v5
	add	x16, sp, #1376
	add	x16, x16, x13
	ldr	q5, [x16]
	add	x17, sp, #1056
	add	x17, x17, x13
	ldr	q15, [x17]
	fmul.4s	v6, v5, v15
	fsub.4s	v0, v0, v6
	and.16b	v0, v1, v0
	fmov	x13, d4
	add	x13, x8, x13, lsl #2
	tbnz	w0, #0, LBB0_426
; %bb.254:                              ; %else532
	ldr	q4, [x14, #16]
	ldr	q6, [x15, #16]
	ldr	q31, [x16, #16]
	ldr	q13, [x17, #16]
	tbnz	w12, #1, LBB0_427
LBB0_255:                               ; %else534
	stp	q6, q4, [sp]                    ; 32-byte Folded Spill
	fmul.4s	v4, v4, v6
	fmul.4s	v6, v31, v13
	tbnz	w12, #2, LBB0_428
LBB0_256:                               ; %else536
	fsub.4s	v4, v4, v6
	tbnz	w12, #3, LBB0_429
LBB0_257:                               ; %else538
	and.16b	v4, v10, v4
	tbnz	w12, #4, LBB0_430
LBB0_258:                               ; %else540
	adrp	x14, lCPI0_25@PAGE
	tbnz	w12, #5, LBB0_431
LBB0_259:                               ; %else542
	ldr	q6, [x14, lCPI0_25@PAGEOFF]
	tbnz	w12, #6, LBB0_432
LBB0_260:                               ; %else544
	str	q17, [sp, #80]                  ; 16-byte Spill
	str	q16, [sp, #336]                 ; 16-byte Spill
	ldr	q0, [sp, #320]                  ; 16-byte Reload
	and.16b	v0, v8, v0
	and.16b	v6, v8, v6
	tbz	w12, #7, LBB0_262
LBB0_261:                               ; %cond.store545
	add	x12, x13, #28
	st1.s	{ v4 }[3], [x12]
LBB0_262:                               ; %else546
	fmov	w0, s2
	and	w12, w0, #0xff
	fmov	x13, d6
	add	x14, sp, #1536
	add	x14, x14, x13
	ldr	q14, [x14]
	add	x15, sp, #1216
	add	x15, x15, x13
	ldr	q8, [x15]
	fmul.4s	v6, v14, v8
	add	x16, sp, #1376
	add	x16, x16, x13
	ldr	q4, [x16]
	add	x17, sp, #1056
	add	x17, x17, x13
	ldr	q16, [x17]
	fmul.4s	v17, v4, v16
	fsub.4s	v6, v6, v17
	and.16b	v17, v1, v6
	fmov	x13, d0
	add	x13, x8, x13, lsl #2
	tbnz	w0, #0, LBB0_433
; %bb.263:                              ; %else549
	ldr	q9, [x14, #16]
	ldr	q25, [x15, #16]
	ldr	q0, [x16, #16]
	ldr	q6, [x17, #16]
	tbnz	w12, #1, LBB0_434
LBB0_264:                               ; %else551
	fmul.4s	v19, v9, v25
	fmul.4s	v20, v0, v6
	tbnz	w12, #2, LBB0_435
LBB0_265:                               ; %else553
	fsub.4s	v19, v19, v20
	tbnz	w12, #3, LBB0_436
LBB0_266:                               ; %else555
	and.16b	v17, v10, v19
	tbnz	w12, #4, LBB0_437
LBB0_267:                               ; %else557
	adrp	x14, lCPI0_7@PAGE
	adrp	x15, lCPI0_8@PAGE
	adrp	x16, lCPI0_9@PAGE
	tbnz	w12, #5, LBB0_438
LBB0_268:                               ; %else559
	ldr	q19, [x14, lCPI0_7@PAGEOFF]
	ldr	q20, [x15, lCPI0_8@PAGEOFF]
	ldr	q21, [x16, lCPI0_9@PAGEOFF]
	tbnz	w12, #6, LBB0_439
LBB0_269:                               ; %else561
	mov.16b	v18, v10
	and.16b	v19, v27, v19
	and.16b	v20, v11, v20
	and.16b	v21, v22, v21
	tbz	w12, #7, LBB0_271
LBB0_270:                               ; %cond.store562
	add	x12, x13, #28
	st1.s	{ v17 }[3], [x12]
LBB0_271:                               ; %else563
	add.2d	v28, v23, v28
	ldr	q17, [sp, #256]                 ; 16-byte Reload
	ldr	q22, [sp, #496]                 ; 16-byte Reload
	add.2d	v10, v17, v22
	ldp	q22, q17, [sp, #288]            ; 32-byte Folded Reload
	add.2d	v11, v22, v26
	add.2d	v29, v17, v24
	stp	q7, q20, [sp, #672]
	stp	q21, q19, [sp, #704]
	ubfiz	x12, x9, #3, #3
	add	x13, sp, #672
	ldr	x13, [x13, x12]
	orr	x13, x13, #0x80
	sub	x11, x13, x11
	tst	w10, #0xff
	csel	x10, xzr, x11, eq
	add	x11, sp, #1536
	add	x11, x11, x10
	ldp	q21, q7, [x11]
	add	x11, sp, #1216
	add	x11, x11, x10
	ldp	q22, q17, [x11]
	fmul.4s	v26, v21, v22
	add	x11, sp, #1376
	add	x11, x11, x10
	ldp	q23, q19, [x11]
	add	x11, sp, #1056
	add	x10, x11, x10
	ldp	q24, q20, [x10]
	fmul.4s	v27, v23, v24
	fsub.4s	v26, v26, v27
	zip2.8b	v27, v3, v0
	zip1.8b	v12, v3, v0
	ushll.4s	v12, v12, #0
	shl.4s	v12, v12, #31
	cmlt.4s	v12, v12, #0
	and.16b	v26, v12, v26
	ldr	d12, [sp, #520]                 ; 8-byte Reload
	fmov	w10, s12
	stp	q29, q11, [sp, #608]
	stp	q10, q28, [sp, #640]
	add	x11, sp, #608
	ldr	x11, [x11, x12]
	sub	x11, x11, x9
	add	x11, x8, x11, lsl #2
	tbnz	w10, #0, LBB0_440
; %bb.272:                              ; %else566
	ushll.4s	v28, v27, #0
	tbnz	w10, #1, LBB0_441
LBB0_273:                               ; %else568
	fmul.4s	v27, v7, v17
	fmul.4s	v10, v19, v20
	shl.4s	v28, v28, #31
	tbnz	w10, #2, LBB0_442
LBB0_274:                               ; %else570
	fsub.4s	v27, v27, v10
	cmlt.4s	v28, v28, #0
	tbnz	w10, #3, LBB0_443
LBB0_275:                               ; %else572
	and.16b	v26, v28, v27
	mov.16b	v29, v18
	tbnz	w10, #4, LBB0_444
LBB0_276:                               ; %else574
	tbnz	w10, #5, LBB0_445
LBB0_277:                               ; %else576
	sshll.2d	v27, v1, #0
	tbnz	w10, #6, LBB0_446
LBB0_278:                               ; %else578
	ldr	q18, [sp, #480]                 ; 16-byte Reload
	and.16b	v27, v27, v18
	tbz	w10, #7, LBB0_280
LBB0_279:                               ; %cond.store579
	add	x10, x11, #28
	st1.s	{ v26 }[3], [x10]
LBB0_280:                               ; %else580
	fmov	w12, s2
	and	w10, w12, #0xff
	ldr	q18, [sp, #272]                 ; 16-byte Reload
	ldp	q26, q28, [sp, #176]            ; 32-byte Folded Reload
	fmul.4s	v26, v18, v26
	ldr	q18, [sp, #240]                 ; 16-byte Reload
	fmul.4s	v28, v18, v28
	fadd.4s	v26, v28, v26
	and.16b	v26, v1, v26
	fmov	x11, d27
	add	x11, x8, x11, lsl #2
	tbnz	w12, #0, LBB0_447
; %bb.281:                              ; %else583
	tbnz	w10, #1, LBB0_448
LBB0_282:                               ; %else585
	ldp	q18, q28, [sp, #208]            ; 32-byte Folded Reload
	fmul.4s	v27, v28, v30
	ldr	q28, [sp, #352]                 ; 16-byte Reload
	fmul.4s	v28, v18, v28
	tbnz	w10, #2, LBB0_449
LBB0_283:                               ; %else587
	fadd.4s	v27, v28, v27
	tbnz	w10, #3, LBB0_450
LBB0_284:                               ; %else589
	and.16b	v26, v29, v27
	tbnz	w10, #4, LBB0_451
LBB0_285:                               ; %else591
	tbnz	w10, #5, LBB0_452
LBB0_286:                               ; %else593
	sshll.2d	v27, v1, #0
	tbnz	w10, #6, LBB0_453
LBB0_287:                               ; %else595
	ldr	q18, [sp, #464]                 ; 16-byte Reload
	and.16b	v27, v27, v18
	tbz	w10, #7, LBB0_289
LBB0_288:                               ; %cond.store596
	add	x10, x11, #28
	st1.s	{ v26 }[3], [x10]
LBB0_289:                               ; %else597
	fmov	w12, s2
	and	w10, w12, #0xff
	ldp	q18, q28, [sp, #144]            ; 32-byte Folded Reload
	ldr	q26, [sp, #64]                  ; 16-byte Reload
	fmul.4s	v26, v28, v26
	ldr	q28, [sp, #96]                  ; 16-byte Reload
	fmul.4s	v28, v18, v28
	fadd.4s	v26, v28, v26
	and.16b	v26, v1, v26
	fmov	x11, d27
	add	x11, x8, x11, lsl #2
	tbnz	w12, #0, LBB0_454
; %bb.290:                              ; %else600
	tbnz	w10, #1, LBB0_455
LBB0_291:                               ; %else602
	ldp	q18, q28, [sp, #112]            ; 32-byte Folded Reload
	ldr	q27, [sp, #80]                  ; 16-byte Reload
	fmul.4s	v27, v28, v27
	ldr	q28, [sp, #336]                 ; 16-byte Reload
	fmul.4s	v28, v18, v28
	tbnz	w10, #2, LBB0_456
LBB0_292:                               ; %else604
	fadd.4s	v27, v28, v27
	tbnz	w10, #3, LBB0_457
LBB0_293:                               ; %else606
	and.16b	v26, v29, v27
	tbnz	w10, #4, LBB0_458
LBB0_294:                               ; %else608
	tbnz	w10, #5, LBB0_459
LBB0_295:                               ; %else610
	sshll.2d	v27, v1, #0
	tbnz	w10, #6, LBB0_460
LBB0_296:                               ; %else612
	ldr	q18, [sp, #448]                 ; 16-byte Reload
	and.16b	v27, v27, v18
	tbz	w10, #7, LBB0_298
LBB0_297:                               ; %cond.store613
	add	x10, x11, #28
	st1.s	{ v26 }[3], [x10]
LBB0_298:                               ; %else614
	fmov	w12, s2
	and	w10, w12, #0xff
	ldp	q18, q28, [sp, #32]             ; 32-byte Folded Reload
	fmul.4s	v26, v28, v15
	fmul.4s	v5, v18, v5
	fadd.4s	v5, v5, v26
	and.16b	v5, v1, v5
	fmov	x11, d27
	add	x11, x8, x11, lsl #2
	tbnz	w12, #0, LBB0_461
; %bb.299:                              ; %else617
	tbnz	w10, #1, LBB0_462
LBB0_300:                               ; %else619
	ldp	q26, q18, [sp]                  ; 32-byte Folded Reload
	fmul.4s	v18, v18, v13
	fmul.4s	v26, v26, v31
	tbnz	w10, #2, LBB0_463
LBB0_301:                               ; %else621
	fadd.4s	v18, v26, v18
	tbnz	w10, #3, LBB0_464
LBB0_302:                               ; %else623
	and.16b	v5, v29, v18
	tbnz	w10, #4, LBB0_465
LBB0_303:                               ; %else625
	tbnz	w10, #5, LBB0_466
LBB0_304:                               ; %else627
	sshll.2d	v18, v1, #0
	tbnz	w10, #6, LBB0_467
LBB0_305:                               ; %else629
	ldr	q26, [sp, #432]                 ; 16-byte Reload
	and.16b	v18, v18, v26
	tbz	w10, #7, LBB0_307
LBB0_306:                               ; %cond.store630
	add	x10, x11, #28
	st1.s	{ v5 }[3], [x10]
LBB0_307:                               ; %else631
	fmov	w12, s2
	and	w10, w12, #0xff
	fmul.4s	v2, v14, v16
	fmul.4s	v4, v8, v4
	fadd.4s	v2, v4, v2
	and.16b	v1, v1, v2
	fmov	x11, d18
	add	x11, x8, x11, lsl #2
	tbnz	w12, #0, LBB0_468
; %bb.308:                              ; %else634
	tbnz	w10, #1, LBB0_469
LBB0_309:                               ; %else636
	fmul.4s	v2, v9, v6
	fmul.4s	v0, v25, v0
	tbnz	w10, #2, LBB0_470
LBB0_310:                               ; %else638
	fadd.4s	v0, v0, v2
	tbnz	w10, #3, LBB0_471
LBB0_311:                               ; %else640
	and.16b	v0, v29, v0
	tbnz	w10, #4, LBB0_472
LBB0_312:                               ; %else642
	tbnz	w10, #5, LBB0_473
LBB0_313:                               ; %else644
	tbnz	w10, #6, LBB0_474
LBB0_314:                               ; %else646
	tbz	w10, #7, LBB0_316
LBB0_315:                               ; %cond.store647
	add	x10, x11, #28
	st1.s	{ v0 }[3], [x10]
LBB0_316:                               ; %else648
	fmul.4s	v0, v21, v24
	fmul.4s	v1, v22, v23
	fadd.4s	v0, v1, v0
	zip2.8b	v1, v3, v0
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v0, v2, v0
	ldr	d2, [sp, #520]                  ; 8-byte Reload
	fmov	w10, s2
	ldp	q4, q2, [sp, #368]              ; 32-byte Folded Reload
	stp	q4, q2, [sp, #528]
	ldp	q4, q2, [sp, #400]              ; 32-byte Folded Reload
	stp	q4, q2, [sp, #560]
	and	x11, x9, #0x7
	add	x12, sp, #528
	ldr	x11, [x12, x11, lsl #3]
	sub	x9, x11, x9
	add	x8, x8, x9, lsl #2
	tbnz	w10, #0, LBB0_475
; %bb.317:                              ; %else651
	ushll.4s	v2, v1, #0
	tbnz	w10, #1, LBB0_476
LBB0_318:                               ; %else653
	fmul.4s	v1, v7, v20
	fmul.4s	v3, v17, v19
	shl.4s	v2, v2, #31
	tbnz	w10, #2, LBB0_477
LBB0_319:                               ; %else655
	fadd.4s	v1, v3, v1
	cmlt.4s	v2, v2, #0
	tbnz	w10, #3, LBB0_478
LBB0_320:                               ; %else657
	and.16b	v0, v2, v1
	tbnz	w10, #4, LBB0_479
LBB0_321:                               ; %else659
	tbnz	w10, #5, LBB0_480
LBB0_322:                               ; %else661
	tbnz	w10, #6, LBB0_481
LBB0_323:                               ; %else663
	tbz	w10, #7, LBB0_325
LBB0_324:                               ; %cond.store664
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_325:                               ; %common.ret
	add	sp, sp, #1696
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
	ret
LBB0_326:                               ; %cond.load166
	add	x0, x17, #24
	ld1.s	{ v17 }[2], [x0]
	and.16b	v6, v8, v6
	tbnz	w16, #7, LBB0_111
	b	LBB0_112
LBB0_327:                               ; %cond.load173
	ld1.s	{ v17 }[0], [x17]
	tbz	w16, #1, LBB0_114
LBB0_328:                               ; %cond.load176
	add	x0, x17, #4
	ld1.s	{ v17 }[1], [x0]
	tbz	w16, #2, LBB0_115
LBB0_329:                               ; %cond.load179
	add	x0, x17, #8
	ld1.s	{ v17 }[2], [x0]
	tbz	w16, #3, LBB0_116
LBB0_330:                               ; %cond.load182
	add	x0, x17, #12
	ld1.s	{ v17 }[3], [x0]
	ldr	q18, [sp, #1456]
	tbz	w16, #4, LBB0_117
LBB0_331:                               ; %cond.load185
	add	x0, x17, #16
	ld1.s	{ v18 }[0], [x0]
	tbz	w16, #5, LBB0_118
LBB0_332:                               ; %cond.load188
	add	x0, x17, #20
	ld1.s	{ v18 }[1], [x0]
	sshll.2d	v16, v1, #0
	tbz	w16, #6, LBB0_119
LBB0_333:                               ; %cond.load191
	add	x0, x17, #24
	ld1.s	{ v18 }[2], [x0]
	str	q16, [sp, #272]                 ; 16-byte Spill
	and.16b	v16, v16, v7
	tbnz	w16, #7, LBB0_120
	b	LBB0_121
LBB0_334:                               ; %cond.load198
	ld1.s	{ v0 }[0], [x17]
	tbz	w16, #1, LBB0_123
LBB0_335:                               ; %cond.load201
	add	x0, x17, #4
	ld1.s	{ v0 }[1], [x0]
	tbz	w16, #2, LBB0_124
LBB0_336:                               ; %cond.load204
	add	x0, x17, #8
	ld1.s	{ v0 }[2], [x0]
	tbz	w16, #3, LBB0_125
LBB0_337:                               ; %cond.load207
	add	x0, x17, #12
	ld1.s	{ v0 }[3], [x0]
	and.16b	v22, v10, v21
	ldr	q18, [sp, #1488]
	tbz	w16, #4, LBB0_126
LBB0_338:                               ; %cond.load210
	add	x0, x17, #16
	ld1.s	{ v18 }[0], [x0]
	adrp	x1, lCPI0_3@PAGE
	adrp	x2, lCPI0_4@PAGE
	adrp	x0, lCPI0_5@PAGE
	movi.4s	v7, #66
	tbnz	w16, #5, LBB0_127
	b	LBB0_128
LBB0_339:                               ; %cond.load223
	ld1.s	{ v0 }[0], [x15]
	tbz	w16, #1, LBB0_134
LBB0_340:                               ; %cond.load226
	add	x0, x15, #4
	ld1.s	{ v0 }[1], [x0]
	tbz	w16, #2, LBB0_135
LBB0_341:                               ; %cond.load229
	add	x0, x15, #8
	ld1.s	{ v0 }[2], [x0]
	tbz	w16, #3, LBB0_136
LBB0_342:                               ; %cond.load232
	add	x0, x15, #12
	ld1.s	{ v0 }[3], [x0]
	ldr	q18, [x17, #16]
	tbz	w16, #4, LBB0_137
LBB0_343:                               ; %cond.load235
	add	x17, x15, #16
	ld1.s	{ v18 }[0], [x17]
	tbz	w16, #5, LBB0_138
LBB0_344:                               ; %cond.load238
	add	x17, x15, #20
	ld1.s	{ v18 }[1], [x17]
	tbz	w16, #6, LBB0_139
LBB0_345:                               ; %cond.load241
	add	x17, x15, #24
	ld1.s	{ v18 }[2], [x17]
	ushll.2d	v19, v13, #0
	tbnz	w16, #7, LBB0_140
	b	LBB0_141
LBB0_346:                               ; %cond.load248
	ld1.s	{ v0 }[0], [x16]
	tbz	w15, #1, LBB0_143
LBB0_347:                               ; %cond.load251
	add	x17, x16, #4
	ld1.s	{ v0 }[1], [x17]
	tbz	w15, #2, LBB0_144
LBB0_348:                               ; %cond.load254
	add	x17, x16, #8
	ld1.s	{ v0 }[2], [x17]
	tbz	w15, #3, LBB0_145
LBB0_349:                               ; %cond.load257
	add	x17, x16, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q18, [sp, #1232]
	tbz	w15, #4, LBB0_146
LBB0_350:                               ; %cond.load260
	add	x17, x16, #16
	ld1.s	{ v18 }[0], [x17]
	tbz	w15, #5, LBB0_147
LBB0_351:                               ; %cond.load263
	add	x17, x16, #20
	ld1.s	{ v18 }[1], [x17]
	tbz	w15, #6, LBB0_148
LBB0_352:                               ; %cond.load266
	add	x17, x16, #24
	ld1.s	{ v18 }[2], [x17]
	tbnz	w15, #7, LBB0_149
	b	LBB0_150
LBB0_353:                               ; %cond.load273
	ld1.s	{ v0 }[0], [x16]
	tbz	w15, #1, LBB0_152
LBB0_354:                               ; %cond.load276
	add	x17, x16, #4
	ld1.s	{ v0 }[1], [x17]
	tbz	w15, #2, LBB0_153
LBB0_355:                               ; %cond.load279
	add	x17, x16, #8
	ld1.s	{ v0 }[2], [x17]
	tbz	w15, #3, LBB0_154
LBB0_356:                               ; %cond.load282
	add	x17, x16, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q18, [sp, #1264]
	tbz	w15, #4, LBB0_155
LBB0_357:                               ; %cond.load285
	add	x17, x16, #16
	ld1.s	{ v18 }[0], [x17]
	tbz	w15, #5, LBB0_156
LBB0_358:                               ; %cond.load288
	add	x17, x16, #20
	ld1.s	{ v18 }[1], [x17]
	tbz	w15, #6, LBB0_157
LBB0_359:                               ; %cond.load291
	add	x17, x16, #24
	ld1.s	{ v18 }[2], [x17]
	tbnz	w15, #7, LBB0_158
	b	LBB0_159
LBB0_360:                               ; %cond.load298
	ld1.s	{ v0 }[0], [x16]
	tbz	w15, #1, LBB0_161
LBB0_361:                               ; %cond.load301
	add	x17, x16, #4
	ld1.s	{ v0 }[1], [x17]
	tbz	w15, #2, LBB0_162
LBB0_362:                               ; %cond.load304
	add	x17, x16, #8
	ld1.s	{ v0 }[2], [x17]
	tbz	w15, #3, LBB0_163
LBB0_363:                               ; %cond.load307
	add	x17, x16, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q6, [sp, #1296]
	tbz	w15, #4, LBB0_164
LBB0_364:                               ; %cond.load310
	add	x17, x16, #16
	ld1.s	{ v6 }[0], [x17]
	tbz	w15, #5, LBB0_165
LBB0_365:                               ; %cond.load313
	add	x17, x16, #20
	ld1.s	{ v6 }[1], [x17]
	tbz	w15, #6, LBB0_166
LBB0_366:                               ; %cond.load316
	add	x17, x16, #24
	ld1.s	{ v6 }[2], [x17]
	tbnz	w15, #7, LBB0_167
	b	LBB0_168
LBB0_367:                               ; %cond.load323
	ld1.s	{ v0 }[0], [x16]
	ushll2.2d	v16, v22, #0
	ushll2.2d	v25, v13, #0
	ushll.2d	v18, v22, #0
	tbz	w15, #1, LBB0_170
LBB0_368:                               ; %cond.load326
	add	x17, x16, #4
	ld1.s	{ v0 }[1], [x17]
	tbz	w15, #2, LBB0_171
LBB0_369:                               ; %cond.load329
	add	x17, x16, #8
	ld1.s	{ v0 }[2], [x17]
	fmov	x5, d25
	fmov	x3, d18
	fmov	x4, d16
	tbnz	w15, #3, LBB0_172
	b	LBB0_173
LBB0_370:                               ; %cond.load348
	ld1.s	{ v0 }[0], [x14]
	ldr	q8, [sp, #272]                  ; 16-byte Reload
	mov.16b	v22, v9
	tbz	w16, #1, LBB0_183
LBB0_371:                               ; %cond.load351
	add	x0, x14, #4
	ld1.s	{ v0 }[1], [x0]
	tbz	w16, #2, LBB0_184
LBB0_372:                               ; %cond.load354
	add	x0, x14, #8
	ld1.s	{ v0 }[2], [x0]
	tbz	w16, #3, LBB0_185
LBB0_373:                               ; %cond.load357
	add	x0, x14, #12
	ld1.s	{ v0 }[3], [x0]
	ldr	q5, [x17, #16]
	tbz	w16, #4, LBB0_186
LBB0_374:                               ; %cond.load360
	add	x17, x14, #16
	ld1.s	{ v5 }[0], [x17]
	tbz	w16, #5, LBB0_187
LBB0_375:                               ; %cond.load363
	add	x17, x14, #20
	ld1.s	{ v5 }[1], [x17]
	tbz	w16, #6, LBB0_188
LBB0_376:                               ; %cond.load366
	add	x17, x14, #24
	ld1.s	{ v5 }[2], [x17]
	and.16b	v7, v19, v23
	tbnz	w16, #7, LBB0_189
	b	LBB0_190
LBB0_377:                               ; %cond.load373
	ld1.s	{ v0 }[0], [x16]
	tbz	w14, #1, LBB0_192
LBB0_378:                               ; %cond.load376
	add	x17, x16, #4
	ld1.s	{ v0 }[1], [x17]
	tbz	w14, #2, LBB0_193
LBB0_379:                               ; %cond.load379
	add	x17, x16, #8
	ld1.s	{ v0 }[2], [x17]
	tbz	w14, #3, LBB0_194
LBB0_380:                               ; %cond.load382
	add	x17, x16, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q5, [sp, #1072]
	tbz	w14, #4, LBB0_195
LBB0_381:                               ; %cond.load385
	add	x17, x16, #16
	ld1.s	{ v5 }[0], [x17]
	tbz	w14, #5, LBB0_196
LBB0_382:                               ; %cond.load388
	add	x17, x16, #20
	ld1.s	{ v5 }[1], [x17]
	sshll.2d	v7, v1, #0
	tbz	w14, #6, LBB0_197
LBB0_383:                               ; %cond.load391
	add	x17, x16, #24
	ld1.s	{ v5 }[2], [x17]
	and.16b	v7, v7, v21
	tbnz	w14, #7, LBB0_198
	b	LBB0_199
LBB0_384:                               ; %cond.load398
	ld1.s	{ v0 }[0], [x16]
	tbz	w14, #1, LBB0_201
LBB0_385:                               ; %cond.load401
	add	x17, x16, #4
	ld1.s	{ v0 }[1], [x17]
	tbz	w14, #2, LBB0_202
LBB0_386:                               ; %cond.load404
	add	x17, x16, #8
	ld1.s	{ v0 }[2], [x17]
	tbz	w14, #3, LBB0_203
LBB0_387:                               ; %cond.load407
	add	x17, x16, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q5, [sp, #1104]
	tbz	w14, #4, LBB0_204
LBB0_388:                               ; %cond.load410
	add	x17, x16, #16
	ld1.s	{ v5 }[0], [x17]
	tbz	w14, #5, LBB0_205
LBB0_389:                               ; %cond.load413
	add	x17, x16, #20
	ld1.s	{ v5 }[1], [x17]
	sshll.2d	v7, v1, #0
	tbz	w14, #6, LBB0_206
LBB0_390:                               ; %cond.load416
	add	x17, x16, #24
	ld1.s	{ v5 }[2], [x17]
	and.16b	v7, v7, v20
	tbnz	w14, #7, LBB0_207
	b	LBB0_208
LBB0_391:                               ; %cond.load423
	ld1.s	{ v0 }[0], [x16]
	tbz	w14, #1, LBB0_210
LBB0_392:                               ; %cond.load426
	add	x17, x16, #4
	ld1.s	{ v0 }[1], [x17]
	tbz	w14, #2, LBB0_211
LBB0_393:                               ; %cond.load429
	add	x17, x16, #8
	ld1.s	{ v0 }[2], [x17]
	tbz	w14, #3, LBB0_212
LBB0_394:                               ; %cond.load432
	add	x17, x16, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q5, [sp, #1136]
	tbz	w14, #4, LBB0_213
LBB0_395:                               ; %cond.load435
	add	x17, x16, #16
	ld1.s	{ v5 }[0], [x17]
	tbz	w14, #5, LBB0_214
LBB0_396:                               ; %cond.load438
	add	x17, x16, #20
	ld1.s	{ v5 }[1], [x17]
	sshll.2d	v7, v1, #0
	tbz	w14, #6, LBB0_215
LBB0_397:                               ; %cond.load441
	add	x17, x16, #24
	ld1.s	{ v5 }[2], [x17]
	and.16b	v6, v7, v6
	tbnz	w14, #7, LBB0_216
	b	LBB0_217
LBB0_398:                               ; %cond.load448
	ld1.s	{ v0 }[0], [x16]
	tbz	w14, #1, LBB0_219
LBB0_399:                               ; %cond.load451
	add	x17, x16, #4
	ld1.s	{ v0 }[1], [x17]
	tbz	w14, #2, LBB0_220
LBB0_400:                               ; %cond.load454
	add	x17, x16, #8
	ld1.s	{ v0 }[2], [x17]
	tbz	w14, #3, LBB0_221
LBB0_401:                               ; %cond.load457
	add	x17, x16, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q5, [sp, #1168]
	tbz	w14, #4, LBB0_222
LBB0_402:                               ; %cond.load460
	add	x17, x16, #16
	ld1.s	{ v5 }[0], [x17]
	tbz	w14, #5, LBB0_223
LBB0_403:                               ; %cond.load463
	add	x17, x16, #20
	ld1.s	{ v5 }[1], [x17]
	tbz	w14, #6, LBB0_224
LBB0_404:                               ; %cond.load466
	add	x17, x16, #24
	ld1.s	{ v5 }[2], [x17]
	tbnz	w14, #7, LBB0_225
	b	LBB0_226
LBB0_405:                               ; %cond.load473
	ld1.s	{ v0 }[0], [x12]
	tbz	w14, #1, LBB0_228
LBB0_406:                               ; %cond.load476
	add	x16, x12, #4
	ld1.s	{ v0 }[1], [x16]
	tbz	w14, #2, LBB0_229
LBB0_407:                               ; %cond.load479
	add	x16, x12, #8
	ld1.s	{ v0 }[2], [x16]
	tbz	w14, #3, LBB0_230
LBB0_408:                               ; %cond.load482
	add	x16, x12, #12
	ld1.s	{ v0 }[3], [x16]
	ldr	q5, [x15, #16]
	tbz	w14, #4, LBB0_231
LBB0_409:                               ; %cond.load485
	add	x15, x12, #16
	ld1.s	{ v5 }[0], [x15]
	adrp	x15, lCPI0_10@PAGE
	tbz	w14, #5, LBB0_232
LBB0_410:                               ; %cond.load488
	add	x16, x12, #20
	ld1.s	{ v5 }[1], [x16]
	ldr	q6, [x15, lCPI0_10@PAGEOFF]
	orr.16b	v4, v4, v12
	tbz	w14, #6, LBB0_233
LBB0_411:                               ; %cond.load491
	add	x15, x12, #24
	ld1.s	{ v5 }[2], [x15]
	and.16b	v7, v26, v6
	and.16b	v4, v26, v4
	tbnz	w14, #7, LBB0_234
	b	LBB0_235
LBB0_412:                               ; %cond.store
	str	s0, [x13]
	ldr	q4, [x14, #16]
	ldr	q5, [x15, #16]
	ldr	q6, [x16, #16]
	ldr	q30, [x17, #16]
	tbz	w12, #1, LBB0_237
LBB0_413:                               ; %cond.store499
	add	x14, x13, #4
	st1.s	{ v0 }[1], [x14]
	stp	q5, q4, [sp, #208]              ; 32-byte Folded Spill
	fmul.4s	v4, v4, v5
	fmul.4s	v5, v6, v30
	tbz	w12, #2, LBB0_238
LBB0_414:                               ; %cond.store501
	add	x14, x13, #8
	st1.s	{ v0 }[2], [x14]
	fsub.4s	v4, v4, v5
	tbz	w12, #3, LBB0_239
LBB0_415:                               ; %cond.store503
	add	x14, x13, #12
	st1.s	{ v0 }[3], [x14]
	and.16b	v0, v10, v4
	tbz	w12, #4, LBB0_240
LBB0_416:                               ; %cond.store505
	str	s0, [x13, #16]
	adrp	x14, lCPI0_15@PAGE
	tbz	w12, #5, LBB0_241
LBB0_417:                               ; %cond.store507
	add	x15, x13, #20
	st1.s	{ v0 }[1], [x15]
	ldr	q5, [x14, lCPI0_15@PAGEOFF]
	tbz	w12, #6, LBB0_242
LBB0_418:                               ; %cond.store509
	add	x14, x13, #24
	st1.s	{ v0 }[2], [x14]
	ldr	q4, [sp, #352]                  ; 16-byte Reload
	and.16b	v4, v29, v4
	and.16b	v5, v29, v5
	tbnz	w12, #7, LBB0_243
	b	LBB0_244
LBB0_419:                               ; %cond.store514
	str	s0, [x13]
	ldr	q4, [x14, #16]
	ldr	q5, [x15, #16]
	ldr	q16, [x16, #16]
	ldr	q17, [x17, #16]
	tbz	w12, #1, LBB0_246
LBB0_420:                               ; %cond.store516
	add	x14, x13, #4
	st1.s	{ v0 }[1], [x14]
	stp	q5, q4, [sp, #112]              ; 32-byte Folded Spill
	fmul.4s	v4, v4, v5
	fmul.4s	v5, v16, v17
	tbz	w12, #2, LBB0_247
LBB0_421:                               ; %cond.store518
	add	x14, x13, #8
	st1.s	{ v0 }[2], [x14]
	fsub.4s	v4, v4, v5
	tbz	w12, #3, LBB0_248
LBB0_422:                               ; %cond.store520
	add	x14, x13, #12
	st1.s	{ v0 }[3], [x14]
	and.16b	v0, v10, v4
	tbz	w12, #4, LBB0_249
LBB0_423:                               ; %cond.store522
	str	s0, [x13, #16]
	adrp	x14, lCPI0_20@PAGE
	tbz	w12, #5, LBB0_250
LBB0_424:                               ; %cond.store524
	add	x15, x13, #20
	st1.s	{ v0 }[1], [x15]
	ldr	q5, [x14, lCPI0_20@PAGEOFF]
	tbz	w12, #6, LBB0_251
LBB0_425:                               ; %cond.store526
	add	x14, x13, #24
	st1.s	{ v0 }[2], [x14]
	str	q6, [sp, #352]                  ; 16-byte Spill
	mov.16b	v26, v15
	ldr	q4, [sp, #336]                  ; 16-byte Reload
	and.16b	v4, v18, v4
	and.16b	v5, v18, v5
	tbnz	w12, #7, LBB0_252
	b	LBB0_253
LBB0_426:                               ; %cond.store531
	str	s0, [x13]
	ldr	q4, [x14, #16]
	ldr	q6, [x15, #16]
	ldr	q31, [x16, #16]
	ldr	q13, [x17, #16]
	tbz	w12, #1, LBB0_255
LBB0_427:                               ; %cond.store533
	add	x14, x13, #4
	st1.s	{ v0 }[1], [x14]
	stp	q6, q4, [sp]                    ; 32-byte Folded Spill
	fmul.4s	v4, v4, v6
	fmul.4s	v6, v31, v13
	tbz	w12, #2, LBB0_256
LBB0_428:                               ; %cond.store535
	add	x14, x13, #8
	st1.s	{ v0 }[2], [x14]
	fsub.4s	v4, v4, v6
	tbz	w12, #3, LBB0_257
LBB0_429:                               ; %cond.store537
	add	x14, x13, #12
	st1.s	{ v0 }[3], [x14]
	and.16b	v4, v10, v4
	tbz	w12, #4, LBB0_258
LBB0_430:                               ; %cond.store539
	str	s4, [x13, #16]
	adrp	x14, lCPI0_25@PAGE
	tbz	w12, #5, LBB0_259
LBB0_431:                               ; %cond.store541
	add	x15, x13, #20
	st1.s	{ v4 }[1], [x15]
	ldr	q6, [x14, lCPI0_25@PAGEOFF]
	tbz	w12, #6, LBB0_260
LBB0_432:                               ; %cond.store543
	add	x14, x13, #24
	st1.s	{ v4 }[2], [x14]
	str	q17, [sp, #80]                  ; 16-byte Spill
	str	q16, [sp, #336]                 ; 16-byte Spill
	ldr	q0, [sp, #320]                  ; 16-byte Reload
	and.16b	v0, v8, v0
	and.16b	v6, v8, v6
	tbnz	w12, #7, LBB0_261
	b	LBB0_262
LBB0_433:                               ; %cond.store548
	str	s17, [x13]
	ldr	q9, [x14, #16]
	ldr	q25, [x15, #16]
	ldr	q0, [x16, #16]
	ldr	q6, [x17, #16]
	tbz	w12, #1, LBB0_264
LBB0_434:                               ; %cond.store550
	add	x14, x13, #4
	st1.s	{ v17 }[1], [x14]
	fmul.4s	v19, v9, v25
	fmul.4s	v20, v0, v6
	tbz	w12, #2, LBB0_265
LBB0_435:                               ; %cond.store552
	add	x14, x13, #8
	st1.s	{ v17 }[2], [x14]
	fsub.4s	v19, v19, v20
	tbz	w12, #3, LBB0_266
LBB0_436:                               ; %cond.store554
	add	x14, x13, #12
	st1.s	{ v17 }[3], [x14]
	and.16b	v17, v10, v19
	tbz	w12, #4, LBB0_267
LBB0_437:                               ; %cond.store556
	str	s17, [x13, #16]
	adrp	x14, lCPI0_7@PAGE
	adrp	x15, lCPI0_8@PAGE
	adrp	x16, lCPI0_9@PAGE
	tbz	w12, #5, LBB0_268
LBB0_438:                               ; %cond.store558
	add	x17, x13, #20
	st1.s	{ v17 }[1], [x17]
	ldr	q19, [x14, lCPI0_7@PAGEOFF]
	ldr	q20, [x15, lCPI0_8@PAGEOFF]
	ldr	q21, [x16, lCPI0_9@PAGEOFF]
	tbz	w12, #6, LBB0_269
LBB0_439:                               ; %cond.store560
	add	x14, x13, #24
	st1.s	{ v17 }[2], [x14]
	mov.16b	v18, v10
	and.16b	v19, v27, v19
	and.16b	v20, v11, v20
	and.16b	v21, v22, v21
	tbnz	w12, #7, LBB0_270
	b	LBB0_271
LBB0_440:                               ; %cond.store565
	str	s26, [x11]
	ushll.4s	v28, v27, #0
	tbz	w10, #1, LBB0_273
LBB0_441:                               ; %cond.store567
	add	x12, x11, #4
	st1.s	{ v26 }[1], [x12]
	fmul.4s	v27, v7, v17
	fmul.4s	v10, v19, v20
	shl.4s	v28, v28, #31
	tbz	w10, #2, LBB0_274
LBB0_442:                               ; %cond.store569
	add	x12, x11, #8
	st1.s	{ v26 }[2], [x12]
	fsub.4s	v27, v27, v10
	cmlt.4s	v28, v28, #0
	tbz	w10, #3, LBB0_275
LBB0_443:                               ; %cond.store571
	add	x12, x11, #12
	st1.s	{ v26 }[3], [x12]
	and.16b	v26, v28, v27
	mov.16b	v29, v18
	tbz	w10, #4, LBB0_276
LBB0_444:                               ; %cond.store573
	str	s26, [x11, #16]
	tbz	w10, #5, LBB0_277
LBB0_445:                               ; %cond.store575
	add	x12, x11, #20
	st1.s	{ v26 }[1], [x12]
	sshll.2d	v27, v1, #0
	tbz	w10, #6, LBB0_278
LBB0_446:                               ; %cond.store577
	add	x12, x11, #24
	st1.s	{ v26 }[2], [x12]
	ldr	q18, [sp, #480]                 ; 16-byte Reload
	and.16b	v27, v27, v18
	tbnz	w10, #7, LBB0_279
	b	LBB0_280
LBB0_447:                               ; %cond.store582
	str	s26, [x11]
	tbz	w10, #1, LBB0_282
LBB0_448:                               ; %cond.store584
	add	x12, x11, #4
	st1.s	{ v26 }[1], [x12]
	ldp	q18, q28, [sp, #208]            ; 32-byte Folded Reload
	fmul.4s	v27, v28, v30
	ldr	q28, [sp, #352]                 ; 16-byte Reload
	fmul.4s	v28, v18, v28
	tbz	w10, #2, LBB0_283
LBB0_449:                               ; %cond.store586
	add	x12, x11, #8
	st1.s	{ v26 }[2], [x12]
	fadd.4s	v27, v28, v27
	tbz	w10, #3, LBB0_284
LBB0_450:                               ; %cond.store588
	add	x12, x11, #12
	st1.s	{ v26 }[3], [x12]
	and.16b	v26, v29, v27
	tbz	w10, #4, LBB0_285
LBB0_451:                               ; %cond.store590
	str	s26, [x11, #16]
	tbz	w10, #5, LBB0_286
LBB0_452:                               ; %cond.store592
	add	x12, x11, #20
	st1.s	{ v26 }[1], [x12]
	sshll.2d	v27, v1, #0
	tbz	w10, #6, LBB0_287
LBB0_453:                               ; %cond.store594
	add	x12, x11, #24
	st1.s	{ v26 }[2], [x12]
	ldr	q18, [sp, #464]                 ; 16-byte Reload
	and.16b	v27, v27, v18
	tbnz	w10, #7, LBB0_288
	b	LBB0_289
LBB0_454:                               ; %cond.store599
	str	s26, [x11]
	tbz	w10, #1, LBB0_291
LBB0_455:                               ; %cond.store601
	add	x12, x11, #4
	st1.s	{ v26 }[1], [x12]
	ldp	q18, q28, [sp, #112]            ; 32-byte Folded Reload
	ldr	q27, [sp, #80]                  ; 16-byte Reload
	fmul.4s	v27, v28, v27
	ldr	q28, [sp, #336]                 ; 16-byte Reload
	fmul.4s	v28, v18, v28
	tbz	w10, #2, LBB0_292
LBB0_456:                               ; %cond.store603
	add	x12, x11, #8
	st1.s	{ v26 }[2], [x12]
	fadd.4s	v27, v28, v27
	tbz	w10, #3, LBB0_293
LBB0_457:                               ; %cond.store605
	add	x12, x11, #12
	st1.s	{ v26 }[3], [x12]
	and.16b	v26, v29, v27
	tbz	w10, #4, LBB0_294
LBB0_458:                               ; %cond.store607
	str	s26, [x11, #16]
	tbz	w10, #5, LBB0_295
LBB0_459:                               ; %cond.store609
	add	x12, x11, #20
	st1.s	{ v26 }[1], [x12]
	sshll.2d	v27, v1, #0
	tbz	w10, #6, LBB0_296
LBB0_460:                               ; %cond.store611
	add	x12, x11, #24
	st1.s	{ v26 }[2], [x12]
	ldr	q18, [sp, #448]                 ; 16-byte Reload
	and.16b	v27, v27, v18
	tbnz	w10, #7, LBB0_297
	b	LBB0_298
LBB0_461:                               ; %cond.store616
	str	s5, [x11]
	tbz	w10, #1, LBB0_300
LBB0_462:                               ; %cond.store618
	add	x12, x11, #4
	st1.s	{ v5 }[1], [x12]
	ldp	q26, q18, [sp]                  ; 32-byte Folded Reload
	fmul.4s	v18, v18, v13
	fmul.4s	v26, v26, v31
	tbz	w10, #2, LBB0_301
LBB0_463:                               ; %cond.store620
	add	x12, x11, #8
	st1.s	{ v5 }[2], [x12]
	fadd.4s	v18, v26, v18
	tbz	w10, #3, LBB0_302
LBB0_464:                               ; %cond.store622
	add	x12, x11, #12
	st1.s	{ v5 }[3], [x12]
	and.16b	v5, v29, v18
	tbz	w10, #4, LBB0_303
LBB0_465:                               ; %cond.store624
	str	s5, [x11, #16]
	tbz	w10, #5, LBB0_304
LBB0_466:                               ; %cond.store626
	add	x12, x11, #20
	st1.s	{ v5 }[1], [x12]
	sshll.2d	v18, v1, #0
	tbz	w10, #6, LBB0_305
LBB0_467:                               ; %cond.store628
	add	x12, x11, #24
	st1.s	{ v5 }[2], [x12]
	ldr	q26, [sp, #432]                 ; 16-byte Reload
	and.16b	v18, v18, v26
	tbnz	w10, #7, LBB0_306
	b	LBB0_307
LBB0_468:                               ; %cond.store633
	str	s1, [x11]
	tbz	w10, #1, LBB0_309
LBB0_469:                               ; %cond.store635
	add	x12, x11, #4
	st1.s	{ v1 }[1], [x12]
	fmul.4s	v2, v9, v6
	fmul.4s	v0, v25, v0
	tbz	w10, #2, LBB0_310
LBB0_470:                               ; %cond.store637
	add	x12, x11, #8
	st1.s	{ v1 }[2], [x12]
	fadd.4s	v0, v0, v2
	tbz	w10, #3, LBB0_311
LBB0_471:                               ; %cond.store639
	add	x12, x11, #12
	st1.s	{ v1 }[3], [x12]
	and.16b	v0, v29, v0
	tbz	w10, #4, LBB0_312
LBB0_472:                               ; %cond.store641
	str	s0, [x11, #16]
	tbz	w10, #5, LBB0_313
LBB0_473:                               ; %cond.store643
	add	x12, x11, #20
	st1.s	{ v0 }[1], [x12]
	tbz	w10, #6, LBB0_314
LBB0_474:                               ; %cond.store645
	add	x12, x11, #24
	st1.s	{ v0 }[2], [x12]
	tbnz	w10, #7, LBB0_315
	b	LBB0_316
LBB0_475:                               ; %cond.store650
	str	s0, [x8]
	ushll.4s	v2, v1, #0
	tbz	w10, #1, LBB0_318
LBB0_476:                               ; %cond.store652
	add	x9, x8, #4
	st1.s	{ v0 }[1], [x9]
	fmul.4s	v1, v7, v20
	fmul.4s	v3, v17, v19
	shl.4s	v2, v2, #31
	tbz	w10, #2, LBB0_319
LBB0_477:                               ; %cond.store654
	add	x9, x8, #8
	st1.s	{ v0 }[2], [x9]
	fadd.4s	v1, v3, v1
	cmlt.4s	v2, v2, #0
	tbz	w10, #3, LBB0_320
LBB0_478:                               ; %cond.store656
	add	x9, x8, #12
	st1.s	{ v0 }[3], [x9]
	and.16b	v0, v2, v1
	tbz	w10, #4, LBB0_321
LBB0_479:                               ; %cond.store658
	str	s0, [x8, #16]
	tbz	w10, #5, LBB0_322
LBB0_480:                               ; %cond.store660
	add	x9, x8, #20
	st1.s	{ v0 }[1], [x9]
	tbz	w10, #6, LBB0_323
LBB0_481:                               ; %cond.store662
	add	x9, x8, #24
	st1.s	{ v0 }[2], [x9]
	tbnz	w10, #7, LBB0_324
	b	LBB0_325
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh22, Lloh23
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

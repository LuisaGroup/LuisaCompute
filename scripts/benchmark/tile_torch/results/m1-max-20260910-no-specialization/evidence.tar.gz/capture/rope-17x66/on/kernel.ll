; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [160 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [160 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [160 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [160 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill11 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill11, align 64
  %.spill12 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill12, align 64
  %.spill13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill13, align 64
  %.spill14 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill14, align 64
  %.spill15 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill15, align 64
  %.spill16 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill16, align 64
  %.spill17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill17, align 64
  %.spill18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill18, align 64
  %.spill19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill19, align 64
  %.spill20 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill20, align 64
  %.spill21 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill21, align 64
  %.spill22 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill22, align 64
  %.spill23 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill23, align 64
  %.spill24 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill24, align 64
  %.spill25 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill25, align 64
  %.spill26 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill26, align 64
  %.spill27 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill27, align 64
  %.spill28 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill28, align 64
  %.spill29 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill29, align 1
  %tile_snapshot.spill30 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill30, align 64
  %.spill31 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill31, align 64
  %.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill32, align 64
  %.spill33 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill33, align 64
  %.spill34 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill34, align 64
  %.spill35 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill35, align 64
  %.spill36 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill36, align 64
  %.spill37 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill37, align 64
  %.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill38, align 64
  %tile_snapshot.spill39 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill39, align 64
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.spill41 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill41, align 64
  %.spill42 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill42, align 64
  %.spill43 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill43, align 64
  %.spill44 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill44, align 64
  %.spill45 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill45, align 64
  %.spill46 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill46, align 64
  %.spill47 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill47, align 64
  %.spill48 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill48, align 64
  %tile_snapshot.spill49 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill49, align 64
  %.spill50 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill50, align 64
  %.spill51 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill51, align 64
  %.spill52 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill52, align 64
  %.spill53 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill53, align 64
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert54 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat55 = shufflevector <8 x i32> %.splatinsert54, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat55, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert56 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat57 = shufflevector <8 x i32> %.splatinsert56, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat57, %45
  %48 = mul i32 %36, 1
  %.splatinsert58 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat59 = shufflevector <8 x i32> %.splatinsert58, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat59, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert60 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat61 = shufflevector <8 x i32> %.splatinsert60, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat61, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert62 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat63 = shufflevector <8 x i32> %.splatinsert62, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat63
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load <8 x i64>, ptr %.spill10, align 64
  %69 = select <8 x i1> %55, <8 x i64> %67, <8 x i64> %68
  store <8 x i64> %69, ptr %.spill10, align 64
  %70 = extractvalue { ptr, i64 } %13, 1
  %71 = extractvalue { ptr, i64 } %13, 0
  %72 = ptrtoint ptr %71 to i64
  %73 = extractvalue { ptr, i64 } %31, 1
  %74 = extractvalue { ptr, i64 } %31, 0
  %75 = ptrtoint ptr %74 to i64
  %76 = icmp uge i64 %72, %75
  %77 = sub i64 %72, %75
  %78 = icmp uge i64 %77, 4488
  %79 = and i1 %76, %78
  %80 = icmp uge i64 %75, %72
  %81 = sub i64 %75, %72
  %82 = icmp uge i64 %81, 4488
  %83 = and i1 %80, %82
  %84 = or i1 %79, %83
  %85 = and i1 true, %84
  %86 = extractvalue { ptr, i64 } %19, 1
  %87 = extractvalue { ptr, i64 } %19, 0
  %88 = ptrtoint ptr %87 to i64
  %89 = icmp uge i64 %88, %75
  %90 = sub i64 %88, %75
  %91 = icmp uge i64 %90, 4488
  %92 = and i1 %89, %91
  %93 = icmp uge i64 %75, %88
  %94 = sub i64 %75, %88
  %95 = icmp uge i64 %94, 2244
  %96 = and i1 %93, %95
  %97 = or i1 %92, %96
  %98 = and i1 %85, %97
  %99 = extractvalue { ptr, i64 } %25, 1
  %100 = extractvalue { ptr, i64 } %25, 0
  %101 = ptrtoint ptr %100 to i64
  %102 = icmp uge i64 %101, %75
  %103 = sub i64 %101, %75
  %104 = icmp uge i64 %103, 4488
  %105 = and i1 %102, %104
  %106 = icmp uge i64 %75, %101
  %107 = sub i64 %75, %101
  %108 = icmp uge i64 %107, 2244
  %109 = and i1 %106, %108
  %110 = or i1 %105, %109
  %111 = and i1 %98, %110
  br i1 %111, label %direct.true, label %direct.false

direct.schedule.1:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %112 = add <8 x i64> zeroinitializer, %.spill.load
  %.spill.load64 = load <8 x i64>, ptr %.spill10, align 64
  %113 = add <8 x i64> %.spill.load64, zeroinitializer
  %114 = add <8 x i64> zeroinitializer, %113
  %115 = add <8 x i64> zeroinitializer, %112
  %116 = mul <8 x i64> %114, splat (i64 66)
  %117 = add <8 x i64> %116, %115
  %118 = extractvalue { ptr, i64 } %13, 0
  %119 = extractelement <8 x i64> %117, i32 0
  %120 = sub i64 %119, 0
  %121 = mul i64 %120, 4
  %buffer.contiguous.address = getelementptr i8, ptr %118, i64 %121
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %55, <8 x float> zeroinitializer)
  %122 = add <8 x i64> splat (i64 33), %112
  %123 = add <8 x i64> %116, %122
  %124 = extractvalue { ptr, i64 } %13, 0
  %125 = extractelement <8 x i64> %123, i32 0
  %126 = sub i64 %125, 0
  %127 = mul i64 %126, 4
  %buffer.contiguous.address65 = getelementptr i8, ptr %124, i64 %127
  %buffer.contiguous.load66 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address65, <8 x i1> %55, <8 x float> zeroinitializer)
  %128 = mul <8 x i64> %114, splat (i64 33)
  %129 = add <8 x i64> %128, %115
  %130 = extractvalue { ptr, i64 } %19, 0
  %131 = extractelement <8 x i64> %129, i32 0
  %132 = sub i64 %131, 0
  %133 = mul i64 %132, 4
  %buffer.contiguous.address67 = getelementptr i8, ptr %130, i64 %133
  %buffer.contiguous.load68 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address67, <8 x i1> %55, <8 x float> zeroinitializer)
  %134 = extractvalue { ptr, i64 } %25, 0
  %135 = extractelement <8 x i64> %129, i32 0
  %136 = sub i64 %135, 0
  %137 = mul i64 %136, 4
  %buffer.contiguous.address69 = getelementptr i8, ptr %134, i64 %137
  %buffer.contiguous.load70 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address69, <8 x i1> %55, <8 x float> zeroinitializer)
  %138 = fmul <8 x float> %buffer.contiguous.load, %buffer.contiguous.load68
  %139 = fmul <8 x float> %buffer.contiguous.load66, %buffer.contiguous.load70
  %140 = fsub <8 x float> %138, %139
  %141 = extractvalue { ptr, i64 } %31, 0
  %142 = extractelement <8 x i64> %117, i32 0
  %143 = sub i64 %142, 0
  %144 = mul i64 %143, 4
  %buffer.contiguous.address71 = getelementptr i8, ptr %141, i64 %144
  call void @llvm.masked.store.v8f32.p0(<8 x float> %140, ptr align 1 %buffer.contiguous.address71, <8 x i1> %55)
  %145 = fmul <8 x float> %buffer.contiguous.load, %buffer.contiguous.load70
  %146 = fmul <8 x float> %buffer.contiguous.load66, %buffer.contiguous.load68
  %147 = fadd <8 x float> %145, %146
  %148 = extractvalue { ptr, i64 } %31, 0
  %149 = extractelement <8 x i64> %123, i32 0
  %150 = sub i64 %149, 0
  %151 = mul i64 %150, 4
  %buffer.contiguous.address72 = getelementptr i8, ptr %148, i64 %151
  call void @llvm.masked.store.v8f32.p0(<8 x float> %147, ptr align 1 %buffer.contiguous.address72, <8 x i1> %55)
  %.spill.load73 = load <8 x i64>, ptr %.spill, align 64
  %152 = add <8 x i64> splat (i64 8), %.spill.load73
  %153 = add <8 x i64> zeroinitializer, %152
  %154 = add <8 x i64> %116, %153
  %155 = extractvalue { ptr, i64 } %13, 0
  %156 = extractelement <8 x i64> %154, i32 0
  %157 = sub i64 %156, 0
  %158 = mul i64 %157, 4
  %buffer.contiguous.address74 = getelementptr i8, ptr %155, i64 %158
  %buffer.contiguous.load75 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address74, <8 x i1> %55, <8 x float> zeroinitializer)
  %159 = add <8 x i64> splat (i64 33), %152
  %160 = add <8 x i64> %116, %159
  %161 = extractvalue { ptr, i64 } %13, 0
  %162 = extractelement <8 x i64> %160, i32 0
  %163 = sub i64 %162, 0
  %164 = mul i64 %163, 4
  %buffer.contiguous.address76 = getelementptr i8, ptr %161, i64 %164
  %buffer.contiguous.load77 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address76, <8 x i1> %55, <8 x float> zeroinitializer)
  %165 = add <8 x i64> %128, %153
  %166 = extractvalue { ptr, i64 } %19, 0
  %167 = extractelement <8 x i64> %165, i32 0
  %168 = sub i64 %167, 0
  %169 = mul i64 %168, 4
  %buffer.contiguous.address78 = getelementptr i8, ptr %166, i64 %169
  %buffer.contiguous.load79 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address78, <8 x i1> %55, <8 x float> zeroinitializer)
  %170 = extractvalue { ptr, i64 } %25, 0
  %171 = extractelement <8 x i64> %165, i32 0
  %172 = sub i64 %171, 0
  %173 = mul i64 %172, 4
  %buffer.contiguous.address80 = getelementptr i8, ptr %170, i64 %173
  %buffer.contiguous.load81 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address80, <8 x i1> %55, <8 x float> zeroinitializer)
  %174 = fmul <8 x float> %buffer.contiguous.load75, %buffer.contiguous.load79
  %175 = fmul <8 x float> %buffer.contiguous.load77, %buffer.contiguous.load81
  %176 = fsub <8 x float> %174, %175
  %177 = extractvalue { ptr, i64 } %31, 0
  %178 = extractelement <8 x i64> %154, i32 0
  %179 = sub i64 %178, 0
  %180 = mul i64 %179, 4
  %buffer.contiguous.address82 = getelementptr i8, ptr %177, i64 %180
  call void @llvm.masked.store.v8f32.p0(<8 x float> %176, ptr align 1 %buffer.contiguous.address82, <8 x i1> %55)
  %181 = fmul <8 x float> %buffer.contiguous.load75, %buffer.contiguous.load81
  %182 = fmul <8 x float> %buffer.contiguous.load77, %buffer.contiguous.load79
  %183 = fadd <8 x float> %181, %182
  %184 = extractvalue { ptr, i64 } %31, 0
  %185 = extractelement <8 x i64> %160, i32 0
  %186 = sub i64 %185, 0
  %187 = mul i64 %186, 4
  %buffer.contiguous.address83 = getelementptr i8, ptr %184, i64 %187
  call void @llvm.masked.store.v8f32.p0(<8 x float> %183, ptr align 1 %buffer.contiguous.address83, <8 x i1> %55)
  %.spill.load84 = load <8 x i64>, ptr %.spill, align 64
  %188 = add <8 x i64> splat (i64 16), %.spill.load84
  %189 = add <8 x i64> zeroinitializer, %188
  %190 = add <8 x i64> %116, %189
  %191 = extractvalue { ptr, i64 } %13, 0
  %192 = extractelement <8 x i64> %190, i32 0
  %193 = sub i64 %192, 0
  %194 = mul i64 %193, 4
  %buffer.contiguous.address85 = getelementptr i8, ptr %191, i64 %194
  %buffer.contiguous.load86 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address85, <8 x i1> %55, <8 x float> zeroinitializer)
  %195 = add <8 x i64> splat (i64 33), %188
  %196 = add <8 x i64> %116, %195
  %197 = extractvalue { ptr, i64 } %13, 0
  %198 = extractelement <8 x i64> %196, i32 0
  %199 = sub i64 %198, 0
  %200 = mul i64 %199, 4
  %buffer.contiguous.address87 = getelementptr i8, ptr %197, i64 %200
  %buffer.contiguous.load88 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address87, <8 x i1> %55, <8 x float> zeroinitializer)
  %201 = add <8 x i64> %128, %189
  %202 = extractvalue { ptr, i64 } %19, 0
  %203 = extractelement <8 x i64> %201, i32 0
  %204 = sub i64 %203, 0
  %205 = mul i64 %204, 4
  %buffer.contiguous.address89 = getelementptr i8, ptr %202, i64 %205
  %buffer.contiguous.load90 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address89, <8 x i1> %55, <8 x float> zeroinitializer)
  %206 = extractvalue { ptr, i64 } %25, 0
  %207 = extractelement <8 x i64> %201, i32 0
  %208 = sub i64 %207, 0
  %209 = mul i64 %208, 4
  %buffer.contiguous.address91 = getelementptr i8, ptr %206, i64 %209
  %buffer.contiguous.load92 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address91, <8 x i1> %55, <8 x float> zeroinitializer)
  %210 = fmul <8 x float> %buffer.contiguous.load86, %buffer.contiguous.load90
  %211 = fmul <8 x float> %buffer.contiguous.load88, %buffer.contiguous.load92
  %212 = fsub <8 x float> %210, %211
  %213 = extractvalue { ptr, i64 } %31, 0
  %214 = extractelement <8 x i64> %190, i32 0
  %215 = sub i64 %214, 0
  %216 = mul i64 %215, 4
  %buffer.contiguous.address93 = getelementptr i8, ptr %213, i64 %216
  call void @llvm.masked.store.v8f32.p0(<8 x float> %212, ptr align 1 %buffer.contiguous.address93, <8 x i1> %55)
  %217 = fmul <8 x float> %buffer.contiguous.load86, %buffer.contiguous.load92
  %218 = fmul <8 x float> %buffer.contiguous.load88, %buffer.contiguous.load90
  %219 = fadd <8 x float> %217, %218
  %220 = extractvalue { ptr, i64 } %31, 0
  %221 = extractelement <8 x i64> %196, i32 0
  %222 = sub i64 %221, 0
  %223 = mul i64 %222, 4
  %buffer.contiguous.address94 = getelementptr i8, ptr %220, i64 %223
  call void @llvm.masked.store.v8f32.p0(<8 x float> %219, ptr align 1 %buffer.contiguous.address94, <8 x i1> %55)
  %.spill.load95 = load <8 x i64>, ptr %.spill, align 64
  %224 = add <8 x i64> splat (i64 24), %.spill.load95
  %225 = add <8 x i64> zeroinitializer, %224
  %226 = add <8 x i64> %116, %225
  %227 = extractvalue { ptr, i64 } %13, 0
  %228 = extractelement <8 x i64> %226, i32 0
  %229 = sub i64 %228, 0
  %230 = mul i64 %229, 4
  %buffer.contiguous.address96 = getelementptr i8, ptr %227, i64 %230
  %buffer.contiguous.load97 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address96, <8 x i1> %55, <8 x float> zeroinitializer)
  %231 = add <8 x i64> splat (i64 33), %224
  %232 = add <8 x i64> %116, %231
  %233 = extractvalue { ptr, i64 } %13, 0
  %234 = extractelement <8 x i64> %232, i32 0
  %235 = sub i64 %234, 0
  %236 = mul i64 %235, 4
  %buffer.contiguous.address98 = getelementptr i8, ptr %233, i64 %236
  %buffer.contiguous.load99 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address98, <8 x i1> %55, <8 x float> zeroinitializer)
  %237 = add <8 x i64> %128, %225
  %238 = extractvalue { ptr, i64 } %19, 0
  %239 = extractelement <8 x i64> %237, i32 0
  %240 = sub i64 %239, 0
  %241 = mul i64 %240, 4
  %buffer.contiguous.address100 = getelementptr i8, ptr %238, i64 %241
  %buffer.contiguous.load101 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address100, <8 x i1> %55, <8 x float> zeroinitializer)
  %242 = extractvalue { ptr, i64 } %25, 0
  %243 = extractelement <8 x i64> %237, i32 0
  %244 = sub i64 %243, 0
  %245 = mul i64 %244, 4
  %buffer.contiguous.address102 = getelementptr i8, ptr %242, i64 %245
  %buffer.contiguous.load103 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address102, <8 x i1> %55, <8 x float> zeroinitializer)
  %246 = fmul <8 x float> %buffer.contiguous.load97, %buffer.contiguous.load101
  %247 = fmul <8 x float> %buffer.contiguous.load99, %buffer.contiguous.load103
  %248 = fsub <8 x float> %246, %247
  %249 = extractvalue { ptr, i64 } %31, 0
  %250 = extractelement <8 x i64> %226, i32 0
  %251 = sub i64 %250, 0
  %252 = mul i64 %251, 4
  %buffer.contiguous.address104 = getelementptr i8, ptr %249, i64 %252
  call void @llvm.masked.store.v8f32.p0(<8 x float> %248, ptr align 1 %buffer.contiguous.address104, <8 x i1> %55)
  %253 = fmul <8 x float> %buffer.contiguous.load97, %buffer.contiguous.load103
  %254 = fmul <8 x float> %buffer.contiguous.load99, %buffer.contiguous.load101
  %255 = fadd <8 x float> %253, %254
  %256 = extractvalue { ptr, i64 } %31, 0
  %257 = extractelement <8 x i64> %232, i32 0
  %258 = sub i64 %257, 0
  %259 = mul i64 %258, 4
  %buffer.contiguous.address105 = getelementptr i8, ptr %256, i64 %259
  call void @llvm.masked.store.v8f32.p0(<8 x float> %255, ptr align 1 %buffer.contiguous.address105, <8 x i1> %55)
  %.spill.load106 = load <8 x i64>, ptr %.spill, align 64
  %260 = icmp slt <8 x i64> %.spill.load106, splat (i64 1)
  %261 = and <8 x i1> %55, %260
  %262 = xor <8 x i1> %260, splat (i1 true)
  %263 = and <8 x i1> %55, %262
  %264 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %261)
  %265 = bitcast <8 x i1> %261 to i8
  %266 = call i8 @llvm.cttz.i8(i8 %265, i1 false)
  %267 = zext i8 %266 to i32
  %268 = select i1 %264, i32 %267, i32 0
  %.spill.load107 = load <8 x i64>, ptr %.spill, align 64
  %269 = add <8 x i64> splat (i64 32), %.spill.load107
  %270 = add <8 x i64> zeroinitializer, %269
  %271 = add <8 x i64> %116, %270
  %272 = extractvalue { ptr, i64 } %13, 0
  %273 = select <8 x i1> %261, <8 x i64> %271, <8 x i64> zeroinitializer
  %274 = extractelement <8 x i64> %273, i32 %268
  %275 = zext i32 %268 to i64
  %276 = sub i64 %274, %275
  %277 = mul i64 %276, 4
  %buffer.contiguous.address108 = getelementptr i8, ptr %272, i64 %277
  %buffer.contiguous.load109 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address108, <8 x i1> %261, <8 x float> zeroinitializer)
  %278 = add <8 x i64> splat (i64 33), %269
  %279 = add <8 x i64> %116, %278
  %280 = extractvalue { ptr, i64 } %13, 0
  %281 = select <8 x i1> %261, <8 x i64> %279, <8 x i64> zeroinitializer
  %282 = extractelement <8 x i64> %281, i32 %268
  %283 = zext i32 %268 to i64
  %284 = sub i64 %282, %283
  %285 = mul i64 %284, 4
  %buffer.contiguous.address110 = getelementptr i8, ptr %280, i64 %285
  %buffer.contiguous.load111 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address110, <8 x i1> %261, <8 x float> zeroinitializer)
  %286 = add <8 x i64> %128, %270
  %287 = extractvalue { ptr, i64 } %19, 0
  %288 = select <8 x i1> %261, <8 x i64> %286, <8 x i64> zeroinitializer
  %289 = extractelement <8 x i64> %288, i32 %268
  %290 = zext i32 %268 to i64
  %291 = sub i64 %289, %290
  %292 = mul i64 %291, 4
  %buffer.contiguous.address112 = getelementptr i8, ptr %287, i64 %292
  %buffer.contiguous.load113 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address112, <8 x i1> %261, <8 x float> zeroinitializer)
  %293 = extractvalue { ptr, i64 } %25, 0
  %294 = select <8 x i1> %261, <8 x i64> %286, <8 x i64> zeroinitializer
  %295 = extractelement <8 x i64> %294, i32 %268
  %296 = zext i32 %268 to i64
  %297 = sub i64 %295, %296
  %298 = mul i64 %297, 4
  %buffer.contiguous.address114 = getelementptr i8, ptr %293, i64 %298
  %buffer.contiguous.load115 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address114, <8 x i1> %261, <8 x float> zeroinitializer)
  %299 = fmul <8 x float> %buffer.contiguous.load109, %buffer.contiguous.load113
  %300 = fmul <8 x float> %buffer.contiguous.load111, %buffer.contiguous.load115
  %301 = fsub <8 x float> %299, %300
  %302 = extractvalue { ptr, i64 } %31, 0
  %303 = extractelement <8 x i64> %271, i32 %268
  %304 = zext i32 %268 to i64
  %305 = sub i64 %303, %304
  %306 = mul i64 %305, 4
  %buffer.contiguous.address116 = getelementptr i8, ptr %302, i64 %306
  call void @llvm.masked.store.v8f32.p0(<8 x float> %301, ptr align 1 %buffer.contiguous.address116, <8 x i1> %261)
  %307 = fmul <8 x float> %buffer.contiguous.load109, %buffer.contiguous.load115
  %308 = fmul <8 x float> %buffer.contiguous.load111, %buffer.contiguous.load113
  %309 = fadd <8 x float> %307, %308
  %310 = extractvalue { ptr, i64 } %31, 0
  %311 = extractelement <8 x i64> %279, i32 %268
  %312 = zext i32 %268 to i64
  %313 = sub i64 %311, %312
  %314 = mul i64 %313, 4
  %buffer.contiguous.address117 = getelementptr i8, ptr %310, i64 %314
  call void @llvm.masked.store.v8f32.p0(<8 x float> %309, ptr align 1 %buffer.contiguous.address117, <8 x i1> %261)
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %263)
  %316 = bitcast <8 x i1> %263 to i8
  %317 = call i8 @llvm.cttz.i8(i8 %316, i1 false)
  %318 = zext i8 %317 to i32
  %319 = select i1 %315, i32 %318, i32 0
  br label %direct.schedule.3

direct.schedule.3:                                ; preds = %direct.schedule.14, %direct.schedule.1
  ret void

direct.schedule.4:                                ; preds = %direct.false
  %320 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %320, 0
  %323 = select <8 x i1> %55, <8 x ptr> %321, <8 x ptr> %322
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %325 = extractvalue { <8 x ptr>, <8 x i64> } %320, 1
  %326 = select <8 x i1> %55, <8 x i64> %324, <8 x i64> %325
  %327 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %323, 0
  %328 = insertvalue { <8 x ptr>, <8 x i64> } %327, <8 x i64> %326, 1
  store { <8 x ptr>, <8 x i64> } %328, ptr %tile_snapshot.spill, align 64
  %.spill.load118 = load <8 x i64>, ptr %.spill, align 64
  %329 = add <8 x i64> zeroinitializer, %.spill.load118
  %330 = load <8 x i64>, ptr %.spill11, align 64
  %331 = select <8 x i1> %55, <8 x i64> %329, <8 x i64> %330
  store <8 x i64> %331, ptr %.spill11, align 64
  %.spill.load119 = load <8 x i64>, ptr %.spill10, align 64
  %332 = add <8 x i64> %.spill.load119, zeroinitializer
  %333 = add <8 x i64> zeroinitializer, %332
  %334 = load <8 x i64>, ptr %.spill12, align 64
  %335 = select <8 x i1> %55, <8 x i64> %333, <8 x i64> %334
  store <8 x i64> %335, ptr %.spill12, align 64
  %336 = add <8 x i64> zeroinitializer, %329
  %337 = load <8 x i64>, ptr %.spill13, align 64
  %338 = select <8 x i1> %55, <8 x i64> %336, <8 x i64> %337
  store <8 x i64> %338, ptr %.spill13, align 64
  %339 = mul <8 x i64> %333, splat (i64 66)
  %340 = load <8 x i64>, ptr %.spill14, align 64
  %341 = select <8 x i1> %55, <8 x i64> %339, <8 x i64> %340
  store <8 x i64> %341, ptr %.spill14, align 64
  %342 = add <8 x i64> %339, %336
  %343 = load <8 x i64>, ptr %.spill15, align 64
  %344 = select <8 x i1> %55, <8 x i64> %342, <8 x i64> %343
  store <8 x i64> %344, ptr %.spill15, align 64
  %345 = extractvalue { ptr, i64 } %13, 0
  %346 = extractelement <8 x i64> %342, i32 0
  %347 = sub i64 %346, 0
  %348 = mul i64 %347, 4
  %buffer.contiguous.address120 = getelementptr i8, ptr %345, i64 %348
  %buffer.contiguous.load121 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address120, <8 x i1> %55, <8 x float> zeroinitializer)
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %351 = add <8 x i64> %350, zeroinitializer
  %352 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %349, 0
  %353 = insertvalue { <8 x ptr>, <8 x i64> } %352, <8 x i64> %351, 1
  %354 = load { <8 x ptr>, <8 x i64> }, ptr %.spill16, align 64
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %353, 0
  %356 = extractvalue { <8 x ptr>, <8 x i64> } %354, 0
  %357 = select <8 x i1> %55, <8 x ptr> %355, <8 x ptr> %356
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %353, 1
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %354, 1
  %360 = select <8 x i1> %55, <8 x i64> %358, <8 x i64> %359
  %361 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %357, 0
  %362 = insertvalue { <8 x ptr>, <8 x i64> } %361, <8 x i64> %360, 1
  store { <8 x ptr>, <8 x i64> } %362, ptr %.spill16, align 64
  %363 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %364 = extractvalue { <8 x ptr>, <8 x i64> } %353, 1
  %365 = extractelement <8 x ptr> %363, i32 0
  %366 = extractelement <8 x i64> %364, i32 0
  %367 = sub i64 %366, 0
  %368 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %369 = select i1 %368, i64 %367, i64 0
  %private.contiguous.address = getelementptr i8, ptr %365, i64 %369
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %370 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load121, <8 x float> %private.contiguous.preserve
  store <8 x float> %370, ptr %private.contiguous.address, align 4
  %.spill.load122 = load <8 x i64>, ptr %.spill, align 64
  %371 = add <8 x i64> splat (i64 8), %.spill.load122
  %372 = load <8 x i64>, ptr %.spill17, align 64
  %373 = select <8 x i1> %55, <8 x i64> %371, <8 x i64> %372
  store <8 x i64> %373, ptr %.spill17, align 64
  %374 = add <8 x i64> zeroinitializer, %371
  %375 = load <8 x i64>, ptr %.spill18, align 64
  %376 = select <8 x i1> %55, <8 x i64> %374, <8 x i64> %375
  store <8 x i64> %376, ptr %.spill18, align 64
  %377 = add <8 x i64> %339, %374
  %378 = load <8 x i64>, ptr %.spill19, align 64
  %379 = select <8 x i1> %55, <8 x i64> %377, <8 x i64> %378
  store <8 x i64> %379, ptr %.spill19, align 64
  %380 = extractvalue { ptr, i64 } %13, 0
  %381 = extractelement <8 x i64> %377, i32 0
  %382 = sub i64 %381, 0
  %383 = mul i64 %382, 4
  %buffer.contiguous.address123 = getelementptr i8, ptr %380, i64 %383
  %buffer.contiguous.load124 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address123, <8 x i1> %55, <8 x float> zeroinitializer)
  %384 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %386 = add <8 x i64> %385, splat (i64 32)
  %387 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %384, 0
  %388 = insertvalue { <8 x ptr>, <8 x i64> } %387, <8 x i64> %386, 1
  %389 = load { <8 x ptr>, <8 x i64> }, ptr %.spill20, align 64
  %390 = extractvalue { <8 x ptr>, <8 x i64> } %388, 0
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %389, 0
  %392 = select <8 x i1> %55, <8 x ptr> %390, <8 x ptr> %391
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %388, 1
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %389, 1
  %395 = select <8 x i1> %55, <8 x i64> %393, <8 x i64> %394
  %396 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %392, 0
  %397 = insertvalue { <8 x ptr>, <8 x i64> } %396, <8 x i64> %395, 1
  store { <8 x ptr>, <8 x i64> } %397, ptr %.spill20, align 64
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %388, 1
  %400 = extractelement <8 x ptr> %398, i32 0
  %401 = extractelement <8 x i64> %399, i32 0
  %402 = sub i64 %401, 0
  %403 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %404 = select i1 %403, i64 %402, i64 0
  %private.contiguous.address125 = getelementptr i8, ptr %400, i64 %404
  %private.contiguous.preserve126 = load <8 x float>, ptr %private.contiguous.address125, align 4
  %405 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load124, <8 x float> %private.contiguous.preserve126
  store <8 x float> %405, ptr %private.contiguous.address125, align 4
  %.spill.load127 = load <8 x i64>, ptr %.spill, align 64
  %406 = add <8 x i64> splat (i64 16), %.spill.load127
  %407 = load <8 x i64>, ptr %.spill21, align 64
  %408 = select <8 x i1> %55, <8 x i64> %406, <8 x i64> %407
  store <8 x i64> %408, ptr %.spill21, align 64
  %409 = add <8 x i64> zeroinitializer, %406
  %410 = load <8 x i64>, ptr %.spill22, align 64
  %411 = select <8 x i1> %55, <8 x i64> %409, <8 x i64> %410
  store <8 x i64> %411, ptr %.spill22, align 64
  %412 = add <8 x i64> %339, %409
  %413 = load <8 x i64>, ptr %.spill23, align 64
  %414 = select <8 x i1> %55, <8 x i64> %412, <8 x i64> %413
  store <8 x i64> %414, ptr %.spill23, align 64
  %415 = extractvalue { ptr, i64 } %13, 0
  %416 = extractelement <8 x i64> %412, i32 0
  %417 = sub i64 %416, 0
  %418 = mul i64 %417, 4
  %buffer.contiguous.address128 = getelementptr i8, ptr %415, i64 %418
  %buffer.contiguous.load129 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address128, <8 x i1> %55, <8 x float> zeroinitializer)
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %420 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %421 = add <8 x i64> %420, splat (i64 64)
  %422 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %419, 0
  %423 = insertvalue { <8 x ptr>, <8 x i64> } %422, <8 x i64> %421, 1
  %424 = load { <8 x ptr>, <8 x i64> }, ptr %.spill24, align 64
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %423, 0
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %424, 0
  %427 = select <8 x i1> %55, <8 x ptr> %425, <8 x ptr> %426
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %423, 1
  %429 = extractvalue { <8 x ptr>, <8 x i64> } %424, 1
  %430 = select <8 x i1> %55, <8 x i64> %428, <8 x i64> %429
  %431 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %427, 0
  %432 = insertvalue { <8 x ptr>, <8 x i64> } %431, <8 x i64> %430, 1
  store { <8 x ptr>, <8 x i64> } %432, ptr %.spill24, align 64
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %434 = extractvalue { <8 x ptr>, <8 x i64> } %423, 1
  %435 = extractelement <8 x ptr> %433, i32 0
  %436 = extractelement <8 x i64> %434, i32 0
  %437 = sub i64 %436, 0
  %438 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %439 = select i1 %438, i64 %437, i64 0
  %private.contiguous.address130 = getelementptr i8, ptr %435, i64 %439
  %private.contiguous.preserve131 = load <8 x float>, ptr %private.contiguous.address130, align 4
  %440 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load129, <8 x float> %private.contiguous.preserve131
  store <8 x float> %440, ptr %private.contiguous.address130, align 4
  %.spill.load132 = load <8 x i64>, ptr %.spill, align 64
  %441 = add <8 x i64> splat (i64 24), %.spill.load132
  %442 = load <8 x i64>, ptr %.spill25, align 64
  %443 = select <8 x i1> %55, <8 x i64> %441, <8 x i64> %442
  store <8 x i64> %443, ptr %.spill25, align 64
  %444 = add <8 x i64> zeroinitializer, %441
  %445 = load <8 x i64>, ptr %.spill26, align 64
  %446 = select <8 x i1> %55, <8 x i64> %444, <8 x i64> %445
  store <8 x i64> %446, ptr %.spill26, align 64
  %447 = add <8 x i64> %339, %444
  %448 = load <8 x i64>, ptr %.spill27, align 64
  %449 = select <8 x i1> %55, <8 x i64> %447, <8 x i64> %448
  store <8 x i64> %449, ptr %.spill27, align 64
  %450 = extractvalue { ptr, i64 } %13, 0
  %451 = extractelement <8 x i64> %447, i32 0
  %452 = sub i64 %451, 0
  %453 = mul i64 %452, 4
  %buffer.contiguous.address133 = getelementptr i8, ptr %450, i64 %453
  %buffer.contiguous.load134 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address133, <8 x i1> %55, <8 x float> zeroinitializer)
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %455 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %456 = add <8 x i64> %455, splat (i64 96)
  %457 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %454, 0
  %458 = insertvalue { <8 x ptr>, <8 x i64> } %457, <8 x i64> %456, 1
  %459 = load { <8 x ptr>, <8 x i64> }, ptr %.spill28, align 64
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %458, 0
  %461 = extractvalue { <8 x ptr>, <8 x i64> } %459, 0
  %462 = select <8 x i1> %55, <8 x ptr> %460, <8 x ptr> %461
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %458, 1
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %459, 1
  %465 = select <8 x i1> %55, <8 x i64> %463, <8 x i64> %464
  %466 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %462, 0
  %467 = insertvalue { <8 x ptr>, <8 x i64> } %466, <8 x i64> %465, 1
  store { <8 x ptr>, <8 x i64> } %467, ptr %.spill28, align 64
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %458, 1
  %470 = extractelement <8 x ptr> %468, i32 0
  %471 = extractelement <8 x i64> %469, i32 0
  %472 = sub i64 %471, 0
  %473 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %474 = select i1 %473, i64 %472, i64 0
  %private.contiguous.address135 = getelementptr i8, ptr %470, i64 %474
  %private.contiguous.preserve136 = load <8 x float>, ptr %private.contiguous.address135, align 4
  %475 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load134, <8 x float> %private.contiguous.preserve136
  store <8 x float> %475, ptr %private.contiguous.address135, align 4
  %.spill.load137 = load <8 x i64>, ptr %.spill, align 64
  %476 = icmp slt <8 x i64> %.spill.load137, splat (i64 1)
  %477 = load <8 x i1>, ptr %.spill29, align 1
  %478 = select <8 x i1> %55, <8 x i1> %476, <8 x i1> %477
  store <8 x i1> %478, ptr %.spill29, align 1
  %479 = and <8 x i1> %55, %476
  %480 = xor <8 x i1> %476, splat (i1 true)
  %481 = and <8 x i1> %55, %480
  %482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %479)
  %483 = bitcast <8 x i1> %479 to i8
  %484 = call i8 @llvm.cttz.i8(i8 %483, i1 false)
  %485 = zext i8 %484 to i32
  %486 = select i1 %482, i32 %485, i32 0
  %.spill.load138 = load <8 x i64>, ptr %.spill, align 64
  %487 = add <8 x i64> splat (i64 32), %.spill.load138
  %488 = add <8 x i64> zeroinitializer, %487
  %489 = add <8 x i64> %339, %488
  %490 = extractvalue { ptr, i64 } %13, 0
  %491 = select <8 x i1> %479, <8 x i64> %489, <8 x i64> zeroinitializer
  %492 = extractelement <8 x i64> %491, i32 %486
  %493 = zext i32 %486 to i64
  %494 = sub i64 %492, %493
  %495 = mul i64 %494, 4
  %buffer.contiguous.address139 = getelementptr i8, ptr %490, i64 %495
  %buffer.contiguous.load140 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address139, <8 x i1> %479, <8 x float> zeroinitializer)
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %497 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %498 = add <8 x i64> %497, splat (i64 128)
  %499 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %496, 0
  %500 = insertvalue { <8 x ptr>, <8 x i64> } %499, <8 x i64> %498, 1
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %502 = extractvalue { <8 x ptr>, <8 x i64> } %500, 1
  %503 = extractelement <8 x ptr> %501, i32 0
  %504 = extractelement <8 x i64> %502, i32 %486
  %505 = zext i32 %486 to i64
  %506 = mul i64 %505, 4
  %507 = sub i64 %504, %506
  %508 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %479)
  %509 = select i1 %508, i64 %507, i64 0
  %private.contiguous.address141 = getelementptr i8, ptr %503, i64 %509
  %private.contiguous.preserve142 = load <8 x float>, ptr %private.contiguous.address141, align 4
  %510 = select <8 x i1> %479, <8 x float> %buffer.contiguous.load140, <8 x float> %private.contiguous.preserve142
  store <8 x float> %510, ptr %private.contiguous.address141, align 4
  %511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %481)
  %512 = bitcast <8 x i1> %481 to i8
  %513 = call i8 @llvm.cttz.i8(i8 %512, i1 false)
  %514 = zext i8 %513 to i32
  %515 = select i1 %511, i32 %514, i32 0
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.4
  %516 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %516, 0
  %519 = select <8 x i1> %55, <8 x ptr> %517, <8 x ptr> %518
  %520 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %521 = extractvalue { <8 x ptr>, <8 x i64> } %516, 1
  %522 = select <8 x i1> %55, <8 x i64> %520, <8 x i64> %521
  %523 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %519, 0
  %524 = insertvalue { <8 x ptr>, <8 x i64> } %523, <8 x i64> %522, 1
  store { <8 x ptr>, <8 x i64> } %524, ptr %tile_snapshot.spill30, align 64
  %.spill.load143 = load <8 x i64>, ptr %.spill11, align 64
  %525 = add <8 x i64> splat (i64 33), %.spill.load143
  %.spill.load144 = load <8 x i64>, ptr %.spill14, align 64
  %526 = add <8 x i64> %.spill.load144, %525
  %527 = load <8 x i64>, ptr %.spill31, align 64
  %528 = select <8 x i1> %55, <8 x i64> %526, <8 x i64> %527
  store <8 x i64> %528, ptr %.spill31, align 64
  %529 = extractvalue { ptr, i64 } %13, 0
  %530 = extractelement <8 x i64> %526, i32 0
  %531 = sub i64 %530, 0
  %532 = mul i64 %531, 4
  %buffer.contiguous.address145 = getelementptr i8, ptr %529, i64 %532
  %buffer.contiguous.load146 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address145, <8 x i1> %55, <8 x float> zeroinitializer)
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %535 = add <8 x i64> %534, zeroinitializer
  %536 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %533, 0
  %537 = insertvalue { <8 x ptr>, <8 x i64> } %536, <8 x i64> %535, 1
  %538 = load { <8 x ptr>, <8 x i64> }, ptr %.spill32, align 64
  %539 = extractvalue { <8 x ptr>, <8 x i64> } %537, 0
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %538, 0
  %541 = select <8 x i1> %55, <8 x ptr> %539, <8 x ptr> %540
  %542 = extractvalue { <8 x ptr>, <8 x i64> } %537, 1
  %543 = extractvalue { <8 x ptr>, <8 x i64> } %538, 1
  %544 = select <8 x i1> %55, <8 x i64> %542, <8 x i64> %543
  %545 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %541, 0
  %546 = insertvalue { <8 x ptr>, <8 x i64> } %545, <8 x i64> %544, 1
  store { <8 x ptr>, <8 x i64> } %546, ptr %.spill32, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %537, 1
  %549 = extractelement <8 x ptr> %547, i32 0
  %550 = extractelement <8 x i64> %548, i32 0
  %551 = sub i64 %550, 0
  %552 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %553 = select i1 %552, i64 %551, i64 0
  %private.contiguous.address147 = getelementptr i8, ptr %549, i64 %553
  %private.contiguous.preserve148 = load <8 x float>, ptr %private.contiguous.address147, align 4
  %554 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load146, <8 x float> %private.contiguous.preserve148
  store <8 x float> %554, ptr %private.contiguous.address147, align 4
  %.spill.load149 = load <8 x i64>, ptr %.spill17, align 64
  %555 = add <8 x i64> splat (i64 33), %.spill.load149
  %.spill.load150 = load <8 x i64>, ptr %.spill14, align 64
  %556 = add <8 x i64> %.spill.load150, %555
  %557 = load <8 x i64>, ptr %.spill33, align 64
  %558 = select <8 x i1> %55, <8 x i64> %556, <8 x i64> %557
  store <8 x i64> %558, ptr %.spill33, align 64
  %559 = extractvalue { ptr, i64 } %13, 0
  %560 = extractelement <8 x i64> %556, i32 0
  %561 = sub i64 %560, 0
  %562 = mul i64 %561, 4
  %buffer.contiguous.address151 = getelementptr i8, ptr %559, i64 %562
  %buffer.contiguous.load152 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address151, <8 x i1> %55, <8 x float> zeroinitializer)
  %563 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %564 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %565 = add <8 x i64> %564, splat (i64 32)
  %566 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %563, 0
  %567 = insertvalue { <8 x ptr>, <8 x i64> } %566, <8 x i64> %565, 1
  %568 = load { <8 x ptr>, <8 x i64> }, ptr %.spill34, align 64
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %567, 0
  %570 = extractvalue { <8 x ptr>, <8 x i64> } %568, 0
  %571 = select <8 x i1> %55, <8 x ptr> %569, <8 x ptr> %570
  %572 = extractvalue { <8 x ptr>, <8 x i64> } %567, 1
  %573 = extractvalue { <8 x ptr>, <8 x i64> } %568, 1
  %574 = select <8 x i1> %55, <8 x i64> %572, <8 x i64> %573
  %575 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %571, 0
  %576 = insertvalue { <8 x ptr>, <8 x i64> } %575, <8 x i64> %574, 1
  store { <8 x ptr>, <8 x i64> } %576, ptr %.spill34, align 64
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %578 = extractvalue { <8 x ptr>, <8 x i64> } %567, 1
  %579 = extractelement <8 x ptr> %577, i32 0
  %580 = extractelement <8 x i64> %578, i32 0
  %581 = sub i64 %580, 0
  %582 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %583 = select i1 %582, i64 %581, i64 0
  %private.contiguous.address153 = getelementptr i8, ptr %579, i64 %583
  %private.contiguous.preserve154 = load <8 x float>, ptr %private.contiguous.address153, align 4
  %584 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load152, <8 x float> %private.contiguous.preserve154
  store <8 x float> %584, ptr %private.contiguous.address153, align 4
  %.spill.load155 = load <8 x i64>, ptr %.spill21, align 64
  %585 = add <8 x i64> splat (i64 33), %.spill.load155
  %.spill.load156 = load <8 x i64>, ptr %.spill14, align 64
  %586 = add <8 x i64> %.spill.load156, %585
  %587 = load <8 x i64>, ptr %.spill35, align 64
  %588 = select <8 x i1> %55, <8 x i64> %586, <8 x i64> %587
  store <8 x i64> %588, ptr %.spill35, align 64
  %589 = extractvalue { ptr, i64 } %13, 0
  %590 = extractelement <8 x i64> %586, i32 0
  %591 = sub i64 %590, 0
  %592 = mul i64 %591, 4
  %buffer.contiguous.address157 = getelementptr i8, ptr %589, i64 %592
  %buffer.contiguous.load158 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address157, <8 x i1> %55, <8 x float> zeroinitializer)
  %593 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %594 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %595 = add <8 x i64> %594, splat (i64 64)
  %596 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %593, 0
  %597 = insertvalue { <8 x ptr>, <8 x i64> } %596, <8 x i64> %595, 1
  %598 = load { <8 x ptr>, <8 x i64> }, ptr %.spill36, align 64
  %599 = extractvalue { <8 x ptr>, <8 x i64> } %597, 0
  %600 = extractvalue { <8 x ptr>, <8 x i64> } %598, 0
  %601 = select <8 x i1> %55, <8 x ptr> %599, <8 x ptr> %600
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %597, 1
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %598, 1
  %604 = select <8 x i1> %55, <8 x i64> %602, <8 x i64> %603
  %605 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %601, 0
  %606 = insertvalue { <8 x ptr>, <8 x i64> } %605, <8 x i64> %604, 1
  store { <8 x ptr>, <8 x i64> } %606, ptr %.spill36, align 64
  %607 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %597, 1
  %609 = extractelement <8 x ptr> %607, i32 0
  %610 = extractelement <8 x i64> %608, i32 0
  %611 = sub i64 %610, 0
  %612 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %613 = select i1 %612, i64 %611, i64 0
  %private.contiguous.address159 = getelementptr i8, ptr %609, i64 %613
  %private.contiguous.preserve160 = load <8 x float>, ptr %private.contiguous.address159, align 4
  %614 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load158, <8 x float> %private.contiguous.preserve160
  store <8 x float> %614, ptr %private.contiguous.address159, align 4
  %.spill.load161 = load <8 x i64>, ptr %.spill25, align 64
  %615 = add <8 x i64> splat (i64 33), %.spill.load161
  %.spill.load162 = load <8 x i64>, ptr %.spill14, align 64
  %616 = add <8 x i64> %.spill.load162, %615
  %617 = load <8 x i64>, ptr %.spill37, align 64
  %618 = select <8 x i1> %55, <8 x i64> %616, <8 x i64> %617
  store <8 x i64> %618, ptr %.spill37, align 64
  %619 = extractvalue { ptr, i64 } %13, 0
  %620 = extractelement <8 x i64> %616, i32 0
  %621 = sub i64 %620, 0
  %622 = mul i64 %621, 4
  %buffer.contiguous.address163 = getelementptr i8, ptr %619, i64 %622
  %buffer.contiguous.load164 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address163, <8 x i1> %55, <8 x float> zeroinitializer)
  %623 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %624 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %625 = add <8 x i64> %624, splat (i64 96)
  %626 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %623, 0
  %627 = insertvalue { <8 x ptr>, <8 x i64> } %626, <8 x i64> %625, 1
  %628 = load { <8 x ptr>, <8 x i64> }, ptr %.spill38, align 64
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %627, 0
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %628, 0
  %631 = select <8 x i1> %55, <8 x ptr> %629, <8 x ptr> %630
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %627, 1
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %628, 1
  %634 = select <8 x i1> %55, <8 x i64> %632, <8 x i64> %633
  %635 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %631, 0
  %636 = insertvalue { <8 x ptr>, <8 x i64> } %635, <8 x i64> %634, 1
  store { <8 x ptr>, <8 x i64> } %636, ptr %.spill38, align 64
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %627, 1
  %639 = extractelement <8 x ptr> %637, i32 0
  %640 = extractelement <8 x i64> %638, i32 0
  %641 = sub i64 %640, 0
  %642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %643 = select i1 %642, i64 %641, i64 0
  %private.contiguous.address165 = getelementptr i8, ptr %639, i64 %643
  %private.contiguous.preserve166 = load <8 x float>, ptr %private.contiguous.address165, align 4
  %644 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load164, <8 x float> %private.contiguous.preserve166
  store <8 x float> %644, ptr %private.contiguous.address165, align 4
  %.spill.load167 = load <8 x i1>, ptr %.spill29, align 1
  %645 = and <8 x i1> %55, %.spill.load167
  %646 = xor <8 x i1> %.spill.load167, splat (i1 true)
  %647 = and <8 x i1> %55, %646
  %648 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %645)
  %649 = bitcast <8 x i1> %645 to i8
  %650 = call i8 @llvm.cttz.i8(i8 %649, i1 false)
  %651 = zext i8 %650 to i32
  %652 = select i1 %648, i32 %651, i32 0
  %.spill.load168 = load <8 x i64>, ptr %.spill, align 64
  %653 = add <8 x i64> splat (i64 32), %.spill.load168
  %654 = add <8 x i64> splat (i64 33), %653
  %.spill.load169 = load <8 x i64>, ptr %.spill14, align 64
  %655 = add <8 x i64> %.spill.load169, %654
  %656 = extractvalue { ptr, i64 } %13, 0
  %657 = select <8 x i1> %645, <8 x i64> %655, <8 x i64> zeroinitializer
  %658 = extractelement <8 x i64> %657, i32 %652
  %659 = zext i32 %652 to i64
  %660 = sub i64 %658, %659
  %661 = mul i64 %660, 4
  %buffer.contiguous.address170 = getelementptr i8, ptr %656, i64 %661
  %buffer.contiguous.load171 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address170, <8 x i1> %645, <8 x float> zeroinitializer)
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %664 = add <8 x i64> %663, splat (i64 128)
  %665 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %662, 0
  %666 = insertvalue { <8 x ptr>, <8 x i64> } %665, <8 x i64> %664, 1
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %666, 1
  %669 = extractelement <8 x ptr> %667, i32 0
  %670 = extractelement <8 x i64> %668, i32 %652
  %671 = zext i32 %652 to i64
  %672 = mul i64 %671, 4
  %673 = sub i64 %670, %672
  %674 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %645)
  %675 = select i1 %674, i64 %673, i64 0
  %private.contiguous.address172 = getelementptr i8, ptr %669, i64 %675
  %private.contiguous.preserve173 = load <8 x float>, ptr %private.contiguous.address172, align 4
  %676 = select <8 x i1> %645, <8 x float> %buffer.contiguous.load171, <8 x float> %private.contiguous.preserve173
  store <8 x float> %676, ptr %private.contiguous.address172, align 4
  %677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %647)
  %678 = bitcast <8 x i1> %647 to i8
  %679 = call i8 @llvm.cttz.i8(i8 %678, i1 false)
  %680 = zext i8 %679 to i32
  %681 = select i1 %677, i32 %680, i32 0
  br label %direct.schedule.8

direct.schedule.8:                                ; preds = %direct.schedule.6
  %682 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %683 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %682, 0
  %685 = select <8 x i1> %55, <8 x ptr> %683, <8 x ptr> %684
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %682, 1
  %688 = select <8 x i1> %55, <8 x i64> %686, <8 x i64> %687
  %689 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %685, 0
  %690 = insertvalue { <8 x ptr>, <8 x i64> } %689, <8 x i64> %688, 1
  store { <8 x ptr>, <8 x i64> } %690, ptr %tile_snapshot.spill39, align 64
  %.spill.load174 = load <8 x i64>, ptr %.spill12, align 64
  %691 = mul <8 x i64> %.spill.load174, splat (i64 33)
  %692 = load <8 x i64>, ptr %.spill40, align 64
  %693 = select <8 x i1> %55, <8 x i64> %691, <8 x i64> %692
  store <8 x i64> %693, ptr %.spill40, align 64
  %.spill.load175 = load <8 x i64>, ptr %.spill13, align 64
  %694 = add <8 x i64> %691, %.spill.load175
  %695 = load <8 x i64>, ptr %.spill41, align 64
  %696 = select <8 x i1> %55, <8 x i64> %694, <8 x i64> %695
  store <8 x i64> %696, ptr %.spill41, align 64
  %697 = extractvalue { ptr, i64 } %19, 0
  %698 = extractelement <8 x i64> %694, i32 0
  %699 = sub i64 %698, 0
  %700 = mul i64 %699, 4
  %buffer.contiguous.address176 = getelementptr i8, ptr %697, i64 %700
  %buffer.contiguous.load177 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address176, <8 x i1> %55, <8 x float> zeroinitializer)
  %701 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %702 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %703 = add <8 x i64> %702, zeroinitializer
  %704 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %701, 0
  %705 = insertvalue { <8 x ptr>, <8 x i64> } %704, <8 x i64> %703, 1
  %706 = load { <8 x ptr>, <8 x i64> }, ptr %.spill42, align 64
  %707 = extractvalue { <8 x ptr>, <8 x i64> } %705, 0
  %708 = extractvalue { <8 x ptr>, <8 x i64> } %706, 0
  %709 = select <8 x i1> %55, <8 x ptr> %707, <8 x ptr> %708
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %705, 1
  %711 = extractvalue { <8 x ptr>, <8 x i64> } %706, 1
  %712 = select <8 x i1> %55, <8 x i64> %710, <8 x i64> %711
  %713 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %709, 0
  %714 = insertvalue { <8 x ptr>, <8 x i64> } %713, <8 x i64> %712, 1
  store { <8 x ptr>, <8 x i64> } %714, ptr %.spill42, align 64
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %705, 1
  %717 = extractelement <8 x ptr> %715, i32 0
  %718 = extractelement <8 x i64> %716, i32 0
  %719 = sub i64 %718, 0
  %720 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %721 = select i1 %720, i64 %719, i64 0
  %private.contiguous.address178 = getelementptr i8, ptr %717, i64 %721
  %private.contiguous.preserve179 = load <8 x float>, ptr %private.contiguous.address178, align 4
  %722 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load177, <8 x float> %private.contiguous.preserve179
  store <8 x float> %722, ptr %private.contiguous.address178, align 4
  %.spill.load180 = load <8 x i64>, ptr %.spill18, align 64
  %723 = add <8 x i64> %691, %.spill.load180
  %724 = load <8 x i64>, ptr %.spill43, align 64
  %725 = select <8 x i1> %55, <8 x i64> %723, <8 x i64> %724
  store <8 x i64> %725, ptr %.spill43, align 64
  %726 = extractvalue { ptr, i64 } %19, 0
  %727 = extractelement <8 x i64> %723, i32 0
  %728 = sub i64 %727, 0
  %729 = mul i64 %728, 4
  %buffer.contiguous.address181 = getelementptr i8, ptr %726, i64 %729
  %buffer.contiguous.load182 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address181, <8 x i1> %55, <8 x float> zeroinitializer)
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %731 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %732 = add <8 x i64> %731, splat (i64 32)
  %733 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %730, 0
  %734 = insertvalue { <8 x ptr>, <8 x i64> } %733, <8 x i64> %732, 1
  %735 = load { <8 x ptr>, <8 x i64> }, ptr %.spill44, align 64
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %734, 0
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %735, 0
  %738 = select <8 x i1> %55, <8 x ptr> %736, <8 x ptr> %737
  %739 = extractvalue { <8 x ptr>, <8 x i64> } %734, 1
  %740 = extractvalue { <8 x ptr>, <8 x i64> } %735, 1
  %741 = select <8 x i1> %55, <8 x i64> %739, <8 x i64> %740
  %742 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %738, 0
  %743 = insertvalue { <8 x ptr>, <8 x i64> } %742, <8 x i64> %741, 1
  store { <8 x ptr>, <8 x i64> } %743, ptr %.spill44, align 64
  %744 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %734, 1
  %746 = extractelement <8 x ptr> %744, i32 0
  %747 = extractelement <8 x i64> %745, i32 0
  %748 = sub i64 %747, 0
  %749 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %750 = select i1 %749, i64 %748, i64 0
  %private.contiguous.address183 = getelementptr i8, ptr %746, i64 %750
  %private.contiguous.preserve184 = load <8 x float>, ptr %private.contiguous.address183, align 4
  %751 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load182, <8 x float> %private.contiguous.preserve184
  store <8 x float> %751, ptr %private.contiguous.address183, align 4
  %.spill.load185 = load <8 x i64>, ptr %.spill22, align 64
  %752 = add <8 x i64> %691, %.spill.load185
  %753 = load <8 x i64>, ptr %.spill45, align 64
  %754 = select <8 x i1> %55, <8 x i64> %752, <8 x i64> %753
  store <8 x i64> %754, ptr %.spill45, align 64
  %755 = extractvalue { ptr, i64 } %19, 0
  %756 = extractelement <8 x i64> %752, i32 0
  %757 = sub i64 %756, 0
  %758 = mul i64 %757, 4
  %buffer.contiguous.address186 = getelementptr i8, ptr %755, i64 %758
  %buffer.contiguous.load187 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address186, <8 x i1> %55, <8 x float> zeroinitializer)
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %761 = add <8 x i64> %760, splat (i64 64)
  %762 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %759, 0
  %763 = insertvalue { <8 x ptr>, <8 x i64> } %762, <8 x i64> %761, 1
  %764 = load { <8 x ptr>, <8 x i64> }, ptr %.spill46, align 64
  %765 = extractvalue { <8 x ptr>, <8 x i64> } %763, 0
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %764, 0
  %767 = select <8 x i1> %55, <8 x ptr> %765, <8 x ptr> %766
  %768 = extractvalue { <8 x ptr>, <8 x i64> } %763, 1
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %764, 1
  %770 = select <8 x i1> %55, <8 x i64> %768, <8 x i64> %769
  %771 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %767, 0
  %772 = insertvalue { <8 x ptr>, <8 x i64> } %771, <8 x i64> %770, 1
  store { <8 x ptr>, <8 x i64> } %772, ptr %.spill46, align 64
  %773 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %774 = extractvalue { <8 x ptr>, <8 x i64> } %763, 1
  %775 = extractelement <8 x ptr> %773, i32 0
  %776 = extractelement <8 x i64> %774, i32 0
  %777 = sub i64 %776, 0
  %778 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %779 = select i1 %778, i64 %777, i64 0
  %private.contiguous.address188 = getelementptr i8, ptr %775, i64 %779
  %private.contiguous.preserve189 = load <8 x float>, ptr %private.contiguous.address188, align 4
  %780 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load187, <8 x float> %private.contiguous.preserve189
  store <8 x float> %780, ptr %private.contiguous.address188, align 4
  %.spill.load190 = load <8 x i64>, ptr %.spill26, align 64
  %781 = add <8 x i64> %691, %.spill.load190
  %782 = load <8 x i64>, ptr %.spill47, align 64
  %783 = select <8 x i1> %55, <8 x i64> %781, <8 x i64> %782
  store <8 x i64> %783, ptr %.spill47, align 64
  %784 = extractvalue { ptr, i64 } %19, 0
  %785 = extractelement <8 x i64> %781, i32 0
  %786 = sub i64 %785, 0
  %787 = mul i64 %786, 4
  %buffer.contiguous.address191 = getelementptr i8, ptr %784, i64 %787
  %buffer.contiguous.load192 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address191, <8 x i1> %55, <8 x float> zeroinitializer)
  %788 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %790 = add <8 x i64> %789, splat (i64 96)
  %791 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %788, 0
  %792 = insertvalue { <8 x ptr>, <8 x i64> } %791, <8 x i64> %790, 1
  %793 = load { <8 x ptr>, <8 x i64> }, ptr %.spill48, align 64
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %792, 0
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %793, 0
  %796 = select <8 x i1> %55, <8 x ptr> %794, <8 x ptr> %795
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %792, 1
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %793, 1
  %799 = select <8 x i1> %55, <8 x i64> %797, <8 x i64> %798
  %800 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %796, 0
  %801 = insertvalue { <8 x ptr>, <8 x i64> } %800, <8 x i64> %799, 1
  store { <8 x ptr>, <8 x i64> } %801, ptr %.spill48, align 64
  %802 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %803 = extractvalue { <8 x ptr>, <8 x i64> } %792, 1
  %804 = extractelement <8 x ptr> %802, i32 0
  %805 = extractelement <8 x i64> %803, i32 0
  %806 = sub i64 %805, 0
  %807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %808 = select i1 %807, i64 %806, i64 0
  %private.contiguous.address193 = getelementptr i8, ptr %804, i64 %808
  %private.contiguous.preserve194 = load <8 x float>, ptr %private.contiguous.address193, align 4
  %809 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load192, <8 x float> %private.contiguous.preserve194
  store <8 x float> %809, ptr %private.contiguous.address193, align 4
  %.spill.load195 = load <8 x i1>, ptr %.spill29, align 1
  %810 = and <8 x i1> %55, %.spill.load195
  %811 = xor <8 x i1> %.spill.load195, splat (i1 true)
  %812 = and <8 x i1> %55, %811
  %813 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %810)
  %814 = bitcast <8 x i1> %810 to i8
  %815 = call i8 @llvm.cttz.i8(i8 %814, i1 false)
  %816 = zext i8 %815 to i32
  %817 = select i1 %813, i32 %816, i32 0
  %.spill.load196 = load <8 x i64>, ptr %.spill, align 64
  %818 = add <8 x i64> splat (i64 32), %.spill.load196
  %819 = add <8 x i64> zeroinitializer, %818
  %820 = add <8 x i64> %691, %819
  %821 = extractvalue { ptr, i64 } %19, 0
  %822 = select <8 x i1> %810, <8 x i64> %820, <8 x i64> zeroinitializer
  %823 = extractelement <8 x i64> %822, i32 %817
  %824 = zext i32 %817 to i64
  %825 = sub i64 %823, %824
  %826 = mul i64 %825, 4
  %buffer.contiguous.address197 = getelementptr i8, ptr %821, i64 %826
  %buffer.contiguous.load198 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address197, <8 x i1> %810, <8 x float> zeroinitializer)
  %827 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %829 = add <8 x i64> %828, splat (i64 128)
  %830 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %827, 0
  %831 = insertvalue { <8 x ptr>, <8 x i64> } %830, <8 x i64> %829, 1
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %833 = extractvalue { <8 x ptr>, <8 x i64> } %831, 1
  %834 = extractelement <8 x ptr> %832, i32 0
  %835 = extractelement <8 x i64> %833, i32 %817
  %836 = zext i32 %817 to i64
  %837 = mul i64 %836, 4
  %838 = sub i64 %835, %837
  %839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %810)
  %840 = select i1 %839, i64 %838, i64 0
  %private.contiguous.address199 = getelementptr i8, ptr %834, i64 %840
  %private.contiguous.preserve200 = load <8 x float>, ptr %private.contiguous.address199, align 4
  %841 = select <8 x i1> %810, <8 x float> %buffer.contiguous.load198, <8 x float> %private.contiguous.preserve200
  store <8 x float> %841, ptr %private.contiguous.address199, align 4
  %842 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %812)
  %843 = bitcast <8 x i1> %812 to i8
  %844 = call i8 @llvm.cttz.i8(i8 %843, i1 false)
  %845 = zext i8 %844 to i32
  %846 = select i1 %842, i32 %845, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %847 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill49, align 64
  %848 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %847, 0
  %850 = select <8 x i1> %55, <8 x ptr> %848, <8 x ptr> %849
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %852 = extractvalue { <8 x ptr>, <8 x i64> } %847, 1
  %853 = select <8 x i1> %55, <8 x i64> %851, <8 x i64> %852
  %854 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %850, 0
  %855 = insertvalue { <8 x ptr>, <8 x i64> } %854, <8 x i64> %853, 1
  store { <8 x ptr>, <8 x i64> } %855, ptr %tile_snapshot.spill49, align 64
  %.spill.load201 = load <8 x i64>, ptr %.spill41, align 64
  %856 = extractvalue { ptr, i64 } %25, 0
  %857 = extractelement <8 x i64> %.spill.load201, i32 0
  %858 = sub i64 %857, 0
  %859 = mul i64 %858, 4
  %buffer.contiguous.address202 = getelementptr i8, ptr %856, i64 %859
  %buffer.contiguous.load203 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address202, <8 x i1> %55, <8 x float> zeroinitializer)
  %860 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %861 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %862 = add <8 x i64> %861, zeroinitializer
  %863 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %860, 0
  %864 = insertvalue { <8 x ptr>, <8 x i64> } %863, <8 x i64> %862, 1
  %865 = load { <8 x ptr>, <8 x i64> }, ptr %.spill50, align 64
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %864, 0
  %867 = extractvalue { <8 x ptr>, <8 x i64> } %865, 0
  %868 = select <8 x i1> %55, <8 x ptr> %866, <8 x ptr> %867
  %869 = extractvalue { <8 x ptr>, <8 x i64> } %864, 1
  %870 = extractvalue { <8 x ptr>, <8 x i64> } %865, 1
  %871 = select <8 x i1> %55, <8 x i64> %869, <8 x i64> %870
  %872 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %868, 0
  %873 = insertvalue { <8 x ptr>, <8 x i64> } %872, <8 x i64> %871, 1
  store { <8 x ptr>, <8 x i64> } %873, ptr %.spill50, align 64
  %874 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %875 = extractvalue { <8 x ptr>, <8 x i64> } %864, 1
  %876 = extractelement <8 x ptr> %874, i32 0
  %877 = extractelement <8 x i64> %875, i32 0
  %878 = sub i64 %877, 0
  %879 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %880 = select i1 %879, i64 %878, i64 0
  %private.contiguous.address204 = getelementptr i8, ptr %876, i64 %880
  %private.contiguous.preserve205 = load <8 x float>, ptr %private.contiguous.address204, align 4
  %881 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load203, <8 x float> %private.contiguous.preserve205
  store <8 x float> %881, ptr %private.contiguous.address204, align 4
  %.spill.load206 = load <8 x i64>, ptr %.spill43, align 64
  %882 = extractvalue { ptr, i64 } %25, 0
  %883 = extractelement <8 x i64> %.spill.load206, i32 0
  %884 = sub i64 %883, 0
  %885 = mul i64 %884, 4
  %buffer.contiguous.address207 = getelementptr i8, ptr %882, i64 %885
  %buffer.contiguous.load208 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address207, <8 x i1> %55, <8 x float> zeroinitializer)
  %886 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %887 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %888 = add <8 x i64> %887, splat (i64 32)
  %889 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %886, 0
  %890 = insertvalue { <8 x ptr>, <8 x i64> } %889, <8 x i64> %888, 1
  %891 = load { <8 x ptr>, <8 x i64> }, ptr %.spill51, align 64
  %892 = extractvalue { <8 x ptr>, <8 x i64> } %890, 0
  %893 = extractvalue { <8 x ptr>, <8 x i64> } %891, 0
  %894 = select <8 x i1> %55, <8 x ptr> %892, <8 x ptr> %893
  %895 = extractvalue { <8 x ptr>, <8 x i64> } %890, 1
  %896 = extractvalue { <8 x ptr>, <8 x i64> } %891, 1
  %897 = select <8 x i1> %55, <8 x i64> %895, <8 x i64> %896
  %898 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %894, 0
  %899 = insertvalue { <8 x ptr>, <8 x i64> } %898, <8 x i64> %897, 1
  store { <8 x ptr>, <8 x i64> } %899, ptr %.spill51, align 64
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %901 = extractvalue { <8 x ptr>, <8 x i64> } %890, 1
  %902 = extractelement <8 x ptr> %900, i32 0
  %903 = extractelement <8 x i64> %901, i32 0
  %904 = sub i64 %903, 0
  %905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %906 = select i1 %905, i64 %904, i64 0
  %private.contiguous.address209 = getelementptr i8, ptr %902, i64 %906
  %private.contiguous.preserve210 = load <8 x float>, ptr %private.contiguous.address209, align 4
  %907 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load208, <8 x float> %private.contiguous.preserve210
  store <8 x float> %907, ptr %private.contiguous.address209, align 4
  %.spill.load211 = load <8 x i64>, ptr %.spill45, align 64
  %908 = extractvalue { ptr, i64 } %25, 0
  %909 = extractelement <8 x i64> %.spill.load211, i32 0
  %910 = sub i64 %909, 0
  %911 = mul i64 %910, 4
  %buffer.contiguous.address212 = getelementptr i8, ptr %908, i64 %911
  %buffer.contiguous.load213 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address212, <8 x i1> %55, <8 x float> zeroinitializer)
  %912 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %913 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %914 = add <8 x i64> %913, splat (i64 64)
  %915 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %912, 0
  %916 = insertvalue { <8 x ptr>, <8 x i64> } %915, <8 x i64> %914, 1
  %917 = load { <8 x ptr>, <8 x i64> }, ptr %.spill52, align 64
  %918 = extractvalue { <8 x ptr>, <8 x i64> } %916, 0
  %919 = extractvalue { <8 x ptr>, <8 x i64> } %917, 0
  %920 = select <8 x i1> %55, <8 x ptr> %918, <8 x ptr> %919
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %916, 1
  %922 = extractvalue { <8 x ptr>, <8 x i64> } %917, 1
  %923 = select <8 x i1> %55, <8 x i64> %921, <8 x i64> %922
  %924 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %920, 0
  %925 = insertvalue { <8 x ptr>, <8 x i64> } %924, <8 x i64> %923, 1
  store { <8 x ptr>, <8 x i64> } %925, ptr %.spill52, align 64
  %926 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %927 = extractvalue { <8 x ptr>, <8 x i64> } %916, 1
  %928 = extractelement <8 x ptr> %926, i32 0
  %929 = extractelement <8 x i64> %927, i32 0
  %930 = sub i64 %929, 0
  %931 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %932 = select i1 %931, i64 %930, i64 0
  %private.contiguous.address214 = getelementptr i8, ptr %928, i64 %932
  %private.contiguous.preserve215 = load <8 x float>, ptr %private.contiguous.address214, align 4
  %933 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load213, <8 x float> %private.contiguous.preserve215
  store <8 x float> %933, ptr %private.contiguous.address214, align 4
  %.spill.load216 = load <8 x i64>, ptr %.spill47, align 64
  %934 = extractvalue { ptr, i64 } %25, 0
  %935 = extractelement <8 x i64> %.spill.load216, i32 0
  %936 = sub i64 %935, 0
  %937 = mul i64 %936, 4
  %buffer.contiguous.address217 = getelementptr i8, ptr %934, i64 %937
  %buffer.contiguous.load218 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address217, <8 x i1> %55, <8 x float> zeroinitializer)
  %938 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %939 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %940 = add <8 x i64> %939, splat (i64 96)
  %941 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %938, 0
  %942 = insertvalue { <8 x ptr>, <8 x i64> } %941, <8 x i64> %940, 1
  %943 = load { <8 x ptr>, <8 x i64> }, ptr %.spill53, align 64
  %944 = extractvalue { <8 x ptr>, <8 x i64> } %942, 0
  %945 = extractvalue { <8 x ptr>, <8 x i64> } %943, 0
  %946 = select <8 x i1> %55, <8 x ptr> %944, <8 x ptr> %945
  %947 = extractvalue { <8 x ptr>, <8 x i64> } %942, 1
  %948 = extractvalue { <8 x ptr>, <8 x i64> } %943, 1
  %949 = select <8 x i1> %55, <8 x i64> %947, <8 x i64> %948
  %950 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %946, 0
  %951 = insertvalue { <8 x ptr>, <8 x i64> } %950, <8 x i64> %949, 1
  store { <8 x ptr>, <8 x i64> } %951, ptr %.spill53, align 64
  %952 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %953 = extractvalue { <8 x ptr>, <8 x i64> } %942, 1
  %954 = extractelement <8 x ptr> %952, i32 0
  %955 = extractelement <8 x i64> %953, i32 0
  %956 = sub i64 %955, 0
  %957 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %958 = select i1 %957, i64 %956, i64 0
  %private.contiguous.address219 = getelementptr i8, ptr %954, i64 %958
  %private.contiguous.preserve220 = load <8 x float>, ptr %private.contiguous.address219, align 4
  %959 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load218, <8 x float> %private.contiguous.preserve220
  store <8 x float> %959, ptr %private.contiguous.address219, align 4
  %.spill.load221 = load <8 x i1>, ptr %.spill29, align 1
  %960 = and <8 x i1> %55, %.spill.load221
  %961 = xor <8 x i1> %.spill.load221, splat (i1 true)
  %962 = and <8 x i1> %55, %961
  %963 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %960)
  %964 = bitcast <8 x i1> %960 to i8
  %965 = call i8 @llvm.cttz.i8(i8 %964, i1 false)
  %966 = zext i8 %965 to i32
  %967 = select i1 %963, i32 %966, i32 0
  %.spill.load222 = load <8 x i64>, ptr %.spill, align 64
  %968 = add <8 x i64> splat (i64 32), %.spill.load222
  %969 = add <8 x i64> zeroinitializer, %968
  %.spill.load223 = load <8 x i64>, ptr %.spill40, align 64
  %970 = add <8 x i64> %.spill.load223, %969
  %971 = extractvalue { ptr, i64 } %25, 0
  %972 = select <8 x i1> %960, <8 x i64> %970, <8 x i64> zeroinitializer
  %973 = extractelement <8 x i64> %972, i32 %967
  %974 = zext i32 %967 to i64
  %975 = sub i64 %973, %974
  %976 = mul i64 %975, 4
  %buffer.contiguous.address224 = getelementptr i8, ptr %971, i64 %976
  %buffer.contiguous.load225 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address224, <8 x i1> %960, <8 x float> zeroinitializer)
  %977 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %978 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %979 = add <8 x i64> %978, splat (i64 128)
  %980 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %977, 0
  %981 = insertvalue { <8 x ptr>, <8 x i64> } %980, <8 x i64> %979, 1
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %983 = extractvalue { <8 x ptr>, <8 x i64> } %981, 1
  %984 = extractelement <8 x ptr> %982, i32 0
  %985 = extractelement <8 x i64> %983, i32 %967
  %986 = zext i32 %967 to i64
  %987 = mul i64 %986, 4
  %988 = sub i64 %985, %987
  %989 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %960)
  %990 = select i1 %989, i64 %988, i64 0
  %private.contiguous.address226 = getelementptr i8, ptr %984, i64 %990
  %private.contiguous.preserve227 = load <8 x float>, ptr %private.contiguous.address226, align 4
  %991 = select <8 x i1> %960, <8 x float> %buffer.contiguous.load225, <8 x float> %private.contiguous.preserve227
  store <8 x float> %991, ptr %private.contiguous.address226, align 4
  %992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %962)
  %993 = bitcast <8 x i1> %962 to i8
  %994 = call i8 @llvm.cttz.i8(i8 %993, i1 false)
  %995 = zext i8 %994 to i32
  %996 = select i1 %992, i32 %995, i32 0
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.10
  %.spill.load228 = load { <8 x ptr>, <8 x i64> }, ptr %.spill16, align 64
  %997 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load228, 1
  %999 = extractelement <8 x ptr> %997, i32 0
  %1000 = extractelement <8 x i64> %998, i32 0
  %1001 = sub i64 %1000, 0
  %1002 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1003 = select i1 %1002, i64 %1001, i64 0
  %private.contiguous.address229 = getelementptr i8, ptr %999, i64 %1003
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address229, align 4
  %1004 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load230 = load { <8 x ptr>, <8 x i64> }, ptr %.spill42, align 64
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load230, 1
  %1007 = extractelement <8 x ptr> %1005, i32 0
  %1008 = extractelement <8 x i64> %1006, i32 0
  %1009 = sub i64 %1008, 0
  %1010 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1011 = select i1 %1010, i64 %1009, i64 0
  %private.contiguous.address231 = getelementptr i8, ptr %1007, i64 %1011
  %private.contiguous.load232 = load <8 x float>, ptr %private.contiguous.address231, align 4
  %1012 = select <8 x i1> %55, <8 x float> %private.contiguous.load232, <8 x float> zeroinitializer
  %1013 = fmul <8 x float> %1004, %1012
  %.spill.load233 = load { <8 x ptr>, <8 x i64> }, ptr %.spill32, align 64
  %1014 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load233, 1
  %1016 = extractelement <8 x ptr> %1014, i32 0
  %1017 = extractelement <8 x i64> %1015, i32 0
  %1018 = sub i64 %1017, 0
  %1019 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1020 = select i1 %1019, i64 %1018, i64 0
  %private.contiguous.address234 = getelementptr i8, ptr %1016, i64 %1020
  %private.contiguous.load235 = load <8 x float>, ptr %private.contiguous.address234, align 4
  %1021 = select <8 x i1> %55, <8 x float> %private.contiguous.load235, <8 x float> zeroinitializer
  %.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %.spill50, align 64
  %1022 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load236, 1
  %1024 = extractelement <8 x ptr> %1022, i32 0
  %1025 = extractelement <8 x i64> %1023, i32 0
  %1026 = sub i64 %1025, 0
  %1027 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1028 = select i1 %1027, i64 %1026, i64 0
  %private.contiguous.address237 = getelementptr i8, ptr %1024, i64 %1028
  %private.contiguous.load238 = load <8 x float>, ptr %private.contiguous.address237, align 4
  %1029 = select <8 x i1> %55, <8 x float> %private.contiguous.load238, <8 x float> zeroinitializer
  %1030 = fmul <8 x float> %1021, %1029
  %1031 = fsub <8 x float> %1013, %1030
  %.spill.load239 = load <8 x i64>, ptr %.spill15, align 64
  %1032 = extractvalue { ptr, i64 } %31, 0
  %1033 = extractelement <8 x i64> %.spill.load239, i32 0
  %1034 = sub i64 %1033, 0
  %1035 = mul i64 %1034, 4
  %buffer.contiguous.address240 = getelementptr i8, ptr %1032, i64 %1035
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1031, ptr align 1 %buffer.contiguous.address240, <8 x i1> %55)
  %.spill.load241 = load { <8 x ptr>, <8 x i64> }, ptr %.spill20, align 64
  %1036 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load241, 1
  %1038 = extractelement <8 x ptr> %1036, i32 0
  %1039 = extractelement <8 x i64> %1037, i32 0
  %1040 = sub i64 %1039, 0
  %1041 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1042 = select i1 %1041, i64 %1040, i64 0
  %private.contiguous.address242 = getelementptr i8, ptr %1038, i64 %1042
  %private.contiguous.load243 = load <8 x float>, ptr %private.contiguous.address242, align 4
  %1043 = select <8 x i1> %55, <8 x float> %private.contiguous.load243, <8 x float> zeroinitializer
  %.spill.load244 = load { <8 x ptr>, <8 x i64> }, ptr %.spill44, align 64
  %1044 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1045 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load244, 1
  %1046 = extractelement <8 x ptr> %1044, i32 0
  %1047 = extractelement <8 x i64> %1045, i32 0
  %1048 = sub i64 %1047, 0
  %1049 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1050 = select i1 %1049, i64 %1048, i64 0
  %private.contiguous.address245 = getelementptr i8, ptr %1046, i64 %1050
  %private.contiguous.load246 = load <8 x float>, ptr %private.contiguous.address245, align 4
  %1051 = select <8 x i1> %55, <8 x float> %private.contiguous.load246, <8 x float> zeroinitializer
  %1052 = fmul <8 x float> %1043, %1051
  %.spill.load247 = load { <8 x ptr>, <8 x i64> }, ptr %.spill34, align 64
  %1053 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1054 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load247, 1
  %1055 = extractelement <8 x ptr> %1053, i32 0
  %1056 = extractelement <8 x i64> %1054, i32 0
  %1057 = sub i64 %1056, 0
  %1058 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1059 = select i1 %1058, i64 %1057, i64 0
  %private.contiguous.address248 = getelementptr i8, ptr %1055, i64 %1059
  %private.contiguous.load249 = load <8 x float>, ptr %private.contiguous.address248, align 4
  %1060 = select <8 x i1> %55, <8 x float> %private.contiguous.load249, <8 x float> zeroinitializer
  %.spill.load250 = load { <8 x ptr>, <8 x i64> }, ptr %.spill51, align 64
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load250, 1
  %1063 = extractelement <8 x ptr> %1061, i32 0
  %1064 = extractelement <8 x i64> %1062, i32 0
  %1065 = sub i64 %1064, 0
  %1066 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1067 = select i1 %1066, i64 %1065, i64 0
  %private.contiguous.address251 = getelementptr i8, ptr %1063, i64 %1067
  %private.contiguous.load252 = load <8 x float>, ptr %private.contiguous.address251, align 4
  %1068 = select <8 x i1> %55, <8 x float> %private.contiguous.load252, <8 x float> zeroinitializer
  %1069 = fmul <8 x float> %1060, %1068
  %1070 = fsub <8 x float> %1052, %1069
  %.spill.load253 = load <8 x i64>, ptr %.spill19, align 64
  %1071 = extractvalue { ptr, i64 } %31, 0
  %1072 = extractelement <8 x i64> %.spill.load253, i32 0
  %1073 = sub i64 %1072, 0
  %1074 = mul i64 %1073, 4
  %buffer.contiguous.address254 = getelementptr i8, ptr %1071, i64 %1074
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1070, ptr align 1 %buffer.contiguous.address254, <8 x i1> %55)
  %.spill.load255 = load { <8 x ptr>, <8 x i64> }, ptr %.spill24, align 64
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load255, 1
  %1077 = extractelement <8 x ptr> %1075, i32 0
  %1078 = extractelement <8 x i64> %1076, i32 0
  %1079 = sub i64 %1078, 0
  %1080 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1081 = select i1 %1080, i64 %1079, i64 0
  %private.contiguous.address256 = getelementptr i8, ptr %1077, i64 %1081
  %private.contiguous.load257 = load <8 x float>, ptr %private.contiguous.address256, align 4
  %1082 = select <8 x i1> %55, <8 x float> %private.contiguous.load257, <8 x float> zeroinitializer
  %.spill.load258 = load { <8 x ptr>, <8 x i64> }, ptr %.spill46, align 64
  %1083 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1084 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load258, 1
  %1085 = extractelement <8 x ptr> %1083, i32 0
  %1086 = extractelement <8 x i64> %1084, i32 0
  %1087 = sub i64 %1086, 0
  %1088 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1089 = select i1 %1088, i64 %1087, i64 0
  %private.contiguous.address259 = getelementptr i8, ptr %1085, i64 %1089
  %private.contiguous.load260 = load <8 x float>, ptr %private.contiguous.address259, align 4
  %1090 = select <8 x i1> %55, <8 x float> %private.contiguous.load260, <8 x float> zeroinitializer
  %1091 = fmul <8 x float> %1082, %1090
  %.spill.load261 = load { <8 x ptr>, <8 x i64> }, ptr %.spill36, align 64
  %1092 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load261, 1
  %1094 = extractelement <8 x ptr> %1092, i32 0
  %1095 = extractelement <8 x i64> %1093, i32 0
  %1096 = sub i64 %1095, 0
  %1097 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1098 = select i1 %1097, i64 %1096, i64 0
  %private.contiguous.address262 = getelementptr i8, ptr %1094, i64 %1098
  %private.contiguous.load263 = load <8 x float>, ptr %private.contiguous.address262, align 4
  %1099 = select <8 x i1> %55, <8 x float> %private.contiguous.load263, <8 x float> zeroinitializer
  %.spill.load264 = load { <8 x ptr>, <8 x i64> }, ptr %.spill52, align 64
  %1100 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load264, 1
  %1102 = extractelement <8 x ptr> %1100, i32 0
  %1103 = extractelement <8 x i64> %1101, i32 0
  %1104 = sub i64 %1103, 0
  %1105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1106 = select i1 %1105, i64 %1104, i64 0
  %private.contiguous.address265 = getelementptr i8, ptr %1102, i64 %1106
  %private.contiguous.load266 = load <8 x float>, ptr %private.contiguous.address265, align 4
  %1107 = select <8 x i1> %55, <8 x float> %private.contiguous.load266, <8 x float> zeroinitializer
  %1108 = fmul <8 x float> %1099, %1107
  %1109 = fsub <8 x float> %1091, %1108
  %.spill.load267 = load <8 x i64>, ptr %.spill23, align 64
  %1110 = extractvalue { ptr, i64 } %31, 0
  %1111 = extractelement <8 x i64> %.spill.load267, i32 0
  %1112 = sub i64 %1111, 0
  %1113 = mul i64 %1112, 4
  %buffer.contiguous.address268 = getelementptr i8, ptr %1110, i64 %1113
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1109, ptr align 1 %buffer.contiguous.address268, <8 x i1> %55)
  %.spill.load269 = load { <8 x ptr>, <8 x i64> }, ptr %.spill28, align 64
  %1114 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load269, 1
  %1116 = extractelement <8 x ptr> %1114, i32 0
  %1117 = extractelement <8 x i64> %1115, i32 0
  %1118 = sub i64 %1117, 0
  %1119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1120 = select i1 %1119, i64 %1118, i64 0
  %private.contiguous.address270 = getelementptr i8, ptr %1116, i64 %1120
  %private.contiguous.load271 = load <8 x float>, ptr %private.contiguous.address270, align 4
  %1121 = select <8 x i1> %55, <8 x float> %private.contiguous.load271, <8 x float> zeroinitializer
  %.spill.load272 = load { <8 x ptr>, <8 x i64> }, ptr %.spill48, align 64
  %1122 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1123 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load272, 1
  %1124 = extractelement <8 x ptr> %1122, i32 0
  %1125 = extractelement <8 x i64> %1123, i32 0
  %1126 = sub i64 %1125, 0
  %1127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1128 = select i1 %1127, i64 %1126, i64 0
  %private.contiguous.address273 = getelementptr i8, ptr %1124, i64 %1128
  %private.contiguous.load274 = load <8 x float>, ptr %private.contiguous.address273, align 4
  %1129 = select <8 x i1> %55, <8 x float> %private.contiguous.load274, <8 x float> zeroinitializer
  %1130 = fmul <8 x float> %1121, %1129
  %.spill.load275 = load { <8 x ptr>, <8 x i64> }, ptr %.spill38, align 64
  %1131 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load275, 1
  %1133 = extractelement <8 x ptr> %1131, i32 0
  %1134 = extractelement <8 x i64> %1132, i32 0
  %1135 = sub i64 %1134, 0
  %1136 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1137 = select i1 %1136, i64 %1135, i64 0
  %private.contiguous.address276 = getelementptr i8, ptr %1133, i64 %1137
  %private.contiguous.load277 = load <8 x float>, ptr %private.contiguous.address276, align 4
  %1138 = select <8 x i1> %55, <8 x float> %private.contiguous.load277, <8 x float> zeroinitializer
  %.spill.load278 = load { <8 x ptr>, <8 x i64> }, ptr %.spill53, align 64
  %1139 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load278, 1
  %1141 = extractelement <8 x ptr> %1139, i32 0
  %1142 = extractelement <8 x i64> %1140, i32 0
  %1143 = sub i64 %1142, 0
  %1144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1145 = select i1 %1144, i64 %1143, i64 0
  %private.contiguous.address279 = getelementptr i8, ptr %1141, i64 %1145
  %private.contiguous.load280 = load <8 x float>, ptr %private.contiguous.address279, align 4
  %1146 = select <8 x i1> %55, <8 x float> %private.contiguous.load280, <8 x float> zeroinitializer
  %1147 = fmul <8 x float> %1138, %1146
  %1148 = fsub <8 x float> %1130, %1147
  %.spill.load281 = load <8 x i64>, ptr %.spill27, align 64
  %1149 = extractvalue { ptr, i64 } %31, 0
  %1150 = extractelement <8 x i64> %.spill.load281, i32 0
  %1151 = sub i64 %1150, 0
  %1152 = mul i64 %1151, 4
  %buffer.contiguous.address282 = getelementptr i8, ptr %1149, i64 %1152
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1148, ptr align 1 %buffer.contiguous.address282, <8 x i1> %55)
  %.spill.load283 = load <8 x i1>, ptr %.spill29, align 1
  %1153 = and <8 x i1> %55, %.spill.load283
  %1154 = xor <8 x i1> %.spill.load283, splat (i1 true)
  %1155 = and <8 x i1> %55, %1154
  %1156 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1153)
  %1157 = bitcast <8 x i1> %1153 to i8
  %1158 = call i8 @llvm.cttz.i8(i8 %1157, i1 false)
  %1159 = zext i8 %1158 to i32
  %1160 = select i1 %1156, i32 %1159, i32 0
  %.spill.load284 = load <8 x i64>, ptr %.spill, align 64
  %1161 = add <8 x i64> splat (i64 32), %.spill.load284
  %1162 = add <8 x i64> zeroinitializer, %1161
  %.spill.load285 = load <8 x i64>, ptr %.spill14, align 64
  %1163 = add <8 x i64> %.spill.load285, %1162
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1164 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %1165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %1166 = add <8 x i64> %1165, splat (i64 128)
  %1167 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1164, 0
  %1168 = insertvalue { <8 x ptr>, <8 x i64> } %1167, <8 x i64> %1166, 1
  %1169 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1170 = extractvalue { <8 x ptr>, <8 x i64> } %1168, 1
  %1171 = extractelement <8 x ptr> %1169, i32 0
  %1172 = extractelement <8 x i64> %1170, i32 %1160
  %1173 = zext i32 %1160 to i64
  %1174 = mul i64 %1173, 4
  %1175 = sub i64 %1172, %1174
  %1176 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1153)
  %1177 = select i1 %1176, i64 %1175, i64 0
  %private.contiguous.address286 = getelementptr i8, ptr %1171, i64 %1177
  %private.contiguous.load287 = load <8 x float>, ptr %private.contiguous.address286, align 4
  %1178 = select <8 x i1> %1153, <8 x float> %private.contiguous.load287, <8 x float> zeroinitializer
  %tile_snapshot.spill.load288 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1179 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 0
  %1180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 1
  %1181 = add <8 x i64> %1180, splat (i64 128)
  %1182 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1179, 0
  %1183 = insertvalue { <8 x ptr>, <8 x i64> } %1182, <8 x i64> %1181, 1
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %1183, 1
  %1186 = extractelement <8 x ptr> %1184, i32 0
  %1187 = extractelement <8 x i64> %1185, i32 %1160
  %1188 = zext i32 %1160 to i64
  %1189 = mul i64 %1188, 4
  %1190 = sub i64 %1187, %1189
  %1191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1153)
  %1192 = select i1 %1191, i64 %1190, i64 0
  %private.contiguous.address289 = getelementptr i8, ptr %1186, i64 %1192
  %private.contiguous.load290 = load <8 x float>, ptr %private.contiguous.address289, align 4
  %1193 = select <8 x i1> %1153, <8 x float> %private.contiguous.load290, <8 x float> zeroinitializer
  %1194 = fmul <8 x float> %1178, %1193
  %tile_snapshot.spill.load291 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %1195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 0
  %1196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 1
  %1197 = add <8 x i64> %1196, splat (i64 128)
  %1198 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1195, 0
  %1199 = insertvalue { <8 x ptr>, <8 x i64> } %1198, <8 x i64> %1197, 1
  %1200 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1201 = extractvalue { <8 x ptr>, <8 x i64> } %1199, 1
  %1202 = extractelement <8 x ptr> %1200, i32 0
  %1203 = extractelement <8 x i64> %1201, i32 %1160
  %1204 = zext i32 %1160 to i64
  %1205 = mul i64 %1204, 4
  %1206 = sub i64 %1203, %1205
  %1207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1153)
  %1208 = select i1 %1207, i64 %1206, i64 0
  %private.contiguous.address292 = getelementptr i8, ptr %1202, i64 %1208
  %private.contiguous.load293 = load <8 x float>, ptr %private.contiguous.address292, align 4
  %1209 = select <8 x i1> %1153, <8 x float> %private.contiguous.load293, <8 x float> zeroinitializer
  %tile_snapshot.spill.load294 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill49, align 64
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 0
  %1211 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 1
  %1212 = add <8 x i64> %1211, splat (i64 128)
  %1213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1210, 0
  %1214 = insertvalue { <8 x ptr>, <8 x i64> } %1213, <8 x i64> %1212, 1
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1216 = extractvalue { <8 x ptr>, <8 x i64> } %1214, 1
  %1217 = extractelement <8 x ptr> %1215, i32 0
  %1218 = extractelement <8 x i64> %1216, i32 %1160
  %1219 = zext i32 %1160 to i64
  %1220 = mul i64 %1219, 4
  %1221 = sub i64 %1218, %1220
  %1222 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1153)
  %1223 = select i1 %1222, i64 %1221, i64 0
  %private.contiguous.address295 = getelementptr i8, ptr %1217, i64 %1223
  %private.contiguous.load296 = load <8 x float>, ptr %private.contiguous.address295, align 4
  %1224 = select <8 x i1> %1153, <8 x float> %private.contiguous.load296, <8 x float> zeroinitializer
  %1225 = fmul <8 x float> %1209, %1224
  %1226 = fsub <8 x float> %1194, %1225
  %1227 = extractvalue { ptr, i64 } %31, 0
  %1228 = extractelement <8 x i64> %1163, i32 %1160
  %1229 = zext i32 %1160 to i64
  %1230 = sub i64 %1228, %1229
  %1231 = mul i64 %1230, 4
  %buffer.contiguous.address297 = getelementptr i8, ptr %1227, i64 %1231
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1226, ptr align 1 %buffer.contiguous.address297, <8 x i1> %1153)
  %1232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1155)
  %1233 = bitcast <8 x i1> %1155 to i8
  %1234 = call i8 @llvm.cttz.i8(i8 %1233, i1 false)
  %1235 = zext i8 %1234 to i32
  %1236 = select i1 %1232, i32 %1235, i32 0
  br label %direct.schedule.14

direct.schedule.14:                               ; preds = %direct.schedule.12
  %.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %.spill16, align 64
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1238 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load298, 1
  %1239 = extractelement <8 x ptr> %1237, i32 0
  %1240 = extractelement <8 x i64> %1238, i32 0
  %1241 = sub i64 %1240, 0
  %1242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1243 = select i1 %1242, i64 %1241, i64 0
  %private.contiguous.address299 = getelementptr i8, ptr %1239, i64 %1243
  %private.contiguous.load300 = load <8 x float>, ptr %private.contiguous.address299, align 4
  %1244 = select <8 x i1> %55, <8 x float> %private.contiguous.load300, <8 x float> zeroinitializer
  %.spill.load301 = load { <8 x ptr>, <8 x i64> }, ptr %.spill50, align 64
  %1245 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1246 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load301, 1
  %1247 = extractelement <8 x ptr> %1245, i32 0
  %1248 = extractelement <8 x i64> %1246, i32 0
  %1249 = sub i64 %1248, 0
  %1250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1251 = select i1 %1250, i64 %1249, i64 0
  %private.contiguous.address302 = getelementptr i8, ptr %1247, i64 %1251
  %private.contiguous.load303 = load <8 x float>, ptr %private.contiguous.address302, align 4
  %1252 = select <8 x i1> %55, <8 x float> %private.contiguous.load303, <8 x float> zeroinitializer
  %1253 = fmul <8 x float> %1244, %1252
  %.spill.load304 = load { <8 x ptr>, <8 x i64> }, ptr %.spill32, align 64
  %1254 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1255 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load304, 1
  %1256 = extractelement <8 x ptr> %1254, i32 0
  %1257 = extractelement <8 x i64> %1255, i32 0
  %1258 = sub i64 %1257, 0
  %1259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1260 = select i1 %1259, i64 %1258, i64 0
  %private.contiguous.address305 = getelementptr i8, ptr %1256, i64 %1260
  %private.contiguous.load306 = load <8 x float>, ptr %private.contiguous.address305, align 4
  %1261 = select <8 x i1> %55, <8 x float> %private.contiguous.load306, <8 x float> zeroinitializer
  %.spill.load307 = load { <8 x ptr>, <8 x i64> }, ptr %.spill42, align 64
  %1262 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load307, 1
  %1264 = extractelement <8 x ptr> %1262, i32 0
  %1265 = extractelement <8 x i64> %1263, i32 0
  %1266 = sub i64 %1265, 0
  %1267 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1268 = select i1 %1267, i64 %1266, i64 0
  %private.contiguous.address308 = getelementptr i8, ptr %1264, i64 %1268
  %private.contiguous.load309 = load <8 x float>, ptr %private.contiguous.address308, align 4
  %1269 = select <8 x i1> %55, <8 x float> %private.contiguous.load309, <8 x float> zeroinitializer
  %1270 = fmul <8 x float> %1261, %1269
  %1271 = fadd <8 x float> %1253, %1270
  %.spill.load310 = load <8 x i64>, ptr %.spill31, align 64
  %1272 = extractvalue { ptr, i64 } %31, 0
  %1273 = extractelement <8 x i64> %.spill.load310, i32 0
  %1274 = sub i64 %1273, 0
  %1275 = mul i64 %1274, 4
  %buffer.contiguous.address311 = getelementptr i8, ptr %1272, i64 %1275
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1271, ptr align 1 %buffer.contiguous.address311, <8 x i1> %55)
  %.spill.load312 = load { <8 x ptr>, <8 x i64> }, ptr %.spill20, align 64
  %1276 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1277 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load312, 1
  %1278 = extractelement <8 x ptr> %1276, i32 0
  %1279 = extractelement <8 x i64> %1277, i32 0
  %1280 = sub i64 %1279, 0
  %1281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1282 = select i1 %1281, i64 %1280, i64 0
  %private.contiguous.address313 = getelementptr i8, ptr %1278, i64 %1282
  %private.contiguous.load314 = load <8 x float>, ptr %private.contiguous.address313, align 4
  %1283 = select <8 x i1> %55, <8 x float> %private.contiguous.load314, <8 x float> zeroinitializer
  %.spill.load315 = load { <8 x ptr>, <8 x i64> }, ptr %.spill51, align 64
  %1284 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1285 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load315, 1
  %1286 = extractelement <8 x ptr> %1284, i32 0
  %1287 = extractelement <8 x i64> %1285, i32 0
  %1288 = sub i64 %1287, 0
  %1289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1290 = select i1 %1289, i64 %1288, i64 0
  %private.contiguous.address316 = getelementptr i8, ptr %1286, i64 %1290
  %private.contiguous.load317 = load <8 x float>, ptr %private.contiguous.address316, align 4
  %1291 = select <8 x i1> %55, <8 x float> %private.contiguous.load317, <8 x float> zeroinitializer
  %1292 = fmul <8 x float> %1283, %1291
  %.spill.load318 = load { <8 x ptr>, <8 x i64> }, ptr %.spill34, align 64
  %1293 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1294 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load318, 1
  %1295 = extractelement <8 x ptr> %1293, i32 0
  %1296 = extractelement <8 x i64> %1294, i32 0
  %1297 = sub i64 %1296, 0
  %1298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1299 = select i1 %1298, i64 %1297, i64 0
  %private.contiguous.address319 = getelementptr i8, ptr %1295, i64 %1299
  %private.contiguous.load320 = load <8 x float>, ptr %private.contiguous.address319, align 4
  %1300 = select <8 x i1> %55, <8 x float> %private.contiguous.load320, <8 x float> zeroinitializer
  %.spill.load321 = load { <8 x ptr>, <8 x i64> }, ptr %.spill44, align 64
  %1301 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load321, 1
  %1303 = extractelement <8 x ptr> %1301, i32 0
  %1304 = extractelement <8 x i64> %1302, i32 0
  %1305 = sub i64 %1304, 0
  %1306 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1307 = select i1 %1306, i64 %1305, i64 0
  %private.contiguous.address322 = getelementptr i8, ptr %1303, i64 %1307
  %private.contiguous.load323 = load <8 x float>, ptr %private.contiguous.address322, align 4
  %1308 = select <8 x i1> %55, <8 x float> %private.contiguous.load323, <8 x float> zeroinitializer
  %1309 = fmul <8 x float> %1300, %1308
  %1310 = fadd <8 x float> %1292, %1309
  %.spill.load324 = load <8 x i64>, ptr %.spill33, align 64
  %1311 = extractvalue { ptr, i64 } %31, 0
  %1312 = extractelement <8 x i64> %.spill.load324, i32 0
  %1313 = sub i64 %1312, 0
  %1314 = mul i64 %1313, 4
  %buffer.contiguous.address325 = getelementptr i8, ptr %1311, i64 %1314
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1310, ptr align 1 %buffer.contiguous.address325, <8 x i1> %55)
  %.spill.load326 = load { <8 x ptr>, <8 x i64> }, ptr %.spill24, align 64
  %1315 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1316 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load326, 1
  %1317 = extractelement <8 x ptr> %1315, i32 0
  %1318 = extractelement <8 x i64> %1316, i32 0
  %1319 = sub i64 %1318, 0
  %1320 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1321 = select i1 %1320, i64 %1319, i64 0
  %private.contiguous.address327 = getelementptr i8, ptr %1317, i64 %1321
  %private.contiguous.load328 = load <8 x float>, ptr %private.contiguous.address327, align 4
  %1322 = select <8 x i1> %55, <8 x float> %private.contiguous.load328, <8 x float> zeroinitializer
  %.spill.load329 = load { <8 x ptr>, <8 x i64> }, ptr %.spill52, align 64
  %1323 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load329, 1
  %1325 = extractelement <8 x ptr> %1323, i32 0
  %1326 = extractelement <8 x i64> %1324, i32 0
  %1327 = sub i64 %1326, 0
  %1328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1329 = select i1 %1328, i64 %1327, i64 0
  %private.contiguous.address330 = getelementptr i8, ptr %1325, i64 %1329
  %private.contiguous.load331 = load <8 x float>, ptr %private.contiguous.address330, align 4
  %1330 = select <8 x i1> %55, <8 x float> %private.contiguous.load331, <8 x float> zeroinitializer
  %1331 = fmul <8 x float> %1322, %1330
  %.spill.load332 = load { <8 x ptr>, <8 x i64> }, ptr %.spill36, align 64
  %1332 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1333 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load332, 1
  %1334 = extractelement <8 x ptr> %1332, i32 0
  %1335 = extractelement <8 x i64> %1333, i32 0
  %1336 = sub i64 %1335, 0
  %1337 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1338 = select i1 %1337, i64 %1336, i64 0
  %private.contiguous.address333 = getelementptr i8, ptr %1334, i64 %1338
  %private.contiguous.load334 = load <8 x float>, ptr %private.contiguous.address333, align 4
  %1339 = select <8 x i1> %55, <8 x float> %private.contiguous.load334, <8 x float> zeroinitializer
  %.spill.load335 = load { <8 x ptr>, <8 x i64> }, ptr %.spill46, align 64
  %1340 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1341 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load335, 1
  %1342 = extractelement <8 x ptr> %1340, i32 0
  %1343 = extractelement <8 x i64> %1341, i32 0
  %1344 = sub i64 %1343, 0
  %1345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1346 = select i1 %1345, i64 %1344, i64 0
  %private.contiguous.address336 = getelementptr i8, ptr %1342, i64 %1346
  %private.contiguous.load337 = load <8 x float>, ptr %private.contiguous.address336, align 4
  %1347 = select <8 x i1> %55, <8 x float> %private.contiguous.load337, <8 x float> zeroinitializer
  %1348 = fmul <8 x float> %1339, %1347
  %1349 = fadd <8 x float> %1331, %1348
  %.spill.load338 = load <8 x i64>, ptr %.spill35, align 64
  %1350 = extractvalue { ptr, i64 } %31, 0
  %1351 = extractelement <8 x i64> %.spill.load338, i32 0
  %1352 = sub i64 %1351, 0
  %1353 = mul i64 %1352, 4
  %buffer.contiguous.address339 = getelementptr i8, ptr %1350, i64 %1353
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1349, ptr align 1 %buffer.contiguous.address339, <8 x i1> %55)
  %.spill.load340 = load { <8 x ptr>, <8 x i64> }, ptr %.spill28, align 64
  %1354 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load340, 1
  %1356 = extractelement <8 x ptr> %1354, i32 0
  %1357 = extractelement <8 x i64> %1355, i32 0
  %1358 = sub i64 %1357, 0
  %1359 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1360 = select i1 %1359, i64 %1358, i64 0
  %private.contiguous.address341 = getelementptr i8, ptr %1356, i64 %1360
  %private.contiguous.load342 = load <8 x float>, ptr %private.contiguous.address341, align 4
  %1361 = select <8 x i1> %55, <8 x float> %private.contiguous.load342, <8 x float> zeroinitializer
  %.spill.load343 = load { <8 x ptr>, <8 x i64> }, ptr %.spill53, align 64
  %1362 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1363 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load343, 1
  %1364 = extractelement <8 x ptr> %1362, i32 0
  %1365 = extractelement <8 x i64> %1363, i32 0
  %1366 = sub i64 %1365, 0
  %1367 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1368 = select i1 %1367, i64 %1366, i64 0
  %private.contiguous.address344 = getelementptr i8, ptr %1364, i64 %1368
  %private.contiguous.load345 = load <8 x float>, ptr %private.contiguous.address344, align 4
  %1369 = select <8 x i1> %55, <8 x float> %private.contiguous.load345, <8 x float> zeroinitializer
  %1370 = fmul <8 x float> %1361, %1369
  %.spill.load346 = load { <8 x ptr>, <8 x i64> }, ptr %.spill38, align 64
  %1371 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1372 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load346, 1
  %1373 = extractelement <8 x ptr> %1371, i32 0
  %1374 = extractelement <8 x i64> %1372, i32 0
  %1375 = sub i64 %1374, 0
  %1376 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1377 = select i1 %1376, i64 %1375, i64 0
  %private.contiguous.address347 = getelementptr i8, ptr %1373, i64 %1377
  %private.contiguous.load348 = load <8 x float>, ptr %private.contiguous.address347, align 4
  %1378 = select <8 x i1> %55, <8 x float> %private.contiguous.load348, <8 x float> zeroinitializer
  %.spill.load349 = load { <8 x ptr>, <8 x i64> }, ptr %.spill48, align 64
  %1379 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1380 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load349, 1
  %1381 = extractelement <8 x ptr> %1379, i32 0
  %1382 = extractelement <8 x i64> %1380, i32 0
  %1383 = sub i64 %1382, 0
  %1384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1385 = select i1 %1384, i64 %1383, i64 0
  %private.contiguous.address350 = getelementptr i8, ptr %1381, i64 %1385
  %private.contiguous.load351 = load <8 x float>, ptr %private.contiguous.address350, align 4
  %1386 = select <8 x i1> %55, <8 x float> %private.contiguous.load351, <8 x float> zeroinitializer
  %1387 = fmul <8 x float> %1378, %1386
  %1388 = fadd <8 x float> %1370, %1387
  %.spill.load352 = load <8 x i64>, ptr %.spill37, align 64
  %1389 = extractvalue { ptr, i64 } %31, 0
  %1390 = extractelement <8 x i64> %.spill.load352, i32 0
  %1391 = sub i64 %1390, 0
  %1392 = mul i64 %1391, 4
  %buffer.contiguous.address353 = getelementptr i8, ptr %1389, i64 %1392
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1388, ptr align 1 %buffer.contiguous.address353, <8 x i1> %55)
  %.spill.load354 = load <8 x i1>, ptr %.spill29, align 1
  %1393 = and <8 x i1> %55, %.spill.load354
  %1394 = xor <8 x i1> %.spill.load354, splat (i1 true)
  %1395 = and <8 x i1> %55, %1394
  %1396 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1393)
  %1397 = bitcast <8 x i1> %1393 to i8
  %1398 = call i8 @llvm.cttz.i8(i8 %1397, i1 false)
  %1399 = zext i8 %1398 to i32
  %1400 = select i1 %1396, i32 %1399, i32 0
  %.spill.load355 = load <8 x i64>, ptr %.spill, align 64
  %1401 = add <8 x i64> splat (i64 32), %.spill.load355
  %1402 = add <8 x i64> splat (i64 33), %1401
  %.spill.load356 = load <8 x i64>, ptr %.spill14, align 64
  %1403 = add <8 x i64> %.spill.load356, %1402
  %tile_snapshot.spill.load357 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load357, 0
  %1405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load357, 1
  %1406 = add <8 x i64> %1405, splat (i64 128)
  %1407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1404, 0
  %1408 = insertvalue { <8 x ptr>, <8 x i64> } %1407, <8 x i64> %1406, 1
  %1409 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %1408, 1
  %1411 = extractelement <8 x ptr> %1409, i32 0
  %1412 = extractelement <8 x i64> %1410, i32 %1400
  %1413 = zext i32 %1400 to i64
  %1414 = mul i64 %1413, 4
  %1415 = sub i64 %1412, %1414
  %1416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1393)
  %1417 = select i1 %1416, i64 %1415, i64 0
  %private.contiguous.address358 = getelementptr i8, ptr %1411, i64 %1417
  %private.contiguous.load359 = load <8 x float>, ptr %private.contiguous.address358, align 4
  %1418 = select <8 x i1> %1393, <8 x float> %private.contiguous.load359, <8 x float> zeroinitializer
  %tile_snapshot.spill.load360 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill49, align 64
  %1419 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load360, 0
  %1420 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load360, 1
  %1421 = add <8 x i64> %1420, splat (i64 128)
  %1422 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1419, 0
  %1423 = insertvalue { <8 x ptr>, <8 x i64> } %1422, <8 x i64> %1421, 1
  %1424 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1425 = extractvalue { <8 x ptr>, <8 x i64> } %1423, 1
  %1426 = extractelement <8 x ptr> %1424, i32 0
  %1427 = extractelement <8 x i64> %1425, i32 %1400
  %1428 = zext i32 %1400 to i64
  %1429 = mul i64 %1428, 4
  %1430 = sub i64 %1427, %1429
  %1431 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1393)
  %1432 = select i1 %1431, i64 %1430, i64 0
  %private.contiguous.address361 = getelementptr i8, ptr %1426, i64 %1432
  %private.contiguous.load362 = load <8 x float>, ptr %private.contiguous.address361, align 4
  %1433 = select <8 x i1> %1393, <8 x float> %private.contiguous.load362, <8 x float> zeroinitializer
  %1434 = fmul <8 x float> %1418, %1433
  %tile_snapshot.spill.load363 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill30, align 64
  %1435 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load363, 0
  %1436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load363, 1
  %1437 = add <8 x i64> %1436, splat (i64 128)
  %1438 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1435, 0
  %1439 = insertvalue { <8 x ptr>, <8 x i64> } %1438, <8 x i64> %1437, 1
  %1440 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %1439, 1
  %1442 = extractelement <8 x ptr> %1440, i32 0
  %1443 = extractelement <8 x i64> %1441, i32 %1400
  %1444 = zext i32 %1400 to i64
  %1445 = mul i64 %1444, 4
  %1446 = sub i64 %1443, %1445
  %1447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1393)
  %1448 = select i1 %1447, i64 %1446, i64 0
  %private.contiguous.address364 = getelementptr i8, ptr %1442, i64 %1448
  %private.contiguous.load365 = load <8 x float>, ptr %private.contiguous.address364, align 4
  %1449 = select <8 x i1> %1393, <8 x float> %private.contiguous.load365, <8 x float> zeroinitializer
  %tile_snapshot.spill.load366 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill39, align 64
  %1450 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load366, 0
  %1451 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load366, 1
  %1452 = add <8 x i64> %1451, splat (i64 128)
  %1453 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1450, 0
  %1454 = insertvalue { <8 x ptr>, <8 x i64> } %1453, <8 x i64> %1452, 1
  %1455 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1456 = extractvalue { <8 x ptr>, <8 x i64> } %1454, 1
  %1457 = extractelement <8 x ptr> %1455, i32 0
  %1458 = extractelement <8 x i64> %1456, i32 %1400
  %1459 = zext i32 %1400 to i64
  %1460 = mul i64 %1459, 4
  %1461 = sub i64 %1458, %1460
  %1462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1393)
  %1463 = select i1 %1462, i64 %1461, i64 0
  %private.contiguous.address367 = getelementptr i8, ptr %1457, i64 %1463
  %private.contiguous.load368 = load <8 x float>, ptr %private.contiguous.address367, align 4
  %1464 = select <8 x i1> %1393, <8 x float> %private.contiguous.load368, <8 x float> zeroinitializer
  %1465 = fmul <8 x float> %1449, %1464
  %1466 = fadd <8 x float> %1434, %1465
  %1467 = extractvalue { ptr, i64 } %31, 0
  %1468 = extractelement <8 x i64> %1403, i32 %1400
  %1469 = zext i32 %1400 to i64
  %1470 = sub i64 %1468, %1469
  %1471 = mul i64 %1470, 4
  %buffer.contiguous.address369 = getelementptr i8, ptr %1467, i64 %1471
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1466, ptr align 1 %buffer.contiguous.address369, <8 x i1> %1393)
  %1472 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1395)
  %1473 = bitcast <8 x i1> %1395 to i8
  %1474 = call i8 @llvm.cttz.i8(i8 %1473, i1 false)
  %1475 = zext i8 %1474 to i32
  %1476 = select i1 %1472, i32 %1475, i32 0
  br label %direct.schedule.3

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.0
  br label %direct.schedule.1

direct.false:                                     ; preds = %direct.schedule.0
  br label %direct.schedule.4
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
